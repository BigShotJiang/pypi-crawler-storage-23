---
type: skill
domain: orchestration
---

# COST_OPTIMIZER
> **ROLE:** Token budget and model cost optimizer
> **TRIGGER:** Task assignment, model selection, or when token usage seems excessive

## Core Directive
Minimize cost per task while maintaining quality. Use the cheapest model that can handle the work. Every wasted token is stolen value.

## Step-by-Step Protocol
1. **Classify task complexity:** Simple (rename, format, docs) → fast tier. Features/refactoring → standard. Architecture/security → premium.
2. **Check task board tier:** Read `recommended_tier` on each task. Match YOUR model to the tier. Opus on a rename = waste.
3. **Estimate token budget:** Simple tasks <2K tokens. Standard <8K tokens. Premium <20K tokens. If exceeding, decompose.
4. **Optimize context:** Only load skills relevant to the domain. Don't inject full PULSE_OS.md for simple tasks. Use slim directive.
5. **Cache and reuse:** Check brain_query before researching. If brain has the answer, skip the LLM call entirely.

## Metrics & Thresholds
- Fast tier tasks: <2,000 tokens total (prompt + response)
- Standard tier tasks: <8,000 tokens total
- Premium tier tasks: <20,000 tokens total
- Model cost hierarchy: Haiku ($0.25/1M) < Flash ($0.10/1M) < Sonnet ($3/1M) < Opus ($15/1M)
- If task needs >3 skills loaded, it should be decomposed into subtasks

## Model Selection Matrix

| Task Type | Model | Tier | Max Tokens |
|-----------|-------|------|------------|
| Rename, format, docs | Haiku/Flash | fast | 2K |
| Bug fix, feature, test | Sonnet/Gemini Pro | standard | 8K |
| Architecture, audit | Opus/GPT-4 | premium | 20K |
| Brain query, search | No LLM needed | free | 0 |

## Anti-Patterns
- Using Opus for formatting or documentation tasks (10x cost for same result)
- Loading all 58 skills into context (wastes ~50K tokens, agent ignores most)
- Re-researching what the brain already knows (always query brain first)
- Not decomposing: one 20K-token task is worse than four 3K-token subtasks

## Tools to Use
- `brain_query.py --query "<task>"` — Free knowledge lookup (zero LLM cost)
- `pulse_relay.py --tasks "Title:domain:fast"` — Decompose and route to cheap models
- `pulse_save.py --learnings "..."` — Cache learnings for future agents (amortize cost)

## Verification
- [ ] Task tier matches model capability (no premium model on fast tasks)
- [ ] Brain queried before any research or implementation
- [ ] Context includes only relevant skills (max 3 per task)
- [ ] Total tokens within budget for tier
