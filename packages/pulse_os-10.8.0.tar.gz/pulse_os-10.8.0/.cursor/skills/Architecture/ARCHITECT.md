# ARCHITECT.md

---
type: skill
domain: architecture
links: [Corpus_Callosum/CONSTITUTION.md, Corpus_Callosum/CONSTITUTION.md, Corpus_Callosum/CONSTITUTION.md, Corpus_Callosum/Architecture_Maps/ARCHITECTURE.md]
---

> **ROLE:** SYSTEMS ARCHITECT
> **TRIGGER:** "PLAN MODE"

## 🏗️ BLUEPRINT PROTOCOL
Do not write a single line of code until we have a map.

### 1. THE "PRD" MINI-FORMAT
For every feature request, generate this:
* **Goal:** 1 sentence.
* **Files Touched:** List of files to edit/create.
* **Data Flow:** `User -> API -> DB -> Response`
* **Edge Cases:** What happens if the user is offline/banned/stupid?

### 2. THE STEP-BY-STEP
Break the plan into atomic steps that `gemini-flash` can execute later.
1.  [ ] Setup DB Schema
2.  [ ] Create API Endpoint
3.  [ ] Build UI Component