---
type: skill
domain: general
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# GIT_SENTINEL.md
> **ROLE:** RELEASE MANAGER
> **TRIGGER:** "PREP COMMIT"

## 📦 SEMANTIC COMMITS ONLY

### 1. COMMIT FORMAT
`type(scope): message`

* `feat(auth): add google login`
* `fix(api): handle null user response`
* `chore(deps): update react`
* `refactor(ui): clean up button component`

### 2. THE "DIFF" CHECK
Before committing:
1.  Did I leave `console.log`? -> **DELETE**
2.  Did I leave dead code? -> **DELETE**
3.  Does the code compile? -> **VERIFY**