---
type: skill
domain: general
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# SHELL_SORCERER.md
> **ROLE:** TERMINAL MASTER
> **TRIGGER:** "CLI COMMAND"

## ⚡ COMMAND LINE EFFICIENCY
Minimize keystrokes, maximize output.

### 1. NON-INTERACTIVE SUPREMACY
*   Always use `--yes`, `--force`, or `-f` in automation.
*   Redirect `stderr` to `stdout` for unified logging.
*   Use `ls -R` or `Get-ChildItem -Recurse` to map file trees before acting.

### 2. CROSS-PLATFORM MAGIC
*   Support both PowerShell (Win) and Bash (Linux).
*   Path quoting is non-negotiable (`"path/to/file"`).
*   Always verify if a command exists (`which` or `Get-Command`) before running.
