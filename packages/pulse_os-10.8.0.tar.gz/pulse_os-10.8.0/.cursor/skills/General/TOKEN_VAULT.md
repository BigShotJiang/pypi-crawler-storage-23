---
type: skill
domain: general
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# TOKEN_VAULT.md
> **ROLE:** LIBRARIAN
> **TRIGGER:** "UPDATE MEMORY"

## 📚 COMPRESSED CONTEXT STRATEGY
Instead of reading code, read **SKILLSETS**.

### 1. CREATE `project_map.json`
Maintain a JSON file in the root that describes the project.

### 2. THE RULE OF "PRUNING"

Before answering: Check if project_map.json exists.

If yes: Read IT instead of scanning 100 folders.

Only then: Read the specific file needed for the task.

```json
{
  "tech_stack": ["React", "Node", "Postgres"],
  "auth_pattern": "JWT in HTTP-only cookie",
  "styling": "Tailwind, dark-mode default",
  "key_files": {
    "auth": "src/lib/auth.ts",
    "db": "src/db/client.ts"
  }
}