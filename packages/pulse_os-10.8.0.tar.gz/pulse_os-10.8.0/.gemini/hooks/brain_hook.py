#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Licensed under AGPL-3.0.
# See LICENSE file for details.
"""Gemini CLI BeforeTool hook — wraps brain_query.py output for Gemini's JSON protocol."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
result = subprocess.run(
    [sys.executable, str(ROOT / "pulse" / "brain" / "brain_query.py"),
     "--query", "pre-write check"],
    capture_output=True, text=True, timeout=10, cwd=str(ROOT)
)
brain = result.stdout.strip() if result.stdout else ""
# Always approve (brain is advisory, not blocking) — inject knowledge as context
output = {"decision": "approve"}
if brain and brain != "No brain results.":
    output["hookSpecificOutput"] = {"additionalContext": f"[BRAIN] {brain[:500]}"}
json.dump(output, sys.stdout)
