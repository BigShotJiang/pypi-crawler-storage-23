// PULSE API client — fetch wrapper for all endpoints

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'
const BASE = `${BASE_URL}/v1`

async function get<T>(path: string): Promise<T> {
  const res = await fetch(`${BASE}${path}`)
  if (!res.ok) throw new Error(`API ${res.status}: ${res.statusText}`)
  return res.json()
}

// Brain endpoints
export const api = {
  getSystemOverview: () => get<any>('/system/overview'),
  getAgents: () => get<{ count: number; agents: any[] }>('/agents'),
  getWorkers: () => get<{ count: number; workers: any[] }>('/workers'),
  getBrainStats: () => get<any>('/brain/stats'),
  getBrainHealth: () => get<any>('/brain/health'),
  getTasks: () => get<{ status: string; dispatches: any[] }>('/brain/tasks'),
  getLessons: (offset = 0, limit = 200) => get<{ count: number; offset: number; limit: number; lessons: string[] }>(`/brain/lessons?offset=${offset}&limit=${limit}`),
  getFailures: (offset = 0, limit = 200) => get<{ count: number; offset: number; limit: number; failures: string[] }>(`/brain/failures?offset=${offset}&limit=${limit}`),
  getPatterns: (offset = 0, limit = 200) => get<{ count: number; offset: number; limit: number; patterns: string[] }>(`/brain/patterns?offset=${offset}&limit=${limit}`),
  getGraph: () => get<{ nodes: number; edges: number; data: any }>('/brain/graph'),
  getSchemas: () => get<{ count: number; schemas: any[] }>('/brain/schemas'),
  getProcedures: () => get<{ count: number; procedures: any[] }>('/brain/procedures'),
  getWants: () => get<{ count: number; wants: any[] }>('/brain/wants'),
  getDontWants: () => get<{ count: number; dont_wants: any[] }>('/brain/dont_wants'),
  getStrategicIntents: () => get<{ count: number; strategic_intents: any[] }>('/brain/strategic_intents'),
  getAntiPatterns: () => get<{ count: number; anti_patterns: any[] }>('/brain/anti_patterns'),
  searchBrain: (q: string) => get<any>(`/brain/search?q=${encodeURIComponent(q)}`),
}
