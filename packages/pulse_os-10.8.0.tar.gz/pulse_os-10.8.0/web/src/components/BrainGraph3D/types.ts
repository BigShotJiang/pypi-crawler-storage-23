// ─── API response types (matches /v1/brain/graph) ─────────────

export interface ApiNode {
  id: string | number
  label?: string
  text?: string
  type: string
  weight?: number
  confidence?: number
  salience?: number
}

export interface ApiEdge {
  id?: string
  from?: string | number
  to?: string | number
  source?: string | number
  target?: string | number
  type?: string
  label?: string
}

export interface ApiGraphResponse {
  nodes: number
  edges: number
  data: {
    nodes: ApiNode[]
    edges: ApiEdge[]
  }
}

// ─── Transformed types for 3D rendering ─────────────────────

export interface GraphNode3D {
  id: string
  label: string
  type: string
  weight: number
  confidence: number
  degree: number
  radius: number
  colorIndex: number
}

export interface GraphEdge3D {
  sourceIndex: number
  targetIndex: number
  type: string
}

export interface TransformedGraph {
  nodes: GraphNode3D[]
  edges: GraphEdge3D[]
}

// ─── Force layout worker messages ───────────────────────────

export interface ForceParams {
  repulsion: number
  attraction: number
  gravity: number
  damping: number
  maxIterations: number
  restLength: number
}

// ─── Interaction state ──────────────────────────────────────

export interface HoverState {
  nodeIndex: number
  node: GraphNode3D
  position: [number, number, number]
}
