import type { ForceParams } from './types'

export const NODE_TYPE_COLORS: Record<string, [number, number, number]> = {
  lesson:       [0.133, 0.773, 0.369],   // #22c55e
  failure:      [0.937, 0.267, 0.267],   // #ef4444
  pattern:      [0.231, 0.510, 0.965],   // #3b82f6
  schema:       [0.659, 0.333, 0.969],   // #a855f7
  procedure:    [0.925, 0.282, 0.600],   // #ec4899
  want:         [0.961, 0.620, 0.043],   // #f59e0b
  dont_want:    [0.976, 0.451, 0.086],   // #f97316
  intent:       [0.024, 0.714, 0.831],   // #06b6d4
  anti_pattern: [0.839, 0.153, 0.157],   // #d62728
  decision:     [0.553, 0.827, 0.780],   // #8dd3c7
  concept:      [0.392, 0.455, 0.545],   // #64748b
  default:      [0.392, 0.455, 0.545],   // #64748b
}

export const NODE_TYPE_HEX: Record<string, string> = {
  lesson:       '#22c55e',
  failure:      '#ef4444',
  pattern:      '#3b82f6',
  schema:       '#a855f7',
  procedure:    '#ec4899',
  want:         '#f59e0b',
  dont_want:    '#f97316',
  intent:       '#06b6d4',
  anti_pattern: '#d62728',
  decision:     '#8dd3c7',
  concept:      '#64748b',
  default:      '#64748b',
}

export const NODE_SIZE = {
  min: 0.35,
  max: 1.2,
  weightScale: 0.1,
  degreeScale: 0.06,
}

export const FORCE_PARAMS: ForceParams = {
  repulsion: 40,
  attraction: 0.005,
  gravity: 0.03,
  damping: 0.88,
  maxIterations: 250,
  restLength: 8,
}

export const HERO_FORCE_PARAMS: ForceParams = {
  repulsion: 200,
  attraction: 0.002,
  gravity: 0.005,
  damping: 0.92,
  maxIterations: 200,
  restLength: 15,
}

export const CAMERA = {
  fov: 60,
  near: 0.1,
  far: 800,
  position: [0, 0, 140] as [number, number, number],
}

export const SCENE = {
  fogNear: 120,
  fogFar: 350,
  bgColor: '#020617',
}

export const ANIMATION = {
  pulseSpeed: 0.5,
  pulseCount: 50,
}

export const HERO_NODE_COUNT = 100
