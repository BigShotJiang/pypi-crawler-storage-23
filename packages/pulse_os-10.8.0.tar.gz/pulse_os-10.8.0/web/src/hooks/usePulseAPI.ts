import { useCallback } from 'react'
import { api } from '../api/client'
import { usePolling } from './usePolling'

/** Poll system overview every 5s */
export function useSystemOverview() {
  const fetcher = useCallback(() => api.getSystemOverview(), [])
  return usePolling(fetcher, 5000)
}

/** Poll agents every 5s */
export function useAgents() {
  const fetcher = useCallback(() => api.getAgents(), [])
  return usePolling(fetcher, 5000)
}

/** Poll workers every 5s */
export function useWorkers() {
  const fetcher = useCallback(() => api.getWorkers(), [])
  return usePolling(fetcher, 5000)
}

/** Poll tasks every 5s */
export function useTasks() {
  const fetcher = useCallback(() => api.getTasks(), [])
  return usePolling(fetcher, 5000)
}

/** Poll brain stats every 10s */
export function useBrainStats() {
  const fetcher = useCallback(() => api.getBrainStats(), [])
  return usePolling(fetcher, 10000)
}
