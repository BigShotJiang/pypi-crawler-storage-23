import { useCallback } from 'react'
import { api } from '../api/client'
import { usePolling } from './usePolling'

/** Poll task board (/v1/brain/tasks) every 5s */
export function useTaskBoard() {
  const fetcher = useCallback(() => api.getTasks(), [])
  return usePolling(fetcher, 5000)
}
