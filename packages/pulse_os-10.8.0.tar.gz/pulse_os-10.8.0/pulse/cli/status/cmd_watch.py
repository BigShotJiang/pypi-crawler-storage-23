#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Auto-refreshing watch command."""
from __future__ import annotations

import os
import time

from pulse.cli.status.cmd_status import cmd_status


def cmd_watch():
    """Auto-refreshing status dashboard."""
    try:
        while True:
            os.system("cls" if os.name == "nt" else "clear")
            cmd_status()
            print("")
            print("  [WATCHING] Refreshing every 3s... Press Ctrl+C to exit.")
            time.sleep(3)
    except KeyboardInterrupt:
        print("")
        print("[PULSE] Watch stopped.")
