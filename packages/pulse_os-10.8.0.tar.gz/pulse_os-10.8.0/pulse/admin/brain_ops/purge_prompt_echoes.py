#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Purge SCRIBE_PROMPT example echoes from brain files.

One-off cleanup script that scans all markdown brain files and JSON intent files,
removes entries that are echoes of the SCRIBE_PROMPT YES/NO examples (Haiku
contamination from the 70-agent extraction swarm), and archives originals.

Usage:
    python -m pulse.admin.brain_ops.purge_prompt_echoes --dry-run   # preview
    python -m pulse.admin.brain_ops.purge_prompt_echoes --verbose    # execute
"""
import io
import json
import os
import shutil
import sys
from datetime import datetime
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent.parent.parent

if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

if os.name == "nt" and __name__ == "__main__":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

from pulse.core.brain_utils import HIPPOCAMPUS_DIR
from pulse.admin.retroactive.retroactive_llm_extractor import _is_prompt_echo

ARCHIVE_DIR = HIPPOCAMPUS_DIR / "Archive"
BRAIN_MD_FILES = [
    HIPPOCAMPUS_DIR / "Failures" / "auto_fails.md",
    HIPPOCAMPUS_DIR / "Lessons" / "auto_lessons.md",
    HIPPOCAMPUS_DIR / "Patterns" / "auto_patterns.md",
]
INTENT_JSON_FILES = [
    HIPPOCAMPUS_DIR / "Evidence" / "Intents" / "wants.json",
    HIPPOCAMPUS_DIR / "Evidence" / "Intents" / "dont_wants.json",
]


def _archive(path: Path, ts: str):
    """Archive a file before modifying it."""
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
    dest = ARCHIVE_DIR / f"{path.stem}_pre_purge_{ts}{path.suffix}"
    shutil.copy2(path, dest)
    return dest


def purge_markdown(filepath: Path, dry_run=False, verbose=False) -> dict:
    """Scan a markdown brain file and remove prompt-echo sections."""
    if not filepath.exists():
        return {"file": filepath.name, "total": 0, "purged": 0}

    text = filepath.read_text(encoding="utf-8", errors="replace")
    sections = text.split("\n## ")
    if len(sections) < 2:
        return {"file": filepath.name, "total": 0, "purged": 0}

    preamble = sections[0]
    kept = []
    purged = 0

    for section in sections[1:]:
        lines = section.strip().split("\n")
        title = lines[0].strip()
        body = "\n".join(lines[1:]).strip()
        # Check title and body for prompt echoes
        if _is_prompt_echo(title) or _is_prompt_echo(body):
            purged += 1
            if verbose:
                print(f"  PURGE: {title[:70]}")
        else:
            kept.append(section)

    total = len(sections) - 1  # exclude preamble

    if purged > 0 and not dry_run:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        _archive(filepath, ts)
        new_text = preamble
        for sec in kept:
            new_text += "\n## " + sec
        filepath.write_text(new_text, encoding="utf-8")

    return {"file": filepath.name, "total": total, "purged": purged, "kept": total - purged}


def purge_json_intents(filepath: Path, dry_run=False, verbose=False) -> dict:
    """Scan a JSON intents file and remove prompt-echo entries."""
    if not filepath.exists():
        return {"file": filepath.name, "total": 0, "purged": 0}

    data = json.loads(filepath.read_text(encoding="utf-8"))
    if not isinstance(data, list):
        return {"file": filepath.name, "total": 0, "purged": 0}

    kept = []
    purged = 0
    for item in data:
        text = item.get("want", "") or item.get("dont_want", "") or item.get("text", "")
        if _is_prompt_echo(text):
            purged += 1
            if verbose:
                print(f"  PURGE: {text[:70]}")
        else:
            kept.append(item)

    total = len(data)

    if purged > 0 and not dry_run:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        _archive(filepath, ts)
        filepath.write_text(json.dumps(kept, indent=2, ensure_ascii=False), encoding="utf-8")

    return {"file": filepath.name, "total": total, "purged": purged, "kept": total - purged}


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Purge SCRIBE_PROMPT echoes from brain")
    parser.add_argument("--dry-run", action="store_true", help="Preview without modifying files")
    parser.add_argument("--verbose", "-v", action="store_true", help="Show each purged item")
    args = parser.parse_args()

    print(f"{'='*60}")
    print(f"BRAIN PURGE — Prompt Echo Cleanup {'(DRY RUN)' if args.dry_run else ''}")
    print(f"{'='*60}\n")

    total_purged = 0

    # Markdown brain files
    for md_file in BRAIN_MD_FILES:
        stats = purge_markdown(md_file, dry_run=args.dry_run, verbose=args.verbose)
        total_purged += stats.get("purged", 0)
        print(f"  {stats['file']}: {stats.get('purged', 0)}/{stats['total']} purged"
              f" -> {stats.get('kept', stats['total'])} kept")

    # JSON intent files
    for json_file in INTENT_JSON_FILES:
        stats = purge_json_intents(json_file, dry_run=args.dry_run, verbose=args.verbose)
        total_purged += stats.get("purged", 0)
        print(f"  {stats['file']}: {stats.get('purged', 0)}/{stats['total']} purged"
              f" -> {stats.get('kept', stats['total'])} kept")

    # Clear dedup cache after purge so new writes don't skip valid entries
    if not args.dry_run and total_purged > 0:
        try:
            from pulse.brain.save_writers import _DEDUP_CACHE
            _DEDUP_CACHE.clear()
            print("\n  Dedup cache cleared.")
        except ImportError:
            pass

    print(f"\n{'='*60}")
    print(f"TOTAL: {total_purged} prompt echoes {'would be ' if args.dry_run else ''}purged")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
