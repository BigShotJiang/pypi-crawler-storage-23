# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
# See LICENSE file for details.
import os
from pathlib import Path
import re

SKILLS_DIR = Path(".cursor/skills")
CORE_LINKS = "links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]"

def wire_skills_to_laws():
    for skill_file in SKILLS_DIR.rglob("*.md"):
        if skill_file.is_dir(): continue
        
        try:
            content = skill_file.read_text(encoding="utf-8")
        except Exception:
            continue
            
        if "links: [" in content:
            # Check if CORE_LINKS already present
            if "Corpus_Callosum/CONSTITUTION.md" in content and "PULSE_OS.md" in content:
                print(f"Skipping {skill_file.name} - already linked to Laws.")
                continue
            
            # Update existing links if CORE_LINKS is missing
            new_content = re.sub(r"links: \[.*?\]", CORE_LINKS, content)
        else:
            # Add new header with CORE_LINKS
            domain = "general" # Default domain
            name_upper = skill_file.name.upper()
            if "SECURITY" in name_upper or "ADVERSARIAL" in name_upper or "TRUST" in name_upper or "SENTINEL" in name_upper or "AUDITOR" in name_upper or "LINT" in name_upper:
                domain = "security"
            elif "ARCHITECT" in name_upper or "SYSTEM" in name_upper or "COMPLEXITY" in name_upper or "DATABASE" in name_upper or "KAFKA" in name_upper or "NETWORK" in name_upper or "UI" in name_upper or "UX" in name_upper:
                domain = "architecture"
            elif "CODE" in name_upper or "REFACTOR" in name_upper or "TEST" in name_upper or "DOCKER" in name_upper or "CI_CD" in name_upper or "TYPE" in name_upper or "API" in name_upper:
                domain = "development"
            elif "ORCHESTRATOR" in name_upper or "SWARM" in name_upper or "CONTEXT" in name_upper or "MEMORY" in name_upper or "BRAIN" in name_upper or "META" in name_upper or "SESSION" in name_upper:
                domain = "orchestration"
            
            header = (
                f"---\n"
                f"type: skill\n"
                f"domain: {domain}\n"
                f"{CORE_LINKS}\n"
                f"---\n\n"
            )
            new_content = header + content
            
        skill_file.write_text(new_content, encoding="utf-8")
        print(f"Wired {skill_file.name} to Laws.")

if __name__ == "__main__":
    wire_skills_to_laws()
