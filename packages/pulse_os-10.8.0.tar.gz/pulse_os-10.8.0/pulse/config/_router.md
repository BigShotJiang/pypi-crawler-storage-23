# Configuration - Router
> **Context:** Automation Tuning

## Quick Navigation
1. **Brain Config** → `./brain_config.json`
2. **Pulse Daemon Config** → `./pulse_daemon.json`

## When to Read This
- Adjusting synthesis thresholds
- Modifying daemon polling rates
