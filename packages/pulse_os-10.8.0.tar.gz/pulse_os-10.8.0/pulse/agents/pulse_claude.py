#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
# See LICENSE file for details.
"""
PULSE v3 - Continuous daemon for real-time conversation capture.
Run ONCE at session start, stays alive monitoring for new interactions.
Usage: python pulse.py [--verbose] [--test] [--reprocess]
"""
import json, sys, re, signal, time
from datetime import datetime, timezone
from pathlib import Path

# Add Utilities to path
SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent.parent

# When run directly, ensure pulse package is importable
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from pulse.core.pulse_crypto import PulseCrypto
from pulse.core.pii_filter import redact_pii

# --- Configuration ---
STATE_DIR = ROOT_DIR / "state"

HOME_CLAUDE = Path.home() / ".claude"
PROJECTS_DIR = HOME_CLAUDE / "projects"
LOG_FILE = STATE_DIR / "pulse_captured_claude.log"
TIMESTAMP_FILE = STATE_DIR / "pulse_last_timestamp.txt"
POLL_INTERVAL = 0.5
TEST_DURATION = 10


def extract_text_from_content(content):
    """Extract plain text from message content blocks."""
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                t = block.get("text", "").strip()
                if t:
                    parts.append(t)
            elif isinstance(block, str):
                parts.append(block.strip())
        return "\n".join(parts)
    return ""


def clean_text(text, max_len=5000):
    """Strip system reminders, collapse whitespace, truncate."""
    text = re.sub(r'<system-reminder>.*?</system-reminder>', '', text, flags=re.DOTALL)
    text = text.encode("ascii", errors="ignore").decode("ascii")
    text = re.sub(r'\s+', ' ', text).strip()
    return text[:max_len] + "..." if len(text) > max_len else text


def format_log_entry(ts_iso, role, text):
    """Format a single log line: [YYYY-MM-DD HH:MM:SS] ROLE: text"""
    try:
        if isinstance(ts_iso, str):
            dt = datetime.fromisoformat(ts_iso.replace("Z", "+00:00"))
        elif isinstance(ts_iso, (int, float)):
            dt = datetime.fromtimestamp(ts_iso / 1000, tz=timezone.utc)
        else:
            dt = datetime.now(tz=timezone.utc)
        ts_str = dt.strftime("%Y-%m-%d %H:%M:%S")
    except (ValueError, OSError):
        ts_str = str(ts_iso)
    return f"[{ts_str}] {role}: {clean_text(text)}"


class PulseDaemon:
    """Continuous monitoring daemon. Stays alive for the entire session."""

    def __init__(self, verbose=False, test_mode=False, reprocess=False):
        self.verbose, self.test_mode, self.reprocess = verbose, test_mode, reprocess
        self.running, self.capture_count, self.last_timestamp = True, 0, ""
        self.file_positions = {}  # {filepath_str: byte_offset}
        self.known_files = set()
        self.crypto = PulseCrypto()
        self._load_state()
        signal.signal(signal.SIGINT, self._handle_signal)
        signal.signal(signal.SIGTERM, self._handle_signal)

    def _handle_signal(self, signum, frame):
        self.running = False

    def _load_state(self):
        if not self.reprocess and TIMESTAMP_FILE.exists():
            text = TIMESTAMP_FILE.read_text(encoding="utf-8").strip()
            if text:
                self.last_timestamp = text

    def _save_state(self):
        if self.last_timestamp:
            TIMESTAMP_FILE.write_text(self.last_timestamp + "\n", encoding="utf-8")

    def _find_project_dirs(self):
        dirs = []
        if not PROJECTS_DIR.exists():
            return dirs
        for d in PROJECTS_DIR.iterdir():
            if d.is_dir():
                (dirs.insert(0, d) if "PULSE" in d.name else dirs.append(d))
        return dirs

    def _discover_session_files(self):
        files = set()
        for pd in self._find_project_dirs():
            files.update(pd.glob("*.jsonl"))
        return files

    def _read_new_entries(self, filepath):
        """Read NEW entries using byte offset tracking. Only reads appended bytes."""
        entries = []
        try:
            file_size = filepath.stat().st_size
        except OSError:
            return entries
        last_pos = self.file_positions.get(str(filepath), 0)
        if file_size < last_pos:
            last_pos = 0
        if file_size == last_pos:
            return entries
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                f.seek(last_pos)
                new_content = f.read()
                self.file_positions[str(filepath)] = f.tell()
            for line in new_content.splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    continue
                msg_type = data.get("type", "")
                if msg_type not in ("user", "assistant"):
                    continue
                timestamp = data.get("timestamp", "")
                if self.last_timestamp and timestamp and timestamp <= self.last_timestamp:
                    continue
                text = extract_text_from_content(data.get("message", {}).get("content", ""))
                if text:
                    role = "USER" if msg_type == "user" else "CLAUDE"
                    entries.append((timestamp, role, text, data.get("sessionId", "")))
        except (OSError, UnicodeDecodeError) as e:
            if self.verbose:
                print(f"  Warning: {filepath.name}: {e}")
        return entries

    def _append_to_log(self, entries):
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            for ts, role, text, sid in entries:
                content_part = format_log_entry(ts, role, redact_pii(text))
                signature = self.crypto.sign_string(content_part, "claude_daemon")
                f.write(f"{content_part} | SIG: {signature}\n")

    def _initialize_positions(self):
        """On fresh start, skip existing content. With timestamp, filter by time."""
        if self.reprocess or self.last_timestamp:
            return
        files = self._discover_session_files()
        for f in files:
            try:
                self.file_positions[str(f)] = f.stat().st_size
            except OSError:
                pass
        self.known_files = files

    def check_for_new_entries(self):
        all_new = []
        current_files = self._discover_session_files()
        new_files = current_files - self.known_files
        if new_files and self.verbose:
            for nf in new_files:
                print(f"  New session file detected: {nf.name}")
        self.known_files = current_files
        for fp in current_files:
            all_new.extend(self._read_new_entries(fp))
        all_new.sort(key=lambda x: x[0] if x[0] else "")
        return all_new

    def run(self):
        """Main daemon loop. Runs until interrupted."""
        print("=" * 55)
        print("  PULSE v3 - Real-Time Conversation Daemon")
        print("=" * 55)
        print(f"  Log:     {LOG_FILE}")
        print(f"  Poll:    every {POLL_INTERVAL}s")
        if self.last_timestamp:
            print(f"  Resume:  {self.last_timestamp}")
        if self.test_mode:
            print(f"  Test:    exit after {TEST_DURATION}s")
        print("\n  Daemon started. Monitoring for new interactions...")
        print("  Press Ctrl+C to stop.\n")
        self._initialize_positions()
        t0 = time.time()
        while self.running:
            try:
                new_entries = self.check_for_new_entries()
                if new_entries:
                    self._append_to_log(new_entries)
                    for ts, role, text, sid in new_entries:
                        self.capture_count += 1
                        print(f"  [{self.capture_count}] {role}: {clean_text(text, 80)}")
                        if isinstance(ts, str) and ts > self.last_timestamp:
                            self.last_timestamp = ts
                    self._save_state()
                if self.test_mode and (time.time() - t0) >= TEST_DURATION:
                    print(f"\n  Test mode: exiting after {TEST_DURATION}s")
                    break
                time.sleep(POLL_INTERVAL)
            except Exception as e:
                if self.verbose:
                    print(f"  Error: {e}")
                time.sleep(POLL_INTERVAL)
        self._save_state()
        print(f"\n{'=' * 55}")
        print(f"  Pulse daemon stopped. Captured: {self.capture_count}")
        print(f"  Log: {LOG_FILE}")
        print(f"{'=' * 55}")


if __name__ == "__main__":
    v = "--verbose" in sys.argv or "-v" in sys.argv
    PulseDaemon(verbose=v, test_mode="--test" in sys.argv,
                reprocess="--reprocess" in sys.argv).run()
