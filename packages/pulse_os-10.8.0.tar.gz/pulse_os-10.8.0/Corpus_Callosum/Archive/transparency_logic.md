# Constitutional System - Transparency Logic
> **Context:** Task-Specific Applications & Enforcement

## Law 9 Propagation Checklist
Show this BEFORE declaring work complete:
- ✅ CHANGELOG.md updated.
- ✅ ui/manifesto.py updated (if applicable).
- ✅ SESSION.md updated.
- ✅ evidence/*.json updated.
- ✅ _growth_metrics.json updated.

---

## Examples by Task Type

### 1. Feature (Multi-file)
**Requirement:** Full Work Template. Must show Law 1 (SoC) and Law 6 (Pure Core) compliance.

### 2. Search/Exploration
**Requirement:** Minimal Template. Must list all files found via Grep/Glob.

### 3. Git Commit
**Requirement:** Minimal Template. Must verify NO co-author lines and correct format: `feat(VX.X): Description`.

---

## Anti-Examples (What NOT to Do)
- **❌ No Rule Declaration:** Starting work without the Ceremony.
- **❌ Partial Law 9:** Only showing 1-2 checklist items.
- **❌ Guessing on Uncertainty:** Proceeding without user clarification on ambiguous rules.
- **❌ Silent Violation:** Bypassing a rule without a request or logging.

---

## Enforcement
Templates are enforced via **Rule 0.2** (Mandatory Declaration) and **Rule 0.4** (Violation Logging). Failure to use the correct template is a constitutional violation.
