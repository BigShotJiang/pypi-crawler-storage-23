# Tier 1 Laws: 4-6
> **Context:** Legal, Tools & Platform Independence

---

## Law 4: Commercial-Safe Dependencies Only
**Statement:** BEFORE adding ANY dependency, CHECK THE LICENSE.

| ✅ Approved | ❌ Forbidden |
|------------|-------------|
| MIT, Apache 2.0 | GPL, AGPL (viral) |
| BSD, CC-BY-SA | CC-BY-NC (non-commercial) |
| LGPL, CC0 | Unknown |

---

## Law 5: Always Upgrade
**Statement:** If a new tool is better, faster, and has same/better license → UPGRADE IMMEDIATELY.

- Don't keep inferior tools out of laziness.
- Example: Chatterbox (MIT) replaced OpenVoice (GPL-like).

---

## Law 6: No Platform Imports in Core
**Statement:** `core/` is a pure library. Must work without Telegram/specific CLI wrappers.

```python
# ❌ FORBIDDEN in core/
from telegram import Update
```

**Rationale:** Core should be reusable in non-Telegram contexts (API, mobile, web).
