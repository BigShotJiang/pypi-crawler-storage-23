# Tier 1 Laws: 1-3
> **Context:** Engine Constraints & Quality Standards

---

## Law 1: Separation of Concerns (SoC)
**Statement:** Every module is a dumb black box. UI draws, Core translates, Handlers orchestrate.

| Layer | Responsibility | Forbidden |
|-------|----------------|-----------|
| `ui/` | Pure drawings. Formatted strings. | NO logic, NO state. |
| `core/` | Raw engine. Text in/out. | NO platform imports. |
| `handlers/` | Traffic routing. | NO engine logic. |

**Rationale:** When we refactor, nothing breaks. Each piece is independently replaceable.

---

## Law 2: Universal Solutions Only
**Statement:** Every solution MUST work for ALL languages, not just tested ones.

```python
# ✅ REQUIRED
def detect_script_contamination(text, target_code):
    # Works for ANY language via Unicode ranges
```

**Golden Test:** "Will this work for Khmer? Tagalog? Arabic?" If NO → redesign.

---

## Law 3: No Regressions
**Statement:** If it works, don't break it. Every update must pass ALL previous tests.

- Check `CHANGELOG.md` before modification.
- Run `python test_universal.py` after translation changes.
- If you broke something working, revert immediately.
