# Rule Enforcement - Violation Handling
> **Context:** Tier 2-4 Rules & Response Protocols

---

## TIER 2: ARCHITECTURAL RULES (Inviolable)

### SoC: Module Boundaries
**Rule:** Respect layer boundaries (ui/, core/, handlers/, state/).
**Severity:** HIGH
**Linked to:** Law 1

### Pure Core Principle
**Rule:** core/ has zero framework dependencies (reusable library).
**Severity:** HIGH
**Linked to:** Law 6

---

## TIER 3: OPERATIONAL RULES (Read Before Starting Work)

### Commit Procedures
**Rule:** NEVER auto-commit. ALWAYS ask user first.
**Severity:** HIGH
**Format:** `feat(V##.#): Short description` - NO co-author lines.

### Testing Procedures
**Rule:** Run tests BEFORE commit if translation logic changed.
**Severity:** HIGH
**Test Matrix:** `test_universal.py` (15 min), `test_speed.py` (45 sec).

---

## TIER 4: PREFERENCES (Quality Standards)

### Naming Conventions
**Rule:** Follow PEP 8 (snake_case functions, PascalCase classes).
**Severity:** LOW

### Documentation Style
**Rule:** Docstrings for public functions, inline comments for complex logic.
**Severity:** LOW

---

## IMPLEMENTATION CHECKLIST

### Files Created:
- ✅ `Corpus_Callosum/Constitutional_Laws/Tier_0_Meta/enforcement_protocol.md`
- ✅ `Corpus_Callosum/Constitutional_Laws/Tier_0_Meta/violation_handling.md`

### Procedures:
- Rule Reading Ceremony (mandatory)
- Rule Declaration Template (mandatory)
- Violation Escalation Procedure (if rule violated)
