# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [9.1.0] - 2026-02-16

### Added
- **Skills-used Tracking**: Automated recording and propagation of skills applied by agents during tasks.
- **Unified Swarm CLI Enhancements**: Improved `--skills-used` flag propagation and CLI autopilot support.

## [9.0.0] - 2026-02-13

### Added
- **Swarm Autopilot Mode**: Subscription-based autonomous agents that poll the task board.
- **Background Workers**: Headless daemons for true autonomous task execution.
- **Web Monitoring Dashboard**: Minimal FastAPI dashboard for real-time swarm visualization.
- **Cost Tracking**: Per-task token usage and cost estimation in `pulse costs`.
- **Agent Heartbeat Tracking**: Live activity monitoring for all swarm participants.
- **Auto-tier Detection**: Automatic selection of model tier based on model name.
- **Pulse Watch Command**: Auto-refreshing terminal dashboard in the CLI.
- **Smoke Test Suite**: Comprehensive `tests/smoke_test.py` to validate system health.
- **Knowledge Loop**: Automated extraction, boot, and save write-back for agent learnings.
- **Pulse History Command**: Timeline view of completed tasks.
- **Mid-session Notifications**: Background thread in wrapper to notify of new tasks.

### Changed
- Swarm autopilot is now the default mode for agent CLI commands (`pulse gemini`, etc.).
- Expanded worker command allowlist to include `mkdir`, `type`, `cat`, and `echo`.
- Increased `MAX_TOOL_ITERATIONS` to 25 for background workers.

## [8.0.0] - 2026-02-11

### Added
- **Security Audit V3**: Critical system hardening and API key vaulting.
- **Synaptic Consolidation**: Brain deduplication and manifest generation.
- **Adaptive Boot**: Smart context injection reducing agent boot tokens by ~60%.
- **Agent Self-Organization Protocol (ASOP)**: Multi-agent governance and coordination rules.
- **Plans Digestion Engine**: Automated processing of strategic intents and personal plans.
- **Synaptic Mesh**: Deep linking of all skills and memories across the Hippocampus.

### Changed
- Reorganized `Autonomic_System/Daemons` structure for improved modularity.
- Switched project license from MIT to AGPL-3.0.
- Unified CLI entry point in `pulse_cli.py`.
