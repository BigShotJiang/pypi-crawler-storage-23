# Governance Map

> Navigation file for Corpus Callosum — the stable governance layer of PULSE.

## What Is Corpus Callosum?

The bridge between intent and action. Contains the constitutional laws that govern all agents and the protocols that define how they coordinate. Immutable principles live here; learned knowledge lives in Hippocampus.

## Structure

```
Corpus_Callosum/
├── CONSTITUTION.md          ← The single sacred text (Tier 0-3)
├── GOVERNANCE_MAP.md        ← This file
├── authorized_humans.json   ← Human authority registry
├── Protocols/               ← Operational how-to
│   ├── ASOP.md             ← Task board coordination
│   ├── HOOKS.md            ← Brain-first enforcement
│   ├── WORKFLOW.md         ← Agent workflow
│   ├── AGENT_CACHE_PROTOCOL.md ← Brain-as-cache
│   └── BENCHMARK_SYSTEM.md ← Goal tracking
└── Archive/                 ← Historical docs (read-only)
```

## Tier Overview

| Tier | Name | What | Where |
|------|------|------|-------|
| 0 | Immutables | Ethics: non-harm, privacy, truth, human override | CONSTITUTION.md §Tier 0 |
| 1 | Sacred Laws | Engineering: brain-first, SoC, no regressions, crypto integrity | CONSTITUTION.md §Tier 1 |
| 2 | Protocols | Operational: ASOP, hooks, workflow, cache, benchmarks | Protocols/ |
| 3 | Preferences | Style: snake_case, cleanup, propagation | CONSTITUTION.md §Tier 3 |

## Enforcement Mechanisms

| Mechanism | What It Enforces | How |
|-----------|-----------------|-----|
| Constitution hash lock | Law 1 (Immutable Constitution) | SHA-256 in .env, pre-commit hook, orchestrator boot check |
| Brain hook | Law 2 (Brain First) | PreToolUse hook → brain_query.py on every Edit/Write |
| Boot injection | Law 3 (No Repeat Mistakes) | pulse_boot.py loads failures into agent context |
| CI/CD smoke tests | Laws 4-5 (SoC + Small Files) | GitHub Actions: structure + line count validation |
| HMAC signing | Law 8 (Crypto Integrity) | pulse_crypto.py signs all state writes |
| Compliance validator | Tier 0 (Non-Harm + Privacy) | Regex patterns on action queue, PII detection |

## Related Regions

- **Hippocampus/** — Learned knowledge (patterns, anti-patterns, lessons, failures)
- **Prefrontal_Cortex/** — Working memory (task board, action queue)
- **Autonomic_System/** — Enforcement code (daemons, agents, brain tools)
