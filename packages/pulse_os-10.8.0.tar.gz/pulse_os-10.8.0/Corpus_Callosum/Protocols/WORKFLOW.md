# WORKFLOW & TESTING

> Session routines, testing rules, commit guidelines.
> **Version:** V43.3

---

## Model-Aware Workflow (V43.3)

**Start sessions with the right model:**
```bash
# Daily work (recommended)
claude --model haiku

# Architecture/debugging only
claude --model opus
```

**Haiku orchestrates, agents execute:**
- Search → Spawn Explore agent (haiku)
- Git → Spawn Bash agent (haiku)
- Features → Spawn general-purpose (sonnet)
- Complex → Recommend user switch to Opus

---

## Session Checklist

### BEFORE Touching Code
```
□ Read Corpus_Callosum/CONSTITUTION.md → Know the laws
□ Run safety gate → `python Autonomic_System/Daemons/safety_check.py` (mandatory)
□ Read brain briefing → pulse_boot.py injects this automatically at boot
□ Read .claude/memory/AGENTS.md  → Know delegation rules
```

### AFTER Making Changes
```
□ Update CHANGELOG.md immediately
□ Run tests if needed (see below)
□ Update Current Session trio with progress (pick the relevant file)
□ Run Law 9 propagation checklist
```

---

## When to Run Tests

| Test | Duration | Run When |
|------|----------|----------|
| `test_universal.py` | ~15 min | Changed: translator.py, guards/*, chunking.py, batch.py |
| `test_speed.py` | ~45 sec | Changed: batching, loops, chunking |
| Telegram (manual) | - | UI, handlers, quick validation |

**DON'T run full suite for:** UI tweaks, config, docs, minor fixes.

### Test Decision Tree
```
Changed translation logic?
├─ YES → test_universal.py + test_speed.py
└─ NO  → Manual Telegram test + check latest.log
```

---

## Git Commits

**RULE: NEVER auto-commit. ALWAYS ask user first.**

### When to Suggest Commit
- ✅ Bug fixed and tested
- ✅ Feature complete and working
- ✅ Before risky refactoring (checkpoint)
- ✅ User explicitly asks

### When NOT to Commit
- ❌ Mid-refactor
- ❌ Just exploring/debugging
- ❌ User hasn't tested yet

### How to Ask
```
"Tests pass. Want me to commit this as V##.#?"
```

### Commit Format
```
feat(V##): Short description

- What changed
- Speed/test results if relevant
```

**NO co-author lines. User's confidentiality - tools used are private.**

---

## Version Workflow

1. Check `CHANGELOG.md` - know where we are
2. Make changes to ONE concern at a time
3. Run tests after EACH change
4. If tests pass → update CHANGELOG.md
5. If tests fail → revert, don't stack

---

## Quality Checks (test_universal.py)

1. **Script Contamination** - Unicode-based detection
2. **Length Ratio** - Catches hallucinations/truncations
3. **Paragraph Preservation** - `\n\n` count matches
4. **Number Preservation** - 3+ digit numbers survive

---

*Current Version: V43.3 (see CHANGELOG.md)*
