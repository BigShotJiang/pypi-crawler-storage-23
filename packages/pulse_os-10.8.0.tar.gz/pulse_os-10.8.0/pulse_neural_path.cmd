@echo off
set WRAPPER=Autonomic_System\Daemons\pulse_wrapper.py

if "%~1"=="" (
  python %WRAPPER% --set-env pulse_neural_path
  exit /b %ERRORLEVEL%
)

if /I "%~1"=="--print" (
  python %WRAPPER% --set-env pulse_neural_path --print
  exit /b %ERRORLEVEL%
)

python %WRAPPER% --set-env pulse_neural_path -- %*
exit /b %ERRORLEVEL%
