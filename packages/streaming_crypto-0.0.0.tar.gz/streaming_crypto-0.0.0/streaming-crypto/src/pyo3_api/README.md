# pyo3-api

Python bindings crate for streaming-crypto using PyO3.
