# core-api
Pure Rust API crate for streaming-crypto.
