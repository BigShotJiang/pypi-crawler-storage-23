# ffi-api
FFI bindings crate for streaming-crypto.
