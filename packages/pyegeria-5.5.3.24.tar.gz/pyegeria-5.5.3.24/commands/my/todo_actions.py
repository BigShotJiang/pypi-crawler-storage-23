"""
SPDX-License-Identifier: Apache-2.0
Copyright Contributors to the ODPi Egeria project.



Execute ToDo actions.

"""

import os
import time
from datetime import datetime, timezone

import click

from pyegeria import EgeriaTech, ACTIVITY_STATUS
from pyegeria.core._exceptions import (
    PyegeriaAPIException as PropertyServerException,
    print_basic_exception as print_exception_response, PyegeriaException, print_basic_exception,
    PyegeriaException, PyegeriaInvalidParameterException
)

erins_guid = "dcfd7e32-8074-4cdf-bdc5-9a6f28818a9d"
peter_guid = "59f0232c-f834-4365-8e06-83695d238d2d"
tanya_guid = "a987c2d2-c8b6-4882-b344-c47956d2de97"

EGERIA_METADATA_STORE = os.environ.get("EGERIA_METADATA_STORE", "active-metadata-store")
EGERIA_KAFKA_ENDPOINT = os.environ.get("KAFKA_ENDPOINT", "localhost:9092")
EGERIA_PLATFORM_URL = os.environ.get("EGERIA_PLATFORM_URL", "https://localhost:9443")
EGERIA_VIEW_SERVER = os.environ.get("EGERIA_VIEW_SERVER", "view-server")
EGERIA_VIEW_SERVER_URL = os.environ.get(
    "EGERIA_VIEW_SERVER_URL", "https://localhost:9443"
)
EGERIA_INTEGRATION_DAEMON = os.environ.get("EGERIA_INTEGRATION_DAEMON", "integration-daemon")
EGERIA_INTEGRATION_DAEMON_URL = os.environ.get(
    "EGERIA_INTEGRATION_DAEMON_URL", "https://localhost:9443"
)
EGERIA_ADMIN_USER = os.environ.get("ADMIN_USER", "garygeeke")
EGERIA_ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "secret")
EGERIA_USER = os.environ.get("EGERIA_USER", "erinoverview")
EGERIA_USER_PASSWORD = os.environ.get("EGERIA_USER_PASSWORD", "secret")


@click.command("create-todo")
@click.option("--server", default=EGERIA_VIEW_SERVER, help="Egeria view server to use.")
@click.option(
    "--url",
    default=EGERIA_VIEW_SERVER_URL,
    help="URL of Egeria platform to connect to.",
)
@click.option("--userid", default=EGERIA_USER, help="Egeria user")
@click.option("--password", default=EGERIA_USER_PASSWORD, help="Egeria user password")
@click.option("--name", help="Name of Todo", required=True)
@click.option(
    "--description",
    help="Brief description of To Do item",
    required=True,
)
@click.option("--category", help="User-defined category", required=False, default=None)
@click.option(
    "--priority",
    type=int,
    help="Priority of Todo",
    required=True,
    default=0,
)
@click.option(
    "--due",
    help="Due date of Todo (yyyy-mm-dd)",
    default=datetime.now().strftime("%Y-%m-%d"),
    required=True,
)
@click.option(
    "--assigned-to",
    help="Party the Todo is assigned to",
    required=True,
    default=peter_guid,
)
@click.option(
    "--sponsor",
    help="Sponsor of the ToDo item",
    required=False,
    default=None,
)
def create_todo(
    server,
    url,
    userid,
    password,
    name,
    description,
    category,
    priority,
    due,
    assigned_to,
    sponsor
):
    """Create a new ToDo item"""
    m_client = EgeriaTech(server, url, user_id=userid, user_pwd=password)
    m_client.create_egeria_bearer_token()
    try:
        body = {
            "class": "ActionRequestBody",
            "properties": {
                "class": "ToDoProperties",
                "qualifiedName": f"{name}-{time.asctime()}",
                "displayName": name,
                "description": description,
                "category": category,
                "priority": priority,
                "dueTime": due,
                "activityStatus": "REQUESTED",
            },
            "assignToActorGUID": assigned_to,
            "actionSponsorGUID": sponsor
        }

        resp = m_client.create_action(body)
        # if type(resp) is str:
        click.echo(f"Response was {resp}")
        # elif type(resp) is dict:
        #     click.echo(json.dumps(resp), indent = 2)

    except (PyegeriaException) as e:
        print_basic_exception(e)
    finally:
        m_client.close_session()


@click.command("delete-todo")
@click.option(
    "--server", default=EGERIA_VIEW_SERVER, help="Egeria metadata store to load"
)
@click.option(
    "--url", default=EGERIA_VIEW_SERVER_URL, help="URL of Egeria platform to connect to"
)
@click.option("--userid", default=EGERIA_USER, help="Egeria user")
@click.option("--password", default=EGERIA_USER_PASSWORD, help="Egeria user password")
@click.option("--timeout", default=60, help="Number of seconds to wait")
@click.argument("todo-guid")
def delete_todo(server, url, userid, password, timeout, todo_guid):
    """Delete the todo item specified"""
    m_client = EgeriaTech(server, url, user_id=userid, user_pwd=password)
    m_client.create_egeria_bearer_token()
    try:
        m_client.delete_asset(todo_guid)

        click.echo(f"Deleted Todo item {todo_guid}")

    except (PyegeriaException) as e:
        print_basic_exception(e)
    finally:
        m_client.close_session()


@click.command("change-todo-status")
@click.argument("todo-guid")
@click.option(
    "--server", default=EGERIA_VIEW_SERVER, help="Egeria metadata store to load"
)
@click.option(
    "--url", default=EGERIA_VIEW_SERVER_URL, help="URL of Egeria platform to connect to"
)
@click.option("--userid", default=EGERIA_USER, help="Egeria user")
@click.option("--password", default=EGERIA_USER_PASSWORD, help="Egeria user password")
@click.option("--timeout", default=60, help="Number of seconds to wait")
@click.option(
    "--new-status",
    type = click.Choice(
        ACTIVITY_STATUS,
        case_sensitive="False",
    ),
    help="Enter the new ToDo item status",
    required=True,
)
def change_todo_status(server, url, userid, password, timeout, todo_guid, new_status):
    """Update a ToDo item status"""
    m_client = EgeriaTech(server, url, user_id=userid, user_pwd=password)
    m_client.create_egeria_bearer_token()
    try:
        if new_status not in ACTIVITY_STATUS:
            raise PyegeriaInvalidParameterException(context={"reason":"Invalid activity status"})
        body = {
            "class": "UpdataElementRequestBody",
            "properties": {
                "class": "ToDoProperties",
                "activityStatus": new_status
            },
            "mergeUpdate": True
        }

        m_client.update_asset(todo_guid, body)

        click.echo(f"Changed todo item {todo_guid} status to {new_status}.")

    except (PyegeriaException, PropertyServerException) as e:
        print_exception_response(e)
    finally:
        m_client.close_session()


@click.command("mark-todo-complete")
@click.option(
    "--server", default=EGERIA_VIEW_SERVER, help="Egeria metadata store to load"
)
@click.option(
    "--url", default=EGERIA_VIEW_SERVER_URL, help="URL of Egeria platform to connect to"
)
@click.option("--userid", default=EGERIA_USER, help="Egeria user")
@click.option("--password", default=EGERIA_USER_PASSWORD, help="Egeria user password")
@click.option("--timeout", default=60, help="Number of seconds to wait")
@click.argument("todo-guid")
def mark_todo_complete(server, url, userid, password, timeout, todo_guid):
    """Mark the specified todo as complete"""
    m_client = EgeriaTech(server, url, user_id=userid, user_pwd=password)
    try:

        m_client.create_egeria_bearer_token()
        body = {
            "class": "UpdataElementRequestBody",
            "properties": {
                "class": "ToDoProperties",
                "activityStatus": "COMPLETED",
                "completionTime": datetime.now(timezone.utc).isoformat()
            },
            "mergeUpdate": True
        }

        m_client.update_asset(todo_guid, body)

        click.echo(f"Marked todo item {todo_guid} as complete.")

    except (PyegeriaException, PropertyServerException) as e:
        print_exception_response(e)
    finally:
        m_client.close_session()


@click.command("reassign-todo")
@click.option(
    "--server", default=EGERIA_VIEW_SERVER, help="Egeria metadata store to load"
)
@click.option(
    "--url", default=EGERIA_VIEW_SERVER_URL, help="URL of Egeria platform to connect to"
)
@click.option("--userid", default=EGERIA_USER, help="Egeria user")
@click.option("--password", default=EGERIA_USER_PASSWORD, help="Egeria user password")
@click.option("--timeout", default=60, help="Number of seconds to wait")
@click.argument("todo-guid")
@click.argument("new-actor-guid")
def reassign_todo(server, url, userid, password, timeout, todo_guid, new_actor_guid):
    """Reassign ToDo item to new actor"""
    m_client = EgeriaTech(server, url, user_id=userid, user_pwd=password)
    m_client.create_egeria_bearer_token()
    try:
        m_client.reassign_action(todo_guid, new_actor_guid)

        click.echo(f"Reassigned Todo item {todo_guid} to {new_actor_guid}")

    except (PyegeriaException, PropertyServerException) as e:
        print_exception_response(e)
    finally:
        m_client.close_session()
