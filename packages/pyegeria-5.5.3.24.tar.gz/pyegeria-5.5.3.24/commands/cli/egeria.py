#!/usr/bin/env python3
"""
SPDX-License-Identifier: Apache-2.0
Copyright Contributors to the ODPi Egeria project.


A object_action line interface for Egeria Users - all md_commands

This is an emerging capability based on the **click** package. Feedback welcome!

"""
import os
import sys

import click
from trogon import tui
from loguru import logger

from pyegeria import config_logging,  settings, ACTIVITY_STATUS

from commands.cat.my_reports import start_exp2
from commands.cat.run_report import list_generic
from commands.cat.list_reports import display_reports
from commands.cat.get_asset_graph import asset_viewer
from commands.cat.get_collection_tree import collection_viewer
from commands.cat.get_project_dependencies import project_dependency_viewer
from commands.cat.get_project_structure import project_structure_viewer
from commands.cat.get_tech_type_elements import tech_viewer
from commands.cat.glossary_actions import (
    create_glossary,
    create_term,
    delete_glossary,
    delete_term,
    export_terms_csv,
    import_terms_csv,
    update_term,
    update_term_status,
)

from commands.cat.collection_actions import (
    create_collection,
    delete_collection,
    update_collection,
    add_element_to_collection,
    remove_element_from_collection
)

from commands.cat.list_assets import display_assets
from commands.cat.list_cert_types import display_certifications
from commands.cat.list_collections import display_collections
from commands.cat.list_deployed_catalogs import list_deployed_catalogs
from commands.cat.list_deployed_database_schemas import (
    list_deployed_database_schemas,
)
from commands.cat.list_deployed_databases import list_deployed_databases
from commands.cat.list_glossaries import display_glossaries
from commands.cat.list_projects import display_project_list
from commands.cat.list_deployed_servers import display_servers_by_dep_imp
from commands.cat.list_tech_type_elements import list_tech_elements
from commands.cat.list_tech_types import display_tech_types
from commands.cat.list_terms import display_glossary_terms
from commands.cat.list_user_actions import display_user_actions
from commands.cat.list_user_ids import list_user_ids

from commands.cat.dr_egeria_md import process_markdown_file

from commands.cli.ops_config import Config
from commands.my.get_my_profile import display_my_profile
from commands.my.list_my_roles import display_my_roles
from commands.my.monitor_my_actions import display_my_todos
from commands.my.todo_actions import (
    change_todo_status,
    create_todo,
    delete_todo,
    mark_todo_complete,
    reassign_todo,
)
from commands.ops.gov_server_actions import (
    add_catalog_target,
    refresh_gov_eng_config,
    remove_catalog_target,
    start_server,
    stop_server,
    update_catalog_target,
)
from commands.ops.list_archives import display_archive_list
from commands.ops.list_catalog_targets import display_catalog_targets
from commands.ops.load_archive import load_archive
from commands.ops.monitor_active_engine_activity import display_engine_activity
from commands.ops.monitor_engine_activity import display_engine_activity_c
from commands.ops.monitor_engine_status import display_gov_eng_status
from commands.ops.monitor_daemon_status import (
    display_integration_daemon_status,
)
from commands.ops.monitor_platform_status import (
    display_status as p_display_status,
)
from commands.ops.monitor_server_startup import display_startup_status
from commands.ops.monitor_server_status import (
    display_status as s_display_status,
)
from commands.ops.refresh_integration_daemon import refresh_connector
from commands.ops.restart_integration_daemon import restart_connector
from commands.tech.get_element_info import display_elements
from commands.tech.get_guid_info import display_guid
from commands.tech.get_tech_details import tech_details_viewer
from commands.tech.get_tech_type_template import template_viewer
from commands.tech.list_all_om_type_elements import list_elements
from commands.tech.list_all_om_type_elements_x import list_elements_x
from commands.tech.list_all_related_elements import list_related_elements
from commands.tech.list_anchored_elements import display_anchored_elements
from commands.tech.list_asset_types import display_asset_types
from commands.tech.list_elements_by_classification_by_property_value import (
    find_elements_by_classification_by_prop_value,
)
from commands.tech.list_elements_by_property_value import (
    find_elements_by_prop_value,
)
from commands.tech.list_elements_by_property_value_x import (
    find_elements_by_prop_value_x,
)
from commands.tech.list_elements_for_classification import (
    list_classified_elements,
)
from commands.tech.list_gov_action_processes import display_gov_processes
from commands.tech.list_information_supply_chains import supply_chain_viewer
from commands.tech.list_registered_services import display_registered_svcs
from commands.tech.list_related_elements_with_prop_value import (
    list_related_elements_with_prop_value,
)
from commands.tech.list_related_specification import (
    display_related_specification,
)
from commands.tech.list_relationship_types import display_relationship_types
from commands.tech.list_relationships import list_relationships
from commands.tech.list_solution_blueprints import blueprint_list
from commands.tech.list_solution_components import solution_component_list
from commands.tech.list_solution_roles import solution_role_list
from commands.tech.list_tech_templates import display_templates_spec
from commands.tech.list_valid_metadata_values import display_metadata_values
from commands.tech.element_actions import delete_element

import sys

# Enable remote debugging (set to True when debugging)
ENABLE_DEBUG = False
#
# if ENABLE_DEBUG:
#     try:
#         import pydevd_pycharm
#
#         pydevd_pycharm.settrace('localhost', port=5678, stdout_to_server=True, stderr_to_server=True)
#     except ImportError:
#         print("pydevd-pycharm not installed. Install with: pip install pydevd-pycharm")
#     except Exception as e:
#         print(f"Could not connect to debugger: {e}")


EGERIA_USER = os.environ.get("EGERIA_USER", "erinoverview")
EGERIA_USER_PASSWORD = os.environ.get("EGERIA_USER_PASSWORD", "secret")
app_settings = settings
app_config = app_settings.Environment
# config_logging()

TUI_RUN_STRING = f"{sys.executable} -m commands.cli.egeria"

@tui(name=TUI_RUN_STRING)
# @tui('menu', 'menu', 'A textual object_action line interface')
@click.version_option("5.4 ", prog_name="hey_egeria")
@click.group()
@click.option(
    "--server",
    default=app_config.egeria_metadata_store,
    help="Egeria metadata store to work with",
)
@click.option(
    "--url",
    default=app_config.egeria_platform_url,
    help="URL of Egeria metadata store platform to connect to",
)
@click.option(
    "--integration_daemon",
    default=app_config.egeria_integration_daemon,
    help="Egeria integration daemon to work with",
)
@click.option(
    "--integration_daemon_url",
    default=app_config.egeria_integration_daemon_url,
    help="URL of Egeria integration daemon platform to connect to",
)
@click.option(
    "--view_server",
    default=app_config.egeria_view_server,
    help="Egeria view server to work with",
)
@click.option(
    "--view_server_url",
    default=app_config.egeria_view_server_url,
    help="URL of Egeria view server platform to connect to",
)
@click.option(
    "--engine_host",
    default=app_config.egeria_engine_host,
    help="Egeria engine host to work with",
)
@click.option(
    "--engine_host_url",
    default=app_config.egeria_engine_host_url,
    help="URL of Egeria engine host platform to connect to",
)

@click.option(
    "--userid",
    default=EGERIA_USER,
    help="Egeria user",
)
@click.option(
    "--password",
    default=EGERIA_USER_PASSWORD,
    help="Egeria user password",
)
@click.option("--timeout", default=60, help="Number of seconds to wait")
@click.option(
    "--jupyter",
    is_flag=True,
    type=bool,
    default=app_config.egeria_jupyter,
    help="Enable for rendering in a Jupyter terminal",
)
@click.option(
    "--width",
    default=app_config.console_width,
    type=int,
    help="Screen width, in characters, to use",
)
@click.option(
    "--home_glossary_name",
    default=app_settings.User_Profile.egeria_home_glossary_name,
    help="Glossary name to use as the home glossary",
)
@click.option(
    "--glossary_path",
    default=app_config.egeria_glossary_path,
    help="Path to glossary import/export files",
)

@click.option(
    "--root_path",
    default=app_config.pyegeria_root,
    help="Root path to use for file operations",
)

@click.option(
    "--inbox_path",
    default=app_config.dr_egeria_inbox,
    help="Path to inbox files",
)
@click.option(
    "--outbox_path",
    default=app_config.dr_egeria_outbox,
    help="Path to outbox files",
)

@click.pass_context
def cli(
    ctx,
    server,
    url,
    view_server,
    view_server_url,
    integration_daemon,
    integration_daemon_url,
    engine_host,
    engine_host_url,
    userid,
    password,
    timeout,
    jupyter,
    width,
    home_glossary_name,
    glossary_path,
    root_path,
    inbox_path,
    outbox_path,
):
    """An Egeria Command Line interface for Operations"""
    ctx.obj = Config(
        server,
        url,
        view_server,
        view_server_url,
        integration_daemon,
        integration_daemon_url,
        engine_host,
        engine_host_url,
        userid,
        password,
        timeout,
        jupyter,
        width,
        home_glossary_name,
        glossary_path,
        root_path,
        inbox_path,
        outbox_path
    )
    ctx.max_content_width = 300
    ctx.ensure_object(Config)


#
#  my: Show
#
@cli.group("my")
@click.pass_context
def my(ctx):
    "Work with my information"
    pass


@my.group("show")
@click.pass_context
def my_show(ctx):
    """Display an Egeria Object"""
    pass


@my_show.command("my-reports")
@click.pass_context
def show_my_reports(ctx):
    """Display my reports

    Usage: show my-reports

    """
    c = ctx.obj
    start_exp2(
        # c.view_server, c.view_server_url, c.userid, c.password, c.jupyter, c.width
    )

@my_show.command("my-profile")
@click.option(
    "--username",
    default=EGERIA_USER,
    help="Username to use",
)
@click.pass_context
def show_my_profile(ctx, username):
    """Display my profiles

    Usage: show my-profile

    """
    c = ctx.obj
    display_my_profile(
        c.view_server, c.view_server_url, username, c.password, c.jupyter, c.width
    )


@my_show.command("my-roles")
@click.pass_context
def show_my_roles(ctx):
    """Display my roles"""
    c = ctx.obj
    display_my_roles(
        c.view_server, c.view_server_url, c.userid, c.password, c.jupyter, c.width
    )


@my_show.command("my-actions")
@click.option(
    "--activity-status",
    default=["REQUESTED"],
    type = click.Choice(
        ACTIVITY_STATUS,
        case_sensitive=False,
    ),
    multiple=True,
    help="Which activity statuses to display",
)
@click.pass_context
def show_my_actions(ctx, activity_status):
    """Show my To-Dos

    Usage: show my-actions

    """
    c = ctx.obj
    display_my_todos(c.view_server, c.view_server_url, c.userid, c.password, c.jupyter,
                     c.width, activity_status)



#
#  my: Tell
#


@my.group("tell")
@click.pass_context
def my_tell(ctx):
    """Perform actions an Egeria Objects"""
    pass


my_tell.add_command(create_todo)
my_tell.add_command(delete_todo)
my_tell.add_command(change_todo_status)
my_tell.add_command(mark_todo_complete)
my_tell.add_command(reassign_todo)



#
#  tech User: Show
#
@cli.group("tech")
@click.pass_context
def tech(ctx):
    """Commands for tech Users"""
    pass

@tech.group("tell")
@click.pass_context
def tech_tell(ctx):
    """Perform actions on Egeria Objects"""
    pass


tech_tell.add_command(delete_element)

@tech.group("show")
@click.pass_context
def show_tech(ctx):
    """Display an Egeria Object"""
    pass


@show_tech.group("tech-info")
@click.pass_context
def show_tech_info(ctx):
    """Show various Egeria information"""
    pass


@show_tech.group("tech-types")
@click.pass_context
def show_tech_type(ctx):
    """Show information about Egeria technology types"""
    pass


@show_tech.group("elements")
@click.pass_context
def show_elements(ctx):
    """Show information about Egeria elements"""


@show_tech.group("supply-chains")
@click.pass_context
def show_supply_chains(ctx):
    """Show information about Information Supply Chainss"""


@show_elements.command("guid-info")
@click.argument("guid", nargs=1)
@click.pass_context
def show_guid_info(ctx, guid):
    """Display guid information

    Usage: show guid-info <a guid>

    """
    c = ctx.obj
    display_guid(guid, c.server, c.url, c.userid, c.password, c.jupyter, c.width)


@show_elements.command("anchored_elements")
@click.pass_context
@click.option(
    "--property_value",
    default="DeployedDatabaseSchema",
    help="value we are searching for",
)
@click.option(
    "--prop-list",
    default="anchorTypeName",
    help="List of properties we are searching",
)
def list_anchored_elements(ctx, property_value: str, prop_list: str):
    """List anchored elements with the specified properties"""
    c = ctx.obj
    if type(prop_list) is str:
        property_names = prop_list.split(",")
    elif type(prop_list) is list:
        property_names = prop_list
    else:
        property_names = []
        raise click.ClickException(f"Error --> Invalid property list - must be a string or list")
    display_anchored_elements(
        property_value,
        [property_names],
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.timeout,
        c.jupyter,
        c.width,
    )


@show_elements.command("elements-by-classification")
@click.option(
    "--om-type",
    default="Referenceable",
    help="Open Metadata type to filter by",
)
@click.option(
    "--classification",
    default="GovernanceProject",
    help="Classification to filter byt",
)
@click.pass_context
def show_elements_by_classification(ctx, om_type, classification):
    """Show elements by classification"""
    c = ctx.obj
    list_classified_elements(
        om_type,
        classification,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
    )


@show_elements.command("elements-by-classification-by-prop-value")
@click.option(
    "--classification",
    default="GovernanceProject",
    help="Classification to filter by",
)
@click.option(
    "--property_value",
    help="Property value to filter by",
)
@click.option(
    "--property_names",
    help="List of properties to search by",
)
@click.option(
    "--om-type",
    default="Referenceable",
    help="Open Metadata type to filter by",
)
@click.pass_context
def show_elements_by_classification_by_prop(
    ctx, classification, property_value, property_names, om_type
):
    """Show elements by classification and property value"""
    c = ctx.obj
    find_elements_by_classification_by_prop_value(
        om_type,
        classification,
        property_value,
        [property_names],
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
    )


@show_elements.command("elements-by-prop-value")
@click.option(
    "--property_value",
    help="Property value to filter by",
)
@click.option(
    "--property_names",
    help="List of properties to search by",
)
@click.option(
    "--om-type",
    default="Referenceable",
    help="Open Metadata type to filter by",
)
@click.option(
    "--extended",
    is_flag=True,
    default=False,
    help="If True, feedback information is displayed",
)
@click.pass_context
def show_elements_by_classification_by_prop(
    ctx, property_value, property_names, om_type, extended
):
    """Show elements by classification and property value"""
    c = ctx.obj
    if extended:
        find_elements_by_prop_value_x(om_type, property_value, [property_names], c.view_server, c.view_server_url,
                                      c.userid, c.password, c.jupyter, c.width)
    else:
        find_elements_by_prop_value(
            om_type,
            property_value,
            [property_names],
            c.view_server,
            c.view_server_url,
            c.userid,
            c.password,
            c.jupyter,
            c.width,
        )


@show_elements.command("related-elements")
@click.option(
    "--element-guid",
    help="GUID of the Element to navigate from.",
)
@click.option(
    "--om-type",
    default="Referenceable",
    help="Open metadata type to filter by.",
)
@click.option(
    "--rel-type",
    default="Certification",
    help="Relationship type to follow.",
)
@click.pass_context
def show_related_elements(ctx, element_guid, om_type, rel_type):
    """Show all elements related to specified guid"""
    c = ctx.obj
    list_related_elements(element_guid, om_type, rel_type, c.view_server, c.view_server_url, c.userid, c.password,
                          c.jupyter, c.width)


@show_elements.command("related-elements_by_prop")
@click.option(
    "--element-guid",
    help="GUID of the Element to navigate from.",
)
@click.option(
    "--rel-type",
    default="Certification",
    help="Relationship type to follow.",
)
@click.option(
    "--property_value",
    help="Property value to filter by",
)
@click.option(
    "--property_names",
    help="List of properties to search by",
)
@click.option(
    "--om-type",
    default="Referenceable",
    help="Open metadata type to filter by.",
)
@click.pass_context
def show_related_elements(
    ctx, element_guid, rel_type, property_value, property_names, om_type
):
    """Show elements related to specified guid and property value"""
    c = ctx.obj
    list_related_elements_with_prop_value(
        element_guid,
        rel_type,
        property_value,
        [property_names],
        om_type,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
    )


@show_elements.command("related-specifications")
@click.pass_context
@click.argument("element-guid")
def show_related_specifications(ctx, element_guid):
    """List specifications related to the given Element"""
    c = ctx.obj
    display_related_specification(
        element_guid,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
    )


@show_tech_type.command("list")
@click.option("--search-string", default="*", help="Tech type to search for")
@click.pass_context
def show_tech_types(ctx, search_string):
    """List deployed technology types

    Usage: show tech-types <optional search-string>

    All tech-types will be returned if no search-string is specified.

    """

    c = ctx.obj
    display_tech_types(search_string, c.view_server, c.view_server_url, c.userid, c.password)


@show_tech_type.command("details")
@click.argument("tech-name")
@click.pass_context
def show_tech_details(ctx, tech_name):
    """Show technology type details"""
    c = ctx.obj
    tech_details_viewer(tech_name, c.view_server, c.view_server_url, c.userid, c.password, c.jupyter, c.width)


@show_tech_type.command("templates")
@click.option(
    "--tech-type",
    default="PostgreSQL Server",
    help="Specific tech type to get elements for",
)
@click.pass_context
def show_tech_type_templates(ctx, tech_type):
    """List technology type templates"""
    c = ctx.obj
    template_viewer(
        tech_type,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
    )


@show_tech_info.command("asset-types")
@click.pass_context
def show_asset_types(ctx):
    """Display asset types"""
    c = ctx.obj
    display_asset_types(
        c.view_server, c.view_server_url, c.userid, c.password, c.jupyter, c.width
    )


@show_tech_info.command("registered-services")
@click.option(
    "--services",
    type = click.Choice(
        [
            "all",
            "access-services",
            "common-services",
            "engine-services",
            "governance-services",
            "integration-services",
            "view-services",
        ],
        case_sensitive=False,
    ),
    default="all",
    help="Which service group to display",
)
@click.pass_context
def show_registered_services(ctx, services):
    """Show information about a registered services"""
    c = ctx.obj
    display_registered_svcs(services, c.view_server, c.view_server_url, c.userid, c.password, c.jupyter, c.width)


@show_tech_info.command("relationship-types")
@click.option(
    "--om-type",
    default="Referenceable",
    help="Relationship type to get information about",
)
@click.pass_context
def show_relationship_types(ctx, om_type):
    """Show information about the specified relationship types"""
    c = ctx.obj
    display_relationship_types(om_type, c.view_server, c.view_server_url, c.userid, c.password, False, c.jupyter,
                               c.width)


@show_tech_type.command("template-spec")
@click.pass_context
@click.option(
    "--search-string", default="*", help="Technology type to get information about"
)
def tech_template_spec(ctx, search_string):
    """Display template specification information about the specified technology."""
    c = ctx.obj
    display_templates_spec(
        search_string,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
    )


@show_tech_info.command("gov-action-processes")
@click.pass_context
@click.option("--search-string", default="*", help="Search string")
def gov_action_processes(ctx, search_string):
    """Display available governance action processes."""
    c = ctx.obj
    display_gov_processes(
        search_string,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
    )


@show_tech_info.command("relationships")
@click.option(
    "--relationship",
    default="Certification",
    help="Relationship type name to search for.",
)
@click.pass_context
def show_relationships(ctx, relationship):
    """Show the structure of the project starting from a root project"""
    c = ctx.obj
    list_relationships(
        relationship,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.timeout,
        c.jupyter,
        c.width,
    )


@show_tech_info.command("valid-metadata-values")
@click.pass_context
@click.option("--property", default="projectHealth", help="Metadata property to query")
@click.option("--type-name", default="Project", help="Metadata type to query")
def valid_metadata_values(ctx, property, type):
    """Display the valid metadata values for a property and type"""
    c = ctx.obj
    display_metadata_values(
        property,
        type,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        False,
        c.jupyter,
        c.width,
    )


@show_elements.command("elements")
@click.pass_context
@click.option(
    "--extended",
    is_flag=True,
    default=False,
    help="If True, feedback information is displayed",
)
@click.option("--om_type", default="Referenceable", help="Metadata type to query")
def list_all_om_type_elements(ctx, om_type, extended):
    """Display all elements of a specific Open Metadata Type"""
    c = ctx.obj
    if extended:
        list_elements_x(
            om_type,
            c.view_server,
            c.view_server_url,
            c.userid,
            c.password,
            c.jupyter,
            c.width,
        )
    else:
        list_elements(
            om_type,
            c.view_server,
            c.view_server_url,
            c.userid,
            c.password,
            c.jupyter,
            c.width,
        )


@show_tech_info.command("processes")
@click.pass_context
def list_element_info(ctx):
    """Display the governance action processes"""
    c = ctx.obj
    list_elements(
        "GovernanceActionProcess",
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
    )


@show_elements.command("get-elements")
@click.pass_context
@click.option("--om_type", default="Referenceable", help="Metadata type to query")
def get_element_info(ctx, om_type):
    """Display a table of elements of an Open Metadata Type"""
    c = ctx.obj
    display_elements(om_type, c.view_server, c.view_server_url, c.userid, c.password, c.jupyter, c.width)


@show_supply_chains.command("supply-chains")
@click.option("--search-string", default="*", help="Search string")
@click.pass_context
def list_supply_chains(ctx, search_string):
    """Display supply chains"""
    c = ctx.obj
    supply_chain_viewer(search_string, c.view_server, c.view_server_url, c.userid, c.password, c.jupyter, c.width)


@show_supply_chains.command("blueprints")
@click.option("--search-string", default="*", help="Search string")
@click.pass_context
def list_blueprints(ctx, search_string):
    """Display solution blueprints"""
    c = ctx.obj
    blueprint_list(search_string, c.view_server, c.view_server_url, c.userid, c.password, c.jupyter, c.width)


@show_supply_chains.command("solution-roles")
@click.option("--search-string", default="*", help="Search string")
@click.pass_context
def list_solution_roles(ctx, search_string):
    """Display solution roles"""
    c = ctx.obj
    solution_role_list(
        search_string,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
    )


@show_supply_chains.command("solution-components")
@click.option("--search-string", default="*", help="Search string")
@click.pass_context
def list_solution_components(ctx, search_string):
    """Display solution componentss"""
    c = ctx.obj
    solution_component_list(search_string, c.view_server, c.view_server_url, c.userid, c.password, c.jupyter, c.width)


#
#   Catalog User: Show
#


@cli.group("cat")
@click.pass_context
def cat(ctx):
    """Commands for all users"""
    pass


@cat.group("show")
@click.pass_context
def show_cat(ctx):
    """Display an Egeria Object"""
    pass

@show_cat.group("data_designer")
@click.pass_context
def show_cat_design(ctx):
    """Group of commands for Egeria Data Designer"""
    pass


@show_cat_design.command("data-fields")
@click.option("--output-format", default = "TABLE", help="Output format type")
@click.option('--search-string', default="*", help="Search string")
@click.pass_context
def show_data_fields(ctx, output_format, search_string):
    """Report on Data Fields"""
    c = ctx.obj
    logger.info(f"Hey Egeria: view server @ {c.view_server_url}")
    list_generic(
        "Data-Fields", output_format = output_format, view_server = c.view_server, view_url= c.view_server_url,
        user = c.userid, user_pass = c.password, params = {"search_string": search_string}, render_table = True
    )


@show_cat_design.command("data-structures")
@click.option("--output-format", default = "TABLE", help="Output format type")
@click.option('--search-string', default="*", help="Search string")
@click.pass_context
def show_data_structures(ctx, output_format, search_string):
    """Reporton Data Structures"""
    c = ctx.obj
    logger.info(f"Hey Egeria: view server @ {c.view_server_url}")
    list_generic(
        "Data-Structures", output_format = output_format, view_server = c.view_server, view_url= c.view_server_url,
        user = c.userid, user_pass = c.password, params = {"search_string": search_string}, render_table = True
    )

@show_cat_design.command("data-classes")
@click.option("--output-format", default = "TABLE", help="Output format type")
@click.option('--search-string', default="*", help="Search string")
@click.pass_context
def show_data_classes(ctx, output_format, search_string):
    """Dynamically generate output based on a format set"""
    c = ctx.obj
    logger.info(f"Hey Egeria: view server @ {c.view_server_url}")
    list_generic(
        "Data-Classes", output_format = output_format, view_server = c.view_server, view_url= c.view_server_url,
        user = c.userid, user_pass = c.password, params = {"search_string": search_string}, render_table = True
    )

@show_cat_design.command("data-dictionaries")
@click.option("--output-format", default = "TABLE", help="Output format type")
@click.option('--search-string', default="*", help="Search string")
@click.pass_context
def show_data_dictionaries(ctx, output_format, search_string):
    """Report on Data Dictionaries"""
    c = ctx.obj
    logger.info(f"Hey Egeria: view server @ {c.view_server_url}")
    list_generic(
        "Data-Dictionaries", output_format = output_format, view_server = c.view_server, view_url= c.view_server_url,
        user = c.userid, user_pass = c.password, params = {"search_string": search_string}, render_table = True
    )

@show_cat_design.command("data-specifications")
@click.option("--output-format", default = "TABLE", help="Output format type")
@click.option('--search-string', default="*", help="Search string")
@click.pass_context
def show_data_specs(ctx, output_format, search_string):
    """Report on Data Specifications"""
    c = ctx.obj
    logger.info(f"Hey Egeria: view server @ {c.view_server_url}")
    list_generic(
        "Data-Specifications", output_format = output_format, view_server = c.view_server, view_url= c.view_server_url,
        user = c.userid, user_pass = c.password, params = {"search_string": search_string}, render_table = True
    )




@show_cat.group("info")
@click.pass_context
def show_cat_info(ctx):
    """Group of md_commands to show information about various Egeria objects"""
    pass

@show_cat_info.command("Run Report")
@click.option("--report", help="Report to output", default="Digital-Products")
@click.option("--output-format", default = "TABLE", help="Output format type")
@click.option('--search-string', default="*", help="Search string")
@click.pass_context
def show_format_set(ctx, report, output_format, search_string):
    """Dynamically generate output based on a format set"""
    c = ctx.obj
    logger.info(f"Hey Egeria: view server @ {c.view_server_url}")
    list_generic(
        report, output_format = output_format, view_server = c.view_server, view_url = c.view_server_url,
        user = c.userid, user_pass = c.password, params = {"search_string": search_string},render_table = True
    )


@show_cat_info.command("list-reports")
@click.option('--search', default="", help="Optional filter for name/description/aliases")
@click.pass_context
def show_list_reports(ctx, search):
    """List available report specs with available formats"""
    _ = ctx.obj  # unused but kept for symmetry
    display_reports(search=search)


@show_cat_info.command("tech-types")
@click.option("--tech_type", default="*", help="Tech type to search for")
@click.pass_context
def show_tech_types(ctx, tech_type):
    """List deployed technology types"""
    c = ctx.obj
    display_tech_types(tech_type, c.view_server, c.view_server_url, c.userid, c.password)


@show_cat_info.command("collections")
@click.option("--collection", default="*", help="Collection to search for")
@click.pass_context
def show_collections(ctx, collection):
    """List Collections"""
    c = ctx.obj
    display_collections(
        collection, c.view_server, c.view_server_url, c.userid, c.password
    )


@show_cat.group("assets")
@click.pass_context
def asset_group(ctx):
    """Show assets known to Egerias"""
    pass


@asset_group.command("elements-of-tech-type")
@click.option(
    "--tech_type",
    default="PostgreSQL Server",
    help="Specific tech type to get elements for",
)
@click.pass_context
def show_tech_type_elements(ctx, tech_type):
    """List technology type elements"""
    c = ctx.obj
    tech_viewer(tech_type, c.view_server, c.view_server_url, c.userid, c.password)


@asset_group.command("in-asset-domain")
@click.argument("search-string")
@click.pass_context
def show_assets(ctx, search_string):
    """Find and display assets in domain

    Usage: show assets <search-string>

           search-string must be greater than four characters.
    """
    c = ctx.obj
    display_assets(
        search_string,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        60,
        c.jupyter,
        c.width,
    )


@asset_group.command("asset-graph")
@click.argument("asset_guid", nargs=1)
@click.pass_context
def show_asset_graph(ctx, asset_guid):
    """Display a tree graph of information about an asset

    Usage: show asset-graph <asset-guid>

           asset-guid must be a valid asset guid. These can be found through other md_commands such as 'show tech-type-elements'

    """
    c = ctx.obj
    asset_viewer(asset_guid, "TABLE", c.view_server, c.view_server_url, c.userid, c.password, c.jupyter, c.width)


@show_cat.group("glossary")
@click.pass_context
def glossary_group(ctx):
    """Show glossary information"""
    pass


@glossary_group.command("glossary-terms")
@click.option(
    "--search-string",
    default="*",
    help="List glossary terms similar to search string - minimum of 4 characters",
)
@click.option(
    "--glossary-guid",
    default=os.environ.get("EGERIA_HOME_GLOSSARY_GUID", None),
    help="Optionally restrict search to glossary with the specified guid",
)
@click.option(
    "--glossary-name",
    default="*",
    help="Optionally restrict search to a specific named glossary",
)
@click.option(
    "--output-format",
    type = click.Choice(["FORM", "REPORT", "TABLE"]),
    default="TABLE",
    help="Display on screen as table, or as FORM or REPORT file",
    )
@click.pass_context
def show_terms(ctx, search_string, glossary_guid, glossary_name, output_format):
    """Find and display glossary terms"""
    c = ctx.obj
    display_glossary_terms(search_string, glossary_guid, glossary_name, c.view_server, c.view_server_url, c.userid,
                           c.password, c.jupyter, c.width, output_format)



@glossary_group.command("glossaries")
@click.option("--search_string", default="*", help="Name to search for glossaries")
@click.option(
    "--output-format",
    type = click.Choice(["FORM", "REPORT", "TABLE"]),
    default="TABLE",
    help="Display on screen as table, or as FORM or REPORT file",
    )
@click.pass_context
def glossaries(ctx, search_string, output_format):
    """Display a list of glossaries"""
    c = ctx.obj
    display_glossaries(
        search_string,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
        output_format,
    )


@show_cat_info.command("collection-graph")
@click.option(
    "--root_collection",
    default="Coco Pharmaceuticals Governance Domains",
    help="View of tree of collections from a given root",
)
@click.pass_context
def show_collection(ctx, root_collection):
    """Display collection graph"""
    c = ctx.obj
    collection_viewer(
        root_collection,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
    )


@show_cat.group("projects")
@click.pass_context
def show_project_group(ctx):
    """Show project information in Egeria"""
    pass


@show_project_group.command("projects")
@click.option("--search-string", default="*", help="List Projects by Search String")
@click.pass_context
def show_projects(ctx, search_string):
    """Display a list of Egeria projects"""
    c = ctx.obj
    display_project_list(
        search_string,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        False,
        c.jupyter,
        c.width,
    )


@show_cat_info.command("certification-types")
@click.option("--search-string", default="CertificationType", help="")
@click.pass_context
def show_certification_types(ctx, search_string):
    """Show certification types"""
    c = ctx.obj
    display_certifications(search_string, c.view_server, c.view_server_url, c.userid, c.password, c.timeout, c.jupyter)


@show_cat_info.command("asset-types")
@click.pass_context
def show_asset_types(ctx):
    """Display known asset types"""
    c = ctx.obj
    display_asset_types(
        c.view_server, c.view_server_url, c.userid, c.password, c.jupyter, c.width
    )


@show_project_group.command("project-structure")
@click.option(
    "--project",
    default="Clinical Trials Management",
    help="Enter the root project to start from",
)
@click.pass_context
def show_project_structure(ctx, project):
    """Show the organization structure of the project starting from a root project"""
    c = ctx.obj
    project_structure_viewer(
        project,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
        c.timeout,
    )


@show_project_group.command("project-dependencies")
@click.option(
    "--project",
    default="Clinical Trials Management",
    help="Enter the root project to start from",
)
@click.pass_context
def show_project_dependencies(ctx, project):
    """Show the dependencies of a project starting from a root project"""
    c = ctx.obj
    project_dependency_viewer(
        project,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
        c.timeout,
    )


@show_cat_info.command("user-actions")
@click.option("--search-string", default="*", help="View the list of To-Do items")
@click.option(
    "--activity-status",
    default=["REQUESTED"],
    type = click.Choice(
        ACTIVITY_STATUS,
        case_sensitive=False,
    ),
    multiple=True,
    help="Which activity statuses to display",
)
@click.pass_context
def show_user_act(ctx, search_string, activity_status):
    """Display list of To Dost"""
    c = ctx.obj
    status_list = activity_status
    display_user_actions(
        search_string,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        status_list,
        c.jupyter,
        c.width,
    )


@show_cat_info.command("user-ids")
@click.pass_context
def show_user_ids(ctx):
    """Display a list of known user-ids"""
    c = ctx.obj
    list_user_ids(
        c.view_server, c.view_server_url, c.userid, c.password, c.jupyter, c.width
    )


@show_cat.group("deployed-data")
@click.pass_context
def deployed_data(ctx):
    """Show deployed data resources known to Egeria"""
    pass


@deployed_data.command("deployed-servers")
@click.option(
    "--search-string",
    default="*",
    help="Filter deployed for deployed implementation type by search string",
)
@click.pass_context
def show_deployed_servers(ctx, search_string):
    """Display deployed servers"""
    c = ctx.obj
    display_servers_by_dep_imp(search_string, c.view_server, c.view_server_url, c.userid, c.password, c.jupyter,
                               c.width)


@deployed_data.command("deployed-schemas")
@click.option("--catalog", default="*", help="What database or catalog to search")
@click.pass_context
def deployed_schemas(ctx, catalog):
    """Display deployed schemas"""
    c = ctx.obj
    list_deployed_database_schemas(
        catalog,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
    )


@deployed_data.command("catalogs")
@click.option("--search_server", default="*", help="Server to search for catalogs")
@click.pass_context
def list_catalogs(ctx, search_server):
    """Display deployed catalogs"""
    c = ctx.obj
    list_deployed_catalogs(
        search_server,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
    )


@deployed_data.command("databases")
@click.pass_context
def list_databases(ctx):
    """Display deployed databases"""
    c = ctx.obj
    list_deployed_databases(c.view_server, c.view_server_url, c.userid, c.password, c.jupyter, c.width)


#
#  Tell-cat
#


@cat.group("tell")
@click.pass_context
def tell_cat(ctx):
    """Perform actions an Egeria Objects"""
    pass

#
# dr.egeria
#
@tell_cat.group("dr_egeria")
@click.pass_context
def dr_egeria(ctx):
    """Execute Dr.Egeria actions"""
    pass

dr_egeria.add_command(process_markdown_file)



@tell_cat.group("glossary")
@click.pass_context
def tell_glossary(ctx):
    """Perform glossary actions"""
    pass


tell_glossary.add_command(create_glossary)
tell_glossary.add_command(delete_glossary)
tell_glossary.add_command(delete_term)
tell_glossary.add_command(create_term)
tell_glossary.add_command(import_terms_csv)
tell_glossary.add_command(export_terms_csv)
tell_glossary.add_command(update_term)
tell_glossary.add_command(update_term_status )

@tell_cat.group("collection")
@click.pass_context
def tell_collections(ctx):
    """Perform actions on collections"""
    pass

tell_collections.add_command(create_collection)
tell_collections.add_command(delete_collection)
tell_collections.add_command(update_collection)
tell_collections.add_command(add_element_to_collection)
tell_collections.add_command(remove_element_from_collection)


@tell_cat.group("todo")
@click.pass_context
def tell_cat_todo(ctx):
    """Perform todo actions"""
    pass


tell_cat_todo.add_command(mark_todo_complete)
tell_cat_todo.add_command(reassign_todo)
tell_cat_todo.add_command(delete_todo)
tell_cat_todo.add_command(create_todo)


@show_cat_info.command("tech-types")
@click.option("--tech_type", default="*", help="Tech type to search for")
@click.pass_context
def show_tech_types(ctx, tech_type):
    """List deployed technology types"""
    c = ctx.obj
    display_tech_types(tech_type, c.view_server, c.view_server_url, c.userid, c.password)


@show_cat_info.command("certification-types")
@click.option("--search-string", default="CertificationType", help="")
@click.pass_context
def show_certification_types(ctx, search_string):
    """Show certification types"""
    c = ctx.obj
    display_certifications(search_string, c.view_server, c.view_server_url, c.userid, c.password, c.timeout, c.jupyter)


@show_project_group.command("project-structure")
@click.option(
    "--project",
    default="Clinical Trials Management",
    help="Enter the root project to start from",
)
@click.pass_context
def show_project_structure(ctx, project):
    """Show the organization structure of the project starting from a root project"""
    c = ctx.obj
    project_structure_viewer(
        project,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
        c.timeout,
    )


@show_project_group.command("project-dependencies")
@click.option(
    "--project",
    default="Clinical Trials Management",
    help="Enter the root project to start from",
)
@click.pass_context
def show_project_dependencies(ctx, project):
    """Show the dependencies of a project starting from a root project"""
    c = ctx.obj
    project_dependency_viewer(
        project,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
        c.timeout,
    )



@asset_group.command("asset-graph")
@click.argument("asset_guid", nargs=1)
@click.pass_context
def show_asset_graph(ctx, asset_guid):
    """Display a tree graph of information about an asset

    Usage: show asset-graph <asset-guid>

           asset-guid must be a valid asset guid. These can be found through other md_commands such as 'show tech-type-elements'

    """
    c = ctx.obj
    asset_viewer( asset_guid, "TABLE", c.view_server,c.view_server_url, c.userid,
                  c.password, c.jupyter, c.width, render_table=True)


@asset_group.command("tech-type-elements")
@click.option(
    "--tech_type",
    default="PostgreSQL Server",
    help="Specific tech type to get elements for",
)
@click.pass_context
def list_tech_type_elements(ctx, tech_type):
    """List technology type elements"""
    c = ctx.obj
    list_tech_elements(
        tech_type, c.view_server, c.view_server_url, c.userid, c.password
    )


@show_project_group.command("projects")
@click.option("--search-string", default="*", help="List Projects by Search String")
@click.pass_context
def show_projects(ctx, search_string):
    """Display a list of Egeria projects"""
    c = ctx.obj
    display_project_list(
        search_string,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        False,
        c.jupyter,
        c.width,
    )





@show_cat_info.command("user-ids")
@click.pass_context
def show_user_ids(ctx):
    """Display table of known user ids"""
    c = ctx.obj
    list_user_ids(
        c.view_server, c.view_server_url, c.userid, c.password, c.jupyter, c.width
    )


@deployed_data.command("deployed-servers")
@click.option(
    "--search-string",
    default="*",
    help="Filter deployed for deployed implementation type by search string",
)
@click.pass_context
def show_deployed_servers(ctx, search_string):
    """Show list of deployed servers"""
    c = ctx.obj
    display_servers_by_dep_imp(search_string, c.view_server, c.view_server_url, c.userid, c.password, c.jupyter,
                               c.width)


@deployed_data.command("deployed-schemas")
@click.option(
    "--search_catalog", default="*", help="What database or catalog to search"
)
@click.pass_context
def deployed_schemas(ctx, search_catalog):
    """Display a list of deployed schemas"""
    c = ctx.obj
    list_deployed_database_schemas(
        search_catalog,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
    )


@deployed_data.command("catalogs")
@click.option("--search_server", default="*", help="Server to search for catalogs")
@click.pass_context
def catalogs(ctx, search_server):
    """Display a list of deployed catalogs"""
    c = ctx.obj
    list_deployed_catalogs(
        search_server,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
    )


@deployed_data.command("databases")
@click.pass_context
def databases(ctx):
    """Display a list of deployed databases"""
    c = ctx.obj
    list_deployed_databases(c.view_server, c.view_server_url, c.userid, c.password, c.jupyter, c.width)


# @tell_cat.group("survey")
# @click.pass_context
# def survey(ctx):
#     """Refresh the specified integration connector or ALL connectors if not specified"""
#     c = ctx.obj
#     pass
#
#
# @survey.object_action("survey-uc-server")
# @click.pass_context
# @click.option(
#     "--uc_endpoint",
#     default="https://localhost:8080",
#     help="Endpoint of the Unity Catalog Server to Survey",
# )
# def survey_uc_server(ctx, uc_endpoint):
#     """Survey the Unity Catalog server at the given endpoint"""
#     c = ctx.obj
#     pass
# restart_connector(connector, c.integration_daemon, c.integration_daemon_url,
#                   c.userid, c.password)


#
#  Operations: Show
#


@cli.group("ops")
@click.pass_context
def ops(ctx):
    """Commands to understand and manage operations"""
    pass


@ops.group("show")
@click.pass_context
def show_ops(ctx):
    """Display an Egeria Object"""
    pass


@show_ops.group("repository")
@click.pass_context
def show_repo(ctx):
    """Group of md_commands to show repository information"""
    pass


@show_repo.command("archives")
@click.pass_context
def show_archives(ctx):
    c = ctx.obj
    display_archive_list(
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        False,
        c.jupyter,
        c.width,
    )


@show_ops.group("platforms")
@click.pass_context
def show_platform(ctx):
    """Group of md_commands to show information about Egeria platforms"""
    pass


@show_platform.command("status")
@click.pass_context
def show_platform_status(ctx):
    """Display a live status view of known platforms"""
    c = ctx.obj
    p_display_status(
        c.view_server, c.view_server_url, c.userid, c.password
    )


@show_ops.group("servers")
@click.pass_context
def show_server(ctx):
    """Group of md_commands to show information about Egeria servers"""
    pass


@show_server.command("status")
@click.option(
    "--full",
    is_flag=True,
    default=False,
    help="If set, full server descriptions will be shown",
)
@click.pass_context
def show_server_status(ctx, full):
    """Display a live status view of Egeria servers for the specified Egeria platform"""
    c = ctx.obj
    s_display_status(
        full,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
    )


@show_server.command("startup")
@click.pass_context
def show_startup_status(ctx):
    """Display a live status view of Egeria servers for the specified Egeria platform"""
    c = ctx.obj
    display_startup_status(
        c.server,
        c.url,
        c.userid,
        c.password,
        c.jupyter,
        c.width,
    )


@show_ops.group("engines")
@click.pass_context
def engine_host(ctx):
    """Group of md_commands to show information about Egeria engines"""
    pass


@engine_host.command("status")
@click.option(
    "--engine-list",
    default="*",
    help="Enter the list of connectors you are interested in or ['*'] for all",
)
@click.option(
    "--list", is_flag=True, default=False, help="If True, a paged list will be shown"
)
@click.pass_context
def gov_eng_status(ctx, engine_list, list):
    """Display engine-host status information"""
    c = ctx.obj
    display_gov_eng_status(
        [engine_list],
        engine_host=c.engine_host,
        view_server=c.view_server,
        url=c.view_server_url,
        username=c.userid,
        user_pass=c.password,
        paging=list,
        jupyter=c.jupyter,
        width=c.width,
    )


@engine_host.command("activity")
@click.option(
    "--rowlimit",
    default=0,
    type=int,
    show_default=True,
    help="If non-zero, limit the number of rows returned",
)
@click.option(
    "--list", is_flag=True, default=False, help="If True, a paged list will be shown"
)
@click.option(
    "--compressed",
    is_flag=True,
    default=False,
    show_default=True,
    help="Compressed combines some attributes into a single column",
)
@click.pass_context
def eng_activity_status(ctx, rowlimit: int, list: bool, compressed: bool):
    """Show Governance Activity in engine-host"""
    c = ctx.obj
    if compressed:
        display_engine_activity_c(
            rowlimit,
            c.view_server,
            c.view_server_url,
            c.userid,
            c.password,
            list,
            c.jupyter,
            c.width,
        )
    else:
        display_engine_activity(
            rowlimit,
            c.view_server,
            c.view_server_url,
            c.userid,
            c.password,
            list,
            c.jupyter,
            c.width,
        )


@show_ops.group("integrations")
@click.pass_context
def integrations(ctx):
    """Group of md_commands to show information about Egeria integrations"""
    pass


@integrations.command("status")
@click.option(
    "--connector-list",
    default="*",
    help="Enter the list of connectors you are interested in or ['*'] for all",
)
@click.option(
    "--list", is_flag=True, default=False, help="If True, a paged list will be shown"
)
@click.option(
    "--sorted", type=bool, default=True, help="If True, the table will be sorted"
)
@click.pass_context
def integrations_status(ctx, connector_list, list, sorted):
    """Display integration_daemon status information"""
    c = ctx.obj
    display_integration_daemon_status(
        [connector_list],
        c.integration_daemon,
        c.integration_daemon_url,
        c.view_server,
        c.view_server_url,
        c.userid,
        c.password,
        list,
        c.jupyter,
        c.width,
        sorted,
    )


@integrations.command("targets")
@click.pass_context
@click.argument("--connector", nargs=1)
def integrations_status(ctx, connector):
    """Display Catalog Targets for a connector"""
    c = ctx.obj
    display_catalog_targets(connector, c.view_server, c.view_server_url, c.userid, c.password, c.jupyter, c.width)


#
#  Operations: Tell
#


@ops.group("tell")
@click.pass_context
def tell_ops(ctx):
    """Perform actions an Egeria Objects"""
    pass


@tell_ops.group("integration-daemon")
@click.pass_context
def tell_integration_daemon(ctx):
    """Group of md_commands to an integration_daemon"""
    pass


@tell_integration_daemon.command("refresh")
@click.pass_context
@click.option(
    "--connector",
    default="all",
    help="Name of connector to refresh or 'all' to refresh all",
)
def refresh_connectors(ctx, connector):
    """Refresh the specified integration connector or ALL connectors if not specified"""
    c = ctx.obj
    refresh_connector(
        connector, c.integration_daemon, c.integration_daemon_urll, c.view_server, c.userid, c.password
    )


@tell_integration_daemon.command("restart")
@click.pass_context
@click.option(
    "--connector",
    default="all",
    help="Name of connector to restart or 'all' to restart all",
)

def restart_connectors(ctx, server, connector):
    """Restart the specified integration connector or ALL connectors if not specified"""
    c = ctx.obj
    restart_connector(
        connector, c.integration_daemon, c.integration_daemon_url, c.view_server, c.userid, c.password
    )


tell_integration_daemon.add_command(add_catalog_target)
tell_integration_daemon.add_command(remove_catalog_target)
tell_integration_daemon.add_command(update_catalog_target)
tell_integration_daemon.add_command(stop_server)
tell_integration_daemon.add_command(start_server)


@tell_ops.group("servers")
@click.pass_context
def servers(ctx):
    """Perform actions on OMAG Servers"""
    pass


servers.add_command(start_server)
servers.add_command(stop_server)


@tell_ops.group("engine-host")
@click.pass_context
def engine_host(ctx):
    """Group of md_commands to an engine-host"""
    pass


engine_host.add_command(start_server)
engine_host.add_command(stop_server)
engine_host.add_command(refresh_gov_eng_config)


@tell_ops.group("repository")
@click.pass_context
def repository(ctx):
    """Group of md_commands to a repository"""
    pass

repository.add_command(load_archive)

if __name__ == "__main__":
    try:
        script_path = os.path.abspath(__file__)

        # The args Click should parse (do NOT include the script path)
        click_args = sys.argv[1:]
        if click_args and os.path.abspath(click_args[0]) == script_path:
            click_args = click_args[1:]

        # The argv Trogon should re-exec (python + script + click args)
        sys.argv = [sys.executable, script_path, *click_args]

        # IMPORTANT: run Click with explicit args so it does not treat script_path as a command
        cli.main(args=click_args, prog_name=os.path.basename(script_path))
    except click.ClickException as e:
        e.show()
        raise SystemExit(1)
    except Exception as e:
        click.echo(f"Unexpected error: {e}")
        raise SystemExit(1)
