"""Vox CLI - Agent-to-Agent Communication Protocol."""

import asyncio
import sys
from vox.cli import cli

if __name__ == "__main__":
    # Run the CLI
    cli()
