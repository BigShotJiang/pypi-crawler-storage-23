# geocif


[![image](https://img.shields.io/pypi/v/geocif.svg)](https://pypi.python.org/pypi/geocif)
[![image](https://img.shields.io/conda/vn/conda-forge/geocif.svg)](https://anaconda.org/conda-forge/geocif)


**Generate Climatic Impact-Drivers (CIDs) from Earth Observation (EO) data**

[Climatic Impact-Drivers for Crop Yield Assessment at NASA Harvest](https://www.loom.com/share/5c2dc62356c6406193cd9d9725c2a6a9)

**Models to visualize and forecast crop conditions and yields**


-   Free software: MIT license
-   Documentation: https://ritviksahajpal.github.io/yield_forecasting/


## Config files

| File | Purpose | Used by |
|------|---------|---------|
| `geobase.txt` | Paths, shapefile column mappings | both |
| `countries.txt` | Per-country config (boundary files, admin levels, seasons, crops) | both |
| `crops.txt` | Crop masks, calendar categories (EWCM, AMIS) | both |
| `geoextract.txt` | Extraction-only settings (method, threshold, parallelism) | geoprepare |
| `geocif.txt` | Indices/ML/agmet settings, country overrides, runtime selections | geocif |

## Usage

```python
cfg_geoprepare = ["geobase.txt", "countries.txt", "crops.txt", "geoextract.txt"]
cfg_geocif = ["geobase.txt", "countries.txt", "crops.txt", "geocif.txt"]
```

### geoprepare (download, extract, merge)

```python
from geoprepare import geodownload
geodownload.run(["geobase.txt"])

from geoprepare import geoextract
geoextract.run(cfg_geoprepare)

from geoprepare import geomerge
geomerge.run(cfg_geoprepare)
```

### geocif (indices, ML, agmet, analysis)

```python
from geocif import indices_runner
indices_runner.run(cfg_geocif)

from geocif import geocif_runner
geocif_runner.run(cfg_geocif)

from geocif.agmet import geoagmet
geoagmet.run(cfg_geocif)

from geocif import analysis
analysis.run(cfg_geocif)
```

## Credits

This package was created with [Cookiecutter](https://github.com/cookiecutter/cookiecutter) and the [giswqs/pypackage](https://github.com/giswqs/pypackage) project template.
