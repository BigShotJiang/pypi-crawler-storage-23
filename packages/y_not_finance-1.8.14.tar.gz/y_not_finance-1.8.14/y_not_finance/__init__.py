"""
Y-Not-Finance: A comprehensive Python library for financial data.

This package provides three main modules:
1. prices - Fetch historical and intraday price data from Yahoo Finance
2. constituents - Fetch stock index constituents from various sources
3. events - Fetch corporate events data (dividends, splits, earnings)

Examples:
    >>> from y_not_finance import YahooFinanceClient, get_constituents, get_historical_constituents, get_intraday_ohlc
    >>> 
    >>> # Fetch price data
    >>> client = YahooFinanceClient()
    >>> prices = client.get_prices(["AAPL", "MSFT"], range_str="1mo")
    >>> 
    >>> # Fetch events data
    >>> events = client.get_events("AAPL", range_str="5y")
    >>> 
    >>> # Get index constituents
    >>> tickers = get_constituents("^SPX", info=True)
    >>> 
    >>> # Get historical constituents
    >>> historical_df = get_historical_constituents(start_date="2024-01-01")
    >>>
    >>> # Get intraday OHLC data
    >>> ohlc_df = get_intraday_ohlc()
"""

from ._version import __version__
from .yahoo_finance import YahooFinanceClient
from .constituents import get_constituents, STOCK_LISTS
from .constituents.historical import get_historical_constituents, get_intraday

__all__ = [
    'YahooFinanceClient',
    'get_constituents',
    'STOCK_LISTS',
    '__version__',
    'get_historical_constituents',
    'get_intraday'
]
