"""
S&P 500 Historical Daily Constituents Fetcher

This module fetches historical S&P 500 constituent data from WRDS (Wharton 
Research Data Services) and stores it in Parquet format for efficient retrieval.
"""

import logging
from pathlib import Path
from typing import Optional, Tuple

import pandas as pd
import wrds

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Configuration constants
START_DATE: str = "1980-01-01"
END_DATE: str = "2025-12-31"
OUTPUT_DIR: Path = Path("y_not_finance/constituents/historical/data")
WRDS_USERNAME: str = "oneavocado"

# WRDS SQL query for S&P 500 constituents on a specific date
SP500_CONSTITUENTS_QUERY: str = """
    SELECT DISTINCT ticker AS ticker
    FROM crsp.msenames a
    JOIN crsp_a_indexes.dsp500list_v2 b ON a.permno = b.permno
    WHERE b.mbrstartdt <= '{date}'
      AND (b.mbrenddt >= '{date}' OR b.mbrenddt IS NULL)
      AND a.namedt <= '{date}'
      AND a.nameendt >= '{date}'
"""


def fetch_sp500_constituents_by_date(
    db: wrds.Connection,
    start_date: str,
    end_date: str,
    output_path: Optional[Path] = None
) -> Tuple[pd.DataFrame, Path]:
    """
    Fetch S&P 500 constituents for each date in the specified range from WRDS.
    
    Retrieves historical daily constituent data from CRSP and stores it in 
    Parquet format for efficient storage and retrieval.
    
    Args:
        db: Active WRDS database connection.
        start_date: Start date in 'YYYY-MM-DD' format.
        end_date: End date in 'YYYY-MM-DD' format (inclusive).
        output_path: Optional custom output path for Parquet file. If None,
                    uses default OUTPUT_DIR with auto-generated filename.
    
    Returns:
        Tuple containing:
            - pd.DataFrame: Consolidated dataframe with columns [ticker, date]
            - Path: Path to saved Parquet file
    
    Raises:
        ValueError: If no constituents found for the date range.
        Exception: If database query fails.
        
    Examples:
        >>> db = wrds.Connection(wrds_username='oneavocado')
        >>> df, path = fetch_sp500_constituents_by_date(
        ...     db, "2024-01-01", "2024-12-31"
        ... )
        >>> print(df.head())
    """
    try:
        logger.info(f"Fetching S&P 500 constituents from {start_date} to {end_date}")
        
        # Generate date range
        date_range = pd.date_range(start=start_date, end=end_date, freq="D")
        logger.info(f"Processing {len(date_range)} dates")
        
        constituent_rows: list[pd.DataFrame] = []
        
        # Fetch constituents for each date
        for date in date_range:
            date_str = date.strftime("%Y-%m-%d")
            
            try:
                query = SP500_CONSTITUENTS_QUERY.format(date=date_str)
                daily_constituents = db.raw_sql(query)
                
                if daily_constituents.empty:
                    logger.debug(f"No constituents found for {date_str}")
                    continue
                
                daily_constituents["date"] = date_str
                constituent_rows.append(daily_constituents)
                
            except Exception as e:
                logger.warning(f"Failed to fetch constituents for {date_str}: {e}")
                continue
        
        # Validate results
        if not constituent_rows:
            error_msg = (
                f"No S&P 500 constituents found for date range "
                f"{start_date} to {end_date}"
            )
            logger.error(error_msg)
            raise ValueError(error_msg)
        
        # Combine all rows and remove duplicates
        consolidated_df = (
            pd.concat(constituent_rows, ignore_index=True)
            .drop_duplicates()
            .reset_index(drop=True)
        )
        
        logger.info(
            f"Consolidated {len(constituent_rows)} daily queries into "
            f"{len(consolidated_df)} unique records"
        )
        
        # Determine output path
        if output_path is None:
            OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
            filename = (
                f"sp500_constituents_"
                f"{start_date.replace('-', '')}_"
                f"{end_date.replace('-', '')}.parquet"
            )
            output_path = OUTPUT_DIR / filename
        else:
            output_path = Path(output_path)
            output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Save to Parquet
        consolidated_df.to_parquet(output_path, index=False, compression="snappy")
        logger.info(f"Saved constituents data to {output_path}")
        
        return consolidated_df, output_path
        
    except Exception as e:
        logger.error(f"Error fetching S&P 500 constituents: {e}", exc_info=True)
        raise


def main() -> None:
    """Main entry point for fetching and storing S&P 500 historical constituents."""
    try:
        # Establish WRDS connection
        logger.info(f"Connecting to WRDS as {WRDS_USERNAME}")
        db = wrds.Connection(wrds_username=WRDS_USERNAME)
        
        # Fetch and save constituents
        constituents_df, output_file = fetch_sp500_constituents_by_date(
            db, START_DATE, END_DATE
        )
        
        # Summary statistics
        logger.info("=" * 60)
        logger.info("S&P 500 Constituents Data Summary")
        logger.info("=" * 60)
        logger.info(f"Total Records: {len(constituents_df)}")
        logger.info(f"Unique Tickers: {constituents_df['ticker'].nunique()}")
        logger.info(f"Date Range: {constituents_df['date'].min()} to {constituents_df['date'].max()}")
        logger.info(f"Output File: {output_file}")
        logger.info("=" * 60)
        
    except Exception as e:
        logger.error(f"Fatal error in main: {e}", exc_info=True)
        raise


if __name__ == "__main__":
    main()