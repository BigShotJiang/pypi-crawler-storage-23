## 16.0.4.0.0 (2025-03-06)

- \[REF\] Alterado o Código de Protesto de Char para Objeto/l10n_br_cnab.code

## 16.0.3.0.0 (2024-12-16)

- \[REF\] "Foward Port" Separando as Configurações do CNAB do Modo de Pagamento.

## 16.0.2.0.0 (2024-12-02)

- \[REF\] "Foward Port" Unindo os Códigos CNAB em um mesmo objeto.

## 16.0.1.0.0 (2024-08-22)

- \[MIG\] Migração para a versão 16.0 

## 14.0.9.0.0 (2024-09-19)

- \[REM\] Removendo Campos, Visões e Objetos obsoletos.

## 14.0.8.0.0 (2024-09-18)

- \[IMP\] Possibilidade de informar Códigos de Desconto além do 0 e 1.

## 14.0.7.0.0 (2024-09-13)

- \[REF\] Separando as Configurações do CNAB do Modo de Pagamento.

## 14.0.6.0.0 (2024-09-10)

- \[REF\] Unindo os Códigos CNAB em um mesmo objeto.

## 14.0.1.0.0 (2022-05-26)

- \[MIG\] Migration

## 12.0.1.0.0 (2021-05-07)

- \[MIG\] Finish migration
- \[IMP\] Integrate with module account_move_base_import used to import
  CNAB file
- \[IMP\] Make possible automatic reconciliation and register the values
  of Fees, Tariff Bank, Rebate in configured accounts.

## 12.0.1.0.0 (2020-06-12)

- \[MIG\] Start Migration

## 10.0.1.0.0 (2019-05-30)

- \[MIG\] Migration

## 8.0.1.0.0 (2018-01-29)

- \[REF\] Maked functional to print Boleto, create CNAB file and import
  CNAB as Extrat Bank the user should be resolved manully the
  divergences between the values( Fee, Tariff Bank, Rebate, etc).

## 8.0.1.0.0 (2017-07-01)

- \[NEW\] First version
