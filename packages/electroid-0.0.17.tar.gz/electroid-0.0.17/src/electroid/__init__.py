# -*- coding: utf-8 -*-
# Python

"""Copyright (c) Alexander Fedotov.
This source code is licensed under the license found in the
LICENSE file in the root directory of this source tree.
"""
from .roid import respond
from .util import discern, decode

__all__ = [
    'respond',
    'discern',
    'decode'
]
