def double(i):
    return i * 2

def square(i):
    return i * i
print(square(double(3)))
print(double(square(3)))