# -*- coding: utf-8 -*-

"""App core."""
