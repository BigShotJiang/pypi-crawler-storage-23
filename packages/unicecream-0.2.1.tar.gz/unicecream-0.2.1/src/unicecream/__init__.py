# -*- coding: utf-8 -*-

"""A simple formatter for removing icecream from your code after debugging."""

__version__ = "0.2.1"
