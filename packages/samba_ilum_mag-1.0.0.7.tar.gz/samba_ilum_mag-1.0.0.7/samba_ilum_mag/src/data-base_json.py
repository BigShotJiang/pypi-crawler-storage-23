# SAMBA_ilum Copyright (C) 2025-2026
# GNU GPL-3.0 license


from pymatgen.io.vasp import Poscar
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
#--------------------------------------------------------
import numpy as np
import shutil
import json
import uuid
import sys
import os


#--------------------
pseudo_type = 'PAW_PBE'
exchange_correlation_functional = 'GGA'
vdW = 'optB86b'
#--------------------
# replace_type_pseudo
# replace_type_XC
# replace_type_vdW
#--------------------


for n in range(2):
    if (n == 0): type_files = ""
    if (n == 1): type_files = "_SO"


    #============================================
    file_poscar    = 'output/POSCAR' + type_files
    file_contcar   = 'output/CONTCAR' + type_files
    info_scf       = 'output/info_scf' + type_files + '.txt'
    info_bands     = 'output/info_bands' + type_files + '.txt'
    POSCAR_info    = 'output/POSCAR' + type_files + '.info'
    dir_bands      = 'output/Bandas' + type_files
    xy-scan_info   = 'output/xy-scan' + type_files + '/info_xy-scan.dat'
    z-scan_info    = 'output/z-scan' + type_files + '/info_z-scan.dat'
    file_oszicar   = 'relax' + type_files.replace("_",".") + '/OSZICAR'
    file_oszicar_f = 'relax' + type_files.replace("_",".") + '/OSZICAR_frozen'
    file_json      = 'output/info' + type_files + '.json'
    pot_bands      = 'output/Potencial_bands' + type_files + '/Potencial_Z.dat'
    pot_scf        = 'output/Potencial_scf' + type_files + '/Potencial_Z.dat'
    file_charger   = 'output/Charge_transfer' + type_files + '/Bader_charge_transfer.dat'
    file_magmom    = 'output/MAGMOM' + type_files + '.txt'
    #====================================================================================


    # =========================================
    # Checking files to be read: ==============
    # =========================================
    l_file = 'null'
    if os.path.isfile(info_scf):    l_file = info_scf.replace("output/","")
    if os.path.isfile(info_bands):  l_file = info_bands.replace("output/","")
    if (l_file == 'null'):  sys.exit(0)


    #==========================================================
    # Extracting the k-path for the Band Structure plot =======
    #==========================================================
    kpoints_file = []
    kpath = []
    kpath_label = []
    #----------------------------
    if os.path.isdir(dir_bands):  dir_kpath = 'bands' + type_files.replace("_",".")
    #----------------------------
    if os.path.exists(dir_kpath):
       #-----------------------------------------------------------------------------
       if os.path.isfile(dir_kpath + '/' + 'KPOINTS'): kpoints_file.append('KPOINTS')
       #--------------------------------------------------------------------------------------
       nkpoints = len([file for file in os.listdir(dir_kpath) if file.startswith("KPOINTS.")])
       for i in range(nkpoints):
           file = 'KPOINTS.' + str(i+1)
           if os.path.isfile(dir_kpath + '/' + file): kpoints_file.append(file)
       #---------------------------------
       for i in range(len(kpoints_file)):
           #-----------------------------
           with open(dir_kpath + '/' + kpoints_file[i], 'r') as file: lines = file.readlines()
           #----------------------------------------------------------------------------------
           if (len(kpoints_file) == 1):
              for j in range(len(lines)):
                  if (j > 3 and len(lines[j]) > 1):
                     line = lines[j].split()
                     line[3] = line[3].replace('!', '').replace('#1', 'Gamma').replace('#', '')
                     kpath.append([round(float(line[0]), 15), round(float(line[1]), 15), round(float(line[2]), 15)])
                     kpath_label.append(line[3])
           #------------------------------------
           if (len(kpoints_file) > 1):
              for j in range(len(lines)):
                  if (i == 0 and j > 3 and len(lines[j]) > 1):
                     line = lines[j].split()
                     line[3] = line[3].replace('!', '').replace('#1', 'Gamma').replace('#', '')
                     kpath.append([round(float(line[0]), 15), round(float(line[1]), 15), round(float(line[2]), 15)])
                     kpath_label.append([line[3]])
                  if (i > 0  and j > 4 and len(lines[j]) > 1):
                     line = lines[j].split()
                     line[3] = line[3].replace('!', '').replace('#1', 'Gamma').replace('#', '')
                     kpath.append([round(float(line[0]), 15), round(float(line[1]), 15), round(float(line[2]), 15)])
       #-------------------------------------------------------------
       # Removing adjacent and repeated elements from the k-path list
       #-------------------------------------------------------------
       i = 0
       while i < (len(kpath) -1):
           if kpath[i] == kpath[i +1]: del kpath[i +1]
           if kpath_label[i] == kpath_label[i +1]: del kpath_label[i +1]
           else: i += 1  # Avança para o próximo par de elementos


    # ===================================================
    # Starting tags with empty values "--" ==============
    # ===================================================
    area_perc_mismatch = '--';   perc_area_change = '--';    perc_mod_vectors_change = '--';
    angle_perc_mismatch = '--';  perc_angle_change = '--';   rotation_angle = '--';
    supercell_matrix = '--';     deformation_matrix = '--';  strain_matrix = '--'
    shift_plane = '--'

    # =============================================================
    # Extracting Configuration Information from Heterostructure ===
    # =============================================================
    l_info = 'null'
    if os.path.isfile(POSCAR_info):  l_info = POSCAR_info
    if (l_info == 'null'):  sys.exit(0)
    #----------------------------------
    if (l_info != 'null'): 
       #-------------------------
       poscar = open(l_info, "r")
       VTemp = poscar.readline().split()
       param = float(poscar.readline())
       poscar.close()
       #------------------------
       if (VTemp[0] == 'SAMBA'):
          #----------------------------------------------------------------
          l_materials = VTemp[1].replace('+', ' ').replace('_', '').split()
          n_materials = len(l_materials)
          #------------------------------------------
          r_ions_materials = []; nions_materials = []
          nion = 0;  passo = 0
          #-----------------------------
          for m in range(n_materials):
              r_ions_materials.append( str(1 + nion) + ':')
              nion += int(VTemp[m+2])
              r_ions_materials[m] += str(nion)
              nions_materials.append(int(VTemp[m+2]))
          #------------------------------------------
          id_materials = []
          #--------------------


          if (n_materials > 1):
             #--------------------------------------------------------------------------
             area_perc_mismatch = []; angle_perc_mismatch = [];      rotation_angle = []
             perc_area_change = [];   perc_mod_vectors_change = [];  perc_angle_change = []
             supercell_matrix = [];   deformation_matrix = [];       strain_matrix = []
             shift_plane = []
             #---------------------
             passo = n_materials +1
             passo += 4
             temp1 = str(VTemp[passo]).replace('_', ' ').split()
             area_perc_mismatch.append([round(float(temp1[0]), 15), round(float(temp1[1]), 15)])
             if (n_materials == 3):
                area_perc_mismatch.append([round(float(temp1[2]), 15), round(float(temp1[3]), 15)])
             #---------------------------------------------------------
             passo += 4
             temp1 = str(VTemp[passo]).replace('_', ' ').split()
             for ii in range(len(temp1)): perc_area_change.append(round(float(temp1[ii]), 15))
             #---------------------------------------------------------
             passo += 4
             temp1 = str(VTemp[passo]).replace('_', ' ').split()
             perc_mod_vectors_change.append([round(float(temp1[0]), 15), round(float(temp1[1]), 15)])
             perc_mod_vectors_change.append([round(float(temp1[2]), 15), round(float(temp1[3]), 15)])
             if (n_materials == 3):
                perc_mod_vectors_change.append([round(float(temp1[4]), 15), round(float(temp1[5]), 15)])
             #---------------------------------------------------------
             passo += 4
             temp1 = str(VTemp[passo]).replace('_', ' ').split()
             angle_perc_mismatch.append([round(float(temp1[0]), 15), round(float(temp1[1]), 15)])
             if (n_materials == 3):
                angle_perc_mismatch.append([round(float(temp1[2]), 15), round(float(temp1[3]), 15)])
             #---------------------------------------------------------
             passo += 4
             temp1 = str(VTemp[passo]).replace('_', ' ').split()
             for ii in range(len(temp1)): perc_angle_change.append(round(float(temp1[ii]), 15))
             #---------------------------------------------------------
             passo += 4
             temp1 = str(VTemp[passo]).replace('_', ' ').split()
             for ii in range(len(temp1)): rotation_angle.append(round(float(temp1[ii]), 15))
             #---------------------------------------------------------
             for i in range(n_materials):
                 passo += 4
                 temp1 = str(VTemp[passo]).replace('_', ' ').split()
                 supercell_matrix.append([[int(temp1[0]), int(temp1[1])], [int(temp1[2]), int(temp1[3])]])
                 # supercell_matrix.append([[round(float(temp1[0]), 15), round(float(temp1[1]), 15)], [round(float(temp1[2]), 15), round(float(temp1[3]), 15)]])
             #---------------------------------------------------------
             for i in range(n_materials):
                 passo += 4
                 temp1 = str(VTemp[passo]).replace('_', ' ').split()
                 deformation_matrix.append([[round(float(temp1[0]), 15), round(float(temp1[1]), 15)], [round(float(temp1[2]), 15), round(float(temp1[3]), 15)]])
             #---------------------------------------------------------
             for i in range(n_materials):
                 passo += 4
                 temp1 = str(VTemp[passo]).replace('_', ' ').split()
                 strain_matrix.append([[round(float(temp1[0]), 15), round(float(temp1[1]), 15)], [round(float(temp1[2]), 15), round(float(temp1[3]), 15)]])
             #---------------------------------------------------------
             passo += 4
             temp1 = str(VTemp[passo]).replace('_', ' ').split()
             for ii in range(len(temp1)): shift_plane.append(round(float(temp1[ii]), 15))
             #---------------------------------------------------------
             passo += 1
             for i in range(n_materials):
                 id_materials.append(str(VTemp[-n_materials -1 +i]))
          #--------------------------------------------
          temp_id = VTemp[-1].replace('_', ' ').split()
          if (len(temp_id) > 1): estequiometria = temp_id[0]
          id_code = VTemp[-1]
       #-------------------------------------------------------
       if (n_materials == 1): id_materials.append(str(id_code))
       #-------------------------------------------------------
       if (VTemp[0] != 'SAMBA'): exit()
       #-------------------------------


    # =============================================================
    # Extracting Configuration Information from Heterostructure ===
    # =============================================================
    poscar = open(l_info, "r")
    VTemp = poscar.readline().split()
    materials = VTemp[1].replace('+', ' ').split()
    #---------------------------------------------
    t_ions_materials = []
    for i in range(len(materials)):
        ions_vector = []
        mat_temp = materials[i].replace('_', ' ').split()
        for j in range(len(mat_temp)): 
            ions_vector.append(str(mat_temp[j]))
        t_ions_materials.append(ions_vector)
    #-------------------------------------------
    for i in range(6): VTemp = poscar.readline().split()
    t_nions_materials = [];  number = -1
    for i in range(len(materials)):
        nions_vector = []
        mat_temp = materials[i].replace('_', ' ').split()
        for j in range(len(mat_temp)):
            number += 1
            nions_vector.append(int(VTemp[number]))
        t_nions_materials.append(nions_vector)
    #-------------
    poscar.close()
    #-------------


    # =====================================================
    # Extracting the positions of ions from the Lattice ===
    # =====================================================
    poscar = open(file_contcar, "r")
    for i in range(5): VTemp = poscar.readline()
    type_ions = poscar.readline().split()
    type_ions_n = poscar.readline().split()
    poscar.readline()
    coord_ions = []
    rotulo_ions = []
    for i in range(len(type_ions)):
        for j in range(int(type_ions_n[i])):
            VTemp = poscar.readline().split()
            coord_ions.append([ round(float(VTemp[0]), 15), round(float(VTemp[1]), 15), round(float(VTemp[2]), 15) ])
            rotulo_ions.append(type_ions[i])
    poscar.close()


    # ========================================================
    # Extracting thicknesses and separating materials ========
    # ========================================================
    thickness = []; temp_z = [];  z_separation = []
    #----------------------------------------------
    poscar = open(l_info, "r")
    for i in range(8): VTemp = poscar.readline()
    for i in range(nion):
        VTemp = poscar.readline().split()
        temp_z.append(float(VTemp[2]))
    total_thickness = (max(temp_z) -min(temp_z))*param
    total_thickness = round(total_thickness, 15)
    poscar.close()
    #---------------------------------------------------------
    if (n_materials == 1): thickness.append( total_thickness )
    #---------------------------------------------------------
    if (n_materials > 1):
       poscar = open(l_info, "r")
       for i in range(8): VTemp = poscar.readline()
       for i in range(n_materials):
           temp_z = []
           for j in range(int(nions_materials[i])):
               VTemp = poscar.readline().split()
               temp_z.append(float(VTemp[2]))
           temp_t = (max(temp_z) -min(temp_z))*param
           thickness.append(round(temp_t, 15))
           #---------------------------------------
           if (i > 0):
              temp_sep = (min(temp_z) -temp_max)*param
              z_separation.append(round(temp_sep, 15))
           temp_max = max(temp_z)
           #---------------------
       poscar.close()   
    #----------------


    # =================================================
    # Extracting Binding Energy =======================
    # =================================================
    e_binding = '--'
    if os.path.isfile(z-scan_info ):
       #------------------------------
       zscan = open(z-scan_info , "r")
       #--------------------------------------------------
       for i in range(5): VTemp = zscan.readline().split()
       e_binding = float(VTemp[2])
       #-------------
       zscan.close()

       # -------------------------------------
       # Updating Binding Energy -------------
       # -------------------------------------
       if os.path.isfile(file_oszicar):
          if os.path.isfile(file_oszicar_f):
             #------------------------------------
             with open(file_oszicar, 'r') as file:
                lines = file.readlines()
                last_line = lines[-1].split()
                energ_r = float(last_line[2])
             #--------------------------------------
             with open(file_oszicar_f, 'r') as file:
                lines = file.readlines()
                last_line = lines[-1].split()
                energ_f = float(last_line[2])
             #-------------------------------
             e_binding += (energ_f - energ_r)


    # =================================================
    # Extracting Slide Energy =========================
    # =================================================
    e_slide = '--'
    if os.path.isfile(xy-scan_info):
       #-------------------------------
       xyscan = open(xy-scan_info, "r")
       #----------------------------------------------------
       for i in range(6): VTemp = xyscan.readline().split()
       e_slide = round(float(VTemp[2]), 15)
       #-------------
       xyscan.close()


    # ==========================================
    # Splitting the POSCAR file ================
    # ==========================================

    if (n_materials > 1):

       #-------------------------
       poscar = open(l_info, "r")
       #--------------------------------
       VTemp = poscar.readline().split()
       label_materials = VTemp[1].replace('+', ' ').split()
       n_Lattice = len(label_materials);  nion = 0
       range_ion_Lattice = []; ntype_ions = ['']*n_Lattice           
       #--------------------------------------------------
       for m in range(n_Lattice):
           range_ion_Lattice.append( str(1 + nion) + ' ')
           nion += int(VTemp[m+2])
           range_ion_Lattice[m] += str(nion)
       #----------------------------------------------------
       for m in range(6):  VTemp = poscar.readline().split()
       #----------------------------------------------------
       poscar.close()
       #-------------
       for m in range(n_Lattice):
           contador = 0
           for n in range(len(VTemp)):
               contador += int(VTemp[n])
               range_ion = range_ion_Lattice[m].split()
               ion_i = int(range_ion[0]);  ion_f = int(range_ion[1])
               if (contador >= ion_i and contador <= ion_f):
                  ntype_ions[m] += str(VTemp[n]) + ' '

       for m in range(n_Lattice):
           #-------------------------
           poscar = open(l_info, "r")
           poscar_new = open('output/POSCAR_material_' + str(m+1) + type_files, 'w')
           #------------------------------------------------------------------------
           VTemp = poscar.readline()
           poscar_new.write(f'POSCAR \n')
           #-----------------------------
           for n in range(4):
               VTemp = poscar.readline()
               poscar_new.write(f'{VTemp}')
           #-------------------------------
           VTemp = poscar.readline()
           temp = label_materials[m].replace('_', ' ')
           poscar_new.write(f'{temp} \n')
           #-----------------------------
           VTemp = poscar.readline()
           poscar_new.write(f'{ntype_ions[m]} \n')
           #--------------------------------------
           VTemp = poscar.readline()
           poscar_new.write(f'direct \n')
           #---------------------------------------
           range_ion = range_ion_Lattice[m].split()
           ion_i = int(range_ion[0]);  ion_f = int(range_ion[1])
           #----------------------------------------------------
           for n in range(1,(nion+1)):
               VTemp = poscar.readline()
               if (n >= ion_i and n <= ion_f):  poscar_new.write(f'{VTemp}')
           #----------------------------------------------------------------
           poscar.close()
           poscar_new.close()
           #-----------------


    # ===============================================
    # Building the .json file =======================
    # ===============================================

    #-----------------------------------------------------
    # Initializing the JSON file with an empty dictionary:
    #-----------------------------------------------------
    with open(file_json, 'w') as file_json:
        json.dump({}, file_json)

    # ===============================================
    # Updating .json file information ===============
    # ===============================================

    #-------
    crit = 1
    #-----------
    file = l_file
    if (file == 'null'):  crit = 0
    #-----------------------------

    if (crit == 1):
       # ===================================================
       # Starting tags with empty values "--" ==============
       # ===================================================
       loop = 0
       #-------
       id = '--';  id_monolayers = '--'
       label = '--';  label_materials = '--';  formula = '--'
       nlayers = '--';  nions = '--';  nions_monolayers = '--';  range_ions_materials = '--'
       type_ions_materials = '--';  type_nions_materials = '--' 
       lattice_type = '--';  point_group = [];  point_group_schoenflies = [];  space_group = [];  space_group_number = [];  inversion_symmetry = []
       param_a = '--';  a1 = '--';  a2 = '--';  a3 = '--';  param_b = '--';  b1 = '--';  b2 = '--';  b3 = '--'
       module_a1_a2_a3 = '--'; module_b1_b2_b3 = '--';  angle_a1a2_a1a3_a2a3 = '--'; angle_b1b2_b1b3_b2b3 = '--'
       cell_area = '--';  cell_vol = '--';  zb_area = '--';  zb_volume = '--'
       direct_coord_ions = '--';  label_ions = '--';  k_path = '--'
       #----------------------------------------------------------------------------------------------------------
       e_vbm = '--';  e_cbm = '--';  e_fermi = '--';  e_vacuum = '--';  work_function = '--';  total_energy = '--'
       tk_vbm = '--';  tk_cbm = '--'; k_vbm = '--';  k_cbm = '--' 
       nk = '--';  nb = '--';  ne = '--';  ne_valence = '--';  vbm = '--';  cbm = '--';  charge_transfer = []
       gap = '--';  type_gap = '--';  k_vbm = [];  k_cbm = [];  lorbit = '--';  ispin = '--'
       #------------------------------------------------------------------------------------
       non_collinear = '--';  spin_orbit = '--';  lorbit = '--';  ispin = '--'
       #----------------------------------------------------------------------


       # =========================================  ????????????????????????????????????????????????????????????????????????????????????????????????????????????
       # Extracting the vacuum level: ============  ?????????????????????????????? Only makes sense for 2D systems confined in Z ???????????????????????????????
       # =========================================  ????????????????????????????????????????????????????????????????????????????????????????????????????????????
       l_pot = 'null'
       #----------------------------------------------
       if os.path.isfile(pot_bands): l_pot = pot_bands
       if os.path.isfile(pot_scf):   l_pot = pot_scf
       #--------------------------------------------
       if (l_pot != 'null'):
          file0 = np.loadtxt(l_pot)
          file0.shape
          #-----------------
          date_e = file0[:,1]
          e_vacuum = max(date_e)
       #------------------------


       # ===========================================
       # Extracting data from VASProcar output =====
       # ===========================================
       with open('output/' + file, "r") as info: lines = info.readlines()
       #-----------------------------------------------------------------
       for i in range(len(lines)):
           VTemp = lines[i].replace('(', ' ( ').replace(')', ' ) ').replace(';', '').replace(',', '').split()
           if (len(VTemp) > 0):
              #----------------------------------------
              if (VTemp[0] == 'LNONCOLLINEAR'):  non_collinear = str(VTemp[2])
              #----------------------------------------
              elif (VTemp[0] == 'LSORBIT'):  spin_orbit = str(VTemp[2])
              #----------------------------------------
              elif (VTemp[0] == 'nº' or VTemp[0] == 'nÂº'):
                 if (VTemp[1] == 'k-points'):  nk = int(VTemp[3])
                 if (VTemp[5] == 'bands'):  nb = int(VTemp[7])
                 if (VTemp[1] == 'ions'):  ni = int(VTemp[3])
                 if (VTemp[5] == 'electrons'):  ne = round(float(VTemp[7]), 15)
              #--------------------------------------------------------------------
              elif (VTemp[0] == 'LORBIT'):
                 lorbit = int(VTemp[2])
                 if (VTemp[3] == 'ISPIN'):  ispin = int(VTemp[5])
              #----------------------------------------
              elif (VTemp[0] == 'Last'):  vbm = int(VTemp[4])
              #----------------------------------------
              elif (VTemp[0] == 'First'):  cbm = vbm +1
              #----------------------------------------
              elif (VTemp[0] == 'Valence'):
                   e_vbm = round(float(VTemp[7]), 15)
                   tk_vbm = int(VTemp[11])
              #----------------------------------------
              elif (VTemp[0] == 'Conduction'):
                   e_cbm = round(float(VTemp[7]), 15)
                   tk_cbm = int(VTemp[11])
              #----------------------------------------
              elif (VTemp[0] == 'GAP'):
                type_gap = str(VTemp[2])
                gap = round(float(VTemp[5]), 15)
              #----------------------------------------
              elif (VTemp[0] == 'Fermi'): e_fermi = round(float(VTemp[3]), 15)
              #----------------------------------------
              elif (VTemp[0] == 'free'):
                   total_energy = round(float(VTemp[4]), 15)
                   # e_per_ion = round(float(total_energy)/ni, 15)
              #--------------------------------------------------------
              elif (VTemp[0] == 'Volume_cell'):  Volume_cell = round(float(VTemp[2]), 15)
              #----------------------------------------
              elif (VTemp[0] == 'Param.'):  param = float(VTemp[2])   
              #----------------------------------------
              elif (VTemp[0] == 'A1'):
                   a1 = [round(float(VTemp[4])*param, 15), round(float(VTemp[5])*param, 15), round(float(VTemp[6])*param, 15)]                  
                   A1 = np.array([float(VTemp[4]), float(VTemp[5]), float(VTemp[6])])*param;  module_a1_a2_a3 = []; module_a1_a2_a3.append(round(np.linalg.norm(A1), 15))
              elif (VTemp[0] == 'A2'):
                   a2 = [round(float(VTemp[4])*param, 15), round(float(VTemp[5])*param, 15), round(float(VTemp[6])*param, 15)]
                   A2 = np.array([float(VTemp[4]), float(VTemp[5]), float(VTemp[6])])*param;  module_a1_a2_a3.append(round(np.linalg.norm(A2), 15))
              elif (VTemp[0] == 'A3'):
                   a3 = [round(float(VTemp[4])*param, 15), round(float(VTemp[5])*param, 15), round(float(VTemp[6])*param, 15)]
                   A3 = np.array([float(VTemp[4]), float(VTemp[5]), float(VTemp[6])])*param;  module_a1_a2_a3.append(round(np.linalg.norm(A3), 15))
                   #-------------------------------------------------------
                   angle_a1a2_a1a3_a2a3 = []
                   angle_a1a2_a1a3_a2a3.append(round(np.degrees(np.arccos(np.dot(A1,A2) / (np.linalg.norm(A1) * np.linalg.norm(A2)))), 15))
                   angle_a1a2_a1a3_a2a3.append(round(np.degrees(np.arccos(np.dot(A1,A3) / (np.linalg.norm(A1) * np.linalg.norm(A3)))), 15))
                   angle_a1a2_a1a3_a2a3.append(round(np.degrees(np.arccos(np.dot(A2,A3) / (np.linalg.norm(A2) * np.linalg.norm(A3)))), 15))
              #----------------------------------------
              elif (VTemp[0] == '2pi/Param.'):  fator_rec = float(VTemp[2])   
              #----------------------------------------
              elif (VTemp[0] == 'B1'):
                   b1 = [round(float(VTemp[4])*fator_rec, 15), round(float(VTemp[5])*fator_rec, 15), round(float(VTemp[6])*fator_rec, 15)]
                   B1 = np.array([float(VTemp[4]), float(VTemp[5]), float(VTemp[6])])*fator_rec;  module_b1_b2_b3 = []; module_b1_b2_b3.append(round(np.linalg.norm(B1), 15))
              elif (VTemp[0] == 'B2'):
                   b2 = [round(float(VTemp[4])*fator_rec, 15), round(float(VTemp[5])*fator_rec, 15), round(float(VTemp[6])*fator_rec, 15)]
                   B2 = np.array([float(VTemp[4]), float(VTemp[5]), float(VTemp[6])])*fator_rec;  module_b1_b2_b3.append(round(np.linalg.norm(B2), 15))
              elif (VTemp[0] == 'B3'):
                   b3 = [round(float(VTemp[4])*fator_rec, 15), round(float(VTemp[5])*fator_rec, 15), round(float(VTemp[6])*fator_rec, 15)]
                   B3 = np.array([float(VTemp[4]), float(VTemp[5]), float(VTemp[6])])*fator_rec;  module_b1_b2_b3.append(round(np.linalg.norm(B3), 15))
                   #-------------------------------------------------------
                   angle_b1b2_b1b3_b2b3 = []
                   angle_b1b2_b1b3_b2b3.append(round(np.degrees(np.arccos(np.dot(B1,B2) / (np.linalg.norm(B1) * np.linalg.norm(B2)))), 15))
                   angle_b1b2_b1b3_b2b3.append(round(np.degrees(np.arccos(np.dot(B1,B3) / (np.linalg.norm(B1) * np.linalg.norm(B3)))), 15))
                   angle_b1b2_b1b3_b2b3.append(round(np.degrees(np.arccos(np.dot(B2,B3) / (np.linalg.norm(B2) * np.linalg.norm(B3)))), 15))
              #----------------------------------------
              elif (VTemp[0] == 'Volume_ZB'):  vol_zb = VTemp[2]   
              #----------------------------------------
              elif (VTemp[0] == 'k-points'):  loop = i+3


       if (tk_vbm != '--' and tk_cbm != '--'):
          # ===========================================
          # Finding the band gap k-points =============
          # ===========================================
          if ( file == info_bands.replace("output/","") ):
             info = open(info_bands, "r")
             #-----------
             test = 'nao'
             #-----------
             while (test == 'nao'):             
                #--------------------------------
                VTemp = info.readline().split()
                #-----------------------------------------------------------
                if (len(VTemp) > 0 and VTemp[0] == 'k-points'): test = 'sim'                       
                #-----------------------------------------------------------
             for nn in range(2): VTemp = info.readline()
             for nn in range(1,(nk+1)):
                 VTemp = info.readline().split()
                 if (nn == int(tk_vbm)): k_vbm = [round(float(VTemp[1]), 15), round(float(VTemp[2]), 15), round(float(VTemp[3]), 15)]
                 if (nn == int(tk_cbm)): k_cbm = [round(float(VTemp[1]), 15), round(float(VTemp[2]), 15), round(float(VTemp[3]), 15)]


       # =================================================================
       # Searching for values ​​for the Transfer of Bader's Charge =========
       # =================================================================
       if (n_materials > 1):
          #===========
          if os.path.isfile(file_charger):
             file_bader = file_charger
             #----------------------------
             bader = open(file_bader, "r")
             for nn in range(4): VTemp = bader.readline()
             for mn in range(len(t_ions_materials)):
                 vector_bader = []
                 VTemp = bader.readline()
                 VTemp = bader.readline().split()
                 vector_bader.append(round(float(VTemp[2]), 15))
                 for mm in range(len(t_ions_materials[mn])):
                     VTemp = bader.readline().split()
                     vector_bader.append(round(float(VTemp[3]), 15))
                 charge_transfer.append(vector_bader)


       # =========================================================
       # Obtaining lattice symmetries ============================
       # =========================================================

       #--------------------------------------------------------------------
       # Hermann-Mauguin Mapping Dictionary for Schoenflies ----------------
       #--------------------------------------------------------------------
       schoenflies = {"1": "C1",  "-1": "Ci",  "2": "C2",  "m": "Cs",  "2/m": "C2h",  "222": "D2",  "mm2": "C2v",  "mmm": "D2h",  "4": "C4",  "-4": "S4",  "4/m": "C4h",
                      "422": "D4",  "4mm": "C4v",  "-42m": "D2d",  "4/mmm": "D4h",  "3": "C3",  "-3": "C3i",  "32": "D3",  "3m": "C3v",  "-3m": "D3d",  "6": "C6",  "-6": "C3h",  
                      "6/m": "C6h",  "622": "D6",  "6mm": "C6v",  "-6m2": "D3h",  "6/mmm": "D6h",  "23": "T",  "m-3": "Th",  "432": "O",  "-43m": "Td",  "m-3m": "Oh"}
       #--------------------------------------------------------------------
       if (n_materials == 1): passo = 1
       if (n_materials >  1): passo = n_materials +1
       #--------------------------------------------
       for i in range(passo):
           #-----------------
           if (i == 0): structure = Poscar.from_file(l_info).structure
           if (i >  0): structure = Poscar.from_file('output/POSCAR_material_' + str(i) + type_files).structure
           analyzer = SpacegroupAnalyzer(structure)
           #----------------------------------------------------
           point_group.append(analyzer.get_point_group_symbol())
           space_group.append(analyzer.get_space_group_symbol())
           space_group_number.append(analyzer.get_space_group_number())
           inversion_symmetry.append(analyzer.is_laue())
           if (i == 0): lattice_type = analyzer.get_lattice_type()
           point_group_schoenflies.append(schoenflies.get(point_group[0], "Desconhecido"))
           #------------------------------------------------------------------------------
 

       #======================================================
       # Obtaining the area in the XY plane of the lattice ===
       #======================================================
       V1 = np.array([A1[0], A1[1]])
       V2 = np.array([A2[0], A2[1]])
       #----------------------------
       # Cell area in the XY plane
       Area_cell = round(np.linalg.norm(np.cross(V1, V2)), 15)
       #------------------------------------------------------


       #===================================================
       # Obtaining the area in the KxKy plane of the ZB ===
       #===================================================
       V1 = np.array([B1[0], B1[1]])
       V2 = np.array([B2[0], B2[1]])
       #----------------------------
       # Area of ​​ZB in the KxKy plane
       Area_ZB = round(np.linalg.norm(np.cross(V1, V2)), 15)
       #----------------------------------------------------


       #===================================================
       # Obtaining information about magnetization ========
       #===================================================
       target_tags = [ "Mean Absolute Magmom",
                       "Total Net MAGMOM",
                       "Magnetic Order Parameter (R)",
                       "Magnetic Type Primary",
                       "Magnetic Phase Description" ]
       #---------------------------------------------
       magnetic_map = { "Non-magnetic (NM)": "NM",
                        "Ferromagnetic (FM)": "FM",
                        "Antiferromagnetic (AFM)": "AFM",
                        "quasi Ferromagnetic (FM)": "quasi-FM",
                        "quasi Antiferromagnetic (AFM)": "quasi-AFM",
                        "quasi Non-magnetic (NM)": "quasi-NM",
                        "Ferrimagnetic/Complex": "FiM/Complex" }
       #--------------------------------------------------------
       magnetic_results = {tag: "--" for tag in target_tags}
       #----------------------------------------------------
       file_path = os.path.join('output', l_file)
       #-----------------------------------------
       if os.path.isfile(file_path):
           with open(file_path, 'r') as f:
               for line in f:
                   if ":" in line:
                       #-------------------------
                       parts = line.split(":", 1)
                       tag = parts[0].strip()
                       #---------------------
                       if tag in target_tags:
                           val_raw = parts[1].strip()
                           if tag == "Magnetic Order Parameter (R)":
                               try: magnetic_results[tag] = float(val_raw)
                               except ValueError: magnetic_results[tag] = val_raw
                           else: magnetic_results[tag] = magnetic_map.get(val_raw, val_raw)
       #-----------------------------------------------------------------------------------
       magmoms_site = []
       if os.path.isfile(file_magmom):
          mag_file = open(file_magmom, 'r') 
          for i in range(2): Mtemp = mag_file.readline()
          for i in range(ni):
              Mtemp = mag_file.readline().split()
              if (len(Mtemp) == 2): magmoms_site.append([round(float(Mtemp[-1]), 4)])
              if (len(Mtemp) == 4): magmoms_site.append([round(float(Mtemp[-3]), 4), round(float(Mtemp[-2]), 4), round(float(Mtemp[-1]), 4)])
          mag_file.close()
       #------------------


       # ===========================================
       # Creating the Dictionary ===================
       # ===========================================

       date = {
               "id": id_code if id_code not in ["--", []] else None,
               "number_layers": n_materials if n_materials not in ["--", []] else None,
               "id_layers": id_materials if id_materials not in ["--", []] else None,
               "formula": estequiometria if estequiometria not in ["--", []] else None,
               "type_ions_layers": t_ions_materials if t_ions_materials not in ["--", []] else None,
               "number_ions_layers": nions_materials if nions_materials not in ["--", []] else None,
               "number_type_ions_layers": t_nions_materials if t_nions_materials not in ["--", []] else None,
               "range_ions_layers": r_ions_materials if r_ions_materials not in ["--", []] else None,
               "number_ions": ni if ni not in ["--", []] else None,
               # --------------------------------------------------
               "doi": "10.1038/s41524-025-01892-z",
               "article": "A high-throughput framework and database for twisted 2D vander Waals bilayers",
               "bibteX": "@article{araujo2025twisted,\n title = {A high-throughput framework and database for twisted 2D van der Waals bilayers},\n author = {Araújo, Augusto L. and Sophia, Pedro H. and Crasto de Lima, F. and Fazzio, Adalberto},\n journal = {npj Computational Materials},\n year = {2025},\n doi = {10.1038/s41524-025-01892-z},\n url = {https://doi.org/10.1038/s41524-025-01892-z},\n publisher = {Nature Publishing Group}\n}",
               # -------------------------------------------------------------------------
               "area_perc_mismatch": area_perc_mismatch  if n_materials > 1 and area_perc_mismatch not in ["--", []] else None,
               "perc_area_change": perc_area_change  if n_materials > 1 and perc_area_change not in ["--", []] else None,
               "perc_mod_vectors_change": perc_mod_vectors_change  if n_materials > 1 and perc_mod_vectors_change not in ["--", []] else None,
               "angle_perc_mismatch": angle_perc_mismatch  if n_materials > 1 and angle_perc_mismatch not in ["--", []] else None,
               "perc_angle_change": perc_angle_change  if n_materials > 1 and perc_angle_change not in ["--", []] else None,
               "rotation_angle": rotation_angle  if n_materials > 1 and rotation_angle not in ["--", []] else None,
               "supercell_matrix": supercell_matrix  if n_materials > 1 and supercell_matrix not in ["--", []] else None,
               "deformation_matrix": deformation_matrix  if n_materials > 1 and deformation_matrix not in ["--", []] else None,
               "strain_matrix": strain_matrix  if n_materials > 1 and strain_matrix not in ["--", []] else None,
               # "structural_optimization": 'DFT',      # 'none', 'DFT', 'ML', 'ML/DFT'
               "shift_plane": shift_plane if n_materials > 1 and shift_plane not in ["--", []] else None,
               "z_separation": z_separation  if n_materials > 1 and z_separation not in ["--", []] else None,
               "thickness": thickness if thickness not in ["--", []] else None,
               "total_thickness": total_thickness if total_thickness not in ["--", []] else None,
               # --------------------------------------------------------------------------------
               "lattice_type": lattice_type if lattice_type not in ["--", []] else None,
               "point_group": point_group if point_group not in ["--", []] else None,
               # "point_group_schoenflies": point_group_schoenflies if point_group_schoenflies not in ["--", []] else None,
               "space_group": space_group if space_group not in ["--", []] else None,
               "space_group_number": space_group_number if space_group_number not in ["--", []] else None,
               "inversion_symmetry": inversion_symmetry if inversion_symmetry not in ["--", []] else None,
               "pseudo_type": pseudo_type if pseudo_type not in ["--", []] else None,
               "exchange_correlation_functional": exchange_correlation_functional if exchange_correlation_functional not in ["--", []] else None,
               "vdW": vdW if vdW not in ["--", []] else None,
               "non_collinear": non_collinear if non_collinear not in ["--", []] else None,
               "spin_orbit": spin_orbit if spin_orbit not in ["--", []] else None,
               # "param_a": param if param not in ["--", []] else None,
               "a1": a1 if a1 not in ["--", []] else None,
               "a2": a2 if a2 not in ["--", []] else None,
               "a3": a3 if a3 not in ["--", []] else None,
               "module_a1_a2_a3": module_a1_a2_a3 if module_a1_a2_a3 not in ["--", []] else None,
               "angle_a1a2_a1a3_a2a3": angle_a1a2_a1a3_a2a3 if angle_a1a2_a1a3_a2a3 not in ["--", []] else None,
               "cell_area": Area_cell if Area_cell not in ["--", []] else None,
               "cell_vol": Volume_cell if Volume_cell not in ["--", []] else None,
               # "param_b": fator_rec if fator_rec not in ["--", []] else None,
               "b1": b1 if b1 not in ["--", []] else None,
               "b2": b2 if b2 not in ["--", []] else None,
               "b3": b3 if b3 not in ["--", []] else None,
               "module_b1_b2_b3": module_b1_b2_b3 if module_b1_b2_b3 not in ["--", []] else None,
               "angle_b1b2_b1b3_b2b3": angle_b1b2_b1b3_b2b3 if angle_b1b2_b1b3_b2b3 not in ["--", []] else None,
               "zb_area": Area_ZB if Area_ZB not in ["--", []] else None,
               "zb_volume": vol_zb if vol_zb not in ["--", []] else None,
               "direct_coord_ions": coord_ions if coord_ions not in ["--", []] else None,
               "label_ions": rotulo_ions if rotulo_ions not in ["--", []] else None,
               "kpath": kpath if kpath not in ["--", []] else None,
               "kpath_label": kpath_label if kpath_label not in ["--", []] else None,
               "lorbit": lorbit if lorbit not in ["--", []] else None,
               "ispin": ispin if ispin not in ["--", []] else None,
               "nk": nk if nk not in ["--", []] else None,
               "nb": nb if nb not in ["--", []] else None,
               "ne": ne if ne not in ["--", []] else None,
               "gap": gap if gap not in ["--", []] else None,
               "e_vbm": e_vbm if e_vbm not in ["--", []] else None,
               "e_cbm": e_cbm if e_cbm not in ["--", []] else None,
               "vbm": vbm if vbm not in ["--", []] else None,
               "cbm": cbm if cbm not in ["--", []] else None,
               "type_gap": type_gap if type_gap not in ["--", []] else None,
               "k_vbm": k_vbm if k_vbm not in ["--", []] else None,
               "k_cbm": k_cbm if k_cbm not in ["--", []] else None,
               "e_fermi": e_fermi if e_fermi not in ["--", []] else None,
               "e_vacuum": e_vacuum if e_vacuum not in ["--", []] else None,
               # "work_function": work_function if work_function not in ["--", []] else None,
               "total_energy": total_energy if total_energy not in ["--", []] else None,
               "e_per_ion":  round(float(total_energy)/ni, 15) if total_energy not in ["--", []] else None,
               "e_per_area": round(float(total_energy)/float(Area_cell), 15) if total_energy not in ["--", []] else None,
               "e_binding": e_binding  if n_materials > 1 and e_binding not in ["--", []] else None,
               "e_slide": e_slide  if n_materials > 1 and e_slide not in ["--", []] else None,
               "charge_transfer": charge_transfer  if n_materials > 1 and charge_transfer not in ["--", []] else None,
               #----------------------------------------------------------------
               "magmoms_site":          magnetic_results.get("magmoms_site") if magnetic_results.get("magmoms_site") else None,
               "mean_absolute_magmom":  None if magnetic_results.get("Mean Absolute Magmom") == "--" else magnetic_results.get("Mean Absolute Magmom"),
               "mag_order_parameter":   None if magnetic_results.get("Magnetic Order Parameter (R)") == "--" else magnetic_results.get("Magnetic Order Parameter (R)"),
               "total_net_magmom":      None if magnetic_results.get("Total Net MAGMOM") in ["NaN", "--"] else magnetic_results.get("Total Net MAGMOM"),
               "mag_type_primary":      None if magnetic_results.get("Magnetic Type Primary") == "--" else magnetic_results.get("Magnetic Type Primary"),
               "mag_phase_description": None if magnetic_results.get("Magnetic Phase Description") == "--" else magnetic_results.get("Magnetic Phase Description")
               }


       # ==================================================
       # Inserting the information into the .json file ====
       # ==================================================
       with open(file_json, 'r', encoding='utf-8') as file: data = json.load(file)
       data.update(date)
       with open(file_json, 'w', encoding='utf-8') as file: json.dump(data, file, indent=4, ensure_ascii=False)
       #-----------------------------------------------------------
       # with open(file_json, 'r') as file:  data = json.load(file)
       # data.update(date)
       # with open(file_json, 'w') as file: json.dump(data, file, indent=4)


    #===============================================================
    # Updating POSCAR and CONTCAR files ============================
    #===============================================================
    with open(file_poscar, 'r') as file: line = file.readlines()
    tline = line[0].split()
    #--------------------
    replace_line = tline[0] + ' ' + tline[1] + ' '
    for i in range(n_materials): replace_line += tline[2 +i] + ' '
    replace_line += tline[-1] + '\n'
    #------------------------------
    line[0] = replace_line
    with open(file_poscar, 'w') as file: file.writelines(line)
    #===============================================================
    with open(file_contcar, 'r') as file: line = file.readlines()
    line[0] = replace_line
    with open(file_contcar, 'w') as file: file.writelines(line)
    #===============================================================
