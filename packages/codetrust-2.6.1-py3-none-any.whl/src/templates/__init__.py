# Copyright (c) 2026 Said Borna. All rights reserved.
# Proprietary — see LICENSE for terms.
# Templates package — product files installed by `codetrust init`.
