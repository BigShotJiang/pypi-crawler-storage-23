# Consignes en didactique des bases de données

En SQL, certains opérateurs sont plus complexes à manipuler que d'autres.

## Les opérateurs de jointure

Globalement, les jointures sont difficiles à comprendre pour un débutant. Leur fonction dans une requête SQL n'est pas évident à comprendre. Parmi les différents types de jointure, la complexité n'est pas uniforme. Voici une analyse :
* Les jointures internes (clause INNER JOIN) de type "clé-primaire = clé-étrangère" sont les plus simples.
* Les jointures externes (clauses LEFT OUTER JOIN, RIGHT OUTER JOIN et FULL OUTER JOIN) sont plus complexes à manipuler. 
* Les jointures croisées (clause CROSS JOIN) sont complexes, mais assez rares.
* Les jointures naturelles (clause NATURAL JOIN) semblent simples, mais sont dangereuses, en particulier par l'implicite et, surtout, par la jointure d'attributs qui n'est pas désirée.

## Les regroupements

Les regroupements (clause GROUP BY) sont complexes à manipuler, en particulier le mécanisme de base. Les fonctions d'agrégation (COUNT, SUM, AVG, MIN, MAX) le sont bien sûr, mais c'est surtout le regroupement lui-même qui est complexe, en particulier, avec conditions (HAVING). Les notions de paquets et de filtres sur les paquets sont complexes à manipuler.

## Les sous-requêtes

Les sous-requêtes sont aussi très complexes à manipuler dont, en particulier, les sous-requêtes corrélées. Les débutants ont souvent du mal avec le type de résultat retourné pas la sous-requête et les opérateurs autorisés.

## L'ordre/tri des lignes (des tuples) et projection des colonnes

L'ordre des lignes dans la table résultat (clause ORDER BY) est relativement simple à manipuler, mais il faut y être attentif. Attention aussi à l'ordre des lignes à plusieurs niveaux qui est un peu plus complexe. Il faut faire attention aux attributs utilisés pour le tri et, quand il y en a plusieurs, leur ordre dans la clause ORDER BY qui impacte le tri des tuples. En cas de clause ORDER BY, l'ordre des lignes (des tuples) est très important.

L'ordre des colonnes (clause SELECT) n'est pas important. Par contre, il faut veiller à ce que toutes les colonnes attendues soient présentes. L'ordre des colonnes dans la clause SELECT n'a pas d'impact sur le résultat et n'est pas en lien avec l'ordre des lignes (attributs de la clause ORDER BY).

## La sélection

La sélection des tuples (clause WHERE) est simple à manipuler, mais il faut y être attentif. En particulier, il faut bien comprendre les opérateurs de comparaison et les opérateurs logiques. 

## Les doublons

Souvent, les débutants utilisent mal la clause DISTINCT. Il faut bien comprendre que DISTINCT s'applique à l'ensemble des colonnes de la clause SELECT. Si on veut éviter les doublons sur une seule colonne, il faut utiliser la clause GROUP BY. Parfois, ils l'utilisent alors qu'ils projettent la clé de la table finale. Il est donc inutile. D'autres fois, ils n'ont pas conscience de la présence de doublons dans les tables de départ et s'ils sont autorisés ou interdits.

# Situation

Pour la recherche suivante :
*{{intention}}*

*La requête SQL correcte* est :
```sql
{{requete_attendue}}
```

L'élève propose *la requête SQL* suivante :
```sql
{{requete}}
```
{% if cmp %}
L'analyse de la table résultat donne :
*{{cmp}}*
{% endif %}

# Instructions

1) Indique à l'élève si sa requête est équivalente à la requête correcte.

2) Fait un feedback. Pour ce feedback, il ne faut pas donner directement la solution ni les opérateurs SQL à utiliser. Tu dois :
* Si la requête de l'élève n'est pas correcte :
  - expliquer pourquoi sa requête ne fonctionne pas.
  - lui donner des indices, éventuellement en lui posant des questions, pour l'amener à corriger sa requête. 
* Si la requête de l'élève est correcte : le féliciter.

Attention à ne pas donner la requête correcte, même par morceaux
