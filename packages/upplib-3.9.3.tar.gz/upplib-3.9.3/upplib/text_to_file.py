import sys
from upplib import *
from upplib.common_package import *


def sync_thread_config(file_dir: str = None,
                       file_name: str = None,
                       file_name_prefix: str = None,
                       file_name_suffix: str = None,
                       interval: int = None,
                       line_with_space_count: int = None,
                       mode: str = 'a',
                       with_time_unique_suffix: bool = False,
                       fun_name: callable = None) -> list:
    """
    实现参数的线程级持久化。
    完善逻辑：若开启唯一后缀，则在首次生成后缓存该文件名，确保后续调用指向同一文件。
    """
    thread_data = get_thread_local_index_data()
    fun_name_str = fun_name.__name__ if fun_name else "default_fun"

    # 1. 预处理：从缓存中恢复“是否开启后缀”的状态
    # 如果当前没传，则看缓存里之前是不是 True
    cache_suffix_key = f"{fun_name_str}__with_time_unique_suffix"
    final_with_suffix = with_time_unique_suffix if with_time_unique_suffix is not False else thread_data.get(cache_suffix_key, False)

    # 2. 核心文件名逻辑
    file_name_new = None
    cache_name_new_key = f"{fun_name_str}__file_name_new"

    # 如果开启了唯一后缀
    if final_with_suffix:
        # 尝试从缓存获取“已经生成过的带时间戳的文件名”
        file_name_new = thread_data.get(cache_name_new_key)

        # 如果缓存里没有，或者本次显式传了新的 file_name，则需要重新生成
        if file_name_new is None and file_name is not None:
            seed_name = file_name if file_name is not None else file_dir
            file_name_new = get_file_name(file_name=seed_name)
    else:
        # 如果没开启后缀，file_name_new 就等于原文件名
        file_name_new = file_name

    # 3. 状态位标记
    if mode != 'a':
        thread_data['_use_fun_flag'] = True
    thread_data['_use_fun'] = fun_name

    # 4. 参数映射与持久化同步
    params_to_track = {
        'file_dir': file_dir,
        'file_name': file_name,
        'file_name_new': file_name_new,  # 这是最终使用的带时间戳的文件名
        'file_name_prefix': file_name_prefix,
        'file_name_suffix': file_name_suffix,
        'interval': interval,
        'line_with_space_count': line_with_space_count,
        'with_time_unique_suffix': final_with_suffix,
    }

    result_values = []
    for key, value in params_to_track.items():
        cache_key = f"{fun_name_str}__{key}"

        # 这里的逻辑是：如果当前有输入，则更新缓存；如果没输入，则复用缓存
        final_val = value if value is not None else thread_data.get(cache_key)

        thread_data[cache_key] = final_val
        result_values.append(final_val)

    return result_values


def get_file_name(file_name: str = 'txt',
                  suffix: str = '.txt') -> str:
    """
    生成文件名格式：{name}_{年月日}_{时分}_{秒随机数}{后缀}
    示例：log_20231027_1030_4512.txt
    """
    # 1. 获取时间分量
    now = datetime.today()
    # %Y%m%d -> 20231027
    # %H%M   -> 1030
    # %S     -> 45
    date_part = now.strftime('%Y%m%d')
    time_part = now.strftime('%H%M')
    second_part = now.strftime('%S')

    # 2. 处理原始文件名与后缀
    raw_name = str(file_name) if file_name is not None else "txt"

    if '.' in raw_name:
        # 分离文件名和后缀，例如 "data.tar.gz" -> "data.tar", "gz"
        name_part, ext_part = raw_name.rsplit('.', 1)
        target_name = name_part
        actual_suffix = '.' + ext_part
    else:
        target_name = raw_name
        actual_suffix = suffix

    # 3. 获取2位随机数
    rand_str = random_int_str(length=2)

    # 4. 按照新格式组合：{name}_{日期}_{时间}_{秒随机数}{后缀}
    return (f"{target_name}"
            f"_{date_part}"
            f"_{time_part}"
            f"_{second_part}{rand_str}"
            f"{actual_suffix}")


def to_print(*args,
             time_prefix: bool = False,
             line_with_space_count: int = None,
             interval: int = None) -> str:
    """
    智能日志打印：支持对象转 JSON、时间前缀、缩进及间隔控制。
    """
    # 1. 节流检查 (Throttling Check) - 优先检查，未到时间直接跳过复杂逻辑
    now_ts = int(time.time())  # 获取当前秒级时间戳
    thread_data = get_thread_local_index_data()
    last_print_time = thread_data.get('to_print_time', 0)

    should_print = (interval is None) or (now_ts - last_print_time >= interval)

    # 2. 格式化数据负载
    def _format(obj: Any) -> str:
        if isinstance(obj, (dict, list)):
            try:
                # 使用 json.dumps 并提供 fallback，确保非标对象不报错
                return json.dumps(obj, ensure_ascii=False, default=str)
            except:
                return str(obj)
        return str(obj)

    # 组合所有参数为字符串
    payload = ' '.join(_format(arg) for arg in args).strip()

    # 3. 处理时间前缀
    current_time_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    # 构造返回和打印的内容
    log_content = f"{current_time_str} {payload}" if time_prefix else payload
    # 处理空内容兜底
    if not log_content:
        log_content = current_time_str

    prefix_space = ' ' * (line_with_space_count or 0)
    final_output = prefix_space + log_content

    # 4. 执行打印并更新状态
    if should_print:
        thread_data['to_print_time'] = now_ts
        # 如果设置了 interval，打印时额外强制带上当前时间戳
        print_msg = f"{current_time_str} {final_output}" if interval else final_output
        print(print_msg)

    return final_output


def to_file(data_param: Any,
            file_name: str = 'to_file',
            file_dir: str = 'to_file',
            fixed_name: bool = False,
            mode: str = 'a',
            suffix: str = '.txt',
            sep_list: str = '\t') -> str:
    r"""
    将 list 中的数据以 json 或者基本类型的形式写入到文件中
    data_param   : 数组数据, 也可以不是数组
    file_name    : 文件名 , 默认 to_file
                  当文件名是 C:\Users\yangpu\Desktop\study\abc\d\e\f\a.sql 这种类型的时候, 可以直接创建文件夹,
                      会赋值 file_name=a,
                            file_dir=C:\Users\yangpu\Desktop\study\abc\d\e\f,
                            fixed_name=True,
                            suffix=.sql
                  当文件名是 abc 的时候, 按照正常值,计算
    file_dir    : 文件路径
    fixed_name  : 是否固定文件名
    suffix      : 文件后缀, 默认 .txt
    sep_list    : 当 data_param 是 list(list) 类型的时候 使用 sep_list 作为分割内部的分隔符,
                  默认使用 \t 作为分隔符, 如果为 None , 则按照 json 去处理这个 list
    """
    # 1. 处理传入的 file_name 包含完整路径的情况
    if os.sep in file_name or '/' in file_name:
        # 使用 os.path 自动拆分路径、文件名、后缀
        full_dir = os.path.dirname(file_name)
        base_with_ext = os.path.basename(file_name)
        name_part, ext_part = os.path.splitext(base_with_ext)

        file_dir = full_dir
        file_name = name_part
        suffix = ext_part or suffix
        fixed_name = True

    # 2. 核心：确保目录存在 (替代 check_file 或在其内部实现)
    # 使用 os.makedirs(..., exist_ok=True) 递归创建目录且不报错
    if file_dir:
        os.makedirs(file_dir, exist_ok=True)

    # 3. 处理文件名逻辑
    # 检查 file_name 自身是否带后缀
    if '.' in file_name:
        name_part, ext_part = os.path.splitext(file_name)
        file_name = name_part
        suffix = ext_part

    if fixed_name:
        final_file_name = f"{file_name}{suffix}"
    else:
        # 调用之前定义的 get_file_name
        final_file_name = get_file_name(file_name, suffix)

    # 4. 安全拼接完整路径
    file_path = os.path.join(file_dir, final_file_name)

    # 5. 写入文件 (使用 with 语句确保自动关闭文件)
    with open(file_path, mode, encoding='utf-8') as text_file:
        # 统一转为列表处理
        if isinstance(data_param, set):
            data_param = list(data_param)

        items = data_param if isinstance(data_param, list) else [data_param]

        for one in items:
            if isinstance(one, (list, tuple, set)) and sep_list is not None:
                # 处理内层列表
                line = str(sep_list).join(map(to_str, one))
            else:
                line = to_str(one)

            text_file.write(line + '\n')

    return file_path


def to_print_file(*args,
                  file_dir: str = None,
                  file_name: str = None,
                  with_time_unique_suffix: bool = False,
                  file_name_prefix: str = '',
                  file_name_suffix: str = '',
                  line_with_space_count: int = 0,
                  mode: str = 'a',
                  interval: int = None,
                  fun_name: callable = None) -> str:
    """
    :param file_dir                 : 文件夹名称, 默认 file_dir='to_print_file', file_dir=''表示是同一个文件夹
    :param file_name                : 文件名称
    :param with_time_unique_suffix  : 这个文件名字带一个时间唯一的结尾，
    :param file_name_prefix         : 名字前缀
    :param file_name_suffix         : 名字后缀
    :param line_with_space_count    : 每一行前面加几个空格
    :param mode                     : 写文件的模式, a: 追加
    :param interval                 : 间隔几秒执行 print ,
    用法1:
        to_print_file('test')
        # 在 to_print_file 文件夹下面，生成一个 2026-02-10.txt(按日归档) 文件，
        # test 文本都是往文件中一行一行的追加
        # 无论运行多少次，都是按日归档的，不会生成多个
    用法2:
        to_print_file('test', file_name='a')
        # 在方法1基础上固定了文件名字为 a.txt
    用法3:
        to_print_file(f'test', file_name='a', with_time_unique_suffix=True)
        # 在方法2基础上固定了文件名字为 a_20260211_1103_5080.txt，
        # 每运行一次，生成一个文件名字，如果是循环调用，只有一个名字
    """
    # 1. 动态获取当前函数对象，避免写死
    # 如果外部没传 fun_name，则通过 sys 模块自动获取当前正在执行的函数
    if fun_name is None:
        # 获取当前运行栈的函数名称并尝试从全局命名空间找回函数对象
        current_fun_name = sys._getframe().f_code.co_name
        fun_name = globals().get(current_fun_name, to_print_file)
    # 1. 同步线程上下文参数
    # 注意：确保 context 返回的顺序与 get_and_save_data_to_thread 内部 params_to_track 一致
    context = sync_thread_config(  # 建议使用之前改名后的函数名
        file_dir=file_dir,
        file_name=file_name,
        file_name_prefix=file_name_prefix,
        file_name_suffix=file_name_suffix,
        interval=interval,
        mode=mode,
        with_time_unique_suffix=with_time_unique_suffix,
        line_with_space_count=line_with_space_count,
        fun_name=fun_name
    )

    # 严格对应 params_to_track 的顺序解构
    (f_dir, f_name, f_name_new, f_prefix, f_suffix,
     f_interval, f_space_count, f_use_unique) = context[:8]

    # 2. 核心文件名决策逻辑
    if f_use_unique:
        # 如果开启了唯一后缀，直接使用 get_and_save_data_to_thread 生成好的带时间戳名字
        base_name = f_name_new
    elif f_name:
        # 如果指定了固定文件名，则使用固定名
        base_name = f_name
    else:
        # 默认：按日期归档
        base_name = datetime.today().strftime('%Y-%m-%d')

    # 3. 拼接前后缀
    # 注意：如果 f_use_unique 为 True，通常建议不再加前缀后缀以免名字太乱，或者根据需求保留
    full_file_name = f"{f_prefix or ''}{base_name}{f_suffix or ''}"

    # 4. 确定存储路径
    target_dir = str(f_dir) if f_dir is not None else fun_name.__name__

    # 5. 生成日志内容 (to_print 内部会处理节流和 JSON 转换)
    log_content = to_print(*args, line_with_space_count=f_space_count, interval=f_interval)

    # 6. 持久化到文件
    return to_file(
        data_param=[log_content],
        file_name=full_file_name,
        file_dir=target_dir,
        mode=mode,
        fixed_name=True,
        suffix='.txt'
    )


def to_print_txt(*args,
                 file_dir: str = None,
                 file_name: str = None,
                 with_time_unique_suffix: bool = False,
                 file_name_prefix: str = '',
                 file_name_suffix: str = '',
                 line_with_space_count: int = 0,
                 mode: str = 'a',
                 interval: int = None) -> str:
    return to_print_file(*args,
                         file_dir=file_dir,
                         file_name=file_name,
                         with_time_unique_suffix=with_time_unique_suffix,
                         file_name_prefix=file_name_prefix,
                         file_name_suffix=file_name_suffix,
                         line_with_space_count=line_with_space_count,
                         mode=mode,
                         interval=interval,
                         fun_name=to_print_txt)
