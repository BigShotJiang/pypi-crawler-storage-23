from upplib import *
from upplib.file_to_text import *
from upplib.file_to_text import _check_line_is_startswith_or_endswith_or_contain


def to_list_list(
        list_data: list[str] = None,
        sep_all: str = None,
        sep_line_equal: str = None,
        sep_line_contain: str = None,
        sep_line_startswith: str = None,
        sep_line_endswith: str = None,
        sep_line_with_space_count: int = None,
        sep_line_put_in_front: bool = True,
        sep_every_line: str = None,
        line_join_str: str = None,
        line_is_json: bool = None
) -> list:
    """
    :param list_data                : list 数据
    :param sep_all                  : 分隔符, 所有的分隔符. 将文件转化成一个字符串,然后对这个字符串,再次总体分割 将 list(str) 转化为 str , 然后再次转化成 list(str)
    :param sep_line_equal           : 分隔符, 行分隔符, 这一行是一个分隔符, 分隔符与这行一样, 将 list(str) 转化为 list(list(str))
    :param sep_line_contain         : 分隔符, 行分隔符, 必须包含. 这一行是一个分隔符,包含这个行分隔符的做分割, 将 list(str) 转化为 list(list(str))
    :param sep_line_startswith      : 分隔符, 行分隔符, 必须以什么开头. 这一行是一个分隔符,以这个分隔符作为前缀的, 将 list(str) 转化为 list(list(str))
    :param sep_line_endswith        : 分隔符, 行分隔符, 必须以什么结尾. 这一行是一个分隔符,以这个分隔符作为后缀的, 将 list(str) 转化为 list(list(str))
    :param sep_line_with_space_count: 分隔符, 行分隔符, 必须包含空格的数量, 分隔符是空格的个数, 将 list(str) 转化为 list(list(str))
    :param sep_line_put_in_front    : 分隔符, 行分隔符, 是否在前面, 这一行，分割行，是包含到前面，还是包含到后面
    :param sep_every_line           : 分隔符, 对每一行进行分割,将 list(str) 转化为 list(list(str)), 或者将 list(list(str)) 转化为 list(list(list(str)))
    :param line_join_str            : 行连接符. 将 list(list(str)) 转化成 list(str) 类型的数据
    :param line_is_json             : 是否是 json 格式. 将 list(str) 转化成 list(json) 类型的数据, 会自动过滤掉空格行
    :return:
    """
    if not list_data:
        return []

    # 1. 全局预切分 (将列表合并再按特征全量切分)
    if sep_all is not None:
        list_data = ''.join(list_data).split(str(sep_all))

    # 2. 核心逻辑：行组分割
    # 检查是否启用了任何行分割条件
    has_sep_line = any(x is not None for x in [
        sep_line_equal, sep_line_contain, sep_line_startswith,
        sep_line_endswith, sep_line_with_space_count
    ])

    if has_sep_line:
        grouped_data = []
        current_group = []
        space_counter = 0

        for line in list_data:
            stripped = line.strip()
            # 更新连续空行计数器
            space_counter = (space_counter + 1) if not stripped else 0

            # 命中测试
            is_sep = (
                    (sep_line_equal is not None and line == sep_line_equal) or
                    (sep_line_startswith is not None and _check_line_is_startswith_or_endswith_or_contain(line, sep_line_startswith, 1)) or
                    (sep_line_endswith is not None and _check_line_is_startswith_or_endswith_or_contain(line, sep_line_endswith, 2)) or
                    (sep_line_contain is not None and _check_line_is_startswith_or_endswith_or_contain(line, sep_line_contain, 3)) or
                    (sep_line_with_space_count is not None and space_counter == sep_line_with_space_count)
            )

            if is_sep:
                # 分隔行：放在当前组的末尾
                if sep_line_put_in_front and stripped:
                    current_group.append(line)

                # 提交当前组
                if current_group:
                    grouped_data.append(current_group)
                    current_group = []

                # 分隔行：放在新组的开头
                if not sep_line_put_in_front and stripped:
                    current_group.append(line)

                space_counter = 0  # 触发分割后重置空行计数
            elif stripped:
                # 普通非空行
                current_group.append(line)

        if current_group:
            grouped_data.append(current_group)
        list_data = grouped_data

    # 3. 行内再次分割 (处理嵌套列表或平面列表)
    if sep_every_line is not None:
        s = str(sep_every_line)
        list_data = [
            [sub.split(s) for sub in row] if isinstance(row, list) else row.split(s)
            for row in list_data
        ]

    # 4. 数据转换 (JSON 解析 或 Join 合并)
    join_char = line_join_str if line_join_str is not None else ""

    if line_is_json:
        # 注意：此处只对 list(list(str)) 结构的内层进行合并解析
        list_data = [
            json.loads(join_char.join(row))
            for row in list_data if row
        ]
    elif line_join_str is not None:
        list_data = [join_char.join(row) for row in list_data]

    return list_data


def list_split_list(list_data: list[str] = None,
                    count: int = None) -> list[list[str]]:
    """
    将 list 按固定数量 count 切分为 list(list)
    """
    if not list_data or count is None or count <= 0:
        return []

    # 使用 Python 切片步长特性，直接生成分片
    return [list_data[i: i + count] for i in range(0, len(list_data), count)]


def to_list_list_from_file_use_blank_line(file_name: str = 'a.txt') -> list:
    """
    将一个文件中以空行作为分隔符,
    组成一个 list(list) 数据
    多行空行,自动合并到一行空行
    """
    return to_list_list(to_list_from_file(file_name), sep_line_equal='')


def list_group_by(data_list: list[list],
                  group_by_index: int = 0) -> list[list[list]]:
    """
    将一个 list 分组
    例如:
    data_list = [
        ['a', 1, 2],
        ['b', 4, 5],
        ['c', 2, 1],
        ['c', 6, 2],
        ['c', 4, 0],
        ['b', 1, 3]
    ]
    返回:
    [
        [
            ['a', 1, 2]
        ],
        [
            ['b', 4, 5], ['b', 1, 3]],
        [
            ['c', 2, 1], ['c', 6, 2], ['c', 4, 0]
        ]
    ]
    """
    groups = defaultdict(list)
    for item in data_list:
        key = item[group_by_index]
        groups[key].append(item)
    r_list = []
    for key, group in groups.items():
        r_list.append(group)
    return r_list
