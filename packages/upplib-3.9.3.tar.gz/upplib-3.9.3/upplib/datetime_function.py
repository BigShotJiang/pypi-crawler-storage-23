from upplib import *
from datetime import datetime, timezone, timedelta, tzinfo
from typing import Any, Optional, Union
import zoneinfo  # Python 3.9+
from dateutil import parser  # 强烈建议安装: pip install python-dateutil
from upplib.common_package import *


def get_tz(tz_info: Union[str, timezone]) -> timezone | tzinfo | None:
    """将时区字符串或对象统一转换为 timezone 对象"""
    if tz_info is None:
        return None
    if isinstance(tz_info, timezone):
        return tz_info
    if not isinstance(tz_info, str):
        raise TypeError(f"预期 str 或 timezone，实际得到: {type(tz_info)}")
    # 1. 优先尝试 IANA 命名解析 (例如: 'Asia/Shanghai', 'UTC', 'America/New_York')
    try:
        # zoneinfo 能处理标准名称，但不能直接转为 timezone 对象，需通过 dummy datetime 转换
        from datetime import datetime
        return datetime.now(zoneinfo.ZoneInfo(tz_info)).tzinfo
    except (zoneinfo.ZoneInfoNotFoundError, ValueError):
        pass

    # 2. 处理偏移格式 (支持 +08:00, -0530, UTC+8, GMT-5)
    # 统一提取符号和数值部分
    cleaned_tz = tz_info.upper().replace("GMT", "").replace("UTC", "").strip()

    # 匹配 [+-]HH[:][MM] 格式
    match = re.match(r"^([+-])(\d{1,2}):?(\d{2})?$", cleaned_tz)
    if match:
        sign, hh, mm = match.groups()
        total_minutes = int(hh) * 60 + (int(mm) if mm else 0)
        offset = timedelta(minutes=total_minutes if sign == "+" else -total_minutes)
        return timezone(offset)

    raise ValueError(f"无法识别的时区格式: {tz_info}")


def to_datetime(s: Any = None,
                param_pattern: str = None,
                param_tz: Union[str, timezone] = None,
                default_tz: Union[str, timezone] = '+08:00',
                result_is_str: bool = False,
                result_tz: Optional[Union[str, timezone]] = None,
                error_is_none: bool = False) -> Union[datetime, str, None]:
    """
    更健壮的日期转换工具。
    s               : 输入值（可以是字符串或其他类型）
    param_pattern   : 入参的格式类型
    param_tz        : 入参的时区
    result_is_str   : 结果是字符串
    result_tz       : 结果的时区，也就是目标时区
    error_is_none   : 当报错的时候，是否返回 None，如果不是 None，那就给当前时间
    default_tz      : 默认时区，当 param_tz 为空的时候，使用默认时区， 当 result_tz 为空的时候，使用默认时区
    """
    if default_tz is not None:
        param_tz = default_tz if param_tz is None else param_tz
        result_tz = default_tz if result_tz is None else result_tz
    result_target_tz = get_tz(result_tz) if result_tz else None
    p_tz = get_tz(param_tz) if param_tz else get_tz(default_tz)

    # 1. 处理空值
    if s is None or s == '':
        dt = datetime.now(p_tz)
        return dt.isoformat() if result_is_str else dt

    try:
        s_str = str(s).strip()
        dt = None

        # 2. 尝试解析时间戳 (10位或13位)
        if re.match(r"^\d{10,13}$", s_str):
            ts = int(s_str)
            dt = datetime.fromtimestamp(ts / 1000 if ts > 2e10 else ts, tz=p_tz)

        # 3. 尝试使用用户定义的 param_pattern
        elif param_pattern:
            dt = datetime.strptime(s_str, param_pattern).replace(tzinfo=p_tz)

        # 4. 自动解析 (处理 ISO8601, GMT, YYYY/MM/DD 等混合格式)
        else:
            # dateutil.parser 几乎能处理所有你写的正则情况，包括 GMT+08:00
            dt = parser.parse(s_str)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=p_tz)

        # 5. 时区转换
        if result_target_tz:
            dt = dt.astimezone(result_target_tz)

        return dt.isoformat() if result_is_str else dt

    except Exception:
        return None if error_is_none else (datetime.now(p_tz).isoformat() if result_is_str else datetime.now(p_tz))


# 将字符串 s 转化成 datetime, 然后再次转化成 str
def to_datetime_str(s: Any = None,
                    param_pattern: str = None,
                    pattern_str: str = None,
                    param_tz: Optional[Union[str, timezone]] = None,
                    default_tz: Optional[Union[str, timezone]] = '+08:00',
                    result_tz: Union[str, timezone] = None) -> datetime | str:
    """
    将 s 先转成 datetime, 然后再转成字符串
    """
    r_s = to_datetime(s, param_pattern=param_pattern, param_tz=param_tz, default_tz=default_tz, result_is_str=False, result_tz=result_tz)
    if pattern_str is None:
        iso_str = r_s.isoformat()
        if '.' not in iso_str:
            # '2025-10-09T10:52:41+08:00'
            return iso_str
        parts = iso_str.split('.')
        time_zone_part = parts[1]
        time_zone_str = param_tz
        millisecond_part = time_zone_part[:3]
        for a in ['+', '-']:
            if a in time_zone_part:
                time_zone_str = a + time_zone_part.split(a)[-1]
        return parts[0] + '.' + millisecond_part + time_zone_str
    else:
        return r_s.strftime(pattern_str)


def to_datetime_format(s: Any = None,
                       pattern_str: str = "%Y-%m-%d %H:%M:%S") -> datetime | str:
    return to_datetime_str(s, param_pattern=None, pattern_str=pattern_str, param_tz=None)


def to_datetime_format__6(s: Any = None,
                          pattern_str: str = "%Y-%m-%d %H:%M:%S") -> datetime | str:
    return to_datetime_str(s, param_pattern=None, pattern_str=pattern_str, param_tz='-06:00')


def to_datetime_format_7(s: Any = None,
                         pattern_str: str = "%Y-%m-%d %H:%M:%S") -> datetime | str:
    return to_datetime_str(s, param_pattern=None, pattern_str=pattern_str, param_tz='+07:00')


def to_datetime_format_8(s: Any = None,
                         pattern_str: str = "%Y-%m-%d %H:%M:%S") -> datetime | str:
    return to_datetime_str(s, param_pattern=None, pattern_str=pattern_str, param_tz='+08:00')


# 时间加减
def to_datetime_add(s: Any = None,
                    days: int = 0,
                    seconds: int = 0,
                    microseconds: int = 0,
                    milliseconds: int = 0,
                    minutes: int = 0,
                    hours: int = 0,
                    weeks: int = 0) -> datetime:
    return to_datetime(s) + timedelta(days=days, seconds=seconds, microseconds=microseconds,
                                      milliseconds=milliseconds, minutes=minutes, hours=hours,
                                      weeks=weeks)


# 将字符串 s 转化成 date 例如: 2021-02-03
def to_date(s: Any = None) -> str:
    return str(to_datetime(s, result_is_str=True))[0:10]


# 将字符串 s 转化成 date 例如: 20210203
def to_date_number(s: Any = None) -> str:
    return to_date(s).replace('-', '')


def get_timestamp(s: Any = None) -> int:
    """获取 Unix 秒级时间戳"""
    return int(to_datetime(s).timestamp())


def get_datetime_number_str(s: Any = None,
                            pattern: str = '%Y%m%d%H%M%S%f',
                            length: int = None,
                            remove_dz: bool = True) -> str:
    """
    获取 datetime 并转为纯数字字符串。
    """
    dt = to_datetime(s)

    # 1. 自动处理逻辑冲突：如果用户自定义了 pattern 且不含 %f，则不应强制执行 remove_dz 的切片
    actual_pattern = pattern
    if remove_dz and '%f' in pattern:
        actual_pattern = pattern.replace('%f', '')  # 直接从格式化层面去掉微秒

    digits_only = dt.strftime(actual_pattern)

    # 2. 如果 pattern 本身不是纯数字格式（虽然函数名叫 number_str），仍做一次清洗
    digits_only = re.sub(r'\D', '', digits_only)

    # 3. 截取长度
    if length and length > 0:
        digits_only = digits_only[-length:]

    return digits_only


def get_month_day_number_str(s: Any = None) -> str:
    """获取日期的月日部分（例如：0520）"""
    return get_datetime_number_str(s, pattern='%m%d')


# 测试
# print(get_datetime_number_str())  # 默认：年月日时分秒 (20240520101010)
# print(get_datetime_number_str(pattern='%m%d'))  # 结果：0520 (不会被 remove_dz 切空)
# print(get_datetime_number_str(remove_dz=False))  # 结果：带微秒的 20 位数字


def get_timestamp_ms(s: Any = None) -> int:
    """获取 Unix 毫秒级时间戳"""
    return int(to_datetime(s).timestamp() * 1000)


# 时间加减
def to_date_add(s: Any = None,
                days: int = 0,
                seconds: int = 0,
                microseconds: int = 0,
                milliseconds: int = 0,
                minutes: int = 0,
                hours: int = 0,
                weeks: int = 0) -> str:
    return str(to_datetime_add(s=s, days=days, seconds=seconds, microseconds=microseconds,
                               milliseconds=milliseconds, minutes=minutes, hours=hours, weeks=weeks))[0:10]
