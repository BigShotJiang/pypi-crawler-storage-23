def if_none_default(obj,default):
    if obj is None:
        obj =default
    return obj
