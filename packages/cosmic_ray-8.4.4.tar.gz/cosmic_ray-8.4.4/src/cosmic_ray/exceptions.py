class CosmicRayTestingException(Exception):
    """Exception that we use for exception replacement."""

    pass
