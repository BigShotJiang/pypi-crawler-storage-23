"""bitHuman Runtime exception hierarchy.

Provides domain-specific exceptions so callers can handle token errors,
model loading errors, and account issues without fragile string matching.
"""


class BithumanError(Exception):
    """Base exception for all bitHuman Runtime errors."""


class TokenError(BithumanError):
    """Base exception for token-related errors."""


class TokenExpiredError(TokenError):
    """Raised when the JWT token has expired."""


class TokenValidationError(TokenError):
    """Raised when token validation fails (invalid signature, claims, etc.)."""


class TokenRequestError(TokenError):
    """Raised when a token request to the auth server fails."""


class AccountStatusError(TokenError):
    """Raised when the account has a billing/access issue (402, 403)."""


class ModelError(BithumanError):
    """Base exception for model-related errors."""


class ModelNotFoundError(ModelError):
    """Raised when the model file cannot be found."""


class ModelLoadError(ModelError):
    """Raised when model loading fails."""


class ModelSecurityError(ModelError):
    """Raised when a security restriction blocks model operations."""


class RuntimeNotReadyError(BithumanError):
    """Raised when an operation is attempted before the runtime is ready."""
