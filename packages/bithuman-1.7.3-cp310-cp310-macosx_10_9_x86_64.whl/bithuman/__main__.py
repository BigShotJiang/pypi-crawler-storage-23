"""bithuman CLI: python -m bithuman <command>"""
import sys
from .cli import main

sys.exit(main())
