"""Live streaming server for bithuman avatars.

Serves MJPEG video stream of an animated avatar with full motion graph
(idle, talking, transitions). Audio can be sent via POST /speak to
drive lip-sync animation. Video actions can be triggered via POST /action.

Usage (via CLI):
    bithuman stream model.imx --key YOUR_API_KEY --port 3001
    bithuman speak hello.wav --port 3001
    bithuman action wave --port 3001
"""
from __future__ import annotations

import asyncio
import os
import tempfile
from typing import Optional, Set

import cv2
from aiohttp import web
from loguru import logger

from .api import VideoControl
from .audio.utils import float32_to_int16, load_audio
from .runtime_async import AsyncBithuman
from .utils.fps_controller import FPSController

_INDEX_HTML = """\
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>bitHuman Avatar</title>
<style>
* { margin: 0; padding: 0; }
body {
    background: #000;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100vw;
    height: 100vh;
}
img {
    max-width: 100vw;
    max-height: 100vh;
    object-fit: contain;
}
#unmute {
    position: fixed; top: 16px; right: 16px; z-index: 10;
    background: rgba(255,255,255,0.15); color: #fff; border: 1px solid rgba(255,255,255,0.3);
    border-radius: 8px; padding: 8px 16px; cursor: pointer; font: 14px sans-serif;
    backdrop-filter: blur(8px);
}
#unmute:hover { background: rgba(255,255,255,0.25); }
#unmute.hidden { display: none; }
</style>
</head>
<body>
<img src="/stream" alt="bitHuman Avatar Stream">
<button id="unmute">Click to enable audio</button>
<script>
(function() {
    const SR = 16000;
    let ctx, started = false, nextTime = 0;

    function initAudio() {
        if (started) return;
        ctx = new AudioContext({ sampleRate: SR });
        started = true;
        document.getElementById('unmute').classList.add('hidden');
        connectWS();
    }

    document.getElementById('unmute').addEventListener('click', initAudio);

    function connectWS() {
        const ws = new WebSocket('ws://' + location.host + '/ws/audio');
        ws.binaryType = 'arraybuffer';
        ws.onmessage = function(e) {
            if (!ctx || ctx.state === 'closed') return;
            const int16 = new Int16Array(e.data);
            const float32 = new Float32Array(int16.length);
            for (let i = 0; i < int16.length; i++) float32[i] = int16[i] / 32768;

            const buf = ctx.createBuffer(1, float32.length, SR);
            buf.getChannelData(0).set(float32);
            const src = ctx.createBufferSource();
            src.buffer = buf;
            src.connect(ctx.destination);

            const now = ctx.currentTime;
            if (nextTime < now) nextTime = now;
            src.start(nextTime);
            nextTime += buf.duration;
        };
        ws.onclose = function() { setTimeout(connectWS, 1000); };
    }
})();
</script>
</body>
</html>
"""


class StreamServer:
    """MJPEG streaming server backed by AsyncBithuman runtime.

    Loads an .imx model, runs the avatar indefinitely (idle + talking),
    and serves video frames as an MJPEG stream over HTTP.  Audio can be
    pushed via POST /speak to drive lip-sync animation.
    """

    def __init__(
        self,
        model_path: str,
        api_key: str = "",
        *,
        host: str = "0.0.0.0",
        port: int = 3001,
        jpeg_quality: int = 80,
    ) -> None:
        self.model_path = model_path
        self.api_key = api_key
        self.host = host
        self.port = port
        self.jpeg_quality = jpeg_quality

        self._runtime: Optional[AsyncBithuman] = None

        # Frame broadcast state
        self._current_frame: Optional[bytes] = None
        self._frame_counter: int = 0
        self._condition: Optional[asyncio.Condition] = None

        # Audio WebSocket clients
        self._audio_clients: Set[web.WebSocketResponse] = set()

        # FPS pacing
        self._fps = FPSController(target_fps=25)

    # ------------------------------------------------------------------
    # Runtime & frame producer
    # ------------------------------------------------------------------

    async def _init_runtime(self) -> None:
        self._runtime = await AsyncBithuman.create(
            model_path=self.model_path,
            api_secret=self.api_key,
        )

        # Tune idle behavior for live streaming preview.
        # Cycle: talking (idle 5-15s) → random action → talking → ...
        script = self._runtime.video_graph.videos_script
        script.BACK_TO_IDLE = 2
        for action in script.idle_actions:
            action.interval = (5.0, 15.0)
        script.set_next_idle_action()

        await self._runtime.start()

    async def _frame_producer(self) -> None:
        """Consume frames from runtime, JPEG-encode, broadcast to clients."""
        encode_params = [cv2.IMWRITE_JPEG_QUALITY, self.jpeg_quality]

        async for frame in self._runtime.run():
            if frame.bgr_image is None:
                continue

            ok, buf = cv2.imencode(".jpg", frame.bgr_image, encode_params)
            if not ok:
                continue

            async with self._condition:
                self._current_frame = buf.tobytes()
                self._frame_counter += 1
                self._condition.notify_all()

            # Broadcast audio to WebSocket clients
            if frame.audio_chunk is not None and self._audio_clients:
                pcm_bytes = frame.audio_chunk.data.tobytes()
                dead = set()
                for ws in self._audio_clients:
                    try:
                        await ws.send_bytes(pcm_bytes)
                    except (ConnectionResetError, asyncio.CancelledError):
                        dead.add(ws)
                self._audio_clients -= dead

            # Pace to 25 FPS
            sleep_time = self._fps.wait_next_frame(sleep=False)
            if sleep_time > 0:
                await asyncio.sleep(sleep_time)
            self._fps.update()

    # ------------------------------------------------------------------
    # HTTP handlers
    # ------------------------------------------------------------------

    async def _handle_index(self, request: web.Request) -> web.Response:
        """GET / — fullscreen HTML viewer."""
        return web.Response(text=_INDEX_HTML, content_type="text/html")

    async def _handle_stream(self, request: web.Request) -> web.StreamResponse:
        """GET /stream — MJPEG multipart stream."""
        boundary = "frame"
        response = web.StreamResponse(
            headers={
                "Content-Type": f"multipart/x-mixed-replace; boundary={boundary}",
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Connection": "close",
            },
        )
        await response.prepare(request)

        last_seen = 0
        try:
            while True:
                async with self._condition:
                    await self._condition.wait_for(
                        lambda: self._frame_counter > last_seen
                    )
                    jpeg_bytes = self._current_frame
                    last_seen = self._frame_counter

                header = (
                    f"--{boundary}\r\n"
                    f"Content-Type: image/jpeg\r\n"
                    f"Content-Length: {len(jpeg_bytes)}\r\n"
                    f"\r\n"
                ).encode()
                await response.write(header + jpeg_bytes + b"\r\n")
        except (ConnectionResetError, asyncio.CancelledError):
            pass

        return response

    async def _handle_speak(self, request: web.Request) -> web.Response:
        """POST /speak — accept audio file, feed to runtime for lip-sync."""
        if self._runtime is None:
            return web.json_response({"error": "Runtime not initialized"}, status=503)

        body = await request.read()
        if not body:
            return web.json_response({"error": "Empty request body"}, status=400)

        content_type = request.content_type or ""
        suffix = ".wav"
        if "mp3" in content_type or "mpeg" in content_type:
            suffix = ".mp3"
        elif "ogg" in content_type:
            suffix = ".ogg"
        elif "flac" in content_type:
            suffix = ".flac"

        try:
            fd, tmp_path = tempfile.mkstemp(suffix=suffix)
            try:
                os.write(fd, body)
                os.close(fd)
                audio_float, sample_rate = load_audio(tmp_path, target_sr=16000)
            finally:
                os.unlink(tmp_path)

            audio_int16 = float32_to_int16(audio_float)
            duration = len(audio_int16) / sample_rate

            # Stream audio to runtime in FPS-aligned chunks
            chunk_size = sample_rate // 25  # 640 samples @ 16kHz
            for i in range(0, len(audio_int16), chunk_size):
                chunk = audio_int16[i : i + chunk_size]
                await self._runtime.push_audio(
                    chunk.tobytes(), sample_rate, last_chunk=False
                )

            await self._runtime.flush()

            return web.json_response({
                "status": "ok",
                "duration_seconds": round(duration, 2),
                "samples": len(audio_int16),
            })

        except Exception as e:
            logger.error(f"Error processing audio: {e}")
            return web.json_response({"error": str(e)}, status=500)

    async def _handle_ws_audio(self, request: web.Request) -> web.WebSocketResponse:
        """WS /ws/audio — stream audio PCM int16 to browser."""
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        self._audio_clients.add(ws)
        try:
            async for _ in ws:
                pass  # Client doesn't send anything; just keep alive
        finally:
            self._audio_clients.discard(ws)
        return ws

    async def _handle_action(self, request: web.Request) -> web.Response:
        """POST /action — immediately play a video action or switch target video.

        JSON body:
            {"action": "wave"}              — play a single action video
            {"action": ["wave", "nod"]}     — play a sequence of action videos
            {"target_video": "talking_happy"} — switch to a different talking video
            {"action": "wave", "target_video": "talking_happy"} — both
        """
        if self._runtime is None:
            return web.json_response({"error": "Runtime not initialized"}, status=503)

        try:
            body = await request.json()
        except Exception:
            return web.json_response(
                {"error": "Invalid JSON body. Expected: {\"action\": \"name\"} or {\"target_video\": \"name\"}"},
                status=400,
            )

        action = body.get("action")
        target_video = body.get("target_video")

        if not action and not target_video:
            return web.json_response(
                {"error": "Provide 'action' and/or 'target_video'"},
                status=400,
            )

        # Validate video names against loaded model
        graph = self._runtime.video_graph
        available = list(graph.clips.keys())

        if action:
            names = action if isinstance(action, list) else [action]
            for name in names:
                if name not in graph.clips:
                    return web.json_response(
                        {"error": f"Unknown video '{name}'", "available": available},
                        status=404,
                    )

        if target_video and target_video not in graph.clips:
            return web.json_response(
                {"error": f"Unknown video '{target_video}'", "available": available},
                status=404,
            )

        control = VideoControl(action=action, target_video=target_video, force_action=True)
        await self._runtime.push(control)

        result = {"status": "playing"}
        if action:
            result["action"] = action
        if target_video:
            result["target_video"] = target_video
        return web.json_response(result)

    async def _handle_videos(self, request: web.Request) -> web.Response:
        """GET /videos — list available videos in the loaded model."""
        if self._runtime is None:
            return web.json_response({"error": "Runtime not initialized"}, status=503)

        graph = self._runtime.video_graph
        script = graph.videos_script

        videos = []
        for clip in graph.clips.values():
            videos.append({
                "name": clip.name,
                "type": "looping" if clip.loop else "action",
                "frames": clip.num_frames,
                "lip_sync": clip.lip_sync,
            })

        result = {
            "default_video": script.default_video,
            "idle_video": script.idle_video,
            "videos": videos,
        }
        return web.json_response(result)

    async def _handle_health(self, request: web.Request) -> web.Response:
        """GET /health — simple health check."""
        return web.json_response({"status": "ok"})

    # ------------------------------------------------------------------
    # Server lifecycle
    # ------------------------------------------------------------------

    async def _on_startup(self, app: web.Application) -> None:
        self._condition = asyncio.Condition()
        await self._init_runtime()
        app["frame_producer"] = asyncio.create_task(self._frame_producer())
        port_flag = f" --port {self.port}" if self.port != 3001 else ""
        print(f"\n  Model loaded! Streaming at http://localhost:{self.port}")
        print(f"  Open browser:  http://localhost:{self.port}")
        print(f"  Send audio:    bithuman speak <audio.wav>{port_flag}")
        print(f"  Trigger action: bithuman action <name>{port_flag}")
        print(f"  Health check:  curl http://localhost:{self.port}/health")
        print(f"\n  Press Ctrl+C to stop.")
        print(f"  {'─' * 41}")

    async def _on_cleanup(self, app: web.Application) -> None:
        task = app.get("frame_producer")
        if task:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        if self._runtime:
            await self._runtime.stop()

    def create_app(self) -> web.Application:
        app = web.Application(client_max_size=100 * 1024 * 1024)
        app.router.add_get("/", self._handle_index)
        app.router.add_get("/stream", self._handle_stream)
        app.router.add_post("/speak", self._handle_speak)
        app.router.add_post("/action", self._handle_action)
        app.router.add_get("/videos", self._handle_videos)
        app.router.add_get("/ws/audio", self._handle_ws_audio)
        app.router.add_get("/health", self._handle_health)
        app.on_startup.append(self._on_startup)
        app.on_cleanup.append(self._on_cleanup)
        return app

    async def run_async(self) -> None:
        """Start the server. Blocks until cancelled."""
        app = self.create_app()
        runner = web.AppRunner(app)
        await runner.setup()
        try:
            site = web.TCPSite(runner, self.host, self.port)
            await site.start()
            await asyncio.Event().wait()
        finally:
            await runner.cleanup()
