"""Image operations — replaces image_ops.cpp (SSE2 blend + bilinear resize).

Blend uses vectorized numpy uint16 arithmetic with exact div255 formula.
Resize delegates to cv2.resize (IPP/SIMD-optimized internally).
"""

from __future__ import annotations

import numpy as np
import cv2


# ---------------------------------------------------------------------------
# Blend
# ---------------------------------------------------------------------------
def _blend_numpy(
    frame: np.ndarray,
    lip: np.ndarray,
    mask: np.ndarray,
    roi_x: int,
    roi_y: int,
    roi_h: int,
    roi_w: int,
) -> None:
    """Vectorized numpy blend with exact div255 formula."""
    roi = frame[roi_y : roi_y + roi_h, roi_x : roi_x + roi_w]

    # Ensure mask is 3-channel
    if mask.ndim == 2:
        m = mask[:, :, np.newaxis].astype(np.uint16)
    elif mask.ndim == 3 and mask.shape[2] == 1:
        m = mask.astype(np.uint16)
    else:
        m = mask.astype(np.uint16)

    # Broadcast to 3 channels if needed
    if m.shape[2] == 1:
        m = np.broadcast_to(m, roi.shape).copy()

    im = np.uint16(255) - m
    val = lip[:roi_h, :roi_w].astype(np.uint16) * m + roi.astype(np.uint16) * im
    # div255: (val + 1 + ((val + 1) >> 8)) >> 8
    val_p1 = val + np.uint16(1)
    result = ((val_p1 + (val_p1 >> 8)) >> 8).astype(np.uint8)
    frame[roi_y : roi_y + roi_h, roi_x : roi_x + roi_w] = result


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def blend_face_region(
    frame: np.ndarray,
    roi_x: int,
    roi_y: int,
    roi_w: int,
    roi_h: int,
    lip: np.ndarray,
    mask: np.ndarray,
) -> None:
    """Alpha-blend lip overlay into face region of frame (in-place).

    Matches image_ops.cpp blend_face_region (lines 429-503):
    Formula per byte: out = div255(lip * mask + face * (255 - mask))
    where div255(x) = (x + 1 + ((x + 1) >> 8)) >> 8

    Args:
        frame: (H, W, 3) uint8 BGR — modified in-place.
        roi_x, roi_y: top-left corner of face region in frame.
        roi_w, roi_h: dimensions of face region.
        lip: (roi_h, roi_w, 3) uint8 BGR lip overlay.
        mask: (roi_h, roi_w, 1) or (roi_h, roi_w, 3) uint8 blend mask.
    """
    _blend_numpy(frame, lip, mask, roi_x, roi_y, roi_h, roi_w)


def resize_image(image: np.ndarray, new_width: int, new_height: int) -> np.ndarray:
    """Resize using OpenCV (IPP/SIMD optimized).

    Uses INTER_NEAREST for near-identity scales (< 5% change) which is
    significantly faster than bilinear and visually indistinguishable.
    """
    if image.size == 0:
        return image
    h, w = image.shape[:2]
    if w == new_width and h == new_height:
        return image
    scale = new_width / w if w > 0 else 1.0
    interp = cv2.INTER_NEAREST if 0.95 <= scale <= 1.05 else cv2.INTER_LINEAR
    return cv2.resize(image, (new_width, new_height), interpolation=interp)


def resize_image_scale(image: np.ndarray, scale: float) -> np.ndarray:
    """Resize by scale factor. Replaces resize_image_scale in C++."""
    if scale == 1.0 or image.size == 0:
        return image
    new_w = round(image.shape[1] * scale)
    new_h = round(image.shape[0] * scale)
    return resize_image(image, new_w, new_h)
