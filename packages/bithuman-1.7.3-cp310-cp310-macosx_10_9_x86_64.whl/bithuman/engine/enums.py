"""Pure Python enums replacing pybind11-exported C++ enums."""

from enum import IntEnum


class CompressionType(IntEnum):
    NONE = 0
    JPEG = 1
    LZ4 = 2
    TEMP_FILE = 3


class LoadingMode(IntEnum):
    SYNC = 0
    ASYNC = 1
    ON_DEMAND = 2
