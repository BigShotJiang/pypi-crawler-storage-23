"""Video decoding with PyAV — replaces video_decode.cpp.

Handles regular video files and XOR-encrypted .bhtensor files.
"""

from __future__ import annotations

import fnmatch
import io
import json
import struct
import threading
from typing import Dict, Iterator, List, Optional, Tuple

import numpy as np

ENCRYPT_KEY = b"bithuman_video_data_key"  # 26 bytes — matches C++ video_data_key


# IMX binary container format constants (v2)
IMX_MAGIC = b"IMX\x00"
IMX_VERSION = 2

# Old IMX v1 magic — used only for detection and upgrade messaging
_OLD_IMX_V1_MAGIC = b"BIMX"


def is_encrypted_file(path: str) -> bool:
    """Check if file is encrypted based on extension.

    Matches video_decode.cpp isEncryptedFile.
    """
    return path.endswith(".bhtensor")


def xor_decrypt_bytes(data: bytes, key: bytes = ENCRYPT_KEY) -> bytes:
    """XOR-decrypt data in-place style, returning a new bytes object.

    Matches video_decode.cpp decryptDataInPlace: byte-wise XOR with repeating key.
    Uses numpy for vectorized XOR (much faster than Python byte loop).
    """
    key_len = len(key)
    data_arr = np.frombuffer(data, dtype=np.uint8).copy()
    key_arr = np.frombuffer(key, dtype=np.uint8)

    # Tile key to match data length and XOR
    full_key = np.tile(key_arr, len(data_arr) // key_len + 1)[: len(data_arr)]
    data_arr ^= full_key
    return data_arr.tobytes()


def _write_xor_encrypted(
    f, file_offset: int, data: bytes, key: bytes
) -> None:
    """XOR-encrypt data at the correct key position and write to file.

    This enables streaming writes without building the entire encrypted file
    in memory. The key cycles correctly from the given file offset.
    """
    key_len = len(key)
    key_start = file_offset % key_len
    data_arr = np.frombuffer(data, dtype=np.uint8)
    key_arr = np.frombuffer(key, dtype=np.uint8)
    indices = np.arange(key_start, key_start + len(data)) % key_len
    f.write((data_arr ^ key_arr[indices]).tobytes())


def read_and_decrypt_file(path: str, key: bytes = ENCRYPT_KEY) -> bytes:
    """Read file and XOR-decrypt its contents.

    Matches video_decode.cpp readAndDecryptFile.
    """
    with open(path, "rb") as f:
        data = f.read()
    return xor_decrypt_bytes(data, key)


class VideoReader:
    """PyAV-based video reader replacing FFmpeg C wrapper.

    Decodes all frames into memory for random access. Avatar data videos
    are typically small, so this is acceptable and matches SYNC loading.

    For encrypted .bhtensor files, the file is fully decrypted into memory
    then passed to PyAV via BytesIO.
    """

    def __init__(
        self,
        video_path: str,
        key: str = "",
        thread_count: int = 0,
    ) -> None:
        import av

        self._path = video_path
        self._is_encrypted = is_encrypted_file(video_path)

        # Open container
        if self._is_encrypted:
            decrypt_key = key.encode("utf-8") if key else ENCRYPT_KEY
            decrypted = read_and_decrypt_file(video_path, decrypt_key)
            self._container = av.open(io.BytesIO(decrypted))
        else:
            self._container = av.open(video_path)

        stream = self._container.streams.video[0]
        stream.thread_type = "AUTO"

        self._width: int = stream.codec_context.width
        self._height: int = stream.codec_context.height

        # Decode all frames into memory for random access
        self._frames: List[np.ndarray] = []
        self._container.seek(0)
        for frame in self._container.decode(video=0):
            bgr = frame.to_ndarray(format="bgr24")
            self._frames.append(bgr)

        self._frame_count = len(self._frames)

    def get(self, index: int) -> np.ndarray:
        """Get a decoded frame by index (returns a copy).

        Matches VideoReader::get in video_decode.cpp.
        """
        if index < 0:
            index = self._frame_count + index
        if index < 0 or index >= self._frame_count:
            raise IndexError(
                f"Frame index {index} out of range [0, {self._frame_count})"
            )
        return self._frames[index].copy()

    def size(self) -> int:
        """Return total number of decoded frames."""
        return self._frame_count

    @property
    def width(self) -> int:
        return self._width

    @property
    def height(self) -> int:
        return self._height

    def close(self) -> None:
        if self._container:
            self._container.close()
            self._container = None


def _streaming_xor_decrypt_file(
    src_path: str, dst_path: str, key: bytes, chunk_size: int = 256 * 1024
) -> None:
    """XOR-decrypt a file to another file in streaming chunks.

    Unlike read_and_decrypt_file() which loads the entire file into memory,
    this processes the file in fixed-size chunks.  Peak memory is one chunk
    (~256 KB) regardless of file size.
    """
    key_len = len(key)
    key_arr = np.frombuffer(key, dtype=np.uint8)
    with open(src_path, "rb") as src, open(dst_path, "wb") as dst:
        offset = 0
        while True:
            chunk = src.read(chunk_size)
            if not chunk:
                break
            data_arr = np.frombuffer(chunk, dtype=np.uint8).copy()
            indices = np.arange(offset % key_len, offset % key_len + len(chunk)) % key_len
            data_arr ^= key_arr[indices]
            dst.write(data_arr.tobytes())
            offset += len(chunk)


def compute_mask_bbox(
    h5_data,
    frame_w: int,
    frame_h: int,
    padding: int = 16,
) -> Tuple[int, int, int, int]:
    """Compute the union bounding box of non-zero face mask pixels.

    Scans all face masks in the HDF5 data to find the tightest region
    that contains all non-zero mask pixels, with padding applied.

    Args:
        h5_data: File path (str) or BytesIO containing HDF5 data.
        frame_w: Frame width for clamping.
        frame_h: Frame height for clamping.
        padding: Pixels of padding around the bounding box.

    Returns:
        (x1, y1, x2, y2) bounding box with padding applied.
    """
    from .compression import decode_jpeg

    import h5py

    global_x1, global_y1 = frame_w, frame_h
    global_x2, global_y2 = 0, 0

    with h5py.File(h5_data, "r") as f:
        masks_ds = f["face_masks"]
        num_masks = len(masks_ds)

        for i in range(num_masks):
            mask_bytes = bytes(masks_ds[i])
            if not mask_bytes:
                continue

            mask_img = decode_jpeg(mask_bytes)
            gray = np.max(mask_img, axis=2)
            nonzero = gray > 0

            if not np.any(nonzero):
                continue

            rows = np.any(nonzero, axis=1)
            cols = np.any(nonzero, axis=0)
            y_indices = np.where(rows)[0]
            x_indices = np.where(cols)[0]

            global_x1 = min(global_x1, int(x_indices[0]))
            global_y1 = min(global_y1, int(y_indices[0]))
            global_x2 = max(global_x2, int(x_indices[-1]) + 1)
            global_y2 = max(global_y2, int(y_indices[-1]) + 1)

    if global_x2 <= global_x1 or global_y2 <= global_y1:
        raise RuntimeError("No non-zero mask pixels found")

    global_x1 = max(0, global_x1 - padding)
    global_y1 = max(0, global_y1 - padding)
    global_x2 = min(frame_w, global_x2 + padding)
    global_y2 = min(frame_h, global_y2 + padding)

    return (global_x1, global_y1, global_x2, global_y2)


def iter_video_frames(
    video_path: str,
    key: str = "",
    thread_count: int = 0,
    max_frames: int = -1,
) -> Iterator[np.ndarray]:
    """Yield decoded BGR24 frames one at a time from a video file.

    Unlike VideoReader (which decodes all frames into memory), this function
    yields frames sequentially and discards each one after yielding. Peak
    memory is ~1 frame instead of all frames.

    Args:
        video_path: Path to video file (.mp4 or .bhtensor).
        key: Decryption key for .bhtensor files. Empty string uses default.
        thread_count: Unused (kept for API symmetry with VideoReader).
        max_frames: Maximum number of frames to yield. -1 means all frames.

    Yields:
        BGR24 numpy arrays of shape (height, width, 3).
    """
    import av

    encrypted = is_encrypted_file(video_path)

    if encrypted:
        decrypt_key = key.encode("utf-8") if key else ENCRYPT_KEY
        decrypted = read_and_decrypt_file(video_path, decrypt_key)
        container = av.open(io.BytesIO(decrypted))
    else:
        container = av.open(video_path)

    try:
        stream = container.streams.video[0]
        stream.thread_type = "AUTO"
        container.seek(0)
        count = 0
        for frame in container.decode(video=0):
            if 0 <= max_frames <= count:
                break
            yield frame.to_ndarray(format="bgr24")
            count += 1
    finally:
        container.close()


# ---------------------------------------------------------------------------
# IMX binary container
# ---------------------------------------------------------------------------


def is_imx_file(path: str) -> bool:
    """Check if a file is an IMX binary container."""
    try:
        with open(path, "rb") as f:
            magic = f.read(4)
            return magic == IMX_MAGIC
    except (OSError, IOError):
        return False




def is_imx_v2_file(path: str) -> bool:
    """Check if a file is an IMX v2 container."""
    try:
        with open(path, "rb") as f:
            return f.read(4) == IMX_MAGIC
    except (OSError, IOError):
        return False


def write_imx_v2_container(
    output_path: str,
    files: dict,
) -> None:
    """Write files into an IMX v2 binary container.

    Same structure as write_imx_container but with IMX v2 magic and version.
    """
    file_count = len(files)
    header = struct.pack("<4sHH", IMX_MAGIC, IMX_VERSION, file_count)

    file_entries = []
    for name, data in files.items():
        name_bytes = name.encode("utf-8")
        file_entries.append((name_bytes, data))

    table_size = sum(2 + len(nb) + 8 + 8 for nb, _ in file_entries)
    data_start = len(header) + table_size

    current_offset = data_start
    file_table = bytearray()
    data_items = []
    for name_bytes, data in file_entries:
        file_table.extend(struct.pack("<H", len(name_bytes)))
        file_table.extend(name_bytes)
        file_table.extend(struct.pack("<QQ", current_offset, len(data)))
        data_items.append(data)
        current_offset += len(data)

    with open(output_path, "wb") as f:
        f.write(header)
        f.write(file_table)
        for data in data_items:
            f.write(data)


class ImxContainer:
    """Virtual filesystem over an IMX binary container.

    Reads the file table on init (<1ms for typical containers) and provides
    random access to embedded files via seek+read without extraction.

    If the container includes a ``manifest.json`` file, it is eagerly
    loaded and exposed via the ``metadata`` property.
    """

    def __init__(self, path: str) -> None:
        self.path = path
        self._entries: Dict[str, Tuple[int, int]] = {}
        self._metadata: Optional[dict] = None

        with open(path, "rb") as f:
            header = f.read(8)
            if len(header) < 8:
                raise RuntimeError("File too small to be an IMX container")
            magic = header[:4]
            if magic == IMX_MAGIC:
                container_version = struct.unpack_from("<H", header, 4)[0]
            elif magic == _OLD_IMX_V1_MAGIC:
                raise RuntimeError(
                    "This model uses an outdated container format (IMX v1). Please upgrade:\n"
                    "  pip install --upgrade bithuman\n"
                    f"  bithuman convert {path}"
                )
            else:
                raise RuntimeError(f"Not an IMX file: bad magic {magic!r}")
            file_count = struct.unpack_from("<H", header, 6)[0]

            for _ in range(file_count):
                name_len = struct.unpack("<H", f.read(2))[0]
                name = f.read(name_len).decode("utf-8")
                data_offset, data_size = struct.unpack("<QQ", f.read(16))
                self._entries[name] = (data_offset, data_size)

        # Eagerly load metadata if present
        if "manifest.json" in self._entries:
            raw = self.read_file("manifest.json")
            self._metadata = json.loads(raw)

    def read_file(self, name: str) -> bytes:
        """Read an embedded file by name."""
        if name not in self._entries:
            raise KeyError(f"File not found in IMX container: {name!r}")
        offset, size = self._entries[name]
        with open(self.path, "rb") as f:
            f.seek(offset)
            return f.read(size)

    def get_entry(self, name: str) -> Tuple[int, int]:
        """Return (offset, size) for an embedded file."""
        if name not in self._entries:
            raise KeyError(f"File not found in IMX container: {name!r}")
        return self._entries[name]

    def has_file(self, name: str) -> bool:
        """Check if a file exists in the container."""
        return name in self._entries

    def list_files(self) -> List[str]:
        """Return all file names in the container."""
        return list(self._entries.keys())

    def find_files(self, pattern: str) -> List[str]:
        """Return file names matching a glob pattern."""
        return [n for n in self._entries if fnmatch.fnmatch(n, pattern)]

    @property
    def format_version(self) -> int:
        """Return the format version from metadata (2 for v2, 1 for v1, 0 if no metadata)."""
        if self._metadata is None:
            return 0
        return self._metadata.get("format_version", self._metadata.get("version", 1))

    @property
    def has_metadata(self) -> bool:
        """Whether the container includes manifest.json."""
        return self._metadata is not None

    @property
    def metadata(self) -> Optional[dict]:
        """Parsed manifest.json contents, or None."""
        return self._metadata



class MP4VideoReader:
    """MP4 frame reader with optional frame caching for ping-pong looping.

    Provides sequential H.264 decoding with support for backward access via
    frame caching (for LoopingVideo ping-pong) or keyframe seeking (fallback
    for large videos that exceed the cache memory cap).

    The reader maintains a frame buffer for the current position. get() advances
    sequentially; calling get(0) seeks back to the start for efficient looping.

    Thread-safe: concurrent access is serialized via a lock.
    """

    def __init__(
        self,
        path: str,
        key: str = "",
        thread_count: int = 0,
        *,
        base_offset: int = 0,
        file_size: int = 0,
        frame_count: int = 0,
        cache_frames: bool = False,
    ) -> None:
        """Initialize MP4 reader from a file or embedded section of an IMX container.

        Args:
            path: Path to the file (IMX container or standalone MP4).
            key: Decryption key (unused for MP4, kept for API compatibility).
            thread_count: Unused (kept for API symmetry).
            base_offset: Byte offset where MP4 data starts (for embedded MP4 in IMX).
            file_size: Size of MP4 data in bytes (0 = read to end of file).
            frame_count: Pre-computed frame count (0 = count by decoding, slow).
            cache_frames: If True, cache decoded frames for O(1) random access.
                Enable for ping-pong looping videos; disable for forward-only
                action videos to save memory.
        """
        import av

        self._path = path
        self._lock = threading.Lock()
        self._base_offset = base_offset
        self._current_frame_idx = 0

        # For embedded MP4 in IMX container, we need to read the data into memory
        # because PyAV doesn't support reading from arbitrary file offsets
        if base_offset > 0 or file_size > 0:
            with open(path, "rb") as f:
                f.seek(base_offset)
                if file_size > 0:
                    mp4_data = f.read(file_size)
                else:
                    mp4_data = f.read()
            self._container = av.open(io.BytesIO(mp4_data))
            self._mp4_bytes = mp4_data  # Keep reference to prevent BytesIO cleanup
        else:
            self._container = av.open(path)
            self._mp4_bytes = None

        stream = self._container.streams.video[0]
        stream.thread_type = "AUTO"

        self._width: int = stream.codec_context.width
        self._height: int = stream.codec_context.height

        # Use pre-computed frame count if available (fast path)
        # Otherwise decode all frames to count (slow but accurate for VFR)
        if frame_count > 0:
            self._frame_count = frame_count
        else:
            self._container.seek(0)
            counted = 0
            for _ in self._container.decode(video=0):
                counted += 1
            self._frame_count = counted

        # Reset decoder for playback
        self._container.seek(0)
        self._decoder = self._container.decode(video=0)
        self._current_frame_idx = -1  # Nothing decoded yet
        self._current_frame: Optional[np.ndarray] = None
        self._at_end = False
        # Frame cache: populated during first forward pass, enables O(1) backward access
        # for ping-pong looping videos without re-decoding from frame 0 each time.
        # Auto-disabled for large frames (e.g. 4K) to avoid excessive memory use.
        frame_bytes = self._width * self._height * 3
        max_cache_bytes = 1024 * 1024 * 1024  # 1 GB
        self._cache_frames = cache_frames and (frame_bytes * self._frame_count <= max_cache_bytes)
        self._frame_cache: dict[int, np.ndarray] = {}

    def _advance_to_frame(self, target_idx: int) -> np.ndarray:
        """Advance decoder to target frame index.

        Uses three strategies in order of preference:
        1. Frame cache hit (O(1), if caching enabled and frame was seen before)
        2. Sequential decode (fast, if target is ahead of current position)
        3. Keyframe seek (O(GOP_size), for backward seeks when cache is disabled)
        """
        # Fast path: frame already cached (backward seek or re-visit)
        if self._cache_frames and target_idx in self._frame_cache:
            self._current_frame = self._frame_cache[target_idx]
            self._current_frame_idx = target_idx
            return self._current_frame

        # Need to decode: if target is behind decoder cursor, seek backward
        if target_idx < self._current_frame_idx or self._current_frame is None:
            stream = self._container.streams.video[0]
            if target_idx == 0:
                self._container.seek(0)
            else:
                # Seek to nearest keyframe at or before target frame.
                # This is O(GOP_size) instead of O(N) for backward seeks.
                fps = float(stream.average_rate)
                tb = float(stream.time_base)
                target_pts = int(target_idx / fps / tb)
                self._container.seek(target_pts, backward=True, stream=stream)

            self._decoder = self._container.decode(video=0)
            self._current_frame_idx = -1
            self._current_frame = None
            self._at_end = False

            # After keyframe seek, determine actual position from first decoded PTS
            if target_idx > 0:
                try:
                    first = next(self._decoder)
                    fps = float(stream.average_rate)
                    tb = float(stream.time_base)
                    self._current_frame_idx = round(first.pts * tb * fps)
                    bgr = first.to_ndarray(format="bgr24")
                    if self._cache_frames:
                        self._frame_cache[self._current_frame_idx] = bgr
                    self._current_frame = bgr
                except StopIteration:
                    self._at_end = True

        # Advance to target frame, caching along the way if enabled
        while self._current_frame_idx < target_idx:
            try:
                frame = next(self._decoder)
                bgr = frame.to_ndarray(format="bgr24")
                self._current_frame_idx += 1
                if self._cache_frames:
                    self._frame_cache[self._current_frame_idx] = bgr
                self._current_frame = bgr
            except StopIteration:
                self._at_end = True
                raise IndexError(
                    f"Frame index {target_idx} out of range [0, {self._frame_count})"
                )

        return self._current_frame

    def get(self, index: int) -> np.ndarray:
        """Get a decoded BGR frame by index (returns a copy).

        Optimized for sequential access. Supports negative indexing.
        Seeking backward resets to frame 0 and advances (efficient for looping).
        """
        if index < 0:
            index = self._frame_count + index
        if index < 0 or index >= self._frame_count:
            raise IndexError(
                f"Frame index {index} out of range [0, {self._frame_count})"
            )

        with self._lock:
            # Fast path: requesting current frame (already decoded)
            if index == self._current_frame_idx and self._current_frame is not None:
                return self._current_frame.copy()

            # General case: advance to target frame
            # _advance_to_frame handles sequential and seeking cases
            frame = self._advance_to_frame(index)
            return frame.copy()

    def get_next(self) -> Tuple[int, np.ndarray]:
        """Get the next frame in sequence, looping back to start at end.

        Returns:
            Tuple of (frame_index, frame_data).
            When reaching the end, returns (0, first_frame) to loop.
        """
        with self._lock:
            if self._at_end:
                # Loop back to start
                self._container.seek(0)
                self._decoder = self._container.decode(video=0)
                self._current_frame_idx = -1
                self._at_end = False

            try:
                frame = next(self._decoder)
                self._current_frame = frame.to_ndarray(format="bgr24")
                self._current_frame_idx += 1
                return self._current_frame_idx, self._current_frame.copy()
            except StopIteration:
                # Loop back to start
                self._at_end = False
                self._container.seek(0)
                self._decoder = self._container.decode(video=0)
                self._current_frame_idx = -1
                frame = next(self._decoder)
                self._current_frame = frame.to_ndarray(format="bgr24")
                self._current_frame_idx = 0
                return 0, self._current_frame.copy()

    def seek_to_start(self) -> None:
        """Reset reader to frame 0 for efficient looping."""
        with self._lock:
            self._container.seek(0)
            self._decoder = self._container.decode(video=0)
            self._current_frame_idx = -1  # Nothing decoded yet
            self._current_frame = None
            self._at_end = False

    def size(self) -> int:
        """Return total number of frames."""
        return self._frame_count

    @property
    def width(self) -> int:
        return self._width

    @property
    def height(self) -> int:
        return self._height

    def close(self) -> None:
        if self._container:
            self._container.close()
            self._container = None
        self._mp4_bytes = None
        self._frame_cache.clear()
        self._current_frame = None
        self._decoder = None

    @classmethod
    def from_bytes(cls, mp4_data: bytes, frame_count: int = 0) -> "MP4VideoReader":
        """Create reader from in-memory H.264 bytes (no frame cache).

        Used for ping-pong videos that have been re-encoded as forward-only
        at load time, eliminating the need for frame caching.
        """
        import av

        instance = cls.__new__(cls)
        instance._path = "<memory>"
        instance._lock = threading.Lock()
        instance._base_offset = 0
        instance._mp4_bytes = mp4_data
        instance._container = av.open(io.BytesIO(mp4_data))
        stream = instance._container.streams.video[0]
        stream.thread_type = "AUTO"
        instance._width = stream.codec_context.width
        instance._height = stream.codec_context.height
        if frame_count > 0:
            instance._frame_count = frame_count
        else:
            instance._container.seek(0)
            instance._frame_count = sum(1 for _ in instance._container.decode(video=0))
        instance._container.seek(0)
        instance._decoder = instance._container.decode(video=0)
        instance._current_frame_idx = -1
        instance._current_frame = None
        instance._at_end = False
        instance._cache_frames = False
        instance._frame_cache = {}
        return instance

    def __del__(self) -> None:
        self.close()

    def __enter__(self) -> "MP4VideoReader":
        return self

    def __exit__(self, *exc) -> None:
        self.close()
