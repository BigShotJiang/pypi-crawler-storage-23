"""ONNX audio encoder inference — replaces C++ melChunkToAudioEmbedding."""

from __future__ import annotations

import os
import threading
from collections import OrderedDict
from typing import Optional

import numpy as np
import onnxruntime as ort

# Module-level ONNX session cache keyed by absolute model path.
# Uses OrderedDict for LRU eviction: accessed items are moved to end,
# oldest items are evicted from front when cache exceeds _ONNX_CACHE_MAX.
_ONNX_CACHE_MAX = 8
_onnx_session_cache: OrderedDict[str, ort.InferenceSession] = OrderedDict()
_onnx_session_lock = threading.Lock()


class AudioEncoder:
    """Wraps an ONNX audio encoder session for mel-to-embedding inference.

    Matches the C++ BithumanRuntime ONNX setup:
    - intra_op_num_threads=1 (avoid nested parallelism)
    - disable CPU memory arena (container compatibility)
    - fallback from EXTENDED to BASIC optimization level
    - pre-allocated input buffer reused across calls
    """

    def __init__(self, model_path: str = ""):
        self._session: Optional[ort.InferenceSession] = None
        self._input_name: Optional[str] = None
        self._output_name: Optional[str] = None
        # Pre-allocated input buffer matching C++ onnx_input_data_ (1*1*80*16)
        self._input_buf: np.ndarray = np.zeros((1, 1, 80, 16), dtype=np.float32)
        if model_path:
            self.load(model_path)

    def load(self, model_path: str, threads: int = 1) -> None:
        """Load ONNX model, reusing cached session if available.

        Mirrors generator.cpp setAudioEncoder (lines 439-502):
        - Try EXTENDED first, fall back to BASIC on failure.

        Args:
            threads: Number of intra-op threads for ONNX (0 = auto).
        """
        abs_path = os.path.abspath(model_path)

        with _onnx_session_lock:
            if abs_path in _onnx_session_cache:
                _onnx_session_cache.move_to_end(abs_path)
                self._session = _onnx_session_cache[abs_path]
                self._input_name = self._session.get_inputs()[0].name
                self._output_name = self._session.get_outputs()[0].name
                return

        # Create new session outside the lock (loading can be slow)
        opts = ort.SessionOptions()
        opts.intra_op_num_threads = threads
        opts.enable_cpu_mem_arena = False

        try:
            opts.graph_optimization_level = (
                ort.GraphOptimizationLevel.ORT_ENABLE_EXTENDED
            )
            session = ort.InferenceSession(model_path, opts)
        except Exception:
            opts.graph_optimization_level = (
                ort.GraphOptimizationLevel.ORT_ENABLE_BASIC
            )
            try:
                session = ort.InferenceSession(model_path, opts)
            except Exception as e:
                raise RuntimeError(
                    f"Failed to load audio encoder model '{model_path}': {e}"
                ) from e

        with _onnx_session_lock:
            # Double-check: another thread may have cached it while we were loading
            if abs_path in _onnx_session_cache:
                _onnx_session_cache.move_to_end(abs_path)
                session = _onnx_session_cache[abs_path]
            else:
                _onnx_session_cache[abs_path] = session
                # Evict least-recently-used entries when over limit
                while len(_onnx_session_cache) > _ONNX_CACHE_MAX:
                    _evicted_path, _evicted_sess = _onnx_session_cache.popitem(last=False)
                    del _evicted_sess

        self._session = session
        self._input_name = self._session.get_inputs()[0].name
        self._output_name = self._session.get_outputs()[0].name

    def encode(self, mel_chunk: np.ndarray) -> np.ndarray:
        """Convert a mel spectrogram chunk to an audio embedding.

        Args:
            mel_chunk: float32 array of shape (80, 16).

        Returns:
            float32 array of shape (embedding_dim,).

        Mirrors generator.cpp melChunkToAudioEmbedding (lines 505-533):
        - Input shape: (1, 1, 80, 16), row-major (C-contiguous = numpy default).
        - Output: squeezed to 1-D embedding vector.
        """
        if self._session is None:
            raise RuntimeError("Audio encoder not initialized")

        # Copy into pre-allocated buffer (matches C++ zero-copy pattern).
        # Assignment handles dtype conversion automatically when needed.
        self._input_buf[0, 0] = mel_chunk

        result = self._session.run(
            [self._output_name],
            {self._input_name: self._input_buf},
        )
        return result[0].squeeze()

    def encode_batch(self, mel_chunks: list[np.ndarray]) -> np.ndarray:
        """Batch encode N mel chunks in a single ONNX call.

        Args:
            mel_chunks: list of float32 arrays, each shape (80, 16).

        Returns:
            float32 array of shape (N, embedding_dim).
        """
        if self._session is None:
            raise RuntimeError("Audio encoder not initialized")

        n = len(mel_chunks)
        if n == 0:
            return np.empty((0, 0), dtype=np.float32)
        if n == 1:
            return self.encode(mel_chunks[0]).reshape(1, -1)

        batch = np.stack(mel_chunks).reshape(n, 1, 80, 16)
        if batch.dtype != np.float32:
            batch = batch.astype(np.float32)

        result = self._session.run(
            [self._output_name],
            {self._input_name: batch},
        )
        out = result[0]
        # Reshape to (N, embedding_dim) regardless of intermediate dims
        return out.reshape(n, -1)
