"""Frame compression/decompression — replaces image.cpp encode/decode."""

from __future__ import annotations

import os
import struct
import tempfile
from typing import Optional
import numpy as np
from .enums import CompressionType

IMAGE_TYPE_BGR8 = 16  # Matches CV_8UC3

# ---------------------------------------------------------------------------
# TurboJPEG (preferred) with cv2 fallback
# ---------------------------------------------------------------------------
try:
    from turbojpeg import TurboJPEG, TJPF_BGR, TJFLAG_FASTDCT, TJSAMP_420

    _TURBOJPEG_LIB_PATHS = [
        None,  # auto-detect first
        "/usr/lib/x86_64-linux-gnu/libturbojpeg.so",
        "/usr/lib/libturbojpeg.so",
        "/opt/libjpeg-turbo/lib64/libturbojpeg.so",
        "/usr/lib/aarch64-linux-gnu/libturbojpeg.so",
    ]
    _tj = None
    for _lib_path in _TURBOJPEG_LIB_PATHS:
        try:
            _tj = TurboJPEG(_lib_path) if _lib_path else TurboJPEG()
            break
        except (RuntimeError, OSError):
            continue
    _HAS_TURBOJPEG = _tj is not None
except ImportError:
    _HAS_TURBOJPEG = False

# ---------------------------------------------------------------------------
# LZ4
# ---------------------------------------------------------------------------
try:
    import lz4.block

    _HAS_LZ4 = True
except ImportError:
    _HAS_LZ4 = False


# ---------------------------------------------------------------------------
# JPEG
# ---------------------------------------------------------------------------
def encode_jpeg(image: np.ndarray, quality: int = 95) -> bytes:
    """Encode BGR uint8 image to JPEG bytes.

    Matches image.cpp encodeJPEG: TurboJPEG with TJPF_BGR, TJSAMP_420.
    """
    if _HAS_TURBOJPEG:
        return _tj.encode(
            image, quality=quality, pixel_format=TJPF_BGR, jpeg_subsample=TJSAMP_420
        )
    import cv2

    _, buf = cv2.imencode(".jpg", image, [cv2.IMWRITE_JPEG_QUALITY, quality])
    return buf.tobytes()


def decode_jpeg(data: bytes) -> np.ndarray:
    """Decode JPEG bytes to BGR uint8 numpy array (H, W, 3).

    Matches image.cpp decodeJPEG: TurboJPEG with TJPF_BGR.
    """
    if not data:
        raise RuntimeError("Empty JPEG data")
    if _HAS_TURBOJPEG:
        return _tj.decode(data, pixel_format=TJPF_BGR)
    import cv2

    arr = np.frombuffer(data, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        raise RuntimeError("Failed to decompress JPEG")
    return img


# ---------------------------------------------------------------------------
# LZ4
# ---------------------------------------------------------------------------
def encode_lz4(image: np.ndarray) -> bytes:
    """Encode BGR image with 16-byte header + LZ4 compressed data.

    Header format matches image.cpp encodeLZ4:
    [uint32 width, uint32 height, uint32 type(16), uint32 original_size]
    """
    if not _HAS_LZ4:
        raise RuntimeError("lz4 package not installed")
    h, w = image.shape[:2]
    data_size = w * h * 3
    header = struct.pack("<IIII", w, h, IMAGE_TYPE_BGR8, data_size)
    # lz4.block.compress accepts buffer-protocol objects; pass raw memory
    # buffer directly when array is already C-contiguous to avoid .tobytes() copy.
    if image.flags.c_contiguous:
        compressed = lz4.block.compress(image.data, store_size=False)
    else:
        compressed = lz4.block.compress(
            np.ascontiguousarray(image).tobytes(), store_size=False
        )
    return header + compressed


def decode_lz4(data: bytes) -> np.ndarray:
    """Decode 16-byte header + LZ4 compressed data to BGR image.

    Matches image.cpp decodeLZ4.
    """
    if not _HAS_LZ4:
        raise RuntimeError("lz4 package not installed")
    if len(data) < 16:
        raise RuntimeError("Invalid LZ4 data: header too small")
    w, h, img_type, orig_size = struct.unpack("<IIII", data[:16])
    if img_type != IMAGE_TYPE_BGR8:
        raise RuntimeError(f"Invalid image type in LZ4 data: {img_type}")
    expected = w * h * 3
    if orig_size != expected:
        raise RuntimeError(
            f"Invalid data size in LZ4 header: {orig_size} != {expected}"
        )
    decompressed = lz4.block.decompress(data[16:], uncompressed_size=orig_size)
    return np.frombuffer(decompressed, dtype=np.uint8).reshape(h, w, 3).copy()


# ---------------------------------------------------------------------------
# NONE (raw with header)
# ---------------------------------------------------------------------------
def encode_none(image: np.ndarray) -> bytes:
    """Encode with 16-byte header + raw BGR pixel data.

    Matches image.cpp encodeNONE.
    """
    h, w = image.shape[:2]
    data_size = w * h * 3
    header = struct.pack("<IIII", w, h, IMAGE_TYPE_BGR8, data_size)
    return header + np.ascontiguousarray(image).tobytes()


def decode_none(data: bytes) -> np.ndarray:
    """Decode 16-byte header + raw BGR pixel data.

    Matches image.cpp decodeNONE.
    """
    if len(data) < 16:
        raise RuntimeError("Invalid raw data: header too small")
    w, h, img_type, data_size = struct.unpack("<IIII", data[:16])
    if img_type != IMAGE_TYPE_BGR8:
        raise RuntimeError(f"Invalid image type in raw data: {img_type}")
    expected = w * h * 3
    if data_size != expected or len(data) != expected + 16:
        raise RuntimeError("Invalid data size in raw header")
    return np.frombuffer(data[16:], dtype=np.uint8).reshape(h, w, 3).copy()


# ---------------------------------------------------------------------------
# TEMP_FILE
# ---------------------------------------------------------------------------
_temp_counter = 0


def encode_temp_file(image: np.ndarray, temp_dir: str, quality: int = 95) -> bytes:
    """Encode image to JPEG, write to temp file, return path as bytes.

    Matches image.cpp encodeTempFile.
    """
    global _temp_counter
    if not temp_dir:
        raise RuntimeError("Temp dir is not set")
    _temp_counter += 1
    path = os.path.join(temp_dir, f"frame_{_temp_counter}.bin")
    jpeg_data = encode_jpeg(image, quality)
    with open(path, "wb") as f:
        f.write(jpeg_data)
    return path.encode("utf-8")


def decode_temp_file(path_data: bytes) -> np.ndarray:
    """Read JPEG data from temp file, decode to BGR image.

    Matches image.cpp decodeTempFile.
    """
    if not path_data:
        raise RuntimeError("Empty path data")
    path = path_data.decode("utf-8")
    with open(path, "rb") as f:
        jpeg_data = f.read()
    return decode_jpeg(jpeg_data)


# ---------------------------------------------------------------------------
# Temp dir management
# ---------------------------------------------------------------------------
def create_temp_dir() -> str:
    """Create a unique temp directory for frame storage.

    Matches image.cpp createTempDir.
    """
    root = os.path.join(tempfile.gettempdir(), "bithuman_tmp")
    os.makedirs(root, exist_ok=True)
    return tempfile.mkdtemp(prefix="video_", dir=root)


def cleanup_temp_dir(path: str) -> None:
    """Remove temp directory and all contents.

    Matches image.cpp cleanupTempDir.
    """
    import shutil

    if path and os.path.isdir(path):
        shutil.rmtree(path, ignore_errors=True)


# ---------------------------------------------------------------------------
# Unified encode/decode API
# ---------------------------------------------------------------------------
def encode_image(
    image: np.ndarray,
    compression: CompressionType,
    quality: int = 95,
    temp_dir: str = "",
) -> bytes:
    """Encode image with specified compression type.

    Matches image.cpp encodeImage.
    """
    if compression == CompressionType.JPEG:
        return encode_jpeg(image, quality)
    elif compression == CompressionType.LZ4:
        return encode_lz4(image)
    elif compression == CompressionType.NONE:
        return encode_none(image)
    elif compression == CompressionType.TEMP_FILE:
        return encode_temp_file(image, temp_dir, quality)
    raise ValueError(f"Unknown compression type: {compression}")


def decode_image(data: bytes, compression: CompressionType) -> np.ndarray:
    """Decode image with specified compression type.

    Matches image.cpp decodeImage.
    """
    if compression == CompressionType.JPEG:
        return decode_jpeg(data)
    elif compression == CompressionType.LZ4:
        return decode_lz4(data)
    elif compression == CompressionType.NONE:
        return decode_none(data)
    elif compression == CompressionType.TEMP_FILE:
        return decode_temp_file(data)
    raise ValueError(f"Unknown compression type: {compression}")
