"""Lip-sync readers for IMX v2 format.

BlobReader: Reads indexed blob archives with pluggable codec (JPEG/WebP).
PatchReader: Reconstructs full frames from base + mouth-region patches.

Storage model: each lip-sync variant stores a full base face crop plus
cropped mouth-region patches (one per cluster). Patches are replacement
images — not pixel diffs — pasted at crop_bbox to produce the final frame.

These readers provide O(1) random-access frame decoding with minimal memory
overhead — only the offset index (~8 bytes per frame) is held in RAM.
"""

from __future__ import annotations

import io
import struct
import threading
from typing import Dict, Optional, Tuple, Union

import cv2
import numpy as np

from .compression import decode_jpeg
from .video_reader import ENCRYPT_KEY

# Blob archive format constants (on-disk magic is b"BJPG" for historical reasons)
BLOB_MAGIC = b"BJPG"
BLOB_VERSION = 1
BLOB_HEADER_SIZE = 24  # magic(4) + version(2) + count(4) + w(2) + h(2) + q(1) + reserved(1) + data_offset(8)


class BlobReader:
    """Indexed blob archive reader with pluggable decoder.

    Reads XOR-encrypted, indexed blob archives containing JPEG or WebP
    encoded image data. Provides O(1) random access to any frame.

    Supports reading from within a larger container file via base_offset
    and file_size parameters (for IMX container embedding).

    Interface: get(index), size(), width, height, close()
    """

    def __init__(
        self,
        path: str,
        key: str = "",
        thread_count: int = 0,
        *,
        decoder: str = "jpeg",
        base_offset: int = 0,
        file_size: int = 0,
        preload: bool = False,
    ) -> None:
        self._path = path
        self._key = key.encode("utf-8") if key else ENCRYPT_KEY
        self._lock = threading.Lock()
        self._base_offset = base_offset
        self._decoder = decoder

        self._file = open(path, "rb")
        if file_size > 0:
            self._file_size = file_size
        else:
            self._file.seek(0, 2)
            self._file_size = self._file.tell()

        self._file.seek(self._base_offset)

        raw_header = self._file.read(BLOB_HEADER_SIZE)
        header = self._xor_decrypt_range(0, raw_header)

        magic = header[:4]
        if magic != BLOB_MAGIC:
            self._file.close()
            raise RuntimeError(f"Invalid blob archive: bad magic {magic!r}")

        version = struct.unpack_from("<H", header, 4)[0]
        if version != BLOB_VERSION:
            self._file.close()
            raise RuntimeError(f"Unsupported blob archive version: {version}")

        self._frame_count: int = struct.unpack_from("<I", header, 6)[0]
        self._width: int = struct.unpack_from("<H", header, 10)[0]
        self._height: int = struct.unpack_from("<H", header, 12)[0]
        self._quality: int = header[14]
        self._data_offset: int = struct.unpack_from("<Q", header, 16)[0]

        index_size = self._frame_count * 8
        raw_index = self._file.read(index_size)
        index_data = self._xor_decrypt_range(BLOB_HEADER_SIZE, raw_index)
        self._offsets = struct.unpack(f"<{self._frame_count}Q", index_data)

        # Preload mode: read entire data section into memory and pre-decrypt.
        # Eliminates per-frame disk I/O and XOR decryption.
        self._preloaded: Optional[bytes] = None
        self._preload_base: int = 0
        # Lazy decode cache: populated on first access, stays forever.
        # After one full cycle through all frames, all decodes are cached.
        self._decoded_cache: Optional[dict] = None
        if preload and self._frame_count > 0:
            data_start = self._data_offset
            data_size = self._file_size - data_start
            self._file.seek(self._base_offset + data_start)
            raw_data = self._file.read(data_size)
            self._preloaded = self._xor_decrypt_range(data_start, raw_data)
            self._preload_base = data_start
            self._file.close()
            self._file = None
            self._decoded_cache = {}

    def _xor_decrypt_range(self, file_offset: int, data: bytes) -> bytes:
        key_len = len(self._key)
        key_start = file_offset % key_len
        data_arr = np.frombuffer(data, dtype=np.uint8).copy()
        key_arr = np.frombuffer(self._key, dtype=np.uint8)
        # Tile the key (much faster than arange + modulo for large data).
        # np.roll shifts key to align with file_offset, then tile repeats it.
        shifted = np.roll(key_arr, -key_start)
        full_key = np.tile(shifted, len(data_arr) // key_len + 1)[:len(data_arr)]
        data_arr ^= full_key
        return data_arr.tobytes()

    def get_blob(self, index: int) -> bytes:
        """Read and decrypt raw blob bytes without decoding."""
        if index < 0:
            index = self._frame_count + index
        if index < 0 or index >= self._frame_count:
            raise IndexError(
                f"Frame index {index} out of range [0, {self._frame_count})"
            )

        start = self._offsets[index]
        end = (
            self._offsets[index + 1]
            if index + 1 < self._frame_count
            else self._file_size
        )

        if self._preloaded is not None:
            return self._preloaded[start - self._preload_base : end - self._preload_base]

        blob_size = end - start
        with self._lock:
            self._file.seek(self._base_offset + start)
            raw_blob = self._file.read(blob_size)

        return self._xor_decrypt_range(start, raw_blob)

    def _decode_blob(self, blob: bytes, index: int = -1) -> np.ndarray:
        """Decode raw blob bytes to BGR uint8 numpy array."""
        if self._decoder == "jpeg":
            return decode_jpeg(blob)
        arr = np.frombuffer(blob, dtype=np.uint8)
        img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        if img is None:
            raise RuntimeError(f"Failed to decode blob at index {index}")
        return img

    def get(self, index: int) -> np.ndarray:
        """Read, decrypt, and decode a frame by index. Returns BGR uint8."""
        if self._decoded_cache is not None:
            if index < 0:
                index = self._frame_count + index
            if index < 0 or index >= self._frame_count:
                raise IndexError(
                    f"Frame index {index} out of range [0, {self._frame_count})"
                )
            cached = self._decoded_cache.get(index)
            if cached is not None:
                return cached
            blob = self.get_blob(index)
            decoded = self._decode_blob(blob, index)
            self._decoded_cache[index] = decoded
            return decoded

        blob = self.get_blob(index)
        return self._decode_blob(blob, index)

    def size(self) -> int:
        return self._frame_count

    @property
    def width(self) -> int:
        return self._width

    @property
    def height(self) -> int:
        return self._height

    def close(self) -> None:
        if self._file:
            self._file.close()
            self._file = None
        # Release preloaded data and decode cache (can be hundreds of MB)
        self._preloaded = None
        if self._decoded_cache is not None:
            self._decoded_cache.clear()
            self._decoded_cache = None
        self._offsets = None

    def __del__(self) -> None:
        self.close()

    def __enter__(self) -> "BlobReader":
        return self

    def __exit__(self, *exc) -> None:
        self.close()


class PatchReader:
    """Reconstructs full face-crop frames from base + mouth-region patches.

    Each cluster variant is produced by pasting a replacement mouth patch
    onto the base frame at crop_bbox. Patches are full images, not pixel diffs.

    Drop-in replacement for any frame reader. Uses the same
    get(index)/size()/width/height/close() interface.

    Storage layout (on disk):
        bases archive:   num_source_frames entries (full face crop each)
        patches archive: num_source_frames * (num_clusters - 1) entries (mouth regions)

    Index translation (FEATURE_FIRST layout):
        frame_idx   = index // num_clusters
        cluster_idx = index %  num_clusters
        cluster 0   → base frame (returned directly)
        cluster 1+  → base (cached) + mouth patch pasted at crop_bbox

    The meta parameter provides crop_bbox, num_source_frames, and num_clusters.
    It can be:
        - dict: from manifest.json lip_sync section
        - str: path to .npz file
        - bytes: raw .npz data
    """

    def __init__(
        self,
        bases_path: str,
        patches_path: str,
        meta: Union[str, bytes, Dict],
        decode_fn: str = "webp",
        *,
        bases_offset: int = 0,
        bases_size: int = 0,
        patches_offset: int = 0,
        patches_size: int = 0,
        preload: bool = False,
    ) -> None:
        # Parse metadata from various sources
        if isinstance(meta, dict):
            self._crop_bbox: Tuple[int, int, int, int] = tuple(meta["crop_bbox"])
            self._num_source_frames: int = int(meta["num_source_frames"])
            self._num_clusters: int = int(meta["num_clusters"])
        elif isinstance(meta, bytes):
            npz = np.load(io.BytesIO(meta))
            self._crop_bbox = tuple(npz["crop_bbox"])
            self._num_source_frames = int(npz["num_source_frames"])
            self._num_clusters = int(npz["num_clusters"])
        else:
            npz = np.load(meta)
            self._crop_bbox = tuple(npz["crop_bbox"])
            self._num_source_frames = int(npz["num_source_frames"])
            self._num_clusters = int(npz["num_clusters"])

        self._base_reader = BlobReader(
            bases_path, decoder=decode_fn,
            base_offset=bases_offset, file_size=bases_size,
            preload=preload,
        )
        self._patch_reader = BlobReader(
            patches_path, decoder=decode_fn,
            base_offset=patches_offset, file_size=patches_size,
            preload=preload,
        )

        # Width/height of the full (reconstructed) frame
        self._width = self._base_reader.width
        self._height = self._base_reader.height

        # Per-source-frame base cache (avoids redundant base decodes)
        self._cached_base_idx: int = -1
        self._cached_base: Optional[np.ndarray] = None
        self._cache_lock = threading.Lock()

    def get(self, index: int) -> np.ndarray:
        """Get a reconstructed frame by flat index (FEATURE_FIRST layout).

        Thread-safe: the base cache is protected by a lock.
        """
        total = self._num_source_frames * self._num_clusters
        if index < 0:
            index = total + index
        if index < 0 or index >= total:
            raise IndexError(f"Frame index {index} out of range [0, {total})")

        frame_idx = index // self._num_clusters
        cluster_idx = index % self._num_clusters

        with self._cache_lock:
            if cluster_idx == 0:
                # base is freshly decoded (new array from BlobReader.get),
                # so we can cache it directly without copying.
                base = self._base_reader.get(frame_idx)
                self._cached_base_idx = frame_idx
                self._cached_base = base
                return base

            # Ensure base is cached for this source frame
            if self._cached_base_idx != frame_idx:
                self._cached_base = self._base_reader.get(frame_idx)
                self._cached_base_idx = frame_idx

            # Copy needed: we paste the patch onto result below,
            # so the cache must not be mutated.
            result = self._cached_base.copy()

        patch_index = frame_idx * (self._num_clusters - 1) + (cluster_idx - 1)
        patch = self._patch_reader.get(patch_index)

        x1, y1, x2, y2 = self._crop_bbox
        result[y1:y2, x1:x2] = patch

        return result

    def size(self) -> int:
        return self._num_source_frames * self._num_clusters

    @property
    def width(self) -> int:
        return self._width

    @property
    def height(self) -> int:
        return self._height

    def close(self) -> None:
        if self._base_reader:
            self._base_reader.close()
            self._base_reader = None
        if self._patch_reader:
            self._patch_reader.close()
            self._patch_reader = None
        self._cached_base = None
        self._cached_base_idx = -1

    def __del__(self) -> None:
        self.close()

    def __enter__(self) -> "PatchReader":
        return self

    def __exit__(self, *exc) -> None:
        self.close()
