"""Pure Python engine replacing the C++ _bithuman_py extension."""

import gc as _gc

from .enums import CompressionType, LoadingMode

RUNTIME_VERSION = "1.2.2"

# Tune GC to reduce pause frequency during frame processing.
# Default thresholds are (700, 10, 10). Raising gen0 to 50000 means
# gen0 collections happen ~70x less often, reducing tail latency spikes.
# Gen1/gen2 ratios stay at 10 (unchanged from default).
_gc.set_threshold(50000, 10, 10)

__all__ = ["CompressionType", "LoadingMode", "RUNTIME_VERSION"]
