"""Video data management and blending pipeline — replaces video_data.cpp.

Manages per-video frame storage, HDF5 metadata (face_coords, face_masks),
avatar lip-sync data, and the compositing pipeline.
"""

from __future__ import annotations

import io
import threading
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Union

import h5py
import numpy as np

from .compression import (
    CompressionType,
    cleanup_temp_dir,
    create_temp_dir,
    decode_image,
    decode_jpeg,
    encode_image,
)
from .enums import LoadingMode
from .image_ops import blend_face_region, resize_image
from .video_reader import (
    ENCRYPT_KEY,
    MP4VideoReader,
    VideoReader,
    iter_video_frames,
)


# ---------------------------------------------------------------------------
# Data structures matching C++ VideoInferenceData / BoundingBox
# ---------------------------------------------------------------------------
@dataclass
class BoundingBox:
    x1: int
    y1: int
    x2: int
    y2: int


@dataclass
class VideoInferenceData:
    face_coords: List[BoundingBox]
    face_masks: List[bytes]  # JPEG-encoded bytes per frame
    frame_wh: tuple  # (width, height)


# ---------------------------------------------------------------------------
# LipFormat — matches VideoData::LipFormat enum in C++
# ---------------------------------------------------------------------------
class LipFormat:
    TIME_FIRST = "time-first"
    FEATURE_FIRST = "feature-first"
    NONE = "none"

    @staticmethod
    def detect(avatar_data_path: str) -> str:
        """Detect lip format from avatar data path.

        Matches video_data.cpp VideoData::detectFormat (lines 232-243).
        """
        if not avatar_data_path:
            return LipFormat.NONE
        if "feature-first" in avatar_data_path:
            return LipFormat.FEATURE_FIRST
        if "time-first" in avatar_data_path:
            return LipFormat.TIME_FIRST
        raise RuntimeError(f"Unknown avatar data format: {avatar_data_path}")


# ---------------------------------------------------------------------------
# HDF5 loading — matches loadVideoInferenceData in video_data.cpp
# ---------------------------------------------------------------------------
def load_video_inference_data(h5_path: Union[str, io.BytesIO]) -> VideoInferenceData:
    """Load face_coords, face_masks, frame_wh from HDF5 file.

    Matches video_data.cpp loadVideoInferenceData (lines 12-95).
    Accepts a file path (str) or in-memory BytesIO (for IMX fast path).
    """
    if isinstance(h5_path, io.BytesIO):
        h5_file = h5py.File(h5_path, "r", driver="fileobj")
    else:
        h5_file = h5py.File(h5_path, "r")
    with h5_file as f:
        # Read frame_wh attribute
        wh = f.attrs["frame_wh"]
        frame_wh = (int(wh[0]), int(wh[1]))

        # Read face_coords: (num_frames, 4) int32
        coords = f["face_coords"][:]
        face_coords = [BoundingBox(*row) for row in coords]

        # Read face_masks: variable-length uint8 arrays (JPEG bytes)
        masks_ds = f["face_masks"]
        face_masks = [bytes(masks_ds[i]) for i in range(len(masks_ds))]

    return VideoInferenceData(
        face_coords=face_coords,
        face_masks=face_masks,
        frame_wh=frame_wh,
    )


# ---------------------------------------------------------------------------
# VideoData — matches VideoData class in video_data.cpp
# ---------------------------------------------------------------------------
class VideoData:
    """Manages frame data, avatar lip-sync, and compositing for one video.

    Supports SYNC, ASYNC, and ON_DEMAND loading modes.
    """

    def __init__(
        self,
        video_path: str,
        video_data_path: str,
        avatar_data_path: str,
        lip_format: str,
        compression_type: CompressionType,
        loading_mode: LoadingMode,
        thread_count: int = 0,
        *,
        original_frame_reader: Optional[Any] = None,
        avatar_reader: Optional[Any] = None,
    ) -> None:
        self._video_path = video_path
        self._video_data_path = video_data_path
        self._avatar_data_path = avatar_data_path
        self._lip_format = lip_format
        self._compression_type = compression_type
        self._loading_mode = loading_mode
        self._thread_count = thread_count

        # On-demand readers from IMX fast path (skip frame decoding)
        self._original_frame_reader = original_frame_reader
        self._provided_avatar_reader: Optional[Any] = avatar_reader

        # Frame storage
        self._frames: List[bytes] = []
        self._data: Optional[VideoInferenceData] = None
        self._avatar_reader: Optional[Any] = None

        # Mask decoding cache – decode on-demand per frame instead of all-at-once
        # to avoid ~49 MB peak for decoded masks.  Only the last decoded mask is
        # kept (sequential access pattern in compositing loop).
        self._cached_mask_idx: int = -1
        self._cached_mask: Optional[np.ndarray] = None
        self._mask_lock = threading.Lock()

        # Temp dir for TEMP_FILE compression
        self._temp_dir = ""
        if compression_type == CompressionType.TEMP_FILE:
            self._temp_dir = create_temp_dir()

        # Async loading state
        self._loading_thread: Optional[threading.Thread] = None
        self._loaded = threading.Event()

        # Load based on mode
        if loading_mode == LoadingMode.SYNC:
            self._load_data()
            self._loaded.set()
        elif loading_mode == LoadingMode.ASYNC:
            self._loading_thread = threading.Thread(
                target=self._load_data_async, daemon=True
            )
            self._loading_thread.start()
        elif loading_mode == LoadingMode.ON_DEMAND:
            self._load_data_on_demand()
            self._loaded.set()

    def _load_data(self) -> None:
        """Load all data synchronously. Matches video_data.cpp loadData."""
        frame_width = -1
        frame_height = -1
        num_frames = -1

        if self._video_data_path:
            self._data = load_video_inference_data(self._video_data_path)
            frame_width, frame_height = self._data.frame_wh
            num_frames = len(self._data.face_coords)

        # Load and compress video frames (skip when original_frame_reader is provided)
        if self._original_frame_reader is None:
            if self._video_path and self._video_path.endswith(".mp4"):
                # Use on-demand MP4 reader instead of loading all frames into
                # memory.  For 252 frames this saves ~100-150 MB of RSS.
                self._original_frame_reader = MP4VideoReader(
                    self._video_path,
                    frame_count=num_frames if num_frames > 0 else 0,
                )
            else:
                self._frames = self._read_video_frames(frame_width, frame_height, num_frames)

                # Verify frame count
                if (
                    self._data
                    and self._data.face_coords
                    and len(self._frames) != len(self._data.face_coords)
                ):
                    raise RuntimeError(
                        f"Video contains {len(self._frames)} frames, but video data "
                        f"contains {len(self._data.face_coords)} face coordinates"
                    )

        # Initialize avatar reader for lip-sync data
        if self._provided_avatar_reader is not None:
            self._avatar_reader = self._provided_avatar_reader
        elif self._avatar_data_path:
            # Legacy path: use VideoReader to decode .bhtensor or other formats
            self._avatar_reader = VideoReader(
                self._avatar_data_path,
                ENCRYPT_KEY.decode("utf-8"),
                self._thread_count,
            )

    def _load_data_async(self) -> None:
        """Load data in background thread. Matches video_data.cpp loadDataAsync."""
        try:
            self._load_data()
        finally:
            self._loaded.set()

    def _load_data_on_demand(self) -> None:
        """Initialize metadata only; frames loaded lazily.

        Matches video_data.cpp loadDataOnDemand.
        """
        if self._video_data_path:
            self._data = load_video_inference_data(self._video_data_path)

        # Initialize avatar reader (prefer provided reader from IMX fast path)
        if self._provided_avatar_reader is not None:
            self._avatar_reader = self._provided_avatar_reader
        elif self._avatar_data_path:
            self._avatar_reader = VideoReader(
                self._avatar_data_path,
                ENCRYPT_KEY.decode("utf-8"),
                self._thread_count,
            )

        # Video reader for on-demand frame access
        self._on_demand_reader: Optional[VideoReader] = None
        self._on_demand_cache: Dict[int, bytes] = {}

    def _read_video_frames(
        self, frame_width: int, frame_height: int, num_frames: int
    ) -> List[bytes]:
        """Read video frames, resize if needed, and compress.

        Uses streaming decode: each frame is decoded, compressed, and then
        the raw frame is discarded. Peak memory is ~1 raw frame + compressed
        frames (instead of all raw frames + compressed frames).

        Matches image.cpp readVideoFrames (lines 85-112).
        """
        max_frames = num_frames if num_frames > 0 else -1
        frames: List[bytes] = []
        for frame in iter_video_frames(self._video_path, "", 0, max_frames):
            if frame.size == 0:
                continue
            if (
                frame_width != -1
                and frame_height != -1
                and (frame.shape[1] != frame_width or frame.shape[0] != frame_height)
            ):
                frame = resize_image(frame, frame_width, frame_height)
            frames.append(
                encode_image(frame, self._compression_type, temp_dir=self._temp_dir)
            )
        return frames

    def _get_frame_data(self, frame_idx: int) -> bytes:
        """Get compressed frame data by index.

        Matches video_data.cpp getFrameData (lines 201-215).
        """
        if self._loading_mode in (LoadingMode.ASYNC, LoadingMode.ON_DEMAND):
            # Wait for async loading to complete
            if not self._loaded.is_set():
                self._loaded.wait()

        if self._loading_mode == LoadingMode.ON_DEMAND and frame_idx not in self._on_demand_cache:
            # Lazy load this frame
            if self._on_demand_reader is None:
                self._on_demand_reader = VideoReader(self._video_path, "", 1)
            frame = self._on_demand_reader.get(frame_idx)
            if (
                self._data
                and self._data.frame_wh[0] > 0
                and (
                    frame.shape[1] != self._data.frame_wh[0]
                    or frame.shape[0] != self._data.frame_wh[1]
                )
            ):
                frame = resize_image(frame, self._data.frame_wh[0], self._data.frame_wh[1])
            compressed = encode_image(
                frame, self._compression_type, temp_dir=self._temp_dir
            )
            self._on_demand_cache[frame_idx] = compressed
            return compressed

        if self._loading_mode == LoadingMode.ON_DEMAND:
            return self._on_demand_cache[frame_idx]

        if frame_idx < 0 or frame_idx >= len(self._frames):
            raise RuntimeError(f"Frame index out of range: {frame_idx}")
        return self._frames[frame_idx]

    def get_original_frame(self, frame_idx: int) -> np.ndarray:
        """Decode compressed frame to BGR image.

        Matches video_data.cpp getOriginalFrame (lines 245-248).
        When original_frame_reader is set (IMX fast path), reads JPEG
        directly from disk with O(1) seek.
        """
        if self._original_frame_reader is not None:
            frame = self._original_frame_reader.get(frame_idx)
            # Resize to match HDF5 frame_wh if needed
            if self._data and (
                frame.shape[1] != self._data.frame_wh[0]
                or frame.shape[0] != self._data.frame_wh[1]
            ):
                frame = resize_image(frame, self._data.frame_wh[0], self._data.frame_wh[1])
            return frame
        data = self._get_frame_data(frame_idx)
        return decode_image(data, self._compression_type)

    def get_avatar_frame(
        self, frame_idx: int, cluster_idx: int, num_clusters: int
    ) -> np.ndarray:
        """Get lip overlay frame using TIME_FIRST or FEATURE_FIRST indexing.

        Matches video_data.cpp getAvatarFrame (lines 250-265).
        """
        if not self._avatar_reader:
            raise RuntimeError("Avatar reader not initialized")

        if self._lip_format == LipFormat.TIME_FIRST:
            index = cluster_idx * self._avatar_reader.size() // num_clusters + frame_idx
        else:
            index = frame_idx * num_clusters + cluster_idx

        return self._avatar_reader.get(index)

    def _get_mask(self, frame_idx: int) -> np.ndarray:
        """Decode a single face mask on demand.

        Only one decoded mask is kept in memory at a time (the most recently
        accessed index), saving ~49 MB compared to decoding all masks up front.
        The compressed JPEG masks (~0.5 MB total) remain in self._data.face_masks.

        Thread-safe: guarded by _mask_lock for parallel blending.
        """
        with self._mask_lock:
            if self._cached_mask_idx == frame_idx and self._cached_mask is not None:
                return self._cached_mask
            if not self._data or not self._data.face_masks:
                return np.empty((0, 0, 3), dtype=np.uint8)
            mask_bytes = self._data.face_masks[frame_idx]
            if mask_bytes:
                self._cached_mask = decode_jpeg(mask_bytes)
            else:
                self._cached_mask = np.empty((0, 0, 3), dtype=np.uint8)
            self._cached_mask_idx = frame_idx
            return self._cached_mask

    def get_blended_frame(
        self, frame_idx: int, cluster_idx: int, num_clusters: int
    ) -> np.ndarray:
        """Full compositing pipeline: original + resize + lip + mask blend.

        Matches video_data.cpp getBlendedFrame (lines 281-316):
        1. Get original frame, resize to frame_wh if needed
        2. Get avatar lip frame
        3. Get face bounding box
        4. Decode face mask (cached)
        5. Alpha blend lip into face region
        """
        # 1. Get original frame (already resized to frame_wh by get_original_frame)
        frame = self.get_original_frame(frame_idx)

        # Ensure writable copy for in-place blend below
        if not frame.flags.writeable:
            frame = frame.copy()

        # 2. Get lip frame
        lip = self.get_avatar_frame(frame_idx, cluster_idx, num_clusters)

        # 3. Get face bounding box
        box = self._data.face_coords[frame_idx]
        face_width = box.x2 - box.x1
        face_height = box.y2 - box.y1

        # 4. Decode face mask (on-demand, single frame)
        mask = self._get_mask(frame_idx)
        if mask.shape[1] != face_width or mask.shape[0] != face_height:
            raise RuntimeError(
                f"Mask size does not match face region size: "
                f"{mask.shape[1]} != {face_width} or "
                f"{mask.shape[0]} != {face_height}"
            )

        # 5. Blend lip into face region
        blend_face_region(frame, box.x1, box.y1, face_width, face_height, lip, mask)

        return frame

    def has_lip_data(self) -> bool:
        return self._avatar_reader is not None

    @property
    def num_frames(self) -> int:
        if self._original_frame_reader is not None:
            return self._original_frame_reader.size()
        if self._frames:
            return len(self._frames)
        if self._loading_mode == LoadingMode.ON_DEMAND and self._data:
            return len(self._data.face_coords)
        return 0

    @property
    def has_lip_sync(self) -> bool:
        """Check if this video has lip-sync capability (avatar reader initialized)."""
        # Wait for async loading if needed
        if self._loading_mode in (LoadingMode.ASYNC, LoadingMode.ON_DEMAND):
            if not self._loaded.is_set():
                self._loaded.wait()
        return self._avatar_reader is not None

    def __del__(self) -> None:
        if self._avatar_reader:
            self._avatar_reader.close()
        if self._original_frame_reader:
            self._original_frame_reader.close()
        if self._temp_dir:
            cleanup_temp_dir(self._temp_dir)
