from __future__ import annotations

import hashlib
import sys
import tarfile
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Optional, Tuple, Union

from loguru import logger

from ..engine.video_reader import IMX_MAGIC, ImxContainer

# Old IMX v1 magic for rejection
_OLD_IMX_V1_MAGIC = b"BIMX"


def unzip_tarfile(
    file_path: str, extract_to_local: bool = False
) -> Tuple[Union[str, ImxContainer], Optional[TemporaryDirectory], bool]:
    """Open a model file or directory.

    Supported formats:
      - IMX v2 binary container with ``manifest.json`` — returns an
        ``ImxContainer`` directly (no extraction, near-instant).
      - Legacy TAR archive — auto-converts to IMX v2 on first load.
        If the original file is writable, overwrites it so future loads
        are instant.  If the source is read-only, converts to a temp
        file that is cleaned up when the returned ``TemporaryDirectory``
        handle is garbage-collected.
      - Plain directory — passed through as-is.

    Rejected formats:
      - IMX v1 (old ``b"BIMX"`` magic) — raises ``RuntimeError`` with
        upgrade instructions.

    Returns:
        Tuple of (workspace_path_or_container, temp_dir_handle, is_legacy_format).
    """
    file_path: Path = Path(file_path)
    if file_path.is_dir():
        return str(file_path), None, False

    # Detect format by reading magic bytes
    with open(file_path, "rb") as f:
        magic = f.read(4)

    # IMX v2 format — instant load
    if magic == IMX_MAGIC:
        container = ImxContainer(str(file_path))
        if container.has_metadata:
            return container, None, False
        raise RuntimeError(
            f"IMX container missing manifest.json: {file_path}\n"
            "Re-convert the model to add metadata:\n"
            f"  bithuman convert {file_path}"
        )

    # Old IMX v1 format — no longer supported
    if magic == _OLD_IMX_V1_MAGIC:
        raise RuntimeError(
            "This model uses an outdated format (IMX v1). Please upgrade:\n"
            "  pip install --upgrade bithuman\n"
            f"  bithuman convert {file_path}"
        )

    # Legacy TAR archive — auto-convert to IMX v2
    return _auto_convert_tar(file_path)


def _auto_convert_tar(
    file_path: Path,
) -> Tuple[ImxContainer, Optional[TemporaryDirectory], bool]:
    """Extract a legacy TAR .imx and convert it to IMX v2 on the fly."""
    from ..cli import convert_tar_to_v2

    logger.info(f"Auto-converting legacy model to IMX v2: {file_path}")

    # Compute model hash from original file
    h = hashlib.md5()
    with open(file_path, "rb") as f:
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            h.update(chunk)
    model_hash = h.hexdigest()

    # Extract TAR to temp dir
    if sys.version_info >= (3, 10):
        extract_dir = TemporaryDirectory(ignore_cleanup_errors=True)
    else:
        extract_dir = TemporaryDirectory()

    mode = "r:gz" if file_path.name.endswith("gz") else "r"
    with tarfile.open(file_path, mode) as tar:
        tar.extractall(extract_dir.name)

    workspace = Path(extract_dir.name)
    contents = list(workspace.iterdir())
    if len(contents) == 1 and contents[0].is_dir():
        workspace = contents[0]

    # Try to overwrite the original file (makes future loads instant)
    try:
        convert_tar_to_v2(workspace, file_path, model_hash=model_hash)
        extract_dir.cleanup()
        container = ImxContainer(str(file_path))
        logger.info(f"Legacy model converted and saved: {file_path}")
        return container, None, False
    except (OSError, PermissionError):
        pass

    # Source is read-only — convert to a temp file
    logger.info("Source is read-only, converting to temporary file")
    if sys.version_info >= (3, 10):
        output_dir = TemporaryDirectory(ignore_cleanup_errors=True)
    else:
        output_dir = TemporaryDirectory()

    tmp_imx = Path(output_dir.name) / file_path.name
    convert_tar_to_v2(workspace, tmp_imx, model_hash=model_hash)
    extract_dir.cleanup()

    container = ImxContainer(str(tmp_imx))
    logger.info(f"Legacy model converted to temp: {tmp_imx}")
    return container, output_dir, False
