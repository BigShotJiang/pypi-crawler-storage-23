"""Video clip for the avatar video graph.

VideoClip is the single class for all video assets. Playback behavior is
determined by properties (loop, lip_sync, single_direction) rather than
by subclass type.
"""

from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

import cv2
import networkx as nx
import numpy as np
from loguru import logger


@dataclass(frozen=True, order=True)
class FrameRef:
    """A position in a video clip: (clip_name, frame_index)."""

    clip_name: str
    frame_index: int

    # Backward compat — runtime.py accesses .video_name
    @property
    def video_name(self) -> str:
        return self.clip_name


@dataclass(frozen=True, order=True)
class NodeID:
    """A graph node identifier."""

    video_name: str
    video_hash: str
    frame_index: int

    def __repr__(self) -> str:
        return f"{self.video_name}_{self.video_hash[:8]}_{self.frame_index}"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _probe_video_frames(metadata: dict, video_path: str, name: str) -> int:
    """Probe frame count from IMX container when metadata has frame_count=0."""
    container = metadata.get("_imx_container")
    video_file_key = metadata.get("_video_file_key", "")
    total = 0

    if container and video_file_key and container.has_file(video_file_key):
        try:
            if video_file_key.endswith(".mp4"):
                import av
                import io

                mp4_data = container.read_file(video_file_key)
                with av.open(io.BytesIO(mp4_data)) as cnt:
                    total = sum(1 for _ in cnt.decode(video=0))
                    s = cnt.streams.video[0]
                    metadata["_probed_resolution"] = (s.width, s.height)
            if total > 0:
                logger.debug(f"Probed {total} frames for '{name}' from {video_file_key}")
                return total
        except Exception as e:
            logger.debug(f"Failed to probe '{name}' from {video_file_key}: {e}")

    if os.path.isfile(video_path):
        cap = cv2.VideoCapture(video_path)
        try:
            if cap.isOpened():
                total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
                metadata["_probed_resolution"] = (
                    int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
                    int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)),
                )
        finally:
            cap.release()

    return total




def _find_video_data_path(video_path: str, file_hash: str) -> Optional[str]:
    video_path = Path(video_path)
    name = f"{video_path.name}.*_{file_hash[:8]}"
    for suffix in ["h5", "pth"]:
        files = list(video_path.parent.glob(name + f".{suffix}"))
        if files:
            return files[0].as_posix()
    return None


# ---------------------------------------------------------------------------
# VideoClip
# ---------------------------------------------------------------------------

class VideoClip:
    """A video asset loaded from the model.

    One class for all video types.  Playback behavior is determined by
    properties rather than inheritance:

    - ``loop=True``  — loops between frames (talking / idle video)
    - ``loop=False`` — plays once (action clips: walk, dance, wave …)
    - ``lip_sync``   — has lip-sync data (can be driven by audio)
    - ``single_direction`` — only plays forward
    """

    def __init__(
        self,
        name: str,
        video_path: str,
        video_data_path: Optional[str] = None,
        num_frames: Optional[int] = None,
        *,
        stride: int = 10,
        loop: bool = False,
        loop_between: Tuple[int, int] = (0, None),
        single_direction: bool = False,
        lip_sync: bool = True,
        stop_on_user_speech: bool = False,
        stop_on_agent_speech: bool = False,
        transition_frames: Optional[List[int]] = None,
        action_frame: int = -1,
        metadata: Optional[dict] = None,
    ) -> None:
        self.name = name
        self.video_path: str = video_path
        self.loop = loop
        self.lip_sync = lip_sync
        self.single_direction = single_direction
        self.stop_on_user_speech = stop_on_user_speech
        self.stop_on_agent_speech = stop_on_agent_speech

        # --- File metadata ---------------------------------------------------
        if metadata is not None:
            self.clip_hash = metadata["hash"]
            self.resolution = tuple(metadata["resolution"])
            total_num_frames = metadata["frame_count"]
            self.video_data_path: Optional[str] = (
                video_data_path or metadata.get("h5_file", "")
            )
            if total_num_frames == 0:
                total_num_frames = _probe_video_frames(metadata, video_path, name)
                if total_num_frames > 0 and self.resolution == (0, 0):
                    self.resolution = metadata.get("_probed_resolution", (0, 0))
        else:
            with open(video_path, "rb") as f:
                self.clip_hash = hashlib.md5(f.read()).hexdigest()
            self.video_data_path: Optional[str] = (
                video_data_path
                or _find_video_data_path(video_path, self.clip_hash)
            )
            cap = cv2.VideoCapture(video_path)
            try:
                if not cap.isOpened():
                    raise ValueError(f"Failed to open video: {video_path}")
                total_num_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
                self.resolution = (
                    int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
                    int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)),
                )
            finally:
                cap.release()

        if num_frames is not None:
            assert num_frames <= total_num_frames, (
                f"num_frames {num_frames} > total_num_frames {total_num_frames}"
            )
        else:
            num_frames = total_num_frames
        self.num_frames = num_frames
        self.frames: List[FrameRef] = [
            FrameRef(self.name, i) for i in range(num_frames)
        ]

        # --- Node setup (depends on playback mode) ---------------------------
        if loop:
            self._init_as_loop(stride, loop_between)
        else:
            self._init_as_action(transition_frames, action_frame)

    # ------------------------------------------------------------------
    # Initialization helpers
    # ------------------------------------------------------------------

    def _init_as_loop(self, stride: int, loop_between: Tuple[int, int]) -> None:
        """Set up nodes for a looping clip."""
        self._init_nodes(stride)
        self.transition_nodes: List[NodeID] = list(self.nodes)
        self.loop_direction = 1
        self._loop_start_node: Optional[NodeID] = None
        self._loop_end_node: Optional[NodeID] = None
        self.loop_between: Optional[Tuple[int, int]] = None
        self.set_loop_between(*loop_between)
        self._action_node: Optional[NodeID] = None

    def _init_as_action(
        self,
        custom_transition_frames: Optional[List[int]],
        action_frame: int,
    ) -> None:
        """Set up nodes for a one-shot action clip."""
        # stride=-1 → only first and last frame as nodes
        self._init_nodes(-1)

        tf = list(custom_transition_frames or [0])
        if self.single_direction:
            tf.append(-1)
        tf = [f if f >= 0 else len(self.frames) + f for f in tf]
        transition_node_ids = [
            NodeID(self.name, self.clip_hash, i) for i in set(tf)
        ]

        af = action_frame if action_frame >= 0 else len(self.frames) + action_frame
        self._action_node = NodeID(self.name, self.clip_hash, af)

        self.nodes = sorted(
            set(self.nodes + transition_node_ids + [self._action_node])
        )
        self.transition_nodes: List[NodeID] = sorted(transition_node_ids)

        # No loop state for action clips
        self.loop_direction = 1
        self._loop_start_node = None
        self._loop_end_node = None
        self.loop_between = None

    def _init_nodes(self, stride: int) -> None:
        if stride <= 0:
            stride = self.num_frames
        self.stride = stride
        self.nodes: List[NodeID] = [
            NodeID(self.name, self.clip_hash, i)
            for i in range(0, self.num_frames, stride)
        ]
        if self.nodes[-1].frame_index != self.num_frames - 1:
            self.nodes.append(
                NodeID(self.name, self.clip_hash, self.num_frames - 1)
            )

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def action_node(self) -> Optional[NodeID]:
        """The action node (None for looping clips)."""
        return self._action_node

    @property
    def clip_id(self) -> str:
        return f"{self.name}_{self.clip_hash[:8]}"

    @property
    def transition_frame_refs(self) -> List[FrameRef]:
        return [self.frames[node.frame_index] for node in self.transition_nodes]

    # ------------------------------------------------------------------
    # Backward-compatibility aliases
    # ------------------------------------------------------------------

    @property
    def video_name(self) -> str:
        return self.name

    @property
    def video_hash(self) -> str:
        return self.clip_hash

    @property
    def video_id(self) -> str:
        return self.clip_id

    @property
    def lip_sync_required(self) -> bool:
        return self.lip_sync

    @property
    def transition_frames(self) -> List[FrameRef]:
        return self.transition_frame_refs

    # ------------------------------------------------------------------
    # Node management
    # ------------------------------------------------------------------

    def remove_nodes(
        self, *, indices: List[int] = None, frame_indices: List[int] = None
    ) -> int:
        new_nodes = list(self.nodes)
        if indices:
            new_nodes = [
                n for idx, n in enumerate(new_nodes) if idx not in set(indices)
            ]
        if frame_indices:
            new_nodes = [
                n for n in new_nodes if n.frame_index not in set(frame_indices)
            ]
        removed = len(self.nodes) - len(new_nodes)
        self.nodes = new_nodes
        self.transition_nodes = list(self.nodes)
        return removed

    def insert_nodes(self, frame_indices: List[int]) -> None:
        new_nodes = [
            NodeID(self.name, self.clip_hash, idx)
            for idx in frame_indices
            if idx < self.num_frames
        ]
        self.nodes = sorted(set(self.nodes + new_nodes))
        self.transition_nodes = list(self.nodes)

    # ------------------------------------------------------------------
    # Loop management (only meaningful when loop=True)
    # ------------------------------------------------------------------

    def set_loop_between(self, start: Optional[int], end: Optional[int]) -> int:
        start = start or 0
        end = end or -1
        if end < 0:
            end = len(self.frames) + end
        self.loop_between = (max(0, start), min(len(self.frames) - 1, end))
        if self.loop_between[0] > self.loop_between[1]:
            raise ValueError(f"Invalid loop_between {self.loop_between}")

        self._loop_start_node = NodeID(
            self.name, self.clip_hash, self.loop_between[0]
        )
        self._loop_end_node = NodeID(
            self.name, self.clip_hash, self.loop_between[1]
        )

        if self._loop_start_node not in self.nodes:
            self.nodes = sorted(self.nodes + [self._loop_start_node])
        if self._loop_end_node not in self.nodes:
            self.nodes = sorted(self.nodes + [self._loop_end_node])

        return self.loop_between[1] - self.loop_between[0]

    # ------------------------------------------------------------------
    # Frame access
    # ------------------------------------------------------------------

    def get_frame_wh(self, scale_size: Optional[int] = None) -> Tuple[int, int]:
        if not scale_size:  # None or 0 → native resolution
            return self.resolution
        scale = scale_size / max(self.resolution)
        return (
            int(self.resolution[0] * scale),
            int(self.resolution[1] * scale),
        )

    def get_first_frame(self, scale_size: Optional[int] = None) -> np.ndarray:
        reader = getattr(self, "_original_frame_reader", None)
        if reader is not None:
            frame = reader.get(0)
            if scale_size:  # None or 0 → skip resize (native resolution)
                frame = cv2.resize(frame, self.get_frame_wh(scale_size))
            return frame

        cap = cv2.VideoCapture(str(self.video_path))
        try:
            if not cap.isOpened():
                raise ValueError(f"Failed to open video: {self.video_path}")
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            ret, frame = cap.read()
            if not ret:
                raise ValueError("Failed to read the first frame")
            if scale_size:  # None or 0 → skip resize (native resolution)
                frame = cv2.resize(frame, self.get_frame_wh(scale_size))
            return frame
        finally:
            cap.release()

    def collect_frames(
        self,
        source: NodeID | int,
        target: NodeID | int,
        allow_multi_steps: bool = True,
    ) -> List[FrameRef]:
        """Collect frames between two nodes (source inclusive, target exclusive)."""
        if isinstance(source, int):
            source = self.nodes[source]
        if isinstance(target, int):
            target = self.nodes[target]

        if (
            source.video_hash != self.clip_hash
            and target.video_hash != self.clip_hash
        ):
            return []

        if source.video_hash != self.clip_hash:
            return []

        if target.video_hash != self.clip_hash or (
            not allow_multi_steps
            and abs(source.frame_index - target.frame_index) > self.stride
        ):
            return [self.frames[source.frame_index]]

        stride = 1 if source.frame_index < target.frame_index else -1
        if self.single_direction and stride == -1:
            return []
        return self.frames[source.frame_index : target.frame_index : stride]

    # ------------------------------------------------------------------
    # Graph representation
    # ------------------------------------------------------------------

    def as_graph(self) -> nx.DiGraph:
        """Create a networkx graph from this clip's nodes."""
        graph = nx.DiGraph()
        graph.add_nodes_from(self.nodes)

        for i in range(1, len(self.nodes)):
            first, second = self.nodes[i - 1], self.nodes[i]
            distance = second.frame_index - first.frame_index
            graph.add_edge(first, second, distance=distance)
            if not self.single_direction:
                graph.add_edge(second, first, distance=distance)

        # Loop-back edge for forward-looping clips
        if self.loop and self.single_direction and self._loop_end_node:
            graph.add_edge(
                self._loop_end_node, self._loop_start_node, distance=0
            )

        return graph

    # ------------------------------------------------------------------
    # Playback: looping
    # ------------------------------------------------------------------

    def get_n_frames(
        self, min_n: int, start: NodeID, last_position: Optional[NodeID] = None
    ) -> Tuple[List[FrameRef], Optional[NodeID]]:
        """Get at least *min_n* frames with looping playback.

        Only valid for ``loop=True`` clips.
        Returns ``(frames, last_node)``.
        """
        if start.video_hash != self.clip_hash:
            logger.warning(
                f"Enter node is not from this clip: {start} != {self.clip_hash}"
            )
            return [], None
        if min_n <= 0:
            return [], None

        start_idx = self.nodes.index(start)
        if start_idx == -1:
            logger.warning(f"Node {start} is not in the nodes list")
            return [], None

        loop_start, loop_end = self.loop_between

        if self.single_direction:
            self.loop_direction = 1
        elif last_position and last_position.video_hash != self.clip_hash:
            left_frames = start.frame_index - loop_start
            right_frames = loop_end - start.frame_index
            self.loop_direction = 1 if right_frames > left_frames else -1

        frames: List[FrameRef] = []
        curr_node = start
        curr_idx = start_idx

        while len(frames) < min_n:
            if self.single_direction:
                if curr_node.frame_index >= loop_end:
                    next_node = self._loop_start_node
                    next_idx = self.nodes.index(self._loop_start_node)
                else:
                    next_idx = curr_idx + 1
                    next_node = self.nodes[next_idx]
            else:
                if curr_node.frame_index >= loop_end:
                    self.loop_direction = -1
                elif curr_node.frame_index <= loop_start:
                    self.loop_direction = 1
                next_idx = curr_idx + self.loop_direction
                next_node = self.nodes[next_idx]

            frames += self.collect_frames(curr_node, next_node)
            curr_node = next_node
            curr_idx = next_idx

        return frames, curr_node

    # ------------------------------------------------------------------
    # Playback: action (one-shot)
    # ------------------------------------------------------------------

    def get_action_frames(
        self, start: NodeID
    ) -> Tuple[List[FrameRef], Optional[NodeID]]:
        """Get all frames for the action sequence.

        Only valid for ``loop=False`` clips with an action_node.
        Returns ``(frames, last_transition_node)``.
        """
        if self._action_node is None:
            logger.warning(f"get_action_frames called on clip without action_node: {self.name}")
            return [], None
        if start.video_hash != self.clip_hash:
            logger.warning(
                f"Enter node is not from this clip: {start} != {self.clip_hash}"
            )
            return [], None

        start_idx = self.nodes.index(start)
        if start_idx == -1:
            logger.warning(f"Node {start} is not in the nodes list")
            return [], None

        path = [start, self._action_node, self.transition_nodes[-1]]
        frames: List[FrameRef] = []
        for i in range(1, len(path)):
            frames += self.collect_frames(
                path[i - 1], path[i], allow_multi_steps=True
            )
        return frames, path[-1]
