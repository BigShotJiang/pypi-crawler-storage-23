from . import trigger
from .clip import FrameRef, NodeID, VideoClip
from .graph import VideoGraph
from .video_script import VideoConfig, VideoConfigs, VideoScript

# Backward-compat aliases
Frame = FrameRef
DriverVideo = VideoClip
LoopingVideo = VideoClip
SingleActionVideo = VideoClip
VideoGraphNavigator = VideoGraph

__all__ = [
    "VideoClip",
    "FrameRef",
    "NodeID",
    "VideoGraph",
    "VideoConfigs",
    "VideoConfig",
    "VideoScript",
    "trigger",
    # Backward-compat
    "DriverVideo",
    "LoopingVideo",
    "SingleActionVideo",
    "VideoGraphNavigator",
    "Frame",
]
