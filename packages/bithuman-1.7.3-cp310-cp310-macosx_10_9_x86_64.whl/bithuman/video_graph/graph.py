"""VideoGraph — the central class for avatar video playback.

Owns clips, the transition graph, frame navigation, and idle scheduling.
Replaces the previous VideoGraphNavigator + VideoScript split.
"""

from __future__ import annotations

import hashlib
import shutil
from collections import OrderedDict
from contextlib import nullcontext
from pathlib import Path
from threading import Lock
from typing import Dict, List, Optional, Tuple, Union

import networkx as nx
import numpy as np
import yaml
from loguru import logger

from bithuman.config import Settings
from bithuman.engine.video_reader import ImxContainer
from bithuman.utils.unzip import unzip_tarfile

from .clip import FrameRef, NodeID, VideoClip
from .video_script import IdleAction, VideoConfig, VideoConfigs, VideoScript


class BoundedOrderedDict(OrderedDict):
    """OrderedDict with a maximum size that evicts the oldest entry on overflow."""

    def __init__(self, maxsize: int = 128, *args, **kwargs):
        self._maxsize = maxsize
        super().__init__(*args, **kwargs)

    def __setitem__(self, key, value):
        if key in self:
            self.move_to_end(key)
        super().__setitem__(key, value)
        while len(self) > self._maxsize:
            self.popitem(last=False)


class VideoGraph:
    """Central class that owns all video playback logic.

    Manages clips, the transition graph, frame buffer, pathfinding,
    and idle scheduling (previously split across VideoGraphNavigator
    and VideoScript).
    """

    CROSS_VIDEO_PENALTY = 30

    def __init__(
        self,
        avatar_model_path: Union[str, ImxContainer, Tuple],
        video_configs: VideoConfigs = None,
    ) -> None:
        self.clips: Dict[str, VideoClip] = {}
        self.filler_clips: Dict[str, VideoClip] = {}

        self._video_configs = video_configs or VideoConfigs(videos=[])

        # Workspace directory or ImxContainer
        self.imx_container: Optional[ImxContainer] = None
        if isinstance(avatar_model_path, ImxContainer):
            self.imx_container = avatar_model_path
            self.avatar_model_path = avatar_model_path.path
            self.temp_dir = None
        elif isinstance(avatar_model_path, tuple):
            first = avatar_model_path[0]
            if isinstance(first, ImxContainer):
                self.imx_container = first
                self.avatar_model_path = first.path
            else:
                self.avatar_model_path = first
            self.temp_dir = avatar_model_path[1]
        else:
            self.avatar_model_path = avatar_model_path
            self.temp_dir = None
        self.filler_frames_dir = Path(self.avatar_model_path) / "filler_videos"
        self.similarity_cache_dir = Path(self.avatar_model_path) / "similarities"

        # Similarity matrices between two clips (bounded to prevent unbounded growth)
        self.similarity_matrices: BoundedOrderedDict = BoundedOrderedDict(maxsize=64)

        # Graph and frame buffer for output
        self.graph = nx.DiGraph()
        self.curr_node: Optional[NodeID] = None
        self.frame_buffer: List[FrameRef] = []

        # Edge-triggered speech state
        self._prev_user_speech = False
        self._prev_agent_speech = False

        # Path cache (bounded to prevent unbounded growth)
        self.path_cache: BoundedOrderedDict = BoundedOrderedDict(maxsize=256)

    # ------------------------------------------------------------------
    # Backward-compat aliases
    # ------------------------------------------------------------------

    @property
    def videos(self) -> Dict[str, VideoClip]:
        """Backward-compat alias for clips."""
        return self.clips

    @property
    def filler_videos(self) -> Dict[str, VideoClip]:
        """Backward-compat alias for filler_clips."""
        return self.filler_clips


    # ------------------------------------------------------------------
    # VideoScript proxy — idle scheduling absorbed into VideoGraph
    # ------------------------------------------------------------------

    @property
    def _script(self) -> VideoScript:
        return self._video_configs.videos_script

    @property
    def videos_script(self) -> VideoScript:
        """Backward-compat access to the internal VideoScript."""
        return self._script

    @property
    def default_video(self) -> Optional[str]:
        return self._script.default_video

    @property
    def idle_actions(self) -> List[IdleAction]:
        return self._script.idle_actions

    @property
    def back_to_idle(self) -> float:
        return self._script.BACK_TO_IDLE

    @back_to_idle.setter
    def back_to_idle(self, value: float) -> None:
        self._script.BACK_TO_IDLE = value

    @property
    def fps(self) -> float:
        return self._script.FPS

    def set_next_idle_action(self, action: Optional[IdleAction] = None) -> None:
        self._script.set_next_idle_action(action)

    def get_video_and_actions(
        self,
        curr_frame_index: int,
        emotions=None,
        text: str = None,
        is_idle: bool = False,
        settings: Settings = None,
    ) -> Tuple[Optional[str], List[str], bool]:
        """Determine target video and actions based on idle state / emotions.

        Returns ``(target_video, actions, reset_action)``.
        """
        return self._script.get_video_and_actions(
            curr_frame_index, emotions, text=text, is_idle=is_idle, settings=settings
        )

    def on_end_of_speech(self) -> None:
        """Called when speech ends.  Resets idle timer and buffer."""
        self._script.last_nonidle_frame = 0
        self.next_n_frames(num_frames=0, on_user_speech=True)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def cleanup(self):
        if self.temp_dir:
            temp_path = Path(self.temp_dir.name)
            try:
                self.temp_dir.cleanup()
            except OSError:
                if temp_path.exists():
                    shutil.rmtree(temp_path, ignore_errors=True)
        self.temp_dir = None

    def __del__(self):
        self.cleanup()

    def update_runtime_configs(self, settings: Settings):
        self._video_configs.update_runtime_configs(settings)

    # ------------------------------------------------------------------
    # Clip queries
    # ------------------------------------------------------------------

    def clip_exists(self, name: str, is_action: bool = None) -> bool:
        """Check if a clip exists.

        Args:
            name: Clip name.
            is_action: ``True`` — only action clips; ``False`` — only looping;
                ``None`` — either.
        """
        if name not in self.clips:
            return False
        if is_action is None:
            return True
        return (not self.clips[name].loop) == is_action

    @property
    def action_clips(self) -> List[VideoClip]:
        return [c for c in self.clips.values() if not c.loop]

    @property
    def action_videos(self) -> List[VideoClip]:
        """Backward-compat alias for action_clips."""
        return self.action_clips

    @property
    def action_video_names(self) -> List[str]:
        return [c.name for c in self.action_clips]

    # ------------------------------------------------------------------
    # Factory methods
    # ------------------------------------------------------------------

    @classmethod
    def from_single_video(
        cls, video_file: str, inference_data_file: str = None
    ) -> "VideoGraph":
        video_configs = VideoConfigs.from_videofile(video_file, inference_data_file)
        return cls(
            avatar_model_path=Path(video_file).parent,
            video_configs=video_configs,
        )

    @classmethod
    def from_workspace(
        cls,
        avatar_model_path: str,
        video_config_file: str = None,
        extract_to_local: bool = False,
    ) -> "VideoGraph":
        """Create a VideoGraph from the model.

        All formats (IMX v2, legacy TAR, directories) are resolved to an
        ``ImxContainer`` by ``unzip_tarfile()``.
        """
        logger.info(f"Loading model from {avatar_model_path}")

        if isinstance(avatar_model_path, ImxContainer):
            container = avatar_model_path
            temp_dir = None
        else:
            result, temp_dir, _ = unzip_tarfile(
                avatar_model_path, extract_to_local=extract_to_local
            )
            if isinstance(result, ImxContainer):
                container = result
            else:
                # Plain directory — load from filesystem
                avatar_model_path_str = result
                video_config_file = video_config_file or Path(avatar_model_path_str) / "videos.yaml"
                if Path(video_config_file).exists():
                    video_configs = VideoConfigs.from_yaml(video_config_file)
                elif (Path(avatar_model_path_str) / "videos").exists():
                    video_configs = VideoConfigs.from_videofolder(
                        Path(avatar_model_path_str) / "videos"
                    )
                else:
                    files = list(Path(avatar_model_path_str).glob("*"))
                    raise FileNotFoundError(
                        f"model not found in {avatar_model_path_str}, files: {files}"
                    )
                for video in video_configs.videos:
                    video.video_file = str(
                        Path(avatar_model_path_str).absolute() / video.video_file
                    )
                return cls(
                    avatar_model_path=(avatar_model_path_str, temp_dir),
                    video_configs=video_configs,
                )

        # IMX v2 container path
        metadata = container.metadata

        video_list = []
        for vname, vmeta in metadata["videos"].items():
            graph_cfg = vmeta.get("graph", {})
            vc = VideoConfig(
                name=vname,
                video_file=vmeta.get("video_file", f"videos/{vname}.mp4"),
                video_type=vmeta.get("type", "LoopingVideo"),
                stride=vmeta.get("stride", 10),
                single_direction=vmeta.get("single_direction", False),
                stop_on_user_speech=vmeta.get("stop_on_user_speech", False),
                stop_on_agent_speech=vmeta.get("stop_on_agent_speech", False),
                transition_frames=vmeta.get("transition_frames"),
                action_frame=vmeta.get("action_frame", -1),
                lip_sync_required=bool(vmeta.get("lip_sync")),
                adding_kwargs={
                    "edge_threshold": graph_cfg.get("edge_threshold", 0.7),
                    "connects_to": graph_cfg.get("connects_to"),
                },
            )
            vc._imx_metadata = {
                "hash": vmeta.get("video_hash", ""),
                "frame_count": vmeta.get("frame_count", 0),
                "resolution": vmeta.get("resolution", [0, 0]),
                "h5_file": vmeta.get("lip_sync", {}).get("h5_file", ""),
                "_imx_container": container,
                "_video_file_key": vmeta.get("video_file", ""),
            }
            video_list.append(vc)

        script_data = metadata.get("script", {})
        videos_script = VideoScript(
            default_video=script_data.get("default_video"),
            action_hi_video=script_data.get("action_hi_video"),
            idle_actions=[
                IdleAction.from_dict(ia)
                for ia in script_data.get("idle_actions", [])
            ],
            FPS=script_data.get("fps", 25),
            BACK_TO_IDLE=script_data.get("back_to_idle", 10),
        )

        video_configs = VideoConfigs(videos=video_list, videos_script=videos_script)
        return cls(
            avatar_model_path=(container, temp_dir),
            video_configs=video_configs,
        )

    def load_workspace(
        self, prepare_filler_frames: bool = True
    ) -> "VideoGraph":
        """Load the clips from workspace."""
        clips = self._video_configs.load_videos(video_root=self.avatar_model_path)
        for clip, config in zip(clips, self._video_configs.videos):
            self.add_clip(clip, **config.adding_kwargs)
        if prepare_filler_frames:
            self.load_filler_frames_for_allnodes()
        self._prune_disconnected_clips()
        return self

    def _prune_disconnected_clips(self) -> None:
        """Remove unreachable action clips from idle_actions."""
        looping = [c for c in self.clips.values() if c.loop]
        if not looping:
            return
        # Use the first looping clip as the connectivity reference
        ref_node = looping[0].nodes[0]
        for idle_action in list(self._script.idle_actions):
            reachable = []
            for action_name in idle_action.actions:
                clip = self.clips.get(action_name)
                if clip is None:
                    continue
                target = clip.action_node or clip.nodes[0]
                if target in self.path_cache.get(ref_node, {}):
                    reachable.append(action_name)
                else:
                    logger.warning(
                        f"Removing unreachable clip '{action_name}' from "
                        f"idle_actions (no path from {looping[0].name})"
                    )
            idle_action.actions = reachable
        # Drop empty idle_actions
        self._script.idle_actions = [
            ia for ia in self._script.idle_actions if ia.actions
        ]

    # ------------------------------------------------------------------
    # Graph building
    # ------------------------------------------------------------------

    def update_path_cache(self):
        self.path_cache.clear()
        for source in self.graph.nodes:
            distance, path = nx.single_source_dijkstra(
                self.graph, source, weight="distance"
            )
            self.path_cache[source] = {
                target: (distance[target], path[target]) for target in path
            }

    def single_source_multi_target_dijkstra(
        self, source: NodeID, targets: List[NodeID]
    ) -> Tuple[float, List[NodeID]]:
        paths = [
            self.path_cache[source][target]
            for target in targets
            if target in self.path_cache[source]
        ]
        if not paths:
            raise nx.NetworkXNoPath(f"No path found from {source} to {targets}")
        return min(paths, key=lambda x: x[0])

    def reset_buffer(self) -> None:
        self.curr_node = None
        self.frame_buffer = []

    def add_edge(
        self,
        source_node: NodeID,
        target_node: NodeID,
        distance: float,
        num_filler_frames: int = 0,
        single_direction: bool = False,
        cross_video: bool = False,
    ) -> None:
        if cross_video:
            distance += self.CROSS_VIDEO_PENALTY
        metadata = {
            "distance": distance,
            "num_filler_frames": num_filler_frames,
            "cross_video": cross_video,
        }
        self.graph.add_edge(source_node, target_node, **metadata)
        if not single_direction:
            self.graph.add_edge(target_node, source_node, **metadata)

    def get_first_frame(self, output_size: Optional[int] = None) -> np.ndarray:
        if not self.clips:
            raise ValueError("No clips added.")
        clip = next(iter(self.clips.values()))
        return clip.get_first_frame(output_size)

    def get_frame_wh(self, output_size: Optional[int] = None) -> Tuple[int, int]:
        if not self.clips:
            raise ValueError("No clips added.")
        clip = next(iter(self.clips.values()))
        return clip.get_frame_wh(output_size)

    @property
    def num_frames(self) -> int:
        return sum(len(c.frames) for c in self.clips.values())

    @property
    def num_nodes(self) -> int:
        return self.graph.number_of_nodes()

    @property
    def num_edges(self) -> int:
        return self.graph.number_of_edges()

    @property
    def edges_with_filler_frames(self) -> List[Tuple[NodeID, NodeID]]:
        edges = []
        seen = set()
        for source, target in self.graph.edges:
            if not self.graph[source][target].get("num_filler_frames"):
                continue
            key = tuple(sorted([source, target]))
            if key in seen:
                continue
            seen.add(key)
            edges.append((source, target))
        return edges

    @property
    def num_filler_frames(self) -> int:
        return sum(
            self.graph[s][t]["num_filler_frames"]
            for s, t in self.edges_with_filler_frames
        )

    # ------------------------------------------------------------------
    # Similarity & filler frames
    # ------------------------------------------------------------------

    def load_similarity_matrix(
        self, clip1: VideoClip, clip2: VideoClip
    ) -> np.ndarray:
        import io

        sorted_clips = sorted([clip1, clip2], key=lambda c: c.clip_id)
        transition_frames = [
            [n.frame_index for n in c.transition_nodes] for c in sorted_clips
        ]
        nodes_hash = hashlib.md5(str(transition_frames).encode()).hexdigest()
        sim_filename = (
            f"{sorted_clips[0].clip_id}-{sorted_clips[1].clip_id}"
            f"-{nodes_hash[:8]}.npy"
        )

        if self.imx_container is not None:
            for imx_path in [
                f"graph/similarities/{sim_filename}",
                f"similarities/{sim_filename}",
            ]:
                if self.imx_container.has_file(imx_path):
                    data = self.imx_container.read_file(imx_path)
                    sim_matrix = np.load(io.BytesIO(data))
                    if sorted_clips[0].clip_id == clip1.clip_id:
                        return sim_matrix
                    else:
                        return sim_matrix.T

        sim_cache_file = Path(self.similarity_cache_dir) / sim_filename
        if not Path(sim_cache_file).exists():
            raise FileNotFoundError(
                f"Similarity matrix not found between {clip1.name} and {clip2.name}."
            )
        sim_matrix = np.load(sim_cache_file)
        if sorted_clips[0].clip_id == clip1.clip_id:
            return sim_matrix
        else:
            return sim_matrix.T

    def load_filler_frames_for_allnodes(self) -> "VideoGraph":
        logger.trace(
            f"Load filler frames for {len(self.edges_with_filler_frames)} edges, "
            f"total {self.num_filler_frames} frames.",
        )
        for source, target in self.edges_with_filler_frames:
            self.load_filler_frames(source, target)
        self.update_path_cache()
        return self

    def load_filler_frames(
        self, source_node: NodeID, target_node: NodeID, lock: Lock = None
    ) -> int:
        edge = self.graph.get_edge_data(source_node, target_node)
        if not edge or not edge.get("num_filler_frames"):
            return 0

        lock = lock or nullcontext()
        num_filler_frames = edge["num_filler_frames"]

        filler_name = self._get_filler_video_name(source_node, target_node)
        filler_video_path = self._get_filler_video_path(source_node, target_node)
        if not Path(filler_video_path).exists():
            logger.warning(
                f"Filler video {filler_video_path} not found, "
                f"skip {num_filler_frames} filler frames between "
                f"{source_node} and {target_node}."
            )
            # Zero out filler expectation so distance matches actual frames
            with lock:
                self.graph[source_node][target_node]["num_filler_frames"] = 0
                self.graph[source_node][target_node]["distance"] = (
                    1 + self.CROSS_VIDEO_PENALTY
                )
                # Also fix reverse edge if it exists
                rev = self.graph.get_edge_data(target_node, source_node)
                if rev and rev.get("num_filler_frames"):
                    rev["num_filler_frames"] = 0
                    rev["distance"] = 1 + self.CROSS_VIDEO_PENALTY
            return 0

        filler_clip = VideoClip(name=filler_name, video_path=filler_video_path)
        self.filler_clips[filler_name] = filler_clip

        with lock:
            self.graph[source_node][target_node]["distance"] = (
                1 + filler_clip.num_frames + self.CROSS_VIDEO_PENALTY
            )
        return filler_clip.num_frames

    def _get_filler_video_name(self, source: NodeID, target: NodeID) -> str:
        key = tuple(sorted([source, target]))
        n1, n2 = key
        return f"Filler_{n1}-{n2}"

    def _get_filler_video_path(self, source: NodeID, target: NodeID) -> str:
        key = tuple(sorted([source, target]))
        n1, n2 = key
        return str(self.filler_frames_dir / f"{n1}-{n2}.mp4")

    def get_filler_frames(
        self, source_node: NodeID, target_node: NodeID
    ) -> List[FrameRef]:
        edge = self.graph.get_edge_data(source_node, target_node)
        if edge is None or not edge.get("num_filler_frames"):
            return []

        filler_name = self._get_filler_video_name(source_node, target_node)
        if filler_name not in self.filler_clips:
            logger.warning(
                f"Filler clip not found between {source_node} and {target_node}. "
                f"Expected {edge['num_filler_frames']} frames."
            )
            return []

        frames = self.filler_clips[filler_name].frames.copy()
        if source_node > target_node:
            frames = frames[::-1]
        return frames

    # ------------------------------------------------------------------
    # Clip management
    # ------------------------------------------------------------------

    def add_clip(
        self,
        clip: VideoClip,
        edge_threshold: float = 0.7,
        connects_to: List[str] = None,
        num_filler_frames: int = None,
    ) -> None:
        """Add a clip to the graph and connect it to existing clips."""
        if clip.name in self.clips:
            raise ValueError(f"Clip {clip.name} is already added.")

        self.clips[clip.name] = clip
        self.graph.update(clip.as_graph())

        for other in self.clips.values():
            if other.clip_hash == clip.clip_hash:
                continue
            if connects_to and other.name not in connects_to:
                continue
            self.connect_two_clips(
                other, clip,
                edge_threshold=edge_threshold,
                num_filler_frames=num_filler_frames,
            )
        self.update_path_cache()

    # Backward compat
    add_video = add_clip

    def connect_two_clips(
        self,
        clip1: VideoClip,
        clip2: VideoClip,
        edge_threshold: float = 0.7,
        num_filler_frames: int = None,
    ) -> int:
        if clip1.clip_hash == clip2.clip_hash:
            return 0

        key = (clip1.clip_id, clip2.clip_id)
        if key not in self.similarity_matrices:
            sim_matrix = self.load_similarity_matrix(clip1, clip2)
            self.similarity_matrices[key] = sim_matrix
            self.similarity_matrices[key[::-1]] = sim_matrix.T

        sim_matrix = self.similarity_matrices[key]

        def get_num_fillers(similarity: float):
            if similarity > 0.98:
                return 0
            if similarity > 0.80:
                return 3
            if similarity > 0.70:
                return 7
            return 7

        new_edges = set()

        def connect(c1: VideoClip, c2: VideoClip, sm):
            sm = sm.copy()
            # Action clip with single_direction: only nodes after action_node are out-nodes
            if not c1.loop and c1.single_direction and c1.action_node:
                invalid = [
                    i for i, n in enumerate(c1.transition_nodes)
                    if n < c1.action_node
                ]
                sm[invalid] = -1
            # Action clip: only nodes before action_node are in-nodes
            if not c2.loop and c2.action_node:
                invalid = [
                    i for i, n in enumerate(c2.transition_nodes)
                    if n >= c2.action_node
                ]
                sm[:, invalid] = -1

            argmax = np.argmax(sm, axis=1)
            indices = [(i, j, sm[i, j]) for i, j in enumerate(argmax)]
            indices = [x for x in indices if x[2] > edge_threshold]

            for i, j, score in indices:
                edge_fillers = (
                    get_num_fillers(score)
                    if num_filler_frames is None
                    else num_filler_frames
                )
                self.add_edge(
                    c1.transition_nodes[i],
                    c2.transition_nodes[j],
                    distance=edge_fillers + 1,
                    num_filler_frames=edge_fillers,
                    single_direction=True,
                    cross_video=c1.clip_id != c2.clip_id,
                )
                k = tuple(sorted([c1.transition_nodes[i], c2.transition_nodes[j]]))
                new_edges.add(k)

        connect(clip1, clip2, sim_matrix)
        connect(clip2, clip1, sim_matrix.T)

        logger.trace(
            f"Connect {clip1.name} and {clip2.name}, {len(new_edges)} edges."
        )

    # Backward compat
    connect_two_videos = connect_two_clips

    # ------------------------------------------------------------------
    # Pathfinding
    # ------------------------------------------------------------------

    def find_path(
        self, source: NodeID, target: str | NodeID
    ) -> Tuple[float, List[NodeID]]:
        def count_cross_video_penalty(path: List[NodeID]) -> int:
            penalty = 0
            for i in range(1, len(path)):
                edge = self.graph.get_edge_data(path[i - 1], path[i])
                if edge is None or not edge.get("cross_video"):
                    continue
                penalty += self.CROSS_VIDEO_PENALTY
            return penalty

        if isinstance(target, NodeID):
            distance, path = self.single_source_multi_target_dijkstra(source, [target])
            return distance - count_cross_video_penalty(path), path

        target_clip = self.clips[target]
        if target_clip.clip_hash == source.video_hash:
            return 0, [source]

        distance, path = self.single_source_multi_target_dijkstra(
            source, target_clip.transition_nodes
        )
        return distance - count_cross_video_penalty(path), path

    def collect_path_frames(self, path: List[NodeID]) -> List[FrameRef]:
        frames: List[FrameRef] = []
        for i in range(len(path) - 1):
            source, target = path[i], path[i + 1]
            frames += self.clips[source.video_name].collect_frames(source, target)
            frames += self.get_filler_frames(source, target)
        return frames

    # ------------------------------------------------------------------
    # Frame collection
    # ------------------------------------------------------------------

    def collect_n_frames(
        self,
        min_n: int,
        target_video_name: str = None,
        actions_name: List[str] | str = None,
    ) -> List[FrameRef]:
        target_video_name, actions_name = self.filter_video_names(
            target_video_name, actions_name
        )
        if min_n <= 0 and not actions_name and not target_video_name:
            return []

        if self.curr_node is None:
            if target_video_name is None:
                self.curr_node = list(self.clips.values())[0].nodes[0]
                logger.trace(
                    f"Current node not set, using first node of "
                    f"{self.curr_node.video_name}."
                )
            else:
                self.curr_node = self.clips[target_video_name].nodes[0]

        target_video_name = target_video_name or self.curr_node.video_name
        target_clips = [self.clips[target_video_name]]

        if isinstance(actions_name, str):
            actions_name = [actions_name]
        if actions_name:
            target_clips = [self.clips[n] for n in actions_name] + target_clips

        assert target_clips[-1].loop, (
            "The final target clip must be a looping clip"
        )

        total_path = [self.curr_node]
        total_distance = 0
        for clip in target_clips:
            target = (
                clip.action_node if clip.action_node else clip.name
            )
            try:
                distance, path = self.find_path(total_path[-1], target)
            except nx.NetworkXNoPath:
                if clip.loop:
                    raise  # looping target is required — cannot skip
                logger.warning(
                    f"Skipping unreachable action clip '{clip.name}' "
                    f"(no path from {total_path[-1]})"
                )
                continue
            total_path += path[1:]
            total_distance += distance

        frames = self.collect_path_frames(total_path)
        if total_distance != len(frames):
            logger.warning(
                f"Distance mismatch: {total_distance} != {len(frames)}, "
                f"Path: {total_path}"
            )

        n_left = min_n - len(frames)
        last_node = total_path[-2] if len(total_path) > 1 else None
        target_frames, last_node = target_clips[-1].get_n_frames(
            n_left, start=total_path[-1], last_position=last_node
        )
        frames += target_frames
        self.curr_node = last_node or total_path[-1]

        logger.trace(
            f"Path: {total_path} -> {self.curr_node}, path len: {total_distance}, "
            f"rest: {len(target_frames)}, total: {len(frames)}/{min_n}"
        )
        return frames

    def next_n_frames(
        self,
        num_frames: int,
        target_video_name: str = None,
        actions_name: List[str] | str = None,
        on_user_speech: bool = False,
        on_agent_speech: bool = False,
        stop_on_user_speech_override: Optional[bool] = None,
        stop_on_agent_speech_override: Optional[bool] = None,
    ) -> List[FrameRef]:
        """Get the next *num_frames* frames from the graph."""
        user_speech_onset = on_user_speech and not self._prev_user_speech
        agent_speech_onset = on_agent_speech and not self._prev_agent_speech
        self._prev_user_speech = on_user_speech
        self._prev_agent_speech = on_agent_speech

        if self.frame_buffer:
            buffered_clip_name = self.frame_buffer[0].clip_name
            clip = self.clips.get(buffered_clip_name)

            if target_video_name and buffered_clip_name != target_video_name:
                self.reset_buffer()
                logger.trace(
                    f"Cleared buffer: target changed from {buffered_clip_name} to {target_video_name}"
                )
            elif clip:
                stop_on_user = (
                    stop_on_user_speech_override
                    if stop_on_user_speech_override is not None
                    else clip.stop_on_user_speech
                )
                stop_on_agent = (
                    stop_on_agent_speech_override
                    if stop_on_agent_speech_override is not None
                    else clip.stop_on_agent_speech
                )
                if (user_speech_onset and stop_on_user) or (
                    agent_speech_onset and stop_on_agent
                ):
                    self.reset_buffer()
                    logger.trace(
                        f"Stop on {clip.name} because of "
                        f"{user_speech_onset=} or {agent_speech_onset=} "
                        f"(stop_on_user={stop_on_user}, stop_on_agent={stop_on_agent})"
                    )

        if num_frames <= 0:
            return []

        min_n = num_frames - len(self.frame_buffer)
        self.frame_buffer += self.collect_n_frames(
            min_n, target_video_name=target_video_name, actions_name=actions_name
        )
        frames = self.frame_buffer[:num_frames]
        self.frame_buffer = self.frame_buffer[num_frames:]
        return frames

    # ------------------------------------------------------------------
    # generate_frame — the primary single-frame API
    # ------------------------------------------------------------------

    def generate_frame(
        self,
        target_video: str = None,
        action: str | List[str] = None,
        on_user_speech: bool = False,
        on_agent_speech: bool = False,
        stop_on_user_speech_override: Optional[bool] = None,
        stop_on_agent_speech_override: Optional[bool] = None,
    ) -> FrameRef:
        """Get the next frame position from the graph.

        This is the primary frame-by-frame API.  It wraps
        ``next_n_frames(1, ...)`` for convenience.
        """
        frames = self.next_n_frames(
            num_frames=1,
            target_video_name=target_video,
            actions_name=action,
            on_user_speech=on_user_speech,
            on_agent_speech=on_agent_speech,
            stop_on_user_speech_override=stop_on_user_speech_override,
            stop_on_agent_speech_override=stop_on_agent_speech_override,
        )
        return frames[0] if frames else None

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    def filter_video_names(
        self, target_video: Optional[str], actions: Optional[List[str] | str]
    ) -> Tuple[Optional[str], Optional[List[str]]]:
        if target_video:
            if not self.clip_exists(target_video, is_action=False):
                logger.warning(f"Invalid video name: {target_video}")
                target_video = None

        if actions:
            if isinstance(actions, str):
                actions = [actions]
            valid = [a for a in actions if self.clip_exists(a, is_action=True)]
            for a in actions:
                if a not in [v for v in valid]:
                    logger.warning(f"Invalid action name: {a}")
            actions = valid
        return target_video, actions
