"""Asynchronous wrapper for Bithuman Runtime."""

from __future__ import annotations

import asyncio
import queue
import threading
import time
from pathlib import Path
from typing import AsyncIterator, Optional, Union

from loguru import logger

from .api import VideoControl, VideoFrame
from .engine.auth import DEFAULT_AUTH_URL
from .exceptions import TokenExpiredError, TokenValidationError
from .runtime import Bithuman, BufferEmptyCallback

# Sentinel to signal end of frame stream
_STREAM_END = object()


class AsyncBithuman(Bithuman):
    """Asynchronous wrapper for Bithuman Runtime.

    This class wraps the synchronous BithumanRuntime to provide an asynchronous interface.
    It runs the runtime in a separate thread to avoid blocking the asyncio event loop.
    """

    def __init__(
        self,
        *,
        model_path: Optional[str] = None,
        token: Optional[str] = None,
        api_secret: Optional[str] = None,
        api_url: str = DEFAULT_AUTH_URL,
        tags: Optional[str] = "bithuman",
        insecure: bool = False,
        input_buffer_size: int = 0,
        output_buffer_size: int = 5,
        load_model: bool = False,
        num_threads: int = 0,
        verbose: Optional[bool] = None,
        batch_workers: int = 1,
    ) -> None:
        """Initialize the async runtime with a BithumanRuntime instance.

        Args:
            model_path: The path to the avatar model.
            token: The token for the Bithuman Runtime. Either token or api_secret must be provided.
            api_secret: API Secret for API authentication. Either token or api_secret must be provided.
            api_url: API endpoint URL for token requests.
            tags: Optional tags for token request.
            insecure: Disable SSL certificate verification (not recommended for production use).
            input_buffer_size: Size of the input buffer.
            output_buffer_size: Size of the output buffer.
            load_model: If True, load the model synchronously.
            num_threads: Number of threads for processing, 0 = single-threaded, >0 = use specified number of threads, <0 = auto-detect optimal thread count
            verbose: Enable verbose logging for token validation. If None, reads from BITHUMAN_VERBOSE environment variable.
            batch_workers: Number of parallel workers for offline batch processing (1 = sequential).
        """
        # Call parent init WITHOUT the model_path parameter
        # This prevents parent's __init__ from calling set_model()
        logger.debug(
            f"Initializing AsyncBithuman with token={token is not None}, api_secret={api_secret is not None}, verbose={verbose}"
        )
        super().__init__(
            input_buffer_size=input_buffer_size,
            token=token,
            model_path=None,  # Important: Pass None here
            api_secret=api_secret,
            api_url=api_url,
            tags=tags,
            insecure=insecure,
            verbose=verbose,
            num_threads=num_threads,
            batch_workers=batch_workers,
        )

        # Store the model path for later use
        self._model_path = model_path

        self._model_hash = None

        # Thread management
        self._stop_event = threading.Event()
        self._thread = None

        # Thread-safe queue for cross-thread frame passing (producer thread → async consumer)
        # Using queue.Queue avoids per-frame Future creation overhead of asyncio.run_coroutine_threadsafe
        self._frame_queue: queue.Queue[Union[VideoFrame, Exception, object]] = queue.Queue(
            maxsize=output_buffer_size
        )

        # State
        self._running = False
        self._loop: Optional[asyncio.AbstractEventLoop] = None

        if load_model:
            self._initialize_token_sync()
            super().set_model(model_path)

    @classmethod
    async def create(
        cls,
        *,
        model_path: Optional[str] = None,
        token: Optional[str] = None,
        api_secret: Optional[str] = None,
        api_url: str = DEFAULT_AUTH_URL,
        tags: Optional[str] = "bithuman",
        insecure: bool = False,
        input_buffer_size: int = 0,
        output_buffer_size: int = 5,
        num_threads: int = 0,
        verbose: Optional[bool] = None,
        batch_workers: int = 1,
    ) -> "AsyncBithuman":
        """Create a fully initialized AsyncBithuman instance asynchronously.

        Token refresh will start lazily when start() is called if api_secret is provided.
        This prevents unnecessary token requests during prewarm/initialization.
        """
        # Create instance with initial parameters but defer model setting
        instance = cls(
            model_path=None,  # Will set model later
            token=token,
            api_secret=api_secret,
            api_url=api_url,
            tags=tags,
            insecure=insecure,
            input_buffer_size=input_buffer_size,
            output_buffer_size=output_buffer_size,
            verbose=verbose,
            batch_workers=batch_workers,
        )

        if model_path:
            instance._model_path = model_path
            await instance._initialize_token()
            await instance.set_model(model_path)

        return instance

    async def set_model(self, model_path: str | None = None) -> "AsyncBithuman":
        """Set the avatar model for the runtime.

        Args:
            model_path: The path to the avatar model. If None, uses the model_path provided during initialization.
        """
        # Use the model path provided during initialization if none is provided
        model_path = model_path or self._model_path

        if not model_path:
            logger.error("No model path provided for set_model")
            raise ValueError(
                "Model path must be provided either during initialization or when calling set_model"
            )

        # Store the model path for token requests
        self._model_path = model_path

        # Now run the set_model in the executor and wait for it to finish
        loop = self._loop or asyncio.get_running_loop()
        try:
            await loop.run_in_executor(None, super().set_model, model_path)
        except Exception as e:
            logger.error(f"Error in parent set_model: {e}")
            raise

        return self

    async def push_audio(
        self, data: bytes, sample_rate: int, last_chunk: bool = True
    ) -> None:
        """Push audio data to the runtime asynchronously.

        Args:
            data: Audio data in bytes.
            sample_rate: Sample rate of the audio.
            last_chunk: Whether this is the last chunk of the speech.
        """
        control = VideoControl.from_audio(data, sample_rate, last_chunk)
        await self._input_buffer.aput(control)

    async def push(self, control: VideoControl) -> None:
        """Push a VideoControl to the runtime asynchronously.

        Args:
            control: The VideoControl to push.
        """
        await self._input_buffer.aput(control)

    async def flush(self) -> None:
        """Flush the audio buffer, indicating end of speech."""
        await self._input_buffer.aput(VideoControl(end_of_speech=True))

    async def run(
        self,
        out_buffer_empty: Optional[BufferEmptyCallback] = None,
        *,
        idle_timeout: float | None = None,
        loop: Optional[asyncio.AbstractEventLoop] = None,
    ) -> AsyncIterator[VideoFrame]:
        """Stream video frames asynchronously.

        Yields:
            VideoFrame objects from the runtime.
        """
        # Start the runtime if not already running
        await self.start(
            out_buffer_empty=out_buffer_empty,
            idle_timeout=idle_timeout,
            loop=loop,
        )

        try:
            loop = asyncio.get_running_loop()
            while True:
                # Get the next frame from the thread-safe queue via executor.
                # Use a timeout so we can detect if the producer thread died
                # without sending _STREAM_END (e.g., crashed or was killed).
                try:
                    item = await loop.run_in_executor(
                        None, lambda: self._frame_queue.get(timeout=1.0)
                    )
                except queue.Empty:
                    # Timed out — check if the producer thread is still alive
                    if self._thread is None or not self._thread.is_alive():
                        logger.warning("Frame producer thread is no longer alive, ending stream")
                        break
                    # Producer is still running, just no frames yet — retry
                    continue

                # Check for stream end sentinel
                if item is _STREAM_END:
                    break

                # If we got an exception, raise it
                if isinstance(item, Exception):
                    if self._is_token_error(item):
                        logger.error(f"Token error in async run loop: {item}")
                        await self.stop()
                    raise item

                # Yield the frame
                yield item

        except asyncio.CancelledError:
            # Stream was cancelled, stop the runtime
            await self.stop()
            raise

    async def _initialize_token(self) -> None:
        """Initialize token if provided by user.

        If user provided a token, validate and set it.
        If user provided api_secret, token refresh is handled automatically.
        """
        if self._token:
            logger.debug("Token provided, validating...")
            try:
                loop = self._loop or asyncio.get_running_loop()
                is_valid = await loop.run_in_executor(
                    None,
                    lambda: self.generator._generator.validate_token(self._token, self._verbose)
                )
                if not is_valid:
                    raise ValueError("Token validation failed")
                logger.debug("Token validated and set successfully")
            except Exception as e:
                logger.warning(f"Token validation failed: {e}")
                raise
        # If api_secret is provided, token refresh is handled automatically

    def _initialize_token_sync(self) -> None:
        """Initialize token if provided by user (synchronous version).

        If user provided a token, validate and set it.
        If user provided api_secret, token refresh is handled automatically.
        """
        if self._token:
            is_valid = self.generator._generator.validate_token(self._token, self._verbose)
            if not is_valid:
                logger.warning("Token validation failed")
                raise ValueError("Token validation failed")
        # If api_secret is provided, token refresh is handled automatically

    async def start(
        self,
        out_buffer_empty: Optional[BufferEmptyCallback] = None,
        *,
        idle_timeout: float | None = None,
        loop: Optional[asyncio.AbstractEventLoop] = None,
    ) -> None:
        """Start the runtime thread."""
        if self._running:
            logger.debug("Runtime already running, skipping start")
            return

        # Start token refresh if api_secret is provided and refresh is not already running
        loop_exec = loop or asyncio.get_running_loop()
        if self._api_secret and self._api_url and self._model_path:
            if not self.generator.is_token_refresh_running():
                try:
                    if not self.transaction_id:
                        self._regenerate_transaction_id()

                    success = await loop_exec.run_in_executor(
                        None,
                        self.generator.start_token_refresh,
                        self._api_url,
                        self._api_secret,
                        self._model_path,
                        self._tags,
                        60,  # refresh_interval
                        self._insecure,
                        30.0  # timeout
                    )
                    if success:
                        logger.debug("Token refresh started in start()")
                        self._token_refresh_started = True
                    else:
                        logger.error("Failed to start token refresh in start()")
                        raise RuntimeError("Failed to start token refresh")
                except Exception as e:
                    logger.error(f"Failed to start token refresh in start(): {e}")
                    raise
            else:
                # Token refresh already running - just ensure transaction ID is set
                if not self.transaction_id:
                    self._regenerate_transaction_id()
        else:
            # Generate transaction ID only if not already set (prevents bypassing billing)
            if not self.transaction_id:
                self._regenerate_transaction_id()

        # Store the current event loop
        self._loop = loop or asyncio.get_running_loop()
        self._input_buffer.set_loop(self._loop)

        # Clear the stop event
        self._stop_event.clear()

        # Start the runtime thread
        self._running = True
        self._thread = threading.Thread(
            target=self._frame_producer,
            kwargs={"out_buffer_empty": out_buffer_empty, "idle_timeout": idle_timeout},
            name="bithuman-frame-producer",
        )
        self._thread.daemon = True
        self._thread.start()
        logger.debug("Frame producer thread started")

    async def stop(self) -> None:
        """Stop the runtime thread and token refresh task."""
        if not self._running:
            return

        # Signal the producer thread to stop
        self._stop_event.set()
        logger.debug("Stop event set, waiting for frame producer thread to finish")

        # Drain frame queue FIRST to unblock the producer thread if it's stuck
        # on a full-queue put(). This must happen before thread.join().
        while not self._frame_queue.empty():
            try:
                self._frame_queue.get_nowait()
            except queue.Empty:
                break

        # Token refresh is automatically stopped (BithumanRuntime destructor)
        # Wait for the thread to finish with a reasonable timeout
        if self._thread and self._thread.is_alive():
            # Join in executor to avoid blocking the event loop
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, self._thread.join, 5.0)
            if self._thread.is_alive():
                logger.warning("Frame producer thread did not exit within 5s timeout")
                # Drain again — thread may have pushed frames while we were joining
                while not self._frame_queue.empty():
                    try:
                        self._frame_queue.get_nowait()
                    except queue.Empty:
                        break

        # Reset state
        self._running = False
        self._thread = None

        # Call parent cleanup to release all model data, readers, and caches
        self.cleanup()

    def _frame_producer(
        self,
        out_buffer_empty: Optional[BufferEmptyCallback] = None,
        *,
        idle_timeout: float | None = None,
    ) -> None:
        """Run the runtime in a separate thread and produce frames."""
        try:
            # Run the runtime and process frames
            out_buffer_empty = out_buffer_empty or self._frame_queue.empty
            frame_iterator = None
            try:
                frame_iterator = super().run(
                    out_buffer_empty, idle_timeout=idle_timeout
                )
            except (TokenExpiredError, TokenValidationError, RuntimeError) as e:
                if self._is_token_error(e):
                    logger.error(f"Token error during frame iterator initialization: {e}")
                    try:
                        self._frame_queue.put(e)
                    except Exception as e2:
                        logger.error(f"Error putting token error in frame queue: {e2}")
                    return
                raise
            except Exception as e:
                logger.error(f"Error initializing frame iterator in run(): {e}")
                raise

            if frame_iterator:
                import time as _time
                _t_start = _time.perf_counter()
                _backpressure = 0.0
                self._producer_frame_count = 0
                for frame in frame_iterator:
                    if self._stop_event.is_set():
                        logger.debug("Stop event set, stopping frame producer")
                        break

                    self._producer_frame_count += 1

                    # Put the frame in the thread-safe queue with timeout so we can
                    # re-check _stop_event if the queue is full (prevents indefinite
                    # blocking when the consumer has stopped).
                    _t0 = _time.perf_counter()
                    try:
                        while not self._stop_event.is_set():
                            try:
                                self._frame_queue.put(frame, timeout=0.5)
                                break
                            except queue.Full:
                                continue
                        else:
                            # stop_event was set while waiting to put
                            break
                    except (TokenExpiredError, TokenValidationError, RuntimeError) as e:
                        if self._is_token_error(e):
                            logger.error(f"Token error in frame producer: {e}")
                            self._frame_queue.put(e)
                            break
                        raise
                    _backpressure += _time.perf_counter() - _t0

                # Raw generation time = thread wall time minus queue backpressure
                self._producer_gen_time = (_time.perf_counter() - _t_start) - _backpressure

                # Log when frame iterator completes
                logger.debug("Frame iterator completed")
            else:
                logger.error("Frame iterator is None")

        except Exception as e:
            logger.error(f"Exception in frame producer: {e}")
            # If an exception occurs, put it in the frame queue
            try:
                self._frame_queue.put(e)
            except Exception as e2:
                logger.error(f"Error putting exception in frame queue: {e2}")
        finally:
            # Signal end of stream (use timeout to avoid blocking if queue is full)
            for _ in range(10):
                try:
                    self._frame_queue.put(_STREAM_END, timeout=0.5)
                    break
                except queue.Full:
                    # Drain one item to make room for the sentinel
                    try:
                        self._frame_queue.get_nowait()
                    except queue.Empty:
                        pass
                except Exception:
                    break

    async def load_data_async(self) -> None:
        """Load the workspace and set up related components asynchronously."""
        if self._video_loaded:
            return
        if self.video_graph is None:
            logger.error("Video graph is None. Model may not be set properly.")
            raise ValueError("Video graph is not set. Call set_avatar_model() first.")

        # Run the synchronous load_data in a thread pool
        loop = self._loop or asyncio.get_running_loop()
        try:
            await loop.run_in_executor(None, super().load_data)
            self._video_loaded = True
        except Exception as e:
            logger.error(f"Error in load_data: {e}")
            raise
