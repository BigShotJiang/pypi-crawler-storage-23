"""AgentArmor supply-chain guards."""
