"""AgentArmor Shadow-Chain attestation storage."""
