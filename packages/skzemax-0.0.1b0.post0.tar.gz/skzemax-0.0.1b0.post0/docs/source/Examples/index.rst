..  _examples:

skZemax Examples
==========================

Here are a number of basic examples of how to use skZemax. These are default ZOS-API examples adapted to use the skZemax package instead.

It is recommended to see `Example 01` first, as this example goes into the most detail about the basic implementation of skZemax.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   example01
   example02
   example03
   example07