Multi-Configuration Editor (MCE) Functions 
###########################################

These functions handle multiple configurations within the same Zemax lens file.

.. automodule::  skZemax.skZemax_subfunctions._MCE_functions
    :members:
