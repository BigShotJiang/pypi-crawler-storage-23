..  _analysisfunctions:

Analysis Functions 
###########################

These functions provide methods to execute some type of optical analysis on the system.

.. automodule::  skZemax.skZemax_subfunctions._analyses_functions
    :members:
