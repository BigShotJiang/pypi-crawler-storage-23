..  _ZOSAPI:

ZOS-API Application
####################################

This is the boilerplate application class of Zemax. If future updates give a different version, one can update skZemax by updating this code first.

.. automodule::  skZemax.skZemax_subfunctions._app
    :members:

