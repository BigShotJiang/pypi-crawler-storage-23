Merit Function Editor (MFE) Functions
######################################

The functions within this category are related Zemax merits. 
These can be used for a large variate of things, not the least of which is configuring Zemax optimization functions (:ref:`solverfunctions`).

.. automodule::  skZemax.skZemax_subfunctions._MFE_functions
    :members:

