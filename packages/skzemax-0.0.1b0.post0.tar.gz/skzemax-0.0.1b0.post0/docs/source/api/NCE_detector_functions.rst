Non-sequential Component Editor (NCE) Detector Functions
#########################################################

The functions within this category are related reading, formatting, saving and loading NCE detector data from ray traces.

.. automodule::  skZemax.skZemax_subfunctions._NCE_detector_functions
    :members:

