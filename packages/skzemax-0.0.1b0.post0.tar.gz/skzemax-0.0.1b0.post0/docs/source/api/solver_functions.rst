.. _solverfunctions:

Solver Functions
####################################

The functions within this category are related to the optimization aspects within Zemax.

.. automodule::  skZemax.skZemax_subfunctions._solver_functions
    :members:

