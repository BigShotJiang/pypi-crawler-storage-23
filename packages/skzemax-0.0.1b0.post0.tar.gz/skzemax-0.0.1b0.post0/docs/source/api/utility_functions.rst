Utility Functions 
###########################

These functions are provided as general utility to skZemax.

.. automodule::  skZemax.skZemax_subfunctions._utility_functions
    :members:
