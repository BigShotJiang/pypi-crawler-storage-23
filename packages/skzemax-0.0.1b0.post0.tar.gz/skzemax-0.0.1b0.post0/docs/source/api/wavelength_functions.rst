Wavelength Functions 
###########################

These functions configure the wavelength settings of the optical system.

.. automodule::  skZemax.skZemax_subfunctions._wavelength_functions
    :members:
