Non-sequential Component Editor (NCE) Functions
#################################################

The functions within this category are related operations in non-sequential mode, largely around configuration of NCE objects and ray tracing. 

.. automodule::  skZemax.skZemax_subfunctions._NCE_functions
    :members:

