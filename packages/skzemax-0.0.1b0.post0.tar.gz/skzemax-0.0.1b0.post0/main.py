from __future__ import annotations


def main():
    print("Hello from skzemax!")


if __name__ == "__main__":
    main()
