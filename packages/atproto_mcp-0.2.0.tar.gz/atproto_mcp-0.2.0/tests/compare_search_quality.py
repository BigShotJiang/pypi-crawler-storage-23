#!/usr/bin/env python3
"""Compare search quality: baseline (post-filter) vs tag-filtered index.

Uses **separate cache dirs** so the two indexes don't interfere.
Repos are symlinked from the shared default cache to avoid re-cloning.

Usage:
    uv run python tests/compare_search_quality.py
"""

import json
import os
import shutil
import sys
import textwrap
import time
from dataclasses import dataclass
from pathlib import Path

# ---------------------------------------------------------------------------
# Paths — two isolated caches, repos symlinked from the default cache
# ---------------------------------------------------------------------------

_DEFAULT_CACHE = Path.home() / ".cache" / "atproto-mcp"
_BASELINE_CACHE = Path.home() / ".cache" / "atproto-mcp-compare-baseline"
_TAGGED_CACHE = Path.home() / ".cache" / "atproto-mcp-compare-tagged"


def _ensure_repo_symlinks(cache_dir: Path) -> None:
    """Symlink repos/ from the default cache into *cache_dir*."""
    src = _DEFAULT_CACHE / "repos"
    if not src.exists():
        sys.exit(
            f"Default repo cache not found at {src}.\n"
            "Run the server once first so repos are cloned."
        )
    dest = cache_dir / "repos"
    cache_dir.mkdir(parents=True, exist_ok=True)
    if dest.exists() or dest.is_symlink():
        dest.unlink() if dest.is_symlink() else shutil.rmtree(dest)
    dest.symlink_to(src)
    # Also link meta/ so freshness checks don't re-clone
    meta_src = _DEFAULT_CACHE / "meta"
    meta_dest = cache_dir / "meta"
    if meta_src.exists():
        if meta_dest.exists() or meta_dest.is_symlink():
            meta_dest.unlink() if meta_dest.is_symlink() else shutil.rmtree(meta_dest)
        meta_dest.symlink_to(meta_src)


# ---------------------------------------------------------------------------
# Test queries — diverse scenarios that exercise filtering
# ---------------------------------------------------------------------------

@dataclass
class TestQuery:
    description: str
    query: str
    source: str | None = None
    tags: list[str] | None = None
    content_type: str | None = None  # for the new path
    expect_source: str | None = None  # expected source in top result
    expect_substring: str | None = None  # expected substring in top title/nsid


QUERIES: list[TestQuery] = [
    TestQuery(
        description="General: create a post",
        query="how to create a post on Bluesky",
    ),
    TestQuery(
        description="Source filter: OAuth in atproto-website only",
        query="OAuth authentication flow",
        source="atproto-website",
        expect_source="atproto-website",
    ),
    TestQuery(
        description="Source filter: firehose in bsky-docs only",
        query="firehose subscription real-time events",
        source="bsky-docs",
        expect_source="bsky-docs",
    ),
    TestQuery(
        description="Lexicon search: follow relationship",
        query="follow relationship schema",
        source="lexicons",
        tags=["content_type:reference"],
        expect_source="lexicons",
        expect_substring="follow",
    ),
    TestQuery(
        description="Lexicon search: procedure for creating a record",
        query="create record procedure input output",
        source="lexicons",
        tags=["content_type:reference"],
        expect_source="lexicons",
        expect_substring="createRecord",
    ),
    TestQuery(
        description="Lexicon search: moderation labels",
        query="moderation labels report",
        source="lexicons",
        tags=["content_type:reference"],
        expect_source="lexicons",
    ),
    TestQuery(
        description="Content type: guides only",
        query="DID resolution and identity",
        tags=["content_type:guide"],
    ),
    TestQuery(
        description="Content type: examples only",
        query="Python bot example",
        tags=["content_type:example"],
        expect_source="cookbook",
    ),
    TestQuery(
        description="Namespace: app.bsky.feed lexicons",
        query="feed generation custom algorithms",
        source="lexicons",
        tags=["content_type:reference", "namespace:app.bsky.feed"],
        expect_source="lexicons",
        expect_substring="app.bsky.feed",
    ),
    TestQuery(
        description="Source + content: blog posts from bsky-docs",
        query="federation launch announcement",
        source="bsky-docs",
        tags=["content_type:blog"],
        expect_source="bsky-docs",
    ),
]


# ---------------------------------------------------------------------------
# Build / load helpers
# ---------------------------------------------------------------------------

def _build_baseline_kb():
    """Build a knowledge-base using the OLD approach (tags=None in txtai)."""
    from atproto_mcp.config import Config
    from atproto_mcp.indexer import KnowledgeBase
    from atproto_mcp.parser import parse_all

    config = Config(cache_dir=_BASELINE_CACHE)
    kb = KnowledgeBase(config)
    if kb.load():
        # Check if this is genuinely a no-tags index
        sample = next(iter(kb._chunks_by_uid.values()), None)
        if sample and not sample.tags:
            print(f"  Loaded cached baseline index ({kb.chunk_count} chunks)")
            return kb
        # Otherwise it has tags from a prior run — rebuild without
        print("  Cached index has tags — rebuilding baseline without tags …")

    chunks = parse_all(config)
    # Strip tags to simulate old behaviour
    for chunk in chunks:
        chunk.tags = []

    kb.build(chunks)
    print(f"  Built baseline index ({kb.chunk_count} chunks)")
    return kb


def _build_tagged_kb():
    """Build a knowledge-base using the NEW tag-aware approach."""
    from atproto_mcp.config import Config
    from atproto_mcp.indexer import KnowledgeBase
    from atproto_mcp.parser import parse_all

    config = Config(cache_dir=_TAGGED_CACHE)
    kb = KnowledgeBase(config)
    if kb.load():
        sample = next(iter(kb._chunks_by_uid.values()), None)
        if sample and sample.tags:
            print(f"  Loaded cached tagged index ({kb.chunk_count} chunks)")
            return kb
        print("  Cached index has no tags — rebuilding with tags …")

    chunks = parse_all(config)
    kb.build(chunks)
    print(f"  Built tagged index ({kb.chunk_count} chunks)")
    return kb


# ---------------------------------------------------------------------------
# Search wrappers
# ---------------------------------------------------------------------------

def _baseline_search(kb, tq: TestQuery, limit: int = 5) -> tuple[list[dict], float]:
    """Old-style search: source post-filter only, no tag awareness."""
    t0 = time.perf_counter()
    results = kb.search(tq.query, source=tq.source, limit=limit)
    elapsed = time.perf_counter() - t0
    return results, elapsed


def _tagged_search(kb, tq: TestQuery, limit: int = 5) -> tuple[list[dict], float]:
    """New-style search: SQL tag filtering."""
    t0 = time.perf_counter()
    results = kb.search(tq.query, source=tq.source, tags=tq.tags, limit=limit)
    elapsed = time.perf_counter() - t0
    return results, elapsed


# ---------------------------------------------------------------------------
# Scoring
# ---------------------------------------------------------------------------

def _score_results(results: list[dict], tq: TestQuery) -> dict:
    """Score a result set against expectations."""
    scores: dict[str, object] = {
        "count": len(results),
        "top_score": results[0]["score"] if results else 0.0,
        "avg_score": (
            sum(float(r["score"]) for r in results) / len(results) if results else 0.0
        ),
        "source_correct": True,
        "substring_found": True,
        "source_purity": 1.0,
    }

    if tq.expect_source and results:
        scores["source_correct"] = results[0].get("source") == tq.expect_source
        matching = sum(1 for r in results if r.get("source") == tq.expect_source)
        scores["source_purity"] = matching / len(results) if results else 0.0

    if tq.expect_substring and results:
        top = results[0]
        haystack = f"{top.get('title', '')} {top.get('nsid', '')}".lower()
        scores["substring_found"] = tq.expect_substring.lower() in haystack

    return scores


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    print("=" * 72)
    print("Search Quality Comparison: Baseline (post-filter) vs Tagged (SQL)")
    print("=" * 72)

    print("\n1. Preparing caches …")
    _ensure_repo_symlinks(_BASELINE_CACHE)
    _ensure_repo_symlinks(_TAGGED_CACHE)

    print("\n2. Building / loading baseline index …")
    baseline_kb = _build_baseline_kb()

    print("\n3. Building / loading tagged index …")
    tagged_kb = _build_tagged_kb()

    print(f"\n4. Running {len(QUERIES)} test queries …\n")
    print("-" * 72)

    baseline_wins = 0
    tagged_wins = 0
    ties = 0
    improvements: list[str] = []
    regressions: list[str] = []

    for i, tq in enumerate(QUERIES, 1):
        print(f"\n  [{i}/{len(QUERIES)}] {tq.description}")
        print(f"  Query: \"{tq.query}\"")
        if tq.source:
            print(f"  Source filter: {tq.source}")
        if tq.tags:
            print(f"  Tag filters: {tq.tags}")

        base_results, base_time = _baseline_search(baseline_kb, tq)
        tag_results, tag_time = _tagged_search(tagged_kb, tq)

        base_scores = _score_results(base_results, tq)
        tag_scores = _score_results(tag_results, tq)

        # Print top-3 from each
        for label, results, elapsed in [
            ("Baseline", base_results, base_time),
            ("Tagged ", tag_results, tag_time),
        ]:
            print(f"\n    {label} ({elapsed*1000:.0f}ms):")
            for j, r in enumerate(results[:3], 1):
                src = r.get("source", "?")
                title = r.get("title", "?")
                nsid = f" ({r['nsid']})" if r.get("nsid") else ""
                score = float(r.get("score", 0))
                tags_str = ""
                t = r.get("tags", [])
                if t:
                    tags_str = f"  tags={t}"
                print(f"      {j}. [{src}] {title}{nsid}  score={score:.3f}{tags_str}")

        # Compare
        verdict_parts: list[str] = []

        # Source purity
        bp = float(base_scores["source_purity"])
        tp = float(tag_scores["source_purity"])
        if tq.expect_source:
            if tp > bp:
                verdict_parts.append(f"source purity ↑ {bp:.0%}→{tp:.0%}")
            elif tp < bp:
                verdict_parts.append(f"source purity ↓ {bp:.0%}→{tp:.0%}")

        # Top score
        bs = float(base_scores["top_score"])
        ts = float(tag_scores["top_score"])
        if abs(ts - bs) > 0.01:
            arrow = "↑" if ts > bs else "↓"
            verdict_parts.append(f"top score {arrow} {bs:.3f}→{ts:.3f}")

        # Substring
        if tq.expect_substring:
            bf = base_scores["substring_found"]
            tf = tag_scores["substring_found"]
            if tf and not bf:
                verdict_parts.append("correct top result ↑")
            elif bf and not tf:
                verdict_parts.append("correct top result ↓")

        # Speed
        speedup = base_time / tag_time if tag_time > 0 else 0
        if speedup > 1.2:
            verdict_parts.append(f"speed {speedup:.1f}x faster")
        elif speedup < 0.8:
            verdict_parts.append(f"speed {1/speedup:.1f}x slower")

        # Overall verdict for this query
        tag_better = (tp > bp) or (ts > bs + 0.01) or (
            tq.expect_substring and tag_scores["substring_found"]
            and not base_scores["substring_found"]
        )
        base_better = (tp < bp) or (
            tq.expect_substring and base_scores["substring_found"]
            and not tag_scores["substring_found"]
        )

        if tag_better and not base_better:
            verdict = "TAGGED WINS"
            tagged_wins += 1
            improvements.append(f"  {tq.description}: {', '.join(verdict_parts)}")
        elif base_better and not tag_better:
            verdict = "BASELINE WINS"
            baseline_wins += 1
            regressions.append(f"  {tq.description}: {', '.join(verdict_parts)}")
        else:
            verdict = "TIE"
            ties += 1

        details = f" ({', '.join(verdict_parts)})" if verdict_parts else ""
        print(f"\n    → {verdict}{details}")

    # ---------------------------------------------------------------------------
    # Summary
    # ---------------------------------------------------------------------------
    print("\n" + "=" * 72)
    print("SUMMARY")
    print("=" * 72)
    print(f"  Queries tested:  {len(QUERIES)}")
    print(f"  Tagged wins:     {tagged_wins}")
    print(f"  Baseline wins:   {baseline_wins}")
    print(f"  Ties:            {ties}")

    if improvements:
        print("\n  Improvements with tags:")
        for line in improvements:
            print(line)
    if regressions:
        print("\n  Regressions with tags:")
        for line in regressions:
            print(line)

    print()
    if tagged_wins >= baseline_wins:
        print("  ✅ Tag-filtered search is at least as good as baseline.")
    else:
        print("  ⚠️  Tag-filtered search shows regressions — investigate.")
    print()


if __name__ == "__main__":
    main()
