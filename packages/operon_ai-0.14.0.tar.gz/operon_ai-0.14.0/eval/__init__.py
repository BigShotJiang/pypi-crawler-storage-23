"""Synthetic evaluation harness for Operon."""
