"""
Multi-Agent Coordination System for Toxo
Enterprise-level agent orchestration and management.
"""

from .coordinator import CoordinatorAgent
from .communication import AgentMessage, MessageBus, MessageType, Priority
from .base import BaseAgent, AgentStatus, AgentCapability

# New enterprise orchestration components
from .orchestrator import (
    AgentOrchestrator,
    Agent,
    LLMAgent,
    Task,
    TaskScheduler,
    MessageRouter,
    AgentType,
    TaskStatus,
    CoordinationPattern,
    create_llm_agent,
    create_orchestrator,
    create_multi_agent_system
)

__all__ = [
    # Original coordination
    'CoordinatorAgent',
    
    # Base classes
    'BaseAgent',
    'AgentStatus',
    'AgentCapability',
    
    # Communication system
    'AgentMessage',
    'MessageBus',
    'MessageType',
    'Priority',
    
    # Enterprise orchestration
    'AgentOrchestrator',
    'Agent',
    'LLMAgent',
    'Task',
    'TaskScheduler',
    'MessageRouter',
    'AgentType',
    'TaskStatus',
    'CoordinationPattern',
    
    # Factory functions
    'create_llm_agent',
    'create_orchestrator',
    'create_multi_agent_system',
]

__version__ = "0.1.0" 