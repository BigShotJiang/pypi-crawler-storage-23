"""
Utility functions and helpers for Toxo.
"""

import sys
import json
import zipfile
from pathlib import Path
from typing import Dict, Any, List

from .logger import get_logger, setup_logging
from .exceptions import ToxoError, TrainingError, MemoryError, ConfigError
from .validation import validate_config, validate_training_data


def get_version() -> str:
    """Get the current version of TOXO package."""
    return "2.0.0"


def check_dependencies() -> Dict[str, Any]:
    """Check if all required dependencies are available."""
    deps = {
        "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "python_compatible": sys.version_info >= (3, 8),
        "required_packages": {},
        "optional_packages": {},
        "status": "unknown"
    }
    for mod, pkg in [("google.generativeai", "google-generativeai"), ("numpy", "numpy"), ("requests", "requests"), ("tqdm", "tqdm"), ("pydantic", "pydantic")]:
        try:
            __import__(mod)
            deps["required_packages"][pkg] = "Available"
        except ImportError:
            deps["required_packages"][pkg] = "Missing"
    for mod, pkg in [("chromadb", "chromadb"), ("sentence_transformers", "sentence-transformers"), ("sklearn", "scikit-learn"), ("pandas", "pandas")]:
        try:
            __import__(mod)
            deps["optional_packages"][pkg] = "Available"
        except ImportError:
            deps["optional_packages"][pkg] = "Optional"
    missing = [p for p, s in deps["required_packages"].items() if s == "Missing"]
    deps["status"] = "All requirements satisfied" if not missing else f"Missing: {missing}"
    return deps


def print_dependency_status() -> None:
    """Print a formatted dependency status report."""
    deps = check_dependencies()
    print("TOXO Dependency Check")
    print("=" * 40)
    print(f"Python Version: {deps['python_version']}")
    print(f"Status: {deps['status']}")


def validate_toxo_file(file_path: str) -> Dict[str, Any]:
    """Validate if a file is a proper .toxo file."""
    result = {"valid": False, "errors": [], "warnings": [], "info": {}}
    fp = Path(file_path)
    if not fp.exists():
        result["errors"].append("File does not exist")
        return result
    if fp.suffix.lower() != '.toxo':
        result["errors"].append("File must have .toxo extension")
        return result
    try:
        with zipfile.ZipFile(fp, 'r') as z:
            names = z.namelist()
            if "manifest.json" not in names:
                result["errors"].append("Missing manifest.json")
            try:
                m = json.loads(z.read("manifest.json").decode('utf-8'))
                pkg = m.get("package_info") or m
                result["info"] = {
                    "name": pkg.get("name", "Unknown"),
                    "domain": m.get("domain", pkg.get("domain", "Unknown")),
                    "version": m.get("version", pkg.get("version", "Unknown")),
                    "file_count": len(names),
                    "file_size": f"{fp.stat().st_size / 1024:.1f} KB"
                }
            except Exception:
                result["info"] = {"file_count": len(names)}
            if not result["errors"]:
                result["valid"] = True
    except zipfile.BadZipFile:
        result["errors"].append("File is not a valid ZIP archive")
    except Exception as e:
        result["errors"].append(str(e))
    return result


def print_toxo_info(file_path: str) -> None:
    """Print information about a .toxo file."""
    v = validate_toxo_file(file_path)
    print(f"TOXO File Information: {Path(file_path).name}")
    print("=" * 50)
    if v["valid"]:
        print("Valid TOXO file")
        for k, val in v.get("info", {}).items():
            print(f"  {k}: {val}")
    else:
        print("Invalid TOXO file")
        for e in v["errors"]:
            print(f"  Error: {e}")


def get_sample_usage() -> str:
    """Get sample usage code for TOXO."""
    return '''from toxo import ToxoLayer
layer = ToxoLayer.load("your_expert_model.toxo")
layer.setup_api_key("your_gemini_api_key_here")
response = layer.query("Your question here")
'''


def get_help_text() -> str:
    """Get help text for TOXO usage."""
    return "TOXO - Smart Layer for CALM. See https://toxotune.com"


__all__ = [
    "get_version",
    "check_dependencies",
    "print_dependency_status",
    "validate_toxo_file",
    "print_toxo_info",
    "get_sample_usage",
    "get_help_text",
    "get_logger",
    "setup_logging",
    "ToxoError",
    "TrainingError", 
    "MemoryError",
    "ConfigError",
    "validate_config",
    "validate_training_data",
] 