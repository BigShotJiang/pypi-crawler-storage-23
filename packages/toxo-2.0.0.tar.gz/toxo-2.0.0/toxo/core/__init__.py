"""
Core Toxo components.
"""

from .config import ToxoConfig, get_default_config
from .toxo_layer import ToxoLayer, ToxoLayerMetadata
# from .memory import ToxoMemory  # Temporarily disabled due to dependency issue
from .prompt_engine import PromptTemplateEngine, ToxoMasterPrompt, PromptIdentity, PromptInstructions, PromptContext
from .rich_prompt_engine import RichPromptEngine
from .api_manager import ToxoAPIManager

# Optional: trainer (requires pandas)
try:
    from .trainer import ToxoTrainer, TrainingExample, TrainingSession
except ImportError:
    ToxoTrainer = None
    TrainingExample = None
    TrainingSession = None

# Optional: neural reranker (requires torch)
try:
    from .neural_reranker import NeuralReranker
except ImportError:
    NeuralReranker = None

# Advanced components
try:
    from .advanced_distributed_training import (
        AdvancedDistributedTrainingManager,
        TrainingStrategy,
        WorkerType,
        ResourceType,
        TrainingJob,
        WorkerNode,
        TrainingRound,
        SecureAggregator,
        ResourceManager,
        FederatedLearningCoordinator,
        create_advanced_distributed_training_manager
    )
    ADVANCED_DISTRIBUTED_TRAINING_AVAILABLE = True
except ImportError:
    AdvancedDistributedTrainingManager = None
    TrainingStrategy = None
    WorkerType = None
    ResourceType = None
    TrainingJob = None
    WorkerNode = None
    TrainingRound = None
    SecureAggregator = None
    ResourceManager = None
    FederatedLearningCoordinator = None
    create_advanced_distributed_training_manager = None
    ADVANCED_DISTRIBUTED_TRAINING_AVAILABLE = False

try:
    from .advanced_analytics import (
        AdvancedAnalyticsManager,
        MetricType,
        AlertSeverity,
        AnomalyType,
        MetricDefinition,
        MetricDataPoint,
        Alert,
        AnomalyDetection,
        PerformanceAnalysis,
        TimeSeriesAnalyzer,
        AnomalyDetector,
        PerformanceAnalyzer,
        AlertManager,
        create_advanced_analytics_manager
    )
    ADVANCED_ANALYTICS_AVAILABLE = True
except ImportError:
    AdvancedAnalyticsManager = None
    MetricType = None
    AlertSeverity = None
    AnomalyType = None
    MetricDefinition = None
    MetricDataPoint = None
    Alert = None
    AnomalyDetection = None
    PerformanceAnalysis = None
    TimeSeriesAnalyzer = None
    AnomalyDetector = None
    PerformanceAnalyzer = None
    AlertManager = None
    create_advanced_analytics_manager = None
    ADVANCED_ANALYTICS_AVAILABLE = False

# Enterprise-level components (make optional)
try:
    from .load_balancer import LoadBalancer, BackendNode, create_load_balancer, LoadBalancingAlgorithm
    LOAD_BALANCER_AVAILABLE = True
except ImportError:
    LoadBalancer = None
    BackendNode = None
    create_load_balancer = None
    LoadBalancingAlgorithm = None
    LOAD_BALANCER_AVAILABLE = False

try:
    from .caching import CacheManager, MemoryCache, RedisCache, HierarchicalCache, cache
    CACHING_AVAILABLE = True
except ImportError:
    CacheManager = None
    MemoryCache = None
    RedisCache = None
    HierarchicalCache = None
    cache = None
    CACHING_AVAILABLE = False

try:
    from .vector_store import VectorStore, get_vector_store
    VECTOR_STORE_AVAILABLE = True
except ImportError:
    VectorStore = None
    get_vector_store = None
    VECTOR_STORE_AVAILABLE = False

try:
    from .quality_scorer import (
        analyze_response,
        classify_query,
        compute_domain_confidence,
        should_use_layer,
        compute_info_density,
        QUALITY_WEIGHTS,
    )
    QUALITY_SCORER_AVAILABLE = True
except ImportError:
    analyze_response = None
    classify_query = None
    compute_domain_confidence = None
    should_use_layer = None
    compute_info_density = None
    QUALITY_WEIGHTS = None
    QUALITY_SCORER_AVAILABLE = False

try:
    from .monitoring import ToxoMonitor, MetricsCollector, PerformanceMonitor, get_monitor
    MONITORING_AVAILABLE = True
except ImportError:
    ToxoMonitor = None
    MetricsCollector = None
    PerformanceMonitor = None
    get_monitor = None
    MONITORING_AVAILABLE = False

try:
    from .distributed import DistributedProcessingManager, DistributedManager, ClusterNode
    DISTRIBUTED_AVAILABLE = True
except ImportError:
    DistributedProcessingManager = None
    DistributedManager = None
    ClusterNode = None
    DISTRIBUTED_AVAILABLE = False

# Phase 2: Enhanced Hierarchical Memory System (requires sklearn)
try:
    from .hierarchical_memory import (
        HierarchicalMemorySystem,
        MemoryItem,
        MemoryAssociation,
        ConsolidationRule,
        MemoryConsolidator,
        AssociativeRetriever,
        MemoryLevel,
        MemoryType,
        create_hierarchical_memory_system
    )
except ImportError:
    HierarchicalMemorySystem = None
    MemoryItem = None
    MemoryAssociation = None
    ConsolidationRule = None
    MemoryConsolidator = None
    AssociativeRetriever = None
    MemoryLevel = None
    MemoryType = None
    create_hierarchical_memory_system = None

__all__ = [
    # Core configuration and layer
    'ToxoConfig',
    # Quality scorer (when available)
    'analyze_response',
    'classify_query',
    'compute_domain_confidence',
    'should_use_layer',
    'compute_info_density',
    'QUALITY_WEIGHTS',
    'get_default_config',
    'ToxoLayer',
    'ToxoLayerMetadata',
    
    # Training and prompt engineering
    'ToxoTrainer',
    'TrainingExample',
    'TrainingSession',
    'PromptTemplateEngine',
    'ToxoMasterPrompt',
    'PromptIdentity',
    'PromptInstructions',
    'PromptContext',
    'RichPromptEngine',
    
    # Neural components
    'NeuralReranker',
    
    # API management
    'ToxoAPIManager',
    
    # Enterprise infrastructure
    'LoadBalancer',
    'BackendNode',
    'create_load_balancer',
    'LoadBalancingAlgorithm',
    'CacheManager',
    'MemoryCache',
    'RedisCache',
    'HierarchicalCache',
    'cache',
    'VectorStore',
    'get_vector_store',
    'ToxoMonitor',
    'MetricsCollector',
    'PerformanceMonitor',
    'get_monitor',
    'DistributedProcessingManager',
    'DistributedManager',
    'ClusterNode',
    
    # Phase 2: Enhanced Hierarchical Memory
    'HierarchicalMemorySystem',
    'MemoryItem',
    'MemoryAssociation',
    'ConsolidationRule',
    'MemoryConsolidator',
    'AssociativeRetriever',
    'MemoryLevel',
    'MemoryType',
    'create_hierarchical_memory_system',
    
    # Advanced components
    'AdvancedDistributedTrainingManager',
    'TrainingStrategy',
    'WorkerType',
    'ResourceType',
    'TrainingJob',
    'WorkerNode',
    'TrainingRound',
    'SecureAggregator',
    'ResourceManager',
    'FederatedLearningCoordinator',
    'create_advanced_distributed_training_manager',
    'AdvancedAnalyticsManager',
    'MetricType',
    'AlertSeverity',
    'AnomalyType',
    'MetricDefinition',
    'MetricDataPoint',
    'Alert',
    'AnomalyDetection',
    'PerformanceAnalysis',
    'TimeSeriesAnalyzer',
    'AnomalyDetector',
    'PerformanceAnalyzer',
    'AlertManager',
    'create_advanced_analytics_manager'
]

# Try to import ToxoMemory, but make it optional
try:
    from .memory import ToxoMemory
    TOXO_MEMORY_AVAILABLE = True
except ImportError:
    ToxoMemory = None
    TOXO_MEMORY_AVAILABLE = False

if TOXO_MEMORY_AVAILABLE:
    __all__.append('ToxoMemory') 