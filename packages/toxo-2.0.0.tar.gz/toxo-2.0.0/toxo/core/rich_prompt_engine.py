"""
Advanced Toxo Rich Prompt Engineering Engine.

This module creates rich, professional-grade system prompts that rival those used in
production AI systems like Cursor, v0, and Bolt. It generates structured, contextual,
and highly detailed prompts that significantly improve LLM performance.

ENHANCED WITH GEMINI: Now includes AI-powered prompt generation, optimization,
and real-time adaptation using Gemini's intelligence.
"""

import json
import re
from datetime import datetime
from typing import Dict, Any, List, Optional, Union
from dataclasses import dataclass, field, asdict
from pathlib import Path
import yaml
import asyncio
import numpy as np

from ..utils.logger import get_logger
from ..utils.exceptions import PromptError, ValidationError, ModelError
from ..integrations.gemini_client import GeminiClient


def extract_json_from_response(response: str) -> Dict[str, Any]:
    """
    Extract and parse JSON from a response that might contain additional text.
    
    Args:
        response: The raw response text
        
    Returns:
        Parsed JSON dictionary
        
    Raises:
        json.JSONDecodeError: If no valid JSON is found
    """
    # First, try to parse the entire response as JSON
    try:
        return json.loads(response.strip())
    except json.JSONDecodeError:
        pass
    
    # Try to find JSON within the response using regex
    # Look for content between curly braces with json markdown
    json_pattern = r'```json\s*(\{.*?\})\s*```'
    match = re.search(json_pattern, response, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            pass
    
    # Look for any JSON object in the response
    json_pattern = r'\{(?:[^{}]|{[^{}]*})*\}'
    matches = re.findall(json_pattern, response, re.DOTALL)
    
    for match in matches:
        try:
            # Try to parse this potential JSON
            parsed = json.loads(match)
            if isinstance(parsed, dict) and parsed:  # Must be a non-empty dict
                return parsed
        except json.JSONDecodeError:
            continue
    
    # If no JSON found, raise an error
    raise json.JSONDecodeError("No valid JSON found in response", response, 0)


@dataclass
class RichPromptIdentity:
    """Rich identity composition for advanced AI personas."""
    core_role: str
    specialization: str
    expertise_level: str
    domain_authority: List[str]
    capabilities: List[str]
    performance_characteristics: Dict[str, str]
    persona_traits: List[str]
    communication_style: str
    
    def __post_init__(self):
        if not self.domain_authority:
            self.domain_authority = []
        if not self.capabilities:
            self.capabilities = []
        if not self.persona_traits:
            self.persona_traits = []
        if not self.performance_characteristics:
            self.performance_characteristics = {}


@dataclass
class RichPromptInstructions:
    """Comprehensive instruction framework for AI behavior."""
    primary_directive: str
    secondary_objectives: List[str]
    reasoning_methodology: str
    decision_framework: List[str]
    quality_standards: Dict[str, str]
    output_specifications: Dict[str, Any]
    interaction_patterns: List[str]
    error_handling: Dict[str, str]
    constraints: List[str]
    success_metrics: List[str]
    
    def __post_init__(self):
        if not self.secondary_objectives:
            self.secondary_objectives = []
        if not self.decision_framework:
            self.decision_framework = []
        if not self.quality_standards:
            self.quality_standards = {}
        if not self.output_specifications:
            self.output_specifications = {}
        if not self.interaction_patterns:
            self.interaction_patterns = []
        if not self.error_handling:
            self.error_handling = {}
        if not self.constraints:
            self.constraints = []
        if not self.success_metrics:
            self.success_metrics = []


@dataclass
class RichPromptContext:
    """Rich contextual information for intelligent prompting."""
    domain_knowledge: Dict[str, List[str]]
    environmental_constraints: Dict[str, Any]
    user_profile: Dict[str, Any]
    session_memory: Dict[str, Any]
    performance_history: Dict[str, float]
    retrieved_documents: List[Dict[str, Any]]
    conversation_context: List[Dict[str, str]]
    temporal_context: Dict[str, str]
    cultural_context: Dict[str, str]
    
    def __post_init__(self):
        if not self.domain_knowledge:
            self.domain_knowledge = {}
        if not self.environmental_constraints:
            self.environmental_constraints = {}
        if not self.user_profile:
            self.user_profile = {}
        if not self.session_memory:
            self.session_memory = {}
        if not self.performance_history:
            self.performance_history = {}
        if not self.retrieved_documents:
            self.retrieved_documents = []
        if not self.conversation_context:
            self.conversation_context = []
        if not self.temporal_context:
            self.temporal_context = {}
        if not self.cultural_context:
            self.cultural_context = {}


@dataclass
class RichPromptMetadata:
    """Metadata for prompt versioning and optimization."""
    version: str
    created_at: str
    domain: str
    task_type: str
    complexity_level: str
    optimization_target: str
    performance_benchmarks: Dict[str, float]
    revision_history: List[Dict[str, Any]]
    
    def __post_init__(self):
        if not self.performance_benchmarks:
            self.performance_benchmarks = {}
        if not self.revision_history:
            self.revision_history = []


@dataclass
class ToxoRichMasterPrompt:
    """Complete rich master prompt structure for Toxo."""
    identity: RichPromptIdentity
    instructions: RichPromptInstructions
    context: RichPromptContext
    metadata: RichPromptMetadata
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class RichPromptEngine:
    """
    Advanced prompt engineering engine that creates rich, professional-grade system prompts.
    
    ENHANCED WITH GEMINI INTELLIGENCE:
    - AI-powered prompt generation and optimization
    - Dynamic prompt adaptation based on performance
    - Real-time prompt improvement from user feedback
    - Intelligent prompt structure analysis and enhancement
    
    This engine produces prompts that rival those used in production AI systems like:
    - Cursor AI Assistant
    - v0 by Vercel
    - Bolt AI
    - Claude Sonnet 
    
    Features:
    - Multi-layered prompt architecture
    - Context-aware prompt adaptation
    - Performance-driven optimization
    - Rich formatting and structure
    - Domain-specific expertise injection
    - AI-powered dynamic enhancement (NEW)
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None, gemini_client=None):
        """Initialize the rich prompt engine."""
        self.config = config or {}
        self.logger = get_logger("toxo.rich_prompt_engine")
        
        # Gemini integration for AI-powered enhancement
        self.gemini_client = gemini_client
        self.ai_enhanced = gemini_client is not None
        
        # Load advanced templates and knowledge bases
        self._load_advanced_templates()
        self._load_domain_expertise()
        self._load_performance_patterns()
        
        # AI enhancement cache
        self._enhancement_cache = {}
        self._performance_history = {}
        
        if self.ai_enhanced:
            self.logger.info("Rich Prompt Engine initialized with Gemini AI enhancement")
        else:
            self.logger.info("Rich Prompt Engine initialized (static mode)")
    
    def create_rich_master_prompt(
        self,
        task_description: str,
        domain: str = "general",
        user_preferences: Optional[Dict[str, Any]] = None,
        context: Optional[Dict[str, Any]] = None,
        performance_metrics: Optional[Dict[str, float]] = None,
        complexity_level: str = "intermediate",
        optimization_target: str = "accuracy"
    ) -> ToxoRichMasterPrompt:
        """
        Create a rich, professional-grade master prompt.
        
        Args:
            task_description: Detailed description of the AI task
            domain: Domain specialization (finance, legal, medical, etc.)
            user_preferences: User-specific preferences and requirements
            context: Additional contextual information
            performance_metrics: Historical performance data
            complexity_level: simple, intermediate, advanced, expert
            optimization_target: accuracy, speed, creativity, safety
            
        Returns:
            Complete ToxoRichMasterPrompt with rich structure
        """
        user_preferences = user_preferences or {}
        context = context or {}
        performance_metrics = performance_metrics or {}
        
        # Create rich identity
        identity = self._create_rich_identity(
            task_description, domain, complexity_level, performance_metrics
        )
        
        # Create comprehensive instructions
        instructions = self._create_rich_instructions(
            task_description, domain, user_preferences, optimization_target
        )
        
        # Create rich context
        rich_context = self._create_rich_context(
            context, domain, user_preferences, performance_metrics
        )
        
        # Create metadata
        metadata = RichPromptMetadata(
            version="1.0.0",
            created_at=self._get_timestamp(),
            domain=domain,
            task_type=self._infer_task_type(task_description),
            complexity_level=complexity_level,
            optimization_target=optimization_target,
            performance_benchmarks=performance_metrics,
            revision_history=[]
        )
        
        master_prompt = ToxoRichMasterPrompt(
            identity=identity,
            instructions=instructions,
            context=rich_context,
            metadata=metadata
        )
        
        self.logger.info(f"Created rich master prompt for domain: {domain}, complexity: {complexity_level}")
        return master_prompt
    
    def render_professional_prompt(
        self,
        master_prompt: ToxoRichMasterPrompt,
        user_input: str,
        template_format: str = "professional"
    ) -> str:
        """
        Render a rich, structured system prompt.
        
        Args:
            master_prompt: Rich master prompt structure
            user_input: Current user input
            template_format: professional, technical, creative, conversational
            
        Returns:
            Fully rendered rich system prompt
        """
        # Select appropriate template
        template = self._get_professional_template(template_format, master_prompt.metadata.task_type)
        
        # Prepare comprehensive variables
        variables = self._prepare_rich_variables(master_prompt, user_input)
        
        # Render with advanced formatting
        rendered_prompt = self._render_rich_template(template, variables)
        
        # Apply post-processing optimizations
        optimized_prompt = self._optimize_prompt_structure(rendered_prompt, master_prompt)
        
        self.logger.debug(f"Rendered rich prompt with {len(optimized_prompt)} characters")
        return optimized_prompt
    
    def _create_rich_identity(
        self,
        task_description: str,
        domain: str,
        complexity_level: str,
        performance_metrics: Dict[str, float]
    ) -> RichPromptIdentity:
        """Create a rich, sophisticated AI identity."""
        
        # Determine core role with sophistication
        core_role = self._determine_sophisticated_role(task_description, domain)
        
        # Create specialized expertise areas
        specialization = self._create_domain_specialization(domain, complexity_level)
        
        # Determine expertise level
        expertise_level = self._assess_expertise_level(complexity_level, performance_metrics)
        
        # Build domain authority
        domain_authority = self._build_domain_authority(domain, task_description)
        
        # Define comprehensive capabilities
        capabilities = self._define_advanced_capabilities(task_description, domain, complexity_level)
        
        # Create performance characteristics
        performance_characteristics = self._define_performance_characteristics(
            complexity_level, performance_metrics
        )
        
        # Define persona traits
        persona_traits = self._select_optimal_persona_traits(domain, task_description)
        
        # Determine communication style
        communication_style = self._select_communication_style(domain, complexity_level)
        
        return RichPromptIdentity(
            core_role=core_role,
            specialization=specialization,
            expertise_level=expertise_level,
            domain_authority=domain_authority,
            capabilities=capabilities,
            performance_characteristics=performance_characteristics,
            persona_traits=persona_traits,
            communication_style=communication_style
        )
    
    def _create_rich_instructions(
        self,
        task_description: str,
        domain: str,
        user_preferences: Dict[str, Any],
        optimization_target: str
    ) -> RichPromptInstructions:
        """Create comprehensive, detailed instructions."""
        
        # Primary directive with clarity and purpose
        primary_directive = self._craft_primary_directive(task_description, domain)
        
        # Secondary objectives
        secondary_objectives = self._define_secondary_objectives(task_description, domain)
        
        # Reasoning methodology
        reasoning_methodology = self._select_reasoning_methodology(domain, optimization_target)
        
        # Decision framework
        decision_framework = self._build_decision_framework(domain, user_preferences)
        
        # Quality standards
        quality_standards = self._define_quality_standards(domain, optimization_target)
        
        # Output specifications
        output_specifications = self._create_output_specifications(
            task_description, user_preferences
        )
        
        # Interaction patterns
        interaction_patterns = self._define_interaction_patterns(domain, user_preferences)
        
        # Error handling
        error_handling = self._create_error_handling_framework(domain)
        
        # Constraints
        constraints = self._extract_domain_constraints(domain, task_description)
        
        # Success metrics
        success_metrics = self._define_success_metrics(domain, optimization_target)
        
        return RichPromptInstructions(
            primary_directive=primary_directive,
            secondary_objectives=secondary_objectives,
            reasoning_methodology=reasoning_methodology,
            decision_framework=decision_framework,
            quality_standards=quality_standards,
            output_specifications=output_specifications,
            interaction_patterns=interaction_patterns,
            error_handling=error_handling,
            constraints=constraints,
            success_metrics=success_metrics
        )
    
    def _create_rich_context(
        self,
        context: Dict[str, Any],
        domain: str,
        user_preferences: Dict[str, Any],
        performance_metrics: Dict[str, float]
    ) -> RichPromptContext:
        """Create rich, comprehensive context."""
        
        # Domain knowledge base
        domain_knowledge = self._build_domain_knowledge_base(domain)
        
        # Environmental constraints
        environmental_constraints = self._assess_environmental_constraints(context)
        
        # User profile
        user_profile = self._build_user_profile(user_preferences, context)
        
        # Session memory
        session_memory = context.get("session_memory", {})
        
        # Performance history
        performance_history = performance_metrics
        
        # Retrieved documents
        retrieved_documents = context.get("retrieved_documents", [])
        
        # Conversation context
        conversation_context = context.get("conversation_history", [])
        
        # Temporal context
        temporal_context = self._create_temporal_context()
        
        # Cultural context
        cultural_context = self._infer_cultural_context(user_preferences)
        
        return RichPromptContext(
            domain_knowledge=domain_knowledge,
            environmental_constraints=environmental_constraints,
            user_profile=user_profile,
            session_memory=session_memory,
            performance_history=performance_history,
            retrieved_documents=retrieved_documents,
            conversation_context=conversation_context,
            temporal_context=temporal_context,
            cultural_context=cultural_context
        )
    
    def _get_professional_template(self, format_type: str, task_type: str) -> str:
        """Get professional template with rich structure."""
        
        base_template = """## Core Identity
You are {core_role}, {specialization} with {expertise_level} expertise.

{domain_authority_section}

## Primary Directive
{primary_directive}

<core_capabilities>
{capabilities_section}
</core_capabilities>

<operational_guidelines>
## Reasoning Methodology
{reasoning_methodology}

## Decision Framework
{decision_framework_section}

## Quality Standards
{quality_standards_section}

## Output Specifications
{output_specifications_section}
</operational_guidelines>

<interaction_protocol>
## Communication Style
{communication_style}

## Interaction Patterns
{interaction_patterns_section}

## Error Handling
{error_handling_section}
</interaction_protocol>

<context_awareness>
## Domain Knowledge
{domain_knowledge_section}

## Environmental Constraints
{environmental_constraints_section}

## User Profile
{user_profile_section}

## Performance History
{performance_history_section}
</context_awareness>

<constraints_and_guidelines>
{constraints_section}
</constraints_and_guidelines>

<success_metrics>
{success_metrics_section}
</success_metrics>

## Current Task Context
User Input: {user_input}

## Instructions
{task_specific_instructions}

{additional_context}"""

        return base_template
    
    def _prepare_rich_variables(
        self, 
        master_prompt: ToxoRichMasterPrompt, 
        user_input: str
    ) -> Dict[str, str]:
        """Prepare comprehensive variables for template rendering."""
        variables = {}
        
        # Identity variables
        variables.update({
            "core_role": master_prompt.identity.core_role,
            "specialization": master_prompt.identity.specialization,
            "expertise_level": master_prompt.identity.expertise_level,
            "communication_style": master_prompt.identity.communication_style,
        })
        
        # Formatted sections
        variables.update({
            "domain_authority_section": self._format_domain_authority(
                master_prompt.identity.domain_authority
            ),
            "capabilities_section": self._format_capabilities(
                master_prompt.identity.capabilities
            ),
            "primary_directive": master_prompt.instructions.primary_directive,
            "reasoning_methodology": master_prompt.instructions.reasoning_methodology,
            "decision_framework_section": self._format_decision_framework(
                master_prompt.instructions.decision_framework
            ),
            "quality_standards_section": self._format_quality_standards(
                master_prompt.instructions.quality_standards
            ),
            "output_specifications_section": self._format_output_specifications(
                master_prompt.instructions.output_specifications
            ),
            "interaction_patterns_section": self._format_interaction_patterns(
                master_prompt.instructions.interaction_patterns
            ),
            "error_handling_section": self._format_error_handling(
                master_prompt.instructions.error_handling
            ),
            "domain_knowledge_section": self._format_domain_knowledge(
                master_prompt.context.domain_knowledge
            ),
            "environmental_constraints_section": self._format_environmental_constraints(
                master_prompt.context.environmental_constraints
            ),
            "user_profile_section": self._format_user_profile(
                master_prompt.context.user_profile
            ),
            "performance_history_section": self._format_performance_history(
                master_prompt.context.performance_history
            ),
            "constraints_section": self._format_constraints(
                master_prompt.instructions.constraints
            ),
            "success_metrics_section": self._format_success_metrics(
                master_prompt.instructions.success_metrics
            ),
            "user_input": user_input,
            "task_specific_instructions": self._generate_task_specific_instructions(
                master_prompt, user_input
            ),
            "additional_context": self._generate_additional_context(master_prompt)
        })
        
        return variables
    
    def _render_rich_template(self, template: str, variables: Dict[str, str]) -> str:
        """Render template with rich variable substitution."""
        rendered = template
        
        for key, value in variables.items():
            placeholder = "{" + key + "}"
            rendered = rendered.replace(placeholder, str(value))
        
        return rendered
    
    def _optimize_prompt_structure(
        self, 
        prompt: str, 
        master_prompt: ToxoRichMasterPrompt
    ) -> str:
        """Apply advanced optimizations to prompt structure."""
        # Remove excessive whitespace while preserving structure
        optimized = re.sub(r'\n\s*\n\s*\n', '\n\n', prompt)
        
        # Ensure proper section spacing
        optimized = re.sub(r'(##[^#\n]*)\n([^#\n])', r'\1\n\n\2', optimized)
        
        # Optimize for readability
        optimized = self._optimize_readability(optimized)
        
        # Apply performance-specific optimizations
        if master_prompt.metadata.optimization_target == "speed":
            optimized = self._optimize_for_speed(optimized)
        elif master_prompt.metadata.optimization_target == "accuracy":
            optimized = self._optimize_for_accuracy(optimized)
        
        return optimized.strip()
    
    # Load configuration and knowledge
    def _load_advanced_templates(self):
        """Load advanced template structures."""
        self.templates = {
            "professional": {
                "structure": ["identity", "directive", "capabilities", "guidelines", "context"],
                "formatting": "structured"
            },
            "technical": {
                "structure": ["specifications", "constraints", "protocols", "implementation"],
                "formatting": "detailed"
            },
            "creative": {
                "structure": ["inspiration", "guidelines", "expression", "refinement"],
                "formatting": "fluid"
            }
        }
    
    def _load_domain_expertise(self):
        """Load domain-specific expertise patterns."""
        self.domain_expertise = {
            "finance": {
                "authorities": ["financial analysis", "risk assessment", "regulatory compliance"],
                "capabilities": ["portfolio optimization", "market analysis", "financial modeling"],
                "constraints": ["regulatory compliance", "risk management", "ethical investing"]
            },
            "legal": {
                "authorities": ["legal research", "case analysis", "regulatory interpretation"],
                "capabilities": ["document review", "legal reasoning", "precedent analysis"],
                "constraints": ["confidentiality", "jurisdictional limits", "ethical guidelines"]
            },
            "medical": {
                "authorities": ["clinical knowledge", "evidence-based medicine", "patient safety"],
                "capabilities": ["symptom analysis", "treatment recommendations", "drug interactions"],
                "constraints": ["patient privacy", "medical ethics", "regulatory compliance"]
            },
            "education": {
                "authorities": ["pedagogical methods", "curriculum design", "learning assessment"],
                "capabilities": ["personalized instruction", "knowledge assessment", "skill development"],
                "constraints": ["age-appropriate content", "learning accessibility", "educational standards"]
            },
            "technical": {
                "authorities": ["software architecture", "best practices", "system design"],
                "capabilities": ["code analysis", "debugging", "optimization", "documentation"],
                "constraints": ["security requirements", "performance standards", "maintainability"]
            }
        }
    
    def _load_performance_patterns(self):
        """Load performance optimization patterns."""
        self.performance_patterns = {
            "accuracy": {
                "reasoning": "systematic and thorough",
                "verification": "multi-step validation",
                "output": "detailed and precise"
            },
            "speed": {
                "reasoning": "efficient and direct",
                "verification": "quick validation",
                "output": "concise and actionable"
            },
            "creativity": {
                "reasoning": "divergent and innovative",
                "verification": "originality check",
                "output": "novel and inspiring"
            }
        }
    
    # Helper methods for creating rich content
    def _determine_sophisticated_role(self, task_description: str, domain: str) -> str:
        """Determine sophisticated AI role based on task and domain."""
        role_patterns = {
            "finance": "Expert Financial AI Advisor and Quantitative Analyst",
            "legal": "Advanced Legal AI Research Assistant and Case Analyst", 
            "medical": "Specialized Medical AI Assistant and Clinical Decision Support",
            "education": "Advanced Educational AI Tutor and Learning Specialist",
            "technical": "Senior AI Software Engineering Assistant and Architecture Advisor",
            "creative": "Creative AI Collaborator and Innovation Catalyst",
            "business": "Strategic Business AI Consultant and Market Analyst"
        }
        
        return role_patterns.get(domain, "Advanced AI Assistant and Domain Expert")
    
    def _create_domain_specialization(self, domain: str, complexity_level: str) -> str:
        """Create domain specialization description."""
        base_specializations = {
            "finance": "Financial Analysis and Investment Strategy",
            "legal": "Legal Research and Regulatory Compliance",
            "medical": "Clinical Decision Support and Medical Research",
            "education": "Personalized Learning and Curriculum Development",
            "technical": "Software Architecture and Engineering Best Practices",
            "creative": "Creative Development and Innovation Strategy",
            "business": "Strategic Planning and Business Intelligence"
        }
        
        complexity_modifiers = {
            "simple": "with focus on clarity and accessibility",
            "intermediate": "with balanced depth and practical application",
            "advanced": "with comprehensive expertise and nuanced understanding",
            "expert": "with cutting-edge knowledge and strategic insight"
        }
        
        base = base_specializations.get(domain, "General AI Assistance")
        modifier = complexity_modifiers.get(complexity_level, "with professional competency")
        
        return f"{base} {modifier}"
    
    def _assess_expertise_level(self, complexity_level: str, performance_metrics: Dict[str, float]) -> str:
        """Assess appropriate expertise level."""
        base_levels = {
            "simple": "Competent Professional",
            "intermediate": "Senior Specialist", 
            "advanced": "Subject Matter Expert",
            "expert": "Industry Authority"
        }
        
        # Adjust based on performance
        avg_performance = sum(performance_metrics.values()) / len(performance_metrics) if performance_metrics else 0.5
        
        if avg_performance > 0.9:
            return f"Elite {base_levels.get(complexity_level, 'Professional')}"
        elif avg_performance > 0.8:
            return f"Distinguished {base_levels.get(complexity_level, 'Professional')}"
        else:
            return base_levels.get(complexity_level, "Competent Professional")
    
    def _build_domain_authority(self, domain: str, task_description: str) -> List[str]:
        """Build domain authority areas."""
        domain_data = self.domain_expertise.get(domain, {})
        return domain_data.get("authorities", ["general expertise", "analytical thinking", "problem solving"])
    
    def _define_advanced_capabilities(self, task_description: str, domain: str, complexity_level: str) -> List[str]:
        """Define advanced capabilities based on domain and task."""
        domain_data = self.domain_expertise.get(domain, {})
        base_capabilities = domain_data.get("capabilities", [
            "analytical reasoning", "information synthesis", "solution generation"
        ])
        
        # Add complexity-specific capabilities
        complexity_capabilities = {
            "simple": ["clear communication", "step-by-step guidance"],
            "intermediate": ["critical analysis", "practical recommendations"],
            "advanced": ["strategic thinking", "complex problem solving"],
            "expert": ["innovation leadership", "paradigm development"]
        }
        
        all_capabilities = base_capabilities + complexity_capabilities.get(complexity_level, [])
        return all_capabilities[:6]  # Limit to 6 for clarity
    
    def _define_performance_characteristics(self, complexity_level: str, performance_metrics: Dict[str, float]) -> Dict[str, str]:
        """Define performance characteristics."""
        base_characteristics = {
            "response_quality": "high precision and relevance",
            "reasoning_depth": "thorough and systematic",
            "adaptability": "context-aware and flexible",
            "reliability": "consistent and dependable"
        }
        
        # Adjust based on complexity and performance
        if complexity_level in ["advanced", "expert"]:
            base_characteristics["innovation"] = "creative and forward-thinking"
            base_characteristics["expertise_depth"] = "comprehensive and nuanced"
        
        return base_characteristics
    
    def _select_optimal_persona_traits(self, domain: str, task_description: str) -> List[str]:
        """Select optimal persona traits for the domain."""
        domain_traits = {
            "finance": ["analytical", "detail-oriented", "risk-aware", "ethical"],
            "legal": ["precise", "thorough", "ethical", "objective"],
            "medical": ["careful", "evidence-based", "compassionate", "ethical"],
            "education": ["patient", "encouraging", "adaptive", "supportive"],
            "technical": ["logical", "systematic", "innovative", "precise"],
            "creative": ["imaginative", "open-minded", "inspiring", "original"],
            "business": ["strategic", "results-oriented", "practical", "insightful"]
        }
        
        return domain_traits.get(domain, ["helpful", "professional", "reliable", "knowledgeable"])
    
    def _select_communication_style(self, domain: str, complexity_level: str) -> str:
        """Select appropriate communication style."""
        styles = {
            "finance": "Professional and analytical with clear risk assessments",
            "legal": "Precise and formal with careful qualification of statements",
            "medical": "Careful and evidence-based with appropriate disclaimers",
            "education": "Clear and encouraging with progressive complexity",
            "technical": "Systematic and detailed with practical examples",
            "creative": "Inspiring and open-ended with innovative perspectives",
            "business": "Strategic and results-focused with actionable insights"
        }
        
        base_style = styles.get(domain, "Professional and helpful")
        
        if complexity_level == "expert":
            return f"{base_style}, with sophisticated depth and industry insight"
        elif complexity_level == "simple":
            return f"{base_style}, with accessible explanations and clear guidance"
        else:
            return base_style
    
    # Formatting methods
    def _format_domain_authority(self, authorities: List[str]) -> str:
        """Format domain authority section."""
        if not authorities:
            return "General expertise across multiple domains."
        
        formatted = "## Domain Authority\n"
        for authority in authorities:
            formatted += f"- **{authority.title()}**: Deep expertise and proven track record\n"
        
        return formatted
    
    def _format_capabilities(self, capabilities: List[str]) -> str:
        """Format capabilities section."""
        if not capabilities:
            return "Core AI reasoning and response generation capabilities."
        
        formatted = ""
        for i, capability in enumerate(capabilities, 1):
            formatted += f"{i}. **{capability.title()}**: Advanced proficiency\n"
        
        return formatted
    
    def _format_decision_framework(self, framework: List[str]) -> str:
        """Format decision framework section."""
        if not framework:
            return "Apply logical reasoning and evidence-based decision making."
        
        formatted = ""
        for i, step in enumerate(framework, 1):
            formatted += f"{i}. {step}\n"
        
        return formatted
    
    def _format_quality_standards(self, standards: Dict[str, str]) -> str:
        """Format quality standards section."""
        if not standards:
            return "Maintain high standards of accuracy, relevance, and helpfulness."
        
        formatted = ""
        for standard, description in standards.items():
            formatted += f"- **{standard.title()}**: {description}\n"
        
        return formatted
    
    def _format_output_specifications(self, specs: Dict[str, Any]) -> str:
        """Format output specifications section."""
        if not specs:
            return "Provide clear, well-structured, and actionable responses."
        
        formatted = ""
        for spec, value in specs.items():
            formatted += f"- **{spec.title()}**: {value}\n"
        
        return formatted
    
    def _format_interaction_patterns(self, patterns: List[str]) -> str:
        """Format interaction patterns section."""
        if not patterns:
            return "Engage professionally and helpfully with users."
        
        formatted = ""
        for pattern in patterns:
            formatted += f"- {pattern}\n"
        
        return formatted
    
    def _format_error_handling(self, error_handling: Dict[str, str]) -> str:
        """Format error handling section."""
        if not error_handling:
            return "Handle errors gracefully and provide helpful guidance."
        
        formatted = ""
        for error_type, handling in error_handling.items():
            formatted += f"- **{error_type}**: {handling}\n"
        
        return formatted
    
    def _format_domain_knowledge(self, knowledge: Dict[str, List[str]]) -> str:
        """Format domain knowledge section."""
        if not knowledge:
            return "Access to general knowledge base."
        
        formatted = ""
        for domain, items in knowledge.items():
            formatted += f"### {domain.title()}\n"
            for item in items[:3]:  # Limit to top 3 for brevity
                formatted += f"- {item}\n"
            formatted += "\n"
        
        return formatted
    
    def _format_environmental_constraints(self, constraints: Dict[str, Any]) -> str:
        """Format environmental constraints section."""
        if not constraints:
            return "Operating in standard environment with full capabilities."
        
        formatted = ""
        for constraint, value in constraints.items():
            formatted += f"- **{constraint.title()}**: {value}\n"
        
        return formatted
    
    def _format_user_profile(self, profile: Dict[str, Any]) -> str:
        """Format user profile section."""
        if not profile:
            return "General user with standard preferences."
        
        formatted = ""
        for key, value in profile.items():
            formatted += f"- **{key.title()}**: {value}\n"
        
        return formatted
    
    def _format_performance_history(self, history: Dict[str, float]) -> str:
        """Format performance history section."""
        if not history:
            return "No previous performance metrics available."
        
        formatted = ""
        for metric, value in history.items():
            formatted += f"- **{metric.title()}**: {value:.2f}\n"
        
        return formatted
    
    def _format_constraints(self, constraints: List[str]) -> str:
        """Format constraints section."""
        if not constraints:
            return "Standard operational constraints apply."
        
        formatted = ""
        for constraint in constraints:
            formatted += f"- {constraint}\n"
        
        return formatted
    
    def _format_success_metrics(self, metrics: List[str]) -> str:
        """Format success metrics section."""
        if not metrics:
            return "Success measured by user satisfaction and task completion."
        
        formatted = ""
        for metric in metrics:
            formatted += f"- {metric}\n"
        
        return formatted
    
    # Instruction creation methods
    def _craft_primary_directive(self, task_description: str, domain: str) -> str:
        """Craft the primary directive."""
        return f"Provide expert assistance in {domain} with focus on {task_description}. Deliver accurate, actionable, and contextually appropriate responses that exceed user expectations while maintaining the highest professional standards."
    
    def _define_secondary_objectives(self, task_description: str, domain: str) -> List[str]:
        """Define secondary objectives."""
        return [
            "Maintain consistency with domain best practices",
            "Provide educational value in responses",
            "Ensure scalable and practical solutions",
            "Adapt communication style to user expertise level"
        ]
    
    def _select_reasoning_methodology(self, domain: str, optimization_target: str) -> str:
        """Select reasoning methodology."""
        methodologies = {
            "accuracy": "Systematic analysis with multiple validation steps",
            "speed": "Direct problem-solving with efficient reasoning",
            "creativity": "Divergent thinking with innovative approaches"
        }
        
        base = methodologies.get(optimization_target, "Balanced analytical approach")
        return f"{base} tailored for {domain} domain expertise"
    
    def _build_decision_framework(self, domain: str, user_preferences: Dict[str, Any]) -> List[str]:
        """Build decision framework."""
        return [
            "Analyze the context and requirements thoroughly",
            "Apply domain-specific expertise and best practices",
            "Consider multiple solution approaches",
            "Evaluate options against quality criteria",
            "Select optimal solution with clear rationale",
            "Provide implementation guidance and next steps"
        ]
    
    def _define_quality_standards(self, domain: str, optimization_target: str) -> Dict[str, str]:
        """Define quality standards."""
        return {
            "accuracy": "Verify all information against reliable sources",
            "relevance": "Ensure direct applicability to user needs",
            "completeness": "Address all aspects of the query",
            "clarity": "Use clear and understandable language",
            "actionability": "Provide specific, implementable guidance"
        }
    
    def _create_output_specifications(self, task_description: str, user_preferences: Dict[str, Any]) -> Dict[str, Any]:
        """Create output specifications."""
        return {
            "format": user_preferences.get("format", "structured text"),
            "detail_level": user_preferences.get("detail_level", "comprehensive"),
            "examples": "Include relevant examples when helpful",
            "citations": "Reference sources when appropriate",
            "next_steps": "Provide clear next steps or recommendations"
        }
    
    def _define_interaction_patterns(self, domain: str, user_preferences: Dict[str, Any]) -> List[str]:
        """Define interaction patterns."""
        return [
            "Ask clarifying questions when requirements are ambiguous",
            "Provide progressive disclosure of complex information",
            "Offer alternative approaches when appropriate",
            "Summarize key points at the end of complex responses"
        ]
    
    def _create_error_handling_framework(self, domain: str) -> Dict[str, str]:
        """Create error handling framework."""
        return {
            "unclear_requirements": "Ask specific clarifying questions",
            "insufficient_information": "Request additional context",
            "out_of_scope": "Clearly explain limitations and suggest alternatives",
            "contradictory_inputs": "Identify conflicts and seek clarification"
        }
    
    def _extract_domain_constraints(self, domain: str, task_description: str) -> List[str]:
        """Extract domain constraints."""
        domain_data = self.domain_expertise.get(domain, {})
        base_constraints = domain_data.get("constraints", [])
        
        return base_constraints + [
            "Maintain professional ethical standards",
            "Respect user privacy and confidentiality",
            "Provide disclaimers for professional advice when appropriate"
        ]
    
    def _define_success_metrics(self, domain: str, optimization_target: str) -> List[str]:
        """Define success metrics."""
        return [
            "User query fully addressed",
            "Information accuracy verified",
            "Response clarity and understandability",
            "Practical applicability of guidance",
            "User satisfaction with assistance"
        ]
    
    # Context creation methods
    def _build_domain_knowledge_base(self, domain: str) -> Dict[str, List[str]]:
        """Build domain knowledge base."""
        domain_data = self.domain_expertise.get(domain, {})
        return {
            "core_concepts": domain_data.get("authorities", []),
            "tools_and_methods": domain_data.get("capabilities", []),
            "best_practices": domain_data.get("constraints", [])
        }
    
    def _assess_environmental_constraints(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Assess environmental constraints."""
        return {
            "platform": context.get("platform", "general"),
            "time_constraints": context.get("time_limit", "none"),
            "resource_limitations": context.get("resources", "standard"),
            "accessibility_requirements": context.get("accessibility", "standard")
        }
    
    def _build_user_profile(self, user_preferences: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        """Build user profile."""
        return {
            "expertise_level": user_preferences.get("expertise", "intermediate"),
            "communication_preference": user_preferences.get("style", "professional"),
            "detail_preference": user_preferences.get("detail", "moderate"),
            "goal_orientation": user_preferences.get("goals", "practical")
        }
    
    def _create_temporal_context(self) -> Dict[str, str]:
        """Create temporal context."""
        now = datetime.now()
        return {
            "current_time": now.isoformat(),
            "timezone": "UTC",
            "session_start": now.isoformat()
        }
    
    def _infer_cultural_context(self, user_preferences: Dict[str, Any]) -> Dict[str, str]:
        """Infer cultural context."""
        return {
            "language": user_preferences.get("language", "English"),
            "region": user_preferences.get("region", "Global"),
            "cultural_considerations": user_preferences.get("culture", "Universal")
        }
    
    # Utility methods
    def _infer_task_type(self, description: str) -> str:
        """Infer task type from description."""
        description_lower = description.lower()
        
        if any(word in description_lower for word in ["classify", "categorize", "identify", "recognize"]):
            return "classification"
        elif any(word in description_lower for word in ["generate", "create", "write", "compose"]):
            return "generation"
        elif any(word in description_lower for word in ["analyze", "examine", "evaluate", "assess"]):
            return "analysis"
        elif any(word in description_lower for word in ["question", "answer", "explain", "help"]):
            return "qa"
        elif any(word in description_lower for word in ["summarize", "summary", "brief"]):
            return "summarization"
        elif any(word in description_lower for word in ["recommend", "suggest", "advise"]):
            return "recommendation"
        elif any(word in description_lower for word in ["plan", "strategy", "approach"]):
            return "planning"
        else:
            return "general"
    
    def _get_timestamp(self) -> str:
        """Get current timestamp."""
        return datetime.now().isoformat()
    
    def _generate_task_specific_instructions(self, master_prompt: ToxoRichMasterPrompt, user_input: str) -> str:
        """Generate task-specific instructions."""
        return f"Apply your expertise to address the user's specific request with attention to detail, accuracy, and practical value. Consider the context and provide comprehensive assistance."
    
    def _generate_additional_context(self, master_prompt: ToxoRichMasterPrompt) -> str:
        """Generate additional context."""
        if master_prompt.context.retrieved_documents:
            return f"\n\n## Retrieved Knowledge\nRelevant information has been retrieved to enhance response accuracy."
        return ""
    
    def _optimize_readability(self, prompt: str) -> str:
        """Optimize prompt for readability."""
        # Ensure proper spacing after headers
        prompt = re.sub(r'(^#{1,6}[^#\n]*)\n([^#\n\s])', r'\1\n\n\2', prompt, flags=re.MULTILINE)
        
        # Ensure proper list formatting
        prompt = re.sub(r'\n-([^\n])', r'\n- \1', prompt)
        prompt = re.sub(r'\n(\d+\.)([^\n])', r'\n\1 \2', prompt)
        
        return prompt
    
    def _optimize_for_speed(self, prompt: str) -> str:
        """Optimize prompt for speed."""
        # Reduce verbosity while maintaining clarity
        prompt = re.sub(r'\n\n+', '\n\n', prompt)
        return prompt
    
    def _optimize_for_accuracy(self, prompt: str) -> str:
        """Optimize prompt for accuracy."""
        # Ensure all important sections are present
        if "## Quality Standards" not in prompt:
            prompt += "\n\n## Quality Standards\nMaintain highest accuracy and verify all information."
        return prompt
    
    def adapt_rich_prompt_from_feedback(
        self,
        master_prompt: ToxoRichMasterPrompt,
        feedback: Dict[str, Any],
        performance_metrics: Dict[str, float]
    ) -> ToxoRichMasterPrompt:
        """
        Adapt and evolve the rich prompt based on feedback and performance.
        
        Args:
            master_prompt: Current rich master prompt
            feedback: User and system feedback
            performance_metrics: Current performance data
            
        Returns:
            Enhanced rich master prompt
        """
        # Clone the current prompt
        enhanced_prompt = self._clone_rich_master_prompt(master_prompt)
        
        # Analyze feedback patterns
        feedback_analysis = self._analyze_feedback_patterns(feedback, performance_metrics)
        
        # Update identity based on performance
        if feedback_analysis.get("enhance_expertise"):
            enhanced_prompt.identity = self._enhance_identity_expertise(
                enhanced_prompt.identity, feedback_analysis
            )
        
        # Refine instructions based on specific feedback
        if feedback_analysis.get("instruction_refinements"):
            enhanced_prompt.instructions = self._refine_instructions(
                enhanced_prompt.instructions, feedback_analysis
            )
        
        # Update context with new learnings
        enhanced_prompt.context.performance_history.update(performance_metrics)
        
        # Update metadata
        enhanced_prompt.metadata.revision_history.append({
            "timestamp": self._get_timestamp(),
            "feedback_summary": feedback_analysis.get("summary", ""),
            "performance_change": self._calculate_performance_delta(
                master_prompt.context.performance_history, performance_metrics
            ),
            "adaptations_made": feedback_analysis.get("adaptations", [])
        })
        
        # Increment version
        enhanced_prompt.metadata.version = self._increment_version(master_prompt.metadata.version)
        
        self.logger.info(f"Adapted rich prompt based on feedback, new version: {enhanced_prompt.metadata.version}")
        return enhanced_prompt
    
    def _clone_rich_master_prompt(self, master_prompt: ToxoRichMasterPrompt) -> ToxoRichMasterPrompt:
        """Create a deep copy of rich master prompt."""
        return ToxoRichMasterPrompt(
            identity=RichPromptIdentity(**asdict(master_prompt.identity)),
            instructions=RichPromptInstructions(**asdict(master_prompt.instructions)),
            context=RichPromptContext(**asdict(master_prompt.context)),
            metadata=RichPromptMetadata(**asdict(master_prompt.metadata))
        )
    
    def _analyze_feedback_patterns(self, feedback: Dict[str, Any], performance_metrics: Dict[str, float]) -> Dict[str, Any]:
        """Analyze feedback patterns to determine adaptations."""
        analysis = {
            "summary": feedback.get("feedback_type", "general"),
            "enhance_expertise": False,
            "instruction_refinements": [],
            "adaptations": []
        }
        
        # Check if performance is declining
        if "accuracy" in performance_metrics and performance_metrics["accuracy"] < 0.7:
            analysis["enhance_expertise"] = True
            analysis["adaptations"].append("Enhanced expertise level")
        
        # Check feedback type for specific improvements
        if feedback.get("feedback_type") == "correction":
            analysis["instruction_refinements"].append("Improve accuracy standards")
            analysis["adaptations"].append("Refined accuracy requirements")
        
        return analysis
    
    def _enhance_identity_expertise(self, identity: RichPromptIdentity, feedback_analysis: Dict[str, Any]) -> RichPromptIdentity:
        """Enhance identity based on feedback analysis."""
        enhanced_identity = RichPromptIdentity(**asdict(identity))
        
        # Upgrade expertise level if needed
        if "Senior" in enhanced_identity.expertise_level:
            enhanced_identity.expertise_level = enhanced_identity.expertise_level.replace("Senior", "Distinguished")
        elif "Competent" in enhanced_identity.expertise_level:
            enhanced_identity.expertise_level = enhanced_identity.expertise_level.replace("Competent", "Senior")
        
        # Add accuracy-focused capabilities
        if "Enhanced accuracy verification" not in enhanced_identity.capabilities:
            enhanced_identity.capabilities.append("Enhanced accuracy verification")
        
        return enhanced_identity
    
    def _refine_instructions(self, instructions: RichPromptInstructions, feedback_analysis: Dict[str, Any]) -> RichPromptInstructions:
        """Refine instructions based on feedback analysis."""
        enhanced_instructions = RichPromptInstructions(**asdict(instructions))
        
        # Add accuracy-focused quality standards
        enhanced_instructions.quality_standards["verification"] = "Double-check all facts and calculations"
        enhanced_instructions.quality_standards["precision"] = "Ensure precise and specific responses"
        
        # Add feedback-specific constraints
        enhanced_instructions.constraints.append("Verify accuracy before finalizing responses")
        
        return enhanced_instructions
    
    def _calculate_performance_delta(self, old_metrics: Dict[str, float], new_metrics: Dict[str, float]) -> Dict[str, float]:
        """Calculate performance change delta."""
        delta = {}
        for metric in new_metrics:
            if metric in old_metrics:
                delta[metric] = new_metrics[metric] - old_metrics[metric]
            else:
                delta[metric] = new_metrics[metric]
        return delta
    
    def _increment_version(self, current_version: str) -> str:
        """Increment version number."""
        try:
            major, minor, patch = current_version.split('.')
            patch = str(int(patch) + 1)
            return f"{major}.{minor}.{patch}"
        except:
            return "1.0.1"

    async def create_ai_enhanced_master_prompt(
        self,
        task_description: str,
        domain: str = "general",
        user_preferences: Optional[Dict[str, Any]] = None,
        context: Optional[Dict[str, Any]] = None,
        performance_metrics: Optional[Dict[str, float]] = None,
        complexity_level: str = "intermediate",
        optimization_target: str = "accuracy",
        enhancement_level: str = "full"
    ) -> ToxoRichMasterPrompt:
        """
        Create an AI-enhanced master prompt using Gemini intelligence.
        
        Args:
            task_description: Detailed description of the AI task
            domain: Domain specialization (finance, legal, medical, etc.)
            user_preferences: User-specific preferences and requirements
            context: Additional contextual information
            performance_metrics: Historical performance data
            complexity_level: simple, intermediate, advanced, expert
            optimization_target: accuracy, speed, creativity, safety
            enhancement_level: basic, moderate, full, experimental
            
        Returns:
            AI-enhanced ToxoRichMasterPrompt with dynamic intelligence
        """
        user_preferences = user_preferences or {}
        context = context or {}
        performance_metrics = performance_metrics or {}
        
        if not self.ai_enhanced:
            # Fallback to static generation
            return self.create_rich_master_prompt(
                task_description, domain, user_preferences, context,
                performance_metrics, complexity_level, optimization_target
            )
        
        try:
            # Step 1: AI-powered task analysis
            task_analysis = await self._ai_analyze_task(task_description, domain)
            
            # Step 2: Generate AI-enhanced identity
            enhanced_identity = await self._ai_create_enhanced_identity(
                task_analysis, complexity_level, performance_metrics
            )
            
            # Step 3: Generate AI-optimized instructions
            optimized_instructions = await self._ai_create_optimized_instructions(
                task_analysis, user_preferences, optimization_target
            )
            
            # Step 4: Build intelligent context
            intelligent_context = await self._ai_build_intelligent_context(
                context, task_analysis, user_preferences, performance_metrics
            )
            
            # Step 5: Create metadata with AI insights
            ai_metadata = await self._ai_create_metadata(
                task_analysis, enhancement_level, optimization_target
            )
            
            # Assemble the AI-enhanced master prompt
            master_prompt = ToxoRichMasterPrompt(
                identity=enhanced_identity,
                instructions=optimized_instructions,
                context=intelligent_context,
                metadata=ai_metadata
            )
            
            # Step 6: AI-powered final optimization
            if enhancement_level in ["full", "experimental"]:
                master_prompt = await self._ai_optimize_final_prompt(master_prompt)
            
            self.logger.info(f"Created AI-enhanced master prompt for {domain} domain")
            return master_prompt
            
        except Exception as e:
            self.logger.error(f"AI enhancement failed, falling back to static: {str(e)}")
            return self.create_rich_master_prompt(
                task_description, domain, user_preferences, context,
                performance_metrics, complexity_level, optimization_target
            )

    async def optimize_prompt_with_ai(
        self,
        current_prompt: ToxoRichMasterPrompt,
        performance_metrics: Dict[str, float],
        user_feedback: Optional[List[str]] = None,
        target_improvements: Optional[List[str]] = None
    ) -> ToxoRichMasterPrompt:
        """
        Use Gemini to optimize an existing prompt based on performance and feedback.
        
        Args:
            current_prompt: Current master prompt to optimize
            performance_metrics: Performance data (accuracy, speed, etc.)
            user_feedback: User feedback and corrections
            target_improvements: Specific areas to improve
            
        Returns:
            Optimized ToxoRichMasterPrompt
        """
        if not self.ai_enhanced:
            return current_prompt
        
        try:
            # Analyze current performance
            performance_analysis = await self._ai_analyze_performance(
                current_prompt, performance_metrics, user_feedback
            )
            
            # Generate optimization strategy
            optimization_strategy = await self._ai_create_optimization_strategy(
                performance_analysis, target_improvements
            )
            
            # Apply AI-powered improvements
            optimized_prompt = await self._ai_apply_optimizations(
                current_prompt, optimization_strategy
            )
            
            # Validate improvements
            if await self._ai_validate_improvements(current_prompt, optimized_prompt):
                self.logger.info("Successfully optimized prompt with AI")
                return optimized_prompt
            else:
                self.logger.warning("AI optimization did not meet validation criteria")
                return current_prompt
                
        except Exception as e:
            self.logger.error(f"AI optimization failed: {str(e)}")
            return current_prompt

    async def adapt_prompt_from_feedback(
        self,
        master_prompt: ToxoRichMasterPrompt,
        user_feedback: str,
        interaction_context: Dict[str, Any],
        adaptation_strength: float = 0.5
    ) -> ToxoRichMasterPrompt:
        """
        Dynamically adapt prompt based on real-time user feedback using AI.
        
        Args:
            master_prompt: Current master prompt
            user_feedback: User's feedback or correction
            interaction_context: Context of the interaction
            adaptation_strength: How strongly to adapt (0.0 to 1.0)
            
        Returns:
            Adapted ToxoRichMasterPrompt
        """
        if not self.ai_enhanced:
            return self.adapt_rich_prompt_from_feedback(
                master_prompt, {"feedback": user_feedback}, {}
            )
        
        try:
            # AI analysis of feedback
            feedback_analysis = await self._ai_analyze_user_feedback(
                user_feedback, interaction_context, master_prompt
            )
            
            # Generate adaptation strategy
            adaptation_plan = await self._ai_create_adaptation_plan(
                feedback_analysis, adaptation_strength
            )
            
            # Apply real-time adaptations
            adapted_prompt = await self._ai_apply_real_time_adaptations(
                master_prompt, adaptation_plan
            )
            
            self.logger.info("Applied AI-powered real-time adaptation")
            return adapted_prompt
            
        except Exception as e:
            self.logger.error(f"AI adaptation failed: {str(e)}")
            return master_prompt

    async def generate_domain_specific_prompt(
        self,
        domain: str,
        task_description: str,
        expertise_requirements: List[str],
        performance_constraints: Dict[str, Any]
    ) -> ToxoRichMasterPrompt:
        """
        Generate highly specialized prompts for specific domains using AI.
        
        Args:
            domain: Specific domain (e.g., "medical-radiology", "legal-contracts")
            task_description: Detailed task requirements
            expertise_requirements: Required expertise areas
            performance_constraints: Performance requirements and constraints
            
        Returns:
            Domain-optimized ToxoRichMasterPrompt
        """
        if not self.ai_enhanced:
            return await self.create_ai_enhanced_master_prompt(
                task_description, domain
            )
        
        try:
            # AI-powered domain analysis
            domain_intelligence = await self._ai_analyze_domain_requirements(
                domain, task_description, expertise_requirements
            )
            
            # Generate specialized identity
            specialist_identity = await self._ai_create_specialist_identity(
                domain_intelligence, expertise_requirements
            )
            
            # Create domain-specific instructions
            specialist_instructions = await self._ai_create_specialist_instructions(
                domain_intelligence, performance_constraints
            )
            
            # Build domain context
            domain_context = await self._ai_build_domain_context(
                domain_intelligence, task_description
            )
            
            # Create specialized metadata
            specialist_metadata = RichPromptMetadata(
                version="1.0",
                created_at=self._get_timestamp(),
                domain=domain,
                task_type=self._infer_task_type(task_description),
                complexity_level="expert",
                optimization_target="domain_accuracy",
                performance_benchmarks={},
                revision_history=[]
            )
            
            specialist_prompt = ToxoRichMasterPrompt(
                identity=specialist_identity,
                instructions=specialist_instructions,
                context=domain_context,
                metadata=specialist_metadata
            )
            
            self.logger.info(f"Generated AI-enhanced domain-specific prompt for {domain}")
            return specialist_prompt
            
        except Exception as e:
            self.logger.error(f"Domain-specific generation failed: {str(e)}")
            raise PromptError(f"Failed to generate domain prompt: {str(e)}")

    # AI-powered internal methods
    async def _ai_analyze_task(
        self, 
        task_description: str, 
        domain: str
    ) -> Dict[str, Any]:
        """Use AI to deeply analyze the task requirements."""
        analysis_prompt = f"""
        As an expert prompt engineer, analyze this AI task in extreme detail:
        
        Task: {task_description}
        Domain: {domain}
        
        Provide a comprehensive analysis as JSON with:
        {{
            "core_objectives": ["primary goals of this task"],
            "cognitive_requirements": ["thinking patterns needed"],
            "knowledge_domains": ["areas of expertise required"],
            "interaction_patterns": ["how the AI should interact"],
            "quality_criteria": ["what makes a good response"],
            "potential_challenges": ["likely difficulties or edge cases"],
            "success_indicators": ["how to measure success"],
            "communication_style": "appropriate tone and style",
            "reasoning_approach": "best reasoning methodology",
            "creativity_level": "required creativity (low/medium/high)",
            "precision_requirements": "precision needs (relaxed/strict/exact)"
        }}
        
        Think step by step and provide deep insights.
        """
        
        try:
            response = await self.gemini_client.generate(analysis_prompt)
            return extract_json_from_response(response)
        except Exception as e:
            self.logger.warning(f"AI task analysis failed: {e}")
            return self._fallback_task_analysis(task_description, domain)

    async def _ai_create_enhanced_identity(
        self,
        task_analysis: Dict[str, Any],
        complexity_level: str,
        performance_metrics: Dict[str, float]
    ) -> RichPromptIdentity:
        """Generate an AI-enhanced identity based on deep task analysis."""
        identity_prompt = f"""
        Create an optimal AI identity for this task analysis:
        
        Analysis: {json.dumps(task_analysis, indent=2)}
        Complexity: {complexity_level}
        Past Performance: {performance_metrics}
        
        Design an AI identity as JSON:
        {{
            "core_role": "precise role definition",
            "specialization": "specific area of expertise",
            "expertise_level": "beginner/intermediate/advanced/expert/world-class",
            "domain_authority": ["specific authorities and credentials"],
            "capabilities": ["precise capabilities and skills"],
            "performance_characteristics": {{
                "accuracy": "accuracy focus description",
                "speed": "speed characteristics",
                "depth": "depth of analysis",
                "creativity": "creative capabilities"
            }},
            "persona_traits": ["personality and behavioral traits"],
            "communication_style": "communication approach"
        }}
        
        Make it sophisticated and precisely tailored.
        """
        
        try:
            response = await self.gemini_client.generate(identity_prompt)
            identity_data = extract_json_from_response(response)
            
            return RichPromptIdentity(
                core_role=identity_data.get("core_role", "AI Assistant"),
                specialization=identity_data.get("specialization", "General"),
                expertise_level=identity_data.get("expertise_level", "advanced"),
                domain_authority=identity_data.get("domain_authority", []),
                capabilities=identity_data.get("capabilities", []),
                performance_characteristics=identity_data.get("performance_characteristics", {}),
                persona_traits=identity_data.get("persona_traits", []),
                communication_style=identity_data.get("communication_style", "professional")
            )
        except Exception as e:
            self.logger.warning(f"AI identity creation failed: {e}")
            return self._create_rich_identity(
                str(task_analysis), "general", complexity_level, performance_metrics
            )

    async def _ai_create_optimized_instructions(
        self,
        task_analysis: Dict[str, Any],
        user_preferences: Dict[str, Any],
        optimization_target: str
    ) -> RichPromptInstructions:
        """Generate AI-optimized instructions for maximum performance."""
        instructions_prompt = f"""
        Create optimized AI instructions for maximum {optimization_target}:
        
        Task Analysis: {json.dumps(task_analysis, indent=2)}
        User Preferences: {json.dumps(user_preferences, indent=2)}
        Optimization Target: {optimization_target}
        
        Generate comprehensive instructions as JSON:
        {{
            "primary_directive": "clear, actionable primary instruction",
            "secondary_objectives": ["supporting objectives"],
            "reasoning_methodology": "step-by-step reasoning approach",
            "decision_framework": ["decision-making guidelines"],
            "quality_standards": {{
                "accuracy": "accuracy requirements",
                "completeness": "completeness standards",
                "clarity": "clarity expectations",
                "relevance": "relevance criteria"
            }},
            "output_specifications": {{
                "format": "output format requirements",
                "structure": "structural requirements",
                "tone": "tone and style",
                "length": "length guidelines"
            }},
            "interaction_patterns": ["how to interact with users"],
            "error_handling": {{
                "uncertainty": "how to handle uncertainty",
                "conflicts": "how to resolve conflicts",
                "missing_info": "how to handle missing information"
            }},
            "constraints": ["important limitations and boundaries"],
            "success_metrics": ["how to measure success"]
        }}
        
        Optimize for {optimization_target} while maintaining quality.
        """
        
        try:
            response = await self.gemini_client.generate(instructions_prompt)
            instructions_data = extract_json_from_response(response)
            
            return RichPromptInstructions(
                primary_directive=instructions_data.get("primary_directive", ""),
                secondary_objectives=instructions_data.get("secondary_objectives", []),
                reasoning_methodology=instructions_data.get("reasoning_methodology", ""),
                decision_framework=instructions_data.get("decision_framework", []),
                quality_standards=instructions_data.get("quality_standards", {}),
                output_specifications=instructions_data.get("output_specifications", {}),
                interaction_patterns=instructions_data.get("interaction_patterns", []),
                error_handling=instructions_data.get("error_handling", {}),
                constraints=instructions_data.get("constraints", []),
                success_metrics=instructions_data.get("success_metrics", [])
            )
        except Exception as e:
            self.logger.warning(f"AI instructions creation failed: {e}")
            return self._create_rich_instructions(
                str(task_analysis), "general", user_preferences, optimization_target
            )

    async def _ai_build_intelligent_context(
        self,
        context: Dict[str, Any],
        task_analysis: Dict[str, Any],
        user_preferences: Dict[str, Any],
        performance_metrics: Dict[str, float]
    ) -> RichPromptContext:
        """Build intelligent context using AI analysis."""
        context_prompt = f"""
        Build intelligent context for optimal AI performance:
        
        Base Context: {json.dumps(context, indent=2)}
        Task Analysis: {json.dumps(task_analysis, indent=2)}
        User Preferences: {json.dumps(user_preferences, indent=2)}
        Performance Data: {performance_metrics}
        
        Create enriched context as JSON:
        {{
            "domain_knowledge": {{
                "core_concepts": ["key concepts for this domain"],
                "best_practices": ["domain best practices"],
                "common_patterns": ["typical patterns and approaches"],
                "expert_insights": ["expert-level insights"]
            }},
            "environmental_constraints": {{
                "technical_limits": "technical limitations",
                "time_constraints": "timing requirements",
                "resource_limits": "resource constraints",
                "quality_thresholds": "minimum quality requirements"
            }},
            "user_profile": {{
                "expertise_level": "user's expertise level",
                "communication_preference": "preferred communication style",
                "detail_preference": "preferred level of detail",
                "interaction_style": "preferred interaction approach"
            }},
            "session_memory": {{
                "key_learnings": ["important learnings from past interactions"],
                "successful_patterns": ["patterns that worked well"],
                "areas_for_improvement": ["areas that need attention"]
            }},
            "performance_history": {performance_metrics},
            "temporal_context": {{
                "current_time": "{datetime.now().isoformat()}",
                "session_duration": "expected session characteristics",
                "urgency_level": "task urgency level"
            }},
            "cultural_context": {{
                "communication_norms": "appropriate communication norms",
                "cultural_sensitivity": "cultural considerations",
                "localization_needs": "localization requirements"
            }}
        }}
        
        Make it comprehensive and intelligence-driven.
        """
        
        try:
            response = await self.gemini_client.generate(context_prompt)
            context_data = extract_json_from_response(response)
            
            return RichPromptContext(
                domain_knowledge=context_data.get("domain_knowledge", {}),
                environmental_constraints=context_data.get("environmental_constraints", {}),
                user_profile=context_data.get("user_profile", {}),
                session_memory=context_data.get("session_memory", {}),
                performance_history=context_data.get("performance_history", performance_metrics),
                retrieved_documents=[],  # Will be populated separately
                conversation_context=[],  # Will be populated during use
                temporal_context=context_data.get("temporal_context", {}),
                cultural_context=context_data.get("cultural_context", {})
            )
        except Exception as e:
            self.logger.warning(f"AI context building failed: {e}")
            return self._create_rich_context(
                context, "general", user_preferences, performance_metrics
            )

    async def _ai_create_metadata(
        self,
        task_analysis: Dict[str, Any],
        enhancement_level: str,
        optimization_target: str
    ) -> RichPromptMetadata:
        """Create AI-enhanced metadata with intelligent insights."""
        return RichPromptMetadata(
            version="1.0-ai-enhanced",
            created_at=self._get_timestamp(),
            domain=task_analysis.get("knowledge_domains", ["general"])[0],
            task_type=task_analysis.get("core_objectives", ["general"])[0],
            complexity_level=enhancement_level,
            optimization_target=optimization_target,
            performance_benchmarks={},
            revision_history=[{
                "timestamp": self._get_timestamp(),
                "change_type": "ai_creation",
                "enhancement_level": enhancement_level,
                "ai_features": ["task_analysis", "identity_optimization", "instruction_enhancement"]
            }]
        )

    async def _ai_optimize_final_prompt(
        self, 
        master_prompt: ToxoRichMasterPrompt
    ) -> ToxoRichMasterPrompt:
        """Apply final AI-powered optimizations to the complete prompt."""
        optimization_prompt = f"""
        As an expert prompt engineer, review and optimize this complete prompt structure:
        
        Current Prompt Structure:
        {json.dumps(master_prompt.to_dict(), indent=2)}
        
        Analyze and suggest specific improvements for:
        1. Identity coherence and specialization
        2. Instruction clarity and actionability  
        3. Context relevance and completeness
        4. Overall prompt effectiveness
        
        Provide optimization suggestions as JSON:
        {{
            "identity_improvements": ["specific identity enhancements"],
            "instruction_improvements": ["instruction optimizations"],
            "context_improvements": ["context enrichments"],
            "overall_improvements": ["holistic improvements"],
            "risk_assessments": ["potential issues to watch"],
            "performance_predictions": {{
                "accuracy": "predicted accuracy improvement",
                "speed": "predicted speed impact",
                "user_satisfaction": "predicted user satisfaction"
            }}
        }}
        
        Focus on practical, measurable improvements.
        """
        
        try:
            response = await self.gemini_client.generate(optimization_prompt)
            optimization_data = extract_json_from_response(response)
            
            # Apply optimizations (simplified implementation)
            # In a full implementation, this would selectively apply the suggested improvements
            
            # For now, we'll log the suggestions and return the prompt
            self.logger.info(f"AI optimization suggestions: {optimization_data}")
            
            # Update metadata with optimization info
            master_prompt.metadata.revision_history.append({
                "timestamp": self._get_timestamp(),
                "change_type": "ai_optimization",
                "optimizations_applied": optimization_data.get("overall_improvements", []),
                "performance_predictions": optimization_data.get("performance_predictions", {})
            })
            
            return master_prompt
            
        except Exception as e:
            self.logger.warning(f"AI final optimization failed: {e}")
            return master_prompt

    def _fallback_task_analysis(self, task_description: str, domain: str) -> Dict[str, Any]:
        """Fallback task analysis when AI is unavailable."""
        return {
            "core_objectives": [task_description],
            "cognitive_requirements": ["analysis", "reasoning"],
            "knowledge_domains": [domain],
            "interaction_patterns": ["helpful", "accurate"],
            "quality_criteria": ["accuracy", "relevance"],
            "potential_challenges": ["complexity", "ambiguity"],
            "success_indicators": ["user_satisfaction"],
            "communication_style": "professional",
            "reasoning_approach": "step_by_step",
            "creativity_level": "medium",
            "precision_requirements": "strict"
        }

    # Additional AI-powered methods for optimization and adaptation
    async def _ai_analyze_performance(
        self,
        current_prompt: ToxoRichMasterPrompt,
        performance_metrics: Dict[str, float],
        user_feedback: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """Analyze current prompt performance using AI."""
        analysis_prompt = f"""
        As a prompt performance analyst, analyze this prompt's effectiveness:
        
        Current Prompt Identity: {current_prompt.identity.core_role}
        Domain: {current_prompt.metadata.domain}
        Performance Metrics: {performance_metrics}
        User Feedback: {user_feedback or []}
        
        Provide performance analysis as JSON:
        {{
            "strengths": ["what's working well"],
            "weaknesses": ["areas needing improvement"],
            "performance_gaps": ["specific performance issues"],
            "optimization_opportunities": ["specific improvements to make"],
            "user_satisfaction_indicators": ["feedback patterns analysis"],
            "technical_recommendations": ["technical improvements"]
        }}
        """
        
        try:
            if self.gemini_client:
                response = await self.gemini_client.generate(analysis_prompt)
                return extract_json_from_response(response)
        except Exception as e:
            self.logger.warning(f"AI performance analysis failed: {e}")
        
        return {
            "strengths": ["functional"],
            "weaknesses": ["needs optimization"],
            "performance_gaps": ["accuracy"],
            "optimization_opportunities": ["prompt clarity"],
            "user_satisfaction_indicators": ["neutral"],
            "technical_recommendations": ["review structure"]
        }

    async def _ai_create_optimization_strategy(
        self,
        performance_analysis: Dict[str, Any],
        target_improvements: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """Create optimization strategy based on performance analysis."""
        strategy_prompt = f"""
        Based on this performance analysis, create an optimization strategy:
        
        Analysis: {json.dumps(performance_analysis, indent=2)}
        Target Improvements: {target_improvements or []}
        
        Create optimization strategy as JSON:
        {{
            "priority_actions": ["most important changes"],
            "identity_adjustments": ["how to improve the AI identity"],
            "instruction_refinements": ["how to refine instructions"],
            "context_enhancements": ["how to improve context"],
            "success_metrics": ["how to measure improvement"],
            "implementation_steps": ["step-by-step implementation"]
        }}
        """
        
        try:
            if self.gemini_client:
                response = await self.gemini_client.generate(strategy_prompt)
                return extract_json_from_response(response)
        except Exception as e:
            self.logger.warning(f"AI optimization strategy failed: {e}")
        
        return {
            "priority_actions": ["improve clarity"],
            "identity_adjustments": ["enhance expertise"],
            "instruction_refinements": ["clarify directives"],
            "context_enhancements": ["add relevant context"],
            "success_metrics": ["accuracy", "user_satisfaction"],
            "implementation_steps": ["review", "update", "test"]
        }

    async def _ai_apply_optimizations(
        self,
        current_prompt: ToxoRichMasterPrompt,
        optimization_strategy: Dict[str, Any]
    ) -> ToxoRichMasterPrompt:
        """Apply AI-generated optimizations to the prompt."""
        # Clone the current prompt
        optimized_prompt = self._clone_rich_master_prompt(current_prompt)
        
        # Apply identity adjustments
        identity_adjustments = optimization_strategy.get("identity_adjustments", [])
        if identity_adjustments:
            # Enhance expertise level if suggested
            if "enhance expertise" in str(identity_adjustments):
                optimized_prompt.identity.expertise_level = "expert"
            
            # Add new capabilities
            new_capabilities = [adj for adj in identity_adjustments if "capability" in adj.lower()]
            optimized_prompt.identity.capabilities.extend(new_capabilities)
        
        # Apply instruction refinements
        instruction_changes = optimization_strategy.get("instruction_refinements", [])
        if instruction_changes:
            # Enhance primary directive
            if optimized_prompt.instructions.primary_directive:
                optimized_prompt.instructions.primary_directive += " " + " ".join(instruction_changes)
        
        # Update metadata
        optimized_prompt.metadata.revision_history.append({
            "timestamp": self._get_timestamp(),
            "change_type": "ai_optimization",
            "optimizations_applied": optimization_strategy.get("priority_actions", []),
            "performance_target": optimization_strategy.get("success_metrics", [])
        })
        
        return optimized_prompt

    async def _ai_validate_improvements(
        self,
        original_prompt: ToxoRichMasterPrompt,
        optimized_prompt: ToxoRichMasterPrompt
    ) -> bool:
        """Validate that optimizations actually improve the prompt."""
        validation_prompt = f"""
        Compare these two prompts and determine if the optimized version is better:
        
        Original: {original_prompt.identity.core_role} - {original_prompt.instructions.primary_directive[:100]}...
        Optimized: {optimized_prompt.identity.core_role} - {optimized_prompt.instructions.primary_directive[:100]}...
        
        Is the optimized version better? Respond with just "true" or "false".
        """
        
        try:
            if self.gemini_client:
                response = await self.gemini_client.generate(validation_prompt)
                return response.strip().lower() == "true"
        except Exception as e:
            self.logger.warning(f"AI validation failed: {e}")
        
        return True  # Default to accepting optimizations

    async def _ai_analyze_user_feedback(
        self,
        user_feedback: str,
        interaction_context: Dict[str, Any],
        master_prompt: ToxoRichMasterPrompt
    ) -> Dict[str, Any]:
        """Analyze user feedback using AI to understand needed adaptations."""
        feedback_prompt = f"""
        Analyze this user feedback in context:
        
        User Feedback: "{user_feedback}"
        Interaction Context: {json.dumps(interaction_context, indent=2)}
        Current AI Role: {master_prompt.identity.core_role}
        
        Provide feedback analysis as JSON:
        {{
            "feedback_sentiment": "positive/negative/neutral",
            "specific_issues": ["what specifically needs fixing"],
            "suggested_improvements": ["concrete improvements"],
            "adaptation_priority": "high/medium/low",
            "affected_components": ["identity/instructions/context"],
            "user_expectations": ["what the user actually wants"]
        }}
        """
        
        try:
            if self.gemini_client:
                response = await self.gemini_client.generate(feedback_prompt)
                return extract_json_from_response(response)
        except Exception as e:
            self.logger.warning(f"AI feedback analysis failed: {e}")
        
        return {
            "feedback_type": "general",
            "sentiment": "neutral",
            "specific_issues": ["unclear"],
            "suggested_improvements": ["clarify instructions"],
            "priority_level": "medium",
            "adaptation_areas": ["instructions"]
        }

    async def _ai_create_adaptation_plan(
        self,
        feedback_analysis: Dict[str, Any],
        adaptation_strength: float
    ) -> Dict[str, Any]:
        """Create a plan for adapting the prompt based on feedback."""
        plan_prompt = f"""
        Create an adaptation plan based on this feedback analysis:
        
        Analysis: {json.dumps(feedback_analysis, indent=2)}
        Adaptation Strength: {adaptation_strength}
        
        Create adaptation plan as JSON:
        {{
            "identity_changes": ["adjust communication style"],
            "instruction_updates": ["clarify directives"],
            "context_modifications": ["add relevant context"],
            "implementation_priority": "high",
            "validation_criteria": ["user satisfaction"]
        }}
        """
        
        try:
            if self.gemini_client:
                response = await self.gemini_client.generate(plan_prompt)
                return extract_json_from_response(response)
        except Exception as e:
            self.logger.warning(f"AI adaptation plan failed: {e}")
        
        return {
            "identity_changes": ["adjust communication style"],
            "instruction_updates": ["clarify directives"],
            "context_modifications": ["add relevant context"],
            "implementation_priority": "high",
            "validation_criteria": ["user satisfaction"]
        }

    async def _ai_apply_real_time_adaptations(
        self,
        master_prompt: ToxoRichMasterPrompt,
        adaptation_plan: Dict[str, Any]
    ) -> ToxoRichMasterPrompt:
        """Apply real-time adaptations to the prompt."""
        adapted_prompt = self._clone_rich_master_prompt(master_prompt)
        
        # Apply immediate changes
        immediate_changes = adaptation_plan.get("immediate_changes", [])
        component_mods = adaptation_plan.get("component_modifications", {})
        
        # Modify identity if needed
        identity_changes = component_mods.get("identity", [])
        if identity_changes:
            for change in identity_changes:
                if "enhance expertise" in change:
                    adapted_prompt.identity.expertise_level = "expert"
                elif "improve communication" in change:
                    adapted_prompt.identity.communication_style = "adaptive"
        
        # Modify instructions if needed
        instruction_changes = component_mods.get("instructions", [])
        if instruction_changes:
            adapted_prompt.instructions.constraints.extend(instruction_changes)
        
        # Update metadata
        adapted_prompt.metadata.revision_history.append({
            "timestamp": self._get_timestamp(),
            "change_type": "real_time_adaptation",
            "adaptations_applied": immediate_changes,
            "adaptation_trigger": "user_feedback"
        })
        
        return adapted_prompt

    # Domain-specific AI methods
    async def _ai_analyze_domain_requirements(
        self,
        domain: str,
        task_description: str,
        expertise_requirements: List[str]
    ) -> Dict[str, Any]:
        """Analyze domain-specific requirements using AI."""
        requirements_prompt = f"""
        As a domain expert analyst, analyze requirements for this specialized domain:
        
        Domain: {domain}
        Task: {task_description}
        Expertise Required: {expertise_requirements}
        
        Provide domain analysis as JSON:
        {{
            "domain_complexity": "basic/intermediate/advanced/expert",
            "key_concepts": ["essential domain concepts"],
            "specialized_knowledge": ["domain-specific knowledge needed"],
            "industry_standards": ["relevant standards and practices"],
            "common_challenges": ["typical challenges in this domain"],
            "success_factors": ["what makes someone successful in this domain"],
            "communication_norms": ["how experts in this domain communicate"],
            "tools_and_methods": ["tools and methodologies used"]
        }}
        """
        
        try:
            if self.gemini_client:
                response = await self.gemini_client.generate(requirements_prompt)
                return extract_json_from_response(response)
        except Exception as e:
            self.logger.warning(f"AI domain analysis failed: {e}")
        
        # Fallback analysis
        return {
            "domain_characteristics": [f"{domain} requires specialized knowledge"],
            "key_competencies": expertise_requirements,
            "critical_success_factors": ["accuracy", "domain relevance"],
            "common_challenges": ["complexity", "technical accuracy"],
            "expert_methodologies": ["systematic analysis"],
            "quality_indicators": ["precision", "completeness"]
        }

    async def _ai_create_specialist_identity(
        self,
        domain_intelligence: Dict[str, Any],
        expertise_requirements: List[str]
    ) -> RichPromptIdentity:
        """Create a specialist identity for specific domains."""
        identity_prompt = f"""
        Create a specialist AI identity based on this domain intelligence:
        
        Domain Intelligence: {json.dumps(domain_intelligence, indent=2)}
        Expertise Requirements: {expertise_requirements}
        
        Create specialist identity as JSON:
        {{
            "core_role": "specific professional role title",
            "specialization": "area of deep expertise",
            "expertise_level": "expert/world-class/authority",
            "domain_authority": ["specific credentials and authorities"],
            "capabilities": ["precise professional capabilities"],
            "performance_characteristics": {{
                "accuracy": "accuracy expectations",
                "depth": "depth of knowledge",
                "speed": "response speed",
                "innovation": "creative problem-solving"
            }},
            "persona_traits": ["professional personality traits"],
            "communication_style": "domain-appropriate communication style"
        }}
        """
        
        try:
            if self.gemini_client:
                response = await self.gemini_client.generate(identity_prompt)
                identity_data = extract_json_from_response(response)
                
                # Extract domain name for fallback values
                domain_name = domain_intelligence.get("key_concepts", ["specialist"])[0]
                
                return RichPromptIdentity(
                    core_role=identity_data.get("core_role", f"{domain_name.title()} Specialist"),
                    specialization=identity_data.get("specialization", f"{domain_name} expertise"),
                    expertise_level=identity_data.get("expertise_level", "expert"),
                    domain_authority=identity_data.get("domain_authority", []),
                    capabilities=identity_data.get("capabilities", []),
                    performance_characteristics=identity_data.get("performance_characteristics", {}),
                    persona_traits=identity_data.get("persona_traits", []),
                    communication_style=identity_data.get("communication_style", "professional")
                )
        except Exception as e:
            self.logger.warning(f"AI specialist identity creation failed: {e}")
        
        # Fallback identity creation
        domain_name = domain_intelligence.get("key_concepts", ["specialist"])[0]
        return RichPromptIdentity(
            core_role=f"{domain_name} Specialist",
            specialization=domain_name,
            expertise_level="expert",
            domain_authority=[f"{domain_name} Expert"],
            capabilities=[f"{domain_name} Analysis", "Problem Solving"],
            performance_characteristics={
                "accuracy": "high precision",
                "depth": "comprehensive analysis",
                "speed": "efficient processing",
                "innovation": "creative solutions"
            },
            persona_traits=["knowledgeable", "analytical", "professional"],
            communication_style="expert-level professional"
        )

    async def _ai_create_specialist_instructions(
        self,
        domain_intelligence: Dict[str, Any],
        performance_constraints: Dict[str, Any]
    ) -> RichPromptInstructions:
        """Create specialist instructions for domain experts."""
        instructions_prompt = f"""
        Create specialist instructions for a domain expert:
        
        Domain Intelligence: {json.dumps(domain_intelligence, indent=2)}
        Performance Constraints: {json.dumps(performance_constraints, indent=2)}
        
        Create instructions as JSON:
        {{
            "primary_directive": "main expert directive",
            "secondary_objectives": ["supporting expert objectives"],
            "reasoning_methodology": "domain-specific reasoning approach",
            "decision_framework": ["expert decision-making guidelines"],
            "quality_standards": {{
                "accuracy": "accuracy requirements",
                "depth": "depth requirements",
                "relevance": "relevance standards",
                "innovation": "innovation expectations"
            }},
            "output_specifications": {{
                "format": "professional output format",
                "detail_level": "appropriate detail level",
                "terminology": "domain terminology usage",
                "structure": "output structure requirements"
            }},
            "interaction_patterns": ["how to interact professionally"],
            "error_handling": {{
                "uncertainty": "how to handle uncertainty",
                "complexity": "how to handle complex issues",
                "limitations": "how to acknowledge limitations"
            }},
            "constraints": ["professional and domain constraints"],
            "success_metrics": ["how to measure expert performance"]
        }}
        """
        
        try:
            if self.gemini_client:
                response = await self.gemini_client.generate(instructions_prompt)
                instructions_data = extract_json_from_response(response)
                
                return RichPromptInstructions(
                    primary_directive=instructions_data.get("primary_directive", "Provide expert guidance"),
                    secondary_objectives=instructions_data.get("secondary_objectives", []),
                    reasoning_methodology=instructions_data.get("reasoning_methodology", "systematic analysis"),
                    decision_framework=instructions_data.get("decision_framework", []),
                    quality_standards=instructions_data.get("quality_standards", {}),
                    output_specifications=instructions_data.get("output_specifications", {}),
                    interaction_patterns=instructions_data.get("interaction_patterns", []),
                    error_handling=instructions_data.get("error_handling", {}),
                    constraints=instructions_data.get("constraints", []),
                    success_metrics=instructions_data.get("success_metrics", [])
                )
        except Exception as e:
            self.logger.warning(f"AI specialist instructions creation failed: {e}")
        
        # Fallback instructions
        domain_name = domain_intelligence.get("key_concepts", ["domain"])[0]
        return RichPromptInstructions(
            primary_directive=f"Provide expert-level {domain_name} analysis and guidance",
            secondary_objectives=[f"Apply {domain_name} best practices", "Ensure accuracy"],
            reasoning_methodology="systematic domain analysis",
            decision_framework=[f"Use {domain_name} standards", "Consider context"],
            quality_standards={
                "accuracy": "expert-level precision",
                "depth": "comprehensive analysis",
                "relevance": "domain-focused",
                "innovation": "creative problem-solving"
            },
            output_specifications={
                "format": "professional response",
                "detail_level": "comprehensive",
                "terminology": f"{domain_name} terminology",
                "structure": "organized presentation"
            },
            interaction_patterns=["professional communication", "expert guidance"],
            error_handling={
                "uncertainty": "acknowledge limitations",
                "complexity": "break down complex issues",
                "limitations": "be transparent about constraints"
            },
            constraints=[f"Maintain {domain_name} standards", "Provide accurate information"],
            success_metrics=["accuracy", "relevance", "user satisfaction"]
        )

    async def _ai_build_domain_context(
        self,
        domain_intelligence: Dict[str, Any],
        task_description: str
    ) -> RichPromptContext:
        """Build domain-specific context using AI intelligence."""
        context_prompt = f"""
        Build specialized domain context:
        
        Domain Intelligence: {json.dumps(domain_intelligence, indent=2)}
        Task: {task_description}
        
        Create domain context as JSON:
        {{
            "domain_knowledge": {{
                "core_principles": ["fundamental domain principles"],
                "methodologies": ["domain methodologies"],
                "best_practices": ["industry best practices"],
                "terminology": ["key domain terms"]
            }},
            "environmental_constraints": {{
                "regulatory": "regulatory considerations",
                "industry_standards": "industry standards",
                "technical_limits": "technical limitations",
                "time_constraints": "typical time constraints"
            }},
            "user_profile": {{
                "typical_expertise": "typical user expertise level",
                "common_needs": "common user needs",
                "communication_preferences": "preferred communication style"
            }},
            "session_memory": {{
                "domain_patterns": ["common domain patterns"],
                "successful_approaches": ["what works well"],
                "common_pitfalls": ["what to avoid"]
            }}
        }}
        """
        
        try:
            if self.gemini_client:
                response = await self.gemini_client.generate(context_prompt)
                context_data = extract_json_from_response(response)
                
                return RichPromptContext(
                    domain_knowledge=context_data.get("domain_knowledge", {}),
                    environmental_constraints=context_data.get("environmental_constraints", {}),
                    user_profile=context_data.get("user_profile", {}),
                    session_memory=context_data.get("session_memory", {}),
                    performance_history=context_data.get("performance_history", {}),
                    retrieved_documents=[],  # Will be populated separately
                    conversation_context=[],  # Will be populated during use
                    temporal_context=context_data.get("temporal_context", {}),
                    cultural_context=context_data.get("cultural_context", {})
                )
        except Exception as e:
            self.logger.warning(f"AI domain context creation failed: {e}")
        
        # Fallback context
        domain_name = domain_intelligence.get("key_concepts", ["domain"])[0]
        return RichPromptContext(
            domain_knowledge={
                "core_principles": [f"{domain_name} fundamentals"],
                "methodologies": [f"{domain_name} approaches"],
                "best_practices": [f"{domain_name} best practices"],
                "terminology": [f"{domain_name} terms"]
            },
            environmental_constraints={
                "industry_standards": f"{domain_name} standards",
                "technical_limits": "standard limitations",
                "time_constraints": "reasonable timeframes"
            },
            user_profile={
                "typical_expertise": "intermediate",
                "common_needs": f"{domain_name} guidance",
                "communication_preferences": "clear and professional"
            },
            session_memory={
                "domain_patterns": [f"common {domain_name} patterns"],
                "successful_approaches": ["systematic analysis"],
                "common_pitfalls": ["avoid oversimplification"]
            },
            performance_history={},
            retrieved_documents=[],
            conversation_context=[],
            temporal_context=self._create_temporal_context(),
            cultural_context={}
        ) 


class ProfessionalAIPatterns:
    """Professional AI patterns inspired by top-tier AI tools"""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        
        # Professional patterns from leading AI tools
        self.patterns = {
            "financial_advisor": {
                "identity": """You are an elite financial advisor AI operating at the sophistication level of top-tier investment banks and hedge funds. You have been trained on specialized contexts and must provide professional-quality analysis.

You are advising clients on complex financial decisions with real-world implications. Each response must demonstrate deep market understanding, quantitative analysis, and strategic thinking that rivals the best human financial advisors.""",
                
                "approach": """<analytical_framework>
Following patterns from Cursor, v0, and Devin AI, your responses must:

1. **ANALYTICAL DEPTH**: Provide quantitative analysis with specific numbers, ratios, calculations
2. **MARKET CONTEXT**: Begin with current macroeconomic environment assessment
3. **STRUCTURED REASONING**: Use clear frameworks and methodologies
4. **ACTIONABLE RECOMMENDATIONS**: Give specific, implementable advice with timelines
5. **RISK MANAGEMENT**: Include comprehensive risk assessment and mitigation strategies
6. **PROFESSIONAL TERMINOLOGY**: Use sophisticated financial language appropriately
</analytical_framework>""",
                
                "expertise_areas": [
                    "Portfolio optimization and asset allocation",
                    "Risk management and hedging strategies", 
                    "Macroeconomic analysis and market timing",
                    "Equity valuation and fundamental analysis",
                    "Fixed income and credit analysis",
                    "Currency and commodity markets",
                    "Alternative investments and derivatives",
                    "Regulatory and tax considerations"
                ],
                
                "response_structure": """<response_methodology>
Your response should follow this professional framework:

**EXECUTIVE SUMMARY**
- One-paragraph synthesis of key findings and recommendations

**MARKET CONTEXT & ANALYSIS**
- Current macroeconomic environment
- Relevant market conditions and sector dynamics
- Key risk factors and opportunities

**QUANTITATIVE ASSESSMENT**
- Specific calculations, ratios, financial models
- Historical data and benchmark comparisons
- Scenario analysis with probability weightings

**STRATEGIC RECOMMENDATIONS**
- Clear, actionable investment/financial advice
- Implementation timeline and specific steps
- Alternative strategies and contingency plans

**RISK MANAGEMENT FRAMEWORK**
- Identified risks and quantified impact
- Specific hedging recommendations
- Portfolio protection measures

**MONITORING & EXECUTION**
- Key performance indicators to track
- Rebalancing triggers and thresholds
- Review schedule and adjustment criteria
</response_methodology>"""
            },
            
            "legal_advisor": {
                "identity": """You are an elite legal AI advisor operating at the sophistication level of top-tier law firms. You provide comprehensive legal analysis with the precision and depth expected from senior partners at prestigious firms.""",
                
                "approach": """<legal_framework>
Your responses must demonstrate:
1. **LEGAL PRECISION**: Accurate citation of relevant laws, regulations, and precedents
2. **RISK ANALYSIS**: Comprehensive assessment of legal risks and exposure
3. **STRATEGIC COUNSEL**: Practical advice balancing legal requirements with business objectives
4. **COMPLIANCE FOCUS**: Detailed compliance requirements and implementation steps
5. **PRECEDENT ANALYSIS**: Reference to relevant case law and regulatory guidance
</legal_framework>""",
                
                "expertise_areas": [
                    "Corporate law and governance",
                    "Contract negotiation and drafting",
                    "Regulatory compliance",
                    "Intellectual property protection",
                    "Employment law and HR compliance",
                    "Mergers and acquisitions",
                    "Securities law and public offerings",
                    "International trade and customs"
                ]
            },
            
            "medical_advisor": {
                "identity": """You are an elite medical AI advisor operating at the sophistication level of leading medical institutions. You provide evidence-based medical analysis with the rigor expected from top medical professionals.""",
                
                "approach": """<medical_framework>
Your responses must demonstrate:
1. **EVIDENCE-BASED ANALYSIS**: Reference to peer-reviewed research and clinical guidelines
2. **DIFFERENTIAL DIAGNOSIS**: Systematic consideration of multiple possibilities
3. **RISK STRATIFICATION**: Assessment of patient risk factors and contraindications
4. **TREATMENT PROTOCOLS**: Detailed treatment recommendations with monitoring plans
5. **SAFETY CONSIDERATIONS**: Comprehensive safety profile and adverse event monitoring
</medical_framework>""",
                
                "expertise_areas": [
                    "Clinical diagnosis and treatment",
                    "Pharmacology and drug interactions",
                    "Medical device evaluation",
                    "Clinical trial design and analysis",
                    "Healthcare quality and safety",
                    "Medical imaging interpretation",
                    "Laboratory medicine",
                    "Preventive medicine and screening"
                ]
            }
        }
    
    def get_pattern(self, domain: str) -> Dict[str, Any]:
        """Get professional pattern for domain"""
        return self.patterns.get(domain, self.patterns["financial_advisor"])
    
    def extract_domain_concepts(self, query: str, domain: str = "financial_advisor") -> List[str]:
        """Extract key concepts from query for contextual enhancement"""
        concepts = []
        query_lower = query.lower()
        
        # Domain-specific concept maps
        concept_maps = {
            "financial_advisor": {
                'portfolio': ['portfolio management', 'asset allocation'],
                'risk': ['risk management', 'risk assessment'],
                'hedge': ['hedging strategies', 'risk mitigation'],
                'fed': ['monetary policy', 'central banking'],
                'inflation': ['inflation analysis', 'macroeconomic factors'],
                'equity': ['equity analysis', 'stock valuation'],
                'bond': ['fixed income', 'credit analysis'],
                'wacc': ['cost of capital', 'corporate finance'],
                'valuation': ['company valuation', 'financial modeling'],
                'roe': ['profitability analysis', 'financial ratios'],
                'startup': ['venture capital', 'growth investing'],
                'currency': ['foreign exchange', 'international finance'],
                'market': ['market analysis', 'economic trends'],
                'investment': ['investment strategy', 'capital allocation'],
                'ebitda': ['earnings analysis', 'cash flow analysis'],
                'dividend': ['dividend policy', 'yield analysis'],
                'recession': ['economic cycles', 'defensive strategies']
            },
            
            "legal_advisor": {
                'contract': ['contract law', 'agreement drafting'],
                'compliance': ['regulatory compliance', 'legal requirements'],
                'liability': ['legal liability', 'risk exposure'],
                'intellectual property': ['IP protection', 'patent law'],
                'merger': ['M&A transactions', 'due diligence'],
                'securities': ['securities law', 'public offerings'],
                'employment': ['employment law', 'HR compliance'],
                'litigation': ['dispute resolution', 'court proceedings']
            },
            
            "medical_advisor": {
                'diagnosis': ['clinical diagnosis', 'differential diagnosis'],
                'treatment': ['treatment protocols', 'therapeutic interventions'],
                'drug': ['pharmacology', 'drug interactions'],
                'clinical trial': ['clinical research', 'evidence-based medicine'],
                'safety': ['patient safety', 'adverse events'],
                'imaging': ['medical imaging', 'diagnostic imaging'],
                'laboratory': ['lab tests', 'biomarkers'],
                'prevention': ['preventive medicine', 'screening protocols']
            }
        }
        
        concept_map = concept_maps.get(domain, concept_maps["financial_advisor"])
        
        for keyword, related_concepts in concept_map.items():
            if keyword in query_lower:
                concepts.extend(related_concepts)
        
        return list(set(concepts))  # Remove duplicates


class DynamicDomainAnalyzer:
    """Advanced domain analysis for query-specific response generation"""
    
    def __init__(self):
        self.logger = get_logger(__name__)
    
    def analyze_query_domain(self, query: str, context_data: Dict[str, Any]) -> Dict[str, Any]:
        """Dynamically analyze query domain and extract key concepts"""
        query_lower = query.lower()
        
        # Advanced domain classification
        domain_indicators = {
            'financial_advisor': [
                'portfolio', 'investment', 'stock', 'bond', 'market', 'finance', 'trading',
                'hedge', 'risk', 'return', 'valuation', 'equity', 'debt', 'currency',
                'fed', 'inflation', 'recession', 'gdp', 'earnings', 'dividend', 'ipo',
                'wacc', 'roe', 'ebitda', 'cash flow', 'p/e', 'p/b', 'dcf'
            ],
            'legal_advisor': [
                'contract', 'law', 'legal', 'compliance', 'regulation', 'liability',
                'court', 'litigation', 'patent', 'trademark', 'copyright', 'merger',
                'acquisition', 'securities', 'employment', 'intellectual property'
            ],
            'medical_advisor': [
                'medical', 'health', 'diagnosis', 'treatment', 'drug', 'patient',
                'clinical', 'therapy', 'disease', 'symptom', 'medication', 'surgery',
                'imaging', 'laboratory', 'prevention', 'screening', 'clinical trial'
            ],
            'technology_advisor': [
                'software', 'hardware', 'algorithm', 'data', 'ai', 'machine learning',
                'cloud', 'security', 'network', 'database', 'api', 'framework',
                'programming', 'development', 'architecture', 'scalability'
            ]
        }
        
        # Score each domain
        domain_scores = {}
        for domain, indicators in domain_indicators.items():
            score = sum(1 for indicator in indicators if indicator in query_lower)
            if score > 0:
                domain_scores[domain] = score
        
        # Determine primary domain
        primary_domain = max(domain_scores, key=domain_scores.get) if domain_scores else 'financial_advisor'
        
        # Extract specific concepts using ProfessionalAIPatterns
        patterns = ProfessionalAIPatterns()
        concepts = patterns.extract_domain_concepts(query, primary_domain)
        
        # Determine complexity level
        complexity_indicators = {
            'high': ['derivative', 'quantitative', 'algorithmic', 'sophisticated', 'advanced', 'complex'],
            'medium': ['analysis', 'strategy', 'optimization', 'evaluation', 'assessment'],
            'basic': ['simple', 'basic', 'introduction', 'overview', 'general']
        }
        
        complexity_score = {'high': 0, 'medium': 0, 'basic': 0}
        for level, indicators in complexity_indicators.items():
            complexity_score[level] = sum(1 for indicator in indicators if indicator in query_lower)
        
        complexity = max(complexity_score, key=complexity_score.get)
        
        # Market/domain context analysis
        context_keywords = {
            'financial_advisor': {
                'recession': 'Economic downturn concerns',
                'inflation': 'Inflationary environment',
                'fed': 'Central bank policy focus',
                'rate': 'Interest rate environment',
                'yield': 'Bond market dynamics',
                'currency': 'Foreign exchange considerations'
            },
            'legal_advisor': {
                'regulation': 'Regulatory environment changes',
                'compliance': 'Compliance requirements focus',
                'litigation': 'Legal dispute considerations',
                'merger': 'M&A transaction environment'
            },
            'medical_advisor': {
                'clinical': 'Clinical practice considerations',
                'safety': 'Patient safety focus',
                'trial': 'Clinical research environment',
                'regulation': 'Medical regulatory landscape'
            }
        }
        
        domain_contexts = context_keywords.get(primary_domain, {})
        active_contexts = []
        for keyword, context in domain_contexts.items():
            if keyword in query_lower:
                active_contexts.append(context)
        
        return {
            'domain': primary_domain.replace('_', ' ').title(),
            'concepts': concepts,
            'complexity': complexity,
            'context': ', '.join(active_contexts) if active_contexts else 'General domain conditions',
            'confidence': domain_scores.get(primary_domain, 0) / max(1, len(query.split()))
        }


class EnhancedMetaPromptGenerator:
    """Generate sophisticated meta-prompts using professional AI patterns"""
    
    def __init__(self):
        self.patterns = ProfessionalAIPatterns()
        self.domain_analyzer = DynamicDomainAnalyzer()
        self.logger = get_logger(__name__)
    
    def create_professional_meta_prompt(
        self, 
        base_prompt: str, 
        query: str, 
        context_data: Dict[str, Any],
        domain: Optional[str] = None
    ) -> str:
        """Create sophisticated meta-prompt based on professional AI patterns"""
        
        # Analyze query domain if not specified
        if not domain:
            domain_analysis = self.domain_analyzer.analyze_query_domain(query, context_data)
            domain = domain_analysis['domain'].lower().replace(' ', '_')
        else:
            domain_analysis = self.domain_analyzer.analyze_query_domain(query, context_data)
        
        # Get professional pattern for domain
        pattern = self.patterns.get_pattern(domain)
        
        # Create sophisticated meta-prompt
        meta_prompt = f"""You are operating at the sophistication level of top-tier professional services. You have been trained on specialized contexts and must provide professional-quality analysis.

## CORE IDENTITY & APPROACH
{pattern['identity']}

{pattern['approach']}

## DOMAIN EXPERTISE
Your specialized knowledge areas include:
{chr(10).join([f"• {area}" for area in pattern['expertise_areas']])}

## CURRENT ANALYSIS CONTEXT
**User Query**: {query}

**Domain Analysis**:
- Primary Domain: {domain_analysis['domain']}
- Key Concepts: {', '.join(domain_analysis['concepts'])}
- Complexity Level: {domain_analysis['complexity']}
- Domain Context: {domain_analysis['context']}
- Analysis Confidence: {domain_analysis['confidence']:.2f}

**Training Context Integration**:
- Specialized Training Contexts: {context_data.get('context_count', 0)}
- Context Details: {context_data.get('training_contexts', [])}
- Layer Influence: {context_data.get('layer_influence', 'N/A')}

## ENHANCED BASE PROMPT
{base_prompt}

{pattern.get('response_structure', '')}

## CRITICAL REQUIREMENTS

- **NO GENERIC STATEMENTS**: Every recommendation must be specific to this query
- **QUANTITATIVE FOCUS**: Include specific numbers, percentages, ratios where applicable
- **CONTEXTUAL INTEGRATION**: Reference the training contexts provided
- **PROFESSIONAL QUALITY**: Match the sophistication of top-tier professional services
- **FRESH ANALYSIS**: Generate completely original insights, no template responses

Generate a comprehensive, professional analysis that demonstrates deep expertise and provides genuine value."""

        return meta_prompt