"""
Training components for Toxo layers.
"""

# Core training components
from .soft_prompt import SoftPromptEngine
from .evolutionary_optimizer import EvolutionaryOptimizer, Individual

# Try to import ResponseReranker, but make it optional due to dependency issues
try:
    from .reranker import ResponseReranker
    RERANKER_AVAILABLE = True
except ImportError as e:
    ResponseReranker = None
    RERANKER_AVAILABLE = False
    print(f"Warning: ResponseReranker not available due to dependency issue: {e}")

# from .spsa_optimizer import SPSAOptimizer  # Not available
# from .trainer import ToxoTrainer, TrainingExample  # Not available

__all__ = [
    'SoftPromptEngine',
    'EvolutionaryOptimizer', 
    'Individual',
    # 'SPSAOptimizer',  # Not available
    # 'ToxoTrainer',  # Not available
    # 'TrainingExample',  # Not available
] 

# Add ResponseReranker to exports if available
if RERANKER_AVAILABLE:
    __all__.append('ResponseReranker') 