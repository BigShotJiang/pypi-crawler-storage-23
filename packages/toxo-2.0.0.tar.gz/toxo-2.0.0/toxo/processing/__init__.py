"""
Document processing modules for Toxo.

This package provides comprehensive document processing capabilities including:
- Basic document processing for common formats
- Advanced multi-modal processing with vision models
- Gemini-powered intelligent document analysis
- Simple processors for testing and development
"""

from .document_processor import DocumentProcessor
from .advanced_document_processor import AdvancedDocumentProcessor
from .enhanced_multimodal_processor import (
    EnhancedMultiModalProcessor,
    VisionModelProcessor,
    FormulaProcessor,
    EnhancedSpreadsheetProcessor,
    DocumentLayout,
    LayoutElement,
    create_enhanced_multimodal_processor
)
from .simple_multimodal_processor import (
    SimpleMultiModalProcessor,
    SimpleFormulaProcessor,
    create_simple_multimodal_processor
)
from .gemini_document_processor import (
    GeminiDocumentProcessor,
    DocumentInsights,
    ProcessingResult,
    create_gemini_document_processor
)

__all__ = [
    # Basic processors
    'DocumentProcessor',
    'AdvancedDocumentProcessor',
    
    # Enhanced multimodal processing
    'EnhancedMultiModalProcessor',
    'VisionModelProcessor',
    'FormulaProcessor',
    'EnhancedSpreadsheetProcessor',
    'DocumentLayout',
    'LayoutElement',
    'create_enhanced_multimodal_processor',
    
    # Simple processors for testing
    'SimpleMultiModalProcessor',
    'SimpleFormulaProcessor',
    'create_simple_multimodal_processor',
    
    # Gemini-powered processing
    'GeminiDocumentProcessor',
    'DocumentInsights',
    'ProcessingResult',
    'create_gemini_document_processor'
] 