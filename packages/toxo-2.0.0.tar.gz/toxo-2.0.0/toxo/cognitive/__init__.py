"""
Cognitive features for Toxo layers.

This module provides advanced cognitive capabilities including
self-improvement, meta-learning, autonomous optimization, and
enterprise-grade retrieval-augmented generation.
"""

from .self_improvement import (
    SelfImprovementEngine,
    PerformanceMonitor,
    StrategyEngine,
    MetaLearner,
    PerformanceMetric,
    ImprovementStrategy,
    OptimizationGoal
)

# Advanced RAG system
from .advanced_rag import (
    AdvancedRAGSystem,
    QueryProcessor,
    AdvancedRetriever,
    ResultRanker,
    ContextCompressor,
    RetrievalStrategy,
    FusionMethod,
    RetrievalQuery,
    RetrievalResult,
    RAGResponse,
    create_advanced_rag_system
)

# Phase 2: Advanced Feedback Learning System
from .advanced_feedback_learning import (
    AdvancedFeedbackLearningSystem,
    FeedbackInstance,
    PreferenceComparison,
    AdaptationTrigger,
    BradleyTerryModel,
    DeepPreferenceNetwork,
    MultiArmedBandit,
    ConceptDriftDetector,
    FeedbackType,
    LearningStrategy,
    create_advanced_feedback_learning_system
)

__all__ = [
    # Self-improvement components
    "SelfImprovementEngine",
    "PerformanceMonitor", 
    "StrategyEngine",
    "MetaLearner",
    "PerformanceMetric",
    "ImprovementStrategy",
    "OptimizationGoal",
    
    # Advanced RAG system
    "AdvancedRAGSystem",
    "QueryProcessor",
    "AdvancedRetriever",
    "ResultRanker",
    "ContextCompressor",
    "RetrievalStrategy",
    "FusionMethod",
    "RetrievalQuery",
    "RetrievalResult",
    "RAGResponse",
    "create_advanced_rag_system",
    
    # Phase 2: Advanced Feedback Learning
    "AdvancedFeedbackLearningSystem",
    "FeedbackInstance",
    "PreferenceComparison",
    "AdaptationTrigger",
    "BradleyTerryModel",
    "DeepPreferenceNetwork",
    "MultiArmedBandit",
    "ConceptDriftDetector",
    "FeedbackType",
    "LearningStrategy",
    "create_advanced_feedback_learning_system"
] 