"""
TOXO - Smart Layer for Context Augmented Language Models (CALM)
Public Python Package for .toxo file support

v2.0: Enhanced - loads prompt_config, memory_state, and uses ALL layer knowledge.

Usage:
    from toxo import ToxoLayer
    
    # Load your trained model
    layer = ToxoLayer.load("your_model.toxo")
    
    # Set your API key (Gemini, OpenAI, or Claude)
    layer.setup_api_key("your_api_key", "gemini-2.0-flash-exp", provider="gemini")
    
    # Query with optional depth control
    response = layer.query("Your question", response_depth="balanced")
"""

__version__ = "2.0.0"
__author__ = "ToxoTune"
__email__ = "support@toxotune.com"
__license__ = "Proprietary"

# Import the main user-facing class
from .core import ToxoLayer

# Import utility functions
from .utils import get_version, check_dependencies

# Public API
__all__ = [
    "ToxoLayer",
    "get_version", 
    "check_dependencies",
    "__version__",
]

# Version check and welcome message
def _check_environment():
    """Check if the environment is properly set up."""
    import sys
    if sys.version_info < (3, 8):
        raise RuntimeError("TOXO requires Python 3.8 or higher")

# Run environment check on import
_check_environment()

# Optional: Print welcome message (can be disabled with environment variable)
import os
if not os.environ.get("TOXO_QUIET", False):
    print(f"🧠 TOXO v{__version__} - Smart Layer for Context Augmented Language Models (CALM)")
    print("   Visit https://toxotune.com to create your AI experts")