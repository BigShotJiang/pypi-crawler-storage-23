"""
Frankenreview v11 - The Squeezer (token_governor.py)
Layer 4: Ensures we don't crash the browser with a 50MB paste.

This module handles token estimation and content pruning to fit
within Gemini's context window limits.

Features:
- XML-aware pruning (preserves file boundaries)
- Priority file preservation
- Proper XML structure maintenance
"""

import re
from typing import List, Tuple, Optional

from ..utils.log_config import get_logger

# Module logger
log = get_logger("frankenreview.token")

# Type aliases
FileBlock = Tuple[str, str, int]  # (path, block_content, char_count)


def estimate_tokens(text: str) -> float:
    """
    Estimate tokens using tiktoken (cl100k_base) if available.
    Fallback to calibrated 3.7 chars/token heuristic (matches CLI).
    """
    try:
        import tiktoken
        enc = tiktoken.get_encoding("cl100k_base")
        return len(enc.encode(text))
    except ImportError:
        return len(text) / 3.7  # Calibrated heuristic
    except Exception as e:
        return len(text) / 3.7  # Calibrated heuristic


def parse_xml_files(xml_content: str) -> Tuple[str, List[FileBlock], str]:
    """
    Parse XML content using strict UUID delimiters.
    Legacy/Naive parsing has been REMOVED to prevent data corruption (P0).
    """
    files: List[FileBlock] = []
    
    # 1. Attempt UUID Extraction
    uuid_match = re.search(r'<!-- REPO_UUID:([a-f0-9]+) -->', xml_content)
    
    if not uuid_match:
        # If no UUID found, we cannot safely split without risking corruption.
        # Return as single blob.
        return xml_content, [], ""

    sys_uuid = uuid_match.group(1)
    
    start_marker = f"<!-- START_FILE:{sys_uuid}:"
    end_marker = f"<!-- END_FILE:{sys_uuid}:"
    
    current_pos = 0
    header_end = xml_content.find(start_marker)
    if header_end == -1:
        # Maybe empty ref? find first generic tag
        header_end = xml_content.find("<file_tree>")
        
    header = xml_content[:header_end] if header_end != -1 else ""
    
    last_file_end = header_end
    
    while True:
        # Find next start marker
        start_idx = xml_content.find(start_marker, current_pos)
        if start_idx == -1:
            break
            
        # Find path end delimiter " -->"
        path_end_idx = xml_content.find(" -->", start_idx)
        if path_end_idx == -1:
            break
            
        # Extract Path (Base64 Encoded)
        b64_path = xml_content[start_idx + len(start_marker):path_end_idx]
        
        try:
            import base64
            path = base64.b64decode(b64_path).decode('utf-8')
        except Exception:
            # Fallback for legacy dumps (plain path)
            path = b64_path
        
        # Find matching END marker (using the exact string found in start, i.e. b64)
        specific_end_marker = f"{end_marker}{b64_path} -->"
        end_idx = xml_content.find(specific_end_marker, path_end_idx)
        
        if end_idx == -1:
            # Try legacy end marker just in case
            legacy_end = f"{end_marker}{path} -->"
            end_idx = xml_content.find(legacy_end, path_end_idx)
            if end_idx == -1:
                # Broken file, skip
                current_pos = path_end_idx
                continue
            specific_end_marker = legacy_end
            
        full_block_end = end_idx + len(specific_end_marker)
        
        full_block = xml_content[start_idx:full_block_end]
        files.append((path, full_block, len(full_block)))
        
        current_pos = full_block_end
        last_file_end = full_block_end
        
    if files:
        footer = xml_content[last_file_end:]
        return header, files, footer

    return header, files, ""


def select_files_for_budget(
    files: List[FileBlock], 
    budget_chars: int, 
    priority_patterns: Optional[List[str]] = None
) -> List[FileBlock]:
    """
    Select files to include within the character budget.
    
    Strategy: DROP LARGEST FILES FIRST
    1. Always include priority files (config, main entry points)
    2. Sort remaining files by size (largest first)
    3. Drop largest non-priority files until under budget
    
    Args:
        files: List of (path, block, char_count) tuples
        budget_chars: Maximum characters for file content
        priority_patterns: Patterns for must-include files
    
    Returns:
        List of (path, block, char_count) tuples to include
    """
    priority_patterns = priority_patterns
    
    if not priority_patterns:
        # Fallback to defaults if not provided by caller or config
        priority_patterns = [
            r'^config\.yaml$', r'^main\.py$', r'__init__\.py$', r'^setup\.py$', r'^pyproject\.toml$',
            r'^package\.json$', r'^requirements\.txt$', r'^README\.md$', 
            r'core/daemon\.py$', r'engine/browser/client\.py$', r'engine/governor\.py$', r'engine/repo_dumper\.py$'
        ]
    
    # Categorize files
    priority_files: List[FileBlock] = []
    regular_files: List[FileBlock] = []
    
    for path, block, count in files:
        is_priority = any(re.search(pat, path, re.I) for pat in priority_patterns)
        if is_priority:
            priority_files.append((path, block, count))
        else:
            regular_files.append((path, block, count))
    
    # Priority files are always included
    priority_size = sum(f[2] for f in priority_files)
    remaining_budget = budget_chars - priority_size
    
    if remaining_budget <= 0:
        # Only priority files fit
        log.warning("Budget tight - only priority files included")
        return priority_files
    
    # Sort regular files by size (SMALLEST first - so we keep small files, drop large ones)
    regular_files_sorted = sorted(regular_files, key=lambda x: x[2])
    
    # Greedily add files until budget exhausted
    selected: List[FileBlock] = []
    total_size = 0
    
    for path, block, count in regular_files_sorted:
        if total_size + count <= remaining_budget:
            selected.append((path, block, count))
            total_size += count
    
    # Count what's being dropped (large files that didn't fit)
    dropped = len(regular_files) - len(selected)
    if dropped > 0:
        # Find which files get dropped (the largest ones)
        dropped_files = sorted(regular_files, key=lambda x: -x[2])[:dropped]
        dropped_names = [f[0].split('/')[-1] for f in dropped_files[:5]]
        log.info(f"Dropping {dropped} largest files: {', '.join(dropped_names)}{'...' if dropped > 5 else ''}")
    
    # Combine and return in original order
    result = priority_files + selected
    original_order = {f[0]: i for i, f in enumerate(files)}
    result.sort(key=lambda f: original_order.get(f[0], 999))
    
    return result


def optimize_dump(xml_content: str, max_tokens: int = 1000000, priority_patterns: Optional[List[str]] = None) -> str:
    """
    Ensures we don't crash the browser with a 50MB paste.
    
    Uses XML-aware pruning to preserve file boundaries and structure.
    
    Strategy:
    1. Estimate token count
    2. If under limit, pass through unchanged
    3. If over limit, parse XML and select files intelligently
    
    Args:
        xml_content: The XML dump content
        max_tokens: Maximum tokens allowed (default: 1M for Gemini 2.5)
        priority_patterns: Optional patterns to always preserve
    
    Returns:
        Optimized content that fits within token limits with valid XML
    """
    estimated_tokens = estimate_tokens(xml_content)
    
    # [FEATURE] Always analyze and display Top 3 Token Eaters
    header, files, footer = parse_xml_files(xml_content)
    
    if files:
        sorted_by_size = sorted(files, key=lambda x: x[2], reverse=True)
        top_3 = sorted_by_size[:3]
        print("\n[i] Top 3 Token Eaters:")
        for f in top_3:
            # Estimate: char_count / 2.0 (heuristic)
            est = int(f[2] / 2.0)
            print(f"    - {f[0]}: {f[2]:,} chars (~{est:,} tokens)")
        print("")

    if estimated_tokens < max_tokens:
        return xml_content
        
    log.info(f"Dump too large ({int(estimated_tokens):,} tokens). Pruning...")
    
    # Target 80% of limit for safety margin
    target_chars = int(max_tokens * 4 * 0.8)
    
    if not files:
        # No file structure found, fall back to simple truncation
        log.warning("No XML file structure found, using simple truncation")
        return xml_content[:target_chars] + "\n<!-- CONTENT TRUNCATED -->\n</repository_context>"
    
    # Calculate budget for files (subtract header and footer)
    header_footer_size = len(header) + len(footer)
    file_budget = target_chars - header_footer_size
    
    if file_budget <= 0:
        # Header and footer alone exceed budget
        log.warning("Header too large, truncating")
        return xml_content[:target_chars]
    
    # Select files that fit in budget
    selected_files = select_files_for_budget(files, file_budget, priority_patterns=priority_patterns)
    
    # Count what we're dropping
    dropped_count = len(files) - len(selected_files)
    dropped_chars = sum(f[2] for f in files) - sum(f[2] for f in selected_files)
    
    if dropped_count > 0:
        log.info(f"Dropping {dropped_count} files ({dropped_chars:,} chars) from middle")
    
    # Rebuild content
    content_parts = [header]
    
    if dropped_count > 0:
        content_parts.append(f"\n<!-- {dropped_count} files ({dropped_chars:,} chars) omitted for size -->\n\n")
    
    for path, block, _ in selected_files:
        content_parts.append(block + "\n\n")
    
    content_parts.append(footer)
    
    result = "".join(content_parts)
    log.info(f"Pruned from {len(xml_content):,} to {len(result):,} chars ({len(selected_files)}/{len(files)} files)")
    
    return result


def smart_prune(
    xml_content: str, 
    max_tokens: int = 1000000, 
    priority_files: Optional[List[str]] = None
) -> str:
    """
    Advanced pruning that prioritizes certain files.
    
    Args:
        xml_content: The XML dump content
        max_tokens: Maximum tokens allowed
        priority_files: List of file patterns to always include
    
    Returns:
        Optimized content with priority files preserved
    """
    # Use optimize_dump with custom priority patterns
    return optimize_dump(xml_content, max_tokens, priority_patterns=priority_files)
