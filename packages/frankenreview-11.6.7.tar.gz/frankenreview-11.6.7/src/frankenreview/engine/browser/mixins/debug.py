"""
Debug utilities for browser automation.
Handles screenshots, debug captures, and path formatting.
"""
import os
import glob
import time


class DebugMixin:
    """Mixin providing debug and screenshot capabilities."""
    def _cleanup_screenshots(self):
        """Keep only the N most recent screenshots in the dumps folder."""
        try:
            pattern = os.path.join(self.dump_dir, "*.png")
            files = sorted(glob.glob(pattern), key=os.path.getmtime)
            
            if len(files) > self.screenshot_keep_max:
                to_delete = files[:len(files) - self.screenshot_keep_max]
                for f in to_delete:
                    try:
                        os.remove(f)
                    except Exception:
                        pass
                if len(to_delete) > 0:
                    print(f"   [~] Cleaned up {len(to_delete)} old screenshots")
        except Exception as e:
            print(f"   [!] Cleanup failed: {e}")

    def _capture_double_debug(self, page, label):
        """Capture TWO screenshots: immediate and after 2s delay."""
        p1 = self._capture_debug(page, f"{label}-immediate")
        time.sleep(2)
        p2 = self._capture_debug(page, f"{label}-delayed")
        self._cleanup_screenshots()
        return p1, p2

    def _capture_debug(self, page, label):
        """
        Capture a full-page screenshot for debugging selector failures.
        
        Args:
            page: Playwright page object
            label: Identifier for the screenshot filename
            
        Returns:
            str: Path to saved screenshot, or None on failure
        """
        try:
            os.makedirs(self.dump_dir, exist_ok=True)
            return self._save_screenshot(page, label)
        except Exception as e:
            print(f"   [!] Could not capture debug screenshot: {e}")
            return None
    
    def _rel_path(self, path):
        """
        Convert absolute path to relative for cleaner log output.
        
        Args:
            path: Absolute file path
            
        Returns:
            str: Relative path from current working directory
        """
        try:
            return os.path.relpath(path, os.getcwd())
        except Exception:
            return path

    def _save_screenshot(self, page, label):
        """Capture screenshot to dump_dir with timestamp."""
        try:
            ts = time.strftime("%Y%m%d-%H%M%S")
            path = os.path.join(self.dump_dir, f"debug-{label}-{ts}.png")
            
            try:
                # Try full page first, but fast timeout (5s) to avoid stalling
                page.screenshot(path=path, full_page=True, timeout=5000)
            except Exception:
                # Fallback to viewport only if full page fails/times out
                try:
                    page.screenshot(path=path, full_page=False, timeout=5000)
                except Exception:
                    # Give up silently to avoid clutter
                    return None
                    
            print(f"   [f]  Saved screenshot: {self._rel_path(path)}")
            return path
        except Exception as e:
            # print(f"   [!]  Could not capture screenshot: {e}")
            return None

