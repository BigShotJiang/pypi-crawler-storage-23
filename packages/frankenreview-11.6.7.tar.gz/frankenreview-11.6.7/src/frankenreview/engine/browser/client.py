"""
Frankenreview v11 - Modular Browser Engine
Layer 6: The "Ghost Paste" and "Anti-Detection" logic.

This module handles browser automation to interact with Google AI Studio
using Playwright. It uses file upload for large content and DOM injection
for prompts.

Features:
- Mixin-based architecture for maintainability
- File Upload or Direct Paste (configurable)
- DOM-based text injection (no clipboard dependency)
- Configurable CSS Selectors (update via config.yaml if UI changes)
"""

import os
import sys
import time
import re
import tempfile
import yaml
from pathlib import Path

# Try to import required packages
try:
    from playwright.sync_api import sync_playwright
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False

# Import canonical config loader from utils (avoids circular import with daemon)
from frankenreview.utils.config_loader import load_config

# Import Mixins
from .mixins.debug import DebugMixin
from .mixins.session import SessionMixin
from .mixins.navigation import NavMixin
from .mixins.interaction import InteractMixin
from .mixins.generation import GenMixin
from .mixins.upload import UploadMixin
from .mixins.actions import ActionMixin


class StudioClient(
    DebugMixin,
    SessionMixin,
    NavMixin,
    InteractMixin,
    GenMixin,
    UploadMixin,
    ActionMixin
):
    """
    Client for interacting with Google AI Studio via browser automation.
    Modularized v10.5 Architecture using Mixin composition.
    """
    def __init__(self, debugger_port=9222, config=None, base_url="https://aistudio.google.com", model=None, continue_url=None):
        """
        Initialize the Studio Client.
        
        Args:
            debugger_port: Chrome debugging port to connect to.
            config: Configuration dictionary.
            base_url: Base AI Studio URL.
            model: Model ID to use.
            continue_url: Saved chat URL to continue from (session continuation).
        """
        if not PLAYWRIGHT_AVAILABLE:
            print("[x] Error: Playwright not installed. Run: pip install playwright")
            sys.exit(1)
        
        # Load config
        self.config = config if config else load_config()
        
        # Session continuation URL (v11.5)
        self.continue_url = continue_url
        self.current_chat_url = None  # Will be populated after navigation
        
        # Resolve active model (Priority: Args -> Config URL -> Config Model -> Default)
        config_url = self.config.get("chat_url") or "https://aistudio.google.com/prompts/new_chat"
        url_model = None
        if "model=" in config_url:
            url_model = config_url.split('model=')[-1].split('&')[0]
            
        self.active_model_id = model or url_model or self.config.get("model") or "gemini-flash-latest"
        
        # Construct Base URL (Injecting model param)
        if "model=" in config_url:
            self.base_url = re.sub(r'model=[^&]*', f'model={self.active_model_id}', config_url)
        else:
            sep = "&" if "?" in config_url else "?"
            self.base_url = f"{config_url}{sep}model={self.active_model_id}"
        
        self.use_file_upload = self.config.get('use_file_upload', True)
        self.preserve_clipboard = self.config.get('preserve_clipboard', True)
        self.max_paste_size = self.config.get('max_paste_size', 100000)
        self.verbose_selectors = self.config.get('verbose_selectors', False)
        
        # Resolve dump_dir relative to project_root (centralized .frankenreview/dumps/)
        project_root = self.config.get('project_root', '.')
        dump_dir_rel = self.config.get('dump_dir', '.frankenreview/dumps')
        self.dump_dir = os.path.join(project_root, dump_dir_rel)
        os.makedirs(self.dump_dir, exist_ok=True)
        
        self.screenshot_keep_max = self.config.get('screenshot_keep_max', 20)
        
        # CSS Selectors
        default_selectors = {
            'textarea': "textarea[aria-label='Enter a prompt']",
            'run_button': "button[aria-label='Run'], button:has-text('Run'), button.ms-button-primary:has-text('Run')",
            'stop_button': "button[aria-label*='Stop'], button:has-text('Stop')",
            'response': "ms-chat-turn, ms-markdown-block",
            'thinking_indicator': "ms-chat-turn:last-of-type mat-expansion-panel, mat-expansion-panel-header:has-text('Thoughts')",
            'file_input': "input[type='file']",
            'attach_button': "button[aria-label^='Insert'], button[aria-label='Insert images, videos, audio, or files']",
            'more_options_button': "button[aria-label='Open options']",
            'copy_markdown_button': "button[role='menuitem']:has-text('Copy'), mat-dialog-container button:has-text('Copy')",
            'chat_menu_button': "button[aria-label='View more actions']",
            'delete_prompt_button': "button[aria-label='Delete prompt']",
            'dialog_container': "mat-dialog-container",
            'dialog_confirm_button': "mat-dialog-container button.ms-button-primary",
            'dialog_cancel_button': "mat-dialog-container button.ms-button-borderless",
            'model_name': "ms-model-selector .title, span.title"
        }
        config_selectors = self.config.get('selectors', {})
        self.selectors = {**default_selectors, **config_selectors}
        self.delete_after_review = self.config.get('delete_after_review', True)
        
        self.p = sync_playwright().start()
        debugger_url = f"http://localhost:{debugger_port}"
        
        # Session Persistence (v9.5)
        self.verified_page = None
        
        try:
            self.browser = self.p.chromium.connect_over_cdp(debugger_url)
        except Exception as e:
            self.p.stop() # CLEANUP: Avoid zombie process
            raise Exception(f"Chrome not found on port {debugger_port}. Run frankenreview --start-chrome --port {debugger_port}") from e

        
        self.context = self.browser.contexts[0]
        try:
            self.context.grant_permissions(["clipboard-read", "clipboard-write"])
        except Exception:
            pass  # Might fail on some Chrome versions/contexts but worth a try

        self.mod_key = "Meta" if sys.platform == "darwin" else "Control"
        self.temp_dir = tempfile.mkdtemp(prefix="frankenreview_")
        self.original_clipboard = None
        # self.active_model_id is now initialized earlier


    def send_prompt_in_chat(self, page, prompt_text, attachments=None, max_retries=2):
        """
        Send a prompt in an existing open chat session.
        
        Args:
            page: Active Playwright page (already connected)
            prompt_text: The prompt text to send
            attachments: Optional list of file paths to upload
            max_retries: Number of retries for transient errors
            
        Returns:
            Model's response text or error string
        """
        retry_count = 0
        last_error = None
        
        while retry_count <= max_retries:
            if retry_count > 0:
                print(f"   [i] Retrying prompt (attempt {retry_count + 1}/{max_retries + 1})...")
                time.sleep(2)  # Brief cooldown before retry
            
            retry_count += 1
            
            # 1. Upload attachments if provided (only on first attempt)
            if attachments and retry_count == 1:
                print(f"   [f] Uploading {len(attachments)} files...")
                upload_success = self._try_file_upload(page, attachments)
                if not upload_success:
                    # All files failed to upload (unsupported format)
                    return "Error: All files failed to upload (unsupported format). Use .txt for XML content."
                # Wait extra time for file processing
                time.sleep(2)
            
            # 2. Inject prompt text
            textarea_selectors = self.selectors.get('prompt_input', "textarea").split(',')
            textarea = None
            for sel in textarea_selectors:
                sel = sel.strip()
                if not sel:
                    continue
                try:
                    loc = page.locator(sel)
                    if loc.count() > 0:
                        textarea = loc.first
                        break
                except Exception:
                    pass
            
            if not textarea:
                last_error = "Error: Could not find prompt input field"
                continue
            
            # DOM injection for prompt
            try:
                injection_result = page.evaluate("""
                    (text, selector) => {
                        const textarea = document.querySelector(selector);
                        if (textarea) {
                            textarea.focus();
                            const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
                                window.HTMLTextAreaElement.prototype, 'value'
                            ).set;
                            if (nativeInputValueSetter) {
                                nativeInputValueSetter.call(textarea, text);
                            }
                            textarea.dispatchEvent(new Event('input', { bubbles: true }));
                            textarea.dispatchEvent(new Event('change', { bubbles: true }));
                            return textarea.value === text;
                        }
                        return false;
                    }
                """, [prompt_text, textarea_selectors[0].strip()])
                
                if injection_result:
                    print(f"   [+] Injected prompt ({len(prompt_text):,} chars)")
                else:
                    textarea.fill(prompt_text)
                    print(f"   [+] Injected prompt via fill()")
            except Exception as e:
                try:
                    textarea.fill(prompt_text)
                except Exception:
                    last_error = "Error: Could not enter prompt text"
                    continue
            
            # 3. Pre-run state
            pre_run_count = self._get_model_turn_count(page)
            
            # 4. Click Run button
            run_selectors = self.selectors.get('run_button', "button:has-text('Run')").split(',')
            stop_selector = self.selectors.get('stop_button', "button[aria-label*='Stop']")
            
            # Wait for Run button to be ready
            time.sleep(1)
            
            if not self._click_run_button(page, run_selectors):
                last_error = "Error: Could not click Run button"
                continue
            
            start_confirmed = self._confirm_generation_started(page, run_selectors, stop_selector, timeout=30)
            if not start_confirmed:
                last_error = "Error: Generation did not start"
                continue
            
            print("   [i] Waiting for response...")
            
            # 5. Wait for response
            try:
                result = self._wait_for_response(page, initial_count=pre_run_count, start_confirmed=start_confirmed)
            except Exception as e:
                try:
                    result = self._fallback_scrape(page)
                except Exception:
                    last_error = f"Error: Response wait failed - {e}"
                    continue
            
            # 6. Check for error responses
            if result:
                result_lower = result.lower()
                
                # Check for internal errors (transient, should retry)
                if "internal error" in result_lower or "error has occurred" in result_lower:
                    print(f"   [!] Model returned internal error - will retry")
                    last_error = f"Error: Model internal error ({result[:100]})"
                    # Click somewhere to dismiss the error
                    try:
                        page.keyboard.press("Escape")
                        time.sleep(1)
                    except Exception:
                        pass
                    continue
                
                # Check for rate limit switch signal
                if result == "RATE_LIMIT_SWITCH":
                    print(f"   [!] Rate limit triggered - model was switched")
                    last_error = "Error: Rate limit reached. Try again with different model."
                    continue
                
                # Success - return the result
                return result
            
            last_error = "Error: Empty response received"
        
        # All retries exhausted
        return last_error or "Error: Failed after multiple retries"


    def send_review(self, prompt_text, xml_content=None, attachments=None):
        """
        Send a review prompt to Gemini and get the response.
        
        Behavior depends on config settings:
        - use_file_upload=True: Uploads XML as file attachment (safe for large files)
        - use_file_upload=False: Pastes XML directly as plain text (faster but may crash)
        
        Args:
            prompt_text: The instruction prompt to send
            xml_content: Optional XML content to send (as file or paste based on config)
            
        Returns:
            The model's response text
        """
        # Note: Clipboard preservation removed for security (Direct DOM injection is used instead)
        return self._do_send_review(prompt_text, xml_content, attachments)


    def _do_send_review(self, prompt_text, xml_content=None, attachments=None):
        """Internal method that does the actual review sending"""
        # Always use fresh chat when delete_after_review is enabled,
        # or when new_window_per_review is explicitly set
        use_fresh_chat = self.delete_after_review or self.config.get('new_window_per_review', False)
        silent_mode = self.config.get('silent_mode', True)
        
        # 1. Connect to AI Studio using Safe Connection Logic
        page = self.connect_to_aistudio()
        
        if not page:
            # Safety Lock or Connection Failure
            print("   [x] Aborting review due to connection failure (Safety Lock or No Tab).")
            # For now return "CONNECTION_ERROR" so upstream can handle it
            return "CONNECTION_ERROR"
        
        # RATE LIMIT FAILOVER LOOP
        # If rate limit switch happens, we loop back here to re-inject prompt
        max_retries = 3
        retry_count = 0
        
        while retry_count < max_retries:
            retry_count += 1
            if retry_count > 1:
                print(f"   [i] Retrying review generation (Attempt {retry_count})...")
            
            # ALWAYS navigate to fresh new_chat to clear any cached attachments (unless on retry with correct model)
            # Use active model ID in URL
            session_id = None
            port = self.config.get('port', 9222)
            home_fr = os.path.join(os.path.expanduser("~"), ".frankenreview", f"session_{port}.id")
            
            if os.path.exists(home_fr):
                with open(home_fr, 'r') as f:
                    session_id = f.read().strip()
            # Fallback handled by connect_to_aistudio primarily, but specific URL construction needs checks here too
            # or we rely on connect_to_aistudio to handle initial nav, and here we just handle re-nav?
            # Actually this block re-checks session ID to construct URL.
            elif os.path.exists(os.path.join(os.getcwd(), ".frankenreview", "session.id")):
                 with open(os.path.join(os.getcwd(), ".frankenreview", "session.id"), 'r') as f:
                     session_id = f.read().strip()

            # Use configured base_url (config.yaml) which includes default model param
            # Or use active_model_id if it differs
            
            # Construct base from config
            base_url = self.base_url
            
            # If active_model_id is set (e.g. via model switch), override the param?
            # Current logic: 
            # if self.active_model_id != default -> construct new url
            # But self.base_url ALREADY has model param from config.
            
            # Use base_url from config by default
            chat_url = base_url
            if session_id:
                separator = "&" if "?" in chat_url else "?"
                chat_url += f"{separator}fr_session_id={session_id}"

            # FIX: Always navigate to new_chat with correct model to prevent model mismatch
            # The previous check `chat_url not in page.url` was too weak and missed model param changes
            current_url = page.url
            target_model = None
            current_model = None
            
            # Extract model from target URL
            if 'model=' in chat_url:
                target_model = chat_url.split('model=')[-1].split('&')[0]
            
            # Extract model from current URL
            if 'model=' in current_url:
                current_model = current_url.split('model=')[-1].split('&')[0]
            
            # Navigate if: different model, not on new_chat, or URL mismatch
            # SKIP navigation if we're in continue mode (reusing existing session)
            is_continue_mode = hasattr(self, 'continue_url') and self.continue_url
            
            needs_navigation = (
                not is_continue_mode and (
                    'new_chat' not in current_url or
                    (target_model and target_model != current_model) or
                    chat_url not in current_url
                )
            )
            
            if needs_navigation:
                print(f"   [>] Navigating to fresh chat (Model: {target_model or 'default'})...")
                page.goto(chat_url, wait_until='domcontentloaded')
                time.sleep(2)  # Wait for page to fully load
            
            # Verify Login State
            self._check_login(page)
        
            # 2. Silent mode: Force window minimization via CDP
            if silent_mode:
                try:
                    # establish CDP session
                    session = self.context.new_cdp_session(page)
                    # Get window ID for the current page
                    res = session.send("Browser.getWindowForTarget")
                    if 'windowId' in res:
                        session.send("Browser.setWindowBounds", {
                            "windowId": res['windowId'], 
                            "bounds": {"windowState": "minimized"}
                        })
                except Exception as e:
                    # Not critical, just a UX improvement
                    pass
                    
            # 3. GPU/CPU Kill Switch (Inject CSS to reduce resource usage)
            try:
                page.add_style_tag(content="""
                    * { 
                        animation: none !important; 
                        transition: none !important; 
                    } 
                    canvas { 
                        display: none !important; 
                    }
                """)
            except Exception:
                pass
    
            # 4. Handle XML content based on config
            # 4. Handle Attachments (XML + Extra Files)
            files_to_upload = []
            if attachments:
                 files_to_upload.extend(attachments)
                 
            if xml_content:
                # Save XML context to file
                xml_file = self._save_xml_to_file(xml_content, filename="Frankenreview_Dump.txt")
                files_to_upload.append(xml_file)
    
            if files_to_upload:
                if self.use_file_upload:
                    # File upload mode (default - prevents browser crash)
                    uploaded = self._try_file_upload(page, files_to_upload)
                    if uploaded:
                        # Wait for file to finish loading (wait for 'Loading...' to disappear)
                        print("   [.] Waiting for file to finish loading...")
                        try:
                            # Wait up to 30 seconds for loading to complete
                            page.wait_for_function("""() => {
                                // Check if any element contains 'Loading'
                                const loading = document.body.innerText.includes('Loading...');
                                return !loading;  // Return true when loading is done
                            }""", timeout=30000)
                            print("   [+] File loaded successfully")
                        except Exception:
                            print("   [!] File may still be loading (timeout)")
                        
                        time.sleep(1)  # Small buffer after loading
                        self._capture_debug(page, "after-xml-upload")
                    else:
                        # Fallback to truncated paste
                        print("   [!]  File upload failed, using truncated paste...")
                        xml_content = self._truncate_for_paste(xml_content)
                        prompt_text = prompt_text + "\n\nCODE:\n" + xml_content
                else:
                    # Direct paste mode (toggleable via config)
                    print(f"   [f] Pasting XML directly ({len(xml_content):,} chars)...")
                    if len(xml_content) > self.max_paste_size:
                        print(f"   [!]  Content exceeds {self.max_paste_size:,} chars, truncating...")
                        xml_content = self._truncate_for_paste(xml_content)
                    prompt_text = prompt_text + "\n\nCODE:\n" + xml_content
            
            # Screenshot before copy-paste phase (or injection)
            self._capture_debug(page, "before-prompt-injection")
            
            # 5. Inject text directly into textarea via JavaScript (no clipboard)
            # This is more reliable than clipboard for large text and doesn't interfere with user's clipboard
            
            # Find textarea using selectors from config
            textarea = None
            textarea_selectors = self.selectors.get('textarea', 'textarea').split(', ')
            
            for selector in textarea_selectors:
                sel = selector.strip()
                try:
                    loc = page.locator(sel)
                    if self.verbose_selectors:
                        try:
                            print(f"DEBUG: textarea selector '{sel}' count={loc.count()}")
                        except Exception:
                            print(f"DEBUG: textarea selector '{sel}' (count unavailable)")
                    textarea = loc.first
                    if textarea.is_visible():
                        break
                except Exception:
                    continue
            
            if not textarea:
                print("[!]  Warning: Could not find input textarea")
                return "Error: Could not find input field"
            
            # Direct DOM injection - set value and dispatch input event
            # This bypasses clipboard entirely (more reliable for large text)
            try:
                # Use evaluate to directly set textarea value and trigger React's onChange
                injection_result = page.evaluate("""
                    ([text, selector]) => {
                        const textarea = document.querySelector(selector);
                        if (textarea) {
                            textarea.focus();
                            
                            // 1. Set values
                            textarea.value = text;
                            
                            // 2. Trigger React's synthetic event system
                            const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
                                window.HTMLTextAreaElement.prototype, 'value'
                            ).set;
                            if (nativeInputValueSetter) {
                                nativeInputValueSetter.call(textarea, text);
                            }
                            
                            // 3. Dispatch events to notify React
                            textarea.dispatchEvent(new Event('input', { bubbles: true }));
                            textarea.dispatchEvent(new Event('change', { bubbles: true }));
                            
                            // 4. Verification Check
                            return textarea.value === text;
                        }
                        return false;
                    }
                """, [prompt_text, textarea_selectors[0].strip()])
                
                if injection_result:
                    print(f"   [+] Injected {len(prompt_text):,} chars via DOM (Verified)")
                else:
                    print(f"   [!] DOM injection failed to verify (Value mismatch or selector failed)")
                    # Fallback to fill()
                    textarea.fill(prompt_text)
                    print(f"   [+] Recovered: Injected via fill()")
            except Exception as e:
                print(f"   [!] DOM injection error: {e}, falling back to fill()...")
                try:
                    textarea.fill(prompt_text)
                except Exception:
                    print("   [x] Text injection failed completely (Clipboard fallback removed for security).")
                    return "Error: Could not enter prompt"
    
            # 6. Functional debounce: wait for Run button to become clickable (not arbitrary sleep)
            # instead of fixed 5s delay, poll for button readiness
            run_selector_check = self.selectors.get('run_button', "button:has-text('Run')").split(',')[0].strip()
            debounce_start = time.time()
            max_debounce = 5
            while time.time() - debounce_start < max_debounce:
                try:
                    run_btn = page.locator(run_selector_check).first
                    if run_btn.count() > 0 and not run_btn.get_attribute("disabled"):
                        break
                except Exception:
                    pass
                time.sleep(0.3)
            
            # Count existing responses before running
            pre_run_count = self._get_model_turn_count(page)
            print(f"   [i] Pre-run response count: {pre_run_count}")
    
            # 7. Run - try selectors from config
            # First, press Escape to close any open menus (dropdowns, etc.) that might block the button
            try:
                page.keyboard.press('Escape')
                time.sleep(0.5)
            except Exception:
                pass
    
            run_selectors = self.selectors.get('run_button', "button:has-text('Run')").split(',')
            stop_selector = self.selectors.get('stop_button', "button[aria-label*='Stop']")

            if not self._click_run_button(page, run_selectors):
                print("   [x] Error: Could not find Run button")
                self._capture_debug(page, "failed-run-click")
                return "Error: Could not find Run button"

            start_confirmed = self._confirm_generation_started(page, run_selectors, stop_selector, timeout=30)
            if not start_confirmed:
                print("   [x] Run click confirmation failed (no Stop indicator or disabled Run detected).")
                self._capture_debug(page, "run-no-confirmation")
                return "Error: Run button failed to start generation"

            # Capture debug screenshots (Immediate + Delayed)
            self._capture_double_debug(page, "after-run-click")
            
            # 8. Wait for Result
            try:
                result = self._wait_for_response(page, initial_count=pre_run_count, start_confirmed=start_confirmed)
            except BaseException as e:
                # Safety Net: If interrupted (Ctrl+C), try to scrape whatever is there
                print(f"\n   [!] Process interrupted ({type(e).__name__}). Attempting emergency scrape...")
                try:
                    result = self._fallback_scrape(page)
                    if result:
                        print(f"   [+] Emergency scrape successful ({len(result)} chars).")
                        # Clean up "Error:" prefix if fallback scrape returns it? No, fallback scrape returns string.
                        pass
                except Exception as scrape_err:
                    print(f"   [x] Emergency scrape failed: {scrape_err}")
                    raise e # Re-raise original interrupt if scrape failed
                
                # If scrape succeeded, we return the result (handling the interrupt gracefully)
                if not result:
                    raise e

            
            # Check for Rate Limit Failover Signal
            if result == "RATE_LIMIT_SWITCH":
                 print("   [i] Rate Limit Failover signaled. Restarting review loop...")
                 # cleanup current chat if possible? No, we switched URLs already.
                 continue
            
            # Capture current chat URL for potential session continuation
            self.current_chat_url = page.url
                 
            # 9. Cleanup: Delete the chat after extracting the review
            if self.delete_after_review and result and not result.startswith("Error:"):
                self.delete_current_chat(page)
            
            return result

