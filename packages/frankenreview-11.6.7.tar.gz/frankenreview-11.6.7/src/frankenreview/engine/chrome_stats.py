"""
Frankenreview v11 - Chrome Performance Stats (chrome_stats.py)

Provides performance monitoring for the Chrome debug instance used by Frankenreview.
Shows CPU, memory, and page-level metrics to help identify resource issues.
"""

import os
import sys
import time
import subprocess

# Optional psutil import
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False


def find_chrome_debug_pid() -> int:
    """
    Find the PID of the Chrome process running with remote debugging.
    
    Returns:
        PID of Chrome debug process, or None if not found
    """
    try:
        # Look for Chrome processes with --remote-debugging-port
        result = subprocess.run(
            ["pgrep", "-f", "remote-debugging-port=9222"],
            capture_output=True,
            text=True
        )
        if result.returncode == 0 and result.stdout.strip():
            pids = result.stdout.strip().split("\n")
            # Return first (parent) PID
            return int(pids[0])
    except Exception:
        pass
    
    # Fallback: look for any Chrome processes
    if PSUTIL_AVAILABLE:
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                if 'chrome' in proc.info['name'].lower():
                    cmdline = proc.info.get('cmdline', [])
                    if cmdline and any('remote-debugging-port' in arg for arg in cmdline):
                        return proc.info['pid']
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
    
    return None


def get_process_stats(pid: int) -> dict:
    """
    Get process-level stats for a Chrome PID using psutil.
    
    Args:
        pid: Process ID to monitor
        
    Returns:
        Dict with cpu_percent, memory_rss, memory_vms, threads
    """
    if not PSUTIL_AVAILABLE:
        return {"error": "psutil not installed. Run: pip install psutil"}
    
    try:
        proc = psutil.Process(pid)
        
        # Get CPU usage (need to call twice with interval for accuracy)
        proc.cpu_percent()  # First call returns 0
        time.sleep(0.5)
        cpu = proc.cpu_percent()
        
        # Memory info
        mem = proc.memory_info()
        
        # Get children processes (Chrome uses multiple processes)
        children = proc.children(recursive=True)
        total_rss = mem.rss
        total_cpu = cpu
        
        for child in children:
            try:
                child_mem = child.memory_info()
                total_rss += child_mem.rss
                total_cpu += child.cpu_percent()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        
        return {
            "pid": pid,
            "cpu_percent": round(total_cpu, 1),
            "memory_rss_mb": round(total_rss / (1024 * 1024), 1),
            "memory_vms_mb": round(mem.vms / (1024 * 1024), 1),
            "threads": proc.num_threads(),
            "child_processes": len(children)
        }
    except psutil.NoSuchProcess:
        return {"error": f"Process {pid} not found"}
    except psutil.AccessDenied:
        return {"error": f"Access denied for process {pid}"}
    except Exception as e:
        return {"error": str(e)}


def get_cdp_metrics(debugger_url: str = "http://127.0.0.1:9222") -> dict:
    """
    Get page-level performance metrics via Chrome DevTools Protocol.
    
    Args:
        debugger_url: Chrome remote debugging URL
        
    Returns:
        Dict with JS heap, DOM nodes, durations
    """
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return {"error": "Playwright not installed"}
    
    try:
        p = sync_playwright().start()
        browser = p.chromium.connect_over_cdp(debugger_url)
        context = browser.contexts[0] if browser.contexts else None
        
        if not context or not context.pages:
            p.stop()
            return {"error": "No pages found in Chrome"}
        
        page = context.pages[0]
        
        # Establish CDP session
        session = context.new_cdp_session(page)
        
        # Enable and get performance metrics
        session.send("Performance.enable")
        result = session.send("Performance.getMetrics")
        session.send("Performance.disable")
        
        # Parse metrics
        metrics = {m["name"]: m["value"] for m in result.get("metrics", [])}
        
        p.stop()
        
        return {
            "js_heap_used_mb": round(metrics.get("JSHeapUsedSize", 0) / (1024 * 1024), 2),
            "js_heap_total_mb": round(metrics.get("JSHeapTotalSize", 0) / (1024 * 1024), 2),
            "dom_nodes": int(metrics.get("Nodes", 0)),
            "documents": int(metrics.get("Documents", 0)),
            "frames": int(metrics.get("Frames", 0)),
            "script_duration_s": round(metrics.get("ScriptDuration", 0), 2),
            "task_duration_s": round(metrics.get("TaskDuration", 0), 2),
            "js_event_listeners": int(metrics.get("JSEventListeners", 0))
        }
    except Exception as e:
        return {"error": str(e)}


def get_gpu_status(debugger_url: str = "http://127.0.0.1:9222") -> dict:
    """
    Get basic GPU/hardware acceleration status.
    
    Args:
        debugger_url: Chrome remote debugging URL
        
    Returns:
        Dict with GPU info
    """
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return {"error": "Playwright not installed"}
    
    try:
        p = sync_playwright().start()
        browser = p.chromium.connect_over_cdp(debugger_url)
        context = browser.contexts[0] if browser.contexts else None
        
        if not context or not context.pages:
            p.stop()
            return {"error": "No pages found"}
        
        page = context.pages[0]
        
        # Check WebGL support
        webgl_info = page.evaluate("""() => {
            try {
                const canvas = document.createElement('canvas');
                const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
                if (gl) {
                    const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
                    if (debugInfo) {
                        return {
                            vendor: gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL),
                            renderer: gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL),
                            enabled: true
                        };
                    }
                    return { enabled: true, vendor: 'Unknown', renderer: 'Unknown' };
                }
                return { enabled: false };
            } catch (e) {
                return { enabled: false, error: e.message };
            }
        }""")
        
        p.stop()
        
        return {
            "webgl_enabled": webgl_info.get("enabled", False),
            "gpu_vendor": webgl_info.get("vendor", "Unknown"),
            "gpu_renderer": webgl_info.get("renderer", "Unknown")
        }
    except Exception as e:
        return {"error": str(e)}


def format_chrome_stats() -> str:
    """
    Collect and format all Chrome performance stats.
    
    Returns:
        Formatted string with all metrics
    """
    lines = []
    lines.append("")
    lines.append("╔════════════════════════════════════════════════════════════════╗")
    lines.append("║  FRANKENREVIEW CHROME PERFORMANCE STATS                        ║")
    lines.append("╚════════════════════════════════════════════════════════════════╝")
    lines.append("")
    
    # Find Chrome process
    pid = find_chrome_debug_pid()
    
    if not pid:
        lines.append("[!] Chrome debug instance not found.")
        lines.append("    Run: frankenreview --start-chrome")
        lines.append("")
        return "\n".join(lines)
    
    # Process metrics
    lines.append(f"PROCESS METRICS (Chrome PID: {pid}):")
    lines.append("─" * 66)
    
    proc_stats = get_process_stats(pid)
    if "error" in proc_stats:
        lines.append(f"  Error: {proc_stats['error']}")
    else:
        lines.append(f"  CPU Usage:           {proc_stats['cpu_percent']:>6.1f}%")
        lines.append(f"  Memory (RSS):        {proc_stats['memory_rss_mb']:>6.1f} MB")
        lines.append(f"  Memory (VMS):        {proc_stats['memory_vms_mb']:>6.1f} MB")
        lines.append(f"  Threads:             {proc_stats['threads']:>6}")
        lines.append(f"  Child Processes:     {proc_stats['child_processes']:>6}")
    lines.append("")
    
    # CDP page metrics
    lines.append("PAGE METRICS (via CDP):")
    lines.append("─" * 66)
    
    cdp_stats = get_cdp_metrics()
    if "error" in cdp_stats:
        lines.append(f"  Error: {cdp_stats['error']}")
    else:
        lines.append(f"  JS Heap Used:        {cdp_stats['js_heap_used_mb']:>6.2f} MB")
        lines.append(f"  JS Heap Total:       {cdp_stats['js_heap_total_mb']:>6.2f} MB")
        lines.append(f"  DOM Nodes:           {cdp_stats['dom_nodes']:>6}")
        lines.append(f"  Documents:           {cdp_stats['documents']:>6}")
        lines.append(f"  Frames:              {cdp_stats['frames']:>6}")
        lines.append(f"  Event Listeners:     {cdp_stats['js_event_listeners']:>6}")
        lines.append(f"  Script Duration:     {cdp_stats['script_duration_s']:>6.2f}s")
        lines.append(f"  Task Duration:       {cdp_stats['task_duration_s']:>6.2f}s")
    lines.append("")
    
    # GPU status
    lines.append("GPU STATUS:")
    lines.append("─" * 66)
    
    gpu_stats = get_gpu_status()
    if "error" in gpu_stats:
        lines.append(f"  Error: {gpu_stats['error']}")
    else:
        status = "Enabled" if gpu_stats['webgl_enabled'] else "Disabled"
        lines.append(f"  WebGL:               {status}")
        lines.append(f"  GPU Vendor:          {gpu_stats.get('gpu_vendor', 'Unknown')}")
        lines.append(f"  GPU Renderer:        {gpu_stats.get('gpu_renderer', 'Unknown')[:40]}")
    lines.append("")
    
    lines.append("─" * 66)
    lines.append("TIP: High memory? Close unused tabs. High CPU? Reduce animations.")
    lines.append("─" * 66)
    
    return "\n".join(lines)
