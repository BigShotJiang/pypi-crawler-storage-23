# STANDARD SHORT PROMPT
In exactly one sentence: confirm you received the context and the repo structure looks healthy.
