"""
Frankenreview v11 - Logging Configuration

This module provides a centralized logging configuration for the entire application.
It supports both console output (with colors) and file logging.
"""

import logging
import sys
from pathlib import Path
from typing import Optional


# ANSI color codes for console output
class LogColors:
    """ANSI color codes for colorized console output."""
    RESET = "\033[0m"
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    GRAY = "\033[90m"


class ColoredFormatter(logging.Formatter):
    """Custom formatter that adds colors to log levels."""
    
    LEVEL_COLORS = {
        logging.DEBUG: LogColors.GRAY,
        logging.INFO: LogColors.GREEN,
        logging.WARNING: LogColors.YELLOW,
        logging.ERROR: LogColors.RED,
        logging.CRITICAL: LogColors.MAGENTA,
    }
    
    def format(self, record: logging.LogRecord) -> str:
        """Format the log record with colors."""
        color = self.LEVEL_COLORS.get(record.levelno, LogColors.RESET)
        
        # Text-based prefixes for better visual scanning (no emojis)
        prefix_map = {
            logging.DEBUG: "[d]",
            logging.INFO: "[i]",
            logging.WARNING: "[!]",
            logging.ERROR: "[x]",
            logging.CRITICAL: "[X]",
        }
        prefix = prefix_map.get(record.levelno, "")
        
        # Format the message
        formatted = super().format(record)
        return f"{color}{prefix} {formatted}{LogColors.RESET}"


def setup_logging(
    name: str = "frankenreview",
    level: int = logging.INFO,
    log_file: Optional[Path] = None,
    verbose: bool = False
) -> logging.Logger:
    """
    Configure and return a logger with console and optional file output.
    
    Args:
        name: Logger name
        level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Optional path to log file
        verbose: If True, set level to DEBUG
        
    Returns:
        Configured logger instance
    """
    if verbose:
        level = logging.DEBUG
    
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # Clear any existing handlers
    logger.handlers.clear()
    
    # Console handler with colors
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_formatter = ColoredFormatter(
        "%(message)s",
        datefmt="%H:%M:%S"
    )
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    # File handler (optional)
    if log_file:
        log_file = Path(log_file)
        log_file.parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)  # Always verbose in files
        file_formatter = logging.Formatter(
            "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        file_handler.setFormatter(file_formatter)
        logger.addHandler(file_handler)
    
    return logger


def get_logger(name: str = "frankenreview") -> logging.Logger:
    """
    Get a logger instance. If not configured, returns basic logger.
    
    Args:
        name: Logger name (usually module name)
        
    Returns:
        Logger instance
    """
    return logging.getLogger(name)


# Pre-configured module loggers
def get_daemon_logger() -> logging.Logger:
    """Get logger for daemon module."""
    return get_logger("frankenreview.daemon")


def get_browser_logger() -> logging.Logger:
    """Get logger for engine.browser.client module."""
    return get_logger("frankenreview.browser")


def get_governor_logger() -> logging.Logger:
    """Get logger for governor module."""
    return get_logger("frankenreview.governor")
