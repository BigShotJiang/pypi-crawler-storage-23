"""
Chrome Process Control Module

Cross-platform Chrome process management for Frankenreview.
Handles starting and stopping Chrome instances with remote debugging.
"""

import os
import sys
import time
import subprocess
import platform
import signal
from pathlib import Path
from typing import Optional, Tuple, List


# Status icons
OK = "[+]"
ERR = "[x]"
WARN = "[!]"
INFO = "[i]"


def get_pid_from_file(port: int) -> Tuple[Optional[int], Path]:
    """
    Get Chrome PID from the PID file written by start_chrome.
    
    Args:
        port: The debugging port number.
        
    Returns:
        Tuple of (PID or None, path to PID file).
    """
    home_fr = Path.home() / ".frankenreview"
    pid_file = home_fr / f"chrome_{port}.pid"
    
    if pid_file.exists():
        try:
            pid = int(pid_file.read_text().strip())
            return pid, pid_file
        except (ValueError, IOError):
            pass
    return None, pid_file


def find_chrome_pids_fallback() -> List[int]:
    """
    Fallback method to find Chrome processes running with frankenreview profile.
    
    Returns:
        List of process IDs.
    """
    pids = []
    system = platform.system()
    
    if system == "Windows":
        try:
            output = subprocess.check_output(
                ["wmic", "process", "where", 
                 "CommandLine like '%frankenreview_profile_%'", "get", "ProcessId"],
                stderr=subprocess.DEVNULL
            ).decode()
            for line in output.strip().split("\n")[1:]:
                line = line.strip()
                if line.isdigit():
                    pids.append(int(line))
        except Exception:
            pass
    else:
        try:
            output = subprocess.check_output(
                ["pgrep", "-f", "frankenreview_profile_"],
                stderr=subprocess.DEVNULL
            ).decode()
            pids = [int(p) for p in output.strip().split("\n") if p.strip()]
        except subprocess.CalledProcessError:
            pass
    
    return pids


def kill_process(pid: int, force: bool = False) -> bool:
    """
    Kill a process by PID.
    
    Args:
        pid: Process ID to kill.
        force: Use SIGKILL instead of SIGTERM.
        
    Returns:
        True if kill signal was sent successfully.
    """
    try:
        if platform.system() == "Windows":
            args = ["taskkill", "/PID", str(pid)]
            if force:
                args.insert(1, "/F")
            subprocess.run(args, capture_output=True)
        else:
            os.kill(pid, signal.SIGKILL if force else signal.SIGTERM)
        return True
    except Exception:
        return False


def is_running(pid: int) -> bool:
    """
    Check if a process is still running.
    
    Args:
        pid: Process ID to check.
        
    Returns:
        True if process is running.
    """
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def cleanup_pid_file(pid_file: Path) -> None:
    """
    Remove PID file after Chrome is stopped.
    
    Args:
        pid_file: Path to the PID file.
    """
    try:
        if pid_file.exists():
            pid_file.unlink()
    except Exception:
        pass


def stop_chrome(port: int = 9222) -> None:
    """
    Stop Chrome instances launched by Frankenreview.
    
    Uses PID file for reliable process targeting, with fallback to pgrep.
    
    Args:
        port: The debugging port to target.
    """
    # Try to get PID from PID file (reliable method)
    pid, pid_file = get_pid_from_file(port)
    
    if pid:
        print(f"{INFO} Found Chrome PID {pid} from file for port {port}")
        
        if is_running(pid):
            print(f"   Stopping PID {pid}...")
            kill_process(pid)
            
            # Wait for process to exit
            for _ in range(20):
                if not is_running(pid):
                    break
                time.sleep(0.5)
            else:
                print(f"{WARN} PID {pid} did not stop, force killing...")
                kill_process(pid, force=True)
                time.sleep(1)
            
            cleanup_pid_file(pid_file)
            print(f"{OK} Chrome stopped.")
        else:
            print(f"{INFO} PID {pid} is not running. Cleaning up stale PID file.")
            cleanup_pid_file(pid_file)
        return
    
    # Fallback to pgrep method (legacy/safety)
    print(f"{INFO} No PID file found for port {port}. Using fallback detection...")
    pids = find_chrome_pids_fallback()
    
    if not pids:
        print(f"{INFO} No Chrome process found with frankenreview profile.")
        return
    
    print(f"{INFO} Found Chrome PIDs (fallback): {pids}")
    
    for pid in pids:
        print(f"   Stopping PID {pid}...")
        kill_process(pid)
    
    # Wait for processes to exit
    timeout = 10
    for pid in pids:
        for _ in range(timeout * 2):
            if not is_running(pid):
                break
            time.sleep(0.5)
        else:
            print(f"{WARN} PID {pid} did not stop, force killing...")
            kill_process(pid, force=True)
    
    print(f"{OK} Chrome stopped.")
