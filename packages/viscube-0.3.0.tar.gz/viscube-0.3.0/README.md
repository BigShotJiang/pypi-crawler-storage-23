<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://github.com/mjyb16/viscub/blob/main/Viscube_logo.svg" width="30%" height="30%">
  <source media="(prefers-color-scheme: light)" srcset="https://github.com/mjyb16/viscube/blob/main/Viscube_logo.svg" width="30%" height="30%">
  <img alt="SuperMAGE logo" src="https://github.com/mjyb16/viscube/blob/main/Viscube_logo.svg" width="30%">
</picture>

# viscube
Visibility-space gridder for spectral cubes. Note: under active development.
