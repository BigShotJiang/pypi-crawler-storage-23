from .main import EventResolver

__all__ = ["EventResolver"]