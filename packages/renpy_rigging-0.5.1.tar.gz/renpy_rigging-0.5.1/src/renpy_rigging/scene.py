"""
Scene system for composable environments.

A scene defines an environment with a background, layered overlay items,
placed characters, and placed attachments. Scenes support side-scrolling
(canvas wider than viewport) and layer-based z-ordering so character rigs
can be interleaved between foreground and background elements.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from .math2d import Vec2

FOCUS_LAYER_NAME = "focus"
FOCUS_LAYER_Z = 0


@dataclass
class SceneBackground:
    """Background for a scene -- a color with an optional image on top."""

    color: str = "#000000"                                          # Always stored; shown in margins
    image: Optional[str] = None                                     # Image path relative to scene dir
    image_offset: Vec2 = field(default_factory=lambda: Vec2(0, 0))  # Pixel offset for background image
    image_scale: float = 1.0                                        # Scale factor for background image

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"color": self.color}
        if self.image is not None:
            d["image"] = self.image
        if self.image_offset.x != 0 or self.image_offset.y != 0:
            d["image_offset"] = [self.image_offset.x, self.image_offset.y]
        if self.image_scale != 1.0:
            d["image_scale"] = self.image_scale
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> SceneBackground:
        # Backward compat: old format used type+path
        if "type" in data:
            bg_type = data["type"]
            if bg_type == "image":
                return cls(color="#000000", image=data.get("path", ""))
            else:
                return cls(color=data.get("color", data.get("path", "#000000")))

        # New format
        offset = data.get("image_offset", [0, 0])
        return cls(
            color=data.get("color", "#000000"),
            image=data.get("image"),
            image_offset=Vec2(float(offset[0]), float(offset[1])),
            image_scale=float(data.get("image_scale", 1.0)),
        )


@dataclass
class SceneLayer:
    """A named layer with a z-order value."""

    name: str
    z: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {"z": self.z}

    @classmethod
    def from_dict(cls, name: str, data: Dict[str, Any]) -> SceneLayer:
        return cls(name=name, z=data.get("z", 0))


@dataclass
class SceneLocation:
    """A named spatial anchor point within a scene."""

    name: str
    pos: Vec2 = field(default_factory=lambda: Vec2(0.0, 0.0))
    layer: str = "focus"
    z_offset: int = 0

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"pos": [self.pos.x, self.pos.y]}
        if self.layer != "focus":
            d["layer"] = self.layer
        if self.z_offset != 0:
            d["z_offset"] = self.z_offset
        return d

    @classmethod
    def from_dict(cls, name: str, data: Dict[str, Any]) -> "SceneLocation":
        pos = data.get("pos", [0, 0])
        return cls(
            name=name,
            pos=Vec2(float(pos[0]), float(pos[1])),
            layer=data.get("layer", "focus"),
            z_offset=int(data.get("z_offset", 0)),
        )


DEFAULT_LOCATION_DEFS = [
    ("stage-left",   0.0, 0.5),
    ("stage-center", 0.5, 0.5),
    ("stage-right",  1.0, 0.5),
]


def _make_default_locations(canvas_size: Vec2) -> Dict[str, "SceneLocation"]:
    result: Dict[str, SceneLocation] = {}
    for name, pct_x, pct_y in DEFAULT_LOCATION_DEFS:
        result[name] = SceneLocation(
            name=name,
            pos=Vec2(canvas_size.x * pct_x, canvas_size.y * pct_y),
        )
    return result


@dataclass
class SceneItem:
    """An overlay image placed on a layer within a scene."""

    name: str
    image: str          # path relative to scene folder
    layer: str          # which layer this belongs to
    pos: Vec2 = field(default_factory=lambda: Vec2(0.0, 0.0))
    scale: Vec2 = field(default_factory=lambda: Vec2(1.0, 1.0))
    rotation: float = 0.0
    z_offset: int = 0

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "name": self.name,
            "image": self.image,
            "layer": self.layer,
            "pos": [self.pos.x, self.pos.y],
        }
        if self.scale.x != 1.0 or self.scale.y != 1.0:
            d["scale"] = [self.scale.x, self.scale.y]
        if self.rotation != 0.0:
            d["rotation"] = self.rotation
        if self.z_offset != 0:
            d["z_offset"] = self.z_offset
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> SceneItem:
        pos = data.get("pos", [0, 0])
        scale = data.get("scale", [1.0, 1.0])
        return cls(
            name=data["name"],
            image=data["image"],
            layer=data.get("layer", "background"),
            pos=Vec2(float(pos[0]), float(pos[1])),
            scale=Vec2(float(scale[0]), float(scale[1])),
            rotation=float(data.get("rotation", 0.0)),
            z_offset=int(data.get("z_offset", 0)),
        )


@dataclass
class SceneCharacter:
    """A character rig placed within a scene."""

    name: str           # unique instance ID (e.g., "guard", "guard_2")
    source: str         # folder name under characters/
    layer: str          # which layer this belongs to
    pos: Vec2 = field(default_factory=lambda: Vec2(0.0, 0.0))
    scale: Vec2 = field(default_factory=lambda: Vec2(1.0, 1.0))
    rotation: float = 0.0
    z_offset: int = 0
    pose: str = "neutral"
    animation: Optional[str] = None
    animation_loop: bool = True
    overlays: List[str] = field(default_factory=list)
    rig_attachments: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "name": self.name,
            "source": self.source,
            "layer": self.layer,
            "pos": [self.pos.x, self.pos.y],
        }
        if self.scale.x != 1.0 or self.scale.y != 1.0:
            d["scale"] = [self.scale.x, self.scale.y]
        if self.rotation != 0.0:
            d["rotation"] = self.rotation
        if self.z_offset != 0:
            d["z_offset"] = self.z_offset
        if self.pose != "neutral":
            d["pose"] = self.pose
        if self.animation is not None:
            d["animation"] = self.animation
        if not self.animation_loop:
            d["animation_loop"] = False
        if self.overlays:
            d["overlays"] = list(self.overlays)
        if self.rig_attachments:
            d["rig_attachments"] = list(self.rig_attachments)
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> SceneCharacter:
        pos = data.get("pos", [0, 0])
        scale = data.get("scale", [1.0, 1.0])
        return cls(
            name=data["name"],
            source=data["source"],
            layer=data.get("layer", "foreground"),
            pos=Vec2(float(pos[0]), float(pos[1])),
            scale=Vec2(float(scale[0]), float(scale[1])),
            rotation=float(data.get("rotation", 0.0)),
            z_offset=int(data.get("z_offset", 0)),
            pose=data.get("pose", "neutral"),
            animation=data.get("animation"),
            animation_loop=data.get("animation_loop", True),
            overlays=list(data.get("overlays", [])),
            rig_attachments=list(data.get("rig_attachments", [])),
        )


@dataclass
class SceneAttachment:
    """An attachment rig placed within a scene."""

    name: str           # unique instance ID (e.g., "sword_display")
    source: str         # folder name under attachments/
    layer: str          # which layer this belongs to
    pos: Vec2 = field(default_factory=lambda: Vec2(0.0, 0.0))
    scale: Vec2 = field(default_factory=lambda: Vec2(1.0, 1.0))
    rotation: float = 0.0
    z_offset: int = 0
    pose: str = "neutral"
    animation: Optional[str] = None
    animation_loop: bool = True
    overlays: List[str] = field(default_factory=list)
    rig_attachments: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "name": self.name,
            "source": self.source,
            "layer": self.layer,
            "pos": [self.pos.x, self.pos.y],
        }
        if self.scale.x != 1.0 or self.scale.y != 1.0:
            d["scale"] = [self.scale.x, self.scale.y]
        if self.rotation != 0.0:
            d["rotation"] = self.rotation
        if self.z_offset != 0:
            d["z_offset"] = self.z_offset
        if self.pose != "neutral":
            d["pose"] = self.pose
        if self.animation is not None:
            d["animation"] = self.animation
        if not self.animation_loop:
            d["animation_loop"] = False
        if self.overlays:
            d["overlays"] = list(self.overlays)
        if self.rig_attachments:
            d["rig_attachments"] = list(self.rig_attachments)
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> SceneAttachment:
        pos = data.get("pos", [0, 0])
        scale = data.get("scale", [1.0, 1.0])
        return cls(
            name=data["name"],
            source=data["source"],
            layer=data.get("layer", "foreground"),
            pos=Vec2(float(pos[0]), float(pos[1])),
            scale=Vec2(float(scale[0]), float(scale[1])),
            rotation=float(data.get("rotation", 0.0)),
            z_offset=int(data.get("z_offset", 0)),
            pose=data.get("pose", "neutral"),
            animation=data.get("animation"),
            animation_loop=data.get("animation_loop", True),
            overlays=list(data.get("overlays", [])),
            rig_attachments=list(data.get("rig_attachments", [])),
        )


@dataclass
class SceneActionStep:
    """A single step within a scheduled action track.

    Each step targets an object in the scene and performs an action on it.
    Steps within a track execute sequentially.

    Action types and their params:
        play_animation:  {"animation": str, "loop": bool}
        set_pose:        {"pose": str}
        add:             {"type": "character"|"attachment"|"item", "source": str, "layer": str, "pos": [x,y], "scale": [x,y]}
        remove:          {}
        set_visible:     {"visible": bool}
        set_background:  {"image": str, "transition_ms": int}
        play_sound:      {"path": str, "channel": str}
        set_overlay:     {"overlay": str, "active": bool}
        flip:            {"flip_h": bool}

    Film Studio action types (dispatched by ClipCueStepper):
        move_to:         {"pos": [x,y], "duration_ms": int, "ease": str}
        scale_to:        {"scale": [x,y], "duration_ms": int, "ease": str}
        rotate_to:       {"rotation": float, "duration_ms": int, "ease": str}
        camera_to:       {"rect": [x,y,w,h], "duration_ms": int, "ease": str}
        stop_animation:  {}
        show_title:      {"text": str, "duration_ms": int, "fade_ms": int, "bg": str, "color": str, "size": int}
        show_credits:    {"lines": [str], "duration_ms": int, "scroll_speed": int}
        fade:            {"color": str, "duration_ms": int, "direction": "in"|"out"}
        set_scene:       {"scene": str, "transition_ms": int}
        hold:            {"duration_ms": int}
    """

    target: str                                       # Instance name or "$scene" for scene-level
    action: str                                       # Action type
    params: Dict[str, Any] = field(default_factory=dict)
    ms: int = 0                                       # Hold duration before next step (0 = immediate)
    wait: bool = False                                # Wait for triggered animation to complete

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "target": self.target,
            "action": self.action,
        }
        if self.params:
            d["params"] = dict(self.params)
        if self.ms != 0:
            d["ms"] = self.ms
        if self.wait:
            d["wait"] = True
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> SceneActionStep:
        return cls(
            target=data["target"],
            action=data["action"],
            params=dict(data.get("params", {})),
            ms=int(data.get("ms", 0)),
            wait=bool(data.get("wait", False)),
        )


@dataclass
class SceneActionTrack:
    """A single track within a scheduled action. Steps execute sequentially.

    Multiple tracks within an action run in parallel.
    """

    name: str = "Track 1"
    steps: List[SceneActionStep] = field(default_factory=list)

    @property
    def total_duration_ms(self) -> int:
        """Total declared duration (sum of step ms values).

        Does not account for wait-for-completion time, which is dynamic.
        """
        return sum(s.ms for s in self.steps)

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"name": self.name}
        if self.steps:
            d["steps"] = [s.to_dict() for s in self.steps]
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> SceneActionTrack:
        steps = [SceneActionStep.from_dict(s) for s in data.get("steps", [])]
        return cls(name=data.get("name", "Track 1"), steps=steps)


@dataclass
class SceneAction:
    """A named scheduled action containing parallel tracks.

    Scheduled actions orchestrate timed events across scene objects:
    playing animations, adding/removing objects, swapping backgrounds,
    and triggering sounds.
    """

    name: str
    tracks: List[SceneActionTrack] = field(default_factory=list)

    @property
    def total_duration_ms(self) -> int:
        """Max duration across all tracks (declared durations only)."""
        return max((t.total_duration_ms for t in self.tracks), default=0)

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {}
        if self.tracks:
            d["tracks"] = [t.to_dict() for t in self.tracks]
        return d

    @classmethod
    def from_dict(cls, name: str, data: Dict[str, Any]) -> SceneAction:
        tracks = [SceneActionTrack.from_dict(t) for t in data.get("tracks", [])]
        return cls(name=name, tracks=tracks)


class _StepDoneCallback:
    """Picklable callback that clears a track's waiting state in an ActionStepper."""
    def __init__(self, stepper, track_idx):
        self._stepper = stepper
        self._track_idx = track_idx

    def __call__(self):
        self._stepper._track_states[self._track_idx]["waiting"] = False


class ActionStepper:
    """Base class for stepping through a SceneAction's parallel tracks.

    Manages track advancement, hold timers, and wait-for-animation blocking.
    Subclasses implement ``_execute_step()`` to perform the actual side effects
    (e.g. Ren'Py displayable updates, PIL state changes, etc.).

    All tracks start simultaneously. Within each track, steps execute
    sequentially. Steps can wait for animations to complete and/or hold
    for a fixed duration before advancing.
    """

    def __init__(self, action):
        """
        Args:
            action: The SceneAction to play.
        """
        self._action = action
        self._track_states = []  # Per-track: {"step_idx": int, "waiting": bool, "hold_until": float}
        self._playing = False
        self._start_time = None
        self._on_complete = None

    def start(self, on_complete=None):
        """Begin playback of all tracks in parallel."""
        self._on_complete = on_complete
        self._playing = True
        self._start_time = None  # Set on first tick
        self._track_states = []
        for track in self._action.tracks:
            state = {"step_idx": -1, "waiting": False, "hold_until": 0.0}
            self._track_states.append(state)

    def tick(self, st):
        """Advance all tracks. Called each frame with elapsed time.

        Args:
            st: Current time in seconds.
        """
        if not self._playing:
            return

        if self._start_time is None:
            self._start_time = st

        all_done = True

        for i, track in enumerate(self._action.tracks):
            ts = self._track_states[i]

            if ts["step_idx"] >= len(track.steps):
                # Track finished
                continue

            all_done = False

            # Waiting for animation completion
            if ts["waiting"]:
                continue

            # Holding for duration
            if ts["hold_until"] > 0 and st < ts["hold_until"]:
                continue

            # Advance to next step
            ts["step_idx"] += 1
            ts["hold_until"] = 0.0

            if ts["step_idx"] >= len(track.steps):
                # Track just finished
                continue

            step = track.steps[ts["step_idx"]]
            self._dispatch_step(step, i, st)

        if all_done:
            self._playing = False
            if self._on_complete:
                cb = self._on_complete
                self._on_complete = None
                cb()

    # Actions that support wait=True (async operations that call on_done)
    _WAITABLE_ACTIONS = frozenset({
        "play_animation",
        "play_action",
    })

    # Actions that wait by holding for a duration (duration from params.duration_ms)
    _TIMED_ACTIONS = frozenset({
        "move_to",
        "scale_to",
        "rotate_to",
        "camera_to",
        "show_title",
        "show_credits",
        "fade",
        "hold",
    })

    def _dispatch_step(self, step, track_idx, st):
        """Execute a single step and configure wait/hold state."""
        ts = self._track_states[track_idx]

        self._execute_step(step, _StepDoneCallback(self, track_idx))

        # Set hold duration from step.ms (legacy) or params.duration_ms (new)
        if step.ms > 0:
            ts["hold_until"] = st + step.ms / 1000.0
        elif step.action in self._TIMED_ACTIONS and step.wait:
            duration_ms = step.params.get("duration_ms", 0)
            if duration_ms > 0:
                ts["hold_until"] = st + duration_ms / 1000.0

        # Set waiting for async actions that call on_done
        if step.wait and step.action in self._WAITABLE_ACTIONS:
            ts["waiting"] = True

    def _execute_step(self, step, on_done):
        """Override in subclass to handle step side effects.

        Args:
            step: SceneActionStep to execute.
            on_done: Callback to invoke when an async operation (e.g. animation)
                     completes. Must be called if step.wait is True, or the
                     track will block forever.
        """
        raise NotImplementedError

    @property
    def is_playing(self):
        return self._playing

    @property
    def is_complete(self):
        return not self._playing and self._start_time is not None


@dataclass
class Scene:
    """
    A composable environment with a background and layered overlay items.

    Scenes define environments that character rigs can be placed in.
    Layers allow z-ordering so characters can appear between foreground
    and background elements.
    """

    name: str
    canvas_size: Vec2
    background: SceneBackground
    layers: Dict[str, SceneLayer] = field(default_factory=dict)
    items: List[SceneItem] = field(default_factory=list)
    characters: List[SceneCharacter] = field(default_factory=list)
    attachments: List[SceneAttachment] = field(default_factory=list)
    base_path: str = ""  # directory containing scene.json
    sound: Optional[str] = None  # Relative path to ambient sound file
    sound_loop: bool = True  # Whether to loop the ambient sound
    camera: Optional[Tuple[float, float, float, float]] = None  # (x, y, w, h) or None = full canvas
    actions: Dict[str, SceneAction] = field(default_factory=dict)  # name -> SceneAction
    locations: Dict[str, SceneLocation] = field(default_factory=dict)  # name -> SceneLocation

    def get_location(self, name: str) -> Optional[SceneLocation]:
        return self.locations.get(name)

    def get_layer(self, name: str) -> Optional[SceneLayer]:
        return self.layers.get(name)

    def get_items_for_layer(self, layer_name: str) -> List[SceneItem]:
        return [item for item in self.items if item.layer == layer_name]

    def get_characters_for_layer(self, layer_name: str) -> List[SceneCharacter]:
        return [ch for ch in self.characters if ch.layer == layer_name]

    def get_attachments_for_layer(self, layer_name: str) -> List[SceneAttachment]:
        return [att for att in self.attachments if att.layer == layer_name]

    def get_sorted_items(self, layer_name: Optional[str] = None) -> List[Tuple[int, SceneItem]]:
        """Get items sorted by effective z-order (layer.z + item.z_offset).

        Args:
            layer_name: If provided, only items from this layer. Otherwise all items.

        Returns:
            List of (effective_z, item) tuples sorted by effective_z.
        """
        result = []
        for item in self.items:
            if layer_name is not None and item.layer != layer_name:
                continue
            layer = self.layers.get(item.layer)
            layer_z = layer.z if layer else 0
            effective_z = layer_z + item.z_offset
            result.append((effective_z, item))
        result.sort(key=lambda x: x[0])
        return result

    def get_sorted_characters(self, layer_name: Optional[str] = None) -> List[Tuple[int, SceneCharacter]]:
        """Get characters sorted by effective z-order (layer.z + character.z_offset)."""
        result = []
        for ch in self.characters:
            if layer_name is not None and ch.layer != layer_name:
                continue
            layer = self.layers.get(ch.layer)
            layer_z = layer.z if layer else 0
            effective_z = layer_z + ch.z_offset
            result.append((effective_z, ch))
        result.sort(key=lambda x: x[0])
        return result

    def get_camera_rect(self) -> Tuple[float, float, float, float]:
        """Return the camera rect (x, y, w, h), falling back to full canvas."""
        if self.camera is not None:
            return self.camera
        return (0.0, 0.0, self.canvas_size.x, self.canvas_size.y)

    def get_camera_size(self) -> Tuple[float, float]:
        """Return the camera viewport size (w, h)."""
        _, _, w, h = self.get_camera_rect()
        return (w, h)

    def get_all_sorted_entries(self, layer_name: Optional[str] = None) -> List[Tuple[int, str, Any]]:
        """Get all entries (items, characters, attachments) sorted by effective z-order.

        Args:
            layer_name: If provided, only entries from this layer. Otherwise all entries.

        Returns:
            List of (effective_z, type_str, entry) tuples sorted by effective_z.
            type_str is one of "item", "character", "attachment".
        """
        entries: List[Tuple[int, str, Any]] = []
        for eff_z, item in self.get_sorted_items(layer_name):
            entries.append((eff_z, "item", item))
        for eff_z, ch in self.get_sorted_characters(layer_name):
            entries.append((eff_z, "character", ch))
        for eff_z, att in self.get_sorted_attachments(layer_name):
            entries.append((eff_z, "attachment", att))
        entries.sort(key=lambda x: x[0])
        return entries

    def resolve_image_path(self, relative_path: str) -> str:
        """Resolve a relative image path against this scene's base_path.

        Args:
            relative_path: Image path relative to the scene directory.

        Returns:
            Full path with forward slashes. If base_path is empty, returns
            the relative path unchanged.
        """
        if not self.base_path:
            return relative_path
        return os.path.join(self.base_path, relative_path).replace("\\", "/")

    def get_sorted_attachments(self, layer_name: Optional[str] = None) -> List[Tuple[int, SceneAttachment]]:
        """Get attachments sorted by effective z-order (layer.z + attachment.z_offset)."""
        result = []
        for att in self.attachments:
            if layer_name is not None and att.layer != layer_name:
                continue
            layer = self.layers.get(att.layer)
            layer_z = layer.z if layer else 0
            effective_z = layer_z + att.z_offset
            result.append((effective_z, att))
        result.sort(key=lambda x: x[0])
        return result

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "canvas": [self.canvas_size.x, self.canvas_size.y],
            "background": self.background.to_dict(),
            "layers": {
                name: layer.to_dict()
                for name, layer in self.layers.items()
            },
            "items": [item.to_dict() for item in self.items],
        }
        if self.characters:
            d["characters"] = [ch.to_dict() for ch in self.characters]
        if self.attachments:
            d["attachments"] = [att.to_dict() for att in self.attachments]
        if self.sound is not None:
            d["sound"] = self.sound
        if not self.sound_loop:
            d["sound_loop"] = False
        if self.camera is not None:
            cx, cy, cw, ch = self.camera
            if not (cx == 0 and cy == 0 and cw == self.canvas_size.x and ch == self.canvas_size.y):
                d["camera"] = [cx, cy, cw, ch]
        if self.locations:
            d["locations"] = {
                name: loc.to_dict()
                for name, loc in self.locations.items()
            }
        if self.actions:
            d["actions"] = {
                name: action.to_dict()
                for name, action in self.actions.items()
            }
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any], name: str = "", base_path: str = "") -> Scene:
        canvas = data.get("canvas", [1920, 1080])
        canvas_size = Vec2(float(canvas[0]), float(canvas[1]))

        bg_data = data.get("background", {"type": "color", "color": "#000000"})
        background = SceneBackground.from_dict(bg_data)

        layers: Dict[str, SceneLayer] = {}
        for layer_name, layer_data in data.get("layers", {}).items():
            layers[layer_name] = SceneLayer.from_dict(layer_name, layer_data)

        # Ensure a focus layer always exists for runtime character placement
        if FOCUS_LAYER_NAME not in layers:
            layers[FOCUS_LAYER_NAME] = SceneLayer(name=FOCUS_LAYER_NAME, z=FOCUS_LAYER_Z)

        items: List[SceneItem] = []
        for item_data in data.get("items", []):
            items.append(SceneItem.from_dict(item_data))

        characters: List[SceneCharacter] = []
        for ch_data in data.get("characters", []):
            characters.append(SceneCharacter.from_dict(ch_data))

        attachments: List[SceneAttachment] = []
        for att_data in data.get("attachments", []):
            attachments.append(SceneAttachment.from_dict(att_data))

        locations: Dict[str, SceneLocation] = {}
        loc_data = data.get("locations", {})
        if loc_data:
            for loc_name, loc_val in loc_data.items():
                locations[loc_name] = SceneLocation.from_dict(loc_name, loc_val)
        else:
            locations = _make_default_locations(canvas_size)

        actions: Dict[str, SceneAction] = {}
        for action_name, action_data in data.get("actions", {}).items():
            actions[action_name] = SceneAction.from_dict(action_name, action_data)

        camera = None
        if "camera" in data:
            cam = data["camera"]
            if isinstance(cam, list) and len(cam) == 4:
                camera = (float(cam[0]), float(cam[1]), float(cam[2]), float(cam[3]))

        return cls(
            name=name,
            canvas_size=canvas_size,
            background=background,
            layers=layers,
            items=items,
            characters=characters,
            attachments=attachments,
            base_path=base_path,
            sound=data.get("sound"),
            sound_loop=data.get("sound_loop", True),
            camera=camera,
            actions=actions,
            locations=locations,
        )
