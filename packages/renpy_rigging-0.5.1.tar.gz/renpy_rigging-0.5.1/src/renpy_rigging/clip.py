"""
Clip system for composing multi-character animated sequences.

A clip is a directed sequence of cues that orchestrate multiple characters,
camera moves, title cards, and sound across time. Clips build on the Scene
and Animation systems to create full animation sequences that can be played
in real-time, edited in the Film Studio UI, or exported to video.

Sequencing model:
    - Cues execute sequentially (each starts after the previous completes)
    - Within each cue, tracks execute in parallel
    - Within each track, steps execute sequentially
    - A cue completes when all its tracks are done (or min_duration_ms elapses)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

from .math2d import Vec2, clamp, ease_in, ease_in_out, ease_out, lerp
from .scene import ActionStepper, SceneAction, SceneActionStep, SceneActionTrack


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class ClipCastEntry:
    """A character or attachment placed in a clip with initial state.

    Cast entries override the scene's default character placement. They specify
    where each actor starts and what they look like at the beginning of the clip.
    """

    name: str               # unique instance ID used in cue targets
    source: str             # folder name under characters/ or attachments/
    kind: str = "character"  # "character" or "attachment"
    layer: str = "background"
    pos: Vec2 = field(default_factory=lambda: Vec2(0.0, 0.0))
    scale: Vec2 = field(default_factory=lambda: Vec2(1.0, 1.0))
    rotation: float = 0.0
    z_offset: int = 0
    visible: bool = True
    pose: str = "neutral"
    animation: Optional[str] = None
    animation_loop: bool = True
    overlays: List[str] = field(default_factory=list)
    attachments: List[str] = field(default_factory=list)
    flip_h: bool = False

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "source": self.source,
        }
        if self.kind != "character":
            d["kind"] = self.kind
        if self.layer != "background":
            d["layer"] = self.layer
        d["pos"] = [self.pos.x, self.pos.y]
        if self.scale.x != 1.0 or self.scale.y != 1.0:
            d["scale"] = [self.scale.x, self.scale.y]
        if self.rotation != 0.0:
            d["rotation"] = self.rotation
        if self.z_offset != 0:
            d["z_offset"] = self.z_offset
        if not self.visible:
            d["visible"] = False
        if self.pose != "neutral":
            d["pose"] = self.pose
        if self.animation is not None:
            d["animation"] = self.animation
        if not self.animation_loop:
            d["animation_loop"] = False
        if self.overlays:
            d["overlays"] = list(self.overlays)
        if self.attachments:
            d["attachments"] = list(self.attachments)
        if self.flip_h:
            d["flip_h"] = True
        return d

    @classmethod
    def from_dict(cls, name: str, data: Dict[str, Any]) -> ClipCastEntry:
        pos = data.get("pos", [0, 0])
        scale = data.get("scale", [1.0, 1.0])
        return cls(
            name=name,
            source=data["source"],
            kind=data.get("kind", "character"),
            layer=data.get("layer", "background"),
            pos=Vec2(float(pos[0]), float(pos[1])),
            scale=Vec2(float(scale[0]), float(scale[1])),
            rotation=float(data.get("rotation", 0.0)),
            z_offset=int(data.get("z_offset", 0)),
            visible=data.get("visible", True),
            pose=data.get("pose", "neutral"),
            animation=data.get("animation"),
            animation_loop=data.get("animation_loop", True),
            overlays=list(data.get("overlays", [])),
            attachments=list(data.get("attachments", [])),
            flip_h=data.get("flip_h", False),
        )


@dataclass
class ClipSoundtrack:
    """A soundtrack entry that plays during the clip."""

    path: str                        # path relative to project
    start_ms: int = 0                # when to start playing (ms from clip start)
    loop: bool = True
    volume: float = 1.0
    fade_in_ms: int = 0
    fade_out_ms: int = 0

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"path": self.path}
        if self.start_ms != 0:
            d["start_ms"] = self.start_ms
        if not self.loop:
            d["loop"] = False
        if self.volume != 1.0:
            d["volume"] = self.volume
        if self.fade_in_ms != 0:
            d["fade_in_ms"] = self.fade_in_ms
        if self.fade_out_ms != 0:
            d["fade_out_ms"] = self.fade_out_ms
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> ClipSoundtrack:
        return cls(
            path=data["path"],
            start_ms=int(data.get("start_ms", 0)),
            loop=data.get("loop", True),
            volume=float(data.get("volume", 1.0)),
            fade_in_ms=int(data.get("fade_in_ms", 0)),
            fade_out_ms=int(data.get("fade_out_ms", 0)),
        )


@dataclass
class ClipStep:
    """A single step within a clip cue track.

    Extends SceneActionStep with Film Studio action types:
        move_to:        {"pos": [x,y], "duration_ms": int, "ease": str}
        scale_to:       {"scale": [x,y], "duration_ms": int, "ease": str}
        rotate_to:      {"rotation": float, "duration_ms": int, "ease": str}
        camera_to:      {"rect": [x,y,w,h], "duration_ms": int, "ease": str}
        stop_animation: {}
        show_title:     {"text": str, "duration_ms": int, "fade_ms": int, "bg": str, "color": str, "size": int}
        show_credits:   {"lines": [str], "duration_ms": int, "scroll_speed": int}
        fade:           {"color": str, "duration_ms": int, "direction": "in"|"out"}
        set_scene:      {"scene": str, "transition_ms": int}
        hold:           {"duration_ms": int}

    Plus all existing SceneActionStep types:
        play_animation, set_pose, set_visible, set_overlay, set_attachment,
        play_sound, play_action, add, remove, set_background, flip
    """

    action: str
    target: Optional[str] = None      # cast member name, "@scene", "@camera", or None
    params: Dict[str, Any] = field(default_factory=dict)
    wait: bool = False                # wait for async action to complete before next step

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"action": self.action}
        if self.target is not None:
            d["target"] = self.target
        if self.params:
            d["params"] = dict(self.params)
        if self.wait:
            d["wait"] = True
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> ClipStep:
        return cls(
            action=data["action"],
            target=data.get("target"),
            params=dict(data.get("params", {})),
            wait=bool(data.get("wait", False)),
        )

    def to_scene_step(self) -> SceneActionStep:
        """Convert to a SceneActionStep for ActionStepper compatibility.

        For tween actions (move_to, scale_to, etc.), the ms field is set to
        duration_ms so the ActionStepper hold timer handles the wait.
        """
        ms = 0
        if self.action == "hold":
            ms = self.params.get("duration_ms", 0)
        elif self.action in ("move_to", "scale_to", "rotate_to", "camera_to"):
            if self.wait:
                ms = self.params.get("duration_ms", 0)
        elif self.action in ("show_title", "show_credits"):
            if self.wait:
                ms = self.params.get("duration_ms", 0)
        elif self.action == "fade":
            if self.wait:
                ms = self.params.get("duration_ms", 0)

        return SceneActionStep(
            target=self.target or "",
            action=self.action,
            params=dict(self.params),
            ms=ms,
            wait=self.wait and self.action == "play_animation",
        )


@dataclass
class ClipTrack:
    """A track within a clip cue. Steps execute sequentially."""

    name: str = "Track 1"
    steps: List[ClipStep] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"name": self.name}
        if self.steps:
            d["steps"] = [s.to_dict() for s in self.steps]
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> ClipTrack:
        steps = [ClipStep.from_dict(s) for s in data.get("steps", [])]
        return cls(name=data.get("name", "Track 1"), steps=steps)

    def to_scene_track(self) -> SceneActionTrack:
        """Convert to a SceneActionTrack for ActionStepper compatibility."""
        scene_steps = [s.to_scene_step() for s in self.steps]
        return SceneActionTrack(name=self.name, steps=scene_steps)


@dataclass
class ClipCue:
    """A named beat in the clip's sequence.

    Each cue contains parallel tracks that execute simultaneously.
    The cue completes when all tracks finish AND min_duration_ms has elapsed.
    """

    id: str
    name: str = ""
    min_duration_ms: int = 0
    tracks: List[ClipTrack] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"id": self.id}
        if self.name:
            d["name"] = self.name
        if self.min_duration_ms > 0:
            d["min_duration_ms"] = self.min_duration_ms
        if self.tracks:
            d["tracks"] = [t.to_dict() for t in self.tracks]
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> ClipCue:
        tracks = [ClipTrack.from_dict(t) for t in data.get("tracks", [])]
        return cls(
            id=data["id"],
            name=data.get("name", ""),
            min_duration_ms=int(data.get("min_duration_ms", 0)),
            tracks=tracks,
        )

    def to_scene_action(self) -> SceneAction:
        """Convert to a SceneAction for ActionStepper compatibility."""
        scene_tracks = [t.to_scene_track() for t in self.tracks]
        return SceneAction(name=self.id, tracks=scene_tracks)


@dataclass
class Clip:
    """A composed animation sequence with multiple characters, camera, and sound.

    A clip orchestrates scenes, characters, camera moves, title cards, and sound
    through a sequence of named cues. Each cue contains parallel tracks that
    direct different actors and scene elements simultaneously.
    """

    name: str
    canvas: Vec2 = field(default_factory=lambda: Vec2(1920, 1080))
    fps: int = 24
    scene: str = ""                  # scene name to load as backdrop
    cast: Dict[str, ClipCastEntry] = field(default_factory=dict)
    camera: Tuple[float, float, float, float] = (0, 0, 1920, 1080)
    soundtrack: List[ClipSoundtrack] = field(default_factory=list)
    cues: List[ClipCue] = field(default_factory=list)
    base_path: str = ""              # directory containing clip.json

    def get_cue(self, cue_id: str) -> Optional[ClipCue]:
        """Find a cue by its ID."""
        for cue in self.cues:
            if cue.id == cue_id:
                return cue
        return None

    def get_cue_index(self, cue_id: str) -> int:
        """Find a cue's index by its ID. Returns -1 if not found."""
        for i, cue in enumerate(self.cues):
            if cue.id == cue_id:
                return i
        return -1

    def estimate_duration_ms(self) -> int:
        """Estimate total clip duration in milliseconds.

        For each cue, takes max(min_duration_ms, max track duration).
        Track duration is the sum of step durations for steps that contribute
        time (tween/hold/fade/title/credits with wait=True, or hold steps).

        This is an estimate since animation waits depend on runtime animation
        lengths which aren't known statically.
        """
        total = 0
        for cue in self.cues:
            max_track_ms = 0
            for track in cue.tracks:
                track_ms = 0
                for step in track.steps:
                    if step.action == "hold":
                        track_ms += step.params.get("duration_ms", 0)
                    elif step.action in ("move_to", "scale_to", "rotate_to", "camera_to"):
                        if step.wait:
                            track_ms += step.params.get("duration_ms", 0)
                    elif step.action in ("show_title", "show_credits", "fade"):
                        if step.wait:
                            track_ms += step.params.get("duration_ms", 0)
                    elif step.action == "play_animation" and step.wait:
                        # Rough estimate — we don't know animation length
                        track_ms += step.params.get("duration_ms", 1000)
                max_track_ms = max(max_track_ms, track_ms)
            total += max(cue.min_duration_ms, max_track_ms)
        return total

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"name": self.name}
        d["canvas"] = [self.canvas.x, self.canvas.y]
        if self.fps != 24:
            d["fps"] = self.fps
        if self.scene:
            d["scene"] = self.scene
        if self.cast:
            d["cast"] = {
                name: entry.to_dict()
                for name, entry in self.cast.items()
            }
        cx, cy, cw, ch = self.camera
        if not (cx == 0 and cy == 0 and cw == self.canvas.x and ch == self.canvas.y):
            d["camera"] = [cx, cy, cw, ch]
        if self.soundtrack:
            d["soundtrack"] = [s.to_dict() for s in self.soundtrack]
        if self.cues:
            d["cues"] = [c.to_dict() for c in self.cues]
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any], base_path: str = "") -> Clip:
        canvas_raw = data.get("canvas", [1920, 1080])
        canvas = Vec2(float(canvas_raw[0]), float(canvas_raw[1]))

        cast: Dict[str, ClipCastEntry] = {}
        for cast_name, cast_data in data.get("cast", {}).items():
            cast[cast_name] = ClipCastEntry.from_dict(cast_name, cast_data)

        cam = data.get("camera", [0, 0, canvas.x, canvas.y])
        camera = (float(cam[0]), float(cam[1]), float(cam[2]), float(cam[3]))

        soundtrack = [ClipSoundtrack.from_dict(s) for s in data.get("soundtrack", [])]
        cues = [ClipCue.from_dict(c) for c in data.get("cues", [])]

        return cls(
            name=data.get("name", "untitled"),
            canvas=canvas,
            fps=int(data.get("fps", 24)),
            scene=data.get("scene", ""),
            cast=cast,
            camera=camera,
            soundtrack=soundtrack,
            cues=cues,
            base_path=base_path,
        )


# ---------------------------------------------------------------------------
# Tween system — smooth interpolation for move_to, scale_to, etc.
# ---------------------------------------------------------------------------


class TweenEase(Enum):
    """Easing modes for tweens, matching EaseType from animation.py."""
    LINEAR = "linear"
    EASE_IN = "ease_in"
    EASE_OUT = "ease_out"
    EASE_IN_OUT = "ease_in_out"


def _apply_ease(t: float, ease: TweenEase) -> float:
    """Apply an easing function to a normalized time value."""
    if ease == TweenEase.EASE_IN:
        return ease_in(t)
    elif ease == TweenEase.EASE_OUT:
        return ease_out(t)
    elif ease == TweenEase.EASE_IN_OUT:
        return ease_in_out(t)
    return t  # LINEAR


def _parse_ease(s: Optional[str]) -> TweenEase:
    """Parse an ease string from JSON into a TweenEase."""
    if s is None:
        return TweenEase.LINEAR
    try:
        return TweenEase(s)
    except ValueError:
        return TweenEase.LINEAR


@dataclass
class Tween:
    """A single property animation over time.

    Tweens interpolate a property from start_value to end_value over
    duration_ms, applying an easing function.
    """

    target: str              # cast member name, "@camera", or "@title"
    prop: str                # "pos", "scale", "rotation", "camera_rect", "alpha"
    start_value: Any         # Vec2, float, or (x,y,w,h) tuple
    end_value: Any
    duration_ms: int
    ease: TweenEase = TweenEase.LINEAR
    start_time: float = 0.0  # st (seconds) when tween began
    on_complete: Optional[Callable] = None
    _completed: bool = False

    @property
    def is_complete(self) -> bool:
        return self._completed

    def evaluate(self, st: float) -> Any:
        """Compute the current value at time st.

        Returns the interpolated value and marks complete if finished.
        """
        elapsed_ms = (st - self.start_time) * 1000.0
        t = clamp(elapsed_ms / max(self.duration_ms, 1), 0.0, 1.0)
        eased_t = _apply_ease(t, self.ease)

        if isinstance(self.start_value, Vec2):
            value = self.start_value.lerp(self.end_value, eased_t)
        elif isinstance(self.start_value, tuple):
            # Lerp each component (for camera rects)
            value = tuple(
                lerp(a, b, eased_t)
                for a, b in zip(self.start_value, self.end_value)
            )
        else:
            # Scalar
            value = lerp(self.start_value, self.end_value, eased_t)

        if t >= 1.0 and not self._completed:
            self._completed = True
            if self.on_complete:
                self.on_complete()

        return value


class TweenManager:
    """Manages active tweens, evaluating them each frame.

    Each tick, all active tweens are advanced and their current values
    are reported via the apply_callback. Completed tweens are removed.
    """

    def __init__(self, apply_callback: Optional[Callable] = None):
        """
        Args:
            apply_callback: Called as apply_callback(target, prop, value) for
                           each tween's current value every tick. If None,
                           values must be retrieved via get_value().
        """
        self._active: List[Tween] = []
        self._apply_callback = apply_callback

    def add(self, tween: Tween) -> None:
        """Add a tween to the active set.

        If a tween already exists for the same target+prop, it is replaced.
        """
        # Remove any existing tween for the same target+prop
        self._active = [
            t for t in self._active
            if not (t.target == tween.target and t.prop == tween.prop)
        ]
        self._active.append(tween)

    def tick(self, st: float) -> None:
        """Evaluate all active tweens at time st.

        Calls apply_callback for each tween's current value.
        Removes completed tweens after evaluation.
        """
        completed = []
        for tween in self._active:
            value = tween.evaluate(st)
            if self._apply_callback:
                self._apply_callback(tween.target, tween.prop, value)
            if tween.is_complete:
                completed.append(tween)

        for tween in completed:
            self._active.remove(tween)

    def clear(self) -> None:
        """Remove all active tweens."""
        self._active.clear()

    @property
    def has_active(self) -> bool:
        """True if there are tweens still animating."""
        return len(self._active) > 0

    def get_active_count(self) -> int:
        """Return the number of active tweens."""
        return len(self._active)


# ---------------------------------------------------------------------------
# Clip cue stepper — extends ActionStepper for Film Studio actions
# ---------------------------------------------------------------------------


class ClipCueStepper(ActionStepper):
    """Steps through a single clip cue, dispatching Film Studio action types.

    Extends ActionStepper to handle tween-based actions (move_to, scale_to,
    camera_to) and clip-specific actions (show_title, show_credits, fade, hold).

    The execute_callback is called for each step, allowing the ClipPlayer
    to handle the actual side effects (Ren'Py displayable updates, etc.).
    """

    def __init__(self, cue: ClipCue, execute_callback: Callable, tween_mgr: TweenManager):
        """
        Args:
            cue: The ClipCue to step through.
            execute_callback: Called as execute_callback(step, on_done, st) for
                            each step. Must call on_done() when async actions
                            complete.
            tween_mgr: TweenManager for handling interpolation actions.
        """
        action = cue.to_scene_action()
        super().__init__(action)
        self._cue = cue
        self._execute_callback = execute_callback
        self._tween_mgr = tween_mgr
        self._min_duration_ms = cue.min_duration_ms
        self._min_hold_until = 0.0

    def start(self, on_complete=None):
        """Begin playback, respecting min_duration_ms."""
        super().start(on_complete=on_complete)
        self._min_hold_until = 0.0  # Set on first tick

    def tick(self, st):
        """Advance tracks and enforce min_duration_ms."""
        if not self._playing:
            return

        if self._start_time is None:
            self._start_time = st
            if self._min_duration_ms > 0:
                self._min_hold_until = st + self._min_duration_ms / 1000.0

        # Tick tweens
        self._tween_mgr.tick(st)

        # Run the base stepper logic
        all_done = True

        for i, track in enumerate(self._action.tracks):
            ts = self._track_states[i]

            if ts["step_idx"] >= len(track.steps):
                continue

            all_done = False

            if ts["waiting"]:
                continue

            if ts["hold_until"] > 0 and st < ts["hold_until"]:
                continue

            ts["step_idx"] += 1
            ts["hold_until"] = 0.0

            if ts["step_idx"] >= len(track.steps):
                continue

            scene_step = track.steps[ts["step_idx"]]
            # Get the original ClipStep for richer dispatch
            clip_step = self._cue.tracks[i].steps[ts["step_idx"]]
            self._dispatch_clip_step(clip_step, scene_step, i, st)

        # Check if all tracks done AND min duration elapsed AND no active tweens
        if all_done and not self._tween_mgr.has_active:
            if self._min_hold_until > 0 and st < self._min_hold_until:
                return  # Still in min hold
            self._playing = False
            if self._on_complete:
                cb = self._on_complete
                self._on_complete = None
                cb()

    def _dispatch_clip_step(self, clip_step: ClipStep, scene_step: SceneActionStep,
                            track_idx: int, st: float):
        """Dispatch a clip step, handling wait and hold states."""
        from .scene import _StepDoneCallback
        ts = self._track_states[track_idx]
        _on_step_done = _StepDoneCallback(self, track_idx)

        # Tween-based actions create tweens and set hold durations
        if clip_step.action in ("move_to", "scale_to", "rotate_to", "camera_to"):
            duration_ms = clip_step.params.get("duration_ms", 0)
            if clip_step.wait and duration_ms > 0:
                ts["hold_until"] = st + duration_ms / 1000.0

        elif clip_step.action == "hold":
            duration_ms = clip_step.params.get("duration_ms", 0)
            if duration_ms > 0:
                ts["hold_until"] = st + duration_ms / 1000.0

        elif clip_step.action in ("show_title", "show_credits", "fade"):
            duration_ms = clip_step.params.get("duration_ms", 0)
            if clip_step.wait and duration_ms > 0:
                ts["hold_until"] = st + duration_ms / 1000.0

        elif clip_step.action == "play_animation":
            if clip_step.wait:
                ts["waiting"] = True

        # Delegate actual side effects to the callback
        self._execute_callback(clip_step, _on_step_done, st)

    def _execute_step(self, step, on_done):
        """Not used directly — overridden by _dispatch_clip_step."""
        pass
