"""
Ren'Py displayable builders.

Creates Ren'Py-native displayables from rigs, poses, and animations.
Uses Transform and Fixed to compose parts into a character.
"""

from __future__ import annotations

import copy
import math
import os
from typing import TYPE_CHECKING, Dict, List, Optional, Callable, Tuple

from .math2d import Vec2, Transform2D
from .rig import Rig, Part
from .pose import Pose, PoseLibrary, apply_pose, flip_posed_rig
from .png_utils import (
    get_png_dimensions as _get_png_dimensions,
    get_png_opaque_bbox as _get_png_opaque_bbox,
    compute_content_bounds as _compute_content_bounds,
)
from .color_utils import (
    parse_color as _parse_color,
    border_offsets as _border_offsets,
    compute_blit_position,
)
from .render_plan import build_render_items
from .rig_state import RigState
from .animation import Animation, AnimationLibrary, AnimationPlayer
from .overlay import Overlay, OverlayLibrary, OverlayPart
from .attachment import (
    AttachmentConfig, AttachmentPoseState, AttachmentBinding,
    AttachmentLibrary, AttachmentInstance,
    compute_attachment_transform, get_attachment_part_world_transform
)
from .scene import (
    Scene, SceneBackground, SceneLayer, SceneLocation, SceneItem,
    SceneCharacter, SceneAttachment,
    SceneAction, SceneActionStep, SceneActionTrack, ActionStepper,
    FOCUS_LAYER_NAME,
)
from .audio import (
    CHANNEL_POSE, CHANNEL_SCENE, CHANNEL_SFX_PREFIX, SFX_CHANNEL_COUNT,
    play_sound, stop_channel,
)

# Ren'Py imports - these only work inside Ren'Py
try:
    import renpy.exports as renpy
    from renpy.display.transform import Transform
    from renpy.display.layout import Fixed
    from renpy.display.im import Image
    from renpy.display.render import render as _renpy_render
    RENPY_AVAILABLE = True
except ImportError:
    RENPY_AVAILABLE = False
    renpy = None
    Transform = None
    Fixed = None
    Image = None
    _renpy_render = None


def _check_renpy():
    """Raise error if Ren'Py is not available."""
    if not RENPY_AVAILABLE:
        raise RuntimeError(
            "Ren'Py is not available. The render module can only be used "
            "inside a Ren'Py game."
        )


class RigDisplayable:
    """
    Creates Ren'Py displayables for a rigged character.

    This is the main interface for showing rigged characters in Ren'Py.
    It can render static poses or play animations.

    Wraps a :class:`RigState` for pure-Python state management and
    delegates rendering to Ren'Py-specific code.
    """

    def __init__(
        self,
        rig: Rig,
        poses: Optional[PoseLibrary] = None,
        animations: Optional[AnimationLibrary] = None,
        overlays: Optional[OverlayLibrary] = None,
        image_path_prefix: str = "",
        attachment_library: Optional[AttachmentLibrary] = None,
        character_directory: str = "",
        base_path: str = "",
        game_directory: str = ""
    ):
        _check_renpy()

        self._state = RigState(
            rig=rig,
            poses=poses,
            animations=animations,
            overlays=overlays,
            attachment_library=attachment_library,
            base_path=base_path,
        )

        # Ren'Py-specific fields
        self.image_path_prefix = image_path_prefix
        self.character_directory = character_directory
        self.game_directory = game_directory

    # ── Delegated properties to RigState ─────────────────────────

    @property
    def rig(self):
        return self._state.rig

    @rig.setter
    def rig(self, value):
        self._state.rig = value

    @property
    def poses(self):
        return self._state.poses

    @poses.setter
    def poses(self, value):
        self._state.poses = value

    @property
    def animations(self):
        return self._state.animations

    @animations.setter
    def animations(self, value):
        self._state.animations = value

    @property
    def overlays(self):
        return self._state.overlays

    @overlays.setter
    def overlays(self, value):
        self._state.overlays = value

    @property
    def attachment_library(self):
        return self._state.attachment_library

    @attachment_library.setter
    def attachment_library(self, value):
        self._state.attachment_library = value

    @property
    def base_path(self):
        return self._state.base_path

    @base_path.setter
    def base_path(self, value):
        self._state.base_path = value

    @property
    def active_overlays(self):
        return self._state.active_overlays

    @active_overlays.setter
    def active_overlays(self, value):
        self._state.active_overlays = value

    @property
    def attachment_instances(self):
        return self._state.attachment_instances

    @attachment_instances.setter
    def attachment_instances(self, value):
        self._state.attachment_instances = value

    @property
    def outline_color(self):
        return self._state.outline_color

    @outline_color.setter
    def outline_color(self, value):
        self._state.outline_color = value

    @property
    def outline_width(self):
        return self._state.outline_width

    @outline_width.setter
    def outline_width(self, value):
        self._state.outline_width = value

    @property
    def outline_alpha(self):
        return self._state.outline_alpha

    @outline_alpha.setter
    def outline_alpha(self, value):
        self._state.outline_alpha = value

    @property
    def _player(self):
        return self._state._player

    @_player.setter
    def _player(self, value):
        self._state._player = value

    @property
    def _current_pose_sound(self):
        return self._state._current_pose_sound

    @_current_pose_sound.setter
    def _current_pose_sound(self, value):
        self._state._current_pose_sound = value

    # ── Delegated state methods ──────────────────────────────────

    def add_attachment(self, name, attachment_rig=None, host_joint=None,
                       poses=None, animations=None, z_offset=0,
                       pos_offset=None, rot_offset=None, scale_offset=None,
                       slot=""):
        """Add an attachment. See RigState.add_attachment for full docs."""
        return self._state.add_attachment(
            name, attachment_rig, host_joint, poses, animations, z_offset,
            pos_offset, rot_offset, scale_offset, slot)

    def remove_attachment(self, name):
        return self._state.remove_attachment(name)

    def get_attachment(self, name):
        return self._state.get_attachment(name)

    def set_attachment_pose(self, name, pose_name):
        self._state.set_attachment_pose(name, pose_name)

    def set_attachment_visible(self, name, visible):
        self._state.set_attachment_visible(name, visible)

    def set_attachment_host_joint(self, name, host_joint):
        self._state.set_attachment_host_joint(name, host_joint)

    def add_overlay(self, name):
        self._state.add_overlay(name)

    def remove_overlay(self, name):
        self._state.remove_overlay(name)

    def get_overlay_by_slot(self, slot):
        return self._state.get_overlay_by_slot(slot)

    def get_attachment_by_slot(self, slot):
        return self._state.get_attachment_by_slot(slot)

    # ── Ren'Py-specific image resolution ─────────────────────────

    def _resolve_image(self, image_path: str, base_path: str = None):
        """Create an Image displayable from a relative image path.

        Args:
            image_path: Relative image path.
            base_path: Optional directory to prepend (e.g. rig.base_path).
        """
        full_path = image_path
        if base_path:
            full_path = os.path.join(base_path, image_path)
        if self.image_path_prefix:
            full_path = os.path.join(self.image_path_prefix, full_path)

        full_path = full_path.replace("\\", "/")

        gamedir = (self.game_directory or renpy.config.gamedir).replace("\\", "/")
        if not gamedir.endswith("/"):
            gamedir += "/"
        if full_path.startswith(gamedir):
            full_path = full_path[len(gamedir):]

        return renpy.displayable(full_path)

    def _get_image(self, image_path: str):
        return self._resolve_image(image_path, base_path=self.rig.base_path)

    def _get_overlay_image(self, image_path: str):
        return self._resolve_image(image_path, base_path=self.rig.base_path)

    def _get_attachment_image(self, image_path: str, attachment_rig: Rig):
        return self._resolve_image(image_path, base_path=attachment_rig.base_path)

    def _get_render_items(self, posed_rig: Rig, pose: Optional[Pose] = None,
                          flip_h: bool = False, flip_v: bool = False):
        """
        Get all items to render (parts + overlays + attachments) sorted by z-order.

        Returns list of tuples: (z_order, item_type, data)
        - item_type is 'part', 'overlay', or 'attachment'
        - data is Part for 'part', (OverlayPart, overlay_name, Part) for 'overlay',
          (Part, AttachmentInstance, Transform2D) for 'attachment'
        """
        return build_render_items(
            posed_rig, self.overlays, self.active_overlays,
            self.attachment_instances, pose, flip_h, flip_v)

    def render_pose(self, pose_name: str = "neutral",
                    crop_to_content: bool = False, crop_rect=None,
                    outline_color=None, outline_width=None,
                    outline_alpha=None,
                    flip_h: bool = False, flip_v: bool = False,
                    overlay_filter=None):
        """
        Render the rig in a specific pose, including any overlays.

        Uses the same pixel-level blit rendering as DynamicRig to ensure
        identical visual output between static poses and animations.

        Args:
            pose_name: Name of the pose to render
            crop_to_content: If True, crop the render to the bounding box
                of visible content (removes transparent margins).
            crop_rect: Optional (x, y, w, h) tuple in canvas coordinates
                to crop to a specific region.  Takes priority over
                crop_to_content.
            outline_color: Optional outline color as a hex string
                (e.g. "#ff0000") or (r, g, b) tuple.  When provided,
                renders a unified outline around the entire rig
                (host + attachments).  Falls back to self.outline_color.
            outline_width: Outline width in pixels.  Falls back to
                self.outline_width (default 3).
            outline_alpha: Outline opacity 0.0–1.0.  Falls back to
                self.outline_alpha (default 1.0).
            flip_h: Mirror the pose horizontally.
            flip_v: Mirror the pose vertically.

        Returns:
            A Ren'Py Displayable
        """
        _check_renpy()

        # Fall back to renderer-level outline settings
        if outline_color is None:
            outline_color = self.outline_color
        if outline_color is not None:
            if outline_width is None:
                outline_width = self.outline_width
            if outline_alpha is None:
                outline_alpha = self.outline_alpha

        # Get the pose and apply it
        pose = self.poses.get(pose_name)
        if pose:
            posed_rig = apply_pose(self.rig, pose)
        else:
            posed_rig = self.rig
            posed_rig.update_world_positions()

        # Apply flip
        if flip_h or flip_v:
            flip_posed_rig(posed_rig, flip_h, flip_v)

        # Play pose sound if changed
        pose_sound = pose.sound if pose else None
        if pose_sound != self._current_pose_sound:
            self._current_pose_sound = pose_sound
            if pose_sound:
                base = self.rig.base_path or ""
                play_sound(pose_sound, CHANNEL_POSE, base_path=base)
            else:
                stop_channel(CHANNEL_POSE)

        return StaticRig(posed_rig, self, pose,
                         crop_to_content=crop_to_content, crop_rect=crop_rect,
                         outline_color=outline_color,
                         outline_width=outline_width,
                         outline_alpha=outline_alpha,
                         flip_h=flip_h, flip_v=flip_v,
                         overlay_filter=overlay_filter)

    def render_pose_direct(self, pose, flip_h=False, flip_v=False,
                           outline_color=None, outline_width=None,
                           outline_alpha=None):
        """Render a Pose object directly (bypasses pose library lookup).

        Used for multi-track compositing where the pose is computed on-the-fly.
        """
        _check_renpy()

        if outline_color is None:
            outline_color = self.outline_color
        if outline_color is not None:
            if outline_width is None:
                outline_width = self.outline_width
            if outline_alpha is None:
                outline_alpha = self.outline_alpha

        if pose:
            posed_rig = apply_pose(self.rig, pose)
        else:
            posed_rig = self.rig
            posed_rig.update_world_positions()

        if flip_h or flip_v:
            flip_posed_rig(posed_rig, flip_h, flip_v)

        return StaticRig(posed_rig, self, pose,
                         outline_color=outline_color,
                         outline_width=outline_width,
                         outline_alpha=outline_alpha,
                         flip_h=flip_h, flip_v=flip_v)

    def render_rig(self, rig: Rig):
        """
        Render a rig directly (used for live editing).

        Args:
            rig: The rig to render (with transforms already applied)

        Returns:
            A Ren'Py Displayable
        """
        _check_renpy()

        rig.update_world_positions()

        return StaticRig(rig, self, pose=None)

    def show_pose(self, pose_name: str = "neutral",
                  crop_to_content: bool = False, crop_rect=None,
                  outline_color=None, outline_width=None,
                  outline_alpha=None,
                  flip_h: bool = False, flip_v: bool = False,
                  overlay_filter=None) -> "Fixed":
        """
        Alias for render_pose, for API consistency.

        Args:
            pose_name: Name of the pose to show
            crop_to_content: If True, crop to visible content bounds.
            crop_rect: Optional (x, y, w, h) crop region in canvas coords.
            outline_color: Optional outline color as a hex string
                (e.g. "#ff0000") or (r, g, b) tuple.
            outline_width: Outline width in pixels (default 3 when
                outline_color is set).
            outline_alpha: Outline opacity 0.0–1.0 (default 1.0).
            flip_h: Mirror the pose horizontally.
            flip_v: Mirror the pose vertically.
            overlay_filter: When set, only render overlay items matching
                this overlay name.

        Returns:
            A Ren'Py Fixed displayable
        """
        return self.render_pose(pose_name, crop_to_content=crop_to_content,
                                crop_rect=crop_rect,
                                outline_color=outline_color,
                                outline_width=outline_width,
                                outline_alpha=outline_alpha,
                                flip_h=flip_h, flip_v=flip_v,
                                overlay_filter=overlay_filter)


def _apply_alpha(child_rv, alpha, w, h, st, at):
    """Return a new Render with *alpha* applied to *child_rv*.

    Uses a Transform wrapper so Ren'Py handles the alpha through its
    normal texture pipeline (Render.alpha alone is not reliable).
    """
    class _Wrap(renpy.Displayable):
        def __init__(self, rv, **kw):
            super().__init__(**kw)
            self._rv = rv
        def render(self, _w, _h, _st, _at):
            return self._rv
        def visit(self):
            return []

    t = Transform(_Wrap(child_rv), alpha=alpha)
    return _renpy_render(t, w, h, st, at)


def _blit_rig_item(img, transform, canvas_w, canvas_h, st, at, rv,
                   silhouette_color=None):
    """
    Render and blit a single rig part onto a render target.

    Handles scale (including negative for flip) and rotation, computing
    the correct blit position so the part's pivot aligns with its world position.

    Used by both StaticRig and DynamicRig for consistent rendering.

    When silhouette_color is set, the image RGB is replaced with the given
    color while preserving alpha, producing a solid-color silhouette.
    """
    if silhouette_color:
        r, g, b = silhouette_color
        matrix = renpy.display.matrix.Matrix([
            0, 0, 0, r / 255.0,
            0, 0, 0, g / 255.0,
            0, 0, 0, b / 255.0,
            0, 0, 0, 1,
        ])
        img = Transform(img, matrixcolor=matrix)

    rotation = transform.rotation
    scale_x = transform.scale.x
    scale_y = transform.scale.y
    pivot_x = transform.pivot.x
    pivot_y = transform.pivot.y

    base_render = renpy.render(img, canvas_w, canvas_h, st, at)
    orig_w, orig_h = base_render.get_size()

    # Compute blit position using pure-Python math
    blit_x, blit_y = compute_blit_position(transform, orig_w, orig_h)

    # Build the scaled/rotated Ren'Py render.
    # Use transform_anchor=True with the pivot as anchor so that scale and
    # rotation happen around the pivot point — matching the editor screen.
    # Without this, Transform rotates around the image center, producing
    # visually different pixel output even though the blit position is correct.
    if rotation == 0:
        if scale_x != 1 or scale_y != 1:
            part_render = renpy.render(
                Transform(img, anchor=(pivot_x, pivot_y),
                          transform_anchor=True,
                          xzoom=scale_x, yzoom=scale_y),
                canvas_w, canvas_h, st, at)
        else:
            part_render = base_render
    else:
        part_render = renpy.render(
            Transform(img, anchor=(pivot_x, pivot_y),
                      transform_anchor=True, rotate_pad=False,
                      xzoom=scale_x, yzoom=scale_y, rotate=rotation),
            canvas_w, canvas_h, st, at)

    rv.blit(part_render, (blit_x, blit_y))
    pw, ph = part_render.get_size()
    return (blit_x, blit_y, pw, ph)


def _render_rig_items(renderer, posed_rig, pose, canvas_w, canvas_h, st, at, rv,
                      silhouette_color=None, attachment_filter=None,
                      exclude_attachments=False, border_silhouettes=None,
                      blit_offset=None, flip_h=False, flip_v=False,
                      overlay_filter=None):
    """
    Render all rig items (parts, overlays, attachments) into a render target.

    Used by both StaticRig and DynamicRig for consistent rendering.

    Args:
        silhouette_color: When set, all items are rendered as a solid-color
            silhouette (for border/outline generation).
        attachment_filter: When set (attachment instance name), only render
            items belonging to that specific attachment.
        exclude_attachments: When True, skip all attachment items (for
            host-only silhouette passes).
        border_silhouettes: Dict mapping group name to (Render, border_width).
            Group '__host__' is for host rig parts/overlays; attachment instance
            names are for attachments.  Each group's silhouette is blitted at
            circular offsets just before the first item of that group in z-order.
        blit_offset: (ox, oy) tuple. When set, content items are blitted into
            rv at this offset (used with padded render targets for borders).

    Returns:
        Content bounding box as (x, y, w, h), or None if nothing was rendered.
    """
    render_items = renderer._get_render_items(posed_rig, pose,
                                              flip_h=flip_h, flip_v=flip_v)

    # When blit_offset is set, render items into a sub-render at canvas size,
    # then blit it into rv at the offset.  Border silhouettes are blitted
    # directly into rv (they're already in padded coordinates).
    if blit_offset:
        content_rv = renpy.Render(int(posed_rig.canvas_size.x), int(posed_rig.canvas_size.y))
    else:
        content_rv = rv

    min_x = float('inf')
    min_y = float('inf')
    max_x = float('-inf')
    max_y = float('-inf')
    has_content = False

    # Track which border groups have been started (for inline insertion)
    started_groups = set() if border_silhouettes is not None else None

    for z_order, item_type, data in render_items:
        rect = None

        # When attachment_filter is set, skip everything except matching attachments
        if attachment_filter is not None:
            if item_type != 'attachment':
                continue
            _part, instance, _wt = data
            if instance.name != attachment_filter:
                continue

        # When overlay_filter is set, skip everything except matching overlays
        if overlay_filter is not None:
            if item_type != 'overlay':
                continue
            _overlay_part, _overlay_name, _base_part = data
            if _overlay_name != overlay_filter:
                continue

        # When exclude_attachments is set, skip all attachment items
        if exclude_attachments and item_type == 'attachment':
            continue

        # Determine group for border insertion
        if border_silhouettes is not None:
            if item_type == 'attachment':
                _part, instance, _wt = data
                group = instance.name
            else:
                group = '__host__'
            # Insert border silhouette before first item of each group
            if group not in started_groups and group in border_silhouettes:
                started_groups.add(group)
                sil, bwidth = border_silhouettes[group]
                for dx, dy in _border_offsets(bwidth):
                    rv.blit(sil, (dx, dy))

        if item_type == 'part':
            part = data
            if not part.visible:
                continue
            img = renderer._get_image(part.image)
            transform = posed_rig.get_part_world_transform(part.name)
            if transform is None:
                continue
            rect = _blit_rig_item(img, transform, canvas_w, canvas_h, st, at,
                                  content_rv, silhouette_color=silhouette_color)

        elif item_type == 'overlay':
            overlay_part, overlay_name, base_part = data
            if not base_part.visible:
                continue
            overlay_image_path = overlay_part.get_image_path(overlay_name)
            img = renderer._get_overlay_image(overlay_image_path)
            transform = posed_rig.get_part_world_transform(base_part.name)
            if transform is None:
                continue
            rect = _blit_rig_item(img, transform, canvas_w, canvas_h, st, at,
                                  content_rv, silhouette_color=silhouette_color)

        elif item_type == 'attachment':
            part, instance, world_transform = data
            if not part.visible:
                continue
            img = renderer._get_attachment_image(part.image, instance.attachment_rig)
            rect = _blit_rig_item(img, world_transform, canvas_w, canvas_h, st, at,
                                  content_rv, silhouette_color=silhouette_color)

        if rect:
            bx, by, bw, bh = rect
            min_x = min(min_x, bx)
            min_y = min(min_y, by)
            max_x = max(max_x, bx + bw)
            max_y = max(max_y, by + bh)
            has_content = True

    # When using blit_offset, composite content_rv into rv at the offset
    if blit_offset and content_rv is not rv:
        rv.blit(content_rv, blit_offset)

    if has_content:
        min_x = max(0.0, min_x)
        min_y = max(0.0, min_y)
        max_x = min(float(canvas_w), max_x)
        max_y = min(float(canvas_h), max_y)
        if max_x > min_x and max_y > min_y:
            return (min_x, min_y, max_x - min_x, max_y - min_y)
    return None


def _render_with_borders(renderer, posed_rig, pose, canvas_w, canvas_h, st, at,
                         outline_color=None, outline_width=None, outline_alpha=None,
                         flip_h=False, flip_v=False, crop=None,
                         border_only=False, border_group=None,
                         overlay_filter=None):
    """Shared border/outline pipeline for StaticRig and DynamicRig.

    Args:
        outline_color: Already-parsed (r, g, b) tuple or None.
        crop: Optional (x, y, w, h) in canvas coords (StaticRig only).
        border_only: Render only border silhouettes (StaticRig only).
        border_group: Filter to a single border group (StaticRig only).

    Returns:
        A renpy.Render.
    """
    # Build outline silhouette
    outline_sil_info = None
    if outline_color is not None:
        outline_sil = renpy.Render(canvas_w, canvas_h)
        _render_rig_items(renderer, posed_rig, pose,
                          canvas_w, canvas_h, st, at, outline_sil,
                          silhouette_color=outline_color,
                          flip_h=flip_h, flip_v=flip_v,
                          overlay_filter=overlay_filter)
        outline_sil_info = (outline_sil, outline_width, outline_alpha)

    # Build per-group border silhouettes
    # Skip when overlay_filter is set — we only want the overlay content,
    # not the full host/attachment border shapes behind it.
    border_sils = {}
    border = posed_rig.border
    if border and border.enabled and not overlay_filter:
        sil = renpy.Render(canvas_w, canvas_h)
        _render_rig_items(renderer, posed_rig, pose,
                          canvas_w, canvas_h, st, at, sil,
                          silhouette_color=border.color,
                          exclude_attachments=True,
                          flip_h=flip_h, flip_v=flip_v)
        border_sils['__host__'] = (sil, border.width)

        for att_name, instance in renderer.attachment_instances.items():
            if not instance.visible or not instance.attachment_rig:
                continue
            att_border = instance.attachment_rig.border
            if att_border and att_border.enabled:
                att_sil = renpy.Render(canvas_w, canvas_h)
                _render_rig_items(renderer, posed_rig, pose,
                                  canvas_w, canvas_h, st, at, att_sil,
                                  silhouette_color=att_border.color,
                                  attachment_filter=att_name,
                                  flip_h=flip_h, flip_v=flip_v)
                border_sils[att_name] = (att_sil, att_border.width)

    # Compute padding
    outline_pad = outline_sil_info[1] if outline_sil_info else 0
    border_vis = max((bw for _sil, bw in border_sils.values()), default=0)
    visual_pad = max(outline_pad, border_vis)

    content_pad = 0
    if crop:
        content_pad = max(
            max(0, -(int(crop[0]) - visual_pad)),
            max(0, -(int(crop[1]) - visual_pad)),
            max(0, int(crop[0] + crop[2] + 1 + visual_pad) - canvas_w),
            max(0, int(crop[1] + crop[3] + 1 + visual_pad) - canvas_h),
        )

    pad = max(visual_pad, content_pad)

    if pad > 0:
        pw = canvas_w + 2 * pad
        ph = canvas_h + 2 * pad

        padded_sils = {}
        for gname, (sil, bwidth) in border_sils.items():
            shifted = renpy.Render(pw, ph)
            shifted.blit(sil, (pad, pad))
            padded_sils[gname] = (shifted, bwidth)

        inner = renpy.Render(pw, ph)

        if outline_sil_info:
            o_sil, o_width, o_alpha = outline_sil_info
            shifted_o = renpy.Render(pw, ph)
            shifted_o.blit(o_sil, (pad, pad))
            outline_rv = renpy.Render(pw, ph)
            for dx, dy in _border_offsets(o_width):
                outline_rv.blit(shifted_o, (dx, dy))
            if o_alpha is not None and o_alpha < 1.0:
                outline_rv = _apply_alpha(outline_rv, o_alpha, pw, ph, st, at)
            inner.blit(outline_rv, (0, 0))

        if border_only:
            for gname, (shifted_sil, bwidth) in padded_sils.items():
                if border_group is not None and gname != border_group:
                    continue
                for dx, dy in _border_offsets(bwidth):
                    inner.blit(shifted_sil, (dx, dy))
        else:
            _render_rig_items(
                renderer, posed_rig, pose,
                pw, ph, st, at, inner,
                border_silhouettes=padded_sils,
                blit_offset=(pad, pad),
                flip_h=flip_h, flip_v=flip_v,
                overlay_filter=overlay_filter)

        if crop:
            bx = int(crop[0]) + pad - visual_pad
            by = int(crop[1]) + pad - visual_pad
            bw = int(crop[2] + 1) + 2 * visual_pad
            bh = int(crop[3] + 1) + 2 * visual_pad
            if bw > 0 and bh > 0:
                tight = renpy.Render(bw, bh)
                tight.xclipping = True
                tight.yclipping = True
                tight.blit(inner, (-bx, -by))
                return tight

        rv = renpy.Render(canvas_w, canvas_h)
        rv.blit(inner, (-pad, -pad))
        return rv

    # No padding — render directly
    rv = renpy.Render(canvas_w, canvas_h)

    if not border_only:
        _render_rig_items(renderer, posed_rig, pose,
                          canvas_w, canvas_h, st, at, rv,
                          flip_h=flip_h, flip_v=flip_v,
                          overlay_filter=overlay_filter)

    if crop:
        bx = int(crop[0])
        by = int(crop[1])
        bw = int(crop[2] + 1)
        bh = int(crop[3] + 1)
        if bw > 0 and bh > 0:
            tight = renpy.Render(bw, bh)
            tight.xclipping = True
            tight.yclipping = True
            tight.blit(rv, (-bx, -by))
            return tight

    return rv


class StaticRig(renpy.Displayable if RENPY_AVAILABLE else object):
    """
    A Ren'Py Displayable that renders a rig in a static pose.

    Uses the same pixel-level blit rendering as DynamicRig to ensure
    identical visual output between static poses and animations.
    """

    def __init__(self, posed_rig, renderer, pose=None,
                 crop_to_content=False, crop_rect=None, border_only=False,
                 border_group=None, outline_color=None, outline_width=None,
                 outline_alpha=None, flip_h=False, flip_v=False,
                 overlay_filter=None, **kwargs):
        if RENPY_AVAILABLE:
            super().__init__(**kwargs)
        self._posed_rig = posed_rig
        self._renderer = renderer
        self._pose = pose
        self._crop_to_content = crop_to_content
        self._crop_rect = crop_rect  # (x, y, w, h) in canvas coordinates
        self._border_only = border_only
        self._border_group = border_group  # when set with border_only, only render this group's border
        self._flip_h = flip_h
        self._flip_v = flip_v
        # On-demand outline: normalise color to (r, g, b) tuple
        if outline_color is not None:
            outline_color = _parse_color(outline_color)
            if outline_width is None:
                outline_width = 3
            if outline_alpha is None:
                outline_alpha = 1.0
        self._outline_color = outline_color
        self._outline_width = outline_width
        self._outline_alpha = outline_alpha
        self._overlay_filter = overlay_filter

    def render(self, width, height, st, at):
        canvas_w = int(self._posed_rig.canvas_size.x)
        canvas_h = int(self._posed_rig.canvas_size.y)

        if self._crop_rect:
            crop = self._crop_rect
        elif self._crop_to_content:
            crop = _compute_content_bounds(
                self._posed_rig, self._renderer.character_directory)
        else:
            crop = None

        return _render_with_borders(
            self._renderer, self._posed_rig, self._pose,
            canvas_w, canvas_h, st, at,
            outline_color=self._outline_color,
            outline_width=self._outline_width,
            outline_alpha=self._outline_alpha,
            flip_h=self._flip_h, flip_v=self._flip_v,
            crop=crop, border_only=self._border_only,
            border_group=self._border_group,
            overlay_filter=self._overlay_filter)

    def visit(self):
        children = []
        for part in self._posed_rig.parts.values():
            img = self._renderer._get_image(part.image)
            children.append(img)
        return children

    def event(self, ev, x, y, st):
        return None

    def get_root_pos(self):
        """Root joint position within the posed rig's canvas."""
        root = self._posed_rig.get_root_joint()
        return (root.world_pos.x, root.world_pos.y) if root else (0, 0)


class DynamicRig(renpy.Displayable if RENPY_AVAILABLE else object):
    """
    A Ren'Py Displayable that animates a rig over time.

    This integrates with Ren'Py's animation system to smoothly
    update the character on each frame.
    """

    def __init__(
        self,
        rig: Rig,
        poses: PoseLibrary,
        animation: Animation,
        overlays: Optional[OverlayLibrary] = None,
        image_path_prefix: str = "",
        interpolate: bool = True,
        flip_h: bool = False,
        flip_v: bool = False,
        on_complete: Optional[Callable[[], None]] = None,
        renderer: Optional[RigDisplayable] = None,
        **kwargs
    ):
        _check_renpy()

        super().__init__(**kwargs)

        self.rig = rig
        self.poses = poses
        self.animation = animation
        self.overlays = overlays or OverlayLibrary()
        self.image_path_prefix = image_path_prefix
        self.flip_h = flip_h
        self.flip_v = flip_v

        if renderer is not None:
            self._renderer = renderer
        else:
            self._renderer = RigDisplayable(rig, poses, None, overlays, image_path_prefix)

        self._player = AnimationPlayer(animation, poses, interpolate)
        self._player.start()

        if on_complete:
            self._player.on_complete(on_complete)

        self._last_pose: Optional[Pose] = None

        # Sound tracking — frame-based, not blend-based
        self._last_frame_idx: int = -1
        # Animation timeline sounds — trigger-based, not window-based
        self._sfx_cycle: int = -1          # current loop cycle
        self._triggered_sfx: set = set()   # indices of sounds already triggered this cycle

    def render(self, width, height, st, at):
        current_pose = self._player.get_current_pose()
        current_frame = self._player.get_current_frame()

        posed_rig = apply_pose(self.rig, current_pose, self.flip_h, self.flip_v)
        posed_rig.update_world_positions()

        # Apply per-frame flip
        _fh = current_frame.flip_h if current_frame else False
        _fv = current_frame.flip_v if current_frame else False
        if _fh or _fv:
            flip_posed_rig(posed_rig, _fh, _fv)

        canvas_w = int(posed_rig.canvas_size.x)
        canvas_h = int(posed_rig.canvas_size.y)

        # Apply per-frame overlay/attachment overrides with save/restore
        saved_overlays = None
        saved_visibility = {}

        if current_frame is not None:
            from .animation import resolve_frame_toggles

            if current_frame.overlays is not None:
                saved_overlays = list(self._renderer.active_overlays)
                self._renderer.active_overlays = resolve_frame_toggles(
                    self._renderer.active_overlays, current_frame.overlays)

            if current_frame.attachments is not None:
                for name, instance in self._renderer.attachment_instances.items():
                    saved_visibility[name] = instance.visible
                active_names = resolve_frame_toggles(
                    [n for n, inst in self._renderer.attachment_instances.items() if inst.visible],
                    current_frame.attachments)
                for name, instance in self._renderer.attachment_instances.items():
                    instance.visible = (name in active_names)

        # --- Pose sound playback (frame-based, not blend-based) ---
        # Trigger sound when the discrete frame index changes, not on every
        # render call.  This avoids the blend_poses fallback issue where the
        # blended pose always carries a sound even during no-sound frames.
        frame_idx, _blend = self._player.animation.get_frame_at_time(
            self._player.elapsed_ms)
        if frame_idx != self._last_frame_idx:
            self._last_frame_idx = frame_idx
            # Resolve per-frame sound override: None=inherit, ""=mute, "path"=override
            if current_frame is not None and current_frame.sound is not None:
                effective_sound = current_frame.sound
            else:
                # Inherit from the pose definition (not the blended pose)
                src_pose = self.poses.get(current_frame.pose) if current_frame else None
                effective_sound = src_pose.sound if src_pose else None

            base = self.rig.base_path or ""
            if effective_sound and effective_sound != "":
                play_sound(effective_sound, CHANNEL_POSE, base_path=base)
            elif effective_sound == "":
                # Explicit mute — stop any currently playing pose sound
                stop_channel(CHANNEL_POSE)
            # effective_sound is None — no sound for this frame, let any
            # previous short sound finish naturally

        # --- Animation timeline sounds (trigger-based) ---
        if self.animation.sounds:
            from .animation import PlayMode
            raw_elapsed = self._player.elapsed_ms
            total_dur = self.animation.total_duration_ms
            base = self.rig.base_path or ""

            # Compute position within the current loop cycle
            if self.animation.mode == PlayMode.LOOP and total_dur > 0:
                cycle = raw_elapsed // total_dur
                loop_elapsed = raw_elapsed % total_dur
            else:
                cycle = 0
                loop_elapsed = raw_elapsed

            # Reset triggers on new cycle (animation looped)
            if cycle != self._sfx_cycle:
                self._sfx_cycle = cycle
                self._triggered_sfx.clear()

            for i, asound in enumerate(self.animation.sounds):
                ch_idx = i % SFX_CHANNEL_COUNT
                ch_name = "{}{}".format(CHANNEL_SFX_PREFIX, ch_idx)

                if i not in self._triggered_sfx and loop_elapsed >= asound.start_ms:
                    # Fire this sound
                    self._triggered_sfx.add(i)
                    loop = asound.duration_ms > 0
                    play_sound(asound.path, ch_name, loop=loop, base_path=base)

                # For looping-duration sounds, stop when the window ends
                if asound.duration_ms > 0 and i in self._triggered_sfx:
                    end_ms = asound.start_ms + asound.duration_ms
                    if loop_elapsed >= end_ms:
                        stop_channel(ch_name)

        # Resolve on-demand outline (read from renderer each frame for live updates)
        o_color = self._renderer.outline_color
        if o_color is not None:
            o_color = _parse_color(o_color)

        # Combine animation-level flip with per-frame flip (XOR: two flips cancel out)
        effective_fh = self.flip_h != _fh
        effective_fv = self.flip_v != _fv

        rv = _render_with_borders(
            self._renderer, posed_rig, current_pose,
            canvas_w, canvas_h, st, at,
            outline_color=o_color,
            outline_width=self._renderer.outline_width,
            outline_alpha=self._renderer.outline_alpha,
            flip_h=effective_fh, flip_v=effective_fv)

        # Restore saved state
        if saved_overlays is not None:
            self._renderer.active_overlays = saved_overlays
        for name, was_visible in saved_visibility.items():
            inst = self._renderer.attachment_instances.get(name)
            if inst is not None:
                inst.visible = was_visible

        needs_redraw = self._player.is_playing
        if not needs_redraw:
            for inst in self._renderer.attachment_instances.values():
                if inst._player and inst._player.is_playing:
                    needs_redraw = True
                    break
        if needs_redraw:
            renpy.redraw(self, 0)

        return rv

    def visit(self):
        children = []
        for part in self.rig.parts.values():
            img = self._renderer._get_image(part.image)
            children.append(img)
        return children

    def event(self, ev, x, y, st):
        return None


class RigRenderer:
    """
    High-level API for rendering rigged characters.

    This is the primary class users should interact with.
    """

    def __init__(
        self,
        rig: Rig,
        poses: Optional[PoseLibrary] = None,
        animations: Optional[AnimationLibrary] = None,
        overlays: Optional[OverlayLibrary] = None,
        image_path_prefix: str = "",
        attachment_library: Optional[AttachmentLibrary] = None,
        character_directory: str = "",
        base_path: str = "",
        game_directory: str = ""
    ):
        """
        Create a rig renderer.

        Args:
            rig: The character rig
            poses: Optional pose library
            animations: Optional animation library
            overlays: Optional overlay library
            image_path_prefix: Prefix to add to all image paths
            attachment_library: Optional attachment library for auto-loading attachments
            character_directory: Character directory path for loading attachment assets
            base_path: Base path for resolving attachment paths
            game_directory: External game directory for resolving image paths.
                When empty, falls back to renpy.config.gamedir.
        """
        self.rig = rig
        self.poses = poses or PoseLibrary()
        self.animations = animations or AnimationLibrary()
        self.overlays = overlays or OverlayLibrary()
        self.image_path_prefix = image_path_prefix
        self.attachment_library = attachment_library or AttachmentLibrary()
        self.character_directory = character_directory
        self.base_path = base_path
        self.game_directory = game_directory

        self._zoom = 1.0
        self._last_displayable = None

        self._static_renderer = RigDisplayable(
            rig, self.poses, self.animations, self.overlays, image_path_prefix,
            attachment_library, character_directory, base_path, game_directory
        )

    # -- Delegated properties (read/write passthrough to _static_renderer) --
    def _delegate(attr):
        """Create a property that delegates to _static_renderer."""
        return property(lambda self: getattr(self._static_renderer, attr),
                        lambda self, v: setattr(self._static_renderer, attr, v))

    active_overlays = _delegate('active_overlays')
    outline_color = _delegate('outline_color')
    outline_width = _delegate('outline_width')
    outline_alpha = _delegate('outline_alpha')
    del _delegate  # remove helper from class namespace

    @property
    def zoom(self) -> float:
        return self._zoom

    @zoom.setter
    def zoom(self, value: float):
        self._zoom = value

    @property
    def attachment_instances(self) -> Dict[str, AttachmentInstance]:
        return self._static_renderer.attachment_instances

    def get_root_canvas_pos(self):
        """Root joint position within the rig's rendered canvas."""
        root = self.rig.get_root_joint()
        return (root.local_pos.x, root.local_pos.y) if root else (0, 0)

    def get_current_displayable(self):
        """Return the most recently created displayable (static or animated).

        Returns the last displayable produced by show_pose() or play_animation().
        Returns None if no displayable has been created yet.
        """
        return self._last_displayable

    # -- Attachment management (delegates to RigDisplayable) --
    def add_attachment(self, name, attachment_rig=None, host_joint=None,
                       poses=None, animations=None, z_offset=0,
                       pos_offset=None, rot_offset=None, scale_offset=None,
                       slot=""):
        """Add an attachment. See RigDisplayable.add_attachment for full docs."""
        return self._static_renderer.add_attachment(
            name, attachment_rig, host_joint, poses, animations, z_offset,
            pos_offset, rot_offset, scale_offset, slot)

    def remove_attachment(self, name):
        return self._static_renderer.remove_attachment(name)

    def get_attachment(self, name):
        return self._static_renderer.get_attachment(name)

    def set_attachment_pose(self, name, pose_name):
        self._static_renderer.set_attachment_pose(name, pose_name)

    def set_attachment_visible(self, name, visible):
        self._static_renderer.set_attachment_visible(name, visible)

    def set_attachment_host_joint(self, name, host_joint):
        self._static_renderer.set_attachment_host_joint(name, host_joint)

    def add_overlay(self, name):
        """Add an overlay. See RigDisplayable.add_overlay for full docs."""
        self._static_renderer.add_overlay(name)

    def remove_overlay(self, name):
        """Remove an overlay. See RigDisplayable.remove_overlay for full docs."""
        self._static_renderer.remove_overlay(name)

    def get_overlay_by_slot(self, slot):
        """Get active overlay name by slot. See RigDisplayable.get_overlay_by_slot."""
        return self._static_renderer.get_overlay_by_slot(slot)

    def get_attachment_by_slot(self, slot):
        """Get attachment instance by slot. See RigDisplayable.get_attachment_by_slot."""
        return self._static_renderer.get_attachment_by_slot(slot)

    def show_pose(self, pose_name="neutral", crop_to_content=False,
                  crop_rect=None, outline_color=None, outline_width=None,
                  outline_alpha=None, flip_h=False, flip_v=False,
                  overlay_filter=None):
        """Get a displayable showing the character in a pose.

        See RigDisplayable.show_pose for full parameter docs.
        Applies self.zoom if != 1.0.
        """
        disp = self._static_renderer.show_pose(
            pose_name, crop_to_content=crop_to_content, crop_rect=crop_rect,
            outline_color=outline_color, outline_width=outline_width,
            outline_alpha=outline_alpha, flip_h=flip_h, flip_v=flip_v,
            overlay_filter=overlay_filter)
        if self._zoom != 1.0:
            disp = Transform(disp, zoom=self._zoom)
        self._last_displayable = disp
        return disp

    def show_pose_direct(self, pose, flip_h=False, flip_v=False,
                         outline_color=None, outline_width=None,
                         outline_alpha=None):
        """Render a Pose object directly (bypasses pose library lookup).

        Used for multi-track compositing preview.
        """
        disp = self._static_renderer.render_pose_direct(
            pose, flip_h=flip_h, flip_v=flip_v,
            outline_color=outline_color, outline_width=outline_width,
            outline_alpha=outline_alpha)
        if self._zoom != 1.0:
            disp = Transform(disp, zoom=self._zoom)
        return disp

    def get_content_bounds(
        self, pose_name: str = "neutral"
    ) -> Optional[Tuple[float, float, float, float]]:
        """
        Compute the bounding box of visible content for a pose.

        Uses the part transforms and image dimensions (read from PNG headers)
        to analytically determine where content falls on the canvas, without
        performing a full render.

        Args:
            pose_name: Name of the pose to compute bounds for.

        Returns:
            (x, y, width, height) bounding box, or None if no visible parts.
        """
        pose = self.poses.get(pose_name)
        if pose:
            posed_rig = apply_pose(self.rig, pose)
        else:
            self.rig.update_world_positions()
            posed_rig = self.rig

        return _compute_content_bounds(posed_rig, self.character_directory)

    def play_animation(
        self,
        animation_name: str,
        loop: bool = True,
        flip_h: bool = False,
        flip_v: bool = False,
        interpolate: bool = True,
        on_complete: Optional[Callable[[], None]] = None,
        sync_attachments: bool = True
    ):
        """
        Get a displayable that plays an animation.

        Usage in Ren'Py:
            show expression renderer.play_animation("idle", loop=True) at center

        Args:
            animation_name: Name of the animation to play
            loop: Whether to loop the animation
            interpolate: Whether to interpolate between poses
            on_complete: Callback when animation completes
            sync_attachments: When True, auto-play matching animations on
                attachments that have animation_sync=True

        Returns:
            A Ren'Py displayable
        """
        animation = self.animations.get(animation_name)
        if animation is None:
            raise ValueError(f"Animation '{animation_name}' not found")

        # Copy so we don't mutate the shared library Animation object
        from .animation import PlayMode
        animation = copy.copy(animation)
        animation.mode = PlayMode.LOOP if loop else PlayMode.ONCE

        # Auto-sync attachment animations
        synced_instances = []
        if sync_attachments:
            for instance in self.attachment_instances.values():
                if not instance.animation_sync:
                    continue
                if instance.attachment_animations is None:
                    continue
                if instance.attachment_animations.get(animation_name) is None:
                    continue
                instance.play_animation(animation_name, loop=loop, interpolate=interpolate)
                synced_instances.append(instance)

        # Wrap on_complete to also stop synced attachment animations (ONCE mode)
        original_on_complete = on_complete
        if synced_instances and not loop:
            def _wrapped_on_complete():
                for inst in synced_instances:
                    inst.stop_animation()
                if original_on_complete:
                    original_on_complete()
            on_complete = _wrapped_on_complete

        disp = DynamicRig(
            rig=self.rig,
            poses=self.poses,
            animation=animation,
            overlays=self.overlays,
            image_path_prefix=self.image_path_prefix,
            interpolate=interpolate,
            flip_h=flip_h,
            flip_v=flip_v,
            on_complete=on_complete,
            renderer=self._static_renderer  # Share renderer for active_overlays sync
        )
        if self._zoom != 1.0:
            disp = Transform(disp, zoom=self._zoom)
        self._last_displayable = disp
        return disp

    def play_attachment_animation(self, name_or_slot: str, animation_name: str,
                                  loop: bool = True, interpolate: bool = True) -> None:
        """Play an animation on a specific attachment by name or slot.

        Args:
            name_or_slot: Attachment instance name or slot name
            animation_name: Name of the animation to play
            loop: Whether to loop the animation
            interpolate: Whether to interpolate between poses
        """
        instance = self.attachment_instances.get(name_or_slot)
        if instance is None:
            instance = self.get_attachment_by_slot(name_or_slot)
        if instance is None:
            raise ValueError(f"Attachment '{name_or_slot}' not found")
        instance.play_animation(animation_name, loop=loop, interpolate=interpolate)

    def stop_attachment_animation(self, name_or_slot: str) -> None:
        """Stop animation on a specific attachment by name or slot.

        Args:
            name_or_slot: Attachment instance name or slot name
        """
        instance = self.attachment_instances.get(name_or_slot)
        if instance is None:
            instance = self.get_attachment_by_slot(name_or_slot)
        if instance is None:
            raise ValueError(f"Attachment '{name_or_slot}' not found")
        instance.stop_animation()

    @classmethod
    def from_directory(
        cls,
        directory: str,
        image_path_prefix: str = "",
        base_path: str = "",
        load_attachments: bool = True,
        game_directory: str = ""
    ) -> "RigRenderer":
        """
        Create a RigRenderer by loading all assets from a directory.

        Args:
            directory: Path to character directory containing rig.json, etc.
            image_path_prefix: Optional prefix for image paths
            base_path: Optional base path for loading files
            load_attachments: Whether to load and setup attachments from attachments.json
            game_directory: External game directory for resolving image paths.
                When empty, falls back to renpy.config.gamedir.

        Returns:
            A configured RigRenderer
        """
        from .io import RigAssets, load_rig, load_poses, load_animations

        # If base_path is empty and directory is absolute, infer game directory
        # by going up from the character directory (typically game/characters/name)
        resolved_base_path = base_path
        if not base_path and os.path.isabs(directory):
            # Try to find the game directory by going up from character directory
            # Typically character is in gamedir/characters/name or similar
            parent = os.path.dirname(directory)
            parent_name = os.path.basename(parent)
            if parent_name in ('characters', 'character', 'attachments', 'attachment'):
                # Character is in characters/ subdirectory, so game dir is one level up
                resolved_base_path = os.path.dirname(parent)
            else:
                # Character is directly in game directory
                resolved_base_path = parent

        assets = RigAssets.load(directory, resolved_base_path)

        renderer = cls(
            rig=assets.rig,
            poses=assets.poses,
            animations=assets.animations,
            overlays=assets.overlays,
            image_path_prefix=image_path_prefix,
            attachment_library=assets.attachment_bindings,
            character_directory=directory,
            base_path=resolved_base_path,
            game_directory=game_directory
        )

        # Note: Attachments are no longer auto-loaded at initialization.
        # Use renderer.add_attachment("attachment-name") to load them dynamically.
        # The attachment metadata is available in renderer.attachment_library.

        return renderer


def sync_renderer_to_entry(renderer, entry):
    """Sync a RigRenderer's overlays and rig-attachments to match a scene entry.

    This is the shared implementation used by SceneDisplayable, SceneManager,
    and RigLab editors to keep a renderer's state in sync with a
    SceneCharacter or SceneAttachment entry.

    Args:
        renderer: A RigRenderer instance.
        entry: A SceneCharacter or SceneAttachment with overlays and rig_attachments lists.
    """
    # Sync overlays
    desired = set(entry.overlays)
    current = set(renderer.active_overlays)
    for name in current - desired:
        renderer.remove_overlay(name)
    for name in desired - current:
        if renderer.overlays.get(name):
            renderer.add_overlay(name)
    # Sync rig-attachments
    desired_att = set(entry.rig_attachments)
    current_att = set(renderer.attachment_instances.keys())
    for name in current_att - desired_att:
        renderer.remove_attachment(name)
    for name in desired_att - current_att:
        try:
            renderer.add_attachment(name)
        except (ValueError, Exception):
            pass


def _load_scene_rig_renderer(source, subdir, base_path, game_directory):
    """Load a RigRenderer for a scene-placed character or attachment.

    Args:
        source: Folder name (e.g. "vince").
        subdir: "characters" or "attachments".
        base_path: Scene base_path (absolute path to the scene dir).
        game_directory: Game directory for image resolution.

    Returns:
        RigRenderer or None.
    """
    # Determine the game directory from scene base_path
    # base_path is typically an absolute path like .../game/scenes/name
    # The game dir is two levels up from scenes/name
    gamedir = game_directory
    if not gamedir and base_path:
        candidate = os.path.dirname(os.path.dirname(base_path))
        if os.path.isdir(os.path.join(candidate, subdir)):
            gamedir = candidate

    if not gamedir:
        gamedir = renpy.config.gamedir

    rig_dir = os.path.join(gamedir, subdir, source)
    if not os.path.isdir(rig_dir):
        # Case-insensitive fallback: scan the subdir for a matching folder
        parent = os.path.join(gamedir, subdir)
        if os.path.isdir(parent):
            source_lower = source.lower()
            for entry in os.listdir(parent):
                if entry.lower() == source_lower and os.path.isdir(os.path.join(parent, entry)):
                    rig_dir = os.path.join(parent, entry)
                    break
            else:
                return None
        else:
            return None

    try:
        return RigRenderer.from_directory(rig_dir, game_directory=gamedir)
    except Exception as e:
        print("_load_scene_rig_renderer: failed to load {}/{}: {}".format(subdir, source, e))
        import traceback
        traceback.print_exc()
        return None


class SceneDisplayable(renpy.Displayable if RENPY_AVAILABLE else object):
    """
    A Ren'Py Displayable that renders scene content.

    Operates in three modes:
    - Full composite: background + all layers merged
    - Background only: just the background fill/image
    - Single layer: items from one named layer (transparent background)
    """

    def __init__(self, scene, mode="full", layer_name=None, game_directory="", apply_camera=True, items_only=False, **kwargs):
        """
        Args:
            scene: The Scene to render
            mode: "full" (all content), "background" (bg only), or "layer" (single layer)
            layer_name: Required when mode="layer"
            game_directory: External game directory for resolving image paths.
                When empty, falls back to renpy.config.gamedir.
            apply_camera: When True (default), crop output to scene.camera rect
                in full mode. Set False for editor canvas rendering.
            items_only: When True, only render overlay items on a layer,
                skipping characters and attachments (used by SceneManager
                which shows those separately for dynamic control).
        """
        _check_renpy()
        if RENPY_AVAILABLE:
            super().__init__(**kwargs)
        self._scene = scene
        self._mode = mode
        self._layer_name = layer_name
        self._game_directory = game_directory
        self._apply_camera = apply_camera
        self._items_only = items_only
        self._rig_cache = {}  # {("character"|"attachment", instance_name): RigRenderer}
        self._anim_cache = {}  # {instance_name: DynamicRig displayable}

    def _get_image(self, image_path):
        """Create an Image displayable for a path relative to scene directory."""
        full_path = image_path
        if self._scene.base_path:
            full_path = os.path.join(self._scene.base_path, image_path)
        full_path = full_path.replace("\\", "/")

        gamedir = (self._game_directory or renpy.config.gamedir).replace("\\", "/")
        if not gamedir.endswith("/"):
            gamedir += "/"
        if full_path.startswith(gamedir):
            full_path = full_path[len(gamedir):]

        return renpy.displayable(full_path)

    def _get_rig_renderer(self, instance_name, source, is_attachment=False):
        """Get a cached RigRenderer for a placed character/attachment."""
        key = ("attachment" if is_attachment else "character", instance_name)
        if key not in self._rig_cache:
            subdir = "attachments" if is_attachment else "characters"
            self._rig_cache[key] = _load_scene_rig_renderer(
                source, subdir, self._scene.base_path, self._game_directory)
        return self._rig_cache[key]

    def _apply_entry_state(self, renderer, entry):
        """Sync renderer overlays and rig-attachments to match entry state."""
        sync_renderer_to_entry(renderer, entry)

    def _get_entry_displayable(self, entry, renderer, st, at):
        """Return the appropriate displayable for an entry's current state."""
        if entry.animation and renderer.animations.get(entry.animation):
            cache_key = entry.name
            if cache_key not in self._anim_cache:
                self._anim_cache[cache_key] = renderer.play_animation(
                    entry.animation, loop=entry.animation_loop)
            return self._anim_cache[cache_key]
        return renderer.show_pose(entry.pose)

    def render(self, width, height, st, at):
        canvas_w = int(self._scene.canvas_size.x)
        canvas_h = int(self._scene.canvas_size.y)
        rv = renpy.Render(canvas_w, canvas_h)

        # Draw background (for "full" and "background" modes)
        if self._mode in ("full", "background"):
            bg = self._scene.background
            # Always render the background color
            color_disp = renpy.displayable(bg.color)
            color_render = renpy.render(color_disp, canvas_w, canvas_h, st, at)
            rv.blit(color_render, (0, 0))
            # Render background image on top if present
            if bg.image:
                img = self._get_image(bg.image)
                scaled = Transform(img, zoom=bg.image_scale)
                img_render = renpy.render(scaled, canvas_w, canvas_h, st, at)
                rv.blit(img_render, (bg.image_offset.x, bg.image_offset.y))

        # Draw all entries z-sorted (for "full" and "layer" modes)
        if self._mode in ("full", "layer"):
            layer_filter = self._layer_name if self._mode == "layer" else None

            # Build combined z-sorted list
            entries = []
            for eff_z, item in self._scene.get_sorted_items(layer_name=layer_filter):
                entries.append((eff_z, "item", item))
            if not self._items_only:
                for eff_z, ch in self._scene.get_sorted_characters(layer_name=layer_filter):
                    entries.append((eff_z, "character", ch))
                for eff_z, att in self._scene.get_sorted_attachments(layer_name=layer_filter):
                    entries.append((eff_z, "attachment", att))
            entries.sort(key=lambda x: x[0])

            for _z, entry_type, entry in entries:
                if entry_type == "item":
                    img = self._get_image(entry.image)
                    item_render = renpy.render(
                        Transform(img,
                                  xzoom=entry.scale.x,
                                  yzoom=entry.scale.y,
                                  rotate=entry.rotation if entry.rotation != 0 else None),
                        canvas_w, canvas_h, st, at
                    )
                    rv.blit(item_render, (entry.pos.x, entry.pos.y))
                elif entry_type in ("character", "attachment"):
                    is_att = (entry_type == "attachment")
                    renderer = self._get_rig_renderer(entry.name, entry.source, is_attachment=is_att)
                    if renderer:
                        self._apply_entry_state(renderer, entry)
                        disp = self._get_entry_displayable(entry, renderer, st, at)
                        rot = entry.rotation if entry.rotation != 0 else None
                        scaled = Transform(disp,
                                           xzoom=entry.scale.x,
                                           yzoom=entry.scale.y,
                                           rotate=rot)
                        rig_render = renpy.render(scaled, canvas_w, canvas_h, st, at)
                        root_x, root_y = renderer.get_root_canvas_pos()
                        rig_cw = float(renderer.rig.canvas_size.x)
                        rig_ch = float(renderer.rig.canvas_size.y)
                        asx, asy = abs(entry.scale.x), abs(entry.scale.y)
                        rx = root_x * asx if entry.scale.x >= 0 else (rig_cw - root_x) * asx
                        ry = root_y * asy if entry.scale.y >= 0 else (rig_ch - root_y) * asy
                        # When rotated, the render's bounding box grows.
                        # Offset by half the size difference so the root stays centred.
                        rw, rh = rig_render.get_size()
                        scaled_w = rig_cw * asx
                        scaled_h = rig_ch * asy
                        rot_dx = (rw - scaled_w) / 2.0
                        rot_dy = (rh - scaled_h) / 2.0
                        rv.blit(rig_render, (entry.pos.x - rx - rot_dx,
                                             entry.pos.y - ry - rot_dy))

        # Camera cropping: extract the camera viewport from the full canvas
        # Use subsurface() which properly clips content to the requested rect.
        if (self._apply_camera and self._mode == "full"
                and self._scene.camera is not None):
            cam_x, cam_y, cam_w, cam_h = self._scene.camera
            # Clamp to canvas bounds to avoid out-of-range subsurface
            cx = max(0, int(cam_x))
            cy = max(0, int(cam_y))
            cw = min(int(cam_w), canvas_w - cx)
            ch = min(int(cam_h), canvas_h - cy)
            if cw > 0 and ch > 0:
                return rv.subsurface((cx, cy, cw, ch))

        return rv

    def visit(self):
        children = []
        bg = self._scene.background
        if bg.image and self._mode in ("full", "background"):
            children.append(self._get_image(bg.image))
        if self._mode in ("full", "layer"):
            for item in self._scene.items:
                if self._layer_name is None or item.layer == self._layer_name:
                    children.append(self._get_image(item.image))
        return children

    def event(self, ev, x, y, st):
        return None


class SceneRenderer:
    """High-level API wrapping SceneDisplayable for convenient scene rendering."""

    def __init__(self, scene, game_directory=""):
        _check_renpy()
        self.scene = scene
        self.game_directory = game_directory

    def show(self):
        """Full composite (all layers baked in), cropped to camera if set."""
        return SceneDisplayable(self.scene, mode="full",
                                game_directory=self.game_directory)

    def show_full_canvas(self):
        """Full composite without camera cropping (for editor use)."""
        return SceneDisplayable(self.scene, mode="full",
                                game_directory=self.game_directory,
                                apply_camera=False)

    def show_background(self):
        """Background image/color only."""
        return SceneDisplayable(self.scene, mode="background",
                                game_directory=self.game_directory)

    def show_layer(self, name, items_only=False):
        """Single layer's items (transparent background).

        Args:
            name: Layer name.
            items_only: When True, only render overlay items, skipping
                characters and attachments.
        """
        return SceneDisplayable(self.scene, mode="layer", layer_name=name,
                                game_directory=self.game_directory,
                                items_only=items_only)

    @classmethod
    def from_directory(cls, path, base_path="", game_directory=""):
        """Create a SceneRenderer by loading scene.json from a directory."""
        from .io import load_scene
        scene_json = os.path.join(path, "scene.json")
        scene = load_scene(scene_json, base_path)
        return cls(scene, game_directory=game_directory)


class SceneActionPlayer(ActionStepper):
    """Plays a SceneAction by dispatching commands to a SceneManager.

    Inherits track-stepping logic from ActionStepper. Implements
    _execute_step() to perform Ren'Py-specific side effects.
    """

    def __init__(self, action, scene_manager):
        """
        Args:
            action: The SceneAction to play.
            scene_manager: The SceneManager that owns the displayed scene.
        """
        super().__init__(action)
        self._mgr = scene_manager

    def _execute_step(self, step, on_done):
        """Route a step to the appropriate Ren'Py dispatch handler."""
        action = step.action
        if action == "play_animation":
            self._dispatch_play_animation(step, on_done)
        elif action == "set_pose":
            self._dispatch_set_pose(step)
        elif action == "set_background":
            self._dispatch_set_background(step)
        elif action == "play_sound":
            self._dispatch_play_sound(step)
        elif action == "set_overlay":
            self._dispatch_set_overlay(step)
        elif action == "set_visible":
            self._dispatch_set_visible(step)
        elif action == "remove":
            self._dispatch_remove(step)
        elif action == "add":
            self._dispatch_add(step)

    def _dispatch_play_animation(self, step, on_done):
        """Play an animation on a target object and re-show its displayable."""
        target = step.target
        params = step.params
        anim_name = params.get("animation", "")
        loop = params.get("loop", False)

        renderer = self._mgr._rig_renderers.get(target)
        if not renderer:
            return
        if anim_name not in renderer.animations.animations:
            return

        # If waiting, wire up the completion callback
        cb = on_done if step.wait else None
        disp = renderer.play_animation(anim_name, loop=loop, on_complete=cb)

        # Re-show the tag with the new displayable
        cam_x, cam_y = self._mgr._cam_offset
        entry, eff_z = self._mgr._get_entry_and_z(target)
        if entry:
            tag = self._mgr._get_tag_for_entry(target, entry)
            root_x, root_y = renderer.get_root_canvas_pos()
            e_rot = entry.rotation if entry.rotation != 0 else None
            placed = Transform(disp,
                               xzoom=entry.scale.x, yzoom=entry.scale.y,
                               rotate=e_rot,
                               xpos=int(entry.pos.x) - cam_x,
                               ypos=int(entry.pos.y) - cam_y,
                               xanchor=int(root_x), yanchor=int(root_y),
                               transform_anchor=True)
            renpy.show(tag, what=placed, zorder=eff_z)

    def _dispatch_set_pose(self, step):
        """Set a static pose on a target and re-show."""
        target = step.target
        pose_name = step.params.get("pose", "neutral")

        renderer = self._mgr._rig_renderers.get(target)
        if not renderer:
            return

        cam_x, cam_y = self._mgr._cam_offset
        disp = renderer.show_pose(pose_name)
        entry, eff_z = self._mgr._get_entry_and_z(target)
        if entry:
            tag = self._mgr._get_tag_for_entry(target, entry)
            root_x, root_y = renderer.get_root_canvas_pos()
            e_rot = entry.rotation if entry.rotation != 0 else None
            placed = Transform(disp,
                               xzoom=entry.scale.x, yzoom=entry.scale.y,
                               rotate=e_rot,
                               xpos=int(entry.pos.x) - cam_x,
                               ypos=int(entry.pos.y) - cam_y,
                               xanchor=int(root_x), yanchor=int(root_y),
                               transform_anchor=True)
            renpy.show(tag, what=placed, zorder=eff_z)

    def _dispatch_set_background(self, step):
        """Swap the scene background image."""
        scene = self._mgr._scene_data
        if not scene:
            return
        image_path = step.params.get("image")
        transition_ms = step.params.get("transition_ms", 0)

        if image_path is not None:
            scene.background.image = image_path

        # Re-show background
        cam_x, cam_y = self._mgr._cam_offset
        bg_renderer = SceneRenderer(scene, game_directory="")
        bg_disp = bg_renderer.show_background()
        bg_placed = Transform(bg_disp, xpos=-cam_x, ypos=-cam_y, xanchor=0, yanchor=0)

        if transition_ms > 0 and RENPY_AVAILABLE:
            renpy.show("_scene_bg", what=bg_placed, zorder=-999)
            renpy.with_statement(renpy.store.Dissolve(transition_ms / 1000.0))
        else:
            renpy.show("_scene_bg", what=bg_placed, zorder=-999)

    def _dispatch_play_sound(self, step):
        """Play a sound effect."""
        path = step.params.get("path", "")
        channel = step.params.get("channel", CHANNEL_SFX_PREFIX + "0")
        scene = self._mgr._scene_data
        base_path = scene.base_path if scene else ""
        if path:
            play_sound(path, channel, loop=False, base_path=base_path)

    def _dispatch_set_overlay(self, step):
        """Toggle an overlay on a target object."""
        target = step.target
        overlay_name = step.params.get("overlay", "")
        active = step.params.get("active", True)

        renderer = self._mgr._rig_renderers.get(target)
        if not renderer:
            return

        if active:
            if renderer.overlays.get(overlay_name):
                renderer.add_overlay(overlay_name)
        else:
            renderer.remove_overlay(overlay_name)

    def _dispatch_set_visible(self, step):
        """Show or hide a target object."""
        target = step.target
        visible = step.params.get("visible", True)

        entry, eff_z = self._mgr._get_entry_and_z(target)
        if not entry:
            return

        tag = self._mgr._get_tag_for_entry(target, entry)
        if visible:
            cam_x, cam_y = self._mgr._cam_offset
            renderer = self._mgr._rig_renderers.get(target)
            if renderer:
                disp = renderer.show_pose(getattr(entry, "pose", "neutral"))
                e_rot = entry.rotation if entry.rotation != 0 else None
                placed = Transform(disp,
                                   xzoom=entry.scale.x, yzoom=entry.scale.y,
                                   rotate=e_rot,
                                   xpos=int(entry.pos.x) - cam_x,
                                   ypos=int(entry.pos.y) - cam_y,
                                   xanchor=0, yanchor=0)
                renpy.show(tag, what=placed, zorder=eff_z)
        else:
            renpy.hide(tag)

    def _dispatch_remove(self, step):
        """Remove a target object from the displayed scene."""
        self._mgr.remove_entry(step.target)

    def _dispatch_add(self, step):
        """Add a new object to the displayed scene at runtime."""
        params = step.params
        obj_type = params.get("type", "attachment")
        source = params.get("source", step.target)
        layer = params.get("layer", FOCUS_LAYER_NAME)
        pos = params.get("pos", [0, 0])
        scale = params.get("scale", [1.0, 1.0])
        if obj_type == "attachment":
            self._mgr.add_attachment(step.target, source, pos=pos, scale=scale, layer=layer)
        else:
            self._mgr.add_character(step.target, source, pos=pos, scale=scale, layer=layer)


class SceneManager:
    """
    Manages scene display within Ren'Py's image system.

    Handles showing/hiding scene layers as separate Ren'Py images at
    appropriate z-orders, enabling character interleaving. Also handles
    scheduled action playback and animation broadcasting.
    """

    def __init__(self, scenes_dir):
        """
        Scan scenes_dir for available scenes.

        Args:
            scenes_dir: Absolute path to the scenes directory
        """
        _check_renpy()
        self._scenes_dir = scenes_dir
        self._current = None
        self._shown_tags = []
        self._rig_renderers = {}   # {instance_name: RigRenderer}
        self._scene_data = None    # Current Scene object
        self._action_player = None  # Current SceneActionPlayer
        self._tween_mgr = None     # TweenManager for entrance tweens (lazy-init)
        self._cam_offset = (0, 0)  # Camera x/y offset for scene positioning

    def _get_renderer(self, scene_name):
        """Create a SceneRenderer for a scene."""
        scene_path = os.path.join(self._scenes_dir, scene_name)
        return SceneRenderer.from_directory(scene_path)

    def _apply_rig_state(self, renderer, entry):
        """Sync renderer overlays and rig-attachments to match entry state."""
        sync_renderer_to_entry(renderer, entry)

    def _get_entry_and_z(self, instance_name):
        """Look up a scene entry (character or attachment) by instance name.

        Returns:
            (entry, effective_z) tuple, or (None, 0) if not found.
        """
        scene = self._scene_data
        if not scene:
            return None, 0
        for ch in scene.characters:
            if ch.name == instance_name:
                layer = scene.layers.get(ch.layer)
                layer_z = layer.z if layer else 0
                return ch, layer_z + ch.z_offset
        for att in scene.attachments:
            if att.name == instance_name:
                layer = scene.layers.get(att.layer)
                layer_z = layer.z if layer else 0
                return att, layer_z + att.z_offset
        return None, 0

    def _get_tag_for_entry(self, instance_name, entry):
        """Get the Ren'Py image tag for a scene entry."""
        if isinstance(entry, SceneCharacter):
            return "_scene_char_" + instance_name
        elif isinstance(entry, SceneAttachment):
            return "_scene_att_" + instance_name
        return "_scene_" + instance_name

    def show(self, scene_name, transition=None, skip_on_show=False):
        """
        Show a scene with layer-separated z-ordering.

        1. Calls renpy.scene() to clear existing images
        2. Shows background as '_scene_bg' at zorder -999
        3. Shows each non-empty layer as '_scene_{layer_name}' at the layer's z value
        4. Shows placed characters and attachments as separate images
        5. Applies transition if provided
        6. Auto-plays "on_show" scheduled action if defined
        """
        renderer = self._get_renderer(scene_name)
        scene = renderer.scene

        # Clear all existing images
        renpy.scene()

        tags = []
        self._rig_renderers = {}
        self._scene_data = scene

        # Camera offset — shift all elements so the camera viewport
        # aligns with the top-left of the Ren'Py screen.
        cam_x, cam_y = 0, 0
        if scene.camera is not None:
            cam_x, cam_y = int(scene.camera[0]), int(scene.camera[1])
        self._cam_offset = (cam_x, cam_y)

        # Show background — anchor at top-left so canvas coordinates
        # match across all separately-shown elements.
        bg_tag = "_scene_bg"
        bg_placed = Transform(renderer.show_background(),
                              xpos=-cam_x, ypos=-cam_y, xanchor=0, yanchor=0)
        renpy.show(bg_tag, what=bg_placed, zorder=-999)
        tags.append(bg_tag)

        # Show each layer that has items (overlay images only —
        # characters and attachments are shown separately below for
        # dynamic control via SceneManager APIs).
        for layer_name, layer in scene.layers.items():
            layer_items = scene.get_items_for_layer(layer_name)
            if layer_items:
                layer_tag = "_scene_" + layer_name
                layer_placed = Transform(renderer.show_layer(layer_name, items_only=True),
                                         xpos=-cam_x, ypos=-cam_y, xanchor=0, yanchor=0)
                renpy.show(layer_tag, what=layer_placed, zorder=layer.z)
                tags.append(layer_tag)

        # Show placed characters
        for ch in scene.characters:
            layer = scene.layers.get(ch.layer)
            layer_z = layer.z if layer else 0
            eff_z = layer_z + ch.z_offset

            rig_renderer = _load_scene_rig_renderer(
                ch.source, "characters", scene.base_path, "")
            if rig_renderer:
                self._rig_renderers[ch.name] = rig_renderer
                self._apply_rig_state(rig_renderer, ch)
                if ch.animation and ch.animation in rig_renderer.animations.animations:
                    disp = rig_renderer.play_animation(ch.animation, loop=ch.animation_loop)
                else:
                    disp = rig_renderer.show_pose(ch.pose)
                root_x, root_y = rig_renderer.get_root_canvas_pos()
                ch_rot = ch.rotation if ch.rotation != 0 else None
                placed = Transform(disp,
                                   xzoom=ch.scale.x, yzoom=ch.scale.y,
                                   rotate=ch_rot,
                                   xpos=int(ch.pos.x) - cam_x,
                                   ypos=int(ch.pos.y) - cam_y,
                                   xanchor=int(root_x), yanchor=int(root_y),
                                   transform_anchor=True)
                ch_tag = "_scene_char_" + ch.name
                renpy.show(ch_tag, what=placed, zorder=eff_z)
                tags.append(ch_tag)

        # Show placed attachments
        for att in scene.attachments:
            layer = scene.layers.get(att.layer)
            layer_z = layer.z if layer else 0
            eff_z = layer_z + att.z_offset

            rig_renderer = _load_scene_rig_renderer(
                att.source, "attachments", scene.base_path, "")
            if rig_renderer:
                self._rig_renderers[att.name] = rig_renderer
                self._apply_rig_state(rig_renderer, att)
                if att.animation and att.animation in rig_renderer.animations.animations:
                    disp = rig_renderer.play_animation(att.animation, loop=att.animation_loop)
                else:
                    disp = rig_renderer.show_pose(att.pose)
                root_x, root_y = rig_renderer.get_root_canvas_pos()
                att_rot = att.rotation if att.rotation != 0 else None
                placed = Transform(disp,
                                   xzoom=att.scale.x, yzoom=att.scale.y,
                                   rotate=att_rot,
                                   xpos=int(att.pos.x) - cam_x,
                                   ypos=int(att.pos.y) - cam_y,
                                   xanchor=int(root_x), yanchor=int(root_y),
                                   transform_anchor=True)
                att_tag = "_scene_att_" + att.name
                renpy.show(att_tag, what=placed, zorder=eff_z)
                tags.append(att_tag)

        self._shown_tags = tags
        self._current = scene_name

        # Apply camera crop and scale to the master layer.
        # The effective viewport is the camera rect when defined, or the
        # full canvas otherwise.  Crop clips content to this viewport,
        # then scale stretches it to fill the game screen.
        # Two separate Transforms because crop+zoom on a single
        # Transform produces wrong coordinates (Ren'Py applies zoom
        # before crop).
        if scene.camera is not None:
            cam_w_i = int(scene.camera[2])
            cam_h_i = int(scene.camera[3])
        else:
            cam_w_i = int(scene.canvas_size.x)
            cam_h_i = int(scene.canvas_size.y)
        screen_w = renpy.config.screen_width
        screen_h = renpy.config.screen_height
        if cam_w_i != screen_w or cam_h_i != screen_h:
            sx = screen_w / float(cam_w_i)
            sy = screen_h / float(cam_h_i)
            renpy.show_layer_at([
                Transform(crop=(0, 0, cam_w_i, cam_h_i)),
                Transform(xzoom=sx, yzoom=sy),
            ], layer='master')

        # Play scene ambient sound
        if scene.sound:
            play_sound(scene.sound, CHANNEL_SCENE, loop=scene.sound_loop,
                       base_path=scene.base_path)
        else:
            stop_channel(CHANNEL_SCENE)

        if transition is not None:
            renpy.with_statement(transition)

        # Auto-play "on_show" scheduled action if defined
        if not skip_on_show and "on_show" in scene.actions:
            self.play("on_show")

    def hide(self, transition=None):
        """Hide all scene layers."""
        for tag in self._shown_tags:
            renpy.hide(tag)
        self._shown_tags = []
        self._current = None
        self._rig_renderers = {}
        self._scene_data = None
        self._action_player = None
        # Clear any camera crop applied to the master layer
        renpy.show_layer_at([], layer='master')
        stop_channel(CHANNEL_SCENE)
        if transition is not None:
            renpy.with_statement(transition)

    def play(self, name, on_complete=None):
        """Play a named action OR broadcast an animation to all matching objects.

        If ``name`` matches a scheduled action defined on the current scene,
        that action is played (all tracks run in parallel, steps execute
        sequentially within each track).

        Otherwise, ``name`` is treated as an animation name and is broadcast
        to every character and attachment in the scene whose AnimationLibrary
        contains that animation.

        Args:
            name: SceneAction name or animation name to broadcast.
            on_complete: Optional callback invoked when all triggered
                animations/actions finish.
        """
        scene = self._scene_data
        if not scene:
            return

        # Check for a scheduled action first
        if name in scene.actions:
            action = scene.actions[name]
            self._action_player = SceneActionPlayer(action, self)
            self._action_player.start(on_complete=on_complete)
            # Show a transparent ticker screen to drive ticks
            renpy.show_screen("_scene_action_tick", player=self._action_player)
            return

        # Broadcast: play animation on every object that has it
        pending = [0]  # mutable counter for outstanding completions
        all_started = [False]

        def _check_all_done():
            pending[0] -= 1
            if pending[0] <= 0 and all_started[0] and on_complete:
                on_complete()

        any_played = False
        for inst_name, renderer in self._rig_renderers.items():
            if name in renderer.animations.animations:
                pending[0] += 1
                disp = renderer.play_animation(name, loop=False, on_complete=_check_all_done)
                entry, eff_z = self._get_entry_and_z(inst_name)
                if entry:
                    tag = self._get_tag_for_entry(inst_name, entry)
                    e_rot = entry.rotation if entry.rotation != 0 else None
                    placed = Transform(disp,
                                       xzoom=entry.scale.x, yzoom=entry.scale.y,
                                       rotate=e_rot,
                                       xpos=int(entry.pos.x), ypos=int(entry.pos.y),
                                       xanchor=0, yanchor=0)
                    renpy.show(tag, what=placed, zorder=eff_z)
                any_played = True

        all_started[0] = True

        # If nothing was played, fire callback immediately
        if not any_played and on_complete:
            on_complete()
        # If all already completed synchronously (unlikely but safe)
        elif pending[0] <= 0 and on_complete:
            on_complete()

    def list_actions(self, scene_name=None):
        """Return list of scheduled action names for the current (or named) scene.

        Args:
            scene_name: Scene to query. If None, uses the currently shown scene.

        Returns:
            List of action name strings.
        """
        name = scene_name or self._current
        if not name:
            return []
        if self._scene_data and self._scene_data.name == name:
            return list(self._scene_data.actions.keys())
        renderer = self._get_renderer(name)
        return list(renderer.scene.actions.keys())

    def get_action(self, name, scene_name=None):
        """Return a SceneAction by name.

        Args:
            name: The action name.
            scene_name: Scene to query. If None, uses the currently shown scene.

        Returns:
            SceneAction or None.
        """
        sn = scene_name or self._current
        if not sn:
            return None
        if self._scene_data and self._scene_data.name == sn:
            return self._scene_data.actions.get(name)
        renderer = self._get_renderer(sn)
        return renderer.scene.actions.get(name)

    def get_characters(self, scene_name=None):
        """Get the list of SceneCharacter entries from a scene.

        Args:
            scene_name: Scene to query. If None, uses the currently shown scene.

        Returns:
            List of SceneCharacter objects, or empty list.
        """
        name = scene_name or self._current
        if not name:
            return []
        renderer = self._get_renderer(name)
        return list(renderer.scene.characters)

    def get_attachments(self, scene_name=None):
        """Get the list of SceneAttachment entries from a scene.

        Args:
            scene_name: Scene to query. If None, uses the currently shown scene.

        Returns:
            List of SceneAttachment objects, or empty list.
        """
        name = scene_name or self._current
        if not name:
            return []
        renderer = self._get_renderer(name)
        return list(renderer.scene.attachments)

    def play_and_wait(self, name):
        """Play an action and block Ren'Py script execution until it completes.

        Uses ``call screen`` internally, so this must be called from a
        Ren'Py label context (not from ``init python``).

        After the action finishes, any non-looping animations are replaced
        with a static displayable of their final pose so the end state
        persists reliably across Ren'Py interactions.

        Args:
            name: SceneAction name or animation name to broadcast.
        """
        self.play(name)
        if self._action_player and self._action_player.is_playing:
            renpy.call_screen("_scene_action_wait", player=self._action_player)

        # Freeze non-looping animations to their final pose as static
        # displayables.  DynamicRig can lose its visual state across
        # Ren'Py interactions; re-showing a static pose guarantees the
        # end state persists.
        scene = self._scene_data
        if scene and name in scene.actions:
            action = scene.actions[name]
            for track in action.tracks:
                for step in track.steps:
                    if step.action != "play_animation":
                        continue
                    loop = step.params.get("loop", False)
                    if loop:
                        continue
                    anim_name = step.params.get("animation", "")
                    renderer = self._rig_renderers.get(step.target)
                    if not renderer:
                        continue
                    anim = renderer.animations.get(anim_name)
                    if not anim or not anim.frames:
                        continue
                    last_pose_name = anim.frames[-1].pose
                    disp = renderer.show_pose(last_pose_name)
                    self._reshow_entry(step.target, disp)

    def get_rig_renderer(self, instance_name):
        """Return the RigRenderer for a scene character/attachment by instance name.

        Args:
            instance_name: The character or attachment instance name in the scene.

        Returns:
            RigRenderer or None if not found.
        """
        return self._rig_renderers.get(instance_name)

    def _reshow_entry(self, instance_name, displayable, flip_h=False):
        """Re-show a scene entry with a new displayable.

        Extracts camera offset, entry position/scale, and root canvas pos
        to build a correctly placed Transform, then calls renpy.show().

        Args:
            instance_name: Character or attachment instance name.
            displayable: The new Ren'Py displayable to show.
            flip_h: If True, flip horizontally by negating xzoom.
        """
        cam_x, cam_y = self._cam_offset
        entry, eff_z = self._get_entry_and_z(instance_name)
        if not entry:
            return
        renderer = self._rig_renderers.get(instance_name)
        if not renderer:
            return
        tag = self._get_tag_for_entry(instance_name, entry)
        root_x, root_y = renderer.get_root_canvas_pos()
        xz = -entry.scale.x if flip_h else entry.scale.x
        rot = entry.rotation if entry.rotation != 0 else None
        placed = Transform(displayable,
                           xzoom=xz, yzoom=entry.scale.y,
                           rotate=rot,
                           xpos=int(entry.pos.x) - cam_x,
                           ypos=int(entry.pos.y) - cam_y,
                           xanchor=int(root_x), yanchor=int(root_y),
                           transform_anchor=True)
        renpy.show(tag, what=placed, zorder=eff_z)

    def play_character_animation(self, instance_name, animation_name,
                                 loop=False, flip_h=False, on_complete=None):
        """Play an animation on a specific scene character or attachment.

        Args:
            instance_name: Character or attachment instance name.
            animation_name: Name of the animation to play.
            loop: Whether to loop the animation.
            flip_h: If True, flip the character horizontally.
            on_complete: Optional callback when animation finishes.
        """
        renderer = self._rig_renderers.get(instance_name)
        if not renderer:
            return
        if animation_name not in renderer.animations.animations:
            return
        disp = renderer.play_animation(animation_name, loop=loop,
                                        on_complete=on_complete)
        self._reshow_entry(instance_name, disp, flip_h=flip_h)

    def set_character_overlay(self, instance_name, overlay_name, active=True):
        """Toggle an overlay on a scene character or attachment.

        No re-show needed — DynamicRig reads overlay state each frame.

        Args:
            instance_name: Character or attachment instance name.
            overlay_name: Name of the overlay.
            active: True to add, False to remove.
        """
        renderer = self._rig_renderers.get(instance_name)
        if not renderer:
            return
        if active:
            renderer.add_overlay(overlay_name)
        else:
            renderer.remove_overlay(overlay_name)

    def set_character_attachment(self, instance_name, attachment_name, active=True):
        """Add or remove a rig-attachment on a scene character.

        No re-show needed — DynamicRig reads attachment state each frame.

        Args:
            instance_name: Character or attachment instance name.
            attachment_name: Name of the rig-attachment.
            active: True to add, False to remove.
        """
        renderer = self._rig_renderers.get(instance_name)
        if not renderer:
            return
        if active:
            renderer.add_attachment(attachment_name)
        else:
            renderer.remove_attachment(attachment_name)

    def set_character_outline(self, instance_name, color=None, width=None, alpha=None):
        """Set outline properties on a scene character or attachment.

        Args:
            instance_name: Character or attachment instance name.
            color: Outline color string (e.g. "#ffff00"), or None to clear.
            width: Outline width in pixels.
            alpha: Outline alpha (0.0-1.0).
        """
        renderer = self._rig_renderers.get(instance_name)
        if not renderer:
            return
        renderer.outline_color = color
        if width is not None:
            renderer.outline_width = width
        if alpha is not None:
            renderer.outline_alpha = alpha

    def add_character(self, instance_name, source, pos=None, scale=None,
                      layer=None, z_offset=0, pose="neutral", rotation=0.0,
                      at=None, from_=None, duration_ms=500, ease="ease_out"):
        """Add a character to the currently displayed scene at runtime.

        Args:
            instance_name: Unique instance ID (e.g. "guard", "guard_2").
            source: Folder name under characters/ (e.g. "vince").
            pos: (x, y) tuple or Vec2 for position. Defaults to (0, 0).
            scale: (x, y) tuple or Vec2 for scale. Defaults to (1, 1).
            layer: Layer name. Defaults to FOCUS_LAYER_NAME.
            z_offset: Z-offset within the layer.
            pose: Initial pose name.
            rotation: Initial rotation in degrees.
            at: Location name to place the character at.
            from_: Location name to tween from (entrance animation).
            duration_ms: Duration of entrance tween in milliseconds.
            ease: Easing function name for entrance tween.

        Returns:
            SceneCharacter entry, or None on failure.
        """
        pos, layer, z_offset, start_pos = self._resolve_location_params(
            pos, layer, z_offset, at, from_)
        entry = self._add_rig_entry(
            instance_name, source, "characters", SceneCharacter,
            "_scene_char_", pos, scale, layer, z_offset, pose, rotation)
        if entry and start_pos is not None:
            self._tween_to_pos(instance_name, start_pos, pos, duration_ms, ease)
        return entry

    def add_attachment(self, instance_name, source, pos=None, scale=None,
                       layer=None, z_offset=0, pose="neutral", rotation=0.0,
                       at=None, from_=None, duration_ms=500, ease="ease_out"):
        """Add an attachment to the currently displayed scene at runtime.

        Args:
            instance_name: Unique instance ID.
            source: Folder name under attachments/.
            pos: (x, y) tuple or Vec2 for position. Defaults to (0, 0).
            scale: (x, y) tuple or Vec2 for scale. Defaults to (1, 1).
            layer: Layer name. Defaults to FOCUS_LAYER_NAME.
            z_offset: Z-offset within the layer.
            pose: Initial pose name.
            rotation: Initial rotation in degrees.
            at: Location name to place the attachment at.
            from_: Location name to tween from (entrance animation).
            duration_ms: Duration of entrance tween in milliseconds.
            ease: Easing function name for entrance tween.

        Returns:
            SceneAttachment entry, or None on failure.
        """
        pos, layer, z_offset, start_pos = self._resolve_location_params(
            pos, layer, z_offset, at, from_)
        entry = self._add_rig_entry(
            instance_name, source, "attachments", SceneAttachment,
            "_scene_att_", pos, scale, layer, z_offset, pose, rotation)
        if entry and start_pos is not None:
            self._tween_to_pos(instance_name, start_pos, pos, duration_ms, ease)
        return entry

    def _add_rig_entry(self, instance_name, source, subdir, entry_cls,
                       tag_prefix, pos, scale, layer, z_offset, pose, rotation):
        """Internal: add a character or attachment entry and show it.

        Returns:
            The created entry, or None on failure.
        """
        scene = self._scene_data
        if not scene:
            return None

        if layer is None:
            layer = FOCUS_LAYER_NAME

        # Normalize pos/scale to Vec2
        if pos is None:
            pos = Vec2(0.0, 0.0)
        elif not isinstance(pos, Vec2):
            pos = Vec2(float(pos[0]), float(pos[1]))
        if scale is None:
            scale = Vec2(1.0, 1.0)
        elif not isinstance(scale, Vec2):
            scale = Vec2(float(scale[0]), float(scale[1]))

        # Replace if already exists
        self.remove_entry(instance_name)

        # Create scene data entry
        entry = entry_cls(
            name=instance_name,
            source=source,
            layer=layer,
            pos=pos,
            scale=scale,
            rotation=rotation,
            z_offset=z_offset,
            pose=pose,
        )
        if entry_cls is SceneCharacter:
            scene.characters.append(entry)
        else:
            scene.attachments.append(entry)

        # Load renderer
        rig_renderer = _load_scene_rig_renderer(source, subdir, scene.base_path, "")
        if not rig_renderer:
            # Clean up the entry we just added
            if entry_cls is SceneCharacter:
                scene.characters.remove(entry)
            else:
                scene.attachments.remove(entry)
            return None

        self._rig_renderers[instance_name] = rig_renderer
        self._apply_rig_state(rig_renderer, entry)
        disp = rig_renderer.show_pose(pose)

        # Build placed Transform and show
        cam_x, cam_y = self._cam_offset
        root_x, root_y = rig_renderer.get_root_canvas_pos()
        layer_obj = scene.layers.get(layer)
        layer_z = layer_obj.z if layer_obj else 0
        eff_z = layer_z + z_offset

        ent_rot = rotation if rotation != 0 else None
        placed = Transform(disp,
                           xzoom=scale.x, yzoom=scale.y,
                           rotate=ent_rot,
                           xpos=int(pos.x) - cam_x,
                           ypos=int(pos.y) - cam_y,
                           xanchor=int(root_x), yanchor=int(root_y),
                           transform_anchor=True)
        tag = tag_prefix + instance_name
        renpy.show(tag, what=placed, zorder=eff_z)
        self._shown_tags.append(tag)

        return entry

    def _resolve_location_params(self, pos, layer, z_offset, at, from_):
        """Resolve location-based placement parameters.

        Returns:
            (pos, layer, z_offset, start_pos) tuple.
            start_pos is None if no entrance tween needed.
        """
        scene = self._scene_data
        start_pos = None

        if at is not None and scene:
            loc = scene.get_location(at)
            if loc:
                pos = Vec2(loc.pos.x, loc.pos.y)
                layer = loc.layer
                z_offset = loc.z_offset
        elif pos is None and scene:
            # Default to stage-center if no position given
            loc = scene.get_location("stage-center")
            if loc:
                pos = Vec2(loc.pos.x, loc.pos.y)
                layer = loc.layer
                z_offset = loc.z_offset

        if from_ is not None and scene:
            from_loc = scene.get_location(from_)
            if from_loc:
                start_pos = Vec2(from_loc.pos.x, from_loc.pos.y)

        return pos, layer, z_offset, start_pos

    def _ensure_tween_mgr(self):
        """Lazy-create TweenManager for entrance tweens."""
        if self._tween_mgr is None:
            from .clip import TweenManager
            self._tween_mgr = TweenManager(apply_callback=self._apply_scene_tween)
        return self._tween_mgr

    def _apply_scene_tween(self, target, prop, value):
        """Apply a tween value to a scene entry."""
        if prop == "pos":
            entry, eff_z = self._get_entry_and_z(target)
            if not entry:
                return
            entry.pos = value
            renderer = self._rig_renderers.get(target)
            if not renderer:
                return

            cam_x, cam_y = self._cam_offset
            tag = self._get_tag_for_entry(target, entry)
            root_x, root_y = renderer.get_root_canvas_pos()

            disp = renderer.get_current_displayable()
            if not disp:
                disp = renderer.show_pose(getattr(entry, "pose", "neutral"))

            e_rot = entry.rotation if entry.rotation != 0 else None
            placed = Transform(disp,
                               xzoom=entry.scale.x, yzoom=entry.scale.y,
                               rotate=e_rot,
                               xpos=int(value.x) - cam_x,
                               ypos=int(value.y) - cam_y,
                               xanchor=int(root_x), yanchor=int(root_y),
                               transform_anchor=True)
            renpy.show(tag, what=placed, zorder=eff_z)

    def _tween_to_pos(self, instance_name, start_pos, end_pos, duration_ms, ease_str):
        """Start a position tween for a scene entry (entrance animation)."""
        import time
        from .clip import Tween, _parse_ease

        tween_mgr = self._ensure_tween_mgr()

        # Place at start position first
        self._apply_scene_tween(instance_name, "pos", start_pos)

        ease = _parse_ease(ease_str)
        tween = Tween(
            target=instance_name, prop="pos",
            start_value=start_pos, end_value=end_pos,
            duration_ms=duration_ms, ease=ease,
            start_time=time.time(),
        )
        tween_mgr.add(tween)

        # Show tick screen to drive the tween
        renpy.show_screen("_scene_move_tick", tween_mgr=tween_mgr)

    def remove_entry(self, instance_name):
        """Remove a character or attachment from the displayed scene.

        Hides the Ren'Py image, removes the scene data entry, and cleans
        up the rig renderer.

        Args:
            instance_name: Character or attachment instance name.

        Returns:
            True if the entry was found and removed, False otherwise.
        """
        entry, eff_z = self._get_entry_and_z(instance_name)
        if not entry:
            return False

        tag = self._get_tag_for_entry(instance_name, entry)
        renpy.hide(tag)
        if tag in self._shown_tags:
            self._shown_tags.remove(tag)

        scene = self._scene_data
        if scene:
            if isinstance(entry, SceneCharacter):
                scene.characters = [ch for ch in scene.characters if ch.name != instance_name]
            elif isinstance(entry, SceneAttachment):
                scene.attachments = [att for att in scene.attachments if att.name != instance_name]

        self._rig_renderers.pop(instance_name, None)
        return True

    def move_entry(self, instance_name, pos=None, scale=None, rotation=None):
        """Move, scale, or rotate a scene entry and re-show it.

        Only mutates the fields that are not None.

        Args:
            instance_name: Character or attachment instance name.
            pos: New (x, y) tuple or Vec2, or None to keep current.
            scale: New (x, y) tuple or Vec2, or None to keep current.
            rotation: New rotation in degrees, or None to keep current.
        """
        entry, eff_z = self._get_entry_and_z(instance_name)
        if not entry:
            return

        if pos is not None:
            if not isinstance(pos, Vec2):
                pos = Vec2(float(pos[0]), float(pos[1]))
            entry.pos = pos
        if scale is not None:
            if not isinstance(scale, Vec2):
                scale = Vec2(float(scale[0]), float(scale[1]))
            entry.scale = scale
        if rotation is not None:
            entry.rotation = rotation

        renderer = self._rig_renderers.get(instance_name)
        if renderer:
            disp = renderer.show_pose(getattr(entry, "pose", "neutral"))
            self._reshow_entry(instance_name, disp)

    def register_images(self):
        """
        Register all scenes as flat Ren'Py images for basic 'scene' usage.

        After calling, `scene street` works (shows flat composite).
        """
        from .io import list_scenes as _list_scenes
        scenes = _list_scenes(self._scenes_dir)
        for scene_info in scenes:
            name = scene_info["name"]
            renderer = self._get_renderer(name)
            renpy.image(name, renderer.show())


# ---------------------------------------------------------------------------
# Clip playback — orchestrates multi-character animated sequences
# ---------------------------------------------------------------------------


class ClipPlayer:
    """Plays a Clip by sequencing cues and dispatching to a SceneManager.

    Each cue is played by a ClipCueStepper. When a cue completes, the next
    cue is started automatically. Tweens (move_to, scale_to, etc.) are
    managed by a shared TweenManager.
    """

    def __init__(self, clip, scene_manager):
        """
        Args:
            clip: The Clip to play.
            scene_manager: SceneManager that owns the displayed scene.
        """
        from .clip import Clip, ClipCueStepper, TweenManager, Tween, TweenEase, _parse_ease

        self._clip = clip
        self._mgr = scene_manager
        self._tween_mgr = TweenManager(apply_callback=self._apply_tween)
        self._current_cue_idx = -1
        self._cue_stepper = None
        self._playing = False
        self._on_complete = None
        self._start_time = None
        # Cache clip module refs
        self._ClipCueStepper = ClipCueStepper
        self._Tween = Tween
        self._TweenEase = TweenEase
        self._parse_ease = _parse_ease

    def start(self, on_complete=None, start_cue_idx=0):
        """Begin clip playback.

        Args:
            on_complete: Optional callback when the entire clip finishes.
            start_cue_idx: Cue index to start from (default 0).
        """
        self._on_complete = on_complete
        self._playing = True
        self._start_time = None
        self._current_cue_idx = start_cue_idx - 1  # Will be incremented on first tick

        # Apply initial cast state to the scene
        self._setup_cast()

        # Advance to first cue
        self._advance_cue()

    def _setup_cast(self):
        """Apply clip cast entries to the scene.

        For each cast member, either find the existing scene entry and update it,
        or add it to the scene dynamically.
        """
        scene = self._mgr._scene_data
        if not scene:
            return

        for name, cast_entry in self._clip.cast.items():
            # Check if this character already exists in the scene
            existing = None
            for ch in scene.characters:
                if ch.name == name:
                    existing = ch
                    break
            if not existing:
                for att in scene.attachments:
                    if att.name == name:
                        existing = att
                        break

            if existing:
                # Update existing entry with clip cast overrides
                existing.pos = cast_entry.pos
                existing.scale = cast_entry.scale
                existing.rotation = cast_entry.rotation
                existing.z_offset = cast_entry.z_offset
                existing.pose = cast_entry.pose
                existing.animation = cast_entry.animation
                existing.animation_loop = cast_entry.animation_loop
                existing.overlays = list(cast_entry.overlays)
                existing.rig_attachments = list(cast_entry.attachments)

                # Re-show with updated state
                renderer = self._mgr._rig_renderers.get(name)
                if renderer:
                    self._mgr._apply_rig_state(renderer, existing)
                    if not cast_entry.visible:
                        tag = self._mgr._get_tag_for_entry(name, existing)
                        renpy.hide(tag)
                    else:
                        disp = renderer.show_pose(cast_entry.pose)
                        self._mgr._reshow_entry(name, disp, flip_h=cast_entry.flip_h)
            else:
                # Add new cast member to scene data
                if cast_entry.kind == "attachment":
                    from .scene import SceneAttachment as _SA
                    entry = _SA(
                        name=name, source=cast_entry.source,
                        layer=cast_entry.layer, pos=cast_entry.pos,
                        scale=cast_entry.scale, rotation=cast_entry.rotation,
                        z_offset=cast_entry.z_offset, pose=cast_entry.pose,
                        animation=cast_entry.animation,
                        animation_loop=cast_entry.animation_loop,
                        overlays=list(cast_entry.overlays),
                        rig_attachments=list(cast_entry.attachments),
                    )
                    scene.attachments.append(entry)
                    subdir = "attachments"
                else:
                    from .scene import SceneCharacter as _SC
                    entry = _SC(
                        name=name, source=cast_entry.source,
                        layer=cast_entry.layer, pos=cast_entry.pos,
                        scale=cast_entry.scale, rotation=cast_entry.rotation,
                        z_offset=cast_entry.z_offset, pose=cast_entry.pose,
                        animation=cast_entry.animation,
                        animation_loop=cast_entry.animation_loop,
                        overlays=list(cast_entry.overlays),
                        rig_attachments=list(cast_entry.attachments),
                    )
                    scene.characters.append(entry)
                    subdir = "characters"

                # Load the rig renderer
                rig_renderer = _load_scene_rig_renderer(
                    cast_entry.source, subdir, scene.base_path, "")
                if rig_renderer:
                    self._mgr._rig_renderers[name] = rig_renderer
                    self._mgr._apply_rig_state(rig_renderer, entry)

                    if cast_entry.visible:
                        disp = rig_renderer.show_pose(cast_entry.pose)
                        cam_x, cam_y = self._mgr._cam_offset
                        _, eff_z = self._mgr._get_entry_and_z(name)
                        root_x, root_y = rig_renderer.get_root_canvas_pos()
                        e_rot = entry.rotation if entry.rotation != 0 else None
                        placed = Transform(disp,
                                           xzoom=entry.scale.x, yzoom=entry.scale.y,
                                           rotate=e_rot,
                                           xpos=int(entry.pos.x) - cam_x,
                                           ypos=int(entry.pos.y) - cam_y,
                                           xanchor=int(root_x), yanchor=int(root_y),
                                           transform_anchor=True)
                        tag = self._mgr._get_tag_for_entry(name, entry)
                        renpy.show(tag, what=placed, zorder=eff_z)
                        self._mgr._shown_tags.append(tag)

    def _advance_cue(self):
        """Move to the next cue in the sequence."""
        self._tween_mgr.clear()
        self._current_cue_idx += 1

        if self._current_cue_idx >= len(self._clip.cues):
            # All cues done
            self._playing = False
            if self._on_complete:
                cb = self._on_complete
                self._on_complete = None
                cb()
            return

        cue = self._clip.cues[self._current_cue_idx]
        self._cue_stepper = self._ClipCueStepper(
            cue, execute_callback=self._execute_step, tween_mgr=self._tween_mgr
        )
        self._cue_stepper.start(on_complete=self._advance_cue)

    def tick(self, st):
        """Advance clip playback. Called each frame.

        Args:
            st: Current time in seconds (e.g., time.time()).
        """
        if not self._playing:
            return

        if self._start_time is None:
            self._start_time = st

        # Tick tweens (updates positions, scales, camera)
        self._tween_mgr.tick(st)

        # Tick the current cue stepper
        if self._cue_stepper:
            self._cue_stepper.tick(st)

    def _execute_step(self, clip_step, on_done, st):
        """Dispatch a ClipStep to the appropriate handler.

        Args:
            clip_step: The ClipStep to execute.
            on_done: Callback for async completion.
            st: Current time in seconds.
        """
        action = clip_step.action
        target = clip_step.target
        params = clip_step.params

        if action == "play_animation":
            self._dispatch_play_animation(clip_step, on_done)
        elif action == "set_pose":
            self._dispatch_set_pose(clip_step)
        elif action == "set_visible":
            self._dispatch_set_visible(clip_step)
        elif action == "stop_animation":
            self._dispatch_stop_animation(clip_step)
        elif action == "move_to":
            self._dispatch_move_to(clip_step, on_done, st)
        elif action == "scale_to":
            self._dispatch_scale_to(clip_step, on_done, st)
        elif action == "rotate_to":
            self._dispatch_rotate_to(clip_step, on_done, st)
        elif action == "camera_to":
            self._dispatch_camera_to(clip_step, on_done, st)
        elif action == "show_title":
            self._dispatch_show_title(clip_step, st)
        elif action == "show_credits":
            self._dispatch_show_credits(clip_step, st)
        elif action == "fade":
            self._dispatch_fade(clip_step, st)
        elif action == "set_background":
            self._dispatch_set_background(clip_step)
        elif action == "play_sound":
            self._dispatch_play_sound(clip_step)
        elif action == "set_overlay":
            self._dispatch_set_overlay(clip_step)
        elif action == "play_action":
            self._dispatch_play_action(clip_step, on_done)
        elif action == "flip":
            self._dispatch_flip(clip_step)
        elif action == "hold":
            pass  # Hold is handled by the stepper's hold_until
        # add, remove handled similarly if needed

    def _dispatch_play_animation(self, step, on_done):
        """Play an animation on a cast member."""
        target = step.target
        params = step.params
        anim_name = params.get("animation", "")
        loop = params.get("loop", False)
        loops = params.get("loops")

        renderer = self._mgr._rig_renderers.get(target)
        if not renderer:
            return
        if anim_name not in renderer.animations.animations:
            return

        cb = on_done if step.wait else None

        # If loops count specified, handle finite loop playback
        if loops is not None and loops > 0:
            remaining = [loops]
            def _loop_cb():
                remaining[0] -= 1
                if remaining[0] <= 0:
                    if cb:
                        cb()
                else:
                    disp = renderer.play_animation(anim_name, loop=False,
                                                    on_complete=_loop_cb)
                    self._mgr._reshow_entry(target, disp)
            disp = renderer.play_animation(anim_name, loop=False,
                                            on_complete=_loop_cb)
        else:
            disp = renderer.play_animation(anim_name, loop=loop,
                                            on_complete=cb)

        self._mgr._reshow_entry(target, disp)

    def _dispatch_set_pose(self, step):
        """Set a static pose on a cast member."""
        target = step.target
        pose_name = step.params.get("pose", "neutral")
        renderer = self._mgr._rig_renderers.get(target)
        if not renderer:
            return
        disp = renderer.show_pose(pose_name)
        self._mgr._reshow_entry(target, disp)

    def _dispatch_set_visible(self, step):
        """Show or hide a cast member."""
        target = step.target
        visible = step.params.get("visible", True)
        entry, eff_z = self._mgr._get_entry_and_z(target)
        if not entry:
            return
        tag = self._mgr._get_tag_for_entry(target, entry)
        if visible:
            renderer = self._mgr._rig_renderers.get(target)
            if renderer:
                disp = renderer.show_pose(getattr(entry, "pose", "neutral"))
                self._mgr._reshow_entry(target, disp)
        else:
            renpy.hide(tag)

    def _dispatch_stop_animation(self, step):
        """Stop animation on a cast member, holding the current pose."""
        target = step.target
        renderer = self._mgr._rig_renderers.get(target)
        if not renderer:
            return
        # Get the current animation player's pose and freeze it
        if renderer._displayable and hasattr(renderer._displayable, '_anim_player'):
            player = renderer._displayable._anim_player
            if player:
                pose = player.get_current_pose()
                if pose:
                    disp = renderer.show_pose(pose.name if hasattr(pose, 'name') else "neutral")
                    self._mgr._reshow_entry(target, disp)
                    return
        # Fallback: show neutral
        disp = renderer.show_pose("neutral")
        self._mgr._reshow_entry(target, disp)

    def _dispatch_move_to(self, step, on_done, st):
        """Start a position tween for a cast member."""
        target = step.target
        params = step.params
        end_pos_raw = params.get("pos", [0, 0])
        end_pos = Vec2(float(end_pos_raw[0]), float(end_pos_raw[1]))
        duration_ms = params.get("duration_ms", 0)
        ease = self._parse_ease(params.get("ease"))

        entry, _ = self._mgr._get_entry_and_z(target)
        if not entry:
            return

        start_pos = Vec2(entry.pos.x, entry.pos.y)
        # Set the final value immediately on entry so subsequent reads see it
        entry.pos = end_pos

        if duration_ms <= 0:
            # Instant move
            self._reshow_at_pos(target, end_pos)
            return

        tween = self._Tween(
            target=target, prop="pos",
            start_value=start_pos, end_value=end_pos,
            duration_ms=duration_ms, ease=ease,
            start_time=st,
        )
        self._tween_mgr.add(tween)

    def _dispatch_scale_to(self, step, on_done, st):
        """Start a scale tween for a cast member."""
        target = step.target
        params = step.params
        end_scale_raw = params.get("scale", [1.0, 1.0])
        end_scale = Vec2(float(end_scale_raw[0]), float(end_scale_raw[1]))
        duration_ms = params.get("duration_ms", 0)
        ease = self._parse_ease(params.get("ease"))

        entry, _ = self._mgr._get_entry_and_z(target)
        if not entry:
            return

        start_scale = Vec2(entry.scale.x, entry.scale.y)
        entry.scale = end_scale

        if duration_ms <= 0:
            self._reshow_current(target)
            return

        tween = self._Tween(
            target=target, prop="scale",
            start_value=start_scale, end_value=end_scale,
            duration_ms=duration_ms, ease=ease,
            start_time=st,
        )
        self._tween_mgr.add(tween)

    def _dispatch_rotate_to(self, step, on_done, st):
        """Start a rotation tween for a cast member."""
        target = step.target
        params = step.params
        end_rotation = float(params.get("rotation", 0.0))
        duration_ms = params.get("duration_ms", 0)
        ease = self._parse_ease(params.get("ease"))

        entry, _ = self._mgr._get_entry_and_z(target)
        if not entry:
            return

        start_rotation = entry.rotation
        entry.rotation = end_rotation

        if duration_ms <= 0:
            self._reshow_current(target)
            return

        tween = self._Tween(
            target=target, prop="rotation",
            start_value=start_rotation, end_value=end_rotation,
            duration_ms=duration_ms, ease=ease,
            start_time=st,
        )
        self._tween_mgr.add(tween)

    def _dispatch_camera_to(self, step, on_done, st):
        """Start a camera tween (pan/zoom)."""
        params = step.params
        end_rect = params.get("rect", [0, 0, 1920, 1080])
        end_rect = tuple(float(v) for v in end_rect)
        duration_ms = params.get("duration_ms", 0)
        ease = self._parse_ease(params.get("ease"))

        scene = self._mgr._scene_data
        if not scene:
            return

        start_rect = scene.get_camera_rect()

        if duration_ms <= 0:
            scene.camera = end_rect
            self._apply_camera(end_rect)
            return

        tween = self._Tween(
            target="@camera", prop="camera_rect",
            start_value=start_rect, end_value=end_rect,
            duration_ms=duration_ms, ease=ease,
            start_time=st,
        )
        self._tween_mgr.add(tween)

    def _dispatch_show_title(self, step, st):
        """Show a title card overlay."""
        params = step.params
        text = params.get("text", "")
        duration_ms = params.get("duration_ms", 3000)
        fade_ms = params.get("fade_ms", 500)
        bg_color = params.get("bg", "#000000")
        text_color = params.get("color", "#FFFFFF")
        text_size = params.get("size", 72)

        title_disp = _make_title_card(text, bg_color, text_color, text_size,
                                       duration_ms, fade_ms)
        renpy.show("_clip_title", what=title_disp, zorder=9999)

        # Schedule removal
        if duration_ms > 0:
            hide_time = duration_ms / 1000.0
            # Use a tween on alpha to handle fade-out, then hide
            def _hide_title():
                renpy.hide("_clip_title")
            tween = self._Tween(
                target="@title", prop="alpha",
                start_value=1.0, end_value=1.0,
                duration_ms=duration_ms, ease=self._TweenEase.LINEAR,
                start_time=st, on_complete=_hide_title,
            )
            self._tween_mgr.add(tween)

    def _dispatch_show_credits(self, step, st):
        """Show scrolling credits overlay."""
        params = step.params
        lines = params.get("lines", [])
        duration_ms = params.get("duration_ms", 10000)
        scroll_speed = params.get("scroll_speed", 60)

        credits_disp = _make_scrolling_credits(lines, duration_ms, scroll_speed)
        renpy.show("_clip_credits", what=credits_disp, zorder=9999)

        def _hide_credits():
            renpy.hide("_clip_credits")
        tween = self._Tween(
            target="@credits", prop="alpha",
            start_value=1.0, end_value=1.0,
            duration_ms=duration_ms, ease=self._TweenEase.LINEAR,
            start_time=st, on_complete=_hide_credits,
        )
        self._tween_mgr.add(tween)

    def _dispatch_fade(self, step, st):
        """Fade to/from a color."""
        params = step.params
        color = params.get("color", "#000000")
        duration_ms = params.get("duration_ms", 1000)
        direction = params.get("direction", "out")  # "out" = to color, "in" = from color

        start_alpha = 0.0 if direction == "out" else 1.0
        end_alpha = 1.0 if direction == "out" else 0.0

        # Show a solid color overlay
        from renpy.display.imagelike import Solid
        fade_disp = Solid(color)
        fade_placed = Transform(fade_disp, alpha=start_alpha)
        renpy.show("_clip_fade", what=fade_placed, zorder=9998)

        def _on_fade_complete():
            if direction == "in":
                renpy.hide("_clip_fade")

        tween = self._Tween(
            target="@fade", prop="alpha",
            start_value=start_alpha, end_value=end_alpha,
            duration_ms=duration_ms, ease=self._TweenEase.LINEAR,
            start_time=st, on_complete=_on_fade_complete,
        )
        self._tween_mgr.add(tween)

    def _dispatch_set_background(self, step):
        """Delegate to SceneActionPlayer's background swap."""
        scene = self._mgr._scene_data
        if not scene:
            return
        image_path = step.params.get("image")
        if image_path is not None:
            scene.background.image = image_path
        cam_x, cam_y = self._mgr._cam_offset
        bg_renderer = SceneRenderer(scene, game_directory="")
        bg_disp = bg_renderer.show_background()
        bg_placed = Transform(bg_disp, xpos=-cam_x, ypos=-cam_y, xanchor=0, yanchor=0)
        renpy.show("_scene_bg", what=bg_placed, zorder=-999)

    def _dispatch_play_sound(self, step):
        """Play a sound effect."""
        path = step.params.get("path", "")
        channel = step.params.get("channel", CHANNEL_SFX_PREFIX + "0")
        loop = step.params.get("loop", False)
        scene = self._mgr._scene_data
        base_path = scene.base_path if scene else ""
        if path:
            play_sound(path, channel, loop=loop, base_path=base_path)

    def _dispatch_set_overlay(self, step):
        """Toggle an overlay on a cast member."""
        target = step.target
        overlay_name = step.params.get("overlay", "")
        active = step.params.get("active", True)
        renderer = self._mgr._rig_renderers.get(target)
        if not renderer:
            return
        if active:
            if renderer.overlays.get(overlay_name):
                renderer.add_overlay(overlay_name)
        else:
            renderer.remove_overlay(overlay_name)

    def _dispatch_play_action(self, step, on_done):
        """Play a named scene action (e.g., on_show for curtains)."""
        action_name = step.params.get("action", "")
        scene = self._mgr._scene_data
        if not scene or action_name not in scene.actions:
            return
        # Use the existing scene action player
        cb = on_done if step.wait else None
        self._mgr.play(action_name, on_complete=cb)

    def _dispatch_flip(self, step):
        """Flip a cast member horizontally."""
        target = step.target
        flip_h = step.params.get("flip_h", True)
        renderer = self._mgr._rig_renderers.get(target)
        if not renderer:
            return
        disp = renderer.show_pose(getattr(
            self._mgr._get_entry_and_z(target)[0], "pose", "neutral"))
        self._mgr._reshow_entry(target, disp, flip_h=flip_h)

    def _apply_tween(self, target, prop, value):
        """Callback from TweenManager — apply interpolated values to the scene."""
        if target == "@camera" and prop == "camera_rect":
            self._apply_camera(value)
        elif target == "@fade" and prop == "alpha":
            self._apply_fade_alpha(value)
        elif target in ("@title", "@credits"):
            pass  # Timer-based, no per-frame update needed
        elif prop == "pos":
            self._reshow_at_pos(target, value)
        elif prop == "scale":
            self._reshow_at_scale(target, value)
        elif prop == "rotation":
            self._reshow_at_rotation(target, value)

    def _reshow_at_pos(self, target, pos):
        """Re-show a cast member at a specific position (during tween)."""
        entry, eff_z = self._mgr._get_entry_and_z(target)
        if not entry:
            return
        renderer = self._mgr._rig_renderers.get(target)
        if not renderer:
            return

        cam_x, cam_y = self._mgr._cam_offset
        tag = self._mgr._get_tag_for_entry(target, entry)
        root_x, root_y = renderer.get_root_canvas_pos()

        # Get current displayable from renderer (could be animating)
        disp = renderer.get_current_displayable()
        if not disp:
            disp = renderer.show_pose(getattr(entry, "pose", "neutral"))

        e_rot = entry.rotation if entry.rotation != 0 else None
        placed = Transform(disp,
                           xzoom=entry.scale.x, yzoom=entry.scale.y,
                           rotate=e_rot,
                           xpos=int(pos.x) - cam_x,
                           ypos=int(pos.y) - cam_y,
                           xanchor=int(root_x), yanchor=int(root_y),
                           transform_anchor=True)
        renpy.show(tag, what=placed, zorder=eff_z)

    def _reshow_at_scale(self, target, scale):
        """Re-show a cast member at a specific scale (during tween)."""
        entry, eff_z = self._mgr._get_entry_and_z(target)
        if not entry:
            return
        renderer = self._mgr._rig_renderers.get(target)
        if not renderer:
            return

        cam_x, cam_y = self._mgr._cam_offset
        tag = self._mgr._get_tag_for_entry(target, entry)
        root_x, root_y = renderer.get_root_canvas_pos()

        disp = renderer.get_current_displayable()
        if not disp:
            disp = renderer.show_pose(getattr(entry, "pose", "neutral"))

        e_rot = entry.rotation if entry.rotation != 0 else None
        placed = Transform(disp,
                           xzoom=scale.x, yzoom=scale.y,
                           rotate=e_rot,
                           xpos=int(entry.pos.x) - cam_x,
                           ypos=int(entry.pos.y) - cam_y,
                           xanchor=int(root_x), yanchor=int(root_y),
                           transform_anchor=True)
        renpy.show(tag, what=placed, zorder=eff_z)

    def _reshow_at_rotation(self, target, rotation):
        """Re-show a cast member at a specific rotation (during tween)."""
        entry, eff_z = self._mgr._get_entry_and_z(target)
        if not entry:
            return
        renderer = self._mgr._rig_renderers.get(target)
        if not renderer:
            return

        cam_x, cam_y = self._mgr._cam_offset
        tag = self._mgr._get_tag_for_entry(target, entry)
        root_x, root_y = renderer.get_root_canvas_pos()

        disp = renderer.get_current_displayable()
        if not disp:
            disp = renderer.show_pose(getattr(entry, "pose", "neutral"))

        placed = Transform(disp,
                           xzoom=entry.scale.x, yzoom=entry.scale.y,
                           rotate=rotation,
                           xpos=int(entry.pos.x) - cam_x,
                           ypos=int(entry.pos.y) - cam_y,
                           xanchor=int(root_x), yanchor=int(root_y),
                           transform_anchor=True)
        renpy.show(tag, what=placed, zorder=eff_z)

    def _reshow_current(self, target):
        """Re-show a cast member with its current entry state."""
        renderer = self._mgr._rig_renderers.get(target)
        if not renderer:
            return
        disp = renderer.get_current_displayable()
        if not disp:
            entry, _ = self._mgr._get_entry_and_z(target)
            disp = renderer.show_pose(getattr(entry, "pose", "neutral"))
        self._mgr._reshow_entry(target, disp)

    def _apply_camera(self, rect):
        """Apply a camera rect to the scene."""
        scene = self._mgr._scene_data
        if not scene:
            return

        if isinstance(rect, tuple):
            cam_x, cam_y, cam_w, cam_h = (int(v) for v in rect)
        else:
            return

        # Update camera offset for element positioning
        self._mgr._cam_offset = (cam_x, cam_y)

        # Re-apply camera crop/scale to master layer
        screen_w = renpy.config.screen_width
        screen_h = renpy.config.screen_height
        if cam_w != screen_w or cam_h != screen_h:
            sx = screen_w / float(cam_w)
            sy = screen_h / float(cam_h)
            renpy.show_layer_at([
                Transform(crop=(0, 0, cam_w, cam_h)),
                Transform(xzoom=sx, yzoom=sy),
            ], layer='master')

        # Re-show background at new offset
        bg_disp = SceneRenderer(scene, game_directory="").show_background()
        bg_placed = Transform(bg_disp, xpos=-cam_x, ypos=-cam_y, xanchor=0, yanchor=0)
        renpy.show("_scene_bg", what=bg_placed, zorder=-999)

    def _apply_fade_alpha(self, alpha):
        """Update fade overlay alpha."""
        # Re-show the fade overlay with updated alpha
        # The solid was already shown; update its transform
        pass  # Fade alpha is handled by ATL or a custom displayable
        # For now, we rely on the tween's on_complete to hide

    @property
    def is_playing(self):
        return self._playing

    @property
    def is_complete(self):
        return not self._playing and self._current_cue_idx >= 0

    @property
    def current_cue_index(self):
        return self._current_cue_idx

    @property
    def current_cue(self):
        if 0 <= self._current_cue_idx < len(self._clip.cues):
            return self._clip.cues[self._current_cue_idx]
        return None


class ClipManager:
    """Manages clip playback within Ren'Py.

    Analogous to SceneManager but for clips. Handles loading clip.json files,
    setting up the scene, and orchestrating playback.
    """

    def __init__(self, clips_dir, scene_manager=None, scenes_dir=None):
        """
        Args:
            clips_dir: Absolute path to the clips directory.
            scene_manager: Optional existing SceneManager to reuse.
            scenes_dir: Path to scenes directory (required if scene_manager not provided).
        """
        _check_renpy()
        self._clips_dir = clips_dir
        self._scenes_dir = scenes_dir
        self._scene_manager = scene_manager
        self._clip_player = None

    def _get_scene_manager(self):
        """Get or create a SceneManager."""
        if self._scene_manager:
            return self._scene_manager
        if self._scenes_dir:
            self._scene_manager = SceneManager(self._scenes_dir)
            return self._scene_manager
        # Infer scenes_dir from clips_dir (sibling directory)
        parent = os.path.dirname(self._clips_dir)
        scenes_dir = os.path.join(parent, "scenes")
        self._scene_manager = SceneManager(scenes_dir)
        return self._scene_manager

    def play_clip(self, name, on_complete=None, start_cue=None):
        """Play a clip by name.

        Args:
            name: Clip name (directory name under clips/).
            on_complete: Optional callback when clip finishes.
            start_cue: Optional cue ID to start from (default: first cue).
        """
        from .io import load_clip as _load_clip

        clip_path = os.path.join(self._clips_dir, name, "clip.json")
        clip = _load_clip(clip_path)

        mgr = self._get_scene_manager()

        # Show the clip's scene
        if clip.scene:
            mgr.show(clip.scene, skip_on_show=True)

        # Create and start the clip player
        self._clip_player = ClipPlayer(clip, mgr)

        start_idx = 0
        if start_cue:
            idx = clip.get_cue_index(start_cue)
            if idx >= 0:
                start_idx = idx

        self._clip_player.start(on_complete=on_complete, start_cue_idx=start_idx)

        # Show ticker screen
        renpy.show_screen("_clip_tick", player=self._clip_player)

    def play_clip_and_wait(self, name, start_cue=None):
        """Play a clip and block Ren'Py script execution until it completes.

        Uses ``call screen`` internally. Must be called from a Ren'Py label context.

        Args:
            name: Clip name (directory name under clips/).
            start_cue: Optional cue ID to start from.
        """
        self.play_clip(name, start_cue=start_cue)
        if self._clip_player and self._clip_player.is_playing:
            renpy.call_screen("_clip_wait", player=self._clip_player)

    @property
    def clip_player(self):
        """The current ClipPlayer, or None."""
        return self._clip_player

    @property
    def scene_manager(self):
        """The underlying SceneManager."""
        return self._get_scene_manager()


def _make_title_card(text, bg_color, text_color, text_size, duration_ms, fade_ms):
    """Create a title card displayable (Solid background + centered Text)."""
    from renpy.display.imagelike import Solid
    from renpy.text.text import Text

    bg = Solid(bg_color)
    title_text = Text(text, size=text_size, color=text_color,
                      xalign=0.5, yalign=0.5)
    return Fixed(bg, title_text, xfill=True, yfill=True)


def _make_scrolling_credits(lines, duration_ms, scroll_speed):
    """Create a scrolling credits displayable.

    Returns a Fixed with a black background and scrolling text.
    For now, uses a simple ATL-driven Transform approach.
    """
    from renpy.display.imagelike import Solid
    from renpy.text.text import Text

    bg = Solid("#000000")
    # Join lines into a single block of text
    credit_text = "\n".join(lines)
    text_disp = Text(credit_text, size=36, color="#FFFFFF",
                     xalign=0.5, text_align=0.5)
    # Position text at bottom and scroll up
    scroll_duration = duration_ms / 1000.0
    scrolling = Transform(text_disp,
                          ypos=1.0, yanchor=0.0,
                          linear=scroll_duration,
                          ypos_end=-1.0)
    return Fixed(bg, scrolling, xfill=True, yfill=True)
