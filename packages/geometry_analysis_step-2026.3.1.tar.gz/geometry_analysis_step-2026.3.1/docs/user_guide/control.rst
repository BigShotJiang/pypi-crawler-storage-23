.. _user-control:

***************************
Controlling the calculation
***************************

