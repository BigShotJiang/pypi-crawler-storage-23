.. _user-output:

**********************
Controlling the output
**********************

