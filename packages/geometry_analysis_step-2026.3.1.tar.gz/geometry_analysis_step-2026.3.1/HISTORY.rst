=======
History
=======
2026.3.1 -- Internal: switching from deprecated library pkg_resources to importlib

2025.7.16 -- Bugfix: explicit OOPs
    * Fixes a bug in the explicit out-of-plane (oop) code that prevented it showing
      results.
      
2025.3.4 -- Bugfix: error specifying units of degrees

2025.2.9 -- Added bond lengths, angles, etc. to results
    * This allows them to be saved to variables, JSON, etc. for external analysis or use
      in the flowchart.

2022.12.24 (2022-12-24)
-----------------------

* Plug-in created using the SEAMM plug-in cookiecutter.
