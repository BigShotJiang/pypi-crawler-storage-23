# AI Box Library


## Development 

Use the `./src/ai-box-lib` to write all the library code which can be used by users. 

In order to test the library locally you can run the following commands: 
1. 
