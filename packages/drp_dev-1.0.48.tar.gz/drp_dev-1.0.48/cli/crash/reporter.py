"""
Crash reporter — scrubs sensitive data, POSTs to the server in the background.

Usage:
    from cli.crash.reporter import handle
    handle("up", exc)   # call from except blocks for unexpected errors only
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import threading
import traceback
import urllib.request

from cli import __version__

_HOME = os.path.expanduser("~")

_SCRUB = [
    (re.compile(r"(TOKEN|SECRET|KEY|PASSWORD|CREDENTIAL|AUTH)[=:]\s*\S+", re.I), r"\1=***"),
    (re.compile(r"(Bearer\s+)\S+", re.I), r"\1<token>"),
    (re.compile(r"\b[0-9a-fA-F]{32,}\b"), "<token>"),
    (re.compile(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+"), "<email>"),
]


def _scrub(text: str) -> str:
    out = text.replace(_HOME, "~")
    for pattern, replacement in _SCRUB:
        out = pattern.sub(replacement, out)
    return out


def _fingerprint(exc: BaseException) -> str:
    frames = "|".join(
        f"{f.filename.rsplit('/', 1)[-1]}:{f.lineno}:{f.name}"
        for f in traceback.extract_tb(exc.__traceback__)
    )
    return hashlib.sha256(f"{type(exc).__qualname__}|{frames}".encode()).hexdigest()


def _post(host: str, payload: bytes) -> None:
    try:
        req = urllib.request.Request(
            f"{host}/api/v1/crash/",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


def handle(command: str, exc: BaseException) -> None:
    """Report an unexpected exception — POST in background, print short ref to stderr."""
    tb_text = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    fp = _fingerprint(exc)

    payload = json.dumps({
        "fingerprint":    fp,
        "command":        command,
        "exc_type":       type(exc).__qualname__,
        "exc_message":    _scrub(str(exc)),
        "traceback":      _scrub(tb_text),
        "cli_version":    __version__,
        "python_version": platform.python_version(),
        "platform":       platform.platform(),
    }).encode()

    try:
        from cli import config
        host = config.load().get("host", "").rstrip("/") or "https://drp.fyi"
    except Exception:
        host = "https://drp.fyi"

    threading.Thread(target=_post, args=(host, payload), daemon=True).start()

    # Short ref on stderr — no links, no "please report", no noise
    import sys
    print(f"drp: unexpected error in '{command}' (ref {fp[:8]})", file=sys.stderr)
