"""Authenticated HTTP session for drp."""

from __future__ import annotations

import requests
from cli import config


def _session() -> requests.Session:
    username = config.get("username")
    cfg = config.load(username)
    s = requests.Session()
    token = cfg.get("token", "")
    if token:
        s.headers["Authorization"] = f"Bearer {token}"
    s.headers["User-Agent"] = "drp-cli"
    return s


def _host() -> str:
    username = config.get("username")
    cfg = config.load(username)
    return cfg.get("host", "").rstrip("/")


def api_url(path: str) -> str:
    h = _host() or "https://drp.fyi"
    return f"{h}{path}" if path.startswith("/") else f"{h}/{path}"


def api_get(path: str, **kwargs) -> requests.Response:
    return _session().get(api_url(path), **kwargs)


def api_post(path: str, **kwargs) -> requests.Response:
    return _session().post(api_url(path), **kwargs)


def api_delete(path: str, **kwargs) -> requests.Response:
    return _session().delete(api_url(path), **kwargs)


def api_patch(path: str, **kwargs) -> requests.Response:
    return _session().patch(api_url(path), **kwargs)


def is_logged_in() -> bool:
    username = config.get("username")
    return bool(config.load(username).get("token"))


def is_guest() -> bool:
    return str(config.get("username", "")).startswith("guest_")


def save_session(token: str, username: str = "", email: str = "",
                 host: str = "") -> None:
    """Persist token + metadata. Host is written globally so it survives before login."""
    global_cfg = config.load()
    if host:
        global_cfg["host"] = host
    global_cfg["username"] = username
    config.save(global_cfg)

    cfg = config.load(username)
    cfg["token"] = token
    cfg["host"] = host or _host()
    if username:
        cfg["username"] = username
    if email:
        cfg["email"] = email
    config.save(cfg, username)


def save_host(host: str) -> None:
    """Persist just the host — called before login attempt so it's never lost."""
    global_cfg = config.load()
    global_cfg["host"] = host.rstrip("/")
    config.save(global_cfg)


def clear_session() -> None:
    username = config.get("username")
    cfg = config.load(username)
    cfg.update({"token": "", "username": "", "email": ""})
    config.save(cfg, username)


def ensure_guest(host: str = "") -> tuple[bool, str]:
    """Ensure a session exists, creating an anonymous guest if not.

    Returns (ok, error_message). Only unexpected errors (server 5xx etc.)
    are reported via crash reporter. Connection failures and missing host
    are user-facing errors returned as messages, never reported.
    """
    if is_logged_in():
        return True, ""

    target_host = (host or _host()).rstrip("/")
    if not target_host:
        return False, "no server configured — run [bold]drp login --server <url>[/bold] first"

    try:
        resp = requests.post(
            f"{target_host}/api/v1/auth/guest/",
            headers={"User-Agent": "drp-cli"},
            timeout=10,
        )
    except requests.RequestException:
        # Network failure — user-facing, not a bug
        return False, f"cannot reach {target_host} — check your connection or server address"

    if resp.status_code != 200:
        # Unexpected server error — worth reporting
        exc = RuntimeError(f"/auth/guest/ returned {resp.status_code}")
        from cli.crash.reporter import handle
        handle("ensure_guest", exc)
        return False, f"server error ({resp.status_code})"

    data = resp.json()
    save_session(data["token"], username=data["username"], host=target_host)
    return True, ""
