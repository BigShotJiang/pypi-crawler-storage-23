"""login — Authenticate with drp."""

from __future__ import annotations

from cli.commands import Arg, Command, register

register(Command(
    name="login",
    description="Log in to drp. Leave blank for anonymous access.",
    args=(
        Arg("--server", "Server base URL (default: https://drp.fyi)."),
    ),
))


def run(ns) -> int:
    import getpass
    import requests
    from rich.console import Console
    from rich.prompt import Confirm
    from cli import config, session

    console = Console()
    err = Console(stderr=True)

    host = (getattr(ns, "server", None) or config.get("host") or "https://drp.fyi").rstrip("/")

    # Save host immediately — before any network attempt
    session.save_host(host)

    console.print(f"[bold]Log in to drp[/bold] [dim]{host}[/dim]")
    console.print("[dim]Leave username blank for anonymous access.[/dim]")

    try:
        raw = input("username:password (or just Enter for anonymous): ").strip()
    except (KeyboardInterrupt, EOFError):
        print()
        return 130

    # Anonymous
    if not raw:
        if session.is_logged_in() and not session.is_guest():
            err.print("[red]drp:[/red] already logged in — provide credentials to switch accounts")
            return 1
        ok, msg = session.ensure_guest(host=host)
        if not ok:
            err.print(f"[red]drp:[/red] {msg}")
            return 1
        console.print("[green]Connected anonymously.[/green]")
        return 0

    # Parse username:password
    if ":" in raw:
        username, password = raw.split(":", 1)
    else:
        username = raw
        try:
            password = getpass.getpass("Password: ")
        except (KeyboardInterrupt, EOFError):
            print()
            return 130

    try:
        resp = requests.post(
            f"{host}/api/v1/auth/login/",
            json={"username": username, "password": password},
            headers={"User-Agent": "drp-cli"},
            timeout=10,
        )
    except requests.RequestException:
        err.print(f"[red]drp:[/red] cannot reach {host} — check your connection or server address")
        return 1

    if resp.status_code == 401:
        err.print("[red]drp:[/red] invalid credentials")
        return 1
    if resp.status_code != 200:
        exc = RuntimeError(f"/auth/login/ returned {resp.status_code}")
        from cli.crash.reporter import handle
        handle("login", exc)
        err.print(f"[red]drp:[/red] server error ({resp.status_code})")
        return 1

    data = resp.json()
    new_token = data["token"]
    new_username = data.get("username", username)
    new_email = data.get("email", "")

    # Offer guest file migration before switching session
    if session.is_logged_in() and session.is_guest():
        _migrate_guest(host, new_token, console)

    session.save_session(new_token, username=new_username, email=new_email, host=host)

    plan = data.get("plan", "")
    console.print(
        f"[green]Logged in[/green] as [bold]{new_username}[/bold]"
        + (f" ({new_email})" if new_email else "")
        + (f" — [dim]{plan}[/dim]" if plan else "")
    )
    return 0


def _migrate_guest(host: str, new_token: str, console) -> None:
    import requests
    from rich.prompt import Confirm
    from cli import config

    console.print("\n[yellow]You have files on a guest account.[/yellow]")
    if not Confirm.ask("Copy them to the root of your account?", default=False):
        _logout_guest(host)
        return

    old_token = config.load(config.get("username")).get("token", "")
    try:
        r = requests.get(
            f"{host}/api/v1/keys/",
            headers={"Authorization": f"Bearer {old_token}", "User-Agent": "drp-cli"},
            timeout=10,
        )
        keys = r.json().get("keys", []) if r.status_code == 200 else []
    except Exception:
        keys = []

    copied = failed = 0
    with console.status(f"  Copying {len(keys)} file(s)...", spinner="dots"):
        for k in keys:
            try:
                r = requests.post(
                    f"{host}/api/v1/keys/{k['key']}/fork/",
                    json={"folder": ""},
                    headers={"Authorization": f"Bearer {new_token}", "User-Agent": "drp-cli"},
                    timeout=10,
                )
                if r.status_code in (200, 201):
                    copied += 1
                else:
                    failed += 1
            except Exception:
                failed += 1

    console.print(
        f"[green]Copied {copied} file(s).[/green]"
        + (f" [yellow]{failed} failed.[/yellow]" if failed else "")
    )
    _logout_guest(host)


def _logout_guest(host: str) -> None:
    import requests
    from cli import config
    token = config.load(config.get("username")).get("token", "")
    try:
        requests.post(
            f"{host}/api/v1/auth/logout/",
            headers={"Authorization": f"Bearer {token}", "User-Agent": "drp-cli"},
            timeout=5,
        )
    except Exception:
        pass
