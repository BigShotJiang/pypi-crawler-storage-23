================
EKF SN4-DJEMBE
================

See `Product Page <https://ekf.com/product/sn4>`_ for the board's technical specifications.

Inventory
=========

.. include:: snippets/cpci_inventory.rst
