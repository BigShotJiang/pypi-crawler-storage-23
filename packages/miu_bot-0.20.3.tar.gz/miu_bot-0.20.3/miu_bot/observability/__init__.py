"""OpenTelemetry observability for miu_bot."""
