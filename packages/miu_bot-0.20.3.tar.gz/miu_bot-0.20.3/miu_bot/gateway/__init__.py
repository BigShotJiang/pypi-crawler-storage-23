"""FastAPI gateway for miu_bot multi-tenant deployment."""
