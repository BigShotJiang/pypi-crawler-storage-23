```{include} ../../README.md
```

## Documentation

```{toctree}
:maxdepth: 2
:caption: Contents:

guides/index
api/index
```

## Indices and tables

- {ref}`genindex`
- {ref}`modindex`
