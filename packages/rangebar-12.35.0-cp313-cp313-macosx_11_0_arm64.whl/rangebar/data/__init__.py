# Issue #79: Package marker for importlib.resources (symbols.toml)
