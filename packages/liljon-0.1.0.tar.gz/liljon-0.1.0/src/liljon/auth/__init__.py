"""Authentication subpackage for the Robinhood client."""
