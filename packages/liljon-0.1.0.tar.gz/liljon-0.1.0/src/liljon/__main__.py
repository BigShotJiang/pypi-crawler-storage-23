"""Allow running as `python -m liljon`."""

from liljon.cli import cli

cli()
