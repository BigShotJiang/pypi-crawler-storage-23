# arpakitlib

import uuid


def uuid4_as_str() -> str:
    return str(uuid.uuid4())
