#!/usr/bin/env python3
"""
Rcoder - 远程代码执行与管理系统
"""

__version__ = "1.0.0"
__author__ = "Trae Team"
__description__ = "远程代码执行与管理系统，支持异步操作、批量执行和实时监控"
