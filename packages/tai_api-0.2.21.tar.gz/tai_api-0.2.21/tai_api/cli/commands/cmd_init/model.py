import subprocess
import sys
import os
import shutil
from pathlib import Path
import click

from tai_api import pm, MainFileGenerator

class InitCommand:

    def __init__(self, project: str, namespace: str, base_path: str = '.', app_dir: str = '.'):
        self.project = project
        self.namespace = namespace
        self.base_path = Path(base_path)
        self.app_dir = app_dir
    
    @property
    def project_root(self) -> Path:
        """Directorio raíz del proyecto (donde vive .taiapiproject y pyproject.toml)"""
        return self.base_path / self.namespace

    @property
    def subnamespace(self) -> str:
        """Retorna el subnamespace basado en el namespace"""
        return self.namespace.replace('-', '_')
    
    def check_poetry(self):
        """Verifica que Poetry esté instalado y disponible con versión >= 2.2.1"""
        try:
            result = subprocess.run(['poetry', '--version'], check=True, capture_output=True, text=True)
            version_output = result.stdout.strip()
            # Extrae la versión del output "Poetry (version X.Y.Z)"
            version_str = version_output.split('(version ')[-1].rstrip(')')
            version_parts = version_str.split('.')
            major, minor, patch = int(version_parts[0]), int(version_parts[1]), int(version_parts[2])
            
            # Verifica que sea >= 2.2.1
            if (major, minor, patch) < (2, 2, 1):
                click.echo(f"❌ Error: Poetry versión {version_str} encontrada, se requiere >= 2.2.1", err=True)
                click.echo("Actualiza Poetry desde: https://python-poetry.org/docs/#installation")
                sys.exit(1)
                
        except (subprocess.CalledProcessError, FileNotFoundError):
            click.echo("❌ Error: Poetry no está instalado o no está en el PATH", err=True)
            click.echo("Instala Poetry desde: https://python-poetry.org/docs/#installation")
            sys.exit(1)
        except (IndexError, ValueError) as e:
            click.echo(f"❌ Error: No se pudo determinar la versión de Poetry: {e}", err=True)
            sys.exit(1)
    
    def check_directory_is_avaliable(self):
        """Verifica que el directorio del proyecto no exista"""
        if self.project_root.exists():
            click.echo(f"❌ Error: el directorio '{self.project_root}' ya existe", err=True)
            sys.exit(1)
    
    def check_virtualenv(self):
        """Verifica que el entorno virtual de Poetry esté activo"""
        if 'VIRTUAL_ENV' not in os.environ:
            click.echo("❌ Error: No hay entorno virutal activo", err=True)
            click.echo("   Puedes crear uno con 'pyenv virtualenv <env_name>' y asignarlo con 'pyenv local <env_name>'", err=True)
            sys.exit(1)
    
    def create_project(self):
        """Crea el proyecto base con Poetry"""
        click.echo(f"🚀 Creando '{self.project_root}'...")
        
        try:
            # Asegurar que el directorio padre exista
            self.base_path.mkdir(parents=True, exist_ok=True)

            subprocess.run(['poetry', 'new', '--flat', '--python', '<4.0,>=3.10', str(self.project_root)], 
                        check=True, 
                        capture_output=True)
            subprocess.run(['poetry', 'install'],
                        cwd=str(self.project_root),
                        check=True, 
                        capture_output=True)
            click.echo(f"✅ poetry new '{self.project_root}': OK")
        except subprocess.CalledProcessError as e:
            click.echo(f"❌ Error: {e}", err=True)
            sys.exit(1)
    
    def create_project_config(self) -> None:
        """Crea el archivo .taiapiproject con la configuración inicial"""
        try:
            pm.create_config(
                name=self.project,
                namespace=self.namespace,
                project_root=self.project_root,
                app_dir=self.app_dir,
            )
            
        except Exception as e:
            click.echo(f"❌ Error al crear configuración del proyecto: {e}", err=True)
            sys.exit(1)

    def add_dependencies(self):
        """Añade las dependencias necesarias al proyecto"""
        click.echo("📦 Añadiendo dependencias...")
        
        # Dependencias con versiones específicas
        # Las redundantes con tai-sql (sqlalchemy, psycopg2-binary, cryptography, pydantic, tai-alphi) se omiten
        # fastapi-mcp se instala solo cuando se ejecuta tai-api set-mcp
        # tai-keycloak se instala solo cuando se ejecuta tai-api set-auth con opción keycloak
        dependencies = [
            'tai-sql>=0.3.59,<1.0',
            'fastapi[standard]>=0.116.1,<1.0',
            'uvicorn[standard]>=0.30.0,<1.0',
            'asyncpg>=0.30.0,<1.0',
            'python-jose>=3.5.0,<4.0',
            'python-multipart>=0.0.9,<1.0'
        ]
        
        for dep in dependencies:
            try:
                subprocess.run(['poetry', 'add', dep], 
                            cwd=str(self.project_root),
                            check=True, 
                            capture_output=True)
                click.echo(f"   ✅ {dep} añadido")
            except subprocess.CalledProcessError as e:
                click.echo(f"   ❌ Error al añadir dependencia {dep}: {e}", err=True)
                sys.exit(1)
    
    def add_folders(self) -> None:
        """Crea la estructura adicional del proyecto"""
        test_dir = self.project_root / 'tests'
        if test_dir.exists():
            shutil.rmtree(test_dir)
        
        # Si app_dir != '.', mover el paquete creado por poetry al subdirectorio indicado
        if self.app_dir != '.':
            poetry_pkg = self.project_root / self.subnamespace
            target_parent = self.project_root / self.app_dir
            target_pkg = target_parent / self.subnamespace

            if poetry_pkg.exists() and not target_pkg.exists():
                target_parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(poetry_pkg), str(target_pkg))
                click.echo(f"📂 Paquete movido a {target_pkg.relative_to(self.project_root)}")

        resources_dir = Path(__file__).parent / 'resources'

        # Crear directorio para responses
        pm.config.resources_namespace.mkdir(parents=True, exist_ok=True)
        
        if resources_dir.exists():
            # Copiar todos los archivos de la carpeta responses
            for item in resources_dir.iterdir():
                if item.is_file():
                    destination = pm.config.resources_namespace / item.name
                    shutil.copy2(item, destination)
                elif item.is_dir():
                    # Si hay subdirectorios, copiarlos recursivamente
                    destination = pm.config.resources_namespace / item.name
                    shutil.copytree(item, destination, dirs_exist_ok=True)
            
            click.echo(f"📁 Estructura responses copiada exitosamente")
        
        #Crear main file
        generator = MainFileGenerator(output_dir=pm.config.main_namespace.as_posix())
        generator.generate()
    
    def add_docker_resources(self) -> None:
        """Copia los recursos de Docker al proyecto"""
        docker_resources_dir = Path(__file__).parent / 'docker'
        
        if docker_resources_dir.exists():
            for item in docker_resources_dir.iterdir():
                if item.is_file():
                    destination = self.project_root / item.name
                    shutil.copy2(item, destination)
                elif item.is_dir():
                    destination = self.project_root / item.name
                    shutil.copytree(item, destination, dirs_exist_ok=True)
            
            click.echo(f"🐳 Recursos de Docker copiados exitosamente")

    def msg(self):
        """Muestra el mensaje de éxito y next steps con información del proyecto"""
        # ✅ Obtener información del proyecto creado
        project_root = self.project_root
        project_config = pm.config
        
        click.echo()
        click.echo(f'🎉 ¡Proyecto "{self.project}" creado exitosamente en {project_root}!')
        
        # Mostrar información del proyecto
        if project_config:
            click.echo()
            click.echo("📋 Información del proyecto:")
            click.echo(f"   Nombre: {project_config.name}")
        
        click.echo()
        click.echo("📋 Próximos pasos:")
        click.echo("💡 Con tai-sql puedes definir tu schema de base de datos y con")
        click.echo("   tai-api generate crear automáticamente los routers/endpoints")
        click.echo("   asociados a ese schema.")
        click.echo()
        click.echo("🔗 Documentación: https://github.com/triplealpha-innovation/tai-sql")
        click.echo()
        click.echo("🔧 Comandos útiles:")
        click.echo("   tai-api generate                   # Generar endpoints")
        click.echo("   tai-api dev                        # Levantar servidor de desarrollo (no auth)")
        # click.echo("   tai-api up                         # Levantar servidor de desarrollo (docker)")
        click.echo("   tai-api set-auth                   # Configurar autenticación")
        click.echo()
        click.echo("🔗 Documentación: https://github.com/triplealpha-innovation/tai-api")
        