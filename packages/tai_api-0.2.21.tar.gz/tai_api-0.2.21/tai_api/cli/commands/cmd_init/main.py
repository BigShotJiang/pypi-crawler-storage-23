import sys
import click
from .model import InitCommand

@click.command()
@click.argument('project', type=str)
@click.option('--namespace', '-n', default='api', help='Nombre del paquete Python (importable)')
@click.option('--path', '-p', default='.', type=click.Path(), help='Directorio padre donde crear el proyecto')
@click.option('--app-dir', '-a', default=None, help='Subruta del paquete dentro del proyecto (default: namespace)')
def init(project: str, namespace: str, path: str, app_dir: str):
    """Inicializa un nuevo proyecto tai-api"""
    if app_dir is None:
        app_dir = '.'

    command = InitCommand(project=project, namespace=namespace, base_path=path, app_dir=app_dir)
    try:
        command.check_poetry()
        command.check_directory_is_avaliable()
        command.check_virtualenv()
        command.create_project()
        command.create_project_config()
        command.add_dependencies()
        command.add_folders()
        command.add_docker_resources()
        command.msg()
    except Exception as e:
        click.echo(f"❌ Error al inicializar el proyecto: {str(e)}", err=True)
        sys.exit(1)