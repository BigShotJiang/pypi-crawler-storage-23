"""IXV-Core OpenAI互換APIルーター"""

import json
import time
import uuid
from typing import List, Optional, AsyncGenerator, Dict, Any

from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse

from app.memory import memory
from app.inference_service import inference_service
from app.rate_limiter import limiter
from app.concurrency_limiter import concurrency_limiter
from app.config import config
from app.prompts import PromptTemplate, PromptType, detect_language
from app.skills.skill_manager import skill_manager
from app.models import (
    Function,
    Tool,
    FunctionCall,
    ToolCall,
    Message,
    ChatCompletionRequest,
    ChatCompletionChoice,
    ChatCompletionResponse,
    Usage,
    ModelInfo,
    ModelsResponse,
)

router = APIRouter(prefix="/v1", tags=["openai-compatible"])


# ==== Function Calling ユーティリティ ====

def convert_skill_action_to_json_schema(action: dict) -> Dict[str, Any]:
    """スキルのアクション定義をJSON Schema形式に変換
    
    Args:
        action: スキルのアクション定義
        
    Returns:
        JSON Schema形式のパラメータ定義
    """
    properties = {}
    required = []
    
    params = action.get("parameters", {})
    for param_name, param_def in params.items():
        param_type = param_def.get("type", "string")
        description = param_def.get("description", "")
        is_required = param_def.get("required", False)
        default = param_def.get("default")
        
        # JSON Schemaの型マッピング
        json_type = param_type
        if param_type == "integer":
            json_type = "integer"
        elif param_type == "boolean":
            json_type = "boolean"
        elif param_type == "array":
            json_type = "array"
        else:
            json_type = "string"
        
        prop = {
            "type": json_type,
            "description": description,
        }
        
        # デフォルト値がある場合は追加
        if default is not None:
            prop["default"] = default
        
        # array型の場合はitemsを追加
        if json_type == "array":
            prop["items"] = {"type": "string"}
        
        properties[param_name] = prop
        
        if is_required:
            required.append(param_name)
    
    schema = {
        "type": "object",
        "properties": properties,
    }
    
    if required:
        schema["required"] = required
    
    return schema


def get_available_tools() -> List[Tool]:
    """有効なスキルをOpenAI互換のtools形式に変換
    
    Returns:
        Toolのリスト
    """
    tools = []
    
    # 有効なスキルを取得
    skills = skill_manager.list_skills()
    
    for skill_info in skills:
        if not skill_info.get("enabled", False):
            continue
        
        skill_name = skill_info["name"]
        skill = skill_manager.get_skill(skill_name)
        if not skill:
            continue
        
        # スキルの各アクションをtoolに変換
        actions = skill.get_actions()
        for action in actions:
            action_name = action["name"]
            function_name = f"{skill_name}_{action_name}"  # スキル名_アクション名
            
            # JSON Schema形式に変換
            parameters = convert_skill_action_to_json_schema(action)
            
            # Function定義を作成
            function = Function(
                name=function_name,
                description=f"{skill_info['description']}: {action['description']}",
                parameters=parameters,
            )
            
            # Tool定義を作成
            tool = Tool(type="function", function=function)
            tools.append(tool)
    
    return tools


def parse_tool_call_from_text(text: str) -> Optional[List[ToolCall]]:
    """LLMの応答テキストからtool_callsを検出・解析
    
    複数のパターンに対応:
    1. JSON形式のtool_calls (```json ... ```)
    2. テキスト内の直接JSON
    3. 関数呼び出し形式: function_name({"param": "value"})
    4. 自然言語からの関数名とパラメータの抽出
    
    Args:
        text: LLMの応答テキスト
        
    Returns:
        ToolCallのリスト（検出できない場合はNone）
    """
    import re
    
    # パターン1: JSONブロック内のtool_calls
    json_pattern = r'```(?:json)?\s*(\{.*?\})\s*```'
    matches = re.findall(json_pattern, text, re.DOTALL)
    
    for match in matches:
        try:
            data = json.loads(match)
            if "tool_calls" in data:
                tool_calls = []
                for tc in data["tool_calls"]:
                    tool_call = ToolCall(
                        id=tc.get("id", str(uuid.uuid4())),
                        type="function",
                        function=FunctionCall(
                            name=tc["function"]["name"],
                            arguments=json.dumps(tc["function"]["arguments"]) if isinstance(tc["function"]["arguments"], dict) else tc["function"]["arguments"],
                        ),
                    )
                    tool_calls.append(tool_call)
                if tool_calls:
                    return tool_calls
        except (json.JSONDecodeError, KeyError):
            continue
    
    # パターン2: テキスト全体がJSONの場合
    try:
        data = json.loads(text.strip())
        if "tool_calls" in data:
            tool_calls = []
            for tc in data["tool_calls"]:
                tool_call = ToolCall(
                    id=tc.get("id", str(uuid.uuid4())),
                    type="function",
                    function=FunctionCall(
                        name=tc["function"]["name"],
                        arguments=json.dumps(tc["function"]["arguments"]) if isinstance(tc["function"]["arguments"], dict) else tc["function"]["arguments"],
                    ),
                )
                tool_calls.append(tool_call)
            if tool_calls:
                return tool_calls
    except (json.JSONDecodeError, KeyError):
        pass
    
    # パターン3: 関数呼び出し形式を検出 (例: file_ops_read_file({"path": "test.txt"}))
    # 利用可能なツール名のリストを取得（後で使用）
    available_tools = get_available_tools()
    tool_names = [tool.function.name for tool in available_tools]
    
    # 関数呼び出しパターンを検索: function_name({...}) または function_name(...)
    for tool_name in tool_names:
        # パターン: tool_name({"param": "value"}) または tool_name({...})
        pattern = rf'\b{re.escape(tool_name)}\s*\(\s*(\{{[^}}]*\}})\s*\)'
        match = re.search(pattern, text, re.DOTALL)
        if match:
            try:
                params_str = match.group(1)
                params = json.loads(params_str)
                tool_call = ToolCall(
                    id=str(uuid.uuid4()),
                    type="function",
                    function=FunctionCall(
                        name=tool_name,
                        arguments=json.dumps(params),
                    ),
                )
                return [tool_call]
            except json.JSONDecodeError:
                continue
    
    # パターン4は削除: 自然言語からの関数名抽出は誤検出が多すぎるため
    # 明示的なJSON形式または関数呼び出し形式（パターン1-3）のみを使用する

    return None


async def execute_tool_calls(tool_calls: List[ToolCall]) -> List[Message]:
    """tool_callsを実行して結果をメッセージに追加

    Args:
        tool_calls: 実行するToolCallのリスト

    Returns:
        実行結果を含むMessageのリスト（tool role）
    """
    tool_messages = []

    # 登録済みスキル名を取得（長い順にソートして最長一致を優先）
    registered_skills = [s["name"] for s in skill_manager.list_skills()]
    registered_skills.sort(key=len, reverse=True)

    for tool_call in tool_calls:
        function_name = tool_call.function.name

        # function_nameは "skill_name_action_name" 形式
        # スキル名自体にアンダースコアが含まれる場合があるため、
        # 登録済みスキル名と最長一致でマッチングする
        skill_name = None
        action_name = None

        for skill in registered_skills:
            prefix = f"{skill}_"
            if function_name.startswith(prefix):
                skill_name = skill
                action_name = function_name[len(prefix):]
                break

        if skill_name is None or action_name is None:
            # 形式が正しくない場合はエラー
            error_result = {
                "status": "error",
                "error": f"Invalid function name format: {function_name}",
                "message": "関数名の形式が正しくありません",
            }
            tool_messages.append(
                Message(
                    role="tool",
                    content=json.dumps(error_result, ensure_ascii=False),
                    tool_call_id=tool_call.id,
                )
            )
            continue
        
        # パラメータを解析
        try:
            params = json.loads(tool_call.function.arguments)
        except json.JSONDecodeError:
            params = {}
        
        # スキルを実行
        result = await skill_manager.execute(
            skill_name=skill_name,
            action=action_name,
            params=params,
        )
        
        # 結果をJSON形式でメッセージに追加
        result_dict = result.to_dict()
        tool_messages.append(
            Message(
                role="tool",
                content=json.dumps(result_dict, ensure_ascii=False),
                tool_call_id=tool_call.id,
            )
        )
    
    return tool_messages


# ==== Endpoints ====

@router.post("/chat/completions")
@limiter.limit(f"{config.rate_limit_requests}/{config.rate_limit_period}")
async def create_chat_completion(request: Request, req: ChatCompletionRequest):
    """OpenAI互換 Chat Completions

    - stream=false: 通常の1レスポンス
    - stream=true : OpenAI風のSSEストリーミング（真のStreaming）
    - tools: Function Calling対応（スキルを自動的に利用可能なtoolsとして提供）
    """

    # toolsが指定されていない場合、有効なスキルを自動的にtoolsとして提供
    available_tools = req.tools
    if available_tools is None and config.skills_enabled and req.tool_choice != "none":
        available_tools = get_available_tools()

    # プロンプトテンプレートの適用
    messages_to_add = list(req.messages)

    # prompt_typeが指定されている場合、システムメッセージを生成
    if req.prompt_type:
        try:
            prompt_type_enum = PromptType(req.prompt_type)

            # ユーザーメッセージの最後のコンテンツを取得（コードとして扱う）
            last_user_message = None
            for m in reversed(req.messages):
                if m.role == "user":
                    last_user_message = m.content
                    break

            if last_user_message:
                # 言語を検出
                language = detect_language(last_user_message)

                # テンプレートを生成
                template_prompt = PromptTemplate.format(
                    prompt_type=prompt_type_enum,
                    language=language,
                    code=last_user_message,
                    context=last_user_message,
                )

                # システムメッセージとして先頭に挿入
                system_message = Message(role="system", content=template_prompt)
                messages_to_add = [system_message] + messages_to_add
        except (ValueError, KeyError) as e:
            # 無効なprompt_typeの場合は無視
            pass

    # 会話メモリに追加（tool roleは除外）
    for m in messages_to_add:
        if m.role != "tool" and m.content:
            memory.add(m.role, m.content)

    prompt = memory.as_prompt()

    # toolsがある場合、プロンプトにtools情報を追加
    if available_tools:
        tools_description = "\n\n=== 利用可能なツール ===\n"
        tools_description += "【重要】ツールは、ユーザーが明示的にファイル操作やコード実行などを依頼した場合のみ使用してください。\n"
        tools_description += "挨拶、質問、雑談などの通常の会話では、ツールを使わずに普通のテキストで応答してください。\n\n"
        tools_description += "ツールを使用する場合は、以下のJSON形式で応答してください:\n"
        tools_description += '```json\n{\n  "tool_calls": [\n    {\n      "id": "call_xxx",\n      "function": {\n        "name": "ツール名",\n        "arguments": {"パラメータ名": "値"}\n      }\n    }\n  ]\n}\n```\n\n'
        tools_description += "利用可能なツール一覧:\n"
        for tool in available_tools:
            func = tool.function
            tools_description += f"\n【{func.name}】\n"
            tools_description += f"説明: {func.description}\n"
            tools_description += f"パラメータ: {json.dumps(func.parameters, ensure_ascii=False, indent=2)}\n"
        prompt = f"{prompt}{tools_description}"

    # 非Streaming
    if not req.stream:
        # 同時実行数制限を適用
        async with concurrency_limiter:
            max_iterations = 5  # 無限ループ防止
            current_messages = messages_to_add.copy()
            
            for iteration in range(max_iterations):
                # 現在のメッセージからプロンプトを生成
                current_prompt = "\n".join([
                    f"{m.role}: {m.content}" if m.content else f"{m.role}:"
                    for m in current_messages
                    if m.role != "tool"
                ]) + "\nassistant:"
                
                if available_tools:
                    tools_description = "\n\n=== 利用可能なツール ===\n"
                    tools_description += "【重要】ツールは、ユーザーが明示的にファイル操作やコード実行などを依頼した場合のみ使用してください。\n"
                    tools_description += "挨拶、質問、雑談などの通常の会話では、ツールを使わずに普通のテキストで応答してください。\n\n"
                    tools_description += "ツールを使用する場合は、以下のJSON形式で応答してください:\n"
                    tools_description += '```json\n{\n  "tool_calls": [\n    {\n      "id": "call_xxx",\n      "function": {\n        "name": "ツール名",\n        "arguments": {"パラメータ名": "値"}\n      }\n    }\n  ]\n}\n```\n\n'
                    tools_description += "利用可能なツール一覧:\n"
                    for tool in available_tools:
                        func = tool.function
                        tools_description += f"\n【{func.name}】\n"
                        tools_description += f"説明: {func.description}\n"
                        tools_description += f"パラメータ: {json.dumps(func.parameters, ensure_ascii=False, indent=2)}\n"
                    current_prompt = f"{current_prompt}{tools_description}"
                
                result = inference_service.chat(
                    prompt=current_prompt,
                    model_name=req.model,
                    temperature=req.temperature,
                    max_tokens=req.max_tokens,
                )

                text: str = result["text"]
                usage_raw = result["usage"]

                # tool_callsを検出
                tool_calls = parse_tool_call_from_text(text)
                
                if tool_calls and available_tools:
                    # tool_callsがある場合、スキルを実行
                    assistant_message = Message(
                        role="assistant",
                        content=text,
                        tool_calls=tool_calls,
                    )
                    current_messages.append(assistant_message)
                    
                    # スキルを実行して結果を追加
                    tool_messages = await execute_tool_calls(tool_calls)
                    current_messages.extend(tool_messages)
                    
                    # メモリにassistant応答を追加（tool_callsを含む）
                    memory.add("assistant", text)
                    
                    # 次のイテレーションで再推論
                    continue
                else:
                    # tool_callsがない場合、通常の応答として返す
                    assistant_message = Message(role="assistant", content=text)
                    current_messages.append(assistant_message)
                    memory.add("assistant", text)
                    
                    usage = Usage(
                        prompt_tokens=usage_raw.get("prompt_tokens"),
                        completion_tokens=usage_raw.get("completion_tokens"),
                        total_tokens=usage_raw.get("total_tokens"),
                    )

                    finish_reason = "tool_calls" if tool_calls else "stop"
                    choice = ChatCompletionChoice(
                        index=0,
                        message=assistant_message,
                        finish_reason=finish_reason,
                    )

                    resp = ChatCompletionResponse(
                        id=f"ixv-chat-{uuid.uuid4()}",
                        created=int(time.time()),
                        model=req.model,
                        choices=[choice],
                        usage=usage,
                    )
                    return resp
            
            # 最大イテレーションに達した場合、最後の応答を返す
            last_message = current_messages[-1] if current_messages else Message(role="assistant", content="")
            usage = Usage(
                prompt_tokens=usage_raw.get("prompt_tokens"),
                completion_tokens=usage_raw.get("completion_tokens"),
                total_tokens=usage_raw.get("total_tokens"),
            )
            choice = ChatCompletionChoice(
                index=0,
                message=last_message,
                finish_reason="stop",
            )
            resp = ChatCompletionResponse(
                id=f"ixv-chat-{uuid.uuid4()}",
                created=int(time.time()),
                model=req.model,
                choices=[choice],
                usage=usage,
            )
            return resp

    # Streaming（OpenAI風 SSE - 真のストリーミング）
    async def stream_generator() -> AsyncGenerator[bytes, None]:
        # 同時実行数制限を適用
        async with concurrency_limiter:
            created = int(time.time())
            chat_id = f"ixv-chat-{uuid.uuid4()}"

            # まずはヘッダだけのチャンクを1つ送る（deltaは空）
            first_chunk = {
                "id": chat_id,
                "object": "chat.completion.chunk",
                "created": created,
                "model": req.model,
                "choices": [
                    {
                        "index": 0,
                        "delta": {"role": "assistant", "content": ""},
                        "finish_reason": None,
                    }
                ],
            }
            yield f"data: {json.dumps(first_chunk, ensure_ascii=False)}\n\n".encode("utf-8")

            # llama.cppからリアルタイムストリーミング
            full_text = ""
            stream_error = None

            for chunk_data in inference_service.stream_chat(
                prompt=prompt,
                model_name=req.model,
                temperature=req.temperature,
                max_tokens=req.max_tokens,
            ):
                # エラーチェック
                if "error" in chunk_data:
                    stream_error = chunk_data
                    # エラーをSSEで送信
                    error_chunk = {
                        "id": chat_id,
                        "object": "error",
                        "error": {
                            "message": chunk_data.get("error", "Unknown streaming error"),
                            "type": chunk_data.get("type", "streaming_error"),
                        }
                    }
                    yield f"data: {json.dumps(error_chunk, ensure_ascii=False)}\n\n".encode("utf-8")
                    break

                content = chunk_data.get("content", "")
                full_text += content

                # 空のチャンクはスキップ
                if not content:
                    continue

                chunk = {
                    "id": chat_id,
                    "object": "chat.completion.chunk",
                    "created": created,
                    "model": req.model,
                    "choices": [
                        {
                            "index": 0,
                            "delta": {"content": content},
                            "finish_reason": None,
                        }
                    ],
                }
                yield f"data: {json.dumps(chunk, ensure_ascii=False)}\n\n".encode("utf-8")

            # エラーがなければメモリに追加して終了
            if stream_error is None:
                # tool_callsを検出
                tool_calls = parse_tool_call_from_text(full_text)
                
                if tool_calls and available_tools:
                    # tool_callsがある場合、スキルを実行
                    # まず、assistantメッセージをtool_calls付きで送信
                    assistant_chunk = {
                        "id": chat_id,
                        "object": "chat.completion.chunk",
                        "created": created,
                        "model": req.model,
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "role": "assistant",
                                    "content": None,
                                    "tool_calls": [
                                        {
                                            "id": tc.id,
                                            "type": "function",
                                            "function": {
                                                "name": tc.function.name,
                                                "arguments": tc.function.arguments,
                                            },
                                        }
                                        for tc in tool_calls
                                    ],
                                },
                                "finish_reason": "tool_calls",
                            }
                        ],
                    }
                    yield f"data: {json.dumps(assistant_chunk, ensure_ascii=False)}\n\n".encode("utf-8")
                    
                    # スキルを実行
                    tool_messages = await execute_tool_calls(tool_calls)
                    
                    # toolメッセージを送信
                    for tool_msg in tool_messages:
                        tool_chunk = {
                            "id": chat_id,
                            "object": "chat.completion.chunk",
                            "created": created,
                            "model": req.model,
                            "choices": [
                                {
                                    "index": 0,
                                    "delta": {
                                        "role": "tool",
                                        "content": tool_msg.content,
                                        "tool_call_id": tool_msg.tool_call_id,
                                    },
                                    "finish_reason": None,
                                }
                            ],
                        }
                        yield f"data: {json.dumps(tool_chunk, ensure_ascii=False)}\n\n".encode("utf-8")
                    
                    # メモリにassistant応答を追加
                    memory.add("assistant", full_text)
                    
                    # 最後に finish_reason=stop のチャンクを送信
                    final_chunk = {
                        "id": chat_id,
                        "object": "chat.completion.chunk",
                        "created": created,
                        "model": req.model,
                        "choices": [
                            {
                                "index": 0,
                                "delta": {},
                                "finish_reason": "stop",
                            }
                        ],
                    }
                    yield f"data: {json.dumps(final_chunk, ensure_ascii=False)}\n\n".encode("utf-8")
                else:
                    # tool_callsがない場合、通常の応答として処理
                    # メモリにassistant応答を追加
                    memory.add("assistant", full_text)

                    # 最後に finish_reason=stop のチャンクを送信
                    final_chunk = {
                        "id": chat_id,
                        "object": "chat.completion.chunk",
                        "created": created,
                        "model": req.model,
                        "choices": [
                            {
                                "index": 0,
                                "delta": {},
                                "finish_reason": "stop",
                            }
                        ],
                    }
                    yield f"data: {json.dumps(final_chunk, ensure_ascii=False)}\n\n".encode("utf-8")

                # OpenAI互換 [DONE]
                yield b"data: [DONE]\n\n"

    return StreamingResponse(stream_generator(), media_type="text/event-stream")


@router.get("/models", response_model=ModelsResponse)
async def list_models():
    """利用可能なモデル一覧を返す（Openβでは固定1件）"""

    models: List[ModelInfo] = [
        ModelInfo(
            id="ixv-model",
            owned_by="ixv-local",
        )
    ]
    return ModelsResponse(data=models)
