"""同時実行数制限

推論リクエストの同時実行数を制限し、
リソースの過剰使用を防ぐ。
"""

import asyncio
import logging
from typing import Optional

from app.config import config

_log = logging.getLogger("ixv-core.concurrency")


class ConcurrencyLimiter:
    """同時実行数を制限するセマフォベースのリミッター"""

    def __init__(self, max_concurrent: int):
        """
        Args:
            max_concurrent: 同時実行可能な最大数
        """
        self.max_concurrent = max_concurrent
        self._semaphore: Optional[asyncio.Semaphore] = None
        self._active_count = 0

    def _ensure_semaphore(self):
        """セマフォの遅延初期化"""
        if self._semaphore is None:
            self._semaphore = asyncio.Semaphore(self.max_concurrent)

    async def __aenter__(self):
        """コンテキストマネージャーのエントリ（即時エラー方式）"""
        self._ensure_semaphore()
        # 即座にセマフォを取得できるかチェック
        if self._semaphore.locked():
            from app.exceptions import ConcurrencyLimitError
            raise ConcurrencyLimitError(
                max_concurrent=self.max_concurrent,
                active_count=self._active_count,
            )
        await self._semaphore.acquire()
        self._active_count += 1
        _log.debug(f"Inference started. Active: {self._active_count}/{self.max_concurrent}")
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """コンテキストマネージャーの終了"""
        self._semaphore.release()
        self._active_count -= 1
        _log.debug(f"Inference finished. Active: {self._active_count}/{self.max_concurrent}")

    def get_active_count(self) -> int:
        """現在の同時実行数を取得"""
        return self._active_count

    def get_max_concurrent(self) -> int:
        """最大同時実行数を取得"""
        return self.max_concurrent


# グローバルインスタンス
concurrency_limiter = ConcurrencyLimiter(max_concurrent=config.max_concurrent_inferences)
