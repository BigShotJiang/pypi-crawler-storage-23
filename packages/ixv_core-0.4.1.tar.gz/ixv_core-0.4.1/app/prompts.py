"""プロンプトテンプレート管理

用途別のプロンプトテンプレートを提供し、
LLMへの指示を体系的に管理する。
"""

from typing import Optional
from enum import Enum


class PromptType(str, Enum):
    """プロンプトタイプの定義"""

    GENERAL = "general"
    CODE_COMPLETION = "code_completion"
    CODE_EXPLANATION = "code_explanation"
    CODE_REVIEW = "code_review"
    BUG_FIX = "bug_fix"
    REFACTORING = "refactoring"


class PromptTemplate:
    """プロンプトテンプレートクラス

    用途に応じたプロンプトを生成する。
    """

    # 汎用会話テンプレート
    GENERAL = """あなたは親切で有能なアシスタントです。
ユーザーの質問に対して、正確で分かりやすい回答を提供してください。

{context}"""

    # コード補完テンプレート
    CODE_COMPLETION = """あなたはプログラミングアシスタントです。
以下のコードの続きを予測して補完してください。

言語: {language}
現在のコード:
```{language}
{code}
```

続きのコードを生成してください（説明は不要、コードのみを出力）:"""

    # コード説明テンプレート
    CODE_EXPLANATION = """あなたはプログラミングの専門家です。
以下のコードを{language}で簡潔に説明してください。

コード:
```{language}
{code}
```

説明（日本語で簡潔に）:"""

    # コードレビューテンプレート
    CODE_REVIEW = """あなたはコードレビューの専門家です。
以下のコードをレビューし、改善点を指摘してください。

言語: {language}
コード:
```{language}
{code}
```

レビュー観点:
- バグや潜在的な問題
- パフォーマンスの改善点
- 可読性の向上
- セキュリティの問題

レビュー結果:"""

    # バグ修正テンプレート
    BUG_FIX = """あなたはデバッグの専門家です。
以下のコードにバグがあります。問題を特定し、修正してください。

言語: {language}
エラー内容: {error}

コード:
```{language}
{code}
```

修正案（説明と修正後のコード）:"""

    # リファクタリングテンプレート
    REFACTORING = """あなたはコードリファクタリングの専門家です。
以下のコードをより良い設計にリファクタリングしてください。

言語: {language}
コード:
```{language}
{code}
```

改善観点:
- 可読性の向上
- 保守性の向上
- 設計パターンの適用
- DRY原則の適用

リファクタリング後のコード:"""

    @classmethod
    def format(
        cls,
        prompt_type: PromptType,
        language: Optional[str] = None,
        code: Optional[str] = None,
        error: Optional[str] = None,
        context: Optional[str] = None,
    ) -> str:
        """指定されたタイプのプロンプトをフォーマットする

        Args:
            prompt_type: プロンプトのタイプ
            language: プログラミング言語（コード関連のプロンプトで使用）
            code: コード内容
            error: エラー内容（バグ修正で使用）
            context: 追加のコンテキスト（汎用会話で使用）

        Returns:
            フォーマットされたプロンプト文字列
        """
        template_map = {
            PromptType.GENERAL: cls.GENERAL,
            PromptType.CODE_COMPLETION: cls.CODE_COMPLETION,
            PromptType.CODE_EXPLANATION: cls.CODE_EXPLANATION,
            PromptType.CODE_REVIEW: cls.CODE_REVIEW,
            PromptType.BUG_FIX: cls.BUG_FIX,
            PromptType.REFACTORING: cls.REFACTORING,
        }

        template = template_map.get(prompt_type, cls.GENERAL)

        # テンプレート変数を置換
        kwargs = {}
        if language is not None:
            kwargs["language"] = language
        if code is not None:
            kwargs["code"] = code
        if error is not None:
            kwargs["error"] = error
        if context is not None:
            kwargs["context"] = context

        # テンプレート内に存在する変数のみ置換
        try:
            return template.format(**kwargs)
        except KeyError as e:
            # 必要な変数が不足している場合はエラー
            raise ValueError(
                f"Missing required template variable: {e}. "
                f"Prompt type '{prompt_type}' requires specific parameters."
            )

    @classmethod
    def get_available_types(cls) -> list[str]:
        """利用可能なプロンプトタイプの一覧を取得"""
        return [t.value for t in PromptType]


# ユーティリティ関数
def detect_language(code: str) -> str:
    """コードから言語を推定する

    簡易的な推定なので、正確性は保証されない。

    Args:
        code: コード文字列

    Returns:
        推定された言語名
    """
    code_lower = code.lower()

    # Python
    if "def " in code or "import " in code or "from " in code or "class " in code:
        if ":" in code:  # インデントベースの可能性が高い
            return "python"

    # JavaScript/TypeScript
    if "function" in code or "const " in code or "let " in code or "var " in code:
        if "=>" in code or "async" in code:
            return "javascript"

    # Java
    if "public class" in code or "private " in code or "protected " in code:
        if "void " in code or "String " in code:
            return "java"

    # C/C++
    if "#include" in code or "int main" in code:
        return "c"

    # Go
    if "package " in code or "func " in code:
        return "go"

    # Rust
    if "fn " in code or "let mut" in code or "impl " in code:
        return "rust"

    # Ruby
    if "end" in code and ("def " in code or "class " in code):
        return "ruby"

    # デフォルト
    return "unknown"
