"""IXV-Core Application Package"""

from pathlib import Path


def _read_version() -> str:
    """VERSIONファイルからバージョンを読み込む"""
    # ルートのVERSIONファイルを読み込む
    # app/__init__.py -> app/ -> ixv-core/ -> ixv/ -> VERSION
    try:
        # __file__が存在する場合（通常のインポート時）
        current_file = Path(__file__).resolve()
        # app/__init__.py -> app/ -> ixv-core/ -> ixv/ (ルート)
        root_dir = current_file.parent.parent.parent
        version_file = root_dir / "VERSION"
        
        if version_file.exists():
            return version_file.read_text().strip()
    except (AttributeError, OSError):
        # __file__が存在しない場合（特殊な環境）
        pass
    
    # フォールバック: pyproject.tomlから読み込む
    try:
        current_file = Path(__file__).resolve()
        pyproject_file = current_file.parent.parent / "pyproject.toml"
        if pyproject_file.exists():
            try:
                import tomllib  # Python 3.11+
                with open(pyproject_file, "rb") as f:
                    data = tomllib.load(f)
                    return data.get("project", {}).get("version", "0.0.0")
            except ImportError:
                try:
                    import tomli  # フォールバック
                    with open(pyproject_file, "rb") as f:
                        data = tomli.load(f)
                        return data.get("project", {}).get("version", "0.0.0")
                except (ImportError, Exception):
                    pass
    except (AttributeError, OSError):
        pass
    
    return "0.0.0"


__version__ = _read_version()
