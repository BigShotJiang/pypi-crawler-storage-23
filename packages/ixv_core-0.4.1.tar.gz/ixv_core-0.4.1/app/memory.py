"""IXV-Core 会話メモリ管理

NOTE: Openβ版はシングルユーザー想定。
全クライアントでメモリを共有する。
"""

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Dict, Optional

from app.config import config

_log = logging.getLogger("ixv-core.memory")


@dataclass
class ConversationMemory:
    """シンプルな会話メモリ（直近Nターンを保持）

    オプションで永続化をサポート。
    """

    max_turns: int = config.max_memory_turns
    _history: List[Dict[str, str]] = field(default_factory=list)
    _persistence_enabled: bool = False
    _persistence_file: Optional[Path] = None

    def __post_init__(self):
        """永続化が有効な場合、起動時にファイルから読み込む"""
        if self._persistence_enabled and self._persistence_file:
            self._load_from_file()

    def enable_persistence(self, file_path: Optional[Path] = None) -> None:
        """永続化を有効化

        Args:
            file_path: 保存先ファイルパス。Noneの場合はデフォルト
        """
        if file_path is None:
            file_path = Path.home() / ".ixv" / "memory.json"

        self._persistence_file = file_path
        self._persistence_enabled = True

        # ディレクトリが存在しない場合は作成
        self._persistence_file.parent.mkdir(parents=True, exist_ok=True)

        # 既存のファイルから読み込み
        self._load_from_file()

        _log.info(f"Memory persistence enabled: {self._persistence_file}")

    def disable_persistence(self) -> None:
        """永続化を無効化"""
        self._persistence_enabled = False
        _log.info("Memory persistence disabled")

    def _load_from_file(self) -> None:
        """ファイルからメモリを読み込む"""
        if not self._persistence_file or not self._persistence_file.exists():
            return

        try:
            with open(self._persistence_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                self._history = data.get("history", [])
                _log.info(f"Loaded {len(self._history)} messages from {self._persistence_file}")
        except Exception as e:
            _log.warning(f"Failed to load memory from file: {e}")

    def _save_to_file(self) -> None:
        """ファイルにメモリを保存"""
        if not self._persistence_enabled or not self._persistence_file:
            return

        try:
            with open(self._persistence_file, "w", encoding="utf-8") as f:
                json.dump({"history": self._history}, f, ensure_ascii=False, indent=2)
        except Exception as e:
            _log.error(f"Failed to save memory to file: {e}")

    def add(self, role: str, content: str) -> None:
        self._history.append({"role": role, "content": content})
        # 上限を越えたら古いものから削除
        if len(self._history) > self.max_turns:
            overflow = len(self._history) - self.max_turns
            if overflow > 0:
                self._history = self._history[overflow:]

        # 永続化が有効な場合はファイルに保存
        if self._persistence_enabled:
            self._save_to_file()

    def as_prompt(self) -> str:
        """llama.cpp に渡すための素朴なプロンプト文字列に変換"""
        lines = []
        for m in self._history:
            lines.append(f"{m['role']}: {m['content']}")
        lines.append("assistant:")
        return "\n".join(lines)

    def get_history(self) -> List[Dict[str, str]]:
        return list(self._history)

    def clear(self) -> None:
        self._history.clear()
        # 永続化が有効な場合はファイルもクリア
        if self._persistence_enabled:
            self._save_to_file()


# グローバルメモリインスタンス（シングルトン）
memory = ConversationMemory()
