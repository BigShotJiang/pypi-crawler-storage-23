"""IXV-Core 設定管理"""

import os
import logging
from pathlib import Path
from dataclasses import dataclass
from typing import Dict, Any, Optional

# 標準 logging の設定
_log = logging.getLogger("ixv-core")


def _parse_int_env(name: str, default: int, min_val: int = 1, max_val: Optional[int] = None) -> int:
    """環境変数から整数を安全にパースする"""
    raw = os.getenv(name)
    if raw is None:
        return default
    try:
        value = int(raw)
        if value < min_val:
            _log.warning(f"{name}={value} is below minimum ({min_val}), using default {default}")
            return default
        if max_val is not None and value > max_val:
            _log.warning(f"{name}={value} exceeds maximum ({max_val}), using default {default}")
            return default
        return value
    except ValueError:
        _log.warning(f"Invalid {name}={raw}, using default {default}")
        return default


@dataclass
class IXVConfig:
    """IXV-Core の設定"""

    # モデル設定
    model_path: str
    n_ctx: int = 8192
    n_threads: int = 8
    n_gpu_layers: int = -1  # -1 = 全レイヤーをGPUに、0 = CPUのみ

    # サーバー設定
    host: str = "0.0.0.0"
    port: int = 8000

    # ログ設定
    log_dir: Path = Path.home() / ".ixv" / "logs"
    log_messages: bool = False  # プロンプト/応答全文をログに含めるか

    # メモリ設定
    max_memory_turns: int = 10
    memory_persistence_enabled: bool = False  # 会話メモリの永続化

    # デバッグ設定
    debug_mode: bool = False  # デバッグモード（設定エンドポイントの詳細表示など）

    # レート制限設定
    rate_limit_enabled: bool = True  # レート制限の有効化
    rate_limit_requests: int = 10  # 制限期間内のリクエスト数
    rate_limit_period: str = "minute"  # 制限期間（second, minute, hour, day）

    # 同時実行数制限
    max_concurrent_inferences: int = 2  # 同時に実行可能な推論数

    # スキル設定（基本）
    skills_enabled: bool = True
    skills_base_dir: Optional[str] = None  # ファイル操作の基準ディレクトリ
    skills_working_dir: Optional[str] = None  # コード実行・Git操作の作業ディレクトリ
    skills_max_file_size: int = 1024 * 1024  # 最大ファイルサイズ（1MB）
    skills_exec_timeout: int = 30  # コード実行タイムアウト（秒）

    # スキル設定（RAG）
    skills_rag_store_path: Optional[str] = None  # RAGストアのパス
    skills_rag_chunk_size: int = 500  # チャンクサイズ（文字数）
    skills_rag_chunk_overlap: int = 50  # チャンクオーバーラップ（文字数）

    # スキル設定（Web検索）
    skills_web_search_timeout: int = 10  # Web検索タイムアウト（秒）
    skills_web_search_max_results: int = 10  # 最大検索結果数

    # スキル設定（個別有効/無効）
    skills_enabled_list: Optional[str] = None  # カンマ区切りの有効なスキル名（例: "file_ops,code_exec"）
    skills_disabled_list: Optional[str] = None  # カンマ区切りの無効なスキル名（例: "web_search,rag")

    def get_public_config(self) -> Dict[str, Any]:
        """公開可能な設定のみを返す（機密情報を除外）"""
        return {
            "n_ctx": self.n_ctx,
            "n_threads": self.n_threads,
            "n_gpu_layers": self.n_gpu_layers,
            "port": self.port,
            "max_memory_turns": self.max_memory_turns,
            "rate_limit_enabled": self.rate_limit_enabled,
            "max_concurrent_inferences": self.max_concurrent_inferences,
            "skills_enabled": self.skills_enabled,
            "model_loaded": True,  # 実際の状態は呼び出し側で上書き可能
        }

    def get_debug_config(self) -> Dict[str, Any]:
        """デバッグモード用の詳細設定を返す"""
        return {
            "model_path": str(self.model_path),
            "n_ctx": self.n_ctx,
            "n_threads": self.n_threads,
            "n_gpu_layers": self.n_gpu_layers,
            "host": self.host,
            "port": self.port,
            "log_dir": str(self.log_dir),
            "log_messages": self.log_messages,
            "max_memory_turns": self.max_memory_turns,
            "debug_mode": self.debug_mode,
            "rate_limit_enabled": self.rate_limit_enabled,
            "rate_limit": f"{self.rate_limit_requests}/{self.rate_limit_period}",
            "max_concurrent_inferences": self.max_concurrent_inferences,
            "skills_enabled": self.skills_enabled,
            "skills_base_dir": self.skills_base_dir,
            "skills_working_dir": self.skills_working_dir,
        }

    @classmethod
    def from_env(cls) -> "IXVConfig":
        """環境変数から設定を生成"""

        # ログディレクトリ（デフォルトは ~/.ixv/logs）
        default_log_dir = Path.home() / ".ixv" / "logs"
        log_dir_env = os.getenv("IXV_LOG_DIR")
        log_dir = Path(log_dir_env) if log_dir_env else default_log_dir

        # スキル設定
        skills_base_dir = os.getenv("IXV_SKILLS_BASE_DIR")
        skills_working_dir = os.getenv("IXV_SKILLS_WORKING_DIR")
        skills_rag_store_path = os.getenv("IXV_SKILLS_RAG_STORE_PATH")
        skills_enabled_list = os.getenv("IXV_SKILLS_ENABLED_LIST")
        skills_disabled_list = os.getenv("IXV_SKILLS_DISABLED_LIST")

        return cls(
            model_path=os.getenv("IXV_MODEL_PATH", "models/ixv-model.gguf"),
            n_ctx=_parse_int_env("IXV_N_CTX", 4096, min_val=512, max_val=32768),
            n_threads=_parse_int_env("IXV_N_THREADS", 8, min_val=1, max_val=128),
            n_gpu_layers=_parse_int_env("IXV_N_GPU_LAYERS", -1, min_val=-1, max_val=200),
            host=os.getenv("IXV_HOST", "0.0.0.0"),
            port=_parse_int_env("IXV_PORT", 8000, min_val=1, max_val=65535),
            log_dir=log_dir,
            log_messages=os.getenv("IXV_LOG_MESSAGES", "false").lower() == "true",
            max_memory_turns=_parse_int_env("IXV_MAX_MEMORY_TURNS", 10, min_val=1, max_val=100),
            memory_persistence_enabled=os.getenv("IXV_MEMORY_PERSISTENCE", "false").lower() == "true",
            debug_mode=os.getenv("IXV_DEBUG", "false").lower() == "true",
            rate_limit_enabled=os.getenv("IXV_RATE_LIMIT_ENABLED", "true").lower() == "true",
            rate_limit_requests=_parse_int_env("IXV_RATE_LIMIT_REQUESTS", 10, min_val=1, max_val=1000),
            rate_limit_period=os.getenv("IXV_RATE_LIMIT_PERIOD", "minute"),
            max_concurrent_inferences=_parse_int_env("IXV_MAX_CONCURRENT_INFERENCES", 2, min_val=1, max_val=10),
            skills_enabled=os.getenv("IXV_SKILLS_ENABLED", "true").lower() == "true",
            skills_base_dir=skills_base_dir,
            skills_working_dir=skills_working_dir,
            skills_max_file_size=int(
                os.getenv("IXV_SKILLS_MAX_FILE_SIZE", str(1024 * 1024))
            ),
            skills_exec_timeout=int(os.getenv("IXV_SKILLS_EXEC_TIMEOUT", "30")),
            skills_rag_store_path=skills_rag_store_path,
            skills_rag_chunk_size=int(
                os.getenv("IXV_SKILLS_RAG_CHUNK_SIZE", "500")
            ),
            skills_rag_chunk_overlap=int(
                os.getenv("IXV_SKILLS_RAG_CHUNK_OVERLAP", "50")
            ),
            skills_web_search_timeout=int(
                os.getenv("IXV_SKILLS_WEB_SEARCH_TIMEOUT", "10")
            ),
            skills_web_search_max_results=int(
                os.getenv("IXV_SKILLS_WEB_SEARCH_MAX_RESULTS", "10")
            ),
            skills_enabled_list=skills_enabled_list,
            skills_disabled_list=skills_disabled_list,
        )


# グローバル設定インスタンス
config = IXVConfig.from_env()
