"""IXV-Core 独自APIルーター"""

from fastapi import APIRouter, Query

from app.logger import logger
from app.memory import memory
from app.config import config
from app.model_loader import ModelLoader
from app.prompts import PromptTemplate

router = APIRouter(prefix="/ixv", tags=["ixv"])


@router.get("/health")
async def health():
    return {"status": "ok"}


@router.get("/logs")
async def get_logs(limit: int = Query(100, ge=1, le=1000)):
    """直近ログを取得"""
    logs = logger.get_recent(limit=limit)
    return {"logs": logs}


@router.get("/memory")
async def get_memory():
    """現在の会話メモリを取得"""
    return {"history": memory.get_history(), "max_turns": memory.max_turns}


@router.post("/memory/clear")
async def clear_memory():
    """会話メモリをクリア"""
    memory.clear()
    return {"status": "cleared"}


@router.get("/config")
async def get_config():
    """現在の設定を返す

    デバッグモード (IXV_DEBUG=true) の場合は詳細情報を返す。
    通常モードでは機密情報を除外した公開設定のみを返す。
    """
    if config.debug_mode:
        return config.get_debug_config()

    public_config = config.get_public_config()
    public_config["model_loaded"] = ModelLoader.is_loaded()
    return public_config


@router.get("/model/info")
async def get_model_info():
    """モデルのメタデータを取得

    モデルがロードされている場合、詳細情報を返す。
    """
    if not ModelLoader.is_loaded():
        return {
            "model_loaded": False,
            "message": "Model not loaded yet"
        }

    try:
        model = ModelLoader.get()
        info = ModelLoader.get_model_info()

        # llama.cppのメタデータを取得
        metadata = {}
        if hasattr(model, 'metadata') and model.metadata:
            # 利用可能なメタデータを抽出
            metadata = {
                "architecture": model.metadata.get("general.architecture", "unknown"),
                "name": model.metadata.get("general.name", "unknown"),
                "file_type": model.metadata.get("general.file_type", "unknown"),
            }

        # コンテキストとスレッド情報を追加
        result = {
            "model_loaded": True,
            "path": info.get("path", "unknown"),
            "n_ctx": config.n_ctx,
            "n_threads": config.n_threads,
            "n_gpu_layers": config.n_gpu_layers,
            "metadata": metadata,
        }

        # vocab sizeなどの追加情報
        if hasattr(model, 'n_vocab'):
            result["n_vocab"] = model.n_vocab()

        return result

    except Exception as e:
        return {
            "model_loaded": True,
            "error": str(e),
            "message": "Failed to retrieve model metadata"
        }


@router.get("/prompts/types")
async def get_prompt_types():
    """利用可能なプロンプトテンプレートのタイプ一覧を取得"""
    return {
        "prompt_types": PromptTemplate.get_available_types(),
        "description": {
            "general": "汎用会話",
            "code_completion": "コード補完",
            "code_explanation": "コード説明",
            "code_review": "コードレビュー",
            "bug_fix": "バグ修正",
            "refactoring": "リファクタリング",
        }
    }
