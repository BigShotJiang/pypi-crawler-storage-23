"""IXV-Core メインアプリケーション

ローカルLLMを OpenAI API互換で提供する FastAPI サーバー。
"""

import logging
import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import ValidationError as PydanticValidationError
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded

from app.config import config
from app.model_loader import ModelLoader
from app.rate_limiter import limiter
from app.router_openai import router as openai_router
from app.router_ixv import router as ixv_router
from app.router_skills import router as skills_router, init_skills
from app import __version__
from app.exceptions import (
    IXVCoreError,
    ModelLoadError,
    ModelNotLoadedError,
    InferenceError,
    ValidationError,
    ConcurrencyLimitError,
)

# logging 設定
logging.basicConfig(
    level=logging.DEBUG if config.debug_mode else logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
_log = logging.getLogger("ixv-core")


def create_app() -> FastAPI:
    app = FastAPI(title="IXV-Core", version=__version__)

    # CORS設定
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],  # Vite default port
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # レート制限をアプリに統合
    app.state.limiter = limiter
    app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

    # グローバル例外ハンドラー
    @app.exception_handler(IXVCoreError)
    async def ixv_core_error_handler(
        request: Request, exc: IXVCoreError
    ) -> JSONResponse:
        """IXV-Core カスタム例外のハンドラー（OpenAI互換形式）"""
        status_code = 500
        if isinstance(exc, ValidationError):
            status_code = 400
        elif isinstance(exc, ModelNotLoadedError):
            status_code = 503
        elif isinstance(exc, ConcurrencyLimitError):
            status_code = 503

        return JSONResponse(
            status_code=status_code,
            content={
                "error": {
                    "message": exc.message,
                    "type": exc.__class__.__name__,
                    "code": exc.code,
                }
            },
        )

    @app.exception_handler(PydanticValidationError)
    async def pydantic_validation_error_handler(
        request: Request, exc: PydanticValidationError
    ) -> JSONResponse:
        """Pydantic バリデーションエラーのハンドラー"""
        errors = exc.errors()
        message = "; ".join(
            f"{e.get('loc', ['unknown'])[-1]}: {e.get('msg', 'invalid')}"
            for e in errors
        )
        return JSONResponse(
            status_code=400,
            content={
                "error": {
                    "message": message,
                    "type": "ValidationError",
                    "code": "validation_error",
                }
            },
        )

    @app.exception_handler(Exception)
    async def general_exception_handler(
        request: Request, exc: Exception
    ) -> JSONResponse:
        """予期しない例外のハンドラー"""
        _log.error(f"Unhandled exception: {exc}", exc_info=True)
        return JSONResponse(
            status_code=500,
            content={
                "error": {
                    "message": f"Internal server error: {str(exc)}",
                    "type": "InternalError",
                    "code": "internal_error",
                }
            },
        )

    @app.on_event("startup")
    async def startup_event():
        # 起動時にモデルをロードしておく
        try:
            ModelLoader.load()
            _log.info("Model loaded successfully")
        except ModelLoadError as e:
            # ログ出力して起動は継続（リクエスト時にエラー）
            _log.warning(f"Model load failed: {e.message}. Server started without model.")

        # メモリ永続化の設定
        if config.memory_persistence_enabled:
            from app.memory import memory
            memory.enable_persistence()
            _log.info("Memory persistence enabled")

        # スキルを初期化
        if config.skills_enabled:
            try:
                init_skills()
                from app.skills.skill_manager import skill_manager
                skills_count = len(skill_manager.list_skills())
                _log.info(f"Skills initialized successfully: {skills_count} skills registered")
            except Exception as e:
                _log.error(f"Failed to initialize skills: {e}", exc_info=True)

    app.include_router(openai_router)
    app.include_router(ixv_router)

    # スキルルーターを追加
    if config.skills_enabled:
        app.include_router(skills_router)

    return app


app = create_app()


def main():
    """CLI entry point for ixv-core."""
    uvicorn.run(
        "app.main:app",
        host=config.host,
        port=config.port,
        reload=False,
        log_level="info",
    )


if __name__ == "__main__":
    main()
