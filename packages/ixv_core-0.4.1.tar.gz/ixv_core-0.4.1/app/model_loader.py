"""IXV-Core モデルローダー"""

import logging
from pathlib import Path
from typing import Optional, Dict, Any

from llama_cpp import Llama

from app.config import config
from app.exceptions import ModelLoadError, ModelNotLoadedError

_log = logging.getLogger("ixv-core.model")


class ModelLoader:
    """llama.cpp モデルの読み込みを管理"""

    _model: Optional[Llama] = None
    _model_path: Optional[Path] = None

    @classmethod
    def load(cls, model_path: Optional[str] = None) -> Llama:
        """モデルをロードして返す（既にロード済みなら再利用）"""

        if model_path is None:
            model_path = config.model_path

        path = Path(model_path)

        if cls._model is not None and cls._model_path == path:
            return cls._model

        # ファイル存在チェック
        if not path.exists():
            raise ModelLoadError(
                f"Model file not found: {path}",
                model_path=str(path),
            )

        _log.info(f"Loading model: {path}")
        _log.info(f"GPU layers: {config.n_gpu_layers} (-1 = all layers on GPU)")
        try:
            cls._model = Llama(
                model_path=str(path),
                n_ctx=config.n_ctx,
                n_threads=config.n_threads,
                n_gpu_layers=config.n_gpu_layers,
                verbose=False,
            )
        except Exception as e:
            raise ModelLoadError(
                f"Failed to load model: {e}",
                model_path=str(path),
            ) from e

        cls._model_path = path
        return cls._model

    @classmethod
    def get(cls) -> Llama:
        if cls._model is None:
            raise ModelNotLoadedError()
        return cls._model

    @classmethod
    def is_loaded(cls) -> bool:
        return cls._model is not None

    @classmethod
    def get_model_info(cls) -> Dict[str, Any]:
        """モデル情報の簡易取得"""

        info: Dict[str, Any] = {}
        if cls._model_path is not None:
            info["path"] = str(cls._model_path)
        # ここでは最小限。必要に応じてメタ情報を追加
        return info
