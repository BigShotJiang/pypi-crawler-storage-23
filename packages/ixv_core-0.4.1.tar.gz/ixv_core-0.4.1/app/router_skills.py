"""スキルAPIルーター"""

import logging
from typing import Any, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.config import config
from app.skills.code_exec import CodeExecSkill
from app.skills.file_ops import FileOpsSkill
from app.skills.git_ops import GitOpsSkill
from app.skills.rag import RAGSkill
from app.skills.skill_manager import skill_manager
from app.skills.web_search import WebSearchSkill

_log = logging.getLogger("ixv-core")
router = APIRouter(prefix="/ixv/skills", tags=["skills"])


def _try_import_checker_skills():
    """チェッカースキルをインポート（オプショナル）"""
    skills = []
    try:
        from app.skills.checker.coding_rules import CodingRulesSkill
        skills.append(CodingRulesSkill())
    except ImportError:
        pass
    try:
        from app.skills.checker.design_checker import DesignCheckerSkill
        skills.append(DesignCheckerSkill())
    except ImportError:
        pass
    return skills


# デフォルトで有効にするスキル（トークン数削減のため基本スキルのみ）
# 全スキルを有効にするとツール定義だけで約6,500トークン消費するため制限
DEFAULT_ENABLED_SKILLS = {"file_ops", "code_exec"}


def _get_skill_enabled_state(skill_name: str) -> bool:
    """設定からスキルの有効/無効状態を取得

    優先順位:
    1. skills_enabled_list が指定されている場合、そのリストに含まれるもののみ有効
    2. skills_disabled_list が指定されている場合、そのリストに含まれるものは無効
    3. デフォルトは DEFAULT_ENABLED_SKILLS に含まれるもののみ有効
    """
    # 有効リストが指定されている場合、そのリストに含まれるもののみ有効
    if config.skills_enabled_list:
        enabled_names = {s.strip() for s in config.skills_enabled_list.split(",")}
        return skill_name in enabled_names

    # 無効リストが指定されている場合、そのリストに含まれるものは無効
    if config.skills_disabled_list:
        disabled_names = {s.strip() for s in config.skills_disabled_list.split(",")}
        return skill_name not in disabled_names

    # デフォルトは基本スキルのみ有効（トークン数削減のため）
    return skill_name in DEFAULT_ENABLED_SKILLS


def init_skills():
    """スキルを初期化して登録"""
    # ファイル操作スキル
    try:
        file_ops = FileOpsSkill(
            base_dir=config.skills_base_dir,
            max_file_size=config.skills_max_file_size,
        )
        skill_manager.register(file_ops, enabled=_get_skill_enabled_state("file_ops"))
        _log.debug(f"Registered skill: file_ops")
    except Exception as e:
        _log.error(f"Failed to register file_ops skill: {e}", exc_info=True)

    # コード実行スキル
    try:
        code_exec = CodeExecSkill(
            timeout=config.skills_exec_timeout,
            working_dir=config.skills_working_dir,
        )
        skill_manager.register(code_exec, enabled=_get_skill_enabled_state("code_exec"))
        _log.debug(f"Registered skill: code_exec")
    except Exception as e:
        _log.error(f"Failed to register code_exec skill: {e}", exc_info=True)

    # Git操作スキル
    try:
        git_ops = GitOpsSkill(
            repo_path=config.skills_working_dir,
            timeout=config.skills_exec_timeout,
        )
        skill_manager.register(git_ops, enabled=_get_skill_enabled_state("git_ops"))
        _log.debug(f"Registered skill: git_ops")
    except Exception as e:
        _log.error(f"Failed to register git_ops skill: {e}", exc_info=True)

    # RAGスキル
    try:
        rag = RAGSkill(
            store_path=config.skills_rag_store_path,
            chunk_size=config.skills_rag_chunk_size,
            chunk_overlap=config.skills_rag_chunk_overlap,
        )
        skill_manager.register(rag, enabled=_get_skill_enabled_state("rag"))
        _log.debug(f"Registered skill: rag")
    except Exception as e:
        _log.error(f"Failed to register rag skill: {e}", exc_info=True)

    # Web検索スキル
    try:
        web_search = WebSearchSkill(
            timeout=config.skills_web_search_timeout,
            max_results=config.skills_web_search_max_results,
        )
        skill_manager.register(web_search, enabled=_get_skill_enabled_state("web_search"))
        _log.debug(f"Registered skill: web_search")
    except Exception as e:
        _log.error(f"Failed to register web_search skill: {e}", exc_info=True)

    # コード分析スキル（オプショナル）
    try:
        from app.skills.code_analysis import CodeAnalysisSkill
        code_analysis = CodeAnalysisSkill()
        skill_manager.register(
            code_analysis,
            enabled=_get_skill_enabled_state("code_analysis")
        )
        _log.debug(f"Registered skill: code_analysis")
    except ImportError:
        # tree-sitterがインストールされていない場合はスキップ
        _log.debug("CodeAnalysisSkill not available (tree-sitter not installed)")
    except Exception as e:
        _log.error(f"Failed to register code_analysis skill: {e}", exc_info=True)

    # チェッカースキル（オプショナル）
    for checker_skill in _try_import_checker_skills():
        try:
            skill_manager.register(
                checker_skill,
                enabled=_get_skill_enabled_state(checker_skill.name)
            )
            _log.debug(f"Registered skill: {checker_skill.name}")
        except Exception as e:
            _log.error(f"Failed to register {checker_skill.name} skill: {e}", exc_info=True)


# リクエスト/レスポンスモデル
class ExecuteRequest(BaseModel):
    """スキル実行リクエスト"""
    skill: str
    action: str
    params: dict[str, Any] = {}


class ExecuteResponse(BaseModel):
    """スキル実行レスポンス"""
    status: str
    message: str
    data: Optional[Any] = None
    error: Optional[str] = None


@router.get("")
async def list_skills():
    """登録済みスキル一覧を取得"""
    skills = skill_manager.list_skills()
    return {"skills": skills, "count": len(skills)}


@router.get("/{skill_name}")
async def get_skill_info(skill_name: str):
    """スキル詳細情報を取得"""
    info = skill_manager.get_skill_info(skill_name)
    if info is None:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")
    return info


@router.get("/{skill_name}/actions")
async def get_skill_actions(skill_name: str):
    """スキルのアクション一覧を取得"""
    info = skill_manager.get_skill_info(skill_name)
    if info is None:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")
    return {"skill": skill_name, "actions": info["actions"]}


@router.post("/execute", response_model=ExecuteResponse)
async def execute_skill(request: ExecuteRequest):
    """スキルのアクションを実行"""
    result = await skill_manager.execute(
        skill_name=request.skill,
        action=request.action,
        params=request.params,
    )
    return ExecuteResponse(
        status=result.status.value,
        message=result.message,
        data=result.data,
        error=result.error,
    )


# 注意: 以下の固定パスのルートは動的ルート (/{skill_name}/{action}) よりも前に定義する必要がある
@router.post("/{skill_name}/enable")
async def enable_skill(skill_name: str):
    """スキルを有効化"""
    success = skill_manager.enable_skill(skill_name)
    if not success:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")
    return {
        "status": "success",
        "message": f"スキル '{skill_name}' を有効化しました",
        "skill": skill_name,
        "enabled": True,
    }


@router.post("/{skill_name}/disable")
async def disable_skill(skill_name: str):
    """スキルを無効化"""
    success = skill_manager.disable_skill(skill_name)
    if not success:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")
    return {
        "status": "success",
        "message": f"スキル '{skill_name}' を無効化しました",
        "skill": skill_name,
        "enabled": False,
    }


@router.get("/{skill_name}/status")
async def get_skill_status(skill_name: str):
    """スキルの状態を取得"""
    skill = skill_manager.get_skill(skill_name)
    if skill is None:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")

    return {
        "skill": skill_name,
        "enabled": skill_manager.is_enabled(skill_name),
        "description": skill.description,
    }


# 動的ルート: 他の固定パスルートより後に定義
@router.post("/{skill_name}/{action}", response_model=ExecuteResponse)
async def execute_skill_action(skill_name: str, action: str, params: dict[str, Any] = {}):
    """スキルのアクションを直接実行（RESTful API）"""
    result = await skill_manager.execute(
        skill_name=skill_name,
        action=action,
        params=params,
    )
    return ExecuteResponse(
        status=result.status.value,
        message=result.message,
        data=result.data,
        error=result.error,
    )
