"""IXV-Core カスタム例外"""

from typing import Optional


class IXVCoreError(Exception):
    """IXV-Core ベース例外"""

    def __init__(self, message: str, code: Optional[str] = None):
        super().__init__(message)
        self.message = message
        self.code = code or "internal_error"


class ModelLoadError(IXVCoreError):
    """モデルロード失敗例外"""

    def __init__(self, message: str, model_path: Optional[str] = None):
        super().__init__(message, code="model_load_error")
        self.model_path = model_path


class ModelNotLoadedError(IXVCoreError):
    """モデル未ロード例外"""

    def __init__(self):
        super().__init__(
            "Model not loaded. Server may still be starting up.",
            code="model_not_loaded",
        )


class InferenceError(IXVCoreError):
    """推論実行時例外"""

    def __init__(self, message: str):
        super().__init__(message, code="inference_error")


class ValidationError(IXVCoreError):
    """入力検証失敗例外"""

    def __init__(self, message: str, field: Optional[str] = None):
        super().__init__(message, code="validation_error")
        self.field = field


class ConcurrencyLimitError(IXVCoreError):
    """同時実行数制限超過例外"""

    def __init__(self, max_concurrent: int, active_count: int):
        super().__init__(
            f"Maximum concurrent inferences ({max_concurrent}) reached. Active: {active_count}",
            code="concurrency_limit_exceeded",
        )
        self.max_concurrent = max_concurrent
        self.active_count = active_count
