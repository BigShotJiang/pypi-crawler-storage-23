"""レート制限設定

slowapiを使用したレート制限の設定を提供する。
循環インポートを避けるため、limiterインスタンスを独立したモジュールで定義。
"""

from slowapi import Limiter
from slowapi.util import get_remote_address

from app.config import config

# レート制限インスタンス
limiter = Limiter(
    key_func=get_remote_address,
    default_limits=[f"{config.rate_limit_requests}/{config.rate_limit_period}"],
    enabled=config.rate_limit_enabled,
)
