"""推論サービス層

- llama.cpp への呼び出しを一元管理
- ログ出力
- Streaming 風のインターフェースを提供（将来の本格Streaming対応もここで吸収）
"""

import time
from typing import Dict, Any, Generator, Optional

from app.model_loader import ModelLoader
from app.logger import logger


class InferenceService:
    """モデル呼び出しをラップするサービス"""

    def chat(
        self,
        prompt: str,
        *,
        model_name: str,
        temperature: float,
        max_tokens: int,
        stop: Optional[list[str]] = None,
    ) -> Dict[str, Any]:
        """通常のチャット補完（非ストリーミング）"""

        if stop is None:
            stop = ["user:", "assistant:"]

        model = ModelLoader.load()

        started = time.time()
        result = model(
            prompt,
            temperature=temperature,
            max_tokens=max_tokens,
            stop=stop,
        )
        elapsed = time.time() - started

        text: str = result["choices"][0]["text"]
        usage: Dict[str, Any] = result.get("usage") or {}

        # ログ出力
        logger.log_inference(
            prompt=prompt,
            completion=text,
            model=model_name,
            usage=usage,
            extra={"elapsed": elapsed},
        )

        return {
            "text": text,
            "usage": usage,
            "elapsed": elapsed,
        }

    def stream_chat(
        self,
        prompt: str,
        *,
        model_name: str,
        temperature: float,
        max_tokens: int,
        stop: Optional[list[str]] = None,
    ) -> Generator[Dict[str, Any], None, None]:
        """真のストリーミングチャット

        llama.cppのネイティブストリーミング機能を使用して、
        トークン生成と同時にリアルタイムで結果を返す。
        """

        if stop is None:
            stop = ["user:", "assistant:"]

        model = ModelLoader.load()

        started = time.time()
        full_text = ""
        usage_info: Dict[str, Any] = {}

        try:
            # llama.cppのstream=Trueを使用
            for chunk in model(
                prompt,
                temperature=temperature,
                max_tokens=max_tokens,
                stop=stop,
                stream=True,  # ネイティブストリーミング
            ):
                # チャンクからテキストを抽出
                chunk_text = chunk["choices"][0].get("text", "")

                # llama-cpp-pythonの一部バージョンでは累積テキストを返すため、
                # 差分を計算して二重化を防ぐ
                if chunk_text.startswith(full_text):
                    # 累積テキストの場合：差分のみを抽出
                    delta = chunk_text[len(full_text):]
                    full_text = chunk_text
                else:
                    # 新しいトークンのみの場合：そのまま使用
                    delta = chunk_text
                    full_text += delta

                # usage情報があれば保存（最後のチャンクに含まれる）
                if "usage" in chunk:
                    usage_info = chunk["usage"]

                # 生成されたテキスト断片を返す（空でない場合のみ）
                if delta:
                    yield {
                        "content": delta,
                    }

            elapsed = time.time() - started

            # ストリーミング完了後にログ出力
            logger.log_inference(
                prompt=prompt,
                completion=full_text,
                model=model_name,
                usage=usage_info,
                extra={"elapsed": elapsed, "streaming": True},
            )

        except Exception as e:
            # ストリーミング中のエラーを通知
            import logging
            _log = logging.getLogger("ixv-core.inference")
            _log.error(f"Streaming error: {e}", exc_info=True)

            # エラーをyieldして呼び出し側に伝える
            yield {
                "error": str(e),
                "type": "streaming_error",
            }


# シングルトンインスタンス
inference_service = InferenceService()
