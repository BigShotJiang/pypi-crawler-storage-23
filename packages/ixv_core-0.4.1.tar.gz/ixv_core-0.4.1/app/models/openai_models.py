"""OpenAI互換APIのPydanticモデル定義

Function Calling関連のモデルを含む、OpenAI API互換のリクエスト/レスポンスモデル。
"""

from typing import Dict, Any, List, Literal, Optional
from pydantic import BaseModel, Field, field_validator


# ==== Function Calling 関連モデル ====

class Function(BaseModel):
    """OpenAI互換のFunction定義"""
    name: str
    description: str
    parameters: Dict[str, Any]  # JSON Schema形式


class Tool(BaseModel):
    """OpenAI互換のTool定義"""
    type: Literal["function"] = "function"
    function: Function


class FunctionCall(BaseModel):
    """Function呼び出しの引数"""
    name: str
    arguments: str  # JSON文字列


class ToolCall(BaseModel):
    """Tool呼び出し"""
    id: str
    type: Literal["function"] = "function"
    function: FunctionCall


# ==== Message モデル ====

class Message(BaseModel):
    """チャットメッセージ"""
    role: Literal["system", "user", "assistant", "tool"]
    content: Optional[str] = Field(None, max_length=100000)
    tool_calls: Optional[List[ToolCall]] = None
    tool_call_id: Optional[str] = None

    @field_validator("content")
    @classmethod
    def validate_content(cls, v: Optional[str], info) -> Optional[str]:
        # tool roleの場合はcontentがNoneでもOK
        role = info.data.get("role")
        if role == "tool":
            return v or ""
        # それ以外の場合は必須
        if not v:
            raise ValueError("content is required for non-tool messages")
        return v


# ==== Request/Response モデル ====

class ChatCompletionRequest(BaseModel):
    """Chat Completionsリクエスト"""
    model: str = "ixv-model"
    messages: List[Message] = Field(..., min_length=1)
    temperature: float = Field(0.7, ge=0.0, le=2.0)
    max_tokens: int = Field(512, ge=1, le=8192)
    stream: bool = False
    prompt_type: Optional[str] = None  # プロンプトテンプレートタイプ
    tools: Optional[List[Tool]] = None  # Function Calling用のtools
    tool_choice: Optional[Literal["none", "auto"]] = "auto"  # Function Callingの選択方法

    @field_validator("messages")
    @classmethod
    def validate_messages_not_empty(cls, v: List[Message]) -> List[Message]:
        if not v:
            raise ValueError("messages cannot be empty")
        return v


class ChatCompletionChoice(BaseModel):
    """Chat Completions応答のchoice"""
    index: int = 0
    message: Message
    finish_reason: Literal["stop", "tool_calls"] = "stop"


class Usage(BaseModel):
    """トークン使用量"""
    prompt_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None
    total_tokens: Optional[int] = None


class ChatCompletionResponse(BaseModel):
    """Chat Completions応答"""
    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: List[ChatCompletionChoice]
    usage: Optional[Usage] = None


class ModelInfo(BaseModel):
    """モデル情報"""
    id: str
    object: str = "model"
    owned_by: str = "ixv-local"


class ModelsResponse(BaseModel):
    """モデル一覧応答"""
    object: str = "list"
    data: List[ModelInfo]
