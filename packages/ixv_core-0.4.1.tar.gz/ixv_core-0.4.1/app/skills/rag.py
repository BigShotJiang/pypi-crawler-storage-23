"""RAGスキル（Retrieval-Augmented Generation）"""

import hashlib
import json
from pathlib import Path
from typing import Optional
from dataclasses import dataclass, asdict

from app.skills.base import BaseSkill, SkillResult


@dataclass
class Document:
    """ドキュメント"""
    id: str
    content: str
    metadata: dict
    embedding: list[float] | None = None


@dataclass
class SearchResult:
    """検索結果"""
    document: Document
    score: float


class SimpleVectorStore:
    """シンプルなベクトルストア

    外部依存なしで動作する軽量な実装。
    本格的な運用にはchromadbやfaissへの置き換えを推奨。
    """

    def __init__(self, store_path: Optional[Path] = None):
        self._documents: dict[str, Document] = {}
        self._store_path = store_path
        if store_path and store_path.exists():
            self._load()

    def _load(self) -> None:
        """ストアを読み込み"""
        if self._store_path and self._store_path.exists():
            data = json.loads(self._store_path.read_text(encoding="utf-8"))
            for doc_data in data.get("documents", []):
                doc = Document(**doc_data)
                self._documents[doc.id] = doc

    def _save(self) -> None:
        """ストアを保存"""
        if self._store_path:
            self._store_path.parent.mkdir(parents=True, exist_ok=True)
            data = {
                "documents": [asdict(doc) for doc in self._documents.values()]
            }
            self._store_path.write_text(
                json.dumps(data, ensure_ascii=False, indent=2),
                encoding="utf-8"
            )

    def add(self, doc: Document) -> None:
        """ドキュメントを追加"""
        self._documents[doc.id] = doc
        self._save()

    def get(self, doc_id: str) -> Optional[Document]:
        """ドキュメントを取得"""
        return self._documents.get(doc_id)

    def delete(self, doc_id: str) -> bool:
        """ドキュメントを削除"""
        if doc_id in self._documents:
            del self._documents[doc_id]
            self._save()
            return True
        return False

    def list_all(self) -> list[Document]:
        """全ドキュメントを取得"""
        return list(self._documents.values())

    def search_keyword(self, query: str, limit: int = 5) -> list[SearchResult]:
        """キーワード検索（シンプルなTF-IDF風スコアリング）"""
        query_terms = query.lower().split()
        results = []

        for doc in self._documents.values():
            content_lower = doc.content.lower()
            # 単純なマッチングスコア
            score = 0.0
            for term in query_terms:
                count = content_lower.count(term)
                if count > 0:
                    # TF-IDF風のスコア（簡易版）
                    score += count / (len(doc.content.split()) + 1)

            if score > 0:
                results.append(SearchResult(document=doc, score=score))

        # スコア順にソート
        results.sort(key=lambda x: x.score, reverse=True)
        return results[:limit]

    def clear(self) -> None:
        """全ドキュメントを削除"""
        self._documents.clear()
        self._save()


class RAGSkill(BaseSkill):
    """RAGスキル

    ローカルドキュメントを検索してコンテキストを提供する。
    """

    def __init__(
        self,
        store_path: Optional[str] = None,
        chunk_size: int = 500,
        chunk_overlap: int = 50,
    ):
        """初期化

        Args:
            store_path: ベクトルストアの保存パス
            chunk_size: チャンクサイズ（文字数）
            chunk_overlap: チャンクのオーバーラップ（文字数）
        """
        default_path = Path.home() / ".ixv" / "rag" / "store.json"
        self._store_path = Path(store_path) if store_path else default_path
        self._store = SimpleVectorStore(self._store_path)
        self._chunk_size = chunk_size
        self._chunk_overlap = chunk_overlap

    @property
    def name(self) -> str:
        return "rag"

    @property
    def description(self) -> str:
        return "ドキュメントを検索してコンテキストを提供するRAGスキル"

    def get_actions(self) -> list[dict]:
        return [
            {
                "name": "index_file",
                "description": "ファイルをインデックスに追加",
                "parameters": {
                    "path": {
                        "type": "string",
                        "description": "ファイルパス",
                        "required": True
                    },
                    "metadata": {
                        "type": "object",
                        "description": "追加のメタデータ",
                        "default": {}
                    },
                },
            },
            {
                "name": "index_directory",
                "description": "ディレクトリ内のファイルを一括インデックス",
                "parameters": {
                    "path": {
                        "type": "string",
                        "description": "ディレクトリパス",
                        "required": True
                    },
                    "pattern": {
                        "type": "string",
                        "description": "ファイルパターン",
                        "default": "**/*.md"
                    },
                    "metadata": {
                        "type": "object",
                        "description": "追加のメタデータ",
                        "default": {}
                    },
                },
            },
            {
                "name": "index_text",
                "description": "テキストを直接インデックスに追加",
                "parameters": {
                    "text": {
                        "type": "string",
                        "description": "インデックスするテキスト",
                        "required": True
                    },
                    "source": {
                        "type": "string",
                        "description": "ソース名",
                        "default": "manual"
                    },
                    "metadata": {
                        "type": "object",
                        "description": "追加のメタデータ",
                        "default": {}
                    },
                },
            },
            {
                "name": "search",
                "description": "ドキュメントを検索",
                "parameters": {
                    "query": {
                        "type": "string",
                        "description": "検索クエリ",
                        "required": True
                    },
                    "limit": {
                        "type": "integer",
                        "description": "取得件数",
                        "default": 5
                    },
                },
            },
            {
                "name": "get_context",
                "description": "クエリに関連するコンテキストを取得（LLMプロンプト用）",
                "parameters": {
                    "query": {
                        "type": "string",
                        "description": "検索クエリ",
                        "required": True
                    },
                    "limit": {
                        "type": "integer",
                        "description": "取得件数",
                        "default": 3
                    },
                    "max_tokens": {
                        "type": "integer",
                        "description": "最大トークン数（概算）",
                        "default": 2000
                    },
                },
            },
            {
                "name": "list_documents",
                "description": "インデックス済みドキュメント一覧",
                "parameters": {},
            },
            {
                "name": "delete_document",
                "description": "ドキュメントを削除",
                "parameters": {
                    "doc_id": {
                        "type": "string",
                        "description": "ドキュメントID",
                        "required": True
                    },
                },
            },
            {
                "name": "clear_index",
                "description": "インデックスをクリア",
                "parameters": {},
            },
        ]

    async def execute(self, action: str, params: dict) -> SkillResult:
        """アクションを実行"""
        actions = {
            "index_file": self._index_file,
            "index_directory": self._index_directory,
            "index_text": self._index_text,
            "search": self._search,
            "get_context": self._get_context,
            "list_documents": self._list_documents,
            "delete_document": self._delete_document,
            "clear_index": self._clear_index,
        }

        handler = actions.get(action)
        if handler is None:
            return SkillResult.error(
                error=f"Unknown action: {action}",
                message=f"不明なアクション: {action}",
            )

        return await handler(params)

    def _generate_doc_id(self, content: str, source: str) -> str:
        """ドキュメントIDを生成"""
        hash_input = f"{source}:{content[:100]}"
        return hashlib.md5(hash_input.encode()).hexdigest()[:12]

    def _chunk_text(self, text: str) -> list[str]:
        """テキストをチャンクに分割"""
        chunks = []
        start = 0
        while start < len(text):
            end = start + self._chunk_size
            chunk = text[start:end]
            chunks.append(chunk)
            start = end - self._chunk_overlap
            if start >= len(text):
                break
        return chunks

    async def _index_file(self, params: dict) -> SkillResult:
        """ファイルをインデックス"""
        path = params.get("path")
        if not path:
            return SkillResult.error("path is required", "パスが必要です")

        metadata = params.get("metadata", {})
        file_path = Path(path)

        if not file_path.exists():
            return SkillResult.error(
                f"File not found: {path}",
                "ファイルが見つかりません"
            )

        try:
            content = file_path.read_text(encoding="utf-8")
        except Exception as e:
            return SkillResult.error(str(e), "ファイル読み込みエラー")

        # チャンクに分割してインデックス
        chunks = self._chunk_text(content)
        doc_ids = []

        for i, chunk in enumerate(chunks):
            doc_id = self._generate_doc_id(chunk, str(file_path))
            doc = Document(
                id=f"{doc_id}_{i}",
                content=chunk,
                metadata={
                    "source": str(file_path),
                    "chunk_index": i,
                    "total_chunks": len(chunks),
                    **metadata,
                },
            )
            self._store.add(doc)
            doc_ids.append(doc.id)

        return SkillResult.success(
            data={"doc_ids": doc_ids, "chunks": len(chunks)},
            message=f"{len(chunks)}チャンクをインデックスしました",
        )

    async def _index_directory(self, params: dict) -> SkillResult:
        """ディレクトリを一括インデックス"""
        path = params.get("path")
        if not path:
            return SkillResult.error("path is required", "パスが必要です")

        pattern = params.get("pattern", "**/*.md")
        metadata = params.get("metadata", {})
        dir_path = Path(path)

        if not dir_path.exists():
            return SkillResult.error(
                f"Directory not found: {path}",
                "ディレクトリが見つかりません"
            )

        files = list(dir_path.glob(pattern))
        total_chunks = 0
        indexed_files = []

        for file_path in files:
            if file_path.is_file():
                try:
                    content = file_path.read_text(encoding="utf-8")
                    chunks = self._chunk_text(content)

                    for i, chunk in enumerate(chunks):
                        doc_id = self._generate_doc_id(chunk, str(file_path))
                        doc = Document(
                            id=f"{doc_id}_{i}",
                            content=chunk,
                            metadata={
                                "source": str(file_path),
                                "chunk_index": i,
                                "total_chunks": len(chunks),
                                **metadata,
                            },
                        )
                        self._store.add(doc)

                    total_chunks += len(chunks)
                    indexed_files.append(str(file_path))
                except Exception:
                    continue

        return SkillResult.success(
            data={
                "files": len(indexed_files),
                "chunks": total_chunks,
                "indexed_files": indexed_files,
            },
            message=f"{len(indexed_files)}ファイル、{total_chunks}チャンクをインデックス",
        )

    async def _index_text(self, params: dict) -> SkillResult:
        """テキストを直接インデックス"""
        text = params.get("text")
        if not text:
            return SkillResult.error("text is required", "テキストが必要です")

        source = params.get("source", "manual")
        metadata = params.get("metadata", {})

        chunks = self._chunk_text(text)
        doc_ids = []

        for i, chunk in enumerate(chunks):
            doc_id = self._generate_doc_id(chunk, source)
            doc = Document(
                id=f"{doc_id}_{i}",
                content=chunk,
                metadata={
                    "source": source,
                    "chunk_index": i,
                    "total_chunks": len(chunks),
                    **metadata,
                },
            )
            self._store.add(doc)
            doc_ids.append(doc.id)

        return SkillResult.success(
            data={"doc_ids": doc_ids, "chunks": len(chunks)},
            message=f"{len(chunks)}チャンクをインデックスしました",
        )

    async def _search(self, params: dict) -> SkillResult:
        """ドキュメントを検索"""
        query = params.get("query")
        if not query:
            return SkillResult.error("query is required", "クエリが必要です")

        limit = params.get("limit", 5)
        results = self._store.search_keyword(query, limit=limit)

        return SkillResult.success(
            data={
                "results": [
                    {
                        "id": r.document.id,
                        "content": r.document.content,
                        "metadata": r.document.metadata,
                        "score": r.score,
                    }
                    for r in results
                ],
                "count": len(results),
            },
            message=f"{len(results)}件の結果が見つかりました",
        )

    async def _get_context(self, params: dict) -> SkillResult:
        """LLM用のコンテキストを取得"""
        query = params.get("query")
        if not query:
            return SkillResult.error("query is required", "クエリが必要です")

        limit = params.get("limit", 3)
        max_tokens = params.get("max_tokens", 2000)

        results = self._store.search_keyword(query, limit=limit)

        # コンテキストを構築（トークン数を概算）
        context_parts = []
        total_chars = 0
        max_chars = max_tokens * 4  # 概算: 1トークン ≈ 4文字

        for r in results:
            if total_chars + len(r.document.content) > max_chars:
                break
            context_parts.append(
                f"[Source: {r.document.metadata.get('source', 'unknown')}]\n"
                f"{r.document.content}"
            )
            total_chars += len(r.document.content)

        context = "\n\n---\n\n".join(context_parts)

        return SkillResult.success(
            data={
                "context": context,
                "sources": [r.document.metadata.get("source") for r in results],
                "num_documents": len(context_parts),
            },
            message=f"{len(context_parts)}ドキュメントからコンテキストを取得",
        )

    async def _list_documents(self, params: dict) -> SkillResult:
        """ドキュメント一覧"""
        docs = self._store.list_all()

        # ソースごとにグループ化
        sources: dict[str, int] = {}
        for doc in docs:
            source = doc.metadata.get("source", "unknown")
            sources[source] = sources.get(source, 0) + 1

        return SkillResult.success(
            data={
                "total_documents": len(docs),
                "sources": sources,
            },
            message=f"合計 {len(docs)} ドキュメント",
        )

    async def _delete_document(self, params: dict) -> SkillResult:
        """ドキュメントを削除"""
        doc_id = params.get("doc_id")
        if not doc_id:
            return SkillResult.error("doc_id is required", "ドキュメントIDが必要です")

        if self._store.delete(doc_id):
            return SkillResult.success(
                data={"doc_id": doc_id},
                message="ドキュメントを削除しました",
            )
        else:
            return SkillResult.error(
                f"Document not found: {doc_id}",
                "ドキュメントが見つかりません",
            )

    async def _clear_index(self, params: dict) -> SkillResult:
        """インデックスをクリア"""
        self._store.clear()
        return SkillResult.success(
            message="インデックスをクリアしました",
        )
