"""ファイル操作スキル"""

import glob as glob_module
from pathlib import Path
from typing import Optional

from app.skills.base import BaseSkill, SkillResult


class FileOpsSkill(BaseSkill):
    """ファイル操作スキル

    ローカルファイルシステムの読み書き・検索を行う。
    """

    def __init__(self, base_dir: Optional[str] = None, max_file_size: int = 1024 * 1024):
        """初期化

        Args:
            base_dir: 操作を許可するベースディレクトリ（Noneの場合は制限なし）
            max_file_size: 読み込み可能な最大ファイルサイズ（バイト）
        """
        self._base_dir = Path(base_dir).resolve() if base_dir else None
        self._max_file_size = max_file_size

    @property
    def name(self) -> str:
        return "file_ops"

    @property
    def description(self) -> str:
        return "ファイルの読み書き・検索を行うスキル"

    def get_actions(self) -> list[dict]:
        return [
            {
                "name": "read_file",
                "description": "ファイルを読み込む",
                "parameters": {
                    "path": {"type": "string", "description": "ファイルパス", "required": True},
                    "encoding": {"type": "string", "description": "文字エンコーディング", "default": "utf-8"},
                },
            },
            {
                "name": "write_file",
                "description": "ファイルに書き込む",
                "parameters": {
                    "path": {"type": "string", "description": "ファイルパス", "required": True},
                    "content": {"type": "string", "description": "書き込む内容", "required": True},
                    "encoding": {"type": "string", "description": "文字エンコーディング", "default": "utf-8"},
                    "create_dirs": {"type": "boolean", "description": "親ディレクトリを作成するか", "default": True},
                },
            },
            {
                "name": "append_file",
                "description": "ファイルに追記する",
                "parameters": {
                    "path": {"type": "string", "description": "ファイルパス", "required": True},
                    "content": {"type": "string", "description": "追記する内容", "required": True},
                    "encoding": {"type": "string", "description": "文字エンコーディング", "default": "utf-8"},
                },
            },
            {
                "name": "list_dir",
                "description": "ディレクトリの内容を一覧表示",
                "parameters": {
                    "path": {"type": "string", "description": "ディレクトリパス", "required": True},
                    "recursive": {"type": "boolean", "description": "再帰的に表示するか", "default": False},
                    "include_hidden": {"type": "boolean", "description": "隠しファイルを含めるか", "default": False},
                },
            },
            {
                "name": "search_files",
                "description": "ファイルをglobパターンで検索",
                "parameters": {
                    "pattern": {"type": "string", "description": "globパターン (例: **/*.py)", "required": True},
                    "base_path": {"type": "string", "description": "検索の起点ディレクトリ", "default": "."},
                },
            },
            {
                "name": "file_info",
                "description": "ファイル情報を取得",
                "parameters": {
                    "path": {"type": "string", "description": "ファイルパス", "required": True},
                },
            },
            {
                "name": "delete_file",
                "description": "ファイルを削除",
                "parameters": {
                    "path": {"type": "string", "description": "ファイルパス", "required": True},
                },
            },
            {
                "name": "move_file",
                "description": "ファイルを移動/リネーム",
                "parameters": {
                    "source": {"type": "string", "description": "移動元パス", "required": True},
                    "destination": {"type": "string", "description": "移動先パス", "required": True},
                },
            },
            {
                "name": "copy_file",
                "description": "ファイルをコピー",
                "parameters": {
                    "source": {"type": "string", "description": "コピー元パス", "required": True},
                    "destination": {"type": "string", "description": "コピー先パス", "required": True},
                },
            },
        ]

    def _validate_path(self, path: str) -> tuple[bool, Path, str]:
        """パスを検証

        Returns:
            tuple: (有効か, 解決済みパス, エラーメッセージ)
        """
        try:
            resolved = Path(path).resolve()
            if self._base_dir:
                # ベースディレクトリ内かチェック
                try:
                    resolved.relative_to(self._base_dir)
                except ValueError:
                    return False, resolved, f"アクセス禁止: {path} はベースディレクトリ外です"
            return True, resolved, ""
        except Exception as e:
            return False, Path(path), f"無効なパス: {e}"

    async def execute(self, action: str, params: dict) -> SkillResult:
        """アクションを実行"""
        actions = {
            "read_file": self._read_file,
            "write_file": self._write_file,
            "append_file": self._append_file,
            "list_dir": self._list_dir,
            "search_files": self._search_files,
            "file_info": self._file_info,
            "delete_file": self._delete_file,
            "move_file": self._move_file,
            "copy_file": self._copy_file,
        }

        handler = actions.get(action)
        if handler is None:
            return SkillResult.error(
                error=f"Unknown action: {action}",
                message=f"不明なアクション: {action}",
            )

        return await handler(params)

    async def _read_file(self, params: dict) -> SkillResult:
        """ファイルを読み込む"""
        path = params.get("path")
        if not path:
            return SkillResult.error("path is required", "パスが必要です")

        encoding = params.get("encoding", "utf-8")

        valid, resolved, error = self._validate_path(path)
        if not valid:
            return SkillResult.error(error, "パス検証エラー")

        if not resolved.exists():
            return SkillResult.error(f"File not found: {path}", "ファイルが見つかりません")

        if not resolved.is_file():
            return SkillResult.error(f"Not a file: {path}", "ファイルではありません")

        # ファイルサイズチェック
        size = resolved.stat().st_size
        if size > self._max_file_size:
            return SkillResult.error(
                f"File too large: {size} bytes (max: {self._max_file_size})",
                "ファイルが大きすぎます",
            )

        try:
            content = resolved.read_text(encoding=encoding)
            return SkillResult.success(
                data={"content": content, "path": str(resolved), "size": size},
                message=f"ファイルを読み込みました: {path}",
            )
        except UnicodeDecodeError as e:
            return SkillResult.error(str(e), "エンコーディングエラー")
        except Exception as e:
            return SkillResult.error(str(e), "読み込みエラー")

    async def _write_file(self, params: dict) -> SkillResult:
        """ファイルに書き込む"""
        path = params.get("path")
        content = params.get("content")
        if not path:
            return SkillResult.error("path is required", "パスが必要です")
        if content is None:
            return SkillResult.error("content is required", "内容が必要です")

        encoding = params.get("encoding", "utf-8")
        create_dirs = params.get("create_dirs", True)

        valid, resolved, error = self._validate_path(path)
        if not valid:
            return SkillResult.error(error, "パス検証エラー")

        try:
            if create_dirs:
                resolved.parent.mkdir(parents=True, exist_ok=True)

            resolved.write_text(content, encoding=encoding)
            return SkillResult.success(
                data={"path": str(resolved), "size": len(content.encode(encoding))},
                message=f"ファイルに書き込みました: {path}",
            )
        except Exception as e:
            return SkillResult.error(str(e), "書き込みエラー")

    async def _append_file(self, params: dict) -> SkillResult:
        """ファイルに追記"""
        path = params.get("path")
        content = params.get("content")
        if not path:
            return SkillResult.error("path is required", "パスが必要です")
        if content is None:
            return SkillResult.error("content is required", "内容が必要です")

        encoding = params.get("encoding", "utf-8")

        valid, resolved, error = self._validate_path(path)
        if not valid:
            return SkillResult.error(error, "パス検証エラー")

        try:
            with open(resolved, "a", encoding=encoding) as f:
                f.write(content)
            return SkillResult.success(
                data={"path": str(resolved)},
                message=f"ファイルに追記しました: {path}",
            )
        except Exception as e:
            return SkillResult.error(str(e), "追記エラー")

    async def _list_dir(self, params: dict) -> SkillResult:
        """ディレクトリ一覧"""
        path = params.get("path")
        if not path:
            return SkillResult.error("path is required", "パスが必要です")

        recursive = params.get("recursive", False)
        include_hidden = params.get("include_hidden", False)

        valid, resolved, error = self._validate_path(path)
        if not valid:
            return SkillResult.error(error, "パス検証エラー")

        if not resolved.exists():
            return SkillResult.error(f"Directory not found: {path}", "ディレクトリが見つかりません")

        if not resolved.is_dir():
            return SkillResult.error(f"Not a directory: {path}", "ディレクトリではありません")

        try:
            entries = []
            if recursive:
                for item in resolved.rglob("*"):
                    if not include_hidden and item.name.startswith("."):
                        continue
                    entries.append({
                        "path": str(item.relative_to(resolved)),
                        "type": "dir" if item.is_dir() else "file",
                        "size": item.stat().st_size if item.is_file() else None,
                    })
            else:
                for item in resolved.iterdir():
                    if not include_hidden and item.name.startswith("."):
                        continue
                    entries.append({
                        "name": item.name,
                        "type": "dir" if item.is_dir() else "file",
                        "size": item.stat().st_size if item.is_file() else None,
                    })

            return SkillResult.success(
                data={"entries": entries, "count": len(entries)},
                message=f"ディレクトリ一覧を取得しました: {path}",
            )
        except Exception as e:
            return SkillResult.error(str(e), "一覧取得エラー")

    async def _search_files(self, params: dict) -> SkillResult:
        """ファイル検索"""
        pattern = params.get("pattern")
        if not pattern:
            return SkillResult.error("pattern is required", "パターンが必要です")

        base_path = params.get("base_path", ".")

        valid, resolved, error = self._validate_path(base_path)
        if not valid:
            return SkillResult.error(error, "パス検証エラー")

        try:
            full_pattern = str(resolved / pattern)
            matches = glob_module.glob(full_pattern, recursive=True)

            results = []
            for match in matches[:100]:  # 最大100件
                p = Path(match)
                results.append({
                    "path": match,
                    "type": "dir" if p.is_dir() else "file",
                    "size": p.stat().st_size if p.is_file() else None,
                })

            return SkillResult.success(
                data={"matches": results, "count": len(results), "truncated": len(matches) > 100},
                message=f"{len(results)}件のファイルが見つかりました",
            )
        except Exception as e:
            return SkillResult.error(str(e), "検索エラー")

    async def _file_info(self, params: dict) -> SkillResult:
        """ファイル情報"""
        path = params.get("path")
        if not path:
            return SkillResult.error("path is required", "パスが必要です")

        valid, resolved, error = self._validate_path(path)
        if not valid:
            return SkillResult.error(error, "パス検証エラー")

        if not resolved.exists():
            return SkillResult.error(f"Not found: {path}", "見つかりません")

        try:
            stat = resolved.stat()
            info = {
                "path": str(resolved),
                "name": resolved.name,
                "type": "dir" if resolved.is_dir() else "file",
                "size": stat.st_size,
                "created": stat.st_ctime,
                "modified": stat.st_mtime,
                "is_symlink": resolved.is_symlink(),
            }
            if resolved.is_file():
                info["extension"] = resolved.suffix

            return SkillResult.success(data=info, message="ファイル情報を取得しました")
        except Exception as e:
            return SkillResult.error(str(e), "情報取得エラー")

    async def _delete_file(self, params: dict) -> SkillResult:
        """ファイル削除"""
        path = params.get("path")
        if not path:
            return SkillResult.error("path is required", "パスが必要です")

        valid, resolved, error = self._validate_path(path)
        if not valid:
            return SkillResult.error(error, "パス検証エラー")

        if not resolved.exists():
            return SkillResult.error(f"Not found: {path}", "見つかりません")

        try:
            if resolved.is_dir():
                return SkillResult.error("Cannot delete directory with this action", "ディレクトリは削除できません")
            resolved.unlink()
            return SkillResult.success(
                data={"path": str(resolved)},
                message=f"ファイルを削除しました: {path}",
            )
        except Exception as e:
            return SkillResult.error(str(e), "削除エラー")

    async def _move_file(self, params: dict) -> SkillResult:
        """ファイル移動"""
        source = params.get("source")
        destination = params.get("destination")
        if not source or not destination:
            return SkillResult.error("source and destination are required", "移動元と移動先が必要です")

        valid_src, resolved_src, error = self._validate_path(source)
        if not valid_src:
            return SkillResult.error(error, "移動元パス検証エラー")

        valid_dst, resolved_dst, error = self._validate_path(destination)
        if not valid_dst:
            return SkillResult.error(error, "移動先パス検証エラー")

        if not resolved_src.exists():
            return SkillResult.error(f"Source not found: {source}", "移動元が見つかりません")

        try:
            import shutil
            shutil.move(str(resolved_src), str(resolved_dst))
            return SkillResult.success(
                data={"source": str(resolved_src), "destination": str(resolved_dst)},
                message=f"ファイルを移動しました: {source} -> {destination}",
            )
        except Exception as e:
            return SkillResult.error(str(e), "移動エラー")

    async def _copy_file(self, params: dict) -> SkillResult:
        """ファイルコピー"""
        source = params.get("source")
        destination = params.get("destination")
        if not source or not destination:
            return SkillResult.error("source and destination are required", "コピー元とコピー先が必要です")

        valid_src, resolved_src, error = self._validate_path(source)
        if not valid_src:
            return SkillResult.error(error, "コピー元パス検証エラー")

        valid_dst, resolved_dst, error = self._validate_path(destination)
        if not valid_dst:
            return SkillResult.error(error, "コピー先パス検証エラー")

        if not resolved_src.exists():
            return SkillResult.error(f"Source not found: {source}", "コピー元が見つかりません")

        try:
            import shutil
            if resolved_src.is_dir():
                shutil.copytree(str(resolved_src), str(resolved_dst))
            else:
                shutil.copy2(str(resolved_src), str(resolved_dst))
            return SkillResult.success(
                data={"source": str(resolved_src), "destination": str(resolved_dst)},
                message=f"ファイルをコピーしました: {source} -> {destination}",
            )
        except Exception as e:
            return SkillResult.error(str(e), "コピーエラー")
