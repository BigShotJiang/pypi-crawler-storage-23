"""Markdownパーサー

コーディング規約や設計書のMarkdownを構造化データにパースする。
"""

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Any


@dataclass
class ParsedSection:
    """パースされたセクション"""
    title: str
    level: int
    content: str
    subsections: list["ParsedSection"] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def find_section(self, title: str) -> Optional["ParsedSection"]:
        """タイトルでセクションを検索"""
        title_lower = title.lower()
        if self.title.lower() == title_lower:
            return self
        for sub in self.subsections:
            found = sub.find_section(title)
            if found:
                return found
        return None

    def get_all_sections(self) -> list["ParsedSection"]:
        """全セクションをフラットに取得"""
        result = [self]
        for sub in self.subsections:
            result.extend(sub.get_all_sections())
        return result


@dataclass
class TableRow:
    """テーブル行"""
    cells: list[str]


@dataclass
class ParsedTable:
    """パースされたテーブル"""
    headers: list[str]
    rows: list[TableRow]

    def to_dicts(self) -> list[dict[str, str]]:
        """辞書のリストに変換"""
        result = []
        for row in self.rows:
            d = {}
            for i, header in enumerate(self.headers):
                if i < len(row.cells):
                    d[header] = row.cells[i]
            result.append(d)
        return result


@dataclass
class CodeBlock:
    """コードブロック"""
    language: str
    code: str


@dataclass
class ListItem:
    """リストアイテム"""
    content: str
    checked: Optional[bool] = None  # チェックリストの場合
    children: list["ListItem"] = field(default_factory=list)


class MarkdownParser:
    """Markdownパーサー"""

    def __init__(self):
        # 正規表現パターン
        self._heading_pattern = re.compile(r'^(#{1,6})\s+(.+)$', re.MULTILINE)
        self._table_pattern = re.compile(
            r'^\|(.+)\|\s*\n\|[-:\s|]+\|\s*\n((?:\|.+\|\s*\n?)+)',
            re.MULTILINE
        )
        self._code_block_pattern = re.compile(
            r'```(\w*)\n(.*?)```',
            re.DOTALL
        )
        self._list_item_pattern = re.compile(
            r'^(\s*)[-*]\s+(?:\[([xX ])\]\s+)?(.+)$',
            re.MULTILINE
        )
        self._key_value_pattern = re.compile(
            r'^[-*]\s+\*\*(.+?)\*\*:\s*(.+)$',
            re.MULTILINE
        )
        self._mermaid_pattern = re.compile(
            r'```mermaid\n(.*?)```',
            re.DOTALL
        )

    def parse_file(self, file_path: Path) -> ParsedSection:
        """ファイルをパース"""
        content = file_path.read_text(encoding="utf-8")
        return self.parse(content)

    def parse(self, content: str) -> ParsedSection:
        """Markdownコンテンツをパース"""
        # ルートセクションを作成
        root = ParsedSection(
            title="root",
            level=0,
            content="",
        )

        # 見出しで分割
        lines = content.split('\n')
        current_sections: dict[int, ParsedSection] = {0: root}

        i = 0
        while i < len(lines):
            line = lines[i]
            heading_match = self._heading_pattern.match(line)

            if heading_match:
                level = len(heading_match.group(1))
                title = heading_match.group(2).strip()

                # セクションの内容を収集
                section_content_lines = []
                i += 1
                while i < len(lines):
                    next_line = lines[i]
                    next_heading = self._heading_pattern.match(next_line)
                    if next_heading:
                        break
                    section_content_lines.append(next_line)
                    i += 1

                section_content = '\n'.join(section_content_lines).strip()

                # 新しいセクションを作成
                section = ParsedSection(
                    title=title,
                    level=level,
                    content=section_content,
                )

                # メタデータを抽出
                section.metadata = self._extract_metadata(section_content)

                # 親セクションを見つけて追加
                parent_level = level - 1
                while parent_level >= 0:
                    if parent_level in current_sections:
                        current_sections[parent_level].subsections.append(section)
                        break
                    parent_level -= 1

                current_sections[level] = section
                # 下位レベルをクリア
                for l in list(current_sections.keys()):
                    if l > level:
                        del current_sections[l]
            else:
                i += 1

        return root

    def _extract_metadata(self, content: str) -> dict[str, Any]:
        """コンテンツからメタデータを抽出"""
        metadata: dict[str, Any] = {}

        # キー・バリュー形式を抽出
        for match in self._key_value_pattern.finditer(content):
            key = match.group(1).strip()
            value = match.group(2).strip()
            # バッククォートを除去
            value = value.strip('`')
            metadata[key] = value

        # テーブルを抽出
        tables = self.extract_tables(content)
        if tables:
            metadata["tables"] = [t.to_dicts() for t in tables]

        # コードブロックを抽出
        code_blocks = self.extract_code_blocks(content)
        if code_blocks:
            metadata["code_blocks"] = [
                {"language": cb.language, "code": cb.code}
                for cb in code_blocks
            ]

        # Mermaid図を抽出
        mermaid = self.extract_mermaid(content)
        if mermaid:
            metadata["mermaid"] = mermaid

        # チェックリストを抽出
        checklist = self.extract_checklist(content)
        if checklist:
            metadata["checklist"] = checklist

        return metadata

    def extract_tables(self, content: str) -> list[ParsedTable]:
        """テーブルを抽出"""
        tables = []

        for match in self._table_pattern.finditer(content):
            header_line = match.group(1)
            body_lines = match.group(2)

            # ヘッダーを解析
            headers = [h.strip() for h in header_line.split('|') if h.strip()]

            # ボディ行を解析
            rows = []
            for line in body_lines.strip().split('\n'):
                cells = [c.strip() for c in line.split('|') if c.strip()]
                if cells:
                    rows.append(TableRow(cells=cells))

            tables.append(ParsedTable(headers=headers, rows=rows))

        return tables

    def extract_code_blocks(self, content: str) -> list[CodeBlock]:
        """コードブロックを抽出"""
        blocks = []

        for match in self._code_block_pattern.finditer(content):
            language = match.group(1) or ""
            code = match.group(2).strip()
            # mermaidは除外
            if language.lower() != "mermaid":
                blocks.append(CodeBlock(language=language, code=code))

        return blocks

    def extract_mermaid(self, content: str) -> list[str]:
        """Mermaid図を抽出"""
        diagrams = []
        for match in self._mermaid_pattern.finditer(content):
            diagrams.append(match.group(1).strip())
        return diagrams

    def extract_checklist(self, content: str) -> list[dict]:
        """チェックリストを抽出"""
        items = []
        for match in self._list_item_pattern.finditer(content):
            checkbox = match.group(2)
            if checkbox is not None:
                items.append({
                    "content": match.group(3).strip(),
                    "checked": checkbox.lower() == 'x',
                })
        return items

    def extract_list_items(self, content: str) -> list[ListItem]:
        """リストアイテムを抽出"""
        items = []
        for match in self._list_item_pattern.finditer(content):
            indent = len(match.group(1))
            checkbox = match.group(2)
            text = match.group(3).strip()

            checked = None
            if checkbox is not None:
                checked = checkbox.lower() == 'x'

            items.append(ListItem(
                content=text,
                checked=checked,
            ))
        return items


class MermaidParser:
    """Mermaidフローチャートパーサー"""

    def __init__(self):
        self._node_pattern = re.compile(
            r'([A-Za-z0-9_]+)(?:\[([^\]]+)\]|\(([^\)]+)\)|{([^}]+)}|\(\[([^\]]+)\]\))?'
        )
        self._arrow_pattern = re.compile(
            r'([A-Za-z0-9_]+)\s*(-->|--[^>].*-->|==>)\s*(?:\|([^|]+)\|)?\s*([A-Za-z0-9_]+)'
        )

    def parse(self, mermaid_code: str) -> dict:
        """Mermaidコードをパース"""
        result = {
            "type": "flowchart",
            "nodes": {},
            "edges": [],
        }

        lines = mermaid_code.strip().split('\n')

        for line in lines:
            line = line.strip()

            # フローチャートの方向を検出
            if line.startswith('flowchart') or line.startswith('graph'):
                parts = line.split()
                if len(parts) > 1:
                    result["direction"] = parts[1]
                continue

            # エッジを解析
            arrow_match = self._arrow_pattern.search(line)
            if arrow_match:
                from_node = arrow_match.group(1)
                label = arrow_match.group(3) or ""
                to_node = arrow_match.group(4)

                result["edges"].append({
                    "from": from_node,
                    "to": to_node,
                    "label": label.strip(),
                })

                # ノードも抽出
                for node_id in [from_node, to_node]:
                    if node_id not in result["nodes"]:
                        result["nodes"][node_id] = {"id": node_id, "label": node_id}

            # 単独ノード定義を解析
            node_match = self._node_pattern.match(line)
            if node_match and not arrow_match:
                node_id = node_match.group(1)
                label = (
                    node_match.group(2) or
                    node_match.group(3) or
                    node_match.group(4) or
                    node_match.group(5) or
                    node_id
                )
                result["nodes"][node_id] = {"id": node_id, "label": label}

        return result

    def get_flow_steps(self, mermaid_code: str) -> list[dict]:
        """フローチャートからステップを抽出"""
        parsed = self.parse(mermaid_code)
        steps = []

        # エッジからフローを構築
        visited = set()
        edges = parsed.get("edges", [])

        # 開始ノードを見つける（入ってくるエッジがないノード）
        to_nodes = {e["to"] for e in edges}
        from_nodes = {e["from"] for e in edges}
        start_nodes = from_nodes - to_nodes

        # 各開始ノードからトラバース
        for start in start_nodes:
            self._traverse_flow(start, edges, parsed["nodes"], steps, visited, 1)

        return steps

    def _traverse_flow(
        self,
        node_id: str,
        edges: list[dict],
        nodes: dict,
        steps: list[dict],
        visited: set,
        step_num: int
    ) -> int:
        """フローをトラバースしてステップを抽出"""
        if node_id in visited:
            return step_num

        visited.add(node_id)
        node = nodes.get(node_id, {"id": node_id, "label": node_id})

        steps.append({
            "step": step_num,
            "id": node_id,
            "label": node["label"],
        })

        # 次のノードを探す
        next_edges = [e for e in edges if e["from"] == node_id]
        for edge in next_edges:
            step_num = self._traverse_flow(
                edge["to"], edges, nodes, steps, visited, step_num + 1
            )

        return step_num
