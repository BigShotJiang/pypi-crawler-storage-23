"""設計・実装整合性チェックスキル

Markdown形式の設計書とソースコードの整合性をチェックする。
"""

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import yaml

from app.skills.base import BaseSkill, SkillResult
from app.skills.checker.markdown_parser import (
    MarkdownParser,
    MermaidParser,
    ParsedSection,
)


@dataclass
class ProcessStep:
    """処理ステップ"""
    id: str
    label: str
    description: str = ""
    conditions: list[str] = field(default_factory=list)
    next_steps: list[str] = field(default_factory=list)


@dataclass
class ProcessFlow:
    """処理フロー"""
    name: str
    description: str = ""
    steps: list[ProcessStep] = field(default_factory=list)
    input_params: list[str] = field(default_factory=list)
    output: str = ""


@dataclass
class DesignMapping:
    """設計-実装の紐付け"""
    design_element: str  # 設計書内の要素ID
    source_file: str  # 実装ファイル
    class_name: str = ""  # クラス名
    method_name: str = ""  # メソッド名
    line_start: int = 0
    line_end: int = 0


@dataclass
class DesignDocument:
    """設計書"""
    title: str
    version: str = ""
    description: str = ""
    flows: list[ProcessFlow] = field(default_factory=list)
    mappings: list[DesignMapping] = field(default_factory=list)
    raw_sections: list[ParsedSection] = field(default_factory=list)


@dataclass
class ConsistencyIssue:
    """整合性の問題"""
    design_element: str
    source_location: str
    issue_type: str  # missing, mismatch, extra, order
    severity: str
    message: str
    suggestion: str = ""


@dataclass
class ConsistencyResult:
    """整合性チェック結果"""
    design_file: str
    source_file: str
    issues: list[ConsistencyIssue] = field(default_factory=list)
    matched_steps: int = 0
    total_steps: int = 0

    @property
    def match_rate(self) -> float:
        if self.total_steps == 0:
            return 100.0
        return (self.matched_steps / self.total_steps) * 100

    def add_issue(self, issue: ConsistencyIssue) -> None:
        self.issues.append(issue)

    def to_dict(self) -> dict:
        return {
            "design_file": self.design_file,
            "source_file": self.source_file,
            "issues": [
                {
                    "design_element": i.design_element,
                    "source_location": i.source_location,
                    "issue_type": i.issue_type,
                    "severity": i.severity,
                    "message": i.message,
                    "suggestion": i.suggestion,
                }
                for i in self.issues
            ],
            "summary": {
                "matched_steps": self.matched_steps,
                "total_steps": self.total_steps,
                "match_rate": f"{self.match_rate:.1f}%",
                "issues_count": len(self.issues),
            },
        }


class DesignCheckerSkill(BaseSkill):
    """設計・実装整合性チェックスキル"""

    def __init__(self):
        self._md_parser = MarkdownParser()
        self._mermaid_parser = MermaidParser()
        self._design: Optional[DesignDocument] = None
        self._design_path: Optional[Path] = None

    @property
    def name(self) -> str:
        return "design_checker"

    @property
    def description(self) -> str:
        return "Markdown設計書とソースコードの整合性をチェック"

    def get_actions(self) -> list[dict]:
        return [
            {
                "name": "load_design",
                "description": "Markdown設計書を読み込み",
                "parameters": {
                    "path": {
                        "type": "string",
                        "description": "設計書ファイルのパス",
                        "required": True
                    },
                },
            },
            {
                "name": "load_mapping",
                "description": "YAML形式の紐付け定義を読み込み",
                "parameters": {
                    "path": {
                        "type": "string",
                        "description": "紐付け定義ファイルのパス",
                        "required": True
                    },
                },
            },
            {
                "name": "check_consistency",
                "description": "設計と実装の整合性をチェック",
                "parameters": {
                    "source_path": {
                        "type": "string",
                        "description": "ソースファイルのパス",
                        "required": True
                    },
                    "flow_name": {
                        "type": "string",
                        "description": "チェックするフロー名",
                        "default": None
                    },
                },
            },
            {
                "name": "check_flow_order",
                "description": "フローの順序をチェック",
                "parameters": {
                    "source_path": {
                        "type": "string",
                        "description": "ソースファイルのパス",
                        "required": True
                    },
                    "flow_name": {
                        "type": "string",
                        "description": "フロー名",
                        "required": True
                    },
                },
            },
            {
                "name": "generate_prompt",
                "description": "AI向け整合性チェックプロンプトを生成",
                "parameters": {
                    "source": {
                        "type": "string",
                        "description": "ソースコード",
                        "required": True
                    },
                    "flow_name": {
                        "type": "string",
                        "description": "フロー名",
                        "default": None
                    },
                },
            },
            {
                "name": "list_flows",
                "description": "設計書のフロー一覧を取得",
                "parameters": {},
            },
            {
                "name": "get_flow_detail",
                "description": "フローの詳細を取得",
                "parameters": {
                    "flow_name": {
                        "type": "string",
                        "description": "フロー名",
                        "required": True
                    },
                },
            },
            {
                "name": "export_report",
                "description": "整合性チェックレポートをMarkdownで出力",
                "parameters": {
                    "results": {
                        "type": "array",
                        "description": "チェック結果の配列",
                        "required": True
                    },
                },
            },
        ]

    async def execute(self, action: str, params: dict) -> SkillResult:
        """アクションを実行"""
        actions = {
            "load_design": self._load_design,
            "load_mapping": self._load_mapping,
            "check_consistency": self._check_consistency,
            "check_flow_order": self._check_flow_order,
            "generate_prompt": self._generate_prompt,
            "list_flows": self._list_flows,
            "get_flow_detail": self._get_flow_detail,
            "export_report": self._export_report,
        }

        handler = actions.get(action)
        if handler is None:
            return SkillResult.error(
                error=f"Unknown action: {action}",
                message=f"不明なアクション: {action}",
            )

        return await handler(params)

    async def _load_design(self, params: dict) -> SkillResult:
        """設計書を読み込み"""
        path = params.get("path")
        if not path:
            return SkillResult.error("path is required", "パスが必要です")

        design_path = Path(path)
        if not design_path.exists():
            return SkillResult.error(
                f"File not found: {path}",
                "ファイルが見つかりません"
            )

        try:
            parsed = self._md_parser.parse_file(design_path)
            self._design = self._parse_design(parsed)
            self._design_path = design_path

            return SkillResult.success(
                data={
                    "title": self._design.title,
                    "version": self._design.version,
                    "flows_count": len(self._design.flows),
                    "flows": [f.name for f in self._design.flows],
                },
                message="設計書を読み込みました",
            )
        except Exception as e:
            return SkillResult.error(str(e), "設計書の読み込みに失敗")

    def _parse_design(self, parsed: ParsedSection) -> DesignDocument:
        """パースされたMarkdownから設計書を構築"""
        design = DesignDocument(title="")
        design.raw_sections = parsed.get_all_sections()

        # タイトルと基本情報
        for section in parsed.subsections:
            if section.level == 1:
                design.title = section.title
                break

        basic_section = parsed.find_section("基本情報")
        if basic_section:
            meta = basic_section.metadata
            design.version = meta.get("バージョン", "")
            design.description = meta.get("概要", "")

        # 処理フローを抽出
        for section in parsed.get_all_sections():
            # Mermaidフローチャートを含むセクション
            mermaid_diagrams = section.metadata.get("mermaid", [])
            for mermaid_code in mermaid_diagrams:
                flow = self._parse_flow_from_mermaid(section.title, mermaid_code)
                if flow:
                    design.flows.append(flow)

            # テーブル形式の処理ステップ
            if "処理フロー" in section.title or "処理手順" in section.title:
                flow = self._parse_flow_from_section(section)
                if flow and flow.steps:
                    design.flows.append(flow)

        return design

    def _parse_flow_from_mermaid(
        self, flow_name: str, mermaid_code: str
    ) -> Optional[ProcessFlow]:
        """Mermaidフローチャートからフローを抽出"""
        if not mermaid_code.strip():
            return None

        parsed = self._mermaid_parser.parse(mermaid_code)
        steps_data = self._mermaid_parser.get_flow_steps(mermaid_code)

        flow = ProcessFlow(name=flow_name)

        for step_data in steps_data:
            step = ProcessStep(
                id=step_data["id"],
                label=step_data["label"],
            )
            flow.steps.append(step)

        # エッジからconditionsとnext_stepsを設定
        for edge in parsed.get("edges", []):
            from_step = self._find_step(flow.steps, edge["from"])
            if from_step:
                from_step.next_steps.append(edge["to"])
                if edge.get("label"):
                    from_step.conditions.append(edge["label"])

        return flow

    def _find_step(self, steps: list[ProcessStep], step_id: str) -> Optional[ProcessStep]:
        """IDでステップを検索"""
        for step in steps:
            if step.id == step_id:
                return step
        return None

    def _parse_flow_from_section(self, section: ParsedSection) -> ProcessFlow:
        """セクションからフローを抽出"""
        flow = ProcessFlow(name=section.title)

        # テーブルからステップを抽出
        tables = section.metadata.get("tables", [])
        for table in tables:
            for row in table:
                step_id = row.get("ステップ", row.get("No", ""))
                step_label = row.get("処理内容", row.get("説明", ""))
                step_condition = row.get("条件", "")

                if step_id and step_label:
                    step = ProcessStep(
                        id=str(step_id),
                        label=step_label,
                        description=row.get("詳細", ""),
                    )
                    if step_condition:
                        step.conditions.append(step_condition)
                    flow.steps.append(step)

        # リスト形式からステップを抽出
        list_items = self._md_parser.extract_list_items(section.content)
        for i, item in enumerate(list_items, 1):
            if item.content and not any(s.label == item.content for s in flow.steps):
                step = ProcessStep(
                    id=str(i),
                    label=item.content,
                )
                flow.steps.append(step)

        return flow

    async def _load_mapping(self, params: dict) -> SkillResult:
        """紐付け定義を読み込み"""
        path = params.get("path")
        if not path:
            return SkillResult.error("path is required", "パスが必要です")

        mapping_path = Path(path)
        if not mapping_path.exists():
            return SkillResult.error(
                f"File not found: {path}",
                "ファイルが見つかりません"
            )

        if not self._design:
            return SkillResult.error(
                "No design loaded",
                "設計書が読み込まれていません"
            )

        try:
            with open(mapping_path, encoding="utf-8") as f:
                mapping_data = yaml.safe_load(f)

            mappings = self._parse_mappings(mapping_data)
            self._design.mappings = mappings

            return SkillResult.success(
                data={
                    "mappings_count": len(mappings),
                    "mappings": [
                        {
                            "design": m.design_element,
                            "source": m.source_file,
                            "method": m.method_name,
                        }
                        for m in mappings
                    ],
                },
                message="紐付け定義を読み込みました",
            )
        except Exception as e:
            return SkillResult.error(str(e), "紐付け定義の読み込みに失敗")

    def _parse_mappings(self, data: dict) -> list[DesignMapping]:
        """YAML紐付け定義をパース"""
        mappings = []

        mapping_list = data.get("mappings", [])
        for m in mapping_list:
            mapping = DesignMapping(
                design_element=m.get("design_element", ""),
                source_file=m.get("source_file", ""),
                class_name=m.get("class", ""),
                method_name=m.get("method", ""),
                line_start=m.get("line_start", 0),
                line_end=m.get("line_end", 0),
            )
            mappings.append(mapping)

        return mappings

    async def _check_consistency(self, params: dict) -> SkillResult:
        """整合性をチェック"""
        source_path = params.get("source_path")
        if not source_path:
            return SkillResult.error("source_path is required", "パスが必要です")

        if not self._design:
            return SkillResult.error(
                "No design loaded",
                "設計書が読み込まれていません"
            )

        file_path = Path(source_path)
        if not file_path.exists():
            return SkillResult.error(
                f"File not found: {source_path}",
                "ファイルが見つかりません"
            )

        flow_name = params.get("flow_name")

        try:
            source = file_path.read_text(encoding="utf-8")
            result = self._check_consistency_internal(
                source, str(file_path), flow_name
            )

            return SkillResult.success(
                data=result.to_dict(),
                message=f"整合性チェック完了: 一致率{result.match_rate:.1f}%",
            )
        except Exception as e:
            return SkillResult.error(str(e), "チェックに失敗")

    def _check_consistency_internal(
        self,
        source: str,
        source_path: str,
        flow_name: Optional[str] = None
    ) -> ConsistencyResult:
        """整合性チェック（内部）"""
        design_file = str(self._design_path) if self._design_path else "unknown"
        result = ConsistencyResult(
            design_file=design_file,
            source_file=source_path,
        )

        # 対象フローを取得
        flows = self._design.flows
        if flow_name:
            flows = [f for f in flows if f.name == flow_name]
            if not flows:
                result.add_issue(ConsistencyIssue(
                    design_element=flow_name,
                    source_location=source_path,
                    issue_type="missing",
                    severity="error",
                    message=f"フロー '{flow_name}' が設計書に見つかりません",
                ))
                return result

        # 各フローのステップをチェック
        for flow in flows:
            result.total_steps += len(flow.steps)

            for step in flow.steps:
                # ステップのラベルに関連するパターンをソースから検索
                found = self._find_step_implementation(source, step)

                if found:
                    result.matched_steps += 1
                else:
                    result.add_issue(ConsistencyIssue(
                        design_element=f"{flow.name}/{step.id}: {step.label}",
                        source_location=source_path,
                        issue_type="missing",
                        severity="warning",
                        message=f"設計ステップ '{step.label}' の実装が見つかりません",
                        suggestion="該当する処理を実装するか、設計書を更新してください",
                    ))

        return result

    def _find_step_implementation(self, source: str, step: ProcessStep) -> bool:
        """ソースコードでステップの実装を検索"""
        # ステップのラベルから検索キーワードを抽出
        keywords = self._extract_keywords(step.label)

        # コメント内での言及をチェック
        comment_patterns = [
            rf'//.*{kw}',
            rf'/\*.*{kw}.*\*/',
            rf'#.*{kw}',
            rf'""".*{kw}.*"""',
        ]

        for pattern in comment_patterns:
            for kw in keywords:
                if re.search(pattern, source, re.IGNORECASE | re.DOTALL):
                    return True

        # メソッド名からの推測
        method_patterns = [
            rf'def\s+\w*{kw}\w*\s*\(',
            rf'(?:public|private|protected)\s+\w+\s+\w*{kw}\w*\s*\(',
        ]

        for pattern in method_patterns:
            for kw in keywords:
                if re.search(pattern, source, re.IGNORECASE):
                    return True

        # 処理パターンの検出
        action_keywords = {
            "登録": ["insert", "create", "save", "add", "register"],
            "更新": ["update", "modify", "edit", "change"],
            "削除": ["delete", "remove", "destroy"],
            "検索": ["find", "search", "get", "fetch", "query", "select"],
            "検証": ["validate", "verify", "check"],
            "送信": ["send", "post", "submit"],
            "取得": ["get", "fetch", "retrieve", "load"],
            "変換": ["convert", "transform", "parse"],
            "チェック": ["check", "validate", "verify"],
            "保存": ["save", "store", "persist"],
        }

        for jp_keyword, en_keywords in action_keywords.items():
            if jp_keyword in step.label:
                for en_kw in en_keywords:
                    if re.search(rf'\b{en_kw}\w*\b', source, re.IGNORECASE):
                        return True

        return False

    def _extract_keywords(self, text: str) -> list[str]:
        """テキストからキーワードを抽出"""
        # 日本語のキーワードを抽出
        jp_keywords = re.findall(r'[一-龥ぁ-んァ-ン]+', text)

        # 英語のキーワードを抽出
        en_keywords = re.findall(r'[A-Za-z]{3,}', text)

        return jp_keywords + en_keywords

    async def _check_flow_order(self, params: dict) -> SkillResult:
        """フローの順序をチェック"""
        source_path = params.get("source_path")
        flow_name = params.get("flow_name")

        if not source_path:
            return SkillResult.error("source_path is required", "パスが必要です")
        if not flow_name:
            return SkillResult.error("flow_name is required", "フロー名が必要です")

        if not self._design:
            return SkillResult.error(
                "No design loaded",
                "設計書が読み込まれていません"
            )

        file_path = Path(source_path)
        if not file_path.exists():
            return SkillResult.error(
                f"File not found: {source_path}",
                "ファイルが見つかりません"
            )

        # フローを取得
        flow = None
        for f in self._design.flows:
            if f.name == flow_name:
                flow = f
                break

        if not flow:
            return SkillResult.error(
                f"Flow not found: {flow_name}",
                "フローが見つかりません"
            )

        try:
            source = file_path.read_text(encoding="utf-8")
            order_issues = self._check_order_internal(source, flow)

            return SkillResult.success(
                data={
                    "flow_name": flow_name,
                    "order_issues": order_issues,
                    "is_valid": len(order_issues) == 0,
                },
                message=f"順序チェック完了: {len(order_issues)}件の問題",
            )
        except Exception as e:
            return SkillResult.error(str(e), "チェックに失敗")

    def _check_order_internal(
        self, source: str, flow: ProcessFlow
    ) -> list[dict[str, Any]]:
        """順序チェック（内部）"""
        issues = []
        lines = source.split('\n')

        # 各ステップの出現位置を検出
        step_positions: list[tuple[ProcessStep, int]] = []

        for step in flow.steps:
            keywords = self._extract_keywords(step.label)
            position = self._find_first_occurrence(lines, keywords)
            if position > 0:
                step_positions.append((step, position))

        # 順序をチェック
        for i in range(len(step_positions) - 1):
            current_step, current_pos = step_positions[i]
            next_step, next_pos = step_positions[i + 1]

            if current_pos > next_pos:
                issues.append({
                    "step1": {
                        "id": current_step.id,
                        "label": current_step.label,
                        "line": current_pos,
                    },
                    "step2": {
                        "id": next_step.id,
                        "label": next_step.label,
                        "line": next_pos,
                    },
                    "message": f"ステップ '{current_step.label}' が "
                               f"'{next_step.label}' より後に出現しています",
                })

        return issues

    def _find_first_occurrence(
        self, lines: list[str], keywords: list[str]
    ) -> int:
        """キーワードの最初の出現位置を検索"""
        for i, line in enumerate(lines, 1):
            line_lower = line.lower()
            for kw in keywords:
                if kw.lower() in line_lower:
                    return i
        return -1

    async def _generate_prompt(self, params: dict) -> SkillResult:
        """AI向けプロンプトを生成"""
        source = params.get("source")
        if not source:
            return SkillResult.error("source is required", "ソースが必要です")

        if not self._design:
            return SkillResult.error(
                "No design loaded",
                "設計書が読み込まれていません"
            )

        flow_name = params.get("flow_name")
        prompt = self._build_ai_prompt(source, flow_name)

        return SkillResult.success(
            data={"prompt": prompt},
            message="プロンプトを生成しました",
        )

    def _build_ai_prompt(
        self, source: str, flow_name: Optional[str] = None
    ) -> str:
        """AI向けプロンプトを構築"""
        prompt_parts = [
            "# 設計・実装整合性チェック指示\n",
            "あなたは設計書と実装コードの整合性をチェックするレビュアーです。",
            "以下の設計書に基づいて、提供されたコードが正しく実装されているか確認してください。\n",
            "## 設計書情報\n",
            f"- **タイトル**: {self._design.title}",
            f"- **バージョン**: {self._design.version}",
            f"- **概要**: {self._design.description}\n",
        ]

        # フロー情報
        flows = self._design.flows
        if flow_name:
            flows = [f for f in flows if f.name == flow_name]

        prompt_parts.append("## 処理フロー\n")

        for flow in flows:
            prompt_parts.append(f"### {flow.name}\n")
            for step in flow.steps:
                conditions_str = ""
                if step.conditions:
                    conditions_str = f" [条件: {', '.join(step.conditions)}]"
                prompt_parts.append(f"- **ステップ {step.id}**: {step.label}{conditions_str}")
            prompt_parts.append("")

        # ソースコード
        prompt_parts.append("## チェック対象コード\n")
        prompt_parts.append("```")
        prompt_parts.append(source)
        prompt_parts.append("```\n")

        # チェック指示
        prompt_parts.append("## チェック項目\n")
        prompt_parts.append("1. **ステップの網羅性**: 設計書の全ステップが実装されているか")
        prompt_parts.append("2. **処理順序**: ステップの実行順序が設計書と一致しているか")
        prompt_parts.append("3. **条件分岐**: 設計書で定義された条件が正しく実装されているか")
        prompt_parts.append("4. **入出力**: 入力パラメータと出力が設計書と一致しているか\n")

        # 出力形式
        prompt_parts.append("## 出力形式\n")
        prompt_parts.append("以下のJSON形式でチェック結果を報告してください:")
        prompt_parts.append("```json")
        prompt_parts.append("""{
  "consistency_check": {
    "step_coverage": {
      "matched": ["ステップID..."],
      "missing": ["ステップID..."],
      "extra": ["追加の処理..."]
    },
    "order_check": {
      "is_valid": true/false,
      "issues": ["順序の問題..."]
    },
    "condition_check": {
      "matched": ["条件..."],
      "missing": ["条件..."]
    }
  },
  "issues": [
    {
      "design_element": "設計要素",
      "issue_type": "missing|mismatch|extra|order",
      "severity": "error|warning|info",
      "message": "問題の説明",
      "suggestion": "修正提案"
    }
  ],
  "summary": {
    "match_rate": "一致率%",
    "total_issues": 件数
  }
}""")
        prompt_parts.append("```")

        return "\n".join(prompt_parts)

    async def _list_flows(self, params: dict) -> SkillResult:
        """フロー一覧を取得"""
        if not self._design:
            return SkillResult.error(
                "No design loaded",
                "設計書が読み込まれていません"
            )

        flows_summary = [
            {
                "name": f.name,
                "description": f.description,
                "steps_count": len(f.steps),
            }
            for f in self._design.flows
        ]

        return SkillResult.success(
            data={
                "design_title": self._design.title,
                "flows": flows_summary,
            },
            message=f"{len(flows_summary)}件のフローを取得",
        )

    async def _get_flow_detail(self, params: dict) -> SkillResult:
        """フロー詳細を取得"""
        flow_name = params.get("flow_name")
        if not flow_name:
            return SkillResult.error("flow_name is required", "フロー名が必要です")

        if not self._design:
            return SkillResult.error(
                "No design loaded",
                "設計書が読み込まれていません"
            )

        flow = None
        for f in self._design.flows:
            if f.name == flow_name:
                flow = f
                break

        if not flow:
            return SkillResult.error(
                f"Flow not found: {flow_name}",
                "フローが見つかりません"
            )

        return SkillResult.success(
            data={
                "name": flow.name,
                "description": flow.description,
                "input_params": flow.input_params,
                "output": flow.output,
                "steps": [
                    {
                        "id": s.id,
                        "label": s.label,
                        "description": s.description,
                        "conditions": s.conditions,
                        "next_steps": s.next_steps,
                    }
                    for s in flow.steps
                ],
            },
            message=f"フロー '{flow_name}' の詳細を取得",
        )

    async def _export_report(self, params: dict) -> SkillResult:
        """レポートをMarkdownで出力"""
        results = params.get("results", [])

        if not results:
            return SkillResult.error("results is required", "結果が必要です")

        report_parts = ["# 設計・実装整合性チェックレポート\n"]

        for result in results:
            design_file = result.get("design_file", "unknown")
            source_file = result.get("source_file", "unknown")
            summary = result.get("summary", {})
            issues = result.get("issues", [])

            report_parts.append(f"\n## チェック結果\n")
            report_parts.append(f"- **設計書**: {design_file}")
            report_parts.append(f"- **ソース**: {source_file}")
            report_parts.append(f"- **一致率**: {summary.get('match_rate', 'N/A')}")
            report_parts.append(
                f"- **ステップ**: {summary.get('matched_steps', 0)} / "
                f"{summary.get('total_steps', 0)}"
            )

            if issues:
                report_parts.append("\n### 検出された問題\n")
                report_parts.append("| 設計要素 | 種別 | 重要度 | メッセージ |")
                report_parts.append("|---------|------|--------|----------|")

                for issue in issues:
                    report_parts.append(
                        f"| {issue['design_element']} | {issue['issue_type']} | "
                        f"{issue['severity']} | {issue['message']} |"
                    )
            else:
                report_parts.append("\n✅ 問題は検出されませんでした。\n")

        report = "\n".join(report_parts)

        return SkillResult.success(
            data={"report": report},
            message="レポートを生成しました",
        )
