"""コーディング規約チェックスキル

Markdown形式で定義されたコーディング規約に基づいてコードをチェックする。
"""

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Any

from app.skills.base import BaseSkill, SkillResult
from app.skills.checker.markdown_parser import MarkdownParser, ParsedSection


@dataclass
class NamingRule:
    """命名規則"""
    target: str  # class, method, constant, field, package
    pattern: str
    message: str
    severity: str = "error"
    examples: list[str] = field(default_factory=list)
    counter_examples: list[str] = field(default_factory=list)


@dataclass
class StructureRule:
    """構造規則"""
    target: str  # method, class
    metric: str  # lines, parameters, nested_depth, complexity
    max_value: int
    severity: str = "warning"
    message: str = ""


@dataclass
class PatternRule:
    """パターン規則（禁止/必須パターン）"""
    name: str
    pattern: str
    is_forbidden: bool = True  # True: 禁止, False: 必須
    severity: str = "error"
    message: str = ""
    suggestion: str = ""


@dataclass
class AnnotationRule:
    """アノテーション規則"""
    target_pattern: str  # クラス名パターン
    required_annotations: list[str] = field(default_factory=list)
    severity: str = "warning"
    message: str = ""


@dataclass
class CodingRulesConfig:
    """コーディング規約設定"""
    project: str = ""
    language: str = ""
    version: str = ""
    naming_rules: list[NamingRule] = field(default_factory=list)
    structure_rules: list[StructureRule] = field(default_factory=list)
    pattern_rules: list[PatternRule] = field(default_factory=list)
    annotation_rules: list[AnnotationRule] = field(default_factory=list)


@dataclass
class Violation:
    """違反"""
    line: int
    rule: str
    severity: str
    message: str
    suggestion: str = ""
    code_snippet: str = ""


@dataclass
class CheckResult:
    """チェック結果"""
    file_path: str
    violations: list[Violation] = field(default_factory=list)
    errors: int = 0
    warnings: int = 0
    info: int = 0

    def add_violation(self, violation: Violation) -> None:
        self.violations.append(violation)
        if violation.severity == "error":
            self.errors += 1
        elif violation.severity == "warning":
            self.warnings += 1
        else:
            self.info += 1

    def to_dict(self) -> dict:
        return {
            "file_path": self.file_path,
            "violations": [
                {
                    "line": v.line,
                    "rule": v.rule,
                    "severity": v.severity,
                    "message": v.message,
                    "suggestion": v.suggestion,
                    "code_snippet": v.code_snippet,
                }
                for v in self.violations
            ],
            "summary": {
                "errors": self.errors,
                "warnings": self.warnings,
                "info": self.info,
                "total": len(self.violations),
            },
        }


class CodingRulesSkill(BaseSkill):
    """コーディング規約チェックスキル"""

    def __init__(self):
        self._parser = MarkdownParser()
        self._config: Optional[CodingRulesConfig] = None
        self._rules_path: Optional[Path] = None

    @property
    def name(self) -> str:
        return "coding_rules"

    @property
    def description(self) -> str:
        return "Markdown形式のコーディング規約に基づいてコードをチェック"

    def get_actions(self) -> list[dict]:
        return [
            {
                "name": "load_rules",
                "description": "Markdown規約ファイルを読み込み",
                "parameters": {
                    "path": {
                        "type": "string",
                        "description": "規約ファイルのパス",
                        "required": True
                    },
                },
            },
            {
                "name": "check_file",
                "description": "ファイルを規約チェック",
                "parameters": {
                    "path": {
                        "type": "string",
                        "description": "チェック対象ファイルのパス",
                        "required": True
                    },
                },
            },
            {
                "name": "check_source",
                "description": "ソースコードを直接チェック",
                "parameters": {
                    "source": {
                        "type": "string",
                        "description": "ソースコード",
                        "required": True
                    },
                    "language": {
                        "type": "string",
                        "description": "言語",
                        "required": True
                    },
                },
            },
            {
                "name": "check_project",
                "description": "プロジェクト全体をチェック",
                "parameters": {
                    "path": {
                        "type": "string",
                        "description": "プロジェクトのルートパス",
                        "required": True
                    },
                    "pattern": {
                        "type": "string",
                        "description": "ファイルパターン",
                        "default": "**/*.java"
                    },
                    "max_files": {
                        "type": "integer",
                        "description": "最大ファイル数",
                        "default": 100
                    },
                },
            },
            {
                "name": "generate_prompt",
                "description": "AI向けチェックプロンプトを生成",
                "parameters": {
                    "source": {
                        "type": "string",
                        "description": "チェック対象ソースコード",
                        "required": True
                    },
                },
            },
            {
                "name": "list_rules",
                "description": "現在の規約一覧を表示",
                "parameters": {},
            },
            {
                "name": "export_report",
                "description": "チェック結果をMarkdownで出力",
                "parameters": {
                    "results": {
                        "type": "array",
                        "description": "チェック結果の配列",
                        "required": True
                    },
                },
            },
        ]

    async def execute(self, action: str, params: dict) -> SkillResult:
        """アクションを実行"""
        actions = {
            "load_rules": self._load_rules,
            "check_file": self._check_file,
            "check_source": self._check_source,
            "check_project": self._check_project,
            "generate_prompt": self._generate_prompt,
            "list_rules": self._list_rules,
            "export_report": self._export_report,
        }

        handler = actions.get(action)
        if handler is None:
            return SkillResult.error(
                error=f"Unknown action: {action}",
                message=f"不明なアクション: {action}",
            )

        return await handler(params)

    async def _load_rules(self, params: dict) -> SkillResult:
        """規約ファイルを読み込み"""
        path = params.get("path")
        if not path:
            return SkillResult.error("path is required", "パスが必要です")

        rules_path = Path(path)
        if not rules_path.exists():
            return SkillResult.error(
                f"File not found: {path}",
                "ファイルが見つかりません"
            )

        try:
            parsed = self._parser.parse_file(rules_path)
            self._config = self._parse_rules(parsed)
            self._rules_path = rules_path

            return SkillResult.success(
                data={
                    "project": self._config.project,
                    "language": self._config.language,
                    "naming_rules": len(self._config.naming_rules),
                    "structure_rules": len(self._config.structure_rules),
                    "pattern_rules": len(self._config.pattern_rules),
                    "annotation_rules": len(self._config.annotation_rules),
                },
                message="規約ファイルを読み込みました",
            )
        except Exception as e:
            return SkillResult.error(str(e), "規約ファイルの読み込みに失敗")

    def _parse_rules(self, parsed: ParsedSection) -> CodingRulesConfig:
        """パースされたMarkdownから規約を抽出"""
        config = CodingRulesConfig()

        # 基本情報
        basic_section = parsed.find_section("基本情報")
        if basic_section:
            meta = basic_section.metadata
            config.project = meta.get("プロジェクト", "")
            config.language = meta.get("言語", "")
            config.version = meta.get("バージョン", "")

        # 命名規則
        naming_section = parsed.find_section("命名規則")
        if naming_section:
            for sub in naming_section.subsections:
                rule = self._parse_naming_rule(sub)
                if rule:
                    config.naming_rules.append(rule)

        # 構造規則
        structure_section = parsed.find_section("構造規則")
        if structure_section:
            config.structure_rules = self._parse_structure_rules(structure_section)

        # 禁止パターン
        forbidden_section = parsed.find_section("禁止パターン")
        if forbidden_section:
            for sub in forbidden_section.subsections:
                rule = self._parse_pattern_rule(sub, is_forbidden=True)
                if rule:
                    config.pattern_rules.append(rule)

        # アノテーション規則
        annotation_section = parsed.find_section("アノテーション規則")
        if annotation_section:
            for sub in annotation_section.subsections:
                rule = self._parse_annotation_rule(sub)
                if rule:
                    config.annotation_rules.append(rule)

        return config

    def _parse_naming_rule(self, section: ParsedSection) -> Optional[NamingRule]:
        """命名規則をパース"""
        meta = section.metadata
        pattern = meta.get("パターン", "")

        # パターン名からターゲットを推定
        target_map = {
            "クラス名": "class",
            "メソッド名": "method",
            "定数": "constant",
            "パッケージ名": "package",
            "変数名": "variable",
            "フィールド": "field",
        }
        target = target_map.get(section.title, "unknown")

        if not pattern:
            return None

        # パターン名を正規表現に変換
        pattern_regex = self._pattern_name_to_regex(pattern)

        return NamingRule(
            target=target,
            pattern=pattern_regex,
            message=meta.get("メッセージ", f"{section.title}の命名規則違反"),
            severity=self._parse_severity(meta.get("重要度", "error")),
            examples=[meta.get("例", "")],
            counter_examples=[meta.get("禁止例", "")],
        )

    def _pattern_name_to_regex(self, pattern_name: str) -> str:
        """パターン名を正規表現に変換"""
        patterns = {
            "PascalCase": r"^[A-Z][a-zA-Z0-9]*$",
            "camelCase": r"^[a-z][a-zA-Z0-9]*$",
            "UPPER_SNAKE_CASE": r"^[A-Z][A-Z0-9_]*$",
            "snake_case": r"^[a-z][a-z0-9_]*$",
            "小文字のみ、ドット区切り": r"^[a-z][a-z0-9.]*$",
        }
        return patterns.get(pattern_name, pattern_name)

    def _parse_structure_rules(self, section: ParsedSection) -> list[StructureRule]:
        """構造規則をパース"""
        rules = []

        for sub in section.subsections:
            tables = sub.metadata.get("tables", [])
            for table in tables:
                for row in table:
                    metric = row.get("項目", "")
                    max_val = row.get("上限", "")
                    severity = row.get("重要度", "warning")

                    if metric and max_val:
                        # 数値を抽出
                        max_num = int(re.search(r'\d+', max_val).group())

                        metric_map = {
                            "行数": "lines",
                            "パラメータ数": "parameters",
                            "ネスト深度": "nested_depth",
                            "循環的複雑度": "complexity",
                            "メソッド数": "method_count",
                            "フィールド数": "field_count",
                        }

                        rules.append(StructureRule(
                            target=sub.title.lower(),
                            metric=metric_map.get(metric, metric),
                            max_value=max_num,
                            severity=self._parse_severity(severity),
                        ))

        return rules

    def _parse_pattern_rule(
        self, section: ParsedSection, is_forbidden: bool
    ) -> Optional[PatternRule]:
        """パターン規則をパース"""
        meta = section.metadata
        pattern = meta.get("パターン", "")

        if not pattern:
            return None

        return PatternRule(
            name=section.title,
            pattern=pattern,
            is_forbidden=is_forbidden,
            severity=self._parse_severity(meta.get("重要度", "error")),
            message=meta.get("理由", section.title),
            suggestion=meta.get("修正例", ""),
        )

    def _parse_annotation_rule(self, section: ParsedSection) -> Optional[AnnotationRule]:
        """アノテーション規則をパース"""
        # コードブロックからアノテーションを抽出
        code_blocks = section.metadata.get("code_blocks", [])
        annotations = []

        for block in code_blocks:
            if block.get("language") == "java":
                code = block.get("code", "")
                # アノテーションを抽出
                for match in re.finditer(r'@\w+(?:\([^)]*\))?', code):
                    annotations.append(match.group())

        target = section.title.replace("クラス", "").strip()

        return AnnotationRule(
            target_pattern=f".*{target}$" if target else ".*",
            required_annotations=annotations,
            message=f"{section.title}に必須のアノテーションが不足しています",
        )

    def _parse_severity(self, severity_str: str) -> str:
        """重要度を正規化"""
        s = severity_str.lower()
        if "エラー" in s or "error" in s:
            return "error"
        elif "警告" in s or "warning" in s:
            return "warning"
        else:
            return "info"

    async def _check_file(self, params: dict) -> SkillResult:
        """ファイルをチェック"""
        path = params.get("path")
        if not path:
            return SkillResult.error("path is required", "パスが必要です")

        if not self._config:
            return SkillResult.error(
                "No rules loaded",
                "規約が読み込まれていません。先にload_rulesを実行してください"
            )

        file_path = Path(path)
        if not file_path.exists():
            return SkillResult.error(
                f"File not found: {path}",
                "ファイルが見つかりません"
            )

        try:
            source = file_path.read_text(encoding="utf-8")
            result = self._check_source_internal(source, str(file_path))

            return SkillResult.success(
                data=result.to_dict(),
                message=f"チェック完了: {result.errors}エラー, {result.warnings}警告",
            )
        except Exception as e:
            return SkillResult.error(str(e), "チェックに失敗")

    async def _check_source(self, params: dict) -> SkillResult:
        """ソースコードを直接チェック"""
        source = params.get("source")
        if not source:
            return SkillResult.error("source is required", "ソースが必要です")

        if not self._config:
            return SkillResult.error(
                "No rules loaded",
                "規約が読み込まれていません"
            )

        result = self._check_source_internal(source, "<source>")

        return SkillResult.success(
            data=result.to_dict(),
            message=f"チェック完了: {result.errors}エラー, {result.warnings}警告",
        )

    def _check_source_internal(self, source: str, file_path: str) -> CheckResult:
        """ソースコードをチェック（内部）"""
        result = CheckResult(file_path=file_path)
        lines = source.split('\n')

        # 禁止パターンチェック
        for rule in self._config.pattern_rules:
            if rule.is_forbidden:
                for i, line in enumerate(lines, 1):
                    if re.search(rule.pattern, line):
                        result.add_violation(Violation(
                            line=i,
                            rule=f"pattern.{rule.name}",
                            severity=rule.severity,
                            message=rule.message,
                            suggestion=rule.suggestion,
                            code_snippet=line.strip(),
                        ))

        # 命名規則チェック（簡易版）
        for rule in self._config.naming_rules:
            violations = self._check_naming_rule(source, lines, rule)
            for v in violations:
                result.add_violation(v)

        # 構造規則チェック（簡易版）
        for rule in self._config.structure_rules:
            violations = self._check_structure_rule(source, lines, rule)
            for v in violations:
                result.add_violation(v)

        return result

    def _check_naming_rule(
        self, source: str, lines: list[str], rule: NamingRule
    ) -> list[Violation]:
        """命名規則をチェック"""
        violations = []

        # ターゲットに応じたパターンで名前を抽出
        if rule.target == "class":
            pattern = r'class\s+(\w+)'
        elif rule.target == "method":
            pattern = r'(?:public|private|protected|static|\s)+\s+\w+\s+(\w+)\s*\('
        elif rule.target == "constant":
            pattern = r'(?:static\s+final|final\s+static)\s+\w+\s+(\w+)\s*='
        elif rule.target == "variable":
            pattern = r'(?:int|String|boolean|long|double|float|\w+)\s+(\w+)\s*[;=]'
        else:
            return violations

        for i, line in enumerate(lines, 1):
            for match in re.finditer(pattern, line):
                name = match.group(1)
                if not re.match(rule.pattern, name):
                    violations.append(Violation(
                        line=i,
                        rule=f"naming.{rule.target}",
                        severity=rule.severity,
                        message=f"{rule.message}: '{name}'",
                        code_snippet=line.strip(),
                    ))

        return violations

    def _check_structure_rule(
        self, source: str, lines: list[str], rule: StructureRule
    ) -> list[Violation]:
        """構造規則をチェック"""
        violations = []

        if rule.metric == "lines" and rule.target == "メソッド":
            # メソッドの行数をチェック（簡易版）
            method_pattern = r'(?:public|private|protected|static|\s)+\s+\w+\s+(\w+)\s*\([^)]*\)\s*\{'
            brace_count = 0
            in_method = False
            method_start = 0
            method_name = ""

            for i, line in enumerate(lines, 1):
                if not in_method:
                    match = re.search(method_pattern, line)
                    if match:
                        in_method = True
                        method_start = i
                        method_name = match.group(1)
                        brace_count = line.count('{') - line.count('}')
                else:
                    brace_count += line.count('{') - line.count('}')
                    if brace_count <= 0:
                        method_lines = i - method_start + 1
                        if method_lines > rule.max_value:
                            violations.append(Violation(
                                line=method_start,
                                rule=f"structure.{rule.metric}",
                                severity=rule.severity,
                                message=f"メソッド '{method_name}' が{method_lines}行です（最大: {rule.max_value}行）",
                            ))
                        in_method = False

        elif rule.metric == "parameters":
            # パラメータ数をチェック
            method_pattern = r'(?:public|private|protected|static|\s)+\s+\w+\s+(\w+)\s*\(([^)]*)\)'
            for i, line in enumerate(lines, 1):
                match = re.search(method_pattern, line)
                if match:
                    method_name = match.group(1)
                    params_str = match.group(2)
                    if params_str.strip():
                        param_count = len(params_str.split(','))
                        if param_count > rule.max_value:
                            violations.append(Violation(
                                line=i,
                                rule=f"structure.{rule.metric}",
                                severity=rule.severity,
                                message=f"メソッド '{method_name}' のパラメータが{param_count}個です（最大: {rule.max_value}個）",
                            ))

        return violations

    async def _check_project(self, params: dict) -> SkillResult:
        """プロジェクト全体をチェック"""
        path = params.get("path")
        if not path:
            return SkillResult.error("path is required", "パスが必要です")

        if not self._config:
            return SkillResult.error(
                "No rules loaded",
                "規約が読み込まれていません"
            )

        pattern = params.get("pattern", "**/*.java")
        max_files = params.get("max_files", 100)

        root_path = Path(path)
        if not root_path.exists():
            return SkillResult.error(
                f"Path not found: {path}",
                "パスが見つかりません"
            )

        files = list(root_path.glob(pattern))[:max_files]
        results = []
        total_errors = 0
        total_warnings = 0

        for file_path in files:
            try:
                source = file_path.read_text(encoding="utf-8")
                result = self._check_source_internal(source, str(file_path))
                results.append(result.to_dict())
                total_errors += result.errors
                total_warnings += result.warnings
            except Exception:
                pass

        return SkillResult.success(
            data={
                "files_checked": len(results),
                "total_errors": total_errors,
                "total_warnings": total_warnings,
                "results": results,
            },
            message=f"{len(results)}ファイルをチェック: {total_errors}エラー, {total_warnings}警告",
        )

    async def _generate_prompt(self, params: dict) -> SkillResult:
        """AI向けプロンプトを生成"""
        source = params.get("source")
        if not source:
            return SkillResult.error("source is required", "ソースが必要です")

        if not self._config:
            return SkillResult.error(
                "No rules loaded",
                "規約が読み込まれていません"
            )

        prompt = self._build_ai_prompt(source)

        return SkillResult.success(
            data={"prompt": prompt},
            message="プロンプトを生成しました",
        )

    def _build_ai_prompt(self, source: str) -> str:
        """AI向けプロンプトを構築"""
        prompt_parts = [
            "# コーディング規約チェック指示\n",
            "あなたはコーディング規約のレビュアーです。",
            "以下の規約に基づいて、提供されたコードをチェックしてください。\n",
            "## チェック対象コード",
            "```",
            source,
            "```\n",
            "## 適用する規約\n",
        ]

        # 命名規則
        if self._config.naming_rules:
            prompt_parts.append("### 命名規則")
            for i, rule in enumerate(self._config.naming_rules, 1):
                prompt_parts.append(f"{i}. {rule.target}は{rule.pattern}形式")

        # 構造規則
        if self._config.structure_rules:
            prompt_parts.append("\n### 構造規則")
            for i, rule in enumerate(self._config.structure_rules, 1):
                prompt_parts.append(
                    f"{i}. {rule.target}の{rule.metric}は{rule.max_value}以下"
                )

        # 禁止パターン
        if self._config.pattern_rules:
            prompt_parts.append("\n### 禁止パターン")
            for i, rule in enumerate(self._config.pattern_rules, 1):
                if rule.is_forbidden:
                    prompt_parts.append(f"{i}. {rule.name}: {rule.message}")

        # 出力形式
        prompt_parts.append("\n## 出力形式\n")
        prompt_parts.append("以下のJSON形式で違反を報告してください:")
        prompt_parts.append("```json")
        prompt_parts.append("""{
  "violations": [
    {
      "line": 行番号,
      "rule": "規則名",
      "severity": "error|warning|info",
      "message": "違反内容の説明",
      "suggestion": "修正提案"
    }
  ],
  "summary": {
    "errors": エラー数,
    "warnings": 警告数,
    "info": 情報数
  }
}""")
        prompt_parts.append("```")

        return "\n".join(prompt_parts)

    async def _list_rules(self, params: dict) -> SkillResult:
        """規約一覧を表示"""
        if not self._config:
            return SkillResult.error(
                "No rules loaded",
                "規約が読み込まれていません"
            )

        rules_summary = {
            "project": self._config.project,
            "language": self._config.language,
            "naming_rules": [
                {"target": r.target, "pattern": r.pattern}
                for r in self._config.naming_rules
            ],
            "structure_rules": [
                {"target": r.target, "metric": r.metric, "max": r.max_value}
                for r in self._config.structure_rules
            ],
            "pattern_rules": [
                {"name": r.name, "forbidden": r.is_forbidden}
                for r in self._config.pattern_rules
            ],
            "annotation_rules": [
                {"target": r.target_pattern, "annotations": r.required_annotations}
                for r in self._config.annotation_rules
            ],
        }

        return SkillResult.success(
            data=rules_summary,
            message="規約一覧を取得しました",
        )

    async def _export_report(self, params: dict) -> SkillResult:
        """レポートをMarkdownで出力"""
        results = params.get("results", [])

        if not results:
            return SkillResult.error("results is required", "結果が必要です")

        report_parts = ["# コーディング規約チェックレポート\n"]

        total_errors = 0
        total_warnings = 0

        for result in results:
            file_path = result.get("file_path", "unknown")
            violations = result.get("violations", [])
            summary = result.get("summary", {})

            total_errors += summary.get("errors", 0)
            total_warnings += summary.get("warnings", 0)

            if violations:
                report_parts.append(f"\n## {file_path}\n")
                report_parts.append("| 行 | 重要度 | 規則 | メッセージ |")
                report_parts.append("|---|--------|------|----------|")

                for v in violations:
                    report_parts.append(
                        f"| {v['line']} | {v['severity']} | "
                        f"{v['rule']} | {v['message']} |"
                    )

        report_parts.insert(1, f"\n**サマリー**: {total_errors}エラー, {total_warnings}警告\n")

        report = "\n".join(report_parts)

        return SkillResult.success(
            data={"report": report},
            message="レポートを生成しました",
        )
