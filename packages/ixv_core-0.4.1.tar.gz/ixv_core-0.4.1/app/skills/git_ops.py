"""Git操作スキル"""

import asyncio
from pathlib import Path
from typing import Optional

from app.skills.base import BaseSkill, SkillResult


class GitOpsSkill(BaseSkill):
    """Git操作スキル

    Gitリポジトリの操作を行う。
    """

    def __init__(self, repo_path: Optional[str] = None, timeout: int = 30):
        """初期化

        Args:
            repo_path: リポジトリのパス（Noneの場合はカレントディレクトリ）
            timeout: コマンドタイムアウト（秒）
        """
        self._repo_path = Path(repo_path) if repo_path else None
        self._timeout = timeout

    @property
    def name(self) -> str:
        return "git_ops"

    @property
    def description(self) -> str:
        return "Gitリポジトリを操作するスキル"

    def get_actions(self) -> list[dict]:
        return [
            {
                "name": "status",
                "description": "リポジトリの状態を確認",
                "parameters": {
                    "path": {"type": "string", "description": "リポジトリパス", "default": "."},
                },
            },
            {
                "name": "diff",
                "description": "変更差分を表示",
                "parameters": {
                    "path": {"type": "string", "description": "リポジトリパス", "default": "."},
                    "staged": {"type": "boolean", "description": "ステージ済みの差分を表示", "default": False},
                    "file": {"type": "string", "description": "特定ファイルの差分のみ表示", "default": None},
                },
            },
            {
                "name": "log",
                "description": "コミット履歴を表示",
                "parameters": {
                    "path": {"type": "string", "description": "リポジトリパス", "default": "."},
                    "count": {"type": "integer", "description": "表示するコミット数", "default": 10},
                    "oneline": {"type": "boolean", "description": "1行表示", "default": True},
                },
            },
            {
                "name": "branch",
                "description": "ブランチ一覧/作成",
                "parameters": {
                    "path": {"type": "string", "description": "リポジトリパス", "default": "."},
                    "name": {"type": "string", "description": "作成するブランチ名（省略時は一覧表示）", "default": None},
                    "all": {"type": "boolean", "description": "リモートブランチも表示", "default": False},
                },
            },
            {
                "name": "checkout",
                "description": "ブランチを切り替え",
                "parameters": {
                    "path": {"type": "string", "description": "リポジトリパス", "default": "."},
                    "branch": {"type": "string", "description": "切り替え先ブランチ", "required": True},
                    "create": {"type": "boolean", "description": "ブランチを新規作成して切り替え", "default": False},
                },
            },
            {
                "name": "add",
                "description": "ファイルをステージング",
                "parameters": {
                    "path": {"type": "string", "description": "リポジトリパス", "default": "."},
                    "files": {"type": "array", "description": "ステージングするファイル（空の場合は全て）", "default": []},
                },
            },
            {
                "name": "commit",
                "description": "コミットを作成",
                "parameters": {
                    "path": {"type": "string", "description": "リポジトリパス", "default": "."},
                    "message": {"type": "string", "description": "コミットメッセージ", "required": True},
                },
            },
            {
                "name": "push",
                "description": "リモートにプッシュ",
                "parameters": {
                    "path": {"type": "string", "description": "リポジトリパス", "default": "."},
                    "remote": {"type": "string", "description": "リモート名", "default": "origin"},
                    "branch": {"type": "string", "description": "ブランチ名（省略時は現在のブランチ）", "default": None},
                },
            },
            {
                "name": "pull",
                "description": "リモートからプル",
                "parameters": {
                    "path": {"type": "string", "description": "リポジトリパス", "default": "."},
                    "remote": {"type": "string", "description": "リモート名", "default": "origin"},
                    "branch": {"type": "string", "description": "ブランチ名（省略時は現在のブランチ）", "default": None},
                },
            },
            {
                "name": "stash",
                "description": "変更を一時退避",
                "parameters": {
                    "path": {"type": "string", "description": "リポジトリパス", "default": "."},
                    "action": {"type": "string", "description": "アクション（push/pop/list）", "default": "push"},
                    "message": {"type": "string", "description": "スタッシュメッセージ", "default": None},
                },
            },
            {
                "name": "show",
                "description": "コミット詳細を表示",
                "parameters": {
                    "path": {"type": "string", "description": "リポジトリパス", "default": "."},
                    "commit": {"type": "string", "description": "コミットハッシュ", "default": "HEAD"},
                },
            },
            {
                "name": "blame",
                "description": "ファイルの各行の最終変更者を表示",
                "parameters": {
                    "path": {"type": "string", "description": "リポジトリパス", "default": "."},
                    "file": {"type": "string", "description": "対象ファイル", "required": True},
                },
            },
        ]

    async def execute(self, action: str, params: dict) -> SkillResult:
        """アクションを実行"""
        actions = {
            "status": self._status,
            "diff": self._diff,
            "log": self._log,
            "branch": self._branch,
            "checkout": self._checkout,
            "add": self._add,
            "commit": self._commit,
            "push": self._push,
            "pull": self._pull,
            "stash": self._stash,
            "show": self._show,
            "blame": self._blame,
        }

        handler = actions.get(action)
        if handler is None:
            return SkillResult.error(
                error=f"Unknown action: {action}",
                message=f"不明なアクション: {action}",
            )

        return await handler(params)

    async def _run_git(self, args: list[str], cwd: Optional[Path] = None) -> SkillResult:
        """Gitコマンドを実行"""
        cmd = ["git"] + args
        work_dir = cwd or self._repo_path

        try:
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(work_dir) if work_dir else None,
            )

            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=self._timeout,
                )
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
                return SkillResult.error("Timeout", "タイムアウトしました")

            stdout_str = stdout.decode("utf-8", errors="replace")
            stderr_str = stderr.decode("utf-8", errors="replace")

            if process.returncode == 0:
                return SkillResult.success(
                    data={"output": stdout_str, "stderr": stderr_str},
                    message="実行完了",
                )
            else:
                return SkillResult.error(
                    error=stderr_str or stdout_str,
                    message=f"Gitコマンドエラー (exit code: {process.returncode})",
                )

        except FileNotFoundError:
            return SkillResult.error("git command not found", "gitコマンドが見つかりません")
        except Exception as e:
            return SkillResult.error(str(e), "実行エラー")

    async def _status(self, params: dict) -> SkillResult:
        """リポジトリ状態"""
        path = params.get("path", ".")
        cwd = Path(path) if path != "." else None

        result = await self._run_git(["status", "--porcelain=v1"], cwd)
        if result.status.value != "success":
            return result

        # ステータスをパース
        output = result.data["output"]
        files = []
        for line in output.strip().split("\n"):
            if line:
                status = line[:2]
                filename = line[3:]
                files.append({"status": status, "file": filename})

        # 現在のブランチも取得
        branch_result = await self._run_git(["branch", "--show-current"], cwd)
        current_branch = ""
        if branch_result.status.value == "success":
            current_branch = branch_result.data["output"].strip()

        return SkillResult.success(
            data={
                "branch": current_branch,
                "files": files,
                "clean": len(files) == 0,
            },
            message=f"ブランチ: {current_branch}, 変更ファイル: {len(files)}件",
        )

    async def _diff(self, params: dict) -> SkillResult:
        """差分表示"""
        path = params.get("path", ".")
        staged = params.get("staged", False)
        file = params.get("file")

        cwd = Path(path) if path != "." else None
        args = ["diff"]
        if staged:
            args.append("--staged")
        if file:
            args.extend(["--", file])

        return await self._run_git(args, cwd)

    async def _log(self, params: dict) -> SkillResult:
        """コミット履歴"""
        path = params.get("path", ".")
        count = params.get("count", 10)
        oneline = params.get("oneline", True)

        cwd = Path(path) if path != "." else None
        args = ["log", f"-{count}"]
        if oneline:
            args.append("--oneline")
        else:
            args.append("--pretty=format:%H%n%an <%ae>%n%ad%n%s%n")

        return await self._run_git(args, cwd)

    async def _branch(self, params: dict) -> SkillResult:
        """ブランチ操作"""
        path = params.get("path", ".")
        name = params.get("name")
        show_all = params.get("all", False)

        cwd = Path(path) if path != "." else None

        if name:
            # ブランチ作成
            return await self._run_git(["branch", name], cwd)
        else:
            # ブランチ一覧
            args = ["branch"]
            if show_all:
                args.append("-a")
            return await self._run_git(args, cwd)

    async def _checkout(self, params: dict) -> SkillResult:
        """ブランチ切り替え"""
        path = params.get("path", ".")
        branch = params.get("branch")
        create = params.get("create", False)

        if not branch:
            return SkillResult.error("branch is required", "ブランチ名が必要です")

        cwd = Path(path) if path != "." else None
        args = ["checkout"]
        if create:
            args.append("-b")
        args.append(branch)

        return await self._run_git(args, cwd)

    async def _add(self, params: dict) -> SkillResult:
        """ステージング"""
        path = params.get("path", ".")
        files = params.get("files", [])

        cwd = Path(path) if path != "." else None
        args = ["add"]
        if files:
            args.extend(files)
        else:
            args.append(".")

        return await self._run_git(args, cwd)

    async def _commit(self, params: dict) -> SkillResult:
        """コミット"""
        path = params.get("path", ".")
        message = params.get("message")

        if not message:
            return SkillResult.error("message is required", "コミットメッセージが必要です")

        cwd = Path(path) if path != "." else None
        return await self._run_git(["commit", "-m", message], cwd)

    async def _push(self, params: dict) -> SkillResult:
        """プッシュ"""
        path = params.get("path", ".")
        remote = params.get("remote", "origin")
        branch = params.get("branch")

        cwd = Path(path) if path != "." else None
        args = ["push", remote]
        if branch:
            args.append(branch)

        return await self._run_git(args, cwd)

    async def _pull(self, params: dict) -> SkillResult:
        """プル"""
        path = params.get("path", ".")
        remote = params.get("remote", "origin")
        branch = params.get("branch")

        cwd = Path(path) if path != "." else None
        args = ["pull", remote]
        if branch:
            args.append(branch)

        return await self._run_git(args, cwd)

    async def _stash(self, params: dict) -> SkillResult:
        """スタッシュ"""
        path = params.get("path", ".")
        action = params.get("action", "push")
        message = params.get("message")

        cwd = Path(path) if path != "." else None
        args = ["stash", action]
        if action == "push" and message:
            args.extend(["-m", message])

        return await self._run_git(args, cwd)

    async def _show(self, params: dict) -> SkillResult:
        """コミット詳細"""
        path = params.get("path", ".")
        commit = params.get("commit", "HEAD")

        cwd = Path(path) if path != "." else None
        return await self._run_git(["show", commit], cwd)

    async def _blame(self, params: dict) -> SkillResult:
        """Blame"""
        path = params.get("path", ".")
        file = params.get("file")

        if not file:
            return SkillResult.error("file is required", "ファイル名が必要です")

        cwd = Path(path) if path != "." else None
        return await self._run_git(["blame", file], cwd)
