"""スキル管理"""

from typing import Optional

from app.skills.base import BaseSkill, SkillResult


class SkillManager:
    """スキル管理クラス

    登録されたスキルを管理し、アクションの実行を仲介する。
    スキルの有効/無効を動的に切り替え可能。
    """

    _instance: Optional["SkillManager"] = None
    _skills: dict[str, BaseSkill]
    _enabled_skills: set[str]  # 有効なスキル名のセット

    def __new__(cls) -> "SkillManager":
        """シングルトンパターン"""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._skills = {}
            cls._instance._enabled_skills = set()
        return cls._instance

    def register(self, skill: BaseSkill, enabled: bool = True) -> None:
        """スキルを登録
        
        Args:
            skill: 登録するスキル
            enabled: 初期状態で有効にするか（デフォルト: True）
        """
        self._skills[skill.name] = skill
        if enabled:
            self._enabled_skills.add(skill.name)

    def unregister(self, skill_name: str) -> bool:
        """スキルを登録解除"""
        if skill_name in self._skills:
            del self._skills[skill_name]
            self._enabled_skills.discard(skill_name)
            return True
        return False

    def enable_skill(self, skill_name: str) -> bool:
        """スキルを有効化
        
        Returns:
            成功した場合True、スキルが存在しない場合False
        """
        if skill_name in self._skills:
            self._enabled_skills.add(skill_name)
            return True
        return False

    def disable_skill(self, skill_name: str) -> bool:
        """スキルを無効化
        
        Returns:
            成功した場合True、スキルが存在しない場合False
        """
        if skill_name in self._skills:
            self._enabled_skills.discard(skill_name)
            return True
        return False

    def is_enabled(self, skill_name: str) -> bool:
        """スキルが有効かどうかを確認"""
        return skill_name in self._enabled_skills

    def get_skill(self, skill_name: str) -> Optional[BaseSkill]:
        """スキルを取得"""
        return self._skills.get(skill_name)

    def list_skills(self) -> list[dict]:
        """登録済みスキル一覧を取得"""
        return [
            {
                "name": skill.name,
                "description": skill.description,
                "actions": [a["name"] for a in skill.get_actions()],
                "enabled": skill.name in self._enabled_skills,
            }
            for skill in self._skills.values()
        ]

    def get_skill_info(self, skill_name: str) -> Optional[dict]:
        """スキル詳細情報を取得"""
        skill = self._skills.get(skill_name)
        if skill is None:
            return None
        info = skill.get_info()
        return {
            "name": info.name,
            "description": info.description,
            "actions": info.actions,
            "enabled": skill_name in self._enabled_skills,
        }

    async def execute(
        self, skill_name: str, action: str, params: dict
    ) -> SkillResult:
        """スキルのアクションを実行"""
        skill = self._skills.get(skill_name)
        if skill is None:
            return SkillResult.error(
                error=f"Skill not found: {skill_name}",
                message="スキルが見つかりません",
            )

        if skill_name not in self._enabled_skills:
            return SkillResult.error(
                error=f"Skill is disabled: {skill_name}",
                message=f"スキル '{skill_name}' は無効化されています",
            )

        try:
            return await skill.execute(action, params)
        except Exception as e:
            return SkillResult.error(
                error=str(e),
                message=f"スキル実行中にエラーが発生しました: {skill_name}.{action}",
            )


# グローバルインスタンス
skill_manager = SkillManager()
