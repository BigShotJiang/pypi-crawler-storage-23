"""コード実行スキル"""

import asyncio
import os
import tempfile
from pathlib import Path
from typing import Optional

from app.skills.base import BaseSkill, SkillResult


class CodeExecSkill(BaseSkill):
    """コード実行スキル

    Python/シェルコードを安全に実行する。
    """

    def __init__(
        self,
        timeout: int = 30,
        max_output_size: int = 64 * 1024,
        working_dir: Optional[str] = None,
        allowed_commands: Optional[list[str]] = None,
    ):
        """初期化

        Args:
            timeout: 実行タイムアウト（秒）
            max_output_size: 最大出力サイズ（バイト）
            working_dir: 作業ディレクトリ
            allowed_commands: 許可するシェルコマンド（Noneの場合は制限なし）
        """
        self._timeout = timeout
        self._max_output_size = max_output_size
        self._working_dir = Path(working_dir) if working_dir else None
        self._allowed_commands = set(allowed_commands) if allowed_commands else None

    @property
    def name(self) -> str:
        return "code_exec"

    @property
    def description(self) -> str:
        return "Python/シェルコードを実行するスキル"

    def get_actions(self) -> list[dict]:
        return [
            {
                "name": "execute_python",
                "description": "Pythonコードを実行",
                "parameters": {
                    "code": {"type": "string", "description": "実行するPythonコード", "required": True},
                    "timeout": {"type": "integer", "description": "タイムアウト（秒）", "default": 30},
                },
            },
            {
                "name": "execute_shell",
                "description": "シェルコマンドを実行",
                "parameters": {
                    "command": {"type": "string", "description": "実行するコマンド", "required": True},
                    "timeout": {"type": "integer", "description": "タイムアウト（秒）", "default": 30},
                    "shell": {"type": "boolean", "description": "シェル経由で実行するか", "default": True},
                },
            },
            {
                "name": "execute_script",
                "description": "スクリプトファイルを実行",
                "parameters": {
                    "path": {"type": "string", "description": "スクリプトファイルのパス", "required": True},
                    "args": {"type": "array", "description": "引数リスト", "default": []},
                    "timeout": {"type": "integer", "description": "タイムアウト（秒）", "default": 30},
                },
            },
        ]

    async def execute(self, action: str, params: dict) -> SkillResult:
        """アクションを実行"""
        actions = {
            "execute_python": self._execute_python,
            "execute_shell": self._execute_shell,
            "execute_script": self._execute_script,
        }

        handler = actions.get(action)
        if handler is None:
            return SkillResult.error(
                error=f"Unknown action: {action}",
                message=f"不明なアクション: {action}",
            )

        return await handler(params)

    async def _execute_python(self, params: dict) -> SkillResult:
        """Pythonコードを実行"""
        code = params.get("code")
        if not code:
            return SkillResult.error("code is required", "コードが必要です")

        timeout = min(params.get("timeout", self._timeout), 120)  # 最大120秒

        # 一時ファイルにコードを書き込んで実行
        try:
            with tempfile.NamedTemporaryFile(
                mode="w",
                suffix=".py",
                delete=False,
                encoding="utf-8",
            ) as f:
                f.write(code)
                temp_path = f.name

            try:
                result = await self._run_subprocess(
                    ["python", temp_path],
                    timeout=timeout,
                )
                return result
            finally:
                os.unlink(temp_path)

        except Exception as e:
            return SkillResult.error(str(e), "Python実行エラー")

    async def _execute_shell(self, params: dict) -> SkillResult:
        """シェルコマンドを実行"""
        command = params.get("command")
        if not command:
            return SkillResult.error("command is required", "コマンドが必要です")

        timeout = min(params.get("timeout", self._timeout), 120)
        use_shell = params.get("shell", True)

        # コマンド制限チェック
        if self._allowed_commands is not None:
            # 最初の単語（コマンド名）を抽出
            cmd_name = command.split()[0] if command.split() else ""
            if cmd_name not in self._allowed_commands:
                return SkillResult.error(
                    f"Command not allowed: {cmd_name}",
                    f"許可されていないコマンドです: {cmd_name}",
                )

        try:
            if use_shell:
                result = await self._run_subprocess(
                    command,
                    timeout=timeout,
                    shell=True,
                )
            else:
                result = await self._run_subprocess(
                    command.split(),
                    timeout=timeout,
                    shell=False,
                )
            return result
        except Exception as e:
            return SkillResult.error(str(e), "シェル実行エラー")

    async def _execute_script(self, params: dict) -> SkillResult:
        """スクリプトファイルを実行"""
        path = params.get("path")
        if not path:
            return SkillResult.error("path is required", "パスが必要です")

        args = params.get("args", [])
        timeout = min(params.get("timeout", self._timeout), 120)

        script_path = Path(path)
        if not script_path.exists():
            return SkillResult.error(f"Script not found: {path}", "スクリプトが見つかりません")

        # 拡張子から実行方法を決定
        suffix = script_path.suffix.lower()
        if suffix == ".py":
            cmd = ["python", str(script_path)] + list(args)
        elif suffix == ".sh":
            cmd = ["bash", str(script_path)] + list(args)
        elif suffix == ".js":
            cmd = ["node", str(script_path)] + list(args)
        else:
            # 実行可能ファイルとして直接実行
            cmd = [str(script_path)] + list(args)

        try:
            result = await self._run_subprocess(cmd, timeout=timeout)
            return result
        except Exception as e:
            return SkillResult.error(str(e), "スクリプト実行エラー")

    async def _run_subprocess(
        self,
        cmd: list | str,
        timeout: int,
        shell: bool = False,
    ) -> SkillResult:
        """サブプロセスを実行"""
        try:
            cwd = str(self._working_dir) if self._working_dir else None

            # asyncio.create_subprocess_exec/shell を使用
            if shell:
                process = await asyncio.create_subprocess_shell(
                    cmd if isinstance(cmd, str) else " ".join(cmd),
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=cwd,
                )
            else:
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=cwd,
                )

            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=timeout,
                )
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
                return SkillResult.error(
                    f"Timeout after {timeout} seconds",
                    "タイムアウトしました",
                )

            # 出力サイズ制限
            stdout_str = stdout.decode("utf-8", errors="replace")
            stderr_str = stderr.decode("utf-8", errors="replace")

            if len(stdout_str) > self._max_output_size:
                stdout_str = stdout_str[: self._max_output_size] + "\n... (truncated)"
            if len(stderr_str) > self._max_output_size:
                stderr_str = stderr_str[: self._max_output_size] + "\n... (truncated)"

            return_code = process.returncode

            if return_code == 0:
                return SkillResult.success(
                    data={
                        "stdout": stdout_str,
                        "stderr": stderr_str,
                        "return_code": return_code,
                    },
                    message="実行完了",
                )
            else:
                return SkillResult.error(
                    error=stderr_str or f"Exit code: {return_code}",
                    message=f"実行失敗 (exit code: {return_code})",
                )

        except FileNotFoundError as e:
            return SkillResult.error(str(e), "コマンドが見つかりません")
        except Exception as e:
            return SkillResult.error(str(e), "実行エラー")
