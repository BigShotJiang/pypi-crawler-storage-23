"""Python言語アナライザー

tree-sitterを使用してPythonコードを解析する。
"""

from pathlib import Path
from typing import Optional

from app.skills.code_analysis.base import (
    AnalysisResult,
    BaseLanguageAnalyzer,
    ClassInfo,
    FieldInfo,
    FunctionInfo,
    ImportInfo,
    MethodInfo,
    ParameterInfo,
)

# tree-sitterはオプショナル依存
try:
    import tree_sitter_python as tspython
    from tree_sitter import Language, Parser, Node

    TREE_SITTER_AVAILABLE = True
except ImportError:
    TREE_SITTER_AVAILABLE = False
    Node = None  # type: ignore


class PythonAnalyzer(BaseLanguageAnalyzer):
    """Pythonコードアナライザー"""

    def __init__(self):
        if not TREE_SITTER_AVAILABLE:
            raise ImportError(
                "tree-sitter-python is required. "
                "Install with: pip install tree-sitter tree-sitter-python"
            )
        self._parser = Parser(Language(tspython.language()))

    @property
    def language(self) -> str:
        return "python"

    @property
    def file_extensions(self) -> list[str]:
        return [".py", ".pyi"]

    def analyze_file(self, file_path: Path) -> AnalysisResult:
        """ファイルを解析"""
        result = AnalysisResult(
            file_path=str(file_path),
            language=self.language,
        )

        try:
            source = file_path.read_text(encoding="utf-8")
            return self.analyze_source(source, str(file_path))
        except Exception as e:
            result.errors.append(f"Failed to read file: {e}")
            return result

    def analyze_source(self, source: str, file_path: str = "<string>") -> AnalysisResult:
        """ソースコードを解析"""
        result = AnalysisResult(
            file_path=file_path,
            language=self.language,
        )

        try:
            tree = self._parser.parse(bytes(source, "utf-8"))
            self._analyze_node(tree.root_node, source, result)
        except Exception as e:
            result.errors.append(f"Parse error: {e}")

        return result

    def _analyze_node(
        self, node: "Node", source: str, result: AnalysisResult
    ) -> None:
        """ノードを解析"""
        for child in node.children:
            if child.type == "import_statement":
                self._parse_import(child, source, result)
            elif child.type == "import_from_statement":
                self._parse_import_from(child, source, result)
            elif child.type == "class_definition":
                class_info = self._parse_class(child, source)
                if class_info:
                    result.classes.append(class_info)
            elif child.type == "function_definition":
                func_info = self._parse_function(child, source)
                if func_info:
                    result.functions.append(func_info)
            elif child.type == "decorated_definition":
                self._parse_decorated(child, source, result)

    def _get_text(self, node: "Node", source: str) -> str:
        """ノードのテキストを取得"""
        return source[node.start_byte:node.end_byte]

    def _parse_import(
        self, node: "Node", source: str, result: AnalysisResult
    ) -> None:
        """import文を解析"""
        for child in node.children:
            if child.type == "dotted_name":
                module = self._get_text(child, source)
                result.imports.append(ImportInfo(
                    module=module,
                    line=node.start_point[0] + 1,
                ))
            elif child.type == "aliased_import":
                name_node = child.child_by_field_name("name")
                alias_node = child.child_by_field_name("alias")
                if name_node:
                    module = self._get_text(name_node, source)
                    alias = self._get_text(alias_node, source) if alias_node else None
                    result.imports.append(ImportInfo(
                        module=module,
                        alias=alias,
                        line=node.start_point[0] + 1,
                    ))

    def _parse_import_from(
        self, node: "Node", source: str, result: AnalysisResult
    ) -> None:
        """from ... import文を解析"""
        module = ""
        names: list[str] = []
        is_relative = False

        for child in node.children:
            if child.type == "dotted_name":
                module = self._get_text(child, source)
            elif child.type == "relative_import":
                is_relative = True
                for sub in child.children:
                    if sub.type == "dotted_name":
                        module = self._get_text(sub, source)
            elif child.type in ("import_prefix",):
                is_relative = True
            elif child.type == "wildcard_import":
                names.append("*")
            elif child.type in ("dotted_name", "identifier") and child.parent and child.parent.type not in ("import_from_statement",):
                names.append(self._get_text(child, source))

        # 名前を取得
        for child in node.children:
            if child.type == "identifier":
                names.append(self._get_text(child, source))
            elif child.type == "aliased_import":
                name_node = child.child_by_field_name("name")
                if name_node:
                    names.append(self._get_text(name_node, source))

        if module or names:
            result.imports.append(ImportInfo(
                module=module,
                names=names,
                line=node.start_point[0] + 1,
                is_relative=is_relative,
            ))

    def _parse_decorated(
        self, node: "Node", source: str, result: AnalysisResult
    ) -> None:
        """デコレーター付き定義を解析"""
        decorators: list[str] = []

        for child in node.children:
            if child.type == "decorator":
                dec_text = self._get_text(child, source)
                # @を除去
                if dec_text.startswith("@"):
                    dec_text = dec_text[1:]
                decorators.append(dec_text)
            elif child.type == "class_definition":
                class_info = self._parse_class(child, source)
                if class_info:
                    class_info.decorators = decorators
                    result.classes.append(class_info)
            elif child.type == "function_definition":
                func_info = self._parse_function(child, source)
                if func_info:
                    func_info.decorators = decorators
                    result.functions.append(func_info)

    def _parse_class(self, node: "Node", source: str) -> Optional[ClassInfo]:
        """クラス定義を解析"""
        name = ""
        bases: list[str] = []
        methods: list[MethodInfo] = []
        fields: list[FieldInfo] = []
        docstring: Optional[str] = None
        nested_classes: list[ClassInfo] = []

        for child in node.children:
            if child.type == "identifier":
                name = self._get_text(child, source)
            elif child.type == "argument_list":
                # 継承元を取得
                for arg in child.children:
                    if arg.type in ("identifier", "attribute"):
                        bases.append(self._get_text(arg, source))
            elif child.type == "block":
                # クラス本体を解析
                first_stmt = True
                for stmt in child.children:
                    if stmt.type == "expression_statement" and first_stmt:
                        # ドキュメント文字列をチェック
                        for sub in stmt.children:
                            if sub.type == "string":
                                docstring = self._get_text(sub, source)
                                break
                        first_stmt = False
                    elif stmt.type == "function_definition":
                        method = self._parse_method(stmt, source)
                        if method:
                            methods.append(method)
                        first_stmt = False
                    elif stmt.type == "decorated_definition":
                        method = self._parse_decorated_method(stmt, source)
                        if method:
                            methods.append(method)
                        first_stmt = False
                    elif stmt.type == "class_definition":
                        nested = self._parse_class(stmt, source)
                        if nested:
                            nested_classes.append(nested)
                        first_stmt = False
                    elif stmt.type == "expression_statement":
                        # クラス変数を解析
                        field = self._parse_class_field(stmt, source)
                        if field:
                            fields.append(field)
                        first_stmt = False

        if not name:
            return None

        is_abstract = any("ABC" in b or "Abstract" in b for b in bases)

        return ClassInfo(
            name=name,
            line_start=node.start_point[0] + 1,
            line_end=node.end_point[0] + 1,
            bases=bases,
            methods=methods,
            fields=fields,
            docstring=docstring,
            is_abstract=is_abstract,
            nested_classes=nested_classes,
        )

    def _parse_function(self, node: "Node", source: str) -> Optional[FunctionInfo]:
        """関数定義を解析"""
        name = ""
        parameters: list[ParameterInfo] = []
        return_type: Optional[str] = None
        is_async = False

        # async関数かチェック
        if node.parent and node.parent.type == "decorated_definition":
            for sib in node.parent.children:
                if self._get_text(sib, source) == "async":
                    is_async = True
                    break

        for child in node.children:
            if child.type == "identifier":
                name = self._get_text(child, source)
            elif child.type == "parameters":
                parameters = self._parse_parameters(child, source)
            elif child.type == "type":
                return_type = self._get_text(child, source)

        if not name:
            return None

        # ドキュメント文字列を取得
        docstring = self._get_docstring(node, source)

        return FunctionInfo(
            name=name,
            line_start=node.start_point[0] + 1,
            line_end=node.end_point[0] + 1,
            parameters=parameters,
            return_type=return_type,
            is_async=is_async,
            docstring=docstring,
        )

    def _parse_method(self, node: "Node", source: str) -> Optional[MethodInfo]:
        """メソッド定義を解析"""
        func = self._parse_function(node, source)
        if not func:
            return None

        # selfを除外
        params = func.parameters
        if params and params[0].name in ("self", "cls"):
            params = params[1:]

        visibility = "public"
        if func.name.startswith("__") and not func.name.endswith("__"):
            visibility = "private"
        elif func.name.startswith("_"):
            visibility = "protected"

        return MethodInfo(
            name=func.name,
            line_start=func.line_start,
            line_end=func.line_end,
            parameters=params,
            return_type=func.return_type,
            decorators=func.decorators,
            docstring=func.docstring,
            is_async=func.is_async,
            visibility=visibility,
        )

    def _parse_decorated_method(
        self, node: "Node", source: str
    ) -> Optional[MethodInfo]:
        """デコレーター付きメソッドを解析"""
        decorators: list[str] = []
        method: Optional[MethodInfo] = None

        for child in node.children:
            if child.type == "decorator":
                dec_text = self._get_text(child, source)
                if dec_text.startswith("@"):
                    dec_text = dec_text[1:]
                decorators.append(dec_text)
            elif child.type == "function_definition":
                method = self._parse_method(child, source)

        if method:
            method.decorators = decorators
            method.is_static = "staticmethod" in decorators
            method.is_class_method = "classmethod" in decorators
            method.is_abstract = any("abstract" in d.lower() for d in decorators)

        return method

    def _parse_parameters(
        self, node: "Node", source: str
    ) -> list[ParameterInfo]:
        """パラメータを解析"""
        params: list[ParameterInfo] = []

        for child in node.children:
            if child.type in ("identifier", "typed_parameter", "default_parameter",
                              "typed_default_parameter"):
                param = self._parse_parameter(child, source)
                if param:
                    params.append(param)
            elif child.type == "list_splat_pattern":
                # *args
                for sub in child.children:
                    if sub.type == "identifier":
                        params.append(ParameterInfo(
                            name="*" + self._get_text(sub, source)
                        ))
            elif child.type == "dictionary_splat_pattern":
                # **kwargs
                for sub in child.children:
                    if sub.type == "identifier":
                        params.append(ParameterInfo(
                            name="**" + self._get_text(sub, source)
                        ))

        return params

    def _parse_parameter(self, node: "Node", source: str) -> Optional[ParameterInfo]:
        """単一パラメータを解析"""
        if node.type == "identifier":
            return ParameterInfo(name=self._get_text(node, source))

        name = ""
        type_hint: Optional[str] = None
        default_value: Optional[str] = None

        for child in node.children:
            if child.type == "identifier":
                if not name:
                    name = self._get_text(child, source)
            elif child.type == "type":
                type_hint = self._get_text(child, source)
            elif child.type in ("integer", "float", "string", "true", "false",
                               "none", "identifier", "list", "dictionary"):
                default_value = self._get_text(child, source)

        if name:
            return ParameterInfo(
                name=name,
                type_hint=type_hint,
                default_value=default_value,
            )
        return None

    def _parse_class_field(
        self, node: "Node", source: str
    ) -> Optional[FieldInfo]:
        """クラスフィールドを解析"""
        for child in node.children:
            if child.type == "assignment":
                # 単純な代入
                for sub in child.children:
                    if sub.type == "identifier":
                        name = self._get_text(sub, source)
                        visibility = "public"
                        if name.startswith("__"):
                            visibility = "private"
                        elif name.startswith("_"):
                            visibility = "protected"
                        return FieldInfo(
                            name=name,
                            line=node.start_point[0] + 1,
                            visibility=visibility,
                        )
        return None

    def _get_docstring(self, node: "Node", source: str) -> Optional[str]:
        """ドキュメント文字列を取得"""
        for child in node.children:
            if child.type == "block":
                for stmt in child.children:
                    if stmt.type == "expression_statement":
                        for sub in stmt.children:
                            if sub.type == "string":
                                return self._get_text(sub, source)
                        break
                break
        return None
