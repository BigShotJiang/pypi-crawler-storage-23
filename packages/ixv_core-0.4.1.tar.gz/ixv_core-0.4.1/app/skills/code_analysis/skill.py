"""コード分析スキル

tree-sitterベースの汎用言語分析機能を提供する。
"""

from pathlib import Path
from typing import Optional

from app.skills.base import BaseSkill, SkillResult
from app.skills.code_analysis.base import (
    AnalysisResult,
    BaseLanguageAnalyzer,
    ProjectAnalysisResult,
)


class CodeAnalysisSkill(BaseSkill):
    """コード分析スキル

    複数言語に対応したコード解析機能を提供する。
    """

    def __init__(self):
        self._analyzers: dict[str, BaseLanguageAnalyzer] = {}
        self._extension_map: dict[str, str] = {}
        self._init_analyzers()

    def _init_analyzers(self) -> None:
        """利用可能なアナライザーを初期化"""
        # Pythonアナライザー
        try:
            from app.skills.code_analysis.python_analyzer import PythonAnalyzer
            analyzer = PythonAnalyzer()
            self._analyzers["python"] = analyzer
            for ext in analyzer.file_extensions:
                self._extension_map[ext] = "python"
        except ImportError:
            pass

        # Javaアナライザー
        try:
            from app.skills.code_analysis.java_analyzer import JavaAnalyzer
            analyzer = JavaAnalyzer()
            self._analyzers["java"] = analyzer
            for ext in analyzer.file_extensions:
                self._extension_map[ext] = "java"
        except ImportError:
            pass

    @property
    def name(self) -> str:
        return "code_analysis"

    @property
    def description(self) -> str:
        languages = ", ".join(self._analyzers.keys()) or "none"
        return f"コード分析スキル（対応言語: {languages}）"

    def get_actions(self) -> list[dict]:
        return [
            {
                "name": "analyze_file",
                "description": "ファイルを解析",
                "parameters": {
                    "path": {
                        "type": "string",
                        "description": "ファイルパス",
                        "required": True
                    },
                    "language": {
                        "type": "string",
                        "description": "言語（省略時は拡張子から推定）",
                        "default": None
                    },
                },
            },
            {
                "name": "analyze_source",
                "description": "ソースコードを直接解析",
                "parameters": {
                    "source": {
                        "type": "string",
                        "description": "ソースコード",
                        "required": True
                    },
                    "language": {
                        "type": "string",
                        "description": "言語",
                        "required": True
                    },
                },
            },
            {
                "name": "analyze_project",
                "description": "プロジェクトを解析",
                "parameters": {
                    "path": {
                        "type": "string",
                        "description": "プロジェクトのルートパス",
                        "required": True
                    },
                    "language": {
                        "type": "string",
                        "description": "言語（省略時は全対応言語）",
                        "default": None
                    },
                    "pattern": {
                        "type": "string",
                        "description": "ファイルパターン",
                        "default": None
                    },
                    "max_files": {
                        "type": "integer",
                        "description": "最大ファイル数",
                        "default": 100
                    },
                },
            },
            {
                "name": "get_class_hierarchy",
                "description": "プロジェクトのクラス階層を取得",
                "parameters": {
                    "path": {
                        "type": "string",
                        "description": "プロジェクトのルートパス",
                        "required": True
                    },
                    "language": {
                        "type": "string",
                        "description": "言語",
                        "default": None
                    },
                },
            },
            {
                "name": "get_dependencies",
                "description": "プロジェクトの依存関係を取得",
                "parameters": {
                    "path": {
                        "type": "string",
                        "description": "プロジェクトのルートパス",
                        "required": True
                    },
                    "language": {
                        "type": "string",
                        "description": "言語",
                        "default": None
                    },
                },
            },
            {
                "name": "list_languages",
                "description": "対応言語一覧を取得",
                "parameters": {},
            },
            {
                "name": "find_class",
                "description": "クラスを検索",
                "parameters": {
                    "path": {
                        "type": "string",
                        "description": "プロジェクトのルートパス",
                        "required": True
                    },
                    "class_name": {
                        "type": "string",
                        "description": "クラス名（部分一致）",
                        "required": True
                    },
                },
            },
            {
                "name": "find_function",
                "description": "関数/メソッドを検索",
                "parameters": {
                    "path": {
                        "type": "string",
                        "description": "プロジェクトのルートパス",
                        "required": True
                    },
                    "function_name": {
                        "type": "string",
                        "description": "関数名（部分一致）",
                        "required": True
                    },
                },
            },
        ]

    async def execute(self, action: str, params: dict) -> SkillResult:
        """アクションを実行"""
        if not self._analyzers:
            return SkillResult.error(
                "No analyzers available. Install tree-sitter packages.",
                "アナライザーが利用できません",
            )

        actions = {
            "analyze_file": self._analyze_file,
            "analyze_source": self._analyze_source,
            "analyze_project": self._analyze_project,
            "get_class_hierarchy": self._get_class_hierarchy,
            "get_dependencies": self._get_dependencies,
            "list_languages": self._list_languages,
            "find_class": self._find_class,
            "find_function": self._find_function,
        }

        handler = actions.get(action)
        if handler is None:
            return SkillResult.error(
                error=f"Unknown action: {action}",
                message=f"不明なアクション: {action}",
            )

        return await handler(params)

    def _get_analyzer(
        self, file_path: Optional[Path] = None, language: Optional[str] = None
    ) -> Optional[BaseLanguageAnalyzer]:
        """適切なアナライザーを取得"""
        if language:
            return self._analyzers.get(language)

        if file_path:
            ext = file_path.suffix.lower()
            lang = self._extension_map.get(ext)
            if lang:
                return self._analyzers.get(lang)

        return None

    async def _analyze_file(self, params: dict) -> SkillResult:
        """ファイルを解析"""
        path = params.get("path")
        if not path:
            return SkillResult.error("path is required", "パスが必要です")

        language = params.get("language")
        file_path = Path(path)

        if not file_path.exists():
            return SkillResult.error(
                f"File not found: {path}",
                "ファイルが見つかりません"
            )

        analyzer = self._get_analyzer(file_path, language)
        if not analyzer:
            return SkillResult.error(
                f"No analyzer for: {file_path.suffix}",
                "対応するアナライザーがありません"
            )

        result = analyzer.analyze_file(file_path)

        return SkillResult.success(
            data=result.to_dict(),
            message=f"解析完了: {len(result.classes)}クラス, "
                    f"{len(result.functions)}関数",
        )

    async def _analyze_source(self, params: dict) -> SkillResult:
        """ソースコードを解析"""
        source = params.get("source")
        language = params.get("language")

        if not source:
            return SkillResult.error("source is required", "ソースが必要です")
        if not language:
            return SkillResult.error("language is required", "言語が必要です")

        analyzer = self._analyzers.get(language)
        if not analyzer:
            return SkillResult.error(
                f"No analyzer for: {language}",
                "対応するアナライザーがありません"
            )

        result = analyzer.analyze_source(source)

        return SkillResult.success(
            data=result.to_dict(),
            message=f"解析完了: {len(result.classes)}クラス, "
                    f"{len(result.functions)}関数",
        )

    async def _analyze_project(self, params: dict) -> SkillResult:
        """プロジェクトを解析"""
        path = params.get("path")
        if not path:
            return SkillResult.error("path is required", "パスが必要です")

        language = params.get("language")
        pattern = params.get("pattern")
        max_files = params.get("max_files", 100)

        root_path = Path(path)
        if not root_path.exists():
            return SkillResult.error(
                f"Path not found: {path}",
                "パスが見つかりません"
            )

        # 解析対象ファイルを収集
        files: list[Path] = []

        if pattern:
            files = list(root_path.glob(pattern))[:max_files]
        else:
            # 対応する全拡張子のファイルを収集
            for ext in self._extension_map:
                if language and self._extension_map[ext] != language:
                    continue
                files.extend(root_path.rglob(f"*{ext}"))
                if len(files) >= max_files:
                    break
            files = files[:max_files]

        # 解析実行
        project_result = ProjectAnalysisResult(root_path=str(root_path))

        for file_path in files:
            analyzer = self._get_analyzer(file_path, language)
            if analyzer:
                try:
                    result = analyzer.analyze_file(file_path)
                    project_result.files.append(result)
                except Exception as e:
                    project_result.errors.append(f"{file_path}: {e}")

        return SkillResult.success(
            data=project_result.get_summary(),
            message=f"解析完了: {len(project_result.files)}ファイル",
        )

    async def _get_class_hierarchy(self, params: dict) -> SkillResult:
        """クラス階層を取得"""
        # まずプロジェクトを解析
        project_result = await self._analyze_project_internal(params)
        if project_result is None:
            return SkillResult.error("Analysis failed", "解析に失敗しました")

        hierarchy = project_result.get_class_hierarchy()

        return SkillResult.success(
            data=hierarchy,
            message=f"{len(hierarchy['class_files'])}クラスの階層を取得",
        )

    async def _get_dependencies(self, params: dict) -> SkillResult:
        """依存関係を取得"""
        project_result = await self._analyze_project_internal(params)
        if project_result is None:
            return SkillResult.error("Analysis failed", "解析に失敗しました")

        deps = project_result.get_dependencies()

        return SkillResult.success(
            data=deps,
            message=f"{len(deps['module_usage'])}モジュールの依存関係を取得",
        )

    async def _analyze_project_internal(
        self, params: dict
    ) -> Optional[ProjectAnalysisResult]:
        """プロジェクトを内部的に解析"""
        path = params.get("path")
        if not path:
            return None

        language = params.get("language")
        root_path = Path(path)

        if not root_path.exists():
            return None

        files: list[Path] = []
        for ext in self._extension_map:
            if language and self._extension_map[ext] != language:
                continue
            files.extend(root_path.rglob(f"*{ext}"))

        project_result = ProjectAnalysisResult(root_path=str(root_path))

        for file_path in files[:200]:  # 最大200ファイル
            analyzer = self._get_analyzer(file_path, language)
            if analyzer:
                try:
                    result = analyzer.analyze_file(file_path)
                    project_result.files.append(result)
                except Exception:
                    pass

        return project_result

    async def _list_languages(self, params: dict) -> SkillResult:
        """対応言語一覧"""
        languages = []
        for lang, analyzer in self._analyzers.items():
            languages.append({
                "name": lang,
                "extensions": analyzer.file_extensions,
            })

        return SkillResult.success(
            data={"languages": languages},
            message=f"{len(languages)}言語に対応",
        )

    async def _find_class(self, params: dict) -> SkillResult:
        """クラスを検索"""
        path = params.get("path")
        class_name = params.get("class_name")

        if not path or not class_name:
            return SkillResult.error(
                "path and class_name are required",
                "パスとクラス名が必要です"
            )

        project_result = await self._analyze_project_internal(params)
        if project_result is None:
            return SkillResult.error("Analysis failed", "解析に失敗しました")

        matches = []
        class_name_lower = class_name.lower()

        for f in project_result.files:
            for c in f.classes:
                if class_name_lower in c.name.lower():
                    matches.append({
                        "name": c.name,
                        "file": f.file_path,
                        "line": c.line_start,
                        "bases": c.bases,
                        "methods": [m.name for m in c.methods],
                    })

        return SkillResult.success(
            data={"matches": matches, "count": len(matches)},
            message=f"{len(matches)}件のクラスが見つかりました",
        )

    async def _find_function(self, params: dict) -> SkillResult:
        """関数/メソッドを検索"""
        path = params.get("path")
        function_name = params.get("function_name")

        if not path or not function_name:
            return SkillResult.error(
                "path and function_name are required",
                "パスと関数名が必要です"
            )

        project_result = await self._analyze_project_internal(params)
        if project_result is None:
            return SkillResult.error("Analysis failed", "解析に失敗しました")

        matches = []
        func_name_lower = function_name.lower()

        for f in project_result.files:
            # トップレベル関数
            for fn in f.functions:
                if func_name_lower in fn.name.lower():
                    matches.append({
                        "name": fn.name,
                        "file": f.file_path,
                        "line": fn.line_start,
                        "type": "function",
                        "parameters": [p.name for p in fn.parameters],
                    })

            # クラスメソッド
            for c in f.classes:
                for m in c.methods:
                    if func_name_lower in m.name.lower():
                        matches.append({
                            "name": m.name,
                            "class": c.name,
                            "file": f.file_path,
                            "line": m.line_start,
                            "type": "method",
                            "parameters": [p.name for p in m.parameters],
                        })

        return SkillResult.success(
            data={"matches": matches, "count": len(matches)},
            message=f"{len(matches)}件の関数が見つかりました",
        )
