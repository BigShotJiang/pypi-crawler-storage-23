"""Java言語アナライザー

tree-sitterを使用してJavaコードを解析する。
"""

from pathlib import Path
from typing import Optional

from app.skills.code_analysis.base import (
    AnalysisResult,
    BaseLanguageAnalyzer,
    ClassInfo,
    FieldInfo,
    ImportInfo,
    MethodInfo,
    ParameterInfo,
)

# tree-sitterはオプショナル依存
try:
    import tree_sitter_java as tsjava
    from tree_sitter import Language, Parser, Node

    TREE_SITTER_AVAILABLE = True
except ImportError:
    TREE_SITTER_AVAILABLE = False
    Node = None  # type: ignore


class JavaAnalyzer(BaseLanguageAnalyzer):
    """Javaコードアナライザー"""

    def __init__(self):
        if not TREE_SITTER_AVAILABLE:
            raise ImportError(
                "tree-sitter-java is required. "
                "Install with: pip install tree-sitter tree-sitter-java"
            )
        self._parser = Parser(Language(tsjava.language()))

    @property
    def language(self) -> str:
        return "java"

    @property
    def file_extensions(self) -> list[str]:
        return [".java"]

    def analyze_file(self, file_path: Path) -> AnalysisResult:
        """ファイルを解析"""
        result = AnalysisResult(
            file_path=str(file_path),
            language=self.language,
        )

        try:
            source = file_path.read_text(encoding="utf-8")
            return self.analyze_source(source, str(file_path))
        except Exception as e:
            result.errors.append(f"Failed to read file: {e}")
            return result

    def analyze_source(self, source: str, file_path: str = "<string>") -> AnalysisResult:
        """ソースコードを解析"""
        result = AnalysisResult(
            file_path=file_path,
            language=self.language,
        )

        try:
            tree = self._parser.parse(bytes(source, "utf-8"))
            self._analyze_node(tree.root_node, source, result)
        except Exception as e:
            result.errors.append(f"Parse error: {e}")

        return result

    def _analyze_node(
        self, node: "Node", source: str, result: AnalysisResult
    ) -> None:
        """ノードを解析"""
        for child in node.children:
            if child.type == "package_declaration":
                result.package = self._parse_package(child, source)
            elif child.type == "import_declaration":
                imp = self._parse_import(child, source)
                if imp:
                    result.imports.append(imp)
            elif child.type == "class_declaration":
                class_info = self._parse_class(child, source)
                if class_info:
                    result.classes.append(class_info)
            elif child.type == "interface_declaration":
                interface_info = self._parse_interface(child, source)
                if interface_info:
                    result.classes.append(interface_info)
            elif child.type == "enum_declaration":
                enum_info = self._parse_enum(child, source)
                if enum_info:
                    result.classes.append(enum_info)

    def _get_text(self, node: "Node", source: str) -> str:
        """ノードのテキストを取得"""
        return source[node.start_byte:node.end_byte]

    def _parse_package(self, node: "Node", source: str) -> Optional[str]:
        """パッケージ宣言を解析"""
        for child in node.children:
            if child.type == "scoped_identifier":
                return self._get_text(child, source)
            elif child.type == "identifier":
                return self._get_text(child, source)
        return None

    def _parse_import(self, node: "Node", source: str) -> Optional[ImportInfo]:
        """インポート宣言を解析"""
        module = ""
        is_static = False

        for child in node.children:
            if child.type == "scoped_identifier":
                module = self._get_text(child, source)
            elif child.type == "identifier":
                module = self._get_text(child, source)
            elif self._get_text(child, source) == "static":
                is_static = True

        if module:
            # ワイルドカードインポートをチェック
            names = []
            if module.endswith(".*"):
                module = module[:-2]
                names = ["*"]

            return ImportInfo(
                module=module,
                names=names,
                line=node.start_point[0] + 1,
            )
        return None

    def _parse_class(self, node: "Node", source: str) -> Optional[ClassInfo]:
        """クラス定義を解析"""
        name = ""
        bases: list[str] = []
        interfaces: list[str] = []
        methods: list[MethodInfo] = []
        fields: list[FieldInfo] = []
        decorators: list[str] = []  # アノテーション
        nested_classes: list[ClassInfo] = []
        is_abstract = False

        for child in node.children:
            if child.type == "modifiers":
                mods, annots = self._parse_modifiers(child, source)
                decorators = annots
                is_abstract = "abstract" in mods
            elif child.type == "identifier":
                name = self._get_text(child, source)
            elif child.type == "superclass":
                for sub in child.children:
                    if sub.type == "type_identifier":
                        bases.append(self._get_text(sub, source))
                    elif sub.type == "generic_type":
                        bases.append(self._get_text(sub, source))
            elif child.type == "super_interfaces":
                interfaces = self._parse_interfaces(child, source)
            elif child.type == "class_body":
                methods, fields, nested_classes = self._parse_class_body(
                    child, source
                )

        if not name:
            return None

        return ClassInfo(
            name=name,
            line_start=node.start_point[0] + 1,
            line_end=node.end_point[0] + 1,
            bases=bases,
            interfaces=interfaces,
            methods=methods,
            fields=fields,
            decorators=decorators,
            is_abstract=is_abstract,
            nested_classes=nested_classes,
        )

    def _parse_interface(self, node: "Node", source: str) -> Optional[ClassInfo]:
        """インターフェース定義を解析"""
        name = ""
        interfaces: list[str] = []
        methods: list[MethodInfo] = []
        decorators: list[str] = []

        for child in node.children:
            if child.type == "modifiers":
                _, annots = self._parse_modifiers(child, source)
                decorators = annots
            elif child.type == "identifier":
                name = self._get_text(child, source)
            elif child.type == "extends_interfaces":
                interfaces = self._parse_interfaces(child, source)
            elif child.type == "interface_body":
                for body_child in child.children:
                    if body_child.type == "method_declaration":
                        method = self._parse_method(body_child, source)
                        if method:
                            method.is_abstract = True
                            methods.append(method)

        if not name:
            return None

        return ClassInfo(
            name=name,
            line_start=node.start_point[0] + 1,
            line_end=node.end_point[0] + 1,
            interfaces=interfaces,
            methods=methods,
            decorators=decorators,
            is_interface=True,
        )

    def _parse_enum(self, node: "Node", source: str) -> Optional[ClassInfo]:
        """Enum定義を解析"""
        name = ""
        decorators: list[str] = []
        fields: list[FieldInfo] = []

        for child in node.children:
            if child.type == "modifiers":
                _, annots = self._parse_modifiers(child, source)
                decorators = annots
            elif child.type == "identifier":
                name = self._get_text(child, source)
            elif child.type == "enum_body":
                for body_child in child.children:
                    if body_child.type == "enum_constant":
                        for sub in body_child.children:
                            if sub.type == "identifier":
                                fields.append(FieldInfo(
                                    name=self._get_text(sub, source),
                                    visibility="public",
                                    is_static=True,
                                    line=body_child.start_point[0] + 1,
                                ))

        if not name:
            return None

        return ClassInfo(
            name=name,
            line_start=node.start_point[0] + 1,
            line_end=node.end_point[0] + 1,
            fields=fields,
            decorators=decorators + ["@Enum"],
        )

    def _parse_interfaces(self, node: "Node", source: str) -> list[str]:
        """実装インターフェースを解析"""
        interfaces: list[str] = []
        for child in node.children:
            if child.type == "type_list":
                for type_child in child.children:
                    if type_child.type in ("type_identifier", "generic_type"):
                        interfaces.append(self._get_text(type_child, source))
            elif child.type in ("type_identifier", "generic_type"):
                interfaces.append(self._get_text(child, source))
        return interfaces

    def _parse_class_body(
        self, node: "Node", source: str
    ) -> tuple[list[MethodInfo], list[FieldInfo], list[ClassInfo]]:
        """クラスボディを解析"""
        methods: list[MethodInfo] = []
        fields: list[FieldInfo] = []
        nested_classes: list[ClassInfo] = []

        for child in node.children:
            if child.type == "method_declaration":
                method = self._parse_method(child, source)
                if method:
                    methods.append(method)
            elif child.type == "constructor_declaration":
                method = self._parse_constructor(child, source)
                if method:
                    methods.append(method)
            elif child.type == "field_declaration":
                new_fields = self._parse_fields(child, source)
                fields.extend(new_fields)
            elif child.type == "class_declaration":
                nested = self._parse_class(child, source)
                if nested:
                    nested_classes.append(nested)
            elif child.type == "interface_declaration":
                nested = self._parse_interface(child, source)
                if nested:
                    nested_classes.append(nested)

        return methods, fields, nested_classes

    def _parse_modifiers(
        self, node: "Node", source: str
    ) -> tuple[list[str], list[str]]:
        """修飾子とアノテーションを解析"""
        modifiers: list[str] = []
        annotations: list[str] = []

        for child in node.children:
            if child.type == "marker_annotation":
                annotations.append(self._get_text(child, source))
            elif child.type == "annotation":
                annotations.append(self._get_text(child, source))
            elif child.type in ("public", "private", "protected", "static",
                               "final", "abstract", "synchronized", "native",
                               "transient", "volatile"):
                modifiers.append(self._get_text(child, source))

        return modifiers, annotations

    def _parse_method(self, node: "Node", source: str) -> Optional[MethodInfo]:
        """メソッド定義を解析"""
        name = ""
        parameters: list[ParameterInfo] = []
        return_type: Optional[str] = None
        decorators: list[str] = []
        visibility = "package"  # デフォルトはpackage-private
        is_static = False
        is_abstract = False

        for child in node.children:
            if child.type == "modifiers":
                mods, annots = self._parse_modifiers(child, source)
                decorators = annots
                if "public" in mods:
                    visibility = "public"
                elif "private" in mods:
                    visibility = "private"
                elif "protected" in mods:
                    visibility = "protected"
                is_static = "static" in mods
                is_abstract = "abstract" in mods
            elif child.type == "identifier":
                name = self._get_text(child, source)
            elif child.type in ("type_identifier", "generic_type", "void_type",
                               "integral_type", "floating_point_type",
                               "boolean_type", "array_type"):
                return_type = self._get_text(child, source)
            elif child.type == "formal_parameters":
                parameters = self._parse_parameters(child, source)

        if not name:
            return None

        return MethodInfo(
            name=name,
            line_start=node.start_point[0] + 1,
            line_end=node.end_point[0] + 1,
            parameters=parameters,
            return_type=return_type,
            decorators=decorators,
            visibility=visibility,
            is_static=is_static,
            is_abstract=is_abstract,
        )

    def _parse_constructor(self, node: "Node", source: str) -> Optional[MethodInfo]:
        """コンストラクタを解析"""
        name = ""
        parameters: list[ParameterInfo] = []
        decorators: list[str] = []
        visibility = "package"

        for child in node.children:
            if child.type == "modifiers":
                mods, annots = self._parse_modifiers(child, source)
                decorators = annots
                if "public" in mods:
                    visibility = "public"
                elif "private" in mods:
                    visibility = "private"
                elif "protected" in mods:
                    visibility = "protected"
            elif child.type == "identifier":
                name = self._get_text(child, source)
            elif child.type == "formal_parameters":
                parameters = self._parse_parameters(child, source)

        if not name:
            return None

        return MethodInfo(
            name=name,
            line_start=node.start_point[0] + 1,
            line_end=node.end_point[0] + 1,
            parameters=parameters,
            decorators=decorators + ["@Constructor"],
            visibility=visibility,
        )

    def _parse_parameters(self, node: "Node", source: str) -> list[ParameterInfo]:
        """パラメータを解析"""
        params: list[ParameterInfo] = []

        for child in node.children:
            if child.type == "formal_parameter":
                param = self._parse_parameter(child, source)
                if param:
                    params.append(param)
            elif child.type == "spread_parameter":
                # 可変長引数
                param = self._parse_parameter(child, source)
                if param:
                    param.name = "..." + param.name
                    params.append(param)

        return params

    def _parse_parameter(self, node: "Node", source: str) -> Optional[ParameterInfo]:
        """単一パラメータを解析"""
        name = ""
        type_hint: Optional[str] = None

        for child in node.children:
            if child.type == "identifier":
                name = self._get_text(child, source)
            elif child.type in ("type_identifier", "generic_type",
                               "integral_type", "floating_point_type",
                               "boolean_type", "array_type"):
                type_hint = self._get_text(child, source)

        if name:
            return ParameterInfo(name=name, type_hint=type_hint)
        return None

    def _parse_fields(self, node: "Node", source: str) -> list[FieldInfo]:
        """フィールド定義を解析"""
        fields: list[FieldInfo] = []
        type_hint: Optional[str] = None
        visibility = "package"
        is_static = False

        for child in node.children:
            if child.type == "modifiers":
                mods, _ = self._parse_modifiers(child, source)
                if "public" in mods:
                    visibility = "public"
                elif "private" in mods:
                    visibility = "private"
                elif "protected" in mods:
                    visibility = "protected"
                is_static = "static" in mods
            elif child.type in ("type_identifier", "generic_type",
                               "integral_type", "floating_point_type",
                               "boolean_type", "array_type"):
                type_hint = self._get_text(child, source)
            elif child.type == "variable_declarator":
                for sub in child.children:
                    if sub.type == "identifier":
                        fields.append(FieldInfo(
                            name=self._get_text(sub, source),
                            type_hint=type_hint,
                            visibility=visibility,
                            is_static=is_static,
                            line=node.start_point[0] + 1,
                        ))

        return fields
