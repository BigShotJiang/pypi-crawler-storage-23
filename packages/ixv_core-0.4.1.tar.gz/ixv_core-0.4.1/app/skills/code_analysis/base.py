"""コード分析基盤

言語非依存の解析結果データ構造と基底クラスを定義する。
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class ImportInfo:
    """インポート情報"""
    module: str
    names: list[str] = field(default_factory=list)  # from X import a, b
    alias: Optional[str] = None
    line: int = 0
    is_relative: bool = False  # 相対インポートか


@dataclass
class ParameterInfo:
    """パラメータ情報"""
    name: str
    type_hint: Optional[str] = None
    default_value: Optional[str] = None


@dataclass
class FunctionInfo:
    """関数情報"""
    name: str
    line_start: int
    line_end: int
    parameters: list[ParameterInfo] = field(default_factory=list)
    return_type: Optional[str] = None
    decorators: list[str] = field(default_factory=list)
    docstring: Optional[str] = None
    is_async: bool = False


@dataclass
class MethodInfo(FunctionInfo):
    """メソッド情報"""
    is_static: bool = False
    is_class_method: bool = False
    is_abstract: bool = False
    visibility: str = "public"  # public, private, protected


@dataclass
class FieldInfo:
    """フィールド情報"""
    name: str
    type_hint: Optional[str] = None
    default_value: Optional[str] = None
    visibility: str = "public"
    is_static: bool = False
    line: int = 0


@dataclass
class ClassInfo:
    """クラス情報"""
    name: str
    line_start: int
    line_end: int
    bases: list[str] = field(default_factory=list)  # 継承元
    interfaces: list[str] = field(default_factory=list)  # 実装インターフェース
    methods: list[MethodInfo] = field(default_factory=list)
    fields: list[FieldInfo] = field(default_factory=list)
    decorators: list[str] = field(default_factory=list)  # アノテーション
    docstring: Optional[str] = None
    is_abstract: bool = False
    is_interface: bool = False
    nested_classes: list["ClassInfo"] = field(default_factory=list)


@dataclass
class AnalysisResult:
    """ファイル解析結果"""
    file_path: str
    language: str
    imports: list[ImportInfo] = field(default_factory=list)
    classes: list[ClassInfo] = field(default_factory=list)
    functions: list[FunctionInfo] = field(default_factory=list)
    package: Optional[str] = None  # Java: package, Python: なし
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        """辞書形式に変換"""
        return {
            "file_path": self.file_path,
            "language": self.language,
            "package": self.package,
            "imports": [
                {
                    "module": i.module,
                    "names": i.names,
                    "alias": i.alias,
                    "line": i.line,
                }
                for i in self.imports
            ],
            "classes": [self._class_to_dict(c) for c in self.classes],
            "functions": [self._function_to_dict(f) for f in self.functions],
            "errors": self.errors,
        }

    def _function_to_dict(self, f: FunctionInfo) -> dict:
        return {
            "name": f.name,
            "line_start": f.line_start,
            "line_end": f.line_end,
            "parameters": [
                {"name": p.name, "type": p.type_hint, "default": p.default_value}
                for p in f.parameters
            ],
            "return_type": f.return_type,
            "decorators": f.decorators,
            "is_async": f.is_async,
        }

    def _method_to_dict(self, m: MethodInfo) -> dict:
        base = self._function_to_dict(m)
        base.update({
            "is_static": m.is_static,
            "is_class_method": m.is_class_method,
            "is_abstract": m.is_abstract,
            "visibility": m.visibility,
        })
        return base

    def _class_to_dict(self, c: ClassInfo) -> dict:
        return {
            "name": c.name,
            "line_start": c.line_start,
            "line_end": c.line_end,
            "bases": c.bases,
            "interfaces": c.interfaces,
            "methods": [self._method_to_dict(m) for m in c.methods],
            "fields": [
                {
                    "name": f.name,
                    "type": f.type_hint,
                    "visibility": f.visibility,
                    "is_static": f.is_static,
                }
                for f in c.fields
            ],
            "decorators": c.decorators,
            "is_abstract": c.is_abstract,
            "is_interface": c.is_interface,
            "nested_classes": [self._class_to_dict(nc) for nc in c.nested_classes],
        }

    def get_summary(self) -> dict:
        """サマリー情報を取得"""
        return {
            "file_path": self.file_path,
            "language": self.language,
            "num_imports": len(self.imports),
            "num_classes": len(self.classes),
            "num_functions": len(self.functions),
            "class_names": [c.name for c in self.classes],
            "function_names": [f.name for f in self.functions],
        }


@dataclass
class ProjectAnalysisResult:
    """プロジェクト解析結果"""
    root_path: str
    files: list[AnalysisResult] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def get_summary(self) -> dict:
        """プロジェクトサマリーを取得"""
        all_classes = []
        all_functions = []
        language_stats: dict[str, int] = {}

        for f in self.files:
            all_classes.extend([(c.name, f.file_path) for c in f.classes])
            all_functions.extend([(fn.name, f.file_path) for fn in f.functions])
            language_stats[f.language] = language_stats.get(f.language, 0) + 1

        return {
            "root_path": self.root_path,
            "total_files": len(self.files),
            "language_stats": language_stats,
            "total_classes": len(all_classes),
            "total_functions": len(all_functions),
            "classes": all_classes[:50],  # 最大50件
            "functions": all_functions[:50],
        }

    def get_class_hierarchy(self) -> dict:
        """クラス階層を取得"""
        hierarchy: dict[str, list[str]] = {}
        class_files: dict[str, str] = {}

        for f in self.files:
            for c in f.classes:
                class_files[c.name] = f.file_path
                for base in c.bases:
                    if base not in hierarchy:
                        hierarchy[base] = []
                    hierarchy[base].append(c.name)

        return {
            "hierarchy": hierarchy,
            "class_files": class_files,
        }

    def get_dependencies(self) -> dict:
        """依存関係を取得"""
        # ファイルごとのインポート
        file_imports: dict[str, list[str]] = {}
        # モジュールの使用状況
        module_usage: dict[str, int] = {}

        for f in self.files:
            imports = []
            for imp in f.imports:
                imports.append(imp.module)
                module_usage[imp.module] = module_usage.get(imp.module, 0) + 1
            file_imports[f.file_path] = imports

        # 使用頻度でソート
        sorted_modules = sorted(
            module_usage.items(),
            key=lambda x: x[1],
            reverse=True
        )

        return {
            "file_imports": file_imports,
            "module_usage": dict(sorted_modules[:30]),
        }


class BaseLanguageAnalyzer(ABC):
    """言語アナライザー基底クラス"""

    @property
    @abstractmethod
    def language(self) -> str:
        """言語名"""
        pass

    @property
    @abstractmethod
    def file_extensions(self) -> list[str]:
        """対応するファイル拡張子"""
        pass

    @abstractmethod
    def analyze_file(self, file_path: Path) -> AnalysisResult:
        """ファイルを解析"""
        pass

    def analyze_source(self, source: str, file_path: str = "<string>") -> AnalysisResult:
        """ソースコードを直接解析"""
        raise NotImplementedError("This analyzer does not support source analysis")

    def can_analyze(self, file_path: Path) -> bool:
        """このファイルを解析できるか"""
        return file_path.suffix.lower() in self.file_extensions
