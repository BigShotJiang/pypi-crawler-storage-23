"""スキル基底クラス"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class SkillStatus(str, Enum):
    """スキル実行結果のステータス"""
    SUCCESS = "success"
    ERROR = "error"
    PARTIAL = "partial"  # 部分的に成功


@dataclass
class SkillResult:
    """スキル実行結果"""
    status: SkillStatus
    data: Any = None
    message: str = ""
    error: str | None = None

    def to_dict(self) -> dict:
        """辞書形式に変換"""
        result = {
            "status": self.status.value,
            "message": self.message,
        }
        if self.data is not None:
            result["data"] = self.data
        if self.error:
            result["error"] = self.error
        return result

    @classmethod
    def success(cls, data: Any = None, message: str = "OK") -> "SkillResult":
        """成功結果を生成"""
        return cls(status=SkillStatus.SUCCESS, data=data, message=message, error=None)

    @classmethod
    def error(cls, error: str, message: str = "Error") -> "SkillResult":
        """エラー結果を生成"""
        return cls(status=SkillStatus.ERROR, error=error, message=message)


@dataclass
class SkillInfo:
    """スキル情報"""
    name: str
    description: str
    actions: list[dict] = field(default_factory=list)


class BaseSkill(ABC):
    """スキル基底クラス

    全てのスキルはこのクラスを継承する。
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """スキル名"""
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """スキルの説明"""
        pass

    @abstractmethod
    def get_actions(self) -> list[dict]:
        """利用可能なアクション一覧を返す

        Returns:
            list[dict]: アクション情報のリスト
                各アクションは以下の形式:
                {
                    "name": "action_name",
                    "description": "アクションの説明",
                    "parameters": {
                        "param1": {"type": "string", "description": "..."},
                        ...
                    }
                }
        """
        pass

    @abstractmethod
    async def execute(self, action: str, params: dict) -> SkillResult:
        """アクションを実行

        Args:
            action: アクション名
            params: パラメータ

        Returns:
            SkillResult: 実行結果
        """
        pass

    def get_info(self) -> SkillInfo:
        """スキル情報を取得"""
        return SkillInfo(
            name=self.name,
            description=self.description,
            actions=self.get_actions(),
        )
