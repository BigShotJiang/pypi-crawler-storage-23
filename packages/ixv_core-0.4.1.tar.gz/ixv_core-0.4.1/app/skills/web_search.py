"""Web検索スキル"""

import asyncio
import urllib.parse
import urllib.request
import json
import re
from typing import Optional
from dataclasses import dataclass

from app.skills.base import BaseSkill, SkillResult


@dataclass
class SearchResultItem:
    """検索結果アイテム"""
    title: str
    url: str
    snippet: str


class WebSearchSkill(BaseSkill):
    """Web検索スキル

    DuckDuckGo検索を使用して最新情報を取得する。
    APIキー不要。
    """

    def __init__(
        self,
        timeout: int = 10,
        max_results: int = 10,
        user_agent: Optional[str] = None,
    ):
        """初期化

        Args:
            timeout: リクエストタイムアウト（秒）
            max_results: 最大結果数
            user_agent: カスタムUser-Agent
        """
        self._timeout = timeout
        self._max_results = max_results
        self._user_agent = user_agent or (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        )

    @property
    def name(self) -> str:
        return "web_search"

    @property
    def description(self) -> str:
        return "Web検索で最新情報を取得するスキル"

    def get_actions(self) -> list[dict]:
        return [
            {
                "name": "search",
                "description": "Web検索を実行",
                "parameters": {
                    "query": {
                        "type": "string",
                        "description": "検索クエリ",
                        "required": True
                    },
                    "num_results": {
                        "type": "integer",
                        "description": "取得する結果数",
                        "default": 5
                    },
                    "region": {
                        "type": "string",
                        "description": "地域コード (例: jp-jp, us-en)",
                        "default": "jp-jp"
                    },
                },
            },
            {
                "name": "search_news",
                "description": "ニュース検索を実行",
                "parameters": {
                    "query": {
                        "type": "string",
                        "description": "検索クエリ",
                        "required": True
                    },
                    "num_results": {
                        "type": "integer",
                        "description": "取得する結果数",
                        "default": 5
                    },
                },
            },
            {
                "name": "fetch_url",
                "description": "URLからテキストを取得",
                "parameters": {
                    "url": {
                        "type": "string",
                        "description": "取得するURL",
                        "required": True
                    },
                    "max_length": {
                        "type": "integer",
                        "description": "最大文字数",
                        "default": 5000
                    },
                },
            },
        ]

    async def execute(self, action: str, params: dict) -> SkillResult:
        """アクションを実行"""
        actions = {
            "search": self._search,
            "search_news": self._search_news,
            "fetch_url": self._fetch_url,
        }

        handler = actions.get(action)
        if handler is None:
            return SkillResult.error(
                error=f"Unknown action: {action}",
                message=f"不明なアクション: {action}",
            )

        return await handler(params)

    def _make_request(self, url: str) -> str:
        """HTTPリクエストを実行"""
        req = urllib.request.Request(
            url,
            headers={"User-Agent": self._user_agent}
        )
        with urllib.request.urlopen(req, timeout=self._timeout) as response:
            return response.read().decode("utf-8", errors="replace")

    async def _search_duckduckgo(
        self,
        query: str,
        num_results: int = 5,
        region: str = "jp-jp",
    ) -> list[SearchResultItem]:
        """DuckDuckGo HTML検索"""
        # DuckDuckGo HTML版を使用（APIキー不要）
        encoded_query = urllib.parse.quote(query)
        url = f"https://html.duckduckgo.com/html/?q={encoded_query}&kl={region}"

        try:
            html = await asyncio.get_event_loop().run_in_executor(
                None, self._make_request, url
            )
        except Exception as e:
            raise Exception(f"検索リクエスト失敗: {e}")

        results = []

        # HTML解析（正規表現でシンプルに）
        # 結果ブロックを抽出
        result_pattern = re.compile(
            r'<a[^>]*class="result__a"[^>]*href="([^"]*)"[^>]*>([^<]*)</a>.*?'
            r'<a[^>]*class="result__snippet"[^>]*>([^<]*(?:<[^>]*>[^<]*)*)</a>',
            re.DOTALL | re.IGNORECASE
        )

        # より単純なパターンも試す
        simple_pattern = re.compile(
            r'<a[^>]*rel="nofollow"[^>]*href="([^"]*)"[^>]*>([^<]*)</a>',
            re.IGNORECASE
        )

        # 結果URLとタイトルを抽出
        for match in result_pattern.finditer(html):
            if len(results) >= num_results:
                break
            url = match.group(1)
            title = self._clean_html(match.group(2))
            snippet = self._clean_html(match.group(3))

            # DuckDuckGoのリダイレクトURLを処理
            if "uddg=" in url:
                parsed = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
                if "uddg" in parsed:
                    url = parsed["uddg"][0]

            if url.startswith("http"):
                results.append(SearchResultItem(
                    title=title,
                    url=url,
                    snippet=snippet,
                ))

        # 結果が少ない場合は別パターンで試す
        if len(results) < num_results:
            # 結果リンクパターン
            link_pattern = re.compile(
                r'<a[^>]*class="[^"]*result[^"]*"[^>]*href="([^"]*)"[^>]*>'
                r'(?:<[^>]*>)*([^<]+)',
                re.IGNORECASE
            )
            for match in link_pattern.finditer(html):
                if len(results) >= num_results:
                    break
                url = match.group(1)
                title = self._clean_html(match.group(2))

                if "uddg=" in url:
                    parsed = urllib.parse.parse_qs(
                        urllib.parse.urlparse(url).query
                    )
                    if "uddg" in parsed:
                        url = parsed["uddg"][0]

                if url.startswith("http") and title.strip():
                    # 重複チェック
                    if not any(r.url == url for r in results):
                        results.append(SearchResultItem(
                            title=title.strip(),
                            url=url,
                            snippet="",
                        ))

        return results

    def _clean_html(self, text: str) -> str:
        """HTMLタグを除去"""
        # HTMLタグを除去
        clean = re.sub(r'<[^>]+>', '', text)
        # HTMLエンティティをデコード
        clean = clean.replace("&amp;", "&")
        clean = clean.replace("&lt;", "<")
        clean = clean.replace("&gt;", ">")
        clean = clean.replace("&quot;", '"')
        clean = clean.replace("&#39;", "'")
        clean = clean.replace("&nbsp;", " ")
        # 余分な空白を除去
        clean = re.sub(r'\s+', ' ', clean).strip()
        return clean

    async def _search(self, params: dict) -> SkillResult:
        """Web検索"""
        query = params.get("query")
        if not query:
            return SkillResult.error("query is required", "クエリが必要です")

        num_results = min(
            params.get("num_results", 5),
            self._max_results
        )
        region = params.get("region", "jp-jp")

        try:
            results = await self._search_duckduckgo(
                query=query,
                num_results=num_results,
                region=region,
            )

            return SkillResult.success(
                data={
                    "query": query,
                    "results": [
                        {
                            "title": r.title,
                            "url": r.url,
                            "snippet": r.snippet,
                        }
                        for r in results
                    ],
                    "count": len(results),
                },
                message=f"{len(results)}件の検索結果",
            )
        except Exception as e:
            return SkillResult.error(str(e), "検索エラー")

    async def _search_news(self, params: dict) -> SkillResult:
        """ニュース検索"""
        query = params.get("query")
        if not query:
            return SkillResult.error("query is required", "クエリが必要です")

        num_results = min(params.get("num_results", 5), self._max_results)

        # ニュース検索用にクエリを調整
        news_query = f"{query} ニュース"

        try:
            results = await self._search_duckduckgo(
                query=news_query,
                num_results=num_results,
                region="jp-jp",
            )

            return SkillResult.success(
                data={
                    "query": query,
                    "results": [
                        {
                            "title": r.title,
                            "url": r.url,
                            "snippet": r.snippet,
                        }
                        for r in results
                    ],
                    "count": len(results),
                },
                message=f"{len(results)}件のニュース結果",
            )
        except Exception as e:
            return SkillResult.error(str(e), "ニュース検索エラー")

    async def _fetch_url(self, params: dict) -> SkillResult:
        """URLからテキストを取得"""
        url = params.get("url")
        if not url:
            return SkillResult.error("url is required", "URLが必要です")

        max_length = params.get("max_length", 5000)

        try:
            html = await asyncio.get_event_loop().run_in_executor(
                None, self._make_request, url
            )

            # HTMLからテキストを抽出（シンプルな方法）
            # scriptとstyleタグを除去
            text = re.sub(
                r'<script[^>]*>.*?</script>',
                '',
                html,
                flags=re.DOTALL | re.IGNORECASE
            )
            text = re.sub(
                r'<style[^>]*>.*?</style>',
                '',
                text,
                flags=re.DOTALL | re.IGNORECASE
            )

            # HTMLタグを除去
            text = self._clean_html(text)

            # 長さ制限
            if len(text) > max_length:
                text = text[:max_length] + "... (truncated)"

            return SkillResult.success(
                data={
                    "url": url,
                    "content": text,
                    "length": len(text),
                },
                message=f"コンテンツを取得しました ({len(text)}文字)",
            )
        except Exception as e:
            return SkillResult.error(str(e), "URL取得エラー")
