"""IXV-Core ログ機能"""

import json
import time
import logging
from pathlib import Path
from typing import Optional, Any, Dict, List
from logging.handlers import RotatingFileHandler

from app.config import config

_log = logging.getLogger("ixv-core.logger")


class IXVLogger:
    """推論ログを管理

    RotatingFileHandlerを使用してログローテーションをサポート。
    """

    def __init__(self, max_bytes: int = 10 * 1024 * 1024, backup_count: int = 5) -> None:
        """
        Args:
            max_bytes: ローテーションするファイルサイズ（デフォルト: 10MB）
            backup_count: 保持する過去ログファイル数（デフォルト: 5）
        """
        self.log_dir: Path = config.log_dir
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.log_file: Path = self.log_dir / "ixv-core.log"

        # ログローテーション用のハンドラー設定
        self.max_bytes = max_bytes
        self.backup_count = backup_count

        _log.info(f"Logger initialized with rotation: max_bytes={max_bytes}, backup_count={backup_count}")

    def _check_and_rotate(self) -> None:
        """ファイルサイズをチェックし、必要に応じてローテーション"""
        if not self.log_file.exists():
            return

        file_size = self.log_file.stat().st_size
        if file_size >= self.max_bytes:
            # バックアップファイルをシフト
            for i in range(self.backup_count - 1, 0, -1):
                old_backup = self.log_dir / f"ixv-core.log.{i}"
                new_backup = self.log_dir / f"ixv-core.log.{i + 1}"
                if old_backup.exists():
                    if new_backup.exists():
                        new_backup.unlink()
                    old_backup.rename(new_backup)

            # 現在のログファイルを .1 にリネーム
            backup_file = self.log_dir / "ixv-core.log.1"
            if backup_file.exists():
                backup_file.unlink()
            self.log_file.rename(backup_file)

            _log.info(f"Log rotated: {self.log_file} -> {backup_file}")

    def log_inference(
        self,
        *,
        prompt: Optional[str],
        completion: Optional[str],
        model: str,
        usage: Optional[Dict[str, Any]] = None,
        extra: Optional[Dict[str, Any]] = None,
    ) -> None:
        """推論ログを1行JSONで記録（ローテーション対応）"""

        record: Dict[str, Any] = {
            "timestamp": time.time(),
            "model": model,
            "usage": usage or {},
        }

        if extra:
            record.update(extra)

        # メッセージ全文はオプション
        if config.log_messages:
            record["prompt"] = prompt
            record["completion"] = completion

        # ローテーションチェック
        self._check_and_rotate()

        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

    def get_recent(self, limit: int = 100) -> list[dict]:
        """直近のログを取得"""

        if not self.log_file.exists():
            return []

        with open(self.log_file, encoding="utf-8") as f:
            lines: List[str] = f.read().splitlines()

        if limit <= 0:
            limit = 1

        # 新しいものが末尾に追加されている前提
        recent_lines = lines[-limit:] if len(lines) > limit else lines

        records: List[dict] = []
        for line in recent_lines:
            line = line.strip()
            if not line:
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError:
                # 壊れた行はスキップ
                continue
        return records


# シングルトンインスタンス
logger = IXVLogger()
