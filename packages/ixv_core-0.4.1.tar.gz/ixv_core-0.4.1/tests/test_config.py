"""IXVConfig のユニットテスト"""

import os
import pytest
from pathlib import Path
from unittest.mock import patch

from app.config import IXVConfig, _parse_int_env


class TestParseIntEnv:
    """_parse_int_env ヘルパー関数のテスト"""

    def test_valid_value(self):
        """有効な値のパース"""
        with patch.dict(os.environ, {"TEST_VAR": "100"}, clear=True):
            result = _parse_int_env("TEST_VAR", 50)
        assert result == 100

    def test_default_when_not_set(self):
        """未設定時のデフォルト値"""
        with patch.dict(os.environ, {}, clear=True):
            result = _parse_int_env("TEST_VAR", 50)
        assert result == 50

    def test_invalid_value_returns_default(self):
        """無効な値はデフォルトを返す"""
        with patch.dict(os.environ, {"TEST_VAR": "abc"}, clear=True):
            result = _parse_int_env("TEST_VAR", 50)
        assert result == 50

    def test_below_min_returns_default(self):
        """最小値未満はデフォルトを返す"""
        with patch.dict(os.environ, {"TEST_VAR": "5"}, clear=True):
            result = _parse_int_env("TEST_VAR", 50, min_val=10)
        assert result == 50

    def test_above_max_returns_default(self):
        """最大値超過はデフォルトを返す"""
        with patch.dict(os.environ, {"TEST_VAR": "200"}, clear=True):
            result = _parse_int_env("TEST_VAR", 50, max_val=100)
        assert result == 50


class TestIXVConfig:
    """IXVConfig クラスのテスト"""

    def test_default_values(self):
        """デフォルト値の確認"""
        with patch.dict(os.environ, {}, clear=True):
            config = IXVConfig.from_env()

        assert config.model_path == "models/ixv-model.gguf"
        assert config.n_ctx == 4096
        assert config.n_threads == 8
        assert config.host == "0.0.0.0"
        assert config.port == 8000
        assert config.log_messages is False
        assert config.max_memory_turns == 10
        assert config.debug_mode is False

    def test_env_override(self):
        """環境変数での上書き"""
        env_vars = {
            "IXV_MODEL_PATH": "/custom/model.gguf",
            "IXV_N_CTX": "8192",
            "IXV_N_THREADS": "16",
            "IXV_HOST": "127.0.0.1",
            "IXV_PORT": "9000",
            "IXV_LOG_MESSAGES": "true",
            "IXV_MAX_MEMORY_TURNS": "20",
            "IXV_DEBUG": "true",
        }
        with patch.dict(os.environ, env_vars, clear=True):
            config = IXVConfig.from_env()

        assert config.model_path == "/custom/model.gguf"
        assert config.n_ctx == 8192
        assert config.n_threads == 16
        assert config.host == "127.0.0.1"
        assert config.port == 9000
        assert config.log_messages is True
        assert config.max_memory_turns == 20
        assert config.debug_mode is True

    def test_log_dir_default(self):
        """ログディレクトリのデフォルト値"""
        with patch.dict(os.environ, {}, clear=True):
            config = IXVConfig.from_env()

        expected = Path.home() / ".ixv" / "logs"
        assert config.log_dir == expected

    def test_log_dir_custom(self):
        """カスタムログディレクトリ"""
        with patch.dict(os.environ, {"IXV_LOG_DIR": "/var/log/ixv"}, clear=True):
            config = IXVConfig.from_env()

        assert config.log_dir == Path("/var/log/ixv")

    def test_log_messages_false_variations(self):
        """log_messages が false と解釈される値"""
        for value in ["false", "False", "FALSE", "0", "no", ""]:
            with patch.dict(os.environ, {"IXV_LOG_MESSAGES": value}, clear=True):
                config = IXVConfig.from_env()
                assert config.log_messages is False, f"Failed for value: {value}"

    def test_log_messages_true(self):
        """log_messages が true と解釈される値"""
        with patch.dict(os.environ, {"IXV_LOG_MESSAGES": "true"}, clear=True):
            config = IXVConfig.from_env()
            assert config.log_messages is True

    def test_get_public_config(self):
        """公開設定の取得"""
        with patch.dict(os.environ, {}, clear=True):
            config = IXVConfig.from_env()
            public = config.get_public_config()

        # 公開される項目
        assert "n_ctx" in public
        assert "n_threads" in public
        assert "port" in public
        assert "max_memory_turns" in public

        # 機密情報は含まれない
        assert "model_path" not in public
        assert "log_dir" not in public
        assert "host" not in public

    def test_get_debug_config(self):
        """デバッグ設定の取得"""
        with patch.dict(os.environ, {}, clear=True):
            config = IXVConfig.from_env()
            debug = config.get_debug_config()

        # 全項目が含まれる
        assert "model_path" in debug
        assert "n_ctx" in debug
        assert "log_dir" in debug
        assert "debug_mode" in debug
