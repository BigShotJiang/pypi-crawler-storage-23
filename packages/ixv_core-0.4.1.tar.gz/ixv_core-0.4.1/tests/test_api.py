"""API エンドポイントの統合テスト"""

import pytest
from unittest.mock import patch, MagicMock, AsyncMock
from fastapi.testclient import TestClient

from app.main import create_app
from app.exceptions import ModelNotLoadedError


@pytest.fixture
def client():
    """テスト用クライアント（モデルロードをスキップ）"""
    with patch("app.main.ModelLoader.load"):
        app = create_app()
        with TestClient(app) as client:
            yield client


@pytest.fixture
def client_with_mock_model():
    """モデルをモックしたテスト用クライアント"""
    # inference_service.chatの戻り値をモック
    mock_chat_result = {
        "text": "This is a test response.",
        "usage": {
            "prompt_tokens": 10,
            "completion_tokens": 5,
            "total_tokens": 15,
        },
        "elapsed": 0.1,
    }

    # 同時実行数制限をモック（即座にコンテキストを返す）
    mock_limiter = MagicMock()
    mock_limiter.__aenter__ = AsyncMock(return_value=mock_limiter)
    mock_limiter.__aexit__ = AsyncMock(return_value=None)

    with patch("app.main.ModelLoader.load"):
        with patch("app.router_openai.inference_service") as mock_inference:
            mock_inference.chat.return_value = mock_chat_result
            with patch("app.router_openai.concurrency_limiter", mock_limiter):
                app = create_app()
                with TestClient(app) as client:
                    yield client


class TestHealthEndpoint:
    """ヘルスチェックエンドポイントのテスト"""

    def test_health_check(self, client):
        """正常系"""
        response = client.get("/ixv/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"


class TestModelsEndpoint:
    """モデル一覧エンドポイントのテスト"""

    def test_list_models(self, client):
        """モデル一覧取得"""
        response = client.get("/v1/models")
        assert response.status_code == 200
        data = response.json()
        assert data["object"] == "list"
        assert len(data["data"]) >= 1
        assert data["data"][0]["id"] == "ixv-model"


class TestChatCompletionsValidation:
    """Chat Completions のバリデーションテスト"""

    def test_empty_messages(self, client):
        """空のメッセージリストはエラー"""
        response = client.post(
            "/v1/chat/completions",
            json={"messages": []},
        )
        assert response.status_code == 422  # Validation Error

    def test_invalid_temperature_too_high(self, client):
        """temperature が範囲外（高）"""
        response = client.post(
            "/v1/chat/completions",
            json={
                "messages": [{"role": "user", "content": "Hello"}],
                "temperature": 3.0,
            },
        )
        assert response.status_code == 422

    def test_invalid_temperature_negative(self, client):
        """temperature が範囲外（負）"""
        response = client.post(
            "/v1/chat/completions",
            json={
                "messages": [{"role": "user", "content": "Hello"}],
                "temperature": -0.5,
            },
        )
        assert response.status_code == 422

    def test_invalid_max_tokens_zero(self, client):
        """max_tokens がゼロ"""
        response = client.post(
            "/v1/chat/completions",
            json={
                "messages": [{"role": "user", "content": "Hello"}],
                "max_tokens": 0,
            },
        )
        assert response.status_code == 422

    def test_invalid_max_tokens_too_large(self, client):
        """max_tokens が大きすぎる"""
        response = client.post(
            "/v1/chat/completions",
            json={
                "messages": [{"role": "user", "content": "Hello"}],
                "max_tokens": 100000,
            },
        )
        assert response.status_code == 422

    def test_invalid_role(self, client):
        """無効なロール"""
        response = client.post(
            "/v1/chat/completions",
            json={
                "messages": [{"role": "invalid", "content": "Hello"}],
            },
        )
        assert response.status_code == 422

    def test_empty_content(self, client):
        """空のコンテンツ"""
        response = client.post(
            "/v1/chat/completions",
            json={
                "messages": [{"role": "user", "content": ""}],
            },
        )
        assert response.status_code == 422


class TestMemoryEndpoints:
    """メモリ管理エンドポイントのテスト"""

    def test_get_memory(self, client):
        """メモリ取得"""
        response = client.get("/ixv/memory")
        assert response.status_code == 200
        data = response.json()
        assert "history" in data

    def test_clear_memory(self, client):
        """メモリクリア"""
        response = client.post("/ixv/memory/clear")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "cleared"


class TestConfigEndpoint:
    """設定エンドポイントのテスト"""

    def test_get_config(self, client):
        """設定取得"""
        response = client.get("/ixv/config")
        assert response.status_code == 200
        data = response.json()
        assert "n_ctx" in data
        assert "n_threads" in data
        assert "port" in data


class TestErrorHandling:
    """エラーハンドリングのテスト"""

    def test_model_not_loaded_error(self, client):
        """モデル未ロードエラー"""
        # 同時実行数制限をモック
        mock_limiter = MagicMock()
        mock_limiter.__aenter__ = AsyncMock(return_value=mock_limiter)
        mock_limiter.__aexit__ = AsyncMock(return_value=None)

        with patch("app.router_openai.concurrency_limiter", mock_limiter):
            with patch(
                "app.router_openai.inference_service.chat",
                side_effect=ModelNotLoadedError(),
            ):
                response = client.post(
                    "/v1/chat/completions",
                    json={
                        "messages": [{"role": "user", "content": "Hello"}],
                    },
                )
                assert response.status_code == 503
                data = response.json()
                assert "error" in data
                assert data["error"]["code"] == "model_not_loaded"
