"""SkillManager のユニットテスト"""

import pytest
from unittest.mock import AsyncMock

from app.skills.base import BaseSkill, SkillResult, SkillStatus


class MockSkill(BaseSkill):
    """テスト用モックスキル"""

    def __init__(self, skill_name: str = "mock_skill"):
        self._name = skill_name

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return f"Mock skill: {self._name}"

    def get_actions(self) -> list[dict]:
        return [
            {"name": "test_action", "description": "Test action", "parameters": {}},
        ]

    async def execute(self, action: str, params: dict) -> SkillResult:
        if action == "test_action":
            return SkillResult.success(data={"result": "ok"}, message="Success")
        elif action == "error_action":
            raise ValueError("Test error")
        return SkillResult.error(error=f"Unknown action: {action}", message="Error")


@pytest.fixture
def fresh_skill_manager():
    """新しいSkillManagerインスタンスを作成（シングルトンをリセット）"""
    from app.skills.skill_manager import SkillManager
    # シングルトンをリセット
    SkillManager._instance = None
    manager = SkillManager()
    yield manager
    # テスト後にリセット
    SkillManager._instance = None


class TestSkillManager:
    """SkillManager のテスト"""

    def test_singleton_pattern(self, fresh_skill_manager):
        """シングルトンパターンの確認"""
        from app.skills.skill_manager import SkillManager
        manager1 = SkillManager()
        manager2 = SkillManager()
        assert manager1 is manager2

    def test_register_skill(self, fresh_skill_manager):
        """スキルの登録"""
        skill = MockSkill("test_skill")
        fresh_skill_manager.register(skill)

        assert fresh_skill_manager.get_skill("test_skill") is skill
        assert fresh_skill_manager.is_enabled("test_skill") is True

    def test_register_skill_disabled(self, fresh_skill_manager):
        """無効状態でスキルを登録"""
        skill = MockSkill("disabled_skill")
        fresh_skill_manager.register(skill, enabled=False)

        assert fresh_skill_manager.get_skill("disabled_skill") is skill
        assert fresh_skill_manager.is_enabled("disabled_skill") is False

    def test_unregister_skill(self, fresh_skill_manager):
        """スキルの登録解除"""
        skill = MockSkill("to_remove")
        fresh_skill_manager.register(skill)

        assert fresh_skill_manager.unregister("to_remove") is True
        assert fresh_skill_manager.get_skill("to_remove") is None
        assert fresh_skill_manager.is_enabled("to_remove") is False

    def test_unregister_nonexistent_skill(self, fresh_skill_manager):
        """存在しないスキルの登録解除"""
        result = fresh_skill_manager.unregister("nonexistent")
        assert result is False

    def test_enable_skill(self, fresh_skill_manager):
        """スキルの有効化"""
        skill = MockSkill("enable_test")
        fresh_skill_manager.register(skill, enabled=False)

        assert fresh_skill_manager.is_enabled("enable_test") is False
        result = fresh_skill_manager.enable_skill("enable_test")
        assert result is True
        assert fresh_skill_manager.is_enabled("enable_test") is True

    def test_enable_nonexistent_skill(self, fresh_skill_manager):
        """存在しないスキルの有効化"""
        result = fresh_skill_manager.enable_skill("nonexistent")
        assert result is False

    def test_disable_skill(self, fresh_skill_manager):
        """スキルの無効化"""
        skill = MockSkill("disable_test")
        fresh_skill_manager.register(skill, enabled=True)

        assert fresh_skill_manager.is_enabled("disable_test") is True
        result = fresh_skill_manager.disable_skill("disable_test")
        assert result is True
        assert fresh_skill_manager.is_enabled("disable_test") is False

    def test_disable_nonexistent_skill(self, fresh_skill_manager):
        """存在しないスキルの無効化"""
        result = fresh_skill_manager.disable_skill("nonexistent")
        assert result is False

    def test_list_skills(self, fresh_skill_manager):
        """スキル一覧の取得"""
        skill1 = MockSkill("skill1")
        skill2 = MockSkill("skill2")
        fresh_skill_manager.register(skill1, enabled=True)
        fresh_skill_manager.register(skill2, enabled=False)

        skills = fresh_skill_manager.list_skills()
        assert len(skills) == 2

        skill_dict = {s["name"]: s for s in skills}
        assert skill_dict["skill1"]["enabled"] is True
        assert skill_dict["skill2"]["enabled"] is False
        assert "test_action" in skill_dict["skill1"]["actions"]

    def test_get_skill_info(self, fresh_skill_manager):
        """スキル詳細情報の取得"""
        skill = MockSkill("info_test")
        fresh_skill_manager.register(skill)

        info = fresh_skill_manager.get_skill_info("info_test")
        assert info is not None
        assert info["name"] == "info_test"
        assert info["description"] == "Mock skill: info_test"
        assert info["enabled"] is True
        assert len(info["actions"]) == 1

    def test_get_skill_info_nonexistent(self, fresh_skill_manager):
        """存在しないスキルの詳細情報取得"""
        info = fresh_skill_manager.get_skill_info("nonexistent")
        assert info is None

    @pytest.mark.asyncio
    async def test_execute_skill(self, fresh_skill_manager):
        """スキルの実行"""
        skill = MockSkill("exec_test")
        fresh_skill_manager.register(skill)

        result = await fresh_skill_manager.execute("exec_test", "test_action", {})
        assert result.status == SkillStatus.SUCCESS
        assert result.data["result"] == "ok"

    @pytest.mark.asyncio
    async def test_execute_nonexistent_skill(self, fresh_skill_manager):
        """存在しないスキルの実行"""
        result = await fresh_skill_manager.execute("nonexistent", "action", {})
        assert result.status == SkillStatus.ERROR
        assert "Skill not found" in result.error

    @pytest.mark.asyncio
    async def test_execute_disabled_skill(self, fresh_skill_manager):
        """無効化されたスキルの実行"""
        skill = MockSkill("disabled_exec")
        fresh_skill_manager.register(skill, enabled=False)

        result = await fresh_skill_manager.execute("disabled_exec", "test_action", {})
        assert result.status == SkillStatus.ERROR
        assert "disabled" in result.error.lower()

    @pytest.mark.asyncio
    async def test_execute_skill_with_exception(self, fresh_skill_manager):
        """例外を発生させるスキルの実行"""
        skill = MockSkill("exception_test")
        fresh_skill_manager.register(skill)

        result = await fresh_skill_manager.execute("exception_test", "error_action", {})
        assert result.status == SkillStatus.ERROR
        assert "Test error" in result.error
