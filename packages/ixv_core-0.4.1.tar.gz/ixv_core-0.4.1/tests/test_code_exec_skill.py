"""CodeExecSkill のユニットテスト"""

import os
import tempfile
import pytest
from pathlib import Path
from unittest.mock import patch, AsyncMock

from app.skills.code_exec import CodeExecSkill
from app.skills.base import SkillStatus


@pytest.fixture
def temp_dir():
    """一時ディレクトリを作成"""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def skill():
    """CodeExecSkill インスタンスを作成"""
    return CodeExecSkill(timeout=10, max_output_size=1024)


@pytest.fixture
def skill_with_restrictions(temp_dir):
    """制限付きCodeExecSkill インスタンス"""
    return CodeExecSkill(
        timeout=10,
        working_dir=str(temp_dir),
        allowed_commands=["echo", "ls", "cat"]
    )


class TestCodeExecSkillProperties:
    """CodeExecSkill プロパティのテスト"""

    def test_name(self, skill):
        """スキル名の確認"""
        assert skill.name == "code_exec"

    def test_description(self, skill):
        """説明の確認"""
        assert "Python" in skill.description or "コード" in skill.description

    def test_get_actions(self, skill):
        """アクション一覧の確認"""
        actions = skill.get_actions()
        action_names = [a["name"] for a in actions]
        assert "execute_python" in action_names
        assert "execute_shell" in action_names
        assert "execute_script" in action_names


class TestCodeExecPython:
    """execute_python アクションのテスト"""

    @pytest.mark.asyncio
    async def test_execute_python_success(self, skill):
        """Python実行成功"""
        result = await skill.execute("execute_python", {
            "code": "print('Hello, World!')"
        })
        assert result.status == SkillStatus.SUCCESS
        assert "Hello, World!" in result.data["stdout"]

    @pytest.mark.asyncio
    async def test_execute_python_with_calculation(self, skill):
        """Python計算実行"""
        result = await skill.execute("execute_python", {
            "code": "result = 2 + 2\nprint(f'Result: {result}')"
        })
        assert result.status == SkillStatus.SUCCESS
        assert "Result: 4" in result.data["stdout"]

    @pytest.mark.asyncio
    async def test_execute_python_missing_code(self, skill):
        """コード未指定"""
        result = await skill.execute("execute_python", {})
        assert result.status == SkillStatus.ERROR
        assert "required" in result.error.lower()

    @pytest.mark.asyncio
    async def test_execute_python_syntax_error(self, skill):
        """Python構文エラー"""
        result = await skill.execute("execute_python", {
            "code": "print('unclosed"
        })
        assert result.status == SkillStatus.ERROR

    @pytest.mark.asyncio
    async def test_execute_python_runtime_error(self, skill):
        """Python実行時エラー"""
        result = await skill.execute("execute_python", {
            "code": "raise ValueError('Test error')"
        })
        assert result.status == SkillStatus.ERROR
        assert "ValueError" in result.error or "Test error" in result.error

    @pytest.mark.asyncio
    async def test_execute_python_timeout(self):
        """Pythonタイムアウト"""
        skill = CodeExecSkill(timeout=1)  # 1秒タイムアウト
        result = await skill.execute("execute_python", {
            "code": "import time; time.sleep(10)"
        })
        assert result.status == SkillStatus.ERROR
        assert "timeout" in result.error.lower() or "タイムアウト" in result.message


class TestCodeExecShell:
    """execute_shell アクションのテスト"""

    @pytest.mark.asyncio
    async def test_execute_shell_success(self, skill):
        """シェルコマンド実行成功"""
        result = await skill.execute("execute_shell", {
            "command": "echo 'Hello Shell'"
        })
        assert result.status == SkillStatus.SUCCESS
        assert "Hello Shell" in result.data["stdout"]

    @pytest.mark.asyncio
    async def test_execute_shell_with_pipe(self, skill):
        """パイプを使用したコマンド"""
        result = await skill.execute("execute_shell", {
            "command": "echo 'line1\nline2\nline3' | wc -l"
        })
        assert result.status == SkillStatus.SUCCESS
        # 行数カウント結果を確認
        assert "3" in result.data["stdout"]

    @pytest.mark.asyncio
    async def test_execute_shell_missing_command(self, skill):
        """コマンド未指定"""
        result = await skill.execute("execute_shell", {})
        assert result.status == SkillStatus.ERROR
        assert "required" in result.error.lower()

    @pytest.mark.asyncio
    async def test_execute_shell_command_not_found(self, skill):
        """存在しないコマンド"""
        result = await skill.execute("execute_shell", {
            "command": "nonexistentcommand12345"
        })
        assert result.status == SkillStatus.ERROR

    @pytest.mark.asyncio
    async def test_execute_shell_allowed_commands(self, skill_with_restrictions):
        """許可されたコマンド"""
        result = await skill_with_restrictions.execute("execute_shell", {
            "command": "echo 'allowed'"
        })
        assert result.status == SkillStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_execute_shell_disallowed_command(self, skill_with_restrictions):
        """許可されていないコマンド"""
        result = await skill_with_restrictions.execute("execute_shell", {
            "command": "rm -rf /"
        })
        assert result.status == SkillStatus.ERROR
        assert "not allowed" in result.error.lower() or "許可" in result.message

    @pytest.mark.asyncio
    async def test_execute_shell_working_dir(self, temp_dir):
        """作業ディレクトリの指定"""
        skill = CodeExecSkill(working_dir=str(temp_dir))
        result = await skill.execute("execute_shell", {
            "command": "pwd"
        })
        assert result.status == SkillStatus.SUCCESS
        assert str(temp_dir) in result.data["stdout"]


class TestCodeExecScript:
    """execute_script アクションのテスト"""

    @pytest.mark.asyncio
    async def test_execute_python_script(self, skill, temp_dir):
        """Pythonスクリプト実行"""
        script = temp_dir / "test_script.py"
        script.write_text("print('Script executed!')")

        result = await skill.execute("execute_script", {
            "path": str(script)
        })
        assert result.status == SkillStatus.SUCCESS
        assert "Script executed!" in result.data["stdout"]

    @pytest.mark.asyncio
    async def test_execute_shell_script(self, skill, temp_dir):
        """シェルスクリプト実行"""
        script = temp_dir / "test_script.sh"
        script.write_text("#!/bin/bash\necho 'Shell script executed!'")
        os.chmod(script, 0o755)

        result = await skill.execute("execute_script", {
            "path": str(script)
        })
        assert result.status == SkillStatus.SUCCESS
        assert "Shell script executed!" in result.data["stdout"]

    @pytest.mark.asyncio
    async def test_execute_script_with_args(self, skill, temp_dir):
        """引数付きスクリプト実行"""
        script = temp_dir / "args_script.py"
        script.write_text("import sys\nprint(f'Args: {sys.argv[1:]}')")

        result = await skill.execute("execute_script", {
            "path": str(script),
            "args": ["arg1", "arg2"]
        })
        assert result.status == SkillStatus.SUCCESS
        assert "arg1" in result.data["stdout"]
        assert "arg2" in result.data["stdout"]

    @pytest.mark.asyncio
    async def test_execute_script_not_found(self, skill):
        """存在しないスクリプト"""
        result = await skill.execute("execute_script", {
            "path": "/nonexistent/script.py"
        })
        assert result.status == SkillStatus.ERROR
        assert "not found" in result.error.lower() or "見つかりません" in result.message

    @pytest.mark.asyncio
    async def test_execute_script_missing_path(self, skill):
        """パス未指定"""
        result = await skill.execute("execute_script", {})
        assert result.status == SkillStatus.ERROR


class TestCodeExecOutputLimit:
    """出力サイズ制限のテスト"""

    @pytest.mark.asyncio
    async def test_output_truncation(self):
        """出力の切り詰め"""
        skill = CodeExecSkill(max_output_size=50)
        result = await skill.execute("execute_python", {
            "code": "print('A' * 1000)"
        })
        assert result.status == SkillStatus.SUCCESS
        # 出力が切り詰められていることを確認
        assert len(result.data["stdout"]) < 200
        assert "truncated" in result.data["stdout"].lower()


class TestCodeExecUnknownAction:
    """不明なアクションのテスト"""

    @pytest.mark.asyncio
    async def test_unknown_action(self, skill):
        """不明なアクション"""
        result = await skill.execute("unknown_action", {})
        assert result.status == SkillStatus.ERROR
        assert "Unknown action" in result.error
