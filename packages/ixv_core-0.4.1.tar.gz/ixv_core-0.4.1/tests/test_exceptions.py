"""exceptions モジュールのユニットテスト"""

import pytest
from app.exceptions import (
    IXVCoreError,
    ModelLoadError,
    ModelNotLoadedError,
    InferenceError,
    ValidationError,
)


class TestIXVCoreError:
    """IXVCoreError 基底クラスのテスト"""

    def test_message_and_code(self):
        """メッセージとコードの設定"""
        error = IXVCoreError("Test error", code="test_code")
        assert error.message == "Test error"
        assert error.code == "test_code"
        assert str(error) == "Test error"

    def test_default_code(self):
        """デフォルトのエラーコード"""
        error = IXVCoreError("Test error")
        assert error.code == "internal_error"


class TestModelLoadError:
    """ModelLoadError のテスト"""

    def test_with_model_path(self):
        """モデルパス付きエラー"""
        error = ModelLoadError("File not found", model_path="/path/to/model.gguf")
        assert error.message == "File not found"
        assert error.code == "model_load_error"
        assert error.model_path == "/path/to/model.gguf"

    def test_without_model_path(self):
        """モデルパスなしエラー"""
        error = ModelLoadError("Unknown error")
        assert error.model_path is None


class TestModelNotLoadedError:
    """ModelNotLoadedError のテスト"""

    def test_default_message(self):
        """デフォルトメッセージ"""
        error = ModelNotLoadedError()
        assert "not loaded" in error.message.lower()
        assert error.code == "model_not_loaded"


class TestInferenceError:
    """InferenceError のテスト"""

    def test_inference_error(self):
        """推論エラー"""
        error = InferenceError("Inference failed")
        assert error.message == "Inference failed"
        assert error.code == "inference_error"


class TestValidationError:
    """ValidationError のテスト"""

    def test_with_field(self):
        """フィールド指定付きエラー"""
        error = ValidationError("Invalid value", field="temperature")
        assert error.message == "Invalid value"
        assert error.code == "validation_error"
        assert error.field == "temperature"

    def test_without_field(self):
        """フィールド指定なしエラー"""
        error = ValidationError("Invalid request")
        assert error.field is None
