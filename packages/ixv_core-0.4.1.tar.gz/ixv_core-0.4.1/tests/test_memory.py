"""ConversationMemory のユニットテスト"""

import pytest
from app.memory import ConversationMemory


class TestConversationMemory:
    """ConversationMemory クラスのテスト"""

    def test_add_and_get_history(self):
        """メッセージ追加と履歴取得"""
        mem = ConversationMemory(max_turns=10)
        mem.add("user", "Hello")
        mem.add("assistant", "Hi there!")

        history = mem.get_history()
        assert len(history) == 2
        assert history[0] == {"role": "user", "content": "Hello"}
        assert history[1] == {"role": "assistant", "content": "Hi there!"}

    def test_max_turns_limit(self):
        """max_turns を超えた場合に古いメッセージが削除される"""
        mem = ConversationMemory(max_turns=3)
        mem.add("user", "msg1")
        mem.add("assistant", "msg2")
        mem.add("user", "msg3")
        mem.add("assistant", "msg4")  # これでmax_turnsを超える

        history = mem.get_history()
        assert len(history) == 3
        # 最初のメッセージが削除されている
        assert history[0]["content"] == "msg2"
        assert history[1]["content"] == "msg3"
        assert history[2]["content"] == "msg4"

    def test_clear(self):
        """履歴クリア"""
        mem = ConversationMemory(max_turns=10)
        mem.add("user", "Hello")
        mem.add("assistant", "Hi!")

        mem.clear()
        assert len(mem.get_history()) == 0

    def test_as_prompt(self):
        """プロンプト文字列への変換"""
        mem = ConversationMemory(max_turns=10)
        mem.add("user", "What is Python?")
        mem.add("assistant", "Python is a programming language.")
        mem.add("user", "Tell me more.")

        prompt = mem.as_prompt()
        expected = (
            "user: What is Python?\n"
            "assistant: Python is a programming language.\n"
            "user: Tell me more.\n"
            "assistant:"
        )
        assert prompt == expected

    def test_as_prompt_empty(self):
        """空の履歴でのプロンプト生成"""
        mem = ConversationMemory(max_turns=10)
        prompt = mem.as_prompt()
        assert prompt == "assistant:"

    def test_get_history_returns_copy(self):
        """get_history() が履歴のコピーを返す"""
        mem = ConversationMemory(max_turns=10)
        mem.add("user", "Hello")

        history = mem.get_history()
        history.append({"role": "user", "content": "Modified"})

        # 元の履歴は変更されていない
        assert len(mem.get_history()) == 1
