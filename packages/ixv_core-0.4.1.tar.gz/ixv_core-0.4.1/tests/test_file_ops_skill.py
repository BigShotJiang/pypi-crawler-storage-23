"""FileOpsSkill のユニットテスト"""

import os
import tempfile
import pytest
from pathlib import Path

from app.skills.file_ops import FileOpsSkill
from app.skills.base import SkillStatus


@pytest.fixture
def temp_dir():
    """一時ディレクトリを作成"""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def skill(temp_dir):
    """FileOpsSkill インスタンスを作成（base_dir制限あり）"""
    return FileOpsSkill(base_dir=str(temp_dir), max_file_size=1024 * 1024)


@pytest.fixture
def skill_no_restriction():
    """制限なしのFileOpsSkill インスタンス"""
    return FileOpsSkill()


class TestFileOpsSkillProperties:
    """FileOpsSkill プロパティのテスト"""

    def test_name(self, skill):
        """スキル名の確認"""
        assert skill.name == "file_ops"

    def test_description(self, skill):
        """説明の確認"""
        assert "ファイル" in skill.description

    def test_get_actions(self, skill):
        """アクション一覧の確認"""
        actions = skill.get_actions()
        action_names = [a["name"] for a in actions]
        assert "read_file" in action_names
        assert "write_file" in action_names
        assert "list_dir" in action_names
        assert "search_files" in action_names
        assert "delete_file" in action_names
        assert "move_file" in action_names
        assert "copy_file" in action_names


class TestFileOpsReadFile:
    """read_file アクションのテスト"""

    @pytest.mark.asyncio
    async def test_read_file_success(self, skill, temp_dir):
        """ファイル読み込み成功"""
        test_file = temp_dir / "test.txt"
        test_file.write_text("Hello, World!", encoding="utf-8")

        result = await skill.execute("read_file", {"path": str(test_file)})
        assert result.status == SkillStatus.SUCCESS
        assert result.data["content"] == "Hello, World!"
        assert result.data["size"] == 13

    @pytest.mark.asyncio
    async def test_read_file_not_found(self, skill, temp_dir):
        """存在しないファイルの読み込み"""
        result = await skill.execute("read_file", {"path": str(temp_dir / "nonexistent.txt")})
        assert result.status == SkillStatus.ERROR
        assert "not found" in result.error.lower()

    @pytest.mark.asyncio
    async def test_read_file_missing_path(self, skill):
        """パス未指定"""
        result = await skill.execute("read_file", {})
        assert result.status == SkillStatus.ERROR
        assert "required" in result.error.lower()

    @pytest.mark.asyncio
    async def test_read_file_directory(self, skill, temp_dir):
        """ディレクトリを読もうとした場合"""
        result = await skill.execute("read_file", {"path": str(temp_dir)})
        assert result.status == SkillStatus.ERROR

    @pytest.mark.asyncio
    async def test_read_file_too_large(self, temp_dir):
        """ファイルサイズ超過"""
        skill = FileOpsSkill(base_dir=str(temp_dir), max_file_size=10)  # 10バイト制限
        test_file = temp_dir / "large.txt"
        test_file.write_text("This is more than 10 bytes", encoding="utf-8")

        result = await skill.execute("read_file", {"path": str(test_file)})
        assert result.status == SkillStatus.ERROR
        assert "too large" in result.error.lower()

    @pytest.mark.asyncio
    async def test_read_file_outside_base_dir(self, skill, temp_dir):
        """base_dir外のファイルアクセス"""
        result = await skill.execute("read_file", {"path": "/etc/passwd"})
        assert result.status == SkillStatus.ERROR
        assert "禁止" in result.error or "outside" in result.error.lower()


class TestFileOpsWriteFile:
    """write_file アクションのテスト"""

    @pytest.mark.asyncio
    async def test_write_file_success(self, skill, temp_dir):
        """ファイル書き込み成功"""
        test_file = temp_dir / "new_file.txt"
        result = await skill.execute("write_file", {
            "path": str(test_file),
            "content": "New content"
        })
        assert result.status == SkillStatus.SUCCESS
        assert test_file.read_text() == "New content"

    @pytest.mark.asyncio
    async def test_write_file_create_dirs(self, skill, temp_dir):
        """親ディレクトリを自動作成"""
        test_file = temp_dir / "subdir" / "nested" / "file.txt"
        result = await skill.execute("write_file", {
            "path": str(test_file),
            "content": "Nested content",
            "create_dirs": True
        })
        assert result.status == SkillStatus.SUCCESS
        assert test_file.exists()
        assert test_file.read_text() == "Nested content"

    @pytest.mark.asyncio
    async def test_write_file_missing_path(self, skill):
        """パス未指定"""
        result = await skill.execute("write_file", {"content": "test"})
        assert result.status == SkillStatus.ERROR

    @pytest.mark.asyncio
    async def test_write_file_missing_content(self, skill, temp_dir):
        """内容未指定"""
        result = await skill.execute("write_file", {"path": str(temp_dir / "test.txt")})
        assert result.status == SkillStatus.ERROR


class TestFileOpsAppendFile:
    """append_file アクションのテスト"""

    @pytest.mark.asyncio
    async def test_append_file_success(self, skill, temp_dir):
        """ファイル追記成功"""
        test_file = temp_dir / "append.txt"
        test_file.write_text("First line\n", encoding="utf-8")

        result = await skill.execute("append_file", {
            "path": str(test_file),
            "content": "Second line\n"
        })
        assert result.status == SkillStatus.SUCCESS
        assert test_file.read_text() == "First line\nSecond line\n"


class TestFileOpsListDir:
    """list_dir アクションのテスト"""

    @pytest.mark.asyncio
    async def test_list_dir_success(self, skill, temp_dir):
        """ディレクトリ一覧取得成功"""
        (temp_dir / "file1.txt").write_text("1")
        (temp_dir / "file2.txt").write_text("2")
        (temp_dir / "subdir").mkdir()

        result = await skill.execute("list_dir", {"path": str(temp_dir)})
        assert result.status == SkillStatus.SUCCESS
        assert result.data["count"] == 3

        names = [e["name"] for e in result.data["entries"]]
        assert "file1.txt" in names
        assert "file2.txt" in names
        assert "subdir" in names

    @pytest.mark.asyncio
    async def test_list_dir_recursive(self, skill, temp_dir):
        """再帰的一覧取得"""
        (temp_dir / "file.txt").write_text("root")
        subdir = temp_dir / "subdir"
        subdir.mkdir()
        (subdir / "nested.txt").write_text("nested")

        result = await skill.execute("list_dir", {
            "path": str(temp_dir),
            "recursive": True
        })
        assert result.status == SkillStatus.SUCCESS
        paths = [e["path"] for e in result.data["entries"]]
        assert any("nested.txt" in p for p in paths)

    @pytest.mark.asyncio
    async def test_list_dir_exclude_hidden(self, skill, temp_dir):
        """隠しファイルを除外"""
        (temp_dir / "visible.txt").write_text("visible")
        (temp_dir / ".hidden").write_text("hidden")

        result = await skill.execute("list_dir", {
            "path": str(temp_dir),
            "include_hidden": False
        })
        assert result.status == SkillStatus.SUCCESS
        names = [e["name"] for e in result.data["entries"]]
        assert "visible.txt" in names
        assert ".hidden" not in names

    @pytest.mark.asyncio
    async def test_list_dir_include_hidden(self, skill, temp_dir):
        """隠しファイルを含める"""
        (temp_dir / "visible.txt").write_text("visible")
        (temp_dir / ".hidden").write_text("hidden")

        result = await skill.execute("list_dir", {
            "path": str(temp_dir),
            "include_hidden": True
        })
        assert result.status == SkillStatus.SUCCESS
        names = [e["name"] for e in result.data["entries"]]
        assert ".hidden" in names


class TestFileOpsSearchFiles:
    """search_files アクションのテスト"""

    @pytest.mark.asyncio
    async def test_search_files_success(self, skill, temp_dir):
        """ファイル検索成功"""
        (temp_dir / "file1.py").write_text("python")
        (temp_dir / "file2.py").write_text("python")
        (temp_dir / "file3.txt").write_text("text")

        result = await skill.execute("search_files", {
            "pattern": "*.py",
            "base_path": str(temp_dir)
        })
        assert result.status == SkillStatus.SUCCESS
        assert result.data["count"] == 2

    @pytest.mark.asyncio
    async def test_search_files_recursive(self, skill, temp_dir):
        """再帰的ファイル検索"""
        (temp_dir / "root.py").write_text("root")
        subdir = temp_dir / "subdir"
        subdir.mkdir()
        (subdir / "nested.py").write_text("nested")

        result = await skill.execute("search_files", {
            "pattern": "**/*.py",
            "base_path": str(temp_dir)
        })
        assert result.status == SkillStatus.SUCCESS
        assert result.data["count"] == 2


class TestFileOpsFileInfo:
    """file_info アクションのテスト"""

    @pytest.mark.asyncio
    async def test_file_info_success(self, skill, temp_dir):
        """ファイル情報取得成功"""
        test_file = temp_dir / "info.txt"
        test_file.write_text("content")

        result = await skill.execute("file_info", {"path": str(test_file)})
        assert result.status == SkillStatus.SUCCESS
        assert result.data["name"] == "info.txt"
        assert result.data["type"] == "file"
        assert result.data["extension"] == ".txt"
        assert result.data["size"] == 7

    @pytest.mark.asyncio
    async def test_file_info_directory(self, skill, temp_dir):
        """ディレクトリ情報取得"""
        result = await skill.execute("file_info", {"path": str(temp_dir)})
        assert result.status == SkillStatus.SUCCESS
        assert result.data["type"] == "dir"


class TestFileOpsDeleteFile:
    """delete_file アクションのテスト"""

    @pytest.mark.asyncio
    async def test_delete_file_success(self, skill, temp_dir):
        """ファイル削除成功"""
        test_file = temp_dir / "to_delete.txt"
        test_file.write_text("delete me")

        result = await skill.execute("delete_file", {"path": str(test_file)})
        assert result.status == SkillStatus.SUCCESS
        assert not test_file.exists()

    @pytest.mark.asyncio
    async def test_delete_file_not_found(self, skill, temp_dir):
        """存在しないファイルの削除"""
        result = await skill.execute("delete_file", {"path": str(temp_dir / "nonexistent.txt")})
        assert result.status == SkillStatus.ERROR

    @pytest.mark.asyncio
    async def test_delete_directory_fails(self, skill, temp_dir):
        """ディレクトリ削除は失敗"""
        subdir = temp_dir / "subdir"
        subdir.mkdir()

        result = await skill.execute("delete_file", {"path": str(subdir)})
        assert result.status == SkillStatus.ERROR


class TestFileOpsMoveFile:
    """move_file アクションのテスト"""

    @pytest.mark.asyncio
    async def test_move_file_success(self, skill, temp_dir):
        """ファイル移動成功"""
        source = temp_dir / "source.txt"
        dest = temp_dir / "destination.txt"
        source.write_text("content")

        result = await skill.execute("move_file", {
            "source": str(source),
            "destination": str(dest)
        })
        assert result.status == SkillStatus.SUCCESS
        assert not source.exists()
        assert dest.exists()
        assert dest.read_text() == "content"

    @pytest.mark.asyncio
    async def test_move_file_rename(self, skill, temp_dir):
        """ファイルリネーム"""
        old_name = temp_dir / "old.txt"
        new_name = temp_dir / "new.txt"
        old_name.write_text("content")

        result = await skill.execute("move_file", {
            "source": str(old_name),
            "destination": str(new_name)
        })
        assert result.status == SkillStatus.SUCCESS
        assert new_name.exists()


class TestFileOpsCopyFile:
    """copy_file アクションのテスト"""

    @pytest.mark.asyncio
    async def test_copy_file_success(self, skill, temp_dir):
        """ファイルコピー成功"""
        source = temp_dir / "source.txt"
        dest = temp_dir / "copy.txt"
        source.write_text("content")

        result = await skill.execute("copy_file", {
            "source": str(source),
            "destination": str(dest)
        })
        assert result.status == SkillStatus.SUCCESS
        assert source.exists()  # 元ファイルは残る
        assert dest.exists()
        assert dest.read_text() == "content"

    @pytest.mark.asyncio
    async def test_copy_directory(self, skill, temp_dir):
        """ディレクトリコピー"""
        source_dir = temp_dir / "source_dir"
        source_dir.mkdir()
        (source_dir / "file.txt").write_text("content")
        dest_dir = temp_dir / "dest_dir"

        result = await skill.execute("copy_file", {
            "source": str(source_dir),
            "destination": str(dest_dir)
        })
        assert result.status == SkillStatus.SUCCESS
        assert (dest_dir / "file.txt").exists()


class TestFileOpsUnknownAction:
    """不明なアクションのテスト"""

    @pytest.mark.asyncio
    async def test_unknown_action(self, skill):
        """不明なアクション"""
        result = await skill.execute("unknown_action", {})
        assert result.status == SkillStatus.ERROR
        assert "Unknown action" in result.error
