"""プロンプトテンプレートのテスト"""

import pytest
from app.prompts import PromptTemplate, PromptType, detect_language


class TestPromptTemplate:
    """PromptTemplateクラスのテスト"""

    def test_format_general(self):
        """汎用プロンプトのフォーマット"""
        result = PromptTemplate.format(
            PromptType.GENERAL, context="今日の天気を教えてください"
        )
        assert "アシスタント" in result
        assert "今日の天気を教えてください" in result

    def test_format_code_completion(self):
        """コード補完プロンプトのフォーマット"""
        result = PromptTemplate.format(
            PromptType.CODE_COMPLETION,
            language="python",
            code="def hello():\n    print(",
        )
        assert "python" in result
        assert "def hello()" in result
        assert "補完" in result or "予測" in result

    def test_format_code_explanation(self):
        """コード説明プロンプトのフォーマット"""
        result = PromptTemplate.format(
            PromptType.CODE_EXPLANATION,
            language="javascript",
            code="const x = 10;",
        )
        assert "javascript" in result
        assert "const x = 10;" in result
        assert "説明" in result

    def test_format_code_review(self):
        """コードレビュープロンプトのフォーマット"""
        result = PromptTemplate.format(
            PromptType.CODE_REVIEW, language="python", code="x=1+2"
        )
        assert "python" in result
        assert "x=1+2" in result
        assert "レビュー" in result

    def test_format_bug_fix(self):
        """バグ修正プロンプトのフォーマット"""
        result = PromptTemplate.format(
            PromptType.BUG_FIX,
            language="python",
            code="print(x)",
            error="NameError: name 'x' is not defined",
        )
        assert "python" in result
        assert "print(x)" in result
        assert "NameError" in result

    def test_format_refactoring(self):
        """リファクタリングプロンプトのフォーマット"""
        result = PromptTemplate.format(
            PromptType.REFACTORING, language="java", code="public class Test {}"
        )
        assert "java" in result
        assert "public class Test" in result
        assert "リファクタリング" in result

    def test_format_missing_required_variable(self):
        """必須変数が不足している場合"""
        with pytest.raises(ValueError) as exc_info:
            PromptTemplate.format(PromptType.CODE_COMPLETION)
        assert "Missing required template variable" in str(exc_info.value)

    def test_get_available_types(self):
        """利用可能なプロンプトタイプの取得"""
        types = PromptTemplate.get_available_types()
        assert "general" in types
        assert "code_completion" in types
        assert "code_explanation" in types
        assert "code_review" in types
        assert "bug_fix" in types
        assert "refactoring" in types
        assert len(types) == 6


class TestDetectLanguage:
    """detect_language関数のテスト"""

    def test_detect_python(self):
        """Pythonコードの検出"""
        code = """
def hello():
    print("Hello")
"""
        assert detect_language(code) == "python"

    def test_detect_javascript(self):
        """JavaScriptコードの検出"""
        code = """
const hello = () => {
    console.log("Hello");
};
"""
        assert detect_language(code) == "javascript"

    def test_detect_java(self):
        """Javaコードの検出"""
        code = """
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello");
    }
}
"""
        assert detect_language(code) == "java"

    def test_detect_c(self):
        """C/C++コードの検出"""
        code = """
#include <stdio.h>
int main() {
    printf("Hello");
    return 0;
}
"""
        assert detect_language(code) == "c"

    def test_detect_go(self):
        """Goコードの検出"""
        code = """
package main
func main() {
    println("Hello")
}
"""
        assert detect_language(code) == "go"

    def test_detect_rust(self):
        """Rustコードの検出"""
        code = """
fn main() {
    println!("Hello");
}
"""
        assert detect_language(code) == "rust"

    def test_detect_ruby(self):
        """Rubyコードの検出"""
        code = """
def hello
    puts "Hello"
end
"""
        assert detect_language(code) == "ruby"

    def test_detect_unknown(self):
        """未知の言語"""
        code = "some random text"
        assert detect_language(code) == "unknown"
