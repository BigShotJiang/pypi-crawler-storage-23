"""WebSearchSkill のユニットテスト"""

import pytest
from unittest.mock import patch, MagicMock, AsyncMock

from app.skills.web_search import WebSearchSkill, SearchResultItem
from app.skills.base import SkillStatus


@pytest.fixture
def skill():
    """WebSearchSkill インスタンスを作成"""
    return WebSearchSkill(timeout=10, max_results=10)


class TestWebSearchSkillProperties:
    """WebSearchSkill プロパティのテスト"""

    def test_name(self, skill):
        """スキル名の確認"""
        assert skill.name == "web_search"

    def test_description(self, skill):
        """説明の確認"""
        assert "Web" in skill.description or "検索" in skill.description

    def test_get_actions(self, skill):
        """アクション一覧の確認"""
        actions = skill.get_actions()
        action_names = [a["name"] for a in actions]
        assert "search" in action_names
        assert "search_news" in action_names
        assert "fetch_url" in action_names


class TestWebSearchCleanHtml:
    """_clean_html メソッドのテスト"""

    def test_clean_html_tags(self, skill):
        """HTMLタグの除去"""
        html = "<p>Hello <strong>World</strong></p>"
        result = skill._clean_html(html)
        assert result == "Hello World"

    def test_clean_html_entities(self, skill):
        """HTMLエンティティのデコード"""
        html = "&amp; &lt; &gt; &quot; &#39;"
        result = skill._clean_html(html)
        assert result == "& < > \" '"

    def test_clean_html_whitespace(self, skill):
        """余分な空白の除去"""
        html = "Hello    World   Test"
        result = skill._clean_html(html)
        assert result == "Hello World Test"


class TestWebSearchSearch:
    """search アクションのテスト"""

    @pytest.mark.asyncio
    async def test_search_missing_query(self, skill):
        """クエリ未指定"""
        result = await skill.execute("search", {})
        assert result.status == SkillStatus.ERROR
        assert "required" in result.error.lower()

    @pytest.mark.asyncio
    async def test_search_success_mocked(self, skill):
        """検索成功（モック）"""
        mock_results = [
            SearchResultItem(
                title="Test Result 1",
                url="https://example.com/1",
                snippet="This is test snippet 1"
            ),
            SearchResultItem(
                title="Test Result 2",
                url="https://example.com/2",
                snippet="This is test snippet 2"
            ),
        ]

        with patch.object(skill, '_search_duckduckgo', return_value=mock_results):
            result = await skill.execute("search", {"query": "test query"})
            assert result.status == SkillStatus.SUCCESS
            assert result.data["count"] == 2
            assert result.data["query"] == "test query"
            assert len(result.data["results"]) == 2
            assert result.data["results"][0]["title"] == "Test Result 1"

    @pytest.mark.asyncio
    async def test_search_with_num_results(self, skill):
        """結果数指定での検索（モック）"""
        mock_results = [
            SearchResultItem(title=f"Result {i}", url=f"https://example.com/{i}", snippet="")
            for i in range(3)
        ]

        with patch.object(skill, '_search_duckduckgo', return_value=mock_results) as mock_search:
            result = await skill.execute("search", {
                "query": "test",
                "num_results": 3
            })
            assert result.status == SkillStatus.SUCCESS
            # _search_duckduckgoが正しいnum_resultsで呼ばれたことを確認
            mock_search.assert_called_once()
            call_args = mock_search.call_args
            assert call_args[1]["num_results"] == 3

    @pytest.mark.asyncio
    async def test_search_with_region(self, skill):
        """地域指定での検索（モック）"""
        mock_results = []

        with patch.object(skill, '_search_duckduckgo', return_value=mock_results) as mock_search:
            await skill.execute("search", {
                "query": "test",
                "region": "us-en"
            })
            mock_search.assert_called_once()
            call_args = mock_search.call_args
            assert call_args[1]["region"] == "us-en"

    @pytest.mark.asyncio
    async def test_search_error(self, skill):
        """検索エラー"""
        with patch.object(skill, '_search_duckduckgo', side_effect=Exception("Network error")):
            result = await skill.execute("search", {"query": "test"})
            assert result.status == SkillStatus.ERROR
            assert "Network error" in result.error

    @pytest.mark.asyncio
    async def test_search_max_results_limit(self):
        """最大結果数の制限"""
        skill = WebSearchSkill(max_results=5)
        mock_results = []

        with patch.object(skill, '_search_duckduckgo', return_value=mock_results) as mock_search:
            await skill.execute("search", {
                "query": "test",
                "num_results": 100  # max_resultsを超える値
            })
            mock_search.assert_called_once()
            call_args = mock_search.call_args
            # max_resultsで制限される
            assert call_args[1]["num_results"] == 5


class TestWebSearchSearchNews:
    """search_news アクションのテスト"""

    @pytest.mark.asyncio
    async def test_search_news_missing_query(self, skill):
        """クエリ未指定"""
        result = await skill.execute("search_news", {})
        assert result.status == SkillStatus.ERROR

    @pytest.mark.asyncio
    async def test_search_news_success_mocked(self, skill):
        """ニュース検索成功（モック）"""
        mock_results = [
            SearchResultItem(
                title="News Article 1",
                url="https://news.example.com/1",
                snippet="Breaking news..."
            ),
        ]

        with patch.object(skill, '_search_duckduckgo', return_value=mock_results) as mock_search:
            result = await skill.execute("search_news", {"query": "technology"})
            assert result.status == SkillStatus.SUCCESS
            # ニュース検索では「ニュース」が付加される
            call_args = mock_search.call_args
            assert "ニュース" in call_args[1]["query"]


class TestWebSearchFetchUrl:
    """fetch_url アクションのテスト"""

    @pytest.mark.asyncio
    async def test_fetch_url_missing_url(self, skill):
        """URL未指定"""
        result = await skill.execute("fetch_url", {})
        assert result.status == SkillStatus.ERROR
        assert "required" in result.error.lower()

    @pytest.mark.asyncio
    async def test_fetch_url_success_mocked(self, skill):
        """URL取得成功（モック）"""
        mock_html = "<html><body><p>Hello World</p></body></html>"

        with patch.object(skill, '_make_request', return_value=mock_html):
            result = await skill.execute("fetch_url", {
                "url": "https://example.com"
            })
            assert result.status == SkillStatus.SUCCESS
            assert "Hello World" in result.data["content"]
            assert result.data["url"] == "https://example.com"

    @pytest.mark.asyncio
    async def test_fetch_url_removes_script_tags(self, skill):
        """scriptタグの除去"""
        mock_html = """
        <html>
            <body>
                <script>var x = 1;</script>
                <p>Content</p>
                <script type="text/javascript">console.log('test');</script>
            </body>
        </html>
        """

        with patch.object(skill, '_make_request', return_value=mock_html):
            result = await skill.execute("fetch_url", {"url": "https://example.com"})
            assert result.status == SkillStatus.SUCCESS
            assert "var x" not in result.data["content"]
            assert "console.log" not in result.data["content"]
            assert "Content" in result.data["content"]

    @pytest.mark.asyncio
    async def test_fetch_url_removes_style_tags(self, skill):
        """styleタグの除去"""
        mock_html = """
        <html>
            <head><style>.class { color: red; }</style></head>
            <body><p>Content</p></body>
        </html>
        """

        with patch.object(skill, '_make_request', return_value=mock_html):
            result = await skill.execute("fetch_url", {"url": "https://example.com"})
            assert result.status == SkillStatus.SUCCESS
            assert "color: red" not in result.data["content"]

    @pytest.mark.asyncio
    async def test_fetch_url_max_length(self, skill):
        """最大長制限"""
        mock_html = "<p>" + "A" * 10000 + "</p>"

        with patch.object(skill, '_make_request', return_value=mock_html):
            result = await skill.execute("fetch_url", {
                "url": "https://example.com",
                "max_length": 100
            })
            assert result.status == SkillStatus.SUCCESS
            assert len(result.data["content"]) <= 120  # truncated文字列を含む
            assert "truncated" in result.data["content"]

    @pytest.mark.asyncio
    async def test_fetch_url_error(self, skill):
        """URL取得エラー"""
        with patch.object(skill, '_make_request', side_effect=Exception("Connection failed")):
            result = await skill.execute("fetch_url", {"url": "https://example.com"})
            assert result.status == SkillStatus.ERROR
            assert "Connection failed" in result.error


class TestWebSearchUnknownAction:
    """不明なアクションのテスト"""

    @pytest.mark.asyncio
    async def test_unknown_action(self, skill):
        """不明なアクション"""
        result = await skill.execute("unknown_action", {})
        assert result.status == SkillStatus.ERROR
        assert "Unknown action" in result.error


class TestSearchResultItem:
    """SearchResultItem のテスト"""

    def test_search_result_item_creation(self):
        """SearchResultItemの生成"""
        item = SearchResultItem(
            title="Test Title",
            url="https://example.com",
            snippet="Test snippet"
        )
        assert item.title == "Test Title"
        assert item.url == "https://example.com"
        assert item.snippet == "Test snippet"
