"""スキル基底クラスとSkillManagerのユニットテスト"""

import pytest
from unittest.mock import AsyncMock, patch

from app.skills.base import BaseSkill, SkillResult, SkillStatus, SkillInfo


class TestSkillResult:
    """SkillResult のテスト"""

    def test_success_result(self):
        """成功結果の生成"""
        result = SkillResult.success(data={"key": "value"}, message="OK")
        assert result.status == SkillStatus.SUCCESS
        assert result.data == {"key": "value"}
        assert result.message == "OK"
        assert result.error is None

    def test_success_result_default_message(self):
        """成功結果のデフォルトメッセージ"""
        result = SkillResult.success()
        assert result.status == SkillStatus.SUCCESS
        assert result.message == "OK"
        assert result.data is None

    def test_error_result(self):
        """エラー結果の生成"""
        result = SkillResult.error(error="Something went wrong", message="Error occurred")
        assert result.status == SkillStatus.ERROR
        assert result.error == "Something went wrong"
        assert result.message == "Error occurred"
        assert result.data is None

    def test_to_dict_success(self):
        """成功結果の辞書変換"""
        result = SkillResult.success(data={"key": "value"}, message="OK")
        d = result.to_dict()
        assert d["status"] == "success"
        assert d["message"] == "OK"
        assert d["data"] == {"key": "value"}
        assert "error" not in d

    def test_to_dict_error(self):
        """エラー結果の辞書変換"""
        result = SkillResult.error(error="Error!", message="Failed")
        d = result.to_dict()
        assert d["status"] == "error"
        assert d["message"] == "Failed"
        assert d["error"] == "Error!"
        assert "data" not in d

    def test_partial_status(self):
        """部分成功ステータス"""
        result = SkillResult(
            status=SkillStatus.PARTIAL,
            data={"partial": True},
            message="Partial success"
        )
        assert result.status == SkillStatus.PARTIAL
        assert result.to_dict()["status"] == "partial"


class TestSkillInfo:
    """SkillInfo のテスト"""

    def test_skill_info_creation(self):
        """SkillInfo の生成"""
        info = SkillInfo(
            name="test_skill",
            description="A test skill",
            actions=[{"name": "action1", "description": "Action 1"}]
        )
        assert info.name == "test_skill"
        assert info.description == "A test skill"
        assert len(info.actions) == 1
        assert info.actions[0]["name"] == "action1"

    def test_skill_info_default_actions(self):
        """SkillInfo のデフォルトアクション"""
        info = SkillInfo(name="test", description="Test")
        assert info.actions == []


class DummySkill(BaseSkill):
    """テスト用ダミースキル"""

    @property
    def name(self) -> str:
        return "dummy"

    @property
    def description(self) -> str:
        return "A dummy skill for testing"

    def get_actions(self) -> list[dict]:
        return [
            {"name": "action1", "description": "First action", "parameters": {}},
            {"name": "action2", "description": "Second action", "parameters": {}},
        ]

    async def execute(self, action: str, params: dict) -> SkillResult:
        if action == "action1":
            return SkillResult.success(data={"action": "action1"}, message="Action 1 executed")
        elif action == "action2":
            return SkillResult.success(data={"action": "action2"}, message="Action 2 executed")
        else:
            return SkillResult.error(error=f"Unknown action: {action}", message="Invalid action")


class TestBaseSkill:
    """BaseSkill のテスト"""

    def test_skill_properties(self):
        """スキルプロパティの確認"""
        skill = DummySkill()
        assert skill.name == "dummy"
        assert skill.description == "A dummy skill for testing"

    def test_get_actions(self):
        """アクション一覧の取得"""
        skill = DummySkill()
        actions = skill.get_actions()
        assert len(actions) == 2
        assert actions[0]["name"] == "action1"
        assert actions[1]["name"] == "action2"

    @pytest.mark.asyncio
    async def test_execute_valid_action(self):
        """有効なアクションの実行"""
        skill = DummySkill()
        result = await skill.execute("action1", {})
        assert result.status == SkillStatus.SUCCESS
        assert result.data["action"] == "action1"

    @pytest.mark.asyncio
    async def test_execute_invalid_action(self):
        """無効なアクションの実行"""
        skill = DummySkill()
        result = await skill.execute("unknown", {})
        assert result.status == SkillStatus.ERROR
        assert "Unknown action" in result.error

    def test_get_info(self):
        """スキル情報の取得"""
        skill = DummySkill()
        info = skill.get_info()
        assert isinstance(info, SkillInfo)
        assert info.name == "dummy"
        assert info.description == "A dummy skill for testing"
        assert len(info.actions) == 2
