"""レート制限のテスト"""

import pytest
from unittest.mock import patch, MagicMock, AsyncMock
from fastapi.testclient import TestClient

from app.main import create_app
from app.rate_limiter import limiter


@pytest.fixture
def client_with_rate_limit():
    """レート制限付きのテスト用クライアント"""
    # inference_service.chatの戻り値をモック
    mock_chat_result = {
        "text": "Test response",
        "usage": {"prompt_tokens": 5, "completion_tokens": 5, "total_tokens": 10},
        "elapsed": 0.1,
    }

    # 同時実行数制限をモック（即座にコンテキストを返す）
    mock_concurrency_limiter = MagicMock()
    mock_concurrency_limiter.__aenter__ = AsyncMock(return_value=mock_concurrency_limiter)
    mock_concurrency_limiter.__aexit__ = AsyncMock(return_value=None)

    # レート制限カウンターをリセット
    limiter.reset()

    # レート制限を有効化し、テスト用の厳しい制限を設定
    original_enabled = limiter.enabled
    limiter.enabled = True

    with patch("app.main.ModelLoader.load"):
        with patch("app.router_openai.inference_service") as mock_inference:
            mock_inference.chat.return_value = mock_chat_result
            with patch("app.router_openai.concurrency_limiter", mock_concurrency_limiter):
                app = create_app()
                with TestClient(app) as client:
                    yield client

    # 元に戻す
    limiter.enabled = original_enabled


@pytest.fixture
def client_without_rate_limit():
    """レート制限なしのテスト用クライアント"""
    # inference_service.chatの戻り値をモック
    mock_chat_result = {
        "text": "Test response",
        "usage": {"prompt_tokens": 5, "completion_tokens": 5, "total_tokens": 10},
        "elapsed": 0.1,
    }

    # 同時実行数制限をモック（即座にコンテキストを返す）
    mock_concurrency_limiter = MagicMock()
    mock_concurrency_limiter.__aenter__ = AsyncMock(return_value=mock_concurrency_limiter)
    mock_concurrency_limiter.__aexit__ = AsyncMock(return_value=None)

    # レート制限カウンターをリセット
    limiter.reset()

    # レート制限を無効化
    original_enabled = limiter.enabled
    limiter.enabled = False

    with patch("app.main.ModelLoader.load"):
        with patch("app.router_openai.inference_service") as mock_inference:
            mock_inference.chat.return_value = mock_chat_result
            with patch("app.router_openai.concurrency_limiter", mock_concurrency_limiter):
                app = create_app()
                with TestClient(app) as client:
                    yield client

    # 元に戻す
    limiter.enabled = original_enabled


class TestRateLimit:
    """レート制限機能のテスト"""

    def test_rate_limit_not_exceeded(self, client_with_rate_limit):
        """レート制限内でのリクエスト"""
        # 最初のリクエスト
        response1 = client_with_rate_limit.post(
            "/v1/chat/completions",
            json={
                "messages": [{"role": "user", "content": "Hello"}],
                "stream": False,
            },
        )
        assert response1.status_code == 200

        # 2回目のリクエスト
        response2 = client_with_rate_limit.post(
            "/v1/chat/completions",
            json={
                "messages": [{"role": "user", "content": "Hello again"}],
                "stream": False,
            },
        )
        assert response2.status_code == 200

    def test_rate_limit_exceeded(self, client_with_rate_limit):
        """レート制限を超えた場合"""
        # デフォルト制限数（10回）までリクエスト
        for i in range(10):
            response = client_with_rate_limit.post(
                "/v1/chat/completions",
                json={
                    "messages": [{"role": "user", "content": f"Request {i}"}],
                    "stream": False,
                },
            )
            # 最初の10回は成功するはず
            assert response.status_code == 200

        # 11回目はレート制限エラー
        response = client_with_rate_limit.post(
            "/v1/chat/completions",
            json={
                "messages": [{"role": "user", "content": "This should fail"}],
                "stream": False,
            },
        )
        # レート制限エラーは429 Too Many Requests
        assert response.status_code == 429

    def test_rate_limit_disabled(self, client_without_rate_limit):
        """レート制限が無効の場合"""
        # 多数のリクエストを送信
        for i in range(10):
            response = client_without_rate_limit.post(
                "/v1/chat/completions",
                json={
                    "messages": [{"role": "user", "content": f"Request {i}"}],
                    "stream": False,
                },
            )
            # レート制限が無効なので全て成功
            assert response.status_code == 200


class TestRateLimitHeaders:
    """レート制限のヘッダー情報テスト"""

    def test_rate_limit_headers_present(self, client_with_rate_limit):
        """レート制限ヘッダーが含まれているか確認"""
        response = client_with_rate_limit.post(
            "/v1/chat/completions",
            json={
                "messages": [{"role": "user", "content": "Hello"}],
                "stream": False,
            },
        )

        # slowapiは通常、レート制限情報をヘッダーに含める
        # X-RateLimit-Limit, X-RateLimit-Remaining, X-RateLimit-Reset など
        # 実装によって異なるため、基本的な動作確認のみ
        assert response.status_code == 200
