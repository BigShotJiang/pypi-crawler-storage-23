"""router_skills のユニットテスト"""

import pytest
from unittest.mock import patch, MagicMock, AsyncMock
from fastapi.testclient import TestClient

from app.skills.base import BaseSkill, SkillResult, SkillStatus
from app.skills.skill_manager import SkillManager


class MockSkill(BaseSkill):
    """テスト用モックスキル"""

    def __init__(self, skill_name: str = "mock_skill"):
        self._name = skill_name

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return f"Mock skill: {self._name}"

    def get_actions(self) -> list[dict]:
        return [
            {
                "name": "test_action",
                "description": "Test action",
                "parameters": {"param1": {"type": "string"}}
            },
        ]

    async def execute(self, action: str, params: dict) -> SkillResult:
        if action == "test_action":
            return SkillResult.success(
                data={"result": "ok", "params": params},
                message="Success"
            )
        return SkillResult.error(f"Unknown action: {action}", "Error")


@pytest.fixture
def setup_skill_manager():
    """SkillManagerをリセットしてテスト用スキルを登録"""
    # シングルトンをリセット
    SkillManager._instance = None

    # 新しいインスタンスを取得（グローバルのskill_managerも更新される）
    from app.skills.skill_manager import skill_manager

    # テスト用スキルを登録
    mock_skill = MockSkill("test_skill")
    skill_manager.register(mock_skill, enabled=True)

    disabled_skill = MockSkill("disabled_skill")
    skill_manager.register(disabled_skill, enabled=False)

    yield skill_manager

    # クリーンアップ
    SkillManager._instance = None


@pytest.fixture
def client(setup_skill_manager):
    """テスト用クライアント"""
    with patch("app.main.ModelLoader.load"):
        with patch("app.router_skills.init_skills"):
            from app.main import create_app
            app = create_app()
            with TestClient(app) as client:
                yield client


class TestSkillsListEndpoint:
    """GET /ixv/skills のテスト"""

    def test_list_skills(self, client, setup_skill_manager):
        """スキル一覧取得"""
        response = client.get("/ixv/skills")
        assert response.status_code == 200
        data = response.json()
        assert "skills" in data
        assert "count" in data
        assert data["count"] >= 2  # test_skill と disabled_skill


class TestSkillInfoEndpoint:
    """GET /ixv/skills/{skill_name} のテスト"""

    def test_get_skill_info(self, client):
        """スキル詳細取得"""
        response = client.get("/ixv/skills/test_skill")
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "test_skill"
        assert "description" in data
        assert "actions" in data
        assert "enabled" in data

    def test_get_skill_info_not_found(self, client):
        """存在しないスキル"""
        response = client.get("/ixv/skills/nonexistent_skill")
        assert response.status_code == 404


class TestSkillActionsEndpoint:
    """GET /ixv/skills/{skill_name}/actions のテスト"""

    def test_get_skill_actions(self, client):
        """スキルアクション一覧取得"""
        response = client.get("/ixv/skills/test_skill/actions")
        assert response.status_code == 200
        data = response.json()
        assert data["skill"] == "test_skill"
        assert "actions" in data
        assert len(data["actions"]) >= 1

    def test_get_skill_actions_not_found(self, client):
        """存在しないスキルのアクション"""
        response = client.get("/ixv/skills/nonexistent_skill/actions")
        assert response.status_code == 404


class TestExecuteSkillEndpoint:
    """POST /ixv/skills/execute のテスト"""

    def test_execute_skill_success(self, client):
        """スキル実行成功"""
        response = client.post("/ixv/skills/execute", json={
            "skill": "test_skill",
            "action": "test_action",
            "params": {"param1": "value1"}
        })
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "success"
        assert data["data"]["result"] == "ok"
        assert data["data"]["params"]["param1"] == "value1"

    def test_execute_skill_not_found(self, client):
        """存在しないスキルの実行"""
        response = client.post("/ixv/skills/execute", json={
            "skill": "nonexistent_skill",
            "action": "test_action",
            "params": {}
        })
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "error"
        assert "not found" in data["error"].lower()

    def test_execute_skill_disabled(self, client):
        """無効化されたスキルの実行"""
        response = client.post("/ixv/skills/execute", json={
            "skill": "disabled_skill",
            "action": "test_action",
            "params": {}
        })
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "error"
        assert "disabled" in data["error"].lower()

    def test_execute_skill_unknown_action(self, client):
        """不明なアクションの実行"""
        response = client.post("/ixv/skills/execute", json={
            "skill": "test_skill",
            "action": "unknown_action",
            "params": {}
        })
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "error"


class TestExecuteSkillActionEndpoint:
    """POST /ixv/skills/{skill_name}/{action} のテスト"""

    def test_execute_skill_action_success(self, client):
        """RESTful API でスキル実行"""
        response = client.post(
            "/ixv/skills/test_skill/test_action",
            json={"param1": "value1"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "success"


class TestEnableDisableEndpoints:
    """スキル有効/無効化エンドポイントのテスト"""

    def test_enable_skill(self, client, setup_skill_manager):
        """スキル有効化"""
        response = client.post("/ixv/skills/disabled_skill/enable")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "success"
        assert data["enabled"] is True
        assert setup_skill_manager.is_enabled("disabled_skill") is True

    def test_enable_nonexistent_skill(self, client):
        """存在しないスキルの有効化"""
        response = client.post("/ixv/skills/nonexistent/enable")
        assert response.status_code == 404

    def test_disable_skill(self, client, setup_skill_manager):
        """スキル無効化"""
        response = client.post("/ixv/skills/test_skill/disable")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "success"
        assert data["enabled"] is False
        assert setup_skill_manager.is_enabled("test_skill") is False

    def test_disable_nonexistent_skill(self, client):
        """存在しないスキルの無効化"""
        response = client.post("/ixv/skills/nonexistent/disable")
        assert response.status_code == 404


class TestSkillStatusEndpoint:
    """GET /ixv/skills/{skill_name}/status のテスト"""

    def test_get_skill_status_enabled(self, client):
        """有効なスキルのステータス取得"""
        response = client.get("/ixv/skills/test_skill/status")
        assert response.status_code == 200
        data = response.json()
        assert data["skill"] == "test_skill"
        assert data["enabled"] is True
        assert "description" in data

    def test_get_skill_status_disabled(self, client, setup_skill_manager):
        """無効なスキルのステータス取得"""
        # 前のテストで有効化されている可能性があるので、再度無効化
        setup_skill_manager.disable_skill("disabled_skill")

        response = client.get("/ixv/skills/disabled_skill/status")
        assert response.status_code == 200
        data = response.json()
        assert data["enabled"] is False

    def test_get_skill_status_not_found(self, client):
        """存在しないスキルのステータス取得"""
        response = client.get("/ixv/skills/nonexistent/status")
        assert response.status_code == 404


class TestInitSkills:
    """init_skills 関数のテスト"""

    def test_init_skills_registers_base_skills(self):
        """基本スキルが登録される"""
        # シングルトンをリセット
        SkillManager._instance = None

        with patch("app.router_skills.config") as mock_config:
            # 設定をモック
            mock_config.skills_base_dir = None
            mock_config.skills_max_file_size = 1024 * 1024
            mock_config.skills_exec_timeout = 30
            mock_config.skills_working_dir = None
            mock_config.skills_rag_store_path = None
            mock_config.skills_rag_chunk_size = 500
            mock_config.skills_rag_chunk_overlap = 50
            mock_config.skills_web_search_timeout = 10
            mock_config.skills_web_search_max_results = 10
            mock_config.skills_enabled_list = ""
            mock_config.skills_disabled_list = ""

            # モジュールを再インポートして新しいシングルトンを使用
            import importlib
            import app.router_skills
            importlib.reload(app.router_skills)

            from app.router_skills import init_skills
            from app.skills.skill_manager import skill_manager

            init_skills()

            # 基本スキルが登録されていることを確認
            skills = skill_manager.list_skills()
            skill_names = [s["name"] for s in skills]

            assert "file_ops" in skill_names
            assert "code_exec" in skill_names
            assert "git_ops" in skill_names
            assert "rag" in skill_names
            assert "web_search" in skill_names

        # クリーンアップ
        SkillManager._instance = None


class TestGetSkillEnabledState:
    """_get_skill_enabled_state 関数のテスト"""

    def test_enabled_by_default(self):
        """デフォルトで有効"""
        with patch("app.router_skills.config") as mock_config:
            mock_config.skills_enabled_list = ""
            mock_config.skills_disabled_list = ""

            from app.router_skills import _get_skill_enabled_state
            assert _get_skill_enabled_state("any_skill") is True

    def test_enabled_list_filters(self):
        """有効リストでフィルタリング"""
        with patch("app.router_skills.config") as mock_config:
            mock_config.skills_enabled_list = "file_ops,code_exec"
            mock_config.skills_disabled_list = ""

            from app.router_skills import _get_skill_enabled_state
            assert _get_skill_enabled_state("file_ops") is True
            assert _get_skill_enabled_state("code_exec") is True
            assert _get_skill_enabled_state("git_ops") is False

    def test_disabled_list_filters(self):
        """無効リストでフィルタリング"""
        with patch("app.router_skills.config") as mock_config:
            mock_config.skills_enabled_list = ""
            mock_config.skills_disabled_list = "git_ops,rag"

            from app.router_skills import _get_skill_enabled_state
            assert _get_skill_enabled_state("file_ops") is True
            assert _get_skill_enabled_state("git_ops") is False
            assert _get_skill_enabled_state("rag") is False
