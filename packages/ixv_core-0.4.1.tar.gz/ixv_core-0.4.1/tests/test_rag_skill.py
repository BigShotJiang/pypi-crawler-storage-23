"""RAGSkill のユニットテスト"""

import tempfile
import pytest
from pathlib import Path

from app.skills.rag import RAGSkill, SimpleVectorStore, Document, SearchResult
from app.skills.base import SkillStatus


@pytest.fixture
def temp_dir():
    """一時ディレクトリを作成"""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def skill(temp_dir):
    """RAGSkill インスタンスを作成"""
    store_path = temp_dir / "rag_store.json"
    return RAGSkill(store_path=str(store_path), chunk_size=100, chunk_overlap=10)


class TestSimpleVectorStore:
    """SimpleVectorStore のテスト"""

    def test_add_and_get_document(self, temp_dir):
        """ドキュメントの追加と取得"""
        store_path = temp_dir / "store.json"
        store = SimpleVectorStore(store_path)

        doc = Document(
            id="test-1",
            content="This is test content",
            metadata={"source": "test"}
        )
        store.add(doc)

        retrieved = store.get("test-1")
        assert retrieved is not None
        assert retrieved.content == "This is test content"
        assert retrieved.metadata["source"] == "test"

    def test_delete_document(self, temp_dir):
        """ドキュメントの削除"""
        store_path = temp_dir / "store.json"
        store = SimpleVectorStore(store_path)

        doc = Document(id="to-delete", content="Delete me", metadata={})
        store.add(doc)
        assert store.get("to-delete") is not None

        result = store.delete("to-delete")
        assert result is True
        assert store.get("to-delete") is None

    def test_delete_nonexistent(self, temp_dir):
        """存在しないドキュメントの削除"""
        store = SimpleVectorStore()
        result = store.delete("nonexistent")
        assert result is False

    def test_list_all(self, temp_dir):
        """全ドキュメントの取得"""
        store = SimpleVectorStore()
        store.add(Document(id="1", content="First", metadata={}))
        store.add(Document(id="2", content="Second", metadata={}))

        docs = store.list_all()
        assert len(docs) == 2

    def test_search_keyword(self, temp_dir):
        """キーワード検索"""
        store = SimpleVectorStore()
        store.add(Document(id="1", content="Python programming language", metadata={}))
        store.add(Document(id="2", content="JavaScript is popular", metadata={}))
        store.add(Document(id="3", content="Python is great for AI", metadata={}))

        results = store.search_keyword("Python", limit=5)
        assert len(results) == 2
        # Pythonを含むドキュメントのみ返される
        doc_ids = [r.document.id for r in results]
        assert "1" in doc_ids
        assert "3" in doc_ids

    def test_search_keyword_no_match(self, temp_dir):
        """マッチしないキーワード検索"""
        store = SimpleVectorStore()
        store.add(Document(id="1", content="Hello world", metadata={}))

        results = store.search_keyword("Python", limit=5)
        assert len(results) == 0

    def test_clear(self, temp_dir):
        """ストアのクリア"""
        store = SimpleVectorStore()
        store.add(Document(id="1", content="First", metadata={}))
        store.add(Document(id="2", content="Second", metadata={}))

        store.clear()
        assert len(store.list_all()) == 0

    def test_persistence(self, temp_dir):
        """永続化のテスト"""
        store_path = temp_dir / "persist.json"

        # 保存
        store1 = SimpleVectorStore(store_path)
        store1.add(Document(id="persist", content="Persistent data", metadata={}))

        # 別インスタンスで読み込み
        store2 = SimpleVectorStore(store_path)
        doc = store2.get("persist")
        assert doc is not None
        assert doc.content == "Persistent data"


class TestRAGSkillProperties:
    """RAGSkill プロパティのテスト"""

    def test_name(self, skill):
        """スキル名の確認"""
        assert skill.name == "rag"

    def test_description(self, skill):
        """説明の確認"""
        assert "RAG" in skill.description or "ドキュメント" in skill.description

    def test_get_actions(self, skill):
        """アクション一覧の確認"""
        actions = skill.get_actions()
        action_names = [a["name"] for a in actions]
        assert "index_file" in action_names
        assert "index_directory" in action_names
        assert "index_text" in action_names
        assert "search" in action_names
        assert "get_context" in action_names
        assert "list_documents" in action_names
        assert "delete_document" in action_names
        assert "clear_index" in action_names


class TestRAGIndexFile:
    """index_file アクションのテスト"""

    @pytest.mark.asyncio
    async def test_index_file_success(self, skill, temp_dir):
        """ファイルインデックス成功"""
        test_file = temp_dir / "test.txt"
        test_file.write_text("This is test content for indexing.")

        result = await skill.execute("index_file", {"path": str(test_file)})
        assert result.status == SkillStatus.SUCCESS
        assert "chunks" in result.data
        assert result.data["chunks"] >= 1

    @pytest.mark.asyncio
    async def test_index_file_with_metadata(self, skill, temp_dir):
        """メタデータ付きでファイルインデックス"""
        test_file = temp_dir / "meta.txt"
        test_file.write_text("Content with metadata")

        result = await skill.execute("index_file", {
            "path": str(test_file),
            "metadata": {"author": "test"}
        })
        assert result.status == SkillStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_index_file_not_found(self, skill, temp_dir):
        """存在しないファイル"""
        result = await skill.execute("index_file", {
            "path": str(temp_dir / "nonexistent.txt")
        })
        assert result.status == SkillStatus.ERROR

    @pytest.mark.asyncio
    async def test_index_file_missing_path(self, skill):
        """パス未指定"""
        result = await skill.execute("index_file", {})
        assert result.status == SkillStatus.ERROR


class TestRAGIndexDirectory:
    """index_directory アクションのテスト"""

    @pytest.mark.asyncio
    async def test_index_directory_success(self, skill, temp_dir):
        """ディレクトリインデックス成功"""
        (temp_dir / "doc1.md").write_text("# Document 1\nContent here")
        (temp_dir / "doc2.md").write_text("# Document 2\nMore content")

        result = await skill.execute("index_directory", {
            "path": str(temp_dir),
            "pattern": "*.md"
        })
        assert result.status == SkillStatus.SUCCESS
        assert result.data["files"] == 2

    @pytest.mark.asyncio
    async def test_index_directory_not_found(self, skill, temp_dir):
        """存在しないディレクトリ"""
        result = await skill.execute("index_directory", {
            "path": str(temp_dir / "nonexistent")
        })
        assert result.status == SkillStatus.ERROR


class TestRAGIndexText:
    """index_text アクションのテスト"""

    @pytest.mark.asyncio
    async def test_index_text_success(self, skill):
        """テキストインデックス成功"""
        result = await skill.execute("index_text", {
            "text": "This is manually indexed text content.",
            "source": "manual_input"
        })
        assert result.status == SkillStatus.SUCCESS
        assert "chunks" in result.data

    @pytest.mark.asyncio
    async def test_index_text_missing_text(self, skill):
        """テキスト未指定"""
        result = await skill.execute("index_text", {})
        assert result.status == SkillStatus.ERROR


class TestRAGSearch:
    """search アクションのテスト"""

    @pytest.mark.asyncio
    async def test_search_success(self, skill, temp_dir):
        """検索成功"""
        # インデックス作成
        test_file = temp_dir / "search_test.txt"
        test_file.write_text("Python is a great programming language for AI and ML.")
        await skill.execute("index_file", {"path": str(test_file)})

        # 検索
        result = await skill.execute("search", {"query": "Python programming"})
        assert result.status == SkillStatus.SUCCESS
        assert "results" in result.data

    @pytest.mark.asyncio
    async def test_search_no_results(self, skill):
        """検索結果なし"""
        result = await skill.execute("search", {"query": "nonexistent term xyz"})
        assert result.status == SkillStatus.SUCCESS
        assert result.data["count"] == 0

    @pytest.mark.asyncio
    async def test_search_missing_query(self, skill):
        """クエリ未指定"""
        result = await skill.execute("search", {})
        assert result.status == SkillStatus.ERROR

    @pytest.mark.asyncio
    async def test_search_with_limit(self, skill, temp_dir):
        """件数制限付き検索"""
        # 複数ドキュメントをインデックス
        for i in range(5):
            (temp_dir / f"doc{i}.txt").write_text(f"Python document number {i}")
        await skill.execute("index_directory", {
            "path": str(temp_dir),
            "pattern": "*.txt"
        })

        result = await skill.execute("search", {
            "query": "Python",
            "limit": 2
        })
        assert result.status == SkillStatus.SUCCESS
        assert len(result.data["results"]) <= 2


class TestRAGGetContext:
    """get_context アクションのテスト"""

    @pytest.mark.asyncio
    async def test_get_context_success(self, skill, temp_dir):
        """コンテキスト取得成功"""
        test_file = temp_dir / "context_test.txt"
        test_file.write_text("Machine learning is a subset of artificial intelligence.")
        await skill.execute("index_file", {"path": str(test_file)})

        result = await skill.execute("get_context", {"query": "machine learning"})
        assert result.status == SkillStatus.SUCCESS
        assert "context" in result.data
        assert "sources" in result.data

    @pytest.mark.asyncio
    async def test_get_context_with_limit(self, skill, temp_dir):
        """件数制限付きコンテキスト取得"""
        for i in range(5):
            (temp_dir / f"ml{i}.txt").write_text(f"ML document {i} about learning")
        await skill.execute("index_directory", {
            "path": str(temp_dir),
            "pattern": "*.txt"
        })

        result = await skill.execute("get_context", {
            "query": "learning",
            "limit": 2
        })
        assert result.status == SkillStatus.SUCCESS
        assert result.data["num_documents"] <= 2


class TestRAGListDocuments:
    """list_documents アクションのテスト"""

    @pytest.mark.asyncio
    async def test_list_documents_empty(self, skill):
        """空のインデックス"""
        result = await skill.execute("list_documents", {})
        assert result.status == SkillStatus.SUCCESS
        assert result.data["total_documents"] == 0

    @pytest.mark.asyncio
    async def test_list_documents_with_content(self, skill, temp_dir):
        """ドキュメントがある場合"""
        test_file = temp_dir / "list_test.txt"
        test_file.write_text("Content for listing")
        await skill.execute("index_file", {"path": str(test_file)})

        result = await skill.execute("list_documents", {})
        assert result.status == SkillStatus.SUCCESS
        assert result.data["total_documents"] >= 1


class TestRAGDeleteDocument:
    """delete_document アクションのテスト"""

    @pytest.mark.asyncio
    async def test_delete_document_success(self, skill, temp_dir):
        """ドキュメント削除成功"""
        await skill.execute("index_text", {
            "text": "Short text",
            "source": "test"
        })

        # ドキュメント一覧を取得してIDを確認
        list_result = await skill.execute("list_documents", {})
        assert list_result.data["total_documents"] >= 1

        # 検索してドキュメントIDを取得
        search_result = await skill.execute("search", {"query": "Short text"})
        if search_result.data["results"]:
            doc_id = search_result.data["results"][0]["id"]
            delete_result = await skill.execute("delete_document", {"doc_id": doc_id})
            assert delete_result.status == SkillStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_delete_document_not_found(self, skill):
        """存在しないドキュメントの削除"""
        result = await skill.execute("delete_document", {"doc_id": "nonexistent"})
        assert result.status == SkillStatus.ERROR

    @pytest.mark.asyncio
    async def test_delete_document_missing_id(self, skill):
        """ID未指定"""
        result = await skill.execute("delete_document", {})
        assert result.status == SkillStatus.ERROR


class TestRAGClearIndex:
    """clear_index アクションのテスト"""

    @pytest.mark.asyncio
    async def test_clear_index_success(self, skill, temp_dir):
        """インデックスクリア成功"""
        # ドキュメントを追加
        await skill.execute("index_text", {"text": "Content to clear"})
        list_result = await skill.execute("list_documents", {})
        assert list_result.data["total_documents"] >= 1

        # クリア
        result = await skill.execute("clear_index", {})
        assert result.status == SkillStatus.SUCCESS

        # 確認
        list_result = await skill.execute("list_documents", {})
        assert list_result.data["total_documents"] == 0


class TestRAGUnknownAction:
    """不明なアクションのテスト"""

    @pytest.mark.asyncio
    async def test_unknown_action(self, skill):
        """不明なアクション"""
        result = await skill.execute("unknown_action", {})
        assert result.status == SkillStatus.ERROR
        assert "Unknown action" in result.error
