"""GitOpsSkill のユニットテスト"""

import os
import tempfile
import pytest
from pathlib import Path
from unittest.mock import patch, AsyncMock

from app.skills.git_ops import GitOpsSkill
from app.skills.base import SkillStatus


@pytest.fixture
def temp_git_repo():
    """一時的なGitリポジトリを作成"""
    with tempfile.TemporaryDirectory() as tmpdir:
        repo_path = Path(tmpdir)
        # Gitリポジトリを初期化
        os.system(f"cd {repo_path} && git init -q")
        os.system(f"cd {repo_path} && git config user.email 'test@test.com'")
        os.system(f"cd {repo_path} && git config user.name 'Test User'")
        # 初期コミットを作成
        (repo_path / "README.md").write_text("# Test Repo")
        os.system(f"cd {repo_path} && git add . && git commit -q -m 'Initial commit'")
        yield repo_path


@pytest.fixture
def skill():
    """GitOpsSkill インスタンスを作成"""
    return GitOpsSkill(timeout=10)


@pytest.fixture
def skill_with_repo(temp_git_repo):
    """リポジトリパス指定のGitOpsSkill"""
    return GitOpsSkill(repo_path=str(temp_git_repo), timeout=10)


class TestGitOpsSkillProperties:
    """GitOpsSkill プロパティのテスト"""

    def test_name(self, skill):
        """スキル名の確認"""
        assert skill.name == "git_ops"

    def test_description(self, skill):
        """説明の確認"""
        assert "Git" in skill.description

    def test_get_actions(self, skill):
        """アクション一覧の確認"""
        actions = skill.get_actions()
        action_names = [a["name"] for a in actions]
        assert "status" in action_names
        assert "diff" in action_names
        assert "log" in action_names
        assert "branch" in action_names
        assert "checkout" in action_names
        assert "add" in action_names
        assert "commit" in action_names
        assert "push" in action_names
        assert "pull" in action_names
        assert "stash" in action_names
        assert "show" in action_names
        assert "blame" in action_names


class TestGitOpsStatus:
    """status アクションのテスト"""

    @pytest.mark.asyncio
    async def test_status_clean(self, skill_with_repo, temp_git_repo):
        """クリーンなリポジトリのステータス"""
        result = await skill_with_repo.execute("status", {"path": str(temp_git_repo)})
        assert result.status == SkillStatus.SUCCESS
        assert result.data["clean"] is True
        assert len(result.data["files"]) == 0

    @pytest.mark.asyncio
    async def test_status_with_changes(self, skill_with_repo, temp_git_repo):
        """変更があるリポジトリのステータス"""
        # 新しいファイルを追加
        (temp_git_repo / "new_file.txt").write_text("new content")

        result = await skill_with_repo.execute("status", {"path": str(temp_git_repo)})
        assert result.status == SkillStatus.SUCCESS
        assert result.data["clean"] is False
        assert len(result.data["files"]) > 0

    @pytest.mark.asyncio
    async def test_status_shows_branch(self, skill_with_repo, temp_git_repo):
        """現在のブランチを表示"""
        result = await skill_with_repo.execute("status", {"path": str(temp_git_repo)})
        assert result.status == SkillStatus.SUCCESS
        assert "branch" in result.data


class TestGitOpsDiff:
    """diff アクションのテスト"""

    @pytest.mark.asyncio
    async def test_diff_no_changes(self, skill_with_repo, temp_git_repo):
        """変更なしのdiff"""
        result = await skill_with_repo.execute("diff", {"path": str(temp_git_repo)})
        assert result.status == SkillStatus.SUCCESS
        assert result.data["output"] == ""

    @pytest.mark.asyncio
    async def test_diff_with_changes(self, skill_with_repo, temp_git_repo):
        """変更ありのdiff"""
        readme = temp_git_repo / "README.md"
        readme.write_text("# Test Repo\n\nModified content")

        result = await skill_with_repo.execute("diff", {"path": str(temp_git_repo)})
        assert result.status == SkillStatus.SUCCESS
        assert "Modified content" in result.data["output"]

    @pytest.mark.asyncio
    async def test_diff_staged(self, skill_with_repo, temp_git_repo):
        """ステージ済み変更のdiff"""
        readme = temp_git_repo / "README.md"
        readme.write_text("# Test Repo\n\nStaged content")
        os.system(f"cd {temp_git_repo} && git add .")

        result = await skill_with_repo.execute("diff", {
            "path": str(temp_git_repo),
            "staged": True
        })
        assert result.status == SkillStatus.SUCCESS
        assert "Staged content" in result.data["output"]


class TestGitOpsLog:
    """log アクションのテスト"""

    @pytest.mark.asyncio
    async def test_log_default(self, skill_with_repo, temp_git_repo):
        """デフォルトログ表示"""
        result = await skill_with_repo.execute("log", {"path": str(temp_git_repo)})
        assert result.status == SkillStatus.SUCCESS
        assert "Initial commit" in result.data["output"]

    @pytest.mark.asyncio
    async def test_log_oneline(self, skill_with_repo, temp_git_repo):
        """onelineフォーマットのログ"""
        result = await skill_with_repo.execute("log", {
            "path": str(temp_git_repo),
            "oneline": True
        })
        assert result.status == SkillStatus.SUCCESS
        # onelineフォーマットでは短いハッシュが表示される

    @pytest.mark.asyncio
    async def test_log_count(self, skill_with_repo, temp_git_repo):
        """コミット数指定"""
        # 追加のコミットを作成
        for i in range(3):
            (temp_git_repo / f"file{i}.txt").write_text(f"content {i}")
            os.system(f"cd {temp_git_repo} && git add . && git commit -q -m 'Commit {i}'")

        result = await skill_with_repo.execute("log", {
            "path": str(temp_git_repo),
            "count": 2
        })
        assert result.status == SkillStatus.SUCCESS


class TestGitOpsBranch:
    """branch アクションのテスト"""

    @pytest.mark.asyncio
    async def test_branch_list(self, skill_with_repo, temp_git_repo):
        """ブランチ一覧"""
        result = await skill_with_repo.execute("branch", {"path": str(temp_git_repo)})
        assert result.status == SkillStatus.SUCCESS
        # masterまたはmainブランチが存在
        assert "master" in result.data["output"] or "main" in result.data["output"]

    @pytest.mark.asyncio
    async def test_branch_create(self, skill_with_repo, temp_git_repo):
        """ブランチ作成"""
        result = await skill_with_repo.execute("branch", {
            "path": str(temp_git_repo),
            "name": "feature-branch"
        })
        assert result.status == SkillStatus.SUCCESS

        # ブランチが作成されたことを確認
        list_result = await skill_with_repo.execute("branch", {"path": str(temp_git_repo)})
        assert "feature-branch" in list_result.data["output"]


class TestGitOpsCheckout:
    """checkout アクションのテスト"""

    @pytest.mark.asyncio
    async def test_checkout_existing_branch(self, skill_with_repo, temp_git_repo):
        """既存ブランチへの切り替え"""
        # ブランチ作成
        os.system(f"cd {temp_git_repo} && git branch test-branch")

        result = await skill_with_repo.execute("checkout", {
            "path": str(temp_git_repo),
            "branch": "test-branch"
        })
        assert result.status == SkillStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_checkout_create_new_branch(self, skill_with_repo, temp_git_repo):
        """新規ブランチ作成して切り替え"""
        result = await skill_with_repo.execute("checkout", {
            "path": str(temp_git_repo),
            "branch": "new-feature",
            "create": True
        })
        assert result.status == SkillStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_checkout_missing_branch(self, skill_with_repo, temp_git_repo):
        """ブランチ未指定"""
        result = await skill_with_repo.execute("checkout", {"path": str(temp_git_repo)})
        assert result.status == SkillStatus.ERROR


class TestGitOpsAdd:
    """add アクションのテスト"""

    @pytest.mark.asyncio
    async def test_add_all(self, skill_with_repo, temp_git_repo):
        """全ファイルをステージング"""
        (temp_git_repo / "new_file.txt").write_text("content")

        result = await skill_with_repo.execute("add", {"path": str(temp_git_repo)})
        assert result.status == SkillStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_add_specific_files(self, skill_with_repo, temp_git_repo):
        """特定ファイルをステージング"""
        (temp_git_repo / "file1.txt").write_text("content1")
        (temp_git_repo / "file2.txt").write_text("content2")

        result = await skill_with_repo.execute("add", {
            "path": str(temp_git_repo),
            "files": ["file1.txt"]
        })
        assert result.status == SkillStatus.SUCCESS


class TestGitOpsCommit:
    """commit アクションのテスト"""

    @pytest.mark.asyncio
    async def test_commit_success(self, skill_with_repo, temp_git_repo):
        """コミット成功"""
        (temp_git_repo / "new_file.txt").write_text("content")
        os.system(f"cd {temp_git_repo} && git add .")

        result = await skill_with_repo.execute("commit", {
            "path": str(temp_git_repo),
            "message": "Add new file"
        })
        assert result.status == SkillStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_commit_missing_message(self, skill_with_repo, temp_git_repo):
        """メッセージ未指定"""
        result = await skill_with_repo.execute("commit", {"path": str(temp_git_repo)})
        assert result.status == SkillStatus.ERROR

    @pytest.mark.asyncio
    async def test_commit_nothing_to_commit(self, skill_with_repo, temp_git_repo):
        """コミットするものがない"""
        result = await skill_with_repo.execute("commit", {
            "path": str(temp_git_repo),
            "message": "Empty commit"
        })
        # nothing to commitはエラーになる
        assert result.status == SkillStatus.ERROR


class TestGitOpsStash:
    """stash アクションのテスト"""

    @pytest.mark.asyncio
    async def test_stash_push(self, skill_with_repo, temp_git_repo):
        """スタッシュ保存"""
        readme = temp_git_repo / "README.md"
        readme.write_text("Modified content")

        result = await skill_with_repo.execute("stash", {
            "path": str(temp_git_repo),
            "action": "push"
        })
        assert result.status == SkillStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_stash_list(self, skill_with_repo, temp_git_repo):
        """スタッシュ一覧"""
        result = await skill_with_repo.execute("stash", {
            "path": str(temp_git_repo),
            "action": "list"
        })
        assert result.status == SkillStatus.SUCCESS


class TestGitOpsShow:
    """show アクションのテスト"""

    @pytest.mark.asyncio
    async def test_show_head(self, skill_with_repo, temp_git_repo):
        """HEADコミットの詳細"""
        result = await skill_with_repo.execute("show", {
            "path": str(temp_git_repo),
            "commit": "HEAD"
        })
        assert result.status == SkillStatus.SUCCESS
        assert "Initial commit" in result.data["output"]


class TestGitOpsBlame:
    """blame アクションのテスト"""

    @pytest.mark.asyncio
    async def test_blame_file(self, skill_with_repo, temp_git_repo):
        """ファイルのblame"""
        result = await skill_with_repo.execute("blame", {
            "path": str(temp_git_repo),
            "file": "README.md"
        })
        assert result.status == SkillStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_blame_missing_file(self, skill_with_repo, temp_git_repo):
        """ファイル未指定"""
        result = await skill_with_repo.execute("blame", {"path": str(temp_git_repo)})
        assert result.status == SkillStatus.ERROR


class TestGitOpsUnknownAction:
    """不明なアクションのテスト"""

    @pytest.mark.asyncio
    async def test_unknown_action(self, skill):
        """不明なアクション"""
        result = await skill.execute("unknown_action", {})
        assert result.status == SkillStatus.ERROR
        assert "Unknown action" in result.error


class TestGitOpsNotARepo:
    """Gitリポジトリでないディレクトリのテスト"""

    @pytest.mark.asyncio
    async def test_status_not_a_repo(self, skill):
        """リポジトリでないディレクトリ"""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = await skill.execute("status", {"path": tmpdir})
            assert result.status == SkillStatus.ERROR
