"""
Constants for language module.
"""

# Language IDs
FRENCH_LANGUAGE = "fr"
ENGLISH_LANGUAGE = "en"