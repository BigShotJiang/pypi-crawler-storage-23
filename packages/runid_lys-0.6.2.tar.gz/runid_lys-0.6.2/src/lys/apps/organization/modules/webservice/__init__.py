"""
Webservice module for organization app.
"""