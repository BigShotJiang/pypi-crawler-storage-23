# Notification module for organization app - extends base notification with organization_data
