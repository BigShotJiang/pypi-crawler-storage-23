"""
Checker module for license rule validation and enforcement.
"""