"""
Client module extension for licensing-specific fields.
"""