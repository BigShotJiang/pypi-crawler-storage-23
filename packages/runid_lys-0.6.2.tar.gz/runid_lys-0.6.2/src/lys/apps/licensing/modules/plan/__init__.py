"""
Plan module for license plans and versions.
"""