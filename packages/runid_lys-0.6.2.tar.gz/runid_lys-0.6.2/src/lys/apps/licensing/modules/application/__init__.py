"""
License application module.

Defines applications that can have their own license plans.
This allows a single client to have different subscriptions for different apps.
"""