class MiddlewareInterface:
    pass