# 🛡️ Security Policy

If you find a vulnerability, please open a [draft security advisory](https://github.com/adamlui/python-utils/security/advisories/new).

Pull requests are also welcome, but for safety reasons, send an email to <adam@kudoai.com> and wait for a response before making it public.
