"""LangGraph/LangChain integration for wl-apdp.

This module provides adapters for integrating wl-apdp authorization
into LangGraph agents and LangChain tools.

Install with: pip install wl-apdp[langgraph]

Example:
    >>> from wl_apdp.contrib.langgraph import authorized_langchain_tool
    >>> from langchain_core.tools import tool
    >>>
    >>> @authorized_langchain_tool(resource='Tool::"calculator"')
    ... @tool
    ... def calculator(expression: str) -> float:
    ...     '''Calculate a mathematical expression.'''
    ...     return eval(expression)
"""

from __future__ import annotations

import functools
from typing import TYPE_CHECKING, Any, Callable, TypeVar

from ..client import WlApdpSyncClient
from ..context import AuthorizationContext, authorization_context, get_current_context
from ..exceptions import AuthorizationDenied
from ..models import cedar_action, cedar_resource

if TYPE_CHECKING:
    from langchain_core.tools import BaseTool, StructuredTool

T = TypeVar("T")


def authorized_langchain_tool(
    resource: str | None = None,
    action: str = "execute",
    base_url: str = "http://localhost:8081/api",
    token: str | None = None,
    fail_closed: bool = True,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Decorator to add authorization to a LangChain tool function.

    This decorator should be applied BEFORE the @tool decorator to wrap
    the underlying function with authorization checks.

    Args:
        resource: Cedar resource reference. If None, derived from function name.
        action: The action to check (default: "execute").
        base_url: Base URL for wl-apdp API.
        token: Optional bearer token.
        fail_closed: If True, deny access when no context is available.

    Returns:
        Decorated function with authorization checks.

    Example:
        >>> @authorized_langchain_tool(resource='Tool::"search"')
        ... @tool
        ... def search(query: str) -> str:
        ...     '''Search the web.'''
        ...     return perform_search(query)
    """

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        tool_resource = resource or cedar_resource("Tool", func.__name__)

        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> T:
            ctx = get_current_context()

            if ctx is None:
                if fail_closed:
                    raise AuthorizationDenied(
                        "No authorization context available",
                        resource=tool_resource,
                        action=action,
                    )
                return func(*args, **kwargs)

            with WlApdpSyncClient(base_url=base_url, token=token) as client:
                result = client.authorize(
                    principal=ctx.to_cedar_principal(),
                    action=cedar_action(action),
                    resource=tool_resource,
                    context=ctx.to_context_dict(),
                )

            if not result.is_allowed:
                raise AuthorizationDenied(
                    f"Not authorized to execute {func.__name__}",
                    response=result,
                    principal=ctx.to_cedar_principal(),
                    action=cedar_action(action),
                    resource=tool_resource,
                )

            return func(*args, **kwargs)

        return wrapper

    return decorator


class AuthorizedToolWrapper:
    """Wrapper for LangChain BaseTool with authorization checks.

    This class wraps any LangChain tool to add authorization checks
    before execution.

    Example:
        >>> from langchain_community.tools import DuckDuckGoSearchRun
        >>> from wl_apdp.contrib.langgraph import AuthorizedToolWrapper
        >>>
        >>> search = DuckDuckGoSearchRun()
        >>> authorized_search = AuthorizedToolWrapper(
        ...     tool=search,
        ...     resource='Tool::"web_search"'
        ... )
    """

    def __init__(
        self,
        tool: BaseTool,
        resource: str | None = None,
        action: str = "execute",
        base_url: str = "http://localhost:8081/api",
        token: str | None = None,
        fail_closed: bool = True,
    ) -> None:
        """Initialize the authorized tool wrapper.

        Args:
            tool: The LangChain tool to wrap.
            resource: Cedar resource reference. If None, uses Tool::"<tool_name>".
            action: The action to check (default: "execute").
            base_url: Base URL for wl-apdp API.
            token: Optional bearer token.
            fail_closed: If True, deny access when no context is available.
        """
        self.tool = tool
        self.resource = resource or cedar_resource("Tool", tool.name)
        self.action = action
        self._base_url = base_url
        self._token = token
        self.fail_closed = fail_closed

    @property
    def name(self) -> str:
        """Return the wrapped tool's name."""
        return self.tool.name

    @property
    def description(self) -> str:
        """Return the wrapped tool's description."""
        return self.tool.description

    def _check_authorization(self) -> None:
        """Check authorization before tool execution."""
        ctx = get_current_context()

        if ctx is None:
            if self.fail_closed:
                raise AuthorizationDenied(
                    "No authorization context available",
                    resource=self.resource,
                    action=self.action,
                )
            return

        with WlApdpSyncClient(base_url=self._base_url, token=self._token) as client:
            result = client.authorize(
                principal=ctx.to_cedar_principal(),
                action=cedar_action(self.action),
                resource=self.resource,
                context=ctx.to_context_dict(),
            )

        if not result.is_allowed:
            raise AuthorizationDenied(
                f"Not authorized to use {self.name}",
                response=result,
                principal=ctx.to_cedar_principal(),
                action=cedar_action(self.action),
                resource=self.resource,
            )

    def invoke(self, input: Any, config: Any = None, **kwargs: Any) -> Any:
        """Invoke the tool with authorization check."""
        self._check_authorization()
        return self.tool.invoke(input, config, **kwargs)

    async def ainvoke(self, input: Any, config: Any = None, **kwargs: Any) -> Any:
        """Async invoke the tool with authorization check."""
        self._check_authorization()
        return await self.tool.ainvoke(input, config, **kwargs)

    def run(self, *args: Any, **kwargs: Any) -> Any:
        """Run the tool with authorization check."""
        self._check_authorization()
        return self.tool.run(*args, **kwargs)

    async def arun(self, *args: Any, **kwargs: Any) -> Any:
        """Async run the tool with authorization check."""
        self._check_authorization()
        return await self.tool.arun(*args, **kwargs)


def wrap_langchain_tools(
    tools: list[BaseTool],
    action: str = "execute",
    base_url: str = "http://localhost:8081/api",
    token: str | None = None,
) -> list[AuthorizedToolWrapper]:
    """Wrap a list of LangChain tools with authorization checks.

    Args:
        tools: List of LangChain tools to wrap.
        action: The action to check for tool execution.
        base_url: Base URL for wl-apdp API.
        token: Optional bearer token.

    Returns:
        List of wrapped tools with authorization checks.

    Example:
        >>> tools = [SearchTool(), CalculatorTool()]
        >>> authorized_tools = wrap_langchain_tools(tools)
    """
    return [
        AuthorizedToolWrapper(
            tool=tool,
            action=action,
            base_url=base_url,
            token=token,
        )
        for tool in tools
    ]


def create_authorized_node(
    action: str,
    resource: str,
    base_url: str = "http://localhost:8081/api",
    token: str | None = None,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Create a decorator for LangGraph nodes with authorization.

    This decorator wraps a LangGraph node function with authorization
    checks that run before the node executes.

    Args:
        action: The action to authorize.
        resource: Cedar resource reference.
        base_url: Base URL for wl-apdp API.
        token: Optional bearer token.

    Returns:
        Decorator for node functions.

    Example:
        >>> @create_authorized_node(action="execute", resource='Node::"process_data"')
        ... def process_data(state: dict) -> dict:
        ...     # Process the data
        ...     return {"result": "processed"}
    """

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> T:
            ctx = get_current_context()
            if ctx is None:
                raise AuthorizationDenied(
                    "No authorization context for node execution",
                    resource=resource,
                    action=action,
                )

            with WlApdpSyncClient(base_url=base_url, token=token) as client:
                result = client.authorize(
                    principal=ctx.to_cedar_principal(),
                    action=cedar_action(action),
                    resource=resource,
                    context=ctx.to_context_dict(),
                )

            if not result.is_allowed:
                raise AuthorizationDenied(
                    f"Not authorized to execute node {func.__name__}",
                    response=result,
                    principal=ctx.to_cedar_principal(),
                    action=cedar_action(action),
                    resource=resource,
                )

            return func(*args, **kwargs)

        return wrapper

    return decorator


class LangGraphAuthContext:
    """Context manager for running LangGraph with authorization.

    This class provides a convenient way to set up authorization context
    for LangGraph execution.

    Example:
        >>> with LangGraphAuthContext(
        ...     principal_id="agent-123",
        ...     tenant_id="tenant-abc"
        ... ):
        ...     result = graph.invoke({"input": "hello"})
    """

    def __init__(
        self,
        principal_id: str,
        principal_type: str = "Agent",
        tenant_id: str | None = None,
        session_id: str | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> None:
        """Initialize the auth context.

        Args:
            principal_id: Unique identifier for the principal.
            principal_type: Type of principal (User, Agent, Service, Bot).
            tenant_id: Optional tenant ID.
            session_id: Optional session ID.
            attributes: Additional attributes.
        """
        self.context = AuthorizationContext(
            principal=principal_id,
            principal_type=principal_type,
            tenant_id=tenant_id,
            session_id=session_id,
            attributes=attributes or {},
        )
        self._ctx_manager = authorization_context(self.context)

    def __enter__(self) -> AuthorizationContext:
        """Enter context manager."""
        return self._ctx_manager.__enter__()

    def __exit__(self, *args: Any) -> None:
        """Exit context manager."""
        self._ctx_manager.__exit__(*args)

    async def __aenter__(self) -> AuthorizationContext:
        """Enter async context manager."""
        return await self._ctx_manager.__aenter__()

    async def __aexit__(self, *args: Any) -> None:
        """Exit async context manager."""
        await self._ctx_manager.__aexit__(*args)
