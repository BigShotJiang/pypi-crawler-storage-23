"""Framework-specific integrations for wl-apdp.

This package contains optional adapters for popular agent frameworks.
Install the corresponding extra to use each adapter:

    pip install wl-apdp[crewai]      # For CrewAI
    pip install wl-apdp[langgraph]   # For LangGraph/LangChain
    pip install wl-apdp[autogen]     # For AutoGen
    pip install wl-apdp[all]         # For all frameworks
"""

__all__: list[str] = []
