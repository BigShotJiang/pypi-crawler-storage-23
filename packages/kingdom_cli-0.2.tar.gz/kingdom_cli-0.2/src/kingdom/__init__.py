"""Kingdom CLI package."""

__all__ = ["cli"]
