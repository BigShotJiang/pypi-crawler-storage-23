"""TUI chat interface for council conversations."""
