"""Tests for the peasant CLI commands."""

from __future__ import annotations

import os
import signal
from datetime import UTC, datetime
from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from kingdom import cli
from kingdom.session import AgentState, get_agent_state, set_agent_state
from kingdom.state import backlog_root, ensure_branch_layout, logs_root, set_current_run
from kingdom.thread import add_message, create_thread, list_messages, thread_dir
from kingdom.ticket import Ticket, find_ticket, read_ticket, write_ticket

runner = CliRunner()

BRANCH = "feature/peasant-test"


def setup_project(base: Path) -> None:
    """Create a minimal project with branch layout and a test ticket."""
    ensure_branch_layout(base, BRANCH)
    set_current_run(base, BRANCH)


def create_test_ticket(base: Path, ticket_id: str = "kin-test", status: str = "open") -> Path:
    """Create a test ticket and return its path."""
    tickets_dir = base / ".kd" / "branches" / "feature-peasant-test" / "tickets"
    tickets_dir.mkdir(parents=True, exist_ok=True)
    ticket = Ticket(
        id=ticket_id,
        status=status,
        title="Test ticket",
        body="Do the thing.\n\n## Acceptance\n\n- [ ] It works",
        created=datetime.now(UTC),
    )
    path = tickets_dir / f"{ticket_id}.md"
    write_ticket(ticket, path)
    return path


class TestPeasantStart:
    def test_start_creates_session_and_thread(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            # Mock Popen so we don't actually launch a process
            mock_proc = MagicMock()
            mock_proc.pid = 12345

            # Mock worktree creation
            with (
                patch("kingdom.cli.create_worktree", return_value=base / ".kd" / "worktrees" / "kin-test"),
                patch("subprocess.Popen", return_value=mock_proc),
                patch("os.open", return_value=3),
                patch("os.close"),
            ):
                result = runner.invoke(cli.app, ["peasant", "start", "kin-test"])

            assert result.exit_code == 0, result.output
            assert "Started peasant-kin-test" in result.output
            assert "pid 12345" in result.output

            # Session should be created
            state = get_agent_state(base, BRANCH, "peasant-kin-test")
            assert state.status == "working"
            assert state.pid == 12345
            assert state.ticket == "kin-test"
            assert state.thread == "kin-test-work"

            # Thread should be created
            tdir = thread_dir(base, BRANCH, "kin-test-work")
            assert tdir.exists()

    def test_start_hand_mode(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            # Mock Popen so we don't actually launch a process
            mock_proc = MagicMock()
            mock_proc.pid = 12345

            # Mock worktree creation - ensure it is NOT called
            with (
                patch("kingdom.cli.create_worktree") as mock_create_worktree,
                patch("subprocess.Popen", return_value=mock_proc),
                patch("os.open", return_value=3),
                patch("os.close"),
            ):
                result = runner.invoke(cli.app, ["peasant", "start", "kin-test", "--hand"])

            assert result.exit_code == 0, result.output
            assert "Running in hand mode" in result.output
            assert "pid 12345" in result.output

            # create_worktree should NOT be called
            mock_create_worktree.assert_not_called()

            # Session should be created
            state = get_agent_state(base, BRANCH, "peasant-kin-test")
            assert state.status == "working"
            assert state.pid == 12345

    def test_start_hand_mode_preserves_agent_when_dead_sessions_exist(self) -> None:
        """The --hand loop variable must not shadow the `agent` parameter."""
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            # Create a dead peasant session so the guard loop iterates
            set_agent_state(
                base,
                BRANCH,
                "peasant-other",
                AgentState(name="peasant-other", status="working", pid=99999999),
            )

            mock_proc = MagicMock()
            mock_proc.pid = 12345

            with (
                patch("subprocess.Popen", return_value=mock_proc),
                patch("os.open", return_value=3),
                patch("os.close"),
            ):
                result = runner.invoke(cli.app, ["peasant", "start", "kin-test", "--hand", "--agent", "claude"])

            assert result.exit_code == 0, result.output

            # The agent_backend should be the string "claude", not an AgentState object
            state = get_agent_state(base, BRANCH, "peasant-kin-test")
            assert state.agent_backend == "claude", f"Expected 'claude', got {state.agent_backend!r}"

    def test_start_refuses_if_already_running(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            # Set up a "running" session with a live PID
            set_agent_state(
                base,
                BRANCH,
                "peasant-kin-test",
                AgentState(name="peasant-kin-test", status="working", pid=os.getpid()),
            )

            result = runner.invoke(cli.app, ["peasant", "start", "kin-test"])

            assert result.exit_code == 1
            assert "already running" in result.output

    def test_start_ticket_not_found(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)

            result = runner.invoke(cli.app, ["peasant", "start", "kin-nope"])

            assert result.exit_code == 1
            assert "not found" in result.output

    def test_start_blocks_on_in_review_ticket(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            tickets_dir = base / ".kd" / "branches" / "feature-peasant-test" / "tickets"
            tickets_dir.mkdir(parents=True, exist_ok=True)
            ticket = Ticket(
                id="kin-rev1",
                status="in_review",
                title="Review ticket",
                body="Under review",
                created=datetime.now(UTC),
            )
            path = tickets_dir / "kin-rev1.md"
            write_ticket(ticket, path)

            result = runner.invoke(cli.app, ["peasant", "start", "kin-rev1"])

            assert result.exit_code == 1
            assert "in_review" in result.output

    def test_start_transitions_open_to_in_progress(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            ticket_path = create_test_ticket(base)  # creates with status="open"

            with patch("kingdom.cli.launch_work_background", return_value=12345):
                result = runner.invoke(cli.app, ["peasant", "start", "kin-test", "--hand"])

            assert result.exit_code == 0, result.output
            # Verify the ticket was transitioned to in_progress
            ticket = read_ticket(ticket_path)
            assert ticket.status == "in_progress"


class TestPeasantStatus:
    def test_status_no_peasants(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)

            result = runner.invoke(cli.app, ["peasant", "status"])

            assert result.exit_code == 0
            assert "No active peasants" in result.output

    def test_status_shows_active_peasants(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)

            now = datetime.now(UTC).isoformat()
            set_agent_state(
                base,
                BRANCH,
                "peasant-kin-042",
                AgentState(
                    name="peasant-kin-042",
                    status="working",
                    pid=99999,
                    ticket="kin-042",
                    agent_backend="claude",
                    started_at=now,
                    last_activity=now,
                ),
            )

            with patch("os.kill"):  # Mock kill so liveness check doesn't mark as dead
                result = runner.invoke(cli.app, ["peasant", "status"])

            assert result.exit_code == 0
            assert "kin-042" in result.output
            assert "working" in result.output
            assert "claude" in result.output

    def test_status_ignores_non_peasant_sessions(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)

            # A regular agent session (not a peasant)
            set_agent_state(
                base,
                BRANCH,
                "claude",
                AgentState(name="claude", status="working"),
            )

            result = runner.invoke(cli.app, ["peasant", "status"])

            assert result.exit_code == 0
            assert "No active peasants" in result.output


class TestPeasantLogs:
    def test_logs_no_logs_found(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            result = runner.invoke(cli.app, ["peasant", "logs", "kin-test"])

            assert result.exit_code == 1
            assert "No logs found" in result.output

    def test_logs_shows_stdout(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            # Create log files
            peasant_logs_dir = logs_root(base, BRANCH) / "peasant-kin-test"
            peasant_logs_dir.mkdir(parents=True, exist_ok=True)
            (peasant_logs_dir / "stdout.log").write_text("Hello from peasant\n", encoding="utf-8")
            (peasant_logs_dir / "stderr.log").write_text("", encoding="utf-8")

            result = runner.invoke(cli.app, ["peasant", "logs", "kin-test"])

            assert result.exit_code == 0
            assert "Hello from peasant" in result.output

    def test_logs_shows_stderr(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            peasant_logs_dir = logs_root(base, BRANCH) / "peasant-kin-test"
            peasant_logs_dir.mkdir(parents=True, exist_ok=True)
            (peasant_logs_dir / "stdout.log").write_text("", encoding="utf-8")
            (peasant_logs_dir / "stderr.log").write_text("Error occurred\n", encoding="utf-8")

            result = runner.invoke(cli.app, ["peasant", "logs", "kin-test"])

            assert result.exit_code == 0
            assert "Error occurred" in result.output

    def test_logs_ticket_not_found(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)

            result = runner.invoke(cli.app, ["peasant", "logs", "kin-nope"])

            assert result.exit_code == 1
            assert "not found" in result.output


class TestPeasantStop:
    def test_stop_kills_process_group(self) -> None:
        """Stop sends SIGTERM to the entire process group, not just the harness PID."""
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            set_agent_state(
                base,
                BRANCH,
                "peasant-kin-test",
                AgentState(name="peasant-kin-test", status="working", pid=99999),
            )

            # killpg SIGTERM succeeds, then killpg(0) raises OSError (all dead)
            with patch("os.killpg") as mock_killpg:
                mock_killpg.side_effect = [None, OSError("No such process")]
                result = runner.invoke(cli.app, ["peasant", "stop", "kin-test"])

            assert result.exit_code == 0
            assert "SIGTERM" in result.output
            assert "process group" in result.output
            mock_killpg.assert_any_call(99999, signal.SIGTERM)

            state = get_agent_state(base, BRANCH, "peasant-kin-test")
            assert state.status == "stopped"

    def test_stop_sigkill_fallback(self) -> None:
        """If processes survive SIGTERM, SIGKILL is sent after timeout."""
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            set_agent_state(
                base,
                BRANCH,
                "peasant-kin-test",
                AgentState(name="peasant-kin-test", status="working", pid=99999),
            )

            # Simulate: SIGTERM succeeds, processes stay alive, then finally die after SIGKILL
            call_count = 0

            def killpg_side_effect(pgid: int, sig: int) -> None:
                nonlocal call_count
                call_count += 1
                if sig == signal.SIGTERM:
                    return  # SIGTERM sent OK
                if sig == 0:
                    return  # process still alive (probe succeeds)
                if sig == signal.SIGKILL:
                    return  # SIGKILL sent OK

            with (
                patch("os.killpg", side_effect=killpg_side_effect),
                patch("time.monotonic") as mock_mono,
                patch("time.sleep"),
            ):
                # First call: before deadline check; second: past deadline
                mock_mono.side_effect = [0, 0, 6]
                result = runner.invoke(cli.app, ["peasant", "stop", "kin-test"])

            assert result.exit_code == 0
            assert "SIGKILL" in result.output

            state = get_agent_state(base, BRANCH, "peasant-kin-test")
            assert state.status == "stopped"

    def test_stop_process_group_already_dead(self) -> None:
        """If the process group is already dead, stop still updates session status."""
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            set_agent_state(
                base,
                BRANCH,
                "peasant-kin-test",
                AgentState(name="peasant-kin-test", status="working", pid=99999),
            )

            with patch("os.killpg", side_effect=OSError("No such process")):
                result = runner.invoke(cli.app, ["peasant", "stop", "kin-test"])

            assert result.exit_code == 0
            assert "not found" in result.output.lower() or "No such process" in result.output
            state = get_agent_state(base, BRANCH, "peasant-kin-test")
            assert state.status == "stopped"

    def test_stop_not_running(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            set_agent_state(
                base,
                BRANCH,
                "peasant-kin-test",
                AgentState(name="peasant-kin-test", status="done"),
            )

            result = runner.invoke(cli.app, ["peasant", "stop", "kin-test"])

            assert result.exit_code == 1
            assert "not running" in result.output

    def test_stop_ticket_not_found(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)

            result = runner.invoke(cli.app, ["peasant", "stop", "kin-nope"])

            assert result.exit_code == 1
            assert "not found" in result.output


class TestPeasantClean:
    def test_clean_removes_worktree(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            with patch("kingdom.cli.remove_worktree") as mock_remove:
                result = runner.invoke(cli.app, ["peasant", "clean", "kin-test"])

            assert result.exit_code == 0
            assert "worktree removed" in result.output
            mock_remove.assert_called_once_with(base, "kin-test")

    def test_clean_no_worktree(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            with patch("kingdom.cli.remove_worktree", side_effect=FileNotFoundError("No worktree")):
                result = runner.invoke(cli.app, ["peasant", "clean", "kin-test"])

            assert result.exit_code == 1
            assert "No worktree" in result.output


class TestPeasantSync:
    def test_sync_merges_parent_branch(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            # Create fake worktree directory
            from kingdom.state import state_root

            worktree_path = state_root(base) / "worktrees" / "kin-test"
            worktree_path.mkdir(parents=True, exist_ok=True)

            merge_result = MagicMock()
            merge_result.returncode = 0
            merge_result.stdout = "Already up to date."
            merge_result.stderr = ""

            with patch("subprocess.run", return_value=merge_result):
                result = runner.invoke(cli.app, ["peasant", "sync", "kin-test"])

            assert result.exit_code == 0, result.output
            assert "[1/2]" in result.output
            assert "[2/2]" in result.output
            assert "Already up to date" in result.output
            assert "sync complete" in result.output

    def test_sync_refuses_while_running(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="working", pid=os.getpid()),
            )

            result = runner.invoke(cli.app, ["peasant", "sync", "kin-test"])

            assert result.exit_code == 1
            assert "running" in result.output.lower()
            assert "stop" in result.output.lower()

    def test_sync_allows_when_dead_pid(self) -> None:
        """Status=working but PID is dead — should allow sync."""
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="working", pid=99999999),
            )

            from kingdom.state import state_root

            worktree_path = state_root(base) / "worktrees" / "kin-test"
            worktree_path.mkdir(parents=True, exist_ok=True)

            merge_result = MagicMock()
            merge_result.returncode = 0
            merge_result.stdout = "Already up to date."
            merge_result.stderr = ""

            with patch("subprocess.run", return_value=merge_result):
                result = runner.invoke(cli.app, ["peasant", "sync", "kin-test"])

            assert result.exit_code == 0, result.output
            assert "sync complete" in result.output

    def test_sync_no_worktree(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            result = runner.invoke(cli.app, ["peasant", "sync", "kin-test"])

            assert result.exit_code == 1
            assert "No worktree" in result.output

    def test_sync_merge_conflict_aborts(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            from kingdom.state import state_root

            worktree_path = state_root(base) / "worktrees" / "kin-test"
            worktree_path.mkdir(parents=True, exist_ok=True)

            merge_result = MagicMock()
            merge_result.returncode = 1
            merge_result.stdout = "CONFLICT (content): Merge conflict in foo.py"
            merge_result.stderr = ""

            abort_result = MagicMock()
            abort_result.returncode = 0

            with patch("subprocess.run", side_effect=[merge_result, abort_result]) as mock_run:
                result = runner.invoke(cli.app, ["peasant", "sync", "kin-test"])

            assert result.exit_code == 1
            assert "Merge failed" in result.output
            assert "resolve manually" in result.output.lower()

            # Should have called git merge --abort
            calls = mock_run.call_args_list
            assert any("--abort" in str(c) for c in calls)

    def test_sync_runs_init_script(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            from kingdom.state import state_root

            worktree_path = state_root(base) / "worktrees" / "kin-test"
            worktree_path.mkdir(parents=True, exist_ok=True)

            # Create executable init script
            init_script = state_root(base) / "init-worktree.sh"
            init_script.write_text("#!/bin/bash\necho 'init ran'", encoding="utf-8")
            init_script.chmod(0o755)

            merge_result = MagicMock()
            merge_result.returncode = 0
            merge_result.stdout = "Already up to date."
            merge_result.stderr = ""

            init_run_result = MagicMock()
            init_run_result.returncode = 0
            init_run_result.stdout = "init ran"
            init_run_result.stderr = ""

            with patch("subprocess.run", side_effect=[merge_result, init_run_result]):
                result = runner.invoke(cli.app, ["peasant", "sync", "kin-test"])

            assert result.exit_code == 0, result.output
            assert "init-worktree.sh" in result.output
            assert "sync complete" in result.output

    def test_sync_non_executable_init_script(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            from kingdom.state import state_root

            worktree_path = state_root(base) / "worktrees" / "kin-test"
            worktree_path.mkdir(parents=True, exist_ok=True)

            # Create init script but do NOT make it executable
            init_script = state_root(base) / "init-worktree.sh"
            init_script.write_text("#!/bin/bash\necho 'init ran'", encoding="utf-8")
            init_script.chmod(0o644)

            merge_result = MagicMock()
            merge_result.returncode = 0
            merge_result.stdout = "Already up to date."
            merge_result.stderr = ""

            with patch("subprocess.run", return_value=merge_result):
                result = runner.invoke(cli.app, ["peasant", "sync", "kin-test"])

            assert result.exit_code == 0, result.output
            assert "not executable" in result.output

    def test_sync_ticket_not_found(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)

            result = runner.invoke(cli.app, ["peasant", "sync", "kin-nope"])

            assert result.exit_code == 1
            assert "not found" in result.output


def setup_work_thread(base: Path, ticket_id: str = "kin-test") -> str:
    """Create a work thread for a ticket. Returns thread_id."""
    thread_id = f"{ticket_id}-work"
    session_name = f"peasant-{ticket_id}"
    create_thread(base, BRANCH, thread_id, [session_name, "king"], "work")
    return thread_id


class TestPeasantMsg:
    def test_msg_sends_directive(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)
            thread_id = setup_work_thread(base)

            result = runner.invoke(cli.app, ["peasant", "msg", "kin-test", "focus on tests"])

            assert result.exit_code == 0, result.output
            assert "directive sent" in result.output

            # Message should appear in the thread
            messages = list_messages(base, BRANCH, thread_id)
            assert len(messages) == 1
            assert messages[0].from_ == "king"
            assert messages[0].to == "peasant-kin-test"
            assert "focus on tests" in messages[0].body

    def test_msg_multiple_directives(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)
            thread_id = setup_work_thread(base)

            runner.invoke(cli.app, ["peasant", "msg", "kin-test", "first directive"])
            runner.invoke(cli.app, ["peasant", "msg", "kin-test", "second directive"])

            messages = list_messages(base, BRANCH, thread_id)
            assert len(messages) == 2
            assert "first directive" in messages[0].body
            assert "second directive" in messages[1].body

    def test_msg_no_thread(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)
            # Don't create the work thread

            result = runner.invoke(cli.app, ["peasant", "msg", "kin-test", "hello"])

            assert result.exit_code == 1
            assert "No work thread" in result.output

    def test_msg_warns_dead_peasant(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)
            thread_id = setup_work_thread(base)

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="done"),
            )

            result = runner.invoke(cli.app, ["peasant", "msg", "kin-test", "do something"])

            assert result.exit_code == 0, result.output
            assert "directive sent" in result.output
            assert "Warning" in result.output
            assert "not running" in result.output

            # Message should still be written to thread
            messages = list_messages(base, BRANCH, thread_id)
            assert len(messages) == 1
            assert "do something" in messages[0].body

    def test_msg_no_warning_when_alive(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)
            setup_work_thread(base)

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="working", pid=os.getpid()),
            )

            result = runner.invoke(cli.app, ["peasant", "msg", "kin-test", "keep going"])

            assert result.exit_code == 0, result.output
            assert "directive sent" in result.output
            assert "Warning" not in result.output

    def test_msg_ticket_not_found(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)

            result = runner.invoke(cli.app, ["peasant", "msg", "kin-nope", "hello"])

            assert result.exit_code == 1
            assert "not found" in result.output


class TestPeasantRead:
    def test_read_shows_peasant_messages(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)
            thread_id = setup_work_thread(base)

            # Add some messages — one from king, two from peasant
            add_message(base, BRANCH, thread_id, from_="king", to="peasant-kin-test", body="Start working")
            add_message(base, BRANCH, thread_id, from_="peasant-kin-test", to="king", body="Working on it")
            add_message(base, BRANCH, thread_id, from_="peasant-kin-test", to="king", body="STATUS: BLOCKED\nNeed help")

            result = runner.invoke(cli.app, ["peasant", "read", "kin-test"])

            assert result.exit_code == 0
            assert "Working on it" in result.output
            assert "BLOCKED" in result.output
            # King's message should not appear (filtered to peasant only)
            assert "Start working" not in result.output

    def test_read_no_messages(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)
            setup_work_thread(base)

            result = runner.invoke(cli.app, ["peasant", "read", "kin-test"])

            assert result.exit_code == 0
            assert "No messages" in result.output

    def test_read_last_n(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)
            thread_id = setup_work_thread(base)

            # Add several peasant messages
            for i in range(5):
                add_message(base, BRANCH, thread_id, from_="peasant-kin-test", to="king", body=f"Message {i}")

            result = runner.invoke(cli.app, ["peasant", "read", "kin-test", "--last", "2"])

            assert result.exit_code == 0
            assert "Message 3" in result.output
            assert "Message 4" in result.output
            assert "Message 0" not in result.output

    def test_read_last_zero_rejected(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)
            setup_work_thread(base)

            result = runner.invoke(cli.app, ["peasant", "read", "kin-test", "--last", "0"])

            assert result.exit_code != 0

    def test_read_last_negative_rejected(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)
            setup_work_thread(base)

            result = runner.invoke(cli.app, ["peasant", "read", "kin-test", "--last", "-1"])

            assert result.exit_code != 0

    def test_read_no_thread(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            result = runner.invoke(cli.app, ["peasant", "read", "kin-test"])

            assert result.exit_code == 1
            assert "No work thread" in result.output

    def test_read_ticket_not_found(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)

            result = runner.invoke(cli.app, ["peasant", "read", "kin-nope"])

            assert result.exit_code == 1
            assert "not found" in result.output


class TestPeasantReview:
    def test_review_shows_results(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            ticket_path = create_test_ticket(base, status="in_review")

            # Add a worklog to the ticket
            from kingdom.harness import append_worklog

            append_worklog(ticket_path, "Did some work")

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="needs_king_review"),
            )

            with patch("subprocess.run") as mock_run:
                diff_result = MagicMock()
                diff_result.returncode = 0
                diff_result.stdout = " src/foo.py | 5 ++-\n 1 file changed"
                diff_result.stderr = ""

                mock_run.return_value = diff_result

                result = runner.invoke(cli.app, ["peasant", "review", "kin-test"])

            assert result.exit_code == 0, result.output
            assert "Did some work" in result.output
            assert "needs_king_review" in result.output
            assert "--accept" in result.output

    def test_review_accept_closes_ticket(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base, status="in_review")

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="needs_king_review"),
            )

            def mock_run(cmd, **kwargs):
                result = MagicMock()
                if cmd and "rev-parse" in cmd and "--abbrev-ref" in cmd:
                    result.returncode = 0
                    result.stdout = f"{BRANCH}\n"
                    result.stderr = ""
                else:
                    # git merge
                    result.returncode = 0
                    result.stdout = "Already up to date."
                    result.stderr = ""
                return result

            with patch("kingdom.cli.subprocess.run", side_effect=mock_run):
                result = runner.invoke(cli.app, ["peasant", "review", "kin-test", "--accept"])

            assert result.exit_code == 0, result.output
            assert "accepted" in result.output
            assert "Integrated" in result.output

            # Ticket should be closed
            ticket_result = find_ticket(base, "kin-test")
            assert ticket_result is not None
            ticket, _ = ticket_result
            assert ticket.status == "closed"

            # Session should be done
            state = get_agent_state(base, BRANCH, session_name)
            assert state.status == "done"

    def test_review_accept_wrong_branch_fails(self) -> None:
        """--accept should hard-fail if HEAD is not on the feature branch."""
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base, status="in_review")

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="needs_king_review"),
            )

            def mock_run(cmd, **kwargs):
                result = MagicMock()
                if cmd and "rev-parse" in cmd and "--abbrev-ref" in cmd:
                    result.returncode = 0
                    result.stdout = "master\n"
                    result.stderr = ""
                else:
                    result.returncode = 0
                    result.stdout = ""
                    result.stderr = ""
                return result

            with patch("kingdom.cli.subprocess.run", side_effect=mock_run):
                result = runner.invoke(cli.app, ["peasant", "review", "kin-test", "--accept"])

            assert result.exit_code == 1
            assert "Cannot accept" in result.output
            assert "master" in result.output

    def test_review_accept_hand_mode_skips_merge(self) -> None:
        """In hand mode, --accept should skip merge and close ticket directly."""
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base, status="in_review")

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="needs_king_review", hand_mode=True),
            )

            def mock_run(cmd, **kwargs):
                result = MagicMock()
                if cmd and "rev-parse" in cmd and "--abbrev-ref" in cmd:
                    result.returncode = 0
                    result.stdout = f"{BRANCH}\n"
                    result.stderr = ""
                else:
                    # Should NOT be called for merge in hand mode
                    raise AssertionError("Unexpected subprocess call in hand mode accept")
                return result

            with patch("kingdom.cli.subprocess.run", side_effect=mock_run):
                result = runner.invoke(cli.app, ["peasant", "review", "kin-test", "--accept"])

            assert result.exit_code == 0, result.output
            assert "Hand mode" in result.output
            assert "accepted" in result.output

            # Ticket should be closed
            ticket_result = find_ticket(base, "kin-test")
            assert ticket_result is not None
            ticket, _ = ticket_result
            assert ticket.status == "closed"

            # Session should be done
            state = get_agent_state(base, BRANCH, session_name)
            assert state.status == "done"

    def test_review_reject_hand_mode_relaunches_in_place(self) -> None:
        """In hand mode, --reject should relaunch using base dir, not worktree."""
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base, status="in_review")
            setup_work_thread(base)

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="needs_king_review", agent_backend="claude", hand_mode=True),
            )

            with patch("kingdom.cli.launch_work_background", return_value=77777) as mock_launch:
                result = runner.invoke(cli.app, ["peasant", "review", "kin-test", "--reject", "try again"])

            assert result.exit_code == 0, result.output
            assert "rejected" in result.output
            assert "relaunched" in result.output

            # launch should have been called with base as worktree (not .kd/worktrees/...)
            mock_launch.assert_called_once()
            call_args = mock_launch.call_args
            worktree_arg = call_args[0][4] if len(call_args[0]) > 4 else call_args[1].get("worktree_path")
            assert worktree_arg == base, f"Expected base dir {base}, got {worktree_arg}"

            # Bounce count should be reset
            state = get_agent_state(base, BRANCH, session_name)
            assert state.review_bounce_count == 0

    def test_review_reject_relaunches_dead_peasant(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base, status="in_review")
            thread_id = setup_work_thread(base)

            # Create worktree directory so reject can relaunch
            worktree_dir = base / ".kd" / "worktrees" / "kin-test"
            worktree_dir.mkdir(parents=True, exist_ok=True)

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="needs_king_review", agent_backend="claude"),
            )

            with patch("kingdom.cli.launch_work_background", return_value=54321) as mock_launch:
                result = runner.invoke(cli.app, ["peasant", "review", "kin-test", "--reject", "fix the edge case"])

            assert result.exit_code == 0, result.output
            assert "rejected" in result.output
            assert "relaunched" in result.output
            assert "54321" in result.output

            # Ticket should be back to in_progress
            ticket_result = find_ticket(base, "kin-test")
            assert ticket_result is not None
            ticket, _ = ticket_result
            assert ticket.status == "in_progress"

            # Feedback should be in the thread
            messages = list_messages(base, BRANCH, thread_id)
            assert len(messages) == 1
            assert "fix the edge case" in messages[0].body

            # Session should be working with new PID and reset bounce count
            state = get_agent_state(base, BRANCH, session_name)
            assert state.status == "working"
            assert state.pid == 54321
            assert state.review_bounce_count == 0

            # launch_harness should have been called
            mock_launch.assert_called_once()

    def test_review_reject_blocks_on_live_pid(self) -> None:
        """When the old peasant PID is still alive, reject should refuse to relaunch."""
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base, status="in_review")
            setup_work_thread(base)

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="needs_king_review", pid=os.getpid(), agent_backend="claude"),
            )

            result = runner.invoke(cli.app, ["peasant", "review", "kin-test", "--reject", "fix it"])

            assert result.exit_code == 1
            assert "still alive" in result.output

    def test_review_reject_no_resume_flag(self) -> None:
        """--no-resume sends feedback without relaunching the peasant."""
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base, status="in_review")
            thread_id = setup_work_thread(base)

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="needs_king_review"),
            )

            with patch("kingdom.cli.launch_work_background") as mock_launch:
                result = runner.invoke(
                    cli.app,
                    ["peasant", "review", "kin-test", "--reject", "try again", "--no-resume"],
                )

            assert result.exit_code == 0, result.output
            assert "rejected" in result.output
            assert "in_progress" in result.output
            assert "relaunched" not in result.output

            # Should NOT have relaunched
            mock_launch.assert_not_called()

            # Ticket should be back to in_progress
            ticket_result = find_ticket(base, "kin-test")
            assert ticket_result is not None
            ticket, _ = ticket_result
            assert ticket.status == "in_progress"

            # Feedback should still be in the thread
            messages = list_messages(base, BRANCH, thread_id)
            assert len(messages) == 1
            assert "try again" in messages[0].body

    def test_review_accept_reject_mutually_exclusive(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            result = runner.invoke(cli.app, ["peasant", "review", "kin-test", "--accept", "--reject", "nope"])

            assert result.exit_code == 1
            assert "mutually exclusive" in result.output

    def test_review_diff_error_shown(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="done"),
            )

            with patch("subprocess.run") as mock_run:
                diff_result = MagicMock()
                diff_result.returncode = 128
                diff_result.stdout = ""
                diff_result.stderr = "fatal: bad revision 'HEAD...ticket/kin-test'"

                mock_run.return_value = diff_result

                result = runner.invoke(cli.app, ["peasant", "review", "kin-test"])

            assert result.exit_code == 0, result.output
            assert "diff error" in result.output
            assert "fatal" in result.output

    def test_review_flags_no_diff(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base)

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="done"),
            )

            with patch("subprocess.run") as mock_run:
                diff_result = MagicMock()
                diff_result.returncode = 0
                diff_result.stdout = ""
                diff_result.stderr = ""

                mock_run.return_value = diff_result

                result = runner.invoke(cli.app, ["peasant", "review", "kin-test"])

            assert result.exit_code == 0, result.output
            assert "No code diff" in result.output

    def test_review_ticket_not_found(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)

            result = runner.invoke(cli.app, ["peasant", "review", "kin-nope"])

            assert result.exit_code == 1
            assert "not found" in result.output

    def test_review_accept_rejects_wrong_ticket_status(self) -> None:
        """--accept should fail if ticket is not in_review."""
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base, status="in_progress")

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="needs_king_review"),
            )

            result = runner.invoke(cli.app, ["peasant", "review", "kin-test", "--accept"])

            assert result.exit_code == 1
            assert "in_progress" in result.output
            assert "in_review" in result.output

    def test_review_accept_rejects_wrong_session_status(self) -> None:
        """--accept should fail if session is not needs_king_review."""
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base, status="in_review")

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="working"),
            )

            result = runner.invoke(cli.app, ["peasant", "review", "kin-test", "--accept"])

            assert result.exit_code == 1
            assert "working" in result.output
            assert "needs_king_review" in result.output

    def test_review_reject_rejects_wrong_ticket_status(self) -> None:
        """--reject should fail if ticket is not in_review."""
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base, status="open")

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="needs_king_review"),
            )

            result = runner.invoke(cli.app, ["peasant", "review", "kin-test", "--reject", "nope"])

            assert result.exit_code == 1
            assert "open" in result.output
            assert "in_review" in result.output

    def test_review_accept_merge_failure_keeps_in_review(self) -> None:
        """If git merge fails, ticket should stay in_review with recovery steps."""
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base, status="in_review")

            # Create worktree directory for recovery instructions
            worktree_dir = base / ".kd" / "worktrees" / "kin-test"
            worktree_dir.mkdir(parents=True, exist_ok=True)

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="needs_king_review"),
            )

            def mock_run(cmd, **kwargs):
                result = MagicMock()
                if cmd and "rev-parse" in cmd and "--abbrev-ref" in cmd:
                    result.returncode = 0
                    result.stdout = f"{BRANCH}\n"
                    result.stderr = ""
                else:
                    # git merge — simulate conflict
                    result.returncode = 1
                    result.stdout = "CONFLICT (content): Merge conflict in src/foo.py"
                    result.stderr = "Automatic merge failed; fix conflicts and then commit the result."
                return result

            with patch("kingdom.cli.subprocess.run", side_effect=mock_run):
                result = runner.invoke(cli.app, ["peasant", "review", "kin-test", "--accept"])

            assert result.exit_code == 1
            assert "Integration failed" in result.output
            assert "Recovery steps" in result.output
            assert "CONFLICT" in result.output

            # Ticket should still be in_review
            ticket_result = find_ticket(base, "kin-test")
            assert ticket_result is not None
            ticket, _ = ticket_result
            assert ticket.status == "in_review"

    def test_review_shows_council_feedback(self) -> None:
        """Review info should include council member messages from the work thread."""
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            ticket_path = create_test_ticket(base, status="in_review")

            from kingdom.harness import append_worklog

            append_worklog(ticket_path, "Implemented the feature")

            thread_id = setup_work_thread(base)
            # Add council feedback messages to the thread
            add_message(base, BRANCH, thread_id, from_="claude", to="all", body="Looks good.\n\nVERDICT: APPROVED")
            add_message(base, BRANCH, thread_id, from_="codex", to="all", body="Minor issue.\n\nVERDICT: APPROVED")

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="needs_king_review", review_bounce_count=1),
            )

            with patch("subprocess.run") as mock_run:
                diff_result = MagicMock()
                diff_result.returncode = 0
                diff_result.stdout = " src/foo.py | 5 ++-\n 1 file changed"
                diff_result.stderr = ""

                mock_run.return_value = diff_result

                result = runner.invoke(cli.app, ["peasant", "review", "kin-test"])

            assert result.exit_code == 0, result.output
            assert "Council Feedback" in result.output
            assert "Looks good" in result.output
            assert "Minor issue" in result.output
            assert "in_review" in result.output
            assert "needs_king_review" in result.output
            assert "Review bounces: 1" in result.output
            assert "--accept" in result.output

    def test_review_warns_on_no_diff(self) -> None:
        """Review should warn when peasant reports done but has no code changes."""
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base, status="in_review")

            session_name = "peasant-kin-test"
            set_agent_state(
                base,
                BRANCH,
                session_name,
                AgentState(name=session_name, status="needs_king_review"),
            )

            with patch("subprocess.run") as mock_run:
                diff_result = MagicMock()
                diff_result.returncode = 0
                diff_result.stdout = ""  # No diff
                diff_result.stderr = ""

                mock_run.return_value = diff_result

                result = runner.invoke(cli.app, ["peasant", "review", "kin-test"])

            assert result.exit_code == 0, result.output
            assert "no code diff" in result.output.lower()
            assert "Warning" in result.output


class TestBacklogAutoPull:
    def test_start_moves_backlog_ticket_to_branch(self) -> None:
        """A ticket in backlog should be moved to the branch tickets dir on peasant start."""
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)

            # Create ticket directly in backlog
            backlog_tickets = backlog_root(base) / "tickets"
            backlog_tickets.mkdir(parents=True, exist_ok=True)
            ticket = Ticket(
                id="kin-back",
                status="open",
                title="Backlog ticket",
                body="From backlog.\n\n## Acceptance\n\n- [ ] Done",
                created=datetime.now(UTC),
            )
            backlog_path = backlog_tickets / "kin-back.md"
            write_ticket(ticket, backlog_path)

            # Verify it's findable in the backlog
            assert backlog_path.exists()

            mock_proc = MagicMock()
            mock_proc.pid = 12345

            with (
                patch("kingdom.cli.create_worktree", return_value=base / ".kd" / "worktrees" / "kin-back"),
                patch("subprocess.Popen", return_value=mock_proc),
                patch("os.open", return_value=3),
                patch("os.close"),
            ):
                result = runner.invoke(cli.app, ["peasant", "start", "kin-back"])

            assert result.exit_code == 0, result.output

            # Backlog copy should be gone
            assert not backlog_path.exists()

            # Ticket should now live under branch tickets
            branch_tickets = base / ".kd" / "branches" / "feature-peasant-test" / "tickets"
            new_path = branch_tickets / "kin-back.md"
            assert new_path.exists()

            # Should still be findable
            found = find_ticket(base, "kin-back")
            assert found is not None
            assert found[0].id == "kin-back"

    def test_auto_pulled_ticket_visible_in_tk_list(self) -> None:
        """After auto-pull, the ticket should appear in `kd tk list`."""
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)

            # Create ticket in backlog
            backlog_tickets = backlog_root(base) / "tickets"
            backlog_tickets.mkdir(parents=True, exist_ok=True)
            ticket = Ticket(
                id="kin-list",
                status="open",
                title="Listable ticket",
                body="Should show in list.\n\n## Acceptance\n\n- [ ] Listed",
                created=datetime.now(UTC),
            )
            write_ticket(ticket, backlog_tickets / "kin-list.md")

            mock_proc = MagicMock()
            mock_proc.pid = 12345

            with (
                patch("kingdom.cli.create_worktree", return_value=base / ".kd" / "worktrees" / "kin-list"),
                patch("subprocess.Popen", return_value=mock_proc),
                patch("os.open", return_value=3),
                patch("os.close"),
            ):
                runner.invoke(cli.app, ["peasant", "start", "kin-list"])

            # kd tk list should now show the ticket
            result = runner.invoke(cli.app, ["tk", "list"])
            assert result.exit_code == 0, result.output
            assert "kin-list" in result.output
            assert "Listable ticket" in result.output


class TestPeasantStatusNewStatuses:
    """Tests for awaiting_council and needs_king_review in peasant status display."""

    def test_awaiting_council_shown_in_status(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)

            set_agent_state(
                base,
                BRANCH,
                "peasant-kin-test",
                AgentState(
                    name="peasant-kin-test",
                    status="awaiting_council",
                    ticket="kin-test",
                    agent_backend="claude",
                ),
            )

            result = runner.invoke(cli.app, ["peasant", "status"])
            assert result.exit_code == 0
            assert "awaiting_council" in result.output

    def test_needs_king_review_shown_in_status(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)

            set_agent_state(
                base,
                BRANCH,
                "peasant-kin-test",
                AgentState(
                    name="peasant-kin-test",
                    status="needs_king_review",
                    ticket="kin-test",
                    agent_backend="codex",
                ),
            )

            result = runner.invoke(cli.app, ["peasant", "status"])
            assert result.exit_code == 0
            assert "needs_king_review" in result.output


class TestPeasantNoResultsMessages:
    """Tests for helpful empty-state messages with next-step guidance."""

    def test_peasant_status_empty_shows_guidance(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)

            result = runner.invoke(cli.app, ["peasant", "status"])

            assert result.exit_code == 0
            assert "No active peasants" in result.output
            assert "kd peasant start" in result.output

    def test_peasant_read_no_messages_shows_context(self) -> None:
        with runner.isolated_filesystem():
            base = Path.cwd()
            setup_project(base)
            create_test_ticket(base, "kin-rd01")

            # Create work thread but no peasant messages
            create_thread(base, BRANCH, "kin-rd01-work", ["peasant-kin-rd01", "king"], "work")
            add_message(base, BRANCH, "kin-rd01-work", from_="king", to="peasant-kin-rd01", body="Do the thing")

            result = runner.invoke(cli.app, ["peasant", "read", "kin-rd01"])

            assert result.exit_code == 0
            assert "No messages from" in result.output
            assert "may still be working" in result.output
