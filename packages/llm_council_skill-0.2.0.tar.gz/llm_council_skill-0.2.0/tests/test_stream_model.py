"""Unit tests for stream_model fallback behavior.

Tests cover:
- Mid-stream error triggers fallback to query_model
- Circuit breaker records failures from astream
- Circuit breaker records success on normal completion
- Budget guard reserve/commit/release with stream_model
- Open circuit breaker causes stream_model to return empty string

Requirements: 10.1, 10.3
"""

from __future__ import annotations

import asyncio

import pytest

from llm_council.budget import BudgetGuard
from llm_council.context import CouncilContext
from llm_council.cost import CouncilCostTracker
from llm_council.progress import ProgressManager
from llm_council.providers import StreamResult
from llm_council.stages import stream_model

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _FailingStreamingProvider:
    """A StreamingProvider whose astream raises mid-stream after yielding some chunks."""

    def __init__(self, chunks_before_error: list[str], error: Exception):
        self._chunks = chunks_before_error
        self._error = error

    async def query(self, prompt: str, model_config: dict, timeout: int) -> tuple[str, dict | None]:
        return "fallback response", {"input_tokens": 10, "output_tokens": 20}

    def astream(self, prompt: str, model_config: dict, timeout: int) -> StreamResult:
        error = self._error
        chunks = self._chunks

        async def _generate():
            for chunk in chunks:
                yield chunk
            raise error

        return StreamResult(_generate())


class _GoodStreamingProvider:
    """A StreamingProvider whose astream completes successfully."""

    def __init__(self, chunks: list[str], usage: dict | None = None):
        self._chunks = chunks
        self._usage = usage

    async def query(self, prompt: str, model_config: dict, timeout: int) -> tuple[str, dict | None]:
        return "".join(self._chunks), self._usage

    def astream(self, prompt: str, model_config: dict, timeout: int) -> StreamResult:
        chunks = self._chunks
        usage = self._usage

        async def _generate():
            for chunk in chunks:
                yield chunk

        result = StreamResult(_generate())
        result.usage = usage
        return result


def _make_ctx(**overrides) -> CouncilContext:
    """Create a minimal CouncilContext for unit tests."""
    ctx = CouncilContext(
        poe_api_key="test-key",
        cost_tracker=CouncilCostTracker(),
        progress=ProgressManager(is_tty=False),
    )
    ctx.semaphore = asyncio.Semaphore(4)
    for k, v in overrides.items():
        setattr(ctx, k, v)
    return ctx


MODEL_CONFIG = {"provider": "bedrock", "name": "test-model"}
MESSAGES = [{"role": "user", "content": "hello"}]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestStreamModelFallback:
    """Test mid-stream error triggers fallback to query_model."""

    @pytest.mark.asyncio
    async def test_mid_stream_error_falls_back_to_query(self):
        """When astream raises mid-stream, stream_model falls back to query_model
        and returns the query result."""
        provider = _FailingStreamingProvider(
            chunks_before_error=["partial ", "text "],
            error=RuntimeError("connection lost"),
        )
        ctx = _make_ctx()
        ctx.providers["bedrock"] = provider

        text, usage = await stream_model(MODEL_CONFIG, MESSAGES, ctx)

        # Should return the fallback query result, not the partial stream
        assert text == "fallback response"
        assert usage == {"input_tokens": 10, "output_tokens": 20}

    @pytest.mark.asyncio
    async def test_mid_stream_error_invokes_on_chunk_before_failure(self):
        """on_chunk is called for chunks yielded before the error, but the
        final result comes from the fallback query."""
        received: list[str] = []

        async def on_chunk(chunk: str) -> None:
            received.append(chunk)

        provider = _FailingStreamingProvider(
            chunks_before_error=["hello ", "world"],
            error=RuntimeError("boom"),
        )
        ctx = _make_ctx()
        ctx.providers["bedrock"] = provider

        text, _usage = await stream_model(MODEL_CONFIG, MESSAGES, ctx, on_chunk=on_chunk)

        # Chunks before error were delivered to callback
        assert received == ["hello ", "world"]
        # But the returned text is from the fallback
        assert text == "fallback response"


class TestStreamModelCircuitBreaker:
    """Test circuit breaker interactions with stream_model."""

    @pytest.mark.asyncio
    async def test_circuit_breaker_records_failure_on_astream_error(self):
        """When astream raises, the circuit breaker records a failure.

        Note: the fallback query_model also succeeds and calls record_success,
        which resets the counter. We verify the failure was recorded by using
        a spy on record_failure.
        """
        provider = _FailingStreamingProvider(
            chunks_before_error=[],
            error=RuntimeError("fail"),
        )
        ctx = _make_ctx()
        ctx.providers["bedrock"] = provider

        cb = ctx.get_circuit_breaker("bedrock:test-model")
        original_record_failure = cb.record_failure
        failure_called = False

        def spy_record_failure():
            nonlocal failure_called
            failure_called = True
            original_record_failure()

        cb.record_failure = spy_record_failure

        await stream_model(MODEL_CONFIG, MESSAGES, ctx)

        # record_failure was called during the streaming error
        assert failure_called

    @pytest.mark.asyncio
    async def test_circuit_breaker_records_success_on_normal_completion(self):
        """When astream completes normally, the circuit breaker records success."""
        provider = _GoodStreamingProvider(["hello", " world"])
        ctx = _make_ctx()
        ctx.providers["bedrock"] = provider

        # Pre-seed a failure so we can verify it gets reset
        cb = ctx.get_circuit_breaker("bedrock:test-model")
        cb.record_failure()
        assert cb._failure_count == 1

        await stream_model(MODEL_CONFIG, MESSAGES, ctx)

        assert cb._failure_count == 0
        assert cb._state == "closed"

    @pytest.mark.asyncio
    async def test_open_circuit_breaker_returns_empty_string(self):
        """When the circuit breaker is open, stream_model returns ('', None)
        without calling the provider."""
        provider = _GoodStreamingProvider(["should", "not", "reach"])
        ctx = _make_ctx()
        ctx.providers["bedrock"] = provider

        # Force the circuit breaker open
        cb = ctx.get_circuit_breaker("bedrock:test-model")
        for _ in range(cb.failure_threshold):
            cb.record_failure()
        assert cb.is_open

        text, usage = await stream_model(MODEL_CONFIG, MESSAGES, ctx)

        assert text == ""
        assert usage is None


class TestStreamModelBudgetGuard:
    """Test budget guard reserve/commit/release with stream_model."""

    @pytest.mark.asyncio
    async def test_budget_reserve_called_before_streaming(self):
        """Budget guard reserve is called before the provider is invoked."""
        provider = _GoodStreamingProvider(["ok"], usage={"input_tokens": 5, "output_tokens": 10})
        budget = BudgetGuard(max_tokens=1_000_000)
        ctx = _make_ctx(budget_guard=budget)
        ctx.providers["bedrock"] = provider

        assert budget.total_input_tokens == 0

        await stream_model(MODEL_CONFIG, MESSAGES, ctx)

        # After commit, budget should reflect actual usage
        assert budget.total_input_tokens > 0 or budget.total_output_tokens > 0

    @pytest.mark.asyncio
    async def test_budget_commit_on_success(self):
        """On successful streaming, budget guard commit adjusts to actual usage."""
        usage = {"input_tokens": 15, "output_tokens": 25}
        provider = _GoodStreamingProvider(["response"], usage=usage)
        budget = BudgetGuard(max_tokens=1_000_000)
        ctx = _make_ctx(budget_guard=budget)
        ctx.providers["bedrock"] = provider

        await stream_model(MODEL_CONFIG, MESSAGES, ctx)

        # After commit, the budget should reflect actual token counts
        assert budget.total_input_tokens == 15
        assert budget.total_output_tokens == 25
        assert len(budget.queries) == 1
        assert budget.queries[0]["model"] == "test-model"

    @pytest.mark.asyncio
    async def test_budget_release_on_failure(self):
        """On streaming failure, budget guard release returns the reservation."""
        provider = _FailingStreamingProvider(
            chunks_before_error=["partial"],
            error=RuntimeError("mid-stream error"),
        )
        budget = BudgetGuard(max_tokens=1_000_000)
        ctx = _make_ctx(budget_guard=budget)
        ctx.providers["bedrock"] = provider

        await stream_model(MODEL_CONFIG, MESSAGES, ctx)

        # The stream_model fallback calls query_model which does its own
        # reserve/commit cycle. The original reservation from the failed
        # stream should have been released. We verify the budget is not
        # stuck with a double-reservation by checking it's still reasonable.
        # The fallback query_model will have committed its own usage.
        # Key check: no BudgetExceededError was raised, and budget is consistent.
        total = budget.total_input_tokens + budget.total_output_tokens
        assert total >= 0  # budget wasn't left negative

    @pytest.mark.asyncio
    async def test_budget_exceeded_returns_empty(self):
        """When budget is exceeded, stream_model returns ('', None) without
        calling the provider."""
        provider = _GoodStreamingProvider(["should not reach"])
        budget = BudgetGuard(max_tokens=1)  # impossibly low
        ctx = _make_ctx(budget_guard=budget)
        ctx.providers["bedrock"] = provider

        text, usage = await stream_model(MODEL_CONFIG, MESSAGES, ctx)

        assert text == ""
        assert usage is None
