from __future__ import annotations

from .clients.async_ import AsyncCPZClient
from .clients.sync import CPZClient
from .common.cpz_ai import CPZAIClient
from .execution.enums import OrderSide, OrderType, TimeInForce
from .execution.models import (
    Account,
    Order,
    OrderReplaceRequest,
    OrderSubmitRequest,
    Position,
    Quote,
)
from .execution.router import BROKER_ALPACA, BROKER_HFT, BROKER_POLYMARKET, wait_for_order_recording

# Data layer exports
from .data.models import (
    Bar,
    Trade,
    News,
    OptionQuote,
    OptionContract,
    EconomicSeries,
    Filing,
    SocialPost,
    TimeFrame,
)
from .data.client import DataClient

# Risk analytics exports
from .risk.engine import RiskAnalytics
RiskEngine = RiskAnalytics  # backward compat
from .risk.models import (
    RiskSnapshot,
    StrategyRisk,
    MonteCarloResult,
    StressScenario,
    RollingMetrics,
    DrawdownAnalysis,
    PositionSizeResult,
    SharpeInference,
    FactorExposure,
    TailRiskMetrics,
)

# Simons AI Assistant exports
from .simons import SimonsClient, AsyncSimonsClient
from .simons_models import (
    SimonsResponse,
    SimonsChunk,
    SimonsMemory,
    TokenUsage,
    CodeProposal,
)

__all__ = [
    # Clients
    "CPZClient",
    "AsyncCPZClient",
    "CPZAIClient",
    "DataClient",
    # Simons AI Assistant
    "SimonsClient",
    "AsyncSimonsClient",
    "SimonsResponse",
    "SimonsChunk",
    "SimonsMemory",
    "TokenUsage",
    "CodeProposal",
    # Execution
    "OrderSide",
    "OrderType",
    "TimeInForce",
    "OrderSubmitRequest",
    "OrderReplaceRequest",
    "Order",
    "Account",
    "Position",
    "Quote",
    "BROKER_ALPACA",
    "BROKER_HFT",
    "BROKER_POLYMARKET",
    "wait_for_order_recording",
    # Risk Analytics
    "RiskAnalytics",
    "RiskEngine",  # backward compat
    "RiskSnapshot",
    "StrategyRisk",
    "MonteCarloResult",
    "StressScenario",
    "RollingMetrics",
    "DrawdownAnalysis",
    "PositionSizeResult",
    "SharpeInference",
    "FactorExposure",
    "TailRiskMetrics",
    # Data Models
    "Bar",
    "Trade",
    "News",
    "OptionQuote",
    "OptionContract",
    "EconomicSeries",
    "Filing",
    "SocialPost",
    "TimeFrame",
]

__version__ = "2.2.6"
