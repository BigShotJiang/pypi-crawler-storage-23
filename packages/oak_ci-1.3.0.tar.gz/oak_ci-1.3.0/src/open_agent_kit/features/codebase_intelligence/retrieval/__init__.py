"""Retrieval engine for Codebase Intelligence."""

from open_agent_kit.features.codebase_intelligence.retrieval.engine import RetrievalEngine

__all__ = ["RetrievalEngine"]
