from .extension import (
    ASSET_PERMISSION_ID,
)

__all__ = [
    "ASSET_PERMISSION_ID",
]
