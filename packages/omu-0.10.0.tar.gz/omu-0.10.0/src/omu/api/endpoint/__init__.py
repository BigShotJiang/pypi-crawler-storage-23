from .endpoint import EndpointType

__all__ = [
    "EndpointType",
]
