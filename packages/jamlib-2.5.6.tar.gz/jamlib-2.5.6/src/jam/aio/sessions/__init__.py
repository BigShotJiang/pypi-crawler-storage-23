# -*- coding: utf-8 -*-

"""Async sessions methods."""
