---
description: Tools for managing Plane workspaces.
tags: [workspaces]
name: plane-workspaces
tools:
- get_workspace_members
- get_workspace_features
- update_workspace_features
---
# plane-workspaces

Tools for managing Plane workspaces.

## Tools
- get_workspace_members
- get_workspace_features
- update_workspace_features
