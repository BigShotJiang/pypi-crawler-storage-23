---
description: Tools for managing Plane work item links.
tags: [work-item-links]
name: plane-work-item-links
tools:
- list_work_item_links
- retrieve_work_item_link
- create_work_item_link
- update_work_item_link
- delete_work_item_link
---
# plane-work-item-links

Tools for managing Plane work item links.

## Tools
- list_work_item_links
- retrieve_work_item_link
- create_work_item_link
- update_work_item_link
- delete_work_item_link
