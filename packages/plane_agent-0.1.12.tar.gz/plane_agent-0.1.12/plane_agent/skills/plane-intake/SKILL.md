---
description: Tools for managing Plane intake.
tags: [intake]
name: plane-intake
tools:
- list_intake_work_items
- create_intake_work_item
- retrieve_intake_work_item
- update_intake_work_item
- delete_intake_work_item
---
# plane-intake

Tools for managing Plane intake.

## Tools
- list_intake_work_items
- create_intake_work_item
- retrieve_intake_work_item
- update_intake_work_item
- delete_intake_work_item
