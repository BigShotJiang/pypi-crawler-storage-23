---
description: Tools for managing Plane work item types.
tags: [work-item-types]
name: plane-work-item-types
tools:
- list_work_item_types
- create_work_item_type
- retrieve_work_item_type
- update_work_item_type
- delete_work_item_type
---
# plane-work-item-types

Tools for managing Plane work item types.

## Tools
- list_work_item_types
- create_work_item_type
- retrieve_work_item_type
- update_work_item_type
- delete_work_item_type
