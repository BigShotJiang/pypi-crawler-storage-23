######################
Marketing Email Module
######################

The *Marketing Email Module* manages mailing lists.

.. toctree::
   :maxdepth: 2

   configuration
   design
   releases
