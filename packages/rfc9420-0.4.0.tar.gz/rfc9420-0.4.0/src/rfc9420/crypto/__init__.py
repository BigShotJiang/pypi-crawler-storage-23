"""Cryptographic abstractions and concrete implementations for RFC9420."""

