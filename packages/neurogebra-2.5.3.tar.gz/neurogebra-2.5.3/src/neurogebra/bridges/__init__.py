"""Bridge modules for framework integration."""
