"""Training utilities for Neurogebra."""

from neurogebra.training.educational_trainer import EducationalTrainer

__all__ = ["EducationalTrainer"]
