<p align="center">
  <img src="Web_Tools.png" alt="WebTools CLI" width="180">
</p>

<h1 align="center">WebTools CLI</h1>

<p align="center">
  <strong>Advanced Web Intelligence & Scraping Toolkit</strong><br>
  <em>OSINT - SEO - AI Analysis - Security Scanner</em>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/python-3.9+-blue?logo=python&logoColor=white" alt="Python">
  <img src="https://img.shields.io/badge/license-MIT-green" alt="License">
  <img src="https://img.shields.io/badge/version-1.0.0-cyan" alt="Version">
</p>

---

## Install

```bash
pip install webtools-cli
```

## Usage

```bash
# Launch CLI
webtools

# Or via Python module
python -m webtools
```

## Features

| Feature | Description |
|---------|-------------|
| **Web Mode** | Full web UI with Cloudflare tunnel + QR code sharing |
| **CLI Intelligence** | Deep scan any URL from terminal |
| **Security Scanner** | Threat detection, honeypot traps, CSRF checks |
| **SEO Analyzer** | Score, headings, broken links, image audit |
| **AI Analysis** | Sentiment, readability, keywords, summarization |
| **OSINT** | Emails, phones, locations, social media, tech stack |
| **Smart Media** | Image quality filter + video deep-scan with sniffer |
| **Proxy Intelligence** | Smart proxy rotation with learning algorithm |
| **Playwright Fallback** | Handles SPAs and auth walls automatically |
| **Performance Tracker** | Phase-by-phase timing with historical stats |

## CLI Commands

| Command | Description |
|---------|-------------|
| `/web` or `/w` | Launch Web UI mode |
| `/cli` or `/c` | Launch CLI Intelligence mode |
| `/image` or `/i` | Image Forensics & AI Detection |
| `/help` or `/h` | Show all commands |
| `/history` or `/hi` | View scan history |
| `/clear` | Purge scraped data |
| `/quit` or `/q` | Exit |

## Requirements

- Python 3.9+
- Optional: `playwright` for SPA/auth wall bypass

## Author

**Abhinav Adarsh**

## License

MIT
