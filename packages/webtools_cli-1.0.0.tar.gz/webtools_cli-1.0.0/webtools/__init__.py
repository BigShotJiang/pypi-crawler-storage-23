"""WebTools CLI - Advanced Web Intelligence & Scraping Toolkit"""
import sys
sys.dont_write_bytecode = True
__version__ = "1.0.0"
