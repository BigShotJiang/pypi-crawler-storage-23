#!/usr/bin/env python3
"""
test_server.py
End-to-end test of the zip-ingestion-mcp tools WITHOUT needing an MCP client.
Run from the project root: python tests/test_server.py

This calls the tool functions directly (they are plain Python functions).
You can also test via MCP Inspector — see README.md.
"""

import json
import sys
import shutil
from pathlib import Path

# Add src to path so we can import without installing
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from create_test_zip import create_test_zip  # creates the sample ZIP
from zip_ingestion_mcp.tools.extractor    import extract_zip
from zip_ingestion_mcp.tools.classifier   import detect_all_artifacts
from zip_ingestion_mcp.tools.encoding     import detect_encoding
from zip_ingestion_mcp.tools.dependencies import scan_dependencies
from zip_ingestion_mcp.tools.csd_parser   import parse_csd_export
from zip_ingestion_mcp.tools.manifest     import build_file_manifest

WORKSPACE = Path(__file__).parent / "workspace"

def separator(title):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print('='*60)

def pprint(data: dict):
    print(json.dumps(data, indent=2, default=str)[:3000])  # truncate for readability

def run_tests():
    # Clean workspace
    if WORKSPACE.exists():
        shutil.rmtree(WORKSPACE)
    WORKSPACE.mkdir()

    # ── Step 0: Create test ZIP ───────────────────────────────────────────────
    separator("Step 0: Creating test ZIP")
    zip_path = create_test_zip()
    print(f"ZIP: {zip_path}")

    # ── Step 1: Extract ───────────────────────────────────────────────────────
    separator("Step 1: extract_zip")
    result = extract_zip(zip_path, str(WORKSPACE / "payroll"))
    pprint(result)
    assert result["status"] == "success", f"extract_zip failed: {result}"
    extracted_dir = result["extracted_to"]
    print(f"\n✅ Extracted {result['total_files']} files to {extracted_dir}")

    # ── Step 2: Classify ──────────────────────────────────────────────────────
    separator("Step 2: detect_all_artifacts")
    result = detect_all_artifacts(extracted_dir)
    pprint(result)
    assert result["status"] == "success"
    stats = result["stats"]
    print(f"\n✅ Classification complete:")
    for ftype, count in stats.items():
        print(f"   {ftype}: {count}")

    # ── Step 3: Encoding check on one file ────────────────────────────────────
    separator("Step 3: detect_encoding")
    cbl_file = str(Path(extracted_dir) / "PAYRL001.CBL")
    result = detect_encoding(cbl_file)
    pprint(result)
    print(f"\n✅ Encoding detected: {result['detected_encoding']} (EBCDIC: {result['is_ebcdic']})")

    # ── Step 4: Dependencies ─────────────────────────────────────────────────
    separator("Step 4: scan_dependencies")
    result = scan_dependencies(extracted_dir)
    pprint(result)
    assert result["status"] == "success"
    print(f"\n✅ Dependency scan complete:")
    print(f"   Unresolved copybooks: {result['unresolved_count']['copybooks']}")
    print(f"   Unresolved BMS maps:  {result['unresolved_count']['bms_maps']}")

    # ── Step 5: CSD parsing ───────────────────────────────────────────────────
    separator("Step 5: parse_csd_export")
    csd_file = str(Path(extracted_dir) / "CSD" / "PAYROLL.CSD")
    result = parse_csd_export(csd_file)
    pprint(result)
    assert result["status"] == "success"
    print(f"\n✅ CSD parsed:")
    print(f"   Transactions: {result['summary']['transactions']}")
    print(f"   Programs:     {result['summary']['programs']}")
    print(f"   Files:        {result['summary']['files']}")
    print("\n   Route table:")
    for route in result["route_table"]:
        print(f"   [{route['http_method']:6}] {route['fastapi_route']:<30} ← {route['transaction_code']} → {route['program']}")

    # ── Step 6: Full manifest ─────────────────────────────────────────────────
    separator("Step 6: build_file_manifest (THE FINAL OUTPUT)")
    result = build_file_manifest(extracted_dir, zip_path)
    
    # Just print the summary + next steps (full manifest is huge)
    summary = result.get("summary", {})
    print("\n📋 MANIFEST SUMMARY:")
    for k, v in summary.items():
        print(f"   {k:<30}: {v}")
    
    print("\n⚠️  WARNINGS:")
    for w in result.get("warnings", [])[:5]:
        print(f"   [{w['severity']:6}] {w['type']}: {w['message'][:80]}")
    
    print("\n🗺️  ROUTE TABLE:")
    for route in result.get("route_table", []):
        print(f"   [{route['http_method']:6}] {route['fastapi_route']:<30} ← {route['transaction_code']}")

    print("\n➡️  NEXT STEPS:")
    for step in result.get("next_steps", []):
        print(f"   {step}")

    manifest_path = result.get("manifest_saved_to")
    if manifest_path:
        print(f"\n✅ Full manifest saved to: {manifest_path}")

    print("\n" + "="*60)
    print("  ALL TESTS PASSED ✅")
    print("="*60)


if __name__ == "__main__":
    # Run from tests/ directory
    import os
    os.chdir(Path(__file__).parent)
    run_tests()
