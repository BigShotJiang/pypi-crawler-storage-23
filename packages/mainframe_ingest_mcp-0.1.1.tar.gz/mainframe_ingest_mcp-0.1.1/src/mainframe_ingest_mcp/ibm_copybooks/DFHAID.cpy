      *----------------------------------------------------------------*
      * DFHAID - CICS Attention Identifier (AID) values               *
      * Standard IBM-supplied copybook. Bundled with zip-ingestion-mcp *
      * because it lives in IBM system libraries, not application code. *
      *----------------------------------------------------------------*
       01  DFHAID.
           02  DFHNULL   PIC X VALUE IS ' '.
           02  DFHENTER  PIC X VALUE IS X'7D'.
           02  DFHCLEAR  PIC X VALUE IS X'6D'.
           02  DFHCLRP   PIC X VALUE IS X'6E'.
           02  DFHPEN    PIC X VALUE IS X'7E'.
           02  DFHOPID   PIC X VALUE IS X'7F'.
           02  DFHMSRE   PIC X VALUE IS X'61'.
           02  DFHSTRF   PIC X VALUE IS X'60'.
           02  DFHTRIG   PIC X VALUE IS X'7F'.
           02  DFHPA1    PIC X VALUE IS X'6C'.
           02  DFHPA2    PIC X VALUE IS X'6E'.
           02  DFHPA3    PIC X VALUE IS X'6B'.
           02  DFHPF1    PIC X VALUE IS X'F1'.
           02  DFHPF2    PIC X VALUE IS X'F2'.
           02  DFHPF3    PIC X VALUE IS X'F3'.
           02  DFHPF4    PIC X VALUE IS X'F4'.
           02  DFHPF5    PIC X VALUE IS X'F5'.
           02  DFHPF6    PIC X VALUE IS X'F6'.
           02  DFHPF7    PIC X VALUE IS X'F7'.
           02  DFHPF8    PIC X VALUE IS X'F8'.
           02  DFHPF9    PIC X VALUE IS X'F9'.
           02  DFHPF10   PIC X VALUE IS X'7A'.
           02  DFHPF11   PIC X VALUE IS X'7B'.
           02  DFHPF12   PIC X VALUE IS X'7C'.
           02  DFHPF13   PIC X VALUE IS X'C1'.
           02  DFHPF14   PIC X VALUE IS X'C2'.
           02  DFHPF15   PIC X VALUE IS X'C3'.
           02  DFHPF16   PIC X VALUE IS X'C4'.
           02  DFHPF17   PIC X VALUE IS X'C5'.
           02  DFHPF18   PIC X VALUE IS X'C6'.
           02  DFHPF19   PIC X VALUE IS X'C7'.
           02  DFHPF20   PIC X VALUE IS X'C8'.
           02  DFHPF21   PIC X VALUE IS X'C9'.
           02  DFHPF22   PIC X VALUE IS X'4A'.
           02  DFHPF23   PIC X VALUE IS X'4B'.
           02  DFHPF24   PIC X VALUE IS X'4C'.
