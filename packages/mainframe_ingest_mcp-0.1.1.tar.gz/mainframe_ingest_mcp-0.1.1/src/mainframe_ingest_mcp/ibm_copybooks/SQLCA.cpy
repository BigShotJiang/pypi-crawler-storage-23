      *----------------------------------------------------------------*
      * SQLCA - SQL Communication Area                                 *
      * Standard IBM DB2 copybook. Bundled with zip-ingestion-mcp     *
      * because it lives in IBM system libraries, not application code.*
      *----------------------------------------------------------------*
       01  SQLCA.
           02  SQLCAID   PIC X(8)      VALUE 'SQLCA   '.
           02  SQLCABC   PIC S9(9)     COMP VALUE 136.
           02  SQLCODE   PIC S9(9)     COMP.
           02  SQLERRM.
               03  SQLERRML  PIC S9(4) COMP.
               03  SQLERRMC  PIC X(70).
           02  SQLERRP   PIC X(8).
           02  SQLERRD   OCCURS 6 TIMES PIC S9(9) COMP.
           02  SQLWARN.
               03  SQLWARN0  PIC X.
               03  SQLWARN1  PIC X.
               03  SQLWARN2  PIC X.
               03  SQLWARN3  PIC X.
               03  SQLWARN4  PIC X.
               03  SQLWARN5  PIC X.
               03  SQLWARN6  PIC X.
               03  SQLWARN7  PIC X.
           02  SQLEXT    PIC X(8).
