"""
Tool: extract_zip
Unpack a mainframe COBOL codebase ZIP and organise it for downstream tools.
"""

import zipfile
import shutil
import logging
from pathlib import Path
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

# File extensions we care about — used for quick pre-classification
KNOWN_EXTENSIONS = {
    ".cbl", ".cob", ".cpy", ".bms", ".jcl",
    ".ddl", ".sql", ".csd", ".inc", ".include",
    ".txt", ".lst", ".asm", ".pli", ".plt",
}


def extract_zip(zip_path: str, target_dir: str) -> dict:
    """
    Extract a ZIP archive to target_dir.

    Returns a summary dict that callers convert to JSON.
    """
    zip_path_obj  = Path(zip_path)
    target_path   = Path(target_dir)

    # ── Validation ────────────────────────────────────────────────────────────
    if not zip_path_obj.exists():
        return _error(f"ZIP file not found: {zip_path}")
    if not zip_path_obj.suffix.lower() == ".zip":
        return _error(f"File does not appear to be a ZIP archive: {zip_path}")

    # ── Create target directory ───────────────────────────────────────────────
    target_path.mkdir(parents=True, exist_ok=True)

    # ── Extract ───────────────────────────────────────────────────────────────
    extracted_files = []
    warnings        = []
    skipped         = []

    try:
        with zipfile.ZipFile(zip_path_obj, "r") as zf:
            # Validate for zip-slip attacks before extracting anything
            _check_zip_slip(zf, target_path)

            for member in zf.infolist():
                # Skip macOS metadata noise
                if "__MACOSX" in member.filename or member.filename.startswith("."):
                    skipped.append(member.filename)
                    continue

                dest = target_path / member.filename

                if member.is_dir():
                    dest.mkdir(parents=True, exist_ok=True)
                    continue

                # Ensure parent dirs exist (nested ZIPs don't always include dir entries)
                dest.parent.mkdir(parents=True, exist_ok=True)
                zf.extract(member, target_path)

                ext = Path(member.filename).suffix.lower()
                size_kb = round(member.file_size / 1024, 1)

                file_entry = {
                    "path":         str(dest),
                    "relative":     member.filename,
                    "size_bytes":   member.file_size,
                    "size_kb":      size_kb,
                    "extension":    ext,
                    "known_type":   ext in KNOWN_EXTENSIONS,
                }

                # Quick EBCDIC sniff (bytes with high frequency of 0x00 or IBM codepage bytes)
                if ext in {".cbl", ".cob", ".cpy", ".bms", ".jcl"} and member.file_size > 0:
                    if _looks_ebcdic(dest):
                        file_entry["likely_ebcdic"] = True
                        warnings.append({
                            "severity": "HIGH",
                            "type":     "EBCDIC_DETECTED",
                            "file":     member.filename,
                            "message":  f"{member.filename} appears to be EBCDIC-encoded. "
                                        "Run convert_encoding before parsing.",
                        })
                    else:
                        file_entry["likely_ebcdic"] = False

                extracted_files.append(file_entry)

    except zipfile.BadZipFile:
        return _error(f"File is not a valid ZIP archive: {zip_path}")
    except Exception as exc:
        return _error(f"Unexpected error during extraction: {exc}")

    # ── Summary ───────────────────────────────────────────────────────────────
    known_files    = [f for f in extracted_files if f["known_type"]]
    unknown_files  = [f for f in extracted_files if not f["known_type"]]
    ebcdic_files   = [f for f in extracted_files if f.get("likely_ebcdic")]

    return {
        "status":           "success",
        "extracted_to":     str(target_path),
        "source_zip":       str(zip_path_obj),
        "extracted_at":     datetime.now(timezone.utc).isoformat(),
        "total_files":      len(extracted_files),
        "known_artifacts":  len(known_files),
        "unknown_files":    len(unknown_files),
        "ebcdic_files":     len(ebcdic_files),
        "skipped_files":    len(skipped),
        "files":            extracted_files,
        "warnings":         warnings,
        "next_step":        "Call detect_all_artifacts to classify every file.",
    }


# ── Helpers ───────────────────────────────────────────────────────────────────

def _check_zip_slip(zf: zipfile.ZipFile, target: Path) -> None:
    """Raise ValueError if any ZIP entry would escape the target directory."""
    for member in zf.infolist():
        dest = (target / member.filename).resolve()
        if not str(dest).startswith(str(target.resolve())):
            raise ValueError(f"Zip-slip detected in entry: {member.filename}")


def _looks_ebcdic(path: Path) -> bool:
    """
    Heuristic: read first 512 bytes and count bytes in typical EBCDIC control
    ranges (0x00-0x3F) that are NOT common in ASCII text.
    EBCDIC files have many bytes in 0x40-0xFF with few 0x0A (newline) bytes.
    """
    try:
        sample = path.read_bytes()[:512]
        if not sample:
            return False
        newlines = sample.count(0x0A)  # ASCII/UTF-8 newline
        high_bytes = sum(1 for b in sample if b > 0x7F)
        null_bytes = sample.count(0x00)
        # Strong EBCDIC signal: almost no newlines, many high bytes, few nulls
        if newlines < 2 and high_bytes > len(sample) * 0.3 and null_bytes < 5:
            return True
        return False
    except Exception:
        return False


def _error(message: str) -> dict:
    return {"status": "error", "message": message}
