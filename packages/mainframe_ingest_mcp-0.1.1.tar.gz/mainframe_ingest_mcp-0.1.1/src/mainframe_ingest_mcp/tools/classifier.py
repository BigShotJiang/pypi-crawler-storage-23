"""
Tool: detect_all_artifacts
Walk a directory and classify every file into its mainframe artifact type.
"""

import re
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

# ── Classification rules ──────────────────────────────────────────────────────
# Priority: extension first, then content sniffing.

EXTENSION_MAP = {
    ".cbl":     "COBOL_PROGRAM",
    ".cob":     "COBOL_PROGRAM",
    ".cobol":   "COBOL_PROGRAM",
    ".jcl":     "JCL_JOB",
    ".proc":    "JCL_PROC",
    ".ddl":     "DB2_DDL",
    ".sql":     "DB2_SQL",
    ".asm":     "ASSEMBLER",
    ".pli":     "PLI_PROGRAM",
    ".plt":     "PLI_PROGRAM",
}

# .cpy is ambiguous — could be a normal copybook OR a BMS-generated copybook
# We resolve this by content sniffing (see _classify_cpy below).
# .bms is always a BMS screen definition.
# .inc / .include could be a SQL INCLUDE or a JCL INCLUDE — resolved by parent.
# .csd is a CSD export (text) only if it contains DEFINE TRANSACTION keywords.

# BMS copybook signature: generated field names end in L (length), A (attr), I (input), O (output)
_BMS_CPY_PATTERN = re.compile(
    r"^\s+\d{2}\s+\w{1,7}[LAIO]\s+PIC\s+S?9|"  # 02 EMPIDL PIC S9(4) COMP
    r"^\s+\d{2}\s+\w+\s+REDEFINES",
    re.MULTILINE,
)

# BMS source signature
_BMS_SOURCE_PATTERN = re.compile(r"\bDFHMSD\b|\bDFHMDI\b|\bDFHMDF\b", re.IGNORECASE)

# CSD export signature
_CSD_PATTERN = re.compile(r"\bDEFINE\s+TRANSACTION\b|\bDEFINE\s+PROGRAM\b", re.IGNORECASE)

# JCL include signature  
_JCL_INCLUDE_PATTERN = re.compile(r"^\s*//\s*INCLUDE\s+MEMBER=", re.MULTILINE)

# SQL include in COBOL
_SQL_INCLUDE_PATTERN = re.compile(r"EXEC\s+SQL\s+INCLUDE\s+\w+", re.IGNORECASE)

# COBOL COPY statement (might catch more copybooks)
_COBOL_COPY_PATTERN = re.compile(r"^\s+COPY\s+\w+", re.MULTILINE | re.IGNORECASE)


def detect_all_artifacts(directory: str) -> dict:
    """
    Walk directory, classify every file, return structured results.
    """
    root = Path(directory)
    if not root.exists():
        return {"status": "error", "message": f"Directory not found: {directory}"}

    files_by_type: dict[str, list] = {}
    all_files = []
    warnings  = []
    stats     = {}

    for path in sorted(root.rglob("*")):
        if path.is_dir():
            continue

        relative = str(path.relative_to(root))
        ext      = path.suffix.lower()
        size     = path.stat().st_size

        artifact_type = _classify_file(path, ext)

        entry = {
            "path":          str(path),
            "relative":      relative,
            "type":          artifact_type,
            "extension":     ext,
            "size_bytes":    size,
            "line_count":    _count_lines(path) if artifact_type != "UNKNOWN" else None,
            "directory":     str(path.parent.relative_to(root)),
        }

        # Extra metadata per type
        if artifact_type == "COBOL_PROGRAM":
            entry["copy_statements"] = _quick_copy_scan(path)
        elif artifact_type == "BMS_SCREEN":
            entry["mapset_name"] = _extract_mapset_name(path)
        elif artifact_type in ("COPYBOOK", "BMS_COPYBOOK"):
            entry["is_bms_generated"] = artifact_type == "BMS_COPYBOOK"

        # Collect warnings for important issues
        if artifact_type == "UNKNOWN" and size > 1000:
            warnings.append({
                "severity": "LOW",
                "type":     "UNKNOWN_FILE_TYPE",
                "file":     relative,
                "message":  f"File type not recognised. May need manual inspection.",
            })

        all_files.append(entry)
        files_by_type.setdefault(artifact_type, []).append(entry)

    # ── Stats ─────────────────────────────────────────────────────────────────
    for ftype, flist in files_by_type.items():
        stats[ftype] = len(flist)

    total_cobol_lines = sum(
        f.get("line_count") or 0
        for f in files_by_type.get("COBOL_PROGRAM", [])
    )

    # ── Detect copybook directories ───────────────────────────────────────────
    copybook_dirs = _find_copybook_dirs(files_by_type.get("COPYBOOK", []), root)
    bms_dirs      = _find_copybook_dirs(files_by_type.get("BMS_SCREEN", []), root)

    return {
        "status":            "success",
        "directory":         str(root),
        "total_files":       len(all_files),
        "stats":             stats,
        "total_cobol_lines": total_cobol_lines,
        "copybook_directories": copybook_dirs,
        "bms_directories":      bms_dirs,
        "files":             all_files,
        "warnings":          warnings,
        "next_step":         "Run convert_encoding on any EBCDIC files, then scan_dependencies.",
    }


# ── Classification helpers ────────────────────────────────────────────────────

def _classify_file(path: Path, ext: str) -> str:
    """Classify a single file. Extension first, content sniff as fallback."""

    # Fast path: unambiguous extensions
    if ext in EXTENSION_MAP:
        return EXTENSION_MAP[ext]
    if ext == ".bms":
        return "BMS_SCREEN"
    if ext == ".cpy":
        return _classify_cpy(path)
    if ext == ".csd":
        return _classify_csd(path)
    if ext in (".inc", ".include"):
        return _classify_include(path)

    # Content sniffing for files with generic extensions (.txt, no extension, etc.)
    content = _safe_read(path, 2048)
    if content:
        if _BMS_SOURCE_PATTERN.search(content):
            return "BMS_SCREEN"
        if _CSD_PATTERN.search(content):
            return "CSD_EXPORT"
        if "IDENTIFICATION DIVISION" in content.upper() or "PROCEDURE DIVISION" in content.upper():
            return "COBOL_PROGRAM"
        if content.lstrip().startswith("//") and "JOB" in content[:200]:
            return "JCL_JOB"

    return "UNKNOWN"


def _classify_cpy(path: Path) -> str:
    """Distinguish a BMS-generated copybook from a regular data copybook."""
    content = _safe_read(path, 4096)
    if not content:
        return "COPYBOOK"
    # BMS copybooks have the L/A/I/O suffix pattern and REDEFINES
    if _BMS_CPY_PATTERN.search(content):
        return "BMS_COPYBOOK"
    return "COPYBOOK"


def _classify_csd(path: Path) -> str:
    content = _safe_read(path, 2048)
    if content and _CSD_PATTERN.search(content):
        return "CSD_EXPORT"
    return "UNKNOWN"


def _classify_include(path: Path) -> str:
    content = _safe_read(path, 2048)
    if not content:
        return "UNKNOWN"
    if _SQL_INCLUDE_PATTERN.search(content):
        return "SQL_INCLUDE"
    if "EXEC SQL" in content.upper():
        return "SQL_INCLUDE"
    if content.lstrip().startswith("//"):
        return "JCL_INCLUDE"
    return "COBOL_COPYBOOK_INCLUDE"


def _quick_copy_scan(path: Path) -> list[str]:
    """Return list of copybook names referenced by COPY statements."""
    content = _safe_read(path)
    if not content:
        return []
    names = []
    for match in re.finditer(r"^\s+COPY\s+([A-Z0-9#@$-]+)", content, re.MULTILINE | re.IGNORECASE):
        names.append(match.group(1).strip().upper())
    return list(dict.fromkeys(names))  # deduplicate, preserve order


def _extract_mapset_name(path: Path) -> str | None:
    """Extract the DFHMSD mapset name from a BMS file."""
    content = _safe_read(path, 4096)
    if not content:
        return None
    match = re.search(r"^(\w+)\s+DFHMSD\b", content, re.MULTILINE | re.IGNORECASE)
    if match:
        return match.group(1).upper()
    return None


def _find_copybook_dirs(file_list: list, root: Path) -> list[str]:
    """Return unique parent directory paths for a list of file entries."""
    dirs = set()
    for f in file_list:
        parent = str(Path(f["path"]).parent.relative_to(root))
        dirs.add(parent)
    return sorted(dirs)


def _count_lines(path: Path) -> int:
    try:
        return sum(1 for _ in path.open("rb"))
    except Exception:
        return 0


def _safe_read(path: Path, max_bytes: int = 0) -> str:
    """Read file content, trying UTF-8 then latin-1 as fallback."""
    try:
        if max_bytes:
            raw = path.read_bytes()[:max_bytes]
        else:
            raw = path.read_bytes()
        try:
            return raw.decode("utf-8")
        except UnicodeDecodeError:
            return raw.decode("latin-1", errors="replace")
    except Exception:
        return ""
