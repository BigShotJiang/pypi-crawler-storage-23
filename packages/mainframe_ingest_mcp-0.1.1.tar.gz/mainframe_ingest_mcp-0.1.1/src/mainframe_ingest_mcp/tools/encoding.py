"""
Tools: detect_encoding, convert_encoding
Handle EBCDIC ↔ UTF-8 character encoding for mainframe files.

IBM mainframes historically used EBCDIC (Extended Binary Coded Decimal
Interchange Code) instead of ASCII. Files downloaded from z/OS systems are
often still in EBCDIC and will look like garbage if opened in a normal text
editor. This module detects and converts them.

Common IBM EBCDIC codepages:
  cp037  – USA / Canada (most common)
  cp500  – International / Western European
  cp1047 – Open Systems (Linux on z)
  cp284  – Spanish
  cp285  – UK English
  cp297  – French
  cp273  – German / Austrian
"""

import logging
import shutil
from pathlib import Path

# chardet is a third-party library for encoding detection
# Install with: pip install chardet
try:
    import chardet
    CHARDET_AVAILABLE = True
except ImportError:
    CHARDET_AVAILABLE = False

logger = logging.getLogger(__name__)

# Sample size for encoding detection (first 8 KB is usually enough)
SAMPLE_BYTES = 8192

# EBCDIC codepages Python knows about
EBCDIC_CODEPAGES = {
    "cp037", "cp500", "cp1047", "cp273", "cp277", "cp278",
    "cp280", "cp284", "cp285", "cp297", "cp1140", "cp1141",
    "cp1142", "cp1143", "cp1144", "cp1145", "cp1146",
    "cp1147", "cp1148", "cp1149",
}

# Bytes that are common in EBCDIC text but rare in UTF-8
# EBCDIC space is 0x40; period is 0x4B; comma is 0x6B
_EBCDIC_SIGNATURE_BYTES = {0x40, 0x4B, 0x6B, 0x7D, 0xF0, 0xF1, 0xF2}


def detect_encoding(file_path: str) -> dict:
    """
    Detect the character encoding of a file.

    Strategy:
      1. Use chardet if available (best accuracy).
      2. Fall back to our own heuristic EBCDIC detector.
      3. Assume UTF-8 if neither fires.
    """
    path = Path(file_path)
    if not path.exists():
        return {"status": "error", "message": f"File not found: {file_path}"}

    sample = _read_sample(path)
    if sample is None:
        return {"status": "error", "message": f"Could not read file: {file_path}"}
    if len(sample) == 0:
        return {
            "file":               str(path),
            "detected_encoding":  "utf-8",
            "confidence":         1.0,
            "readable":           True,
            "is_ebcdic":          False,
            "recommendation":     "File is empty.",
        }

    # ── Strategy 1: chardet ───────────────────────────────────────────────────
    if CHARDET_AVAILABLE:
        result = chardet.detect(sample)
        encoding = (result.get("encoding") or "utf-8").lower().replace("-", "")
        confidence = round(result.get("confidence", 0.0), 3)

        # Map chardet names to Python codec names
        encoding = _normalise_codec(encoding)
        is_ebcdic = encoding in EBCDIC_CODEPAGES

        return _build_result(path, encoding, confidence, is_ebcdic)

    # ── Strategy 2: heuristic ─────────────────────────────────────────────────
    is_ebcdic, confidence = _heuristic_ebcdic(sample)
    encoding = "cp037" if is_ebcdic else "utf-8"
    return _build_result(path, encoding, confidence, is_ebcdic)


def convert_encoding(file_path: str, from_encoding: str, to_encoding: str) -> dict:
    """
    Convert a file from one encoding to another.
    Creates a .bak backup before overwriting.
    """
    path = Path(file_path)
    if not path.exists():
        return {"status": "error", "message": f"File not found: {file_path}"}

    # Validate encodings
    for enc_name, enc_val in [("from_encoding", from_encoding), ("to_encoding", to_encoding)]:
        try:
            "test".encode(enc_val)
        except LookupError:
            return {"status": "error", "message": f"Unknown encoding for {enc_name}: {enc_val}"}

    original_bytes = path.read_bytes()
    original_size  = len(original_bytes)

    # ── Backup ────────────────────────────────────────────────────────────────
    backup_path = path.with_suffix(path.suffix + ".bak")
    shutil.copy2(path, backup_path)

    # ── Convert ───────────────────────────────────────────────────────────────
    try:
        text = original_bytes.decode(from_encoding)
    except (UnicodeDecodeError, LookupError) as exc:
        return {
            "status":  "error",
            "message": f"Failed to decode with {from_encoding}: {exc}",
            "file":    str(path),
            "backup":  str(backup_path),
        }

    try:
        converted_bytes = text.encode(to_encoding)
    except (UnicodeEncodeError, LookupError) as exc:
        return {
            "status":  "error",
            "message": f"Failed to encode to {to_encoding}: {exc}",
            "file":    str(path),
            "backup":  str(backup_path),
        }

    path.write_bytes(converted_bytes)
    converted_size = len(converted_bytes)

    # Quick sanity check: decoded text should have recognisable COBOL keywords
    sample_text = text[:500].upper()
    looks_correct = any(
        kw in sample_text
        for kw in ("IDENTIFICATION", "PROCEDURE", "DATA DIVISION", "WORKING", "EXEC", "JOB", "DFHMSD")
    )

    return {
        "status":         "success",
        "file":           str(path),
        "backup":         str(backup_path),
        "from_encoding":  from_encoding,
        "to_encoding":    to_encoding,
        "bytes_before":   original_size,
        "bytes_after":    converted_size,
        "looks_correct":  looks_correct,
        "preview":        text[:200].replace("\n", "↵"),  # first 200 chars for visual check
    }


# ── Helpers ───────────────────────────────────────────────────────────────────

def _read_sample(path: Path) -> bytes | None:
    try:
        return path.read_bytes()[:SAMPLE_BYTES]
    except Exception:
        return None


def _heuristic_ebcdic(sample: bytes) -> tuple[bool, float]:
    """
    Return (is_ebcdic, confidence) using byte distribution heuristics.

    Key signals:
    - ASCII text has newlines (0x0A), EBCDIC uses 0x25 as line-feed
    - EBCDIC space is 0x40 (very common in fixed-width COBOL records)
    - High proportion of bytes in 0x40-0xFF range with no 0x0A → EBCDIC
    """
    n = len(sample)
    if n == 0:
        return False, 0.0

    ascii_newlines  = sample.count(0x0A)
    ebcdic_spaces   = sample.count(0x40)   # EBCDIC space
    ebcdic_newlines = sample.count(0x25)   # EBCDIC line-feed
    high_bytes      = sum(1 for b in sample if b > 0x7F)
    null_bytes      = sample.count(0x00)

    score = 0.0

    # EBCDIC has no 0x0A newlines (or very few)
    if ascii_newlines == 0:
        score += 0.4
    elif ascii_newlines < 3:
        score += 0.2

    # EBCDIC space (0x40) is very common in COBOL fixed-width records
    if ebcdic_spaces > n * 0.05:
        score += 0.3

    # EBCDIC has its own newline
    if ebcdic_newlines > 0:
        score += 0.2

    # Many high bytes, few nulls → likely EBCDIC not binary
    if high_bytes > n * 0.2 and null_bytes < 5:
        score += 0.1

    return score >= 0.5, min(score, 0.97)


def _normalise_codec(name: str) -> str:
    """Map chardet codec names to Python codec names."""
    mapping = {
        "ibm037":  "cp037",
        "ibm500":  "cp500",
        "ibm1047": "cp1047",
        "ascii":   "utf-8",
    }
    return mapping.get(name, name)


def _build_result(path: Path, encoding: str, confidence: float, is_ebcdic: bool) -> dict:
    readable = not is_ebcdic
    if is_ebcdic:
        recommendation = (
            f"File is EBCDIC ({encoding}). "
            "Run convert_encoding with from_encoding='{encoding}' and to_encoding='utf-8' "
            "before any parsing."
        )
    else:
        recommendation = "File is already in a human-readable encoding. No conversion needed."

    return {
        "file":               str(path),
        "detected_encoding":  encoding,
        "confidence":         confidence,
        "readable":           readable,
        "is_ebcdic":          is_ebcdic,
        "recommendation":     recommendation,
        "chardet_available":  CHARDET_AVAILABLE,
    }
