"""
Tool: build_file_manifest
Assembles the complete handoff JSON manifest by calling all other tools.

This is the PRIMARY output of the ingestion server.
It is consumed by every downstream MCP server:
  - cobol-parser-mcp     reads files[] filtered by COBOL_PROGRAM
  - bms-to-angular-mcp   reads bms_screens[] and angular_components[]
  - db2-schema-mcp       reads db2_files[] and sql_includes[]
  - csd-routes-mcp       reads cics_transactions[] and route_table[]
"""

import json
import logging
from datetime import datetime, timezone
from pathlib import Path

from .classifier   import detect_all_artifacts
from .dependencies import scan_dependencies
from .csd_parser   import parse_csd_export

logger = logging.getLogger(__name__)

MANIFEST_VERSION = "1.0"


def build_file_manifest(directory: str, source_zip: str = "") -> dict:
    """
    Orchestrate all ingestion steps and return a unified manifest.
    """
    root = Path(directory)
    if not root.exists():
        return {"status": "error", "message": f"Directory not found: {directory}"}

    logger.info("Building manifest for: %s", directory)
    all_warnings = []

    # ── Step 1: Classify all files ────────────────────────────────────────────
    logger.info("Step 1/3: Classifying files…")
    artifact_result = detect_all_artifacts(directory)
    if artifact_result.get("status") == "error":
        return artifact_result
    all_warnings.extend(artifact_result.get("warnings", []))

    files_by_type: dict[str, list] = {}
    for f in artifact_result.get("files", []):
        files_by_type.setdefault(f["type"], []).append(f)

    # ── Step 2: Scan dependencies ─────────────────────────────────────────────
    logger.info("Step 2/3: Scanning dependencies…")
    dep_result = scan_dependencies(directory)
    if dep_result.get("status") == "error":
        return dep_result
    all_warnings.extend(dep_result.get("warnings", []))

    # ── Step 3: Parse CSD if present ──────────────────────────────────────────
    csd_result = None
    csd_files  = files_by_type.get("CSD_EXPORT", [])
    if csd_files:
        logger.info("Step 3/3: Parsing CSD export: %s", csd_files[0]["path"])
        csd_result = parse_csd_export(csd_files[0]["path"])
    else:
        logger.info("Step 3/3: No CSD export found — skipping.")
        all_warnings.append({
            "severity": "LOW",
            "type":     "NO_CSD_FOUND",
            "message":  (
                "No CICS CSD export file found. Transaction-to-program routing cannot "
                "be automatically determined. Consider exporting with: DFHCSDUP LIST ALL"
            ),
        })

    # ── Assemble the manifest ─────────────────────────────────────────────────
    dep_graph = dep_result.get("dependency_graph", {})
    copybook_used_by = dep_result.get("copybook_used_by", {})

    # Enrich COBOL program entries with dependency info
    cobol_programs = []
    for f in files_by_type.get("COBOL_PROGRAM", []):
        rel = f["relative"]
        deps = dep_graph.get(rel, {})
        entry = {
            **f,
            "copies":       deps.get("copies", []),
            "sql_includes": deps.get("sql_includes", []),
            "bms_sends":    deps.get("bms_sends", []),
            "bms_receives": deps.get("bms_receives", []),
            "static_calls": deps.get("static_calls", []),
            "cics_links":   deps.get("cics_links", []),
            "ready_for_parsing": _is_ready(deps),
        }
        cobol_programs.append(entry)

    # Enrich copybook entries with "used_by"
    copybooks = []
    for f in files_by_type.get("COPYBOOK", []):
        stem = Path(f["path"]).stem.upper()
        copybooks.append({
            **f,
            "used_by":  copybook_used_by.get(stem, []),
            "is_dclgen": False,
        })

    # BMS screen entries with Angular component hints
    bms_screens = []
    for f in files_by_type.get("BMS_SCREEN", []):
        stem     = Path(f["path"]).stem.upper()
        mapset   = f.get("mapset_name") or stem
        bms_screens.append({
            **f,
            "angular_component": _suggest_angular_component(mapset),
        })

    # BMS copybooks (auto-generated from BMS source)
    bms_copybooks = files_by_type.get("BMS_COPYBOOK", [])

    # CICS transaction routing
    cics_transactions = []
    route_table       = []
    if csd_result and csd_result.get("status") != "error":
        cics_transactions = csd_result.get("transactions", [])
        route_table       = csd_result.get("route_table", [])

    # DB2 DDL files
    db2_files = files_by_type.get("DB2_DDL", []) + files_by_type.get("DB2_SQL", [])

    # JCL files
    jcl_files = files_by_type.get("JCL_JOB", []) + files_by_type.get("JCL_PROC", [])

    # JCL batch programs → background task hints
    jcl_programs = _extract_jcl_programs(jcl_files)

    # ── Summary statistics ────────────────────────────────────────────────────
    total_cobol_lines = sum(f.get("line_count") or 0 for f in cobol_programs)
    unresolved_copies = dep_result.get("unresolved_count", {}).get("copybooks", 0)
    ebcdic_count      = artifact_result.get("ebcdic_files", 0)

    # Determine overall readiness
    critical_warnings = [w for w in all_warnings if w.get("severity") == "HIGH"]
    readiness = "READY" if not critical_warnings else "NEEDS_ATTENTION"

    manifest = {
        "manifest_version":  MANIFEST_VERSION,
        "status":            "success",
        "readiness":         readiness,
        "created_at":        datetime.now(timezone.utc).isoformat(),

        "source": {
            "type":          "zip" if source_zip else "directory",
            "original_file": source_zip or None,
            "extracted_to":  str(root),
        },

        "summary": {
            "total_files":           artifact_result.get("total_files", 0),
            "cobol_programs":        len(cobol_programs),
            "copybooks":             len(copybooks),
            "bms_screens":           len(bms_screens),
            "bms_copybooks":         len(bms_copybooks),
            "jcl_files":             len(jcl_files),
            "db2_files":             len(db2_files),
            "csd_files":             len(csd_files),
            "cics_transactions":     len(cics_transactions),
            "total_cobol_lines":     total_cobol_lines,
            "ebcdic_files_detected": ebcdic_count,
            "unresolved_copybooks":  unresolved_copies,
            "warnings_total":        len(all_warnings),
            "warnings_high":         len(critical_warnings),
        },

        # ── File sections (consumed by downstream servers) ────────────────────
        "cobol_programs":    cobol_programs,
        "copybooks":         copybooks,
        "bms_screens":       bms_screens,
        "bms_copybooks":     bms_copybooks,
        "jcl_files":         jcl_files,
        "db2_files":         db2_files,
        "csd_files":         csd_files,
        "other_files":       files_by_type.get("UNKNOWN", []),

        # ── Routing & modernization hints ─────────────────────────────────────
        "cics_transactions": cics_transactions,
        "route_table":       route_table,
        "jcl_programs":      jcl_programs,

        # ── Dependency graph ──────────────────────────────────────────────────
        "copybook_dependency_graph": copybook_used_by,

        # ── All warnings ──────────────────────────────────────────────────────
        "warnings": all_warnings,

        # ── What to do next ───────────────────────────────────────────────────
        "next_steps": _build_next_steps(
            cobol_programs, bms_screens, db2_files,
            cics_transactions, unresolved_copies, ebcdic_count
        ),
    }

    # Write manifest.json to the workspace directory
    manifest_path = root / "manifest.json"
    try:
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        manifest["manifest_saved_to"] = str(manifest_path)
        logger.info("Manifest saved: %s", manifest_path)
    except Exception as exc:
        logger.warning("Could not save manifest.json: %s", exc)
        manifest["manifest_save_error"] = str(exc)

    return manifest


# ── Helpers ───────────────────────────────────────────────────────────────────

def _is_ready(deps: dict) -> bool:
    """A COBOL program is 'ready for parsing' if all its copybooks are resolved."""
    for copy_ref in deps.get("copies", []):
        if not copy_ref.get("resolved"):
            return False
    return True


def _suggest_angular_component(mapset_name: str) -> dict:
    """Generate Angular component naming conventions from a BMS mapset name."""
    # PAYMSTP → PaymComponent, pay-m.component.ts
    clean = mapset_name.rstrip("P").rstrip("S")  # strip common BMS suffixes
    pascal = "".join(w.capitalize() for w in re.split(r"[^A-Z0-9]", clean, flags=re.IGNORECASE) if w)
    kebab  = re.sub(r"(?<!^)(?=[A-Z])", "-", pascal).lower()
    return {
        "component_class":  f"{pascal}Component",
        "selector":         f"app-{kebab}",
        "template_file":    f"{kebab}.component.html",
        "ts_file":          f"{kebab}.component.ts",
        "module_suggestion": f"{pascal}Module",
    }


def _extract_jcl_programs(jcl_files: list) -> list[dict]:
    """
    Extract EXEC PGM= statements from JCL to identify batch program entry points.
    These become FastAPI background tasks or Celery workers.
    """
    import re
    pgm_re = re.compile(r"EXEC\s+PGM=([A-Z0-9#@$]+)", re.IGNORECASE)
    results = []
    for jcl_file in jcl_files:
        try:
            content = Path(jcl_file["path"]).read_text(encoding="utf-8", errors="replace")
            for m in pgm_re.finditer(content):
                prog = m.group(1).upper()
                if not prog.startswith("IEBG") and not prog.startswith("IEFBR"):  # skip IBM utilities
                    results.append({
                        "program":    prog,
                        "jcl_file":   jcl_file["relative"],
                        "target":     "celery_task",
                        "suggestion": f"Convert to a FastAPI background task or Celery worker: {prog.lower()}_task()",
                    })
        except Exception:
            continue
    return results


def _build_next_steps(cobol_programs, bms_screens, db2_files,
                       cics_transactions, unresolved_copies, ebcdic_count) -> list[str]:
    steps = []
    if ebcdic_count > 0:
        steps.append(
            f"🔴 URGENT: {ebcdic_count} file(s) are EBCDIC-encoded. "
            "Run convert_encoding on each before any parsing."
        )
    if unresolved_copies > 0:
        steps.append(
            f"🟡 {unresolved_copies} copybook(s) could not be found in the ZIP. "
            "Locate them (mainframe system libraries) and add to the workspace."
        )
    if cobol_programs:
        steps.append(
            f"➡  Send {len(cobol_programs)} COBOL program(s) to cobol-parser-mcp "
            "for AST extraction and business logic analysis."
        )
    if db2_files:
        steps.append(
            f"➡  Send {len(db2_files)} DB2 DDL file(s) to db2-schema-mcp "
            "to generate PostgreSQL migration scripts."
        )
    if bms_screens:
        steps.append(
            f"➡  Send {len(bms_screens)} BMS screen(s) to bms-to-angular-mcp "
            "to generate Angular component scaffolding."
        )
    if cics_transactions:
        steps.append(
            f"➡  Use the route_table ({len(cics_transactions)} transactions) "
            "to scaffold FastAPI endpoint stubs."
        )
    return steps


import re  # needed for _suggest_angular_component
