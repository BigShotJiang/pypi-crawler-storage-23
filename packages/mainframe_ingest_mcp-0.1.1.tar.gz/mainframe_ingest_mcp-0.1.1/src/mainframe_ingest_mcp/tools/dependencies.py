"""
Tool: scan_dependencies
Scan COBOL, JCL, and BMS files to build a cross-reference dependency graph.

Finds:
  • COPY <name>               → copybook references in COBOL
  • EXEC SQL INCLUDE <name>   → DB2 DCLGEN includes in COBOL
  • EXEC CICS SEND MAP(<n>)   → BMS screen send references
  • EXEC CICS RECEIVE MAP(<n>)→ BMS screen receive references
  • CALL '<program>'          → static COBOL program calls
  • EXEC CICS LINK PROGRAM(<n>) → dynamic CICS program links
  • EXEC CICS XCTL PROGRAM(<n>) → CICS program transfers
  • //xxx INCLUDE MEMBER=<n>  → JCL INCLUDE references
"""

import re
import logging
from pathlib import Path
from collections import defaultdict

logger = logging.getLogger(__name__)

# ── Regex patterns ────────────────────────────────────────────────────────────

# COBOL COPY — handles continuation lines and IN/OF library qualifiers
_COPY_RE = re.compile(
    r"^\s+COPY\s+([A-Z0-9#@$-]+)(?:\s+(?:IN|OF)\s+([A-Z0-9#@$-]+))?",
    re.MULTILINE | re.IGNORECASE,
)

# DB2 SQL INCLUDE (DCLGEN)
_SQL_INCLUDE_RE = re.compile(
    r"EXEC\s+SQL\s+INCLUDE\s+([A-Z0-9#@$-]+)",
    re.MULTILINE | re.IGNORECASE,
)

# CICS SEND MAP / RECEIVE MAP
_CICS_SEND_RE = re.compile(
    r"EXEC\s+CICS\s+SEND\s+MAP\s*\(\s*['\"]([A-Z0-9#@$]+)['\"]",
    re.MULTILINE | re.IGNORECASE,
)
_CICS_RECV_RE = re.compile(
    r"EXEC\s+CICS\s+RECEIVE\s+MAP\s*\(\s*['\"]([A-Z0-9#@$]+)['\"]",
    re.MULTILINE | re.IGNORECASE,
)
# Note: quotes are required around map names. MAP('SSHDMAP') is a literal
# map name we can resolve. MAP(COMM-MAP-ID) is a variable reference whose
# value can only be known at runtime — we skip those to avoid false warnings.

# CICS MAPSET(...) — identifies the mapset the map belongs to
_CICS_MAPSET_RE = re.compile(
    r"MAPSET\s*\(\s*['\"]?([A-Z0-9#@$-]+)['\"]?\s*\)",
    re.MULTILINE | re.IGNORECASE,
)

# Static COBOL CALL
_CALL_RE = re.compile(
    r"CALL\s+['\"]([A-Z0-9#@$-]+)['\"]",
    re.MULTILINE | re.IGNORECASE,
)

# CICS LINK / XCTL
_CICS_LINK_RE = re.compile(
    r"EXEC\s+CICS\s+(?:LINK|XCTL)\s+PROGRAM\s*\(\s*['\"]?([A-Z0-9#@$-]+)['\"]?\s*\)",
    re.MULTILINE | re.IGNORECASE,
)

# JCL INCLUDE
_JCL_INCLUDE_RE = re.compile(
    r"^//\w*\s+INCLUDE\s+MEMBER=([A-Z0-9#@$-]+)",
    re.MULTILINE | re.IGNORECASE,
)


def scan_dependencies(directory: str) -> dict:
    """
    Walk directory, scan every relevant file, return a dependency graph.
    """
    root = Path(directory)
    if not root.exists():
        return {"status": "error", "message": f"Directory not found: {directory}"}

    # ── Index: build lookup tables for quick resolution ───────────────────────
    copybook_index  = {}   # name.upper() → path
    program_index   = {}   # name.upper() → path
    bms_index       = {}   # mapset_name.upper() → path
    dclgen_index    = {}   # name.upper() → path

    # Pre-populate with bundled IBM system copybooks (DFHAID, SQLCA etc.)
    # These live in IBM system libraries on the mainframe and are never
    # included in application ZIPs, so we bundle them with the tool.
    _ibm_dir = Path(__file__).parent.parent / "ibm_copybooks"
    if _ibm_dir.exists():
        for _ibm_cpy in _ibm_dir.glob("*.cpy"):
            _stem = _ibm_cpy.stem.upper()
            copybook_index[_stem] = _ibm_cpy
            dclgen_index[_stem]   = _ibm_cpy

    for path in root.rglob("*"):
        if path.is_dir():
            continue
        stem = path.stem.upper()
        ext  = path.suffix.lower()
        if ext in (".cpy",):
            copybook_index[stem] = path
            # .cpy files in any directory can also be DCLGEN members
            # (e.g. include/WRKORDER.cpy, include/SQLCA.cpy)
            dclgen_index[stem] = path
        elif ext in (".cbl", ".cob", ".cobol"):
            program_index[stem] = path
        elif ext == ".bms":
            bms_index[stem] = path
        elif ext in (".inc", ".include"):
            dclgen_index[stem] = path

    # ── Scan each file ────────────────────────────────────────────────────────
    dep_graph   = {}   # relative_file_path → { copies, sql_includes, bms_maps, calls }
    warnings    = []
    stats       = defaultdict(int)

    for path in sorted(root.rglob("*")):
        if path.is_dir():
            continue
        ext      = path.suffix.lower()
        relative = str(path.relative_to(root))
        content  = _safe_read(path)
        if not content:
            continue

        file_deps = {}

        # COBOL files
        if ext in (".cbl", ".cob", ".cobol"):
            copies        = _scan_copy(content, copybook_index, relative, warnings)
            sql_includes  = _scan_sql_include(content, dclgen_index, relative, warnings)
            bms_sends     = _scan_bms_refs(content, "SEND",    bms_index, relative, warnings)
            bms_receives  = _scan_bms_refs(content, "RECEIVE", bms_index, relative, warnings)
            calls         = _scan_calls(content, program_index, relative, warnings)
            cics_links    = _scan_cics_links(content, program_index, relative, warnings)

            file_deps = {
                "type":         "COBOL_PROGRAM",
                "copies":       copies,
                "sql_includes": sql_includes,
                "bms_sends":    bms_sends,
                "bms_receives": bms_receives,
                "static_calls": calls,
                "cics_links":   cics_links,
            }
            stats["cobol_files"] += 1
            stats["copy_refs"]   += len(copies)
            stats["bms_refs"]    += len(bms_sends) + len(bms_receives)

        # JCL files
        elif ext == ".jcl":
            jcl_includes = _scan_jcl_includes(content, dclgen_index, relative, warnings)
            file_deps = {
                "type":         "JCL_JOB",
                "jcl_includes": jcl_includes,
            }
            stats["jcl_files"] += 1

        # BMS files — scan for DFHMDI map definitions so we know what maps exist
        elif ext == ".bms":
            maps_defined = _scan_bms_definitions(content)
            file_deps = {
                "type":         "BMS_SCREEN",
                "maps_defined": maps_defined,
            }
            stats["bms_files"] += 1

        if file_deps:
            dep_graph[relative] = file_deps

    # ── Invert: for each copybook, which programs use it? ─────────────────────
    copybook_used_by: dict[str, list] = defaultdict(list)
    for src_file, deps in dep_graph.items():
        for copy_ref in deps.get("copies", []):
            copybook_used_by[copy_ref["name"]].append(src_file)

    # ── High-severity warnings for common blockers ────────────────────────────
    unresolved_copybooks = [w for w in warnings if w.get("type") == "UNRESOLVED_COPYBOOK"]
    unresolved_bms       = [w for w in warnings if w.get("type") == "UNRESOLVED_BMS"]

    if unresolved_copybooks:
        warnings.insert(0, {
            "severity": "HIGH",
            "type":     "SUMMARY",
            "message":  (
                f"{len(unresolved_copybooks)} copybook(s) are referenced but not found in the codebase. "
                "These must be located before the AI can fully understand data structures."
            ),
        })

    return {
        "status":              "success",
        "directory":           str(root),
        "stats":               dict(stats),
        "dependency_graph":    dep_graph,
        "copybook_used_by":    dict(copybook_used_by),
        "warnings":            warnings,
        "unresolved_count": {
            "copybooks": len(unresolved_copybooks),
            "bms_maps":  len(unresolved_bms),
        },
        "next_step": "Run parse_csd_export (if a CSD file exists), then build_file_manifest.",
    }


# ── Scanners ──────────────────────────────────────────────────────────────────

def _scan_copy(content, index, src_file, warnings):
    refs = []
    for m in _COPY_RE.finditer(content):
        name    = m.group(1).upper()
        library = (m.group(2) or "").upper()
        resolved_path = index.get(name)
        entry = {
            "name":     name,
            "library":  library or None,
            "resolved": resolved_path is not None,
            "path":     str(resolved_path) if resolved_path else None,
        }
        if not resolved_path:
            warnings.append({
                "severity":    "HIGH" if not library else "MEDIUM",
                "type":        "UNRESOLVED_COPYBOOK",
                "copybook":    name,
                "referenced_in": src_file,
                "message":     f"Copybook '{name}' referenced in {src_file} but not found.",
            })
        refs.append(entry)
    return refs


def _scan_sql_include(content, index, src_file, warnings):
    refs = []
    for m in _SQL_INCLUDE_RE.finditer(content):
        name = m.group(1).upper()
        resolved_path = index.get(name)
        entry = {
            "name":     name,
            "type":     "DB2_DCLGEN",
            "resolved": resolved_path is not None,
            "path":     str(resolved_path) if resolved_path else None,
        }
        if not resolved_path:
            warnings.append({
                "severity":    "MEDIUM",
                "type":        "UNRESOLVED_SQL_INCLUDE",
                "include":     name,
                "referenced_in": src_file,
                "message":     f"SQL INCLUDE '{name}' in {src_file} not found. May be a DCLGEN member.",
            })
        refs.append(entry)
    return refs


def _scan_bms_refs(content, direction, bms_index, src_file, warnings):
    pattern = _CICS_SEND_RE if direction == "SEND" else _CICS_RECV_RE
    refs = []
    for m in pattern.finditer(content):
        map_name  = m.group(1).upper()
        # Try to find the mapset too
        mapset_match = _CICS_MAPSET_RE.search(content[max(0, m.start()-100):m.end()+100])
        mapset_name  = mapset_match.group(1).upper() if mapset_match else None
        resolved_path = bms_index.get(mapset_name or map_name)
        entry = {
            "map":       map_name,
            "mapset":    mapset_name,
            "direction": direction,
            "resolved":  resolved_path is not None,
            "path":      str(resolved_path) if resolved_path else None,
        }
        if not resolved_path:
            warnings.append({
                "severity":    "MEDIUM",
                "type":        "UNRESOLVED_BMS",
                "map":         map_name,
                "mapset":      mapset_name,
                "referenced_in": src_file,
                "message":     f"BMS map '{map_name}' (mapset {mapset_name}) used in {src_file} not found.",
            })
        refs.append(entry)
    return refs


def _scan_calls(content, program_index, src_file, warnings):
    refs = []
    for m in _CALL_RE.finditer(content):
        name = m.group(1).upper()
        resolved_path = program_index.get(name)
        refs.append({
            "program":  name,
            "resolved": resolved_path is not None,
            "path":     str(resolved_path) if resolved_path else None,
        })
    return refs


def _scan_cics_links(content, program_index, src_file, warnings):
    refs = []
    for m in _CICS_LINK_RE.finditer(content):
        name = m.group(1).upper()
        resolved_path = program_index.get(name)
        refs.append({
            "program":  name,
            "resolved": resolved_path is not None,
            "path":     str(resolved_path) if resolved_path else None,
        })
    return refs


def _scan_jcl_includes(content, index, src_file, warnings):
    refs = []
    for m in _JCL_INCLUDE_RE.finditer(content):
        name = m.group(1).upper()
        resolved_path = index.get(name)
        refs.append({
            "member":   name,
            "resolved": resolved_path is not None,
            "path":     str(resolved_path) if resolved_path else None,
        })
    return refs


def _scan_bms_definitions(content) -> list[dict]:
    """Extract map names from a BMS source file."""
    maps = []
    for m in re.finditer(r"^(\w+)\s+DFHMDI\b", content, re.MULTILINE | re.IGNORECASE):
        maps.append({"map_name": m.group(1).upper()})
    return maps


def _safe_read(path: Path) -> str:
    try:
        raw = path.read_bytes()
        try:
            return raw.decode("utf-8")
        except UnicodeDecodeError:
            return raw.decode("latin-1", errors="replace")
    except Exception:
        return ""
