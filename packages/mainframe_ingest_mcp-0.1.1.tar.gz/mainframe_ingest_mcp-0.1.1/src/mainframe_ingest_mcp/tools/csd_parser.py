"""
Tool: parse_csd_export
Parse a CICS System Definition (CSD) export file (text output of DFHCSDUP LIST).

The CSD is CICS's "registry" — it maps:
  transaction codes → programs    (e.g. PAYR → PAYRL001)
  programs          → attributes  (language, reload, etc.)
  files             → VSAM datasets
  mapsets           → BMS load modules

This parser works on the TEXT export produced by:
  DFHCSDUP LIST ALL      (lists everything)
  DFHCSDUP LIST GROUP(x) (lists a specific group)

Example CSD export snippet:
  DEFINE TRANSACTION(PAYR)
         PROGRAM(PAYRL001)
         TWASIZE(256)
         PROFILE(DFHCICST)

  DEFINE PROGRAM(PAYRL001)
         LANGUAGE(COBOL)
         RELOAD(NO)

  DEFINE FILE(EMPFILE)
         DSNAME(PROD.PAYROLL.EMPLOYEE.VSAM)
         RLSACCESS(NO)
"""

import re
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

# ── Patterns ──────────────────────────────────────────────────────────────────

_DEFINE_BLOCK_RE = re.compile(
    r"DEFINE\s+(\w+)\s*\(([^)]+)\)(.*?)(?=DEFINE\s+\w+\s*\(|\Z)",
    re.DOTALL | re.IGNORECASE,
)
_ATTR_RE = re.compile(r"(\w+)\s*\(([^)]*)\)", re.IGNORECASE)

# HTTP method heuristics from transaction code naming conventions
_TXN_READ_PREFIXES = {"INQ", "DSP", "LST", "QRY", "GET", "SHW", "VIW", "RPT", "ENQ"}
_TXN_DELETE_PREFIXES = {"DEL", "RMV", "PUR", "CAN", "CLR"}
_TXN_CREATE_PREFIXES = {"ADD", "CRT", "INS", "NEW", "REG", "ENT"}
_TXN_UPDATE_PREFIXES = {"UPD", "MOD", "CHG", "MNT", "EDT", "AMN"}


def parse_csd_export(file_path: str) -> dict:
    """
    Parse a CSD export text file and extract all resource definitions.
    """
    path = Path(file_path)
    if not path.exists():
        return {"status": "error", "message": f"File not found: {file_path}"}

    content = _safe_read(path)
    if not content:
        return {"status": "error", "message": f"File is empty or unreadable: {file_path}"}

    # Sanity check
    if "DEFINE" not in content.upper():
        return {
            "status":  "warning",
            "message": "File does not appear to be a CSD export (no DEFINE statements found).",
            "file":    str(path),
        }

    transactions = []
    programs     = []
    files        = []
    mapsets      = []
    others       = []

    for match in _DEFINE_BLOCK_RE.finditer(content):
        resource_type = match.group(1).upper()
        resource_name = match.group(2).strip().upper()
        attrs_block   = match.group(3)

        # Parse key(value) attributes from the block
        attrs = {}
        for attr_match in _ATTR_RE.finditer(attrs_block):
            key = attr_match.group(1).upper()
            val = attr_match.group(2).strip()
            attrs[key] = val

        if resource_type == "TRANSACTION":
            program = attrs.get("PROGRAM", "").upper()
            entry = {
                "transaction_code": resource_name,
                "program":          program,
                "profile":          attrs.get("PROFILE"),
                "twasize":          attrs.get("TWASIZE"),
                "taskdataloc":      attrs.get("TASKDATALOC"),
                "raw_attrs":        attrs,
            }
            # Suggest a FastAPI route
            entry["suggested_route"]  = _suggest_route(resource_name, program)
            entry["suggested_method"] = _suggest_http_method(resource_name)
            transactions.append(entry)

        elif resource_type == "PROGRAM":
            programs.append({
                "program_name": resource_name,
                "language":     attrs.get("LANGUAGE", "COBOL").upper(),
                "reload":       attrs.get("RELOAD", "NO").upper(),
                "resident":     attrs.get("RESIDENT", "NO").upper(),
                "raw_attrs":    attrs,
            })

        elif resource_type == "FILE":
            files.append({
                "file_name":    resource_name,
                "dsname":       attrs.get("DSNAME"),    # VSAM dataset name
                "rlsaccess":    attrs.get("RLSACCESS", "NO").upper(),
                "servreq":      attrs.get("SERVREQ"),
                "raw_attrs":    attrs,
                "modernization_note": (
                    "This VSAM file should be migrated to a PostgreSQL table. "
                    "Use the DSNAME and record layout from the COBOL FD entry."
                ),
            })

        elif resource_type == "MAPSET":
            mapsets.append({
                "mapset_name":  resource_name,
                "resident":     attrs.get("RESIDENT", "NO").upper(),
                "raw_attrs":    attrs,
                "modernization_note": (
                    "This BMS mapset should be converted to Angular components. "
                    "One Angular component per MAP within the mapset."
                ),
            })

        else:
            others.append({
                "type":  resource_type,
                "name":  resource_name,
                "attrs": attrs,
            })

    # ── Build route table ─────────────────────────────────────────────────────
    route_table = [
        {
            "transaction_code": t["transaction_code"],
            "program":          t["program"],
            "http_method":      t["suggested_method"],
            "fastapi_route":    t["suggested_route"],
        }
        for t in transactions
        if t["program"]
    ]

    return {
        "status":        "success",
        "file":          str(path),
        "summary": {
            "transactions": len(transactions),
            "programs":     len(programs),
            "files":        len(files),
            "mapsets":      len(mapsets),
            "other":        len(others),
        },
        "transactions":  transactions,
        "programs":      programs,
        "files":         files,
        "mapsets":       mapsets,
        "other_resources": others,
        "route_table":   route_table,
        "next_step":     "Call build_file_manifest to assemble the complete handoff document.",
    }


# ── Route suggestion helpers ──────────────────────────────────────────────────

def _suggest_route(txn_code: str, program: str) -> str:
    """
    Heuristically suggest a FastAPI route path from the transaction code.

    Convention: PAYR → /api/payroll, EMPI → /api/employee/{id}
    """
    code = txn_code.upper()
    prog = program.upper()

    # Try to extract a domain word from program name (strip numeric suffix)
    domain_match = re.match(r"([A-Z]{3,})", prog)
    domain = domain_match.group(1).lower() if domain_match else code[:4].lower()

    # Map common abbreviations to full words
    abbreviations = {
        "payr": "payroll", "pay":  "payroll",
        "emp":  "employee","empl": "employee",
        "cust": "customer","cus":  "customer",
        "acct": "account", "acc":  "account",
        "ord":  "order",   "ordr": "order",
        "inv":  "invoice", "invx": "invoice",
        "inq":  "inquiry", "rpt":  "report",
        "mnt":  "maintenance",
    }
    for abbr, full in abbreviations.items():
        if domain.startswith(abbr):
            domain = full
            break

    method = _suggest_http_method(code)
    if method in ("GET",):
        return f"/api/{domain}/{{id}}"
    return f"/api/{domain}"


def _suggest_http_method(txn_code: str) -> str:
    """Heuristically map a 4-char CICS transaction code to an HTTP method."""
    prefix = txn_code[:3].upper()
    if prefix in _TXN_READ_PREFIXES:
        return "GET"
    if prefix in _TXN_DELETE_PREFIXES:
        return "DELETE"
    if prefix in _TXN_CREATE_PREFIXES:
        return "POST"
    if prefix in _TXN_UPDATE_PREFIXES:
        return "PUT"
    return "POST"  # safe default for unknown transactions


def _safe_read(path: Path) -> str:
    try:
        raw = path.read_bytes()
        try:
            return raw.decode("utf-8")
        except UnicodeDecodeError:
            return raw.decode("latin-1", errors="replace")
    except Exception:
        return ""
