"""
zip-ingestion-mcp — COBOL Codebase Onboarding Server
=====================================================
An MCP server that ingests ZIP files (or prepared directories) containing
mainframe COBOL source code and produces a structured manifest that all
downstream MCP servers (cobol-parser, bms-to-angular, etc.) consume.

Tools exposed:
  1. extract_zip          – unzip and organise the codebase
  2. detect_all_artifacts – classify every file by type
  3. detect_encoding      – detect EBCDIC vs ASCII on a single file
  4. convert_encoding     – convert EBCDIC → UTF-8 in-place
  5. scan_dependencies    – find COPY / INCLUDE / BMS refs inside source files
  6. parse_csd_export     – extract CICS transaction & program definitions
  7. build_file_manifest  – produce the final JSON inventory (the "handoff doc")
"""

import json
import logging
import sys
from pathlib import Path

# FastMCP is the high-level decorator-based API on top of the official MCP SDK.
# `pip install mcp` gives you both mcp and mcp.server.fastmcp.
from mcp.server.fastmcp import FastMCP

from .tools.extractor    import extract_zip
from .tools.classifier   import detect_all_artifacts
from .tools.encoding     import detect_encoding, convert_encoding
from .tools.dependencies import scan_dependencies
from .tools.csd_parser   import parse_csd_export
from .tools.manifest     import build_file_manifest

# ── Logging ──────────────────────────────────────────────────────────────────
# IMPORTANT: MCP STDIO transport uses stdout for JSON-RPC messages.
# ALL logging MUST go to stderr, never stdout.
logging.basicConfig(
    stream=sys.stderr,
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("zip-ingestion-mcp")

# ── Server instance ───────────────────────────────────────────────────────────
mcp = FastMCP(
    "zip-ingestion-mcp",
    instructions=(
        "Use this server to ingest a COBOL mainframe codebase from a ZIP file. "
        "Typical workflow:\n"
        "  1. extract_zip        → unpack the archive\n"
        "  2. detect_all_artifacts → classify every file\n"
        "  3. convert_encoding   → fix any EBCDIC files\n"
        "  4. scan_dependencies  → resolve COPY/INCLUDE/BMS refs\n"
        "  5. parse_csd_export   → extract CICS transaction routing\n"
        "  6. build_file_manifest → produce the final handoff JSON\n"
    ),
)

# ── Tool registrations ────────────────────────────────────────────────────────
# Each @mcp.tool() decorated function is automatically discovered and exposed
# to any MCP client (Claude Desktop, Claude Code, your own pipeline, etc.).


@mcp.tool()
def tool_extract_zip(zip_path: str, target_dir: str) -> str:
    """
    Extract a ZIP file containing a COBOL mainframe codebase.

    Args:
        zip_path:   Absolute path to the .zip file to extract.
        target_dir: Absolute path to the directory where files will be placed.
                    Will be created if it does not exist.

    Returns:
        JSON string with extraction summary (file count, warnings, etc.).
    """
    logger.info("extract_zip called: %s → %s", zip_path, target_dir)
    result = extract_zip(zip_path, target_dir)
    return json.dumps(result, indent=2)


@mcp.tool()
def tool_detect_all_artifacts(directory: str) -> str:
    """
    Walk a directory and classify every file by its mainframe artifact type.

    Recognised types:
      COBOL_PROGRAM, COPYBOOK, BMS_COPYBOOK, BMS_SCREEN,
      JCL_JOB, DB2_DDL, CSD_EXPORT, SQL_INCLUDE, JCL_INCLUDE, UNKNOWN

    Args:
        directory: Absolute path to the root of the extracted codebase.

    Returns:
        JSON string with a list of classified file entries.
    """
    logger.info("detect_all_artifacts called: %s", directory)
    result = detect_all_artifacts(directory)
    return json.dumps(result, indent=2)


@mcp.tool()
def tool_detect_encoding(file_path: str) -> str:
    """
    Detect whether a file is EBCDIC-encoded (IBM mainframe) or ASCII/UTF-8.

    Args:
        file_path: Absolute path to the file to inspect.

    Returns:
        JSON string: { detected_encoding, confidence, readable, recommendation }
    """
    logger.info("detect_encoding called: %s", file_path)
    result = detect_encoding(file_path)
    return json.dumps(result, indent=2)


@mcp.tool()
def tool_convert_encoding(file_path: str, from_encoding: str, to_encoding: str) -> str:
    """
    Convert a file's character encoding (e.g. EBCDIC cp037 → UTF-8).

    The converted content overwrites the original file.
    A backup is saved as <file_path>.bak before conversion.

    Common EBCDIC codepages:
      cp037  – US/Canada English
      cp500  – International
      cp1047 – Open Systems (Linux on z)

    Args:
        file_path:     Absolute path to the file.
        from_encoding: Source encoding (e.g. "cp037").
        to_encoding:   Target encoding (e.g. "utf-8").

    Returns:
        JSON string with conversion status and byte counts.
    """
    logger.info("convert_encoding called: %s (%s → %s)", file_path, from_encoding, to_encoding)
    result = convert_encoding(file_path, from_encoding, to_encoding)
    return json.dumps(result, indent=2)


@mcp.tool()
def tool_scan_dependencies(directory: str) -> str:
    """
    Scan all COBOL, JCL, and BMS files in a directory to build a dependency graph.

    Finds:
      • COPY <name>         → copybook references in COBOL
      • EXEC SQL INCLUDE    → DB2 DCLGEN includes in COBOL
      • EXEC CICS SEND MAP  → BMS screen references in COBOL
      • EXEC CICS RECEIVE MAP
      • INCLUDE MEMBER=     → JCL include references

    For each reference, it attempts to locate the target file in the directory.
    Unresolved references are flagged with severity MEDIUM or HIGH.

    Args:
        directory: Absolute path to the root of the extracted codebase.

    Returns:
        JSON string with the full dependency graph and unresolved warnings.
    """
    logger.info("scan_dependencies called: %s", directory)
    result = scan_dependencies(directory)
    return json.dumps(result, indent=2)


@mcp.tool()
def tool_parse_csd_export(file_path: str) -> str:
    """
    Parse a CICS System Definition (CSD) export file (text format from DFHCSDUP LIST).

    Extracts:
      • TRANSACTION definitions → maps txn codes to program names
      • PROGRAM definitions     → language, attributes
      • FILE definitions        → VSAM dataset names
      • MAPSET definitions      → BMS mapset registrations

    Also generates suggested FastAPI route names from each transaction code.

    Args:
        file_path: Absolute path to the CSD export text file.

    Returns:
        JSON string with transactions, programs, files, and suggested routes.
    """
    logger.info("parse_csd_export called: %s", file_path)
    result = parse_csd_export(file_path)
    return json.dumps(result, indent=2)


@mcp.tool()
def tool_build_file_manifest(directory: str, source_zip: str = "") -> str:
    """
    Build the complete file manifest for a COBOL codebase directory.

    This is the PRIMARY output of the ingestion server. It calls all other
    tools internally and assembles a single JSON document that downstream
    servers (cobol-parser-mcp, bms-to-angular-mcp, etc.) consume.

    The manifest includes:
      • Full classified file list with encoding status
      • Copybook dependency graph
      • BMS screen → Angular component mapping hints
      • CICS transaction → FastAPI route mapping hints
      • SQL INCLUDE / DCLGEN resolutions
      • All warnings (missing copybooks, EBCDIC files, unresolved deps)

    Args:
        directory:  Absolute path to the root of the extracted codebase.
        source_zip: (Optional) Original ZIP file path, recorded in manifest metadata.

    Returns:
        JSON string — the complete manifest. Save this as manifest.json.
    """
    logger.info("build_file_manifest called: %s", directory)
    result = build_file_manifest(directory, source_zip)
    return json.dumps(result, indent=2)


# ── Entry point ───────────────────────────────────────────────────────────────
def main():
    """CLI entry point — called when user runs: zip-ingestion-mcp"""
    mcp.run(transport="stdio")

if __name__ == "__main__":
    main()
