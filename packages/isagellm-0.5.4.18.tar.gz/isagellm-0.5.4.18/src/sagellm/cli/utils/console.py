"""Rich console utilities."""

# Lazy import rich for faster CLI startup
_console = None


def get_console():
    """Get rich console with lazy import."""
    global _console
    if _console is None:
        from rich.console import Console

        _console = Console()
    return _console
