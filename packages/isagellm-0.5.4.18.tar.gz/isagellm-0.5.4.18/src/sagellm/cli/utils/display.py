"""Display utilities for CLI."""

from .console import get_console

# Version from package
try:
    from sagellm import __version__
except ImportError:
    __version__ = "0.1.0"


def show_welcome_message(cli_name: str = "sagellm") -> None:
    """Show welcome message with supported backends when running CLI without subcommand."""
    console = get_console()

    console.print()
    console.print(f"[bold blue]🚀 sageLLM v{__version__}[/bold blue]")
    console.print("[dim]Modular LLM inference engine for domestic computing power[/dim]")
    console.print()

    # Show supported backends
    console.print("[bold]Supported backends (按优先级排序):[/bold]")
    console.print()
    console.print("  [cyan]国产芯片 (Domestic):[/cyan]")
    console.print("    [green]ascend[/green]     华为昇腾 Ascend NPU    [dim](priority: 100)[/dim]")
    console.print("    [green]kunlun[/green]     百度昆仑 Kunlun XPU    [dim](priority: 90)[/dim]")
    console.print("    [green]haiguang[/green]   海光 DCU               [dim](priority: 85)[/dim]")
    console.print("    [green]muxi[/green]       沐曦 Muxi GPU          [dim](priority: 80)[/dim]")
    console.print()
    console.print("  [cyan]NVIDIA:[/cyan]")
    console.print("    [green]cuda[/green]       NVIDIA CUDA 12.1       [dim](priority: 50)[/dim]")
    console.print(
        "    [green]cuda11[/green]     NVIDIA CUDA 11.8       [dim](for older drivers)[/dim]"
    )
    console.print()
    console.print("  [cyan]CPU:[/cyan]")
    console.print(
        "    [green]cpu[/green]        CPU only               [dim](priority: 10, fallback)[/dim]"
    )
    console.print()

    # Quick start
    console.print("[bold]Quick start:[/bold]")
    console.print()
    console.print(f"  [cyan]{cli_name} install cuda[/cyan]     # 安装 NVIDIA CUDA 支持")
    console.print(f"  [cyan]{cli_name} install ascend[/cyan]   # 安装华为昇腾支持")
    console.print(f"  [cyan]{cli_name} hello[/cyan]            # 🚀 一键测试推理")
    console.print(f"  [cyan]{cli_name} run -p 'Hello!'[/cyan]  # 运行推理")
    console.print(f"  [cyan]{cli_name} info[/cyan]             # 查看系统信息")
    console.print()

    console.print(f"[dim]Run '{cli_name} --help' for all commands.[/dim]")
    console.print()
