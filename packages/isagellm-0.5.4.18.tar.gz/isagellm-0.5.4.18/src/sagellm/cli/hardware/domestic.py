"""Domestic chip hardware detection (Kunlun, Haiguang, Muxi)."""


def check_kunlun_available() -> tuple[bool, str]:
    """Check if Kunlun XPU is available."""
    try:
        # Kunlun uses XPU device
        import torch
        import torch_xmlir  # noqa: F401

        if hasattr(torch, "xpu") and torch.xpu.is_available():
            return True, "✅ Kunlun XPU ready"
        return False, "❌ Kunlun XPU not detected"
    except ImportError:
        return False, "❌ torch_xmlir not installed"
    except Exception as e:
        return False, f"❌ Error: {e}"


def check_haiguang_available() -> tuple[bool, str]:
    """Check if Haiguang DCU is available."""
    try:
        import torch

        # Haiguang DCU uses ROCm/HIP, appears as CUDA device
        if torch.cuda.is_available():
            device_name = torch.cuda.get_device_name(0).lower()
            if "dcu" in device_name or "hygon" in device_name or "gfx" in device_name:
                return True, f"✅ Haiguang DCU ready: {torch.cuda.get_device_name(0)}"
        return False, "❌ Haiguang DCU not detected"
    except ImportError:
        return False, "❌ PyTorch not installed"
    except Exception as e:
        return False, f"❌ Error: {e}"


def check_muxi_available() -> tuple[bool, str]:
    """Check if Muxi GPU is available."""
    try:
        import torch
        import torch_muxi  # noqa: F401

        if hasattr(torch, "muxi") and torch.muxi.is_available():
            device_count = torch.muxi.device_count()
            return True, f"✅ Muxi GPU ready ({device_count} device(s))"
        return False, "❌ Muxi GPU not detected"
    except ImportError:
        return False, "❌ torch_muxi not installed"
    except Exception as e:
        return False, f"❌ Error: {e}"
