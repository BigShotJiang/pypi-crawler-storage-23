"""sage-llm CLI: Ollama-style command-line interface for sageLLM.

This module provides backward compatibility by importing from the refactored CLI structure.
All functionality has been moved to modular subpackages under sagellm.cli/

New structure:
    sagellm/cli/
        ├── main.py           # CLI entry point
        ├── commands/         # Command modules
        ├── utils/            # Utilities (console, config, backend, display)
        └── hardware/         # Hardware detection

Usage:
    sage-llm info                    # Show system info
    sage-llm serve                   # Start inference server
    sage-llm run -p "prompt"          # Single inference
    sage-llm demo --workload year1   # Run demo validation
    sage-llm config [show|reset]     # Manage configuration

Examples:
    $ sage-llm info
    $ sage-llm serve --port 8000
    $ sage-llm run -p "Hello world"
    $ sage-llm demo --workload year1 --output metrics.json
"""

from __future__ import annotations

# Import main entry point from refactored CLI
from .cli.main import main

# Re-export for backward compatibility
__all__ = ["main"]

# Legacy imports for backward compatibility (will be deprecated)

# Version
try:
    from sagellm import __version__
except ImportError:
    __version__ = "0.1.0"


if __name__ == "__main__":
    main()
