class AbstractDatasetPrior:
    def new_dataset(self) -> None:
        raise NotImplementedError
