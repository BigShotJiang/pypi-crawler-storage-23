const s=!1;export{s as D};
