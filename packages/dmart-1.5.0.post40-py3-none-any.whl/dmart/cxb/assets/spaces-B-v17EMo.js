import{w as s}from"./svelte-CkHOYXft.js";const o=s(null);export{o as s};
