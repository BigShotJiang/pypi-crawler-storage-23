"""Attachment tracker for detecting duplicate content using URL, SHA-256, and dHash."""

import sqlite3
from datetime import datetime
from datetime import timedelta
from pathlib import Path
from typing import NamedTuple

from loguru import logger as log

RETENTION_DAYS: int = 90


class AttachmentRecord(NamedTuple):
    """Record of a tracked attachment."""

    url: str
    content_hash: str | None
    dhash: str | None
    media_type: str | None
    boosted_post_id: str
    first_seen: datetime
    last_seen: datetime


class AttachmentTracker:
    """Track attachments to prevent re-boosting duplicate content.

    Uses a 3-tier approach:
    1. URL check (fast, catches exact URL matches)
    2. SHA-256 hash (detects identical content)
    3. dHash (detects visually similar images)

    Records are kept for RETENTION_DAYS (default 90 days).
    """

    def __init__(self, db_path: Path | str = "cache.db") -> None:
        """Initialize attachment tracker with SQLite database.

        Args:
            db_path: Path to SQLite database file

        """
        self.db_path = Path(db_path)
        self._initialize_db()

    def _initialize_db(self) -> None:
        """Create tables if they don't exist."""
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS boosted_attachments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    url TEXT NOT NULL UNIQUE,
                    content_hash TEXT,
                    dhash TEXT,
                    media_type TEXT,
                    boosted_post_id TEXT NOT NULL,
                    first_seen TEXT NOT NULL,
                    last_seen TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_content_hash
                ON boosted_attachments(content_hash)
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_dhash
                ON boosted_attachments(dhash)
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_first_seen
                ON boosted_attachments(first_seen)
                """
            )
            conn.commit()
        finally:
            conn.close()

    async def check_attachment(
        self,
        url: str,
        content_hash: str | None = None,
        dhash: str | None = None,
    ) -> AttachmentRecord | None:
        """Check if attachment has been boosted before.

        Checks in order:
        1. URL match
        2. Content hash match
        3. dHash match (if both provided and within threshold)

        Args:
            url: Media attachment URL
            content_hash: SHA-256 hash of attachment content
            dhash: Perceptual hash of image (if available)

        Returns:
            AttachmentRecord if found (duplicate), None otherwise.

        """
        conn = sqlite3.connect(self.db_path)
        try:
            # Check 1: URL match
            cursor = conn.execute(
                "SELECT * FROM boosted_attachments WHERE url = ?",
                (url,),
            )
            row = cursor.fetchone()
            if row:
                return self._row_to_record(row)

            # Check 2: Content hash match (if provided)
            if content_hash:
                cursor = conn.execute(
                    "SELECT * FROM boosted_attachments WHERE content_hash = ?",
                    (content_hash,),
                )
                row = cursor.fetchone()
                if row:
                    return self._row_to_record(row)

            # Check 3: dHash match (if provided)
            if dhash:
                cursor = conn.execute(
                    "SELECT * FROM boosted_attachments WHERE dhash = ?",
                    (dhash,),
                )
                row = cursor.fetchone()
                if row:
                    return self._row_to_record(row)

            return None
        finally:
            conn.close()

    async def record_attachment(
        self,
        url: str,
        boosted_post_id: str,
        content_hash: str | None = None,
        dhash: str | None = None,
        media_type: str | None = None,
    ) -> None:
        """Record an attachment as boosted.

        Args:
            url: Media attachment URL
            boosted_post_id: ID of post this attachment was boosted with
            content_hash: SHA-256 hash of attachment content
            dhash: Perceptual hash of image
            media_type: MIME type of attachment

        """
        now = datetime.now().isoformat()

        conn = sqlite3.connect(self.db_path)
        try:
            try:
                conn.execute(
                    """
                    INSERT INTO boosted_attachments
                    (url, content_hash, dhash, media_type, boosted_post_id, first_seen, last_seen)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (url, content_hash, dhash, media_type, boosted_post_id, now, now),
                )
            except sqlite3.IntegrityError:
                # URL already exists, update last_seen
                conn.execute(
                    "UPDATE boosted_attachments SET last_seen = ? WHERE url = ?",
                    (now, url),
                )
            conn.commit()
            log.debug(f"Recorded attachment: {url} for post {boosted_post_id}")
        finally:
            conn.close()

    async def cleanup_old_records(self) -> int:
        """Remove attachment records older than RETENTION_DAYS.

        Returns:
            Number of records deleted.

        """
        cutoff_date = (datetime.now() - timedelta(days=RETENTION_DAYS)).isoformat()

        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.execute(
                "DELETE FROM boosted_attachments WHERE first_seen < ?",
                (cutoff_date,),
            )
            deleted_count = cursor.rowcount
            conn.commit()
        finally:
            conn.close()

        if deleted_count > 0:
            log.info(f"Cleaned up {deleted_count} old attachment records")

        return deleted_count

    def _row_to_record(self, row: tuple) -> AttachmentRecord:
        """Convert database row to AttachmentRecord.

        Args:
            row: Database row tuple

        Returns:
            AttachmentRecord instance

        """
        return AttachmentRecord(
            url=row[1],
            content_hash=row[2],
            dhash=row[3],
            media_type=row[4],
            boosted_post_id=row[5],
            first_seen=datetime.fromisoformat(row[6]),
            last_seen=datetime.fromisoformat(row[7]),
        )
