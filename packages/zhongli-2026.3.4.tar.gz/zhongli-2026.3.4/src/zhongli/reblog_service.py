"""Service for reblogging operations with retry logic and circuit breaker protection."""

import stamina
from httpx import AsyncClient
from loguru import logger as log
from minimal_activitypub.client_2_server import ActivityPub
from minimal_activitypub.client_2_server import ConflictError
from minimal_activitypub.client_2_server import ForbiddenError
from minimal_activitypub.client_2_server import GoneError
from minimal_activitypub.client_2_server import NetworkError
from minimal_activitypub.client_2_server import SearchType
from minimal_activitypub.client_2_server import Status
from minimal_activitypub.client_2_server import UnprocessedError
from pybreaker import CircuitBreakerError

from zhongli.circuit_breaker import circuit_protected_call


class ReblogService:
    """Service for reblogging operations with built-in retry and circuit breaker protection.

    Encapsulates the logic for:
    - Finding status by URL
    - Reblogging with retry logic
    - Handling errors appropriately
    """

    def __init__(self, instance: ActivityPub, client: AsyncClient) -> None:
        """Initialize ReblogService.

        Args:
            instance: ActivityPub instance for interacting with the Fediverse
            client: AsyncClient for HTTP requests

        """
        self.instance = instance
        self.client = client

    async def find_status_by_url(self, status_url: str) -> Status | None:
        """Search for a status by URL and return the status dict if found.

        Args:
            status_url: URL of the status to find

        Returns:
            Status object if found, None otherwise.

        """
        search_result = await self.instance.search(query=status_url, query_type=SearchType.STATUSES, resolve=True)
        statuses = search_result.get("statuses")
        return statuses[0] if statuses else None

    async def reblog_status(self, status_id: str, status_url: str) -> tuple[bool, bool]:
        """Attempt to reblog a status with retry logic and circuit breaker protection.

        Returns a tuple of (success, should_record).
        - success: True if reblog was successful
        - should_record: True if status should be recorded (success or permanent failure)

        Args:
            status_id: ID of the status to reblog
            status_url: URL of the status (for logging)

        Returns:
            Tuple of (success, should_record).

        """

        @circuit_protected_call("reblog_operation", operation_description=f"reblogging status {status_url}")
        async def protected_reblog():
            retry_caller = stamina.AsyncRetryingCaller(attempts=3)
            try:
                await retry_caller(NetworkError, self.instance.reblog, status_id=status_id)
            except (ForbiddenError, GoneError, ConflictError, UnprocessedError) as error:
                log.opt(colors=True).info(f"<cyan>{status_url}</> <red>NOT</> boosted... got {error}")
                return False, True  # Permanent failure, record to avoid retrying
            except NetworkError:
                # NetworkError will be raised after all retries fail
                return False, False  # Transient failure, don't record
            else:
                log.opt(colors=True).info(f"Boosted <cyan>{status_url}</>")
                return True, True  # Success, record

        try:
            return await protected_reblog()
        except CircuitBreakerError:
            # Circuit breaker is OPEN for reblog operations
            log.warning(f"Circuit breaker OPEN for reblog operations, skipping {status_url}")
            return False, False  # Treat as transient failure, don't record

    async def attempt_boost(self, status_url: str) -> tuple[bool, bool] | None:
        """Attempt to boost a status by finding it first, then reblogging.

        This orchestrates the boosting process by:
        1. Searching for the status by URL
        2. Attempting to reblog it with retry logic
        3. Returning results appropriately

        Args:
            status_url: URL of the status to boost

        Returns:
            Tuple of (success, should_record) if status was found, None otherwise.
            - success: True if reblog was successful
            - should_record: True if status should be recorded

        """
        status_to_reblog = await self.find_status_by_url(status_url=status_url)

        if not status_to_reblog:
            return None

        reblog_id = status_to_reblog.get("id")
        if not reblog_id:
            return None

        return await self.reblog_status(status_id=reblog_id, status_url=status_url)
