# Zhongli

Automatically boost/reblog Fediverse posts. Formerly **Fedibooster**.

[![Repo](https://img.shields.io/badge/repo-Codeberg.org-blue)](https://codeberg.org/MarvinsMastodonTools/zhongli) [![CI](https://ci.codeberg.org/api/badges/13923/status.svg)](https://ci.codeberg.org/repos/13923) [![Downloads](https://pepy.tech/badge/zhongli)](https://pepy.tech/project/zhongli) [![AGPL](https://www.gnu.org/graphics/agplv3-with-text-162x68.png)](https://codeberg.org/MarvinsMastodonTools/zhongli/src/branch/main/LICENSE.md)

## Modes

- **FenLiu Mode** (recommended): Consumes pre-filtered posts from [FenLiu](https://codeberg.org/marvinsmastodontools/fenliu) queue
- **Legacy Mode**: Searches independently for posts with specified hashtags

## Status

| Phase | Status | Notes |
|-------|--------|-------|
| 1: Infrastructure | ✅ Complete | FenLiu client, models, tests |
| 2: Dual-Mode | ✅ Complete | Feature flag, ReblogService, queue polling |
| 3: Simplify Validation | ⏳ Ready | Deprecate complex filters |
| 4: Remove Legacy | ⏳ Pending | Breaking changes |
| 5: UX Polish | ⏳ Optional | Metrics, dry-run, progress |

## Install

```bash
pip install zhongli
```

Or from source:
```bash
git clone https://codeberg.org/marvinsmastodontools/zhongli.git
cd zhongli
uv sync
uv run zhongli
```

## Configuration

FenLiu mode:
```toml
[fediverse]
domain_name = "mastodon.social"
api_token = "your-token"

[zhongli]
run_continuously = true
delay_between_posts = 60
max_reblog = 5

[fenliu]
enabled = true
base_url = "https://fenliu.example.com"
api_key = "your-key"
```

Legacy mode:
```toml
[fenliu]
enabled = false

[zhongli]
search_tags_list = ["fediverse"]
```

## Usage

```bash
zhongli              # Run in configured mode
zhongli --dry-run    # Preview without boosting
zhongli --help       # Show options
```

## Development

```bash
uv sync              # Install deps
prek run --all-files # Pre-commit checks
pytest               # Run tests
nox                  # Full CI simulation
```

## Recent Work

- ✅ Phase 2: Dual-mode execution fully operational
- ✅ Phase 1: FenLiu infrastructure complete
- ✅ Circuit breaker pattern integrated
- ✅ Typer → Cyclopts CLI migration

## Roadmap

See [ROADMAP.md](ROADMAP.md) and [FENLIU_MIGRATION_PLAN.md](FENLIU_MIGRATION_PLAN.md)

## License

[GNU AGPL v3.0](http://www.gnu.org/licenses/agpl-3.0.html)

## Support

- [Buy me coffee](https://www.buymeacoffee.com/marvin8)
- Monero: `88xtj3hqQEpXrb5KLCigRF1azxDh8r9XvYZPuXwaGaX5fWtgub1gQsn8sZCmEGhReZMww6RRaq5HZ48HjrNqmeccUHcwABg`
