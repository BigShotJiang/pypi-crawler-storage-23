"""Debug logging for Configuration Explorer.

Provides structured debug logging for diagnosing config change flow issues.
Enable via `obra config --debug` flag.

Debug Output Levels:
- Normal mode: Errors only (to stderr)
- Debug mode: Full trace of message flow, set_value calls, and pending changes

Log File: ~/.obra/logs/config-explorer.log (when debug enabled)
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from obra.config.explorer.models import ConfigTree

# Module-level debug state
_debug_enabled = False
_debug_logger: logging.Logger | None = None
_session_id: str = ""


def enable_debug_logging() -> tuple[str, Path]:
    """Enable debug logging for config explorer.

    Creates a file handler at ~/.obra/logs/config-explorer.log
    and sets log level to DEBUG for the config.explorer namespace.

    Returns:
        Tuple of (session_id, log_file_path) for display to user.
    """
    global _debug_enabled, _debug_logger, _session_id

    _debug_enabled = True
    _session_id = uuid.uuid4().hex[:8]  # Short unique session ID

    # Create log directory
    log_dir = Path.home() / ".obra" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    log_file = log_dir / "config-explorer.log"

    # Configure logger
    _debug_logger = logging.getLogger("obra.config.explorer")
    _debug_logger.setLevel(logging.DEBUG)

    # Clear existing handlers to avoid duplicates
    _debug_logger.handlers.clear()

    # File handler with detailed format including session ID
    file_handler = logging.FileHandler(log_file, mode="a", encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(
        logging.Formatter(
            f"%(asctime)s.%(msecs)03d | {_session_id} | %(levelname)-5s | %(message)s",
            datefmt="%H:%M:%S",
        )
    )
    _debug_logger.addHandler(file_handler)

    # Log session start
    _debug_logger.info("=" * 70)
    _debug_logger.info("Session %s started at %s", _session_id, datetime.now().isoformat())
    _debug_logger.info("Log file: %s", log_file)
    _debug_logger.info("=" * 70)

    return _session_id, log_file


def is_debug_enabled() -> bool:
    """Check if debug logging is enabled."""
    return _debug_enabled


def log_message_received(handler_name: str, event_attrs: dict[str, Any]) -> None:
    """Log when a message handler is invoked.

    Args:
        handler_name: Name of the handler method
        event_attrs: Dict of event attributes to log
    """
    if not _debug_enabled or not _debug_logger:
        return

    attr_str = ", ".join(f"{k}={v!r}" for k, v in event_attrs.items())
    _debug_logger.debug("MSG_RECV | %s | %s", handler_name, attr_str)


def log_set_value(path: str, old_value: Any, new_value: Any, success: bool) -> None:
    """Log a set_value operation.

    Args:
        path: Config path being set
        old_value: Previous value
        new_value: New value being set
        success: Whether set_value returned True
    """
    if not _debug_enabled or not _debug_logger:
        return

    status = "OK" if success else "FAILED"
    _debug_logger.debug(
        "SET_VALUE | %s | %s | old=%r -> new=%r",
        status,
        path,
        old_value,
        new_value,
    )


def log_get_node(path: str, found: bool, node_info: str | None = None) -> None:
    """Log a get_node operation.

    Args:
        path: Config path being looked up
        found: Whether the node was found
        node_info: Optional info about the found node
    """
    if not _debug_enabled or not _debug_logger:
        return

    status = "FOUND" if found else "NOT_FOUND"
    if node_info:
        _debug_logger.debug("GET_NODE | %s | %s | %s", status, path, node_info)
    else:
        _debug_logger.debug("GET_NODE | %s | %s", status, path)


def log_pending_changes(config_tree: ConfigTree | None, context: str) -> None:
    """Log current pending changes state.

    Args:
        config_tree: The ConfigTree to inspect
        context: Description of when this is being logged
    """
    if not _debug_enabled or not _debug_logger:
        return

    if config_tree is None:
        _debug_logger.debug("PENDING | %s | config_tree=None", context)
        return

    count = config_tree.pending_count
    if count == 0:
        _debug_logger.debug("PENDING | %s | count=0 (empty)", context)
    else:
        _debug_logger.debug("PENDING | %s | count=%d", context, count)
        for path, (old, new) in config_tree.pending_changes.items():
            _debug_logger.debug("  -> %s: %r -> %r", path, old, new)


def log_action(action_name: str, details: str = "") -> None:
    """Log a user action.

    Args:
        action_name: Name of the action (e.g., 'save', 'discard')
        details: Optional details about the action
    """
    if not _debug_enabled or not _debug_logger:
        return

    if details:
        _debug_logger.debug("ACTION | %s | %s", action_name, details)
    else:
        _debug_logger.debug("ACTION | %s", action_name)


def log_tree_rebuild(reason: str) -> None:
    """Log when the config tree is rebuilt.

    Args:
        reason: Why the tree is being rebuilt
    """
    if not _debug_enabled or not _debug_logger:
        return

    _debug_logger.debug("TREE_REBUILD | %s", reason)


def log_view_mount(view_name: str, initial_values: dict[str, Any] | None = None) -> None:
    """Log when a view is mounted.

    Args:
        view_name: Name of the view being mounted
        initial_values: Optional dict of initial values passed to the view
    """
    if not _debug_enabled or not _debug_logger:
        return

    if initial_values:
        vals_str = ", ".join(f"{k}={v!r}" for k, v in list(initial_values.items())[:5])
        if len(initial_values) > 5:
            vals_str += f", ... ({len(initial_values)} total)"
        _debug_logger.debug("VIEW_MOUNT | %s | %s", view_name, vals_str)
    else:
        _debug_logger.debug("VIEW_MOUNT | %s", view_name)


def log_error(context: str, error: Exception) -> None:
    """Log an error with context.

    Args:
        context: Where the error occurred
        error: The exception
    """
    if not _debug_enabled or not _debug_logger:
        return

    _debug_logger.error("ERROR | %s | %s: %s", context, type(error).__name__, error)
