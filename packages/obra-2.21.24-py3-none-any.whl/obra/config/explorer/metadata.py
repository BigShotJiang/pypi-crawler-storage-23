"""Pipeline stage and tag metadata for the Config Explorer."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

# Pipeline phases with their handler actions (for LLM configuration views).
# Maps phase name to list of handler action IDs.
PIPELINE_PHASES: dict[str, list[str]] = {
    "pre_planning": [
        "enrichment_assumptions",
        "enrichment_analogues",
        "enrichment_brief",
    ],
    "planning": ["derive", "examine", "revise"],
    "execution": ["execute", "fix"],
    "review": ["review"],
}

# Metadata for llm.roles configuration paths.
# Used by CustomLLMView and other LLM configuration interfaces.
# Keys: 'description', 'type', 'options', 'tags', 'stage'
CONFIG_METADATA: dict[str, dict[str, Any]] = {
    "llm.roles.derive": {
        "description": "LLM profile for derive (planning) action",
        "type": "select",
        "options": ["orchestrator", "implementation"],
        "tags": ["llm", "planning"],
        "stage": "plan_derive",
    },
    "llm.roles.examine": {
        "description": "LLM profile for examine (plan refinement) action",
        "type": "select",
        "options": ["orchestrator", "implementation"],
        "tags": ["llm", "planning"],
        "stage": "plan_refine",
    },
    "llm.roles.revise": {
        "description": "LLM profile for revise (plan refinement) action",
        "type": "select",
        "options": ["orchestrator", "implementation"],
        "tags": ["llm", "planning"],
        "stage": "plan_refine",
    },
    "llm.roles.execute": {
        "description": "LLM profile for execute (task execution) action",
        "type": "select",
        "options": ["orchestrator", "implementation"],
        "tags": ["llm", "execution"],
        "stage": "execute",
    },
    "llm.roles.fix": {
        "description": "LLM profile for fix (issue fixing) action",
        "type": "select",
        "options": ["orchestrator", "implementation"],
        "tags": ["llm", "execution"],
        "stage": "fix",
    },
    "llm.roles.review": {
        "description": "LLM profile for review (quality review) action",
        "type": "select",
        "options": ["orchestrator", "implementation"],
        "tags": ["llm", "review"],
        "stage": "review",
    },
    "llm.roles.enrichment_assumptions": {
        "description": "LLM profile for assumptions gathering stage",
        "type": "select",
        "options": ["orchestrator", "implementation"],
        "tags": ["llm", "enrichment"],
        "stage": "intent",
    },
    "llm.roles.enrichment_analogues": {
        "description": "LLM profile for analogues finding stage",
        "type": "select",
        "options": ["orchestrator", "implementation"],
        "tags": ["llm", "enrichment"],
        "stage": "enrich",
    },
    "llm.roles.enrichment_brief": {
        "description": "LLM profile for brief generation stage",
        "type": "select",
        "options": ["orchestrator", "implementation"],
        "tags": ["llm", "enrichment"],
        "stage": "scaffold",
    },
}

# Ordered pipeline stages (UI grouping order).
PIPELINE_STAGE_ORDER: list[str] = [
    "input",
    "intent",
    "scaffold",
    "enrich",
    "plan_derive",
    "plan_refine",
    "execute",
    "review",
    "fix",
    "post_review",
    "other",
]

STAGE_LABELS: dict[str, str] = {
    "input": "Input",
    "intent": "Intent Generation",
    "scaffold": "Scaffolded Planning",
    "enrich": "Intent Enrichment",
    "plan_derive": "Plan Derivation",
    "plan_refine": "Plan Refinement",
    "execute": "Execute",
    "review": "Review",
    "fix": "Fix",
    "post_review": "Post-Review",
    "other": "Other",
}

# Mapping from config path prefix to pipeline stage.
# Use longest-prefix match to resolve stage for a setting path.
CONFIG_STAGE_MAP: dict[str, str] = {
    "features.intake": "input",
    "features.intent": "enrich",
    "features.userplan.intake": "input",
    "features.userplan.quality_gate": "intent",
    "features.userplan.intent_alignment": "plan_refine",
    "features.userplan.intent_gap_check": "post_review",
    "planning.scaffolded.stages.assumptions": "intent",
    "planning.scaffolded.stages.analogues": "enrich",
    "planning.scaffolded.stages.brief": "scaffold",
    "planning.scaffolded.stages.derive": "plan_derive",
    "planning.scaffolded.stages.review": "plan_refine",
    "planning.scaffolded": "scaffold",
    "planning.intent_alignment": "plan_refine",
    "planning.intent_gap_check": "post_review",
    "derivation": "plan_derive",
    "rederivation": "plan_refine",
    "execution": "execute",
    "orchestration.parallel": "execute",
    "orchestration": "execute",
    "review": "review",
    "features.quality_automation": "review",
    "agents": "review",
    "llm": "execute",
    # LLM Role-Based Configuration (ADR-069)
    "llm.roles": "execute",
    "llm.roles.derive": "plan_derive",
    "llm.roles.examine": "plan_refine",
    "llm.roles.revise": "plan_refine",
    "llm.roles.execute": "execute",
    "llm.roles.fix": "fix",
    "llm.roles.review": "review",
    "llm.roles.enrichment_assumptions": "intent",
    "llm.roles.enrichment_analogues": "enrich",
    "llm.roles.enrichment_brief": "scaffold",
    # Legacy aliases retained for compatibility with older config paths.
    "llm.roles.scaffolded_assumptions": "intent",
    "llm.roles.scaffolded_analogues": "enrich",
    "llm.roles.scaffolded_brief": "scaffold",
}

# Optional tags to support alternate grouping.
CONFIG_TAGS: dict[str, list[str]] = {
    "llm": ["llm", "cost"],
    "llm.reasoning": ["llm", "quality"],
    "llm.roles": ["llm", "roles"],
    "llm.roles.derive": ["llm", "roles", "planning"],
    "llm.roles.examine": ["llm", "roles", "planning"],
    "llm.roles.revise": ["llm", "roles", "planning"],
    "llm.roles.execute": ["llm", "roles", "execution"],
    "llm.roles.fix": ["llm", "roles", "execution"],
    "llm.roles.review": ["llm", "roles", "review"],
    "llm.roles.enrichment_assumptions": ["llm", "roles", "enrichment"],
    "llm.roles.enrichment_analogues": ["llm", "roles", "enrichment"],
    "llm.roles.enrichment_brief": ["llm", "roles", "enrichment"],
    # Legacy aliases retained for compatibility with older config paths.
    "llm.roles.scaffolded_assumptions": ["llm", "roles", "enrichment"],
    "llm.roles.scaffolded_analogues": ["llm", "roles", "enrichment"],
    "llm.roles.scaffolded_brief": ["llm", "roles", "enrichment"],
    "features.quality_automation": ["review", "quality"],
    "features.intake": ["intent"],
    "features.intent": ["intent", "quality"],
    "agents": ["review", "quality"],
    "planning": ["planning"],
    "planning.scaffolded": ["planning", "scaffolded"],
    "planning.intent_alignment": ["planning", "quality"],
    "planning.intent_gap_check": ["planning", "quality"],
    "derivation": ["planning"],
    "rederivation": ["planning"],
    "orchestration.parallel": ["execution", "rate-limits"],
    "orchestration": ["execution"],
    "execution": ["execution"],
    "review": ["review"],
}


def _dedupe_preserve_order(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        result.append(value)
    return result


def resolve_stage(path: str) -> str | None:
    """Resolve a pipeline stage for a config path using longest-prefix match."""
    if not path:
        return None
    best_match = None
    for prefix in CONFIG_STAGE_MAP:
        if path == prefix or path.startswith(prefix + "."):
            if best_match is None or len(prefix) > len(best_match):
                best_match = prefix
    if best_match:
        return CONFIG_STAGE_MAP[best_match]
    return None


def get_tags(path: str) -> list[str]:
    """Return tags for a config path using longest-prefix match."""
    if not path:
        return []
    best_match = None
    for prefix in CONFIG_TAGS:
        if path == prefix or path.startswith(prefix + "."):
            if best_match is None or len(prefix) > len(best_match):
                best_match = prefix
    if not best_match:
        return []
    return _dedupe_preserve_order(CONFIG_TAGS.get(best_match, []))


def get_stage_label(stage: str | None) -> str:
    """Return a display label for a stage id."""
    if not stage:
        return STAGE_LABELS["other"]
    return STAGE_LABELS.get(stage, stage)


# Phase-to-settings mapping for PipelineOptionsView (S4.T1).
# Maps pipeline phases to behavior settings (non-LLM configuration).
# Settings are grouped by the phase they affect.
# Note: model_tier settings removed - now shown via model inheritance display
# from Menu 3 (LLM Custom) in the PipelineOptionsView header.
# Phase settings with optional sub-group headers.
# Entries starting with "GROUP:" are rendered as section headers.
PHASE_SETTINGS: dict[str, list[str]] = {
    "pre_planning": [
        "_enrichment_mode",  # Virtual setting: maps to enabled + always_on
        "GROUP:Assumptions Stage",
        "planning.enrichment.stages.assumptions.reasoning_level",
        "planning.enrichment.stages.assumptions.max_passes",
        "GROUP:Analogues Stage",
        "planning.enrichment.stages.analogues.reasoning_level",
        "planning.enrichment.stages.analogues.max_passes",
        "GROUP:Brief Stage",
        "planning.enrichment.stages.brief.reasoning_level",
        "planning.enrichment.stages.brief.max_passes",
    ],
    "planning": [
        "GROUP:Derivation",
        "derivation.max_depth",
        "derivation.approval_required",
        "derivation.hierarchy.enabled",
        "derivation.hierarchy.story.max_per_epic",
        "GROUP:Step Configuration",
        "derivation.steps.step1_tier",
        "derivation.steps.step2_tier",
        "derivation.steps.step3_tier",
        "derivation.serialize.max_concurrent",
        "GROUP:Intent Alignment",
        "planning.intent_alignment.model_tier",
        "planning.intent_alignment.max_concurrent",
        "GROUP:Enrichment Review",
        "planning.enrichment.stages.review.model_tier",
        "planning.enrichment.stages.review.max_concurrent",
        "GROUP:Refinement",
        "refinement.planning.enabled",
        "refinement.planning.quality_gate.min_score",
    ],
    "execution": [
        "GROUP:Iteration Limits",
        "orchestration.max_iterations",
        "orchestration.iteration_timeout_s",
        "orchestration.timeouts.agent_execution_s",
        "GROUP:Environment Setup",
        "story0.enabled",
        "story0.auto_env_setup",
        "story0.install_target",
        "GROUP:Agent",
        "agent.timeout",
    ],
    "review": [
        "GROUP:Quality Policy",
        "orchestration.quality.policy_mode",
        "GROUP:Quality Thresholds",
        "review.default_quality_threshold",
        "validation.quality.threshold",
        "GROUP:Review Agents",
        "review.agents.parallel",
        "review.agents.max_workers",
        "GROUP:Fix Behavior",
        "fix.batching.enabled",
        "fix.verification.required",
        "GROUP:Bypass Options",
        "review.permissive_mode",
    ],
}

# Human-readable labels for pipeline phases in the options view.
PHASE_OPTION_LABELS: dict[str, str] = {
    "pre_planning": "Pre-Planning (Enrichment)",
    "planning": "Planning (Derivation)",
    "execution": "Execution",
    "review": "Review & Fix",
}


def get_config_metadata(path: str) -> dict[str, Any] | None:
    """Get metadata for a configuration path.

    Args:
        path: Dot-notation config path (e.g., 'llm.roles.derive')

    Returns:
        Metadata dict with description, type, options, tags, stage,
        or None if no metadata is defined for the path.
    """
    return CONFIG_METADATA.get(path)
