"""Configuration file I/O and path management for Obra.

Handles loading and saving client configuration from
~/.obra/config-layers/01-user.yaml, plus environment variable resolution for
API URLs and timeouts.

Example:
    from obra.config.loaders import load_config, save_config, get_api_base_url

    config = load_config()
    api_url = get_api_base_url()
"""

import json
import logging
import os
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any, cast

import yaml

from obra.constants import MAX_PROMPT_FILES
from obra.exceptions import ConfigurationError

# Module logger
logger = logging.getLogger(__name__)

# Prefer LibYAML C loader when available (same YAML semantics, faster parse).
try:
    from yaml import CSafeLoader as _YAML_SAFE_LOADER
except ImportError:  # pragma: no cover - depends on PyYAML build
    from yaml import SafeLoader as _YAML_SAFE_LOADER


def _yaml_safe_load(content: str) -> Any:
    """Parse YAML content with the fastest available safe loader."""
    return yaml.load(content, Loader=_YAML_SAFE_LOADER)

# Config validation cache - ensures validation runs only once per process
_config_validated = False
_DEFAULT_SCHEMA_CACHE: dict[str, Any] | None = None

# Config layer paths
CONFIG_LAYER_DIR = Path.home() / ".obra" / "config-layers"
CONFIG_PATH = CONFIG_LAYER_DIR / "01-user.yaml"
LEGACY_CONFIG_PATH = Path.home() / ".obra" / "client-config.yaml"
PROJECT_LAYER_PREFIX = "02-project-"
SESSION_LAYER_PREFIX = "03-session-"
SESSION_CONFIG_ENV_VAR = "OBRA_SESSION_CONFIG"

# Auth state file (separate from config - not subject to schema validation)
AUTH_STATE_PATH = Path.home() / ".obra" / "auth.yaml"

# Default API URL (production)
# Can be overridden via OBRA_API_BASE_URL environment variable
DEFAULT_API_BASE_URL = "https://us-central1-obra-205b0.cloudfunctions.net"

# Local emulator API URL
# Used when --local flag is passed to CLI commands
LOCAL_EMULATOR_API_URL = "http://localhost:5001/obra-205b0/us-central1"

# Default LLM execution timeout (30 minutes)
# Can be overridden via OBRA_LLM_TIMEOUT environment variable
DEFAULT_LLM_TIMEOUT = 1800

# Default agent execution timeout (90 minutes) - FIX-TIMEOUT-CONSOLIDATION-001
# Can be overridden via OBRA_AGENT_EXECUTION_TIMEOUT environment variable
DEFAULT_AGENT_EXECUTION_TIMEOUT = 5400

# Default review agent timeout (30 minutes) - FIX-TIMEOUT-CONSOLIDATION-001
# Can be overridden via OBRA_REVIEW_AGENT_TIMEOUT environment variable
DEFAULT_REVIEW_AGENT_TIMEOUT = 1800

# Default CLI runner timeout (120 minutes) - CHORE-LLM-SUBPROCESS-001
# Used for orchestration LLM calls (derive, examine, revise, planning)
# Longest timeout because orchestration is the critical path
# Can be overridden via OBRA_CLI_RUNNER_TIMEOUT environment variable
DEFAULT_CLI_RUNNER_TIMEOUT = 7200

# Default maximum iterations for orchestration loop
# Can be overridden via 01-user.yaml max_iterations setting
DEFAULT_MAX_ITERATIONS = 100

# =============================================================================
# DEPRECATED CONSTANTS - Fallbacks only, prefer config values
# =============================================================================
# These constants are maintained for backward compatibility but should not be
# used in new code. All operational defaults should come from default_config.yaml
# via config getters in this module. See ADR-047 for rationale.
# =============================================================================

# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default auto runner story timeout (1 hour) - CHORE-CONFIG-DEFAULTS-001-E3
# Can be overridden via OBRA_AUTO_STORY_TIMEOUT_S environment variable
DEFAULT_AUTO_STORY_TIMEOUT_S = 3600

# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default cleanup retry sleep cap (0.5 seconds) - CHORE-CONFIG-DEFAULTS-001-E3
# Can be overridden via OBRA_CLEANUP_SLEEP_CAP_S environment variable
DEFAULT_CLEANUP_SLEEP_CAP_S = 0.5

# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default intent detection thresholds - CHORE-CONFIG-DEFAULTS-001-E3
DEFAULT_INTENT_RICH_MIN_WORDS = 50
DEFAULT_INTENT_MIN_KEYWORD_MATCHES = 2
DEFAULT_INTENT_MIN_DETAIL_MARKERS = 2

# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default intent template settings - CHORE-CONFIG-DEFAULTS-001-E3
DEFAULT_INTENT_SUMMARY_PREVIEW_LENGTH = 60

# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default file tracking settings - CHORE-CONFIG-DEFAULTS-001-E3
DEFAULT_MAX_FILE_SIZE_BYTES = 10485760  # 10MB

# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default cache monitor settings - CHORE-CONFIG-DEFAULTS-001-E3
DEFAULT_CACHE_SUBDIR_THRESHOLD_MB = 50
DEFAULT_CACHE_TOP_SUBDIRS_COUNT = 3

# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default derivation preview settings - CHORE-CONFIG-DEFAULTS-001-E3 S2
DEFAULT_DERIVATION_README_LIMIT = 2000
DEFAULT_DERIVATION_RAW_RESPONSE_LIMIT = 200
DEFAULT_DERIVATION_RAW_RESPONSE_WARN_LIMIT = 10000
DEFAULT_DERIVATION_EPIC_OUTPUT_TOKEN_LIMIT = 12000
DEFAULT_DERIVATION_EXPLORATION_LOOKBACK_MINUTES = 180
DEFAULT_DERIVATION_EPIC_ITEM_REDERIVE_THRESHOLD = 30
DEFAULT_DERIVATION_MAX_DEPTH_WARNING_THRESHOLD = 0.8
DEFAULT_DERIVATION_STORY_RANGE = "3-6"
DEFAULT_DERIVATION_TASK_RANGE = "2-5"
DEFAULT_DERIVATION_STRICT_STORY_RANGE = "2-4"
DEFAULT_DERIVATION_STRICT_TASK_RANGE = "2-3"

# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default intake settings - CHORE-CONFIG-DEFAULTS-001-E3 S2
DEFAULT_INTAKE_MIN_WORDS = 3

# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default skip tracking settings - CHORE-CONFIG-DEFAULTS-001-E3 S2
DEFAULT_SKIP_TRACKING_MAX_LOGS_CHARS = 2000

# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default tooling discovery settings - CHORE-CONFIG-DEFAULTS-001-E3 S2
DEFAULT_TOOLING_DISCOVERY_MAX_MANIFEST_BYTES = 2048

# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default process registry settings - CHORE-CONFIG-DEFAULTS-001-E3 S2
DEFAULT_PROCESS_REGISTRY_TERMINATE_TIMEOUT_S = 3.0

# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default execution quality settings - CHORE-CONFIG-DEFAULTS-001-E3 S2
DEFAULT_EXECUTION_QUALITY_DEFAULT_THRESHOLD = 0.6
DEFAULT_EXECUTION_QUALITY_GENERATED_PLAN_THRESHOLD = 0.4

# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default intent thresholds - CHORE-CONFIG-DEFAULTS-001-E3 S2
DEFAULT_INTENT_DETECTION_EMPTY = 5
DEFAULT_INTENT_DETECTION_EXISTING = 50
DEFAULT_INTENT_INTERROGATIVE_RATIO = 0.5
DEFAULT_INTENT_TOKEN_WARNING = 0.8

# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Log viewer, CLI, auth & validation defaults - CHORE-CONFIG-DEFAULTS-001-E3 S3
DEFAULT_LOG_VIEWER_HOST = "127.0.0.1"
DEFAULT_LOG_VIEWER_PORT = 8844
DEFAULT_LOG_VIEWER_TAIL_LIMIT = 200
DEFAULT_LOG_VIEWER_MAX_EVENTS = 500
DEFAULT_LOG_VIEWER_MAX_SNAPSHOT_BYTES = 2097152  # 2MB
DEFAULT_LOG_VIEWER_INDEX_ROTATION_FILES = 3
DEFAULT_LOG_VIEWER_STREAM_SLEEP_S = 0.2
DEFAULT_LOG_VIEWER_GRACEFUL_SHUTDOWN_DELAY_S = 1.0
# Gateway server defaults (FEAT-GATEWAY-001)
DEFAULT_GATEWAY_HOST = "127.0.0.1"
DEFAULT_GATEWAY_PORT = 18790
DEFAULT_GATEWAY_MAX_SESSIONS = 5
DEFAULT_GATEWAY_ESCALATION_TIMEOUT_S = 300.0
DEFAULT_GATEWAY_ENABLE_CORS = False
DEFAULT_GATEWAY_CORS_ORIGINS = ["*"]
DEFAULT_PRODUCTION_LOGGER_MAX_SIZE_BYTES = 104857600  # 100MB
DEFAULT_PRODUCTION_LOGGER_BACKUP_COUNT = 10
DEFAULT_CLI_RETRY_MAX_ATTEMPTS = 3
DEFAULT_CLI_RETRY_INITIAL_DELAY_S = 2
DEFAULT_CLI_RETRY_BACKOFF_MULTIPLIER = 2
DEFAULT_CLI_FORCE_QUIT_WINDOW_S = 3.0
DEFAULT_CLI_CACHE_WARN_THRESHOLD_MB = 500
DEFAULT_CLI_CACHE_CRITICAL_THRESHOLD_MB = 1000
DEFAULT_OAUTH_POLL_INTERVAL_S = 0.1
DEFAULT_OAUTH_THREAD_JOIN_TIMEOUT_S = 1.0
DEFAULT_PLAN_ITEM_MAX_ACCEPTANCE_CRITERIA = 5
DEFAULT_PLAN_ITEM_MAX_DESCRIPTION_WORDS = 150
DEFAULT_PLAN_ITEM_MAX_TASKS = 8
DEFAULT_PLAN_ITEM_MAX_LOC = 400
DEFAULT_PLAN_ITEM_MAX_FILES_PER_TASK = 5
DEFAULT_API_CLIENT_DEFAULT_TIMEOUT_S = 120
DEFAULT_CONFIG_EXPLORER_NOTIFICATION_TIMEOUT_S = 10

# =============================================================================
# END DEPRECATED CONSTANTS
# =============================================================================

# Workflow configuration (CHORE-CONFIG-DEFAULTS-001-E2 Story 6)
DEFAULT_WORKFLOW_PATTERN_WEIGHT = 0.6
DEFAULT_WORKFLOW_KEYWORD_WEIGHT = 0.4
DEFAULT_TRIAGE_HIGH_CONFIDENCE = 0.9
DEFAULT_TRIAGE_MEDIUM_CONFIDENCE = 0.5
DEFAULT_TRIAGE_LOW_CONFIDENCE = 0.3
# Priority order dict
DEFAULT_PRIORITY_ORDER = {"P0": 0, "P1": 1, "P2": 2, "P3": 3}

# Work type configuration (CHORE-CONFIG-DEFAULTS-001-E2 Story 6, R31 GAP FIX)
DEFAULT_WORK_TYPE_KEYWORD_WEIGHT = 0.25
DEFAULT_WORK_TYPE_PHRASE_WEIGHT = 0.35
DEFAULT_WORK_TYPE_REGEX_WEIGHT = 0.15
DEFAULT_WORK_TYPE_BASE_SCORE = 0.5
DEFAULT_WORK_TYPE_MAX_BONUS = 0.5

# Network timeout configuration (C17)
# Default timeout for general network operations (seconds)
DEFAULT_NETWORK_TIMEOUT = 30
# Timeout for LLM API operations (seconds) - 15 min (ISSUE-HYBRID-002)
DEFAULT_LLM_API_TIMEOUT = 900
# Default stream idle timeout for streaming LLM output (seconds)
# Set to 0 to disable idle timeout (prevent false positives on silent file edits)
DEFAULT_LLM_STREAM_IDLE_TIMEOUT = 0

# Version check configuration (FEAT-CLI-VERSION-NOTIFY-001)
# Enable/disable automatic version checking
DEFAULT_CHECK_FOR_UPDATES = True
# Cooldown period between version notifications (minutes)
DEFAULT_UPDATE_NOTIFICATION_COOLDOWN_MINUTES = 10
# Auto-update configuration (FEAT-CLI-AUTO-UPDATE-001)
# Enable/disable automatic pipx upgrade on startup when behind
DEFAULT_AUTO_UPDATE = True
# Cooldown period between auto-update checks (minutes)
DEFAULT_AUTO_UPDATE_COOLDOWN_MINUTES = 60
# Max retries for pipx upgrade (caching often needs 2+ runs)
DEFAULT_AUTO_UPDATE_MAX_RETRIES = 3
# Base delay between retries in seconds (doubles each retry: 2s, 4s)
DEFAULT_AUTO_UPDATE_RETRY_DELAY_S = 2.0
# Timeout per pipx upgrade attempt in seconds
DEFAULT_AUTO_UPDATE_PIPX_TIMEOUT_S = 120

# Prompt file retention
DEFAULT_PROMPT_RETAIN = False
DEFAULT_PROMPT_MAX_FILES = MAX_PROMPT_FILES

# Template edit retention (LLM JSON templates)
DEFAULT_TEMPLATE_RETAIN_ON_SUCCESS = False
DEFAULT_TEMPLATE_RETAIN_ON_ERROR = True

# Retry configuration defaults (matches default_config.yaml retry section)
# Balanced defaults reduce duplicate pressure when provider CLIs already retry internally.
DEFAULT_RETRY_MAX_ATTEMPTS = 3
DEFAULT_RETRY_AUTH_MAX_ATTEMPTS = 3
DEFAULT_RETRY_RATE_LIMIT_MAX_ATTEMPTS = 1
DEFAULT_RETRY_BASE_DELAY = 8.0
DEFAULT_RETRY_MAX_DELAY = 120.0
DEFAULT_RETRY_BACKOFF_MULTIPLIER = 2.0
DEFAULT_RETRY_JITTER = 0.2
DEFAULT_RETRY_PATTERNS = [
    "rate limit",
    "rate_limit",
    "too many requests",
    "timeout",
    "timed out",
    "connection",
    "network",
    "service unavailable",
    "temporarily unavailable",
    "try again",
    "stream disconnected",
    "stream disconnected before completion",
    "error occurred while processing your request",
    "retry your request",
]

# Handler configuration defaults (CHORE-CONFIG-DEFAULTS-001-E2)
# All LLM timeouts: 10 min minimum per Rule 22
# Derive handler defaults
DEFAULT_DERIVE_ALIGNMENT_TIMEOUT = 600  # 10 min minimum per Rule 22
DEFAULT_DERIVE_MAPPING_TIMEOUT = 600  # 10 min minimum per Rule 22
DEFAULT_DERIVE_CACHE_MAX_AGE = 3600
DEFAULT_DERIVE_MAX_RETRIES = 3
DEFAULT_DERIVE_MAX_RELEVANT_FILES = 10
DEFAULT_DERIVE_RAW_RESPONSE_LOG_PREVIEW = 200
DEFAULT_DERIVE_COMPLEXITY_SIMPLE_MAX_STEPS = 3
DEFAULT_DERIVE_COMPLEXITY_MEDIUM_MAX_STEPS = 8
DEFAULT_DERIVE_LLM_TIMEOUT = 600  # 10 min minimum per Rule 22

# Fix handler defaults
DEFAULT_FIX_HANDLER_DOC_TIMEOUT = 600  # 10 min minimum per Rule 22
DEFAULT_FIX_HANDLER_MAX_RETRIES = 3
DEFAULT_FIX_HANDLER_PARALLEL_ENABLED = False
DEFAULT_FIX_HANDLER_PARALLEL_WORKERS = 4
DEFAULT_FIX_HANDLER_MIN_FILE_SIZE = 100
DEFAULT_FIX_LLM_SUGGESTION_TIMEOUT = 600  # 10 min minimum per Rule 22
DEFAULT_FIX_LLM_TEST_GAP_TIMEOUT = 600  # 10 min minimum per Rule 22

# Story0 handler defaults
DEFAULT_STORY0_TIMEOUT = 600  # 10 min minimum per Rule 22
DEFAULT_STORY0_MAX_RETRIES = 2
DEFAULT_STORY0_SERVICE_POLL_INTERVAL = 0.2
DEFAULT_STORY0_SERVICE_POLL_MAX_ATTEMPTS = 20
DEFAULT_STORY0_DOCKER_TIMEOUT = 600
DEFAULT_STORY0_PORT_MAPPINGS = {
    "postgres": 5432,
    "redis": 6379,
    "mysql": 3306,
    "mongodb": 27017,
}
DEFAULT_STORY0_SERVICE_IMAGES = {
    "postgres": "postgres:15",
    "redis": "redis:7",
    "mysql": "mysql:8",
    "mongodb": "mongo:6",
}
DEFAULT_STORY0_LLM_SCHEMA_TIMEOUT = 600  # 10 min minimum per Rule 22
DEFAULT_STORY0_CAPABILITY_CHECKS: dict[str, dict[str, Any]] = {
    "python_runtime": {
        "indicators": [
            "python interpreter",
            "python 3 interpreter",
            "python3 interpreter",
            "python runtime",
            "python3 runtime",
        ],
        "commands": [["python3", "--version"], ["python", "--version"]],
    },
    "display": {
        "indicators": ["gui", "display", "window", "screen", "graphical"],
        "platforms": {
            "linux": {"env_vars": ["DISPLAY", "WAYLAND_DISPLAY"]},
            "darwin": {"always_available": True},
            "win32": {"always_available": True},
        },
        "fallback": {"env_vars": ["DISPLAY"]},
    },
    "audio": {
        "indicators": ["audio", "sound", "speaker", "microphone"],
        "platforms": {
            "linux": {"env_vars": ["PULSE_SERVER", "ALSA_CARD"]},
            "darwin": {"always_available": True},
            "win32": {"always_available": True},
        },
        "fallback": {"env_vars": ["PULSE_SERVER"]},
    },
    "filesystem_write": {
        "indicators": ["write permission", "writable", "filesystem"],
        "always_available": True,
    },
}

# Execute handler defaults
DEFAULT_EXECUTE_PARALLEL_WORKERS = 4
DEFAULT_EXECUTE_MIN_FILE_SIZE = 100
DEFAULT_EXECUTE_THREAD_JOIN_TIMEOUT = 5  # Thread join, not LLM
DEFAULT_EXECUTE_SUBPROCESS_TIMEOUT = 30  # Subprocess ops, not LLM

# Review handler defaults
DEFAULT_REVIEW_HANDLER_TIMEOUT = 600  # 10 min minimum per Rule 22
DEFAULT_REVIEW_HANDLER_MAX_RETRIES = 2
DEFAULT_REVIEW_MODEL_TIER = "high"

# Escalate handler defaults
DEFAULT_ESCALATE_TRUNCATION_CHARS = 57
DEFAULT_ESCALATE_TIMEOUT = 600  # 10 min minimum per Rule 22

# Intent handler defaults
DEFAULT_INTENT_MAX_RETRIES = 3
DEFAULT_INTENT_RATE_LIMIT_MAX_RETRIES = 3
DEFAULT_INTENT_BYPASS_SANDBOX = False

# Examine handler defaults
DEFAULT_EXAMINE_MAX_RETRIES = 3
DEFAULT_EXAMINE_BYPASS_SANDBOX = False
DEFAULT_EXAMINE_MODEL_TIER = "high"

# Revise handler defaults
DEFAULT_REVISE_MAX_RETRIES = 3
DEFAULT_REVISE_BYPASS_SANDBOX = False
DEFAULT_REVISE_MODEL_TIER = "high"

# Story0 handler defaults
DEFAULT_STORY0_MODEL_TIER = "high"

# Clarification handler defaults
DEFAULT_CLARIFICATION_MAX_ITERATIONS = 3
DEFAULT_CLARIFICATION_QUALITY_DELTA_THRESHOLD = 0.05
DEFAULT_CLARIFICATION_TARGET_QUALITY = 0.8

# Template edit pipeline defaults
DEFAULT_TEMPLATE_EDIT_MAX_RETRIES = 2

# Tooling discovery defaults
DEFAULT_TOOLING_DISCOVERY_TIMEOUT = 600  # 10 min minimum per Rule 22

# Derivation module defaults
DEFAULT_DERIVATION_PRE_FILTER_TIMEOUT = 600  # 10 min minimum per Rule 22
DEFAULT_DERIVATION_SIZING_GATE_TIMEOUT = 600  # 10 min minimum per Rule 22

# Monitoring module defaults (CHORE-CONFIG-DEFAULTS-001-E2 Story 5)
DEFAULT_LIVENESS_CPU_DELTA_THRESHOLD = 1.0
DEFAULT_LIVENESS_LOG_SILENCE_THRESHOLD = 300
DEFAULT_LIVENESS_FILE_MTIME_WINDOW = 300
DEFAULT_LIVENESS_DB_UPDATE_WINDOW = 300
DEFAULT_LIVENESS_MIN_ALIVE_INDICATORS = 2
DEFAULT_AGENT_LIVENESS_CHECK_INTERVAL = 180
DEFAULT_AGENT_EXTENDED_TIMEOUT = 3600
DEFAULT_AGENT_GRACEFUL_TERMINATION_WAIT = 2.0
DEFAULT_AGENT_BASE_TIMEOUT = 1200
DEFAULT_HANG_CONFIDENCE = {
    "real_hang": 0.95,
    "io_blocking_with_file": 0.85,
    "io_blocking_without": 0.65,
    "slow_progress": 0.60,
    "external_blocking": 0.75,
    "unknown": 0.30,
}

# Deprecated config keys mapped to new paths (schema reorg)
CONFIG_PATH_ALIASES: dict[str, str] = {
    "logging": "advanced.logging",
    "debug": "advanced.debug",
    "audit": "advanced.audit",
    "metrics": "advanced.metrics",
}

# Deprecated/legacy fields that should trigger migration warnings
# Maps old field path to (new field path or None, additional context)
# The deprecation message is generated using the message library
DEPRECATED_FIELDS: dict[str, tuple[str | None, str]] = {
    "llm.type": (
        "llm.provider",
        "Example: llm.provider: anthropic (not llm.type: claude-cli)",
    ),
    "llm.cli_command": (
        None,  # No replacement - should be removed
        "CLI is now derived automatically from llm.provider. "
        "Remove llm.cli_command from your config.",
    ),
}

# Semantic config aliases for intuitive access (UX-CONFIG-001)
# These map user-friendly paths to the actual config structure.
# Unlike CONFIG_PATH_ALIASES, these are bidirectional and don't trigger deprecation warnings.
SEMANTIC_CONFIG_ALIASES: dict[str, str] = {
    # Agent shortcuts - map intuitive names to features.quality_automation.agents.*
    "agents.security": "features.quality_automation.agents.security_audit.enabled",
    "agents.security_audit": "features.quality_automation.agents.security_audit.enabled",
    "agents.doc_audit": "features.quality_automation.agents.doc_audit.enabled",
    "agents.documentation": "features.quality_automation.agents.doc_audit.enabled",
    "agents.rca": "features.quality_automation.agents.rca_agent.enabled",
    "agents.code_review": "features.quality_automation.agents.code_review.enabled",
    "agents.test_generation": "features.quality_automation.agents.test_generation.enabled",
    "agents.test_execution": "features.quality_automation.agents.test_execution.enabled",
    "agents.sense_check": "features.quality_automation.agents.sense_check.enabled",
    "agents.code_verify": "features.quality_automation.agents.code_verify.enabled",
    # Shorter agent aliases (match config schema)
    "agents.test_gen": "features.quality_automation.agents.test_generation.enabled",
    "agents.test_exec": "features.quality_automation.agents.test_execution.enabled",
    # Review shortcuts - common user mental model
    "review.security": "features.quality_automation.agents.security_audit.enabled",
    "review.security.enabled": "features.quality_automation.agents.security_audit.enabled",
    "review.documentation": "features.quality_automation.agents.doc_audit.enabled",
    "review.documentation.enabled": "features.quality_automation.agents.doc_audit.enabled",
    "review.code": "features.quality_automation.agents.code_review.enabled",
    # Orchestration review shortcuts (common user confusion)
    "orchestration.review.security": "features.quality_automation.agents.security_audit.enabled",
    "orchestration.review.security.enabled": "features.quality_automation.agents.security_audit.enabled",
    "orchestration.review.documentation": "features.quality_automation.agents.doc_audit.enabled",
    "orchestration.review.documentation.enabled": "features.quality_automation.agents.doc_audit.enabled",
    # LLM shortcuts
    "llm.orchestrator.model": "llm.model",
    "llm.orchestrator_model": "llm.model",
    # Quality automation shortcuts
    "quality_automation": "features.quality_automation",
    "quality_automation.enabled": "features.quality_automation.enabled",
}

AGENT_LLM_DEFAULTS: dict[str, str] = {
    "provider": "inherit",
    "model": "inherit",
    "model_tier": "inherit",
    "reasoning_level": "inherit",
}


def resolve_semantic_alias(path: str) -> tuple[str, str | None]:
    """Resolve semantic config aliases to canonical paths.

    Returns:
        Tuple of (canonical_path, hint_message or None).
        If an alias was resolved, hint_message explains the mapping.
    """
    canonical = SEMANTIC_CONFIG_ALIASES.get(path)
    if canonical:
        return canonical, f"'{path}' maps to '{canonical}'"
    return path, None


def get_config_path() -> Path:
    """Get path to user configuration file.

    Returns:
        Path to ~/.obra/config-layers/01-user.yaml
    """
    return CONFIG_PATH


def get_project_layer_path(project_id: str) -> Path:
    """Return the project layer path for a project identifier."""
    return CONFIG_LAYER_DIR / f"{PROJECT_LAYER_PREFIX}{project_id}.yaml"


def get_session_layer_path(session_id: str) -> Path:
    """Return the session layer path for a session identifier."""
    return CONFIG_LAYER_DIR / f"{SESSION_LAYER_PREFIX}{session_id}.yaml"


def get_session_layer_override() -> Path | None:
    """Return the session layer override path from environment, if set."""
    value = os.environ.get(SESSION_CONFIG_ENV_VAR)
    if not value:
        return None
    return Path(value).expanduser()


def _ensure_user_config_exists() -> None:
    if CONFIG_PATH.exists():
        return
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text("{}\n", encoding="utf-8")


def resolve_config_alias(path: str) -> str:
    """Resolve deprecated config paths to their canonical replacements.

    This function checks both deprecated aliases (which trigger warnings)
    and semantic aliases (which are user-friendly shortcuts).
    """
    # First check deprecated aliases
    if path in CONFIG_PATH_ALIASES:
        return CONFIG_PATH_ALIASES[path]
    # Then check semantic aliases
    if path in SEMANTIC_CONFIG_ALIASES:
        return SEMANTIC_CONFIG_ALIASES[path]
    return path


def _get_nested_value(config: dict[str, Any], path: str) -> Any:
    """Return nested value by dotted path."""
    current: Any = config
    for part in path.split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current


def _has_nested_key(config: dict[str, Any], path: str) -> bool:
    """Check whether a dotted path exists in the config."""
    current: Any = config
    for part in path.split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return False
    return True


def _set_nested_value(config: dict[str, Any], path: str, value: Any) -> None:
    """Set a nested value by dotted path, creating containers as needed."""
    parts = path.split(".")
    current: dict[str, Any] = config
    for part in parts[:-1]:
        if part not in current or not isinstance(current[part], dict):
            current[part] = {}
        current = current[part]
    current[parts[-1]] = value


def _check_deprecated_fields(
    config: dict[str, Any],
    warnings: list[str],
) -> None:
    """Check for deprecated fields and add migration warnings.

    This function scans user config for deprecated fields defined in
    DEPRECATED_FIELDS and adds actionable warnings to help users migrate.

    Args:
        config: User configuration dictionary
        warnings: List to append warning messages to
    """
    from obra.messages import get_message

    for deprecated_path, (new_path, extra_context) in DEPRECATED_FIELDS.items():
        if _has_nested_key(config, deprecated_path):
            # Generate deprecation message using message library
            if new_path:
                base_msg = cast(
                    str,
                    get_message(  # type: ignore[operator]
                        "warning.deprecation.config_key",
                        old=deprecated_path,
                        new=new_path,
                    ),
                )
            else:
                # No replacement - use generic deprecation message
                base_msg = f"Config key '{deprecated_path}' is no longer supported."
            # Append extra context if provided
            full_msg = f"{base_msg} {extra_context}" if extra_context else base_msg
            # Add [LEGACY CONFIG] prefix to make it stand out
            warnings.append(f"[LEGACY CONFIG] {full_msg}")


def _apply_config_aliases(
    config: dict[str, Any],
    warnings: list[str] | None = None,
) -> dict[str, Any]:
    """Apply deprecated path aliases without mutating the source dict."""
    normalized = deepcopy(config)

    # Check for deprecated fields first (before path aliasing)
    if warnings is not None:
        _check_deprecated_fields(normalized, warnings)

    for legacy, canonical in CONFIG_PATH_ALIASES.items():
        legacy_exists = _has_nested_key(normalized, legacy)
        canonical_exists = _has_nested_key(normalized, canonical)
        legacy_value = _get_nested_value(normalized, legacy) if legacy_exists else None
        canonical_value = _get_nested_value(normalized, canonical) if canonical_exists else None

        if legacy_exists and not canonical_exists:
            _set_nested_value(normalized, canonical, legacy_value)
            if warnings is not None:
                warnings.append(f"Deprecated config key '{legacy}' detected; use '{canonical}'.")
        elif canonical_exists and not legacy_exists:
            _set_nested_value(normalized, legacy, canonical_value)
        elif legacy_exists and canonical_exists and legacy_value != canonical_value:
            _set_nested_value(normalized, legacy, canonical_value)
            if warnings is not None:
                warnings.append(
                    f"Config keys '{legacy}' and '{canonical}' both set; "
                    f"'{canonical}' takes precedence."
                )

    return normalized


def _normalize_agent_bool_configs(
    config: dict[str, Any],
    origins: dict[str, str] | None,
    include_defaults: bool,
) -> None:
    """Normalize legacy agent booleans to {enabled, llm} objects."""
    agents = _get_nested_value(config, "features.quality_automation.agents")
    if not isinstance(agents, dict):
        return

    for agent_name, value in list(agents.items()):
        if agent_name in ("description", "ignore_patterns"):
            continue
        if isinstance(value, bool):
            path = f"features.quality_automation.agents.{agent_name}"
            origin = origins.get(path) if origins is not None else None
            agents[agent_name] = {
                "enabled": value,
                "llm": deepcopy(AGENT_LLM_DEFAULTS),
            }
            if origins is not None:
                if origin:
                    origins[f"{path}.enabled"] = origin
                elif include_defaults and f"{path}.enabled" not in origins:
                    origins[f"{path}.enabled"] = "default"
                for llm_key in AGENT_LLM_DEFAULTS:
                    llm_path = f"{path}.llm.{llm_key}"
                    if include_defaults and llm_path not in origins:
                        origins[llm_path] = "default"
                if path in origins:
                    del origins[path]


def load_config(config_path: Path | None = None) -> dict[str, Any]:
    """Load configuration from ~/.obra/config-layers/01-user.yaml.

    Returns:
        Configuration dictionary, empty dict if file doesn't exist
    """
    path = config_path or CONFIG_PATH
    if path == CONFIG_PATH:
        _ensure_user_config_exists()
    if not path.exists():
        return {}

    try:
        content = path.read_text(encoding="utf-8")
        data = _yaml_safe_load(content) or {}
    except (OSError, yaml.YAMLError):
        return {}

    if not isinstance(data, dict):
        logger.warning(
            "Invalid user config at %s: expected mapping, got %s",
            path,
            type(data).__name__,
        )
        return {}

    return _apply_config_aliases(data)


def load_config_with_warnings(
    config_path: Path | None = None,
) -> tuple[dict[str, Any], list[str], bool]:
    """Load user configuration and return warnings instead of raising.

    Args:
        config_path: Optional override path for the config file.

    Returns:
        Tuple of (config dict, warnings list, file_exists).
    """
    path = config_path or CONFIG_PATH
    warnings: list[str] = []

    if path == CONFIG_PATH:
        _ensure_user_config_exists()

    if not path.exists():
        return {}, warnings, False

    try:
        content = path.read_text(encoding="utf-8")
    except OSError as exc:
        warnings.append(f"Failed to read config at {path}: {exc}. Using defaults.")
        return {}, warnings, True

    try:
        data = _yaml_safe_load(content) or {}
    except yaml.YAMLError as exc:
        warnings.append(f"Invalid YAML in config at {path}: {exc}. Using defaults.")
        return {}, warnings, True

    if not isinstance(data, dict):
        warnings.append(
            f"Invalid config at {path}: expected mapping, got {type(data).__name__}. "
            "Using defaults."
        )
        return {}, warnings, True

    return _apply_config_aliases(data, warnings), warnings, True


def _load_layer_file(
    path: Path,
    warnings: list[str],
    label: str,
) -> dict[str, Any]:
    if not path.exists():
        return {}

    try:
        content = path.read_text(encoding="utf-8")
    except OSError as exc:
        warnings.append(f"Failed to read {label} at {path}: {exc}. Ignoring.")
        return {}

    try:
        data = _yaml_safe_load(content) or {}
    except yaml.YAMLError as exc:
        warnings.append(f"Invalid YAML in {label} at {path}: {exc}. Ignoring.")
        return {}

    if not isinstance(data, dict):
        warnings.append(
            f"Invalid {label} at {path}: expected mapping, got {type(data).__name__}. Ignoring."
        )
        return {}

    return _apply_config_aliases(data, warnings)


def _record_origins(
    data: dict[str, Any],
    layer: str,
    origins: dict[str, str],
    prefix: str = "",
) -> None:
    for key, value in data.items():
        path = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            _record_origins(value, layer, origins, path)
        else:
            origins[path] = layer


def _merge_with_origins(
    base: dict[str, Any],
    override: dict[str, Any],
    layer: str,
    origins: dict[str, str],
    prefix: str = "",
) -> None:
    for key, value in override.items():
        path = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            base_value = base.get(key)
            if not isinstance(base_value, dict):
                base_value = {}
            base[key] = base_value
            _merge_with_origins(base_value, value, layer, origins, path)
        else:
            base[key] = value
            origins[path] = layer


def _load_default_schema() -> dict[str, Any]:
    """Load the default configuration schema from package resources.

    Raises:
        ConfigurationError: If default_config.yaml is missing or unreadable.
            This indicates a corrupted installation that should be fixed
            by reinstalling the package.
    """
    from importlib import resources

    try:
        default_path = resources.files("obra.config").joinpath("default_config.yaml")
        content = default_path.read_text(encoding="utf-8")
    except FileNotFoundError:
        msg = (
            "default_config.yaml not found in package. "
            "Installation may be corrupted. "
            "Path searched: obra.config/default_config.yaml. "
            "Try: pip install --force-reinstall obra"
        )
        raise ConfigurationError(msg) from None
    except Exception as exc:
        msg = (
            f"Failed to read default_config.yaml: {exc}. "
            "Installation may be corrupted. "
            "Try: pip install --force-reinstall obra"
        )
        raise ConfigurationError(msg) from exc

    data = _yaml_safe_load(content) or {}
    if not isinstance(data, dict):
        msg = (
            "default_config.yaml has invalid format (expected dict). "
            "Installation may be corrupted. "
            "Try: pip install --force-reinstall obra"
        )
        raise ConfigurationError(msg)
    return data


def _get_default_schema_cached() -> dict[str, Any]:
    """Return cached default schema for this process.

    Safe because packaged defaults are immutable for the lifetime of a process.
    """
    global _DEFAULT_SCHEMA_CACHE
    if _DEFAULT_SCHEMA_CACHE is None:
        _DEFAULT_SCHEMA_CACHE = _load_default_schema()
    return _DEFAULT_SCHEMA_CACHE


def validate_default_schema() -> None:
    """Validate that the default configuration schema is available and valid.

    Call this early in CLI initialization to fail fast if the installation
    is corrupted or config has missing/invalid keys. This must run before
    handler imports to provide clear error messages.

    Uses caching to ensure validation runs only once per process.

    Raises:
        SystemExit: If configuration validation fails (exits with code 1).

    Related:
        - ADR-047: Config single source of truth
        - S4.T1: Startup schema validation
    """
    global _config_validated

    # First check that default_config.yaml exists and is loadable
    defaults = _load_default_schema()
    global _DEFAULT_SCHEMA_CACHE
    if _DEFAULT_SCHEMA_CACHE is None:
        _DEFAULT_SCHEMA_CACHE = defaults

    if _config_validated:
        return

    # Then validate config values against comprehensive schema
    try:
        from obra.config.schema import validate_config

        # Load config with defaults to validate complete merged config
        config, _, _ = load_layered_config(include_defaults=True)
        is_valid, errors = validate_config(config)

        if not is_valid:
            print("Config validation failed:", file=sys.stderr)
            for err in errors:
                print(f"  - {err}", file=sys.stderr)
            print(
                "\nPlease check your config or run: obra config reset --force",
                file=sys.stderr,
            )
            sys.exit(1)

        # Validate pipeline configuration (FEAT-PIPELINE-001)
        pipeline_errors = validate_pipeline_config(config)
        if pipeline_errors:
            print("Pipeline configuration validation failed:", file=sys.stderr)
            for err in pipeline_errors:
                print(f"  - {err}", file=sys.stderr)
            print(
                "\nPlease check your pipeline config or see: "
                "docs/guides/obra/pipeline-configuration-guide.md",
                file=sys.stderr,
            )
            sys.exit(1)

        _config_validated = True

    except ImportError as e:
        # Schema module not available - log warning but don't fail
        # This ensures backward compatibility during development
        logger.warning(f"Config schema validation unavailable: {e}")
        _config_validated = True


def expand_automation_mode(
    config: dict[str, Any],
    origins: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Expand automation_mode into granular Story0/FIX defaults."""
    if config is None:
        return {}

    mode = config.get("automation_mode")
    if mode is None:
        mode = "auto_full"
        config["automation_mode"] = mode
        if origins is not None and "automation_mode" not in origins:
            origins["automation_mode"] = "derived"

    mode_defaults: dict[str, dict[str, Any]] = {
        "off": {
            "story0.auto_env_setup": False,
            "story0.install_policy": "manifest_only",
            "story0.allow_inferred_installs": False,
            "story0.auto_approve": False,
            "story0.install_target": "existing_env_only",
            "story0.env_creation": "never",
            "fix.verification.auto_install": False,
        },
        "guided": {
            "story0.auto_env_setup": True,
            "story0.prompt_for_env_setup": True,
            "story0.install_policy": "manifest_then_inferred",
            "story0.allow_inferred_installs": True,
            "story0.auto_approve": False,
            "story0.install_target": "project_local",
            "story0.env_creation": "when_missing",
            "fix.verification.auto_install": True,
        },
        "auto_safe": {
            "story0.auto_env_setup": True,
            "story0.prompt_for_env_setup": False,
            "story0.install_policy": "manifest_then_inferred",
            "story0.allow_inferred_installs": True,
            "story0.auto_approve": False,
            "story0.install_target": "project_local",
            "story0.env_creation": "when_missing",
            "fix.verification.auto_install": True,
        },
        "auto_full": {
            "story0.auto_env_setup": True,
            "story0.prompt_for_env_setup": False,
            "story0.install_policy": "manifest_or_inferred",
            "story0.allow_inferred_installs": True,
            "story0.auto_approve": True,
            "story0.install_target": "project_local",
            "story0.env_creation": "always",
            "fix.verification.auto_install": True,
        },
    }

    if mode not in mode_defaults:
        msg = f"Invalid automation_mode '{mode}'. Valid values: off, guided, auto_safe, auto_full."
        raise ConfigurationError(msg)

    # Legacy flags (story0.auto_approve, fix.verification.auto_install) predate
    # automation_mode. Preserve explicit values from non-default layers.
    derived = mode_defaults[mode]
    for path, value in derived.items():
        if origins is not None:
            origin = origins.get(path)
            if origin and origin != "default":
                logger.debug(
                    "Config key %s explicitly set in %s layer, not applying mode-derived default",
                    path,
                    origin,
                )
                continue
        _set_nested_value(config, path, value)
        if origins is not None and path not in origins:
            origins[path] = "derived"

    return config


def load_layered_config(
    project_id: str | None = None,
    session_path: Path | None = None,
    include_defaults: bool = False,
) -> tuple[dict[str, Any], dict[str, str], list[str]]:
    """Load layered config with deterministic precedence."""
    warnings: list[str] = []

    user_config, user_warnings, _ = load_config_with_warnings()
    warnings.extend(user_warnings)

    resolved_project_id = project_id
    if resolved_project_id is None:
        try:
            from obra.intent.storage import IntentStorage

            resolved_project_id = IntentStorage().get_project_id(Path.cwd())
        except Exception as exc:
            warnings.append(
                f"Unable to resolve project ID for config layers: {exc}. Skipping project layer."
            )
            resolved_project_id = None

    project_config: dict[str, Any] = {}
    if resolved_project_id:
        project_path = get_project_layer_path(resolved_project_id)
        project_config = _load_layer_file(project_path, warnings, "project config")

    session_config: dict[str, Any] = {}
    resolved_session_path = session_path or get_session_layer_override()
    if resolved_session_path:
        if not resolved_session_path.exists():
            warnings.append(f"Session config not found at {resolved_session_path}. Ignoring.")
        else:
            session_config = _load_layer_file(resolved_session_path, warnings, "session config")

    layers_empty = not user_config and not project_config and not session_config
    if LEGACY_CONFIG_PATH.exists() and layers_empty:
        warnings.append(
            f"Legacy config detected at {LEGACY_CONFIG_PATH}. "
            "Run 'obra setup' to regenerate config layers."
        )

    origins: dict[str, str] = {}
    merged: dict[str, Any] = {}
    if include_defaults:
        defaults = _get_default_schema_cached()
        merged = deepcopy(defaults)
        _record_origins(defaults, "default", origins)

    _merge_with_origins(merged, user_config, "user", origins)
    if project_config:
        _merge_with_origins(merged, project_config, "project", origins)
    if session_config:
        _merge_with_origins(merged, session_config, "session", origins)

    _normalize_agent_bool_configs(merged, origins, include_defaults)
    expand_automation_mode(merged, origins)
    return merged, origins, warnings


def load_project_layer(project_id: str) -> tuple[dict[str, Any], list[str], bool]:
    """Load a project-specific config layer."""
    warnings: list[str] = []
    path = get_project_layer_path(project_id)
    if not path.exists():
        return {}, warnings, False
    return _load_layer_file(path, warnings, "project config"), warnings, True


def save_config(config: dict[str, Any]) -> None:
    """Save configuration to ~/.obra/config-layers/01-user.yaml.

    Args:
        config: Configuration dictionary to save

    Raises:
        OSError: If unable to write config file
    """
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)

    with CONFIG_PATH.open("w", encoding="utf-8") as f:
        yaml.safe_dump(config, f, default_flow_style=False, sort_keys=False)


def load_auth_state() -> dict[str, Any]:
    """Load auth state from ~/.obra/auth.yaml.

    Auth credentials are stored separately from application config so that
    the config schema validator does not flag them as unknown keys.

    On first call after upgrade, migrates auth keys from the old location
    (01-user.yaml) into auth.yaml so users don't need to re-login.

    Returns:
        Auth state dictionary (empty if file does not exist)
    """
    if not AUTH_STATE_PATH.exists():
        _migrate_auth_from_config()
        if not AUTH_STATE_PATH.exists():
            return {}

    try:
        with AUTH_STATE_PATH.open(encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
    except Exception:
        logger.warning("Failed to load auth state from %s", AUTH_STATE_PATH)
        return {}

    if not isinstance(data, dict):
        return {}
    return data


# Auth keys to migrate from old config location
_AUTH_STATE_KEYS = frozenset({
    "firebase_uid",
    "user_email",
    "user_id",
    "auth_token",
    "refresh_token",
    "auth_provider",
    "auth_timestamp",
    "display_name",
    "token_expires_at",
})


def _migrate_auth_from_config() -> None:
    """One-time migration: extract auth keys from 01-user.yaml into auth.yaml.

    Runs only when auth.yaml does not exist and the old config has auth keys.
    After extraction, the auth keys are removed from 01-user.yaml.
    """
    if not CONFIG_PATH.exists():
        return

    try:
        with CONFIG_PATH.open(encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}
    except Exception:
        return

    if not isinstance(config, dict):
        return

    # Extract auth keys that exist in the old config
    auth_state = {k: config[k] for k in _AUTH_STATE_KEYS if k in config}
    if not auth_state:
        return

    # Write auth state to new location
    AUTH_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    with AUTH_STATE_PATH.open("w", encoding="utf-8") as f:
        yaml.safe_dump(auth_state, f, default_flow_style=False, sort_keys=False)

    # Remove auth keys from old config
    for k in _AUTH_STATE_KEYS:
        config.pop(k, None)
    with CONFIG_PATH.open("w", encoding="utf-8") as f:
        yaml.safe_dump(config, f, default_flow_style=False, sort_keys=False)

    logger.info("Migrated auth credentials from %s to %s", CONFIG_PATH, AUTH_STATE_PATH)


def save_auth_state(state: dict[str, Any]) -> None:
    """Save auth state to ~/.obra/auth.yaml.

    Args:
        state: Auth state dictionary to save
    """
    AUTH_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)

    with AUTH_STATE_PATH.open("w", encoding="utf-8") as f:
        yaml.safe_dump(state, f, default_flow_style=False, sort_keys=False)


def get_api_base_url() -> str:
    """Get API base URL with environment variable override support.

    Resolution order:
    1. OBRA_API_BASE_URL environment variable
    2. api_base_url from config file
    3. DEFAULT_API_BASE_URL constant

    Returns:
        API base URL string

    Example:
        # Override for local development
        export OBRA_API_BASE_URL="http://localhost:5001/obra-205b0/us-central1"

        # Override for staging
        export OBRA_API_BASE_URL="https://us-central1-obra-staging.cloudfunctions.net"
    """
    # Priority 1: Environment variable
    env_url = os.environ.get("OBRA_API_BASE_URL")
    if env_url:
        return env_url.rstrip("/")

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    config_url = config.get("api_base_url")
    if isinstance(config_url, str):
        return config_url.rstrip("/")

    # Priority 3: Default constant
    return DEFAULT_API_BASE_URL


def enable_local_mode() -> None:
    """Enable local emulator mode for the current process.

    Sets the OBRA_API_BASE_URL environment variable to the local emulator URL.
    This affects all subsequent API calls in the current process.

    Called when --local flag is passed to CLI commands.

    Example:
        # In CLI command handler
        if local:
            enable_local_mode()
        # All subsequent APIClient calls will use the emulator
    """
    os.environ["OBRA_API_BASE_URL"] = LOCAL_EMULATOR_API_URL
    logger.info("Local mode enabled: API calls will use %s", LOCAL_EMULATOR_API_URL)


def is_local_mode() -> bool:
    """Check if local emulator mode is currently enabled.

    Returns:
        True if the API base URL is set to the local emulator URL
    """
    return get_api_base_url() == LOCAL_EMULATOR_API_URL


def get_llm_timeout() -> int:
    """Get LLM execution timeout in seconds.

    Resolution order:
    1. OBRA_LLM_TIMEOUT environment variable
    2. llm_timeout from config file
    3. DEFAULT_LLM_TIMEOUT constant (1800s = 30 min)

    Returns:
        Timeout in seconds

    Example:
        # Override for long-running tasks
        export OBRA_LLM_TIMEOUT=3600

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # llm_timeout: 3600
    """
    # Priority 1: Environment variable
    env_timeout = os.environ.get("OBRA_LLM_TIMEOUT")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    config_timeout = config.get("llm_timeout")
    if config_timeout:
        return int(config_timeout)

    # Priority 3: Default constant
    return DEFAULT_LLM_TIMEOUT


# ---- Input Budget Preflight Config (FEAT-LLM-CONTEXT-BUDGET-001) ----

DEFAULT_INPUT_BUDGET_ENABLED = True
DEFAULT_INPUT_BUDGET_WARNING_THRESHOLD = 0.85
DEFAULT_INPUT_BUDGET_ON_EXCEED = "warn"


def get_input_budget_enabled() -> bool:
    """Get whether input budget preflight checks are enabled.

    Resolution order:
    1. OBRA_INPUT_BUDGET_ENABLED environment variable
    2. llm.input_budget.enabled from config file
    3. DEFAULT_INPUT_BUDGET_ENABLED constant (True)

    Returns:
        True if preflight checks are enabled
    """
    env_val = os.environ.get("OBRA_INPUT_BUDGET_ENABLED")
    if env_val is not None:
        return env_val.lower() in ("true", "1", "yes")

    config, _, _ = load_layered_config()
    llm_config = config.get("llm", {})
    if isinstance(llm_config, dict):
        budget_config = llm_config.get("input_budget", {})
        if isinstance(budget_config, dict):
            enabled = budget_config.get("enabled")
            if enabled is not None:
                return bool(enabled)

    return DEFAULT_INPUT_BUDGET_ENABLED


def get_input_budget_warning_threshold() -> float:
    """Get input budget warning threshold (utilization ratio).

    Resolution order:
    1. OBRA_INPUT_BUDGET_WARNING_THRESHOLD environment variable
    2. llm.input_budget.warning_threshold from config file
    3. DEFAULT_INPUT_BUDGET_WARNING_THRESHOLD constant (0.85)

    Returns:
        Warning threshold as a float (0.0-1.0)
    """
    env_val = os.environ.get("OBRA_INPUT_BUDGET_WARNING_THRESHOLD")
    if env_val is not None:
        try:
            return float(env_val)
        except ValueError:
            pass

    config, _, _ = load_layered_config()
    llm_config = config.get("llm", {})
    if isinstance(llm_config, dict):
        budget_config = llm_config.get("input_budget", {})
        if isinstance(budget_config, dict):
            threshold = budget_config.get("warning_threshold")
            if threshold is not None:
                return float(threshold)

    return DEFAULT_INPUT_BUDGET_WARNING_THRESHOLD


def get_input_budget_on_exceed() -> str:
    """Get input budget exceed policy.

    Resolution order:
    1. OBRA_INPUT_BUDGET_ON_EXCEED environment variable
    2. llm.input_budget.on_exceed from config file
    3. DEFAULT_INPUT_BUDGET_ON_EXCEED constant ("warn")

    Returns:
        "warn" (log and continue) or "fail" (return error, no provider call)
    """
    env_val = os.environ.get("OBRA_INPUT_BUDGET_ON_EXCEED")
    if env_val is not None:
        return env_val.lower()

    config, _, _ = load_layered_config()
    llm_config = config.get("llm", {})
    if isinstance(llm_config, dict):
        budget_config = llm_config.get("input_budget", {})
        if isinstance(budget_config, dict):
            on_exceed = budget_config.get("on_exceed")
            if on_exceed is not None:
                return str(on_exceed).lower()

    return DEFAULT_INPUT_BUDGET_ON_EXCEED


def get_agent_execution_timeout() -> int:
    """Get agent execution timeout in seconds.

    Resolution order:
    1. OBRA_AGENT_EXECUTION_TIMEOUT environment variable
    2. orchestration.timeouts.agent_execution_s from config file
    3. DEFAULT_AGENT_EXECUTION_TIMEOUT constant (5400s = 90 min)

    Returns:
        Timeout in seconds

    Example:
        # Override for shorter timeout
        export OBRA_AGENT_EXECUTION_TIMEOUT=300

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   timeouts:
        #     agent_execution_s: 300
    """
    # Priority 1: Environment variable
    env_timeout = os.environ.get("OBRA_AGENT_EXECUTION_TIMEOUT")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        timeouts_config = orch_config.get("timeouts", {})
        if isinstance(timeouts_config, dict):
            timeout = timeouts_config.get("agent_execution_s")
            if timeout is not None:
                return int(timeout)

    # Priority 3: Default constant
    return DEFAULT_AGENT_EXECUTION_TIMEOUT


def get_prompt_retention() -> bool:
    """Get prompt file retention setting.

    Resolution order:
    1. orchestration.prompts.retain from config file
    2. DEFAULT_PROMPT_RETAIN constant (False)

    Returns:
        True if prompt files should be retained, else False
    """
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        prompts_config = orch_config.get("prompts", {})
        if isinstance(prompts_config, dict):
            retain = prompts_config.get("retain")
            if retain is not None:
                return bool(retain)
    return DEFAULT_PROMPT_RETAIN


def get_template_retention_settings() -> tuple[bool, bool]:
    """Get template edit retention settings.

    Resolution order:
    1. orchestration.template_retention.keep_on_success from config file
    2. orchestration.template_retention.keep_on_error from config file
    3. DEFAULT_TEMPLATE_RETAIN_ON_SUCCESS/ERROR constants

    Returns:
        Tuple of (keep_on_success, keep_on_error)
    """
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    keep_on_success = DEFAULT_TEMPLATE_RETAIN_ON_SUCCESS
    keep_on_error = DEFAULT_TEMPLATE_RETAIN_ON_ERROR
    if isinstance(orch_config, dict):
        template_config = orch_config.get("template_retention", {})
        if isinstance(template_config, dict):
            if template_config.get("keep_on_success") is not None:
                keep_on_success = bool(template_config.get("keep_on_success"))
            if template_config.get("keep_on_error") is not None:
                keep_on_error = bool(template_config.get("keep_on_error"))

    return (keep_on_success, keep_on_error)


def get_prompt_max_files() -> int:
    """Get max prompt files to retain before cleanup.

    Resolution order:
    1. orchestration.prompts.max_files from config file
    2. DEFAULT_PROMPT_MAX_FILES constant (200)

    Returns:
        Max prompt files to retain before cleanup
    """
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        prompts_config = orch_config.get("prompts", {})
        if isinstance(prompts_config, dict):
            max_files = prompts_config.get("max_files")
            if max_files is not None:
                try:
                    return int(max_files)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_PROMPT_MAX_FILES


DEFAULT_PROMPT_CLEANUP_AGE_HOURS = 24


def get_prompt_cleanup_age_hours() -> int:
    """Get age threshold in hours for prompt cleanup.

    Prompt files older than this threshold are eligible for cleanup
    via the explicit 'obra prompts cleanup' command.

    Resolution order:
    1. orchestration.prompts.cleanup_age_hours from config file
    2. DEFAULT_PROMPT_CLEANUP_AGE_HOURS constant (24)

    Returns:
        Age threshold in hours for prompt file cleanup
    """
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        prompts_config = orch_config.get("prompts", {})
        if isinstance(prompts_config, dict):
            age_hours = prompts_config.get("cleanup_age_hours")
            if age_hours is not None:
                try:
                    return int(age_hours)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_PROMPT_CLEANUP_AGE_HOURS


def get_review_agent_timeout() -> int:
    """Get review agent timeout in seconds.

    Resolution order:
    1. OBRA_REVIEW_AGENT_TIMEOUT environment variable
    2. orchestration.timeouts.review_agent_s from config file
    3. DEFAULT_REVIEW_AGENT_TIMEOUT constant (1800s = 30 min)

    Returns:
        Timeout in seconds

    Example:
        # Override for longer review timeout
        export OBRA_REVIEW_AGENT_TIMEOUT=120

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   timeouts:
        #     review_agent_s: 120
    """
    # Priority 1: Environment variable
    env_timeout = os.environ.get("OBRA_REVIEW_AGENT_TIMEOUT")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        timeouts_config = orch_config.get("timeouts", {})
        if isinstance(timeouts_config, dict):
            timeout = timeouts_config.get("review_agent_s")
            if timeout is not None:
                return int(timeout)

    # Priority 3: Default constant
    return DEFAULT_REVIEW_AGENT_TIMEOUT


def get_cli_runner_timeout() -> int:
    """Get CLI runner timeout in seconds for orchestration LLM calls.

    Used by cli_runner.py for orchestration operations like derive, examine,
    revise, and planning. This is the longest timeout because orchestration
    is the critical path - if it times out, the entire session fails.

    Resolution order:
    1. OBRA_CLI_RUNNER_TIMEOUT environment variable
    2. orchestration.timeouts.cli_runner_s from config file
    3. DEFAULT_CLI_RUNNER_TIMEOUT constant (7200s = 120 min)

    Returns:
        Timeout in seconds

    Example:
        # Override for shorter orchestration timeout
        export OBRA_CLI_RUNNER_TIMEOUT=3600

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   timeouts:
        #     cli_runner_s: 3600
    """
    # Priority 1: Environment variable
    env_timeout = os.environ.get("OBRA_CLI_RUNNER_TIMEOUT")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        timeouts_config = orch_config.get("timeouts", {})
        if isinstance(timeouts_config, dict):
            timeout = timeouts_config.get("cli_runner_s")
            if timeout is not None:
                return int(timeout)

    # Priority 3: Default constant
    return DEFAULT_CLI_RUNNER_TIMEOUT


def get_llm_api_timeout() -> int:
    """Get LLM API operation timeout in seconds.

    This is the timeout for individual LLM API calls (quality assessment,
    intent extraction, etc.). Distinct from orchestration timeouts.

    Resolution order:
    1. OBRA_LLM_API_TIMEOUT environment variable
    2. orchestration.timeouts.llm_request from config file
    3. DEFAULT_LLM_API_TIMEOUT constant (900s = 15 min)

    Returns:
        Timeout in seconds

    Example:
        # Override via environment variable
        export OBRA_LLM_API_TIMEOUT=1800

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   timeouts:
        #     llm_request: 1800
    """
    # Priority 1: Environment variable
    env_timeout = os.environ.get("OBRA_LLM_API_TIMEOUT")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        timeouts_config = orch_config.get("timeouts", {})
        if isinstance(timeouts_config, dict):
            timeout = timeouts_config.get("llm_request")
            if timeout is not None:
                return int(timeout)

    # Priority 3: Default constant
    return DEFAULT_LLM_API_TIMEOUT


def get_llm_stream_idle_timeout() -> int:
    """Get streaming LLM idle timeout in seconds.

    This timeout applies to streaming subprocess calls. If no stdout/stderr
    is produced for this duration, the subprocess is terminated and retried.

    Resolution order:
    1. OBRA_LLM_STREAM_IDLE_TIMEOUT environment variable
    2. orchestration.timeouts.llm_stream_idle_s from config file
    3. DEFAULT_LLM_STREAM_IDLE_TIMEOUT constant (0 = disabled)

    Returns:
        Idle timeout in seconds (0 disables idle timeout)

    Note:
        Disabled by default. The liveness detection system provides smarter
        hang detection using CPU activity, file modifications, and log entries.
        Only enable stream idle timeout if you need a simple fallback.

    Example:
        # Override via environment variable (e.g., 10 minutes)
        export OBRA_LLM_STREAM_IDLE_TIMEOUT=600

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   timeouts:
        #     llm_stream_idle_s: 600
    """
    # Priority 1: Environment variable
    env_timeout = os.environ.get("OBRA_LLM_STREAM_IDLE_TIMEOUT")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        timeouts_config = orch_config.get("timeouts", {})
        if isinstance(timeouts_config, dict):
            timeout = timeouts_config.get("llm_stream_idle_s")
            if timeout is not None:
                return int(timeout)

    # Priority 3: Default constant
    return DEFAULT_LLM_STREAM_IDLE_TIMEOUT


def get_heartbeat_interval() -> int:
    """Get heartbeat interval in seconds.

    Resolution order:
    1. OBRA_HEARTBEAT_INTERVAL environment variable
    2. orchestration.progress.heartbeat_interval_s from config file
    3. Default 60 seconds

    Returns:
        Heartbeat interval in seconds

    Example:
        # Override for more frequent heartbeats
        export OBRA_HEARTBEAT_INTERVAL=30

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   progress:
        #     heartbeat_interval_s: 30
    """
    # Priority 1: Environment variable
    env_interval = os.environ.get("OBRA_HEARTBEAT_INTERVAL")
    if env_interval:
        try:
            value = int(env_interval)
            if value > 0:
                return value
            logger.warning("OBRA_HEARTBEAT_INTERVAL must be > 0 (got %s)", env_interval)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        progress_config = orch_config.get("progress", {})
        if isinstance(progress_config, dict):
            interval = progress_config.get("heartbeat_interval_s")
            if interval is not None:
                value = int(interval)
                if value > 0:
                    return value
                logger.warning(
                    "orchestration.progress.heartbeat_interval_s must be > 0 (got %s)",
                    interval,
                )

    # Priority 3: Default constant
    return 60


def get_heartbeat_initial_delay() -> int:
    """Get heartbeat initial delay in seconds.

    Resolution order:
    1. OBRA_HEARTBEAT_INITIAL_DELAY environment variable
    2. orchestration.progress.heartbeat_initial_delay_s from config file
    3. Default 30 seconds

    Returns:
        Heartbeat initial delay in seconds

    Example:
        # Override for shorter initial delay
        export OBRA_HEARTBEAT_INITIAL_DELAY=10

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   progress:
        #     heartbeat_initial_delay_s: 10
    """
    # Priority 1: Environment variable
    env_delay = os.environ.get("OBRA_HEARTBEAT_INITIAL_DELAY")
    if env_delay:
        try:
            value = int(env_delay)
            if value >= 0:
                return value
            logger.warning("OBRA_HEARTBEAT_INITIAL_DELAY must be >= 0 (got %s)", env_delay)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        progress_config = orch_config.get("progress", {})
        if isinstance(progress_config, dict):
            delay = progress_config.get("heartbeat_initial_delay_s")
            if delay is not None:
                value = int(delay)
                if value >= 0:
                    return value
                logger.warning(
                    "orchestration.progress.heartbeat_initial_delay_s must be >= 0 (got %s)",
                    delay,
                )

    # Priority 3: Default constant
    return 30


# LLM logging defaults (FEAT-LLM-LOG-VIEWER-001)
DEFAULT_LLM_LOGGING_PREVIEW_ENABLED = True
DEFAULT_LLM_LOGGING_PREVIEW_MAX_PROMPT_CHARS = 500
DEFAULT_LLM_LOGGING_PREVIEW_MAX_RESPONSE_CHARS = 1000
DEFAULT_SLOW_LLM_CALL_THRESHOLD_MS = 60000  # HYBRID-084: 60s default


def get_llm_logging_preview_enabled() -> bool:
    """Get whether LLM call event previews are enabled.

    Resolution order:
    1. advanced.llm_logging.preview_enabled from config file
    2. DEFAULT_LLM_LOGGING_PREVIEW_ENABLED constant (True)

    Returns:
        True if prompt/response previews should be included in llm_call events

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # advanced:
        #   llm_logging:
        #     preview_enabled: false
    """
    config, _, _ = load_layered_config()
    advanced_config = config.get("advanced", {})
    if isinstance(advanced_config, dict):
        llm_logging_config = advanced_config.get("llm_logging", {})
        if isinstance(llm_logging_config, dict):
            preview_enabled = llm_logging_config.get("preview_enabled")
            if preview_enabled is not None:
                return bool(preview_enabled)

    return DEFAULT_LLM_LOGGING_PREVIEW_ENABLED


def get_llm_logging_preview_max_prompt_chars() -> int:
    """Get max characters for prompt preview in llm_call events.

    Resolution order:
    1. advanced.llm_logging.preview_max_prompt_chars from config file
    2. DEFAULT_LLM_LOGGING_PREVIEW_MAX_PROMPT_CHARS constant (500)

    Returns:
        Maximum characters to include from prompt (truncated if longer)

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # advanced:
        #   llm_logging:
        #     preview_max_prompt_chars: 1000
    """
    config, _, _ = load_layered_config()
    advanced_config = config.get("advanced", {})
    if isinstance(advanced_config, dict):
        llm_logging_config = advanced_config.get("llm_logging", {})
        if isinstance(llm_logging_config, dict):
            max_chars = llm_logging_config.get("preview_max_prompt_chars")
            if max_chars is not None:
                try:
                    return int(max_chars)
                except (TypeError, ValueError):
                    pass

    return DEFAULT_LLM_LOGGING_PREVIEW_MAX_PROMPT_CHARS


def get_llm_logging_preview_max_response_chars() -> int:
    """Get max characters for response preview in llm_call events.

    Resolution order:
    1. advanced.llm_logging.preview_max_response_chars from config file
    2. DEFAULT_LLM_LOGGING_PREVIEW_MAX_RESPONSE_CHARS constant (1000)

    Returns:
        Maximum characters to include from response (truncated if longer)

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # advanced:
        #   llm_logging:
        #     preview_max_response_chars: 2000
    """
    config, _, _ = load_layered_config()
    advanced_config = config.get("advanced", {})
    if isinstance(advanced_config, dict):
        llm_logging_config = advanced_config.get("llm_logging", {})
        if isinstance(llm_logging_config, dict):
            max_chars = llm_logging_config.get("preview_max_response_chars")
            if max_chars is not None:
                try:
                    return int(max_chars)
                except (TypeError, ValueError):
                    pass

    return DEFAULT_LLM_LOGGING_PREVIEW_MAX_RESPONSE_CHARS


def get_slow_llm_call_threshold_ms() -> int:
    """Get threshold (ms) for slow LLM call alerting.

    Resolution order:
    1. orchestration.llm.slow_call_threshold_ms from config file
    2. DEFAULT_SLOW_LLM_CALL_THRESHOLD_MS constant (60000)

    Set to 0 to disable slow call alerting.
    """
    try:
        config, _, _ = load_layered_config()
        orchestration = config.get("orchestration", {})
        if isinstance(orchestration, dict):
            llm_section = orchestration.get("llm", {})
            if isinstance(llm_section, dict):
                raw = llm_section.get("slow_call_threshold_ms")
                if raw is not None:
                    try:
                        return int(raw)
                    except (TypeError, ValueError):
                        pass
    except Exception:
        pass
    return DEFAULT_SLOW_LLM_CALL_THRESHOLD_MS


# Default watchdog settings (ISSUE-HYBRID-003)
DEFAULT_WATCHDOG_ENABLED = True
DEFAULT_WATCHDOG_STALL_TIMEOUT_S = 1800  # 30 minutes

# Adaptive decomposition defaults (FEAT-ADAPTIVE-DECOMP-001)
DEFAULT_DECOMPOSITION_ENABLED = True
DEFAULT_DECOMPOSITION_DURATION_THRESHOLD_S = 600  # 10 minutes
DEFAULT_DECOMPOSITION_WARNING_THRESHOLD_S = 300  # 5 minutes
DEFAULT_DECOMPOSITION_MAX_ATTEMPTS = 2
DEFAULT_DECOMPOSITION_SUMMARY_MAX_CHARS = 2000

# Session runtime limits (FEAT-SESSION-GUARD-001)
DEFAULT_SESSION_WARNING_HOURS = 24  # Prompt user after 24 hours
DEFAULT_SESSION_MAX_HOURS = 48  # Hard limit at 48 hours

# Interactive guard defaults (FEAT-INTERACTIVE-GUARD-001)
DEFAULT_INTERACTIVE_GUARD_ENABLED = True
DEFAULT_INTERACTIVE_GUARD_PATTERNS = [
    r"(?i)\bpassword\b",
    r"(?i)enter passphrase",
    r"(?i)are you sure.*\?(\s*\[y/n\]|\s*\(y/n\))?",
    r"(?i)continue\?\s*(\[y/n\]|\(y/n\))?",
    r"(?i)press any key",
    r"(?i)enter .* to continue",
]
DEFAULT_INTERACTIVE_GUARD_RETRY_MAX = 1
DEFAULT_INTERACTIVE_GUARD_ROLLBACK_ENABLED = True
DEFAULT_INTERACTIVE_GUARD_ROLLBACK_CODES = ["LLM_INTERACTIVE_BLOCKED"]


def get_watchdog_enabled() -> bool:
    """Get whether session watchdog is enabled.

    The session watchdog detects stalled sessions where no progress is made
    (no events logged) while no LLM subprocess is active.

    Resolution order:
    1. OBRA_WATCHDOG_ENABLED environment variable
    2. orchestration.watchdog.enabled from config file
    3. DEFAULT_WATCHDOG_ENABLED constant (True)

    Returns:
        True if watchdog is enabled

    Example:
        # Disable via environment variable
        export OBRA_WATCHDOG_ENABLED=false

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   watchdog:
        #     enabled: false
    """
    # Priority 1: Environment variable
    env_enabled = os.environ.get("OBRA_WATCHDOG_ENABLED")
    if env_enabled is not None:
        return env_enabled.lower() in ("true", "1", "yes")

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        watchdog_config = orch_config.get("watchdog", {})
        if isinstance(watchdog_config, dict):
            enabled = watchdog_config.get("enabled")
            if enabled is not None:
                return bool(enabled)

    # Priority 3: Default constant
    return DEFAULT_WATCHDOG_ENABLED


def _get_interactive_guard_config() -> dict[str, Any]:
    """Return orchestration.interactive_guard config section."""
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        guard_config = orch_config.get("interactive_guard", {})
        if isinstance(guard_config, dict):
            return guard_config
    return {}


def get_interactive_guard_enabled() -> bool:
    """Get interactive guard enabled flag."""
    guard_config = _get_interactive_guard_config()
    enabled = guard_config.get("enabled")
    if enabled is not None:
        return bool(enabled)
    return DEFAULT_INTERACTIVE_GUARD_ENABLED


def get_interactive_guard_patterns() -> list[str]:
    """Get interactive guard regex patterns."""
    guard_config = _get_interactive_guard_config()
    patterns = guard_config.get("patterns")
    if isinstance(patterns, list) and patterns:
        return [str(pattern) for pattern in patterns]
    return DEFAULT_INTERACTIVE_GUARD_PATTERNS.copy()


def get_interactive_guard_retry_max() -> int:
    """Get interactive guard retry max."""
    guard_config = _get_interactive_guard_config()
    retry_max = guard_config.get("retry_max")
    if retry_max is not None:
        return int(retry_max)
    return DEFAULT_INTERACTIVE_GUARD_RETRY_MAX


def get_interactive_guard_rollback_enabled() -> bool:
    """Get interactive guard rollback enabled flag."""
    guard_config = _get_interactive_guard_config()
    rollback = guard_config.get("rollback")
    if isinstance(rollback, dict):
        enabled = rollback.get("enabled")
        if enabled is not None:
            return bool(enabled)
    return DEFAULT_INTERACTIVE_GUARD_ROLLBACK_ENABLED


def get_interactive_guard_rollback_codes() -> list[str]:
    """Get interactive guard rollback trigger codes."""
    guard_config = _get_interactive_guard_config()
    rollback = guard_config.get("rollback")
    if isinstance(rollback, dict):
        codes = rollback.get("trigger_codes")
        if isinstance(codes, list) and codes:
            return [str(code) for code in codes]
    return DEFAULT_INTERACTIVE_GUARD_ROLLBACK_CODES.copy()


def get_watchdog_stall_timeout() -> int:
    """Get watchdog stall timeout in seconds.

    The stall timeout is the number of seconds of no events before a session
    is considered stalled. Only triggers when no LLM subprocess is active.

    Resolution order:
    1. OBRA_WATCHDOG_STALL_TIMEOUT environment variable
    2. orchestration.watchdog.stall_timeout_s from config file
    3. DEFAULT_WATCHDOG_STALL_TIMEOUT_S constant (1800s = 30 minutes)

    Returns:
        Stall timeout in seconds

    Example:
        # Override for shorter timeout (10 minutes)
        export OBRA_WATCHDOG_STALL_TIMEOUT=600

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   watchdog:
        #     stall_timeout_s: 600
    """
    # Priority 1: Environment variable
    env_timeout = os.environ.get("OBRA_WATCHDOG_STALL_TIMEOUT")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        watchdog_config = orch_config.get("watchdog", {})
        if isinstance(watchdog_config, dict):
            timeout = watchdog_config.get("stall_timeout_s")
            if timeout is not None:
                return int(timeout)

    # Priority 3: Default constant
    return DEFAULT_WATCHDOG_STALL_TIMEOUT_S


def get_decomposition_duration_threshold_s() -> int:
    """Get adaptive decomposition duration threshold in seconds.

    Resolution order:
    1. OBRA_DECOMPOSE_DURATION_S environment variable
    2. orchestration.decomposition.duration_threshold_s from config file
    3. DEFAULT_DECOMPOSITION_DURATION_THRESHOLD_S constant (600s = 10 minutes)

    Returns:
        Duration threshold in seconds

    Example:
        # Override duration threshold
        export OBRA_DECOMPOSE_DURATION_S=900

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   decomposition:
        #     duration_threshold_s: 900
    """
    env_timeout = os.environ.get("OBRA_DECOMPOSE_DURATION_S")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        decomposition_config = orch_config.get("decomposition", {})
        if isinstance(decomposition_config, dict):
            threshold = decomposition_config.get("duration_threshold_s")
            if threshold is not None:
                return int(threshold)

    return DEFAULT_DECOMPOSITION_DURATION_THRESHOLD_S


def get_decomposition_warning_threshold_s() -> int:
    """Get adaptive decomposition warning threshold in seconds.

    Resolution order:
    1. OBRA_DECOMPOSE_WARNING_S environment variable
    2. orchestration.decomposition.warning_threshold_s from config file
    3. DEFAULT_DECOMPOSITION_WARNING_THRESHOLD_S constant (300s = 5 minutes)

    Returns:
        Warning threshold in seconds

    Example:
        # Override warning threshold
        export OBRA_DECOMPOSE_WARNING_S=300

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   decomposition:
        #     warning_threshold_s: 300
    """
    env_timeout = os.environ.get("OBRA_DECOMPOSE_WARNING_S")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        decomposition_config = orch_config.get("decomposition", {})
        if isinstance(decomposition_config, dict):
            threshold = decomposition_config.get("warning_threshold_s")
            if threshold is not None:
                return int(threshold)

    return DEFAULT_DECOMPOSITION_WARNING_THRESHOLD_S


def get_decomposition_max_attempts() -> int:
    """Get adaptive decomposition max attempts per task."""
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        decomposition_config = orch_config.get("decomposition", {})
        if isinstance(decomposition_config, dict):
            attempts = decomposition_config.get("max_attempts")
            if attempts is not None:
                return int(attempts)
    return DEFAULT_DECOMPOSITION_MAX_ATTEMPTS


def get_decomposition_summary_max_chars() -> int:
    """Get max characters for partial work summary."""
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        decomposition_config = orch_config.get("decomposition", {})
        if isinstance(decomposition_config, dict):
            max_chars = decomposition_config.get("summary_max_chars")
            if max_chars is not None:
                return int(max_chars)
    return DEFAULT_DECOMPOSITION_SUMMARY_MAX_CHARS


def is_decomposition_enabled() -> bool:
    """Check whether adaptive decomposition is enabled.

    Requires both features.userplan.auto_decompose.enabled and
    orchestration.decomposition.enabled (or legacy orchestration.auto_decompose_on_timeout).
    """
    config, _, _ = load_layered_config()

    auto_decompose_enabled = True
    features_config = config.get("features", {})
    if isinstance(features_config, dict):
        userplan_config = features_config.get("userplan", {})
        if isinstance(userplan_config, dict):
            auto_decompose_config = userplan_config.get("auto_decompose", {})
            if isinstance(auto_decompose_config, dict):
                enabled = auto_decompose_config.get("enabled")
                if enabled is not None:
                    auto_decompose_enabled = bool(enabled)

    decomposition_enabled = DEFAULT_DECOMPOSITION_ENABLED
    enabled = None
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        decomposition_config = orch_config.get("decomposition", {})
        if isinstance(decomposition_config, dict):
            enabled = decomposition_config.get("enabled")
            if enabled is not None:
                decomposition_enabled = bool(enabled)
        if enabled is None:
            legacy_enabled = orch_config.get("auto_decompose_on_timeout")
            if legacy_enabled is not None:
                decomposition_enabled = bool(legacy_enabled)

    return auto_decompose_enabled and decomposition_enabled


def get_watchdog_max_silent_seconds() -> int:
    """Get watchdog max silent seconds timeout (ISSUE-HYBRID-008).

    The max_silent_seconds is the absolute maximum time with no events before
    stall detection triggers, REGARDLESS of whether a handler is active.
    This catches HTTP hangs and other silent failures during handler execution.

    Resolution order:
    1. OBRA_WATCHDOG_MAX_SILENT_SECONDS environment variable
    2. orchestration.watchdog.max_silent_seconds from config file
    3. DEFAULT_WATCHDOG_STALL_TIMEOUT_S constant (1800s = 30 minutes)

    Note: This timeout applies even when _handler_active=True, unlike stall_timeout_s.

    Returns:
        Max silent seconds timeout

    Example:
        # Override for shorter timeout (10 minutes)
        export OBRA_WATCHDOG_MAX_SILENT_SECONDS=600

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   watchdog:
        #     max_silent_seconds: 600
    """
    # Priority 1: Environment variable
    env_timeout = os.environ.get("OBRA_WATCHDOG_MAX_SILENT_SECONDS")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        watchdog_config = orch_config.get("watchdog", {})
        if isinstance(watchdog_config, dict):
            timeout = watchdog_config.get("max_silent_seconds")
            if timeout is not None:
                return int(timeout)

    # Priority 3: Default constant (same as stall_timeout default)
    return DEFAULT_WATCHDOG_STALL_TIMEOUT_S


def get_session_warning_hours() -> float:
    """Get session runtime warning threshold in hours (FEAT-SESSION-GUARD-001).

    After this many hours, the session will prompt the user to continue.
    User input resets the timer for another warning_hours period.

    Resolution order:
    1. OBRA_SESSION_WARNING_HOURS environment variable
    2. orchestration.session.warning_hours from config file
    3. DEFAULT_SESSION_WARNING_HOURS constant (24 hours)

    Returns:
        Warning threshold in hours
    """
    env_val = os.environ.get("OBRA_SESSION_WARNING_HOURS")
    if env_val:
        try:
            return float(env_val)
        except ValueError:
            pass

    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        session_config = orch_config.get("session", {})
        if isinstance(session_config, dict):
            val = session_config.get("warning_hours")
            if val is not None:
                return float(val)

    return DEFAULT_SESSION_WARNING_HOURS


def get_session_max_hours() -> float:
    """Get session maximum runtime in hours (FEAT-SESSION-GUARD-001).

    Hard limit - session terminates after this many hours regardless of user input.

    Resolution order:
    1. OBRA_SESSION_MAX_HOURS environment variable
    2. orchestration.session.max_hours from config file
    3. DEFAULT_SESSION_MAX_HOURS constant (48 hours)

    Returns:
        Maximum runtime in hours
    """
    env_val = os.environ.get("OBRA_SESSION_MAX_HOURS")
    if env_val:
        try:
            return float(env_val)
        except ValueError:
            pass

    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        session_config = orch_config.get("session", {})
        if isinstance(session_config, dict):
            val = session_config.get("max_hours")
            if val is not None:
                return float(val)

    return DEFAULT_SESSION_MAX_HOURS


def get_max_iterations() -> int:
    """Get maximum orchestration loop iterations.

    Resolution order:
    1. OBRA_MAX_ITERATIONS environment variable
    2. max_iterations from config file
    3. DEFAULT_MAX_ITERATIONS constant (100)

    Returns:
        Maximum iterations

    Example:
        # Override for complex tasks
        export OBRA_MAX_ITERATIONS=150

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # max_iterations: 150
    """
    # Priority 1: Environment variable
    env_max_iterations = os.environ.get("OBRA_MAX_ITERATIONS")
    if env_max_iterations:
        try:
            return int(env_max_iterations)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    config_max_iterations = config.get("max_iterations")
    if config_max_iterations:
        return int(config_max_iterations)

    # Priority 3: Default constant
    return DEFAULT_MAX_ITERATIONS


def get_default_project_override() -> str | None:
    """Get local default project override from layered config."""
    config, _, _ = load_layered_config()
    projects = config.get("projects", {})
    if isinstance(projects, dict):
        value = projects.get("default_project")
        return str(value) if value is not None else None
    return None


def get_isolated_mode() -> bool | None:
    """Get agent isolation mode from config.

    Returns:
        True: Enable isolation
        False: Disable isolation
        None: Use default (auto-detect from CLI/ENV/CI)

    Config location: ~/.obra/config-layers/01-user.yaml

    Example:
        # In 01-user.yaml:
        agent:
          isolated_mode: true
    """
    config, _, _ = load_layered_config()
    agent_config = config.get("agent", {})
    if isinstance(agent_config, dict):
        return agent_config.get("isolated_mode")
    return None


def set_isolated_mode(enabled: bool | None) -> None:
    """Set agent isolation mode in config.

    Args:
        enabled: True to enable, False to disable, None to clear

    Config location: ~/.obra/config-layers/01-user.yaml
    """
    config, _, _ = load_layered_config()

    if enabled is None:
        # Clear the setting
        if "agent" in config and isinstance(config["agent"], dict):
            config["agent"].pop("isolated_mode", None)
            if not config["agent"]:
                del config["agent"]
    else:
        if "agent" not in config:
            config["agent"] = {}
        config["agent"]["isolated_mode"] = enabled

    save_config(config)


def get_check_for_updates() -> bool:
    """Get version check enable/disable setting.

    Resolution order:
    1. OBRA_CHECK_FOR_UPDATES environment variable
    2. cli.check_for_updates from config file
    3. DEFAULT_CHECK_FOR_UPDATES constant (True)

    Returns:
        True to enable version checks, False to disable

    Example:
        # Disable via environment variable
        export OBRA_CHECK_FOR_UPDATES=false

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # cli:
        #   check_for_updates: false
    """
    # Priority 1: Environment variable
    env_check = os.environ.get("OBRA_CHECK_FOR_UPDATES")
    if env_check:
        return env_check.lower() in ("true", "1", "yes", "on")

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    cli_config = config.get("cli", {})
    if isinstance(cli_config, dict):
        check = cli_config.get("check_for_updates")
        if check is not None:
            return bool(check)

    # Priority 3: Default constant
    return DEFAULT_CHECK_FOR_UPDATES


def get_update_notification_cooldown_minutes() -> int:
    """Get cooldown period between version update notifications.

    Resolution order:
    1. OBRA_UPDATE_NOTIFICATION_COOLDOWN_MINUTES environment variable
    2. cli.update_notification_cooldown_minutes from config file
    3. DEFAULT_UPDATE_NOTIFICATION_COOLDOWN_MINUTES constant (10)

    Returns:
        Cooldown period in minutes

    Example:
        # Override for shorter cooldown
        export OBRA_UPDATE_NOTIFICATION_COOLDOWN_MINUTES=5

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # cli:
        #   update_notification_cooldown_minutes: 5
    """
    # Priority 1: Environment variable
    env_cooldown = os.environ.get("OBRA_UPDATE_NOTIFICATION_COOLDOWN_MINUTES")
    if env_cooldown:
        try:
            return int(env_cooldown)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    cli_config = config.get("cli", {})
    if isinstance(cli_config, dict):
        cooldown = cli_config.get("update_notification_cooldown_minutes")
        if cooldown is not None:
            return int(cooldown)

    # Priority 3: Default constant
    return DEFAULT_UPDATE_NOTIFICATION_COOLDOWN_MINUTES


def get_auto_update() -> bool:
    """Get auto-update enable/disable setting.

    When enabled, Obra automatically runs ``pipx upgrade obra`` on startup
    if the installed version is behind PyPI. Falls back to notification
    banner when disabled.

    Resolution order:
    1. OBRA_AUTO_UPDATE environment variable
    2. cli.auto_update from config file
    3. DEFAULT_AUTO_UPDATE constant (True)

    Returns:
        True to enable auto-update, False to disable
    """
    # Priority 1: Environment variable
    env_val = os.environ.get("OBRA_AUTO_UPDATE")
    if env_val:
        return env_val.lower() in ("true", "1", "yes", "on")

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    cli_config = config.get("cli", {})
    if isinstance(cli_config, dict):
        auto = cli_config.get("auto_update")
        if auto is not None:
            return bool(auto)

    # Priority 3: Default constant
    return DEFAULT_AUTO_UPDATE


def get_auto_update_cooldown_minutes() -> int:
    """Get cooldown period between auto-update checks.

    Resolution order:
    1. OBRA_AUTO_UPDATE_COOLDOWN_MINUTES environment variable
    2. cli.auto_update_cooldown_minutes from config file
    3. DEFAULT_AUTO_UPDATE_COOLDOWN_MINUTES constant (60)

    Returns:
        Cooldown period in minutes
    """
    # Priority 1: Environment variable
    env_cooldown = os.environ.get("OBRA_AUTO_UPDATE_COOLDOWN_MINUTES")
    if env_cooldown:
        try:
            return int(env_cooldown)
        except ValueError:
            pass

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    cli_config = config.get("cli", {})
    if isinstance(cli_config, dict):
        cooldown = cli_config.get("auto_update_cooldown_minutes")
        if cooldown is not None:
            return int(cooldown)

    # Priority 3: Default constant
    return DEFAULT_AUTO_UPDATE_COOLDOWN_MINUTES


def get_auto_update_max_retries() -> int:
    """Get maximum retry attempts for pipx upgrade.

    Resolution order:
    1. OBRA_AUTO_UPDATE_MAX_RETRIES environment variable
    2. cli.auto_update_max_retries from config file
    3. DEFAULT_AUTO_UPDATE_MAX_RETRIES constant (3)

    Returns:
        Maximum number of pipx upgrade attempts
    """
    env_val = os.environ.get("OBRA_AUTO_UPDATE_MAX_RETRIES")
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            pass

    config, _, _ = load_layered_config()
    cli_config = config.get("cli", {})
    if isinstance(cli_config, dict):
        retries = cli_config.get("auto_update_max_retries")
        if retries is not None:
            return int(retries)

    return DEFAULT_AUTO_UPDATE_MAX_RETRIES


def get_auto_update_retry_delay_s() -> float:
    """Get base delay between auto-update retries (doubles each attempt).

    Resolution order:
    1. OBRA_AUTO_UPDATE_RETRY_DELAY_S environment variable
    2. cli.auto_update_retry_delay_s from config file
    3. DEFAULT_AUTO_UPDATE_RETRY_DELAY_S constant (2.0)

    Returns:
        Base delay in seconds
    """
    env_val = os.environ.get("OBRA_AUTO_UPDATE_RETRY_DELAY_S")
    if env_val:
        try:
            return float(env_val)
        except ValueError:
            pass

    config, _, _ = load_layered_config()
    cli_config = config.get("cli", {})
    if isinstance(cli_config, dict):
        delay = cli_config.get("auto_update_retry_delay_s")
        if delay is not None:
            return float(delay)

    return DEFAULT_AUTO_UPDATE_RETRY_DELAY_S


def get_auto_update_pipx_timeout_s() -> int:
    """Get timeout per pipx upgrade attempt.

    Resolution order:
    1. OBRA_AUTO_UPDATE_PIPX_TIMEOUT_S environment variable
    2. cli.auto_update_pipx_timeout_s from config file
    3. DEFAULT_AUTO_UPDATE_PIPX_TIMEOUT_S constant (120)

    Returns:
        Timeout in seconds
    """
    env_val = os.environ.get("OBRA_AUTO_UPDATE_PIPX_TIMEOUT_S")
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            pass

    config, _, _ = load_layered_config()
    cli_config = config.get("cli", {})
    if isinstance(cli_config, dict):
        timeout = cli_config.get("auto_update_pipx_timeout_s")
        if timeout is not None:
            return int(timeout)

    return DEFAULT_AUTO_UPDATE_PIPX_TIMEOUT_S


def get_project_detection_empty_threshold() -> int:
    """Get project detection empty threshold.

    Resolution order:
    1. intent.project_detection.empty_threshold from config file
    2. Default 5

    Returns:
        Empty threshold (number of files)

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # intent:
        #   project_detection:
        #     empty_threshold: 10
    """
    config, _, _ = load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        detection_config = intent_config.get("project_detection", {})
        if isinstance(detection_config, dict):
            threshold = detection_config.get("empty_threshold")
            if threshold is not None:
                return int(threshold)

    # Default
    return 5


def get_project_detection_existing_threshold() -> int:
    """Get project detection existing threshold.

    Resolution order:
    1. intent.project_detection.existing_threshold from config file
    2. Default 50

    Returns:
        Existing threshold (number of files)

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # intent:
        #   project_detection:
        #     existing_threshold: 100
    """
    config, _, _ = load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        detection_config = intent_config.get("project_detection", {})
        if isinstance(detection_config, dict):
            threshold = detection_config.get("existing_threshold")
            if threshold is not None:
                return int(threshold)

    # Default
    return 50


def get_project_detection_enabled() -> bool:
    """Get project detection enabled flag.

    Resolution order:
    1. intent.project_detection.enabled from config file
    2. Default True

    Returns:
        True if detection is enabled

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # intent:
        #   project_detection:
        #     enabled: false
    """
    config, _, _ = load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        detection_config = intent_config.get("project_detection", {})
        if isinstance(detection_config, dict):
            enabled = detection_config.get("enabled")
            if enabled is not None:
                return bool(enabled)

    # Default
    return True


def get_retry_config() -> Any:
    """Get retry configuration for LLM invocations.

    Loads settings from the orchestration.retry section in config.
    Returns a RetryConfig object from obra.llm.retry.

    Resolution order:
    1. orchestration.retry.* from config file
    2. DEFAULT_RETRY_* constants

    Returns:
        RetryConfig object with retry settings

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # retry:
        #   max_attempts: 5
        #   base_delay: 1.0
        #   auth_max_attempts: 3
    """
    # Import here to avoid circular dependency
    from obra.llm.retry import RetryConfig

    config, _, _ = load_layered_config()
    retry_section = config.get("retry", {})

    if not isinstance(retry_section, dict):
        return RetryConfig()

    # Extract values with defaults
    max_attempts = retry_section.get("max_attempts", DEFAULT_RETRY_MAX_ATTEMPTS)
    auth_max_attempts = retry_section.get("auth_max_attempts", DEFAULT_RETRY_AUTH_MAX_ATTEMPTS)
    rate_limit_max_attempts = retry_section.get(
        "rate_limit_max_attempts", DEFAULT_RETRY_RATE_LIMIT_MAX_ATTEMPTS
    )
    # Backward-compatible key handling:
    # - canonical: retry.base_delay / retry.max_delay
    # - legacy: retry.base_delay_s / retry.max_delay_s
    base_delay = retry_section.get(
        "base_delay",
        retry_section.get("base_delay_s", DEFAULT_RETRY_BASE_DELAY),
    )
    max_delay = retry_section.get(
        "max_delay",
        retry_section.get("max_delay_s", DEFAULT_RETRY_MAX_DELAY),
    )
    backoff_multiplier = retry_section.get("backoff_multiplier", DEFAULT_RETRY_BACKOFF_MULTIPLIER)
    jitter = retry_section.get("jitter", DEFAULT_RETRY_JITTER)
    configured_patterns = retry_section.get("retryable_errors")
    if isinstance(configured_patterns, list):
        normalized_configured = [
            str(pattern).strip()
            for pattern in configured_patterns
            if str(pattern).strip()
        ]
        # Merge configured patterns with defaults so new built-in transient
        # signatures remain active even when user/default config specifies a list.
        retryable_patterns = list(dict.fromkeys([*normalized_configured, *DEFAULT_RETRY_PATTERNS]))
    else:
        retryable_patterns = list(DEFAULT_RETRY_PATTERNS)

    # Environment override (OBRA_RETRY_RATE_LIMIT_MAX_ATTEMPTS)
    env_rl = os.environ.get("OBRA_RETRY_RATE_LIMIT_MAX_ATTEMPTS")
    if env_rl:
        rate_limit_max_attempts = env_rl

    return RetryConfig(
        max_attempts=int(max_attempts),
        auth_max_attempts=int(auth_max_attempts),
        rate_limit_max_attempts=int(rate_limit_max_attempts),
        base_delay=float(base_delay),
        max_delay=float(max_delay),
        backoff_multiplier=float(backoff_multiplier),
        jitter=float(jitter),
        retryable_patterns=list(retryable_patterns),
    )


def load_llm_section(config: dict[str, Any]) -> dict[str, Any]:
    """Extract and validate llm section from client config."""
    llm_config = config.get("llm")
    if llm_config is None:
        return {}
    if not isinstance(llm_config, dict):
        msg = "Invalid llm section in ~/.obra/config-layers/01-user.yaml."
        raise ConfigurationError(
            msg,
            "Set llm to a mapping. Example:\nllm:\n  provider: anthropic\n  model: sonnet",
        )
    return llm_config


# Default intent token budget (120K tokens)
DEFAULT_INTENT_TOKEN_BUDGET = 120_000

# Quality threshold defaults
# Standard threshold for user-provided plans (0.6 = 60%)
DEFAULT_QUALITY_THRESHOLD = 0.6
# Relaxed threshold for Obra-generated plans (0.4 = 40%)
DEFAULT_GENERATED_PLAN_QUALITY_THRESHOLD = 0.4
# Quality policy mode (FEAT-QUALITY-POLICY-MODE-001)
VALID_QUALITY_POLICY_MODES = {"auto", "fast", "medium", "high"}
DEFAULT_QUALITY_POLICY_MODE = "auto"


def get_intent_token_budget() -> int:
    """Get intent extraction token budget.

    Resolution order:
    1. OBRA_INTENT_TOKEN_BUDGET environment variable
    2. intent.token_budget from config file
    3. DEFAULT_INTENT_TOKEN_BUDGET constant (120000)

    Returns:
        Token budget for intent extraction

    Example:
        # Override for larger inputs
        export OBRA_INTENT_TOKEN_BUDGET=150000

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # intent:
        #   token_budget: 150000
    """
    # Priority 1: Environment variable
    env_budget = os.environ.get("OBRA_INTENT_TOKEN_BUDGET")
    if env_budget:
        try:
            return int(env_budget)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        token_budget = intent_config.get("token_budget")
        if token_budget is not None:
            try:
                return int(token_budget)
            except (TypeError, ValueError):
                pass

    # Priority 3: Default constant
    return DEFAULT_INTENT_TOKEN_BUDGET


def get_quality_threshold() -> float:
    """Get standard quality threshold for user-provided plans.

    Resolution order:
    1. OBRA_QUALITY_THRESHOLD environment variable
    2. quality.threshold from config file
    3. DEFAULT_QUALITY_THRESHOLD constant (0.6)

    Returns:
        Quality threshold as float (0.0 to 1.0)

    Example:
        # Override via environment variable
        export OBRA_QUALITY_THRESHOLD=0.7

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # quality:
        #   threshold: 0.7
    """
    # Priority 1: Environment variable
    env_threshold = os.environ.get("OBRA_QUALITY_THRESHOLD")
    if env_threshold:
        try:
            threshold = float(env_threshold)
            if 0.0 <= threshold <= 1.0:
                return threshold
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    quality_config = config.get("quality", {})
    if isinstance(quality_config, dict):
        config_threshold: Any = quality_config.get("threshold")
        if config_threshold is not None:
            try:
                threshold_val = float(config_threshold)
                if 0.0 <= threshold_val <= 1.0:
                    return threshold_val
            except (TypeError, ValueError):
                pass

    # Priority 3: Default constant
    return DEFAULT_QUALITY_THRESHOLD


def get_generated_plan_quality_threshold() -> float:
    """Get relaxed quality threshold for Obra-generated plans.

    This threshold is used when the UserPlan was generated by Obra itself
    (source.generated=True), allowing more flexibility for machine-generated plans.

    Resolution order:
    1. OBRA_GENERATED_PLAN_QUALITY_THRESHOLD environment variable
    2. quality.generated_plan_threshold from config file
    3. DEFAULT_GENERATED_PLAN_QUALITY_THRESHOLD constant (0.4)

    Returns:
        Quality threshold as float (0.0 to 1.0)

    Example:
        # Override via environment variable
        export OBRA_GENERATED_PLAN_QUALITY_THRESHOLD=0.5

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # quality:
        #   generated_plan_threshold: 0.5
    """
    # Priority 1: Environment variable
    env_threshold = os.environ.get("OBRA_GENERATED_PLAN_QUALITY_THRESHOLD")
    if env_threshold:
        try:
            threshold = float(env_threshold)
            if 0.0 <= threshold <= 1.0:
                return threshold
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    quality_config = config.get("quality", {})
    if isinstance(quality_config, dict):
        config_threshold: Any = quality_config.get("generated_plan_threshold")
        if config_threshold is not None:
            try:
                threshold_val = float(config_threshold)
                if 0.0 <= threshold_val <= 1.0:
                    return threshold_val
            except (TypeError, ValueError):
                pass

    # Priority 3: Default constant
    return DEFAULT_GENERATED_PLAN_QUALITY_THRESHOLD


def get_quality_policy_mode() -> str:
    """Get quality policy mode override.

    Decouples quality gate behavior from model tier selection.
    When set to a forced mode (fast/medium/high), quality gates use that
    tier regardless of the execute model's tier.

    Resolution order:
    1. OBRA_QUALITY_POLICY_MODE environment variable
    2. orchestration.quality.policy_mode from config file
    3. DEFAULT_QUALITY_POLICY_MODE constant ("auto")

    Returns:
        Quality policy mode string: "auto", "fast", "medium", or "high"

    Raises:
        ConfigurationError: If the value is not in the allowed set
    """
    # Priority 1: Environment variable
    env_val = os.environ.get("OBRA_QUALITY_POLICY_MODE")
    if env_val is not None:
        normalized = env_val.strip().lower()
        if normalized not in VALID_QUALITY_POLICY_MODES:
            raise ConfigurationError(
                f"Invalid OBRA_QUALITY_POLICY_MODE='{env_val}'. "
                f"Allowed values: {sorted(VALID_QUALITY_POLICY_MODES)}"
            )
        return normalized

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        quality_config = orch_config.get("quality", {})
        if isinstance(quality_config, dict):
            mode = quality_config.get("policy_mode")
            if mode is not None:
                mode_str = str(mode).strip().lower()
                if mode_str not in VALID_QUALITY_POLICY_MODES:
                    raise ConfigurationError(
                        f"Invalid orchestration.quality.policy_mode='{mode}'. "
                        f"Allowed values: {sorted(VALID_QUALITY_POLICY_MODES)}"
                    )
                return mode_str

    # Priority 3: Default constant
    return DEFAULT_QUALITY_POLICY_MODE


# Working Directory Enforcement default (defense-in-depth)
DEFAULT_WORKING_DIR_ENFORCEMENT_ENABLED = True


def get_working_dir_enforcement_enabled() -> bool:
    """Get whether working directory enforcement is enabled.

    When enabled, Obra validates that file operations stay within the working
    directory as a defense-in-depth measure against path traversal attacks.
    This provides protection regardless of LLM CLI sandbox implementation.

    Resolution order:
    1. OBRA_WORKING_DIR_ENFORCEMENT_ENABLED environment variable
    2. orchestration.file_access.working_dir_enforcement.enabled from config
    3. DEFAULT_WORKING_DIR_ENFORCEMENT_ENABLED constant (True)

    Returns:
        True if working directory enforcement is enabled

    Example:
        # Disable via environment variable
        export OBRA_WORKING_DIR_ENFORCEMENT_ENABLED=false

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   file_access:
        #     working_dir_enforcement:
        #       enabled: false
    """
    # Priority 1: Environment variable
    env_enabled = os.environ.get("OBRA_WORKING_DIR_ENFORCEMENT_ENABLED")
    if env_enabled is not None:
        return env_enabled.lower() in ("true", "1", "yes")

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        file_access_config = orch_config.get("file_access", {})
        if isinstance(file_access_config, dict):
            enforcement_config = file_access_config.get("working_dir_enforcement", {})
            if isinstance(enforcement_config, dict):
                enabled = enforcement_config.get("enabled")
                if enabled is not None:
                    return bool(enabled)

    # Priority 3: Default constant
    return DEFAULT_WORKING_DIR_ENFORCEMENT_ENABLED


# Parallel review agent defaults (FEAT-PARALLEL-REVIEW-001)
DEFAULT_REVIEW_AGENTS_PARALLEL = True
DEFAULT_REVIEW_AGENTS_MAX_WORKERS = 4
DEFAULT_REVIEW_BLOCKING_LOW_PRIORITY_STRICT = False
DEFAULT_REVIEW_LOOP_EXIT_POLICY_ENABLED = False
DEFAULT_REVIEW_LOOP_EXIT_POLICY_MAX_NON_CRITICAL_REVIEW_CYCLES = 2
DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_THRESHOLD_MET = True
DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_REQUIRED_CHECKS_PASS = True
DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_NO_NEW_CRITICAL = True
DEFAULT_REVISION_PLAN_SHRINKAGE_WARNING_THRESHOLD = 0.5
DEFAULT_REVISION_PLAN_SHRINKAGE_BLOCK_THRESHOLD = 0.3

# Fix batching defaults (FEAT-PARALLEL-REVIEW-001)
DEFAULT_FIX_BATCHING_ENABLED = True
DEFAULT_FIX_BATCHING_MAX_SIZE = 5
DEFAULT_FIX_BATCHING_SPLIT_ON_RETRY = True
# Fix test-gap inference defaults (FEAT-REVIEW-FIX-TESTGAP-LLM-001)
DEFAULT_FIX_TEST_GAP_INFERENCE_ENABLED = True
DEFAULT_FIX_TEST_GAP_INFERENCE_CONFIDENCE_THRESHOLD = 0.6
DEFAULT_FIX_TEST_GAP_INFERENCE_MAX_CANDIDATES = 3
# Verification defaults (CHORE-LANG-AGNOSTIC-VERIFY-001)
DEFAULT_VERIFICATION_DISCOVERY_ENABLED = True
DEFAULT_VERIFICATION_MAX_RETRIES = 3
DEFAULT_VERIFICATION_FORCE_REFRESH = False
DEFAULT_FAILURE_CONTEXT_MAX_CHARS = 500
DEFAULT_VERIFICATION_AUTO_INSTALL = False

# Review complexity thresholds (CHORE-CONFIG-DEFAULTS-001-E2 Story 7)
DEFAULT_REVIEW_COMPLEXITY_SIMPLE = {
    "max_words": 20,
    "max_files": 2,
    "max_lines": 50,
}
DEFAULT_REVIEW_COMPLEXITY_MEDIUM = {
    "max_files": 5,
    "max_lines": 200,
}

# Review feedback scoring (CHORE-CONFIG-DEFAULTS-001-E2 Story 8)
DEFAULT_REVIEW_FLAG_WEIGHTS = {
    "incorrect": 0.3,
    "off_topic": 0.25,
    "incomplete": 0.2,
    "unclear": 0.15,
    "quality_issue": 0.1,
}
DEFAULT_REVIEW_RATING_ADJUSTMENTS = {
    1: -0.3,
    2: -0.15,
    3: 0.0,
    4: 0.1,
    5: 0.2,
}
DEFAULT_REVIEW_PASS_ADJUSTMENT = 0.1
DEFAULT_REVIEW_FAIL_ADJUSTMENT = -0.2
DEFAULT_REVIEW_FLAG_PENALTY_CAP = 0.5
DEFAULT_REVIEW_DEFAULT_INITIAL_QUALITY_SCORE = 0.7
DEFAULT_REVIEW_REDERIVATION_THRESHOLD = 0.4
DEFAULT_REVIEW_PASS_RATING_THRESHOLD = 3

# Intent constants (CHORE-CONFIG-DEFAULTS-001-E2 Story 7)
DEFAULT_INTENT_CONTEXT_MAX_ITEMS = 5
DEFAULT_INTENT_CONTEXT_MAX_ITEM_CHARS = 200
DEFAULT_INTENT_CONTEXT_MAX_CHARS = 1200
DEFAULT_INTENT_SLUG_MAX_LENGTH = 50
DEFAULT_INTENT_CHUNKING_CONFIG = {
    "size_tokens": 80000,
    "overlap_tokens": 2000,
    "warning_threshold": 0.8,
}
DEFAULT_INTENT_RATE_LIMIT_CONFIG = {
    "max_retries": 3,
    "backoff_delays_s": [2.0, 4.0, 8.0],
}
DEFAULT_USER_STORY_GENERATION_ENABLED = True
DEFAULT_USER_STORY_GENERATION_TIMEOUT_S = 600
DEFAULT_USER_STORY_MAX_STORIES = 10
DEFAULT_USER_STORY_MODEL_TIER = "fast"

# Derivation constants (CHORE-CONFIG-DEFAULTS-001-E2 Story 7)
DEFAULT_DERIVATION_AUTO_DECOMPOSE_CONFIG = {
    "failure_threshold": 3,
    "max_depth": 3,
}
DEFAULT_DERIVATION_BUDGET_CONFIG = {
    "decompose_threshold": 0.80,
    "warning_threshold": 0.60,
    "min_subtask_ratio": 0.10,
}
DEFAULT_DERIVATION_TASK_CONFIG = {
    "token_budget": 100000,
    "cost_budget_usd": 0.50,
}

# Hybrid polling constants (CHORE-CONFIG-DEFAULTS-001-E2 Story 7)
DEFAULT_HYBRID_POLLING_CONFIG = {
    "max_delay_s": 30.0,
    "backoff_multiplier": 2.0,
    "base_delay_s": 1.0,
}


def get_review_agents_parallel() -> bool:
    """Get whether review agents run in parallel.

    When enabled, review agents execute concurrently via ThreadPoolExecutor
    instead of sequentially. Reduces total review time from ~120s to ~30s
    for 4 agents.

    Resolution order:
    1. review.agents.parallel from config file
    2. DEFAULT_REVIEW_AGENTS_PARALLEL constant (True)

    Returns:
        True if parallel execution is enabled

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # review:
        #   agents:
        #     parallel: true
    """
    config, _, _ = load_layered_config()
    review_config = config.get("review", {})
    if isinstance(review_config, dict):
        agents_config = review_config.get("agents", {})
        if isinstance(agents_config, dict):
            parallel = agents_config.get("parallel")
            if parallel is not None:
                return bool(parallel)

    return DEFAULT_REVIEW_AGENTS_PARALLEL


def get_review_agents_max_workers() -> int:
    """Get max concurrent review agents when parallel mode is enabled.

    Controls the max_workers parameter of ThreadPoolExecutor used for
    parallel agent execution.

    Resolution order:
    1. review.agents.max_workers from config file
    2. DEFAULT_REVIEW_AGENTS_MAX_WORKERS constant (4)

    Returns:
        Maximum number of concurrent agents

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # review:
        #   agents:
        #     max_workers: 8
    """
    config, _, _ = load_layered_config()
    review_config = config.get("review", {})
    if isinstance(review_config, dict):
        agents_config = review_config.get("agents", {})
        if isinstance(agents_config, dict):
            max_workers = agents_config.get("max_workers")
            if max_workers is not None:
                try:
                    return int(max_workers)
                except (TypeError, ValueError):
                    pass

    return DEFAULT_REVIEW_AGENTS_MAX_WORKERS


def get_convergence_fresh_fix_enabled() -> bool:
    """Get review convergence fresh-fix toggle.

    Resolution order:
    1. OBRA_CONVERGENCE_FRESH_FIX_ENABLED
    2. review.convergence.fresh_fix_enabled
    3. Fail fast if missing/invalid
    """
    env_name = "OBRA_CONVERGENCE_FRESH_FIX_ENABLED"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        normalized = env_val.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
        msg = f"Invalid boolean value '{env_val}' for {env_name}"
        raise ConfigurationError(msg)

    try:
        config, _, _ = load_layered_config(include_defaults=True)
    except Exception:
        return DEFAULT_REVIEW_BLOCKING_LOW_PRIORITY_STRICT
    try:
        raw_value = config["review"]["convergence"]["fresh_fix_enabled"]
    except (KeyError, TypeError) as exc:
        msg = (
            "Convergence setting missing at "
            "review.convergence.fresh_fix_enabled"
        )
        raise ConfigurationError(msg) from exc
    if isinstance(raw_value, bool):
        return raw_value
    if isinstance(raw_value, str):
        normalized = raw_value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    if isinstance(raw_value, (int, float)):
        return bool(raw_value)
    msg = (
        "Convergence setting review.convergence.fresh_fix_enabled "
        f"is invalid: {raw_value!r}"
    )
    raise ConfigurationError(msg)


def get_convergence_stale_cycles_for_fresh_fix() -> int:
    """Get stale cycle threshold before triggering fresh-fix.

    Resolution order:
    1. OBRA_CONVERGENCE_STALE_CYCLES_FOR_FRESH_FIX
    2. review.convergence.stale_cycles_for_fresh_fix
    3. Fail fast if missing/invalid
    """
    env_name = "OBRA_CONVERGENCE_STALE_CYCLES_FOR_FRESH_FIX"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        try:
            value = int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None
        if value <= 0:
            msg = f"{env_name} must be > 0 (got {value})"
            raise ConfigurationError(msg)
        return value

    try:
        config, _, _ = load_layered_config(include_defaults=True)
    except Exception:
        return DEFAULT_REVIEW_LOOP_EXIT_POLICY_ENABLED
    try:
        value = int(config["review"]["convergence"]["stale_cycles_for_fresh_fix"])
    except (KeyError, TypeError, ValueError) as exc:
        msg = (
            "Convergence setting missing/invalid at "
            "review.convergence.stale_cycles_for_fresh_fix"
        )
        raise ConfigurationError(msg) from exc
    if value <= 0:
        msg = (
            "Convergence setting review.convergence.stale_cycles_for_fresh_fix "
            f"must be > 0 (got {value})"
        )
        raise ConfigurationError(msg)
    return value


def get_convergence_stale_cycles_for_escalate() -> int:
    """Get stale cycle threshold before convergence escalation.

    Resolution order:
    1. OBRA_CONVERGENCE_STALE_CYCLES_FOR_ESCALATE
    2. review.convergence.stale_cycles_for_escalate
    3. Fail fast if missing/invalid
    """
    env_name = "OBRA_CONVERGENCE_STALE_CYCLES_FOR_ESCALATE"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        try:
            value = int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None
        if value <= 0:
            msg = f"{env_name} must be > 0 (got {value})"
            raise ConfigurationError(msg)
        return value

    try:
        config, _, _ = load_layered_config(include_defaults=True)
    except Exception:
        return DEFAULT_REVIEW_LOOP_EXIT_POLICY_MAX_NON_CRITICAL_REVIEW_CYCLES
    try:
        value = int(config["review"]["convergence"]["stale_cycles_for_escalate"])
    except (KeyError, TypeError, ValueError) as exc:
        msg = (
            "Convergence setting missing/invalid at "
            "review.convergence.stale_cycles_for_escalate"
        )
        raise ConfigurationError(msg) from exc
    if value <= 0:
        msg = (
            "Convergence setting review.convergence.stale_cycles_for_escalate "
            f"must be > 0 (got {value})"
        )
        raise ConfigurationError(msg)
    return value


def get_convergence_max_template_failure_cycles() -> int:
    """Get max consecutive template-failure cycles before counting toward stale_cycles.

    Resolution order:
    1. OBRA_CONVERGENCE_MAX_TEMPLATE_FAILURE_CYCLES
    2. review.convergence.max_template_failure_cycles
    3. Default: 3
    """
    env_name = "OBRA_CONVERGENCE_MAX_TEMPLATE_FAILURE_CYCLES"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        try:
            value = int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None
        if value <= 0:
            msg = f"{env_name} must be > 0 (got {value})"
            raise ConfigurationError(msg)
        return value

    try:
        config, _, _ = load_layered_config(include_defaults=True)
    except Exception:
        return 3
    try:
        value = int(config["review"]["convergence"]["max_template_failure_cycles"])
    except (KeyError, TypeError, ValueError):
        return 3
    if value <= 0:
        return 3
    return value


def get_escalation_continue_iteration_reset() -> int:
    """Get iteration value to reset to when user selects 'continue fixing' after escalation.

    0 means full budget (restart from iteration 0). Higher values grant fewer
    additional cycles.

    Resolution order:
    1. OBRA_ESCALATION_CONTINUE_ITERATION_RESET
    2. refinement.escalation_continue_iteration_reset
    3. Default: 0
    """
    env_name = "OBRA_ESCALATION_CONTINUE_ITERATION_RESET"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        try:
            value = int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None
        if value < 0:
            msg = f"{env_name} must be >= 0 (got {value})"
            raise ConfigurationError(msg)
        return value

    try:
        config, _, _ = load_layered_config(include_defaults=True)
    except Exception:
        return 0
    try:
        value = int(config["refinement"]["escalation_continue_iteration_reset"])
    except (KeyError, TypeError, ValueError):
        return 0
    if value < 0:
        return 0
    return value


def get_review_blocking_low_priority_strict() -> bool:
    """Get strict low-priority blocking policy toggle for review scorecards."""
    env_name = "OBRA_REVIEW_LOW_PRIORITY_STRICT"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        normalized = env_val.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
        msg = f"Invalid boolean value '{env_val}' for {env_name}"
        raise ConfigurationError(msg)

    try:
        config, _, _ = load_layered_config(include_defaults=True)
    except Exception:
        return DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_THRESHOLD_MET
    review_config = config.get("review", {})
    if not isinstance(review_config, dict):
        return DEFAULT_REVIEW_BLOCKING_LOW_PRIORITY_STRICT
    blocking_policy = review_config.get("blocking_policy", {})
    if not isinstance(blocking_policy, dict):
        return DEFAULT_REVIEW_BLOCKING_LOW_PRIORITY_STRICT
    raw_value = blocking_policy.get(
        "low_priority_strict",
        DEFAULT_REVIEW_BLOCKING_LOW_PRIORITY_STRICT,
    )
    if isinstance(raw_value, bool):
        return raw_value
    if isinstance(raw_value, str):
        normalized = raw_value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    if isinstance(raw_value, (int, float)):
        return bool(raw_value)
    msg = "Invalid review.blocking_policy.low_priority_strict value"
    raise ConfigurationError(msg)


def get_review_loop_exit_policy_enabled() -> bool:
    """Get review.loop_exit_policy.enabled."""
    env_name = "OBRA_REVIEW_LOOP_EXIT_POLICY_ENABLED"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        normalized = env_val.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
        msg = f"Invalid boolean value '{env_val}' for {env_name}"
        raise ConfigurationError(msg)

    try:
        config, _, _ = load_layered_config(include_defaults=True)
    except Exception:
        return DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_REQUIRED_CHECKS_PASS
    review_cfg = config.get("review", {})
    if not isinstance(review_cfg, dict):
        return DEFAULT_REVIEW_LOOP_EXIT_POLICY_ENABLED
    policy_cfg = review_cfg.get("loop_exit_policy", {})
    if not isinstance(policy_cfg, dict):
        return DEFAULT_REVIEW_LOOP_EXIT_POLICY_ENABLED
    raw_value = policy_cfg.get(
        "enabled",
        DEFAULT_REVIEW_LOOP_EXIT_POLICY_ENABLED,
    )
    if isinstance(raw_value, bool):
        return raw_value
    if isinstance(raw_value, str):
        normalized = raw_value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    if isinstance(raw_value, (int, float)):
        return bool(raw_value)
    msg = "Invalid review.loop_exit_policy.enabled value"
    raise ConfigurationError(msg)


def get_review_loop_exit_policy_max_non_critical_review_cycles() -> int:
    """Get review.loop_exit_policy.max_non_critical_review_cycles."""
    env_name = "OBRA_REVIEW_LOOP_EXIT_POLICY_MAX_NON_CRITICAL_REVIEW_CYCLES"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        try:
            value = int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None
        if value <= 0:
            msg = f"{env_name} must be > 0 (got {value})"
            raise ConfigurationError(msg)
        return value

    try:
        config, _, _ = load_layered_config(include_defaults=True)
    except Exception:
        return DEFAULT_REVIEW_LOOP_EXIT_POLICY_MAX_NON_CRITICAL_REVIEW_CYCLES
    review_cfg = config.get("review", {})
    if not isinstance(review_cfg, dict):
        return DEFAULT_REVIEW_LOOP_EXIT_POLICY_MAX_NON_CRITICAL_REVIEW_CYCLES
    policy_cfg = review_cfg.get("loop_exit_policy", {})
    if not isinstance(policy_cfg, dict):
        return DEFAULT_REVIEW_LOOP_EXIT_POLICY_MAX_NON_CRITICAL_REVIEW_CYCLES
    raw_value = policy_cfg.get(
        "max_non_critical_review_cycles",
        DEFAULT_REVIEW_LOOP_EXIT_POLICY_MAX_NON_CRITICAL_REVIEW_CYCLES,
    )
    try:
        value = int(raw_value)
    except (TypeError, ValueError):
        msg = "Invalid review.loop_exit_policy.max_non_critical_review_cycles value"
        raise ConfigurationError(msg) from None
    if value <= 0:
        msg = "review.loop_exit_policy.max_non_critical_review_cycles must be > 0"
        raise ConfigurationError(msg)
    return value


def get_review_loop_exit_policy_require_threshold_met() -> bool:
    """Get review.loop_exit_policy.require_threshold_met."""
    try:
        config, _, _ = load_layered_config(include_defaults=True)
    except Exception:
        return DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_THRESHOLD_MET
    review_cfg = config.get("review", {})
    if not isinstance(review_cfg, dict):
        return DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_THRESHOLD_MET
    policy_cfg = review_cfg.get("loop_exit_policy", {})
    if not isinstance(policy_cfg, dict):
        return DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_THRESHOLD_MET
    raw_value = policy_cfg.get(
        "require_threshold_met",
        DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_THRESHOLD_MET,
    )
    if isinstance(raw_value, bool):
        return raw_value
    if isinstance(raw_value, str):
        normalized = raw_value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    if isinstance(raw_value, (int, float)):
        return bool(raw_value)
    msg = "Invalid review.loop_exit_policy.require_threshold_met value"
    raise ConfigurationError(msg)


def get_review_loop_exit_policy_require_required_checks_pass() -> bool:
    """Get review.loop_exit_policy.require_required_checks_pass."""
    try:
        config, _, _ = load_layered_config(include_defaults=True)
    except Exception:
        return DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_REQUIRED_CHECKS_PASS
    review_cfg = config.get("review", {})
    if not isinstance(review_cfg, dict):
        return DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_REQUIRED_CHECKS_PASS
    policy_cfg = review_cfg.get("loop_exit_policy", {})
    if not isinstance(policy_cfg, dict):
        return DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_REQUIRED_CHECKS_PASS
    raw_value = policy_cfg.get(
        "require_required_checks_pass",
        DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_REQUIRED_CHECKS_PASS,
    )
    if isinstance(raw_value, bool):
        return raw_value
    if isinstance(raw_value, str):
        normalized = raw_value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    if isinstance(raw_value, (int, float)):
        return bool(raw_value)
    msg = "Invalid review.loop_exit_policy.require_required_checks_pass value"
    raise ConfigurationError(msg)


def get_review_loop_exit_policy_require_no_new_critical() -> bool:
    """Get review.loop_exit_policy.require_no_new_critical."""
    try:
        config, _, _ = load_layered_config(include_defaults=True)
    except Exception:
        return DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_NO_NEW_CRITICAL
    review_cfg = config.get("review", {})
    if not isinstance(review_cfg, dict):
        return DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_NO_NEW_CRITICAL
    policy_cfg = review_cfg.get("loop_exit_policy", {})
    if not isinstance(policy_cfg, dict):
        return DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_NO_NEW_CRITICAL
    raw_value = policy_cfg.get(
        "require_no_new_critical",
        DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_NO_NEW_CRITICAL,
    )
    if isinstance(raw_value, bool):
        return raw_value
    if isinstance(raw_value, str):
        normalized = raw_value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    if isinstance(raw_value, (int, float)):
        return bool(raw_value)
    msg = "Invalid review.loop_exit_policy.require_no_new_critical value"
    raise ConfigurationError(msg)


def get_revision_plan_shrinkage_warning_threshold() -> float:
    """Get review.revision_integrity.plan_shrinkage_warning_threshold."""
    env_name = "OBRA_REVISION_PLAN_SHRINKAGE_WARNING_THRESHOLD"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        try:
            value = float(env_val)
        except ValueError:
            msg = f"Invalid float value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None
        if value < 0 or value > 1:
            msg = f"{env_name} must be between 0 and 1 (got {value})"
            raise ConfigurationError(msg)
        return value

    try:
        config, _, _ = load_layered_config(include_defaults=True)
    except Exception:
        return DEFAULT_REVISION_PLAN_SHRINKAGE_WARNING_THRESHOLD

    review_cfg = config.get("review", {})
    if not isinstance(review_cfg, dict):
        return DEFAULT_REVISION_PLAN_SHRINKAGE_WARNING_THRESHOLD
    integrity_cfg = review_cfg.get("revision_integrity", {})
    if not isinstance(integrity_cfg, dict):
        return DEFAULT_REVISION_PLAN_SHRINKAGE_WARNING_THRESHOLD

    raw_value = integrity_cfg.get(
        "plan_shrinkage_warning_threshold",
        DEFAULT_REVISION_PLAN_SHRINKAGE_WARNING_THRESHOLD,
    )
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        msg = "Invalid review.revision_integrity.plan_shrinkage_warning_threshold value"
        raise ConfigurationError(msg) from None

    if value < 0 or value > 1:
        msg = (
            "review.revision_integrity.plan_shrinkage_warning_threshold "
            f"must be between 0 and 1 (got {value})"
        )
        raise ConfigurationError(msg)
    return value


def get_revision_plan_shrinkage_block_threshold() -> float:
    """Get review.revision_integrity.plan_shrinkage_block_threshold."""
    env_name = "OBRA_REVISION_PLAN_SHRINKAGE_BLOCK_THRESHOLD"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        try:
            value = float(env_val)
        except ValueError:
            msg = f"Invalid float value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None
        if value < 0 or value > 1:
            msg = f"{env_name} must be between 0 and 1 (got {value})"
            raise ConfigurationError(msg)
        return value

    try:
        config, _, _ = load_layered_config(include_defaults=True)
    except Exception:
        return DEFAULT_REVISION_PLAN_SHRINKAGE_BLOCK_THRESHOLD

    review_cfg = config.get("review", {})
    if not isinstance(review_cfg, dict):
        return DEFAULT_REVISION_PLAN_SHRINKAGE_BLOCK_THRESHOLD
    integrity_cfg = review_cfg.get("revision_integrity", {})
    if not isinstance(integrity_cfg, dict):
        return DEFAULT_REVISION_PLAN_SHRINKAGE_BLOCK_THRESHOLD

    raw_value = integrity_cfg.get(
        "plan_shrinkage_block_threshold",
        DEFAULT_REVISION_PLAN_SHRINKAGE_BLOCK_THRESHOLD,
    )
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        msg = "Invalid review.revision_integrity.plan_shrinkage_block_threshold value"
        raise ConfigurationError(msg) from None

    warning_threshold = get_revision_plan_shrinkage_warning_threshold()
    if value < 0 or value > warning_threshold:
        msg = (
            "review.revision_integrity.plan_shrinkage_block_threshold "
            f"must be between 0 and warning threshold {warning_threshold} (got {value})"
        )
        raise ConfigurationError(msg)
    return value


def get_agent_ignore_patterns() -> list[str]:
    """Get ignore patterns for agent file scanning.

    Returns:
        List of glob patterns or directory names to skip during agent scans.
    """
    config, _, _ = load_layered_config(include_defaults=True)
    patterns = (
        config.get("features", {})
        .get("quality_automation", {})
        .get("agents", {})
        .get("ignore_patterns")
    )
    if isinstance(patterns, list):
        return [str(item) for item in patterns if item]
    return []


def get_fix_batching_enabled() -> bool:
    """Get whether fix phase batches issues by file.

    When enabled, issues in the same file are grouped and fixed in a single
    LLM call, reducing total LLM invocations and context switching.

    Resolution order:
    1. fix.batching.enabled from config file
    2. DEFAULT_FIX_BATCHING_ENABLED constant (True)

    Returns:
        True if issue batching is enabled

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # fix:
        #   batching:
        #     enabled: false  # Revert to one-at-a-time (legacy)
    """
    config, _, _ = load_layered_config()
    fix_config = config.get("fix", {})
    if isinstance(fix_config, dict):
        batching_config = fix_config.get("batching", {})
        if isinstance(batching_config, dict):
            enabled = batching_config.get("enabled")
            if enabled is not None:
                return bool(enabled)

    return DEFAULT_FIX_BATCHING_ENABLED


def get_fix_batching_max_size() -> int:
    """Get max issues per batch to avoid context overflow.

    Limits how many issues are grouped in a single LLM call. Large batches
    risk context overflow and reduced fix quality.

    Resolution order:
    1. fix.batching.max_batch_size from config file
    2. DEFAULT_FIX_BATCHING_MAX_SIZE constant (5)

    Returns:
        Maximum issues per batch

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # fix:
        #   batching:
        #     max_batch_size: 10
    """
    config, _, _ = load_layered_config()
    fix_config = config.get("fix", {})
    if isinstance(fix_config, dict):
        batching_config = fix_config.get("batching", {})
        if isinstance(batching_config, dict):
            max_size = batching_config.get("max_batch_size")
            if max_size is not None:
                try:
                    return int(max_size)
                except (TypeError, ValueError):
                    pass

    return DEFAULT_FIX_BATCHING_MAX_SIZE


def get_fix_batching_split_on_retry() -> bool:
    """Get whether batching is disabled on server-initiated fix retries.

    When enabled, fix retries (detected via non-empty fix_history) process
    issues individually instead of batching by file. This isolates failures
    so one issue's fix cannot contaminate another.

    Resolution order:
    1. fix.batching.split_on_retry from config file
    2. DEFAULT_FIX_BATCHING_SPLIT_ON_RETRY constant (True)

    Returns:
        True if batching should be disabled on retry
    """
    config, _, _ = load_layered_config()
    fix_config = config.get("fix", {})
    if isinstance(fix_config, dict):
        batching_config = fix_config.get("batching", {})
        if isinstance(batching_config, dict):
            split_on_retry = batching_config.get("split_on_retry")
            if split_on_retry is not None:
                return bool(split_on_retry)

    return DEFAULT_FIX_BATCHING_SPLIT_ON_RETRY


def get_fix_test_gap_inference_enabled() -> bool:
    """Get whether test-gap inference is enabled for missing target test files.

    Resolution order:
    1. fix.test_gap.inference.enabled from config file
    2. DEFAULT_FIX_TEST_GAP_INFERENCE_ENABLED constant (True)
    """
    config, _, _ = load_layered_config()
    fix_config = config.get("fix", {})
    if isinstance(fix_config, dict):
        test_gap_config = fix_config.get("test_gap", {})
        if isinstance(test_gap_config, dict):
            inference_config = test_gap_config.get("inference", {})
            if isinstance(inference_config, dict):
                enabled = inference_config.get("enabled")
                if enabled is not None:
                    return bool(enabled)
    return DEFAULT_FIX_TEST_GAP_INFERENCE_ENABLED


def get_fix_test_gap_inference_confidence_threshold() -> float:
    """Get minimum confidence threshold for accepting inferred test target.

    Resolution order:
    1. fix.test_gap.inference.confidence_threshold from config file
    2. DEFAULT_FIX_TEST_GAP_INFERENCE_CONFIDENCE_THRESHOLD constant (0.6)
    """
    config, _, _ = load_layered_config()
    fix_config = config.get("fix", {})
    if isinstance(fix_config, dict):
        test_gap_config = fix_config.get("test_gap", {})
        if isinstance(test_gap_config, dict):
            inference_config = test_gap_config.get("inference", {})
            if isinstance(inference_config, dict):
                threshold = inference_config.get("confidence_threshold")
                if threshold is not None:
                    try:
                        return float(threshold)
                    except (TypeError, ValueError):
                        pass
    return DEFAULT_FIX_TEST_GAP_INFERENCE_CONFIDENCE_THRESHOLD


def get_fix_test_gap_inference_max_candidates() -> int:
    """Get max candidate test files for LLM test-gap inference.

    Resolution order:
    1. fix.test_gap.inference.max_candidates from config file
    2. DEFAULT_FIX_TEST_GAP_INFERENCE_MAX_CANDIDATES constant (3)
    """
    config, _, _ = load_layered_config()
    fix_config = config.get("fix", {})
    if isinstance(fix_config, dict):
        test_gap_config = fix_config.get("test_gap", {})
        if isinstance(test_gap_config, dict):
            inference_config = test_gap_config.get("inference", {})
            if isinstance(inference_config, dict):
                max_candidates = inference_config.get("max_candidates")
                if max_candidates is not None:
                    try:
                        return int(max_candidates)
                    except (TypeError, ValueError):
                        pass
    return DEFAULT_FIX_TEST_GAP_INFERENCE_MAX_CANDIDATES


def get_verification_discovery_enabled() -> bool:
    """Get whether tooling discovery is enabled for verification.

    Resolution order:
    1. fix.verification.discovery_enabled from config file
    2. DEFAULT_VERIFICATION_DISCOVERY_ENABLED constant (True)
    """
    config, _, _ = load_layered_config()
    fix_config = config.get("fix", {})
    if isinstance(fix_config, dict):
        verification_config = fix_config.get("verification", {})
        if isinstance(verification_config, dict):
            enabled = verification_config.get("discovery_enabled")
            if enabled is not None:
                return bool(enabled)
    return DEFAULT_VERIFICATION_DISCOVERY_ENABLED


def get_verification_force_refresh() -> bool:
    """Get whether tooling discovery should force refresh the cache.

    Resolution order:
    1. fix.verification.discovery_force_refresh from config file
    2. DEFAULT_VERIFICATION_FORCE_REFRESH constant (False)
    """
    config, _, _ = load_layered_config()
    fix_config = config.get("fix", {})
    if isinstance(fix_config, dict):
        verification_config = fix_config.get("verification", {})
        if isinstance(verification_config, dict):
            force_refresh = verification_config.get("discovery_force_refresh")
            if force_refresh is not None:
                return bool(force_refresh)
    return DEFAULT_VERIFICATION_FORCE_REFRESH


def get_failure_context_max_chars() -> int:
    """Get max chars of verification error output to propagate to retry prompt.

    Controls truncation of test/lint output included in fix_details sent to
    the server, which flows into fix_history for subsequent retry attempts.

    Resolution order:
    1. fix.verification.failure_context_max_chars from config file
    2. DEFAULT_FAILURE_CONTEXT_MAX_CHARS constant (500)
    """
    config, _, _ = load_layered_config()
    fix_config = config.get("fix", {})
    if isinstance(fix_config, dict):
        verification_config = fix_config.get("verification", {})
        if isinstance(verification_config, dict):
            max_chars = verification_config.get("failure_context_max_chars")
            if max_chars is not None:
                try:
                    return int(max_chars)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_FAILURE_CONTEXT_MAX_CHARS


def get_verification_max_retries() -> int:
    """Get max verification feedback loop retries.

    Resolution order:
    1. fix.verification.max_retries from config file
    2. DEFAULT_VERIFICATION_MAX_RETRIES constant (3)
    """
    config, _, _ = load_layered_config()
    fix_config = config.get("fix", {})
    if isinstance(fix_config, dict):
        verification_config = fix_config.get("verification", {})
        if isinstance(verification_config, dict):
            max_retries = verification_config.get("max_retries")
            if max_retries is not None:
                try:
                    return int(max_retries)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_VERIFICATION_MAX_RETRIES


def get_verification_required() -> bool:
    """Get whether verification tools are required before FIX phase.

    S0.T7: When true (default), FIX handler will not proceed without
    verification tools available. When false, FIX can proceed without
    verification (degraded mode - not recommended).

    Resolution order:
    1. fix.verification.required from config file
    2. True (verification required by default)
    """
    config, _, _ = load_layered_config()
    fix_config = config.get("fix", {})
    if isinstance(fix_config, dict):
        verification_config = fix_config.get("verification", {})
        if isinstance(verification_config, dict):
            required = verification_config.get("required")
            if required is not None:
                return bool(required)
    return True  # Default: verification required


def get_verification_auto_install() -> bool:
    """Get whether verification tool auto-install is enabled.

    Resolution order:
    1. fix.verification.auto_install from config file
    2. DEFAULT_VERIFICATION_AUTO_INSTALL constant (False)
    """
    config, _, _ = load_layered_config()
    fix_config = config.get("fix", {})
    if isinstance(fix_config, dict):
        verification_config = fix_config.get("verification", {})
        if isinstance(verification_config, dict):
            auto_install = verification_config.get("auto_install")
            if auto_install is not None:
                return bool(auto_install)
    return DEFAULT_VERIFICATION_AUTO_INSTALL


def get_verification_tool_installs() -> dict[str, list[str]]:
    """Get install command lists for verification tool categories.

    Returns a mapping of category -> list of install command strings.
    """
    config, _, _ = load_layered_config()
    fix_config = config.get("fix", {})
    if not isinstance(fix_config, dict):
        return {}
    verification_config = fix_config.get("verification", {})
    if not isinstance(verification_config, dict):
        return {}
    tools = verification_config.get("tools", [])
    if not isinstance(tools, list):
        return {}
    installs: dict[str, list[str]] = {}
    for tool in tools:
        if not isinstance(tool, dict):
            continue
        category = str(tool.get("category") or tool.get("name") or "").strip()
        if not category:
            continue
        install = tool.get("install", [])
        if isinstance(install, str):
            commands = [install]
        elif isinstance(install, list):
            commands = [str(cmd).strip() for cmd in install if str(cmd).strip()]
        else:
            commands = []
        if commands:
            installs[category] = commands
    return installs


def get_verification_discovery_settings() -> dict[str, bool | int]:
    """Get verification discovery settings as a composite dict.

    Returns dict with enabled, force_refresh, and timeout_s settings.
    Supports OBRA_VERIFICATION_DISCOVERY_ENABLED env override.

    Resolution order for enabled:
    1. OBRA_VERIFICATION_DISCOVERY_ENABLED environment variable
    2. fix.verification.discovery_enabled from config file
    3. DEFAULT_VERIFICATION_DISCOVERY_ENABLED constant (True)

    Returns:
        Dict with:
        - enabled: Whether tooling discovery is enabled (default: True)
        - force_refresh: Whether to force refresh cache (default: False)
        - timeout_s: Discovery timeout in seconds (default: 120)

    Example:
        settings = get_verification_discovery_settings()
        if settings['enabled']:
            discovery = ToolingDiscovery(working_dir, llm_config)
            result = discovery.discover(force_refresh=settings['force_refresh'])
    """
    # Check env override for enabled
    env_enabled = os.environ.get("OBRA_VERIFICATION_DISCOVERY_ENABLED")
    if env_enabled is not None:
        enabled = env_enabled.lower() in ("true", "1", "yes")
    else:
        enabled = get_verification_discovery_enabled()

    return {
        "enabled": enabled,
        "force_refresh": get_verification_force_refresh(),
        "timeout_s": get_tooling_discovery_timeout(),
    }


def get_verification_tools_config(
    config: dict | None = None,
) -> dict[str, dict[str, str]]:
    """Get verification tools configuration, handling dual schema.

    Supports both legacy list format and new nested dict format:
    - Legacy: [{category: test, command: pytest}]
    - New: {test: {command: pytest}, lint: {command: ruff check}}

    Args:
        config: Optional config dict. If None, loads via load_layered_config().

    Returns:
        Dict with keys: test, lint, format, typecheck (each with command subkey).
        Empty command string means 'use detected tool'.

    Example:
        tools = get_verification_tools_config()
        test_cmd = tools['test']['command']  # 'pytest -v' or '' for detected
    """
    if config is None:
        config, _, _ = load_layered_config()

    fix_config = config.get("fix", {})
    if not isinstance(fix_config, dict):
        return _empty_tools_config()

    verification_config = fix_config.get("verification", {})
    if not isinstance(verification_config, dict):
        return _empty_tools_config()

    tools = verification_config.get("tools", [])

    # Handle legacy list format: [{category: test, command: pytest}]
    if isinstance(tools, list):
        return _convert_legacy_tools_config(tools)

    # Handle new nested dict format: {test: {command: pytest}}
    if isinstance(tools, dict):
        return _normalize_tools_config(tools)

    return _empty_tools_config()


def _empty_tools_config() -> dict[str, dict[str, str]]:
    """Return empty tools config with all categories."""
    return {
        "test": {"command": ""},
        "lint": {"command": ""},
        "format": {"command": ""},
        "typecheck": {"command": ""},
    }


def _convert_legacy_tools_config(tools: list) -> dict[str, dict[str, str]]:
    """Convert legacy list format to nested dict format."""
    result = _empty_tools_config()
    for tool in tools:
        if not isinstance(tool, dict):
            continue
        category = str(tool.get("category", "")).strip()
        command = str(tool.get("command", "")).strip()
        if category in result:
            result[category]["command"] = command
    return result


def _normalize_tools_config(tools: dict) -> dict[str, dict[str, str]]:
    """Normalize nested dict format, ensuring all categories present."""
    result = _empty_tools_config()
    for category in result:
        if category in tools and isinstance(tools[category], dict):
            cmd = tools[category].get("command", "")
            result[category]["command"] = str(cmd).strip() if cmd else ""
    return result


def get_derivation_step_timeout(step_name: str) -> int:
    """Get timeout for a specific derivation step in seconds.

    .. deprecated::
        ISSUE-DERIVE-001: This function has been superseded and will be removed.
        Post-hoc timeout checks cannot detect actual stalls - only duration
        after completion. Real stall detection is handled by MonitoringThread
        during CLI subprocess execution. The CLI subprocess timeout (7200s)
        is the authoritative timeout mechanism.

    Args:
        step_name: Name of the derivation step (structure, tasks, serialize)

    Returns:
        Timeout in seconds (600s default, but value is unused)
    """
    import warnings

    warnings.warn(
        "get_derivation_step_timeout has been superseded per ISSUE-DERIVE-001. "
        "Post-hoc timeout checks were removed; use CLI subprocess timeout instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    return 600


def get_derivation_stall_threshold() -> int:
    """Get stall warning threshold for derivation in seconds.

    Returns the number of seconds without output before a stall warning
    is emitted during derivation.

    Resolution order:
    1. derivation.pipeline.stall_warning_threshold from config file
    2. Default 30 seconds

    Returns:
        Stall warning threshold in seconds

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # derivation:
        #   pipeline:
        #     stall_warning_threshold: 45
    """
    config, _, _ = load_layered_config()
    derivation_config = config.get("derivation", {})
    if isinstance(derivation_config, dict):
        pipeline_config = derivation_config.get("pipeline", {})
        if isinstance(pipeline_config, dict):
            threshold = pipeline_config.get("stall_warning_threshold")
            if threshold is not None:
                try:
                    value = int(threshold)
                    if value > 0:
                        return value
                    logger.warning(
                        "derivation.pipeline.stall_warning_threshold must be > 0 (got %s)",
                        threshold,
                    )
                except (TypeError, ValueError):
                    pass

    return 30


def get_derivation_serialize_max_concurrent() -> int:
    """Get max concurrent workers for Step 3 per-epic JSON serialization.

    Returns the number of parallel workers to use when serializing epics
    to JSON in derivation Step 3. Higher values speed up serialization
    but may hit rate limits.

    Resolution order:
    1. OBRA_DERIVATION_SERIALIZE_MAX_CONCURRENT environment variable
    2. derivation.serialize.max_concurrent from config file
    3. KeyError if missing (default must be in default_config.yaml)

    Returns:
        Max concurrent workers (default: 4)

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # derivation:
        #   serialize:
        #     max_concurrent: 6
    """
    env_val = os.environ.get("OBRA_DERIVATION_SERIALIZE_MAX_CONCURRENT")
    if env_val:
        try:
            value = int(env_val)
            if value > 0:
                return value
            logger.warning(
                "OBRA_DERIVATION_SERIALIZE_MAX_CONCURRENT must be > 0 (got %s)",
                env_val,
            )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_DERIVATION_SERIALIZE_MAX_CONCURRENT must be an integer (got %s)",
                env_val,
            )

    config, _, _ = load_layered_config()
    derivation_config = config.get("derivation", {})
    if isinstance(derivation_config, dict):
        serialize_config = derivation_config.get("serialize", {})
        if isinstance(serialize_config, dict):
            max_concurrent = serialize_config.get("max_concurrent")
            if max_concurrent is not None:
                try:
                    value = int(max_concurrent)
                    if value > 0:
                        return value
                    logger.warning(
                        "derivation.serialize.max_concurrent must be > 0 (got %s)",
                        max_concurrent,
                    )
                except (TypeError, ValueError):
                    logger.warning(
                        "derivation.serialize.max_concurrent must be an integer (got %s)",
                        max_concurrent,
                    )

    # Default from default_config.yaml should always exist
    return 4


def get_refinement_parallel_max_workers() -> int:
    """Get max concurrent workers for parallel refinement batch dispatch.

    Resolution order:
    1. OBRA_REFINEMENT_PARALLEL_MAX_WORKERS environment variable
    2. refinement.parallel.max_workers from config file
    3. Default: 4

    Returns:
        Max concurrent workers for refinement examination/revision batches.
    """
    env_val = os.environ.get("OBRA_REFINEMENT_PARALLEL_MAX_WORKERS")
    if env_val:
        try:
            value = int(env_val)
            if value > 0:
                return value
            logger.warning(
                "OBRA_REFINEMENT_PARALLEL_MAX_WORKERS must be > 0 (got %s)",
                env_val,
            )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_REFINEMENT_PARALLEL_MAX_WORKERS must be an integer (got %s)",
                env_val,
            )

    config, _, _ = load_layered_config()
    refinement_config = config.get("refinement", {})
    if isinstance(refinement_config, dict):
        parallel_config = refinement_config.get("parallel", {})
        if isinstance(parallel_config, dict):
            max_workers = parallel_config.get("max_workers")
            if max_workers is not None:
                try:
                    value = int(max_workers)
                    if value > 0:
                        return value
                    logger.warning(
                        "refinement.parallel.max_workers must be > 0 (got %s)",
                        max_workers,
                    )
                except (TypeError, ValueError):
                    logger.warning(
                        "refinement.parallel.max_workers must be an integer (got %s)",
                        max_workers,
                    )

    return 4


def get_parallel_worker_delay_s(provider: str | None = None) -> float:
    """Get inter-worker delay for parallel LLM dispatchers.

    Staggers parallel worker starts to avoid simultaneous API calls
    that exhaust provider rate limits.

    Used by all parallel LLM workloads: derivation serialization,
    intent alignment, and review agent deployment.

    Resolution order:
    1. OBRA_PARALLEL_WORKER_DELAY_S_<PROVIDER> environment variable (if provider given)
    2. OBRA_PARALLEL_WORKER_DELAY_S environment variable
    3. orchestration.parallel.provider_overrides.<provider> (if provider given)
    4. orchestration.parallel.worker_delay_s from config file
    5. Default: 1.0

    Args:
        provider: Optional LLM provider name (e.g., "google", "anthropic").
            When provided, checks for provider-specific overrides first.

    Returns:
        Delay in seconds between worker starts (0 to disable staggering)
    """
    provider_lower = provider.lower() if provider else None

    # 1. Provider-specific env override
    if provider_lower:
        env_key = f"OBRA_PARALLEL_WORKER_DELAY_S_{provider_lower.upper()}"
        env_val = os.environ.get(env_key)
        if env_val:
            try:
                value = float(env_val)
                if value >= 0:
                    return value
                logger.warning("%s must be >= 0 (got %s)", env_key, env_val)
            except (TypeError, ValueError):
                logger.warning("%s must be a number (got %s)", env_key, env_val)

    # 2. General env override
    env_val = os.environ.get("OBRA_PARALLEL_WORKER_DELAY_S")
    if env_val:
        try:
            value = float(env_val)
            if value >= 0:
                return value
            logger.warning(
                "OBRA_PARALLEL_WORKER_DELAY_S must be >= 0 (got %s)",
                env_val,
            )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_PARALLEL_WORKER_DELAY_S must be a number (got %s)",
                env_val,
            )

    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        parallel_config = orch_config.get("parallel", {})
        if isinstance(parallel_config, dict):
            # 3. Provider-specific config override
            if provider_lower:
                overrides = parallel_config.get("provider_overrides", {})
                if isinstance(overrides, dict):
                    provider_delay = overrides.get(provider_lower)
                    if provider_delay is not None:
                        try:
                            value = float(provider_delay)
                            if value >= 0:
                                return value
                            logger.warning(
                                "orchestration.parallel.provider_overrides.%s "
                                "must be >= 0 (got %s)",
                                provider_lower,
                                provider_delay,
                            )
                        except (TypeError, ValueError):
                            logger.warning(
                                "orchestration.parallel.provider_overrides.%s "
                                "must be a number (got %s)",
                                provider_lower,
                                provider_delay,
                            )

            # 4. General config value
            delay = parallel_config.get("worker_delay_s")
            if delay is not None:
                try:
                    value = float(delay)
                    if value >= 0:
                        return value
                    logger.warning(
                        "orchestration.parallel.worker_delay_s must be >= 0 (got %s)",
                        delay,
                    )
                except (TypeError, ValueError):
                    logger.warning(
                        "orchestration.parallel.worker_delay_s must be a number (got %s)",
                        delay,
                    )

    return 1.0


def get_derivation_serialize_worker_delay_s(provider: str | None = None) -> float:
    """Get inter-worker delay for derivation serialization.

    Delegates to get_parallel_worker_delay_s() — kept for backward
    compatibility with existing config overrides.
    """
    return get_parallel_worker_delay_s(provider=provider)


def get_intent_alignment_max_concurrent() -> int:
    """Get max concurrent workers for intent story checks.

    Resolution order:
    1. OBRA_INTENT_ALIGNMENT_MAX_CONCURRENT environment variable
    2. planning.intent_alignment.max_concurrent from config file
    3. Default: 4

    Returns:
        Max concurrent workers (default: 4)
    """
    env_val = os.environ.get("OBRA_INTENT_ALIGNMENT_MAX_CONCURRENT")
    if env_val:
        try:
            value = int(env_val)
            if value > 0:
                return value
            logger.warning(
                "OBRA_INTENT_ALIGNMENT_MAX_CONCURRENT must be > 0 (got %s)",
                env_val,
            )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_INTENT_ALIGNMENT_MAX_CONCURRENT must be an integer (got %s)",
                env_val,
            )

    config, _, _ = load_layered_config()
    planning_config = config.get("planning", {})
    if isinstance(planning_config, dict):
        alignment_config = planning_config.get("intent_alignment", {})
        if isinstance(alignment_config, dict):
            max_concurrent = alignment_config.get("max_concurrent")
            if max_concurrent is not None:
                try:
                    value = int(max_concurrent)
                    if value > 0:
                        return value
                    logger.warning(
                        "planning.intent_alignment.max_concurrent must be > 0 (got %s)",
                        max_concurrent,
                    )
                except (TypeError, ValueError):
                    logger.warning(
                        "planning.intent_alignment.max_concurrent must be an integer (got %s)",
                        max_concurrent,
                    )

    return 4


def get_enrichment_review_max_concurrent() -> int:
    """Get max concurrent workers for enrichment story review.

    Resolution order:
    1. OBRA_ENRICHMENT_REVIEW_MAX_CONCURRENT environment variable
    2. planning.enrichment.stages.review.max_concurrent from config file
       (falls back to planning.enrichment.stages.revise.max_concurrent)
    3. Default: 4

    Returns:
        Max concurrent workers (default: 4)
    """
    env_val = os.environ.get("OBRA_ENRICHMENT_REVIEW_MAX_CONCURRENT")
    if env_val:
        try:
            value = int(env_val)
            if value > 0:
                return value
            logger.warning(
                "OBRA_ENRICHMENT_REVIEW_MAX_CONCURRENT must be > 0 (got %s)",
                env_val,
            )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_ENRICHMENT_REVIEW_MAX_CONCURRENT must be an integer (got %s)",
                env_val,
            )

    config, _, _ = load_layered_config()
    planning_config = config.get("planning", {})
    if isinstance(planning_config, dict):
        enrichment_config = planning_config.get("enrichment", {})
        if isinstance(enrichment_config, dict):
            stages_config = enrichment_config.get("stages", {})
            if isinstance(stages_config, dict):
                review_config = stages_config.get("review")
                if not isinstance(review_config, dict):
                    review_config = stages_config.get("revise", {})
                if isinstance(review_config, dict):
                    max_concurrent = review_config.get("max_concurrent")
                    if max_concurrent is not None:
                        try:
                            value = int(max_concurrent)
                            if value > 0:
                                return value
                            logger.warning(
                                "planning.enrichment.stages.review.max_concurrent must be > 0 (got %s)",
                                max_concurrent,
                            )
                        except (TypeError, ValueError):
                            logger.warning(
                                "planning.enrichment.stages.review.max_concurrent must be an integer (got %s)",
                                max_concurrent,
                            )

    return 4


def get_derivation_step_tier(step: int) -> str:
    """Get the orchestrator tier for a derivation step.

    Returns the tier (fast, medium, high) that should be used for the
    specified derivation step. This maps to orchestrator.tiers.X model.

    Args:
        step: Step number (1, 2, or 3)
            - Step 1: Epic derivation from objective
            - Step 2: Story/task expansion per epic
            - Step 3: NL prose to JSON serialization

    Returns:
        Tier name: 'fast', 'medium', or 'high'

    Raises:
        ValueError: If step is not 1, 2, or 3

    Example:
        tier = get_derivation_step_tier(3)  # Returns 'fast'
    """
    if step not in (1, 2, 3):
        raise ValueError(f"Invalid derivation step: {step}. Must be 1, 2, or 3.")

    step_key = f"step{step}_tier"
    env_var = f"OBRA_DERIVATION_STEP{step}_TIER"
    default_tiers = {1: "high", 2: "high", 3: "fast"}

    # Check environment variable first
    env_val = os.environ.get(env_var)
    if env_val:
        tier = env_val.lower()
        if tier in ("fast", "medium", "high"):
            return tier
        logger.warning(
            "%s must be fast, medium, or high (got %s)",
            env_var,
            env_val,
        )

    # Load from config
    config, _, _ = load_layered_config()
    derivation_config = config.get("derivation", {})
    if isinstance(derivation_config, dict):
        steps_config = derivation_config.get("steps", {})
        if isinstance(steps_config, dict):
            config_tier = steps_config.get(step_key)
            if config_tier and isinstance(config_tier, str):
                config_tier = config_tier.lower()
                if config_tier in ("fast", "medium", "high"):
                    return config_tier
                logger.warning(
                    "derivation.steps.%s must be fast, medium, or high (got %s)",
                    step_key,
                    config_tier,
                )

    return default_tiers[step]


def get_derivation_step1_tier() -> str:
    """Get orchestrator tier for Step 1 (epic derivation).

    Returns:
        Tier name: 'fast', 'medium', or 'high' (default: 'high')
    """
    return get_derivation_step_tier(1)


def get_derivation_step2_tier() -> str:
    """Get orchestrator tier for Step 2 (story/task expansion).

    Returns:
        Tier name: 'fast', 'medium', or 'high' (default: 'high')
    """
    return get_derivation_step_tier(2)


def get_derivation_step3_tier() -> str:
    """Get orchestrator tier for Step 3 (JSON serialization).

    Returns:
        Tier name: 'fast', 'medium', or 'high' (default: 'fast')
    """
    return get_derivation_step_tier(3)


def get_provider_tier_defaults(config: dict | None = None) -> dict[str, dict[str, str]]:
    """Get provider tier defaults from configuration.

    Returns the default model assignments for each provider's fast/medium/high tiers.

    Args:
        config: Optional config dict. If None, loads layered runtime config
            (defaults + user/project/session overrides).

    Returns:
        Nested dict mapping provider -> tier -> model name.
        Example: {'anthropic': {'fast': 'claude-haiku-4-5', ...}, ...}

    Raises:
        KeyError: If llm.provider_defaults section is missing from config

    Example:
        defaults = get_provider_tier_defaults()
        anthropic_fast_model = defaults['anthropic']['fast']
    """
    if config is None:
        config, _, _ = load_layered_config(include_defaults=True)

    try:
        return config["llm"]["provider_defaults"]
    except KeyError as e:
        msg = (
            f"Missing config section: llm.provider_defaults. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_role_tier_defaults(config: dict | None = None) -> dict[str, dict[str, dict[str, str]]]:
    """Get role-aware tier defaults from configuration.

    Returns model assignments for each provider/role/tier combination.
    These are role-specific selections that override provider_defaults.

    Args:
        config: Optional config dict. If None, loads layered runtime config.

    Returns:
        Nested dict: provider -> role -> tier -> model name.
        Example: {'anthropic': {'orchestrator': {'fast': 'sonnet', ...}, ...}}

    Raises:
        KeyError: If llm.role_defaults section is missing from config
    """
    if config is None:
        config, _, _ = load_layered_config(include_defaults=True)

    try:
        return config["llm"]["role_defaults"]
    except KeyError as e:
        msg = (
            f"Missing config section: llm.role_defaults. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_thinking_config(config: dict | None = None) -> dict[str, int]:
    """Get thinking/reasoning token budget configuration.

    Returns token budgets for extended thinking and reasoning operations.

    Args:
        config: Optional config dict. If None, loads layered runtime config
            (defaults + user/project/session overrides).

    Returns:
        Dict with keys: min_tokens, standard_tokens, max_tokens, default_budget.
        Example: {'min_tokens': 1024, 'standard_tokens': 8000, ...}

    Raises:
        KeyError: If llm.thinking section is missing from config

    Example:
        thinking = get_thinking_config()
        budget = thinking['default_budget']
    """
    if config is None:
        config, _, _ = load_layered_config(include_defaults=True)

    try:
        return config["llm"]["thinking"]
    except KeyError as e:
        msg = (
            f"Missing config section: llm.thinking. Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_tier_fallbacks(config: dict | None = None) -> dict[str, list[str]]:
    """Get tier fallback sequences from configuration.

    Returns fallback tier sequences for when a tier is unavailable.

    Args:
        config: Optional config dict. If None, loads layered runtime config
            (defaults + user/project/session overrides).

    Returns:
        Dict mapping tier name to list of fallback tiers in priority order.
        Example: {'fast': ['fast', 'medium', 'high'], ...}

    Raises:
        KeyError: If llm.tier_fallbacks section is missing from config

    Example:
        fallbacks = get_tier_fallbacks()
        fast_fallback_sequence = fallbacks['fast']
    """
    if config is None:
        config, _, _ = load_layered_config(include_defaults=True)

    try:
        return config["llm"]["tier_fallbacks"]
    except KeyError as e:
        msg = (
            f"Missing config section: llm.tier_fallbacks. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_xhigh_supported_models(config: dict | None = None) -> dict[str, list[str]]:
    """Get models supporting xhigh/maximum reasoning effort.

    Returns provider-specific lists of models that support extra high reasoning.

    Args:
        config: Optional config dict. If None, loads layered runtime config
            (defaults + user/project/session overrides).

    Returns:
        Dict mapping provider name to list of model names supporting xhigh.
        Example: {'openai': ['gpt-5.2', 'gpt-5.1-codex-max', 'codex'], ...}

    Raises:
        KeyError: If llm.xhigh_supported_models section is missing from config

    Example:
        xhigh_models = get_xhigh_supported_models()
        openai_xhigh = xhigh_models['openai']
    """
    if config is None:
        config, _, _ = load_layered_config(include_defaults=True)

    try:
        return config["llm"]["xhigh_supported_models"]
    except KeyError as e:
        msg = (
            f"Missing config section: llm.xhigh_supported_models. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_timeout_config(config: dict | None = None) -> dict:
    """Get full timeouts configuration section.

    Returns the complete timeouts section with all subsections.

    Args:
        config: Optional config dict. If None, loads from default_config.yaml

    Returns:
        Dict containing all timeout configurations including LLM, Ollama,
        handler, and subprocess_runner subsections.
        Example: {'auto_assessor_s': 900, 'ollama': {...}, ...}

    Raises:
        KeyError: If timeouts section is missing from config

    Example:
        timeouts = get_timeout_config()
        assessor_timeout = timeouts['auto_assessor_s']
    """
    if config is None:
        config = _load_default_schema()

    try:
        return config["timeouts"]
    except KeyError as e:
        msg = f"Missing config section: timeouts. Expected in default_config.yaml. Key error: {e}"
        raise KeyError(msg) from e


def get_llm_timeouts(config: dict | None = None) -> dict[str, int]:
    """Get LLM operation timeout configuration.

    Returns timeout values for LLM operations (quality assessment,
    story execution, subprocess calls).

    Args:
        config: Optional config dict. If None, loads from default_config.yaml

    Returns:
        Dict with keys: auto_assessor_s, auto_story_s, llm_subprocess_s.
        Example: {'auto_assessor_s': 900, 'auto_story_s': 3600, ...}

    Raises:
        KeyError: If timeouts section is missing from config

    Example:
        llm_timeouts = get_llm_timeouts()
        subprocess_timeout = llm_timeouts['llm_subprocess_s']
    """
    if config is None:
        config = _load_default_schema()

    try:
        timeouts = config["timeouts"]
        return {
            "auto_assessor_s": timeouts["auto_assessor_s"],
            "auto_story_s": timeouts["auto_story_s"],
            "llm_subprocess_s": timeouts["llm_subprocess_s"],
        }
    except KeyError as e:
        msg = (
            f"Missing config key in timeouts section. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_ollama_timeouts(config: dict | None = None) -> dict[str, int]:
    """Get Ollama-specific timeout configuration.

    Returns timeout values for Ollama LLM provider operations.

    Args:
        config: Optional config dict. If None, loads from default_config.yaml

    Returns:
        Dict with keys: default_s, status_s, status_ready_s.
        Example: {'default_s': 900, 'status_s': 5, ...}

    Raises:
        KeyError: If timeouts.ollama section is missing from config

    Example:
        ollama_timeouts = get_ollama_timeouts()
        default_timeout = ollama_timeouts['default_s']
    """
    if config is None:
        config = _load_default_schema()

    try:
        return config["timeouts"]["ollama"]
    except KeyError as e:
        msg = (
            f"Missing config section: timeouts.ollama. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_subprocess_runner_timeouts(config: dict | None = None) -> dict[str, float]:
    """Get subprocess runner timeout configuration.

    Returns timeout values for subprocess runner operations.

    Args:
        config: Optional config dict. If None, loads from default_config.yaml

    Returns:
        Dict with keys: poll_interval_s, process_wait_s, error_cleanup_s.
        Example: {'poll_interval_s': 0.5, 'process_wait_s': 5, ...}

    Raises:
        KeyError: If timeouts.subprocess_runner section is missing from config

    Example:
        runner_timeouts = get_subprocess_runner_timeouts()
        poll_interval = runner_timeouts['poll_interval_s']
    """
    if config is None:
        config = _load_default_schema()

    try:
        return config["timeouts"]["subprocess_runner"]
    except KeyError as e:
        msg = (
            f"Missing config section: timeouts.subprocess_runner. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_quality_config(config: dict | None = None) -> dict[str, Any]:
    """Get quality assessment configuration.

    Returns the full quality configuration section including thresholds and settings.

    Args:
        config: Optional config dict. If None, loads from layered config

    Returns:
        Dict with quality configuration keys (enabled, assessment_model, thresholds, etc.)

    Example:
        quality_cfg = get_quality_config()
        threshold = quality_cfg.get('generated_plan_threshold', 0.4)
    """
    if config is None:
        config, _, _ = load_layered_config()

    return config.get("quality", {})


def get_cli_update_check_config(config: dict | None = None) -> dict[str, Any]:
    """Get CLI update check configuration.

    Returns CLI configuration including update checking and notification settings.

    Args:
        config: Optional config dict. If None, loads from layered config

    Returns:
        Dict with CLI config keys (check_for_updates, update_notification_cooldown_minutes, etc.)

    Example:
        cli_cfg = get_cli_update_check_config()
        enabled = cli_cfg.get('check_for_updates', True)
        cooldown = cli_cfg.get('update_notification_cooldown_minutes', 10)
    """
    if config is None:
        config, _, _ = load_layered_config()

    return config.get("cli", {})


def get_ollama_endpoint(config: dict | None = None) -> str:
    """Get Ollama API endpoint URL.

    Returns the configured Ollama endpoint for local LLM operations.

    Args:
        config: Optional config dict. If None, loads from default_config.yaml

    Returns:
        Ollama endpoint URL (e.g., 'http://localhost:11434')

    Raises:
        KeyError: If llm.ollama.endpoint is missing from config

    Example:
        endpoint = get_ollama_endpoint()
        # Returns: 'http://localhost:11434'
    """
    if config is None:
        config = _load_default_schema()

    try:
        return config["llm"]["ollama"]["endpoint"]
    except KeyError as e:
        msg = (
            f"Missing config key: llm.ollama.endpoint. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_api_limits(config: dict | None = None) -> dict[str, int]:
    """Get API pagination limits configuration.

    Returns default pagination limits for API client operations.

    Args:
        config: Optional config dict. If None, loads from default_config.yaml

    Returns:
        Dict with keys: sessions, events, plans, user_feedback.
        Example: {'sessions': 10, 'events': 100, 'plans': 50, 'user_feedback': 20}

    Raises:
        KeyError: If api.limits section is missing from config

    Example:
        limits = get_api_limits()
        session_limit = limits['sessions']
    """
    if config is None:
        config = _load_default_schema()

    try:
        return config["api"]["limits"]
    except KeyError as e:
        msg = f"Missing config section: api.limits. Expected in default_config.yaml. Key error: {e}"
        raise KeyError(msg) from e


def get_api_connection_pool_config(
    config: dict | None = None,
) -> dict[str, int | float]:
    """Get API connection pool configuration.

    Returns HTTP connection pool settings for the API client.

    Args:
        config: Optional config dict. If None, loads from default_config.yaml

    Returns:
        Dict with keys: timeout_s, connections, maxsize, retry_total, retry_connect, retry_backoff.
        Example: {'timeout_s': 10, 'connections': 10, 'maxsize': 10, 'retry_total': 3, ...}

    Raises:
        KeyError: If api.connection_pool section is missing from config

    Example:
        pool_cfg = get_api_connection_pool_config()
        timeout = pool_cfg['timeout_s']
        connections = pool_cfg['connections']
    """
    if config is None:
        config = _load_default_schema()

    try:
        return config["api"]["connection_pool"]
    except KeyError as e:
        msg = (
            f"Missing config section: api.connection_pool. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_api_retry_delays(config: dict | None = None) -> list[int]:
    """Get API retry delays configuration.

    Returns exponential backoff delays for API retries.

    Args:
        config: Optional config dict. If None, loads from default_config.yaml

    Returns:
        List of retry delays in seconds.
        Example: [1, 2, 4]

    Raises:
        KeyError: If api.retry_delays_s is missing from config

    Example:
        delays = get_api_retry_delays()
        first_retry_delay = delays[0]  # 1 second
    """
    if config is None:
        config = _load_default_schema()

    try:
        return config["api"]["retry_delays_s"]
    except KeyError as e:
        msg = (
            f"Missing config key: api.retry_delays_s. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_api_timeouts(config: dict | None = None) -> dict[str, int]:
    """Get API operation timeouts configuration.

    Returns timeouts for specific API operations.

    Args:
        config: Optional config dict. If None, loads from default_config.yaml

    Returns:
        Dict with timeout keys in seconds.
        Example: {'feedback_submission_s': 60}

    Raises:
        KeyError: If api.timeouts section is missing from config

    Example:
        timeouts = get_api_timeouts()
        feedback_timeout = timeouts['feedback_submission_s']
    """
    if config is None:
        config = _load_default_schema()

    try:
        return config["api"]["timeouts"]
    except KeyError as e:
        msg = (
            f"Missing config section: api.timeouts. Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_auto_story_timeout_s() -> int:
    """Get auto runner story timeout in seconds.

    Resolution order:
    1. OBRA_AUTO_STORY_TIMEOUT_S environment variable
    2. orchestration.auto.story_timeout_s from config file
    3. DEFAULT_AUTO_STORY_TIMEOUT_S constant (3600s = 1 hour)

    Returns:
        Timeout in seconds

    Example:
        # Override for longer stories
        export OBRA_AUTO_STORY_TIMEOUT_S=7200

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   auto:
        #     story_timeout_s: 7200
    """
    # Priority 1: Environment variable
    env_timeout = os.environ.get("OBRA_AUTO_STORY_TIMEOUT_S")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    try:
        config_timeout = config["orchestration"]["auto"]["story_timeout_s"]
        return int(config_timeout)
    except (KeyError, TypeError):
        pass  # Fall through to default

    # Priority 3: Default constant
    return DEFAULT_AUTO_STORY_TIMEOUT_S


def _get_default_code_verify_config() -> dict[str, Any]:
    """Get bundled default config for code_verify agent."""
    defaults = _load_default_schema()
    try:
        value = defaults["features"]["quality_automation"]["agents"]["code_verify"]
        if isinstance(value, dict):
            return deepcopy(value)
    except KeyError:
        pass

    # Defensive fallback if bundled schema is missing keys
    return {
        "enabled": True,
        "llm": deepcopy(AGENT_LLM_DEFAULTS) | {"model_tier": "inherit"},
        "checks": {
            "grounding": True,
            "compliance": True,
            "dependency_graph": True,
        },
        "parallel_calls": True,
        "timeout_s": 900,
        "max_findings": 50,
        "brownfield_threshold": 50,
        "greenfield_skip_story1": True,
        "story_preflight": {
            "enabled": True,
            "sense_check": True,
            "checks": ["C1", "C2", "C3", "C4", "C7", "C8", "C9"],
            "v0_action": "escalate",
            "timeout_s": 600,
            "max_task_modifications": 10,
            "max_verification_passes": 5,
            "scope_to_modified": True,
            "track_resolved": True,
        },
    }


def get_code_verify_config() -> dict[str, Any]:
    """Get full CodeVerify agent configuration with env override support.

    Resolution order for enabled flag:
    1. OBRA_CODE_VERIFY_ENABLED environment variable
    2. features.quality_automation.agents.code_verify.enabled from layered config
    3. Bundled default config (enabled=true)
    """
    env_enabled = os.environ.get("OBRA_CODE_VERIFY_ENABLED")

    config, _, _ = load_layered_config()
    default_config = _get_default_code_verify_config()

    agent_value = (
        config.get("features", {})
        .get("quality_automation", {})
        .get("agents", {})
        .get("code_verify")
    )
    agent_config = deepcopy(agent_value) if isinstance(agent_value, dict) else default_config

    if env_enabled is not None:
        agent_config["enabled"] = env_enabled.lower() in ("true", "1", "yes", "on")

    return agent_config


def get_code_verify_timeout_s() -> int:
    """Get CodeVerify timeout in seconds with env override support."""
    env_timeout = os.environ.get("OBRA_CODE_VERIFY_TIMEOUT_S")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass

    config = get_code_verify_config()
    timeout = config.get("timeout_s")
    if timeout is not None:
        try:
            return int(timeout)
        except (TypeError, ValueError):
            pass

    return int(_get_default_code_verify_config().get("timeout_s", 900))


def get_code_verify_preflight_config() -> dict[str, Any]:
    """Get CodeVerify story pre-flight config with env override support."""
    env_enabled = os.environ.get("OBRA_CODE_VERIFY_PREFLIGHT_ENABLED")

    config = get_code_verify_config()
    preflight = config.get("story_preflight")
    preflight_config = (
        deepcopy(preflight)
        if isinstance(preflight, dict)
        else deepcopy(_get_default_code_verify_config().get("story_preflight", {}))
    )

    if env_enabled is not None:
        preflight_config["enabled"] = env_enabled.lower() in (
            "true",
            "1",
            "yes",
            "on",
        )

    return preflight_config


def get_cleanup_sleep_cap_s() -> float:
    """Get cleanup retry sleep cap in seconds.

    Resolution order:
    1. OBRA_CLEANUP_SLEEP_CAP_S environment variable
    2. orchestration.cleanup.sleep_cap_s from config file
    3. DEFAULT_CLEANUP_SLEEP_CAP_S constant (0.5s)

    Returns:
        Sleep cap in seconds (float)

    Example:
        # Override for different environments
        export OBRA_CLEANUP_SLEEP_CAP_S=1.0

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   cleanup:
        #     sleep_cap_s: 1.0
    """
    # Priority 1: Environment variable
    env_cap = os.environ.get("OBRA_CLEANUP_SLEEP_CAP_S")
    if env_cap:
        try:
            return float(env_cap)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    try:
        config_cap = config["orchestration"]["cleanup"]["sleep_cap_s"]
        return float(config_cap)
    except (KeyError, TypeError):
        pass  # Fall through to default

    # Priority 3: Default constant
    return DEFAULT_CLEANUP_SLEEP_CAP_S


def get_cleanup_investigation_config() -> dict:
    """Get cleanup investigation configuration.

    Returns dict with max_hints, tier_gap, tier_context from
    orchestration.cleanup.investigation section.

    Returns:
        Dict with investigation settings:
        - max_hints: Maximum investigation hints (default: 5)
        - tier_gap: Gap between tiers (default: 1)
        - tier_context: Context depth (default: 2)

    Example:
        config = get_cleanup_investigation_config()
        max_hints = config['max_hints']
        tier_gap = config['tier_gap']
        tier_context = config['tier_context']
    """
    config, _, _ = load_layered_config()
    try:
        investigation_config = config["orchestration"]["cleanup"]["investigation"]
        return {
            "max_hints": investigation_config["max_hints"],
            "tier_gap": investigation_config["tier_gap"],
            "tier_context": investigation_config["tier_context"],
        }
    except (KeyError, TypeError):
        # Return defaults if config section missing
        return {
            "max_hints": 5,
            "tier_gap": 1,
            "tier_context": 2,
        }


def get_auto_retry_config() -> dict:
    """Get auto runner retry configuration.

    Returns dict with retry_count, retry_delay_seconds, parallel_max_workers
    from orchestration.auto section.

    Returns:
        Dict with retry settings:
        - retry_count: Number of retries for transient failures (default: 2)
        - retry_delay_seconds: Delay between retries in seconds (default: 30)
        - parallel_max_workers: Max parallel workers (default: 4)

    Example:
        config = get_auto_retry_config()
        retry_count = config['retry_count']
        retry_delay = config['retry_delay_seconds']
        max_workers = config['parallel_max_workers']
    """
    config, _, _ = load_layered_config()
    try:
        auto_config = config["orchestration"]["auto"]
        return {
            "retry_count": auto_config["retry_count"],
            "retry_delay_seconds": auto_config["retry_delay_seconds"],
            "parallel_max_workers": auto_config["parallel_max_workers"],
        }
    except (KeyError, TypeError):
        # Return defaults if config section missing
        return {
            "retry_count": 2,
            "retry_delay_seconds": 30,
            "parallel_max_workers": 4,
        }


# ====================================================================================
# STORY S1: INTENT DETECTION & FILE TRACKING GETTERS (CHORE-CONFIG-DEFAULTS-001-E3)
# ====================================================================================


def get_intent_detection_config() -> dict:
    """Get intent detection configuration.

    Returns dict with rich_min_words, min_keyword_matches, min_detail_markers
    from intent.detection section.

    Returns:
        Dict with detection settings:
        - rich_min_words: Min words to classify as rich NL (default: 50)
        - min_keyword_matches: Min keywords for PRD/plan detection (default: 2)
        - min_detail_markers: Min detail markers for rich classification (default: 2)

    Example:
        config = get_intent_detection_config()
        rich_min = config['rich_min_words']
        keyword_min = config['min_keyword_matches']
        detail_min = config['min_detail_markers']
    """
    config, _, _ = load_layered_config()
    try:
        detection_config = config["intent"]["detection"]
        return {
            "rich_min_words": detection_config["rich_min_words"],
            "min_keyword_matches": detection_config["min_keyword_matches"],
            "min_detail_markers": detection_config["min_detail_markers"],
        }
    except (KeyError, TypeError):
        # Return defaults if config section missing
        return {
            "rich_min_words": DEFAULT_INTENT_RICH_MIN_WORDS,
            "min_keyword_matches": DEFAULT_INTENT_MIN_KEYWORD_MATCHES,
            "min_detail_markers": DEFAULT_INTENT_MIN_DETAIL_MARKERS,
        }


def get_intent_template_config() -> dict:
    """Get intent template configuration.

    Returns dict with summary_preview_length from intent.templates section.

    Returns:
        Dict with template settings:
        - summary_preview_length: Max chars for intent summary preview (default: 60)

    Example:
        config = get_intent_template_config()
        preview_len = config['summary_preview_length']
    """
    config, _, _ = load_layered_config()
    try:
        template_config = config["intent"]["templates"]
        return {
            "summary_preview_length": template_config["summary_preview_length"],
        }
    except (KeyError, TypeError):
        # Return defaults if config section missing
        return {
            "summary_preview_length": DEFAULT_INTENT_SUMMARY_PREVIEW_LENGTH,
        }


def get_file_tracking_config() -> dict:
    """Get file tracking configuration.

    Returns dict with max_file_size_bytes from file_tracking section.

    Returns:
        Dict with file tracking settings:
        - max_file_size_bytes: Max file size to track in bytes (default: 10485760 = 10MB)

    Example:
        config = get_file_tracking_config()
        max_size = config['max_file_size_bytes']
    """
    config, _, _ = load_layered_config()
    try:
        tracking_config = config["file_tracking"]
        return {
            "max_file_size_bytes": tracking_config["max_file_size_bytes"],
        }
    except (KeyError, TypeError):
        # Return defaults if config section missing
        return {
            "max_file_size_bytes": DEFAULT_MAX_FILE_SIZE_BYTES,
        }


def get_cache_monitor_config() -> dict:
    """Get cache monitor configuration.

    Returns dict with subdir_threshold_mb, top_subdirs_count from
    observability.cache_monitor section.

    Returns:
        Dict with cache monitor settings:
        - subdir_threshold_mb: Show subdirs >= this size in MB (default: 50)
        - top_subdirs_count: Number of top subdirs to display (default: 3)

    Example:
        config = get_cache_monitor_config()
        threshold = config['subdir_threshold_mb']
        top_count = config['top_subdirs_count']
    """
    config, _, _ = load_layered_config()
    try:
        monitor_config = config["observability"]["cache_monitor"]
        return {
            "subdir_threshold_mb": monitor_config["subdir_threshold_mb"],
            "top_subdirs_count": monitor_config["top_subdirs_count"],
        }
    except (KeyError, TypeError):
        # Return defaults if config section missing
        return {
            "subdir_threshold_mb": DEFAULT_CACHE_SUBDIR_THRESHOLD_MB,
            "top_subdirs_count": DEFAULT_CACHE_TOP_SUBDIRS_COUNT,
        }


# ====================================================================================
# HANDLER CONFIGURATION GETTERS (CHORE-CONFIG-DEFAULTS-001-E2)
# ====================================================================================
# Getter functions for handler configuration with typed access and fail-safe defaults.
# ====================================================================================


def get_derive_alignment_timeout() -> int:
    """Get alignment timeout for derive handler.

    Returns:
        Alignment timeout in seconds (default: 120)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        derive_config = handlers_config.get("derive", {})
        if isinstance(derive_config, dict):
            timeout = derive_config.get("alignment_timeout_s")
            if timeout is not None:
                try:
                    return int(timeout)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_DERIVE_ALIGNMENT_TIMEOUT


def get_derive_mapping_timeout() -> int:
    """Get mapping timeout for derive handler.

    Returns:
        Mapping timeout in seconds (default: 60)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        derive_config = handlers_config.get("derive", {})
        if isinstance(derive_config, dict):
            timeout = derive_config.get("mapping_timeout_s")
            if timeout is not None:
                try:
                    return int(timeout)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_DERIVE_MAPPING_TIMEOUT


def get_derive_cache_max_age() -> int:
    """Get cache max age for derive handler.

    Returns:
        Cache max age in seconds (default: 3600)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        derive_config = handlers_config.get("derive", {})
        if isinstance(derive_config, dict):
            max_age = derive_config.get("cache_max_age_s")
            if max_age is not None:
                try:
                    return int(max_age)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_DERIVE_CACHE_MAX_AGE


def get_derive_max_retries() -> int:
    """Get max retries for derive handler.

    Returns:
        Max retries (default: 3)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        derive_config = handlers_config.get("derive", {})
        if isinstance(derive_config, dict):
            retries = derive_config.get("max_retries")
            if retries is not None:
                try:
                    return int(retries)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_DERIVE_MAX_RETRIES


def get_derive_max_relevant_files() -> int:
    """Get max relevant files for derive handler.

    Returns:
        Max relevant files (default: 10)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        derive_config = handlers_config.get("derive", {})
        if isinstance(derive_config, dict):
            max_files = derive_config.get("max_relevant_files")
            if max_files is not None:
                try:
                    return int(max_files)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_DERIVE_MAX_RELEVANT_FILES


def get_derive_raw_response_log_preview() -> int:
    """Get raw response log preview length for derive handler.

    Returns:
        Character limit for log preview (default: 200)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        derive_config = handlers_config.get("derive", {})
        if isinstance(derive_config, dict):
            preview = derive_config.get("raw_response_log_preview")
            if preview is not None:
                try:
                    return int(preview)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_DERIVE_RAW_RESPONSE_LOG_PREVIEW


def get_derive_complexity_thresholds() -> dict:
    """Get complexity thresholds for derive handler.

    Returns:
        Dict with 'simple_max_steps' and 'medium_max_steps' keys
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        derive_config = handlers_config.get("derive", {})
        if isinstance(derive_config, dict):
            thresholds = derive_config.get("complexity_thresholds", {})
            if isinstance(thresholds, dict):
                simple = thresholds.get("simple_max_steps")
                medium = thresholds.get("medium_max_steps")
                if simple is not None and medium is not None:
                    try:
                        return {
                            "simple_max_steps": int(simple),
                            "medium_max_steps": int(medium),
                        }
                    except (TypeError, ValueError):
                        pass
    return {
        "simple_max_steps": DEFAULT_DERIVE_COMPLEXITY_SIMPLE_MAX_STEPS,
        "medium_max_steps": DEFAULT_DERIVE_COMPLEXITY_MEDIUM_MAX_STEPS,
    }


def get_fix_handler_doc_timeout() -> int:
    """Get documentation timeout for fix handler.

    Returns:
        Documentation timeout in seconds (default: 120)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        fix_config = handlers_config.get("fix", {})
        if isinstance(fix_config, dict):
            timeout = fix_config.get("doc_timeout_s")
            if timeout is not None:
                try:
                    return int(timeout)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_FIX_HANDLER_DOC_TIMEOUT


def get_fix_handler_max_retries() -> int:
    """Get max retries for fix handler.

    Returns:
        Max retries (default: 3)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        fix_config = handlers_config.get("fix", {})
        if isinstance(fix_config, dict):
            retries = fix_config.get("max_retries")
            if retries is not None:
                try:
                    return int(retries)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_FIX_HANDLER_MAX_RETRIES


def get_fix_handler_parallel_enabled() -> bool:
    """Get whether parallel execution is enabled for fix handler batches.

    Canonical config accessor for fix parallel enablement (ADR-072).
    Consumer: obra/hybrid/handlers/fix.py

    Resolution order:
    1. OBRA_FIX_HANDLER_PARALLEL_ENABLED environment variable
    2. handlers.fix.parallel_enabled from config file
    3. Default: False

    Returns:
        True if parallel execution is enabled, False otherwise
    """
    env_val = os.environ.get("OBRA_FIX_HANDLER_PARALLEL_ENABLED")
    if env_val is not None:
        return env_val.lower() in {"1", "true", "yes"}
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        fix_config = handlers_config.get("fix", {})
        if isinstance(fix_config, dict):
            enabled = fix_config.get("parallel_enabled")
            if enabled is not None:
                return bool(enabled)
    return DEFAULT_FIX_HANDLER_PARALLEL_ENABLED


def get_fix_handler_parallel_workers() -> int:
    """Get parallel workers for fix handler.

    Canonical config accessor for fix parallel worker count (ADR-072).
    Consumer: obra/hybrid/handlers/fix.py

    Resolution order:
    1. OBRA_FIX_HANDLER_PARALLEL_WORKERS environment variable
    2. handlers.fix.parallel_workers from config file
    3. Default: 4

    Returns:
        Number of parallel workers (default: 4)
    """
    env_val = os.environ.get("OBRA_FIX_HANDLER_PARALLEL_WORKERS")
    if env_val is not None:
        try:
            return int(env_val)
        except (TypeError, ValueError):
            pass
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        fix_config = handlers_config.get("fix", {})
        if isinstance(fix_config, dict):
            workers = fix_config.get("parallel_workers")
            if workers is not None:
                try:
                    return int(workers)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_FIX_HANDLER_PARALLEL_WORKERS


def get_fix_handler_min_file_size() -> int:
    """Get minimum file size for fix handler.

    Returns:
        Minimum file size in bytes (default: 100)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        fix_config = handlers_config.get("fix", {})
        if isinstance(fix_config, dict):
            min_size = fix_config.get("min_file_size_bytes")
            if min_size is not None:
                try:
                    return int(min_size)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_FIX_HANDLER_MIN_FILE_SIZE


def get_story0_timeout() -> int:
    """Get timeout for story0 handler.

    Returns:
        Timeout in seconds (default: 300)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        story0_config = handlers_config.get("story0", {})
        if isinstance(story0_config, dict):
            timeout = story0_config.get("timeout_s")
            if timeout is not None:
                try:
                    return int(timeout)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_STORY0_TIMEOUT


def get_story0_max_retries() -> int:
    """Get max retries for story0 handler.

    Returns:
        Max retries (default: 2)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        story0_config = handlers_config.get("story0", {})
        if isinstance(story0_config, dict):
            retries = story0_config.get("max_retries")
            if retries is not None:
                try:
                    return int(retries)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_STORY0_MAX_RETRIES


def get_story0_service_poll_interval() -> float:
    """Get service poll interval for story0 handler.

    Returns:
        Poll interval in seconds (default: 0.2)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        story0_config = handlers_config.get("story0", {})
        if isinstance(story0_config, dict):
            interval = story0_config.get("service_poll_interval_s")
            if interval is not None:
                try:
                    return float(interval)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_STORY0_SERVICE_POLL_INTERVAL


def get_story0_service_poll_max_attempts() -> int:
    """Get max polling attempts for story0 handler.

    Returns:
        Max attempts (default: 20)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        story0_config = handlers_config.get("story0", {})
        if isinstance(story0_config, dict):
            attempts = story0_config.get("service_poll_max_attempts")
            if attempts is not None:
                try:
                    return int(attempts)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_STORY0_SERVICE_POLL_MAX_ATTEMPTS


def get_story0_docker_timeout() -> int:
    """Get Docker timeout for story0 handler.

    Returns:
        Timeout in seconds (default: 600)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        story0_config = handlers_config.get("story0", {})
        if isinstance(story0_config, dict):
            timeout = story0_config.get("docker_timeout_s")
            if timeout is not None:
                try:
                    return int(timeout)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_STORY0_DOCKER_TIMEOUT


def get_story0_port_mapping(service_name: str) -> int | None:
    """Get port mapping for a service in story0 handler.

    Args:
        service_name: Name of the service (postgres, redis, mysql, mongodb)

    Returns:
        Port number if configured, None otherwise
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        story0_config = handlers_config.get("story0", {})
        if isinstance(story0_config, dict):
            mappings = story0_config.get("port_mappings", {})
            if isinstance(mappings, dict):
                port = mappings.get(service_name)
                if port is not None:
                    try:
                        return int(port)
                    except (TypeError, ValueError):
                        pass
    return DEFAULT_STORY0_PORT_MAPPINGS.get(service_name)


def get_story0_service_image(service_name: str) -> str:
    """Get Docker image for a service in story0 handler.

    Args:
        service_name: Name of the service (postgres, redis, mysql, mongodb)

    Returns:
        Docker image string, defaults to service_name if not configured
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        story0_config = handlers_config.get("story0", {})
        if isinstance(story0_config, dict):
            images = story0_config.get("service_images", {})
            if isinstance(images, dict):
                image = images.get(service_name)
                if image and isinstance(image, str):
                    return image
    return DEFAULT_STORY0_SERVICE_IMAGES.get(service_name, service_name)


def get_execute_parallel_workers() -> int:
    """Get parallel workers for execute handler.

    Returns:
        Number of parallel workers (default: 4)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        execute_config = handlers_config.get("execute", {})
        if isinstance(execute_config, dict):
            workers = execute_config.get("parallel_max_workers")
            if workers is not None:
                try:
                    return int(workers)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_EXECUTE_PARALLEL_WORKERS


def get_execute_min_file_size() -> int:
    """Get minimum file size for execute handler.

    Returns:
        Minimum file size in bytes (default: 100)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        execute_config = handlers_config.get("execute", {})
        if isinstance(execute_config, dict):
            min_size = execute_config.get("min_file_size_bytes")
            if min_size is not None:
                try:
                    return int(min_size)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_EXECUTE_MIN_FILE_SIZE


def get_execute_thread_join_timeout() -> int:
    """Get thread join timeout for execute handler.

    Returns:
        Timeout in seconds (default: 5)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        execute_config = handlers_config.get("execute", {})
        if isinstance(execute_config, dict):
            timeout = execute_config.get("thread_join_timeout_s")
            if timeout is not None:
                try:
                    return int(timeout)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_EXECUTE_THREAD_JOIN_TIMEOUT


def get_execute_subprocess_timeout() -> int:
    """Get subprocess timeout for execute handler.

    Returns:
        Timeout in seconds (default: 30)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        execute_config = handlers_config.get("execute", {})
        if isinstance(execute_config, dict):
            timeout = execute_config.get("subprocess_timeout_s")
            if timeout is not None:
                try:
                    return int(timeout)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_EXECUTE_SUBPROCESS_TIMEOUT


def get_review_handler_timeout() -> int:
    """Get timeout for review handler.

    Returns:
        Timeout in seconds (default: 300)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        review_config = handlers_config.get("review", {})
        if isinstance(review_config, dict):
            timeout = review_config.get("timeout_s")
            if timeout is not None:
                try:
                    return int(timeout)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_REVIEW_HANDLER_TIMEOUT


def get_review_handler_max_retries() -> int:
    """Get max retries for review handler.

    Returns:
        Max retries (default: 2)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        review_config = handlers_config.get("review", {})
        if isinstance(review_config, dict):
            max_retries = review_config.get("max_retries")
            if max_retries is not None:
                try:
                    return int(max_retries)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_REVIEW_HANDLER_MAX_RETRIES


def get_review_model_tier() -> str:
    """Get implementation tier for review agents.

    Returns:
        Tier name: 'fast', 'medium', or 'high' (default: 'high')
    """
    env_val = os.environ.get("OBRA_REVIEW_MODEL_TIER")
    if env_val:
        return env_val
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        review_config = handlers_config.get("review", {})
        if isinstance(review_config, dict):
            tier = review_config.get("model_tier")
            if isinstance(tier, str) and tier.strip():
                return tier.strip()
    return DEFAULT_REVIEW_MODEL_TIER


def get_escalate_truncation_chars() -> int:
    """Get description truncation character limit for escalate handler.

    Returns:
        Truncation character limit (default: 57)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        escalate_config = handlers_config.get("escalate", {})
        if isinstance(escalate_config, dict):
            chars = escalate_config.get("description_truncation_chars")
            if chars is not None:
                try:
                    return int(chars)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_ESCALATE_TRUNCATION_CHARS


def get_escalate_timeout() -> int:
    """Get timeout for escalate handler.

    Returns:
        Timeout in seconds (default: 120)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        escalate_config = handlers_config.get("escalate", {})
        if isinstance(escalate_config, dict):
            timeout = escalate_config.get("timeout_s")
            if timeout is not None:
                try:
                    return int(timeout)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_ESCALATE_TIMEOUT


def get_intent_max_retries() -> int:
    """Get max retries for intent handler.

    Returns:
        Max retries (default: 3)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        intent_config = handlers_config.get("intent", {})
        if isinstance(intent_config, dict):
            max_retries = intent_config.get("max_retries")
            if max_retries is not None:
                try:
                    return int(max_retries)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_INTENT_MAX_RETRIES


def get_intent_rate_limit_max_retries() -> int:
    """Get rate limit max retries for intent handler.

    Returns:
        Rate limit max retries (default: 3)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        intent_config = handlers_config.get("intent", {})
        if isinstance(intent_config, dict):
            max_retries = intent_config.get("rate_limit_max_retries")
            if max_retries is not None:
                try:
                    return int(max_retries)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_INTENT_RATE_LIMIT_MAX_RETRIES


def get_intent_bypass_sandbox() -> bool:
    """Get bypass sandbox flag for intent handler.

    Returns:
        Whether to bypass sandbox (default: False)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        intent_config = handlers_config.get("intent", {})
        if isinstance(intent_config, dict):
            bypass = intent_config.get("bypass_sandbox")
            if bypass is not None:
                return bool(bypass)
    return DEFAULT_INTENT_BYPASS_SANDBOX


def get_examine_max_retries() -> int:
    """Get max retries for examine handler.

    Returns:
        Max retries (default: 3)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        examine_config = handlers_config.get("examine", {})
        if isinstance(examine_config, dict):
            max_retries = examine_config.get("max_retries")
            if max_retries is not None:
                try:
                    return int(max_retries)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_EXAMINE_MAX_RETRIES


def get_examine_bypass_sandbox() -> bool:
    """Get bypass sandbox flag for examine handler.

    Returns:
        Whether to bypass sandbox (default: False)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        examine_config = handlers_config.get("examine", {})
        if isinstance(examine_config, dict):
            bypass = examine_config.get("bypass_sandbox")
            if bypass is not None:
                return bool(bypass)
    return DEFAULT_EXAMINE_BYPASS_SANDBOX


def get_revise_max_retries() -> int:
    """Get max retries for revise handler.

    Returns:
        Max retries (default: 3)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        revise_config = handlers_config.get("revise", {})
        if isinstance(revise_config, dict):
            max_retries = revise_config.get("max_retries")
            if max_retries is not None:
                try:
                    return int(max_retries)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_REVISE_MAX_RETRIES


def get_revise_bypass_sandbox() -> bool:
    """Get bypass sandbox flag for revise handler.

    Returns:
        Whether to bypass sandbox (default: False)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        revise_config = handlers_config.get("revise", {})
        if isinstance(revise_config, dict):
            bypass = revise_config.get("bypass_sandbox")
            if bypass is not None:
                return bool(bypass)
    return DEFAULT_REVISE_BYPASS_SANDBOX


def get_examine_model_tier() -> str:
    """Get orchestrator tier for examine handler.

    Returns:
        Tier name: 'fast', 'medium', or 'high' (default: 'high')
    """
    env_val = os.environ.get("OBRA_EXAMINE_MODEL_TIER")
    if env_val:
        return env_val
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        examine_config = handlers_config.get("examine", {})
        if isinstance(examine_config, dict):
            tier = examine_config.get("model_tier")
            if isinstance(tier, str) and tier.strip():
                return tier.strip()
    return DEFAULT_EXAMINE_MODEL_TIER


def get_revise_model_tier() -> str:
    """Get orchestrator tier for revise handler.

    Returns:
        Tier name: 'fast', 'medium', or 'high' (default: 'high')
    """
    env_val = os.environ.get("OBRA_REVISE_MODEL_TIER")
    if env_val:
        return env_val
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        revise_config = handlers_config.get("revise", {})
        if isinstance(revise_config, dict):
            tier = revise_config.get("model_tier")
            if isinstance(tier, str) and tier.strip():
                return tier.strip()
    return DEFAULT_REVISE_MODEL_TIER


def get_story0_model_tier() -> str:
    """Get orchestrator tier for story0 derivation.

    Returns:
        Tier name: 'fast', 'medium', or 'high' (default: 'high')
    """
    env_val = os.environ.get("OBRA_STORY0_MODEL_TIER")
    if env_val:
        return env_val
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        story0_config = handlers_config.get("story0", {})
        if isinstance(story0_config, dict):
            tier = story0_config.get("model_tier")
            if isinstance(tier, str) and tier.strip():
                return tier.strip()
    return DEFAULT_STORY0_MODEL_TIER


def get_clarification_max_iterations() -> int:
    """Get max iterations for clarification handler.

    Returns:
        Max iterations (default: 3)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        clarification_config = handlers_config.get("clarification", {})
        if isinstance(clarification_config, dict):
            max_iterations = clarification_config.get("max_iterations")
            if max_iterations is not None:
                try:
                    return int(max_iterations)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_CLARIFICATION_MAX_ITERATIONS


def get_clarification_quality_delta_threshold() -> float:
    """Get quality delta threshold for clarification handler.

    Returns:
        Quality delta threshold (default: 0.05)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        clarification_config = handlers_config.get("clarification", {})
        if isinstance(clarification_config, dict):
            threshold = clarification_config.get("quality_delta_threshold")
            if threshold is not None:
                try:
                    return float(threshold)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_CLARIFICATION_QUALITY_DELTA_THRESHOLD


def get_clarification_target_quality() -> float:
    """Get target quality for clarification handler.

    Returns:
        Target quality score 0.0-1.0 (default: 0.8)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        clarification_config = handlers_config.get("clarification", {})
        if isinstance(clarification_config, dict):
            target = clarification_config.get("target_quality")
            if target is not None:
                try:
                    return float(target)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_CLARIFICATION_TARGET_QUALITY


def get_template_edit_max_retries() -> int:
    """Get max retries for template edit pipeline.

    Returns:
        Max retries (default: 3)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        template_edit_config = handlers_config.get("template_edit", {})
        if isinstance(template_edit_config, dict):
            max_retries = template_edit_config.get("max_retries")
            if max_retries is not None:
                try:
                    return int(max_retries)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_TEMPLATE_EDIT_MAX_RETRIES


def get_fix_llm_suggestion_timeout() -> int:
    """Get LLM suggestion timeout for fix handler.

    Returns:
        Timeout in seconds (default: 300)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        fix_config = handlers_config.get("fix", {})
        if isinstance(fix_config, dict):
            timeout = fix_config.get("llm_suggestion_timeout_s")
            if timeout is not None:
                try:
                    return int(timeout)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_FIX_LLM_SUGGESTION_TIMEOUT


def get_fix_llm_test_gap_timeout() -> int:
    """Get LLM test gap timeout for fix handler.

    Returns:
        Timeout in seconds (default: 300)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        fix_config = handlers_config.get("fix", {})
        if isinstance(fix_config, dict):
            timeout = fix_config.get("llm_test_gap_timeout_s")
            if timeout is not None:
                try:
                    return int(timeout)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_FIX_LLM_TEST_GAP_TIMEOUT


def get_story0_llm_schema_timeout() -> int:
    """Get LLM schema timeout for story0 handler.

    Returns:
        Timeout in seconds (default: 300)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        story0_config = handlers_config.get("story0", {})
        if isinstance(story0_config, dict):
            timeout = story0_config.get("llm_schema_timeout_s")
            if timeout is not None:
                try:
                    return int(timeout)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_STORY0_LLM_SCHEMA_TIMEOUT


def get_story0_capability_checks() -> dict[str, dict[str, Any]]:
    """Get host capability check definitions for story0 LOCAL_CAPABILITY handling.

    3-tier resolution: OBRA_STORY0_CAPABILITY_CHECKS env var (JSON) -> config -> default.

    Returns:
        Mapping of capability name to {env_vars, indicators, always_available}.
    """
    env_val = os.environ.get("OBRA_STORY0_CAPABILITY_CHECKS")
    if env_val:
        try:
            parsed = json.loads(env_val)
            if isinstance(parsed, dict):
                return parsed
        except (json.JSONDecodeError, TypeError):
            pass
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        story0_config = handlers_config.get("story0", {})
        if isinstance(story0_config, dict):
            checks = story0_config.get("capability_checks")
            if isinstance(checks, dict) and checks:
                return checks
    return dict(DEFAULT_STORY0_CAPABILITY_CHECKS)


def get_derive_llm_timeout() -> int:
    """Get LLM timeout for derive handler.

    Returns:
        Timeout in seconds (default: 120)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        derive_config = handlers_config.get("derive", {})
        if isinstance(derive_config, dict):
            timeout = derive_config.get("llm_timeout_s")
            if timeout is not None:
                try:
                    return int(timeout)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_DERIVE_LLM_TIMEOUT


def get_plan_integrity_auto_repair_max_attempts() -> int:
    """Get max auto-repair attempts for plan integrity fixes."""
    env_val = os.environ.get("OBRA_PLAN_INTEGRITY_AUTO_REPAIR_MAX_ATTEMPTS")
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            pass

    config, _, _ = load_layered_config()
    try:
        attempts = config["planning"]["plan_integrity"]["auto_repair_max_attempts"]
        return int(attempts)
    except (KeyError, TypeError, ValueError):
        return 2


def get_plan_integrity_auto_repair_timeout_s() -> int:
    """Get timeout for each plan integrity auto-repair attempt."""
    env_val = os.environ.get("OBRA_PLAN_INTEGRITY_AUTO_REPAIR_TIMEOUT_S")
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            pass

    config, _, _ = load_layered_config()
    try:
        timeout_s = config["planning"]["plan_integrity"]["auto_repair_timeout_s"]
        return int(timeout_s)
    except (KeyError, TypeError, ValueError):
        return 120


def get_tooling_discovery_timeout() -> int:
    """Get timeout for tooling discovery.

    Returns:
        Timeout in seconds (default: 120)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        tooling_config = handlers_config.get("tooling_discovery", {})
        if isinstance(tooling_config, dict):
            timeout = tooling_config.get("timeout_s")
            if timeout is not None:
                try:
                    return int(timeout)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_TOOLING_DISCOVERY_TIMEOUT


def get_derivation_pre_filter_timeout() -> int:
    """Get pre-filter timeout for derivation.

    Returns:
        Timeout in seconds (default: 120)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        derivation_config = handlers_config.get("derivation", {})
        if isinstance(derivation_config, dict):
            timeout = derivation_config.get("pre_filter_timeout_s")
            if timeout is not None:
                try:
                    return int(timeout)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_DERIVATION_PRE_FILTER_TIMEOUT


def get_derivation_sizing_gate_timeout() -> int:
    """Get sizing gate timeout for derivation.

    Returns:
        Timeout in seconds (default: 120)
    """
    config, _, _ = load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        derivation_config = handlers_config.get("derivation", {})
        if isinstance(derivation_config, dict):
            timeout = derivation_config.get("sizing_gate_timeout_s")
            if timeout is not None:
                try:
                    return int(timeout)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_DERIVATION_SIZING_GATE_TIMEOUT


# ====================================================================================
# Monitoring Configuration Getters (CHORE-CONFIG-DEFAULTS-001-E2 Story 5)
# ====================================================================================


def get_liveness_cpu_delta_threshold() -> float:
    """Get CPU delta threshold for liveness monitoring.

    Returns:
        CPU delta threshold (default: 1.0)
    """
    config, _, _ = load_layered_config()
    monitoring_config = config.get("monitoring", {})
    if isinstance(monitoring_config, dict):
        liveness_config = monitoring_config.get("liveness", {})
        if isinstance(liveness_config, dict):
            threshold = liveness_config.get("cpu_delta_threshold")
            if threshold is not None:
                try:
                    return float(threshold)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_LIVENESS_CPU_DELTA_THRESHOLD


def get_liveness_log_silence_threshold() -> int:
    """Get log silence threshold for liveness monitoring.

    Returns:
        Log silence threshold in seconds (default: 300)
    """
    config, _, _ = load_layered_config()
    monitoring_config = config.get("monitoring", {})
    if isinstance(monitoring_config, dict):
        liveness_config = monitoring_config.get("liveness", {})
        if isinstance(liveness_config, dict):
            threshold = liveness_config.get("log_silence_threshold_s")
            if threshold is not None:
                try:
                    return int(threshold)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_LIVENESS_LOG_SILENCE_THRESHOLD


def get_liveness_file_mtime_window() -> int:
    """Get file modification time window for liveness monitoring.

    Returns:
        File mtime window in seconds (default: 300)
    """
    config, _, _ = load_layered_config()
    monitoring_config = config.get("monitoring", {})
    if isinstance(monitoring_config, dict):
        liveness_config = monitoring_config.get("liveness", {})
        if isinstance(liveness_config, dict):
            window = liveness_config.get("file_mtime_window_s")
            if window is not None:
                try:
                    return int(window)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_LIVENESS_FILE_MTIME_WINDOW


def get_liveness_db_update_window() -> int:
    """Get database update window for liveness monitoring.

    Returns:
        DB update window in seconds (default: 300)
    """
    config, _, _ = load_layered_config()
    monitoring_config = config.get("monitoring", {})
    if isinstance(monitoring_config, dict):
        liveness_config = monitoring_config.get("liveness", {})
        if isinstance(liveness_config, dict):
            window = liveness_config.get("db_update_window_s")
            if window is not None:
                try:
                    return int(window)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_LIVENESS_DB_UPDATE_WINDOW


def get_liveness_min_alive_indicators() -> int:
    """Get minimum alive indicators for liveness monitoring.

    Returns:
        Minimum alive indicators (default: 2)
    """
    config, _, _ = load_layered_config()
    monitoring_config = config.get("monitoring", {})
    if isinstance(monitoring_config, dict):
        liveness_config = monitoring_config.get("liveness", {})
        if isinstance(liveness_config, dict):
            min_indicators = liveness_config.get("min_alive_indicators")
            if min_indicators is not None:
                try:
                    return int(min_indicators)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_LIVENESS_MIN_ALIVE_INDICATORS


def get_agent_liveness_check_interval() -> int:
    """Get liveness check interval for agent monitoring.

    Returns:
        Liveness check interval in seconds (default: 180)
    """
    config, _, _ = load_layered_config()
    monitoring_config = config.get("monitoring", {})
    if isinstance(monitoring_config, dict):
        agent_config = monitoring_config.get("agent", {})
        if isinstance(agent_config, dict):
            interval = agent_config.get("liveness_check_interval_s")
            if interval is not None:
                try:
                    return int(interval)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_AGENT_LIVENESS_CHECK_INTERVAL


def get_agent_extended_timeout() -> int:
    """Get extended timeout for agent monitoring.

    Returns:
        Extended timeout in seconds (default: 3600)
    """
    config, _, _ = load_layered_config()
    monitoring_config = config.get("monitoring", {})
    if isinstance(monitoring_config, dict):
        agent_config = monitoring_config.get("agent", {})
        if isinstance(agent_config, dict):
            timeout = agent_config.get("extended_timeout_s")
            if timeout is not None:
                try:
                    return int(timeout)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_AGENT_EXTENDED_TIMEOUT


def get_agent_graceful_termination_wait() -> float:
    """Get graceful termination wait time for agent monitoring.

    Returns:
        Graceful termination wait in seconds (default: 2.0)
    """
    config, _, _ = load_layered_config()
    monitoring_config = config.get("monitoring", {})
    if isinstance(monitoring_config, dict):
        agent_config = monitoring_config.get("agent", {})
        if isinstance(agent_config, dict):
            wait = agent_config.get("graceful_termination_wait_s")
            if wait is not None:
                try:
                    return float(wait)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_AGENT_GRACEFUL_TERMINATION_WAIT


def get_agent_base_timeout() -> int:
    """Get base timeout for agent monitoring.

    Returns:
        Base timeout in seconds (default: 1200)
    """
    config, _, _ = load_layered_config()
    monitoring_config = config.get("monitoring", {})
    if isinstance(monitoring_config, dict):
        agent_config = monitoring_config.get("agent", {})
        if isinstance(agent_config, dict):
            timeout = agent_config.get("base_timeout_s")
            if timeout is not None:
                try:
                    return int(timeout)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_AGENT_BASE_TIMEOUT


def get_hang_confidence(hang_type: str) -> float:
    """Get confidence score for hang type classification.

    Args:
        hang_type: Type of hang (real_hang, io_blocking_with_file,
                  io_blocking_without, slow_progress, external_blocking, unknown)

    Returns:
        Confidence score for hang type (0.0-1.0)
    """
    config, _, _ = load_layered_config()
    monitoring_config = config.get("monitoring", {})
    if isinstance(monitoring_config, dict):
        hang_config = monitoring_config.get("hang_investigation", {})
        if isinstance(hang_config, dict):
            confidence_config = hang_config.get("confidence", {})
            if isinstance(confidence_config, dict):
                confidence = confidence_config.get(hang_type)
                if confidence is not None:
                    try:
                        return float(confidence)
                    except (TypeError, ValueError):
                        pass
    return DEFAULT_HANG_CONFIDENCE.get(hang_type, 0.30)


def get_derivation_preview_config() -> dict:
    """Get derivation preview/display limits configuration.

    Returns dict with readme_limit, raw_response_limit, raw_response_warn_limit
    from derivation.preview section.

    Returns:
        Dict with preview settings:
        - readme_limit: Character limit for README preview (default: 2000)
        - raw_response_limit: Character limit for raw response preview (default: 200)
        - raw_response_warn_limit: Warn threshold for raw response (default: 10000)

    Example:
        config = get_derivation_preview_config()
        readme_limit = config['readme_limit']
        raw_limit = config['raw_response_limit']
    """
    config, _, _ = load_layered_config()
    try:
        preview_config = config["derivation"]["preview"]
        return {
            "readme_limit": preview_config["readme_limit"],
            "raw_response_limit": preview_config["raw_response_limit"],
            "raw_response_warn_limit": preview_config["raw_response_warn_limit"],
        }
    except (KeyError, TypeError):
        # Return defaults if config section missing
        return {
            "readme_limit": DEFAULT_DERIVATION_README_LIMIT,
            "raw_response_limit": DEFAULT_DERIVATION_RAW_RESPONSE_LIMIT,
            "raw_response_warn_limit": DEFAULT_DERIVATION_RAW_RESPONSE_WARN_LIMIT,
        }


def get_derivation_epic_item_rederive_threshold() -> int:
    """Get epic item rederive threshold.

    Returns:
        Threshold count for triggering epic re-derivation (default: 30)
    """
    config, _, _ = load_layered_config()
    try:
        return int(config["derivation"]["epic_item_rederive_threshold"])
    except (KeyError, TypeError):
        return DEFAULT_DERIVATION_EPIC_ITEM_REDERIVE_THRESHOLD


def get_derivation_epic_output_token_limit() -> int:
    """Get epic output token limit for oversized detection.

    Estimated tokens (len(text) // 4) above this trigger a strict retry.
    The item count threshold is the primary guard; this is a secondary
    safety net for pathologically verbose responses.

    Returns:
        Token estimate limit (default: 12000, ~48K chars)
    """
    env_val = os.environ.get("OBRA_DERIVATION_EPIC_OUTPUT_TOKEN_LIMIT")
    if env_val:
        return int(env_val)
    config, _, _ = load_layered_config()
    try:
        return int(config["derivation"]["epic_output_token_limit"])
    except (KeyError, TypeError):
        return DEFAULT_DERIVATION_EPIC_OUTPUT_TOKEN_LIMIT


def get_derivation_story_range() -> str:
    """Get default per-epic story range for Step 2 derivation."""
    env_val = os.environ.get("OBRA_DERIVATION_STORY_RANGE")
    if env_val:
        return env_val
    config, _, _ = load_layered_config()
    try:
        return str(config["derivation"]["story_range"])
    except (KeyError, TypeError):
        return DEFAULT_DERIVATION_STORY_RANGE


def get_derivation_task_range() -> str:
    """Get default per-story task range for Step 2 derivation."""
    env_val = os.environ.get("OBRA_DERIVATION_TASK_RANGE")
    if env_val:
        return env_val
    config, _, _ = load_layered_config()
    try:
        return str(config["derivation"]["task_range"])
    except (KeyError, TypeError):
        return DEFAULT_DERIVATION_TASK_RANGE


def get_derivation_strict_story_range() -> str:
    """Get strict per-epic story range used for constrained retries."""
    env_val = os.environ.get("OBRA_DERIVATION_STRICT_STORY_RANGE")
    if env_val:
        return env_val
    config, _, _ = load_layered_config()
    try:
        return str(config["derivation"]["strict_story_range"])
    except (KeyError, TypeError):
        return DEFAULT_DERIVATION_STRICT_STORY_RANGE


def get_derivation_strict_task_range() -> str:
    """Get strict per-story task range used for constrained retries."""
    env_val = os.environ.get("OBRA_DERIVATION_STRICT_TASK_RANGE")
    if env_val:
        return env_val
    config, _, _ = load_layered_config()
    try:
        return str(config["derivation"]["strict_task_range"])
    except (KeyError, TypeError):
        return DEFAULT_DERIVATION_STRICT_TASK_RANGE


def get_derivation_max_depth_warning_threshold() -> float:
    """Get max depth warning threshold.

    Returns:
        Ratio threshold for max depth warning (default: 0.8)
    """
    config, _, _ = load_layered_config()
    try:
        return float(config["derivation"]["max_depth_warning_threshold"])
    except (KeyError, TypeError):
        return DEFAULT_DERIVATION_MAX_DEPTH_WARNING_THRESHOLD


def get_intake_config() -> dict:
    """Get intake validation configuration.

    Returns dict with min_words from intake section.

    Returns:
        Dict with intake settings:
        - min_words: Minimum word count for valid objective (default: 3)

    Example:
        config = get_intake_config()
        min_words = config['min_words']
    """
    config, _, _ = load_layered_config()
    try:
        intake_config = config["intake"]
        return {
            "min_words": intake_config["min_words"],
        }
    except (KeyError, TypeError):
        # Return default if config section missing
        return {
            "min_words": DEFAULT_INTAKE_MIN_WORDS,
        }


def get_skip_tracking_config() -> dict:
    """Get skip tracking configuration.

    Returns dict with max_logs_chars from skip_tracking section.

    Returns:
        Dict with skip tracking settings:
        - max_logs_chars: Maximum character count for log messages (default: 2000)

    Example:
        config = get_skip_tracking_config()
        max_chars = config['max_logs_chars']
    """
    config, _, _ = load_layered_config()
    try:
        skip_config = config["skip_tracking"]
        return {
            "max_logs_chars": skip_config["max_logs_chars"],
        }
    except (KeyError, TypeError):
        # Return default if config section missing
        return {
            "max_logs_chars": DEFAULT_SKIP_TRACKING_MAX_LOGS_CHARS,
        }


def get_tooling_discovery_config() -> dict:
    """Get tooling discovery configuration.

    Returns dict with max_manifest_bytes from tooling_discovery section.

    Returns:
        Dict with tooling discovery settings:
        - max_manifest_bytes: Maximum size for manifest files (default: 2048)

    Example:
        config = get_tooling_discovery_config()
        max_bytes = config['max_manifest_bytes']
    """
    config, _, _ = load_layered_config()
    try:
        tooling_config = config["tooling_discovery"]
        return {
            "max_manifest_bytes": tooling_config["max_manifest_bytes"],
        }
    except (KeyError, TypeError):
        # Return default if config section missing
        return {
            "max_manifest_bytes": DEFAULT_TOOLING_DISCOVERY_MAX_MANIFEST_BYTES,
        }


def get_process_registry_config() -> dict:
    """Get process registry configuration.

    Returns dict with terminate_timeout_s from process_registry section.

    Returns:
        Dict with process registry settings:
        - terminate_timeout_s: Timeout for process termination (default: 3.0)

    Example:
        config = get_process_registry_config()
        timeout = config['terminate_timeout_s']
    """
    config, _, _ = load_layered_config()
    try:
        registry_config = config["process_registry"]
        return {
            "terminate_timeout_s": registry_config["terminate_timeout_s"],
        }
    except (KeyError, TypeError):
        # Return default if config section missing
        return {
            "terminate_timeout_s": DEFAULT_PROCESS_REGISTRY_TERMINATE_TIMEOUT_S,
        }


def get_execution_quality_config() -> dict:
    """Get execution quality thresholds configuration.

    Returns dict with default_threshold, generated_plan_threshold from
    execution.quality section.

    Returns:
        Dict with quality settings:
        - default_threshold: Default quality score threshold (default: 0.6)
        - generated_plan_threshold: Lower threshold for generated plans (default: 0.4)

    Example:
        config = get_execution_quality_config()
        default_threshold = config['default_threshold']
        generated_threshold = config['generated_plan_threshold']
    """
    config, _, _ = load_layered_config()
    try:
        quality_config = config["execution"]["quality"]
        return {
            "default_threshold": quality_config["default_threshold"],
            "generated_plan_threshold": quality_config["generated_plan_threshold"],
        }
    except (KeyError, TypeError):
        # Return defaults if config section missing
        return {
            "default_threshold": DEFAULT_EXECUTION_QUALITY_DEFAULT_THRESHOLD,
            "generated_plan_threshold": DEFAULT_EXECUTION_QUALITY_GENERATED_PLAN_THRESHOLD,
        }


def get_intent_thresholds_config() -> dict:
    """Get intent validation thresholds configuration.

    Returns dict with detection_empty, detection_existing, interrogative_ratio,
    token_warning from intent.thresholds section.

    Returns:
        Dict with intent threshold settings:
        - detection_empty: Min word count for empty project intent (default: 5)
        - detection_existing: Min word count for existing project intent (default: 50)
        - interrogative_ratio: Threshold for interrogative ratio (default: 0.5)
        - token_warning: Token usage warning threshold (default: 0.8)

    Example:
        config = get_intent_thresholds_config()
        empty_threshold = config['detection_empty']
        existing_threshold = config['detection_existing']
    """
    config, _, _ = load_layered_config()
    try:
        thresholds_config = config["intent"]["thresholds"]
        return {
            "detection_empty": thresholds_config["detection_empty"],
            "detection_existing": thresholds_config["detection_existing"],
            "interrogative_ratio": thresholds_config["interrogative_ratio"],
            "token_warning": thresholds_config["token_warning"],
        }
    except (KeyError, TypeError):
        # Return defaults if config section missing
        return {
            "detection_empty": DEFAULT_INTENT_DETECTION_EMPTY,
            "detection_existing": DEFAULT_INTENT_DETECTION_EXISTING,
            "interrogative_ratio": DEFAULT_INTENT_INTERROGATIVE_RATIO,
            "token_warning": DEFAULT_INTENT_TOKEN_WARNING,
        }


# ====================================================================================
# LOG VIEWER, CLI, AUTH & VALIDATION CONFIG GETTERS (CHORE-CONFIG-DEFAULTS-001-E3 S3)
# ====================================================================================


def get_log_viewer_config() -> dict:
    """Get log viewer server configuration.

    Returns dict with host, port, tail_limit, max_events, max_snapshot_bytes,
    index_rotation_files, stream_sleep_s, graceful_shutdown_delay_s from
    observability.log_viewer section.

    Returns:
        Dict with log viewer settings:
        - host: Server host (default: '127.0.0.1')
        - port: Server port (default: 8844)
        - tail_limit: Recent log entries to show (default: 200)
        - max_events: Max events in memory (default: 500)
        - max_snapshot_bytes: Max snapshot size (default: 2097152 / 2MB)
        - index_rotation_files: Rotated files to scan for indexing (default: 3)
        - stream_sleep_s: Stream update interval (default: 0.2)
        - graceful_shutdown_delay_s: Shutdown delay (default: 1.0)

    Example:
        config = get_log_viewer_config()
        port = config['port']
        host = config['host']
    """
    config, _, _ = load_layered_config()
    try:
        log_viewer_config = config["observability"]["log_viewer"]
        return {
            "host": log_viewer_config["host"],
            "port": log_viewer_config["port"],
            "tail_limit": log_viewer_config["tail_limit"],
            "max_events": log_viewer_config["max_events"],
            "max_snapshot_bytes": log_viewer_config["max_snapshot_bytes"],
            "index_rotation_files": log_viewer_config["index_rotation_files"],
            "stream_sleep_s": log_viewer_config["stream_sleep_s"],
            "graceful_shutdown_delay_s": log_viewer_config["graceful_shutdown_delay_s"],
        }
    except (KeyError, TypeError):
        # Return defaults if config section missing
        return {
            "host": DEFAULT_LOG_VIEWER_HOST,
            "port": DEFAULT_LOG_VIEWER_PORT,
            "tail_limit": DEFAULT_LOG_VIEWER_TAIL_LIMIT,
            "max_events": DEFAULT_LOG_VIEWER_MAX_EVENTS,
            "max_snapshot_bytes": DEFAULT_LOG_VIEWER_MAX_SNAPSHOT_BYTES,
            "index_rotation_files": DEFAULT_LOG_VIEWER_INDEX_ROTATION_FILES,
            "stream_sleep_s": DEFAULT_LOG_VIEWER_STREAM_SLEEP_S,
            "graceful_shutdown_delay_s": DEFAULT_LOG_VIEWER_GRACEFUL_SHUTDOWN_DELAY_S,
        }


def get_gateway_config() -> dict:
    """Get gateway server configuration.

    Returns dict with host, port, max_sessions, auth_token, escalation_timeout_s,
    enable_cors, cors_origins from gateway section.

    Returns:
        Dict with gateway settings:
        - host: Server bind address (default: '127.0.0.1')
        - port: Server port (default: 18790)
        - max_sessions: Max concurrent sessions (default: 5)
        - auth_token: Bearer token or None for auto-generate (default: None)
        - escalation_timeout_s: Escalation decision timeout (default: 300.0)
        - enable_cors: Enable CORS middleware (default: False)
        - cors_origins: Allowed CORS origins (default: ['*'])

    Example:
        config = get_gateway_config()
        port = config['port']
        host = config['host']
    """
    config, _, _ = load_layered_config()
    try:
        gw = config["gateway"]
        return {
            "host": gw["host"],
            "port": gw["port"],
            "max_sessions": gw["max_sessions"],
            "auth_token": gw.get("auth_token"),
            "escalation_timeout_s": float(gw["escalation_timeout_s"]),
            "enable_cors": gw["enable_cors"],
            "cors_origins": gw["cors_origins"],
        }
    except (KeyError, TypeError):
        return {
            "host": DEFAULT_GATEWAY_HOST,
            "port": DEFAULT_GATEWAY_PORT,
            "max_sessions": DEFAULT_GATEWAY_MAX_SESSIONS,
            "auth_token": None,
            "escalation_timeout_s": DEFAULT_GATEWAY_ESCALATION_TIMEOUT_S,
            "enable_cors": DEFAULT_GATEWAY_ENABLE_CORS,
            "cors_origins": DEFAULT_GATEWAY_CORS_ORIGINS,
        }


def get_production_logger_config() -> dict:
    """Get production logger rotation configuration.

    Returns dict with max_size_bytes, backup_count from
    observability.production_logger section.

    Returns:
        Dict with logger rotation settings:
        - max_size_bytes: Max log file size before rotation (default: 104857600 / 100MB)
        - backup_count: Number of rotated log files to keep (default: 10)

    Example:
        config = get_production_logger_config()
        max_size = config['max_size_bytes']
        backup_count = config['backup_count']
    """
    config, _, _ = load_layered_config()
    try:
        logger_config = config["observability"]["production_logger"]
        return {
            "max_size_bytes": logger_config["max_size_bytes"],
            "backup_count": logger_config["backup_count"],
        }
    except (KeyError, TypeError):
        # Return defaults if config section missing
        return {
            "max_size_bytes": DEFAULT_PRODUCTION_LOGGER_MAX_SIZE_BYTES,
            "backup_count": DEFAULT_PRODUCTION_LOGGER_BACKUP_COUNT,
        }


def get_cli_retry_config() -> dict:
    """Get CLI retry policy configuration.

    Returns dict with max_attempts, initial_delay_s, backoff_multiplier from
    cli.retry section.

    Returns:
        Dict with CLI retry settings:
        - max_attempts: Maximum retry attempts (default: 3)
        - initial_delay_s: Initial retry delay in seconds (default: 2)
        - backoff_multiplier: Exponential backoff multiplier (default: 2)

    Example:
        config = get_cli_retry_config()
        max_attempts = config['max_attempts']
        initial_delay = config['initial_delay_s']
    """
    config, _, _ = load_layered_config()
    try:
        retry_config = config["cli"]["retry"]
        return {
            "max_attempts": retry_config["max_attempts"],
            "initial_delay_s": retry_config["initial_delay_s"],
            "backoff_multiplier": retry_config["backoff_multiplier"],
        }
    except (KeyError, TypeError):
        # Return defaults if config section missing
        return {
            "max_attempts": DEFAULT_CLI_RETRY_MAX_ATTEMPTS,
            "initial_delay_s": DEFAULT_CLI_RETRY_INITIAL_DELAY_S,
            "backoff_multiplier": DEFAULT_CLI_RETRY_BACKOFF_MULTIPLIER,
        }


def get_cli_cache_config() -> dict:
    """Get CLI cache monitoring thresholds.

    Returns dict with warn_threshold_mb, critical_threshold_mb from cli.cache section.

    Returns:
        Dict with cache threshold settings:
        - warn_threshold_mb: Warn when cache exceeds this size (default: 500 MB)
        - critical_threshold_mb: Critical threshold for cache size (default: 1000 MB)

    Example:
        config = get_cli_cache_config()
        warn_threshold = config['warn_threshold_mb']
        critical_threshold = config['critical_threshold_mb']
    """
    config, _, _ = load_layered_config()
    try:
        cache_config = config["cli"]["cache"]
        return {
            "warn_threshold_mb": cache_config["warn_threshold_mb"],
            "critical_threshold_mb": cache_config["critical_threshold_mb"],
        }
    except (KeyError, TypeError):
        # Return defaults if config section missing
        return {
            "warn_threshold_mb": DEFAULT_CLI_CACHE_WARN_THRESHOLD_MB,
            "critical_threshold_mb": DEFAULT_CLI_CACHE_CRITICAL_THRESHOLD_MB,
        }


def get_oauth_config() -> dict:
    """Get OAuth flow configuration.

    Returns dict with poll_interval_s, thread_join_timeout_s from auth.oauth section.

    Returns:
        Dict with OAuth settings:
        - poll_interval_s: Polling interval for OAuth status checks (default: 0.1)
        - thread_join_timeout_s: Timeout for thread cleanup (default: 1.0)

    Example:
        config = get_oauth_config()
        poll_interval = config['poll_interval_s']
        join_timeout = config['thread_join_timeout_s']
    """
    config, _, _ = load_layered_config()
    try:
        oauth_config = config["auth"]["oauth"]
        return {
            "poll_interval_s": oauth_config["poll_interval_s"],
            "thread_join_timeout_s": oauth_config["thread_join_timeout_s"],
        }
    except (KeyError, TypeError):
        # Return defaults if config section missing
        return {
            "poll_interval_s": DEFAULT_OAUTH_POLL_INTERVAL_S,
            "thread_join_timeout_s": DEFAULT_OAUTH_THREAD_JOIN_TIMEOUT_S,
        }


def get_plan_item_validation_config() -> dict:
    """Get plan item validation limits.

    Returns dict with max_acceptance_criteria, max_description_words, max_tasks,
    max_loc, max_files_per_task from validation.plan_item section.

    Returns:
        Dict with plan item validation settings:
        - max_acceptance_criteria: Max acceptance criteria per item (default: 5)
        - max_description_words: Max word count for descriptions (default: 150)
        - max_tasks: Max tasks per story (default: 8)
        - max_loc: Max lines of code per task (default: 400)
        - max_files_per_task: Max files modified per task (default: 5)

    Example:
        config = get_plan_item_validation_config()
        max_tasks = config['max_tasks']
        max_loc = config['max_loc']
    """
    config, _, _ = load_layered_config()
    try:
        validation_config = config["validation"]["plan_item"]
        return {
            "max_acceptance_criteria": validation_config["max_acceptance_criteria"],
            "max_description_words": validation_config["max_description_words"],
            "max_tasks": validation_config["max_tasks"],
            "max_loc": validation_config["max_loc"],
            "max_files_per_task": validation_config["max_files_per_task"],
        }
    except (KeyError, TypeError):
        # Return defaults if config section missing
        return {
            "max_acceptance_criteria": DEFAULT_PLAN_ITEM_MAX_ACCEPTANCE_CRITERIA,
            "max_description_words": DEFAULT_PLAN_ITEM_MAX_DESCRIPTION_WORDS,
            "max_tasks": DEFAULT_PLAN_ITEM_MAX_TASKS,
            "max_loc": DEFAULT_PLAN_ITEM_MAX_LOC,
            "max_files_per_task": DEFAULT_PLAN_ITEM_MAX_FILES_PER_TASK,
        }


def get_api_client_config() -> dict:
    """Get API client configuration.

    Returns dict with default_timeout_s from api.client section.

    Returns:
        Dict with API client settings:
        - default_timeout_s: Default timeout for API calls (default: 120, minimum per Rule 22)

    Example:
        config = get_api_client_config()
        timeout = config['default_timeout_s']
    """
    config, _, _ = load_layered_config()
    try:
        client_config = config["api"]["client"]
        return {
            "default_timeout_s": client_config["default_timeout_s"],
        }
    except (KeyError, TypeError):
        # Return default if config section missing
        return {
            "default_timeout_s": DEFAULT_API_CLIENT_DEFAULT_TIMEOUT_S,
        }


def get_config_explorer_config() -> dict:
    """Get config explorer UI configuration.

    Returns dict with notification_timeout_s from config_explorer section.

    Returns:
        Dict with config explorer settings:
        - notification_timeout_s: Notification display timeout (default: 10)

    Example:
        config = get_config_explorer_config()
        timeout = config['notification_timeout_s']
    """
    config, _, _ = load_layered_config()
    try:
        explorer_config = config["config_explorer"]
        return {
            "notification_timeout_s": explorer_config["notification_timeout_s"],
        }
    except (KeyError, TypeError):
        # Return default if config section missing
        return {
            "notification_timeout_s": DEFAULT_CONFIG_EXPLORER_NOTIFICATION_TIMEOUT_S,
        }


# ===================================
# Workflow & Work Type Configuration (CHORE-CONFIG-DEFAULTS-001-E2 Story 6)
# ===================================


def get_workflow_pattern_weight() -> float:
    """Get pattern weight for workflow resolution.

    Returns:
        Pattern weight (default: 0.6)
    """
    config, _, _ = load_layered_config()
    workflow_config = config.get("workflow", {})
    if isinstance(workflow_config, dict):
        weighting_config = workflow_config.get("pattern_weighting", {})
        if isinstance(weighting_config, dict):
            weight = weighting_config.get("pattern_weight")
            if weight is not None:
                try:
                    return float(weight)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_WORKFLOW_PATTERN_WEIGHT


def get_workflow_keyword_weight() -> float:
    """Get keyword weight for workflow resolution.

    Returns:
        Keyword weight (default: 0.4)
    """
    config, _, _ = load_layered_config()
    workflow_config = config.get("workflow", {})
    if isinstance(workflow_config, dict):
        weighting_config = workflow_config.get("pattern_weighting", {})
        if isinstance(weighting_config, dict):
            weight = weighting_config.get("keyword_weight")
            if weight is not None:
                try:
                    return float(weight)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_WORKFLOW_KEYWORD_WEIGHT


def get_triage_high_confidence() -> float:
    """Get high confidence threshold for feedback triage.

    Returns:
        High confidence threshold (default: 0.9)
    """
    config, _, _ = load_layered_config()
    workflow_config = config.get("workflow", {})
    if isinstance(workflow_config, dict):
        triage_config = workflow_config.get("triage", {})
        if isinstance(triage_config, dict):
            threshold = triage_config.get("high_confidence")
            if threshold is not None:
                try:
                    return float(threshold)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_TRIAGE_HIGH_CONFIDENCE


def get_triage_medium_confidence() -> float:
    """Get medium confidence threshold for feedback triage.

    Returns:
        Medium confidence threshold (default: 0.5)
    """
    config, _, _ = load_layered_config()
    workflow_config = config.get("workflow", {})
    if isinstance(workflow_config, dict):
        triage_config = workflow_config.get("triage", {})
        if isinstance(triage_config, dict):
            threshold = triage_config.get("medium_confidence")
            if threshold is not None:
                try:
                    return float(threshold)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_TRIAGE_MEDIUM_CONFIDENCE


def get_triage_low_confidence() -> float:
    """Get low confidence threshold for feedback triage.

    Returns:
        Low confidence threshold (default: 0.3)
    """
    config, _, _ = load_layered_config()
    workflow_config = config.get("workflow", {})
    if isinstance(workflow_config, dict):
        triage_config = workflow_config.get("triage", {})
        if isinstance(triage_config, dict):
            threshold = triage_config.get("low_confidence")
            if threshold is not None:
                try:
                    return float(threshold)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_TRIAGE_LOW_CONFIDENCE


def get_priority_order() -> dict:
    """Get priority ordering for issue severity levels.

    Returns:
        Dict mapping P0-P3 to numeric order (default: {"P0": 0, "P1": 1, "P2": 2, "P3": 3})
    """
    config, _, _ = load_layered_config()
    workflow_config = config.get("workflow", {})
    if isinstance(workflow_config, dict):
        order = workflow_config.get("priority_order")
        if isinstance(order, dict):
            return order
    return DEFAULT_PRIORITY_ORDER.copy()


def get_work_type_keyword_weight() -> float:
    """Get keyword weight for work type detection.

    Returns:
        Keyword weight (default: 0.25)
    """
    config, _, _ = load_layered_config()
    work_type_config = config.get("work_type", {})
    if isinstance(work_type_config, dict):
        weights = work_type_config.get("weights", {})
        if isinstance(weights, dict):
            weight = weights.get("keywords")
            if weight is not None:
                try:
                    return float(weight)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_WORK_TYPE_KEYWORD_WEIGHT


def get_work_type_phrase_weight() -> float:
    """Get phrase weight for work type detection.

    Returns:
        Phrase weight (default: 0.35)
    """
    config, _, _ = load_layered_config()
    work_type_config = config.get("work_type", {})
    if isinstance(work_type_config, dict):
        weights = work_type_config.get("weights", {})
        if isinstance(weights, dict):
            weight = weights.get("phrases")
            if weight is not None:
                try:
                    return float(weight)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_WORK_TYPE_PHRASE_WEIGHT


def get_work_type_regex_weight() -> float:
    """Get regex weight for work type detection.

    Returns:
        Regex weight (default: 0.15)
    """
    config, _, _ = load_layered_config()
    work_type_config = config.get("work_type", {})
    if isinstance(work_type_config, dict):
        weights = work_type_config.get("weights", {})
        if isinstance(weights, dict):
            weight = weights.get("regex_patterns")
            if weight is not None:
                try:
                    return float(weight)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_WORK_TYPE_REGEX_WEIGHT


def get_work_type_base_score() -> float:
    """Get base score for work type classification.

    Returns:
        Base score (default: 0.5)
    """
    config, _, _ = load_layered_config()
    work_type_config = config.get("work_type", {})
    if isinstance(work_type_config, dict):
        scoring = work_type_config.get("scoring", {})
        if isinstance(scoring, dict):
            score = scoring.get("base_score")
            if score is not None:
                try:
                    return float(score)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_WORK_TYPE_BASE_SCORE


def get_work_type_max_bonus() -> float:
    """Get max bonus score for work type classification.

    Returns:
        Max bonus (default: 0.5)
    """
    config, _, _ = load_layered_config()
    work_type_config = config.get("work_type", {})
    if isinstance(work_type_config, dict):
        scoring = work_type_config.get("scoring", {})
        if isinstance(scoring, dict):
            bonus = scoring.get("max_bonus")
            if bonus is not None:
                try:
                    return float(bonus)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_WORK_TYPE_MAX_BONUS


# Review complexity getters (CHORE-CONFIG-DEFAULTS-001-E2 Story 7)


def get_review_complexity_simple() -> dict:
    """Get simple review complexity thresholds.

    Returns:
        Dict with max_words, max_files, max_lines keys
    """
    config, _, _ = load_layered_config()
    review_config = config.get("review", {})
    if isinstance(review_config, dict):
        complexity_config = review_config.get("complexity", {})
        if isinstance(complexity_config, dict):
            simple_config = complexity_config.get("simple", {})
            if isinstance(simple_config, dict):
                return {
                    "max_words": simple_config.get(
                        "max_words", DEFAULT_REVIEW_COMPLEXITY_SIMPLE["max_words"]
                    ),
                    "max_files": simple_config.get(
                        "max_files", DEFAULT_REVIEW_COMPLEXITY_SIMPLE["max_files"]
                    ),
                    "max_lines": simple_config.get(
                        "max_lines", DEFAULT_REVIEW_COMPLEXITY_SIMPLE["max_lines"]
                    ),
                }
    return DEFAULT_REVIEW_COMPLEXITY_SIMPLE.copy()


def get_review_complexity_medium() -> dict:
    """Get medium review complexity thresholds.

    Returns:
        Dict with max_files, max_lines keys
    """
    config, _, _ = load_layered_config()
    review_config = config.get("review", {})
    if isinstance(review_config, dict):
        complexity_config = review_config.get("complexity", {})
        if isinstance(complexity_config, dict):
            medium_config = complexity_config.get("medium", {})
            if isinstance(medium_config, dict):
                return {
                    "max_files": medium_config.get(
                        "max_files", DEFAULT_REVIEW_COMPLEXITY_MEDIUM["max_files"]
                    ),
                    "max_lines": medium_config.get(
                        "max_lines", DEFAULT_REVIEW_COMPLEXITY_MEDIUM["max_lines"]
                    ),
                }
    return DEFAULT_REVIEW_COMPLEXITY_MEDIUM.copy()


# Review feedback scoring getters (CHORE-CONFIG-DEFAULTS-001-E2 Story 8)


def get_review_flag_weights() -> dict:
    """Get severity weights for review flags.

    Returns:
        Dict with flag names (incorrect, off_topic, incomplete, unclear, quality_issue)
        mapped to severity weights (0.0-1.0). Higher weights indicate more severe
        impact on quality score.

        Default: {
            "incorrect": 0.3,
            "off_topic": 0.25,
            "incomplete": 0.2,
            "unclear": 0.15,
            "quality_issue": 0.1
        }
    """
    config, _, _ = load_layered_config()
    review_config = config.get("review", {})
    if isinstance(review_config, dict):
        feedback_config = review_config.get("feedback", {})
        if isinstance(feedback_config, dict):
            flag_weights = feedback_config.get("flag_weights", {})
            if isinstance(flag_weights, dict):
                return {
                    "incorrect": flag_weights.get(
                        "incorrect", DEFAULT_REVIEW_FLAG_WEIGHTS["incorrect"]
                    ),
                    "off_topic": flag_weights.get(
                        "off_topic", DEFAULT_REVIEW_FLAG_WEIGHTS["off_topic"]
                    ),
                    "incomplete": flag_weights.get(
                        "incomplete", DEFAULT_REVIEW_FLAG_WEIGHTS["incomplete"]
                    ),
                    "unclear": flag_weights.get("unclear", DEFAULT_REVIEW_FLAG_WEIGHTS["unclear"]),
                    "quality_issue": flag_weights.get(
                        "quality_issue", DEFAULT_REVIEW_FLAG_WEIGHTS["quality_issue"]
                    ),
                }
    return DEFAULT_REVIEW_FLAG_WEIGHTS.copy()


def get_review_rating_adjustments() -> dict:
    """Get quality score adjustments based on numeric rating (1-5).

    Returns:
        Dict mapping rating (1-5) to quality score adjustment.
        Positive values indicate quality improvement, negative indicate degradation.

        Default: {
            1: -0.3,    # Poor
            2: -0.15,   # Below expectations
            3: 0.0,     # Acceptable/neutral
            4: 0.1,     # Good
            5: 0.2      # Excellent
        }
    """
    config, _, _ = load_layered_config()
    review_config = config.get("review", {})
    if isinstance(review_config, dict):
        feedback_config = review_config.get("feedback", {})
        if isinstance(feedback_config, dict):
            rating_adjustments = feedback_config.get("rating_adjustments", {})
            if isinstance(rating_adjustments, dict):
                result = {}
                for rating in [1, 2, 3, 4, 5]:
                    value = rating_adjustments.get(rating)
                    if value is not None:
                        try:
                            result[rating] = float(value)
                        except (TypeError, ValueError):
                            result[rating] = DEFAULT_REVIEW_RATING_ADJUSTMENTS[rating]
                    else:
                        result[rating] = DEFAULT_REVIEW_RATING_ADJUSTMENTS[rating]
                return result
    return DEFAULT_REVIEW_RATING_ADJUSTMENTS.copy()


def get_review_feedback_config() -> dict:
    """Get review feedback configuration (scalar values).

    Returns:
        Dict with scalar configuration values for review feedback scoring:
        - pass_adjustment (float): Quality adjustment when review passes
        - fail_adjustment (float): Quality adjustment when review fails
        - flag_penalty_cap (float): Maximum total penalty from flags
        - default_initial_quality_score (float): Initial quality score for new work (0.0-1.0)
        - rederivation_threshold (float): Quality threshold for triggering rederivation (0.0-1.0)
        - pass_rating_threshold (int): Minimum rating considered passing (1-5 scale)

        Default: {
            "pass_adjustment": 0.1,
            "fail_adjustment": -0.2,
            "flag_penalty_cap": 0.5,
            "default_initial_quality_score": 0.7,
            "rederivation_threshold": 0.4,
            "pass_rating_threshold": 3
        }
    """
    config, _, _ = load_layered_config()
    review_config = config.get("review", {})
    if isinstance(review_config, dict):
        feedback_config = review_config.get("feedback", {})
        if isinstance(feedback_config, dict):
            result = {}
            # Float values
            for key in [
                "pass_adjustment",
                "fail_adjustment",
                "flag_penalty_cap",
                "default_initial_quality_score",
                "rederivation_threshold",
            ]:
                value = feedback_config.get(key)
                if value is not None:
                    try:
                        result[key] = float(value)
                    except (TypeError, ValueError):
                        result[key] = globals()[f"DEFAULT_REVIEW_{key.upper()}"]
                else:
                    result[key] = globals()[f"DEFAULT_REVIEW_{key.upper()}"]

            # Int value
            value = feedback_config.get("pass_rating_threshold")
            if value is not None:
                try:
                    result["pass_rating_threshold"] = int(value)
                except (TypeError, ValueError):
                    result["pass_rating_threshold"] = DEFAULT_REVIEW_PASS_RATING_THRESHOLD
            else:
                result["pass_rating_threshold"] = DEFAULT_REVIEW_PASS_RATING_THRESHOLD

            return result

    # Return all defaults
    return {
        "pass_adjustment": DEFAULT_REVIEW_PASS_ADJUSTMENT,
        "fail_adjustment": DEFAULT_REVIEW_FAIL_ADJUSTMENT,
        "flag_penalty_cap": DEFAULT_REVIEW_FLAG_PENALTY_CAP,
        "default_initial_quality_score": DEFAULT_REVIEW_DEFAULT_INITIAL_QUALITY_SCORE,
        "rederivation_threshold": DEFAULT_REVIEW_REDERIVATION_THRESHOLD,
        "pass_rating_threshold": DEFAULT_REVIEW_PASS_RATING_THRESHOLD,
    }


# Intent getters (CHORE-CONFIG-DEFAULTS-001-E2 Story 7)


def get_intent_context_max_items() -> int:
    """Get max items for intent context."""
    config, _, _ = load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        context_config = intent_config.get("context", {})
        if isinstance(context_config, dict):
            max_items = context_config.get("max_items")
            if max_items is not None:
                try:
                    return int(max_items)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_INTENT_CONTEXT_MAX_ITEMS


def get_intent_context_max_item_chars() -> int:
    """Get max characters per intent context item."""
    config, _, _ = load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        context_config = intent_config.get("context", {})
        if isinstance(context_config, dict):
            max_chars = context_config.get("max_item_chars")
            if max_chars is not None:
                try:
                    return int(max_chars)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_INTENT_CONTEXT_MAX_ITEM_CHARS


def get_intent_context_max_chars() -> int:
    """Get max total characters for intent context."""
    config, _, _ = load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        context_config = intent_config.get("context", {})
        if isinstance(context_config, dict):
            max_chars = context_config.get("max_chars")
            if max_chars is not None:
                try:
                    return int(max_chars)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_INTENT_CONTEXT_MAX_CHARS


def get_intent_slug_max_length() -> int:
    """Get max length for generated slugs."""
    config, _, _ = load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        slug_max = intent_config.get("slug_max_length")
        if slug_max is not None:
            try:
                return int(slug_max)
            except (TypeError, ValueError):
                pass
    return DEFAULT_INTENT_SLUG_MAX_LENGTH


def get_intent_chunking_config() -> dict:
    """Get intent chunking configuration.

    Returns:
        Dict with size_tokens, overlap_tokens, warning_threshold keys
    """
    config, _, _ = load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        chunking_config = intent_config.get("chunking", {})
        if isinstance(chunking_config, dict):
            return {
                "size_tokens": chunking_config.get(
                    "size_tokens", DEFAULT_INTENT_CHUNKING_CONFIG["size_tokens"]
                ),
                "overlap_tokens": chunking_config.get(
                    "overlap_tokens", DEFAULT_INTENT_CHUNKING_CONFIG["overlap_tokens"]
                ),
                "warning_threshold": chunking_config.get(
                    "warning_threshold",
                    DEFAULT_INTENT_CHUNKING_CONFIG["warning_threshold"],
                ),
            }
    return DEFAULT_INTENT_CHUNKING_CONFIG.copy()


def get_intent_rate_limit_config() -> dict:
    """Get intent rate limit configuration.

    Returns:
        Dict with max_retries, backoff_delays_s (list) keys
    """
    config, _, _ = load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        rate_limit_config = intent_config.get("rate_limit", {})
        if isinstance(rate_limit_config, dict):
            return {
                "max_retries": rate_limit_config.get(
                    "max_retries", DEFAULT_INTENT_RATE_LIMIT_CONFIG["max_retries"]
                ),
                "backoff_delays_s": rate_limit_config.get(
                    "backoff_delays_s",
                    DEFAULT_INTENT_RATE_LIMIT_CONFIG["backoff_delays_s"],
                ),
            }
    return DEFAULT_INTENT_RATE_LIMIT_CONFIG.copy()


def get_user_story_generation_enabled() -> bool:
    """Get user story generation enabled flag with env override.

    Resolution order:
    1. OBRA_USER_STORY_GENERATION_ENABLED environment variable
    2. intent.user_stories.enabled from config file
    3. Default: True
    """
    import os

    env_val = os.environ.get("OBRA_USER_STORY_GENERATION_ENABLED")
    if env_val is not None:
        return env_val.lower() in ("true", "1", "yes")

    config, _, _ = load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        user_stories_config = intent_config.get("user_stories", {})
        if isinstance(user_stories_config, dict):
            enabled = user_stories_config.get("enabled")
            if enabled is not None:
                return bool(enabled)
    return DEFAULT_USER_STORY_GENERATION_ENABLED


def get_user_story_generation_timeout_s() -> int:
    """Get user story generation timeout with env override.

    Resolution order:
    1. OBRA_USER_STORY_GENERATION_TIMEOUT_S environment variable
    2. intent.user_stories.timeout_s from config file
    3. Default: 600
    """
    import os

    env_val = os.environ.get("OBRA_USER_STORY_GENERATION_TIMEOUT_S")
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            pass

    config, _, _ = load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        user_stories_config = intent_config.get("user_stories", {})
        if isinstance(user_stories_config, dict):
            timeout = user_stories_config.get("timeout_s")
            if timeout is not None:
                try:
                    return int(timeout)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_USER_STORY_GENERATION_TIMEOUT_S


def get_user_story_max_stories() -> int:
    """Get max user stories with env override.

    Resolution order:
    1. OBRA_USER_STORY_MAX_STORIES environment variable
    2. intent.user_stories.max_stories from config file
    3. Default: 10
    """
    import os

    env_val = os.environ.get("OBRA_USER_STORY_MAX_STORIES")
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            pass

    config, _, _ = load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        user_stories_config = intent_config.get("user_stories", {})
        if isinstance(user_stories_config, dict):
            max_stories = user_stories_config.get("max_stories")
            if max_stories is not None:
                try:
                    return int(max_stories)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_USER_STORY_MAX_STORIES


def get_user_story_model_tier() -> str:
    """Get user story model tier with env override.

    Resolution order:
    1. OBRA_USER_STORY_MODEL_TIER environment variable
    2. intent.user_stories.model_tier from config file
    3. Default: 'fast'
    """
    import os

    env_val = os.environ.get("OBRA_USER_STORY_MODEL_TIER")
    if env_val:
        return str(env_val)

    config, _, _ = load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        user_stories_config = intent_config.get("user_stories", {})
        if isinstance(user_stories_config, dict):
            model_tier = user_stories_config.get("model_tier")
            if model_tier is not None:
                return str(model_tier)
    return DEFAULT_USER_STORY_MODEL_TIER


# Derivation getters (CHORE-CONFIG-DEFAULTS-001-E2 Story 7)


def get_derivation_auto_decompose_config() -> dict:
    """Get derivation auto-decompose configuration.

    Returns:
        Dict with failure_threshold, max_depth keys
    """
    config, _, _ = load_layered_config()
    derivation_config = config.get("derivation", {})
    if isinstance(derivation_config, dict):
        auto_decompose_config = derivation_config.get("auto_decompose", {})
        if isinstance(auto_decompose_config, dict):
            return {
                "failure_threshold": auto_decompose_config.get(
                    "failure_threshold",
                    DEFAULT_DERIVATION_AUTO_DECOMPOSE_CONFIG["failure_threshold"],
                ),
                "max_depth": auto_decompose_config.get(
                    "max_depth", DEFAULT_DERIVATION_AUTO_DECOMPOSE_CONFIG["max_depth"]
                ),
            }
    return DEFAULT_DERIVATION_AUTO_DECOMPOSE_CONFIG.copy()


def get_derivation_budget_config() -> dict:
    """Get derivation budget configuration.

    Returns:
        Dict with decompose_threshold, warning_threshold, min_subtask_ratio keys
    """
    config, _, _ = load_layered_config()
    derivation_config = config.get("derivation", {})
    if isinstance(derivation_config, dict):
        budget_config = derivation_config.get("budget", {})
        if isinstance(budget_config, dict):
            return {
                "decompose_threshold": budget_config.get(
                    "decompose_threshold",
                    DEFAULT_DERIVATION_BUDGET_CONFIG["decompose_threshold"],
                ),
                "warning_threshold": budget_config.get(
                    "warning_threshold",
                    DEFAULT_DERIVATION_BUDGET_CONFIG["warning_threshold"],
                ),
                "min_subtask_ratio": budget_config.get(
                    "min_subtask_ratio",
                    DEFAULT_DERIVATION_BUDGET_CONFIG["min_subtask_ratio"],
                ),
            }
    return DEFAULT_DERIVATION_BUDGET_CONFIG.copy()


def get_derivation_task_config() -> dict:
    """Get derivation task budget configuration.

    Returns:
        Dict with token_budget, cost_budget_usd keys
    """
    config, _, _ = load_layered_config()
    derivation_config = config.get("derivation", {})
    if isinstance(derivation_config, dict):
        task_config = derivation_config.get("task", {})
        if isinstance(task_config, dict):
            return {
                "token_budget": task_config.get(
                    "token_budget", DEFAULT_DERIVATION_TASK_CONFIG["token_budget"]
                ),
                "cost_budget_usd": task_config.get(
                    "cost_budget_usd", DEFAULT_DERIVATION_TASK_CONFIG["cost_budget_usd"]
                ),
            }
    return DEFAULT_DERIVATION_TASK_CONFIG.copy()


# Hybrid polling getter (CHORE-CONFIG-DEFAULTS-001-E2 Story 7)


def get_hybrid_polling_config() -> dict:
    """Get hybrid orchestration polling configuration.

    Returns:
        Dict with max_delay_s, backoff_multiplier, base_delay_s keys
    """
    config, _, _ = load_layered_config()
    hybrid_config = config.get("hybrid", {})
    if isinstance(hybrid_config, dict):
        polling_config = hybrid_config.get("polling", {})
        if isinstance(polling_config, dict):
            return {
                "max_delay_s": polling_config.get(
                    "max_delay_s", DEFAULT_HYBRID_POLLING_CONFIG["max_delay_s"]
                ),
                "backoff_multiplier": polling_config.get(
                    "backoff_multiplier",
                    DEFAULT_HYBRID_POLLING_CONFIG["backoff_multiplier"],
                ),
                "base_delay_s": polling_config.get(
                    "base_delay_s", DEFAULT_HYBRID_POLLING_CONFIG["base_delay_s"]
                ),
            }
    return DEFAULT_HYBRID_POLLING_CONFIG.copy()


# Display limits getter (CHORE-MAGIC-VALUES-002)

# Valid display limit names
_DISPLAY_LIMIT_NAMES = frozenset(
    [
        "title_max_chars",
        "description_max_chars",
        "note_max_chars",
        "summary_max_chars",
        "objective_preview_max_chars",
        "list_preview_max_items",
        "seconds_before_minutes",
    ]
)


def get_display_limit(name: str) -> int:
    """Get display truncation limit by name.

    Resolution order (Rule 22):
    1. OBRA_DISPLAY_LIMIT_{NAME.upper()} environment variable
    2. display.limits.{name} from config file
    3. Fail fast if not found (no silent fallback)

    Args:
        name: One of 'title_max_chars', 'description_max_chars',
              'note_max_chars', 'seconds_before_minutes'

    Returns:
        The limit value as an integer

    Raises:
        ConfigurationError: If name is not a valid display limit name
        ConfigurationError: If limit is not found in config

    Example:
        # Override title truncation limit via environment
        export OBRA_DISPLAY_LIMIT_TITLE_MAX_CHARS=50

        # Or set in config:
        # display:
        #   limits:
        #     title_max_chars: 50
    """
    # Validate name
    if name not in _DISPLAY_LIMIT_NAMES:
        valid_names = ", ".join(sorted(_DISPLAY_LIMIT_NAMES))
        msg = f"Invalid display limit name '{name}'. Valid names: {valid_names}"
        raise ConfigurationError(msg)

    # Priority 1: Environment variable
    env_name = f"OBRA_DISPLAY_LIMIT_{name.upper()}"
    env_val = os.environ.get(env_name)
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None

    # Priority 2: Config file (include defaults to get display.limits from default_config.yaml)
    config, _, _ = load_layered_config(include_defaults=True)
    try:
        display_config = config["display"]
        limits_config = display_config["limits"]
        return int(limits_config[name])
    except (KeyError, TypeError) as exc:
        msg = f"Display limit '{name}' not found in config at display.limits.{name}"
        raise ConfigurationError(msg) from exc


# Valid spinner config keys
_SPINNER_CONFIG_KEYS = frozenset(
    [
        "enabled",
        "accent_enabled",
        "phrase_rotation_interval_s",
        "phrase_rotation_min_s",
        "phrase_rotation_max_s",
        "accent_highlight_color",
        "accent_highlight_width",
        "accent_highlight_gradient",
        "accent_sweep_target_s",
        "accent_step_min_ms",
        "accent_step_max_ms",
        "accent_pause_min_s",
        "accent_pause_max_s",
        "refresh_rate_hz",
    ]
)

_SPINNER_BOOL_KEYS = frozenset({"enabled", "accent_enabled", "accent_highlight_gradient"})
_SPINNER_INT_KEYS = frozenset(
    {"refresh_rate_hz", "accent_highlight_width", "accent_step_min_ms", "accent_step_max_ms"}
)
_SPINNER_STR_KEYS = frozenset({"accent_highlight_color"})


def get_spinner_config(key: str) -> bool | int | float | str:
    """Get spinner configuration value by key.

    Resolution order (Rule 22):
    1. OBRA_SPINNER_{KEY.upper()} environment variable
    2. display.spinner.{key} from config file
    3. Fail fast if not found (no silent fallback)

    Args:
        key: One of 'enabled', 'accent_enabled', 'phrase_rotation_interval_s',
            'phrase_rotation_min_s', 'phrase_rotation_max_s', 'accent_highlight_color',
            'accent_highlight_width', 'accent_sweep_target_s', 'accent_step_min_ms',
            'accent_step_max_ms', 'accent_pause_min_s', 'accent_pause_max_s',
            'refresh_rate_hz'

    Returns:
        The config value (bool for enabled, numeric for others, str for colors)

    Raises:
        ConfigurationError: If key is not valid or not found in config

    Example:
        # Override spinner interval via environment
        export OBRA_SPINNER_PHRASE_ROTATION_INTERVAL_S=5
        export OBRA_SPINNER_PHRASE_ROTATION_MIN_S=240
        export OBRA_SPINNER_PHRASE_ROTATION_MAX_S=660
        export OBRA_SPINNER_ACCENT_ENABLED=1
        export OBRA_SPINNER_ACCENT_SWEEP_TARGET_S=6
        export OBRA_SPINNER_ACCENT_PAUSE_MIN_S=5
        export OBRA_SPINNER_ACCENT_PAUSE_MAX_S=9

        # Or set in config:
        # display:
        #   spinner:
        #     phrase_rotation_interval_s: 5
        #     phrase_rotation_min_s: 240
        #     phrase_rotation_max_s: 660
        #     accent_enabled: true
        #     accent_highlight_color: "#7aa7ff"
        #     accent_highlight_width: 5
        #     accent_highlight_gradient: true
        #     accent_sweep_target_s: 6
        #     accent_step_min_ms: 80
        #     accent_step_max_ms: 200
        #     accent_pause_min_s: 5
        #     accent_pause_max_s: 9
    """
    # Validate key
    if key not in _SPINNER_CONFIG_KEYS:
        valid_keys = ", ".join(sorted(_SPINNER_CONFIG_KEYS))
        msg = f"Invalid spinner config key '{key}'. Valid keys: {valid_keys}"
        raise ConfigurationError(msg)

    # Priority 1: Environment variable
    env_name = f"OBRA_SPINNER_{key.upper()}"
    env_val = os.environ.get(env_name)
    if env_val:
        if key in _SPINNER_BOOL_KEYS:
            return env_val.lower() in ("true", "1", "yes")
        if key in _SPINNER_STR_KEYS:
            return env_val
        try:
            if key in _SPINNER_INT_KEYS:
                return int(env_val)
            return float(env_val)
        except ValueError:
            msg = f"Invalid value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None

    # Priority 2: Config file (include defaults to get display.spinner from default_config.yaml)
    config, _, _ = load_layered_config(include_defaults=True)
    try:
        spinner_config = config["display"]["spinner"]
        value = spinner_config[key]
        if key in _SPINNER_BOOL_KEYS:
            return bool(value)
        if key in _SPINNER_STR_KEYS:
            return str(value)
        if key in _SPINNER_INT_KEYS:
            return int(value)
        return float(value)
    except (KeyError, TypeError) as exc:
        msg = f"Spinner config '{key}' not found in config at display.spinner.{key}"
        raise ConfigurationError(msg) from exc


# Valid timeout categories (CHORE-MAGIC-VALUES-002)
_TIMEOUT_CATEGORIES = frozenset(
    [
        "display",
        "http",
        "ollama",
        "handler",
        "subprocess_runner",
    ]
)

# Valid timeout names per category
_TIMEOUT_NAMES: dict[str, frozenset[str]] = {
    "display": frozenset(["status_update_interval_s"]),
    "http": frozenset(["request_s", "upload_s"]),
    "ollama": frozenset(["default_s", "status_s", "status_ready_s"]),
    "handler": frozenset(["thread_join_s", "subprocess_s", "socket_connect_s"]),
    "subprocess_runner": frozenset(["poll_interval_s", "process_wait_s", "error_cleanup_s"]),
}


def get_timeout(category: str, name: str) -> float:
    """Get timeout value by category and name.

    Resolution order (Rule 22):
    1. OBRA_TIMEOUT_{CATEGORY}_{NAME} environment variable (uppercase)
    2. timeouts.{category}.{name} from config file
    3. Fail fast if not found (no silent fallback)

    Args:
        category: One of 'display', 'http', 'ollama', 'handler', 'subprocess_runner'
        name: Timeout name within the category (e.g., 'request_s', 'status_update_interval_s')

    Returns:
        The timeout value as a float

    Raises:
        ConfigurationError: If category or name is invalid
        ConfigurationError: If timeout is not found in config

    Example:
        # Override HTTP request timeout via environment
        export OBRA_TIMEOUT_HTTP_REQUEST_S=60

        # Or set in config:
        # timeouts:
        #   http:
        #     request_s: 60
    """
    # Validate category
    if category not in _TIMEOUT_CATEGORIES:
        valid_cats = ", ".join(sorted(_TIMEOUT_CATEGORIES))
        msg = f"Invalid timeout category '{category}'. Valid categories: {valid_cats}"
        raise ConfigurationError(msg)

    # Validate name for category
    valid_names = _TIMEOUT_NAMES.get(category, frozenset())
    if name not in valid_names:
        valid_names_str = ", ".join(sorted(valid_names))
        msg = (
            f"Invalid timeout name '{name}' for category '{category}'. "
            f"Valid names: {valid_names_str}"
        )
        raise ConfigurationError(msg)

    # Priority 1: Environment variable
    env_name = f"OBRA_TIMEOUT_{category.upper()}_{name.upper()}"
    env_val = os.environ.get(env_name)
    if env_val:
        try:
            return float(env_val)
        except ValueError:
            msg = f"Invalid float value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None

    # Priority 2: Config file
    config, _, _ = load_layered_config(include_defaults=True)
    try:
        timeouts_config = config["timeouts"]
        category_config = timeouts_config[category]
        return float(category_config[name])
    except (KeyError, TypeError) as exc:
        msg = f"Timeout '{category}.{name}' not found in config at timeouts.{category}.{name}"
        raise ConfigurationError(msg) from exc


# Valid orchestration limit names (CHORE-MAGIC-VALUES-002)
_LIMIT_NAMES = frozenset(
    [
        "max_retries_default",
        "max_retries_critical",
        "batch_size_default",
        "page_limit",
        "max_iterations",
        "max_fix_attempts",
    ]
)


def get_limit(name: str) -> int:
    """Get operational limit by name.

    Resolution order (Rule 22):
    1. OBRA_LIMIT_{NAME} environment variable (uppercase)
    2. orchestration.limits.{name} from config file
    3. Fail fast if not found (no silent fallback)

    Args:
        name: One of 'max_retries_default', 'max_retries_critical', 'batch_size_default',
              'page_limit', 'max_iterations', 'max_fix_attempts'

    Returns:
        The limit value as an integer

    Raises:
        ConfigurationError: If name is not a valid limit name
        ConfigurationError: If limit is not found in config

    Example:
        # Override max iterations via environment
        export OBRA_LIMIT_MAX_ITERATIONS=20

        # Or set in config:
        # orchestration:
        #   limits:
        #     max_iterations: 20
    """
    # Validate name
    if name not in _LIMIT_NAMES:
        valid_names = ", ".join(sorted(_LIMIT_NAMES))
        msg = f"Invalid limit name '{name}'. Valid names: {valid_names}"
        raise ConfigurationError(msg)

    # Priority 1: Environment variable
    env_name = f"OBRA_LIMIT_{name.upper()}"
    env_val = os.environ.get(env_name)
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None

    # Priority 2: Config file
    config, _, _ = load_layered_config(include_defaults=True)
    try:
        limits_config = config["orchestration"]["limits"]
        return int(limits_config[name])
    except (KeyError, TypeError) as exc:
        msg = f"Limit '{name}' not found in config at orchestration.limits.{name}"
        raise ConfigurationError(msg) from exc


# Valid hierarchy limit names (CHORE-MAGIC-VALUES-002)
_HIERARCHY_LIMIT_NAMES = frozenset(
    [
        "max_stories_per_epic",
        "max_tasks_per_story",
        "max_subtasks_per_task",
    ]
)


def get_hierarchy_limit(name: str) -> int:
    """Get hierarchy constraint limit by name.

    Resolution order (Rule 22):
    1. OBRA_HIERARCHY_{NAME} environment variable (uppercase)
    2. orchestration.hierarchy.{name} from config file
    3. Fail fast if not found (no silent fallback)

    Args:
        name: One of 'max_stories_per_epic', 'max_tasks_per_story', 'max_subtasks_per_task'

    Returns:
        The limit value as an integer

    Raises:
        ConfigurationError: If name is not a valid hierarchy limit name
        ConfigurationError: If limit is not found in config

    Example:
        # Override max stories per epic via environment
        export OBRA_HIERARCHY_MAX_STORIES_PER_EPIC=20

        # Or set in config:
        # orchestration:
        #   hierarchy:
        #     max_stories_per_epic: 20
    """
    # Validate name
    if name not in _HIERARCHY_LIMIT_NAMES:
        valid_names = ", ".join(sorted(_HIERARCHY_LIMIT_NAMES))
        msg = f"Invalid hierarchy limit name '{name}'. Valid names: {valid_names}"
        raise ConfigurationError(msg)

    # Priority 1: Environment variable
    env_name = f"OBRA_HIERARCHY_{name.upper()}"
    env_val = os.environ.get(env_name)
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None

    # Priority 2: Config file
    config, _, _ = load_layered_config(include_defaults=True)
    try:
        hierarchy_config = config["orchestration"]["hierarchy"]
        return int(hierarchy_config[name])
    except (KeyError, TypeError) as exc:
        msg = f"Hierarchy limit '{name}' not found in config at orchestration.hierarchy.{name}"
        raise ConfigurationError(msg) from exc


def get_cli_interrupt_threshold() -> int:
    """Get the CLI interrupt threshold for force quit.

    Resolution order (Rule 22):
    1. OBRA_CLI_INTERRUPT_THRESHOLD environment variable
    2. cli.interrupt_threshold from config file
    3. Fail fast if not found (no silent fallback)

    Returns:
        The threshold value (second Ctrl+C within window triggers force quit)
    """
    env_val = os.environ.get("OBRA_CLI_INTERRUPT_THRESHOLD")
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for OBRA_CLI_INTERRUPT_THRESHOLD"
            raise ConfigurationError(msg) from None

    config, _, _ = load_layered_config(include_defaults=True)
    try:
        return int(config["cli"]["interrupt_threshold"])
    except (KeyError, TypeError) as exc:
        msg = "cli.interrupt_threshold not found in config"
        raise ConfigurationError(msg) from exc


def get_cli_force_exit_threshold() -> int:
    """Get the CLI force exit threshold.

    Resolution order (Rule 22):
    1. OBRA_CLI_FORCE_EXIT_THRESHOLD environment variable
    2. cli.force_exit_threshold from config file
    3. Fail fast if not found (no silent fallback)

    Returns:
        The threshold value (third+ Ctrl+C total bypasses countdown)
    """
    env_val = os.environ.get("OBRA_CLI_FORCE_EXIT_THRESHOLD")
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for OBRA_CLI_FORCE_EXIT_THRESHOLD"
            raise ConfigurationError(msg) from None

    config, _, _ = load_layered_config(include_defaults=True)
    try:
        return int(config["cli"]["force_exit_threshold"])
    except (KeyError, TypeError) as exc:
        msg = "cli.force_exit_threshold not found in config"
        raise ConfigurationError(msg) from exc


# ==============================================================================
# Pipeline Configuration (FEAT-PIPELINE-001)
# ==============================================================================

# Valid trigger points for pipeline stages
VALID_TRIGGERS = [
    "after_intent",
    "after_derivation",
    "before_step",
    "after_step",
    "after_implementation",
    "before_review",
    "before_scorecard",
]


def get_pipeline_custom_stages() -> list[dict[str, Any]]:
    """Get enabled custom pipeline stages from configuration.

    Resolution order:
    1. pipeline.custom_stages from config file
    2. Empty list (default)

    Returns:
        List of enabled stage configurations (filtered to enabled=True only)

    Example:
        >>> stages = get_pipeline_custom_stages()
        >>> for stage in stages:
        ...     print(f"Stage {stage['name']} runs at {stage['trigger']}")
    """
    config, _, _ = load_layered_config(include_defaults=True)

    # Get custom stages, default to empty list
    custom_stages = config.get("pipeline", {}).get("custom_stages", [])

    # Filter to enabled stages only
    return [stage for stage in custom_stages if stage.get("enabled", True)]


def get_pipeline_stage_timeout(stage_name: str) -> int:
    """Get timeout for a specific pipeline stage.

    Resolution order:
    1. OBRA_PIPELINE_STAGE_TIMEOUT_S environment variable
    2. Stage-specific timeout from config (if defined)
    3. pipeline.defaults.timeout_s from config
    4. 300 seconds (default)

    Args:
        stage_name: Name of the stage to get timeout for

    Returns:
        Timeout in seconds

    Example:
        # Override globally
        export OBRA_PIPELINE_STAGE_TIMEOUT_S=600

        # Or set per-stage in config:
        pipeline:
          custom_stages:
            - name: my_stage
              timeout_s: 600
    """
    # Check environment override first
    env_val = os.environ.get("OBRA_PIPELINE_STAGE_TIMEOUT_S")
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for OBRA_PIPELINE_STAGE_TIMEOUT_S"
            raise ConfigurationError(msg) from None

    config, _, _ = load_layered_config(include_defaults=True)

    # Check for stage-specific timeout
    custom_stages = config.get("pipeline", {}).get("custom_stages", [])
    for stage in custom_stages:
        if stage.get("name") == stage_name and "timeout_s" in stage:
            return int(stage["timeout_s"])

    # Fall back to default timeout
    try:
        return int(config["pipeline"]["defaults"]["timeout_s"])
    except (KeyError, TypeError):
        return 300  # Default fallback


def get_pipeline_max_iterations() -> int:
    """Get maximum re-validate iterations for pipeline stages.

    Resolution order:
    1. OBRA_PIPELINE_MAX_ITERATIONS environment variable
    2. pipeline.defaults.max_iterations from config
    3. 3 (default)

    Returns:
        Maximum iterations before escalation

    Example:
        # Override via environment
        export OBRA_PIPELINE_MAX_ITERATIONS=5

        # Or set in config:
        pipeline:
          defaults:
            max_iterations: 5
    """
    # Check environment override first
    env_val = os.environ.get("OBRA_PIPELINE_MAX_ITERATIONS")
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for OBRA_PIPELINE_MAX_ITERATIONS"
            raise ConfigurationError(msg) from None

    config, _, _ = load_layered_config(include_defaults=True)

    try:
        return int(config["pipeline"]["defaults"]["max_iterations"])
    except (KeyError, TypeError):
        return 3  # Default fallback


def validate_pipeline_config(config: dict[str, Any]) -> list[str]:
    """Validate pipeline configuration against schema.

    Validates:
        1. Trigger values against VALID_TRIGGERS
        2. Agent/agents values against AgentRegistry (built-in + plug-in)
        3. Actor values against valid options
        4. Action values against valid options
        5. Then values against valid options
        6. On_sound values against valid options

    Args:
        config: Configuration dictionary to validate

    Returns:
        List of error strings (empty if valid)

    Example:
        >>> config = load_layered_config()[0]
        >>> errors = validate_pipeline_config(config)
        >>> if errors:
        ...     print("\\n".join(errors))
    """
    errors: list[str] = []

    # Check if pipeline config exists
    if "pipeline" not in config:
        return errors  # No pipeline config is valid (optional feature)

    pipeline_config = config["pipeline"]

    # Validate custom_stages structure
    if "custom_stages" not in pipeline_config:
        return errors  # Empty stages is valid

    custom_stages = pipeline_config.get("custom_stages", [])
    if not isinstance(custom_stages, list):
        errors.append("pipeline.custom_stages must be a list")
        return errors

    # Import AgentRegistry for agent validation
    try:
        from obra.agents.registry import AgentRegistry
        from obra.api.protocol import AgentType

        registry = AgentRegistry()
        # Get all valid agent names (built-in + registered plug-ins)
        valid_agents = set()
        # Add built-in agents from AgentType enum
        for agent_type in AgentType:
            valid_agents.add(agent_type.value)
        # Add registered plug-in agents
        valid_agents.update(registry.list_agents())
    except ImportError as exc:
        errors.append(f"Failed to import agent registry for validation: {exc}")
        return errors

    # Validate each stage
    for idx, stage in enumerate(custom_stages):
        if not isinstance(stage, dict):
            errors.append(f"Stage {idx} must be a dictionary")
            continue

        stage_name = stage.get("name", f"stage-{idx}")

        # Validate trigger
        trigger = stage.get("trigger")
        if trigger and trigger not in VALID_TRIGGERS:
            errors.append(
                f"Stage '{stage_name}': invalid trigger '{trigger}'. "
                f"Must be one of: {', '.join(VALID_TRIGGERS)}"
            )

        # Validate agent/agents
        agent = stage.get("agent")
        agents = stage.get("agents")

        if agent and agents:
            errors.append(f"Stage '{stage_name}': cannot specify both 'agent' and 'agents'")
        elif not agent and not agents:
            errors.append(f"Stage '{stage_name}': must specify either 'agent' or 'agents'")
        else:
            # Validate agent names against registry
            agents_to_check = [agent] if agent else (agents or [])
            for agent_name in agents_to_check:
                if agent_name not in valid_agents:
                    errors.append(
                        f"Stage '{stage_name}': agent '{agent_name}' not found in registry. "
                        f"Available agents: {', '.join(sorted(valid_agents))}"
                    )

        # Validate on_issues structure
        on_issues = stage.get("on_issues")
        if on_issues and isinstance(on_issues, dict):
            # Validate actor
            actor = on_issues.get("actor")
            valid_actors = ["implementer", "orchestrator", "escalate"]
            if actor and actor not in valid_actors:
                errors.append(
                    f"Stage '{stage_name}': invalid actor '{actor}'. "
                    f"Must be one of: {', '.join(valid_actors)}"
                )

            # Validate action
            action = on_issues.get("action")
            valid_actions = ["refine", "review"]
            if action and action not in valid_actions:
                errors.append(
                    f"Stage '{stage_name}': invalid action '{action}'. "
                    f"Must be one of: {', '.join(valid_actions)}"
                )

            # Validate then
            then = on_issues.get("then")
            valid_then_values = ["re-validate", "continue", "escalate", "block"]
            if then and then not in valid_then_values:
                errors.append(
                    f"Stage '{stage_name}': invalid then '{then}'. "
                    f"Must be one of: {', '.join(valid_then_values)}"
                )

        # Validate on_sound
        on_sound = stage.get("on_sound")
        valid_on_sound = ["continue"]
        if on_sound and on_sound not in valid_on_sound:
            errors.append(
                f"Stage '{stage_name}': invalid on_sound '{on_sound}'. "
                f"Must be one of: {', '.join(valid_on_sound)}"
            )

    return errors


# Public exports
__all__ = [
    "CONFIG_LAYER_DIR",
    # Constants
    "CONFIG_PATH",
    "DEFAULT_AGENT_BASE_TIMEOUT",
    "DEFAULT_AGENT_EXECUTION_TIMEOUT",
    "DEFAULT_AGENT_EXTENDED_TIMEOUT",
    "DEFAULT_AGENT_GRACEFUL_TERMINATION_WAIT",
    "DEFAULT_AGENT_LIVENESS_CHECK_INTERVAL",
    "DEFAULT_API_BASE_URL",
    "DEFAULT_API_CLIENT_DEFAULT_TIMEOUT_S",
    # Auto runner & cleanup config (CHORE-CONFIG-DEFAULTS-001-E3 Story 0)
    "DEFAULT_AUTO_STORY_TIMEOUT_S",
    "DEFAULT_CHECK_FOR_UPDATES",
    "DEFAULT_CLEANUP_SLEEP_CAP_S",
    "DEFAULT_CLI_CACHE_CRITICAL_THRESHOLD_MB",
    "DEFAULT_CLI_CACHE_WARN_THRESHOLD_MB",
    "DEFAULT_CLI_FORCE_QUIT_WINDOW_S",
    "DEFAULT_CLI_RETRY_BACKOFF_MULTIPLIER",
    "DEFAULT_CLI_RETRY_INITIAL_DELAY_S",
    "DEFAULT_CLI_RETRY_MAX_ATTEMPTS",
    "DEFAULT_CONFIG_EXPLORER_NOTIFICATION_TIMEOUT_S",
    "DEFAULT_DERIVATION_AUTO_DECOMPOSE_CONFIG",
    "DEFAULT_DERIVATION_BUDGET_CONFIG",
    "DEFAULT_DERIVATION_EPIC_ITEM_REDERIVE_THRESHOLD",
    "DEFAULT_DERIVATION_EPIC_OUTPUT_TOKEN_LIMIT",
    "DEFAULT_DERIVATION_EXPLORATION_LOOKBACK_MINUTES",
    "DEFAULT_DERIVATION_MAX_DEPTH_WARNING_THRESHOLD",
    "DEFAULT_DERIVATION_STORY_RANGE",
    "DEFAULT_DERIVATION_TASK_RANGE",
    "DEFAULT_DERIVATION_STRICT_STORY_RANGE",
    "DEFAULT_DERIVATION_STRICT_TASK_RANGE",
    "DEFAULT_DERIVATION_PRE_FILTER_TIMEOUT",
    "DEFAULT_DERIVATION_RAW_RESPONSE_LIMIT",
    "DEFAULT_DERIVATION_RAW_RESPONSE_WARN_LIMIT",
    # Derivation & execution limits config (CHORE-CONFIG-DEFAULTS-001-E3 Story 2)
    "DEFAULT_DERIVATION_README_LIMIT",
    "DEFAULT_DERIVATION_SIZING_GATE_TIMEOUT",
    "DEFAULT_DERIVATION_TASK_CONFIG",
    # Handler configuration (CHORE-CONFIG-DEFAULTS-001-E2 Story 0)
    "DEFAULT_DERIVE_ALIGNMENT_TIMEOUT",
    "DEFAULT_DERIVE_CACHE_MAX_AGE",
    "DEFAULT_DERIVE_COMPLEXITY_MEDIUM_MAX_STEPS",
    "DEFAULT_DERIVE_COMPLEXITY_SIMPLE_MAX_STEPS",
    "DEFAULT_DERIVE_LLM_TIMEOUT",
    "DEFAULT_DERIVE_MAPPING_TIMEOUT",
    "DEFAULT_DERIVE_MAX_RELEVANT_FILES",
    "DEFAULT_DERIVE_MAX_RETRIES",
    "DEFAULT_DERIVE_RAW_RESPONSE_LOG_PREVIEW",
    "DEFAULT_EXECUTION_QUALITY_DEFAULT_THRESHOLD",
    "DEFAULT_EXECUTION_QUALITY_GENERATED_PLAN_THRESHOLD",
    "DEFAULT_FIX_BATCHING_ENABLED",
    "DEFAULT_FIX_BATCHING_MAX_SIZE",
    "DEFAULT_FIX_BATCHING_SPLIT_ON_RETRY",
    "DEFAULT_FIX_HANDLER_DOC_TIMEOUT",
    "DEFAULT_FIX_HANDLER_MAX_RETRIES",
    "DEFAULT_FIX_HANDLER_MIN_FILE_SIZE",
    "DEFAULT_FIX_HANDLER_PARALLEL_ENABLED",
    "DEFAULT_FIX_HANDLER_PARALLEL_WORKERS",
    "DEFAULT_FIX_LLM_SUGGESTION_TIMEOUT",
    "DEFAULT_FIX_LLM_TEST_GAP_TIMEOUT",
    "DEFAULT_FIX_TEST_GAP_INFERENCE_CONFIDENCE_THRESHOLD",
    "DEFAULT_FIX_TEST_GAP_INFERENCE_ENABLED",
    "DEFAULT_FIX_TEST_GAP_INFERENCE_MAX_CANDIDATES",
    # Gateway server config (FEAT-GATEWAY-001)
    "DEFAULT_GATEWAY_CORS_ORIGINS",
    "DEFAULT_GATEWAY_ENABLE_CORS",
    "DEFAULT_GATEWAY_ESCALATION_TIMEOUT_S",
    "DEFAULT_GATEWAY_HOST",
    "DEFAULT_GATEWAY_MAX_SESSIONS",
    "DEFAULT_GATEWAY_PORT",
    "DEFAULT_GENERATED_PLAN_QUALITY_THRESHOLD",
    "DEFAULT_HANG_CONFIDENCE",
    "DEFAULT_HYBRID_POLLING_CONFIG",
    "DEFAULT_INTAKE_MIN_WORDS",
    "DEFAULT_INTENT_CHUNKING_CONFIG",
    "DEFAULT_INTENT_CONTEXT_MAX_CHARS",
    "DEFAULT_INTENT_CONTEXT_MAX_ITEMS",
    "DEFAULT_INTENT_CONTEXT_MAX_ITEM_CHARS",
    "DEFAULT_INTENT_DETECTION_EMPTY",
    "DEFAULT_INTENT_DETECTION_EXISTING",
    "DEFAULT_INTENT_INTERROGATIVE_RATIO",
    "DEFAULT_INTENT_RATE_LIMIT_CONFIG",
    "DEFAULT_INTENT_SLUG_MAX_LENGTH",
    "DEFAULT_INTENT_TOKEN_BUDGET",
    "DEFAULT_INTENT_TOKEN_WARNING",
    "DEFAULT_INTERACTIVE_GUARD_ENABLED",
    "DEFAULT_INTERACTIVE_GUARD_PATTERNS",
    "DEFAULT_INTERACTIVE_GUARD_RETRY_MAX",
    "DEFAULT_INTERACTIVE_GUARD_ROLLBACK_CODES",
    "DEFAULT_INTERACTIVE_GUARD_ROLLBACK_ENABLED",
    # Monitoring configuration (CHORE-CONFIG-DEFAULTS-001-E2 Story 5)
    "DEFAULT_LIVENESS_CPU_DELTA_THRESHOLD",
    "DEFAULT_LIVENESS_DB_UPDATE_WINDOW",
    "DEFAULT_LIVENESS_FILE_MTIME_WINDOW",
    "DEFAULT_LIVENESS_LOG_SILENCE_THRESHOLD",
    "DEFAULT_LIVENESS_MIN_ALIVE_INDICATORS",
    "DEFAULT_LLM_API_TIMEOUT",
    "DEFAULT_LLM_STREAM_IDLE_TIMEOUT",
    "DEFAULT_LLM_TIMEOUT",
    "DEFAULT_LOG_VIEWER_GRACEFUL_SHUTDOWN_DELAY_S",
    # Log viewer, CLI, auth & validation config (CHORE-CONFIG-DEFAULTS-001-E3 Story 3)
    "DEFAULT_LOG_VIEWER_HOST",
    "DEFAULT_LOG_VIEWER_INDEX_ROTATION_FILES",
    "DEFAULT_LOG_VIEWER_MAX_EVENTS",
    "DEFAULT_LOG_VIEWER_MAX_SNAPSHOT_BYTES",
    "DEFAULT_LOG_VIEWER_PORT",
    "DEFAULT_LOG_VIEWER_STREAM_SLEEP_S",
    "DEFAULT_LOG_VIEWER_TAIL_LIMIT",
    "DEFAULT_MAX_ITERATIONS",
    "DEFAULT_NETWORK_TIMEOUT",
    "DEFAULT_OAUTH_POLL_INTERVAL_S",
    "DEFAULT_OAUTH_THREAD_JOIN_TIMEOUT_S",
    "DEFAULT_PLAN_ITEM_MAX_ACCEPTANCE_CRITERIA",
    "DEFAULT_PLAN_ITEM_MAX_DESCRIPTION_WORDS",
    "DEFAULT_PLAN_ITEM_MAX_FILES_PER_TASK",
    "DEFAULT_PLAN_ITEM_MAX_LOC",
    "DEFAULT_PLAN_ITEM_MAX_TASKS",
    "DEFAULT_PRIORITY_ORDER",
    "DEFAULT_PROCESS_REGISTRY_TERMINATE_TIMEOUT_S",
    "DEFAULT_PRODUCTION_LOGGER_BACKUP_COUNT",
    "DEFAULT_PRODUCTION_LOGGER_MAX_SIZE_BYTES",
    "DEFAULT_QUALITY_THRESHOLD",
    "DEFAULT_REVIEW_AGENTS_MAX_WORKERS",
    "DEFAULT_REVIEW_AGENTS_PARALLEL",
    "DEFAULT_REVIEW_AGENT_TIMEOUT",
    "DEFAULT_REVIEW_BLOCKING_LOW_PRIORITY_STRICT",
    "DEFAULT_REVIEW_COMPLEXITY_MEDIUM",
    # Review complexity, intent, derivation, hybrid config (CHORE-CONFIG-DEFAULTS-001-E2 Story 7)
    "DEFAULT_REVIEW_COMPLEXITY_SIMPLE",
    "DEFAULT_REVIEW_LOOP_EXIT_POLICY_ENABLED",
    "DEFAULT_REVIEW_LOOP_EXIT_POLICY_MAX_NON_CRITICAL_REVIEW_CYCLES",
    "DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_NO_NEW_CRITICAL",
    "DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_REQUIRED_CHECKS_PASS",
    "DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_THRESHOLD_MET",
    "DEFAULT_REVISION_PLAN_SHRINKAGE_BLOCK_THRESHOLD",
    "DEFAULT_REVISION_PLAN_SHRINKAGE_WARNING_THRESHOLD",
    "DEFAULT_SKIP_TRACKING_MAX_LOGS_CHARS",
    "DEFAULT_STORY0_LLM_SCHEMA_TIMEOUT",
    "DEFAULT_TOOLING_DISCOVERY_MAX_MANIFEST_BYTES",
    "DEFAULT_TOOLING_DISCOVERY_TIMEOUT",
    "DEFAULT_TRIAGE_HIGH_CONFIDENCE",
    "DEFAULT_TRIAGE_LOW_CONFIDENCE",
    "DEFAULT_TRIAGE_MEDIUM_CONFIDENCE",
    "DEFAULT_UPDATE_NOTIFICATION_COOLDOWN_MINUTES",
    "DEFAULT_VERIFICATION_AUTO_INSTALL",
    "DEFAULT_VERIFICATION_DISCOVERY_ENABLED",
    "DEFAULT_FAILURE_CONTEXT_MAX_CHARS",
    "DEFAULT_VERIFICATION_FORCE_REFRESH",
    "DEFAULT_VERIFICATION_MAX_RETRIES",
    "DEFAULT_WATCHDOG_ENABLED",
    "DEFAULT_WATCHDOG_STALL_TIMEOUT_S",
    "DEFAULT_WORKFLOW_KEYWORD_WEIGHT",
    # Workflow & work type config (CHORE-CONFIG-DEFAULTS-001-E2 Story 6)
    "DEFAULT_WORKFLOW_PATTERN_WEIGHT",
    "DEFAULT_WORKING_DIR_ENFORCEMENT_ENABLED",
    "DEFAULT_WORK_TYPE_BASE_SCORE",
    "DEFAULT_WORK_TYPE_KEYWORD_WEIGHT",
    "DEFAULT_WORK_TYPE_MAX_BONUS",
    "DEFAULT_WORK_TYPE_PHRASE_WEIGHT",
    "DEFAULT_WORK_TYPE_REGEX_WEIGHT",
    "DEPRECATED_FIELDS",
    "LEGACY_CONFIG_PATH",
    "LOCAL_EMULATOR_API_URL",
    # Semantic aliases (UX-CONFIG-001)
    "SEMANTIC_CONFIG_ALIASES",
    # Local emulator mode
    "enable_local_mode",
    "expand_automation_mode",
    "get_agent_base_timeout",
    "get_agent_execution_timeout",
    "get_agent_extended_timeout",
    "get_agent_graceful_termination_wait",
    "get_agent_ignore_patterns",
    "get_agent_liveness_check_interval",
    # Getters with env override
    "get_api_base_url",
    "get_api_client_config",
    # API constants migration (CHORE-CONFIG-DEFAULTS-001-E1 Story 7)
    "get_api_connection_pool_config",
    "get_api_limits",
    "get_api_retry_delays",
    "get_api_timeouts",
    "get_auto_retry_config",
    "get_auto_story_timeout_s",
    "get_code_verify_config",
    "get_code_verify_preflight_config",
    "get_code_verify_timeout_s",
    "get_decomposition_duration_threshold_s",
    "get_decomposition_max_attempts",
    "get_decomposition_summary_max_chars",
    "get_decomposition_warning_threshold_s",
    # Version check config
    "get_check_for_updates",
    # Auto-update config (FEAT-CLI-AUTO-UPDATE-001)
    "get_auto_update",
    "get_auto_update_cooldown_minutes",
    "get_auto_update_max_retries",
    "get_auto_update_retry_delay_s",
    "get_auto_update_pipx_timeout_s",
    "get_cleanup_investigation_config",
    "get_cleanup_sleep_cap_s",
    "get_cli_cache_config",
    "get_cli_force_exit_threshold",
    "get_cli_interrupt_threshold",
    "get_cli_retry_config",
    "get_cli_update_check_config",
    "get_config_explorer_config",
    # Config I/O functions
    "get_config_path",
    # Project config
    "get_default_project_override",
    "get_derivation_auto_decompose_config",
    "get_derivation_budget_config",
    "get_derivation_epic_item_rederive_threshold",
    "get_derivation_epic_output_token_limit",
    "get_derivation_story_range",
    "get_derivation_task_range",
    "get_derivation_strict_story_range",
    "get_derivation_strict_task_range",
    "get_derivation_max_depth_warning_threshold",
    "get_derivation_pre_filter_timeout",
    "get_derivation_preview_config",
    "get_derivation_sizing_gate_timeout",
    "get_derivation_task_config",
    "get_derive_alignment_timeout",
    "get_derive_cache_max_age",
    "get_derive_complexity_thresholds",
    "get_derive_llm_timeout",
    "get_derive_mapping_timeout",
    "get_derive_max_relevant_files",
    "get_derive_max_retries",
    "get_derive_raw_response_log_preview",
    # Display limits (CHORE-MAGIC-VALUES-002)
    "get_display_limit",
    "get_hierarchy_limit",
    "get_limit",
    "get_timeout",
    "get_execution_quality_config",
    # Fix batching (FEAT-PARALLEL-REVIEW-001)
    "get_gateway_config",
    "get_fix_batching_enabled",
    "get_fix_batching_max_size",
    "get_fix_batching_split_on_retry",
    "get_fix_handler_doc_timeout",
    "get_fix_handler_max_retries",
    "get_fix_handler_min_file_size",
    "get_fix_handler_parallel_enabled",
    "get_fix_handler_parallel_workers",
    "get_fix_llm_suggestion_timeout",
    "get_fix_llm_test_gap_timeout",
    "get_fix_test_gap_inference_confidence_threshold",
    # Fix test-gap inference (FEAT-REVIEW-FIX-TESTGAP-LLM-001)
    "get_fix_test_gap_inference_enabled",
    "get_fix_test_gap_inference_max_candidates",
    "get_generated_plan_quality_threshold",
    "get_hang_confidence",
    "get_hybrid_polling_config",
    "get_intake_config",
    "get_intent_chunking_config",
    "get_intent_context_max_chars",
    "get_intent_context_max_item_chars",
    "get_intent_context_max_items",
    "get_intent_rate_limit_config",
    "get_intent_slug_max_length",
    "get_intent_thresholds_config",
    # Intent token budget
    "get_intent_token_budget",
    "get_interactive_guard_enabled",
    "get_interactive_guard_patterns",
    "get_interactive_guard_retry_max",
    "get_interactive_guard_rollback_codes",
    "get_interactive_guard_rollback_enabled",
    # Agent isolation config
    "get_isolated_mode",
    "get_liveness_cpu_delta_threshold",
    "get_liveness_db_update_window",
    "get_liveness_file_mtime_window",
    "get_liveness_log_silence_threshold",
    "get_liveness_min_alive_indicators",
    "get_llm_api_timeout",
    "get_llm_stream_idle_timeout",
    "get_llm_timeout",
    "get_log_viewer_config",
    "get_max_iterations",
    "get_oauth_config",
    "get_ollama_endpoint",
    "get_plan_item_validation_config",
    "get_pipeline_custom_stages",
    "get_pipeline_max_iterations",
    "get_pipeline_stage_timeout",
    "get_priority_order",
    "get_process_registry_config",
    "get_production_logger_config",
    "get_project_layer_path",
    # Provider tier defaults (CHORE-CONFIG-DEFAULTS-001-E1)
    "get_provider_tier_defaults",
    # Role-aware tier defaults
    "get_role_tier_defaults",
    # Missing config entries (CHORE-CONFIG-DEFAULTS-001-E1 Story 6)
    "get_quality_config",
    # Quality thresholds
    "get_quality_threshold",
    "get_retry_config",
    "get_review_agent_timeout",
    "get_review_agents_max_workers",
    # Parallel review agents (FEAT-PARALLEL-REVIEW-001)
    "get_review_agents_parallel",
    "get_review_blocking_low_priority_strict",
    "get_review_complexity_medium",
    "get_review_complexity_simple",
    "get_review_loop_exit_policy_enabled",
    "get_review_loop_exit_policy_max_non_critical_review_cycles",
    "get_review_loop_exit_policy_require_no_new_critical",
    "get_review_loop_exit_policy_require_required_checks_pass",
    "get_review_loop_exit_policy_require_threshold_met",
    "get_revision_plan_shrinkage_block_threshold",
    "get_revision_plan_shrinkage_warning_threshold",
    "get_session_layer_override",
    "get_session_layer_path",
    "get_skip_tracking_config",
    "get_spinner_config",
    "get_story0_llm_schema_timeout",
    "get_story0_capability_checks",
    # Thinking configuration (CHORE-CONFIG-DEFAULTS-001-E1 Story 4)
    "get_thinking_config",
    "get_tier_fallbacks",
    "get_tooling_discovery_config",
    "get_tooling_discovery_timeout",
    "get_triage_high_confidence",
    "get_triage_low_confidence",
    "get_triage_medium_confidence",
    "get_update_notification_cooldown_minutes",
    "DEFAULT_AUTO_UPDATE",
    "DEFAULT_AUTO_UPDATE_COOLDOWN_MINUTES",
    "DEFAULT_AUTO_UPDATE_MAX_RETRIES",
    "DEFAULT_AUTO_UPDATE_RETRY_DELAY_S",
    "DEFAULT_AUTO_UPDATE_PIPX_TIMEOUT_S",
    "get_user_story_generation_enabled",
    "get_user_story_generation_timeout_s",
    "get_user_story_max_stories",
    "get_user_story_model_tier",
    "get_verification_auto_install",
    # Verification discovery (CHORE-LANG-AGNOSTIC-VERIFY-001)
    "get_verification_discovery_enabled",
    "get_failure_context_max_chars",
    "get_verification_force_refresh",
    "get_verification_max_retries",
    "get_verification_tool_installs",
    # Verification discovery settings (FEAT-MENU6-001)
    "get_verification_discovery_settings",
    "get_verification_tools_config",
    # Watchdog config (ISSUE-HYBRID-003)
    "get_watchdog_enabled",
    "get_watchdog_stall_timeout",
    "get_work_type_base_score",
    "get_work_type_keyword_weight",
    "get_work_type_max_bonus",
    "get_work_type_phrase_weight",
    "get_work_type_regex_weight",
    "get_workflow_keyword_weight",
    "get_workflow_pattern_weight",
    # Working directory enforcement (defense-in-depth)
    "get_working_dir_enforcement_enabled",
    "get_xhigh_supported_models",
    "is_decomposition_enabled",
    "is_local_mode",
    "load_config",
    "load_layered_config",
    "load_llm_section",
    "load_project_layer",
    "resolve_config_alias",
    "resolve_semantic_alias",
    "save_config",
    "set_isolated_mode",
    "validate_default_schema",
    "validate_pipeline_config",
]
