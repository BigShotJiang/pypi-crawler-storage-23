"""Base class and types for review agents.

This module defines the BaseAgent abstract class and AgentResult dataclass
that all review agents must implement.

Agent Architecture:
    - Agents are lightweight, stateless workers
    - Each agent runs as a subprocess for isolation
    - Agents analyze code and return structured results
    - Results include issues (with priority) and dimension scores

Related:
    - obra/agents/deployer.py
    - obra/api/protocol.py
"""

import contextlib
import hashlib
import json
import logging
import re
from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, cast

from obra.api.protocol import AgentType, Priority
from obra.config import get_review_agent_timeout
from obra.exceptions import ErrorContext, ExecutionError
from obra.hybrid.json_utils import (
    unwrap_claude_cli_json,
    unwrap_gemini_cli_json,
)

logger = logging.getLogger(__name__)


# Files that should be excluded from most agent analysis
# These are infrastructure/config files, not application code
EXCLUDED_FILES = {
    # Pytest infrastructure
    "conftest.py",
    # Build/packaging
    "setup.py",
    "setup.cfg",
    "pyproject.toml",
    "package-lock.json",
    "pnpm-lock.yaml",
    "yarn.lock",
    "go.sum",
    "Cargo.lock",
    "Gemfile.lock",
    "composer.lock",
    # Noxfile/tox
    "noxfile.py",
    "toxfile.py",
    # Type stubs
    "py.typed",
}

# Patterns for files that should be excluded (checked with fnmatch)
EXCLUDED_PATTERNS = [
    # Migration files
    "**/migrations/*.py",
    "**/alembic/versions/*.py",
    "**/migrations/*.sql",
    # Auto-generated
    "**/*_pb2.py",  # protobuf
    "**/*_pb2_grpc.py",
]

# File size thresholds for reading.
# - WARN: Log warning but still read (large but possibly legitimate)
# - MAX: Hard skip (almost certainly generated/binary/unreasonable)
#
# Context: LLM context windows are 500KB-800KB, so files above that would need
# chunking anyway. We set generous limits and let downstream handle it.
FILE_SIZE_WARN_BYTES: int = 1 * 1024 * 1024  # 1MB - warn but read
MAX_FILE_SIZE_BYTES: int = 10 * 1024 * 1024  # 10MB - hard skip

# Bytes to read for binary detection (check for null bytes).
BINARY_CHECK_BYTES: int = 8192  # 8KB

# Binary and generated file extensions to exclude from analysis.
# NOTE: This is an OPTIMIZATION layer, not a hard requirement. Binary files that
# slip through are handled gracefully by read_file() (UnicodeDecodeError → skip).
# We maintain common patterns to reduce wasted I/O, not for correctness.
BINARY_EXTENSIONS: frozenset[str] = frozenset(
    {
        # Python bytecode/packaging
        ".pyc",
        ".pyo",
        ".pyd",
        ".egg",
        ".whl",
        # Coverage/testing artifacts
        ".coverage",
        # Compiled binaries
        ".exe",
        ".dll",
        ".so",
        ".dylib",
        ".o",
        ".a",
        ".lib",
        # Archives
        ".tar",
        ".gz",
        ".zip",
        ".rar",
        ".7z",
        ".bz2",
        ".xz",
        # Images
        ".png",
        ".jpg",
        ".jpeg",
        ".gif",
        ".ico",
        ".bmp",
        ".svg",
        ".webp",
        # Fonts
        ".ttf",
        ".otf",
        ".woff",
        ".woff2",
        ".eot",
        # Media
        ".mp3",
        ".mp4",
        ".wav",
        ".avi",
        ".mov",
        ".webm",
        # Documents (binary)
        ".pdf",
        ".doc",
        ".docx",
        ".xls",
        ".xlsx",
        ".ppt",
        ".pptx",
        # Database
        ".db",
        ".sqlite",
        ".sqlite3",
        # Lock files (not useful to analyze)
        ".lock",
        # Minified files (not readable)
        ".min.js",
        ".min.css",
        # Build/cache binary files
        ".pack",  # webpack cache files
        ".idx",  # git index files
        ".map",  # source maps (often large, not useful for code review)
    }
)


@dataclass
class AgentIssue:
    """Issue found by a review agent.

    Attributes:
        id: Unique issue identifier
        title: Short description of the issue
        description: Detailed description
        priority: Issue priority (P0-P3)
        file_path: File where issue was found (if applicable)
        line_number: Line number (if applicable)
        dimension: Quality dimension (security, testing, docs, maintainability)
        suggestion: Suggested fix
        issue_type: Optional issue classification (e.g., test_gap)
        target_test_file: Optional target test file for test gap issues
        target_paths: Optional list of acceptable target file paths
        test_name: Optional test function name
        arrange: Optional arrange steps for the test
        act: Optional act steps for the test
        assert_steps: Optional assert steps for the test
        issue_kind: Optional issue intent (defect | coverage_gap | docs)
        resolution_path: Optional fix routing hint (code_and_tests | tests_only)
        verification_scope: Optional verification scope hint (auto | tests | lint | security)
        metadata: Additional metadata
    """

    id: str
    title: str
    description: str
    priority: Priority
    file_path: str | None = None
    line_number: int | None = None
    dimension: str = ""
    suggestion: str = ""
    issue_type: str | None = None
    target_test_file: str | None = None
    target_paths: list[str] | None = None
    test_name: str | None = None
    arrange: str | None = None
    act: str | None = None
    assert_steps: str | None = None
    issue_kind: str = "defect"
    resolution_path: str = "code_and_tests"
    verification_scope: str = "auto"
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "priority": self.priority.value,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "dimension": self.dimension,
            "suggestion": self.suggestion,
            "issue_type": self.issue_type,
            "target_test_file": self.target_test_file,
            "target_paths": self.target_paths or [],
            "test_name": self.test_name,
            "arrange": self.arrange,
            "act": self.act,
            "assert": self.assert_steps,
            "issue_kind": self.issue_kind,
            "resolution_path": self.resolution_path,
            "verification_scope": self.verification_scope,
            "metadata": self.metadata,
        }


@dataclass
class AgentResult:
    """Result from agent execution.

    Attributes:
        agent_type: Type of agent that produced this result
        status: Execution status (complete, timeout, error)
        issues: List of issues found
        scores: Dimension scores (0.0 - 1.0)
        execution_time_ms: Time taken in milliseconds
        error: Error message if status is error
        metadata: Additional metadata
    """

    agent_type: AgentType
    status: str  # complete, timeout, error
    issues: list[AgentIssue] = field(default_factory=list)
    scores: dict[str, float] = field(default_factory=dict)
    execution_time_ms: int = 0
    error: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API serialization."""
        return {
            "agent_type": self.agent_type.value,
            "status": self.status,
            "issues": [issue.to_dict() for issue in self.issues],
            "scores": self.scores,
            "execution_time_ms": self.execution_time_ms,
            "error": self.error,
            "metadata": self.metadata,
        }


class BaseAgent(ABC):
    """Abstract base class for review agents.

    All review agents must implement this interface. Agents analyze code
    in a workspace and return structured results with issues and scores.

    Implementing a new agent:
        1. Subclass BaseAgent
        2. Implement analyze() method
        3. Register with AgentRegistry
        4. Add to obra/agents/__init__.py

    See also:
        docs/guides/parameter-validation-guide.md - Parameter validation patterns (ADR-042)

    Example:
        >>> class MyAgent(BaseAgent):
        ...     agent_type = AgentType.SECURITY
        ...
        ...     def analyze(self, item_id, changed_files, timeout_ms):
        ...         issues = self._check_for_issues(changed_files)
        ...         scores = self._calculate_scores(changed_files)
        ...         return AgentResult(
        ...             agent_type=self.agent_type,
        ...             status="complete",
        ...             issues=issues,
        ...             scores=scores
        ...         )
    """

    # Subclasses must set this
    agent_type: AgentType

    # Directories to ignore when scanning for files (exact name match).
    # These are infrastructure/build directories that should not be analyzed.
    # Used by get_files_to_analyze() and should be used by any agent doing rglob().
    IGNORE_DIRS: frozenset[str] = frozenset(
        {
            ".git",
            ".obra",
            ".idea",
            ".vscode",
            "__pycache__",
            "node_modules",
            ".venv",
            "venv",
            ".tox",
            ".mypy_cache",
            ".pytest_cache",
            ".ruff_cache",
            ".coverage",
            "dist",
            "build",
            "target",
            "vendor",
            ".gradle",
            ".cargo",
            "bin",
            "obj",
            "eggs",
            ".eggs",
            "site-packages",
            ".nox",
            ".cache",
            "htmlcov",
            # JavaScript/TypeScript build outputs
            ".next",  # Next.js build output
            ".nuxt",  # Nuxt.js build output
            ".output",  # Nuxt 3 build output
            ".svelte-kit",  # SvelteKit build output
            ".vercel",  # Vercel deployment output
            ".turbo",  # Turborepo cache
            # Large non-code data sources (reduce LLM context noise)
            "logs",
            "firebase-seed-data",
            "research",
            "emulator-backup",
        }
    )

    # Directory suffixes to ignore (for patterns like *.egg-info).
    # Checked separately since IGNORE_DIRS uses exact match.
    IGNORE_DIR_SUFFIXES: tuple[str, ...] = (".egg-info",)

    def __init__(
        self,
        working_dir: Path,
        llm_config: dict[str, Any] | None = None,
        log_event: Callable[..., None] | None = None,
    ) -> None:
        """Initialize agent.

        Args:
            working_dir: Working directory containing code to analyze
            llm_config: Optional LLM configuration dict for CLI-based analysis.
                       If None, agent returns empty results (no analysis performed).
            log_event: Optional callback for event logging (observability)
        """
        self._working_dir = working_dir
        self._llm_config = llm_config
        self._log_event = log_event
        self._intent_context: str | None = None
        self._issue_id_seen: dict[str, str] = {}
        self._ignore_patterns = self._load_ignore_patterns()
        logger.debug(f"Initialized {self.__class__.__name__} for {working_dir}")

    def _load_ignore_patterns(self) -> list[str]:
        """Load ignore patterns for agent scans from config."""
        try:
            from obra.config.loaders import get_agent_ignore_patterns

            return get_agent_ignore_patterns()
        except Exception:
            return []

    def _matches_ignore_pattern(self, path: Path) -> bool:
        """Check if a path matches configured ignore patterns."""
        if not self._ignore_patterns:
            return False
        import fnmatch

        try:
            rel_path = path.relative_to(self._working_dir)
            rel_str = rel_path.as_posix()
            rel_parts = rel_path.parts
        except ValueError:
            rel_str = path.as_posix()
            rel_parts = path.parts

        for pattern in self._ignore_patterns:
            if not pattern:
                continue
            if "/" not in pattern and "\\" not in pattern:
                if pattern in rel_parts:
                    return True
                continue
            if fnmatch.fnmatch(rel_str, pattern):
                return True
            if fnmatch.fnmatch(rel_str + "/", pattern):
                return True
            if pattern.endswith("/**"):
                prefix = pattern[:-3].rstrip("/")
                if prefix and (rel_str == prefix or rel_str.startswith(prefix + "/")):
                    return True
            if pattern.endswith("/**/*"):
                prefix = pattern[:-4].rstrip("/")
                if prefix and (rel_str == prefix or rel_str.startswith(prefix + "/")):
                    return True
        return False

    @property
    def working_dir(self) -> Path:
        """Get working directory."""
        return self._working_dir

    def set_intent_context(self, intent_context: str | None) -> None:
        """Set intent context for prompt injection."""
        normalized = str(intent_context or "").strip()
        self._intent_context = normalized or None

    def _inject_intent_context(self, prompt: str) -> str:
        """Prepend intent context when available."""
        if not self._intent_context:
            return prompt
        return f"{self._intent_context}\n\n{prompt}"

    def _invoke_cli(
        self,
        call_site: str,
        prompt: str,
        timeout_ms: int | None = None,
    ) -> str:
        """Invoke LLM via CLI subprocess for analysis.

        Uses the shared subprocess runner module for consistent behavior
        with execute/fix handlers.

        Args:
            call_site: Identifier for where the LLM is being called from
                      (e.g., "security_tier1", "testing_analysis")
            prompt: The prompt to send to the LLM
            timeout_ms: Maximum execution time in milliseconds (None = use config default)

        Returns:
            Response text from the LLM (unwrapped from JSON if applicable)
        """
        from obra.llm import (
            LLMSubprocessConfig,
            LLMSubprocessResult,
            run_llm_subprocess,
        )

        if not self._llm_config:
            logger.warning(f"{call_site}: No LLM config available, returning empty response")
            return ""

        # Resolve timeout (convert ms to seconds for subprocess)
        timeout_s = (timeout_ms or (get_review_agent_timeout() * 1000)) / 1000

        # Inject intent context into prompt
        prepared_prompt = self._inject_intent_context(prompt)

        # Get provider config
        provider = self._llm_config.get("provider", "anthropic")
        model = self._llm_config.get("model", "default")
        reasoning_level = self._llm_config.get("reasoning_level", "medium")
        auth_method = self._llm_config.get("auth_method", "oauth")

        # Resolve skip_git_check: default to True for OpenAI
        git_config = self._llm_config.get("git", {})
        skip_git_check = git_config.get("skip_check", provider == "openai")
        codex_config = cast(dict, self._llm_config.get("codex", {}))
        bypass_sandbox = bool(codex_config.get("bypass_sandbox", False))
        approval_mode = codex_config.get("approval_mode")

        # Use trace_id if available (set by deployer), otherwise let subprocess_runner generate UUID
        run_id = getattr(self, "_trace_id", None)

        # Build config for subprocess runner
        config = LLMSubprocessConfig(
            prompt=prepared_prompt,
            cwd=self._working_dir,
            provider=provider,
            model=model,
            reasoning_level=reasoning_level,
            auth_method=auth_method,
            timeout_s=int(timeout_s),
            skip_git_check=skip_git_check,
            bypass_sandbox=bypass_sandbox,
            approval_mode=approval_mode,
            streaming=False,  # Review agents don't stream
            log_event=self._log_event,
            call_site=call_site,
            run_id=run_id,
        )

        # Execute via shared subprocess runner
        result: LLMSubprocessResult = run_llm_subprocess(config)

        if not result.success:
            error_message = result.error or "Unknown error"
            if result.error_details and result.error_details.request_id:
                if "request_id=" not in error_message:
                    error_message = (
                        f"{error_message} (request_id={result.error_details.request_id})"
                    )
            if result.retry_count and "retries=" not in error_message:
                error_message = f"{error_message} (retries={result.retry_count})"
            error_context = ErrorContext(
                request_id=(result.error_details.request_id if result.error_details else None),
                retry_count=result.retry_count,
            )
            logger.error(f"{call_site}: LLM subprocess failed: {error_message}")
            # ISSUE-HYBRID-045: llm_call event is emitted by subprocess_runner
            # (authoritative source with full field coverage). No duplicate
            # emission needed here.
            raise ExecutionError(
                error_message,
                exit_code=result.returncode,
                stderr=result.error or "",
                error_context=error_context,
            )

        response_text: str = result.output.strip()

        # BUG-804dc037: Unwrap provider-specific JSON wrappers
        # Review agents use mode="text" which outputs --output-format json
        if response_text and provider in ("anthropic", "google"):
            try:
                data = json.loads(response_text)
                if provider == "anthropic":
                    unwrapped, was_wrapped = unwrap_claude_cli_json(data)
                else:
                    unwrapped, was_wrapped = unwrap_gemini_cli_json(data)

                if was_wrapped:
                    if isinstance(unwrapped, str):
                        response_text = unwrapped
                    else:
                        # If unwrapped to dict/list, re-serialize for parsing
                        response_text = json.dumps(unwrapped)
                    logger.debug(f"{call_site}: Unwrapped {provider} CLI JSON response")
            except json.JSONDecodeError:
                # Not valid JSON, use response as-is
                pass

        # ISSUE-HYBRID-045: llm_call event is emitted by subprocess_runner
        # (authoritative source with full field coverage). Duplicate emission
        # removed to prevent paired events in telemetry.

        return response_text

    def _validate_analyze_params(
        self,
        item_id: str,
        timeout_ms: int,
    ) -> None:
        """Validate analyze() parameters (ADR-042 Contract 3).

        Agent implementations SHOULD call this at the start of their
        analyze() method to ensure parameter contracts are enforced.

        Args:
            item_id: Plan item ID to validate
            timeout_ms: Timeout value to validate

        Raises:
            ValueError: If item_id is empty or timeout_ms is invalid
        """
        if not item_id or not item_id.strip():
            msg = "item_id must be non-empty string"
            raise ValueError(msg)

        if timeout_ms <= 0:
            msg = f"timeout_ms must be positive, got {timeout_ms}"
            raise ValueError(msg)

    def _resolve_timeout_ms(self, timeout_ms: int | None) -> int:
        """Resolve timeout_ms to a concrete value.

        Uses config-based timeout from get_review_agent_timeout() if None provided.

        Args:
            timeout_ms: Explicit timeout in milliseconds, or None to use config default

        Returns:
            Timeout in milliseconds (config default converted from seconds if None was passed)
        """
        if timeout_ms is None:
            timeout_seconds = int(get_review_agent_timeout())
            return timeout_seconds * 1000
        return timeout_ms

    def _is_ignored_path(self, path: Path) -> bool:
        """Check if a path should be ignored based on IGNORE_DIRS and IGNORE_DIR_SUFFIXES.

        Use this method when doing manual rglob() scans to ensure consistent
        filtering across all agents. Prevents scanning into virtual environments,
        node_modules, build directories, and other infrastructure paths.

        Only checks paths RELATIVE to working_dir. Parent directories outside
        the working directory do not affect filtering. This prevents incorrectly
        filtering all files when the working directory itself is named "build",
        ".cache", etc. (ISSUE-001).

        Args:
            path: Path to check (can be relative or absolute)

        Returns:
            True if any path component (relative to working_dir) matches an ignored
            directory name or ends with an ignored suffix (e.g., .egg-info)
        """
        try:
            # Only check relative path components within working_dir
            rel_path = path.relative_to(self._working_dir)
            if self._matches_ignore_pattern(rel_path):
                return True
            for part in rel_path.parts:
                # Exact match
                if part in self.IGNORE_DIRS:
                    return True
                # Suffix match (e.g., *.egg-info)
                if part.endswith(self.IGNORE_DIR_SUFFIXES):
                    return True
            return False
        except ValueError:
            # Path is outside working_dir, don't filter
            return False

    @abstractmethod
    def analyze(
        self,
        item_id: str,
        changed_files: list[str] | None = None,
        timeout_ms: int | None = None,
    ) -> AgentResult:
        """Analyze code and return results.

        This is the main entry point for agent execution. Agents should
        analyze the code in working_dir and return issues and scores.

        Parameter Contracts (ADR-042):
            item_id: MUST be non-empty string. Typically matches [A-Z]+-[0-9]+ format.
            changed_files: If None, analyzes all files in working_dir.
                          If empty list, returns empty result.
                          If non-empty, only analyzes specified files.
                          Files are passed to get_files_to_analyze() which respects
                          agent-specific extensions filtering.
            timeout_ms: If None, uses config-based timeout via get_review_agent_timeout().
                       If provided, MUST be positive integer. Typical range: [5000-300000].
                       Applies to entire analysis, not per-file.

        Parameter Interactions:
            - changed_files paths are resolved relative to working_dir
            - Extensions filtering (agent-specific) applies to changed_files
            - timeout_ms enforced by agent implementation (may vary)
            - When timeout_ms is None, resolved via orchestration.timeouts.review_agent_s config

        Args:
            item_id: Plan item ID being reviewed
            changed_files: List of files that changed (optional, for focused review)
            timeout_ms: Maximum execution time in milliseconds (None = use config default)

        Returns:
            AgentResult with issues and scores

        Raises:
            ValueError: If item_id is empty or timeout_ms <= 0
            TimeoutError: If analysis exceeds timeout_ms
            Exception: If analysis fails
        """

    def get_files_to_analyze(
        self,
        changed_files: list[str] | None = None,
        extensions: list[str] | None = None,
        exclude_binary: bool = True,
    ) -> list[Path]:
        """Get list of files to analyze.

        Parameter Contracts (ADR-042):
            changed_files: If None, scans entire working_dir recursively.
                          If provided, only these files are considered (scope constraint).
                          Paths can be relative or absolute.
                          Non-existent files are silently skipped.
            extensions: DEPRECATED - use exclude_binary instead.
                       If None, uses blocklist approach (exclude binary files).
                       If provided (e.g., [".py", ".js"]), uses allowlist approach.
                       MUST be applied in BOTH changed_files and directory scan paths.
            exclude_binary: If True (default), excludes binary/generated files using
                           BINARY_EXTENSIONS blocklist. This allows all code file types
                           (.py, .js, .go, .yaml, Dockerfile, etc.) while filtering out
                           non-analyzable files (.pyc, .png, .exe, etc.).
                           Ignored if extensions is provided (allowlist takes precedence).

        Parameter Interactions:
            - When changed_files provided: constrains scope to those files only
            - When extensions provided: uses allowlist (legacy behavior)
            - When exclude_binary=True (default): uses blocklist approach
            - Filtering is consistent across all code paths (ISSUE-CLI-013 fix)

        Args:
            changed_files: If provided, only analyze these files (scope constraint)
            extensions: DEPRECATED. If provided, filter by file extensions (allowlist)
            exclude_binary: If True, exclude binary files using blocklist (default: True)

        Returns:
            List of file paths to analyze (all paths are absolute Path objects)
        """
        if changed_files is not None:
            # Short-circuit: empty list means no files to analyze
            if not changed_files:
                return []

            # Filter to existing files, respecting IGNORE_DIRS
            files = []
            for f in changed_files:
                path = self._working_dir / f if not Path(f).is_absolute() else Path(f)
                if path.exists() and path.is_file():
                    # Skip ignored directories (e.g., .obra/, node_modules/)
                    # ISSUE-REVIEW-AGENTS-002: changed_files path was missing this filter
                    if self._is_ignored_path(path):
                        continue
                    # Allowlist takes precedence (legacy behavior)
                    if extensions is not None:
                        if path.suffix not in extensions:
                            continue
                    # Otherwise use blocklist if enabled
                    elif exclude_binary and self._is_binary_file(path):
                        continue
                    files.append(path)
            return files

        # Scan all files in working directory
        # Short-circuit: empty extensions list means nothing matches
        if extensions is not None and not extensions:
            return []

        files = []

        for path in self._working_dir.rglob("*"):
            # Skip ignored directories (uses class constant IGNORE_DIRS)
            if self._is_ignored_path(path):
                continue

            if not path.is_file():
                continue

            # Allowlist takes precedence (legacy behavior)
            if extensions is not None:
                if path.suffix not in extensions:
                    continue
            # Otherwise use blocklist if enabled
            elif exclude_binary and self._is_binary_file(path):
                continue

            files.append(path)

        return files

    def _is_binary_file(self, path: Path) -> bool:
        """Check if a file should be excluded as binary/generated.

        Uses BINARY_EXTENSIONS blocklist to identify files that cannot be
        meaningfully analyzed by review agents.

        Args:
            path: Path to check

        Returns:
            True if file should be excluded (is binary/generated)
        """
        # Check suffix against blocklist
        suffix = path.suffix.lower()
        if suffix in BINARY_EXTENSIONS:
            return True

        # Check for compound extensions like .min.js, .min.css
        name_lower = path.name.lower()
        return bool(name_lower.endswith((".min.js", ".min.css")))

    def read_file(self, path: Path) -> str:
        """Read file contents safely.

        Performs layered checks before reading:
        1. Hard size limit (skip files > MAX_FILE_SIZE_BYTES, almost certainly not source)
        2. Warn threshold (log warning for files > FILE_SIZE_WARN_BYTES, but still read)
        3. Binary detection (null bytes in first BINARY_CHECK_BYTES)
        4. UTF-8 decode with graceful fallback

        Args:
            path: Path to file

        Returns:
            File contents or empty string if unreadable (too large, binary, or error)
        """
        try:
            # Check file size first
            file_size = path.stat().st_size

            # Hard limit - skip files that are almost certainly not source code
            if file_size > MAX_FILE_SIZE_BYTES:
                logger.debug(f"Skipping very large file ({file_size:,} bytes): {path}")
                return ""

            # Warn threshold - large but possibly legitimate, let downstream handle
            if file_size > FILE_SIZE_WARN_BYTES:
                logger.warning(
                    f"Reading large file ({file_size:,} bytes): {path} - "
                    "may exceed LLM context limits"
                )

            # Proactive binary detection: check for null bytes in first chunk
            # This is faster than attempting full UTF-8 decode on large binaries
            with path.open("rb") as f:
                chunk = f.read(BINARY_CHECK_BYTES)
                if b"\x00" in chunk:
                    logger.debug(f"Skipping binary file (null bytes detected): {path}")
                    return ""

            # Now safe to read as text
            return path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            # Binary file slipped through null byte check (rare but possible)
            logger.debug(f"Skipping binary file (decode failed): {path}")
            return ""
        except Exception as e:
            # Unexpected error (permissions, missing file, etc.)
            logger.warning(f"Could not read {path}: {e}")
            return ""

    def _generate_issue_id(self, prefix: str, index: int) -> str:
        """Generate unique issue ID.

        Args:
            prefix: Agent prefix (e.g., "SEC", "TEST")
            index: Issue index

        Returns:
            Unique issue ID (e.g., "SEC-001")
        """
        return f"{prefix}-{index:03d}"

    def _generate_stable_issue_id(self, prefix: str, issue: dict[str, Any]) -> str:
        """Generate a content-stable issue ID based on issue details.

        Args:
            prefix: Agent prefix (e.g., "SEC", "TEST")
            issue: Issue dict with file/line/description details

        Returns:
            Stable issue ID (e.g., "SEC-a1b2c3d4e5f6")
        """
        file_path = issue.get("file_path") or issue.get("file") or ""
        line_number = issue.get("line_number") or issue.get("line") or ""
        description = issue.get("description") or ""
        description = description.strip().lower()[:100]

        content = f"{file_path}|{line_number}|{description}"
        digest = hashlib.sha256(content.encode("utf-8")).hexdigest()[:12]
        issue_id = f"{prefix}-{digest}"

        existing = self._issue_id_seen.get(issue_id)
        if existing and existing != content:
            suffix = 2
            while f"{issue_id}-{suffix}" in self._issue_id_seen:
                suffix += 1
            issue_id = f"{issue_id}-{suffix}"

        self._issue_id_seen[issue_id] = content
        return issue_id

    def is_test_file(self, path: Path, patterns: list[str] | None = None) -> bool:
        """Check if a file is a test file.

        Parameter Contracts (ADR-042):
            path: MUST be a concrete file path. The file is not required to exist,
                  but path.name and path.parts must be valid for matching.
            patterns: Optional glob patterns. If None, uses default patterns.
                     If provided, MUST be non-empty strings suitable for fnmatch.

        Parameter Interactions:
            - patterns overrides default patterns
            - Directory checks ("tests"/"test") apply regardless of patterns

        Args:
            path: Path to check
            patterns: Optional list of glob patterns for test files

        Returns:
            True if this is a test file
        """
        import fnmatch

        name = path.name
        test_patterns = patterns or ["test_*", "*_test.*", "*.test.*", "*.spec.*"]
        if any(fnmatch.fnmatch(name, pattern) for pattern in test_patterns):
            return True
        # Check if in a tests directory
        return bool("tests" in path.parts or "test" in path.parts)

    def is_excluded_file(self, path: Path) -> bool:
        """Check if a file should be excluded from analysis.

        Checks against common infrastructure files that shouldn't be
        analyzed as application code (conftest.py, setup.py, migrations, etc.)

        Args:
            path: Path to check

        Returns:
            True if file should be excluded
        """
        import fnmatch

        # Check exact filename matches
        if path.name in EXCLUDED_FILES:
            return True

        # Check patterns
        rel_path = str(path)
        if self._matches_ignore_pattern(path):
            return True
        return any(fnmatch.fnmatch(rel_path, pattern) for pattern in EXCLUDED_PATTERNS)

    def parse_structured_response(
        self,
        response: str,
        prefix: str = "ISSUE",
    ) -> list[AgentIssue]:
        """Parse LLM structured text response into AgentIssue list.

        Parses responses in the structured text format used by all agent prompts.
        The format uses `---` as delimiter between issues.

        Expected format per issue:
            ISSUE: <ID like SEC-001, TEST-002, etc.>
            FILE: <exact file path>
            LINE: <line number>
            SEVERITY: <S0=critical, S1=high, S2=medium, S3=low>
            CONFIDENCE: <high/medium/low>
            WHY_BUG: <explain why this is wrong>
            FAILING_SCENARIO: <concrete input, state, or sequence that triggers>
            SUGGESTED_FIX: <minimal code change or test>
            NEEDS_DEEP_REVIEW: <yes/no>
            ---

        Parameter Contracts (ADR-042):
            response: Raw LLM response text. Empty or whitespace-only yields [].
            prefix: Fallback issue ID prefix used when ISSUE field is missing.
                    MUST be non-empty string; typical values: "SEC", "TEST".

        Parameter Interactions:
            - If response is empty, no parsing occurs and [] is returned.
            - prefix only applies when ISSUE is missing in a block.

        Args:
            response: Raw LLM response text
            prefix: Issue ID prefix for fallback generation (e.g., "SEC", "TEST")

        Returns:
            List of AgentIssue objects. Empty list if response is empty or
            contains no parseable issues.
        """
        if not response or not response.strip():
            return []

        issues: list[AgentIssue] = []
        # Split by delimiter (--- on its own line)
        blocks = response.split("\n---")

        # Severity mapping
        severity_map = {
            "s0": Priority.P0,
            "critical": Priority.P0,
            "s1": Priority.P1,
            "high": Priority.P1,
            "s2": Priority.P2,
            "medium": Priority.P2,
            "s3": Priority.P3,
            "low": Priority.P3,
        }

        for _idx, block in enumerate(blocks):
            block = block.strip()
            if not block:
                continue

            # Parse fields from block
            fields = self._parse_block_fields(block)

            # Skip blocks without minimum required fields
            if not fields.get("issue") and not fields.get("file"):
                continue

            # Map severity string to Priority enum
            severity_str = fields.get("severity", "s2").lower()
            priority = severity_map.get(severity_str, Priority.P2)

            # Parse line number safely
            line_num = None
            if fields.get("line"):
                with contextlib.suppress(ValueError, TypeError):
                    line_num = int(fields["line"])

            # Generate issue ID if not provided
            issue_id = fields.get("issue") or self._generate_stable_issue_id(prefix, fields)

            # Build description from WHY_BUG if available
            description = fields.get("why_bug", "")
            if fields.get("failing_scenario"):
                description += f"\n\nFailing scenario: {fields['failing_scenario']}"

            # Trace parsed fields for debugging
            logger.debug(
                f"Parsed issue: id={issue_id}, file={fields.get('file')}, "
                f"line={line_num}, fields={list(fields.keys())}"
            )

            target_paths_raw = fields.get("target_paths", "")
            target_paths = []
            if target_paths_raw:
                target_paths = [
                    path.strip() for path in re.split(r"[,\n;]+", target_paths_raw) if path.strip()
                ]

            issues.append(
                AgentIssue(
                    id=issue_id,
                    title=fields.get("why_bug", "Issue detected")[:100],
                    description=description,
                    priority=priority,
                    file_path=fields.get("file"),
                    line_number=line_num,
                    dimension=fields.get("dimension", ""),
                    suggestion=fields.get("suggested_fix", ""),
                    issue_type=fields.get("issue_type") or None,
                    target_test_file=fields.get("target_test_file") or None,
                    target_paths=target_paths or None,
                    test_name=fields.get("test_name") or None,
                    arrange=fields.get("arrange") or None,
                    act=fields.get("act") or None,
                    assert_steps=fields.get("assert") or None,
                    issue_kind=fields.get("issue_kind") or "defect",
                    resolution_path=fields.get("resolution_path") or "code_and_tests",
                    verification_scope=fields.get("verification_scope") or "auto",
                    metadata={
                        "confidence": fields.get("confidence", "medium"),
                        "needs_deep_review": fields.get("needs_deep_review", "no").lower() == "yes",
                        "failing_scenario": fields.get("failing_scenario", ""),
                        "issue_type": fields.get("issue_type", ""),
                        "target_test_file": fields.get("target_test_file", ""),
                        "target_paths": target_paths,
                        "test_name": fields.get("test_name", ""),
                        "arrange": fields.get("arrange", ""),
                        "act": fields.get("act", ""),
                        "assert": fields.get("assert", ""),
                        # FIX-RAW-FINDING-001: Preserve full review agent output to avoid
                        # lossy reconstruction in fix prompts. Frontier LLMs benefit from
                        # seeing the complete finding context including code examples.
                        "raw_finding": block.strip(),
                    },
                )
            )

        # Safety net: warn if response contains issue-like markers but nothing parsed.
        # Catches future formatting variants the parser doesn't handle yet.
        if not issues and response:
            marker_pattern = re.compile(
                r"\b(QUAL|TEST|SEC|PERF|ISSUE)[-_]\d{3}\b", re.IGNORECASE
            )
            if marker_pattern.search(response):
                logger.warning(
                    f"Response contains issue markers but parser extracted 0 issues "
                    f"(prefix={prefix}). Possible formatting mismatch — "
                    f"first 200 chars: {response[:200]!r}"
                )

        return issues

    def _parse_block_fields(self, block: str) -> dict[str, str]:
        """Parse key-value fields from a structured response block.

        Handles multi-line values by collecting text until the next field.

        Args:
            block: Single issue block text

        Returns:
            Dictionary of field name to value
        """
        fields: dict[str, str] = {}
        current_field: str | None = None
        current_value: list[str] = []

        # Known field names (case-insensitive)
        known_fields = {
            "issue",
            "issue_type",
            "file",
            "line",
            "severity",
            "confidence",
            "why_bug",
            "failing_scenario",
            "suggested_fix",
            "needs_deep_review",
            "dimension",
            "target_test_file",
            "target_paths",
            "test_name",
            "arrange",
            "act",
            "assert",
            "issue_kind",
            "resolution_path",
            "verification_scope",
        }

        for line in block.split("\n"):
            line = line.strip()
            if not line:
                continue

            # Strip markdown bold formatting for field matching.
            # LLMs sometimes wrap field headers in **bold** (e.g. **ISSUE: QUAL-001**).
            # Use cleaned version for matching/extraction, original for continuation.
            match_line = line
            if line.startswith("*"):
                match_line = line.replace("*", "").strip()

            # Check if line starts a new field
            field_found = False
            for field_name in known_fields:
                # Match "FIELD:" or "FIELD :" patterns (case-insensitive)
                upper_field = field_name.upper()
                if match_line.upper().startswith(f"{upper_field}:") or match_line.upper().startswith(
                    f"{upper_field} :"
                ):
                    # Save previous field
                    if current_field:
                        fields[current_field] = " ".join(current_value).strip()

                    # Start new field
                    current_field = field_name
                    # Extract value after colon (from cleaned line)
                    colon_idx = match_line.find(":")
                    current_value = [match_line[colon_idx + 1 :].strip()] if colon_idx >= 0 else []
                    field_found = True
                    break

            if not field_found and current_field:
                # Continue multi-line value (preserve original formatting)
                current_value.append(line)

        # Save last field
        if current_field:
            fields[current_field] = " ".join(current_value).strip()

        return fields

    # Paths that indicate sensitive code requiring escalation
    ESCALATION_PATHS: frozenset[str] = frozenset(
        {
            "auth",
            "authentication",
            "authorization",
            "payment",
            "payments",
            "billing",
            "tenant",
            "tenants",
            "migrations",
            "security",
            "crypto",
            "encryption",
        }
    )

    # Keywords in content that indicate sensitive code
    ESCALATION_KEYWORDS: frozenset[str] = frozenset(
        {
            # Authentication/Authorization
            "authenticate",
            "authorize",
            "authorization",
            "jwt",
            "oauth",
            "token",
            "session",
            "login",
            "logout",
            "password",
            "credential",
            # Payment/Financial
            "stripe",
            "paypal",
            "payment",
            "charge",
            "refund",
            "billing",
            "invoice",
            "credit_card",
            "creditcard",
            # Concurrency (race conditions)
            "asyncio.lock",
            "threading.lock",
            "multiprocessing.lock",
            "mutex",
            "semaphore",
            "atomic",
            "race_condition",
            # Security/Crypto
            "encrypt",
            "decrypt",
            "hash",
            "secret",
            "private_key",
            "privatekey",
            "api_key",
            "apikey",
            # Database migrations
            "alembic",
            "migrate",
            "migration",
            "schema",
            # Multi-tenancy
            "tenant_id",
            "tenant",
            "isolation",
        }
    )

    def _needs_escalation(
        self,
        file_path: Path | str | None = None,
        content: str | None = None,
    ) -> bool:
        """Check if code requires escalation to higher-tier LLM.

        Detects sensitive code patterns that benefit from deeper analysis:
        - Authentication/authorization logic
        - Payment processing
        - Concurrency primitives (race condition risk)
        - Cryptographic operations
        - Multi-tenant isolation
        - Database migrations

        Args:
            file_path: File path to check (checks directory components)
            content: File content to check (scans for keywords)

        Returns:
            True if sensitive code detected, requiring escalation
        """
        # Check file path components
        if file_path:
            path = Path(file_path) if isinstance(file_path, str) else file_path
            # Check each path component
            for part in path.parts:
                if part.lower() in self.ESCALATION_PATHS:
                    logger.debug(f"Escalation triggered by path component: {part}")
                    return True

        # Check content for keywords
        if content:
            content_lower = content.lower()
            for keyword in self.ESCALATION_KEYWORDS:
                if keyword in content_lower:
                    logger.debug(f"Escalation triggered by keyword: {keyword}")
                    return True

        return False


__all__ = [
    "BINARY_CHECK_BYTES",
    "BINARY_EXTENSIONS",
    "EXCLUDED_FILES",
    "EXCLUDED_PATTERNS",
    "FILE_SIZE_WARN_BYTES",
    "MAX_FILE_SIZE_BYTES",
    "AgentIssue",
    "AgentResult",
    "BaseAgent",
]
