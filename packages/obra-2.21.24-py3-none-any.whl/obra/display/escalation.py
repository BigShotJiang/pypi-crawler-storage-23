"""Unified escalation rendering for all client-side display surfaces.

Consolidates escalation display logic previously scattered across
cli.py (_build_escalation_callback) and orchestrator.py (_handle_escalation)
into a single renderer class. All output goes through the injected
Rich Console so tests can capture output by monkeypatching.
"""

from __future__ import annotations

import re
from typing import Any

from rich.console import Console

from obra.api.protocol import EscalationNotice


class EscalationRenderer:
    """Renders escalation notices to a Rich Console.

    All output uses self.console.print() with Rich markup so tests
    can capture output by injecting a Console(file=StringIO()).

    Args:
        console: Rich Console instance for output.
    """

    def __init__(self, console: Console) -> None:
        self.console = console

    def render_full(self, notice: EscalationNotice) -> None:
        """Render complete escalation for interactive prompts.

        Calls render_header, then conditionally renders each
        diagnostic section based on available data.
        """
        self.render_header(notice)

        raw_invariant_errors = (
            notice.invariant_errors
            if isinstance(notice.invariant_errors, list)
            else []
        )
        invariant_errors = [
            str(error).strip()
            for error in raw_invariant_errors
            if str(error).strip()
        ]
        if invariant_errors:
            self.render_invariant_errors(invariant_errors)

        reason_code = str(getattr(notice, "reason_code", "") or "").strip()
        is_revision_merge_rejected = reason_code == "revision_merge_rejected"

        if is_revision_merge_rejected:
            self.render_revision_merge_diagnostic(notice)
        elif notice.repair_attempt_history:
            raw_repair = (
                notice.repair_attempt_history
                if isinstance(notice.repair_attempt_history, list)
                else []
            )
            valid_repair = [e for e in raw_repair if isinstance(e, dict)]
            if valid_repair:
                self.render_repair_history(valid_repair)

        blocking_issues = notice.blocking_issues
        if not isinstance(blocking_issues, list):
            blocking_issues = []
        valid_issues = [i for i in blocking_issues if isinstance(i, dict)]
        if valid_issues:
            self.render_blocking_issues(valid_issues)

        convergence_diagnostic = (
            notice.convergence_diagnostic
            if isinstance(notice.convergence_diagnostic, dict)
            else {}
        )
        if convergence_diagnostic:
            self.render_convergence_diagnostic(convergence_diagnostic)

        if notice.iteration_history:
            self.render_iteration_history(notice.iteration_history)

    def render_summary(self, notice: EscalationNotice) -> None:
        """Compact rendering for sessions show.

        Shows reason in yellow, blocking issue count, and options list.
        """
        reason_value = str(getattr(notice.reason, "value", notice.reason)).strip()
        self.console.print(f"  [yellow]{reason_value}[/yellow]")

        blocking_issues = notice.blocking_issues
        if isinstance(blocking_issues, list):
            valid_issues = [i for i in blocking_issues if isinstance(i, dict)]
            if valid_issues:
                self.console.print(f"  Blocking issues: {len(valid_issues)}")

        if notice.options:
            for opt in notice.options:
                if not isinstance(opt, dict):
                    continue
                opt_id = opt.get("id", "")
                label = opt.get("label", "")
                description = opt.get("description", "")
                self.console.print(f"    \\[{opt_id}] {label}: {description}")

    def render_header(self, notice: EscalationNotice) -> None:
        """Print escalation header with reason and detail."""
        reason_value = str(getattr(notice.reason, "value", notice.reason)).strip()
        reason_code = str(getattr(notice, "reason_code", "") or "").strip()

        display_reason = reason_code or reason_value or "blocked"
        self.console.print(
            f"[bold yellow]Warning: [/bold yellow]Escalation: {display_reason}"
        )

        reason_text = str(getattr(notice, "reason_text", "") or "").strip()
        if reason_text:
            self.console.print(f"  Detail: {reason_text}")

        if reason_code and reason_code != display_reason:
            self.console.print(f"  [dim]Code: {reason_code}[/dim]")

    def render_blocking_issues(self, issues: list[dict[str, Any]]) -> None:
        """Render blocking issues list (max 5)."""
        valid = [i for i in issues if isinstance(i, dict)]
        if not valid:
            return
        self.console.print(f"  Blocking issues: {len(valid)}")
        for issue in valid[:5]:
            priority = issue.get("priority", "P3")
            description = issue.get("description") or "(no description)"
            self.console.print(f"    - \\[{priority}] {description}")

    def render_convergence_diagnostic(self, diagnostic: dict[str, Any]) -> None:
        """Render convergence diagnostic data."""
        self.console.print("  Convergence diagnostic:")

        raw_sizes = diagnostic.get("per_cycle_blocking_sizes", {})
        if isinstance(raw_sizes, dict) and raw_sizes:
            sorted_sizes = sorted(
                (
                    (str(iteration), int(size))
                    for iteration, size in raw_sizes.items()
                ),
                key=lambda item: (
                    int(item[0]) if item[0].isdigit() else 10_000_000,
                    item[0],
                ),
            )
            size_summary = ", ".join(
                f"{iteration}:{size}" for iteration, size in sorted_sizes
            )
            self.console.print(f"    - Blocking sizes by cycle: {size_summary}")

        raw_persisted = diagnostic.get("persisted_issues", [])
        persisted_issues = (
            [str(issue_id) for issue_id in raw_persisted if str(issue_id).strip()]
            if isinstance(raw_persisted, list)
            else []
        )
        if persisted_issues:
            self.console.print(
                "    - Persisted issues: "
                + ", ".join(persisted_issues[:5])
                + (" ..." if len(persisted_issues) > 5 else "")
            )

        raw_appeared = diagnostic.get("appeared_issues", [])
        appeared_issues = (
            [str(issue_id) for issue_id in raw_appeared if str(issue_id).strip()]
            if isinstance(raw_appeared, list)
            else []
        )
        if appeared_issues:
            self.console.print(
                "    - Appeared during stale window: "
                + ", ".join(appeared_issues[:5])
                + (" ..." if len(appeared_issues) > 5 else "")
            )

    def render_invariant_errors(self, errors: list[str]) -> None:
        """Render plan integrity violation errors (max 5)."""
        clean = [str(e).strip() for e in errors if str(e).strip()]
        if not clean:
            return
        self.console.print(f"  Plan integrity violations ({len(clean)}):")
        for error in clean[:5]:
            self.console.print(f"    - {error}")

    def render_repair_history(self, history: list[dict[str, Any]]) -> None:
        """Render repair attempt history (last 2 entries)."""
        valid = [e for e in history if isinstance(e, dict)]
        if not valid:
            return
        self.console.print(f"  Repair attempts: {len(valid)}")
        for attempt in valid[-2:]:
            outcome = str(attempt.get("outcome", "unknown") or "unknown")
            self.console.print(f"    - {outcome}")

    def render_iteration_history(self, history: list[dict[str, Any]]) -> None:
        """Render iteration history summary."""
        for entry in history:
            if not isinstance(entry, dict):
                continue
            idx = entry.get("iteration", "?")
            validated = entry.get("validated_count")
            total = entry.get("total_items")
            if validated is not None and total is not None:
                self.console.print(f"  Iteration {idx}: {validated}/{total} validated")
            else:
                self.console.print(f"  Iteration {idx}")

    def render_options(self, options: list[dict[str, Any]]) -> None:
        """Render available escalation options."""
        for opt in options:
            if not isinstance(opt, dict):
                continue
            opt_id = opt.get("id") or opt.get("choice", "")
            label = opt.get("label", "")
            description = opt.get("description", "")
            self.console.print(f"    \\[{opt_id}] {label}: {description}")

    def render_revision_merge_diagnostic(self, notice: EscalationNotice) -> None:
        """Render revision merge rejection diagnostics.

        Extracts invariant names and offending item IDs from error strings,
        then shows the last repair outcome.
        """
        raw_invariant_errors = (
            notice.invariant_errors
            if isinstance(notice.invariant_errors, list)
            else []
        )
        invariant_errors = [
            str(e).strip() for e in raw_invariant_errors if str(e).strip()
        ]

        invariant_names = sorted(
            {
                match.group(1)
                for error in invariant_errors
                for match in [re.search(r"\[([A-Z_]+)\]", error)]
                if match
            }
        )

        offending_item_ids = sorted(
            {
                token
                for error in invariant_errors
                for token in re.findall(
                    r"[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+)+",
                    error,
                )
            }
        )

        raw_repair = (
            notice.repair_attempt_history
            if isinstance(notice.repair_attempt_history, list)
            else []
        )
        repair_history = [e for e in raw_repair if isinstance(e, dict)]

        self.console.print("  Revision merge rejection diagnostics:")
        if invariant_names:
            self.console.print("    - Invariants: " + ", ".join(invariant_names))
        if offending_item_ids:
            self.console.print(
                "    - Offending item IDs: "
                + ", ".join(offending_item_ids[:10])
                + (" ..." if len(offending_item_ids) > 10 else "")
            )
        if repair_history:
            last_outcome = str(
                repair_history[-1].get("outcome", "unknown") or "unknown"
            )
            self.console.print(f"    - Last repair outcome: {last_outcome}")
