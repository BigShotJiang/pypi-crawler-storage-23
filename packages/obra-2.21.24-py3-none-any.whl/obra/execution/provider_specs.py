"""Provider-specific spec builders for the typed LLM pipeline.

Extracts all provider-specific command-building logic from obra/config/llm.py
into focused builder functions. Each builder translates a CommandSpec into a
ProviderSpec with provider-specific argv, environment, and execution details.

All platform-specific decisions (path format, encoding, preexec_fn) are received
via EnvironmentProfile — no direct OS detection calls in this module.

Related:
    - docs/design/briefs/ECL_PHASE2_TYPED_PIPELINE_BRIEF.md
    - obra/execution/pipeline_types.py (dataclass definitions)
    - obra/execution/os_compat.py (EnvironmentProfile)
"""

from __future__ import annotations

import uuid

from obra.config.llm import get_llm_cli
from obra.execution.os_compat import EnvironmentProfile
from obra.execution.pipeline_types import CommandSpec, ProviderSpec


def build_anthropic_spec(
    cmd_spec: CommandSpec,
    profile: EnvironmentProfile,
) -> ProviderSpec:
    """Build ProviderSpec for Anthropic Claude Code CLI.

    Extracts logic from obra/config/llm.py lines 1638-1673.

    Args:
        cmd_spec: High-level command specification with user intent
        profile: Resolved OS environment profile for platform-specific decisions

    Returns:
        ProviderSpec with Anthropic-specific argv and execution configuration

    Notes:
        - Text mode uses --print for JSON output (no file writing)
        - Execute mode allows file operations (no --print)
        - Thinking level is binary: on/off (alwaysThinkingEnabled)
        - Session isolation via --no-session-persistence and fresh UUID
        - Prompt delivery is always 'file' for Anthropic
    """
    args = []

    # Mode-aware argument building
    if cmd_spec.mode == "text":
        args.append("--print")  # Text generation mode (prevents code writing)
        # Only add --output-format json when JSON is expected
        if cmd_spec.response_format == "json":
            args.extend(["--output-format", "json"])

    # Execute mode: No --print flag - allows Claude Code to write files
    args.append("--dangerously-skip-permissions")

    # Model selection
    if cmd_spec.model and cmd_spec.model != "default":
        args.extend(["--model", cmd_spec.model])

    # Thinking configuration (binary: on/off)
    thinking_enabled = cmd_spec.reasoning_level != "off"
    args.extend(
        [
            "--settings",
            f'{{"alwaysThinkingEnabled": {str(thinking_enabled).lower()}}}',
        ]
    )

    # Context isolation flags to prevent cross-session pollution
    session_id = str(uuid.uuid4())
    args.extend(["--no-session-persistence"])  # Don't persist session state
    args.extend(["--session-id", session_id])  # Fresh session each invocation
    args.extend(["--setting-sources", ""])  # Block user-level settings pollution

    return ProviderSpec(
        argv=args,
        cli_executable=get_llm_cli("anthropic"),
        env_overrides={},  # No special env vars for Anthropic
        prompt_delivery="file",  # Anthropic always uses prompt files
        stdin_content=None,  # Not used for Anthropic
        use_absolute_paths=profile.use_absolute_paths,  # OS default (False on Tier 1)
        provider_meta={
            "thinking_enabled": thinking_enabled,
            "session_id": session_id,
        },
        spec_id=cmd_spec.spec_id,  # Preserve correlation ID
    )


def build_google_spec(
    cmd_spec: CommandSpec,
    profile: EnvironmentProfile,
) -> ProviderSpec:
    """Build ProviderSpec for Google Gemini CLI.

    Extracts logic from obra/config/llm.py lines 1675-1699.

    Args:
        cmd_spec: High-level command specification with user intent
        profile: Resolved OS environment profile for platform-specific decisions

    Returns:
        ProviderSpec with Google-specific argv and execution configuration

    Notes:
        - Text mode uses --sandbox=none to disable tools (prevents hijacking)
        - Execute mode uses --sandbox=permissive with --yolo for auto-approval
        - No reasoning level support (Google doesn't support it)
        - Model 'default' and 'auto' both mean let Gemini choose (no --model flag)
        - Prompt delivery is always 'file' for Google
    """
    args = []

    # Mode-aware sandbox configuration
    if cmd_spec.mode == "text":
        # Text generation mode - disable tools
        args.append("--sandbox=none")
        # Only add --output-format json when caller expects JSON response
        if cmd_spec.response_format == "json":
            args.extend(["--output-format", "json"])
        sandbox_mode = "none"
    else:
        # Execute mode - MUST have --sandbox=permissive for file operations
        # and --yolo for auto-approval (Gemini waits for approval in headless mode)
        args.append("--sandbox=permissive")
        args.append("--yolo")
        sandbox_mode = "permissive"

    # Model selection: "default" and "auto" both mean let Gemini choose
    if cmd_spec.model and cmd_spec.model not in ("default", "auto"):
        args.extend(["--model", cmd_spec.model])

    # Gemini CLI requires -p for headless mode. Without it, Gemini enters
    # interactive TUI and hangs. Must be last in argv so the prompt argument
    # appended by build_exec_spec() becomes -p's value.
    args.append("-p")

    return ProviderSpec(
        argv=args,
        cli_executable=get_llm_cli("google"),
        env_overrides={},  # No special env vars for Google
        prompt_delivery="file",  # Google always uses prompt files
        stdin_content=None,  # Not used for Google
        use_absolute_paths=profile.use_absolute_paths,  # OS default (False on Tier 1)
        provider_meta={"sandbox_mode": sandbox_mode},
        spec_id=cmd_spec.spec_id,  # Preserve correlation ID
    )


def build_openai_spec(
    cmd_spec: CommandSpec,
    profile: EnvironmentProfile,
) -> ProviderSpec:
    """Build ProviderSpec for OpenAI Codex CLI.

    Merges logic from BOTH build_llm_args() (lines 1701-1734) AND
    _build_codex_cmd() in subprocess_runner.py (lines 649-698).
    The _build_codex_cmd() output is what actually executes for Codex.

    Args:
        cmd_spec: High-level command specification with user intent
        profile: Resolved OS environment profile (ignored for OpenAI)

    Returns:
        ProviderSpec with OpenAI-specific argv and execution configuration

    Notes:
        - Base command starts with 'exec', '-C' + cwd
        - Text mode without bypass: --sandbox read-only
        - Text mode with bypass: --dangerously-bypass-approvals-and-sandbox
        - Execute mode without bypass: --sandbox workspace-write
        - Execute mode with bypass: --dangerously-bypass-approvals-and-sandbox
        - approval_mode from codex_config: --config defaults.approval_mode={mode}
        - skip_git_check from codex_config: --skip-git-repo-check
        - provider_reasoning_level: --config model_reasoning_effort={level}
        - use_absolute_paths=True (provider requirement, resolves BUG-c2e0a391)
    """
    import os

    # Extract Codex-specific config
    codex_config = cmd_spec.codex_config or {}
    bypass_sandbox = bool(codex_config.get("bypass_sandbox", False))
    approval_mode = codex_config.get("approval_mode")
    skip_git_check = bool(codex_config.get("skip_git_check", False))

    # Base command: exec -C <cwd>
    args = [
        "exec",
        "-C",
        str(cmd_spec.cwd),
    ]

    # Mode-aware sandbox configuration
    if cmd_spec.mode == "text":
        if bypass_sandbox:
            args.append("--dangerously-bypass-approvals-and-sandbox")
        else:
            args.extend(["--sandbox", "read-only"])
            # Text mode can have approval_mode even without bypass
            if approval_mode:
                args.extend(["--config", f"defaults.approval_mode={approval_mode}"])
        sandbox_mode = "bypass" if bypass_sandbox else "read-only"
    else:  # execute mode
        if bypass_sandbox:
            args.append("--dangerously-bypass-approvals-and-sandbox")
        else:
            args.extend(["--sandbox", "workspace-write"])
            if approval_mode:
                args.extend(["--config", f"defaults.approval_mode={approval_mode}"])
        sandbox_mode = "bypass" if bypass_sandbox else "workspace-write"

    # Git check bypass
    if skip_git_check:
        args.append("--skip-git-repo-check")

    # Model selection
    if cmd_spec.model and cmd_spec.model not in ("default", "auto"):
        args.extend(["--model", cmd_spec.model])

    # Reasoning effort (provider-specific thinking level)
    if cmd_spec.provider_reasoning_level:
        args.extend(
            ["--config", f"model_reasoning_effort={cmd_spec.provider_reasoning_level}"]
        )

    # Prompt delivery: default to 'file' for safety
    # Inline optimization (for short text mode prompts) can be added later
    # when prompt content is available at execution time
    force_prompt_file = os.environ.get("OBRA_OPENAI_TEXT_FORCE_PROMPT_FILE") == "1"
    prompt_delivery = "file"
    if cmd_spec.mode == "text" and not force_prompt_file:
        # Note: actual inline delivery requires prompt length check (<=4000 chars)
        # This will be validated at execution time in build_exec_spec()
        prompt_delivery = "inline"

    return ProviderSpec(
        argv=args,
        cli_executable=get_llm_cli("openai"),
        env_overrides={},  # No special env vars for OpenAI
        prompt_delivery=prompt_delivery,
        stdin_content=None,  # Not used for OpenAI
        use_absolute_paths=True,  # Provider requirement (resolves BUG-c2e0a391)
        provider_meta={
            "bypass_sandbox": bypass_sandbox,
            "approval_mode": approval_mode,
            "sandbox_mode": sandbox_mode,
        },
        spec_id=cmd_spec.spec_id,  # Preserve correlation ID
    )


def build_default_spec(
    cmd_spec: CommandSpec,
    profile: EnvironmentProfile,
) -> ProviderSpec:
    """Build ProviderSpec for unknown/fallback providers (Ollama, etc).

    Extracts fallback logic from obra/config/llm.py line 1737.

    Args:
        cmd_spec: High-level command specification with user intent
        profile: Resolved OS environment profile for platform-specific decisions

    Returns:
        ProviderSpec with minimal fallback configuration

    Notes:
        - Produces minimal argv: ['--dangerously-skip-permissions']
        - Covers Ollama and any unknown provider string
        - Uses OS default path format (not provider-specific)
        - Prompt delivery is always 'file' for fallback providers
    """
    # Minimal fallback argv
    args = ["--dangerously-skip-permissions"]

    return ProviderSpec(
        argv=args,
        cli_executable=get_llm_cli(cmd_spec.provider),
        env_overrides={},  # No special env vars for fallback
        prompt_delivery="file",  # Always use prompt files for fallback
        stdin_content=None,  # Not used for fallback
        use_absolute_paths=profile.use_absolute_paths,  # OS default
        provider_meta={"fallback": True},
        spec_id=cmd_spec.spec_id,  # Preserve correlation ID
    )
