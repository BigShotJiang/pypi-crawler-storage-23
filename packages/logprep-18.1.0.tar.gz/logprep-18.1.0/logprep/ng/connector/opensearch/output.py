"""
OpensearchOutput
================

This section contains the connection settings for Opensearch, the default
index, the error index and a buffer size. Documents are sent in batches to Opensearch to reduce
the amount of times connections are created.

The documents desired index is the field :code:`_index` in the document. It is deleted afterwards.
If you want to send documents to data streams, you have to set the field :code:`_op_type: create` in
the document.

Example
^^^^^^^
..  code-block:: yaml
    :linenos:

    output:
      myopensearch_output:
        type: opensearch_output
        hosts:
            - 127.0.0.1:9200
        default_index: default_index
        error_index: error_index
        message_backlog_size: 10000
        timeout: 10000
        max_retries:
        user:
        secret:
        ca_cert: /path/to/cert.crt
"""

import logging
import ssl
import typing
from functools import cached_property
from typing import List, Optional

import opensearchpy as search
from attrs import define, field, validators
from opensearchpy import OpenSearchException, helpers
from opensearchpy.serializer import JSONSerializer

from logprep.abc.exceptions import LogprepException
from logprep.metrics.metrics import Metric
from logprep.ng.abc.event import Event
from logprep.ng.abc.output import Output

logger = logging.getLogger("OpenSearchOutput")


class BulkError(LogprepException):
    """Exception created when a bulk operation fails in Opensearch."""

    def __init__(
        self,
        message: str,
        status: str | None = None,
        exception: str | None = None,
        **kwargs,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.exception = exception

    def __str__(self) -> str:
        return f"BulkError: {self.message}, status_code: {self.status}, exception: {self.exception}"


class MSGPECSerializer(JSONSerializer):
    """A MSGPEC serializer"""

    def __init__(self, output_connector: Output, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._encoder = output_connector._encoder
        self._decoder = output_connector._decoder

    def dumps(self, data):
        # don't serialize strings
        if isinstance(data, str):
            return data
        try:
            return self._encoder.encode(data).decode("utf-8")
        except (ValueError, TypeError) as e:
            raise search.exceptions.SerializationError(data, e)

    def loads(self, s):
        return self._decoder.decode(s)


class OpensearchOutput(Output):
    """An OpenSearch output connector."""

    @define(kw_only=True, slots=False)
    class Config(Output.Config):
        """Opensearch Output Config

        .. security-best-practice::
           :title: Output Connectors - OpensearchOutput

           It is suggested to enable a secure message transfer by setting :code:`user`,
           :code:`secret` and a valid :code:`ca_cert`.
        """

        hosts: List[str] = field(
            validator=validators.deep_iterable(
                member_validator=validators.instance_of((str, type(None))),
                iterable_validator=validators.instance_of(list),
            ),
            default=[],
        )
        """Addresses of opensearch/opensearch servers. Can be a list of hosts or one single host
        in the format HOST:PORT without specifying a schema. The schema is set automatically to
        https if a certificate is being used."""
        default_index: str = field(validator=validators.instance_of(str))
        """Default index to write to if no index was set in the document or the document could not
        be indexed. The document will be transformed into a string to prevent rejections by the
        default index."""
        message_backlog_size: int = field(validator=validators.instance_of(int))
        """Amount of documents to store before sending them."""
        timeout: int = field(validator=validators.instance_of(int), default=500)
        """(Optional) Timeout for the connection (default is 500ms)."""
        user: Optional[str] = field(validator=validators.instance_of(str), default="")
        """(Optional) User used for authentication."""
        secret: Optional[str] = field(validator=validators.instance_of(str), default="")
        """(Optional) Secret used for authentication."""
        ca_cert: Optional[str] = field(validator=validators.instance_of(str), default="")
        """(Optional) Path to a SSL ca certificate to verify the ssl context."""
        flush_timeout: Optional[int] = field(validator=validators.instance_of(int), default=60)
        """(Optional) Timeout after :code:`message_backlog` is flushed if
        :code:`message_backlog_size` is not reached."""
        thread_count: int = field(
            default=4, validator=(validators.instance_of(int), validators.gt(1))
        )
        """Number of threads to use for bulk requests."""
        queue_size: int = field(
            default=4, validator=(validators.instance_of(int), validators.gt(1))
        )
        """Number of queue size to use for bulk requests."""
        chunk_size: int = field(
            default=500, validator=(validators.instance_of(int), validators.gt(1))
        )
        """Chunk size to use for bulk requests."""
        max_chunk_bytes: int = field(
            default=100 * 1024 * 1024, validator=(validators.instance_of(int), validators.gt(1))
        )
        """Max chunk size to use for bulk requests. The default is 100MB."""
        max_retries: int = field(
            default=3, validator=(validators.instance_of(int), validators.gt(0))
        )
        """Max retries for all requests. Default is 3."""
        desired_cluster_status: list = field(
            default=["green"], validator=validators.instance_of(list)
        )
        """Desired cluster status for health check as list of strings. Default is ["green"]"""
        default_op_type: str = field(
            default="index",
            validator=(validators.instance_of(str), validators.in_(["create", "index"])),
        )
        """Default op_type for indexing documents. Default is 'index',
        Consider using 'create' for data streams or to prevent overwriting existing documents."""

    __slots__ = ("_message_backlog",)

    _message_backlog: list[Event]
    """List of messages to be sent to Opensearch."""

    @property
    def config(self) -> Config:
        """Provides the properly typed rule configuration object"""
        return typing.cast(OpensearchOutput.Config, self._config)

    @cached_property
    def ssl_context(self) -> ssl.SSLContext | None:
        """Returns the ssl context

        Returns
        -------
        SSLContext
            The ssl context
        """
        return (
            ssl.create_default_context(cafile=self.config.ca_cert) if self.config.ca_cert else None
        )

    @property
    def schema(self) -> str:
        """Returns the schema. `https` if ssl config is set, else `http`

        Returns
        -------
        str
            the schema
        """
        return "https" if self.config.ca_cert else "http"

    @property
    def http_auth(self) -> tuple | None:
        """Returns the credentials

        Returns
        -------
        tuple
            the credentials in format (user, secret)
        """
        return (
            (self.config.user, self.config.secret)
            if self.config.user and self.config.secret
            else None
        )

    @cached_property
    def _search_context(self):
        """Returns the opensearch client."""
        return search.OpenSearch(
            self.config.hosts,
            scheme=self.schema,
            http_auth=self.http_auth,
            ssl_context=self.ssl_context,
            verify_certs=True,  # default is True, but we want to be explicit
            timeout=self.config.timeout,
            serializer=MSGPECSerializer(self),
            max_retries=self.config.max_retries,
            pool_maxsize=10,
            # default for connection pooling is 10 see:
            # https://github.com/opensearch-project/opensearch-py/blob/main/guides/connection_classes.md
        )

    def __init__(self, name: str, configuration: "OpensearchOutput.Config"):
        super().__init__(name, configuration)
        self._message_backlog = []

    def setup(self):
        super().setup()
        flush_timeout = self.config.flush_timeout
        self._schedule_task(task=self.flush, seconds=flush_timeout)

    def describe(self) -> str:
        """Get name of Opensearch endpoint with the host.

        Returns
        -------
        opensearch_output : OpensearchOutput
            Acts as output connector for Opensearch.

        """
        base_description = Output.describe(self)
        return f"{base_description} - Opensearch Output: {self.config.hosts}"

    @Output._handle_errors
    def store(self, event: Event) -> None:
        """Store a document in the index defined in the document or to the default index."""
        self.store_custom(event, event.data.get("_index", self.config.default_index))

    @Output._handle_errors
    def store_custom(self, event: Event, target: str) -> None:
        """Store document into backlog to be written into Opensearch with the target index.
        The target index is determined per document by parameter :code:`target`.

        Parameters
        ----------
        document : dict
            Document to be stored into the target index.
        target : str
            Index to store the document in.
        """
        event.state.next_state()
        document = event.data
        document["_index"] = target
        document["_op_type"] = document.get("_op_type", self.config.default_op_type)
        self.metrics.number_of_processed_events += 1
        self._message_backlog.append(event)
        self._write_to_search_context()

    def _write_to_search_context(self):
        """Writes documents from a buffer into Opensearch indices.

        Writes documents in a bulk if the document buffer limit has been reached.
        This reduces connections to Opensearch and improves performance.
        """
        if len(self._message_backlog) >= self.config.message_backlog_size:
            self.flush()

    @Metric.measure_time()
    def flush(self):
        if not self._message_backlog:
            return
        logger.debug("Flushing %d documents to Opensearch", len(self._message_backlog))
        self._bulk(self._search_context, self._message_backlog)
        self._message_backlog.clear()

    def _bulk(self, client: search.OpenSearch, events: list[Event]) -> None:
        """Bulk index documents into Opensearch.
        Uses the parallel_bulk function from the opensearchpy library.

        the error information is stored in a document with the following structure:

        ```json
        {
            "op_type": {
                "error": "error message",
                "status": "status_code",
                "exception": "exception message"
                }
            }
        }
        """
        kwargs = {
            "max_chunk_bytes": self.config.max_chunk_bytes,
            "chunk_size": self.config.chunk_size,
            "queue_size": self.config.queue_size,
            "thread_count": self.config.thread_count,
            "raise_on_error": False,
            "raise_on_exception": False,
        }
        actions = (event.data for event in events)
        for index, result in enumerate(helpers.parallel_bulk(client, actions, **kwargs)):  # type: ignore
            success, item = result
            if success:
                events[index].state.next_state(success=True)
                continue
            op_type = item.get("_op_type", self.config.default_op_type)
            error_info = item.get(op_type, {})
            error = BulkError(error_info.get("error", "Failed to index document"), **error_info)
            event = events[index]
            event.state.next_state(success=False)
            event.errors.append(error)

    def health(self) -> bool:
        """Check the health of the component."""
        try:
            resp = self._search_context.cluster.health(
                params={"timeout": self.config.health_timeout}
            )
        except (OpenSearchException, ConnectionError) as error:
            logger.error("Health check failed: %s", error)
            self.metrics.number_of_errors += 1
            return False
        return super().health() and resp.get("status") in self.config.desired_cluster_status
