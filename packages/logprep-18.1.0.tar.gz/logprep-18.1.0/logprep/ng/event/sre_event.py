"""Concrete Sre Event implementation"""

from logprep.ng.abc.event import ExtraDataEvent


class SreEvent(ExtraDataEvent):
    """Concrete Sre event class."""
