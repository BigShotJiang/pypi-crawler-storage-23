"""
Rule Configuration
^^^^^^^^^^^^^^^^^^

A speaking example:

..  code-block:: yaml
    :linenos:
    :caption: Given string_splitter rule

    filter: message
    string_splitter:
        source_fields: ["message"]
        target_field: result
    description: '...'

..  code-block:: json
    :linenos:
    :caption: Incoming event

    {"message": "this is the message"}

..  code-block:: json
    :linenos:
    :caption: Processed event

    {"message": "this is the message", "result": ["this", "is", "the", "message"]}


.. autoclass:: logprep.processor.string_splitter.rule.StringSplitterRule.Config
   :members:
   :undoc-members:
   :inherited-members:
   :noindex:

Examples for string_splitter:
------------------------------------------------

.. datatemplate:import-module:: tests.unit.processor.string_splitter.test_string_splitter
   :template: testcase-renderer.tmpl

"""

import typing

from attrs import define, field, validators

from logprep.processor.field_manager.rule import FieldManagerRule


class StringSplitterRule(FieldManagerRule):
    """..."""

    @define(kw_only=True)
    class Config(FieldManagerRule.Config):
        """Config for StringSplitterRule"""

        source_fields: list = field(
            validator=[
                validators.instance_of(list),
                validators.deep_iterable(member_validator=validators.instance_of(str)),
                validators.min_len(1),
                validators.max_len(1),
            ],
            default=[],
        )
        delimiter: str = field(validator=validators.instance_of(str), default=" ")
        """The delimiter for splitting. Defaults to whitespace"""
        mapping: dict = field(default={}, init=False, repr=False, eq=False)
        ignore_missing_fields: bool = field(default=False, init=False, repr=False, eq=False)
        drop_empty: bool = field(default=False)
        """If empty list values (as a result of the splitting operation) should be dropped or kept.
        By this definition, the empty string (no characters) and strings containing only `whitespace <https://docs.python.org/3/library/stdtypes.html#str.isspace>`_ count as 'empty'.
        The default setting is to keep empty list values."""

    @property
    def config(self) -> Config:
        """returns the config as typed StringSplitterRule.Config"""
        return typing.cast(StringSplitterRule.Config, self._config)

    @property
    def delimiter(self) -> str:
        """returns the configured delimiter"""
        return self.config.delimiter

    @property
    def drop_empty(self) -> bool:
        """returns the configured drop_empty flag"""
        return self.config.drop_empty
