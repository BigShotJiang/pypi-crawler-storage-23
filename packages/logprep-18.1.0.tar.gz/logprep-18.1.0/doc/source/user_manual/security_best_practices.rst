Security Best Practices
=======================

Here you find a list of all security best practices that should be considered when running logprep
in a production environment.

To compare your production environment against these best practices we provide a
:download:`Best Practice Check List <../_static/security-best-practices-check-list.xlsx>` for your use.

.. security-best-practices-list::
