## needed setup to generate documentation

* install pandoc with `apt-get install pandoc`
* install requirements with `uv sync --frozen --extra doc` in project root
