"""claudre — Claude Session Manager TUI."""
