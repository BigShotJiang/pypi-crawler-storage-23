# Help

To generate this documentation:

1. Install `Node.js` and `npm`
2. Run:
  ```console
  git clone https://github.com/posativ/isso && cd isso
  make apidoc-init apidoc
  ```
3. View API documentation in browser at `./apidoc/_output/index.html`:
  ```console
  xdg-open apidoc/_output/index.html
  ```
