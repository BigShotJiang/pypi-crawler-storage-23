var domready = require("app/lib/ready");
var count = require("app/count");

domready(function() {
    count();
});
