/* Configuration specific to `jest-puppeteer`, for E2E integration tests
 * Could be used to set e.g. Firefox as test runner
 * https://github.com/smooth-code/jest-puppeteer */

/*
module.exports = {
  launch: {
    dumpio: true,
    headless: process.env.HEADLESS !== 'false',
    product: 'chrome',
  },
  browserContext: 'default',
}
*/
