module.exports = {
    "arrow-down": require("app/svg/arrow-down.svg"),
    "arrow-up": require("app/svg/arrow-up.svg"),
};
