:orphan:

Theme testing page
==================

This page is for testing out and QA of various features of the ``_isso`` custom
sphinx theme.

This page should be hidden.

Admonitions
-----------

``attention``, ``caution``, ``danger``, ``error``, ``hint``, ``important``, ``note``, ``tip``, ``warning``, ``admonition``

.. attention::
   Testing a note

.. caution::
   Testing a note

.. danger::
   Testing a note

.. error::
   Testing a note

.. hint::
   Testing a note

.. important::
   Testing a note

.. note::
   Testing a note

.. tip::
   Testing a note

.. warning::
   Testing a note

.. admonition:: Take note

   Testing an admonition which needs its own content block. Does not render
   correctly and there shouldn't be a need to use it.

TODOs
-----

.. todo:
   This is a TODO. It should not be visible.
