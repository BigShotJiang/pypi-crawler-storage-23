# Changelog

## [0.1.0] - 2026-03-01

### Added
- Initial release
- Core verification engine with 5 modules (price, intent, authorization, seller, terms)
- LangChain integration
- CrewAI integration
- Configurable policy engine
- Audit logging
