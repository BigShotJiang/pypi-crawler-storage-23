"""P2P network layer."""
