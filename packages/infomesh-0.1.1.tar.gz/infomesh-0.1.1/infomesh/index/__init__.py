"""Search index."""
