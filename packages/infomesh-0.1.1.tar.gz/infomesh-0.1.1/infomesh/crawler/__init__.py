"""Web crawler."""

# Maximum response body size (10 MB) — shared across crawl modules
MAX_RESPONSE_BYTES: int = 10 * 1024 * 1024
