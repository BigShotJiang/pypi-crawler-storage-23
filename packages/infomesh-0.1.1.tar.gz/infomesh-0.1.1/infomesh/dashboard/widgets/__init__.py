"""Dashboard custom widgets."""

from __future__ import annotations
