"""InfoMesh Console Dashboard — Textual-based TUI for node monitoring."""

from __future__ import annotations
