"""CLI for AISafe Guard."""
