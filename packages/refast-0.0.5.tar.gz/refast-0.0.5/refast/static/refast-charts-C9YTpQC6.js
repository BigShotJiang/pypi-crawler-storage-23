var hC = Object.defineProperty;
var mC = (e, t, r) => t in e ? hC(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r;
var Qd = (e, t, r) => mC(e, typeof t != "symbol" ? t + "" : t, r);
function yC(e, t) {
  for (var r = 0; r < t.length; r++) {
    const n = t[r];
    if (typeof n != "string" && !Array.isArray(n)) {
      for (const i in n)
        if (i !== "default" && !(i in e)) {
          const a = Object.getOwnPropertyDescriptor(n, i);
          a && Object.defineProperty(e, i, a.get ? a : {
            enumerable: !0,
            get: () => n[i]
          });
        }
    }
  }
  return Object.freeze(Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }));
}
var gZ = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function Wt(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var B1 = { exports: {} }, ne = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var tu = Symbol.for("react.element"), gC = Symbol.for("react.portal"), bC = Symbol.for("react.fragment"), xC = Symbol.for("react.strict_mode"), wC = Symbol.for("react.profiler"), PC = Symbol.for("react.provider"), OC = Symbol.for("react.context"), SC = Symbol.for("react.forward_ref"), EC = Symbol.for("react.suspense"), AC = Symbol.for("react.memo"), kC = Symbol.for("react.lazy"), d0 = Symbol.iterator;
function _C(e) {
  return e === null || typeof e != "object" ? null : (e = d0 && e[d0] || e["@@iterator"], typeof e == "function" ? e : null);
}
var F1 = { isMounted: function() {
  return !1;
}, enqueueForceUpdate: function() {
}, enqueueReplaceState: function() {
}, enqueueSetState: function() {
} }, K1 = Object.assign, W1 = {};
function lo(e, t, r) {
  this.props = e, this.context = t, this.refs = W1, this.updater = r || F1;
}
lo.prototype.isReactComponent = {};
lo.prototype.setState = function(e, t) {
  if (typeof e != "object" && typeof e != "function" && e != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
  this.updater.enqueueSetState(this, e, t, "setState");
};
lo.prototype.forceUpdate = function(e) {
  this.updater.enqueueForceUpdate(this, e, "forceUpdate");
};
function U1() {
}
U1.prototype = lo.prototype;
function tm(e, t, r) {
  this.props = e, this.context = t, this.refs = W1, this.updater = r || F1;
}
var rm = tm.prototype = new U1();
rm.constructor = tm;
K1(rm, lo.prototype);
rm.isPureReactComponent = !0;
var v0 = Array.isArray, V1 = Object.prototype.hasOwnProperty, nm = { current: null }, H1 = { key: !0, ref: !0, __self: !0, __source: !0 };
function X1(e, t, r) {
  var n, i = {}, a = null, o = null;
  if (t != null) for (n in t.ref !== void 0 && (o = t.ref), t.key !== void 0 && (a = "" + t.key), t) V1.call(t, n) && !H1.hasOwnProperty(n) && (i[n] = t[n]);
  var l = arguments.length - 2;
  if (l === 1) i.children = r;
  else if (1 < l) {
    for (var u = Array(l), s = 0; s < l; s++) u[s] = arguments[s + 2];
    i.children = u;
  }
  if (e && e.defaultProps) for (n in l = e.defaultProps, l) i[n] === void 0 && (i[n] = l[n]);
  return { $$typeof: tu, type: e, key: a, ref: o, props: i, _owner: nm.current };
}
function IC(e, t) {
  return { $$typeof: tu, type: e.type, key: t, ref: e.ref, props: e.props, _owner: e._owner };
}
function im(e) {
  return typeof e == "object" && e !== null && e.$$typeof === tu;
}
function jC(e) {
  var t = { "=": "=0", ":": "=2" };
  return "$" + e.replace(/[=:]/g, function(r) {
    return t[r];
  });
}
var p0 = /\/+/g;
function Jd(e, t) {
  return typeof e == "object" && e !== null && e.key != null ? jC("" + e.key) : t.toString(36);
}
function Ms(e, t, r, n, i) {
  var a = typeof e;
  (a === "undefined" || a === "boolean") && (e = null);
  var o = !1;
  if (e === null) o = !0;
  else switch (a) {
    case "string":
    case "number":
      o = !0;
      break;
    case "object":
      switch (e.$$typeof) {
        case tu:
        case gC:
          o = !0;
      }
  }
  if (o) return o = e, i = i(o), e = n === "" ? "." + Jd(o, 0) : n, v0(i) ? (r = "", e != null && (r = e.replace(p0, "$&/") + "/"), Ms(i, t, r, "", function(s) {
    return s;
  })) : i != null && (im(i) && (i = IC(i, r + (!i.key || o && o.key === i.key ? "" : ("" + i.key).replace(p0, "$&/") + "/") + e)), t.push(i)), 1;
  if (o = 0, n = n === "" ? "." : n + ":", v0(e)) for (var l = 0; l < e.length; l++) {
    a = e[l];
    var u = n + Jd(a, l);
    o += Ms(a, t, r, u, i);
  }
  else if (u = _C(e), typeof u == "function") for (e = u.call(e), l = 0; !(a = e.next()).done; ) a = a.value, u = n + Jd(a, l++), o += Ms(a, t, r, u, i);
  else if (a === "object") throw t = String(e), Error("Objects are not valid as a React child (found: " + (t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t) + "). If you meant to render a collection of children, use an array instead.");
  return o;
}
function Zu(e, t, r) {
  if (e == null) return e;
  var n = [], i = 0;
  return Ms(e, n, "", "", function(a) {
    return t.call(r, a, i++);
  }), n;
}
function CC(e) {
  if (e._status === -1) {
    var t = e._result;
    t = t(), t.then(function(r) {
      (e._status === 0 || e._status === -1) && (e._status = 1, e._result = r);
    }, function(r) {
      (e._status === 0 || e._status === -1) && (e._status = 2, e._result = r);
    }), e._status === -1 && (e._status = 0, e._result = t);
  }
  if (e._status === 1) return e._result.default;
  throw e._result;
}
var _t = { current: null }, Ds = { transition: null }, TC = { ReactCurrentDispatcher: _t, ReactCurrentBatchConfig: Ds, ReactCurrentOwner: nm };
function Y1() {
  throw Error("act(...) is not supported in production builds of React.");
}
ne.Children = { map: Zu, forEach: function(e, t, r) {
  Zu(e, function() {
    t.apply(this, arguments);
  }, r);
}, count: function(e) {
  var t = 0;
  return Zu(e, function() {
    t++;
  }), t;
}, toArray: function(e) {
  return Zu(e, function(t) {
    return t;
  }) || [];
}, only: function(e) {
  if (!im(e)) throw Error("React.Children.only expected to receive a single React element child.");
  return e;
} };
ne.Component = lo;
ne.Fragment = bC;
ne.Profiler = wC;
ne.PureComponent = tm;
ne.StrictMode = xC;
ne.Suspense = EC;
ne.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = TC;
ne.act = Y1;
ne.cloneElement = function(e, t, r) {
  if (e == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + e + ".");
  var n = K1({}, e.props), i = e.key, a = e.ref, o = e._owner;
  if (t != null) {
    if (t.ref !== void 0 && (a = t.ref, o = nm.current), t.key !== void 0 && (i = "" + t.key), e.type && e.type.defaultProps) var l = e.type.defaultProps;
    for (u in t) V1.call(t, u) && !H1.hasOwnProperty(u) && (n[u] = t[u] === void 0 && l !== void 0 ? l[u] : t[u]);
  }
  var u = arguments.length - 2;
  if (u === 1) n.children = r;
  else if (1 < u) {
    l = Array(u);
    for (var s = 0; s < u; s++) l[s] = arguments[s + 2];
    n.children = l;
  }
  return { $$typeof: tu, type: e.type, key: i, ref: a, props: n, _owner: o };
};
ne.createContext = function(e) {
  return e = { $$typeof: OC, _currentValue: e, _currentValue2: e, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null }, e.Provider = { $$typeof: PC, _context: e }, e.Consumer = e;
};
ne.createElement = X1;
ne.createFactory = function(e) {
  var t = X1.bind(null, e);
  return t.type = e, t;
};
ne.createRef = function() {
  return { current: null };
};
ne.forwardRef = function(e) {
  return { $$typeof: SC, render: e };
};
ne.isValidElement = im;
ne.lazy = function(e) {
  return { $$typeof: kC, _payload: { _status: -1, _result: e }, _init: CC };
};
ne.memo = function(e, t) {
  return { $$typeof: AC, type: e, compare: t === void 0 ? null : t };
};
ne.startTransition = function(e) {
  var t = Ds.transition;
  Ds.transition = {};
  try {
    e();
  } finally {
    Ds.transition = t;
  }
};
ne.unstable_act = Y1;
ne.useCallback = function(e, t) {
  return _t.current.useCallback(e, t);
};
ne.useContext = function(e) {
  return _t.current.useContext(e);
};
ne.useDebugValue = function() {
};
ne.useDeferredValue = function(e) {
  return _t.current.useDeferredValue(e);
};
ne.useEffect = function(e, t) {
  return _t.current.useEffect(e, t);
};
ne.useId = function() {
  return _t.current.useId();
};
ne.useImperativeHandle = function(e, t, r) {
  return _t.current.useImperativeHandle(e, t, r);
};
ne.useInsertionEffect = function(e, t) {
  return _t.current.useInsertionEffect(e, t);
};
ne.useLayoutEffect = function(e, t) {
  return _t.current.useLayoutEffect(e, t);
};
ne.useMemo = function(e, t) {
  return _t.current.useMemo(e, t);
};
ne.useReducer = function(e, t, r) {
  return _t.current.useReducer(e, t, r);
};
ne.useRef = function(e) {
  return _t.current.useRef(e);
};
ne.useState = function(e) {
  return _t.current.useState(e);
};
ne.useSyncExternalStore = function(e, t, r) {
  return _t.current.useSyncExternalStore(e, t, r);
};
ne.useTransition = function() {
  return _t.current.useTransition();
};
ne.version = "18.3.1";
B1.exports = ne;
var d = B1.exports;
const MC = /* @__PURE__ */ Wt(d), DC = /* @__PURE__ */ yC({
  __proto__: null,
  default: MC
}, [d]);
var G1 = { exports: {} }, rr = {}, q1 = { exports: {} }, Z1 = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
(function(e) {
  function t(C, D) {
    var F = C.length;
    C.push(D);
    e: for (; 0 < F; ) {
      var Z = F - 1 >>> 1, Q = C[Z];
      if (0 < i(Q, D)) C[Z] = D, C[F] = Q, F = Z;
      else break e;
    }
  }
  function r(C) {
    return C.length === 0 ? null : C[0];
  }
  function n(C) {
    if (C.length === 0) return null;
    var D = C[0], F = C.pop();
    if (F !== D) {
      C[0] = F;
      e: for (var Z = 0, Q = C.length, Be = Q >>> 1; Z < Be; ) {
        var be = 2 * (Z + 1) - 1, Je = C[be], Xe = be + 1, fe = C[Xe];
        if (0 > i(Je, F)) Xe < Q && 0 > i(fe, Je) ? (C[Z] = fe, C[Xe] = F, Z = Xe) : (C[Z] = Je, C[be] = F, Z = be);
        else if (Xe < Q && 0 > i(fe, F)) C[Z] = fe, C[Xe] = F, Z = Xe;
        else break e;
      }
    }
    return D;
  }
  function i(C, D) {
    var F = C.sortIndex - D.sortIndex;
    return F !== 0 ? F : C.id - D.id;
  }
  if (typeof performance == "object" && typeof performance.now == "function") {
    var a = performance;
    e.unstable_now = function() {
      return a.now();
    };
  } else {
    var o = Date, l = o.now();
    e.unstable_now = function() {
      return o.now() - l;
    };
  }
  var u = [], s = [], c = 1, f = null, v = 3, p = !1, h = !1, y = !1, g = typeof setTimeout == "function" ? setTimeout : null, m = typeof clearTimeout == "function" ? clearTimeout : null, b = typeof setImmediate < "u" ? setImmediate : null;
  typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);
  function x(C) {
    for (var D = r(s); D !== null; ) {
      if (D.callback === null) n(s);
      else if (D.startTime <= C) n(s), D.sortIndex = D.expirationTime, t(u, D);
      else break;
      D = r(s);
    }
  }
  function w(C) {
    if (y = !1, x(C), !h) if (r(u) !== null) h = !0, V(P);
    else {
      var D = r(s);
      D !== null && H(w, D.startTime - C);
    }
  }
  function P(C, D) {
    h = !1, y && (y = !1, m(E), E = -1), p = !0;
    var F = v;
    try {
      for (x(D), f = r(u); f !== null && (!(f.expirationTime > D) || C && !I()); ) {
        var Z = f.callback;
        if (typeof Z == "function") {
          f.callback = null, v = f.priorityLevel;
          var Q = Z(f.expirationTime <= D);
          D = e.unstable_now(), typeof Q == "function" ? f.callback = Q : f === r(u) && n(u), x(D);
        } else n(u);
        f = r(u);
      }
      if (f !== null) var Be = !0;
      else {
        var be = r(s);
        be !== null && H(w, be.startTime - D), Be = !1;
      }
      return Be;
    } finally {
      f = null, v = F, p = !1;
    }
  }
  var O = !1, S = null, E = -1, k = 5, _ = -1;
  function I() {
    return !(e.unstable_now() - _ < k);
  }
  function j() {
    if (S !== null) {
      var C = e.unstable_now();
      _ = C;
      var D = !0;
      try {
        D = S(!0, C);
      } finally {
        D ? z() : (O = !1, S = null);
      }
    } else O = !1;
  }
  var z;
  if (typeof b == "function") z = function() {
    b(j);
  };
  else if (typeof MessageChannel < "u") {
    var N = new MessageChannel(), R = N.port2;
    N.port1.onmessage = j, z = function() {
      R.postMessage(null);
    };
  } else z = function() {
    g(j, 0);
  };
  function V(C) {
    S = C, O || (O = !0, z());
  }
  function H(C, D) {
    E = g(function() {
      C(e.unstable_now());
    }, D);
  }
  e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(C) {
    C.callback = null;
  }, e.unstable_continueExecution = function() {
    h || p || (h = !0, V(P));
  }, e.unstable_forceFrameRate = function(C) {
    0 > C || 125 < C ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : k = 0 < C ? Math.floor(1e3 / C) : 5;
  }, e.unstable_getCurrentPriorityLevel = function() {
    return v;
  }, e.unstable_getFirstCallbackNode = function() {
    return r(u);
  }, e.unstable_next = function(C) {
    switch (v) {
      case 1:
      case 2:
      case 3:
        var D = 3;
        break;
      default:
        D = v;
    }
    var F = v;
    v = D;
    try {
      return C();
    } finally {
      v = F;
    }
  }, e.unstable_pauseExecution = function() {
  }, e.unstable_requestPaint = function() {
  }, e.unstable_runWithPriority = function(C, D) {
    switch (C) {
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
        break;
      default:
        C = 3;
    }
    var F = v;
    v = C;
    try {
      return D();
    } finally {
      v = F;
    }
  }, e.unstable_scheduleCallback = function(C, D, F) {
    var Z = e.unstable_now();
    switch (typeof F == "object" && F !== null ? (F = F.delay, F = typeof F == "number" && 0 < F ? Z + F : Z) : F = Z, C) {
      case 1:
        var Q = -1;
        break;
      case 2:
        Q = 250;
        break;
      case 5:
        Q = 1073741823;
        break;
      case 4:
        Q = 1e4;
        break;
      default:
        Q = 5e3;
    }
    return Q = F + Q, C = { id: c++, callback: D, priorityLevel: C, startTime: F, expirationTime: Q, sortIndex: -1 }, F > Z ? (C.sortIndex = F, t(s, C), r(u) === null && C === r(s) && (y ? (m(E), E = -1) : y = !0, H(w, F - Z))) : (C.sortIndex = Q, t(u, C), h || p || (h = !0, V(P))), C;
  }, e.unstable_shouldYield = I, e.unstable_wrapCallback = function(C) {
    var D = v;
    return function() {
      var F = v;
      v = D;
      try {
        return C.apply(this, arguments);
      } finally {
        v = F;
      }
    };
  };
})(Z1);
q1.exports = Z1;
var NC = q1.exports;
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var $C = d, Jt = NC;
function $(e) {
  for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, r = 1; r < arguments.length; r++) t += "&args[]=" + encodeURIComponent(arguments[r]);
  return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
}
var Q1 = /* @__PURE__ */ new Set(), yl = {};
function na(e, t) {
  Fa(e, t), Fa(e + "Capture", t);
}
function Fa(e, t) {
  for (yl[e] = t, e = 0; e < t.length; e++) Q1.add(t[e]);
}
var On = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"), Jv = Object.prototype.hasOwnProperty, LC = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/, h0 = {}, m0 = {};
function RC(e) {
  return Jv.call(m0, e) ? !0 : Jv.call(h0, e) ? !1 : LC.test(e) ? m0[e] = !0 : (h0[e] = !0, !1);
}
function zC(e, t, r, n) {
  if (r !== null && r.type === 0) return !1;
  switch (typeof t) {
    case "function":
    case "symbol":
      return !0;
    case "boolean":
      return n ? !1 : r !== null ? !r.acceptsBooleans : (e = e.toLowerCase().slice(0, 5), e !== "data-" && e !== "aria-");
    default:
      return !1;
  }
}
function BC(e, t, r, n) {
  if (t === null || typeof t > "u" || zC(e, t, r, n)) return !0;
  if (n) return !1;
  if (r !== null) switch (r.type) {
    case 3:
      return !t;
    case 4:
      return t === !1;
    case 5:
      return isNaN(t);
    case 6:
      return isNaN(t) || 1 > t;
  }
  return !1;
}
function It(e, t, r, n, i, a, o) {
  this.acceptsBooleans = t === 2 || t === 3 || t === 4, this.attributeName = n, this.attributeNamespace = i, this.mustUseProperty = r, this.propertyName = e, this.type = t, this.sanitizeURL = a, this.removeEmptyString = o;
}
var vt = {};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e) {
  vt[e] = new It(e, 0, !1, e, null, !1, !1);
});
[["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(e) {
  var t = e[0];
  vt[t] = new It(t, 1, !1, e[1], null, !1, !1);
});
["contentEditable", "draggable", "spellCheck", "value"].forEach(function(e) {
  vt[e] = new It(e, 2, !1, e.toLowerCase(), null, !1, !1);
});
["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(e) {
  vt[e] = new It(e, 2, !1, e, null, !1, !1);
});
"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e) {
  vt[e] = new It(e, 3, !1, e.toLowerCase(), null, !1, !1);
});
["checked", "multiple", "muted", "selected"].forEach(function(e) {
  vt[e] = new It(e, 3, !0, e, null, !1, !1);
});
["capture", "download"].forEach(function(e) {
  vt[e] = new It(e, 4, !1, e, null, !1, !1);
});
["cols", "rows", "size", "span"].forEach(function(e) {
  vt[e] = new It(e, 6, !1, e, null, !1, !1);
});
["rowSpan", "start"].forEach(function(e) {
  vt[e] = new It(e, 5, !1, e.toLowerCase(), null, !1, !1);
});
var am = /[\-:]([a-z])/g;
function om(e) {
  return e[1].toUpperCase();
}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e) {
  var t = e.replace(
    am,
    om
  );
  vt[t] = new It(t, 1, !1, e, null, !1, !1);
});
"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e) {
  var t = e.replace(am, om);
  vt[t] = new It(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1);
});
["xml:base", "xml:lang", "xml:space"].forEach(function(e) {
  var t = e.replace(am, om);
  vt[t] = new It(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1);
});
["tabIndex", "crossOrigin"].forEach(function(e) {
  vt[e] = new It(e, 1, !1, e.toLowerCase(), null, !1, !1);
});
vt.xlinkHref = new It("xlinkHref", 1, !1, "xlink:href", "http://www.w3.org/1999/xlink", !0, !1);
["src", "href", "action", "formAction"].forEach(function(e) {
  vt[e] = new It(e, 1, !1, e.toLowerCase(), null, !0, !0);
});
function lm(e, t, r, n) {
  var i = vt.hasOwnProperty(t) ? vt[t] : null;
  (i !== null ? i.type !== 0 : n || !(2 < t.length) || t[0] !== "o" && t[0] !== "O" || t[1] !== "n" && t[1] !== "N") && (BC(t, r, i, n) && (r = null), n || i === null ? RC(t) && (r === null ? e.removeAttribute(t) : e.setAttribute(t, "" + r)) : i.mustUseProperty ? e[i.propertyName] = r === null ? i.type === 3 ? !1 : "" : r : (t = i.attributeName, n = i.attributeNamespace, r === null ? e.removeAttribute(t) : (i = i.type, r = i === 3 || i === 4 && r === !0 ? "" : "" + r, n ? e.setAttributeNS(n, t, r) : e.setAttribute(t, r))));
}
var Dn = $C.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, Qu = Symbol.for("react.element"), ma = Symbol.for("react.portal"), ya = Symbol.for("react.fragment"), um = Symbol.for("react.strict_mode"), ep = Symbol.for("react.profiler"), J1 = Symbol.for("react.provider"), eO = Symbol.for("react.context"), sm = Symbol.for("react.forward_ref"), tp = Symbol.for("react.suspense"), rp = Symbol.for("react.suspense_list"), cm = Symbol.for("react.memo"), Kn = Symbol.for("react.lazy"), tO = Symbol.for("react.offscreen"), y0 = Symbol.iterator;
function $o(e) {
  return e === null || typeof e != "object" ? null : (e = y0 && e[y0] || e["@@iterator"], typeof e == "function" ? e : null);
}
var De = Object.assign, ev;
function Jo(e) {
  if (ev === void 0) try {
    throw Error();
  } catch (r) {
    var t = r.stack.trim().match(/\n( *(at )?)/);
    ev = t && t[1] || "";
  }
  return `
` + ev + e;
}
var tv = !1;
function rv(e, t) {
  if (!e || tv) return "";
  tv = !0;
  var r = Error.prepareStackTrace;
  Error.prepareStackTrace = void 0;
  try {
    if (t) if (t = function() {
      throw Error();
    }, Object.defineProperty(t.prototype, "props", { set: function() {
      throw Error();
    } }), typeof Reflect == "object" && Reflect.construct) {
      try {
        Reflect.construct(t, []);
      } catch (s) {
        var n = s;
      }
      Reflect.construct(e, [], t);
    } else {
      try {
        t.call();
      } catch (s) {
        n = s;
      }
      e.call(t.prototype);
    }
    else {
      try {
        throw Error();
      } catch (s) {
        n = s;
      }
      e();
    }
  } catch (s) {
    if (s && n && typeof s.stack == "string") {
      for (var i = s.stack.split(`
`), a = n.stack.split(`
`), o = i.length - 1, l = a.length - 1; 1 <= o && 0 <= l && i[o] !== a[l]; ) l--;
      for (; 1 <= o && 0 <= l; o--, l--) if (i[o] !== a[l]) {
        if (o !== 1 || l !== 1)
          do
            if (o--, l--, 0 > l || i[o] !== a[l]) {
              var u = `
` + i[o].replace(" at new ", " at ");
              return e.displayName && u.includes("<anonymous>") && (u = u.replace("<anonymous>", e.displayName)), u;
            }
          while (1 <= o && 0 <= l);
        break;
      }
    }
  } finally {
    tv = !1, Error.prepareStackTrace = r;
  }
  return (e = e ? e.displayName || e.name : "") ? Jo(e) : "";
}
function FC(e) {
  switch (e.tag) {
    case 5:
      return Jo(e.type);
    case 16:
      return Jo("Lazy");
    case 13:
      return Jo("Suspense");
    case 19:
      return Jo("SuspenseList");
    case 0:
    case 2:
    case 15:
      return e = rv(e.type, !1), e;
    case 11:
      return e = rv(e.type.render, !1), e;
    case 1:
      return e = rv(e.type, !0), e;
    default:
      return "";
  }
}
function np(e) {
  if (e == null) return null;
  if (typeof e == "function") return e.displayName || e.name || null;
  if (typeof e == "string") return e;
  switch (e) {
    case ya:
      return "Fragment";
    case ma:
      return "Portal";
    case ep:
      return "Profiler";
    case um:
      return "StrictMode";
    case tp:
      return "Suspense";
    case rp:
      return "SuspenseList";
  }
  if (typeof e == "object") switch (e.$$typeof) {
    case eO:
      return (e.displayName || "Context") + ".Consumer";
    case J1:
      return (e._context.displayName || "Context") + ".Provider";
    case sm:
      var t = e.render;
      return e = e.displayName, e || (e = t.displayName || t.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
    case cm:
      return t = e.displayName || null, t !== null ? t : np(e.type) || "Memo";
    case Kn:
      t = e._payload, e = e._init;
      try {
        return np(e(t));
      } catch {
      }
  }
  return null;
}
function KC(e) {
  var t = e.type;
  switch (e.tag) {
    case 24:
      return "Cache";
    case 9:
      return (t.displayName || "Context") + ".Consumer";
    case 10:
      return (t._context.displayName || "Context") + ".Provider";
    case 18:
      return "DehydratedFragment";
    case 11:
      return e = t.render, e = e.displayName || e.name || "", t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef");
    case 7:
      return "Fragment";
    case 5:
      return t;
    case 4:
      return "Portal";
    case 3:
      return "Root";
    case 6:
      return "Text";
    case 16:
      return np(t);
    case 8:
      return t === um ? "StrictMode" : "Mode";
    case 22:
      return "Offscreen";
    case 12:
      return "Profiler";
    case 21:
      return "Scope";
    case 13:
      return "Suspense";
    case 19:
      return "SuspenseList";
    case 25:
      return "TracingMarker";
    case 1:
    case 0:
    case 17:
    case 2:
    case 14:
    case 15:
      if (typeof t == "function") return t.displayName || t.name || null;
      if (typeof t == "string") return t;
  }
  return null;
}
function li(e) {
  switch (typeof e) {
    case "boolean":
    case "number":
    case "string":
    case "undefined":
      return e;
    case "object":
      return e;
    default:
      return "";
  }
}
function rO(e) {
  var t = e.type;
  return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio");
}
function WC(e) {
  var t = rO(e) ? "checked" : "value", r = Object.getOwnPropertyDescriptor(e.constructor.prototype, t), n = "" + e[t];
  if (!e.hasOwnProperty(t) && typeof r < "u" && typeof r.get == "function" && typeof r.set == "function") {
    var i = r.get, a = r.set;
    return Object.defineProperty(e, t, { configurable: !0, get: function() {
      return i.call(this);
    }, set: function(o) {
      n = "" + o, a.call(this, o);
    } }), Object.defineProperty(e, t, { enumerable: r.enumerable }), { getValue: function() {
      return n;
    }, setValue: function(o) {
      n = "" + o;
    }, stopTracking: function() {
      e._valueTracker = null, delete e[t];
    } };
  }
}
function Ju(e) {
  e._valueTracker || (e._valueTracker = WC(e));
}
function nO(e) {
  if (!e) return !1;
  var t = e._valueTracker;
  if (!t) return !0;
  var r = t.getValue(), n = "";
  return e && (n = rO(e) ? e.checked ? "true" : "false" : e.value), e = n, e !== r ? (t.setValue(e), !0) : !1;
}
function Qs(e) {
  if (e = e || (typeof document < "u" ? document : void 0), typeof e > "u") return null;
  try {
    return e.activeElement || e.body;
  } catch {
    return e.body;
  }
}
function ip(e, t) {
  var r = t.checked;
  return De({}, t, { defaultChecked: void 0, defaultValue: void 0, value: void 0, checked: r ?? e._wrapperState.initialChecked });
}
function g0(e, t) {
  var r = t.defaultValue == null ? "" : t.defaultValue, n = t.checked != null ? t.checked : t.defaultChecked;
  r = li(t.value != null ? t.value : r), e._wrapperState = { initialChecked: n, initialValue: r, controlled: t.type === "checkbox" || t.type === "radio" ? t.checked != null : t.value != null };
}
function iO(e, t) {
  t = t.checked, t != null && lm(e, "checked", t, !1);
}
function ap(e, t) {
  iO(e, t);
  var r = li(t.value), n = t.type;
  if (r != null) n === "number" ? (r === 0 && e.value === "" || e.value != r) && (e.value = "" + r) : e.value !== "" + r && (e.value = "" + r);
  else if (n === "submit" || n === "reset") {
    e.removeAttribute("value");
    return;
  }
  t.hasOwnProperty("value") ? op(e, t.type, r) : t.hasOwnProperty("defaultValue") && op(e, t.type, li(t.defaultValue)), t.checked == null && t.defaultChecked != null && (e.defaultChecked = !!t.defaultChecked);
}
function b0(e, t, r) {
  if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
    var n = t.type;
    if (!(n !== "submit" && n !== "reset" || t.value !== void 0 && t.value !== null)) return;
    t = "" + e._wrapperState.initialValue, r || t === e.value || (e.value = t), e.defaultValue = t;
  }
  r = e.name, r !== "" && (e.name = ""), e.defaultChecked = !!e._wrapperState.initialChecked, r !== "" && (e.name = r);
}
function op(e, t, r) {
  (t !== "number" || Qs(e.ownerDocument) !== e) && (r == null ? e.defaultValue = "" + e._wrapperState.initialValue : e.defaultValue !== "" + r && (e.defaultValue = "" + r));
}
var el = Array.isArray;
function Ta(e, t, r, n) {
  if (e = e.options, t) {
    t = {};
    for (var i = 0; i < r.length; i++) t["$" + r[i]] = !0;
    for (r = 0; r < e.length; r++) i = t.hasOwnProperty("$" + e[r].value), e[r].selected !== i && (e[r].selected = i), i && n && (e[r].defaultSelected = !0);
  } else {
    for (r = "" + li(r), t = null, i = 0; i < e.length; i++) {
      if (e[i].value === r) {
        e[i].selected = !0, n && (e[i].defaultSelected = !0);
        return;
      }
      t !== null || e[i].disabled || (t = e[i]);
    }
    t !== null && (t.selected = !0);
  }
}
function lp(e, t) {
  if (t.dangerouslySetInnerHTML != null) throw Error($(91));
  return De({}, t, { value: void 0, defaultValue: void 0, children: "" + e._wrapperState.initialValue });
}
function x0(e, t) {
  var r = t.value;
  if (r == null) {
    if (r = t.children, t = t.defaultValue, r != null) {
      if (t != null) throw Error($(92));
      if (el(r)) {
        if (1 < r.length) throw Error($(93));
        r = r[0];
      }
      t = r;
    }
    t == null && (t = ""), r = t;
  }
  e._wrapperState = { initialValue: li(r) };
}
function aO(e, t) {
  var r = li(t.value), n = li(t.defaultValue);
  r != null && (r = "" + r, r !== e.value && (e.value = r), t.defaultValue == null && e.defaultValue !== r && (e.defaultValue = r)), n != null && (e.defaultValue = "" + n);
}
function w0(e) {
  var t = e.textContent;
  t === e._wrapperState.initialValue && t !== "" && t !== null && (e.value = t);
}
function oO(e) {
  switch (e) {
    case "svg":
      return "http://www.w3.org/2000/svg";
    case "math":
      return "http://www.w3.org/1998/Math/MathML";
    default:
      return "http://www.w3.org/1999/xhtml";
  }
}
function up(e, t) {
  return e == null || e === "http://www.w3.org/1999/xhtml" ? oO(t) : e === "http://www.w3.org/2000/svg" && t === "foreignObject" ? "http://www.w3.org/1999/xhtml" : e;
}
var es, lO = function(e) {
  return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction ? function(t, r, n, i) {
    MSApp.execUnsafeLocalFunction(function() {
      return e(t, r, n, i);
    });
  } : e;
}(function(e, t) {
  if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e) e.innerHTML = t;
  else {
    for (es = es || document.createElement("div"), es.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>", t = es.firstChild; e.firstChild; ) e.removeChild(e.firstChild);
    for (; t.firstChild; ) e.appendChild(t.firstChild);
  }
});
function gl(e, t) {
  if (t) {
    var r = e.firstChild;
    if (r && r === e.lastChild && r.nodeType === 3) {
      r.nodeValue = t;
      return;
    }
  }
  e.textContent = t;
}
var al = {
  animationIterationCount: !0,
  aspectRatio: !0,
  borderImageOutset: !0,
  borderImageSlice: !0,
  borderImageWidth: !0,
  boxFlex: !0,
  boxFlexGroup: !0,
  boxOrdinalGroup: !0,
  columnCount: !0,
  columns: !0,
  flex: !0,
  flexGrow: !0,
  flexPositive: !0,
  flexShrink: !0,
  flexNegative: !0,
  flexOrder: !0,
  gridArea: !0,
  gridRow: !0,
  gridRowEnd: !0,
  gridRowSpan: !0,
  gridRowStart: !0,
  gridColumn: !0,
  gridColumnEnd: !0,
  gridColumnSpan: !0,
  gridColumnStart: !0,
  fontWeight: !0,
  lineClamp: !0,
  lineHeight: !0,
  opacity: !0,
  order: !0,
  orphans: !0,
  tabSize: !0,
  widows: !0,
  zIndex: !0,
  zoom: !0,
  fillOpacity: !0,
  floodOpacity: !0,
  stopOpacity: !0,
  strokeDasharray: !0,
  strokeDashoffset: !0,
  strokeMiterlimit: !0,
  strokeOpacity: !0,
  strokeWidth: !0
}, UC = ["Webkit", "ms", "Moz", "O"];
Object.keys(al).forEach(function(e) {
  UC.forEach(function(t) {
    t = t + e.charAt(0).toUpperCase() + e.substring(1), al[t] = al[e];
  });
});
function uO(e, t, r) {
  return t == null || typeof t == "boolean" || t === "" ? "" : r || typeof t != "number" || t === 0 || al.hasOwnProperty(e) && al[e] ? ("" + t).trim() : t + "px";
}
function sO(e, t) {
  e = e.style;
  for (var r in t) if (t.hasOwnProperty(r)) {
    var n = r.indexOf("--") === 0, i = uO(r, t[r], n);
    r === "float" && (r = "cssFloat"), n ? e.setProperty(r, i) : e[r] = i;
  }
}
var VC = De({ menuitem: !0 }, { area: !0, base: !0, br: !0, col: !0, embed: !0, hr: !0, img: !0, input: !0, keygen: !0, link: !0, meta: !0, param: !0, source: !0, track: !0, wbr: !0 });
function sp(e, t) {
  if (t) {
    if (VC[e] && (t.children != null || t.dangerouslySetInnerHTML != null)) throw Error($(137, e));
    if (t.dangerouslySetInnerHTML != null) {
      if (t.children != null) throw Error($(60));
      if (typeof t.dangerouslySetInnerHTML != "object" || !("__html" in t.dangerouslySetInnerHTML)) throw Error($(61));
    }
    if (t.style != null && typeof t.style != "object") throw Error($(62));
  }
}
function cp(e, t) {
  if (e.indexOf("-") === -1) return typeof t.is == "string";
  switch (e) {
    case "annotation-xml":
    case "color-profile":
    case "font-face":
    case "font-face-src":
    case "font-face-uri":
    case "font-face-format":
    case "font-face-name":
    case "missing-glyph":
      return !1;
    default:
      return !0;
  }
}
var fp = null;
function fm(e) {
  return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e;
}
var dp = null, Ma = null, Da = null;
function P0(e) {
  if (e = iu(e)) {
    if (typeof dp != "function") throw Error($(280));
    var t = e.stateNode;
    t && (t = Mf(t), dp(e.stateNode, e.type, t));
  }
}
function cO(e) {
  Ma ? Da ? Da.push(e) : Da = [e] : Ma = e;
}
function fO() {
  if (Ma) {
    var e = Ma, t = Da;
    if (Da = Ma = null, P0(e), t) for (e = 0; e < t.length; e++) P0(t[e]);
  }
}
function dO(e, t) {
  return e(t);
}
function vO() {
}
var nv = !1;
function pO(e, t, r) {
  if (nv) return e(t, r);
  nv = !0;
  try {
    return dO(e, t, r);
  } finally {
    nv = !1, (Ma !== null || Da !== null) && (vO(), fO());
  }
}
function bl(e, t) {
  var r = e.stateNode;
  if (r === null) return null;
  var n = Mf(r);
  if (n === null) return null;
  r = n[t];
  e: switch (t) {
    case "onClick":
    case "onClickCapture":
    case "onDoubleClick":
    case "onDoubleClickCapture":
    case "onMouseDown":
    case "onMouseDownCapture":
    case "onMouseMove":
    case "onMouseMoveCapture":
    case "onMouseUp":
    case "onMouseUpCapture":
    case "onMouseEnter":
      (n = !n.disabled) || (e = e.type, n = !(e === "button" || e === "input" || e === "select" || e === "textarea")), e = !n;
      break e;
    default:
      e = !1;
  }
  if (e) return null;
  if (r && typeof r != "function") throw Error($(231, t, typeof r));
  return r;
}
var vp = !1;
if (On) try {
  var Lo = {};
  Object.defineProperty(Lo, "passive", { get: function() {
    vp = !0;
  } }), window.addEventListener("test", Lo, Lo), window.removeEventListener("test", Lo, Lo);
} catch {
  vp = !1;
}
function HC(e, t, r, n, i, a, o, l, u) {
  var s = Array.prototype.slice.call(arguments, 3);
  try {
    t.apply(r, s);
  } catch (c) {
    this.onError(c);
  }
}
var ol = !1, Js = null, ec = !1, pp = null, XC = { onError: function(e) {
  ol = !0, Js = e;
} };
function YC(e, t, r, n, i, a, o, l, u) {
  ol = !1, Js = null, HC.apply(XC, arguments);
}
function GC(e, t, r, n, i, a, o, l, u) {
  if (YC.apply(this, arguments), ol) {
    if (ol) {
      var s = Js;
      ol = !1, Js = null;
    } else throw Error($(198));
    ec || (ec = !0, pp = s);
  }
}
function ia(e) {
  var t = e, r = e;
  if (e.alternate) for (; t.return; ) t = t.return;
  else {
    e = t;
    do
      t = e, t.flags & 4098 && (r = t.return), e = t.return;
    while (e);
  }
  return t.tag === 3 ? r : null;
}
function hO(e) {
  if (e.tag === 13) {
    var t = e.memoizedState;
    if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated;
  }
  return null;
}
function O0(e) {
  if (ia(e) !== e) throw Error($(188));
}
function qC(e) {
  var t = e.alternate;
  if (!t) {
    if (t = ia(e), t === null) throw Error($(188));
    return t !== e ? null : e;
  }
  for (var r = e, n = t; ; ) {
    var i = r.return;
    if (i === null) break;
    var a = i.alternate;
    if (a === null) {
      if (n = i.return, n !== null) {
        r = n;
        continue;
      }
      break;
    }
    if (i.child === a.child) {
      for (a = i.child; a; ) {
        if (a === r) return O0(i), e;
        if (a === n) return O0(i), t;
        a = a.sibling;
      }
      throw Error($(188));
    }
    if (r.return !== n.return) r = i, n = a;
    else {
      for (var o = !1, l = i.child; l; ) {
        if (l === r) {
          o = !0, r = i, n = a;
          break;
        }
        if (l === n) {
          o = !0, n = i, r = a;
          break;
        }
        l = l.sibling;
      }
      if (!o) {
        for (l = a.child; l; ) {
          if (l === r) {
            o = !0, r = a, n = i;
            break;
          }
          if (l === n) {
            o = !0, n = a, r = i;
            break;
          }
          l = l.sibling;
        }
        if (!o) throw Error($(189));
      }
    }
    if (r.alternate !== n) throw Error($(190));
  }
  if (r.tag !== 3) throw Error($(188));
  return r.stateNode.current === r ? e : t;
}
function mO(e) {
  return e = qC(e), e !== null ? yO(e) : null;
}
function yO(e) {
  if (e.tag === 5 || e.tag === 6) return e;
  for (e = e.child; e !== null; ) {
    var t = yO(e);
    if (t !== null) return t;
    e = e.sibling;
  }
  return null;
}
var gO = Jt.unstable_scheduleCallback, S0 = Jt.unstable_cancelCallback, ZC = Jt.unstable_shouldYield, QC = Jt.unstable_requestPaint, ze = Jt.unstable_now, JC = Jt.unstable_getCurrentPriorityLevel, dm = Jt.unstable_ImmediatePriority, bO = Jt.unstable_UserBlockingPriority, tc = Jt.unstable_NormalPriority, eT = Jt.unstable_LowPriority, xO = Jt.unstable_IdlePriority, If = null, Vr = null;
function tT(e) {
  if (Vr && typeof Vr.onCommitFiberRoot == "function") try {
    Vr.onCommitFiberRoot(If, e, void 0, (e.current.flags & 128) === 128);
  } catch {
  }
}
var Ir = Math.clz32 ? Math.clz32 : iT, rT = Math.log, nT = Math.LN2;
function iT(e) {
  return e >>>= 0, e === 0 ? 32 : 31 - (rT(e) / nT | 0) | 0;
}
var ts = 64, rs = 4194304;
function tl(e) {
  switch (e & -e) {
    case 1:
      return 1;
    case 2:
      return 2;
    case 4:
      return 4;
    case 8:
      return 8;
    case 16:
      return 16;
    case 32:
      return 32;
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return e & 4194240;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return e & 130023424;
    case 134217728:
      return 134217728;
    case 268435456:
      return 268435456;
    case 536870912:
      return 536870912;
    case 1073741824:
      return 1073741824;
    default:
      return e;
  }
}
function rc(e, t) {
  var r = e.pendingLanes;
  if (r === 0) return 0;
  var n = 0, i = e.suspendedLanes, a = e.pingedLanes, o = r & 268435455;
  if (o !== 0) {
    var l = o & ~i;
    l !== 0 ? n = tl(l) : (a &= o, a !== 0 && (n = tl(a)));
  } else o = r & ~i, o !== 0 ? n = tl(o) : a !== 0 && (n = tl(a));
  if (n === 0) return 0;
  if (t !== 0 && t !== n && !(t & i) && (i = n & -n, a = t & -t, i >= a || i === 16 && (a & 4194240) !== 0)) return t;
  if (n & 4 && (n |= r & 16), t = e.entangledLanes, t !== 0) for (e = e.entanglements, t &= n; 0 < t; ) r = 31 - Ir(t), i = 1 << r, n |= e[r], t &= ~i;
  return n;
}
function aT(e, t) {
  switch (e) {
    case 1:
    case 2:
    case 4:
      return t + 250;
    case 8:
    case 16:
    case 32:
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return t + 5e3;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return -1;
    case 134217728:
    case 268435456:
    case 536870912:
    case 1073741824:
      return -1;
    default:
      return -1;
  }
}
function oT(e, t) {
  for (var r = e.suspendedLanes, n = e.pingedLanes, i = e.expirationTimes, a = e.pendingLanes; 0 < a; ) {
    var o = 31 - Ir(a), l = 1 << o, u = i[o];
    u === -1 ? (!(l & r) || l & n) && (i[o] = aT(l, t)) : u <= t && (e.expiredLanes |= l), a &= ~l;
  }
}
function hp(e) {
  return e = e.pendingLanes & -1073741825, e !== 0 ? e : e & 1073741824 ? 1073741824 : 0;
}
function wO() {
  var e = ts;
  return ts <<= 1, !(ts & 4194240) && (ts = 64), e;
}
function iv(e) {
  for (var t = [], r = 0; 31 > r; r++) t.push(e);
  return t;
}
function ru(e, t, r) {
  e.pendingLanes |= t, t !== 536870912 && (e.suspendedLanes = 0, e.pingedLanes = 0), e = e.eventTimes, t = 31 - Ir(t), e[t] = r;
}
function lT(e, t) {
  var r = e.pendingLanes & ~t;
  e.pendingLanes = t, e.suspendedLanes = 0, e.pingedLanes = 0, e.expiredLanes &= t, e.mutableReadLanes &= t, e.entangledLanes &= t, t = e.entanglements;
  var n = e.eventTimes;
  for (e = e.expirationTimes; 0 < r; ) {
    var i = 31 - Ir(r), a = 1 << i;
    t[i] = 0, n[i] = -1, e[i] = -1, r &= ~a;
  }
}
function vm(e, t) {
  var r = e.entangledLanes |= t;
  for (e = e.entanglements; r; ) {
    var n = 31 - Ir(r), i = 1 << n;
    i & t | e[n] & t && (e[n] |= t), r &= ~i;
  }
}
var ve = 0;
function PO(e) {
  return e &= -e, 1 < e ? 4 < e ? e & 268435455 ? 16 : 536870912 : 4 : 1;
}
var OO, pm, SO, EO, AO, mp = !1, ns = [], Qn = null, Jn = null, ei = null, xl = /* @__PURE__ */ new Map(), wl = /* @__PURE__ */ new Map(), Hn = [], uT = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
function E0(e, t) {
  switch (e) {
    case "focusin":
    case "focusout":
      Qn = null;
      break;
    case "dragenter":
    case "dragleave":
      Jn = null;
      break;
    case "mouseover":
    case "mouseout":
      ei = null;
      break;
    case "pointerover":
    case "pointerout":
      xl.delete(t.pointerId);
      break;
    case "gotpointercapture":
    case "lostpointercapture":
      wl.delete(t.pointerId);
  }
}
function Ro(e, t, r, n, i, a) {
  return e === null || e.nativeEvent !== a ? (e = { blockedOn: t, domEventName: r, eventSystemFlags: n, nativeEvent: a, targetContainers: [i] }, t !== null && (t = iu(t), t !== null && pm(t)), e) : (e.eventSystemFlags |= n, t = e.targetContainers, i !== null && t.indexOf(i) === -1 && t.push(i), e);
}
function sT(e, t, r, n, i) {
  switch (t) {
    case "focusin":
      return Qn = Ro(Qn, e, t, r, n, i), !0;
    case "dragenter":
      return Jn = Ro(Jn, e, t, r, n, i), !0;
    case "mouseover":
      return ei = Ro(ei, e, t, r, n, i), !0;
    case "pointerover":
      var a = i.pointerId;
      return xl.set(a, Ro(xl.get(a) || null, e, t, r, n, i)), !0;
    case "gotpointercapture":
      return a = i.pointerId, wl.set(a, Ro(wl.get(a) || null, e, t, r, n, i)), !0;
  }
  return !1;
}
function kO(e) {
  var t = _i(e.target);
  if (t !== null) {
    var r = ia(t);
    if (r !== null) {
      if (t = r.tag, t === 13) {
        if (t = hO(r), t !== null) {
          e.blockedOn = t, AO(e.priority, function() {
            SO(r);
          });
          return;
        }
      } else if (t === 3 && r.stateNode.current.memoizedState.isDehydrated) {
        e.blockedOn = r.tag === 3 ? r.stateNode.containerInfo : null;
        return;
      }
    }
  }
  e.blockedOn = null;
}
function Ns(e) {
  if (e.blockedOn !== null) return !1;
  for (var t = e.targetContainers; 0 < t.length; ) {
    var r = yp(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
    if (r === null) {
      r = e.nativeEvent;
      var n = new r.constructor(r.type, r);
      fp = n, r.target.dispatchEvent(n), fp = null;
    } else return t = iu(r), t !== null && pm(t), e.blockedOn = r, !1;
    t.shift();
  }
  return !0;
}
function A0(e, t, r) {
  Ns(e) && r.delete(t);
}
function cT() {
  mp = !1, Qn !== null && Ns(Qn) && (Qn = null), Jn !== null && Ns(Jn) && (Jn = null), ei !== null && Ns(ei) && (ei = null), xl.forEach(A0), wl.forEach(A0);
}
function zo(e, t) {
  e.blockedOn === t && (e.blockedOn = null, mp || (mp = !0, Jt.unstable_scheduleCallback(Jt.unstable_NormalPriority, cT)));
}
function Pl(e) {
  function t(i) {
    return zo(i, e);
  }
  if (0 < ns.length) {
    zo(ns[0], e);
    for (var r = 1; r < ns.length; r++) {
      var n = ns[r];
      n.blockedOn === e && (n.blockedOn = null);
    }
  }
  for (Qn !== null && zo(Qn, e), Jn !== null && zo(Jn, e), ei !== null && zo(ei, e), xl.forEach(t), wl.forEach(t), r = 0; r < Hn.length; r++) n = Hn[r], n.blockedOn === e && (n.blockedOn = null);
  for (; 0 < Hn.length && (r = Hn[0], r.blockedOn === null); ) kO(r), r.blockedOn === null && Hn.shift();
}
var Na = Dn.ReactCurrentBatchConfig, nc = !0;
function fT(e, t, r, n) {
  var i = ve, a = Na.transition;
  Na.transition = null;
  try {
    ve = 1, hm(e, t, r, n);
  } finally {
    ve = i, Na.transition = a;
  }
}
function dT(e, t, r, n) {
  var i = ve, a = Na.transition;
  Na.transition = null;
  try {
    ve = 4, hm(e, t, r, n);
  } finally {
    ve = i, Na.transition = a;
  }
}
function hm(e, t, r, n) {
  if (nc) {
    var i = yp(e, t, r, n);
    if (i === null) pv(e, t, n, ic, r), E0(e, n);
    else if (sT(i, e, t, r, n)) n.stopPropagation();
    else if (E0(e, n), t & 4 && -1 < uT.indexOf(e)) {
      for (; i !== null; ) {
        var a = iu(i);
        if (a !== null && OO(a), a = yp(e, t, r, n), a === null && pv(e, t, n, ic, r), a === i) break;
        i = a;
      }
      i !== null && n.stopPropagation();
    } else pv(e, t, n, null, r);
  }
}
var ic = null;
function yp(e, t, r, n) {
  if (ic = null, e = fm(n), e = _i(e), e !== null) if (t = ia(e), t === null) e = null;
  else if (r = t.tag, r === 13) {
    if (e = hO(t), e !== null) return e;
    e = null;
  } else if (r === 3) {
    if (t.stateNode.current.memoizedState.isDehydrated) return t.tag === 3 ? t.stateNode.containerInfo : null;
    e = null;
  } else t !== e && (e = null);
  return ic = e, null;
}
function _O(e) {
  switch (e) {
    case "cancel":
    case "click":
    case "close":
    case "contextmenu":
    case "copy":
    case "cut":
    case "auxclick":
    case "dblclick":
    case "dragend":
    case "dragstart":
    case "drop":
    case "focusin":
    case "focusout":
    case "input":
    case "invalid":
    case "keydown":
    case "keypress":
    case "keyup":
    case "mousedown":
    case "mouseup":
    case "paste":
    case "pause":
    case "play":
    case "pointercancel":
    case "pointerdown":
    case "pointerup":
    case "ratechange":
    case "reset":
    case "resize":
    case "seeked":
    case "submit":
    case "touchcancel":
    case "touchend":
    case "touchstart":
    case "volumechange":
    case "change":
    case "selectionchange":
    case "textInput":
    case "compositionstart":
    case "compositionend":
    case "compositionupdate":
    case "beforeblur":
    case "afterblur":
    case "beforeinput":
    case "blur":
    case "fullscreenchange":
    case "focus":
    case "hashchange":
    case "popstate":
    case "select":
    case "selectstart":
      return 1;
    case "drag":
    case "dragenter":
    case "dragexit":
    case "dragleave":
    case "dragover":
    case "mousemove":
    case "mouseout":
    case "mouseover":
    case "pointermove":
    case "pointerout":
    case "pointerover":
    case "scroll":
    case "toggle":
    case "touchmove":
    case "wheel":
    case "mouseenter":
    case "mouseleave":
    case "pointerenter":
    case "pointerleave":
      return 4;
    case "message":
      switch (JC()) {
        case dm:
          return 1;
        case bO:
          return 4;
        case tc:
        case eT:
          return 16;
        case xO:
          return 536870912;
        default:
          return 16;
      }
    default:
      return 16;
  }
}
var Gn = null, mm = null, $s = null;
function IO() {
  if ($s) return $s;
  var e, t = mm, r = t.length, n, i = "value" in Gn ? Gn.value : Gn.textContent, a = i.length;
  for (e = 0; e < r && t[e] === i[e]; e++) ;
  var o = r - e;
  for (n = 1; n <= o && t[r - n] === i[a - n]; n++) ;
  return $s = i.slice(e, 1 < n ? 1 - n : void 0);
}
function Ls(e) {
  var t = e.keyCode;
  return "charCode" in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0;
}
function is() {
  return !0;
}
function k0() {
  return !1;
}
function nr(e) {
  function t(r, n, i, a, o) {
    this._reactName = r, this._targetInst = i, this.type = n, this.nativeEvent = a, this.target = o, this.currentTarget = null;
    for (var l in e) e.hasOwnProperty(l) && (r = e[l], this[l] = r ? r(a) : a[l]);
    return this.isDefaultPrevented = (a.defaultPrevented != null ? a.defaultPrevented : a.returnValue === !1) ? is : k0, this.isPropagationStopped = k0, this;
  }
  return De(t.prototype, { preventDefault: function() {
    this.defaultPrevented = !0;
    var r = this.nativeEvent;
    r && (r.preventDefault ? r.preventDefault() : typeof r.returnValue != "unknown" && (r.returnValue = !1), this.isDefaultPrevented = is);
  }, stopPropagation: function() {
    var r = this.nativeEvent;
    r && (r.stopPropagation ? r.stopPropagation() : typeof r.cancelBubble != "unknown" && (r.cancelBubble = !0), this.isPropagationStopped = is);
  }, persist: function() {
  }, isPersistent: is }), t;
}
var uo = { eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(e) {
  return e.timeStamp || Date.now();
}, defaultPrevented: 0, isTrusted: 0 }, ym = nr(uo), nu = De({}, uo, { view: 0, detail: 0 }), vT = nr(nu), av, ov, Bo, jf = De({}, nu, { screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: gm, button: 0, buttons: 0, relatedTarget: function(e) {
  return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget;
}, movementX: function(e) {
  return "movementX" in e ? e.movementX : (e !== Bo && (Bo && e.type === "mousemove" ? (av = e.screenX - Bo.screenX, ov = e.screenY - Bo.screenY) : ov = av = 0, Bo = e), av);
}, movementY: function(e) {
  return "movementY" in e ? e.movementY : ov;
} }), _0 = nr(jf), pT = De({}, jf, { dataTransfer: 0 }), hT = nr(pT), mT = De({}, nu, { relatedTarget: 0 }), lv = nr(mT), yT = De({}, uo, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }), gT = nr(yT), bT = De({}, uo, { clipboardData: function(e) {
  return "clipboardData" in e ? e.clipboardData : window.clipboardData;
} }), xT = nr(bT), wT = De({}, uo, { data: 0 }), I0 = nr(wT), PT = {
  Esc: "Escape",
  Spacebar: " ",
  Left: "ArrowLeft",
  Up: "ArrowUp",
  Right: "ArrowRight",
  Down: "ArrowDown",
  Del: "Delete",
  Win: "OS",
  Menu: "ContextMenu",
  Apps: "ContextMenu",
  Scroll: "ScrollLock",
  MozPrintableKey: "Unidentified"
}, OT = {
  8: "Backspace",
  9: "Tab",
  12: "Clear",
  13: "Enter",
  16: "Shift",
  17: "Control",
  18: "Alt",
  19: "Pause",
  20: "CapsLock",
  27: "Escape",
  32: " ",
  33: "PageUp",
  34: "PageDown",
  35: "End",
  36: "Home",
  37: "ArrowLeft",
  38: "ArrowUp",
  39: "ArrowRight",
  40: "ArrowDown",
  45: "Insert",
  46: "Delete",
  112: "F1",
  113: "F2",
  114: "F3",
  115: "F4",
  116: "F5",
  117: "F6",
  118: "F7",
  119: "F8",
  120: "F9",
  121: "F10",
  122: "F11",
  123: "F12",
  144: "NumLock",
  145: "ScrollLock",
  224: "Meta"
}, ST = { Alt: "altKey", Control: "ctrlKey", Meta: "metaKey", Shift: "shiftKey" };
function ET(e) {
  var t = this.nativeEvent;
  return t.getModifierState ? t.getModifierState(e) : (e = ST[e]) ? !!t[e] : !1;
}
function gm() {
  return ET;
}
var AT = De({}, nu, { key: function(e) {
  if (e.key) {
    var t = PT[e.key] || e.key;
    if (t !== "Unidentified") return t;
  }
  return e.type === "keypress" ? (e = Ls(e), e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? OT[e.keyCode] || "Unidentified" : "";
}, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: gm, charCode: function(e) {
  return e.type === "keypress" ? Ls(e) : 0;
}, keyCode: function(e) {
  return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
}, which: function(e) {
  return e.type === "keypress" ? Ls(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
} }), kT = nr(AT), _T = De({}, jf, { pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0 }), j0 = nr(_T), IT = De({}, nu, { touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: gm }), jT = nr(IT), CT = De({}, uo, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }), TT = nr(CT), MT = De({}, jf, {
  deltaX: function(e) {
    return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0;
  },
  deltaY: function(e) {
    return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0;
  },
  deltaZ: 0,
  deltaMode: 0
}), DT = nr(MT), NT = [9, 13, 27, 32], bm = On && "CompositionEvent" in window, ll = null;
On && "documentMode" in document && (ll = document.documentMode);
var $T = On && "TextEvent" in window && !ll, jO = On && (!bm || ll && 8 < ll && 11 >= ll), C0 = " ", T0 = !1;
function CO(e, t) {
  switch (e) {
    case "keyup":
      return NT.indexOf(t.keyCode) !== -1;
    case "keydown":
      return t.keyCode !== 229;
    case "keypress":
    case "mousedown":
    case "focusout":
      return !0;
    default:
      return !1;
  }
}
function TO(e) {
  return e = e.detail, typeof e == "object" && "data" in e ? e.data : null;
}
var ga = !1;
function LT(e, t) {
  switch (e) {
    case "compositionend":
      return TO(t);
    case "keypress":
      return t.which !== 32 ? null : (T0 = !0, C0);
    case "textInput":
      return e = t.data, e === C0 && T0 ? null : e;
    default:
      return null;
  }
}
function RT(e, t) {
  if (ga) return e === "compositionend" || !bm && CO(e, t) ? (e = IO(), $s = mm = Gn = null, ga = !1, e) : null;
  switch (e) {
    case "paste":
      return null;
    case "keypress":
      if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
        if (t.char && 1 < t.char.length) return t.char;
        if (t.which) return String.fromCharCode(t.which);
      }
      return null;
    case "compositionend":
      return jO && t.locale !== "ko" ? null : t.data;
    default:
      return null;
  }
}
var zT = { color: !0, date: !0, datetime: !0, "datetime-local": !0, email: !0, month: !0, number: !0, password: !0, range: !0, search: !0, tel: !0, text: !0, time: !0, url: !0, week: !0 };
function M0(e) {
  var t = e && e.nodeName && e.nodeName.toLowerCase();
  return t === "input" ? !!zT[e.type] : t === "textarea";
}
function MO(e, t, r, n) {
  cO(n), t = ac(t, "onChange"), 0 < t.length && (r = new ym("onChange", "change", null, r, n), e.push({ event: r, listeners: t }));
}
var ul = null, Ol = null;
function BT(e) {
  UO(e, 0);
}
function Cf(e) {
  var t = wa(e);
  if (nO(t)) return e;
}
function FT(e, t) {
  if (e === "change") return t;
}
var DO = !1;
if (On) {
  var uv;
  if (On) {
    var sv = "oninput" in document;
    if (!sv) {
      var D0 = document.createElement("div");
      D0.setAttribute("oninput", "return;"), sv = typeof D0.oninput == "function";
    }
    uv = sv;
  } else uv = !1;
  DO = uv && (!document.documentMode || 9 < document.documentMode);
}
function N0() {
  ul && (ul.detachEvent("onpropertychange", NO), Ol = ul = null);
}
function NO(e) {
  if (e.propertyName === "value" && Cf(Ol)) {
    var t = [];
    MO(t, Ol, e, fm(e)), pO(BT, t);
  }
}
function KT(e, t, r) {
  e === "focusin" ? (N0(), ul = t, Ol = r, ul.attachEvent("onpropertychange", NO)) : e === "focusout" && N0();
}
function WT(e) {
  if (e === "selectionchange" || e === "keyup" || e === "keydown") return Cf(Ol);
}
function UT(e, t) {
  if (e === "click") return Cf(t);
}
function VT(e, t) {
  if (e === "input" || e === "change") return Cf(t);
}
function HT(e, t) {
  return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t;
}
var Tr = typeof Object.is == "function" ? Object.is : HT;
function Sl(e, t) {
  if (Tr(e, t)) return !0;
  if (typeof e != "object" || e === null || typeof t != "object" || t === null) return !1;
  var r = Object.keys(e), n = Object.keys(t);
  if (r.length !== n.length) return !1;
  for (n = 0; n < r.length; n++) {
    var i = r[n];
    if (!Jv.call(t, i) || !Tr(e[i], t[i])) return !1;
  }
  return !0;
}
function $0(e) {
  for (; e && e.firstChild; ) e = e.firstChild;
  return e;
}
function L0(e, t) {
  var r = $0(e);
  e = 0;
  for (var n; r; ) {
    if (r.nodeType === 3) {
      if (n = e + r.textContent.length, e <= t && n >= t) return { node: r, offset: t - e };
      e = n;
    }
    e: {
      for (; r; ) {
        if (r.nextSibling) {
          r = r.nextSibling;
          break e;
        }
        r = r.parentNode;
      }
      r = void 0;
    }
    r = $0(r);
  }
}
function $O(e, t) {
  return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? $O(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1;
}
function LO() {
  for (var e = window, t = Qs(); t instanceof e.HTMLIFrameElement; ) {
    try {
      var r = typeof t.contentWindow.location.href == "string";
    } catch {
      r = !1;
    }
    if (r) e = t.contentWindow;
    else break;
    t = Qs(e.document);
  }
  return t;
}
function xm(e) {
  var t = e && e.nodeName && e.nodeName.toLowerCase();
  return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true");
}
function XT(e) {
  var t = LO(), r = e.focusedElem, n = e.selectionRange;
  if (t !== r && r && r.ownerDocument && $O(r.ownerDocument.documentElement, r)) {
    if (n !== null && xm(r)) {
      if (t = n.start, e = n.end, e === void 0 && (e = t), "selectionStart" in r) r.selectionStart = t, r.selectionEnd = Math.min(e, r.value.length);
      else if (e = (t = r.ownerDocument || document) && t.defaultView || window, e.getSelection) {
        e = e.getSelection();
        var i = r.textContent.length, a = Math.min(n.start, i);
        n = n.end === void 0 ? a : Math.min(n.end, i), !e.extend && a > n && (i = n, n = a, a = i), i = L0(r, a);
        var o = L0(
          r,
          n
        );
        i && o && (e.rangeCount !== 1 || e.anchorNode !== i.node || e.anchorOffset !== i.offset || e.focusNode !== o.node || e.focusOffset !== o.offset) && (t = t.createRange(), t.setStart(i.node, i.offset), e.removeAllRanges(), a > n ? (e.addRange(t), e.extend(o.node, o.offset)) : (t.setEnd(o.node, o.offset), e.addRange(t)));
      }
    }
    for (t = [], e = r; e = e.parentNode; ) e.nodeType === 1 && t.push({ element: e, left: e.scrollLeft, top: e.scrollTop });
    for (typeof r.focus == "function" && r.focus(), r = 0; r < t.length; r++) e = t[r], e.element.scrollLeft = e.left, e.element.scrollTop = e.top;
  }
}
var YT = On && "documentMode" in document && 11 >= document.documentMode, ba = null, gp = null, sl = null, bp = !1;
function R0(e, t, r) {
  var n = r.window === r ? r.document : r.nodeType === 9 ? r : r.ownerDocument;
  bp || ba == null || ba !== Qs(n) || (n = ba, "selectionStart" in n && xm(n) ? n = { start: n.selectionStart, end: n.selectionEnd } : (n = (n.ownerDocument && n.ownerDocument.defaultView || window).getSelection(), n = { anchorNode: n.anchorNode, anchorOffset: n.anchorOffset, focusNode: n.focusNode, focusOffset: n.focusOffset }), sl && Sl(sl, n) || (sl = n, n = ac(gp, "onSelect"), 0 < n.length && (t = new ym("onSelect", "select", null, t, r), e.push({ event: t, listeners: n }), t.target = ba)));
}
function as(e, t) {
  var r = {};
  return r[e.toLowerCase()] = t.toLowerCase(), r["Webkit" + e] = "webkit" + t, r["Moz" + e] = "moz" + t, r;
}
var xa = { animationend: as("Animation", "AnimationEnd"), animationiteration: as("Animation", "AnimationIteration"), animationstart: as("Animation", "AnimationStart"), transitionend: as("Transition", "TransitionEnd") }, cv = {}, RO = {};
On && (RO = document.createElement("div").style, "AnimationEvent" in window || (delete xa.animationend.animation, delete xa.animationiteration.animation, delete xa.animationstart.animation), "TransitionEvent" in window || delete xa.transitionend.transition);
function Tf(e) {
  if (cv[e]) return cv[e];
  if (!xa[e]) return e;
  var t = xa[e], r;
  for (r in t) if (t.hasOwnProperty(r) && r in RO) return cv[e] = t[r];
  return e;
}
var zO = Tf("animationend"), BO = Tf("animationiteration"), FO = Tf("animationstart"), KO = Tf("transitionend"), WO = /* @__PURE__ */ new Map(), z0 = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
function di(e, t) {
  WO.set(e, t), na(t, [e]);
}
for (var fv = 0; fv < z0.length; fv++) {
  var dv = z0[fv], GT = dv.toLowerCase(), qT = dv[0].toUpperCase() + dv.slice(1);
  di(GT, "on" + qT);
}
di(zO, "onAnimationEnd");
di(BO, "onAnimationIteration");
di(FO, "onAnimationStart");
di("dblclick", "onDoubleClick");
di("focusin", "onFocus");
di("focusout", "onBlur");
di(KO, "onTransitionEnd");
Fa("onMouseEnter", ["mouseout", "mouseover"]);
Fa("onMouseLeave", ["mouseout", "mouseover"]);
Fa("onPointerEnter", ["pointerout", "pointerover"]);
Fa("onPointerLeave", ["pointerout", "pointerover"]);
na("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
na("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
na("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
na("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
na("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
na("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
var rl = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), ZT = new Set("cancel close invalid load scroll toggle".split(" ").concat(rl));
function B0(e, t, r) {
  var n = e.type || "unknown-event";
  e.currentTarget = r, GC(n, t, void 0, e), e.currentTarget = null;
}
function UO(e, t) {
  t = (t & 4) !== 0;
  for (var r = 0; r < e.length; r++) {
    var n = e[r], i = n.event;
    n = n.listeners;
    e: {
      var a = void 0;
      if (t) for (var o = n.length - 1; 0 <= o; o--) {
        var l = n[o], u = l.instance, s = l.currentTarget;
        if (l = l.listener, u !== a && i.isPropagationStopped()) break e;
        B0(i, l, s), a = u;
      }
      else for (o = 0; o < n.length; o++) {
        if (l = n[o], u = l.instance, s = l.currentTarget, l = l.listener, u !== a && i.isPropagationStopped()) break e;
        B0(i, l, s), a = u;
      }
    }
  }
  if (ec) throw e = pp, ec = !1, pp = null, e;
}
function Oe(e, t) {
  var r = t[Sp];
  r === void 0 && (r = t[Sp] = /* @__PURE__ */ new Set());
  var n = e + "__bubble";
  r.has(n) || (VO(t, e, 2, !1), r.add(n));
}
function vv(e, t, r) {
  var n = 0;
  t && (n |= 4), VO(r, e, n, t);
}
var os = "_reactListening" + Math.random().toString(36).slice(2);
function El(e) {
  if (!e[os]) {
    e[os] = !0, Q1.forEach(function(r) {
      r !== "selectionchange" && (ZT.has(r) || vv(r, !1, e), vv(r, !0, e));
    });
    var t = e.nodeType === 9 ? e : e.ownerDocument;
    t === null || t[os] || (t[os] = !0, vv("selectionchange", !1, t));
  }
}
function VO(e, t, r, n) {
  switch (_O(t)) {
    case 1:
      var i = fT;
      break;
    case 4:
      i = dT;
      break;
    default:
      i = hm;
  }
  r = i.bind(null, t, r, e), i = void 0, !vp || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (i = !0), n ? i !== void 0 ? e.addEventListener(t, r, { capture: !0, passive: i }) : e.addEventListener(t, r, !0) : i !== void 0 ? e.addEventListener(t, r, { passive: i }) : e.addEventListener(t, r, !1);
}
function pv(e, t, r, n, i) {
  var a = n;
  if (!(t & 1) && !(t & 2) && n !== null) e: for (; ; ) {
    if (n === null) return;
    var o = n.tag;
    if (o === 3 || o === 4) {
      var l = n.stateNode.containerInfo;
      if (l === i || l.nodeType === 8 && l.parentNode === i) break;
      if (o === 4) for (o = n.return; o !== null; ) {
        var u = o.tag;
        if ((u === 3 || u === 4) && (u = o.stateNode.containerInfo, u === i || u.nodeType === 8 && u.parentNode === i)) return;
        o = o.return;
      }
      for (; l !== null; ) {
        if (o = _i(l), o === null) return;
        if (u = o.tag, u === 5 || u === 6) {
          n = a = o;
          continue e;
        }
        l = l.parentNode;
      }
    }
    n = n.return;
  }
  pO(function() {
    var s = a, c = fm(r), f = [];
    e: {
      var v = WO.get(e);
      if (v !== void 0) {
        var p = ym, h = e;
        switch (e) {
          case "keypress":
            if (Ls(r) === 0) break e;
          case "keydown":
          case "keyup":
            p = kT;
            break;
          case "focusin":
            h = "focus", p = lv;
            break;
          case "focusout":
            h = "blur", p = lv;
            break;
          case "beforeblur":
          case "afterblur":
            p = lv;
            break;
          case "click":
            if (r.button === 2) break e;
          case "auxclick":
          case "dblclick":
          case "mousedown":
          case "mousemove":
          case "mouseup":
          case "mouseout":
          case "mouseover":
          case "contextmenu":
            p = _0;
            break;
          case "drag":
          case "dragend":
          case "dragenter":
          case "dragexit":
          case "dragleave":
          case "dragover":
          case "dragstart":
          case "drop":
            p = hT;
            break;
          case "touchcancel":
          case "touchend":
          case "touchmove":
          case "touchstart":
            p = jT;
            break;
          case zO:
          case BO:
          case FO:
            p = gT;
            break;
          case KO:
            p = TT;
            break;
          case "scroll":
            p = vT;
            break;
          case "wheel":
            p = DT;
            break;
          case "copy":
          case "cut":
          case "paste":
            p = xT;
            break;
          case "gotpointercapture":
          case "lostpointercapture":
          case "pointercancel":
          case "pointerdown":
          case "pointermove":
          case "pointerout":
          case "pointerover":
          case "pointerup":
            p = j0;
        }
        var y = (t & 4) !== 0, g = !y && e === "scroll", m = y ? v !== null ? v + "Capture" : null : v;
        y = [];
        for (var b = s, x; b !== null; ) {
          x = b;
          var w = x.stateNode;
          if (x.tag === 5 && w !== null && (x = w, m !== null && (w = bl(b, m), w != null && y.push(Al(b, w, x)))), g) break;
          b = b.return;
        }
        0 < y.length && (v = new p(v, h, null, r, c), f.push({ event: v, listeners: y }));
      }
    }
    if (!(t & 7)) {
      e: {
        if (v = e === "mouseover" || e === "pointerover", p = e === "mouseout" || e === "pointerout", v && r !== fp && (h = r.relatedTarget || r.fromElement) && (_i(h) || h[Sn])) break e;
        if ((p || v) && (v = c.window === c ? c : (v = c.ownerDocument) ? v.defaultView || v.parentWindow : window, p ? (h = r.relatedTarget || r.toElement, p = s, h = h ? _i(h) : null, h !== null && (g = ia(h), h !== g || h.tag !== 5 && h.tag !== 6) && (h = null)) : (p = null, h = s), p !== h)) {
          if (y = _0, w = "onMouseLeave", m = "onMouseEnter", b = "mouse", (e === "pointerout" || e === "pointerover") && (y = j0, w = "onPointerLeave", m = "onPointerEnter", b = "pointer"), g = p == null ? v : wa(p), x = h == null ? v : wa(h), v = new y(w, b + "leave", p, r, c), v.target = g, v.relatedTarget = x, w = null, _i(c) === s && (y = new y(m, b + "enter", h, r, c), y.target = x, y.relatedTarget = g, w = y), g = w, p && h) t: {
            for (y = p, m = h, b = 0, x = y; x; x = fa(x)) b++;
            for (x = 0, w = m; w; w = fa(w)) x++;
            for (; 0 < b - x; ) y = fa(y), b--;
            for (; 0 < x - b; ) m = fa(m), x--;
            for (; b--; ) {
              if (y === m || m !== null && y === m.alternate) break t;
              y = fa(y), m = fa(m);
            }
            y = null;
          }
          else y = null;
          p !== null && F0(f, v, p, y, !1), h !== null && g !== null && F0(f, g, h, y, !0);
        }
      }
      e: {
        if (v = s ? wa(s) : window, p = v.nodeName && v.nodeName.toLowerCase(), p === "select" || p === "input" && v.type === "file") var P = FT;
        else if (M0(v)) if (DO) P = VT;
        else {
          P = WT;
          var O = KT;
        }
        else (p = v.nodeName) && p.toLowerCase() === "input" && (v.type === "checkbox" || v.type === "radio") && (P = UT);
        if (P && (P = P(e, s))) {
          MO(f, P, r, c);
          break e;
        }
        O && O(e, v, s), e === "focusout" && (O = v._wrapperState) && O.controlled && v.type === "number" && op(v, "number", v.value);
      }
      switch (O = s ? wa(s) : window, e) {
        case "focusin":
          (M0(O) || O.contentEditable === "true") && (ba = O, gp = s, sl = null);
          break;
        case "focusout":
          sl = gp = ba = null;
          break;
        case "mousedown":
          bp = !0;
          break;
        case "contextmenu":
        case "mouseup":
        case "dragend":
          bp = !1, R0(f, r, c);
          break;
        case "selectionchange":
          if (YT) break;
        case "keydown":
        case "keyup":
          R0(f, r, c);
      }
      var S;
      if (bm) e: {
        switch (e) {
          case "compositionstart":
            var E = "onCompositionStart";
            break e;
          case "compositionend":
            E = "onCompositionEnd";
            break e;
          case "compositionupdate":
            E = "onCompositionUpdate";
            break e;
        }
        E = void 0;
      }
      else ga ? CO(e, r) && (E = "onCompositionEnd") : e === "keydown" && r.keyCode === 229 && (E = "onCompositionStart");
      E && (jO && r.locale !== "ko" && (ga || E !== "onCompositionStart" ? E === "onCompositionEnd" && ga && (S = IO()) : (Gn = c, mm = "value" in Gn ? Gn.value : Gn.textContent, ga = !0)), O = ac(s, E), 0 < O.length && (E = new I0(E, e, null, r, c), f.push({ event: E, listeners: O }), S ? E.data = S : (S = TO(r), S !== null && (E.data = S)))), (S = $T ? LT(e, r) : RT(e, r)) && (s = ac(s, "onBeforeInput"), 0 < s.length && (c = new I0("onBeforeInput", "beforeinput", null, r, c), f.push({ event: c, listeners: s }), c.data = S));
    }
    UO(f, t);
  });
}
function Al(e, t, r) {
  return { instance: e, listener: t, currentTarget: r };
}
function ac(e, t) {
  for (var r = t + "Capture", n = []; e !== null; ) {
    var i = e, a = i.stateNode;
    i.tag === 5 && a !== null && (i = a, a = bl(e, r), a != null && n.unshift(Al(e, a, i)), a = bl(e, t), a != null && n.push(Al(e, a, i))), e = e.return;
  }
  return n;
}
function fa(e) {
  if (e === null) return null;
  do
    e = e.return;
  while (e && e.tag !== 5);
  return e || null;
}
function F0(e, t, r, n, i) {
  for (var a = t._reactName, o = []; r !== null && r !== n; ) {
    var l = r, u = l.alternate, s = l.stateNode;
    if (u !== null && u === n) break;
    l.tag === 5 && s !== null && (l = s, i ? (u = bl(r, a), u != null && o.unshift(Al(r, u, l))) : i || (u = bl(r, a), u != null && o.push(Al(r, u, l)))), r = r.return;
  }
  o.length !== 0 && e.push({ event: t, listeners: o });
}
var QT = /\r\n?/g, JT = /\u0000|\uFFFD/g;
function K0(e) {
  return (typeof e == "string" ? e : "" + e).replace(QT, `
`).replace(JT, "");
}
function ls(e, t, r) {
  if (t = K0(t), K0(e) !== t && r) throw Error($(425));
}
function oc() {
}
var xp = null, wp = null;
function Pp(e, t) {
  return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null;
}
var Op = typeof setTimeout == "function" ? setTimeout : void 0, eM = typeof clearTimeout == "function" ? clearTimeout : void 0, W0 = typeof Promise == "function" ? Promise : void 0, tM = typeof queueMicrotask == "function" ? queueMicrotask : typeof W0 < "u" ? function(e) {
  return W0.resolve(null).then(e).catch(rM);
} : Op;
function rM(e) {
  setTimeout(function() {
    throw e;
  });
}
function hv(e, t) {
  var r = t, n = 0;
  do {
    var i = r.nextSibling;
    if (e.removeChild(r), i && i.nodeType === 8) if (r = i.data, r === "/$") {
      if (n === 0) {
        e.removeChild(i), Pl(t);
        return;
      }
      n--;
    } else r !== "$" && r !== "$?" && r !== "$!" || n++;
    r = i;
  } while (r);
  Pl(t);
}
function ti(e) {
  for (; e != null; e = e.nextSibling) {
    var t = e.nodeType;
    if (t === 1 || t === 3) break;
    if (t === 8) {
      if (t = e.data, t === "$" || t === "$!" || t === "$?") break;
      if (t === "/$") return null;
    }
  }
  return e;
}
function U0(e) {
  e = e.previousSibling;
  for (var t = 0; e; ) {
    if (e.nodeType === 8) {
      var r = e.data;
      if (r === "$" || r === "$!" || r === "$?") {
        if (t === 0) return e;
        t--;
      } else r === "/$" && t++;
    }
    e = e.previousSibling;
  }
  return null;
}
var so = Math.random().toString(36).slice(2), Fr = "__reactFiber$" + so, kl = "__reactProps$" + so, Sn = "__reactContainer$" + so, Sp = "__reactEvents$" + so, nM = "__reactListeners$" + so, iM = "__reactHandles$" + so;
function _i(e) {
  var t = e[Fr];
  if (t) return t;
  for (var r = e.parentNode; r; ) {
    if (t = r[Sn] || r[Fr]) {
      if (r = t.alternate, t.child !== null || r !== null && r.child !== null) for (e = U0(e); e !== null; ) {
        if (r = e[Fr]) return r;
        e = U0(e);
      }
      return t;
    }
    e = r, r = e.parentNode;
  }
  return null;
}
function iu(e) {
  return e = e[Fr] || e[Sn], !e || e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3 ? null : e;
}
function wa(e) {
  if (e.tag === 5 || e.tag === 6) return e.stateNode;
  throw Error($(33));
}
function Mf(e) {
  return e[kl] || null;
}
var Ep = [], Pa = -1;
function vi(e) {
  return { current: e };
}
function Ee(e) {
  0 > Pa || (e.current = Ep[Pa], Ep[Pa] = null, Pa--);
}
function Pe(e, t) {
  Pa++, Ep[Pa] = e.current, e.current = t;
}
var ui = {}, wt = vi(ui), Lt = vi(!1), Ki = ui;
function Ka(e, t) {
  var r = e.type.contextTypes;
  if (!r) return ui;
  var n = e.stateNode;
  if (n && n.__reactInternalMemoizedUnmaskedChildContext === t) return n.__reactInternalMemoizedMaskedChildContext;
  var i = {}, a;
  for (a in r) i[a] = t[a];
  return n && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = t, e.__reactInternalMemoizedMaskedChildContext = i), i;
}
function Rt(e) {
  return e = e.childContextTypes, e != null;
}
function lc() {
  Ee(Lt), Ee(wt);
}
function V0(e, t, r) {
  if (wt.current !== ui) throw Error($(168));
  Pe(wt, t), Pe(Lt, r);
}
function HO(e, t, r) {
  var n = e.stateNode;
  if (t = t.childContextTypes, typeof n.getChildContext != "function") return r;
  n = n.getChildContext();
  for (var i in n) if (!(i in t)) throw Error($(108, KC(e) || "Unknown", i));
  return De({}, r, n);
}
function uc(e) {
  return e = (e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext || ui, Ki = wt.current, Pe(wt, e), Pe(Lt, Lt.current), !0;
}
function H0(e, t, r) {
  var n = e.stateNode;
  if (!n) throw Error($(169));
  r ? (e = HO(e, t, Ki), n.__reactInternalMemoizedMergedChildContext = e, Ee(Lt), Ee(wt), Pe(wt, e)) : Ee(Lt), Pe(Lt, r);
}
var fn = null, Df = !1, mv = !1;
function XO(e) {
  fn === null ? fn = [e] : fn.push(e);
}
function aM(e) {
  Df = !0, XO(e);
}
function pi() {
  if (!mv && fn !== null) {
    mv = !0;
    var e = 0, t = ve;
    try {
      var r = fn;
      for (ve = 1; e < r.length; e++) {
        var n = r[e];
        do
          n = n(!0);
        while (n !== null);
      }
      fn = null, Df = !1;
    } catch (i) {
      throw fn !== null && (fn = fn.slice(e + 1)), gO(dm, pi), i;
    } finally {
      ve = t, mv = !1;
    }
  }
  return null;
}
var Oa = [], Sa = 0, sc = null, cc = 0, sr = [], cr = 0, Wi = null, pn = 1, hn = "";
function Pi(e, t) {
  Oa[Sa++] = cc, Oa[Sa++] = sc, sc = e, cc = t;
}
function YO(e, t, r) {
  sr[cr++] = pn, sr[cr++] = hn, sr[cr++] = Wi, Wi = e;
  var n = pn;
  e = hn;
  var i = 32 - Ir(n) - 1;
  n &= ~(1 << i), r += 1;
  var a = 32 - Ir(t) + i;
  if (30 < a) {
    var o = i - i % 5;
    a = (n & (1 << o) - 1).toString(32), n >>= o, i -= o, pn = 1 << 32 - Ir(t) + i | r << i | n, hn = a + e;
  } else pn = 1 << a | r << i | n, hn = e;
}
function wm(e) {
  e.return !== null && (Pi(e, 1), YO(e, 1, 0));
}
function Pm(e) {
  for (; e === sc; ) sc = Oa[--Sa], Oa[Sa] = null, cc = Oa[--Sa], Oa[Sa] = null;
  for (; e === Wi; ) Wi = sr[--cr], sr[cr] = null, hn = sr[--cr], sr[cr] = null, pn = sr[--cr], sr[cr] = null;
}
var Zt = null, Gt = null, _e = !1, Sr = null;
function GO(e, t) {
  var r = fr(5, null, null, 0);
  r.elementType = "DELETED", r.stateNode = t, r.return = e, t = e.deletions, t === null ? (e.deletions = [r], e.flags |= 16) : t.push(r);
}
function X0(e, t) {
  switch (e.tag) {
    case 5:
      var r = e.type;
      return t = t.nodeType !== 1 || r.toLowerCase() !== t.nodeName.toLowerCase() ? null : t, t !== null ? (e.stateNode = t, Zt = e, Gt = ti(t.firstChild), !0) : !1;
    case 6:
      return t = e.pendingProps === "" || t.nodeType !== 3 ? null : t, t !== null ? (e.stateNode = t, Zt = e, Gt = null, !0) : !1;
    case 13:
      return t = t.nodeType !== 8 ? null : t, t !== null ? (r = Wi !== null ? { id: pn, overflow: hn } : null, e.memoizedState = { dehydrated: t, treeContext: r, retryLane: 1073741824 }, r = fr(18, null, null, 0), r.stateNode = t, r.return = e, e.child = r, Zt = e, Gt = null, !0) : !1;
    default:
      return !1;
  }
}
function Ap(e) {
  return (e.mode & 1) !== 0 && (e.flags & 128) === 0;
}
function kp(e) {
  if (_e) {
    var t = Gt;
    if (t) {
      var r = t;
      if (!X0(e, t)) {
        if (Ap(e)) throw Error($(418));
        t = ti(r.nextSibling);
        var n = Zt;
        t && X0(e, t) ? GO(n, r) : (e.flags = e.flags & -4097 | 2, _e = !1, Zt = e);
      }
    } else {
      if (Ap(e)) throw Error($(418));
      e.flags = e.flags & -4097 | 2, _e = !1, Zt = e;
    }
  }
}
function Y0(e) {
  for (e = e.return; e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13; ) e = e.return;
  Zt = e;
}
function us(e) {
  if (e !== Zt) return !1;
  if (!_e) return Y0(e), _e = !0, !1;
  var t;
  if ((t = e.tag !== 3) && !(t = e.tag !== 5) && (t = e.type, t = t !== "head" && t !== "body" && !Pp(e.type, e.memoizedProps)), t && (t = Gt)) {
    if (Ap(e)) throw qO(), Error($(418));
    for (; t; ) GO(e, t), t = ti(t.nextSibling);
  }
  if (Y0(e), e.tag === 13) {
    if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error($(317));
    e: {
      for (e = e.nextSibling, t = 0; e; ) {
        if (e.nodeType === 8) {
          var r = e.data;
          if (r === "/$") {
            if (t === 0) {
              Gt = ti(e.nextSibling);
              break e;
            }
            t--;
          } else r !== "$" && r !== "$!" && r !== "$?" || t++;
        }
        e = e.nextSibling;
      }
      Gt = null;
    }
  } else Gt = Zt ? ti(e.stateNode.nextSibling) : null;
  return !0;
}
function qO() {
  for (var e = Gt; e; ) e = ti(e.nextSibling);
}
function Wa() {
  Gt = Zt = null, _e = !1;
}
function Om(e) {
  Sr === null ? Sr = [e] : Sr.push(e);
}
var oM = Dn.ReactCurrentBatchConfig;
function Fo(e, t, r) {
  if (e = r.ref, e !== null && typeof e != "function" && typeof e != "object") {
    if (r._owner) {
      if (r = r._owner, r) {
        if (r.tag !== 1) throw Error($(309));
        var n = r.stateNode;
      }
      if (!n) throw Error($(147, e));
      var i = n, a = "" + e;
      return t !== null && t.ref !== null && typeof t.ref == "function" && t.ref._stringRef === a ? t.ref : (t = function(o) {
        var l = i.refs;
        o === null ? delete l[a] : l[a] = o;
      }, t._stringRef = a, t);
    }
    if (typeof e != "string") throw Error($(284));
    if (!r._owner) throw Error($(290, e));
  }
  return e;
}
function ss(e, t) {
  throw e = Object.prototype.toString.call(t), Error($(31, e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e));
}
function G0(e) {
  var t = e._init;
  return t(e._payload);
}
function ZO(e) {
  function t(m, b) {
    if (e) {
      var x = m.deletions;
      x === null ? (m.deletions = [b], m.flags |= 16) : x.push(b);
    }
  }
  function r(m, b) {
    if (!e) return null;
    for (; b !== null; ) t(m, b), b = b.sibling;
    return null;
  }
  function n(m, b) {
    for (m = /* @__PURE__ */ new Map(); b !== null; ) b.key !== null ? m.set(b.key, b) : m.set(b.index, b), b = b.sibling;
    return m;
  }
  function i(m, b) {
    return m = ai(m, b), m.index = 0, m.sibling = null, m;
  }
  function a(m, b, x) {
    return m.index = x, e ? (x = m.alternate, x !== null ? (x = x.index, x < b ? (m.flags |= 2, b) : x) : (m.flags |= 2, b)) : (m.flags |= 1048576, b);
  }
  function o(m) {
    return e && m.alternate === null && (m.flags |= 2), m;
  }
  function l(m, b, x, w) {
    return b === null || b.tag !== 6 ? (b = Ov(x, m.mode, w), b.return = m, b) : (b = i(b, x), b.return = m, b);
  }
  function u(m, b, x, w) {
    var P = x.type;
    return P === ya ? c(m, b, x.props.children, w, x.key) : b !== null && (b.elementType === P || typeof P == "object" && P !== null && P.$$typeof === Kn && G0(P) === b.type) ? (w = i(b, x.props), w.ref = Fo(m, b, x), w.return = m, w) : (w = Us(x.type, x.key, x.props, null, m.mode, w), w.ref = Fo(m, b, x), w.return = m, w);
  }
  function s(m, b, x, w) {
    return b === null || b.tag !== 4 || b.stateNode.containerInfo !== x.containerInfo || b.stateNode.implementation !== x.implementation ? (b = Sv(x, m.mode, w), b.return = m, b) : (b = i(b, x.children || []), b.return = m, b);
  }
  function c(m, b, x, w, P) {
    return b === null || b.tag !== 7 ? (b = $i(x, m.mode, w, P), b.return = m, b) : (b = i(b, x), b.return = m, b);
  }
  function f(m, b, x) {
    if (typeof b == "string" && b !== "" || typeof b == "number") return b = Ov("" + b, m.mode, x), b.return = m, b;
    if (typeof b == "object" && b !== null) {
      switch (b.$$typeof) {
        case Qu:
          return x = Us(b.type, b.key, b.props, null, m.mode, x), x.ref = Fo(m, null, b), x.return = m, x;
        case ma:
          return b = Sv(b, m.mode, x), b.return = m, b;
        case Kn:
          var w = b._init;
          return f(m, w(b._payload), x);
      }
      if (el(b) || $o(b)) return b = $i(b, m.mode, x, null), b.return = m, b;
      ss(m, b);
    }
    return null;
  }
  function v(m, b, x, w) {
    var P = b !== null ? b.key : null;
    if (typeof x == "string" && x !== "" || typeof x == "number") return P !== null ? null : l(m, b, "" + x, w);
    if (typeof x == "object" && x !== null) {
      switch (x.$$typeof) {
        case Qu:
          return x.key === P ? u(m, b, x, w) : null;
        case ma:
          return x.key === P ? s(m, b, x, w) : null;
        case Kn:
          return P = x._init, v(
            m,
            b,
            P(x._payload),
            w
          );
      }
      if (el(x) || $o(x)) return P !== null ? null : c(m, b, x, w, null);
      ss(m, x);
    }
    return null;
  }
  function p(m, b, x, w, P) {
    if (typeof w == "string" && w !== "" || typeof w == "number") return m = m.get(x) || null, l(b, m, "" + w, P);
    if (typeof w == "object" && w !== null) {
      switch (w.$$typeof) {
        case Qu:
          return m = m.get(w.key === null ? x : w.key) || null, u(b, m, w, P);
        case ma:
          return m = m.get(w.key === null ? x : w.key) || null, s(b, m, w, P);
        case Kn:
          var O = w._init;
          return p(m, b, x, O(w._payload), P);
      }
      if (el(w) || $o(w)) return m = m.get(x) || null, c(b, m, w, P, null);
      ss(b, w);
    }
    return null;
  }
  function h(m, b, x, w) {
    for (var P = null, O = null, S = b, E = b = 0, k = null; S !== null && E < x.length; E++) {
      S.index > E ? (k = S, S = null) : k = S.sibling;
      var _ = v(m, S, x[E], w);
      if (_ === null) {
        S === null && (S = k);
        break;
      }
      e && S && _.alternate === null && t(m, S), b = a(_, b, E), O === null ? P = _ : O.sibling = _, O = _, S = k;
    }
    if (E === x.length) return r(m, S), _e && Pi(m, E), P;
    if (S === null) {
      for (; E < x.length; E++) S = f(m, x[E], w), S !== null && (b = a(S, b, E), O === null ? P = S : O.sibling = S, O = S);
      return _e && Pi(m, E), P;
    }
    for (S = n(m, S); E < x.length; E++) k = p(S, m, E, x[E], w), k !== null && (e && k.alternate !== null && S.delete(k.key === null ? E : k.key), b = a(k, b, E), O === null ? P = k : O.sibling = k, O = k);
    return e && S.forEach(function(I) {
      return t(m, I);
    }), _e && Pi(m, E), P;
  }
  function y(m, b, x, w) {
    var P = $o(x);
    if (typeof P != "function") throw Error($(150));
    if (x = P.call(x), x == null) throw Error($(151));
    for (var O = P = null, S = b, E = b = 0, k = null, _ = x.next(); S !== null && !_.done; E++, _ = x.next()) {
      S.index > E ? (k = S, S = null) : k = S.sibling;
      var I = v(m, S, _.value, w);
      if (I === null) {
        S === null && (S = k);
        break;
      }
      e && S && I.alternate === null && t(m, S), b = a(I, b, E), O === null ? P = I : O.sibling = I, O = I, S = k;
    }
    if (_.done) return r(
      m,
      S
    ), _e && Pi(m, E), P;
    if (S === null) {
      for (; !_.done; E++, _ = x.next()) _ = f(m, _.value, w), _ !== null && (b = a(_, b, E), O === null ? P = _ : O.sibling = _, O = _);
      return _e && Pi(m, E), P;
    }
    for (S = n(m, S); !_.done; E++, _ = x.next()) _ = p(S, m, E, _.value, w), _ !== null && (e && _.alternate !== null && S.delete(_.key === null ? E : _.key), b = a(_, b, E), O === null ? P = _ : O.sibling = _, O = _);
    return e && S.forEach(function(j) {
      return t(m, j);
    }), _e && Pi(m, E), P;
  }
  function g(m, b, x, w) {
    if (typeof x == "object" && x !== null && x.type === ya && x.key === null && (x = x.props.children), typeof x == "object" && x !== null) {
      switch (x.$$typeof) {
        case Qu:
          e: {
            for (var P = x.key, O = b; O !== null; ) {
              if (O.key === P) {
                if (P = x.type, P === ya) {
                  if (O.tag === 7) {
                    r(m, O.sibling), b = i(O, x.props.children), b.return = m, m = b;
                    break e;
                  }
                } else if (O.elementType === P || typeof P == "object" && P !== null && P.$$typeof === Kn && G0(P) === O.type) {
                  r(m, O.sibling), b = i(O, x.props), b.ref = Fo(m, O, x), b.return = m, m = b;
                  break e;
                }
                r(m, O);
                break;
              } else t(m, O);
              O = O.sibling;
            }
            x.type === ya ? (b = $i(x.props.children, m.mode, w, x.key), b.return = m, m = b) : (w = Us(x.type, x.key, x.props, null, m.mode, w), w.ref = Fo(m, b, x), w.return = m, m = w);
          }
          return o(m);
        case ma:
          e: {
            for (O = x.key; b !== null; ) {
              if (b.key === O) if (b.tag === 4 && b.stateNode.containerInfo === x.containerInfo && b.stateNode.implementation === x.implementation) {
                r(m, b.sibling), b = i(b, x.children || []), b.return = m, m = b;
                break e;
              } else {
                r(m, b);
                break;
              }
              else t(m, b);
              b = b.sibling;
            }
            b = Sv(x, m.mode, w), b.return = m, m = b;
          }
          return o(m);
        case Kn:
          return O = x._init, g(m, b, O(x._payload), w);
      }
      if (el(x)) return h(m, b, x, w);
      if ($o(x)) return y(m, b, x, w);
      ss(m, x);
    }
    return typeof x == "string" && x !== "" || typeof x == "number" ? (x = "" + x, b !== null && b.tag === 6 ? (r(m, b.sibling), b = i(b, x), b.return = m, m = b) : (r(m, b), b = Ov(x, m.mode, w), b.return = m, m = b), o(m)) : r(m, b);
  }
  return g;
}
var Ua = ZO(!0), QO = ZO(!1), fc = vi(null), dc = null, Ea = null, Sm = null;
function Em() {
  Sm = Ea = dc = null;
}
function Am(e) {
  var t = fc.current;
  Ee(fc), e._currentValue = t;
}
function _p(e, t, r) {
  for (; e !== null; ) {
    var n = e.alternate;
    if ((e.childLanes & t) !== t ? (e.childLanes |= t, n !== null && (n.childLanes |= t)) : n !== null && (n.childLanes & t) !== t && (n.childLanes |= t), e === r) break;
    e = e.return;
  }
}
function $a(e, t) {
  dc = e, Sm = Ea = null, e = e.dependencies, e !== null && e.firstContext !== null && (e.lanes & t && (Mt = !0), e.firstContext = null);
}
function pr(e) {
  var t = e._currentValue;
  if (Sm !== e) if (e = { context: e, memoizedValue: t, next: null }, Ea === null) {
    if (dc === null) throw Error($(308));
    Ea = e, dc.dependencies = { lanes: 0, firstContext: e };
  } else Ea = Ea.next = e;
  return t;
}
var Ii = null;
function km(e) {
  Ii === null ? Ii = [e] : Ii.push(e);
}
function JO(e, t, r, n) {
  var i = t.interleaved;
  return i === null ? (r.next = r, km(t)) : (r.next = i.next, i.next = r), t.interleaved = r, En(e, n);
}
function En(e, t) {
  e.lanes |= t;
  var r = e.alternate;
  for (r !== null && (r.lanes |= t), r = e, e = e.return; e !== null; ) e.childLanes |= t, r = e.alternate, r !== null && (r.childLanes |= t), r = e, e = e.return;
  return r.tag === 3 ? r.stateNode : null;
}
var Wn = !1;
function _m(e) {
  e.updateQueue = { baseState: e.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: { pending: null, interleaved: null, lanes: 0 }, effects: null };
}
function eS(e, t) {
  e = e.updateQueue, t.updateQueue === e && (t.updateQueue = { baseState: e.baseState, firstBaseUpdate: e.firstBaseUpdate, lastBaseUpdate: e.lastBaseUpdate, shared: e.shared, effects: e.effects });
}
function xn(e, t) {
  return { eventTime: e, lane: t, tag: 0, payload: null, callback: null, next: null };
}
function ri(e, t, r) {
  var n = e.updateQueue;
  if (n === null) return null;
  if (n = n.shared, ae & 2) {
    var i = n.pending;
    return i === null ? t.next = t : (t.next = i.next, i.next = t), n.pending = t, En(e, r);
  }
  return i = n.interleaved, i === null ? (t.next = t, km(n)) : (t.next = i.next, i.next = t), n.interleaved = t, En(e, r);
}
function Rs(e, t, r) {
  if (t = t.updateQueue, t !== null && (t = t.shared, (r & 4194240) !== 0)) {
    var n = t.lanes;
    n &= e.pendingLanes, r |= n, t.lanes = r, vm(e, r);
  }
}
function q0(e, t) {
  var r = e.updateQueue, n = e.alternate;
  if (n !== null && (n = n.updateQueue, r === n)) {
    var i = null, a = null;
    if (r = r.firstBaseUpdate, r !== null) {
      do {
        var o = { eventTime: r.eventTime, lane: r.lane, tag: r.tag, payload: r.payload, callback: r.callback, next: null };
        a === null ? i = a = o : a = a.next = o, r = r.next;
      } while (r !== null);
      a === null ? i = a = t : a = a.next = t;
    } else i = a = t;
    r = { baseState: n.baseState, firstBaseUpdate: i, lastBaseUpdate: a, shared: n.shared, effects: n.effects }, e.updateQueue = r;
    return;
  }
  e = r.lastBaseUpdate, e === null ? r.firstBaseUpdate = t : e.next = t, r.lastBaseUpdate = t;
}
function vc(e, t, r, n) {
  var i = e.updateQueue;
  Wn = !1;
  var a = i.firstBaseUpdate, o = i.lastBaseUpdate, l = i.shared.pending;
  if (l !== null) {
    i.shared.pending = null;
    var u = l, s = u.next;
    u.next = null, o === null ? a = s : o.next = s, o = u;
    var c = e.alternate;
    c !== null && (c = c.updateQueue, l = c.lastBaseUpdate, l !== o && (l === null ? c.firstBaseUpdate = s : l.next = s, c.lastBaseUpdate = u));
  }
  if (a !== null) {
    var f = i.baseState;
    o = 0, c = s = u = null, l = a;
    do {
      var v = l.lane, p = l.eventTime;
      if ((n & v) === v) {
        c !== null && (c = c.next = {
          eventTime: p,
          lane: 0,
          tag: l.tag,
          payload: l.payload,
          callback: l.callback,
          next: null
        });
        e: {
          var h = e, y = l;
          switch (v = t, p = r, y.tag) {
            case 1:
              if (h = y.payload, typeof h == "function") {
                f = h.call(p, f, v);
                break e;
              }
              f = h;
              break e;
            case 3:
              h.flags = h.flags & -65537 | 128;
            case 0:
              if (h = y.payload, v = typeof h == "function" ? h.call(p, f, v) : h, v == null) break e;
              f = De({}, f, v);
              break e;
            case 2:
              Wn = !0;
          }
        }
        l.callback !== null && l.lane !== 0 && (e.flags |= 64, v = i.effects, v === null ? i.effects = [l] : v.push(l));
      } else p = { eventTime: p, lane: v, tag: l.tag, payload: l.payload, callback: l.callback, next: null }, c === null ? (s = c = p, u = f) : c = c.next = p, o |= v;
      if (l = l.next, l === null) {
        if (l = i.shared.pending, l === null) break;
        v = l, l = v.next, v.next = null, i.lastBaseUpdate = v, i.shared.pending = null;
      }
    } while (!0);
    if (c === null && (u = f), i.baseState = u, i.firstBaseUpdate = s, i.lastBaseUpdate = c, t = i.shared.interleaved, t !== null) {
      i = t;
      do
        o |= i.lane, i = i.next;
      while (i !== t);
    } else a === null && (i.shared.lanes = 0);
    Vi |= o, e.lanes = o, e.memoizedState = f;
  }
}
function Z0(e, t, r) {
  if (e = t.effects, t.effects = null, e !== null) for (t = 0; t < e.length; t++) {
    var n = e[t], i = n.callback;
    if (i !== null) {
      if (n.callback = null, n = r, typeof i != "function") throw Error($(191, i));
      i.call(n);
    }
  }
}
var au = {}, Hr = vi(au), _l = vi(au), Il = vi(au);
function ji(e) {
  if (e === au) throw Error($(174));
  return e;
}
function Im(e, t) {
  switch (Pe(Il, t), Pe(_l, e), Pe(Hr, au), e = t.nodeType, e) {
    case 9:
    case 11:
      t = (t = t.documentElement) ? t.namespaceURI : up(null, "");
      break;
    default:
      e = e === 8 ? t.parentNode : t, t = e.namespaceURI || null, e = e.tagName, t = up(t, e);
  }
  Ee(Hr), Pe(Hr, t);
}
function Va() {
  Ee(Hr), Ee(_l), Ee(Il);
}
function tS(e) {
  ji(Il.current);
  var t = ji(Hr.current), r = up(t, e.type);
  t !== r && (Pe(_l, e), Pe(Hr, r));
}
function jm(e) {
  _l.current === e && (Ee(Hr), Ee(_l));
}
var Te = vi(0);
function pc(e) {
  for (var t = e; t !== null; ) {
    if (t.tag === 13) {
      var r = t.memoizedState;
      if (r !== null && (r = r.dehydrated, r === null || r.data === "$?" || r.data === "$!")) return t;
    } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
      if (t.flags & 128) return t;
    } else if (t.child !== null) {
      t.child.return = t, t = t.child;
      continue;
    }
    if (t === e) break;
    for (; t.sibling === null; ) {
      if (t.return === null || t.return === e) return null;
      t = t.return;
    }
    t.sibling.return = t.return, t = t.sibling;
  }
  return null;
}
var yv = [];
function Cm() {
  for (var e = 0; e < yv.length; e++) yv[e]._workInProgressVersionPrimary = null;
  yv.length = 0;
}
var zs = Dn.ReactCurrentDispatcher, gv = Dn.ReactCurrentBatchConfig, Ui = 0, Me = null, Ye = null, nt = null, hc = !1, cl = !1, jl = 0, lM = 0;
function pt() {
  throw Error($(321));
}
function Tm(e, t) {
  if (t === null) return !1;
  for (var r = 0; r < t.length && r < e.length; r++) if (!Tr(e[r], t[r])) return !1;
  return !0;
}
function Mm(e, t, r, n, i, a) {
  if (Ui = a, Me = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, zs.current = e === null || e.memoizedState === null ? fM : dM, e = r(n, i), cl) {
    a = 0;
    do {
      if (cl = !1, jl = 0, 25 <= a) throw Error($(301));
      a += 1, nt = Ye = null, t.updateQueue = null, zs.current = vM, e = r(n, i);
    } while (cl);
  }
  if (zs.current = mc, t = Ye !== null && Ye.next !== null, Ui = 0, nt = Ye = Me = null, hc = !1, t) throw Error($(300));
  return e;
}
function Dm() {
  var e = jl !== 0;
  return jl = 0, e;
}
function zr() {
  var e = { memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null };
  return nt === null ? Me.memoizedState = nt = e : nt = nt.next = e, nt;
}
function hr() {
  if (Ye === null) {
    var e = Me.alternate;
    e = e !== null ? e.memoizedState : null;
  } else e = Ye.next;
  var t = nt === null ? Me.memoizedState : nt.next;
  if (t !== null) nt = t, Ye = e;
  else {
    if (e === null) throw Error($(310));
    Ye = e, e = { memoizedState: Ye.memoizedState, baseState: Ye.baseState, baseQueue: Ye.baseQueue, queue: Ye.queue, next: null }, nt === null ? Me.memoizedState = nt = e : nt = nt.next = e;
  }
  return nt;
}
function Cl(e, t) {
  return typeof t == "function" ? t(e) : t;
}
function bv(e) {
  var t = hr(), r = t.queue;
  if (r === null) throw Error($(311));
  r.lastRenderedReducer = e;
  var n = Ye, i = n.baseQueue, a = r.pending;
  if (a !== null) {
    if (i !== null) {
      var o = i.next;
      i.next = a.next, a.next = o;
    }
    n.baseQueue = i = a, r.pending = null;
  }
  if (i !== null) {
    a = i.next, n = n.baseState;
    var l = o = null, u = null, s = a;
    do {
      var c = s.lane;
      if ((Ui & c) === c) u !== null && (u = u.next = { lane: 0, action: s.action, hasEagerState: s.hasEagerState, eagerState: s.eagerState, next: null }), n = s.hasEagerState ? s.eagerState : e(n, s.action);
      else {
        var f = {
          lane: c,
          action: s.action,
          hasEagerState: s.hasEagerState,
          eagerState: s.eagerState,
          next: null
        };
        u === null ? (l = u = f, o = n) : u = u.next = f, Me.lanes |= c, Vi |= c;
      }
      s = s.next;
    } while (s !== null && s !== a);
    u === null ? o = n : u.next = l, Tr(n, t.memoizedState) || (Mt = !0), t.memoizedState = n, t.baseState = o, t.baseQueue = u, r.lastRenderedState = n;
  }
  if (e = r.interleaved, e !== null) {
    i = e;
    do
      a = i.lane, Me.lanes |= a, Vi |= a, i = i.next;
    while (i !== e);
  } else i === null && (r.lanes = 0);
  return [t.memoizedState, r.dispatch];
}
function xv(e) {
  var t = hr(), r = t.queue;
  if (r === null) throw Error($(311));
  r.lastRenderedReducer = e;
  var n = r.dispatch, i = r.pending, a = t.memoizedState;
  if (i !== null) {
    r.pending = null;
    var o = i = i.next;
    do
      a = e(a, o.action), o = o.next;
    while (o !== i);
    Tr(a, t.memoizedState) || (Mt = !0), t.memoizedState = a, t.baseQueue === null && (t.baseState = a), r.lastRenderedState = a;
  }
  return [a, n];
}
function rS() {
}
function nS(e, t) {
  var r = Me, n = hr(), i = t(), a = !Tr(n.memoizedState, i);
  if (a && (n.memoizedState = i, Mt = !0), n = n.queue, Nm(oS.bind(null, r, n, e), [e]), n.getSnapshot !== t || a || nt !== null && nt.memoizedState.tag & 1) {
    if (r.flags |= 2048, Tl(9, aS.bind(null, r, n, i, t), void 0, null), at === null) throw Error($(349));
    Ui & 30 || iS(r, t, i);
  }
  return i;
}
function iS(e, t, r) {
  e.flags |= 16384, e = { getSnapshot: t, value: r }, t = Me.updateQueue, t === null ? (t = { lastEffect: null, stores: null }, Me.updateQueue = t, t.stores = [e]) : (r = t.stores, r === null ? t.stores = [e] : r.push(e));
}
function aS(e, t, r, n) {
  t.value = r, t.getSnapshot = n, lS(t) && uS(e);
}
function oS(e, t, r) {
  return r(function() {
    lS(t) && uS(e);
  });
}
function lS(e) {
  var t = e.getSnapshot;
  e = e.value;
  try {
    var r = t();
    return !Tr(e, r);
  } catch {
    return !0;
  }
}
function uS(e) {
  var t = En(e, 1);
  t !== null && jr(t, e, 1, -1);
}
function Q0(e) {
  var t = zr();
  return typeof e == "function" && (e = e()), t.memoizedState = t.baseState = e, e = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: Cl, lastRenderedState: e }, t.queue = e, e = e.dispatch = cM.bind(null, Me, e), [t.memoizedState, e];
}
function Tl(e, t, r, n) {
  return e = { tag: e, create: t, destroy: r, deps: n, next: null }, t = Me.updateQueue, t === null ? (t = { lastEffect: null, stores: null }, Me.updateQueue = t, t.lastEffect = e.next = e) : (r = t.lastEffect, r === null ? t.lastEffect = e.next = e : (n = r.next, r.next = e, e.next = n, t.lastEffect = e)), e;
}
function sS() {
  return hr().memoizedState;
}
function Bs(e, t, r, n) {
  var i = zr();
  Me.flags |= e, i.memoizedState = Tl(1 | t, r, void 0, n === void 0 ? null : n);
}
function Nf(e, t, r, n) {
  var i = hr();
  n = n === void 0 ? null : n;
  var a = void 0;
  if (Ye !== null) {
    var o = Ye.memoizedState;
    if (a = o.destroy, n !== null && Tm(n, o.deps)) {
      i.memoizedState = Tl(t, r, a, n);
      return;
    }
  }
  Me.flags |= e, i.memoizedState = Tl(1 | t, r, a, n);
}
function J0(e, t) {
  return Bs(8390656, 8, e, t);
}
function Nm(e, t) {
  return Nf(2048, 8, e, t);
}
function cS(e, t) {
  return Nf(4, 2, e, t);
}
function fS(e, t) {
  return Nf(4, 4, e, t);
}
function dS(e, t) {
  if (typeof t == "function") return e = e(), t(e), function() {
    t(null);
  };
  if (t != null) return e = e(), t.current = e, function() {
    t.current = null;
  };
}
function vS(e, t, r) {
  return r = r != null ? r.concat([e]) : null, Nf(4, 4, dS.bind(null, t, e), r);
}
function $m() {
}
function pS(e, t) {
  var r = hr();
  t = t === void 0 ? null : t;
  var n = r.memoizedState;
  return n !== null && t !== null && Tm(t, n[1]) ? n[0] : (r.memoizedState = [e, t], e);
}
function hS(e, t) {
  var r = hr();
  t = t === void 0 ? null : t;
  var n = r.memoizedState;
  return n !== null && t !== null && Tm(t, n[1]) ? n[0] : (e = e(), r.memoizedState = [e, t], e);
}
function mS(e, t, r) {
  return Ui & 21 ? (Tr(r, t) || (r = wO(), Me.lanes |= r, Vi |= r, e.baseState = !0), t) : (e.baseState && (e.baseState = !1, Mt = !0), e.memoizedState = r);
}
function uM(e, t) {
  var r = ve;
  ve = r !== 0 && 4 > r ? r : 4, e(!0);
  var n = gv.transition;
  gv.transition = {};
  try {
    e(!1), t();
  } finally {
    ve = r, gv.transition = n;
  }
}
function yS() {
  return hr().memoizedState;
}
function sM(e, t, r) {
  var n = ii(e);
  if (r = { lane: n, action: r, hasEagerState: !1, eagerState: null, next: null }, gS(e)) bS(t, r);
  else if (r = JO(e, t, r, n), r !== null) {
    var i = At();
    jr(r, e, n, i), xS(r, t, n);
  }
}
function cM(e, t, r) {
  var n = ii(e), i = { lane: n, action: r, hasEagerState: !1, eagerState: null, next: null };
  if (gS(e)) bS(t, i);
  else {
    var a = e.alternate;
    if (e.lanes === 0 && (a === null || a.lanes === 0) && (a = t.lastRenderedReducer, a !== null)) try {
      var o = t.lastRenderedState, l = a(o, r);
      if (i.hasEagerState = !0, i.eagerState = l, Tr(l, o)) {
        var u = t.interleaved;
        u === null ? (i.next = i, km(t)) : (i.next = u.next, u.next = i), t.interleaved = i;
        return;
      }
    } catch {
    } finally {
    }
    r = JO(e, t, i, n), r !== null && (i = At(), jr(r, e, n, i), xS(r, t, n));
  }
}
function gS(e) {
  var t = e.alternate;
  return e === Me || t !== null && t === Me;
}
function bS(e, t) {
  cl = hc = !0;
  var r = e.pending;
  r === null ? t.next = t : (t.next = r.next, r.next = t), e.pending = t;
}
function xS(e, t, r) {
  if (r & 4194240) {
    var n = t.lanes;
    n &= e.pendingLanes, r |= n, t.lanes = r, vm(e, r);
  }
}
var mc = { readContext: pr, useCallback: pt, useContext: pt, useEffect: pt, useImperativeHandle: pt, useInsertionEffect: pt, useLayoutEffect: pt, useMemo: pt, useReducer: pt, useRef: pt, useState: pt, useDebugValue: pt, useDeferredValue: pt, useTransition: pt, useMutableSource: pt, useSyncExternalStore: pt, useId: pt, unstable_isNewReconciler: !1 }, fM = { readContext: pr, useCallback: function(e, t) {
  return zr().memoizedState = [e, t === void 0 ? null : t], e;
}, useContext: pr, useEffect: J0, useImperativeHandle: function(e, t, r) {
  return r = r != null ? r.concat([e]) : null, Bs(
    4194308,
    4,
    dS.bind(null, t, e),
    r
  );
}, useLayoutEffect: function(e, t) {
  return Bs(4194308, 4, e, t);
}, useInsertionEffect: function(e, t) {
  return Bs(4, 2, e, t);
}, useMemo: function(e, t) {
  var r = zr();
  return t = t === void 0 ? null : t, e = e(), r.memoizedState = [e, t], e;
}, useReducer: function(e, t, r) {
  var n = zr();
  return t = r !== void 0 ? r(t) : t, n.memoizedState = n.baseState = t, e = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: e, lastRenderedState: t }, n.queue = e, e = e.dispatch = sM.bind(null, Me, e), [n.memoizedState, e];
}, useRef: function(e) {
  var t = zr();
  return e = { current: e }, t.memoizedState = e;
}, useState: Q0, useDebugValue: $m, useDeferredValue: function(e) {
  return zr().memoizedState = e;
}, useTransition: function() {
  var e = Q0(!1), t = e[0];
  return e = uM.bind(null, e[1]), zr().memoizedState = e, [t, e];
}, useMutableSource: function() {
}, useSyncExternalStore: function(e, t, r) {
  var n = Me, i = zr();
  if (_e) {
    if (r === void 0) throw Error($(407));
    r = r();
  } else {
    if (r = t(), at === null) throw Error($(349));
    Ui & 30 || iS(n, t, r);
  }
  i.memoizedState = r;
  var a = { value: r, getSnapshot: t };
  return i.queue = a, J0(oS.bind(
    null,
    n,
    a,
    e
  ), [e]), n.flags |= 2048, Tl(9, aS.bind(null, n, a, r, t), void 0, null), r;
}, useId: function() {
  var e = zr(), t = at.identifierPrefix;
  if (_e) {
    var r = hn, n = pn;
    r = (n & ~(1 << 32 - Ir(n) - 1)).toString(32) + r, t = ":" + t + "R" + r, r = jl++, 0 < r && (t += "H" + r.toString(32)), t += ":";
  } else r = lM++, t = ":" + t + "r" + r.toString(32) + ":";
  return e.memoizedState = t;
}, unstable_isNewReconciler: !1 }, dM = {
  readContext: pr,
  useCallback: pS,
  useContext: pr,
  useEffect: Nm,
  useImperativeHandle: vS,
  useInsertionEffect: cS,
  useLayoutEffect: fS,
  useMemo: hS,
  useReducer: bv,
  useRef: sS,
  useState: function() {
    return bv(Cl);
  },
  useDebugValue: $m,
  useDeferredValue: function(e) {
    var t = hr();
    return mS(t, Ye.memoizedState, e);
  },
  useTransition: function() {
    var e = bv(Cl)[0], t = hr().memoizedState;
    return [e, t];
  },
  useMutableSource: rS,
  useSyncExternalStore: nS,
  useId: yS,
  unstable_isNewReconciler: !1
}, vM = { readContext: pr, useCallback: pS, useContext: pr, useEffect: Nm, useImperativeHandle: vS, useInsertionEffect: cS, useLayoutEffect: fS, useMemo: hS, useReducer: xv, useRef: sS, useState: function() {
  return xv(Cl);
}, useDebugValue: $m, useDeferredValue: function(e) {
  var t = hr();
  return Ye === null ? t.memoizedState = e : mS(t, Ye.memoizedState, e);
}, useTransition: function() {
  var e = xv(Cl)[0], t = hr().memoizedState;
  return [e, t];
}, useMutableSource: rS, useSyncExternalStore: nS, useId: yS, unstable_isNewReconciler: !1 };
function Pr(e, t) {
  if (e && e.defaultProps) {
    t = De({}, t), e = e.defaultProps;
    for (var r in e) t[r] === void 0 && (t[r] = e[r]);
    return t;
  }
  return t;
}
function Ip(e, t, r, n) {
  t = e.memoizedState, r = r(n, t), r = r == null ? t : De({}, t, r), e.memoizedState = r, e.lanes === 0 && (e.updateQueue.baseState = r);
}
var $f = { isMounted: function(e) {
  return (e = e._reactInternals) ? ia(e) === e : !1;
}, enqueueSetState: function(e, t, r) {
  e = e._reactInternals;
  var n = At(), i = ii(e), a = xn(n, i);
  a.payload = t, r != null && (a.callback = r), t = ri(e, a, i), t !== null && (jr(t, e, i, n), Rs(t, e, i));
}, enqueueReplaceState: function(e, t, r) {
  e = e._reactInternals;
  var n = At(), i = ii(e), a = xn(n, i);
  a.tag = 1, a.payload = t, r != null && (a.callback = r), t = ri(e, a, i), t !== null && (jr(t, e, i, n), Rs(t, e, i));
}, enqueueForceUpdate: function(e, t) {
  e = e._reactInternals;
  var r = At(), n = ii(e), i = xn(r, n);
  i.tag = 2, t != null && (i.callback = t), t = ri(e, i, n), t !== null && (jr(t, e, n, r), Rs(t, e, n));
} };
function eb(e, t, r, n, i, a, o) {
  return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(n, a, o) : t.prototype && t.prototype.isPureReactComponent ? !Sl(r, n) || !Sl(i, a) : !0;
}
function wS(e, t, r) {
  var n = !1, i = ui, a = t.contextType;
  return typeof a == "object" && a !== null ? a = pr(a) : (i = Rt(t) ? Ki : wt.current, n = t.contextTypes, a = (n = n != null) ? Ka(e, i) : ui), t = new t(r, a), e.memoizedState = t.state !== null && t.state !== void 0 ? t.state : null, t.updater = $f, e.stateNode = t, t._reactInternals = e, n && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = i, e.__reactInternalMemoizedMaskedChildContext = a), t;
}
function tb(e, t, r, n) {
  e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(r, n), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(r, n), t.state !== e && $f.enqueueReplaceState(t, t.state, null);
}
function jp(e, t, r, n) {
  var i = e.stateNode;
  i.props = r, i.state = e.memoizedState, i.refs = {}, _m(e);
  var a = t.contextType;
  typeof a == "object" && a !== null ? i.context = pr(a) : (a = Rt(t) ? Ki : wt.current, i.context = Ka(e, a)), i.state = e.memoizedState, a = t.getDerivedStateFromProps, typeof a == "function" && (Ip(e, t, a, r), i.state = e.memoizedState), typeof t.getDerivedStateFromProps == "function" || typeof i.getSnapshotBeforeUpdate == "function" || typeof i.UNSAFE_componentWillMount != "function" && typeof i.componentWillMount != "function" || (t = i.state, typeof i.componentWillMount == "function" && i.componentWillMount(), typeof i.UNSAFE_componentWillMount == "function" && i.UNSAFE_componentWillMount(), t !== i.state && $f.enqueueReplaceState(i, i.state, null), vc(e, r, i, n), i.state = e.memoizedState), typeof i.componentDidMount == "function" && (e.flags |= 4194308);
}
function Ha(e, t) {
  try {
    var r = "", n = t;
    do
      r += FC(n), n = n.return;
    while (n);
    var i = r;
  } catch (a) {
    i = `
Error generating stack: ` + a.message + `
` + a.stack;
  }
  return { value: e, source: t, stack: i, digest: null };
}
function wv(e, t, r) {
  return { value: e, source: null, stack: r ?? null, digest: t ?? null };
}
function Cp(e, t) {
  try {
    console.error(t.value);
  } catch (r) {
    setTimeout(function() {
      throw r;
    });
  }
}
var pM = typeof WeakMap == "function" ? WeakMap : Map;
function PS(e, t, r) {
  r = xn(-1, r), r.tag = 3, r.payload = { element: null };
  var n = t.value;
  return r.callback = function() {
    gc || (gc = !0, Fp = n), Cp(e, t);
  }, r;
}
function OS(e, t, r) {
  r = xn(-1, r), r.tag = 3;
  var n = e.type.getDerivedStateFromError;
  if (typeof n == "function") {
    var i = t.value;
    r.payload = function() {
      return n(i);
    }, r.callback = function() {
      Cp(e, t);
    };
  }
  var a = e.stateNode;
  return a !== null && typeof a.componentDidCatch == "function" && (r.callback = function() {
    Cp(e, t), typeof n != "function" && (ni === null ? ni = /* @__PURE__ */ new Set([this]) : ni.add(this));
    var o = t.stack;
    this.componentDidCatch(t.value, { componentStack: o !== null ? o : "" });
  }), r;
}
function rb(e, t, r) {
  var n = e.pingCache;
  if (n === null) {
    n = e.pingCache = new pM();
    var i = /* @__PURE__ */ new Set();
    n.set(t, i);
  } else i = n.get(t), i === void 0 && (i = /* @__PURE__ */ new Set(), n.set(t, i));
  i.has(r) || (i.add(r), e = _M.bind(null, e, t, r), t.then(e, e));
}
function nb(e) {
  do {
    var t;
    if ((t = e.tag === 13) && (t = e.memoizedState, t = t !== null ? t.dehydrated !== null : !0), t) return e;
    e = e.return;
  } while (e !== null);
  return null;
}
function ib(e, t, r, n, i) {
  return e.mode & 1 ? (e.flags |= 65536, e.lanes = i, e) : (e === t ? e.flags |= 65536 : (e.flags |= 128, r.flags |= 131072, r.flags &= -52805, r.tag === 1 && (r.alternate === null ? r.tag = 17 : (t = xn(-1, 1), t.tag = 2, ri(r, t, 1))), r.lanes |= 1), e);
}
var hM = Dn.ReactCurrentOwner, Mt = !1;
function Ot(e, t, r, n) {
  t.child = e === null ? QO(t, null, r, n) : Ua(t, e.child, r, n);
}
function ab(e, t, r, n, i) {
  r = r.render;
  var a = t.ref;
  return $a(t, i), n = Mm(e, t, r, n, a, i), r = Dm(), e !== null && !Mt ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~i, An(e, t, i)) : (_e && r && wm(t), t.flags |= 1, Ot(e, t, n, i), t.child);
}
function ob(e, t, r, n, i) {
  if (e === null) {
    var a = r.type;
    return typeof a == "function" && !Um(a) && a.defaultProps === void 0 && r.compare === null && r.defaultProps === void 0 ? (t.tag = 15, t.type = a, SS(e, t, a, n, i)) : (e = Us(r.type, null, n, t, t.mode, i), e.ref = t.ref, e.return = t, t.child = e);
  }
  if (a = e.child, !(e.lanes & i)) {
    var o = a.memoizedProps;
    if (r = r.compare, r = r !== null ? r : Sl, r(o, n) && e.ref === t.ref) return An(e, t, i);
  }
  return t.flags |= 1, e = ai(a, n), e.ref = t.ref, e.return = t, t.child = e;
}
function SS(e, t, r, n, i) {
  if (e !== null) {
    var a = e.memoizedProps;
    if (Sl(a, n) && e.ref === t.ref) if (Mt = !1, t.pendingProps = n = a, (e.lanes & i) !== 0) e.flags & 131072 && (Mt = !0);
    else return t.lanes = e.lanes, An(e, t, i);
  }
  return Tp(e, t, r, n, i);
}
function ES(e, t, r) {
  var n = t.pendingProps, i = n.children, a = e !== null ? e.memoizedState : null;
  if (n.mode === "hidden") if (!(t.mode & 1)) t.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, Pe(ka, Xt), Xt |= r;
  else {
    if (!(r & 1073741824)) return e = a !== null ? a.baseLanes | r : r, t.lanes = t.childLanes = 1073741824, t.memoizedState = { baseLanes: e, cachePool: null, transitions: null }, t.updateQueue = null, Pe(ka, Xt), Xt |= e, null;
    t.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, n = a !== null ? a.baseLanes : r, Pe(ka, Xt), Xt |= n;
  }
  else a !== null ? (n = a.baseLanes | r, t.memoizedState = null) : n = r, Pe(ka, Xt), Xt |= n;
  return Ot(e, t, i, r), t.child;
}
function AS(e, t) {
  var r = t.ref;
  (e === null && r !== null || e !== null && e.ref !== r) && (t.flags |= 512, t.flags |= 2097152);
}
function Tp(e, t, r, n, i) {
  var a = Rt(r) ? Ki : wt.current;
  return a = Ka(t, a), $a(t, i), r = Mm(e, t, r, n, a, i), n = Dm(), e !== null && !Mt ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~i, An(e, t, i)) : (_e && n && wm(t), t.flags |= 1, Ot(e, t, r, i), t.child);
}
function lb(e, t, r, n, i) {
  if (Rt(r)) {
    var a = !0;
    uc(t);
  } else a = !1;
  if ($a(t, i), t.stateNode === null) Fs(e, t), wS(t, r, n), jp(t, r, n, i), n = !0;
  else if (e === null) {
    var o = t.stateNode, l = t.memoizedProps;
    o.props = l;
    var u = o.context, s = r.contextType;
    typeof s == "object" && s !== null ? s = pr(s) : (s = Rt(r) ? Ki : wt.current, s = Ka(t, s));
    var c = r.getDerivedStateFromProps, f = typeof c == "function" || typeof o.getSnapshotBeforeUpdate == "function";
    f || typeof o.UNSAFE_componentWillReceiveProps != "function" && typeof o.componentWillReceiveProps != "function" || (l !== n || u !== s) && tb(t, o, n, s), Wn = !1;
    var v = t.memoizedState;
    o.state = v, vc(t, n, o, i), u = t.memoizedState, l !== n || v !== u || Lt.current || Wn ? (typeof c == "function" && (Ip(t, r, c, n), u = t.memoizedState), (l = Wn || eb(t, r, l, n, v, u, s)) ? (f || typeof o.UNSAFE_componentWillMount != "function" && typeof o.componentWillMount != "function" || (typeof o.componentWillMount == "function" && o.componentWillMount(), typeof o.UNSAFE_componentWillMount == "function" && o.UNSAFE_componentWillMount()), typeof o.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof o.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = n, t.memoizedState = u), o.props = n, o.state = u, o.context = s, n = l) : (typeof o.componentDidMount == "function" && (t.flags |= 4194308), n = !1);
  } else {
    o = t.stateNode, eS(e, t), l = t.memoizedProps, s = t.type === t.elementType ? l : Pr(t.type, l), o.props = s, f = t.pendingProps, v = o.context, u = r.contextType, typeof u == "object" && u !== null ? u = pr(u) : (u = Rt(r) ? Ki : wt.current, u = Ka(t, u));
    var p = r.getDerivedStateFromProps;
    (c = typeof p == "function" || typeof o.getSnapshotBeforeUpdate == "function") || typeof o.UNSAFE_componentWillReceiveProps != "function" && typeof o.componentWillReceiveProps != "function" || (l !== f || v !== u) && tb(t, o, n, u), Wn = !1, v = t.memoizedState, o.state = v, vc(t, n, o, i);
    var h = t.memoizedState;
    l !== f || v !== h || Lt.current || Wn ? (typeof p == "function" && (Ip(t, r, p, n), h = t.memoizedState), (s = Wn || eb(t, r, s, n, v, h, u) || !1) ? (c || typeof o.UNSAFE_componentWillUpdate != "function" && typeof o.componentWillUpdate != "function" || (typeof o.componentWillUpdate == "function" && o.componentWillUpdate(n, h, u), typeof o.UNSAFE_componentWillUpdate == "function" && o.UNSAFE_componentWillUpdate(n, h, u)), typeof o.componentDidUpdate == "function" && (t.flags |= 4), typeof o.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof o.componentDidUpdate != "function" || l === e.memoizedProps && v === e.memoizedState || (t.flags |= 4), typeof o.getSnapshotBeforeUpdate != "function" || l === e.memoizedProps && v === e.memoizedState || (t.flags |= 1024), t.memoizedProps = n, t.memoizedState = h), o.props = n, o.state = h, o.context = u, n = s) : (typeof o.componentDidUpdate != "function" || l === e.memoizedProps && v === e.memoizedState || (t.flags |= 4), typeof o.getSnapshotBeforeUpdate != "function" || l === e.memoizedProps && v === e.memoizedState || (t.flags |= 1024), n = !1);
  }
  return Mp(e, t, r, n, a, i);
}
function Mp(e, t, r, n, i, a) {
  AS(e, t);
  var o = (t.flags & 128) !== 0;
  if (!n && !o) return i && H0(t, r, !1), An(e, t, a);
  n = t.stateNode, hM.current = t;
  var l = o && typeof r.getDerivedStateFromError != "function" ? null : n.render();
  return t.flags |= 1, e !== null && o ? (t.child = Ua(t, e.child, null, a), t.child = Ua(t, null, l, a)) : Ot(e, t, l, a), t.memoizedState = n.state, i && H0(t, r, !0), t.child;
}
function kS(e) {
  var t = e.stateNode;
  t.pendingContext ? V0(e, t.pendingContext, t.pendingContext !== t.context) : t.context && V0(e, t.context, !1), Im(e, t.containerInfo);
}
function ub(e, t, r, n, i) {
  return Wa(), Om(i), t.flags |= 256, Ot(e, t, r, n), t.child;
}
var Dp = { dehydrated: null, treeContext: null, retryLane: 0 };
function Np(e) {
  return { baseLanes: e, cachePool: null, transitions: null };
}
function _S(e, t, r) {
  var n = t.pendingProps, i = Te.current, a = !1, o = (t.flags & 128) !== 0, l;
  if ((l = o) || (l = e !== null && e.memoizedState === null ? !1 : (i & 2) !== 0), l ? (a = !0, t.flags &= -129) : (e === null || e.memoizedState !== null) && (i |= 1), Pe(Te, i & 1), e === null)
    return kp(t), e = t.memoizedState, e !== null && (e = e.dehydrated, e !== null) ? (t.mode & 1 ? e.data === "$!" ? t.lanes = 8 : t.lanes = 1073741824 : t.lanes = 1, null) : (o = n.children, e = n.fallback, a ? (n = t.mode, a = t.child, o = { mode: "hidden", children: o }, !(n & 1) && a !== null ? (a.childLanes = 0, a.pendingProps = o) : a = zf(o, n, 0, null), e = $i(e, n, r, null), a.return = t, e.return = t, a.sibling = e, t.child = a, t.child.memoizedState = Np(r), t.memoizedState = Dp, e) : Lm(t, o));
  if (i = e.memoizedState, i !== null && (l = i.dehydrated, l !== null)) return mM(e, t, o, n, l, i, r);
  if (a) {
    a = n.fallback, o = t.mode, i = e.child, l = i.sibling;
    var u = { mode: "hidden", children: n.children };
    return !(o & 1) && t.child !== i ? (n = t.child, n.childLanes = 0, n.pendingProps = u, t.deletions = null) : (n = ai(i, u), n.subtreeFlags = i.subtreeFlags & 14680064), l !== null ? a = ai(l, a) : (a = $i(a, o, r, null), a.flags |= 2), a.return = t, n.return = t, n.sibling = a, t.child = n, n = a, a = t.child, o = e.child.memoizedState, o = o === null ? Np(r) : { baseLanes: o.baseLanes | r, cachePool: null, transitions: o.transitions }, a.memoizedState = o, a.childLanes = e.childLanes & ~r, t.memoizedState = Dp, n;
  }
  return a = e.child, e = a.sibling, n = ai(a, { mode: "visible", children: n.children }), !(t.mode & 1) && (n.lanes = r), n.return = t, n.sibling = null, e !== null && (r = t.deletions, r === null ? (t.deletions = [e], t.flags |= 16) : r.push(e)), t.child = n, t.memoizedState = null, n;
}
function Lm(e, t) {
  return t = zf({ mode: "visible", children: t }, e.mode, 0, null), t.return = e, e.child = t;
}
function cs(e, t, r, n) {
  return n !== null && Om(n), Ua(t, e.child, null, r), e = Lm(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e;
}
function mM(e, t, r, n, i, a, o) {
  if (r)
    return t.flags & 256 ? (t.flags &= -257, n = wv(Error($(422))), cs(e, t, o, n)) : t.memoizedState !== null ? (t.child = e.child, t.flags |= 128, null) : (a = n.fallback, i = t.mode, n = zf({ mode: "visible", children: n.children }, i, 0, null), a = $i(a, i, o, null), a.flags |= 2, n.return = t, a.return = t, n.sibling = a, t.child = n, t.mode & 1 && Ua(t, e.child, null, o), t.child.memoizedState = Np(o), t.memoizedState = Dp, a);
  if (!(t.mode & 1)) return cs(e, t, o, null);
  if (i.data === "$!") {
    if (n = i.nextSibling && i.nextSibling.dataset, n) var l = n.dgst;
    return n = l, a = Error($(419)), n = wv(a, n, void 0), cs(e, t, o, n);
  }
  if (l = (o & e.childLanes) !== 0, Mt || l) {
    if (n = at, n !== null) {
      switch (o & -o) {
        case 4:
          i = 2;
          break;
        case 16:
          i = 8;
          break;
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
          i = 32;
          break;
        case 536870912:
          i = 268435456;
          break;
        default:
          i = 0;
      }
      i = i & (n.suspendedLanes | o) ? 0 : i, i !== 0 && i !== a.retryLane && (a.retryLane = i, En(e, i), jr(n, e, i, -1));
    }
    return Wm(), n = wv(Error($(421))), cs(e, t, o, n);
  }
  return i.data === "$?" ? (t.flags |= 128, t.child = e.child, t = IM.bind(null, e), i._reactRetry = t, null) : (e = a.treeContext, Gt = ti(i.nextSibling), Zt = t, _e = !0, Sr = null, e !== null && (sr[cr++] = pn, sr[cr++] = hn, sr[cr++] = Wi, pn = e.id, hn = e.overflow, Wi = t), t = Lm(t, n.children), t.flags |= 4096, t);
}
function sb(e, t, r) {
  e.lanes |= t;
  var n = e.alternate;
  n !== null && (n.lanes |= t), _p(e.return, t, r);
}
function Pv(e, t, r, n, i) {
  var a = e.memoizedState;
  a === null ? e.memoizedState = { isBackwards: t, rendering: null, renderingStartTime: 0, last: n, tail: r, tailMode: i } : (a.isBackwards = t, a.rendering = null, a.renderingStartTime = 0, a.last = n, a.tail = r, a.tailMode = i);
}
function IS(e, t, r) {
  var n = t.pendingProps, i = n.revealOrder, a = n.tail;
  if (Ot(e, t, n.children, r), n = Te.current, n & 2) n = n & 1 | 2, t.flags |= 128;
  else {
    if (e !== null && e.flags & 128) e: for (e = t.child; e !== null; ) {
      if (e.tag === 13) e.memoizedState !== null && sb(e, r, t);
      else if (e.tag === 19) sb(e, r, t);
      else if (e.child !== null) {
        e.child.return = e, e = e.child;
        continue;
      }
      if (e === t) break e;
      for (; e.sibling === null; ) {
        if (e.return === null || e.return === t) break e;
        e = e.return;
      }
      e.sibling.return = e.return, e = e.sibling;
    }
    n &= 1;
  }
  if (Pe(Te, n), !(t.mode & 1)) t.memoizedState = null;
  else switch (i) {
    case "forwards":
      for (r = t.child, i = null; r !== null; ) e = r.alternate, e !== null && pc(e) === null && (i = r), r = r.sibling;
      r = i, r === null ? (i = t.child, t.child = null) : (i = r.sibling, r.sibling = null), Pv(t, !1, i, r, a);
      break;
    case "backwards":
      for (r = null, i = t.child, t.child = null; i !== null; ) {
        if (e = i.alternate, e !== null && pc(e) === null) {
          t.child = i;
          break;
        }
        e = i.sibling, i.sibling = r, r = i, i = e;
      }
      Pv(t, !0, r, null, a);
      break;
    case "together":
      Pv(t, !1, null, null, void 0);
      break;
    default:
      t.memoizedState = null;
  }
  return t.child;
}
function Fs(e, t) {
  !(t.mode & 1) && e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2);
}
function An(e, t, r) {
  if (e !== null && (t.dependencies = e.dependencies), Vi |= t.lanes, !(r & t.childLanes)) return null;
  if (e !== null && t.child !== e.child) throw Error($(153));
  if (t.child !== null) {
    for (e = t.child, r = ai(e, e.pendingProps), t.child = r, r.return = t; e.sibling !== null; ) e = e.sibling, r = r.sibling = ai(e, e.pendingProps), r.return = t;
    r.sibling = null;
  }
  return t.child;
}
function yM(e, t, r) {
  switch (t.tag) {
    case 3:
      kS(t), Wa();
      break;
    case 5:
      tS(t);
      break;
    case 1:
      Rt(t.type) && uc(t);
      break;
    case 4:
      Im(t, t.stateNode.containerInfo);
      break;
    case 10:
      var n = t.type._context, i = t.memoizedProps.value;
      Pe(fc, n._currentValue), n._currentValue = i;
      break;
    case 13:
      if (n = t.memoizedState, n !== null)
        return n.dehydrated !== null ? (Pe(Te, Te.current & 1), t.flags |= 128, null) : r & t.child.childLanes ? _S(e, t, r) : (Pe(Te, Te.current & 1), e = An(e, t, r), e !== null ? e.sibling : null);
      Pe(Te, Te.current & 1);
      break;
    case 19:
      if (n = (r & t.childLanes) !== 0, e.flags & 128) {
        if (n) return IS(e, t, r);
        t.flags |= 128;
      }
      if (i = t.memoizedState, i !== null && (i.rendering = null, i.tail = null, i.lastEffect = null), Pe(Te, Te.current), n) break;
      return null;
    case 22:
    case 23:
      return t.lanes = 0, ES(e, t, r);
  }
  return An(e, t, r);
}
var jS, $p, CS, TS;
jS = function(e, t) {
  for (var r = t.child; r !== null; ) {
    if (r.tag === 5 || r.tag === 6) e.appendChild(r.stateNode);
    else if (r.tag !== 4 && r.child !== null) {
      r.child.return = r, r = r.child;
      continue;
    }
    if (r === t) break;
    for (; r.sibling === null; ) {
      if (r.return === null || r.return === t) return;
      r = r.return;
    }
    r.sibling.return = r.return, r = r.sibling;
  }
};
$p = function() {
};
CS = function(e, t, r, n) {
  var i = e.memoizedProps;
  if (i !== n) {
    e = t.stateNode, ji(Hr.current);
    var a = null;
    switch (r) {
      case "input":
        i = ip(e, i), n = ip(e, n), a = [];
        break;
      case "select":
        i = De({}, i, { value: void 0 }), n = De({}, n, { value: void 0 }), a = [];
        break;
      case "textarea":
        i = lp(e, i), n = lp(e, n), a = [];
        break;
      default:
        typeof i.onClick != "function" && typeof n.onClick == "function" && (e.onclick = oc);
    }
    sp(r, n);
    var o;
    r = null;
    for (s in i) if (!n.hasOwnProperty(s) && i.hasOwnProperty(s) && i[s] != null) if (s === "style") {
      var l = i[s];
      for (o in l) l.hasOwnProperty(o) && (r || (r = {}), r[o] = "");
    } else s !== "dangerouslySetInnerHTML" && s !== "children" && s !== "suppressContentEditableWarning" && s !== "suppressHydrationWarning" && s !== "autoFocus" && (yl.hasOwnProperty(s) ? a || (a = []) : (a = a || []).push(s, null));
    for (s in n) {
      var u = n[s];
      if (l = i != null ? i[s] : void 0, n.hasOwnProperty(s) && u !== l && (u != null || l != null)) if (s === "style") if (l) {
        for (o in l) !l.hasOwnProperty(o) || u && u.hasOwnProperty(o) || (r || (r = {}), r[o] = "");
        for (o in u) u.hasOwnProperty(o) && l[o] !== u[o] && (r || (r = {}), r[o] = u[o]);
      } else r || (a || (a = []), a.push(
        s,
        r
      )), r = u;
      else s === "dangerouslySetInnerHTML" ? (u = u ? u.__html : void 0, l = l ? l.__html : void 0, u != null && l !== u && (a = a || []).push(s, u)) : s === "children" ? typeof u != "string" && typeof u != "number" || (a = a || []).push(s, "" + u) : s !== "suppressContentEditableWarning" && s !== "suppressHydrationWarning" && (yl.hasOwnProperty(s) ? (u != null && s === "onScroll" && Oe("scroll", e), a || l === u || (a = [])) : (a = a || []).push(s, u));
    }
    r && (a = a || []).push("style", r);
    var s = a;
    (t.updateQueue = s) && (t.flags |= 4);
  }
};
TS = function(e, t, r, n) {
  r !== n && (t.flags |= 4);
};
function Ko(e, t) {
  if (!_e) switch (e.tailMode) {
    case "hidden":
      t = e.tail;
      for (var r = null; t !== null; ) t.alternate !== null && (r = t), t = t.sibling;
      r === null ? e.tail = null : r.sibling = null;
      break;
    case "collapsed":
      r = e.tail;
      for (var n = null; r !== null; ) r.alternate !== null && (n = r), r = r.sibling;
      n === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : n.sibling = null;
  }
}
function ht(e) {
  var t = e.alternate !== null && e.alternate.child === e.child, r = 0, n = 0;
  if (t) for (var i = e.child; i !== null; ) r |= i.lanes | i.childLanes, n |= i.subtreeFlags & 14680064, n |= i.flags & 14680064, i.return = e, i = i.sibling;
  else for (i = e.child; i !== null; ) r |= i.lanes | i.childLanes, n |= i.subtreeFlags, n |= i.flags, i.return = e, i = i.sibling;
  return e.subtreeFlags |= n, e.childLanes = r, t;
}
function gM(e, t, r) {
  var n = t.pendingProps;
  switch (Pm(t), t.tag) {
    case 2:
    case 16:
    case 15:
    case 0:
    case 11:
    case 7:
    case 8:
    case 12:
    case 9:
    case 14:
      return ht(t), null;
    case 1:
      return Rt(t.type) && lc(), ht(t), null;
    case 3:
      return n = t.stateNode, Va(), Ee(Lt), Ee(wt), Cm(), n.pendingContext && (n.context = n.pendingContext, n.pendingContext = null), (e === null || e.child === null) && (us(t) ? t.flags |= 4 : e === null || e.memoizedState.isDehydrated && !(t.flags & 256) || (t.flags |= 1024, Sr !== null && (Up(Sr), Sr = null))), $p(e, t), ht(t), null;
    case 5:
      jm(t);
      var i = ji(Il.current);
      if (r = t.type, e !== null && t.stateNode != null) CS(e, t, r, n, i), e.ref !== t.ref && (t.flags |= 512, t.flags |= 2097152);
      else {
        if (!n) {
          if (t.stateNode === null) throw Error($(166));
          return ht(t), null;
        }
        if (e = ji(Hr.current), us(t)) {
          n = t.stateNode, r = t.type;
          var a = t.memoizedProps;
          switch (n[Fr] = t, n[kl] = a, e = (t.mode & 1) !== 0, r) {
            case "dialog":
              Oe("cancel", n), Oe("close", n);
              break;
            case "iframe":
            case "object":
            case "embed":
              Oe("load", n);
              break;
            case "video":
            case "audio":
              for (i = 0; i < rl.length; i++) Oe(rl[i], n);
              break;
            case "source":
              Oe("error", n);
              break;
            case "img":
            case "image":
            case "link":
              Oe(
                "error",
                n
              ), Oe("load", n);
              break;
            case "details":
              Oe("toggle", n);
              break;
            case "input":
              g0(n, a), Oe("invalid", n);
              break;
            case "select":
              n._wrapperState = { wasMultiple: !!a.multiple }, Oe("invalid", n);
              break;
            case "textarea":
              x0(n, a), Oe("invalid", n);
          }
          sp(r, a), i = null;
          for (var o in a) if (a.hasOwnProperty(o)) {
            var l = a[o];
            o === "children" ? typeof l == "string" ? n.textContent !== l && (a.suppressHydrationWarning !== !0 && ls(n.textContent, l, e), i = ["children", l]) : typeof l == "number" && n.textContent !== "" + l && (a.suppressHydrationWarning !== !0 && ls(
              n.textContent,
              l,
              e
            ), i = ["children", "" + l]) : yl.hasOwnProperty(o) && l != null && o === "onScroll" && Oe("scroll", n);
          }
          switch (r) {
            case "input":
              Ju(n), b0(n, a, !0);
              break;
            case "textarea":
              Ju(n), w0(n);
              break;
            case "select":
            case "option":
              break;
            default:
              typeof a.onClick == "function" && (n.onclick = oc);
          }
          n = i, t.updateQueue = n, n !== null && (t.flags |= 4);
        } else {
          o = i.nodeType === 9 ? i : i.ownerDocument, e === "http://www.w3.org/1999/xhtml" && (e = oO(r)), e === "http://www.w3.org/1999/xhtml" ? r === "script" ? (e = o.createElement("div"), e.innerHTML = "<script><\/script>", e = e.removeChild(e.firstChild)) : typeof n.is == "string" ? e = o.createElement(r, { is: n.is }) : (e = o.createElement(r), r === "select" && (o = e, n.multiple ? o.multiple = !0 : n.size && (o.size = n.size))) : e = o.createElementNS(e, r), e[Fr] = t, e[kl] = n, jS(e, t, !1, !1), t.stateNode = e;
          e: {
            switch (o = cp(r, n), r) {
              case "dialog":
                Oe("cancel", e), Oe("close", e), i = n;
                break;
              case "iframe":
              case "object":
              case "embed":
                Oe("load", e), i = n;
                break;
              case "video":
              case "audio":
                for (i = 0; i < rl.length; i++) Oe(rl[i], e);
                i = n;
                break;
              case "source":
                Oe("error", e), i = n;
                break;
              case "img":
              case "image":
              case "link":
                Oe(
                  "error",
                  e
                ), Oe("load", e), i = n;
                break;
              case "details":
                Oe("toggle", e), i = n;
                break;
              case "input":
                g0(e, n), i = ip(e, n), Oe("invalid", e);
                break;
              case "option":
                i = n;
                break;
              case "select":
                e._wrapperState = { wasMultiple: !!n.multiple }, i = De({}, n, { value: void 0 }), Oe("invalid", e);
                break;
              case "textarea":
                x0(e, n), i = lp(e, n), Oe("invalid", e);
                break;
              default:
                i = n;
            }
            sp(r, i), l = i;
            for (a in l) if (l.hasOwnProperty(a)) {
              var u = l[a];
              a === "style" ? sO(e, u) : a === "dangerouslySetInnerHTML" ? (u = u ? u.__html : void 0, u != null && lO(e, u)) : a === "children" ? typeof u == "string" ? (r !== "textarea" || u !== "") && gl(e, u) : typeof u == "number" && gl(e, "" + u) : a !== "suppressContentEditableWarning" && a !== "suppressHydrationWarning" && a !== "autoFocus" && (yl.hasOwnProperty(a) ? u != null && a === "onScroll" && Oe("scroll", e) : u != null && lm(e, a, u, o));
            }
            switch (r) {
              case "input":
                Ju(e), b0(e, n, !1);
                break;
              case "textarea":
                Ju(e), w0(e);
                break;
              case "option":
                n.value != null && e.setAttribute("value", "" + li(n.value));
                break;
              case "select":
                e.multiple = !!n.multiple, a = n.value, a != null ? Ta(e, !!n.multiple, a, !1) : n.defaultValue != null && Ta(
                  e,
                  !!n.multiple,
                  n.defaultValue,
                  !0
                );
                break;
              default:
                typeof i.onClick == "function" && (e.onclick = oc);
            }
            switch (r) {
              case "button":
              case "input":
              case "select":
              case "textarea":
                n = !!n.autoFocus;
                break e;
              case "img":
                n = !0;
                break e;
              default:
                n = !1;
            }
          }
          n && (t.flags |= 4);
        }
        t.ref !== null && (t.flags |= 512, t.flags |= 2097152);
      }
      return ht(t), null;
    case 6:
      if (e && t.stateNode != null) TS(e, t, e.memoizedProps, n);
      else {
        if (typeof n != "string" && t.stateNode === null) throw Error($(166));
        if (r = ji(Il.current), ji(Hr.current), us(t)) {
          if (n = t.stateNode, r = t.memoizedProps, n[Fr] = t, (a = n.nodeValue !== r) && (e = Zt, e !== null)) switch (e.tag) {
            case 3:
              ls(n.nodeValue, r, (e.mode & 1) !== 0);
              break;
            case 5:
              e.memoizedProps.suppressHydrationWarning !== !0 && ls(n.nodeValue, r, (e.mode & 1) !== 0);
          }
          a && (t.flags |= 4);
        } else n = (r.nodeType === 9 ? r : r.ownerDocument).createTextNode(n), n[Fr] = t, t.stateNode = n;
      }
      return ht(t), null;
    case 13:
      if (Ee(Te), n = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
        if (_e && Gt !== null && t.mode & 1 && !(t.flags & 128)) qO(), Wa(), t.flags |= 98560, a = !1;
        else if (a = us(t), n !== null && n.dehydrated !== null) {
          if (e === null) {
            if (!a) throw Error($(318));
            if (a = t.memoizedState, a = a !== null ? a.dehydrated : null, !a) throw Error($(317));
            a[Fr] = t;
          } else Wa(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
          ht(t), a = !1;
        } else Sr !== null && (Up(Sr), Sr = null), a = !0;
        if (!a) return t.flags & 65536 ? t : null;
      }
      return t.flags & 128 ? (t.lanes = r, t) : (n = n !== null, n !== (e !== null && e.memoizedState !== null) && n && (t.child.flags |= 8192, t.mode & 1 && (e === null || Te.current & 1 ? qe === 0 && (qe = 3) : Wm())), t.updateQueue !== null && (t.flags |= 4), ht(t), null);
    case 4:
      return Va(), $p(e, t), e === null && El(t.stateNode.containerInfo), ht(t), null;
    case 10:
      return Am(t.type._context), ht(t), null;
    case 17:
      return Rt(t.type) && lc(), ht(t), null;
    case 19:
      if (Ee(Te), a = t.memoizedState, a === null) return ht(t), null;
      if (n = (t.flags & 128) !== 0, o = a.rendering, o === null) if (n) Ko(a, !1);
      else {
        if (qe !== 0 || e !== null && e.flags & 128) for (e = t.child; e !== null; ) {
          if (o = pc(e), o !== null) {
            for (t.flags |= 128, Ko(a, !1), n = o.updateQueue, n !== null && (t.updateQueue = n, t.flags |= 4), t.subtreeFlags = 0, n = r, r = t.child; r !== null; ) a = r, e = n, a.flags &= 14680066, o = a.alternate, o === null ? (a.childLanes = 0, a.lanes = e, a.child = null, a.subtreeFlags = 0, a.memoizedProps = null, a.memoizedState = null, a.updateQueue = null, a.dependencies = null, a.stateNode = null) : (a.childLanes = o.childLanes, a.lanes = o.lanes, a.child = o.child, a.subtreeFlags = 0, a.deletions = null, a.memoizedProps = o.memoizedProps, a.memoizedState = o.memoizedState, a.updateQueue = o.updateQueue, a.type = o.type, e = o.dependencies, a.dependencies = e === null ? null : { lanes: e.lanes, firstContext: e.firstContext }), r = r.sibling;
            return Pe(Te, Te.current & 1 | 2), t.child;
          }
          e = e.sibling;
        }
        a.tail !== null && ze() > Xa && (t.flags |= 128, n = !0, Ko(a, !1), t.lanes = 4194304);
      }
      else {
        if (!n) if (e = pc(o), e !== null) {
          if (t.flags |= 128, n = !0, r = e.updateQueue, r !== null && (t.updateQueue = r, t.flags |= 4), Ko(a, !0), a.tail === null && a.tailMode === "hidden" && !o.alternate && !_e) return ht(t), null;
        } else 2 * ze() - a.renderingStartTime > Xa && r !== 1073741824 && (t.flags |= 128, n = !0, Ko(a, !1), t.lanes = 4194304);
        a.isBackwards ? (o.sibling = t.child, t.child = o) : (r = a.last, r !== null ? r.sibling = o : t.child = o, a.last = o);
      }
      return a.tail !== null ? (t = a.tail, a.rendering = t, a.tail = t.sibling, a.renderingStartTime = ze(), t.sibling = null, r = Te.current, Pe(Te, n ? r & 1 | 2 : r & 1), t) : (ht(t), null);
    case 22:
    case 23:
      return Km(), n = t.memoizedState !== null, e !== null && e.memoizedState !== null !== n && (t.flags |= 8192), n && t.mode & 1 ? Xt & 1073741824 && (ht(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : ht(t), null;
    case 24:
      return null;
    case 25:
      return null;
  }
  throw Error($(156, t.tag));
}
function bM(e, t) {
  switch (Pm(t), t.tag) {
    case 1:
      return Rt(t.type) && lc(), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
    case 3:
      return Va(), Ee(Lt), Ee(wt), Cm(), e = t.flags, e & 65536 && !(e & 128) ? (t.flags = e & -65537 | 128, t) : null;
    case 5:
      return jm(t), null;
    case 13:
      if (Ee(Te), e = t.memoizedState, e !== null && e.dehydrated !== null) {
        if (t.alternate === null) throw Error($(340));
        Wa();
      }
      return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
    case 19:
      return Ee(Te), null;
    case 4:
      return Va(), null;
    case 10:
      return Am(t.type._context), null;
    case 22:
    case 23:
      return Km(), null;
    case 24:
      return null;
    default:
      return null;
  }
}
var fs = !1, gt = !1, xM = typeof WeakSet == "function" ? WeakSet : Set, K = null;
function Aa(e, t) {
  var r = e.ref;
  if (r !== null) if (typeof r == "function") try {
    r(null);
  } catch (n) {
    $e(e, t, n);
  }
  else r.current = null;
}
function Lp(e, t, r) {
  try {
    r();
  } catch (n) {
    $e(e, t, n);
  }
}
var cb = !1;
function wM(e, t) {
  if (xp = nc, e = LO(), xm(e)) {
    if ("selectionStart" in e) var r = { start: e.selectionStart, end: e.selectionEnd };
    else e: {
      r = (r = e.ownerDocument) && r.defaultView || window;
      var n = r.getSelection && r.getSelection();
      if (n && n.rangeCount !== 0) {
        r = n.anchorNode;
        var i = n.anchorOffset, a = n.focusNode;
        n = n.focusOffset;
        try {
          r.nodeType, a.nodeType;
        } catch {
          r = null;
          break e;
        }
        var o = 0, l = -1, u = -1, s = 0, c = 0, f = e, v = null;
        t: for (; ; ) {
          for (var p; f !== r || i !== 0 && f.nodeType !== 3 || (l = o + i), f !== a || n !== 0 && f.nodeType !== 3 || (u = o + n), f.nodeType === 3 && (o += f.nodeValue.length), (p = f.firstChild) !== null; )
            v = f, f = p;
          for (; ; ) {
            if (f === e) break t;
            if (v === r && ++s === i && (l = o), v === a && ++c === n && (u = o), (p = f.nextSibling) !== null) break;
            f = v, v = f.parentNode;
          }
          f = p;
        }
        r = l === -1 || u === -1 ? null : { start: l, end: u };
      } else r = null;
    }
    r = r || { start: 0, end: 0 };
  } else r = null;
  for (wp = { focusedElem: e, selectionRange: r }, nc = !1, K = t; K !== null; ) if (t = K, e = t.child, (t.subtreeFlags & 1028) !== 0 && e !== null) e.return = t, K = e;
  else for (; K !== null; ) {
    t = K;
    try {
      var h = t.alternate;
      if (t.flags & 1024) switch (t.tag) {
        case 0:
        case 11:
        case 15:
          break;
        case 1:
          if (h !== null) {
            var y = h.memoizedProps, g = h.memoizedState, m = t.stateNode, b = m.getSnapshotBeforeUpdate(t.elementType === t.type ? y : Pr(t.type, y), g);
            m.__reactInternalSnapshotBeforeUpdate = b;
          }
          break;
        case 3:
          var x = t.stateNode.containerInfo;
          x.nodeType === 1 ? x.textContent = "" : x.nodeType === 9 && x.documentElement && x.removeChild(x.documentElement);
          break;
        case 5:
        case 6:
        case 4:
        case 17:
          break;
        default:
          throw Error($(163));
      }
    } catch (w) {
      $e(t, t.return, w);
    }
    if (e = t.sibling, e !== null) {
      e.return = t.return, K = e;
      break;
    }
    K = t.return;
  }
  return h = cb, cb = !1, h;
}
function fl(e, t, r) {
  var n = t.updateQueue;
  if (n = n !== null ? n.lastEffect : null, n !== null) {
    var i = n = n.next;
    do {
      if ((i.tag & e) === e) {
        var a = i.destroy;
        i.destroy = void 0, a !== void 0 && Lp(t, r, a);
      }
      i = i.next;
    } while (i !== n);
  }
}
function Lf(e, t) {
  if (t = t.updateQueue, t = t !== null ? t.lastEffect : null, t !== null) {
    var r = t = t.next;
    do {
      if ((r.tag & e) === e) {
        var n = r.create;
        r.destroy = n();
      }
      r = r.next;
    } while (r !== t);
  }
}
function Rp(e) {
  var t = e.ref;
  if (t !== null) {
    var r = e.stateNode;
    switch (e.tag) {
      case 5:
        e = r;
        break;
      default:
        e = r;
    }
    typeof t == "function" ? t(e) : t.current = e;
  }
}
function MS(e) {
  var t = e.alternate;
  t !== null && (e.alternate = null, MS(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && (delete t[Fr], delete t[kl], delete t[Sp], delete t[nM], delete t[iM])), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null;
}
function DS(e) {
  return e.tag === 5 || e.tag === 3 || e.tag === 4;
}
function fb(e) {
  e: for (; ; ) {
    for (; e.sibling === null; ) {
      if (e.return === null || DS(e.return)) return null;
      e = e.return;
    }
    for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18; ) {
      if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
      e.child.return = e, e = e.child;
    }
    if (!(e.flags & 2)) return e.stateNode;
  }
}
function zp(e, t, r) {
  var n = e.tag;
  if (n === 5 || n === 6) e = e.stateNode, t ? r.nodeType === 8 ? r.parentNode.insertBefore(e, t) : r.insertBefore(e, t) : (r.nodeType === 8 ? (t = r.parentNode, t.insertBefore(e, r)) : (t = r, t.appendChild(e)), r = r._reactRootContainer, r != null || t.onclick !== null || (t.onclick = oc));
  else if (n !== 4 && (e = e.child, e !== null)) for (zp(e, t, r), e = e.sibling; e !== null; ) zp(e, t, r), e = e.sibling;
}
function Bp(e, t, r) {
  var n = e.tag;
  if (n === 5 || n === 6) e = e.stateNode, t ? r.insertBefore(e, t) : r.appendChild(e);
  else if (n !== 4 && (e = e.child, e !== null)) for (Bp(e, t, r), e = e.sibling; e !== null; ) Bp(e, t, r), e = e.sibling;
}
var st = null, Or = !1;
function Fn(e, t, r) {
  for (r = r.child; r !== null; ) NS(e, t, r), r = r.sibling;
}
function NS(e, t, r) {
  if (Vr && typeof Vr.onCommitFiberUnmount == "function") try {
    Vr.onCommitFiberUnmount(If, r);
  } catch {
  }
  switch (r.tag) {
    case 5:
      gt || Aa(r, t);
    case 6:
      var n = st, i = Or;
      st = null, Fn(e, t, r), st = n, Or = i, st !== null && (Or ? (e = st, r = r.stateNode, e.nodeType === 8 ? e.parentNode.removeChild(r) : e.removeChild(r)) : st.removeChild(r.stateNode));
      break;
    case 18:
      st !== null && (Or ? (e = st, r = r.stateNode, e.nodeType === 8 ? hv(e.parentNode, r) : e.nodeType === 1 && hv(e, r), Pl(e)) : hv(st, r.stateNode));
      break;
    case 4:
      n = st, i = Or, st = r.stateNode.containerInfo, Or = !0, Fn(e, t, r), st = n, Or = i;
      break;
    case 0:
    case 11:
    case 14:
    case 15:
      if (!gt && (n = r.updateQueue, n !== null && (n = n.lastEffect, n !== null))) {
        i = n = n.next;
        do {
          var a = i, o = a.destroy;
          a = a.tag, o !== void 0 && (a & 2 || a & 4) && Lp(r, t, o), i = i.next;
        } while (i !== n);
      }
      Fn(e, t, r);
      break;
    case 1:
      if (!gt && (Aa(r, t), n = r.stateNode, typeof n.componentWillUnmount == "function")) try {
        n.props = r.memoizedProps, n.state = r.memoizedState, n.componentWillUnmount();
      } catch (l) {
        $e(r, t, l);
      }
      Fn(e, t, r);
      break;
    case 21:
      Fn(e, t, r);
      break;
    case 22:
      r.mode & 1 ? (gt = (n = gt) || r.memoizedState !== null, Fn(e, t, r), gt = n) : Fn(e, t, r);
      break;
    default:
      Fn(e, t, r);
  }
}
function db(e) {
  var t = e.updateQueue;
  if (t !== null) {
    e.updateQueue = null;
    var r = e.stateNode;
    r === null && (r = e.stateNode = new xM()), t.forEach(function(n) {
      var i = jM.bind(null, e, n);
      r.has(n) || (r.add(n), n.then(i, i));
    });
  }
}
function wr(e, t) {
  var r = t.deletions;
  if (r !== null) for (var n = 0; n < r.length; n++) {
    var i = r[n];
    try {
      var a = e, o = t, l = o;
      e: for (; l !== null; ) {
        switch (l.tag) {
          case 5:
            st = l.stateNode, Or = !1;
            break e;
          case 3:
            st = l.stateNode.containerInfo, Or = !0;
            break e;
          case 4:
            st = l.stateNode.containerInfo, Or = !0;
            break e;
        }
        l = l.return;
      }
      if (st === null) throw Error($(160));
      NS(a, o, i), st = null, Or = !1;
      var u = i.alternate;
      u !== null && (u.return = null), i.return = null;
    } catch (s) {
      $e(i, t, s);
    }
  }
  if (t.subtreeFlags & 12854) for (t = t.child; t !== null; ) $S(t, e), t = t.sibling;
}
function $S(e, t) {
  var r = e.alternate, n = e.flags;
  switch (e.tag) {
    case 0:
    case 11:
    case 14:
    case 15:
      if (wr(t, e), Lr(e), n & 4) {
        try {
          fl(3, e, e.return), Lf(3, e);
        } catch (y) {
          $e(e, e.return, y);
        }
        try {
          fl(5, e, e.return);
        } catch (y) {
          $e(e, e.return, y);
        }
      }
      break;
    case 1:
      wr(t, e), Lr(e), n & 512 && r !== null && Aa(r, r.return);
      break;
    case 5:
      if (wr(t, e), Lr(e), n & 512 && r !== null && Aa(r, r.return), e.flags & 32) {
        var i = e.stateNode;
        try {
          gl(i, "");
        } catch (y) {
          $e(e, e.return, y);
        }
      }
      if (n & 4 && (i = e.stateNode, i != null)) {
        var a = e.memoizedProps, o = r !== null ? r.memoizedProps : a, l = e.type, u = e.updateQueue;
        if (e.updateQueue = null, u !== null) try {
          l === "input" && a.type === "radio" && a.name != null && iO(i, a), cp(l, o);
          var s = cp(l, a);
          for (o = 0; o < u.length; o += 2) {
            var c = u[o], f = u[o + 1];
            c === "style" ? sO(i, f) : c === "dangerouslySetInnerHTML" ? lO(i, f) : c === "children" ? gl(i, f) : lm(i, c, f, s);
          }
          switch (l) {
            case "input":
              ap(i, a);
              break;
            case "textarea":
              aO(i, a);
              break;
            case "select":
              var v = i._wrapperState.wasMultiple;
              i._wrapperState.wasMultiple = !!a.multiple;
              var p = a.value;
              p != null ? Ta(i, !!a.multiple, p, !1) : v !== !!a.multiple && (a.defaultValue != null ? Ta(
                i,
                !!a.multiple,
                a.defaultValue,
                !0
              ) : Ta(i, !!a.multiple, a.multiple ? [] : "", !1));
          }
          i[kl] = a;
        } catch (y) {
          $e(e, e.return, y);
        }
      }
      break;
    case 6:
      if (wr(t, e), Lr(e), n & 4) {
        if (e.stateNode === null) throw Error($(162));
        i = e.stateNode, a = e.memoizedProps;
        try {
          i.nodeValue = a;
        } catch (y) {
          $e(e, e.return, y);
        }
      }
      break;
    case 3:
      if (wr(t, e), Lr(e), n & 4 && r !== null && r.memoizedState.isDehydrated) try {
        Pl(t.containerInfo);
      } catch (y) {
        $e(e, e.return, y);
      }
      break;
    case 4:
      wr(t, e), Lr(e);
      break;
    case 13:
      wr(t, e), Lr(e), i = e.child, i.flags & 8192 && (a = i.memoizedState !== null, i.stateNode.isHidden = a, !a || i.alternate !== null && i.alternate.memoizedState !== null || (Bm = ze())), n & 4 && db(e);
      break;
    case 22:
      if (c = r !== null && r.memoizedState !== null, e.mode & 1 ? (gt = (s = gt) || c, wr(t, e), gt = s) : wr(t, e), Lr(e), n & 8192) {
        if (s = e.memoizedState !== null, (e.stateNode.isHidden = s) && !c && e.mode & 1) for (K = e, c = e.child; c !== null; ) {
          for (f = K = c; K !== null; ) {
            switch (v = K, p = v.child, v.tag) {
              case 0:
              case 11:
              case 14:
              case 15:
                fl(4, v, v.return);
                break;
              case 1:
                Aa(v, v.return);
                var h = v.stateNode;
                if (typeof h.componentWillUnmount == "function") {
                  n = v, r = v.return;
                  try {
                    t = n, h.props = t.memoizedProps, h.state = t.memoizedState, h.componentWillUnmount();
                  } catch (y) {
                    $e(n, r, y);
                  }
                }
                break;
              case 5:
                Aa(v, v.return);
                break;
              case 22:
                if (v.memoizedState !== null) {
                  pb(f);
                  continue;
                }
            }
            p !== null ? (p.return = v, K = p) : pb(f);
          }
          c = c.sibling;
        }
        e: for (c = null, f = e; ; ) {
          if (f.tag === 5) {
            if (c === null) {
              c = f;
              try {
                i = f.stateNode, s ? (a = i.style, typeof a.setProperty == "function" ? a.setProperty("display", "none", "important") : a.display = "none") : (l = f.stateNode, u = f.memoizedProps.style, o = u != null && u.hasOwnProperty("display") ? u.display : null, l.style.display = uO("display", o));
              } catch (y) {
                $e(e, e.return, y);
              }
            }
          } else if (f.tag === 6) {
            if (c === null) try {
              f.stateNode.nodeValue = s ? "" : f.memoizedProps;
            } catch (y) {
              $e(e, e.return, y);
            }
          } else if ((f.tag !== 22 && f.tag !== 23 || f.memoizedState === null || f === e) && f.child !== null) {
            f.child.return = f, f = f.child;
            continue;
          }
          if (f === e) break e;
          for (; f.sibling === null; ) {
            if (f.return === null || f.return === e) break e;
            c === f && (c = null), f = f.return;
          }
          c === f && (c = null), f.sibling.return = f.return, f = f.sibling;
        }
      }
      break;
    case 19:
      wr(t, e), Lr(e), n & 4 && db(e);
      break;
    case 21:
      break;
    default:
      wr(
        t,
        e
      ), Lr(e);
  }
}
function Lr(e) {
  var t = e.flags;
  if (t & 2) {
    try {
      e: {
        for (var r = e.return; r !== null; ) {
          if (DS(r)) {
            var n = r;
            break e;
          }
          r = r.return;
        }
        throw Error($(160));
      }
      switch (n.tag) {
        case 5:
          var i = n.stateNode;
          n.flags & 32 && (gl(i, ""), n.flags &= -33);
          var a = fb(e);
          Bp(e, a, i);
          break;
        case 3:
        case 4:
          var o = n.stateNode.containerInfo, l = fb(e);
          zp(e, l, o);
          break;
        default:
          throw Error($(161));
      }
    } catch (u) {
      $e(e, e.return, u);
    }
    e.flags &= -3;
  }
  t & 4096 && (e.flags &= -4097);
}
function PM(e, t, r) {
  K = e, LS(e);
}
function LS(e, t, r) {
  for (var n = (e.mode & 1) !== 0; K !== null; ) {
    var i = K, a = i.child;
    if (i.tag === 22 && n) {
      var o = i.memoizedState !== null || fs;
      if (!o) {
        var l = i.alternate, u = l !== null && l.memoizedState !== null || gt;
        l = fs;
        var s = gt;
        if (fs = o, (gt = u) && !s) for (K = i; K !== null; ) o = K, u = o.child, o.tag === 22 && o.memoizedState !== null ? hb(i) : u !== null ? (u.return = o, K = u) : hb(i);
        for (; a !== null; ) K = a, LS(a), a = a.sibling;
        K = i, fs = l, gt = s;
      }
      vb(e);
    } else i.subtreeFlags & 8772 && a !== null ? (a.return = i, K = a) : vb(e);
  }
}
function vb(e) {
  for (; K !== null; ) {
    var t = K;
    if (t.flags & 8772) {
      var r = t.alternate;
      try {
        if (t.flags & 8772) switch (t.tag) {
          case 0:
          case 11:
          case 15:
            gt || Lf(5, t);
            break;
          case 1:
            var n = t.stateNode;
            if (t.flags & 4 && !gt) if (r === null) n.componentDidMount();
            else {
              var i = t.elementType === t.type ? r.memoizedProps : Pr(t.type, r.memoizedProps);
              n.componentDidUpdate(i, r.memoizedState, n.__reactInternalSnapshotBeforeUpdate);
            }
            var a = t.updateQueue;
            a !== null && Z0(t, a, n);
            break;
          case 3:
            var o = t.updateQueue;
            if (o !== null) {
              if (r = null, t.child !== null) switch (t.child.tag) {
                case 5:
                  r = t.child.stateNode;
                  break;
                case 1:
                  r = t.child.stateNode;
              }
              Z0(t, o, r);
            }
            break;
          case 5:
            var l = t.stateNode;
            if (r === null && t.flags & 4) {
              r = l;
              var u = t.memoizedProps;
              switch (t.type) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  u.autoFocus && r.focus();
                  break;
                case "img":
                  u.src && (r.src = u.src);
              }
            }
            break;
          case 6:
            break;
          case 4:
            break;
          case 12:
            break;
          case 13:
            if (t.memoizedState === null) {
              var s = t.alternate;
              if (s !== null) {
                var c = s.memoizedState;
                if (c !== null) {
                  var f = c.dehydrated;
                  f !== null && Pl(f);
                }
              }
            }
            break;
          case 19:
          case 17:
          case 21:
          case 22:
          case 23:
          case 25:
            break;
          default:
            throw Error($(163));
        }
        gt || t.flags & 512 && Rp(t);
      } catch (v) {
        $e(t, t.return, v);
      }
    }
    if (t === e) {
      K = null;
      break;
    }
    if (r = t.sibling, r !== null) {
      r.return = t.return, K = r;
      break;
    }
    K = t.return;
  }
}
function pb(e) {
  for (; K !== null; ) {
    var t = K;
    if (t === e) {
      K = null;
      break;
    }
    var r = t.sibling;
    if (r !== null) {
      r.return = t.return, K = r;
      break;
    }
    K = t.return;
  }
}
function hb(e) {
  for (; K !== null; ) {
    var t = K;
    try {
      switch (t.tag) {
        case 0:
        case 11:
        case 15:
          var r = t.return;
          try {
            Lf(4, t);
          } catch (u) {
            $e(t, r, u);
          }
          break;
        case 1:
          var n = t.stateNode;
          if (typeof n.componentDidMount == "function") {
            var i = t.return;
            try {
              n.componentDidMount();
            } catch (u) {
              $e(t, i, u);
            }
          }
          var a = t.return;
          try {
            Rp(t);
          } catch (u) {
            $e(t, a, u);
          }
          break;
        case 5:
          var o = t.return;
          try {
            Rp(t);
          } catch (u) {
            $e(t, o, u);
          }
      }
    } catch (u) {
      $e(t, t.return, u);
    }
    if (t === e) {
      K = null;
      break;
    }
    var l = t.sibling;
    if (l !== null) {
      l.return = t.return, K = l;
      break;
    }
    K = t.return;
  }
}
var OM = Math.ceil, yc = Dn.ReactCurrentDispatcher, Rm = Dn.ReactCurrentOwner, vr = Dn.ReactCurrentBatchConfig, ae = 0, at = null, Ke = null, ft = 0, Xt = 0, ka = vi(0), qe = 0, Ml = null, Vi = 0, Rf = 0, zm = 0, dl = null, Tt = null, Bm = 0, Xa = 1 / 0, cn = null, gc = !1, Fp = null, ni = null, ds = !1, qn = null, bc = 0, vl = 0, Kp = null, Ks = -1, Ws = 0;
function At() {
  return ae & 6 ? ze() : Ks !== -1 ? Ks : Ks = ze();
}
function ii(e) {
  return e.mode & 1 ? ae & 2 && ft !== 0 ? ft & -ft : oM.transition !== null ? (Ws === 0 && (Ws = wO()), Ws) : (e = ve, e !== 0 || (e = window.event, e = e === void 0 ? 16 : _O(e.type)), e) : 1;
}
function jr(e, t, r, n) {
  if (50 < vl) throw vl = 0, Kp = null, Error($(185));
  ru(e, r, n), (!(ae & 2) || e !== at) && (e === at && (!(ae & 2) && (Rf |= r), qe === 4 && Xn(e, ft)), zt(e, n), r === 1 && ae === 0 && !(t.mode & 1) && (Xa = ze() + 500, Df && pi()));
}
function zt(e, t) {
  var r = e.callbackNode;
  oT(e, t);
  var n = rc(e, e === at ? ft : 0);
  if (n === 0) r !== null && S0(r), e.callbackNode = null, e.callbackPriority = 0;
  else if (t = n & -n, e.callbackPriority !== t) {
    if (r != null && S0(r), t === 1) e.tag === 0 ? aM(mb.bind(null, e)) : XO(mb.bind(null, e)), tM(function() {
      !(ae & 6) && pi();
    }), r = null;
    else {
      switch (PO(n)) {
        case 1:
          r = dm;
          break;
        case 4:
          r = bO;
          break;
        case 16:
          r = tc;
          break;
        case 536870912:
          r = xO;
          break;
        default:
          r = tc;
      }
      r = VS(r, RS.bind(null, e));
    }
    e.callbackPriority = t, e.callbackNode = r;
  }
}
function RS(e, t) {
  if (Ks = -1, Ws = 0, ae & 6) throw Error($(327));
  var r = e.callbackNode;
  if (La() && e.callbackNode !== r) return null;
  var n = rc(e, e === at ? ft : 0);
  if (n === 0) return null;
  if (n & 30 || n & e.expiredLanes || t) t = xc(e, n);
  else {
    t = n;
    var i = ae;
    ae |= 2;
    var a = BS();
    (at !== e || ft !== t) && (cn = null, Xa = ze() + 500, Ni(e, t));
    do
      try {
        AM();
        break;
      } catch (l) {
        zS(e, l);
      }
    while (!0);
    Em(), yc.current = a, ae = i, Ke !== null ? t = 0 : (at = null, ft = 0, t = qe);
  }
  if (t !== 0) {
    if (t === 2 && (i = hp(e), i !== 0 && (n = i, t = Wp(e, i))), t === 1) throw r = Ml, Ni(e, 0), Xn(e, n), zt(e, ze()), r;
    if (t === 6) Xn(e, n);
    else {
      if (i = e.current.alternate, !(n & 30) && !SM(i) && (t = xc(e, n), t === 2 && (a = hp(e), a !== 0 && (n = a, t = Wp(e, a))), t === 1)) throw r = Ml, Ni(e, 0), Xn(e, n), zt(e, ze()), r;
      switch (e.finishedWork = i, e.finishedLanes = n, t) {
        case 0:
        case 1:
          throw Error($(345));
        case 2:
          Oi(e, Tt, cn);
          break;
        case 3:
          if (Xn(e, n), (n & 130023424) === n && (t = Bm + 500 - ze(), 10 < t)) {
            if (rc(e, 0) !== 0) break;
            if (i = e.suspendedLanes, (i & n) !== n) {
              At(), e.pingedLanes |= e.suspendedLanes & i;
              break;
            }
            e.timeoutHandle = Op(Oi.bind(null, e, Tt, cn), t);
            break;
          }
          Oi(e, Tt, cn);
          break;
        case 4:
          if (Xn(e, n), (n & 4194240) === n) break;
          for (t = e.eventTimes, i = -1; 0 < n; ) {
            var o = 31 - Ir(n);
            a = 1 << o, o = t[o], o > i && (i = o), n &= ~a;
          }
          if (n = i, n = ze() - n, n = (120 > n ? 120 : 480 > n ? 480 : 1080 > n ? 1080 : 1920 > n ? 1920 : 3e3 > n ? 3e3 : 4320 > n ? 4320 : 1960 * OM(n / 1960)) - n, 10 < n) {
            e.timeoutHandle = Op(Oi.bind(null, e, Tt, cn), n);
            break;
          }
          Oi(e, Tt, cn);
          break;
        case 5:
          Oi(e, Tt, cn);
          break;
        default:
          throw Error($(329));
      }
    }
  }
  return zt(e, ze()), e.callbackNode === r ? RS.bind(null, e) : null;
}
function Wp(e, t) {
  var r = dl;
  return e.current.memoizedState.isDehydrated && (Ni(e, t).flags |= 256), e = xc(e, t), e !== 2 && (t = Tt, Tt = r, t !== null && Up(t)), e;
}
function Up(e) {
  Tt === null ? Tt = e : Tt.push.apply(Tt, e);
}
function SM(e) {
  for (var t = e; ; ) {
    if (t.flags & 16384) {
      var r = t.updateQueue;
      if (r !== null && (r = r.stores, r !== null)) for (var n = 0; n < r.length; n++) {
        var i = r[n], a = i.getSnapshot;
        i = i.value;
        try {
          if (!Tr(a(), i)) return !1;
        } catch {
          return !1;
        }
      }
    }
    if (r = t.child, t.subtreeFlags & 16384 && r !== null) r.return = t, t = r;
    else {
      if (t === e) break;
      for (; t.sibling === null; ) {
        if (t.return === null || t.return === e) return !0;
        t = t.return;
      }
      t.sibling.return = t.return, t = t.sibling;
    }
  }
  return !0;
}
function Xn(e, t) {
  for (t &= ~zm, t &= ~Rf, e.suspendedLanes |= t, e.pingedLanes &= ~t, e = e.expirationTimes; 0 < t; ) {
    var r = 31 - Ir(t), n = 1 << r;
    e[r] = -1, t &= ~n;
  }
}
function mb(e) {
  if (ae & 6) throw Error($(327));
  La();
  var t = rc(e, 0);
  if (!(t & 1)) return zt(e, ze()), null;
  var r = xc(e, t);
  if (e.tag !== 0 && r === 2) {
    var n = hp(e);
    n !== 0 && (t = n, r = Wp(e, n));
  }
  if (r === 1) throw r = Ml, Ni(e, 0), Xn(e, t), zt(e, ze()), r;
  if (r === 6) throw Error($(345));
  return e.finishedWork = e.current.alternate, e.finishedLanes = t, Oi(e, Tt, cn), zt(e, ze()), null;
}
function Fm(e, t) {
  var r = ae;
  ae |= 1;
  try {
    return e(t);
  } finally {
    ae = r, ae === 0 && (Xa = ze() + 500, Df && pi());
  }
}
function Hi(e) {
  qn !== null && qn.tag === 0 && !(ae & 6) && La();
  var t = ae;
  ae |= 1;
  var r = vr.transition, n = ve;
  try {
    if (vr.transition = null, ve = 1, e) return e();
  } finally {
    ve = n, vr.transition = r, ae = t, !(ae & 6) && pi();
  }
}
function Km() {
  Xt = ka.current, Ee(ka);
}
function Ni(e, t) {
  e.finishedWork = null, e.finishedLanes = 0;
  var r = e.timeoutHandle;
  if (r !== -1 && (e.timeoutHandle = -1, eM(r)), Ke !== null) for (r = Ke.return; r !== null; ) {
    var n = r;
    switch (Pm(n), n.tag) {
      case 1:
        n = n.type.childContextTypes, n != null && lc();
        break;
      case 3:
        Va(), Ee(Lt), Ee(wt), Cm();
        break;
      case 5:
        jm(n);
        break;
      case 4:
        Va();
        break;
      case 13:
        Ee(Te);
        break;
      case 19:
        Ee(Te);
        break;
      case 10:
        Am(n.type._context);
        break;
      case 22:
      case 23:
        Km();
    }
    r = r.return;
  }
  if (at = e, Ke = e = ai(e.current, null), ft = Xt = t, qe = 0, Ml = null, zm = Rf = Vi = 0, Tt = dl = null, Ii !== null) {
    for (t = 0; t < Ii.length; t++) if (r = Ii[t], n = r.interleaved, n !== null) {
      r.interleaved = null;
      var i = n.next, a = r.pending;
      if (a !== null) {
        var o = a.next;
        a.next = i, n.next = o;
      }
      r.pending = n;
    }
    Ii = null;
  }
  return e;
}
function zS(e, t) {
  do {
    var r = Ke;
    try {
      if (Em(), zs.current = mc, hc) {
        for (var n = Me.memoizedState; n !== null; ) {
          var i = n.queue;
          i !== null && (i.pending = null), n = n.next;
        }
        hc = !1;
      }
      if (Ui = 0, nt = Ye = Me = null, cl = !1, jl = 0, Rm.current = null, r === null || r.return === null) {
        qe = 1, Ml = t, Ke = null;
        break;
      }
      e: {
        var a = e, o = r.return, l = r, u = t;
        if (t = ft, l.flags |= 32768, u !== null && typeof u == "object" && typeof u.then == "function") {
          var s = u, c = l, f = c.tag;
          if (!(c.mode & 1) && (f === 0 || f === 11 || f === 15)) {
            var v = c.alternate;
            v ? (c.updateQueue = v.updateQueue, c.memoizedState = v.memoizedState, c.lanes = v.lanes) : (c.updateQueue = null, c.memoizedState = null);
          }
          var p = nb(o);
          if (p !== null) {
            p.flags &= -257, ib(p, o, l, a, t), p.mode & 1 && rb(a, s, t), t = p, u = s;
            var h = t.updateQueue;
            if (h === null) {
              var y = /* @__PURE__ */ new Set();
              y.add(u), t.updateQueue = y;
            } else h.add(u);
            break e;
          } else {
            if (!(t & 1)) {
              rb(a, s, t), Wm();
              break e;
            }
            u = Error($(426));
          }
        } else if (_e && l.mode & 1) {
          var g = nb(o);
          if (g !== null) {
            !(g.flags & 65536) && (g.flags |= 256), ib(g, o, l, a, t), Om(Ha(u, l));
            break e;
          }
        }
        a = u = Ha(u, l), qe !== 4 && (qe = 2), dl === null ? dl = [a] : dl.push(a), a = o;
        do {
          switch (a.tag) {
            case 3:
              a.flags |= 65536, t &= -t, a.lanes |= t;
              var m = PS(a, u, t);
              q0(a, m);
              break e;
            case 1:
              l = u;
              var b = a.type, x = a.stateNode;
              if (!(a.flags & 128) && (typeof b.getDerivedStateFromError == "function" || x !== null && typeof x.componentDidCatch == "function" && (ni === null || !ni.has(x)))) {
                a.flags |= 65536, t &= -t, a.lanes |= t;
                var w = OS(a, l, t);
                q0(a, w);
                break e;
              }
          }
          a = a.return;
        } while (a !== null);
      }
      KS(r);
    } catch (P) {
      t = P, Ke === r && r !== null && (Ke = r = r.return);
      continue;
    }
    break;
  } while (!0);
}
function BS() {
  var e = yc.current;
  return yc.current = mc, e === null ? mc : e;
}
function Wm() {
  (qe === 0 || qe === 3 || qe === 2) && (qe = 4), at === null || !(Vi & 268435455) && !(Rf & 268435455) || Xn(at, ft);
}
function xc(e, t) {
  var r = ae;
  ae |= 2;
  var n = BS();
  (at !== e || ft !== t) && (cn = null, Ni(e, t));
  do
    try {
      EM();
      break;
    } catch (i) {
      zS(e, i);
    }
  while (!0);
  if (Em(), ae = r, yc.current = n, Ke !== null) throw Error($(261));
  return at = null, ft = 0, qe;
}
function EM() {
  for (; Ke !== null; ) FS(Ke);
}
function AM() {
  for (; Ke !== null && !ZC(); ) FS(Ke);
}
function FS(e) {
  var t = US(e.alternate, e, Xt);
  e.memoizedProps = e.pendingProps, t === null ? KS(e) : Ke = t, Rm.current = null;
}
function KS(e) {
  var t = e;
  do {
    var r = t.alternate;
    if (e = t.return, t.flags & 32768) {
      if (r = bM(r, t), r !== null) {
        r.flags &= 32767, Ke = r;
        return;
      }
      if (e !== null) e.flags |= 32768, e.subtreeFlags = 0, e.deletions = null;
      else {
        qe = 6, Ke = null;
        return;
      }
    } else if (r = gM(r, t, Xt), r !== null) {
      Ke = r;
      return;
    }
    if (t = t.sibling, t !== null) {
      Ke = t;
      return;
    }
    Ke = t = e;
  } while (t !== null);
  qe === 0 && (qe = 5);
}
function Oi(e, t, r) {
  var n = ve, i = vr.transition;
  try {
    vr.transition = null, ve = 1, kM(e, t, r, n);
  } finally {
    vr.transition = i, ve = n;
  }
  return null;
}
function kM(e, t, r, n) {
  do
    La();
  while (qn !== null);
  if (ae & 6) throw Error($(327));
  r = e.finishedWork;
  var i = e.finishedLanes;
  if (r === null) return null;
  if (e.finishedWork = null, e.finishedLanes = 0, r === e.current) throw Error($(177));
  e.callbackNode = null, e.callbackPriority = 0;
  var a = r.lanes | r.childLanes;
  if (lT(e, a), e === at && (Ke = at = null, ft = 0), !(r.subtreeFlags & 2064) && !(r.flags & 2064) || ds || (ds = !0, VS(tc, function() {
    return La(), null;
  })), a = (r.flags & 15990) !== 0, r.subtreeFlags & 15990 || a) {
    a = vr.transition, vr.transition = null;
    var o = ve;
    ve = 1;
    var l = ae;
    ae |= 4, Rm.current = null, wM(e, r), $S(r, e), XT(wp), nc = !!xp, wp = xp = null, e.current = r, PM(r), QC(), ae = l, ve = o, vr.transition = a;
  } else e.current = r;
  if (ds && (ds = !1, qn = e, bc = i), a = e.pendingLanes, a === 0 && (ni = null), tT(r.stateNode), zt(e, ze()), t !== null) for (n = e.onRecoverableError, r = 0; r < t.length; r++) i = t[r], n(i.value, { componentStack: i.stack, digest: i.digest });
  if (gc) throw gc = !1, e = Fp, Fp = null, e;
  return bc & 1 && e.tag !== 0 && La(), a = e.pendingLanes, a & 1 ? e === Kp ? vl++ : (vl = 0, Kp = e) : vl = 0, pi(), null;
}
function La() {
  if (qn !== null) {
    var e = PO(bc), t = vr.transition, r = ve;
    try {
      if (vr.transition = null, ve = 16 > e ? 16 : e, qn === null) var n = !1;
      else {
        if (e = qn, qn = null, bc = 0, ae & 6) throw Error($(331));
        var i = ae;
        for (ae |= 4, K = e.current; K !== null; ) {
          var a = K, o = a.child;
          if (K.flags & 16) {
            var l = a.deletions;
            if (l !== null) {
              for (var u = 0; u < l.length; u++) {
                var s = l[u];
                for (K = s; K !== null; ) {
                  var c = K;
                  switch (c.tag) {
                    case 0:
                    case 11:
                    case 15:
                      fl(8, c, a);
                  }
                  var f = c.child;
                  if (f !== null) f.return = c, K = f;
                  else for (; K !== null; ) {
                    c = K;
                    var v = c.sibling, p = c.return;
                    if (MS(c), c === s) {
                      K = null;
                      break;
                    }
                    if (v !== null) {
                      v.return = p, K = v;
                      break;
                    }
                    K = p;
                  }
                }
              }
              var h = a.alternate;
              if (h !== null) {
                var y = h.child;
                if (y !== null) {
                  h.child = null;
                  do {
                    var g = y.sibling;
                    y.sibling = null, y = g;
                  } while (y !== null);
                }
              }
              K = a;
            }
          }
          if (a.subtreeFlags & 2064 && o !== null) o.return = a, K = o;
          else e: for (; K !== null; ) {
            if (a = K, a.flags & 2048) switch (a.tag) {
              case 0:
              case 11:
              case 15:
                fl(9, a, a.return);
            }
            var m = a.sibling;
            if (m !== null) {
              m.return = a.return, K = m;
              break e;
            }
            K = a.return;
          }
        }
        var b = e.current;
        for (K = b; K !== null; ) {
          o = K;
          var x = o.child;
          if (o.subtreeFlags & 2064 && x !== null) x.return = o, K = x;
          else e: for (o = b; K !== null; ) {
            if (l = K, l.flags & 2048) try {
              switch (l.tag) {
                case 0:
                case 11:
                case 15:
                  Lf(9, l);
              }
            } catch (P) {
              $e(l, l.return, P);
            }
            if (l === o) {
              K = null;
              break e;
            }
            var w = l.sibling;
            if (w !== null) {
              w.return = l.return, K = w;
              break e;
            }
            K = l.return;
          }
        }
        if (ae = i, pi(), Vr && typeof Vr.onPostCommitFiberRoot == "function") try {
          Vr.onPostCommitFiberRoot(If, e);
        } catch {
        }
        n = !0;
      }
      return n;
    } finally {
      ve = r, vr.transition = t;
    }
  }
  return !1;
}
function yb(e, t, r) {
  t = Ha(r, t), t = PS(e, t, 1), e = ri(e, t, 1), t = At(), e !== null && (ru(e, 1, t), zt(e, t));
}
function $e(e, t, r) {
  if (e.tag === 3) yb(e, e, r);
  else for (; t !== null; ) {
    if (t.tag === 3) {
      yb(t, e, r);
      break;
    } else if (t.tag === 1) {
      var n = t.stateNode;
      if (typeof t.type.getDerivedStateFromError == "function" || typeof n.componentDidCatch == "function" && (ni === null || !ni.has(n))) {
        e = Ha(r, e), e = OS(t, e, 1), t = ri(t, e, 1), e = At(), t !== null && (ru(t, 1, e), zt(t, e));
        break;
      }
    }
    t = t.return;
  }
}
function _M(e, t, r) {
  var n = e.pingCache;
  n !== null && n.delete(t), t = At(), e.pingedLanes |= e.suspendedLanes & r, at === e && (ft & r) === r && (qe === 4 || qe === 3 && (ft & 130023424) === ft && 500 > ze() - Bm ? Ni(e, 0) : zm |= r), zt(e, t);
}
function WS(e, t) {
  t === 0 && (e.mode & 1 ? (t = rs, rs <<= 1, !(rs & 130023424) && (rs = 4194304)) : t = 1);
  var r = At();
  e = En(e, t), e !== null && (ru(e, t, r), zt(e, r));
}
function IM(e) {
  var t = e.memoizedState, r = 0;
  t !== null && (r = t.retryLane), WS(e, r);
}
function jM(e, t) {
  var r = 0;
  switch (e.tag) {
    case 13:
      var n = e.stateNode, i = e.memoizedState;
      i !== null && (r = i.retryLane);
      break;
    case 19:
      n = e.stateNode;
      break;
    default:
      throw Error($(314));
  }
  n !== null && n.delete(t), WS(e, r);
}
var US;
US = function(e, t, r) {
  if (e !== null) if (e.memoizedProps !== t.pendingProps || Lt.current) Mt = !0;
  else {
    if (!(e.lanes & r) && !(t.flags & 128)) return Mt = !1, yM(e, t, r);
    Mt = !!(e.flags & 131072);
  }
  else Mt = !1, _e && t.flags & 1048576 && YO(t, cc, t.index);
  switch (t.lanes = 0, t.tag) {
    case 2:
      var n = t.type;
      Fs(e, t), e = t.pendingProps;
      var i = Ka(t, wt.current);
      $a(t, r), i = Mm(null, t, n, e, i, r);
      var a = Dm();
      return t.flags |= 1, typeof i == "object" && i !== null && typeof i.render == "function" && i.$$typeof === void 0 ? (t.tag = 1, t.memoizedState = null, t.updateQueue = null, Rt(n) ? (a = !0, uc(t)) : a = !1, t.memoizedState = i.state !== null && i.state !== void 0 ? i.state : null, _m(t), i.updater = $f, t.stateNode = i, i._reactInternals = t, jp(t, n, e, r), t = Mp(null, t, n, !0, a, r)) : (t.tag = 0, _e && a && wm(t), Ot(null, t, i, r), t = t.child), t;
    case 16:
      n = t.elementType;
      e: {
        switch (Fs(e, t), e = t.pendingProps, i = n._init, n = i(n._payload), t.type = n, i = t.tag = TM(n), e = Pr(n, e), i) {
          case 0:
            t = Tp(null, t, n, e, r);
            break e;
          case 1:
            t = lb(null, t, n, e, r);
            break e;
          case 11:
            t = ab(null, t, n, e, r);
            break e;
          case 14:
            t = ob(null, t, n, Pr(n.type, e), r);
            break e;
        }
        throw Error($(
          306,
          n,
          ""
        ));
      }
      return t;
    case 0:
      return n = t.type, i = t.pendingProps, i = t.elementType === n ? i : Pr(n, i), Tp(e, t, n, i, r);
    case 1:
      return n = t.type, i = t.pendingProps, i = t.elementType === n ? i : Pr(n, i), lb(e, t, n, i, r);
    case 3:
      e: {
        if (kS(t), e === null) throw Error($(387));
        n = t.pendingProps, a = t.memoizedState, i = a.element, eS(e, t), vc(t, n, null, r);
        var o = t.memoizedState;
        if (n = o.element, a.isDehydrated) if (a = { element: n, isDehydrated: !1, cache: o.cache, pendingSuspenseBoundaries: o.pendingSuspenseBoundaries, transitions: o.transitions }, t.updateQueue.baseState = a, t.memoizedState = a, t.flags & 256) {
          i = Ha(Error($(423)), t), t = ub(e, t, n, r, i);
          break e;
        } else if (n !== i) {
          i = Ha(Error($(424)), t), t = ub(e, t, n, r, i);
          break e;
        } else for (Gt = ti(t.stateNode.containerInfo.firstChild), Zt = t, _e = !0, Sr = null, r = QO(t, null, n, r), t.child = r; r; ) r.flags = r.flags & -3 | 4096, r = r.sibling;
        else {
          if (Wa(), n === i) {
            t = An(e, t, r);
            break e;
          }
          Ot(e, t, n, r);
        }
        t = t.child;
      }
      return t;
    case 5:
      return tS(t), e === null && kp(t), n = t.type, i = t.pendingProps, a = e !== null ? e.memoizedProps : null, o = i.children, Pp(n, i) ? o = null : a !== null && Pp(n, a) && (t.flags |= 32), AS(e, t), Ot(e, t, o, r), t.child;
    case 6:
      return e === null && kp(t), null;
    case 13:
      return _S(e, t, r);
    case 4:
      return Im(t, t.stateNode.containerInfo), n = t.pendingProps, e === null ? t.child = Ua(t, null, n, r) : Ot(e, t, n, r), t.child;
    case 11:
      return n = t.type, i = t.pendingProps, i = t.elementType === n ? i : Pr(n, i), ab(e, t, n, i, r);
    case 7:
      return Ot(e, t, t.pendingProps, r), t.child;
    case 8:
      return Ot(e, t, t.pendingProps.children, r), t.child;
    case 12:
      return Ot(e, t, t.pendingProps.children, r), t.child;
    case 10:
      e: {
        if (n = t.type._context, i = t.pendingProps, a = t.memoizedProps, o = i.value, Pe(fc, n._currentValue), n._currentValue = o, a !== null) if (Tr(a.value, o)) {
          if (a.children === i.children && !Lt.current) {
            t = An(e, t, r);
            break e;
          }
        } else for (a = t.child, a !== null && (a.return = t); a !== null; ) {
          var l = a.dependencies;
          if (l !== null) {
            o = a.child;
            for (var u = l.firstContext; u !== null; ) {
              if (u.context === n) {
                if (a.tag === 1) {
                  u = xn(-1, r & -r), u.tag = 2;
                  var s = a.updateQueue;
                  if (s !== null) {
                    s = s.shared;
                    var c = s.pending;
                    c === null ? u.next = u : (u.next = c.next, c.next = u), s.pending = u;
                  }
                }
                a.lanes |= r, u = a.alternate, u !== null && (u.lanes |= r), _p(
                  a.return,
                  r,
                  t
                ), l.lanes |= r;
                break;
              }
              u = u.next;
            }
          } else if (a.tag === 10) o = a.type === t.type ? null : a.child;
          else if (a.tag === 18) {
            if (o = a.return, o === null) throw Error($(341));
            o.lanes |= r, l = o.alternate, l !== null && (l.lanes |= r), _p(o, r, t), o = a.sibling;
          } else o = a.child;
          if (o !== null) o.return = a;
          else for (o = a; o !== null; ) {
            if (o === t) {
              o = null;
              break;
            }
            if (a = o.sibling, a !== null) {
              a.return = o.return, o = a;
              break;
            }
            o = o.return;
          }
          a = o;
        }
        Ot(e, t, i.children, r), t = t.child;
      }
      return t;
    case 9:
      return i = t.type, n = t.pendingProps.children, $a(t, r), i = pr(i), n = n(i), t.flags |= 1, Ot(e, t, n, r), t.child;
    case 14:
      return n = t.type, i = Pr(n, t.pendingProps), i = Pr(n.type, i), ob(e, t, n, i, r);
    case 15:
      return SS(e, t, t.type, t.pendingProps, r);
    case 17:
      return n = t.type, i = t.pendingProps, i = t.elementType === n ? i : Pr(n, i), Fs(e, t), t.tag = 1, Rt(n) ? (e = !0, uc(t)) : e = !1, $a(t, r), wS(t, n, i), jp(t, n, i, r), Mp(null, t, n, !0, e, r);
    case 19:
      return IS(e, t, r);
    case 22:
      return ES(e, t, r);
  }
  throw Error($(156, t.tag));
};
function VS(e, t) {
  return gO(e, t);
}
function CM(e, t, r, n) {
  this.tag = e, this.key = r, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = n, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
}
function fr(e, t, r, n) {
  return new CM(e, t, r, n);
}
function Um(e) {
  return e = e.prototype, !(!e || !e.isReactComponent);
}
function TM(e) {
  if (typeof e == "function") return Um(e) ? 1 : 0;
  if (e != null) {
    if (e = e.$$typeof, e === sm) return 11;
    if (e === cm) return 14;
  }
  return 2;
}
function ai(e, t) {
  var r = e.alternate;
  return r === null ? (r = fr(e.tag, t, e.key, e.mode), r.elementType = e.elementType, r.type = e.type, r.stateNode = e.stateNode, r.alternate = e, e.alternate = r) : (r.pendingProps = t, r.type = e.type, r.flags = 0, r.subtreeFlags = 0, r.deletions = null), r.flags = e.flags & 14680064, r.childLanes = e.childLanes, r.lanes = e.lanes, r.child = e.child, r.memoizedProps = e.memoizedProps, r.memoizedState = e.memoizedState, r.updateQueue = e.updateQueue, t = e.dependencies, r.dependencies = t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }, r.sibling = e.sibling, r.index = e.index, r.ref = e.ref, r;
}
function Us(e, t, r, n, i, a) {
  var o = 2;
  if (n = e, typeof e == "function") Um(e) && (o = 1);
  else if (typeof e == "string") o = 5;
  else e: switch (e) {
    case ya:
      return $i(r.children, i, a, t);
    case um:
      o = 8, i |= 8;
      break;
    case ep:
      return e = fr(12, r, t, i | 2), e.elementType = ep, e.lanes = a, e;
    case tp:
      return e = fr(13, r, t, i), e.elementType = tp, e.lanes = a, e;
    case rp:
      return e = fr(19, r, t, i), e.elementType = rp, e.lanes = a, e;
    case tO:
      return zf(r, i, a, t);
    default:
      if (typeof e == "object" && e !== null) switch (e.$$typeof) {
        case J1:
          o = 10;
          break e;
        case eO:
          o = 9;
          break e;
        case sm:
          o = 11;
          break e;
        case cm:
          o = 14;
          break e;
        case Kn:
          o = 16, n = null;
          break e;
      }
      throw Error($(130, e == null ? e : typeof e, ""));
  }
  return t = fr(o, r, t, i), t.elementType = e, t.type = n, t.lanes = a, t;
}
function $i(e, t, r, n) {
  return e = fr(7, e, n, t), e.lanes = r, e;
}
function zf(e, t, r, n) {
  return e = fr(22, e, n, t), e.elementType = tO, e.lanes = r, e.stateNode = { isHidden: !1 }, e;
}
function Ov(e, t, r) {
  return e = fr(6, e, null, t), e.lanes = r, e;
}
function Sv(e, t, r) {
  return t = fr(4, e.children !== null ? e.children : [], e.key, t), t.lanes = r, t.stateNode = { containerInfo: e.containerInfo, pendingChildren: null, implementation: e.implementation }, t;
}
function MM(e, t, r, n, i) {
  this.tag = t, this.containerInfo = e, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = iv(0), this.expirationTimes = iv(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = iv(0), this.identifierPrefix = n, this.onRecoverableError = i, this.mutableSourceEagerHydrationData = null;
}
function Vm(e, t, r, n, i, a, o, l, u) {
  return e = new MM(e, t, r, l, u), t === 1 ? (t = 1, a === !0 && (t |= 8)) : t = 0, a = fr(3, null, null, t), e.current = a, a.stateNode = e, a.memoizedState = { element: n, isDehydrated: r, cache: null, transitions: null, pendingSuspenseBoundaries: null }, _m(a), e;
}
function DM(e, t, r) {
  var n = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
  return { $$typeof: ma, key: n == null ? null : "" + n, children: e, containerInfo: t, implementation: r };
}
function HS(e) {
  if (!e) return ui;
  e = e._reactInternals;
  e: {
    if (ia(e) !== e || e.tag !== 1) throw Error($(170));
    var t = e;
    do {
      switch (t.tag) {
        case 3:
          t = t.stateNode.context;
          break e;
        case 1:
          if (Rt(t.type)) {
            t = t.stateNode.__reactInternalMemoizedMergedChildContext;
            break e;
          }
      }
      t = t.return;
    } while (t !== null);
    throw Error($(171));
  }
  if (e.tag === 1) {
    var r = e.type;
    if (Rt(r)) return HO(e, r, t);
  }
  return t;
}
function XS(e, t, r, n, i, a, o, l, u) {
  return e = Vm(r, n, !0, e, i, a, o, l, u), e.context = HS(null), r = e.current, n = At(), i = ii(r), a = xn(n, i), a.callback = t ?? null, ri(r, a, i), e.current.lanes = i, ru(e, i, n), zt(e, n), e;
}
function Bf(e, t, r, n) {
  var i = t.current, a = At(), o = ii(i);
  return r = HS(r), t.context === null ? t.context = r : t.pendingContext = r, t = xn(a, o), t.payload = { element: e }, n = n === void 0 ? null : n, n !== null && (t.callback = n), e = ri(i, t, o), e !== null && (jr(e, i, o, a), Rs(e, i, o)), o;
}
function wc(e) {
  if (e = e.current, !e.child) return null;
  switch (e.child.tag) {
    case 5:
      return e.child.stateNode;
    default:
      return e.child.stateNode;
  }
}
function gb(e, t) {
  if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
    var r = e.retryLane;
    e.retryLane = r !== 0 && r < t ? r : t;
  }
}
function Hm(e, t) {
  gb(e, t), (e = e.alternate) && gb(e, t);
}
function NM() {
  return null;
}
var YS = typeof reportError == "function" ? reportError : function(e) {
  console.error(e);
};
function Xm(e) {
  this._internalRoot = e;
}
Ff.prototype.render = Xm.prototype.render = function(e) {
  var t = this._internalRoot;
  if (t === null) throw Error($(409));
  Bf(e, t, null, null);
};
Ff.prototype.unmount = Xm.prototype.unmount = function() {
  var e = this._internalRoot;
  if (e !== null) {
    this._internalRoot = null;
    var t = e.containerInfo;
    Hi(function() {
      Bf(null, e, null, null);
    }), t[Sn] = null;
  }
};
function Ff(e) {
  this._internalRoot = e;
}
Ff.prototype.unstable_scheduleHydration = function(e) {
  if (e) {
    var t = EO();
    e = { blockedOn: null, target: e, priority: t };
    for (var r = 0; r < Hn.length && t !== 0 && t < Hn[r].priority; r++) ;
    Hn.splice(r, 0, e), r === 0 && kO(e);
  }
};
function Ym(e) {
  return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11);
}
function Kf(e) {
  return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11 && (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "));
}
function bb() {
}
function $M(e, t, r, n, i) {
  if (i) {
    if (typeof n == "function") {
      var a = n;
      n = function() {
        var s = wc(o);
        a.call(s);
      };
    }
    var o = XS(t, n, e, 0, null, !1, !1, "", bb);
    return e._reactRootContainer = o, e[Sn] = o.current, El(e.nodeType === 8 ? e.parentNode : e), Hi(), o;
  }
  for (; i = e.lastChild; ) e.removeChild(i);
  if (typeof n == "function") {
    var l = n;
    n = function() {
      var s = wc(u);
      l.call(s);
    };
  }
  var u = Vm(e, 0, !1, null, null, !1, !1, "", bb);
  return e._reactRootContainer = u, e[Sn] = u.current, El(e.nodeType === 8 ? e.parentNode : e), Hi(function() {
    Bf(t, u, r, n);
  }), u;
}
function Wf(e, t, r, n, i) {
  var a = r._reactRootContainer;
  if (a) {
    var o = a;
    if (typeof i == "function") {
      var l = i;
      i = function() {
        var u = wc(o);
        l.call(u);
      };
    }
    Bf(t, o, e, i);
  } else o = $M(r, t, e, i, n);
  return wc(o);
}
OO = function(e) {
  switch (e.tag) {
    case 3:
      var t = e.stateNode;
      if (t.current.memoizedState.isDehydrated) {
        var r = tl(t.pendingLanes);
        r !== 0 && (vm(t, r | 1), zt(t, ze()), !(ae & 6) && (Xa = ze() + 500, pi()));
      }
      break;
    case 13:
      Hi(function() {
        var n = En(e, 1);
        if (n !== null) {
          var i = At();
          jr(n, e, 1, i);
        }
      }), Hm(e, 1);
  }
};
pm = function(e) {
  if (e.tag === 13) {
    var t = En(e, 134217728);
    if (t !== null) {
      var r = At();
      jr(t, e, 134217728, r);
    }
    Hm(e, 134217728);
  }
};
SO = function(e) {
  if (e.tag === 13) {
    var t = ii(e), r = En(e, t);
    if (r !== null) {
      var n = At();
      jr(r, e, t, n);
    }
    Hm(e, t);
  }
};
EO = function() {
  return ve;
};
AO = function(e, t) {
  var r = ve;
  try {
    return ve = e, t();
  } finally {
    ve = r;
  }
};
dp = function(e, t, r) {
  switch (t) {
    case "input":
      if (ap(e, r), t = r.name, r.type === "radio" && t != null) {
        for (r = e; r.parentNode; ) r = r.parentNode;
        for (r = r.querySelectorAll("input[name=" + JSON.stringify("" + t) + '][type="radio"]'), t = 0; t < r.length; t++) {
          var n = r[t];
          if (n !== e && n.form === e.form) {
            var i = Mf(n);
            if (!i) throw Error($(90));
            nO(n), ap(n, i);
          }
        }
      }
      break;
    case "textarea":
      aO(e, r);
      break;
    case "select":
      t = r.value, t != null && Ta(e, !!r.multiple, t, !1);
  }
};
dO = Fm;
vO = Hi;
var LM = { usingClientEntryPoint: !1, Events: [iu, wa, Mf, cO, fO, Fm] }, Wo = { findFiberByHostInstance: _i, bundleType: 0, version: "18.3.1", rendererPackageName: "react-dom" }, RM = { bundleType: Wo.bundleType, version: Wo.version, rendererPackageName: Wo.rendererPackageName, rendererConfig: Wo.rendererConfig, overrideHookState: null, overrideHookStateDeletePath: null, overrideHookStateRenamePath: null, overrideProps: null, overridePropsDeletePath: null, overridePropsRenamePath: null, setErrorHandler: null, setSuspenseHandler: null, scheduleUpdate: null, currentDispatcherRef: Dn.ReactCurrentDispatcher, findHostInstanceByFiber: function(e) {
  return e = mO(e), e === null ? null : e.stateNode;
}, findFiberByHostInstance: Wo.findFiberByHostInstance || NM, findHostInstancesForRefresh: null, scheduleRefresh: null, scheduleRoot: null, setRefreshHandler: null, getCurrentFiber: null, reconcilerVersion: "18.3.1-next-f1338f8080-20240426" };
if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
  var vs = __REACT_DEVTOOLS_GLOBAL_HOOK__;
  if (!vs.isDisabled && vs.supportsFiber) try {
    If = vs.inject(RM), Vr = vs;
  } catch {
  }
}
rr.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = LM;
rr.createPortal = function(e, t) {
  var r = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
  if (!Ym(t)) throw Error($(200));
  return DM(e, t, null, r);
};
rr.createRoot = function(e, t) {
  if (!Ym(e)) throw Error($(299));
  var r = !1, n = "", i = YS;
  return t != null && (t.unstable_strictMode === !0 && (r = !0), t.identifierPrefix !== void 0 && (n = t.identifierPrefix), t.onRecoverableError !== void 0 && (i = t.onRecoverableError)), t = Vm(e, 1, !1, null, null, r, !1, n, i), e[Sn] = t.current, El(e.nodeType === 8 ? e.parentNode : e), new Xm(t);
};
rr.findDOMNode = function(e) {
  if (e == null) return null;
  if (e.nodeType === 1) return e;
  var t = e._reactInternals;
  if (t === void 0)
    throw typeof e.render == "function" ? Error($(188)) : (e = Object.keys(e).join(","), Error($(268, e)));
  return e = mO(t), e = e === null ? null : e.stateNode, e;
};
rr.flushSync = function(e) {
  return Hi(e);
};
rr.hydrate = function(e, t, r) {
  if (!Kf(t)) throw Error($(200));
  return Wf(null, e, t, !0, r);
};
rr.hydrateRoot = function(e, t, r) {
  if (!Ym(e)) throw Error($(405));
  var n = r != null && r.hydratedSources || null, i = !1, a = "", o = YS;
  if (r != null && (r.unstable_strictMode === !0 && (i = !0), r.identifierPrefix !== void 0 && (a = r.identifierPrefix), r.onRecoverableError !== void 0 && (o = r.onRecoverableError)), t = XS(t, null, e, 1, r ?? null, i, !1, a, o), e[Sn] = t.current, El(e), n) for (e = 0; e < n.length; e++) r = n[e], i = r._getVersion, i = i(r._source), t.mutableSourceEagerHydrationData == null ? t.mutableSourceEagerHydrationData = [r, i] : t.mutableSourceEagerHydrationData.push(
    r,
    i
  );
  return new Ff(t);
};
rr.render = function(e, t, r) {
  if (!Kf(t)) throw Error($(200));
  return Wf(null, e, t, !1, r);
};
rr.unmountComponentAtNode = function(e) {
  if (!Kf(e)) throw Error($(40));
  return e._reactRootContainer ? (Hi(function() {
    Wf(null, null, e, !1, function() {
      e._reactRootContainer = null, e[Sn] = null;
    });
  }), !0) : !1;
};
rr.unstable_batchedUpdates = Fm;
rr.unstable_renderSubtreeIntoContainer = function(e, t, r, n) {
  if (!Kf(r)) throw Error($(200));
  if (e == null || e._reactInternals === void 0) throw Error($(38));
  return Wf(e, t, r, !1, n);
};
rr.version = "18.3.1-next-f1338f8080-20240426";
function GS() {
  if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
    try {
      __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(GS);
    } catch (e) {
      console.error(e);
    }
}
GS(), G1.exports = rr;
var Uf = G1.exports;
const bZ = /* @__PURE__ */ Wt(Uf);
function qS(e) {
  var t, r, n = "";
  if (typeof e == "string" || typeof e == "number") n += e;
  else if (typeof e == "object") if (Array.isArray(e)) {
    var i = e.length;
    for (t = 0; t < i; t++) e[t] && (r = qS(e[t])) && (n && (n += " "), n += r);
  } else for (r in e) e[r] && (n && (n += " "), n += r);
  return n;
}
function Y() {
  for (var e, t, r = 0, n = "", i = arguments.length; r < i; r++) (e = arguments[r]) && (t = qS(e)) && (n && (n += " "), n += t);
  return n;
}
var zM = ["dangerouslySetInnerHTML", "onCopy", "onCopyCapture", "onCut", "onCutCapture", "onPaste", "onPasteCapture", "onCompositionEnd", "onCompositionEndCapture", "onCompositionStart", "onCompositionStartCapture", "onCompositionUpdate", "onCompositionUpdateCapture", "onFocus", "onFocusCapture", "onBlur", "onBlurCapture", "onChange", "onChangeCapture", "onBeforeInput", "onBeforeInputCapture", "onInput", "onInputCapture", "onReset", "onResetCapture", "onSubmit", "onSubmitCapture", "onInvalid", "onInvalidCapture", "onLoad", "onLoadCapture", "onError", "onErrorCapture", "onKeyDown", "onKeyDownCapture", "onKeyPress", "onKeyPressCapture", "onKeyUp", "onKeyUpCapture", "onAbort", "onAbortCapture", "onCanPlay", "onCanPlayCapture", "onCanPlayThrough", "onCanPlayThroughCapture", "onDurationChange", "onDurationChangeCapture", "onEmptied", "onEmptiedCapture", "onEncrypted", "onEncryptedCapture", "onEnded", "onEndedCapture", "onLoadedData", "onLoadedDataCapture", "onLoadedMetadata", "onLoadedMetadataCapture", "onLoadStart", "onLoadStartCapture", "onPause", "onPauseCapture", "onPlay", "onPlayCapture", "onPlaying", "onPlayingCapture", "onProgress", "onProgressCapture", "onRateChange", "onRateChangeCapture", "onSeeked", "onSeekedCapture", "onSeeking", "onSeekingCapture", "onStalled", "onStalledCapture", "onSuspend", "onSuspendCapture", "onTimeUpdate", "onTimeUpdateCapture", "onVolumeChange", "onVolumeChangeCapture", "onWaiting", "onWaitingCapture", "onAuxClick", "onAuxClickCapture", "onClick", "onClickCapture", "onContextMenu", "onContextMenuCapture", "onDoubleClick", "onDoubleClickCapture", "onDrag", "onDragCapture", "onDragEnd", "onDragEndCapture", "onDragEnter", "onDragEnterCapture", "onDragExit", "onDragExitCapture", "onDragLeave", "onDragLeaveCapture", "onDragOver", "onDragOverCapture", "onDragStart", "onDragStartCapture", "onDrop", "onDropCapture", "onMouseDown", "onMouseDownCapture", "onMouseEnter", "onMouseLeave", "onMouseMove", "onMouseMoveCapture", "onMouseOut", "onMouseOutCapture", "onMouseOver", "onMouseOverCapture", "onMouseUp", "onMouseUpCapture", "onSelect", "onSelectCapture", "onTouchCancel", "onTouchCancelCapture", "onTouchEnd", "onTouchEndCapture", "onTouchMove", "onTouchMoveCapture", "onTouchStart", "onTouchStartCapture", "onPointerDown", "onPointerDownCapture", "onPointerMove", "onPointerMoveCapture", "onPointerUp", "onPointerUpCapture", "onPointerCancel", "onPointerCancelCapture", "onPointerEnter", "onPointerEnterCapture", "onPointerLeave", "onPointerLeaveCapture", "onPointerOver", "onPointerOverCapture", "onPointerOut", "onPointerOutCapture", "onGotPointerCapture", "onGotPointerCaptureCapture", "onLostPointerCapture", "onLostPointerCaptureCapture", "onScroll", "onScrollCapture", "onWheel", "onWheelCapture", "onAnimationStart", "onAnimationStartCapture", "onAnimationEnd", "onAnimationEndCapture", "onAnimationIteration", "onAnimationIterationCapture", "onTransitionEnd", "onTransitionEndCapture"];
function Gm(e) {
  if (typeof e != "string")
    return !1;
  var t = zM;
  return t.includes(e);
}
var BM = [
  "aria-activedescendant",
  "aria-atomic",
  "aria-autocomplete",
  "aria-busy",
  "aria-checked",
  "aria-colcount",
  "aria-colindex",
  "aria-colspan",
  "aria-controls",
  "aria-current",
  "aria-describedby",
  "aria-details",
  "aria-disabled",
  "aria-errormessage",
  "aria-expanded",
  "aria-flowto",
  "aria-haspopup",
  "aria-hidden",
  "aria-invalid",
  "aria-keyshortcuts",
  "aria-label",
  "aria-labelledby",
  "aria-level",
  "aria-live",
  "aria-modal",
  "aria-multiline",
  "aria-multiselectable",
  "aria-orientation",
  "aria-owns",
  "aria-placeholder",
  "aria-posinset",
  "aria-pressed",
  "aria-readonly",
  "aria-relevant",
  "aria-required",
  "aria-roledescription",
  "aria-rowcount",
  "aria-rowindex",
  "aria-rowspan",
  "aria-selected",
  "aria-setsize",
  "aria-sort",
  "aria-valuemax",
  "aria-valuemin",
  "aria-valuenow",
  "aria-valuetext",
  "className",
  "color",
  "height",
  "id",
  "lang",
  "max",
  "media",
  "method",
  "min",
  "name",
  "style",
  /*
   * removed 'type' SVGElementPropKey because we do not currently use any SVG elements
   * that can use it, and it conflicts with the recharts prop 'type'
   * https://github.com/recharts/recharts/pull/3327
   * https://developer.mozilla.org/en-US/docs/Web/SVG/Attribute/type
   */
  // 'type',
  "target",
  "width",
  "role",
  "tabIndex",
  "accentHeight",
  "accumulate",
  "additive",
  "alignmentBaseline",
  "allowReorder",
  "alphabetic",
  "amplitude",
  "arabicForm",
  "ascent",
  "attributeName",
  "attributeType",
  "autoReverse",
  "azimuth",
  "baseFrequency",
  "baselineShift",
  "baseProfile",
  "bbox",
  "begin",
  "bias",
  "by",
  "calcMode",
  "capHeight",
  "clip",
  "clipPath",
  "clipPathUnits",
  "clipRule",
  "colorInterpolation",
  "colorInterpolationFilters",
  "colorProfile",
  "colorRendering",
  "contentScriptType",
  "contentStyleType",
  "cursor",
  "cx",
  "cy",
  "d",
  "decelerate",
  "descent",
  "diffuseConstant",
  "direction",
  "display",
  "divisor",
  "dominantBaseline",
  "dur",
  "dx",
  "dy",
  "edgeMode",
  "elevation",
  "enableBackground",
  "end",
  "exponent",
  "externalResourcesRequired",
  "fill",
  "fillOpacity",
  "fillRule",
  "filter",
  "filterRes",
  "filterUnits",
  "floodColor",
  "floodOpacity",
  "focusable",
  "fontFamily",
  "fontSize",
  "fontSizeAdjust",
  "fontStretch",
  "fontStyle",
  "fontVariant",
  "fontWeight",
  "format",
  "from",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyphName",
  "glyphOrientationHorizontal",
  "glyphOrientationVertical",
  "glyphRef",
  "gradientTransform",
  "gradientUnits",
  "hanging",
  "horizAdvX",
  "horizOriginX",
  "href",
  "ideographic",
  "imageRendering",
  "in2",
  "in",
  "intercept",
  "k1",
  "k2",
  "k3",
  "k4",
  "k",
  "kernelMatrix",
  "kernelUnitLength",
  "kerning",
  "keyPoints",
  "keySplines",
  "keyTimes",
  "lengthAdjust",
  "letterSpacing",
  "lightingColor",
  "limitingConeAngle",
  "local",
  "markerEnd",
  "markerHeight",
  "markerMid",
  "markerStart",
  "markerUnits",
  "markerWidth",
  "mask",
  "maskContentUnits",
  "maskUnits",
  "mathematical",
  "mode",
  "numOctaves",
  "offset",
  "opacity",
  "operator",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "overlinePosition",
  "overlineThickness",
  "paintOrder",
  "panose1",
  "pathLength",
  "patternContentUnits",
  "patternTransform",
  "patternUnits",
  "pointerEvents",
  "pointsAtX",
  "pointsAtY",
  "pointsAtZ",
  "preserveAlpha",
  "preserveAspectRatio",
  "primitiveUnits",
  "r",
  "radius",
  "refX",
  "refY",
  "renderingIntent",
  "repeatCount",
  "repeatDur",
  "requiredExtensions",
  "requiredFeatures",
  "restart",
  "result",
  "rotate",
  "rx",
  "ry",
  "seed",
  "shapeRendering",
  "slope",
  "spacing",
  "specularConstant",
  "specularExponent",
  "speed",
  "spreadMethod",
  "startOffset",
  "stdDeviation",
  "stemh",
  "stemv",
  "stitchTiles",
  "stopColor",
  "stopOpacity",
  "strikethroughPosition",
  "strikethroughThickness",
  "string",
  "stroke",
  "strokeDasharray",
  "strokeDashoffset",
  "strokeLinecap",
  "strokeLinejoin",
  "strokeMiterlimit",
  "strokeOpacity",
  "strokeWidth",
  "surfaceScale",
  "systemLanguage",
  "tableValues",
  "targetX",
  "targetY",
  "textAnchor",
  "textDecoration",
  "textLength",
  "textRendering",
  "to",
  "transform",
  "u1",
  "u2",
  "underlinePosition",
  "underlineThickness",
  "unicode",
  "unicodeBidi",
  "unicodeRange",
  "unitsPerEm",
  "vAlphabetic",
  "values",
  "vectorEffect",
  "version",
  "vertAdvY",
  "vertOriginX",
  "vertOriginY",
  "vHanging",
  "vIdeographic",
  "viewTarget",
  "visibility",
  "vMathematical",
  "widths",
  "wordSpacing",
  "writingMode",
  "x1",
  "x2",
  "x",
  "xChannelSelector",
  "xHeight",
  "xlinkActuate",
  "xlinkArcrole",
  "xlinkHref",
  "xlinkRole",
  "xlinkShow",
  "xlinkTitle",
  "xlinkType",
  "xmlBase",
  "xmlLang",
  "xmlns",
  "xmlnsXlink",
  "xmlSpace",
  "y1",
  "y2",
  "y",
  "yChannelSelector",
  "z",
  "zoomAndPan",
  "ref",
  "key",
  "angle"
], FM = new Set(BM);
function ZS(e) {
  return typeof e != "string" ? !1 : FM.has(e);
}
function QS(e) {
  return typeof e == "string" && e.startsWith("data-");
}
function re(e) {
  if (typeof e != "object" || e === null)
    return {};
  var t = {};
  for (var r in e)
    Object.prototype.hasOwnProperty.call(e, r) && (ZS(r) || QS(r)) && (t[r] = e[r]);
  return t;
}
function er(e) {
  if (e == null)
    return null;
  if (/* @__PURE__ */ d.isValidElement(e) && typeof e.props == "object" && e.props !== null) {
    var t = e.props;
    return re(t);
  }
  return typeof e == "object" && !Array.isArray(e) ? re(e) : null;
}
function Ie(e) {
  var t = {};
  for (var r in e)
    Object.prototype.hasOwnProperty.call(e, r) && (ZS(r) || QS(r) || Gm(r)) && (t[r] = e[r]);
  return t;
}
function KM(e) {
  return e == null ? null : /* @__PURE__ */ d.isValidElement(e) ? Ie(e.props) : typeof e == "object" && !Array.isArray(e) ? Ie(e) : null;
}
var WM = ["children", "width", "height", "viewBox", "className", "style", "title", "desc"];
function Vp() {
  return Vp = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Vp.apply(null, arguments);
}
function UM(e, t) {
  if (e == null) return {};
  var r, n, i = VM(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function VM(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
var ou = /* @__PURE__ */ d.forwardRef((e, t) => {
  var {
    children: r,
    width: n,
    height: i,
    viewBox: a,
    className: o,
    style: l,
    title: u,
    desc: s
  } = e, c = UM(e, WM), f = a || {
    width: n,
    height: i,
    x: 0,
    y: 0
  }, v = Y("recharts-surface", o);
  return /* @__PURE__ */ d.createElement("svg", Vp({}, Ie(c), {
    className: v,
    width: n,
    height: i,
    style: l,
    viewBox: "".concat(f.x, " ").concat(f.y, " ").concat(f.width, " ").concat(f.height),
    ref: t
  }), /* @__PURE__ */ d.createElement("title", null, u), /* @__PURE__ */ d.createElement("desc", null, s), r);
}), HM = ["children", "className"];
function Hp() {
  return Hp = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Hp.apply(null, arguments);
}
function XM(e, t) {
  if (e == null) return {};
  var r, n, i = YM(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function YM(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
var U = /* @__PURE__ */ d.forwardRef((e, t) => {
  var {
    children: r,
    className: n
  } = e, i = XM(e, HM), a = Y("recharts-layer", n);
  return /* @__PURE__ */ d.createElement("g", Hp({
    className: a
  }, Ie(i), {
    ref: t
  }), r);
}), JS = /* @__PURE__ */ d.createContext(null), GM = () => d.useContext(JS);
function we(e) {
  return function() {
    return e;
  };
}
const eE = Math.cos, Pc = Math.sin, Dr = Math.sqrt, Oc = Math.PI, Vf = 2 * Oc, Xp = Math.PI, Yp = 2 * Xp, Si = 1e-6, qM = Yp - Si;
function tE(e) {
  this._ += e[0];
  for (let t = 1, r = e.length; t < r; ++t)
    this._ += arguments[t] + e[t];
}
function ZM(e) {
  let t = Math.floor(e);
  if (!(t >= 0)) throw new Error(`invalid digits: ${e}`);
  if (t > 15) return tE;
  const r = 10 ** t;
  return function(n) {
    this._ += n[0];
    for (let i = 1, a = n.length; i < a; ++i)
      this._ += Math.round(arguments[i] * r) / r + n[i];
  };
}
class QM {
  constructor(t) {
    this._x0 = this._y0 = // start of current subpath
    this._x1 = this._y1 = null, this._ = "", this._append = t == null ? tE : ZM(t);
  }
  moveTo(t, r) {
    this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +r}`;
  }
  closePath() {
    this._x1 !== null && (this._x1 = this._x0, this._y1 = this._y0, this._append`Z`);
  }
  lineTo(t, r) {
    this._append`L${this._x1 = +t},${this._y1 = +r}`;
  }
  quadraticCurveTo(t, r, n, i) {
    this._append`Q${+t},${+r},${this._x1 = +n},${this._y1 = +i}`;
  }
  bezierCurveTo(t, r, n, i, a, o) {
    this._append`C${+t},${+r},${+n},${+i},${this._x1 = +a},${this._y1 = +o}`;
  }
  arcTo(t, r, n, i, a) {
    if (t = +t, r = +r, n = +n, i = +i, a = +a, a < 0) throw new Error(`negative radius: ${a}`);
    let o = this._x1, l = this._y1, u = n - t, s = i - r, c = o - t, f = l - r, v = c * c + f * f;
    if (this._x1 === null)
      this._append`M${this._x1 = t},${this._y1 = r}`;
    else if (v > Si) if (!(Math.abs(f * u - s * c) > Si) || !a)
      this._append`L${this._x1 = t},${this._y1 = r}`;
    else {
      let p = n - o, h = i - l, y = u * u + s * s, g = p * p + h * h, m = Math.sqrt(y), b = Math.sqrt(v), x = a * Math.tan((Xp - Math.acos((y + v - g) / (2 * m * b))) / 2), w = x / b, P = x / m;
      Math.abs(w - 1) > Si && this._append`L${t + w * c},${r + w * f}`, this._append`A${a},${a},0,0,${+(f * p > c * h)},${this._x1 = t + P * u},${this._y1 = r + P * s}`;
    }
  }
  arc(t, r, n, i, a, o) {
    if (t = +t, r = +r, n = +n, o = !!o, n < 0) throw new Error(`negative radius: ${n}`);
    let l = n * Math.cos(i), u = n * Math.sin(i), s = t + l, c = r + u, f = 1 ^ o, v = o ? i - a : a - i;
    this._x1 === null ? this._append`M${s},${c}` : (Math.abs(this._x1 - s) > Si || Math.abs(this._y1 - c) > Si) && this._append`L${s},${c}`, n && (v < 0 && (v = v % Yp + Yp), v > qM ? this._append`A${n},${n},0,1,${f},${t - l},${r - u}A${n},${n},0,1,${f},${this._x1 = s},${this._y1 = c}` : v > Si && this._append`A${n},${n},0,${+(v >= Xp)},${f},${this._x1 = t + n * Math.cos(a)},${this._y1 = r + n * Math.sin(a)}`);
  }
  rect(t, r, n, i) {
    this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +r}h${n = +n}v${+i}h${-n}Z`;
  }
  toString() {
    return this._;
  }
}
function qm(e) {
  let t = 3;
  return e.digits = function(r) {
    if (!arguments.length) return t;
    if (r == null)
      t = null;
    else {
      const n = Math.floor(r);
      if (!(n >= 0)) throw new RangeError(`invalid digits: ${r}`);
      t = n;
    }
    return e;
  }, () => new QM(t);
}
function Zm(e) {
  return typeof e == "object" && "length" in e ? e : Array.from(e);
}
function rE(e) {
  this._context = e;
}
rE.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
      default:
        this._context.lineTo(e, t);
        break;
    }
  }
};
function Hf(e) {
  return new rE(e);
}
function nE(e) {
  return e[0];
}
function iE(e) {
  return e[1];
}
function aE(e, t) {
  var r = we(!0), n = null, i = Hf, a = null, o = qm(l);
  e = typeof e == "function" ? e : e === void 0 ? nE : we(e), t = typeof t == "function" ? t : t === void 0 ? iE : we(t);
  function l(u) {
    var s, c = (u = Zm(u)).length, f, v = !1, p;
    for (n == null && (a = i(p = o())), s = 0; s <= c; ++s)
      !(s < c && r(f = u[s], s, u)) === v && ((v = !v) ? a.lineStart() : a.lineEnd()), v && a.point(+e(f, s, u), +t(f, s, u));
    if (p) return a = null, p + "" || null;
  }
  return l.x = function(u) {
    return arguments.length ? (e = typeof u == "function" ? u : we(+u), l) : e;
  }, l.y = function(u) {
    return arguments.length ? (t = typeof u == "function" ? u : we(+u), l) : t;
  }, l.defined = function(u) {
    return arguments.length ? (r = typeof u == "function" ? u : we(!!u), l) : r;
  }, l.curve = function(u) {
    return arguments.length ? (i = u, n != null && (a = i(n)), l) : i;
  }, l.context = function(u) {
    return arguments.length ? (u == null ? n = a = null : a = i(n = u), l) : n;
  }, l;
}
function ps(e, t, r) {
  var n = null, i = we(!0), a = null, o = Hf, l = null, u = qm(s);
  e = typeof e == "function" ? e : e === void 0 ? nE : we(+e), t = typeof t == "function" ? t : we(t === void 0 ? 0 : +t), r = typeof r == "function" ? r : r === void 0 ? iE : we(+r);
  function s(f) {
    var v, p, h, y = (f = Zm(f)).length, g, m = !1, b, x = new Array(y), w = new Array(y);
    for (a == null && (l = o(b = u())), v = 0; v <= y; ++v) {
      if (!(v < y && i(g = f[v], v, f)) === m)
        if (m = !m)
          p = v, l.areaStart(), l.lineStart();
        else {
          for (l.lineEnd(), l.lineStart(), h = v - 1; h >= p; --h)
            l.point(x[h], w[h]);
          l.lineEnd(), l.areaEnd();
        }
      m && (x[v] = +e(g, v, f), w[v] = +t(g, v, f), l.point(n ? +n(g, v, f) : x[v], r ? +r(g, v, f) : w[v]));
    }
    if (b) return l = null, b + "" || null;
  }
  function c() {
    return aE().defined(i).curve(o).context(a);
  }
  return s.x = function(f) {
    return arguments.length ? (e = typeof f == "function" ? f : we(+f), n = null, s) : e;
  }, s.x0 = function(f) {
    return arguments.length ? (e = typeof f == "function" ? f : we(+f), s) : e;
  }, s.x1 = function(f) {
    return arguments.length ? (n = f == null ? null : typeof f == "function" ? f : we(+f), s) : n;
  }, s.y = function(f) {
    return arguments.length ? (t = typeof f == "function" ? f : we(+f), r = null, s) : t;
  }, s.y0 = function(f) {
    return arguments.length ? (t = typeof f == "function" ? f : we(+f), s) : t;
  }, s.y1 = function(f) {
    return arguments.length ? (r = f == null ? null : typeof f == "function" ? f : we(+f), s) : r;
  }, s.lineX0 = s.lineY0 = function() {
    return c().x(e).y(t);
  }, s.lineY1 = function() {
    return c().x(e).y(r);
  }, s.lineX1 = function() {
    return c().x(n).y(t);
  }, s.defined = function(f) {
    return arguments.length ? (i = typeof f == "function" ? f : we(!!f), s) : i;
  }, s.curve = function(f) {
    return arguments.length ? (o = f, a != null && (l = o(a)), s) : o;
  }, s.context = function(f) {
    return arguments.length ? (f == null ? a = l = null : l = o(a = f), s) : a;
  }, s;
}
class oE {
  constructor(t, r) {
    this._context = t, this._x = r;
  }
  areaStart() {
    this._line = 0;
  }
  areaEnd() {
    this._line = NaN;
  }
  lineStart() {
    this._point = 0;
  }
  lineEnd() {
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  }
  point(t, r) {
    switch (t = +t, r = +r, this._point) {
      case 0: {
        this._point = 1, this._line ? this._context.lineTo(t, r) : this._context.moveTo(t, r);
        break;
      }
      case 1:
        this._point = 2;
      default: {
        this._x ? this._context.bezierCurveTo(this._x0 = (this._x0 + t) / 2, this._y0, this._x0, r, t, r) : this._context.bezierCurveTo(this._x0, this._y0 = (this._y0 + r) / 2, t, this._y0, t, r);
        break;
      }
    }
    this._x0 = t, this._y0 = r;
  }
}
function JM(e) {
  return new oE(e, !0);
}
function eD(e) {
  return new oE(e, !1);
}
const Qm = {
  draw(e, t) {
    const r = Dr(t / Oc);
    e.moveTo(r, 0), e.arc(0, 0, r, 0, Vf);
  }
}, tD = {
  draw(e, t) {
    const r = Dr(t / 5) / 2;
    e.moveTo(-3 * r, -r), e.lineTo(-r, -r), e.lineTo(-r, -3 * r), e.lineTo(r, -3 * r), e.lineTo(r, -r), e.lineTo(3 * r, -r), e.lineTo(3 * r, r), e.lineTo(r, r), e.lineTo(r, 3 * r), e.lineTo(-r, 3 * r), e.lineTo(-r, r), e.lineTo(-3 * r, r), e.closePath();
  }
}, lE = Dr(1 / 3), rD = lE * 2, nD = {
  draw(e, t) {
    const r = Dr(t / rD), n = r * lE;
    e.moveTo(0, -r), e.lineTo(n, 0), e.lineTo(0, r), e.lineTo(-n, 0), e.closePath();
  }
}, iD = {
  draw(e, t) {
    const r = Dr(t), n = -r / 2;
    e.rect(n, n, r, r);
  }
}, aD = 0.8908130915292852, uE = Pc(Oc / 10) / Pc(7 * Oc / 10), oD = Pc(Vf / 10) * uE, lD = -eE(Vf / 10) * uE, uD = {
  draw(e, t) {
    const r = Dr(t * aD), n = oD * r, i = lD * r;
    e.moveTo(0, -r), e.lineTo(n, i);
    for (let a = 1; a < 5; ++a) {
      const o = Vf * a / 5, l = eE(o), u = Pc(o);
      e.lineTo(u * r, -l * r), e.lineTo(l * n - u * i, u * n + l * i);
    }
    e.closePath();
  }
}, Ev = Dr(3), sD = {
  draw(e, t) {
    const r = -Dr(t / (Ev * 3));
    e.moveTo(0, r * 2), e.lineTo(-Ev * r, -r), e.lineTo(Ev * r, -r), e.closePath();
  }
}, ar = -0.5, or = Dr(3) / 2, Gp = 1 / Dr(12), cD = (Gp / 2 + 1) * 3, fD = {
  draw(e, t) {
    const r = Dr(t / cD), n = r / 2, i = r * Gp, a = n, o = r * Gp + r, l = -a, u = o;
    e.moveTo(n, i), e.lineTo(a, o), e.lineTo(l, u), e.lineTo(ar * n - or * i, or * n + ar * i), e.lineTo(ar * a - or * o, or * a + ar * o), e.lineTo(ar * l - or * u, or * l + ar * u), e.lineTo(ar * n + or * i, ar * i - or * n), e.lineTo(ar * a + or * o, ar * o - or * a), e.lineTo(ar * l + or * u, ar * u - or * l), e.closePath();
  }
};
function dD(e, t) {
  let r = null, n = qm(i);
  e = typeof e == "function" ? e : we(e || Qm), t = typeof t == "function" ? t : we(t === void 0 ? 64 : +t);
  function i() {
    let a;
    if (r || (r = a = n()), e.apply(this, arguments).draw(r, +t.apply(this, arguments)), a) return r = null, a + "" || null;
  }
  return i.type = function(a) {
    return arguments.length ? (e = typeof a == "function" ? a : we(a), i) : e;
  }, i.size = function(a) {
    return arguments.length ? (t = typeof a == "function" ? a : we(+a), i) : t;
  }, i.context = function(a) {
    return arguments.length ? (r = a ?? null, i) : r;
  }, i;
}
function Sc() {
}
function Ec(e, t, r) {
  e._context.bezierCurveTo(
    (2 * e._x0 + e._x1) / 3,
    (2 * e._y0 + e._y1) / 3,
    (e._x0 + 2 * e._x1) / 3,
    (e._y0 + 2 * e._y1) / 3,
    (e._x0 + 4 * e._x1 + t) / 6,
    (e._y0 + 4 * e._y1 + r) / 6
  );
}
function sE(e) {
  this._context = e;
}
sE.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 3:
        Ec(this, this._x1, this._y1);
      case 2:
        this._context.lineTo(this._x1, this._y1);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._context.lineTo((5 * this._x0 + this._x1) / 6, (5 * this._y0 + this._y1) / 6);
      default:
        Ec(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function vD(e) {
  return new sE(e);
}
function cE(e) {
  this._context = e;
}
cE.prototype = {
  areaStart: Sc,
  areaEnd: Sc,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x2, this._y2), this._context.closePath();
        break;
      }
      case 2: {
        this._context.moveTo((this._x2 + 2 * this._x3) / 3, (this._y2 + 2 * this._y3) / 3), this._context.lineTo((this._x3 + 2 * this._x2) / 3, (this._y3 + 2 * this._y2) / 3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x2, this._y2), this.point(this._x3, this._y3), this.point(this._x4, this._y4);
        break;
      }
    }
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._x2 = e, this._y2 = t;
        break;
      case 1:
        this._point = 2, this._x3 = e, this._y3 = t;
        break;
      case 2:
        this._point = 3, this._x4 = e, this._y4 = t, this._context.moveTo((this._x0 + 4 * this._x1 + e) / 6, (this._y0 + 4 * this._y1 + t) / 6);
        break;
      default:
        Ec(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function pD(e) {
  return new cE(e);
}
function fE(e) {
  this._context = e;
}
fE.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3;
        var r = (this._x0 + 4 * this._x1 + e) / 6, n = (this._y0 + 4 * this._y1 + t) / 6;
        this._line ? this._context.lineTo(r, n) : this._context.moveTo(r, n);
        break;
      case 3:
        this._point = 4;
      default:
        Ec(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function hD(e) {
  return new fE(e);
}
function dE(e) {
  this._context = e;
}
dE.prototype = {
  areaStart: Sc,
  areaEnd: Sc,
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    this._point && this._context.closePath();
  },
  point: function(e, t) {
    e = +e, t = +t, this._point ? this._context.lineTo(e, t) : (this._point = 1, this._context.moveTo(e, t));
  }
};
function mD(e) {
  return new dE(e);
}
function xb(e) {
  return e < 0 ? -1 : 1;
}
function wb(e, t, r) {
  var n = e._x1 - e._x0, i = t - e._x1, a = (e._y1 - e._y0) / (n || i < 0 && -0), o = (r - e._y1) / (i || n < 0 && -0), l = (a * i + o * n) / (n + i);
  return (xb(a) + xb(o)) * Math.min(Math.abs(a), Math.abs(o), 0.5 * Math.abs(l)) || 0;
}
function Pb(e, t) {
  var r = e._x1 - e._x0;
  return r ? (3 * (e._y1 - e._y0) / r - t) / 2 : t;
}
function Av(e, t, r) {
  var n = e._x0, i = e._y0, a = e._x1, o = e._y1, l = (a - n) / 3;
  e._context.bezierCurveTo(n + l, i + l * t, a - l, o - l * r, a, o);
}
function Ac(e) {
  this._context = e;
}
Ac.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = this._t0 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x1, this._y1);
        break;
      case 3:
        Av(this, this._t0, Pb(this, this._t0));
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    var r = NaN;
    if (e = +e, t = +t, !(e === this._x1 && t === this._y1)) {
      switch (this._point) {
        case 0:
          this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
          break;
        case 1:
          this._point = 2;
          break;
        case 2:
          this._point = 3, Av(this, Pb(this, r = wb(this, e, t)), r);
          break;
        default:
          Av(this, this._t0, r = wb(this, e, t));
          break;
      }
      this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t, this._t0 = r;
    }
  }
};
function vE(e) {
  this._context = new pE(e);
}
(vE.prototype = Object.create(Ac.prototype)).point = function(e, t) {
  Ac.prototype.point.call(this, t, e);
};
function pE(e) {
  this._context = e;
}
pE.prototype = {
  moveTo: function(e, t) {
    this._context.moveTo(t, e);
  },
  closePath: function() {
    this._context.closePath();
  },
  lineTo: function(e, t) {
    this._context.lineTo(t, e);
  },
  bezierCurveTo: function(e, t, r, n, i, a) {
    this._context.bezierCurveTo(t, e, n, r, a, i);
  }
};
function yD(e) {
  return new Ac(e);
}
function gD(e) {
  return new vE(e);
}
function hE(e) {
  this._context = e;
}
hE.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x = [], this._y = [];
  },
  lineEnd: function() {
    var e = this._x, t = this._y, r = e.length;
    if (r)
      if (this._line ? this._context.lineTo(e[0], t[0]) : this._context.moveTo(e[0], t[0]), r === 2)
        this._context.lineTo(e[1], t[1]);
      else
        for (var n = Ob(e), i = Ob(t), a = 0, o = 1; o < r; ++a, ++o)
          this._context.bezierCurveTo(n[0][a], i[0][a], n[1][a], i[1][a], e[o], t[o]);
    (this._line || this._line !== 0 && r === 1) && this._context.closePath(), this._line = 1 - this._line, this._x = this._y = null;
  },
  point: function(e, t) {
    this._x.push(+e), this._y.push(+t);
  }
};
function Ob(e) {
  var t, r = e.length - 1, n, i = new Array(r), a = new Array(r), o = new Array(r);
  for (i[0] = 0, a[0] = 2, o[0] = e[0] + 2 * e[1], t = 1; t < r - 1; ++t) i[t] = 1, a[t] = 4, o[t] = 4 * e[t] + 2 * e[t + 1];
  for (i[r - 1] = 2, a[r - 1] = 7, o[r - 1] = 8 * e[r - 1] + e[r], t = 1; t < r; ++t) n = i[t] / a[t - 1], a[t] -= n, o[t] -= n * o[t - 1];
  for (i[r - 1] = o[r - 1] / a[r - 1], t = r - 2; t >= 0; --t) i[t] = (o[t] - i[t + 1]) / a[t];
  for (a[r - 1] = (e[r] + i[r - 1]) / 2, t = 0; t < r - 1; ++t) a[t] = 2 * e[t + 1] - i[t + 1];
  return [i, a];
}
function bD(e) {
  return new hE(e);
}
function Xf(e, t) {
  this._context = e, this._t = t;
}
Xf.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x = this._y = NaN, this._point = 0;
  },
  lineEnd: function() {
    0 < this._t && this._t < 1 && this._point === 2 && this._context.lineTo(this._x, this._y), (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line >= 0 && (this._t = 1 - this._t, this._line = 1 - this._line);
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
      default: {
        if (this._t <= 0)
          this._context.lineTo(this._x, t), this._context.lineTo(e, t);
        else {
          var r = this._x * (1 - this._t) + e * this._t;
          this._context.lineTo(r, this._y), this._context.lineTo(r, t);
        }
        break;
      }
    }
    this._x = e, this._y = t;
  }
};
function xD(e) {
  return new Xf(e, 0.5);
}
function wD(e) {
  return new Xf(e, 0);
}
function PD(e) {
  return new Xf(e, 1);
}
function Xi(e, t) {
  if ((o = e.length) > 1)
    for (var r = 1, n, i, a = e[t[0]], o, l = a.length; r < o; ++r)
      for (i = a, a = e[t[r]], n = 0; n < l; ++n)
        a[n][1] += a[n][0] = isNaN(i[n][1]) ? i[n][0] : i[n][1];
}
function qp(e) {
  for (var t = e.length, r = new Array(t); --t >= 0; ) r[t] = t;
  return r;
}
function OD(e, t) {
  return e[t];
}
function SD(e) {
  const t = [];
  return t.key = e, t;
}
function ED() {
  var e = we([]), t = qp, r = Xi, n = OD;
  function i(a) {
    var o = Array.from(e.apply(this, arguments), SD), l, u = o.length, s = -1, c;
    for (const f of a)
      for (l = 0, ++s; l < u; ++l)
        (o[l][s] = [0, +n(f, o[l].key, s, a)]).data = f;
    for (l = 0, c = Zm(t(o)); l < u; ++l)
      o[c[l]].index = l;
    return r(o, c), o;
  }
  return i.keys = function(a) {
    return arguments.length ? (e = typeof a == "function" ? a : we(Array.from(a)), i) : e;
  }, i.value = function(a) {
    return arguments.length ? (n = typeof a == "function" ? a : we(+a), i) : n;
  }, i.order = function(a) {
    return arguments.length ? (t = a == null ? qp : typeof a == "function" ? a : we(Array.from(a)), i) : t;
  }, i.offset = function(a) {
    return arguments.length ? (r = a ?? Xi, i) : r;
  }, i;
}
function AD(e, t) {
  if ((n = e.length) > 0) {
    for (var r, n, i = 0, a = e[0].length, o; i < a; ++i) {
      for (o = r = 0; r < n; ++r) o += e[r][i][1] || 0;
      if (o) for (r = 0; r < n; ++r) e[r][i][1] /= o;
    }
    Xi(e, t);
  }
}
function kD(e, t) {
  if ((i = e.length) > 0) {
    for (var r = 0, n = e[t[0]], i, a = n.length; r < a; ++r) {
      for (var o = 0, l = 0; o < i; ++o) l += e[o][r][1] || 0;
      n[r][1] += n[r][0] = -l / 2;
    }
    Xi(e, t);
  }
}
function _D(e, t) {
  if (!(!((o = e.length) > 0) || !((a = (i = e[t[0]]).length) > 0))) {
    for (var r = 0, n = 1, i, a, o; n < a; ++n) {
      for (var l = 0, u = 0, s = 0; l < o; ++l) {
        for (var c = e[t[l]], f = c[n][1] || 0, v = c[n - 1][1] || 0, p = (f - v) / 2, h = 0; h < l; ++h) {
          var y = e[t[h]], g = y[n][1] || 0, m = y[n - 1][1] || 0;
          p += g - m;
        }
        u += f, s += p * f;
      }
      i[n - 1][1] += i[n - 1][0] = r, u && (r -= s / u);
    }
    i[n - 1][1] += i[n - 1][0] = r, Xi(e, t);
  }
}
var lu = {}, Jm = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r) {
    return r === "__proto__";
  }
  e.isUnsafeProperty = t;
})(Jm);
var uu = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r) {
    switch (typeof r) {
      case "number":
      case "symbol":
        return !1;
      case "string":
        return r.includes(".") || r.includes("[") || r.includes("]");
    }
  }
  e.isDeepKey = t;
})(uu);
var su = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r) {
    var n;
    return typeof r == "string" || typeof r == "symbol" ? r : Object.is((n = r == null ? void 0 : r.valueOf) == null ? void 0 : n.call(r), -0) ? "-0" : String(r);
  }
  e.toKey = t;
})(su);
var cu = {}, mE = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r) {
    if (r == null)
      return "";
    if (typeof r == "string")
      return r;
    if (Array.isArray(r))
      return r.map(t).join(",");
    const n = String(r);
    return n === "0" && Object.is(Number(r), -0) ? "-0" : n;
  }
  e.toString = t;
})(mE);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = mE, r = su;
  function n(i) {
    if (Array.isArray(i))
      return i.map(r.toKey);
    if (typeof i == "symbol")
      return [i];
    i = t.toString(i);
    const a = [], o = i.length;
    if (o === 0)
      return a;
    let l = 0, u = "", s = "", c = !1;
    for (i.charCodeAt(0) === 46 && (a.push(""), l++); l < o; ) {
      const f = i[l];
      s ? f === "\\" && l + 1 < o ? (l++, u += i[l]) : f === s ? s = "" : u += f : c ? f === '"' || f === "'" ? s = f : f === "]" ? (c = !1, a.push(u), u = "") : u += f : f === "[" ? (c = !0, u && (a.push(u), u = "")) : f === "." ? u && (a.push(u), u = "") : u += f, l++;
    }
    return u && a.push(u), a;
  }
  e.toPath = n;
})(cu);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = Jm, r = uu, n = su, i = cu;
  function a(l, u, s) {
    if (l == null)
      return s;
    switch (typeof u) {
      case "string": {
        if (t.isUnsafeProperty(u))
          return s;
        const c = l[u];
        return c === void 0 ? r.isDeepKey(u) ? a(l, i.toPath(u), s) : s : c;
      }
      case "number":
      case "symbol": {
        typeof u == "number" && (u = n.toKey(u));
        const c = l[u];
        return c === void 0 ? s : c;
      }
      default: {
        if (Array.isArray(u))
          return o(l, u, s);
        if (Object.is(u == null ? void 0 : u.valueOf(), -0) ? u = "-0" : u = String(u), t.isUnsafeProperty(u))
          return s;
        const c = l[u];
        return c === void 0 ? s : c;
      }
    }
  }
  function o(l, u, s) {
    if (u.length === 0)
      return s;
    let c = l;
    for (let f = 0; f < u.length; f++) {
      if (c == null || t.isUnsafeProperty(u[f]))
        return s;
      c = c[u[f]];
    }
    return c === void 0 ? s : c;
  }
  e.get = a;
})(lu);
var ID = lu.get;
const Gr = /* @__PURE__ */ Wt(ID);
var jD = 4;
function Zn(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : jD, r = 10 ** t, n = Math.round(e * r) / r;
  return Object.is(n, -0) ? 0 : n;
}
function Ce(e) {
  for (var t = arguments.length, r = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
    r[n - 1] = arguments[n];
  return e.reduce((i, a, o) => {
    var l = r[o - 1];
    return typeof l == "string" ? i + l + a : l !== void 0 ? i + Zn(l) + a : i + a;
  }, "");
}
var We = (e) => e === 0 ? 0 : e > 0 ? 1 : -1, Pt = (e) => typeof e == "number" && e != +e, kn = (e) => typeof e == "string" && e.indexOf("%") === e.length - 1, B = (e) => (typeof e == "number" || e instanceof Number) && !Pt(e), it = (e) => B(e) || typeof e == "string", CD = 0, Ya = (e) => {
  var t = ++CD;
  return "".concat(e || "").concat(t);
}, dt = function(t, r) {
  var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 0, i = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !1;
  if (!B(t) && typeof t != "string")
    return n;
  var a;
  if (kn(t)) {
    if (r == null)
      return n;
    var o = t.indexOf("%");
    a = r * parseFloat(t.slice(0, o)) / 100;
  } else
    a = +t;
  return Pt(a) && (a = n), i && r != null && a > r && (a = r), a;
}, yE = (e) => {
  if (!Array.isArray(e))
    return !1;
  for (var t = e.length, r = {}, n = 0; n < t; n++)
    if (!r[String(e[n])])
      r[String(e[n])] = !0;
    else
      return !0;
  return !1;
};
function X(e, t, r) {
  return B(e) && B(t) ? Zn(e + r * (t - e)) : t;
}
function gE(e, t, r) {
  if (!(!e || !e.length))
    return e.find((n) => n && (typeof t == "function" ? t(n) : Gr(n, t)) === r);
}
var TD = (e) => {
  for (var t = e.length, r = 0, n = 0, i = 0, a = 0, o = 1 / 0, l = -1 / 0, u = 0, s = 0, c = 0; c < t; c++) {
    var f, v;
    u = ((f = e[c]) === null || f === void 0 ? void 0 : f.cx) || 0, s = ((v = e[c]) === null || v === void 0 ? void 0 : v.cy) || 0, r += u, n += s, i += u * s, a += u * u, o = Math.min(o, u), l = Math.max(l, u);
  }
  var p = t * a !== r * r ? (t * i - r * n) / (t * a - r * r) : 0;
  return {
    xmin: o,
    xmax: l,
    a: p,
    b: (n - p * r) / t
  };
}, oe = (e) => e === null || typeof e > "u", fu = (e) => oe(e) ? e : "".concat(e.charAt(0).toUpperCase()).concat(e.slice(1));
function ey(e) {
  return e != null;
}
function co() {
}
var MD = ["type", "size", "sizeType"];
function Zp() {
  return Zp = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Zp.apply(null, arguments);
}
function Sb(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Eb(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Sb(Object(r), !0).forEach(function(n) {
      DD(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Sb(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function DD(e, t, r) {
  return (t = ND(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function ND(e) {
  var t = $D(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function $D(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function LD(e, t) {
  if (e == null) return {};
  var r, n, i = RD(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function RD(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
var bE = {
  symbolCircle: Qm,
  symbolCross: tD,
  symbolDiamond: nD,
  symbolSquare: iD,
  symbolStar: uD,
  symbolTriangle: sD,
  symbolWye: fD
}, zD = Math.PI / 180, BD = (e) => {
  var t = "symbol".concat(fu(e));
  return bE[t] || Qm;
}, FD = (e, t, r) => {
  if (t === "area")
    return e;
  switch (r) {
    case "cross":
      return 5 * e * e / 9;
    case "diamond":
      return 0.5 * e * e / Math.sqrt(3);
    case "square":
      return e * e;
    case "star": {
      var n = 18 * zD;
      return 1.25 * e * e * (Math.tan(n) - Math.tan(n * 2) * Math.tan(n) ** 2);
    }
    case "triangle":
      return Math.sqrt(3) * e * e / 4;
    case "wye":
      return (21 - 10 * Math.sqrt(3)) * e * e / 8;
    default:
      return Math.PI * e * e / 4;
  }
}, KD = (e, t) => {
  bE["symbol".concat(fu(e))] = t;
}, Yf = (e) => {
  var {
    type: t = "circle",
    size: r = 64,
    sizeType: n = "area"
  } = e, i = LD(e, MD), a = Eb(Eb({}, i), {}, {
    type: t,
    size: r,
    sizeType: n
  }), o = "circle";
  typeof t == "string" && (o = t);
  var l = () => {
    var v = BD(o), p = dD().type(v).size(FD(r, n, o)), h = p();
    if (h !== null)
      return h;
  }, {
    className: u,
    cx: s,
    cy: c
  } = a, f = Ie(a);
  return B(s) && B(c) && B(r) ? /* @__PURE__ */ d.createElement("path", Zp({}, f, {
    className: Y("recharts-symbols", u),
    transform: "translate(".concat(s, ", ").concat(c, ")"),
    d: l()
  })) : null;
};
Yf.registerSymbol = KD;
var xE = (e) => "radius" in e && "startAngle" in e && "endAngle" in e, ty = (e, t) => {
  if (!e || typeof e == "function" || typeof e == "boolean")
    return null;
  var r = e;
  if (/* @__PURE__ */ d.isValidElement(e) && (r = e.props), typeof r != "object" && typeof r != "function")
    return null;
  var n = {};
  return Object.keys(r).forEach((i) => {
    Gm(i) && (n[i] = (a) => r[i](r, a));
  }), n;
}, WD = (e, t, r) => (n) => (e(t, r, n), null), Nr = (e, t, r) => {
  if (e === null || typeof e != "object" && typeof e != "function")
    return null;
  var n = null;
  return Object.keys(e).forEach((i) => {
    var a = e[i];
    Gm(i) && typeof a == "function" && (n || (n = {}), n[i] = WD(a, t, r));
  }), n;
}, UD = (e) => Array.isArray(e) && e.length > 0;
function Ab(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function VD(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Ab(Object(r), !0).forEach(function(n) {
      HD(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Ab(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function HD(e, t, r) {
  return (t = XD(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function XD(e) {
  var t = YD(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function YD(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function ee(e, t) {
  var r = VD({}, e), n = t, i = Object.keys(t), a = i.reduce((o, l) => (o[l] === void 0 && n[l] !== void 0 && (o[l] = n[l]), o), r);
  return a;
}
function kc() {
  return kc = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, kc.apply(null, arguments);
}
function kb(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function GD(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? kb(Object(r), !0).forEach(function(n) {
      qD(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : kb(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function qD(e, t, r) {
  return (t = ZD(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function ZD(e) {
  var t = QD(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function QD(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var ur = 32, JD = {
  align: "center",
  iconSize: 14,
  inactiveColor: "#ccc",
  layout: "horizontal",
  verticalAlign: "middle"
};
function e2(e) {
  var {
    data: t,
    iconType: r,
    inactiveColor: n
  } = e, i = ur / 2, a = ur / 6, o = ur / 3, l = t.inactive ? n : t.color, u = r ?? t.type;
  if (u === "none")
    return null;
  if (u === "plainline") {
    var s;
    return /* @__PURE__ */ d.createElement("line", {
      strokeWidth: 4,
      fill: "none",
      stroke: l,
      strokeDasharray: (s = t.payload) === null || s === void 0 ? void 0 : s.strokeDasharray,
      x1: 0,
      y1: i,
      x2: ur,
      y2: i,
      className: "recharts-legend-icon"
    });
  }
  if (u === "line")
    return /* @__PURE__ */ d.createElement("path", {
      strokeWidth: 4,
      fill: "none",
      stroke: l,
      d: "M0,".concat(i, "h").concat(o, `
            A`).concat(a, ",").concat(a, ",0,1,1,").concat(2 * o, ",").concat(i, `
            H`).concat(ur, "M").concat(2 * o, ",").concat(i, `
            A`).concat(a, ",").concat(a, ",0,1,1,").concat(o, ",").concat(i),
      className: "recharts-legend-icon"
    });
  if (u === "rect")
    return /* @__PURE__ */ d.createElement("path", {
      stroke: "none",
      fill: l,
      d: "M0,".concat(ur / 8, "h").concat(ur, "v").concat(ur * 3 / 4, "h").concat(-ur, "z"),
      className: "recharts-legend-icon"
    });
  if (/* @__PURE__ */ d.isValidElement(t.legendIcon)) {
    var c = GD({}, t);
    return delete c.legendIcon, /* @__PURE__ */ d.cloneElement(t.legendIcon, c);
  }
  return /* @__PURE__ */ d.createElement(Yf, {
    fill: l,
    cx: i,
    cy: i,
    size: ur,
    sizeType: "diameter",
    type: u
  });
}
function t2(e) {
  var {
    payload: t,
    iconSize: r,
    layout: n,
    formatter: i,
    inactiveColor: a,
    iconType: o
  } = e, l = {
    x: 0,
    y: 0,
    width: ur,
    height: ur
  }, u = {
    display: n === "horizontal" ? "inline-block" : "block",
    marginRight: 10
  }, s = {
    display: "inline-block",
    verticalAlign: "middle",
    marginRight: 4
  };
  return t.map((c, f) => {
    var v = c.formatter || i, p = Y({
      "recharts-legend-item": !0,
      ["legend-item-".concat(f)]: !0,
      inactive: c.inactive
    });
    if (c.type === "none")
      return null;
    var h = c.inactive ? a : c.color, y = v ? v(c.value, c, f) : c.value;
    return /* @__PURE__ */ d.createElement("li", kc({
      className: p,
      style: u,
      key: "legend-item-".concat(f)
    }, Nr(e, c, f)), /* @__PURE__ */ d.createElement(ou, {
      width: r,
      height: r,
      viewBox: l,
      style: s,
      "aria-label": "".concat(y, " legend icon")
    }, /* @__PURE__ */ d.createElement(e2, {
      data: c,
      iconType: o,
      inactiveColor: a
    })), /* @__PURE__ */ d.createElement("span", {
      className: "recharts-legend-item-text",
      style: {
        color: h
      }
    }, y));
  });
}
var r2 = (e) => {
  var t = ee(e, JD), {
    payload: r,
    layout: n,
    align: i
  } = t;
  if (!r || !r.length)
    return null;
  var a = {
    padding: 0,
    margin: 0,
    textAlign: n === "horizontal" ? i : "left"
  };
  return /* @__PURE__ */ d.createElement("ul", {
    className: "recharts-default-legend",
    style: a
  }, /* @__PURE__ */ d.createElement(t2, kc({}, t, {
    payload: r
  })));
}, wE = {}, PE = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r, n) {
    const i = /* @__PURE__ */ new Map();
    for (let a = 0; a < r.length; a++) {
      const o = r[a], l = n(o);
      i.has(l) || i.set(l, o);
    }
    return Array.from(i.values());
  }
  e.uniqBy = t;
})(PE);
var du = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r) {
    return r;
  }
  e.identity = t;
})(du);
var OE = {}, fo = {}, SE = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r) {
    return Number.isSafeInteger(r) && r >= 0;
  }
  e.isLength = t;
})(SE);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = SE;
  function r(n) {
    return n != null && typeof n != "function" && t.isLength(n.length);
  }
  e.isArrayLike = r;
})(fo);
var EE = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r) {
    return typeof r == "object" && r !== null;
  }
  e.isObjectLike = t;
})(EE);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = fo, r = EE;
  function n(i) {
    return r.isObjectLike(i) && t.isArrayLike(i);
  }
  e.isArrayLikeObject = n;
})(OE);
var vu = {}, AE = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = lu;
  function r(n) {
    return function(i) {
      return t.get(i, n);
    };
  }
  e.property = r;
})(AE);
var kE = {}, ry = {}, _E = {}, ny = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r) {
    return r !== null && (typeof r == "object" || typeof r == "function");
  }
  e.isObject = t;
})(ny);
var iy = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r) {
    return r == null || typeof r != "object" && typeof r != "function";
  }
  e.isPrimitive = t;
})(iy);
var ay = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r, n) {
    return r === n || Number.isNaN(r) && Number.isNaN(n);
  }
  e.eq = t;
})(ay);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = ny, r = iy, n = ay;
  function i(c, f, v) {
    return typeof v != "function" ? i(c, f, () => {
    }) : a(c, f, function p(h, y, g, m, b, x) {
      const w = v(h, y, g, m, b, x);
      return w !== void 0 ? !!w : a(h, y, p, x);
    }, /* @__PURE__ */ new Map());
  }
  function a(c, f, v, p) {
    if (f === c)
      return !0;
    switch (typeof f) {
      case "object":
        return o(c, f, v, p);
      case "function":
        return Object.keys(f).length > 0 ? a(c, { ...f }, v, p) : n.eq(c, f);
      default:
        return t.isObject(c) ? typeof f == "string" ? f === "" : !0 : n.eq(c, f);
    }
  }
  function o(c, f, v, p) {
    if (f == null)
      return !0;
    if (Array.isArray(f))
      return u(c, f, v, p);
    if (f instanceof Map)
      return l(c, f, v, p);
    if (f instanceof Set)
      return s(c, f, v, p);
    const h = Object.keys(f);
    if (c == null || r.isPrimitive(c))
      return h.length === 0;
    if (h.length === 0)
      return !0;
    if (p != null && p.has(f))
      return p.get(f) === c;
    p == null || p.set(f, c);
    try {
      for (let y = 0; y < h.length; y++) {
        const g = h[y];
        if (!r.isPrimitive(c) && !(g in c) || f[g] === void 0 && c[g] !== void 0 || f[g] === null && c[g] !== null || !v(c[g], f[g], g, c, f, p))
          return !1;
      }
      return !0;
    } finally {
      p == null || p.delete(f);
    }
  }
  function l(c, f, v, p) {
    if (f.size === 0)
      return !0;
    if (!(c instanceof Map))
      return !1;
    for (const [h, y] of f.entries()) {
      const g = c.get(h);
      if (v(g, y, h, c, f, p) === !1)
        return !1;
    }
    return !0;
  }
  function u(c, f, v, p) {
    if (f.length === 0)
      return !0;
    if (!Array.isArray(c))
      return !1;
    const h = /* @__PURE__ */ new Set();
    for (let y = 0; y < f.length; y++) {
      const g = f[y];
      let m = !1;
      for (let b = 0; b < c.length; b++) {
        if (h.has(b))
          continue;
        const x = c[b];
        let w = !1;
        if (v(x, g, y, c, f, p) && (w = !0), w) {
          h.add(b), m = !0;
          break;
        }
      }
      if (!m)
        return !1;
    }
    return !0;
  }
  function s(c, f, v, p) {
    return f.size === 0 ? !0 : c instanceof Set ? u([...c], [...f], v, p) : !1;
  }
  e.isMatchWith = i, e.isSetMatch = s;
})(_E);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = _E;
  function r(n, i) {
    return t.isMatchWith(n, i, () => {
    });
  }
  e.isMatch = r;
})(ry);
var IE = {}, oy = {}, ly = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r) {
    return Object.getOwnPropertySymbols(r).filter((n) => Object.prototype.propertyIsEnumerable.call(r, n));
  }
  e.getSymbols = t;
})(ly);
var uy = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r) {
    return r == null ? r === void 0 ? "[object Undefined]" : "[object Null]" : Object.prototype.toString.call(r);
  }
  e.getTag = t;
})(uy);
var sy = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = "[object RegExp]", r = "[object String]", n = "[object Number]", i = "[object Boolean]", a = "[object Arguments]", o = "[object Symbol]", l = "[object Date]", u = "[object Map]", s = "[object Set]", c = "[object Array]", f = "[object Function]", v = "[object ArrayBuffer]", p = "[object Object]", h = "[object Error]", y = "[object DataView]", g = "[object Uint8Array]", m = "[object Uint8ClampedArray]", b = "[object Uint16Array]", x = "[object Uint32Array]", w = "[object BigUint64Array]", P = "[object Int8Array]", O = "[object Int16Array]", S = "[object Int32Array]", E = "[object BigInt64Array]", k = "[object Float32Array]", _ = "[object Float64Array]";
  e.argumentsTag = a, e.arrayBufferTag = v, e.arrayTag = c, e.bigInt64ArrayTag = E, e.bigUint64ArrayTag = w, e.booleanTag = i, e.dataViewTag = y, e.dateTag = l, e.errorTag = h, e.float32ArrayTag = k, e.float64ArrayTag = _, e.functionTag = f, e.int16ArrayTag = O, e.int32ArrayTag = S, e.int8ArrayTag = P, e.mapTag = u, e.numberTag = n, e.objectTag = p, e.regexpTag = t, e.setTag = s, e.stringTag = r, e.symbolTag = o, e.uint16ArrayTag = b, e.uint32ArrayTag = x, e.uint8ArrayTag = g, e.uint8ClampedArrayTag = m;
})(sy);
var cy = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r) {
    return ArrayBuffer.isView(r) && !(r instanceof DataView);
  }
  e.isTypedArray = t;
})(cy);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = ly, r = uy, n = sy, i = iy, a = cy;
  function o(c, f) {
    return l(c, void 0, c, /* @__PURE__ */ new Map(), f);
  }
  function l(c, f, v, p = /* @__PURE__ */ new Map(), h = void 0) {
    const y = h == null ? void 0 : h(c, f, v, p);
    if (y !== void 0)
      return y;
    if (i.isPrimitive(c))
      return c;
    if (p.has(c))
      return p.get(c);
    if (Array.isArray(c)) {
      const g = new Array(c.length);
      p.set(c, g);
      for (let m = 0; m < c.length; m++)
        g[m] = l(c[m], m, v, p, h);
      return Object.hasOwn(c, "index") && (g.index = c.index), Object.hasOwn(c, "input") && (g.input = c.input), g;
    }
    if (c instanceof Date)
      return new Date(c.getTime());
    if (c instanceof RegExp) {
      const g = new RegExp(c.source, c.flags);
      return g.lastIndex = c.lastIndex, g;
    }
    if (c instanceof Map) {
      const g = /* @__PURE__ */ new Map();
      p.set(c, g);
      for (const [m, b] of c)
        g.set(m, l(b, m, v, p, h));
      return g;
    }
    if (c instanceof Set) {
      const g = /* @__PURE__ */ new Set();
      p.set(c, g);
      for (const m of c)
        g.add(l(m, void 0, v, p, h));
      return g;
    }
    if (typeof Buffer < "u" && Buffer.isBuffer(c))
      return c.subarray();
    if (a.isTypedArray(c)) {
      const g = new (Object.getPrototypeOf(c)).constructor(c.length);
      p.set(c, g);
      for (let m = 0; m < c.length; m++)
        g[m] = l(c[m], m, v, p, h);
      return g;
    }
    if (c instanceof ArrayBuffer || typeof SharedArrayBuffer < "u" && c instanceof SharedArrayBuffer)
      return c.slice(0);
    if (c instanceof DataView) {
      const g = new DataView(c.buffer.slice(0), c.byteOffset, c.byteLength);
      return p.set(c, g), u(g, c, v, p, h), g;
    }
    if (typeof File < "u" && c instanceof File) {
      const g = new File([c], c.name, {
        type: c.type
      });
      return p.set(c, g), u(g, c, v, p, h), g;
    }
    if (typeof Blob < "u" && c instanceof Blob) {
      const g = new Blob([c], { type: c.type });
      return p.set(c, g), u(g, c, v, p, h), g;
    }
    if (c instanceof Error) {
      const g = new c.constructor();
      return p.set(c, g), g.message = c.message, g.name = c.name, g.stack = c.stack, g.cause = c.cause, u(g, c, v, p, h), g;
    }
    if (c instanceof Boolean) {
      const g = new Boolean(c.valueOf());
      return p.set(c, g), u(g, c, v, p, h), g;
    }
    if (c instanceof Number) {
      const g = new Number(c.valueOf());
      return p.set(c, g), u(g, c, v, p, h), g;
    }
    if (c instanceof String) {
      const g = new String(c.valueOf());
      return p.set(c, g), u(g, c, v, p, h), g;
    }
    if (typeof c == "object" && s(c)) {
      const g = Object.create(Object.getPrototypeOf(c));
      return p.set(c, g), u(g, c, v, p, h), g;
    }
    return c;
  }
  function u(c, f, v = c, p, h) {
    const y = [...Object.keys(f), ...t.getSymbols(f)];
    for (let g = 0; g < y.length; g++) {
      const m = y[g], b = Object.getOwnPropertyDescriptor(c, m);
      (b == null || b.writable) && (c[m] = l(f[m], m, v, p, h));
    }
  }
  function s(c) {
    switch (r.getTag(c)) {
      case n.argumentsTag:
      case n.arrayTag:
      case n.arrayBufferTag:
      case n.dataViewTag:
      case n.booleanTag:
      case n.dateTag:
      case n.float32ArrayTag:
      case n.float64ArrayTag:
      case n.int8ArrayTag:
      case n.int16ArrayTag:
      case n.int32ArrayTag:
      case n.mapTag:
      case n.numberTag:
      case n.objectTag:
      case n.regexpTag:
      case n.setTag:
      case n.stringTag:
      case n.symbolTag:
      case n.uint8ArrayTag:
      case n.uint8ClampedArrayTag:
      case n.uint16ArrayTag:
      case n.uint32ArrayTag:
        return !0;
      default:
        return !1;
    }
  }
  e.cloneDeepWith = o, e.cloneDeepWithImpl = l, e.copyProperties = u;
})(oy);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = oy;
  function r(n) {
    return t.cloneDeepWithImpl(n, void 0, n, /* @__PURE__ */ new Map(), void 0);
  }
  e.cloneDeep = r;
})(IE);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = ry, r = IE;
  function n(i) {
    return i = r.cloneDeep(i), (a) => t.isMatch(a, i);
  }
  e.matches = n;
})(kE);
var jE = {}, CE = {}, fy = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = oy, r = sy;
  function n(i, a) {
    return t.cloneDeepWith(i, (o, l, u, s) => {
      const c = a == null ? void 0 : a(o, l, u, s);
      if (c !== void 0)
        return c;
      if (typeof i == "object")
        switch (Object.prototype.toString.call(i)) {
          case r.numberTag:
          case r.stringTag:
          case r.booleanTag: {
            const f = new i.constructor(i == null ? void 0 : i.valueOf());
            return t.copyProperties(f, i), f;
          }
          case r.argumentsTag: {
            const f = {};
            return t.copyProperties(f, i), f.length = i.length, f[Symbol.iterator] = i[Symbol.iterator], f;
          }
          default:
            return;
        }
    });
  }
  e.cloneDeepWith = n;
})(fy);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = fy;
  function r(n) {
    return t.cloneDeepWith(n);
  }
  e.cloneDeep = r;
})(CE);
var TE = {}, dy = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = /^(?:0|[1-9]\d*)$/;
  function r(n, i = Number.MAX_SAFE_INTEGER) {
    switch (typeof n) {
      case "number":
        return Number.isInteger(n) && n >= 0 && n < i;
      case "symbol":
        return !1;
      case "string":
        return t.test(n);
    }
  }
  e.isIndex = r;
})(dy);
var ME = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = uy;
  function r(n) {
    return n !== null && typeof n == "object" && t.getTag(n) === "[object Arguments]";
  }
  e.isArguments = r;
})(ME);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = uu, r = dy, n = ME, i = cu;
  function a(o, l) {
    let u;
    if (Array.isArray(l) ? u = l : typeof l == "string" && t.isDeepKey(l) && (o == null ? void 0 : o[l]) == null ? u = i.toPath(l) : u = [l], u.length === 0)
      return !1;
    let s = o;
    for (let c = 0; c < u.length; c++) {
      const f = u[c];
      if ((s == null || !Object.hasOwn(s, f)) && !((Array.isArray(s) || n.isArguments(s)) && r.isIndex(f) && f < s.length))
        return !1;
      s = s[f];
    }
    return !0;
  }
  e.has = a;
})(TE);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = ry, r = su, n = CE, i = lu, a = TE;
  function o(l, u) {
    switch (typeof l) {
      case "object": {
        Object.is(l == null ? void 0 : l.valueOf(), -0) && (l = "-0");
        break;
      }
      case "number": {
        l = r.toKey(l);
        break;
      }
    }
    return u = n.cloneDeep(u), function(s) {
      const c = i.get(s, l);
      return c === void 0 ? a.has(s, l) : u === void 0 ? c === void 0 : t.isMatch(c, u);
    };
  }
  e.matchesProperty = o;
})(jE);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = du, r = AE, n = kE, i = jE;
  function a(o) {
    if (o == null)
      return t.identity;
    switch (typeof o) {
      case "function":
        return o;
      case "object":
        return Array.isArray(o) && o.length === 2 ? i.matchesProperty(o[0], o[1]) : n.matches(o);
      case "string":
      case "symbol":
      case "number":
        return r.property(o);
    }
  }
  e.iteratee = a;
})(vu);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = PE, r = du, n = OE, i = vu;
  function a(o, l = r.identity) {
    return n.isArrayLikeObject(o) ? t.uniqBy(Array.from(o), i.iteratee(l)) : [];
  }
  e.uniqBy = a;
})(wE);
var n2 = wE.uniqBy;
const _b = /* @__PURE__ */ Wt(n2);
function DE(e, t, r) {
  return t === !0 ? _b(e, r) : typeof t == "function" ? _b(e, t) : e;
}
var NE = { exports: {} }, $E = {}, LE = { exports: {} }, RE = {};
/**
 * @license React
 * use-sync-external-store-shim.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Ga = d;
function i2(e, t) {
  return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t;
}
var a2 = typeof Object.is == "function" ? Object.is : i2, o2 = Ga.useState, l2 = Ga.useEffect, u2 = Ga.useLayoutEffect, s2 = Ga.useDebugValue;
function c2(e, t) {
  var r = t(), n = o2({ inst: { value: r, getSnapshot: t } }), i = n[0].inst, a = n[1];
  return u2(
    function() {
      i.value = r, i.getSnapshot = t, kv(i) && a({ inst: i });
    },
    [e, r, t]
  ), l2(
    function() {
      return kv(i) && a({ inst: i }), e(function() {
        kv(i) && a({ inst: i });
      });
    },
    [e]
  ), s2(r), r;
}
function kv(e) {
  var t = e.getSnapshot;
  e = e.value;
  try {
    var r = t();
    return !a2(e, r);
  } catch {
    return !0;
  }
}
function f2(e, t) {
  return t();
}
var d2 = typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u" ? f2 : c2;
RE.useSyncExternalStore = Ga.useSyncExternalStore !== void 0 ? Ga.useSyncExternalStore : d2;
LE.exports = RE;
var v2 = LE.exports;
/**
 * @license React
 * use-sync-external-store-shim/with-selector.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Gf = d, p2 = v2;
function h2(e, t) {
  return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t;
}
var m2 = typeof Object.is == "function" ? Object.is : h2, y2 = p2.useSyncExternalStore, g2 = Gf.useRef, b2 = Gf.useEffect, x2 = Gf.useMemo, w2 = Gf.useDebugValue;
$E.useSyncExternalStoreWithSelector = function(e, t, r, n, i) {
  var a = g2(null);
  if (a.current === null) {
    var o = { hasValue: !1, value: null };
    a.current = o;
  } else o = a.current;
  a = x2(
    function() {
      function u(p) {
        if (!s) {
          if (s = !0, c = p, p = n(p), i !== void 0 && o.hasValue) {
            var h = o.value;
            if (i(h, p))
              return f = h;
          }
          return f = p;
        }
        if (h = f, m2(c, p)) return h;
        var y = n(p);
        return i !== void 0 && i(h, y) ? (c = p, h) : (c = p, f = y);
      }
      var s = !1, c, f, v = r === void 0 ? null : r;
      return [
        function() {
          return u(t());
        },
        v === null ? void 0 : function() {
          return u(v());
        }
      ];
    },
    [t, r, n, i]
  );
  var l = y2(e, a[0], a[1]);
  return b2(
    function() {
      o.hasValue = !0, o.value = l;
    },
    [l]
  ), w2(l), l;
};
NE.exports = $E;
var P2 = NE.exports, vy = /* @__PURE__ */ d.createContext(null), O2 = (e) => e, J = () => {
  var e = d.useContext(vy);
  return e ? e.store.dispatch : O2;
}, Vs = () => {
}, S2 = () => Vs, E2 = (e, t) => e === t;
function T(e) {
  var t = d.useContext(vy);
  return P2.useSyncExternalStoreWithSelector(t ? t.subscription.addNestedSub : S2, t ? t.store.getState : Vs, t ? t.store.getState : Vs, t ? e : Vs, E2);
}
function A2(e, t = `expected a function, instead received ${typeof e}`) {
  if (typeof e != "function")
    throw new TypeError(t);
}
function k2(e, t = `expected an object, instead received ${typeof e}`) {
  if (typeof e != "object")
    throw new TypeError(t);
}
function _2(e, t = "expected all items to be functions, instead received the following types: ") {
  if (!e.every((r) => typeof r == "function")) {
    const r = e.map(
      (n) => typeof n == "function" ? `function ${n.name || "unnamed"}()` : typeof n
    ).join(", ");
    throw new TypeError(`${t}[${r}]`);
  }
}
var Ib = (e) => Array.isArray(e) ? e : [e];
function I2(e) {
  const t = Array.isArray(e[0]) ? e[0] : e;
  return _2(
    t,
    "createSelector expects all input-selectors to be functions, but received the following types: "
  ), t;
}
function j2(e, t) {
  const r = [], { length: n } = e;
  for (let i = 0; i < n; i++)
    r.push(e[i].apply(null, t));
  return r;
}
var C2 = class {
  constructor(e) {
    this.value = e;
  }
  deref() {
    return this.value;
  }
}, T2 = typeof WeakRef < "u" ? WeakRef : C2, M2 = 0, jb = 1;
function hs() {
  return {
    s: M2,
    v: void 0,
    o: null,
    p: null
  };
}
function zE(e, t = {}) {
  let r = hs();
  const { resultEqualityCheck: n } = t;
  let i, a = 0;
  function o() {
    var f;
    let l = r;
    const { length: u } = arguments;
    for (let v = 0, p = u; v < p; v++) {
      const h = arguments[v];
      if (typeof h == "function" || typeof h == "object" && h !== null) {
        let y = l.o;
        y === null && (l.o = y = /* @__PURE__ */ new WeakMap());
        const g = y.get(h);
        g === void 0 ? (l = hs(), y.set(h, l)) : l = g;
      } else {
        let y = l.p;
        y === null && (l.p = y = /* @__PURE__ */ new Map());
        const g = y.get(h);
        g === void 0 ? (l = hs(), y.set(h, l)) : l = g;
      }
    }
    const s = l;
    let c;
    if (l.s === jb)
      c = l.v;
    else if (c = e.apply(null, arguments), a++, n) {
      const v = ((f = i == null ? void 0 : i.deref) == null ? void 0 : f.call(i)) ?? i;
      v != null && n(v, c) && (c = v, a !== 0 && a--), i = typeof c == "object" && c !== null || typeof c == "function" ? new T2(c) : c;
    }
    return s.s = jb, s.v = c, c;
  }
  return o.clearCache = () => {
    r = hs(), o.resetResultsCount();
  }, o.resultsCount = () => a, o.resetResultsCount = () => {
    a = 0;
  }, o;
}
function D2(e, ...t) {
  const r = typeof e == "function" ? {
    memoize: e,
    memoizeOptions: t
  } : e, n = (...i) => {
    let a = 0, o = 0, l, u = {}, s = i.pop();
    typeof s == "object" && (u = s, s = i.pop()), A2(
      s,
      `createSelector expects an output function after the inputs, but received: [${typeof s}]`
    );
    const c = {
      ...r,
      ...u
    }, {
      memoize: f,
      memoizeOptions: v = [],
      argsMemoize: p = zE,
      argsMemoizeOptions: h = []
    } = c, y = Ib(v), g = Ib(h), m = I2(i), b = f(function() {
      return a++, s.apply(
        null,
        arguments
      );
    }, ...y), x = p(function() {
      o++;
      const P = j2(
        m,
        arguments
      );
      return l = b.apply(null, P), l;
    }, ...g);
    return Object.assign(x, {
      resultFunc: s,
      memoizedResultFunc: b,
      dependencies: m,
      dependencyRecomputations: () => o,
      resetDependencyRecomputations: () => {
        o = 0;
      },
      lastResult: () => l,
      recomputations: () => a,
      resetRecomputations: () => {
        a = 0;
      },
      memoize: f,
      argsMemoize: p
    });
  };
  return Object.assign(n, {
    withTypes: () => n
  }), n;
}
var A = /* @__PURE__ */ D2(zE), N2 = Object.assign(
  (e, t = A) => {
    k2(
      e,
      `createStructuredSelector expects first argument to be an object where each property is a selector, instead received a ${typeof e}`
    );
    const r = Object.keys(e), n = r.map(
      (a) => e[a]
    );
    return t(
      n,
      (...a) => a.reduce((o, l, u) => (o[r[u]] = l, o), {})
    );
  },
  { withTypes: () => N2 }
), BE = {}, FE = {}, KE = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(n) {
    return typeof n == "symbol" ? 1 : n === null ? 2 : n === void 0 ? 3 : n !== n ? 4 : 0;
  }
  const r = (n, i, a) => {
    if (n !== i) {
      const o = t(n), l = t(i);
      if (o === l && o === 0) {
        if (n < i)
          return a === "desc" ? 1 : -1;
        if (n > i)
          return a === "desc" ? -1 : 1;
      }
      return a === "desc" ? l - o : o - l;
    }
    return 0;
  };
  e.compareValues = r;
})(KE);
var WE = {}, py = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r) {
    return typeof r == "symbol" || r instanceof Symbol;
  }
  e.isSymbol = t;
})(py);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = py, r = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/, n = /^\w*$/;
  function i(a, o) {
    return Array.isArray(a) ? !1 : typeof a == "number" || typeof a == "boolean" || a == null || t.isSymbol(a) ? !0 : typeof a == "string" && (n.test(a) || !r.test(a)) || o != null && Object.hasOwn(o, a);
  }
  e.isKey = i;
})(WE);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = KE, r = WE, n = cu;
  function i(a, o, l, u) {
    if (a == null)
      return [];
    l = u ? void 0 : l, Array.isArray(a) || (a = Object.values(a)), Array.isArray(o) || (o = o == null ? [null] : [o]), o.length === 0 && (o = [null]), Array.isArray(l) || (l = l == null ? [] : [l]), l = l.map((p) => String(p));
    const s = (p, h) => {
      let y = p;
      for (let g = 0; g < h.length && y != null; ++g)
        y = y[h[g]];
      return y;
    }, c = (p, h) => h == null || p == null ? h : typeof p == "object" && "key" in p ? Object.hasOwn(h, p.key) ? h[p.key] : s(h, p.path) : typeof p == "function" ? p(h) : Array.isArray(p) ? s(h, p) : typeof h == "object" ? h[p] : h, f = o.map((p) => (Array.isArray(p) && p.length === 1 && (p = p[0]), p == null || typeof p == "function" || Array.isArray(p) || r.isKey(p) ? p : { key: p, path: n.toPath(p) }));
    return a.map((p) => ({
      original: p,
      criteria: f.map((h) => c(h, p))
    })).slice().sort((p, h) => {
      for (let y = 0; y < f.length; y++) {
        const g = t.compareValues(p.criteria[y], h.criteria[y], l[y]);
        if (g !== 0)
          return g;
      }
      return 0;
    }).map((p) => p.original);
  }
  e.orderBy = i;
})(FE);
var UE = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r, n = 1) {
    const i = [], a = Math.floor(n), o = (l, u) => {
      for (let s = 0; s < l.length; s++) {
        const c = l[s];
        Array.isArray(c) && u < a ? o(c, u + 1) : i.push(c);
      }
    };
    return o(r, 0), i;
  }
  e.flatten = t;
})(UE);
var hy = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = dy, r = fo, n = ny, i = ay;
  function a(o, l, u) {
    return n.isObject(u) && (typeof l == "number" && r.isArrayLike(u) && t.isIndex(l) && l < u.length || typeof l == "string" && l in u) ? i.eq(u[l], o) : !1;
  }
  e.isIterateeCall = a;
})(hy);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = FE, r = UE, n = hy;
  function i(a, ...o) {
    const l = o.length;
    return l > 1 && n.isIterateeCall(a, o[0], o[1]) ? o = [] : l > 2 && n.isIterateeCall(o[0], o[1], o[2]) && (o = [o[0]]), t.orderBy(a, r.flatten(o), ["asc"]);
  }
  e.sortBy = i;
})(BE);
var $2 = BE.sortBy;
const qf = /* @__PURE__ */ Wt($2);
var VE = (e) => e.legend.settings, L2 = (e) => e.legend.size, R2 = (e) => e.legend.payload, z2 = A([R2, VE], (e, t) => {
  var {
    itemSorter: r
  } = t, n = e.flat(1);
  return r ? qf(n, r) : n;
});
function B2() {
  return T(z2);
}
var ms = 1;
function HE() {
  var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], [t, r] = d.useState({
    height: 0,
    left: 0,
    top: 0,
    width: 0
  }), n = d.useCallback(
    (i) => {
      if (i != null) {
        var a = i.getBoundingClientRect(), o = {
          height: a.height,
          left: a.left,
          top: a.top,
          width: a.width
        };
        (Math.abs(o.height - t.height) > ms || Math.abs(o.left - t.left) > ms || Math.abs(o.top - t.top) > ms || Math.abs(o.width - t.width) > ms) && r({
          height: o.height,
          left: o.left,
          top: o.top,
          width: o.width
        });
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [t.width, t.height, t.top, t.left, ...e]
  );
  return [t, n];
}
function ut(e) {
  return `Minified Redux error #${e}; visit https://redux.js.org/Errors?code=${e} for the full message or use the non-minified dev environment for full errors. `;
}
var F2 = typeof Symbol == "function" && Symbol.observable || "@@observable", Cb = F2, _v = () => Math.random().toString(36).substring(7).split("").join("."), K2 = {
  INIT: `@@redux/INIT${/* @__PURE__ */ _v()}`,
  REPLACE: `@@redux/REPLACE${/* @__PURE__ */ _v()}`,
  PROBE_UNKNOWN_ACTION: () => `@@redux/PROBE_UNKNOWN_ACTION${_v()}`
}, _c = K2;
function my(e) {
  if (typeof e != "object" || e === null)
    return !1;
  let t = e;
  for (; Object.getPrototypeOf(t) !== null; )
    t = Object.getPrototypeOf(t);
  return Object.getPrototypeOf(e) === t || Object.getPrototypeOf(e) === null;
}
function XE(e, t, r) {
  if (typeof e != "function")
    throw new Error(ut(2));
  if (typeof t == "function" && typeof r == "function" || typeof r == "function" && typeof arguments[3] == "function")
    throw new Error(ut(0));
  if (typeof t == "function" && typeof r > "u" && (r = t, t = void 0), typeof r < "u") {
    if (typeof r != "function")
      throw new Error(ut(1));
    return r(XE)(e, t);
  }
  let n = e, i = t, a = /* @__PURE__ */ new Map(), o = a, l = 0, u = !1;
  function s() {
    o === a && (o = /* @__PURE__ */ new Map(), a.forEach((g, m) => {
      o.set(m, g);
    }));
  }
  function c() {
    if (u)
      throw new Error(ut(3));
    return i;
  }
  function f(g) {
    if (typeof g != "function")
      throw new Error(ut(4));
    if (u)
      throw new Error(ut(5));
    let m = !0;
    s();
    const b = l++;
    return o.set(b, g), function() {
      if (m) {
        if (u)
          throw new Error(ut(6));
        m = !1, s(), o.delete(b), a = null;
      }
    };
  }
  function v(g) {
    if (!my(g))
      throw new Error(ut(7));
    if (typeof g.type > "u")
      throw new Error(ut(8));
    if (typeof g.type != "string")
      throw new Error(ut(17));
    if (u)
      throw new Error(ut(9));
    try {
      u = !0, i = n(i, g);
    } finally {
      u = !1;
    }
    return (a = o).forEach((b) => {
      b();
    }), g;
  }
  function p(g) {
    if (typeof g != "function")
      throw new Error(ut(10));
    n = g, v({
      type: _c.REPLACE
    });
  }
  function h() {
    const g = f;
    return {
      /**
       * The minimal observable subscription method.
       * @param observer Any object that can be used as an observer.
       * The observer object should have a `next` method.
       * @returns An object with an `unsubscribe` method that can
       * be used to unsubscribe the observable from the store, and prevent further
       * emission of values from the observable.
       */
      subscribe(m) {
        if (typeof m != "object" || m === null)
          throw new Error(ut(11));
        function b() {
          const w = m;
          w.next && w.next(c());
        }
        return b(), {
          unsubscribe: g(b)
        };
      },
      [Cb]() {
        return this;
      }
    };
  }
  return v({
    type: _c.INIT
  }), {
    dispatch: v,
    subscribe: f,
    getState: c,
    replaceReducer: p,
    [Cb]: h
  };
}
function W2(e) {
  Object.keys(e).forEach((t) => {
    const r = e[t];
    if (typeof r(void 0, {
      type: _c.INIT
    }) > "u")
      throw new Error(ut(12));
    if (typeof r(void 0, {
      type: _c.PROBE_UNKNOWN_ACTION()
    }) > "u")
      throw new Error(ut(13));
  });
}
function YE(e) {
  const t = Object.keys(e), r = {};
  for (let a = 0; a < t.length; a++) {
    const o = t[a];
    typeof e[o] == "function" && (r[o] = e[o]);
  }
  const n = Object.keys(r);
  let i;
  try {
    W2(r);
  } catch (a) {
    i = a;
  }
  return function(o = {}, l) {
    if (i)
      throw i;
    let u = !1;
    const s = {};
    for (let c = 0; c < n.length; c++) {
      const f = n[c], v = r[f], p = o[f], h = v(p, l);
      if (typeof h > "u")
        throw l && l.type, new Error(ut(14));
      s[f] = h, u = u || h !== p;
    }
    return u = u || n.length !== Object.keys(o).length, u ? s : o;
  };
}
function Ic(...e) {
  return e.length === 0 ? (t) => t : e.length === 1 ? e[0] : e.reduce((t, r) => (...n) => t(r(...n)));
}
function U2(...e) {
  return (t) => (r, n) => {
    const i = t(r, n);
    let a = () => {
      throw new Error(ut(15));
    };
    const o = {
      getState: i.getState,
      dispatch: (u, ...s) => a(u, ...s)
    }, l = e.map((u) => u(o));
    return a = Ic(...l)(i.dispatch), {
      ...i,
      dispatch: a
    };
  };
}
function GE(e) {
  return my(e) && "type" in e && typeof e.type == "string";
}
var qE = Symbol.for("immer-nothing"), Tb = Symbol.for("immer-draftable"), kt = Symbol.for("immer-state");
function Er(e, ...t) {
  throw new Error(
    `[Immer] minified error nr: ${e}. Full error at: https://bit.ly/3cXEKWf`
  );
}
var qt = Object, qa = qt.getPrototypeOf, jc = "constructor", Zf = "prototype", Qp = "configurable", Cc = "enumerable", Hs = "writable", Dl = "value", _n = (e) => !!e && !!e[kt];
function Mr(e) {
  var t;
  return e ? ZE(e) || Jf(e) || !!e[Tb] || !!((t = e[jc]) != null && t[Tb]) || ed(e) || td(e) : !1;
}
var V2 = qt[Zf][jc].toString(), Mb = /* @__PURE__ */ new WeakMap();
function ZE(e) {
  if (!e || !yy(e))
    return !1;
  const t = qa(e);
  if (t === null || t === qt[Zf])
    return !0;
  const r = qt.hasOwnProperty.call(t, jc) && t[jc];
  if (r === Object)
    return !0;
  if (!ha(r))
    return !1;
  let n = Mb.get(r);
  return n === void 0 && (n = Function.toString.call(r), Mb.set(r, n)), n === V2;
}
function Qf(e, t, r = !0) {
  pu(e) === 0 ? (r ? Reflect.ownKeys(e) : qt.keys(e)).forEach((i) => {
    t(i, e[i], e);
  }) : e.forEach((n, i) => t(i, n, e));
}
function pu(e) {
  const t = e[kt];
  return t ? t.type_ : Jf(e) ? 1 : ed(e) ? 2 : td(e) ? 3 : 0;
}
var Db = (e, t, r = pu(e)) => r === 2 ? e.has(t) : qt[Zf].hasOwnProperty.call(e, t), Jp = (e, t, r = pu(e)) => (
  // @ts-ignore
  r === 2 ? e.get(t) : e[t]
), Tc = (e, t, r, n = pu(e)) => {
  n === 2 ? e.set(t, r) : n === 3 ? e.add(r) : e[t] = r;
};
function H2(e, t) {
  return e === t ? e !== 0 || 1 / e === 1 / t : e !== e && t !== t;
}
var Jf = Array.isArray, ed = (e) => e instanceof Map, td = (e) => e instanceof Set, yy = (e) => typeof e == "object", ha = (e) => typeof e == "function", Iv = (e) => typeof e == "boolean";
function X2(e) {
  const t = +e;
  return Number.isInteger(t) && String(t) === e;
}
var dn = (e) => e.copy_ || e.base_, gy = (e) => e.modified_ ? e.copy_ : e.base_;
function eh(e, t) {
  if (ed(e))
    return new Map(e);
  if (td(e))
    return new Set(e);
  if (Jf(e))
    return Array[Zf].slice.call(e);
  const r = ZE(e);
  if (t === !0 || t === "class_only" && !r) {
    const n = qt.getOwnPropertyDescriptors(e);
    delete n[kt];
    let i = Reflect.ownKeys(n);
    for (let a = 0; a < i.length; a++) {
      const o = i[a], l = n[o];
      l[Hs] === !1 && (l[Hs] = !0, l[Qp] = !0), (l.get || l.set) && (n[o] = {
        [Qp]: !0,
        [Hs]: !0,
        // could live with !!desc.set as well here...
        [Cc]: l[Cc],
        [Dl]: e[o]
      });
    }
    return qt.create(qa(e), n);
  } else {
    const n = qa(e);
    if (n !== null && r)
      return { ...e };
    const i = qt.create(n);
    return qt.assign(i, e);
  }
}
function by(e, t = !1) {
  return rd(e) || _n(e) || !Mr(e) || (pu(e) > 1 && qt.defineProperties(e, {
    set: ys,
    add: ys,
    clear: ys,
    delete: ys
  }), qt.freeze(e), t && Qf(
    e,
    (r, n) => {
      by(n, !0);
    },
    !1
  )), e;
}
function Y2() {
  Er(2);
}
var ys = {
  [Dl]: Y2
};
function rd(e) {
  return e === null || !yy(e) ? !0 : qt.isFrozen(e);
}
var Mc = "MapSet", th = "Patches", Nb = "ArrayMethods", QE = {};
function Yi(e) {
  const t = QE[e];
  return t || Er(0, e), t;
}
var $b = (e) => !!QE[e], Nl, JE = () => Nl, G2 = (e, t) => ({
  drafts_: [],
  parent_: e,
  immer_: t,
  // Whenever the modified draft contains a draft from another scope, we
  // need to prevent auto-freezing so the unowned draft can be finalized.
  canAutoFreeze_: !0,
  unfinalizedDrafts_: 0,
  handledSet_: /* @__PURE__ */ new Set(),
  processedForPatches_: /* @__PURE__ */ new Set(),
  mapSetPlugin_: $b(Mc) ? Yi(Mc) : void 0,
  arrayMethodsPlugin_: $b(Nb) ? Yi(Nb) : void 0
});
function Lb(e, t) {
  t && (e.patchPlugin_ = Yi(th), e.patches_ = [], e.inversePatches_ = [], e.patchListener_ = t);
}
function rh(e) {
  nh(e), e.drafts_.forEach(q2), e.drafts_ = null;
}
function nh(e) {
  e === Nl && (Nl = e.parent_);
}
var Rb = (e) => Nl = G2(Nl, e);
function q2(e) {
  const t = e[kt];
  t.type_ === 0 || t.type_ === 1 ? t.revoke_() : t.revoked_ = !0;
}
function zb(e, t) {
  t.unfinalizedDrafts_ = t.drafts_.length;
  const r = t.drafts_[0];
  if (e !== void 0 && e !== r) {
    r[kt].modified_ && (rh(t), Er(4)), Mr(e) && (e = Bb(t, e));
    const { patchPlugin_: i } = t;
    i && i.generateReplacementPatches_(
      r[kt].base_,
      e,
      t
    );
  } else
    e = Bb(t, r);
  return Z2(t, e, !0), rh(t), t.patches_ && t.patchListener_(t.patches_, t.inversePatches_), e !== qE ? e : void 0;
}
function Bb(e, t) {
  if (rd(t))
    return t;
  const r = t[kt];
  if (!r)
    return Dc(t, e.handledSet_, e);
  if (!nd(r, e))
    return t;
  if (!r.modified_)
    return r.base_;
  if (!r.finalized_) {
    const { callbacks_: n } = r;
    if (n)
      for (; n.length > 0; )
        n.pop()(e);
    rA(r, e);
  }
  return r.copy_;
}
function Z2(e, t, r = !1) {
  !e.parent_ && e.immer_.autoFreeze_ && e.canAutoFreeze_ && by(t, r);
}
function eA(e) {
  e.finalized_ = !0, e.scope_.unfinalizedDrafts_--;
}
var nd = (e, t) => e.scope_ === t, Q2 = [];
function tA(e, t, r, n) {
  const i = dn(e), a = e.type_;
  if (n !== void 0 && Jp(i, n, a) === t) {
    Tc(i, n, r, a);
    return;
  }
  if (!e.draftLocations_) {
    const l = e.draftLocations_ = /* @__PURE__ */ new Map();
    Qf(i, (u, s) => {
      if (_n(s)) {
        const c = l.get(s) || [];
        c.push(u), l.set(s, c);
      }
    });
  }
  const o = e.draftLocations_.get(t) ?? Q2;
  for (const l of o)
    Tc(i, l, r, a);
}
function J2(e, t, r) {
  e.callbacks_.push(function(i) {
    var l;
    const a = t;
    if (!a || !nd(a, i))
      return;
    (l = i.mapSetPlugin_) == null || l.fixSetContents(a);
    const o = gy(a);
    tA(e, a.draft_ ?? a, o, r), rA(a, i);
  });
}
function rA(e, t) {
  var n;
  if (e.modified_ && !e.finalized_ && (e.type_ === 3 || e.type_ === 1 && e.allIndicesReassigned_ || (((n = e.assigned_) == null ? void 0 : n.size) ?? 0) > 0)) {
    const { patchPlugin_: i } = t;
    if (i) {
      const a = i.getPath(e);
      a && i.generatePatches_(e, a, t);
    }
    eA(e);
  }
}
function eN(e, t, r) {
  const { scope_: n } = e;
  if (_n(r)) {
    const i = r[kt];
    nd(i, n) && i.callbacks_.push(function() {
      Xs(e);
      const o = gy(i);
      tA(e, r, o, t);
    });
  } else Mr(r) && e.callbacks_.push(function() {
    const a = dn(e);
    e.type_ === 3 ? a.has(r) && Dc(r, n.handledSet_, n) : Jp(a, t, e.type_) === r && n.drafts_.length > 1 && (e.assigned_.get(t) ?? !1) === !0 && e.copy_ && Dc(
      Jp(e.copy_, t, e.type_),
      n.handledSet_,
      n
    );
  });
}
function Dc(e, t, r) {
  return !r.immer_.autoFreeze_ && r.unfinalizedDrafts_ < 1 || _n(e) || t.has(e) || !Mr(e) || rd(e) || (t.add(e), Qf(e, (n, i) => {
    if (_n(i)) {
      const a = i[kt];
      if (nd(a, r)) {
        const o = gy(a);
        Tc(e, n, o, e.type_), eA(a);
      }
    } else Mr(i) && Dc(i, t, r);
  })), e;
}
function tN(e, t) {
  const r = Jf(e), n = {
    type_: r ? 1 : 0,
    // Track which produce call this is associated with.
    scope_: t ? t.scope_ : JE(),
    // True for both shallow and deep changes.
    modified_: !1,
    // Used during finalization.
    finalized_: !1,
    // Track which properties have been assigned (true) or deleted (false).
    // actually instantiated in `prepareCopy()`
    assigned_: void 0,
    // The parent draft state.
    parent_: t,
    // The base state.
    base_: e,
    // The base proxy.
    draft_: null,
    // set below
    // The base copy with any updated values.
    copy_: null,
    // Called by the `produce` function.
    revoke_: null,
    isManual_: !1,
    // `callbacks` actually gets assigned in `createProxy`
    callbacks_: void 0
  };
  let i = n, a = Nc;
  r && (i = [n], a = $l);
  const { revoke: o, proxy: l } = Proxy.revocable(i, a);
  return n.draft_ = l, n.revoke_ = o, [l, n];
}
var Nc = {
  get(e, t) {
    if (t === kt)
      return e;
    let r = e.scope_.arrayMethodsPlugin_;
    const n = e.type_ === 1 && typeof t == "string";
    if (n && r != null && r.isArrayOperationMethod(t))
      return r.createMethodInterceptor(e, t);
    const i = dn(e);
    if (!Db(i, t, e.type_))
      return rN(e, i, t);
    const a = i[t];
    if (e.finalized_ || !Mr(a) || n && e.operationMethod && (r != null && r.isMutatingArrayMethod(
      e.operationMethod
    )) && X2(t))
      return a;
    if (a === jv(e.base_, t)) {
      Xs(e);
      const o = e.type_ === 1 ? +t : t, l = ah(e.scope_, a, e, o);
      return e.copy_[o] = l;
    }
    return a;
  },
  has(e, t) {
    return t in dn(e);
  },
  ownKeys(e) {
    return Reflect.ownKeys(dn(e));
  },
  set(e, t, r) {
    const n = nA(dn(e), t);
    if (n != null && n.set)
      return n.set.call(e.draft_, r), !0;
    if (!e.modified_) {
      const i = jv(dn(e), t), a = i == null ? void 0 : i[kt];
      if (a && a.base_ === r)
        return e.copy_[t] = r, e.assigned_.set(t, !1), !0;
      if (H2(r, i) && (r !== void 0 || Db(e.base_, t, e.type_)))
        return !0;
      Xs(e), ih(e);
    }
    return e.copy_[t] === r && // special case: handle new props with value 'undefined'
    (r !== void 0 || t in e.copy_) || // special case: NaN
    Number.isNaN(r) && Number.isNaN(e.copy_[t]) || (e.copy_[t] = r, e.assigned_.set(t, !0), eN(e, t, r)), !0;
  },
  deleteProperty(e, t) {
    return Xs(e), jv(e.base_, t) !== void 0 || t in e.base_ ? (e.assigned_.set(t, !1), ih(e)) : e.assigned_.delete(t), e.copy_ && delete e.copy_[t], !0;
  },
  // Note: We never coerce `desc.value` into an Immer draft, because we can't make
  // the same guarantee in ES5 mode.
  getOwnPropertyDescriptor(e, t) {
    const r = dn(e), n = Reflect.getOwnPropertyDescriptor(r, t);
    return n && {
      [Hs]: !0,
      [Qp]: e.type_ !== 1 || t !== "length",
      [Cc]: n[Cc],
      [Dl]: r[t]
    };
  },
  defineProperty() {
    Er(11);
  },
  getPrototypeOf(e) {
    return qa(e.base_);
  },
  setPrototypeOf() {
    Er(12);
  }
}, $l = {};
for (let e in Nc) {
  let t = Nc[e];
  $l[e] = function() {
    const r = arguments;
    return r[0] = r[0][0], t.apply(this, r);
  };
}
$l.deleteProperty = function(e, t) {
  return $l.set.call(this, e, t, void 0);
};
$l.set = function(e, t, r) {
  return Nc.set.call(this, e[0], t, r, e[0]);
};
function jv(e, t) {
  const r = e[kt];
  return (r ? dn(r) : e)[t];
}
function rN(e, t, r) {
  var i;
  const n = nA(t, r);
  return n ? Dl in n ? n[Dl] : (
    // This is a very special case, if the prop is a getter defined by the
    // prototype, we should invoke it with the draft as context!
    (i = n.get) == null ? void 0 : i.call(e.draft_)
  ) : void 0;
}
function nA(e, t) {
  if (!(t in e))
    return;
  let r = qa(e);
  for (; r; ) {
    const n = Object.getOwnPropertyDescriptor(r, t);
    if (n)
      return n;
    r = qa(r);
  }
}
function ih(e) {
  e.modified_ || (e.modified_ = !0, e.parent_ && ih(e.parent_));
}
function Xs(e) {
  e.copy_ || (e.assigned_ = /* @__PURE__ */ new Map(), e.copy_ = eh(
    e.base_,
    e.scope_.immer_.useStrictShallowCopy_
  ));
}
var nN = class {
  constructor(t) {
    this.autoFreeze_ = !0, this.useStrictShallowCopy_ = !1, this.useStrictIteration_ = !1, this.produce = (r, n, i) => {
      if (ha(r) && !ha(n)) {
        const o = n;
        n = r;
        const l = this;
        return function(s = o, ...c) {
          return l.produce(s, (f) => n.call(this, f, ...c));
        };
      }
      ha(n) || Er(6), i !== void 0 && !ha(i) && Er(7);
      let a;
      if (Mr(r)) {
        const o = Rb(this), l = ah(o, r, void 0);
        let u = !0;
        try {
          a = n(l), u = !1;
        } finally {
          u ? rh(o) : nh(o);
        }
        return Lb(o, i), zb(a, o);
      } else if (!r || !yy(r)) {
        if (a = n(r), a === void 0 && (a = r), a === qE && (a = void 0), this.autoFreeze_ && by(a, !0), i) {
          const o = [], l = [];
          Yi(th).generateReplacementPatches_(r, a, {
            patches_: o,
            inversePatches_: l
          }), i(o, l);
        }
        return a;
      } else
        Er(1, r);
    }, this.produceWithPatches = (r, n) => {
      if (ha(r))
        return (l, ...u) => this.produceWithPatches(l, (s) => r(s, ...u));
      let i, a;
      return [this.produce(r, n, (l, u) => {
        i = l, a = u;
      }), i, a];
    }, Iv(t == null ? void 0 : t.autoFreeze) && this.setAutoFreeze(t.autoFreeze), Iv(t == null ? void 0 : t.useStrictShallowCopy) && this.setUseStrictShallowCopy(t.useStrictShallowCopy), Iv(t == null ? void 0 : t.useStrictIteration) && this.setUseStrictIteration(t.useStrictIteration);
  }
  createDraft(t) {
    Mr(t) || Er(8), _n(t) && (t = Cr(t));
    const r = Rb(this), n = ah(r, t, void 0);
    return n[kt].isManual_ = !0, nh(r), n;
  }
  finishDraft(t, r) {
    const n = t && t[kt];
    (!n || !n.isManual_) && Er(9);
    const { scope_: i } = n;
    return Lb(i, r), zb(void 0, i);
  }
  /**
   * Pass true to automatically freeze all copies created by Immer.
   *
   * By default, auto-freezing is enabled.
   */
  setAutoFreeze(t) {
    this.autoFreeze_ = t;
  }
  /**
   * Pass true to enable strict shallow copy.
   *
   * By default, immer does not copy the object descriptors such as getter, setter and non-enumrable properties.
   */
  setUseStrictShallowCopy(t) {
    this.useStrictShallowCopy_ = t;
  }
  /**
   * Pass false to use faster iteration that skips non-enumerable properties
   * but still handles symbols for compatibility.
   *
   * By default, strict iteration is enabled (includes all own properties).
   */
  setUseStrictIteration(t) {
    this.useStrictIteration_ = t;
  }
  shouldUseStrictIteration() {
    return this.useStrictIteration_;
  }
  applyPatches(t, r) {
    let n;
    for (n = r.length - 1; n >= 0; n--) {
      const a = r[n];
      if (a.path.length === 0 && a.op === "replace") {
        t = a.value;
        break;
      }
    }
    n > -1 && (r = r.slice(n + 1));
    const i = Yi(th).applyPatches_;
    return _n(t) ? i(t, r) : this.produce(
      t,
      (a) => i(a, r)
    );
  }
};
function ah(e, t, r, n) {
  const [i, a] = ed(t) ? Yi(Mc).proxyMap_(t, r) : td(t) ? Yi(Mc).proxySet_(t, r) : tN(t, r);
  return ((r == null ? void 0 : r.scope_) ?? JE()).drafts_.push(i), a.callbacks_ = (r == null ? void 0 : r.callbacks_) ?? [], a.key_ = n, r && n !== void 0 ? J2(r, a, n) : a.callbacks_.push(function(u) {
    var c;
    (c = u.mapSetPlugin_) == null || c.fixSetContents(a);
    const { patchPlugin_: s } = u;
    a.modified_ && s && s.generatePatches_(a, [], u);
  }), i;
}
function Cr(e) {
  return _n(e) || Er(10, e), iA(e);
}
function iA(e) {
  if (!Mr(e) || rd(e))
    return e;
  const t = e[kt];
  let r, n = !0;
  if (t) {
    if (!t.modified_)
      return t.base_;
    t.finalized_ = !0, r = eh(e, t.scope_.immer_.useStrictShallowCopy_), n = t.scope_.immer_.shouldUseStrictIteration();
  } else
    r = eh(e, !0);
  return Qf(
    r,
    (i, a) => {
      Tc(r, i, iA(a));
    },
    n
  ), t && (t.finalized_ = !1), r;
}
var iN = new nN(), aA = iN.produce;
function oA(e) {
  return ({ dispatch: r, getState: n }) => (i) => (a) => typeof a == "function" ? a(r, n, e) : i(a);
}
var aN = oA(), oN = oA, lN = typeof window < "u" && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ : function() {
  if (arguments.length !== 0)
    return typeof arguments[0] == "object" ? Ic : Ic.apply(null, arguments);
};
function mr(e, t) {
  function r(...n) {
    if (t) {
      let i = t(...n);
      if (!i)
        throw new Error(Qt(0));
      return {
        type: e,
        payload: i.payload,
        ..."meta" in i && {
          meta: i.meta
        },
        ..."error" in i && {
          error: i.error
        }
      };
    }
    return {
      type: e,
      payload: n[0]
    };
  }
  return r.toString = () => `${e}`, r.type = e, r.match = (n) => GE(n) && n.type === e, r;
}
var lA = class nl extends Array {
  constructor(...t) {
    super(...t), Object.setPrototypeOf(this, nl.prototype);
  }
  static get [Symbol.species]() {
    return nl;
  }
  concat(...t) {
    return super.concat.apply(this, t);
  }
  prepend(...t) {
    return t.length === 1 && Array.isArray(t[0]) ? new nl(...t[0].concat(this)) : new nl(...t.concat(this));
  }
};
function Fb(e) {
  return Mr(e) ? aA(e, () => {
  }) : e;
}
function gs(e, t, r) {
  return e.has(t) ? e.get(t) : e.set(t, r(t)).get(t);
}
function uN(e) {
  return typeof e == "boolean";
}
var sN = () => function(t) {
  const {
    thunk: r = !0,
    immutableCheck: n = !0,
    serializableCheck: i = !0,
    actionCreatorCheck: a = !0
  } = t ?? {};
  let o = new lA();
  return r && (uN(r) ? o.push(aN) : o.push(oN(r.extraArgument))), o;
}, uA = "RTK_autoBatch", ke = () => (e) => ({
  payload: e,
  meta: {
    [uA]: !0
  }
}), Kb = (e) => (t) => {
  setTimeout(t, e);
}, sA = (e = {
  type: "raf"
}) => (t) => (...r) => {
  const n = t(...r);
  let i = !0, a = !1, o = !1;
  const l = /* @__PURE__ */ new Set(), u = e.type === "tick" ? queueMicrotask : e.type === "raf" ? (
    // requestAnimationFrame won't exist in SSR environments. Fall back to a vague approximation just to keep from erroring.
    typeof window < "u" && window.requestAnimationFrame ? window.requestAnimationFrame : Kb(10)
  ) : e.type === "callback" ? e.queueNotification : Kb(e.timeout), s = () => {
    o = !1, a && (a = !1, l.forEach((c) => c()));
  };
  return Object.assign({}, n, {
    // Override the base `store.subscribe` method to keep original listeners
    // from running if we're delaying notifications
    subscribe(c) {
      const f = () => i && c(), v = n.subscribe(f);
      return l.add(c), () => {
        v(), l.delete(c);
      };
    },
    // Override the base `store.dispatch` method so that we can check actions
    // for the `shouldAutoBatch` flag and determine if batching is active
    dispatch(c) {
      var f;
      try {
        return i = !((f = c == null ? void 0 : c.meta) != null && f[uA]), a = !i, a && (o || (o = !0, u(s))), n.dispatch(c);
      } finally {
        i = !0;
      }
    }
  });
}, cN = (e) => function(r) {
  const {
    autoBatch: n = !0
  } = r ?? {};
  let i = new lA(e);
  return n && i.push(sA(typeof n == "object" ? n : void 0)), i;
};
function fN(e) {
  const t = sN(), {
    reducer: r = void 0,
    middleware: n,
    devTools: i = !0,
    preloadedState: a = void 0,
    enhancers: o = void 0
  } = e || {};
  let l;
  if (typeof r == "function")
    l = r;
  else if (my(r))
    l = YE(r);
  else
    throw new Error(Qt(1));
  let u;
  typeof n == "function" ? u = n(t) : u = t();
  let s = Ic;
  i && (s = lN({
    // Enable capture of stack traces for dispatched Redux actions
    trace: !1,
    ...typeof i == "object" && i
  }));
  const c = U2(...u), f = cN(c);
  let v = typeof o == "function" ? o(f) : f();
  const p = s(...v);
  return XE(l, a, p);
}
function cA(e) {
  const t = {}, r = [];
  let n;
  const i = {
    addCase(a, o) {
      const l = typeof a == "string" ? a : a.type;
      if (!l)
        throw new Error(Qt(28));
      if (l in t)
        throw new Error(Qt(29));
      return t[l] = o, i;
    },
    addAsyncThunk(a, o) {
      return o.pending && (t[a.pending.type] = o.pending), o.rejected && (t[a.rejected.type] = o.rejected), o.fulfilled && (t[a.fulfilled.type] = o.fulfilled), o.settled && r.push({
        matcher: a.settled,
        reducer: o.settled
      }), i;
    },
    addMatcher(a, o) {
      return r.push({
        matcher: a,
        reducer: o
      }), i;
    },
    addDefaultCase(a) {
      return n = a, i;
    }
  };
  return e(i), [t, r, n];
}
function dN(e) {
  return typeof e == "function";
}
function vN(e, t) {
  let [r, n, i] = cA(t), a;
  if (dN(e))
    a = () => Fb(e());
  else {
    const l = Fb(e);
    a = () => l;
  }
  function o(l = a(), u) {
    let s = [r[u.type], ...n.filter(({
      matcher: c
    }) => c(u)).map(({
      reducer: c
    }) => c)];
    return s.filter((c) => !!c).length === 0 && (s = [i]), s.reduce((c, f) => {
      if (f)
        if (_n(c)) {
          const p = f(c, u);
          return p === void 0 ? c : p;
        } else {
          if (Mr(c))
            return aA(c, (v) => f(v, u));
          {
            const v = f(c, u);
            if (v === void 0) {
              if (c === null)
                return c;
              throw Error("A case reducer on a non-draftable value must not return undefined");
            }
            return v;
          }
        }
      return c;
    }, l);
  }
  return o.getInitialState = a, o;
}
var pN = "ModuleSymbhasOwnPr-0123456789ABCDEFGHNRVfgctiUvz_KqYTJkLxpZXIjQW", hN = (e = 21) => {
  let t = "", r = e;
  for (; r--; )
    t += pN[Math.random() * 64 | 0];
  return t;
}, mN = /* @__PURE__ */ Symbol.for("rtk-slice-createasyncthunk");
function yN(e, t) {
  return `${e}/${t}`;
}
function gN({
  creators: e
} = {}) {
  var r;
  const t = (r = e == null ? void 0 : e.asyncThunk) == null ? void 0 : r[mN];
  return function(i) {
    const {
      name: a,
      reducerPath: o = a
    } = i;
    if (!a)
      throw new Error(Qt(11));
    const l = (typeof i.reducers == "function" ? i.reducers(xN()) : i.reducers) || {}, u = Object.keys(l), s = {
      sliceCaseReducersByName: {},
      sliceCaseReducersByType: {},
      actionCreators: {},
      sliceMatchers: []
    }, c = {
      addCase(w, P) {
        const O = typeof w == "string" ? w : w.type;
        if (!O)
          throw new Error(Qt(12));
        if (O in s.sliceCaseReducersByType)
          throw new Error(Qt(13));
        return s.sliceCaseReducersByType[O] = P, c;
      },
      addMatcher(w, P) {
        return s.sliceMatchers.push({
          matcher: w,
          reducer: P
        }), c;
      },
      exposeAction(w, P) {
        return s.actionCreators[w] = P, c;
      },
      exposeCaseReducer(w, P) {
        return s.sliceCaseReducersByName[w] = P, c;
      }
    };
    u.forEach((w) => {
      const P = l[w], O = {
        reducerName: w,
        type: yN(a, w),
        createNotation: typeof i.reducers == "function"
      };
      PN(P) ? SN(O, P, c, t) : wN(O, P, c);
    });
    function f() {
      const [w = {}, P = [], O = void 0] = typeof i.extraReducers == "function" ? cA(i.extraReducers) : [i.extraReducers], S = {
        ...w,
        ...s.sliceCaseReducersByType
      };
      return vN(i.initialState, (E) => {
        for (let k in S)
          E.addCase(k, S[k]);
        for (let k of s.sliceMatchers)
          E.addMatcher(k.matcher, k.reducer);
        for (let k of P)
          E.addMatcher(k.matcher, k.reducer);
        O && E.addDefaultCase(O);
      });
    }
    const v = (w) => w, p = /* @__PURE__ */ new Map(), h = /* @__PURE__ */ new WeakMap();
    let y;
    function g(w, P) {
      return y || (y = f()), y(w, P);
    }
    function m() {
      return y || (y = f()), y.getInitialState();
    }
    function b(w, P = !1) {
      function O(E) {
        let k = E[w];
        return typeof k > "u" && P && (k = gs(h, O, m)), k;
      }
      function S(E = v) {
        const k = gs(p, P, () => /* @__PURE__ */ new WeakMap());
        return gs(k, E, () => {
          const _ = {};
          for (const [I, j] of Object.entries(i.selectors ?? {}))
            _[I] = bN(j, E, () => gs(h, E, m), P);
          return _;
        });
      }
      return {
        reducerPath: w,
        getSelectors: S,
        get selectors() {
          return S(O);
        },
        selectSlice: O
      };
    }
    const x = {
      name: a,
      reducer: g,
      actions: s.actionCreators,
      caseReducers: s.sliceCaseReducersByName,
      getInitialState: m,
      ...b(o),
      injectInto(w, {
        reducerPath: P,
        ...O
      } = {}) {
        const S = P ?? o;
        return w.inject({
          reducerPath: S,
          reducer: g
        }, O), {
          ...x,
          ...b(S, !0)
        };
      }
    };
    return x;
  };
}
function bN(e, t, r, n) {
  function i(a, ...o) {
    let l = t(a);
    return typeof l > "u" && n && (l = r()), e(l, ...o);
  }
  return i.unwrapped = e, i;
}
var Ut = /* @__PURE__ */ gN();
function xN() {
  function e(t, r) {
    return {
      _reducerDefinitionType: "asyncThunk",
      payloadCreator: t,
      ...r
    };
  }
  return e.withTypes = () => e, {
    reducer(t) {
      return Object.assign({
        // hack so the wrapping function has the same name as the original
        // we need to create a wrapper so the `reducerDefinitionType` is not assigned to the original
        [t.name](...r) {
          return t(...r);
        }
      }[t.name], {
        _reducerDefinitionType: "reducer"
        /* reducer */
      });
    },
    preparedReducer(t, r) {
      return {
        _reducerDefinitionType: "reducerWithPrepare",
        prepare: t,
        reducer: r
      };
    },
    asyncThunk: e
  };
}
function wN({
  type: e,
  reducerName: t,
  createNotation: r
}, n, i) {
  let a, o;
  if ("reducer" in n) {
    if (r && !ON(n))
      throw new Error(Qt(17));
    a = n.reducer, o = n.prepare;
  } else
    a = n;
  i.addCase(e, a).exposeCaseReducer(t, a).exposeAction(t, o ? mr(e, o) : mr(e));
}
function PN(e) {
  return e._reducerDefinitionType === "asyncThunk";
}
function ON(e) {
  return e._reducerDefinitionType === "reducerWithPrepare";
}
function SN({
  type: e,
  reducerName: t
}, r, n, i) {
  if (!i)
    throw new Error(Qt(18));
  const {
    payloadCreator: a,
    fulfilled: o,
    pending: l,
    rejected: u,
    settled: s,
    options: c
  } = r, f = i(e, a, c);
  n.exposeAction(t, f), o && n.addCase(f.fulfilled, o), l && n.addCase(f.pending, l), u && n.addCase(f.rejected, u), s && n.addMatcher(f.settled, s), n.exposeCaseReducer(t, {
    fulfilled: o || bs,
    pending: l || bs,
    rejected: u || bs,
    settled: s || bs
  });
}
function bs() {
}
var EN = "task", fA = "listener", dA = "completed", xy = "cancelled", AN = `task-${xy}`, kN = `task-${dA}`, oh = `${fA}-${xy}`, _N = `${fA}-${dA}`, id = class {
  constructor(e) {
    Qd(this, "name", "TaskAbortError");
    Qd(this, "message");
    this.code = e, this.message = `${EN} ${xy} (reason: ${e})`;
  }
}, wy = (e, t) => {
  if (typeof e != "function")
    throw new TypeError(Qt(32));
}, $c = () => {
}, vA = (e, t = $c) => (e.catch(t), e), pA = (e, t) => (e.addEventListener("abort", t, {
  once: !0
}), () => e.removeEventListener("abort", t)), Li = (e) => {
  if (e.aborted)
    throw new id(e.reason);
};
function hA(e, t) {
  let r = $c;
  return new Promise((n, i) => {
    const a = () => i(new id(e.reason));
    if (e.aborted) {
      a();
      return;
    }
    r = pA(e, a), t.finally(() => r()).then(n, i);
  }).finally(() => {
    r = $c;
  });
}
var IN = async (e, t) => {
  try {
    return await Promise.resolve(), {
      status: "ok",
      value: await e()
    };
  } catch (r) {
    return {
      status: r instanceof id ? "cancelled" : "rejected",
      error: r
    };
  } finally {
    t == null || t();
  }
}, Lc = (e) => (t) => vA(hA(e, t).then((r) => (Li(e), r))), mA = (e) => {
  const t = Lc(e);
  return (r) => t(new Promise((n) => setTimeout(n, r)));
}, {
  assign: Ra
} = Object, Wb = {}, ad = "listenerMiddleware", jN = (e, t) => {
  const r = (n) => pA(e, () => n.abort(e.reason));
  return (n, i) => {
    wy(n);
    const a = new AbortController();
    r(a);
    const o = IN(async () => {
      Li(e), Li(a.signal);
      const l = await n({
        pause: Lc(a.signal),
        delay: mA(a.signal),
        signal: a.signal
      });
      return Li(a.signal), l;
    }, () => a.abort(kN));
    return i != null && i.autoJoin && t.push(o.catch($c)), {
      result: Lc(e)(o),
      cancel() {
        a.abort(AN);
      }
    };
  };
}, CN = (e, t) => {
  const r = async (n, i) => {
    Li(t);
    let a = () => {
    };
    const l = [new Promise((u, s) => {
      let c = e({
        predicate: n,
        effect: (f, v) => {
          v.unsubscribe(), u([f, v.getState(), v.getOriginalState()]);
        }
      });
      a = () => {
        c(), s();
      };
    })];
    i != null && l.push(new Promise((u) => setTimeout(u, i, null)));
    try {
      const u = await hA(t, Promise.race(l));
      return Li(t), u;
    } finally {
      a();
    }
  };
  return (n, i) => vA(r(n, i));
}, yA = (e) => {
  let {
    type: t,
    actionCreator: r,
    matcher: n,
    predicate: i,
    effect: a
  } = e;
  if (t)
    i = mr(t).match;
  else if (r)
    t = r.type, i = r.match;
  else if (n)
    i = n;
  else if (!i) throw new Error(Qt(21));
  return wy(a), {
    predicate: i,
    type: t,
    effect: a
  };
}, gA = /* @__PURE__ */ Ra((e) => {
  const {
    type: t,
    predicate: r,
    effect: n
  } = yA(e);
  return {
    id: hN(),
    effect: n,
    type: t,
    predicate: r,
    pending: /* @__PURE__ */ new Set(),
    unsubscribe: () => {
      throw new Error(Qt(22));
    }
  };
}, {
  withTypes: () => gA
}), Ub = (e, t) => {
  const {
    type: r,
    effect: n,
    predicate: i
  } = yA(t);
  return Array.from(e.values()).find((a) => (typeof r == "string" ? a.type === r : a.predicate === i) && a.effect === n);
}, lh = (e) => {
  e.pending.forEach((t) => {
    t.abort(oh);
  });
}, TN = (e, t) => () => {
  for (const r of t.keys())
    lh(r);
  e.clear();
}, Vb = (e, t, r) => {
  try {
    e(t, r);
  } catch (n) {
    setTimeout(() => {
      throw n;
    }, 0);
  }
}, bA = /* @__PURE__ */ Ra(/* @__PURE__ */ mr(`${ad}/add`), {
  withTypes: () => bA
}), MN = /* @__PURE__ */ mr(`${ad}/removeAll`), xA = /* @__PURE__ */ Ra(/* @__PURE__ */ mr(`${ad}/remove`), {
  withTypes: () => xA
}), DN = (...e) => {
  console.error(`${ad}/error`, ...e);
}, hu = (e = {}) => {
  const t = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map(), n = (p) => {
    const h = r.get(p) ?? 0;
    r.set(p, h + 1);
  }, i = (p) => {
    const h = r.get(p) ?? 1;
    h === 1 ? r.delete(p) : r.set(p, h - 1);
  }, {
    extra: a,
    onError: o = DN
  } = e;
  wy(o);
  const l = (p) => (p.unsubscribe = () => t.delete(p.id), t.set(p.id, p), (h) => {
    p.unsubscribe(), h != null && h.cancelActive && lh(p);
  }), u = (p) => {
    const h = Ub(t, p) ?? gA(p);
    return l(h);
  };
  Ra(u, {
    withTypes: () => u
  });
  const s = (p) => {
    const h = Ub(t, p);
    return h && (h.unsubscribe(), p.cancelActive && lh(h)), !!h;
  };
  Ra(s, {
    withTypes: () => s
  });
  const c = async (p, h, y, g) => {
    const m = new AbortController(), b = CN(u, m.signal), x = [];
    try {
      p.pending.add(m), n(p), await Promise.resolve(p.effect(
        h,
        // Use assign() rather than ... to avoid extra helper functions added to bundle
        Ra({}, y, {
          getOriginalState: g,
          condition: (w, P) => b(w, P).then(Boolean),
          take: b,
          delay: mA(m.signal),
          pause: Lc(m.signal),
          extra: a,
          signal: m.signal,
          fork: jN(m.signal, x),
          unsubscribe: p.unsubscribe,
          subscribe: () => {
            t.set(p.id, p);
          },
          cancelActiveListeners: () => {
            p.pending.forEach((w, P, O) => {
              w !== m && (w.abort(oh), O.delete(w));
            });
          },
          cancel: () => {
            m.abort(oh), p.pending.delete(m);
          },
          throwIfCancelled: () => {
            Li(m.signal);
          }
        })
      ));
    } catch (w) {
      w instanceof id || Vb(o, w, {
        raisedBy: "effect"
      });
    } finally {
      await Promise.all(x), m.abort(_N), i(p), p.pending.delete(m);
    }
  }, f = TN(t, r);
  return {
    middleware: (p) => (h) => (y) => {
      if (!GE(y))
        return h(y);
      if (bA.match(y))
        return u(y.payload);
      if (MN.match(y)) {
        f();
        return;
      }
      if (xA.match(y))
        return s(y.payload);
      let g = p.getState();
      const m = () => {
        if (g === Wb)
          throw new Error(Qt(23));
        return g;
      };
      let b;
      try {
        if (b = h(y), t.size > 0) {
          const x = p.getState(), w = Array.from(t.values());
          for (const P of w) {
            let O = !1;
            try {
              O = P.predicate(y, x, g);
            } catch (S) {
              O = !1, Vb(o, S, {
                raisedBy: "predicate"
              });
            }
            O && c(P, y, p, m);
          }
        }
      } finally {
        g = Wb;
      }
      return b;
    },
    startListening: u,
    stopListening: s,
    clearListeners: f
  };
};
function Qt(e) {
  return `Minified Redux Toolkit error #${e}; visit https://redux-toolkit.js.org/Errors?code=${e} for the full message or use the non-minified dev environment for full errors. `;
}
var NN = {
  layoutType: "horizontal",
  width: 0,
  height: 0,
  margin: {
    top: 5,
    right: 5,
    bottom: 5,
    left: 5
  },
  scale: 1
}, wA = Ut({
  name: "chartLayout",
  initialState: NN,
  reducers: {
    setLayout(e, t) {
      e.layoutType = t.payload;
    },
    setChartSize(e, t) {
      e.width = t.payload.width, e.height = t.payload.height;
    },
    setMargin(e, t) {
      var r, n, i, a;
      e.margin.top = (r = t.payload.top) !== null && r !== void 0 ? r : 0, e.margin.right = (n = t.payload.right) !== null && n !== void 0 ? n : 0, e.margin.bottom = (i = t.payload.bottom) !== null && i !== void 0 ? i : 0, e.margin.left = (a = t.payload.left) !== null && a !== void 0 ? a : 0;
    },
    setScale(e, t) {
      e.scale = t.payload;
    }
  }
}), {
  setMargin: PA,
  setLayout: $N,
  setChartSize: LN,
  setScale: RN
} = wA.actions, zN = wA.reducer;
function OA(e, t, r) {
  return Array.isArray(e) && e && t + r !== 0 ? e.slice(t, r + 1) : e;
}
function se(e) {
  return Number.isFinite(e);
}
function Bt(e) {
  return typeof e == "number" && e > 0 && Number.isFinite(e);
}
function Hb(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function _a(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Hb(Object(r), !0).forEach(function(n) {
      BN(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Hb(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function BN(e, t, r) {
  return (t = FN(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function FN(e) {
  var t = KN(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function KN(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function G(e, t, r) {
  return oe(e) || oe(t) ? r : it(t) ? Gr(e, t, r) : typeof t == "function" ? t(e) : r;
}
var WN = (e, t, r) => {
  if (t && r) {
    var {
      width: n,
      height: i
    } = r, {
      align: a,
      verticalAlign: o,
      layout: l
    } = t;
    if ((l === "vertical" || l === "horizontal" && o === "middle") && a !== "center" && B(e[a]))
      return _a(_a({}, e), {}, {
        [a]: e[a] + (n || 0)
      });
    if ((l === "horizontal" || l === "vertical" && a === "center") && o !== "middle" && B(e[o]))
      return _a(_a({}, e), {}, {
        [o]: e[o] + (i || 0)
      });
  }
  return e;
}, br = (e, t) => e === "horizontal" && t === "xAxis" || e === "vertical" && t === "yAxis" || e === "centric" && t === "angleAxis" || e === "radial" && t === "radiusAxis", SA = (e, t, r, n) => {
  if (n)
    return e.map((l) => l.coordinate);
  var i, a, o = e.map((l) => (l.coordinate === t && (i = !0), l.coordinate === r && (a = !0), l.coordinate));
  return i || o.push(t), a || o.push(r), o;
}, EA = (e, t, r) => {
  if (!e)
    return null;
  var {
    duplicateDomain: n,
    type: i,
    range: a,
    scale: o,
    realScaleType: l,
    isCategorical: u,
    categoricalDomain: s,
    tickCount: c,
    ticks: f,
    niceTicks: v,
    axisType: p
  } = e;
  if (!o)
    return null;
  var h = l === "scaleBand" && o.bandwidth ? o.bandwidth() / 2 : 2, y = i === "category" && o.bandwidth ? o.bandwidth() / h : 0;
  if (y = p === "angleAxis" && a && a.length >= 2 ? We(a[0] - a[1]) * 2 * y : y, f || v) {
    var g = (f || v || []).map((m, b) => {
      var x = n ? n.indexOf(m) : m;
      return {
        // If the scaleContent is not a number, the coordinate will be NaN.
        // That could be the case for example with a PointScale and a string as domain.
        coordinate: o(x) + y,
        value: m,
        offset: y,
        index: b
      };
    });
    return g.filter((m) => !Pt(m.coordinate));
  }
  return u && s ? s.map((m, b) => ({
    coordinate: o(m) + y,
    value: m,
    index: b,
    offset: y
  })) : o.ticks && c != null ? o.ticks(c).map((m, b) => ({
    coordinate: o(m) + y,
    value: m,
    offset: y,
    index: b
  })) : o.domain().map((m, b) => ({
    coordinate: o(m) + y,
    value: n ? n[m] : m,
    index: b,
    offset: y
  }));
}, Xb = 1e-4, UN = (e) => {
  var t = e.domain();
  if (!(!t || t.length <= 2)) {
    var r = t.length, n = e.range(), i = Math.min(n[0], n[1]) - Xb, a = Math.max(n[0], n[1]) + Xb, o = e(t[0]), l = e(t[r - 1]);
    (o < i || o > a || l < i || l > a) && e.domain([t[0], t[r - 1]]);
  }
}, AA = (e, t) => {
  if (!t || t.length !== 2 || !B(t[0]) || !B(t[1]))
    return e;
  var r = Math.min(t[0], t[1]), n = Math.max(t[0], t[1]), i = [e[0], e[1]];
  return (!B(e[0]) || e[0] < r) && (i[0] = r), (!B(e[1]) || e[1] > n) && (i[1] = n), i[0] > n && (i[0] = n), i[1] < r && (i[1] = r), i;
}, VN = (e) => {
  var t, r = e.length;
  if (!(r <= 0)) {
    var n = (t = e[0]) === null || t === void 0 ? void 0 : t.length;
    if (!(n == null || n <= 0))
      for (var i = 0; i < n; ++i)
        for (var a = 0, o = 0, l = 0; l < r; ++l) {
          var u = e[l], s = u == null ? void 0 : u[i];
          if (s != null) {
            var c = s[1], f = s[0], v = Pt(c) ? f : c;
            v >= 0 ? (s[0] = a, s[1] = a + v, a = c) : (s[0] = o, s[1] = o + v, o = c);
          }
        }
  }
}, HN = (e) => {
  var t, r = e.length;
  if (!(r <= 0)) {
    var n = (t = e[0]) === null || t === void 0 ? void 0 : t.length;
    if (!(n == null || n <= 0))
      for (var i = 0; i < n; ++i)
        for (var a = 0, o = 0; o < r; ++o) {
          var l = e[o], u = l == null ? void 0 : l[i];
          if (u != null) {
            var s = Pt(u[1]) ? u[0] : u[1];
            s >= 0 ? (u[0] = a, u[1] = a + s, a = u[1]) : (u[0] = 0, u[1] = 0);
          }
        }
  }
}, XN = {
  sign: VN,
  // @ts-expect-error definitelytyped types are incorrect
  expand: AD,
  // @ts-expect-error definitelytyped types are incorrect
  none: Xi,
  // @ts-expect-error definitelytyped types are incorrect
  silhouette: kD,
  // @ts-expect-error definitelytyped types are incorrect
  wiggle: _D,
  positive: HN
}, YN = (e, t, r) => {
  var n, i = (n = XN[r]) !== null && n !== void 0 ? n : Xi, a = ED().keys(t).value((l, u) => Number(G(l, u, 0))).order(qp).offset(i), o = a(e);
  return o.forEach((l, u) => {
    l.forEach((s, c) => {
      var f = G(e[c], t[u], 0);
      Array.isArray(f) && f.length === 2 && B(f[0]) && B(f[1]) && (s[0] = f[0], s[1] = f[1]);
    });
  }), o;
};
function od(e) {
  return e == null ? void 0 : String(e);
}
function Za(e) {
  var {
    axis: t,
    ticks: r,
    bandSize: n,
    entry: i,
    index: a,
    dataKey: o
  } = e;
  if (t.type === "category") {
    if (!t.allowDuplicatedCategory && t.dataKey && !oe(i[t.dataKey])) {
      var l = gE(r, "value", i[t.dataKey]);
      if (l)
        return l.coordinate + n / 2;
    }
    return r[a] ? r[a].coordinate + n / 2 : null;
  }
  var u = G(i, oe(o) ? t.dataKey : o);
  return oe(u) ? null : t.scale(u);
}
var Rc = (e) => {
  var {
    axis: t,
    ticks: r,
    offset: n,
    bandSize: i,
    entry: a,
    index: o
  } = e;
  if (t.type === "category")
    return r[o] ? r[o].coordinate + n : null;
  var l = G(a, t.dataKey, t.scale.domain()[o]);
  return oe(l) ? null : t.scale(l) - i / 2 + n;
}, kA = (e) => {
  var {
    numericAxis: t
  } = e, r = t.scale.domain();
  if (t.type === "number") {
    var n = Math.min(r[0], r[1]), i = Math.max(r[0], r[1]);
    return n <= 0 && i >= 0 ? 0 : i < 0 ? i : n;
  }
  return r[0];
}, GN = (e) => {
  var t = e.flat(2).filter(B);
  return [Math.min(...t), Math.max(...t)];
}, qN = (e) => [e[0] === 1 / 0 ? 0 : e[0], e[1] === -1 / 0 ? 0 : e[1]], ZN = (e, t, r) => {
  if (e != null)
    return qN(Object.keys(e).reduce((n, i) => {
      var a = e[i];
      if (!a)
        return n;
      var {
        stackedData: o
      } = a, l = o.reduce((u, s) => {
        var c = OA(s, t, r), f = GN(c);
        return !se(f[0]) || !se(f[1]) ? u : [Math.min(u[0], f[0]), Math.max(u[1], f[1])];
      }, [1 / 0, -1 / 0]);
      return [Math.min(l[0], n[0]), Math.max(l[1], n[1])];
    }, [1 / 0, -1 / 0]));
}, Yb = /^dataMin[\s]*-[\s]*([0-9]+([.]{1}[0-9]+){0,1})$/, Gb = /^dataMax[\s]*\+[\s]*([0-9]+([.]{1}[0-9]+){0,1})$/, Ft = (e, t, r) => {
  if (e && e.scale && e.scale.bandwidth) {
    var n = e.scale.bandwidth();
    if (!r || n > 0)
      return n;
  }
  if (e && t && t.length >= 2) {
    for (var i = qf(t, (c) => c.coordinate), a = 1 / 0, o = 1, l = i.length; o < l; o++) {
      var u = i[o], s = i[o - 1];
      a = Math.min(((u == null ? void 0 : u.coordinate) || 0) - ((s == null ? void 0 : s.coordinate) || 0), a);
    }
    return a === 1 / 0 ? 0 : a;
  }
  return r ? void 0 : 0;
};
function qb(e) {
  var {
    tooltipEntrySettings: t,
    dataKey: r,
    payload: n,
    value: i,
    name: a
  } = e;
  return _a(_a({}, t), {}, {
    dataKey: r,
    payload: n,
    value: i,
    name: a
  });
}
function ir(e, t) {
  if (e)
    return String(e);
  if (typeof t == "string")
    return t;
}
var QN = (e, t) => {
  if (t === "horizontal")
    return e.chartX;
  if (t === "vertical")
    return e.chartY;
}, JN = (e, t) => t === "centric" ? e.angle : e.radius, Nn = (e) => e.layout.width, $n = (e) => e.layout.height, e$ = (e) => e.layout.scale, _A = (e) => e.layout.margin, ld = A((e) => e.cartesianAxis.xAxis, (e) => Object.values(e)), ud = A((e) => e.cartesianAxis.yAxis, (e) => Object.values(e)), t$ = ["#1890FF", "#66B5FF", "#41D9C7", "#2FC25B", "#6EDB8F", "#9AE65C", "#FACC14", "#E6965C", "#57AD71", "#223273", "#738AE6", "#7564CC", "#8543E0", "#A877ED", "#5C8EE6", "#13C2C2", "#70E0E0", "#5CA3E6", "#3436C7", "#8082FF", "#DD81E6", "#F04864", "#FA7D92", "#D598D9"], Py = "data-recharts-item-index", Oy = "data-recharts-item-id", mu = 60;
function Zb(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function xs(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Zb(Object(r), !0).forEach(function(n) {
      r$(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Zb(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function r$(e, t, r) {
  return (t = n$(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function n$(e) {
  var t = i$(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function i$(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var a$ = (e) => e.brush.height;
function o$(e) {
  var t = ud(e);
  return t.reduce((r, n) => {
    if (n.orientation === "left" && !n.mirror && !n.hide) {
      var i = typeof n.width == "number" ? n.width : mu;
      return r + i;
    }
    return r;
  }, 0);
}
function l$(e) {
  var t = ud(e);
  return t.reduce((r, n) => {
    if (n.orientation === "right" && !n.mirror && !n.hide) {
      var i = typeof n.width == "number" ? n.width : mu;
      return r + i;
    }
    return r;
  }, 0);
}
function u$(e) {
  var t = ld(e);
  return t.reduce((r, n) => n.orientation === "top" && !n.mirror && !n.hide ? r + n.height : r, 0);
}
function s$(e) {
  var t = ld(e);
  return t.reduce((r, n) => n.orientation === "bottom" && !n.mirror && !n.hide ? r + n.height : r, 0);
}
var Ve = A([Nn, $n, _A, a$, o$, l$, u$, s$, VE, L2], (e, t, r, n, i, a, o, l, u, s) => {
  var c = {
    left: (r.left || 0) + i,
    right: (r.right || 0) + a
  }, f = {
    top: (r.top || 0) + o,
    bottom: (r.bottom || 0) + l
  }, v = xs(xs({}, f), c), p = v.bottom;
  v.bottom += n, v = WN(v, u, s);
  var h = e - v.left - v.right, y = t - v.top - v.bottom;
  return xs(xs({
    brushBottom: p
  }, v), {}, {
    // never return negative values for height and width
    width: Math.max(h, 0),
    height: Math.max(y, 0)
  });
}), c$ = A(Ve, (e) => ({
  x: e.left,
  y: e.top,
  width: e.width,
  height: e.height
})), Sy = A(Nn, $n, (e, t) => ({
  x: 0,
  y: 0,
  width: e,
  height: t
})), IA = /* @__PURE__ */ d.createContext(null), me = () => d.useContext(IA) != null, f$ = (e) => {
  var {
    children: t
  } = e;
  return /* @__PURE__ */ d.createElement(IA.Provider, {
    value: !0
  }, t);
}, sd = (e) => e.brush, yu = A([sd, Ve, _A], (e, t, r) => ({
  height: e.height,
  x: B(e.x) ? e.x : t.left,
  y: B(e.y) ? e.y : t.top + t.height + t.brushBottom - ((r == null ? void 0 : r.bottom) || 0),
  width: B(e.width) ? e.width : t.width
})), jA = {}, CA = {}, TA = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r, n, { signal: i, edges: a } = {}) {
    let o, l = null;
    const u = a != null && a.includes("leading"), s = a == null || a.includes("trailing"), c = () => {
      l !== null && (r.apply(o, l), o = void 0, l = null);
    }, f = () => {
      s && c(), y();
    };
    let v = null;
    const p = () => {
      v != null && clearTimeout(v), v = setTimeout(() => {
        v = null, f();
      }, n);
    }, h = () => {
      v !== null && (clearTimeout(v), v = null);
    }, y = () => {
      h(), o = void 0, l = null;
    }, g = () => {
      c();
    }, m = function(...b) {
      if (i != null && i.aborted)
        return;
      o = this, l = b;
      const x = v == null;
      p(), u && x && c();
    };
    return m.schedule = p, m.cancel = y, m.flush = g, i == null || i.addEventListener("abort", y, { once: !0 }), m;
  }
  e.debounce = t;
})(TA);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = TA;
  function r(n, i = 0, a = {}) {
    typeof a != "object" && (a = {});
    const { leading: o = !1, trailing: l = !0, maxWait: u } = a, s = Array(2);
    o && (s[0] = "leading"), l && (s[1] = "trailing");
    let c, f = null;
    const v = t.debounce(function(...y) {
      c = n.apply(this, y), f = null;
    }, i, { edges: s }), p = function(...y) {
      return u != null && (f === null && (f = Date.now()), Date.now() - f >= u) ? (c = n.apply(this, y), f = Date.now(), v.cancel(), v.schedule(), c) : (v.apply(this, y), c);
    }, h = () => (v.flush(), c);
    return p.cancel = v.cancel, p.flush = h, p;
  }
  e.debounce = r;
})(CA);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = CA;
  function r(n, i = 0, a = {}) {
    const { leading: o = !0, trailing: l = !0 } = a;
    return t.debounce(n, i, {
      leading: o,
      maxWait: i,
      trailing: l
    });
  }
  e.throttle = r;
})(jA);
var d$ = jA.throttle;
const v$ = /* @__PURE__ */ Wt(d$);
var zc = function(t, r) {
  for (var n = arguments.length, i = new Array(n > 2 ? n - 2 : 0), a = 2; a < n; a++)
    i[a - 2] = arguments[a];
  if (typeof console < "u" && console.warn && (r === void 0 && console.warn("LogUtils requires an error message argument"), !t))
    if (r === void 0)
      console.warn("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
    else {
      var o = 0;
      console.warn(r.replace(/%s/g, () => i[o++]));
    }
}, MA = (e, t, r) => {
  var {
    width: n = "100%",
    height: i = "100%",
    aspect: a,
    maxHeight: o
  } = r, l = kn(n) ? e : Number(n), u = kn(i) ? t : Number(i);
  return a && a > 0 && (l ? u = l / a : u && (l = u * a), o && u != null && u > o && (u = o)), {
    calculatedWidth: l,
    calculatedHeight: u
  };
}, p$ = {
  width: 0,
  height: 0,
  overflow: "visible"
}, h$ = {
  width: 0,
  overflowX: "visible"
}, m$ = {
  height: 0,
  overflowY: "visible"
}, y$ = {}, g$ = (e) => {
  var {
    width: t,
    height: r
  } = e, n = kn(t), i = kn(r);
  return n && i ? p$ : n ? h$ : i ? m$ : y$;
};
function b$(e) {
  var {
    width: t,
    height: r,
    aspect: n
  } = e, i = t, a = r;
  return i === void 0 && a === void 0 ? (i = "100%", a = "100%") : i === void 0 ? i = n && n > 0 ? void 0 : "100%" : a === void 0 && (a = n && n > 0 ? void 0 : "100%"), {
    width: i,
    height: a
  };
}
function uh() {
  return uh = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, uh.apply(null, arguments);
}
function Qb(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Jb(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Qb(Object(r), !0).forEach(function(n) {
      x$(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Qb(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function x$(e, t, r) {
  return (t = w$(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function w$(e) {
  var t = P$(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function P$(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var DA = /* @__PURE__ */ d.createContext({
  width: -1,
  height: -1
});
function O$(e) {
  return Bt(e.width) && Bt(e.height);
}
function NA(e) {
  var {
    children: t,
    width: r,
    height: n
  } = e, i = d.useMemo(() => ({
    width: r,
    height: n
  }), [r, n]);
  return O$(i) ? /* @__PURE__ */ d.createElement(DA.Provider, {
    value: i
  }, t) : null;
}
var Ey = () => d.useContext(DA), S$ = /* @__PURE__ */ d.forwardRef((e, t) => {
  var {
    aspect: r,
    initialDimension: n = {
      width: -1,
      height: -1
    },
    width: i,
    height: a,
    /*
     * default min-width to 0 if not specified - 'auto' causes issues with flexbox
     * https://github.com/recharts/recharts/issues/172
     */
    minWidth: o = 0,
    minHeight: l,
    maxHeight: u,
    children: s,
    debounce: c = 0,
    id: f,
    className: v,
    onResize: p,
    style: h = {}
  } = e, y = d.useRef(null), g = d.useRef();
  g.current = p, d.useImperativeHandle(t, () => y.current);
  var [m, b] = d.useState({
    containerWidth: n.width,
    containerHeight: n.height
  }), x = d.useCallback((E, k) => {
    b((_) => {
      var I = Math.round(E), j = Math.round(k);
      return _.containerWidth === I && _.containerHeight === j ? _ : {
        containerWidth: I,
        containerHeight: j
      };
    });
  }, []);
  d.useEffect(() => {
    if (y.current == null || typeof ResizeObserver > "u")
      return co;
    var E = (j) => {
      var z, {
        width: N,
        height: R
      } = j[0].contentRect;
      x(N, R), (z = g.current) === null || z === void 0 || z.call(g, N, R);
    };
    c > 0 && (E = v$(E, c, {
      trailing: !0,
      leading: !1
    }));
    var k = new ResizeObserver(E), {
      width: _,
      height: I
    } = y.current.getBoundingClientRect();
    return x(_, I), k.observe(y.current), () => {
      k.disconnect();
    };
  }, [x, c]);
  var {
    containerWidth: w,
    containerHeight: P
  } = m;
  zc(!r || r > 0, "The aspect(%s) must be greater than zero.", r);
  var {
    calculatedWidth: O,
    calculatedHeight: S
  } = MA(w, P, {
    width: i,
    height: a,
    aspect: r,
    maxHeight: u
  });
  return zc(O != null && O > 0 || S != null && S > 0, `The width(%s) and height(%s) of chart should be greater than 0,
       please check the style of container, or the props width(%s) and height(%s),
       or add a minWidth(%s) or minHeight(%s) or use aspect(%s) to control the
       height and width.`, O, S, i, a, o, l, r), /* @__PURE__ */ d.createElement("div", {
    id: f ? "".concat(f) : void 0,
    className: Y("recharts-responsive-container", v),
    style: Jb(Jb({}, h), {}, {
      width: i,
      height: a,
      minWidth: o,
      minHeight: l,
      maxHeight: u
    }),
    ref: y
  }, /* @__PURE__ */ d.createElement("div", {
    style: g$({
      width: i,
      height: a
    })
  }, /* @__PURE__ */ d.createElement(NA, {
    width: O,
    height: S
  }, s)));
}), wZ = /* @__PURE__ */ d.forwardRef((e, t) => {
  var r = Ey();
  if (Bt(r.width) && Bt(r.height))
    return e.children;
  var {
    width: n,
    height: i
  } = b$({
    width: e.width,
    height: e.height,
    aspect: e.aspect
  }), {
    calculatedWidth: a,
    calculatedHeight: o
  } = MA(void 0, void 0, {
    width: n,
    height: i,
    aspect: e.aspect,
    maxHeight: e.maxHeight
  });
  return B(a) && B(o) ? /* @__PURE__ */ d.createElement(NA, {
    width: a,
    height: o
  }, e.children) : /* @__PURE__ */ d.createElement(S$, uh({}, e, {
    width: n,
    height: i,
    ref: t
  }));
});
function $A(e) {
  if (e)
    return {
      x: e.x,
      y: e.y,
      upperWidth: "upperWidth" in e ? e.upperWidth : e.width,
      lowerWidth: "lowerWidth" in e ? e.lowerWidth : e.width,
      width: e.width,
      height: e.height
    };
}
var vo = () => {
  var e, t = me(), r = T(c$), n = T(yu), i = (e = T(sd)) === null || e === void 0 ? void 0 : e.padding;
  return !t || !n || !i ? r : {
    width: n.width - i.left - i.right,
    height: n.height - i.top - i.bottom,
    x: i.left,
    y: i.top
  };
}, E$ = {
  top: 0,
  bottom: 0,
  left: 0,
  right: 0,
  width: 0,
  height: 0,
  brushBottom: 0
}, LA = () => {
  var e;
  return (e = T(Ve)) !== null && e !== void 0 ? e : E$;
}, gu = () => T(Nn), bu = () => T($n), A$ = () => T((e) => e.layout.margin), q = (e) => e.layout.layoutType, Ln = () => T(q), k$ = () => {
  var e = Ln();
  if (e === "horizontal" || e === "vertical")
    return e;
}, _$ = () => {
  var e = Ln();
  return e !== void 0;
}, xu = (e) => {
  var t = J(), r = me(), {
    width: n,
    height: i
  } = e, a = Ey(), o = n, l = i;
  return a && (o = a.width > 0 ? a.width : n, l = a.height > 0 ? a.height : i), d.useEffect(() => {
    !r && Bt(o) && Bt(l) && t(LN({
      width: o,
      height: l
    }));
  }, [t, r, o, l]), null;
}, RA = (e) => {
  var {
    margin: t
  } = e, r = J();
  return d.useEffect(() => {
    r(PA(t));
  }, [r, t]), null;
}, zA = Symbol.for("immer-nothing"), ex = Symbol.for("immer-draftable"), tr = Symbol.for("immer-state");
function Ar(e, ...t) {
  throw new Error(
    `[Immer] minified error nr: ${e}. Full error at: https://bit.ly/3cXEKWf`
  );
}
var Ll = Object.getPrototypeOf;
function Qa(e) {
  return !!e && !!e[tr];
}
function Gi(e) {
  var t;
  return e ? BA(e) || Array.isArray(e) || !!e[ex] || !!((t = e.constructor) != null && t[ex]) || wu(e) || fd(e) : !1;
}
var I$ = Object.prototype.constructor.toString(), tx = /* @__PURE__ */ new WeakMap();
function BA(e) {
  if (!e || typeof e != "object")
    return !1;
  const t = Object.getPrototypeOf(e);
  if (t === null || t === Object.prototype)
    return !0;
  const r = Object.hasOwnProperty.call(t, "constructor") && t.constructor;
  if (r === Object)
    return !0;
  if (typeof r != "function")
    return !1;
  let n = tx.get(r);
  return n === void 0 && (n = Function.toString.call(r), tx.set(r, n)), n === I$;
}
function Bc(e, t, r = !0) {
  cd(e) === 0 ? (r ? Reflect.ownKeys(e) : Object.keys(e)).forEach((i) => {
    t(i, e[i], e);
  }) : e.forEach((n, i) => t(i, n, e));
}
function cd(e) {
  const t = e[tr];
  return t ? t.type_ : Array.isArray(e) ? 1 : wu(e) ? 2 : fd(e) ? 3 : 0;
}
function sh(e, t) {
  return cd(e) === 2 ? e.has(t) : Object.prototype.hasOwnProperty.call(e, t);
}
function FA(e, t, r) {
  const n = cd(e);
  n === 2 ? e.set(t, r) : n === 3 ? e.add(r) : e[t] = r;
}
function j$(e, t) {
  return e === t ? e !== 0 || 1 / e === 1 / t : e !== e && t !== t;
}
function wu(e) {
  return e instanceof Map;
}
function fd(e) {
  return e instanceof Set;
}
function Ei(e) {
  return e.copy_ || e.base_;
}
function ch(e, t) {
  if (wu(e))
    return new Map(e);
  if (fd(e))
    return new Set(e);
  if (Array.isArray(e))
    return Array.prototype.slice.call(e);
  const r = BA(e);
  if (t === !0 || t === "class_only" && !r) {
    const n = Object.getOwnPropertyDescriptors(e);
    delete n[tr];
    let i = Reflect.ownKeys(n);
    for (let a = 0; a < i.length; a++) {
      const o = i[a], l = n[o];
      l.writable === !1 && (l.writable = !0, l.configurable = !0), (l.get || l.set) && (n[o] = {
        configurable: !0,
        writable: !0,
        // could live with !!desc.set as well here...
        enumerable: l.enumerable,
        value: e[o]
      });
    }
    return Object.create(Ll(e), n);
  } else {
    const n = Ll(e);
    if (n !== null && r)
      return { ...e };
    const i = Object.create(n);
    return Object.assign(i, e);
  }
}
function Ay(e, t = !1) {
  return dd(e) || Qa(e) || !Gi(e) || (cd(e) > 1 && Object.defineProperties(e, {
    set: ws,
    add: ws,
    clear: ws,
    delete: ws
  }), Object.freeze(e), t && Object.values(e).forEach((r) => Ay(r, !0))), e;
}
function C$() {
  Ar(2);
}
var ws = {
  value: C$
};
function dd(e) {
  return e === null || typeof e != "object" ? !0 : Object.isFrozen(e);
}
var T$ = {};
function qi(e) {
  const t = T$[e];
  return t || Ar(0, e), t;
}
var Rl;
function KA() {
  return Rl;
}
function M$(e, t) {
  return {
    drafts_: [],
    parent_: e,
    immer_: t,
    // Whenever the modified draft contains a draft from another scope, we
    // need to prevent auto-freezing so the unowned draft can be finalized.
    canAutoFreeze_: !0,
    unfinalizedDrafts_: 0
  };
}
function rx(e, t) {
  t && (qi("Patches"), e.patches_ = [], e.inversePatches_ = [], e.patchListener_ = t);
}
function fh(e) {
  dh(e), e.drafts_.forEach(D$), e.drafts_ = null;
}
function dh(e) {
  e === Rl && (Rl = e.parent_);
}
function nx(e) {
  return Rl = M$(Rl, e);
}
function D$(e) {
  const t = e[tr];
  t.type_ === 0 || t.type_ === 1 ? t.revoke_() : t.revoked_ = !0;
}
function ix(e, t) {
  t.unfinalizedDrafts_ = t.drafts_.length;
  const r = t.drafts_[0];
  return e !== void 0 && e !== r ? (r[tr].modified_ && (fh(t), Ar(4)), Gi(e) && (e = Fc(t, e), t.parent_ || Kc(t, e)), t.patches_ && qi("Patches").generateReplacementPatches_(
    r[tr].base_,
    e,
    t.patches_,
    t.inversePatches_
  )) : e = Fc(t, r, []), fh(t), t.patches_ && t.patchListener_(t.patches_, t.inversePatches_), e !== zA ? e : void 0;
}
function Fc(e, t, r) {
  if (dd(t))
    return t;
  const n = e.immer_.shouldUseStrictIteration(), i = t[tr];
  if (!i)
    return Bc(
      t,
      (a, o) => ax(e, i, t, a, o, r),
      n
    ), t;
  if (i.scope_ !== e)
    return t;
  if (!i.modified_)
    return Kc(e, i.base_, !0), i.base_;
  if (!i.finalized_) {
    i.finalized_ = !0, i.scope_.unfinalizedDrafts_--;
    const a = i.copy_;
    let o = a, l = !1;
    i.type_ === 3 && (o = new Set(a), a.clear(), l = !0), Bc(
      o,
      (u, s) => ax(
        e,
        i,
        a,
        u,
        s,
        r,
        l
      ),
      n
    ), Kc(e, a, !1), r && e.patches_ && qi("Patches").generatePatches_(
      i,
      r,
      e.patches_,
      e.inversePatches_
    );
  }
  return i.copy_;
}
function ax(e, t, r, n, i, a, o) {
  if (i == null || typeof i != "object" && !o)
    return;
  const l = dd(i);
  if (!(l && !o)) {
    if (Qa(i)) {
      const u = a && t && t.type_ !== 3 && // Set objects are atomic since they have no keys.
      !sh(t.assigned_, n) ? a.concat(n) : void 0, s = Fc(e, i, u);
      if (FA(r, n, s), Qa(s))
        e.canAutoFreeze_ = !1;
      else
        return;
    } else o && r.add(i);
    if (Gi(i) && !l) {
      if (!e.immer_.autoFreeze_ && e.unfinalizedDrafts_ < 1 || t && t.base_ && t.base_[n] === i && l)
        return;
      Fc(e, i), (!t || !t.scope_.parent_) && typeof n != "symbol" && (wu(r) ? r.has(n) : Object.prototype.propertyIsEnumerable.call(r, n)) && Kc(e, i);
    }
  }
}
function Kc(e, t, r = !1) {
  !e.parent_ && e.immer_.autoFreeze_ && e.canAutoFreeze_ && Ay(t, r);
}
function N$(e, t) {
  const r = Array.isArray(e), n = {
    type_: r ? 1 : 0,
    // Track which produce call this is associated with.
    scope_: t ? t.scope_ : KA(),
    // True for both shallow and deep changes.
    modified_: !1,
    // Used during finalization.
    finalized_: !1,
    // Track which properties have been assigned (true) or deleted (false).
    assigned_: {},
    // The parent draft state.
    parent_: t,
    // The base state.
    base_: e,
    // The base proxy.
    draft_: null,
    // set below
    // The base copy with any updated values.
    copy_: null,
    // Called by the `produce` function.
    revoke_: null,
    isManual_: !1
  };
  let i = n, a = ky;
  r && (i = [n], a = zl);
  const { revoke: o, proxy: l } = Proxy.revocable(i, a);
  return n.draft_ = l, n.revoke_ = o, l;
}
var ky = {
  get(e, t) {
    if (t === tr)
      return e;
    const r = Ei(e);
    if (!sh(r, t))
      return $$(e, r, t);
    const n = r[t];
    return e.finalized_ || !Gi(n) ? n : n === Cv(e.base_, t) ? (Tv(e), e.copy_[t] = ph(n, e)) : n;
  },
  has(e, t) {
    return t in Ei(e);
  },
  ownKeys(e) {
    return Reflect.ownKeys(Ei(e));
  },
  set(e, t, r) {
    const n = WA(Ei(e), t);
    if (n != null && n.set)
      return n.set.call(e.draft_, r), !0;
    if (!e.modified_) {
      const i = Cv(Ei(e), t), a = i == null ? void 0 : i[tr];
      if (a && a.base_ === r)
        return e.copy_[t] = r, e.assigned_[t] = !1, !0;
      if (j$(r, i) && (r !== void 0 || sh(e.base_, t)))
        return !0;
      Tv(e), vh(e);
    }
    return e.copy_[t] === r && // special case: handle new props with value 'undefined'
    (r !== void 0 || t in e.copy_) || // special case: NaN
    Number.isNaN(r) && Number.isNaN(e.copy_[t]) || (e.copy_[t] = r, e.assigned_[t] = !0), !0;
  },
  deleteProperty(e, t) {
    return Cv(e.base_, t) !== void 0 || t in e.base_ ? (e.assigned_[t] = !1, Tv(e), vh(e)) : delete e.assigned_[t], e.copy_ && delete e.copy_[t], !0;
  },
  // Note: We never coerce `desc.value` into an Immer draft, because we can't make
  // the same guarantee in ES5 mode.
  getOwnPropertyDescriptor(e, t) {
    const r = Ei(e), n = Reflect.getOwnPropertyDescriptor(r, t);
    return n && {
      writable: !0,
      configurable: e.type_ !== 1 || t !== "length",
      enumerable: n.enumerable,
      value: r[t]
    };
  },
  defineProperty() {
    Ar(11);
  },
  getPrototypeOf(e) {
    return Ll(e.base_);
  },
  setPrototypeOf() {
    Ar(12);
  }
}, zl = {};
Bc(ky, (e, t) => {
  zl[e] = function() {
    return arguments[0] = arguments[0][0], t.apply(this, arguments);
  };
});
zl.deleteProperty = function(e, t) {
  return zl.set.call(this, e, t, void 0);
};
zl.set = function(e, t, r) {
  return ky.set.call(this, e[0], t, r, e[0]);
};
function Cv(e, t) {
  const r = e[tr];
  return (r ? Ei(r) : e)[t];
}
function $$(e, t, r) {
  var i;
  const n = WA(t, r);
  return n ? "value" in n ? n.value : (
    // This is a very special case, if the prop is a getter defined by the
    // prototype, we should invoke it with the draft as context!
    (i = n.get) == null ? void 0 : i.call(e.draft_)
  ) : void 0;
}
function WA(e, t) {
  if (!(t in e))
    return;
  let r = Ll(e);
  for (; r; ) {
    const n = Object.getOwnPropertyDescriptor(r, t);
    if (n)
      return n;
    r = Ll(r);
  }
}
function vh(e) {
  e.modified_ || (e.modified_ = !0, e.parent_ && vh(e.parent_));
}
function Tv(e) {
  e.copy_ || (e.copy_ = ch(
    e.base_,
    e.scope_.immer_.useStrictShallowCopy_
  ));
}
var L$ = class {
  constructor(e) {
    this.autoFreeze_ = !0, this.useStrictShallowCopy_ = !1, this.useStrictIteration_ = !0, this.produce = (t, r, n) => {
      if (typeof t == "function" && typeof r != "function") {
        const a = r;
        r = t;
        const o = this;
        return function(u = a, ...s) {
          return o.produce(u, (c) => r.call(this, c, ...s));
        };
      }
      typeof r != "function" && Ar(6), n !== void 0 && typeof n != "function" && Ar(7);
      let i;
      if (Gi(t)) {
        const a = nx(this), o = ph(t, void 0);
        let l = !0;
        try {
          i = r(o), l = !1;
        } finally {
          l ? fh(a) : dh(a);
        }
        return rx(a, n), ix(i, a);
      } else if (!t || typeof t != "object") {
        if (i = r(t), i === void 0 && (i = t), i === zA && (i = void 0), this.autoFreeze_ && Ay(i, !0), n) {
          const a = [], o = [];
          qi("Patches").generateReplacementPatches_(t, i, a, o), n(a, o);
        }
        return i;
      } else
        Ar(1, t);
    }, this.produceWithPatches = (t, r) => {
      if (typeof t == "function")
        return (o, ...l) => this.produceWithPatches(o, (u) => t(u, ...l));
      let n, i;
      return [this.produce(t, r, (o, l) => {
        n = o, i = l;
      }), n, i];
    }, typeof (e == null ? void 0 : e.autoFreeze) == "boolean" && this.setAutoFreeze(e.autoFreeze), typeof (e == null ? void 0 : e.useStrictShallowCopy) == "boolean" && this.setUseStrictShallowCopy(e.useStrictShallowCopy), typeof (e == null ? void 0 : e.useStrictIteration) == "boolean" && this.setUseStrictIteration(e.useStrictIteration);
  }
  createDraft(e) {
    Gi(e) || Ar(8), Qa(e) && (e = R$(e));
    const t = nx(this), r = ph(e, void 0);
    return r[tr].isManual_ = !0, dh(t), r;
  }
  finishDraft(e, t) {
    const r = e && e[tr];
    (!r || !r.isManual_) && Ar(9);
    const { scope_: n } = r;
    return rx(n, t), ix(void 0, n);
  }
  /**
   * Pass true to automatically freeze all copies created by Immer.
   *
   * By default, auto-freezing is enabled.
   */
  setAutoFreeze(e) {
    this.autoFreeze_ = e;
  }
  /**
   * Pass true to enable strict shallow copy.
   *
   * By default, immer does not copy the object descriptors such as getter, setter and non-enumrable properties.
   */
  setUseStrictShallowCopy(e) {
    this.useStrictShallowCopy_ = e;
  }
  /**
   * Pass false to use faster iteration that skips non-enumerable properties
   * but still handles symbols for compatibility.
   *
   * By default, strict iteration is enabled (includes all own properties).
   */
  setUseStrictIteration(e) {
    this.useStrictIteration_ = e;
  }
  shouldUseStrictIteration() {
    return this.useStrictIteration_;
  }
  applyPatches(e, t) {
    let r;
    for (r = t.length - 1; r >= 0; r--) {
      const i = t[r];
      if (i.path.length === 0 && i.op === "replace") {
        e = i.value;
        break;
      }
    }
    r > -1 && (t = t.slice(r + 1));
    const n = qi("Patches").applyPatches_;
    return Qa(e) ? n(e, t) : this.produce(
      e,
      (i) => n(i, t)
    );
  }
};
function ph(e, t) {
  const r = wu(e) ? qi("MapSet").proxyMap_(e, t) : fd(e) ? qi("MapSet").proxySet_(e, t) : N$(e, t);
  return (t ? t.scope_ : KA()).drafts_.push(r), r;
}
function R$(e) {
  return Qa(e) || Ar(10, e), UA(e);
}
function UA(e) {
  if (!Gi(e) || dd(e))
    return e;
  const t = e[tr];
  let r, n = !0;
  if (t) {
    if (!t.modified_)
      return t.base_;
    t.finalized_ = !0, r = ch(e, t.scope_.immer_.useStrictShallowCopy_), n = t.scope_.immer_.shouldUseStrictIteration();
  } else
    r = ch(e, !0);
  return Bc(
    r,
    (i, a) => {
      FA(r, i, UA(a));
    },
    n
  ), t && (t.finalized_ = !1), r;
}
var z$ = new L$();
z$.produce;
var B$ = {
  settings: {
    layout: "horizontal",
    align: "center",
    verticalAlign: "middle",
    itemSorter: "value"
  },
  size: {
    width: 0,
    height: 0
  },
  payload: []
}, VA = Ut({
  name: "legend",
  initialState: B$,
  reducers: {
    setLegendSize(e, t) {
      e.size.width = t.payload.width, e.size.height = t.payload.height;
    },
    setLegendSettings(e, t) {
      e.settings.align = t.payload.align, e.settings.layout = t.payload.layout, e.settings.verticalAlign = t.payload.verticalAlign, e.settings.itemSorter = t.payload.itemSorter;
    },
    addLegendPayload: {
      reducer(e, t) {
        e.payload.push(t.payload);
      },
      prepare: ke()
    },
    replaceLegendPayload: {
      reducer(e, t) {
        var {
          prev: r,
          next: n
        } = t.payload, i = Cr(e).payload.indexOf(r);
        i > -1 && (e.payload[i] = n);
      },
      prepare: ke()
    },
    removeLegendPayload: {
      reducer(e, t) {
        var r = Cr(e).payload.indexOf(t.payload);
        r > -1 && e.payload.splice(r, 1);
      },
      prepare: ke()
    }
  }
}), {
  setLegendSize: ox,
  setLegendSettings: F$,
  addLegendPayload: HA,
  replaceLegendPayload: XA,
  removeLegendPayload: YA
} = VA.actions, K$ = VA.reducer, W$ = ["contextPayload"];
function hh() {
  return hh = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, hh.apply(null, arguments);
}
function lx(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Ja(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? lx(Object(r), !0).forEach(function(n) {
      U$(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : lx(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function U$(e, t, r) {
  return (t = V$(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function V$(e) {
  var t = H$(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function H$(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function X$(e, t) {
  if (e == null) return {};
  var r, n, i = Y$(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function Y$(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function G$(e) {
  return e.value;
}
function q$(e) {
  var {
    contextPayload: t
  } = e, r = X$(e, W$), n = DE(t, e.payloadUniqBy, G$), i = Ja(Ja({}, r), {}, {
    payload: n
  });
  return /* @__PURE__ */ d.isValidElement(e.content) ? /* @__PURE__ */ d.cloneElement(e.content, i) : typeof e.content == "function" ? /* @__PURE__ */ d.createElement(e.content, i) : /* @__PURE__ */ d.createElement(r2, i);
}
function Z$(e, t, r, n, i, a) {
  var {
    layout: o,
    align: l,
    verticalAlign: u
  } = t, s, c;
  return (!e || (e.left === void 0 || e.left === null) && (e.right === void 0 || e.right === null)) && (l === "center" && o === "vertical" ? s = {
    left: ((n || 0) - a.width) / 2
  } : s = l === "right" ? {
    right: r && r.right || 0
  } : {
    left: r && r.left || 0
  }), (!e || (e.top === void 0 || e.top === null) && (e.bottom === void 0 || e.bottom === null)) && (u === "middle" ? c = {
    top: ((i || 0) - a.height) / 2
  } : c = u === "bottom" ? {
    bottom: r && r.bottom || 0
  } : {
    top: r && r.top || 0
  }), Ja(Ja({}, s), c);
}
function Q$(e) {
  var t = J();
  return d.useEffect(() => {
    t(F$(e));
  }, [t, e]), null;
}
function J$(e) {
  var t = J();
  return d.useEffect(() => (t(ox(e)), () => {
    t(ox({
      width: 0,
      height: 0
    }));
  }), [t, e]), null;
}
function eL(e, t, r, n) {
  return e === "vertical" && B(t) ? {
    height: t
  } : e === "horizontal" ? {
    width: r || n
  } : null;
}
var tL = {
  align: "center",
  iconSize: 14,
  itemSorter: "value",
  layout: "horizontal",
  verticalAlign: "bottom"
};
function rL(e) {
  var t = ee(e, tL), r = B2(), n = GM(), i = A$(), {
    width: a,
    height: o,
    wrapperStyle: l,
    portal: u
  } = t, [s, c] = HE([r]), f = gu(), v = bu();
  if (f == null || v == null)
    return null;
  var p = f - ((i == null ? void 0 : i.left) || 0) - ((i == null ? void 0 : i.right) || 0), h = eL(t.layout, o, a, p), y = u ? l : Ja(Ja({
    position: "absolute",
    width: (h == null ? void 0 : h.width) || a || "auto",
    height: (h == null ? void 0 : h.height) || o || "auto"
  }, Z$(l, t, i, f, v, s)), l), g = u ?? n;
  if (g == null || r == null)
    return null;
  var m = /* @__PURE__ */ d.createElement("div", {
    className: "recharts-legend-wrapper",
    style: y,
    ref: c
  }, /* @__PURE__ */ d.createElement(Q$, {
    layout: t.layout,
    align: t.align,
    verticalAlign: t.verticalAlign,
    itemSorter: t.itemSorter
  }), !u && /* @__PURE__ */ d.createElement(J$, {
    width: s.width,
    height: s.height
  }), /* @__PURE__ */ d.createElement(q$, hh({}, t, h, {
    margin: i,
    chartWidth: f,
    chartHeight: v,
    contextPayload: r
  })));
  return /* @__PURE__ */ Uf.createPortal(m, g);
}
rL.displayName = "Legend";
function mh() {
  return mh = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, mh.apply(null, arguments);
}
function ux(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Mv(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? ux(Object(r), !0).forEach(function(n) {
      nL(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : ux(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function nL(e, t, r) {
  return (t = iL(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function iL(e) {
  var t = aL(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function aL(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function oL(e) {
  return Array.isArray(e) && it(e[0]) && it(e[1]) ? e.join(" ~ ") : e;
}
var lL = (e) => {
  var {
    separator: t = " : ",
    contentStyle: r = {},
    itemStyle: n = {},
    labelStyle: i = {},
    payload: a,
    formatter: o,
    itemSorter: l,
    wrapperClassName: u,
    labelClassName: s,
    label: c,
    labelFormatter: f,
    accessibilityLayer: v = !1
  } = e, p = () => {
    if (a && a.length) {
      var P = {
        padding: 0,
        margin: 0
      }, O = (l ? qf(a, l) : a).map((S, E) => {
        if (S.type === "none")
          return null;
        var k = S.formatter || o || oL, {
          value: _,
          name: I
        } = S, j = _, z = I;
        if (k) {
          var N = k(_, I, S, E, a);
          if (Array.isArray(N))
            [j, z] = N;
          else if (N != null)
            j = N;
          else
            return null;
        }
        var R = Mv({
          display: "block",
          paddingTop: 4,
          paddingBottom: 4,
          color: S.color || "#000"
        }, n);
        return /* @__PURE__ */ d.createElement("li", {
          className: "recharts-tooltip-item",
          key: "tooltip-item-".concat(E),
          style: R
        }, it(z) ? /* @__PURE__ */ d.createElement("span", {
          className: "recharts-tooltip-item-name"
        }, z) : null, it(z) ? /* @__PURE__ */ d.createElement("span", {
          className: "recharts-tooltip-item-separator"
        }, t) : null, /* @__PURE__ */ d.createElement("span", {
          className: "recharts-tooltip-item-value"
        }, j), /* @__PURE__ */ d.createElement("span", {
          className: "recharts-tooltip-item-unit"
        }, S.unit || ""));
      });
      return /* @__PURE__ */ d.createElement("ul", {
        className: "recharts-tooltip-item-list",
        style: P
      }, O);
    }
    return null;
  }, h = Mv({
    margin: 0,
    padding: 10,
    backgroundColor: "#fff",
    border: "1px solid #ccc",
    whiteSpace: "nowrap"
  }, r), y = Mv({
    margin: 0
  }, i), g = !oe(c), m = g ? c : "", b = Y("recharts-default-tooltip", u), x = Y("recharts-tooltip-label", s);
  g && f && a !== void 0 && a !== null && (m = f(c, a));
  var w = v ? {
    role: "status",
    "aria-live": "assertive"
  } : {};
  return /* @__PURE__ */ d.createElement("div", mh({
    className: b,
    style: h
  }, w), /* @__PURE__ */ d.createElement("p", {
    className: x,
    style: y
  }, /* @__PURE__ */ d.isValidElement(m) ? m : "".concat(m)), p());
}, Uo = "recharts-tooltip-wrapper", uL = {
  visibility: "hidden"
};
function sL(e) {
  var {
    coordinate: t,
    translateX: r,
    translateY: n
  } = e;
  return Y(Uo, {
    ["".concat(Uo, "-right")]: B(r) && t && B(t.x) && r >= t.x,
    ["".concat(Uo, "-left")]: B(r) && t && B(t.x) && r < t.x,
    ["".concat(Uo, "-bottom")]: B(n) && t && B(t.y) && n >= t.y,
    ["".concat(Uo, "-top")]: B(n) && t && B(t.y) && n < t.y
  });
}
function sx(e) {
  var {
    allowEscapeViewBox: t,
    coordinate: r,
    key: n,
    offsetTopLeft: i,
    position: a,
    reverseDirection: o,
    tooltipDimension: l,
    viewBox: u,
    viewBoxDimension: s
  } = e;
  if (a && B(a[n]))
    return a[n];
  var c = r[n] - l - (i > 0 ? i : 0), f = r[n] + i;
  if (t[n])
    return o[n] ? c : f;
  var v = u[n];
  if (v == null)
    return 0;
  if (o[n]) {
    var p = c, h = v;
    return p < h ? Math.max(f, v) : Math.max(c, v);
  }
  if (s == null)
    return 0;
  var y = f + l, g = v + s;
  return y > g ? Math.max(c, v) : Math.max(f, v);
}
function cL(e) {
  var {
    translateX: t,
    translateY: r,
    useTranslate3d: n
  } = e;
  return {
    transform: n ? "translate3d(".concat(t, "px, ").concat(r, "px, 0)") : "translate(".concat(t, "px, ").concat(r, "px)")
  };
}
function fL(e) {
  var {
    allowEscapeViewBox: t,
    coordinate: r,
    offsetTopLeft: n,
    position: i,
    reverseDirection: a,
    tooltipBox: o,
    useTranslate3d: l,
    viewBox: u
  } = e, s, c, f;
  return o.height > 0 && o.width > 0 && r ? (c = sx({
    allowEscapeViewBox: t,
    coordinate: r,
    key: "x",
    offsetTopLeft: n,
    position: i,
    reverseDirection: a,
    tooltipDimension: o.width,
    viewBox: u,
    viewBoxDimension: u.width
  }), f = sx({
    allowEscapeViewBox: t,
    coordinate: r,
    key: "y",
    offsetTopLeft: n,
    position: i,
    reverseDirection: a,
    tooltipDimension: o.height,
    viewBox: u,
    viewBoxDimension: u.height
  }), s = cL({
    translateX: c,
    translateY: f,
    useTranslate3d: l
  })) : s = uL, {
    cssProperties: s,
    cssClasses: sL({
      translateX: c,
      translateY: f,
      coordinate: r
    })
  };
}
function cx(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Ps(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? cx(Object(r), !0).forEach(function(n) {
      yh(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : cx(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function yh(e, t, r) {
  return (t = dL(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function dL(e) {
  var t = vL(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function vL(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
class pL extends d.PureComponent {
  constructor() {
    super(...arguments), yh(this, "state", {
      dismissed: !1,
      dismissedAtCoordinate: {
        x: 0,
        y: 0
      }
    }), yh(this, "handleKeyDown", (t) => {
      if (t.key === "Escape") {
        var r, n, i, a;
        this.setState({
          dismissed: !0,
          dismissedAtCoordinate: {
            x: (r = (n = this.props.coordinate) === null || n === void 0 ? void 0 : n.x) !== null && r !== void 0 ? r : 0,
            y: (i = (a = this.props.coordinate) === null || a === void 0 ? void 0 : a.y) !== null && i !== void 0 ? i : 0
          }
        });
      }
    });
  }
  componentDidMount() {
    document.addEventListener("keydown", this.handleKeyDown);
  }
  componentWillUnmount() {
    document.removeEventListener("keydown", this.handleKeyDown);
  }
  componentDidUpdate() {
    var t, r;
    this.state.dismissed && (((t = this.props.coordinate) === null || t === void 0 ? void 0 : t.x) !== this.state.dismissedAtCoordinate.x || ((r = this.props.coordinate) === null || r === void 0 ? void 0 : r.y) !== this.state.dismissedAtCoordinate.y) && (this.state.dismissed = !1);
  }
  render() {
    var {
      active: t,
      allowEscapeViewBox: r,
      animationDuration: n,
      animationEasing: i,
      children: a,
      coordinate: o,
      hasPayload: l,
      isAnimationActive: u,
      offset: s,
      position: c,
      reverseDirection: f,
      useTranslate3d: v,
      viewBox: p,
      wrapperStyle: h,
      lastBoundingBox: y,
      innerRef: g,
      hasPortalFromProps: m
    } = this.props, {
      cssClasses: b,
      cssProperties: x
    } = fL({
      allowEscapeViewBox: r,
      coordinate: o,
      offsetTopLeft: s,
      position: c,
      reverseDirection: f,
      tooltipBox: {
        height: y.height,
        width: y.width
      },
      useTranslate3d: v,
      viewBox: p
    }), w = m ? {} : Ps(Ps({
      transition: u && t ? "transform ".concat(n, "ms ").concat(i) : void 0
    }, x), {}, {
      pointerEvents: "none",
      visibility: !this.state.dismissed && t && l ? "visible" : "hidden",
      position: "absolute",
      top: 0,
      left: 0
    }), P = Ps(Ps({}, w), {}, {
      visibility: !this.state.dismissed && t && l ? "visible" : "hidden"
    }, h);
    return (
      // This element allow listening to the `Escape` key. See https://github.com/recharts/recharts/pull/2925
      /* @__PURE__ */ d.createElement("div", {
        // @ts-expect-error typescript library does not recognize xmlns attribute, but it's required for an HTML chunk inside SVG.
        xmlns: "http://www.w3.org/1999/xhtml",
        tabIndex: -1,
        className: b,
        style: P,
        ref: g
      }, a)
    );
  }
}
var GA = () => {
  var e;
  return (e = T((t) => t.rootProps.accessibilityLayer)) !== null && e !== void 0 ? e : !0;
};
function gh() {
  return gh = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, gh.apply(null, arguments);
}
function fx(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function dx(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? fx(Object(r), !0).forEach(function(n) {
      hL(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : fx(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function hL(e, t, r) {
  return (t = mL(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function mL(e) {
  var t = yL(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function yL(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var vx = {
  curveBasisClosed: pD,
  curveBasisOpen: hD,
  curveBasis: vD,
  curveBumpX: JM,
  curveBumpY: eD,
  curveLinearClosed: mD,
  curveLinear: Hf,
  curveMonotoneX: yD,
  curveMonotoneY: gD,
  curveNatural: bD,
  curveStep: xD,
  curveStepAfter: PD,
  curveStepBefore: wD
}, Wc = (e) => se(e.x) && se(e.y), px = (e) => e.base != null && Wc(e.base) && Wc(e), Vo = (e) => e.x, Ho = (e) => e.y, gL = (e, t) => {
  if (typeof e == "function")
    return e;
  var r = "curve".concat(fu(e));
  return (r === "curveMonotone" || r === "curveBump") && t ? vx["".concat(r).concat(t === "vertical" ? "Y" : "X")] : vx[r] || Hf;
}, bL = (e) => {
  var {
    type: t = "linear",
    points: r = [],
    baseLine: n,
    layout: i,
    connectNulls: a = !1
  } = e, o = gL(t, i), l = a ? r.filter(Wc) : r, u;
  if (Array.isArray(n)) {
    var s = r.map((p, h) => dx(dx({}, p), {}, {
      base: n[h]
    }));
    i === "vertical" ? u = ps().y(Ho).x1(Vo).x0((p) => p.base.x) : u = ps().x(Vo).y1(Ho).y0((p) => p.base.y);
    var c = u.defined(px).curve(o), f = a ? s.filter(px) : s;
    return c(f);
  }
  i === "vertical" && B(n) ? u = ps().y(Ho).x1(Vo).x0(n) : B(n) ? u = ps().x(Vo).y1(Ho).y0(n) : u = aE().x(Vo).y(Ho);
  var v = u.defined(Wc).curve(o);
  return v(l);
}, Ri = (e) => {
  var {
    className: t,
    points: r,
    path: n,
    pathRef: i
  } = e, a = Ln();
  if ((!r || !r.length) && !n)
    return null;
  var o = {
    type: e.type,
    points: e.points,
    baseLine: e.baseLine,
    layout: e.layout || a,
    connectNulls: e.connectNulls
  }, l = r && r.length ? bL(o) : n;
  return /* @__PURE__ */ d.createElement("path", gh({}, re(e), ty(e), {
    className: Y("recharts-curve", t),
    d: l === null ? void 0 : l,
    ref: i
  }));
}, xL = ["x", "y", "top", "left", "width", "height", "className"];
function bh() {
  return bh = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, bh.apply(null, arguments);
}
function hx(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function wL(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? hx(Object(r), !0).forEach(function(n) {
      PL(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : hx(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function PL(e, t, r) {
  return (t = OL(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function OL(e) {
  var t = SL(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function SL(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function EL(e, t) {
  if (e == null) return {};
  var r, n, i = AL(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function AL(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
var kL = (e, t, r, n, i, a) => "M".concat(e, ",").concat(i, "v").concat(n, "M").concat(a, ",").concat(t, "h").concat(r), _L = (e) => {
  var {
    x: t = 0,
    y: r = 0,
    top: n = 0,
    left: i = 0,
    width: a = 0,
    height: o = 0,
    className: l
  } = e, u = EL(e, xL), s = wL({
    x: t,
    y: r,
    top: n,
    left: i,
    width: a,
    height: o
  }, u);
  return !B(t) || !B(r) || !B(a) || !B(o) || !B(n) || !B(i) ? null : /* @__PURE__ */ d.createElement("path", bh({}, Ie(s), {
    className: Y("recharts-cross", l),
    d: kL(t, r, a, o, n, i)
  }));
};
function IL(e, t, r, n) {
  var i = n / 2;
  return {
    stroke: "none",
    fill: "#ccc",
    x: e === "horizontal" ? t.x - i : r.left + 0.5,
    y: e === "horizontal" ? r.top + 0.5 : t.y - i,
    width: e === "horizontal" ? n : r.width - 1,
    height: e === "horizontal" ? r.height - 1 : n
  };
}
function mx(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function yx(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? mx(Object(r), !0).forEach(function(n) {
      jL(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : mx(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function jL(e, t, r) {
  return (t = CL(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function CL(e) {
  var t = TL(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function TL(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var ML = (e) => e.replace(/([A-Z])/g, (t) => "-".concat(t.toLowerCase())), _y = (e, t, r) => e.map((n) => "".concat(ML(n), " ").concat(t, "ms ").concat(r)).join(","), DL = (e, t) => [Object.keys(e), Object.keys(t)].reduce((r, n) => r.filter((i) => n.includes(i))), Bl = (e, t) => Object.keys(t).reduce((r, n) => yx(yx({}, r), {}, {
  [n]: e(n, t[n])
}), {});
function gx(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Ge(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? gx(Object(r), !0).forEach(function(n) {
      NL(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : gx(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function NL(e, t, r) {
  return (t = $L(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function $L(e) {
  var t = LL(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function LL(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var Uc = (e, t, r) => e + (t - e) * r, xh = (e) => {
  var {
    from: t,
    to: r
  } = e;
  return t !== r;
}, qA = (e, t, r) => {
  var n = Bl((i, a) => {
    if (xh(a)) {
      var [o, l] = e(a.from, a.to, a.velocity);
      return Ge(Ge({}, a), {}, {
        from: o,
        velocity: l
      });
    }
    return a;
  }, t);
  return r < 1 ? Bl((i, a) => xh(a) && n[i] != null ? Ge(Ge({}, a), {}, {
    velocity: Uc(a.velocity, n[i].velocity, r),
    from: Uc(a.from, n[i].from, r)
  }) : a, t) : qA(e, n, r - 1);
};
function RL(e, t, r, n, i, a) {
  var o, l = n.reduce((v, p) => Ge(Ge({}, v), {}, {
    [p]: {
      from: e[p],
      velocity: 0,
      to: t[p]
    }
  }), {}), u = () => Bl((v, p) => p.from, l), s = () => !Object.values(l).filter(xh).length, c = null, f = (v) => {
    o || (o = v);
    var p = v - o, h = p / r.dt;
    l = qA(r, l, h), i(Ge(Ge(Ge({}, e), t), u())), o = v, s() || (c = a.setTimeout(f));
  };
  return () => (c = a.setTimeout(f), () => {
    var v;
    (v = c) === null || v === void 0 || v();
  });
}
function zL(e, t, r, n, i, a, o) {
  var l = null, u = i.reduce((f, v) => {
    var p = e[v], h = t[v];
    return p == null || h == null ? f : Ge(Ge({}, f), {}, {
      [v]: [p, h]
    });
  }, {}), s, c = (f) => {
    s || (s = f);
    var v = (f - s) / n, p = Bl((y, g) => Uc(...g, r(v)), u);
    if (a(Ge(Ge(Ge({}, e), t), p)), v < 1)
      l = o.setTimeout(c);
    else {
      var h = Bl((y, g) => Uc(...g, r(1)), u);
      a(Ge(Ge(Ge({}, e), t), h));
    }
  };
  return () => (l = o.setTimeout(c), () => {
    var f;
    (f = l) === null || f === void 0 || f();
  });
}
const BL = (e, t, r, n, i, a) => {
  var o = DL(e, t);
  return r == null ? () => (i(Ge(Ge({}, e), t)), () => {
  }) : r.isStepper === !0 ? RL(e, t, r, o, i, a) : zL(e, t, r, n, o, i, a);
};
var Vc = 1e-4, ZA = (e, t) => [0, 3 * e, 3 * t - 6 * e, 3 * e - 3 * t + 1], QA = (e, t) => e.map((r, n) => r * t ** n).reduce((r, n) => r + n), bx = (e, t) => (r) => {
  var n = ZA(e, t);
  return QA(n, r);
}, FL = (e, t) => (r) => {
  var n = ZA(e, t), i = [...n.map((a, o) => a * o).slice(1), 0];
  return QA(i, r);
}, KL = (e) => {
  var t, r = e.split("(");
  if (r.length !== 2 || r[0] !== "cubic-bezier")
    return null;
  var n = (t = r[1]) === null || t === void 0 || (t = t.split(")")[0]) === null || t === void 0 ? void 0 : t.split(",");
  if (n == null || n.length !== 4)
    return null;
  var i = n.map((a) => parseFloat(a));
  return [i[0], i[1], i[2], i[3]];
}, WL = function() {
  for (var t = arguments.length, r = new Array(t), n = 0; n < t; n++)
    r[n] = arguments[n];
  if (r.length === 1)
    switch (r[0]) {
      case "linear":
        return [0, 0, 1, 1];
      case "ease":
        return [0.25, 0.1, 0.25, 1];
      case "ease-in":
        return [0.42, 0, 1, 1];
      case "ease-out":
        return [0.42, 0, 0.58, 1];
      case "ease-in-out":
        return [0, 0, 0.58, 1];
      default: {
        var i = KL(r[0]);
        if (i)
          return i;
      }
    }
  return r.length === 4 ? r : [0, 0, 1, 1];
}, UL = (e, t, r, n) => {
  var i = bx(e, r), a = bx(t, n), o = FL(e, r), l = (s) => s > 1 ? 1 : s < 0 ? 0 : s, u = (s) => {
    for (var c = s > 1 ? 1 : s, f = c, v = 0; v < 8; ++v) {
      var p = i(f) - c, h = o(f);
      if (Math.abs(p - c) < Vc || h < Vc)
        return a(f);
      f = l(f - p / h);
    }
    return a(f);
  };
  return u.isStepper = !1, u;
}, xx = function() {
  return UL(...WL(...arguments));
}, VL = function() {
  var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, {
    stiff: r = 100,
    damping: n = 8,
    dt: i = 17
  } = t, a = (o, l, u) => {
    var s = -(o - l) * r, c = u * n, f = u + (s - c) * i / 1e3, v = u * i / 1e3 + o;
    return Math.abs(v - l) < Vc && Math.abs(f) < Vc ? [l, 0] : [v, f];
  };
  return a.isStepper = !0, a.dt = i, a;
}, HL = (e) => {
  if (typeof e == "string")
    switch (e) {
      case "ease":
      case "ease-in-out":
      case "ease-out":
      case "ease-in":
      case "linear":
        return xx(e);
      case "spring":
        return VL();
      default:
        if (e.split("(")[0] === "cubic-bezier")
          return xx(e);
    }
  return typeof e == "function" ? e : null;
};
function XL(e) {
  var t, r = () => null, n = !1, i = null, a = (o) => {
    if (!n) {
      if (Array.isArray(o)) {
        if (!o.length)
          return;
        var l = o, [u, ...s] = l;
        if (typeof u == "number") {
          i = e.setTimeout(a.bind(null, s), u);
          return;
        }
        a(u), i = e.setTimeout(a.bind(null, s));
        return;
      }
      typeof o == "string" && (t = o, r(t)), typeof o == "object" && (t = o, r(t)), typeof o == "function" && o();
    }
  };
  return {
    stop: () => {
      n = !0;
    },
    start: (o) => {
      n = !1, i && (i(), i = null), a(o);
    },
    subscribe: (o) => (r = o, () => {
      r = () => null;
    }),
    getTimeoutController: () => e
  };
}
class YL {
  setTimeout(t) {
    var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0, n = performance.now(), i = null, a = (o) => {
      o - n >= r ? t(o) : typeof requestAnimationFrame == "function" && (i = requestAnimationFrame(a));
    };
    return i = requestAnimationFrame(a), () => {
      i != null && cancelAnimationFrame(i);
    };
  }
}
function GL() {
  return XL(new YL());
}
var qL = /* @__PURE__ */ d.createContext(GL);
function JA(e, t) {
  var r = d.useContext(qL);
  return d.useMemo(() => t ?? r(e), [e, t, r]);
}
var ZL = () => !(typeof window < "u" && window.document && window.document.createElement && window.setTimeout), po = {
  isSsr: ZL()
}, QL = {
  begin: 0,
  duration: 1e3,
  easing: "ease",
  isActive: !0,
  canBegin: !0,
  onAnimationEnd: () => {
  },
  onAnimationStart: () => {
  }
}, wx = {
  t: 0
}, Dv = {
  t: 1
};
function Jr(e) {
  var t = ee(e, QL), {
    isActive: r,
    canBegin: n,
    duration: i,
    easing: a,
    begin: o,
    onAnimationEnd: l,
    onAnimationStart: u,
    children: s
  } = t, c = r === "auto" ? !po.isSsr : r, f = JA(t.animationId, t.animationManager), [v, p] = d.useState(c ? wx : Dv), h = d.useRef(null);
  return d.useEffect(() => {
    c || p(Dv);
  }, [c]), d.useEffect(() => {
    if (!c || !n)
      return co;
    var y = BL(wx, Dv, HL(a), i, p, f.getTimeoutController()), g = () => {
      h.current = y();
    };
    return f.start([u, o, g, i, l]), () => {
      f.stop(), h.current && h.current(), l();
    };
  }, [c, n, i, a, o, u, l, f]), s(v.t);
}
function en(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "animation-", r = d.useRef(Ya(t)), n = d.useRef(e);
  return n.current !== e && (r.current = Ya(t), n.current = e), r.current;
}
var JL = ["radius"], eR = ["radius"], Px, Ox, Sx, Ex, Ax, kx, _x, Ix, jx, Cx;
function Tx(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Mx(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Tx(Object(r), !0).forEach(function(n) {
      tR(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Tx(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function tR(e, t, r) {
  return (t = rR(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function rR(e) {
  var t = nR(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function nR(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function Hc() {
  return Hc = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Hc.apply(null, arguments);
}
function Dx(e, t) {
  if (e == null) return {};
  var r, n, i = iR(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function iR(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function Rr(e, t) {
  return t || (t = e.slice(0)), Object.freeze(Object.defineProperties(e, { raw: { value: Object.freeze(t) } }));
}
var Nx = (e, t, r, n, i) => {
  var a = Zn(r), o = Zn(n), l = Math.min(Math.abs(a) / 2, Math.abs(o) / 2), u = o >= 0 ? 1 : -1, s = a >= 0 ? 1 : -1, c = o >= 0 && a >= 0 || o < 0 && a < 0 ? 1 : 0, f;
  if (l > 0 && i instanceof Array) {
    for (var v = [0, 0, 0, 0], p = 0, h = 4; p < h; p++)
      v[p] = i[p] > l ? l : i[p];
    f = Ce(Px || (Px = Rr(["M", ",", ""])), e, t + u * v[0]), v[0] > 0 && (f += Ce(Ox || (Ox = Rr(["A ", ",", ",0,0,", ",", ",", ""])), v[0], v[0], c, e + s * v[0], t)), f += Ce(Sx || (Sx = Rr(["L ", ",", ""])), e + r - s * v[1], t), v[1] > 0 && (f += Ce(Ex || (Ex = Rr(["A ", ",", ",0,0,", `,
        `, ",", ""])), v[1], v[1], c, e + r, t + u * v[1])), f += Ce(Ax || (Ax = Rr(["L ", ",", ""])), e + r, t + n - u * v[2]), v[2] > 0 && (f += Ce(kx || (kx = Rr(["A ", ",", ",0,0,", `,
        `, ",", ""])), v[2], v[2], c, e + r - s * v[2], t + n)), f += Ce(_x || (_x = Rr(["L ", ",", ""])), e + s * v[3], t + n), v[3] > 0 && (f += Ce(Ix || (Ix = Rr(["A ", ",", ",0,0,", `,
        `, ",", ""])), v[3], v[3], c, e, t + n - u * v[3])), f += "Z";
  } else if (l > 0 && i === +i && i > 0) {
    var y = Math.min(l, i);
    f = Ce(jx || (jx = Rr(["M ", ",", `
            A `, ",", ",0,0,", ",", ",", `
            L `, ",", `
            A `, ",", ",0,0,", ",", ",", `
            L `, ",", `
            A `, ",", ",0,0,", ",", ",", `
            L `, ",", `
            A `, ",", ",0,0,", ",", ",", " Z"])), e, t + u * y, y, y, c, e + s * y, t, e + r - s * y, t, y, y, c, e + r, t + u * y, e + r, t + n - u * y, y, y, c, e + r - s * y, t + n, e + s * y, t + n, y, y, c, e, t + n - u * y);
  } else
    f = Ce(Cx || (Cx = Rr(["M ", ",", " h ", " v ", " h ", " Z"])), e, t, r, n, -r);
  return f;
}, $x = {
  x: 0,
  y: 0,
  width: 0,
  height: 0,
  // The radius of border
  // The radius of four corners when radius is a number
  // The radius of left-top, right-top, right-bottom, left-bottom when radius is an array
  radius: 0,
  isAnimationActive: !1,
  isUpdateAnimationActive: !1,
  animationBegin: 0,
  animationDuration: 1500,
  animationEasing: "ease"
}, Pu = (e) => {
  var t = ee(e, $x), r = d.useRef(null), [n, i] = d.useState(-1);
  d.useEffect(() => {
    if (r.current && r.current.getTotalLength)
      try {
        var H = r.current.getTotalLength();
        H && i(H);
      } catch {
      }
  }, []);
  var {
    x: a,
    y: o,
    width: l,
    height: u,
    radius: s,
    className: c
  } = t, {
    animationEasing: f,
    animationDuration: v,
    animationBegin: p,
    isAnimationActive: h,
    isUpdateAnimationActive: y
  } = t, g = d.useRef(l), m = d.useRef(u), b = d.useRef(a), x = d.useRef(o), w = d.useMemo(() => ({
    x: a,
    y: o,
    width: l,
    height: u,
    radius: s
  }), [a, o, l, u, s]), P = en(w, "rectangle-");
  if (a !== +a || o !== +o || l !== +l || u !== +u || l === 0 || u === 0)
    return null;
  var O = Y("recharts-rectangle", c);
  if (!y) {
    var S = Ie(t), {
      radius: E
    } = S, k = Dx(S, JL);
    return /* @__PURE__ */ d.createElement("path", Hc({}, k, {
      x: Zn(a),
      y: Zn(o),
      width: Zn(l),
      height: Zn(u),
      radius: typeof s == "number" ? s : void 0,
      className: O,
      d: Nx(a, o, l, u, s)
    }));
  }
  var _ = g.current, I = m.current, j = b.current, z = x.current, N = "0px ".concat(n === -1 ? 1 : n, "px"), R = "".concat(n, "px 0px"), V = _y(["strokeDasharray"], v, typeof f == "string" ? f : $x.animationEasing);
  return /* @__PURE__ */ d.createElement(Jr, {
    animationId: P,
    key: P,
    canBegin: n > 0,
    duration: v,
    easing: f,
    isActive: y,
    begin: p
  }, (H) => {
    var C = X(_, l, H), D = X(I, u, H), F = X(j, a, H), Z = X(z, o, H);
    r.current && (g.current = C, m.current = D, b.current = F, x.current = Z);
    var Q;
    h ? H > 0 ? Q = {
      transition: V,
      strokeDasharray: R
    } : Q = {
      strokeDasharray: N
    } : Q = {
      strokeDasharray: R
    };
    var Be = Ie(t), {
      radius: be
    } = Be, Je = Dx(Be, eR);
    return /* @__PURE__ */ d.createElement("path", Hc({}, Je, {
      radius: typeof s == "number" ? s : void 0,
      className: O,
      d: Nx(F, Z, C, D, s),
      ref: r,
      style: Mx(Mx({}, Q), t.style)
    }));
  });
};
function Lx(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Rx(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Lx(Object(r), !0).forEach(function(n) {
      aR(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Lx(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function aR(e, t, r) {
  return (t = oR(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function oR(e) {
  var t = lR(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function lR(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var Xc = Math.PI / 180, Yc = (e) => e * Math.PI / 180, uR = (e) => e * 180 / Math.PI, ce = (e, t, r, n) => ({
  x: e + Math.cos(-Xc * n) * r,
  y: t + Math.sin(-Xc * n) * r
}), ek = function(t, r) {
  var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  };
  return Math.min(Math.abs(t - (n.left || 0) - (n.right || 0)), Math.abs(r - (n.top || 0) - (n.bottom || 0))) / 2;
}, sR = (e, t) => {
  var {
    x: r,
    y: n
  } = e, {
    x: i,
    y: a
  } = t;
  return Math.sqrt((r - i) ** 2 + (n - a) ** 2);
}, cR = (e, t) => {
  var {
    x: r,
    y: n
  } = e, {
    cx: i,
    cy: a
  } = t, o = sR({
    x: r,
    y: n
  }, {
    x: i,
    y: a
  });
  if (o <= 0)
    return {
      radius: o,
      angle: 0
    };
  var l = (r - i) / o, u = Math.acos(l);
  return n > a && (u = 2 * Math.PI - u), {
    radius: o,
    angle: uR(u),
    angleInRadian: u
  };
}, fR = (e) => {
  var {
    startAngle: t,
    endAngle: r
  } = e, n = Math.floor(t / 360), i = Math.floor(r / 360), a = Math.min(n, i);
  return {
    startAngle: t - a * 360,
    endAngle: r - a * 360
  };
}, dR = (e, t) => {
  var {
    startAngle: r,
    endAngle: n
  } = t, i = Math.floor(r / 360), a = Math.floor(n / 360), o = Math.min(i, a);
  return e + o * 360;
}, vR = (e, t) => {
  var {
    chartX: r,
    chartY: n
  } = e, {
    radius: i,
    angle: a
  } = cR({
    x: r,
    y: n
  }, t), {
    innerRadius: o,
    outerRadius: l
  } = t;
  if (i < o || i > l || i === 0)
    return null;
  var {
    startAngle: u,
    endAngle: s
  } = fR(t), c = a, f;
  if (u <= s) {
    for (; c > s; )
      c -= 360;
    for (; c < u; )
      c += 360;
    f = c >= u && c <= s;
  } else {
    for (; c > u; )
      c -= 360;
    for (; c < s; )
      c += 360;
    f = c >= s && c <= u;
  }
  return f ? Rx(Rx({}, t), {}, {
    radius: i,
    angle: dR(c, t)
  }) : null;
}, tk = (e) => !/* @__PURE__ */ d.isValidElement(e) && typeof e != "function" && typeof e != "boolean" && e != null ? e.className : "";
function rk(e) {
  var {
    cx: t,
    cy: r,
    radius: n,
    startAngle: i,
    endAngle: a
  } = e, o = ce(t, r, n, i), l = ce(t, r, n, a);
  return {
    points: [o, l],
    cx: t,
    cy: r,
    radius: n,
    startAngle: i,
    endAngle: a
  };
}
var zx, Bx, Fx, Kx, Wx, Ux, Vx;
function wh() {
  return wh = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, wh.apply(null, arguments);
}
function Ci(e, t) {
  return t || (t = e.slice(0)), Object.freeze(Object.defineProperties(e, { raw: { value: Object.freeze(t) } }));
}
var pR = (e, t) => {
  var r = We(t - e), n = Math.min(Math.abs(t - e), 359.999);
  return r * n;
}, Os = (e) => {
  var {
    cx: t,
    cy: r,
    radius: n,
    angle: i,
    sign: a,
    isExternal: o,
    cornerRadius: l,
    cornerIsExternal: u
  } = e, s = l * (o ? 1 : -1) + n, c = Math.asin(l / s) / Xc, f = u ? i : i + a * c, v = ce(t, r, s, f), p = ce(t, r, n, f), h = u ? i - a * c : i, y = ce(t, r, s * Math.cos(c * Xc), h);
  return {
    center: v,
    circleTangency: p,
    lineTangency: y,
    theta: c
  };
}, nk = (e) => {
  var {
    cx: t,
    cy: r,
    innerRadius: n,
    outerRadius: i,
    startAngle: a,
    endAngle: o
  } = e, l = pR(a, o), u = a + l, s = ce(t, r, i, a), c = ce(t, r, i, u), f = Ce(zx || (zx = Ci(["M ", ",", `
    A `, ",", `,0,
    `, ",", `,
    `, ",", `
  `])), s.x, s.y, i, i, +(Math.abs(l) > 180), +(a > u), c.x, c.y);
  if (n > 0) {
    var v = ce(t, r, n, a), p = ce(t, r, n, u);
    f += Ce(Bx || (Bx = Ci(["L ", ",", `
            A `, ",", `,0,
            `, ",", `,
            `, ",", " Z"])), p.x, p.y, n, n, +(Math.abs(l) > 180), +(a <= u), v.x, v.y);
  } else
    f += Ce(Fx || (Fx = Ci(["L ", ",", " Z"])), t, r);
  return f;
}, hR = (e) => {
  var {
    cx: t,
    cy: r,
    innerRadius: n,
    outerRadius: i,
    cornerRadius: a,
    forceCornerRadius: o,
    cornerIsExternal: l,
    startAngle: u,
    endAngle: s
  } = e, c = We(s - u), {
    circleTangency: f,
    lineTangency: v,
    theta: p
  } = Os({
    cx: t,
    cy: r,
    radius: i,
    angle: u,
    sign: c,
    cornerRadius: a,
    cornerIsExternal: l
  }), {
    circleTangency: h,
    lineTangency: y,
    theta: g
  } = Os({
    cx: t,
    cy: r,
    radius: i,
    angle: s,
    sign: -c,
    cornerRadius: a,
    cornerIsExternal: l
  }), m = l ? Math.abs(u - s) : Math.abs(u - s) - p - g;
  if (m < 0)
    return o ? Ce(Kx || (Kx = Ci(["M ", ",", `
        a`, ",", ",0,0,1,", `,0
        a`, ",", ",0,0,1,", `,0
      `])), v.x, v.y, a, a, a * 2, a, a, -a * 2) : nk({
      cx: t,
      cy: r,
      innerRadius: n,
      outerRadius: i,
      startAngle: u,
      endAngle: s
    });
  var b = Ce(Wx || (Wx = Ci(["M ", ",", `
    A`, ",", ",0,0,", ",", ",", `
    A`, ",", ",0,", ",", ",", ",", `
    A`, ",", ",0,0,", ",", ",", `
  `])), v.x, v.y, a, a, +(c < 0), f.x, f.y, i, i, +(m > 180), +(c < 0), h.x, h.y, a, a, +(c < 0), y.x, y.y);
  if (n > 0) {
    var {
      circleTangency: x,
      lineTangency: w,
      theta: P
    } = Os({
      cx: t,
      cy: r,
      radius: n,
      angle: u,
      sign: c,
      isExternal: !0,
      cornerRadius: a,
      cornerIsExternal: l
    }), {
      circleTangency: O,
      lineTangency: S,
      theta: E
    } = Os({
      cx: t,
      cy: r,
      radius: n,
      angle: s,
      sign: -c,
      isExternal: !0,
      cornerRadius: a,
      cornerIsExternal: l
    }), k = l ? Math.abs(u - s) : Math.abs(u - s) - P - E;
    if (k < 0 && a === 0)
      return "".concat(b, "L").concat(t, ",").concat(r, "Z");
    b += Ce(Ux || (Ux = Ci(["L", ",", `
      A`, ",", ",0,0,", ",", ",", `
      A`, ",", ",0,", ",", ",", ",", `
      A`, ",", ",0,0,", ",", ",", "Z"])), S.x, S.y, a, a, +(c < 0), O.x, O.y, n, n, +(k > 180), +(c > 0), x.x, x.y, a, a, +(c < 0), w.x, w.y);
  } else
    b += Ce(Vx || (Vx = Ci(["L", ",", "Z"])), t, r);
  return b;
}, mR = {
  cx: 0,
  cy: 0,
  innerRadius: 0,
  outerRadius: 0,
  startAngle: 0,
  endAngle: 0,
  cornerRadius: 0,
  forceCornerRadius: !1,
  cornerIsExternal: !1
}, ik = (e) => {
  var t = ee(e, mR), {
    cx: r,
    cy: n,
    innerRadius: i,
    outerRadius: a,
    cornerRadius: o,
    forceCornerRadius: l,
    cornerIsExternal: u,
    startAngle: s,
    endAngle: c,
    className: f
  } = t;
  if (a < i || s === c)
    return null;
  var v = Y("recharts-sector", f), p = a - i, h = dt(o, p, 0, !0), y;
  return h > 0 && Math.abs(s - c) < 360 ? y = hR({
    cx: r,
    cy: n,
    innerRadius: i,
    outerRadius: a,
    cornerRadius: Math.min(h, p / 2),
    forceCornerRadius: l,
    cornerIsExternal: u,
    startAngle: s,
    endAngle: c
  }) : y = nk({
    cx: r,
    cy: n,
    innerRadius: i,
    outerRadius: a,
    startAngle: s,
    endAngle: c
  }), /* @__PURE__ */ d.createElement("path", wh({}, Ie(t), {
    className: v,
    d: y
  }));
};
function yR(e, t, r) {
  if (e === "horizontal")
    return [{
      x: t.x,
      y: r.top
    }, {
      x: t.x,
      y: r.top + r.height
    }];
  if (e === "vertical")
    return [{
      x: r.left,
      y: t.y
    }, {
      x: r.left + r.width,
      y: t.y
    }];
  if (xE(t)) {
    if (e === "centric") {
      var {
        cx: n,
        cy: i,
        innerRadius: a,
        outerRadius: o,
        angle: l
      } = t, u = ce(n, i, a, l), s = ce(n, i, o, l);
      return [{
        x: u.x,
        y: u.y
      }, {
        x: s.x,
        y: s.y
      }];
    }
    return rk(t);
  }
}
var ak = {}, Iy = {}, ok = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = py;
  function r(n) {
    return t.isSymbol(n) ? NaN : Number(n);
  }
  e.toNumber = r;
})(ok);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = ok;
  function r(n) {
    return n ? (n = t.toNumber(n), n === 1 / 0 || n === -1 / 0 ? (n < 0 ? -1 : 1) * Number.MAX_VALUE : n === n ? n : 0) : n === 0 ? n : 0;
  }
  e.toFinite = r;
})(Iy);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = hy, r = Iy;
  function n(i, a, o) {
    o && typeof o != "number" && t.isIterateeCall(i, a, o) && (a = o = void 0), i = r.toFinite(i), a === void 0 ? (a = i, i = 0) : a = r.toFinite(a), o = o === void 0 ? i < a ? 1 : -1 : r.toFinite(o);
    const l = Math.max(Math.ceil((a - i) / (o || 1)), 0), u = new Array(l);
    for (let s = 0; s < l; s++)
      u[s] = i, i += o;
    return u;
  }
  e.range = n;
})(ak);
var gR = ak.range;
const jy = /* @__PURE__ */ Wt(gR);
function oi(e, t) {
  return e == null || t == null ? NaN : e < t ? -1 : e > t ? 1 : e >= t ? 0 : NaN;
}
function bR(e, t) {
  return e == null || t == null ? NaN : t < e ? -1 : t > e ? 1 : t >= e ? 0 : NaN;
}
function Cy(e) {
  let t, r, n;
  e.length !== 2 ? (t = oi, r = (l, u) => oi(e(l), u), n = (l, u) => e(l) - u) : (t = e === oi || e === bR ? e : xR, r = e, n = e);
  function i(l, u, s = 0, c = l.length) {
    if (s < c) {
      if (t(u, u) !== 0) return c;
      do {
        const f = s + c >>> 1;
        r(l[f], u) < 0 ? s = f + 1 : c = f;
      } while (s < c);
    }
    return s;
  }
  function a(l, u, s = 0, c = l.length) {
    if (s < c) {
      if (t(u, u) !== 0) return c;
      do {
        const f = s + c >>> 1;
        r(l[f], u) <= 0 ? s = f + 1 : c = f;
      } while (s < c);
    }
    return s;
  }
  function o(l, u, s = 0, c = l.length) {
    const f = i(l, u, s, c - 1);
    return f > s && n(l[f - 1], u) > -n(l[f], u) ? f - 1 : f;
  }
  return { left: i, center: o, right: a };
}
function xR() {
  return 0;
}
function lk(e) {
  return e === null ? NaN : +e;
}
function* wR(e, t) {
  for (let r of e)
    r != null && (r = +r) >= r && (yield r);
}
const PR = Cy(oi), Ou = PR.right;
Cy(lk).center;
class Hx extends Map {
  constructor(t, r = ER) {
    if (super(), Object.defineProperties(this, { _intern: { value: /* @__PURE__ */ new Map() }, _key: { value: r } }), t != null) for (const [n, i] of t) this.set(n, i);
  }
  get(t) {
    return super.get(Xx(this, t));
  }
  has(t) {
    return super.has(Xx(this, t));
  }
  set(t, r) {
    return super.set(OR(this, t), r);
  }
  delete(t) {
    return super.delete(SR(this, t));
  }
}
function Xx({ _intern: e, _key: t }, r) {
  const n = t(r);
  return e.has(n) ? e.get(n) : r;
}
function OR({ _intern: e, _key: t }, r) {
  const n = t(r);
  return e.has(n) ? e.get(n) : (e.set(n, r), r);
}
function SR({ _intern: e, _key: t }, r) {
  const n = t(r);
  return e.has(n) && (r = e.get(n), e.delete(n)), r;
}
function ER(e) {
  return e !== null && typeof e == "object" ? e.valueOf() : e;
}
function AR(e = oi) {
  if (e === oi) return uk;
  if (typeof e != "function") throw new TypeError("compare is not a function");
  return (t, r) => {
    const n = e(t, r);
    return n || n === 0 ? n : (e(r, r) === 0) - (e(t, t) === 0);
  };
}
function uk(e, t) {
  return (e == null || !(e >= e)) - (t == null || !(t >= t)) || (e < t ? -1 : e > t ? 1 : 0);
}
const kR = Math.sqrt(50), _R = Math.sqrt(10), IR = Math.sqrt(2);
function Gc(e, t, r) {
  const n = (t - e) / Math.max(0, r), i = Math.floor(Math.log10(n)), a = n / Math.pow(10, i), o = a >= kR ? 10 : a >= _R ? 5 : a >= IR ? 2 : 1;
  let l, u, s;
  return i < 0 ? (s = Math.pow(10, -i) / o, l = Math.round(e * s), u = Math.round(t * s), l / s < e && ++l, u / s > t && --u, s = -s) : (s = Math.pow(10, i) * o, l = Math.round(e / s), u = Math.round(t / s), l * s < e && ++l, u * s > t && --u), u < l && 0.5 <= r && r < 2 ? Gc(e, t, r * 2) : [l, u, s];
}
function Ph(e, t, r) {
  if (t = +t, e = +e, r = +r, !(r > 0)) return [];
  if (e === t) return [e];
  const n = t < e, [i, a, o] = n ? Gc(t, e, r) : Gc(e, t, r);
  if (!(a >= i)) return [];
  const l = a - i + 1, u = new Array(l);
  if (n)
    if (o < 0) for (let s = 0; s < l; ++s) u[s] = (a - s) / -o;
    else for (let s = 0; s < l; ++s) u[s] = (a - s) * o;
  else if (o < 0) for (let s = 0; s < l; ++s) u[s] = (i + s) / -o;
  else for (let s = 0; s < l; ++s) u[s] = (i + s) * o;
  return u;
}
function Oh(e, t, r) {
  return t = +t, e = +e, r = +r, Gc(e, t, r)[2];
}
function Sh(e, t, r) {
  t = +t, e = +e, r = +r;
  const n = t < e, i = n ? Oh(t, e, r) : Oh(e, t, r);
  return (n ? -1 : 1) * (i < 0 ? 1 / -i : i);
}
function Yx(e, t) {
  let r;
  for (const n of e)
    n != null && (r < n || r === void 0 && n >= n) && (r = n);
  return r;
}
function Gx(e, t) {
  let r;
  for (const n of e)
    n != null && (r > n || r === void 0 && n >= n) && (r = n);
  return r;
}
function sk(e, t, r = 0, n = 1 / 0, i) {
  if (t = Math.floor(t), r = Math.floor(Math.max(0, r)), n = Math.floor(Math.min(e.length - 1, n)), !(r <= t && t <= n)) return e;
  for (i = i === void 0 ? uk : AR(i); n > r; ) {
    if (n - r > 600) {
      const u = n - r + 1, s = t - r + 1, c = Math.log(u), f = 0.5 * Math.exp(2 * c / 3), v = 0.5 * Math.sqrt(c * f * (u - f) / u) * (s - u / 2 < 0 ? -1 : 1), p = Math.max(r, Math.floor(t - s * f / u + v)), h = Math.min(n, Math.floor(t + (u - s) * f / u + v));
      sk(e, t, p, h, i);
    }
    const a = e[t];
    let o = r, l = n;
    for (Xo(e, r, t), i(e[n], a) > 0 && Xo(e, r, n); o < l; ) {
      for (Xo(e, o, l), ++o, --l; i(e[o], a) < 0; ) ++o;
      for (; i(e[l], a) > 0; ) --l;
    }
    i(e[r], a) === 0 ? Xo(e, r, l) : (++l, Xo(e, l, n)), l <= t && (r = l + 1), t <= l && (n = l - 1);
  }
  return e;
}
function Xo(e, t, r) {
  const n = e[t];
  e[t] = e[r], e[r] = n;
}
function jR(e, t, r) {
  if (e = Float64Array.from(wR(e)), !(!(n = e.length) || isNaN(t = +t))) {
    if (t <= 0 || n < 2) return Gx(e);
    if (t >= 1) return Yx(e);
    var n, i = (n - 1) * t, a = Math.floor(i), o = Yx(sk(e, a).subarray(0, a + 1)), l = Gx(e.subarray(a + 1));
    return o + (l - o) * (i - a);
  }
}
function CR(e, t, r = lk) {
  if (!(!(n = e.length) || isNaN(t = +t))) {
    if (t <= 0 || n < 2) return +r(e[0], 0, e);
    if (t >= 1) return +r(e[n - 1], n - 1, e);
    var n, i = (n - 1) * t, a = Math.floor(i), o = +r(e[a], a, e), l = +r(e[a + 1], a + 1, e);
    return o + (l - o) * (i - a);
  }
}
function TR(e, t, r) {
  e = +e, t = +t, r = (i = arguments.length) < 2 ? (t = e, e = 0, 1) : i < 3 ? 1 : +r;
  for (var n = -1, i = Math.max(0, Math.ceil((t - e) / r)) | 0, a = new Array(i); ++n < i; )
    a[n] = e + n * r;
  return a;
}
function xr(e, t) {
  switch (arguments.length) {
    case 0:
      break;
    case 1:
      this.range(e);
      break;
    default:
      this.range(t).domain(e);
      break;
  }
  return this;
}
function Rn(e, t) {
  switch (arguments.length) {
    case 0:
      break;
    case 1: {
      typeof e == "function" ? this.interpolator(e) : this.range(e);
      break;
    }
    default: {
      this.domain(e), typeof t == "function" ? this.interpolator(t) : this.range(t);
      break;
    }
  }
  return this;
}
const Eh = Symbol("implicit");
function Ty() {
  var e = new Hx(), t = [], r = [], n = Eh;
  function i(a) {
    let o = e.get(a);
    if (o === void 0) {
      if (n !== Eh) return n;
      e.set(a, o = t.push(a) - 1);
    }
    return r[o % r.length];
  }
  return i.domain = function(a) {
    if (!arguments.length) return t.slice();
    t = [], e = new Hx();
    for (const o of a)
      e.has(o) || e.set(o, t.push(o) - 1);
    return i;
  }, i.range = function(a) {
    return arguments.length ? (r = Array.from(a), i) : r.slice();
  }, i.unknown = function(a) {
    return arguments.length ? (n = a, i) : n;
  }, i.copy = function() {
    return Ty(t, r).unknown(n);
  }, xr.apply(i, arguments), i;
}
function My() {
  var e = Ty().unknown(void 0), t = e.domain, r = e.range, n = 0, i = 1, a, o, l = !1, u = 0, s = 0, c = 0.5;
  delete e.unknown;
  function f() {
    var v = t().length, p = i < n, h = p ? i : n, y = p ? n : i;
    a = (y - h) / Math.max(1, v - u + s * 2), l && (a = Math.floor(a)), h += (y - h - a * (v - u)) * c, o = a * (1 - u), l && (h = Math.round(h), o = Math.round(o));
    var g = TR(v).map(function(m) {
      return h + a * m;
    });
    return r(p ? g.reverse() : g);
  }
  return e.domain = function(v) {
    return arguments.length ? (t(v), f()) : t();
  }, e.range = function(v) {
    return arguments.length ? ([n, i] = v, n = +n, i = +i, f()) : [n, i];
  }, e.rangeRound = function(v) {
    return [n, i] = v, n = +n, i = +i, l = !0, f();
  }, e.bandwidth = function() {
    return o;
  }, e.step = function() {
    return a;
  }, e.round = function(v) {
    return arguments.length ? (l = !!v, f()) : l;
  }, e.padding = function(v) {
    return arguments.length ? (u = Math.min(1, s = +v), f()) : u;
  }, e.paddingInner = function(v) {
    return arguments.length ? (u = Math.min(1, v), f()) : u;
  }, e.paddingOuter = function(v) {
    return arguments.length ? (s = +v, f()) : s;
  }, e.align = function(v) {
    return arguments.length ? (c = Math.max(0, Math.min(1, v)), f()) : c;
  }, e.copy = function() {
    return My(t(), [n, i]).round(l).paddingInner(u).paddingOuter(s).align(c);
  }, xr.apply(f(), arguments);
}
function ck(e) {
  var t = e.copy;
  return e.padding = e.paddingOuter, delete e.paddingInner, delete e.paddingOuter, e.copy = function() {
    return ck(t());
  }, e;
}
function fk() {
  return ck(My.apply(null, arguments).paddingInner(1));
}
function Dy(e, t, r) {
  e.prototype = t.prototype = r, r.constructor = e;
}
function dk(e, t) {
  var r = Object.create(e.prototype);
  for (var n in t) r[n] = t[n];
  return r;
}
function Su() {
}
var Fl = 0.7, qc = 1 / Fl, za = "\\s*([+-]?\\d+)\\s*", Kl = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*", Xr = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*", MR = /^#([0-9a-f]{3,8})$/, DR = new RegExp(`^rgb\\(${za},${za},${za}\\)$`), NR = new RegExp(`^rgb\\(${Xr},${Xr},${Xr}\\)$`), $R = new RegExp(`^rgba\\(${za},${za},${za},${Kl}\\)$`), LR = new RegExp(`^rgba\\(${Xr},${Xr},${Xr},${Kl}\\)$`), RR = new RegExp(`^hsl\\(${Kl},${Xr},${Xr}\\)$`), zR = new RegExp(`^hsla\\(${Kl},${Xr},${Xr},${Kl}\\)$`), qx = {
  aliceblue: 15792383,
  antiquewhite: 16444375,
  aqua: 65535,
  aquamarine: 8388564,
  azure: 15794175,
  beige: 16119260,
  bisque: 16770244,
  black: 0,
  blanchedalmond: 16772045,
  blue: 255,
  blueviolet: 9055202,
  brown: 10824234,
  burlywood: 14596231,
  cadetblue: 6266528,
  chartreuse: 8388352,
  chocolate: 13789470,
  coral: 16744272,
  cornflowerblue: 6591981,
  cornsilk: 16775388,
  crimson: 14423100,
  cyan: 65535,
  darkblue: 139,
  darkcyan: 35723,
  darkgoldenrod: 12092939,
  darkgray: 11119017,
  darkgreen: 25600,
  darkgrey: 11119017,
  darkkhaki: 12433259,
  darkmagenta: 9109643,
  darkolivegreen: 5597999,
  darkorange: 16747520,
  darkorchid: 10040012,
  darkred: 9109504,
  darksalmon: 15308410,
  darkseagreen: 9419919,
  darkslateblue: 4734347,
  darkslategray: 3100495,
  darkslategrey: 3100495,
  darkturquoise: 52945,
  darkviolet: 9699539,
  deeppink: 16716947,
  deepskyblue: 49151,
  dimgray: 6908265,
  dimgrey: 6908265,
  dodgerblue: 2003199,
  firebrick: 11674146,
  floralwhite: 16775920,
  forestgreen: 2263842,
  fuchsia: 16711935,
  gainsboro: 14474460,
  ghostwhite: 16316671,
  gold: 16766720,
  goldenrod: 14329120,
  gray: 8421504,
  green: 32768,
  greenyellow: 11403055,
  grey: 8421504,
  honeydew: 15794160,
  hotpink: 16738740,
  indianred: 13458524,
  indigo: 4915330,
  ivory: 16777200,
  khaki: 15787660,
  lavender: 15132410,
  lavenderblush: 16773365,
  lawngreen: 8190976,
  lemonchiffon: 16775885,
  lightblue: 11393254,
  lightcoral: 15761536,
  lightcyan: 14745599,
  lightgoldenrodyellow: 16448210,
  lightgray: 13882323,
  lightgreen: 9498256,
  lightgrey: 13882323,
  lightpink: 16758465,
  lightsalmon: 16752762,
  lightseagreen: 2142890,
  lightskyblue: 8900346,
  lightslategray: 7833753,
  lightslategrey: 7833753,
  lightsteelblue: 11584734,
  lightyellow: 16777184,
  lime: 65280,
  limegreen: 3329330,
  linen: 16445670,
  magenta: 16711935,
  maroon: 8388608,
  mediumaquamarine: 6737322,
  mediumblue: 205,
  mediumorchid: 12211667,
  mediumpurple: 9662683,
  mediumseagreen: 3978097,
  mediumslateblue: 8087790,
  mediumspringgreen: 64154,
  mediumturquoise: 4772300,
  mediumvioletred: 13047173,
  midnightblue: 1644912,
  mintcream: 16121850,
  mistyrose: 16770273,
  moccasin: 16770229,
  navajowhite: 16768685,
  navy: 128,
  oldlace: 16643558,
  olive: 8421376,
  olivedrab: 7048739,
  orange: 16753920,
  orangered: 16729344,
  orchid: 14315734,
  palegoldenrod: 15657130,
  palegreen: 10025880,
  paleturquoise: 11529966,
  palevioletred: 14381203,
  papayawhip: 16773077,
  peachpuff: 16767673,
  peru: 13468991,
  pink: 16761035,
  plum: 14524637,
  powderblue: 11591910,
  purple: 8388736,
  rebeccapurple: 6697881,
  red: 16711680,
  rosybrown: 12357519,
  royalblue: 4286945,
  saddlebrown: 9127187,
  salmon: 16416882,
  sandybrown: 16032864,
  seagreen: 3050327,
  seashell: 16774638,
  sienna: 10506797,
  silver: 12632256,
  skyblue: 8900331,
  slateblue: 6970061,
  slategray: 7372944,
  slategrey: 7372944,
  snow: 16775930,
  springgreen: 65407,
  steelblue: 4620980,
  tan: 13808780,
  teal: 32896,
  thistle: 14204888,
  tomato: 16737095,
  turquoise: 4251856,
  violet: 15631086,
  wheat: 16113331,
  white: 16777215,
  whitesmoke: 16119285,
  yellow: 16776960,
  yellowgreen: 10145074
};
Dy(Su, Wl, {
  copy(e) {
    return Object.assign(new this.constructor(), this, e);
  },
  displayable() {
    return this.rgb().displayable();
  },
  hex: Zx,
  // Deprecated! Use color.formatHex.
  formatHex: Zx,
  formatHex8: BR,
  formatHsl: FR,
  formatRgb: Qx,
  toString: Qx
});
function Zx() {
  return this.rgb().formatHex();
}
function BR() {
  return this.rgb().formatHex8();
}
function FR() {
  return vk(this).formatHsl();
}
function Qx() {
  return this.rgb().formatRgb();
}
function Wl(e) {
  var t, r;
  return e = (e + "").trim().toLowerCase(), (t = MR.exec(e)) ? (r = t[1].length, t = parseInt(t[1], 16), r === 6 ? Jx(t) : r === 3 ? new Dt(t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, (t & 15) << 4 | t & 15, 1) : r === 8 ? Ss(t >> 24 & 255, t >> 16 & 255, t >> 8 & 255, (t & 255) / 255) : r === 4 ? Ss(t >> 12 & 15 | t >> 8 & 240, t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, ((t & 15) << 4 | t & 15) / 255) : null) : (t = DR.exec(e)) ? new Dt(t[1], t[2], t[3], 1) : (t = NR.exec(e)) ? new Dt(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, 1) : (t = $R.exec(e)) ? Ss(t[1], t[2], t[3], t[4]) : (t = LR.exec(e)) ? Ss(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, t[4]) : (t = RR.exec(e)) ? rw(t[1], t[2] / 100, t[3] / 100, 1) : (t = zR.exec(e)) ? rw(t[1], t[2] / 100, t[3] / 100, t[4]) : qx.hasOwnProperty(e) ? Jx(qx[e]) : e === "transparent" ? new Dt(NaN, NaN, NaN, 0) : null;
}
function Jx(e) {
  return new Dt(e >> 16 & 255, e >> 8 & 255, e & 255, 1);
}
function Ss(e, t, r, n) {
  return n <= 0 && (e = t = r = NaN), new Dt(e, t, r, n);
}
function KR(e) {
  return e instanceof Su || (e = Wl(e)), e ? (e = e.rgb(), new Dt(e.r, e.g, e.b, e.opacity)) : new Dt();
}
function Ah(e, t, r, n) {
  return arguments.length === 1 ? KR(e) : new Dt(e, t, r, n ?? 1);
}
function Dt(e, t, r, n) {
  this.r = +e, this.g = +t, this.b = +r, this.opacity = +n;
}
Dy(Dt, Ah, dk(Su, {
  brighter(e) {
    return e = e == null ? qc : Math.pow(qc, e), new Dt(this.r * e, this.g * e, this.b * e, this.opacity);
  },
  darker(e) {
    return e = e == null ? Fl : Math.pow(Fl, e), new Dt(this.r * e, this.g * e, this.b * e, this.opacity);
  },
  rgb() {
    return this;
  },
  clamp() {
    return new Dt(zi(this.r), zi(this.g), zi(this.b), Zc(this.opacity));
  },
  displayable() {
    return -0.5 <= this.r && this.r < 255.5 && -0.5 <= this.g && this.g < 255.5 && -0.5 <= this.b && this.b < 255.5 && 0 <= this.opacity && this.opacity <= 1;
  },
  hex: ew,
  // Deprecated! Use color.formatHex.
  formatHex: ew,
  formatHex8: WR,
  formatRgb: tw,
  toString: tw
}));
function ew() {
  return `#${Ti(this.r)}${Ti(this.g)}${Ti(this.b)}`;
}
function WR() {
  return `#${Ti(this.r)}${Ti(this.g)}${Ti(this.b)}${Ti((isNaN(this.opacity) ? 1 : this.opacity) * 255)}`;
}
function tw() {
  const e = Zc(this.opacity);
  return `${e === 1 ? "rgb(" : "rgba("}${zi(this.r)}, ${zi(this.g)}, ${zi(this.b)}${e === 1 ? ")" : `, ${e})`}`;
}
function Zc(e) {
  return isNaN(e) ? 1 : Math.max(0, Math.min(1, e));
}
function zi(e) {
  return Math.max(0, Math.min(255, Math.round(e) || 0));
}
function Ti(e) {
  return e = zi(e), (e < 16 ? "0" : "") + e.toString(16);
}
function rw(e, t, r, n) {
  return n <= 0 ? e = t = r = NaN : r <= 0 || r >= 1 ? e = t = NaN : t <= 0 && (e = NaN), new kr(e, t, r, n);
}
function vk(e) {
  if (e instanceof kr) return new kr(e.h, e.s, e.l, e.opacity);
  if (e instanceof Su || (e = Wl(e)), !e) return new kr();
  if (e instanceof kr) return e;
  e = e.rgb();
  var t = e.r / 255, r = e.g / 255, n = e.b / 255, i = Math.min(t, r, n), a = Math.max(t, r, n), o = NaN, l = a - i, u = (a + i) / 2;
  return l ? (t === a ? o = (r - n) / l + (r < n) * 6 : r === a ? o = (n - t) / l + 2 : o = (t - r) / l + 4, l /= u < 0.5 ? a + i : 2 - a - i, o *= 60) : l = u > 0 && u < 1 ? 0 : o, new kr(o, l, u, e.opacity);
}
function UR(e, t, r, n) {
  return arguments.length === 1 ? vk(e) : new kr(e, t, r, n ?? 1);
}
function kr(e, t, r, n) {
  this.h = +e, this.s = +t, this.l = +r, this.opacity = +n;
}
Dy(kr, UR, dk(Su, {
  brighter(e) {
    return e = e == null ? qc : Math.pow(qc, e), new kr(this.h, this.s, this.l * e, this.opacity);
  },
  darker(e) {
    return e = e == null ? Fl : Math.pow(Fl, e), new kr(this.h, this.s, this.l * e, this.opacity);
  },
  rgb() {
    var e = this.h % 360 + (this.h < 0) * 360, t = isNaN(e) || isNaN(this.s) ? 0 : this.s, r = this.l, n = r + (r < 0.5 ? r : 1 - r) * t, i = 2 * r - n;
    return new Dt(
      Nv(e >= 240 ? e - 240 : e + 120, i, n),
      Nv(e, i, n),
      Nv(e < 120 ? e + 240 : e - 120, i, n),
      this.opacity
    );
  },
  clamp() {
    return new kr(nw(this.h), Es(this.s), Es(this.l), Zc(this.opacity));
  },
  displayable() {
    return (0 <= this.s && this.s <= 1 || isNaN(this.s)) && 0 <= this.l && this.l <= 1 && 0 <= this.opacity && this.opacity <= 1;
  },
  formatHsl() {
    const e = Zc(this.opacity);
    return `${e === 1 ? "hsl(" : "hsla("}${nw(this.h)}, ${Es(this.s) * 100}%, ${Es(this.l) * 100}%${e === 1 ? ")" : `, ${e})`}`;
  }
}));
function nw(e) {
  return e = (e || 0) % 360, e < 0 ? e + 360 : e;
}
function Es(e) {
  return Math.max(0, Math.min(1, e || 0));
}
function Nv(e, t, r) {
  return (e < 60 ? t + (r - t) * e / 60 : e < 180 ? r : e < 240 ? t + (r - t) * (240 - e) / 60 : t) * 255;
}
const Ny = (e) => () => e;
function VR(e, t) {
  return function(r) {
    return e + r * t;
  };
}
function HR(e, t, r) {
  return e = Math.pow(e, r), t = Math.pow(t, r) - e, r = 1 / r, function(n) {
    return Math.pow(e + n * t, r);
  };
}
function XR(e) {
  return (e = +e) == 1 ? pk : function(t, r) {
    return r - t ? HR(t, r, e) : Ny(isNaN(t) ? r : t);
  };
}
function pk(e, t) {
  var r = t - e;
  return r ? VR(e, r) : Ny(isNaN(e) ? t : e);
}
const iw = function e(t) {
  var r = XR(t);
  function n(i, a) {
    var o = r((i = Ah(i)).r, (a = Ah(a)).r), l = r(i.g, a.g), u = r(i.b, a.b), s = pk(i.opacity, a.opacity);
    return function(c) {
      return i.r = o(c), i.g = l(c), i.b = u(c), i.opacity = s(c), i + "";
    };
  }
  return n.gamma = e, n;
}(1);
function YR(e, t) {
  t || (t = []);
  var r = e ? Math.min(t.length, e.length) : 0, n = t.slice(), i;
  return function(a) {
    for (i = 0; i < r; ++i) n[i] = e[i] * (1 - a) + t[i] * a;
    return n;
  };
}
function GR(e) {
  return ArrayBuffer.isView(e) && !(e instanceof DataView);
}
function qR(e, t) {
  var r = t ? t.length : 0, n = e ? Math.min(r, e.length) : 0, i = new Array(n), a = new Array(r), o;
  for (o = 0; o < n; ++o) i[o] = ho(e[o], t[o]);
  for (; o < r; ++o) a[o] = t[o];
  return function(l) {
    for (o = 0; o < n; ++o) a[o] = i[o](l);
    return a;
  };
}
function ZR(e, t) {
  var r = /* @__PURE__ */ new Date();
  return e = +e, t = +t, function(n) {
    return r.setTime(e * (1 - n) + t * n), r;
  };
}
function Qc(e, t) {
  return e = +e, t = +t, function(r) {
    return e * (1 - r) + t * r;
  };
}
function QR(e, t) {
  var r = {}, n = {}, i;
  (e === null || typeof e != "object") && (e = {}), (t === null || typeof t != "object") && (t = {});
  for (i in t)
    i in e ? r[i] = ho(e[i], t[i]) : n[i] = t[i];
  return function(a) {
    for (i in r) n[i] = r[i](a);
    return n;
  };
}
var kh = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g, $v = new RegExp(kh.source, "g");
function JR(e) {
  return function() {
    return e;
  };
}
function ez(e) {
  return function(t) {
    return e(t) + "";
  };
}
function tz(e, t) {
  var r = kh.lastIndex = $v.lastIndex = 0, n, i, a, o = -1, l = [], u = [];
  for (e = e + "", t = t + ""; (n = kh.exec(e)) && (i = $v.exec(t)); )
    (a = i.index) > r && (a = t.slice(r, a), l[o] ? l[o] += a : l[++o] = a), (n = n[0]) === (i = i[0]) ? l[o] ? l[o] += i : l[++o] = i : (l[++o] = null, u.push({ i: o, x: Qc(n, i) })), r = $v.lastIndex;
  return r < t.length && (a = t.slice(r), l[o] ? l[o] += a : l[++o] = a), l.length < 2 ? u[0] ? ez(u[0].x) : JR(t) : (t = u.length, function(s) {
    for (var c = 0, f; c < t; ++c) l[(f = u[c]).i] = f.x(s);
    return l.join("");
  });
}
function ho(e, t) {
  var r = typeof t, n;
  return t == null || r === "boolean" ? Ny(t) : (r === "number" ? Qc : r === "string" ? (n = Wl(t)) ? (t = n, iw) : tz : t instanceof Wl ? iw : t instanceof Date ? ZR : GR(t) ? YR : Array.isArray(t) ? qR : typeof t.valueOf != "function" && typeof t.toString != "function" || isNaN(t) ? QR : Qc)(e, t);
}
function $y(e, t) {
  return e = +e, t = +t, function(r) {
    return Math.round(e * (1 - r) + t * r);
  };
}
function rz(e, t) {
  t === void 0 && (t = e, e = ho);
  for (var r = 0, n = t.length - 1, i = t[0], a = new Array(n < 0 ? 0 : n); r < n; ) a[r] = e(i, i = t[++r]);
  return function(o) {
    var l = Math.max(0, Math.min(n - 1, Math.floor(o *= n)));
    return a[l](o - l);
  };
}
function nz(e) {
  return function() {
    return e;
  };
}
function Jc(e) {
  return +e;
}
var aw = [0, 1];
function Et(e) {
  return e;
}
function _h(e, t) {
  return (t -= e = +e) ? function(r) {
    return (r - e) / t;
  } : nz(isNaN(t) ? NaN : 0.5);
}
function iz(e, t) {
  var r;
  return e > t && (r = e, e = t, t = r), function(n) {
    return Math.max(e, Math.min(t, n));
  };
}
function az(e, t, r) {
  var n = e[0], i = e[1], a = t[0], o = t[1];
  return i < n ? (n = _h(i, n), a = r(o, a)) : (n = _h(n, i), a = r(a, o)), function(l) {
    return a(n(l));
  };
}
function oz(e, t, r) {
  var n = Math.min(e.length, t.length) - 1, i = new Array(n), a = new Array(n), o = -1;
  for (e[n] < e[0] && (e = e.slice().reverse(), t = t.slice().reverse()); ++o < n; )
    i[o] = _h(e[o], e[o + 1]), a[o] = r(t[o], t[o + 1]);
  return function(l) {
    var u = Ou(e, l, 1, n) - 1;
    return a[u](i[u](l));
  };
}
function Eu(e, t) {
  return t.domain(e.domain()).range(e.range()).interpolate(e.interpolate()).clamp(e.clamp()).unknown(e.unknown());
}
function vd() {
  var e = aw, t = aw, r = ho, n, i, a, o = Et, l, u, s;
  function c() {
    var v = Math.min(e.length, t.length);
    return o !== Et && (o = iz(e[0], e[v - 1])), l = v > 2 ? oz : az, u = s = null, f;
  }
  function f(v) {
    return v == null || isNaN(v = +v) ? a : (u || (u = l(e.map(n), t, r)))(n(o(v)));
  }
  return f.invert = function(v) {
    return o(i((s || (s = l(t, e.map(n), Qc)))(v)));
  }, f.domain = function(v) {
    return arguments.length ? (e = Array.from(v, Jc), c()) : e.slice();
  }, f.range = function(v) {
    return arguments.length ? (t = Array.from(v), c()) : t.slice();
  }, f.rangeRound = function(v) {
    return t = Array.from(v), r = $y, c();
  }, f.clamp = function(v) {
    return arguments.length ? (o = v ? !0 : Et, c()) : o !== Et;
  }, f.interpolate = function(v) {
    return arguments.length ? (r = v, c()) : r;
  }, f.unknown = function(v) {
    return arguments.length ? (a = v, f) : a;
  }, function(v, p) {
    return n = v, i = p, c();
  };
}
function Ly() {
  return vd()(Et, Et);
}
function lz(e) {
  return Math.abs(e = Math.round(e)) >= 1e21 ? e.toLocaleString("en").replace(/,/g, "") : e.toString(10);
}
function ef(e, t) {
  if ((r = (e = t ? e.toExponential(t - 1) : e.toExponential()).indexOf("e")) < 0) return null;
  var r, n = e.slice(0, r);
  return [
    n.length > 1 ? n[0] + n.slice(2) : n,
    +e.slice(r + 1)
  ];
}
function eo(e) {
  return e = ef(Math.abs(e)), e ? e[1] : NaN;
}
function uz(e, t) {
  return function(r, n) {
    for (var i = r.length, a = [], o = 0, l = e[0], u = 0; i > 0 && l > 0 && (u + l + 1 > n && (l = Math.max(1, n - u)), a.push(r.substring(i -= l, i + l)), !((u += l + 1) > n)); )
      l = e[o = (o + 1) % e.length];
    return a.reverse().join(t);
  };
}
function sz(e) {
  return function(t) {
    return t.replace(/[0-9]/g, function(r) {
      return e[+r];
    });
  };
}
var cz = /^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;
function Ul(e) {
  if (!(t = cz.exec(e))) throw new Error("invalid format: " + e);
  var t;
  return new Ry({
    fill: t[1],
    align: t[2],
    sign: t[3],
    symbol: t[4],
    zero: t[5],
    width: t[6],
    comma: t[7],
    precision: t[8] && t[8].slice(1),
    trim: t[9],
    type: t[10]
  });
}
Ul.prototype = Ry.prototype;
function Ry(e) {
  this.fill = e.fill === void 0 ? " " : e.fill + "", this.align = e.align === void 0 ? ">" : e.align + "", this.sign = e.sign === void 0 ? "-" : e.sign + "", this.symbol = e.symbol === void 0 ? "" : e.symbol + "", this.zero = !!e.zero, this.width = e.width === void 0 ? void 0 : +e.width, this.comma = !!e.comma, this.precision = e.precision === void 0 ? void 0 : +e.precision, this.trim = !!e.trim, this.type = e.type === void 0 ? "" : e.type + "";
}
Ry.prototype.toString = function() {
  return this.fill + this.align + this.sign + this.symbol + (this.zero ? "0" : "") + (this.width === void 0 ? "" : Math.max(1, this.width | 0)) + (this.comma ? "," : "") + (this.precision === void 0 ? "" : "." + Math.max(0, this.precision | 0)) + (this.trim ? "~" : "") + this.type;
};
function fz(e) {
  e: for (var t = e.length, r = 1, n = -1, i; r < t; ++r)
    switch (e[r]) {
      case ".":
        n = i = r;
        break;
      case "0":
        n === 0 && (n = r), i = r;
        break;
      default:
        if (!+e[r]) break e;
        n > 0 && (n = 0);
        break;
    }
  return n > 0 ? e.slice(0, n) + e.slice(i + 1) : e;
}
var hk;
function dz(e, t) {
  var r = ef(e, t);
  if (!r) return e + "";
  var n = r[0], i = r[1], a = i - (hk = Math.max(-8, Math.min(8, Math.floor(i / 3))) * 3) + 1, o = n.length;
  return a === o ? n : a > o ? n + new Array(a - o + 1).join("0") : a > 0 ? n.slice(0, a) + "." + n.slice(a) : "0." + new Array(1 - a).join("0") + ef(e, Math.max(0, t + a - 1))[0];
}
function ow(e, t) {
  var r = ef(e, t);
  if (!r) return e + "";
  var n = r[0], i = r[1];
  return i < 0 ? "0." + new Array(-i).join("0") + n : n.length > i + 1 ? n.slice(0, i + 1) + "." + n.slice(i + 1) : n + new Array(i - n.length + 2).join("0");
}
const lw = {
  "%": (e, t) => (e * 100).toFixed(t),
  b: (e) => Math.round(e).toString(2),
  c: (e) => e + "",
  d: lz,
  e: (e, t) => e.toExponential(t),
  f: (e, t) => e.toFixed(t),
  g: (e, t) => e.toPrecision(t),
  o: (e) => Math.round(e).toString(8),
  p: (e, t) => ow(e * 100, t),
  r: ow,
  s: dz,
  X: (e) => Math.round(e).toString(16).toUpperCase(),
  x: (e) => Math.round(e).toString(16)
};
function uw(e) {
  return e;
}
var sw = Array.prototype.map, cw = ["y", "z", "a", "f", "p", "n", "µ", "m", "", "k", "M", "G", "T", "P", "E", "Z", "Y"];
function vz(e) {
  var t = e.grouping === void 0 || e.thousands === void 0 ? uw : uz(sw.call(e.grouping, Number), e.thousands + ""), r = e.currency === void 0 ? "" : e.currency[0] + "", n = e.currency === void 0 ? "" : e.currency[1] + "", i = e.decimal === void 0 ? "." : e.decimal + "", a = e.numerals === void 0 ? uw : sz(sw.call(e.numerals, String)), o = e.percent === void 0 ? "%" : e.percent + "", l = e.minus === void 0 ? "−" : e.minus + "", u = e.nan === void 0 ? "NaN" : e.nan + "";
  function s(f) {
    f = Ul(f);
    var v = f.fill, p = f.align, h = f.sign, y = f.symbol, g = f.zero, m = f.width, b = f.comma, x = f.precision, w = f.trim, P = f.type;
    P === "n" ? (b = !0, P = "g") : lw[P] || (x === void 0 && (x = 12), w = !0, P = "g"), (g || v === "0" && p === "=") && (g = !0, v = "0", p = "=");
    var O = y === "$" ? r : y === "#" && /[boxX]/.test(P) ? "0" + P.toLowerCase() : "", S = y === "$" ? n : /[%p]/.test(P) ? o : "", E = lw[P], k = /[defgprs%]/.test(P);
    x = x === void 0 ? 6 : /[gprs]/.test(P) ? Math.max(1, Math.min(21, x)) : Math.max(0, Math.min(20, x));
    function _(I) {
      var j = O, z = S, N, R, V;
      if (P === "c")
        z = E(I) + z, I = "";
      else {
        I = +I;
        var H = I < 0 || 1 / I < 0;
        if (I = isNaN(I) ? u : E(Math.abs(I), x), w && (I = fz(I)), H && +I == 0 && h !== "+" && (H = !1), j = (H ? h === "(" ? h : l : h === "-" || h === "(" ? "" : h) + j, z = (P === "s" ? cw[8 + hk / 3] : "") + z + (H && h === "(" ? ")" : ""), k) {
          for (N = -1, R = I.length; ++N < R; )
            if (V = I.charCodeAt(N), 48 > V || V > 57) {
              z = (V === 46 ? i + I.slice(N + 1) : I.slice(N)) + z, I = I.slice(0, N);
              break;
            }
        }
      }
      b && !g && (I = t(I, 1 / 0));
      var C = j.length + I.length + z.length, D = C < m ? new Array(m - C + 1).join(v) : "";
      switch (b && g && (I = t(D + I, D.length ? m - z.length : 1 / 0), D = ""), p) {
        case "<":
          I = j + I + z + D;
          break;
        case "=":
          I = j + D + I + z;
          break;
        case "^":
          I = D.slice(0, C = D.length >> 1) + j + I + z + D.slice(C);
          break;
        default:
          I = D + j + I + z;
          break;
      }
      return a(I);
    }
    return _.toString = function() {
      return f + "";
    }, _;
  }
  function c(f, v) {
    var p = s((f = Ul(f), f.type = "f", f)), h = Math.max(-8, Math.min(8, Math.floor(eo(v) / 3))) * 3, y = Math.pow(10, -h), g = cw[8 + h / 3];
    return function(m) {
      return p(y * m) + g;
    };
  }
  return {
    format: s,
    formatPrefix: c
  };
}
var As, zy, mk;
pz({
  thousands: ",",
  grouping: [3],
  currency: ["$", ""]
});
function pz(e) {
  return As = vz(e), zy = As.format, mk = As.formatPrefix, As;
}
function hz(e) {
  return Math.max(0, -eo(Math.abs(e)));
}
function mz(e, t) {
  return Math.max(0, Math.max(-8, Math.min(8, Math.floor(eo(t) / 3))) * 3 - eo(Math.abs(e)));
}
function yz(e, t) {
  return e = Math.abs(e), t = Math.abs(t) - e, Math.max(0, eo(t) - eo(e)) + 1;
}
function yk(e, t, r, n) {
  var i = Sh(e, t, r), a;
  switch (n = Ul(n ?? ",f"), n.type) {
    case "s": {
      var o = Math.max(Math.abs(e), Math.abs(t));
      return n.precision == null && !isNaN(a = mz(i, o)) && (n.precision = a), mk(n, o);
    }
    case "":
    case "e":
    case "g":
    case "p":
    case "r": {
      n.precision == null && !isNaN(a = yz(i, Math.max(Math.abs(e), Math.abs(t)))) && (n.precision = a - (n.type === "e"));
      break;
    }
    case "f":
    case "%": {
      n.precision == null && !isNaN(a = hz(i)) && (n.precision = a - (n.type === "%") * 2);
      break;
    }
  }
  return zy(n);
}
function hi(e) {
  var t = e.domain;
  return e.ticks = function(r) {
    var n = t();
    return Ph(n[0], n[n.length - 1], r ?? 10);
  }, e.tickFormat = function(r, n) {
    var i = t();
    return yk(i[0], i[i.length - 1], r ?? 10, n);
  }, e.nice = function(r) {
    r == null && (r = 10);
    var n = t(), i = 0, a = n.length - 1, o = n[i], l = n[a], u, s, c = 10;
    for (l < o && (s = o, o = l, l = s, s = i, i = a, a = s); c-- > 0; ) {
      if (s = Oh(o, l, r), s === u)
        return n[i] = o, n[a] = l, t(n);
      if (s > 0)
        o = Math.floor(o / s) * s, l = Math.ceil(l / s) * s;
      else if (s < 0)
        o = Math.ceil(o * s) / s, l = Math.floor(l * s) / s;
      else
        break;
      u = s;
    }
    return e;
  }, e;
}
function gk() {
  var e = Ly();
  return e.copy = function() {
    return Eu(e, gk());
  }, xr.apply(e, arguments), hi(e);
}
function bk(e) {
  var t;
  function r(n) {
    return n == null || isNaN(n = +n) ? t : n;
  }
  return r.invert = r, r.domain = r.range = function(n) {
    return arguments.length ? (e = Array.from(n, Jc), r) : e.slice();
  }, r.unknown = function(n) {
    return arguments.length ? (t = n, r) : t;
  }, r.copy = function() {
    return bk(e).unknown(t);
  }, e = arguments.length ? Array.from(e, Jc) : [0, 1], hi(r);
}
function xk(e, t) {
  e = e.slice();
  var r = 0, n = e.length - 1, i = e[r], a = e[n], o;
  return a < i && (o = r, r = n, n = o, o = i, i = a, a = o), e[r] = t.floor(i), e[n] = t.ceil(a), e;
}
function fw(e) {
  return Math.log(e);
}
function dw(e) {
  return Math.exp(e);
}
function gz(e) {
  return -Math.log(-e);
}
function bz(e) {
  return -Math.exp(-e);
}
function xz(e) {
  return isFinite(e) ? +("1e" + e) : e < 0 ? 0 : e;
}
function wz(e) {
  return e === 10 ? xz : e === Math.E ? Math.exp : (t) => Math.pow(e, t);
}
function Pz(e) {
  return e === Math.E ? Math.log : e === 10 && Math.log10 || e === 2 && Math.log2 || (e = Math.log(e), (t) => Math.log(t) / e);
}
function vw(e) {
  return (t, r) => -e(-t, r);
}
function By(e) {
  const t = e(fw, dw), r = t.domain;
  let n = 10, i, a;
  function o() {
    return i = Pz(n), a = wz(n), r()[0] < 0 ? (i = vw(i), a = vw(a), e(gz, bz)) : e(fw, dw), t;
  }
  return t.base = function(l) {
    return arguments.length ? (n = +l, o()) : n;
  }, t.domain = function(l) {
    return arguments.length ? (r(l), o()) : r();
  }, t.ticks = (l) => {
    const u = r();
    let s = u[0], c = u[u.length - 1];
    const f = c < s;
    f && ([s, c] = [c, s]);
    let v = i(s), p = i(c), h, y;
    const g = l == null ? 10 : +l;
    let m = [];
    if (!(n % 1) && p - v < g) {
      if (v = Math.floor(v), p = Math.ceil(p), s > 0) {
        for (; v <= p; ++v)
          for (h = 1; h < n; ++h)
            if (y = v < 0 ? h / a(-v) : h * a(v), !(y < s)) {
              if (y > c) break;
              m.push(y);
            }
      } else for (; v <= p; ++v)
        for (h = n - 1; h >= 1; --h)
          if (y = v > 0 ? h / a(-v) : h * a(v), !(y < s)) {
            if (y > c) break;
            m.push(y);
          }
      m.length * 2 < g && (m = Ph(s, c, g));
    } else
      m = Ph(v, p, Math.min(p - v, g)).map(a);
    return f ? m.reverse() : m;
  }, t.tickFormat = (l, u) => {
    if (l == null && (l = 10), u == null && (u = n === 10 ? "s" : ","), typeof u != "function" && (!(n % 1) && (u = Ul(u)).precision == null && (u.trim = !0), u = zy(u)), l === 1 / 0) return u;
    const s = Math.max(1, n * l / t.ticks().length);
    return (c) => {
      let f = c / a(Math.round(i(c)));
      return f * n < n - 0.5 && (f *= n), f <= s ? u(c) : "";
    };
  }, t.nice = () => r(xk(r(), {
    floor: (l) => a(Math.floor(i(l))),
    ceil: (l) => a(Math.ceil(i(l)))
  })), t;
}
function wk() {
  const e = By(vd()).domain([1, 10]);
  return e.copy = () => Eu(e, wk()).base(e.base()), xr.apply(e, arguments), e;
}
function pw(e) {
  return function(t) {
    return Math.sign(t) * Math.log1p(Math.abs(t / e));
  };
}
function hw(e) {
  return function(t) {
    return Math.sign(t) * Math.expm1(Math.abs(t)) * e;
  };
}
function Fy(e) {
  var t = 1, r = e(pw(t), hw(t));
  return r.constant = function(n) {
    return arguments.length ? e(pw(t = +n), hw(t)) : t;
  }, hi(r);
}
function Pk() {
  var e = Fy(vd());
  return e.copy = function() {
    return Eu(e, Pk()).constant(e.constant());
  }, xr.apply(e, arguments);
}
function mw(e) {
  return function(t) {
    return t < 0 ? -Math.pow(-t, e) : Math.pow(t, e);
  };
}
function Oz(e) {
  return e < 0 ? -Math.sqrt(-e) : Math.sqrt(e);
}
function Sz(e) {
  return e < 0 ? -e * e : e * e;
}
function Ky(e) {
  var t = e(Et, Et), r = 1;
  function n() {
    return r === 1 ? e(Et, Et) : r === 0.5 ? e(Oz, Sz) : e(mw(r), mw(1 / r));
  }
  return t.exponent = function(i) {
    return arguments.length ? (r = +i, n()) : r;
  }, hi(t);
}
function Wy() {
  var e = Ky(vd());
  return e.copy = function() {
    return Eu(e, Wy()).exponent(e.exponent());
  }, xr.apply(e, arguments), e;
}
function Ez() {
  return Wy.apply(null, arguments).exponent(0.5);
}
function yw(e) {
  return Math.sign(e) * e * e;
}
function Az(e) {
  return Math.sign(e) * Math.sqrt(Math.abs(e));
}
function Ok() {
  var e = Ly(), t = [0, 1], r = !1, n;
  function i(a) {
    var o = Az(e(a));
    return isNaN(o) ? n : r ? Math.round(o) : o;
  }
  return i.invert = function(a) {
    return e.invert(yw(a));
  }, i.domain = function(a) {
    return arguments.length ? (e.domain(a), i) : e.domain();
  }, i.range = function(a) {
    return arguments.length ? (e.range((t = Array.from(a, Jc)).map(yw)), i) : t.slice();
  }, i.rangeRound = function(a) {
    return i.range(a).round(!0);
  }, i.round = function(a) {
    return arguments.length ? (r = !!a, i) : r;
  }, i.clamp = function(a) {
    return arguments.length ? (e.clamp(a), i) : e.clamp();
  }, i.unknown = function(a) {
    return arguments.length ? (n = a, i) : n;
  }, i.copy = function() {
    return Ok(e.domain(), t).round(r).clamp(e.clamp()).unknown(n);
  }, xr.apply(i, arguments), hi(i);
}
function Sk() {
  var e = [], t = [], r = [], n;
  function i() {
    var o = 0, l = Math.max(1, t.length);
    for (r = new Array(l - 1); ++o < l; ) r[o - 1] = CR(e, o / l);
    return a;
  }
  function a(o) {
    return o == null || isNaN(o = +o) ? n : t[Ou(r, o)];
  }
  return a.invertExtent = function(o) {
    var l = t.indexOf(o);
    return l < 0 ? [NaN, NaN] : [
      l > 0 ? r[l - 1] : e[0],
      l < r.length ? r[l] : e[e.length - 1]
    ];
  }, a.domain = function(o) {
    if (!arguments.length) return e.slice();
    e = [];
    for (let l of o) l != null && !isNaN(l = +l) && e.push(l);
    return e.sort(oi), i();
  }, a.range = function(o) {
    return arguments.length ? (t = Array.from(o), i()) : t.slice();
  }, a.unknown = function(o) {
    return arguments.length ? (n = o, a) : n;
  }, a.quantiles = function() {
    return r.slice();
  }, a.copy = function() {
    return Sk().domain(e).range(t).unknown(n);
  }, xr.apply(a, arguments);
}
function Ek() {
  var e = 0, t = 1, r = 1, n = [0.5], i = [0, 1], a;
  function o(u) {
    return u != null && u <= u ? i[Ou(n, u, 0, r)] : a;
  }
  function l() {
    var u = -1;
    for (n = new Array(r); ++u < r; ) n[u] = ((u + 1) * t - (u - r) * e) / (r + 1);
    return o;
  }
  return o.domain = function(u) {
    return arguments.length ? ([e, t] = u, e = +e, t = +t, l()) : [e, t];
  }, o.range = function(u) {
    return arguments.length ? (r = (i = Array.from(u)).length - 1, l()) : i.slice();
  }, o.invertExtent = function(u) {
    var s = i.indexOf(u);
    return s < 0 ? [NaN, NaN] : s < 1 ? [e, n[0]] : s >= r ? [n[r - 1], t] : [n[s - 1], n[s]];
  }, o.unknown = function(u) {
    return arguments.length && (a = u), o;
  }, o.thresholds = function() {
    return n.slice();
  }, o.copy = function() {
    return Ek().domain([e, t]).range(i).unknown(a);
  }, xr.apply(hi(o), arguments);
}
function Ak() {
  var e = [0.5], t = [0, 1], r, n = 1;
  function i(a) {
    return a != null && a <= a ? t[Ou(e, a, 0, n)] : r;
  }
  return i.domain = function(a) {
    return arguments.length ? (e = Array.from(a), n = Math.min(e.length, t.length - 1), i) : e.slice();
  }, i.range = function(a) {
    return arguments.length ? (t = Array.from(a), n = Math.min(e.length, t.length - 1), i) : t.slice();
  }, i.invertExtent = function(a) {
    var o = t.indexOf(a);
    return [e[o - 1], e[o]];
  }, i.unknown = function(a) {
    return arguments.length ? (r = a, i) : r;
  }, i.copy = function() {
    return Ak().domain(e).range(t).unknown(r);
  }, xr.apply(i, arguments);
}
const Lv = /* @__PURE__ */ new Date(), Rv = /* @__PURE__ */ new Date();
function Ze(e, t, r, n) {
  function i(a) {
    return e(a = arguments.length === 0 ? /* @__PURE__ */ new Date() : /* @__PURE__ */ new Date(+a)), a;
  }
  return i.floor = (a) => (e(a = /* @__PURE__ */ new Date(+a)), a), i.ceil = (a) => (e(a = new Date(a - 1)), t(a, 1), e(a), a), i.round = (a) => {
    const o = i(a), l = i.ceil(a);
    return a - o < l - a ? o : l;
  }, i.offset = (a, o) => (t(a = /* @__PURE__ */ new Date(+a), o == null ? 1 : Math.floor(o)), a), i.range = (a, o, l) => {
    const u = [];
    if (a = i.ceil(a), l = l == null ? 1 : Math.floor(l), !(a < o) || !(l > 0)) return u;
    let s;
    do
      u.push(s = /* @__PURE__ */ new Date(+a)), t(a, l), e(a);
    while (s < a && a < o);
    return u;
  }, i.filter = (a) => Ze((o) => {
    if (o >= o) for (; e(o), !a(o); ) o.setTime(o - 1);
  }, (o, l) => {
    if (o >= o)
      if (l < 0) for (; ++l <= 0; )
        for (; t(o, -1), !a(o); )
          ;
      else for (; --l >= 0; )
        for (; t(o, 1), !a(o); )
          ;
  }), r && (i.count = (a, o) => (Lv.setTime(+a), Rv.setTime(+o), e(Lv), e(Rv), Math.floor(r(Lv, Rv))), i.every = (a) => (a = Math.floor(a), !isFinite(a) || !(a > 0) ? null : a > 1 ? i.filter(n ? (o) => n(o) % a === 0 : (o) => i.count(0, o) % a === 0) : i)), i;
}
const tf = Ze(() => {
}, (e, t) => {
  e.setTime(+e + t);
}, (e, t) => t - e);
tf.every = (e) => (e = Math.floor(e), !isFinite(e) || !(e > 0) ? null : e > 1 ? Ze((t) => {
  t.setTime(Math.floor(t / e) * e);
}, (t, r) => {
  t.setTime(+t + r * e);
}, (t, r) => (r - t) / e) : tf);
tf.range;
const mn = 1e3, dr = mn * 60, yn = dr * 60, In = yn * 24, Uy = In * 7, gw = In * 30, zv = In * 365, Mi = Ze((e) => {
  e.setTime(e - e.getMilliseconds());
}, (e, t) => {
  e.setTime(+e + t * mn);
}, (e, t) => (t - e) / mn, (e) => e.getUTCSeconds());
Mi.range;
const Vy = Ze((e) => {
  e.setTime(e - e.getMilliseconds() - e.getSeconds() * mn);
}, (e, t) => {
  e.setTime(+e + t * dr);
}, (e, t) => (t - e) / dr, (e) => e.getMinutes());
Vy.range;
const Hy = Ze((e) => {
  e.setUTCSeconds(0, 0);
}, (e, t) => {
  e.setTime(+e + t * dr);
}, (e, t) => (t - e) / dr, (e) => e.getUTCMinutes());
Hy.range;
const Xy = Ze((e) => {
  e.setTime(e - e.getMilliseconds() - e.getSeconds() * mn - e.getMinutes() * dr);
}, (e, t) => {
  e.setTime(+e + t * yn);
}, (e, t) => (t - e) / yn, (e) => e.getHours());
Xy.range;
const Yy = Ze((e) => {
  e.setUTCMinutes(0, 0, 0);
}, (e, t) => {
  e.setTime(+e + t * yn);
}, (e, t) => (t - e) / yn, (e) => e.getUTCHours());
Yy.range;
const Au = Ze(
  (e) => e.setHours(0, 0, 0, 0),
  (e, t) => e.setDate(e.getDate() + t),
  (e, t) => (t - e - (t.getTimezoneOffset() - e.getTimezoneOffset()) * dr) / In,
  (e) => e.getDate() - 1
);
Au.range;
const pd = Ze((e) => {
  e.setUTCHours(0, 0, 0, 0);
}, (e, t) => {
  e.setUTCDate(e.getUTCDate() + t);
}, (e, t) => (t - e) / In, (e) => e.getUTCDate() - 1);
pd.range;
const kk = Ze((e) => {
  e.setUTCHours(0, 0, 0, 0);
}, (e, t) => {
  e.setUTCDate(e.getUTCDate() + t);
}, (e, t) => (t - e) / In, (e) => Math.floor(e / In));
kk.range;
function aa(e) {
  return Ze((t) => {
    t.setDate(t.getDate() - (t.getDay() + 7 - e) % 7), t.setHours(0, 0, 0, 0);
  }, (t, r) => {
    t.setDate(t.getDate() + r * 7);
  }, (t, r) => (r - t - (r.getTimezoneOffset() - t.getTimezoneOffset()) * dr) / Uy);
}
const hd = aa(0), rf = aa(1), kz = aa(2), _z = aa(3), to = aa(4), Iz = aa(5), jz = aa(6);
hd.range;
rf.range;
kz.range;
_z.range;
to.range;
Iz.range;
jz.range;
function oa(e) {
  return Ze((t) => {
    t.setUTCDate(t.getUTCDate() - (t.getUTCDay() + 7 - e) % 7), t.setUTCHours(0, 0, 0, 0);
  }, (t, r) => {
    t.setUTCDate(t.getUTCDate() + r * 7);
  }, (t, r) => (r - t) / Uy);
}
const md = oa(0), nf = oa(1), Cz = oa(2), Tz = oa(3), ro = oa(4), Mz = oa(5), Dz = oa(6);
md.range;
nf.range;
Cz.range;
Tz.range;
ro.range;
Mz.range;
Dz.range;
const Gy = Ze((e) => {
  e.setDate(1), e.setHours(0, 0, 0, 0);
}, (e, t) => {
  e.setMonth(e.getMonth() + t);
}, (e, t) => t.getMonth() - e.getMonth() + (t.getFullYear() - e.getFullYear()) * 12, (e) => e.getMonth());
Gy.range;
const qy = Ze((e) => {
  e.setUTCDate(1), e.setUTCHours(0, 0, 0, 0);
}, (e, t) => {
  e.setUTCMonth(e.getUTCMonth() + t);
}, (e, t) => t.getUTCMonth() - e.getUTCMonth() + (t.getUTCFullYear() - e.getUTCFullYear()) * 12, (e) => e.getUTCMonth());
qy.range;
const jn = Ze((e) => {
  e.setMonth(0, 1), e.setHours(0, 0, 0, 0);
}, (e, t) => {
  e.setFullYear(e.getFullYear() + t);
}, (e, t) => t.getFullYear() - e.getFullYear(), (e) => e.getFullYear());
jn.every = (e) => !isFinite(e = Math.floor(e)) || !(e > 0) ? null : Ze((t) => {
  t.setFullYear(Math.floor(t.getFullYear() / e) * e), t.setMonth(0, 1), t.setHours(0, 0, 0, 0);
}, (t, r) => {
  t.setFullYear(t.getFullYear() + r * e);
});
jn.range;
const Cn = Ze((e) => {
  e.setUTCMonth(0, 1), e.setUTCHours(0, 0, 0, 0);
}, (e, t) => {
  e.setUTCFullYear(e.getUTCFullYear() + t);
}, (e, t) => t.getUTCFullYear() - e.getUTCFullYear(), (e) => e.getUTCFullYear());
Cn.every = (e) => !isFinite(e = Math.floor(e)) || !(e > 0) ? null : Ze((t) => {
  t.setUTCFullYear(Math.floor(t.getUTCFullYear() / e) * e), t.setUTCMonth(0, 1), t.setUTCHours(0, 0, 0, 0);
}, (t, r) => {
  t.setUTCFullYear(t.getUTCFullYear() + r * e);
});
Cn.range;
function _k(e, t, r, n, i, a) {
  const o = [
    [Mi, 1, mn],
    [Mi, 5, 5 * mn],
    [Mi, 15, 15 * mn],
    [Mi, 30, 30 * mn],
    [a, 1, dr],
    [a, 5, 5 * dr],
    [a, 15, 15 * dr],
    [a, 30, 30 * dr],
    [i, 1, yn],
    [i, 3, 3 * yn],
    [i, 6, 6 * yn],
    [i, 12, 12 * yn],
    [n, 1, In],
    [n, 2, 2 * In],
    [r, 1, Uy],
    [t, 1, gw],
    [t, 3, 3 * gw],
    [e, 1, zv]
  ];
  function l(s, c, f) {
    const v = c < s;
    v && ([s, c] = [c, s]);
    const p = f && typeof f.range == "function" ? f : u(s, c, f), h = p ? p.range(s, +c + 1) : [];
    return v ? h.reverse() : h;
  }
  function u(s, c, f) {
    const v = Math.abs(c - s) / f, p = Cy(([, , g]) => g).right(o, v);
    if (p === o.length) return e.every(Sh(s / zv, c / zv, f));
    if (p === 0) return tf.every(Math.max(Sh(s, c, f), 1));
    const [h, y] = o[v / o[p - 1][2] < o[p][2] / v ? p - 1 : p];
    return h.every(y);
  }
  return [l, u];
}
const [Nz, $z] = _k(Cn, qy, md, kk, Yy, Hy), [Lz, Rz] = _k(jn, Gy, hd, Au, Xy, Vy);
function Bv(e) {
  if (0 <= e.y && e.y < 100) {
    var t = new Date(-1, e.m, e.d, e.H, e.M, e.S, e.L);
    return t.setFullYear(e.y), t;
  }
  return new Date(e.y, e.m, e.d, e.H, e.M, e.S, e.L);
}
function Fv(e) {
  if (0 <= e.y && e.y < 100) {
    var t = new Date(Date.UTC(-1, e.m, e.d, e.H, e.M, e.S, e.L));
    return t.setUTCFullYear(e.y), t;
  }
  return new Date(Date.UTC(e.y, e.m, e.d, e.H, e.M, e.S, e.L));
}
function Yo(e, t, r) {
  return { y: e, m: t, d: r, H: 0, M: 0, S: 0, L: 0 };
}
function zz(e) {
  var t = e.dateTime, r = e.date, n = e.time, i = e.periods, a = e.days, o = e.shortDays, l = e.months, u = e.shortMonths, s = Go(i), c = qo(i), f = Go(a), v = qo(a), p = Go(o), h = qo(o), y = Go(l), g = qo(l), m = Go(u), b = qo(u), x = {
    a: H,
    A: C,
    b: D,
    B: F,
    c: null,
    d: Sw,
    e: Sw,
    f: uB,
    g: gB,
    G: xB,
    H: aB,
    I: oB,
    j: lB,
    L: Ik,
    m: sB,
    M: cB,
    p: Z,
    q: Q,
    Q: kw,
    s: _w,
    S: fB,
    u: dB,
    U: vB,
    V: pB,
    w: hB,
    W: mB,
    x: null,
    X: null,
    y: yB,
    Y: bB,
    Z: wB,
    "%": Aw
  }, w = {
    a: Be,
    A: be,
    b: Je,
    B: Xe,
    c: null,
    d: Ew,
    e: Ew,
    f: EB,
    g: NB,
    G: LB,
    H: PB,
    I: OB,
    j: SB,
    L: Ck,
    m: AB,
    M: kB,
    p: fe,
    q: No,
    Q: kw,
    s: _w,
    S: _B,
    u: IB,
    U: jB,
    V: CB,
    w: TB,
    W: MB,
    x: null,
    X: null,
    y: DB,
    Y: $B,
    Z: RB,
    "%": Aw
  }, P = {
    a: _,
    A: I,
    b: j,
    B: z,
    c: N,
    d: Pw,
    e: Pw,
    f: tB,
    g: ww,
    G: xw,
    H: Ow,
    I: Ow,
    j: Zz,
    L: eB,
    m: qz,
    M: Qz,
    p: k,
    q: Gz,
    Q: nB,
    s: iB,
    S: Jz,
    u: Uz,
    U: Vz,
    V: Hz,
    w: Wz,
    W: Xz,
    x: R,
    X: V,
    y: ww,
    Y: xw,
    Z: Yz,
    "%": rB
  };
  x.x = O(r, x), x.X = O(n, x), x.c = O(t, x), w.x = O(r, w), w.X = O(n, w), w.c = O(t, w);
  function O(M, te) {
    return function(le) {
      var L = [], jt = -1, xe = 0, Vt = M.length, Ht, wi, f0;
      for (le instanceof Date || (le = /* @__PURE__ */ new Date(+le)); ++jt < Vt; )
        M.charCodeAt(jt) === 37 && (L.push(M.slice(xe, jt)), (wi = bw[Ht = M.charAt(++jt)]) != null ? Ht = M.charAt(++jt) : wi = Ht === "e" ? " " : "0", (f0 = te[Ht]) && (Ht = f0(le, wi)), L.push(Ht), xe = jt + 1);
      return L.push(M.slice(xe, jt)), L.join("");
    };
  }
  function S(M, te) {
    return function(le) {
      var L = Yo(1900, void 0, 1), jt = E(L, M, le += "", 0), xe, Vt;
      if (jt != le.length) return null;
      if ("Q" in L) return new Date(L.Q);
      if ("s" in L) return new Date(L.s * 1e3 + ("L" in L ? L.L : 0));
      if (te && !("Z" in L) && (L.Z = 0), "p" in L && (L.H = L.H % 12 + L.p * 12), L.m === void 0 && (L.m = "q" in L ? L.q : 0), "V" in L) {
        if (L.V < 1 || L.V > 53) return null;
        "w" in L || (L.w = 1), "Z" in L ? (xe = Fv(Yo(L.y, 0, 1)), Vt = xe.getUTCDay(), xe = Vt > 4 || Vt === 0 ? nf.ceil(xe) : nf(xe), xe = pd.offset(xe, (L.V - 1) * 7), L.y = xe.getUTCFullYear(), L.m = xe.getUTCMonth(), L.d = xe.getUTCDate() + (L.w + 6) % 7) : (xe = Bv(Yo(L.y, 0, 1)), Vt = xe.getDay(), xe = Vt > 4 || Vt === 0 ? rf.ceil(xe) : rf(xe), xe = Au.offset(xe, (L.V - 1) * 7), L.y = xe.getFullYear(), L.m = xe.getMonth(), L.d = xe.getDate() + (L.w + 6) % 7);
      } else ("W" in L || "U" in L) && ("w" in L || (L.w = "u" in L ? L.u % 7 : "W" in L ? 1 : 0), Vt = "Z" in L ? Fv(Yo(L.y, 0, 1)).getUTCDay() : Bv(Yo(L.y, 0, 1)).getDay(), L.m = 0, L.d = "W" in L ? (L.w + 6) % 7 + L.W * 7 - (Vt + 5) % 7 : L.w + L.U * 7 - (Vt + 6) % 7);
      return "Z" in L ? (L.H += L.Z / 100 | 0, L.M += L.Z % 100, Fv(L)) : Bv(L);
    };
  }
  function E(M, te, le, L) {
    for (var jt = 0, xe = te.length, Vt = le.length, Ht, wi; jt < xe; ) {
      if (L >= Vt) return -1;
      if (Ht = te.charCodeAt(jt++), Ht === 37) {
        if (Ht = te.charAt(jt++), wi = P[Ht in bw ? te.charAt(jt++) : Ht], !wi || (L = wi(M, le, L)) < 0) return -1;
      } else if (Ht != le.charCodeAt(L++))
        return -1;
    }
    return L;
  }
  function k(M, te, le) {
    var L = s.exec(te.slice(le));
    return L ? (M.p = c.get(L[0].toLowerCase()), le + L[0].length) : -1;
  }
  function _(M, te, le) {
    var L = p.exec(te.slice(le));
    return L ? (M.w = h.get(L[0].toLowerCase()), le + L[0].length) : -1;
  }
  function I(M, te, le) {
    var L = f.exec(te.slice(le));
    return L ? (M.w = v.get(L[0].toLowerCase()), le + L[0].length) : -1;
  }
  function j(M, te, le) {
    var L = m.exec(te.slice(le));
    return L ? (M.m = b.get(L[0].toLowerCase()), le + L[0].length) : -1;
  }
  function z(M, te, le) {
    var L = y.exec(te.slice(le));
    return L ? (M.m = g.get(L[0].toLowerCase()), le + L[0].length) : -1;
  }
  function N(M, te, le) {
    return E(M, t, te, le);
  }
  function R(M, te, le) {
    return E(M, r, te, le);
  }
  function V(M, te, le) {
    return E(M, n, te, le);
  }
  function H(M) {
    return o[M.getDay()];
  }
  function C(M) {
    return a[M.getDay()];
  }
  function D(M) {
    return u[M.getMonth()];
  }
  function F(M) {
    return l[M.getMonth()];
  }
  function Z(M) {
    return i[+(M.getHours() >= 12)];
  }
  function Q(M) {
    return 1 + ~~(M.getMonth() / 3);
  }
  function Be(M) {
    return o[M.getUTCDay()];
  }
  function be(M) {
    return a[M.getUTCDay()];
  }
  function Je(M) {
    return u[M.getUTCMonth()];
  }
  function Xe(M) {
    return l[M.getUTCMonth()];
  }
  function fe(M) {
    return i[+(M.getUTCHours() >= 12)];
  }
  function No(M) {
    return 1 + ~~(M.getUTCMonth() / 3);
  }
  return {
    format: function(M) {
      var te = O(M += "", x);
      return te.toString = function() {
        return M;
      }, te;
    },
    parse: function(M) {
      var te = S(M += "", !1);
      return te.toString = function() {
        return M;
      }, te;
    },
    utcFormat: function(M) {
      var te = O(M += "", w);
      return te.toString = function() {
        return M;
      }, te;
    },
    utcParse: function(M) {
      var te = S(M += "", !0);
      return te.toString = function() {
        return M;
      }, te;
    }
  };
}
var bw = { "-": "", _: " ", 0: "0" }, ot = /^\s*\d+/, Bz = /^%/, Fz = /[\\^$*+?|[\]().{}]/g;
function ue(e, t, r) {
  var n = e < 0 ? "-" : "", i = (n ? -e : e) + "", a = i.length;
  return n + (a < r ? new Array(r - a + 1).join(t) + i : i);
}
function Kz(e) {
  return e.replace(Fz, "\\$&");
}
function Go(e) {
  return new RegExp("^(?:" + e.map(Kz).join("|") + ")", "i");
}
function qo(e) {
  return new Map(e.map((t, r) => [t.toLowerCase(), r]));
}
function Wz(e, t, r) {
  var n = ot.exec(t.slice(r, r + 1));
  return n ? (e.w = +n[0], r + n[0].length) : -1;
}
function Uz(e, t, r) {
  var n = ot.exec(t.slice(r, r + 1));
  return n ? (e.u = +n[0], r + n[0].length) : -1;
}
function Vz(e, t, r) {
  var n = ot.exec(t.slice(r, r + 2));
  return n ? (e.U = +n[0], r + n[0].length) : -1;
}
function Hz(e, t, r) {
  var n = ot.exec(t.slice(r, r + 2));
  return n ? (e.V = +n[0], r + n[0].length) : -1;
}
function Xz(e, t, r) {
  var n = ot.exec(t.slice(r, r + 2));
  return n ? (e.W = +n[0], r + n[0].length) : -1;
}
function xw(e, t, r) {
  var n = ot.exec(t.slice(r, r + 4));
  return n ? (e.y = +n[0], r + n[0].length) : -1;
}
function ww(e, t, r) {
  var n = ot.exec(t.slice(r, r + 2));
  return n ? (e.y = +n[0] + (+n[0] > 68 ? 1900 : 2e3), r + n[0].length) : -1;
}
function Yz(e, t, r) {
  var n = /^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(t.slice(r, r + 6));
  return n ? (e.Z = n[1] ? 0 : -(n[2] + (n[3] || "00")), r + n[0].length) : -1;
}
function Gz(e, t, r) {
  var n = ot.exec(t.slice(r, r + 1));
  return n ? (e.q = n[0] * 3 - 3, r + n[0].length) : -1;
}
function qz(e, t, r) {
  var n = ot.exec(t.slice(r, r + 2));
  return n ? (e.m = n[0] - 1, r + n[0].length) : -1;
}
function Pw(e, t, r) {
  var n = ot.exec(t.slice(r, r + 2));
  return n ? (e.d = +n[0], r + n[0].length) : -1;
}
function Zz(e, t, r) {
  var n = ot.exec(t.slice(r, r + 3));
  return n ? (e.m = 0, e.d = +n[0], r + n[0].length) : -1;
}
function Ow(e, t, r) {
  var n = ot.exec(t.slice(r, r + 2));
  return n ? (e.H = +n[0], r + n[0].length) : -1;
}
function Qz(e, t, r) {
  var n = ot.exec(t.slice(r, r + 2));
  return n ? (e.M = +n[0], r + n[0].length) : -1;
}
function Jz(e, t, r) {
  var n = ot.exec(t.slice(r, r + 2));
  return n ? (e.S = +n[0], r + n[0].length) : -1;
}
function eB(e, t, r) {
  var n = ot.exec(t.slice(r, r + 3));
  return n ? (e.L = +n[0], r + n[0].length) : -1;
}
function tB(e, t, r) {
  var n = ot.exec(t.slice(r, r + 6));
  return n ? (e.L = Math.floor(n[0] / 1e3), r + n[0].length) : -1;
}
function rB(e, t, r) {
  var n = Bz.exec(t.slice(r, r + 1));
  return n ? r + n[0].length : -1;
}
function nB(e, t, r) {
  var n = ot.exec(t.slice(r));
  return n ? (e.Q = +n[0], r + n[0].length) : -1;
}
function iB(e, t, r) {
  var n = ot.exec(t.slice(r));
  return n ? (e.s = +n[0], r + n[0].length) : -1;
}
function Sw(e, t) {
  return ue(e.getDate(), t, 2);
}
function aB(e, t) {
  return ue(e.getHours(), t, 2);
}
function oB(e, t) {
  return ue(e.getHours() % 12 || 12, t, 2);
}
function lB(e, t) {
  return ue(1 + Au.count(jn(e), e), t, 3);
}
function Ik(e, t) {
  return ue(e.getMilliseconds(), t, 3);
}
function uB(e, t) {
  return Ik(e, t) + "000";
}
function sB(e, t) {
  return ue(e.getMonth() + 1, t, 2);
}
function cB(e, t) {
  return ue(e.getMinutes(), t, 2);
}
function fB(e, t) {
  return ue(e.getSeconds(), t, 2);
}
function dB(e) {
  var t = e.getDay();
  return t === 0 ? 7 : t;
}
function vB(e, t) {
  return ue(hd.count(jn(e) - 1, e), t, 2);
}
function jk(e) {
  var t = e.getDay();
  return t >= 4 || t === 0 ? to(e) : to.ceil(e);
}
function pB(e, t) {
  return e = jk(e), ue(to.count(jn(e), e) + (jn(e).getDay() === 4), t, 2);
}
function hB(e) {
  return e.getDay();
}
function mB(e, t) {
  return ue(rf.count(jn(e) - 1, e), t, 2);
}
function yB(e, t) {
  return ue(e.getFullYear() % 100, t, 2);
}
function gB(e, t) {
  return e = jk(e), ue(e.getFullYear() % 100, t, 2);
}
function bB(e, t) {
  return ue(e.getFullYear() % 1e4, t, 4);
}
function xB(e, t) {
  var r = e.getDay();
  return e = r >= 4 || r === 0 ? to(e) : to.ceil(e), ue(e.getFullYear() % 1e4, t, 4);
}
function wB(e) {
  var t = e.getTimezoneOffset();
  return (t > 0 ? "-" : (t *= -1, "+")) + ue(t / 60 | 0, "0", 2) + ue(t % 60, "0", 2);
}
function Ew(e, t) {
  return ue(e.getUTCDate(), t, 2);
}
function PB(e, t) {
  return ue(e.getUTCHours(), t, 2);
}
function OB(e, t) {
  return ue(e.getUTCHours() % 12 || 12, t, 2);
}
function SB(e, t) {
  return ue(1 + pd.count(Cn(e), e), t, 3);
}
function Ck(e, t) {
  return ue(e.getUTCMilliseconds(), t, 3);
}
function EB(e, t) {
  return Ck(e, t) + "000";
}
function AB(e, t) {
  return ue(e.getUTCMonth() + 1, t, 2);
}
function kB(e, t) {
  return ue(e.getUTCMinutes(), t, 2);
}
function _B(e, t) {
  return ue(e.getUTCSeconds(), t, 2);
}
function IB(e) {
  var t = e.getUTCDay();
  return t === 0 ? 7 : t;
}
function jB(e, t) {
  return ue(md.count(Cn(e) - 1, e), t, 2);
}
function Tk(e) {
  var t = e.getUTCDay();
  return t >= 4 || t === 0 ? ro(e) : ro.ceil(e);
}
function CB(e, t) {
  return e = Tk(e), ue(ro.count(Cn(e), e) + (Cn(e).getUTCDay() === 4), t, 2);
}
function TB(e) {
  return e.getUTCDay();
}
function MB(e, t) {
  return ue(nf.count(Cn(e) - 1, e), t, 2);
}
function DB(e, t) {
  return ue(e.getUTCFullYear() % 100, t, 2);
}
function NB(e, t) {
  return e = Tk(e), ue(e.getUTCFullYear() % 100, t, 2);
}
function $B(e, t) {
  return ue(e.getUTCFullYear() % 1e4, t, 4);
}
function LB(e, t) {
  var r = e.getUTCDay();
  return e = r >= 4 || r === 0 ? ro(e) : ro.ceil(e), ue(e.getUTCFullYear() % 1e4, t, 4);
}
function RB() {
  return "+0000";
}
function Aw() {
  return "%";
}
function kw(e) {
  return +e;
}
function _w(e) {
  return Math.floor(+e / 1e3);
}
var da, Mk, Dk;
zB({
  dateTime: "%x, %X",
  date: "%-m/%-d/%Y",
  time: "%-I:%M:%S %p",
  periods: ["AM", "PM"],
  days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
  shortDays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
  months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
  shortMonths: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
});
function zB(e) {
  return da = zz(e), Mk = da.format, da.parse, Dk = da.utcFormat, da.utcParse, da;
}
function BB(e) {
  return new Date(e);
}
function FB(e) {
  return e instanceof Date ? +e : +/* @__PURE__ */ new Date(+e);
}
function Zy(e, t, r, n, i, a, o, l, u, s) {
  var c = Ly(), f = c.invert, v = c.domain, p = s(".%L"), h = s(":%S"), y = s("%I:%M"), g = s("%I %p"), m = s("%a %d"), b = s("%b %d"), x = s("%B"), w = s("%Y");
  function P(O) {
    return (u(O) < O ? p : l(O) < O ? h : o(O) < O ? y : a(O) < O ? g : n(O) < O ? i(O) < O ? m : b : r(O) < O ? x : w)(O);
  }
  return c.invert = function(O) {
    return new Date(f(O));
  }, c.domain = function(O) {
    return arguments.length ? v(Array.from(O, FB)) : v().map(BB);
  }, c.ticks = function(O) {
    var S = v();
    return e(S[0], S[S.length - 1], O ?? 10);
  }, c.tickFormat = function(O, S) {
    return S == null ? P : s(S);
  }, c.nice = function(O) {
    var S = v();
    return (!O || typeof O.range != "function") && (O = t(S[0], S[S.length - 1], O ?? 10)), O ? v(xk(S, O)) : c;
  }, c.copy = function() {
    return Eu(c, Zy(e, t, r, n, i, a, o, l, u, s));
  }, c;
}
function KB() {
  return xr.apply(Zy(Lz, Rz, jn, Gy, hd, Au, Xy, Vy, Mi, Mk).domain([new Date(2e3, 0, 1), new Date(2e3, 0, 2)]), arguments);
}
function WB() {
  return xr.apply(Zy(Nz, $z, Cn, qy, md, pd, Yy, Hy, Mi, Dk).domain([Date.UTC(2e3, 0, 1), Date.UTC(2e3, 0, 2)]), arguments);
}
function yd() {
  var e = 0, t = 1, r, n, i, a, o = Et, l = !1, u;
  function s(f) {
    return f == null || isNaN(f = +f) ? u : o(i === 0 ? 0.5 : (f = (a(f) - r) * i, l ? Math.max(0, Math.min(1, f)) : f));
  }
  s.domain = function(f) {
    return arguments.length ? ([e, t] = f, r = a(e = +e), n = a(t = +t), i = r === n ? 0 : 1 / (n - r), s) : [e, t];
  }, s.clamp = function(f) {
    return arguments.length ? (l = !!f, s) : l;
  }, s.interpolator = function(f) {
    return arguments.length ? (o = f, s) : o;
  };
  function c(f) {
    return function(v) {
      var p, h;
      return arguments.length ? ([p, h] = v, o = f(p, h), s) : [o(0), o(1)];
    };
  }
  return s.range = c(ho), s.rangeRound = c($y), s.unknown = function(f) {
    return arguments.length ? (u = f, s) : u;
  }, function(f) {
    return a = f, r = f(e), n = f(t), i = r === n ? 0 : 1 / (n - r), s;
  };
}
function mi(e, t) {
  return t.domain(e.domain()).interpolator(e.interpolator()).clamp(e.clamp()).unknown(e.unknown());
}
function Nk() {
  var e = hi(yd()(Et));
  return e.copy = function() {
    return mi(e, Nk());
  }, Rn.apply(e, arguments);
}
function $k() {
  var e = By(yd()).domain([1, 10]);
  return e.copy = function() {
    return mi(e, $k()).base(e.base());
  }, Rn.apply(e, arguments);
}
function Lk() {
  var e = Fy(yd());
  return e.copy = function() {
    return mi(e, Lk()).constant(e.constant());
  }, Rn.apply(e, arguments);
}
function Qy() {
  var e = Ky(yd());
  return e.copy = function() {
    return mi(e, Qy()).exponent(e.exponent());
  }, Rn.apply(e, arguments);
}
function UB() {
  return Qy.apply(null, arguments).exponent(0.5);
}
function Rk() {
  var e = [], t = Et;
  function r(n) {
    if (n != null && !isNaN(n = +n)) return t((Ou(e, n, 1) - 1) / (e.length - 1));
  }
  return r.domain = function(n) {
    if (!arguments.length) return e.slice();
    e = [];
    for (let i of n) i != null && !isNaN(i = +i) && e.push(i);
    return e.sort(oi), r;
  }, r.interpolator = function(n) {
    return arguments.length ? (t = n, r) : t;
  }, r.range = function() {
    return e.map((n, i) => t(i / (e.length - 1)));
  }, r.quantiles = function(n) {
    return Array.from({ length: n + 1 }, (i, a) => jR(e, a / n));
  }, r.copy = function() {
    return Rk(t).domain(e);
  }, Rn.apply(r, arguments);
}
function gd() {
  var e = 0, t = 0.5, r = 1, n = 1, i, a, o, l, u, s = Et, c, f = !1, v;
  function p(y) {
    return isNaN(y = +y) ? v : (y = 0.5 + ((y = +c(y)) - a) * (n * y < n * a ? l : u), s(f ? Math.max(0, Math.min(1, y)) : y));
  }
  p.domain = function(y) {
    return arguments.length ? ([e, t, r] = y, i = c(e = +e), a = c(t = +t), o = c(r = +r), l = i === a ? 0 : 0.5 / (a - i), u = a === o ? 0 : 0.5 / (o - a), n = a < i ? -1 : 1, p) : [e, t, r];
  }, p.clamp = function(y) {
    return arguments.length ? (f = !!y, p) : f;
  }, p.interpolator = function(y) {
    return arguments.length ? (s = y, p) : s;
  };
  function h(y) {
    return function(g) {
      var m, b, x;
      return arguments.length ? ([m, b, x] = g, s = rz(y, [m, b, x]), p) : [s(0), s(0.5), s(1)];
    };
  }
  return p.range = h(ho), p.rangeRound = h($y), p.unknown = function(y) {
    return arguments.length ? (v = y, p) : v;
  }, function(y) {
    return c = y, i = y(e), a = y(t), o = y(r), l = i === a ? 0 : 0.5 / (a - i), u = a === o ? 0 : 0.5 / (o - a), n = a < i ? -1 : 1, p;
  };
}
function zk() {
  var e = hi(gd()(Et));
  return e.copy = function() {
    return mi(e, zk());
  }, Rn.apply(e, arguments);
}
function Bk() {
  var e = By(gd()).domain([0.1, 1, 10]);
  return e.copy = function() {
    return mi(e, Bk()).base(e.base());
  }, Rn.apply(e, arguments);
}
function Fk() {
  var e = Fy(gd());
  return e.copy = function() {
    return mi(e, Fk()).constant(e.constant());
  }, Rn.apply(e, arguments);
}
function Jy() {
  var e = Ky(gd());
  return e.copy = function() {
    return mi(e, Jy()).exponent(e.exponent());
  }, Rn.apply(e, arguments);
}
function VB() {
  return Jy.apply(null, arguments).exponent(0.5);
}
const il = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  scaleBand: My,
  scaleDiverging: zk,
  scaleDivergingLog: Bk,
  scaleDivergingPow: Jy,
  scaleDivergingSqrt: VB,
  scaleDivergingSymlog: Fk,
  scaleIdentity: bk,
  scaleImplicit: Eh,
  scaleLinear: gk,
  scaleLog: wk,
  scaleOrdinal: Ty,
  scalePoint: fk,
  scalePow: Wy,
  scaleQuantile: Sk,
  scaleQuantize: Ek,
  scaleRadial: Ok,
  scaleSequential: Nk,
  scaleSequentialLog: $k,
  scaleSequentialPow: Qy,
  scaleSequentialQuantile: Rk,
  scaleSequentialSqrt: UB,
  scaleSequentialSymlog: Lk,
  scaleSqrt: Ez,
  scaleSymlog: Pk,
  scaleThreshold: Ak,
  scaleTime: KB,
  scaleUtc: WB,
  tickFormat: yk
}, Symbol.toStringTag, { value: "Module" }));
var tn = (e) => e.chartData, yi = A([tn], (e) => {
  var t = e.chartData != null ? e.chartData.length - 1 : 0;
  return {
    chartData: e.chartData,
    computedData: e.computedData,
    dataEndIndex: t,
    dataStartIndex: 0
  };
}), bd = (e, t, r, n) => n ? yi(e) : tn(e), Kk = (e, t, r) => r ? yi(e) : tn(e);
function si(e) {
  if (Array.isArray(e) && e.length === 2) {
    var [t, r] = e;
    if (se(t) && se(r))
      return !0;
  }
  return !1;
}
function Iw(e, t, r) {
  return r ? e : [Math.min(e[0], t[0]), Math.max(e[1], t[1])];
}
function Wk(e, t) {
  if (t && typeof e != "function" && Array.isArray(e) && e.length === 2) {
    var [r, n] = e, i, a;
    if (se(r))
      i = r;
    else if (typeof r == "function")
      return;
    if (se(n))
      a = n;
    else if (typeof n == "function")
      return;
    var o = [i, a];
    if (si(o))
      return o;
  }
}
function HB(e, t, r) {
  if (!(!r && t == null)) {
    if (typeof e == "function" && t != null)
      try {
        var n = e(t, r);
        if (si(n))
          return Iw(n, t, r);
      } catch {
      }
    if (Array.isArray(e) && e.length === 2) {
      var [i, a] = e, o, l;
      if (i === "auto")
        t != null && (o = Math.min(...t));
      else if (B(i))
        o = i;
      else if (typeof i == "function")
        try {
          t != null && (o = i(t == null ? void 0 : t[0]));
        } catch {
        }
      else if (typeof i == "string" && Yb.test(i)) {
        var u = Yb.exec(i);
        if (u == null || u[1] == null || t == null)
          o = void 0;
        else {
          var s = +u[1];
          o = t[0] - s;
        }
      } else
        o = t == null ? void 0 : t[0];
      if (a === "auto")
        t != null && (l = Math.max(...t));
      else if (B(a))
        l = a;
      else if (typeof a == "function")
        try {
          t != null && (l = a(t == null ? void 0 : t[1]));
        } catch {
        }
      else if (typeof a == "string" && Gb.test(a)) {
        var c = Gb.exec(a);
        if (c == null || c[1] == null || t == null)
          l = void 0;
        else {
          var f = +c[1];
          l = t[1] + f;
        }
      } else
        l = t == null ? void 0 : t[1];
      var v = [o, l];
      if (si(v))
        return t == null ? v : Iw(v, t, r);
    }
  }
}
var mo = 1e9, XB = {
  // These values must be integers within the stated ranges (inclusive).
  // Most of these values can be changed during run-time using `Decimal.config`.
  // The maximum number of significant digits of the result of a calculation or base conversion.
  // E.g. `Decimal.config({ precision: 20 });`
  precision: 20,
  // 1 to MAX_DIGITS
  // The rounding mode used by default by `toInteger`, `toDecimalPlaces`, `toExponential`,
  // `toFixed`, `toPrecision` and `toSignificantDigits`.
  //
  // ROUND_UP         0 Away from zero.
  // ROUND_DOWN       1 Towards zero.
  // ROUND_CEIL       2 Towards +Infinity.
  // ROUND_FLOOR      3 Towards -Infinity.
  // ROUND_HALF_UP    4 Towards nearest neighbour. If equidistant, up.
  // ROUND_HALF_DOWN  5 Towards nearest neighbour. If equidistant, down.
  // ROUND_HALF_EVEN  6 Towards nearest neighbour. If equidistant, towards even neighbour.
  // ROUND_HALF_CEIL  7 Towards nearest neighbour. If equidistant, towards +Infinity.
  // ROUND_HALF_FLOOR 8 Towards nearest neighbour. If equidistant, towards -Infinity.
  //
  // E.g.
  // `Decimal.rounding = 4;`
  // `Decimal.rounding = Decimal.ROUND_HALF_UP;`
  rounding: 4,
  // 0 to 8
  // The exponent value at and beneath which `toString` returns exponential notation.
  // JavaScript numbers: -7
  toExpNeg: -7,
  // 0 to -MAX_E
  // The exponent value at and above which `toString` returns exponential notation.
  // JavaScript numbers: 21
  toExpPos: 21,
  // 0 to MAX_E
  // The natural logarithm of 10.
  // 115 digits
  LN10: "2.302585092994045684017991454684364207601101488628772976033327900967572609677352480235997205089598298341967784042286"
}, tg, je = !0, yr = "[DecimalError] ", Bi = yr + "Invalid argument: ", eg = yr + "Exponent out of range: ", yo = Math.floor, Ai = Math.pow, YB = /^(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i, Yt, rt = 1e7, Se = 7, Uk = 9007199254740991, af = yo(Uk / Se), W = {};
W.absoluteValue = W.abs = function() {
  var e = new this.constructor(this);
  return e.s && (e.s = 1), e;
};
W.comparedTo = W.cmp = function(e) {
  var t, r, n, i, a = this;
  if (e = new a.constructor(e), a.s !== e.s) return a.s || -e.s;
  if (a.e !== e.e) return a.e > e.e ^ a.s < 0 ? 1 : -1;
  for (n = a.d.length, i = e.d.length, t = 0, r = n < i ? n : i; t < r; ++t)
    if (a.d[t] !== e.d[t]) return a.d[t] > e.d[t] ^ a.s < 0 ? 1 : -1;
  return n === i ? 0 : n > i ^ a.s < 0 ? 1 : -1;
};
W.decimalPlaces = W.dp = function() {
  var e = this, t = e.d.length - 1, r = (t - e.e) * Se;
  if (t = e.d[t], t) for (; t % 10 == 0; t /= 10) r--;
  return r < 0 ? 0 : r;
};
W.dividedBy = W.div = function(e) {
  return wn(this, new this.constructor(e));
};
W.dividedToIntegerBy = W.idiv = function(e) {
  var t = this, r = t.constructor;
  return he(wn(t, new r(e), 0, 1), r.precision);
};
W.equals = W.eq = function(e) {
  return !this.cmp(e);
};
W.exponent = function() {
  return Ue(this);
};
W.greaterThan = W.gt = function(e) {
  return this.cmp(e) > 0;
};
W.greaterThanOrEqualTo = W.gte = function(e) {
  return this.cmp(e) >= 0;
};
W.isInteger = W.isint = function() {
  return this.e > this.d.length - 2;
};
W.isNegative = W.isneg = function() {
  return this.s < 0;
};
W.isPositive = W.ispos = function() {
  return this.s > 0;
};
W.isZero = function() {
  return this.s === 0;
};
W.lessThan = W.lt = function(e) {
  return this.cmp(e) < 0;
};
W.lessThanOrEqualTo = W.lte = function(e) {
  return this.cmp(e) < 1;
};
W.logarithm = W.log = function(e) {
  var t, r = this, n = r.constructor, i = n.precision, a = i + 5;
  if (e === void 0)
    e = new n(10);
  else if (e = new n(e), e.s < 1 || e.eq(Yt)) throw Error(yr + "NaN");
  if (r.s < 1) throw Error(yr + (r.s ? "NaN" : "-Infinity"));
  return r.eq(Yt) ? new n(0) : (je = !1, t = wn(Vl(r, a), Vl(e, a), a), je = !0, he(t, i));
};
W.minus = W.sub = function(e) {
  var t = this;
  return e = new t.constructor(e), t.s == e.s ? Xk(t, e) : Vk(t, (e.s = -e.s, e));
};
W.modulo = W.mod = function(e) {
  var t, r = this, n = r.constructor, i = n.precision;
  if (e = new n(e), !e.s) throw Error(yr + "NaN");
  return r.s ? (je = !1, t = wn(r, e, 0, 1).times(e), je = !0, r.minus(t)) : he(new n(r), i);
};
W.naturalExponential = W.exp = function() {
  return Hk(this);
};
W.naturalLogarithm = W.ln = function() {
  return Vl(this);
};
W.negated = W.neg = function() {
  var e = new this.constructor(this);
  return e.s = -e.s || 0, e;
};
W.plus = W.add = function(e) {
  var t = this;
  return e = new t.constructor(e), t.s == e.s ? Vk(t, e) : Xk(t, (e.s = -e.s, e));
};
W.precision = W.sd = function(e) {
  var t, r, n, i = this;
  if (e !== void 0 && e !== !!e && e !== 1 && e !== 0) throw Error(Bi + e);
  if (t = Ue(i) + 1, n = i.d.length - 1, r = n * Se + 1, n = i.d[n], n) {
    for (; n % 10 == 0; n /= 10) r--;
    for (n = i.d[0]; n >= 10; n /= 10) r++;
  }
  return e && t > r ? t : r;
};
W.squareRoot = W.sqrt = function() {
  var e, t, r, n, i, a, o, l = this, u = l.constructor;
  if (l.s < 1) {
    if (!l.s) return new u(0);
    throw Error(yr + "NaN");
  }
  for (e = Ue(l), je = !1, i = Math.sqrt(+l), i == 0 || i == 1 / 0 ? (t = Ur(l.d), (t.length + e) % 2 == 0 && (t += "0"), i = Math.sqrt(t), e = yo((e + 1) / 2) - (e < 0 || e % 2), i == 1 / 0 ? t = "5e" + e : (t = i.toExponential(), t = t.slice(0, t.indexOf("e") + 1) + e), n = new u(t)) : n = new u(i.toString()), r = u.precision, i = o = r + 3; ; )
    if (a = n, n = a.plus(wn(l, a, o + 2)).times(0.5), Ur(a.d).slice(0, o) === (t = Ur(n.d)).slice(0, o)) {
      if (t = t.slice(o - 3, o + 1), i == o && t == "4999") {
        if (he(a, r + 1, 0), a.times(a).eq(l)) {
          n = a;
          break;
        }
      } else if (t != "9999")
        break;
      o += 4;
    }
  return je = !0, he(n, r);
};
W.times = W.mul = function(e) {
  var t, r, n, i, a, o, l, u, s, c = this, f = c.constructor, v = c.d, p = (e = new f(e)).d;
  if (!c.s || !e.s) return new f(0);
  for (e.s *= c.s, r = c.e + e.e, u = v.length, s = p.length, u < s && (a = v, v = p, p = a, o = u, u = s, s = o), a = [], o = u + s, n = o; n--; ) a.push(0);
  for (n = s; --n >= 0; ) {
    for (t = 0, i = u + n; i > n; )
      l = a[i] + p[n] * v[i - n - 1] + t, a[i--] = l % rt | 0, t = l / rt | 0;
    a[i] = (a[i] + t) % rt | 0;
  }
  for (; !a[--o]; ) a.pop();
  return t ? ++r : a.shift(), e.d = a, e.e = r, je ? he(e, f.precision) : e;
};
W.toDecimalPlaces = W.todp = function(e, t) {
  var r = this, n = r.constructor;
  return r = new n(r), e === void 0 ? r : (qr(e, 0, mo), t === void 0 ? t = n.rounding : qr(t, 0, 8), he(r, e + Ue(r) + 1, t));
};
W.toExponential = function(e, t) {
  var r, n = this, i = n.constructor;
  return e === void 0 ? r = Zi(n, !0) : (qr(e, 0, mo), t === void 0 ? t = i.rounding : qr(t, 0, 8), n = he(new i(n), e + 1, t), r = Zi(n, !0, e + 1)), r;
};
W.toFixed = function(e, t) {
  var r, n, i = this, a = i.constructor;
  return e === void 0 ? Zi(i) : (qr(e, 0, mo), t === void 0 ? t = a.rounding : qr(t, 0, 8), n = he(new a(i), e + Ue(i) + 1, t), r = Zi(n.abs(), !1, e + Ue(n) + 1), i.isneg() && !i.isZero() ? "-" + r : r);
};
W.toInteger = W.toint = function() {
  var e = this, t = e.constructor;
  return he(new t(e), Ue(e) + 1, t.rounding);
};
W.toNumber = function() {
  return +this;
};
W.toPower = W.pow = function(e) {
  var t, r, n, i, a, o, l = this, u = l.constructor, s = 12, c = +(e = new u(e));
  if (!e.s) return new u(Yt);
  if (l = new u(l), !l.s) {
    if (e.s < 1) throw Error(yr + "Infinity");
    return l;
  }
  if (l.eq(Yt)) return l;
  if (n = u.precision, e.eq(Yt)) return he(l, n);
  if (t = e.e, r = e.d.length - 1, o = t >= r, a = l.s, o) {
    if ((r = c < 0 ? -c : c) <= Uk) {
      for (i = new u(Yt), t = Math.ceil(n / Se + 4), je = !1; r % 2 && (i = i.times(l), Cw(i.d, t)), r = yo(r / 2), r !== 0; )
        l = l.times(l), Cw(l.d, t);
      return je = !0, e.s < 0 ? new u(Yt).div(i) : he(i, n);
    }
  } else if (a < 0) throw Error(yr + "NaN");
  return a = a < 0 && e.d[Math.max(t, r)] & 1 ? -1 : 1, l.s = 1, je = !1, i = e.times(Vl(l, n + s)), je = !0, i = Hk(i), i.s = a, i;
};
W.toPrecision = function(e, t) {
  var r, n, i = this, a = i.constructor;
  return e === void 0 ? (r = Ue(i), n = Zi(i, r <= a.toExpNeg || r >= a.toExpPos)) : (qr(e, 1, mo), t === void 0 ? t = a.rounding : qr(t, 0, 8), i = he(new a(i), e, t), r = Ue(i), n = Zi(i, e <= r || r <= a.toExpNeg, e)), n;
};
W.toSignificantDigits = W.tosd = function(e, t) {
  var r = this, n = r.constructor;
  return e === void 0 ? (e = n.precision, t = n.rounding) : (qr(e, 1, mo), t === void 0 ? t = n.rounding : qr(t, 0, 8)), he(new n(r), e, t);
};
W.toString = W.valueOf = W.val = W.toJSON = W[Symbol.for("nodejs.util.inspect.custom")] = function() {
  var e = this, t = Ue(e), r = e.constructor;
  return Zi(e, t <= r.toExpNeg || t >= r.toExpPos);
};
function Vk(e, t) {
  var r, n, i, a, o, l, u, s, c = e.constructor, f = c.precision;
  if (!e.s || !t.s)
    return t.s || (t = new c(e)), je ? he(t, f) : t;
  if (u = e.d, s = t.d, o = e.e, i = t.e, u = u.slice(), a = o - i, a) {
    for (a < 0 ? (n = u, a = -a, l = s.length) : (n = s, i = o, l = u.length), o = Math.ceil(f / Se), l = o > l ? o + 1 : l + 1, a > l && (a = l, n.length = 1), n.reverse(); a--; ) n.push(0);
    n.reverse();
  }
  for (l = u.length, a = s.length, l - a < 0 && (a = l, n = s, s = u, u = n), r = 0; a; )
    r = (u[--a] = u[a] + s[a] + r) / rt | 0, u[a] %= rt;
  for (r && (u.unshift(r), ++i), l = u.length; u[--l] == 0; ) u.pop();
  return t.d = u, t.e = i, je ? he(t, f) : t;
}
function qr(e, t, r) {
  if (e !== ~~e || e < t || e > r)
    throw Error(Bi + e);
}
function Ur(e) {
  var t, r, n, i = e.length - 1, a = "", o = e[0];
  if (i > 0) {
    for (a += o, t = 1; t < i; t++)
      n = e[t] + "", r = Se - n.length, r && (a += Un(r)), a += n;
    o = e[t], n = o + "", r = Se - n.length, r && (a += Un(r));
  } else if (o === 0)
    return "0";
  for (; o % 10 === 0; ) o /= 10;
  return a + o;
}
var wn = /* @__PURE__ */ function() {
  function e(n, i) {
    var a, o = 0, l = n.length;
    for (n = n.slice(); l--; )
      a = n[l] * i + o, n[l] = a % rt | 0, o = a / rt | 0;
    return o && n.unshift(o), n;
  }
  function t(n, i, a, o) {
    var l, u;
    if (a != o)
      u = a > o ? 1 : -1;
    else
      for (l = u = 0; l < a; l++)
        if (n[l] != i[l]) {
          u = n[l] > i[l] ? 1 : -1;
          break;
        }
    return u;
  }
  function r(n, i, a) {
    for (var o = 0; a--; )
      n[a] -= o, o = n[a] < i[a] ? 1 : 0, n[a] = o * rt + n[a] - i[a];
    for (; !n[0] && n.length > 1; ) n.shift();
  }
  return function(n, i, a, o) {
    var l, u, s, c, f, v, p, h, y, g, m, b, x, w, P, O, S, E, k = n.constructor, _ = n.s == i.s ? 1 : -1, I = n.d, j = i.d;
    if (!n.s) return new k(n);
    if (!i.s) throw Error(yr + "Division by zero");
    for (u = n.e - i.e, S = j.length, P = I.length, p = new k(_), h = p.d = [], s = 0; j[s] == (I[s] || 0); ) ++s;
    if (j[s] > (I[s] || 0) && --u, a == null ? b = a = k.precision : o ? b = a + (Ue(n) - Ue(i)) + 1 : b = a, b < 0) return new k(0);
    if (b = b / Se + 2 | 0, s = 0, S == 1)
      for (c = 0, j = j[0], b++; (s < P || c) && b--; s++)
        x = c * rt + (I[s] || 0), h[s] = x / j | 0, c = x % j | 0;
    else {
      for (c = rt / (j[0] + 1) | 0, c > 1 && (j = e(j, c), I = e(I, c), S = j.length, P = I.length), w = S, y = I.slice(0, S), g = y.length; g < S; ) y[g++] = 0;
      E = j.slice(), E.unshift(0), O = j[0], j[1] >= rt / 2 && ++O;
      do
        c = 0, l = t(j, y, S, g), l < 0 ? (m = y[0], S != g && (m = m * rt + (y[1] || 0)), c = m / O | 0, c > 1 ? (c >= rt && (c = rt - 1), f = e(j, c), v = f.length, g = y.length, l = t(f, y, v, g), l == 1 && (c--, r(f, S < v ? E : j, v))) : (c == 0 && (l = c = 1), f = j.slice()), v = f.length, v < g && f.unshift(0), r(y, f, g), l == -1 && (g = y.length, l = t(j, y, S, g), l < 1 && (c++, r(y, S < g ? E : j, g))), g = y.length) : l === 0 && (c++, y = [0]), h[s++] = c, l && y[0] ? y[g++] = I[w] || 0 : (y = [I[w]], g = 1);
      while ((w++ < P || y[0] !== void 0) && b--);
    }
    return h[0] || h.shift(), p.e = u, he(p, o ? a + Ue(p) + 1 : a);
  };
}();
function Hk(e, t) {
  var r, n, i, a, o, l, u = 0, s = 0, c = e.constructor, f = c.precision;
  if (Ue(e) > 16) throw Error(eg + Ue(e));
  if (!e.s) return new c(Yt);
  for (je = !1, l = f, o = new c(0.03125); e.abs().gte(0.1); )
    e = e.times(o), s += 5;
  for (n = Math.log(Ai(2, s)) / Math.LN10 * 2 + 5 | 0, l += n, r = i = a = new c(Yt), c.precision = l; ; ) {
    if (i = he(i.times(e), l), r = r.times(++u), o = a.plus(wn(i, r, l)), Ur(o.d).slice(0, l) === Ur(a.d).slice(0, l)) {
      for (; s--; ) a = he(a.times(a), l);
      return c.precision = f, t == null ? (je = !0, he(a, f)) : a;
    }
    a = o;
  }
}
function Ue(e) {
  for (var t = e.e * Se, r = e.d[0]; r >= 10; r /= 10) t++;
  return t;
}
function Kv(e, t, r) {
  if (t > e.LN10.sd())
    throw je = !0, r && (e.precision = r), Error(yr + "LN10 precision limit exceeded");
  return he(new e(e.LN10), t);
}
function Un(e) {
  for (var t = ""; e--; ) t += "0";
  return t;
}
function Vl(e, t) {
  var r, n, i, a, o, l, u, s, c, f = 1, v = 10, p = e, h = p.d, y = p.constructor, g = y.precision;
  if (p.s < 1) throw Error(yr + (p.s ? "NaN" : "-Infinity"));
  if (p.eq(Yt)) return new y(0);
  if (t == null ? (je = !1, s = g) : s = t, p.eq(10))
    return t == null && (je = !0), Kv(y, s);
  if (s += v, y.precision = s, r = Ur(h), n = r.charAt(0), a = Ue(p), Math.abs(a) < 15e14) {
    for (; n < 7 && n != 1 || n == 1 && r.charAt(1) > 3; )
      p = p.times(e), r = Ur(p.d), n = r.charAt(0), f++;
    a = Ue(p), n > 1 ? (p = new y("0." + r), a++) : p = new y(n + "." + r.slice(1));
  } else
    return u = Kv(y, s + 2, g).times(a + ""), p = Vl(new y(n + "." + r.slice(1)), s - v).plus(u), y.precision = g, t == null ? (je = !0, he(p, g)) : p;
  for (l = o = p = wn(p.minus(Yt), p.plus(Yt), s), c = he(p.times(p), s), i = 3; ; ) {
    if (o = he(o.times(c), s), u = l.plus(wn(o, new y(i), s)), Ur(u.d).slice(0, s) === Ur(l.d).slice(0, s))
      return l = l.times(2), a !== 0 && (l = l.plus(Kv(y, s + 2, g).times(a + ""))), l = wn(l, new y(f), s), y.precision = g, t == null ? (je = !0, he(l, g)) : l;
    l = u, i += 2;
  }
}
function jw(e, t) {
  var r, n, i;
  for ((r = t.indexOf(".")) > -1 && (t = t.replace(".", "")), (n = t.search(/e/i)) > 0 ? (r < 0 && (r = n), r += +t.slice(n + 1), t = t.substring(0, n)) : r < 0 && (r = t.length), n = 0; t.charCodeAt(n) === 48; ) ++n;
  for (i = t.length; t.charCodeAt(i - 1) === 48; ) --i;
  if (t = t.slice(n, i), t) {
    if (i -= n, r = r - n - 1, e.e = yo(r / Se), e.d = [], n = (r + 1) % Se, r < 0 && (n += Se), n < i) {
      for (n && e.d.push(+t.slice(0, n)), i -= Se; n < i; ) e.d.push(+t.slice(n, n += Se));
      t = t.slice(n), n = Se - t.length;
    } else
      n -= i;
    for (; n--; ) t += "0";
    if (e.d.push(+t), je && (e.e > af || e.e < -af)) throw Error(eg + r);
  } else
    e.s = 0, e.e = 0, e.d = [0];
  return e;
}
function he(e, t, r) {
  var n, i, a, o, l, u, s, c, f = e.d;
  for (o = 1, a = f[0]; a >= 10; a /= 10) o++;
  if (n = t - o, n < 0)
    n += Se, i = t, s = f[c = 0];
  else {
    if (c = Math.ceil((n + 1) / Se), a = f.length, c >= a) return e;
    for (s = a = f[c], o = 1; a >= 10; a /= 10) o++;
    n %= Se, i = n - Se + o;
  }
  if (r !== void 0 && (a = Ai(10, o - i - 1), l = s / a % 10 | 0, u = t < 0 || f[c + 1] !== void 0 || s % a, u = r < 4 ? (l || u) && (r == 0 || r == (e.s < 0 ? 3 : 2)) : l > 5 || l == 5 && (r == 4 || u || r == 6 && // Check whether the digit to the left of the rounding digit is odd.
  (n > 0 ? i > 0 ? s / Ai(10, o - i) : 0 : f[c - 1]) % 10 & 1 || r == (e.s < 0 ? 8 : 7))), t < 1 || !f[0])
    return u ? (a = Ue(e), f.length = 1, t = t - a - 1, f[0] = Ai(10, (Se - t % Se) % Se), e.e = yo(-t / Se) || 0) : (f.length = 1, f[0] = e.e = e.s = 0), e;
  if (n == 0 ? (f.length = c, a = 1, c--) : (f.length = c + 1, a = Ai(10, Se - n), f[c] = i > 0 ? (s / Ai(10, o - i) % Ai(10, i) | 0) * a : 0), u)
    for (; ; )
      if (c == 0) {
        (f[0] += a) == rt && (f[0] = 1, ++e.e);
        break;
      } else {
        if (f[c] += a, f[c] != rt) break;
        f[c--] = 0, a = 1;
      }
  for (n = f.length; f[--n] === 0; ) f.pop();
  if (je && (e.e > af || e.e < -af))
    throw Error(eg + Ue(e));
  return e;
}
function Xk(e, t) {
  var r, n, i, a, o, l, u, s, c, f, v = e.constructor, p = v.precision;
  if (!e.s || !t.s)
    return t.s ? t.s = -t.s : t = new v(e), je ? he(t, p) : t;
  if (u = e.d, f = t.d, n = t.e, s = e.e, u = u.slice(), o = s - n, o) {
    for (c = o < 0, c ? (r = u, o = -o, l = f.length) : (r = f, n = s, l = u.length), i = Math.max(Math.ceil(p / Se), l) + 2, o > i && (o = i, r.length = 1), r.reverse(), i = o; i--; ) r.push(0);
    r.reverse();
  } else {
    for (i = u.length, l = f.length, c = i < l, c && (l = i), i = 0; i < l; i++)
      if (u[i] != f[i]) {
        c = u[i] < f[i];
        break;
      }
    o = 0;
  }
  for (c && (r = u, u = f, f = r, t.s = -t.s), l = u.length, i = f.length - l; i > 0; --i) u[l++] = 0;
  for (i = f.length; i > o; ) {
    if (u[--i] < f[i]) {
      for (a = i; a && u[--a] === 0; ) u[a] = rt - 1;
      --u[a], u[i] += rt;
    }
    u[i] -= f[i];
  }
  for (; u[--l] === 0; ) u.pop();
  for (; u[0] === 0; u.shift()) --n;
  return u[0] ? (t.d = u, t.e = n, je ? he(t, p) : t) : new v(0);
}
function Zi(e, t, r) {
  var n, i = Ue(e), a = Ur(e.d), o = a.length;
  return t ? (r && (n = r - o) > 0 ? a = a.charAt(0) + "." + a.slice(1) + Un(n) : o > 1 && (a = a.charAt(0) + "." + a.slice(1)), a = a + (i < 0 ? "e" : "e+") + i) : i < 0 ? (a = "0." + Un(-i - 1) + a, r && (n = r - o) > 0 && (a += Un(n))) : i >= o ? (a += Un(i + 1 - o), r && (n = r - i - 1) > 0 && (a = a + "." + Un(n))) : ((n = i + 1) < o && (a = a.slice(0, n) + "." + a.slice(n)), r && (n = r - o) > 0 && (i + 1 === o && (a += "."), a += Un(n))), e.s < 0 ? "-" + a : a;
}
function Cw(e, t) {
  if (e.length > t)
    return e.length = t, !0;
}
function Yk(e) {
  var t, r, n;
  function i(a) {
    var o = this;
    if (!(o instanceof i)) return new i(a);
    if (o.constructor = i, a instanceof i) {
      o.s = a.s, o.e = a.e, o.d = (a = a.d) ? a.slice() : a;
      return;
    }
    if (typeof a == "number") {
      if (a * 0 !== 0)
        throw Error(Bi + a);
      if (a > 0)
        o.s = 1;
      else if (a < 0)
        a = -a, o.s = -1;
      else {
        o.s = 0, o.e = 0, o.d = [0];
        return;
      }
      if (a === ~~a && a < 1e7) {
        o.e = 0, o.d = [a];
        return;
      }
      return jw(o, a.toString());
    } else if (typeof a != "string")
      throw Error(Bi + a);
    if (a.charCodeAt(0) === 45 ? (a = a.slice(1), o.s = -1) : o.s = 1, YB.test(a)) jw(o, a);
    else throw Error(Bi + a);
  }
  if (i.prototype = W, i.ROUND_UP = 0, i.ROUND_DOWN = 1, i.ROUND_CEIL = 2, i.ROUND_FLOOR = 3, i.ROUND_HALF_UP = 4, i.ROUND_HALF_DOWN = 5, i.ROUND_HALF_EVEN = 6, i.ROUND_HALF_CEIL = 7, i.ROUND_HALF_FLOOR = 8, i.clone = Yk, i.config = i.set = GB, e === void 0 && (e = {}), e)
    for (n = ["precision", "rounding", "toExpNeg", "toExpPos", "LN10"], t = 0; t < n.length; ) e.hasOwnProperty(r = n[t++]) || (e[r] = this[r]);
  return i.config(e), i;
}
function GB(e) {
  if (!e || typeof e != "object")
    throw Error(yr + "Object expected");
  var t, r, n, i = [
    "precision",
    1,
    mo,
    "rounding",
    0,
    8,
    "toExpNeg",
    -1 / 0,
    0,
    "toExpPos",
    0,
    1 / 0
  ];
  for (t = 0; t < i.length; t += 3)
    if ((n = e[r = i[t]]) !== void 0)
      if (yo(n) === n && n >= i[t + 1] && n <= i[t + 2]) this[r] = n;
      else throw Error(Bi + r + ": " + n);
  if ((n = e[r = "LN10"]) !== void 0)
    if (n == Math.LN10) this[r] = new this(n);
    else throw Error(Bi + r + ": " + n);
  return this;
}
var tg = Yk(XB);
Yt = new tg(1);
const de = tg;
var qB = (e) => e, Gk = {}, qk = (e) => e === Gk, Tw = (e) => function t() {
  return arguments.length === 0 || arguments.length === 1 && qk(arguments.length <= 0 ? void 0 : arguments[0]) ? t : e(...arguments);
}, Zk = (e, t) => e === 1 ? t : Tw(function() {
  for (var r = arguments.length, n = new Array(r), i = 0; i < r; i++)
    n[i] = arguments[i];
  var a = n.filter((o) => o !== Gk).length;
  return a >= e ? t(...n) : Zk(e - a, Tw(function() {
    for (var o = arguments.length, l = new Array(o), u = 0; u < o; u++)
      l[u] = arguments[u];
    var s = n.map((c) => qk(c) ? l.shift() : c);
    return t(...s, ...l);
  }));
}), ZB = (e) => Zk(e.length, e), Ih = (e, t) => {
  for (var r = [], n = e; n < t; ++n)
    r[n - e] = n;
  return r;
}, QB = ZB((e, t) => Array.isArray(t) ? t.map(e) : Object.keys(t).map((r) => t[r]).map(e)), JB = function() {
  for (var t = arguments.length, r = new Array(t), n = 0; n < t; n++)
    r[n] = arguments[n];
  if (!r.length)
    return qB;
  var i = r.reverse(), a = i[0], o = i.slice(1);
  return function() {
    return o.reduce((l, u) => u(l), a(...arguments));
  };
};
function Qk(e) {
  var t;
  return e === 0 ? t = 1 : t = Math.floor(new de(e).abs().log(10).toNumber()) + 1, t;
}
function Jk(e, t, r) {
  for (var n = new de(e), i = 0, a = []; n.lt(t) && i < 1e5; )
    a.push(n.toNumber()), n = n.add(r), i++;
  return a;
}
var e_ = (e) => {
  var [t, r] = e, [n, i] = [t, r];
  return t > r && ([n, i] = [r, t]), [n, i];
}, t_ = (e, t, r) => {
  if (e.lte(0))
    return new de(0);
  var n = Qk(e.toNumber()), i = new de(10).pow(n), a = e.div(i), o = n !== 1 ? 0.05 : 0.1, l = new de(Math.ceil(a.div(o).toNumber())).add(r).mul(o), u = l.mul(i);
  return t ? new de(u.toNumber()) : new de(Math.ceil(u.toNumber()));
}, e3 = (e, t, r) => {
  var n = new de(1), i = new de(e);
  if (!i.isint() && r) {
    var a = Math.abs(e);
    a < 1 ? (n = new de(10).pow(Qk(e) - 1), i = new de(Math.floor(i.div(n).toNumber())).mul(n)) : a > 1 && (i = new de(Math.floor(e)));
  } else e === 0 ? i = new de(Math.floor((t - 1) / 2)) : r || (i = new de(Math.floor(e)));
  var o = Math.floor((t - 1) / 2), l = JB(QB((u) => i.add(new de(u - o).mul(n)).toNumber()), Ih);
  return l(0, t);
}, r_ = function(t, r, n, i) {
  var a = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : 0;
  if (!Number.isFinite((r - t) / (n - 1)))
    return {
      step: new de(0),
      tickMin: new de(0),
      tickMax: new de(0)
    };
  var o = t_(new de(r).sub(t).div(n - 1), i, a), l;
  t <= 0 && r >= 0 ? l = new de(0) : (l = new de(t).add(r).div(2), l = l.sub(new de(l).mod(o)));
  var u = Math.ceil(l.sub(t).div(o).toNumber()), s = Math.ceil(new de(r).sub(l).div(o).toNumber()), c = u + s + 1;
  return c > n ? r_(t, r, n, i, a + 1) : (c < n && (s = r > 0 ? s + (n - c) : s, u = r > 0 ? u : u + (n - c)), {
    step: o,
    tickMin: l.sub(new de(u).mul(o)),
    tickMax: l.add(new de(s).mul(o))
  });
}, t3 = function(t) {
  var [r, n] = t, i = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 6, a = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0, o = Math.max(i, 2), [l, u] = e_([r, n]);
  if (l === -1 / 0 || u === 1 / 0) {
    var s = u === 1 / 0 ? [l, ...Ih(0, i - 1).map(() => 1 / 0)] : [...Ih(0, i - 1).map(() => -1 / 0), u];
    return r > n ? s.reverse() : s;
  }
  if (l === u)
    return e3(l, i, a);
  var {
    step: c,
    tickMin: f,
    tickMax: v
  } = r_(l, u, o, a, 0), p = Jk(f, v.add(new de(0.1).mul(c)), c);
  return r > n ? p.reverse() : p;
}, r3 = function(t, r) {
  var [n, i] = t, a = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0, [o, l] = e_([n, i]);
  if (o === -1 / 0 || l === 1 / 0)
    return [n, i];
  if (o === l)
    return [o];
  var u = Math.max(r, 2), s = t_(new de(l).sub(o).div(u - 1), a, 0), c = [...Jk(new de(o), new de(l), s), l];
  return a === !1 && (c = c.map((f) => Math.round(f))), n > i ? c.reverse() : c;
}, xd = (e) => e.rootProps.maxBarSize, n_ = (e) => e.rootProps.barGap, rg = (e) => e.rootProps.barCategoryGap, i_ = (e) => e.rootProps.barSize, go = (e) => e.rootProps.stackOffset, ng = (e) => e.rootProps.reverseStackOrder, ig = (e) => e.options.chartName, wd = (e) => e.rootProps.syncId, a_ = (e) => e.rootProps.syncMethod, Pd = (e) => e.options.eventEmitter, n3 = (e) => e.rootProps.baseValue, ie = {
  /**
   * CartesianGrid and PolarGrid
   */
  grid: -100,
  /**
   * Background of Bar and RadialBar.
   * This is not visible by default but can be enabled by setting background={true} on Bar or RadialBar.
   */
  barBackground: -50,
  /*
   * other chart elements or custom elements without specific zIndex
   * render in here, at zIndex 0
   */
  /**
   * Area, Pie, Radar, and ReferenceArea
   */
  area: 100,
  /**
   * Cursor is embedded inside Tooltip and controlled by it.
   * The Tooltip itself has a separate portal and is not included in the zIndex system;
   * Cursor is the decoration inside the chart area. CursorRectangle is a rectangle box.
   * It renders below bar so that in a stacked bar chart the cursor rectangle does not hide the other bars.
   */
  cursorRectangle: 200,
  /**
   * Bar and RadialBar
   */
  bar: 300,
  /**
   * Line and ReferenceLine, and ErrorBor
   */
  line: 400,
  /**
   * XAxis and YAxis and PolarAngleAxis and PolarRadiusAxis ticks and lines and children
   */
  axis: 500,
  /**
   * Scatter and ReferenceDot,
   * and Dots of Line and Area and Radar if they have dot=true
   */
  scatter: 600,
  /**
   * Hovering over a Bar or RadialBar renders a highlight rectangle
   */
  activeBar: 1e3,
  /**
   * Cursor is embedded inside Tooltip and controlled by it.
   * The Tooltip itself has a separate portal and is not included in the zIndex system;
   * Cursor is the decoration inside the chart area, usually a cross or a box.
   * CursorLine is a line cursor rendered in Line, Area, Scatter, Radar charts.
   * It renders above the Line and Scatter so that it is always visible.
   * It renders below active dot so that the dot is always visible and shows the current point.
   * We're also assuming that the active dot is small enough that it does not fully cover the cursor line.
   *
   * This also applies to the radial cursor in RadialBarChart.
   */
  cursorLine: 1100,
  /**
   * Hovering over a Point in Line, Area, Scatter, Radar renders a highlight dot
   */
  activeDot: 1200,
  /**
   * LabelList and Label, including Axis labels
   */
  label: 2e3
}, Kr = {
  allowDecimals: !1,
  allowDuplicatedCategory: !0,
  // if I set this to false then Tooltip synchronisation stops working in Radar, wtf
  angleAxisId: 0,
  axisLine: !0,
  axisLineType: "polygon",
  cx: 0,
  cy: 0,
  orientation: "outer",
  reversed: !1,
  scale: "auto",
  tick: !0,
  tickLine: !0,
  tickSize: 8,
  type: "category",
  zIndex: ie.axis
}, Ct = {
  allowDataOverflow: !1,
  allowDecimals: !1,
  allowDuplicatedCategory: !0,
  angle: 0,
  axisLine: !0,
  includeHidden: !1,
  hide: !1,
  label: !1,
  orientation: "right",
  radiusAxisId: 0,
  reversed: !1,
  scale: "auto",
  stroke: "#ccc",
  tick: !0,
  tickCount: 5,
  type: "number",
  zIndex: ie.axis
}, Od = (e, t) => {
  if (!(!e || !t))
    return e != null && e.reversed ? [t[1], t[0]] : t;
}, i3 = {
  allowDataOverflow: !1,
  allowDecimals: !1,
  allowDuplicatedCategory: !1,
  // defaultPolarAngleAxisProps.allowDuplicatedCategory has it set to true but the actual axis rendering ignores the prop because reasons,
  dataKey: void 0,
  domain: void 0,
  id: Kr.angleAxisId,
  includeHidden: !1,
  name: void 0,
  reversed: Kr.reversed,
  scale: Kr.scale,
  tick: Kr.tick,
  tickCount: void 0,
  ticks: void 0,
  type: Kr.type,
  unit: void 0
}, a3 = {
  allowDataOverflow: Ct.allowDataOverflow,
  allowDecimals: !1,
  allowDuplicatedCategory: Ct.allowDuplicatedCategory,
  dataKey: void 0,
  domain: void 0,
  id: Ct.radiusAxisId,
  includeHidden: !1,
  name: void 0,
  reversed: !1,
  scale: Ct.scale,
  tick: Ct.tick,
  tickCount: Ct.tickCount,
  ticks: void 0,
  type: Ct.type,
  unit: void 0
}, o3 = {
  allowDataOverflow: !1,
  allowDecimals: !1,
  allowDuplicatedCategory: Kr.allowDuplicatedCategory,
  dataKey: void 0,
  domain: void 0,
  id: Kr.angleAxisId,
  includeHidden: !1,
  name: void 0,
  reversed: !1,
  scale: Kr.scale,
  tick: Kr.tick,
  tickCount: void 0,
  ticks: void 0,
  type: "number",
  unit: void 0
}, l3 = {
  allowDataOverflow: Ct.allowDataOverflow,
  allowDecimals: !1,
  allowDuplicatedCategory: Ct.allowDuplicatedCategory,
  dataKey: void 0,
  domain: void 0,
  id: Ct.radiusAxisId,
  includeHidden: !1,
  name: void 0,
  reversed: !1,
  scale: Ct.scale,
  tick: Ct.tick,
  tickCount: Ct.tickCount,
  ticks: void 0,
  type: "category",
  unit: void 0
}, la = (e, t) => e.polarAxis.angleAxis[t] != null ? e.polarAxis.angleAxis[t] : e.layout.layoutType === "radial" ? o3 : i3, bo = (e, t) => e.polarAxis.radiusAxis[t] != null ? e.polarAxis.radiusAxis[t] : e.layout.layoutType === "radial" ? l3 : a3, Sd = (e) => e.polarOptions, ag = A([Nn, $n, Ve], ek), o_ = A([Sd, ag], (e, t) => {
  if (e != null)
    return dt(e.innerRadius, t, 0);
}), l_ = A([Sd, ag], (e, t) => {
  if (e != null)
    return dt(e.outerRadius, t, t * 0.8);
}), u3 = (e) => {
  if (e == null)
    return [0, 0];
  var {
    startAngle: t,
    endAngle: r
  } = e;
  return [t, r];
}, u_ = A([Sd], u3), s3 = A([la, u_], Od), s_ = A([ag, o_, l_], (e, t, r) => {
  if (!(e == null || t == null || r == null))
    return [t, r];
}), c3 = A([bo, s_], Od), ua = A([q, Sd, o_, l_, Nn, $n], (e, t, r, n, i, a) => {
  if (!(e !== "centric" && e !== "radial" || t == null || r == null || n == null)) {
    var {
      cx: o,
      cy: l,
      startAngle: u,
      endAngle: s
    } = t;
    return {
      cx: dt(o, i, i / 2),
      cy: dt(l, a, a / 2),
      innerRadius: r,
      outerRadius: n,
      startAngle: u,
      endAngle: s,
      clockWise: !1
      // this property look useful, why not use it?
    };
  }
}), ye = (e, t) => t, ku = (e, t, r) => r;
function Ed(e) {
  return e == null ? void 0 : e.id;
}
function og(e, t, r) {
  var {
    chartData: n = []
  } = t, {
    allowDuplicatedCategory: i,
    dataKey: a
  } = r, o = /* @__PURE__ */ new Map();
  return e.forEach((l) => {
    var u, s = (u = l.data) !== null && u !== void 0 ? u : n;
    if (!(s == null || s.length === 0)) {
      var c = Ed(l);
      s.forEach((f, v) => {
        var p = a == null || i ? v : String(G(f, a, null)), h = G(f, l.dataKey, 0), y;
        o.has(p) ? y = o.get(p) : y = {}, Object.assign(y, {
          [c]: h
        }), o.set(p, y);
      });
    }
  }), Array.from(o.values());
}
function _u(e) {
  return "stackId" in e && e.stackId != null && e.dataKey != null;
}
var Ad = (e, t) => e === t ? !0 : e == null || t == null ? !1 : e[0] === t[0] && e[1] === t[1];
function kd(e, t) {
  return Array.isArray(e) && Array.isArray(t) && e.length === 0 && t.length === 0 ? !0 : e === t;
}
function f3(e, t) {
  if (e.length === t.length) {
    for (var r = 0; r < e.length; r++)
      if (e[r] !== t[r])
        return !1;
    return !0;
  }
  return !1;
}
var Qe = (e) => {
  var t = q(e);
  return t === "horizontal" ? "xAxis" : t === "vertical" ? "yAxis" : t === "centric" ? "angleAxis" : "radiusAxis";
}, xo = (e) => e.tooltip.settings.axisId;
function Mw(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function of(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Mw(Object(r), !0).forEach(function(n) {
      d3(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Mw(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function d3(e, t, r) {
  return (t = v3(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function v3(e) {
  var t = p3(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function p3(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var jh = [0, "auto"], et = {
  allowDataOverflow: !1,
  allowDecimals: !0,
  allowDuplicatedCategory: !0,
  angle: 0,
  dataKey: void 0,
  domain: void 0,
  height: 30,
  hide: !0,
  id: 0,
  includeHidden: !1,
  interval: "preserveEnd",
  minTickGap: 5,
  mirror: !1,
  name: void 0,
  orientation: "bottom",
  padding: {
    left: 0,
    right: 0
  },
  reversed: !1,
  scale: "auto",
  tick: !0,
  tickCount: 5,
  tickFormatter: void 0,
  ticks: void 0,
  type: "category",
  unit: void 0
}, c_ = (e, t) => e.cartesianAxis.xAxis[t], rn = (e, t) => {
  var r = c_(e, t);
  return r ?? et;
}, tt = {
  allowDataOverflow: !1,
  allowDecimals: !0,
  allowDuplicatedCategory: !0,
  angle: 0,
  dataKey: void 0,
  domain: jh,
  hide: !0,
  id: 0,
  includeHidden: !1,
  interval: "preserveEnd",
  minTickGap: 5,
  mirror: !1,
  name: void 0,
  orientation: "left",
  padding: {
    top: 0,
    bottom: 0
  },
  reversed: !1,
  scale: "auto",
  tick: !0,
  tickCount: 5,
  tickFormatter: void 0,
  ticks: void 0,
  type: "number",
  unit: void 0,
  width: mu
}, f_ = (e, t) => e.cartesianAxis.yAxis[t], nn = (e, t) => {
  var r = f_(e, t);
  return r ?? tt;
}, gn = {
  domain: [0, "auto"],
  includeHidden: !1,
  reversed: !1,
  allowDataOverflow: !1,
  allowDuplicatedCategory: !1,
  dataKey: void 0,
  id: 0,
  name: "",
  range: [64, 64],
  scale: "auto",
  type: "number",
  unit: ""
}, lg = (e, t) => {
  var r = e.cartesianAxis.zAxis[t];
  return r ?? gn;
}, Ne = (e, t, r) => {
  switch (t) {
    case "xAxis":
      return rn(e, r);
    case "yAxis":
      return nn(e, r);
    case "zAxis":
      return lg(e, r);
    case "angleAxis":
      return la(e, r);
    case "radiusAxis":
      return bo(e, r);
    default:
      throw new Error("Unexpected axis type: ".concat(t));
  }
}, h3 = (e, t, r) => {
  switch (t) {
    case "xAxis":
      return rn(e, r);
    case "yAxis":
      return nn(e, r);
    default:
      throw new Error("Unexpected axis type: ".concat(t));
  }
}, wo = (e, t, r) => {
  switch (t) {
    case "xAxis":
      return rn(e, r);
    case "yAxis":
      return nn(e, r);
    case "angleAxis":
      return la(e, r);
    case "radiusAxis":
      return bo(e, r);
    default:
      throw new Error("Unexpected axis type: ".concat(t));
  }
}, d_ = (e) => e.graphicalItems.cartesianItems.some((t) => t.type === "bar") || e.graphicalItems.polarItems.some((t) => t.type === "radialBar");
function ug(e, t) {
  return (r) => {
    switch (e) {
      case "xAxis":
        return "xAxisId" in r && r.xAxisId === t;
      case "yAxis":
        return "yAxisId" in r && r.yAxisId === t;
      case "zAxis":
        return "zAxisId" in r && r.zAxisId === t;
      case "angleAxis":
        return "angleAxisId" in r && r.angleAxisId === t;
      case "radiusAxis":
        return "radiusAxisId" in r && r.radiusAxisId === t;
      default:
        return !1;
    }
  };
}
var Po = (e) => e.graphicalItems.cartesianItems, m3 = A([ye, ku], ug), sg = (e, t, r) => e.filter(r).filter((n) => (t == null ? void 0 : t.includeHidden) === !0 ? !0 : !n.hide), Iu = A([Po, Ne, m3], sg, {
  memoizeOptions: {
    resultEqualityCheck: kd
  }
}), v_ = A([Iu], (e) => e.filter((t) => t.type === "area" || t.type === "bar").filter(_u)), p_ = (e) => e.filter((t) => !("stackId" in t) || t.stackId === void 0), y3 = A([Iu], p_), cg = (e) => e.map((t) => t.data).filter(Boolean).flat(1), g3 = A([Iu], cg, {
  memoizeOptions: {
    resultEqualityCheck: kd
  }
}), fg = (e, t) => {
  var {
    chartData: r = [],
    dataStartIndex: n,
    dataEndIndex: i
  } = t;
  return e.length > 0 ? e : r.slice(n, i + 1);
}, dg = A([g3, bd], fg), vg = (e, t, r) => (t == null ? void 0 : t.dataKey) != null ? e.map((n) => ({
  value: G(n, t.dataKey)
})) : r.length > 0 ? r.map((n) => n.dataKey).flatMap((n) => e.map((i) => ({
  value: G(i, n)
}))) : e.map((n) => ({
  value: n
})), _d = A([dg, Ne, Iu], vg);
function h_(e, t) {
  switch (e) {
    case "xAxis":
      return t.direction === "x";
    case "yAxis":
      return t.direction === "y";
    default:
      return !1;
  }
}
function Ys(e) {
  if (it(e) || e instanceof Date) {
    var t = Number(e);
    if (se(t))
      return t;
  }
}
function Dw(e) {
  if (Array.isArray(e)) {
    var t = [Ys(e[0]), Ys(e[1])];
    return si(t) ? t : void 0;
  }
  var r = Ys(e);
  if (r != null)
    return [r, r];
}
function Tn(e) {
  return e.map(Ys).filter(ey);
}
function b3(e, t, r) {
  return !r || typeof t != "number" || Pt(t) ? [] : r.length ? Tn(r.flatMap((n) => {
    var i = G(e, n.dataKey), a, o;
    if (Array.isArray(i) ? [a, o] = i : a = o = i, !(!se(a) || !se(o)))
      return [t - a, t + o];
  })) : [];
}
var He = (e) => {
  var t = Qe(e), r = xo(e);
  return wo(e, t, r);
}, ju = A([He], (e) => e == null ? void 0 : e.dataKey), x3 = A([v_, bd, He], og), pg = (e, t, r, n) => {
  var i = {}, a = t.reduce((o, l) => {
    if (l.stackId == null)
      return o;
    var u = o[l.stackId];
    return u == null && (u = []), u.push(l), o[l.stackId] = u, o;
  }, i);
  return Object.fromEntries(Object.entries(a).map((o) => {
    var [l, u] = o, s = n ? [...u].reverse() : u, c = s.map(Ed);
    return [l, {
      // @ts-expect-error getStackedData requires that the input is array of objects, Recharts does not test for that
      stackedData: YN(e, c, r),
      graphicalItems: s
    }];
  }));
}, lf = A([x3, v_, go, ng], pg), m_ = (e, t, r, n) => {
  var {
    dataStartIndex: i,
    dataEndIndex: a
  } = t;
  if (n == null && r !== "zAxis") {
    var o = ZN(e, i, a);
    if (!(o != null && o[0] === 0 && o[1] === 0))
      return o;
  }
}, w3 = A([Ne], (e) => e.allowDataOverflow), hg = (e) => {
  var t;
  if (e == null || !("domain" in e))
    return jh;
  if (e.domain != null)
    return e.domain;
  if ("ticks" in e && e.ticks != null) {
    if (e.type === "number") {
      var r = Tn(e.ticks);
      return [Math.min(...r), Math.max(...r)];
    }
    if (e.type === "category")
      return e.ticks.map(String);
  }
  return (t = e == null ? void 0 : e.domain) !== null && t !== void 0 ? t : jh;
}, mg = A([Ne], hg), yg = A([mg, w3], Wk), P3 = A([lf, tn, ye, yg], m_, {
  memoizeOptions: {
    resultEqualityCheck: Ad
  }
}), Id = (e) => e.errorBars, O3 = (e, t, r) => e.flatMap((n) => t[n.id]).filter(Boolean).filter((n) => h_(r, n)), uf = function() {
  for (var t = arguments.length, r = new Array(t), n = 0; n < t; n++)
    r[n] = arguments[n];
  var i = r.filter(Boolean);
  if (i.length !== 0) {
    var a = i.flat(), o = Math.min(...a), l = Math.max(...a);
    return [o, l];
  }
}, gg = (e, t, r, n, i) => {
  var a, o;
  if (r.length > 0 && e.forEach((l) => {
    r.forEach((u) => {
      var s, c, f = (s = n[u.id]) === null || s === void 0 ? void 0 : s.filter((m) => h_(i, m)), v = G(l, (c = t.dataKey) !== null && c !== void 0 ? c : u.dataKey), p = b3(l, v, f);
      if (p.length >= 2) {
        var h = Math.min(...p), y = Math.max(...p);
        (a == null || h < a) && (a = h), (o == null || y > o) && (o = y);
      }
      var g = Dw(v);
      g != null && (a = a == null ? g[0] : Math.min(a, g[0]), o = o == null ? g[1] : Math.max(o, g[1]));
    });
  }), (t == null ? void 0 : t.dataKey) != null && e.forEach((l) => {
    var u = Dw(G(l, t.dataKey));
    u != null && (a = a == null ? u[0] : Math.min(a, u[0]), o = o == null ? u[1] : Math.max(o, u[1]));
  }), se(a) && se(o))
    return [a, o];
}, S3 = A([dg, Ne, y3, Id, ye], gg, {
  memoizeOptions: {
    resultEqualityCheck: Ad
  }
});
function E3(e) {
  var {
    value: t
  } = e;
  if (it(t) || t instanceof Date)
    return t;
}
var A3 = (e, t, r) => {
  var n = e.map(E3).filter((i) => i != null);
  return r && (t.dataKey == null || t.allowDuplicatedCategory && yE(n)) ? jy(0, e.length) : t.allowDuplicatedCategory ? n : Array.from(new Set(n));
}, y_ = (e) => e.referenceElements.dots, Oo = (e, t, r) => e.filter((n) => n.ifOverflow === "extendDomain").filter((n) => t === "xAxis" ? n.xAxisId === r : n.yAxisId === r), k3 = A([y_, ye, ku], Oo), g_ = (e) => e.referenceElements.areas, _3 = A([g_, ye, ku], Oo), b_ = (e) => e.referenceElements.lines, I3 = A([b_, ye, ku], Oo), x_ = (e, t) => {
  if (e != null) {
    var r = Tn(e.map((n) => t === "xAxis" ? n.x : n.y));
    if (r.length !== 0)
      return [Math.min(...r), Math.max(...r)];
  }
}, j3 = A(k3, ye, x_), w_ = (e, t) => {
  if (e != null) {
    var r = Tn(e.flatMap((n) => [t === "xAxis" ? n.x1 : n.y1, t === "xAxis" ? n.x2 : n.y2]));
    if (r.length !== 0)
      return [Math.min(...r), Math.max(...r)];
  }
}, C3 = A([_3, ye], w_);
function T3(e) {
  var t;
  if (e.x != null)
    return Tn([e.x]);
  var r = (t = e.segment) === null || t === void 0 ? void 0 : t.map((n) => n.x);
  return r == null || r.length === 0 ? [] : Tn(r);
}
function M3(e) {
  var t;
  if (e.y != null)
    return Tn([e.y]);
  var r = (t = e.segment) === null || t === void 0 ? void 0 : t.map((n) => n.y);
  return r == null || r.length === 0 ? [] : Tn(r);
}
var P_ = (e, t) => {
  if (e != null) {
    var r = e.flatMap((n) => t === "xAxis" ? T3(n) : M3(n));
    if (r.length !== 0)
      return [Math.min(...r), Math.max(...r)];
  }
}, D3 = A([I3, ye], P_), N3 = A(j3, D3, C3, (e, t, r) => uf(e, r, t)), bg = (e, t, r, n, i, a, o, l) => {
  if (r != null)
    return r;
  var u = o === "vertical" && l === "xAxis" || o === "horizontal" && l === "yAxis", s = u ? uf(n, a, i) : uf(a, i);
  return HB(t, s, e.allowDataOverflow);
}, $3 = A([Ne, mg, yg, P3, S3, N3, q, ye], bg, {
  memoizeOptions: {
    resultEqualityCheck: Ad
  }
}), L3 = [0, 1], xg = (e, t, r, n, i, a, o) => {
  if (!((e == null || r == null || r.length === 0) && o === void 0)) {
    var {
      dataKey: l,
      type: u
    } = e, s = br(t, a);
    if (s && l == null) {
      var c;
      return jy(0, (c = r == null ? void 0 : r.length) !== null && c !== void 0 ? c : 0);
    }
    return u === "category" ? A3(n, e, s) : i === "expand" ? L3 : o;
  }
}, wg = A([Ne, q, dg, _d, go, ye, $3], xg), O_ = (e, t, r, n, i) => {
  if (e != null) {
    var {
      scale: a,
      type: o
    } = e;
    if (a === "auto")
      return t === "radial" && i === "radiusAxis" ? "band" : t === "radial" && i === "angleAxis" ? "linear" : o === "category" && n && (n.indexOf("LineChart") >= 0 || n.indexOf("AreaChart") >= 0 || n.indexOf("ComposedChart") >= 0 && !r) ? "point" : o === "category" ? "band" : "linear";
    if (typeof a == "string") {
      var l = "scale".concat(fu(a));
      return l in il ? l : "point";
    }
  }
}, gi = A([Ne, q, d_, ig, ye], O_);
function R3(e) {
  if (e != null) {
    if (e in il)
      return il[e]();
    var t = "scale".concat(fu(e));
    if (t in il)
      return il[t]();
  }
}
function jd(e, t, r, n) {
  if (!(r == null || n == null)) {
    if (typeof e.scale == "function")
      return e.scale.copy().domain(r).range(n);
    var i = R3(t);
    if (i != null) {
      var a = i.domain(r).range(n);
      return UN(a), a;
    }
  }
}
var Pg = (e, t, r) => {
  var n = hg(t);
  if (!(r !== "auto" && r !== "linear")) {
    if (t != null && t.tickCount && Array.isArray(n) && (n[0] === "auto" || n[1] === "auto") && si(e))
      return t3(e, t.tickCount, t.allowDecimals);
    if (t != null && t.tickCount && t.type === "number" && si(e))
      return r3(e, t.tickCount, t.allowDecimals);
  }
}, Og = A([wg, wo, gi], Pg), Sg = (e, t, r, n) => {
  if (
    /*
     * Angle axis for some reason uses nice ticks when rendering axis tick labels,
     * but doesn't use nice ticks for extending domain like all the other axes do.
     * Not really sure why? Is there a good reason,
     * or is it just because someone added support for nice ticks to the other axes and forgot this one?
     */
    n !== "angleAxis" && (e == null ? void 0 : e.type) === "number" && si(t) && Array.isArray(r) && r.length > 0
  ) {
    var i = t[0], a = r[0], o = t[1], l = r[r.length - 1];
    return [Math.min(i, a), Math.max(o, l)];
  }
  return t;
}, z3 = A([Ne, wg, Og, ye], Sg), B3 = A(_d, Ne, (e, t) => {
  if (!(!t || t.type !== "number")) {
    var r = 1 / 0, n = Array.from(Tn(e.map((f) => f.value))).sort((f, v) => f - v), i = n[0], a = n[n.length - 1];
    if (i == null || a == null)
      return 1 / 0;
    var o = a - i;
    if (o === 0)
      return 1 / 0;
    for (var l = 0; l < n.length - 1; l++) {
      var u = n[l], s = n[l + 1];
      if (!(u == null || s == null)) {
        var c = s - u;
        r = Math.min(r, c);
      }
    }
    return r / o;
  }
}), S_ = A(B3, q, rg, Ve, (e, t, r, n, i) => i, (e, t, r, n, i) => {
  if (!se(e))
    return 0;
  var a = t === "vertical" ? n.height : n.width;
  if (i === "gap")
    return e * a / 2;
  if (i === "no-gap") {
    var o = dt(r, e * a), l = e * a / 2;
    return l - o - (l - o) / a * o;
  }
  return 0;
}), F3 = (e, t, r) => {
  var n = rn(e, t);
  return n == null || typeof n.padding != "string" ? 0 : S_(e, "xAxis", t, r, n.padding);
}, K3 = (e, t, r) => {
  var n = nn(e, t);
  return n == null || typeof n.padding != "string" ? 0 : S_(e, "yAxis", t, r, n.padding);
}, W3 = A(rn, F3, (e, t) => {
  var r, n;
  if (e == null)
    return {
      left: 0,
      right: 0
    };
  var {
    padding: i
  } = e;
  return typeof i == "string" ? {
    left: t,
    right: t
  } : {
    left: ((r = i.left) !== null && r !== void 0 ? r : 0) + t,
    right: ((n = i.right) !== null && n !== void 0 ? n : 0) + t
  };
}), U3 = A(nn, K3, (e, t) => {
  var r, n;
  if (e == null)
    return {
      top: 0,
      bottom: 0
    };
  var {
    padding: i
  } = e;
  return typeof i == "string" ? {
    top: t,
    bottom: t
  } : {
    top: ((r = i.top) !== null && r !== void 0 ? r : 0) + t,
    bottom: ((n = i.bottom) !== null && n !== void 0 ? n : 0) + t
  };
}), V3 = A([Ve, W3, yu, sd, (e, t, r) => r], (e, t, r, n, i) => {
  var {
    padding: a
  } = n;
  return i ? [a.left, r.width - a.right] : [e.left + t.left, e.left + e.width - t.right];
}), H3 = A([Ve, q, U3, yu, sd, (e, t, r) => r], (e, t, r, n, i, a) => {
  var {
    padding: o
  } = i;
  return a ? [n.height - o.bottom, o.top] : t === "horizontal" ? [e.top + e.height - r.bottom, e.top + r.top] : [e.top + r.top, e.top + e.height - r.bottom];
}), Cu = (e, t, r, n) => {
  var i;
  switch (t) {
    case "xAxis":
      return V3(e, r, n);
    case "yAxis":
      return H3(e, r, n);
    case "zAxis":
      return (i = lg(e, r)) === null || i === void 0 ? void 0 : i.range;
    case "angleAxis":
      return u_(e);
    case "radiusAxis":
      return s_(e, r);
    default:
      return;
  }
}, E_ = A([Ne, Cu], Od), Zr = A([Ne, gi, z3, E_], jd);
A([Iu, Id, ye], O3);
function A_(e, t) {
  return e.id < t.id ? -1 : e.id > t.id ? 1 : 0;
}
var Cd = (e, t) => t, Td = (e, t, r) => r, X3 = A(ld, Cd, Td, (e, t, r) => e.filter((n) => n.orientation === t).filter((n) => n.mirror === r).sort(A_)), Y3 = A(ud, Cd, Td, (e, t, r) => e.filter((n) => n.orientation === t).filter((n) => n.mirror === r).sort(A_)), k_ = (e, t) => ({
  width: e.width,
  height: t.height
}), G3 = (e, t) => {
  var r = typeof t.width == "number" ? t.width : mu;
  return {
    width: r,
    height: e.height
  };
}, __ = A(Ve, rn, k_), q3 = (e, t, r) => {
  switch (t) {
    case "top":
      return e.top;
    case "bottom":
      return r - e.bottom;
    default:
      return 0;
  }
}, Z3 = (e, t, r) => {
  switch (t) {
    case "left":
      return e.left;
    case "right":
      return r - e.right;
    default:
      return 0;
  }
}, Q3 = A($n, Ve, X3, Cd, Td, (e, t, r, n, i) => {
  var a = {}, o;
  return r.forEach((l) => {
    var u = k_(t, l);
    o == null && (o = q3(t, n, e));
    var s = n === "top" && !i || n === "bottom" && i;
    a[l.id] = o - Number(s) * u.height, o += (s ? -1 : 1) * u.height;
  }), a;
}), J3 = A(Nn, Ve, Y3, Cd, Td, (e, t, r, n, i) => {
  var a = {}, o;
  return r.forEach((l) => {
    var u = G3(t, l);
    o == null && (o = Z3(t, n, e));
    var s = n === "left" && !i || n === "right" && i;
    a[l.id] = o - Number(s) * u.width, o += (s ? -1 : 1) * u.width;
  }), a;
}), eF = (e, t) => {
  var r = rn(e, t);
  if (r != null)
    return Q3(e, r.orientation, r.mirror);
}, tF = A([Ve, rn, eF, (e, t) => t], (e, t, r, n) => {
  if (t != null) {
    var i = r == null ? void 0 : r[n];
    return i == null ? {
      x: e.left,
      y: 0
    } : {
      x: e.left,
      y: i
    };
  }
}), rF = (e, t) => {
  var r = nn(e, t);
  if (r != null)
    return J3(e, r.orientation, r.mirror);
}, nF = A([Ve, nn, rF, (e, t) => t], (e, t, r, n) => {
  if (t != null) {
    var i = r == null ? void 0 : r[n];
    return i == null ? {
      x: 0,
      y: e.top
    } : {
      x: i,
      y: e.top
    };
  }
}), I_ = A(Ve, nn, (e, t) => {
  var r = typeof t.width == "number" ? t.width : mu;
  return {
    width: r,
    height: e.height
  };
}), Nw = (e, t, r) => {
  switch (t) {
    case "xAxis":
      return __(e, r).width;
    case "yAxis":
      return I_(e, r).height;
    default:
      return;
  }
}, j_ = (e, t, r, n) => {
  if (r != null) {
    var {
      allowDuplicatedCategory: i,
      type: a,
      dataKey: o
    } = r, l = br(e, n), u = t.map((s) => s.value);
    if (o && l && a === "category" && i && yE(u))
      return u;
  }
}, Tu = A([q, _d, Ne, ye], j_), Eg = (e, t, r, n) => {
  if (!(r == null || r.dataKey == null)) {
    var {
      type: i,
      scale: a
    } = r, o = br(e, n);
    if (o && (i === "number" || a !== "auto"))
      return t.map((l) => l.value);
  }
}, Ag = A([q, _d, wo, ye], Eg), $w = A([q, h3, gi, Zr, Tu, Ag, Cu, Og, ye], (e, t, r, n, i, a, o, l, u) => {
  if (t != null) {
    var s = br(e, u);
    return {
      angle: t.angle,
      interval: t.interval,
      minTickGap: t.minTickGap,
      orientation: t.orientation,
      tick: t.tick,
      tickCount: t.tickCount,
      tickFormatter: t.tickFormatter,
      ticks: t.ticks,
      type: t.type,
      unit: t.unit,
      axisType: u,
      categoricalDomain: a,
      duplicateDomain: i,
      isCategorical: s,
      niceTicks: l,
      range: o,
      realScaleType: r,
      scale: n
    };
  }
}), C_ = (e, t, r, n, i, a, o, l, u) => {
  if (!(t == null || n == null)) {
    var s = br(e, u), {
      type: c,
      ticks: f,
      tickCount: v
    } = t, p = r === "scaleBand" && typeof n.bandwidth == "function" ? n.bandwidth() / 2 : 2, h = c === "category" && n.bandwidth ? n.bandwidth() / p : 0;
    h = u === "angleAxis" && a != null && a.length >= 2 ? We(a[0] - a[1]) * 2 * h : h;
    var y = f || i;
    if (y) {
      var g = y.map((m, b) => {
        var x = o ? o.indexOf(m) : m;
        return {
          index: b,
          // If the scaleContent is not a number, the coordinate will be NaN.
          // That could be the case for example with a PointScale and a string as domain.
          coordinate: n(x) + h,
          value: m,
          offset: h
        };
      });
      return g.filter((m) => se(m.coordinate));
    }
    return s && l ? l.map((m, b) => ({
      coordinate: n(m) + h,
      value: m,
      index: b,
      offset: h
    })).filter((m) => se(m.coordinate)) : n.ticks ? n.ticks(v).map((m) => ({
      coordinate: n(m) + h,
      value: m,
      offset: h
    })) : n.domain().map((m, b) => ({
      coordinate: n(m) + h,
      value: o ? o[m] : m,
      index: b,
      offset: h
    }));
  }
}, T_ = A([q, wo, gi, Zr, Og, Cu, Tu, Ag, ye], C_), M_ = (e, t, r, n, i, a, o) => {
  if (!(t == null || r == null || n == null || n[0] === n[1])) {
    var l = br(e, o), {
      tickCount: u
    } = t, s = 0;
    return s = o === "angleAxis" && (n == null ? void 0 : n.length) >= 2 ? We(n[0] - n[1]) * 2 * s : s, l && a ? a.map((c, f) => ({
      coordinate: r(c) + s,
      value: c,
      index: f,
      offset: s
    })) : r.ticks ? r.ticks(u).map((c) => ({
      coordinate: r(c) + s,
      value: c,
      offset: s
    })) : r.domain().map((c, f) => ({
      coordinate: r(c) + s,
      value: i ? i[c] : c,
      index: f,
      offset: s
    }));
  }
}, gr = A([q, wo, Zr, Cu, Tu, Ag, ye], M_), Kt = A(Ne, Zr, (e, t) => {
  if (!(e == null || t == null))
    return of(of({}, e), {}, {
      scale: t
    });
}), iF = A([Ne, gi, wg, E_], jd), aF = A((e, t, r) => lg(e, r), iF, (e, t) => {
  if (!(e == null || t == null))
    return of(of({}, e), {}, {
      scale: t
    });
}), oF = A([q, ld, ud], (e, t, r) => {
  switch (e) {
    case "horizontal":
      return t.some((n) => n.reversed) ? "right-to-left" : "left-to-right";
    case "vertical":
      return r.some((n) => n.reversed) ? "bottom-to-top" : "top-to-bottom";
    case "centric":
    case "radial":
      return "left-to-right";
    default:
      return;
  }
}), D_ = (e) => e.options.defaultTooltipEventType, N_ = (e) => e.options.validateTooltipEventTypes;
function $_(e, t, r) {
  if (e == null)
    return t;
  var n = e ? "axis" : "item";
  return r == null ? t : r.includes(n) ? n : t;
}
function kg(e, t) {
  var r = D_(e), n = N_(e);
  return $_(t, r, n);
}
function lF(e) {
  return T((t) => kg(t, e));
}
var L_ = (e, t) => {
  var r, n = Number(t);
  if (!(Pt(n) || t == null))
    return n >= 0 ? e == null || (r = e[n]) === null || r === void 0 ? void 0 : r.value : void 0;
}, uF = (e) => e.tooltip.settings, Yn = {
  active: !1,
  index: null,
  dataKey: void 0,
  graphicalItemId: void 0,
  coordinate: void 0
}, sF = {
  itemInteraction: {
    click: Yn,
    hover: Yn
  },
  axisInteraction: {
    click: Yn,
    hover: Yn
  },
  keyboardInteraction: Yn,
  syncInteraction: {
    active: !1,
    index: null,
    dataKey: void 0,
    label: void 0,
    coordinate: void 0,
    sourceViewBox: void 0,
    graphicalItemId: void 0
  },
  tooltipItemPayloads: [],
  settings: {
    shared: void 0,
    trigger: "hover",
    axisId: 0,
    active: !1,
    defaultIndex: void 0
  }
}, R_ = Ut({
  name: "tooltip",
  initialState: sF,
  reducers: {
    addTooltipEntrySettings: {
      reducer(e, t) {
        e.tooltipItemPayloads.push(t.payload);
      },
      prepare: ke()
    },
    replaceTooltipEntrySettings: {
      reducer(e, t) {
        var {
          prev: r,
          next: n
        } = t.payload, i = Cr(e).tooltipItemPayloads.indexOf(r);
        i > -1 && (e.tooltipItemPayloads[i] = n);
      },
      prepare: ke()
    },
    removeTooltipEntrySettings: {
      reducer(e, t) {
        var r = Cr(e).tooltipItemPayloads.indexOf(t.payload);
        r > -1 && e.tooltipItemPayloads.splice(r, 1);
      },
      prepare: ke()
    },
    setTooltipSettingsState(e, t) {
      e.settings = t.payload;
    },
    setActiveMouseOverItemIndex(e, t) {
      e.syncInteraction.active = !1, e.keyboardInteraction.active = !1, e.itemInteraction.hover.active = !0, e.itemInteraction.hover.index = t.payload.activeIndex, e.itemInteraction.hover.dataKey = t.payload.activeDataKey, e.itemInteraction.hover.graphicalItemId = t.payload.activeGraphicalItemId, e.itemInteraction.hover.coordinate = t.payload.activeCoordinate;
    },
    mouseLeaveChart(e) {
      e.itemInteraction.hover.active = !1, e.axisInteraction.hover.active = !1;
    },
    mouseLeaveItem(e) {
      e.itemInteraction.hover.active = !1;
    },
    setActiveClickItemIndex(e, t) {
      e.syncInteraction.active = !1, e.itemInteraction.click.active = !0, e.keyboardInteraction.active = !1, e.itemInteraction.click.index = t.payload.activeIndex, e.itemInteraction.click.dataKey = t.payload.activeDataKey, e.itemInteraction.click.graphicalItemId = t.payload.activeGraphicalItemId, e.itemInteraction.click.coordinate = t.payload.activeCoordinate;
    },
    setMouseOverAxisIndex(e, t) {
      e.syncInteraction.active = !1, e.axisInteraction.hover.active = !0, e.keyboardInteraction.active = !1, e.axisInteraction.hover.index = t.payload.activeIndex, e.axisInteraction.hover.dataKey = t.payload.activeDataKey, e.axisInteraction.hover.coordinate = t.payload.activeCoordinate;
    },
    setMouseClickAxisIndex(e, t) {
      e.syncInteraction.active = !1, e.keyboardInteraction.active = !1, e.axisInteraction.click.active = !0, e.axisInteraction.click.index = t.payload.activeIndex, e.axisInteraction.click.dataKey = t.payload.activeDataKey, e.axisInteraction.click.coordinate = t.payload.activeCoordinate;
    },
    setSyncInteraction(e, t) {
      e.syncInteraction = t.payload;
    },
    setKeyboardInteraction(e, t) {
      e.keyboardInteraction.active = t.payload.active, e.keyboardInteraction.index = t.payload.activeIndex, e.keyboardInteraction.coordinate = t.payload.activeCoordinate;
    }
  }
}), {
  addTooltipEntrySettings: cF,
  replaceTooltipEntrySettings: fF,
  removeTooltipEntrySettings: dF,
  setTooltipSettingsState: vF,
  setActiveMouseOverItemIndex: So,
  mouseLeaveItem: _g,
  mouseLeaveChart: z_,
  setActiveClickItemIndex: Md,
  setMouseOverAxisIndex: B_,
  setMouseClickAxisIndex: pF,
  setSyncInteraction: Ch,
  setKeyboardInteraction: Th
} = R_.actions, hF = R_.reducer;
function Lw(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function ks(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Lw(Object(r), !0).forEach(function(n) {
      mF(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Lw(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function mF(e, t, r) {
  return (t = yF(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function yF(e) {
  var t = gF(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function gF(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function bF(e, t, r) {
  return t === "axis" ? r === "click" ? e.axisInteraction.click : e.axisInteraction.hover : r === "click" ? e.itemInteraction.click : e.itemInteraction.hover;
}
function xF(e) {
  return e.index != null;
}
var F_ = (e, t, r, n) => {
  if (t == null)
    return Yn;
  var i = bF(e, t, r);
  if (i == null)
    return Yn;
  if (i.active)
    return i;
  if (e.keyboardInteraction.active)
    return e.keyboardInteraction;
  if (e.syncInteraction.active && e.syncInteraction.index != null)
    return e.syncInteraction;
  var a = e.settings.active === !0;
  if (xF(i)) {
    if (a)
      return ks(ks({}, i), {}, {
        active: !0
      });
  } else if (n != null)
    return {
      active: !0,
      coordinate: void 0,
      dataKey: void 0,
      index: n,
      graphicalItemId: void 0
    };
  return ks(ks({}, Yn), {}, {
    coordinate: i.coordinate
  });
};
function wF(e) {
  if (typeof e == "number")
    return Number.isFinite(e) ? e : void 0;
  if (e instanceof Date) {
    var t = e.valueOf();
    return Number.isFinite(t) ? t : void 0;
  }
  var r = Number(e);
  return Number.isFinite(r) ? r : void 0;
}
function PF(e, t) {
  var r = wF(e), n = t[0], i = t[1];
  if (r === void 0)
    return !1;
  var a = Math.min(n, i), o = Math.max(n, i);
  return r >= a && r <= o;
}
function OF(e, t, r) {
  if (r == null || t == null)
    return !0;
  var n = G(e, t);
  return n == null || !si(r) ? !0 : PF(n, r);
}
var Ig = (e, t, r, n) => {
  var i = e == null ? void 0 : e.index;
  if (i == null)
    return null;
  var a = Number(i);
  if (!se(a))
    return i;
  var o = 0, l = 1 / 0;
  t.length > 0 && (l = t.length - 1);
  var u = Math.max(o, Math.min(a, l)), s = t[u];
  return s == null || OF(s, r, n) ? String(u) : null;
}, K_ = (e, t, r, n, i, a, o, l) => {
  if (!(a == null || l == null)) {
    var u = o[0], s = u == null ? void 0 : l(u.positions, a);
    if (s != null)
      return s;
    var c = i == null ? void 0 : i[Number(a)];
    if (c)
      switch (r) {
        case "horizontal":
          return {
            x: c.coordinate,
            y: (n.top + t) / 2
          };
        default:
          return {
            x: (n.left + e) / 2,
            y: c.coordinate
          };
      }
  }
}, W_ = (e, t, r, n) => {
  if (t === "axis")
    return e.tooltipItemPayloads;
  if (e.tooltipItemPayloads.length === 0)
    return [];
  var i;
  if (r === "hover" ? i = e.itemInteraction.hover.graphicalItemId : i = e.itemInteraction.click.graphicalItemId, i == null && n != null) {
    var a = e.tooltipItemPayloads[0];
    return a != null ? [a] : [];
  }
  return e.tooltipItemPayloads.filter((o) => {
    var l;
    return ((l = o.settings) === null || l === void 0 ? void 0 : l.graphicalItemId) === i;
  });
}, Mu = (e) => e.options.tooltipPayloadSearcher, Eo = (e) => e.tooltip;
function Rw(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function zw(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Rw(Object(r), !0).forEach(function(n) {
      SF(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Rw(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function SF(e, t, r) {
  return (t = EF(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function EF(e) {
  var t = AF(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function AF(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function kF(e, t) {
  return e ?? t;
}
var U_ = (e, t, r, n, i, a, o) => {
  if (!(t == null || a == null)) {
    var {
      chartData: l,
      computedData: u,
      dataStartIndex: s,
      dataEndIndex: c
    } = r, f = [];
    return e.reduce((v, p) => {
      var h, {
        dataDefinedOnItem: y,
        settings: g
      } = p, m = kF(y, l), b = Array.isArray(m) ? OA(m, s, c) : m, x = (h = g == null ? void 0 : g.dataKey) !== null && h !== void 0 ? h : n, w = g == null ? void 0 : g.nameKey, P;
      if (n && Array.isArray(b) && /*
       * findEntryInArray won't work for Scatter because Scatter provides an array of arrays
       * as tooltip payloads and findEntryInArray is not prepared to handle that.
       * Sad but also ScatterChart only allows 'item' tooltipEventType
       * and also this is only a problem if there are multiple Scatters and each has its own data array
       * so let's fix that some other time.
       */
      !Array.isArray(b[0]) && /*
       * If the tooltipEventType is 'axis', we should search for the dataKey in the sliced data
       * because thanks to allowDuplicatedCategory=false, the order of elements in the array
       * no longer matches the order of elements in the original data
       * and so we need to search by the active dataKey + label rather than by index.
       *
       * The same happens if multiple graphical items are present in the chart
       * and each of them has its own data array. Those arrays get concatenated
       * and again the tooltip index no longer matches the original data.
       *
       * On the other hand the tooltipEventType 'item' should always search by index
       * because we get the index from interacting over the individual elements
       * which is always accurate, irrespective of the allowDuplicatedCategory setting.
       */
      o === "axis" ? P = gE(b, n, i) : P = a(b, t, u, w), Array.isArray(P))
        P.forEach((S) => {
          var E = zw(zw({}, g), {}, {
            // @ts-expect-error we're assuming that item has name and unit properties
            name: S.name,
            // @ts-expect-error we're assuming that item has name and unit properties
            unit: S.unit,
            // color and fill are erased to keep 100% the identical behaviour to recharts 2.x - but there's nothing stopping us from returning them here. It's technically a breaking change.
            color: void 0,
            // color and fill are erased to keep 100% the identical behaviour to recharts 2.x - but there's nothing stopping us from returning them here. It's technically a breaking change.
            fill: void 0
          });
          v.push(qb({
            tooltipEntrySettings: E,
            // @ts-expect-error we're assuming that item has name and unit properties
            dataKey: S.dataKey,
            // @ts-expect-error we're assuming that item has name and unit properties
            payload: S.payload,
            // @ts-expect-error getValueByDataKey does not validate the output type
            value: G(S.payload, S.dataKey),
            // @ts-expect-error we're assuming that item has name and unit properties
            name: S.name
          }));
        });
      else {
        var O;
        v.push(qb({
          tooltipEntrySettings: g,
          dataKey: x,
          payload: P,
          // @ts-expect-error getValueByDataKey does not validate the output type
          value: G(P, x),
          // @ts-expect-error getValueByDataKey does not validate the output type
          name: (O = G(P, w)) !== null && O !== void 0 ? O : g == null ? void 0 : g.name
        }));
      }
      return v;
    }, f);
  }
}, jg = A([He, q, d_, ig, Qe], O_), _F = A([(e) => e.graphicalItems.cartesianItems, (e) => e.graphicalItems.polarItems], (e, t) => [...e, ...t]), IF = A([Qe, xo], ug), Ao = A([_F, He, IF], sg, {
  memoizeOptions: {
    resultEqualityCheck: kd
  }
}), jF = A([Ao], (e) => e.filter(_u)), CF = A([Ao], cg, {
  memoizeOptions: {
    resultEqualityCheck: kd
  }
}), ko = A([CF, tn], fg), TF = A([jF, tn, He], og), Cg = A([ko, He, Ao], vg), V_ = A([He], hg), MF = A([He], (e) => e.allowDataOverflow), H_ = A([V_, MF], Wk), DF = A([Ao], (e) => e.filter(_u)), NF = A([TF, DF, go, ng], pg), $F = A([NF, tn, Qe, H_], m_), LF = A([Ao], p_), RF = A([ko, He, LF, Id, Qe], gg, {
  memoizeOptions: {
    resultEqualityCheck: Ad
  }
}), zF = A([y_, Qe, xo], Oo), BF = A([zF, Qe], x_), FF = A([g_, Qe, xo], Oo), KF = A([FF, Qe], w_), WF = A([b_, Qe, xo], Oo), UF = A([WF, Qe], P_), VF = A([BF, UF, KF], uf), HF = A([He, V_, H_, $F, RF, VF, q, Qe], bg), Du = A([He, q, ko, Cg, go, Qe, HF], xg), XF = A([Du, He, jg], Pg), YF = A([He, Du, XF, Qe], Sg), X_ = (e) => {
  var t = Qe(e), r = xo(e), n = !1;
  return Cu(e, t, r, n);
}, Y_ = A([He, X_], Od), G_ = A([He, jg, YF, Y_], jd), GF = A([q, Cg, He, Qe], j_), qF = A([q, Cg, He, Qe], Eg), ZF = (e, t, r, n, i, a, o, l) => {
  if (t) {
    var {
      type: u
    } = t, s = br(e, l);
    if (n) {
      var c = r === "scaleBand" && n.bandwidth ? n.bandwidth() / 2 : 2, f = u === "category" && n.bandwidth ? n.bandwidth() / c : 0;
      return f = l === "angleAxis" && i != null && (i == null ? void 0 : i.length) >= 2 ? We(i[0] - i[1]) * 2 * f : f, s && o ? o.map((v, p) => ({
        coordinate: n(v) + f,
        value: v,
        index: p,
        offset: f
      })) : n.domain().map((v, p) => ({
        coordinate: n(v) + f,
        value: a ? a[v] : v,
        index: p,
        offset: f
      }));
    }
  }
}, zn = A([q, He, jg, G_, X_, GF, qF, Qe], ZF), Tg = A([D_, N_, uF], (e, t, r) => $_(r.shared, e, t)), q_ = (e) => e.tooltip.settings.trigger, Mg = (e) => e.tooltip.settings.defaultIndex, Nu = A([Eo, Tg, q_, Mg], F_), Qr = A([Nu, ko, ju, Du], Ig), Z_ = A([zn, Qr], L_), Dg = A([Nu], (e) => {
  if (e)
    return e.dataKey;
}), QF = A([Nu], (e) => {
  if (e)
    return e.graphicalItemId;
}), Q_ = A([Eo, Tg, q_, Mg], W_), JF = A([Nn, $n, q, Ve, zn, Mg, Q_, Mu], K_), eK = A([Nu, JF], (e, t) => e != null && e.coordinate ? e.coordinate : t), tK = A([Nu], (e) => {
  var t;
  return (t = e == null ? void 0 : e.active) !== null && t !== void 0 ? t : !1;
}), rK = A([Q_, Qr, tn, ju, Z_, Mu, Tg], U_), nK = A([rK], (e) => {
  if (e != null) {
    var t = e.map((r) => r.payload).filter((r) => r != null);
    return Array.from(new Set(t));
  }
});
function Bw(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Fw(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Bw(Object(r), !0).forEach(function(n) {
      iK(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Bw(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function iK(e, t, r) {
  return (t = aK(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function aK(e) {
  var t = oK(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function oK(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var lK = () => T(He), uK = () => {
  var e = lK(), t = T(zn), r = T(G_);
  return Ft(!e || !r ? void 0 : Fw(Fw({}, e), {}, {
    scale: r
  }), t);
};
function Kw(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function va(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Kw(Object(r), !0).forEach(function(n) {
      sK(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Kw(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function sK(e, t, r) {
  return (t = cK(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function cK(e) {
  var t = fK(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function fK(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var dK = (e, t, r, n) => {
  var i = t.find((a) => a && a.index === r);
  if (i) {
    if (e === "horizontal")
      return {
        x: i.coordinate,
        y: n.chartY
      };
    if (e === "vertical")
      return {
        x: n.chartX,
        y: i.coordinate
      };
  }
  return {
    x: 0,
    y: 0
  };
}, vK = (e, t, r, n) => {
  var i = t.find((s) => s && s.index === r);
  if (i) {
    if (e === "centric") {
      var a = i.coordinate, {
        radius: o
      } = n;
      return va(va(va({}, n), ce(n.cx, n.cy, o, a)), {}, {
        angle: a,
        radius: o
      });
    }
    var l = i.coordinate, {
      angle: u
    } = n;
    return va(va(va({}, n), ce(n.cx, n.cy, l, u)), {}, {
      angle: u,
      radius: l
    });
  }
  return {
    angle: 0,
    clockWise: !1,
    cx: 0,
    cy: 0,
    endAngle: 0,
    innerRadius: 0,
    outerRadius: 0,
    radius: 0,
    startAngle: 0,
    x: 0,
    y: 0
  };
};
function pK(e, t) {
  var {
    chartX: r,
    chartY: n
  } = e;
  return r >= t.left && r <= t.left + t.width && n >= t.top && n <= t.top + t.height;
}
var J_ = (e, t, r, n, i) => {
  var a, o = (a = t == null ? void 0 : t.length) !== null && a !== void 0 ? a : 0;
  if (o <= 1 || e == null)
    return 0;
  if (n === "angleAxis" && i != null && Math.abs(Math.abs(i[1] - i[0]) - 360) <= 1e-6)
    for (var l = 0; l < o; l++) {
      var u, s, c, f, v, p = l > 0 ? (u = r[l - 1]) === null || u === void 0 ? void 0 : u.coordinate : (s = r[o - 1]) === null || s === void 0 ? void 0 : s.coordinate, h = (c = r[l]) === null || c === void 0 ? void 0 : c.coordinate, y = l >= o - 1 ? (f = r[0]) === null || f === void 0 ? void 0 : f.coordinate : (v = r[l + 1]) === null || v === void 0 ? void 0 : v.coordinate, g = void 0;
      if (!(p == null || h == null || y == null))
        if (We(h - p) !== We(y - h)) {
          var m = [];
          if (We(y - h) === We(i[1] - i[0])) {
            g = y;
            var b = h + i[1] - i[0];
            m[0] = Math.min(b, (b + p) / 2), m[1] = Math.max(b, (b + p) / 2);
          } else {
            g = p;
            var x = y + i[1] - i[0];
            m[0] = Math.min(h, (x + h) / 2), m[1] = Math.max(h, (x + h) / 2);
          }
          var w = [Math.min(h, (g + h) / 2), Math.max(h, (g + h) / 2)];
          if (e > w[0] && e <= w[1] || e >= m[0] && e <= m[1]) {
            var P;
            return (P = r[l]) === null || P === void 0 ? void 0 : P.index;
          }
        } else {
          var O = Math.min(p, y), S = Math.max(p, y);
          if (e > (O + h) / 2 && e <= (S + h) / 2) {
            var E;
            return (E = r[l]) === null || E === void 0 ? void 0 : E.index;
          }
        }
    }
  else if (t)
    for (var k = 0; k < o; k++) {
      var _ = t[k];
      if (_ != null) {
        var I = t[k + 1], j = t[k - 1];
        if (k === 0 && I != null && e <= (_.coordinate + I.coordinate) / 2 || k === o - 1 && j != null && e > (_.coordinate + j.coordinate) / 2 || k > 0 && k < o - 1 && j != null && I != null && e > (_.coordinate + j.coordinate) / 2 && e <= (_.coordinate + I.coordinate) / 2)
          return _.index;
      }
    }
  return -1;
}, eI = () => T(ig), Ng = (e, t) => t, tI = (e, t, r) => r, $g = (e, t, r, n) => n, hK = A(zn, (e) => qf(e, (t) => t.coordinate)), Lg = A([Eo, Ng, tI, $g], F_), Dd = A([Lg, ko, ju, Du], Ig), mK = (e, t, r) => {
  if (t != null) {
    var n = Eo(e);
    return t === "axis" ? r === "hover" ? n.axisInteraction.hover.dataKey : n.axisInteraction.click.dataKey : r === "hover" ? n.itemInteraction.hover.dataKey : n.itemInteraction.click.dataKey;
  }
}, rI = A([Eo, Ng, tI, $g], W_), sf = A([Nn, $n, q, Ve, zn, $g, rI, Mu], K_), yK = A([Lg, sf], (e, t) => {
  var r;
  return (r = e.coordinate) !== null && r !== void 0 ? r : t;
}), nI = A([zn, Dd], L_), gK = A([rI, Dd, tn, ju, nI, Mu, Ng], U_), bK = A([Lg, Dd], (e, t) => ({
  isActive: e.active && t != null,
  activeIndex: t
})), xK = (e, t, r, n, i, a, o) => {
  if (!(!e || !r || !n || !i) && pK(e, o)) {
    var l = QN(e, t), u = J_(l, a, i, r, n), s = dK(t, i, u, e);
    return {
      activeIndex: String(u),
      activeCoordinate: s
    };
  }
}, wK = (e, t, r, n, i, a, o) => {
  if (!(!e || !n || !i || !a || !r)) {
    var l = vR(e, r);
    if (l) {
      var u = JN(l, t), s = J_(u, o, a, n, i), c = vK(t, a, s, l);
      return {
        activeIndex: String(s),
        activeCoordinate: c
      };
    }
  }
}, PK = (e, t, r, n, i, a, o, l) => {
  if (!(!e || !t || !n || !i || !a))
    return t === "horizontal" || t === "vertical" ? xK(e, t, n, i, a, o, l) : wK(e, t, r, n, i, a, o);
}, OK = A((e) => e.zIndex.zIndexMap, (e, t) => t, (e, t, r) => r, (e, t, r) => {
  if (t != null) {
    var n = e[t];
    if (n != null)
      return r ? n.panoramaElement : n.element;
  }
}), SK = A((e) => e.zIndex.zIndexMap, (e) => {
  var t = Object.keys(e).map((n) => parseInt(n, 10)).concat(Object.values(ie)), r = Array.from(new Set(t));
  return r.sort((n, i) => n - i);
}, {
  memoizeOptions: {
    resultEqualityCheck: f3
  }
});
function Ww(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Uw(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Ww(Object(r), !0).forEach(function(n) {
      EK(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Ww(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function EK(e, t, r) {
  return (t = AK(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function AK(e) {
  var t = kK(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function kK(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var _K = {}, IK = {
  zIndexMap: Object.values(ie).reduce((e, t) => Uw(Uw({}, e), {}, {
    [t]: {
      element: void 0,
      panoramaElement: void 0,
      consumers: 0
    }
  }), _K)
}, jK = new Set(Object.values(ie));
function CK(e) {
  return jK.has(e);
}
var iI = Ut({
  name: "zIndex",
  initialState: IK,
  reducers: {
    registerZIndexPortal: {
      reducer: (e, t) => {
        var {
          zIndex: r
        } = t.payload;
        e.zIndexMap[r] ? e.zIndexMap[r].consumers += 1 : e.zIndexMap[r] = {
          consumers: 1,
          element: void 0,
          panoramaElement: void 0
        };
      },
      prepare: ke()
    },
    unregisterZIndexPortal: {
      reducer: (e, t) => {
        var {
          zIndex: r
        } = t.payload;
        e.zIndexMap[r] && (e.zIndexMap[r].consumers -= 1, e.zIndexMap[r].consumers <= 0 && !CK(r) && delete e.zIndexMap[r]);
      },
      prepare: ke()
    },
    registerZIndexPortalElement: {
      reducer: (e, t) => {
        var {
          zIndex: r,
          element: n,
          isPanorama: i
        } = t.payload;
        e.zIndexMap[r] ? i ? e.zIndexMap[r].panoramaElement = n : e.zIndexMap[r].element = n : e.zIndexMap[r] = {
          consumers: 0,
          element: i ? void 0 : n,
          panoramaElement: i ? n : void 0
        };
      },
      prepare: ke()
    },
    unregisterZIndexPortalElement: {
      reducer: (e, t) => {
        var {
          zIndex: r
        } = t.payload;
        e.zIndexMap[r] && (t.payload.isPanorama ? e.zIndexMap[r].panoramaElement = void 0 : e.zIndexMap[r].element = void 0);
      },
      prepare: ke()
    }
  }
}), {
  registerZIndexPortal: TK,
  unregisterZIndexPortal: MK,
  registerZIndexPortalElement: DK,
  unregisterZIndexPortalElement: NK
} = iI.actions, $K = iI.reducer;
function pe(e) {
  var {
    zIndex: t,
    children: r
  } = e, n = _$(), i = n && t !== void 0 && t !== 0, a = me(), o = J();
  d.useLayoutEffect(() => i ? (o(TK({
    zIndex: t
  })), () => {
    o(MK({
      zIndex: t
    }));
  }) : co, [o, t, i]);
  var l = T((u) => OK(u, t, a));
  return i ? l ? /* @__PURE__ */ Uf.createPortal(r, l) : null : r;
}
function Mh() {
  return Mh = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Mh.apply(null, arguments);
}
function Vw(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function _s(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Vw(Object(r), !0).forEach(function(n) {
      LK(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Vw(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function LK(e, t, r) {
  return (t = RK(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function RK(e) {
  var t = zK(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function zK(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function BK(e) {
  var {
    cursor: t,
    cursorComp: r,
    cursorProps: n
  } = e;
  return /* @__PURE__ */ d.isValidElement(t) ? /* @__PURE__ */ d.cloneElement(t, n) : /* @__PURE__ */ d.createElement(r, n);
}
function FK(e) {
  var t, {
    coordinate: r,
    payload: n,
    index: i,
    offset: a,
    tooltipAxisBandSize: o,
    layout: l,
    cursor: u,
    tooltipEventType: s,
    chartName: c
  } = e, f = r, v = n, p = i;
  if (!u || !f || c !== "ScatterChart" && s !== "axis")
    return null;
  var h, y, g;
  if (c === "ScatterChart")
    h = f, y = _L, g = ie.cursorLine;
  else if (c === "BarChart")
    h = IL(l, f, a, o), y = Pu, g = ie.cursorRectangle;
  else if (l === "radial" && xE(f)) {
    var {
      cx: m,
      cy: b,
      radius: x,
      startAngle: w,
      endAngle: P
    } = rk(f);
    h = {
      cx: m,
      cy: b,
      startAngle: w,
      endAngle: P,
      innerRadius: x,
      outerRadius: x
    }, y = ik, g = ie.cursorLine;
  } else
    h = {
      points: yR(l, f, a)
    }, y = Ri, g = ie.cursorLine;
  var O = typeof u == "object" && "className" in u ? u.className : void 0, S = _s(_s(_s(_s({
    stroke: "#ccc",
    pointerEvents: "none"
  }, a), h), er(u)), {}, {
    payload: v,
    payloadIndex: p,
    className: Y("recharts-tooltip-cursor", O)
  });
  return /* @__PURE__ */ d.createElement(pe, {
    zIndex: (t = e.zIndex) !== null && t !== void 0 ? t : g
  }, /* @__PURE__ */ d.createElement(BK, {
    cursor: u,
    cursorComp: y,
    cursorProps: S
  }));
}
function KK(e) {
  var t = uK(), r = LA(), n = Ln(), i = eI();
  return t == null || r == null || n == null || i == null ? null : /* @__PURE__ */ d.createElement(FK, Mh({}, e, {
    offset: r,
    layout: n,
    tooltipAxisBandSize: t,
    chartName: i
  }));
}
var Nd = /* @__PURE__ */ d.createContext(null), WK = () => d.useContext(Nd), aI = { exports: {} };
(function(e) {
  var t = Object.prototype.hasOwnProperty, r = "~";
  function n() {
  }
  Object.create && (n.prototype = /* @__PURE__ */ Object.create(null), new n().__proto__ || (r = !1));
  function i(u, s, c) {
    this.fn = u, this.context = s, this.once = c || !1;
  }
  function a(u, s, c, f, v) {
    if (typeof c != "function")
      throw new TypeError("The listener must be a function");
    var p = new i(c, f || u, v), h = r ? r + s : s;
    return u._events[h] ? u._events[h].fn ? u._events[h] = [u._events[h], p] : u._events[h].push(p) : (u._events[h] = p, u._eventsCount++), u;
  }
  function o(u, s) {
    --u._eventsCount === 0 ? u._events = new n() : delete u._events[s];
  }
  function l() {
    this._events = new n(), this._eventsCount = 0;
  }
  l.prototype.eventNames = function() {
    var s = [], c, f;
    if (this._eventsCount === 0) return s;
    for (f in c = this._events)
      t.call(c, f) && s.push(r ? f.slice(1) : f);
    return Object.getOwnPropertySymbols ? s.concat(Object.getOwnPropertySymbols(c)) : s;
  }, l.prototype.listeners = function(s) {
    var c = r ? r + s : s, f = this._events[c];
    if (!f) return [];
    if (f.fn) return [f.fn];
    for (var v = 0, p = f.length, h = new Array(p); v < p; v++)
      h[v] = f[v].fn;
    return h;
  }, l.prototype.listenerCount = function(s) {
    var c = r ? r + s : s, f = this._events[c];
    return f ? f.fn ? 1 : f.length : 0;
  }, l.prototype.emit = function(s, c, f, v, p, h) {
    var y = r ? r + s : s;
    if (!this._events[y]) return !1;
    var g = this._events[y], m = arguments.length, b, x;
    if (g.fn) {
      switch (g.once && this.removeListener(s, g.fn, void 0, !0), m) {
        case 1:
          return g.fn.call(g.context), !0;
        case 2:
          return g.fn.call(g.context, c), !0;
        case 3:
          return g.fn.call(g.context, c, f), !0;
        case 4:
          return g.fn.call(g.context, c, f, v), !0;
        case 5:
          return g.fn.call(g.context, c, f, v, p), !0;
        case 6:
          return g.fn.call(g.context, c, f, v, p, h), !0;
      }
      for (x = 1, b = new Array(m - 1); x < m; x++)
        b[x - 1] = arguments[x];
      g.fn.apply(g.context, b);
    } else {
      var w = g.length, P;
      for (x = 0; x < w; x++)
        switch (g[x].once && this.removeListener(s, g[x].fn, void 0, !0), m) {
          case 1:
            g[x].fn.call(g[x].context);
            break;
          case 2:
            g[x].fn.call(g[x].context, c);
            break;
          case 3:
            g[x].fn.call(g[x].context, c, f);
            break;
          case 4:
            g[x].fn.call(g[x].context, c, f, v);
            break;
          default:
            if (!b) for (P = 1, b = new Array(m - 1); P < m; P++)
              b[P - 1] = arguments[P];
            g[x].fn.apply(g[x].context, b);
        }
    }
    return !0;
  }, l.prototype.on = function(s, c, f) {
    return a(this, s, c, f, !1);
  }, l.prototype.once = function(s, c, f) {
    return a(this, s, c, f, !0);
  }, l.prototype.removeListener = function(s, c, f, v) {
    var p = r ? r + s : s;
    if (!this._events[p]) return this;
    if (!c)
      return o(this, p), this;
    var h = this._events[p];
    if (h.fn)
      h.fn === c && (!v || h.once) && (!f || h.context === f) && o(this, p);
    else {
      for (var y = 0, g = [], m = h.length; y < m; y++)
        (h[y].fn !== c || v && !h[y].once || f && h[y].context !== f) && g.push(h[y]);
      g.length ? this._events[p] = g.length === 1 ? g[0] : g : o(this, p);
    }
    return this;
  }, l.prototype.removeAllListeners = function(s) {
    var c;
    return s ? (c = r ? r + s : s, this._events[c] && o(this, c)) : (this._events = new n(), this._eventsCount = 0), this;
  }, l.prototype.off = l.prototype.removeListener, l.prototype.addListener = l.prototype.on, l.prefixed = r, l.EventEmitter = l, e.exports = l;
})(aI);
var UK = aI.exports;
const VK = /* @__PURE__ */ Wt(UK);
var no = new VK(), Dh = "recharts.syncEvent.tooltip", Nh = "recharts.syncEvent.brush";
function Bn(e, t) {
  if (t) {
    var r = Number.parseInt(t, 10);
    if (!Pt(r))
      return e == null ? void 0 : e[r];
  }
}
var HK = {
  chartName: "",
  tooltipPayloadSearcher: void 0,
  eventEmitter: void 0,
  defaultTooltipEventType: "axis"
}, oI = Ut({
  name: "options",
  initialState: HK,
  reducers: {
    createEventEmitter: (e) => {
      e.eventEmitter == null && (e.eventEmitter = Symbol("rechartsEventEmitter"));
    }
  }
}), XK = oI.reducer, {
  createEventEmitter: YK
} = oI.actions;
function GK(e) {
  return e.tooltip.syncInteraction;
}
var qK = {
  chartData: void 0,
  computedData: void 0,
  dataStartIndex: 0,
  dataEndIndex: 0
}, lI = Ut({
  name: "chartData",
  initialState: qK,
  reducers: {
    setChartData(e, t) {
      if (e.chartData = t.payload, t.payload == null) {
        e.dataStartIndex = 0, e.dataEndIndex = 0;
        return;
      }
      t.payload.length > 0 && e.dataEndIndex !== t.payload.length - 1 && (e.dataEndIndex = t.payload.length - 1);
    },
    setComputedData(e, t) {
      e.computedData = t.payload;
    },
    setDataStartEndIndexes(e, t) {
      var {
        startIndex: r,
        endIndex: n
      } = t.payload;
      r != null && (e.dataStartIndex = r), n != null && (e.dataEndIndex = n);
    }
  }
}), {
  setChartData: $h,
  setDataStartEndIndexes: Lh,
  setComputedData: ZK
} = lI.actions, QK = lI.reducer, JK = ["x", "y"];
function Hw(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function pa(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Hw(Object(r), !0).forEach(function(n) {
      eW(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Hw(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function eW(e, t, r) {
  return (t = tW(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function tW(e) {
  var t = rW(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function rW(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function nW(e, t) {
  if (e == null) return {};
  var r, n, i = iW(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function iW(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function aW() {
  var e = T(wd), t = T(Pd), r = J(), n = T(a_), i = T(zn), a = Ln(), o = vo(), l = T((u) => u.rootProps.className);
  d.useEffect(() => {
    if (e == null)
      return co;
    var u = (s, c, f) => {
      if (t !== f && e === s) {
        if (n === "index") {
          var v;
          if (o && c !== null && c !== void 0 && (v = c.payload) !== null && v !== void 0 && v.coordinate && c.payload.sourceViewBox) {
            var p = c.payload.coordinate, {
              x: h,
              y
            } = p, g = nW(p, JK), {
              x: m,
              y: b,
              width: x,
              height: w
            } = c.payload.sourceViewBox, P = pa(pa({}, g), {}, {
              x: o.x + (x ? (h - m) / x : 0) * o.width,
              y: o.y + (w ? (y - b) / w : 0) * o.height
            });
            r(pa(pa({}, c), {}, {
              payload: pa(pa({}, c.payload), {}, {
                coordinate: P
              })
            }));
          } else
            r(c);
          return;
        }
        if (i != null) {
          var O;
          if (typeof n == "function") {
            var S = {
              activeTooltipIndex: c.payload.index == null ? void 0 : Number(c.payload.index),
              isTooltipActive: c.payload.active,
              activeIndex: c.payload.index == null ? void 0 : Number(c.payload.index),
              activeLabel: c.payload.label,
              activeDataKey: c.payload.dataKey,
              activeCoordinate: c.payload.coordinate
            }, E = n(i, S);
            O = i[E];
          } else n === "value" && (O = i.find((V) => String(V.value) === c.payload.label));
          var {
            coordinate: k
          } = c.payload;
          if (O == null || c.payload.active === !1 || k == null || o == null) {
            r(Ch({
              active: !1,
              coordinate: void 0,
              dataKey: void 0,
              index: null,
              label: void 0,
              sourceViewBox: void 0,
              graphicalItemId: void 0
            }));
            return;
          }
          var {
            x: _,
            y: I
          } = k, j = Math.min(_, o.x + o.width), z = Math.min(I, o.y + o.height), N = {
            x: a === "horizontal" ? O.coordinate : j,
            y: a === "horizontal" ? z : O.coordinate
          }, R = Ch({
            active: c.payload.active,
            coordinate: N,
            dataKey: c.payload.dataKey,
            index: String(O.index),
            label: c.payload.label,
            sourceViewBox: c.payload.sourceViewBox,
            graphicalItemId: c.payload.graphicalItemId
          });
          r(R);
        }
      }
    };
    return no.on(Dh, u), () => {
      no.off(Dh, u);
    };
  }, [l, r, t, e, n, i, a, o]);
}
function oW() {
  var e = T(wd), t = T(Pd), r = J();
  d.useEffect(() => {
    if (e == null)
      return co;
    var n = (i, a, o) => {
      t !== o && e === i && r(Lh(a));
    };
    return no.on(Nh, n), () => {
      no.off(Nh, n);
    };
  }, [r, t, e]);
}
function lW() {
  var e = J();
  d.useEffect(() => {
    e(YK());
  }, [e]), aW(), oW();
}
function uW(e, t, r, n, i, a) {
  var o = T((p) => mK(p, e, t)), l = T(Pd), u = T(wd), s = T(a_), c = T(GK), f = c == null ? void 0 : c.active, v = vo();
  d.useEffect(() => {
    if (!f && u != null && l != null) {
      var p = Ch({
        active: a,
        coordinate: r,
        dataKey: o,
        index: i,
        label: typeof n == "number" ? String(n) : n,
        sourceViewBox: v,
        graphicalItemId: void 0
      });
      no.emit(Dh, u, p, l);
    }
  }, [f, r, o, i, n, l, u, s, a, v]);
}
function sW() {
  var e = T(wd), t = T(Pd), r = T((i) => i.chartData.dataStartIndex), n = T((i) => i.chartData.dataEndIndex);
  d.useEffect(() => {
    if (!(e == null || r == null || n == null || t == null)) {
      var i = {
        startIndex: r,
        endIndex: n
      };
      no.emit(Nh, e, i, t);
    }
  }, [n, r, t, e]);
}
function Xw(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Yw(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Xw(Object(r), !0).forEach(function(n) {
      cW(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Xw(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function cW(e, t, r) {
  return (t = fW(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function fW(e) {
  var t = dW(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function dW(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function vW(e) {
  return e.dataKey;
}
function pW(e, t) {
  return /* @__PURE__ */ d.isValidElement(e) ? /* @__PURE__ */ d.cloneElement(e, t) : typeof e == "function" ? /* @__PURE__ */ d.createElement(e, t) : /* @__PURE__ */ d.createElement(lL, t);
}
var Gw = [], hW = {
  allowEscapeViewBox: {
    x: !1,
    y: !1
  },
  animationDuration: 400,
  animationEasing: "ease",
  axisId: 0,
  contentStyle: {},
  cursor: !0,
  filterNull: !0,
  includeHidden: !1,
  isAnimationActive: "auto",
  itemSorter: "name",
  itemStyle: {},
  labelStyle: {},
  offset: 10,
  reverseDirection: {
    x: !1,
    y: !1
  },
  separator: " : ",
  trigger: "hover",
  useTranslate3d: !1,
  wrapperStyle: {}
};
function PZ(e) {
  var t, r, n = ee(e, hW), {
    active: i,
    allowEscapeViewBox: a,
    animationDuration: o,
    animationEasing: l,
    content: u,
    filterNull: s,
    isAnimationActive: c,
    offset: f,
    payloadUniqBy: v,
    position: p,
    reverseDirection: h,
    useTranslate3d: y,
    wrapperStyle: g,
    cursor: m,
    shared: b,
    trigger: x,
    defaultIndex: w,
    portal: P,
    axisId: O
  } = n, S = J(), E = typeof w == "number" ? String(w) : w;
  d.useEffect(() => {
    S(vF({
      shared: b,
      trigger: x,
      axisId: O,
      active: i,
      defaultIndex: E
    }));
  }, [S, b, x, O, i, E]);
  var k = vo(), _ = GA(), I = lF(b), {
    activeIndex: j,
    isActive: z
  } = (t = T((fe) => bK(fe, I, x, E))) !== null && t !== void 0 ? t : {}, N = T((fe) => gK(fe, I, x, E)), R = T((fe) => nI(fe, I, x, E)), V = T((fe) => yK(fe, I, x, E)), H = N, C = WK(), D = (r = i ?? z) !== null && r !== void 0 ? r : !1, [F, Z] = HE([H, D]), Q = I === "axis" ? R : void 0;
  uW(I, x, V, Q, j, D);
  var Be = P ?? C;
  if (Be == null || k == null || I == null)
    return null;
  var be = H ?? Gw;
  D || (be = Gw), s && be.length && (be = DE(be.filter((fe) => fe.value != null && (fe.hide !== !0 || n.includeHidden)), v, vW));
  var Je = be.length > 0, Xe = /* @__PURE__ */ d.createElement(pL, {
    allowEscapeViewBox: a,
    animationDuration: o,
    animationEasing: l,
    isAnimationActive: c,
    active: D,
    coordinate: V,
    hasPayload: Je,
    offset: f,
    position: p,
    reverseDirection: h,
    useTranslate3d: y,
    viewBox: k,
    wrapperStyle: g,
    lastBoundingBox: F,
    innerRef: Z,
    hasPortalFromProps: !!P
  }, pW(u, Yw(Yw({}, n), {}, {
    payload: be,
    label: Q,
    active: D,
    activeIndex: j,
    coordinate: V,
    accessibilityLayer: _
  })));
  return /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ Uf.createPortal(Xe, Be), D && /* @__PURE__ */ d.createElement(KK, {
    cursor: m,
    tooltipEventType: I,
    coordinate: V,
    payload: be,
    index: j
  }));
}
var sa = (e) => null;
sa.displayName = "Cell";
function mW(e, t, r) {
  return (t = yW(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function yW(e) {
  var t = gW(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function gW(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
class bW {
  constructor(t) {
    mW(this, "cache", /* @__PURE__ */ new Map()), this.maxSize = t;
  }
  get(t) {
    var r = this.cache.get(t);
    return r !== void 0 && (this.cache.delete(t), this.cache.set(t, r)), r;
  }
  set(t, r) {
    if (this.cache.has(t))
      this.cache.delete(t);
    else if (this.cache.size >= this.maxSize) {
      var n = this.cache.keys().next().value;
      n != null && this.cache.delete(n);
    }
    this.cache.set(t, r);
  }
  clear() {
    this.cache.clear();
  }
  size() {
    return this.cache.size;
  }
}
function qw(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function xW(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? qw(Object(r), !0).forEach(function(n) {
      wW(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : qw(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function wW(e, t, r) {
  return (t = PW(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function PW(e) {
  var t = OW(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function OW(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var SW = {
  cacheSize: 2e3,
  enableCache: !0
}, uI = xW({}, SW), Zw = new bW(uI.cacheSize), EW = {
  position: "absolute",
  top: "-20000px",
  left: 0,
  padding: 0,
  margin: 0,
  border: "none",
  whiteSpace: "pre"
}, Qw = "recharts_measurement_span";
function AW(e, t) {
  var r = t.fontSize || "", n = t.fontFamily || "", i = t.fontWeight || "", a = t.fontStyle || "", o = t.letterSpacing || "", l = t.textTransform || "";
  return "".concat(e, "|").concat(r, "|").concat(n, "|").concat(i, "|").concat(a, "|").concat(o, "|").concat(l);
}
var Jw = (e, t) => {
  try {
    var r = document.getElementById(Qw);
    r || (r = document.createElement("span"), r.setAttribute("id", Qw), r.setAttribute("aria-hidden", "true"), document.body.appendChild(r)), Object.assign(r.style, EW, t), r.textContent = "".concat(e);
    var n = r.getBoundingClientRect();
    return {
      width: n.width,
      height: n.height
    };
  } catch {
    return {
      width: 0,
      height: 0
    };
  }
}, Ba = function(t) {
  var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
  if (t == null || po.isSsr)
    return {
      width: 0,
      height: 0
    };
  if (!uI.enableCache)
    return Jw(t, r);
  var n = AW(t, r), i = Zw.get(n);
  if (i)
    return i;
  var a = Jw(t, r);
  return Zw.set(n, a), a;
}, sI;
function kW(e, t, r) {
  return (t = _W(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function _W(e) {
  var t = IW(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function IW(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var eP = /(-?\d+(?:\.\d+)?[a-zA-Z%]*)([*/])(-?\d+(?:\.\d+)?[a-zA-Z%]*)/, tP = /(-?\d+(?:\.\d+)?[a-zA-Z%]*)([+-])(-?\d+(?:\.\d+)?[a-zA-Z%]*)/, jW = /^px|cm|vh|vw|em|rem|%|mm|in|pt|pc|ex|ch|vmin|vmax|Q$/, CW = /(-?\d+(?:\.\d+)?)([a-zA-Z%]+)?/, TW = {
  cm: 96 / 2.54,
  mm: 96 / 25.4,
  pt: 96 / 72,
  pc: 96 / 6,
  in: 96,
  Q: 96 / (2.54 * 40),
  px: 1
}, MW = ["cm", "mm", "pt", "pc", "in", "Q", "px"];
function DW(e) {
  return MW.includes(e);
}
var Ia = "NaN";
function NW(e, t) {
  return e * TW[t];
}
class ct {
  static parse(t) {
    var r, [, n, i] = (r = CW.exec(t)) !== null && r !== void 0 ? r : [];
    return n == null ? ct.NaN : new ct(parseFloat(n), i ?? "");
  }
  constructor(t, r) {
    this.num = t, this.unit = r, this.num = t, this.unit = r, Pt(t) && (this.unit = ""), r !== "" && !jW.test(r) && (this.num = NaN, this.unit = ""), DW(r) && (this.num = NW(t, r), this.unit = "px");
  }
  add(t) {
    return this.unit !== t.unit ? new ct(NaN, "") : new ct(this.num + t.num, this.unit);
  }
  subtract(t) {
    return this.unit !== t.unit ? new ct(NaN, "") : new ct(this.num - t.num, this.unit);
  }
  multiply(t) {
    return this.unit !== "" && t.unit !== "" && this.unit !== t.unit ? new ct(NaN, "") : new ct(this.num * t.num, this.unit || t.unit);
  }
  divide(t) {
    return this.unit !== "" && t.unit !== "" && this.unit !== t.unit ? new ct(NaN, "") : new ct(this.num / t.num, this.unit || t.unit);
  }
  toString() {
    return "".concat(this.num).concat(this.unit);
  }
  isNaN() {
    return Pt(this.num);
  }
}
sI = ct;
kW(ct, "NaN", new sI(NaN, ""));
function cI(e) {
  if (e == null || e.includes(Ia))
    return Ia;
  for (var t = e; t.includes("*") || t.includes("/"); ) {
    var r, [, n, i, a] = (r = eP.exec(t)) !== null && r !== void 0 ? r : [], o = ct.parse(n ?? ""), l = ct.parse(a ?? ""), u = i === "*" ? o.multiply(l) : o.divide(l);
    if (u.isNaN())
      return Ia;
    t = t.replace(eP, u.toString());
  }
  for (; t.includes("+") || /.-\d+(?:\.\d+)?/.test(t); ) {
    var s, [, c, f, v] = (s = tP.exec(t)) !== null && s !== void 0 ? s : [], p = ct.parse(c ?? ""), h = ct.parse(v ?? ""), y = f === "+" ? p.add(h) : p.subtract(h);
    if (y.isNaN())
      return Ia;
    t = t.replace(tP, y.toString());
  }
  return t;
}
var rP = /\(([^()]*)\)/;
function $W(e) {
  for (var t = e, r; (r = rP.exec(t)) != null; ) {
    var [, n] = r;
    t = t.replace(rP, cI(n));
  }
  return t;
}
function LW(e) {
  var t = e.replace(/\s+/g, "");
  return t = $W(t), t = cI(t), t;
}
function RW(e) {
  try {
    return LW(e);
  } catch {
    return Ia;
  }
}
function Wv(e) {
  var t = RW(e.slice(5, -1));
  return t === Ia ? "" : t;
}
var zW = ["x", "y", "lineHeight", "capHeight", "fill", "scaleToFit", "textAnchor", "verticalAnchor"], BW = ["dx", "dy", "angle", "className", "breakAll"];
function Rh() {
  return Rh = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Rh.apply(null, arguments);
}
function nP(e, t) {
  if (e == null) return {};
  var r, n, i = FW(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function FW(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
var fI = /[ \f\n\r\t\v\u2028\u2029]+/, dI = (e) => {
  var {
    children: t,
    breakAll: r,
    style: n
  } = e;
  try {
    var i = [];
    oe(t) || (r ? i = t.toString().split("") : i = t.toString().split(fI));
    var a = i.map((l) => ({
      word: l,
      width: Ba(l, n).width
    })), o = r ? 0 : Ba(" ", n).width;
    return {
      wordsWithComputedWidth: a,
      spaceWidth: o
    };
  } catch {
    return null;
  }
};
function KW(e) {
  return e === "start" || e === "middle" || e === "end" || e === "inherit";
}
var vI = (e, t, r, n) => e.reduce((i, a) => {
  var {
    word: o,
    width: l
  } = a, u = i[i.length - 1];
  if (u && l != null && (t == null || n || u.width + l + r < Number(t)))
    u.words.push(o), u.width += l + r;
  else {
    var s = {
      words: [o],
      width: l
    };
    i.push(s);
  }
  return i;
}, []), pI = (e) => e.reduce((t, r) => t.width > r.width ? t : r), WW = "…", iP = (e, t, r, n, i, a, o, l) => {
  var u = e.slice(0, t), s = dI({
    breakAll: r,
    style: n,
    children: u + WW
  });
  if (!s)
    return [!1, []];
  var c = vI(s.wordsWithComputedWidth, a, o, l), f = c.length > i || pI(c).width > Number(a);
  return [f, c];
}, UW = (e, t, r, n, i) => {
  var {
    maxLines: a,
    children: o,
    style: l,
    breakAll: u
  } = e, s = B(a), c = String(o), f = vI(t, n, r, i);
  if (!s || i)
    return f;
  var v = f.length > a || pI(f).width > Number(n);
  if (!v)
    return f;
  for (var p = 0, h = c.length - 1, y = 0, g; p <= h && y <= c.length - 1; ) {
    var m = Math.floor((p + h) / 2), b = m - 1, [x, w] = iP(c, b, u, l, a, n, r, i), [P] = iP(c, m, u, l, a, n, r, i);
    if (!x && !P && (p = m + 1), x && P && (h = m - 1), !x && P) {
      g = w;
      break;
    }
    y++;
  }
  return g || f;
}, aP = (e) => {
  var t = oe(e) ? [] : e.toString().split(fI);
  return [{
    words: t,
    width: void 0
  }];
}, VW = (e) => {
  var {
    width: t,
    scaleToFit: r,
    children: n,
    style: i,
    breakAll: a,
    maxLines: o
  } = e;
  if ((t || r) && !po.isSsr) {
    var l, u, s = dI({
      breakAll: a,
      children: n,
      style: i
    });
    if (s) {
      var {
        wordsWithComputedWidth: c,
        spaceWidth: f
      } = s;
      l = c, u = f;
    } else
      return aP(n);
    return UW({
      breakAll: a,
      children: n,
      maxLines: o,
      style: i
    }, l, u, t, !!r);
  }
  return aP(n);
}, hI = "#808080", HW = {
  angle: 0,
  breakAll: !1,
  // Magic number from d3
  capHeight: "0.71em",
  fill: hI,
  lineHeight: "1em",
  scaleToFit: !1,
  textAnchor: "start",
  // Maintain compat with existing charts / default SVG behavior
  verticalAnchor: "end",
  x: 0,
  y: 0
}, ci = /* @__PURE__ */ d.forwardRef((e, t) => {
  var r = ee(e, HW), {
    x: n,
    y: i,
    lineHeight: a,
    capHeight: o,
    fill: l,
    scaleToFit: u,
    textAnchor: s,
    verticalAnchor: c
  } = r, f = nP(r, zW), v = d.useMemo(() => VW({
    breakAll: f.breakAll,
    children: f.children,
    maxLines: f.maxLines,
    scaleToFit: u,
    style: f.style,
    width: f.width
  }), [f.breakAll, f.children, f.maxLines, u, f.style, f.width]), {
    dx: p,
    dy: h,
    angle: y,
    className: g,
    breakAll: m
  } = f, b = nP(f, BW);
  if (!it(n) || !it(i) || v.length === 0)
    return null;
  var x = Number(n) + (B(p) ? p : 0), w = Number(i) + (B(h) ? h : 0);
  if (!se(x) || !se(w))
    return null;
  var P;
  switch (c) {
    case "start":
      P = Wv("calc(".concat(o, ")"));
      break;
    case "middle":
      P = Wv("calc(".concat((v.length - 1) / 2, " * -").concat(a, " + (").concat(o, " / 2))"));
      break;
    default:
      P = Wv("calc(".concat(v.length - 1, " * -").concat(a, ")"));
      break;
  }
  var O = [];
  if (u) {
    var S = v[0].width, {
      width: E
    } = f;
    O.push("scale(".concat(B(E) && B(S) ? E / S : 1, ")"));
  }
  return y && O.push("rotate(".concat(y, ", ").concat(x, ", ").concat(w, ")")), O.length && (b.transform = O.join(" ")), /* @__PURE__ */ d.createElement("text", Rh({}, Ie(b), {
    ref: t,
    x,
    y: w,
    className: Y("recharts-text", g),
    textAnchor: s,
    fill: l.includes("url") ? hI : l
  }), v.map((k, _) => {
    var I = k.words.join(m ? "" : " ");
    return (
      // duplicate words will cause duplicate keys which is why we add the array index here
      /* @__PURE__ */ d.createElement("tspan", {
        x,
        dy: _ === 0 ? P : a,
        key: "".concat(I, "-").concat(_)
      }, I)
    );
  }));
});
ci.displayName = "Text";
var XW = ["labelRef"], YW = ["content"];
function oP(e, t) {
  if (e == null) return {};
  var r, n, i = GW(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function GW(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function lP(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Re(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? lP(Object(r), !0).forEach(function(n) {
      qW(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : lP(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function qW(e, t, r) {
  return (t = ZW(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function ZW(e) {
  var t = QW(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function QW(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function vn() {
  return vn = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, vn.apply(null, arguments);
}
var mI = /* @__PURE__ */ d.createContext(null), $d = (e) => {
  var {
    x: t,
    y: r,
    upperWidth: n,
    lowerWidth: i,
    width: a,
    height: o,
    children: l
  } = e, u = d.useMemo(() => ({
    x: t,
    y: r,
    upperWidth: n,
    lowerWidth: i,
    width: a,
    height: o
  }), [t, r, n, i, a, o]);
  return /* @__PURE__ */ d.createElement(mI.Provider, {
    value: u
  }, l);
}, yI = () => {
  var e = d.useContext(mI), t = vo();
  return e || $A(t);
}, gI = /* @__PURE__ */ d.createContext(null), JW = (e) => {
  var {
    cx: t,
    cy: r,
    innerRadius: n,
    outerRadius: i,
    startAngle: a,
    endAngle: o,
    clockWise: l,
    children: u
  } = e, s = d.useMemo(() => ({
    cx: t,
    cy: r,
    innerRadius: n,
    outerRadius: i,
    startAngle: a,
    endAngle: o,
    clockWise: l
  }), [t, r, n, i, a, o, l]);
  return /* @__PURE__ */ d.createElement(gI.Provider, {
    value: s
  }, u);
}, bI = () => {
  var e = d.useContext(gI), t = T(ua);
  return e || t;
}, e4 = (e) => {
  var {
    value: t,
    formatter: r
  } = e, n = oe(e.children) ? t : e.children;
  return typeof r == "function" ? r(n) : n;
}, Rg = (e) => e != null && typeof e == "function", t4 = (e, t) => {
  var r = We(t - e), n = Math.min(Math.abs(t - e), 360);
  return r * n;
}, r4 = (e, t, r, n, i) => {
  var {
    offset: a,
    className: o
  } = e, {
    cx: l,
    cy: u,
    innerRadius: s,
    outerRadius: c,
    startAngle: f,
    endAngle: v,
    clockWise: p
  } = i, h = (s + c) / 2, y = t4(f, v), g = y >= 0 ? 1 : -1, m, b;
  switch (t) {
    case "insideStart":
      m = f + g * a, b = p;
      break;
    case "insideEnd":
      m = v - g * a, b = !p;
      break;
    case "end":
      m = v + g * a, b = p;
      break;
    default:
      throw new Error("Unsupported position ".concat(t));
  }
  b = y <= 0 ? b : !b;
  var x = ce(l, u, h, m), w = ce(l, u, h, m + (b ? 1 : -1) * 359), P = "M".concat(x.x, ",").concat(x.y, `
    A`).concat(h, ",").concat(h, ",0,1,").concat(b ? 0 : 1, `,
    `).concat(w.x, ",").concat(w.y), O = oe(e.id) ? Ya("recharts-radial-line-") : e.id;
  return /* @__PURE__ */ d.createElement("text", vn({}, n, {
    dominantBaseline: "central",
    className: Y("recharts-radial-bar-label", o)
  }), /* @__PURE__ */ d.createElement("defs", null, /* @__PURE__ */ d.createElement("path", {
    id: O,
    d: P
  })), /* @__PURE__ */ d.createElement("textPath", {
    xlinkHref: "#".concat(O)
  }, r));
}, n4 = (e, t, r) => {
  var {
    cx: n,
    cy: i,
    innerRadius: a,
    outerRadius: o,
    startAngle: l,
    endAngle: u
  } = e, s = (l + u) / 2;
  if (r === "outside") {
    var {
      x: c,
      y: f
    } = ce(n, i, o + t, s);
    return {
      x: c,
      y: f,
      textAnchor: c >= n ? "start" : "end",
      verticalAnchor: "middle"
    };
  }
  if (r === "center")
    return {
      x: n,
      y: i,
      textAnchor: "middle",
      verticalAnchor: "middle"
    };
  if (r === "centerTop")
    return {
      x: n,
      y: i,
      textAnchor: "middle",
      verticalAnchor: "start"
    };
  if (r === "centerBottom")
    return {
      x: n,
      y: i,
      textAnchor: "middle",
      verticalAnchor: "end"
    };
  var v = (a + o) / 2, {
    x: p,
    y: h
  } = ce(n, i, v, s);
  return {
    x: p,
    y: h,
    textAnchor: "middle",
    verticalAnchor: "middle"
  };
}, zh = (e) => "cx" in e && B(e.cx), i4 = (e, t) => {
  var {
    parentViewBox: r,
    offset: n,
    position: i
  } = e, a;
  r != null && !zh(r) && (a = r);
  var {
    x: o,
    y: l,
    upperWidth: u,
    lowerWidth: s,
    height: c
  } = t, f = o, v = o + (u - s) / 2, p = (f + v) / 2, h = (u + s) / 2, y = f + u / 2, g = c >= 0 ? 1 : -1, m = g * n, b = g > 0 ? "end" : "start", x = g > 0 ? "start" : "end", w = u >= 0 ? 1 : -1, P = w * n, O = w > 0 ? "end" : "start", S = w > 0 ? "start" : "end";
  if (i === "top") {
    var E = {
      x: f + u / 2,
      y: l - m,
      textAnchor: "middle",
      verticalAnchor: b
    };
    return Re(Re({}, E), a ? {
      height: Math.max(l - a.y, 0),
      width: u
    } : {});
  }
  if (i === "bottom") {
    var k = {
      x: v + s / 2,
      y: l + c + m,
      textAnchor: "middle",
      verticalAnchor: x
    };
    return Re(Re({}, k), a ? {
      height: Math.max(a.y + a.height - (l + c), 0),
      width: s
    } : {});
  }
  if (i === "left") {
    var _ = {
      x: p - P,
      y: l + c / 2,
      textAnchor: O,
      verticalAnchor: "middle"
    };
    return Re(Re({}, _), a ? {
      width: Math.max(_.x - a.x, 0),
      height: c
    } : {});
  }
  if (i === "right") {
    var I = {
      x: p + h + P,
      y: l + c / 2,
      textAnchor: S,
      verticalAnchor: "middle"
    };
    return Re(Re({}, I), a ? {
      width: Math.max(a.x + a.width - I.x, 0),
      height: c
    } : {});
  }
  var j = a ? {
    width: h,
    height: c
  } : {};
  return i === "insideLeft" ? Re({
    x: p + P,
    y: l + c / 2,
    textAnchor: S,
    verticalAnchor: "middle"
  }, j) : i === "insideRight" ? Re({
    x: p + h - P,
    y: l + c / 2,
    textAnchor: O,
    verticalAnchor: "middle"
  }, j) : i === "insideTop" ? Re({
    x: f + u / 2,
    y: l + m,
    textAnchor: "middle",
    verticalAnchor: x
  }, j) : i === "insideBottom" ? Re({
    x: v + s / 2,
    y: l + c - m,
    textAnchor: "middle",
    verticalAnchor: b
  }, j) : i === "insideTopLeft" ? Re({
    x: f + P,
    y: l + m,
    textAnchor: S,
    verticalAnchor: x
  }, j) : i === "insideTopRight" ? Re({
    x: f + u - P,
    y: l + m,
    textAnchor: O,
    verticalAnchor: x
  }, j) : i === "insideBottomLeft" ? Re({
    x: v + P,
    y: l + c - m,
    textAnchor: S,
    verticalAnchor: b
  }, j) : i === "insideBottomRight" ? Re({
    x: v + s - P,
    y: l + c - m,
    textAnchor: O,
    verticalAnchor: b
  }, j) : i && typeof i == "object" && (B(i.x) || kn(i.x)) && (B(i.y) || kn(i.y)) ? Re({
    x: o + dt(i.x, h),
    y: l + dt(i.y, c),
    textAnchor: "end",
    verticalAnchor: "end"
  }, j) : Re({
    x: y,
    y: l + c / 2,
    textAnchor: "middle",
    verticalAnchor: "middle"
  }, j);
}, a4 = {
  angle: 0,
  offset: 5,
  zIndex: ie.label,
  position: "middle",
  textBreakAll: !1
};
function Vn(e) {
  var t = ee(e, a4), {
    viewBox: r,
    position: n,
    value: i,
    children: a,
    content: o,
    className: l = "",
    textBreakAll: u,
    labelRef: s
  } = t, c = bI(), f = yI(), v = n === "center" ? f : c ?? f, p, h, y;
  if (r == null ? p = v : zh(r) ? p = r : p = $A(r), !p || oe(i) && oe(a) && !/* @__PURE__ */ d.isValidElement(o) && typeof o != "function")
    return null;
  var g = Re(Re({}, t), {}, {
    viewBox: p
  });
  if (/* @__PURE__ */ d.isValidElement(o)) {
    var {
      labelRef: m
    } = g, b = oP(g, XW);
    return /* @__PURE__ */ d.cloneElement(o, b);
  }
  if (typeof o == "function") {
    var {
      content: x
    } = g, w = oP(g, YW);
    if (h = /* @__PURE__ */ d.createElement(o, w), /* @__PURE__ */ d.isValidElement(h))
      return h;
  } else
    h = e4(t);
  var P = Ie(t);
  if (zh(p)) {
    if (n === "insideStart" || n === "insideEnd" || n === "end")
      return r4(t, n, h, P, p);
    y = n4(p, t.offset, t.position);
  } else
    y = i4(t, p);
  return /* @__PURE__ */ d.createElement(pe, {
    zIndex: t.zIndex
  }, /* @__PURE__ */ d.createElement(ci, vn({
    ref: s,
    className: Y("recharts-label", l)
  }, P, y, {
    /*
     * textAnchor is decided by default based on the `position`
     * but we allow overriding via props for precise control.
     */
    textAnchor: KW(P.textAnchor) ? P.textAnchor : y.textAnchor,
    breakAll: u
  }), h));
}
Vn.displayName = "Label";
var xI = (e, t, r) => {
  if (!e)
    return null;
  var n = {
    viewBox: t,
    labelRef: r
  };
  return e === !0 ? /* @__PURE__ */ d.createElement(Vn, vn({
    key: "label-implicit"
  }, n)) : it(e) ? /* @__PURE__ */ d.createElement(Vn, vn({
    key: "label-implicit",
    value: e
  }, n)) : /* @__PURE__ */ d.isValidElement(e) ? e.type === Vn ? /* @__PURE__ */ d.cloneElement(e, Re({
    key: "label-implicit"
  }, n)) : /* @__PURE__ */ d.createElement(Vn, vn({
    key: "label-implicit",
    content: e
  }, n)) : Rg(e) ? /* @__PURE__ */ d.createElement(Vn, vn({
    key: "label-implicit",
    content: e
  }, n)) : e && typeof e == "object" ? /* @__PURE__ */ d.createElement(Vn, vn({}, e, {
    key: "label-implicit"
  }, n)) : null;
};
function Ld(e) {
  var {
    label: t,
    labelRef: r
  } = e, n = yI();
  return xI(t, n, r) || null;
}
function o4(e) {
  var {
    label: t
  } = e, r = bI();
  return xI(t, r) || null;
}
var wI = {}, PI = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r) {
    return r[r.length - 1];
  }
  e.last = t;
})(PI);
var OI = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r) {
    return Array.isArray(r) ? r : Array.from(r);
  }
  e.toArray = t;
})(OI);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = PI, r = OI, n = fo;
  function i(a) {
    if (n.isArrayLike(a))
      return t.last(r.toArray(a));
  }
  e.last = i;
})(wI);
var l4 = wI.last;
const SI = /* @__PURE__ */ Wt(l4);
var u4 = ["valueAccessor"], s4 = ["dataKey", "clockWise", "id", "textBreakAll", "zIndex"];
function cf() {
  return cf = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, cf.apply(null, arguments);
}
function uP(e, t) {
  if (e == null) return {};
  var r, n, i = c4(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function c4(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
var f4 = (e) => Array.isArray(e.value) ? SI(e.value) : e.value, EI = /* @__PURE__ */ d.createContext(void 0), _o = EI.Provider, AI = /* @__PURE__ */ d.createContext(void 0), kI = AI.Provider;
function d4() {
  return d.useContext(EI);
}
function v4() {
  return d.useContext(AI);
}
function Gs(e) {
  var {
    valueAccessor: t = f4
  } = e, r = uP(e, u4), {
    dataKey: n,
    clockWise: i,
    id: a,
    textBreakAll: o,
    zIndex: l
  } = r, u = uP(r, s4), s = d4(), c = v4(), f = s || c;
  return !f || !f.length ? null : /* @__PURE__ */ d.createElement(pe, {
    zIndex: l ?? ie.label
  }, /* @__PURE__ */ d.createElement(U, {
    className: "recharts-label-list"
  }, f.map((v, p) => {
    var h, y = oe(n) ? t(v, p) : G(v && v.payload, n), g = oe(a) ? {} : {
      id: "".concat(a, "-").concat(p)
    };
    return /* @__PURE__ */ d.createElement(Vn, cf({
      key: "label-".concat(p)
    }, Ie(v), u, g, {
      /*
       * Prefer to use the explicit fill from LabelList props.
       * Only in an absence of that, fall back to the fill of the entry.
       * The entry fill can be quite difficult to see especially in Bar, Pie, RadialBar in inside positions.
       * On the other hand it's quite convenient in Scatter, Line, or when the position is outside the Bar, Pie filled shapes.
       */
      fill: (h = r.fill) !== null && h !== void 0 ? h : v.fill,
      parentViewBox: v.parentViewBox,
      value: y,
      textBreakAll: o,
      viewBox: v.viewBox,
      index: p,
      zIndex: 0
    }));
  })));
}
Gs.displayName = "LabelList";
function bi(e) {
  var {
    label: t
  } = e;
  return t ? t === !0 ? /* @__PURE__ */ d.createElement(Gs, {
    key: "labelList-implicit"
  }) : /* @__PURE__ */ d.isValidElement(t) || Rg(t) ? /* @__PURE__ */ d.createElement(Gs, {
    key: "labelList-implicit",
    content: t
  }) : typeof t == "object" ? /* @__PURE__ */ d.createElement(Gs, cf({
    key: "labelList-implicit"
  }, t, {
    type: String(t.type)
  })) : null : null;
}
var p4 = ["points", "className", "baseLinePoints", "connectNulls"], sP;
function ja() {
  return ja = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, ja.apply(null, arguments);
}
function h4(e, t) {
  if (e == null) return {};
  var r, n, i = m4(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function m4(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function y4(e, t) {
  return t || (t = e.slice(0)), Object.freeze(Object.defineProperties(e, { raw: { value: Object.freeze(t) } }));
}
var cP = (e) => e && e.x === +e.x && e.y === +e.y, g4 = function() {
  var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], r = [[]];
  return t.forEach((n) => {
    cP(n) ? r[r.length - 1].push(n) : r[r.length - 1].length > 0 && r.push([]);
  }), cP(t[0]) && r[r.length - 1].push(t[0]), r[r.length - 1].length <= 0 && (r = r.slice(0, -1)), r;
}, pl = (e, t) => {
  var r = g4(e);
  t && (r = [r.reduce((i, a) => [...i, ...a], [])]);
  var n = r.map((i) => i.reduce((a, o, l) => Ce(sP || (sP = y4(["", "", "", ",", ""])), a, l === 0 ? "M" : "L", o.x, o.y), "")).join("");
  return r.length === 1 ? "".concat(n, "Z") : n;
}, b4 = (e, t, r) => {
  var n = pl(e, r);
  return "".concat(n.slice(-1) === "Z" ? n.slice(0, -1) : n, "L").concat(pl(Array.from(t).reverse(), r).slice(1));
}, zg = (e) => {
  var {
    points: t,
    className: r,
    baseLinePoints: n,
    connectNulls: i
  } = e, a = h4(e, p4);
  if (!t || !t.length)
    return null;
  var o = Y("recharts-polygon", r);
  if (n && n.length) {
    var l = a.stroke && a.stroke !== "none", u = b4(t, n, i);
    return /* @__PURE__ */ d.createElement("g", {
      className: o
    }, /* @__PURE__ */ d.createElement("path", ja({}, Ie(a), {
      fill: u.slice(-1) === "Z" ? a.fill : "none",
      stroke: "none",
      d: u
    })), l ? /* @__PURE__ */ d.createElement("path", ja({}, Ie(a), {
      fill: "none",
      d: pl(t, i)
    })) : null, l ? /* @__PURE__ */ d.createElement("path", ja({}, Ie(a), {
      fill: "none",
      d: pl(n, i)
    })) : null);
  }
  var s = pl(t, i);
  return /* @__PURE__ */ d.createElement("path", ja({}, Ie(a), {
    fill: s.slice(-1) === "Z" ? a.fill : "none",
    className: o,
    d: s
  }));
};
function Bh() {
  return Bh = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Bh.apply(null, arguments);
}
var Rd = (e) => {
  var {
    cx: t,
    cy: r,
    r: n,
    className: i
  } = e, a = Y("recharts-dot", i);
  return B(t) && B(r) && B(n) ? /* @__PURE__ */ d.createElement("circle", Bh({}, re(e), ty(e), {
    className: a,
    cx: t,
    cy: r,
    r: n
  })) : null;
}, $u = (e) => e.graphicalItems.polarItems, x4 = A([ye, ku], ug), Lu = A([$u, Ne, x4], sg), w4 = A([Lu], cg), zd = A([w4, yi], fg), _I = A([zd, Ne, Lu], vg);
A([zd, Ne, Lu], (e, t, r) => r.length > 0 ? e.flatMap((n) => r.flatMap((i) => {
  var a, o = G(n, (a = t.dataKey) !== null && a !== void 0 ? a : i.dataKey);
  return {
    value: o,
    errorDomain: []
    // polar charts do not have error bars
  };
})).filter(Boolean) : (t == null ? void 0 : t.dataKey) != null ? e.map((n) => ({
  value: G(n, t.dataKey),
  errorDomain: []
})) : e.map((n) => ({
  value: n,
  errorDomain: []
})));
var fP = () => {
}, P4 = A([zd, Ne, Lu, Id, ye], gg), O4 = A([Ne, mg, yg, fP, P4, fP, q, ye], bg), II = A([Ne, q, zd, _I, go, ye, O4], xg), jI = A([II, Ne, gi], Pg), S4 = A([Ne, II, jI, ye], Sg), Bg = (e, t, r) => {
  switch (t) {
    case "angleAxis":
      return la(e, r);
    case "radiusAxis":
      return bo(e, r);
    default:
      throw new Error("Unexpected axis type: ".concat(t));
  }
}, Fg = (e, t, r) => {
  switch (t) {
    case "angleAxis":
      return s3(e, r);
    case "radiusAxis":
      return c3(e, r);
    default:
      throw new Error("Unexpected axis type: ".concat(t));
  }
}, xi = A([Bg, gi, S4, Fg], jd), CI = A([q, _I, wo, ye], Eg), ca = A([q, Bg, gi, xi, jI, Fg, Tu, CI, ye], C_), E4 = A([ca], (e) => {
  if (e) {
    var t = /* @__PURE__ */ new Map();
    return e.forEach((r) => {
      var n = (r.coordinate + 360) % 360;
      t.has(n) || t.set(n, r);
    }), Array.from(t.values());
  }
}), A4 = A([q, Bg, xi, Fg, Tu, CI, ye], M_), k4 = (e, t) => ca(e, "angleAxis", t, !1), _4 = A([k4], (e) => {
  if (e)
    return e.map((t) => t.coordinate);
}), I4 = (e, t) => ca(e, "radiusAxis", t, !1), j4 = A([I4], (e) => {
  if (e)
    return e.map((t) => t.coordinate);
}), C4 = ["gridType", "radialLines", "angleAxisId", "radiusAxisId", "cx", "cy", "innerRadius", "outerRadius", "polarAngles", "polarRadius"];
function T4(e, t) {
  if (e == null) return {};
  var r, n, i = M4(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function M4(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function _r() {
  return _r = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, _r.apply(null, arguments);
}
function dP(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Hl(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? dP(Object(r), !0).forEach(function(n) {
      D4(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : dP(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function D4(e, t, r) {
  return (t = N4(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function N4(e) {
  var t = $4(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function $4(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var L4 = (e, t, r, n) => {
  var i = "";
  return n.forEach((a, o) => {
    var l = ce(t, r, e, a);
    o ? i += "L ".concat(l.x, ",").concat(l.y) : i += "M ".concat(l.x, ",").concat(l.y);
  }), i += "Z", i;
}, R4 = (e) => {
  var {
    cx: t,
    cy: r,
    innerRadius: n,
    outerRadius: i,
    polarAngles: a,
    radialLines: o
  } = e;
  if (!a || !a.length || !o)
    return null;
  var l = Hl({
    stroke: "#ccc"
  }, re(e));
  return /* @__PURE__ */ d.createElement("g", {
    className: "recharts-polar-grid-angle"
  }, a.map((u) => {
    var s = ce(t, r, n, u), c = ce(t, r, i, u);
    return /* @__PURE__ */ d.createElement("line", _r({
      key: "line-".concat(u)
    }, l, {
      x1: s.x,
      y1: s.y,
      x2: c.x,
      y2: c.y
    }));
  }));
}, vP = (e) => {
  var {
    cx: t,
    cy: r,
    radius: n
  } = e, i = Hl({
    stroke: "#ccc",
    fill: "none"
  }, re(e));
  return (
    // @ts-expect-error wrong SVG element type
    /* @__PURE__ */ d.createElement("circle", _r({}, i, {
      className: Y("recharts-polar-grid-concentric-circle", e.className),
      cx: t,
      cy: r,
      r: n
    }))
  );
}, pP = (e) => {
  var {
    radius: t
  } = e, r = Hl({
    stroke: "#ccc",
    fill: "none"
  }, re(e));
  return /* @__PURE__ */ d.createElement("path", _r({}, r, {
    className: Y("recharts-polar-grid-concentric-polygon", e.className),
    d: L4(t, e.cx, e.cy, e.polarAngles)
  }));
}, z4 = (e) => {
  var {
    polarRadius: t,
    gridType: r
  } = e;
  if (!t || !t.length)
    return null;
  var n = Math.max(...t), i = e.fill && e.fill !== "none";
  return /* @__PURE__ */ d.createElement("g", {
    className: "recharts-polar-grid-concentric"
  }, i && r === "circle" && /* @__PURE__ */ d.createElement(vP, _r({}, e, {
    radius: n
  })), i && r !== "circle" && /* @__PURE__ */ d.createElement(pP, _r({}, e, {
    radius: n
  })), t.map((a, o) => {
    var l = o;
    return r === "circle" ? /* @__PURE__ */ d.createElement(vP, _r({
      key: l
    }, e, {
      fill: "none",
      radius: a
    })) : /* @__PURE__ */ d.createElement(pP, _r({
      key: l
    }, e, {
      fill: "none",
      radius: a
    }));
  }));
}, B4 = (e) => {
  var t, r, n, i, a, o, l, u, s, {
    gridType: c = "polygon",
    radialLines: f = !0,
    angleAxisId: v = 0,
    radiusAxisId: p = 0,
    cx: h,
    cy: y,
    innerRadius: g,
    outerRadius: m,
    polarAngles: b,
    polarRadius: x
  } = e, w = T4(e, C4), P = T(ua), O = T((j) => _4(j, v)), S = T((j) => j4(j, p)), E = Array.isArray(b) ? b : O, k = Array.isArray(x) ? x : S;
  if (E == null || k == null)
    return null;
  var _ = Hl(Hl({
    cx: (t = (r = P == null ? void 0 : P.cx) !== null && r !== void 0 ? r : h) !== null && t !== void 0 ? t : 0,
    cy: (n = (i = P == null ? void 0 : P.cy) !== null && i !== void 0 ? i : y) !== null && n !== void 0 ? n : 0,
    innerRadius: (a = (o = P == null ? void 0 : P.innerRadius) !== null && o !== void 0 ? o : g) !== null && a !== void 0 ? a : 0,
    outerRadius: (l = (u = P == null ? void 0 : P.outerRadius) !== null && u !== void 0 ? u : m) !== null && l !== void 0 ? l : 0,
    polarAngles: E,
    polarRadius: k
  }, w), {}, {
    zIndex: (s = w.zIndex) !== null && s !== void 0 ? s : ie.grid
  }), {
    outerRadius: I
  } = _;
  return I <= 0 ? null : /* @__PURE__ */ d.createElement(pe, {
    zIndex: _.zIndex
  }, /* @__PURE__ */ d.createElement("g", {
    className: "recharts-polar-grid"
  }, /* @__PURE__ */ d.createElement(z4, _r({
    gridType: c,
    radialLines: f
  }, _, {
    polarAngles: E,
    polarRadius: k
  })), /* @__PURE__ */ d.createElement(R4, _r({
    gridType: c,
    radialLines: f
  }, _, {
    polarAngles: E,
    polarRadius: k
  }))));
};
B4.displayName = "PolarGrid";
var TI = {}, MI = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r, n) {
    if (r.length === 0)
      return;
    let i = r[0], a = n(i);
    for (let o = 1; o < r.length; o++) {
      const l = r[o], u = n(l);
      u > a && (a = u, i = l);
    }
    return i;
  }
  e.maxBy = t;
})(MI);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = MI, r = du, n = vu;
  function i(a, o) {
    if (a != null)
      return t.maxBy(Array.from(a), n.iteratee(o ?? r.identity));
  }
  e.maxBy = i;
})(TI);
var F4 = TI.maxBy;
const DI = /* @__PURE__ */ Wt(F4);
var NI = {}, $I = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r, n) {
    if (r.length === 0)
      return;
    let i = r[0], a = n(i);
    for (let o = 1; o < r.length; o++) {
      const l = r[o], u = n(l);
      u < a && (a = u, i = l);
    }
    return i;
  }
  e.minBy = t;
})($I);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = $I, r = du, n = vu;
  function i(a, o) {
    if (a != null)
      return t.minBy(Array.from(a), n.iteratee(o ?? r.identity));
  }
  e.minBy = i;
})(NI);
var K4 = NI.minBy;
const W4 = /* @__PURE__ */ Wt(K4);
var U4 = {
  radiusAxis: {},
  angleAxis: {}
}, LI = Ut({
  name: "polarAxis",
  initialState: U4,
  reducers: {
    addRadiusAxis(e, t) {
      e.radiusAxis[t.payload.id] = t.payload;
    },
    removeRadiusAxis(e, t) {
      delete e.radiusAxis[t.payload.id];
    },
    addAngleAxis(e, t) {
      e.angleAxis[t.payload.id] = t.payload;
    },
    removeAngleAxis(e, t) {
      delete e.angleAxis[t.payload.id];
    }
  }
}), {
  addRadiusAxis: V4,
  removeRadiusAxis: H4,
  addAngleAxis: X4,
  removeAngleAxis: Y4
} = LI.actions, G4 = LI.reducer, q4 = ["cx", "cy", "angle", "axisLine"], Z4 = ["angle", "tickFormatter", "stroke", "tick"];
function Xl() {
  return Xl = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Xl.apply(null, arguments);
}
function hP(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function bn(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? hP(Object(r), !0).forEach(function(n) {
      Q4(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : hP(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function Q4(e, t, r) {
  return (t = J4(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function J4(e) {
  var t = e5(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function e5(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function RI(e, t) {
  if (e == null) return {};
  var r, n, i = t5(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function t5(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
var r5 = "radiusAxis";
function n5(e) {
  var t = J();
  return d.useEffect(() => (t(V4(e)), () => {
    t(H4(e));
  })), null;
}
var i5 = (e, t, r, n) => {
  var {
    coordinate: i
  } = e;
  return ce(r, n, i, t);
}, a5 = (e) => {
  var t;
  switch (e) {
    case "left":
      t = "end";
      break;
    case "right":
      t = "start";
      break;
    default:
      t = "middle";
      break;
  }
  return t;
}, o5 = (e, t, r, n) => {
  var i = DI(n, (o) => o.coordinate || 0), a = W4(n, (o) => o.coordinate || 0);
  return {
    cx: t,
    cy: r,
    startAngle: e,
    endAngle: e,
    innerRadius: (a == null ? void 0 : a.coordinate) || 0,
    outerRadius: (i == null ? void 0 : i.coordinate) || 0,
    clockWise: !1
  };
}, l5 = (e, t) => {
  var {
    cx: r,
    cy: n,
    angle: i,
    axisLine: a
  } = e, o = RI(e, q4), l = t.reduce((f, v) => [Math.min(f[0], v.coordinate), Math.max(f[1], v.coordinate)], [1 / 0, -1 / 0]), u = ce(r, n, l[0], i), s = ce(r, n, l[1], i), c = bn(bn(bn({}, re(o)), {}, {
    fill: "none"
  }, re(a)), {}, {
    x1: u.x,
    y1: u.y,
    x2: s.x,
    y2: s.y
  });
  return /* @__PURE__ */ d.createElement("line", Xl({
    className: "recharts-polar-radius-axis-line"
  }, c));
}, u5 = (e, t, r) => {
  var n;
  return /* @__PURE__ */ d.isValidElement(e) ? n = /* @__PURE__ */ d.cloneElement(e, t) : typeof e == "function" ? n = e(t) : n = /* @__PURE__ */ d.createElement(ci, Xl({}, t, {
    className: "recharts-polar-radius-axis-tick-value"
  }), r), n;
}, s5 = (e, t) => {
  var {
    angle: r,
    tickFormatter: n,
    stroke: i,
    tick: a
  } = e, o = RI(e, Z4), l = a5(e.orientation), u = re(o), s = er(a), c = t.map((f, v) => {
    var p = i5(f, e.angle, e.cx, e.cy), h = bn(bn(bn(bn({
      textAnchor: l,
      transform: "rotate(".concat(90 - r, ", ").concat(p.x, ", ").concat(p.y, ")")
    }, u), {}, {
      stroke: "none",
      fill: i
    }, s), {}, {
      index: v
    }, p), {}, {
      payload: f
    });
    return /* @__PURE__ */ d.createElement(U, Xl({
      className: Y("recharts-polar-radius-axis-tick", tk(a)),
      key: "tick-".concat(f.coordinate)
    }, Nr(e, f, v)), u5(a, h, n ? n(f.value, v) : f.value));
  });
  return /* @__PURE__ */ d.createElement(U, {
    className: "recharts-polar-radius-axis-ticks"
  }, c);
}, c5 = (e) => {
  var {
    radiusAxisId: t
  } = e, r = T(ua), n = T((u) => xi(u, "radiusAxis", t)), i = T((u) => ca(u, "radiusAxis", t, !1));
  if (r == null || !i || !i.length || n == null)
    return null;
  var a = bn(bn({}, e), {}, {
    scale: n
  }, r), {
    tick: o,
    axisLine: l
  } = a;
  return /* @__PURE__ */ d.createElement(pe, {
    zIndex: a.zIndex
  }, /* @__PURE__ */ d.createElement(U, {
    className: Y("recharts-polar-radius-axis", r5, a.className)
  }, l && l5(a, i), o && s5(a, i), /* @__PURE__ */ d.createElement(JW, o5(a.angle, a.cx, a.cy, i), /* @__PURE__ */ d.createElement(o4, {
    label: a.label
  }), a.children)));
};
function f5(e) {
  var t = ee(e, Ct);
  return /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(n5, {
    domain: t.domain,
    id: t.radiusAxisId,
    scale: t.scale,
    type: t.type,
    dataKey: t.dataKey,
    unit: void 0,
    name: t.name,
    allowDuplicatedCategory: t.allowDuplicatedCategory,
    allowDataOverflow: t.allowDataOverflow,
    reversed: t.reversed,
    includeHidden: t.includeHidden,
    allowDecimals: t.allowDecimals,
    ticks: t.ticks,
    tickCount: t.tickCount,
    tick: t.tick
  }), /* @__PURE__ */ d.createElement(c5, t));
}
f5.displayName = "PolarRadiusAxis";
var d5 = ["children"];
function Qi() {
  return Qi = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Qi.apply(null, arguments);
}
function mP(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Wr(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? mP(Object(r), !0).forEach(function(n) {
      v5(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : mP(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function v5(e, t, r) {
  return (t = p5(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function p5(e) {
  var t = h5(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function h5(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function m5(e, t) {
  if (e == null) return {};
  var r, n, i = y5(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function y5(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
var yP = 1e-5, g5 = Math.cos(Yc(45)), b5 = "angleAxis";
function x5(e) {
  var t = J(), r = d.useMemo(() => {
    var {
      children: a
    } = e, o = m5(e, d5);
    return o;
  }, [e]), n = T((a) => la(a, r.id)), i = r === n;
  return d.useEffect(() => (t(X4(r)), () => {
    t(Y4(r));
  }), [t, r]), i ? e.children : null;
}
var w5 = (e, t) => {
  var {
    cx: r,
    cy: n,
    radius: i,
    orientation: a,
    tickSize: o
  } = t, l = o || 8, u = ce(r, n, i, e.coordinate), s = ce(r, n, i + (a === "inner" ? -1 : 1) * l, e.coordinate);
  return {
    x1: u.x,
    y1: u.y,
    x2: s.x,
    y2: s.y
  };
}, P5 = (e, t) => {
  var r = Math.cos(Yc(-e.coordinate));
  return r > yP ? t === "outer" ? "start" : "end" : r < -yP ? t === "outer" ? "end" : "start" : "middle";
}, O5 = (e) => {
  var t = Math.cos(Yc(-e.coordinate)), r = Math.sin(Yc(-e.coordinate));
  return Math.abs(t) <= g5 ? r > 0 ? "start" : "end" : "middle";
}, S5 = (e) => {
  var {
    cx: t,
    cy: r,
    radius: n,
    axisLineType: i,
    axisLine: a,
    ticks: o
  } = e;
  if (!a)
    return null;
  var l = Wr(Wr({}, re(e)), {}, {
    fill: "none"
  }, re(a));
  if (i === "circle")
    return /* @__PURE__ */ d.createElement(Rd, Qi({
      className: "recharts-polar-angle-axis-line"
    }, l, {
      cx: t,
      cy: r,
      r: n
    }));
  var u = o.map((s) => ce(t, r, n, s.coordinate));
  return /* @__PURE__ */ d.createElement(zg, Qi({
    className: "recharts-polar-angle-axis-line"
  }, l, {
    points: u
  }));
}, E5 = (e) => {
  var {
    tick: t,
    tickProps: r,
    value: n
  } = e;
  return t ? /* @__PURE__ */ d.isValidElement(t) ? /* @__PURE__ */ d.cloneElement(t, r) : typeof t == "function" ? t(r) : /* @__PURE__ */ d.createElement(ci, Qi({}, r, {
    className: "recharts-polar-angle-axis-tick-value"
  }), n) : null;
}, A5 = (e) => {
  var {
    tick: t,
    tickLine: r,
    tickFormatter: n,
    stroke: i,
    ticks: a
  } = e, o = re(e), l = er(t), u = Wr(Wr({}, o), {}, {
    fill: "none"
  }, re(r)), s = a.map((c, f) => {
    var v = w5(c, e), p = P5(c, e.orientation), h = O5(c), y = Wr(Wr(Wr({}, o), {}, {
      // @ts-expect-error customTickProps is contributing unknown props
      textAnchor: p,
      verticalAnchor: h,
      // @ts-expect-error customTickProps is contributing unknown props
      stroke: "none",
      // @ts-expect-error customTickProps is contributing unknown props
      fill: i
    }, l), {}, {
      index: f,
      payload: c,
      x: v.x2,
      y: v.y2
    });
    return /* @__PURE__ */ d.createElement(U, Qi({
      className: Y("recharts-polar-angle-axis-tick", tk(t)),
      key: "tick-".concat(c.coordinate)
    }, Nr(e, c, f)), r && /* @__PURE__ */ d.createElement("line", Qi({
      className: "recharts-polar-angle-axis-tick-line"
    }, u, v)), /* @__PURE__ */ d.createElement(E5, {
      tick: t,
      tickProps: y,
      value: n ? n(c.value, f) : c.value
    }));
  });
  return /* @__PURE__ */ d.createElement(U, {
    className: "recharts-polar-angle-axis-ticks"
  }, s);
}, k5 = (e) => {
  var {
    angleAxisId: t
  } = e, r = T(ua), n = T((l) => xi(l, "angleAxis", t)), i = me(), a = T((l) => E4(l, "angleAxis", t, i));
  if (r == null || !a || !a.length || n == null)
    return null;
  var o = Wr(Wr(Wr({}, e), {}, {
    scale: n
  }, r), {}, {
    radius: r.outerRadius,
    ticks: a
  });
  return /* @__PURE__ */ d.createElement(pe, {
    zIndex: o.zIndex
  }, /* @__PURE__ */ d.createElement(U, {
    className: Y("recharts-polar-angle-axis", b5, o.className)
  }, /* @__PURE__ */ d.createElement(S5, o), /* @__PURE__ */ d.createElement(A5, o)));
};
function _5(e) {
  var t = ee(e, Kr);
  return /* @__PURE__ */ d.createElement(x5, {
    id: t.angleAxisId,
    scale: t.scale,
    type: t.type,
    dataKey: t.dataKey,
    unit: void 0,
    name: t.name,
    allowDuplicatedCategory: !1,
    allowDataOverflow: !1,
    reversed: t.reversed,
    includeHidden: !1,
    allowDecimals: t.allowDecimals,
    tickCount: t.tickCount,
    ticks: t.ticks,
    tick: t.tick,
    domain: t.domain
  }, /* @__PURE__ */ d.createElement(k5, t));
}
_5.displayName = "PolarAngleAxis";
function gP(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function bP(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? gP(Object(r), !0).forEach(function(n) {
      I5(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : gP(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function I5(e, t, r) {
  return (t = j5(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function j5(e) {
  var t = C5(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function C5(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var T5 = (e, t) => t, Kg = A([$u, T5], (e, t) => e.filter((r) => r.type === "pie").find((r) => r.id === t)), M5 = [], Wg = (e, t, r) => (r == null ? void 0 : r.length) === 0 ? M5 : r, zI = A([yi, Kg, Wg], (e, t, r) => {
  var {
    chartData: n
  } = e;
  if (t != null) {
    var i;
    if ((t == null ? void 0 : t.data) != null && t.data.length > 0 ? i = t.data : i = n, (!i || !i.length) && r != null && (i = r.map((a) => bP(bP({}, t.presentationProps), a.props))), i != null)
      return i;
  }
}), D5 = A([zI, Kg, Wg], (e, t, r) => {
  if (!(e == null || t == null))
    return e.map((n, i) => {
      var a, o = G(n, t.nameKey, t.name), l;
      return r != null && (a = r[i]) !== null && a !== void 0 && (a = a.props) !== null && a !== void 0 && a.fill ? l = r[i].props.fill : typeof n == "object" && n != null && "fill" in n ? l = n.fill : l = t.fill, {
        value: ir(o, t.dataKey),
        color: l,
        // @ts-expect-error we need a better typing for our data inputs
        payload: n,
        type: t.legendType
      };
    });
}), N5 = A([zI, Kg, Wg, Ve], (e, t, r, n) => {
  if (!(t == null || e == null))
    return F6({
      offset: n,
      pieSettings: t,
      displayedData: e,
      cells: r
    });
}), BI = { exports: {} }, ge = {};
/** @license React v17.0.2
 * react-is.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Bd = 60103, Fd = 60106, Ru = 60107, zu = 60108, Bu = 60114, Fu = 60109, Ku = 60110, Wu = 60112, Uu = 60113, Ug = 60120, Vu = 60115, Hu = 60116, FI = 60121, KI = 60122, WI = 60117, UI = 60129, VI = 60131;
if (typeof Symbol == "function" && Symbol.for) {
  var lt = Symbol.for;
  Bd = lt("react.element"), Fd = lt("react.portal"), Ru = lt("react.fragment"), zu = lt("react.strict_mode"), Bu = lt("react.profiler"), Fu = lt("react.provider"), Ku = lt("react.context"), Wu = lt("react.forward_ref"), Uu = lt("react.suspense"), Ug = lt("react.suspense_list"), Vu = lt("react.memo"), Hu = lt("react.lazy"), FI = lt("react.block"), KI = lt("react.server.block"), WI = lt("react.fundamental"), UI = lt("react.debug_trace_mode"), VI = lt("react.legacy_hidden");
}
function $r(e) {
  if (typeof e == "object" && e !== null) {
    var t = e.$$typeof;
    switch (t) {
      case Bd:
        switch (e = e.type, e) {
          case Ru:
          case Bu:
          case zu:
          case Uu:
          case Ug:
            return e;
          default:
            switch (e = e && e.$$typeof, e) {
              case Ku:
              case Wu:
              case Hu:
              case Vu:
              case Fu:
                return e;
              default:
                return t;
            }
        }
      case Fd:
        return t;
    }
  }
}
var $5 = Fu, L5 = Bd, R5 = Wu, z5 = Ru, B5 = Hu, F5 = Vu, K5 = Fd, W5 = Bu, U5 = zu, V5 = Uu;
ge.ContextConsumer = Ku;
ge.ContextProvider = $5;
ge.Element = L5;
ge.ForwardRef = R5;
ge.Fragment = z5;
ge.Lazy = B5;
ge.Memo = F5;
ge.Portal = K5;
ge.Profiler = W5;
ge.StrictMode = U5;
ge.Suspense = V5;
ge.isAsyncMode = function() {
  return !1;
};
ge.isConcurrentMode = function() {
  return !1;
};
ge.isContextConsumer = function(e) {
  return $r(e) === Ku;
};
ge.isContextProvider = function(e) {
  return $r(e) === Fu;
};
ge.isElement = function(e) {
  return typeof e == "object" && e !== null && e.$$typeof === Bd;
};
ge.isForwardRef = function(e) {
  return $r(e) === Wu;
};
ge.isFragment = function(e) {
  return $r(e) === Ru;
};
ge.isLazy = function(e) {
  return $r(e) === Hu;
};
ge.isMemo = function(e) {
  return $r(e) === Vu;
};
ge.isPortal = function(e) {
  return $r(e) === Fd;
};
ge.isProfiler = function(e) {
  return $r(e) === Bu;
};
ge.isStrictMode = function(e) {
  return $r(e) === zu;
};
ge.isSuspense = function(e) {
  return $r(e) === Uu;
};
ge.isValidElementType = function(e) {
  return typeof e == "string" || typeof e == "function" || e === Ru || e === Bu || e === UI || e === zu || e === Uu || e === Ug || e === VI || typeof e == "object" && e !== null && (e.$$typeof === Hu || e.$$typeof === Vu || e.$$typeof === Fu || e.$$typeof === Ku || e.$$typeof === Wu || e.$$typeof === WI || e.$$typeof === FI || e[0] === KI);
};
ge.typeOf = $r;
BI.exports = ge;
var H5 = BI.exports, xP = (e) => typeof e == "string" ? e : e ? e.displayName || e.name || "Component" : "", wP = null, Uv = null, HI = (e) => {
  if (e === wP && Array.isArray(Uv))
    return Uv;
  var t = [];
  return d.Children.forEach(e, (r) => {
    oe(r) || (H5.isFragment(r) ? t = t.concat(HI(r.props.children)) : t.push(r));
  }), Uv = t, wP = e, t;
};
function Io(e, t) {
  var r = [], n = [];
  return Array.isArray(t) ? n = t.map((i) => xP(i)) : n = [xP(t)], HI(e).forEach((i) => {
    var a = Gr(i, "type.displayName") || Gr(i, "type.name");
    a && n.indexOf(a) !== -1 && r.push(i);
  }), r;
}
var Vg = (e) => e && typeof e == "object" && "clipDot" in e ? !!e.clipDot : !0, Hg = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r) {
    var i;
    if (typeof r != "object" || r == null)
      return !1;
    if (Object.getPrototypeOf(r) === null)
      return !0;
    if (Object.prototype.toString.call(r) !== "[object Object]") {
      const a = r[Symbol.toStringTag];
      return a == null || !((i = Object.getOwnPropertyDescriptor(r, Symbol.toStringTag)) != null && i.writable) ? !1 : r.toString() === `[object ${a}]`;
    }
    let n = r;
    for (; Object.getPrototypeOf(n) !== null; )
      n = Object.getPrototypeOf(n);
    return Object.getPrototypeOf(r) === n;
  }
  e.isPlainObject = t;
})(Hg);
var X5 = Hg.isPlainObject;
const Y5 = /* @__PURE__ */ Wt(X5);
var PP, OP, SP, EP, AP;
function kP(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function _P(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? kP(Object(r), !0).forEach(function(n) {
      G5(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : kP(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function G5(e, t, r) {
  return (t = q5(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function q5(e) {
  var t = Z5(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function Z5(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function ff() {
  return ff = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, ff.apply(null, arguments);
}
function Zo(e, t) {
  return t || (t = e.slice(0)), Object.freeze(Object.defineProperties(e, { raw: { value: Object.freeze(t) } }));
}
var IP = (e, t, r, n, i) => {
  var a = r - n, o;
  return o = Ce(PP || (PP = Zo(["M ", ",", ""])), e, t), o += Ce(OP || (OP = Zo(["L ", ",", ""])), e + r, t), o += Ce(SP || (SP = Zo(["L ", ",", ""])), e + r - a / 2, t + i), o += Ce(EP || (EP = Zo(["L ", ",", ""])), e + r - a / 2 - n, t + i), o += Ce(AP || (AP = Zo(["L ", ",", " Z"])), e, t), o;
}, Q5 = {
  x: 0,
  y: 0,
  upperWidth: 0,
  lowerWidth: 0,
  height: 0,
  isUpdateAnimationActive: !1,
  animationBegin: 0,
  animationDuration: 1500,
  animationEasing: "ease"
}, J5 = (e) => {
  var t = ee(e, Q5), {
    x: r,
    y: n,
    upperWidth: i,
    lowerWidth: a,
    height: o,
    className: l
  } = t, {
    animationEasing: u,
    animationDuration: s,
    animationBegin: c,
    isUpdateAnimationActive: f
  } = t, v = d.useRef(null), [p, h] = d.useState(-1), y = d.useRef(i), g = d.useRef(a), m = d.useRef(o), b = d.useRef(r), x = d.useRef(n), w = en(e, "trapezoid-");
  if (d.useEffect(() => {
    if (v.current && v.current.getTotalLength)
      try {
        var N = v.current.getTotalLength();
        N && h(N);
      } catch {
      }
  }, []), r !== +r || n !== +n || i !== +i || a !== +a || o !== +o || i === 0 && a === 0 || o === 0)
    return null;
  var P = Y("recharts-trapezoid", l);
  if (!f)
    return /* @__PURE__ */ d.createElement("g", null, /* @__PURE__ */ d.createElement("path", ff({}, Ie(t), {
      className: P,
      d: IP(r, n, i, a, o)
    })));
  var O = y.current, S = g.current, E = m.current, k = b.current, _ = x.current, I = "0px ".concat(p === -1 ? 1 : p, "px"), j = "".concat(p, "px 0px"), z = _y(["strokeDasharray"], s, u);
  return /* @__PURE__ */ d.createElement(Jr, {
    animationId: w,
    key: w,
    canBegin: p > 0,
    duration: s,
    easing: u,
    isActive: f,
    begin: c
  }, (N) => {
    var R = X(O, i, N), V = X(S, a, N), H = X(E, o, N), C = X(k, r, N), D = X(_, n, N);
    v.current && (y.current = R, g.current = V, m.current = H, b.current = C, x.current = D);
    var F = N > 0 ? {
      transition: z,
      strokeDasharray: j
    } : {
      strokeDasharray: I
    };
    return /* @__PURE__ */ d.createElement("path", ff({}, Ie(t), {
      className: P,
      d: IP(C, D, R, V, H),
      ref: v,
      style: _P(_P({}, F), t.style)
    }));
  });
}, e6 = ["option", "shapeType", "activeClassName"];
function t6(e, t) {
  if (e == null) return {};
  var r, n, i = r6(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function r6(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function jP(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function df(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? jP(Object(r), !0).forEach(function(n) {
      n6(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : jP(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function n6(e, t, r) {
  return (t = i6(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function i6(e) {
  var t = a6(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function a6(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function o6(e, t) {
  return df(df({}, t), e);
}
function l6(e, t) {
  return e === "symbols";
}
function CP(e) {
  var {
    shapeType: t,
    elementProps: r
  } = e;
  switch (t) {
    case "rectangle":
      return /* @__PURE__ */ d.createElement(Pu, r);
    case "trapezoid":
      return /* @__PURE__ */ d.createElement(J5, r);
    case "sector":
      return /* @__PURE__ */ d.createElement(ik, r);
    case "symbols":
      if (l6(t))
        return /* @__PURE__ */ d.createElement(Yf, r);
      break;
    case "curve":
      return /* @__PURE__ */ d.createElement(Ri, r);
    default:
      return null;
  }
}
function u6(e) {
  return /* @__PURE__ */ d.isValidElement(e) ? e.props : e;
}
function Ji(e) {
  var {
    option: t,
    shapeType: r,
    activeClassName: n = "recharts-active-shape"
  } = e, i = t6(e, e6), a;
  if (/* @__PURE__ */ d.isValidElement(t))
    a = /* @__PURE__ */ d.cloneElement(t, df(df({}, i), u6(t)));
  else if (typeof t == "function")
    a = t(i, i.index);
  else if (Y5(t) && typeof t != "boolean") {
    var o = o6(t, i);
    a = /* @__PURE__ */ d.createElement(CP, {
      shapeType: r,
      elementProps: o
    });
  } else {
    var l = i;
    a = /* @__PURE__ */ d.createElement(CP, {
      shapeType: r,
      elementProps: l
    });
  }
  return i.isActive ? /* @__PURE__ */ d.createElement(U, {
    className: n
  }, a) : a;
}
var jo = (e, t, r) => {
  var n = J();
  return (i, a) => (o) => {
    e == null || e(i, a, o), n(So({
      activeIndex: String(a),
      activeDataKey: t,
      activeCoordinate: i.tooltipPosition,
      activeGraphicalItemId: r
    }));
  };
}, Co = (e) => {
  var t = J();
  return (r, n) => (i) => {
    e == null || e(r, n, i), t(_g());
  };
}, To = (e, t, r) => {
  var n = J();
  return (i, a) => (o) => {
    e == null || e(i, a, o), n(Md({
      activeIndex: String(a),
      activeDataKey: t,
      activeCoordinate: i.tooltipPosition,
      activeGraphicalItemId: r
    }));
  };
};
function an(e) {
  var {
    tooltipEntrySettings: t
  } = e, r = J(), n = me(), i = d.useRef(null);
  return d.useLayoutEffect(() => {
    n || (i.current === null ? r(cF(t)) : i.current !== t && r(fF({
      prev: i.current,
      next: t
    })), i.current = t);
  }, [t, r, n]), d.useLayoutEffect(() => () => {
    i.current && (r(dF(i.current)), i.current = null);
  }, [r]), null;
}
function Kd(e) {
  var {
    legendPayload: t
  } = e, r = J(), n = me(), i = d.useRef(null);
  return d.useLayoutEffect(() => {
    n || (i.current === null ? r(HA(t)) : i.current !== t && r(XA({
      prev: i.current,
      next: t
    })), i.current = t);
  }, [r, n, t]), d.useLayoutEffect(() => () => {
    i.current && (r(YA(i.current)), i.current = null);
  }, [r]), null;
}
function Xg(e) {
  var {
    legendPayload: t
  } = e, r = J(), n = T(q), i = d.useRef(null);
  return d.useLayoutEffect(() => {
    n !== "centric" && n !== "radial" || (i.current === null ? r(HA(t)) : i.current !== t && r(XA({
      prev: i.current,
      next: t
    })), i.current = t);
  }, [r, n, t]), d.useLayoutEffect(() => () => {
    i.current && (r(YA(i.current)), i.current = null);
  }, [r]), null;
}
var Vv, s6 = () => {
  var [e] = d.useState(() => Ya("uid-"));
  return e;
}, c6 = (Vv = DC.useId) !== null && Vv !== void 0 ? Vv : s6;
function f6(e, t) {
  var r = c6();
  return t || (e ? "".concat(e, "-").concat(r) : r);
}
var XI = /* @__PURE__ */ d.createContext(void 0), on = (e) => {
  var {
    id: t,
    type: r,
    children: n
  } = e, i = f6("recharts-".concat(r), t);
  return /* @__PURE__ */ d.createElement(XI.Provider, {
    value: i
  }, n(i));
};
function d6() {
  return d.useContext(XI);
}
var v6 = {
  cartesianItems: [],
  polarItems: []
}, YI = Ut({
  name: "graphicalItems",
  initialState: v6,
  reducers: {
    addCartesianGraphicalItem: {
      reducer(e, t) {
        e.cartesianItems.push(t.payload);
      },
      prepare: ke()
    },
    replaceCartesianGraphicalItem: {
      reducer(e, t) {
        var {
          prev: r,
          next: n
        } = t.payload, i = Cr(e).cartesianItems.indexOf(r);
        i > -1 && (e.cartesianItems[i] = n);
      },
      prepare: ke()
    },
    removeCartesianGraphicalItem: {
      reducer(e, t) {
        var r = Cr(e).cartesianItems.indexOf(t.payload);
        r > -1 && e.cartesianItems.splice(r, 1);
      },
      prepare: ke()
    },
    addPolarGraphicalItem: {
      reducer(e, t) {
        e.polarItems.push(t.payload);
      },
      prepare: ke()
    },
    removePolarGraphicalItem: {
      reducer(e, t) {
        var r = Cr(e).polarItems.indexOf(t.payload);
        r > -1 && e.polarItems.splice(r, 1);
      },
      prepare: ke()
    }
  }
}), {
  addCartesianGraphicalItem: p6,
  replaceCartesianGraphicalItem: h6,
  removeCartesianGraphicalItem: m6,
  addPolarGraphicalItem: y6,
  removePolarGraphicalItem: g6
} = YI.actions, b6 = YI.reducer, x6 = (e) => {
  var t = J(), r = d.useRef(null);
  return d.useLayoutEffect(() => {
    r.current === null ? t(p6(e)) : r.current !== e && t(h6({
      prev: r.current,
      next: e
    })), r.current = e;
  }, [t, e]), d.useLayoutEffect(() => () => {
    r.current && (t(m6(r.current)), r.current = null);
  }, [t]), null;
}, Wd = /* @__PURE__ */ d.memo(x6);
function Yg(e) {
  var t = J();
  return d.useLayoutEffect(() => (t(y6(e)), () => {
    t(g6(e));
  }), [t, e]), null;
}
var w6 = ["key"], P6 = ["onMouseEnter", "onClick", "onMouseLeave"], O6 = ["id"], S6 = ["id"];
function TP(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Le(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? TP(Object(r), !0).forEach(function(n) {
      E6(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : TP(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function E6(e, t, r) {
  return (t = A6(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function A6(e) {
  var t = k6(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function k6(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function fi() {
  return fi = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, fi.apply(null, arguments);
}
function Ud(e, t) {
  if (e == null) return {};
  var r, n, i = _6(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function _6(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function I6(e) {
  var t = d.useMemo(() => Io(e.children, sa), [e.children]), r = T((n) => D5(n, e.id, t));
  return r == null ? null : /* @__PURE__ */ d.createElement(Xg, {
    legendPayload: r
  });
}
var j6 = /* @__PURE__ */ d.memo((e) => {
  var {
    dataKey: t,
    nameKey: r,
    sectors: n,
    stroke: i,
    strokeWidth: a,
    fill: o,
    name: l,
    hide: u,
    tooltipType: s,
    id: c
  } = e, f = {
    dataDefinedOnItem: n.map((v) => v.tooltipPayload),
    positions: n.map((v) => v.tooltipPosition),
    settings: {
      stroke: i,
      strokeWidth: a,
      fill: o,
      dataKey: t,
      nameKey: r,
      name: ir(l, t),
      hide: u,
      type: s,
      color: o,
      unit: "",
      // why doesn't Pie support unit?
      graphicalItemId: c
    }
  };
  return /* @__PURE__ */ d.createElement(an, {
    tooltipEntrySettings: f
  });
}), C6 = (e, t) => e > t ? "start" : e < t ? "end" : "middle", T6 = (e, t, r) => dt(typeof t == "function" ? t(e) : t, r, r * 0.8), M6 = (e, t, r) => {
  var {
    top: n,
    left: i,
    width: a,
    height: o
  } = t, l = ek(a, o), u = i + dt(e.cx, a, a / 2), s = n + dt(e.cy, o, o / 2), c = dt(e.innerRadius, l, 0), f = T6(r, e.outerRadius, l), v = e.maxRadius || Math.sqrt(a * a + o * o) / 2;
  return {
    cx: u,
    cy: s,
    innerRadius: c,
    outerRadius: f,
    maxRadius: v
  };
}, D6 = (e, t) => {
  var r = We(t - e), n = Math.min(Math.abs(t - e), 360);
  return r * n;
};
function N6(e) {
  return e && typeof e == "object" && "className" in e && typeof e.className == "string" ? e.className : "";
}
var $6 = (e, t) => {
  if (/* @__PURE__ */ d.isValidElement(e))
    return /* @__PURE__ */ d.cloneElement(e, t);
  if (typeof e == "function")
    return e(t);
  var r = Y("recharts-pie-label-line", typeof e != "boolean" ? e.className : ""), {
    key: n
  } = t, i = Ud(t, w6);
  return /* @__PURE__ */ d.createElement(Ri, fi({}, i, {
    type: "linear",
    className: r
  }));
}, L6 = (e, t, r) => {
  if (/* @__PURE__ */ d.isValidElement(e))
    return /* @__PURE__ */ d.cloneElement(e, t);
  var n = r;
  if (typeof e == "function" && (n = e(t), /* @__PURE__ */ d.isValidElement(n)))
    return n;
  var i = Y("recharts-pie-label-text", N6(e));
  return /* @__PURE__ */ d.createElement(ci, fi({}, t, {
    alignmentBaseline: "middle",
    className: i
  }), n);
};
function R6(e) {
  var {
    sectors: t,
    props: r,
    showLabels: n
  } = e, {
    label: i,
    labelLine: a,
    dataKey: o
  } = r;
  if (!n || !i || !t)
    return null;
  var l = re(r), u = er(i), s = er(a), c = typeof i == "object" && "offsetRadius" in i && typeof i.offsetRadius == "number" && i.offsetRadius || 20, f = t.map((v, p) => {
    var h = (v.startAngle + v.endAngle) / 2, y = ce(v.cx, v.cy, v.outerRadius + c, h), g = Le(Le(Le(Le({}, l), v), {}, {
      // @ts-expect-error customLabelProps is contributing unknown props
      stroke: "none"
    }, u), {}, {
      index: p,
      textAnchor: C6(y.x, v.cx)
    }, y), m = Le(Le(Le(Le({}, l), v), {}, {
      // @ts-expect-error customLabelLineProps is contributing unknown props
      fill: "none",
      // @ts-expect-error customLabelLineProps is contributing unknown props
      stroke: v.fill
    }, s), {}, {
      index: p,
      points: [ce(v.cx, v.cy, v.outerRadius, h), y],
      key: "line"
    });
    return /* @__PURE__ */ d.createElement(pe, {
      zIndex: ie.label,
      key: "label-".concat(v.startAngle, "-").concat(v.endAngle, "-").concat(v.midAngle, "-").concat(p)
    }, /* @__PURE__ */ d.createElement(U, null, a && $6(a, m), L6(i, g, G(v, o))));
  });
  return /* @__PURE__ */ d.createElement(U, {
    className: "recharts-pie-labels"
  }, f);
}
function z6(e) {
  var {
    sectors: t,
    props: r,
    showLabels: n
  } = e, {
    label: i
  } = r;
  return typeof i == "object" && i != null && "position" in i ? /* @__PURE__ */ d.createElement(bi, {
    label: i
  }) : /* @__PURE__ */ d.createElement(R6, {
    sectors: t,
    props: r,
    showLabels: n
  });
}
function B6(e) {
  var {
    sectors: t,
    activeShape: r,
    inactiveShape: n,
    allOtherPieProps: i,
    shape: a,
    id: o
  } = e, l = T(Qr), u = T(Dg), s = T(QF), {
    onMouseEnter: c,
    onClick: f,
    onMouseLeave: v
  } = i, p = Ud(i, P6), h = jo(c, i.dataKey, o), y = Co(v), g = To(f, i.dataKey, o);
  return t == null || t.length === 0 ? null : /* @__PURE__ */ d.createElement(d.Fragment, null, t.map((m, b) => {
    if ((m == null ? void 0 : m.startAngle) === 0 && (m == null ? void 0 : m.endAngle) === 0 && t.length !== 1) return null;
    var x = s == null || s === o, w = String(b) === l && (u == null || i.dataKey === u) && x, P = l ? n : null, O = r && w ? r : P, S = Le(Le({}, m), {}, {
      stroke: m.stroke,
      tabIndex: -1,
      [Py]: b,
      [Oy]: o
    });
    return /* @__PURE__ */ d.createElement(U, fi({
      key: "sector-".concat(m == null ? void 0 : m.startAngle, "-").concat(m == null ? void 0 : m.endAngle, "-").concat(m.midAngle, "-").concat(b),
      tabIndex: -1,
      className: "recharts-pie-sector"
    }, Nr(p, m, b), {
      // @ts-expect-error the types need a bit of attention
      onMouseEnter: h(m, b),
      onMouseLeave: y(m, b),
      onClick: g(m, b)
    }), /* @__PURE__ */ d.createElement(Ji, fi({
      option: a ?? O,
      index: b,
      shapeType: "sector",
      isActive: w
    }, S)));
  }));
}
function F6(e) {
  var t, {
    pieSettings: r,
    displayedData: n,
    cells: i,
    offset: a
  } = e, {
    cornerRadius: o,
    startAngle: l,
    endAngle: u,
    dataKey: s,
    nameKey: c,
    tooltipType: f
  } = r, v = Math.abs(r.minAngle), p = D6(l, u), h = Math.abs(p), y = n.length <= 1 ? 0 : (t = r.paddingAngle) !== null && t !== void 0 ? t : 0, g = n.filter((O) => G(O, s, 0) !== 0).length, m = (h >= 360 ? g : g - 1) * y, b = h - g * v - m, x = n.reduce((O, S) => {
    var E = G(S, s, 0);
    return O + (B(E) ? E : 0);
  }, 0), w;
  if (x > 0) {
    var P;
    w = n.map((O, S) => {
      var E = G(O, s, 0), k = G(O, c, S), _ = M6(r, a, O), I = (B(E) ? E : 0) / x, j, z = Le(Le({}, O), i && i[S] && i[S].props);
      S ? j = P.endAngle + We(p) * y * (E !== 0 ? 1 : 0) : j = l;
      var N = j + We(p) * ((E !== 0 ? v : 0) + I * b), R = (j + N) / 2, V = (_.innerRadius + _.outerRadius) / 2, H = [{
        name: k,
        value: E,
        payload: z,
        dataKey: s,
        type: f,
        graphicalItemId: r.id
      }], C = ce(_.cx, _.cy, V, R);
      return P = Le(Le(Le(Le({}, r.presentationProps), {}, {
        percent: I,
        cornerRadius: typeof o == "string" ? parseFloat(o) : o,
        name: k,
        tooltipPayload: H,
        midAngle: R,
        middleRadius: V,
        tooltipPosition: C
      }, z), _), {}, {
        value: E,
        dataKey: s,
        startAngle: j,
        endAngle: N,
        payload: z,
        paddingAngle: We(p) * y
      }), P;
    });
  }
  return w;
}
function K6(e) {
  var {
    showLabels: t,
    sectors: r,
    children: n
  } = e, i = d.useMemo(() => !t || !r ? [] : r.map((a) => ({
    value: a.value,
    payload: a.payload,
    clockWise: !1,
    parentViewBox: void 0,
    viewBox: {
      cx: a.cx,
      cy: a.cy,
      innerRadius: a.innerRadius,
      outerRadius: a.outerRadius,
      startAngle: a.startAngle,
      endAngle: a.endAngle,
      clockWise: !1
    },
    fill: a.fill
  })), [r, t]);
  return /* @__PURE__ */ d.createElement(kI, {
    value: t ? i : void 0
  }, n);
}
function W6(e) {
  var {
    props: t,
    previousSectorsRef: r,
    id: n
  } = e, {
    sectors: i,
    isAnimationActive: a,
    animationBegin: o,
    animationDuration: l,
    animationEasing: u,
    activeShape: s,
    inactiveShape: c,
    onAnimationStart: f,
    onAnimationEnd: v
  } = t, p = en(t, "recharts-pie-"), h = r.current, [y, g] = d.useState(!1), m = d.useCallback(() => {
    typeof v == "function" && v(), g(!1);
  }, [v]), b = d.useCallback(() => {
    typeof f == "function" && f(), g(!0);
  }, [f]);
  return /* @__PURE__ */ d.createElement(K6, {
    showLabels: !y,
    sectors: i
  }, /* @__PURE__ */ d.createElement(Jr, {
    animationId: p,
    begin: o,
    duration: l,
    isActive: a,
    easing: u,
    onAnimationStart: b,
    onAnimationEnd: m,
    key: p
  }, (x) => {
    var w = [], P = i && i[0], O = P == null ? void 0 : P.startAngle;
    return i == null || i.forEach((S, E) => {
      var k = h && h[E], _ = E > 0 ? Gr(S, "paddingAngle", 0) : 0;
      if (k) {
        var I = X(k.endAngle - k.startAngle, S.endAngle - S.startAngle, x), j = Le(Le({}, S), {}, {
          startAngle: O + _,
          endAngle: O + I + _
        });
        w.push(j), O = j.endAngle;
      } else {
        var {
          endAngle: z,
          startAngle: N
        } = S, R = X(0, z - N, x), V = Le(Le({}, S), {}, {
          startAngle: O + _,
          endAngle: O + R + _
        });
        w.push(V), O = V.endAngle;
      }
    }), r.current = w, /* @__PURE__ */ d.createElement(U, null, /* @__PURE__ */ d.createElement(B6, {
      sectors: w,
      activeShape: s,
      inactiveShape: c,
      allOtherPieProps: t,
      shape: t.shape,
      id: n
    }));
  }), /* @__PURE__ */ d.createElement(z6, {
    showLabels: !y,
    sectors: i,
    props: t
  }), t.children);
}
var U6 = {
  animationBegin: 400,
  animationDuration: 1500,
  animationEasing: "ease",
  cx: "50%",
  cy: "50%",
  dataKey: "value",
  endAngle: 360,
  fill: "#808080",
  hide: !1,
  innerRadius: 0,
  isAnimationActive: "auto",
  label: !1,
  labelLine: !0,
  legendType: "rect",
  minAngle: 0,
  nameKey: "name",
  outerRadius: "80%",
  paddingAngle: 0,
  rootTabIndex: 0,
  startAngle: 0,
  stroke: "#fff",
  zIndex: ie.area
};
function V6(e) {
  var {
    id: t
  } = e, r = Ud(e, O6), {
    hide: n,
    className: i,
    rootTabIndex: a
  } = e, o = d.useMemo(() => Io(e.children, sa), [e.children]), l = T((c) => N5(c, t, o)), u = d.useRef(null), s = Y("recharts-pie", i);
  return n || l == null ? (u.current = null, /* @__PURE__ */ d.createElement(U, {
    tabIndex: a,
    className: s
  })) : /* @__PURE__ */ d.createElement(pe, {
    zIndex: e.zIndex
  }, /* @__PURE__ */ d.createElement(j6, {
    dataKey: e.dataKey,
    nameKey: e.nameKey,
    sectors: l,
    stroke: e.stroke,
    strokeWidth: e.strokeWidth,
    fill: e.fill,
    name: e.name,
    hide: e.hide,
    tooltipType: e.tooltipType,
    id: t
  }), /* @__PURE__ */ d.createElement(U, {
    tabIndex: a,
    className: s
  }, /* @__PURE__ */ d.createElement(W6, {
    props: Le(Le({}, r), {}, {
      sectors: l
    }),
    previousSectorsRef: u,
    id: t
  })));
}
function H6(e) {
  var t = ee(e, U6), {
    id: r
  } = t, n = Ud(t, S6), i = re(n);
  return /* @__PURE__ */ d.createElement(on, {
    id: r,
    type: "pie"
  }, (a) => /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(Yg, {
    type: "pie",
    id: a,
    data: n.data,
    dataKey: n.dataKey,
    hide: n.hide,
    angleAxisId: 0,
    radiusAxisId: 0,
    name: n.name,
    nameKey: n.nameKey,
    tooltipType: n.tooltipType,
    legendType: n.legendType,
    fill: n.fill,
    cx: n.cx,
    cy: n.cy,
    startAngle: n.startAngle,
    endAngle: n.endAngle,
    paddingAngle: n.paddingAngle,
    minAngle: n.minAngle,
    innerRadius: n.innerRadius,
    outerRadius: n.outerRadius,
    cornerRadius: n.cornerRadius,
    presentationProps: i,
    maxRadius: t.maxRadius
  }), /* @__PURE__ */ d.createElement(I6, fi({}, n, {
    id: a
  })), /* @__PURE__ */ d.createElement(V6, fi({}, n, {
    id: a
  }))));
}
H6.displayName = "Pie";
var X6 = ["points"];
function MP(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Hv(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? MP(Object(r), !0).forEach(function(n) {
      Y6(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : MP(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function Y6(e, t, r) {
  return (t = G6(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function G6(e) {
  var t = q6(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function q6(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function vf() {
  return vf = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, vf.apply(null, arguments);
}
function Z6(e, t) {
  if (e == null) return {};
  var r, n, i = Q6(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function Q6(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function J6(e) {
  var {
    option: t,
    dotProps: r,
    className: n
  } = e;
  if (/* @__PURE__ */ d.isValidElement(t))
    return /* @__PURE__ */ d.cloneElement(t, r);
  if (typeof t == "function")
    return t(r);
  var i = Y(n, typeof t != "boolean" ? t.className : ""), a = r ?? {}, {
    points: o
  } = a, l = Z6(a, X6);
  return /* @__PURE__ */ d.createElement(Rd, vf({}, l, {
    className: i
  }));
}
function e8(e, t) {
  return e == null ? !1 : t ? !0 : e.length === 1;
}
function Gg(e) {
  var {
    points: t,
    dot: r,
    className: n,
    dotClassName: i,
    dataKey: a,
    baseProps: o,
    needClip: l,
    clipPathId: u,
    zIndex: s = ie.scatter
  } = e;
  if (!e8(t, r))
    return null;
  var c = Vg(r), f = KM(r), v = t.map((h, y) => {
    var g, m, b = Hv(Hv(Hv({
      r: 3
    }, o), f), {}, {
      index: y,
      cx: (g = h.x) !== null && g !== void 0 ? g : void 0,
      cy: (m = h.y) !== null && m !== void 0 ? m : void 0,
      dataKey: a,
      value: h.value,
      payload: h.payload,
      points: t
    });
    return /* @__PURE__ */ d.createElement(J6, {
      key: "dot-".concat(y),
      option: r,
      dotProps: b,
      className: i
    });
  }), p = {};
  return l && u != null && (p.clipPath = "url(#clipPath-".concat(c ? "" : "dots-").concat(u, ")")), /* @__PURE__ */ d.createElement(pe, {
    zIndex: s
  }, /* @__PURE__ */ d.createElement(U, vf({
    className: n
  }, p), v));
}
function DP(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function NP(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? DP(Object(r), !0).forEach(function(n) {
      t8(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : DP(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function t8(e, t, r) {
  return (t = r8(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function r8(e) {
  var t = n8(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function n8(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var GI = 0, i8 = {
  xAxis: {},
  yAxis: {},
  zAxis: {}
}, qI = Ut({
  name: "cartesianAxis",
  initialState: i8,
  reducers: {
    addXAxis: {
      reducer(e, t) {
        e.xAxis[t.payload.id] = t.payload;
      },
      prepare: ke()
    },
    replaceXAxis: {
      reducer(e, t) {
        var {
          prev: r,
          next: n
        } = t.payload;
        e.xAxis[r.id] !== void 0 && (r.id !== n.id && delete e.xAxis[r.id], e.xAxis[n.id] = n);
      },
      prepare: ke()
    },
    removeXAxis: {
      reducer(e, t) {
        delete e.xAxis[t.payload.id];
      },
      prepare: ke()
    },
    addYAxis: {
      reducer(e, t) {
        e.yAxis[t.payload.id] = t.payload;
      },
      prepare: ke()
    },
    replaceYAxis: {
      reducer(e, t) {
        var {
          prev: r,
          next: n
        } = t.payload;
        e.yAxis[r.id] !== void 0 && (r.id !== n.id && delete e.yAxis[r.id], e.yAxis[n.id] = n);
      },
      prepare: ke()
    },
    removeYAxis: {
      reducer(e, t) {
        delete e.yAxis[t.payload.id];
      },
      prepare: ke()
    },
    addZAxis: {
      reducer(e, t) {
        e.zAxis[t.payload.id] = t.payload;
      },
      prepare: ke()
    },
    replaceZAxis: {
      reducer(e, t) {
        var {
          prev: r,
          next: n
        } = t.payload;
        e.zAxis[r.id] !== void 0 && (r.id !== n.id && delete e.zAxis[r.id], e.zAxis[n.id] = n);
      },
      prepare: ke()
    },
    removeZAxis: {
      reducer(e, t) {
        delete e.zAxis[t.payload.id];
      },
      prepare: ke()
    },
    updateYAxisWidth(e, t) {
      var {
        id: r,
        width: n
      } = t.payload, i = e.yAxis[r];
      if (i) {
        var a = i.widthHistory || [];
        if (a.length === 3 && a[0] === a[2] && n === a[1] && n !== i.width && Math.abs(n - a[0]) <= 1)
          return;
        var o = [...a, n].slice(-3);
        e.yAxis[r] = NP(NP({}, e.yAxis[r]), {}, {
          width: n,
          widthHistory: o
        });
      }
    }
  }
}), {
  addXAxis: a8,
  replaceXAxis: o8,
  removeXAxis: l8,
  addYAxis: u8,
  replaceYAxis: s8,
  removeYAxis: c8,
  addZAxis: f8,
  replaceZAxis: d8,
  removeZAxis: v8,
  updateYAxisWidth: p8
} = qI.actions, h8 = qI.reducer, m8 = A([Ve], (e) => ({
  top: e.top,
  bottom: e.bottom,
  left: e.left,
  right: e.right
})), y8 = A([m8, Nn, $n], (e, t, r) => {
  if (!(!e || t == null || r == null))
    return {
      x: e.left,
      y: e.top,
      width: Math.max(0, t - e.left - e.right),
      height: Math.max(0, r - e.top - e.bottom)
    };
}), g8 = (e) => {
  var t = me();
  return T((r) => Kt(r, "xAxis", e, t));
}, b8 = (e) => {
  var t = me();
  return T((r) => Kt(r, "yAxis", e, t));
}, Xu = () => T(y8), x8 = () => T(nK);
function $P(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Xv(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? $P(Object(r), !0).forEach(function(n) {
      w8(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : $P(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function w8(e, t, r) {
  return (t = P8(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function P8(e) {
  var t = O8(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function O8(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var S8 = (e) => {
  var {
    point: t,
    childIndex: r,
    mainColor: n,
    activeDot: i,
    dataKey: a,
    clipPath: o
  } = e;
  if (i === !1 || t.x == null || t.y == null)
    return null;
  var l = {
    index: r,
    dataKey: a,
    cx: t.x,
    cy: t.y,
    r: 4,
    fill: n ?? "none",
    strokeWidth: 2,
    stroke: "#fff",
    payload: t.payload,
    value: t.value
  }, u = Xv(Xv(Xv({}, l), er(i)), ty(i)), s;
  return /* @__PURE__ */ d.isValidElement(i) ? s = /* @__PURE__ */ d.cloneElement(i, u) : typeof i == "function" ? s = i(u) : s = /* @__PURE__ */ d.createElement(Rd, u), /* @__PURE__ */ d.createElement(U, {
    className: "recharts-active-dot",
    clipPath: o
  }, s);
};
function pf(e) {
  var {
    points: t,
    mainColor: r,
    activeDot: n,
    itemDataKey: i,
    clipPath: a,
    zIndex: o = ie.activeDot
  } = e, l = T(Qr), u = x8();
  if (t == null || u == null)
    return null;
  var s = t.find((c) => u.includes(c.payload));
  return oe(s) ? null : /* @__PURE__ */ d.createElement(pe, {
    zIndex: o
  }, /* @__PURE__ */ d.createElement(S8, {
    point: s,
    childIndex: Number(l),
    mainColor: r,
    dataKey: i,
    activeDot: n,
    clipPath: a
  }));
}
function LP(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function hf(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? LP(Object(r), !0).forEach(function(n) {
      E8(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : LP(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function E8(e, t, r) {
  return (t = A8(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function A8(e) {
  var t = k8(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function k8(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var ZI = (e, t) => xi(e, "radiusAxis", t), _8 = A([ZI], (e) => {
  if (e != null)
    return {
      scale: e
    };
}), I8 = A([bo, ZI], (e, t) => {
  if (!(e == null || t == null))
    return hf(hf({}, e), {}, {
      scale: t
    });
}), j8 = (e, t, r, n) => ca(e, "radiusAxis", t, n), QI = (e, t, r) => la(e, r), JI = (e, t, r) => xi(e, "angleAxis", r), C8 = A([QI, JI], (e, t) => {
  if (!(e == null || t == null))
    return hf(hf({}, e), {}, {
      scale: t
    });
}), T8 = (e, t, r, n) => ca(e, "angleAxis", r, n), M8 = A([QI, JI, ua], (e, t, r) => {
  if (!(r == null || t == null))
    return {
      scale: t,
      type: e.type,
      dataKey: e.dataKey,
      cx: r.cx,
      cy: r.cy
    };
}), D8 = (e, t, r, n, i) => i, N8 = A([q, I8, j8, C8, T8], (e, t, r, n, i) => br(e, "radiusAxis") ? Ft(t, r, !1) : Ft(n, i, !1)), $8 = A([$u, D8], (e, t) => {
  if (e != null) {
    var r = e.find((n) => n.type === "radar" && t === n.id);
    return r == null ? void 0 : r.dataKey;
  }
}), L8 = A([_8, M8, yi, $8, N8], (e, t, r, n, i) => {
  var {
    chartData: a,
    dataStartIndex: o,
    dataEndIndex: l
  } = r;
  if (!(e == null || t == null || a == null || i == null || n == null)) {
    var u = a.slice(o, l + 1);
    return X8({
      radiusAxis: e,
      angleAxis: t,
      displayedData: u,
      dataKey: n,
      bandSize: i
    });
  }
}), R8 = ["id"];
function Yl() {
  return Yl = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Yl.apply(null, arguments);
}
function RP(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Nt(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? RP(Object(r), !0).forEach(function(n) {
      z8(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : RP(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function z8(e, t, r) {
  return (t = B8(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function B8(e) {
  var t = F8(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function F8(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function K8(e, t) {
  if (e == null) return {};
  var r, n, i = W8(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function W8(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function qg(e, t) {
  return e && e !== "none" ? e : t;
}
var U8 = (e) => {
  var {
    dataKey: t,
    name: r,
    stroke: n,
    fill: i,
    legendType: a,
    hide: o
  } = e;
  return [{
    inactive: o,
    dataKey: t,
    type: a,
    color: qg(n, i),
    value: ir(r, t),
    payload: e
  }];
}, V8 = /* @__PURE__ */ d.memo((e) => {
  var {
    dataKey: t,
    stroke: r,
    strokeWidth: n,
    fill: i,
    name: a,
    hide: o,
    tooltipType: l,
    id: u
  } = e, s = {
    /*
     * I suppose this here _could_ return props.points
     * because while Radar does not support item tooltip mode, it _could_ support it.
     * But when I actually do return the points here, a defaultIndex test starts failing.
     * So, undefined it is.
     */
    dataDefinedOnItem: void 0,
    positions: void 0,
    settings: {
      stroke: r,
      strokeWidth: n,
      fill: i,
      nameKey: void 0,
      // RadarChart does not have nameKey unfortunately
      dataKey: t,
      name: ir(a, t),
      hide: o,
      type: l,
      color: qg(r, i),
      unit: "",
      // why doesn't Radar support unit?
      graphicalItemId: u
    }
  };
  return /* @__PURE__ */ d.createElement(an, {
    tooltipEntrySettings: s
  });
});
function H8(e) {
  var {
    points: t,
    props: r
  } = e, {
    dot: n,
    dataKey: i
  } = r, {
    id: a
  } = r, o = K8(r, R8), l = re(o);
  return /* @__PURE__ */ d.createElement(Gg, {
    points: t,
    dot: n,
    className: "recharts-radar-dots",
    dotClassName: "recharts-radar-dot",
    dataKey: i,
    baseProps: l
  });
}
function X8(e) {
  var {
    radiusAxis: t,
    angleAxis: r,
    displayedData: n,
    dataKey: i,
    bandSize: a
  } = e, {
    cx: o,
    cy: l
  } = r, u = !1, s = [], c = r.type !== "number" ? a ?? 0 : 0;
  n.forEach((v, p) => {
    var h = G(v, r.dataKey, p), y = G(v, i), g = r.scale(h) + c, m = Array.isArray(y) ? SI(y) : y, b = oe(m) ? 0 : t.scale(m);
    Array.isArray(y) && y.length >= 2 && (u = !0), s.push(Nt(Nt({}, ce(o, l, b, g)), {}, {
      // @ts-expect-error getValueByDataKey does not validate the output type
      name: h,
      // @ts-expect-error getValueByDataKey does not validate the output type
      value: y,
      cx: o,
      cy: l,
      radius: b,
      angle: g,
      payload: v
    }));
  });
  var f = [];
  return u && s.forEach((v) => {
    if (Array.isArray(v.value)) {
      var p = v.value[0], h = oe(p) ? 0 : t.scale(p);
      f.push(Nt(Nt({}, v), {}, {
        radius: h
      }, ce(o, l, h, v.angle)));
    } else
      f.push(v);
  }), {
    points: s,
    isRange: u,
    baseLinePoints: f
  };
}
function Y8(e) {
  var {
    showLabels: t,
    points: r,
    children: n
  } = e, i = r.map((a) => {
    var o, l = {
      x: a.x,
      y: a.y,
      width: 0,
      lowerWidth: 0,
      upperWidth: 0,
      height: 0
    };
    return Nt(Nt({}, l), {}, {
      value: (o = a.value) !== null && o !== void 0 ? o : "",
      payload: a.payload,
      parentViewBox: void 0,
      viewBox: l,
      fill: void 0
    });
  });
  return /* @__PURE__ */ d.createElement(_o, {
    value: t ? i : void 0
  }, n);
}
function G8(e) {
  var {
    points: t,
    baseLinePoints: r,
    props: n
  } = e;
  if (t == null)
    return null;
  var {
    shape: i,
    isRange: a,
    connectNulls: o
  } = n, l = (c) => {
    var {
      onMouseEnter: f
    } = n;
    f && f(n, c);
  }, u = (c) => {
    var {
      onMouseLeave: f
    } = n;
    f && f(n, c);
  }, s;
  return /* @__PURE__ */ d.isValidElement(i) ? s = /* @__PURE__ */ d.cloneElement(i, Nt(Nt({}, n), {}, {
    points: t
  })) : typeof i == "function" ? s = i(Nt(Nt({}, n), {}, {
    points: t
  })) : s = /* @__PURE__ */ d.createElement(zg, Yl({}, Ie(n), {
    onMouseEnter: l,
    onMouseLeave: u,
    points: t,
    baseLinePoints: a ? r : void 0,
    connectNulls: o
  })), /* @__PURE__ */ d.createElement(U, {
    className: "recharts-radar-polygon"
  }, s, /* @__PURE__ */ d.createElement(H8, {
    props: n,
    points: t
  }));
}
var zP = (e, t, r) => (n, i) => {
  var a = e && e[Math.floor(i * t)];
  return a ? Nt(Nt({}, n), {}, {
    x: X(a.x, n.x, r),
    y: X(a.y, n.y, r)
  }) : Nt(Nt({}, n), {}, {
    x: X(n.cx, n.x, r),
    y: X(n.cy, n.y, r)
  });
};
function q8(e) {
  var {
    props: t,
    previousPointsRef: r,
    previousBaseLinePointsRef: n
  } = e, {
    points: i,
    baseLinePoints: a,
    isAnimationActive: o,
    animationBegin: l,
    animationDuration: u,
    animationEasing: s,
    onAnimationEnd: c,
    onAnimationStart: f
  } = t, v = r.current, p = n.current, h = v ? v.length / i.length : 1, y = p ? p.length / a.length : 1, g = en(t, "recharts-radar-"), [m, b] = d.useState(!1), x = !m, w = d.useCallback(() => {
    typeof c == "function" && c(), b(!1);
  }, [c]), P = d.useCallback(() => {
    typeof f == "function" && f(), b(!0);
  }, [f]);
  return /* @__PURE__ */ d.createElement(Y8, {
    showLabels: x,
    points: i
  }, /* @__PURE__ */ d.createElement(Jr, {
    animationId: g,
    begin: l,
    duration: u,
    isActive: o,
    easing: s,
    key: "radar-".concat(g),
    onAnimationEnd: w,
    onAnimationStart: P
  }, (O) => {
    var S = O === 1 ? i : i.map(zP(v, h, O)), E = O === 1 ? a : a == null ? void 0 : a.map(zP(p, y, O));
    return O > 0 && (r.current = S, n.current = E), /* @__PURE__ */ d.createElement(G8, {
      points: S,
      baseLinePoints: E,
      props: t
    });
  }), /* @__PURE__ */ d.createElement(bi, {
    label: t.label
  }), t.children);
}
function Z8(e) {
  var t = d.useRef(void 0), r = d.useRef(void 0);
  return /* @__PURE__ */ d.createElement(q8, {
    props: e,
    previousPointsRef: t,
    previousBaseLinePointsRef: r
  });
}
var Q8 = {
  activeDot: !0,
  angleAxisId: 0,
  animationBegin: 0,
  animationDuration: 1500,
  animationEasing: "ease",
  dot: !1,
  hide: !1,
  isAnimationActive: "auto",
  label: !1,
  legendType: "rect",
  radiusAxisId: 0,
  zIndex: ie.area
};
function J8(e) {
  var {
    hide: t,
    className: r,
    points: n
  } = e;
  if (t)
    return null;
  var i = Y("recharts-radar", r);
  return /* @__PURE__ */ d.createElement(pe, {
    zIndex: e.zIndex
  }, /* @__PURE__ */ d.createElement(U, {
    className: i
  }, /* @__PURE__ */ d.createElement(Z8, e)), /* @__PURE__ */ d.createElement(pf, {
    points: n,
    mainColor: qg(e.stroke, e.fill),
    itemDataKey: e.dataKey,
    activeDot: e.activeDot
  }));
}
function eU(e) {
  var t = me(), r = T((n) => L8(n, e.radiusAxisId, e.angleAxisId, t, e.id));
  return (r == null ? void 0 : r.points) == null ? null : /* @__PURE__ */ d.createElement(J8, Yl({}, e, {
    points: r == null ? void 0 : r.points,
    baseLinePoints: r == null ? void 0 : r.baseLinePoints,
    isRange: r == null ? void 0 : r.isRange
  }));
}
function tU(e) {
  var t = ee(e, Q8);
  return /* @__PURE__ */ d.createElement(on, {
    id: t.id,
    type: "radar"
  }, (r) => /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(Yg, {
    type: "radar",
    id: r,
    data: void 0,
    dataKey: t.dataKey,
    hide: t.hide,
    angleAxisId: t.angleAxisId,
    radiusAxisId: t.radiusAxisId
  }), /* @__PURE__ */ d.createElement(Xg, {
    legendPayload: U8(t)
  }), /* @__PURE__ */ d.createElement(V8, {
    dataKey: t.dataKey,
    stroke: t.stroke,
    strokeWidth: t.strokeWidth,
    fill: t.fill,
    name: t.name,
    hide: t.hide,
    tooltipType: t.tooltipType,
    id: r
  }), /* @__PURE__ */ d.createElement(eU, Yl({}, t, {
    id: r
  }))));
}
tU.displayName = "Radar";
function Fh() {
  return Fh = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Fh.apply(null, arguments);
}
function ej(e) {
  return typeof e == "string" ? parseInt(e, 10) : e;
}
function Kh(e) {
  return /* @__PURE__ */ d.createElement(Ji, Fh({
    shapeType: "sector"
  }, e));
}
var BP = (e, t, r) => {
  var n = r ?? e;
  if (!oe(n))
    return dt(n, t, 0);
}, tj = (e, t, r) => {
  var n = {}, i = e.filter(_u), a = e.filter((s) => s.stackId == null), o = i.reduce((s, c) => (s[c.stackId] || (s[c.stackId] = []), s[c.stackId].push(c), s), n), l = Object.entries(o).map((s) => {
    var [c, f] = s, v = f.map((h) => h.dataKey), p = BP(t, r, f[0].barSize);
    return {
      stackId: c,
      dataKeys: v,
      barSize: p
    };
  }), u = a.map((s) => {
    var c = [s.dataKey].filter((v) => v != null), f = BP(t, r, s.barSize);
    return {
      stackId: void 0,
      dataKeys: c,
      barSize: f
    };
  });
  return [...l, ...u];
};
function FP(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Is(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? FP(Object(r), !0).forEach(function(n) {
      rU(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : FP(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function rU(e, t, r) {
  return (t = nU(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function nU(e) {
  var t = iU(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function iU(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function aU(e, t, r, n, i) {
  var a = n.length;
  if (!(a < 1)) {
    var o = dt(e, r, 0, !0), l, u = [];
    if (se(n[0].barSize)) {
      var s = !1, c = r / a, f = n.reduce((m, b) => m + (b.barSize || 0), 0);
      f += (a - 1) * o, f >= r && (f -= (a - 1) * o, o = 0), f >= r && c > 0 && (s = !0, c *= 0.9, f = a * c);
      var v = (r - f) / 2 >> 0, p = {
        offset: v - o,
        size: 0
      };
      l = n.reduce((m, b) => {
        var x, w = {
          stackId: b.stackId,
          dataKeys: b.dataKeys,
          position: {
            offset: p.offset + p.size + o,
            size: s ? c : (x = b.barSize) !== null && x !== void 0 ? x : 0
          }
        }, P = [...m, w];
        return p = P[P.length - 1].position, P;
      }, u);
    } else {
      var h = dt(t, r, 0, !0);
      r - 2 * h - (a - 1) * o <= 0 && (o = 0);
      var y = (r - 2 * h - (a - 1) * o) / a;
      y > 1 && (y >>= 0);
      var g = se(i) ? Math.min(y, i) : y;
      l = n.reduce((m, b, x) => [...m, {
        stackId: b.stackId,
        dataKeys: b.dataKeys,
        position: {
          offset: h + (y + o) * x + (y - g) / 2,
          size: g
        }
      }], u);
    }
    return l;
  }
}
var rj = (e, t, r, n, i, a, o) => {
  var l = oe(o) ? t : o, u = aU(r, n, i !== a ? i : a, e, l);
  return i !== a && u != null && (u = u.map((s) => Is(Is({}, s), {}, {
    position: Is(Is({}, s.position), {}, {
      offset: s.position.offset - i / 2
    })
  }))), u;
}, nj = (e, t) => {
  var r = Ed(t);
  if (!(!e || r == null || t == null)) {
    var {
      stackId: n
    } = t;
    if (n != null) {
      var i = e[n];
      if (i) {
        var {
          stackedData: a
        } = i;
        if (a)
          return a.find((o) => o.key === r);
      }
    }
  }
};
function KP(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function mf(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? KP(Object(r), !0).forEach(function(n) {
      oU(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : KP(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function oU(e, t, r) {
  return (t = lU(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function lU(e) {
  var t = uU(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function uU(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var sU = (e, t) => bo(e, t), cU = (e, t) => xi(e, "radiusAxis", t), Vd = A([sU, cU], (e, t) => {
  if (!(e == null || t == null))
    return mf(mf({}, e), {}, {
      scale: t
    });
}), Zg = (e, t, r, n) => A4(e, "radiusAxis", t, n), fU = (e, t, r) => la(e, r), dU = (e, t, r) => xi(e, "angleAxis", r), Hd = A([fU, dU], (e, t) => {
  if (!(e == null || t == null))
    return mf(mf({}, e), {}, {
      scale: t
    });
}), Qg = (e, t, r, n) => ca(e, "angleAxis", r, n), vU = (e, t, r, n) => n, Jg = A([$u, vU], (e, t) => {
  if (e.some((r) => r.type === "radialBar" && t.dataKey === r.dataKey && t.stackId === r.stackId))
    return t;
}), ij = A([q, Vd, Zg, Hd, Qg], (e, t, r, n, i) => br(e, "radiusAxis") ? Ft(t, r, !1) : Ft(n, i, !1)), pU = A([Hd, Vd, q], (e, t, r) => {
  var n = r === "radial" ? e : t;
  if (!(n == null || n.scale == null))
    return kA({
      numericAxis: n
    });
}), hU = (e, t, r, n, i) => i, mU = (e, t, r, n, i) => r, yU = (e, t, r, n, i) => t, aj = (e, t, r, n, i) => n.maxBarSize, oj = (e) => e.type === "radialBar", gU = A([q, $u, mU, yU], (e, t, r, n) => t.filter((i) => e === "centric" ? i.angleAxisId === r : i.radiusAxisId === n).filter((i) => i.hide === !1).filter(oj)), bU = () => {
}, xU = A([gU, i_, bU], tj), wU = A([q, xd, Hd, Qg, Vd, Zg, aj], (e, t, r, n, i, a, o) => {
  var l, u, s = oe(o) ? t : o;
  if (e === "centric") {
    var c, f;
    return (c = (f = Ft(r, n, !0)) !== null && f !== void 0 ? f : s) !== null && c !== void 0 ? c : 0;
  }
  return (l = (u = Ft(i, a, !0)) !== null && u !== void 0 ? u : s) !== null && l !== void 0 ? l : 0;
}), PU = A([xU, xd, n_, rg, wU, ij, aj], rj), OU = A([PU, Jg], (e, t) => {
  if (!(e == null || t == null)) {
    var r = e.find((n) => n.stackId === t.stackId && t.dataKey != null && n.dataKeys.includes(t.dataKey));
    if (r != null)
      return r.position;
  }
}), lj = A([Lu], (e) => e.filter(oj).filter(_u)), SU = A([lj, yi, He], og), WP = A([SU, lj, go, ng], pg), EU = (e, t, r) => {
  var n = q(e);
  return n === "centric" ? WP(e, "radiusAxis", t) : WP(e, "angleAxis", r);
}, AU = A([EU, Jg], nj), kU = A([Hd, Qg, Vd, Zg, tn, Jg, ij, q, pU, ua, hU, OU, AU], (e, t, r, n, i, a, o, l, u, s, c, f, v) => {
  var {
    chartData: p,
    dataStartIndex: h,
    dataEndIndex: y
  } = i;
  if (a == null || r == null || e == null || p == null || o == null || f == null || l !== "centric" && l !== "radial" || n == null)
    return [];
  var {
    dataKey: g,
    minPointSize: m
  } = a, {
    cx: b,
    cy: x,
    startAngle: w,
    endAngle: P
  } = s, O = p.slice(h, y + 1), S = l === "centric" ? r : e, E = v ? S.scale.domain() : null;
  return UU({
    angleAxis: e,
    angleAxisTicks: t,
    bandSize: o,
    baseValue: u,
    cells: c,
    cx: b,
    cy: x,
    dataKey: g,
    dataStartIndex: h,
    displayedData: O,
    endAngle: P,
    layout: l,
    minPointSize: m,
    pos: f,
    radiusAxis: r,
    radiusAxisTicks: n,
    stackedData: v,
    stackedDomain: E,
    startAngle: w
  });
}), _U = A([yi, (e, t) => t], (e, t) => {
  var {
    chartData: r,
    dataStartIndex: n,
    dataEndIndex: i
  } = e;
  if (r == null)
    return [];
  var a = r.slice(n, i + 1);
  return a.length === 0 ? [] : a.map((o) => ({
    type: t,
    // @ts-expect-error we need a better typing for our data inputs
    value: o.name,
    // @ts-expect-error we need a better typing for our data inputs
    color: o.fill,
    // @ts-expect-error we need a better typing for our data inputs
    payload: o
  }));
});
function uj(e, t) {
  return e && typeof e == "object" && "zIndex" in e && typeof e.zIndex == "number" && se(e.zIndex) ? e.zIndex : t;
}
var IU = ["shape", "activeShape", "cornerRadius", "id"], jU = ["onMouseEnter", "onClick", "onMouseLeave"], CU = ["value", "background"];
function io() {
  return io = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, io.apply(null, arguments);
}
function UP(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function xt(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? UP(Object(r), !0).forEach(function(n) {
      TU(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : UP(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function TU(e, t, r) {
  return (t = MU(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function MU(e) {
  var t = DU(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function DU(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function Wh(e, t) {
  if (e == null) return {};
  var r, n, i = NU(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function NU(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
var yf = [];
function $U(e) {
  var {
    showLabels: t,
    sectors: r,
    children: n
  } = e, i = r.map((a) => ({
    value: a.value,
    payload: a.payload,
    parentViewBox: void 0,
    clockWise: !1,
    viewBox: {
      cx: a.cx,
      cy: a.cy,
      innerRadius: a.innerRadius,
      outerRadius: a.outerRadius,
      startAngle: a.startAngle,
      endAngle: a.endAngle,
      clockWise: !1
    },
    fill: a.fill
  }));
  return /* @__PURE__ */ d.createElement(kI, {
    value: t ? i : void 0
  }, n);
}
function LU(e) {
  var {
    sectors: t,
    allOtherRadialBarProps: r,
    showLabels: n
  } = e, {
    shape: i,
    activeShape: a,
    cornerRadius: o,
    id: l
  } = r, u = Wh(r, IU), s = re(u), c = T(Qr), {
    onMouseEnter: f,
    onClick: v,
    onMouseLeave: p
  } = r, h = Wh(r, jU), y = jo(f, r.dataKey, l), g = Co(p), m = To(v, r.dataKey, l);
  return t == null ? null : /* @__PURE__ */ d.createElement($U, {
    showLabels: n,
    sectors: t
  }, t.map((b, x) => {
    var w = a && c === String(x), P = y(b, x), O = g(b, x), S = m(b, x), E = xt(xt(xt(xt({}, s), {}, {
      cornerRadius: ej(o)
    }, b), Nr(h, b, x)), {}, {
      onMouseEnter: P,
      onMouseLeave: O,
      onClick: S,
      className: "recharts-radial-bar-sector ".concat(b.className),
      forceCornerRadius: u.forceCornerRadius,
      cornerIsExternal: u.cornerIsExternal,
      isActive: w,
      option: w ? a : i
    });
    return w ? /* @__PURE__ */ d.createElement(pe, {
      zIndex: ie.activeBar,
      key: "sector-".concat(b.cx, "-").concat(b.cy, "-").concat(b.innerRadius, "-").concat(b.outerRadius, "-").concat(b.startAngle, "-").concat(b.endAngle, "-").concat(x)
    }, /* @__PURE__ */ d.createElement(Kh, E)) : /* @__PURE__ */ d.createElement(Kh, io({
      key: "sector-".concat(b.cx, "-").concat(b.cy, "-").concat(b.innerRadius, "-").concat(b.outerRadius, "-").concat(b.startAngle, "-").concat(b.endAngle, "-").concat(x)
    }, E));
  }), /* @__PURE__ */ d.createElement(bi, {
    label: r.label
  }), r.children);
}
function RU(e) {
  var {
    props: t,
    previousSectorsRef: r
  } = e, {
    data: n,
    isAnimationActive: i,
    animationBegin: a,
    animationDuration: o,
    animationEasing: l,
    onAnimationEnd: u,
    onAnimationStart: s
  } = t, c = en(t, "recharts-radialbar-"), f = r.current, [v, p] = d.useState(!1), h = d.useCallback(() => {
    typeof u == "function" && u(), p(!1);
  }, [u]), y = d.useCallback(() => {
    typeof s == "function" && s(), p(!0);
  }, [s]);
  return /* @__PURE__ */ d.createElement(Jr, {
    animationId: c,
    begin: a,
    duration: o,
    isActive: i,
    easing: l,
    onAnimationStart: y,
    onAnimationEnd: h,
    key: c
  }, (g) => {
    var m = g === 1 ? n : (n ?? yf).map((b, x) => {
      var w = f && f[x];
      if (w)
        return xt(xt({}, b), {}, {
          startAngle: X(w.startAngle, b.startAngle, g),
          endAngle: X(w.endAngle, b.endAngle, g)
        });
      var {
        endAngle: P,
        startAngle: O
      } = b;
      return xt(xt({}, b), {}, {
        endAngle: X(O, P, g)
      });
    });
    return g > 0 && (r.current = m ?? null), /* @__PURE__ */ d.createElement(U, null, /* @__PURE__ */ d.createElement(LU, {
      sectors: m ?? yf,
      allOtherRadialBarProps: t,
      showLabels: !v
    }));
  });
}
function zU(e) {
  var t = d.useRef(null);
  return /* @__PURE__ */ d.createElement(RU, {
    props: e,
    previousSectorsRef: t
  });
}
function BU(e) {
  var t = T((r) => _U(r, e.legendType));
  return /* @__PURE__ */ d.createElement(Xg, {
    legendPayload: t ?? []
  });
}
var FU = /* @__PURE__ */ d.memo((e) => {
  var {
    dataKey: t,
    data: r,
    stroke: n,
    strokeWidth: i,
    name: a,
    hide: o,
    fill: l,
    tooltipType: u,
    id: s
  } = e, c = {
    dataDefinedOnItem: r,
    positions: void 0,
    settings: {
      graphicalItemId: s,
      stroke: n,
      strokeWidth: i,
      fill: l,
      nameKey: void 0,
      // RadialBar does not have nameKey, why?
      dataKey: t,
      name: ir(a, t),
      hide: o,
      type: u,
      color: l,
      unit: ""
      // Why does RadialBar not support unit?
    }
  };
  return /* @__PURE__ */ d.createElement(an, {
    tooltipEntrySettings: c
  });
});
class KU extends d.PureComponent {
  renderBackground(t) {
    if (t == null)
      return null;
    var {
      cornerRadius: r
    } = this.props, n = er(this.props.background);
    return /* @__PURE__ */ d.createElement(pe, {
      zIndex: uj(this.props.background, ie.barBackground)
    }, t.map((i, a) => {
      var {
        value: o,
        background: l
      } = i, u = Wh(i, CU);
      if (!l)
        return null;
      var s = xt(xt(xt(xt(xt({
        cornerRadius: ej(r)
      }, u), {}, {
        // @ts-expect-error backgroundProps is contributing unknown props
        fill: "#eee"
      }, l), n), Nr(this.props, i, a)), {}, {
        index: a,
        className: Y("recharts-radial-bar-background-sector", String(n == null ? void 0 : n.className)),
        option: l,
        isActive: !1
      });
      return /* @__PURE__ */ d.createElement(Kh, io({
        key: "background-".concat(u.cx, "-").concat(u.cy, "-").concat(u.innerRadius, "-").concat(u.outerRadius, "-").concat(u.startAngle, "-").concat(u.endAngle, "-").concat(a)
      }, s));
    }));
  }
  render() {
    var {
      hide: t,
      data: r,
      className: n,
      background: i
    } = this.props;
    if (t)
      return null;
    var a = Y("recharts-area", n);
    return /* @__PURE__ */ d.createElement(pe, {
      zIndex: this.props.zIndex
    }, /* @__PURE__ */ d.createElement(U, {
      className: a
    }, i && /* @__PURE__ */ d.createElement(U, {
      className: "recharts-radial-bar-background"
    }, this.renderBackground(r)), /* @__PURE__ */ d.createElement(U, {
      className: "recharts-radial-bar-sectors"
    }, /* @__PURE__ */ d.createElement(zU, this.props))));
  }
}
function WU(e) {
  var t, r = Io(e.children, sa), n = {
    data: void 0,
    hide: !1,
    id: e.id,
    dataKey: e.dataKey,
    minPointSize: e.minPointSize,
    stackId: od(e.stackId),
    maxBarSize: e.maxBarSize,
    barSize: e.barSize,
    type: "radialBar",
    angleAxisId: e.angleAxisId,
    radiusAxisId: e.radiusAxisId
  }, i = (t = T((a) => kU(a, e.radiusAxisId, e.angleAxisId, n, r))) !== null && t !== void 0 ? t : yf;
  return /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(FU, {
    dataKey: e.dataKey,
    data: i,
    stroke: e.stroke,
    strokeWidth: e.strokeWidth,
    name: e.name,
    hide: e.hide,
    fill: e.fill,
    tooltipType: e.tooltipType,
    id: e.id
  }), /* @__PURE__ */ d.createElement(KU, io({}, e, {
    data: i
  })));
}
var js = {
  angleAxisId: 0,
  animationBegin: 0,
  animationDuration: 1500,
  animationEasing: "ease",
  background: !1,
  cornerIsExternal: !1,
  cornerRadius: 0,
  data: [],
  forceCornerRadius: !1,
  hide: !1,
  isAnimationActive: "auto",
  label: !1,
  legendType: "rect",
  minPointSize: 0,
  radiusAxisId: 0,
  zIndex: ie.bar
};
function UU(e) {
  var {
    displayedData: t,
    stackedData: r,
    dataStartIndex: n,
    stackedDomain: i,
    dataKey: a,
    baseValue: o,
    layout: l,
    radiusAxis: u,
    radiusAxisTicks: s,
    bandSize: c,
    pos: f,
    angleAxis: v,
    minPointSize: p,
    cx: h,
    cy: y,
    angleAxisTicks: g,
    cells: m,
    startAngle: b,
    endAngle: x
  } = e;
  return g == null || s == null ? yf : (t ?? []).map((w, P) => {
    var O, S, E, k, _, I;
    if (r ? O = AA(r[n + P], i) : (O = G(w, a), Array.isArray(O) || (O = [o, O])), l === "radial") {
      S = Rc({
        axis: u,
        ticks: s,
        bandSize: c,
        offset: f.offset,
        entry: w,
        index: P
      }), _ = v.scale(O[1]), k = v.scale(O[0]), E = (S ?? 0) + f.size;
      var j = _ - k;
      if (Math.abs(p) > 0 && Math.abs(j) < Math.abs(p)) {
        var z = We(j || p) * (Math.abs(p) - Math.abs(j));
        _ += z;
      }
      I = {
        background: {
          cx: h,
          cy: y,
          innerRadius: S,
          outerRadius: E,
          startAngle: b,
          endAngle: x
        }
      };
    } else {
      S = u.scale(O[0]), E = u.scale(O[1]), k = Rc({
        axis: v,
        ticks: g,
        bandSize: c,
        offset: f.offset,
        entry: w,
        index: P
      }), _ = (k ?? 0) + f.size;
      var N = E - S;
      if (Math.abs(p) > 0 && Math.abs(N) < Math.abs(p)) {
        var R = We(N || p) * (Math.abs(p) - Math.abs(N));
        E += R;
      }
    }
    return xt(xt(xt({}, w), I), {}, {
      payload: w,
      value: r ? O : O[1],
      cx: h,
      cy: y,
      innerRadius: S,
      outerRadius: E,
      startAngle: k,
      endAngle: _
    }, m && m[P] && m[P].props);
  });
}
function VU(e) {
  var t = ee(e, js);
  return /* @__PURE__ */ d.createElement(on, {
    id: t.id,
    type: "radialBar"
  }, (r) => {
    var n, i, a;
    return /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(Yg, {
      type: "radialBar",
      id: r,
      data: void 0,
      dataKey: t.dataKey,
      hide: (n = t.hide) !== null && n !== void 0 ? n : js.hide,
      angleAxisId: (i = t.angleAxisId) !== null && i !== void 0 ? i : js.angleAxisId,
      radiusAxisId: (a = t.radiusAxisId) !== null && a !== void 0 ? a : js.radiusAxisId,
      stackId: od(t.stackId),
      barSize: t.barSize,
      minPointSize: t.minPointSize,
      maxBarSize: t.maxBarSize
    }), /* @__PURE__ */ d.createElement(BU, t), /* @__PURE__ */ d.createElement(WU, io({}, t, {
      id: r
    })));
  });
}
VU.displayName = "RadialBar";
function VP(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function HP(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? VP(Object(r), !0).forEach(function(n) {
      HU(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : VP(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function HU(e, t, r) {
  return (t = XU(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function XU(e) {
  var t = YU(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function YU(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var GU = ["Webkit", "Moz", "O", "ms"], qU = (e, t) => {
  var r = e.replace(/(\w)/, (i) => i.toUpperCase()), n = GU.reduce((i, a) => HP(HP({}, i), {}, {
    [a + r]: t
  }), {});
  return n[e] = t, n;
}, sj = (e) => {
  var {
    chartData: t
  } = e, r = J(), n = me();
  return d.useEffect(() => n ? () => {
  } : (r($h(t)), () => {
    r($h(void 0));
  }), [t, r, n]), null;
}, ZU = (e) => {
  var {
    computedData: t
  } = e, r = J();
  return d.useEffect(() => (r(ZK(t)), () => {
    r($h(void 0));
  }), [t, r]), null;
}, QU = (e) => e.chartData.chartData, JU = () => T(QU), eV = (e) => {
  var {
    dataStartIndex: t,
    dataEndIndex: r
  } = e.chartData;
  return {
    startIndex: t,
    endIndex: r
  };
}, tV = () => T(eV), rV = /* @__PURE__ */ d.createContext(() => {
}), XP = {
  x: 0,
  y: 0,
  width: 0,
  height: 0,
  padding: {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  }
}, cj = Ut({
  name: "brush",
  initialState: XP,
  reducers: {
    setBrushSettings(e, t) {
      return t.payload == null ? XP : t.payload;
    }
  }
}), {
  setBrushSettings: YP
} = cj.actions, nV = cj.reducer;
function Gl() {
  return Gl = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Gl.apply(null, arguments);
}
function GP(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function ki(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? GP(Object(r), !0).forEach(function(n) {
      sn(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : GP(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function sn(e, t, r) {
  return (t = iV(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function iV(e) {
  var t = aV(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function aV(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function oV(e) {
  var {
    x: t,
    y: r,
    width: n,
    height: i,
    stroke: a
  } = e, o = Math.floor(r + i / 2) - 1;
  return /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement("rect", {
    x: t,
    y: r,
    width: n,
    height: i,
    fill: a,
    stroke: "none"
  }), /* @__PURE__ */ d.createElement("line", {
    x1: t + 1,
    y1: o,
    x2: t + n - 1,
    y2: o,
    fill: "none",
    stroke: "#fff"
  }), /* @__PURE__ */ d.createElement("line", {
    x1: t + 1,
    y1: o + 2,
    x2: t + n - 1,
    y2: o + 2,
    fill: "none",
    stroke: "#fff"
  }));
}
function lV(e) {
  var {
    travellerProps: t,
    travellerType: r
  } = e;
  return /* @__PURE__ */ d.isValidElement(r) ? /* @__PURE__ */ d.cloneElement(r, t) : typeof r == "function" ? r(t) : /* @__PURE__ */ d.createElement(oV, t);
}
function qP(e) {
  var t, r, {
    otherProps: n,
    travellerX: i,
    id: a,
    onMouseEnter: o,
    onMouseLeave: l,
    onMouseDown: u,
    onTouchStart: s,
    onTravellerMoveKeyboard: c,
    onFocus: f,
    onBlur: v
  } = e, {
    y: p,
    x: h,
    travellerWidth: y,
    height: g,
    traveller: m,
    ariaLabel: b,
    data: x,
    startIndex: w,
    endIndex: P
  } = n, O = Math.max(i, h), S = ki(ki({}, re(n)), {}, {
    x: O,
    y: p,
    width: y,
    height: g
  }), E = b || "Min value: ".concat((t = x[w]) === null || t === void 0 ? void 0 : t.name, ", Max value: ").concat((r = x[P]) === null || r === void 0 ? void 0 : r.name);
  return /* @__PURE__ */ d.createElement(U, {
    tabIndex: 0,
    role: "slider",
    "aria-label": E,
    "aria-valuenow": i,
    className: "recharts-brush-traveller",
    onMouseEnter: o,
    onMouseLeave: l,
    onMouseDown: u,
    onTouchStart: s,
    onKeyDown: (k) => {
      ["ArrowLeft", "ArrowRight"].includes(k.key) && (k.preventDefault(), k.stopPropagation(), c(k.key === "ArrowRight" ? 1 : -1, a));
    },
    onFocus: f,
    onBlur: v,
    style: {
      cursor: "col-resize"
    }
  }, /* @__PURE__ */ d.createElement(lV, {
    travellerType: m,
    travellerProps: S
  }));
}
function ZP(e) {
  var {
    index: t,
    data: r,
    tickFormatter: n,
    dataKey: i
  } = e, a = G(r[t], i, t);
  return typeof n == "function" ? n(a, t) : a;
}
function QP(e, t) {
  for (var r = e.length, n = 0, i = r - 1; i - n > 1; ) {
    var a = Math.floor((n + i) / 2);
    e[a] > t ? i = a : n = a;
  }
  return t >= e[i] ? i : n;
}
function Yv(e) {
  var {
    startX: t,
    endX: r,
    scaleValues: n,
    gap: i,
    data: a
  } = e, o = a.length - 1, l = Math.min(t, r), u = Math.max(t, r), s = QP(n, l), c = QP(n, u);
  return {
    startIndex: s - s % i,
    endIndex: c === o ? o : c - c % i
  };
}
function uV(e) {
  var {
    x: t,
    y: r,
    width: n,
    height: i,
    fill: a,
    stroke: o
  } = e;
  return /* @__PURE__ */ d.createElement("rect", {
    stroke: o,
    fill: a,
    x: t,
    y: r,
    width: n,
    height: i
  });
}
function sV(e) {
  var {
    startIndex: t,
    endIndex: r,
    y: n,
    height: i,
    travellerWidth: a,
    stroke: o,
    tickFormatter: l,
    dataKey: u,
    data: s,
    startX: c,
    endX: f
  } = e, v = 5, p = {
    pointerEvents: "none",
    fill: o
  };
  return /* @__PURE__ */ d.createElement(U, {
    className: "recharts-brush-texts"
  }, /* @__PURE__ */ d.createElement(ci, Gl({
    textAnchor: "end",
    verticalAnchor: "middle",
    x: Math.min(c, f) - v,
    y: n + i / 2
  }, p), ZP({
    index: t,
    tickFormatter: l,
    dataKey: u,
    data: s
  })), /* @__PURE__ */ d.createElement(ci, Gl({
    textAnchor: "start",
    verticalAnchor: "middle",
    x: Math.max(c, f) + a + v,
    y: n + i / 2
  }, p), ZP({
    index: r,
    tickFormatter: l,
    dataKey: u,
    data: s
  })));
}
function cV(e) {
  var {
    y: t,
    height: r,
    stroke: n,
    travellerWidth: i,
    startX: a,
    endX: o,
    onMouseEnter: l,
    onMouseLeave: u,
    onMouseDown: s,
    onTouchStart: c
  } = e, f = Math.min(a, o) + i, v = Math.max(Math.abs(o - a) - i, 0);
  return /* @__PURE__ */ d.createElement("rect", {
    className: "recharts-brush-slide",
    onMouseEnter: l,
    onMouseLeave: u,
    onMouseDown: s,
    onTouchStart: c,
    style: {
      cursor: "move"
    },
    stroke: "none",
    fill: n,
    fillOpacity: 0.2,
    x: f,
    y: t,
    width: v,
    height: r
  });
}
function fV(e) {
  var {
    x: t,
    y: r,
    width: n,
    height: i,
    data: a,
    children: o,
    padding: l
  } = e, u = d.Children.count(o) === 1;
  if (!u)
    return null;
  var s = d.Children.only(o);
  return s ? /* @__PURE__ */ d.cloneElement(s, {
    x: t,
    y: r,
    width: n,
    height: i,
    margin: l,
    compact: !0,
    data: a
  }) : null;
}
var dV = (e) => {
  var {
    data: t,
    startIndex: r,
    endIndex: n,
    x: i,
    width: a,
    travellerWidth: o
  } = e;
  if (!t || !t.length)
    return {};
  var l = t.length, u = fk().domain(jy(0, l)).range([i, i + a - o]), s = u.domain().map((c) => u(c)).filter(ey);
  return {
    isTextActive: !1,
    isSlideMoving: !1,
    isTravellerMoving: !1,
    isTravellerFocused: !1,
    startX: u(r),
    endX: u(n),
    scale: u,
    scaleValues: s
  };
}, JP = (e) => e.changedTouches && !!e.changedTouches.length;
class vV extends d.PureComponent {
  constructor(t) {
    super(t), sn(this, "handleDrag", (r) => {
      this.leaveTimer && (clearTimeout(this.leaveTimer), this.leaveTimer = null), this.state.isTravellerMoving ? this.handleTravellerMove(r) : this.state.isSlideMoving && this.handleSlideDrag(r);
    }), sn(this, "handleTouchMove", (r) => {
      r.changedTouches != null && r.changedTouches.length > 0 && this.handleDrag(r.changedTouches[0]);
    }), sn(this, "handleDragEnd", () => {
      this.setState({
        isTravellerMoving: !1,
        isSlideMoving: !1
      }, () => {
        var {
          endIndex: r,
          onDragEnd: n,
          startIndex: i
        } = this.props;
        n == null || n({
          endIndex: r,
          startIndex: i
        });
      }), this.detachDragEndListener();
    }), sn(this, "handleLeaveWrapper", () => {
      (this.state.isTravellerMoving || this.state.isSlideMoving) && (this.leaveTimer = window.setTimeout(this.handleDragEnd, this.props.leaveTimeOut));
    }), sn(this, "handleEnterSlideOrTraveller", () => {
      this.setState({
        isTextActive: !0
      });
    }), sn(this, "handleLeaveSlideOrTraveller", () => {
      this.setState({
        isTextActive: !1
      });
    }), sn(this, "handleSlideDragStart", (r) => {
      var n = JP(r) ? r.changedTouches[0] : r;
      this.setState({
        isTravellerMoving: !1,
        isSlideMoving: !0,
        slideMoveStartX: n.pageX
      }), this.attachDragEndListener();
    }), sn(this, "handleTravellerMoveKeyboard", (r, n) => {
      var {
        data: i,
        gap: a,
        startIndex: o,
        endIndex: l
      } = this.props, {
        scaleValues: u,
        startX: s,
        endX: c
      } = this.state;
      if (u != null) {
        var f = -1;
        if (n === "startX" ? f = o : n === "endX" && (f = l), !(f < 0 || f >= i.length)) {
          var v = f + r;
          if (!(v === -1 || v >= u.length)) {
            var p = u[v];
            n === "startX" && p >= c || n === "endX" && p <= s || this.setState(
              // @ts-expect-error not sure why typescript is not happy with this, partial update is fine in React
              {
                [n]: p
              },
              () => {
                this.props.onChange(Yv({
                  startX: this.state.startX,
                  endX: this.state.endX,
                  data: i,
                  gap: a,
                  scaleValues: u
                }));
              }
            );
          }
        }
      }
    }), this.travellerDragStartHandlers = {
      startX: this.handleTravellerDragStart.bind(this, "startX"),
      endX: this.handleTravellerDragStart.bind(this, "endX")
    }, this.state = {
      brushMoveStartX: 0,
      movingTravellerId: void 0,
      endX: 0,
      startX: 0,
      slideMoveStartX: 0
    };
  }
  static getDerivedStateFromProps(t, r) {
    var {
      data: n,
      width: i,
      x: a,
      travellerWidth: o,
      startIndex: l,
      endIndex: u,
      startIndexControlledFromProps: s,
      endIndexControlledFromProps: c
    } = t;
    if (n !== r.prevData)
      return ki({
        prevData: n,
        prevTravellerWidth: o,
        prevX: a,
        prevWidth: i
      }, n && n.length ? dV({
        data: n,
        width: i,
        x: a,
        travellerWidth: o,
        startIndex: l,
        endIndex: u
      }) : {
        scale: void 0,
        scaleValues: void 0
      });
    var f = r.scale;
    if (f && (i !== r.prevWidth || a !== r.prevX || o !== r.prevTravellerWidth)) {
      f.range([a, a + i - o]);
      var v = f.domain().map((p) => f(p)).filter((p) => p != null);
      return {
        prevData: n,
        prevTravellerWidth: o,
        prevX: a,
        prevWidth: i,
        startX: f(t.startIndex),
        endX: f(t.endIndex),
        scaleValues: v
      };
    }
    if (r.scale && !r.isSlideMoving && !r.isTravellerMoving && !r.isTravellerFocused && !r.isTextActive) {
      if (s != null && r.prevStartIndexControlledFromProps !== s)
        return {
          startX: r.scale(s),
          prevStartIndexControlledFromProps: s
        };
      if (c != null && r.prevEndIndexControlledFromProps !== c)
        return {
          endX: r.scale(c),
          prevEndIndexControlledFromProps: c
        };
    }
    return null;
  }
  componentWillUnmount() {
    this.leaveTimer && (clearTimeout(this.leaveTimer), this.leaveTimer = null), this.detachDragEndListener();
  }
  attachDragEndListener() {
    window.addEventListener("mouseup", this.handleDragEnd, !0), window.addEventListener("touchend", this.handleDragEnd, !0), window.addEventListener("mousemove", this.handleDrag, !0);
  }
  detachDragEndListener() {
    window.removeEventListener("mouseup", this.handleDragEnd, !0), window.removeEventListener("touchend", this.handleDragEnd, !0), window.removeEventListener("mousemove", this.handleDrag, !0);
  }
  handleSlideDrag(t) {
    var {
      slideMoveStartX: r,
      startX: n,
      endX: i,
      scaleValues: a
    } = this.state;
    if (a != null) {
      var {
        x: o,
        width: l,
        travellerWidth: u,
        startIndex: s,
        endIndex: c,
        onChange: f,
        data: v,
        gap: p
      } = this.props, h = t.pageX - r;
      h > 0 ? h = Math.min(h, o + l - u - i, o + l - u - n) : h < 0 && (h = Math.max(h, o - n, o - i));
      var y = Yv({
        startX: n + h,
        endX: i + h,
        data: v,
        gap: p,
        scaleValues: a
      });
      (y.startIndex !== s || y.endIndex !== c) && f && f(y), this.setState({
        startX: n + h,
        endX: i + h,
        slideMoveStartX: t.pageX
      });
    }
  }
  handleTravellerDragStart(t, r) {
    var n = JP(r) ? r.changedTouches[0] : r;
    this.setState({
      isSlideMoving: !1,
      isTravellerMoving: !0,
      movingTravellerId: t,
      brushMoveStartX: n.pageX
    }), this.attachDragEndListener();
  }
  handleTravellerMove(t) {
    var {
      brushMoveStartX: r,
      movingTravellerId: n,
      endX: i,
      startX: a,
      scaleValues: o
    } = this.state;
    if (!(n == null || o == null)) {
      var l = this.state[n], {
        x: u,
        width: s,
        travellerWidth: c,
        onChange: f,
        gap: v,
        data: p
      } = this.props, h = {
        startX: this.state.startX,
        endX: this.state.endX,
        data: p,
        gap: v,
        scaleValues: o
      }, y = t.pageX - r;
      y > 0 ? y = Math.min(y, u + s - c - l) : y < 0 && (y = Math.max(y, u - l)), h[n] = l + y;
      var g = Yv(h), {
        startIndex: m,
        endIndex: b
      } = g, x = () => {
        var w = p.length - 1;
        return n === "startX" && (i > a ? m % v === 0 : b % v === 0) || i < a && b === w || n === "endX" && (i > a ? b % v === 0 : m % v === 0) || i > a && b === w;
      };
      this.setState(
        // @ts-expect-error not sure why typescript is not happy with this, partial update is fine in React
        {
          [n]: l + y,
          brushMoveStartX: t.pageX
        },
        () => {
          f && x() && f(g);
        }
      );
    }
  }
  render() {
    var {
      data: t,
      className: r,
      children: n,
      x: i,
      y: a,
      dy: o,
      width: l,
      height: u,
      alwaysShowText: s,
      fill: c,
      stroke: f,
      startIndex: v,
      endIndex: p,
      travellerWidth: h,
      tickFormatter: y,
      dataKey: g,
      padding: m
    } = this.props, {
      startX: b,
      endX: x,
      isTextActive: w,
      isSlideMoving: P,
      isTravellerMoving: O,
      isTravellerFocused: S
    } = this.state;
    if (!t || !t.length || !B(i) || !B(a) || !B(l) || !B(u) || l <= 0 || u <= 0)
      return null;
    var E = Y("recharts-brush", r), k = qU("userSelect", "none"), _ = a + (o ?? 0);
    return /* @__PURE__ */ d.createElement(U, {
      className: E,
      onMouseLeave: this.handleLeaveWrapper,
      onTouchMove: this.handleTouchMove,
      style: k
    }, /* @__PURE__ */ d.createElement(uV, {
      x: i,
      y: _,
      width: l,
      height: u,
      fill: c,
      stroke: f
    }), /* @__PURE__ */ d.createElement(f$, null, /* @__PURE__ */ d.createElement(fV, {
      x: i,
      y: _,
      width: l,
      height: u,
      data: t,
      padding: m
    }, n)), /* @__PURE__ */ d.createElement(cV, {
      y: _,
      height: u,
      stroke: f,
      travellerWidth: h,
      startX: b,
      endX: x,
      onMouseEnter: this.handleEnterSlideOrTraveller,
      onMouseLeave: this.handleLeaveSlideOrTraveller,
      onMouseDown: this.handleSlideDragStart,
      onTouchStart: this.handleSlideDragStart
    }), /* @__PURE__ */ d.createElement(qP, {
      travellerX: b,
      id: "startX",
      otherProps: ki(ki({}, this.props), {}, {
        y: _
      }),
      onMouseEnter: this.handleEnterSlideOrTraveller,
      onMouseLeave: this.handleLeaveSlideOrTraveller,
      onMouseDown: this.travellerDragStartHandlers.startX,
      onTouchStart: this.travellerDragStartHandlers.startX,
      onTravellerMoveKeyboard: this.handleTravellerMoveKeyboard,
      onFocus: () => {
        this.setState({
          isTravellerFocused: !0
        });
      },
      onBlur: () => {
        this.setState({
          isTravellerFocused: !1
        });
      }
    }), /* @__PURE__ */ d.createElement(qP, {
      travellerX: x,
      id: "endX",
      otherProps: ki(ki({}, this.props), {}, {
        y: _
      }),
      onMouseEnter: this.handleEnterSlideOrTraveller,
      onMouseLeave: this.handleLeaveSlideOrTraveller,
      onMouseDown: this.travellerDragStartHandlers.endX,
      onTouchStart: this.travellerDragStartHandlers.endX,
      onTravellerMoveKeyboard: this.handleTravellerMoveKeyboard,
      onFocus: () => {
        this.setState({
          isTravellerFocused: !0
        });
      },
      onBlur: () => {
        this.setState({
          isTravellerFocused: !1
        });
      }
    }), (w || P || O || S || s) && /* @__PURE__ */ d.createElement(sV, {
      startIndex: v,
      endIndex: p,
      y: _,
      height: u,
      travellerWidth: h,
      stroke: f,
      tickFormatter: y,
      dataKey: g,
      data: t,
      startX: b,
      endX: x
    }));
  }
}
function pV(e) {
  var t = J(), r = JU(), n = tV(), i = d.useContext(rV), a = e.onChange, {
    startIndex: o,
    endIndex: l
  } = e;
  d.useEffect(() => {
    t(Lh({
      startIndex: o,
      endIndex: l
    }));
  }, [t, l, o]), sW();
  var u = d.useCallback((g) => {
    if (n != null) {
      var {
        startIndex: m,
        endIndex: b
      } = n;
      (g.startIndex !== m || g.endIndex !== b) && (i == null || i(g), a == null || a(g), t(Lh(g)));
    }
  }, [a, i, t, n]), s = T(yu);
  if (s == null || n == null || r == null || !r.length)
    return null;
  var {
    startIndex: c,
    endIndex: f
  } = n, {
    x: v,
    y: p,
    width: h
  } = s, y = {
    data: r,
    x: v,
    y: p,
    width: h,
    startIndex: c,
    endIndex: f,
    onChange: u
  };
  return /* @__PURE__ */ d.createElement(vV, Gl({}, e, y, {
    startIndexControlledFromProps: o ?? void 0,
    endIndexControlledFromProps: l ?? void 0
  }));
}
function hV(e) {
  var t = J();
  return d.useEffect(() => (t(YP(e)), () => {
    t(YP(null));
  }), [t, e]), null;
}
var mV = {
  height: 40,
  travellerWidth: 5,
  gap: 1,
  fill: "#fff",
  stroke: "#666",
  padding: {
    top: 1,
    right: 1,
    bottom: 1,
    left: 1
  },
  leaveTimeOut: 1e3,
  alwaysShowText: !1
};
function yV(e) {
  var t = ee(e, mV);
  return /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(hV, {
    height: t.height,
    x: t.x,
    y: t.y,
    width: t.width,
    padding: t.padding
  }), /* @__PURE__ */ d.createElement(pV, t));
}
yV.displayName = "Brush";
function e1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Cs(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? e1(Object(r), !0).forEach(function(n) {
      fj(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : e1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function fj(e, t, r) {
  return (t = gV(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function gV(e) {
  var t = bV(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function bV(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var dj = (e, t) => {
  var {
    x: r,
    y: n
  } = e, {
    x: i,
    y: a
  } = t;
  return {
    x: Math.min(r, i),
    y: Math.min(n, a),
    width: Math.abs(i - r),
    height: Math.abs(a - n)
  };
}, xV = (e) => {
  var {
    x1: t,
    y1: r,
    x2: n,
    y2: i
  } = e;
  return dj({
    x: t,
    y: r
  }, {
    x: n,
    y: i
  });
};
class Xd {
  static create(t) {
    return new Xd(t);
  }
  constructor(t) {
    this.scale = t;
  }
  get domain() {
    return this.scale.domain;
  }
  get range() {
    return this.scale.range;
  }
  get rangeMin() {
    return this.range()[0];
  }
  get rangeMax() {
    return this.range()[1];
  }
  get bandwidth() {
    return this.scale.bandwidth;
  }
  apply(t) {
    var {
      bandAware: r,
      position: n
    } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    if (t !== void 0) {
      if (n)
        switch (n) {
          case "start":
            return this.scale(t);
          case "middle": {
            var i = this.bandwidth ? this.bandwidth() / 2 : 0;
            return this.scale(t) + i;
          }
          case "end": {
            var a = this.bandwidth ? this.bandwidth() : 0;
            return this.scale(t) + a;
          }
          default:
            return this.scale(t);
        }
      if (r) {
        var o = this.bandwidth ? this.bandwidth() / 2 : 0;
        return this.scale(t) + o;
      }
      return this.scale(t);
    }
  }
  isInRange(t) {
    var r = this.range(), n = r[0], i = r[r.length - 1];
    return n <= i ? t >= n && t <= i : t >= i && t <= n;
  }
}
fj(Xd, "EPS", 1e-4);
var e0 = (e) => {
  var t = Object.keys(e).reduce((r, n) => Cs(Cs({}, r), {}, {
    [n]: Xd.create(e[n])
  }), {});
  return Cs(Cs({}, t), {}, {
    apply(r) {
      var {
        bandAware: n,
        position: i
      } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      return Object.fromEntries(Object.entries(r).map((a) => {
        var [o, l] = a;
        return [o, t[o].apply(l, {
          bandAware: n,
          position: i
        })];
      }));
    },
    isInRange(r) {
      return Object.keys(r).every((n) => t[n].isInRange(r[n]));
    }
  });
};
function wV(e) {
  return (e % 180 + 180) % 180;
}
var PV = function(t) {
  var {
    width: r,
    height: n
  } = t, i = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0, a = wV(i), o = a * Math.PI / 180, l = Math.atan(n / r), u = o > l && o < Math.PI - l ? n / Math.sin(o) : r / Math.cos(o);
  return Math.abs(u);
}, OV = {
  dots: [],
  areas: [],
  lines: []
}, vj = Ut({
  name: "referenceElements",
  initialState: OV,
  reducers: {
    addDot: (e, t) => {
      e.dots.push(t.payload);
    },
    removeDot: (e, t) => {
      var r = Cr(e).dots.findIndex((n) => n === t.payload);
      r !== -1 && e.dots.splice(r, 1);
    },
    addArea: (e, t) => {
      e.areas.push(t.payload);
    },
    removeArea: (e, t) => {
      var r = Cr(e).areas.findIndex((n) => n === t.payload);
      r !== -1 && e.areas.splice(r, 1);
    },
    addLine: (e, t) => {
      e.lines.push(t.payload);
    },
    removeLine: (e, t) => {
      var r = Cr(e).lines.findIndex((n) => n === t.payload);
      r !== -1 && e.lines.splice(r, 1);
    }
  }
}), {
  addDot: SV,
  removeDot: EV,
  addArea: AV,
  removeArea: kV,
  addLine: _V,
  removeLine: IV
} = vj.actions, jV = vj.reducer, pj = /* @__PURE__ */ d.createContext(void 0), CV = (e) => {
  var {
    children: t
  } = e, [r] = d.useState("".concat(Ya("recharts"), "-clip")), n = Xu();
  if (n == null)
    return null;
  var {
    x: i,
    y: a,
    width: o,
    height: l
  } = n;
  return /* @__PURE__ */ d.createElement(pj.Provider, {
    value: r
  }, /* @__PURE__ */ d.createElement("defs", null, /* @__PURE__ */ d.createElement("clipPath", {
    id: r
  }, /* @__PURE__ */ d.createElement("rect", {
    x: i,
    y: a,
    height: l,
    width: o
  }))), t);
}, t0 = () => d.useContext(pj);
function t1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function r1(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? t1(Object(r), !0).forEach(function(n) {
      TV(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : t1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function TV(e, t, r) {
  return (t = MV(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function MV(e) {
  var t = DV(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function DV(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function gf() {
  return gf = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, gf.apply(null, arguments);
}
var NV = (e, t) => {
  var r;
  if (/* @__PURE__ */ d.isValidElement(e))
    r = /* @__PURE__ */ d.cloneElement(e, t);
  else if (typeof e == "function")
    r = e(t);
  else {
    if (!se(t.x1) || !se(t.y1) || !se(t.x2) || !se(t.y2))
      return null;
    r = /* @__PURE__ */ d.createElement("line", gf({}, t, {
      className: "recharts-reference-line-line"
    }));
  }
  return r;
}, $V = (e, t, r, n, i, a) => {
  var {
    x: o,
    width: l
  } = a, u = i.y.apply(e, {
    position: r
  });
  if (Pt(u) || t === "discard" && !i.y.isInRange(u))
    return null;
  var s = [{
    x: o + l,
    y: u
  }, {
    x: o,
    y: u
  }];
  return n === "left" ? s.reverse() : s;
}, LV = (e, t, r, n, i, a) => {
  var {
    y: o,
    height: l
  } = a, u = i.x.apply(e, {
    position: r
  });
  if (Pt(u) || t === "discard" && !i.x.isInRange(u))
    return null;
  var s = [{
    x: u,
    y: o + l
  }, {
    x: u,
    y: o
  }];
  return n === "top" ? s.reverse() : s;
}, RV = (e, t, r, n) => {
  var i = e.map((a) => n.apply(a, {
    position: r
  }));
  return t === "discard" && i.some((a) => !n.isInRange(a)) ? null : i;
}, zV = (e, t, r, n, i, a) => {
  var {
    x: o,
    y: l,
    segment: u,
    ifOverflow: s
  } = a, c = it(o), f = it(l);
  return f ? $V(l, s, r, i, e, t) : c ? LV(o, s, r, n, e, t) : u != null && u.length === 2 ? RV(u, s, r, e) : null;
};
function BV(e) {
  var t = J();
  return d.useEffect(() => (t(_V(e)), () => {
    t(IV(e));
  })), null;
}
function FV(e) {
  var {
    xAxisId: t,
    yAxisId: r,
    shape: n,
    className: i,
    ifOverflow: a
  } = e, o = me(), l = t0(), u = T((O) => rn(O, t)), s = T((O) => nn(O, r)), c = T((O) => Zr(O, "xAxis", t, o)), f = T((O) => Zr(O, "yAxis", r, o)), v = vo();
  if (!l || !v || u == null || s == null || c == null || f == null)
    return null;
  var p = e0({
    x: c,
    y: f
  }), h = zV(p, v, e.position, u.orientation, s.orientation, e);
  if (!h)
    return null;
  var [{
    x: y,
    y: g
  }, {
    x: m,
    y: b
  }] = h, x = a === "hidden" ? "url(#".concat(l, ")") : void 0, w = r1(r1({
    clipPath: x
  }, Ie(e)), {}, {
    x1: y,
    y1: g,
    x2: m,
    y2: b
  }), P = xV({
    x1: y,
    y1: g,
    x2: m,
    y2: b
  });
  return /* @__PURE__ */ d.createElement(pe, {
    zIndex: e.zIndex
  }, /* @__PURE__ */ d.createElement(U, {
    className: Y("recharts-reference-line", i)
  }, NV(n, w), /* @__PURE__ */ d.createElement($d, gf({}, P, {
    lowerWidth: P.width,
    upperWidth: P.width
  }), /* @__PURE__ */ d.createElement(Ld, {
    label: e.label
  }), e.children)));
}
var KV = {
  ifOverflow: "discard",
  xAxisId: 0,
  yAxisId: 0,
  fill: "none",
  stroke: "#ccc",
  fillOpacity: 1,
  strokeWidth: 1,
  position: "middle",
  zIndex: ie.line
};
function WV(e) {
  var t = ee(e, KV);
  return /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(BV, {
    yAxisId: t.yAxisId,
    xAxisId: t.xAxisId,
    ifOverflow: t.ifOverflow,
    x: t.x,
    y: t.y,
    segment: t.segment
  }), /* @__PURE__ */ d.createElement(FV, t));
}
WV.displayName = "ReferenceLine";
function n1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function i1(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? n1(Object(r), !0).forEach(function(n) {
      UV(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : n1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function UV(e, t, r) {
  return (t = VV(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function VV(e) {
  var t = HV(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function HV(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function Uh() {
  return Uh = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Uh.apply(null, arguments);
}
var XV = (e, t, r, n, i) => {
  var a = it(e), o = it(t), l = me(), u = T((v) => Zr(v, "xAxis", r, l)), s = T((v) => Zr(v, "yAxis", n, l));
  if (!a || !o || u == null || s == null)
    return null;
  var c = e0({
    x: u,
    y: s
  }), f = c.apply({
    x: e,
    y: t
  }, {
    bandAware: !0
  });
  return i === "discard" && !c.isInRange(f) ? null : f;
};
function YV(e) {
  var t = J();
  return d.useEffect(() => (t(SV(e)), () => {
    t(EV(e));
  })), null;
}
var GV = (e, t) => {
  var r;
  return /* @__PURE__ */ d.isValidElement(e) ? r = /* @__PURE__ */ d.cloneElement(e, t) : typeof e == "function" ? r = e(t) : r = /* @__PURE__ */ d.createElement(Rd, Uh({}, t, {
    cx: t.cx,
    cy: t.cy,
    className: "recharts-reference-dot-dot"
  })), r;
};
function qV(e) {
  var {
    x: t,
    y: r,
    r: n
  } = e, i = t0(), a = XV(t, r, e.xAxisId, e.yAxisId, e.ifOverflow);
  if (!a)
    return null;
  var {
    x: o,
    y: l
  } = a, {
    shape: u,
    className: s,
    ifOverflow: c
  } = e, f = c === "hidden" ? "url(#".concat(i, ")") : void 0, v = i1(i1({
    clipPath: f
  }, Ie(e)), {}, {
    cx: o,
    cy: l
  });
  return /* @__PURE__ */ d.createElement(pe, {
    zIndex: e.zIndex
  }, /* @__PURE__ */ d.createElement(U, {
    className: Y("recharts-reference-dot", s)
  }, GV(u, v), /* @__PURE__ */ d.createElement($d, {
    x: o - n,
    y: l - n,
    width: 2 * n,
    height: 2 * n,
    upperWidth: 2 * n,
    lowerWidth: 2 * n
  }, /* @__PURE__ */ d.createElement(Ld, {
    label: e.label
  }), e.children)));
}
var ZV = {
  ifOverflow: "discard",
  xAxisId: 0,
  yAxisId: 0,
  r: 10,
  fill: "#fff",
  stroke: "#ccc",
  fillOpacity: 1,
  strokeWidth: 1,
  zIndex: ie.scatter
};
function QV(e) {
  var t = ee(e, ZV), {
    x: r,
    y: n,
    r: i,
    ifOverflow: a,
    yAxisId: o,
    xAxisId: l
  } = t;
  return /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(YV, {
    y: n,
    x: r,
    r: i,
    yAxisId: o,
    xAxisId: l,
    ifOverflow: a
  }), /* @__PURE__ */ d.createElement(qV, t));
}
QV.displayName = "ReferenceDot";
function a1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function o1(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? a1(Object(r), !0).forEach(function(n) {
      JV(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : a1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function JV(e, t, r) {
  return (t = eH(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function eH(e) {
  var t = tH(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function tH(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function bf() {
  return bf = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, bf.apply(null, arguments);
}
var rH = (e, t, r, n, i, a, o) => {
  var {
    x1: l,
    x2: u,
    y1: s,
    y2: c
  } = o;
  if (i == null || a == null)
    return null;
  var f = e0({
    x: i,
    y: a
  }), v = {
    x: e ? f.x.apply(l, {
      position: "start"
    }) : f.x.rangeMin,
    y: r ? f.y.apply(s, {
      position: "start"
    }) : f.y.rangeMin
  }, p = {
    x: t ? f.x.apply(u, {
      position: "end"
    }) : f.x.rangeMax,
    y: n ? f.y.apply(c, {
      position: "end"
    }) : f.y.rangeMax
  };
  return o.ifOverflow === "discard" && (!f.isInRange(v) || !f.isInRange(p)) ? null : dj(v, p);
}, nH = (e, t) => {
  var r;
  return /* @__PURE__ */ d.isValidElement(e) ? r = /* @__PURE__ */ d.cloneElement(e, t) : typeof e == "function" ? r = e(t) : r = /* @__PURE__ */ d.createElement(Pu, bf({}, t, {
    className: "recharts-reference-area-rect"
  })), r;
};
function iH(e) {
  var t = J();
  return d.useEffect(() => (t(AV(e)), () => {
    t(kV(e));
  })), null;
}
function aH(e) {
  var {
    x1: t,
    x2: r,
    y1: n,
    y2: i,
    className: a,
    shape: o,
    xAxisId: l,
    yAxisId: u
  } = e, s = t0(), c = me(), f = T((w) => Zr(w, "xAxis", l, c)), v = T((w) => Zr(w, "yAxis", u, c));
  if (f == null || v == null)
    return null;
  var p = it(t), h = it(r), y = it(n), g = it(i);
  if (!p && !h && !y && !g && !o)
    return null;
  var m = rH(p, h, y, g, f, v, e);
  if (!m && !o)
    return null;
  var b = e.ifOverflow === "hidden", x = b ? "url(#".concat(s, ")") : void 0;
  return /* @__PURE__ */ d.createElement(pe, {
    zIndex: e.zIndex
  }, /* @__PURE__ */ d.createElement(U, {
    className: Y("recharts-reference-area", a)
  }, nH(o, o1(o1({
    clipPath: x
  }, Ie(e)), m)), m != null && /* @__PURE__ */ d.createElement($d, bf({}, m, {
    lowerWidth: m.width,
    upperWidth: m.width
  }), /* @__PURE__ */ d.createElement(Ld, {
    label: e.label
  }), e.children)));
}
var oH = {
  ifOverflow: "discard",
  xAxisId: 0,
  yAxisId: 0,
  radius: 0,
  fill: "#ccc",
  fillOpacity: 0.5,
  stroke: "none",
  strokeWidth: 1,
  zIndex: ie.area
};
function lH(e) {
  var t = ee(e, oH);
  return /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(iH, {
    yAxisId: t.yAxisId,
    xAxisId: t.xAxisId,
    ifOverflow: t.ifOverflow,
    x1: t.x1,
    x2: t.x2,
    y1: t.y1,
    y2: t.y2
  }), /* @__PURE__ */ d.createElement(aH, t));
}
lH.displayName = "ReferenceArea";
function hj(e, t) {
  if (t < 1)
    return [];
  if (t === 1)
    return e;
  for (var r = [], n = 0; n < e.length; n += t) {
    var i = e[n];
    i !== void 0 && r.push(i);
  }
  return r;
}
function uH(e, t, r) {
  var n = {
    width: e.width + t.width,
    height: e.height + t.height
  };
  return PV(n, r);
}
function sH(e, t, r) {
  var n = r === "width", {
    x: i,
    y: a,
    width: o,
    height: l
  } = e;
  return t === 1 ? {
    start: n ? i : a,
    end: n ? i + o : a + l
  } : {
    start: n ? i + o : a + l,
    end: n ? i : a
  };
}
function ql(e, t, r, n, i) {
  if (e * t < e * n || e * t > e * i)
    return !1;
  var a = r();
  return e * (t - e * a / 2 - n) >= 0 && e * (t + e * a / 2 - i) <= 0;
}
function cH(e, t) {
  return hj(e, t + 1);
}
function fH(e, t, r, n, i) {
  for (var a = (n || []).slice(), {
    start: o,
    end: l
  } = t, u = 0, s = 1, c = o, f = function() {
    var h = n == null ? void 0 : n[u];
    if (h === void 0)
      return {
        v: hj(n, s)
      };
    var y = u, g, m = () => (g === void 0 && (g = r(h, y)), g), b = h.coordinate, x = u === 0 || ql(e, b, m, c, l);
    x || (u = 0, c = o, s += 1), x && (c = b + e * (m() / 2 + i), u += s);
  }, v; s <= a.length; )
    if (v = f(), v) return v.v;
  return [];
}
function dH(e, t, r, n, i) {
  var a = (n || []).slice(), o = a.length;
  if (o === 0)
    return [];
  for (var {
    start: l,
    end: u
  } = t, s = 1; s <= o; s++) {
    for (var c = (o - 1) % s, f = l, v = !0, p = function() {
      var b = n[h], x = h, w, P = () => (w === void 0 && (w = r(b, x)), w), O = b.coordinate, S = h === c || ql(e, O, P, f, u);
      if (!S)
        return v = !1, 1;
      S && (f = O + e * (P() / 2 + i));
    }, h = c; h < o && !p(); h += s)
      ;
    if (v) {
      for (var y = [], g = c; g < o; g += s)
        y.push(n[g]);
      return y;
    }
  }
  return [];
}
function l1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function mt(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? l1(Object(r), !0).forEach(function(n) {
      vH(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : l1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function vH(e, t, r) {
  return (t = pH(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function pH(e) {
  var t = hH(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function hH(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function mH(e, t, r, n, i) {
  for (var a = (n || []).slice(), o = a.length, {
    start: l
  } = t, {
    end: u
  } = t, s = function(v) {
    var p = a[v], h, y = () => (h === void 0 && (h = r(p, v)), h);
    if (v === o - 1) {
      var g = e * (p.coordinate + e * y() / 2 - u);
      a[v] = p = mt(mt({}, p), {}, {
        tickCoord: g > 0 ? p.coordinate - g * e : p.coordinate
      });
    } else
      a[v] = p = mt(mt({}, p), {}, {
        tickCoord: p.coordinate
      });
    if (p.tickCoord != null) {
      var m = ql(e, p.tickCoord, y, l, u);
      m && (u = p.tickCoord - e * (y() / 2 + i), a[v] = mt(mt({}, p), {}, {
        isShow: !0
      }));
    }
  }, c = o - 1; c >= 0; c--)
    s(c);
  return a;
}
function yH(e, t, r, n, i, a) {
  var o = (n || []).slice(), l = o.length, {
    start: u,
    end: s
  } = t;
  if (a) {
    var c = n[l - 1], f = r(c, l - 1), v = e * (c.coordinate + e * f / 2 - s);
    if (o[l - 1] = c = mt(mt({}, c), {}, {
      tickCoord: v > 0 ? c.coordinate - v * e : c.coordinate
    }), c.tickCoord != null) {
      var p = ql(e, c.tickCoord, () => f, u, s);
      p && (s = c.tickCoord - e * (f / 2 + i), o[l - 1] = mt(mt({}, c), {}, {
        isShow: !0
      }));
    }
  }
  for (var h = a ? l - 1 : l, y = function(b) {
    var x = o[b], w, P = () => (w === void 0 && (w = r(x, b)), w);
    if (b === 0) {
      var O = e * (x.coordinate - e * P() / 2 - u);
      o[b] = x = mt(mt({}, x), {}, {
        tickCoord: O < 0 ? x.coordinate - O * e : x.coordinate
      });
    } else
      o[b] = x = mt(mt({}, x), {}, {
        tickCoord: x.coordinate
      });
    if (x.tickCoord != null) {
      var S = ql(e, x.tickCoord, P, u, s);
      S && (u = x.tickCoord + e * (P() / 2 + i), o[b] = mt(mt({}, x), {}, {
        isShow: !0
      }));
    }
  }, g = 0; g < h; g++)
    y(g);
  return o;
}
function r0(e, t, r) {
  var {
    tick: n,
    ticks: i,
    viewBox: a,
    minTickGap: o,
    orientation: l,
    interval: u,
    tickFormatter: s,
    unit: c,
    angle: f
  } = e;
  if (!i || !i.length || !n)
    return [];
  if (B(u) || po.isSsr) {
    var v;
    return (v = cH(i, B(u) ? u : 0)) !== null && v !== void 0 ? v : [];
  }
  var p = [], h = l === "top" || l === "bottom" ? "width" : "height", y = c && h === "width" ? Ba(c, {
    fontSize: t,
    letterSpacing: r
  }) : {
    width: 0,
    height: 0
  }, g = (x, w) => {
    var P = typeof s == "function" ? s(x.value, w) : x.value;
    return h === "width" ? uH(Ba(P, {
      fontSize: t,
      letterSpacing: r
    }), y, f) : Ba(P, {
      fontSize: t,
      letterSpacing: r
    })[h];
  }, m = i.length >= 2 ? We(i[1].coordinate - i[0].coordinate) : 1, b = sH(a, m, h);
  return u === "equidistantPreserveStart" ? fH(m, b, g, i, o) : u === "equidistantPreserveEnd" ? dH(m, b, g, i, o) : (u === "preserveStart" || u === "preserveStartEnd" ? p = yH(m, b, g, i, o, u === "preserveStartEnd") : p = mH(m, b, g, i, o), p.filter((x) => x.isShow));
}
var gH = (e) => {
  var {
    ticks: t,
    label: r,
    labelGapWithTick: n = 5,
    // Default gap between label and tick
    tickSize: i = 0,
    tickMargin: a = 0
  } = e, o = 0;
  if (t) {
    Array.from(t).forEach((c) => {
      if (c) {
        var f = c.getBoundingClientRect();
        f.width > o && (o = f.width);
      }
    });
    var l = r ? r.getBoundingClientRect().width : 0, u = i + a, s = o + u + l + (r ? n : 0);
    return Math.round(s);
  }
  return 0;
}, bH = ["axisLine", "width", "height", "className", "hide", "ticks", "axisType"];
function xH(e, t) {
  if (e == null) return {};
  var r, n, i = wH(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function wH(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function ea() {
  return ea = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, ea.apply(null, arguments);
}
function u1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Fe(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? u1(Object(r), !0).forEach(function(n) {
      PH(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : u1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function PH(e, t, r) {
  return (t = OH(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function OH(e) {
  var t = SH(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function SH(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var Pn = {
  x: 0,
  y: 0,
  width: 0,
  height: 0,
  viewBox: {
    x: 0,
    y: 0,
    width: 0,
    height: 0
  },
  // The orientation of axis
  orientation: "bottom",
  // The ticks
  ticks: [],
  stroke: "#666",
  tickLine: !0,
  axisLine: !0,
  tick: !0,
  mirror: !1,
  minTickGap: 5,
  // The width or height of tick
  tickSize: 6,
  tickMargin: 2,
  interval: "preserveEnd",
  zIndex: ie.axis
};
function EH(e) {
  var {
    x: t,
    y: r,
    width: n,
    height: i,
    orientation: a,
    mirror: o,
    axisLine: l,
    otherSvgProps: u
  } = e;
  if (!l)
    return null;
  var s = Fe(Fe(Fe({}, u), re(l)), {}, {
    fill: "none"
  });
  if (a === "top" || a === "bottom") {
    var c = +(a === "top" && !o || a === "bottom" && o);
    s = Fe(Fe({}, s), {}, {
      x1: t,
      y1: r + c * i,
      x2: t + n,
      y2: r + c * i
    });
  } else {
    var f = +(a === "left" && !o || a === "right" && o);
    s = Fe(Fe({}, s), {}, {
      x1: t + f * n,
      y1: r,
      x2: t + f * n,
      y2: r + i
    });
  }
  return /* @__PURE__ */ d.createElement("line", ea({}, s, {
    className: Y("recharts-cartesian-axis-line", Gr(l, "className"))
  }));
}
function AH(e, t, r, n, i, a, o, l, u) {
  var s, c, f, v, p, h, y = l ? -1 : 1, g = e.tickSize || o, m = B(e.tickCoord) ? e.tickCoord : e.coordinate;
  switch (a) {
    case "top":
      s = c = e.coordinate, v = r + +!l * i, f = v - y * g, h = f - y * u, p = m;
      break;
    case "left":
      f = v = e.coordinate, c = t + +!l * n, s = c - y * g, p = s - y * u, h = m;
      break;
    case "right":
      f = v = e.coordinate, c = t + +l * n, s = c + y * g, p = s + y * u, h = m;
      break;
    default:
      s = c = e.coordinate, v = r + +l * i, f = v + y * g, h = f + y * u, p = m;
      break;
  }
  return {
    line: {
      x1: s,
      y1: f,
      x2: c,
      y2: v
    },
    tick: {
      x: p,
      y: h
    }
  };
}
function kH(e, t) {
  switch (e) {
    case "left":
      return t ? "start" : "end";
    case "right":
      return t ? "end" : "start";
    default:
      return "middle";
  }
}
function _H(e, t) {
  switch (e) {
    case "left":
    case "right":
      return "middle";
    case "top":
      return t ? "start" : "end";
    default:
      return t ? "end" : "start";
  }
}
function IH(e) {
  var {
    option: t,
    tickProps: r,
    value: n
  } = e, i, a = Y(r.className, "recharts-cartesian-axis-tick-value");
  if (/* @__PURE__ */ d.isValidElement(t))
    i = /* @__PURE__ */ d.cloneElement(t, Fe(Fe({}, r), {}, {
      className: a
    }));
  else if (typeof t == "function")
    i = t(Fe(Fe({}, r), {}, {
      className: a
    }));
  else {
    var o = "recharts-cartesian-axis-tick-value";
    typeof t != "boolean" && (o = Y(o, t == null ? void 0 : t.className)), i = /* @__PURE__ */ d.createElement(ci, ea({}, r, {
      className: o
    }), n);
  }
  return i;
}
var jH = /* @__PURE__ */ d.forwardRef((e, t) => {
  var {
    ticks: r = [],
    tick: n,
    tickLine: i,
    stroke: a,
    tickFormatter: o,
    unit: l,
    padding: u,
    tickTextProps: s,
    orientation: c,
    mirror: f,
    x: v,
    y: p,
    width: h,
    height: y,
    tickSize: g,
    tickMargin: m,
    fontSize: b,
    letterSpacing: x,
    getTicksConfig: w,
    events: P,
    axisType: O
  } = e, S = r0(Fe(Fe({}, w), {}, {
    ticks: r
  }), b, x), E = kH(c, f), k = _H(c, f), _ = re(w), I = er(n), j = {};
  typeof i == "object" && (j = i);
  var z = Fe(Fe({}, _), {}, {
    fill: "none"
  }, j), N = S.map((H) => Fe({
    entry: H
  }, AH(H, v, p, h, y, c, g, f, m))), R = N.map((H) => {
    var {
      entry: C,
      line: D
    } = H;
    return /* @__PURE__ */ d.createElement(U, {
      className: "recharts-cartesian-axis-tick",
      key: "tick-".concat(C.value, "-").concat(C.coordinate, "-").concat(C.tickCoord)
    }, i && /* @__PURE__ */ d.createElement("line", ea({}, z, D, {
      className: Y("recharts-cartesian-axis-tick-line", Gr(i, "className"))
    })));
  }), V = N.map((H, C) => {
    var {
      entry: D,
      tick: F
    } = H, Z = Fe(Fe(Fe(Fe({
      // @ts-expect-error textAnchor from axisProps is typed as `string` but Text wants type `TextAnchor`
      textAnchor: E,
      verticalAnchor: k
    }, _), {}, {
      // @ts-expect-error customTickProps is contributing unknown props
      stroke: "none",
      // @ts-expect-error customTickProps is contributing unknown props
      fill: a
    }, I), F), {}, {
      index: C,
      payload: D,
      visibleTicksCount: S.length,
      tickFormatter: o,
      padding: u
    }, s);
    return /* @__PURE__ */ d.createElement(U, ea({
      className: "recharts-cartesian-axis-tick-label",
      key: "tick-label-".concat(D.value, "-").concat(D.coordinate, "-").concat(D.tickCoord)
    }, Nr(P, D, C)), n && /* @__PURE__ */ d.createElement(IH, {
      option: n,
      tickProps: Z,
      value: "".concat(typeof o == "function" ? o(D.value, C) : D.value).concat(l || "")
    }));
  });
  return /* @__PURE__ */ d.createElement("g", {
    className: "recharts-cartesian-axis-ticks recharts-".concat(O, "-ticks")
  }, V.length > 0 && /* @__PURE__ */ d.createElement(pe, {
    zIndex: ie.label
  }, /* @__PURE__ */ d.createElement("g", {
    className: "recharts-cartesian-axis-tick-labels recharts-".concat(O, "-tick-labels"),
    ref: t
  }, V)), R.length > 0 && /* @__PURE__ */ d.createElement("g", {
    className: "recharts-cartesian-axis-tick-lines recharts-".concat(O, "-tick-lines")
  }, R));
}), CH = /* @__PURE__ */ d.forwardRef((e, t) => {
  var {
    axisLine: r,
    width: n,
    height: i,
    className: a,
    hide: o,
    ticks: l,
    axisType: u
  } = e, s = xH(e, bH), [c, f] = d.useState(""), [v, p] = d.useState(""), h = d.useRef(null);
  d.useImperativeHandle(t, () => ({
    getCalculatedWidth: () => {
      var g;
      return gH({
        ticks: h.current,
        label: (g = e.labelRef) === null || g === void 0 ? void 0 : g.current,
        labelGapWithTick: 5,
        tickSize: e.tickSize,
        tickMargin: e.tickMargin
      });
    }
  }));
  var y = d.useCallback((g) => {
    if (g) {
      var m = g.getElementsByClassName("recharts-cartesian-axis-tick-value");
      h.current = m;
      var b = m[0];
      if (b) {
        var x = window.getComputedStyle(b), w = x.fontSize, P = x.letterSpacing;
        (w !== c || P !== v) && (f(w), p(P));
      }
    }
  }, [c, v]);
  return o || n != null && n <= 0 || i != null && i <= 0 ? null : /* @__PURE__ */ d.createElement(pe, {
    zIndex: e.zIndex
  }, /* @__PURE__ */ d.createElement(U, {
    className: Y("recharts-cartesian-axis", a)
  }, /* @__PURE__ */ d.createElement(EH, {
    x: e.x,
    y: e.y,
    width: n,
    height: i,
    orientation: e.orientation,
    mirror: e.mirror,
    axisLine: r,
    otherSvgProps: re(e)
  }), /* @__PURE__ */ d.createElement(jH, {
    ref: y,
    axisType: u,
    events: s,
    fontSize: c,
    getTicksConfig: e,
    height: e.height,
    letterSpacing: v,
    mirror: e.mirror,
    orientation: e.orientation,
    padding: e.padding,
    stroke: e.stroke,
    tick: e.tick,
    tickFormatter: e.tickFormatter,
    tickLine: e.tickLine,
    tickMargin: e.tickMargin,
    tickSize: e.tickSize,
    tickTextProps: e.tickTextProps,
    ticks: l,
    unit: e.unit,
    width: e.width,
    x: e.x,
    y: e.y
  }), /* @__PURE__ */ d.createElement($d, {
    x: e.x,
    y: e.y,
    width: e.width,
    height: e.height,
    lowerWidth: e.width,
    upperWidth: e.width
  }, /* @__PURE__ */ d.createElement(Ld, {
    label: e.label,
    labelRef: e.labelRef
  }), e.children)));
}), n0 = /* @__PURE__ */ d.forwardRef((e, t) => {
  var r = ee(e, Pn);
  return /* @__PURE__ */ d.createElement(CH, ea({}, r, {
    ref: t
  }));
});
n0.displayName = "CartesianAxis";
var TH = ["x1", "y1", "x2", "y2", "key"], MH = ["offset"], DH = ["xAxisId", "yAxisId"], NH = ["xAxisId", "yAxisId"];
function s1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function bt(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? s1(Object(r), !0).forEach(function(n) {
      $H(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : s1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function $H(e, t, r) {
  return (t = LH(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function LH(e) {
  var t = RH(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function RH(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function Di() {
  return Di = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Di.apply(null, arguments);
}
function xf(e, t) {
  if (e == null) return {};
  var r, n, i = zH(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function zH(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
var BH = (e) => {
  var {
    fill: t
  } = e;
  if (!t || t === "none")
    return null;
  var {
    fillOpacity: r,
    x: n,
    y: i,
    width: a,
    height: o,
    ry: l
  } = e;
  return /* @__PURE__ */ d.createElement("rect", {
    x: n,
    y: i,
    ry: l,
    width: a,
    height: o,
    stroke: "none",
    fill: t,
    fillOpacity: r,
    className: "recharts-cartesian-grid-bg"
  });
};
function mj(e) {
  var {
    option: t,
    lineItemProps: r
  } = e, n;
  if (/* @__PURE__ */ d.isValidElement(t))
    n = /* @__PURE__ */ d.cloneElement(t, r);
  else if (typeof t == "function")
    n = t(r);
  else {
    var i, {
      x1: a,
      y1: o,
      x2: l,
      y2: u,
      key: s
    } = r, c = xf(r, TH), f = (i = re(c)) !== null && i !== void 0 ? i : {}, {
      offset: v
    } = f, p = xf(f, MH);
    n = /* @__PURE__ */ d.createElement("line", Di({}, p, {
      x1: a,
      y1: o,
      x2: l,
      y2: u,
      fill: "none",
      key: s
    }));
  }
  return n;
}
function FH(e) {
  var {
    x: t,
    width: r,
    horizontal: n = !0,
    horizontalPoints: i
  } = e;
  if (!n || !i || !i.length)
    return null;
  var {
    xAxisId: a,
    yAxisId: o
  } = e, l = xf(e, DH), u = i.map((s, c) => {
    var f = bt(bt({}, l), {}, {
      x1: t,
      y1: s,
      x2: t + r,
      y2: s,
      key: "line-".concat(c),
      index: c
    });
    return /* @__PURE__ */ d.createElement(mj, {
      key: "line-".concat(c),
      option: n,
      lineItemProps: f
    });
  });
  return /* @__PURE__ */ d.createElement("g", {
    className: "recharts-cartesian-grid-horizontal"
  }, u);
}
function KH(e) {
  var {
    y: t,
    height: r,
    vertical: n = !0,
    verticalPoints: i
  } = e;
  if (!n || !i || !i.length)
    return null;
  var {
    xAxisId: a,
    yAxisId: o
  } = e, l = xf(e, NH), u = i.map((s, c) => {
    var f = bt(bt({}, l), {}, {
      x1: s,
      y1: t,
      x2: s,
      y2: t + r,
      key: "line-".concat(c),
      index: c
    });
    return /* @__PURE__ */ d.createElement(mj, {
      option: n,
      lineItemProps: f,
      key: "line-".concat(c)
    });
  });
  return /* @__PURE__ */ d.createElement("g", {
    className: "recharts-cartesian-grid-vertical"
  }, u);
}
function WH(e) {
  var {
    horizontalFill: t,
    fillOpacity: r,
    x: n,
    y: i,
    width: a,
    height: o,
    horizontalPoints: l,
    horizontal: u = !0
  } = e;
  if (!u || !t || !t.length || l == null)
    return null;
  var s = l.map((f) => Math.round(f + i - i)).sort((f, v) => f - v);
  i !== s[0] && s.unshift(0);
  var c = s.map((f, v) => {
    var p = !s[v + 1], h = p ? i + o - f : s[v + 1] - f;
    if (h <= 0)
      return null;
    var y = v % t.length;
    return /* @__PURE__ */ d.createElement("rect", {
      key: "react-".concat(v),
      y: f,
      x: n,
      height: h,
      width: a,
      stroke: "none",
      fill: t[y],
      fillOpacity: r,
      className: "recharts-cartesian-grid-bg"
    });
  });
  return /* @__PURE__ */ d.createElement("g", {
    className: "recharts-cartesian-gridstripes-horizontal"
  }, c);
}
function UH(e) {
  var {
    vertical: t = !0,
    verticalFill: r,
    fillOpacity: n,
    x: i,
    y: a,
    width: o,
    height: l,
    verticalPoints: u
  } = e;
  if (!t || !r || !r.length)
    return null;
  var s = u.map((f) => Math.round(f + i - i)).sort((f, v) => f - v);
  i !== s[0] && s.unshift(0);
  var c = s.map((f, v) => {
    var p = !s[v + 1], h = p ? i + o - f : s[v + 1] - f;
    if (h <= 0)
      return null;
    var y = v % r.length;
    return /* @__PURE__ */ d.createElement("rect", {
      key: "react-".concat(v),
      x: f,
      y: a,
      width: h,
      height: l,
      stroke: "none",
      fill: r[y],
      fillOpacity: n,
      className: "recharts-cartesian-grid-bg"
    });
  });
  return /* @__PURE__ */ d.createElement("g", {
    className: "recharts-cartesian-gridstripes-vertical"
  }, c);
}
var VH = (e, t) => {
  var {
    xAxis: r,
    width: n,
    height: i,
    offset: a
  } = e;
  return SA(r0(bt(bt(bt({}, Pn), r), {}, {
    ticks: EA(r),
    viewBox: {
      x: 0,
      y: 0,
      width: n,
      height: i
    }
  })), a.left, a.left + a.width, t);
}, HH = (e, t) => {
  var {
    yAxis: r,
    width: n,
    height: i,
    offset: a
  } = e;
  return SA(r0(bt(bt(bt({}, Pn), r), {}, {
    ticks: EA(r),
    viewBox: {
      x: 0,
      y: 0,
      width: n,
      height: i
    }
  })), a.top, a.top + a.height, t);
}, XH = {
  horizontal: !0,
  vertical: !0,
  // The ordinates of horizontal grid lines
  horizontalPoints: [],
  // The abscissas of vertical grid lines
  verticalPoints: [],
  stroke: "#ccc",
  fill: "none",
  // The fill of colors of grid lines
  verticalFill: [],
  horizontalFill: [],
  xAxisId: 0,
  yAxisId: 0,
  syncWithTicks: !1,
  zIndex: ie.grid
};
function YH(e) {
  var t = gu(), r = bu(), n = LA(), i = bt(bt({}, ee(e, XH)), {}, {
    x: B(e.x) ? e.x : n.left,
    y: B(e.y) ? e.y : n.top,
    width: B(e.width) ? e.width : n.width,
    height: B(e.height) ? e.height : n.height
  }), {
    xAxisId: a,
    yAxisId: o,
    x: l,
    y: u,
    width: s,
    height: c,
    syncWithTicks: f,
    horizontalValues: v,
    verticalValues: p
  } = i, h = me(), y = T((k) => $w(k, "xAxis", a, h)), g = T((k) => $w(k, "yAxis", o, h));
  if (!Bt(s) || !Bt(c) || !B(l) || !B(u))
    return null;
  var m = i.verticalCoordinatesGenerator || VH, b = i.horizontalCoordinatesGenerator || HH, {
    horizontalPoints: x,
    verticalPoints: w
  } = i;
  if ((!x || !x.length) && typeof b == "function") {
    var P = v && v.length, O = b({
      yAxis: g ? bt(bt({}, g), {}, {
        ticks: P ? v : g.ticks
      }) : void 0,
      width: t ?? s,
      height: r ?? c,
      offset: n
    }, P ? !0 : f);
    zc(Array.isArray(O), "horizontalCoordinatesGenerator should return Array but instead it returned [".concat(typeof O, "]")), Array.isArray(O) && (x = O);
  }
  if ((!w || !w.length) && typeof m == "function") {
    var S = p && p.length, E = m({
      xAxis: y ? bt(bt({}, y), {}, {
        ticks: S ? p : y.ticks
      }) : void 0,
      width: t ?? s,
      height: r ?? c,
      offset: n
    }, S ? !0 : f);
    zc(Array.isArray(E), "verticalCoordinatesGenerator should return Array but instead it returned [".concat(typeof E, "]")), Array.isArray(E) && (w = E);
  }
  return /* @__PURE__ */ d.createElement(pe, {
    zIndex: i.zIndex
  }, /* @__PURE__ */ d.createElement("g", {
    className: "recharts-cartesian-grid"
  }, /* @__PURE__ */ d.createElement(BH, {
    fill: i.fill,
    fillOpacity: i.fillOpacity,
    x: i.x,
    y: i.y,
    width: i.width,
    height: i.height,
    ry: i.ry
  }), /* @__PURE__ */ d.createElement(WH, Di({}, i, {
    horizontalPoints: x
  })), /* @__PURE__ */ d.createElement(UH, Di({}, i, {
    verticalPoints: w
  })), /* @__PURE__ */ d.createElement(FH, Di({}, i, {
    offset: n,
    horizontalPoints: x,
    xAxis: y,
    yAxis: g
  })), /* @__PURE__ */ d.createElement(KH, Di({}, i, {
    offset: n,
    verticalPoints: w,
    xAxis: y,
    yAxis: g
  }))));
}
YH.displayName = "CartesianGrid";
var GH = {}, yj = Ut({
  name: "errorBars",
  initialState: GH,
  reducers: {
    addErrorBar: (e, t) => {
      var {
        itemId: r,
        errorBar: n
      } = t.payload;
      e[r] || (e[r] = []), e[r].push(n);
    },
    replaceErrorBar: (e, t) => {
      var {
        itemId: r,
        prev: n,
        next: i
      } = t.payload;
      e[r] && (e[r] = e[r].map((a) => a.dataKey === n.dataKey && a.direction === n.direction ? i : a));
    },
    removeErrorBar: (e, t) => {
      var {
        itemId: r,
        errorBar: n
      } = t.payload;
      e[r] && (e[r] = e[r].filter((i) => i.dataKey !== n.dataKey || i.direction !== n.direction));
    }
  }
}), {
  addErrorBar: qH,
  replaceErrorBar: ZH,
  removeErrorBar: QH
} = yj.actions, JH = yj.reducer, e9 = ["children"];
function t9(e, t) {
  if (e == null) return {};
  var r, n, i = r9(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function r9(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
var n9 = {
  data: [],
  xAxisId: "xAxis-0",
  yAxisId: "yAxis-0",
  dataPointFormatter: () => ({
    x: 0,
    y: 0,
    value: 0
  }),
  errorBarOffset: 0
}, gj = /* @__PURE__ */ d.createContext(n9);
function i0(e) {
  var {
    children: t
  } = e, r = t9(e, e9);
  return /* @__PURE__ */ d.createElement(gj.Provider, {
    value: r
  }, t);
}
var i9 = () => d.useContext(gj);
function a9(e) {
  var t = J(), r = d6(), n = d.useRef(null);
  return d.useEffect(() => {
    r != null && (n.current === null ? t(qH({
      itemId: r,
      errorBar: e
    })) : n.current !== e && t(ZH({
      itemId: r,
      prev: n.current,
      next: e
    })), n.current = e);
  }, [t, r, e]), d.useEffect(() => () => {
    n.current != null && r != null && (t(QH({
      itemId: r,
      errorBar: n.current
    })), n.current = null);
  }, [t, r]), null;
}
function Yu(e, t) {
  var r, n, i = T((s) => rn(s, e)), a = T((s) => nn(s, t)), o = (r = i == null ? void 0 : i.allowDataOverflow) !== null && r !== void 0 ? r : et.allowDataOverflow, l = (n = a == null ? void 0 : a.allowDataOverflow) !== null && n !== void 0 ? n : tt.allowDataOverflow, u = o || l;
  return {
    needClip: u,
    needClipX: o,
    needClipY: l
  };
}
function Yd(e) {
  var {
    xAxisId: t,
    yAxisId: r,
    clipPathId: n
  } = e, i = Xu(), {
    needClipX: a,
    needClipY: o,
    needClip: l
  } = Yu(t, r);
  if (!l || !i)
    return null;
  var {
    x: u,
    y: s,
    width: c,
    height: f
  } = i;
  return /* @__PURE__ */ d.createElement("clipPath", {
    id: "clipPath-".concat(n)
  }, /* @__PURE__ */ d.createElement("rect", {
    x: a ? u : u - c / 2,
    y: o ? s : s - f / 2,
    width: a ? c : c * 2,
    height: o ? f : f * 2
  }));
}
var bj = (e, t, r, n) => Kt(e, "xAxis", t, n), xj = (e, t, r, n) => gr(e, "xAxis", t, n), wj = (e, t, r, n) => Kt(e, "yAxis", r, n), Pj = (e, t, r, n) => gr(e, "yAxis", r, n), o9 = A([q, bj, wj, xj, Pj], (e, t, r, n, i) => br(e, "xAxis") ? Ft(t, n, !1) : Ft(r, i, !1)), l9 = (e, t, r, n, i) => i;
function u9(e) {
  return e.type === "line";
}
var s9 = A([Po, l9], (e, t) => e.filter(u9).find((r) => r.id === t)), c9 = A([q, bj, wj, xj, Pj, s9, o9, bd], (e, t, r, n, i, a, o, l) => {
  var {
    chartData: u,
    dataStartIndex: s,
    dataEndIndex: c
  } = l;
  if (!(a == null || t == null || r == null || n == null || i == null || n.length === 0 || i.length === 0 || o == null || e !== "horizontal" && e !== "vertical")) {
    var {
      dataKey: f,
      data: v
    } = a, p;
    if (v != null && v.length > 0 ? p = v : p = u == null ? void 0 : u.slice(s, c + 1), p != null)
      return e7({
        layout: e,
        xAxis: t,
        yAxis: r,
        xAxisTicks: n,
        yAxisTicks: i,
        dataKey: f,
        bandSize: o,
        displayedData: p
      });
  }
});
function Oj(e) {
  var t = er(e), r = 3, n = 2;
  if (t != null) {
    var {
      r: i,
      strokeWidth: a
    } = t, o = Number(i), l = Number(a);
    return (Number.isNaN(o) || o < 0) && (o = r), (Number.isNaN(l) || l < 0) && (l = n), {
      r: o,
      strokeWidth: l
    };
  }
  return {
    r,
    strokeWidth: n
  };
}
var f9 = {};
/**
 * @license React
 * use-sync-external-store-with-selector.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Gu = d;
function d9(e, t) {
  return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t;
}
var v9 = typeof Object.is == "function" ? Object.is : d9, p9 = Gu.useSyncExternalStore, h9 = Gu.useRef, m9 = Gu.useEffect, y9 = Gu.useMemo, g9 = Gu.useDebugValue;
f9.useSyncExternalStoreWithSelector = function(e, t, r, n, i) {
  var a = h9(null);
  if (a.current === null) {
    var o = { hasValue: !1, value: null };
    a.current = o;
  } else o = a.current;
  a = y9(
    function() {
      function u(p) {
        if (!s) {
          if (s = !0, c = p, p = n(p), i !== void 0 && o.hasValue) {
            var h = o.value;
            if (i(h, p))
              return f = h;
          }
          return f = p;
        }
        if (h = f, v9(c, p)) return h;
        var y = n(p);
        return i !== void 0 && i(h, y) ? (c = p, h) : (c = p, f = y);
      }
      var s = !1, c, f, v = r === void 0 ? null : r;
      return [
        function() {
          return u(t());
        },
        v === null ? void 0 : function() {
          return u(v());
        }
      ];
    },
    [t, r, n, i]
  );
  var l = p9(e, a[0], a[1]);
  return m9(
    function() {
      o.hasValue = !0, o.value = l;
    },
    [l]
  ), g9(l), l;
};
function b9(e) {
  e();
}
function x9() {
  let e = null, t = null;
  return {
    clear() {
      e = null, t = null;
    },
    notify() {
      b9(() => {
        let r = e;
        for (; r; )
          r.callback(), r = r.next;
      });
    },
    get() {
      const r = [];
      let n = e;
      for (; n; )
        r.push(n), n = n.next;
      return r;
    },
    subscribe(r) {
      let n = !0;
      const i = t = {
        callback: r,
        next: null,
        prev: t
      };
      return i.prev ? i.prev.next = i : e = i, function() {
        !n || e === null || (n = !1, i.next ? i.next.prev = i.prev : t = i.prev, i.prev ? i.prev.next = i.next : e = i.next);
      };
    }
  };
}
var c1 = {
  notify() {
  },
  get: () => []
};
function w9(e, t) {
  let r, n = c1, i = 0, a = !1;
  function o(y) {
    c();
    const g = n.subscribe(y);
    let m = !1;
    return () => {
      m || (m = !0, g(), f());
    };
  }
  function l() {
    n.notify();
  }
  function u() {
    h.onStateChange && h.onStateChange();
  }
  function s() {
    return a;
  }
  function c() {
    i++, r || (r = e.subscribe(u), n = x9());
  }
  function f() {
    i--, r && i === 0 && (r(), r = void 0, n.clear(), n = c1);
  }
  function v() {
    a || (a = !0, c());
  }
  function p() {
    a && (a = !1, f());
  }
  const h = {
    addNestedSub: o,
    notifyNestedSubs: l,
    handleChangeWrapper: u,
    isSubscribed: s,
    trySubscribe: v,
    tryUnsubscribe: p,
    getListeners: () => n
  };
  return h;
}
var P9 = () => typeof window < "u" && typeof window.document < "u" && typeof window.document.createElement < "u", O9 = /* @__PURE__ */ P9(), S9 = () => typeof navigator < "u" && navigator.product === "ReactNative", E9 = /* @__PURE__ */ S9(), A9 = () => O9 || E9 ? d.useLayoutEffect : d.useEffect, k9 = /* @__PURE__ */ A9();
function f1(e, t) {
  return e === t ? e !== 0 || t !== 0 || 1 / e === 1 / t : e !== e && t !== t;
}
function _9(e, t) {
  if (f1(e, t)) return !0;
  if (typeof e != "object" || e === null || typeof t != "object" || t === null)
    return !1;
  const r = Object.keys(e), n = Object.keys(t);
  if (r.length !== n.length) return !1;
  for (let i = 0; i < r.length; i++)
    if (!Object.prototype.hasOwnProperty.call(t, r[i]) || !f1(e[r[i]], t[r[i]]))
      return !1;
  return !0;
}
var Gv = /* @__PURE__ */ Symbol.for("react-redux-context"), qv = typeof globalThis < "u" ? globalThis : (
  /* fall back to a per-module scope (pre-8.1 behaviour) if `globalThis` is not available */
  {}
);
function I9() {
  if (!d.createContext) return {};
  const e = qv[Gv] ?? (qv[Gv] = /* @__PURE__ */ new Map());
  let t = e.get(d.createContext);
  return t || (t = d.createContext(
    null
  ), e.set(d.createContext, t)), t;
}
var j9 = /* @__PURE__ */ I9();
function C9(e) {
  const { children: t, context: r, serverState: n, store: i } = e, a = d.useMemo(() => {
    const u = w9(i);
    return {
      store: i,
      subscription: u,
      getServerState: n ? () => n : void 0
    };
  }, [i, n]), o = d.useMemo(() => i.getState(), [i]);
  k9(() => {
    const { subscription: u } = a;
    return u.onStateChange = u.notifyNestedSubs, u.trySubscribe(), o !== i.getState() && u.notifyNestedSubs(), () => {
      u.tryUnsubscribe(), u.onStateChange = void 0;
    };
  }, [a, o]);
  const l = r || j9;
  return /* @__PURE__ */ d.createElement(l.Provider, { value: a }, t);
}
var T9 = C9, M9 = /* @__PURE__ */ new Set([
  "axisLine",
  "tickLine",
  "activeBar",
  "activeDot",
  "activeLabel",
  "activeShape",
  "allowEscapeViewBox",
  "background",
  "cursor",
  "dot",
  "label",
  "line",
  "margin",
  "padding",
  "position",
  "shape",
  "style",
  "tick",
  "wrapperStyle",
  // radius can be an array of 4 numbers, easy to compare shallowly
  "radius"
]);
function D9(e, t) {
  return e == null && t == null ? !0 : typeof e == "number" && typeof t == "number" ? e === t || e !== e && t !== t : e === t;
}
function Mo(e, t) {
  var r = /* @__PURE__ */ new Set([...Object.keys(e), ...Object.keys(t)]);
  for (var n of r)
    if (M9.has(n)) {
      if (e[n] == null && t[n] == null)
        continue;
      if (!_9(e[n], t[n]))
        return !1;
    } else if (!D9(e[n], t[n]))
      return !1;
  return !0;
}
var N9 = ["id"], $9 = ["type", "layout", "connectNulls", "needClip", "shape"], L9 = ["activeDot", "animateNewValues", "animationBegin", "animationDuration", "animationEasing", "connectNulls", "dot", "hide", "isAnimationActive", "label", "legendType", "xAxisId", "yAxisId", "id"];
function Zl() {
  return Zl = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Zl.apply(null, arguments);
}
function d1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Br(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? d1(Object(r), !0).forEach(function(n) {
      R9(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : d1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function R9(e, t, r) {
  return (t = z9(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function z9(e) {
  var t = B9(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function B9(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function a0(e, t) {
  if (e == null) return {};
  var r, n, i = F9(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function F9(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
var K9 = (e) => {
  var {
    dataKey: t,
    name: r,
    stroke: n,
    legendType: i,
    hide: a
  } = e;
  return [{
    inactive: a,
    dataKey: t,
    type: i,
    color: n,
    value: ir(r, t),
    payload: e
  }];
}, W9 = /* @__PURE__ */ d.memo((e) => {
  var {
    dataKey: t,
    data: r,
    stroke: n,
    strokeWidth: i,
    fill: a,
    name: o,
    hide: l,
    unit: u,
    tooltipType: s,
    id: c
  } = e, f = {
    dataDefinedOnItem: r,
    positions: void 0,
    settings: {
      stroke: n,
      strokeWidth: i,
      fill: a,
      dataKey: t,
      nameKey: void 0,
      name: ir(o, t),
      hide: l,
      type: s,
      color: n,
      unit: u,
      graphicalItemId: c
    }
  };
  return /* @__PURE__ */ d.createElement(an, {
    tooltipEntrySettings: f
  });
}), Sj = (e, t) => "".concat(t, "px ").concat(e - t, "px");
function U9(e, t) {
  for (var r = e.length % 2 !== 0 ? [...e, 0] : e, n = [], i = 0; i < t; ++i)
    n = [...n, ...r];
  return n;
}
var V9 = (e, t, r) => {
  var n = r.reduce((f, v) => f + v);
  if (!n)
    return Sj(t, e);
  for (var i = Math.floor(e / n), a = e % n, o = t - e, l = [], u = 0, s = 0; u < r.length; s += r[u], ++u)
    if (s + r[u] > a) {
      l = [...r.slice(0, u), a - s];
      break;
    }
  var c = l.length % 2 === 0 ? [0, o] : [o];
  return [...U9(r, i), ...l, ...c].map((f) => "".concat(f, "px")).join(", ");
};
function H9(e) {
  var {
    clipPathId: t,
    points: r,
    props: n
  } = e, {
    dot: i,
    dataKey: a,
    needClip: o
  } = n, {
    id: l
  } = n, u = a0(n, N9), s = re(u);
  return /* @__PURE__ */ d.createElement(Gg, {
    points: r,
    dot: i,
    className: "recharts-line-dots",
    dotClassName: "recharts-line-dot",
    dataKey: a,
    baseProps: s,
    needClip: o,
    clipPathId: t
  });
}
function X9(e) {
  var {
    showLabels: t,
    children: r,
    points: n
  } = e, i = d.useMemo(() => n == null ? void 0 : n.map((a) => {
    var o, l, u = {
      x: (o = a.x) !== null && o !== void 0 ? o : 0,
      y: (l = a.y) !== null && l !== void 0 ? l : 0,
      width: 0,
      lowerWidth: 0,
      upperWidth: 0,
      height: 0
    };
    return Br(Br({}, u), {}, {
      value: a.value,
      payload: a.payload,
      viewBox: u,
      /*
       * Line is not passing parentViewBox to the LabelList so the labels can escape - looks like a bug, should we pass parentViewBox?
       * Or should this just be the root chart viewBox?
       */
      parentViewBox: void 0,
      fill: void 0
    });
  }), [n]);
  return /* @__PURE__ */ d.createElement(_o, {
    value: t ? i : void 0
  }, r);
}
function v1(e) {
  var {
    clipPathId: t,
    pathRef: r,
    points: n,
    strokeDasharray: i,
    props: a
  } = e, {
    type: o,
    layout: l,
    connectNulls: u,
    needClip: s,
    shape: c
  } = a, f = a0(a, $9), v = Br(Br({}, Ie(f)), {}, {
    fill: "none",
    className: "recharts-line-curve",
    clipPath: s ? "url(#clipPath-".concat(t, ")") : void 0,
    points: n,
    type: o,
    layout: l,
    connectNulls: u,
    strokeDasharray: i ?? a.strokeDasharray
  });
  return /* @__PURE__ */ d.createElement(d.Fragment, null, (n == null ? void 0 : n.length) > 1 && /* @__PURE__ */ d.createElement(Ji, Zl({
    shapeType: "curve",
    option: c
  }, v, {
    pathRef: r
  })), /* @__PURE__ */ d.createElement(H9, {
    points: n,
    clipPathId: t,
    props: a
  }));
}
function Y9(e) {
  try {
    return e && e.getTotalLength && e.getTotalLength() || 0;
  } catch {
    return 0;
  }
}
function G9(e) {
  var {
    clipPathId: t,
    props: r,
    pathRef: n,
    previousPointsRef: i,
    longestAnimatedLengthRef: a
  } = e, {
    points: o,
    strokeDasharray: l,
    isAnimationActive: u,
    animationBegin: s,
    animationDuration: c,
    animationEasing: f,
    animateNewValues: v,
    width: p,
    height: h,
    onAnimationEnd: y,
    onAnimationStart: g
  } = r, m = i.current, b = en(o, "recharts-line-"), x = d.useRef(b), [w, P] = d.useState(!1), O = !w, S = d.useCallback(() => {
    typeof y == "function" && y(), P(!1);
  }, [y]), E = d.useCallback(() => {
    typeof g == "function" && g(), P(!0);
  }, [g]), k = Y9(n.current), _ = d.useRef(0);
  x.current !== b && (_.current = a.current, x.current = b);
  var I = _.current;
  return /* @__PURE__ */ d.createElement(X9, {
    points: o,
    showLabels: O
  }, r.children, /* @__PURE__ */ d.createElement(Jr, {
    animationId: b,
    begin: s,
    duration: c,
    isActive: u,
    easing: f,
    onAnimationEnd: S,
    onAnimationStart: E,
    key: b
  }, (j) => {
    var z = X(I, k + I, j), N = Math.min(z, k), R;
    if (u)
      if (l) {
        var V = "".concat(l).split(/[,\s]+/gim).map((D) => parseFloat(D));
        R = V9(N, k, V);
      } else
        R = Sj(k, N);
    else
      R = l == null ? void 0 : String(l);
    if (j > 0 && k > 0 && (i.current = o, a.current = Math.max(a.current, N)), m) {
      var H = m.length / o.length, C = j === 1 ? o : o.map((D, F) => {
        var Z = Math.floor(F * H);
        if (m[Z]) {
          var Q = m[Z];
          return Br(Br({}, D), {}, {
            x: X(Q.x, D.x, j),
            y: X(Q.y, D.y, j)
          });
        }
        return v ? Br(Br({}, D), {}, {
          x: X(p * 2, D.x, j),
          y: X(h / 2, D.y, j)
        }) : Br(Br({}, D), {}, {
          x: D.x,
          y: D.y
        });
      });
      return i.current = C, /* @__PURE__ */ d.createElement(v1, {
        props: r,
        points: C,
        clipPathId: t,
        pathRef: n,
        strokeDasharray: R
      });
    }
    return /* @__PURE__ */ d.createElement(v1, {
      props: r,
      points: o,
      clipPathId: t,
      pathRef: n,
      strokeDasharray: R
    });
  }), /* @__PURE__ */ d.createElement(bi, {
    label: r.label
  }));
}
function q9(e) {
  var {
    clipPathId: t,
    props: r
  } = e, n = d.useRef(null), i = d.useRef(0), a = d.useRef(null);
  return /* @__PURE__ */ d.createElement(G9, {
    props: r,
    clipPathId: t,
    previousPointsRef: n,
    longestAnimatedLengthRef: i,
    pathRef: a
  });
}
var Z9 = (e, t) => {
  var r, n;
  return {
    x: (r = e.x) !== null && r !== void 0 ? r : void 0,
    y: (n = e.y) !== null && n !== void 0 ? n : void 0,
    value: e.value,
    // @ts-expect-error getValueByDataKey does not validate the output type
    errorVal: G(e.payload, t)
  };
};
class Q9 extends d.Component {
  render() {
    var {
      hide: t,
      dot: r,
      points: n,
      className: i,
      xAxisId: a,
      yAxisId: o,
      top: l,
      left: u,
      width: s,
      height: c,
      id: f,
      needClip: v,
      zIndex: p
    } = this.props;
    if (t)
      return null;
    var h = Y("recharts-line", i), y = f, {
      r: g,
      strokeWidth: m
    } = Oj(r), b = Vg(r), x = g * 2 + m, w = v ? "url(#clipPath-".concat(b ? "" : "dots-").concat(y, ")") : void 0;
    return /* @__PURE__ */ d.createElement(pe, {
      zIndex: p
    }, /* @__PURE__ */ d.createElement(U, {
      className: h
    }, v && /* @__PURE__ */ d.createElement("defs", null, /* @__PURE__ */ d.createElement(Yd, {
      clipPathId: y,
      xAxisId: a,
      yAxisId: o
    }), !b && /* @__PURE__ */ d.createElement("clipPath", {
      id: "clipPath-dots-".concat(y)
    }, /* @__PURE__ */ d.createElement("rect", {
      x: u - x / 2,
      y: l - x / 2,
      width: s + x,
      height: c + x
    }))), /* @__PURE__ */ d.createElement(i0, {
      xAxisId: a,
      yAxisId: o,
      data: n,
      dataPointFormatter: Z9,
      errorBarOffset: 0
    }, /* @__PURE__ */ d.createElement(q9, {
      props: this.props,
      clipPathId: y
    }))), /* @__PURE__ */ d.createElement(pf, {
      activeDot: this.props.activeDot,
      points: n,
      mainColor: this.props.stroke,
      itemDataKey: this.props.dataKey,
      clipPath: w
    }));
  }
}
var Ej = {
  activeDot: !0,
  animateNewValues: !0,
  animationBegin: 0,
  animationDuration: 1500,
  animationEasing: "ease",
  connectNulls: !1,
  dot: !0,
  fill: "#fff",
  hide: !1,
  isAnimationActive: "auto",
  label: !1,
  legendType: "line",
  stroke: "#3182bd",
  strokeWidth: 1,
  xAxisId: 0,
  yAxisId: 0,
  zIndex: ie.line,
  type: "linear"
};
function J9(e) {
  var t = ee(e, Ej), {
    activeDot: r,
    animateNewValues: n,
    animationBegin: i,
    animationDuration: a,
    animationEasing: o,
    connectNulls: l,
    dot: u,
    hide: s,
    isAnimationActive: c,
    label: f,
    legendType: v,
    xAxisId: p,
    yAxisId: h,
    id: y
  } = t, g = a0(t, L9), {
    needClip: m
  } = Yu(p, h), b = Xu(), x = Ln(), w = me(), P = T((_) => c9(_, p, h, w, y));
  if (x !== "horizontal" && x !== "vertical" || P == null || b == null)
    return null;
  var {
    height: O,
    width: S,
    x: E,
    y: k
  } = b;
  return /* @__PURE__ */ d.createElement(Q9, Zl({}, g, {
    id: y,
    connectNulls: l,
    dot: u,
    activeDot: r,
    animateNewValues: n,
    animationBegin: i,
    animationDuration: a,
    animationEasing: o,
    isAnimationActive: c,
    hide: s,
    label: f,
    legendType: v,
    xAxisId: p,
    yAxisId: h,
    points: P,
    layout: x,
    height: O,
    width: S,
    left: E,
    top: k,
    needClip: m
  }));
}
function e7(e) {
  var {
    layout: t,
    xAxis: r,
    yAxis: n,
    xAxisTicks: i,
    yAxisTicks: a,
    dataKey: o,
    bandSize: l,
    displayedData: u
  } = e;
  return u.map((s, c) => {
    var f = G(s, o);
    if (t === "horizontal") {
      var v = Za({
        axis: r,
        ticks: i,
        bandSize: l,
        entry: s,
        index: c
      }), p = oe(f) ? null : n.scale(f);
      return {
        x: v,
        y: p,
        value: f,
        payload: s
      };
    }
    var h = oe(f) ? null : r.scale(f), y = Za({
      axis: n,
      ticks: a,
      bandSize: l,
      entry: s,
      index: c
    });
    return h == null || y == null ? null : {
      x: h,
      y,
      value: f,
      payload: s
    };
  }).filter(Boolean);
}
function t7(e) {
  var t = ee(e, Ej), r = me();
  return /* @__PURE__ */ d.createElement(on, {
    id: t.id,
    type: "line"
  }, (n) => /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(Kd, {
    legendPayload: K9(t)
  }), /* @__PURE__ */ d.createElement(W9, {
    dataKey: t.dataKey,
    data: t.data,
    stroke: t.stroke,
    strokeWidth: t.strokeWidth,
    fill: t.fill,
    name: t.name,
    hide: t.hide,
    unit: t.unit,
    tooltipType: t.tooltipType,
    id: n
  }), /* @__PURE__ */ d.createElement(Wd, {
    type: "line",
    id: n,
    data: t.data,
    xAxisId: t.xAxisId,
    yAxisId: t.yAxisId,
    zAxisId: 0,
    dataKey: t.dataKey,
    hide: t.hide,
    isPanorama: r
  }), /* @__PURE__ */ d.createElement(J9, Zl({}, t, {
    id: n
  }))));
}
var r7 = /* @__PURE__ */ d.memo(t7, Mo);
r7.displayName = "Line";
function ln(e, t) {
  var r, n;
  return (r = (n = e.graphicalItems.cartesianItems.find((i) => i.id === t)) === null || n === void 0 ? void 0 : n.xAxisId) !== null && r !== void 0 ? r : GI;
}
function un(e, t) {
  var r, n;
  return (r = (n = e.graphicalItems.cartesianItems.find((i) => i.id === t)) === null || n === void 0 ? void 0 : n.yAxisId) !== null && r !== void 0 ? r : GI;
}
var Aj = (e, t, r) => Kt(e, "xAxis", ln(e, t), r), kj = (e, t, r) => gr(e, "xAxis", ln(e, t), r), _j = (e, t, r) => Kt(e, "yAxis", un(e, t), r), Ij = (e, t, r) => gr(e, "yAxis", un(e, t), r), n7 = A([q, Aj, _j, kj, Ij], (e, t, r, n, i) => br(e, "xAxis") ? Ft(t, n, !1) : Ft(r, i, !1)), i7 = (e, t) => t, jj = A([Po, i7], (e, t) => e.filter((r) => r.type === "area").find((r) => r.id === t)), Cj = (e) => {
  var t = q(e), r = br(t, "xAxis");
  return r ? "yAxis" : "xAxis";
}, a7 = (e, t) => {
  var r = Cj(e);
  return r === "yAxis" ? un(e, t) : ln(e, t);
}, o7 = (e, t, r) => lf(e, Cj(e), a7(e, t), r), l7 = A([jj, o7], (e, t) => {
  var r;
  if (!(e == null || t == null)) {
    var {
      stackId: n
    } = e, i = Ed(e);
    if (!(n == null || i == null)) {
      var a = (r = t[n]) === null || r === void 0 ? void 0 : r.stackedData, o = a == null ? void 0 : a.find((l) => l.key === i);
      if (o != null)
        return o.map((l) => [l[0], l[1]]);
    }
  }
}), u7 = A([q, Aj, _j, kj, Ij, l7, Kk, n7, jj, n3], (e, t, r, n, i, a, o, l, u, s) => {
  var {
    chartData: c,
    dataStartIndex: f,
    dataEndIndex: v
  } = o;
  if (!(u == null || e !== "horizontal" && e !== "vertical" || t == null || r == null || n == null || i == null || n.length === 0 || i.length === 0 || l == null)) {
    var {
      data: p
    } = u, h;
    if (p && p.length > 0 ? h = p : h = c == null ? void 0 : c.slice(f, v + 1), h != null)
      return k7({
        layout: e,
        xAxis: t,
        yAxis: r,
        xAxisTicks: n,
        yAxisTicks: i,
        dataStartIndex: f,
        areaSettings: u,
        stackedData: a,
        displayedData: h,
        chartBaseValue: s,
        bandSize: l
      });
  }
}), s7 = ["id"], c7 = ["activeDot", "animationBegin", "animationDuration", "animationEasing", "connectNulls", "dot", "fill", "fillOpacity", "hide", "isAnimationActive", "legendType", "stroke", "xAxisId", "yAxisId"];
function Fi() {
  return Fi = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Fi.apply(null, arguments);
}
function Tj(e, t) {
  if (e == null) return {};
  var r, n, i = f7(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function f7(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function p1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Ca(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? p1(Object(r), !0).forEach(function(n) {
      d7(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : p1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function d7(e, t, r) {
  return (t = v7(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function v7(e) {
  var t = p7(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function p7(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function wf(e, t) {
  return e && e !== "none" ? e : t;
}
var h7 = (e) => {
  var {
    dataKey: t,
    name: r,
    stroke: n,
    fill: i,
    legendType: a,
    hide: o
  } = e;
  return [{
    inactive: o,
    dataKey: t,
    type: a,
    color: wf(n, i),
    value: ir(r, t),
    payload: e
  }];
}, m7 = /* @__PURE__ */ d.memo((e) => {
  var {
    dataKey: t,
    data: r,
    stroke: n,
    strokeWidth: i,
    fill: a,
    name: o,
    hide: l,
    unit: u,
    tooltipType: s,
    id: c
  } = e, f = {
    dataDefinedOnItem: r,
    positions: void 0,
    settings: {
      stroke: n,
      strokeWidth: i,
      fill: a,
      dataKey: t,
      nameKey: void 0,
      name: ir(o, t),
      hide: l,
      type: s,
      color: wf(n, a),
      unit: u,
      graphicalItemId: c
    }
  };
  return /* @__PURE__ */ d.createElement(an, {
    tooltipEntrySettings: f
  });
});
function y7(e) {
  var {
    clipPathId: t,
    points: r,
    props: n
  } = e, {
    needClip: i,
    dot: a,
    dataKey: o
  } = n, l = re(n);
  return /* @__PURE__ */ d.createElement(Gg, {
    points: r,
    dot: a,
    className: "recharts-area-dots",
    dotClassName: "recharts-area-dot",
    dataKey: o,
    baseProps: l,
    needClip: i,
    clipPathId: t
  });
}
function g7(e) {
  var {
    showLabels: t,
    children: r,
    points: n
  } = e, i = n.map((a) => {
    var o, l, u = {
      x: (o = a.x) !== null && o !== void 0 ? o : 0,
      y: (l = a.y) !== null && l !== void 0 ? l : 0,
      width: 0,
      lowerWidth: 0,
      upperWidth: 0,
      height: 0
    };
    return Ca(Ca({}, u), {}, {
      value: a.value,
      payload: a.payload,
      parentViewBox: void 0,
      viewBox: u,
      fill: void 0
    });
  });
  return /* @__PURE__ */ d.createElement(_o, {
    value: t ? i : void 0
  }, r);
}
function h1(e) {
  var {
    points: t,
    baseLine: r,
    needClip: n,
    clipPathId: i,
    props: a
  } = e, {
    layout: o,
    type: l,
    stroke: u,
    connectNulls: s,
    isRange: c
  } = a, {
    id: f
  } = a, v = Tj(a, s7), p = re(v), h = Ie(v);
  return /* @__PURE__ */ d.createElement(d.Fragment, null, (t == null ? void 0 : t.length) > 1 && /* @__PURE__ */ d.createElement(U, {
    clipPath: n ? "url(#clipPath-".concat(i, ")") : void 0
  }, /* @__PURE__ */ d.createElement(Ri, Fi({}, h, {
    id: f,
    points: t,
    connectNulls: s,
    type: l,
    baseLine: r,
    layout: o,
    stroke: "none",
    className: "recharts-area-area"
  })), u !== "none" && /* @__PURE__ */ d.createElement(Ri, Fi({}, p, {
    className: "recharts-area-curve",
    layout: o,
    type: l,
    connectNulls: s,
    fill: "none",
    points: t
  })), u !== "none" && c && /* @__PURE__ */ d.createElement(Ri, Fi({}, p, {
    className: "recharts-area-curve",
    layout: o,
    type: l,
    connectNulls: s,
    fill: "none",
    points: r
  }))), /* @__PURE__ */ d.createElement(y7, {
    points: t,
    props: v,
    clipPathId: i
  }));
}
function b7(e) {
  var t, r, {
    alpha: n,
    baseLine: i,
    points: a,
    strokeWidth: o
  } = e, l = (t = a[0]) === null || t === void 0 ? void 0 : t.y, u = (r = a[a.length - 1]) === null || r === void 0 ? void 0 : r.y;
  if (!se(l) || !se(u))
    return null;
  var s = n * Math.abs(l - u), c = Math.max(...a.map((f) => f.x || 0));
  return B(i) ? c = Math.max(i, c) : i && Array.isArray(i) && i.length && (c = Math.max(...i.map((f) => f.x || 0), c)), B(c) ? /* @__PURE__ */ d.createElement("rect", {
    x: 0,
    y: l < u ? l : l - s,
    width: c + (o ? parseInt("".concat(o), 10) : 1),
    height: Math.floor(s)
  }) : null;
}
function x7(e) {
  var t, r, {
    alpha: n,
    baseLine: i,
    points: a,
    strokeWidth: o
  } = e, l = (t = a[0]) === null || t === void 0 ? void 0 : t.x, u = (r = a[a.length - 1]) === null || r === void 0 ? void 0 : r.x;
  if (!se(l) || !se(u))
    return null;
  var s = n * Math.abs(l - u), c = Math.max(...a.map((f) => f.y || 0));
  return B(i) ? c = Math.max(i, c) : i && Array.isArray(i) && i.length && (c = Math.max(...i.map((f) => f.y || 0), c)), B(c) ? /* @__PURE__ */ d.createElement("rect", {
    x: l < u ? l : l - s,
    y: 0,
    width: s,
    height: Math.floor(c + (o ? parseInt("".concat(o), 10) : 1))
  }) : null;
}
function w7(e) {
  var {
    alpha: t,
    layout: r,
    points: n,
    baseLine: i,
    strokeWidth: a
  } = e;
  return r === "vertical" ? /* @__PURE__ */ d.createElement(b7, {
    alpha: t,
    points: n,
    baseLine: i,
    strokeWidth: a
  }) : /* @__PURE__ */ d.createElement(x7, {
    alpha: t,
    points: n,
    baseLine: i,
    strokeWidth: a
  });
}
function P7(e) {
  var {
    needClip: t,
    clipPathId: r,
    props: n,
    previousPointsRef: i,
    previousBaselineRef: a
  } = e, {
    points: o,
    baseLine: l,
    isAnimationActive: u,
    animationBegin: s,
    animationDuration: c,
    animationEasing: f,
    onAnimationStart: v,
    onAnimationEnd: p
  } = n, h = d.useMemo(() => ({
    points: o,
    baseLine: l
  }), [o, l]), y = en(h, "recharts-area-"), g = k$(), [m, b] = d.useState(!1), x = !m, w = d.useCallback(() => {
    typeof p == "function" && p(), b(!1);
  }, [p]), P = d.useCallback(() => {
    typeof v == "function" && v(), b(!0);
  }, [v]);
  if (g == null)
    return null;
  var O = i.current, S = a.current;
  return /* @__PURE__ */ d.createElement(g7, {
    showLabels: x,
    points: o
  }, n.children, /* @__PURE__ */ d.createElement(Jr, {
    animationId: y,
    begin: s,
    duration: c,
    isActive: u,
    easing: f,
    onAnimationEnd: w,
    onAnimationStart: P,
    key: y
  }, (E) => {
    if (O) {
      var k = O.length / o.length, _ = (
        /*
         * Here it is important that at the very end of the animation, on the last frame,
         * we render the original points without any interpolation.
         * This is needed because the code above is checking for reference equality to decide if the animation should run
         * and if we create a new array instance (even if the numbers were the same)
         * then we would break animations.
         */
        E === 1 ? o : o.map((j, z) => {
          var N = Math.floor(z * k);
          if (O[N]) {
            var R = O[N];
            return Ca(Ca({}, j), {}, {
              x: X(R.x, j.x, E),
              y: X(R.y, j.y, E)
            });
          }
          return j;
        })
      ), I;
      return B(l) ? I = X(S, l, E) : oe(l) || Pt(l) ? I = X(S, 0, E) : I = l.map((j, z) => {
        var N = Math.floor(z * k);
        if (Array.isArray(S) && S[N]) {
          var R = S[N];
          return Ca(Ca({}, j), {}, {
            x: X(R.x, j.x, E),
            y: X(R.y, j.y, E)
          });
        }
        return j;
      }), E > 0 && (i.current = _, a.current = I), /* @__PURE__ */ d.createElement(h1, {
        points: _,
        baseLine: I,
        needClip: t,
        clipPathId: r,
        props: n
      });
    }
    return E > 0 && (i.current = o, a.current = l), /* @__PURE__ */ d.createElement(U, null, u && /* @__PURE__ */ d.createElement("defs", null, /* @__PURE__ */ d.createElement("clipPath", {
      id: "animationClipPath-".concat(r)
    }, /* @__PURE__ */ d.createElement(w7, {
      alpha: E,
      points: o,
      baseLine: l,
      layout: g,
      strokeWidth: n.strokeWidth
    }))), /* @__PURE__ */ d.createElement(U, {
      clipPath: "url(#animationClipPath-".concat(r, ")")
    }, /* @__PURE__ */ d.createElement(h1, {
      points: o,
      baseLine: l,
      needClip: t,
      clipPathId: r,
      props: n
    })));
  }), /* @__PURE__ */ d.createElement(bi, {
    label: n.label
  }));
}
function O7(e) {
  var {
    needClip: t,
    clipPathId: r,
    props: n
  } = e, i = d.useRef(null), a = d.useRef();
  return /* @__PURE__ */ d.createElement(P7, {
    needClip: t,
    clipPathId: r,
    props: n,
    previousPointsRef: i,
    previousBaselineRef: a
  });
}
class S7 extends d.PureComponent {
  render() {
    var {
      hide: t,
      dot: r,
      points: n,
      className: i,
      top: a,
      left: o,
      needClip: l,
      xAxisId: u,
      yAxisId: s,
      width: c,
      height: f,
      id: v,
      baseLine: p,
      zIndex: h
    } = this.props;
    if (t)
      return null;
    var y = Y("recharts-area", i), g = v, {
      r: m,
      strokeWidth: b
    } = Oj(r), x = Vg(r), w = m * 2 + b, P = l ? "url(#clipPath-".concat(x ? "" : "dots-").concat(g, ")") : void 0;
    return /* @__PURE__ */ d.createElement(pe, {
      zIndex: h
    }, /* @__PURE__ */ d.createElement(U, {
      className: y
    }, l && /* @__PURE__ */ d.createElement("defs", null, /* @__PURE__ */ d.createElement(Yd, {
      clipPathId: g,
      xAxisId: u,
      yAxisId: s
    }), !x && /* @__PURE__ */ d.createElement("clipPath", {
      id: "clipPath-dots-".concat(g)
    }, /* @__PURE__ */ d.createElement("rect", {
      x: o - w / 2,
      y: a - w / 2,
      width: c + w,
      height: f + w
    }))), /* @__PURE__ */ d.createElement(O7, {
      needClip: l,
      clipPathId: g,
      props: this.props
    })), /* @__PURE__ */ d.createElement(pf, {
      points: n,
      mainColor: wf(this.props.stroke, this.props.fill),
      itemDataKey: this.props.dataKey,
      activeDot: this.props.activeDot,
      clipPath: P
    }), this.props.isRange && Array.isArray(p) && /* @__PURE__ */ d.createElement(pf, {
      points: p,
      mainColor: wf(this.props.stroke, this.props.fill),
      itemDataKey: this.props.dataKey,
      activeDot: this.props.activeDot,
      clipPath: P
    }));
  }
}
var Mj = {
  activeDot: !0,
  animationBegin: 0,
  animationDuration: 1500,
  animationEasing: "ease",
  connectNulls: !1,
  dot: !1,
  fill: "#3182bd",
  fillOpacity: 0.6,
  hide: !1,
  isAnimationActive: "auto",
  legendType: "line",
  stroke: "#3182bd",
  strokeWidth: 1,
  type: "linear",
  label: !1,
  xAxisId: 0,
  yAxisId: 0,
  zIndex: ie.area
};
function E7(e) {
  var t, r = ee(e, Mj), {
    activeDot: n,
    animationBegin: i,
    animationDuration: a,
    animationEasing: o,
    connectNulls: l,
    dot: u,
    fill: s,
    fillOpacity: c,
    hide: f,
    isAnimationActive: v,
    legendType: p,
    stroke: h,
    xAxisId: y,
    yAxisId: g
  } = r, m = Tj(r, c7), b = Ln(), x = eI(), {
    needClip: w
  } = Yu(y, g), P = me(), {
    points: O,
    isRange: S,
    baseLine: E
  } = (t = T((N) => u7(N, e.id, P))) !== null && t !== void 0 ? t : {}, k = Xu();
  if (b !== "horizontal" && b !== "vertical" || k == null || x !== "AreaChart" && x !== "ComposedChart")
    return null;
  var {
    height: _,
    width: I,
    x: j,
    y: z
  } = k;
  return !O || !O.length ? null : /* @__PURE__ */ d.createElement(S7, Fi({}, m, {
    activeDot: n,
    animationBegin: i,
    animationDuration: a,
    animationEasing: o,
    baseLine: E,
    connectNulls: l,
    dot: u,
    fill: s,
    fillOpacity: c,
    height: _,
    hide: f,
    layout: b,
    isAnimationActive: v === "auto" ? !po.isSsr : v,
    isRange: S,
    legendType: p,
    needClip: w,
    points: O,
    stroke: h,
    width: I,
    left: j,
    top: z,
    xAxisId: y,
    yAxisId: g
  }));
}
var A7 = (e, t, r, n, i) => {
  var a = r ?? t;
  if (B(a))
    return a;
  var o = e === "horizontal" ? i : n, l = o.scale.domain();
  if (o.type === "number") {
    var u = Math.max(l[0], l[1]), s = Math.min(l[0], l[1]);
    return a === "dataMin" ? s : a === "dataMax" || u < 0 ? u : Math.max(Math.min(l[0], l[1]), 0);
  }
  return a === "dataMin" ? l[0] : a === "dataMax" ? l[1] : l[0];
};
function k7(e) {
  var {
    areaSettings: {
      connectNulls: t,
      baseValue: r,
      dataKey: n
    },
    stackedData: i,
    layout: a,
    chartBaseValue: o,
    xAxis: l,
    yAxis: u,
    displayedData: s,
    dataStartIndex: c,
    xAxisTicks: f,
    yAxisTicks: v,
    bandSize: p
  } = e, h = i && i.length, y = A7(a, o, r, l, u), g = a === "horizontal", m = !1, b = s.map((w, P) => {
    var O, S, E;
    if (h)
      E = i[c + P];
    else {
      var k = G(w, n);
      Array.isArray(k) ? (E = k, m = !0) : E = [y, k];
    }
    var _ = (O = (S = E) === null || S === void 0 ? void 0 : S[1]) !== null && O !== void 0 ? O : null, I = _ == null || h && !t && G(w, n) == null;
    return g ? {
      x: Za({
        axis: l,
        ticks: f,
        bandSize: p,
        entry: w,
        index: P
      }),
      y: I ? null : u.scale(_),
      value: E,
      payload: w
    } : {
      x: I ? null : l.scale(_),
      y: Za({
        axis: u,
        ticks: v,
        bandSize: p,
        entry: w,
        index: P
      }),
      value: E,
      payload: w
    };
  }), x;
  return h || m ? x = b.map((w) => {
    var P = Array.isArray(w.value) ? w.value[0] : null;
    return g ? {
      x: w.x,
      y: P != null && w.y != null ? u.scale(P) : null,
      payload: w.payload
    } : {
      x: P != null ? l.scale(P) : null,
      y: w.y,
      payload: w.payload
    };
  }) : x = g ? u.scale(y) : l.scale(y), {
    points: b,
    baseLine: x,
    isRange: m
  };
}
function _7(e) {
  var t = ee(e, Mj), r = me();
  return /* @__PURE__ */ d.createElement(on, {
    id: t.id,
    type: "area"
  }, (n) => /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(Kd, {
    legendPayload: h7(t)
  }), /* @__PURE__ */ d.createElement(m7, {
    dataKey: t.dataKey,
    data: t.data,
    stroke: t.stroke,
    strokeWidth: t.strokeWidth,
    fill: t.fill,
    name: t.name,
    hide: t.hide,
    unit: t.unit,
    tooltipType: t.tooltipType,
    id: n
  }), /* @__PURE__ */ d.createElement(Wd, {
    type: "area",
    id: n,
    data: t.data,
    dataKey: t.dataKey,
    xAxisId: t.xAxisId,
    yAxisId: t.yAxisId,
    zAxisId: 0,
    stackId: od(t.stackId),
    hide: t.hide,
    barSize: void 0,
    baseValue: t.baseValue,
    isPanorama: r,
    connectNulls: t.connectNulls
  }), /* @__PURE__ */ d.createElement(E7, Fi({}, t, {
    id: n
  }))));
}
var I7 = /* @__PURE__ */ d.memo(_7, Mo);
I7.displayName = "Area";
var j7 = "Invariant failed";
function C7(e, t) {
  throw new Error(j7);
}
function Vh() {
  return Vh = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Vh.apply(null, arguments);
}
function Pf(e) {
  return /* @__PURE__ */ d.createElement(Ji, Vh({
    shapeType: "rectangle",
    activeClassName: "recharts-active-bar"
  }, e));
}
var T7 = function(t) {
  var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0;
  return (n, i) => {
    if (B(t)) return t;
    var a = B(n) || oe(n);
    return a ? t(n, i) : (a || C7(), r);
  };
}, M7 = (e, t, r) => r, D7 = (e, t) => t, qu = A([Po, D7], (e, t) => e.filter((r) => r.type === "bar").find((r) => r.id === t)), N7 = A([qu], (e) => e == null ? void 0 : e.maxBarSize), $7 = (e, t, r, n) => n, L7 = A([q, Po, ln, un, M7], (e, t, r, n, i) => t.filter((a) => e === "horizontal" ? a.xAxisId === r : a.yAxisId === n).filter((a) => a.isPanorama === i).filter((a) => a.hide === !1).filter((a) => a.type === "bar")), R7 = (e, t, r) => {
  var n = q(e), i = ln(e, t), a = un(e, t);
  if (!(i == null || a == null))
    return n === "horizontal" ? lf(e, "yAxis", a, r) : lf(e, "xAxis", i, r);
}, z7 = (e, t) => {
  var r = q(e), n = ln(e, t), i = un(e, t);
  if (!(n == null || i == null))
    return r === "horizontal" ? Nw(e, "xAxis", n) : Nw(e, "yAxis", i);
}, B7 = A([L7, i_, z7], tj), F7 = (e, t, r) => {
  var n, i, a = qu(e, t);
  if (a != null) {
    var o = ln(e, t), l = un(e, t);
    if (!(o == null || l == null)) {
      var u = q(e), s = xd(e), {
        maxBarSize: c
      } = a, f = oe(c) ? s : c, v, p;
      return u === "horizontal" ? (v = Kt(e, "xAxis", o, r), p = gr(e, "xAxis", o, r)) : (v = Kt(e, "yAxis", l, r), p = gr(e, "yAxis", l, r)), (n = (i = Ft(v, p, !0)) !== null && i !== void 0 ? i : f) !== null && n !== void 0 ? n : 0;
    }
  }
}, Dj = (e, t, r) => {
  var n = q(e), i = ln(e, t), a = un(e, t);
  if (!(i == null || a == null)) {
    var o, l;
    return n === "horizontal" ? (o = Kt(e, "xAxis", i, r), l = gr(e, "xAxis", i, r)) : (o = Kt(e, "yAxis", a, r), l = gr(e, "yAxis", a, r)), Ft(o, l);
  }
}, K7 = A([B7, xd, n_, rg, F7, Dj, N7], rj), W7 = (e, t, r) => {
  var n = ln(e, t);
  if (n != null)
    return Kt(e, "xAxis", n, r);
}, U7 = (e, t, r) => {
  var n = un(e, t);
  if (n != null)
    return Kt(e, "yAxis", n, r);
}, V7 = (e, t, r) => {
  var n = ln(e, t);
  if (n != null)
    return gr(e, "xAxis", n, r);
}, H7 = (e, t, r) => {
  var n = un(e, t);
  if (n != null)
    return gr(e, "yAxis", n, r);
}, X7 = A([K7, qu], (e, t) => {
  if (!(e == null || t == null)) {
    var r = e.find((n) => n.stackId === t.stackId && t.dataKey != null && n.dataKeys.includes(t.dataKey));
    if (r != null)
      return r.position;
  }
}), Y7 = A([R7, qu], nj), G7 = A([Ve, Sy, W7, U7, V7, H7, X7, q, Kk, Dj, Y7, qu, $7], (e, t, r, n, i, a, o, l, u, s, c, f, v) => {
  var {
    chartData: p,
    dataStartIndex: h,
    dataEndIndex: y
  } = u;
  if (!(f == null || o == null || t == null || l !== "horizontal" && l !== "vertical" || r == null || n == null || i == null || a == null || s == null)) {
    var {
      data: g
    } = f, m;
    if (g != null && g.length > 0 ? m = g : m = p == null ? void 0 : p.slice(h, y + 1), m != null)
      return SX({
        layout: l,
        barSettings: f,
        pos: o,
        parentViewBox: t,
        bandSize: s,
        xAxis: r,
        yAxis: n,
        xAxisTicks: i,
        yAxisTicks: a,
        stackedData: c,
        displayedData: m,
        offset: e,
        cells: v,
        dataStartIndex: h
      });
  }
}), q7 = ["index"];
function Hh() {
  return Hh = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Hh.apply(null, arguments);
}
function Z7(e, t) {
  if (e == null) return {};
  var r, n, i = Q7(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function Q7(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
var Nj = /* @__PURE__ */ d.createContext(void 0), J7 = (e) => {
  var t = d.useContext(Nj);
  if (t != null)
    return t.stackId;
  if (e != null)
    return od(e);
}, eX = (e, t) => "recharts-bar-stack-clip-path-".concat(e, "-").concat(t), tX = (e) => {
  var t = d.useContext(Nj);
  if (t != null) {
    var {
      stackId: r
    } = t;
    return "url(#".concat(eX(r, e), ")");
  }
}, rX = (e) => {
  var {
    index: t
  } = e, r = Z7(e, q7), n = tX(t);
  return /* @__PURE__ */ d.createElement(U, Hh({
    className: "recharts-bar-stack-layer",
    clipPath: n
  }, r));
}, nX = ["onMouseEnter", "onMouseLeave", "onClick"], iX = ["value", "background", "tooltipPosition"], aX = ["id"], oX = ["onMouseEnter", "onClick", "onMouseLeave"];
function Mn() {
  return Mn = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Mn.apply(null, arguments);
}
function m1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function St(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? m1(Object(r), !0).forEach(function(n) {
      lX(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : m1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function lX(e, t, r) {
  return (t = uX(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function uX(e) {
  var t = sX(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function sX(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function Of(e, t) {
  if (e == null) return {};
  var r, n, i = cX(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function cX(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
var fX = (e) => {
  var {
    dataKey: t,
    name: r,
    fill: n,
    legendType: i,
    hide: a
  } = e;
  return [{
    inactive: a,
    dataKey: t,
    type: i,
    color: n,
    value: ir(r, t),
    payload: e
  }];
}, dX = /* @__PURE__ */ d.memo((e) => {
  var {
    dataKey: t,
    stroke: r,
    strokeWidth: n,
    fill: i,
    name: a,
    hide: o,
    unit: l,
    tooltipType: u,
    id: s
  } = e, c = {
    dataDefinedOnItem: void 0,
    positions: void 0,
    settings: {
      stroke: r,
      strokeWidth: n,
      fill: i,
      dataKey: t,
      nameKey: void 0,
      name: ir(a, t),
      hide: o,
      type: u,
      color: i,
      unit: l,
      graphicalItemId: s
    }
  };
  return /* @__PURE__ */ d.createElement(an, {
    tooltipEntrySettings: c
  });
});
function vX(e) {
  var t = T(Qr), {
    data: r,
    dataKey: n,
    background: i,
    allOtherBarProps: a
  } = e, {
    onMouseEnter: o,
    onMouseLeave: l,
    onClick: u
  } = a, s = Of(a, nX), c = jo(o, n, a.id), f = Co(l), v = To(u, n, a.id);
  if (!i || r == null)
    return null;
  var p = er(i);
  return /* @__PURE__ */ d.createElement(pe, {
    zIndex: uj(i, ie.barBackground)
  }, r.map((h, y) => {
    var {
      value: g,
      background: m,
      tooltipPosition: b
    } = h, x = Of(h, iX);
    if (!m)
      return null;
    var w = c(h, y), P = f(h, y), O = v(h, y), S = St(St(St(St(St({
      option: i,
      isActive: String(y) === t
    }, x), {}, {
      // @ts-expect-error backgroundProps is contributing unknown props
      fill: "#eee"
    }, m), p), Nr(s, h, y)), {}, {
      onMouseEnter: w,
      onMouseLeave: P,
      onClick: O,
      dataKey: n,
      index: y,
      className: "recharts-bar-background-rectangle"
    });
    return /* @__PURE__ */ d.createElement(Pf, Mn({
      key: "background-bar-".concat(y)
    }, S));
  }));
}
function pX(e) {
  var {
    showLabels: t,
    children: r,
    rects: n
  } = e, i = n == null ? void 0 : n.map((a) => {
    var o = {
      x: a.x,
      y: a.y,
      width: a.width,
      lowerWidth: a.width,
      upperWidth: a.width,
      height: a.height
    };
    return St(St({}, o), {}, {
      value: a.value,
      payload: a.payload,
      parentViewBox: a.parentViewBox,
      viewBox: o,
      fill: a.fill
    });
  });
  return /* @__PURE__ */ d.createElement(_o, {
    value: t ? i : void 0
  }, r);
}
function hX(e) {
  var {
    shape: t,
    activeBar: r,
    baseProps: n,
    entry: i,
    index: a,
    dataKey: o
  } = e, l = T(Qr), u = T(Dg), s = r && String(a) === l && (u == null || o === u), c = s ? r : t;
  return s ? /* @__PURE__ */ d.createElement(pe, {
    zIndex: ie.activeBar
  }, /* @__PURE__ */ d.createElement(Pf, Mn({}, n, {
    name: String(n.name)
  }, i, {
    isActive: s,
    option: c,
    index: a,
    dataKey: o
  }))) : /* @__PURE__ */ d.createElement(Pf, Mn({}, n, {
    name: String(n.name)
  }, i, {
    isActive: s,
    option: c,
    index: a,
    dataKey: o
  }));
}
function mX(e) {
  var {
    shape: t,
    baseProps: r,
    entry: n,
    index: i,
    dataKey: a
  } = e;
  return /* @__PURE__ */ d.createElement(Pf, Mn({}, r, {
    name: String(r.name)
  }, n, {
    isActive: !1,
    option: t,
    index: i,
    dataKey: a
  }));
}
function yX(e) {
  var t, {
    data: r,
    props: n
  } = e, i = (t = re(n)) !== null && t !== void 0 ? t : {}, {
    id: a
  } = i, o = Of(i, aX), {
    shape: l,
    dataKey: u,
    activeBar: s
  } = n, {
    onMouseEnter: c,
    onClick: f,
    onMouseLeave: v
  } = n, p = Of(n, oX), h = jo(c, u, a), y = Co(v), g = To(f, u, a);
  return r ? /* @__PURE__ */ d.createElement(d.Fragment, null, r.map((m, b) => /* @__PURE__ */ d.createElement(rX, Mn({
    index: b,
    key: "rectangle-".concat(m == null ? void 0 : m.x, "-").concat(m == null ? void 0 : m.y, "-").concat(m == null ? void 0 : m.value, "-").concat(b),
    className: "recharts-bar-rectangle"
  }, Nr(p, m, b), {
    // @ts-expect-error BarRectangleItem type definition says it's missing properties, but I can see them present in debugger!
    onMouseEnter: h(m, b),
    onMouseLeave: y(m, b),
    onClick: g(m, b)
  }), s ? /* @__PURE__ */ d.createElement(hX, {
    shape: l,
    activeBar: s,
    baseProps: o,
    entry: m,
    index: b,
    dataKey: u
  }) : (
    /*
     * If the `activeBar` prop is falsy, then let's call the variant without hooks.
     * Using the `selectActiveTooltipIndex` selector is usually fast
     * but in charts with large-ish amount of data even the few nanoseconds add up to a noticeable jank.
     * If the activeBar is false then we don't need to know which index is active - because we won't use it anyway.
     * So let's just skip the hooks altogether. That way, React can skip rendering the component,
     * and can skip the tree reconciliation for its children too.
     * Because we can't call hooks conditionally, we need to have a separate component for that.
     */
    /* @__PURE__ */ d.createElement(mX, {
      shape: l,
      baseProps: o,
      entry: m,
      index: b,
      dataKey: u
    })
  )))) : null;
}
function gX(e) {
  var {
    props: t,
    previousRectanglesRef: r
  } = e, {
    data: n,
    layout: i,
    isAnimationActive: a,
    animationBegin: o,
    animationDuration: l,
    animationEasing: u,
    onAnimationEnd: s,
    onAnimationStart: c
  } = t, f = r.current, v = en(t, "recharts-bar-"), [p, h] = d.useState(!1), y = !p, g = d.useCallback(() => {
    typeof s == "function" && s(), h(!1);
  }, [s]), m = d.useCallback(() => {
    typeof c == "function" && c(), h(!0);
  }, [c]);
  return /* @__PURE__ */ d.createElement(pX, {
    showLabels: y,
    rects: n
  }, /* @__PURE__ */ d.createElement(Jr, {
    animationId: v,
    begin: o,
    duration: l,
    isActive: a,
    easing: u,
    onAnimationEnd: g,
    onAnimationStart: m,
    key: v
  }, (b) => {
    var x = b === 1 ? n : n == null ? void 0 : n.map((w, P) => {
      var O = f && f[P];
      if (O)
        return St(St({}, w), {}, {
          x: X(O.x, w.x, b),
          y: X(O.y, w.y, b),
          width: X(O.width, w.width, b),
          height: X(O.height, w.height, b)
        });
      if (i === "horizontal") {
        var S = X(0, w.height, b), E = X(w.stackedBarStart, w.y, b);
        return St(St({}, w), {}, {
          y: E,
          height: S
        });
      }
      var k = X(0, w.width, b), _ = X(w.stackedBarStart, w.x, b);
      return St(St({}, w), {}, {
        width: k,
        x: _
      });
    });
    return b > 0 && (r.current = x ?? null), x == null ? null : /* @__PURE__ */ d.createElement(U, null, /* @__PURE__ */ d.createElement(yX, {
      props: t,
      data: x
    }));
  }), /* @__PURE__ */ d.createElement(bi, {
    label: t.label
  }), t.children);
}
function bX(e) {
  var t = d.useRef(null);
  return /* @__PURE__ */ d.createElement(gX, {
    previousRectanglesRef: t,
    props: e
  });
}
var $j = 0, xX = (e, t) => {
  var r = Array.isArray(e.value) ? e.value[1] : e.value;
  return {
    x: e.x,
    y: e.y,
    value: r,
    // @ts-expect-error getValueByDataKey does not validate the output type
    errorVal: G(e, t)
  };
};
class wX extends d.PureComponent {
  render() {
    var {
      hide: t,
      data: r,
      dataKey: n,
      className: i,
      xAxisId: a,
      yAxisId: o,
      needClip: l,
      background: u,
      id: s
    } = this.props;
    if (t || r == null)
      return null;
    var c = Y("recharts-bar", i), f = s;
    return /* @__PURE__ */ d.createElement(U, {
      className: c,
      id: s
    }, l && /* @__PURE__ */ d.createElement("defs", null, /* @__PURE__ */ d.createElement(Yd, {
      clipPathId: f,
      xAxisId: a,
      yAxisId: o
    })), /* @__PURE__ */ d.createElement(U, {
      className: "recharts-bar-rectangles",
      clipPath: l ? "url(#clipPath-".concat(f, ")") : void 0
    }, /* @__PURE__ */ d.createElement(vX, {
      data: r,
      dataKey: n,
      background: u,
      allOtherBarProps: this.props
    }), /* @__PURE__ */ d.createElement(bX, this.props)));
  }
}
var PX = {
  activeBar: !1,
  animationBegin: 0,
  animationDuration: 400,
  animationEasing: "ease",
  background: !1,
  hide: !1,
  isAnimationActive: "auto",
  label: !1,
  legendType: "rect",
  minPointSize: $j,
  xAxisId: 0,
  yAxisId: 0,
  zIndex: ie.bar
};
function OX(e) {
  var {
    xAxisId: t,
    yAxisId: r,
    hide: n,
    legendType: i,
    minPointSize: a,
    activeBar: o,
    animationBegin: l,
    animationDuration: u,
    animationEasing: s,
    isAnimationActive: c
  } = e, {
    needClip: f
  } = Yu(t, r), v = Ln(), p = me(), h = Io(e.children, sa), y = T((b) => G7(b, e.id, p, h));
  if (v !== "vertical" && v !== "horizontal")
    return null;
  var g, m = y == null ? void 0 : y[0];
  return m == null || m.height == null || m.width == null ? g = 0 : g = v === "vertical" ? m.height / 2 : m.width / 2, /* @__PURE__ */ d.createElement(i0, {
    xAxisId: t,
    yAxisId: r,
    data: y,
    dataPointFormatter: xX,
    errorBarOffset: g
  }, /* @__PURE__ */ d.createElement(wX, Mn({}, e, {
    layout: v,
    needClip: f,
    data: y,
    xAxisId: t,
    yAxisId: r,
    hide: n,
    legendType: i,
    minPointSize: a,
    activeBar: o,
    animationBegin: l,
    animationDuration: u,
    animationEasing: s,
    isAnimationActive: c
  })));
}
function SX(e) {
  var {
    layout: t,
    barSettings: {
      dataKey: r,
      minPointSize: n
    },
    pos: i,
    bandSize: a,
    xAxis: o,
    yAxis: l,
    xAxisTicks: u,
    yAxisTicks: s,
    stackedData: c,
    displayedData: f,
    offset: v,
    cells: p,
    parentViewBox: h,
    dataStartIndex: y
  } = e, g = t === "horizontal" ? l : o, m = c ? g.scale.domain() : null, b = kA({
    numericAxis: g
  }), x = g.scale(b);
  return f.map((w, P) => {
    var O, S, E, k, _, I;
    if (c) {
      var j = c[P + y];
      if (j == null)
        return null;
      O = AA(j, m);
    } else
      O = G(w, r), Array.isArray(O) || (O = [b, O]);
    var z = T7(n, $j)(O[1], P);
    if (t === "horizontal") {
      var N, [R, V] = [l.scale(O[0]), l.scale(O[1])];
      S = Rc({
        axis: o,
        ticks: u,
        bandSize: a,
        offset: i.offset,
        entry: w,
        index: P
      }), E = (N = V ?? R) !== null && N !== void 0 ? N : void 0, k = i.size;
      var H = R - V;
      if (_ = Pt(H) ? 0 : H, I = {
        x: S,
        y: v.top,
        width: k,
        height: v.height
      }, Math.abs(z) > 0 && Math.abs(_) < Math.abs(z)) {
        var C = We(_ || z) * (Math.abs(z) - Math.abs(_));
        E -= C, _ += C;
      }
    } else {
      var [D, F] = [o.scale(O[0]), o.scale(O[1])];
      if (S = D, E = Rc({
        axis: l,
        ticks: s,
        bandSize: a,
        offset: i.offset,
        entry: w,
        index: P
      }), k = F - D, _ = i.size, I = {
        x: v.left,
        y: E,
        width: v.width,
        height: _
      }, Math.abs(z) > 0 && Math.abs(k) < Math.abs(z)) {
        var Z = We(k || z) * (Math.abs(z) - Math.abs(k));
        k += Z;
      }
    }
    if (S == null || E == null || k == null || _ == null)
      return null;
    var Q = St(St({}, w), {}, {
      stackedBarStart: x,
      x: S,
      y: E,
      width: k,
      height: _,
      value: c ? O : O[1],
      payload: w,
      background: I,
      tooltipPosition: {
        x: S + k / 2,
        y: E + _ / 2
      },
      parentViewBox: h
    }, p && p[P] && p[P].props);
    return Q;
  }).filter(Boolean);
}
function EX(e) {
  var t = ee(e, PX), r = J7(t.stackId), n = me();
  return /* @__PURE__ */ d.createElement(on, {
    id: t.id,
    type: "bar"
  }, (i) => /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(Kd, {
    legendPayload: fX(t)
  }), /* @__PURE__ */ d.createElement(dX, {
    dataKey: t.dataKey,
    stroke: t.stroke,
    strokeWidth: t.strokeWidth,
    fill: t.fill,
    name: t.name,
    hide: t.hide,
    unit: t.unit,
    tooltipType: t.tooltipType,
    id: i
  }), /* @__PURE__ */ d.createElement(Wd, {
    type: "bar",
    id: i,
    data: void 0,
    xAxisId: t.xAxisId,
    yAxisId: t.yAxisId,
    zAxisId: 0,
    dataKey: t.dataKey,
    stackId: r,
    hide: t.hide,
    barSize: t.barSize,
    minPointSize: t.minPointSize,
    maxBarSize: t.maxBarSize,
    isPanorama: n
  }), /* @__PURE__ */ d.createElement(pe, {
    zIndex: t.zIndex
  }, /* @__PURE__ */ d.createElement(OX, Mn({}, t, {
    id: i
  })))));
}
var AX = /* @__PURE__ */ d.memo(EX, Mo);
AX.displayName = "Bar";
var kX = ["option", "isActive"];
function hl() {
  return hl = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, hl.apply(null, arguments);
}
function _X(e, t) {
  if (e == null) return {};
  var r, n, i = IX(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function IX(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function jX(e) {
  var {
    option: t,
    isActive: r
  } = e, n = _X(e, kX);
  return typeof t == "string" ? /* @__PURE__ */ d.createElement(Ji, hl({
    option: /* @__PURE__ */ d.createElement(Yf, hl({
      type: t
    }, n)),
    isActive: r,
    shapeType: "symbols"
  }, n)) : /* @__PURE__ */ d.createElement(Ji, hl({
    option: t,
    isActive: r,
    shapeType: "symbols"
  }, n));
}
var CX = (e, t, r, n, i, a, o) => Kt(e, "xAxis", t, o), TX = (e, t, r, n, i, a, o) => gr(e, "xAxis", t, o), MX = (e, t, r, n, i, a, o) => Kt(e, "yAxis", r, o), DX = (e, t, r, n, i, a, o) => gr(e, "yAxis", r, o), NX = (e, t, r, n) => aF(e, "zAxis", n, !1), $X = (e, t, r, n, i) => i, LX = (e, t, r, n, i, a) => a, RX = (e, t, r, n, i, a, o) => bd(e, void 0, void 0, o), zX = A([Po, $X], (e, t) => e.filter((r) => r.type === "scatter").find((r) => r.id === t)), BX = A([RX, CX, TX, MX, DX, NX, zX, LX], (e, t, r, n, i, a, o, l) => {
  var {
    chartData: u,
    dataStartIndex: s,
    dataEndIndex: c
  } = e;
  if (o != null) {
    var f;
    if ((o == null ? void 0 : o.data) != null && o.data.length > 0 ? f = o.data : f = u == null ? void 0 : u.slice(s, c + 1), !(f == null || t == null || n == null || r == null || i == null || (r == null ? void 0 : r.length) === 0 || (i == null ? void 0 : i.length) === 0))
      return eY({
        displayedData: f,
        xAxis: t,
        yAxis: n,
        zAxis: a,
        scatterSettings: o,
        xAxisTicks: r,
        yAxisTicks: i,
        cells: l
      });
  }
}), FX = ["id"], KX = ["onMouseEnter", "onClick", "onMouseLeave"], WX = ["animationBegin", "animationDuration", "animationEasing", "hide", "isAnimationActive", "legendType", "lineJointType", "lineType", "shape", "xAxisId", "yAxisId", "zAxisId"];
function Xh(e, t) {
  if (e == null) return {};
  var r, n, i = UX(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function UX(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function ta() {
  return ta = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, ta.apply(null, arguments);
}
function y1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function $t(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? y1(Object(r), !0).forEach(function(n) {
      VX(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : y1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function VX(e, t, r) {
  return (t = HX(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function HX(e) {
  var t = XX(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function XX(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var YX = (e) => {
  var {
    dataKey: t,
    name: r,
    fill: n,
    legendType: i,
    hide: a
  } = e;
  return [{
    inactive: a,
    dataKey: t,
    type: i,
    color: n,
    value: ir(r, t),
    payload: e
  }];
}, GX = /* @__PURE__ */ d.memo((e) => {
  var {
    dataKey: t,
    points: r,
    stroke: n,
    strokeWidth: i,
    fill: a,
    name: o,
    hide: l,
    tooltipType: u,
    id: s
  } = e, c = {
    dataDefinedOnItem: r == null ? void 0 : r.map((f) => f.tooltipPayload),
    positions: r == null ? void 0 : r.map((f) => f.tooltipPosition),
    settings: {
      stroke: n,
      strokeWidth: i,
      fill: a,
      nameKey: void 0,
      dataKey: t,
      name: ir(o, t),
      hide: l,
      type: u,
      color: a,
      unit: "",
      // why doesn't Scatter support unit?
      graphicalItemId: s
    }
  };
  return /* @__PURE__ */ d.createElement(an, {
    tooltipEntrySettings: c
  });
});
function qX(e) {
  var {
    points: t,
    props: r
  } = e, {
    line: n,
    lineType: i,
    lineJointType: a
  } = r;
  if (!n)
    return null;
  var o = re(r), l = er(n), u, s;
  if (i === "joint")
    u = t.map((g) => {
      var m, b;
      return {
        x: (m = g.cx) !== null && m !== void 0 ? m : null,
        y: (b = g.cy) !== null && b !== void 0 ? b : null
      };
    });
  else if (i === "fitting") {
    var {
      xmin: c,
      xmax: f,
      a: v,
      b: p
    } = TD(t), h = (g) => v * g + p;
    u = [{
      x: c,
      y: h(c)
    }, {
      x: f,
      y: h(f)
    }];
  }
  var y = $t($t($t({}, o), {}, {
    // @ts-expect-error customLineProps is contributing unknown props
    fill: "none",
    // @ts-expect-error customLineProps is contributing unknown props
    stroke: o && o.fill
  }, l), {}, {
    // @ts-expect-error linePoints is used before it is assigned (???)
    points: u
  });
  return /* @__PURE__ */ d.isValidElement(n) ? s = /* @__PURE__ */ d.cloneElement(n, y) : typeof n == "function" ? s = n(y) : s = /* @__PURE__ */ d.createElement(Ri, ta({}, y, {
    type: a
  })), /* @__PURE__ */ d.createElement(U, {
    className: "recharts-scatter-line",
    key: "recharts-scatter-line"
  }, s);
}
function ZX(e) {
  var {
    showLabels: t,
    points: r,
    children: n
  } = e, i = vo(), a = d.useMemo(() => r == null ? void 0 : r.map((o) => {
    var l, u, s = {
      /*
       * Scatter label uses x and y as the reference point for the label,
       * not cx and cy.
       */
      x: (l = o.x) !== null && l !== void 0 ? l : 0,
      /*
       * Scatter label uses x and y as the reference point for the label,
       * not cx and cy.
       */
      y: (u = o.y) !== null && u !== void 0 ? u : 0,
      width: o.width,
      height: o.height,
      lowerWidth: o.width,
      upperWidth: o.width
    };
    return $t($t({}, s), {}, {
      /*
       * Here we put undefined because Scatter shows two values usually, one for X and one for Y.
       * LabelList will see this undefined and will use its own `dataKey` prop to determine which value to show,
       * using the payload below.
       */
      value: void 0,
      payload: o.payload,
      viewBox: s,
      parentViewBox: i,
      fill: void 0
    });
  }), [i, r]);
  return /* @__PURE__ */ d.createElement(_o, {
    value: t ? a : void 0
  }, n);
}
function QX(e) {
  var {
    points: t,
    allOtherScatterProps: r
  } = e, {
    shape: n,
    activeShape: i,
    dataKey: a
  } = r, {
    id: o
  } = r, l = Xh(r, FX), u = T(Qr), {
    onMouseEnter: s,
    onClick: c,
    onMouseLeave: f
  } = r, v = Xh(r, KX), p = jo(s, a, o), h = Co(f), y = To(c, a, o);
  if (!UD(t))
    return null;
  var g = re(l);
  return /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(qX, {
    points: t,
    props: l
  }), t.map((m, b) => {
    var x = i != null && i !== !1, w = x && u === String(b), P = x && w ? i : n, O = $t($t($t({}, g), m), {}, {
      [Py]: b,
      [Oy]: String(o)
    });
    return /* @__PURE__ */ d.createElement(pe, {
      key: "symbol-".concat(m == null ? void 0 : m.cx, "-").concat(m == null ? void 0 : m.cy, "-").concat(m == null ? void 0 : m.size, "-").concat(b),
      zIndex: w ? ie.activeDot : void 0
    }, /* @__PURE__ */ d.createElement(U, ta({
      className: "recharts-scatter-symbol"
    }, Nr(v, m, b), {
      // @ts-expect-error the types need a bit of attention
      onMouseEnter: p(m, b),
      onMouseLeave: h(m, b),
      onClick: y(m, b)
    }), /* @__PURE__ */ d.createElement(jX, ta({
      option: P,
      isActive: w
    }, O))));
  }));
}
function JX(e) {
  var {
    previousPointsRef: t,
    props: r
  } = e, {
    points: n,
    isAnimationActive: i,
    animationBegin: a,
    animationDuration: o,
    animationEasing: l
  } = r, u = t.current, s = en(r, "recharts-scatter-"), [c, f] = d.useState(!1), v = d.useCallback(() => {
    f(!1);
  }, []), p = d.useCallback(() => {
    f(!0);
  }, []), h = !c;
  return /* @__PURE__ */ d.createElement(ZX, {
    showLabels: h,
    points: n
  }, r.children, /* @__PURE__ */ d.createElement(Jr, {
    animationId: s,
    begin: a,
    duration: o,
    isActive: i,
    easing: l,
    onAnimationEnd: v,
    onAnimationStart: p,
    key: s
  }, (y) => {
    var g = y === 1 ? n : n == null ? void 0 : n.map((m, b) => {
      var x = u && u[b];
      return x ? $t($t({}, m), {}, {
        cx: m.cx == null ? void 0 : X(x.cx, m.cx, y),
        cy: m.cy == null ? void 0 : X(x.cy, m.cy, y),
        size: X(x.size, m.size, y)
      }) : $t($t({}, m), {}, {
        size: X(0, m.size, y)
      });
    });
    return y > 0 && (t.current = g), /* @__PURE__ */ d.createElement(U, null, /* @__PURE__ */ d.createElement(QX, {
      points: g,
      allOtherScatterProps: r,
      showLabels: h
    }));
  }), /* @__PURE__ */ d.createElement(bi, {
    label: r.label
  }));
}
function eY(e) {
  var {
    displayedData: t,
    xAxis: r,
    yAxis: n,
    zAxis: i,
    scatterSettings: a,
    xAxisTicks: o,
    yAxisTicks: l,
    cells: u
  } = e, s = oe(r.dataKey) ? a.dataKey : r.dataKey, c = oe(n.dataKey) ? a.dataKey : n.dataKey, f = i && i.dataKey, v = i ? i.range : gn.range, p = v && v[0], h = r.scale.bandwidth ? r.scale.bandwidth() : 0, y = n.scale.bandwidth ? n.scale.bandwidth() : 0;
  return t.map((g, m) => {
    var b = G(g, s), x = G(g, c), w = !oe(f) && G(g, f) || "-", P = [{
      name: oe(r.dataKey) ? a.name : r.name || String(r.dataKey),
      unit: r.unit || "",
      // @ts-expect-error getValueByDataKey does not validate the output type
      value: b,
      payload: g,
      dataKey: s,
      type: a.tooltipType
    }, {
      name: oe(n.dataKey) ? a.name : n.name || String(n.dataKey),
      unit: n.unit || "",
      // @ts-expect-error getValueByDataKey does not validate the output type
      value: x,
      payload: g,
      dataKey: c,
      type: a.tooltipType
    }];
    w !== "-" && P.push({
      // @ts-expect-error name prop should not have dataKey in it
      name: i.name || i.dataKey,
      unit: i.unit || "",
      // @ts-expect-error getValueByDataKey does not validate the output type
      value: w,
      payload: g,
      dataKey: f,
      type: a.tooltipType
    });
    var O = Za({
      axis: r,
      ticks: o,
      bandSize: h,
      entry: g,
      index: m,
      dataKey: s
    }), S = Za({
      axis: n,
      ticks: l,
      bandSize: y,
      entry: g,
      index: m,
      dataKey: c
    }), E = w !== "-" ? i.scale(w) : p, k = Math.sqrt(Math.max(E, 0) / Math.PI);
    return $t($t({}, g), {}, {
      cx: O,
      cy: S,
      x: O == null ? void 0 : O - k,
      y: S == null ? void 0 : S - k,
      width: 2 * k,
      height: 2 * k,
      size: E,
      node: {
        x: b,
        y: x,
        z: w
      },
      tooltipPayload: P,
      tooltipPosition: {
        x: O,
        y: S
      },
      payload: g
    }, u && u[m] && u[m].props);
  });
}
var tY = (e, t, r) => ({
  x: e.cx,
  y: e.cy,
  value: Number(r === "x" ? e.node.x : e.node.y),
  // @ts-expect-error getValueByDataKey does not validate the output type
  errorVal: G(e, t)
});
function rY(e) {
  var {
    hide: t,
    points: r,
    className: n,
    needClip: i,
    xAxisId: a,
    yAxisId: o,
    id: l
  } = e, u = d.useRef(null);
  if (t)
    return null;
  var s = Y("recharts-scatter", n), c = l;
  return /* @__PURE__ */ d.createElement(pe, {
    zIndex: e.zIndex
  }, /* @__PURE__ */ d.createElement(U, {
    className: s,
    clipPath: i ? "url(#clipPath-".concat(c, ")") : void 0,
    id: l
  }, i && /* @__PURE__ */ d.createElement("defs", null, /* @__PURE__ */ d.createElement(Yd, {
    clipPathId: c,
    xAxisId: a,
    yAxisId: o
  })), /* @__PURE__ */ d.createElement(i0, {
    xAxisId: a,
    yAxisId: o,
    data: r,
    dataPointFormatter: tY,
    errorBarOffset: 0
  }, /* @__PURE__ */ d.createElement(U, {
    key: "recharts-scatter-symbols"
  }, /* @__PURE__ */ d.createElement(JX, {
    props: e,
    previousPointsRef: u
  })))));
}
var Lj = {
  xAxisId: 0,
  yAxisId: 0,
  zAxisId: 0,
  label: !1,
  line: !1,
  legendType: "circle",
  lineType: "joint",
  lineJointType: "linear",
  shape: "circle",
  hide: !1,
  isAnimationActive: "auto",
  animationBegin: 0,
  animationDuration: 400,
  animationEasing: "linear",
  zIndex: ie.scatter
};
function nY(e) {
  var t = ee(e, Lj), {
    animationBegin: r,
    animationDuration: n,
    animationEasing: i,
    hide: a,
    isAnimationActive: o,
    legendType: l,
    lineJointType: u,
    lineType: s,
    shape: c,
    xAxisId: f,
    yAxisId: v,
    zAxisId: p
  } = t, h = Xh(t, WX), {
    needClip: y
  } = Yu(f, v), g = d.useMemo(() => Io(e.children, sa), [e.children]), m = me(), b = T((x) => BX(x, f, v, p, e.id, g, m));
  return y == null || b == null ? null : /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(GX, {
    dataKey: e.dataKey,
    points: b,
    stroke: e.stroke,
    strokeWidth: e.strokeWidth,
    fill: e.fill,
    name: e.name,
    hide: e.hide,
    tooltipType: e.tooltipType,
    id: e.id
  }), /* @__PURE__ */ d.createElement(rY, ta({}, h, {
    xAxisId: f,
    yAxisId: v,
    zAxisId: p,
    lineType: s,
    lineJointType: u,
    legendType: l,
    shape: c,
    hide: a,
    isAnimationActive: o,
    animationBegin: r,
    animationDuration: n,
    animationEasing: i,
    points: b,
    needClip: y
  })));
}
function iY(e) {
  var t = ee(e, Lj), r = me();
  return /* @__PURE__ */ d.createElement(on, {
    id: t.id,
    type: "scatter"
  }, (n) => /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(Kd, {
    legendPayload: YX(t)
  }), /* @__PURE__ */ d.createElement(Wd, {
    type: "scatter",
    id: n,
    data: t.data,
    xAxisId: t.xAxisId,
    yAxisId: t.yAxisId,
    zAxisId: t.zAxisId,
    dataKey: t.dataKey,
    hide: t.hide,
    name: t.name,
    tooltipType: t.tooltipType,
    isPanorama: r
  }), /* @__PURE__ */ d.createElement(nY, ta({}, t, {
    id: n
  }))));
}
var aY = /* @__PURE__ */ d.memo(iY, Mo);
aY.displayName = "Scatter";
var oY = ["domain", "range"], lY = ["domain", "range"];
function g1(e, t) {
  if (e == null) return {};
  var r, n, i = uY(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function uY(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function b1(e, t) {
  return e === t ? !0 : Array.isArray(e) && e.length === 2 && Array.isArray(t) && t.length === 2 ? e[0] === t[0] && e[1] === t[1] : !1;
}
function Rj(e, t) {
  if (e === t)
    return !0;
  var {
    domain: r,
    range: n
  } = e, i = g1(e, oY), {
    domain: a,
    range: o
  } = t, l = g1(t, lY);
  return !b1(r, a) || !b1(n, o) ? !1 : Mo(i, l);
}
var sY = ["dangerouslySetInnerHTML", "ticks", "scale"], cY = ["id", "scale"];
function Yh() {
  return Yh = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Yh.apply(null, arguments);
}
function x1(e, t) {
  if (e == null) return {};
  var r, n, i = fY(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function fY(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function dY(e) {
  var t = J(), r = d.useRef(null);
  return d.useLayoutEffect(() => {
    r.current === null ? t(a8(e)) : r.current !== e && t(o8({
      prev: r.current,
      next: e
    })), r.current = e;
  }, [e, t]), d.useLayoutEffect(() => () => {
    r.current && (t(l8(r.current)), r.current = null);
  }, [t]), null;
}
var vY = (e) => {
  var {
    xAxisId: t,
    className: r
  } = e, n = T(Sy), i = me(), a = "xAxis", o = T((m) => T_(m, a, t, i)), l = T((m) => __(m, t)), u = T((m) => tF(m, t)), s = T((m) => c_(m, t));
  if (l == null || u == null || s == null)
    return null;
  var {
    dangerouslySetInnerHTML: c,
    ticks: f,
    scale: v
  } = e, p = x1(e, sY), {
    id: h,
    scale: y
  } = s, g = x1(s, cY);
  return /* @__PURE__ */ d.createElement(n0, Yh({}, p, g, {
    x: u.x,
    y: u.y,
    width: l.width,
    height: l.height,
    className: Y("recharts-".concat(a, " ").concat(a), r),
    viewBox: n,
    ticks: o,
    axisType: a
  }));
}, pY = {
  allowDataOverflow: et.allowDataOverflow,
  allowDecimals: et.allowDecimals,
  allowDuplicatedCategory: et.allowDuplicatedCategory,
  angle: et.angle,
  axisLine: Pn.axisLine,
  height: et.height,
  hide: !1,
  includeHidden: et.includeHidden,
  interval: et.interval,
  minTickGap: et.minTickGap,
  mirror: et.mirror,
  orientation: et.orientation,
  padding: et.padding,
  reversed: et.reversed,
  scale: et.scale,
  tick: et.tick,
  tickCount: et.tickCount,
  tickLine: Pn.tickLine,
  tickSize: Pn.tickSize,
  type: et.type,
  xAxisId: 0
}, hY = (e) => {
  var t = ee(e, pY);
  return /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(dY, {
    allowDataOverflow: t.allowDataOverflow,
    allowDecimals: t.allowDecimals,
    allowDuplicatedCategory: t.allowDuplicatedCategory,
    angle: t.angle,
    dataKey: t.dataKey,
    domain: t.domain,
    height: t.height,
    hide: t.hide,
    id: t.xAxisId,
    includeHidden: t.includeHidden,
    interval: t.interval,
    minTickGap: t.minTickGap,
    mirror: t.mirror,
    name: t.name,
    orientation: t.orientation,
    padding: t.padding,
    reversed: t.reversed,
    scale: t.scale,
    tick: t.tick,
    tickCount: t.tickCount,
    tickFormatter: t.tickFormatter,
    ticks: t.ticks,
    type: t.type,
    unit: t.unit
  }), /* @__PURE__ */ d.createElement(vY, t));
}, mY = /* @__PURE__ */ d.memo(hY, Rj);
mY.displayName = "XAxis";
var yY = ["dangerouslySetInnerHTML", "ticks", "scale"], gY = ["id", "scale"];
function Gh() {
  return Gh = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Gh.apply(null, arguments);
}
function w1(e, t) {
  if (e == null) return {};
  var r, n, i = bY(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function bY(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function xY(e) {
  var t = J(), r = d.useRef(null);
  return d.useLayoutEffect(() => {
    r.current === null ? t(u8(e)) : r.current !== e && t(s8({
      prev: r.current,
      next: e
    })), r.current = e;
  }, [e, t]), d.useLayoutEffect(() => () => {
    r.current && (t(c8(r.current)), r.current = null);
  }, [t]), null;
}
var wY = (e) => {
  var {
    yAxisId: t,
    className: r,
    width: n,
    label: i
  } = e, a = d.useRef(null), o = d.useRef(null), l = T(Sy), u = me(), s = J(), c = "yAxis", f = T((O) => I_(O, t)), v = T((O) => nF(O, t)), p = T((O) => T_(O, c, t, u)), h = T((O) => f_(O, t));
  if (d.useLayoutEffect(() => {
    if (!(n !== "auto" || !f || Rg(i) || /* @__PURE__ */ d.isValidElement(i) || h == null)) {
      var O = a.current;
      if (O) {
        var S = O.getCalculatedWidth();
        Math.round(f.width) !== Math.round(S) && s(p8({
          id: t,
          width: S
        }));
      }
    }
  }, [
    // The dependency on cartesianAxisRef.current is not needed because useLayoutEffect will run after every render.
    // The ref will be populated by then.
    // To re-run this effect when ticks change, we can depend on the ticks array from the store.
    p,
    f,
    s,
    i,
    t,
    n,
    h
  ]), f == null || v == null || h == null)
    return null;
  var {
    dangerouslySetInnerHTML: y,
    ticks: g,
    scale: m
  } = e, b = w1(e, yY), {
    id: x,
    scale: w
  } = h, P = w1(h, gY);
  return /* @__PURE__ */ d.createElement(n0, Gh({}, b, P, {
    ref: a,
    labelRef: o,
    x: v.x,
    y: v.y,
    tickTextProps: n === "auto" ? {
      width: void 0
    } : {
      width: n
    },
    width: f.width,
    height: f.height,
    className: Y("recharts-".concat(c, " ").concat(c), r),
    viewBox: l,
    ticks: p,
    axisType: c
  }));
}, PY = {
  allowDataOverflow: tt.allowDataOverflow,
  allowDecimals: tt.allowDecimals,
  allowDuplicatedCategory: tt.allowDuplicatedCategory,
  angle: tt.angle,
  axisLine: Pn.axisLine,
  hide: !1,
  includeHidden: tt.includeHidden,
  interval: tt.interval,
  minTickGap: tt.minTickGap,
  mirror: tt.mirror,
  orientation: tt.orientation,
  padding: tt.padding,
  reversed: tt.reversed,
  scale: tt.scale,
  tick: tt.tick,
  tickCount: tt.tickCount,
  tickLine: Pn.tickLine,
  tickSize: Pn.tickSize,
  type: tt.type,
  width: tt.width,
  yAxisId: 0
}, OY = (e) => {
  var t = ee(e, PY);
  return /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(xY, {
    interval: t.interval,
    id: t.yAxisId,
    scale: t.scale,
    type: t.type,
    domain: t.domain,
    allowDataOverflow: t.allowDataOverflow,
    dataKey: t.dataKey,
    allowDuplicatedCategory: t.allowDuplicatedCategory,
    allowDecimals: t.allowDecimals,
    tickCount: t.tickCount,
    padding: t.padding,
    includeHidden: t.includeHidden,
    reversed: t.reversed,
    ticks: t.ticks,
    width: t.width,
    orientation: t.orientation,
    mirror: t.mirror,
    hide: t.hide,
    unit: t.unit,
    name: t.name,
    angle: t.angle,
    minTickGap: t.minTickGap,
    tick: t.tick,
    tickFormatter: t.tickFormatter
  }), /* @__PURE__ */ d.createElement(wY, t));
}, SY = /* @__PURE__ */ d.memo(OY, Rj);
SY.displayName = "YAxis";
function EY(e) {
  var t = J(), r = d.useRef(null);
  return d.useLayoutEffect(() => {
    r.current === null ? t(f8(e)) : r.current !== e && t(d8({
      prev: r.current,
      next: e
    })), r.current = e;
  }, [e, t]), d.useLayoutEffect(() => () => {
    r.current && (t(v8(r.current)), r.current = null);
  }, [t]), null;
}
var AY = {
  zAxisId: 0,
  range: gn.range,
  scale: gn.scale,
  type: gn.type
};
function kY(e) {
  var t = ee(e, AY);
  return /* @__PURE__ */ d.createElement(EY, {
    domain: t.domain,
    id: t.zAxisId,
    dataKey: t.dataKey,
    name: t.name,
    unit: t.unit,
    range: t.range,
    scale: t.scale,
    type: t.type,
    allowDuplicatedCategory: gn.allowDuplicatedCategory,
    allowDataOverflow: gn.allowDataOverflow,
    reversed: gn.reversed,
    includeHidden: gn.includeHidden
  });
}
kY.displayName = "ZAxis";
var _Y = {
  begin: 0,
  duration: 1e3,
  easing: "ease",
  isActive: !0,
  canBegin: !0,
  onAnimationEnd: () => {
  },
  onAnimationStart: () => {
  }
};
function zj(e) {
  var t = ee(e, _Y), {
    animationId: r,
    from: n,
    to: i,
    attributeName: a,
    isActive: o,
    canBegin: l,
    duration: u,
    easing: s,
    begin: c,
    onAnimationEnd: f,
    onAnimationStart: v,
    children: p
  } = t, h = o === "auto" ? !po.isSsr : o, y = JA(r + a, t.animationManager), [g, m] = d.useState(() => h ? n : i), b = d.useRef(!1), x = d.useCallback(() => {
    m(n), v();
  }, [n, v]);
  if (d.useEffect(() => {
    if (!h || !l)
      return co;
    b.current = !0;
    var P = y.subscribe(m);
    return y.start([x, c, i, u, f]), () => {
      y.stop(), P && P(), f();
    };
  }, [h, l, u, s, c, x, f, y, i, n]), !h)
    return p({
      [a]: i
    });
  if (!l)
    return p({
      [a]: n
    });
  if (b.current) {
    var w = _y([a], u, s);
    return p({
      transition: w,
      [a]: g
    });
  }
  return p({
    [a]: n
  });
}
var IY = ["direction", "width", "dataKey", "isAnimationActive", "animationBegin", "animationDuration", "animationEasing"];
function Ql() {
  return Ql = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Ql.apply(null, arguments);
}
function P1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function O1(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? P1(Object(r), !0).forEach(function(n) {
      jY(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : P1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function jY(e, t, r) {
  return (t = CY(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function CY(e) {
  var t = TY(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function TY(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function MY(e, t) {
  if (e == null) return {};
  var r, n, i = DY(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function DY(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function NY(e) {
  var {
    direction: t,
    width: r,
    dataKey: n,
    isAnimationActive: i,
    animationBegin: a,
    animationDuration: o,
    animationEasing: l
  } = e, u = MY(e, IY), s = re(u), {
    data: c,
    dataPointFormatter: f,
    xAxisId: v,
    yAxisId: p,
    errorBarOffset: h
  } = i9(), y = g8(v), g = b8(p);
  if ((y == null ? void 0 : y.scale) == null || (g == null ? void 0 : g.scale) == null || c == null || t === "x" && y.type !== "number")
    return null;
  var m = c.map((b, x) => {
    var {
      x: w,
      y: P,
      value: O,
      errorVal: S
    } = f(b, n, t);
    if (!S || w == null || P == null)
      return null;
    var E = [], k, _;
    if (Array.isArray(S)) {
      var [I, j] = S;
      if (I == null || j == null)
        return null;
      k = I, _ = j;
    } else
      k = _ = S;
    if (t === "x") {
      var {
        scale: z
      } = y, N = P + h, R = N + r, V = N - r, H = z(O - k), C = z(O + _);
      E.push({
        x1: C,
        y1: R,
        x2: C,
        y2: V
      }), E.push({
        x1: H,
        y1: N,
        x2: C,
        y2: N
      }), E.push({
        x1: H,
        y1: R,
        x2: H,
        y2: V
      });
    } else if (t === "y") {
      var {
        scale: D
      } = g, F = w + h, Z = F - r, Q = F + r, Be = D(O - k), be = D(O + _);
      E.push({
        x1: Z,
        y1: be,
        x2: Q,
        y2: be
      }), E.push({
        x1: F,
        y1: Be,
        x2: F,
        y2: be
      }), E.push({
        x1: Z,
        y1: Be,
        x2: Q,
        y2: Be
      });
    }
    var Je = t === "x" ? "scaleX" : "scaleY", Xe = "".concat(w + h, "px ").concat(P + h, "px");
    return /* @__PURE__ */ d.createElement(U, Ql({
      className: "recharts-errorBar",
      key: "bar-".concat(w, "-").concat(P, "-").concat(O, "-").concat(x)
    }, s), E.map((fe, No) => {
      var M = i ? {
        transformOrigin: Xe
      } : void 0;
      return /* @__PURE__ */ d.createElement(zj, {
        animationId: "error-bar-".concat(t, "_").concat(fe.x1, "-").concat(fe.x2, "-").concat(fe.y1, "-").concat(fe.y2),
        from: "".concat(Je, "(0)"),
        to: "".concat(Je, "(1)"),
        attributeName: "transform",
        begin: a,
        easing: l,
        isActive: i,
        duration: o,
        key: "errorbar-".concat(x, "-").concat(fe.x1, "-").concat(fe.y1, "-").concat(fe.x2, "-").concat(fe.y2, "-").concat(No)
      }, (te) => /* @__PURE__ */ d.createElement("line", Ql({}, fe, {
        style: O1(O1({}, M), te)
      })));
    }));
  });
  return /* @__PURE__ */ d.createElement(U, {
    className: "recharts-errorBars"
  }, m);
}
function $Y(e) {
  var t = Ln();
  return e ?? (t != null && t === "horizontal" ? "y" : "x");
}
var LY = {
  stroke: "black",
  strokeWidth: 1.5,
  width: 5,
  offset: 0,
  isAnimationActive: !0,
  animationBegin: 0,
  animationDuration: 400,
  animationEasing: "ease-in-out",
  zIndex: ie.line
};
function RY(e) {
  var t = $Y(e.direction), r = ee(e, LY), {
    width: n,
    isAnimationActive: i,
    animationBegin: a,
    animationDuration: o,
    animationEasing: l,
    zIndex: u
  } = r;
  return /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(a9, {
    dataKey: r.dataKey,
    direction: t
  }), /* @__PURE__ */ d.createElement(pe, {
    zIndex: u
  }, /* @__PURE__ */ d.createElement(NY, Ql({}, r, {
    direction: t,
    width: n,
    isAnimationActive: i,
    animationBegin: a,
    animationDuration: o,
    animationEasing: l
  }))));
}
RY.displayName = "ErrorBar";
var zY = (e, t) => t, o0 = A([zY, q, ua, Qe, Y_, zn, hK, Ve], PK), l0 = (e) => {
  var t = e.currentTarget.getBoundingClientRect(), r = t.width / e.currentTarget.offsetWidth, n = t.height / e.currentTarget.offsetHeight;
  return {
    /*
     * Here it's important to use:
     * - event.clientX and event.clientY to get the mouse position relative to the viewport, including scroll.
     * - pageX and pageY are not used because they are relative to the whole document, and ignore scroll.
     * - rect.left and rect.top are used to get the position of the chart relative to the viewport.
     * - offsetX and offsetY are not used because they are relative to the offset parent
     *  which may or may not be the same as the clientX and clientY, depending on the position of the chart in the DOM
     *  and surrounding element styles. CSS position: relative, absolute, fixed, will change the offset parent.
     * - scaleX and scaleY are necessary for when the chart element is scaled using CSS `transform: scale(N)`.
     */
    chartX: Math.round((e.clientX - t.left) / r),
    chartY: Math.round((e.clientY - t.top) / n)
  };
}, Bj = mr("mouseClick"), Fj = hu();
Fj.startListening({
  actionCreator: Bj,
  effect: (e, t) => {
    var r = e.payload, n = o0(t.getState(), l0(r));
    (n == null ? void 0 : n.activeIndex) != null && t.dispatch(pF({
      activeIndex: n.activeIndex,
      activeDataKey: void 0,
      activeCoordinate: n.activeCoordinate
    }));
  }
});
var qh = mr("mouseMove"), Kj = hu(), Ts = null;
Kj.startListening({
  actionCreator: qh,
  effect: (e, t) => {
    var r = e.payload;
    Ts !== null && cancelAnimationFrame(Ts);
    var n = l0(r);
    Ts = requestAnimationFrame(() => {
      var i = t.getState(), a = kg(i, i.tooltip.settings.shared);
      if (a === "axis") {
        var o = o0(i, n);
        (o == null ? void 0 : o.activeIndex) != null ? t.dispatch(B_({
          activeIndex: o.activeIndex,
          activeDataKey: void 0,
          activeCoordinate: o.activeCoordinate
        })) : t.dispatch(z_());
      }
      Ts = null;
    });
  }
});
function BY(e, t) {
  return t instanceof HTMLElement ? "HTMLElement <".concat(t.tagName, ' class="').concat(t.className, '">') : t === window ? "global.window" : e === "children" && typeof t == "object" && t !== null ? "<<CHILDREN>>" : t;
}
var S1 = {
  accessibilityLayer: !0,
  barCategoryGap: "10%",
  barGap: 4,
  barSize: void 0,
  className: void 0,
  maxBarSize: void 0,
  stackOffset: "none",
  syncId: void 0,
  syncMethod: "index",
  baseValue: void 0,
  reverseStackOrder: !1
}, Wj = Ut({
  name: "rootProps",
  initialState: S1,
  reducers: {
    updateOptions: (e, t) => {
      var r;
      e.accessibilityLayer = t.payload.accessibilityLayer, e.barCategoryGap = t.payload.barCategoryGap, e.barGap = (r = t.payload.barGap) !== null && r !== void 0 ? r : S1.barGap, e.barSize = t.payload.barSize, e.maxBarSize = t.payload.maxBarSize, e.stackOffset = t.payload.stackOffset, e.syncId = t.payload.syncId, e.syncMethod = t.payload.syncMethod, e.className = t.payload.className, e.baseValue = t.payload.baseValue, e.reverseStackOrder = t.payload.reverseStackOrder;
    }
  }
}), FY = Wj.reducer, {
  updateOptions: KY
} = Wj.actions, Uj = Ut({
  name: "polarOptions",
  initialState: null,
  reducers: {
    updatePolarOptions: (e, t) => t.payload
  }
}), {
  updatePolarOptions: WY
} = Uj.actions, UY = Uj.reducer, Vj = mr("keyDown"), Hj = mr("focus"), u0 = hu();
u0.startListening({
  actionCreator: Vj,
  effect: (e, t) => {
    var r = t.getState(), n = r.rootProps.accessibilityLayer !== !1;
    if (n) {
      var {
        keyboardInteraction: i
      } = r.tooltip, a = e.payload;
      if (!(a !== "ArrowRight" && a !== "ArrowLeft" && a !== "Enter")) {
        var o = Ig(i, ko(r), ju(r), Du(r)), l = o == null ? -1 : Number(o);
        if (!(!Number.isFinite(l) || l < 0)) {
          var u = zn(r);
          if (a === "Enter") {
            var s = sf(r, "axis", "hover", String(i.index));
            t.dispatch(Th({
              active: !i.active,
              activeIndex: i.index,
              activeCoordinate: s
            }));
            return;
          }
          var c = oF(r), f = c === "left-to-right" ? 1 : -1, v = a === "ArrowRight" ? 1 : -1, p = l + v * f;
          if (!(u == null || p >= u.length || p < 0)) {
            var h = sf(r, "axis", "hover", String(p));
            t.dispatch(Th({
              active: !0,
              activeIndex: p.toString(),
              activeCoordinate: h
            }));
          }
        }
      }
    }
  }
});
u0.startListening({
  actionCreator: Hj,
  effect: (e, t) => {
    var r = t.getState(), n = r.rootProps.accessibilityLayer !== !1;
    if (n) {
      var {
        keyboardInteraction: i
      } = r.tooltip;
      if (!i.active && i.index == null) {
        var a = "0", o = sf(r, "axis", "hover", String(a));
        t.dispatch(Th({
          active: !0,
          activeIndex: a,
          activeCoordinate: o
        }));
      }
    }
  }
});
var lr = mr("externalEvent"), Xj = hu(), Zv = /* @__PURE__ */ new Map();
Xj.startListening({
  actionCreator: lr,
  effect: (e, t) => {
    var {
      handler: r,
      reactEvent: n
    } = e.payload;
    if (r != null) {
      n.persist();
      var i = n.type, a = Zv.get(i);
      a !== void 0 && cancelAnimationFrame(a);
      var o = requestAnimationFrame(() => {
        try {
          var l = t.getState(), u = {
            activeCoordinate: eK(l),
            activeDataKey: Dg(l),
            activeIndex: Qr(l),
            activeLabel: Z_(l),
            activeTooltipIndex: Qr(l),
            isTooltipActive: tK(l)
          };
          r(u, n);
        } finally {
          Zv.delete(i);
        }
      });
      Zv.set(i, o);
    }
  }
});
var VY = A([Eo], (e) => e.tooltipItemPayloads), HY = A([VY, Mu, (e, t) => t, (e, t, r) => r], (e, t, r, n) => {
  var i = e.find((l) => l.settings.graphicalItemId === n);
  if (i != null) {
    var {
      positions: a
    } = i;
    if (a != null) {
      var o = t(a, r);
      return o;
    }
  }
}), Yj = mr("touchMove"), Gj = hu();
Gj.startListening({
  actionCreator: Yj,
  effect: (e, t) => {
    var r = e.payload;
    if (!(r.touches == null || r.touches.length === 0)) {
      var n = t.getState(), i = kg(n, n.tooltip.settings.shared);
      if (i === "axis") {
        var a = r.touches[0];
        if (a == null)
          return;
        var o = o0(n, l0({
          clientX: a.clientX,
          clientY: a.clientY,
          currentTarget: r.currentTarget
        }));
        (o == null ? void 0 : o.activeIndex) != null && t.dispatch(B_({
          activeIndex: o.activeIndex,
          activeDataKey: void 0,
          activeCoordinate: o.activeCoordinate
        }));
      } else if (i === "item") {
        var l, u = r.touches[0];
        if (document.elementFromPoint == null || u == null)
          return;
        var s = document.elementFromPoint(u.clientX, u.clientY);
        if (!s || !s.getAttribute)
          return;
        var c = s.getAttribute(Py), f = (l = s.getAttribute(Oy)) !== null && l !== void 0 ? l : void 0, v = Ao(n).find((y) => y.id === f);
        if (c == null || v == null || f == null)
          return;
        var {
          dataKey: p
        } = v, h = HY(n, c, f);
        t.dispatch(So({
          activeDataKey: p,
          activeIndex: c,
          activeCoordinate: h,
          activeGraphicalItemId: f
        }));
      }
    }
  }
});
var XY = YE({
  brush: nV,
  cartesianAxis: h8,
  chartData: QK,
  errorBars: JH,
  graphicalItems: b6,
  layout: zN,
  legend: K$,
  options: XK,
  polarAxis: G4,
  polarOptions: UY,
  referenceElements: jV,
  rootProps: FY,
  tooltip: hF,
  zIndex: $K
}), YY = function(t) {
  var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "Chart";
  return fN({
    reducer: XY,
    // redux-toolkit v1 types are unhappy with the preloadedState type. Remove the `as any` when bumping to v2
    preloadedState: t,
    // @ts-expect-error redux-toolkit v1 types are unhappy with the middleware array. Remove this comment when bumping to v2
    middleware: (n) => {
      var i;
      return n({
        serializableCheck: !1,
        immutableCheck: !["commonjs", "es6", "production"].includes((i = "es6") !== null && i !== void 0 ? i : "")
      }).concat([Fj.middleware, Kj.middleware, u0.middleware, Xj.middleware, Gj.middleware]);
    },
    /*
     * I can't find out how to satisfy typescript here.
     * We return `EnhancerArray<[StoreEnhancer<{}, {}>, StoreEnhancer]>` from this function,
     * but the types say we should return `EnhancerArray<StoreEnhancer<{}, {}>`.
     * Looks like it's badly inferred generics, but it won't allow me to provide the correct type manually either.
     * So let's just ignore the error for now.
     */
    // @ts-expect-error mismatched generics
    enhancers: (n) => {
      var i = n;
      return typeof n == "function" && (i = n()), i.concat(sA({
        type: "raf"
      }));
    },
    devTools: {
      serialize: {
        replacer: BY
      },
      name: "recharts-".concat(r)
    }
  });
};
function Gd(e) {
  var {
    preloadedState: t,
    children: r,
    reduxStoreName: n
  } = e, i = me(), a = d.useRef(null);
  if (i)
    return r;
  a.current == null && (a.current = YY(t, n));
  var o = vy;
  return /* @__PURE__ */ d.createElement(T9, {
    context: o,
    store: a.current
  }, r);
}
function GY(e) {
  var {
    layout: t,
    margin: r
  } = e, n = J(), i = me();
  return d.useEffect(() => {
    i || (n($N(t)), n(PA(r)));
  }, [n, i, t, r]), null;
}
var qj = /* @__PURE__ */ d.memo(GY, Mo);
function Zj(e) {
  var t = J();
  return d.useEffect(() => {
    t(KY(e));
  }, [t, e]), null;
}
function E1(e) {
  var {
    zIndex: t,
    isPanorama: r
  } = e, n = d.useRef(null), i = J();
  return d.useLayoutEffect(() => (n.current && i(DK({
    zIndex: t,
    element: n.current,
    isPanorama: r
  })), () => {
    i(NK({
      zIndex: t,
      isPanorama: r
    }));
  }), [i, t, r]), /* @__PURE__ */ d.createElement("g", {
    tabIndex: -1,
    ref: n
  });
}
function A1(e) {
  var {
    children: t,
    isPanorama: r
  } = e, n = T(SK);
  if (!n || n.length === 0)
    return t;
  var i = n.filter((o) => o < 0), a = n.filter((o) => o > 0);
  return /* @__PURE__ */ d.createElement(d.Fragment, null, i.map((o) => /* @__PURE__ */ d.createElement(E1, {
    key: o,
    zIndex: o,
    isPanorama: r
  })), t, a.map((o) => /* @__PURE__ */ d.createElement(E1, {
    key: o,
    zIndex: o,
    isPanorama: r
  })));
}
var qY = ["children"];
function ZY(e, t) {
  if (e == null) return {};
  var r, n, i = QY(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function QY(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function Sf() {
  return Sf = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Sf.apply(null, arguments);
}
var JY = {
  width: "100%",
  height: "100%",
  /*
   * display: block is necessary here because the default for an SVG is display: inline,
   * which in some browsers (Chrome) adds a little bit of extra space above and below the SVG
   * to make space for the descender of letters like "g" and "y". This throws off the height calculation
   * and causes the container to grow indefinitely on each render with responsive=true.
   * Display: block removes that extra space.
   *
   * Interestingly, Firefox does not have this problem, but it doesn't hurt to add the style anyway.
   */
  display: "block"
}, eG = /* @__PURE__ */ d.forwardRef((e, t) => {
  var r = gu(), n = bu(), i = GA();
  if (!Bt(r) || !Bt(n))
    return null;
  var {
    children: a,
    otherAttributes: o,
    title: l,
    desc: u
  } = e, s, c;
  return o != null && (typeof o.tabIndex == "number" ? s = o.tabIndex : s = i ? 0 : void 0, typeof o.role == "string" ? c = o.role : c = i ? "application" : void 0), /* @__PURE__ */ d.createElement(ou, Sf({}, o, {
    title: l,
    desc: u,
    role: c,
    tabIndex: s,
    width: r,
    height: n,
    style: JY,
    ref: t
  }), a);
}), tG = (e) => {
  var {
    children: t
  } = e, r = T(yu);
  if (!r)
    return null;
  var {
    width: n,
    height: i,
    y: a,
    x: o
  } = r;
  return /* @__PURE__ */ d.createElement(ou, {
    width: n,
    height: i,
    x: o,
    y: a
  }, t);
}, k1 = /* @__PURE__ */ d.forwardRef((e, t) => {
  var {
    children: r
  } = e, n = ZY(e, qY), i = me();
  return i ? /* @__PURE__ */ d.createElement(tG, null, /* @__PURE__ */ d.createElement(A1, {
    isPanorama: !0
  }, r)) : /* @__PURE__ */ d.createElement(eG, Sf({
    ref: t
  }, n), /* @__PURE__ */ d.createElement(A1, {
    isPanorama: !1
  }, r));
});
function rG() {
  var e = J(), [t, r] = d.useState(null), n = T(e$);
  return d.useEffect(() => {
    if (t != null) {
      var i = t.getBoundingClientRect(), a = i.width / t.offsetWidth;
      se(a) && a !== n && e(RN(a));
    }
  }, [t, e, n]), r;
}
function _1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function nG(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? _1(Object(r), !0).forEach(function(n) {
      iG(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : _1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function iG(e, t, r) {
  return (t = aG(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function aG(e) {
  var t = oG(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function oG(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function ra() {
  return ra = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, ra.apply(null, arguments);
}
var lG = () => (lW(), null);
function Ef(e) {
  if (typeof e == "number")
    return e;
  if (typeof e == "string") {
    var t = parseFloat(e);
    if (!Number.isNaN(t))
      return t;
  }
  return 0;
}
var uG = /* @__PURE__ */ d.forwardRef((e, t) => {
  var r, n, i = d.useRef(null), [a, o] = d.useState({
    containerWidth: Ef((r = e.style) === null || r === void 0 ? void 0 : r.width),
    containerHeight: Ef((n = e.style) === null || n === void 0 ? void 0 : n.height)
  }), l = d.useCallback((s, c) => {
    o((f) => {
      var v = Math.round(s), p = Math.round(c);
      return f.containerWidth === v && f.containerHeight === p ? f : {
        containerWidth: v,
        containerHeight: p
      };
    });
  }, []), u = d.useCallback((s) => {
    if (typeof t == "function" && t(s), s != null && typeof ResizeObserver < "u") {
      var {
        width: c,
        height: f
      } = s.getBoundingClientRect();
      l(c, f);
      var v = (h) => {
        var {
          width: y,
          height: g
        } = h[0].contentRect;
        l(y, g);
      }, p = new ResizeObserver(v);
      p.observe(s), i.current = p;
    }
  }, [t, l]);
  return d.useEffect(() => () => {
    var s = i.current;
    s != null && s.disconnect();
  }, [l]), /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(xu, {
    width: a.containerWidth,
    height: a.containerHeight
  }), /* @__PURE__ */ d.createElement("div", ra({
    ref: u
  }, e)));
}), sG = /* @__PURE__ */ d.forwardRef((e, t) => {
  var {
    width: r,
    height: n
  } = e, [i, a] = d.useState({
    containerWidth: Ef(r),
    containerHeight: Ef(n)
  }), o = d.useCallback((u, s) => {
    a((c) => {
      var f = Math.round(u), v = Math.round(s);
      return c.containerWidth === f && c.containerHeight === v ? c : {
        containerWidth: f,
        containerHeight: v
      };
    });
  }, []), l = d.useCallback((u) => {
    if (typeof t == "function" && t(u), u != null) {
      var {
        width: s,
        height: c
      } = u.getBoundingClientRect();
      o(s, c);
    }
  }, [t, o]);
  return /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(xu, {
    width: i.containerWidth,
    height: i.containerHeight
  }), /* @__PURE__ */ d.createElement("div", ra({
    ref: l
  }, e)));
}), cG = /* @__PURE__ */ d.forwardRef((e, t) => {
  var {
    width: r,
    height: n
  } = e;
  return /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(xu, {
    width: r,
    height: n
  }), /* @__PURE__ */ d.createElement("div", ra({
    ref: t
  }, e)));
}), fG = /* @__PURE__ */ d.forwardRef((e, t) => {
  var {
    width: r,
    height: n
  } = e;
  return kn(r) || kn(n) ? /* @__PURE__ */ d.createElement(sG, ra({}, e, {
    ref: t
  })) : /* @__PURE__ */ d.createElement(cG, ra({}, e, {
    ref: t
  }));
});
function dG(e) {
  return e === !0 ? uG : fG;
}
var s0 = /* @__PURE__ */ d.forwardRef((e, t) => {
  var {
    children: r,
    className: n,
    height: i,
    onClick: a,
    onContextMenu: o,
    onDoubleClick: l,
    onMouseDown: u,
    onMouseEnter: s,
    onMouseLeave: c,
    onMouseMove: f,
    onMouseUp: v,
    onTouchEnd: p,
    onTouchMove: h,
    onTouchStart: y,
    style: g,
    width: m,
    responsive: b,
    dispatchTouchEvents: x = !0
  } = e, w = d.useRef(null), P = J(), [O, S] = d.useState(null), [E, k] = d.useState(null), _ = rG(), I = Ey(), j = (I == null ? void 0 : I.width) > 0 ? I.width : m, z = (I == null ? void 0 : I.height) > 0 ? I.height : i, N = d.useCallback((M) => {
    _(M), typeof t == "function" && t(M), S(M), k(M), M != null && (w.current = M);
  }, [_, t, S, k]), R = d.useCallback((M) => {
    P(Bj(M)), P(lr({
      handler: a,
      reactEvent: M
    }));
  }, [P, a]), V = d.useCallback((M) => {
    P(qh(M)), P(lr({
      handler: s,
      reactEvent: M
    }));
  }, [P, s]), H = d.useCallback((M) => {
    P(z_()), P(lr({
      handler: c,
      reactEvent: M
    }));
  }, [P, c]), C = d.useCallback((M) => {
    P(qh(M)), P(lr({
      handler: f,
      reactEvent: M
    }));
  }, [P, f]), D = d.useCallback(() => {
    P(Hj());
  }, [P]), F = d.useCallback((M) => {
    P(Vj(M.key));
  }, [P]), Z = d.useCallback((M) => {
    P(lr({
      handler: o,
      reactEvent: M
    }));
  }, [P, o]), Q = d.useCallback((M) => {
    P(lr({
      handler: l,
      reactEvent: M
    }));
  }, [P, l]), Be = d.useCallback((M) => {
    P(lr({
      handler: u,
      reactEvent: M
    }));
  }, [P, u]), be = d.useCallback((M) => {
    P(lr({
      handler: v,
      reactEvent: M
    }));
  }, [P, v]), Je = d.useCallback((M) => {
    P(lr({
      handler: y,
      reactEvent: M
    }));
  }, [P, y]), Xe = d.useCallback((M) => {
    x && P(Yj(M)), P(lr({
      handler: h,
      reactEvent: M
    }));
  }, [P, x, h]), fe = d.useCallback((M) => {
    P(lr({
      handler: p,
      reactEvent: M
    }));
  }, [P, p]), No = dG(b);
  return /* @__PURE__ */ d.createElement(Nd.Provider, {
    value: O
  }, /* @__PURE__ */ d.createElement(JS.Provider, {
    value: E
  }, /* @__PURE__ */ d.createElement(No, {
    width: j ?? (g == null ? void 0 : g.width),
    height: z ?? (g == null ? void 0 : g.height),
    className: Y("recharts-wrapper", n),
    style: nG({
      position: "relative",
      cursor: "default",
      width: j,
      height: z
    }, g),
    onClick: R,
    onContextMenu: Z,
    onDoubleClick: Q,
    onFocus: D,
    onKeyDown: F,
    onMouseDown: Be,
    onMouseEnter: V,
    onMouseLeave: H,
    onMouseMove: C,
    onMouseUp: be,
    onTouchEnd: fe,
    onTouchMove: Xe,
    onTouchStart: Je,
    ref: N
  }, /* @__PURE__ */ d.createElement(lG, null), r)));
}), vG = ["width", "height", "responsive", "children", "className", "style", "compact", "title", "desc"];
function pG(e, t) {
  if (e == null) return {};
  var r, n, i = hG(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function hG(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
var Qj = /* @__PURE__ */ d.forwardRef((e, t) => {
  var {
    width: r,
    height: n,
    responsive: i,
    children: a,
    className: o,
    style: l,
    compact: u,
    title: s,
    desc: c
  } = e, f = pG(e, vG), v = re(f);
  return u ? /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(xu, {
    width: r,
    height: n
  }), /* @__PURE__ */ d.createElement(k1, {
    otherAttributes: v,
    title: s,
    desc: c
  }, a)) : /* @__PURE__ */ d.createElement(s0, {
    className: o,
    style: l,
    width: r,
    height: n,
    responsive: i ?? !1,
    onClick: e.onClick,
    onMouseLeave: e.onMouseLeave,
    onMouseEnter: e.onMouseEnter,
    onMouseMove: e.onMouseMove,
    onMouseDown: e.onMouseDown,
    onMouseUp: e.onMouseUp,
    onContextMenu: e.onContextMenu,
    onDoubleClick: e.onDoubleClick,
    onTouchStart: e.onTouchStart,
    onTouchMove: e.onTouchMove,
    onTouchEnd: e.onTouchEnd
  }, /* @__PURE__ */ d.createElement(k1, {
    otherAttributes: v,
    title: s,
    desc: c,
    ref: t
  }, /* @__PURE__ */ d.createElement(CV, null, a)));
});
function Zh() {
  return Zh = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Zh.apply(null, arguments);
}
var mG = {
  top: 5,
  right: 5,
  bottom: 5,
  left: 5
}, yG = {
  accessibilityLayer: !0,
  barCategoryGap: "10%",
  barGap: 4,
  layout: "horizontal",
  margin: mG,
  responsive: !1,
  reverseStackOrder: !1,
  stackOffset: "none",
  syncMethod: "index"
}, Do = /* @__PURE__ */ d.forwardRef(function(t, r) {
  var n, i = ee(t.categoricalChartProps, yG), {
    chartName: a,
    defaultTooltipEventType: o,
    validateTooltipEventTypes: l,
    tooltipPayloadSearcher: u,
    categoricalChartProps: s
  } = t, c = {
    chartName: a,
    defaultTooltipEventType: o,
    validateTooltipEventTypes: l,
    tooltipPayloadSearcher: u,
    eventEmitter: void 0
  };
  return /* @__PURE__ */ d.createElement(Gd, {
    preloadedState: {
      options: c
    },
    reduxStoreName: (n = s.id) !== null && n !== void 0 ? n : a
  }, /* @__PURE__ */ d.createElement(sj, {
    chartData: s.data
  }), /* @__PURE__ */ d.createElement(qj, {
    layout: i.layout,
    margin: i.margin
  }), /* @__PURE__ */ d.createElement(Zj, {
    baseValue: i.baseValue,
    accessibilityLayer: i.accessibilityLayer,
    barCategoryGap: i.barCategoryGap,
    maxBarSize: i.maxBarSize,
    stackOffset: i.stackOffset,
    barGap: i.barGap,
    barSize: i.barSize,
    syncId: i.syncId,
    syncMethod: i.syncMethod,
    className: i.className,
    reverseStackOrder: i.reverseStackOrder
  }), /* @__PURE__ */ d.createElement(Qj, Zh({}, i, {
    ref: r
  })));
}), gG = ["axis"], OZ = /* @__PURE__ */ d.forwardRef((e, t) => /* @__PURE__ */ d.createElement(Do, {
  chartName: "LineChart",
  defaultTooltipEventType: "axis",
  validateTooltipEventTypes: gG,
  tooltipPayloadSearcher: Bn,
  categoricalChartProps: e,
  ref: t
})), bG = ["axis", "item"], SZ = /* @__PURE__ */ d.forwardRef((e, t) => /* @__PURE__ */ d.createElement(Do, {
  chartName: "BarChart",
  defaultTooltipEventType: "axis",
  validateTooltipEventTypes: bG,
  tooltipPayloadSearcher: Bn,
  categoricalChartProps: e,
  ref: t
}));
function xG(e) {
  var t = J();
  return d.useEffect(() => {
    t(WY(e));
  }, [t, e]), null;
}
var wG = ["layout"];
function Qh() {
  return Qh = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Qh.apply(null, arguments);
}
function PG(e, t) {
  if (e == null) return {};
  var r, n, i = OG(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function OG(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
var SG = {
  top: 5,
  right: 5,
  bottom: 5,
  left: 5
}, qd = {
  accessibilityLayer: !0,
  stackOffset: "none",
  barCategoryGap: "10%",
  barGap: 4,
  margin: SG,
  reverseStackOrder: !1,
  syncMethod: "index",
  layout: "radial",
  responsive: !1,
  cx: "50%",
  cy: "50%",
  innerRadius: 0,
  outerRadius: "80%"
}, c0 = /* @__PURE__ */ d.forwardRef(function(t, r) {
  var n, i = ee(t.categoricalChartProps, qd), {
    layout: a
  } = i, o = PG(i, wG), {
    chartName: l,
    defaultTooltipEventType: u,
    validateTooltipEventTypes: s,
    tooltipPayloadSearcher: c
  } = t, f = {
    chartName: l,
    defaultTooltipEventType: u,
    validateTooltipEventTypes: s,
    tooltipPayloadSearcher: c,
    eventEmitter: void 0
  };
  return /* @__PURE__ */ d.createElement(Gd, {
    preloadedState: {
      options: f
    },
    reduxStoreName: (n = i.id) !== null && n !== void 0 ? n : l
  }, /* @__PURE__ */ d.createElement(sj, {
    chartData: i.data
  }), /* @__PURE__ */ d.createElement(qj, {
    layout: a,
    margin: i.margin
  }), /* @__PURE__ */ d.createElement(Zj, {
    baseValue: void 0,
    accessibilityLayer: i.accessibilityLayer,
    barCategoryGap: i.barCategoryGap,
    maxBarSize: i.maxBarSize,
    stackOffset: i.stackOffset,
    barGap: i.barGap,
    barSize: i.barSize,
    syncId: i.syncId,
    syncMethod: i.syncMethod,
    className: i.className,
    reverseStackOrder: i.reverseStackOrder
  }), /* @__PURE__ */ d.createElement(xG, {
    cx: i.cx,
    cy: i.cy,
    startAngle: i.startAngle,
    endAngle: i.endAngle,
    innerRadius: i.innerRadius,
    outerRadius: i.outerRadius
  }), /* @__PURE__ */ d.createElement(Qj, Qh({}, o, {
    ref: r
  })));
});
function I1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function j1(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? I1(Object(r), !0).forEach(function(n) {
      EG(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : I1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function EG(e, t, r) {
  return (t = AG(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function AG(e) {
  var t = kG(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function kG(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var _G = ["item"], IG = j1(j1({}, qd), {}, {
  layout: "centric",
  startAngle: 0,
  endAngle: 360
}), EZ = /* @__PURE__ */ d.forwardRef((e, t) => {
  var r = ee(e, IG);
  return /* @__PURE__ */ d.createElement(c0, {
    chartName: "PieChart",
    defaultTooltipEventType: "item",
    validateTooltipEventTypes: _G,
    tooltipPayloadSearcher: Bn,
    categoricalChartProps: r,
    ref: t
  });
}), Jj = {}, eC = {}, tC = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r) {
    return typeof Buffer < "u" && Buffer.isBuffer(r);
  }
  e.isBuffer = t;
})(tC);
var rC = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  function t(r) {
    const n = r == null ? void 0 : r.constructor, i = typeof n == "function" ? n.prototype : Object.prototype;
    return r === i;
  }
  e.isPrototype = t;
})(rC);
var nC = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = cy;
  function r(n) {
    return t.isTypedArray(n);
  }
  e.isTypedArray = r;
})(nC);
var iC = {}, aC = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = Iy;
  function r(n) {
    const i = t.toFinite(n), a = i % 1;
    return a ? i - a : i;
  }
  e.toInteger = r;
})(aC);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = aC;
  function r(n, i) {
    if (n = t.toInteger(n), n < 1 || !Number.isSafeInteger(n))
      return [];
    const a = new Array(n);
    for (let o = 0; o < n; o++)
      a[o] = typeof i == "function" ? i(o) : o;
    return a;
  }
  e.times = r;
})(iC);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = tC, r = rC, n = fo, i = nC, a = iC;
  function o(c) {
    if (c == null)
      return [];
    switch (typeof c) {
      case "object":
      case "function":
        return n.isArrayLike(c) ? s(c) : r.isPrototype(c) ? u(c) : l(c);
      default:
        return l(Object(c));
    }
  }
  function l(c) {
    const f = [];
    for (const v in c)
      f.push(v);
    return f;
  }
  function u(c) {
    return l(c).filter((v) => v !== "constructor");
  }
  function s(c) {
    const f = a.times(c.length, (h) => `${h}`), v = new Set(f);
    t.isBuffer(c) && (v.add("offset"), v.add("parent")), i.isTypedArray(c) && (v.add("buffer"), v.add("byteLength"), v.add("byteOffset"));
    const p = l(c).filter((h) => !v.has(h));
    return Array.isArray(c) ? [...f, ...p] : [...f.filter((h) => Object.hasOwn(c, h)), ...p];
  }
  e.keysIn = o;
})(eC);
var oC = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = lu, r = Jm, n = uu, i = su, a = cu;
  function o(u, s) {
    if (u == null)
      return !0;
    switch (typeof s) {
      case "symbol":
      case "number":
      case "object": {
        if (Array.isArray(s))
          return l(u, s);
        if (typeof s == "number" ? s = i.toKey(s) : typeof s == "object" && (Object.is(s == null ? void 0 : s.valueOf(), -0) ? s = "-0" : s = String(s)), r.isUnsafeProperty(s))
          return !1;
        if ((u == null ? void 0 : u[s]) === void 0)
          return !0;
        try {
          return delete u[s], !0;
        } catch {
          return !1;
        }
      }
      case "string": {
        if ((u == null ? void 0 : u[s]) === void 0 && n.isDeepKey(s))
          return l(u, a.toPath(s));
        if (r.isUnsafeProperty(s))
          return !1;
        try {
          return delete u[s], !0;
        } catch {
          return !1;
        }
      }
    }
  }
  function l(u, s) {
    const c = s.length === 1 ? u : t.get(u, s.slice(0, -1)), f = s[s.length - 1];
    if ((c == null ? void 0 : c[f]) === void 0)
      return !0;
    if (r.isUnsafeProperty(f))
      return !1;
    try {
      return delete c[f], !0;
    } catch {
      return !1;
    }
  }
  e.unset = o;
})(oC);
var lC = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = ly;
  function r(n) {
    const i = [];
    for (; n; )
      i.push(...t.getSymbols(n)), n = Object.getPrototypeOf(n);
    return i;
  }
  e.getSymbolsIn = r;
})(lC);
var uC = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = fo;
  function r(n, i = 1) {
    const a = [], o = Math.floor(i);
    if (!t.isArrayLike(n))
      return a;
    const l = (u, s) => {
      for (let c = 0; c < u.length; c++) {
        const f = u[c];
        s < o && (Array.isArray(f) || f != null && f[Symbol.isConcatSpreadable] || f !== null && typeof f == "object" && Object.prototype.toString.call(f) === "[object Arguments]") ? Array.isArray(f) ? l(f, s + 1) : l(Array.from(f), s + 1) : a.push(f);
      }
    };
    return l(Array.from(n), 0), a;
  }
  e.flatten = r;
})(uC);
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = fy, r = eC, n = oC, i = lC, a = uu, o = uC, l = Hg;
  function u(v, ...p) {
    if (v == null)
      return {};
    p = o.flatten(p);
    const h = s(v, p);
    for (let y = 0; y < p.length; y++) {
      let g = p[y];
      switch (typeof g) {
        case "object": {
          Array.isArray(g) || (g = Array.from(g));
          for (let m = 0; m < g.length; m++) {
            const b = g[m];
            n.unset(h, b);
          }
          break;
        }
        case "string":
        case "symbol":
        case "number": {
          n.unset(h, g);
          break;
        }
      }
    }
    return h;
  }
  function s(v, p) {
    return p.some((y) => Array.isArray(y) || a.isDeepKey(y)) ? f(v) : c(v);
  }
  function c(v) {
    const p = {}, h = [...r.keysIn(v), ...i.getSymbolsIn(v)];
    for (let y = 0; y < h.length; y++) {
      const g = h[y];
      p[g] = v[g];
    }
    return p;
  }
  function f(v) {
    const p = {}, h = [...r.keysIn(v), ...i.getSymbolsIn(v)];
    for (let y = 0; y < h.length; y++) {
      const g = h[y];
      p[g] = t.cloneDeepWith(v[g], (m) => {
        if (!l.isPlainObject(m))
          return m;
      });
    }
    return p;
  }
  e.omit = u;
})(Jj);
var jG = Jj.omit;
const sC = /* @__PURE__ */ Wt(jG);
var CG = ["width", "height", "className", "style", "children", "type"];
function TG(e, t) {
  if (e == null) return {};
  var r, n, i = MG(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function MG(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function ao() {
  return ao = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, ao.apply(null, arguments);
}
function C1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Ae(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? C1(Object(r), !0).forEach(function(n) {
      ml(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : C1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function ml(e, t, r) {
  return (t = DG(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function DG(e) {
  var t = NG(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function NG(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var Af = "value", cC = (e, t) => {
  if (!(!e || !t))
    return Gr(e, t);
}, $G = function(t) {
  var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
  return "".concat(r, "children[").concat(t, "]");
}, LG = {
  chartName: "Treemap",
  defaultTooltipEventType: "item",
  validateTooltipEventTypes: ["item"],
  tooltipPayloadSearcher: cC,
  eventEmitter: void 0
}, qs = (e) => {
  var {
    depth: t,
    node: r,
    index: n,
    dataKey: i,
    nameKey: a,
    nestedActiveTooltipIndex: o
  } = e, l = t === 0 ? "" : $G(n, o), {
    children: u
  } = r, s = t + 1, c = u && u.length ? u.map((v, p) => qs({
    depth: s,
    node: v,
    index: p,
    dataKey: i,
    nameKey: a,
    nestedActiveTooltipIndex: l
  })) : null, f;
  return c && c.length ? f = c.reduce((v, p) => v + p[Af], 0) : f = Pt(r[i]) || r[i] <= 0 ? 0 : r[i], Ae(Ae({}, r), {}, {
    children: c,
    // @ts-expect-error getValueByDataKey does not validate the output type
    name: G(r, a, ""),
    [Af]: f,
    depth: t,
    index: n,
    tooltipIndex: l
  });
}, RG = (e) => ({
  x: e.x,
  y: e.y,
  width: e.width,
  height: e.height
}), zG = (e, t) => {
  var r = t < 0 ? 0 : t;
  return e.map((n) => {
    var i = n[Af] * r;
    return Ae(Ae({}, n), {}, {
      area: Pt(i) || i <= 0 ? 0 : i
    });
  });
}, BG = (e, t, r) => {
  var n = t * t, i = e.area * e.area, {
    min: a,
    max: o
  } = e.reduce((l, u) => ({
    min: Math.min(l.min, u.area),
    max: Math.max(l.max, u.area)
  }), {
    min: 1 / 0,
    max: 0
  });
  return i ? Math.max(n * o * r / i, i / (n * a * r)) : 1 / 0;
}, FG = (e, t, r, n) => {
  var i = t ? Math.round(e.area / t) : 0;
  (n || i > r.height) && (i = r.height);
  for (var a = r.x, o, l = 0, u = e.length; l < u; l++)
    o = e[l], o.x = a, o.y = r.y, o.height = i, o.width = Math.min(i ? Math.round(o.area / i) : 0, r.x + r.width - a), a += o.width;
  return o != null && (o.width += r.x + r.width - a), Ae(Ae({}, r), {}, {
    y: r.y + i,
    height: r.height - i
  });
}, KG = (e, t, r, n) => {
  var i = t ? Math.round(e.area / t) : 0;
  (n || i > r.width) && (i = r.width);
  for (var a = r.y, o, l = 0, u = e.length; l < u; l++)
    o = e[l], o.x = r.x, o.y = a, o.width = i, o.height = Math.min(i ? Math.round(o.area / i) : 0, r.y + r.height - a), a += o.height;
  return o && (o.height += r.y + r.height - a), Ae(Ae({}, r), {}, {
    x: r.x + i,
    width: r.width - i
  });
}, T1 = (e, t, r, n) => t === r.width ? FG(e, t, r, n) : KG(e, t, r, n), Zs = (e, t) => {
  var {
    children: r
  } = e;
  if (r && r.length) {
    var n = RG(e), i = [], a = 1 / 0, o, l, u = Math.min(n.width, n.height), s = zG(r, n.width * n.height / e[Af]), c = s.slice();
    for (i.area = 0; c.length > 0; )
      if (i.push(o = c[0]), i.area += o.area, l = BG(i, u, t), l <= a)
        c.shift(), a = l;
      else {
        var f, v;
        i.area -= (f = (v = i.pop()) === null || v === void 0 ? void 0 : v.area) !== null && f !== void 0 ? f : 0, n = T1(i, u, n, !1), u = Math.min(n.width, n.height), i.length = i.area = 0, a = 1 / 0;
      }
    return i.length && (n = T1(i, u, n, !0), i.length = i.area = 0), Ae(Ae({}, e), {}, {
      children: s.map((p) => Zs(p, t))
    });
  }
  return e;
}, Jh = {
  aspectRatio: 0.5 * (1 + Math.sqrt(5)),
  dataKey: "value",
  nameKey: "name",
  type: "flat",
  isAnimationActive: "auto",
  isUpdateAnimationActive: "auto",
  animationBegin: 0,
  animationDuration: 1500,
  animationEasing: "linear"
}, WG = {
  isAnimationFinished: !1,
  formatRoot: null,
  currentRoot: null,
  nestIndex: [],
  prevAspectRatio: Jh.aspectRatio,
  prevDataKey: Jh.dataKey
};
function UG(e) {
  var {
    content: t,
    nodeProps: r,
    type: n,
    colorPanel: i,
    onMouseEnter: a,
    onMouseLeave: o,
    onClick: l
  } = e;
  if (/* @__PURE__ */ d.isValidElement(t))
    return /* @__PURE__ */ d.createElement(U, {
      onMouseEnter: a,
      onMouseLeave: o,
      onClick: l
    }, /* @__PURE__ */ d.cloneElement(t, r));
  if (typeof t == "function")
    return /* @__PURE__ */ d.createElement(U, {
      onMouseEnter: a,
      onMouseLeave: o,
      onClick: l
    }, t(r));
  var {
    x: u,
    y: s,
    width: c,
    height: f,
    index: v
  } = r, p = null;
  c > 10 && f > 10 && r.children && n === "nest" && (p = /* @__PURE__ */ d.createElement(zg, {
    points: [{
      x: u + 2,
      y: s + f / 2
    }, {
      x: u + 6,
      y: s + f / 2 + 3
    }, {
      x: u + 2,
      y: s + f / 2 + 6
    }]
  }));
  var h = null, y = Ba(r.name);
  c > 20 && f > 20 && y.width < c && y.height < f && (h = /* @__PURE__ */ d.createElement("text", {
    x: u + 8,
    y: s + f / 2 + 7,
    fontSize: 14
  }, r.name));
  var g = i || t$;
  return /* @__PURE__ */ d.createElement("g", null, /* @__PURE__ */ d.createElement(Pu, ao({
    fill: r.depth < 2 ? g[v % g.length] : "rgba(255,255,255,0)",
    stroke: "#fff"
  }, sC(r, ["children"]), {
    onMouseEnter: a,
    onMouseLeave: o,
    onClick: l,
    "data-recharts-item-index": r.tooltipIndex
  })), p, h);
}
function VG(e) {
  var t = J(), r = {
    x: e.nodeProps.x + e.nodeProps.width / 2,
    y: e.nodeProps.y + e.nodeProps.height / 2
  }, n = () => {
    t(So({
      activeIndex: e.nodeProps.tooltipIndex,
      activeDataKey: e.dataKey,
      activeCoordinate: r,
      activeGraphicalItemId: e.id
    }));
  }, i = () => {
  }, a = () => {
    t(Md({
      activeIndex: e.nodeProps.tooltipIndex,
      activeDataKey: e.dataKey,
      activeCoordinate: r,
      activeGraphicalItemId: e.id
    }));
  };
  return /* @__PURE__ */ d.createElement(UG, ao({}, e, {
    onMouseEnter: n,
    onMouseLeave: i,
    onClick: a
  }));
}
var HG = /* @__PURE__ */ d.memo((e) => {
  var {
    dataKey: t,
    nameKey: r,
    stroke: n,
    fill: i,
    currentRoot: a,
    id: o
  } = e, l = {
    dataDefinedOnItem: a,
    positions: void 0,
    // TODO I think Treemap has the capability of computing positions and supporting defaultIndex? Except it doesn't yet
    settings: {
      stroke: n,
      strokeWidth: void 0,
      fill: i,
      dataKey: t,
      nameKey: r,
      name: void 0,
      // Each TreemapNode has its own name
      hide: !1,
      type: void 0,
      color: i,
      unit: "",
      graphicalItemId: o
    }
  };
  return /* @__PURE__ */ d.createElement(an, {
    tooltipEntrySettings: l
  });
}), XG = {
  top: 0,
  right: 0,
  bottom: 0,
  left: 0
};
function YG(e) {
  var {
    content: t,
    nodeProps: r,
    isLeaf: n,
    treemapProps: i,
    onNestClick: a
  } = e, {
    id: o,
    isAnimationActive: l,
    animationBegin: u,
    animationDuration: s,
    animationEasing: c,
    isUpdateAnimationActive: f,
    type: v,
    colorPanel: p,
    dataKey: h,
    onAnimationStart: y,
    onAnimationEnd: g,
    onMouseEnter: m,
    onClick: b,
    onMouseLeave: x
  } = i, {
    width: w,
    height: P,
    x: O,
    y: S
  } = r, E = -O - w, k = 0, _ = (R) => {
    (n || v === "nest") && typeof m == "function" && m(r, R);
  }, I = (R) => {
    (n || v === "nest") && typeof x == "function" && x(r, R);
  }, j = () => {
    v === "nest" && a(r), (n || v === "nest") && typeof b == "function" && b(r);
  }, z = d.useCallback(() => {
    typeof g == "function" && g();
  }, [g]), N = d.useCallback(() => {
    typeof y == "function" && y();
  }, [y]);
  return /* @__PURE__ */ d.createElement(zj, {
    animationId: "treemap-".concat(r.tooltipIndex),
    from: "translate(".concat(E, "px, ").concat(k, "px)"),
    to: "translate(0, 0)",
    attributeName: "transform",
    begin: u,
    easing: c,
    isActive: l,
    duration: s,
    onAnimationStart: N,
    onAnimationEnd: z
  }, (R) => /* @__PURE__ */ d.createElement(U, {
    onMouseEnter: _,
    onMouseLeave: I,
    onClick: j,
    style: Ae(Ae({}, R), {}, {
      transformOrigin: "".concat(O, " ").concat(S)
    })
  }, /* @__PURE__ */ d.createElement(VG, {
    id: o,
    content: t,
    dataKey: h,
    nodeProps: Ae(Ae({}, r), {}, {
      isAnimationActive: l,
      isUpdateAnimationActive: !f,
      width: w,
      height: P,
      x: O,
      y: S
    }),
    type: v,
    colorPanel: p
  })));
}
class fC extends d.PureComponent {
  constructor() {
    super(...arguments), ml(this, "state", Ae({}, WG)), ml(this, "handleClick", (t) => {
      var {
        onClick: r,
        type: n
      } = this.props;
      if (n === "nest" && t.children) {
        var {
          width: i,
          height: a,
          dataKey: o,
          nameKey: l,
          aspectRatio: u
        } = this.props, s = qs({
          depth: 0,
          node: Ae(Ae({}, t), {}, {
            x: 0,
            y: 0,
            width: i,
            height: a
          }),
          index: 0,
          dataKey: o,
          nameKey: l,
          // with Treemap nesting, should this continue nesting the index or start from empty string?
          nestedActiveTooltipIndex: t.tooltipIndex
        }), c = Zs(s, u), {
          nestIndex: f
        } = this.state;
        f.push(t), this.setState({
          formatRoot: c,
          currentRoot: s,
          nestIndex: f
        });
      }
      r && r(t);
    }), ml(this, "handleTouchMove", (t) => {
      var r = t.touches[0], n = document.elementFromPoint(r.clientX, r.clientY);
      if (!(!n || !n.getAttribute || this.state.formatRoot == null)) {
        var i = n.getAttribute("data-recharts-item-index"), a = cC(this.state.formatRoot, i);
        if (a) {
          var {
            dataKey: o,
            dispatch: l
          } = this.props, u = {
            x: a.x + a.width / 2,
            y: a.y + a.height / 2
          };
          l(So({
            activeIndex: i,
            activeDataKey: o,
            activeCoordinate: u,
            activeGraphicalItemId: this.props.id
          }));
        }
      }
    });
  }
  static getDerivedStateFromProps(t, r) {
    if (t.data !== r.prevData || t.type !== r.prevType || t.width !== r.prevWidth || t.height !== r.prevHeight || t.dataKey !== r.prevDataKey || t.aspectRatio !== r.prevAspectRatio) {
      var n = qs({
        depth: 0,
        // @ts-expect-error missing properties
        node: {
          children: t.data,
          x: 0,
          y: 0,
          width: t.width,
          height: t.height
        },
        index: 0,
        dataKey: t.dataKey,
        nameKey: t.nameKey
      }), i = Zs(n, t.aspectRatio);
      return Ae(Ae({}, r), {}, {
        formatRoot: i,
        currentRoot: n,
        nestIndex: [n],
        prevAspectRatio: t.aspectRatio,
        prevData: t.data,
        prevWidth: t.width,
        prevHeight: t.height,
        prevDataKey: t.dataKey,
        prevType: t.type
      });
    }
    return null;
  }
  handleNestIndex(t, r) {
    var {
      nestIndex: n
    } = this.state, {
      width: i,
      height: a,
      dataKey: o,
      nameKey: l,
      aspectRatio: u
    } = this.props, s = qs({
      depth: 0,
      node: Ae(Ae({}, t), {}, {
        x: 0,
        y: 0,
        width: i,
        height: a
      }),
      index: 0,
      dataKey: o,
      nameKey: l,
      // with Treemap nesting, should this continue nesting the index or start from empty string?
      nestedActiveTooltipIndex: t.tooltipIndex
    }), c = Zs(s, u);
    n = n.slice(0, r + 1), this.setState({
      formatRoot: c,
      currentRoot: t,
      nestIndex: n
    });
  }
  renderNode(t, r) {
    var {
      content: n,
      type: i
    } = this.props, a = Ae(Ae(Ae({}, re(this.props)), r), {}, {
      root: t
    }), o = !r.children || !r.children.length, {
      currentRoot: l
    } = this.state, u = ((l == null ? void 0 : l.children) || []).filter((s) => s.depth === r.depth && s.name === r.name);
    return !u.length && t.depth && i === "nest" ? null : /* @__PURE__ */ d.createElement(U, {
      key: "recharts-treemap-node-".concat(a.x, "-").concat(a.y, "-").concat(a.name),
      className: "recharts-treemap-depth-".concat(r.depth)
    }, /* @__PURE__ */ d.createElement(YG, {
      isLeaf: o,
      content: n,
      nodeProps: a,
      treemapProps: this.props,
      onNestClick: this.handleClick
    }), r.children && r.children.length ? r.children.map((s) => this.renderNode(r, s)) : null);
  }
  renderAllNodes() {
    var {
      formatRoot: t
    } = this.state;
    return t ? this.renderNode(t, t) : null;
  }
  // render nest treemap
  renderNestIndex() {
    var {
      nameKey: t,
      nestIndexContent: r
    } = this.props, {
      nestIndex: n
    } = this.state;
    return /* @__PURE__ */ d.createElement("div", {
      className: "recharts-treemap-nest-index-wrapper",
      style: {
        marginTop: "8px",
        textAlign: "center"
      }
    }, n.map((i, a) => {
      var o = Gr(i, t, "root"), l;
      return /* @__PURE__ */ d.isValidElement(r) && (l = /* @__PURE__ */ d.cloneElement(r, i, a)), typeof r == "function" ? l = r(i, a) : l = o, // eslint-disable-next-line jsx-a11y/click-events-have-key-events, jsx-a11y/no-static-element-interactions
      /* @__PURE__ */ d.createElement("div", {
        onClick: this.handleNestIndex.bind(this, i, a),
        key: "nest-index-".concat(Ya()),
        className: "recharts-treemap-nest-index-box",
        style: {
          cursor: "pointer",
          display: "inline-block",
          padding: "0 7px",
          background: "#000",
          color: "#fff",
          marginRight: "3px"
        }
      }, l);
    }));
  }
  render() {
    var t = this.props, {
      width: r,
      height: n,
      className: i,
      style: a,
      children: o,
      type: l
    } = t, u = TG(t, CG), s = re(u);
    return /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(HG, {
      dataKey: this.props.dataKey,
      nameKey: this.props.nameKey,
      stroke: this.props.stroke,
      fill: this.props.fill,
      currentRoot: this.state.currentRoot,
      id: this.props.id
    }), /* @__PURE__ */ d.createElement(ou, ao({}, s, {
      width: r,
      height: l === "nest" ? n - 30 : n,
      onTouchMove: this.handleTouchMove
    }), this.renderAllNodes(), o), l === "nest" && this.renderNestIndex());
  }
}
ml(fC, "displayName", "Treemap");
function GG(e) {
  var t = J(), r = gu(), n = bu();
  if (!Bt(r) || !Bt(n))
    return null;
  var {
    id: i
  } = e;
  return /* @__PURE__ */ d.createElement(on, {
    id: i,
    type: "treemap"
  }, (a) => /* @__PURE__ */ d.createElement(fC, ao({}, e, {
    id: a,
    width: r,
    height: n,
    dispatch: t
  })));
}
function AZ(e) {
  var t, r = ee(e, Jh), {
    className: n,
    style: i,
    width: a,
    height: o
  } = r, [l, u] = d.useState(null);
  return /* @__PURE__ */ d.createElement(Gd, {
    preloadedState: {
      options: LG
    },
    reduxStoreName: (t = r.className) !== null && t !== void 0 ? t : "Treemap"
  }, /* @__PURE__ */ d.createElement(RA, {
    margin: XG
  }), /* @__PURE__ */ d.createElement(s0, {
    dispatchTouchEvents: !1,
    className: n,
    style: i,
    width: a,
    height: o,
    responsive: !1,
    ref: (s) => {
      l == null && s != null && u(s);
    },
    onMouseEnter: void 0,
    onMouseLeave: void 0,
    onClick: void 0,
    onMouseMove: void 0,
    onMouseDown: void 0,
    onMouseUp: void 0,
    onContextMenu: void 0,
    onDoubleClick: void 0,
    onTouchStart: void 0,
    onTouchMove: void 0,
    onTouchEnd: void 0
  }, /* @__PURE__ */ d.createElement(Nd.Provider, {
    value: l
  }, /* @__PURE__ */ d.createElement(GG, r))));
}
var dC = {};
(function(e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  const t = vu;
  function r(n, i) {
    if (!n || !n.length)
      return 0;
    i != null && (i = t.iteratee(i));
    let a;
    for (let o = 0; o < n.length; o++) {
      const l = i ? i(n[o]) : n[o];
      l !== void 0 && (a === void 0 ? a = l : a += l);
    }
    return a;
  }
  e.sumBy = r;
})(dC);
var qG = dC.sumBy;
const ZG = /* @__PURE__ */ Wt(qG);
var QG = ["sourceX", "sourceY", "sourceControlX", "targetX", "targetY", "targetControlX", "linkWidth"], JG = ["className", "style", "children", "id"];
function oo() {
  return oo = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, oo.apply(null, arguments);
}
function vC(e, t) {
  if (e == null) return {};
  var r, n, i = eq(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function eq(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function M1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Yr(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? M1(Object(r), !0).forEach(function(n) {
      tq(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : M1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function tq(e, t, r) {
  return (t = rq(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function rq(e) {
  var t = nq(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function nq(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var iq = (e, t) => {
  var r = +e, n = t - r;
  return (i) => r + n * i;
}, Zd = (e) => e.y + e.dy / 2, Jl = (e) => e && e.value || 0, kf = (e, t) => t.reduce((r, n) => r + Jl(e[n]), 0), aq = (e, t, r) => r.reduce((n, i) => {
  var a = t[i];
  if (a == null)
    return n;
  var o = e[a.source];
  return o == null ? n : n + Zd(o) * Jl(t[i]);
}, 0), oq = (e, t, r) => r.reduce((n, i) => {
  var a = t[i];
  if (a == null)
    return n;
  var o = e[a.target];
  return o == null ? n : n + Zd(o) * Jl(t[i]);
}, 0), lq = (e, t) => e.y - t.y, uq = (e, t) => {
  for (var r = [], n = [], i = [], a = [], o = 0, l = e.length; o < l; o++) {
    var u = e[o];
    (u == null ? void 0 : u.source) === t && (i.push(u.target), a.push(o)), (u == null ? void 0 : u.target) === t && (r.push(u.source), n.push(o));
  }
  return {
    sourceNodes: r,
    sourceLinks: n,
    targetLinks: a,
    targetNodes: i
  };
}, pC = (e, t) => {
  for (var {
    targetNodes: r
  } = t, n = 0, i = r.length; n < i; n++) {
    var a = r[n];
    if (a != null) {
      var o = e[a];
      o && (o.depth = Math.max(t.depth + 1, o.depth), pC(e, o));
    }
  }
}, sq = (e, t, r, n) => {
  for (var i, a, {
    nodes: o,
    links: l
  } = e, u = o.map((m, b) => {
    var x = uq(l, b);
    return Yr(Yr(Yr({}, m), x), {}, {
      value: Math.max(kf(l, x.sourceLinks), kf(l, x.targetLinks)),
      depth: 0
    });
  }), s = 0, c = u.length; s < c; s++) {
    var f = u[s];
    f != null && !f.sourceNodes.length && pC(u, f);
  }
  var v = (i = (a = DI(u, (m) => m.depth)) === null || a === void 0 ? void 0 : a.depth) !== null && i !== void 0 ? i : 0;
  if (v >= 1)
    for (var p = (t - r) / v, h = 0, y = u.length; h < y; h++) {
      var g = u[h];
      g != null && (g.targetNodes.length || n === "justify" && (g.depth = v), g.x = g.depth * p, g.dx = r);
    }
  return {
    tree: u,
    maxDepth: v
  };
}, cq = (e) => {
  for (var t = [], r = 0, n = e.length; r < n; r++) {
    var i, a = e[r];
    a != null && (t[a.depth] || (t[a.depth] = []), (i = t[a.depth]) === null || i === void 0 || i.push(a));
  }
  return t;
}, fq = (e, t, r, n, i) => {
  for (var a = Math.min(...e.map((g) => (t - (g.length - 1) * r) / ZG(g, Jl))), o = 0, l = e.length; o < l; o++) {
    var u = e[o];
    if (u != null)
      if (i === "top")
        for (var s = 0, c = 0, f = u.length; c < f; c++) {
          var v = u[c];
          v != null && (v.dy = v.value * a, v.y = s, s += v.dy + r);
        }
      else
        for (var p = 0, h = u.length; p < h; p++) {
          var y = u[p];
          y != null && (y.y = p, y.dy = y.value * a);
        }
  }
  return n.map((g) => Yr(Yr({}, g), {}, {
    dy: Jl(g) * a
  }));
}, Qv = function(t, r, n) {
  for (var i = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !0, a = 0, o = t.length; a < o; a++) {
    var l = t[a];
    if (l != null) {
      var u = l.length;
      i && l.sort(lq);
      for (var s = 0, c = 0; c < u; c++) {
        var f = l[c];
        if (f != null) {
          var v = s - f.y;
          v > 0 && (f.y += v), s = f.y + f.dy + n;
        }
      }
      s = r + n;
      for (var p = u - 1; p >= 0; p--) {
        var h = l[p];
        if (h != null) {
          var y = h.y + h.dy + n - s;
          if (y > 0)
            h.y -= y, s = h.y;
          else
            break;
        }
      }
    }
  }
}, dq = (e, t, r, n) => {
  for (var i = 0, a = t.length; i < a; i++) {
    var o = t[i];
    if (o != null)
      for (var l = 0, u = o.length; l < u; l++) {
        var s = o[l];
        if (s != null && s.sourceLinks.length) {
          var c = kf(r, s.sourceLinks), f = aq(e, r, s.sourceLinks), v = f / c;
          s.y += (v - Zd(s)) * n;
        }
      }
  }
}, vq = (e, t, r, n) => {
  for (var i = t.length - 1; i >= 0; i--) {
    var a = t[i];
    if (a != null)
      for (var o = 0, l = a.length; o < l; o++) {
        var u = a[o];
        if (u != null && u.targetLinks.length) {
          var s = kf(r, u.targetLinks), c = oq(e, r, u.targetLinks), f = c / s;
          u.y += (f - Zd(u)) * n;
        }
      }
  }
}, pq = (e, t) => {
  for (var r = 0, n = e.length; r < n; r++) {
    var i = e[r];
    if (i != null) {
      var a = 0, o = 0;
      i.targetLinks.sort((y, g) => {
        var m, b, x, w, P = (m = t[y]) === null || m === void 0 ? void 0 : m.target, O = (b = t[g]) === null || b === void 0 ? void 0 : b.target;
        if (P == null || O == null)
          return 0;
        var S = (x = e[P]) === null || x === void 0 ? void 0 : x.y, E = (w = e[O]) === null || w === void 0 ? void 0 : w.y;
        return S == null || E == null ? 0 : S - E;
      }), i.sourceLinks.sort((y, g) => {
        var m, b, x, w, P = (m = t[y]) === null || m === void 0 ? void 0 : m.source, O = (b = t[g]) === null || b === void 0 ? void 0 : b.source;
        if (P == null || O == null)
          return 0;
        var S = (x = e[P]) === null || x === void 0 ? void 0 : x.y, E = (w = e[O]) === null || w === void 0 ? void 0 : w.y;
        return S == null || E == null ? 0 : S - E;
      });
      for (var l = 0, u = i.targetLinks.length; l < u; l++) {
        var s = i.targetLinks[l];
        if (s != null) {
          var c = t[s];
          c && (c.sy = a, a += c.dy);
        }
      }
      for (var f = 0, v = i.sourceLinks.length; f < v; f++) {
        var p = i.sourceLinks[f];
        if (p != null) {
          var h = t[p];
          h && (h.ty = o, o += h.dy);
        }
      }
    }
  }
}, hq = (e) => {
  var {
    data: t,
    width: r,
    height: n,
    iterations: i,
    nodeWidth: a,
    nodePadding: o,
    sort: l,
    verticalAlign: u,
    align: s
  } = e, {
    links: c
  } = t, {
    tree: f
  } = sq(t, r, a, s), v = cq(f), p = fq(v, n, o, c, u);
  if (Qv(v, n, o, l), u === "justify")
    for (var h = 1, y = 1; y <= i; y++)
      vq(f, v, p, h *= 0.99), Qv(v, n, o, l), dq(f, v, p, h), Qv(v, n, o, l);
  pq(f, p);
  var g = p;
  return {
    nodes: f,
    links: g
  };
}, mq = (e) => ({
  x: +e.x + +e.width / 2,
  y: +e.y + +e.height / 2
}), yq = (e) => "sourceX" in e ? {
  x: (e.sourceX + e.targetX) / 2,
  y: (e.sourceY + e.targetY) / 2
} : void 0, gq = (e, t, r) => {
  var {
    payload: n
  } = e;
  if (t === "node")
    return {
      payload: n,
      name: G(n, r, ""),
      value: G(n, "value")
    };
  if ("source" in n && n.source && n.target) {
    var i = G(n.source, r, ""), a = G(n.target, r, "");
    return {
      payload: n,
      name: "".concat(i, " - ").concat(a),
      value: G(n, "value")
    };
  }
}, bq = (e, t, r, n) => {
  if (!(t == null || typeof t != "string")) {
    var i = t.split("-"), [a, o] = i, l = Gr(r, "".concat(a, "s[").concat(o, "]"));
    if (l) {
      var u = gq(l, a, n);
      return u;
    }
  }
}, xq = {
  chartName: "Sankey",
  defaultTooltipEventType: "item",
  validateTooltipEventTypes: ["item"],
  tooltipPayloadSearcher: bq,
  eventEmitter: void 0
}, wq = /* @__PURE__ */ d.memo((e) => {
  var {
    dataKey: t,
    nameKey: r,
    stroke: n,
    strokeWidth: i,
    fill: a,
    name: o,
    data: l,
    id: u
  } = e, s = {
    dataDefinedOnItem: l,
    positions: void 0,
    settings: {
      stroke: n,
      strokeWidth: i,
      fill: a,
      dataKey: t,
      name: o,
      nameKey: r,
      hide: !1,
      type: void 0,
      color: a,
      unit: "",
      graphicalItemId: u
    }
  };
  return /* @__PURE__ */ d.createElement(an, {
    tooltipEntrySettings: s
  });
});
function Pq(e, t) {
  if (/* @__PURE__ */ d.isValidElement(e))
    return /* @__PURE__ */ d.cloneElement(e, t);
  if (typeof e == "function")
    return e(t);
  var {
    sourceX: r,
    sourceY: n,
    sourceControlX: i,
    targetX: a,
    targetY: o,
    targetControlX: l,
    linkWidth: u
  } = t, s = vC(t, QG);
  return /* @__PURE__ */ d.createElement("path", oo({
    className: "recharts-sankey-link",
    d: `
          M`.concat(r, ",").concat(n, `
          C`).concat(i, ",").concat(n, " ").concat(l, ",").concat(o, " ").concat(a, ",").concat(o, `
        `),
    fill: "none",
    stroke: "#333",
    strokeWidth: u,
    strokeOpacity: "0.2"
  }, re(s)));
}
var Oq = (e) => {
  var {
    link: t,
    nodes: r,
    left: n,
    top: i,
    i: a,
    linkContent: o,
    linkCurvature: l
  } = e, {
    sy: u,
    ty: s,
    dy: c
  } = t, f = r[t.source], v = r[t.target];
  if (!(f == null || v == null)) {
    var p = f.x + f.dx + n, h = v.x + n, y = iq(p, h), g = y(l), m = y(1 - l), b = f.y + u + c / 2 + i, x = v.y + s + c / 2 + i, w = Yr({
      sourceX: p,
      // @ts-expect-error the linkContent from below is contributing unknown props
      targetX: h,
      sourceY: b,
      // @ts-expect-error the linkContent from below is contributing unknown props
      targetY: x,
      sourceControlX: g,
      targetControlX: m,
      sourceRelativeY: u,
      targetRelativeY: s,
      linkWidth: c,
      index: a,
      payload: Yr(Yr({}, t), {}, {
        source: f,
        target: v
      })
    }, er(o));
    return w;
  }
};
function Sq(e) {
  var {
    graphicalItemId: t,
    props: r,
    i: n,
    linkContent: i,
    onMouseEnter: a,
    onMouseLeave: o,
    onClick: l,
    dataKey: u
  } = e, s = yq(r), c = "link-".concat(n), f = J(), v = {
    onMouseEnter: (p) => {
      f(So({
        activeIndex: c,
        activeDataKey: u,
        activeCoordinate: s,
        activeGraphicalItemId: t
      })), a(r, p);
    },
    onMouseLeave: (p) => {
      f(_g()), o(r, p);
    },
    onClick: (p) => {
      f(Md({
        activeIndex: c,
        activeDataKey: u,
        activeCoordinate: s,
        activeGraphicalItemId: t
      })), l(r, p);
    }
  };
  return /* @__PURE__ */ d.createElement(U, v, Pq(i, r));
}
function Eq(e) {
  var {
    graphicalItemId: t,
    modifiedLinks: r,
    links: n,
    linkContent: i,
    onMouseEnter: a,
    onMouseLeave: o,
    onClick: l,
    dataKey: u
  } = e;
  return /* @__PURE__ */ d.createElement(U, {
    className: "recharts-sankey-links",
    key: "recharts-sankey-links"
  }, n.map((s, c) => {
    var f = r[c];
    return f == null ? null : /* @__PURE__ */ d.createElement(Sq, {
      graphicalItemId: t,
      key: "link-".concat(s.source, "-").concat(s.target, "-").concat(s.value),
      props: f,
      linkContent: i,
      i: c,
      onMouseEnter: a,
      onMouseLeave: o,
      onClick: l,
      dataKey: u
    });
  }));
}
function Aq(e, t) {
  return /* @__PURE__ */ d.isValidElement(e) ? /* @__PURE__ */ d.cloneElement(e, t) : typeof e == "function" ? e(t) : (
    // @ts-expect-error recharts radius is not compatible with SVG radius
    /* @__PURE__ */ d.createElement(Pu, oo({
      className: "recharts-sankey-node",
      fill: "#0088fe",
      fillOpacity: "0.8"
    }, re(t)))
  );
}
var kq = (e) => {
  var {
    node: t,
    nodeContent: r,
    top: n,
    left: i,
    i: a
  } = e, {
    x: o,
    y: l,
    dx: u,
    dy: s
  } = t, c = Yr(Yr({}, er(r)), {}, {
    x: o + i,
    y: l + n,
    width: u,
    height: s,
    index: a,
    payload: t
  });
  return c;
};
function _q(e) {
  var {
    graphicalItemId: t,
    props: r,
    nodeContent: n,
    i,
    onMouseEnter: a,
    onMouseLeave: o,
    onClick: l,
    dataKey: u
  } = e, s = J(), c = mq(r), f = "node-".concat(i), v = {
    onMouseEnter: (p) => {
      s(So({
        activeIndex: f,
        activeDataKey: u,
        activeCoordinate: c,
        activeGraphicalItemId: t
      })), a(r, p);
    },
    onMouseLeave: (p) => {
      s(_g()), o(r, p);
    },
    onClick: (p) => {
      s(Md({
        activeIndex: f,
        activeDataKey: u,
        activeCoordinate: c,
        activeGraphicalItemId: t
      })), l(r, p);
    }
  };
  return /* @__PURE__ */ d.createElement(U, v, Aq(n, r));
}
function Iq(e) {
  var {
    graphicalItemId: t,
    modifiedNodes: r,
    nodeContent: n,
    onMouseEnter: i,
    onMouseLeave: a,
    onClick: o,
    dataKey: l
  } = e;
  return /* @__PURE__ */ d.createElement(U, {
    className: "recharts-sankey-nodes",
    key: "recharts-sankey-nodes"
  }, r.map((u, s) => /* @__PURE__ */ d.createElement(_q, {
    graphicalItemId: t,
    key: "node-".concat(u.index, "-").concat(u.x, "-").concat(u.y),
    props: u,
    nodeContent: n,
    i: s,
    onMouseEnter: i,
    onMouseLeave: a,
    onClick: o,
    dataKey: l
  })));
}
var jq = {
  align: "justify",
  dataKey: "value",
  iterations: 32,
  linkCurvature: 0.5,
  margin: {
    top: 5,
    right: 5,
    bottom: 5,
    left: 5
  },
  nameKey: "name",
  nodePadding: 10,
  nodeWidth: 10,
  sort: !0,
  verticalAlign: "justify"
};
function Cq(e) {
  var {
    className: t,
    style: r,
    children: n,
    id: i
  } = e, a = vC(e, JG), {
    link: o,
    dataKey: l,
    node: u,
    onMouseEnter: s,
    onMouseLeave: c,
    onClick: f,
    data: v,
    iterations: p,
    nodeWidth: h,
    nodePadding: y,
    sort: g,
    linkCurvature: m,
    margin: b,
    verticalAlign: x,
    align: w
  } = e, P = re(a), O = gu(), S = bu(), {
    links: E,
    modifiedLinks: k,
    modifiedNodes: _
  } = d.useMemo(() => {
    var N, R, V, H;
    if (!v || !O || !S || O <= 0 || S <= 0)
      return {
        nodes: [],
        links: [],
        modifiedLinks: [],
        modifiedNodes: []
      };
    var C = O - ((N = b.left) !== null && N !== void 0 ? N : 0) - ((R = b.right) !== null && R !== void 0 ? R : 0), D = S - ((V = b.top) !== null && V !== void 0 ? V : 0) - ((H = b.bottom) !== null && H !== void 0 ? H : 0), F = hq({
      data: v,
      width: C,
      height: D,
      iterations: p,
      nodeWidth: h,
      nodePadding: y,
      sort: g,
      verticalAlign: x,
      align: w
    }), Z = b.top || 0, Q = b.left || 0, Be = F.links.map((Je, Xe) => Oq({
      link: Je,
      nodes: F.nodes,
      i: Xe,
      top: Z,
      left: Q,
      linkContent: o,
      linkCurvature: m
    })).filter(ey), be = F.nodes.map((Je, Xe) => kq({
      node: Je,
      nodeContent: u,
      i: Xe,
      top: Z,
      left: Q
    }));
    return {
      nodes: F.nodes,
      links: F.links,
      modifiedLinks: Be,
      modifiedNodes: be
    };
  }, [v, O, S, b, p, h, y, g, o, u, m, w, x]), I = d.useCallback((N, R, V) => {
    s && s(N, R, V);
  }, [s]), j = d.useCallback((N, R, V) => {
    c && c(N, R, V);
  }, [c]), z = d.useCallback((N, R, V) => {
    f && f(N, R, V);
  }, [f]);
  return !Bt(O) || !Bt(S) || !v || !v.links || !v.nodes ? null : /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(ZU, {
    computedData: {
      links: k,
      nodes: _
    }
  }), /* @__PURE__ */ d.createElement(ou, oo({}, P, {
    width: O,
    height: S
  }), n, /* @__PURE__ */ d.createElement(Eq, {
    graphicalItemId: i,
    links: E,
    modifiedLinks: k,
    linkContent: o,
    dataKey: l,
    onMouseEnter: (N, R) => I(N, "link", R),
    onMouseLeave: (N, R) => j(N, "link", R),
    onClick: (N, R) => z(N, "link", R)
  }), /* @__PURE__ */ d.createElement(Iq, {
    graphicalItemId: i,
    modifiedNodes: _,
    nodeContent: u,
    dataKey: l,
    onMouseEnter: (N, R) => I(N, "node", R),
    onMouseLeave: (N, R) => j(N, "node", R),
    onClick: (N, R) => z(N, "node", R)
  })));
}
function Tq(e) {
  var t = ee(e, jq), {
    width: r,
    height: n,
    style: i,
    className: a,
    id: o
  } = t, [l, u] = d.useState(null);
  return /* @__PURE__ */ d.createElement(Gd, {
    preloadedState: {
      options: xq
    },
    reduxStoreName: a ?? "Sankey"
  }, /* @__PURE__ */ d.createElement(xu, {
    width: r,
    height: n
  }), /* @__PURE__ */ d.createElement(RA, {
    margin: t.margin
  }), /* @__PURE__ */ d.createElement(s0, {
    className: a,
    style: i,
    width: r,
    height: n,
    responsive: !1,
    ref: (s) => {
      s && !l && u(s);
    },
    onMouseEnter: void 0,
    onMouseLeave: void 0,
    onClick: void 0,
    onMouseMove: void 0,
    onMouseDown: void 0,
    onMouseUp: void 0,
    onContextMenu: void 0,
    onDoubleClick: void 0,
    onTouchStart: void 0,
    onTouchMove: void 0,
    onTouchEnd: void 0
  }, /* @__PURE__ */ d.createElement(Nd.Provider, {
    value: l
  }, /* @__PURE__ */ d.createElement(on, {
    id: o,
    type: "sankey"
  }, (s) => /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(wq, {
    dataKey: t.dataKey,
    nameKey: t.nameKey,
    stroke: t.stroke,
    strokeWidth: t.strokeWidth,
    fill: t.fill,
    name: t.name,
    data: t.data,
    id: s
  }), /* @__PURE__ */ d.createElement(Cq, oo({}, t, {
    id: s
  })))))));
}
Tq.displayName = "Sankey";
function D1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function N1(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? D1(Object(r), !0).forEach(function(n) {
      Mq(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : D1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function Mq(e, t, r) {
  return (t = Dq(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function Dq(e) {
  var t = Nq(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function Nq(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var $q = ["axis"], Lq = N1(N1({}, qd), {}, {
  layout: "centric",
  startAngle: 90,
  endAngle: -270
}), kZ = /* @__PURE__ */ d.forwardRef((e, t) => {
  var r = ee(e, Lq);
  return /* @__PURE__ */ d.createElement(c0, {
    chartName: "RadarChart",
    defaultTooltipEventType: "axis",
    validateTooltipEventTypes: $q,
    tooltipPayloadSearcher: Bn,
    categoricalChartProps: r,
    ref: t
  });
}), Rq = ["item"], _Z = /* @__PURE__ */ d.forwardRef((e, t) => /* @__PURE__ */ d.createElement(Do, {
  chartName: "ScatterChart",
  defaultTooltipEventType: "item",
  validateTooltipEventTypes: Rq,
  tooltipPayloadSearcher: Bn,
  categoricalChartProps: e,
  ref: t
})), zq = ["axis"], IZ = /* @__PURE__ */ d.forwardRef((e, t) => /* @__PURE__ */ d.createElement(Do, {
  chartName: "AreaChart",
  defaultTooltipEventType: "axis",
  validateTooltipEventTypes: zq,
  tooltipPayloadSearcher: Bn,
  categoricalChartProps: e,
  ref: t
}));
function $1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function L1(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? $1(Object(r), !0).forEach(function(n) {
      Bq(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : $1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function Bq(e, t, r) {
  return (t = Fq(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function Fq(e) {
  var t = Kq(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function Kq(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var Wq = ["axis", "item"], Uq = L1(L1({}, qd), {}, {
  layout: "radial",
  startAngle: 0,
  endAngle: 360
}), jZ = /* @__PURE__ */ d.forwardRef((e, t) => {
  var r = ee(e, Uq);
  return /* @__PURE__ */ d.createElement(c0, {
    chartName: "RadialBarChart",
    defaultTooltipEventType: "axis",
    validateTooltipEventTypes: Wq,
    tooltipPayloadSearcher: Bn,
    categoricalChartProps: r,
    ref: t
  });
}), Vq = ["axis"], CZ = /* @__PURE__ */ d.forwardRef((e, t) => /* @__PURE__ */ d.createElement(Do, {
  chartName: "ComposedChart",
  defaultTooltipEventType: "axis",
  validateTooltipEventTypes: Vq,
  tooltipPayloadSearcher: Bn,
  categoricalChartProps: e,
  ref: t
}));
function em() {
  return em = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, em.apply(null, arguments);
}
function Hq(e) {
  return /* @__PURE__ */ d.createElement(Ji, em({
    shapeType: "trapezoid"
  }, e));
}
function R1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Qo(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? R1(Object(r), !0).forEach(function(n) {
      Xq(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : R1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function Xq(e, t, r) {
  return (t = Yq(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function Yq(e) {
  var t = Gq(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function Gq(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var qq = (e, t) => t, Zq = A([Ve, qq, yi], (e, t, r) => {
  var {
    data: n,
    dataKey: i,
    nameKey: a,
    tooltipType: o,
    lastShapeType: l,
    reversed: u,
    customWidth: s,
    cells: c,
    presentationProps: f,
    id: v
  } = t, {
    chartData: p
  } = r, h;
  if (n != null && n.length > 0 ? h = n : p != null && p.length > 0 && (h = p), h && h.length)
    h = h.map((y, g) => Qo(Qo(Qo({
      payload: y
    }, f), y), c && c[g] && c[g].props));
  else if (c && c.length)
    h = c.map((y) => Qo(Qo({}, f), y.props));
  else
    return [];
  return pZ({
    dataKey: i,
    nameKey: a,
    displayedData: h,
    tooltipType: o,
    lastShapeType: l,
    reversed: u,
    offset: e,
    customWidth: s,
    graphicalItemId: v
  });
}), Qq = ["onMouseEnter", "onClick", "onMouseLeave", "shape", "activeShape"], Jq = ["id"], eZ = ["stroke", "fill", "legendType", "hide", "isAnimationActive", "animationBegin", "animationDuration", "animationEasing", "nameKey", "lastShapeType", "id"], tZ = ["id"];
function eu() {
  return eu = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, eu.apply(null, arguments);
}
function _f(e, t) {
  if (e == null) return {};
  var r, n, i = rZ(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) === -1 && {}.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
  }
  return i;
}
function rZ(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e) if ({}.hasOwnProperty.call(e, n)) {
    if (t.indexOf(n) !== -1) continue;
    r[n] = e[n];
  }
  return r;
}
function z1(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function yt(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? z1(Object(r), !0).forEach(function(n) {
      nZ(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : z1(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function nZ(e, t, r) {
  return (t = iZ(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function iZ(e) {
  var t = aZ(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function aZ(e, t) {
  if (typeof e != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (typeof n != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var oZ = /* @__PURE__ */ d.memo((e) => {
  var {
    dataKey: t,
    nameKey: r,
    stroke: n,
    strokeWidth: i,
    fill: a,
    name: o,
    hide: l,
    tooltipType: u,
    data: s,
    trapezoids: c,
    id: f
  } = e, v = {
    dataDefinedOnItem: s,
    positions: c.map((p) => {
      var {
        tooltipPosition: h
      } = p;
      return h;
    }),
    settings: {
      stroke: n,
      strokeWidth: i,
      fill: a,
      dataKey: t,
      name: o,
      nameKey: r,
      hide: l,
      type: u,
      color: a,
      unit: "",
      // Funnel does not have unit, why?
      graphicalItemId: f
    }
  };
  return /* @__PURE__ */ d.createElement(an, {
    tooltipEntrySettings: v
  });
});
function lZ(e) {
  var {
    showLabels: t,
    trapezoids: r,
    children: n
  } = e, i = d.useMemo(() => {
    if (t)
      return r == null ? void 0 : r.map((a) => {
        var o = a.labelViewBox;
        return yt(yt({}, o), {}, {
          value: a.name,
          payload: a.payload,
          parentViewBox: a.parentViewBox,
          viewBox: o,
          fill: a.fill
        });
      });
  }, [t, r]);
  return /* @__PURE__ */ d.createElement(_o, {
    value: i
  }, n);
}
function uZ(e) {
  var {
    trapezoids: t,
    allOtherFunnelProps: r
  } = e, n = T((p) => Dd(p, "item", p.tooltip.settings.trigger, void 0)), {
    onMouseEnter: i,
    onClick: a,
    onMouseLeave: o,
    shape: l,
    activeShape: u
  } = r, s = _f(r, Qq), c = jo(i, r.dataKey, r.id), f = Co(o), v = To(a, r.dataKey, r.id);
  return /* @__PURE__ */ d.createElement(d.Fragment, null, t.map((p, h) => {
    var y = !!u && n === String(h), g = y ? u : l, m = yt(yt({}, p), {}, {
      option: g,
      isActive: y,
      stroke: p.stroke
    }), {
      id: b
    } = m, x = _f(m, Jq);
    return /* @__PURE__ */ d.createElement(U, eu({
      key: "trapezoid-".concat(p == null ? void 0 : p.x, "-").concat(p == null ? void 0 : p.y, "-").concat(p == null ? void 0 : p.name, "-").concat(p == null ? void 0 : p.value),
      className: "recharts-funnel-trapezoid"
    }, Nr(s, p, h), {
      // @ts-expect-error the types need a bit of attention
      onMouseEnter: c(p, h),
      onMouseLeave: f(p, h),
      onClick: v(p, h)
    }), /* @__PURE__ */ d.createElement(Hq, x));
  }));
}
function sZ(e) {
  var {
    previousTrapezoidsRef: t,
    props: r
  } = e, {
    trapezoids: n,
    isAnimationActive: i,
    animationBegin: a,
    animationDuration: o,
    animationEasing: l,
    onAnimationEnd: u,
    onAnimationStart: s
  } = r, c = t.current, [f, v] = d.useState(!1), p = !f, h = en(n, "recharts-funnel-"), y = d.useCallback(() => {
    typeof u == "function" && u(), v(!1);
  }, [u]), g = d.useCallback(() => {
    typeof s == "function" && s(), v(!0);
  }, [s]);
  return /* @__PURE__ */ d.createElement(lZ, {
    showLabels: p,
    trapezoids: n
  }, /* @__PURE__ */ d.createElement(Jr, {
    animationId: h,
    begin: a,
    duration: o,
    isActive: i,
    easing: l,
    key: h,
    onAnimationStart: g,
    onAnimationEnd: y
  }, (m) => {
    var b = m === 1 ? n : n.map((x, w) => {
      var P = c && c[w];
      return P ? yt(yt({}, x), {}, {
        x: X(P.x, x.x, m),
        y: X(P.y, x.y, m),
        upperWidth: X(P.upperWidth, x.upperWidth, m),
        lowerWidth: X(P.lowerWidth, x.lowerWidth, m),
        height: X(P.height, x.height, m)
      }) : yt(yt({}, x), {}, {
        x: X(x.x + x.upperWidth / 2, x.x, m),
        y: X(x.y + x.height / 2, x.y, m),
        upperWidth: X(0, x.upperWidth, m),
        lowerWidth: X(0, x.lowerWidth, m),
        height: X(0, x.height, m)
      });
    });
    return m > 0 && (t.current = b), /* @__PURE__ */ d.createElement(U, null, /* @__PURE__ */ d.createElement(uZ, {
      trapezoids: b,
      allOtherFunnelProps: r
    }));
  }), /* @__PURE__ */ d.createElement(bi, {
    label: r.label
  }), r.children);
}
function cZ(e) {
  var t = d.useRef(void 0);
  return /* @__PURE__ */ d.createElement(sZ, {
    props: e,
    previousTrapezoidsRef: t
  });
}
var fZ = (e, t) => {
  var {
    width: r,
    height: n,
    left: i,
    top: a
  } = t, o = dt(e, r, r);
  return {
    realWidth: o,
    realHeight: n,
    offsetX: i,
    offsetY: a
  };
}, dZ = {
  animationBegin: 400,
  animationDuration: 1500,
  animationEasing: "ease",
  fill: "#808080",
  hide: !1,
  isAnimationActive: "auto",
  lastShapeType: "triangle",
  legendType: "rect",
  nameKey: "name",
  reversed: !1,
  stroke: "#fff"
};
function vZ(e) {
  var t = Xu(), {
    stroke: r,
    fill: n,
    legendType: i,
    hide: a,
    isAnimationActive: o,
    animationBegin: l,
    animationDuration: u,
    animationEasing: s,
    nameKey: c,
    lastShapeType: f,
    id: v
  } = e, p = _f(e, eZ), h = re(e), y = Io(e.children, sa), g = d.useMemo(() => ({
    dataKey: e.dataKey,
    nameKey: c,
    data: e.data,
    tooltipType: e.tooltipType,
    lastShapeType: f,
    reversed: e.reversed,
    customWidth: e.width,
    cells: y,
    presentationProps: h,
    id: v
  }), [e.dataKey, c, e.data, e.tooltipType, f, e.reversed, e.width, y, h, v]), m = T((P) => Zq(P, g));
  if (a || !m || !m.length || !t)
    return null;
  var {
    height: b,
    width: x
  } = t, w = Y("recharts-trapezoids", e.className);
  return /* @__PURE__ */ d.createElement(d.Fragment, null, /* @__PURE__ */ d.createElement(oZ, {
    dataKey: e.dataKey,
    nameKey: e.nameKey,
    stroke: e.stroke,
    strokeWidth: e.strokeWidth,
    fill: e.fill,
    name: e.name,
    hide: e.hide,
    tooltipType: e.tooltipType,
    data: e.data,
    trapezoids: m,
    id: v
  }), /* @__PURE__ */ d.createElement(U, {
    className: w
  }, /* @__PURE__ */ d.createElement(cZ, eu({}, p, {
    id: v,
    stroke: r,
    fill: n,
    nameKey: c,
    lastShapeType: f,
    animationBegin: l,
    animationDuration: u,
    animationEasing: s,
    isAnimationActive: o,
    hide: a,
    legendType: i,
    height: b,
    width: x,
    trapezoids: m
  }))));
}
function pZ(e) {
  var {
    dataKey: t,
    nameKey: r,
    displayedData: n,
    tooltipType: i,
    lastShapeType: a,
    reversed: o,
    offset: l,
    customWidth: u,
    graphicalItemId: s
  } = e, {
    realHeight: c,
    realWidth: f,
    offsetX: v,
    offsetY: p
  } = fZ(u, l), h = Math.max.apply(null, n.map((x) => G(x, t, 0))), y = n.length, g = c / y, m = {
    x: l.left,
    y: l.top,
    width: l.width,
    height: l.height
  }, b = n.map((x, w) => {
    var P = G(x, t, 0), O = String(G(x, r, w)), S = P, E;
    w !== y - 1 ? (E = G(n[w + 1], t, 0), E instanceof Array && ([S, E] = E)) : P instanceof Array && P.length === 2 ? [S, E] = P : a === "rectangle" ? E = S : E = 0;
    var k = (h - S) * f / (2 * h) + v, _ = g * w + p, I = S / h * f, j = E / h * f, z = [{
      name: O,
      value: S,
      payload: x,
      dataKey: t,
      type: i,
      graphicalItemId: s
    }], N = {
      x: k + I / 2,
      y: _ + g / 2
    }, R = {
      x: k,
      y: _,
      upperWidth: I,
      lowerWidth: j,
      width: Math.max(I, j),
      height: g
    };
    return yt(yt(yt({}, R), {}, {
      name: O,
      val: S,
      tooltipPayload: z,
      tooltipPosition: N
    }, sC(x, ["width"])), {}, {
      payload: x,
      parentViewBox: m,
      labelViewBox: R
    });
  });
  return o && (b = b.map((x, w) => {
    var P = {
      x: x.x - (x.lowerWidth - x.upperWidth) / 2,
      y: x.y - w * g + (y - 1 - w) * g,
      upperWidth: x.lowerWidth,
      lowerWidth: x.upperWidth,
      width: Math.max(x.lowerWidth, x.upperWidth),
      height: g
    };
    return yt(yt(yt({}, x), P), {}, {
      tooltipPosition: yt(yt({}, x.tooltipPosition), {}, {
        y: x.y - w * g + (y - 1 - w) * g + g / 2
      }),
      labelViewBox: P
    });
  })), b;
}
function hZ(e) {
  var t = ee(e, dZ), {
    id: r
  } = t, n = _f(t, tZ);
  return /* @__PURE__ */ d.createElement(on, {
    id: r,
    type: "funnel"
  }, (i) => /* @__PURE__ */ d.createElement(vZ, eu({}, n, {
    id: i
  })));
}
hZ.displayName = "Funnel";
var mZ = ["item"], TZ = /* @__PURE__ */ d.forwardRef((e, t) => /* @__PURE__ */ d.createElement(Do, {
  chartName: "FunnelChart",
  defaultTooltipEventType: "item",
  validateTooltipEventTypes: mZ,
  tooltipPayloadSearcher: Bn,
  categoricalChartProps: e,
  ref: t
}));
export {
  IZ as A,
  SZ as B,
  CZ as C,
  YH as D,
  WV as E,
  TZ as F,
  lH as G,
  QV as H,
  yV as I,
  sa as J,
  Gs as K,
  rL as L,
  RY as M,
  EZ as P,
  MC as R,
  ik as S,
  PZ as T,
  mY as X,
  SY as Y,
  kY as Z,
  Uf as a,
  Y as b,
  gZ as c,
  DC as d,
  bZ as e,
  wZ as f,
  Wt as g,
  I7 as h,
  AX as i,
  OZ as j,
  r7 as k,
  H6 as l,
  Vn as m,
  kZ as n,
  tU as o,
  B4 as p,
  _5 as q,
  d as r,
  f5 as s,
  jZ as t,
  VU as u,
  _Z as v,
  aY as w,
  hZ as x,
  AZ as y,
  Tq as z
};
