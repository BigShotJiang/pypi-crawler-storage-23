import { j as n } from "./refast-markdown-ByFT1VZb.js";
import { r as s, e as Ut, R as K } from "./refast-charts-C9YTpQC6.js";
import { R as Ht, P as qt, O as Yt, C as Xt, c as Jt, a as Qt, S as Zt, b as er, d as tr, e as rr, I as ar, f as nr, g as or, h as ir, i as sr, j as dr, A as ur, k as lr, G as cr, L as fr, l as mr } from "./refast-index-D9xrDqow.js";
import { n as G, P as L, o as Z, b as T, p as We, c as Je, u as te, q as le, f as Ie, r as pr, g as Qe, a as ce, D as gr, s as he, t as U, d as vr, i as Ze, I as br, R as xr, j as g, m as et } from "./refast-index-iXHSFA1L.js";
var Ue = 1, hr = 0.9, wr = 0.8, Mr = 0.17, ve = 0.1, be = 0.999, Nr = 0.9999, yr = 0.99, Cr = /[\\\/_+.#"@\[\(\{&]/, jr = /[\\\/_+.#"@\[\(\{&]/g, Rr = /[\s-]/, tt = /[\s-]/g;
function we(e, r, t, a, o, i, d) {
  if (i === r.length) return o === e.length ? Ue : yr;
  var u = `${o},${i}`;
  if (d[u] !== void 0) return d[u];
  for (var c = a.charAt(i), m = t.indexOf(c, o), l = 0, p, h, w, v; m >= 0; ) p = we(e, r, t, a, m + 1, i + 1, d), p > l && (m === o ? p *= Ue : Cr.test(e.charAt(m - 1)) ? (p *= wr, w = e.slice(o, m - 1).match(jr), w && o > 0 && (p *= Math.pow(be, w.length))) : Rr.test(e.charAt(m - 1)) ? (p *= hr, v = e.slice(o, m - 1).match(tt), v && o > 0 && (p *= Math.pow(be, v.length))) : (p *= Mr, o > 0 && (p *= Math.pow(be, m - o))), e.charAt(m) !== r.charAt(i) && (p *= Nr)), (p < ve && t.charAt(m - 1) === a.charAt(i + 1) || a.charAt(i + 1) === a.charAt(i) && t.charAt(m - 1) !== a.charAt(i)) && (h = we(e, r, t, a, m + 1, i + 2, d), h * ve > p && (p = h * ve)), p > l && (l = p), m = t.indexOf(c, m + 1);
  return d[u] = l, l;
}
function He(e) {
  return e.toLowerCase().replace(tt, " ");
}
function Er(e, r, t) {
  return e = t && t.length > 0 ? `${e + " " + t.join(" ")}` : e, we(e, r, He(e), He(r), 0, 0, {});
}
var ne = '[cmdk-group=""]', xe = '[cmdk-group-items=""]', kr = '[cmdk-group-heading=""]', rt = '[cmdk-item=""]', qe = `${rt}:not([aria-disabled="true"])`, Me = "cmdk-item-select", J = "data-value", Sr = (e, r, t) => Er(e, r, t), at = s.createContext(void 0), oe = () => s.useContext(at), nt = s.createContext(void 0), _e = () => s.useContext(nt), ot = s.createContext(void 0), it = s.forwardRef((e, r) => {
  let t = Q(() => {
    var f, C;
    return { search: "", value: (C = (f = e.value) != null ? f : e.defaultValue) != null ? C : "", selectedItemId: void 0, filtered: { count: 0, items: /* @__PURE__ */ new Map(), groups: /* @__PURE__ */ new Set() } };
  }), a = Q(() => /* @__PURE__ */ new Set()), o = Q(() => /* @__PURE__ */ new Map()), i = Q(() => /* @__PURE__ */ new Map()), d = Q(() => /* @__PURE__ */ new Set()), u = st(e), { label: c, children: m, value: l, onValueChange: p, filter: h, shouldFilter: w, loop: v, disablePointerSelection: M = !1, vimBindings: R = !0, ..._ } = e, A = G(), b = G(), y = G(), N = s.useRef(null), j = $r();
  H(() => {
    if (l !== void 0) {
      let f = l.trim();
      t.current.value = f, k.emit();
    }
  }, [l]), H(() => {
    j(6, $e);
  }, []);
  let k = s.useMemo(() => ({ subscribe: (f) => (d.current.add(f), () => d.current.delete(f)), snapshot: () => t.current, setState: (f, C, E) => {
    var x, I, P, F;
    if (!Object.is(t.current[f], C)) {
      if (t.current[f] = C, f === "search") re(), B(), j(1, W);
      else if (f === "value") {
        if (document.activeElement.hasAttribute("cmdk-input") || document.activeElement.hasAttribute("cmdk-root")) {
          let O = document.getElementById(y);
          O ? O.focus() : (x = document.getElementById(A)) == null || x.focus();
        }
        if (j(7, () => {
          var O;
          t.current.selectedItemId = (O = X()) == null ? void 0 : O.id, k.emit();
        }), E || j(5, $e), ((I = u.current) == null ? void 0 : I.value) !== void 0) {
          let O = C ?? "";
          (F = (P = u.current).onValueChange) == null || F.call(P, O);
          return;
        }
      }
      k.emit();
    }
  }, emit: () => {
    d.current.forEach((f) => f());
  } }), []), $ = s.useMemo(() => ({ value: (f, C, E) => {
    var x;
    C !== ((x = i.current.get(f)) == null ? void 0 : x.value) && (i.current.set(f, { value: C, keywords: E }), t.current.filtered.items.set(f, S(C, E)), j(2, () => {
      B(), k.emit();
    }));
  }, item: (f, C) => (a.current.add(f), C && (o.current.has(C) ? o.current.get(C).add(f) : o.current.set(C, /* @__PURE__ */ new Set([f]))), j(3, () => {
    re(), B(), t.current.value || W(), k.emit();
  }), () => {
    i.current.delete(f), a.current.delete(f), t.current.filtered.items.delete(f);
    let E = X();
    j(4, () => {
      re(), (E == null ? void 0 : E.getAttribute("id")) === f && W(), k.emit();
    });
  }), group: (f) => (o.current.has(f) || o.current.set(f, /* @__PURE__ */ new Set()), () => {
    i.current.delete(f), o.current.delete(f);
  }), filter: () => u.current.shouldFilter, label: c || e["aria-label"], getDisablePointerSelection: () => u.current.disablePointerSelection, listId: A, inputId: y, labelId: b, listInnerRef: N }), []);
  function S(f, C) {
    var E, x;
    let I = (x = (E = u.current) == null ? void 0 : E.filter) != null ? x : Sr;
    return f ? I(f, t.current.search, C) : 0;
  }
  function B() {
    if (!t.current.search || u.current.shouldFilter === !1) return;
    let f = t.current.filtered.items, C = [];
    t.current.filtered.groups.forEach((x) => {
      let I = o.current.get(x), P = 0;
      I.forEach((F) => {
        let O = f.get(F);
        P = Math.max(O, P);
      }), C.push([x, P]);
    });
    let E = N.current;
    ae().sort((x, I) => {
      var P, F;
      let O = x.getAttribute("id"), se = I.getAttribute("id");
      return ((P = f.get(se)) != null ? P : 0) - ((F = f.get(O)) != null ? F : 0);
    }).forEach((x) => {
      let I = x.closest(xe);
      I ? I.appendChild(x.parentElement === I ? x : x.closest(`${xe} > *`)) : E.appendChild(x.parentElement === E ? x : x.closest(`${xe} > *`));
    }), C.sort((x, I) => I[1] - x[1]).forEach((x) => {
      var I;
      let P = (I = N.current) == null ? void 0 : I.querySelector(`${ne}[${J}="${encodeURIComponent(x[0])}"]`);
      P == null || P.parentElement.appendChild(P);
    });
  }
  function W() {
    let f = ae().find((E) => E.getAttribute("aria-disabled") !== "true"), C = f == null ? void 0 : f.getAttribute(J);
    k.setState("value", C || void 0);
  }
  function re() {
    var f, C, E, x;
    if (!t.current.search || u.current.shouldFilter === !1) {
      t.current.filtered.count = a.current.size;
      return;
    }
    t.current.filtered.groups = /* @__PURE__ */ new Set();
    let I = 0;
    for (let P of a.current) {
      let F = (C = (f = i.current.get(P)) == null ? void 0 : f.value) != null ? C : "", O = (x = (E = i.current.get(P)) == null ? void 0 : E.keywords) != null ? x : [], se = S(F, O);
      t.current.filtered.items.set(P, se), se > 0 && I++;
    }
    for (let [P, F] of o.current) for (let O of F) if (t.current.filtered.items.get(O) > 0) {
      t.current.filtered.groups.add(P);
      break;
    }
    t.current.filtered.count = I;
  }
  function $e() {
    var f, C, E;
    let x = X();
    x && (((f = x.parentElement) == null ? void 0 : f.firstChild) === x && ((E = (C = x.closest(ne)) == null ? void 0 : C.querySelector(kr)) == null || E.scrollIntoView({ block: "nearest" })), x.scrollIntoView({ block: "nearest" }));
  }
  function X() {
    var f;
    return (f = N.current) == null ? void 0 : f.querySelector(`${rt}[aria-selected="true"]`);
  }
  function ae() {
    var f;
    return Array.from(((f = N.current) == null ? void 0 : f.querySelectorAll(qe)) || []);
  }
  function pe(f) {
    let C = ae()[f];
    C && k.setState("value", C.getAttribute(J));
  }
  function ge(f) {
    var C;
    let E = X(), x = ae(), I = x.findIndex((F) => F === E), P = x[I + f];
    (C = u.current) != null && C.loop && (P = I + f < 0 ? x[x.length - 1] : I + f === x.length ? x[0] : x[I + f]), P && k.setState("value", P.getAttribute(J));
  }
  function ze(f) {
    let C = X(), E = C == null ? void 0 : C.closest(ne), x;
    for (; E && !x; ) E = f > 0 ? Fr(E, ne) : Kr(E, ne), x = E == null ? void 0 : E.querySelector(qe);
    x ? k.setState("value", x.getAttribute(J)) : ge(f);
  }
  let Be = () => pe(ae().length - 1), Ge = (f) => {
    f.preventDefault(), f.metaKey ? Be() : f.altKey ? ze(1) : ge(1);
  }, Ve = (f) => {
    f.preventDefault(), f.metaKey ? pe(0) : f.altKey ? ze(-1) : ge(-1);
  };
  return s.createElement(L.div, { ref: r, tabIndex: -1, ..._, "cmdk-root": "", onKeyDown: (f) => {
    var C;
    (C = _.onKeyDown) == null || C.call(_, f);
    let E = f.nativeEvent.isComposing || f.keyCode === 229;
    if (!(f.defaultPrevented || E)) switch (f.key) {
      case "n":
      case "j": {
        R && f.ctrlKey && Ge(f);
        break;
      }
      case "ArrowDown": {
        Ge(f);
        break;
      }
      case "p":
      case "k": {
        R && f.ctrlKey && Ve(f);
        break;
      }
      case "ArrowUp": {
        Ve(f);
        break;
      }
      case "Home": {
        f.preventDefault(), pe(0);
        break;
      }
      case "End": {
        f.preventDefault(), Be();
        break;
      }
      case "Enter": {
        f.preventDefault();
        let x = X();
        if (x) {
          let I = new Event(Me);
          x.dispatchEvent(I);
        }
      }
    }
  } }, s.createElement("label", { "cmdk-label": "", htmlFor: $.inputId, id: $.labelId, style: Br }, c), fe(e, (f) => s.createElement(nt.Provider, { value: k }, s.createElement(at.Provider, { value: $ }, f))));
}), Ir = s.forwardRef((e, r) => {
  var t, a;
  let o = G(), i = s.useRef(null), d = s.useContext(ot), u = oe(), c = st(e), m = (a = (t = c.current) == null ? void 0 : t.forceMount) != null ? a : d == null ? void 0 : d.forceMount;
  H(() => {
    if (!m) return u.item(o, d == null ? void 0 : d.id);
  }, [m]);
  let l = dt(o, i, [e.value, e.children, i], e.keywords), p = _e(), h = V((j) => j.value && j.value === l.current), w = V((j) => m || u.filter() === !1 ? !0 : j.search ? j.filtered.items.get(o) > 0 : !0);
  s.useEffect(() => {
    let j = i.current;
    if (!(!j || e.disabled)) return j.addEventListener(Me, v), () => j.removeEventListener(Me, v);
  }, [w, e.onSelect, e.disabled]);
  function v() {
    var j, k;
    M(), (k = (j = c.current).onSelect) == null || k.call(j, l.current);
  }
  function M() {
    p.setState("value", l.current, !0);
  }
  if (!w) return null;
  let { disabled: R, value: _, onSelect: A, forceMount: b, keywords: y, ...N } = e;
  return s.createElement(L.div, { ref: Z(i, r), ...N, id: o, "cmdk-item": "", role: "option", "aria-disabled": !!R, "aria-selected": !!h, "data-disabled": !!R, "data-selected": !!h, onPointerMove: R || u.getDisablePointerSelection() ? void 0 : M, onClick: R ? void 0 : v }, e.children);
}), _r = s.forwardRef((e, r) => {
  let { heading: t, children: a, forceMount: o, ...i } = e, d = G(), u = s.useRef(null), c = s.useRef(null), m = G(), l = oe(), p = V((w) => o || l.filter() === !1 ? !0 : w.search ? w.filtered.groups.has(d) : !0);
  H(() => l.group(d), []), dt(d, u, [e.value, e.heading, c]);
  let h = s.useMemo(() => ({ id: d, forceMount: o }), [o]);
  return s.createElement(L.div, { ref: Z(u, r), ...i, "cmdk-group": "", role: "presentation", hidden: p ? void 0 : !0 }, t && s.createElement("div", { ref: c, "cmdk-group-heading": "", "aria-hidden": !0, id: m }, t), fe(e, (w) => s.createElement("div", { "cmdk-group-items": "", role: "group", "aria-labelledby": t ? m : void 0 }, s.createElement(ot.Provider, { value: h }, w))));
}), Tr = s.forwardRef((e, r) => {
  let { alwaysRender: t, ...a } = e, o = s.useRef(null), i = V((d) => !d.search);
  return !t && !i ? null : s.createElement(L.div, { ref: Z(o, r), ...a, "cmdk-separator": "", role: "separator" });
}), Pr = s.forwardRef((e, r) => {
  let { onValueChange: t, ...a } = e, o = e.value != null, i = _e(), d = V((m) => m.search), u = V((m) => m.selectedItemId), c = oe();
  return s.useEffect(() => {
    e.value != null && i.setState("search", e.value);
  }, [e.value]), s.createElement(L.input, { ref: r, ...a, "cmdk-input": "", autoComplete: "off", autoCorrect: "off", spellCheck: !1, "aria-autocomplete": "list", role: "combobox", "aria-expanded": !0, "aria-controls": c.listId, "aria-labelledby": c.labelId, "aria-activedescendant": u, id: c.inputId, type: "text", value: o ? e.value : d, onChange: (m) => {
    o || i.setState("search", m.target.value), t == null || t(m.target.value);
  } });
}), Ar = s.forwardRef((e, r) => {
  let { children: t, label: a = "Suggestions", ...o } = e, i = s.useRef(null), d = s.useRef(null), u = V((m) => m.selectedItemId), c = oe();
  return s.useEffect(() => {
    if (d.current && i.current) {
      let m = d.current, l = i.current, p, h = new ResizeObserver(() => {
        p = requestAnimationFrame(() => {
          let w = m.offsetHeight;
          l.style.setProperty("--cmdk-list-height", w.toFixed(1) + "px");
        });
      });
      return h.observe(m), () => {
        cancelAnimationFrame(p), h.unobserve(m);
      };
    }
  }, []), s.createElement(L.div, { ref: Z(i, r), ...o, "cmdk-list": "", role: "listbox", tabIndex: -1, "aria-activedescendant": u, "aria-label": a, id: c.listId }, fe(e, (m) => s.createElement("div", { ref: Z(d, c.listInnerRef), "cmdk-list-sizer": "" }, m)));
}), Lr = s.forwardRef((e, r) => {
  let { open: t, onOpenChange: a, overlayClassName: o, contentClassName: i, container: d, ...u } = e;
  return s.createElement(Ht, { open: t, onOpenChange: a }, s.createElement(qt, { container: d }, s.createElement(Yt, { "cmdk-overlay": "", className: o }), s.createElement(Xt, { "aria-label": e.label, "cmdk-dialog": "", className: i }, s.createElement(it, { ref: r, ...u }))));
}), Dr = s.forwardRef((e, r) => V((t) => t.filtered.count === 0) ? s.createElement(L.div, { ref: r, ...e, "cmdk-empty": "", role: "presentation" }) : null), Or = s.forwardRef((e, r) => {
  let { progress: t, children: a, label: o = "Loading...", ...i } = e;
  return s.createElement(L.div, { ref: r, ...i, "cmdk-loading": "", role: "progressbar", "aria-valuenow": t, "aria-valuemin": 0, "aria-valuemax": 100, "aria-label": o }, fe(e, (d) => s.createElement("div", { "aria-hidden": !0 }, d)));
}), q = Object.assign(it, { List: Ar, Item: Ir, Input: Pr, Group: _r, Separator: Tr, Dialog: Lr, Empty: Dr, Loading: Or });
function Fr(e, r) {
  let t = e.nextElementSibling;
  for (; t; ) {
    if (t.matches(r)) return t;
    t = t.nextElementSibling;
  }
}
function Kr(e, r) {
  let t = e.previousElementSibling;
  for (; t; ) {
    if (t.matches(r)) return t;
    t = t.previousElementSibling;
  }
}
function st(e) {
  let r = s.useRef(e);
  return H(() => {
    r.current = e;
  }), r;
}
var H = typeof window > "u" ? s.useEffect : s.useLayoutEffect;
function Q(e) {
  let r = s.useRef();
  return r.current === void 0 && (r.current = e()), r;
}
function V(e) {
  let r = _e(), t = () => e(r.snapshot());
  return s.useSyncExternalStore(r.subscribe, t, t);
}
function dt(e, r, t, a = []) {
  let o = s.useRef(), i = oe();
  return H(() => {
    var d;
    let u = (() => {
      var m;
      for (let l of t) {
        if (typeof l == "string") return l.trim();
        if (typeof l == "object" && "current" in l) return l.current ? (m = l.current.textContent) == null ? void 0 : m.trim() : o.current;
      }
    })(), c = a.map((m) => m.trim());
    i.value(e, u, c), (d = r.current) == null || d.setAttribute(J, u), o.current = u;
  }), o;
}
var $r = () => {
  let [e, r] = s.useState(), t = Q(() => /* @__PURE__ */ new Map());
  return H(() => {
    t.current.forEach((a) => a()), t.current = /* @__PURE__ */ new Map();
  }, [e]), (a, o) => {
    t.current.set(a, o), r({});
  };
};
function zr(e) {
  let r = e.type;
  return typeof r == "function" ? r(e.props) : "render" in r ? r.render(e.props) : e;
}
function fe({ asChild: e, children: r }, t) {
  return e && s.isValidElement(r) ? s.cloneElement(zr(r), { ref: r.ref }, t(r.props.children)) : t(r);
}
var Br = { position: "absolute", width: "1px", height: "1px", padding: "0", margin: "-1px", overflow: "hidden", clip: "rect(0, 0, 0, 0)", whiteSpace: "nowrap", borderWidth: "0" }, Y = "NavigationMenu", [Te, ut, Gr] = Ie(Y), [Ne, Vr, Wr] = Ie(Y), [Pe] = Je(
  Y,
  [Gr, Wr]
), [Ur, z] = Pe(Y), [Hr, qr] = Pe(Y), lt = s.forwardRef(
  (e, r) => {
    const {
      __scopeNavigationMenu: t,
      value: a,
      onValueChange: o,
      defaultValue: i,
      delayDuration: d = 200,
      skipDelayDuration: u = 300,
      orientation: c = "horizontal",
      dir: m,
      ...l
    } = e, [p, h] = s.useState(null), w = te(r, (S) => h(S)), v = Qe(m), M = s.useRef(0), R = s.useRef(0), _ = s.useRef(0), [A, b] = s.useState(!0), [y, N] = ce({
      prop: a,
      onChange: (S) => {
        const B = S !== "", W = u > 0;
        B ? (window.clearTimeout(_.current), W && b(!1)) : (window.clearTimeout(_.current), _.current = window.setTimeout(
          () => b(!0),
          u
        )), o == null || o(S);
      },
      defaultProp: i ?? "",
      caller: Y
    }), j = s.useCallback(() => {
      window.clearTimeout(R.current), R.current = window.setTimeout(() => N(""), 150);
    }, [N]), k = s.useCallback(
      (S) => {
        window.clearTimeout(R.current), N(S);
      },
      [N]
    ), $ = s.useCallback(
      (S) => {
        y === S ? window.clearTimeout(R.current) : M.current = window.setTimeout(() => {
          window.clearTimeout(R.current), N(S);
        }, d);
      },
      [y, N, d]
    );
    return s.useEffect(() => () => {
      window.clearTimeout(M.current), window.clearTimeout(R.current), window.clearTimeout(_.current);
    }, []), /* @__PURE__ */ n.jsx(
      ct,
      {
        scope: t,
        isRootMenu: !0,
        value: y,
        dir: v,
        orientation: c,
        rootNavigationMenu: p,
        onTriggerEnter: (S) => {
          window.clearTimeout(M.current), A ? $(S) : k(S);
        },
        onTriggerLeave: () => {
          window.clearTimeout(M.current), j();
        },
        onContentEnter: () => window.clearTimeout(R.current),
        onContentLeave: j,
        onItemSelect: (S) => {
          N((B) => B === S ? "" : S);
        },
        onItemDismiss: () => N(""),
        children: /* @__PURE__ */ n.jsx(
          L.nav,
          {
            "aria-label": "Main",
            "data-orientation": c,
            dir: v,
            ...l,
            ref: w
          }
        )
      }
    );
  }
);
lt.displayName = Y;
var ye = "NavigationMenuSub", Yr = s.forwardRef(
  (e, r) => {
    const {
      __scopeNavigationMenu: t,
      value: a,
      onValueChange: o,
      defaultValue: i,
      orientation: d = "horizontal",
      ...u
    } = e, c = z(ye, t), [m, l] = ce({
      prop: a,
      onChange: o,
      defaultProp: i ?? "",
      caller: ye
    });
    return /* @__PURE__ */ n.jsx(
      ct,
      {
        scope: t,
        isRootMenu: !1,
        value: m,
        dir: c.dir,
        orientation: d,
        rootNavigationMenu: c.rootNavigationMenu,
        onTriggerEnter: (p) => l(p),
        onItemSelect: (p) => l(p),
        onItemDismiss: () => l(""),
        children: /* @__PURE__ */ n.jsx(L.div, { "data-orientation": d, ...u, ref: r })
      }
    );
  }
);
Yr.displayName = ye;
var ct = (e) => {
  const {
    scope: r,
    isRootMenu: t,
    rootNavigationMenu: a,
    dir: o,
    orientation: i,
    children: d,
    value: u,
    onItemSelect: c,
    onItemDismiss: m,
    onTriggerEnter: l,
    onTriggerLeave: p,
    onContentEnter: h,
    onContentLeave: w
  } = e, [v, M] = s.useState(null), [R, _] = s.useState(/* @__PURE__ */ new Map()), [A, b] = s.useState(null);
  return /* @__PURE__ */ n.jsx(
    Ur,
    {
      scope: r,
      isRootMenu: t,
      rootNavigationMenu: a,
      value: u,
      previousValue: vr(u),
      baseId: G(),
      dir: o,
      orientation: i,
      viewport: v,
      onViewportChange: M,
      indicatorTrack: A,
      onIndicatorTrackChange: b,
      onTriggerEnter: U(l),
      onTriggerLeave: U(p),
      onContentEnter: U(h),
      onContentLeave: U(w),
      onItemSelect: U(c),
      onItemDismiss: U(m),
      onViewportContentChange: s.useCallback((y, N) => {
        _((j) => (j.set(y, N), new Map(j)));
      }, []),
      onViewportContentRemove: s.useCallback((y) => {
        _((N) => N.has(y) ? (N.delete(y), new Map(N)) : N);
      }, []),
      children: /* @__PURE__ */ n.jsx(Te.Provider, { scope: r, children: /* @__PURE__ */ n.jsx(Hr, { scope: r, items: R, children: d }) })
    }
  );
}, ft = "NavigationMenuList", mt = s.forwardRef(
  (e, r) => {
    const { __scopeNavigationMenu: t, ...a } = e, o = z(ft, t), i = /* @__PURE__ */ n.jsx(L.ul, { "data-orientation": o.orientation, ...a, ref: r });
    return /* @__PURE__ */ n.jsx(L.div, { style: { position: "relative" }, ref: o.onIndicatorTrackChange, children: /* @__PURE__ */ n.jsx(Te.Slot, { scope: t, children: o.isRootMenu ? /* @__PURE__ */ n.jsx(Nt, { asChild: !0, children: i }) : i }) });
  }
);
mt.displayName = ft;
var pt = "NavigationMenuItem", [Xr, gt] = Pe(pt), vt = s.forwardRef(
  (e, r) => {
    const { __scopeNavigationMenu: t, value: a, ...o } = e, i = G(), d = a || i || "LEGACY_REACT_AUTO_VALUE", u = s.useRef(null), c = s.useRef(null), m = s.useRef(null), l = s.useRef(() => {
    }), p = s.useRef(!1), h = s.useCallback((v = "start") => {
      if (u.current) {
        l.current();
        const M = je(u.current);
        M.length && De(v === "start" ? M : M.reverse());
      }
    }, []), w = s.useCallback(() => {
      if (u.current) {
        const v = je(u.current);
        v.length && (l.current = na(v));
      }
    }, []);
    return /* @__PURE__ */ n.jsx(
      Xr,
      {
        scope: t,
        value: d,
        triggerRef: c,
        contentRef: u,
        focusProxyRef: m,
        wasEscapeCloseRef: p,
        onEntryKeyDown: h,
        onFocusProxyEnter: h,
        onRootContentClose: w,
        onContentFocusOutside: w,
        children: /* @__PURE__ */ n.jsx(L.li, { ...o, ref: r })
      }
    );
  }
);
vt.displayName = pt;
var Ce = "NavigationMenuTrigger", bt = s.forwardRef((e, r) => {
  const { __scopeNavigationMenu: t, disabled: a, ...o } = e, i = z(Ce, e.__scopeNavigationMenu), d = gt(Ce, e.__scopeNavigationMenu), u = s.useRef(null), c = te(u, d.triggerRef, r), m = Ct(i.baseId, d.value), l = jt(i.baseId, d.value), p = s.useRef(!1), h = s.useRef(!1), w = d.value === i.value;
  return /* @__PURE__ */ n.jsxs(n.Fragment, { children: [
    /* @__PURE__ */ n.jsx(Te.ItemSlot, { scope: t, value: d.value, children: /* @__PURE__ */ n.jsx(yt, { asChild: !0, children: /* @__PURE__ */ n.jsx(
      L.button,
      {
        id: m,
        disabled: a,
        "data-disabled": a ? "" : void 0,
        "data-state": Oe(w),
        "aria-expanded": w,
        "aria-controls": l,
        ...o,
        ref: c,
        onPointerEnter: T(e.onPointerEnter, () => {
          h.current = !1, d.wasEscapeCloseRef.current = !1;
        }),
        onPointerMove: T(
          e.onPointerMove,
          ue(() => {
            a || h.current || d.wasEscapeCloseRef.current || p.current || (i.onTriggerEnter(d.value), p.current = !0);
          })
        ),
        onPointerLeave: T(
          e.onPointerLeave,
          ue(() => {
            a || (i.onTriggerLeave(), p.current = !1);
          })
        ),
        onClick: T(e.onClick, () => {
          i.onItemSelect(d.value), h.current = w;
        }),
        onKeyDown: T(e.onKeyDown, (v) => {
          const R = { horizontal: "ArrowDown", vertical: i.dir === "rtl" ? "ArrowLeft" : "ArrowRight" }[i.orientation];
          w && v.key === R && (d.onEntryKeyDown(), v.preventDefault());
        })
      }
    ) }) }),
    w && /* @__PURE__ */ n.jsxs(n.Fragment, { children: [
      /* @__PURE__ */ n.jsx(
        pr,
        {
          "aria-hidden": !0,
          tabIndex: 0,
          ref: d.focusProxyRef,
          onFocus: (v) => {
            const M = d.contentRef.current, R = v.relatedTarget, _ = R === u.current, A = M == null ? void 0 : M.contains(R);
            (_ || !A) && d.onFocusProxyEnter(_ ? "start" : "end");
          }
        }
      ),
      i.viewport && /* @__PURE__ */ n.jsx("span", { "aria-owns": l })
    ] })
  ] });
});
bt.displayName = Ce;
var Jr = "NavigationMenuLink", Ye = "navigationMenu.linkSelect", xt = s.forwardRef(
  (e, r) => {
    const { __scopeNavigationMenu: t, active: a, onSelect: o, ...i } = e;
    return /* @__PURE__ */ n.jsx(yt, { asChild: !0, children: /* @__PURE__ */ n.jsx(
      L.a,
      {
        "data-active": a ? "" : void 0,
        "aria-current": a ? "page" : void 0,
        ...i,
        ref: r,
        onClick: T(
          e.onClick,
          (d) => {
            const u = d.target, c = new CustomEvent(Ye, {
              bubbles: !0,
              cancelable: !0
            });
            if (u.addEventListener(Ye, (m) => o == null ? void 0 : o(m), { once: !0 }), We(u, c), !c.defaultPrevented && !d.metaKey) {
              const m = new CustomEvent(de, {
                bubbles: !0,
                cancelable: !0
              });
              We(u, m);
            }
          },
          { checkForDefaultPrevented: !1 }
        )
      }
    ) });
  }
);
xt.displayName = Jr;
var Ae = "NavigationMenuIndicator", Qr = s.forwardRef((e, r) => {
  const { forceMount: t, ...a } = e, o = z(Ae, e.__scopeNavigationMenu), i = !!o.value;
  return o.indicatorTrack ? Ut.createPortal(
    /* @__PURE__ */ n.jsx(le, { present: t || i, children: /* @__PURE__ */ n.jsx(Zr, { ...a, ref: r }) }),
    o.indicatorTrack
  ) : null;
});
Qr.displayName = Ae;
var Zr = s.forwardRef((e, r) => {
  const { __scopeNavigationMenu: t, ...a } = e, o = z(Ae, t), i = ut(t), [d, u] = s.useState(
    null
  ), [c, m] = s.useState(null), l = o.orientation === "horizontal", p = !!o.value;
  s.useEffect(() => {
    var M;
    const v = (M = i().find((R) => R.value === o.value)) == null ? void 0 : M.ref.current;
    v && u(v);
  }, [i, o.value]);
  const h = () => {
    d && m({
      size: l ? d.offsetWidth : d.offsetHeight,
      offset: l ? d.offsetLeft : d.offsetTop
    });
  };
  return Re(d, h), Re(o.indicatorTrack, h), c ? /* @__PURE__ */ n.jsx(
    L.div,
    {
      "aria-hidden": !0,
      "data-state": p ? "visible" : "hidden",
      "data-orientation": o.orientation,
      ...a,
      ref: r,
      style: {
        position: "absolute",
        ...l ? {
          left: 0,
          width: c.size + "px",
          transform: `translateX(${c.offset}px)`
        } : {
          top: 0,
          height: c.size + "px",
          transform: `translateY(${c.offset}px)`
        },
        ...a.style
      }
    }
  ) : null;
}), ee = "NavigationMenuContent", ht = s.forwardRef((e, r) => {
  const { forceMount: t, ...a } = e, o = z(ee, e.__scopeNavigationMenu), i = gt(ee, e.__scopeNavigationMenu), d = te(i.contentRef, r), u = i.value === o.value, c = {
    value: i.value,
    triggerRef: i.triggerRef,
    focusProxyRef: i.focusProxyRef,
    wasEscapeCloseRef: i.wasEscapeCloseRef,
    onContentFocusOutside: i.onContentFocusOutside,
    onRootContentClose: i.onRootContentClose,
    ...a
  };
  return o.viewport ? /* @__PURE__ */ n.jsx(ea, { forceMount: t, ...c, ref: d }) : /* @__PURE__ */ n.jsx(le, { present: t || u, children: /* @__PURE__ */ n.jsx(
    wt,
    {
      "data-state": Oe(u),
      ...c,
      ref: d,
      onPointerEnter: T(e.onPointerEnter, o.onContentEnter),
      onPointerLeave: T(
        e.onPointerLeave,
        ue(o.onContentLeave)
      ),
      style: {
        // Prevent interaction when animating out
        pointerEvents: !u && o.isRootMenu ? "none" : void 0,
        ...c.style
      }
    }
  ) });
});
ht.displayName = ee;
var ea = s.forwardRef((e, r) => {
  const t = z(ee, e.__scopeNavigationMenu), { onViewportContentChange: a, onViewportContentRemove: o } = t;
  return he(() => {
    a(e.value, {
      ref: r,
      ...e
    });
  }, [e, r, a]), he(() => () => o(e.value), [e.value, o]), null;
}), de = "navigationMenu.rootContentDismiss", wt = s.forwardRef((e, r) => {
  const {
    __scopeNavigationMenu: t,
    value: a,
    triggerRef: o,
    focusProxyRef: i,
    wasEscapeCloseRef: d,
    onRootContentClose: u,
    onContentFocusOutside: c,
    ...m
  } = e, l = z(ee, t), p = s.useRef(null), h = te(p, r), w = Ct(l.baseId, a), v = jt(l.baseId, a), M = ut(t), R = s.useRef(null), { onItemDismiss: _ } = l;
  s.useEffect(() => {
    const b = p.current;
    if (l.isRootMenu && b) {
      const y = () => {
        var N;
        _(), u(), b.contains(document.activeElement) && ((N = o.current) == null || N.focus());
      };
      return b.addEventListener(de, y), () => b.removeEventListener(de, y);
    }
  }, [l.isRootMenu, e.value, o, _, u]);
  const A = s.useMemo(() => {
    const y = M().map((B) => B.value);
    l.dir === "rtl" && y.reverse();
    const N = y.indexOf(l.value), j = y.indexOf(l.previousValue), k = a === l.value, $ = j === y.indexOf(a);
    if (!k && !$) return R.current;
    const S = (() => {
      if (N !== j) {
        if (k && j !== -1) return N > j ? "from-end" : "from-start";
        if ($ && N !== -1) return N > j ? "to-start" : "to-end";
      }
      return null;
    })();
    return R.current = S, S;
  }, [l.previousValue, l.value, l.dir, M, a]);
  return /* @__PURE__ */ n.jsx(Nt, { asChild: !0, children: /* @__PURE__ */ n.jsx(
    gr,
    {
      id: v,
      "aria-labelledby": w,
      "data-motion": A,
      "data-orientation": l.orientation,
      ...m,
      ref: h,
      disableOutsidePointerEvents: !1,
      onDismiss: () => {
        var y;
        const b = new Event(de, {
          bubbles: !0,
          cancelable: !0
        });
        (y = p.current) == null || y.dispatchEvent(b);
      },
      onFocusOutside: T(e.onFocusOutside, (b) => {
        var N;
        c();
        const y = b.target;
        (N = l.rootNavigationMenu) != null && N.contains(y) && b.preventDefault();
      }),
      onPointerDownOutside: T(e.onPointerDownOutside, (b) => {
        var k;
        const y = b.target, N = M().some(($) => {
          var S;
          return (S = $.ref.current) == null ? void 0 : S.contains(y);
        }), j = l.isRootMenu && ((k = l.viewport) == null ? void 0 : k.contains(y));
        (N || j || !l.isRootMenu) && b.preventDefault();
      }),
      onKeyDown: T(e.onKeyDown, (b) => {
        var j;
        const y = b.altKey || b.ctrlKey || b.metaKey;
        if (b.key === "Tab" && !y) {
          const k = je(b.currentTarget), $ = document.activeElement, S = k.findIndex((re) => re === $), W = b.shiftKey ? k.slice(0, S).reverse() : k.slice(S + 1, k.length);
          De(W) ? b.preventDefault() : (j = i.current) == null || j.focus();
        }
      }),
      onEscapeKeyDown: T(e.onEscapeKeyDown, (b) => {
        d.current = !0;
      })
    }
  ) });
}), Le = "NavigationMenuViewport", Mt = s.forwardRef((e, r) => {
  const { forceMount: t, ...a } = e, i = !!z(Le, e.__scopeNavigationMenu).value;
  return /* @__PURE__ */ n.jsx(le, { present: t || i, children: /* @__PURE__ */ n.jsx(ta, { ...a, ref: r }) });
});
Mt.displayName = Le;
var ta = s.forwardRef((e, r) => {
  const { __scopeNavigationMenu: t, children: a, ...o } = e, i = z(Le, t), d = te(r, i.onViewportChange), u = qr(
    ee,
    e.__scopeNavigationMenu
  ), [c, m] = s.useState(null), [l, p] = s.useState(null), h = c ? (c == null ? void 0 : c.width) + "px" : void 0, w = c ? (c == null ? void 0 : c.height) + "px" : void 0, v = !!i.value, M = v ? i.value : i.previousValue;
  return Re(l, () => {
    l && m({ width: l.offsetWidth, height: l.offsetHeight });
  }), /* @__PURE__ */ n.jsx(
    L.div,
    {
      "data-state": Oe(v),
      "data-orientation": i.orientation,
      ...o,
      ref: d,
      style: {
        // Prevent interaction when animating out
        pointerEvents: !v && i.isRootMenu ? "none" : void 0,
        "--radix-navigation-menu-viewport-width": h,
        "--radix-navigation-menu-viewport-height": w,
        ...o.style
      },
      onPointerEnter: T(e.onPointerEnter, i.onContentEnter),
      onPointerLeave: T(e.onPointerLeave, ue(i.onContentLeave)),
      children: Array.from(u.items).map(([_, { ref: A, forceMount: b, ...y }]) => {
        const N = M === _;
        return /* @__PURE__ */ n.jsx(le, { present: b || N, children: /* @__PURE__ */ n.jsx(
          wt,
          {
            ...y,
            ref: Z(A, (j) => {
              N && j && p(j);
            })
          }
        ) }, _);
      })
    }
  );
}), ra = "FocusGroup", Nt = s.forwardRef(
  (e, r) => {
    const { __scopeNavigationMenu: t, ...a } = e, o = z(ra, t);
    return /* @__PURE__ */ n.jsx(Ne.Provider, { scope: t, children: /* @__PURE__ */ n.jsx(Ne.Slot, { scope: t, children: /* @__PURE__ */ n.jsx(L.div, { dir: o.dir, ...a, ref: r }) }) });
  }
), Xe = ["ArrowRight", "ArrowLeft", "ArrowUp", "ArrowDown"], aa = "FocusGroupItem", yt = s.forwardRef(
  (e, r) => {
    const { __scopeNavigationMenu: t, ...a } = e, o = Vr(t), i = z(aa, t);
    return /* @__PURE__ */ n.jsx(Ne.ItemSlot, { scope: t, children: /* @__PURE__ */ n.jsx(
      L.button,
      {
        ...a,
        ref: r,
        onKeyDown: T(e.onKeyDown, (d) => {
          if (["Home", "End", ...Xe].includes(d.key)) {
            let c = o().map((p) => p.ref.current);
            if ([i.dir === "rtl" ? "ArrowRight" : "ArrowLeft", "ArrowUp", "End"].includes(d.key) && c.reverse(), Xe.includes(d.key)) {
              const p = c.indexOf(d.currentTarget);
              c = c.slice(p + 1);
            }
            setTimeout(() => De(c)), d.preventDefault();
          }
        })
      }
    ) });
  }
);
function je(e) {
  const r = [], t = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (a) => {
      const o = a.tagName === "INPUT" && a.type === "hidden";
      return a.disabled || a.hidden || o ? NodeFilter.FILTER_SKIP : a.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }
  });
  for (; t.nextNode(); ) r.push(t.currentNode);
  return r;
}
function De(e) {
  const r = document.activeElement;
  return e.some((t) => t === r ? !0 : (t.focus(), document.activeElement !== r));
}
function na(e) {
  return e.forEach((r) => {
    r.dataset.tabindex = r.getAttribute("tabindex") || "", r.setAttribute("tabindex", "-1");
  }), () => {
    e.forEach((r) => {
      const t = r.dataset.tabindex;
      r.setAttribute("tabindex", t);
    });
  };
}
function Re(e, r) {
  const t = U(r);
  he(() => {
    let a = 0;
    if (e) {
      const o = new ResizeObserver(() => {
        cancelAnimationFrame(a), a = window.requestAnimationFrame(t);
      });
      return o.observe(e), () => {
        window.cancelAnimationFrame(a), o.unobserve(e);
      };
    }
  }, [e, t]);
}
function Oe(e) {
  return e ? "open" : "closed";
}
function Ct(e, r) {
  return `${e}-trigger-${r}`;
}
function jt(e, r) {
  return `${e}-content-${r}`;
}
function ue(e) {
  return (r) => r.pointerType === "mouse" ? e(r) : void 0;
}
var oa = lt, ia = mt, sa = vt, da = bt, ua = xt, la = ht, ca = Mt, ie = "Menubar", [Ee, fa, ma] = Ie(ie), [Rt] = Je(ie, [
  ma,
  Ze
]), D = Jt(), Et = Ze(), [pa, Fe] = Rt(ie), kt = s.forwardRef(
  (e, r) => {
    const {
      __scopeMenubar: t,
      value: a,
      onValueChange: o,
      defaultValue: i,
      loop: d = !0,
      dir: u,
      ...c
    } = e, m = Qe(u), l = Et(t), [p, h] = ce({
      prop: a,
      onChange: o,
      defaultProp: i ?? "",
      caller: ie
    }), [w, v] = s.useState(null);
    return /* @__PURE__ */ n.jsx(
      pa,
      {
        scope: t,
        value: p,
        onMenuOpen: s.useCallback(
          (M) => {
            h(M), v(M);
          },
          [h]
        ),
        onMenuClose: s.useCallback(() => h(""), [h]),
        onMenuToggle: s.useCallback(
          (M) => {
            h((R) => R ? "" : M), v(M);
          },
          [h]
        ),
        dir: m,
        loop: d,
        children: /* @__PURE__ */ n.jsx(Ee.Provider, { scope: t, children: /* @__PURE__ */ n.jsx(Ee.Slot, { scope: t, children: /* @__PURE__ */ n.jsx(
          xr,
          {
            asChild: !0,
            ...l,
            orientation: "horizontal",
            loop: d,
            dir: m,
            currentTabStopId: w,
            onCurrentTabStopIdChange: v,
            children: /* @__PURE__ */ n.jsx(L.div, { role: "menubar", ...c, ref: r })
          }
        ) }) })
      }
    );
  }
);
kt.displayName = ie;
var Ke = "MenubarMenu", [ga, St] = Rt(Ke), It = (e) => {
  const { __scopeMenubar: r, value: t, ...a } = e, o = G(), i = t || o || "LEGACY_REACT_AUTO_VALUE", d = Fe(Ke, r), u = D(r), c = s.useRef(null), m = s.useRef(!1), l = d.value === i;
  return s.useEffect(() => {
    l || (m.current = !1);
  }, [l]), /* @__PURE__ */ n.jsx(
    ga,
    {
      scope: r,
      value: i,
      triggerId: G(),
      triggerRef: c,
      contentId: G(),
      wasKeyboardTriggerOpenRef: m,
      children: /* @__PURE__ */ n.jsx(
        lr,
        {
          ...u,
          open: l,
          onOpenChange: (p) => {
            p || d.onMenuClose();
          },
          modal: !1,
          dir: d.dir,
          ...a
        }
      )
    }
  );
};
It.displayName = Ke;
var ke = "MenubarTrigger", _t = s.forwardRef(
  (e, r) => {
    const { __scopeMenubar: t, disabled: a = !1, ...o } = e, i = Et(t), d = D(t), u = Fe(ke, t), c = St(ke, t), m = s.useRef(null), l = te(r, m, c.triggerRef), [p, h] = s.useState(!1), w = u.value === c.value;
    return /* @__PURE__ */ n.jsx(Ee.ItemSlot, { scope: t, value: c.value, disabled: a, children: /* @__PURE__ */ n.jsx(
      br,
      {
        asChild: !0,
        ...i,
        focusable: !a,
        tabStopId: c.value,
        children: /* @__PURE__ */ n.jsx(ur, { asChild: !0, ...d, children: /* @__PURE__ */ n.jsx(
          L.button,
          {
            type: "button",
            role: "menuitem",
            id: c.triggerId,
            "aria-haspopup": "menu",
            "aria-expanded": w,
            "aria-controls": w ? c.contentId : void 0,
            "data-highlighted": p ? "" : void 0,
            "data-state": w ? "open" : "closed",
            "data-disabled": a ? "" : void 0,
            disabled: a,
            ...o,
            ref: l,
            onPointerDown: T(e.onPointerDown, (v) => {
              !a && v.button === 0 && v.ctrlKey === !1 && (u.onMenuOpen(c.value), w || v.preventDefault());
            }),
            onPointerEnter: T(e.onPointerEnter, () => {
              var M;
              !!u.value && !w && (u.onMenuOpen(c.value), (M = m.current) == null || M.focus());
            }),
            onKeyDown: T(e.onKeyDown, (v) => {
              a || (["Enter", " "].includes(v.key) && u.onMenuToggle(c.value), v.key === "ArrowDown" && u.onMenuOpen(c.value), ["Enter", " ", "ArrowDown"].includes(v.key) && (c.wasKeyboardTriggerOpenRef.current = !0, v.preventDefault()));
            }),
            onFocus: T(e.onFocus, () => h(!0)),
            onBlur: T(e.onBlur, () => h(!1))
          }
        ) })
      }
    ) });
  }
);
_t.displayName = ke;
var va = "MenubarPortal", Tt = (e) => {
  const { __scopeMenubar: r, ...t } = e, a = D(r);
  return /* @__PURE__ */ n.jsx(Qt, { ...a, ...t });
};
Tt.displayName = va;
var Se = "MenubarContent", Pt = s.forwardRef(
  (e, r) => {
    const { __scopeMenubar: t, align: a = "start", ...o } = e, i = D(t), d = Fe(Se, t), u = St(Se, t), c = fa(t), m = s.useRef(!1);
    return /* @__PURE__ */ n.jsx(
      dr,
      {
        id: u.contentId,
        "aria-labelledby": u.triggerId,
        "data-radix-menubar-content": "",
        ...i,
        ...o,
        ref: r,
        align: a,
        onCloseAutoFocus: T(e.onCloseAutoFocus, (l) => {
          var h;
          !!!d.value && !m.current && ((h = u.triggerRef.current) == null || h.focus()), m.current = !1, l.preventDefault();
        }),
        onFocusOutside: T(e.onFocusOutside, (l) => {
          const p = l.target;
          c().some((w) => {
            var v;
            return (v = w.ref.current) == null ? void 0 : v.contains(p);
          }) && l.preventDefault();
        }),
        onInteractOutside: T(e.onInteractOutside, () => {
          m.current = !0;
        }),
        onEntryFocus: (l) => {
          u.wasKeyboardTriggerOpenRef.current || l.preventDefault();
        },
        onKeyDown: T(
          e.onKeyDown,
          (l) => {
            if (["ArrowRight", "ArrowLeft"].includes(l.key)) {
              const p = l.target, h = p.hasAttribute("data-radix-menubar-subtrigger"), w = p.closest("[data-radix-menubar-content]") !== l.currentTarget, M = (d.dir === "rtl" ? "ArrowRight" : "ArrowLeft") === l.key;
              if (!M && h || w && M) return;
              let A = c().filter((N) => !N.disabled).map((N) => N.value);
              M && A.reverse();
              const b = A.indexOf(u.value);
              A = d.loop ? _a(A, b + 1) : A.slice(b + 1);
              const [y] = A;
              y && d.onMenuOpen(y);
            }
          },
          { checkForDefaultPrevented: !1 }
        ),
        style: {
          ...e.style,
          "--radix-menubar-content-transform-origin": "var(--radix-popper-transform-origin)",
          "--radix-menubar-content-available-width": "var(--radix-popper-available-width)",
          "--radix-menubar-content-available-height": "var(--radix-popper-available-height)",
          "--radix-menubar-trigger-width": "var(--radix-popper-anchor-width)",
          "--radix-menubar-trigger-height": "var(--radix-popper-anchor-height)"
        }
      }
    );
  }
);
Pt.displayName = Se;
var ba = "MenubarGroup", xa = s.forwardRef(
  (e, r) => {
    const { __scopeMenubar: t, ...a } = e, o = D(t);
    return /* @__PURE__ */ n.jsx(cr, { ...o, ...a, ref: r });
  }
);
xa.displayName = ba;
var ha = "MenubarLabel", wa = s.forwardRef(
  (e, r) => {
    const { __scopeMenubar: t, ...a } = e, o = D(t);
    return /* @__PURE__ */ n.jsx(fr, { ...o, ...a, ref: r });
  }
);
wa.displayName = ha;
var Ma = "MenubarItem", At = s.forwardRef(
  (e, r) => {
    const { __scopeMenubar: t, ...a } = e, o = D(t);
    return /* @__PURE__ */ n.jsx(sr, { ...o, ...a, ref: r });
  }
);
At.displayName = Ma;
var Na = "MenubarCheckboxItem", Lt = s.forwardRef(
  (e, r) => {
    const { __scopeMenubar: t, ...a } = e, o = D(t);
    return /* @__PURE__ */ n.jsx(or, { ...o, ...a, ref: r });
  }
);
Lt.displayName = Na;
var ya = "MenubarRadioGroup", Dt = s.forwardRef(
  (e, r) => {
    const { __scopeMenubar: t, ...a } = e, o = D(t);
    return /* @__PURE__ */ n.jsx(nr, { ...o, ...a, ref: r });
  }
);
Dt.displayName = ya;
var Ca = "MenubarRadioItem", Ot = s.forwardRef(
  (e, r) => {
    const { __scopeMenubar: t, ...a } = e, o = D(t);
    return /* @__PURE__ */ n.jsx(rr, { ...o, ...a, ref: r });
  }
);
Ot.displayName = Ca;
var ja = "MenubarItemIndicator", Ft = s.forwardRef((e, r) => {
  const { __scopeMenubar: t, ...a } = e, o = D(t);
  return /* @__PURE__ */ n.jsx(ar, { ...o, ...a, ref: r });
});
Ft.displayName = ja;
var Ra = "MenubarSeparator", Kt = s.forwardRef(
  (e, r) => {
    const { __scopeMenubar: t, ...a } = e, o = D(t);
    return /* @__PURE__ */ n.jsx(ir, { ...o, ...a, ref: r });
  }
);
Kt.displayName = Ra;
var Ea = "MenubarArrow", ka = s.forwardRef(
  (e, r) => {
    const { __scopeMenubar: t, ...a } = e, o = D(t);
    return /* @__PURE__ */ n.jsx(mr, { ...o, ...a, ref: r });
  }
);
ka.displayName = Ea;
var $t = "MenubarSub", zt = (e) => {
  const { __scopeMenubar: r, children: t, open: a, onOpenChange: o, defaultOpen: i } = e, d = D(r), [u, c] = ce({
    prop: a,
    defaultProp: i ?? !1,
    onChange: o,
    caller: $t
  });
  return /* @__PURE__ */ n.jsx(tr, { ...d, open: u, onOpenChange: c, children: t });
};
zt.displayName = $t;
var Sa = "MenubarSubTrigger", Bt = s.forwardRef(
  (e, r) => {
    const { __scopeMenubar: t, ...a } = e, o = D(t);
    return /* @__PURE__ */ n.jsx(
      er,
      {
        "data-radix-menubar-subtrigger": "",
        ...o,
        ...a,
        ref: r
      }
    );
  }
);
Bt.displayName = Sa;
var Ia = "MenubarSubContent", Gt = s.forwardRef(
  (e, r) => {
    const { __scopeMenubar: t, ...a } = e, o = D(t);
    return /* @__PURE__ */ n.jsx(
      Zt,
      {
        ...o,
        "data-radix-menubar-content": "",
        ...a,
        ref: r,
        style: {
          ...e.style,
          "--radix-menubar-content-transform-origin": "var(--radix-popper-transform-origin)",
          "--radix-menubar-content-available-width": "var(--radix-popper-available-width)",
          "--radix-menubar-content-available-height": "var(--radix-popper-available-height)",
          "--radix-menubar-trigger-width": "var(--radix-popper-anchor-width)",
          "--radix-menubar-trigger-height": "var(--radix-popper-anchor-height)"
        }
      }
    );
  }
);
Gt.displayName = Ia;
function _a(e, r) {
  return e.map((t, a) => e[(r + a) % e.length]);
}
var Ta = kt, Pa = It, Aa = _t, Vt = Tt, La = Pt, Da = At, Oa = Lt, Fa = Dt, Ka = Ot, Wt = Ft, $a = Kt, za = zt, Ba = Bt, Ga = Gt;
function Za({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "nav",
    {
      id: e,
      "aria-label": "breadcrumb",
      className: r,
      "data-refast-id": a,
      children: /* @__PURE__ */ n.jsx("ol", { className: "flex flex-wrap items-center gap-1.5 break-words text-sm text-muted-foreground sm:gap-2.5", children: t })
    }
  );
}
function en({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "ol",
    {
      id: e,
      className: g(
        "flex flex-wrap items-center gap-1.5 break-words text-sm text-muted-foreground sm:gap-2.5",
        r
      ),
      "data-refast-id": a,
      children: t
    }
  );
}
function tn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "li",
    {
      id: e,
      className: g("inline-flex items-center gap-1.5", r),
      "data-refast-id": a,
      children: t
    }
  );
}
function rn({
  id: e,
  className: r,
  href: t = "#",
  onClick: a,
  children: o,
  "data-refast-id": i
}) {
  return /* @__PURE__ */ n.jsx(
    "a",
    {
      id: e,
      href: t,
      onClick: (d) => {
        a && (d.preventDefault(), a());
      },
      className: g("transition-colors hover:text-foreground", r),
      "data-refast-id": i,
      children: o
    }
  );
}
function an({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "span",
    {
      id: e,
      role: "link",
      "aria-disabled": "true",
      "aria-current": "page",
      className: g("font-normal text-foreground", r),
      "data-refast-id": a,
      children: t
    }
  );
}
function nn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "li",
    {
      id: e,
      role: "presentation",
      "aria-hidden": "true",
      className: g("[&>svg]:size-3.5", r),
      "data-refast-id": a,
      children: t || /* @__PURE__ */ n.jsx(
        "svg",
        {
          xmlns: "http://www.w3.org/2000/svg",
          width: "16",
          height: "16",
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: "currentColor",
          strokeWidth: "2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          children: /* @__PURE__ */ n.jsx("path", { d: "m9 18 6-6-6-6" })
        }
      )
    }
  );
}
function on({
  id: e,
  className: r,
  "data-refast-id": t
}) {
  return /* @__PURE__ */ n.jsxs(
    "span",
    {
      id: e,
      role: "presentation",
      "aria-hidden": "true",
      className: g("flex h-9 w-9 items-center justify-center", r),
      "data-refast-id": t,
      children: [
        /* @__PURE__ */ n.jsxs(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "h-4 w-4",
            children: [
              /* @__PURE__ */ n.jsx("circle", { cx: "12", cy: "12", r: "1" }),
              /* @__PURE__ */ n.jsx("circle", { cx: "19", cy: "12", r: "1" }),
              /* @__PURE__ */ n.jsx("circle", { cx: "5", cy: "12", r: "1" })
            ]
          }
        ),
        /* @__PURE__ */ n.jsx("span", { className: "sr-only", children: "More" })
      ]
    }
  );
}
function sn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsxs(
    oa,
    {
      id: e,
      className: g(
        "relative z-10 flex max-w-max flex-1 items-center justify-center",
        r
      ),
      "data-refast-id": a,
      children: [
        t,
        /* @__PURE__ */ n.jsx(Va, {})
      ]
    }
  );
}
function Va() {
  return /* @__PURE__ */ n.jsx("div", { className: "absolute left-0 top-full flex justify-center", children: /* @__PURE__ */ n.jsx(
    ca,
    {
      className: g(
        "origin-top-center relative mt-1.5 h-[var(--radix-navigation-menu-viewport-height)] w-full overflow-hidden rounded-md border bg-popover text-popover-foreground shadow-lg",
        "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-90",
        "md:w-[var(--radix-navigation-menu-viewport-width)]"
      )
    }
  ) });
}
function dn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    ia,
    {
      id: e,
      className: g(
        "group flex flex-1 list-none items-center justify-center space-x-1",
        r
      ),
      "data-refast-id": a,
      children: t
    }
  );
}
function un({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    sa,
    {
      id: e,
      className: r,
      "data-refast-id": a,
      children: t
    }
  );
}
function ln({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsxs(
    da,
    {
      id: e,
      className: g(
        "group inline-flex h-10 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium transition-colors",
        "hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground focus:outline-none",
        "disabled:pointer-events-none disabled:opacity-50 data-[active]:bg-accent/50 data-[state=open]:bg-accent/50",
        r
      ),
      "data-refast-id": a,
      children: [
        t,
        /* @__PURE__ */ n.jsx(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "relative top-[1px] ml-1 h-3 w-3 transition duration-200 group-data-[state=open]:rotate-180",
            "aria-hidden": "true",
            children: /* @__PURE__ */ n.jsx("path", { d: "m6 9 6 6 6-6" })
          }
        )
      ]
    }
  );
}
function cn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    la,
    {
      id: e,
      className: g(
        "left-0 top-0 w-full data-[motion^=from-]:animate-in data-[motion^=to-]:animate-out",
        "data-[motion^=from-]:fade-in data-[motion^=to-]:fade-out",
        "data-[motion=from-end]:slide-in-from-right-52 data-[motion=from-start]:slide-in-from-left-52",
        "data-[motion=to-end]:slide-out-to-right-52 data-[motion=to-start]:slide-out-to-left-52",
        "md:absolute md:w-auto",
        r
      ),
      "data-refast-id": a,
      children: t
    }
  );
}
function fn({
  id: e,
  className: r,
  href: t = "#",
  active: a,
  onClick: o,
  children: i,
  "data-refast-id": d
}) {
  return /* @__PURE__ */ n.jsx(
    ua,
    {
      id: e,
      href: t,
      active: a,
      onClick: (u) => {
        o && (u.preventDefault(), o());
      },
      className: g(
        "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors",
        "hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
        r
      ),
      "data-refast-id": d,
      children: i
    }
  );
}
function mn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "nav",
    {
      id: e,
      role: "navigation",
      "aria-label": "pagination",
      className: g("mx-auto flex w-full justify-center", r),
      "data-refast-id": a,
      children: t
    }
  );
}
function pn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "ul",
    {
      id: e,
      className: g("flex flex-row items-center gap-1", r),
      "data-refast-id": a,
      children: t
    }
  );
}
function gn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx("li", { id: e, className: r, "data-refast-id": a, children: t });
}
function vn({
  id: e,
  className: r,
  href: t = "#",
  active: a,
  onClick: o,
  children: i,
  "data-refast-id": d
}) {
  return /* @__PURE__ */ n.jsx(
    "a",
    {
      id: e,
      href: t,
      onClick: (u) => {
        o && (u.preventDefault(), o());
      },
      "aria-current": a ? "page" : void 0,
      className: g(
        "inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "h-10 w-10",
        a ? "border border-input bg-background hover:bg-accent hover:text-accent-foreground" : "hover:bg-accent hover:text-accent-foreground",
        r
      ),
      "data-refast-id": d,
      children: i
    }
  );
}
function bn({
  id: e,
  className: r,
  href: t = "#",
  onClick: a,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ n.jsxs(
    "a",
    {
      id: e,
      href: t,
      onClick: (i) => {
        a && (i.preventDefault(), a());
      },
      "aria-label": "Go to previous page",
      className: g(
        "inline-flex items-center justify-center gap-1 pl-2.5 pr-4 h-10 rounded-md text-sm font-medium",
        "hover:bg-accent hover:text-accent-foreground transition-colors",
        r
      ),
      "data-refast-id": o,
      children: [
        /* @__PURE__ */ n.jsx(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "h-4 w-4",
            children: /* @__PURE__ */ n.jsx("path", { d: "m15 18-6-6 6-6" })
          }
        ),
        /* @__PURE__ */ n.jsx("span", { children: "Previous" })
      ]
    }
  );
}
function xn({
  id: e,
  className: r,
  href: t = "#",
  onClick: a,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ n.jsxs(
    "a",
    {
      id: e,
      href: t,
      onClick: (i) => {
        a && (i.preventDefault(), a());
      },
      "aria-label": "Go to next page",
      className: g(
        "inline-flex items-center justify-center gap-1 pr-2.5 pl-4 h-10 rounded-md text-sm font-medium",
        "hover:bg-accent hover:text-accent-foreground transition-colors",
        r
      ),
      "data-refast-id": o,
      children: [
        /* @__PURE__ */ n.jsx("span", { children: "Next" }),
        /* @__PURE__ */ n.jsx(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "h-4 w-4",
            children: /* @__PURE__ */ n.jsx("path", { d: "m9 18 6-6-6-6" })
          }
        )
      ]
    }
  );
}
function hn({
  id: e,
  className: r,
  "data-refast-id": t
}) {
  return /* @__PURE__ */ n.jsxs(
    "span",
    {
      id: e,
      "aria-hidden": !0,
      className: g("flex h-9 w-9 items-center justify-center", r),
      "data-refast-id": t,
      children: [
        /* @__PURE__ */ n.jsxs(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "h-4 w-4",
            children: [
              /* @__PURE__ */ n.jsx("circle", { cx: "12", cy: "12", r: "1" }),
              /* @__PURE__ */ n.jsx("circle", { cx: "19", cy: "12", r: "1" }),
              /* @__PURE__ */ n.jsx("circle", { cx: "5", cy: "12", r: "1" })
            ]
          }
        ),
        /* @__PURE__ */ n.jsx("span", { className: "sr-only", children: "More pages" })
      ]
    }
  );
}
function wn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    Ta,
    {
      id: e,
      className: g(
        "flex h-10 items-center space-x-1 rounded-md border bg-background p-1",
        r
      ),
      "data-refast-id": a,
      children: t
    }
  );
}
function Mn({
  children: e,
  "data-refast-id": r
}) {
  return /* @__PURE__ */ n.jsx(Pa, { "data-refast-id": r, children: e });
}
function Nn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    Aa,
    {
      id: e,
      className: g(
        "flex cursor-default select-none items-center rounded-sm px-3 py-1.5 text-sm font-medium outline-none",
        "focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground",
        r
      ),
      "data-refast-id": a,
      children: t
    }
  );
}
function yn({
  id: e,
  className: r,
  align: t = "start",
  sideOffset: a = 5,
  children: o,
  "data-refast-id": i
}) {
  return /* @__PURE__ */ n.jsx(Vt, { children: /* @__PURE__ */ n.jsx(
    La,
    {
      id: e,
      align: t,
      sideOffset: a,
      className: g(
        "z-50 min-w-[12rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md",
        "data-[state=open]:animate-in data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
        "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
        "data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2",
        "data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
        r
      ),
      "data-refast-id": i,
      children: o
    }
  ) });
}
function Cn({
  id: e,
  className: r,
  shortcut: t,
  disabled: a,
  onSelect: o,
  children: i,
  "data-refast-id": d
}) {
  return /* @__PURE__ */ n.jsxs(
    Da,
    {
      id: e,
      disabled: a,
      onSelect: o,
      className: g(
        "relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none",
        "focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        r
      ),
      "data-refast-id": d,
      children: [
        i,
        t && /* @__PURE__ */ n.jsx("span", { className: "ml-auto text-xs tracking-widest text-muted-foreground", children: t })
      ]
    }
  );
}
function jn({
  id: e,
  className: r,
  "data-refast-id": t
}) {
  return /* @__PURE__ */ n.jsx(
    $a,
    {
      id: e,
      className: g("-mx-1 my-1 h-px bg-muted", r),
      "data-refast-id": t
    }
  );
}
function Rn({
  id: e,
  className: r,
  checked: t,
  onCheckedChange: a,
  disabled: o,
  children: i,
  "data-refast-id": d
}) {
  return /* @__PURE__ */ n.jsxs(
    Oa,
    {
      id: e,
      checked: t,
      onCheckedChange: a,
      disabled: o,
      className: g(
        "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none",
        "focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        r
      ),
      "data-refast-id": d,
      children: [
        /* @__PURE__ */ n.jsx("span", { className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ n.jsx(Wt, { children: /* @__PURE__ */ n.jsx(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "h-4 w-4",
            children: /* @__PURE__ */ n.jsx("polyline", { points: "20 6 9 17 4 12" })
          }
        ) }) }),
        i
      ]
    }
  );
}
function En({
  id: e,
  className: r,
  value: t,
  onValueChange: a,
  children: o,
  "data-refast-id": i
}) {
  return /* @__PURE__ */ n.jsx(
    Fa,
    {
      id: e,
      value: t,
      onValueChange: a,
      className: r,
      "data-refast-id": i,
      children: o
    }
  );
}
function kn({
  id: e,
  className: r,
  value: t,
  children: a,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ n.jsxs(
    Ka,
    {
      id: e,
      value: t,
      className: g(
        "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none",
        "focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        r
      ),
      "data-refast-id": o,
      children: [
        /* @__PURE__ */ n.jsx("span", { className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ n.jsx(Wt, { children: /* @__PURE__ */ n.jsx(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "h-2 w-2 fill-current",
            children: /* @__PURE__ */ n.jsx("circle", { cx: "12", cy: "12", r: "10" })
          }
        ) }) }),
        a
      ]
    }
  );
}
function Sn({
  children: e,
  "data-refast-id": r
}) {
  return /* @__PURE__ */ n.jsx(za, { "data-refast-id": r, children: e });
}
function In({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsxs(
    Ba,
    {
      id: e,
      className: g(
        "flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none",
        "focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground",
        r
      ),
      "data-refast-id": a,
      children: [
        t,
        /* @__PURE__ */ n.jsx(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "ml-auto h-4 w-4",
            children: /* @__PURE__ */ n.jsx("path", { d: "m9 18 6-6-6-6" })
          }
        )
      ]
    }
  );
}
function _n({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(Vt, { children: /* @__PURE__ */ n.jsx(
    Ga,
    {
      id: e,
      className: g(
        "z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground",
        "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
        "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
        "data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2",
        "data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
        r
      ),
      "data-refast-id": a,
      children: t
    }
  ) });
}
function Tn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    q,
    {
      id: e,
      className: g(
        "flex h-full w-full flex-col overflow-hidden rounded-md bg-popover text-popover-foreground",
        r
      ),
      "data-refast-id": a,
      children: t
    }
  );
}
function Pn({
  id: e,
  className: r,
  placeholder: t = "Search...",
  value: a,
  onValueChange: o,
  "data-refast-id": i
}) {
  return /* @__PURE__ */ n.jsxs("div", { className: "flex items-center border-b px-3", "cmdk-input-wrapper": "", "data-refast-id": i, children: [
    /* @__PURE__ */ n.jsxs(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        width: "16",
        height: "16",
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "2",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        className: "mr-2 h-4 w-4 shrink-0 opacity-50",
        children: [
          /* @__PURE__ */ n.jsx("circle", { cx: "11", cy: "11", r: "8" }),
          /* @__PURE__ */ n.jsx("path", { d: "m21 21-4.3-4.3" })
        ]
      }
    ),
    /* @__PURE__ */ n.jsx(
      q.Input,
      {
        id: e,
        value: a,
        onValueChange: o,
        placeholder: t,
        className: g(
          "flex h-11 w-full rounded-md bg-transparent py-3 text-sm outline-none",
          "placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50",
          r
        )
      }
    )
  ] });
}
function An({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    q.List,
    {
      id: e,
      className: g("max-h-[300px] overflow-y-auto overflow-x-hidden", r),
      "data-refast-id": a,
      children: t
    }
  );
}
function Ln({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    q.Empty,
    {
      id: e,
      className: g("py-6 text-center text-sm", r),
      "data-refast-id": a,
      children: t
    }
  );
}
function Dn({
  id: e,
  className: r,
  heading: t,
  children: a,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ n.jsx(
    q.Group,
    {
      id: e,
      heading: t,
      className: g(
        "overflow-hidden p-1 text-foreground",
        "[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs",
        "[&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground",
        r
      ),
      "data-refast-id": o,
      children: a
    }
  );
}
function On({
  id: e,
  className: r,
  icon: t,
  value: a,
  disabled: o,
  onSelect: i,
  children: d,
  "data-refast-id": u
}) {
  return /* @__PURE__ */ n.jsxs(
    q.Item,
    {
      id: e,
      value: a,
      disabled: o,
      onSelect: i,
      className: g(
        "relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none",
        "aria-selected:bg-accent aria-selected:text-accent-foreground",
        "data-[disabled=true]:pointer-events-none data-[disabled=true]:opacity-50",
        r
      ),
      "data-refast-id": u,
      children: [
        t && /* @__PURE__ */ n.jsx(et, { name: t, size: 16, className: "shrink-0" }),
        d
      ]
    }
  );
}
function Fn({
  id: e,
  className: r,
  "data-refast-id": t
}) {
  return /* @__PURE__ */ n.jsx(
    q.Separator,
    {
      id: e,
      className: g("-mx-1 h-px bg-border", r),
      "data-refast-id": t
    }
  );
}
function Kn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "span",
    {
      id: e,
      className: g("ml-auto text-xs tracking-widest text-muted-foreground", r),
      "data-refast-id": a,
      children: t
    }
  );
}
const Wa = "16rem", Ua = "18rem", Ha = "3rem", qa = "b", me = K.createContext(null);
function $n({
  id: e,
  className: r,
  defaultOpen: t = !0,
  open: a,
  onOpenChange: o,
  children: i,
  style: d,
  "data-refast-id": u
}) {
  const [c, m] = K.useState(!1), [l, p] = K.useState(!1), [h, w] = K.useState(t), v = a ?? h, M = K.useCallback(
    (b) => {
      const y = typeof b == "function" ? b(v) : b;
      o ? o(y) : w(y);
    },
    [o, v]
  ), R = K.useCallback(() => c ? p((b) => !b) : M((b) => !b), [c, M, p]);
  K.useEffect(() => {
    const b = () => {
      m(window.innerWidth < 768);
    };
    return b(), window.addEventListener("resize", b), () => window.removeEventListener("resize", b);
  }, []), K.useEffect(() => {
    const b = (y) => {
      y.key === qa && (y.metaKey || y.ctrlKey) && (y.preventDefault(), R());
    };
    return window.addEventListener("keydown", b), () => window.removeEventListener("keydown", b);
  }, [R]);
  const _ = v ? "expanded" : "collapsed", A = K.useMemo(
    () => ({
      state: _,
      open: v,
      setOpen: M,
      isMobile: c,
      openMobile: l,
      setOpenMobile: p,
      toggleSidebar: R
    }),
    [_, v, M, c, l, p, R]
  );
  return /* @__PURE__ */ n.jsx(me.Provider, { value: A, children: /* @__PURE__ */ n.jsx(
    "div",
    {
      id: e,
      style: {
        "--sidebar-width": Wa,
        "--sidebar-width-mobile": Ua,
        "--sidebar-width-icon": Ha,
        ...d
      },
      className: g(
        "group/sidebar-wrapper flex min-h-svh w-full has-[[data-variant=inset]]:bg-sidebar",
        r
      ),
      "data-refast-id": u,
      children: i
    }
  ) });
}
function zn({
  id: e,
  className: r,
  side: t = "left",
  variant: a = "sidebar",
  collapsible: o = "offcanvas",
  children: i,
  "data-refast-id": d
}) {
  const u = K.useContext(me);
  if (!u)
    return /* @__PURE__ */ n.jsx(
      "aside",
      {
        id: e,
        className: g(
          "flex h-full w-64 flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border",
          t === "right" && "border-l border-r-0",
          r
        ),
        "data-refast-id": d,
        children: i
      }
    );
  const { isMobile: c, state: m, openMobile: l, setOpenMobile: p } = u;
  return o === "none" ? /* @__PURE__ */ n.jsx(
    "div",
    {
      id: e,
      className: g(
        "flex h-full w-[--sidebar-width] flex-col bg-sidebar text-sidebar-foreground",
        r
      ),
      "data-refast-id": d,
      children: i
    }
  ) : c ? /* @__PURE__ */ n.jsxs(n.Fragment, { children: [
    l && /* @__PURE__ */ n.jsx(
      "div",
      {
        className: "fixed inset-0 z-50 bg-black/80",
        onClick: () => p(!1)
      }
    ),
    /* @__PURE__ */ n.jsx(
      "aside",
      {
        id: e,
        className: g(
          "fixed inset-y-0 z-50 flex h-svh w-[--sidebar-width-mobile] flex-col bg-sidebar text-sidebar-foreground",
          "transition-transform duration-200 ease-in-out",
          t === "left" ? "left-0" : "right-0",
          l ? "translate-x-0" : t === "left" ? "-translate-x-full" : "translate-x-full",
          r
        ),
        "data-refast-id": d,
        children: i
      }
    )
  ] }) : /* @__PURE__ */ n.jsxs(
    "div",
    {
      className: "group peer hidden md:block text-sidebar-foreground",
      "data-state": m,
      "data-collapsible": m === "collapsed" ? o : "",
      "data-variant": a,
      "data-side": t,
      children: [
        /* @__PURE__ */ n.jsx(
          "div",
          {
            className: g(
              "relative h-svh w-[--sidebar-width] bg-transparent transition-[width] duration-200 ease-linear",
              "group-data-[collapsible=offcanvas]:w-0",
              "group-data-[side=right]:rotate-180",
              a === "floating" || a === "inset" ? "group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)_+_theme(spacing.4))]" : "group-data-[collapsible=icon]:w-[--sidebar-width-icon]"
            )
          }
        ),
        /* @__PURE__ */ n.jsx(
          "aside",
          {
            id: e,
            className: g(
              "fixed inset-y-0 z-10 hidden h-svh w-[--sidebar-width] transition-[left,right,width] duration-200 ease-linear md:flex",
              t === "left" ? "left-0 group-data-[collapsible=offcanvas]:left-[calc(var(--sidebar-width)*-1)]" : "right-0 group-data-[collapsible=offcanvas]:right-[calc(var(--sidebar-width)*-1)]",
              "group-data-[collapsible=icon]:w-[--sidebar-width-icon] group-data-[collapsible=icon]:overflow-hidden",
              a === "floating" || a === "inset" ? "p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)_+_theme(spacing.4)_+2px)]" : "group-data-[side=left]:border-r group-data-[side=right]:border-l border-sidebar-border",
              r
            ),
            "data-refast-id": d,
            children: /* @__PURE__ */ n.jsx(
              "div",
              {
                "data-sidebar": "sidebar",
                className: g(
                  "flex h-full w-full flex-col bg-sidebar",
                  a === "floating" && "rounded-lg border border-sidebar-border shadow",
                  a === "inset" && "rounded-lg border border-sidebar-border shadow"
                ),
                children: i
              }
            )
          }
        )
      ]
    }
  );
}
function Bn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "main",
    {
      id: e,
      className: g(
        "relative flex min-h-svh flex-1 flex-col bg-background",
        "peer-data-[variant=inset]:min-h-[calc(100svh-theme(spacing.4))] md:peer-data-[variant=inset]:m-2 md:peer-data-[state=collapsed]:peer-data-[variant=inset]:ml-2 md:peer-data-[variant=inset]:ml-0 md:peer-data-[variant=inset]:rounded-xl md:peer-data-[variant=inset]:shadow",
        r
      ),
      "data-refast-id": a,
      children: t
    }
  );
}
function Gn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "div",
    {
      id: e,
      "data-sidebar": "header",
      className: g("flex flex-col gap-2 p-2", r),
      "data-refast-id": a,
      children: t
    }
  );
}
function Vn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "div",
    {
      id: e,
      "data-sidebar": "content",
      className: g(
        "flex min-h-0 flex-1 flex-col gap-2 overflow-auto group-data-[collapsible=icon]:overflow-hidden",
        r
      ),
      "data-refast-id": a,
      children: t
    }
  );
}
function Wn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "div",
    {
      id: e,
      "data-sidebar": "footer",
      className: g("flex flex-col gap-2 p-2", r),
      "data-refast-id": a,
      children: t
    }
  );
}
function Un({
  id: e,
  className: r,
  "data-refast-id": t
}) {
  return /* @__PURE__ */ n.jsx(
    "hr",
    {
      id: e,
      "data-sidebar": "separator",
      className: g("mx-2 w-auto bg-sidebar-border", r),
      "data-refast-id": t
    }
  );
}
function Hn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "div",
    {
      id: e,
      "data-sidebar": "group",
      className: g("relative flex w-full min-w-0 flex-col p-2", r),
      "data-refast-id": a,
      children: t
    }
  );
}
function qn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "div",
    {
      id: e,
      "data-sidebar": "group-label",
      className: g(
        "flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium text-sidebar-foreground/70 outline-none ring-sidebar-ring transition-[margin,opa] duration-200 ease-linear",
        "focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0",
        "group-data-[collapsible=icon]:-mt-8 group-data-[collapsible=icon]:opacity-0",
        r
      ),
      "data-refast-id": a,
      children: t
    }
  );
}
function Yn({
  id: e,
  className: r,
  children: t,
  onClick: a,
  title: o,
  "data-refast-id": i
}) {
  return /* @__PURE__ */ n.jsx(
    "button",
    {
      id: e,
      "data-sidebar": "group-action",
      onClick: a,
      title: o,
      className: g(
        "absolute right-3 top-3.5 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground outline-none ring-sidebar-ring transition-transform hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2",
        "[&>svg]:size-4 [&>svg]:shrink-0",
        "after:absolute after:-inset-2 after:md:hidden",
        "group-data-[collapsible=icon]:hidden",
        r
      ),
      "data-refast-id": i,
      children: t
    }
  );
}
function Xn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "div",
    {
      id: e,
      "data-sidebar": "group-content",
      className: g("w-full text-sm", r),
      "data-refast-id": a,
      children: t
    }
  );
}
function Jn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "ul",
    {
      id: e,
      "data-sidebar": "menu",
      className: g("flex w-full min-w-0 flex-col gap-1", r),
      "data-refast-id": a,
      children: t
    }
  );
}
function Qn({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "li",
    {
      id: e,
      "data-sidebar": "menu-item",
      className: g("group/menu-item relative", r),
      "data-refast-id": a,
      children: t
    }
  );
}
function Zn({
  id: e,
  className: r,
  icon: t,
  isActive: a = !1,
  variant: o = "default",
  size: i = "default",
  onClick: d,
  href: u,
  children: c,
  "data-refast-id": m
}) {
  const l = g(
    "peer/menu-button flex w-full items-center gap-2 overflow-hidden rounded-md p-2 text-left text-sm outline-none ring-sidebar-ring transition-[width,height,padding] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 group-has-[[data-sidebar=menu-action]]/menu-item:pr-8 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-[active=true]:bg-sidebar-accent data-[active=true]:font-medium data-[active=true]:text-sidebar-accent-foreground data-[state=open]:hover:bg-sidebar-accent data-[state=open]:hover:text-sidebar-accent-foreground",
    "group-data-[collapsible=icon]:!size-8 group-data-[collapsible=icon]:!p-2 [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0",
    o === "outline" && "bg-background shadow-[0_0_0_1px_hsl(var(--sidebar-border))] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:shadow-[0_0_0_1px_hsl(var(--sidebar-accent))]",
    i === "sm" && "h-7 text-xs",
    i === "lg" && "h-12 text-sm group-data-[collapsible=icon]:!p-0",
    r
  ), p = /* @__PURE__ */ n.jsxs(n.Fragment, { children: [
    t && /* @__PURE__ */ n.jsx(et, { name: t, size: 16, className: "shrink-0" }),
    /* @__PURE__ */ n.jsx("span", { className: "truncate", children: c })
  ] });
  return u ? /* @__PURE__ */ n.jsx(
    "a",
    {
      id: e,
      href: u,
      "data-sidebar": "menu-button",
      "data-size": i,
      "data-active": a,
      className: l,
      "data-refast-id": m,
      children: p
    }
  ) : /* @__PURE__ */ n.jsx(
    "button",
    {
      id: e,
      "data-sidebar": "menu-button",
      "data-size": i,
      "data-active": a,
      onClick: d,
      className: l,
      "data-refast-id": m,
      children: p
    }
  );
}
function eo({
  id: e,
  className: r,
  showOnHover: t = !1,
  onClick: a,
  children: o,
  "data-refast-id": i
}) {
  return /* @__PURE__ */ n.jsx(
    "button",
    {
      id: e,
      "data-sidebar": "menu-action",
      onClick: a,
      className: g(
        "absolute right-1 top-1.5 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground outline-none ring-sidebar-ring transition-transform hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 peer-hover/menu-button:text-sidebar-accent-foreground",
        "[&>svg]:size-4 [&>svg]:shrink-0",
        "after:absolute after:-inset-2 after:md:hidden",
        "peer-data-[size=sm]/menu-button:top-1",
        "peer-data-[size=default]/menu-button:top-1.5",
        "peer-data-[size=lg]/menu-button:top-2.5",
        "group-data-[collapsible=icon]:hidden",
        t && "group-focus-within/menu-item:opacity-100 group-hover/menu-item:opacity-100 data-[state=open]:opacity-100 peer-data-[active=true]/menu-button:text-sidebar-accent-foreground md:opacity-0",
        r
      ),
      "data-refast-id": i,
      children: o
    }
  );
}
function to({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "div",
    {
      id: e,
      "data-sidebar": "menu-badge",
      className: g(
        "absolute right-1 flex h-5 min-w-5 items-center justify-center rounded-md px-1 text-xs font-medium tabular-nums text-sidebar-foreground select-none pointer-events-none",
        "peer-hover/menu-button:text-sidebar-accent-foreground peer-data-[active=true]/menu-button:text-sidebar-accent-foreground",
        "peer-data-[size=sm]/menu-button:top-1",
        "peer-data-[size=default]/menu-button:top-1.5",
        "peer-data-[size=lg]/menu-button:top-2.5",
        "group-data-[collapsible=icon]:hidden",
        r
      ),
      "data-refast-id": a,
      children: t
    }
  );
}
function ro({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "ul",
    {
      id: e,
      "data-sidebar": "menu-sub",
      className: g(
        "mx-3.5 flex min-w-0 translate-x-px flex-col gap-1 border-l border-sidebar-border px-2.5 py-0.5",
        "group-data-[collapsible=icon]:hidden",
        r
      ),
      "data-refast-id": a,
      children: t
    }
  );
}
function ao({
  id: e,
  className: r,
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ n.jsx(
    "li",
    {
      id: e,
      className: r,
      "data-refast-id": a,
      children: t
    }
  );
}
function no({
  id: e,
  className: r,
  isActive: t = !1,
  size: a = "md",
  href: o,
  onClick: i,
  children: d,
  "data-refast-id": u
}) {
  const c = g(
    "flex h-7 min-w-0 -translate-x-px items-center gap-2 overflow-hidden rounded-md px-2 text-sidebar-foreground outline-none ring-sidebar-ring hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0 [&>svg]:text-sidebar-accent-foreground",
    t && "bg-sidebar-accent text-sidebar-accent-foreground",
    a === "sm" && "text-xs",
    a === "md" && "text-sm",
    r
  );
  return o ? /* @__PURE__ */ n.jsx(
    "a",
    {
      id: e,
      href: o,
      "data-sidebar": "menu-sub-button",
      "data-size": a,
      "data-active": t,
      className: c,
      "data-refast-id": u,
      children: d
    }
  ) : /* @__PURE__ */ n.jsx(
    "button",
    {
      id: e,
      "data-sidebar": "menu-sub-button",
      "data-size": a,
      "data-active": t,
      onClick: i,
      className: c,
      "data-refast-id": u,
      children: d
    }
  );
}
function oo({
  id: e,
  className: r,
  showIcon: t = !1,
  "data-refast-id": a
}) {
  const o = K.useMemo(() => `${Math.floor(Math.random() * 40) + 50}%`, []);
  return /* @__PURE__ */ n.jsxs(
    "div",
    {
      id: e,
      "data-sidebar": "menu-skeleton",
      className: g("rounded-md h-8 flex gap-2 px-2 items-center", r),
      "data-refast-id": a,
      children: [
        t && /* @__PURE__ */ n.jsx("div", { className: "size-4 rounded-md bg-sidebar-accent animate-pulse" }),
        /* @__PURE__ */ n.jsx(
          "div",
          {
            className: "h-4 flex-1 max-w-[--skeleton-width] rounded-md bg-sidebar-accent animate-pulse",
            style: { "--skeleton-width": o }
          }
        )
      ]
    }
  );
}
function io({
  id: e,
  className: r,
  "data-refast-id": t
}) {
  const a = K.useContext(me), o = a == null ? void 0 : a.toggleSidebar;
  return /* @__PURE__ */ n.jsx(
    "button",
    {
      id: e,
      "data-sidebar": "rail",
      "aria-label": "Toggle Sidebar",
      tabIndex: -1,
      onClick: o,
      title: "Toggle Sidebar",
      className: g(
        "absolute inset-y-0 z-20 hidden w-4 -translate-x-1/2 transition-all ease-linear after:absolute after:inset-y-0 after:left-1/2 after:w-[2px] hover:after:bg-sidebar-border group-data-[side=left]:-right-4 group-data-[side=right]:left-0 sm:flex",
        "[[data-side=left]_&]:cursor-w-resize [[data-side=right]_&]:cursor-e-resize",
        "[[data-side=left][data-state=collapsed]_&]:cursor-e-resize [[data-side=right][data-state=collapsed]_&]:cursor-w-resize",
        "group-data-[collapsible=offcanvas]:translate-x-0 group-data-[collapsible=offcanvas]:after:left-full group-data-[collapsible=offcanvas]:hover:bg-sidebar",
        "[[data-side=left][data-collapsible=offcanvas]_&]:-right-2",
        "[[data-side=right][data-collapsible=offcanvas]_&]:-left-2",
        r
      ),
      "data-refast-id": t
    }
  );
}
function so({
  id: e,
  className: r,
  onClick: t,
  "data-refast-id": a
}) {
  const o = K.useContext(me), i = () => {
    t ? t() : o != null && o.toggleSidebar && o.toggleSidebar();
  };
  return /* @__PURE__ */ n.jsxs(
    "button",
    {
      id: e,
      "data-sidebar": "trigger",
      onClick: i,
      className: g(
        "inline-flex h-7 w-7 items-center justify-center rounded-md text-sm font-medium",
        "ring-offset-background transition-colors hover:bg-accent hover:text-accent-foreground",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        r
      ),
      "data-refast-id": a,
      children: [
        /* @__PURE__ */ n.jsxs(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "size-4",
            children: [
              /* @__PURE__ */ n.jsx("rect", { width: "18", height: "18", x: "3", y: "3", rx: "2" }),
              /* @__PURE__ */ n.jsx("path", { d: "M9 3v18" })
            ]
          }
        ),
        /* @__PURE__ */ n.jsx("span", { className: "sr-only", children: "Toggle Sidebar" })
      ]
    }
  );
}
export {
  Za as Breadcrumb,
  on as BreadcrumbEllipsis,
  tn as BreadcrumbItem,
  rn as BreadcrumbLink,
  en as BreadcrumbList,
  an as BreadcrumbPage,
  nn as BreadcrumbSeparator,
  Tn as Command,
  Ln as CommandEmpty,
  Dn as CommandGroup,
  Pn as CommandInput,
  On as CommandItem,
  An as CommandList,
  Fn as CommandSeparator,
  Kn as CommandShortcut,
  wn as Menubar,
  Rn as MenubarCheckboxItem,
  yn as MenubarContent,
  Cn as MenubarItem,
  Mn as MenubarMenu,
  En as MenubarRadioGroup,
  kn as MenubarRadioItem,
  jn as MenubarSeparator,
  Sn as MenubarSub,
  _n as MenubarSubContent,
  In as MenubarSubTrigger,
  Nn as MenubarTrigger,
  sn as NavigationMenu,
  cn as NavigationMenuContent,
  un as NavigationMenuItem,
  fn as NavigationMenuLink,
  dn as NavigationMenuList,
  ln as NavigationMenuTrigger,
  mn as Pagination,
  pn as PaginationContent,
  hn as PaginationEllipsis,
  gn as PaginationItem,
  vn as PaginationLink,
  xn as PaginationNext,
  bn as PaginationPrevious,
  zn as Sidebar,
  Vn as SidebarContent,
  Wn as SidebarFooter,
  Hn as SidebarGroup,
  Yn as SidebarGroupAction,
  Xn as SidebarGroupContent,
  qn as SidebarGroupLabel,
  Gn as SidebarHeader,
  Bn as SidebarInset,
  Jn as SidebarMenu,
  eo as SidebarMenuAction,
  to as SidebarMenuBadge,
  Zn as SidebarMenuButton,
  Qn as SidebarMenuItem,
  oo as SidebarMenuSkeleton,
  ro as SidebarMenuSub,
  no as SidebarMenuSubButton,
  ao as SidebarMenuSubItem,
  $n as SidebarProvider,
  io as SidebarRail,
  Un as SidebarSeparator,
  so as SidebarTrigger
};
