import { f as Ne, p as ge, a as Re, n as De, h as ie, s as Z, o as he, z as Ve, b as Bt, c as xt, d as H, v as kt, e as ze, g as Pe } from "./refast-markdown-ByFT1VZb.js";
const Me = /[#.]/g;
function Ht(e, t) {
  const a = e || "", s = {};
  let c = 0, d, l;
  for (; c < a.length; ) {
    Me.lastIndex = c;
    const m = Me.exec(a), f = a.slice(c, m ? m.index : a.length);
    f && (d ? d === "#" ? s.id = f : Array.isArray(s.className) ? s.className.push(f) : s.className = [f] : l = f, c += f.length), m && (d = m[0], c++);
  }
  return {
    type: "element",
    // @ts-expect-error: tag name is parsed.
    tagName: l || t || "div",
    properties: s,
    children: []
  };
}
function je(e, t, a) {
  const s = a ? wt(a) : void 0;
  function c(d, l, ...m) {
    let f;
    if (d == null) {
      f = { type: "root", children: [] };
      const b = (
        /** @type {Child} */
        l
      );
      m.unshift(b);
    } else {
      f = Ht(d, t);
      const b = f.tagName.toLowerCase(), S = s ? s.get(b) : void 0;
      if (f.tagName = S || b, Ft(l))
        m.unshift(l);
      else
        for (const [U, Mt] of Object.entries(l))
          Ut(e, f.properties, U, Mt);
    }
    for (const b of m)
      fe(f.children, b);
    return f.type === "element" && f.tagName === "template" && (f.content = { type: "root", children: f.children }, f.children = []), f;
  }
  return c;
}
function Ft(e) {
  if (e === null || typeof e != "object" || Array.isArray(e))
    return !0;
  if (typeof e.type != "string") return !1;
  const t = (
    /** @type {Record<string, unknown>} */
    e
  ), a = Object.keys(e);
  for (const s of a) {
    const c = t[s];
    if (c && typeof c == "object") {
      if (!Array.isArray(c)) return !0;
      const d = (
        /** @type {ReadonlyArray<unknown>} */
        c
      );
      for (const l of d)
        if (typeof l != "number" && typeof l != "string")
          return !0;
    }
  }
  return !!("children" in e && Array.isArray(e.children));
}
function Ut(e, t, a, s) {
  const c = Ne(e, a);
  let d;
  if (s != null) {
    if (typeof s == "number") {
      if (Number.isNaN(s)) return;
      d = s;
    } else typeof s == "boolean" ? d = s : typeof s == "string" ? c.spaceSeparated ? d = ge(s) : c.commaSeparated ? d = Re(s) : c.commaOrSpaceSeparated ? d = ge(Re(s).join(" ")) : d = Be(c, c.property, s) : Array.isArray(s) ? d = [...s] : d = c.property === "style" ? yt(s) : String(s);
    if (Array.isArray(d)) {
      const l = [];
      for (const m of d)
        l.push(
          /** @type {number | string} */
          Be(c, c.property, m)
        );
      d = l;
    }
    c.property === "className" && Array.isArray(t.className) && (d = t.className.concat(
      /** @type {Array<number | string> | number | string} */
      d
    )), t[c.property] = d;
  }
}
function fe(e, t) {
  if (t != null) if (typeof t == "number" || typeof t == "string")
    e.push({ type: "text", value: String(t) });
  else if (Array.isArray(t))
    for (const a of t)
      fe(e, a);
  else if (typeof t == "object" && "type" in t)
    t.type === "root" ? fe(e, t.children) : e.push(t);
  else
    throw new Error("Expected node, nodes, or string, got `" + t + "`");
}
function Be(e, t, a) {
  if (typeof a == "string") {
    if (e.number && a && !Number.isNaN(Number(a)))
      return Number(a);
    if ((e.boolean || e.overloadedBoolean) && (a === "" || De(a) === De(t)))
      return !0;
  }
  return a;
}
function yt(e) {
  const t = [];
  for (const [a, s] of Object.entries(e))
    t.push([a, s].join(": "));
  return t.join("; ");
}
function wt(e) {
  const t = /* @__PURE__ */ new Map();
  for (const a of e)
    t.set(a.toLowerCase(), a);
  return t;
}
const Yt = [
  "altGlyph",
  "altGlyphDef",
  "altGlyphItem",
  "animateColor",
  "animateMotion",
  "animateTransform",
  "clipPath",
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feDropShadow",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence",
  "foreignObject",
  "glyphRef",
  "linearGradient",
  "radialGradient",
  "solidColor",
  "textArea",
  "textPath"
], vt = je(ie, "div"), Qt = je(Z, "g", Yt);
function Gt(e) {
  const t = String(e), a = [];
  return { toOffset: c, toPoint: s };
  function s(d) {
    if (typeof d == "number" && d > -1 && d <= t.length) {
      let l = 0;
      for (; ; ) {
        let m = a[l];
        if (m === void 0) {
          const f = xe(t, a[l - 1]);
          m = f === -1 ? t.length + 1 : f + 1, a[l] = m;
        }
        if (m > d)
          return {
            line: l + 1,
            column: d - (l > 0 ? a[l - 1] : 0) + 1,
            offset: d
          };
        l++;
      }
    }
  }
  function c(d) {
    if (d && typeof d.line == "number" && typeof d.column == "number" && !Number.isNaN(d.line) && !Number.isNaN(d.column)) {
      for (; a.length < d.line; ) {
        const m = a[a.length - 1], f = xe(t, m), b = f === -1 ? t.length + 1 : f + 1;
        if (m === b) break;
        a.push(b);
      }
      const l = (d.line > 1 ? a[d.line - 2] : 0) + d.column - 1;
      if (l < a[d.line - 1]) return l;
    }
  }
}
function xe(e, t) {
  const a = e.indexOf("\r", t), s = e.indexOf(`
`, t);
  return s === -1 ? a : a === -1 || a + 1 === s ? s : a < s ? a : s;
}
const x = {
  html: "http://www.w3.org/1999/xhtml",
  mathml: "http://www.w3.org/1998/Math/MathML",
  svg: "http://www.w3.org/2000/svg",
  xlink: "http://www.w3.org/1999/xlink",
  xml: "http://www.w3.org/XML/1998/namespace",
  xmlns: "http://www.w3.org/2000/xmlns/"
}, Je = {}.hasOwnProperty, Wt = Object.prototype;
function qt(e, t) {
  const a = t || {};
  return Ie(
    {
      file: a.file || void 0,
      location: !1,
      schema: a.space === "svg" ? Z : ie,
      verbose: a.verbose || !1
    },
    e
  );
}
function Ie(e, t) {
  let a;
  switch (t.nodeName) {
    case "#comment": {
      const s = (
        /** @type {DefaultTreeAdapterMap['commentNode']} */
        t
      );
      return a = { type: "comment", value: s.data }, ue(e, s, a), a;
    }
    case "#document":
    case "#document-fragment": {
      const s = (
        /** @type {DefaultTreeAdapterMap['document'] | DefaultTreeAdapterMap['documentFragment']} */
        t
      ), c = "mode" in s ? s.mode === "quirks" || s.mode === "limited-quirks" : !1;
      if (a = {
        type: "root",
        children: Ze(e, t.childNodes),
        data: { quirksMode: c }
      }, e.file && e.location) {
        const d = String(e.file), l = Gt(d), m = l.toPoint(0), f = l.toPoint(d.length);
        a.position = { start: m, end: f };
      }
      return a;
    }
    case "#documentType": {
      const s = (
        /** @type {DefaultTreeAdapterMap['documentType']} */
        t
      );
      return a = { type: "doctype" }, ue(e, s, a), a;
    }
    case "#text": {
      const s = (
        /** @type {DefaultTreeAdapterMap['textNode']} */
        t
      );
      return a = { type: "text", value: s.value }, ue(e, s, a), a;
    }
    default:
      return a = Xt(
        e,
        /** @type {DefaultTreeAdapterMap['element']} */
        t
      ), a;
  }
}
function Ze(e, t) {
  let a = -1;
  const s = [];
  for (; ++a < t.length; ) {
    const c = (
      /** @type {RootContent} */
      Ie(e, t[a])
    );
    s.push(c);
  }
  return s;
}
function Xt(e, t) {
  const a = e.schema;
  e.schema = t.namespaceURI === x.svg ? Z : ie;
  let s = -1;
  const c = {};
  for (; ++s < t.attrs.length; ) {
    const m = t.attrs[s], f = (m.prefix ? m.prefix + ":" : "") + m.name;
    Je.call(Wt, f) || (c[f] = m.value);
  }
  const l = (e.schema.space === "svg" ? Qt : vt)(t.tagName, c, Ze(e, t.childNodes));
  if (ue(e, t, l), l.tagName === "template") {
    const m = (
      /** @type {DefaultTreeAdapterMap['template']} */
      t
    ), f = m.sourceCodeLocation, b = f && f.startTag && y(f.startTag), S = f && f.endTag && y(f.endTag), U = (
      /** @type {Root} */
      Ie(e, m.content)
    );
    b && S && e.file && (U.position = { start: b.end, end: S.start }), l.content = U;
  }
  return e.schema = a, l;
}
function ue(e, t, a) {
  if ("sourceCodeLocation" in t && t.sourceCodeLocation && e.file) {
    const s = Kt(e, a, t.sourceCodeLocation);
    s && (e.location = !0, a.position = s);
  }
}
function Kt(e, t, a) {
  const s = y(a);
  if (t.type === "element") {
    const c = t.children[t.children.length - 1];
    if (s && !a.endTag && c && c.position && c.position.end && (s.end = Object.assign({}, c.position.end)), e.verbose) {
      const d = {};
      let l;
      if (a.attrs)
        for (l in a.attrs)
          Je.call(a.attrs, l) && (d[Ne(e.schema, l).property] = y(
            a.attrs[l]
          ));
      he(a.startTag);
      const m = y(a.startTag), f = a.endTag ? y(a.endTag) : void 0, b = { opening: m };
      f && (b.closing = f), b.properties = d, t.data = { position: b };
    }
  }
  return s;
}
function y(e) {
  const t = ke({
    line: e.startLine,
    column: e.startCol,
    offset: e.startOffset
  }), a = ke({
    line: e.endLine,
    column: e.endCol,
    offset: e.endOffset
  });
  return t || a ? { start: t, end: a } : void 0;
}
function ke(e) {
  return e.line && e.column ? e : void 0;
}
const Vt = {}, zt = {}.hasOwnProperty, $e = Ve("type", { handlers: { root: Jt, element: uu, text: eu, comment: tu, doctype: $t } });
function jt(e, t) {
  const s = (t || Vt).space;
  return $e(e, s === "svg" ? Z : ie);
}
function Jt(e, t) {
  const a = {
    nodeName: "#document",
    // @ts-expect-error: `parse5` uses enums, which are actually strings.
    mode: (e.data || {}).quirksMode ? "quirks" : "no-quirks",
    childNodes: []
  };
  return a.childNodes = Ce(e.children, a, t), Y(e, a), a;
}
function Zt(e, t) {
  const a = { nodeName: "#document-fragment", childNodes: [] };
  return a.childNodes = Ce(e.children, a, t), Y(e, a), a;
}
function $t(e) {
  const t = {
    nodeName: "#documentType",
    name: "html",
    publicId: "",
    systemId: "",
    parentNode: null
  };
  return Y(e, t), t;
}
function eu(e) {
  const t = {
    nodeName: "#text",
    value: e.value,
    parentNode: null
  };
  return Y(e, t), t;
}
function tu(e) {
  const t = {
    nodeName: "#comment",
    data: e.value,
    parentNode: null
  };
  return Y(e, t), t;
}
function uu(e, t) {
  const a = t;
  let s = a;
  e.type === "element" && e.tagName.toLowerCase() === "svg" && a.space === "html" && (s = Z);
  const c = [];
  let d;
  if (e.properties) {
    for (d in e.properties)
      if (d !== "children" && zt.call(e.properties, d)) {
        const f = au(
          s,
          d,
          e.properties[d]
        );
        f && c.push(f);
      }
  }
  const l = s.space, m = {
    nodeName: e.tagName,
    tagName: e.tagName,
    attrs: c,
    // @ts-expect-error: `parse5` types are wrong.
    namespaceURI: x[l],
    childNodes: [],
    parentNode: null
  };
  return m.childNodes = Ce(e.children, m, s), Y(e, m), e.tagName === "template" && e.content && (m.content = Zt(e.content, s)), m;
}
function au(e, t, a) {
  const s = Ne(e, t);
  if (a === !1 || a === null || a === void 0 || typeof a == "number" && Number.isNaN(a) || !a && s.boolean)
    return;
  Array.isArray(a) && (a = s.commaSeparated ? Bt(a) : xt(a));
  const c = {
    name: s.attribute,
    value: a === !0 ? "" : String(a)
  };
  if (s.space && s.space !== "html" && s.space !== "svg") {
    const d = c.name.indexOf(":");
    d < 0 ? c.prefix = "" : (c.name = c.name.slice(d + 1), c.prefix = s.attribute.slice(0, d)), c.namespace = x[s.space];
  }
  return c;
}
function Ce(e, t, a) {
  let s = -1;
  const c = [];
  if (e)
    for (; ++s < e.length; ) {
      const d = $e(e[s], a);
      d.parentNode = t, c.push(d);
    }
  return c;
}
function Y(e, t) {
  const a = e.position;
  a && a.start && a.end && (he(typeof a.start.offset == "number"), he(typeof a.end.offset == "number"), t.sourceCodeLocation = {
    startLine: a.start.line,
    startCol: a.start.column,
    startOffset: a.start.offset,
    endLine: a.end.line,
    endCol: a.end.column,
    endOffset: a.end.offset
  });
}
const su = [
  "area",
  "base",
  "basefont",
  "bgsound",
  "br",
  "col",
  "command",
  "embed",
  "frame",
  "hr",
  "image",
  "img",
  "input",
  "keygen",
  "link",
  "meta",
  "param",
  "source",
  "track",
  "wbr"
], ru = /* @__PURE__ */ new Set([
  65534,
  65535,
  131070,
  131071,
  196606,
  196607,
  262142,
  262143,
  327678,
  327679,
  393214,
  393215,
  458750,
  458751,
  524286,
  524287,
  589822,
  589823,
  655358,
  655359,
  720894,
  720895,
  786430,
  786431,
  851966,
  851967,
  917502,
  917503,
  983038,
  983039,
  1048574,
  1048575,
  1114110,
  1114111
]), A = "�";
var r;
(function(e) {
  e[e.EOF = -1] = "EOF", e[e.NULL = 0] = "NULL", e[e.TABULATION = 9] = "TABULATION", e[e.CARRIAGE_RETURN = 13] = "CARRIAGE_RETURN", e[e.LINE_FEED = 10] = "LINE_FEED", e[e.FORM_FEED = 12] = "FORM_FEED", e[e.SPACE = 32] = "SPACE", e[e.EXCLAMATION_MARK = 33] = "EXCLAMATION_MARK", e[e.QUOTATION_MARK = 34] = "QUOTATION_MARK", e[e.AMPERSAND = 38] = "AMPERSAND", e[e.APOSTROPHE = 39] = "APOSTROPHE", e[e.HYPHEN_MINUS = 45] = "HYPHEN_MINUS", e[e.SOLIDUS = 47] = "SOLIDUS", e[e.DIGIT_0 = 48] = "DIGIT_0", e[e.DIGIT_9 = 57] = "DIGIT_9", e[e.SEMICOLON = 59] = "SEMICOLON", e[e.LESS_THAN_SIGN = 60] = "LESS_THAN_SIGN", e[e.EQUALS_SIGN = 61] = "EQUALS_SIGN", e[e.GREATER_THAN_SIGN = 62] = "GREATER_THAN_SIGN", e[e.QUESTION_MARK = 63] = "QUESTION_MARK", e[e.LATIN_CAPITAL_A = 65] = "LATIN_CAPITAL_A", e[e.LATIN_CAPITAL_Z = 90] = "LATIN_CAPITAL_Z", e[e.RIGHT_SQUARE_BRACKET = 93] = "RIGHT_SQUARE_BRACKET", e[e.GRAVE_ACCENT = 96] = "GRAVE_ACCENT", e[e.LATIN_SMALL_A = 97] = "LATIN_SMALL_A", e[e.LATIN_SMALL_Z = 122] = "LATIN_SMALL_Z";
})(r || (r = {}));
const O = {
  DASH_DASH: "--",
  CDATA_START: "[CDATA[",
  DOCTYPE: "doctype",
  SCRIPT: "script",
  PUBLIC: "public",
  SYSTEM: "system"
};
function et(e) {
  return e >= 55296 && e <= 57343;
}
function nu(e) {
  return e >= 56320 && e <= 57343;
}
function iu(e, t) {
  return (e - 55296) * 1024 + 9216 + t;
}
function tt(e) {
  return e !== 32 && e !== 10 && e !== 13 && e !== 9 && e !== 12 && e >= 1 && e <= 31 || e >= 127 && e <= 159;
}
function ut(e) {
  return e >= 64976 && e <= 65007 || ru.has(e);
}
var E;
(function(e) {
  e.controlCharacterInInputStream = "control-character-in-input-stream", e.noncharacterInInputStream = "noncharacter-in-input-stream", e.surrogateInInputStream = "surrogate-in-input-stream", e.nonVoidHtmlElementStartTagWithTrailingSolidus = "non-void-html-element-start-tag-with-trailing-solidus", e.endTagWithAttributes = "end-tag-with-attributes", e.endTagWithTrailingSolidus = "end-tag-with-trailing-solidus", e.unexpectedSolidusInTag = "unexpected-solidus-in-tag", e.unexpectedNullCharacter = "unexpected-null-character", e.unexpectedQuestionMarkInsteadOfTagName = "unexpected-question-mark-instead-of-tag-name", e.invalidFirstCharacterOfTagName = "invalid-first-character-of-tag-name", e.unexpectedEqualsSignBeforeAttributeName = "unexpected-equals-sign-before-attribute-name", e.missingEndTagName = "missing-end-tag-name", e.unexpectedCharacterInAttributeName = "unexpected-character-in-attribute-name", e.unknownNamedCharacterReference = "unknown-named-character-reference", e.missingSemicolonAfterCharacterReference = "missing-semicolon-after-character-reference", e.unexpectedCharacterAfterDoctypeSystemIdentifier = "unexpected-character-after-doctype-system-identifier", e.unexpectedCharacterInUnquotedAttributeValue = "unexpected-character-in-unquoted-attribute-value", e.eofBeforeTagName = "eof-before-tag-name", e.eofInTag = "eof-in-tag", e.missingAttributeValue = "missing-attribute-value", e.missingWhitespaceBetweenAttributes = "missing-whitespace-between-attributes", e.missingWhitespaceAfterDoctypePublicKeyword = "missing-whitespace-after-doctype-public-keyword", e.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers = "missing-whitespace-between-doctype-public-and-system-identifiers", e.missingWhitespaceAfterDoctypeSystemKeyword = "missing-whitespace-after-doctype-system-keyword", e.missingQuoteBeforeDoctypePublicIdentifier = "missing-quote-before-doctype-public-identifier", e.missingQuoteBeforeDoctypeSystemIdentifier = "missing-quote-before-doctype-system-identifier", e.missingDoctypePublicIdentifier = "missing-doctype-public-identifier", e.missingDoctypeSystemIdentifier = "missing-doctype-system-identifier", e.abruptDoctypePublicIdentifier = "abrupt-doctype-public-identifier", e.abruptDoctypeSystemIdentifier = "abrupt-doctype-system-identifier", e.cdataInHtmlContent = "cdata-in-html-content", e.incorrectlyOpenedComment = "incorrectly-opened-comment", e.eofInScriptHtmlCommentLikeText = "eof-in-script-html-comment-like-text", e.eofInDoctype = "eof-in-doctype", e.nestedComment = "nested-comment", e.abruptClosingOfEmptyComment = "abrupt-closing-of-empty-comment", e.eofInComment = "eof-in-comment", e.incorrectlyClosedComment = "incorrectly-closed-comment", e.eofInCdata = "eof-in-cdata", e.absenceOfDigitsInNumericCharacterReference = "absence-of-digits-in-numeric-character-reference", e.nullCharacterReference = "null-character-reference", e.surrogateCharacterReference = "surrogate-character-reference", e.characterReferenceOutsideUnicodeRange = "character-reference-outside-unicode-range", e.controlCharacterReference = "control-character-reference", e.noncharacterCharacterReference = "noncharacter-character-reference", e.missingWhitespaceBeforeDoctypeName = "missing-whitespace-before-doctype-name", e.missingDoctypeName = "missing-doctype-name", e.invalidCharacterSequenceAfterDoctypeName = "invalid-character-sequence-after-doctype-name", e.duplicateAttribute = "duplicate-attribute", e.nonConformingDoctype = "non-conforming-doctype", e.missingDoctype = "missing-doctype", e.misplacedDoctype = "misplaced-doctype", e.endTagWithoutMatchingOpenElement = "end-tag-without-matching-open-element", e.closingOfElementWithOpenChildElements = "closing-of-element-with-open-child-elements", e.disallowedContentInNoscriptInHead = "disallowed-content-in-noscript-in-head", e.openElementsLeftAfterEof = "open-elements-left-after-eof", e.abandonedHeadElementChild = "abandoned-head-element-child", e.misplacedStartTagForHeadElement = "misplaced-start-tag-for-head-element", e.nestedNoscriptInHead = "nested-noscript-in-head", e.eofInElementThatCanContainOnlyText = "eof-in-element-that-can-contain-only-text";
})(E || (E = {}));
const cu = 65536;
class ou {
  constructor(t) {
    this.handler = t, this.html = "", this.pos = -1, this.lastGapPos = -2, this.gapStack = [], this.skipNextNewLine = !1, this.lastChunkWritten = !1, this.endOfChunkHit = !1, this.bufferWaterline = cu, this.isEol = !1, this.lineStartPos = 0, this.droppedBufferSize = 0, this.line = 1, this.lastErrOffset = -1;
  }
  /** The column on the current line. If we just saw a gap (eg. a surrogate pair), return the index before. */
  get col() {
    return this.pos - this.lineStartPos + +(this.lastGapPos !== this.pos);
  }
  get offset() {
    return this.droppedBufferSize + this.pos;
  }
  getError(t, a) {
    const { line: s, col: c, offset: d } = this, l = c + a, m = d + a;
    return {
      code: t,
      startLine: s,
      endLine: s,
      startCol: l,
      endCol: l,
      startOffset: m,
      endOffset: m
    };
  }
  _err(t) {
    this.handler.onParseError && this.lastErrOffset !== this.offset && (this.lastErrOffset = this.offset, this.handler.onParseError(this.getError(t, 0)));
  }
  _addGap() {
    this.gapStack.push(this.lastGapPos), this.lastGapPos = this.pos;
  }
  _processSurrogate(t) {
    if (this.pos !== this.html.length - 1) {
      const a = this.html.charCodeAt(this.pos + 1);
      if (nu(a))
        return this.pos++, this._addGap(), iu(t, a);
    } else if (!this.lastChunkWritten)
      return this.endOfChunkHit = !0, r.EOF;
    return this._err(E.surrogateInInputStream), t;
  }
  willDropParsedChunk() {
    return this.pos > this.bufferWaterline;
  }
  dropParsedChunk() {
    this.willDropParsedChunk() && (this.html = this.html.substring(this.pos), this.lineStartPos -= this.pos, this.droppedBufferSize += this.pos, this.pos = 0, this.lastGapPos = -2, this.gapStack.length = 0);
  }
  write(t, a) {
    this.html.length > 0 ? this.html += t : this.html = t, this.endOfChunkHit = !1, this.lastChunkWritten = a;
  }
  insertHtmlAtCurrentPos(t) {
    this.html = this.html.substring(0, this.pos + 1) + t + this.html.substring(this.pos + 1), this.endOfChunkHit = !1;
  }
  startsWith(t, a) {
    if (this.pos + t.length > this.html.length)
      return this.endOfChunkHit = !this.lastChunkWritten, !1;
    if (a)
      return this.html.startsWith(t, this.pos);
    for (let s = 0; s < t.length; s++)
      if ((this.html.charCodeAt(this.pos + s) | 32) !== t.charCodeAt(s))
        return !1;
    return !0;
  }
  peek(t) {
    const a = this.pos + t;
    if (a >= this.html.length)
      return this.endOfChunkHit = !this.lastChunkWritten, r.EOF;
    const s = this.html.charCodeAt(a);
    return s === r.CARRIAGE_RETURN ? r.LINE_FEED : s;
  }
  advance() {
    if (this.pos++, this.isEol && (this.isEol = !1, this.line++, this.lineStartPos = this.pos), this.pos >= this.html.length)
      return this.endOfChunkHit = !this.lastChunkWritten, r.EOF;
    let t = this.html.charCodeAt(this.pos);
    return t === r.CARRIAGE_RETURN ? (this.isEol = !0, this.skipNextNewLine = !0, r.LINE_FEED) : t === r.LINE_FEED && (this.isEol = !0, this.skipNextNewLine) ? (this.line--, this.skipNextNewLine = !1, this._addGap(), this.advance()) : (this.skipNextNewLine = !1, et(t) && (t = this._processSurrogate(t)), this.handler.onParseError === null || t > 31 && t < 127 || t === r.LINE_FEED || t === r.CARRIAGE_RETURN || t > 159 && t < 64976 || this._checkForProblematicCharacters(t), t);
  }
  _checkForProblematicCharacters(t) {
    tt(t) ? this._err(E.controlCharacterInInputStream) : ut(t) && this._err(E.noncharacterInInputStream);
  }
  retreat(t) {
    for (this.pos -= t; this.pos < this.lastGapPos; )
      this.lastGapPos = this.gapStack.pop(), this.pos--;
    this.isEol = !1;
  }
}
var _;
(function(e) {
  e[e.CHARACTER = 0] = "CHARACTER", e[e.NULL_CHARACTER = 1] = "NULL_CHARACTER", e[e.WHITESPACE_CHARACTER = 2] = "WHITESPACE_CHARACTER", e[e.START_TAG = 3] = "START_TAG", e[e.END_TAG = 4] = "END_TAG", e[e.COMMENT = 5] = "COMMENT", e[e.DOCTYPE = 6] = "DOCTYPE", e[e.EOF = 7] = "EOF", e[e.HIBERNATION = 8] = "HIBERNATION";
})(_ || (_ = {}));
function at(e, t) {
  for (let a = e.attrs.length - 1; a >= 0; a--)
    if (e.attrs[a].name === t)
      return e.attrs[a].value;
  return null;
}
const du = /* @__PURE__ */ new Uint16Array(
  // prettier-ignore
  /* @__PURE__ */ 'ᵁ<Õıʊҝջאٵ۞ޢߖࠏ੊ઑඡ๭༉༦჊ረዡᐕᒝᓃᓟᔥ\0\0\0\0\0\0ᕫᛍᦍᰒᷝ὾⁠↰⊍⏀⏻⑂⠤⤒ⴈ⹈⿎〖㊺㘹㞬㣾㨨㩱㫠㬮ࠀEMabcfglmnoprstu\\bfms¦³¹ÈÏlig耻Æ䃆P耻&䀦cute耻Á䃁reve;䄂Āiyx}rc耻Â䃂;䐐r;쀀𝔄rave耻À䃀pha;䎑acr;䄀d;橓Āgp¡on;䄄f;쀀𝔸plyFunction;恡ing耻Å䃅Ācs¾Ãr;쀀𝒜ign;扔ilde耻Ã䃃ml耻Ä䃄ЀaceforsuåûþėĜĢħĪĀcrêòkslash;或Ŷöø;櫧ed;挆y;䐑ƀcrtąċĔause;戵noullis;愬a;䎒r;쀀𝔅pf;쀀𝔹eve;䋘còēmpeq;扎܀HOacdefhilorsuōőŖƀƞƢƵƷƺǜȕɳɸɾcy;䐧PY耻©䂩ƀcpyŝŢźute;䄆Ā;iŧŨ拒talDifferentialD;慅leys;愭ȀaeioƉƎƔƘron;䄌dil耻Ç䃇rc;䄈nint;戰ot;䄊ĀdnƧƭilla;䂸terDot;䂷òſi;䎧rcleȀDMPTǇǋǑǖot;抙inus;抖lus;投imes;抗oĀcsǢǸkwiseContourIntegral;戲eCurlyĀDQȃȏoubleQuote;思uote;怙ȀlnpuȞȨɇɕonĀ;eȥȦ户;橴ƀgitȯȶȺruent;扡nt;戯ourIntegral;戮ĀfrɌɎ;愂oduct;成nterClockwiseContourIntegral;戳oss;樯cr;쀀𝒞pĀ;Cʄʅ拓ap;才րDJSZacefiosʠʬʰʴʸˋ˗ˡ˦̳ҍĀ;oŹʥtrahd;椑cy;䐂cy;䐅cy;䐏ƀgrsʿ˄ˇger;怡r;憡hv;櫤Āayː˕ron;䄎;䐔lĀ;t˝˞戇a;䎔r;쀀𝔇Āaf˫̧Ācm˰̢riticalȀADGT̖̜̀̆cute;䂴oŴ̋̍;䋙bleAcute;䋝rave;䁠ilde;䋜ond;拄ferentialD;慆Ѱ̽\0\0\0͔͂\0Ѕf;쀀𝔻ƀ;DE͈͉͍䂨ot;惜qual;扐blèCDLRUVͣͲ΂ϏϢϸontourIntegraìȹoɴ͹\0\0ͻ»͉nArrow;懓Āeo·ΤftƀARTΐΖΡrrow;懐ightArrow;懔eåˊngĀLRΫτeftĀARγιrrow;柸ightArrow;柺ightArrow;柹ightĀATϘϞrrow;懒ee;抨pɁϩ\0\0ϯrrow;懑ownArrow;懕erticalBar;戥ǹABLRTaВЪаўѿͼrrowƀ;BUНОТ憓ar;椓pArrow;懵reve;䌑eft˒к\0ц\0ѐightVector;楐eeVector;楞ectorĀ;Bљњ憽ar;楖ightǔѧ\0ѱeeVector;楟ectorĀ;BѺѻ懁ar;楗eeĀ;A҆҇护rrow;憧ĀctҒҗr;쀀𝒟rok;䄐ࠀNTacdfglmopqstuxҽӀӄӋӞӢӧӮӵԡԯԶՒ՝ՠեG;䅊H耻Ð䃐cute耻É䃉ƀaiyӒӗӜron;䄚rc耻Ê䃊;䐭ot;䄖r;쀀𝔈rave耻È䃈ement;戈ĀapӺӾcr;䄒tyɓԆ\0\0ԒmallSquare;旻erySmallSquare;斫ĀgpԦԪon;䄘f;쀀𝔼silon;䎕uĀaiԼՉlĀ;TՂՃ橵ilde;扂librium;懌Āci՗՚r;愰m;橳a;䎗ml耻Ë䃋Āipժկsts;戃onentialE;慇ʀcfiosօֈ֍ֲ׌y;䐤r;쀀𝔉lledɓ֗\0\0֣mallSquare;旼erySmallSquare;斪Ͱֺ\0ֿ\0\0ׄf;쀀𝔽All;戀riertrf;愱cò׋؀JTabcdfgorstר׬ׯ׺؀ؒؖ؛؝أ٬ٲcy;䐃耻>䀾mmaĀ;d׷׸䎓;䏜reve;䄞ƀeiy؇،ؐdil;䄢rc;䄜;䐓ot;䄠r;쀀𝔊;拙pf;쀀𝔾eater̀EFGLSTصلَٖٛ٦qualĀ;Lؾؿ扥ess;招ullEqual;执reater;檢ess;扷lantEqual;橾ilde;扳cr;쀀𝒢;扫ЀAacfiosuڅڋږڛڞڪھۊRDcy;䐪Āctڐڔek;䋇;䁞irc;䄤r;愌lbertSpace;愋ǰگ\0ڲf;愍izontalLine;攀Āctۃۅòکrok;䄦mpńېۘownHumðįqual;扏܀EJOacdfgmnostuۺ۾܃܇܎ܚܞܡܨ݄ݸދޏޕcy;䐕lig;䄲cy;䐁cute耻Í䃍Āiyܓܘrc耻Î䃎;䐘ot;䄰r;愑rave耻Ì䃌ƀ;apܠܯܿĀcgܴܷr;䄪inaryI;慈lieóϝǴ݉\0ݢĀ;eݍݎ戬Āgrݓݘral;戫section;拂isibleĀCTݬݲomma;恣imes;恢ƀgptݿރވon;䄮f;쀀𝕀a;䎙cr;愐ilde;䄨ǫޚ\0ޞcy;䐆l耻Ï䃏ʀcfosuެ޷޼߂ߐĀiyޱ޵rc;䄴;䐙r;쀀𝔍pf;쀀𝕁ǣ߇\0ߌr;쀀𝒥rcy;䐈kcy;䐄΀HJacfosߤߨ߽߬߱ࠂࠈcy;䐥cy;䐌ppa;䎚Āey߶߻dil;䄶;䐚r;쀀𝔎pf;쀀𝕂cr;쀀𝒦րJTaceflmostࠥࠩࠬࡐࡣ঳সে্਷ੇcy;䐉耻<䀼ʀcmnpr࠷࠼ࡁࡄࡍute;䄹bda;䎛g;柪lacetrf;愒r;憞ƀaeyࡗ࡜ࡡron;䄽dil;䄻;䐛Āfsࡨ॰tԀACDFRTUVarࡾࢩࢱࣦ࣠ࣼयज़ΐ४Ānrࢃ࢏gleBracket;柨rowƀ;BR࢙࢚࢞憐ar;懤ightArrow;懆eiling;挈oǵࢷ\0ࣃbleBracket;柦nǔࣈ\0࣒eeVector;楡ectorĀ;Bࣛࣜ懃ar;楙loor;挊ightĀAV࣯ࣵrrow;憔ector;楎Āerँगeƀ;AVउऊऐ抣rrow;憤ector;楚iangleƀ;BEतथऩ抲ar;槏qual;抴pƀDTVषूौownVector;楑eeVector;楠ectorĀ;Bॖॗ憿ar;楘ectorĀ;B॥०憼ar;楒ightáΜs̀EFGLSTॾঋকঝঢভqualGreater;拚ullEqual;扦reater;扶ess;檡lantEqual;橽ilde;扲r;쀀𝔏Ā;eঽা拘ftarrow;懚idot;䄿ƀnpw৔ਖਛgȀLRlr৞৷ਂਐeftĀAR০৬rrow;柵ightArrow;柷ightArrow;柶eftĀarγਊightáοightáϊf;쀀𝕃erĀLRਢਬeftArrow;憙ightArrow;憘ƀchtਾੀੂòࡌ;憰rok;䅁;扪Ѐacefiosuਗ਼੝੠੷੼અઋ઎p;椅y;䐜Ādl੥੯iumSpace;恟lintrf;愳r;쀀𝔐nusPlus;戓pf;쀀𝕄cò੶;䎜ҀJacefostuણધભીଔଙඑ඗ඞcy;䐊cute;䅃ƀaey઴હાron;䅇dil;䅅;䐝ƀgswે૰଎ativeƀMTV૓૟૨ediumSpace;怋hiĀcn૦૘ë૙eryThiî૙tedĀGL૸ଆreaterGreateòٳessLesóੈLine;䀊r;쀀𝔑ȀBnptଢନଷ଺reak;恠BreakingSpace;䂠f;愕ڀ;CDEGHLNPRSTV୕ୖ୪୼஡௫ఄ౞಄ದ೘ൡඅ櫬Āou୛୤ngruent;扢pCap;扭oubleVerticalBar;戦ƀlqxஃஊ஛ement;戉ualĀ;Tஒஓ扠ilde;쀀≂̸ists;戄reater΀;EFGLSTஶஷ஽௉௓௘௥扯qual;扱ullEqual;쀀≧̸reater;쀀≫̸ess;批lantEqual;쀀⩾̸ilde;扵umpń௲௽ownHump;쀀≎̸qual;쀀≏̸eĀfsఊధtTriangleƀ;BEచఛడ拪ar;쀀⧏̸qual;括s̀;EGLSTవశ఼ౄోౘ扮qual;扰reater;扸ess;쀀≪̸lantEqual;쀀⩽̸ilde;扴estedĀGL౨౹reaterGreater;쀀⪢̸essLess;쀀⪡̸recedesƀ;ESಒಓಛ技qual;쀀⪯̸lantEqual;拠ĀeiಫಹverseElement;戌ghtTriangleƀ;BEೋೌ೒拫ar;쀀⧐̸qual;拭ĀquೝഌuareSuĀbp೨೹setĀ;E೰ೳ쀀⊏̸qual;拢ersetĀ;Eഃആ쀀⊐̸qual;拣ƀbcpഓതൎsetĀ;Eഛഞ쀀⊂⃒qual;抈ceedsȀ;ESTലള഻െ抁qual;쀀⪰̸lantEqual;拡ilde;쀀≿̸ersetĀ;E൘൛쀀⊃⃒qual;抉ildeȀ;EFT൮൯൵ൿ扁qual;扄ullEqual;扇ilde;扉erticalBar;戤cr;쀀𝒩ilde耻Ñ䃑;䎝܀Eacdfgmoprstuvලෂ෉෕ෛ෠෧෼ขภยา฿ไlig;䅒cute耻Ó䃓Āiy෎ීrc耻Ô䃔;䐞blac;䅐r;쀀𝔒rave耻Ò䃒ƀaei෮ෲ෶cr;䅌ga;䎩cron;䎟pf;쀀𝕆enCurlyĀDQฎบoubleQuote;怜uote;怘;橔Āclวฬr;쀀𝒪ash耻Ø䃘iŬื฼de耻Õ䃕es;樷ml耻Ö䃖erĀBP๋๠Āar๐๓r;怾acĀek๚๜;揞et;掴arenthesis;揜Ҁacfhilors๿ງຊຏຒດຝະ໼rtialD;戂y;䐟r;쀀𝔓i;䎦;䎠usMinus;䂱Āipຢອncareplanåڝf;愙Ȁ;eio຺ູ໠໤檻cedesȀ;EST່້໏໚扺qual;檯lantEqual;扼ilde;找me;怳Ādp໩໮uct;戏ortionĀ;aȥ໹l;戝Āci༁༆r;쀀𝒫;䎨ȀUfos༑༖༛༟OT耻"䀢r;쀀𝔔pf;愚cr;쀀𝒬؀BEacefhiorsu༾གྷཇའཱིྦྷྪྭ႖ႩႴႾarr;椐G耻®䂮ƀcnrཎནབute;䅔g;柫rĀ;tཛྷཝ憠l;椖ƀaeyཧཬཱron;䅘dil;䅖;䐠Ā;vླྀཹ愜erseĀEUྂྙĀlq྇ྎement;戋uilibrium;懋pEquilibrium;楯r»ཹo;䎡ghtЀACDFTUVa࿁࿫࿳ဢဨၛႇϘĀnr࿆࿒gleBracket;柩rowƀ;BL࿜࿝࿡憒ar;懥eftArrow;懄eiling;按oǵ࿹\0စbleBracket;柧nǔည\0နeeVector;楝ectorĀ;Bဝသ懂ar;楕loor;挋Āerိ၃eƀ;AVဵံြ抢rrow;憦ector;楛iangleƀ;BEၐၑၕ抳ar;槐qual;抵pƀDTVၣၮၸownVector;楏eeVector;楜ectorĀ;Bႂႃ憾ar;楔ectorĀ;B႑႒懀ar;楓Āpuႛ႞f;愝ndImplies;楰ightarrow;懛ĀchႹႼr;愛;憱leDelayed;槴ڀHOacfhimoqstuფჱჷჽᄙᄞᅑᅖᅡᅧᆵᆻᆿĀCcჩხHcy;䐩y;䐨FTcy;䐬cute;䅚ʀ;aeiyᄈᄉᄎᄓᄗ檼ron;䅠dil;䅞rc;䅜;䐡r;쀀𝔖ortȀDLRUᄪᄴᄾᅉownArrow»ОeftArrow»࢚ightArrow»࿝pArrow;憑gma;䎣allCircle;战pf;쀀𝕊ɲᅭ\0\0ᅰt;戚areȀ;ISUᅻᅼᆉᆯ斡ntersection;抓uĀbpᆏᆞsetĀ;Eᆗᆘ抏qual;抑ersetĀ;Eᆨᆩ抐qual;抒nion;抔cr;쀀𝒮ar;拆ȀbcmpᇈᇛሉላĀ;sᇍᇎ拐etĀ;Eᇍᇕqual;抆ĀchᇠህeedsȀ;ESTᇭᇮᇴᇿ扻qual;檰lantEqual;扽ilde;承Tháྌ;我ƀ;esሒሓሣ拑rsetĀ;Eሜም抃qual;抇et»ሓրHRSacfhiorsሾቄ቉ቕ቞ቱቶኟዂወዑORN耻Þ䃞ADE;愢ĀHc቎ቒcy;䐋y;䐦Ābuቚቜ;䀉;䎤ƀaeyብቪቯron;䅤dil;䅢;䐢r;쀀𝔗Āeiቻ኉ǲኀ\0ኇefore;戴a;䎘Ācn኎ኘkSpace;쀀  Space;怉ldeȀ;EFTካኬኲኼ戼qual;扃ullEqual;扅ilde;扈pf;쀀𝕋ipleDot;惛Āctዖዛr;쀀𝒯rok;䅦ૡዷጎጚጦ\0ጬጱ\0\0\0\0\0ጸጽ፷ᎅ\0᏿ᐄᐊᐐĀcrዻጁute耻Ú䃚rĀ;oጇገ憟cir;楉rǣጓ\0጖y;䐎ve;䅬Āiyጞጣrc耻Û䃛;䐣blac;䅰r;쀀𝔘rave耻Ù䃙acr;䅪Ādiፁ፩erĀBPፈ፝Āarፍፐr;䁟acĀekፗፙ;揟et;掵arenthesis;揝onĀ;P፰፱拃lus;抎Āgp፻፿on;䅲f;쀀𝕌ЀADETadps᎕ᎮᎸᏄϨᏒᏗᏳrrowƀ;BDᅐᎠᎤar;椒ownArrow;懅ownArrow;憕quilibrium;楮eeĀ;AᏋᏌ报rrow;憥ownáϳerĀLRᏞᏨeftArrow;憖ightArrow;憗iĀ;lᏹᏺ䏒on;䎥ing;䅮cr;쀀𝒰ilde;䅨ml耻Ü䃜ҀDbcdefosvᐧᐬᐰᐳᐾᒅᒊᒐᒖash;披ar;櫫y;䐒ashĀ;lᐻᐼ抩;櫦Āerᑃᑅ;拁ƀbtyᑌᑐᑺar;怖Ā;iᑏᑕcalȀBLSTᑡᑥᑪᑴar;戣ine;䁼eparator;杘ilde;所ThinSpace;怊r;쀀𝔙pf;쀀𝕍cr;쀀𝒱dash;抪ʀcefosᒧᒬᒱᒶᒼirc;䅴dge;拀r;쀀𝔚pf;쀀𝕎cr;쀀𝒲Ȁfiosᓋᓐᓒᓘr;쀀𝔛;䎞pf;쀀𝕏cr;쀀𝒳ҀAIUacfosuᓱᓵᓹᓽᔄᔏᔔᔚᔠcy;䐯cy;䐇cy;䐮cute耻Ý䃝Āiyᔉᔍrc;䅶;䐫r;쀀𝔜pf;쀀𝕐cr;쀀𝒴ml;䅸ЀHacdefosᔵᔹᔿᕋᕏᕝᕠᕤcy;䐖cute;䅹Āayᕄᕉron;䅽;䐗ot;䅻ǲᕔ\0ᕛoWidtè૙a;䎖r;愨pf;愤cr;쀀𝒵௡ᖃᖊᖐ\0ᖰᖶᖿ\0\0\0\0ᗆᗛᗫᙟ᙭\0ᚕ᚛ᚲᚹ\0ᚾcute耻á䃡reve;䄃̀;Ediuyᖜᖝᖡᖣᖨᖭ戾;쀀∾̳;房rc耻â䃢te肻´̆;䐰lig耻æ䃦Ā;r²ᖺ;쀀𝔞rave耻à䃠ĀepᗊᗖĀfpᗏᗔsym;愵èᗓha;䎱ĀapᗟcĀclᗤᗧr;䄁g;樿ɤᗰ\0\0ᘊʀ;adsvᗺᗻᗿᘁᘇ戧nd;橕;橜lope;橘;橚΀;elmrszᘘᘙᘛᘞᘿᙏᙙ戠;榤e»ᘙsdĀ;aᘥᘦ戡ѡᘰᘲᘴᘶᘸᘺᘼᘾ;榨;榩;榪;榫;榬;榭;榮;榯tĀ;vᙅᙆ戟bĀ;dᙌᙍ抾;榝Āptᙔᙗh;戢»¹arr;捼Āgpᙣᙧon;䄅f;쀀𝕒΀;Eaeiop዁ᙻᙽᚂᚄᚇᚊ;橰cir;橯;扊d;手s;䀧roxĀ;e዁ᚒñᚃing耻å䃥ƀctyᚡᚦᚨr;쀀𝒶;䀪mpĀ;e዁ᚯñʈilde耻ã䃣ml耻ä䃤Āciᛂᛈoninôɲnt;樑ࠀNabcdefiklnoprsu᛭ᛱᜰ᜼ᝃᝈ᝸᝽០៦ᠹᡐᜍ᤽᥈ᥰot;櫭Ācrᛶ᜞kȀcepsᜀᜅᜍᜓong;扌psilon;䏶rime;怵imĀ;e᜚᜛戽q;拍Ŷᜢᜦee;抽edĀ;gᜬᜭ挅e»ᜭrkĀ;t፜᜷brk;掶Āoyᜁᝁ;䐱quo;怞ʀcmprtᝓ᝛ᝡᝤᝨausĀ;eĊĉptyv;榰séᜌnoõēƀahwᝯ᝱ᝳ;䎲;愶een;扬r;쀀𝔟g΀costuvwឍឝឳេ៕៛៞ƀaiuបពរðݠrc;旯p»፱ƀdptឤឨឭot;樀lus;樁imes;樂ɱឹ\0\0ើcup;樆ar;昅riangleĀdu៍្own;施p;斳plus;樄eåᑄåᒭarow;植ƀako៭ᠦᠵĀcn៲ᠣkƀlst៺֫᠂ozenge;槫riangleȀ;dlr᠒᠓᠘᠝斴own;斾eft;旂ight;斸k;搣Ʊᠫ\0ᠳƲᠯ\0ᠱ;斒;斑4;斓ck;斈ĀeoᠾᡍĀ;qᡃᡆ쀀=⃥uiv;쀀≡⃥t;挐Ȁptwxᡙᡞᡧᡬf;쀀𝕓Ā;tᏋᡣom»Ꮜtie;拈؀DHUVbdhmptuvᢅᢖᢪᢻᣗᣛᣬ᣿ᤅᤊᤐᤡȀLRlrᢎᢐᢒᢔ;敗;敔;敖;敓ʀ;DUduᢡᢢᢤᢦᢨ敐;敦;敩;敤;敧ȀLRlrᢳᢵᢷᢹ;敝;敚;敜;教΀;HLRhlrᣊᣋᣍᣏᣑᣓᣕ救;敬;散;敠;敫;敢;敟ox;槉ȀLRlrᣤᣦᣨᣪ;敕;敒;攐;攌ʀ;DUduڽ᣷᣹᣻᣽;敥;敨;攬;攴inus;抟lus;択imes;抠ȀLRlrᤙᤛᤝ᤟;敛;敘;攘;攔΀;HLRhlrᤰᤱᤳᤵᤷ᤻᤹攂;敪;敡;敞;攼;攤;攜Āevģ᥂bar耻¦䂦Ȁceioᥑᥖᥚᥠr;쀀𝒷mi;恏mĀ;e᜚᜜lƀ;bhᥨᥩᥫ䁜;槅sub;柈Ŭᥴ᥾lĀ;e᥹᥺怢t»᥺pƀ;Eeįᦅᦇ;檮Ā;qۜۛೡᦧ\0᧨ᨑᨕᨲ\0ᨷᩐ\0\0᪴\0\0᫁\0\0ᬡᬮ᭍᭒\0᯽\0ᰌƀcpr᦭ᦲ᧝ute;䄇̀;abcdsᦿᧀᧄ᧊᧕᧙戩nd;橄rcup;橉Āau᧏᧒p;橋p;橇ot;橀;쀀∩︀Āeo᧢᧥t;恁îړȀaeiu᧰᧻ᨁᨅǰ᧵\0᧸s;橍on;䄍dil耻ç䃧rc;䄉psĀ;sᨌᨍ橌m;橐ot;䄋ƀdmnᨛᨠᨦil肻¸ƭptyv;榲t脀¢;eᨭᨮ䂢räƲr;쀀𝔠ƀceiᨽᩀᩍy;䑇ckĀ;mᩇᩈ朓ark»ᩈ;䏇r΀;Ecefms᩟᩠ᩢᩫ᪤᪪᪮旋;槃ƀ;elᩩᩪᩭ䋆q;扗eɡᩴ\0\0᪈rrowĀlr᩼᪁eft;憺ight;憻ʀRSacd᪒᪔᪖᪚᪟»ཇ;擈st;抛irc;抚ash;抝nint;樐id;櫯cir;槂ubsĀ;u᪻᪼晣it»᪼ˬ᫇᫔᫺\0ᬊonĀ;eᫍᫎ䀺Ā;qÇÆɭ᫙\0\0᫢aĀ;t᫞᫟䀬;䁀ƀ;fl᫨᫩᫫戁îᅠeĀmx᫱᫶ent»᫩eóɍǧ᫾\0ᬇĀ;dኻᬂot;橭nôɆƀfryᬐᬔᬗ;쀀𝕔oäɔ脀©;sŕᬝr;愗Āaoᬥᬩrr;憵ss;朗Ācuᬲᬷr;쀀𝒸Ābpᬼ᭄Ā;eᭁᭂ櫏;櫑Ā;eᭉᭊ櫐;櫒dot;拯΀delprvw᭠᭬᭷ᮂᮬᯔ᯹arrĀlr᭨᭪;椸;椵ɰ᭲\0\0᭵r;拞c;拟arrĀ;p᭿ᮀ憶;椽̀;bcdosᮏᮐᮖᮡᮥᮨ截rcap;橈Āauᮛᮞp;橆p;橊ot;抍r;橅;쀀∪︀Ȁalrv᮵ᮿᯞᯣrrĀ;mᮼᮽ憷;椼yƀevwᯇᯔᯘqɰᯎ\0\0ᯒreã᭳uã᭵ee;拎edge;拏en耻¤䂤earrowĀlrᯮ᯳eft»ᮀight»ᮽeäᯝĀciᰁᰇoninôǷnt;戱lcty;挭ঀAHabcdefhijlorstuwz᰸᰻᰿ᱝᱩᱵᲊᲞᲬᲷ᳻᳿ᴍᵻᶑᶫᶻ᷆᷍rò΁ar;楥Ȁglrs᱈ᱍ᱒᱔ger;怠eth;愸òᄳhĀ;vᱚᱛ怐»ऊūᱡᱧarow;椏aã̕Āayᱮᱳron;䄏;䐴ƀ;ao̲ᱼᲄĀgrʿᲁr;懊tseq;橷ƀglmᲑᲔᲘ耻°䂰ta;䎴ptyv;榱ĀirᲣᲨsht;楿;쀀𝔡arĀlrᲳᲵ»ࣜ»သʀaegsv᳂͸᳖᳜᳠mƀ;oș᳊᳔ndĀ;ș᳑uit;晦amma;䏝in;拲ƀ;io᳧᳨᳸䃷de脀÷;o᳧ᳰntimes;拇nø᳷cy;䑒cɯᴆ\0\0ᴊrn;挞op;挍ʀlptuwᴘᴝᴢᵉᵕlar;䀤f;쀀𝕕ʀ;emps̋ᴭᴷᴽᵂqĀ;d͒ᴳot;扑inus;戸lus;戔quare;抡blebarwedgåúnƀadhᄮᵝᵧownarrowóᲃarpoonĀlrᵲᵶefôᲴighôᲶŢᵿᶅkaro÷གɯᶊ\0\0ᶎrn;挟op;挌ƀcotᶘᶣᶦĀryᶝᶡ;쀀𝒹;䑕l;槶rok;䄑Ādrᶰᶴot;拱iĀ;fᶺ᠖斿Āah᷀᷃ròЩaòྦangle;榦Āci᷒ᷕy;䑟grarr;柿ऀDacdefglmnopqrstuxḁḉḙḸոḼṉṡṾấắẽỡἪἷὄ὎὚ĀDoḆᴴoôᲉĀcsḎḔute耻é䃩ter;橮ȀaioyḢḧḱḶron;䄛rĀ;cḭḮ扖耻ê䃪lon;払;䑍ot;䄗ĀDrṁṅot;扒;쀀𝔢ƀ;rsṐṑṗ檚ave耻è䃨Ā;dṜṝ檖ot;檘Ȁ;ilsṪṫṲṴ檙nters;揧;愓Ā;dṹṺ檕ot;檗ƀapsẅẉẗcr;䄓tyƀ;svẒẓẕ戅et»ẓpĀ1;ẝẤĳạả;怄;怅怃ĀgsẪẬ;䅋p;怂ĀgpẴẸon;䄙f;쀀𝕖ƀalsỄỎỒrĀ;sỊị拕l;槣us;橱iƀ;lvỚớở䎵on»ớ;䏵ȀcsuvỪỳἋἣĀioữḱrc»Ḯɩỹ\0\0ỻíՈantĀglἂἆtr»ṝess»Ṻƀaeiἒ἖Ἒls;䀽st;扟vĀ;DȵἠD;橸parsl;槥ĀDaἯἳot;打rr;楱ƀcdiἾὁỸr;愯oô͒ĀahὉὋ;䎷耻ð䃰Āmrὓὗl耻ë䃫o;悬ƀcipὡὤὧl;䀡sôծĀeoὬὴctatioîՙnentialåչৡᾒ\0ᾞ\0ᾡᾧ\0\0ῆῌ\0ΐ\0ῦῪ \0 ⁚llingdotseñṄy;䑄male;晀ƀilrᾭᾳ῁lig;耀ﬃɩᾹ\0\0᾽g;耀ﬀig;耀ﬄ;쀀𝔣lig;耀ﬁlig;쀀fjƀaltῙ῜ῡt;晭ig;耀ﬂns;斱of;䆒ǰ΅\0ῳf;쀀𝕗ĀakֿῷĀ;vῼ´拔;櫙artint;樍Āao‌⁕Ācs‑⁒α‚‰‸⁅⁈\0⁐β•‥‧‪‬\0‮耻½䂽;慓耻¼䂼;慕;慙;慛Ƴ‴\0‶;慔;慖ʴ‾⁁\0\0⁃耻¾䂾;慗;慜5;慘ƶ⁌\0⁎;慚;慝8;慞l;恄wn;挢cr;쀀𝒻ࢀEabcdefgijlnorstv₂₉₟₥₰₴⃰⃵⃺⃿℃ℒℸ̗ℾ⅒↞Ā;lٍ₇;檌ƀcmpₐₕ₝ute;䇵maĀ;dₜ᳚䎳;檆reve;䄟Āiy₪₮rc;䄝;䐳ot;䄡Ȁ;lqsؾق₽⃉ƀ;qsؾٌ⃄lanô٥Ȁ;cdl٥⃒⃥⃕c;檩otĀ;o⃜⃝檀Ā;l⃢⃣檂;檄Ā;e⃪⃭쀀⋛︀s;檔r;쀀𝔤Ā;gٳ؛mel;愷cy;䑓Ȁ;Eajٚℌℎℐ;檒;檥;檤ȀEaesℛℝ℩ℴ;扩pĀ;p℣ℤ檊rox»ℤĀ;q℮ℯ檈Ā;q℮ℛim;拧pf;쀀𝕘Āci⅃ⅆr;愊mƀ;el٫ⅎ⅐;檎;檐茀>;cdlqr׮ⅠⅪⅮⅳⅹĀciⅥⅧ;檧r;橺ot;拗Par;榕uest;橼ʀadelsↄⅪ←ٖ↛ǰ↉\0↎proø₞r;楸qĀlqؿ↖lesó₈ií٫Āen↣↭rtneqq;쀀≩︀Å↪ԀAabcefkosy⇄⇇⇱⇵⇺∘∝∯≨≽ròΠȀilmr⇐⇔⇗⇛rsðᒄf»․ilôکĀdr⇠⇤cy;䑊ƀ;cwࣴ⇫⇯ir;楈;憭ar;意irc;䄥ƀalr∁∎∓rtsĀ;u∉∊晥it»∊lip;怦con;抹r;쀀𝔥sĀew∣∩arow;椥arow;椦ʀamopr∺∾≃≞≣rr;懿tht;戻kĀlr≉≓eftarrow;憩ightarrow;憪f;쀀𝕙bar;怕ƀclt≯≴≸r;쀀𝒽asè⇴rok;䄧Ābp⊂⊇ull;恃hen»ᱛૡ⊣\0⊪\0⊸⋅⋎\0⋕⋳\0\0⋸⌢⍧⍢⍿\0⎆⎪⎴cute耻í䃭ƀ;iyݱ⊰⊵rc耻î䃮;䐸Ācx⊼⊿y;䐵cl耻¡䂡ĀfrΟ⋉;쀀𝔦rave耻ì䃬Ȁ;inoܾ⋝⋩⋮Āin⋢⋦nt;樌t;戭fin;槜ta;愩lig;䄳ƀaop⋾⌚⌝ƀcgt⌅⌈⌗r;䄫ƀelpܟ⌏⌓inåގarôܠh;䄱f;抷ed;䆵ʀ;cfotӴ⌬⌱⌽⍁are;愅inĀ;t⌸⌹戞ie;槝doô⌙ʀ;celpݗ⍌⍐⍛⍡al;抺Āgr⍕⍙eróᕣã⍍arhk;樗rod;樼Ȁcgpt⍯⍲⍶⍻y;䑑on;䄯f;쀀𝕚a;䎹uest耻¿䂿Āci⎊⎏r;쀀𝒾nʀ;EdsvӴ⎛⎝⎡ӳ;拹ot;拵Ā;v⎦⎧拴;拳Ā;iݷ⎮lde;䄩ǫ⎸\0⎼cy;䑖l耻ï䃯̀cfmosu⏌⏗⏜⏡⏧⏵Āiy⏑⏕rc;䄵;䐹r;쀀𝔧ath;䈷pf;쀀𝕛ǣ⏬\0⏱r;쀀𝒿rcy;䑘kcy;䑔Ѐacfghjos␋␖␢␧␭␱␵␻ppaĀ;v␓␔䎺;䏰Āey␛␠dil;䄷;䐺r;쀀𝔨reen;䄸cy;䑅cy;䑜pf;쀀𝕜cr;쀀𝓀஀ABEHabcdefghjlmnoprstuv⑰⒁⒆⒍⒑┎┽╚▀♎♞♥♹♽⚚⚲⛘❝❨➋⟀⠁⠒ƀart⑷⑺⑼rò৆òΕail;椛arr;椎Ā;gঔ⒋;檋ar;楢ॣ⒥\0⒪\0⒱\0\0\0\0\0⒵Ⓔ\0ⓆⓈⓍ\0⓹ute;䄺mptyv;榴raîࡌbda;䎻gƀ;dlࢎⓁⓃ;榑åࢎ;檅uo耻«䂫rЀ;bfhlpst࢙ⓞⓦⓩ⓫⓮⓱⓵Ā;f࢝ⓣs;椟s;椝ë≒p;憫l;椹im;楳l;憢ƀ;ae⓿─┄檫il;椙Ā;s┉┊檭;쀀⪭︀ƀabr┕┙┝rr;椌rk;杲Āak┢┬cĀek┨┪;䁻;䁛Āes┱┳;榋lĀdu┹┻;榏;榍Ȁaeuy╆╋╖╘ron;䄾Ādi═╔il;䄼ìࢰâ┩;䐻Ȁcqrs╣╦╭╽a;椶uoĀ;rนᝆĀdu╲╷har;楧shar;楋h;憲ʀ;fgqs▋▌উ◳◿扤tʀahlrt▘▤▷◂◨rrowĀ;t࢙□aé⓶arpoonĀdu▯▴own»њp»०eftarrows;懇ightƀahs◍◖◞rrowĀ;sࣴࢧarpoonó྘quigarro÷⇰hreetimes;拋ƀ;qs▋ও◺lanôবʀ;cdgsব☊☍☝☨c;檨otĀ;o☔☕橿Ā;r☚☛檁;檃Ā;e☢☥쀀⋚︀s;檓ʀadegs☳☹☽♉♋pproøⓆot;拖qĀgq♃♅ôউgtò⒌ôছiíলƀilr♕࣡♚sht;楼;쀀𝔩Ā;Eজ♣;檑š♩♶rĀdu▲♮Ā;l॥♳;楪lk;斄cy;䑙ʀ;achtੈ⚈⚋⚑⚖rò◁orneòᴈard;楫ri;旺Āio⚟⚤dot;䅀ustĀ;a⚬⚭掰che»⚭ȀEaes⚻⚽⛉⛔;扨pĀ;p⛃⛄檉rox»⛄Ā;q⛎⛏檇Ā;q⛎⚻im;拦Ѐabnoptwz⛩⛴⛷✚✯❁❇❐Ānr⛮⛱g;柬r;懽rëࣁgƀlmr⛿✍✔eftĀar০✇ightá৲apsto;柼ightá৽parrowĀlr✥✩efô⓭ight;憬ƀafl✶✹✽r;榅;쀀𝕝us;樭imes;樴š❋❏st;戗áፎƀ;ef❗❘᠀旊nge»❘arĀ;l❤❥䀨t;榓ʀachmt❳❶❼➅➇ròࢨorneòᶌarĀ;d྘➃;業;怎ri;抿̀achiqt➘➝ੀ➢➮➻quo;怹r;쀀𝓁mƀ;egল➪➬;檍;檏Ābu┪➳oĀ;rฟ➹;怚rok;䅂萀<;cdhilqrࠫ⟒☹⟜⟠⟥⟪⟰Āci⟗⟙;檦r;橹reå◲mes;拉arr;楶uest;橻ĀPi⟵⟹ar;榖ƀ;ef⠀भ᠛旃rĀdu⠇⠍shar;楊har;楦Āen⠗⠡rtneqq;쀀≨︀Å⠞܀Dacdefhilnopsu⡀⡅⢂⢎⢓⢠⢥⢨⣚⣢⣤ઃ⣳⤂Dot;戺Ȁclpr⡎⡒⡣⡽r耻¯䂯Āet⡗⡙;時Ā;e⡞⡟朠se»⡟Ā;sျ⡨toȀ;dluျ⡳⡷⡻owîҌefôएðᏑker;斮Āoy⢇⢌mma;権;䐼ash;怔asuredangle»ᘦr;쀀𝔪o;愧ƀcdn⢯⢴⣉ro耻µ䂵Ȁ;acdᑤ⢽⣀⣄sôᚧir;櫰ot肻·Ƶusƀ;bd⣒ᤃ⣓戒Ā;uᴼ⣘;横ţ⣞⣡p;櫛ò−ðઁĀdp⣩⣮els;抧f;쀀𝕞Āct⣸⣽r;쀀𝓂pos»ᖝƀ;lm⤉⤊⤍䎼timap;抸ఀGLRVabcdefghijlmoprstuvw⥂⥓⥾⦉⦘⧚⧩⨕⨚⩘⩝⪃⪕⪤⪨⬄⬇⭄⭿⮮ⰴⱧⱼ⳩Āgt⥇⥋;쀀⋙̸Ā;v⥐௏쀀≫⃒ƀelt⥚⥲⥶ftĀar⥡⥧rrow;懍ightarrow;懎;쀀⋘̸Ā;v⥻ే쀀≪⃒ightarrow;懏ĀDd⦎⦓ash;抯ash;抮ʀbcnpt⦣⦧⦬⦱⧌la»˞ute;䅄g;쀀∠⃒ʀ;Eiop඄⦼⧀⧅⧈;쀀⩰̸d;쀀≋̸s;䅉roø඄urĀ;a⧓⧔普lĀ;s⧓ସǳ⧟\0⧣p肻 ଷmpĀ;e௹ఀʀaeouy⧴⧾⨃⨐⨓ǰ⧹\0⧻;橃on;䅈dil;䅆ngĀ;dൾ⨊ot;쀀⩭̸p;橂;䐽ash;怓΀;Aadqsxஒ⨩⨭⨻⩁⩅⩐rr;懗rĀhr⨳⨶k;椤Ā;oᏲᏰot;쀀≐̸uiöୣĀei⩊⩎ar;椨í஘istĀ;s஠டr;쀀𝔫ȀEest௅⩦⩹⩼ƀ;qs஼⩭௡ƀ;qs஼௅⩴lanô௢ií௪Ā;rஶ⪁»ஷƀAap⪊⪍⪑rò⥱rr;憮ar;櫲ƀ;svྍ⪜ྌĀ;d⪡⪢拼;拺cy;䑚΀AEadest⪷⪺⪾⫂⫅⫶⫹rò⥦;쀀≦̸rr;憚r;急Ȁ;fqs఻⫎⫣⫯tĀar⫔⫙rro÷⫁ightarro÷⪐ƀ;qs఻⪺⫪lanôౕĀ;sౕ⫴»శiíౝĀ;rవ⫾iĀ;eచథiäඐĀpt⬌⬑f;쀀𝕟膀¬;in⬙⬚⬶䂬nȀ;Edvஉ⬤⬨⬮;쀀⋹̸ot;쀀⋵̸ǡஉ⬳⬵;拷;拶iĀ;vಸ⬼ǡಸ⭁⭃;拾;拽ƀaor⭋⭣⭩rȀ;ast୻⭕⭚⭟lleì୻l;쀀⫽⃥;쀀∂̸lint;樔ƀ;ceಒ⭰⭳uåಥĀ;cಘ⭸Ā;eಒ⭽ñಘȀAait⮈⮋⮝⮧rò⦈rrƀ;cw⮔⮕⮙憛;쀀⤳̸;쀀↝̸ghtarrow»⮕riĀ;eೋೖ΀chimpqu⮽⯍⯙⬄୸⯤⯯Ȁ;cerല⯆ഷ⯉uå൅;쀀𝓃ortɭ⬅\0\0⯖ará⭖mĀ;e൮⯟Ā;q൴൳suĀbp⯫⯭å೸åഋƀbcp⯶ⰑⰙȀ;Ees⯿ⰀഢⰄ抄;쀀⫅̸etĀ;eഛⰋqĀ;qണⰀcĀ;eലⰗñസȀ;EesⰢⰣൟⰧ抅;쀀⫆̸etĀ;e൘ⰮqĀ;qൠⰣȀgilrⰽⰿⱅⱇìௗlde耻ñ䃱çృiangleĀlrⱒⱜeftĀ;eచⱚñదightĀ;eೋⱥñ೗Ā;mⱬⱭ䎽ƀ;esⱴⱵⱹ䀣ro;愖p;怇ҀDHadgilrsⲏⲔⲙⲞⲣⲰⲶⳓⳣash;抭arr;椄p;쀀≍⃒ash;抬ĀetⲨⲬ;쀀≥⃒;쀀>⃒nfin;槞ƀAetⲽⳁⳅrr;椂;쀀≤⃒Ā;rⳊⳍ쀀<⃒ie;쀀⊴⃒ĀAtⳘⳜrr;椃rie;쀀⊵⃒im;쀀∼⃒ƀAan⳰⳴ⴂrr;懖rĀhr⳺⳽k;椣Ā;oᏧᏥear;椧ቓ᪕\0\0\0\0\0\0\0\0\0\0\0\0\0ⴭ\0ⴸⵈⵠⵥ⵲ⶄᬇ\0\0ⶍⶫ\0ⷈⷎ\0ⷜ⸙⸫⸾⹃Ācsⴱ᪗ute耻ó䃳ĀiyⴼⵅrĀ;c᪞ⵂ耻ô䃴;䐾ʀabios᪠ⵒⵗǈⵚlac;䅑v;樸old;榼lig;䅓Ācr⵩⵭ir;榿;쀀𝔬ͯ⵹\0\0⵼\0ⶂn;䋛ave耻ò䃲;槁Ābmⶈ෴ar;榵Ȁacitⶕ⶘ⶥⶨrò᪀Āir⶝ⶠr;榾oss;榻nå๒;槀ƀaeiⶱⶵⶹcr;䅍ga;䏉ƀcdnⷀⷅǍron;䎿;榶pf;쀀𝕠ƀaelⷔ⷗ǒr;榷rp;榹΀;adiosvⷪⷫⷮ⸈⸍⸐⸖戨rò᪆Ȁ;efmⷷⷸ⸂⸅橝rĀ;oⷾⷿ愴f»ⷿ耻ª䂪耻º䂺gof;抶r;橖lope;橗;橛ƀclo⸟⸡⸧ò⸁ash耻ø䃸l;折iŬⸯ⸴de耻õ䃵esĀ;aǛ⸺s;樶ml耻ö䃶bar;挽ૡ⹞\0⹽\0⺀⺝\0⺢⺹\0\0⻋ຜ\0⼓\0\0⼫⾼\0⿈rȀ;astЃ⹧⹲຅脀¶;l⹭⹮䂶leìЃɩ⹸\0\0⹻m;櫳;櫽y;䐿rʀcimpt⺋⺏⺓ᡥ⺗nt;䀥od;䀮il;怰enk;怱r;쀀𝔭ƀimo⺨⺰⺴Ā;v⺭⺮䏆;䏕maô੶ne;明ƀ;tv⺿⻀⻈䏀chfork»´;䏖Āau⻏⻟nĀck⻕⻝kĀ;h⇴⻛;愎ö⇴sҀ;abcdemst⻳⻴ᤈ⻹⻽⼄⼆⼊⼎䀫cir;樣ir;樢Āouᵀ⼂;樥;橲n肻±ຝim;樦wo;樧ƀipu⼙⼠⼥ntint;樕f;쀀𝕡nd耻£䂣Ԁ;Eaceinosu່⼿⽁⽄⽇⾁⾉⾒⽾⾶;檳p;檷uå໙Ā;c໎⽌̀;acens່⽙⽟⽦⽨⽾pproø⽃urlyeñ໙ñ໎ƀaes⽯⽶⽺pprox;檹qq;檵im;拨iíໟmeĀ;s⾈ຮ怲ƀEas⽸⾐⽺ð⽵ƀdfp໬⾙⾯ƀals⾠⾥⾪lar;挮ine;挒urf;挓Ā;t໻⾴ï໻rel;抰Āci⿀⿅r;쀀𝓅;䏈ncsp;怈̀fiopsu⿚⋢⿟⿥⿫⿱r;쀀𝔮pf;쀀𝕢rime;恗cr;쀀𝓆ƀaeo⿸〉〓tĀei⿾々rnionóڰnt;樖stĀ;e【】䀿ñἙô༔઀ABHabcdefhilmnoprstux぀けさすムㄎㄫㅇㅢㅲㆎ㈆㈕㈤㈩㉘㉮㉲㊐㊰㊷ƀartぇおがròႳòϝail;検aròᱥar;楤΀cdenqrtとふへみわゔヌĀeuねぱ;쀀∽̱te;䅕iãᅮmptyv;榳gȀ;del࿑らるろ;榒;榥å࿑uo耻»䂻rր;abcfhlpstw࿜ガクシスゼゾダッデナp;極Ā;f࿠ゴs;椠;椳s;椞ë≝ð✮l;楅im;楴l;憣;憝Āaiパフil;椚oĀ;nホボ戶aló༞ƀabrョリヮrò៥rk;杳ĀakンヽcĀekヹ・;䁽;䁝Āes㄂㄄;榌lĀduㄊㄌ;榎;榐Ȁaeuyㄗㄜㄧㄩron;䅙Ādiㄡㄥil;䅗ì࿲âヺ;䑀Ȁclqsㄴㄷㄽㅄa;椷dhar;楩uoĀ;rȎȍh;憳ƀacgㅎㅟངlȀ;ipsླྀㅘㅛႜnåႻarôྩt;断ƀilrㅩဣㅮsht;楽;쀀𝔯ĀaoㅷㆆrĀduㅽㅿ»ѻĀ;l႑ㆄ;楬Ā;vㆋㆌ䏁;䏱ƀgns㆕ㇹㇼht̀ahlrstㆤㆰ㇂㇘㇤㇮rrowĀ;t࿜ㆭaéトarpoonĀduㆻㆿowîㅾp»႒eftĀah㇊㇐rrowó࿪arpoonóՑightarrows;應quigarro÷ニhreetimes;拌g;䋚ingdotseñἲƀahm㈍㈐㈓rò࿪aòՑ;怏oustĀ;a㈞㈟掱che»㈟mid;櫮Ȁabpt㈲㈽㉀㉒Ānr㈷㈺g;柭r;懾rëဃƀafl㉇㉊㉎r;榆;쀀𝕣us;樮imes;樵Āap㉝㉧rĀ;g㉣㉤䀩t;榔olint;樒arò㇣Ȁachq㉻㊀Ⴜ㊅quo;怺r;쀀𝓇Ābu・㊊oĀ;rȔȓƀhir㊗㊛㊠reåㇸmes;拊iȀ;efl㊪ၙᠡ㊫方tri;槎luhar;楨;愞ൡ㋕㋛㋟㌬㌸㍱\0㍺㎤\0\0㏬㏰\0㐨㑈㑚㒭㒱㓊㓱\0㘖\0\0㘳cute;䅛quï➺Ԁ;Eaceinpsyᇭ㋳㋵㋿㌂㌋㌏㌟㌦㌩;檴ǰ㋺\0㋼;檸on;䅡uåᇾĀ;dᇳ㌇il;䅟rc;䅝ƀEas㌖㌘㌛;檶p;檺im;择olint;樓iíሄ;䑁otƀ;be㌴ᵇ㌵担;橦΀Aacmstx㍆㍊㍗㍛㍞㍣㍭rr;懘rĀhr㍐㍒ë∨Ā;oਸ਼਴t耻§䂧i;䀻war;椩mĀin㍩ðnuóñt;朶rĀ;o㍶⁕쀀𝔰Ȁacoy㎂㎆㎑㎠rp;景Āhy㎋㎏cy;䑉;䑈rtɭ㎙\0\0㎜iäᑤaraì⹯耻­䂭Āgm㎨㎴maƀ;fv㎱㎲㎲䏃;䏂Ѐ;deglnprካ㏅㏉㏎㏖㏞㏡㏦ot;橪Ā;q኱ኰĀ;E㏓㏔檞;檠Ā;E㏛㏜檝;檟e;扆lus;樤arr;楲aròᄽȀaeit㏸㐈㐏㐗Āls㏽㐄lsetmé㍪hp;樳parsl;槤Ādlᑣ㐔e;挣Ā;e㐜㐝檪Ā;s㐢㐣檬;쀀⪬︀ƀflp㐮㐳㑂tcy;䑌Ā;b㐸㐹䀯Ā;a㐾㐿槄r;挿f;쀀𝕤aĀdr㑍ЂesĀ;u㑔㑕晠it»㑕ƀcsu㑠㑹㒟Āau㑥㑯pĀ;sᆈ㑫;쀀⊓︀pĀ;sᆴ㑵;쀀⊔︀uĀbp㑿㒏ƀ;esᆗᆜ㒆etĀ;eᆗ㒍ñᆝƀ;esᆨᆭ㒖etĀ;eᆨ㒝ñᆮƀ;afᅻ㒦ְrť㒫ֱ»ᅼaròᅈȀcemt㒹㒾㓂㓅r;쀀𝓈tmîñiì㐕aræᆾĀar㓎㓕rĀ;f㓔ឿ昆Āan㓚㓭ightĀep㓣㓪psiloîỠhé⺯s»⡒ʀbcmnp㓻㕞ሉ㖋㖎Ҁ;Edemnprs㔎㔏㔑㔕㔞㔣㔬㔱㔶抂;櫅ot;檽Ā;dᇚ㔚ot;櫃ult;櫁ĀEe㔨㔪;櫋;把lus;檿arr;楹ƀeiu㔽㕒㕕tƀ;en㔎㕅㕋qĀ;qᇚ㔏eqĀ;q㔫㔨m;櫇Ābp㕚㕜;櫕;櫓c̀;acensᇭ㕬㕲㕹㕻㌦pproø㋺urlyeñᇾñᇳƀaes㖂㖈㌛pproø㌚qñ㌗g;晪ڀ123;Edehlmnps㖩㖬㖯ሜ㖲㖴㗀㗉㗕㗚㗟㗨㗭耻¹䂹耻²䂲耻³䂳;櫆Āos㖹㖼t;檾ub;櫘Ā;dሢ㗅ot;櫄sĀou㗏㗒l;柉b;櫗arr;楻ult;櫂ĀEe㗤㗦;櫌;抋lus;櫀ƀeiu㗴㘉㘌tƀ;enሜ㗼㘂qĀ;qሢ㖲eqĀ;q㗧㗤m;櫈Ābp㘑㘓;櫔;櫖ƀAan㘜㘠㘭rr;懙rĀhr㘦㘨ë∮Ā;oਫ਩war;椪lig耻ß䃟௡㙑㙝㙠ዎ㙳㙹\0㙾㛂\0\0\0\0\0㛛㜃\0㜉㝬\0\0\0㞇ɲ㙖\0\0㙛get;挖;䏄rë๟ƀaey㙦㙫㙰ron;䅥dil;䅣;䑂lrec;挕r;쀀𝔱Ȁeiko㚆㚝㚵㚼ǲ㚋\0㚑eĀ4fኄኁaƀ;sv㚘㚙㚛䎸ym;䏑Ācn㚢㚲kĀas㚨㚮pproø዁im»ኬsðኞĀas㚺㚮ð዁rn耻þ䃾Ǭ̟㛆⋧es膀×;bd㛏㛐㛘䃗Ā;aᤏ㛕r;樱;樰ƀeps㛡㛣㜀á⩍Ȁ;bcf҆㛬㛰㛴ot;挶ir;櫱Ā;o㛹㛼쀀𝕥rk;櫚á㍢rime;怴ƀaip㜏㜒㝤dåቈ΀adempst㜡㝍㝀㝑㝗㝜㝟ngleʀ;dlqr㜰㜱㜶㝀㝂斵own»ᶻeftĀ;e⠀㜾ñम;扜ightĀ;e㊪㝋ñၚot;旬inus;樺lus;樹b;槍ime;樻ezium;揢ƀcht㝲㝽㞁Āry㝷㝻;쀀𝓉;䑆cy;䑛rok;䅧Āio㞋㞎xô᝷headĀlr㞗㞠eftarro÷ࡏightarrow»ཝऀAHabcdfghlmoprstuw㟐㟓㟗㟤㟰㟼㠎㠜㠣㠴㡑㡝㡫㢩㣌㣒㣪㣶ròϭar;楣Ācr㟜㟢ute耻ú䃺òᅐrǣ㟪\0㟭y;䑞ve;䅭Āiy㟵㟺rc耻û䃻;䑃ƀabh㠃㠆㠋ròᎭlac;䅱aòᏃĀir㠓㠘sht;楾;쀀𝔲rave耻ù䃹š㠧㠱rĀlr㠬㠮»ॗ»ႃlk;斀Āct㠹㡍ɯ㠿\0\0㡊rnĀ;e㡅㡆挜r»㡆op;挏ri;旸Āal㡖㡚cr;䅫肻¨͉Āgp㡢㡦on;䅳f;쀀𝕦̀adhlsuᅋ㡸㡽፲㢑㢠ownáᎳarpoonĀlr㢈㢌efô㠭ighô㠯iƀ;hl㢙㢚㢜䏅»ᏺon»㢚parrows;懈ƀcit㢰㣄㣈ɯ㢶\0\0㣁rnĀ;e㢼㢽挝r»㢽op;挎ng;䅯ri;旹cr;쀀𝓊ƀdir㣙㣝㣢ot;拰lde;䅩iĀ;f㜰㣨»᠓Āam㣯㣲rò㢨l耻ü䃼angle;榧ހABDacdeflnoprsz㤜㤟㤩㤭㦵㦸㦽㧟㧤㧨㧳㧹㧽㨁㨠ròϷarĀ;v㤦㤧櫨;櫩asèϡĀnr㤲㤷grt;榜΀eknprst㓣㥆㥋㥒㥝㥤㦖appá␕othinçẖƀhir㓫⻈㥙opô⾵Ā;hᎷ㥢ïㆍĀiu㥩㥭gmá㎳Ābp㥲㦄setneqĀ;q㥽㦀쀀⊊︀;쀀⫋︀setneqĀ;q㦏㦒쀀⊋︀;쀀⫌︀Āhr㦛㦟etá㚜iangleĀlr㦪㦯eft»थight»ၑy;䐲ash»ံƀelr㧄㧒㧗ƀ;beⷪ㧋㧏ar;抻q;扚lip;拮Ābt㧜ᑨaòᑩr;쀀𝔳tré㦮suĀbp㧯㧱»ജ»൙pf;쀀𝕧roð໻tré㦴Ācu㨆㨋r;쀀𝓋Ābp㨐㨘nĀEe㦀㨖»㥾nĀEe㦒㨞»㦐igzag;榚΀cefoprs㨶㨻㩖㩛㩔㩡㩪irc;䅵Ādi㩀㩑Ābg㩅㩉ar;機eĀ;qᗺ㩏;扙erp;愘r;쀀𝔴pf;쀀𝕨Ā;eᑹ㩦atèᑹcr;쀀𝓌ૣណ㪇\0㪋\0㪐㪛\0\0㪝㪨㪫㪯\0\0㫃㫎\0㫘ៜ៟tré៑r;쀀𝔵ĀAa㪔㪗ròσrò৶;䎾ĀAa㪡㪤ròθrò৫að✓is;拻ƀdptឤ㪵㪾Āfl㪺ឩ;쀀𝕩imåឲĀAa㫇㫊ròώròਁĀcq㫒ីr;쀀𝓍Āpt៖㫜ré។Ѐacefiosu㫰㫽㬈㬌㬑㬕㬛㬡cĀuy㫶㫻te耻ý䃽;䑏Āiy㬂㬆rc;䅷;䑋n耻¥䂥r;쀀𝔶cy;䑗pf;쀀𝕪cr;쀀𝓎Ācm㬦㬩y;䑎l耻ÿ䃿Ԁacdefhiosw㭂㭈㭔㭘㭤㭩㭭㭴㭺㮀cute;䅺Āay㭍㭒ron;䅾;䐷ot;䅼Āet㭝㭡træᕟa;䎶r;쀀𝔷cy;䐶grarr;懝pf;쀀𝕫cr;쀀𝓏Ājn㮅㮇;怍j;怌'.split("").map((e) => e.charCodeAt(0))
), Eu = /* @__PURE__ */ new Map([
  [0, 65533],
  // C1 Unicode control character reference replacements
  [128, 8364],
  [130, 8218],
  [131, 402],
  [132, 8222],
  [133, 8230],
  [134, 8224],
  [135, 8225],
  [136, 710],
  [137, 8240],
  [138, 352],
  [139, 8249],
  [140, 338],
  [142, 381],
  [145, 8216],
  [146, 8217],
  [147, 8220],
  [148, 8221],
  [149, 8226],
  [150, 8211],
  [151, 8212],
  [152, 732],
  [153, 8482],
  [154, 353],
  [155, 8250],
  [156, 339],
  [158, 382],
  [159, 376]
]);
function Tu(e) {
  var t;
  return e >= 55296 && e <= 57343 || e > 1114111 ? 65533 : (t = Eu.get(e)) !== null && t !== void 0 ? t : e;
}
var C;
(function(e) {
  e[e.NUM = 35] = "NUM", e[e.SEMI = 59] = "SEMI", e[e.EQUALS = 61] = "EQUALS", e[e.ZERO = 48] = "ZERO", e[e.NINE = 57] = "NINE", e[e.LOWER_A = 97] = "LOWER_A", e[e.LOWER_F = 102] = "LOWER_F", e[e.LOWER_X = 120] = "LOWER_X", e[e.LOWER_Z = 122] = "LOWER_Z", e[e.UPPER_A = 65] = "UPPER_A", e[e.UPPER_F = 70] = "UPPER_F", e[e.UPPER_Z = 90] = "UPPER_Z";
})(C || (C = {}));
const lu = 32;
var B;
(function(e) {
  e[e.VALUE_LENGTH = 49152] = "VALUE_LENGTH", e[e.BRANCH_LENGTH = 16256] = "BRANCH_LENGTH", e[e.JUMP_TABLE = 127] = "JUMP_TABLE";
})(B || (B = {}));
function me(e) {
  return e >= C.ZERO && e <= C.NINE;
}
function hu(e) {
  return e >= C.UPPER_A && e <= C.UPPER_F || e >= C.LOWER_A && e <= C.LOWER_F;
}
function fu(e) {
  return e >= C.UPPER_A && e <= C.UPPER_Z || e >= C.LOWER_A && e <= C.LOWER_Z || me(e);
}
function mu(e) {
  return e === C.EQUALS || fu(e);
}
var I;
(function(e) {
  e[e.EntityStart = 0] = "EntityStart", e[e.NumericStart = 1] = "NumericStart", e[e.NumericDecimal = 2] = "NumericDecimal", e[e.NumericHex = 3] = "NumericHex", e[e.NamedEntity = 4] = "NamedEntity";
})(I || (I = {}));
var D;
(function(e) {
  e[e.Legacy = 0] = "Legacy", e[e.Strict = 1] = "Strict", e[e.Attribute = 2] = "Attribute";
})(D || (D = {}));
class _u {
  constructor(t, a, s) {
    this.decodeTree = t, this.emitCodePoint = a, this.errors = s, this.state = I.EntityStart, this.consumed = 1, this.result = 0, this.treeIndex = 0, this.excess = 1, this.decodeMode = D.Strict;
  }
  /** Resets the instance to make it reusable. */
  startEntity(t) {
    this.decodeMode = t, this.state = I.EntityStart, this.result = 0, this.treeIndex = 0, this.excess = 1, this.consumed = 1;
  }
  /**
   * Write an entity to the decoder. This can be called multiple times with partial entities.
   * If the entity is incomplete, the decoder will return -1.
   *
   * Mirrors the implementation of `getDecoder`, but with the ability to stop decoding if the
   * entity is incomplete, and resume when the next string is written.
   *
   * @param input The string containing the entity (or a continuation of the entity).
   * @param offset The offset at which the entity begins. Should be 0 if this is not the first call.
   * @returns The number of characters that were consumed, or -1 if the entity is incomplete.
   */
  write(t, a) {
    switch (this.state) {
      case I.EntityStart:
        return t.charCodeAt(a) === C.NUM ? (this.state = I.NumericStart, this.consumed += 1, this.stateNumericStart(t, a + 1)) : (this.state = I.NamedEntity, this.stateNamedEntity(t, a));
      case I.NumericStart:
        return this.stateNumericStart(t, a);
      case I.NumericDecimal:
        return this.stateNumericDecimal(t, a);
      case I.NumericHex:
        return this.stateNumericHex(t, a);
      case I.NamedEntity:
        return this.stateNamedEntity(t, a);
    }
  }
  /**
   * Switches between the numeric decimal and hexadecimal states.
   *
   * Equivalent to the `Numeric character reference state` in the HTML spec.
   *
   * @param input The string containing the entity (or a continuation of the entity).
   * @param offset The current offset.
   * @returns The number of characters that were consumed, or -1 if the entity is incomplete.
   */
  stateNumericStart(t, a) {
    return a >= t.length ? -1 : (t.charCodeAt(a) | lu) === C.LOWER_X ? (this.state = I.NumericHex, this.consumed += 1, this.stateNumericHex(t, a + 1)) : (this.state = I.NumericDecimal, this.stateNumericDecimal(t, a));
  }
  addToNumericResult(t, a, s, c) {
    if (a !== s) {
      const d = s - a;
      this.result = this.result * Math.pow(c, d) + Number.parseInt(t.substr(a, d), c), this.consumed += d;
    }
  }
  /**
   * Parses a hexadecimal numeric entity.
   *
   * Equivalent to the `Hexademical character reference state` in the HTML spec.
   *
   * @param input The string containing the entity (or a continuation of the entity).
   * @param offset The current offset.
   * @returns The number of characters that were consumed, or -1 if the entity is incomplete.
   */
  stateNumericHex(t, a) {
    const s = a;
    for (; a < t.length; ) {
      const c = t.charCodeAt(a);
      if (me(c) || hu(c))
        a += 1;
      else
        return this.addToNumericResult(t, s, a, 16), this.emitNumericEntity(c, 3);
    }
    return this.addToNumericResult(t, s, a, 16), -1;
  }
  /**
   * Parses a decimal numeric entity.
   *
   * Equivalent to the `Decimal character reference state` in the HTML spec.
   *
   * @param input The string containing the entity (or a continuation of the entity).
   * @param offset The current offset.
   * @returns The number of characters that were consumed, or -1 if the entity is incomplete.
   */
  stateNumericDecimal(t, a) {
    const s = a;
    for (; a < t.length; ) {
      const c = t.charCodeAt(a);
      if (me(c))
        a += 1;
      else
        return this.addToNumericResult(t, s, a, 10), this.emitNumericEntity(c, 2);
    }
    return this.addToNumericResult(t, s, a, 10), -1;
  }
  /**
   * Validate and emit a numeric entity.
   *
   * Implements the logic from the `Hexademical character reference start
   * state` and `Numeric character reference end state` in the HTML spec.
   *
   * @param lastCp The last code point of the entity. Used to see if the
   *               entity was terminated with a semicolon.
   * @param expectedLength The minimum number of characters that should be
   *                       consumed. Used to validate that at least one digit
   *                       was consumed.
   * @returns The number of characters that were consumed.
   */
  emitNumericEntity(t, a) {
    var s;
    if (this.consumed <= a)
      return (s = this.errors) === null || s === void 0 || s.absenceOfDigitsInNumericCharacterReference(this.consumed), 0;
    if (t === C.SEMI)
      this.consumed += 1;
    else if (this.decodeMode === D.Strict)
      return 0;
    return this.emitCodePoint(Tu(this.result), this.consumed), this.errors && (t !== C.SEMI && this.errors.missingSemicolonAfterCharacterReference(), this.errors.validateNumericCharacterReference(this.result)), this.consumed;
  }
  /**
   * Parses a named entity.
   *
   * Equivalent to the `Named character reference state` in the HTML spec.
   *
   * @param input The string containing the entity (or a continuation of the entity).
   * @param offset The current offset.
   * @returns The number of characters that were consumed, or -1 if the entity is incomplete.
   */
  stateNamedEntity(t, a) {
    const { decodeTree: s } = this;
    let c = s[this.treeIndex], d = (c & B.VALUE_LENGTH) >> 14;
    for (; a < t.length; a++, this.excess++) {
      const l = t.charCodeAt(a);
      if (this.treeIndex = bu(s, c, this.treeIndex + Math.max(1, d), l), this.treeIndex < 0)
        return this.result === 0 || // If we are parsing an attribute
        this.decodeMode === D.Attribute && // We shouldn't have consumed any characters after the entity,
        (d === 0 || // And there should be no invalid characters.
        mu(l)) ? 0 : this.emitNotTerminatedNamedEntity();
      if (c = s[this.treeIndex], d = (c & B.VALUE_LENGTH) >> 14, d !== 0) {
        if (l === C.SEMI)
          return this.emitNamedEntityData(this.treeIndex, d, this.consumed + this.excess);
        this.decodeMode !== D.Strict && (this.result = this.treeIndex, this.consumed += this.excess, this.excess = 0);
      }
    }
    return -1;
  }
  /**
   * Emit a named entity that was not terminated with a semicolon.
   *
   * @returns The number of characters consumed.
   */
  emitNotTerminatedNamedEntity() {
    var t;
    const { result: a, decodeTree: s } = this, c = (s[a] & B.VALUE_LENGTH) >> 14;
    return this.emitNamedEntityData(a, c, this.consumed), (t = this.errors) === null || t === void 0 || t.missingSemicolonAfterCharacterReference(), this.consumed;
  }
  /**
   * Emit a named entity.
   *
   * @param result The index of the entity in the decode tree.
   * @param valueLength The number of bytes in the entity.
   * @param consumed The number of characters consumed.
   *
   * @returns The number of characters consumed.
   */
  emitNamedEntityData(t, a, s) {
    const { decodeTree: c } = this;
    return this.emitCodePoint(a === 1 ? c[t] & ~B.VALUE_LENGTH : c[t + 1], s), a === 3 && this.emitCodePoint(c[t + 2], s), s;
  }
  /**
   * Signal to the parser that the end of the input was reached.
   *
   * Remaining data will be emitted and relevant errors will be produced.
   *
   * @returns The number of characters consumed.
   */
  end() {
    var t;
    switch (this.state) {
      case I.NamedEntity:
        return this.result !== 0 && (this.decodeMode !== D.Attribute || this.result === this.treeIndex) ? this.emitNotTerminatedNamedEntity() : 0;
      case I.NumericDecimal:
        return this.emitNumericEntity(0, 2);
      case I.NumericHex:
        return this.emitNumericEntity(0, 3);
      case I.NumericStart:
        return (t = this.errors) === null || t === void 0 || t.absenceOfDigitsInNumericCharacterReference(this.consumed), 0;
      case I.EntityStart:
        return 0;
    }
  }
}
function bu(e, t, a, s) {
  const c = (t & B.BRANCH_LENGTH) >> 7, d = t & B.JUMP_TABLE;
  if (c === 0)
    return d !== 0 && s === d ? a : -1;
  if (d) {
    const f = s - d;
    return f < 0 || f >= c ? -1 : e[a + f] - 1;
  }
  let l = a, m = l + c - 1;
  for (; l <= m; ) {
    const f = l + m >>> 1, b = e[f];
    if (b < s)
      l = f + 1;
    else if (b > s)
      m = f - 1;
    else
      return e[f + c];
  }
  return -1;
}
var T;
(function(e) {
  e.HTML = "http://www.w3.org/1999/xhtml", e.MATHML = "http://www.w3.org/1998/Math/MathML", e.SVG = "http://www.w3.org/2000/svg", e.XLINK = "http://www.w3.org/1999/xlink", e.XML = "http://www.w3.org/XML/1998/namespace", e.XMLNS = "http://www.w3.org/2000/xmlns/";
})(T || (T = {}));
var k;
(function(e) {
  e.TYPE = "type", e.ACTION = "action", e.ENCODING = "encoding", e.PROMPT = "prompt", e.NAME = "name", e.COLOR = "color", e.FACE = "face", e.SIZE = "size";
})(k || (k = {}));
var L;
(function(e) {
  e.NO_QUIRKS = "no-quirks", e.QUIRKS = "quirks", e.LIMITED_QUIRKS = "limited-quirks";
})(L || (L = {}));
var o;
(function(e) {
  e.A = "a", e.ADDRESS = "address", e.ANNOTATION_XML = "annotation-xml", e.APPLET = "applet", e.AREA = "area", e.ARTICLE = "article", e.ASIDE = "aside", e.B = "b", e.BASE = "base", e.BASEFONT = "basefont", e.BGSOUND = "bgsound", e.BIG = "big", e.BLOCKQUOTE = "blockquote", e.BODY = "body", e.BR = "br", e.BUTTON = "button", e.CAPTION = "caption", e.CENTER = "center", e.CODE = "code", e.COL = "col", e.COLGROUP = "colgroup", e.DD = "dd", e.DESC = "desc", e.DETAILS = "details", e.DIALOG = "dialog", e.DIR = "dir", e.DIV = "div", e.DL = "dl", e.DT = "dt", e.EM = "em", e.EMBED = "embed", e.FIELDSET = "fieldset", e.FIGCAPTION = "figcaption", e.FIGURE = "figure", e.FONT = "font", e.FOOTER = "footer", e.FOREIGN_OBJECT = "foreignObject", e.FORM = "form", e.FRAME = "frame", e.FRAMESET = "frameset", e.H1 = "h1", e.H2 = "h2", e.H3 = "h3", e.H4 = "h4", e.H5 = "h5", e.H6 = "h6", e.HEAD = "head", e.HEADER = "header", e.HGROUP = "hgroup", e.HR = "hr", e.HTML = "html", e.I = "i", e.IMG = "img", e.IMAGE = "image", e.INPUT = "input", e.IFRAME = "iframe", e.KEYGEN = "keygen", e.LABEL = "label", e.LI = "li", e.LINK = "link", e.LISTING = "listing", e.MAIN = "main", e.MALIGNMARK = "malignmark", e.MARQUEE = "marquee", e.MATH = "math", e.MENU = "menu", e.META = "meta", e.MGLYPH = "mglyph", e.MI = "mi", e.MO = "mo", e.MN = "mn", e.MS = "ms", e.MTEXT = "mtext", e.NAV = "nav", e.NOBR = "nobr", e.NOFRAMES = "noframes", e.NOEMBED = "noembed", e.NOSCRIPT = "noscript", e.OBJECT = "object", e.OL = "ol", e.OPTGROUP = "optgroup", e.OPTION = "option", e.P = "p", e.PARAM = "param", e.PLAINTEXT = "plaintext", e.PRE = "pre", e.RB = "rb", e.RP = "rp", e.RT = "rt", e.RTC = "rtc", e.RUBY = "ruby", e.S = "s", e.SCRIPT = "script", e.SEARCH = "search", e.SECTION = "section", e.SELECT = "select", e.SOURCE = "source", e.SMALL = "small", e.SPAN = "span", e.STRIKE = "strike", e.STRONG = "strong", e.STYLE = "style", e.SUB = "sub", e.SUMMARY = "summary", e.SUP = "sup", e.TABLE = "table", e.TBODY = "tbody", e.TEMPLATE = "template", e.TEXTAREA = "textarea", e.TFOOT = "tfoot", e.TD = "td", e.TH = "th", e.THEAD = "thead", e.TITLE = "title", e.TR = "tr", e.TRACK = "track", e.TT = "tt", e.U = "u", e.UL = "ul", e.SVG = "svg", e.VAR = "var", e.WBR = "wbr", e.XMP = "xmp";
})(o || (o = {}));
var u;
(function(e) {
  e[e.UNKNOWN = 0] = "UNKNOWN", e[e.A = 1] = "A", e[e.ADDRESS = 2] = "ADDRESS", e[e.ANNOTATION_XML = 3] = "ANNOTATION_XML", e[e.APPLET = 4] = "APPLET", e[e.AREA = 5] = "AREA", e[e.ARTICLE = 6] = "ARTICLE", e[e.ASIDE = 7] = "ASIDE", e[e.B = 8] = "B", e[e.BASE = 9] = "BASE", e[e.BASEFONT = 10] = "BASEFONT", e[e.BGSOUND = 11] = "BGSOUND", e[e.BIG = 12] = "BIG", e[e.BLOCKQUOTE = 13] = "BLOCKQUOTE", e[e.BODY = 14] = "BODY", e[e.BR = 15] = "BR", e[e.BUTTON = 16] = "BUTTON", e[e.CAPTION = 17] = "CAPTION", e[e.CENTER = 18] = "CENTER", e[e.CODE = 19] = "CODE", e[e.COL = 20] = "COL", e[e.COLGROUP = 21] = "COLGROUP", e[e.DD = 22] = "DD", e[e.DESC = 23] = "DESC", e[e.DETAILS = 24] = "DETAILS", e[e.DIALOG = 25] = "DIALOG", e[e.DIR = 26] = "DIR", e[e.DIV = 27] = "DIV", e[e.DL = 28] = "DL", e[e.DT = 29] = "DT", e[e.EM = 30] = "EM", e[e.EMBED = 31] = "EMBED", e[e.FIELDSET = 32] = "FIELDSET", e[e.FIGCAPTION = 33] = "FIGCAPTION", e[e.FIGURE = 34] = "FIGURE", e[e.FONT = 35] = "FONT", e[e.FOOTER = 36] = "FOOTER", e[e.FOREIGN_OBJECT = 37] = "FOREIGN_OBJECT", e[e.FORM = 38] = "FORM", e[e.FRAME = 39] = "FRAME", e[e.FRAMESET = 40] = "FRAMESET", e[e.H1 = 41] = "H1", e[e.H2 = 42] = "H2", e[e.H3 = 43] = "H3", e[e.H4 = 44] = "H4", e[e.H5 = 45] = "H5", e[e.H6 = 46] = "H6", e[e.HEAD = 47] = "HEAD", e[e.HEADER = 48] = "HEADER", e[e.HGROUP = 49] = "HGROUP", e[e.HR = 50] = "HR", e[e.HTML = 51] = "HTML", e[e.I = 52] = "I", e[e.IMG = 53] = "IMG", e[e.IMAGE = 54] = "IMAGE", e[e.INPUT = 55] = "INPUT", e[e.IFRAME = 56] = "IFRAME", e[e.KEYGEN = 57] = "KEYGEN", e[e.LABEL = 58] = "LABEL", e[e.LI = 59] = "LI", e[e.LINK = 60] = "LINK", e[e.LISTING = 61] = "LISTING", e[e.MAIN = 62] = "MAIN", e[e.MALIGNMARK = 63] = "MALIGNMARK", e[e.MARQUEE = 64] = "MARQUEE", e[e.MATH = 65] = "MATH", e[e.MENU = 66] = "MENU", e[e.META = 67] = "META", e[e.MGLYPH = 68] = "MGLYPH", e[e.MI = 69] = "MI", e[e.MO = 70] = "MO", e[e.MN = 71] = "MN", e[e.MS = 72] = "MS", e[e.MTEXT = 73] = "MTEXT", e[e.NAV = 74] = "NAV", e[e.NOBR = 75] = "NOBR", e[e.NOFRAMES = 76] = "NOFRAMES", e[e.NOEMBED = 77] = "NOEMBED", e[e.NOSCRIPT = 78] = "NOSCRIPT", e[e.OBJECT = 79] = "OBJECT", e[e.OL = 80] = "OL", e[e.OPTGROUP = 81] = "OPTGROUP", e[e.OPTION = 82] = "OPTION", e[e.P = 83] = "P", e[e.PARAM = 84] = "PARAM", e[e.PLAINTEXT = 85] = "PLAINTEXT", e[e.PRE = 86] = "PRE", e[e.RB = 87] = "RB", e[e.RP = 88] = "RP", e[e.RT = 89] = "RT", e[e.RTC = 90] = "RTC", e[e.RUBY = 91] = "RUBY", e[e.S = 92] = "S", e[e.SCRIPT = 93] = "SCRIPT", e[e.SEARCH = 94] = "SEARCH", e[e.SECTION = 95] = "SECTION", e[e.SELECT = 96] = "SELECT", e[e.SOURCE = 97] = "SOURCE", e[e.SMALL = 98] = "SMALL", e[e.SPAN = 99] = "SPAN", e[e.STRIKE = 100] = "STRIKE", e[e.STRONG = 101] = "STRONG", e[e.STYLE = 102] = "STYLE", e[e.SUB = 103] = "SUB", e[e.SUMMARY = 104] = "SUMMARY", e[e.SUP = 105] = "SUP", e[e.TABLE = 106] = "TABLE", e[e.TBODY = 107] = "TBODY", e[e.TEMPLATE = 108] = "TEMPLATE", e[e.TEXTAREA = 109] = "TEXTAREA", e[e.TFOOT = 110] = "TFOOT", e[e.TD = 111] = "TD", e[e.TH = 112] = "TH", e[e.THEAD = 113] = "THEAD", e[e.TITLE = 114] = "TITLE", e[e.TR = 115] = "TR", e[e.TRACK = 116] = "TRACK", e[e.TT = 117] = "TT", e[e.U = 118] = "U", e[e.UL = 119] = "UL", e[e.SVG = 120] = "SVG", e[e.VAR = 121] = "VAR", e[e.WBR = 122] = "WBR", e[e.XMP = 123] = "XMP";
})(u || (u = {}));
const Au = /* @__PURE__ */ new Map([
  [o.A, u.A],
  [o.ADDRESS, u.ADDRESS],
  [o.ANNOTATION_XML, u.ANNOTATION_XML],
  [o.APPLET, u.APPLET],
  [o.AREA, u.AREA],
  [o.ARTICLE, u.ARTICLE],
  [o.ASIDE, u.ASIDE],
  [o.B, u.B],
  [o.BASE, u.BASE],
  [o.BASEFONT, u.BASEFONT],
  [o.BGSOUND, u.BGSOUND],
  [o.BIG, u.BIG],
  [o.BLOCKQUOTE, u.BLOCKQUOTE],
  [o.BODY, u.BODY],
  [o.BR, u.BR],
  [o.BUTTON, u.BUTTON],
  [o.CAPTION, u.CAPTION],
  [o.CENTER, u.CENTER],
  [o.CODE, u.CODE],
  [o.COL, u.COL],
  [o.COLGROUP, u.COLGROUP],
  [o.DD, u.DD],
  [o.DESC, u.DESC],
  [o.DETAILS, u.DETAILS],
  [o.DIALOG, u.DIALOG],
  [o.DIR, u.DIR],
  [o.DIV, u.DIV],
  [o.DL, u.DL],
  [o.DT, u.DT],
  [o.EM, u.EM],
  [o.EMBED, u.EMBED],
  [o.FIELDSET, u.FIELDSET],
  [o.FIGCAPTION, u.FIGCAPTION],
  [o.FIGURE, u.FIGURE],
  [o.FONT, u.FONT],
  [o.FOOTER, u.FOOTER],
  [o.FOREIGN_OBJECT, u.FOREIGN_OBJECT],
  [o.FORM, u.FORM],
  [o.FRAME, u.FRAME],
  [o.FRAMESET, u.FRAMESET],
  [o.H1, u.H1],
  [o.H2, u.H2],
  [o.H3, u.H3],
  [o.H4, u.H4],
  [o.H5, u.H5],
  [o.H6, u.H6],
  [o.HEAD, u.HEAD],
  [o.HEADER, u.HEADER],
  [o.HGROUP, u.HGROUP],
  [o.HR, u.HR],
  [o.HTML, u.HTML],
  [o.I, u.I],
  [o.IMG, u.IMG],
  [o.IMAGE, u.IMAGE],
  [o.INPUT, u.INPUT],
  [o.IFRAME, u.IFRAME],
  [o.KEYGEN, u.KEYGEN],
  [o.LABEL, u.LABEL],
  [o.LI, u.LI],
  [o.LINK, u.LINK],
  [o.LISTING, u.LISTING],
  [o.MAIN, u.MAIN],
  [o.MALIGNMARK, u.MALIGNMARK],
  [o.MARQUEE, u.MARQUEE],
  [o.MATH, u.MATH],
  [o.MENU, u.MENU],
  [o.META, u.META],
  [o.MGLYPH, u.MGLYPH],
  [o.MI, u.MI],
  [o.MO, u.MO],
  [o.MN, u.MN],
  [o.MS, u.MS],
  [o.MTEXT, u.MTEXT],
  [o.NAV, u.NAV],
  [o.NOBR, u.NOBR],
  [o.NOFRAMES, u.NOFRAMES],
  [o.NOEMBED, u.NOEMBED],
  [o.NOSCRIPT, u.NOSCRIPT],
  [o.OBJECT, u.OBJECT],
  [o.OL, u.OL],
  [o.OPTGROUP, u.OPTGROUP],
  [o.OPTION, u.OPTION],
  [o.P, u.P],
  [o.PARAM, u.PARAM],
  [o.PLAINTEXT, u.PLAINTEXT],
  [o.PRE, u.PRE],
  [o.RB, u.RB],
  [o.RP, u.RP],
  [o.RT, u.RT],
  [o.RTC, u.RTC],
  [o.RUBY, u.RUBY],
  [o.S, u.S],
  [o.SCRIPT, u.SCRIPT],
  [o.SEARCH, u.SEARCH],
  [o.SECTION, u.SECTION],
  [o.SELECT, u.SELECT],
  [o.SOURCE, u.SOURCE],
  [o.SMALL, u.SMALL],
  [o.SPAN, u.SPAN],
  [o.STRIKE, u.STRIKE],
  [o.STRONG, u.STRONG],
  [o.STYLE, u.STYLE],
  [o.SUB, u.SUB],
  [o.SUMMARY, u.SUMMARY],
  [o.SUP, u.SUP],
  [o.TABLE, u.TABLE],
  [o.TBODY, u.TBODY],
  [o.TEMPLATE, u.TEMPLATE],
  [o.TEXTAREA, u.TEXTAREA],
  [o.TFOOT, u.TFOOT],
  [o.TD, u.TD],
  [o.TH, u.TH],
  [o.THEAD, u.THEAD],
  [o.TITLE, u.TITLE],
  [o.TR, u.TR],
  [o.TRACK, u.TRACK],
  [o.TT, u.TT],
  [o.U, u.U],
  [o.UL, u.UL],
  [o.SVG, u.SVG],
  [o.VAR, u.VAR],
  [o.WBR, u.WBR],
  [o.XMP, u.XMP]
]);
function v(e) {
  var t;
  return (t = Au.get(e)) !== null && t !== void 0 ? t : u.UNKNOWN;
}
const h = u, Nu = {
  [T.HTML]: /* @__PURE__ */ new Set([
    h.ADDRESS,
    h.APPLET,
    h.AREA,
    h.ARTICLE,
    h.ASIDE,
    h.BASE,
    h.BASEFONT,
    h.BGSOUND,
    h.BLOCKQUOTE,
    h.BODY,
    h.BR,
    h.BUTTON,
    h.CAPTION,
    h.CENTER,
    h.COL,
    h.COLGROUP,
    h.DD,
    h.DETAILS,
    h.DIR,
    h.DIV,
    h.DL,
    h.DT,
    h.EMBED,
    h.FIELDSET,
    h.FIGCAPTION,
    h.FIGURE,
    h.FOOTER,
    h.FORM,
    h.FRAME,
    h.FRAMESET,
    h.H1,
    h.H2,
    h.H3,
    h.H4,
    h.H5,
    h.H6,
    h.HEAD,
    h.HEADER,
    h.HGROUP,
    h.HR,
    h.HTML,
    h.IFRAME,
    h.IMG,
    h.INPUT,
    h.LI,
    h.LINK,
    h.LISTING,
    h.MAIN,
    h.MARQUEE,
    h.MENU,
    h.META,
    h.NAV,
    h.NOEMBED,
    h.NOFRAMES,
    h.NOSCRIPT,
    h.OBJECT,
    h.OL,
    h.P,
    h.PARAM,
    h.PLAINTEXT,
    h.PRE,
    h.SCRIPT,
    h.SECTION,
    h.SELECT,
    h.SOURCE,
    h.STYLE,
    h.SUMMARY,
    h.TABLE,
    h.TBODY,
    h.TD,
    h.TEMPLATE,
    h.TEXTAREA,
    h.TFOOT,
    h.TH,
    h.THEAD,
    h.TITLE,
    h.TR,
    h.TRACK,
    h.UL,
    h.WBR,
    h.XMP
  ]),
  [T.MATHML]: /* @__PURE__ */ new Set([h.MI, h.MO, h.MN, h.MS, h.MTEXT, h.ANNOTATION_XML]),
  [T.SVG]: /* @__PURE__ */ new Set([h.TITLE, h.FOREIGN_OBJECT, h.DESC]),
  [T.XLINK]: /* @__PURE__ */ new Set(),
  [T.XML]: /* @__PURE__ */ new Set(),
  [T.XMLNS]: /* @__PURE__ */ new Set()
}, _e = /* @__PURE__ */ new Set([h.H1, h.H2, h.H3, h.H4, h.H5, h.H6]);
o.STYLE, o.SCRIPT, o.XMP, o.IFRAME, o.NOEMBED, o.NOFRAMES, o.PLAINTEXT;
var n;
(function(e) {
  e[e.DATA = 0] = "DATA", e[e.RCDATA = 1] = "RCDATA", e[e.RAWTEXT = 2] = "RAWTEXT", e[e.SCRIPT_DATA = 3] = "SCRIPT_DATA", e[e.PLAINTEXT = 4] = "PLAINTEXT", e[e.TAG_OPEN = 5] = "TAG_OPEN", e[e.END_TAG_OPEN = 6] = "END_TAG_OPEN", e[e.TAG_NAME = 7] = "TAG_NAME", e[e.RCDATA_LESS_THAN_SIGN = 8] = "RCDATA_LESS_THAN_SIGN", e[e.RCDATA_END_TAG_OPEN = 9] = "RCDATA_END_TAG_OPEN", e[e.RCDATA_END_TAG_NAME = 10] = "RCDATA_END_TAG_NAME", e[e.RAWTEXT_LESS_THAN_SIGN = 11] = "RAWTEXT_LESS_THAN_SIGN", e[e.RAWTEXT_END_TAG_OPEN = 12] = "RAWTEXT_END_TAG_OPEN", e[e.RAWTEXT_END_TAG_NAME = 13] = "RAWTEXT_END_TAG_NAME", e[e.SCRIPT_DATA_LESS_THAN_SIGN = 14] = "SCRIPT_DATA_LESS_THAN_SIGN", e[e.SCRIPT_DATA_END_TAG_OPEN = 15] = "SCRIPT_DATA_END_TAG_OPEN", e[e.SCRIPT_DATA_END_TAG_NAME = 16] = "SCRIPT_DATA_END_TAG_NAME", e[e.SCRIPT_DATA_ESCAPE_START = 17] = "SCRIPT_DATA_ESCAPE_START", e[e.SCRIPT_DATA_ESCAPE_START_DASH = 18] = "SCRIPT_DATA_ESCAPE_START_DASH", e[e.SCRIPT_DATA_ESCAPED = 19] = "SCRIPT_DATA_ESCAPED", e[e.SCRIPT_DATA_ESCAPED_DASH = 20] = "SCRIPT_DATA_ESCAPED_DASH", e[e.SCRIPT_DATA_ESCAPED_DASH_DASH = 21] = "SCRIPT_DATA_ESCAPED_DASH_DASH", e[e.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN = 22] = "SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN", e[e.SCRIPT_DATA_ESCAPED_END_TAG_OPEN = 23] = "SCRIPT_DATA_ESCAPED_END_TAG_OPEN", e[e.SCRIPT_DATA_ESCAPED_END_TAG_NAME = 24] = "SCRIPT_DATA_ESCAPED_END_TAG_NAME", e[e.SCRIPT_DATA_DOUBLE_ESCAPE_START = 25] = "SCRIPT_DATA_DOUBLE_ESCAPE_START", e[e.SCRIPT_DATA_DOUBLE_ESCAPED = 26] = "SCRIPT_DATA_DOUBLE_ESCAPED", e[e.SCRIPT_DATA_DOUBLE_ESCAPED_DASH = 27] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH", e[e.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH = 28] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH", e[e.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN = 29] = "SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN", e[e.SCRIPT_DATA_DOUBLE_ESCAPE_END = 30] = "SCRIPT_DATA_DOUBLE_ESCAPE_END", e[e.BEFORE_ATTRIBUTE_NAME = 31] = "BEFORE_ATTRIBUTE_NAME", e[e.ATTRIBUTE_NAME = 32] = "ATTRIBUTE_NAME", e[e.AFTER_ATTRIBUTE_NAME = 33] = "AFTER_ATTRIBUTE_NAME", e[e.BEFORE_ATTRIBUTE_VALUE = 34] = "BEFORE_ATTRIBUTE_VALUE", e[e.ATTRIBUTE_VALUE_DOUBLE_QUOTED = 35] = "ATTRIBUTE_VALUE_DOUBLE_QUOTED", e[e.ATTRIBUTE_VALUE_SINGLE_QUOTED = 36] = "ATTRIBUTE_VALUE_SINGLE_QUOTED", e[e.ATTRIBUTE_VALUE_UNQUOTED = 37] = "ATTRIBUTE_VALUE_UNQUOTED", e[e.AFTER_ATTRIBUTE_VALUE_QUOTED = 38] = "AFTER_ATTRIBUTE_VALUE_QUOTED", e[e.SELF_CLOSING_START_TAG = 39] = "SELF_CLOSING_START_TAG", e[e.BOGUS_COMMENT = 40] = "BOGUS_COMMENT", e[e.MARKUP_DECLARATION_OPEN = 41] = "MARKUP_DECLARATION_OPEN", e[e.COMMENT_START = 42] = "COMMENT_START", e[e.COMMENT_START_DASH = 43] = "COMMENT_START_DASH", e[e.COMMENT = 44] = "COMMENT", e[e.COMMENT_LESS_THAN_SIGN = 45] = "COMMENT_LESS_THAN_SIGN", e[e.COMMENT_LESS_THAN_SIGN_BANG = 46] = "COMMENT_LESS_THAN_SIGN_BANG", e[e.COMMENT_LESS_THAN_SIGN_BANG_DASH = 47] = "COMMENT_LESS_THAN_SIGN_BANG_DASH", e[e.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH = 48] = "COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH", e[e.COMMENT_END_DASH = 49] = "COMMENT_END_DASH", e[e.COMMENT_END = 50] = "COMMENT_END", e[e.COMMENT_END_BANG = 51] = "COMMENT_END_BANG", e[e.DOCTYPE = 52] = "DOCTYPE", e[e.BEFORE_DOCTYPE_NAME = 53] = "BEFORE_DOCTYPE_NAME", e[e.DOCTYPE_NAME = 54] = "DOCTYPE_NAME", e[e.AFTER_DOCTYPE_NAME = 55] = "AFTER_DOCTYPE_NAME", e[e.AFTER_DOCTYPE_PUBLIC_KEYWORD = 56] = "AFTER_DOCTYPE_PUBLIC_KEYWORD", e[e.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER = 57] = "BEFORE_DOCTYPE_PUBLIC_IDENTIFIER", e[e.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED = 58] = "DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED", e[e.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED = 59] = "DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED", e[e.AFTER_DOCTYPE_PUBLIC_IDENTIFIER = 60] = "AFTER_DOCTYPE_PUBLIC_IDENTIFIER", e[e.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS = 61] = "BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS", e[e.AFTER_DOCTYPE_SYSTEM_KEYWORD = 62] = "AFTER_DOCTYPE_SYSTEM_KEYWORD", e[e.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER = 63] = "BEFORE_DOCTYPE_SYSTEM_IDENTIFIER", e[e.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED = 64] = "DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED", e[e.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED = 65] = "DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED", e[e.AFTER_DOCTYPE_SYSTEM_IDENTIFIER = 66] = "AFTER_DOCTYPE_SYSTEM_IDENTIFIER", e[e.BOGUS_DOCTYPE = 67] = "BOGUS_DOCTYPE", e[e.CDATA_SECTION = 68] = "CDATA_SECTION", e[e.CDATA_SECTION_BRACKET = 69] = "CDATA_SECTION_BRACKET", e[e.CDATA_SECTION_END = 70] = "CDATA_SECTION_END", e[e.CHARACTER_REFERENCE = 71] = "CHARACTER_REFERENCE", e[e.AMBIGUOUS_AMPERSAND = 72] = "AMBIGUOUS_AMPERSAND";
})(n || (n = {}));
const N = {
  DATA: n.DATA,
  RCDATA: n.RCDATA,
  RAWTEXT: n.RAWTEXT,
  SCRIPT_DATA: n.SCRIPT_DATA,
  PLAINTEXT: n.PLAINTEXT,
  CDATA_SECTION: n.CDATA_SECTION
};
function Iu(e) {
  return e >= r.DIGIT_0 && e <= r.DIGIT_9;
}
function q(e) {
  return e >= r.LATIN_CAPITAL_A && e <= r.LATIN_CAPITAL_Z;
}
function Cu(e) {
  return e >= r.LATIN_SMALL_A && e <= r.LATIN_SMALL_Z;
}
function P(e) {
  return Cu(e) || q(e);
}
function He(e) {
  return P(e) || Iu(e);
}
function te(e) {
  return e + 32;
}
function st(e) {
  return e === r.SPACE || e === r.LINE_FEED || e === r.TABULATION || e === r.FORM_FEED;
}
function Fe(e) {
  return st(e) || e === r.SOLIDUS || e === r.GREATER_THAN_SIGN;
}
function pu(e) {
  return e === r.NULL ? E.nullCharacterReference : e > 1114111 ? E.characterReferenceOutsideUnicodeRange : et(e) ? E.surrogateCharacterReference : ut(e) ? E.noncharacterCharacterReference : tt(e) || e === r.CARRIAGE_RETURN ? E.controlCharacterReference : null;
}
class Ou {
  constructor(t, a) {
    this.options = t, this.handler = a, this.paused = !1, this.inLoop = !1, this.inForeignNode = !1, this.lastStartTagName = "", this.active = !1, this.state = n.DATA, this.returnState = n.DATA, this.entityStartPos = 0, this.consumedAfterSnapshot = -1, this.currentCharacterToken = null, this.currentToken = null, this.currentAttr = { name: "", value: "" }, this.preprocessor = new ou(a), this.currentLocation = this.getCurrentLocation(-1), this.entityDecoder = new _u(du, (s, c) => {
      this.preprocessor.pos = this.entityStartPos + c - 1, this._flushCodePointConsumedAsCharacterReference(s);
    }, a.onParseError ? {
      missingSemicolonAfterCharacterReference: () => {
        this._err(E.missingSemicolonAfterCharacterReference, 1);
      },
      absenceOfDigitsInNumericCharacterReference: (s) => {
        this._err(E.absenceOfDigitsInNumericCharacterReference, this.entityStartPos - this.preprocessor.pos + s);
      },
      validateNumericCharacterReference: (s) => {
        const c = pu(s);
        c && this._err(c, 1);
      }
    } : void 0);
  }
  //Errors
  _err(t, a = 0) {
    var s, c;
    (c = (s = this.handler).onParseError) === null || c === void 0 || c.call(s, this.preprocessor.getError(t, a));
  }
  // NOTE: `offset` may never run across line boundaries.
  getCurrentLocation(t) {
    return this.options.sourceCodeLocationInfo ? {
      startLine: this.preprocessor.line,
      startCol: this.preprocessor.col - t,
      startOffset: this.preprocessor.offset - t,
      endLine: -1,
      endCol: -1,
      endOffset: -1
    } : null;
  }
  _runParsingLoop() {
    if (!this.inLoop) {
      for (this.inLoop = !0; this.active && !this.paused; ) {
        this.consumedAfterSnapshot = 0;
        const t = this._consume();
        this._ensureHibernation() || this._callState(t);
      }
      this.inLoop = !1;
    }
  }
  //API
  pause() {
    this.paused = !0;
  }
  resume(t) {
    if (!this.paused)
      throw new Error("Parser was already resumed");
    this.paused = !1, !this.inLoop && (this._runParsingLoop(), this.paused || t == null || t());
  }
  write(t, a, s) {
    this.active = !0, this.preprocessor.write(t, a), this._runParsingLoop(), this.paused || s == null || s();
  }
  insertHtmlAtCurrentPos(t) {
    this.active = !0, this.preprocessor.insertHtmlAtCurrentPos(t), this._runParsingLoop();
  }
  //Hibernation
  _ensureHibernation() {
    return this.preprocessor.endOfChunkHit ? (this.preprocessor.retreat(this.consumedAfterSnapshot), this.consumedAfterSnapshot = 0, this.active = !1, !0) : !1;
  }
  //Consumption
  _consume() {
    return this.consumedAfterSnapshot++, this.preprocessor.advance();
  }
  _advanceBy(t) {
    this.consumedAfterSnapshot += t;
    for (let a = 0; a < t; a++)
      this.preprocessor.advance();
  }
  _consumeSequenceIfMatch(t, a) {
    return this.preprocessor.startsWith(t, a) ? (this._advanceBy(t.length - 1), !0) : !1;
  }
  //Token creation
  _createStartTagToken() {
    this.currentToken = {
      type: _.START_TAG,
      tagName: "",
      tagID: u.UNKNOWN,
      selfClosing: !1,
      ackSelfClosing: !1,
      attrs: [],
      location: this.getCurrentLocation(1)
    };
  }
  _createEndTagToken() {
    this.currentToken = {
      type: _.END_TAG,
      tagName: "",
      tagID: u.UNKNOWN,
      selfClosing: !1,
      ackSelfClosing: !1,
      attrs: [],
      location: this.getCurrentLocation(2)
    };
  }
  _createCommentToken(t) {
    this.currentToken = {
      type: _.COMMENT,
      data: "",
      location: this.getCurrentLocation(t)
    };
  }
  _createDoctypeToken(t) {
    this.currentToken = {
      type: _.DOCTYPE,
      name: t,
      forceQuirks: !1,
      publicId: null,
      systemId: null,
      location: this.currentLocation
    };
  }
  _createCharacterToken(t, a) {
    this.currentCharacterToken = {
      type: t,
      chars: a,
      location: this.currentLocation
    };
  }
  //Tag attributes
  _createAttr(t) {
    this.currentAttr = {
      name: t,
      value: ""
    }, this.currentLocation = this.getCurrentLocation(0);
  }
  _leaveAttrName() {
    var t, a;
    const s = this.currentToken;
    if (at(s, this.currentAttr.name) === null) {
      if (s.attrs.push(this.currentAttr), s.location && this.currentLocation) {
        const c = (t = (a = s.location).attrs) !== null && t !== void 0 ? t : a.attrs = /* @__PURE__ */ Object.create(null);
        c[this.currentAttr.name] = this.currentLocation, this._leaveAttrValue();
      }
    } else
      this._err(E.duplicateAttribute);
  }
  _leaveAttrValue() {
    this.currentLocation && (this.currentLocation.endLine = this.preprocessor.line, this.currentLocation.endCol = this.preprocessor.col, this.currentLocation.endOffset = this.preprocessor.offset);
  }
  //Token emission
  prepareToken(t) {
    this._emitCurrentCharacterToken(t.location), this.currentToken = null, t.location && (t.location.endLine = this.preprocessor.line, t.location.endCol = this.preprocessor.col + 1, t.location.endOffset = this.preprocessor.offset + 1), this.currentLocation = this.getCurrentLocation(-1);
  }
  emitCurrentTagToken() {
    const t = this.currentToken;
    this.prepareToken(t), t.tagID = v(t.tagName), t.type === _.START_TAG ? (this.lastStartTagName = t.tagName, this.handler.onStartTag(t)) : (t.attrs.length > 0 && this._err(E.endTagWithAttributes), t.selfClosing && this._err(E.endTagWithTrailingSolidus), this.handler.onEndTag(t)), this.preprocessor.dropParsedChunk();
  }
  emitCurrentComment(t) {
    this.prepareToken(t), this.handler.onComment(t), this.preprocessor.dropParsedChunk();
  }
  emitCurrentDoctype(t) {
    this.prepareToken(t), this.handler.onDoctype(t), this.preprocessor.dropParsedChunk();
  }
  _emitCurrentCharacterToken(t) {
    if (this.currentCharacterToken) {
      switch (t && this.currentCharacterToken.location && (this.currentCharacterToken.location.endLine = t.startLine, this.currentCharacterToken.location.endCol = t.startCol, this.currentCharacterToken.location.endOffset = t.startOffset), this.currentCharacterToken.type) {
        case _.CHARACTER: {
          this.handler.onCharacter(this.currentCharacterToken);
          break;
        }
        case _.NULL_CHARACTER: {
          this.handler.onNullCharacter(this.currentCharacterToken);
          break;
        }
        case _.WHITESPACE_CHARACTER: {
          this.handler.onWhitespaceCharacter(this.currentCharacterToken);
          break;
        }
      }
      this.currentCharacterToken = null;
    }
  }
  _emitEOFToken() {
    const t = this.getCurrentLocation(0);
    t && (t.endLine = t.startLine, t.endCol = t.startCol, t.endOffset = t.startOffset), this._emitCurrentCharacterToken(t), this.handler.onEof({ type: _.EOF, location: t }), this.active = !1;
  }
  //Characters emission
  //OPTIMIZATION: The specification uses only one type of character token (one token per character).
  //This causes a huge memory overhead and a lot of unnecessary parser loops. parse5 uses 3 groups of characters.
  //If we have a sequence of characters that belong to the same group, the parser can process it
  //as a single solid character token.
  //So, there are 3 types of character tokens in parse5:
  //1)TokenType.NULL_CHARACTER - \u0000-character sequences (e.g. '\u0000\u0000\u0000')
  //2)TokenType.WHITESPACE_CHARACTER - any whitespace/new-line character sequences (e.g. '\n  \r\t   \f')
  //3)TokenType.CHARACTER - any character sequence which don't belong to groups 1 and 2 (e.g. 'abcdef1234@@#$%^')
  _appendCharToCurrentCharacterToken(t, a) {
    if (this.currentCharacterToken)
      if (this.currentCharacterToken.type === t) {
        this.currentCharacterToken.chars += a;
        return;
      } else
        this.currentLocation = this.getCurrentLocation(0), this._emitCurrentCharacterToken(this.currentLocation), this.preprocessor.dropParsedChunk();
    this._createCharacterToken(t, a);
  }
  _emitCodePoint(t) {
    const a = st(t) ? _.WHITESPACE_CHARACTER : t === r.NULL ? _.NULL_CHARACTER : _.CHARACTER;
    this._appendCharToCurrentCharacterToken(a, String.fromCodePoint(t));
  }
  //NOTE: used when we emit characters explicitly.
  //This is always for non-whitespace and non-null characters, which allows us to avoid additional checks.
  _emitChars(t) {
    this._appendCharToCurrentCharacterToken(_.CHARACTER, t);
  }
  // Character reference helpers
  _startCharacterReference() {
    this.returnState = this.state, this.state = n.CHARACTER_REFERENCE, this.entityStartPos = this.preprocessor.pos, this.entityDecoder.startEntity(this._isCharacterReferenceInAttribute() ? D.Attribute : D.Legacy);
  }
  _isCharacterReferenceInAttribute() {
    return this.returnState === n.ATTRIBUTE_VALUE_DOUBLE_QUOTED || this.returnState === n.ATTRIBUTE_VALUE_SINGLE_QUOTED || this.returnState === n.ATTRIBUTE_VALUE_UNQUOTED;
  }
  _flushCodePointConsumedAsCharacterReference(t) {
    this._isCharacterReferenceInAttribute() ? this.currentAttr.value += String.fromCodePoint(t) : this._emitCodePoint(t);
  }
  // Calling states this way turns out to be much faster than any other approach.
  _callState(t) {
    switch (this.state) {
      case n.DATA: {
        this._stateData(t);
        break;
      }
      case n.RCDATA: {
        this._stateRcdata(t);
        break;
      }
      case n.RAWTEXT: {
        this._stateRawtext(t);
        break;
      }
      case n.SCRIPT_DATA: {
        this._stateScriptData(t);
        break;
      }
      case n.PLAINTEXT: {
        this._statePlaintext(t);
        break;
      }
      case n.TAG_OPEN: {
        this._stateTagOpen(t);
        break;
      }
      case n.END_TAG_OPEN: {
        this._stateEndTagOpen(t);
        break;
      }
      case n.TAG_NAME: {
        this._stateTagName(t);
        break;
      }
      case n.RCDATA_LESS_THAN_SIGN: {
        this._stateRcdataLessThanSign(t);
        break;
      }
      case n.RCDATA_END_TAG_OPEN: {
        this._stateRcdataEndTagOpen(t);
        break;
      }
      case n.RCDATA_END_TAG_NAME: {
        this._stateRcdataEndTagName(t);
        break;
      }
      case n.RAWTEXT_LESS_THAN_SIGN: {
        this._stateRawtextLessThanSign(t);
        break;
      }
      case n.RAWTEXT_END_TAG_OPEN: {
        this._stateRawtextEndTagOpen(t);
        break;
      }
      case n.RAWTEXT_END_TAG_NAME: {
        this._stateRawtextEndTagName(t);
        break;
      }
      case n.SCRIPT_DATA_LESS_THAN_SIGN: {
        this._stateScriptDataLessThanSign(t);
        break;
      }
      case n.SCRIPT_DATA_END_TAG_OPEN: {
        this._stateScriptDataEndTagOpen(t);
        break;
      }
      case n.SCRIPT_DATA_END_TAG_NAME: {
        this._stateScriptDataEndTagName(t);
        break;
      }
      case n.SCRIPT_DATA_ESCAPE_START: {
        this._stateScriptDataEscapeStart(t);
        break;
      }
      case n.SCRIPT_DATA_ESCAPE_START_DASH: {
        this._stateScriptDataEscapeStartDash(t);
        break;
      }
      case n.SCRIPT_DATA_ESCAPED: {
        this._stateScriptDataEscaped(t);
        break;
      }
      case n.SCRIPT_DATA_ESCAPED_DASH: {
        this._stateScriptDataEscapedDash(t);
        break;
      }
      case n.SCRIPT_DATA_ESCAPED_DASH_DASH: {
        this._stateScriptDataEscapedDashDash(t);
        break;
      }
      case n.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN: {
        this._stateScriptDataEscapedLessThanSign(t);
        break;
      }
      case n.SCRIPT_DATA_ESCAPED_END_TAG_OPEN: {
        this._stateScriptDataEscapedEndTagOpen(t);
        break;
      }
      case n.SCRIPT_DATA_ESCAPED_END_TAG_NAME: {
        this._stateScriptDataEscapedEndTagName(t);
        break;
      }
      case n.SCRIPT_DATA_DOUBLE_ESCAPE_START: {
        this._stateScriptDataDoubleEscapeStart(t);
        break;
      }
      case n.SCRIPT_DATA_DOUBLE_ESCAPED: {
        this._stateScriptDataDoubleEscaped(t);
        break;
      }
      case n.SCRIPT_DATA_DOUBLE_ESCAPED_DASH: {
        this._stateScriptDataDoubleEscapedDash(t);
        break;
      }
      case n.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH: {
        this._stateScriptDataDoubleEscapedDashDash(t);
        break;
      }
      case n.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN: {
        this._stateScriptDataDoubleEscapedLessThanSign(t);
        break;
      }
      case n.SCRIPT_DATA_DOUBLE_ESCAPE_END: {
        this._stateScriptDataDoubleEscapeEnd(t);
        break;
      }
      case n.BEFORE_ATTRIBUTE_NAME: {
        this._stateBeforeAttributeName(t);
        break;
      }
      case n.ATTRIBUTE_NAME: {
        this._stateAttributeName(t);
        break;
      }
      case n.AFTER_ATTRIBUTE_NAME: {
        this._stateAfterAttributeName(t);
        break;
      }
      case n.BEFORE_ATTRIBUTE_VALUE: {
        this._stateBeforeAttributeValue(t);
        break;
      }
      case n.ATTRIBUTE_VALUE_DOUBLE_QUOTED: {
        this._stateAttributeValueDoubleQuoted(t);
        break;
      }
      case n.ATTRIBUTE_VALUE_SINGLE_QUOTED: {
        this._stateAttributeValueSingleQuoted(t);
        break;
      }
      case n.ATTRIBUTE_VALUE_UNQUOTED: {
        this._stateAttributeValueUnquoted(t);
        break;
      }
      case n.AFTER_ATTRIBUTE_VALUE_QUOTED: {
        this._stateAfterAttributeValueQuoted(t);
        break;
      }
      case n.SELF_CLOSING_START_TAG: {
        this._stateSelfClosingStartTag(t);
        break;
      }
      case n.BOGUS_COMMENT: {
        this._stateBogusComment(t);
        break;
      }
      case n.MARKUP_DECLARATION_OPEN: {
        this._stateMarkupDeclarationOpen(t);
        break;
      }
      case n.COMMENT_START: {
        this._stateCommentStart(t);
        break;
      }
      case n.COMMENT_START_DASH: {
        this._stateCommentStartDash(t);
        break;
      }
      case n.COMMENT: {
        this._stateComment(t);
        break;
      }
      case n.COMMENT_LESS_THAN_SIGN: {
        this._stateCommentLessThanSign(t);
        break;
      }
      case n.COMMENT_LESS_THAN_SIGN_BANG: {
        this._stateCommentLessThanSignBang(t);
        break;
      }
      case n.COMMENT_LESS_THAN_SIGN_BANG_DASH: {
        this._stateCommentLessThanSignBangDash(t);
        break;
      }
      case n.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH: {
        this._stateCommentLessThanSignBangDashDash(t);
        break;
      }
      case n.COMMENT_END_DASH: {
        this._stateCommentEndDash(t);
        break;
      }
      case n.COMMENT_END: {
        this._stateCommentEnd(t);
        break;
      }
      case n.COMMENT_END_BANG: {
        this._stateCommentEndBang(t);
        break;
      }
      case n.DOCTYPE: {
        this._stateDoctype(t);
        break;
      }
      case n.BEFORE_DOCTYPE_NAME: {
        this._stateBeforeDoctypeName(t);
        break;
      }
      case n.DOCTYPE_NAME: {
        this._stateDoctypeName(t);
        break;
      }
      case n.AFTER_DOCTYPE_NAME: {
        this._stateAfterDoctypeName(t);
        break;
      }
      case n.AFTER_DOCTYPE_PUBLIC_KEYWORD: {
        this._stateAfterDoctypePublicKeyword(t);
        break;
      }
      case n.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER: {
        this._stateBeforeDoctypePublicIdentifier(t);
        break;
      }
      case n.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED: {
        this._stateDoctypePublicIdentifierDoubleQuoted(t);
        break;
      }
      case n.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED: {
        this._stateDoctypePublicIdentifierSingleQuoted(t);
        break;
      }
      case n.AFTER_DOCTYPE_PUBLIC_IDENTIFIER: {
        this._stateAfterDoctypePublicIdentifier(t);
        break;
      }
      case n.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS: {
        this._stateBetweenDoctypePublicAndSystemIdentifiers(t);
        break;
      }
      case n.AFTER_DOCTYPE_SYSTEM_KEYWORD: {
        this._stateAfterDoctypeSystemKeyword(t);
        break;
      }
      case n.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER: {
        this._stateBeforeDoctypeSystemIdentifier(t);
        break;
      }
      case n.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED: {
        this._stateDoctypeSystemIdentifierDoubleQuoted(t);
        break;
      }
      case n.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED: {
        this._stateDoctypeSystemIdentifierSingleQuoted(t);
        break;
      }
      case n.AFTER_DOCTYPE_SYSTEM_IDENTIFIER: {
        this._stateAfterDoctypeSystemIdentifier(t);
        break;
      }
      case n.BOGUS_DOCTYPE: {
        this._stateBogusDoctype(t);
        break;
      }
      case n.CDATA_SECTION: {
        this._stateCdataSection(t);
        break;
      }
      case n.CDATA_SECTION_BRACKET: {
        this._stateCdataSectionBracket(t);
        break;
      }
      case n.CDATA_SECTION_END: {
        this._stateCdataSectionEnd(t);
        break;
      }
      case n.CHARACTER_REFERENCE: {
        this._stateCharacterReference();
        break;
      }
      case n.AMBIGUOUS_AMPERSAND: {
        this._stateAmbiguousAmpersand(t);
        break;
      }
      default:
        throw new Error("Unknown state");
    }
  }
  // State machine
  // Data state
  //------------------------------------------------------------------
  _stateData(t) {
    switch (t) {
      case r.LESS_THAN_SIGN: {
        this.state = n.TAG_OPEN;
        break;
      }
      case r.AMPERSAND: {
        this._startCharacterReference();
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), this._emitCodePoint(t);
        break;
      }
      case r.EOF: {
        this._emitEOFToken();
        break;
      }
      default:
        this._emitCodePoint(t);
    }
  }
  //  RCDATA state
  //------------------------------------------------------------------
  _stateRcdata(t) {
    switch (t) {
      case r.AMPERSAND: {
        this._startCharacterReference();
        break;
      }
      case r.LESS_THAN_SIGN: {
        this.state = n.RCDATA_LESS_THAN_SIGN;
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._emitEOFToken();
        break;
      }
      default:
        this._emitCodePoint(t);
    }
  }
  // RAWTEXT state
  //------------------------------------------------------------------
  _stateRawtext(t) {
    switch (t) {
      case r.LESS_THAN_SIGN: {
        this.state = n.RAWTEXT_LESS_THAN_SIGN;
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._emitEOFToken();
        break;
      }
      default:
        this._emitCodePoint(t);
    }
  }
  // Script data state
  //------------------------------------------------------------------
  _stateScriptData(t) {
    switch (t) {
      case r.LESS_THAN_SIGN: {
        this.state = n.SCRIPT_DATA_LESS_THAN_SIGN;
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._emitEOFToken();
        break;
      }
      default:
        this._emitCodePoint(t);
    }
  }
  // PLAINTEXT state
  //------------------------------------------------------------------
  _statePlaintext(t) {
    switch (t) {
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._emitEOFToken();
        break;
      }
      default:
        this._emitCodePoint(t);
    }
  }
  // Tag open state
  //------------------------------------------------------------------
  _stateTagOpen(t) {
    if (P(t))
      this._createStartTagToken(), this.state = n.TAG_NAME, this._stateTagName(t);
    else
      switch (t) {
        case r.EXCLAMATION_MARK: {
          this.state = n.MARKUP_DECLARATION_OPEN;
          break;
        }
        case r.SOLIDUS: {
          this.state = n.END_TAG_OPEN;
          break;
        }
        case r.QUESTION_MARK: {
          this._err(E.unexpectedQuestionMarkInsteadOfTagName), this._createCommentToken(1), this.state = n.BOGUS_COMMENT, this._stateBogusComment(t);
          break;
        }
        case r.EOF: {
          this._err(E.eofBeforeTagName), this._emitChars("<"), this._emitEOFToken();
          break;
        }
        default:
          this._err(E.invalidFirstCharacterOfTagName), this._emitChars("<"), this.state = n.DATA, this._stateData(t);
      }
  }
  // End tag open state
  //------------------------------------------------------------------
  _stateEndTagOpen(t) {
    if (P(t))
      this._createEndTagToken(), this.state = n.TAG_NAME, this._stateTagName(t);
    else
      switch (t) {
        case r.GREATER_THAN_SIGN: {
          this._err(E.missingEndTagName), this.state = n.DATA;
          break;
        }
        case r.EOF: {
          this._err(E.eofBeforeTagName), this._emitChars("</"), this._emitEOFToken();
          break;
        }
        default:
          this._err(E.invalidFirstCharacterOfTagName), this._createCommentToken(2), this.state = n.BOGUS_COMMENT, this._stateBogusComment(t);
      }
  }
  // Tag name state
  //------------------------------------------------------------------
  _stateTagName(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED: {
        this.state = n.BEFORE_ATTRIBUTE_NAME;
        break;
      }
      case r.SOLIDUS: {
        this.state = n.SELF_CLOSING_START_TAG;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this.state = n.DATA, this.emitCurrentTagToken();
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), a.tagName += A;
        break;
      }
      case r.EOF: {
        this._err(E.eofInTag), this._emitEOFToken();
        break;
      }
      default:
        a.tagName += String.fromCodePoint(q(t) ? te(t) : t);
    }
  }
  // RCDATA less-than sign state
  //------------------------------------------------------------------
  _stateRcdataLessThanSign(t) {
    t === r.SOLIDUS ? this.state = n.RCDATA_END_TAG_OPEN : (this._emitChars("<"), this.state = n.RCDATA, this._stateRcdata(t));
  }
  // RCDATA end tag open state
  //------------------------------------------------------------------
  _stateRcdataEndTagOpen(t) {
    P(t) ? (this.state = n.RCDATA_END_TAG_NAME, this._stateRcdataEndTagName(t)) : (this._emitChars("</"), this.state = n.RCDATA, this._stateRcdata(t));
  }
  handleSpecialEndTag(t) {
    if (!this.preprocessor.startsWith(this.lastStartTagName, !1))
      return !this._ensureHibernation();
    this._createEndTagToken();
    const a = this.currentToken;
    switch (a.tagName = this.lastStartTagName, this.preprocessor.peek(this.lastStartTagName.length)) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
        return this._advanceBy(this.lastStartTagName.length), this.state = n.BEFORE_ATTRIBUTE_NAME, !1;
      case r.SOLIDUS:
        return this._advanceBy(this.lastStartTagName.length), this.state = n.SELF_CLOSING_START_TAG, !1;
      case r.GREATER_THAN_SIGN:
        return this._advanceBy(this.lastStartTagName.length), this.emitCurrentTagToken(), this.state = n.DATA, !1;
      default:
        return !this._ensureHibernation();
    }
  }
  // RCDATA end tag name state
  //------------------------------------------------------------------
  _stateRcdataEndTagName(t) {
    this.handleSpecialEndTag(t) && (this._emitChars("</"), this.state = n.RCDATA, this._stateRcdata(t));
  }
  // RAWTEXT less-than sign state
  //------------------------------------------------------------------
  _stateRawtextLessThanSign(t) {
    t === r.SOLIDUS ? this.state = n.RAWTEXT_END_TAG_OPEN : (this._emitChars("<"), this.state = n.RAWTEXT, this._stateRawtext(t));
  }
  // RAWTEXT end tag open state
  //------------------------------------------------------------------
  _stateRawtextEndTagOpen(t) {
    P(t) ? (this.state = n.RAWTEXT_END_TAG_NAME, this._stateRawtextEndTagName(t)) : (this._emitChars("</"), this.state = n.RAWTEXT, this._stateRawtext(t));
  }
  // RAWTEXT end tag name state
  //------------------------------------------------------------------
  _stateRawtextEndTagName(t) {
    this.handleSpecialEndTag(t) && (this._emitChars("</"), this.state = n.RAWTEXT, this._stateRawtext(t));
  }
  // Script data less-than sign state
  //------------------------------------------------------------------
  _stateScriptDataLessThanSign(t) {
    switch (t) {
      case r.SOLIDUS: {
        this.state = n.SCRIPT_DATA_END_TAG_OPEN;
        break;
      }
      case r.EXCLAMATION_MARK: {
        this.state = n.SCRIPT_DATA_ESCAPE_START, this._emitChars("<!");
        break;
      }
      default:
        this._emitChars("<"), this.state = n.SCRIPT_DATA, this._stateScriptData(t);
    }
  }
  // Script data end tag open state
  //------------------------------------------------------------------
  _stateScriptDataEndTagOpen(t) {
    P(t) ? (this.state = n.SCRIPT_DATA_END_TAG_NAME, this._stateScriptDataEndTagName(t)) : (this._emitChars("</"), this.state = n.SCRIPT_DATA, this._stateScriptData(t));
  }
  // Script data end tag name state
  //------------------------------------------------------------------
  _stateScriptDataEndTagName(t) {
    this.handleSpecialEndTag(t) && (this._emitChars("</"), this.state = n.SCRIPT_DATA, this._stateScriptData(t));
  }
  // Script data escape start state
  //------------------------------------------------------------------
  _stateScriptDataEscapeStart(t) {
    t === r.HYPHEN_MINUS ? (this.state = n.SCRIPT_DATA_ESCAPE_START_DASH, this._emitChars("-")) : (this.state = n.SCRIPT_DATA, this._stateScriptData(t));
  }
  // Script data escape start dash state
  //------------------------------------------------------------------
  _stateScriptDataEscapeStartDash(t) {
    t === r.HYPHEN_MINUS ? (this.state = n.SCRIPT_DATA_ESCAPED_DASH_DASH, this._emitChars("-")) : (this.state = n.SCRIPT_DATA, this._stateScriptData(t));
  }
  // Script data escaped state
  //------------------------------------------------------------------
  _stateScriptDataEscaped(t) {
    switch (t) {
      case r.HYPHEN_MINUS: {
        this.state = n.SCRIPT_DATA_ESCAPED_DASH, this._emitChars("-");
        break;
      }
      case r.LESS_THAN_SIGN: {
        this.state = n.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._err(E.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
        break;
      }
      default:
        this._emitCodePoint(t);
    }
  }
  // Script data escaped dash state
  //------------------------------------------------------------------
  _stateScriptDataEscapedDash(t) {
    switch (t) {
      case r.HYPHEN_MINUS: {
        this.state = n.SCRIPT_DATA_ESCAPED_DASH_DASH, this._emitChars("-");
        break;
      }
      case r.LESS_THAN_SIGN: {
        this.state = n.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), this.state = n.SCRIPT_DATA_ESCAPED, this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._err(E.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
        break;
      }
      default:
        this.state = n.SCRIPT_DATA_ESCAPED, this._emitCodePoint(t);
    }
  }
  // Script data escaped dash dash state
  //------------------------------------------------------------------
  _stateScriptDataEscapedDashDash(t) {
    switch (t) {
      case r.HYPHEN_MINUS: {
        this._emitChars("-");
        break;
      }
      case r.LESS_THAN_SIGN: {
        this.state = n.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this.state = n.SCRIPT_DATA, this._emitChars(">");
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), this.state = n.SCRIPT_DATA_ESCAPED, this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._err(E.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
        break;
      }
      default:
        this.state = n.SCRIPT_DATA_ESCAPED, this._emitCodePoint(t);
    }
  }
  // Script data escaped less-than sign state
  //------------------------------------------------------------------
  _stateScriptDataEscapedLessThanSign(t) {
    t === r.SOLIDUS ? this.state = n.SCRIPT_DATA_ESCAPED_END_TAG_OPEN : P(t) ? (this._emitChars("<"), this.state = n.SCRIPT_DATA_DOUBLE_ESCAPE_START, this._stateScriptDataDoubleEscapeStart(t)) : (this._emitChars("<"), this.state = n.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(t));
  }
  // Script data escaped end tag open state
  //------------------------------------------------------------------
  _stateScriptDataEscapedEndTagOpen(t) {
    P(t) ? (this.state = n.SCRIPT_DATA_ESCAPED_END_TAG_NAME, this._stateScriptDataEscapedEndTagName(t)) : (this._emitChars("</"), this.state = n.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(t));
  }
  // Script data escaped end tag name state
  //------------------------------------------------------------------
  _stateScriptDataEscapedEndTagName(t) {
    this.handleSpecialEndTag(t) && (this._emitChars("</"), this.state = n.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(t));
  }
  // Script data double escape start state
  //------------------------------------------------------------------
  _stateScriptDataDoubleEscapeStart(t) {
    if (this.preprocessor.startsWith(O.SCRIPT, !1) && Fe(this.preprocessor.peek(O.SCRIPT.length))) {
      this._emitCodePoint(t);
      for (let a = 0; a < O.SCRIPT.length; a++)
        this._emitCodePoint(this._consume());
      this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED;
    } else this._ensureHibernation() || (this.state = n.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(t));
  }
  // Script data double escaped state
  //------------------------------------------------------------------
  _stateScriptDataDoubleEscaped(t) {
    switch (t) {
      case r.HYPHEN_MINUS: {
        this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED_DASH, this._emitChars("-");
        break;
      }
      case r.LESS_THAN_SIGN: {
        this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN, this._emitChars("<");
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._err(E.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
        break;
      }
      default:
        this._emitCodePoint(t);
    }
  }
  // Script data double escaped dash state
  //------------------------------------------------------------------
  _stateScriptDataDoubleEscapedDash(t) {
    switch (t) {
      case r.HYPHEN_MINUS: {
        this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH, this._emitChars("-");
        break;
      }
      case r.LESS_THAN_SIGN: {
        this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN, this._emitChars("<");
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._err(E.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
        break;
      }
      default:
        this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitCodePoint(t);
    }
  }
  // Script data double escaped dash dash state
  //------------------------------------------------------------------
  _stateScriptDataDoubleEscapedDashDash(t) {
    switch (t) {
      case r.HYPHEN_MINUS: {
        this._emitChars("-");
        break;
      }
      case r.LESS_THAN_SIGN: {
        this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN, this._emitChars("<");
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this.state = n.SCRIPT_DATA, this._emitChars(">");
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitChars(A);
        break;
      }
      case r.EOF: {
        this._err(E.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
        break;
      }
      default:
        this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitCodePoint(t);
    }
  }
  // Script data double escaped less-than sign state
  //------------------------------------------------------------------
  _stateScriptDataDoubleEscapedLessThanSign(t) {
    t === r.SOLIDUS ? (this.state = n.SCRIPT_DATA_DOUBLE_ESCAPE_END, this._emitChars("/")) : (this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED, this._stateScriptDataDoubleEscaped(t));
  }
  // Script data double escape end state
  //------------------------------------------------------------------
  _stateScriptDataDoubleEscapeEnd(t) {
    if (this.preprocessor.startsWith(O.SCRIPT, !1) && Fe(this.preprocessor.peek(O.SCRIPT.length))) {
      this._emitCodePoint(t);
      for (let a = 0; a < O.SCRIPT.length; a++)
        this._emitCodePoint(this._consume());
      this.state = n.SCRIPT_DATA_ESCAPED;
    } else this._ensureHibernation() || (this.state = n.SCRIPT_DATA_DOUBLE_ESCAPED, this._stateScriptDataDoubleEscaped(t));
  }
  // Before attribute name state
  //------------------------------------------------------------------
  _stateBeforeAttributeName(t) {
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
        break;
      case r.SOLIDUS:
      case r.GREATER_THAN_SIGN:
      case r.EOF: {
        this.state = n.AFTER_ATTRIBUTE_NAME, this._stateAfterAttributeName(t);
        break;
      }
      case r.EQUALS_SIGN: {
        this._err(E.unexpectedEqualsSignBeforeAttributeName), this._createAttr("="), this.state = n.ATTRIBUTE_NAME;
        break;
      }
      default:
        this._createAttr(""), this.state = n.ATTRIBUTE_NAME, this._stateAttributeName(t);
    }
  }
  // Attribute name state
  //------------------------------------------------------------------
  _stateAttributeName(t) {
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
      case r.SOLIDUS:
      case r.GREATER_THAN_SIGN:
      case r.EOF: {
        this._leaveAttrName(), this.state = n.AFTER_ATTRIBUTE_NAME, this._stateAfterAttributeName(t);
        break;
      }
      case r.EQUALS_SIGN: {
        this._leaveAttrName(), this.state = n.BEFORE_ATTRIBUTE_VALUE;
        break;
      }
      case r.QUOTATION_MARK:
      case r.APOSTROPHE:
      case r.LESS_THAN_SIGN: {
        this._err(E.unexpectedCharacterInAttributeName), this.currentAttr.name += String.fromCodePoint(t);
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), this.currentAttr.name += A;
        break;
      }
      default:
        this.currentAttr.name += String.fromCodePoint(q(t) ? te(t) : t);
    }
  }
  // After attribute name state
  //------------------------------------------------------------------
  _stateAfterAttributeName(t) {
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
        break;
      case r.SOLIDUS: {
        this.state = n.SELF_CLOSING_START_TAG;
        break;
      }
      case r.EQUALS_SIGN: {
        this.state = n.BEFORE_ATTRIBUTE_VALUE;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this.state = n.DATA, this.emitCurrentTagToken();
        break;
      }
      case r.EOF: {
        this._err(E.eofInTag), this._emitEOFToken();
        break;
      }
      default:
        this._createAttr(""), this.state = n.ATTRIBUTE_NAME, this._stateAttributeName(t);
    }
  }
  // Before attribute value state
  //------------------------------------------------------------------
  _stateBeforeAttributeValue(t) {
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
        break;
      case r.QUOTATION_MARK: {
        this.state = n.ATTRIBUTE_VALUE_DOUBLE_QUOTED;
        break;
      }
      case r.APOSTROPHE: {
        this.state = n.ATTRIBUTE_VALUE_SINGLE_QUOTED;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(E.missingAttributeValue), this.state = n.DATA, this.emitCurrentTagToken();
        break;
      }
      default:
        this.state = n.ATTRIBUTE_VALUE_UNQUOTED, this._stateAttributeValueUnquoted(t);
    }
  }
  // Attribute value (double-quoted) state
  //------------------------------------------------------------------
  _stateAttributeValueDoubleQuoted(t) {
    switch (t) {
      case r.QUOTATION_MARK: {
        this.state = n.AFTER_ATTRIBUTE_VALUE_QUOTED;
        break;
      }
      case r.AMPERSAND: {
        this._startCharacterReference();
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), this.currentAttr.value += A;
        break;
      }
      case r.EOF: {
        this._err(E.eofInTag), this._emitEOFToken();
        break;
      }
      default:
        this.currentAttr.value += String.fromCodePoint(t);
    }
  }
  // Attribute value (single-quoted) state
  //------------------------------------------------------------------
  _stateAttributeValueSingleQuoted(t) {
    switch (t) {
      case r.APOSTROPHE: {
        this.state = n.AFTER_ATTRIBUTE_VALUE_QUOTED;
        break;
      }
      case r.AMPERSAND: {
        this._startCharacterReference();
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), this.currentAttr.value += A;
        break;
      }
      case r.EOF: {
        this._err(E.eofInTag), this._emitEOFToken();
        break;
      }
      default:
        this.currentAttr.value += String.fromCodePoint(t);
    }
  }
  // Attribute value (unquoted) state
  //------------------------------------------------------------------
  _stateAttributeValueUnquoted(t) {
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED: {
        this._leaveAttrValue(), this.state = n.BEFORE_ATTRIBUTE_NAME;
        break;
      }
      case r.AMPERSAND: {
        this._startCharacterReference();
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._leaveAttrValue(), this.state = n.DATA, this.emitCurrentTagToken();
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), this.currentAttr.value += A;
        break;
      }
      case r.QUOTATION_MARK:
      case r.APOSTROPHE:
      case r.LESS_THAN_SIGN:
      case r.EQUALS_SIGN:
      case r.GRAVE_ACCENT: {
        this._err(E.unexpectedCharacterInUnquotedAttributeValue), this.currentAttr.value += String.fromCodePoint(t);
        break;
      }
      case r.EOF: {
        this._err(E.eofInTag), this._emitEOFToken();
        break;
      }
      default:
        this.currentAttr.value += String.fromCodePoint(t);
    }
  }
  // After attribute value (quoted) state
  //------------------------------------------------------------------
  _stateAfterAttributeValueQuoted(t) {
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED: {
        this._leaveAttrValue(), this.state = n.BEFORE_ATTRIBUTE_NAME;
        break;
      }
      case r.SOLIDUS: {
        this._leaveAttrValue(), this.state = n.SELF_CLOSING_START_TAG;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._leaveAttrValue(), this.state = n.DATA, this.emitCurrentTagToken();
        break;
      }
      case r.EOF: {
        this._err(E.eofInTag), this._emitEOFToken();
        break;
      }
      default:
        this._err(E.missingWhitespaceBetweenAttributes), this.state = n.BEFORE_ATTRIBUTE_NAME, this._stateBeforeAttributeName(t);
    }
  }
  // Self-closing start tag state
  //------------------------------------------------------------------
  _stateSelfClosingStartTag(t) {
    switch (t) {
      case r.GREATER_THAN_SIGN: {
        const a = this.currentToken;
        a.selfClosing = !0, this.state = n.DATA, this.emitCurrentTagToken();
        break;
      }
      case r.EOF: {
        this._err(E.eofInTag), this._emitEOFToken();
        break;
      }
      default:
        this._err(E.unexpectedSolidusInTag), this.state = n.BEFORE_ATTRIBUTE_NAME, this._stateBeforeAttributeName(t);
    }
  }
  // Bogus comment state
  //------------------------------------------------------------------
  _stateBogusComment(t) {
    const a = this.currentToken;
    switch (t) {
      case r.GREATER_THAN_SIGN: {
        this.state = n.DATA, this.emitCurrentComment(a);
        break;
      }
      case r.EOF: {
        this.emitCurrentComment(a), this._emitEOFToken();
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), a.data += A;
        break;
      }
      default:
        a.data += String.fromCodePoint(t);
    }
  }
  // Markup declaration open state
  //------------------------------------------------------------------
  _stateMarkupDeclarationOpen(t) {
    this._consumeSequenceIfMatch(O.DASH_DASH, !0) ? (this._createCommentToken(O.DASH_DASH.length + 1), this.state = n.COMMENT_START) : this._consumeSequenceIfMatch(O.DOCTYPE, !1) ? (this.currentLocation = this.getCurrentLocation(O.DOCTYPE.length + 1), this.state = n.DOCTYPE) : this._consumeSequenceIfMatch(O.CDATA_START, !0) ? this.inForeignNode ? this.state = n.CDATA_SECTION : (this._err(E.cdataInHtmlContent), this._createCommentToken(O.CDATA_START.length + 1), this.currentToken.data = "[CDATA[", this.state = n.BOGUS_COMMENT) : this._ensureHibernation() || (this._err(E.incorrectlyOpenedComment), this._createCommentToken(2), this.state = n.BOGUS_COMMENT, this._stateBogusComment(t));
  }
  // Comment start state
  //------------------------------------------------------------------
  _stateCommentStart(t) {
    switch (t) {
      case r.HYPHEN_MINUS: {
        this.state = n.COMMENT_START_DASH;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(E.abruptClosingOfEmptyComment), this.state = n.DATA;
        const a = this.currentToken;
        this.emitCurrentComment(a);
        break;
      }
      default:
        this.state = n.COMMENT, this._stateComment(t);
    }
  }
  // Comment start dash state
  //------------------------------------------------------------------
  _stateCommentStartDash(t) {
    const a = this.currentToken;
    switch (t) {
      case r.HYPHEN_MINUS: {
        this.state = n.COMMENT_END;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(E.abruptClosingOfEmptyComment), this.state = n.DATA, this.emitCurrentComment(a);
        break;
      }
      case r.EOF: {
        this._err(E.eofInComment), this.emitCurrentComment(a), this._emitEOFToken();
        break;
      }
      default:
        a.data += "-", this.state = n.COMMENT, this._stateComment(t);
    }
  }
  // Comment state
  //------------------------------------------------------------------
  _stateComment(t) {
    const a = this.currentToken;
    switch (t) {
      case r.HYPHEN_MINUS: {
        this.state = n.COMMENT_END_DASH;
        break;
      }
      case r.LESS_THAN_SIGN: {
        a.data += "<", this.state = n.COMMENT_LESS_THAN_SIGN;
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), a.data += A;
        break;
      }
      case r.EOF: {
        this._err(E.eofInComment), this.emitCurrentComment(a), this._emitEOFToken();
        break;
      }
      default:
        a.data += String.fromCodePoint(t);
    }
  }
  // Comment less-than sign state
  //------------------------------------------------------------------
  _stateCommentLessThanSign(t) {
    const a = this.currentToken;
    switch (t) {
      case r.EXCLAMATION_MARK: {
        a.data += "!", this.state = n.COMMENT_LESS_THAN_SIGN_BANG;
        break;
      }
      case r.LESS_THAN_SIGN: {
        a.data += "<";
        break;
      }
      default:
        this.state = n.COMMENT, this._stateComment(t);
    }
  }
  // Comment less-than sign bang state
  //------------------------------------------------------------------
  _stateCommentLessThanSignBang(t) {
    t === r.HYPHEN_MINUS ? this.state = n.COMMENT_LESS_THAN_SIGN_BANG_DASH : (this.state = n.COMMENT, this._stateComment(t));
  }
  // Comment less-than sign bang dash state
  //------------------------------------------------------------------
  _stateCommentLessThanSignBangDash(t) {
    t === r.HYPHEN_MINUS ? this.state = n.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH : (this.state = n.COMMENT_END_DASH, this._stateCommentEndDash(t));
  }
  // Comment less-than sign bang dash dash state
  //------------------------------------------------------------------
  _stateCommentLessThanSignBangDashDash(t) {
    t !== r.GREATER_THAN_SIGN && t !== r.EOF && this._err(E.nestedComment), this.state = n.COMMENT_END, this._stateCommentEnd(t);
  }
  // Comment end dash state
  //------------------------------------------------------------------
  _stateCommentEndDash(t) {
    const a = this.currentToken;
    switch (t) {
      case r.HYPHEN_MINUS: {
        this.state = n.COMMENT_END;
        break;
      }
      case r.EOF: {
        this._err(E.eofInComment), this.emitCurrentComment(a), this._emitEOFToken();
        break;
      }
      default:
        a.data += "-", this.state = n.COMMENT, this._stateComment(t);
    }
  }
  // Comment end state
  //------------------------------------------------------------------
  _stateCommentEnd(t) {
    const a = this.currentToken;
    switch (t) {
      case r.GREATER_THAN_SIGN: {
        this.state = n.DATA, this.emitCurrentComment(a);
        break;
      }
      case r.EXCLAMATION_MARK: {
        this.state = n.COMMENT_END_BANG;
        break;
      }
      case r.HYPHEN_MINUS: {
        a.data += "-";
        break;
      }
      case r.EOF: {
        this._err(E.eofInComment), this.emitCurrentComment(a), this._emitEOFToken();
        break;
      }
      default:
        a.data += "--", this.state = n.COMMENT, this._stateComment(t);
    }
  }
  // Comment end bang state
  //------------------------------------------------------------------
  _stateCommentEndBang(t) {
    const a = this.currentToken;
    switch (t) {
      case r.HYPHEN_MINUS: {
        a.data += "--!", this.state = n.COMMENT_END_DASH;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(E.incorrectlyClosedComment), this.state = n.DATA, this.emitCurrentComment(a);
        break;
      }
      case r.EOF: {
        this._err(E.eofInComment), this.emitCurrentComment(a), this._emitEOFToken();
        break;
      }
      default:
        a.data += "--!", this.state = n.COMMENT, this._stateComment(t);
    }
  }
  // DOCTYPE state
  //------------------------------------------------------------------
  _stateDoctype(t) {
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED: {
        this.state = n.BEFORE_DOCTYPE_NAME;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this.state = n.BEFORE_DOCTYPE_NAME, this._stateBeforeDoctypeName(t);
        break;
      }
      case r.EOF: {
        this._err(E.eofInDoctype), this._createDoctypeToken(null);
        const a = this.currentToken;
        a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        this._err(E.missingWhitespaceBeforeDoctypeName), this.state = n.BEFORE_DOCTYPE_NAME, this._stateBeforeDoctypeName(t);
    }
  }
  // Before DOCTYPE name state
  //------------------------------------------------------------------
  _stateBeforeDoctypeName(t) {
    if (q(t))
      this._createDoctypeToken(String.fromCharCode(te(t))), this.state = n.DOCTYPE_NAME;
    else
      switch (t) {
        case r.SPACE:
        case r.LINE_FEED:
        case r.TABULATION:
        case r.FORM_FEED:
          break;
        case r.NULL: {
          this._err(E.unexpectedNullCharacter), this._createDoctypeToken(A), this.state = n.DOCTYPE_NAME;
          break;
        }
        case r.GREATER_THAN_SIGN: {
          this._err(E.missingDoctypeName), this._createDoctypeToken(null);
          const a = this.currentToken;
          a.forceQuirks = !0, this.emitCurrentDoctype(a), this.state = n.DATA;
          break;
        }
        case r.EOF: {
          this._err(E.eofInDoctype), this._createDoctypeToken(null);
          const a = this.currentToken;
          a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
          break;
        }
        default:
          this._createDoctypeToken(String.fromCodePoint(t)), this.state = n.DOCTYPE_NAME;
      }
  }
  // DOCTYPE name state
  //------------------------------------------------------------------
  _stateDoctypeName(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED: {
        this.state = n.AFTER_DOCTYPE_NAME;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this.state = n.DATA, this.emitCurrentDoctype(a);
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), a.name += A;
        break;
      }
      case r.EOF: {
        this._err(E.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        a.name += String.fromCodePoint(q(t) ? te(t) : t);
    }
  }
  // After DOCTYPE name state
  //------------------------------------------------------------------
  _stateAfterDoctypeName(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
        break;
      case r.GREATER_THAN_SIGN: {
        this.state = n.DATA, this.emitCurrentDoctype(a);
        break;
      }
      case r.EOF: {
        this._err(E.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        this._consumeSequenceIfMatch(O.PUBLIC, !1) ? this.state = n.AFTER_DOCTYPE_PUBLIC_KEYWORD : this._consumeSequenceIfMatch(O.SYSTEM, !1) ? this.state = n.AFTER_DOCTYPE_SYSTEM_KEYWORD : this._ensureHibernation() || (this._err(E.invalidCharacterSequenceAfterDoctypeName), a.forceQuirks = !0, this.state = n.BOGUS_DOCTYPE, this._stateBogusDoctype(t));
    }
  }
  // After DOCTYPE public keyword state
  //------------------------------------------------------------------
  _stateAfterDoctypePublicKeyword(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED: {
        this.state = n.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER;
        break;
      }
      case r.QUOTATION_MARK: {
        this._err(E.missingWhitespaceAfterDoctypePublicKeyword), a.publicId = "", this.state = n.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
        break;
      }
      case r.APOSTROPHE: {
        this._err(E.missingWhitespaceAfterDoctypePublicKeyword), a.publicId = "", this.state = n.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(E.missingDoctypePublicIdentifier), a.forceQuirks = !0, this.state = n.DATA, this.emitCurrentDoctype(a);
        break;
      }
      case r.EOF: {
        this._err(E.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        this._err(E.missingQuoteBeforeDoctypePublicIdentifier), a.forceQuirks = !0, this.state = n.BOGUS_DOCTYPE, this._stateBogusDoctype(t);
    }
  }
  // Before DOCTYPE public identifier state
  //------------------------------------------------------------------
  _stateBeforeDoctypePublicIdentifier(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
        break;
      case r.QUOTATION_MARK: {
        a.publicId = "", this.state = n.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
        break;
      }
      case r.APOSTROPHE: {
        a.publicId = "", this.state = n.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(E.missingDoctypePublicIdentifier), a.forceQuirks = !0, this.state = n.DATA, this.emitCurrentDoctype(a);
        break;
      }
      case r.EOF: {
        this._err(E.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        this._err(E.missingQuoteBeforeDoctypePublicIdentifier), a.forceQuirks = !0, this.state = n.BOGUS_DOCTYPE, this._stateBogusDoctype(t);
    }
  }
  // DOCTYPE public identifier (double-quoted) state
  //------------------------------------------------------------------
  _stateDoctypePublicIdentifierDoubleQuoted(t) {
    const a = this.currentToken;
    switch (t) {
      case r.QUOTATION_MARK: {
        this.state = n.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), a.publicId += A;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(E.abruptDoctypePublicIdentifier), a.forceQuirks = !0, this.emitCurrentDoctype(a), this.state = n.DATA;
        break;
      }
      case r.EOF: {
        this._err(E.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        a.publicId += String.fromCodePoint(t);
    }
  }
  // DOCTYPE public identifier (single-quoted) state
  //------------------------------------------------------------------
  _stateDoctypePublicIdentifierSingleQuoted(t) {
    const a = this.currentToken;
    switch (t) {
      case r.APOSTROPHE: {
        this.state = n.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), a.publicId += A;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(E.abruptDoctypePublicIdentifier), a.forceQuirks = !0, this.emitCurrentDoctype(a), this.state = n.DATA;
        break;
      }
      case r.EOF: {
        this._err(E.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        a.publicId += String.fromCodePoint(t);
    }
  }
  // After DOCTYPE public identifier state
  //------------------------------------------------------------------
  _stateAfterDoctypePublicIdentifier(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED: {
        this.state = n.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this.state = n.DATA, this.emitCurrentDoctype(a);
        break;
      }
      case r.QUOTATION_MARK: {
        this._err(E.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers), a.systemId = "", this.state = n.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
        break;
      }
      case r.APOSTROPHE: {
        this._err(E.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers), a.systemId = "", this.state = n.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
        break;
      }
      case r.EOF: {
        this._err(E.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        this._err(E.missingQuoteBeforeDoctypeSystemIdentifier), a.forceQuirks = !0, this.state = n.BOGUS_DOCTYPE, this._stateBogusDoctype(t);
    }
  }
  // Between DOCTYPE public and system identifiers state
  //------------------------------------------------------------------
  _stateBetweenDoctypePublicAndSystemIdentifiers(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
        break;
      case r.GREATER_THAN_SIGN: {
        this.emitCurrentDoctype(a), this.state = n.DATA;
        break;
      }
      case r.QUOTATION_MARK: {
        a.systemId = "", this.state = n.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
        break;
      }
      case r.APOSTROPHE: {
        a.systemId = "", this.state = n.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
        break;
      }
      case r.EOF: {
        this._err(E.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        this._err(E.missingQuoteBeforeDoctypeSystemIdentifier), a.forceQuirks = !0, this.state = n.BOGUS_DOCTYPE, this._stateBogusDoctype(t);
    }
  }
  // After DOCTYPE system keyword state
  //------------------------------------------------------------------
  _stateAfterDoctypeSystemKeyword(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED: {
        this.state = n.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER;
        break;
      }
      case r.QUOTATION_MARK: {
        this._err(E.missingWhitespaceAfterDoctypeSystemKeyword), a.systemId = "", this.state = n.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
        break;
      }
      case r.APOSTROPHE: {
        this._err(E.missingWhitespaceAfterDoctypeSystemKeyword), a.systemId = "", this.state = n.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(E.missingDoctypeSystemIdentifier), a.forceQuirks = !0, this.state = n.DATA, this.emitCurrentDoctype(a);
        break;
      }
      case r.EOF: {
        this._err(E.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        this._err(E.missingQuoteBeforeDoctypeSystemIdentifier), a.forceQuirks = !0, this.state = n.BOGUS_DOCTYPE, this._stateBogusDoctype(t);
    }
  }
  // Before DOCTYPE system identifier state
  //------------------------------------------------------------------
  _stateBeforeDoctypeSystemIdentifier(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
        break;
      case r.QUOTATION_MARK: {
        a.systemId = "", this.state = n.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
        break;
      }
      case r.APOSTROPHE: {
        a.systemId = "", this.state = n.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(E.missingDoctypeSystemIdentifier), a.forceQuirks = !0, this.state = n.DATA, this.emitCurrentDoctype(a);
        break;
      }
      case r.EOF: {
        this._err(E.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        this._err(E.missingQuoteBeforeDoctypeSystemIdentifier), a.forceQuirks = !0, this.state = n.BOGUS_DOCTYPE, this._stateBogusDoctype(t);
    }
  }
  // DOCTYPE system identifier (double-quoted) state
  //------------------------------------------------------------------
  _stateDoctypeSystemIdentifierDoubleQuoted(t) {
    const a = this.currentToken;
    switch (t) {
      case r.QUOTATION_MARK: {
        this.state = n.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), a.systemId += A;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(E.abruptDoctypeSystemIdentifier), a.forceQuirks = !0, this.emitCurrentDoctype(a), this.state = n.DATA;
        break;
      }
      case r.EOF: {
        this._err(E.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        a.systemId += String.fromCodePoint(t);
    }
  }
  // DOCTYPE system identifier (single-quoted) state
  //------------------------------------------------------------------
  _stateDoctypeSystemIdentifierSingleQuoted(t) {
    const a = this.currentToken;
    switch (t) {
      case r.APOSTROPHE: {
        this.state = n.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter), a.systemId += A;
        break;
      }
      case r.GREATER_THAN_SIGN: {
        this._err(E.abruptDoctypeSystemIdentifier), a.forceQuirks = !0, this.emitCurrentDoctype(a), this.state = n.DATA;
        break;
      }
      case r.EOF: {
        this._err(E.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        a.systemId += String.fromCodePoint(t);
    }
  }
  // After DOCTYPE system identifier state
  //------------------------------------------------------------------
  _stateAfterDoctypeSystemIdentifier(t) {
    const a = this.currentToken;
    switch (t) {
      case r.SPACE:
      case r.LINE_FEED:
      case r.TABULATION:
      case r.FORM_FEED:
        break;
      case r.GREATER_THAN_SIGN: {
        this.emitCurrentDoctype(a), this.state = n.DATA;
        break;
      }
      case r.EOF: {
        this._err(E.eofInDoctype), a.forceQuirks = !0, this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
      default:
        this._err(E.unexpectedCharacterAfterDoctypeSystemIdentifier), this.state = n.BOGUS_DOCTYPE, this._stateBogusDoctype(t);
    }
  }
  // Bogus DOCTYPE state
  //------------------------------------------------------------------
  _stateBogusDoctype(t) {
    const a = this.currentToken;
    switch (t) {
      case r.GREATER_THAN_SIGN: {
        this.emitCurrentDoctype(a), this.state = n.DATA;
        break;
      }
      case r.NULL: {
        this._err(E.unexpectedNullCharacter);
        break;
      }
      case r.EOF: {
        this.emitCurrentDoctype(a), this._emitEOFToken();
        break;
      }
    }
  }
  // CDATA section state
  //------------------------------------------------------------------
  _stateCdataSection(t) {
    switch (t) {
      case r.RIGHT_SQUARE_BRACKET: {
        this.state = n.CDATA_SECTION_BRACKET;
        break;
      }
      case r.EOF: {
        this._err(E.eofInCdata), this._emitEOFToken();
        break;
      }
      default:
        this._emitCodePoint(t);
    }
  }
  // CDATA section bracket state
  //------------------------------------------------------------------
  _stateCdataSectionBracket(t) {
    t === r.RIGHT_SQUARE_BRACKET ? this.state = n.CDATA_SECTION_END : (this._emitChars("]"), this.state = n.CDATA_SECTION, this._stateCdataSection(t));
  }
  // CDATA section end state
  //------------------------------------------------------------------
  _stateCdataSectionEnd(t) {
    switch (t) {
      case r.GREATER_THAN_SIGN: {
        this.state = n.DATA;
        break;
      }
      case r.RIGHT_SQUARE_BRACKET: {
        this._emitChars("]");
        break;
      }
      default:
        this._emitChars("]]"), this.state = n.CDATA_SECTION, this._stateCdataSection(t);
    }
  }
  // Character reference state
  //------------------------------------------------------------------
  _stateCharacterReference() {
    let t = this.entityDecoder.write(this.preprocessor.html, this.preprocessor.pos);
    if (t < 0)
      if (this.preprocessor.lastChunkWritten)
        t = this.entityDecoder.end();
      else {
        this.active = !1, this.preprocessor.pos = this.preprocessor.html.length - 1, this.consumedAfterSnapshot = 0, this.preprocessor.endOfChunkHit = !0;
        return;
      }
    t === 0 ? (this.preprocessor.pos = this.entityStartPos, this._flushCodePointConsumedAsCharacterReference(r.AMPERSAND), this.state = !this._isCharacterReferenceInAttribute() && He(this.preprocessor.peek(1)) ? n.AMBIGUOUS_AMPERSAND : this.returnState) : this.state = this.returnState;
  }
  // Ambiguos ampersand state
  //------------------------------------------------------------------
  _stateAmbiguousAmpersand(t) {
    He(t) ? this._flushCodePointConsumedAsCharacterReference(t) : (t === r.SEMICOLON && this._err(E.unknownNamedCharacterReference), this.state = this.returnState, this._callState(t));
  }
}
const rt = /* @__PURE__ */ new Set([u.DD, u.DT, u.LI, u.OPTGROUP, u.OPTION, u.P, u.RB, u.RP, u.RT, u.RTC]), Ue = /* @__PURE__ */ new Set([
  ...rt,
  u.CAPTION,
  u.COLGROUP,
  u.TBODY,
  u.TD,
  u.TFOOT,
  u.TH,
  u.THEAD,
  u.TR
]), se = /* @__PURE__ */ new Set([
  u.APPLET,
  u.CAPTION,
  u.HTML,
  u.MARQUEE,
  u.OBJECT,
  u.TABLE,
  u.TD,
  u.TEMPLATE,
  u.TH
]), Su = /* @__PURE__ */ new Set([...se, u.OL, u.UL]), Lu = /* @__PURE__ */ new Set([...se, u.BUTTON]), ye = /* @__PURE__ */ new Set([u.ANNOTATION_XML, u.MI, u.MN, u.MO, u.MS, u.MTEXT]), we = /* @__PURE__ */ new Set([u.DESC, u.FOREIGN_OBJECT, u.TITLE]), gu = /* @__PURE__ */ new Set([u.TR, u.TEMPLATE, u.HTML]), Ru = /* @__PURE__ */ new Set([u.TBODY, u.TFOOT, u.THEAD, u.TEMPLATE, u.HTML]), Du = /* @__PURE__ */ new Set([u.TABLE, u.TEMPLATE, u.HTML]), Pu = /* @__PURE__ */ new Set([u.TD, u.TH]);
class Mu {
  get currentTmplContentOrNode() {
    return this._isInTemplate() ? this.treeAdapter.getTemplateContent(this.current) : this.current;
  }
  constructor(t, a, s) {
    this.treeAdapter = a, this.handler = s, this.items = [], this.tagIDs = [], this.stackTop = -1, this.tmplCount = 0, this.currentTagId = u.UNKNOWN, this.current = t;
  }
  //Index of element
  _indexOf(t) {
    return this.items.lastIndexOf(t, this.stackTop);
  }
  //Update current element
  _isInTemplate() {
    return this.currentTagId === u.TEMPLATE && this.treeAdapter.getNamespaceURI(this.current) === T.HTML;
  }
  _updateCurrentElement() {
    this.current = this.items[this.stackTop], this.currentTagId = this.tagIDs[this.stackTop];
  }
  //Mutations
  push(t, a) {
    this.stackTop++, this.items[this.stackTop] = t, this.current = t, this.tagIDs[this.stackTop] = a, this.currentTagId = a, this._isInTemplate() && this.tmplCount++, this.handler.onItemPush(t, a, !0);
  }
  pop() {
    const t = this.current;
    this.tmplCount > 0 && this._isInTemplate() && this.tmplCount--, this.stackTop--, this._updateCurrentElement(), this.handler.onItemPop(t, !0);
  }
  replace(t, a) {
    const s = this._indexOf(t);
    this.items[s] = a, s === this.stackTop && (this.current = a);
  }
  insertAfter(t, a, s) {
    const c = this._indexOf(t) + 1;
    this.items.splice(c, 0, a), this.tagIDs.splice(c, 0, s), this.stackTop++, c === this.stackTop && this._updateCurrentElement(), this.current && this.currentTagId !== void 0 && this.handler.onItemPush(this.current, this.currentTagId, c === this.stackTop);
  }
  popUntilTagNamePopped(t) {
    let a = this.stackTop + 1;
    do
      a = this.tagIDs.lastIndexOf(t, a - 1);
    while (a > 0 && this.treeAdapter.getNamespaceURI(this.items[a]) !== T.HTML);
    this.shortenToLength(Math.max(a, 0));
  }
  shortenToLength(t) {
    for (; this.stackTop >= t; ) {
      const a = this.current;
      this.tmplCount > 0 && this._isInTemplate() && (this.tmplCount -= 1), this.stackTop--, this._updateCurrentElement(), this.handler.onItemPop(a, this.stackTop < t);
    }
  }
  popUntilElementPopped(t) {
    const a = this._indexOf(t);
    this.shortenToLength(Math.max(a, 0));
  }
  popUntilPopped(t, a) {
    const s = this._indexOfTagNames(t, a);
    this.shortenToLength(Math.max(s, 0));
  }
  popUntilNumberedHeaderPopped() {
    this.popUntilPopped(_e, T.HTML);
  }
  popUntilTableCellPopped() {
    this.popUntilPopped(Pu, T.HTML);
  }
  popAllUpToHtmlElement() {
    this.tmplCount = 0, this.shortenToLength(1);
  }
  _indexOfTagNames(t, a) {
    for (let s = this.stackTop; s >= 0; s--)
      if (t.has(this.tagIDs[s]) && this.treeAdapter.getNamespaceURI(this.items[s]) === a)
        return s;
    return -1;
  }
  clearBackTo(t, a) {
    const s = this._indexOfTagNames(t, a);
    this.shortenToLength(s + 1);
  }
  clearBackToTableContext() {
    this.clearBackTo(Du, T.HTML);
  }
  clearBackToTableBodyContext() {
    this.clearBackTo(Ru, T.HTML);
  }
  clearBackToTableRowContext() {
    this.clearBackTo(gu, T.HTML);
  }
  remove(t) {
    const a = this._indexOf(t);
    a >= 0 && (a === this.stackTop ? this.pop() : (this.items.splice(a, 1), this.tagIDs.splice(a, 1), this.stackTop--, this._updateCurrentElement(), this.handler.onItemPop(t, !1)));
  }
  //Search
  tryPeekProperlyNestedBodyElement() {
    return this.stackTop >= 1 && this.tagIDs[1] === u.BODY ? this.items[1] : null;
  }
  contains(t) {
    return this._indexOf(t) > -1;
  }
  getCommonAncestor(t) {
    const a = this._indexOf(t) - 1;
    return a >= 0 ? this.items[a] : null;
  }
  isRootHtmlElementCurrent() {
    return this.stackTop === 0 && this.tagIDs[0] === u.HTML;
  }
  //Element in scope
  hasInDynamicScope(t, a) {
    for (let s = this.stackTop; s >= 0; s--) {
      const c = this.tagIDs[s];
      switch (this.treeAdapter.getNamespaceURI(this.items[s])) {
        case T.HTML: {
          if (c === t)
            return !0;
          if (a.has(c))
            return !1;
          break;
        }
        case T.SVG: {
          if (we.has(c))
            return !1;
          break;
        }
        case T.MATHML: {
          if (ye.has(c))
            return !1;
          break;
        }
      }
    }
    return !0;
  }
  hasInScope(t) {
    return this.hasInDynamicScope(t, se);
  }
  hasInListItemScope(t) {
    return this.hasInDynamicScope(t, Su);
  }
  hasInButtonScope(t) {
    return this.hasInDynamicScope(t, Lu);
  }
  hasNumberedHeaderInScope() {
    for (let t = this.stackTop; t >= 0; t--) {
      const a = this.tagIDs[t];
      switch (this.treeAdapter.getNamespaceURI(this.items[t])) {
        case T.HTML: {
          if (_e.has(a))
            return !0;
          if (se.has(a))
            return !1;
          break;
        }
        case T.SVG: {
          if (we.has(a))
            return !1;
          break;
        }
        case T.MATHML: {
          if (ye.has(a))
            return !1;
          break;
        }
      }
    }
    return !0;
  }
  hasInTableScope(t) {
    for (let a = this.stackTop; a >= 0; a--)
      if (this.treeAdapter.getNamespaceURI(this.items[a]) === T.HTML)
        switch (this.tagIDs[a]) {
          case t:
            return !0;
          case u.TABLE:
          case u.HTML:
            return !1;
        }
    return !0;
  }
  hasTableBodyContextInTableScope() {
    for (let t = this.stackTop; t >= 0; t--)
      if (this.treeAdapter.getNamespaceURI(this.items[t]) === T.HTML)
        switch (this.tagIDs[t]) {
          case u.TBODY:
          case u.THEAD:
          case u.TFOOT:
            return !0;
          case u.TABLE:
          case u.HTML:
            return !1;
        }
    return !0;
  }
  hasInSelectScope(t) {
    for (let a = this.stackTop; a >= 0; a--)
      if (this.treeAdapter.getNamespaceURI(this.items[a]) === T.HTML)
        switch (this.tagIDs[a]) {
          case t:
            return !0;
          case u.OPTION:
          case u.OPTGROUP:
            break;
          default:
            return !1;
        }
    return !0;
  }
  //Implied end tags
  generateImpliedEndTags() {
    for (; this.currentTagId !== void 0 && rt.has(this.currentTagId); )
      this.pop();
  }
  generateImpliedEndTagsThoroughly() {
    for (; this.currentTagId !== void 0 && Ue.has(this.currentTagId); )
      this.pop();
  }
  generateImpliedEndTagsWithExclusion(t) {
    for (; this.currentTagId !== void 0 && this.currentTagId !== t && Ue.has(this.currentTagId); )
      this.pop();
  }
}
const Te = 3;
var R;
(function(e) {
  e[e.Marker = 0] = "Marker", e[e.Element = 1] = "Element";
})(R || (R = {}));
const Ye = { type: R.Marker };
class Bu {
  constructor(t) {
    this.treeAdapter = t, this.entries = [], this.bookmark = null;
  }
  //Noah Ark's condition
  //OPTIMIZATION: at first we try to find possible candidates for exclusion using
  //lightweight heuristics without thorough attributes check.
  _getNoahArkConditionCandidates(t, a) {
    const s = [], c = a.length, d = this.treeAdapter.getTagName(t), l = this.treeAdapter.getNamespaceURI(t);
    for (let m = 0; m < this.entries.length; m++) {
      const f = this.entries[m];
      if (f.type === R.Marker)
        break;
      const { element: b } = f;
      if (this.treeAdapter.getTagName(b) === d && this.treeAdapter.getNamespaceURI(b) === l) {
        const S = this.treeAdapter.getAttrList(b);
        S.length === c && s.push({ idx: m, attrs: S });
      }
    }
    return s;
  }
  _ensureNoahArkCondition(t) {
    if (this.entries.length < Te)
      return;
    const a = this.treeAdapter.getAttrList(t), s = this._getNoahArkConditionCandidates(t, a);
    if (s.length < Te)
      return;
    const c = new Map(a.map((l) => [l.name, l.value]));
    let d = 0;
    for (let l = 0; l < s.length; l++) {
      const m = s[l];
      m.attrs.every((f) => c.get(f.name) === f.value) && (d += 1, d >= Te && this.entries.splice(m.idx, 1));
    }
  }
  //Mutations
  insertMarker() {
    this.entries.unshift(Ye);
  }
  pushElement(t, a) {
    this._ensureNoahArkCondition(t), this.entries.unshift({
      type: R.Element,
      element: t,
      token: a
    });
  }
  insertElementAfterBookmark(t, a) {
    const s = this.entries.indexOf(this.bookmark);
    this.entries.splice(s, 0, {
      type: R.Element,
      element: t,
      token: a
    });
  }
  removeEntry(t) {
    const a = this.entries.indexOf(t);
    a !== -1 && this.entries.splice(a, 1);
  }
  /**
   * Clears the list of formatting elements up to the last marker.
   *
   * @see https://html.spec.whatwg.org/multipage/parsing.html#clear-the-list-of-active-formatting-elements-up-to-the-last-marker
   */
  clearToLastMarker() {
    const t = this.entries.indexOf(Ye);
    t === -1 ? this.entries.length = 0 : this.entries.splice(0, t + 1);
  }
  //Search
  getElementEntryInScopeWithTagName(t) {
    const a = this.entries.find((s) => s.type === R.Marker || this.treeAdapter.getTagName(s.element) === t);
    return a && a.type === R.Element ? a : null;
  }
  getElementEntry(t) {
    return this.entries.find((a) => a.type === R.Element && a.element === t);
  }
}
const M = {
  //Node construction
  createDocument() {
    return {
      nodeName: "#document",
      mode: L.NO_QUIRKS,
      childNodes: []
    };
  },
  createDocumentFragment() {
    return {
      nodeName: "#document-fragment",
      childNodes: []
    };
  },
  createElement(e, t, a) {
    return {
      nodeName: e,
      tagName: e,
      attrs: a,
      namespaceURI: t,
      childNodes: [],
      parentNode: null
    };
  },
  createCommentNode(e) {
    return {
      nodeName: "#comment",
      data: e,
      parentNode: null
    };
  },
  createTextNode(e) {
    return {
      nodeName: "#text",
      value: e,
      parentNode: null
    };
  },
  //Tree mutation
  appendChild(e, t) {
    e.childNodes.push(t), t.parentNode = e;
  },
  insertBefore(e, t, a) {
    const s = e.childNodes.indexOf(a);
    e.childNodes.splice(s, 0, t), t.parentNode = e;
  },
  setTemplateContent(e, t) {
    e.content = t;
  },
  getTemplateContent(e) {
    return e.content;
  },
  setDocumentType(e, t, a, s) {
    const c = e.childNodes.find((d) => d.nodeName === "#documentType");
    if (c)
      c.name = t, c.publicId = a, c.systemId = s;
    else {
      const d = {
        nodeName: "#documentType",
        name: t,
        publicId: a,
        systemId: s,
        parentNode: null
      };
      M.appendChild(e, d);
    }
  },
  setDocumentMode(e, t) {
    e.mode = t;
  },
  getDocumentMode(e) {
    return e.mode;
  },
  detachNode(e) {
    if (e.parentNode) {
      const t = e.parentNode.childNodes.indexOf(e);
      e.parentNode.childNodes.splice(t, 1), e.parentNode = null;
    }
  },
  insertText(e, t) {
    if (e.childNodes.length > 0) {
      const a = e.childNodes[e.childNodes.length - 1];
      if (M.isTextNode(a)) {
        a.value += t;
        return;
      }
    }
    M.appendChild(e, M.createTextNode(t));
  },
  insertTextBefore(e, t, a) {
    const s = e.childNodes[e.childNodes.indexOf(a) - 1];
    s && M.isTextNode(s) ? s.value += t : M.insertBefore(e, M.createTextNode(t), a);
  },
  adoptAttributes(e, t) {
    const a = new Set(e.attrs.map((s) => s.name));
    for (let s = 0; s < t.length; s++)
      a.has(t[s].name) || e.attrs.push(t[s]);
  },
  //Tree traversing
  getFirstChild(e) {
    return e.childNodes[0];
  },
  getChildNodes(e) {
    return e.childNodes;
  },
  getParentNode(e) {
    return e.parentNode;
  },
  getAttrList(e) {
    return e.attrs;
  },
  //Node data
  getTagName(e) {
    return e.tagName;
  },
  getNamespaceURI(e) {
    return e.namespaceURI;
  },
  getTextNodeContent(e) {
    return e.value;
  },
  getCommentNodeContent(e) {
    return e.data;
  },
  getDocumentTypeNodeName(e) {
    return e.name;
  },
  getDocumentTypeNodePublicId(e) {
    return e.publicId;
  },
  getDocumentTypeNodeSystemId(e) {
    return e.systemId;
  },
  //Node types
  isTextNode(e) {
    return e.nodeName === "#text";
  },
  isCommentNode(e) {
    return e.nodeName === "#comment";
  },
  isDocumentTypeNode(e) {
    return e.nodeName === "#documentType";
  },
  isElementNode(e) {
    return Object.prototype.hasOwnProperty.call(e, "tagName");
  },
  // Source code location
  setNodeSourceCodeLocation(e, t) {
    e.sourceCodeLocation = t;
  },
  getNodeSourceCodeLocation(e) {
    return e.sourceCodeLocation;
  },
  updateNodeSourceCodeLocation(e, t) {
    e.sourceCodeLocation = { ...e.sourceCodeLocation, ...t };
  }
}, nt = "html", xu = "about:legacy-compat", ku = "http://www.ibm.com/data/dtd/v11/ibmxhtml1-transitional.dtd", it = [
  "+//silmaril//dtd html pro v0r11 19970101//",
  "-//as//dtd html 3.0 aswedit + extensions//",
  "-//advasoft ltd//dtd html 3.0 aswedit + extensions//",
  "-//ietf//dtd html 2.0 level 1//",
  "-//ietf//dtd html 2.0 level 2//",
  "-//ietf//dtd html 2.0 strict level 1//",
  "-//ietf//dtd html 2.0 strict level 2//",
  "-//ietf//dtd html 2.0 strict//",
  "-//ietf//dtd html 2.0//",
  "-//ietf//dtd html 2.1e//",
  "-//ietf//dtd html 3.0//",
  "-//ietf//dtd html 3.2 final//",
  "-//ietf//dtd html 3.2//",
  "-//ietf//dtd html 3//",
  "-//ietf//dtd html level 0//",
  "-//ietf//dtd html level 1//",
  "-//ietf//dtd html level 2//",
  "-//ietf//dtd html level 3//",
  "-//ietf//dtd html strict level 0//",
  "-//ietf//dtd html strict level 1//",
  "-//ietf//dtd html strict level 2//",
  "-//ietf//dtd html strict level 3//",
  "-//ietf//dtd html strict//",
  "-//ietf//dtd html//",
  "-//metrius//dtd metrius presentational//",
  "-//microsoft//dtd internet explorer 2.0 html strict//",
  "-//microsoft//dtd internet explorer 2.0 html//",
  "-//microsoft//dtd internet explorer 2.0 tables//",
  "-//microsoft//dtd internet explorer 3.0 html strict//",
  "-//microsoft//dtd internet explorer 3.0 html//",
  "-//microsoft//dtd internet explorer 3.0 tables//",
  "-//netscape comm. corp.//dtd html//",
  "-//netscape comm. corp.//dtd strict html//",
  "-//o'reilly and associates//dtd html 2.0//",
  "-//o'reilly and associates//dtd html extended 1.0//",
  "-//o'reilly and associates//dtd html extended relaxed 1.0//",
  "-//sq//dtd html 2.0 hotmetal + extensions//",
  "-//softquad software//dtd hotmetal pro 6.0::19990601::extensions to html 4.0//",
  "-//softquad//dtd hotmetal pro 4.0::19971010::extensions to html 4.0//",
  "-//spyglass//dtd html 2.0 extended//",
  "-//sun microsystems corp.//dtd hotjava html//",
  "-//sun microsystems corp.//dtd hotjava strict html//",
  "-//w3c//dtd html 3 1995-03-24//",
  "-//w3c//dtd html 3.2 draft//",
  "-//w3c//dtd html 3.2 final//",
  "-//w3c//dtd html 3.2//",
  "-//w3c//dtd html 3.2s draft//",
  "-//w3c//dtd html 4.0 frameset//",
  "-//w3c//dtd html 4.0 transitional//",
  "-//w3c//dtd html experimental 19960712//",
  "-//w3c//dtd html experimental 970421//",
  "-//w3c//dtd w3 html//",
  "-//w3o//dtd w3 html 3.0//",
  "-//webtechs//dtd mozilla html 2.0//",
  "-//webtechs//dtd mozilla html//"
], Hu = [
  ...it,
  "-//w3c//dtd html 4.01 frameset//",
  "-//w3c//dtd html 4.01 transitional//"
], Fu = /* @__PURE__ */ new Set([
  "-//w3o//dtd w3 html strict 3.0//en//",
  "-/w3c/dtd html 4.0 transitional/en",
  "html"
]), ct = ["-//w3c//dtd xhtml 1.0 frameset//", "-//w3c//dtd xhtml 1.0 transitional//"], Uu = [
  ...ct,
  "-//w3c//dtd html 4.01 frameset//",
  "-//w3c//dtd html 4.01 transitional//"
];
function ve(e, t) {
  return t.some((a) => e.startsWith(a));
}
function yu(e) {
  return e.name === nt && e.publicId === null && (e.systemId === null || e.systemId === xu);
}
function wu(e) {
  if (e.name !== nt)
    return L.QUIRKS;
  const { systemId: t } = e;
  if (t && t.toLowerCase() === ku)
    return L.QUIRKS;
  let { publicId: a } = e;
  if (a !== null) {
    if (a = a.toLowerCase(), Fu.has(a))
      return L.QUIRKS;
    let s = t === null ? Hu : it;
    if (ve(a, s))
      return L.QUIRKS;
    if (s = t === null ? ct : Uu, ve(a, s))
      return L.LIMITED_QUIRKS;
  }
  return L.NO_QUIRKS;
}
const Qe = {
  TEXT_HTML: "text/html",
  APPLICATION_XML: "application/xhtml+xml"
}, Yu = "definitionurl", vu = "definitionURL", Qu = new Map([
  "attributeName",
  "attributeType",
  "baseFrequency",
  "baseProfile",
  "calcMode",
  "clipPathUnits",
  "diffuseConstant",
  "edgeMode",
  "filterUnits",
  "glyphRef",
  "gradientTransform",
  "gradientUnits",
  "kernelMatrix",
  "kernelUnitLength",
  "keyPoints",
  "keySplines",
  "keyTimes",
  "lengthAdjust",
  "limitingConeAngle",
  "markerHeight",
  "markerUnits",
  "markerWidth",
  "maskContentUnits",
  "maskUnits",
  "numOctaves",
  "pathLength",
  "patternContentUnits",
  "patternTransform",
  "patternUnits",
  "pointsAtX",
  "pointsAtY",
  "pointsAtZ",
  "preserveAlpha",
  "preserveAspectRatio",
  "primitiveUnits",
  "refX",
  "refY",
  "repeatCount",
  "repeatDur",
  "requiredExtensions",
  "requiredFeatures",
  "specularConstant",
  "specularExponent",
  "spreadMethod",
  "startOffset",
  "stdDeviation",
  "stitchTiles",
  "surfaceScale",
  "systemLanguage",
  "tableValues",
  "targetX",
  "targetY",
  "textLength",
  "viewBox",
  "viewTarget",
  "xChannelSelector",
  "yChannelSelector",
  "zoomAndPan"
].map((e) => [e.toLowerCase(), e])), Gu = /* @__PURE__ */ new Map([
  ["xlink:actuate", { prefix: "xlink", name: "actuate", namespace: T.XLINK }],
  ["xlink:arcrole", { prefix: "xlink", name: "arcrole", namespace: T.XLINK }],
  ["xlink:href", { prefix: "xlink", name: "href", namespace: T.XLINK }],
  ["xlink:role", { prefix: "xlink", name: "role", namespace: T.XLINK }],
  ["xlink:show", { prefix: "xlink", name: "show", namespace: T.XLINK }],
  ["xlink:title", { prefix: "xlink", name: "title", namespace: T.XLINK }],
  ["xlink:type", { prefix: "xlink", name: "type", namespace: T.XLINK }],
  ["xml:lang", { prefix: "xml", name: "lang", namespace: T.XML }],
  ["xml:space", { prefix: "xml", name: "space", namespace: T.XML }],
  ["xmlns", { prefix: "", name: "xmlns", namespace: T.XMLNS }],
  ["xmlns:xlink", { prefix: "xmlns", name: "xlink", namespace: T.XMLNS }]
]), Wu = new Map([
  "altGlyph",
  "altGlyphDef",
  "altGlyphItem",
  "animateColor",
  "animateMotion",
  "animateTransform",
  "clipPath",
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence",
  "foreignObject",
  "glyphRef",
  "linearGradient",
  "radialGradient",
  "textPath"
].map((e) => [e.toLowerCase(), e])), qu = /* @__PURE__ */ new Set([
  u.B,
  u.BIG,
  u.BLOCKQUOTE,
  u.BODY,
  u.BR,
  u.CENTER,
  u.CODE,
  u.DD,
  u.DIV,
  u.DL,
  u.DT,
  u.EM,
  u.EMBED,
  u.H1,
  u.H2,
  u.H3,
  u.H4,
  u.H5,
  u.H6,
  u.HEAD,
  u.HR,
  u.I,
  u.IMG,
  u.LI,
  u.LISTING,
  u.MENU,
  u.META,
  u.NOBR,
  u.OL,
  u.P,
  u.PRE,
  u.RUBY,
  u.S,
  u.SMALL,
  u.SPAN,
  u.STRONG,
  u.STRIKE,
  u.SUB,
  u.SUP,
  u.TABLE,
  u.TT,
  u.U,
  u.UL,
  u.VAR
]);
function Xu(e) {
  const t = e.tagID;
  return t === u.FONT && e.attrs.some(({ name: s }) => s === k.COLOR || s === k.SIZE || s === k.FACE) || qu.has(t);
}
function ot(e) {
  for (let t = 0; t < e.attrs.length; t++)
    if (e.attrs[t].name === Yu) {
      e.attrs[t].name = vu;
      break;
    }
}
function dt(e) {
  for (let t = 0; t < e.attrs.length; t++) {
    const a = Qu.get(e.attrs[t].name);
    a != null && (e.attrs[t].name = a);
  }
}
function pe(e) {
  for (let t = 0; t < e.attrs.length; t++) {
    const a = Gu.get(e.attrs[t].name);
    a && (e.attrs[t].prefix = a.prefix, e.attrs[t].name = a.name, e.attrs[t].namespace = a.namespace);
  }
}
function Ku(e) {
  const t = Wu.get(e.tagName);
  t != null && (e.tagName = t, e.tagID = v(e.tagName));
}
function Vu(e, t) {
  return t === T.MATHML && (e === u.MI || e === u.MO || e === u.MN || e === u.MS || e === u.MTEXT);
}
function zu(e, t, a) {
  if (t === T.MATHML && e === u.ANNOTATION_XML) {
    for (let s = 0; s < a.length; s++)
      if (a[s].name === k.ENCODING) {
        const c = a[s].value.toLowerCase();
        return c === Qe.TEXT_HTML || c === Qe.APPLICATION_XML;
      }
  }
  return t === T.SVG && (e === u.FOREIGN_OBJECT || e === u.DESC || e === u.TITLE);
}
function ju(e, t, a, s) {
  return (!s || s === T.HTML) && zu(e, t, a) || (!s || s === T.MATHML) && Vu(e, t);
}
const Ju = "hidden", Zu = 8, $u = 3;
var i;
(function(e) {
  e[e.INITIAL = 0] = "INITIAL", e[e.BEFORE_HTML = 1] = "BEFORE_HTML", e[e.BEFORE_HEAD = 2] = "BEFORE_HEAD", e[e.IN_HEAD = 3] = "IN_HEAD", e[e.IN_HEAD_NO_SCRIPT = 4] = "IN_HEAD_NO_SCRIPT", e[e.AFTER_HEAD = 5] = "AFTER_HEAD", e[e.IN_BODY = 6] = "IN_BODY", e[e.TEXT = 7] = "TEXT", e[e.IN_TABLE = 8] = "IN_TABLE", e[e.IN_TABLE_TEXT = 9] = "IN_TABLE_TEXT", e[e.IN_CAPTION = 10] = "IN_CAPTION", e[e.IN_COLUMN_GROUP = 11] = "IN_COLUMN_GROUP", e[e.IN_TABLE_BODY = 12] = "IN_TABLE_BODY", e[e.IN_ROW = 13] = "IN_ROW", e[e.IN_CELL = 14] = "IN_CELL", e[e.IN_SELECT = 15] = "IN_SELECT", e[e.IN_SELECT_IN_TABLE = 16] = "IN_SELECT_IN_TABLE", e[e.IN_TEMPLATE = 17] = "IN_TEMPLATE", e[e.AFTER_BODY = 18] = "AFTER_BODY", e[e.IN_FRAMESET = 19] = "IN_FRAMESET", e[e.AFTER_FRAMESET = 20] = "AFTER_FRAMESET", e[e.AFTER_AFTER_BODY = 21] = "AFTER_AFTER_BODY", e[e.AFTER_AFTER_FRAMESET = 22] = "AFTER_AFTER_FRAMESET";
})(i || (i = {}));
const ea = {
  startLine: -1,
  startCol: -1,
  startOffset: -1,
  endLine: -1,
  endCol: -1,
  endOffset: -1
}, Et = /* @__PURE__ */ new Set([u.TABLE, u.TBODY, u.TFOOT, u.THEAD, u.TR]), Ge = {
  scriptingEnabled: !0,
  sourceCodeLocationInfo: !1,
  treeAdapter: M,
  onParseError: null
};
class We {
  constructor(t, a, s = null, c = null) {
    this.fragmentContext = s, this.scriptHandler = c, this.currentToken = null, this.stopped = !1, this.insertionMode = i.INITIAL, this.originalInsertionMode = i.INITIAL, this.headElement = null, this.formElement = null, this.currentNotInHTML = !1, this.tmplInsertionModeStack = [], this.pendingCharacterTokens = [], this.hasNonWhitespacePendingCharacterToken = !1, this.framesetOk = !0, this.skipNextNewLine = !1, this.fosterParentingEnabled = !1, this.options = {
      ...Ge,
      ...t
    }, this.treeAdapter = this.options.treeAdapter, this.onParseError = this.options.onParseError, this.onParseError && (this.options.sourceCodeLocationInfo = !0), this.document = a ?? this.treeAdapter.createDocument(), this.tokenizer = new Ou(this.options, this), this.activeFormattingElements = new Bu(this.treeAdapter), this.fragmentContextID = s ? v(this.treeAdapter.getTagName(s)) : u.UNKNOWN, this._setContextModes(s ?? this.document, this.fragmentContextID), this.openElements = new Mu(this.document, this.treeAdapter, this);
  }
  // API
  static parse(t, a) {
    const s = new this(a);
    return s.tokenizer.write(t, !0), s.document;
  }
  static getFragmentParser(t, a) {
    const s = {
      ...Ge,
      ...a
    };
    t ?? (t = s.treeAdapter.createElement(o.TEMPLATE, T.HTML, []));
    const c = s.treeAdapter.createElement("documentmock", T.HTML, []), d = new this(s, c, t);
    return d.fragmentContextID === u.TEMPLATE && d.tmplInsertionModeStack.unshift(i.IN_TEMPLATE), d._initTokenizerForFragmentParsing(), d._insertFakeRootElement(), d._resetInsertionMode(), d._findFormInFragmentContext(), d;
  }
  getFragment() {
    const t = this.treeAdapter.getFirstChild(this.document), a = this.treeAdapter.createDocumentFragment();
    return this._adoptNodes(t, a), a;
  }
  //Errors
  /** @internal */
  _err(t, a, s) {
    var c;
    if (!this.onParseError)
      return;
    const d = (c = t.location) !== null && c !== void 0 ? c : ea, l = {
      code: a,
      startLine: d.startLine,
      startCol: d.startCol,
      startOffset: d.startOffset,
      endLine: s ? d.startLine : d.endLine,
      endCol: s ? d.startCol : d.endCol,
      endOffset: s ? d.startOffset : d.endOffset
    };
    this.onParseError(l);
  }
  //Stack events
  /** @internal */
  onItemPush(t, a, s) {
    var c, d;
    (d = (c = this.treeAdapter).onItemPush) === null || d === void 0 || d.call(c, t), s && this.openElements.stackTop > 0 && this._setContextModes(t, a);
  }
  /** @internal */
  onItemPop(t, a) {
    var s, c;
    if (this.options.sourceCodeLocationInfo && this._setEndLocation(t, this.currentToken), (c = (s = this.treeAdapter).onItemPop) === null || c === void 0 || c.call(s, t, this.openElements.current), a) {
      let d, l;
      this.openElements.stackTop === 0 && this.fragmentContext ? (d = this.fragmentContext, l = this.fragmentContextID) : { current: d, currentTagId: l } = this.openElements, this._setContextModes(d, l);
    }
  }
  _setContextModes(t, a) {
    const s = t === this.document || t && this.treeAdapter.getNamespaceURI(t) === T.HTML;
    this.currentNotInHTML = !s, this.tokenizer.inForeignNode = !s && t !== void 0 && a !== void 0 && !this._isIntegrationPoint(a, t);
  }
  /** @protected */
  _switchToTextParsing(t, a) {
    this._insertElement(t, T.HTML), this.tokenizer.state = a, this.originalInsertionMode = this.insertionMode, this.insertionMode = i.TEXT;
  }
  switchToPlaintextParsing() {
    this.insertionMode = i.TEXT, this.originalInsertionMode = i.IN_BODY, this.tokenizer.state = N.PLAINTEXT;
  }
  //Fragment parsing
  /** @protected */
  _getAdjustedCurrentElement() {
    return this.openElements.stackTop === 0 && this.fragmentContext ? this.fragmentContext : this.openElements.current;
  }
  /** @protected */
  _findFormInFragmentContext() {
    let t = this.fragmentContext;
    for (; t; ) {
      if (this.treeAdapter.getTagName(t) === o.FORM) {
        this.formElement = t;
        break;
      }
      t = this.treeAdapter.getParentNode(t);
    }
  }
  _initTokenizerForFragmentParsing() {
    if (!(!this.fragmentContext || this.treeAdapter.getNamespaceURI(this.fragmentContext) !== T.HTML))
      switch (this.fragmentContextID) {
        case u.TITLE:
        case u.TEXTAREA: {
          this.tokenizer.state = N.RCDATA;
          break;
        }
        case u.STYLE:
        case u.XMP:
        case u.IFRAME:
        case u.NOEMBED:
        case u.NOFRAMES:
        case u.NOSCRIPT: {
          this.tokenizer.state = N.RAWTEXT;
          break;
        }
        case u.SCRIPT: {
          this.tokenizer.state = N.SCRIPT_DATA;
          break;
        }
        case u.PLAINTEXT: {
          this.tokenizer.state = N.PLAINTEXT;
          break;
        }
      }
  }
  //Tree mutation
  /** @protected */
  _setDocumentType(t) {
    const a = t.name || "", s = t.publicId || "", c = t.systemId || "";
    if (this.treeAdapter.setDocumentType(this.document, a, s, c), t.location) {
      const l = this.treeAdapter.getChildNodes(this.document).find((m) => this.treeAdapter.isDocumentTypeNode(m));
      l && this.treeAdapter.setNodeSourceCodeLocation(l, t.location);
    }
  }
  /** @protected */
  _attachElementToTree(t, a) {
    if (this.options.sourceCodeLocationInfo) {
      const s = a && {
        ...a,
        startTag: a
      };
      this.treeAdapter.setNodeSourceCodeLocation(t, s);
    }
    if (this._shouldFosterParentOnInsertion())
      this._fosterParentElement(t);
    else {
      const s = this.openElements.currentTmplContentOrNode;
      this.treeAdapter.appendChild(s ?? this.document, t);
    }
  }
  /**
   * For self-closing tags. Add an element to the tree, but skip adding it
   * to the stack.
   */
  /** @protected */
  _appendElement(t, a) {
    const s = this.treeAdapter.createElement(t.tagName, a, t.attrs);
    this._attachElementToTree(s, t.location);
  }
  /** @protected */
  _insertElement(t, a) {
    const s = this.treeAdapter.createElement(t.tagName, a, t.attrs);
    this._attachElementToTree(s, t.location), this.openElements.push(s, t.tagID);
  }
  /** @protected */
  _insertFakeElement(t, a) {
    const s = this.treeAdapter.createElement(t, T.HTML, []);
    this._attachElementToTree(s, null), this.openElements.push(s, a);
  }
  /** @protected */
  _insertTemplate(t) {
    const a = this.treeAdapter.createElement(t.tagName, T.HTML, t.attrs), s = this.treeAdapter.createDocumentFragment();
    this.treeAdapter.setTemplateContent(a, s), this._attachElementToTree(a, t.location), this.openElements.push(a, t.tagID), this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(s, null);
  }
  /** @protected */
  _insertFakeRootElement() {
    const t = this.treeAdapter.createElement(o.HTML, T.HTML, []);
    this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(t, null), this.treeAdapter.appendChild(this.openElements.current, t), this.openElements.push(t, u.HTML);
  }
  /** @protected */
  _appendCommentNode(t, a) {
    const s = this.treeAdapter.createCommentNode(t.data);
    this.treeAdapter.appendChild(a, s), this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(s, t.location);
  }
  /** @protected */
  _insertCharacters(t) {
    let a, s;
    if (this._shouldFosterParentOnInsertion() ? ({ parent: a, beforeElement: s } = this._findFosterParentingLocation(), s ? this.treeAdapter.insertTextBefore(a, t.chars, s) : this.treeAdapter.insertText(a, t.chars)) : (a = this.openElements.currentTmplContentOrNode, this.treeAdapter.insertText(a, t.chars)), !t.location)
      return;
    const c = this.treeAdapter.getChildNodes(a), d = s ? c.lastIndexOf(s) : c.length, l = c[d - 1];
    if (this.treeAdapter.getNodeSourceCodeLocation(l)) {
      const { endLine: f, endCol: b, endOffset: S } = t.location;
      this.treeAdapter.updateNodeSourceCodeLocation(l, { endLine: f, endCol: b, endOffset: S });
    } else this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(l, t.location);
  }
  /** @protected */
  _adoptNodes(t, a) {
    for (let s = this.treeAdapter.getFirstChild(t); s; s = this.treeAdapter.getFirstChild(t))
      this.treeAdapter.detachNode(s), this.treeAdapter.appendChild(a, s);
  }
  /** @protected */
  _setEndLocation(t, a) {
    if (this.treeAdapter.getNodeSourceCodeLocation(t) && a.location) {
      const s = a.location, c = this.treeAdapter.getTagName(t), d = (
        // NOTE: For cases like <p> <p> </p> - First 'p' closes without a closing
        // tag and for cases like <td> <p> </td> - 'p' closes without a closing tag.
        a.type === _.END_TAG && c === a.tagName ? {
          endTag: { ...s },
          endLine: s.endLine,
          endCol: s.endCol,
          endOffset: s.endOffset
        } : {
          endLine: s.startLine,
          endCol: s.startCol,
          endOffset: s.startOffset
        }
      );
      this.treeAdapter.updateNodeSourceCodeLocation(t, d);
    }
  }
  //Token processing
  shouldProcessStartTagTokenInForeignContent(t) {
    if (!this.currentNotInHTML)
      return !1;
    let a, s;
    return this.openElements.stackTop === 0 && this.fragmentContext ? (a = this.fragmentContext, s = this.fragmentContextID) : { current: a, currentTagId: s } = this.openElements, t.tagID === u.SVG && this.treeAdapter.getTagName(a) === o.ANNOTATION_XML && this.treeAdapter.getNamespaceURI(a) === T.MATHML ? !1 : (
      // Check that `current` is not an integration point for HTML or MathML elements.
      this.tokenizer.inForeignNode || // If it _is_ an integration point, then we might have to check that it is not an HTML
      // integration point.
      (t.tagID === u.MGLYPH || t.tagID === u.MALIGNMARK) && s !== void 0 && !this._isIntegrationPoint(s, a, T.HTML)
    );
  }
  /** @protected */
  _processToken(t) {
    switch (t.type) {
      case _.CHARACTER: {
        this.onCharacter(t);
        break;
      }
      case _.NULL_CHARACTER: {
        this.onNullCharacter(t);
        break;
      }
      case _.COMMENT: {
        this.onComment(t);
        break;
      }
      case _.DOCTYPE: {
        this.onDoctype(t);
        break;
      }
      case _.START_TAG: {
        this._processStartTag(t);
        break;
      }
      case _.END_TAG: {
        this.onEndTag(t);
        break;
      }
      case _.EOF: {
        this.onEof(t);
        break;
      }
      case _.WHITESPACE_CHARACTER: {
        this.onWhitespaceCharacter(t);
        break;
      }
    }
  }
  //Integration points
  /** @protected */
  _isIntegrationPoint(t, a, s) {
    const c = this.treeAdapter.getNamespaceURI(a), d = this.treeAdapter.getAttrList(a);
    return ju(t, c, d, s);
  }
  //Active formatting elements reconstruction
  /** @protected */
  _reconstructActiveFormattingElements() {
    const t = this.activeFormattingElements.entries.length;
    if (t) {
      const a = this.activeFormattingElements.entries.findIndex((c) => c.type === R.Marker || this.openElements.contains(c.element)), s = a === -1 ? t - 1 : a - 1;
      for (let c = s; c >= 0; c--) {
        const d = this.activeFormattingElements.entries[c];
        this._insertElement(d.token, this.treeAdapter.getNamespaceURI(d.element)), d.element = this.openElements.current;
      }
    }
  }
  //Close elements
  /** @protected */
  _closeTableCell() {
    this.openElements.generateImpliedEndTags(), this.openElements.popUntilTableCellPopped(), this.activeFormattingElements.clearToLastMarker(), this.insertionMode = i.IN_ROW;
  }
  /** @protected */
  _closePElement() {
    this.openElements.generateImpliedEndTagsWithExclusion(u.P), this.openElements.popUntilTagNamePopped(u.P);
  }
  //Insertion modes
  /** @protected */
  _resetInsertionMode() {
    for (let t = this.openElements.stackTop; t >= 0; t--)
      switch (t === 0 && this.fragmentContext ? this.fragmentContextID : this.openElements.tagIDs[t]) {
        case u.TR: {
          this.insertionMode = i.IN_ROW;
          return;
        }
        case u.TBODY:
        case u.THEAD:
        case u.TFOOT: {
          this.insertionMode = i.IN_TABLE_BODY;
          return;
        }
        case u.CAPTION: {
          this.insertionMode = i.IN_CAPTION;
          return;
        }
        case u.COLGROUP: {
          this.insertionMode = i.IN_COLUMN_GROUP;
          return;
        }
        case u.TABLE: {
          this.insertionMode = i.IN_TABLE;
          return;
        }
        case u.BODY: {
          this.insertionMode = i.IN_BODY;
          return;
        }
        case u.FRAMESET: {
          this.insertionMode = i.IN_FRAMESET;
          return;
        }
        case u.SELECT: {
          this._resetInsertionModeForSelect(t);
          return;
        }
        case u.TEMPLATE: {
          this.insertionMode = this.tmplInsertionModeStack[0];
          return;
        }
        case u.HTML: {
          this.insertionMode = this.headElement ? i.AFTER_HEAD : i.BEFORE_HEAD;
          return;
        }
        case u.TD:
        case u.TH: {
          if (t > 0) {
            this.insertionMode = i.IN_CELL;
            return;
          }
          break;
        }
        case u.HEAD: {
          if (t > 0) {
            this.insertionMode = i.IN_HEAD;
            return;
          }
          break;
        }
      }
    this.insertionMode = i.IN_BODY;
  }
  /** @protected */
  _resetInsertionModeForSelect(t) {
    if (t > 0)
      for (let a = t - 1; a > 0; a--) {
        const s = this.openElements.tagIDs[a];
        if (s === u.TEMPLATE)
          break;
        if (s === u.TABLE) {
          this.insertionMode = i.IN_SELECT_IN_TABLE;
          return;
        }
      }
    this.insertionMode = i.IN_SELECT;
  }
  //Foster parenting
  /** @protected */
  _isElementCausesFosterParenting(t) {
    return Et.has(t);
  }
  /** @protected */
  _shouldFosterParentOnInsertion() {
    return this.fosterParentingEnabled && this.openElements.currentTagId !== void 0 && this._isElementCausesFosterParenting(this.openElements.currentTagId);
  }
  /** @protected */
  _findFosterParentingLocation() {
    for (let t = this.openElements.stackTop; t >= 0; t--) {
      const a = this.openElements.items[t];
      switch (this.openElements.tagIDs[t]) {
        case u.TEMPLATE: {
          if (this.treeAdapter.getNamespaceURI(a) === T.HTML)
            return { parent: this.treeAdapter.getTemplateContent(a), beforeElement: null };
          break;
        }
        case u.TABLE: {
          const s = this.treeAdapter.getParentNode(a);
          return s ? { parent: s, beforeElement: a } : { parent: this.openElements.items[t - 1], beforeElement: null };
        }
      }
    }
    return { parent: this.openElements.items[0], beforeElement: null };
  }
  /** @protected */
  _fosterParentElement(t) {
    const a = this._findFosterParentingLocation();
    a.beforeElement ? this.treeAdapter.insertBefore(a.parent, t, a.beforeElement) : this.treeAdapter.appendChild(a.parent, t);
  }
  //Special elements
  /** @protected */
  _isSpecialElement(t, a) {
    const s = this.treeAdapter.getNamespaceURI(t);
    return Nu[s].has(a);
  }
  /** @internal */
  onCharacter(t) {
    if (this.skipNextNewLine = !1, this.tokenizer.inForeignNode) {
      Ps(this, t);
      return;
    }
    switch (this.insertionMode) {
      case i.INITIAL: {
        G(this, t);
        break;
      }
      case i.BEFORE_HTML: {
        X(this, t);
        break;
      }
      case i.BEFORE_HEAD: {
        K(this, t);
        break;
      }
      case i.IN_HEAD: {
        V(this, t);
        break;
      }
      case i.IN_HEAD_NO_SCRIPT: {
        z(this, t);
        break;
      }
      case i.AFTER_HEAD: {
        j(this, t);
        break;
      }
      case i.IN_BODY:
      case i.IN_CAPTION:
      case i.IN_CELL:
      case i.IN_TEMPLATE: {
        lt(this, t);
        break;
      }
      case i.TEXT:
      case i.IN_SELECT:
      case i.IN_SELECT_IN_TABLE: {
        this._insertCharacters(t);
        break;
      }
      case i.IN_TABLE:
      case i.IN_TABLE_BODY:
      case i.IN_ROW: {
        le(this, t);
        break;
      }
      case i.IN_TABLE_TEXT: {
        At(this, t);
        break;
      }
      case i.IN_COLUMN_GROUP: {
        re(this, t);
        break;
      }
      case i.AFTER_BODY: {
        ne(this, t);
        break;
      }
      case i.AFTER_AFTER_BODY: {
        ae(this, t);
        break;
      }
    }
  }
  /** @internal */
  onNullCharacter(t) {
    if (this.skipNextNewLine = !1, this.tokenizer.inForeignNode) {
      Ds(this, t);
      return;
    }
    switch (this.insertionMode) {
      case i.INITIAL: {
        G(this, t);
        break;
      }
      case i.BEFORE_HTML: {
        X(this, t);
        break;
      }
      case i.BEFORE_HEAD: {
        K(this, t);
        break;
      }
      case i.IN_HEAD: {
        V(this, t);
        break;
      }
      case i.IN_HEAD_NO_SCRIPT: {
        z(this, t);
        break;
      }
      case i.AFTER_HEAD: {
        j(this, t);
        break;
      }
      case i.TEXT: {
        this._insertCharacters(t);
        break;
      }
      case i.IN_TABLE:
      case i.IN_TABLE_BODY:
      case i.IN_ROW: {
        le(this, t);
        break;
      }
      case i.IN_COLUMN_GROUP: {
        re(this, t);
        break;
      }
      case i.AFTER_BODY: {
        ne(this, t);
        break;
      }
      case i.AFTER_AFTER_BODY: {
        ae(this, t);
        break;
      }
    }
  }
  /** @internal */
  onComment(t) {
    if (this.skipNextNewLine = !1, this.currentNotInHTML) {
      be(this, t);
      return;
    }
    switch (this.insertionMode) {
      case i.INITIAL:
      case i.BEFORE_HTML:
      case i.BEFORE_HEAD:
      case i.IN_HEAD:
      case i.IN_HEAD_NO_SCRIPT:
      case i.AFTER_HEAD:
      case i.IN_BODY:
      case i.IN_TABLE:
      case i.IN_CAPTION:
      case i.IN_COLUMN_GROUP:
      case i.IN_TABLE_BODY:
      case i.IN_ROW:
      case i.IN_CELL:
      case i.IN_SELECT:
      case i.IN_SELECT_IN_TABLE:
      case i.IN_TEMPLATE:
      case i.IN_FRAMESET:
      case i.AFTER_FRAMESET: {
        be(this, t);
        break;
      }
      case i.IN_TABLE_TEXT: {
        W(this, t);
        break;
      }
      case i.AFTER_BODY: {
        ia(this, t);
        break;
      }
      case i.AFTER_AFTER_BODY:
      case i.AFTER_AFTER_FRAMESET: {
        ca(this, t);
        break;
      }
    }
  }
  /** @internal */
  onDoctype(t) {
    switch (this.skipNextNewLine = !1, this.insertionMode) {
      case i.INITIAL: {
        oa(this, t);
        break;
      }
      case i.BEFORE_HEAD:
      case i.IN_HEAD:
      case i.IN_HEAD_NO_SCRIPT:
      case i.AFTER_HEAD: {
        this._err(t, E.misplacedDoctype);
        break;
      }
      case i.IN_TABLE_TEXT: {
        W(this, t);
        break;
      }
    }
  }
  /** @internal */
  onStartTag(t) {
    this.skipNextNewLine = !1, this.currentToken = t, this._processStartTag(t), t.selfClosing && !t.ackSelfClosing && this._err(t, E.nonVoidHtmlElementStartTagWithTrailingSolidus);
  }
  /**
   * Processes a given start tag.
   *
   * `onStartTag` checks if a self-closing tag was recognized. When a token
   * is moved inbetween multiple insertion modes, this check for self-closing
   * could lead to false positives. To avoid this, `_processStartTag` is used
   * for nested calls.
   *
   * @param token The token to process.
   * @protected
   */
  _processStartTag(t) {
    this.shouldProcessStartTagTokenInForeignContent(t) ? Ms(this, t) : this._startTagOutsideForeignContent(t);
  }
  /** @protected */
  _startTagOutsideForeignContent(t) {
    switch (this.insertionMode) {
      case i.INITIAL: {
        G(this, t);
        break;
      }
      case i.BEFORE_HTML: {
        da(this, t);
        break;
      }
      case i.BEFORE_HEAD: {
        Ta(this, t);
        break;
      }
      case i.IN_HEAD: {
        g(this, t);
        break;
      }
      case i.IN_HEAD_NO_SCRIPT: {
        fa(this, t);
        break;
      }
      case i.AFTER_HEAD: {
        _a(this, t);
        break;
      }
      case i.IN_BODY: {
        p(this, t);
        break;
      }
      case i.IN_TABLE: {
        w(this, t);
        break;
      }
      case i.IN_TABLE_TEXT: {
        W(this, t);
        break;
      }
      case i.IN_CAPTION: {
        ls(this, t);
        break;
      }
      case i.IN_COLUMN_GROUP: {
        Le(this, t);
        break;
      }
      case i.IN_TABLE_BODY: {
        de(this, t);
        break;
      }
      case i.IN_ROW: {
        Ee(this, t);
        break;
      }
      case i.IN_CELL: {
        ms(this, t);
        break;
      }
      case i.IN_SELECT: {
        Ct(this, t);
        break;
      }
      case i.IN_SELECT_IN_TABLE: {
        bs(this, t);
        break;
      }
      case i.IN_TEMPLATE: {
        Ns(this, t);
        break;
      }
      case i.AFTER_BODY: {
        Cs(this, t);
        break;
      }
      case i.IN_FRAMESET: {
        ps(this, t);
        break;
      }
      case i.AFTER_FRAMESET: {
        Ss(this, t);
        break;
      }
      case i.AFTER_AFTER_BODY: {
        gs(this, t);
        break;
      }
      case i.AFTER_AFTER_FRAMESET: {
        Rs(this, t);
        break;
      }
    }
  }
  /** @internal */
  onEndTag(t) {
    this.skipNextNewLine = !1, this.currentToken = t, this.currentNotInHTML ? Bs(this, t) : this._endTagOutsideForeignContent(t);
  }
  /** @protected */
  _endTagOutsideForeignContent(t) {
    switch (this.insertionMode) {
      case i.INITIAL: {
        G(this, t);
        break;
      }
      case i.BEFORE_HTML: {
        Ea(this, t);
        break;
      }
      case i.BEFORE_HEAD: {
        la(this, t);
        break;
      }
      case i.IN_HEAD: {
        ha(this, t);
        break;
      }
      case i.IN_HEAD_NO_SCRIPT: {
        ma(this, t);
        break;
      }
      case i.AFTER_HEAD: {
        ba(this, t);
        break;
      }
      case i.IN_BODY: {
        oe(this, t);
        break;
      }
      case i.TEXT: {
        as(this, t);
        break;
      }
      case i.IN_TABLE: {
        J(this, t);
        break;
      }
      case i.IN_TABLE_TEXT: {
        W(this, t);
        break;
      }
      case i.IN_CAPTION: {
        hs(this, t);
        break;
      }
      case i.IN_COLUMN_GROUP: {
        fs(this, t);
        break;
      }
      case i.IN_TABLE_BODY: {
        Ae(this, t);
        break;
      }
      case i.IN_ROW: {
        It(this, t);
        break;
      }
      case i.IN_CELL: {
        _s(this, t);
        break;
      }
      case i.IN_SELECT: {
        pt(this, t);
        break;
      }
      case i.IN_SELECT_IN_TABLE: {
        As(this, t);
        break;
      }
      case i.IN_TEMPLATE: {
        Is(this, t);
        break;
      }
      case i.AFTER_BODY: {
        St(this, t);
        break;
      }
      case i.IN_FRAMESET: {
        Os(this, t);
        break;
      }
      case i.AFTER_FRAMESET: {
        Ls(this, t);
        break;
      }
      case i.AFTER_AFTER_BODY: {
        ae(this, t);
        break;
      }
    }
  }
  /** @internal */
  onEof(t) {
    switch (this.insertionMode) {
      case i.INITIAL: {
        G(this, t);
        break;
      }
      case i.BEFORE_HTML: {
        X(this, t);
        break;
      }
      case i.BEFORE_HEAD: {
        K(this, t);
        break;
      }
      case i.IN_HEAD: {
        V(this, t);
        break;
      }
      case i.IN_HEAD_NO_SCRIPT: {
        z(this, t);
        break;
      }
      case i.AFTER_HEAD: {
        j(this, t);
        break;
      }
      case i.IN_BODY:
      case i.IN_TABLE:
      case i.IN_CAPTION:
      case i.IN_COLUMN_GROUP:
      case i.IN_TABLE_BODY:
      case i.IN_ROW:
      case i.IN_CELL:
      case i.IN_SELECT:
      case i.IN_SELECT_IN_TABLE: {
        _t(this, t);
        break;
      }
      case i.TEXT: {
        ss(this, t);
        break;
      }
      case i.IN_TABLE_TEXT: {
        W(this, t);
        break;
      }
      case i.IN_TEMPLATE: {
        Ot(this, t);
        break;
      }
      case i.AFTER_BODY:
      case i.IN_FRAMESET:
      case i.AFTER_FRAMESET:
      case i.AFTER_AFTER_BODY:
      case i.AFTER_AFTER_FRAMESET: {
        Se(this, t);
        break;
      }
    }
  }
  /** @internal */
  onWhitespaceCharacter(t) {
    if (this.skipNextNewLine && (this.skipNextNewLine = !1, t.chars.charCodeAt(0) === r.LINE_FEED)) {
      if (t.chars.length === 1)
        return;
      t.chars = t.chars.substr(1);
    }
    if (this.tokenizer.inForeignNode) {
      this._insertCharacters(t);
      return;
    }
    switch (this.insertionMode) {
      case i.IN_HEAD:
      case i.IN_HEAD_NO_SCRIPT:
      case i.AFTER_HEAD:
      case i.TEXT:
      case i.IN_COLUMN_GROUP:
      case i.IN_SELECT:
      case i.IN_SELECT_IN_TABLE:
      case i.IN_FRAMESET:
      case i.AFTER_FRAMESET: {
        this._insertCharacters(t);
        break;
      }
      case i.IN_BODY:
      case i.IN_CAPTION:
      case i.IN_CELL:
      case i.IN_TEMPLATE:
      case i.AFTER_BODY:
      case i.AFTER_AFTER_BODY:
      case i.AFTER_AFTER_FRAMESET: {
        Tt(this, t);
        break;
      }
      case i.IN_TABLE:
      case i.IN_TABLE_BODY:
      case i.IN_ROW: {
        le(this, t);
        break;
      }
      case i.IN_TABLE_TEXT: {
        bt(this, t);
        break;
      }
    }
  }
}
function ta(e, t) {
  let a = e.activeFormattingElements.getElementEntryInScopeWithTagName(t.tagName);
  return a ? e.openElements.contains(a.element) ? e.openElements.hasInScope(t.tagID) || (a = null) : (e.activeFormattingElements.removeEntry(a), a = null) : mt(e, t), a;
}
function ua(e, t) {
  let a = null, s = e.openElements.stackTop;
  for (; s >= 0; s--) {
    const c = e.openElements.items[s];
    if (c === t.element)
      break;
    e._isSpecialElement(c, e.openElements.tagIDs[s]) && (a = c);
  }
  return a || (e.openElements.shortenToLength(Math.max(s, 0)), e.activeFormattingElements.removeEntry(t)), a;
}
function aa(e, t, a) {
  let s = t, c = e.openElements.getCommonAncestor(t);
  for (let d = 0, l = c; l !== a; d++, l = c) {
    c = e.openElements.getCommonAncestor(l);
    const m = e.activeFormattingElements.getElementEntry(l), f = m && d >= $u;
    !m || f ? (f && e.activeFormattingElements.removeEntry(m), e.openElements.remove(l)) : (l = sa(e, m), s === t && (e.activeFormattingElements.bookmark = m), e.treeAdapter.detachNode(s), e.treeAdapter.appendChild(l, s), s = l);
  }
  return s;
}
function sa(e, t) {
  const a = e.treeAdapter.getNamespaceURI(t.element), s = e.treeAdapter.createElement(t.token.tagName, a, t.token.attrs);
  return e.openElements.replace(t.element, s), t.element = s, s;
}
function ra(e, t, a) {
  const s = e.treeAdapter.getTagName(t), c = v(s);
  if (e._isElementCausesFosterParenting(c))
    e._fosterParentElement(a);
  else {
    const d = e.treeAdapter.getNamespaceURI(t);
    c === u.TEMPLATE && d === T.HTML && (t = e.treeAdapter.getTemplateContent(t)), e.treeAdapter.appendChild(t, a);
  }
}
function na(e, t, a) {
  const s = e.treeAdapter.getNamespaceURI(a.element), { token: c } = a, d = e.treeAdapter.createElement(c.tagName, s, c.attrs);
  e._adoptNodes(t, d), e.treeAdapter.appendChild(t, d), e.activeFormattingElements.insertElementAfterBookmark(d, c), e.activeFormattingElements.removeEntry(a), e.openElements.remove(a.element), e.openElements.insertAfter(t, d, c.tagID);
}
function Oe(e, t) {
  for (let a = 0; a < Zu; a++) {
    const s = ta(e, t);
    if (!s)
      break;
    const c = ua(e, s);
    if (!c)
      break;
    e.activeFormattingElements.bookmark = s;
    const d = aa(e, c, s.element), l = e.openElements.getCommonAncestor(s.element);
    e.treeAdapter.detachNode(d), l && ra(e, l, d), na(e, c, s);
  }
}
function be(e, t) {
  e._appendCommentNode(t, e.openElements.currentTmplContentOrNode);
}
function ia(e, t) {
  e._appendCommentNode(t, e.openElements.items[0]);
}
function ca(e, t) {
  e._appendCommentNode(t, e.document);
}
function Se(e, t) {
  if (e.stopped = !0, t.location) {
    const a = e.fragmentContext ? 0 : 2;
    for (let s = e.openElements.stackTop; s >= a; s--)
      e._setEndLocation(e.openElements.items[s], t);
    if (!e.fragmentContext && e.openElements.stackTop >= 0) {
      const s = e.openElements.items[0], c = e.treeAdapter.getNodeSourceCodeLocation(s);
      if (c && !c.endTag && (e._setEndLocation(s, t), e.openElements.stackTop >= 1)) {
        const d = e.openElements.items[1], l = e.treeAdapter.getNodeSourceCodeLocation(d);
        l && !l.endTag && e._setEndLocation(d, t);
      }
    }
  }
}
function oa(e, t) {
  e._setDocumentType(t);
  const a = t.forceQuirks ? L.QUIRKS : wu(t);
  yu(t) || e._err(t, E.nonConformingDoctype), e.treeAdapter.setDocumentMode(e.document, a), e.insertionMode = i.BEFORE_HTML;
}
function G(e, t) {
  e._err(t, E.missingDoctype, !0), e.treeAdapter.setDocumentMode(e.document, L.QUIRKS), e.insertionMode = i.BEFORE_HTML, e._processToken(t);
}
function da(e, t) {
  t.tagID === u.HTML ? (e._insertElement(t, T.HTML), e.insertionMode = i.BEFORE_HEAD) : X(e, t);
}
function Ea(e, t) {
  const a = t.tagID;
  (a === u.HTML || a === u.HEAD || a === u.BODY || a === u.BR) && X(e, t);
}
function X(e, t) {
  e._insertFakeRootElement(), e.insertionMode = i.BEFORE_HEAD, e._processToken(t);
}
function Ta(e, t) {
  switch (t.tagID) {
    case u.HTML: {
      p(e, t);
      break;
    }
    case u.HEAD: {
      e._insertElement(t, T.HTML), e.headElement = e.openElements.current, e.insertionMode = i.IN_HEAD;
      break;
    }
    default:
      K(e, t);
  }
}
function la(e, t) {
  const a = t.tagID;
  a === u.HEAD || a === u.BODY || a === u.HTML || a === u.BR ? K(e, t) : e._err(t, E.endTagWithoutMatchingOpenElement);
}
function K(e, t) {
  e._insertFakeElement(o.HEAD, u.HEAD), e.headElement = e.openElements.current, e.insertionMode = i.IN_HEAD, e._processToken(t);
}
function g(e, t) {
  switch (t.tagID) {
    case u.HTML: {
      p(e, t);
      break;
    }
    case u.BASE:
    case u.BASEFONT:
    case u.BGSOUND:
    case u.LINK:
    case u.META: {
      e._appendElement(t, T.HTML), t.ackSelfClosing = !0;
      break;
    }
    case u.TITLE: {
      e._switchToTextParsing(t, N.RCDATA);
      break;
    }
    case u.NOSCRIPT: {
      e.options.scriptingEnabled ? e._switchToTextParsing(t, N.RAWTEXT) : (e._insertElement(t, T.HTML), e.insertionMode = i.IN_HEAD_NO_SCRIPT);
      break;
    }
    case u.NOFRAMES:
    case u.STYLE: {
      e._switchToTextParsing(t, N.RAWTEXT);
      break;
    }
    case u.SCRIPT: {
      e._switchToTextParsing(t, N.SCRIPT_DATA);
      break;
    }
    case u.TEMPLATE: {
      e._insertTemplate(t), e.activeFormattingElements.insertMarker(), e.framesetOk = !1, e.insertionMode = i.IN_TEMPLATE, e.tmplInsertionModeStack.unshift(i.IN_TEMPLATE);
      break;
    }
    case u.HEAD: {
      e._err(t, E.misplacedStartTagForHeadElement);
      break;
    }
    default:
      V(e, t);
  }
}
function ha(e, t) {
  switch (t.tagID) {
    case u.HEAD: {
      e.openElements.pop(), e.insertionMode = i.AFTER_HEAD;
      break;
    }
    case u.BODY:
    case u.BR:
    case u.HTML: {
      V(e, t);
      break;
    }
    case u.TEMPLATE: {
      F(e, t);
      break;
    }
    default:
      e._err(t, E.endTagWithoutMatchingOpenElement);
  }
}
function F(e, t) {
  e.openElements.tmplCount > 0 ? (e.openElements.generateImpliedEndTagsThoroughly(), e.openElements.currentTagId !== u.TEMPLATE && e._err(t, E.closingOfElementWithOpenChildElements), e.openElements.popUntilTagNamePopped(u.TEMPLATE), e.activeFormattingElements.clearToLastMarker(), e.tmplInsertionModeStack.shift(), e._resetInsertionMode()) : e._err(t, E.endTagWithoutMatchingOpenElement);
}
function V(e, t) {
  e.openElements.pop(), e.insertionMode = i.AFTER_HEAD, e._processToken(t);
}
function fa(e, t) {
  switch (t.tagID) {
    case u.HTML: {
      p(e, t);
      break;
    }
    case u.BASEFONT:
    case u.BGSOUND:
    case u.HEAD:
    case u.LINK:
    case u.META:
    case u.NOFRAMES:
    case u.STYLE: {
      g(e, t);
      break;
    }
    case u.NOSCRIPT: {
      e._err(t, E.nestedNoscriptInHead);
      break;
    }
    default:
      z(e, t);
  }
}
function ma(e, t) {
  switch (t.tagID) {
    case u.NOSCRIPT: {
      e.openElements.pop(), e.insertionMode = i.IN_HEAD;
      break;
    }
    case u.BR: {
      z(e, t);
      break;
    }
    default:
      e._err(t, E.endTagWithoutMatchingOpenElement);
  }
}
function z(e, t) {
  const a = t.type === _.EOF ? E.openElementsLeftAfterEof : E.disallowedContentInNoscriptInHead;
  e._err(t, a), e.openElements.pop(), e.insertionMode = i.IN_HEAD, e._processToken(t);
}
function _a(e, t) {
  switch (t.tagID) {
    case u.HTML: {
      p(e, t);
      break;
    }
    case u.BODY: {
      e._insertElement(t, T.HTML), e.framesetOk = !1, e.insertionMode = i.IN_BODY;
      break;
    }
    case u.FRAMESET: {
      e._insertElement(t, T.HTML), e.insertionMode = i.IN_FRAMESET;
      break;
    }
    case u.BASE:
    case u.BASEFONT:
    case u.BGSOUND:
    case u.LINK:
    case u.META:
    case u.NOFRAMES:
    case u.SCRIPT:
    case u.STYLE:
    case u.TEMPLATE:
    case u.TITLE: {
      e._err(t, E.abandonedHeadElementChild), e.openElements.push(e.headElement, u.HEAD), g(e, t), e.openElements.remove(e.headElement);
      break;
    }
    case u.HEAD: {
      e._err(t, E.misplacedStartTagForHeadElement);
      break;
    }
    default:
      j(e, t);
  }
}
function ba(e, t) {
  switch (t.tagID) {
    case u.BODY:
    case u.HTML:
    case u.BR: {
      j(e, t);
      break;
    }
    case u.TEMPLATE: {
      F(e, t);
      break;
    }
    default:
      e._err(t, E.endTagWithoutMatchingOpenElement);
  }
}
function j(e, t) {
  e._insertFakeElement(o.BODY, u.BODY), e.insertionMode = i.IN_BODY, ce(e, t);
}
function ce(e, t) {
  switch (t.type) {
    case _.CHARACTER: {
      lt(e, t);
      break;
    }
    case _.WHITESPACE_CHARACTER: {
      Tt(e, t);
      break;
    }
    case _.COMMENT: {
      be(e, t);
      break;
    }
    case _.START_TAG: {
      p(e, t);
      break;
    }
    case _.END_TAG: {
      oe(e, t);
      break;
    }
    case _.EOF: {
      _t(e, t);
      break;
    }
  }
}
function Tt(e, t) {
  e._reconstructActiveFormattingElements(), e._insertCharacters(t);
}
function lt(e, t) {
  e._reconstructActiveFormattingElements(), e._insertCharacters(t), e.framesetOk = !1;
}
function Aa(e, t) {
  e.openElements.tmplCount === 0 && e.treeAdapter.adoptAttributes(e.openElements.items[0], t.attrs);
}
function Na(e, t) {
  const a = e.openElements.tryPeekProperlyNestedBodyElement();
  a && e.openElements.tmplCount === 0 && (e.framesetOk = !1, e.treeAdapter.adoptAttributes(a, t.attrs));
}
function Ia(e, t) {
  const a = e.openElements.tryPeekProperlyNestedBodyElement();
  e.framesetOk && a && (e.treeAdapter.detachNode(a), e.openElements.popAllUpToHtmlElement(), e._insertElement(t, T.HTML), e.insertionMode = i.IN_FRAMESET);
}
function Ca(e, t) {
  e.openElements.hasInButtonScope(u.P) && e._closePElement(), e._insertElement(t, T.HTML);
}
function pa(e, t) {
  e.openElements.hasInButtonScope(u.P) && e._closePElement(), e.openElements.currentTagId !== void 0 && _e.has(e.openElements.currentTagId) && e.openElements.pop(), e._insertElement(t, T.HTML);
}
function Oa(e, t) {
  e.openElements.hasInButtonScope(u.P) && e._closePElement(), e._insertElement(t, T.HTML), e.skipNextNewLine = !0, e.framesetOk = !1;
}
function Sa(e, t) {
  const a = e.openElements.tmplCount > 0;
  (!e.formElement || a) && (e.openElements.hasInButtonScope(u.P) && e._closePElement(), e._insertElement(t, T.HTML), a || (e.formElement = e.openElements.current));
}
function La(e, t) {
  e.framesetOk = !1;
  const a = t.tagID;
  for (let s = e.openElements.stackTop; s >= 0; s--) {
    const c = e.openElements.tagIDs[s];
    if (a === u.LI && c === u.LI || (a === u.DD || a === u.DT) && (c === u.DD || c === u.DT)) {
      e.openElements.generateImpliedEndTagsWithExclusion(c), e.openElements.popUntilTagNamePopped(c);
      break;
    }
    if (c !== u.ADDRESS && c !== u.DIV && c !== u.P && e._isSpecialElement(e.openElements.items[s], c))
      break;
  }
  e.openElements.hasInButtonScope(u.P) && e._closePElement(), e._insertElement(t, T.HTML);
}
function ga(e, t) {
  e.openElements.hasInButtonScope(u.P) && e._closePElement(), e._insertElement(t, T.HTML), e.tokenizer.state = N.PLAINTEXT;
}
function Ra(e, t) {
  e.openElements.hasInScope(u.BUTTON) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(u.BUTTON)), e._reconstructActiveFormattingElements(), e._insertElement(t, T.HTML), e.framesetOk = !1;
}
function Da(e, t) {
  const a = e.activeFormattingElements.getElementEntryInScopeWithTagName(o.A);
  a && (Oe(e, t), e.openElements.remove(a.element), e.activeFormattingElements.removeEntry(a)), e._reconstructActiveFormattingElements(), e._insertElement(t, T.HTML), e.activeFormattingElements.pushElement(e.openElements.current, t);
}
function Pa(e, t) {
  e._reconstructActiveFormattingElements(), e._insertElement(t, T.HTML), e.activeFormattingElements.pushElement(e.openElements.current, t);
}
function Ma(e, t) {
  e._reconstructActiveFormattingElements(), e.openElements.hasInScope(u.NOBR) && (Oe(e, t), e._reconstructActiveFormattingElements()), e._insertElement(t, T.HTML), e.activeFormattingElements.pushElement(e.openElements.current, t);
}
function Ba(e, t) {
  e._reconstructActiveFormattingElements(), e._insertElement(t, T.HTML), e.activeFormattingElements.insertMarker(), e.framesetOk = !1;
}
function xa(e, t) {
  e.treeAdapter.getDocumentMode(e.document) !== L.QUIRKS && e.openElements.hasInButtonScope(u.P) && e._closePElement(), e._insertElement(t, T.HTML), e.framesetOk = !1, e.insertionMode = i.IN_TABLE;
}
function ht(e, t) {
  e._reconstructActiveFormattingElements(), e._appendElement(t, T.HTML), e.framesetOk = !1, t.ackSelfClosing = !0;
}
function ft(e) {
  const t = at(e, k.TYPE);
  return t != null && t.toLowerCase() === Ju;
}
function ka(e, t) {
  e._reconstructActiveFormattingElements(), e._appendElement(t, T.HTML), ft(t) || (e.framesetOk = !1), t.ackSelfClosing = !0;
}
function Ha(e, t) {
  e._appendElement(t, T.HTML), t.ackSelfClosing = !0;
}
function Fa(e, t) {
  e.openElements.hasInButtonScope(u.P) && e._closePElement(), e._appendElement(t, T.HTML), e.framesetOk = !1, t.ackSelfClosing = !0;
}
function Ua(e, t) {
  t.tagName = o.IMG, t.tagID = u.IMG, ht(e, t);
}
function ya(e, t) {
  e._insertElement(t, T.HTML), e.skipNextNewLine = !0, e.tokenizer.state = N.RCDATA, e.originalInsertionMode = e.insertionMode, e.framesetOk = !1, e.insertionMode = i.TEXT;
}
function wa(e, t) {
  e.openElements.hasInButtonScope(u.P) && e._closePElement(), e._reconstructActiveFormattingElements(), e.framesetOk = !1, e._switchToTextParsing(t, N.RAWTEXT);
}
function Ya(e, t) {
  e.framesetOk = !1, e._switchToTextParsing(t, N.RAWTEXT);
}
function qe(e, t) {
  e._switchToTextParsing(t, N.RAWTEXT);
}
function va(e, t) {
  e._reconstructActiveFormattingElements(), e._insertElement(t, T.HTML), e.framesetOk = !1, e.insertionMode = e.insertionMode === i.IN_TABLE || e.insertionMode === i.IN_CAPTION || e.insertionMode === i.IN_TABLE_BODY || e.insertionMode === i.IN_ROW || e.insertionMode === i.IN_CELL ? i.IN_SELECT_IN_TABLE : i.IN_SELECT;
}
function Qa(e, t) {
  e.openElements.currentTagId === u.OPTION && e.openElements.pop(), e._reconstructActiveFormattingElements(), e._insertElement(t, T.HTML);
}
function Ga(e, t) {
  e.openElements.hasInScope(u.RUBY) && e.openElements.generateImpliedEndTags(), e._insertElement(t, T.HTML);
}
function Wa(e, t) {
  e.openElements.hasInScope(u.RUBY) && e.openElements.generateImpliedEndTagsWithExclusion(u.RTC), e._insertElement(t, T.HTML);
}
function qa(e, t) {
  e._reconstructActiveFormattingElements(), ot(t), pe(t), t.selfClosing ? e._appendElement(t, T.MATHML) : e._insertElement(t, T.MATHML), t.ackSelfClosing = !0;
}
function Xa(e, t) {
  e._reconstructActiveFormattingElements(), dt(t), pe(t), t.selfClosing ? e._appendElement(t, T.SVG) : e._insertElement(t, T.SVG), t.ackSelfClosing = !0;
}
function Xe(e, t) {
  e._reconstructActiveFormattingElements(), e._insertElement(t, T.HTML);
}
function p(e, t) {
  switch (t.tagID) {
    case u.I:
    case u.S:
    case u.B:
    case u.U:
    case u.EM:
    case u.TT:
    case u.BIG:
    case u.CODE:
    case u.FONT:
    case u.SMALL:
    case u.STRIKE:
    case u.STRONG: {
      Pa(e, t);
      break;
    }
    case u.A: {
      Da(e, t);
      break;
    }
    case u.H1:
    case u.H2:
    case u.H3:
    case u.H4:
    case u.H5:
    case u.H6: {
      pa(e, t);
      break;
    }
    case u.P:
    case u.DL:
    case u.OL:
    case u.UL:
    case u.DIV:
    case u.DIR:
    case u.NAV:
    case u.MAIN:
    case u.MENU:
    case u.ASIDE:
    case u.CENTER:
    case u.FIGURE:
    case u.FOOTER:
    case u.HEADER:
    case u.HGROUP:
    case u.DIALOG:
    case u.DETAILS:
    case u.ADDRESS:
    case u.ARTICLE:
    case u.SEARCH:
    case u.SECTION:
    case u.SUMMARY:
    case u.FIELDSET:
    case u.BLOCKQUOTE:
    case u.FIGCAPTION: {
      Ca(e, t);
      break;
    }
    case u.LI:
    case u.DD:
    case u.DT: {
      La(e, t);
      break;
    }
    case u.BR:
    case u.IMG:
    case u.WBR:
    case u.AREA:
    case u.EMBED:
    case u.KEYGEN: {
      ht(e, t);
      break;
    }
    case u.HR: {
      Fa(e, t);
      break;
    }
    case u.RB:
    case u.RTC: {
      Ga(e, t);
      break;
    }
    case u.RT:
    case u.RP: {
      Wa(e, t);
      break;
    }
    case u.PRE:
    case u.LISTING: {
      Oa(e, t);
      break;
    }
    case u.XMP: {
      wa(e, t);
      break;
    }
    case u.SVG: {
      Xa(e, t);
      break;
    }
    case u.HTML: {
      Aa(e, t);
      break;
    }
    case u.BASE:
    case u.LINK:
    case u.META:
    case u.STYLE:
    case u.TITLE:
    case u.SCRIPT:
    case u.BGSOUND:
    case u.BASEFONT:
    case u.TEMPLATE: {
      g(e, t);
      break;
    }
    case u.BODY: {
      Na(e, t);
      break;
    }
    case u.FORM: {
      Sa(e, t);
      break;
    }
    case u.NOBR: {
      Ma(e, t);
      break;
    }
    case u.MATH: {
      qa(e, t);
      break;
    }
    case u.TABLE: {
      xa(e, t);
      break;
    }
    case u.INPUT: {
      ka(e, t);
      break;
    }
    case u.PARAM:
    case u.TRACK:
    case u.SOURCE: {
      Ha(e, t);
      break;
    }
    case u.IMAGE: {
      Ua(e, t);
      break;
    }
    case u.BUTTON: {
      Ra(e, t);
      break;
    }
    case u.APPLET:
    case u.OBJECT:
    case u.MARQUEE: {
      Ba(e, t);
      break;
    }
    case u.IFRAME: {
      Ya(e, t);
      break;
    }
    case u.SELECT: {
      va(e, t);
      break;
    }
    case u.OPTION:
    case u.OPTGROUP: {
      Qa(e, t);
      break;
    }
    case u.NOEMBED:
    case u.NOFRAMES: {
      qe(e, t);
      break;
    }
    case u.FRAMESET: {
      Ia(e, t);
      break;
    }
    case u.TEXTAREA: {
      ya(e, t);
      break;
    }
    case u.NOSCRIPT: {
      e.options.scriptingEnabled ? qe(e, t) : Xe(e, t);
      break;
    }
    case u.PLAINTEXT: {
      ga(e, t);
      break;
    }
    case u.COL:
    case u.TH:
    case u.TD:
    case u.TR:
    case u.HEAD:
    case u.FRAME:
    case u.TBODY:
    case u.TFOOT:
    case u.THEAD:
    case u.CAPTION:
    case u.COLGROUP:
      break;
    default:
      Xe(e, t);
  }
}
function Ka(e, t) {
  if (e.openElements.hasInScope(u.BODY) && (e.insertionMode = i.AFTER_BODY, e.options.sourceCodeLocationInfo)) {
    const a = e.openElements.tryPeekProperlyNestedBodyElement();
    a && e._setEndLocation(a, t);
  }
}
function Va(e, t) {
  e.openElements.hasInScope(u.BODY) && (e.insertionMode = i.AFTER_BODY, St(e, t));
}
function za(e, t) {
  const a = t.tagID;
  e.openElements.hasInScope(a) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(a));
}
function ja(e) {
  const t = e.openElements.tmplCount > 0, { formElement: a } = e;
  t || (e.formElement = null), (a || t) && e.openElements.hasInScope(u.FORM) && (e.openElements.generateImpliedEndTags(), t ? e.openElements.popUntilTagNamePopped(u.FORM) : a && e.openElements.remove(a));
}
function Ja(e) {
  e.openElements.hasInButtonScope(u.P) || e._insertFakeElement(o.P, u.P), e._closePElement();
}
function Za(e) {
  e.openElements.hasInListItemScope(u.LI) && (e.openElements.generateImpliedEndTagsWithExclusion(u.LI), e.openElements.popUntilTagNamePopped(u.LI));
}
function $a(e, t) {
  const a = t.tagID;
  e.openElements.hasInScope(a) && (e.openElements.generateImpliedEndTagsWithExclusion(a), e.openElements.popUntilTagNamePopped(a));
}
function es(e) {
  e.openElements.hasNumberedHeaderInScope() && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilNumberedHeaderPopped());
}
function ts(e, t) {
  const a = t.tagID;
  e.openElements.hasInScope(a) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(a), e.activeFormattingElements.clearToLastMarker());
}
function us(e) {
  e._reconstructActiveFormattingElements(), e._insertFakeElement(o.BR, u.BR), e.openElements.pop(), e.framesetOk = !1;
}
function mt(e, t) {
  const a = t.tagName, s = t.tagID;
  for (let c = e.openElements.stackTop; c > 0; c--) {
    const d = e.openElements.items[c], l = e.openElements.tagIDs[c];
    if (s === l && (s !== u.UNKNOWN || e.treeAdapter.getTagName(d) === a)) {
      e.openElements.generateImpliedEndTagsWithExclusion(s), e.openElements.stackTop >= c && e.openElements.shortenToLength(c);
      break;
    }
    if (e._isSpecialElement(d, l))
      break;
  }
}
function oe(e, t) {
  switch (t.tagID) {
    case u.A:
    case u.B:
    case u.I:
    case u.S:
    case u.U:
    case u.EM:
    case u.TT:
    case u.BIG:
    case u.CODE:
    case u.FONT:
    case u.NOBR:
    case u.SMALL:
    case u.STRIKE:
    case u.STRONG: {
      Oe(e, t);
      break;
    }
    case u.P: {
      Ja(e);
      break;
    }
    case u.DL:
    case u.UL:
    case u.OL:
    case u.DIR:
    case u.DIV:
    case u.NAV:
    case u.PRE:
    case u.MAIN:
    case u.MENU:
    case u.ASIDE:
    case u.BUTTON:
    case u.CENTER:
    case u.FIGURE:
    case u.FOOTER:
    case u.HEADER:
    case u.HGROUP:
    case u.DIALOG:
    case u.ADDRESS:
    case u.ARTICLE:
    case u.DETAILS:
    case u.SEARCH:
    case u.SECTION:
    case u.SUMMARY:
    case u.LISTING:
    case u.FIELDSET:
    case u.BLOCKQUOTE:
    case u.FIGCAPTION: {
      za(e, t);
      break;
    }
    case u.LI: {
      Za(e);
      break;
    }
    case u.DD:
    case u.DT: {
      $a(e, t);
      break;
    }
    case u.H1:
    case u.H2:
    case u.H3:
    case u.H4:
    case u.H5:
    case u.H6: {
      es(e);
      break;
    }
    case u.BR: {
      us(e);
      break;
    }
    case u.BODY: {
      Ka(e, t);
      break;
    }
    case u.HTML: {
      Va(e, t);
      break;
    }
    case u.FORM: {
      ja(e);
      break;
    }
    case u.APPLET:
    case u.OBJECT:
    case u.MARQUEE: {
      ts(e, t);
      break;
    }
    case u.TEMPLATE: {
      F(e, t);
      break;
    }
    default:
      mt(e, t);
  }
}
function _t(e, t) {
  e.tmplInsertionModeStack.length > 0 ? Ot(e, t) : Se(e, t);
}
function as(e, t) {
  var a;
  t.tagID === u.SCRIPT && ((a = e.scriptHandler) === null || a === void 0 || a.call(e, e.openElements.current)), e.openElements.pop(), e.insertionMode = e.originalInsertionMode;
}
function ss(e, t) {
  e._err(t, E.eofInElementThatCanContainOnlyText), e.openElements.pop(), e.insertionMode = e.originalInsertionMode, e.onEof(t);
}
function le(e, t) {
  if (e.openElements.currentTagId !== void 0 && Et.has(e.openElements.currentTagId))
    switch (e.pendingCharacterTokens.length = 0, e.hasNonWhitespacePendingCharacterToken = !1, e.originalInsertionMode = e.insertionMode, e.insertionMode = i.IN_TABLE_TEXT, t.type) {
      case _.CHARACTER: {
        At(e, t);
        break;
      }
      case _.WHITESPACE_CHARACTER: {
        bt(e, t);
        break;
      }
    }
  else
    $(e, t);
}
function rs(e, t) {
  e.openElements.clearBackToTableContext(), e.activeFormattingElements.insertMarker(), e._insertElement(t, T.HTML), e.insertionMode = i.IN_CAPTION;
}
function ns(e, t) {
  e.openElements.clearBackToTableContext(), e._insertElement(t, T.HTML), e.insertionMode = i.IN_COLUMN_GROUP;
}
function is(e, t) {
  e.openElements.clearBackToTableContext(), e._insertFakeElement(o.COLGROUP, u.COLGROUP), e.insertionMode = i.IN_COLUMN_GROUP, Le(e, t);
}
function cs(e, t) {
  e.openElements.clearBackToTableContext(), e._insertElement(t, T.HTML), e.insertionMode = i.IN_TABLE_BODY;
}
function os(e, t) {
  e.openElements.clearBackToTableContext(), e._insertFakeElement(o.TBODY, u.TBODY), e.insertionMode = i.IN_TABLE_BODY, de(e, t);
}
function ds(e, t) {
  e.openElements.hasInTableScope(u.TABLE) && (e.openElements.popUntilTagNamePopped(u.TABLE), e._resetInsertionMode(), e._processStartTag(t));
}
function Es(e, t) {
  ft(t) ? e._appendElement(t, T.HTML) : $(e, t), t.ackSelfClosing = !0;
}
function Ts(e, t) {
  !e.formElement && e.openElements.tmplCount === 0 && (e._insertElement(t, T.HTML), e.formElement = e.openElements.current, e.openElements.pop());
}
function w(e, t) {
  switch (t.tagID) {
    case u.TD:
    case u.TH:
    case u.TR: {
      os(e, t);
      break;
    }
    case u.STYLE:
    case u.SCRIPT:
    case u.TEMPLATE: {
      g(e, t);
      break;
    }
    case u.COL: {
      is(e, t);
      break;
    }
    case u.FORM: {
      Ts(e, t);
      break;
    }
    case u.TABLE: {
      ds(e, t);
      break;
    }
    case u.TBODY:
    case u.TFOOT:
    case u.THEAD: {
      cs(e, t);
      break;
    }
    case u.INPUT: {
      Es(e, t);
      break;
    }
    case u.CAPTION: {
      rs(e, t);
      break;
    }
    case u.COLGROUP: {
      ns(e, t);
      break;
    }
    default:
      $(e, t);
  }
}
function J(e, t) {
  switch (t.tagID) {
    case u.TABLE: {
      e.openElements.hasInTableScope(u.TABLE) && (e.openElements.popUntilTagNamePopped(u.TABLE), e._resetInsertionMode());
      break;
    }
    case u.TEMPLATE: {
      F(e, t);
      break;
    }
    case u.BODY:
    case u.CAPTION:
    case u.COL:
    case u.COLGROUP:
    case u.HTML:
    case u.TBODY:
    case u.TD:
    case u.TFOOT:
    case u.TH:
    case u.THEAD:
    case u.TR:
      break;
    default:
      $(e, t);
  }
}
function $(e, t) {
  const a = e.fosterParentingEnabled;
  e.fosterParentingEnabled = !0, ce(e, t), e.fosterParentingEnabled = a;
}
function bt(e, t) {
  e.pendingCharacterTokens.push(t);
}
function At(e, t) {
  e.pendingCharacterTokens.push(t), e.hasNonWhitespacePendingCharacterToken = !0;
}
function W(e, t) {
  let a = 0;
  if (e.hasNonWhitespacePendingCharacterToken)
    for (; a < e.pendingCharacterTokens.length; a++)
      $(e, e.pendingCharacterTokens[a]);
  else
    for (; a < e.pendingCharacterTokens.length; a++)
      e._insertCharacters(e.pendingCharacterTokens[a]);
  e.insertionMode = e.originalInsertionMode, e._processToken(t);
}
const Nt = /* @__PURE__ */ new Set([u.CAPTION, u.COL, u.COLGROUP, u.TBODY, u.TD, u.TFOOT, u.TH, u.THEAD, u.TR]);
function ls(e, t) {
  const a = t.tagID;
  Nt.has(a) ? e.openElements.hasInTableScope(u.CAPTION) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(u.CAPTION), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = i.IN_TABLE, w(e, t)) : p(e, t);
}
function hs(e, t) {
  const a = t.tagID;
  switch (a) {
    case u.CAPTION:
    case u.TABLE: {
      e.openElements.hasInTableScope(u.CAPTION) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(u.CAPTION), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = i.IN_TABLE, a === u.TABLE && J(e, t));
      break;
    }
    case u.BODY:
    case u.COL:
    case u.COLGROUP:
    case u.HTML:
    case u.TBODY:
    case u.TD:
    case u.TFOOT:
    case u.TH:
    case u.THEAD:
    case u.TR:
      break;
    default:
      oe(e, t);
  }
}
function Le(e, t) {
  switch (t.tagID) {
    case u.HTML: {
      p(e, t);
      break;
    }
    case u.COL: {
      e._appendElement(t, T.HTML), t.ackSelfClosing = !0;
      break;
    }
    case u.TEMPLATE: {
      g(e, t);
      break;
    }
    default:
      re(e, t);
  }
}
function fs(e, t) {
  switch (t.tagID) {
    case u.COLGROUP: {
      e.openElements.currentTagId === u.COLGROUP && (e.openElements.pop(), e.insertionMode = i.IN_TABLE);
      break;
    }
    case u.TEMPLATE: {
      F(e, t);
      break;
    }
    case u.COL:
      break;
    default:
      re(e, t);
  }
}
function re(e, t) {
  e.openElements.currentTagId === u.COLGROUP && (e.openElements.pop(), e.insertionMode = i.IN_TABLE, e._processToken(t));
}
function de(e, t) {
  switch (t.tagID) {
    case u.TR: {
      e.openElements.clearBackToTableBodyContext(), e._insertElement(t, T.HTML), e.insertionMode = i.IN_ROW;
      break;
    }
    case u.TH:
    case u.TD: {
      e.openElements.clearBackToTableBodyContext(), e._insertFakeElement(o.TR, u.TR), e.insertionMode = i.IN_ROW, Ee(e, t);
      break;
    }
    case u.CAPTION:
    case u.COL:
    case u.COLGROUP:
    case u.TBODY:
    case u.TFOOT:
    case u.THEAD: {
      e.openElements.hasTableBodyContextInTableScope() && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = i.IN_TABLE, w(e, t));
      break;
    }
    default:
      w(e, t);
  }
}
function Ae(e, t) {
  const a = t.tagID;
  switch (t.tagID) {
    case u.TBODY:
    case u.TFOOT:
    case u.THEAD: {
      e.openElements.hasInTableScope(a) && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = i.IN_TABLE);
      break;
    }
    case u.TABLE: {
      e.openElements.hasTableBodyContextInTableScope() && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = i.IN_TABLE, J(e, t));
      break;
    }
    case u.BODY:
    case u.CAPTION:
    case u.COL:
    case u.COLGROUP:
    case u.HTML:
    case u.TD:
    case u.TH:
    case u.TR:
      break;
    default:
      J(e, t);
  }
}
function Ee(e, t) {
  switch (t.tagID) {
    case u.TH:
    case u.TD: {
      e.openElements.clearBackToTableRowContext(), e._insertElement(t, T.HTML), e.insertionMode = i.IN_CELL, e.activeFormattingElements.insertMarker();
      break;
    }
    case u.CAPTION:
    case u.COL:
    case u.COLGROUP:
    case u.TBODY:
    case u.TFOOT:
    case u.THEAD:
    case u.TR: {
      e.openElements.hasInTableScope(u.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = i.IN_TABLE_BODY, de(e, t));
      break;
    }
    default:
      w(e, t);
  }
}
function It(e, t) {
  switch (t.tagID) {
    case u.TR: {
      e.openElements.hasInTableScope(u.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = i.IN_TABLE_BODY);
      break;
    }
    case u.TABLE: {
      e.openElements.hasInTableScope(u.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = i.IN_TABLE_BODY, Ae(e, t));
      break;
    }
    case u.TBODY:
    case u.TFOOT:
    case u.THEAD: {
      (e.openElements.hasInTableScope(t.tagID) || e.openElements.hasInTableScope(u.TR)) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = i.IN_TABLE_BODY, Ae(e, t));
      break;
    }
    case u.BODY:
    case u.CAPTION:
    case u.COL:
    case u.COLGROUP:
    case u.HTML:
    case u.TD:
    case u.TH:
      break;
    default:
      J(e, t);
  }
}
function ms(e, t) {
  const a = t.tagID;
  Nt.has(a) ? (e.openElements.hasInTableScope(u.TD) || e.openElements.hasInTableScope(u.TH)) && (e._closeTableCell(), Ee(e, t)) : p(e, t);
}
function _s(e, t) {
  const a = t.tagID;
  switch (a) {
    case u.TD:
    case u.TH: {
      e.openElements.hasInTableScope(a) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(a), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = i.IN_ROW);
      break;
    }
    case u.TABLE:
    case u.TBODY:
    case u.TFOOT:
    case u.THEAD:
    case u.TR: {
      e.openElements.hasInTableScope(a) && (e._closeTableCell(), It(e, t));
      break;
    }
    case u.BODY:
    case u.CAPTION:
    case u.COL:
    case u.COLGROUP:
    case u.HTML:
      break;
    default:
      oe(e, t);
  }
}
function Ct(e, t) {
  switch (t.tagID) {
    case u.HTML: {
      p(e, t);
      break;
    }
    case u.OPTION: {
      e.openElements.currentTagId === u.OPTION && e.openElements.pop(), e._insertElement(t, T.HTML);
      break;
    }
    case u.OPTGROUP: {
      e.openElements.currentTagId === u.OPTION && e.openElements.pop(), e.openElements.currentTagId === u.OPTGROUP && e.openElements.pop(), e._insertElement(t, T.HTML);
      break;
    }
    case u.HR: {
      e.openElements.currentTagId === u.OPTION && e.openElements.pop(), e.openElements.currentTagId === u.OPTGROUP && e.openElements.pop(), e._appendElement(t, T.HTML), t.ackSelfClosing = !0;
      break;
    }
    case u.INPUT:
    case u.KEYGEN:
    case u.TEXTAREA:
    case u.SELECT: {
      e.openElements.hasInSelectScope(u.SELECT) && (e.openElements.popUntilTagNamePopped(u.SELECT), e._resetInsertionMode(), t.tagID !== u.SELECT && e._processStartTag(t));
      break;
    }
    case u.SCRIPT:
    case u.TEMPLATE: {
      g(e, t);
      break;
    }
  }
}
function pt(e, t) {
  switch (t.tagID) {
    case u.OPTGROUP: {
      e.openElements.stackTop > 0 && e.openElements.currentTagId === u.OPTION && e.openElements.tagIDs[e.openElements.stackTop - 1] === u.OPTGROUP && e.openElements.pop(), e.openElements.currentTagId === u.OPTGROUP && e.openElements.pop();
      break;
    }
    case u.OPTION: {
      e.openElements.currentTagId === u.OPTION && e.openElements.pop();
      break;
    }
    case u.SELECT: {
      e.openElements.hasInSelectScope(u.SELECT) && (e.openElements.popUntilTagNamePopped(u.SELECT), e._resetInsertionMode());
      break;
    }
    case u.TEMPLATE: {
      F(e, t);
      break;
    }
  }
}
function bs(e, t) {
  const a = t.tagID;
  a === u.CAPTION || a === u.TABLE || a === u.TBODY || a === u.TFOOT || a === u.THEAD || a === u.TR || a === u.TD || a === u.TH ? (e.openElements.popUntilTagNamePopped(u.SELECT), e._resetInsertionMode(), e._processStartTag(t)) : Ct(e, t);
}
function As(e, t) {
  const a = t.tagID;
  a === u.CAPTION || a === u.TABLE || a === u.TBODY || a === u.TFOOT || a === u.THEAD || a === u.TR || a === u.TD || a === u.TH ? e.openElements.hasInTableScope(a) && (e.openElements.popUntilTagNamePopped(u.SELECT), e._resetInsertionMode(), e.onEndTag(t)) : pt(e, t);
}
function Ns(e, t) {
  switch (t.tagID) {
    case u.BASE:
    case u.BASEFONT:
    case u.BGSOUND:
    case u.LINK:
    case u.META:
    case u.NOFRAMES:
    case u.SCRIPT:
    case u.STYLE:
    case u.TEMPLATE:
    case u.TITLE: {
      g(e, t);
      break;
    }
    case u.CAPTION:
    case u.COLGROUP:
    case u.TBODY:
    case u.TFOOT:
    case u.THEAD: {
      e.tmplInsertionModeStack[0] = i.IN_TABLE, e.insertionMode = i.IN_TABLE, w(e, t);
      break;
    }
    case u.COL: {
      e.tmplInsertionModeStack[0] = i.IN_COLUMN_GROUP, e.insertionMode = i.IN_COLUMN_GROUP, Le(e, t);
      break;
    }
    case u.TR: {
      e.tmplInsertionModeStack[0] = i.IN_TABLE_BODY, e.insertionMode = i.IN_TABLE_BODY, de(e, t);
      break;
    }
    case u.TD:
    case u.TH: {
      e.tmplInsertionModeStack[0] = i.IN_ROW, e.insertionMode = i.IN_ROW, Ee(e, t);
      break;
    }
    default:
      e.tmplInsertionModeStack[0] = i.IN_BODY, e.insertionMode = i.IN_BODY, p(e, t);
  }
}
function Is(e, t) {
  t.tagID === u.TEMPLATE && F(e, t);
}
function Ot(e, t) {
  e.openElements.tmplCount > 0 ? (e.openElements.popUntilTagNamePopped(u.TEMPLATE), e.activeFormattingElements.clearToLastMarker(), e.tmplInsertionModeStack.shift(), e._resetInsertionMode(), e.onEof(t)) : Se(e, t);
}
function Cs(e, t) {
  t.tagID === u.HTML ? p(e, t) : ne(e, t);
}
function St(e, t) {
  var a;
  if (t.tagID === u.HTML) {
    if (e.fragmentContext || (e.insertionMode = i.AFTER_AFTER_BODY), e.options.sourceCodeLocationInfo && e.openElements.tagIDs[0] === u.HTML) {
      e._setEndLocation(e.openElements.items[0], t);
      const s = e.openElements.items[1];
      s && !(!((a = e.treeAdapter.getNodeSourceCodeLocation(s)) === null || a === void 0) && a.endTag) && e._setEndLocation(s, t);
    }
  } else
    ne(e, t);
}
function ne(e, t) {
  e.insertionMode = i.IN_BODY, ce(e, t);
}
function ps(e, t) {
  switch (t.tagID) {
    case u.HTML: {
      p(e, t);
      break;
    }
    case u.FRAMESET: {
      e._insertElement(t, T.HTML);
      break;
    }
    case u.FRAME: {
      e._appendElement(t, T.HTML), t.ackSelfClosing = !0;
      break;
    }
    case u.NOFRAMES: {
      g(e, t);
      break;
    }
  }
}
function Os(e, t) {
  t.tagID === u.FRAMESET && !e.openElements.isRootHtmlElementCurrent() && (e.openElements.pop(), !e.fragmentContext && e.openElements.currentTagId !== u.FRAMESET && (e.insertionMode = i.AFTER_FRAMESET));
}
function Ss(e, t) {
  switch (t.tagID) {
    case u.HTML: {
      p(e, t);
      break;
    }
    case u.NOFRAMES: {
      g(e, t);
      break;
    }
  }
}
function Ls(e, t) {
  t.tagID === u.HTML && (e.insertionMode = i.AFTER_AFTER_FRAMESET);
}
function gs(e, t) {
  t.tagID === u.HTML ? p(e, t) : ae(e, t);
}
function ae(e, t) {
  e.insertionMode = i.IN_BODY, ce(e, t);
}
function Rs(e, t) {
  switch (t.tagID) {
    case u.HTML: {
      p(e, t);
      break;
    }
    case u.NOFRAMES: {
      g(e, t);
      break;
    }
  }
}
function Ds(e, t) {
  t.chars = A, e._insertCharacters(t);
}
function Ps(e, t) {
  e._insertCharacters(t), e.framesetOk = !1;
}
function Lt(e) {
  for (; e.treeAdapter.getNamespaceURI(e.openElements.current) !== T.HTML && e.openElements.currentTagId !== void 0 && !e._isIntegrationPoint(e.openElements.currentTagId, e.openElements.current); )
    e.openElements.pop();
}
function Ms(e, t) {
  if (Xu(t))
    Lt(e), e._startTagOutsideForeignContent(t);
  else {
    const a = e._getAdjustedCurrentElement(), s = e.treeAdapter.getNamespaceURI(a);
    s === T.MATHML ? ot(t) : s === T.SVG && (Ku(t), dt(t)), pe(t), t.selfClosing ? e._appendElement(t, s) : e._insertElement(t, s), t.ackSelfClosing = !0;
  }
}
function Bs(e, t) {
  if (t.tagID === u.P || t.tagID === u.BR) {
    Lt(e), e._endTagOutsideForeignContent(t);
    return;
  }
  for (let a = e.openElements.stackTop; a > 0; a--) {
    const s = e.openElements.items[a];
    if (e.treeAdapter.getNamespaceURI(s) === T.HTML) {
      e._endTagOutsideForeignContent(t);
      break;
    }
    const c = e.treeAdapter.getTagName(s);
    if (c.toLowerCase() === t.tagName) {
      t.tagName = c, e.openElements.shortenToLength(a);
      break;
    }
  }
}
o.AREA, o.BASE, o.BASEFONT, o.BGSOUND, o.BR, o.COL, o.EMBED, o.FRAME, o.HR, o.IMG, o.INPUT, o.KEYGEN, o.LINK, o.META, o.PARAM, o.SOURCE, o.TRACK, o.WBR;
const xs = /<(\/?)(iframe|noembed|noframes|plaintext|script|style|textarea|title|xmp)(?=[\t\n\f\r />])/gi, ks = /* @__PURE__ */ new Set([
  "mdxFlowExpression",
  "mdxJsxFlowElement",
  "mdxJsxTextElement",
  "mdxTextExpression",
  "mdxjsEsm"
]), Ke = { sourceCodeLocationInfo: !0, scriptingEnabled: !1 };
function gt(e, t) {
  const a = Ws(e), s = Ve("type", {
    handlers: { root: Hs, element: Fs, text: Us, comment: Dt, doctype: ys, raw: Ys },
    unknown: vs
  }), c = {
    parser: a ? new We(Ke) : We.getFragmentParser(void 0, Ke),
    handle(m) {
      s(m, c);
    },
    stitches: !1,
    options: t || {}
  };
  s(e, c), Q(c, H());
  const d = a ? c.parser.document : c.parser.getFragment(), l = qt(d, {
    // To do: support `space`?
    file: c.options.file
  });
  return c.stitches && kt(l, "comment", function(m, f, b) {
    const S = (
      /** @type {Stitch} */
      /** @type {unknown} */
      m
    );
    if (S.value.stitch && b && f !== void 0) {
      const U = b.children;
      return U[f] = S.value.stitch, f;
    }
  }), l.type === "root" && l.children.length === 1 && l.children[0].type === e.type ? l.children[0] : l;
}
function Rt(e, t) {
  let a = -1;
  if (e)
    for (; ++a < e.length; )
      t.handle(e[a]);
}
function Hs(e, t) {
  Rt(e.children, t);
}
function Fs(e, t) {
  Qs(e, t), Rt(e.children, t), Gs(e, t);
}
function Us(e, t) {
  t.parser.tokenizer.state > 4 && (t.parser.tokenizer.state = 0);
  const a = {
    type: _.CHARACTER,
    chars: e.value,
    location: ee(e)
  };
  Q(t, H(e)), t.parser.currentToken = a, t.parser._processToken(t.parser.currentToken);
}
function ys(e, t) {
  const a = {
    type: _.DOCTYPE,
    name: "html",
    forceQuirks: !1,
    publicId: "",
    systemId: "",
    location: ee(e)
  };
  Q(t, H(e)), t.parser.currentToken = a, t.parser._processToken(t.parser.currentToken);
}
function ws(e, t) {
  t.stitches = !0;
  const a = qs(e);
  if ("children" in e && "children" in a) {
    const s = (
      /** @type {Root} */
      gt({ type: "root", children: e.children }, t.options)
    );
    a.children = s.children;
  }
  Dt({ type: "comment", value: { stitch: a } }, t);
}
function Dt(e, t) {
  const a = e.value, s = {
    type: _.COMMENT,
    data: a,
    location: ee(e)
  };
  Q(t, H(e)), t.parser.currentToken = s, t.parser._processToken(t.parser.currentToken);
}
function Ys(e, t) {
  if (t.parser.tokenizer.preprocessor.html = "", t.parser.tokenizer.preprocessor.pos = -1, t.parser.tokenizer.preprocessor.lastGapPos = -2, t.parser.tokenizer.preprocessor.gapStack = [], t.parser.tokenizer.preprocessor.skipNextNewLine = !1, t.parser.tokenizer.preprocessor.lastChunkWritten = !1, t.parser.tokenizer.preprocessor.endOfChunkHit = !1, t.parser.tokenizer.preprocessor.isEol = !1, Pt(t, H(e)), t.parser.tokenizer.write(
    t.options.tagfilter ? e.value.replace(xs, "&lt;$1$2") : e.value,
    !1
  ), t.parser.tokenizer._runParsingLoop(), t.parser.tokenizer.state === 72 || // @ts-expect-error: removed.
  t.parser.tokenizer.state === 78) {
    t.parser.tokenizer.preprocessor.lastChunkWritten = !0;
    const a = t.parser.tokenizer._consume();
    t.parser.tokenizer._callState(a);
  }
}
function vs(e, t) {
  const a = (
    /** @type {Nodes} */
    e
  );
  if (t.options.passThrough && t.options.passThrough.includes(a.type))
    ws(a, t);
  else {
    let s = "";
    throw ks.has(a.type) && (s = ". It looks like you are using MDX nodes with `hast-util-raw` (or `rehype-raw`). If you use this because you are using remark or rehype plugins that inject `'html'` nodes, then please raise an issue with that plugin, as its a bad and slow idea. If you use this because you are using markdown syntax, then you have to configure this utility (or plugin) to pass through these nodes (see `passThrough` in docs), but you can also migrate to use the MDX syntax"), new Error("Cannot compile `" + a.type + "` node" + s);
  }
}
function Q(e, t) {
  Pt(e, t);
  const a = e.parser.tokenizer.currentCharacterToken;
  a && a.location && (a.location.endLine = e.parser.tokenizer.preprocessor.line, a.location.endCol = e.parser.tokenizer.preprocessor.col + 1, a.location.endOffset = e.parser.tokenizer.preprocessor.offset + 1, e.parser.currentToken = a, e.parser._processToken(e.parser.currentToken)), e.parser.tokenizer.paused = !1, e.parser.tokenizer.inLoop = !1, e.parser.tokenizer.active = !1, e.parser.tokenizer.returnState = N.DATA, e.parser.tokenizer.charRefCode = -1, e.parser.tokenizer.consumedAfterSnapshot = -1, e.parser.tokenizer.currentLocation = null, e.parser.tokenizer.currentCharacterToken = null, e.parser.tokenizer.currentToken = null, e.parser.tokenizer.currentAttr = { name: "", value: "" };
}
function Pt(e, t) {
  if (t && t.offset !== void 0) {
    const a = {
      startLine: t.line,
      startCol: t.column,
      startOffset: t.offset,
      endLine: -1,
      endCol: -1,
      endOffset: -1
    };
    e.parser.tokenizer.preprocessor.lineStartPos = -t.column + 1, e.parser.tokenizer.preprocessor.droppedBufferSize = t.offset, e.parser.tokenizer.preprocessor.line = t.line, e.parser.tokenizer.currentLocation = a;
  }
}
function Qs(e, t) {
  const a = e.tagName.toLowerCase();
  if (t.parser.tokenizer.state === N.PLAINTEXT) return;
  Q(t, H(e));
  const s = t.parser.openElements.current;
  let c = "namespaceURI" in s ? s.namespaceURI : x.html;
  c === x.html && a === "svg" && (c = x.svg);
  const d = jt(
    // Shallow clone to not delve into `children`: we only need the attributes.
    { ...e, children: [] },
    { space: c === x.svg ? "svg" : "html" }
  ), l = {
    type: _.START_TAG,
    tagName: a,
    tagID: v(a),
    // We always send start and end tags.
    selfClosing: !1,
    ackSelfClosing: !1,
    // Always element.
    /* c8 ignore next */
    attrs: "attrs" in d ? d.attrs : [],
    location: ee(e)
  };
  t.parser.currentToken = l, t.parser._processToken(t.parser.currentToken), t.parser.tokenizer.lastStartTagName = a;
}
function Gs(e, t) {
  const a = e.tagName.toLowerCase();
  if (!t.parser.tokenizer.inForeignNode && su.includes(a) || t.parser.tokenizer.state === N.PLAINTEXT) return;
  Q(t, ze(e));
  const s = {
    type: _.END_TAG,
    tagName: a,
    tagID: v(a),
    selfClosing: !1,
    ackSelfClosing: !1,
    attrs: [],
    location: ee(e)
  };
  t.parser.currentToken = s, t.parser._processToken(t.parser.currentToken), // Current element is closed.
  a === t.parser.tokenizer.lastStartTagName && // `<textarea>` and `<title>`
  (t.parser.tokenizer.state === N.RCDATA || // `<iframe>`, `<noembed>`, `<noframes>`, `<style>`, `<xmp>`
  t.parser.tokenizer.state === N.RAWTEXT || // `<script>`
  t.parser.tokenizer.state === N.SCRIPT_DATA) && (t.parser.tokenizer.state = N.DATA);
}
function Ws(e) {
  const t = e.type === "root" ? e.children[0] : e;
  return !!(t && (t.type === "doctype" || t.type === "element" && t.tagName.toLowerCase() === "html"));
}
function ee(e) {
  const t = H(e) || {
    line: void 0,
    column: void 0,
    offset: void 0
  }, a = ze(e) || {
    line: void 0,
    column: void 0,
    offset: void 0
  };
  return {
    startLine: t.line,
    startCol: t.column,
    startOffset: t.offset,
    endLine: a.line,
    endCol: a.column,
    endOffset: a.offset
  };
}
function qs(e) {
  return "children" in e ? Pe({ ...e, children: [] }) : Pe(e);
}
function Ks(e) {
  return function(t, a) {
    return (
      /** @type {Root} */
      gt(t, { ...e, file: a })
    );
  };
}
export {
  Ks as default
};
