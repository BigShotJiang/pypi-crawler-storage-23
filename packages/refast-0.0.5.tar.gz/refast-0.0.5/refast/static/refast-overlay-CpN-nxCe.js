import { j as r } from "./refast-markdown-ByFT1VZb.js";
import { r as i } from "./refast-charts-C9YTpQC6.js";
import { m as jt, n as Mt, u as yt, F as Nt, c as L, a as re, S as ae, b as se, d as Pt, e as ie, I as de, f as ce, g as le, h as ue, L as pe, i as fe, j as me, A as xe, k as ge, G as he, l as ve, o as N, D as P, T as R, P as _, O as D, C as S, p as M, R as y } from "./refast-index-D9xrDqow.js";
import { o as Ce, c as F, q as X, v as Rt, w as z, u as Z, P as A, b as h, A as q, a as H, x as be, n as V, y as we, D as je, C as Me, t as _t, j as u, m as ye } from "./refast-index-iXHSFA1L.js";
// @__NO_SIDE_EFFECTS__
function Dt(e) {
  const t = /* @__PURE__ */ St(e), o = i.forwardRef((n, a) => {
    const { children: s, ...d } = n, c = i.Children.toArray(s), l = c.find(Et);
    if (l) {
      const f = l.props.children, p = c.map((m) => m === l ? i.Children.count(f) > 1 ? i.Children.only(null) : i.isValidElement(f) ? f.props.children : null : m);
      return /* @__PURE__ */ r.jsx(t, { ...d, ref: a, children: i.isValidElement(f) ? i.cloneElement(f, void 0, p) : null });
    }
    return /* @__PURE__ */ r.jsx(t, { ...d, ref: a, children: s });
  });
  return o.displayName = `${e}.Slot`, o;
}
// @__NO_SIDE_EFFECTS__
function St(e) {
  const t = i.forwardRef((o, n) => {
    const { children: a, ...s } = o;
    if (i.isValidElement(a)) {
      const d = Tt(a), c = Ot(s, a.props);
      return a.type !== i.Fragment && (c.ref = n ? Ce(n, d) : d), i.cloneElement(a, c);
    }
    return i.Children.count(a) > 1 ? i.Children.only(null) : null;
  });
  return t.displayName = `${e}.SlotClone`, t;
}
var At = Symbol("radix.slottable");
function Et(e) {
  return i.isValidElement(e) && typeof e.type == "function" && "__radixId" in e.type && e.type.__radixId === At;
}
function Ot(e, t) {
  const o = { ...t };
  for (const n in t) {
    const a = e[n], s = t[n];
    /^on[A-Z]/.test(n) ? a && s ? o[n] = (...c) => {
      const l = s(...c);
      return a(...c), l;
    } : a && (o[n] = a) : n === "style" ? o[n] = { ...a, ...s } : n === "className" && (o[n] = [a, s].filter(Boolean).join(" "));
  }
  return { ...e, ...o };
}
function Tt(e) {
  var n, a;
  let t = (n = Object.getOwnPropertyDescriptor(e.props, "ref")) == null ? void 0 : n.get, o = t && "isReactWarning" in t && t.isReactWarning;
  return o ? e.ref : (t = (a = Object.getOwnPropertyDescriptor(e, "ref")) == null ? void 0 : a.get, o = t && "isReactWarning" in t && t.isReactWarning, o ? e.props.ref : e.props.ref || e.ref);
}
var G = "Popover", [Ne] = F(G, [
  z
]), E = z(), [It, w] = Ne(G), Pe = (e) => {
  const {
    __scopePopover: t,
    children: o,
    open: n,
    defaultOpen: a,
    onOpenChange: s,
    modal: d = !1
  } = e, c = E(t), l = i.useRef(null), [f, p] = i.useState(!1), [m, x] = H({
    prop: n,
    defaultProp: a ?? !1,
    onChange: s,
    caller: G
  });
  return /* @__PURE__ */ r.jsx(be, { ...c, children: /* @__PURE__ */ r.jsx(
    It,
    {
      scope: t,
      contentId: V(),
      triggerRef: l,
      open: m,
      onOpenChange: x,
      onOpenToggle: i.useCallback(() => x((b) => !b), [x]),
      hasCustomAnchor: f,
      onCustomAnchorAdd: i.useCallback(() => p(!0), []),
      onCustomAnchorRemove: i.useCallback(() => p(!1), []),
      modal: d,
      children: o
    }
  ) });
};
Pe.displayName = G;
var Re = "PopoverAnchor", kt = i.forwardRef(
  (e, t) => {
    const { __scopePopover: o, ...n } = e, a = w(Re, o), s = E(o), { onCustomAnchorAdd: d, onCustomAnchorRemove: c } = a;
    return i.useEffect(() => (d(), () => c()), [d, c]), /* @__PURE__ */ r.jsx(q, { ...s, ...n, ref: t });
  }
);
kt.displayName = Re;
var _e = "PopoverTrigger", De = i.forwardRef(
  (e, t) => {
    const { __scopePopover: o, ...n } = e, a = w(_e, o), s = E(o), d = Z(t, a.triggerRef), c = /* @__PURE__ */ r.jsx(
      A.button,
      {
        type: "button",
        "aria-haspopup": "dialog",
        "aria-expanded": a.open,
        "aria-controls": a.contentId,
        "data-state": Ie(a.open),
        ...n,
        ref: d,
        onClick: h(e.onClick, a.onOpenToggle)
      }
    );
    return a.hasCustomAnchor ? c : /* @__PURE__ */ r.jsx(q, { asChild: !0, ...s, children: c });
  }
);
De.displayName = _e;
var Y = "PopoverPortal", [$t, Lt] = Ne(Y, {
  forceMount: void 0
}), Se = (e) => {
  const { __scopePopover: t, forceMount: o, children: n, container: a } = e, s = w(Y, t);
  return /* @__PURE__ */ r.jsx($t, { scope: t, forceMount: o, children: /* @__PURE__ */ r.jsx(X, { present: o || s.open, children: /* @__PURE__ */ r.jsx(Rt, { asChild: !0, container: a, children: n }) }) });
};
Se.displayName = Y;
var j = "PopoverContent", Ae = i.forwardRef(
  (e, t) => {
    const o = Lt(j, e.__scopePopover), { forceMount: n = o.forceMount, ...a } = e, s = w(j, e.__scopePopover);
    return /* @__PURE__ */ r.jsx(X, { present: n || s.open, children: s.modal ? /* @__PURE__ */ r.jsx(zt, { ...a, ref: t }) : /* @__PURE__ */ r.jsx(Ht, { ...a, ref: t }) });
  }
);
Ae.displayName = j;
var Ft = /* @__PURE__ */ Dt("PopoverContent.RemoveScroll"), zt = i.forwardRef(
  (e, t) => {
    const o = w(j, e.__scopePopover), n = i.useRef(null), a = Z(t, n), s = i.useRef(!1);
    return i.useEffect(() => {
      const d = n.current;
      if (d) return jt(d);
    }, []), /* @__PURE__ */ r.jsx(Mt, { as: Ft, allowPinchZoom: !0, children: /* @__PURE__ */ r.jsx(
      Ee,
      {
        ...e,
        ref: a,
        trapFocus: o.open,
        disableOutsidePointerEvents: !0,
        onCloseAutoFocus: h(e.onCloseAutoFocus, (d) => {
          var c;
          d.preventDefault(), s.current || (c = o.triggerRef.current) == null || c.focus();
        }),
        onPointerDownOutside: h(
          e.onPointerDownOutside,
          (d) => {
            const c = d.detail.originalEvent, l = c.button === 0 && c.ctrlKey === !0, f = c.button === 2 || l;
            s.current = f;
          },
          { checkForDefaultPrevented: !1 }
        ),
        onFocusOutside: h(
          e.onFocusOutside,
          (d) => d.preventDefault(),
          { checkForDefaultPrevented: !1 }
        )
      }
    ) });
  }
), Ht = i.forwardRef(
  (e, t) => {
    const o = w(j, e.__scopePopover), n = i.useRef(!1), a = i.useRef(!1);
    return /* @__PURE__ */ r.jsx(
      Ee,
      {
        ...e,
        ref: t,
        trapFocus: !1,
        disableOutsidePointerEvents: !1,
        onCloseAutoFocus: (s) => {
          var d, c;
          (d = e.onCloseAutoFocus) == null || d.call(e, s), s.defaultPrevented || (n.current || (c = o.triggerRef.current) == null || c.focus(), s.preventDefault()), n.current = !1, a.current = !1;
        },
        onInteractOutside: (s) => {
          var l, f;
          (l = e.onInteractOutside) == null || l.call(e, s), s.defaultPrevented || (n.current = !0, s.detail.originalEvent.type === "pointerdown" && (a.current = !0));
          const d = s.target;
          ((f = o.triggerRef.current) == null ? void 0 : f.contains(d)) && s.preventDefault(), s.detail.originalEvent.type === "focusin" && a.current && s.preventDefault();
        }
      }
    );
  }
), Ee = i.forwardRef(
  (e, t) => {
    const {
      __scopePopover: o,
      trapFocus: n,
      onOpenAutoFocus: a,
      onCloseAutoFocus: s,
      disableOutsidePointerEvents: d,
      onEscapeKeyDown: c,
      onPointerDownOutside: l,
      onFocusOutside: f,
      onInteractOutside: p,
      ...m
    } = e, x = w(j, o), b = E(o);
    return yt(), /* @__PURE__ */ r.jsx(
      Nt,
      {
        asChild: !0,
        loop: !0,
        trapped: n,
        onMountAutoFocus: a,
        onUnmountAutoFocus: s,
        children: /* @__PURE__ */ r.jsx(
          je,
          {
            asChild: !0,
            disableOutsidePointerEvents: d,
            onInteractOutside: p,
            onEscapeKeyDown: c,
            onPointerDownOutside: l,
            onFocusOutside: f,
            onDismiss: () => x.onOpenChange(!1),
            children: /* @__PURE__ */ r.jsx(
              Me,
              {
                "data-state": Ie(x.open),
                role: "dialog",
                id: x.contentId,
                ...b,
                ...m,
                ref: t,
                style: {
                  ...m.style,
                  "--radix-popover-content-transform-origin": "var(--radix-popper-transform-origin)",
                  "--radix-popover-content-available-width": "var(--radix-popper-available-width)",
                  "--radix-popover-content-available-height": "var(--radix-popper-available-height)",
                  "--radix-popover-trigger-width": "var(--radix-popper-anchor-width)",
                  "--radix-popover-trigger-height": "var(--radix-popper-anchor-height)"
                }
              }
            )
          }
        )
      }
    );
  }
), Oe = "PopoverClose", Gt = i.forwardRef(
  (e, t) => {
    const { __scopePopover: o, ...n } = e, a = w(Oe, o);
    return /* @__PURE__ */ r.jsx(
      A.button,
      {
        type: "button",
        ...n,
        ref: t,
        onClick: h(e.onClick, () => a.onOpenChange(!1))
      }
    );
  }
);
Gt.displayName = Oe;
var Ut = "PopoverArrow", Te = i.forwardRef(
  (e, t) => {
    const { __scopePopover: o, ...n } = e, a = E(o);
    return /* @__PURE__ */ r.jsx(we, { ...a, ...n, ref: t });
  }
);
Te.displayName = Ut;
function Ie(e) {
  return e ? "open" : "closed";
}
var ee = Pe, ke = De, $e = Se, Le = Ae, Bt = Te, K, U = "HoverCard", [Fe] = F(U, [
  z
]), B = z(), [Wt, J] = Fe(U), ze = (e) => {
  const {
    __scopeHoverCard: t,
    children: o,
    open: n,
    defaultOpen: a,
    onOpenChange: s,
    openDelay: d = 700,
    closeDelay: c = 300
  } = e, l = B(t), f = i.useRef(0), p = i.useRef(0), m = i.useRef(!1), x = i.useRef(!1), [b, g] = H({
    prop: n,
    defaultProp: a ?? !1,
    onChange: s,
    caller: U
  }), O = i.useCallback(() => {
    clearTimeout(p.current), f.current = window.setTimeout(() => g(!0), d);
  }, [d, g]), T = i.useCallback(() => {
    clearTimeout(f.current), !m.current && !x.current && (p.current = window.setTimeout(() => g(!1), c));
  }, [c, g]), wt = i.useCallback(() => g(!1), [g]);
  return i.useEffect(() => () => {
    clearTimeout(f.current), clearTimeout(p.current);
  }, []), /* @__PURE__ */ r.jsx(
    Wt,
    {
      scope: t,
      open: b,
      onOpenChange: g,
      onOpen: O,
      onClose: T,
      onDismiss: wt,
      hasSelectionRef: m,
      isPointerDownOnContentRef: x,
      children: /* @__PURE__ */ r.jsx(be, { ...l, children: o })
    }
  );
};
ze.displayName = U;
var He = "HoverCardTrigger", Ge = i.forwardRef(
  (e, t) => {
    const { __scopeHoverCard: o, ...n } = e, a = J(He, o), s = B(o);
    return /* @__PURE__ */ r.jsx(q, { asChild: !0, ...s, children: /* @__PURE__ */ r.jsx(
      A.a,
      {
        "data-state": a.open ? "open" : "closed",
        ...n,
        ref: t,
        onPointerEnter: h(e.onPointerEnter, $(a.onOpen)),
        onPointerLeave: h(e.onPointerLeave, $(a.onClose)),
        onFocus: h(e.onFocus, a.onOpen),
        onBlur: h(e.onBlur, a.onClose),
        onTouchStart: h(e.onTouchStart, (d) => d.preventDefault())
      }
    ) });
  }
);
Ge.displayName = He;
var Kt = "HoverCardPortal", [an, Vt] = Fe(Kt, {
  forceMount: void 0
}), k = "HoverCardContent", Ue = i.forwardRef(
  (e, t) => {
    const o = Vt(k, e.__scopeHoverCard), { forceMount: n = o.forceMount, ...a } = e, s = J(k, e.__scopeHoverCard);
    return /* @__PURE__ */ r.jsx(X, { present: n || s.open, children: /* @__PURE__ */ r.jsx(
      Xt,
      {
        "data-state": s.open ? "open" : "closed",
        ...a,
        onPointerEnter: h(e.onPointerEnter, $(s.onOpen)),
        onPointerLeave: h(e.onPointerLeave, $(s.onClose)),
        ref: t
      }
    ) });
  }
);
Ue.displayName = k;
var Xt = i.forwardRef((e, t) => {
  const {
    __scopeHoverCard: o,
    onEscapeKeyDown: n,
    onPointerDownOutside: a,
    onFocusOutside: s,
    onInteractOutside: d,
    ...c
  } = e, l = J(k, o), f = B(o), p = i.useRef(null), m = Z(t, p), [x, b] = i.useState(!1);
  return i.useEffect(() => {
    if (x) {
      const g = document.body;
      return K = g.style.userSelect || g.style.webkitUserSelect, g.style.userSelect = "none", g.style.webkitUserSelect = "none", () => {
        g.style.userSelect = K, g.style.webkitUserSelect = K;
      };
    }
  }, [x]), i.useEffect(() => {
    if (p.current) {
      const g = () => {
        b(!1), l.isPointerDownOnContentRef.current = !1, setTimeout(() => {
          var T;
          ((T = document.getSelection()) == null ? void 0 : T.toString()) !== "" && (l.hasSelectionRef.current = !0);
        });
      };
      return document.addEventListener("pointerup", g), () => {
        document.removeEventListener("pointerup", g), l.hasSelectionRef.current = !1, l.isPointerDownOnContentRef.current = !1;
      };
    }
  }, [l.isPointerDownOnContentRef, l.hasSelectionRef]), i.useEffect(() => {
    p.current && Yt(p.current).forEach((O) => O.setAttribute("tabindex", "-1"));
  }), /* @__PURE__ */ r.jsx(
    je,
    {
      asChild: !0,
      disableOutsidePointerEvents: !1,
      onInteractOutside: d,
      onEscapeKeyDown: n,
      onPointerDownOutside: a,
      onFocusOutside: h(s, (g) => {
        g.preventDefault();
      }),
      onDismiss: l.onDismiss,
      children: /* @__PURE__ */ r.jsx(
        Me,
        {
          ...f,
          ...c,
          onPointerDown: h(c.onPointerDown, (g) => {
            g.currentTarget.contains(g.target) && b(!0), l.hasSelectionRef.current = !1, l.isPointerDownOnContentRef.current = !0;
          }),
          ref: m,
          style: {
            ...c.style,
            userSelect: x ? "text" : void 0,
            // Safari requires prefix
            WebkitUserSelect: x ? "text" : void 0,
            "--radix-hover-card-content-transform-origin": "var(--radix-popper-transform-origin)",
            "--radix-hover-card-content-available-width": "var(--radix-popper-available-width)",
            "--radix-hover-card-content-available-height": "var(--radix-popper-available-height)",
            "--radix-hover-card-trigger-width": "var(--radix-popper-anchor-width)",
            "--radix-hover-card-trigger-height": "var(--radix-popper-anchor-height)"
          }
        }
      )
    }
  );
}), Zt = "HoverCardArrow", qt = i.forwardRef(
  (e, t) => {
    const { __scopeHoverCard: o, ...n } = e, a = B(o);
    return /* @__PURE__ */ r.jsx(we, { ...a, ...n, ref: t });
  }
);
qt.displayName = Zt;
function $(e) {
  return (t) => t.pointerType === "touch" ? void 0 : e();
}
function Yt(e) {
  const t = [], o = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (n) => n.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
  });
  for (; o.nextNode(); ) t.push(o.currentNode);
  return t;
}
var te = ze, Be = Ge, We = Ue, W = "DropdownMenu", [Jt] = F(
  W,
  [L]
), v = L(), [Qt, Ke] = Jt(W), Ve = (e) => {
  const {
    __scopeDropdownMenu: t,
    children: o,
    dir: n,
    open: a,
    defaultOpen: s,
    onOpenChange: d,
    modal: c = !0
  } = e, l = v(t), f = i.useRef(null), [p, m] = H({
    prop: a,
    defaultProp: s ?? !1,
    onChange: d,
    caller: W
  });
  return /* @__PURE__ */ r.jsx(
    Qt,
    {
      scope: t,
      triggerId: V(),
      triggerRef: f,
      contentId: V(),
      open: p,
      onOpenChange: m,
      onOpenToggle: i.useCallback(() => m((x) => !x), [m]),
      modal: c,
      children: /* @__PURE__ */ r.jsx(ge, { ...l, open: p, onOpenChange: m, dir: n, modal: c, children: o })
    }
  );
};
Ve.displayName = W;
var Xe = "DropdownMenuTrigger", Ze = i.forwardRef(
  (e, t) => {
    const { __scopeDropdownMenu: o, disabled: n = !1, ...a } = e, s = Ke(Xe, o), d = v(o);
    return /* @__PURE__ */ r.jsx(xe, { asChild: !0, ...d, children: /* @__PURE__ */ r.jsx(
      A.button,
      {
        type: "button",
        id: s.triggerId,
        "aria-haspopup": "menu",
        "aria-expanded": s.open,
        "aria-controls": s.open ? s.contentId : void 0,
        "data-state": s.open ? "open" : "closed",
        "data-disabled": n ? "" : void 0,
        disabled: n,
        ...a,
        ref: Ce(t, s.triggerRef),
        onPointerDown: h(e.onPointerDown, (c) => {
          !n && c.button === 0 && c.ctrlKey === !1 && (s.onOpenToggle(), s.open || c.preventDefault());
        }),
        onKeyDown: h(e.onKeyDown, (c) => {
          n || (["Enter", " "].includes(c.key) && s.onOpenToggle(), c.key === "ArrowDown" && s.onOpenChange(!0), ["Enter", " ", "ArrowDown"].includes(c.key) && c.preventDefault());
        })
      }
    ) });
  }
);
Ze.displayName = Xe;
var eo = "DropdownMenuPortal", qe = (e) => {
  const { __scopeDropdownMenu: t, ...o } = e, n = v(t);
  return /* @__PURE__ */ r.jsx(re, { ...n, ...o });
};
qe.displayName = eo;
var Ye = "DropdownMenuContent", Je = i.forwardRef(
  (e, t) => {
    const { __scopeDropdownMenu: o, ...n } = e, a = Ke(Ye, o), s = v(o), d = i.useRef(!1);
    return /* @__PURE__ */ r.jsx(
      me,
      {
        id: a.contentId,
        "aria-labelledby": a.triggerId,
        ...s,
        ...n,
        ref: t,
        onCloseAutoFocus: h(e.onCloseAutoFocus, (c) => {
          var l;
          d.current || (l = a.triggerRef.current) == null || l.focus(), d.current = !1, c.preventDefault();
        }),
        onInteractOutside: h(e.onInteractOutside, (c) => {
          const l = c.detail.originalEvent, f = l.button === 0 && l.ctrlKey === !0, p = l.button === 2 || f;
          (!a.modal || p) && (d.current = !0);
        }),
        style: {
          ...e.style,
          "--radix-dropdown-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
          "--radix-dropdown-menu-content-available-width": "var(--radix-popper-available-width)",
          "--radix-dropdown-menu-content-available-height": "var(--radix-popper-available-height)",
          "--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
          "--radix-dropdown-menu-trigger-height": "var(--radix-popper-anchor-height)"
        }
      }
    );
  }
);
Je.displayName = Ye;
var to = "DropdownMenuGroup", oo = i.forwardRef(
  (e, t) => {
    const { __scopeDropdownMenu: o, ...n } = e, a = v(o);
    return /* @__PURE__ */ r.jsx(he, { ...a, ...n, ref: t });
  }
);
oo.displayName = to;
var no = "DropdownMenuLabel", Qe = i.forwardRef(
  (e, t) => {
    const { __scopeDropdownMenu: o, ...n } = e, a = v(o);
    return /* @__PURE__ */ r.jsx(pe, { ...a, ...n, ref: t });
  }
);
Qe.displayName = no;
var ro = "DropdownMenuItem", et = i.forwardRef(
  (e, t) => {
    const { __scopeDropdownMenu: o, ...n } = e, a = v(o);
    return /* @__PURE__ */ r.jsx(fe, { ...a, ...n, ref: t });
  }
);
et.displayName = ro;
var ao = "DropdownMenuCheckboxItem", tt = i.forwardRef((e, t) => {
  const { __scopeDropdownMenu: o, ...n } = e, a = v(o);
  return /* @__PURE__ */ r.jsx(le, { ...a, ...n, ref: t });
});
tt.displayName = ao;
var so = "DropdownMenuRadioGroup", ot = i.forwardRef((e, t) => {
  const { __scopeDropdownMenu: o, ...n } = e, a = v(o);
  return /* @__PURE__ */ r.jsx(ce, { ...a, ...n, ref: t });
});
ot.displayName = so;
var io = "DropdownMenuRadioItem", nt = i.forwardRef((e, t) => {
  const { __scopeDropdownMenu: o, ...n } = e, a = v(o);
  return /* @__PURE__ */ r.jsx(ie, { ...a, ...n, ref: t });
});
nt.displayName = io;
var co = "DropdownMenuItemIndicator", rt = i.forwardRef((e, t) => {
  const { __scopeDropdownMenu: o, ...n } = e, a = v(o);
  return /* @__PURE__ */ r.jsx(de, { ...a, ...n, ref: t });
});
rt.displayName = co;
var lo = "DropdownMenuSeparator", at = i.forwardRef((e, t) => {
  const { __scopeDropdownMenu: o, ...n } = e, a = v(o);
  return /* @__PURE__ */ r.jsx(ue, { ...a, ...n, ref: t });
});
at.displayName = lo;
var uo = "DropdownMenuArrow", po = i.forwardRef(
  (e, t) => {
    const { __scopeDropdownMenu: o, ...n } = e, a = v(o);
    return /* @__PURE__ */ r.jsx(ve, { ...a, ...n, ref: t });
  }
);
po.displayName = uo;
var fo = (e) => {
  const { __scopeDropdownMenu: t, children: o, open: n, onOpenChange: a, defaultOpen: s } = e, d = v(t), [c, l] = H({
    prop: n,
    defaultProp: s ?? !1,
    onChange: a,
    caller: "DropdownMenuSub"
  });
  return /* @__PURE__ */ r.jsx(Pt, { ...d, open: c, onOpenChange: l, children: o });
}, mo = "DropdownMenuSubTrigger", st = i.forwardRef((e, t) => {
  const { __scopeDropdownMenu: o, ...n } = e, a = v(o);
  return /* @__PURE__ */ r.jsx(se, { ...a, ...n, ref: t });
});
st.displayName = mo;
var xo = "DropdownMenuSubContent", it = i.forwardRef((e, t) => {
  const { __scopeDropdownMenu: o, ...n } = e, a = v(o);
  return /* @__PURE__ */ r.jsx(
    ae,
    {
      ...a,
      ...n,
      ref: t,
      style: {
        ...e.style,
        "--radix-dropdown-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
        "--radix-dropdown-menu-content-available-width": "var(--radix-popper-available-width)",
        "--radix-dropdown-menu-content-available-height": "var(--radix-popper-available-height)",
        "--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
        "--radix-dropdown-menu-trigger-height": "var(--radix-popper-anchor-height)"
      }
    }
  );
});
it.displayName = xo;
var go = Ve, oe = Ze, dt = qe, ho = Je, vo = Qe, Co = et, bo = tt, wo = ot, jo = nt, ct = rt, Mo = at, yo = fo, No = st, Po = it, Q = "ContextMenu", [Ro] = F(Q, [
  L
]), C = L(), [_o, lt] = Ro(Q), ut = (e) => {
  const { __scopeContextMenu: t, children: o, onOpenChange: n, dir: a, modal: s = !0 } = e, [d, c] = i.useState(!1), l = C(t), f = _t(n), p = i.useCallback(
    (m) => {
      c(m), f(m);
    },
    [f]
  );
  return /* @__PURE__ */ r.jsx(
    _o,
    {
      scope: t,
      open: d,
      onOpenChange: p,
      modal: s,
      children: /* @__PURE__ */ r.jsx(
        ge,
        {
          ...l,
          dir: a,
          open: d,
          onOpenChange: p,
          modal: s,
          children: o
        }
      )
    }
  );
};
ut.displayName = Q;
var pt = "ContextMenuTrigger", ft = i.forwardRef(
  (e, t) => {
    const { __scopeContextMenu: o, disabled: n = !1, ...a } = e, s = lt(pt, o), d = C(o), c = i.useRef({ x: 0, y: 0 }), l = i.useRef({
      getBoundingClientRect: () => DOMRect.fromRect({ width: 0, height: 0, ...c.current })
    }), f = i.useRef(0), p = i.useCallback(
      () => window.clearTimeout(f.current),
      []
    ), m = (x) => {
      c.current = { x: x.clientX, y: x.clientY }, s.onOpenChange(!0);
    };
    return i.useEffect(() => p, [p]), i.useEffect(() => void (n && p()), [n, p]), /* @__PURE__ */ r.jsxs(r.Fragment, { children: [
      /* @__PURE__ */ r.jsx(xe, { ...d, virtualRef: l }),
      /* @__PURE__ */ r.jsx(
        A.span,
        {
          "data-state": s.open ? "open" : "closed",
          "data-disabled": n ? "" : void 0,
          ...a,
          ref: t,
          style: { WebkitTouchCallout: "none", ...e.style },
          onContextMenu: n ? e.onContextMenu : h(e.onContextMenu, (x) => {
            p(), m(x), x.preventDefault();
          }),
          onPointerDown: n ? e.onPointerDown : h(
            e.onPointerDown,
            I((x) => {
              p(), f.current = window.setTimeout(() => m(x), 700);
            })
          ),
          onPointerMove: n ? e.onPointerMove : h(e.onPointerMove, I(p)),
          onPointerCancel: n ? e.onPointerCancel : h(e.onPointerCancel, I(p)),
          onPointerUp: n ? e.onPointerUp : h(e.onPointerUp, I(p))
        }
      )
    ] });
  }
);
ft.displayName = pt;
var Do = "ContextMenuPortal", mt = (e) => {
  const { __scopeContextMenu: t, ...o } = e, n = C(t);
  return /* @__PURE__ */ r.jsx(re, { ...n, ...o });
};
mt.displayName = Do;
var xt = "ContextMenuContent", gt = i.forwardRef(
  (e, t) => {
    const { __scopeContextMenu: o, ...n } = e, a = lt(xt, o), s = C(o), d = i.useRef(!1);
    return /* @__PURE__ */ r.jsx(
      me,
      {
        ...s,
        ...n,
        ref: t,
        side: "right",
        sideOffset: 2,
        align: "start",
        onCloseAutoFocus: (c) => {
          var l;
          (l = e.onCloseAutoFocus) == null || l.call(e, c), !c.defaultPrevented && d.current && c.preventDefault(), d.current = !1;
        },
        onInteractOutside: (c) => {
          var l;
          (l = e.onInteractOutside) == null || l.call(e, c), !c.defaultPrevented && !a.modal && (d.current = !0);
        },
        style: {
          ...e.style,
          "--radix-context-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
          "--radix-context-menu-content-available-width": "var(--radix-popper-available-width)",
          "--radix-context-menu-content-available-height": "var(--radix-popper-available-height)",
          "--radix-context-menu-trigger-width": "var(--radix-popper-anchor-width)",
          "--radix-context-menu-trigger-height": "var(--radix-popper-anchor-height)"
        }
      }
    );
  }
);
gt.displayName = xt;
var So = "ContextMenuGroup", Ao = i.forwardRef(
  (e, t) => {
    const { __scopeContextMenu: o, ...n } = e, a = C(o);
    return /* @__PURE__ */ r.jsx(he, { ...a, ...n, ref: t });
  }
);
Ao.displayName = So;
var Eo = "ContextMenuLabel", Oo = i.forwardRef(
  (e, t) => {
    const { __scopeContextMenu: o, ...n } = e, a = C(o);
    return /* @__PURE__ */ r.jsx(pe, { ...a, ...n, ref: t });
  }
);
Oo.displayName = Eo;
var To = "ContextMenuItem", ht = i.forwardRef(
  (e, t) => {
    const { __scopeContextMenu: o, ...n } = e, a = C(o);
    return /* @__PURE__ */ r.jsx(fe, { ...a, ...n, ref: t });
  }
);
ht.displayName = To;
var Io = "ContextMenuCheckboxItem", vt = i.forwardRef((e, t) => {
  const { __scopeContextMenu: o, ...n } = e, a = C(o);
  return /* @__PURE__ */ r.jsx(le, { ...a, ...n, ref: t });
});
vt.displayName = Io;
var ko = "ContextMenuRadioGroup", $o = i.forwardRef((e, t) => {
  const { __scopeContextMenu: o, ...n } = e, a = C(o);
  return /* @__PURE__ */ r.jsx(ce, { ...a, ...n, ref: t });
});
$o.displayName = ko;
var Lo = "ContextMenuRadioItem", Fo = i.forwardRef((e, t) => {
  const { __scopeContextMenu: o, ...n } = e, a = C(o);
  return /* @__PURE__ */ r.jsx(ie, { ...a, ...n, ref: t });
});
Fo.displayName = Lo;
var zo = "ContextMenuItemIndicator", Ct = i.forwardRef((e, t) => {
  const { __scopeContextMenu: o, ...n } = e, a = C(o);
  return /* @__PURE__ */ r.jsx(de, { ...a, ...n, ref: t });
});
Ct.displayName = zo;
var Ho = "ContextMenuSeparator", bt = i.forwardRef((e, t) => {
  const { __scopeContextMenu: o, ...n } = e, a = C(o);
  return /* @__PURE__ */ r.jsx(ue, { ...a, ...n, ref: t });
});
bt.displayName = Ho;
var Go = "ContextMenuArrow", Uo = i.forwardRef(
  (e, t) => {
    const { __scopeContextMenu: o, ...n } = e, a = C(o);
    return /* @__PURE__ */ r.jsx(ve, { ...a, ...n, ref: t });
  }
);
Uo.displayName = Go;
var Bo = "ContextMenuSubTrigger", Wo = i.forwardRef((e, t) => {
  const { __scopeContextMenu: o, ...n } = e, a = C(o);
  return /* @__PURE__ */ r.jsx(se, { ...a, ...n, ref: t });
});
Wo.displayName = Bo;
var Ko = "ContextMenuSubContent", Vo = i.forwardRef((e, t) => {
  const { __scopeContextMenu: o, ...n } = e, a = C(o);
  return /* @__PURE__ */ r.jsx(
    ae,
    {
      ...a,
      ...n,
      ref: t,
      style: {
        ...e.style,
        "--radix-context-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
        "--radix-context-menu-content-available-width": "var(--radix-popper-available-width)",
        "--radix-context-menu-content-available-height": "var(--radix-popper-available-height)",
        "--radix-context-menu-trigger-width": "var(--radix-popper-anchor-width)",
        "--radix-context-menu-trigger-height": "var(--radix-popper-anchor-height)"
      }
    }
  );
});
Vo.displayName = Ko;
function I(e) {
  return (t) => t.pointerType !== "mouse" ? e(t) : void 0;
}
var Xo = ut, ne = ft, Zo = mt, qo = gt, Yo = ht, Jo = vt, Qo = Ct, en = bt;
function sn({
  open: e,
  onOpenChange: t,
  title: o,
  description: n,
  confirmLabel: a = "Continue",
  cancelLabel: s = "Cancel",
  onConfirm: d,
  onCancel: c,
  trigger: l,
  variant: f = "default",
  className: p,
  children: m,
  ...x
}) {
  if (!l && m && i.Children.count(m) > 0)
    return /* @__PURE__ */ r.jsx(y, { open: e, onOpenChange: t, children: m });
  const b = () => {
    d == null || d(), t == null || t(!1);
  }, g = () => {
    c == null || c(), t == null || t(!1);
  };
  return /* @__PURE__ */ r.jsxs(y, { open: e, onOpenChange: t, children: [
    l && /* @__PURE__ */ r.jsx(M, { asChild: !0, children: l }),
    /* @__PURE__ */ r.jsxs(_, { children: [
      /* @__PURE__ */ r.jsx(
        D,
        {
          className: u(
            "fixed inset-0 z-50 bg-black/80",
            "data-[state=open]:animate-in data-[state=closed]:animate-out",
            "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0"
          )
        }
      ),
      /* @__PURE__ */ r.jsxs(
        S,
        {
          className: u(
            "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4",
            "border bg-background p-6 shadow-lg duration-200",
            "data-[state=open]:animate-in data-[state=closed]:animate-out",
            "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
            "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
            "data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%]",
            "data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%]",
            "sm:rounded-lg",
            p
          ),
          ...x,
          children: [
            /* @__PURE__ */ r.jsxs("div", { className: "flex flex-col space-y-2 text-center sm:text-left", children: [
              o && /* @__PURE__ */ r.jsx(R, { className: "text-lg font-semibold", children: o }),
              n && /* @__PURE__ */ r.jsx(P, { className: "text-sm text-muted-foreground", children: n })
            ] }),
            m,
            /* @__PURE__ */ r.jsxs("div", { className: "flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", children: [
              /* @__PURE__ */ r.jsx(
                "button",
                {
                  type: "button",
                  onClick: g,
                  className: u(
                    "inline-flex h-10 items-center justify-center rounded-md px-4 py-2",
                    "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
                    "text-sm font-medium ring-offset-background transition-colors",
                    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
                    "disabled:pointer-events-none disabled:opacity-50",
                    "mt-2 sm:mt-0"
                  ),
                  children: s
                }
              ),
              /* @__PURE__ */ r.jsx(
                "button",
                {
                  type: "button",
                  onClick: b,
                  className: u(
                    "inline-flex h-10 items-center justify-center rounded-md px-4 py-2",
                    "text-sm font-medium ring-offset-background transition-colors",
                    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
                    "disabled:pointer-events-none disabled:opacity-50",
                    f === "destructive" ? "bg-destructive text-destructive-foreground hover:bg-destructive/90" : "bg-primary text-primary-foreground hover:bg-primary/90"
                  ),
                  children: a
                }
              )
            ] })
          ]
        }
      )
    ] })
  ] });
}
function dn({
  asChild: e = !0,
  className: t,
  children: o
}) {
  const n = i.Children.toArray(o), a = n.length === 1 ? n[0] : null, s = e && !!a;
  return /* @__PURE__ */ r.jsx(M, { asChild: s, className: t, children: s ? a : o });
}
function cn({
  className: e,
  children: t
}) {
  return /* @__PURE__ */ r.jsxs(_, { children: [
    /* @__PURE__ */ r.jsx(
      D,
      {
        className: u(
          "fixed inset-0 z-50 bg-black/80",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0"
        )
      }
    ),
    /* @__PURE__ */ r.jsx(
      S,
      {
        className: u(
          "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4",
          "border bg-background p-6 shadow-lg duration-200",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
          "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
          "data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%]",
          "data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%]",
          "sm:rounded-lg",
          e
        ),
        children: t
      }
    )
  ] });
}
function ln({
  className: e,
  children: t
}) {
  return /* @__PURE__ */ r.jsx("div", { className: u("flex flex-col space-y-2 text-center sm:text-left", e), children: t });
}
function un({
  className: e,
  children: t
}) {
  return /* @__PURE__ */ r.jsx("div", { className: u("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", e), children: t });
}
function pn({
  title: e,
  className: t,
  children: o
}) {
  return /* @__PURE__ */ r.jsx(R, { className: u("text-lg font-semibold", t), children: e || o });
}
function fn({
  description: e,
  className: t,
  children: o
}) {
  return /* @__PURE__ */ r.jsx(P, { className: u("text-sm text-muted-foreground", t), children: e || o });
}
function mn({
  label: e,
  onClick: t,
  className: o,
  children: n
}) {
  return /* @__PURE__ */ r.jsx(
    N,
    {
      onClick: t,
      className: u(
        "inline-flex h-10 items-center justify-center rounded-md px-4 py-2",
        "bg-primary text-primary-foreground hover:bg-primary/90",
        "text-sm font-medium ring-offset-background transition-colors",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "disabled:pointer-events-none disabled:opacity-50",
        o
      ),
      children: e || n
    }
  );
}
function xn({
  label: e,
  onClick: t,
  className: o,
  children: n
}) {
  return /* @__PURE__ */ r.jsx(
    N,
    {
      onClick: t,
      className: u(
        "inline-flex h-10 items-center justify-center rounded-md px-4 py-2",
        "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
        "text-sm font-medium ring-offset-background transition-colors",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "disabled:pointer-events-none disabled:opacity-50",
        "mt-2 sm:mt-0",
        o
      ),
      children: e || n
    }
  );
}
function gn({
  open: e,
  defaultOpen: t = !1,
  onOpenChange: o,
  children: n
}) {
  return /* @__PURE__ */ r.jsx(
    y,
    {
      open: e ?? void 0,
      defaultOpen: t,
      onOpenChange: o,
      children: n
    }
  );
}
function hn({
  asChild: e = !1,
  className: t,
  children: o
}) {
  const n = i.Children.toArray(o), a = n.length === 1 ? n[0] : null;
  return e && a ? /* @__PURE__ */ r.jsx(M, { asChild: !0, className: t, children: a }) : /* @__PURE__ */ r.jsx(M, { className: u("inline-flex", t), children: o });
}
function vn({
  asChild: e = !0,
  className: t,
  children: o
}) {
  return /* @__PURE__ */ r.jsx(N, { asChild: e, className: t, children: o });
}
function Cn({
  side: e = "right",
  className: t,
  children: o
}) {
  const n = {
    top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
    bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
    left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
    right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
  };
  return /* @__PURE__ */ r.jsxs(_, { children: [
    /* @__PURE__ */ r.jsx(
      D,
      {
        className: u(
          "fixed inset-0 z-50 bg-black/80",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0"
        )
      }
    ),
    /* @__PURE__ */ r.jsxs(
      S,
      {
        className: u(
          "fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:duration-300 data-[state=open]:duration-500",
          n[e],
          t
        ),
        children: [
          o,
          /* @__PURE__ */ r.jsxs(
            N,
            {
              className: u(
                "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity",
                "hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
                "disabled:pointer-events-none data-[state=open]:bg-secondary"
              ),
              children: [
                /* @__PURE__ */ r.jsxs(
                  "svg",
                  {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "24",
                    height: "24",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: "h-4 w-4",
                    children: [
                      /* @__PURE__ */ r.jsx("line", { x1: "18", y1: "6", x2: "6", y2: "18" }),
                      /* @__PURE__ */ r.jsx("line", { x1: "6", y1: "6", x2: "18", y2: "18" })
                    ]
                  }
                ),
                /* @__PURE__ */ r.jsx("span", { className: "sr-only", children: "Close" })
              ]
            }
          )
        ]
      }
    )
  ] });
}
function bn({
  className: e,
  children: t
}) {
  return /* @__PURE__ */ r.jsx("div", { className: u("flex flex-col space-y-2 text-center sm:text-left", e), children: t });
}
function wn({
  className: e,
  children: t
}) {
  return /* @__PURE__ */ r.jsx("div", { className: u("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", e), children: t });
}
function jn({
  title: e,
  className: t,
  children: o
}) {
  return /* @__PURE__ */ r.jsx(R, { className: u("text-lg font-semibold text-foreground", t), children: e || o });
}
function Mn({
  description: e,
  className: t,
  children: o
}) {
  return /* @__PURE__ */ r.jsx(P, { className: u("text-sm text-muted-foreground", t), children: e || o });
}
function yn({
  open: e,
  onOpenChange: t,
  title: o,
  description: n,
  className: a,
  children: s,
  ...d
}) {
  return s && i.Children.count(s) > 0 ? /* @__PURE__ */ r.jsx(y, { open: e, onOpenChange: t, children: s }) : /* @__PURE__ */ r.jsx(y, { open: e, onOpenChange: t, children: /* @__PURE__ */ r.jsxs(_, { children: [
    /* @__PURE__ */ r.jsx(
      D,
      {
        className: u(
          "fixed inset-0 z-50 bg-black/80",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0"
        )
      }
    ),
    /* @__PURE__ */ r.jsxs(
      S,
      {
        className: u(
          "fixed inset-x-0 bottom-0 z-50 mt-24 flex h-auto flex-col rounded-t-[10px] border bg-background",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
          a
        ),
        ...d,
        children: [
          /* @__PURE__ */ r.jsx("div", { className: "mx-auto mt-4 h-2 w-[100px] rounded-full bg-muted" }),
          /* @__PURE__ */ r.jsxs("div", { className: "p-4", children: [
            o && /* @__PURE__ */ r.jsx(R, { className: "text-lg font-semibold text-foreground", children: o }),
            n && /* @__PURE__ */ r.jsx(P, { className: "text-sm text-muted-foreground", children: n })
          ] }),
          /* @__PURE__ */ r.jsx("div", { className: "p-4", children: s })
        ]
      }
    )
  ] }) });
}
function Nn({
  asChild: e = !0,
  className: t,
  children: o
}) {
  const n = i.Children.toArray(o), a = n.length === 1 ? n[0] : null, s = e && !!a;
  return /* @__PURE__ */ r.jsx(M, { asChild: s, className: t, children: s ? a : o });
}
function Pn({ className: e, children: t }) {
  return /* @__PURE__ */ r.jsxs(_, { children: [
    /* @__PURE__ */ r.jsx(
      D,
      {
        className: u(
          "fixed inset-0 z-50 bg-black/80",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0"
        )
      }
    ),
    /* @__PURE__ */ r.jsxs(
      S,
      {
        className: u(
          "fixed inset-x-0 bottom-0 z-50 mt-24 flex h-auto flex-col rounded-t-[10px] border bg-background",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
          e
        ),
        children: [
          /* @__PURE__ */ r.jsx("div", { className: "mx-auto mt-4 h-2 w-[100px] rounded-full bg-muted" }),
          /* @__PURE__ */ r.jsx("div", { className: "p-4", children: t })
        ]
      }
    )
  ] });
}
function Rn({ className: e, children: t }) {
  return /* @__PURE__ */ r.jsx("div", { className: u("flex flex-col space-y-2 text-center sm:text-left", e), children: t });
}
function _n({ className: e, children: t }) {
  return /* @__PURE__ */ r.jsx("div", { className: u("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", e), children: t });
}
function Dn({ title: e, className: t, children: o }) {
  return /* @__PURE__ */ r.jsx(R, { className: u("text-lg font-semibold text-foreground", t), children: e || o });
}
function Sn({ description: e, className: t, children: o }) {
  return /* @__PURE__ */ r.jsx(P, { className: u("text-sm text-muted-foreground", t), children: e || o });
}
function An({ asChild: e = !0, className: t, children: o }) {
  const n = i.Children.toArray(o), a = n.length === 1 ? n[0] : null, s = e && !!a;
  return /* @__PURE__ */ r.jsx(N, { asChild: s, className: t, children: s ? a : o });
}
function En({
  trigger: e,
  openDelay: t = 700,
  closeDelay: o = 300,
  side: n = "bottom",
  align: a = "center",
  className: s,
  children: d,
  ...c
}) {
  return !e && d && i.Children.count(d) > 0 ? /* @__PURE__ */ r.jsx(te, { openDelay: t, closeDelay: o, children: d }) : /* @__PURE__ */ r.jsxs(te, { openDelay: t, closeDelay: o, children: [
    /* @__PURE__ */ r.jsx(Be, { asChild: !0, children: e }),
    /* @__PURE__ */ r.jsx(
      We,
      {
        side: n,
        align: a,
        sideOffset: 4,
        className: u(
          "z-50 w-64 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
          "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
          "data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2",
          "data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
          s
        ),
        ...c,
        children: d
      }
    )
  ] });
}
function On({
  open: e,
  onOpenChange: t,
  trigger: o,
  side: n = "bottom",
  align: a = "center",
  className: s,
  children: d,
  ...c
}) {
  return !o && d && i.Children.count(d) > 0 ? /* @__PURE__ */ r.jsx(ee, { open: e, onOpenChange: t, children: d }) : /* @__PURE__ */ r.jsxs(ee, { open: e, onOpenChange: t, children: [
    /* @__PURE__ */ r.jsx(ke, { asChild: !0, children: o }),
    /* @__PURE__ */ r.jsx($e, { children: /* @__PURE__ */ r.jsxs(
      Le,
      {
        side: n,
        align: a,
        sideOffset: 4,
        className: u(
          "z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
          "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
          "data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2",
          "data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
          s
        ),
        ...c,
        children: [
          d,
          /* @__PURE__ */ r.jsx(Bt, { className: "fill-popover" })
        ]
      }
    ) })
  ] });
}
function Tn({
  asChild: e = !0,
  className: t,
  children: o
}) {
  const n = i.Children.toArray(o), a = n.length === 1 ? n[0] : null, s = e && !!a;
  return /* @__PURE__ */ r.jsx(Be, { asChild: s, className: t, children: s ? a : o });
}
function In({
  className: e,
  side: t = "bottom",
  align: o = "center",
  sideOffset: n = 4,
  children: a
}) {
  return /* @__PURE__ */ r.jsx(
    We,
    {
      side: t,
      align: o,
      sideOffset: n,
      className: u(
        "z-50 w-64 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none",
        "data-[state=open]:animate-in data-[state=closed]:animate-out",
        "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
        "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
        "data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2",
        "data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
        e
      ),
      children: a
    }
  );
}
function kn({
  asChild: e = !0,
  className: t,
  children: o
}) {
  const n = i.Children.toArray(o), a = n.length === 1 ? n[0] : null, s = e && !!a;
  return /* @__PURE__ */ r.jsx(ke, { asChild: s, className: t, children: s ? a : o });
}
function $n({
  className: e,
  side: t = "bottom",
  align: o = "center",
  sideOffset: n = 4,
  children: a
}) {
  return /* @__PURE__ */ r.jsx($e, { children: /* @__PURE__ */ r.jsx(
    Le,
    {
      side: t,
      align: o,
      sideOffset: n,
      className: u(
        "z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none",
        "data-[state=open]:animate-in data-[state=closed]:animate-out",
        "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
        "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
        "data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2",
        "data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
        e
      ),
      children: a
    }
  ) });
}
function Ln({
  open: e,
  defaultOpen: t = !1,
  onOpenChange: o,
  children: n
}) {
  return /* @__PURE__ */ r.jsx(
    go,
    {
      open: e ?? void 0,
      defaultOpen: t,
      onOpenChange: o,
      children: n
    }
  );
}
function Fn({
  asChild: e = !1,
  className: t,
  children: o
}) {
  const n = i.Children.toArray(o), a = n.length === 1 ? n[0] : null;
  return e && a ? /* @__PURE__ */ r.jsx(oe, { asChild: !0, className: t, children: a }) : /* @__PURE__ */ r.jsx(oe, { className: u("inline-flex", t), children: o });
}
function zn({
  side: e = "bottom",
  sideOffset: t = 4,
  align: o = "start",
  className: n,
  children: a,
  ...s
}) {
  return /* @__PURE__ */ r.jsx(dt, { children: /* @__PURE__ */ r.jsx(
    ho,
    {
      side: e,
      sideOffset: t,
      align: o,
      className: u(
        "z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md",
        "data-[state=open]:animate-in data-[state=closed]:animate-out",
        "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
        "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
        "data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2",
        "data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
        n
      ),
      ...s,
      children: a
    }
  ) });
}
function Hn({
  icon: e,
  shortcut: t,
  disabled: o = !1,
  onSelect: n,
  className: a,
  children: s,
  ...d
}) {
  return /* @__PURE__ */ r.jsxs(
    Co,
    {
      disabled: o,
      onSelect: n,
      className: u(
        "relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none",
        "transition-colors focus:bg-accent focus:text-accent-foreground",
        "data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        a
      ),
      ...d,
      children: [
        e && /* @__PURE__ */ r.jsx(ye, { name: e, size: 16, className: "shrink-0" }),
        /* @__PURE__ */ r.jsx("span", { className: "flex-1", children: s }),
        t && /* @__PURE__ */ r.jsx("span", { className: "ml-auto text-xs tracking-widest text-muted-foreground", children: t })
      ]
    }
  );
}
function Gn({
  inset: e = !1,
  className: t,
  children: o,
  ...n
}) {
  return /* @__PURE__ */ r.jsx(
    vo,
    {
      className: u(
        "px-2 py-1.5 text-sm font-semibold",
        e && "pl-8",
        t
      ),
      ...n,
      children: o
    }
  );
}
function Un({
  className: e,
  ...t
}) {
  return /* @__PURE__ */ r.jsx(
    Mo,
    {
      className: u("-mx-1 my-1 h-px bg-muted", e),
      ...t
    }
  );
}
function Bn({
  checked: e = !1,
  onCheckedChange: t,
  disabled: o = !1,
  className: n,
  children: a
}) {
  return /* @__PURE__ */ r.jsxs(
    bo,
    {
      checked: e,
      onCheckedChange: t,
      disabled: o,
      className: u(
        "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none",
        "transition-colors focus:bg-accent focus:text-accent-foreground",
        "data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        n
      ),
      children: [
        /* @__PURE__ */ r.jsx("span", { className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ r.jsx(ct, { children: /* @__PURE__ */ r.jsx("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: /* @__PURE__ */ r.jsx("polyline", { points: "20 6 9 17 4 12" }) }) }) }),
        a
      ]
    }
  );
}
function Wn({
  value: e,
  onValueChange: t,
  className: o,
  children: n,
  ...a
}) {
  return /* @__PURE__ */ r.jsx(
    wo,
    {
      value: e,
      onValueChange: t,
      className: o,
      ...a,
      children: n
    }
  );
}
function Kn({
  value: e,
  className: t,
  children: o
}) {
  return /* @__PURE__ */ r.jsxs(
    jo,
    {
      value: e,
      className: u(
        "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none",
        "transition-colors focus:bg-accent focus:text-accent-foreground",
        "data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        t
      ),
      children: [
        /* @__PURE__ */ r.jsx("span", { className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ r.jsx(ct, { children: /* @__PURE__ */ r.jsx("svg", { xmlns: "http://www.w3.org/2000/svg", width: "8", height: "8", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ r.jsx("circle", { cx: "12", cy: "12", r: "10" }) }) }) }),
        o
      ]
    }
  );
}
function Vn({
  children: e
}) {
  return /* @__PURE__ */ r.jsx(yo, { children: e });
}
function Xn({
  inset: e = !1,
  className: t,
  children: o,
  ...n
}) {
  return /* @__PURE__ */ r.jsxs(
    No,
    {
      className: u(
        "flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none",
        "focus:bg-accent data-[state=open]:bg-accent",
        e && "pl-8",
        t
      ),
      ...n,
      children: [
        o,
        /* @__PURE__ */ r.jsx("svg", { className: "ml-auto h-4 w-4", xmlns: "http://www.w3.org/2000/svg", width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: /* @__PURE__ */ r.jsx("polyline", { points: "9 18 15 12 9 6" }) })
      ]
    }
  );
}
function Zn({
  className: e,
  children: t,
  ...o
}) {
  return /* @__PURE__ */ r.jsx(dt, { children: /* @__PURE__ */ r.jsx(
    Po,
    {
      className: u(
        "z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg",
        "data-[state=open]:animate-in data-[state=closed]:animate-out",
        "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
        "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
        "data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2",
        "data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
        e
      ),
      ...o,
      children: t
    }
  ) });
}
function qn({
  children: e
}) {
  return /* @__PURE__ */ r.jsx(Xo, { children: e });
}
function Yn({
  asChild: e = !1,
  className: t,
  children: o
}) {
  const n = i.Children.toArray(o), a = n.length === 1 ? n[0] : null;
  return e && a ? /* @__PURE__ */ r.jsx(ne, { asChild: !0, className: t, children: a }) : /* @__PURE__ */ r.jsx(ne, { className: t, children: o });
}
function Jn({
  className: e,
  children: t,
  ...o
}) {
  return /* @__PURE__ */ r.jsx(Zo, { children: /* @__PURE__ */ r.jsx(
    qo,
    {
      className: u(
        "z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md",
        "animate-in fade-in-80 data-[state=open]:animate-in data-[state=closed]:animate-out",
        "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
        "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
        e
      ),
      ...o,
      children: t
    }
  ) });
}
function Qn({
  icon: e,
  shortcut: t,
  disabled: o = !1,
  onSelect: n,
  className: a,
  children: s,
  ...d
}) {
  return /* @__PURE__ */ r.jsxs(
    Yo,
    {
      disabled: o,
      onSelect: n,
      className: u(
        "relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none",
        "transition-colors focus:bg-accent focus:text-accent-foreground",
        "data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        a
      ),
      ...d,
      children: [
        e && /* @__PURE__ */ r.jsx(ye, { name: e, size: 16, className: "shrink-0" }),
        /* @__PURE__ */ r.jsx("span", { className: "flex-1", children: s }),
        t && /* @__PURE__ */ r.jsx("span", { className: "ml-auto text-xs tracking-widest text-muted-foreground", children: t })
      ]
    }
  );
}
function er({
  className: e,
  ...t
}) {
  return /* @__PURE__ */ r.jsx(
    en,
    {
      className: u("-mx-1 my-1 h-px bg-muted", e),
      ...t
    }
  );
}
function tr({
  checked: e = !1,
  onCheckedChange: t,
  disabled: o = !1,
  className: n,
  children: a
}) {
  return /* @__PURE__ */ r.jsxs(
    Jo,
    {
      checked: e,
      onCheckedChange: t,
      disabled: o,
      className: u(
        "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none",
        "transition-colors focus:bg-accent focus:text-accent-foreground",
        "data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        n
      ),
      children: [
        /* @__PURE__ */ r.jsx("span", { className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ r.jsx(Qo, { children: /* @__PURE__ */ r.jsx("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: /* @__PURE__ */ r.jsx("polyline", { points: "20 6 9 17 4 12" }) }) }) }),
        a
      ]
    }
  );
}
export {
  qn as ContextMenu,
  tr as ContextMenuCheckboxItem,
  Jn as ContextMenuContent,
  Qn as ContextMenuItem,
  er as ContextMenuSeparator,
  Yn as ContextMenuTrigger,
  sn as Dialog,
  mn as DialogAction,
  xn as DialogCancel,
  cn as DialogContent,
  fn as DialogDescription,
  un as DialogFooter,
  ln as DialogHeader,
  pn as DialogTitle,
  dn as DialogTrigger,
  yn as Drawer,
  An as DrawerClose,
  Pn as DrawerContent,
  Sn as DrawerDescription,
  _n as DrawerFooter,
  Rn as DrawerHeader,
  Dn as DrawerTitle,
  Nn as DrawerTrigger,
  Ln as DropdownMenu,
  Bn as DropdownMenuCheckboxItem,
  zn as DropdownMenuContent,
  Hn as DropdownMenuItem,
  Gn as DropdownMenuLabel,
  Wn as DropdownMenuRadioGroup,
  Kn as DropdownMenuRadioItem,
  Un as DropdownMenuSeparator,
  Vn as DropdownMenuSub,
  Zn as DropdownMenuSubContent,
  Xn as DropdownMenuSubTrigger,
  Fn as DropdownMenuTrigger,
  En as HoverCard,
  In as HoverCardContent,
  Tn as HoverCardTrigger,
  On as Popover,
  $n as PopoverContent,
  kn as PopoverTrigger,
  gn as Sheet,
  vn as SheetClose,
  Cn as SheetContent,
  Mn as SheetDescription,
  wn as SheetFooter,
  bn as SheetHeader,
  jn as SheetTitle,
  hn as SheetTrigger
};
