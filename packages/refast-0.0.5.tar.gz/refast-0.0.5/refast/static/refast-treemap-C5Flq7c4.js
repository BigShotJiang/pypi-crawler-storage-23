import { y as e } from "./refast-charts-C9YTpQC6.js";
const m = e;
export {
  m as Treemap
};
