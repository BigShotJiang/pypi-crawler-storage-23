var Ql = Object.defineProperty;
var ec = (e, t, n) => t in e ? Ql(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n;
var he = (e, t, n) => ec(e, typeof t != "symbol" ? t + "" : t, n);
import { a as $r, r as h, b as ia, R as P, d as Dn, e as zn } from "./refast-charts-C9YTpQC6.js";
import { j as m } from "./refast-markdown-ByFT1VZb.js";
import { L as tc, C as nc, H as rc, P as oc, a as sc, b as ac, W as ic, B as lc, T as cc, c as uc, d as dc, e as fc, f as pc, R as mc, g as hc, M as gc, G as bc, h as vc, i as Ro, j as Ao, O as xc, k as yc, l as wc, S as Cc, m as Sc, n as Ec, o as kc, A as No, p as To, q as Pc, r as jo, s as Io, t as Mo, u as Rc, v as Ac, w as Nc, x as Lo, y as Do, z as zo, D as Oo, E as Tc, F as _o, I as $o, J as jc, K as Ic, N as cr, Q as Fo, U as Bo, V as Ho, X as Mc, Y as Lc, Z as Dc, _ as zc, $ as Vo, a0 as Oc, a1 as _c, a2 as Wo, a3 as $c, a4 as Fc, a5 as Bc, a6 as Hc, a7 as Vc, a8 as Go, a9 as Wc, aa as Gc, ab as Uc, ac as Kc, ad as Yc, ae as Uo, af as Xc, ag as qc, ah as ur, ai as Jc, aj as Ko, ak as Zc, al as Yo, am as Qc, an as Xo, ao as qo, ap as eu, aq as tu, ar as nu, as as ru, at as ou, au as Jo, av as su, aw as au, ax as iu, ay as lu, az as cu, aA as uu, aB as Zo, aC as Qo, aD as es, aE as du, aF as fu, aG as pu, aH as mu, aI as hu, aJ as gu, aK as bu, aL as vu, aM as ts, aN as xu, aO as ns, aP as yu, aQ as wu, aR as Cu, aS as Su, aT as Eu, aU as ku, aV as Pu, aW as rs, aX as Ru, aY as Au, aZ as Nu, a_ as Tu, a$ as ju, b0 as os, b1 as Iu, b2 as ss, b3 as Mu, b4 as Lu, b5 as Du, b6 as zu, b7 as as, b8 as Ou, b9 as _u, ba as la, bb as is, bc as $u, bd as ls, be as Fu, bf as Bu, bg as Hu, bh as Vu, bi as Wu, bj as cs, bk as us, bl as Gu, bm as Uu, bn as Ku, bo as Yu, bp as Xu, bq as qu, br as Ju, bs as Zu, bt as Qu, bu as ed, bv as td, bw as nd, bx as rd, by as od, bz as sd, bA as ad, bB as id, bC as ld, bD as cd, bE as ud, bF as dd, bG as ca, bH as ds, bI as fd, bJ as pd, bK as md, bL as hd, bM as fs, bN as gd, bO as bd, bP as vd, bQ as xd, bR as yd, bS as wd, bT as Cd, bU as Sd, bV as Ed, bW as kd, bX as Pd, bY as Rd, bZ as Ad, b_ as Nd, b$ as Td, c0 as jd, c1 as Id, c2 as Md, c3 as Ld, c4 as Dd, c5 as zd, c6 as Od, c7 as _d, c8 as $d, c9 as Fd, ca as Bd, cb as ps, cc as Hd, cd as Vd, ce as ms, cf as Wd, cg as Gd, ch as Ud, ci as Kd, cj as Yd, ck as Xd, cl as qd, cm as pn, cn as Fr, co as ua, cp as Jd, cq as Zd, cr as Qd, cs as ef, ct as tf, cu as nf, cv as rf, cw as of, cx as sf, cy as af, cz as lf, cA as cf, cB as uf, cC as df, cD as ff, cE as pf, cF as da, cG as mf, cH as hf, cI as gf, cJ as bf, cK as vf } from "./refast-icons-C3hKXcni.js";
var fa, hs = $r;
fa = hs.createRoot, hs.hydrateRoot;
const pa = "refast:", Sr = `${pa}local:`, Er = `${pa}session:`;
function ma(e, t) {
  const n = [];
  for (let r = 0; r < e.length; r++) {
    const o = e.key(r);
    o && o.startsWith(t) && n.push(o);
  }
  return n;
}
function Bt(e, t) {
  const n = {}, r = ma(e, t);
  for (const o of r) {
    const s = o.substring(t.length), a = e.getItem(o);
    a !== null && (n[s] = a);
  }
  return n;
}
function dr(e) {
  return e === "local" ? { storage: localStorage, prefix: Sr } : { storage: sessionStorage, prefix: Er };
}
class xf {
  constructor() {
    he(this, "websocket", null);
    he(this, "initialized", !1);
    he(this, "onReadyCallback", null);
  }
  /**
   * Set the WebSocket connection to use for communication.
   */
  setWebSocket(t) {
    this.websocket = t, t && t.readyState === WebSocket.OPEN ? this.sendInitialState() : t && t.addEventListener("open", () => {
      this.sendInitialState();
    }, { once: !0 });
  }
  /**
   * Register a callback to be called when store is ready (after init is acknowledged).
   */
  onReady(t) {
    this.onReadyCallback = t;
  }
  /**
   * Called when backend acknowledges store_init.
   */
  handleStoreReady() {
    this.onReadyCallback && this.onReadyCallback();
  }
  /**
   * Check if store has been initialized with backend.
   */
  isInitialized() {
    return this.initialized;
  }
  /**
   * Resync the store state with the backend.
   * This sends the current browser storage state as a store_sync message.
   */
  resyncStore() {
    if (!this.websocket || this.websocket.readyState !== WebSocket.OPEN) {
      console.warn("[Refast] Cannot resync store: WebSocket not connected");
      return;
    }
    const t = {
      local: Bt(localStorage, Sr),
      session: Bt(sessionStorage, Er)
    };
    this.websocket.send(JSON.stringify({
      type: "store_sync",
      data: t
    }));
  }
  /**
   * Send the current browser storage state to the backend.
   */
  sendInitialState() {
    if (!this.websocket || this.websocket.readyState !== WebSocket.OPEN || this.initialized)
      return;
    const t = {
      local: Bt(localStorage, Sr),
      session: Bt(sessionStorage, Er)
    };
    this.websocket.send(JSON.stringify({
      type: "store_init",
      data: t,
      path: window.location.pathname
    })), this.initialized = !0;
  }
  /**
   * Handle store updates from the backend.
   */
  handleUpdates(t) {
    for (const n of t)
      this.applyUpdate(n);
  }
  /**
   * Apply a single store update.
   */
  applyUpdate(t) {
    const { storage: n, prefix: r } = dr(t.storageType);
    switch (t.operation) {
      case "set":
        if (t.key !== null && t.value !== void 0) {
          const s = t.value;
          typeof s == "string" ? n.setItem(`${r}${t.key}`, s) : n.setItem(`${r}${t.key}`, JSON.stringify(s));
        }
        break;
      case "delete":
        t.key !== null && n.removeItem(`${r}${t.key}`);
        break;
      case "clear":
        const o = ma(n, r);
        for (const s of o)
          n.removeItem(s);
        break;
    }
  }
  /**
   * Read a value from browser storage directly.
   * Useful for getting initial values before backend sync.
   */
  get(t, n) {
    const { storage: r, prefix: o } = dr(t);
    return r.getItem(`${o}${n}`);
  }
  /**
   * Get all values from a storage type.
   */
  getAll(t) {
    const { storage: n, prefix: r } = dr(t);
    return Bt(n, r);
  }
  /**
   * Reset the initialized state (used on reconnect).
   */
  reset() {
    this.initialized = !1;
  }
}
const lt = new xf(), ha = {
  invoke(e, t = {}) {
    if (!e || !e.callbackId) {
      console.warn("[Refast] refast.invoke() called with invalid callback:", e);
      return;
    }
    const n = new CustomEvent("refast:callback", {
      detail: {
        callbackId: e.callbackId,
        data: { ...e.boundArgs || {}, ...t }
      }
    });
    window.dispatchEvent(n);
  }
};
let gs = !1;
function yf(e) {
  const t = document.documentElement;
  if (!gs) {
    const c = t.style, d = [];
    for (let f = 0; f < c.length; f++) {
      const p = c[f];
      p.startsWith("--") && d.push(p);
    }
    d.forEach((f) => c.removeProperty(f)), gs = !0;
  }
  const n = document.querySelector("style[data-refast-theme]");
  n && (n.textContent = "");
  let r = document.querySelector("style[data-refast-theme-runtime]");
  r || (r = document.createElement("style"), r.setAttribute("data-refast-theme-runtime", ""), document.head.appendChild(r));
  const o = Object.entries(e.light), s = Object.entries(e.dark);
  e.radius && o.push(["--radius", e.radius]);
  const a = o.map(([c, d]) => `  ${c}: ${d};`).join(`
`), i = s.map(([c, d]) => `  ${c}: ${d};`).join(`
`);
  let l = "";
  a && (l += `:root {
${a}
}
`), i && (l += `.dark {
${i}
}`), r.textContent = l, e.fontFamily ? document.body.style.fontFamily = e.fontFamily : document.body.style.removeProperty("font-family");
}
const ga = h.createContext(null);
function wf({
  children: e,
  websocket: t,
  onComponentUpdate: n
}) {
  const r = h.useRef(/* @__PURE__ */ new Set()), o = h.useRef(t);
  h.useEffect(() => {
    o.current = t;
  }, [t]), h.useEffect(() => {
    const f = (p) => {
      const u = p, { callbackId: g, data: b } = u.detail;
      if (o.current && o.current.readyState === WebSocket.OPEN) {
        const x = {
          type: "callback",
          callbackId: g,
          data: b
        };
        o.current.send(JSON.stringify(x));
      } else
        console.warn("WebSocket not connected, cannot invoke callback");
    };
    return window.addEventListener("refast:callback", f), () => {
      window.removeEventListener("refast:callback", f);
    };
  }, []), h.useEffect(() => {
    if (!t) return;
    const f = (p) => {
      try {
        const u = JSON.parse(p.data);
        if (r.current.forEach((g) => g(u)), u.type === "store_update" && u.updates && lt.handleUpdates(u.updates), u.type === "store_ready" && lt.handleStoreReady(), u.type === "js_exec" && u.code)
          try {
            new Function("args", "refast", u.code)(u.args || {}, ha);
          } catch (g) {
            console.error("[Refast] Error executing JavaScript from server:", g), console.error("[Refast] Code:", u.code);
          }
        if (u.type === "bound_method_call" && u.targetId && u.methodName)
          try {
            const g = document.getElementById(u.targetId);
            if (g) {
              const b = g[u.methodName];
              if (typeof b == "function") {
                const x = Array.isArray(u.args) ? u.args : [], v = u.kwargs || {}, S = Object.keys(v).length > 0 ? [...x, v] : x;
                S.length === 0 ? b.call(g) : S.length === 1 ? b.call(g, S[0]) : b.apply(g, S);
              } else
                console.warn(`[Refast] Method '${u.methodName}' not found on element '${u.targetId}'`);
            } else
              console.warn(`[Refast] Element with id '${u.targetId}' not found`);
          } catch (g) {
            console.error("[Refast] Error calling bound method:", g), console.error("[Refast] Target:", u.targetId, "Method:", u.methodName);
          }
        u.type === "resync_store" && lt.resyncStore(), u.type === "theme_update" && u.theme && yf(u.theme);
      } catch (u) {
        console.error("Error parsing WebSocket message:", u);
      }
    };
    return t.addEventListener("message", f), () => t.removeEventListener("message", f);
  }, [t, n]);
  const s = h.useCallback(
    (f, p, u) => {
      if (!t || t.readyState !== WebSocket.OPEN) {
        console.warn("WebSocket not connected");
        return;
      }
      const g = {
        type: "callback",
        callbackId: f,
        data: p,
        ...u && Object.keys(u).length > 0 ? { eventData: u } : {}
      };
      t.send(JSON.stringify(g));
    },
    [t]
  ), a = h.useCallback(
    (f, p) => {
      if (!t || t.readyState !== WebSocket.OPEN) {
        console.warn("WebSocket not connected");
        return;
      }
      const u = {
        type: "event",
        eventType: f,
        data: p
      };
      t.send(JSON.stringify(u));
    },
    [t]
  ), i = h.useCallback(
    (f) => {
      if (!t || t.readyState !== WebSocket.OPEN) return;
      const p = {
        type: "subscribe",
        eventType: f
      };
      t.send(JSON.stringify(p));
    },
    [t]
  ), l = h.useCallback(
    (f) => {
      if (!t || t.readyState !== WebSocket.OPEN) return;
      const p = {
        type: "unsubscribe",
        eventType: f
      };
      t.send(JSON.stringify(p));
    },
    [t]
  ), c = h.useCallback(
    (f) => (r.current.add(f), () => {
      r.current.delete(f);
    }),
    []
  ), d = h.useMemo(
    () => ({
      invokeCallback: s,
      emitEvent: a,
      subscribe: i,
      unsubscribe: l,
      onUpdate: c
    }),
    [s, a, i, l, c]
  );
  return /* @__PURE__ */ m.jsx(ga.Provider, { value: d, children: e });
}
function Lt() {
  const e = h.useContext(ga);
  if (!e)
    throw new Error("useEventManager must be used within EventManagerProvider");
  return e;
}
function yy(e, t) {
  const { onUpdate: n } = Lt();
  h.useEffect(() => n((r) => {
    r.type === "event" && r.eventType === e && t(r.data);
  }), [e, t, n]);
}
function wy(e) {
  const { subscribe: t, unsubscribe: n } = Lt();
  h.useEffect(() => (t(e), () => n(e)), [e, t, n]);
}
const Br = "-", Cf = (e) => {
  const t = Ef(e), {
    conflictingClassGroups: n,
    conflictingClassGroupModifiers: r
  } = e;
  return {
    getClassGroupId: (a) => {
      const i = a.split(Br);
      return i[0] === "" && i.length !== 1 && i.shift(), ba(i, t) || Sf(a);
    },
    getConflictingClassGroupIds: (a, i) => {
      const l = n[a] || [];
      return i && r[a] ? [...l, ...r[a]] : l;
    }
  };
}, ba = (e, t) => {
  var a;
  if (e.length === 0)
    return t.classGroupId;
  const n = e[0], r = t.nextPart.get(n), o = r ? ba(e.slice(1), r) : void 0;
  if (o)
    return o;
  if (t.validators.length === 0)
    return;
  const s = e.join(Br);
  return (a = t.validators.find(({
    validator: i
  }) => i(s))) == null ? void 0 : a.classGroupId;
}, bs = /^\[(.+)\]$/, Sf = (e) => {
  if (bs.test(e)) {
    const t = bs.exec(e)[1], n = t == null ? void 0 : t.substring(0, t.indexOf(":"));
    if (n)
      return "arbitrary.." + n;
  }
}, Ef = (e) => {
  const {
    theme: t,
    prefix: n
  } = e, r = {
    nextPart: /* @__PURE__ */ new Map(),
    validators: []
  };
  return Pf(Object.entries(e.classGroups), n).forEach(([s, a]) => {
    kr(a, r, s, t);
  }), r;
}, kr = (e, t, n, r) => {
  e.forEach((o) => {
    if (typeof o == "string") {
      const s = o === "" ? t : vs(t, o);
      s.classGroupId = n;
      return;
    }
    if (typeof o == "function") {
      if (kf(o)) {
        kr(o(r), t, n, r);
        return;
      }
      t.validators.push({
        validator: o,
        classGroupId: n
      });
      return;
    }
    Object.entries(o).forEach(([s, a]) => {
      kr(a, vs(t, s), n, r);
    });
  });
}, vs = (e, t) => {
  let n = e;
  return t.split(Br).forEach((r) => {
    n.nextPart.has(r) || n.nextPart.set(r, {
      nextPart: /* @__PURE__ */ new Map(),
      validators: []
    }), n = n.nextPart.get(r);
  }), n;
}, kf = (e) => e.isThemeGetter, Pf = (e, t) => t ? e.map(([n, r]) => {
  const o = r.map((s) => typeof s == "string" ? t + s : typeof s == "object" ? Object.fromEntries(Object.entries(s).map(([a, i]) => [t + a, i])) : s);
  return [n, o];
}) : e, Rf = (e) => {
  if (e < 1)
    return {
      get: () => {
      },
      set: () => {
      }
    };
  let t = 0, n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map();
  const o = (s, a) => {
    n.set(s, a), t++, t > e && (t = 0, r = n, n = /* @__PURE__ */ new Map());
  };
  return {
    get(s) {
      let a = n.get(s);
      if (a !== void 0)
        return a;
      if ((a = r.get(s)) !== void 0)
        return o(s, a), a;
    },
    set(s, a) {
      n.has(s) ? n.set(s, a) : o(s, a);
    }
  };
}, va = "!", Af = (e) => {
  const {
    separator: t,
    experimentalParseClassName: n
  } = e, r = t.length === 1, o = t[0], s = t.length, a = (i) => {
    const l = [];
    let c = 0, d = 0, f;
    for (let x = 0; x < i.length; x++) {
      let v = i[x];
      if (c === 0) {
        if (v === o && (r || i.slice(x, x + s) === t)) {
          l.push(i.slice(d, x)), d = x + s;
          continue;
        }
        if (v === "/") {
          f = x;
          continue;
        }
      }
      v === "[" ? c++ : v === "]" && c--;
    }
    const p = l.length === 0 ? i : i.substring(d), u = p.startsWith(va), g = u ? p.substring(1) : p, b = f && f > d ? f - d : void 0;
    return {
      modifiers: l,
      hasImportantModifier: u,
      baseClassName: g,
      maybePostfixModifierPosition: b
    };
  };
  return n ? (i) => n({
    className: i,
    parseClassName: a
  }) : a;
}, Nf = (e) => {
  if (e.length <= 1)
    return e;
  const t = [];
  let n = [];
  return e.forEach((r) => {
    r[0] === "[" ? (t.push(...n.sort(), r), n = []) : n.push(r);
  }), t.push(...n.sort()), t;
}, Tf = (e) => ({
  cache: Rf(e.cacheSize),
  parseClassName: Af(e),
  ...Cf(e)
}), jf = /\s+/, If = (e, t) => {
  const {
    parseClassName: n,
    getClassGroupId: r,
    getConflictingClassGroupIds: o
  } = t, s = [], a = e.trim().split(jf);
  let i = "";
  for (let l = a.length - 1; l >= 0; l -= 1) {
    const c = a[l], {
      modifiers: d,
      hasImportantModifier: f,
      baseClassName: p,
      maybePostfixModifierPosition: u
    } = n(c);
    let g = !!u, b = r(g ? p.substring(0, u) : p);
    if (!b) {
      if (!g) {
        i = c + (i.length > 0 ? " " + i : i);
        continue;
      }
      if (b = r(p), !b) {
        i = c + (i.length > 0 ? " " + i : i);
        continue;
      }
      g = !1;
    }
    const x = Nf(d).join(":"), v = f ? x + va : x, y = v + b;
    if (s.includes(y))
      continue;
    s.push(y);
    const S = o(b, g);
    for (let C = 0; C < S.length; ++C) {
      const k = S[C];
      s.push(v + k);
    }
    i = c + (i.length > 0 ? " " + i : i);
  }
  return i;
};
function Mf() {
  let e = 0, t, n, r = "";
  for (; e < arguments.length; )
    (t = arguments[e++]) && (n = xa(t)) && (r && (r += " "), r += n);
  return r;
}
const xa = (e) => {
  if (typeof e == "string")
    return e;
  let t, n = "";
  for (let r = 0; r < e.length; r++)
    e[r] && (t = xa(e[r])) && (n && (n += " "), n += t);
  return n;
};
function Lf(e, ...t) {
  let n, r, o, s = a;
  function a(l) {
    const c = t.reduce((d, f) => f(d), e());
    return n = Tf(c), r = n.cache.get, o = n.cache.set, s = i, i(l);
  }
  function i(l) {
    const c = r(l);
    if (c)
      return c;
    const d = If(l, n);
    return o(l, d), d;
  }
  return function() {
    return s(Mf.apply(null, arguments));
  };
}
const de = (e) => {
  const t = (n) => n[e] || [];
  return t.isThemeGetter = !0, t;
}, ya = /^\[(?:([a-z-]+):)?(.+)\]$/i, Df = /^\d+\/\d+$/, zf = /* @__PURE__ */ new Set(["px", "full", "screen"]), Of = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/, _f = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/, $f = /^(rgba?|hsla?|hwb|(ok)?(lab|lch))\(.+\)$/, Ff = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/, Bf = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/, qe = (e) => At(e) || zf.has(e) || Df.test(e), st = (e) => Dt(e, "length", Xf), At = (e) => !!e && !Number.isNaN(Number(e)), fr = (e) => Dt(e, "number", At), Ht = (e) => !!e && Number.isInteger(Number(e)), Hf = (e) => e.endsWith("%") && At(e.slice(0, -1)), ee = (e) => ya.test(e), at = (e) => Of.test(e), Vf = /* @__PURE__ */ new Set(["length", "size", "percentage"]), Wf = (e) => Dt(e, Vf, wa), Gf = (e) => Dt(e, "position", wa), Uf = /* @__PURE__ */ new Set(["image", "url"]), Kf = (e) => Dt(e, Uf, Jf), Yf = (e) => Dt(e, "", qf), Vt = () => !0, Dt = (e, t, n) => {
  const r = ya.exec(e);
  return r ? r[1] ? typeof t == "string" ? r[1] === t : t.has(r[1]) : n(r[2]) : !1;
}, Xf = (e) => (
  // `colorFunctionRegex` check is necessary because color functions can have percentages in them which which would be incorrectly classified as lengths.
  // For example, `hsl(0 0% 0%)` would be classified as a length without this check.
  // I could also use lookbehind assertion in `lengthUnitRegex` but that isn't supported widely enough.
  _f.test(e) && !$f.test(e)
), wa = () => !1, qf = (e) => Ff.test(e), Jf = (e) => Bf.test(e), Zf = () => {
  const e = de("colors"), t = de("spacing"), n = de("blur"), r = de("brightness"), o = de("borderColor"), s = de("borderRadius"), a = de("borderSpacing"), i = de("borderWidth"), l = de("contrast"), c = de("grayscale"), d = de("hueRotate"), f = de("invert"), p = de("gap"), u = de("gradientColorStops"), g = de("gradientColorStopPositions"), b = de("inset"), x = de("margin"), v = de("opacity"), y = de("padding"), S = de("saturate"), C = de("scale"), k = de("sepia"), E = de("skew"), w = de("space"), R = de("translate"), T = () => ["auto", "contain", "none"], I = () => ["auto", "hidden", "clip", "visible", "scroll"], A = () => ["auto", ee, t], N = () => [ee, t], _ = () => ["", qe, st], O = () => ["auto", At, ee], M = () => ["bottom", "center", "left", "left-bottom", "left-top", "right", "right-bottom", "right-top", "top"], L = () => ["solid", "dashed", "dotted", "double", "none"], V = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"], W = () => ["start", "end", "center", "between", "around", "evenly", "stretch"], B = () => ["", "0", ee], te = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"], re = () => [At, ee];
  return {
    cacheSize: 500,
    separator: ":",
    theme: {
      colors: [Vt],
      spacing: [qe, st],
      blur: ["none", "", at, ee],
      brightness: re(),
      borderColor: [e],
      borderRadius: ["none", "", "full", at, ee],
      borderSpacing: N(),
      borderWidth: _(),
      contrast: re(),
      grayscale: B(),
      hueRotate: re(),
      invert: B(),
      gap: N(),
      gradientColorStops: [e],
      gradientColorStopPositions: [Hf, st],
      inset: A(),
      margin: A(),
      opacity: re(),
      padding: N(),
      saturate: re(),
      scale: re(),
      sepia: B(),
      skew: re(),
      space: N(),
      translate: N()
    },
    classGroups: {
      // Layout
      /**
       * Aspect Ratio
       * @see https://tailwindcss.com/docs/aspect-ratio
       */
      aspect: [{
        aspect: ["auto", "square", "video", ee]
      }],
      /**
       * Container
       * @see https://tailwindcss.com/docs/container
       */
      container: ["container"],
      /**
       * Columns
       * @see https://tailwindcss.com/docs/columns
       */
      columns: [{
        columns: [at]
      }],
      /**
       * Break After
       * @see https://tailwindcss.com/docs/break-after
       */
      "break-after": [{
        "break-after": te()
      }],
      /**
       * Break Before
       * @see https://tailwindcss.com/docs/break-before
       */
      "break-before": [{
        "break-before": te()
      }],
      /**
       * Break Inside
       * @see https://tailwindcss.com/docs/break-inside
       */
      "break-inside": [{
        "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
      }],
      /**
       * Box Decoration Break
       * @see https://tailwindcss.com/docs/box-decoration-break
       */
      "box-decoration": [{
        "box-decoration": ["slice", "clone"]
      }],
      /**
       * Box Sizing
       * @see https://tailwindcss.com/docs/box-sizing
       */
      box: [{
        box: ["border", "content"]
      }],
      /**
       * Display
       * @see https://tailwindcss.com/docs/display
       */
      display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
      /**
       * Floats
       * @see https://tailwindcss.com/docs/float
       */
      float: [{
        float: ["right", "left", "none", "start", "end"]
      }],
      /**
       * Clear
       * @see https://tailwindcss.com/docs/clear
       */
      clear: [{
        clear: ["left", "right", "both", "none", "start", "end"]
      }],
      /**
       * Isolation
       * @see https://tailwindcss.com/docs/isolation
       */
      isolation: ["isolate", "isolation-auto"],
      /**
       * Object Fit
       * @see https://tailwindcss.com/docs/object-fit
       */
      "object-fit": [{
        object: ["contain", "cover", "fill", "none", "scale-down"]
      }],
      /**
       * Object Position
       * @see https://tailwindcss.com/docs/object-position
       */
      "object-position": [{
        object: [...M(), ee]
      }],
      /**
       * Overflow
       * @see https://tailwindcss.com/docs/overflow
       */
      overflow: [{
        overflow: I()
      }],
      /**
       * Overflow X
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-x": [{
        "overflow-x": I()
      }],
      /**
       * Overflow Y
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-y": [{
        "overflow-y": I()
      }],
      /**
       * Overscroll Behavior
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      overscroll: [{
        overscroll: T()
      }],
      /**
       * Overscroll Behavior X
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-x": [{
        "overscroll-x": T()
      }],
      /**
       * Overscroll Behavior Y
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-y": [{
        "overscroll-y": T()
      }],
      /**
       * Position
       * @see https://tailwindcss.com/docs/position
       */
      position: ["static", "fixed", "absolute", "relative", "sticky"],
      /**
       * Top / Right / Bottom / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      inset: [{
        inset: [b]
      }],
      /**
       * Right / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-x": [{
        "inset-x": [b]
      }],
      /**
       * Top / Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-y": [{
        "inset-y": [b]
      }],
      /**
       * Start
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      start: [{
        start: [b]
      }],
      /**
       * End
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      end: [{
        end: [b]
      }],
      /**
       * Top
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      top: [{
        top: [b]
      }],
      /**
       * Right
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      right: [{
        right: [b]
      }],
      /**
       * Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      bottom: [{
        bottom: [b]
      }],
      /**
       * Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      left: [{
        left: [b]
      }],
      /**
       * Visibility
       * @see https://tailwindcss.com/docs/visibility
       */
      visibility: ["visible", "invisible", "collapse"],
      /**
       * Z-Index
       * @see https://tailwindcss.com/docs/z-index
       */
      z: [{
        z: ["auto", Ht, ee]
      }],
      // Flexbox and Grid
      /**
       * Flex Basis
       * @see https://tailwindcss.com/docs/flex-basis
       */
      basis: [{
        basis: A()
      }],
      /**
       * Flex Direction
       * @see https://tailwindcss.com/docs/flex-direction
       */
      "flex-direction": [{
        flex: ["row", "row-reverse", "col", "col-reverse"]
      }],
      /**
       * Flex Wrap
       * @see https://tailwindcss.com/docs/flex-wrap
       */
      "flex-wrap": [{
        flex: ["wrap", "wrap-reverse", "nowrap"]
      }],
      /**
       * Flex
       * @see https://tailwindcss.com/docs/flex
       */
      flex: [{
        flex: ["1", "auto", "initial", "none", ee]
      }],
      /**
       * Flex Grow
       * @see https://tailwindcss.com/docs/flex-grow
       */
      grow: [{
        grow: B()
      }],
      /**
       * Flex Shrink
       * @see https://tailwindcss.com/docs/flex-shrink
       */
      shrink: [{
        shrink: B()
      }],
      /**
       * Order
       * @see https://tailwindcss.com/docs/order
       */
      order: [{
        order: ["first", "last", "none", Ht, ee]
      }],
      /**
       * Grid Template Columns
       * @see https://tailwindcss.com/docs/grid-template-columns
       */
      "grid-cols": [{
        "grid-cols": [Vt]
      }],
      /**
       * Grid Column Start / End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start-end": [{
        col: ["auto", {
          span: ["full", Ht, ee]
        }, ee]
      }],
      /**
       * Grid Column Start
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start": [{
        "col-start": O()
      }],
      /**
       * Grid Column End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-end": [{
        "col-end": O()
      }],
      /**
       * Grid Template Rows
       * @see https://tailwindcss.com/docs/grid-template-rows
       */
      "grid-rows": [{
        "grid-rows": [Vt]
      }],
      /**
       * Grid Row Start / End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start-end": [{
        row: ["auto", {
          span: [Ht, ee]
        }, ee]
      }],
      /**
       * Grid Row Start
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start": [{
        "row-start": O()
      }],
      /**
       * Grid Row End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-end": [{
        "row-end": O()
      }],
      /**
       * Grid Auto Flow
       * @see https://tailwindcss.com/docs/grid-auto-flow
       */
      "grid-flow": [{
        "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
      }],
      /**
       * Grid Auto Columns
       * @see https://tailwindcss.com/docs/grid-auto-columns
       */
      "auto-cols": [{
        "auto-cols": ["auto", "min", "max", "fr", ee]
      }],
      /**
       * Grid Auto Rows
       * @see https://tailwindcss.com/docs/grid-auto-rows
       */
      "auto-rows": [{
        "auto-rows": ["auto", "min", "max", "fr", ee]
      }],
      /**
       * Gap
       * @see https://tailwindcss.com/docs/gap
       */
      gap: [{
        gap: [p]
      }],
      /**
       * Gap X
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-x": [{
        "gap-x": [p]
      }],
      /**
       * Gap Y
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-y": [{
        "gap-y": [p]
      }],
      /**
       * Justify Content
       * @see https://tailwindcss.com/docs/justify-content
       */
      "justify-content": [{
        justify: ["normal", ...W()]
      }],
      /**
       * Justify Items
       * @see https://tailwindcss.com/docs/justify-items
       */
      "justify-items": [{
        "justify-items": ["start", "end", "center", "stretch"]
      }],
      /**
       * Justify Self
       * @see https://tailwindcss.com/docs/justify-self
       */
      "justify-self": [{
        "justify-self": ["auto", "start", "end", "center", "stretch"]
      }],
      /**
       * Align Content
       * @see https://tailwindcss.com/docs/align-content
       */
      "align-content": [{
        content: ["normal", ...W(), "baseline"]
      }],
      /**
       * Align Items
       * @see https://tailwindcss.com/docs/align-items
       */
      "align-items": [{
        items: ["start", "end", "center", "baseline", "stretch"]
      }],
      /**
       * Align Self
       * @see https://tailwindcss.com/docs/align-self
       */
      "align-self": [{
        self: ["auto", "start", "end", "center", "stretch", "baseline"]
      }],
      /**
       * Place Content
       * @see https://tailwindcss.com/docs/place-content
       */
      "place-content": [{
        "place-content": [...W(), "baseline"]
      }],
      /**
       * Place Items
       * @see https://tailwindcss.com/docs/place-items
       */
      "place-items": [{
        "place-items": ["start", "end", "center", "baseline", "stretch"]
      }],
      /**
       * Place Self
       * @see https://tailwindcss.com/docs/place-self
       */
      "place-self": [{
        "place-self": ["auto", "start", "end", "center", "stretch"]
      }],
      // Spacing
      /**
       * Padding
       * @see https://tailwindcss.com/docs/padding
       */
      p: [{
        p: [y]
      }],
      /**
       * Padding X
       * @see https://tailwindcss.com/docs/padding
       */
      px: [{
        px: [y]
      }],
      /**
       * Padding Y
       * @see https://tailwindcss.com/docs/padding
       */
      py: [{
        py: [y]
      }],
      /**
       * Padding Start
       * @see https://tailwindcss.com/docs/padding
       */
      ps: [{
        ps: [y]
      }],
      /**
       * Padding End
       * @see https://tailwindcss.com/docs/padding
       */
      pe: [{
        pe: [y]
      }],
      /**
       * Padding Top
       * @see https://tailwindcss.com/docs/padding
       */
      pt: [{
        pt: [y]
      }],
      /**
       * Padding Right
       * @see https://tailwindcss.com/docs/padding
       */
      pr: [{
        pr: [y]
      }],
      /**
       * Padding Bottom
       * @see https://tailwindcss.com/docs/padding
       */
      pb: [{
        pb: [y]
      }],
      /**
       * Padding Left
       * @see https://tailwindcss.com/docs/padding
       */
      pl: [{
        pl: [y]
      }],
      /**
       * Margin
       * @see https://tailwindcss.com/docs/margin
       */
      m: [{
        m: [x]
      }],
      /**
       * Margin X
       * @see https://tailwindcss.com/docs/margin
       */
      mx: [{
        mx: [x]
      }],
      /**
       * Margin Y
       * @see https://tailwindcss.com/docs/margin
       */
      my: [{
        my: [x]
      }],
      /**
       * Margin Start
       * @see https://tailwindcss.com/docs/margin
       */
      ms: [{
        ms: [x]
      }],
      /**
       * Margin End
       * @see https://tailwindcss.com/docs/margin
       */
      me: [{
        me: [x]
      }],
      /**
       * Margin Top
       * @see https://tailwindcss.com/docs/margin
       */
      mt: [{
        mt: [x]
      }],
      /**
       * Margin Right
       * @see https://tailwindcss.com/docs/margin
       */
      mr: [{
        mr: [x]
      }],
      /**
       * Margin Bottom
       * @see https://tailwindcss.com/docs/margin
       */
      mb: [{
        mb: [x]
      }],
      /**
       * Margin Left
       * @see https://tailwindcss.com/docs/margin
       */
      ml: [{
        ml: [x]
      }],
      /**
       * Space Between X
       * @see https://tailwindcss.com/docs/space
       */
      "space-x": [{
        "space-x": [w]
      }],
      /**
       * Space Between X Reverse
       * @see https://tailwindcss.com/docs/space
       */
      "space-x-reverse": ["space-x-reverse"],
      /**
       * Space Between Y
       * @see https://tailwindcss.com/docs/space
       */
      "space-y": [{
        "space-y": [w]
      }],
      /**
       * Space Between Y Reverse
       * @see https://tailwindcss.com/docs/space
       */
      "space-y-reverse": ["space-y-reverse"],
      // Sizing
      /**
       * Width
       * @see https://tailwindcss.com/docs/width
       */
      w: [{
        w: ["auto", "min", "max", "fit", "svw", "lvw", "dvw", ee, t]
      }],
      /**
       * Min-Width
       * @see https://tailwindcss.com/docs/min-width
       */
      "min-w": [{
        "min-w": [ee, t, "min", "max", "fit"]
      }],
      /**
       * Max-Width
       * @see https://tailwindcss.com/docs/max-width
       */
      "max-w": [{
        "max-w": [ee, t, "none", "full", "min", "max", "fit", "prose", {
          screen: [at]
        }, at]
      }],
      /**
       * Height
       * @see https://tailwindcss.com/docs/height
       */
      h: [{
        h: [ee, t, "auto", "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Min-Height
       * @see https://tailwindcss.com/docs/min-height
       */
      "min-h": [{
        "min-h": [ee, t, "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Max-Height
       * @see https://tailwindcss.com/docs/max-height
       */
      "max-h": [{
        "max-h": [ee, t, "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Size
       * @see https://tailwindcss.com/docs/size
       */
      size: [{
        size: [ee, t, "auto", "min", "max", "fit"]
      }],
      // Typography
      /**
       * Font Size
       * @see https://tailwindcss.com/docs/font-size
       */
      "font-size": [{
        text: ["base", at, st]
      }],
      /**
       * Font Smoothing
       * @see https://tailwindcss.com/docs/font-smoothing
       */
      "font-smoothing": ["antialiased", "subpixel-antialiased"],
      /**
       * Font Style
       * @see https://tailwindcss.com/docs/font-style
       */
      "font-style": ["italic", "not-italic"],
      /**
       * Font Weight
       * @see https://tailwindcss.com/docs/font-weight
       */
      "font-weight": [{
        font: ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black", fr]
      }],
      /**
       * Font Family
       * @see https://tailwindcss.com/docs/font-family
       */
      "font-family": [{
        font: [Vt]
      }],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-normal": ["normal-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-ordinal": ["ordinal"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-slashed-zero": ["slashed-zero"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-figure": ["lining-nums", "oldstyle-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-spacing": ["proportional-nums", "tabular-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
      /**
       * Letter Spacing
       * @see https://tailwindcss.com/docs/letter-spacing
       */
      tracking: [{
        tracking: ["tighter", "tight", "normal", "wide", "wider", "widest", ee]
      }],
      /**
       * Line Clamp
       * @see https://tailwindcss.com/docs/line-clamp
       */
      "line-clamp": [{
        "line-clamp": ["none", At, fr]
      }],
      /**
       * Line Height
       * @see https://tailwindcss.com/docs/line-height
       */
      leading: [{
        leading: ["none", "tight", "snug", "normal", "relaxed", "loose", qe, ee]
      }],
      /**
       * List Style Image
       * @see https://tailwindcss.com/docs/list-style-image
       */
      "list-image": [{
        "list-image": ["none", ee]
      }],
      /**
       * List Style Type
       * @see https://tailwindcss.com/docs/list-style-type
       */
      "list-style-type": [{
        list: ["none", "disc", "decimal", ee]
      }],
      /**
       * List Style Position
       * @see https://tailwindcss.com/docs/list-style-position
       */
      "list-style-position": [{
        list: ["inside", "outside"]
      }],
      /**
       * Placeholder Color
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/placeholder-color
       */
      "placeholder-color": [{
        placeholder: [e]
      }],
      /**
       * Placeholder Opacity
       * @see https://tailwindcss.com/docs/placeholder-opacity
       */
      "placeholder-opacity": [{
        "placeholder-opacity": [v]
      }],
      /**
       * Text Alignment
       * @see https://tailwindcss.com/docs/text-align
       */
      "text-alignment": [{
        text: ["left", "center", "right", "justify", "start", "end"]
      }],
      /**
       * Text Color
       * @see https://tailwindcss.com/docs/text-color
       */
      "text-color": [{
        text: [e]
      }],
      /**
       * Text Opacity
       * @see https://tailwindcss.com/docs/text-opacity
       */
      "text-opacity": [{
        "text-opacity": [v]
      }],
      /**
       * Text Decoration
       * @see https://tailwindcss.com/docs/text-decoration
       */
      "text-decoration": ["underline", "overline", "line-through", "no-underline"],
      /**
       * Text Decoration Style
       * @see https://tailwindcss.com/docs/text-decoration-style
       */
      "text-decoration-style": [{
        decoration: [...L(), "wavy"]
      }],
      /**
       * Text Decoration Thickness
       * @see https://tailwindcss.com/docs/text-decoration-thickness
       */
      "text-decoration-thickness": [{
        decoration: ["auto", "from-font", qe, st]
      }],
      /**
       * Text Underline Offset
       * @see https://tailwindcss.com/docs/text-underline-offset
       */
      "underline-offset": [{
        "underline-offset": ["auto", qe, ee]
      }],
      /**
       * Text Decoration Color
       * @see https://tailwindcss.com/docs/text-decoration-color
       */
      "text-decoration-color": [{
        decoration: [e]
      }],
      /**
       * Text Transform
       * @see https://tailwindcss.com/docs/text-transform
       */
      "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
      /**
       * Text Overflow
       * @see https://tailwindcss.com/docs/text-overflow
       */
      "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
      /**
       * Text Wrap
       * @see https://tailwindcss.com/docs/text-wrap
       */
      "text-wrap": [{
        text: ["wrap", "nowrap", "balance", "pretty"]
      }],
      /**
       * Text Indent
       * @see https://tailwindcss.com/docs/text-indent
       */
      indent: [{
        indent: N()
      }],
      /**
       * Vertical Alignment
       * @see https://tailwindcss.com/docs/vertical-align
       */
      "vertical-align": [{
        align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", ee]
      }],
      /**
       * Whitespace
       * @see https://tailwindcss.com/docs/whitespace
       */
      whitespace: [{
        whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
      }],
      /**
       * Word Break
       * @see https://tailwindcss.com/docs/word-break
       */
      break: [{
        break: ["normal", "words", "all", "keep"]
      }],
      /**
       * Hyphens
       * @see https://tailwindcss.com/docs/hyphens
       */
      hyphens: [{
        hyphens: ["none", "manual", "auto"]
      }],
      /**
       * Content
       * @see https://tailwindcss.com/docs/content
       */
      content: [{
        content: ["none", ee]
      }],
      // Backgrounds
      /**
       * Background Attachment
       * @see https://tailwindcss.com/docs/background-attachment
       */
      "bg-attachment": [{
        bg: ["fixed", "local", "scroll"]
      }],
      /**
       * Background Clip
       * @see https://tailwindcss.com/docs/background-clip
       */
      "bg-clip": [{
        "bg-clip": ["border", "padding", "content", "text"]
      }],
      /**
       * Background Opacity
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/background-opacity
       */
      "bg-opacity": [{
        "bg-opacity": [v]
      }],
      /**
       * Background Origin
       * @see https://tailwindcss.com/docs/background-origin
       */
      "bg-origin": [{
        "bg-origin": ["border", "padding", "content"]
      }],
      /**
       * Background Position
       * @see https://tailwindcss.com/docs/background-position
       */
      "bg-position": [{
        bg: [...M(), Gf]
      }],
      /**
       * Background Repeat
       * @see https://tailwindcss.com/docs/background-repeat
       */
      "bg-repeat": [{
        bg: ["no-repeat", {
          repeat: ["", "x", "y", "round", "space"]
        }]
      }],
      /**
       * Background Size
       * @see https://tailwindcss.com/docs/background-size
       */
      "bg-size": [{
        bg: ["auto", "cover", "contain", Wf]
      }],
      /**
       * Background Image
       * @see https://tailwindcss.com/docs/background-image
       */
      "bg-image": [{
        bg: ["none", {
          "gradient-to": ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
        }, Kf]
      }],
      /**
       * Background Color
       * @see https://tailwindcss.com/docs/background-color
       */
      "bg-color": [{
        bg: [e]
      }],
      /**
       * Gradient Color Stops From Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from-pos": [{
        from: [g]
      }],
      /**
       * Gradient Color Stops Via Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via-pos": [{
        via: [g]
      }],
      /**
       * Gradient Color Stops To Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to-pos": [{
        to: [g]
      }],
      /**
       * Gradient Color Stops From
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from": [{
        from: [u]
      }],
      /**
       * Gradient Color Stops Via
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via": [{
        via: [u]
      }],
      /**
       * Gradient Color Stops To
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to": [{
        to: [u]
      }],
      // Borders
      /**
       * Border Radius
       * @see https://tailwindcss.com/docs/border-radius
       */
      rounded: [{
        rounded: [s]
      }],
      /**
       * Border Radius Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-s": [{
        "rounded-s": [s]
      }],
      /**
       * Border Radius End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-e": [{
        "rounded-e": [s]
      }],
      /**
       * Border Radius Top
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-t": [{
        "rounded-t": [s]
      }],
      /**
       * Border Radius Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-r": [{
        "rounded-r": [s]
      }],
      /**
       * Border Radius Bottom
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-b": [{
        "rounded-b": [s]
      }],
      /**
       * Border Radius Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-l": [{
        "rounded-l": [s]
      }],
      /**
       * Border Radius Start Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ss": [{
        "rounded-ss": [s]
      }],
      /**
       * Border Radius Start End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-se": [{
        "rounded-se": [s]
      }],
      /**
       * Border Radius End End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ee": [{
        "rounded-ee": [s]
      }],
      /**
       * Border Radius End Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-es": [{
        "rounded-es": [s]
      }],
      /**
       * Border Radius Top Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tl": [{
        "rounded-tl": [s]
      }],
      /**
       * Border Radius Top Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tr": [{
        "rounded-tr": [s]
      }],
      /**
       * Border Radius Bottom Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-br": [{
        "rounded-br": [s]
      }],
      /**
       * Border Radius Bottom Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-bl": [{
        "rounded-bl": [s]
      }],
      /**
       * Border Width
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w": [{
        border: [i]
      }],
      /**
       * Border Width X
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-x": [{
        "border-x": [i]
      }],
      /**
       * Border Width Y
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-y": [{
        "border-y": [i]
      }],
      /**
       * Border Width Start
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-s": [{
        "border-s": [i]
      }],
      /**
       * Border Width End
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-e": [{
        "border-e": [i]
      }],
      /**
       * Border Width Top
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-t": [{
        "border-t": [i]
      }],
      /**
       * Border Width Right
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-r": [{
        "border-r": [i]
      }],
      /**
       * Border Width Bottom
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-b": [{
        "border-b": [i]
      }],
      /**
       * Border Width Left
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-l": [{
        "border-l": [i]
      }],
      /**
       * Border Opacity
       * @see https://tailwindcss.com/docs/border-opacity
       */
      "border-opacity": [{
        "border-opacity": [v]
      }],
      /**
       * Border Style
       * @see https://tailwindcss.com/docs/border-style
       */
      "border-style": [{
        border: [...L(), "hidden"]
      }],
      /**
       * Divide Width X
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-x": [{
        "divide-x": [i]
      }],
      /**
       * Divide Width X Reverse
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-x-reverse": ["divide-x-reverse"],
      /**
       * Divide Width Y
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-y": [{
        "divide-y": [i]
      }],
      /**
       * Divide Width Y Reverse
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-y-reverse": ["divide-y-reverse"],
      /**
       * Divide Opacity
       * @see https://tailwindcss.com/docs/divide-opacity
       */
      "divide-opacity": [{
        "divide-opacity": [v]
      }],
      /**
       * Divide Style
       * @see https://tailwindcss.com/docs/divide-style
       */
      "divide-style": [{
        divide: L()
      }],
      /**
       * Border Color
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color": [{
        border: [o]
      }],
      /**
       * Border Color X
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-x": [{
        "border-x": [o]
      }],
      /**
       * Border Color Y
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-y": [{
        "border-y": [o]
      }],
      /**
       * Border Color S
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-s": [{
        "border-s": [o]
      }],
      /**
       * Border Color E
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-e": [{
        "border-e": [o]
      }],
      /**
       * Border Color Top
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-t": [{
        "border-t": [o]
      }],
      /**
       * Border Color Right
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-r": [{
        "border-r": [o]
      }],
      /**
       * Border Color Bottom
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-b": [{
        "border-b": [o]
      }],
      /**
       * Border Color Left
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-l": [{
        "border-l": [o]
      }],
      /**
       * Divide Color
       * @see https://tailwindcss.com/docs/divide-color
       */
      "divide-color": [{
        divide: [o]
      }],
      /**
       * Outline Style
       * @see https://tailwindcss.com/docs/outline-style
       */
      "outline-style": [{
        outline: ["", ...L()]
      }],
      /**
       * Outline Offset
       * @see https://tailwindcss.com/docs/outline-offset
       */
      "outline-offset": [{
        "outline-offset": [qe, ee]
      }],
      /**
       * Outline Width
       * @see https://tailwindcss.com/docs/outline-width
       */
      "outline-w": [{
        outline: [qe, st]
      }],
      /**
       * Outline Color
       * @see https://tailwindcss.com/docs/outline-color
       */
      "outline-color": [{
        outline: [e]
      }],
      /**
       * Ring Width
       * @see https://tailwindcss.com/docs/ring-width
       */
      "ring-w": [{
        ring: _()
      }],
      /**
       * Ring Width Inset
       * @see https://tailwindcss.com/docs/ring-width
       */
      "ring-w-inset": ["ring-inset"],
      /**
       * Ring Color
       * @see https://tailwindcss.com/docs/ring-color
       */
      "ring-color": [{
        ring: [e]
      }],
      /**
       * Ring Opacity
       * @see https://tailwindcss.com/docs/ring-opacity
       */
      "ring-opacity": [{
        "ring-opacity": [v]
      }],
      /**
       * Ring Offset Width
       * @see https://tailwindcss.com/docs/ring-offset-width
       */
      "ring-offset-w": [{
        "ring-offset": [qe, st]
      }],
      /**
       * Ring Offset Color
       * @see https://tailwindcss.com/docs/ring-offset-color
       */
      "ring-offset-color": [{
        "ring-offset": [e]
      }],
      // Effects
      /**
       * Box Shadow
       * @see https://tailwindcss.com/docs/box-shadow
       */
      shadow: [{
        shadow: ["", "inner", "none", at, Yf]
      }],
      /**
       * Box Shadow Color
       * @see https://tailwindcss.com/docs/box-shadow-color
       */
      "shadow-color": [{
        shadow: [Vt]
      }],
      /**
       * Opacity
       * @see https://tailwindcss.com/docs/opacity
       */
      opacity: [{
        opacity: [v]
      }],
      /**
       * Mix Blend Mode
       * @see https://tailwindcss.com/docs/mix-blend-mode
       */
      "mix-blend": [{
        "mix-blend": [...V(), "plus-lighter", "plus-darker"]
      }],
      /**
       * Background Blend Mode
       * @see https://tailwindcss.com/docs/background-blend-mode
       */
      "bg-blend": [{
        "bg-blend": V()
      }],
      // Filters
      /**
       * Filter
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/filter
       */
      filter: [{
        filter: ["", "none"]
      }],
      /**
       * Blur
       * @see https://tailwindcss.com/docs/blur
       */
      blur: [{
        blur: [n]
      }],
      /**
       * Brightness
       * @see https://tailwindcss.com/docs/brightness
       */
      brightness: [{
        brightness: [r]
      }],
      /**
       * Contrast
       * @see https://tailwindcss.com/docs/contrast
       */
      contrast: [{
        contrast: [l]
      }],
      /**
       * Drop Shadow
       * @see https://tailwindcss.com/docs/drop-shadow
       */
      "drop-shadow": [{
        "drop-shadow": ["", "none", at, ee]
      }],
      /**
       * Grayscale
       * @see https://tailwindcss.com/docs/grayscale
       */
      grayscale: [{
        grayscale: [c]
      }],
      /**
       * Hue Rotate
       * @see https://tailwindcss.com/docs/hue-rotate
       */
      "hue-rotate": [{
        "hue-rotate": [d]
      }],
      /**
       * Invert
       * @see https://tailwindcss.com/docs/invert
       */
      invert: [{
        invert: [f]
      }],
      /**
       * Saturate
       * @see https://tailwindcss.com/docs/saturate
       */
      saturate: [{
        saturate: [S]
      }],
      /**
       * Sepia
       * @see https://tailwindcss.com/docs/sepia
       */
      sepia: [{
        sepia: [k]
      }],
      /**
       * Backdrop Filter
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/backdrop-filter
       */
      "backdrop-filter": [{
        "backdrop-filter": ["", "none"]
      }],
      /**
       * Backdrop Blur
       * @see https://tailwindcss.com/docs/backdrop-blur
       */
      "backdrop-blur": [{
        "backdrop-blur": [n]
      }],
      /**
       * Backdrop Brightness
       * @see https://tailwindcss.com/docs/backdrop-brightness
       */
      "backdrop-brightness": [{
        "backdrop-brightness": [r]
      }],
      /**
       * Backdrop Contrast
       * @see https://tailwindcss.com/docs/backdrop-contrast
       */
      "backdrop-contrast": [{
        "backdrop-contrast": [l]
      }],
      /**
       * Backdrop Grayscale
       * @see https://tailwindcss.com/docs/backdrop-grayscale
       */
      "backdrop-grayscale": [{
        "backdrop-grayscale": [c]
      }],
      /**
       * Backdrop Hue Rotate
       * @see https://tailwindcss.com/docs/backdrop-hue-rotate
       */
      "backdrop-hue-rotate": [{
        "backdrop-hue-rotate": [d]
      }],
      /**
       * Backdrop Invert
       * @see https://tailwindcss.com/docs/backdrop-invert
       */
      "backdrop-invert": [{
        "backdrop-invert": [f]
      }],
      /**
       * Backdrop Opacity
       * @see https://tailwindcss.com/docs/backdrop-opacity
       */
      "backdrop-opacity": [{
        "backdrop-opacity": [v]
      }],
      /**
       * Backdrop Saturate
       * @see https://tailwindcss.com/docs/backdrop-saturate
       */
      "backdrop-saturate": [{
        "backdrop-saturate": [S]
      }],
      /**
       * Backdrop Sepia
       * @see https://tailwindcss.com/docs/backdrop-sepia
       */
      "backdrop-sepia": [{
        "backdrop-sepia": [k]
      }],
      // Tables
      /**
       * Border Collapse
       * @see https://tailwindcss.com/docs/border-collapse
       */
      "border-collapse": [{
        border: ["collapse", "separate"]
      }],
      /**
       * Border Spacing
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing": [{
        "border-spacing": [a]
      }],
      /**
       * Border Spacing X
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-x": [{
        "border-spacing-x": [a]
      }],
      /**
       * Border Spacing Y
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-y": [{
        "border-spacing-y": [a]
      }],
      /**
       * Table Layout
       * @see https://tailwindcss.com/docs/table-layout
       */
      "table-layout": [{
        table: ["auto", "fixed"]
      }],
      /**
       * Caption Side
       * @see https://tailwindcss.com/docs/caption-side
       */
      caption: [{
        caption: ["top", "bottom"]
      }],
      // Transitions and Animation
      /**
       * Tranisition Property
       * @see https://tailwindcss.com/docs/transition-property
       */
      transition: [{
        transition: ["none", "all", "", "colors", "opacity", "shadow", "transform", ee]
      }],
      /**
       * Transition Duration
       * @see https://tailwindcss.com/docs/transition-duration
       */
      duration: [{
        duration: re()
      }],
      /**
       * Transition Timing Function
       * @see https://tailwindcss.com/docs/transition-timing-function
       */
      ease: [{
        ease: ["linear", "in", "out", "in-out", ee]
      }],
      /**
       * Transition Delay
       * @see https://tailwindcss.com/docs/transition-delay
       */
      delay: [{
        delay: re()
      }],
      /**
       * Animation
       * @see https://tailwindcss.com/docs/animation
       */
      animate: [{
        animate: ["none", "spin", "ping", "pulse", "bounce", ee]
      }],
      // Transforms
      /**
       * Transform
       * @see https://tailwindcss.com/docs/transform
       */
      transform: [{
        transform: ["", "gpu", "none"]
      }],
      /**
       * Scale
       * @see https://tailwindcss.com/docs/scale
       */
      scale: [{
        scale: [C]
      }],
      /**
       * Scale X
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-x": [{
        "scale-x": [C]
      }],
      /**
       * Scale Y
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-y": [{
        "scale-y": [C]
      }],
      /**
       * Rotate
       * @see https://tailwindcss.com/docs/rotate
       */
      rotate: [{
        rotate: [Ht, ee]
      }],
      /**
       * Translate X
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-x": [{
        "translate-x": [R]
      }],
      /**
       * Translate Y
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-y": [{
        "translate-y": [R]
      }],
      /**
       * Skew X
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-x": [{
        "skew-x": [E]
      }],
      /**
       * Skew Y
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-y": [{
        "skew-y": [E]
      }],
      /**
       * Transform Origin
       * @see https://tailwindcss.com/docs/transform-origin
       */
      "transform-origin": [{
        origin: ["center", "top", "top-right", "right", "bottom-right", "bottom", "bottom-left", "left", "top-left", ee]
      }],
      // Interactivity
      /**
       * Accent Color
       * @see https://tailwindcss.com/docs/accent-color
       */
      accent: [{
        accent: ["auto", e]
      }],
      /**
       * Appearance
       * @see https://tailwindcss.com/docs/appearance
       */
      appearance: [{
        appearance: ["none", "auto"]
      }],
      /**
       * Cursor
       * @see https://tailwindcss.com/docs/cursor
       */
      cursor: [{
        cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", ee]
      }],
      /**
       * Caret Color
       * @see https://tailwindcss.com/docs/just-in-time-mode#caret-color-utilities
       */
      "caret-color": [{
        caret: [e]
      }],
      /**
       * Pointer Events
       * @see https://tailwindcss.com/docs/pointer-events
       */
      "pointer-events": [{
        "pointer-events": ["none", "auto"]
      }],
      /**
       * Resize
       * @see https://tailwindcss.com/docs/resize
       */
      resize: [{
        resize: ["none", "y", "x", ""]
      }],
      /**
       * Scroll Behavior
       * @see https://tailwindcss.com/docs/scroll-behavior
       */
      "scroll-behavior": [{
        scroll: ["auto", "smooth"]
      }],
      /**
       * Scroll Margin
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-m": [{
        "scroll-m": N()
      }],
      /**
       * Scroll Margin X
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mx": [{
        "scroll-mx": N()
      }],
      /**
       * Scroll Margin Y
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-my": [{
        "scroll-my": N()
      }],
      /**
       * Scroll Margin Start
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ms": [{
        "scroll-ms": N()
      }],
      /**
       * Scroll Margin End
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-me": [{
        "scroll-me": N()
      }],
      /**
       * Scroll Margin Top
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mt": [{
        "scroll-mt": N()
      }],
      /**
       * Scroll Margin Right
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mr": [{
        "scroll-mr": N()
      }],
      /**
       * Scroll Margin Bottom
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mb": [{
        "scroll-mb": N()
      }],
      /**
       * Scroll Margin Left
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ml": [{
        "scroll-ml": N()
      }],
      /**
       * Scroll Padding
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-p": [{
        "scroll-p": N()
      }],
      /**
       * Scroll Padding X
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-px": [{
        "scroll-px": N()
      }],
      /**
       * Scroll Padding Y
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-py": [{
        "scroll-py": N()
      }],
      /**
       * Scroll Padding Start
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-ps": [{
        "scroll-ps": N()
      }],
      /**
       * Scroll Padding End
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pe": [{
        "scroll-pe": N()
      }],
      /**
       * Scroll Padding Top
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pt": [{
        "scroll-pt": N()
      }],
      /**
       * Scroll Padding Right
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pr": [{
        "scroll-pr": N()
      }],
      /**
       * Scroll Padding Bottom
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pb": [{
        "scroll-pb": N()
      }],
      /**
       * Scroll Padding Left
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pl": [{
        "scroll-pl": N()
      }],
      /**
       * Scroll Snap Align
       * @see https://tailwindcss.com/docs/scroll-snap-align
       */
      "snap-align": [{
        snap: ["start", "end", "center", "align-none"]
      }],
      /**
       * Scroll Snap Stop
       * @see https://tailwindcss.com/docs/scroll-snap-stop
       */
      "snap-stop": [{
        snap: ["normal", "always"]
      }],
      /**
       * Scroll Snap Type
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-type": [{
        snap: ["none", "x", "y", "both"]
      }],
      /**
       * Scroll Snap Type Strictness
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-strictness": [{
        snap: ["mandatory", "proximity"]
      }],
      /**
       * Touch Action
       * @see https://tailwindcss.com/docs/touch-action
       */
      touch: [{
        touch: ["auto", "none", "manipulation"]
      }],
      /**
       * Touch Action X
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-x": [{
        "touch-pan": ["x", "left", "right"]
      }],
      /**
       * Touch Action Y
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-y": [{
        "touch-pan": ["y", "up", "down"]
      }],
      /**
       * Touch Action Pinch Zoom
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-pz": ["touch-pinch-zoom"],
      /**
       * User Select
       * @see https://tailwindcss.com/docs/user-select
       */
      select: [{
        select: ["none", "text", "all", "auto"]
      }],
      /**
       * Will Change
       * @see https://tailwindcss.com/docs/will-change
       */
      "will-change": [{
        "will-change": ["auto", "scroll", "contents", "transform", ee]
      }],
      // SVG
      /**
       * Fill
       * @see https://tailwindcss.com/docs/fill
       */
      fill: [{
        fill: [e, "none"]
      }],
      /**
       * Stroke Width
       * @see https://tailwindcss.com/docs/stroke-width
       */
      "stroke-w": [{
        stroke: [qe, st, fr]
      }],
      /**
       * Stroke
       * @see https://tailwindcss.com/docs/stroke
       */
      stroke: [{
        stroke: [e, "none"]
      }],
      // Accessibility
      /**
       * Screen Readers
       * @see https://tailwindcss.com/docs/screen-readers
       */
      sr: ["sr-only", "not-sr-only"],
      /**
       * Forced Color Adjust
       * @see https://tailwindcss.com/docs/forced-color-adjust
       */
      "forced-color-adjust": [{
        "forced-color-adjust": ["auto", "none"]
      }]
    },
    conflictingClassGroups: {
      overflow: ["overflow-x", "overflow-y"],
      overscroll: ["overscroll-x", "overscroll-y"],
      inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
      "inset-x": ["right", "left"],
      "inset-y": ["top", "bottom"],
      flex: ["basis", "grow", "shrink"],
      gap: ["gap-x", "gap-y"],
      p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
      px: ["pr", "pl"],
      py: ["pt", "pb"],
      m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
      mx: ["mr", "ml"],
      my: ["mt", "mb"],
      size: ["w", "h"],
      "font-size": ["leading"],
      "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
      "fvn-ordinal": ["fvn-normal"],
      "fvn-slashed-zero": ["fvn-normal"],
      "fvn-figure": ["fvn-normal"],
      "fvn-spacing": ["fvn-normal"],
      "fvn-fraction": ["fvn-normal"],
      "line-clamp": ["display", "overflow"],
      rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
      "rounded-s": ["rounded-ss", "rounded-es"],
      "rounded-e": ["rounded-se", "rounded-ee"],
      "rounded-t": ["rounded-tl", "rounded-tr"],
      "rounded-r": ["rounded-tr", "rounded-br"],
      "rounded-b": ["rounded-br", "rounded-bl"],
      "rounded-l": ["rounded-tl", "rounded-bl"],
      "border-spacing": ["border-spacing-x", "border-spacing-y"],
      "border-w": ["border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
      "border-w-x": ["border-w-r", "border-w-l"],
      "border-w-y": ["border-w-t", "border-w-b"],
      "border-color": ["border-color-s", "border-color-e", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
      "border-color-x": ["border-color-r", "border-color-l"],
      "border-color-y": ["border-color-t", "border-color-b"],
      "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
      "scroll-mx": ["scroll-mr", "scroll-ml"],
      "scroll-my": ["scroll-mt", "scroll-mb"],
      "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
      "scroll-px": ["scroll-pr", "scroll-pl"],
      "scroll-py": ["scroll-pt", "scroll-pb"],
      touch: ["touch-x", "touch-y", "touch-pz"],
      "touch-x": ["touch"],
      "touch-y": ["touch"],
      "touch-pz": ["touch"]
    },
    conflictingClassGroupModifiers: {
      "font-size": ["leading"]
    }
  };
}, Qf = /* @__PURE__ */ Lf(Zf);
function D(...e) {
  return Qf(ia(e));
}
function ep(e, t) {
  let n;
  return (...r) => {
    clearTimeout(n), n = setTimeout(() => e(...r), t);
  };
}
function tp(e, t) {
  let n = 0;
  return (...r) => {
    const o = Date.now();
    o - n >= t && (n = o, e(...r));
  };
}
function Cy(e = "refast") {
  return `${e}-${Math.random().toString(36).substring(2, 11)}`;
}
function xs(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
function np(e, t) {
  const n = { ...e };
  for (const r in t) {
    const o = t[r], s = e[r];
    xs(o) && xs(s) ? n[r] = np(
      s,
      o
    ) : o !== void 0 && (n[r] = o);
  }
  return n;
}
function rp({
  id: e,
  className: t,
  style: n,
  children: r,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ m.jsx(
    "div",
    {
      id: e,
      className: D("", t),
      style: n,
      "data-refast-id": o,
      children: r
    }
  );
}
function op({
  id: e,
  className: t,
  style: n,
  children: r,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ m.jsx(
    "span",
    {
      id: e,
      className: D("", t),
      style: n,
      "data-refast-id": o,
      children: r
    }
  );
}
function sp({ children: e }) {
  return /* @__PURE__ */ m.jsx(m.Fragment, { children: e });
}
function Ca({
  id: e,
  className: t,
  justify: n = "start",
  align: r = "start",
  gap: o = 0,
  wrap: s = !1,
  children: a,
  "data-refast-id": i
}) {
  const l = {
    start: "justify-start",
    end: "justify-end",
    center: "justify-center",
    between: "justify-between",
    around: "justify-around",
    evenly: "justify-evenly"
  }[n], c = {
    start: "items-start",
    end: "items-end",
    center: "items-center",
    stretch: "items-stretch",
    baseline: "items-baseline"
  }[r];
  return /* @__PURE__ */ m.jsx(
    "div",
    {
      id: e,
      className: D(
        "flex flex-row",
        l,
        c,
        s && "flex-wrap",
        t
      ),
      style: { gap: typeof o == "number" ? `${o * 0.25}rem` : o },
      "data-refast-id": i,
      children: a
    }
  );
}
function Sa({
  id: e,
  className: t,
  justify: n = "start",
  align: r = "stretch",
  gap: o = 0,
  wrap: s = !1,
  children: a,
  "data-refast-id": i
}) {
  const l = {
    start: "justify-start",
    end: "justify-end",
    center: "justify-center",
    between: "justify-between",
    around: "justify-around",
    evenly: "justify-evenly"
  }[n], c = {
    start: "items-start",
    end: "items-end",
    center: "items-center",
    stretch: "items-stretch",
    baseline: "items-baseline"
  }[r];
  return /* @__PURE__ */ m.jsx(
    "div",
    {
      id: e,
      className: D("flex flex-col", l, c, s && "flex-wrap", t),
      style: { gap: typeof o == "number" ? `${o * 0.25}rem` : o },
      "data-refast-id": i,
      children: a
    }
  );
}
function ap({
  id: e,
  className: t,
  columns: n = 1,
  rows: r,
  gap: o = 0,
  children: s,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ m.jsx(
    "div",
    {
      id: e,
      className: D("grid", t),
      style: {
        gridTemplateColumns: typeof n == "number" ? `repeat(${n}, 1fr)` : n,
        gridTemplateRows: r ? typeof r == "number" ? `repeat(${r}, 1fr)` : r : void 0,
        gap: typeof o == "number" ? `${o * 0.25}rem` : o
      },
      "data-refast-id": a,
      children: s
    }
  );
}
function ip({
  direction: e = "row",
  ...t
}) {
  return e === "column" ? /* @__PURE__ */ m.jsx(Sa, { ...t }) : /* @__PURE__ */ m.jsx(Ca, { ...t });
}
function lp({
  id: e,
  className: t,
  children: n,
  "data-refast-id": r
}) {
  return /* @__PURE__ */ m.jsx(
    "div",
    {
      id: e,
      className: D("flex items-center justify-center", t),
      "data-refast-id": r,
      children: n
    }
  );
}
const ys = (e) => typeof e == "boolean" ? `${e}` : e === 0 ? "0" : e, ws = ia, cp = (e, t) => (n) => {
  var r;
  if ((t == null ? void 0 : t.variants) == null) return ws(e, n == null ? void 0 : n.class, n == null ? void 0 : n.className);
  const { variants: o, defaultVariants: s } = t, a = Object.keys(o).map((c) => {
    const d = n == null ? void 0 : n[c], f = s == null ? void 0 : s[c];
    if (d === null) return null;
    const p = ys(d) || ys(f);
    return o[c][p];
  }), i = n && Object.entries(n).reduce((c, d) => {
    let [f, p] = d;
    return p === void 0 || (c[f] = p), c;
  }, {}), l = t == null || (r = t.compoundVariants) === null || r === void 0 ? void 0 : r.reduce((c, d) => {
    let { class: f, className: p, ...u } = d;
    return Object.entries(u).every((g) => {
      let [b, x] = g;
      return Array.isArray(x) ? x.includes({
        ...s,
        ...i
      }[b]) : {
        ...s,
        ...i
      }[b] === x;
    }) ? [
      ...c,
      f,
      p
    ] : c;
  }, []);
  return ws(e, a, l, n == null ? void 0 : n.class, n == null ? void 0 : n.className);
}, up = {
  // Navigation
  home: vf,
  menu: bf,
  "chevron-left": gf,
  "chevron-right": hf,
  "chevron-up": mf,
  "chevron-down": da,
  "chevrons-left": pf,
  "chevrons-right": ff,
  "chevrons-up": df,
  "chevrons-down": uf,
  "arrow-left": cf,
  "arrow-right": lf,
  "arrow-up": af,
  "arrow-down": sf,
  "arrow-up-right": of,
  "arrow-down-left": rf,
  "corner-up-left": nf,
  "corner-up-right": tf,
  move: ef,
  "external-link": Qd,
  // Actions
  plus: Zd,
  minus: Jd,
  x: ua,
  check: Fr,
  edit: pn,
  "edit-2": pn,
  "edit-3": pn,
  pencil: pn,
  trash: qd,
  "trash-2": Xd,
  save: Yd,
  copy: Kd,
  clipboard: Ud,
  "clipboard-check": Gd,
  paste: Wd,
  cut: ms,
  scissors: ms,
  undo: Vd,
  redo: Hd,
  "refresh-cw": ps,
  refresh: ps,
  "rotate-ccw": Bd,
  "rotate-cw": Fd,
  // Files
  file: $d,
  "file-text": _d,
  "file-plus": Od,
  "file-minus": zd,
  "file-check": Dd,
  "file-x": Ld,
  folder: Md,
  "folder-open": Id,
  "folder-plus": jd,
  "folder-minus": Td,
  upload: Nd,
  download: Ad,
  "cloud-off": Rd,
  image: Pd,
  video: kd,
  music: Ed,
  archive: Sd,
  // Documents & Buildings
  book: Cd,
  "book-open": wd,
  building: yd,
  "building-2": xd,
  // UI
  search: vd,
  settings: bd,
  "settings-2": gd,
  sliders: fs,
  "sliders-horizontal": fs,
  filter: hd,
  "sort-asc": md,
  "sort-desc": pd,
  "more-horizontal": ds,
  "more-vertical": fd,
  ellipsis: ds,
  "grip-vertical": ca,
  "grip-horizontal": dd,
  maximize: ud,
  minimize: cd,
  "maximize-2": ld,
  "minimize-2": id,
  expand: ad,
  shrink: sd,
  eye: od,
  "eye-off": rd,
  lock: nd,
  unlock: td,
  key: ed,
  link: Qu,
  "link-2": Zu,
  unlink: Ju,
  // Users
  user: qu,
  users: Xu,
  "user-plus": Yu,
  "user-minus": Ku,
  "user-check": Uu,
  "user-x": Gu,
  "log-in": us,
  "log-out": cs,
  login: us,
  logout: cs,
  // Status
  "check-circle": Wu,
  "check-circle-2": Vu,
  "x-circle": Hu,
  "alert-circle": Bu,
  info: Fu,
  "alert-triangle": ls,
  warning: ls,
  loader: $u,
  "loader-2": is,
  spinner: is,
  circle: la,
  "circle-dot": _u,
  ban: Ou,
  // Communication
  mail: as,
  email: as,
  "mail-open": zu,
  send: Du,
  inbox: Lu,
  "message-circle": ss,
  "message-square": Mu,
  chat: ss,
  bell: os,
  "bell-off": Iu,
  notification: os,
  phone: ju,
  "phone-call": Tu,
  "phone-off": Nu,
  // Media
  play: Au,
  pause: Ru,
  "stop-circle": rs,
  stop: rs,
  "skip-back": Pu,
  "skip-forward": ku,
  "fast-forward": Eu,
  rewind: Su,
  volume: Cu,
  "volume-1": wu,
  "volume-2": yu,
  "volume-x": ns,
  mute: ns,
  // Data
  "bar-chart": xu,
  "bar-chart-2": ts,
  chart: ts,
  "line-chart": vu,
  "pie-chart": bu,
  activity: gu,
  "trending-up": hu,
  "trending-down": mu,
  database: pu,
  server: fu,
  // Layout
  layout: du,
  "layout-grid": es,
  grid: es,
  "layout-list": Qo,
  list: Qo,
  sidebar: Zo,
  "panel-left": Zo,
  "panel-right": uu,
  "panel-top": cu,
  "panel-bottom": lu,
  columns: iu,
  rows: au,
  // Misc
  star: su,
  heart: Jo,
  like: Jo,
  "thumbs-up": ou,
  "thumbs-down": ru,
  bookmark: nu,
  flag: tu,
  tag: eu,
  hash: qo,
  hashtag: qo,
  "at-sign": Xo,
  at: Xo,
  calendar: Qc,
  clock: Yo,
  time: Yo,
  timer: Zc,
  "alarm-clock": Ko,
  alarm: Ko,
  map: Jc,
  "map-pin": ur,
  location: ur,
  pin: ur,
  navigation: qc,
  compass: Xc,
  globe: Uo,
  world: Uo,
  wifi: Yc,
  "wifi-off": Kc,
  bluetooth: Uc,
  battery: Gc,
  power: Wc,
  zap: Go,
  lightning: Go,
  sun: Vc,
  moon: Hc,
  cloud: Bc,
  umbrella: Fc,
  thermometer: $c,
  droplet: Wo,
  water: Wo,
  wind: _c,
  code: Oc,
  terminal: Vo,
  console: Vo,
  github: zc,
  gitlab: Dc,
  package: Lc,
  box: Mc,
  "shopping-cart": Ho,
  cart: Ho,
  "shopping-bag": Bo,
  bag: Bo,
  "credit-card": Fo,
  card: Fo,
  "dollar-sign": cr,
  dollar: cr,
  money: cr,
  percent: Ic,
  gift: jc,
  truck: $o,
  delivery: $o,
  printer: _o,
  print: _o,
  camera: Tc,
  mic: Oo,
  microphone: Oo,
  headphones: zo,
  audio: zo,
  monitor: Do,
  desktop: Do,
  smartphone: Lo,
  mobile: Lo,
  tablet: Nc,
  laptop: Ac,
  watch: Rc,
  tv: Mo,
  television: Mo,
  cpu: Io,
  processor: Io,
  "hard-drive": jo,
  hdd: jo,
  shield: To,
  "shield-check": Pc,
  security: To,
  award: No,
  trophy: No,
  target: kc,
  crosshair: Ec,
  layers: Sc,
  square: Cc,
  triangle: wc,
  hexagon: yc,
  octagon: xc,
  "help-circle": Ao,
  help: Ao,
  "life-buoy": Ro,
  support: Ro,
  // Additional icons for docs & common use
  rocket: vc,
  "grid-3x3": bc,
  "mouse-pointer-click": gc,
  route: hc,
  radio: mc,
  palette: pc,
  component: fc,
  type: dc,
  "text-cursor-input": uc,
  table: cc,
  "bar-chart-3": lc,
  wrench: ic,
  hammer: ac,
  puzzle: sc,
  paintbrush: oc,
  "hand-metal": rc,
  "check-square": nc,
  "layout-dashboard": tc
};
function Cn({
  name: e,
  size: t = 16,
  color: n,
  strokeWidth: r = 2,
  className: o,
  "data-refast-id": s
}) {
  const a = up[e.toLowerCase()];
  return a ? /* @__PURE__ */ m.jsx(
    a,
    {
      size: t,
      color: n,
      strokeWidth: r,
      className: D("shrink-0", o),
      "data-refast-id": s,
      "aria-hidden": "true"
    }
  ) : /* @__PURE__ */ m.jsx(
    "span",
    {
      className: D("inline-flex shrink-0 items-center justify-center", o),
      style: {
        width: t,
        height: t,
        fontSize: t * 0.875,
        lineHeight: 1
      },
      "data-refast-id": s,
      "aria-hidden": "true",
      children: e
    }
  );
}
const dp = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Icon: Cn
}, Symbol.toStringTag, { value: "Module" })), Hr = P.forwardRef(({
  className: e,
  variant: t = "default",
  size: n = "md",
  loading: r = !1,
  icon: o,
  iconPosition: s = "left",
  children: a,
  "data-refast-id": i,
  ...l
}, c) => {
  const d = {
    default: "bg-primary text-primary-foreground hover:bg-primary/90",
    primary: "bg-primary text-primary-foreground hover:bg-primary/90",
    secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
    destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
    outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
    ghost: "hover:bg-accent hover:text-accent-foreground",
    link: "text-primary underline-offset-4 hover:underline"
  }, f = {
    sm: "h-9 px-3 text-sm",
    md: "h-10 px-4 py-2",
    lg: "h-11 px-8 text-lg",
    icon: "h-10 w-10"
  }, p = n === "lg" ? 20 : n === "sm" ? 14 : 16, u = P.Children.count(a) > 0 || typeof a == "string" && a.length > 0;
  return /* @__PURE__ */ m.jsxs(
    "button",
    {
      ref: c,
      disabled: l.disabled || r,
      className: D(
        "inline-flex items-center justify-center gap-2 rounded-md font-medium transition-colors",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "disabled:pointer-events-none disabled:opacity-50",
        d[t],
        f[n],
        e
      ),
      "data-refast-id": i,
      ...l,
      children: [
        r && /* @__PURE__ */ m.jsx("span", { className: "h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" }),
        !r && o && s === "left" && /* @__PURE__ */ m.jsx(Cn, { name: o, size: p }),
        u && /* @__PURE__ */ m.jsx("span", { children: a }),
        !r && o && s === "right" && /* @__PURE__ */ m.jsx(Cn, { name: o, size: p })
      ]
    }
  );
});
Hr.displayName = "Button";
const Ea = P.forwardRef(({
  id: e,
  className: t,
  icon: n,
  variant: r = "ghost",
  size: o = "md",
  disabled: s = !1,
  onClick: a,
  ariaLabel: i,
  "data-refast-id": l
}, c) => {
  const d = o === "lg" ? 20 : o === "sm" ? 14 : 16;
  return /* @__PURE__ */ m.jsx(
    Hr,
    {
      ref: c,
      id: e,
      className: t,
      variant: r,
      size: "icon",
      disabled: s,
      onClick: a,
      "data-refast-id": l,
      "aria-label": i || n,
      children: /* @__PURE__ */ m.jsx(Cn, { name: n, size: d })
    }
  );
});
Ea.displayName = "IconButton";
const Sy = cp(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive: "bg-destructive text-white hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
        outline: "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-9 px-4 py-2 has-[>svg]:px-3",
        sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
        lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
        icon: "size-9",
        "icon-sm": "size-8",
        "icon-lg": "size-10"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
function fp({
  id: e,
  className: t,
  style: n,
  children: r,
  "data-refast-id": o,
  ...s
}) {
  return /* @__PURE__ */ m.jsx(
    "div",
    {
      id: e,
      className: D(
        "rounded-lg border bg-card text-card-foreground shadow-sm",
        t
      ),
      style: n,
      "data-refast-id": o,
      ...s,
      children: r
    }
  );
}
function pp({
  id: e,
  className: t,
  style: n,
  children: r,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ m.jsx(
    "div",
    {
      id: e,
      className: D("flex flex-col space-y-1.5 p-6", t),
      style: n,
      "data-refast-id": o,
      children: r
    }
  );
}
function mp({
  id: e,
  className: t,
  style: n,
  children: r,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ m.jsx(
    "h3",
    {
      id: e,
      className: D(
        "text-2xl font-semibold leading-none tracking-tight",
        t
      ),
      style: n,
      "data-refast-id": o,
      children: r
    }
  );
}
function hp({
  id: e,
  className: t,
  style: n,
  children: r,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ m.jsx(
    "p",
    {
      id: e,
      className: D("text-sm text-muted-foreground", t),
      style: n,
      "data-refast-id": o,
      children: r
    }
  );
}
function gp({
  id: e,
  className: t,
  style: n,
  children: r,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ m.jsx(
    "div",
    {
      id: e,
      className: D("p-6 pt-0", t),
      style: n,
      "data-refast-id": o,
      children: r
    }
  );
}
function bp({
  id: e,
  className: t,
  style: n,
  children: r,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ m.jsx(
    "div",
    {
      id: e,
      className: D("flex items-center p-6 pt-0", t),
      style: n,
      "data-refast-id": o,
      children: r
    }
  );
}
function Cs(e, t) {
  if (typeof e == "function")
    return e(t);
  e != null && (e.current = t);
}
function On(...e) {
  return (t) => {
    let n = !1;
    const r = e.map((o) => {
      const s = Cs(o, t);
      return !n && typeof s == "function" && (n = !0), s;
    });
    if (n)
      return () => {
        for (let o = 0; o < r.length; o++) {
          const s = r[o];
          typeof s == "function" ? s() : Cs(e[o], null);
        }
      };
  };
}
function pe(...e) {
  return h.useCallback(On(...e), e);
}
function Ey(e, t) {
  const n = h.createContext(t), r = (s) => {
    const { children: a, ...i } = s, l = h.useMemo(() => i, Object.values(i));
    return /* @__PURE__ */ m.jsx(n.Provider, { value: l, children: a });
  };
  r.displayName = e + "Provider";
  function o(s) {
    const a = h.useContext(n);
    if (a) return a;
    if (t !== void 0) return t;
    throw new Error(`\`${s}\` must be used within \`${e}\``);
  }
  return [r, o];
}
function We(e, t = []) {
  let n = [];
  function r(s, a) {
    const i = h.createContext(a), l = n.length;
    n = [...n, a];
    const c = (f) => {
      var v;
      const { scope: p, children: u, ...g } = f, b = ((v = p == null ? void 0 : p[e]) == null ? void 0 : v[l]) || i, x = h.useMemo(() => g, Object.values(g));
      return /* @__PURE__ */ m.jsx(b.Provider, { value: x, children: u });
    };
    c.displayName = s + "Provider";
    function d(f, p) {
      var b;
      const u = ((b = p == null ? void 0 : p[e]) == null ? void 0 : b[l]) || i, g = h.useContext(u);
      if (g) return g;
      if (a !== void 0) return a;
      throw new Error(`\`${f}\` must be used within \`${s}\``);
    }
    return [c, d];
  }
  const o = () => {
    const s = n.map((a) => h.createContext(a));
    return function(i) {
      const l = (i == null ? void 0 : i[e]) || s;
      return h.useMemo(
        () => ({ [`__scope${e}`]: { ...i, [e]: l } }),
        [i, l]
      );
    };
  };
  return o.scopeName = e, [r, vp(o, ...t)];
}
function vp(...e) {
  const t = e[0];
  if (e.length === 1) return t;
  const n = () => {
    const r = e.map((o) => ({
      useScope: o(),
      scopeName: o.scopeName
    }));
    return function(s) {
      const a = r.reduce((i, { useScope: l, scopeName: c }) => {
        const f = l(s)[`__scope${c}`];
        return { ...i, ...f };
      }, {});
      return h.useMemo(() => ({ [`__scope${t.scopeName}`]: a }), [a]);
    };
  };
  return n.scopeName = t.scopeName, n;
}
function ae(e, t, { checkForDefaultPrevented: n = !0 } = {}) {
  return function(o) {
    if (e == null || e(o), n === !1 || !o.defaultPrevented)
      return t == null ? void 0 : t(o);
  };
}
var He = globalThis != null && globalThis.document ? h.useLayoutEffect : () => {
}, xp = Dn[" useInsertionEffect ".trim().toString()] || He;
function Ct({
  prop: e,
  defaultProp: t,
  onChange: n = () => {
  },
  caller: r
}) {
  const [o, s, a] = yp({
    defaultProp: t,
    onChange: n
  }), i = e !== void 0, l = i ? e : o;
  {
    const d = h.useRef(e !== void 0);
    h.useEffect(() => {
      const f = d.current;
      f !== i && console.warn(
        `${r} is changing from ${f ? "controlled" : "uncontrolled"} to ${i ? "controlled" : "uncontrolled"}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`
      ), d.current = i;
    }, [i, r]);
  }
  const c = h.useCallback(
    (d) => {
      var f;
      if (i) {
        const p = wp(d) ? d(e) : d;
        p !== e && ((f = a.current) == null || f.call(a, p));
      } else
        s(d);
    },
    [i, e, s, a]
  );
  return [l, c];
}
function yp({
  defaultProp: e,
  onChange: t
}) {
  const [n, r] = h.useState(e), o = h.useRef(n), s = h.useRef(t);
  return xp(() => {
    s.current = t;
  }, [t]), h.useEffect(() => {
    var a;
    o.current !== n && ((a = s.current) == null || a.call(s, n), o.current = n);
  }, [n, o]), [n, r, s];
}
function wp(e) {
  return typeof e == "function";
}
function ka(e) {
  const t = h.useRef({ value: e, previous: e });
  return h.useMemo(() => (t.current.value !== e && (t.current.previous = t.current.value, t.current.value = e), t.current.previous), [e]);
}
function Vr(e) {
  const [t, n] = h.useState(void 0);
  return He(() => {
    if (e) {
      n({ width: e.offsetWidth, height: e.offsetHeight });
      const r = new ResizeObserver((o) => {
        if (!Array.isArray(o) || !o.length)
          return;
        const s = o[0];
        let a, i;
        if ("borderBoxSize" in s) {
          const l = s.borderBoxSize, c = Array.isArray(l) ? l[0] : l;
          a = c.inlineSize, i = c.blockSize;
        } else
          a = e.offsetWidth, i = e.offsetHeight;
        n({ width: a, height: i });
      });
      return r.observe(e, { box: "border-box" }), () => r.unobserve(e);
    } else
      n(void 0);
  }, [e]), t;
}
function Cp(e, t) {
  return h.useReducer((n, r) => t[n][r] ?? n, e);
}
var Ge = (e) => {
  const { present: t, children: n } = e, r = Sp(t), o = typeof n == "function" ? n({ present: r.isPresent }) : h.Children.only(n), s = pe(r.ref, Ep(o));
  return typeof n == "function" || r.isPresent ? h.cloneElement(o, { ref: s }) : null;
};
Ge.displayName = "Presence";
function Sp(e) {
  const [t, n] = h.useState(), r = h.useRef(null), o = h.useRef(e), s = h.useRef("none"), a = e ? "mounted" : "unmounted", [i, l] = Cp(a, {
    mounted: {
      UNMOUNT: "unmounted",
      ANIMATION_OUT: "unmountSuspended"
    },
    unmountSuspended: {
      MOUNT: "mounted",
      ANIMATION_END: "unmounted"
    },
    unmounted: {
      MOUNT: "mounted"
    }
  });
  return h.useEffect(() => {
    const c = mn(r.current);
    s.current = i === "mounted" ? c : "none";
  }, [i]), He(() => {
    const c = r.current, d = o.current;
    if (d !== e) {
      const p = s.current, u = mn(c);
      e ? l("MOUNT") : u === "none" || (c == null ? void 0 : c.display) === "none" ? l("UNMOUNT") : l(d && p !== u ? "ANIMATION_OUT" : "UNMOUNT"), o.current = e;
    }
  }, [e, l]), He(() => {
    if (t) {
      let c;
      const d = t.ownerDocument.defaultView ?? window, f = (u) => {
        const b = mn(r.current).includes(CSS.escape(u.animationName));
        if (u.target === t && b && (l("ANIMATION_END"), !o.current)) {
          const x = t.style.animationFillMode;
          t.style.animationFillMode = "forwards", c = d.setTimeout(() => {
            t.style.animationFillMode === "forwards" && (t.style.animationFillMode = x);
          });
        }
      }, p = (u) => {
        u.target === t && (s.current = mn(r.current));
      };
      return t.addEventListener("animationstart", p), t.addEventListener("animationcancel", f), t.addEventListener("animationend", f), () => {
        d.clearTimeout(c), t.removeEventListener("animationstart", p), t.removeEventListener("animationcancel", f), t.removeEventListener("animationend", f);
      };
    } else
      l("ANIMATION_END");
  }, [t, l]), {
    isPresent: ["mounted", "unmountSuspended"].includes(i),
    ref: h.useCallback((c) => {
      r.current = c ? getComputedStyle(c) : null, n(c);
    }, [])
  };
}
function mn(e) {
  return (e == null ? void 0 : e.animationName) || "none";
}
function Ep(e) {
  var r, o;
  let t = (r = Object.getOwnPropertyDescriptor(e.props, "ref")) == null ? void 0 : r.get, n = t && "isReactWarning" in t && t.isReactWarning;
  return n ? e.ref : (t = (o = Object.getOwnPropertyDescriptor(e, "ref")) == null ? void 0 : o.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
// @__NO_SIDE_EFFECTS__
function kp(e) {
  const t = /* @__PURE__ */ Pp(e), n = h.forwardRef((r, o) => {
    const { children: s, ...a } = r, i = h.Children.toArray(s), l = i.find(Ap);
    if (l) {
      const c = l.props.children, d = i.map((f) => f === l ? h.Children.count(c) > 1 ? h.Children.only(null) : h.isValidElement(c) ? c.props.children : null : f);
      return /* @__PURE__ */ m.jsx(t, { ...a, ref: o, children: h.isValidElement(c) ? h.cloneElement(c, void 0, d) : null });
    }
    return /* @__PURE__ */ m.jsx(t, { ...a, ref: o, children: s });
  });
  return n.displayName = `${e}.Slot`, n;
}
// @__NO_SIDE_EFFECTS__
function Pp(e) {
  const t = h.forwardRef((n, r) => {
    const { children: o, ...s } = n;
    if (h.isValidElement(o)) {
      const a = Tp(o), i = Np(s, o.props);
      return o.type !== h.Fragment && (i.ref = r ? On(r, a) : a), h.cloneElement(o, i);
    }
    return h.Children.count(o) > 1 ? h.Children.only(null) : null;
  });
  return t.displayName = `${e}.SlotClone`, t;
}
var Rp = Symbol("radix.slottable");
function Ap(e) {
  return h.isValidElement(e) && typeof e.type == "function" && "__radixId" in e.type && e.type.__radixId === Rp;
}
function Np(e, t) {
  const n = { ...t };
  for (const r in t) {
    const o = e[r], s = t[r];
    /^on[A-Z]/.test(r) ? o && s ? n[r] = (...i) => {
      const l = s(...i);
      return o(...i), l;
    } : o && (n[r] = o) : r === "style" ? n[r] = { ...o, ...s } : r === "className" && (n[r] = [o, s].filter(Boolean).join(" "));
  }
  return { ...e, ...n };
}
function Tp(e) {
  var r, o;
  let t = (r = Object.getOwnPropertyDescriptor(e.props, "ref")) == null ? void 0 : r.get, n = t && "isReactWarning" in t && t.isReactWarning;
  return n ? e.ref : (t = (o = Object.getOwnPropertyDescriptor(e, "ref")) == null ? void 0 : o.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
var jp = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "select",
  "span",
  "svg",
  "ul"
], le = jp.reduce((e, t) => {
  const n = /* @__PURE__ */ kp(`Primitive.${t}`), r = h.forwardRef((o, s) => {
    const { asChild: a, ...i } = o, l = a ? n : t;
    return typeof window < "u" && (window[Symbol.for("radix-ui")] = !0), /* @__PURE__ */ m.jsx(l, { ...i, ref: s });
  });
  return r.displayName = `Primitive.${t}`, { ...e, [t]: r };
}, {});
function Ip(e, t) {
  e && $r.flushSync(() => e.dispatchEvent(t));
}
var _n = "Checkbox", [Mp] = We(_n), [Lp, Wr] = Mp(_n);
function Dp(e) {
  const {
    __scopeCheckbox: t,
    checked: n,
    children: r,
    defaultChecked: o,
    disabled: s,
    form: a,
    name: i,
    onCheckedChange: l,
    required: c,
    value: d = "on",
    // @ts-expect-error
    internal_do_not_use_render: f
  } = e, [p, u] = Ct({
    prop: n,
    defaultProp: o ?? !1,
    onChange: l,
    caller: _n
  }), [g, b] = h.useState(null), [x, v] = h.useState(null), y = h.useRef(!1), S = g ? !!a || !!g.closest("form") : (
    // We set this to true by default so that events bubble to forms without JS (SSR)
    !0
  ), C = {
    checked: p,
    disabled: s,
    setChecked: u,
    control: g,
    setControl: b,
    name: i,
    form: a,
    value: d,
    hasConsumerStoppedPropagationRef: y,
    required: c,
    defaultChecked: dt(o) ? !1 : o,
    isFormControl: S,
    bubbleInput: x,
    setBubbleInput: v
  };
  return /* @__PURE__ */ m.jsx(
    Lp,
    {
      scope: t,
      ...C,
      children: zp(f) ? f(C) : r
    }
  );
}
var Pa = "CheckboxTrigger", Ra = h.forwardRef(
  ({ __scopeCheckbox: e, onKeyDown: t, onClick: n, ...r }, o) => {
    const {
      control: s,
      value: a,
      disabled: i,
      checked: l,
      required: c,
      setControl: d,
      setChecked: f,
      hasConsumerStoppedPropagationRef: p,
      isFormControl: u,
      bubbleInput: g
    } = Wr(Pa, e), b = pe(o, d), x = h.useRef(l);
    return h.useEffect(() => {
      const v = s == null ? void 0 : s.form;
      if (v) {
        const y = () => f(x.current);
        return v.addEventListener("reset", y), () => v.removeEventListener("reset", y);
      }
    }, [s, f]), /* @__PURE__ */ m.jsx(
      le.button,
      {
        type: "button",
        role: "checkbox",
        "aria-checked": dt(l) ? "mixed" : l,
        "aria-required": c,
        "data-state": ja(l),
        "data-disabled": i ? "" : void 0,
        disabled: i,
        value: a,
        ...r,
        ref: b,
        onKeyDown: ae(t, (v) => {
          v.key === "Enter" && v.preventDefault();
        }),
        onClick: ae(n, (v) => {
          f((y) => dt(y) ? !0 : !y), g && u && (p.current = v.isPropagationStopped(), p.current || v.stopPropagation());
        })
      }
    );
  }
);
Ra.displayName = Pa;
var Gr = h.forwardRef(
  (e, t) => {
    const {
      __scopeCheckbox: n,
      name: r,
      checked: o,
      defaultChecked: s,
      required: a,
      disabled: i,
      value: l,
      onCheckedChange: c,
      form: d,
      ...f
    } = e;
    return /* @__PURE__ */ m.jsx(
      Dp,
      {
        __scopeCheckbox: n,
        checked: o,
        defaultChecked: s,
        disabled: i,
        required: a,
        onCheckedChange: c,
        name: r,
        form: d,
        value: l,
        internal_do_not_use_render: ({ isFormControl: p }) => /* @__PURE__ */ m.jsxs(m.Fragment, { children: [
          /* @__PURE__ */ m.jsx(
            Ra,
            {
              ...f,
              ref: t,
              __scopeCheckbox: n
            }
          ),
          p && /* @__PURE__ */ m.jsx(
            Ta,
            {
              __scopeCheckbox: n
            }
          )
        ] })
      }
    );
  }
);
Gr.displayName = _n;
var Aa = "CheckboxIndicator", Ur = h.forwardRef(
  (e, t) => {
    const { __scopeCheckbox: n, forceMount: r, ...o } = e, s = Wr(Aa, n);
    return /* @__PURE__ */ m.jsx(
      Ge,
      {
        present: r || dt(s.checked) || s.checked === !0,
        children: /* @__PURE__ */ m.jsx(
          le.span,
          {
            "data-state": ja(s.checked),
            "data-disabled": s.disabled ? "" : void 0,
            ...o,
            ref: t,
            style: { pointerEvents: "none", ...e.style }
          }
        )
      }
    );
  }
);
Ur.displayName = Aa;
var Na = "CheckboxBubbleInput", Ta = h.forwardRef(
  ({ __scopeCheckbox: e, ...t }, n) => {
    const {
      control: r,
      hasConsumerStoppedPropagationRef: o,
      checked: s,
      defaultChecked: a,
      required: i,
      disabled: l,
      name: c,
      value: d,
      form: f,
      bubbleInput: p,
      setBubbleInput: u
    } = Wr(Na, e), g = pe(n, u), b = ka(s), x = Vr(r);
    h.useEffect(() => {
      const y = p;
      if (!y) return;
      const S = window.HTMLInputElement.prototype, k = Object.getOwnPropertyDescriptor(
        S,
        "checked"
      ).set, E = !o.current;
      if (b !== s && k) {
        const w = new Event("click", { bubbles: E });
        y.indeterminate = dt(s), k.call(y, dt(s) ? !1 : s), y.dispatchEvent(w);
      }
    }, [p, b, s, o]);
    const v = h.useRef(dt(s) ? !1 : s);
    return /* @__PURE__ */ m.jsx(
      le.input,
      {
        type: "checkbox",
        "aria-hidden": !0,
        defaultChecked: a ?? v.current,
        required: i,
        disabled: l,
        name: c,
        value: d,
        form: f,
        ...t,
        tabIndex: -1,
        ref: g,
        style: {
          ...t.style,
          ...x,
          position: "absolute",
          pointerEvents: "none",
          opacity: 0,
          margin: 0,
          // We transform because the input is absolutely positioned but we have
          // rendered it **after** the button. This pulls it back to sit on top
          // of the button.
          transform: "translateX(-100%)"
        }
      }
    );
  }
);
Ta.displayName = Na;
function zp(e) {
  return typeof e == "function";
}
function dt(e) {
  return e === "indeterminate";
}
function ja(e) {
  return dt(e) ? "indeterminate" : e ? "checked" : "unchecked";
}
// @__NO_SIDE_EFFECTS__
function Ss(e) {
  const t = /* @__PURE__ */ Op(e), n = h.forwardRef((r, o) => {
    const { children: s, ...a } = r, i = h.Children.toArray(s), l = i.find($p);
    if (l) {
      const c = l.props.children, d = i.map((f) => f === l ? h.Children.count(c) > 1 ? h.Children.only(null) : h.isValidElement(c) ? c.props.children : null : f);
      return /* @__PURE__ */ m.jsx(t, { ...a, ref: o, children: h.isValidElement(c) ? h.cloneElement(c, void 0, d) : null });
    }
    return /* @__PURE__ */ m.jsx(t, { ...a, ref: o, children: s });
  });
  return n.displayName = `${e}.Slot`, n;
}
// @__NO_SIDE_EFFECTS__
function Op(e) {
  const t = h.forwardRef((n, r) => {
    const { children: o, ...s } = n;
    if (h.isValidElement(o)) {
      const a = Bp(o), i = Fp(s, o.props);
      return o.type !== h.Fragment && (i.ref = r ? On(r, a) : a), h.cloneElement(o, i);
    }
    return h.Children.count(o) > 1 ? h.Children.only(null) : null;
  });
  return t.displayName = `${e}.SlotClone`, t;
}
var _p = Symbol("radix.slottable");
function $p(e) {
  return h.isValidElement(e) && typeof e.type == "function" && "__radixId" in e.type && e.type.__radixId === _p;
}
function Fp(e, t) {
  const n = { ...t };
  for (const r in t) {
    const o = e[r], s = t[r];
    /^on[A-Z]/.test(r) ? o && s ? n[r] = (...i) => {
      const l = s(...i);
      return o(...i), l;
    } : o && (n[r] = o) : r === "style" ? n[r] = { ...o, ...s } : r === "className" && (n[r] = [o, s].filter(Boolean).join(" "));
  }
  return { ...e, ...n };
}
function Bp(e) {
  var r, o;
  let t = (r = Object.getOwnPropertyDescriptor(e.props, "ref")) == null ? void 0 : r.get, n = t && "isReactWarning" in t && t.isReactWarning;
  return n ? e.ref : (t = (o = Object.getOwnPropertyDescriptor(e, "ref")) == null ? void 0 : o.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
function Ia(e) {
  const t = e + "CollectionProvider", [n, r] = We(t), [o, s] = n(
    t,
    { collectionRef: { current: null }, itemMap: /* @__PURE__ */ new Map() }
  ), a = (b) => {
    const { scope: x, children: v } = b, y = P.useRef(null), S = P.useRef(/* @__PURE__ */ new Map()).current;
    return /* @__PURE__ */ m.jsx(o, { scope: x, itemMap: S, collectionRef: y, children: v });
  };
  a.displayName = t;
  const i = e + "CollectionSlot", l = /* @__PURE__ */ Ss(i), c = P.forwardRef(
    (b, x) => {
      const { scope: v, children: y } = b, S = s(i, v), C = pe(x, S.collectionRef);
      return /* @__PURE__ */ m.jsx(l, { ref: C, children: y });
    }
  );
  c.displayName = i;
  const d = e + "CollectionItemSlot", f = "data-radix-collection-item", p = /* @__PURE__ */ Ss(d), u = P.forwardRef(
    (b, x) => {
      const { scope: v, children: y, ...S } = b, C = P.useRef(null), k = pe(x, C), E = s(d, v);
      return P.useEffect(() => (E.itemMap.set(C, { ref: C, ...S }), () => void E.itemMap.delete(C))), /* @__PURE__ */ m.jsx(p, { [f]: "", ref: k, children: y });
    }
  );
  u.displayName = d;
  function g(b) {
    const x = s(e + "CollectionConsumer", b);
    return P.useCallback(() => {
      const y = x.collectionRef.current;
      if (!y) return [];
      const S = Array.from(y.querySelectorAll(`[${f}]`));
      return Array.from(x.itemMap.values()).sort(
        (E, w) => S.indexOf(E.ref.current) - S.indexOf(w.ref.current)
      );
    }, [x.collectionRef, x.itemMap]);
  }
  return [
    { Provider: a, Slot: c, ItemSlot: u },
    g,
    r
  ];
}
var Hp = Dn[" useId ".trim().toString()] || (() => {
}), Vp = 0;
function $n(e) {
  const [t, n] = h.useState(Hp());
  return He(() => {
    n((r) => r ?? String(Vp++));
  }, [e]), e || (t ? `radix-${t}` : "");
}
function Re(e) {
  const t = h.useRef(e);
  return h.useEffect(() => {
    t.current = e;
  }), h.useMemo(() => (...n) => {
    var r;
    return (r = t.current) == null ? void 0 : r.call(t, ...n);
  }, []);
}
var Wp = h.createContext(void 0);
function Fn(e) {
  const t = h.useContext(Wp);
  return e || t || "ltr";
}
var pr = "rovingFocusGroup.onEntryFocus", Gp = { bubbles: !1, cancelable: !0 }, nn = "RovingFocusGroup", [Pr, Ma, Up] = Ia(nn), [Kp, La] = We(
  nn,
  [Up]
), [Yp, Xp] = Kp(nn), Da = h.forwardRef(
  (e, t) => /* @__PURE__ */ m.jsx(Pr.Provider, { scope: e.__scopeRovingFocusGroup, children: /* @__PURE__ */ m.jsx(Pr.Slot, { scope: e.__scopeRovingFocusGroup, children: /* @__PURE__ */ m.jsx(qp, { ...e, ref: t }) }) })
);
Da.displayName = nn;
var qp = h.forwardRef((e, t) => {
  const {
    __scopeRovingFocusGroup: n,
    orientation: r,
    loop: o = !1,
    dir: s,
    currentTabStopId: a,
    defaultCurrentTabStopId: i,
    onCurrentTabStopIdChange: l,
    onEntryFocus: c,
    preventScrollOnEntryFocus: d = !1,
    ...f
  } = e, p = h.useRef(null), u = pe(t, p), g = Fn(s), [b, x] = Ct({
    prop: a,
    defaultProp: i ?? null,
    onChange: l,
    caller: nn
  }), [v, y] = h.useState(!1), S = Re(c), C = Ma(n), k = h.useRef(!1), [E, w] = h.useState(0);
  return h.useEffect(() => {
    const R = p.current;
    if (R)
      return R.addEventListener(pr, S), () => R.removeEventListener(pr, S);
  }, [S]), /* @__PURE__ */ m.jsx(
    Yp,
    {
      scope: n,
      orientation: r,
      dir: g,
      loop: o,
      currentTabStopId: b,
      onItemFocus: h.useCallback(
        (R) => x(R),
        [x]
      ),
      onItemShiftTab: h.useCallback(() => y(!0), []),
      onFocusableItemAdd: h.useCallback(
        () => w((R) => R + 1),
        []
      ),
      onFocusableItemRemove: h.useCallback(
        () => w((R) => R - 1),
        []
      ),
      children: /* @__PURE__ */ m.jsx(
        le.div,
        {
          tabIndex: v || E === 0 ? -1 : 0,
          "data-orientation": r,
          ...f,
          ref: u,
          style: { outline: "none", ...e.style },
          onMouseDown: ae(e.onMouseDown, () => {
            k.current = !0;
          }),
          onFocus: ae(e.onFocus, (R) => {
            const T = !k.current;
            if (R.target === R.currentTarget && T && !v) {
              const I = new CustomEvent(pr, Gp);
              if (R.currentTarget.dispatchEvent(I), !I.defaultPrevented) {
                const A = C().filter((L) => L.focusable), N = A.find((L) => L.active), _ = A.find((L) => L.id === b), M = [N, _, ...A].filter(
                  Boolean
                ).map((L) => L.ref.current);
                _a(M, d);
              }
            }
            k.current = !1;
          }),
          onBlur: ae(e.onBlur, () => y(!1))
        }
      )
    }
  );
}), za = "RovingFocusGroupItem", Oa = h.forwardRef(
  (e, t) => {
    const {
      __scopeRovingFocusGroup: n,
      focusable: r = !0,
      active: o = !1,
      tabStopId: s,
      children: a,
      ...i
    } = e, l = $n(), c = s || l, d = Xp(za, n), f = d.currentTabStopId === c, p = Ma(n), { onFocusableItemAdd: u, onFocusableItemRemove: g, currentTabStopId: b } = d;
    return h.useEffect(() => {
      if (r)
        return u(), () => g();
    }, [r, u, g]), /* @__PURE__ */ m.jsx(
      Pr.ItemSlot,
      {
        scope: n,
        id: c,
        focusable: r,
        active: o,
        children: /* @__PURE__ */ m.jsx(
          le.span,
          {
            tabIndex: f ? 0 : -1,
            "data-orientation": d.orientation,
            ...i,
            ref: t,
            onMouseDown: ae(e.onMouseDown, (x) => {
              r ? d.onItemFocus(c) : x.preventDefault();
            }),
            onFocus: ae(e.onFocus, () => d.onItemFocus(c)),
            onKeyDown: ae(e.onKeyDown, (x) => {
              if (x.key === "Tab" && x.shiftKey) {
                d.onItemShiftTab();
                return;
              }
              if (x.target !== x.currentTarget) return;
              const v = Qp(x, d.orientation, d.dir);
              if (v !== void 0) {
                if (x.metaKey || x.ctrlKey || x.altKey || x.shiftKey) return;
                x.preventDefault();
                let S = p().filter((C) => C.focusable).map((C) => C.ref.current);
                if (v === "last") S.reverse();
                else if (v === "prev" || v === "next") {
                  v === "prev" && S.reverse();
                  const C = S.indexOf(x.currentTarget);
                  S = d.loop ? em(S, C + 1) : S.slice(C + 1);
                }
                setTimeout(() => _a(S));
              }
            }),
            children: typeof a == "function" ? a({ isCurrentTabStop: f, hasTabStop: b != null }) : a
          }
        )
      }
    );
  }
);
Oa.displayName = za;
var Jp = {
  ArrowLeft: "prev",
  ArrowUp: "prev",
  ArrowRight: "next",
  ArrowDown: "next",
  PageUp: "first",
  Home: "first",
  PageDown: "last",
  End: "last"
};
function Zp(e, t) {
  return t !== "rtl" ? e : e === "ArrowLeft" ? "ArrowRight" : e === "ArrowRight" ? "ArrowLeft" : e;
}
function Qp(e, t, n) {
  const r = Zp(e.key, n);
  if (!(t === "vertical" && ["ArrowLeft", "ArrowRight"].includes(r)) && !(t === "horizontal" && ["ArrowUp", "ArrowDown"].includes(r)))
    return Jp[r];
}
function _a(e, t = !1) {
  const n = document.activeElement;
  for (const r of e)
    if (r === n || (r.focus({ preventScroll: t }), document.activeElement !== n)) return;
}
function em(e, t) {
  return e.map((n, r) => e[(t + r) % e.length]);
}
var tm = Da, nm = Oa, Kr = "Radio", [rm, $a] = We(Kr), [om, sm] = rm(Kr), Fa = h.forwardRef(
  (e, t) => {
    const {
      __scopeRadio: n,
      name: r,
      checked: o = !1,
      required: s,
      disabled: a,
      value: i = "on",
      onCheck: l,
      form: c,
      ...d
    } = e, [f, p] = h.useState(null), u = pe(t, (x) => p(x)), g = h.useRef(!1), b = f ? c || !!f.closest("form") : !0;
    return /* @__PURE__ */ m.jsxs(om, { scope: n, checked: o, disabled: a, children: [
      /* @__PURE__ */ m.jsx(
        le.button,
        {
          type: "button",
          role: "radio",
          "aria-checked": o,
          "data-state": Wa(o),
          "data-disabled": a ? "" : void 0,
          disabled: a,
          value: i,
          ...d,
          ref: u,
          onClick: ae(e.onClick, (x) => {
            o || l == null || l(), b && (g.current = x.isPropagationStopped(), g.current || x.stopPropagation());
          })
        }
      ),
      b && /* @__PURE__ */ m.jsx(
        Va,
        {
          control: f,
          bubbles: !g.current,
          name: r,
          value: i,
          checked: o,
          required: s,
          disabled: a,
          form: c,
          style: { transform: "translateX(-100%)" }
        }
      )
    ] });
  }
);
Fa.displayName = Kr;
var Ba = "RadioIndicator", Ha = h.forwardRef(
  (e, t) => {
    const { __scopeRadio: n, forceMount: r, ...o } = e, s = sm(Ba, n);
    return /* @__PURE__ */ m.jsx(Ge, { present: r || s.checked, children: /* @__PURE__ */ m.jsx(
      le.span,
      {
        "data-state": Wa(s.checked),
        "data-disabled": s.disabled ? "" : void 0,
        ...o,
        ref: t
      }
    ) });
  }
);
Ha.displayName = Ba;
var am = "RadioBubbleInput", Va = h.forwardRef(
  ({
    __scopeRadio: e,
    control: t,
    checked: n,
    bubbles: r = !0,
    ...o
  }, s) => {
    const a = h.useRef(null), i = pe(a, s), l = ka(n), c = Vr(t);
    return h.useEffect(() => {
      const d = a.current;
      if (!d) return;
      const f = window.HTMLInputElement.prototype, u = Object.getOwnPropertyDescriptor(
        f,
        "checked"
      ).set;
      if (l !== n && u) {
        const g = new Event("click", { bubbles: r });
        u.call(d, n), d.dispatchEvent(g);
      }
    }, [l, n, r]), /* @__PURE__ */ m.jsx(
      le.input,
      {
        type: "radio",
        "aria-hidden": !0,
        defaultChecked: n,
        ...o,
        tabIndex: -1,
        ref: i,
        style: {
          ...o.style,
          ...c,
          position: "absolute",
          pointerEvents: "none",
          opacity: 0,
          margin: 0
        }
      }
    );
  }
);
Va.displayName = am;
function Wa(e) {
  return e ? "checked" : "unchecked";
}
var im = ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"], Bn = "RadioGroup", [lm] = We(Bn, [
  La,
  $a
]), Ga = La(), Ua = $a(), [cm, um] = lm(Bn), Ka = h.forwardRef(
  (e, t) => {
    const {
      __scopeRadioGroup: n,
      name: r,
      defaultValue: o,
      value: s,
      required: a = !1,
      disabled: i = !1,
      orientation: l,
      dir: c,
      loop: d = !0,
      onValueChange: f,
      ...p
    } = e, u = Ga(n), g = Fn(c), [b, x] = Ct({
      prop: s,
      defaultProp: o ?? null,
      onChange: f,
      caller: Bn
    });
    return /* @__PURE__ */ m.jsx(
      cm,
      {
        scope: n,
        name: r,
        required: a,
        disabled: i,
        value: b,
        onValueChange: x,
        children: /* @__PURE__ */ m.jsx(
          tm,
          {
            asChild: !0,
            ...u,
            orientation: l,
            dir: g,
            loop: d,
            children: /* @__PURE__ */ m.jsx(
              le.div,
              {
                role: "radiogroup",
                "aria-required": a,
                "aria-orientation": l,
                "data-disabled": i ? "" : void 0,
                dir: g,
                ...p,
                ref: t
              }
            )
          }
        )
      }
    );
  }
);
Ka.displayName = Bn;
var Ya = "RadioGroupItem", Xa = h.forwardRef(
  (e, t) => {
    const { __scopeRadioGroup: n, disabled: r, ...o } = e, s = um(Ya, n), a = s.disabled || r, i = Ga(n), l = Ua(n), c = h.useRef(null), d = pe(t, c), f = s.value === o.value, p = h.useRef(!1);
    return h.useEffect(() => {
      const u = (b) => {
        im.includes(b.key) && (p.current = !0);
      }, g = () => p.current = !1;
      return document.addEventListener("keydown", u), document.addEventListener("keyup", g), () => {
        document.removeEventListener("keydown", u), document.removeEventListener("keyup", g);
      };
    }, []), /* @__PURE__ */ m.jsx(
      nm,
      {
        asChild: !0,
        ...i,
        focusable: !a,
        active: f,
        children: /* @__PURE__ */ m.jsx(
          Fa,
          {
            disabled: a,
            required: s.required,
            checked: f,
            ...l,
            ...o,
            name: s.name,
            ref: d,
            onCheck: () => s.onValueChange(o.value),
            onKeyDown: ae((u) => {
              u.key === "Enter" && u.preventDefault();
            }),
            onFocus: ae(o.onFocus, () => {
              var u;
              p.current && ((u = c.current) == null || u.click());
            })
          }
        )
      }
    );
  }
);
Xa.displayName = Ya;
var dm = "RadioGroupIndicator", qa = h.forwardRef(
  (e, t) => {
    const { __scopeRadioGroup: n, ...r } = e, o = Ua(n);
    return /* @__PURE__ */ m.jsx(Ha, { ...o, ...r, ref: t });
  }
);
qa.displayName = dm;
var fm = Ka, pm = Xa, mm = qa;
function Hn({
  id: e,
  className: t,
  label: n,
  description: r,
  required: o = !1,
  error: s,
  children: a,
  "data-refast-id": i
}) {
  return !n && !r && !s ? /* @__PURE__ */ m.jsx(m.Fragment, { children: a }) : /* @__PURE__ */ m.jsxs("div", { className: D("mb-2", t), "data-input-wrapper": !0, "data-refast-id": i, children: [
    n && /* @__PURE__ */ m.jsxs(
      "label",
      {
        htmlFor: e,
        className: "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
        children: [
          n,
          o && /* @__PURE__ */ m.jsx("span", { className: "text-destructive ml-1", children: "*" })
        ]
      }
    ),
    r && /* @__PURE__ */ m.jsx("p", { className: "text-sm text-muted-foreground", children: r }),
    /* @__PURE__ */ m.jsx("div", { className: "my-1", children: a }),
    s && /* @__PURE__ */ m.jsx("p", { className: "text-xs text-destructive", children: s })
  ] });
}
function hm({
  id: e,
  className: t,
  label: n,
  description: r,
  type: o = "text",
  placeholder: s,
  value: a,
  defaultValue: i,
  disabled: l = !1,
  required: c = !1,
  error: d,
  name: f,
  debounce: p = 0,
  onChange: u,
  onBlur: g,
  onFocus: b,
  onKeydown: x,
  onKeyup: v,
  onInput: y,
  "data-refast-id": S
}) {
  const [C, k] = P.useState(a !== void 0 ? a : i || ""), E = P.useRef(null), w = P.useRef(u), R = P.useRef(a);
  P.useEffect(() => {
    w.current = u;
  }, [u]), P.useEffect(() => {
    a !== void 0 && a !== R.current && (R.current = a, E.current || k(a));
  }, [a]), P.useEffect(() => {
    const A = (N) => {
      const { targetId: _, value: O } = N.detail;
      _ === e && O !== void 0 && (R.current = O, k(O), E.current !== null && (window.clearTimeout(E.current), E.current = null));
    };
    return window.addEventListener("refast:force-value-sync", A), () => window.removeEventListener("refast:force-value-sync", A);
  }, [e]), P.useEffect(() => () => {
    E.current !== null && (window.clearTimeout(E.current), E.current = null);
  }, []);
  const T = P.useCallback(
    (A) => {
      const N = A.target.value;
      if (k(N), !!w.current) {
        if (p > 0) {
          E.current !== null && window.clearTimeout(E.current);
          const _ = {
            ...A,
            target: { ...A.target, tagName: A.target.tagName, name: A.target.name, type: A.target.type, value: N },
            currentTarget: { ...A.currentTarget, tagName: A.currentTarget.tagName, name: A.currentTarget.name, type: A.currentTarget.type, value: N }
          };
          E.current = window.setTimeout(() => {
            var O;
            E.current = null, (O = w.current) == null || O.call(w, _);
          }, p);
          return;
        }
        w.current(A);
      }
    },
    [p, f]
  ), I = /* @__PURE__ */ m.jsx(
    "input",
    {
      id: e,
      type: o,
      placeholder: s,
      value: C,
      disabled: l,
      required: c,
      name: f || void 0,
      onChange: T,
      onBlur: g,
      onFocus: b,
      onKeyDown: x,
      onKeyUp: v,
      onInput: y,
      className: D(
        "flex h-10 w-full rounded-md border bg-background px-3 py-2 text-sm",
        "ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "disabled:cursor-not-allowed disabled:opacity-50",
        d ? "border-destructive placeholder:text-destructive" : "border-input placeholder:text-muted-foreground",
        t
      )
    }
  );
  return n || r || d ? /* @__PURE__ */ m.jsx(
    Hn,
    {
      id: e,
      label: n,
      description: r,
      required: c,
      error: d,
      "data-refast-id": S,
      children: I
    }
  ) : /* @__PURE__ */ m.jsx("div", { "data-refast-id": S, children: I });
}
function gm({
  id: e,
  className: t,
  label: n,
  description: r,
  required: o = !1,
  error: s,
  placeholder: a,
  value: i,
  defaultValue: l,
  disabled: c = !1,
  rows: d = 3,
  name: f,
  debounce: p = 0,
  onChange: u,
  onBlur: g,
  onFocus: b,
  onKeydown: x,
  onKeyup: v,
  onInput: y,
  "data-refast-id": S
}) {
  const [C, k] = P.useState(i !== void 0 ? i : l || ""), E = P.useRef(null), w = P.useRef(u), R = P.useRef(i);
  P.useEffect(() => {
    w.current = u;
  }, [u]), P.useEffect(() => {
    i !== void 0 && i !== R.current && (R.current = i, E.current || k(i));
  }, [i]), P.useEffect(() => {
    const A = (N) => {
      const { targetId: _, value: O } = N.detail;
      _ === e && O !== void 0 && (R.current = O, k(O), E.current !== null && (window.clearTimeout(E.current), E.current = null));
    };
    return window.addEventListener("refast:force-value-sync", A), () => window.removeEventListener("refast:force-value-sync", A);
  }, [e]), P.useEffect(() => () => {
    E.current !== null && (window.clearTimeout(E.current), E.current = null);
  }, []);
  const T = P.useCallback(
    (A) => {
      const N = A.target.value;
      if (k(N), !!w.current) {
        if (p > 0) {
          E.current !== null && window.clearTimeout(E.current);
          const _ = {
            ...A,
            target: { ...A.target, tagName: A.target.tagName, name: A.target.name, value: N },
            currentTarget: { ...A.currentTarget, tagName: A.currentTarget.tagName, name: A.currentTarget.name, value: N }
          };
          E.current = window.setTimeout(() => {
            var O;
            E.current = null, (O = w.current) == null || O.call(w, _);
          }, p);
          return;
        }
        w.current(A);
      }
    },
    [p, f]
  ), I = /* @__PURE__ */ m.jsx(
    "textarea",
    {
      id: e,
      placeholder: a,
      value: C,
      disabled: c,
      required: o,
      rows: d,
      name: f || void 0,
      onChange: T,
      onBlur: g,
      onFocus: b,
      onKeyDown: x,
      onKeyUp: v,
      onInput: y,
      className: D(
        "flex min-h-[80px] w-full rounded-md border bg-background px-3 py-2 text-sm",
        "ring-offset-background placeholder:text-muted-foreground",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "disabled:cursor-not-allowed disabled:opacity-50",
        s ? "border-destructive" : "border-input",
        t
      )
    }
  );
  return n || r || s ? /* @__PURE__ */ m.jsx(
    Hn,
    {
      id: e,
      label: n,
      description: r,
      required: o,
      error: s,
      "data-refast-id": S,
      children: I
    }
  ) : /* @__PURE__ */ m.jsx("div", { "data-refast-id": S, children: I });
}
function bm({
  id: e,
  className: t,
  label: n,
  description: r,
  required: o = !1,
  error: s,
  placeholder: a,
  value: i,
  defaultValue: l,
  disabled: c = !1,
  name: d,
  options: f,
  onChange: p,
  children: u,
  "data-refast-id": g
}) {
  const [b, x] = P.useState(i !== void 0 ? i : l || "");
  P.useEffect(() => {
    i !== void 0 && x(i);
  }, [i]), P.useEffect(() => {
    const S = (C) => {
      const { targetId: k, value: E } = C.detail;
      k === e && E !== void 0 && x(E);
    };
    return window.addEventListener("refast:force-value-sync", S), () => window.removeEventListener("refast:force-value-sync", S);
  }, [e]);
  const v = (S) => {
    x(S.target.value), p && p(S);
  }, y = /* @__PURE__ */ m.jsxs(
    "select",
    {
      id: e,
      value: b,
      disabled: c,
      required: o,
      name: d || void 0,
      onChange: v,
      className: D(
        "flex h-10 w-full items-center justify-between rounded-md border bg-background px-3 py-2 text-sm",
        "ring-offset-background placeholder:text-muted-foreground",
        "focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
        "disabled:cursor-not-allowed disabled:opacity-50",
        s ? "border-destructive" : "border-input",
        t
      ),
      children: [
        a && /* @__PURE__ */ m.jsx("option", { value: "", disabled: !0, children: a }),
        f == null ? void 0 : f.map((S) => /* @__PURE__ */ m.jsx("option", { value: S.value, disabled: S.disabled, children: S.label }, S.value)),
        u
      ]
    }
  );
  return n || r || s ? /* @__PURE__ */ m.jsx(
    Hn,
    {
      id: e,
      label: n,
      description: r,
      required: o,
      error: s,
      "data-refast-id": g,
      children: y
    }
  ) : /* @__PURE__ */ m.jsx("div", { "data-refast-id": g, children: y });
}
function vm({
  value: e,
  disabled: t = !1,
  children: n,
  "data-refast-id": r
}) {
  return /* @__PURE__ */ m.jsx("option", { value: e, disabled: t, "data-refast-id": r, children: n });
}
function xm({
  id: e,
  className: t,
  label: n,
  description: r,
  required: o = !1,
  error: s,
  checked: a,
  defaultChecked: i,
  disabled: l = !1,
  name: c,
  value: d,
  onCheckedChange: f,
  "data-refast-id": p
}) {
  const u = P.useId(), g = e || u, [b, x] = P.useState(a !== void 0 ? a : i || !1);
  P.useEffect(() => {
    a !== void 0 && x(a);
  }, [a]);
  const v = (S) => {
    const C = S === !0;
    x(C), f && f(C);
  }, y = /* @__PURE__ */ m.jsxs("div", { className: "flex items-center space-x-2", children: [
    /* @__PURE__ */ m.jsx(
      Gr,
      {
        id: g,
        name: c || void 0,
        value: d,
        checked: b,
        defaultChecked: i,
        disabled: l,
        onCheckedChange: v,
        className: D(
          "peer h-4 w-4 shrink-0 rounded-sm border ring-offset-background",
          "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
          "disabled:cursor-not-allowed disabled:opacity-50",
          "data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground",
          s ? "border-destructive" : "border-primary"
        ),
        children: /* @__PURE__ */ m.jsx(Ur, { className: D("flex items-center justify-center text-current"), children: /* @__PURE__ */ m.jsx(Fr, { className: "h-4 w-4" }) })
      }
    ),
    n && /* @__PURE__ */ m.jsxs(
      "label",
      {
        htmlFor: g,
        className: "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
        children: [
          n,
          o && /* @__PURE__ */ m.jsx("span", { className: "text-destructive ml-1", children: "*" })
        ]
      }
    )
  ] });
  return r || s ? /* @__PURE__ */ m.jsxs("div", { className: D("space-y-1", t), "data-refast-id": p, children: [
    y,
    r && /* @__PURE__ */ m.jsx("p", { className: "text-sm text-muted-foreground ml-6", children: r }),
    s && /* @__PURE__ */ m.jsx("p", { className: "text-xs text-destructive ml-6", children: s })
  ] }) : /* @__PURE__ */ m.jsx("div", { className: t, "data-refast-id": p, children: y });
}
function ym({
  id: e,
  className: t,
  checked: n,
  defaultChecked: r,
  disabled: o = !1,
  name: s,
  value: a,
  onChange: i,
  label: l,
  description: c,
  required: d,
  error: f,
  "data-refast-id": p
}) {
  const [u, g] = P.useState(n !== void 0 ? n : r || !1);
  P.useEffect(() => {
    n !== void 0 && g(n);
  }, [n]);
  const b = (x) => {
    g(x.target.checked), i && i(x);
  };
  return /* @__PURE__ */ m.jsxs("div", { className: "space-y-1", "data-refast-id": p, children: [
    /* @__PURE__ */ m.jsxs("label", { className: D("flex items-center space-x-2", t), children: [
      /* @__PURE__ */ m.jsx(
        "input",
        {
          id: e,
          type: "radio",
          checked: u,
          disabled: o,
          name: s || void 0,
          value: a,
          onChange: b,
          className: D(
            "aspect-square h-4 w-4 rounded-full border border-primary text-primary ring-offset-background",
            "focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
            "disabled:cursor-not-allowed disabled:opacity-50",
            f && "border-destructive"
          )
        }
      ),
      l && /* @__PURE__ */ m.jsxs("span", { className: "text-sm font-medium leading-none", children: [
        l,
        d && /* @__PURE__ */ m.jsx("span", { className: "text-destructive ml-1", children: "*" })
      ] })
    ] }),
    (c || f) && /* @__PURE__ */ m.jsxs("div", { className: "ml-6", children: [
      c && !f && /* @__PURE__ */ m.jsx("p", { className: "text-sm text-muted-foreground", children: c }),
      f && /* @__PURE__ */ m.jsx("p", { className: "text-sm text-destructive", children: f })
    ] })
  ] });
}
function wm({
  id: e,
  className: t,
  name: n,
  value: r,
  defaultValue: o,
  disabled: s = !1,
  orientation: a = "vertical",
  label: i,
  description: l,
  required: c,
  error: d,
  options: f,
  onValueChange: p,
  children: u,
  "data-refast-id": g
}) {
  const b = P.useId(), x = e || b, [v, y] = P.useState(r !== void 0 ? r : o || "");
  P.useEffect(() => {
    r !== void 0 && y(r);
  }, [r]), P.useEffect(() => {
    const k = (E) => {
      const { targetId: w, value: R } = E.detail;
      w === e && R !== void 0 && y(R);
    };
    return window.addEventListener("refast:force-value-sync", k), () => window.removeEventListener("refast:force-value-sync", k);
  }, [e]);
  const S = (k) => {
    y(k), p && p(k);
  }, C = () => f && f.length > 0 ? f.map((k) => /* @__PURE__ */ m.jsxs("div", { className: "flex items-center space-x-2", children: [
    /* @__PURE__ */ m.jsx(
      pm,
      {
        value: k.value,
        id: `${x}-${k.value}`,
        disabled: k.disabled,
        className: D(
          "aspect-square h-4 w-4 rounded-full border border-primary text-primary ring-offset-background",
          "focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
          "disabled:cursor-not-allowed disabled:opacity-50",
          d && "border-destructive"
        ),
        children: /* @__PURE__ */ m.jsx(mm, { className: "flex items-center justify-center", children: /* @__PURE__ */ m.jsx(la, { className: "h-2.5 w-2.5 fill-current text-current" }) })
      }
    ),
    /* @__PURE__ */ m.jsx(
      "label",
      {
        htmlFor: `${x}-${k.value}`,
        className: D(
          "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
          k.disabled && "cursor-not-allowed opacity-70"
        ),
        children: k.label
      }
    )
  ] }, k.value)) : u;
  return /* @__PURE__ */ m.jsxs("div", { className: D("space-y-1", t), "data-refast-id": g, children: [
    i && /* @__PURE__ */ m.jsxs("label", { className: "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70", children: [
      i,
      c && /* @__PURE__ */ m.jsx("span", { className: "text-destructive ml-1", children: "*" })
    ] }),
    l && !d && /* @__PURE__ */ m.jsx("p", { className: "text-sm text-muted-foreground", children: l }),
    /* @__PURE__ */ m.jsx(
      fm,
      {
        className: D(
          "flex",
          a === "vertical" ? "flex-col space-y-2" : "flex-row space-x-4"
        ),
        value: v,
        defaultValue: o,
        disabled: s,
        name: n || void 0,
        onValueChange: S,
        orientation: a,
        id: x,
        children: C()
      }
    ),
    d && /* @__PURE__ */ m.jsx("p", { className: "text-sm text-destructive", children: d })
  ] });
}
function Cm({
  id: e,
  className: t,
  name: n,
  value: r,
  defaultValue: o,
  disabled: s = !1,
  orientation: a = "vertical",
  label: i,
  description: l,
  required: c,
  error: d,
  options: f,
  onChange: p,
  children: u,
  "data-refast-id": g
}) {
  const b = P.useId(), x = e || b, [v, y] = P.useState(
    r !== void 0 ? r : o || []
  );
  P.useEffect(() => {
    r !== void 0 && y(r);
  }, [r]);
  const S = (k, E) => {
    let w;
    E ? v.includes(k) ? w = v : w = [...v, k] : w = v.filter((R) => R !== k), y(w), p && p(w);
  }, C = () => f && f.length > 0 ? f.map((k) => {
    const E = `${x}-${k.value}`, w = v.includes(k.value), R = s || k.disabled;
    return /* @__PURE__ */ m.jsxs("div", { className: "flex items-center space-x-2", children: [
      /* @__PURE__ */ m.jsx(
        Gr,
        {
          id: E,
          name: n || void 0,
          value: k.value,
          checked: w,
          disabled: R,
          onCheckedChange: (T) => S(k.value, T === !0),
          className: D(
            "peer h-4 w-4 shrink-0 rounded-sm border border-primary ring-offset-background",
            "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
            "disabled:cursor-not-allowed disabled:opacity-50",
            "data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground",
            d && "border-destructive"
          ),
          children: /* @__PURE__ */ m.jsx(Ur, { className: D("flex items-center justify-center text-current"), children: /* @__PURE__ */ m.jsx(Fr, { className: "h-4 w-4" }) })
        }
      ),
      /* @__PURE__ */ m.jsx(
        "label",
        {
          htmlFor: E,
          className: D(
            "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
            R && "cursor-not-allowed opacity-70"
          ),
          children: k.label
        }
      )
    ] }, k.value);
  }) : P.Children.map(u, (k) => {
    if (P.isValidElement(k) && k.props.value) {
      const E = k.props.value;
      return P.cloneElement(k, {
        name: n,
        checked: v.includes(E),
        disabled: s || k.props.disabled,
        onCheckedChange: (w) => S(E, w)
      });
    }
    return k;
  });
  return /* @__PURE__ */ m.jsxs(
    "div",
    {
      id: x,
      role: "group",
      className: D("space-y-1", t),
      "data-refast-id": g,
      children: [
        i && /* @__PURE__ */ m.jsxs("label", { className: "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70", children: [
          i,
          c && /* @__PURE__ */ m.jsx("span", { className: "text-destructive ml-1", children: "*" })
        ] }),
        l && !d && /* @__PURE__ */ m.jsx("p", { className: "text-sm text-muted-foreground", children: l }),
        /* @__PURE__ */ m.jsx(
          "div",
          {
            className: D(
              "flex",
              a === "vertical" ? "flex-col space-y-2" : "flex-row space-x-4"
            ),
            children: C()
          }
        ),
        d && /* @__PURE__ */ m.jsx("p", { className: "text-sm text-destructive", children: d })
      ]
    }
  );
}
function Sm({
  id: e,
  name: t,
  fallback: n,
  children: r,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ m.jsx("div", { id: e, "data-slot-name": t, "data-refast-id": o, children: r || n || null });
}
function Ja() {
  const [e, t] = P.useState(() => typeof document < "u" && document.documentElement.classList.contains("dark") ? "dark" : "light");
  return P.useEffect(() => {
    if (typeof document > "u") return;
    const n = document.documentElement.classList.contains("dark");
    (n && e === "light" || !n && e === "dark") && t(n ? "dark" : "light");
    const r = new MutationObserver((o) => {
      for (const s of o)
        if (s.type === "attributes" && s.attributeName === "class") {
          const a = document.documentElement.classList.contains("dark");
          t(a ? "dark" : "light");
        }
    });
    return r.observe(document.documentElement, {
      attributes: !0,
      attributeFilter: ["class"]
    }), () => r.disconnect();
  }, []), e;
}
function Em({
  id: e,
  className: t,
  level: n = 1,
  children: r,
  style: o,
  "data-refast-id": s
}) {
  const a = {
    1: "scroll-m-20 text-4xl font-bold tracking-tight",
    2: "scroll-m-20 text-3xl font-semibold tracking-tight",
    3: "scroll-m-20 text-2xl font-semibold tracking-tight",
    4: "scroll-m-20 text-xl font-semibold tracking-tight",
    5: "scroll-m-20 text-lg font-semibold tracking-tight",
    6: "scroll-m-20 text-base font-semibold tracking-tight"
  }, i = `h${n}`;
  return /* @__PURE__ */ m.jsx(
    i,
    {
      id: e,
      className: D(a[n], t),
      style: o,
      "data-refast-id": s,
      children: r
    }
  );
}
function km({
  id: e,
  className: t,
  lead: n = !1,
  muted: r = !1,
  children: o,
  style: s,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ m.jsx(
    "p",
    {
      id: e,
      className: D(
        "leading-7",
        n && "text-xl text-muted-foreground",
        r && "text-sm text-muted-foreground",
        !n && !r && "[&:not(:first-child)]:mt-6",
        t
      ),
      style: s,
      "data-refast-id": a,
      children: o
    }
  );
}
function Pm({
  id: e,
  className: t,
  href: n = "#",
  target: r,
  external: o = !1,
  onClick: s,
  children: a,
  style: i,
  "data-refast-id": l
}) {
  return /* @__PURE__ */ m.jsx(
    "a",
    {
      id: e,
      href: n,
      target: o ? "_blank" : r,
      rel: o ? "noopener noreferrer" : void 0,
      onClick: s,
      className: D(
        "font-medium text-primary px-2 hover:bg-accent",
        t
      ),
      style: i,
      "data-refast-id": l,
      children: a
    }
  );
}
function Rm({
  id: e,
  className: t,
  inline: n = !0,
  showLineNumbers: r = !1,
  language: o,
  code: s,
  children: a,
  style: i,
  "data-refast-id": l
}) {
  const c = Ja(), [d, f] = P.useState(null), [p, u] = P.useState(null), g = P.useMemo(() => {
    if (s) return s;
    const x = (v) => typeof v == "string" ? v : typeof v == "number" ? String(v) : v ? Array.isArray(v) ? v.map(x).join("") : P.isValidElement(v) ? x(v.props.children) : "" : "";
    return x(a);
  }, [a, s]);
  P.useEffect(() => {
    n || (async () => {
      try {
        const [v, y, S] = await Promise.all([
          import("./refast-markdown-ByFT1VZb.js").then((L) => L.i),
          import("./refast-markdown-ByFT1VZb.js").then((L) => L.k),
          import("./refast-markdown-ByFT1VZb.js").then((L) => L.l)
        ]), C = v.default, [k, E, w, R, T, I, A, N, _, O, M] = await Promise.all([
          import("./refast-markdown-ByFT1VZb.js").then((L) => L.m),
          import("./refast-markdown-ByFT1VZb.js").then((L) => L.t),
          import("./refast-markdown-ByFT1VZb.js").then((L) => L.q),
          import("./refast-markdown-ByFT1VZb.js").then((L) => L.r),
          import("./refast-markdown-ByFT1VZb.js").then((L) => L.u),
          import("./refast-markdown-ByFT1VZb.js").then((L) => L.w),
          import("./refast-markdown-ByFT1VZb.js").then((L) => L.x),
          import("./refast-markdown-ByFT1VZb.js").then((L) => L.y),
          import("./refast-markdown-ByFT1VZb.js").then((L) => L.A),
          import("./refast-markdown-ByFT1VZb.js").then((L) => L.B),
          import("./refast-markdown-ByFT1VZb.js").then((L) => L.C)
        ]);
        C.registerLanguage("javascript", k.default), C.registerLanguage("js", k.default), C.registerLanguage("typescript", E.default), C.registerLanguage("ts", E.default), C.registerLanguage("python", w.default), C.registerLanguage("py", w.default), C.registerLanguage("bash", R.default), C.registerLanguage("shell", R.default), C.registerLanguage("sh", R.default), C.registerLanguage("json", T.default), C.registerLanguage("css", I.default), C.registerLanguage("jsx", A.default), C.registerLanguage("tsx", N.default), C.registerLanguage("sql", _.default), C.registerLanguage("yaml", O.default), C.registerLanguage("yml", O.default), C.registerLanguage("markdown", M.default), C.registerLanguage("md", M.default), f(() => C), u({
          light: S.default,
          dark: y.default
        });
      } catch (v) {
        console.error("Failed to load syntax highlighter:", v);
      }
    })();
  }, [n]);
  const b = p ? p[c] : null;
  return n ? /* @__PURE__ */ m.jsx(
    "code",
    {
      id: e,
      className: D(
        "relative rounded bg-muted px-[0.3rem] py-[0.2rem] font-mono text-sm font-semibold",
        t
      ),
      style: i,
      "data-refast-id": l,
      "data-language": o,
      children: g
    }
  ) : d && b ? /* @__PURE__ */ m.jsx(
    "div",
    {
      id: e,
      className: D("mb-4 mt-6 overflow-x-auto rounded-lg border", t),
      style: i,
      "data-refast-id": l,
      "data-language": o,
      children: /* @__PURE__ */ m.jsx(
        d,
        {
          language: o || "text",
          style: b,
          customStyle: {
            margin: 0,
            borderRadius: "0.5rem",
            fontSize: "0.875rem"
          },
          showLineNumbers: r,
          children: g
        }
      )
    }
  ) : /* @__PURE__ */ m.jsx(
    "pre",
    {
      id: e,
      className: D(
        "mb-4 mt-6 overflow-x-auto rounded-lg border py-4",
        c === "dark" ? "bg-zinc-950 text-white" : "bg-zinc-100 text-zinc-900",
        t
      ),
      "data-refast-id": l,
      "data-language": o,
      style: i,
      children: /* @__PURE__ */ m.jsx("code", { className: "relative rounded bg-transparent px-4 py-[0.2rem] font-mono text-sm text-inherit", children: g })
    }
  );
}
function Am({
  id: e,
  className: t,
  cite: n,
  children: r,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ m.jsx(
    "blockquote",
    {
      id: e,
      cite: n,
      className: D(
        "mt-6 border-l-2 pl-6 italic text-muted-foreground",
        t
      ),
      "data-refast-id": o,
      children: r
    }
  );
}
function Nm({
  id: e,
  className: t,
  ordered: n = !1,
  children: r,
  "data-refast-id": o
}) {
  const s = n ? "ol" : "ul";
  return /* @__PURE__ */ m.jsx(
    s,
    {
      id: e,
      className: D(
        "my-6 ml-6",
        n ? "list-decimal" : "list-disc",
        "[&>li]:mt-2",
        t
      ),
      "data-refast-id": o,
      children: r
    }
  );
}
function Tm({
  id: e,
  className: t,
  style: n,
  children: r,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ m.jsx("li", { id: e, className: D("", t), "data-refast-id": o, style: n, children: r });
}
function jm({
  id: e,
  className: t,
  htmlFor: n,
  required: r = !1,
  children: o,
  style: s,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ m.jsxs(
    "label",
    {
      id: e,
      htmlFor: n,
      className: D(
        "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
        t
      ),
      style: s,
      "data-refast-id": a,
      children: [
        o,
        r && /* @__PURE__ */ m.jsx("span", { className: "ml-1 text-destructive", children: "*" })
      ]
    }
  );
}
function Im({
  id: e,
  className: t,
  content: n,
  allowHtml: r = !1,
  "data-refast-id": o
}) {
  const s = Ja(), [a, i] = P.useState(null), [l, c] = P.useState(null), [d, f] = P.useState(null), [p, u] = P.useState(null), [g, b] = P.useState(null);
  P.useEffect(() => {
    (async () => {
      try {
        const [k, E, w] = await Promise.all([
          import("./refast-markdown-ByFT1VZb.js").then((R) => R.D),
          import("./refast-markdown-ByFT1VZb.js").then((R) => R.E),
          import("./refast-index-DDzJ7GHf.js")
        ]);
        i(() => k.default), c(() => E.default), f(() => w.default);
        try {
          const [R, T, I] = await Promise.all([
            import("./refast-markdown-ByFT1VZb.js").then((j) => j.i),
            import("./refast-markdown-ByFT1VZb.js").then((j) => j.k),
            import("./refast-markdown-ByFT1VZb.js").then((j) => j.l)
          ]), A = R.default, [N, _, O, M, L, V, W, B, te, re, J] = await Promise.all([
            import("./refast-markdown-ByFT1VZb.js").then((j) => j.m),
            import("./refast-markdown-ByFT1VZb.js").then((j) => j.t),
            import("./refast-markdown-ByFT1VZb.js").then((j) => j.q),
            import("./refast-markdown-ByFT1VZb.js").then((j) => j.r),
            import("./refast-markdown-ByFT1VZb.js").then((j) => j.u),
            import("./refast-markdown-ByFT1VZb.js").then((j) => j.w),
            import("./refast-markdown-ByFT1VZb.js").then((j) => j.x),
            import("./refast-markdown-ByFT1VZb.js").then((j) => j.y),
            import("./refast-markdown-ByFT1VZb.js").then((j) => j.A),
            import("./refast-markdown-ByFT1VZb.js").then((j) => j.B),
            import("./refast-markdown-ByFT1VZb.js").then((j) => j.C)
          ]);
          A.registerLanguage("javascript", N.default), A.registerLanguage("js", N.default), A.registerLanguage("typescript", _.default), A.registerLanguage("ts", _.default), A.registerLanguage("python", O.default), A.registerLanguage("py", O.default), A.registerLanguage("bash", M.default), A.registerLanguage("shell", M.default), A.registerLanguage("sh", M.default), A.registerLanguage("json", L.default), A.registerLanguage("css", V.default), A.registerLanguage("jsx", W.default), A.registerLanguage("tsx", B.default), A.registerLanguage("sql", te.default), A.registerLanguage("yaml", re.default), A.registerLanguage("yml", re.default), A.registerLanguage("markdown", J.default), A.registerLanguage("md", J.default), u(() => A), b({
            light: I.default,
            dark: T.default
          });
        } catch (R) {
          console.error("Failed to load syntax highlighter:", R);
        }
      } catch (k) {
        console.error("Failed to load markdown libraries:", k);
      }
    })();
  }, []);
  const x = P.useMemo(() => ({
    // Headers
    h1: ({ children: C }) => /* @__PURE__ */ m.jsx("h1", { className: "scroll-m-20 text-4xl font-extrabold tracking-tight lg:text-5xl mb-4", children: C }),
    h2: ({ children: C }) => /* @__PURE__ */ m.jsx("h2", { className: "scroll-m-20 border-b pb-2 text-3xl font-semibold tracking-tight first:mt-0 mt-8 mb-4", children: C }),
    h3: ({ children: C }) => /* @__PURE__ */ m.jsx("h3", { className: "scroll-m-20 text-2xl font-semibold tracking-tight mt-6 mb-3", children: C }),
    h4: ({ children: C }) => /* @__PURE__ */ m.jsx("h4", { className: "scroll-m-20 text-xl font-semibold tracking-tight mt-4 mb-2", children: C }),
    // Paragraph
    p: ({ children: C }) => /* @__PURE__ */ m.jsx("p", { className: "leading-7 [&:not(:first-child)]:mt-4", children: C }),
    // Lists
    ul: ({ children: C }) => /* @__PURE__ */ m.jsx("ul", { className: "my-4 ml-6 list-disc [&>li]:mt-2", children: C }),
    ol: ({ children: C }) => /* @__PURE__ */ m.jsx("ol", { className: "my-4 ml-6 list-decimal [&>li]:mt-2", children: C }),
    // Blockquote
    blockquote: ({ children: C }) => /* @__PURE__ */ m.jsx("blockquote", { className: "mt-6 border-l-2 pl-6 italic text-muted-foreground", children: C }),
    // Code with syntax highlighting
    code: ({ className: C, children: k }) => {
      if (!C)
        return /* @__PURE__ */ m.jsx("code", { className: "relative rounded bg-muted px-[0.3rem] py-[0.2rem] font-mono text-sm font-semibold", children: k });
      const w = /language-(\w+)/.exec(C || ""), R = w ? w[1] : "text", T = String(k).replace(/\n$/, ""), I = g ? g[s] : null;
      return p && I ? /* @__PURE__ */ m.jsx(
        p,
        {
          language: R,
          style: I,
          customStyle: {
            margin: 0,
            borderRadius: "0.5rem",
            fontSize: "0.875rem"
          },
          showLineNumbers: !1,
          children: T
        }
      ) : /* @__PURE__ */ m.jsx("code", { className: "relative rounded bg-transparent font-mono text-sm", children: k });
    },
    pre: ({ children: C }) => {
      const k = g ? g[s] : null;
      return p && k ? /* @__PURE__ */ m.jsx("div", { className: "mb-4 mt-6 overflow-x-auto rounded-lg border", children: C }) : /* @__PURE__ */ m.jsx("pre", { className: D(
        "mb-4 mt-6 overflow-x-auto rounded-lg border py-4 px-4",
        s === "dark" ? "bg-zinc-950 text-white" : "bg-zinc-100 text-zinc-900"
      ), children: C });
    },
    // Links
    a: ({ href: C, children: k }) => /* @__PURE__ */ m.jsx(
      "a",
      {
        href: C,
        className: "font-medium text-primary underline underline-offset-4 hover:no-underline",
        target: C != null && C.startsWith("http") ? "_blank" : void 0,
        rel: C != null && C.startsWith("http") ? "noopener noreferrer" : void 0,
        children: k
      }
    ),
    // Table
    table: ({ children: C }) => /* @__PURE__ */ m.jsx("div", { className: "my-6 w-full overflow-y-auto", children: /* @__PURE__ */ m.jsx("table", { className: "w-full", children: C }) }),
    th: ({ children: C }) => /* @__PURE__ */ m.jsx("th", { className: "border px-4 py-2 text-left font-bold [&[align=center]]:text-center [&[align=right]]:text-right", children: C }),
    td: ({ children: C }) => /* @__PURE__ */ m.jsx("td", { className: "border px-4 py-2 text-left [&[align=center]]:text-center [&[align=right]]:text-right", children: C }),
    // Horizontal rule
    hr: () => /* @__PURE__ */ m.jsx("hr", { className: "my-6 border-muted" })
  }), [s, p, g]);
  if (!a)
    return /* @__PURE__ */ m.jsx(
      "div",
      {
        id: e,
        className: D("prose prose-sm dark:prose-invert max-w-none", t),
        "data-refast-id": o,
        children: /* @__PURE__ */ m.jsx("pre", { className: "whitespace-pre-wrap text-sm", children: n })
      }
    );
  const v = [];
  l && v.push(l);
  const S = `${s}-${!!(p && g)}`;
  return /* @__PURE__ */ m.jsx(
    "div",
    {
      id: e,
      className: D("prose prose-sm dark:prose-invert max-w-none", t),
      "data-refast-id": o,
      children: /* @__PURE__ */ m.jsx(
        a,
        {
          remarkPlugins: v,
          rehypePlugins: r && d ? [d] : void 0,
          components: x,
          children: n
        }
      )
    },
    S
  );
}
function Mm({
  id: e,
  className: t,
  variant: n = "default",
  title: r,
  message: o,
  children: s,
  dismissible: a,
  onDismiss: i,
  "data-refast-id": l
}) {
  const [c, d] = h.useState(!0);
  if (!c)
    return null;
  const f = {
    default: "bg-background text-foreground",
    destructive: "bg-destructive text-destructive-foreground [&>svg]:text-destructive-foreground",
    success: "bg-success text-success-foreground [&>svg]:text-success-foreground",
    warning: "bg-warning text-warning-foreground [&>svg]:text-warning-foreground",
    info: "bg-info text-info-foreground [&>svg]:text-info-foreground"
  }, p = (u) => {
    u.stopPropagation(), d(!1), i == null || i();
  };
  return /* @__PURE__ */ m.jsxs(
    "div",
    {
      id: e,
      role: "alert",
      className: D(
        "relative w-full rounded-lg border p-4",
        "[&>svg~*]:pl-7 [&>svg+div]:translate-y-[-3px]",
        "[&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4 [&>svg]:text-foreground",
        f[n],
        t
      ),
      "data-refast-id": l,
      children: [
        a && /* @__PURE__ */ m.jsxs(
          "button",
          {
            onClick: p,
            className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
            children: [
              /* @__PURE__ */ m.jsx(ua, { className: "h-4 w-4" }),
              /* @__PURE__ */ m.jsx("span", { className: "sr-only", children: "Close" })
            ]
          }
        ),
        r && /* @__PURE__ */ m.jsx(Za, { children: r }),
        o && /* @__PURE__ */ m.jsx(Qa, { children: o }),
        s
      ]
    }
  );
}
function Za({
  id: e,
  className: t,
  children: n,
  "data-refast-id": r
}) {
  return /* @__PURE__ */ m.jsx(
    "h5",
    {
      id: e,
      className: D("mb-1 font-medium leading-none tracking-tight", t),
      "data-refast-id": r,
      children: n
    }
  );
}
function Qa({
  id: e,
  className: t,
  children: n,
  "data-refast-id": r
}) {
  return /* @__PURE__ */ m.jsx(
    "div",
    {
      id: e,
      className: D("text-sm [&_p]:leading-relaxed", t),
      "data-refast-id": r,
      children: n
    }
  );
}
function Lm({
  id: e,
  className: t,
  variant: n = "default",
  children: r,
  "data-refast-id": o
}) {
  const s = {
    default: "border-transparent bg-primary text-primary-foreground hover:bg-primary/80",
    secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
    destructive: "border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80",
    outline: "text-foreground",
    success: "border-transparent bg-green-500 text-white hover:bg-green-600",
    warning: "border-transparent bg-yellow-500 text-white hover:bg-yellow-600"
  };
  return /* @__PURE__ */ m.jsx(
    "div",
    {
      id: e,
      className: D(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors",
        "focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
        s[n],
        t
      ),
      "data-refast-id": o,
      children: r
    }
  );
}
const Dm = ["primary", "secondary", "destructive", "muted", "accent", "popover", "card", "background", "foreground"];
function zm({
  id: e,
  className: t,
  value: n = 0,
  max: r = 100,
  showValue: o = !1,
  foregroundColor: s,
  trackColor: a,
  striped: i,
  "data-refast-id": l
}) {
  const c = Math.min(100, Math.max(0, n / r * 100)), d = (b, x) => b ? Dm.includes(b) ? { className: `bg-${b}`, style: {} } : { className: "", style: { backgroundColor: b } } : { className: x, style: {} }, f = d(a, "bg-secondary"), p = d(s, "bg-primary"), u = i ? {
    backgroundImage: "linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent)",
    backgroundSize: "1rem 1rem"
  } : {}, g = i === "animated" ? "animate-stripes" : "";
  return /* @__PURE__ */ m.jsxs("div", { className: D("relative", t), "data-refast-id": l, children: [
    /* @__PURE__ */ m.jsx(
      "div",
      {
        id: e,
        role: "progressbar",
        "aria-valuenow": n,
        "aria-valuemin": 0,
        "aria-valuemax": r,
        className: D("relative h-4 w-full overflow-hidden rounded-full", f.className),
        style: f.style,
        children: /* @__PURE__ */ m.jsx(
          "div",
          {
            className: D("h-full transition-all flex-1", p.className, g),
            style: { width: `${c}%`, ...p.style, ...u }
          }
        )
      }
    ),
    o && /* @__PURE__ */ m.jsxs("span", { className: "absolute right-0 top-0 -mt-6 text-sm text-muted-foreground", children: [
      Math.round(c),
      "%"
    ] })
  ] });
}
function Om({
  id: e,
  className: t,
  size: n = "md",
  "data-refast-id": r
}) {
  const o = {
    sm: "h-4 w-4",
    md: "h-6 w-6",
    lg: "h-8 w-8"
  };
  return /* @__PURE__ */ m.jsx(
    "div",
    {
      id: e,
      className: D(
        "animate-spin rounded-full border-2 border-current border-t-transparent text-primary",
        o[n],
        t
      ),
      role: "status",
      "aria-label": "Loading",
      "data-refast-id": r,
      children: /* @__PURE__ */ m.jsx("span", { className: "sr-only", children: "Loading..." })
    }
  );
}
function _m({
  id: e,
  className: t,
  width: n,
  height: r,
  circle: o = !1,
  "data-refast-id": s
}) {
  return /* @__PURE__ */ m.jsx(
    "div",
    {
      id: e,
      className: D(
        "animate-pulse bg-muted",
        o ? "rounded-full" : "rounded-md",
        t
      ),
      style: {
        width: typeof n == "number" ? `${n}px` : n,
        height: typeof r == "number" ? `${r}px` : r
      },
      "data-refast-id": s
    }
  );
}
function $m({
  id: e,
  className: t,
  childrenConnected: n = [],
  childrenDisconnected: r = [],
  position: o = "bottom-right",
  onDisconnect: s,
  onReconnect: a,
  jsOnDisconnect: i,
  jsOnReconnect: l,
  debounceMs: c = 500,
  "data-refast-id": d
}) {
  const [f, p] = h.useState(!0), [u, g] = h.useState(!1), [b, x] = h.useState(0), v = h.useRef(null), y = h.useRef(null);
  h.useEffect(() => {
    const E = document.querySelector(".refast-app");
    if (!E) return;
    const w = () => {
      if (i != null && i.jsFunction)
        try {
          new Function("args", "event", i.jsFunction)(i.boundArgs || {}, { type: "disconnect" });
        } catch (A) {
          console.error("[ConnectionStatus] Error executing jsOnDisconnect:", A);
        }
      s != null && s.callbackId && window.dispatchEvent(
        new CustomEvent("refast:callback", {
          detail: {
            callbackId: s.callbackId,
            data: { ...s.boundArgs || {}, event_type: "disconnect" }
          }
        })
      );
    }, R = () => {
      if (l != null && l.jsFunction)
        try {
          new Function("args", "event", l.jsFunction)(l.boundArgs || {}, { type: "reconnect" });
        } catch (A) {
          console.error("[ConnectionStatus] Error executing jsOnReconnect:", A);
        }
      a != null && a.callbackId && window.dispatchEvent(
        new CustomEvent("refast:callback", {
          detail: {
            callbackId: a.callbackId,
            data: { ...a.boundArgs || {}, event_type: "reconnect" }
          }
        })
      );
    }, T = () => {
      const A = E.getAttribute("data-connected") === "true", N = E.getAttribute("data-connecting") === "true", _ = parseInt(E.getAttribute("data-reconnect-attempts") || "0", 10);
      p(A), g(N), x(_), y.current !== null && y.current !== A && (v.current && clearTimeout(v.current), v.current = setTimeout(() => {
        A ? R() : w();
      }, c)), y.current = A;
    };
    T();
    const I = new MutationObserver((A) => {
      for (const N of A)
        if (N.type === "attributes" && (N.attributeName === "data-connected" || N.attributeName === "data-connecting" || N.attributeName === "data-reconnect-attempts")) {
          T();
          break;
        }
    });
    return I.observe(E, { attributes: !0 }), () => {
      I.disconnect(), v.current && clearTimeout(v.current);
    };
  }, [c, i, l, s, a]);
  const S = f ? n : r, C = S && S.length > 0, k = {
    "top-left": "fixed top-4 left-4 z-50",
    "top-right": "fixed top-4 right-4 z-50",
    "bottom-left": "fixed bottom-4 left-4 z-50",
    "bottom-right": "fixed bottom-4 right-4 z-50",
    inline: ""
  };
  return C ? /* @__PURE__ */ m.jsx(
    "div",
    {
      id: e,
      className: D(k[o], t),
      "data-refast-id": d,
      "data-connected": f,
      "data-connecting": u,
      "data-reconnect-attempts": b,
      children: S.map((E, w) => /* @__PURE__ */ m.jsx(vt, { tree: E }, E.id || w))
    }
  ) : !f && r.length === 0 ? /* @__PURE__ */ m.jsx(
    "div",
    {
      id: e,
      className: D(k[o], t),
      "data-refast-id": d,
      "data-connected": f,
      "data-connecting": u,
      "data-reconnect-attempts": b,
      children: /* @__PURE__ */ m.jsx(
        "div",
        {
          className: D(
            "flex items-center gap-2 rounded-lg px-3 py-2 shadow-lg",
            u ? "bg-yellow-500 text-white" : "bg-destructive text-destructive-foreground"
          ),
          children: u ? /* @__PURE__ */ m.jsxs(m.Fragment, { children: [
            /* @__PURE__ */ m.jsx("div", { className: "h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" }),
            /* @__PURE__ */ m.jsxs("span", { children: [
              "Reconnecting... (",
              b,
              ")"
            ] })
          ] }) : /* @__PURE__ */ m.jsxs(m.Fragment, { children: [
            /* @__PURE__ */ m.jsx("div", { className: "h-2 w-2 rounded-full bg-white animate-pulse" }),
            /* @__PURE__ */ m.jsx("span", { children: "Connection lost" })
          ] })
        }
      )
    }
  ) : null;
}
function Fm(e, t = globalThis == null ? void 0 : globalThis.document) {
  const n = Re(e);
  h.useEffect(() => {
    const r = (o) => {
      o.key === "Escape" && n(o);
    };
    return t.addEventListener("keydown", r, { capture: !0 }), () => t.removeEventListener("keydown", r, { capture: !0 });
  }, [n, t]);
}
var Bm = "DismissableLayer", Rr = "dismissableLayer.update", Hm = "dismissableLayer.pointerDownOutside", Vm = "dismissableLayer.focusOutside", Es, ei = h.createContext({
  layers: /* @__PURE__ */ new Set(),
  layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
  branches: /* @__PURE__ */ new Set()
}), ti = h.forwardRef(
  (e, t) => {
    const {
      disableOutsidePointerEvents: n = !1,
      onEscapeKeyDown: r,
      onPointerDownOutside: o,
      onFocusOutside: s,
      onInteractOutside: a,
      onDismiss: i,
      ...l
    } = e, c = h.useContext(ei), [d, f] = h.useState(null), p = (d == null ? void 0 : d.ownerDocument) ?? (globalThis == null ? void 0 : globalThis.document), [, u] = h.useState({}), g = pe(t, (w) => f(w)), b = Array.from(c.layers), [x] = [...c.layersWithOutsidePointerEventsDisabled].slice(-1), v = b.indexOf(x), y = d ? b.indexOf(d) : -1, S = c.layersWithOutsidePointerEventsDisabled.size > 0, C = y >= v, k = Um((w) => {
      const R = w.target, T = [...c.branches].some((I) => I.contains(R));
      !C || T || (o == null || o(w), a == null || a(w), w.defaultPrevented || i == null || i());
    }, p), E = Km((w) => {
      const R = w.target;
      [...c.branches].some((I) => I.contains(R)) || (s == null || s(w), a == null || a(w), w.defaultPrevented || i == null || i());
    }, p);
    return Fm((w) => {
      y === c.layers.size - 1 && (r == null || r(w), !w.defaultPrevented && i && (w.preventDefault(), i()));
    }, p), h.useEffect(() => {
      if (d)
        return n && (c.layersWithOutsidePointerEventsDisabled.size === 0 && (Es = p.body.style.pointerEvents, p.body.style.pointerEvents = "none"), c.layersWithOutsidePointerEventsDisabled.add(d)), c.layers.add(d), ks(), () => {
          n && c.layersWithOutsidePointerEventsDisabled.size === 1 && (p.body.style.pointerEvents = Es);
        };
    }, [d, p, n, c]), h.useEffect(() => () => {
      d && (c.layers.delete(d), c.layersWithOutsidePointerEventsDisabled.delete(d), ks());
    }, [d, c]), h.useEffect(() => {
      const w = () => u({});
      return document.addEventListener(Rr, w), () => document.removeEventListener(Rr, w);
    }, []), /* @__PURE__ */ m.jsx(
      le.div,
      {
        ...l,
        ref: g,
        style: {
          pointerEvents: S ? C ? "auto" : "none" : void 0,
          ...e.style
        },
        onFocusCapture: ae(e.onFocusCapture, E.onFocusCapture),
        onBlurCapture: ae(e.onBlurCapture, E.onBlurCapture),
        onPointerDownCapture: ae(
          e.onPointerDownCapture,
          k.onPointerDownCapture
        )
      }
    );
  }
);
ti.displayName = Bm;
var Wm = "DismissableLayerBranch", Gm = h.forwardRef((e, t) => {
  const n = h.useContext(ei), r = h.useRef(null), o = pe(t, r);
  return h.useEffect(() => {
    const s = r.current;
    if (s)
      return n.branches.add(s), () => {
        n.branches.delete(s);
      };
  }, [n.branches]), /* @__PURE__ */ m.jsx(le.div, { ...e, ref: o });
});
Gm.displayName = Wm;
function Um(e, t = globalThis == null ? void 0 : globalThis.document) {
  const n = Re(e), r = h.useRef(!1), o = h.useRef(() => {
  });
  return h.useEffect(() => {
    const s = (i) => {
      if (i.target && !r.current) {
        let l = function() {
          ni(
            Hm,
            n,
            c,
            { discrete: !0 }
          );
        };
        const c = { originalEvent: i };
        i.pointerType === "touch" ? (t.removeEventListener("click", o.current), o.current = l, t.addEventListener("click", o.current, { once: !0 })) : l();
      } else
        t.removeEventListener("click", o.current);
      r.current = !1;
    }, a = window.setTimeout(() => {
      t.addEventListener("pointerdown", s);
    }, 0);
    return () => {
      window.clearTimeout(a), t.removeEventListener("pointerdown", s), t.removeEventListener("click", o.current);
    };
  }, [t, n]), {
    // ensures we check React component tree (not just DOM tree)
    onPointerDownCapture: () => r.current = !0
  };
}
function Km(e, t = globalThis == null ? void 0 : globalThis.document) {
  const n = Re(e), r = h.useRef(!1);
  return h.useEffect(() => {
    const o = (s) => {
      s.target && !r.current && ni(Vm, n, { originalEvent: s }, {
        discrete: !1
      });
    };
    return t.addEventListener("focusin", o), () => t.removeEventListener("focusin", o);
  }, [t, n]), {
    onFocusCapture: () => r.current = !0,
    onBlurCapture: () => r.current = !1
  };
}
function ks() {
  const e = new CustomEvent(Rr);
  document.dispatchEvent(e);
}
function ni(e, t, n, { discrete: r }) {
  const o = n.originalEvent.target, s = new CustomEvent(e, { bubbles: !1, cancelable: !0, detail: n });
  t && o.addEventListener(e, t, { once: !0 }), r ? Ip(o, s) : o.dispatchEvent(s);
}
const Ym = ["top", "right", "bottom", "left"], ft = Math.min, Ee = Math.max, Sn = Math.round, hn = Math.floor, Be = (e) => ({
  x: e,
  y: e
}), Xm = {
  left: "right",
  right: "left",
  bottom: "top",
  top: "bottom"
}, qm = {
  start: "end",
  end: "start"
};
function Ar(e, t, n) {
  return Ee(e, ft(t, n));
}
function Ze(e, t) {
  return typeof e == "function" ? e(t) : e;
}
function Qe(e) {
  return e.split("-")[0];
}
function zt(e) {
  return e.split("-")[1];
}
function Yr(e) {
  return e === "x" ? "y" : "x";
}
function Xr(e) {
  return e === "y" ? "height" : "width";
}
const Jm = /* @__PURE__ */ new Set(["top", "bottom"]);
function Fe(e) {
  return Jm.has(Qe(e)) ? "y" : "x";
}
function qr(e) {
  return Yr(Fe(e));
}
function Zm(e, t, n) {
  n === void 0 && (n = !1);
  const r = zt(e), o = qr(e), s = Xr(o);
  let a = o === "x" ? r === (n ? "end" : "start") ? "right" : "left" : r === "start" ? "bottom" : "top";
  return t.reference[s] > t.floating[s] && (a = En(a)), [a, En(a)];
}
function Qm(e) {
  const t = En(e);
  return [Nr(e), t, Nr(t)];
}
function Nr(e) {
  return e.replace(/start|end/g, (t) => qm[t]);
}
const Ps = ["left", "right"], Rs = ["right", "left"], eh = ["top", "bottom"], th = ["bottom", "top"];
function nh(e, t, n) {
  switch (e) {
    case "top":
    case "bottom":
      return n ? t ? Rs : Ps : t ? Ps : Rs;
    case "left":
    case "right":
      return t ? eh : th;
    default:
      return [];
  }
}
function rh(e, t, n, r) {
  const o = zt(e);
  let s = nh(Qe(e), n === "start", r);
  return o && (s = s.map((a) => a + "-" + o), t && (s = s.concat(s.map(Nr)))), s;
}
function En(e) {
  return e.replace(/left|right|bottom|top/g, (t) => Xm[t]);
}
function oh(e) {
  return {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    ...e
  };
}
function ri(e) {
  return typeof e != "number" ? oh(e) : {
    top: e,
    right: e,
    bottom: e,
    left: e
  };
}
function kn(e) {
  const {
    x: t,
    y: n,
    width: r,
    height: o
  } = e;
  return {
    width: r,
    height: o,
    top: n,
    left: t,
    right: t + r,
    bottom: n + o,
    x: t,
    y: n
  };
}
function As(e, t, n) {
  let {
    reference: r,
    floating: o
  } = e;
  const s = Fe(t), a = qr(t), i = Xr(a), l = Qe(t), c = s === "y", d = r.x + r.width / 2 - o.width / 2, f = r.y + r.height / 2 - o.height / 2, p = r[i] / 2 - o[i] / 2;
  let u;
  switch (l) {
    case "top":
      u = {
        x: d,
        y: r.y - o.height
      };
      break;
    case "bottom":
      u = {
        x: d,
        y: r.y + r.height
      };
      break;
    case "right":
      u = {
        x: r.x + r.width,
        y: f
      };
      break;
    case "left":
      u = {
        x: r.x - o.width,
        y: f
      };
      break;
    default:
      u = {
        x: r.x,
        y: r.y
      };
  }
  switch (zt(t)) {
    case "start":
      u[a] -= p * (n && c ? -1 : 1);
      break;
    case "end":
      u[a] += p * (n && c ? -1 : 1);
      break;
  }
  return u;
}
const sh = async (e, t, n) => {
  const {
    placement: r = "bottom",
    strategy: o = "absolute",
    middleware: s = [],
    platform: a
  } = n, i = s.filter(Boolean), l = await (a.isRTL == null ? void 0 : a.isRTL(t));
  let c = await a.getElementRects({
    reference: e,
    floating: t,
    strategy: o
  }), {
    x: d,
    y: f
  } = As(c, r, l), p = r, u = {}, g = 0;
  for (let b = 0; b < i.length; b++) {
    const {
      name: x,
      fn: v
    } = i[b], {
      x: y,
      y: S,
      data: C,
      reset: k
    } = await v({
      x: d,
      y: f,
      initialPlacement: r,
      placement: p,
      strategy: o,
      middlewareData: u,
      rects: c,
      platform: a,
      elements: {
        reference: e,
        floating: t
      }
    });
    d = y ?? d, f = S ?? f, u = {
      ...u,
      [x]: {
        ...u[x],
        ...C
      }
    }, k && g <= 50 && (g++, typeof k == "object" && (k.placement && (p = k.placement), k.rects && (c = k.rects === !0 ? await a.getElementRects({
      reference: e,
      floating: t,
      strategy: o
    }) : k.rects), {
      x: d,
      y: f
    } = As(c, p, l)), b = -1);
  }
  return {
    x: d,
    y: f,
    placement: p,
    strategy: o,
    middlewareData: u
  };
};
async function Yt(e, t) {
  var n;
  t === void 0 && (t = {});
  const {
    x: r,
    y: o,
    platform: s,
    rects: a,
    elements: i,
    strategy: l
  } = e, {
    boundary: c = "clippingAncestors",
    rootBoundary: d = "viewport",
    elementContext: f = "floating",
    altBoundary: p = !1,
    padding: u = 0
  } = Ze(t, e), g = ri(u), x = i[p ? f === "floating" ? "reference" : "floating" : f], v = kn(await s.getClippingRect({
    element: (n = await (s.isElement == null ? void 0 : s.isElement(x))) == null || n ? x : x.contextElement || await (s.getDocumentElement == null ? void 0 : s.getDocumentElement(i.floating)),
    boundary: c,
    rootBoundary: d,
    strategy: l
  })), y = f === "floating" ? {
    x: r,
    y: o,
    width: a.floating.width,
    height: a.floating.height
  } : a.reference, S = await (s.getOffsetParent == null ? void 0 : s.getOffsetParent(i.floating)), C = await (s.isElement == null ? void 0 : s.isElement(S)) ? await (s.getScale == null ? void 0 : s.getScale(S)) || {
    x: 1,
    y: 1
  } : {
    x: 1,
    y: 1
  }, k = kn(s.convertOffsetParentRelativeRectToViewportRelativeRect ? await s.convertOffsetParentRelativeRectToViewportRelativeRect({
    elements: i,
    rect: y,
    offsetParent: S,
    strategy: l
  }) : y);
  return {
    top: (v.top - k.top + g.top) / C.y,
    bottom: (k.bottom - v.bottom + g.bottom) / C.y,
    left: (v.left - k.left + g.left) / C.x,
    right: (k.right - v.right + g.right) / C.x
  };
}
const ah = (e) => ({
  name: "arrow",
  options: e,
  async fn(t) {
    const {
      x: n,
      y: r,
      placement: o,
      rects: s,
      platform: a,
      elements: i,
      middlewareData: l
    } = t, {
      element: c,
      padding: d = 0
    } = Ze(e, t) || {};
    if (c == null)
      return {};
    const f = ri(d), p = {
      x: n,
      y: r
    }, u = qr(o), g = Xr(u), b = await a.getDimensions(c), x = u === "y", v = x ? "top" : "left", y = x ? "bottom" : "right", S = x ? "clientHeight" : "clientWidth", C = s.reference[g] + s.reference[u] - p[u] - s.floating[g], k = p[u] - s.reference[u], E = await (a.getOffsetParent == null ? void 0 : a.getOffsetParent(c));
    let w = E ? E[S] : 0;
    (!w || !await (a.isElement == null ? void 0 : a.isElement(E))) && (w = i.floating[S] || s.floating[g]);
    const R = C / 2 - k / 2, T = w / 2 - b[g] / 2 - 1, I = ft(f[v], T), A = ft(f[y], T), N = I, _ = w - b[g] - A, O = w / 2 - b[g] / 2 + R, M = Ar(N, O, _), L = !l.arrow && zt(o) != null && O !== M && s.reference[g] / 2 - (O < N ? I : A) - b[g] / 2 < 0, V = L ? O < N ? O - N : O - _ : 0;
    return {
      [u]: p[u] + V,
      data: {
        [u]: M,
        centerOffset: O - M - V,
        ...L && {
          alignmentOffset: V
        }
      },
      reset: L
    };
  }
}), ih = function(e) {
  return e === void 0 && (e = {}), {
    name: "flip",
    options: e,
    async fn(t) {
      var n, r;
      const {
        placement: o,
        middlewareData: s,
        rects: a,
        initialPlacement: i,
        platform: l,
        elements: c
      } = t, {
        mainAxis: d = !0,
        crossAxis: f = !0,
        fallbackPlacements: p,
        fallbackStrategy: u = "bestFit",
        fallbackAxisSideDirection: g = "none",
        flipAlignment: b = !0,
        ...x
      } = Ze(e, t);
      if ((n = s.arrow) != null && n.alignmentOffset)
        return {};
      const v = Qe(o), y = Fe(i), S = Qe(i) === i, C = await (l.isRTL == null ? void 0 : l.isRTL(c.floating)), k = p || (S || !b ? [En(i)] : Qm(i)), E = g !== "none";
      !p && E && k.push(...rh(i, b, g, C));
      const w = [i, ...k], R = await Yt(t, x), T = [];
      let I = ((r = s.flip) == null ? void 0 : r.overflows) || [];
      if (d && T.push(R[v]), f) {
        const O = Zm(o, a, C);
        T.push(R[O[0]], R[O[1]]);
      }
      if (I = [...I, {
        placement: o,
        overflows: T
      }], !T.every((O) => O <= 0)) {
        var A, N;
        const O = (((A = s.flip) == null ? void 0 : A.index) || 0) + 1, M = w[O];
        if (M && (!(f === "alignment" ? y !== Fe(M) : !1) || // We leave the current main axis only if every placement on that axis
        // overflows the main axis.
        I.every((W) => Fe(W.placement) === y ? W.overflows[0] > 0 : !0)))
          return {
            data: {
              index: O,
              overflows: I
            },
            reset: {
              placement: M
            }
          };
        let L = (N = I.filter((V) => V.overflows[0] <= 0).sort((V, W) => V.overflows[1] - W.overflows[1])[0]) == null ? void 0 : N.placement;
        if (!L)
          switch (u) {
            case "bestFit": {
              var _;
              const V = (_ = I.filter((W) => {
                if (E) {
                  const B = Fe(W.placement);
                  return B === y || // Create a bias to the `y` side axis due to horizontal
                  // reading directions favoring greater width.
                  B === "y";
                }
                return !0;
              }).map((W) => [W.placement, W.overflows.filter((B) => B > 0).reduce((B, te) => B + te, 0)]).sort((W, B) => W[1] - B[1])[0]) == null ? void 0 : _[0];
              V && (L = V);
              break;
            }
            case "initialPlacement":
              L = i;
              break;
          }
        if (o !== L)
          return {
            reset: {
              placement: L
            }
          };
      }
      return {};
    }
  };
};
function Ns(e, t) {
  return {
    top: e.top - t.height,
    right: e.right - t.width,
    bottom: e.bottom - t.height,
    left: e.left - t.width
  };
}
function Ts(e) {
  return Ym.some((t) => e[t] >= 0);
}
const lh = function(e) {
  return e === void 0 && (e = {}), {
    name: "hide",
    options: e,
    async fn(t) {
      const {
        rects: n
      } = t, {
        strategy: r = "referenceHidden",
        ...o
      } = Ze(e, t);
      switch (r) {
        case "referenceHidden": {
          const s = await Yt(t, {
            ...o,
            elementContext: "reference"
          }), a = Ns(s, n.reference);
          return {
            data: {
              referenceHiddenOffsets: a,
              referenceHidden: Ts(a)
            }
          };
        }
        case "escaped": {
          const s = await Yt(t, {
            ...o,
            altBoundary: !0
          }), a = Ns(s, n.floating);
          return {
            data: {
              escapedOffsets: a,
              escaped: Ts(a)
            }
          };
        }
        default:
          return {};
      }
    }
  };
}, oi = /* @__PURE__ */ new Set(["left", "top"]);
async function ch(e, t) {
  const {
    placement: n,
    platform: r,
    elements: o
  } = e, s = await (r.isRTL == null ? void 0 : r.isRTL(o.floating)), a = Qe(n), i = zt(n), l = Fe(n) === "y", c = oi.has(a) ? -1 : 1, d = s && l ? -1 : 1, f = Ze(t, e);
  let {
    mainAxis: p,
    crossAxis: u,
    alignmentAxis: g
  } = typeof f == "number" ? {
    mainAxis: f,
    crossAxis: 0,
    alignmentAxis: null
  } : {
    mainAxis: f.mainAxis || 0,
    crossAxis: f.crossAxis || 0,
    alignmentAxis: f.alignmentAxis
  };
  return i && typeof g == "number" && (u = i === "end" ? g * -1 : g), l ? {
    x: u * d,
    y: p * c
  } : {
    x: p * c,
    y: u * d
  };
}
const uh = function(e) {
  return e === void 0 && (e = 0), {
    name: "offset",
    options: e,
    async fn(t) {
      var n, r;
      const {
        x: o,
        y: s,
        placement: a,
        middlewareData: i
      } = t, l = await ch(t, e);
      return a === ((n = i.offset) == null ? void 0 : n.placement) && (r = i.arrow) != null && r.alignmentOffset ? {} : {
        x: o + l.x,
        y: s + l.y,
        data: {
          ...l,
          placement: a
        }
      };
    }
  };
}, dh = function(e) {
  return e === void 0 && (e = {}), {
    name: "shift",
    options: e,
    async fn(t) {
      const {
        x: n,
        y: r,
        placement: o
      } = t, {
        mainAxis: s = !0,
        crossAxis: a = !1,
        limiter: i = {
          fn: (x) => {
            let {
              x: v,
              y
            } = x;
            return {
              x: v,
              y
            };
          }
        },
        ...l
      } = Ze(e, t), c = {
        x: n,
        y: r
      }, d = await Yt(t, l), f = Fe(Qe(o)), p = Yr(f);
      let u = c[p], g = c[f];
      if (s) {
        const x = p === "y" ? "top" : "left", v = p === "y" ? "bottom" : "right", y = u + d[x], S = u - d[v];
        u = Ar(y, u, S);
      }
      if (a) {
        const x = f === "y" ? "top" : "left", v = f === "y" ? "bottom" : "right", y = g + d[x], S = g - d[v];
        g = Ar(y, g, S);
      }
      const b = i.fn({
        ...t,
        [p]: u,
        [f]: g
      });
      return {
        ...b,
        data: {
          x: b.x - n,
          y: b.y - r,
          enabled: {
            [p]: s,
            [f]: a
          }
        }
      };
    }
  };
}, fh = function(e) {
  return e === void 0 && (e = {}), {
    options: e,
    fn(t) {
      const {
        x: n,
        y: r,
        placement: o,
        rects: s,
        middlewareData: a
      } = t, {
        offset: i = 0,
        mainAxis: l = !0,
        crossAxis: c = !0
      } = Ze(e, t), d = {
        x: n,
        y: r
      }, f = Fe(o), p = Yr(f);
      let u = d[p], g = d[f];
      const b = Ze(i, t), x = typeof b == "number" ? {
        mainAxis: b,
        crossAxis: 0
      } : {
        mainAxis: 0,
        crossAxis: 0,
        ...b
      };
      if (l) {
        const S = p === "y" ? "height" : "width", C = s.reference[p] - s.floating[S] + x.mainAxis, k = s.reference[p] + s.reference[S] - x.mainAxis;
        u < C ? u = C : u > k && (u = k);
      }
      if (c) {
        var v, y;
        const S = p === "y" ? "width" : "height", C = oi.has(Qe(o)), k = s.reference[f] - s.floating[S] + (C && ((v = a.offset) == null ? void 0 : v[f]) || 0) + (C ? 0 : x.crossAxis), E = s.reference[f] + s.reference[S] + (C ? 0 : ((y = a.offset) == null ? void 0 : y[f]) || 0) - (C ? x.crossAxis : 0);
        g < k ? g = k : g > E && (g = E);
      }
      return {
        [p]: u,
        [f]: g
      };
    }
  };
}, ph = function(e) {
  return e === void 0 && (e = {}), {
    name: "size",
    options: e,
    async fn(t) {
      var n, r;
      const {
        placement: o,
        rects: s,
        platform: a,
        elements: i
      } = t, {
        apply: l = () => {
        },
        ...c
      } = Ze(e, t), d = await Yt(t, c), f = Qe(o), p = zt(o), u = Fe(o) === "y", {
        width: g,
        height: b
      } = s.floating;
      let x, v;
      f === "top" || f === "bottom" ? (x = f, v = p === (await (a.isRTL == null ? void 0 : a.isRTL(i.floating)) ? "start" : "end") ? "left" : "right") : (v = f, x = p === "end" ? "top" : "bottom");
      const y = b - d.top - d.bottom, S = g - d.left - d.right, C = ft(b - d[x], y), k = ft(g - d[v], S), E = !t.middlewareData.shift;
      let w = C, R = k;
      if ((n = t.middlewareData.shift) != null && n.enabled.x && (R = S), (r = t.middlewareData.shift) != null && r.enabled.y && (w = y), E && !p) {
        const I = Ee(d.left, 0), A = Ee(d.right, 0), N = Ee(d.top, 0), _ = Ee(d.bottom, 0);
        u ? R = g - 2 * (I !== 0 || A !== 0 ? I + A : Ee(d.left, d.right)) : w = b - 2 * (N !== 0 || _ !== 0 ? N + _ : Ee(d.top, d.bottom));
      }
      await l({
        ...t,
        availableWidth: R,
        availableHeight: w
      });
      const T = await a.getDimensions(i.floating);
      return g !== T.width || b !== T.height ? {
        reset: {
          rects: !0
        }
      } : {};
    }
  };
};
function Vn() {
  return typeof window < "u";
}
function Ot(e) {
  return si(e) ? (e.nodeName || "").toLowerCase() : "#document";
}
function ke(e) {
  var t;
  return (e == null || (t = e.ownerDocument) == null ? void 0 : t.defaultView) || window;
}
function Ue(e) {
  var t;
  return (t = (si(e) ? e.ownerDocument : e.document) || window.document) == null ? void 0 : t.documentElement;
}
function si(e) {
  return Vn() ? e instanceof Node || e instanceof ke(e).Node : !1;
}
function Oe(e) {
  return Vn() ? e instanceof Element || e instanceof ke(e).Element : !1;
}
function Ve(e) {
  return Vn() ? e instanceof HTMLElement || e instanceof ke(e).HTMLElement : !1;
}
function js(e) {
  return !Vn() || typeof ShadowRoot > "u" ? !1 : e instanceof ShadowRoot || e instanceof ke(e).ShadowRoot;
}
const mh = /* @__PURE__ */ new Set(["inline", "contents"]);
function rn(e) {
  const {
    overflow: t,
    overflowX: n,
    overflowY: r,
    display: o
  } = _e(e);
  return /auto|scroll|overlay|hidden|clip/.test(t + r + n) && !mh.has(o);
}
const hh = /* @__PURE__ */ new Set(["table", "td", "th"]);
function gh(e) {
  return hh.has(Ot(e));
}
const bh = [":popover-open", ":modal"];
function Wn(e) {
  return bh.some((t) => {
    try {
      return e.matches(t);
    } catch {
      return !1;
    }
  });
}
const vh = ["transform", "translate", "scale", "rotate", "perspective"], xh = ["transform", "translate", "scale", "rotate", "perspective", "filter"], yh = ["paint", "layout", "strict", "content"];
function Jr(e) {
  const t = Zr(), n = Oe(e) ? _e(e) : e;
  return vh.some((r) => n[r] ? n[r] !== "none" : !1) || (n.containerType ? n.containerType !== "normal" : !1) || !t && (n.backdropFilter ? n.backdropFilter !== "none" : !1) || !t && (n.filter ? n.filter !== "none" : !1) || xh.some((r) => (n.willChange || "").includes(r)) || yh.some((r) => (n.contain || "").includes(r));
}
function wh(e) {
  let t = pt(e);
  for (; Ve(t) && !jt(t); ) {
    if (Jr(t))
      return t;
    if (Wn(t))
      return null;
    t = pt(t);
  }
  return null;
}
function Zr() {
  return typeof CSS > "u" || !CSS.supports ? !1 : CSS.supports("-webkit-backdrop-filter", "none");
}
const Ch = /* @__PURE__ */ new Set(["html", "body", "#document"]);
function jt(e) {
  return Ch.has(Ot(e));
}
function _e(e) {
  return ke(e).getComputedStyle(e);
}
function Gn(e) {
  return Oe(e) ? {
    scrollLeft: e.scrollLeft,
    scrollTop: e.scrollTop
  } : {
    scrollLeft: e.scrollX,
    scrollTop: e.scrollY
  };
}
function pt(e) {
  if (Ot(e) === "html")
    return e;
  const t = (
    // Step into the shadow DOM of the parent of a slotted node.
    e.assignedSlot || // DOM Element detected.
    e.parentNode || // ShadowRoot detected.
    js(e) && e.host || // Fallback.
    Ue(e)
  );
  return js(t) ? t.host : t;
}
function ai(e) {
  const t = pt(e);
  return jt(t) ? e.ownerDocument ? e.ownerDocument.body : e.body : Ve(t) && rn(t) ? t : ai(t);
}
function Xt(e, t, n) {
  var r;
  t === void 0 && (t = []), n === void 0 && (n = !0);
  const o = ai(e), s = o === ((r = e.ownerDocument) == null ? void 0 : r.body), a = ke(o);
  if (s) {
    const i = Tr(a);
    return t.concat(a, a.visualViewport || [], rn(o) ? o : [], i && n ? Xt(i) : []);
  }
  return t.concat(o, Xt(o, [], n));
}
function Tr(e) {
  return e.parent && Object.getPrototypeOf(e.parent) ? e.frameElement : null;
}
function ii(e) {
  const t = _e(e);
  let n = parseFloat(t.width) || 0, r = parseFloat(t.height) || 0;
  const o = Ve(e), s = o ? e.offsetWidth : n, a = o ? e.offsetHeight : r, i = Sn(n) !== s || Sn(r) !== a;
  return i && (n = s, r = a), {
    width: n,
    height: r,
    $: i
  };
}
function Qr(e) {
  return Oe(e) ? e : e.contextElement;
}
function Nt(e) {
  const t = Qr(e);
  if (!Ve(t))
    return Be(1);
  const n = t.getBoundingClientRect(), {
    width: r,
    height: o,
    $: s
  } = ii(t);
  let a = (s ? Sn(n.width) : n.width) / r, i = (s ? Sn(n.height) : n.height) / o;
  return (!a || !Number.isFinite(a)) && (a = 1), (!i || !Number.isFinite(i)) && (i = 1), {
    x: a,
    y: i
  };
}
const Sh = /* @__PURE__ */ Be(0);
function li(e) {
  const t = ke(e);
  return !Zr() || !t.visualViewport ? Sh : {
    x: t.visualViewport.offsetLeft,
    y: t.visualViewport.offsetTop
  };
}
function Eh(e, t, n) {
  return t === void 0 && (t = !1), !n || t && n !== ke(e) ? !1 : t;
}
function xt(e, t, n, r) {
  t === void 0 && (t = !1), n === void 0 && (n = !1);
  const o = e.getBoundingClientRect(), s = Qr(e);
  let a = Be(1);
  t && (r ? Oe(r) && (a = Nt(r)) : a = Nt(e));
  const i = Eh(s, n, r) ? li(s) : Be(0);
  let l = (o.left + i.x) / a.x, c = (o.top + i.y) / a.y, d = o.width / a.x, f = o.height / a.y;
  if (s) {
    const p = ke(s), u = r && Oe(r) ? ke(r) : r;
    let g = p, b = Tr(g);
    for (; b && r && u !== g; ) {
      const x = Nt(b), v = b.getBoundingClientRect(), y = _e(b), S = v.left + (b.clientLeft + parseFloat(y.paddingLeft)) * x.x, C = v.top + (b.clientTop + parseFloat(y.paddingTop)) * x.y;
      l *= x.x, c *= x.y, d *= x.x, f *= x.y, l += S, c += C, g = ke(b), b = Tr(g);
    }
  }
  return kn({
    width: d,
    height: f,
    x: l,
    y: c
  });
}
function Un(e, t) {
  const n = Gn(e).scrollLeft;
  return t ? t.left + n : xt(Ue(e)).left + n;
}
function ci(e, t) {
  const n = e.getBoundingClientRect(), r = n.left + t.scrollLeft - Un(e, n), o = n.top + t.scrollTop;
  return {
    x: r,
    y: o
  };
}
function kh(e) {
  let {
    elements: t,
    rect: n,
    offsetParent: r,
    strategy: o
  } = e;
  const s = o === "fixed", a = Ue(r), i = t ? Wn(t.floating) : !1;
  if (r === a || i && s)
    return n;
  let l = {
    scrollLeft: 0,
    scrollTop: 0
  }, c = Be(1);
  const d = Be(0), f = Ve(r);
  if ((f || !f && !s) && ((Ot(r) !== "body" || rn(a)) && (l = Gn(r)), Ve(r))) {
    const u = xt(r);
    c = Nt(r), d.x = u.x + r.clientLeft, d.y = u.y + r.clientTop;
  }
  const p = a && !f && !s ? ci(a, l) : Be(0);
  return {
    width: n.width * c.x,
    height: n.height * c.y,
    x: n.x * c.x - l.scrollLeft * c.x + d.x + p.x,
    y: n.y * c.y - l.scrollTop * c.y + d.y + p.y
  };
}
function Ph(e) {
  return Array.from(e.getClientRects());
}
function Rh(e) {
  const t = Ue(e), n = Gn(e), r = e.ownerDocument.body, o = Ee(t.scrollWidth, t.clientWidth, r.scrollWidth, r.clientWidth), s = Ee(t.scrollHeight, t.clientHeight, r.scrollHeight, r.clientHeight);
  let a = -n.scrollLeft + Un(e);
  const i = -n.scrollTop;
  return _e(r).direction === "rtl" && (a += Ee(t.clientWidth, r.clientWidth) - o), {
    width: o,
    height: s,
    x: a,
    y: i
  };
}
const Is = 25;
function Ah(e, t) {
  const n = ke(e), r = Ue(e), o = n.visualViewport;
  let s = r.clientWidth, a = r.clientHeight, i = 0, l = 0;
  if (o) {
    s = o.width, a = o.height;
    const d = Zr();
    (!d || d && t === "fixed") && (i = o.offsetLeft, l = o.offsetTop);
  }
  const c = Un(r);
  if (c <= 0) {
    const d = r.ownerDocument, f = d.body, p = getComputedStyle(f), u = d.compatMode === "CSS1Compat" && parseFloat(p.marginLeft) + parseFloat(p.marginRight) || 0, g = Math.abs(r.clientWidth - f.clientWidth - u);
    g <= Is && (s -= g);
  } else c <= Is && (s += c);
  return {
    width: s,
    height: a,
    x: i,
    y: l
  };
}
const Nh = /* @__PURE__ */ new Set(["absolute", "fixed"]);
function Th(e, t) {
  const n = xt(e, !0, t === "fixed"), r = n.top + e.clientTop, o = n.left + e.clientLeft, s = Ve(e) ? Nt(e) : Be(1), a = e.clientWidth * s.x, i = e.clientHeight * s.y, l = o * s.x, c = r * s.y;
  return {
    width: a,
    height: i,
    x: l,
    y: c
  };
}
function Ms(e, t, n) {
  let r;
  if (t === "viewport")
    r = Ah(e, n);
  else if (t === "document")
    r = Rh(Ue(e));
  else if (Oe(t))
    r = Th(t, n);
  else {
    const o = li(e);
    r = {
      x: t.x - o.x,
      y: t.y - o.y,
      width: t.width,
      height: t.height
    };
  }
  return kn(r);
}
function ui(e, t) {
  const n = pt(e);
  return n === t || !Oe(n) || jt(n) ? !1 : _e(n).position === "fixed" || ui(n, t);
}
function jh(e, t) {
  const n = t.get(e);
  if (n)
    return n;
  let r = Xt(e, [], !1).filter((i) => Oe(i) && Ot(i) !== "body"), o = null;
  const s = _e(e).position === "fixed";
  let a = s ? pt(e) : e;
  for (; Oe(a) && !jt(a); ) {
    const i = _e(a), l = Jr(a);
    !l && i.position === "fixed" && (o = null), (s ? !l && !o : !l && i.position === "static" && !!o && Nh.has(o.position) || rn(a) && !l && ui(e, a)) ? r = r.filter((d) => d !== a) : o = i, a = pt(a);
  }
  return t.set(e, r), r;
}
function Ih(e) {
  let {
    element: t,
    boundary: n,
    rootBoundary: r,
    strategy: o
  } = e;
  const a = [...n === "clippingAncestors" ? Wn(t) ? [] : jh(t, this._c) : [].concat(n), r], i = a[0], l = a.reduce((c, d) => {
    const f = Ms(t, d, o);
    return c.top = Ee(f.top, c.top), c.right = ft(f.right, c.right), c.bottom = ft(f.bottom, c.bottom), c.left = Ee(f.left, c.left), c;
  }, Ms(t, i, o));
  return {
    width: l.right - l.left,
    height: l.bottom - l.top,
    x: l.left,
    y: l.top
  };
}
function Mh(e) {
  const {
    width: t,
    height: n
  } = ii(e);
  return {
    width: t,
    height: n
  };
}
function Lh(e, t, n) {
  const r = Ve(t), o = Ue(t), s = n === "fixed", a = xt(e, !0, s, t);
  let i = {
    scrollLeft: 0,
    scrollTop: 0
  };
  const l = Be(0);
  function c() {
    l.x = Un(o);
  }
  if (r || !r && !s)
    if ((Ot(t) !== "body" || rn(o)) && (i = Gn(t)), r) {
      const u = xt(t, !0, s, t);
      l.x = u.x + t.clientLeft, l.y = u.y + t.clientTop;
    } else o && c();
  s && !r && o && c();
  const d = o && !r && !s ? ci(o, i) : Be(0), f = a.left + i.scrollLeft - l.x - d.x, p = a.top + i.scrollTop - l.y - d.y;
  return {
    x: f,
    y: p,
    width: a.width,
    height: a.height
  };
}
function mr(e) {
  return _e(e).position === "static";
}
function Ls(e, t) {
  if (!Ve(e) || _e(e).position === "fixed")
    return null;
  if (t)
    return t(e);
  let n = e.offsetParent;
  return Ue(e) === n && (n = n.ownerDocument.body), n;
}
function di(e, t) {
  const n = ke(e);
  if (Wn(e))
    return n;
  if (!Ve(e)) {
    let o = pt(e);
    for (; o && !jt(o); ) {
      if (Oe(o) && !mr(o))
        return o;
      o = pt(o);
    }
    return n;
  }
  let r = Ls(e, t);
  for (; r && gh(r) && mr(r); )
    r = Ls(r, t);
  return r && jt(r) && mr(r) && !Jr(r) ? n : r || wh(e) || n;
}
const Dh = async function(e) {
  const t = this.getOffsetParent || di, n = this.getDimensions, r = await n(e.floating);
  return {
    reference: Lh(e.reference, await t(e.floating), e.strategy),
    floating: {
      x: 0,
      y: 0,
      width: r.width,
      height: r.height
    }
  };
};
function zh(e) {
  return _e(e).direction === "rtl";
}
const Oh = {
  convertOffsetParentRelativeRectToViewportRelativeRect: kh,
  getDocumentElement: Ue,
  getClippingRect: Ih,
  getOffsetParent: di,
  getElementRects: Dh,
  getClientRects: Ph,
  getDimensions: Mh,
  getScale: Nt,
  isElement: Oe,
  isRTL: zh
};
function fi(e, t) {
  return e.x === t.x && e.y === t.y && e.width === t.width && e.height === t.height;
}
function _h(e, t) {
  let n = null, r;
  const o = Ue(e);
  function s() {
    var i;
    clearTimeout(r), (i = n) == null || i.disconnect(), n = null;
  }
  function a(i, l) {
    i === void 0 && (i = !1), l === void 0 && (l = 1), s();
    const c = e.getBoundingClientRect(), {
      left: d,
      top: f,
      width: p,
      height: u
    } = c;
    if (i || t(), !p || !u)
      return;
    const g = hn(f), b = hn(o.clientWidth - (d + p)), x = hn(o.clientHeight - (f + u)), v = hn(d), S = {
      rootMargin: -g + "px " + -b + "px " + -x + "px " + -v + "px",
      threshold: Ee(0, ft(1, l)) || 1
    };
    let C = !0;
    function k(E) {
      const w = E[0].intersectionRatio;
      if (w !== l) {
        if (!C)
          return a();
        w ? a(!1, w) : r = setTimeout(() => {
          a(!1, 1e-7);
        }, 1e3);
      }
      w === 1 && !fi(c, e.getBoundingClientRect()) && a(), C = !1;
    }
    try {
      n = new IntersectionObserver(k, {
        ...S,
        // Handle <iframe>s
        root: o.ownerDocument
      });
    } catch {
      n = new IntersectionObserver(k, S);
    }
    n.observe(e);
  }
  return a(!0), s;
}
function $h(e, t, n, r) {
  r === void 0 && (r = {});
  const {
    ancestorScroll: o = !0,
    ancestorResize: s = !0,
    elementResize: a = typeof ResizeObserver == "function",
    layoutShift: i = typeof IntersectionObserver == "function",
    animationFrame: l = !1
  } = r, c = Qr(e), d = o || s ? [...c ? Xt(c) : [], ...Xt(t)] : [];
  d.forEach((v) => {
    o && v.addEventListener("scroll", n, {
      passive: !0
    }), s && v.addEventListener("resize", n);
  });
  const f = c && i ? _h(c, n) : null;
  let p = -1, u = null;
  a && (u = new ResizeObserver((v) => {
    let [y] = v;
    y && y.target === c && u && (u.unobserve(t), cancelAnimationFrame(p), p = requestAnimationFrame(() => {
      var S;
      (S = u) == null || S.observe(t);
    })), n();
  }), c && !l && u.observe(c), u.observe(t));
  let g, b = l ? xt(e) : null;
  l && x();
  function x() {
    const v = xt(e);
    b && !fi(b, v) && n(), b = v, g = requestAnimationFrame(x);
  }
  return n(), () => {
    var v;
    d.forEach((y) => {
      o && y.removeEventListener("scroll", n), s && y.removeEventListener("resize", n);
    }), f == null || f(), (v = u) == null || v.disconnect(), u = null, l && cancelAnimationFrame(g);
  };
}
const Fh = uh, Bh = dh, Hh = ih, Vh = ph, Wh = lh, Ds = ah, Gh = fh, Uh = (e, t, n) => {
  const r = /* @__PURE__ */ new Map(), o = {
    platform: Oh,
    ...n
  }, s = {
    ...o.platform,
    _c: r
  };
  return sh(e, t, {
    ...o,
    platform: s
  });
};
var Kh = typeof document < "u", Yh = function() {
}, yn = Kh ? h.useLayoutEffect : Yh;
function Pn(e, t) {
  if (e === t)
    return !0;
  if (typeof e != typeof t)
    return !1;
  if (typeof e == "function" && e.toString() === t.toString())
    return !0;
  let n, r, o;
  if (e && t && typeof e == "object") {
    if (Array.isArray(e)) {
      if (n = e.length, n !== t.length) return !1;
      for (r = n; r-- !== 0; )
        if (!Pn(e[r], t[r]))
          return !1;
      return !0;
    }
    if (o = Object.keys(e), n = o.length, n !== Object.keys(t).length)
      return !1;
    for (r = n; r-- !== 0; )
      if (!{}.hasOwnProperty.call(t, o[r]))
        return !1;
    for (r = n; r-- !== 0; ) {
      const s = o[r];
      if (!(s === "_owner" && e.$$typeof) && !Pn(e[s], t[s]))
        return !1;
    }
    return !0;
  }
  return e !== e && t !== t;
}
function pi(e) {
  return typeof window > "u" ? 1 : (e.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function zs(e, t) {
  const n = pi(e);
  return Math.round(t * n) / n;
}
function hr(e) {
  const t = h.useRef(e);
  return yn(() => {
    t.current = e;
  }), t;
}
function Xh(e) {
  e === void 0 && (e = {});
  const {
    placement: t = "bottom",
    strategy: n = "absolute",
    middleware: r = [],
    platform: o,
    elements: {
      reference: s,
      floating: a
    } = {},
    transform: i = !0,
    whileElementsMounted: l,
    open: c
  } = e, [d, f] = h.useState({
    x: 0,
    y: 0,
    strategy: n,
    placement: t,
    middlewareData: {},
    isPositioned: !1
  }), [p, u] = h.useState(r);
  Pn(p, r) || u(r);
  const [g, b] = h.useState(null), [x, v] = h.useState(null), y = h.useCallback((W) => {
    W !== E.current && (E.current = W, b(W));
  }, []), S = h.useCallback((W) => {
    W !== w.current && (w.current = W, v(W));
  }, []), C = s || g, k = a || x, E = h.useRef(null), w = h.useRef(null), R = h.useRef(d), T = l != null, I = hr(l), A = hr(o), N = hr(c), _ = h.useCallback(() => {
    if (!E.current || !w.current)
      return;
    const W = {
      placement: t,
      strategy: n,
      middleware: p
    };
    A.current && (W.platform = A.current), Uh(E.current, w.current, W).then((B) => {
      const te = {
        ...B,
        // The floating element's position may be recomputed while it's closed
        // but still mounted (such as when transitioning out). To ensure
        // `isPositioned` will be `false` initially on the next open, avoid
        // setting it to `true` when `open === false` (must be specified).
        isPositioned: N.current !== !1
      };
      O.current && !Pn(R.current, te) && (R.current = te, $r.flushSync(() => {
        f(te);
      }));
    });
  }, [p, t, n, A, N]);
  yn(() => {
    c === !1 && R.current.isPositioned && (R.current.isPositioned = !1, f((W) => ({
      ...W,
      isPositioned: !1
    })));
  }, [c]);
  const O = h.useRef(!1);
  yn(() => (O.current = !0, () => {
    O.current = !1;
  }), []), yn(() => {
    if (C && (E.current = C), k && (w.current = k), C && k) {
      if (I.current)
        return I.current(C, k, _);
      _();
    }
  }, [C, k, _, I, T]);
  const M = h.useMemo(() => ({
    reference: E,
    floating: w,
    setReference: y,
    setFloating: S
  }), [y, S]), L = h.useMemo(() => ({
    reference: C,
    floating: k
  }), [C, k]), V = h.useMemo(() => {
    const W = {
      position: n,
      left: 0,
      top: 0
    };
    if (!L.floating)
      return W;
    const B = zs(L.floating, d.x), te = zs(L.floating, d.y);
    return i ? {
      ...W,
      transform: "translate(" + B + "px, " + te + "px)",
      ...pi(L.floating) >= 1.5 && {
        willChange: "transform"
      }
    } : {
      position: n,
      left: B,
      top: te
    };
  }, [n, i, L.floating, d.x, d.y]);
  return h.useMemo(() => ({
    ...d,
    update: _,
    refs: M,
    elements: L,
    floatingStyles: V
  }), [d, _, M, L, V]);
}
const qh = (e) => {
  function t(n) {
    return {}.hasOwnProperty.call(n, "current");
  }
  return {
    name: "arrow",
    options: e,
    fn(n) {
      const {
        element: r,
        padding: o
      } = typeof e == "function" ? e(n) : e;
      return r && t(r) ? r.current != null ? Ds({
        element: r.current,
        padding: o
      }).fn(n) : {} : r ? Ds({
        element: r,
        padding: o
      }).fn(n) : {};
    }
  };
}, Jh = (e, t) => ({
  ...Fh(e),
  options: [e, t]
}), Zh = (e, t) => ({
  ...Bh(e),
  options: [e, t]
}), Qh = (e, t) => ({
  ...Gh(e),
  options: [e, t]
}), eg = (e, t) => ({
  ...Hh(e),
  options: [e, t]
}), tg = (e, t) => ({
  ...Vh(e),
  options: [e, t]
}), ng = (e, t) => ({
  ...Wh(e),
  options: [e, t]
}), rg = (e, t) => ({
  ...qh(e),
  options: [e, t]
});
var og = "Arrow", mi = h.forwardRef((e, t) => {
  const { children: n, width: r = 10, height: o = 5, ...s } = e;
  return /* @__PURE__ */ m.jsx(
    le.svg,
    {
      ...s,
      ref: t,
      width: r,
      height: o,
      viewBox: "0 0 30 10",
      preserveAspectRatio: "none",
      children: e.asChild ? n : /* @__PURE__ */ m.jsx("polygon", { points: "0,0 30,0 15,10" })
    }
  );
});
mi.displayName = og;
var sg = mi, eo = "Popper", [hi, gi] = We(eo), [ag, bi] = hi(eo), vi = (e) => {
  const { __scopePopper: t, children: n } = e, [r, o] = h.useState(null);
  return /* @__PURE__ */ m.jsx(ag, { scope: t, anchor: r, onAnchorChange: o, children: n });
};
vi.displayName = eo;
var xi = "PopperAnchor", yi = h.forwardRef(
  (e, t) => {
    const { __scopePopper: n, virtualRef: r, ...o } = e, s = bi(xi, n), a = h.useRef(null), i = pe(t, a), l = h.useRef(null);
    return h.useEffect(() => {
      const c = l.current;
      l.current = (r == null ? void 0 : r.current) || a.current, c !== l.current && s.onAnchorChange(l.current);
    }), r ? null : /* @__PURE__ */ m.jsx(le.div, { ...o, ref: i });
  }
);
yi.displayName = xi;
var to = "PopperContent", [ig, lg] = hi(to), wi = h.forwardRef(
  (e, t) => {
    var z, G, X, Q, Z, H;
    const {
      __scopePopper: n,
      side: r = "bottom",
      sideOffset: o = 0,
      align: s = "center",
      alignOffset: a = 0,
      arrowPadding: i = 0,
      avoidCollisions: l = !0,
      collisionBoundary: c = [],
      collisionPadding: d = 0,
      sticky: f = "partial",
      hideWhenDetached: p = !1,
      updatePositionStrategy: u = "optimized",
      onPlaced: g,
      ...b
    } = e, x = bi(to, n), [v, y] = h.useState(null), S = pe(t, (Y) => y(Y)), [C, k] = h.useState(null), E = Vr(C), w = (E == null ? void 0 : E.width) ?? 0, R = (E == null ? void 0 : E.height) ?? 0, T = r + (s !== "center" ? "-" + s : ""), I = typeof d == "number" ? d : { top: 0, right: 0, bottom: 0, left: 0, ...d }, A = Array.isArray(c) ? c : [c], N = A.length > 0, _ = {
      padding: I,
      boundary: A.filter(ug),
      // with `strategy: 'fixed'`, this is the only way to get it to respect boundaries
      altBoundary: N
    }, { refs: O, floatingStyles: M, placement: L, isPositioned: V, middlewareData: W } = Xh({
      // default to `fixed` strategy so users don't have to pick and we also avoid focus scroll issues
      strategy: "fixed",
      placement: T,
      whileElementsMounted: (...Y) => $h(...Y, {
        animationFrame: u === "always"
      }),
      elements: {
        reference: x.anchor
      },
      middleware: [
        Jh({ mainAxis: o + R, alignmentAxis: a }),
        l && Zh({
          mainAxis: !0,
          crossAxis: !1,
          limiter: f === "partial" ? Qh() : void 0,
          ..._
        }),
        l && eg({ ..._ }),
        tg({
          ..._,
          apply: ({ elements: Y, rects: oe, availableWidth: ue, availableHeight: ge }) => {
            const { width: ve, height: ie } = oe.reference, be = Y.floating.style;
            be.setProperty("--radix-popper-available-width", `${ue}px`), be.setProperty("--radix-popper-available-height", `${ge}px`), be.setProperty("--radix-popper-anchor-width", `${ve}px`), be.setProperty("--radix-popper-anchor-height", `${ie}px`);
          }
        }),
        C && rg({ element: C, padding: i }),
        dg({ arrowWidth: w, arrowHeight: R }),
        p && ng({ strategy: "referenceHidden", ..._ })
      ]
    }), [B, te] = Ei(L), re = Re(g);
    He(() => {
      V && (re == null || re());
    }, [V, re]);
    const J = (z = W.arrow) == null ? void 0 : z.x, j = (G = W.arrow) == null ? void 0 : G.y, F = ((X = W.arrow) == null ? void 0 : X.centerOffset) !== 0, [U, K] = h.useState();
    return He(() => {
      v && K(window.getComputedStyle(v).zIndex);
    }, [v]), /* @__PURE__ */ m.jsx(
      "div",
      {
        ref: O.setFloating,
        "data-radix-popper-content-wrapper": "",
        style: {
          ...M,
          transform: V ? M.transform : "translate(0, -200%)",
          // keep off the page when measuring
          minWidth: "max-content",
          zIndex: U,
          "--radix-popper-transform-origin": [
            (Q = W.transformOrigin) == null ? void 0 : Q.x,
            (Z = W.transformOrigin) == null ? void 0 : Z.y
          ].join(" "),
          // hide the content if using the hide middleware and should be hidden
          // set visibility to hidden and disable pointer events so the UI behaves
          // as if the PopperContent isn't there at all
          ...((H = W.hide) == null ? void 0 : H.referenceHidden) && {
            visibility: "hidden",
            pointerEvents: "none"
          }
        },
        dir: e.dir,
        children: /* @__PURE__ */ m.jsx(
          ig,
          {
            scope: n,
            placedSide: B,
            onArrowChange: k,
            arrowX: J,
            arrowY: j,
            shouldHideArrow: F,
            children: /* @__PURE__ */ m.jsx(
              le.div,
              {
                "data-side": B,
                "data-align": te,
                ...b,
                ref: S,
                style: {
                  ...b.style,
                  // if the PopperContent hasn't been placed yet (not all measurements done)
                  // we prevent animations so that users's animation don't kick in too early referring wrong sides
                  animation: V ? void 0 : "none"
                }
              }
            )
          }
        )
      }
    );
  }
);
wi.displayName = to;
var Ci = "PopperArrow", cg = {
  top: "bottom",
  right: "left",
  bottom: "top",
  left: "right"
}, Si = h.forwardRef(function(t, n) {
  const { __scopePopper: r, ...o } = t, s = lg(Ci, r), a = cg[s.placedSide];
  return (
    // we have to use an extra wrapper because `ResizeObserver` (used by `useSize`)
    // doesn't report size as we'd expect on SVG elements.
    // it reports their bounding box which is effectively the largest path inside the SVG.
    /* @__PURE__ */ m.jsx(
      "span",
      {
        ref: s.onArrowChange,
        style: {
          position: "absolute",
          left: s.arrowX,
          top: s.arrowY,
          [a]: 0,
          transformOrigin: {
            top: "",
            right: "0 0",
            bottom: "center 0",
            left: "100% 0"
          }[s.placedSide],
          transform: {
            top: "translateY(100%)",
            right: "translateY(50%) rotate(90deg) translateX(-50%)",
            bottom: "rotate(180deg)",
            left: "translateY(50%) rotate(-90deg) translateX(50%)"
          }[s.placedSide],
          visibility: s.shouldHideArrow ? "hidden" : void 0
        },
        children: /* @__PURE__ */ m.jsx(
          sg,
          {
            ...o,
            ref: n,
            style: {
              ...o.style,
              // ensures the element can be measured correctly (mostly for if SVG)
              display: "block"
            }
          }
        )
      }
    )
  );
});
Si.displayName = Ci;
function ug(e) {
  return e !== null;
}
var dg = (e) => ({
  name: "transformOrigin",
  options: e,
  fn(t) {
    var x, v, y;
    const { placement: n, rects: r, middlewareData: o } = t, a = ((x = o.arrow) == null ? void 0 : x.centerOffset) !== 0, i = a ? 0 : e.arrowWidth, l = a ? 0 : e.arrowHeight, [c, d] = Ei(n), f = { start: "0%", center: "50%", end: "100%" }[d], p = (((v = o.arrow) == null ? void 0 : v.x) ?? 0) + i / 2, u = (((y = o.arrow) == null ? void 0 : y.y) ?? 0) + l / 2;
    let g = "", b = "";
    return c === "bottom" ? (g = a ? f : `${p}px`, b = `${-l}px`) : c === "top" ? (g = a ? f : `${p}px`, b = `${r.floating.height + l}px`) : c === "right" ? (g = `${-l}px`, b = a ? f : `${u}px`) : c === "left" && (g = `${r.floating.width + l}px`, b = a ? f : `${u}px`), { data: { x: g, y: b } };
  }
});
function Ei(e) {
  const [t, n = "center"] = e.split("-");
  return [t, n];
}
var fg = vi, pg = yi, mg = wi, hg = Si, gg = "Portal", ki = h.forwardRef((e, t) => {
  var i;
  const { container: n, ...r } = e, [o, s] = h.useState(!1);
  He(() => s(!0), []);
  const a = n || o && ((i = globalThis == null ? void 0 : globalThis.document) == null ? void 0 : i.body);
  return a ? zn.createPortal(/* @__PURE__ */ m.jsx(le.div, { ...r, ref: t }), a) : null;
});
ki.displayName = gg;
var bg = Symbol("radix.slottable");
// @__NO_SIDE_EFFECTS__
function vg(e) {
  const t = ({ children: n }) => /* @__PURE__ */ m.jsx(m.Fragment, { children: n });
  return t.displayName = `${e}.Slottable`, t.__radixId = bg, t;
}
var xg = Object.freeze({
  // See: https://github.com/twbs/bootstrap/blob/main/scss/mixins/_visually-hidden.scss
  position: "absolute",
  border: 0,
  width: 1,
  height: 1,
  padding: 0,
  margin: -1,
  overflow: "hidden",
  clip: "rect(0, 0, 0, 0)",
  whiteSpace: "nowrap",
  wordWrap: "normal"
}), yg = "VisuallyHidden", Pi = h.forwardRef(
  (e, t) => /* @__PURE__ */ m.jsx(
    le.span,
    {
      ...e,
      ref: t,
      style: { ...xg, ...e.style }
    }
  )
);
Pi.displayName = yg;
var wg = Pi, [Kn] = We("Tooltip", [
  gi
]), Yn = gi(), Ri = "TooltipProvider", Cg = 700, jr = "tooltip.open", [Sg, no] = Kn(Ri), Ai = (e) => {
  const {
    __scopeTooltip: t,
    delayDuration: n = Cg,
    skipDelayDuration: r = 300,
    disableHoverableContent: o = !1,
    children: s
  } = e, a = h.useRef(!0), i = h.useRef(!1), l = h.useRef(0);
  return h.useEffect(() => {
    const c = l.current;
    return () => window.clearTimeout(c);
  }, []), /* @__PURE__ */ m.jsx(
    Sg,
    {
      scope: t,
      isOpenDelayedRef: a,
      delayDuration: n,
      onOpen: h.useCallback(() => {
        window.clearTimeout(l.current), a.current = !1;
      }, []),
      onClose: h.useCallback(() => {
        window.clearTimeout(l.current), l.current = window.setTimeout(
          () => a.current = !0,
          r
        );
      }, [r]),
      isPointerInTransitRef: i,
      onPointerInTransitChange: h.useCallback((c) => {
        i.current = c;
      }, []),
      disableHoverableContent: o,
      children: s
    }
  );
};
Ai.displayName = Ri;
var qt = "Tooltip", [Eg, on] = Kn(qt), Ni = (e) => {
  const {
    __scopeTooltip: t,
    children: n,
    open: r,
    defaultOpen: o,
    onOpenChange: s,
    disableHoverableContent: a,
    delayDuration: i
  } = e, l = no(qt, e.__scopeTooltip), c = Yn(t), [d, f] = h.useState(null), p = $n(), u = h.useRef(0), g = a ?? l.disableHoverableContent, b = i ?? l.delayDuration, x = h.useRef(!1), [v, y] = Ct({
    prop: r,
    defaultProp: o ?? !1,
    onChange: (w) => {
      w ? (l.onOpen(), document.dispatchEvent(new CustomEvent(jr))) : l.onClose(), s == null || s(w);
    },
    caller: qt
  }), S = h.useMemo(() => v ? x.current ? "delayed-open" : "instant-open" : "closed", [v]), C = h.useCallback(() => {
    window.clearTimeout(u.current), u.current = 0, x.current = !1, y(!0);
  }, [y]), k = h.useCallback(() => {
    window.clearTimeout(u.current), u.current = 0, y(!1);
  }, [y]), E = h.useCallback(() => {
    window.clearTimeout(u.current), u.current = window.setTimeout(() => {
      x.current = !0, y(!0), u.current = 0;
    }, b);
  }, [b, y]);
  return h.useEffect(() => () => {
    u.current && (window.clearTimeout(u.current), u.current = 0);
  }, []), /* @__PURE__ */ m.jsx(fg, { ...c, children: /* @__PURE__ */ m.jsx(
    Eg,
    {
      scope: t,
      contentId: p,
      open: v,
      stateAttribute: S,
      trigger: d,
      onTriggerChange: f,
      onTriggerEnter: h.useCallback(() => {
        l.isOpenDelayedRef.current ? E() : C();
      }, [l.isOpenDelayedRef, E, C]),
      onTriggerLeave: h.useCallback(() => {
        g ? k() : (window.clearTimeout(u.current), u.current = 0);
      }, [k, g]),
      onOpen: C,
      onClose: k,
      disableHoverableContent: g,
      children: n
    }
  ) });
};
Ni.displayName = qt;
var Ir = "TooltipTrigger", Ti = h.forwardRef(
  (e, t) => {
    const { __scopeTooltip: n, ...r } = e, o = on(Ir, n), s = no(Ir, n), a = Yn(n), i = h.useRef(null), l = pe(t, i, o.onTriggerChange), c = h.useRef(!1), d = h.useRef(!1), f = h.useCallback(() => c.current = !1, []);
    return h.useEffect(() => () => document.removeEventListener("pointerup", f), [f]), /* @__PURE__ */ m.jsx(pg, { asChild: !0, ...a, children: /* @__PURE__ */ m.jsx(
      le.button,
      {
        "aria-describedby": o.open ? o.contentId : void 0,
        "data-state": o.stateAttribute,
        ...r,
        ref: l,
        onPointerMove: ae(e.onPointerMove, (p) => {
          p.pointerType !== "touch" && !d.current && !s.isPointerInTransitRef.current && (o.onTriggerEnter(), d.current = !0);
        }),
        onPointerLeave: ae(e.onPointerLeave, () => {
          o.onTriggerLeave(), d.current = !1;
        }),
        onPointerDown: ae(e.onPointerDown, () => {
          o.open && o.onClose(), c.current = !0, document.addEventListener("pointerup", f, { once: !0 });
        }),
        onFocus: ae(e.onFocus, () => {
          c.current || o.onOpen();
        }),
        onBlur: ae(e.onBlur, o.onClose),
        onClick: ae(e.onClick, o.onClose)
      }
    ) });
  }
);
Ti.displayName = Ir;
var ro = "TooltipPortal", [kg, Pg] = Kn(ro, {
  forceMount: void 0
}), ji = (e) => {
  const { __scopeTooltip: t, forceMount: n, children: r, container: o } = e, s = on(ro, t);
  return /* @__PURE__ */ m.jsx(kg, { scope: t, forceMount: n, children: /* @__PURE__ */ m.jsx(Ge, { present: n || s.open, children: /* @__PURE__ */ m.jsx(ki, { asChild: !0, container: o, children: r }) }) });
};
ji.displayName = ro;
var It = "TooltipContent", Ii = h.forwardRef(
  (e, t) => {
    const n = Pg(It, e.__scopeTooltip), { forceMount: r = n.forceMount, side: o = "top", ...s } = e, a = on(It, e.__scopeTooltip);
    return /* @__PURE__ */ m.jsx(Ge, { present: r || a.open, children: a.disableHoverableContent ? /* @__PURE__ */ m.jsx(Mi, { side: o, ...s, ref: t }) : /* @__PURE__ */ m.jsx(Rg, { side: o, ...s, ref: t }) });
  }
), Rg = h.forwardRef((e, t) => {
  const n = on(It, e.__scopeTooltip), r = no(It, e.__scopeTooltip), o = h.useRef(null), s = pe(t, o), [a, i] = h.useState(null), { trigger: l, onClose: c } = n, d = o.current, { onPointerInTransitChange: f } = r, p = h.useCallback(() => {
    i(null), f(!1);
  }, [f]), u = h.useCallback(
    (g, b) => {
      const x = g.currentTarget, v = { x: g.clientX, y: g.clientY }, y = jg(v, x.getBoundingClientRect()), S = Ig(v, y), C = Mg(b.getBoundingClientRect()), k = Dg([...S, ...C]);
      i(k), f(!0);
    },
    [f]
  );
  return h.useEffect(() => () => p(), [p]), h.useEffect(() => {
    if (l && d) {
      const g = (x) => u(x, d), b = (x) => u(x, l);
      return l.addEventListener("pointerleave", g), d.addEventListener("pointerleave", b), () => {
        l.removeEventListener("pointerleave", g), d.removeEventListener("pointerleave", b);
      };
    }
  }, [l, d, u, p]), h.useEffect(() => {
    if (a) {
      const g = (b) => {
        const x = b.target, v = { x: b.clientX, y: b.clientY }, y = (l == null ? void 0 : l.contains(x)) || (d == null ? void 0 : d.contains(x)), S = !Lg(v, a);
        y ? p() : S && (p(), c());
      };
      return document.addEventListener("pointermove", g), () => document.removeEventListener("pointermove", g);
    }
  }, [l, d, a, c, p]), /* @__PURE__ */ m.jsx(Mi, { ...e, ref: s });
}), [Ag, Ng] = Kn(qt, { isInside: !1 }), Tg = /* @__PURE__ */ vg("TooltipContent"), Mi = h.forwardRef(
  (e, t) => {
    const {
      __scopeTooltip: n,
      children: r,
      "aria-label": o,
      onEscapeKeyDown: s,
      onPointerDownOutside: a,
      ...i
    } = e, l = on(It, n), c = Yn(n), { onClose: d } = l;
    return h.useEffect(() => (document.addEventListener(jr, d), () => document.removeEventListener(jr, d)), [d]), h.useEffect(() => {
      if (l.trigger) {
        const f = (p) => {
          const u = p.target;
          u != null && u.contains(l.trigger) && d();
        };
        return window.addEventListener("scroll", f, { capture: !0 }), () => window.removeEventListener("scroll", f, { capture: !0 });
      }
    }, [l.trigger, d]), /* @__PURE__ */ m.jsx(
      ti,
      {
        asChild: !0,
        disableOutsidePointerEvents: !1,
        onEscapeKeyDown: s,
        onPointerDownOutside: a,
        onFocusOutside: (f) => f.preventDefault(),
        onDismiss: d,
        children: /* @__PURE__ */ m.jsxs(
          mg,
          {
            "data-state": l.stateAttribute,
            ...c,
            ...i,
            ref: t,
            style: {
              ...i.style,
              "--radix-tooltip-content-transform-origin": "var(--radix-popper-transform-origin)",
              "--radix-tooltip-content-available-width": "var(--radix-popper-available-width)",
              "--radix-tooltip-content-available-height": "var(--radix-popper-available-height)",
              "--radix-tooltip-trigger-width": "var(--radix-popper-anchor-width)",
              "--radix-tooltip-trigger-height": "var(--radix-popper-anchor-height)"
            },
            children: [
              /* @__PURE__ */ m.jsx(Tg, { children: r }),
              /* @__PURE__ */ m.jsx(Ag, { scope: n, isInside: !0, children: /* @__PURE__ */ m.jsx(wg, { id: l.contentId, role: "tooltip", children: o || r }) })
            ]
          }
        )
      }
    );
  }
);
Ii.displayName = It;
var Li = "TooltipArrow", Di = h.forwardRef(
  (e, t) => {
    const { __scopeTooltip: n, ...r } = e, o = Yn(n);
    return Ng(
      Li,
      n
    ).isInside ? null : /* @__PURE__ */ m.jsx(hg, { ...o, ...r, ref: t });
  }
);
Di.displayName = Li;
function jg(e, t) {
  const n = Math.abs(t.top - e.y), r = Math.abs(t.bottom - e.y), o = Math.abs(t.right - e.x), s = Math.abs(t.left - e.x);
  switch (Math.min(n, r, o, s)) {
    case s:
      return "left";
    case o:
      return "right";
    case n:
      return "top";
    case r:
      return "bottom";
    default:
      throw new Error("unreachable");
  }
}
function Ig(e, t, n = 5) {
  const r = [];
  switch (t) {
    case "top":
      r.push(
        { x: e.x - n, y: e.y + n },
        { x: e.x + n, y: e.y + n }
      );
      break;
    case "bottom":
      r.push(
        { x: e.x - n, y: e.y - n },
        { x: e.x + n, y: e.y - n }
      );
      break;
    case "left":
      r.push(
        { x: e.x + n, y: e.y - n },
        { x: e.x + n, y: e.y + n }
      );
      break;
    case "right":
      r.push(
        { x: e.x - n, y: e.y - n },
        { x: e.x - n, y: e.y + n }
      );
      break;
  }
  return r;
}
function Mg(e) {
  const { top: t, right: n, bottom: r, left: o } = e;
  return [
    { x: o, y: t },
    { x: n, y: t },
    { x: n, y: r },
    { x: o, y: r }
  ];
}
function Lg(e, t) {
  const { x: n, y: r } = e;
  let o = !1;
  for (let s = 0, a = t.length - 1; s < t.length; a = s++) {
    const i = t[s], l = t[a], c = i.x, d = i.y, f = l.x, p = l.y;
    d > r != p > r && n < (f - c) * (r - d) / (p - d) + c && (o = !o);
  }
  return o;
}
function Dg(e) {
  const t = e.slice();
  return t.sort((n, r) => n.x < r.x ? -1 : n.x > r.x ? 1 : n.y < r.y ? -1 : n.y > r.y ? 1 : 0), zg(t);
}
function zg(e) {
  if (e.length <= 1) return e.slice();
  const t = [];
  for (let r = 0; r < e.length; r++) {
    const o = e[r];
    for (; t.length >= 2; ) {
      const s = t[t.length - 1], a = t[t.length - 2];
      if ((s.x - a.x) * (o.y - a.y) >= (s.y - a.y) * (o.x - a.x)) t.pop();
      else break;
    }
    t.push(o);
  }
  t.pop();
  const n = [];
  for (let r = e.length - 1; r >= 0; r--) {
    const o = e[r];
    for (; n.length >= 2; ) {
      const s = n[n.length - 1], a = n[n.length - 2];
      if ((s.x - a.x) * (o.y - a.y) >= (s.y - a.y) * (o.x - a.x)) n.pop();
      else break;
    }
    n.push(o);
  }
  return n.pop(), t.length === 1 && n.length === 1 && t[0].x === n[0].x && t[0].y === n[0].y ? t : t.concat(n);
}
var Og = Ai, _g = Ni, $g = Ti, Fg = ji, Bg = Ii, Hg = Di, Xn = "Collapsible", [Vg, zi] = We(Xn), [Wg, oo] = Vg(Xn), Oi = h.forwardRef(
  (e, t) => {
    const {
      __scopeCollapsible: n,
      open: r,
      defaultOpen: o,
      disabled: s,
      onOpenChange: a,
      ...i
    } = e, [l, c] = Ct({
      prop: r,
      defaultProp: o ?? !1,
      onChange: a,
      caller: Xn
    });
    return /* @__PURE__ */ m.jsx(
      Wg,
      {
        scope: n,
        disabled: s,
        contentId: $n(),
        open: l,
        onOpenToggle: h.useCallback(() => c((d) => !d), [c]),
        children: /* @__PURE__ */ m.jsx(
          le.div,
          {
            "data-state": ao(l),
            "data-disabled": s ? "" : void 0,
            ...i,
            ref: t
          }
        )
      }
    );
  }
);
Oi.displayName = Xn;
var _i = "CollapsibleTrigger", $i = h.forwardRef(
  (e, t) => {
    const { __scopeCollapsible: n, ...r } = e, o = oo(_i, n);
    return /* @__PURE__ */ m.jsx(
      le.button,
      {
        type: "button",
        "aria-controls": o.contentId,
        "aria-expanded": o.open || !1,
        "data-state": ao(o.open),
        "data-disabled": o.disabled ? "" : void 0,
        disabled: o.disabled,
        ...r,
        ref: t,
        onClick: ae(e.onClick, o.onOpenToggle)
      }
    );
  }
);
$i.displayName = _i;
var so = "CollapsibleContent", Fi = h.forwardRef(
  (e, t) => {
    const { forceMount: n, ...r } = e, o = oo(so, e.__scopeCollapsible);
    return /* @__PURE__ */ m.jsx(Ge, { present: n || o.open, children: ({ present: s }) => /* @__PURE__ */ m.jsx(Gg, { ...r, ref: t, present: s }) });
  }
);
Fi.displayName = so;
var Gg = h.forwardRef((e, t) => {
  const { __scopeCollapsible: n, present: r, children: o, ...s } = e, a = oo(so, n), [i, l] = h.useState(r), c = h.useRef(null), d = pe(t, c), f = h.useRef(0), p = f.current, u = h.useRef(0), g = u.current, b = a.open || i, x = h.useRef(b), v = h.useRef(void 0);
  return h.useEffect(() => {
    const y = requestAnimationFrame(() => x.current = !1);
    return () => cancelAnimationFrame(y);
  }, []), He(() => {
    const y = c.current;
    if (y) {
      v.current = v.current || {
        transitionDuration: y.style.transitionDuration,
        animationName: y.style.animationName
      }, y.style.transitionDuration = "0s", y.style.animationName = "none";
      const S = y.getBoundingClientRect();
      f.current = S.height, u.current = S.width, x.current || (y.style.transitionDuration = v.current.transitionDuration, y.style.animationName = v.current.animationName), l(r);
    }
  }, [a.open, r]), /* @__PURE__ */ m.jsx(
    le.div,
    {
      "data-state": ao(a.open),
      "data-disabled": a.disabled ? "" : void 0,
      id: a.contentId,
      hidden: !b,
      ...s,
      ref: d,
      style: {
        "--radix-collapsible-content-height": p ? `${p}px` : void 0,
        "--radix-collapsible-content-width": g ? `${g}px` : void 0,
        ...e.style
      },
      children: b && o
    }
  );
});
function ao(e) {
  return e ? "open" : "closed";
}
var Bi = Oi, io = $i, lo = Fi, $e = "Accordion", Ug = ["Home", "End", "ArrowDown", "ArrowUp", "ArrowLeft", "ArrowRight"], [co, Kg, Yg] = Ia($e), [qn] = We($e, [
  Yg,
  zi
]), uo = zi(), Hi = P.forwardRef(
  (e, t) => {
    const { type: n, ...r } = e, o = r, s = r;
    return /* @__PURE__ */ m.jsx(co.Provider, { scope: e.__scopeAccordion, children: n === "multiple" ? /* @__PURE__ */ m.jsx(Zg, { ...s, ref: t }) : /* @__PURE__ */ m.jsx(Jg, { ...o, ref: t }) });
  }
);
Hi.displayName = $e;
var [Vi, Xg] = qn($e), [Wi, qg] = qn(
  $e,
  { collapsible: !1 }
), Jg = P.forwardRef(
  (e, t) => {
    const {
      value: n,
      defaultValue: r,
      onValueChange: o = () => {
      },
      collapsible: s = !1,
      ...a
    } = e, [i, l] = Ct({
      prop: n,
      defaultProp: r ?? "",
      onChange: o,
      caller: $e
    });
    return /* @__PURE__ */ m.jsx(
      Vi,
      {
        scope: e.__scopeAccordion,
        value: P.useMemo(() => i ? [i] : [], [i]),
        onItemOpen: l,
        onItemClose: P.useCallback(() => s && l(""), [s, l]),
        children: /* @__PURE__ */ m.jsx(Wi, { scope: e.__scopeAccordion, collapsible: s, children: /* @__PURE__ */ m.jsx(Gi, { ...a, ref: t }) })
      }
    );
  }
), Zg = P.forwardRef((e, t) => {
  const {
    value: n,
    defaultValue: r,
    onValueChange: o = () => {
    },
    ...s
  } = e, [a, i] = Ct({
    prop: n,
    defaultProp: r ?? [],
    onChange: o,
    caller: $e
  }), l = P.useCallback(
    (d) => i((f = []) => [...f, d]),
    [i]
  ), c = P.useCallback(
    (d) => i((f = []) => f.filter((p) => p !== d)),
    [i]
  );
  return /* @__PURE__ */ m.jsx(
    Vi,
    {
      scope: e.__scopeAccordion,
      value: a,
      onItemOpen: l,
      onItemClose: c,
      children: /* @__PURE__ */ m.jsx(Wi, { scope: e.__scopeAccordion, collapsible: !0, children: /* @__PURE__ */ m.jsx(Gi, { ...s, ref: t }) })
    }
  );
}), [Qg, Jn] = qn($e), Gi = P.forwardRef(
  (e, t) => {
    const { __scopeAccordion: n, disabled: r, dir: o, orientation: s = "vertical", ...a } = e, i = P.useRef(null), l = pe(i, t), c = Kg(n), f = Fn(o) === "ltr", p = ae(e.onKeyDown, (u) => {
      var R;
      if (!Ug.includes(u.key)) return;
      const g = u.target, b = c().filter((T) => {
        var I;
        return !((I = T.ref.current) != null && I.disabled);
      }), x = b.findIndex((T) => T.ref.current === g), v = b.length;
      if (x === -1) return;
      u.preventDefault();
      let y = x;
      const S = 0, C = v - 1, k = () => {
        y = x + 1, y > C && (y = S);
      }, E = () => {
        y = x - 1, y < S && (y = C);
      };
      switch (u.key) {
        case "Home":
          y = S;
          break;
        case "End":
          y = C;
          break;
        case "ArrowRight":
          s === "horizontal" && (f ? k() : E());
          break;
        case "ArrowDown":
          s === "vertical" && k();
          break;
        case "ArrowLeft":
          s === "horizontal" && (f ? E() : k());
          break;
        case "ArrowUp":
          s === "vertical" && E();
          break;
      }
      const w = y % v;
      (R = b[w].ref.current) == null || R.focus();
    });
    return /* @__PURE__ */ m.jsx(
      Qg,
      {
        scope: n,
        disabled: r,
        direction: o,
        orientation: s,
        children: /* @__PURE__ */ m.jsx(co.Slot, { scope: n, children: /* @__PURE__ */ m.jsx(
          le.div,
          {
            ...a,
            "data-orientation": s,
            ref: l,
            onKeyDown: r ? void 0 : p
          }
        ) })
      }
    );
  }
), Rn = "AccordionItem", [eb, fo] = qn(Rn), Ui = P.forwardRef(
  (e, t) => {
    const { __scopeAccordion: n, value: r, ...o } = e, s = Jn(Rn, n), a = Xg(Rn, n), i = uo(n), l = $n(), c = r && a.value.includes(r) || !1, d = s.disabled || e.disabled;
    return /* @__PURE__ */ m.jsx(
      eb,
      {
        scope: n,
        open: c,
        disabled: d,
        triggerId: l,
        children: /* @__PURE__ */ m.jsx(
          Bi,
          {
            "data-orientation": s.orientation,
            "data-state": Zi(c),
            ...i,
            ...o,
            ref: t,
            disabled: d,
            open: c,
            onOpenChange: (f) => {
              f ? a.onItemOpen(r) : a.onItemClose(r);
            }
          }
        )
      }
    );
  }
);
Ui.displayName = Rn;
var Ki = "AccordionHeader", Yi = P.forwardRef(
  (e, t) => {
    const { __scopeAccordion: n, ...r } = e, o = Jn($e, n), s = fo(Ki, n);
    return /* @__PURE__ */ m.jsx(
      le.h3,
      {
        "data-orientation": o.orientation,
        "data-state": Zi(s.open),
        "data-disabled": s.disabled ? "" : void 0,
        ...r,
        ref: t
      }
    );
  }
);
Yi.displayName = Ki;
var Mr = "AccordionTrigger", Xi = P.forwardRef(
  (e, t) => {
    const { __scopeAccordion: n, ...r } = e, o = Jn($e, n), s = fo(Mr, n), a = qg(Mr, n), i = uo(n);
    return /* @__PURE__ */ m.jsx(co.ItemSlot, { scope: n, children: /* @__PURE__ */ m.jsx(
      io,
      {
        "aria-disabled": s.open && !a.collapsible || void 0,
        "data-orientation": o.orientation,
        id: s.triggerId,
        ...i,
        ...r,
        ref: t
      }
    ) });
  }
);
Xi.displayName = Mr;
var qi = "AccordionContent", Ji = P.forwardRef(
  (e, t) => {
    const { __scopeAccordion: n, ...r } = e, o = Jn($e, n), s = fo(qi, n), a = uo(n);
    return /* @__PURE__ */ m.jsx(
      lo,
      {
        role: "region",
        "aria-labelledby": s.triggerId,
        "data-orientation": o.orientation,
        ...a,
        ...r,
        ref: t,
        style: {
          "--radix-accordion-content-height": "var(--radix-collapsible-content-height)",
          "--radix-accordion-content-width": "var(--radix-collapsible-content-width)",
          ...e.style
        }
      }
    );
  }
);
Ji.displayName = qi;
function Zi(e) {
  return e ? "open" : "closed";
}
var Os = Hi, tb = Ui, nb = Yi, rb = Xi, ob = Ji;
function sb({
  id: e,
  className: t,
  type: n = "single",
  collapsible: r = !0,
  defaultValue: o,
  value: s,
  onValueChange: a,
  children: i,
  "data-refast-id": l
}) {
  return n === "single" ? /* @__PURE__ */ m.jsx(
    Os,
    {
      id: e,
      type: "single",
      collapsible: r,
      defaultValue: o,
      value: s,
      onValueChange: a,
      className: D("w-full", t),
      "data-refast-id": l,
      children: i
    }
  ) : /* @__PURE__ */ m.jsx(
    Os,
    {
      id: e,
      type: "multiple",
      defaultValue: o,
      value: s,
      onValueChange: a,
      className: D("w-full", t),
      "data-refast-id": l,
      children: i
    }
  );
}
function ab({
  id: e,
  className: t,
  value: n,
  children: r,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ m.jsx(
    tb,
    {
      id: e,
      value: n,
      className: D("border-b", t),
      "data-refast-id": o,
      children: r
    }
  );
}
const Qi = P.forwardRef(({ id: e, className: t, children: n, "data-refast-id": r }, o) => /* @__PURE__ */ m.jsx(nb, { className: "flex", children: /* @__PURE__ */ m.jsxs(
  rb,
  {
    ref: o,
    id: e,
    className: D(
      "flex flex-1 items-center justify-between py-4 font-medium transition-all hover:underline [&[data-state=open]>svg]:rotate-180",
      t
    ),
    "data-refast-id": r,
    children: [
      n,
      /* @__PURE__ */ m.jsx(da, { className: "h-4 w-4 shrink-0 transition-transform duration-200" })
    ]
  }
) }));
Qi.displayName = "AccordionTrigger";
const el = P.forwardRef(({ id: e, className: t, children: n, "data-refast-id": r }, o) => /* @__PURE__ */ m.jsx(
  ob,
  {
    ref: o,
    id: e,
    className: "overflow-hidden text-sm transition-all data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down",
    "data-refast-id": r,
    children: /* @__PURE__ */ m.jsx("div", { className: D("pb-4 pt-0", t), children: n })
  }
));
el.displayName = "AccordionContent";
function ib({
  id: e,
  className: t,
  children: n,
  "data-refast-id": r
}) {
  return /* @__PURE__ */ m.jsx("div", { className: "relative w-full overflow-auto", "data-refast-id": r, children: /* @__PURE__ */ m.jsx(
    "table",
    {
      id: e,
      className: D("w-full caption-bottom text-sm", t),
      children: n
    }
  ) });
}
function lb({
  id: e,
  className: t,
  children: n,
  "data-refast-id": r
}) {
  return /* @__PURE__ */ m.jsx(
    "thead",
    {
      id: e,
      className: D("[&_tr]:border-b", t),
      "data-refast-id": r,
      children: n
    }
  );
}
function cb({
  id: e,
  className: t,
  children: n,
  "data-refast-id": r
}) {
  return /* @__PURE__ */ m.jsx(
    "tbody",
    {
      id: e,
      className: D("[&_tr:last-child]:border-0", t),
      "data-refast-id": r,
      children: n
    }
  );
}
function ub({
  id: e,
  className: t,
  children: n,
  "data-refast-id": r
}) {
  return /* @__PURE__ */ m.jsx(
    "tr",
    {
      id: e,
      className: D(
        "border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted",
        t
      ),
      "data-refast-id": r,
      children: n
    }
  );
}
function db({
  id: e,
  className: t,
  children: n,
  "data-refast-id": r
}) {
  return /* @__PURE__ */ m.jsx(
    "th",
    {
      id: e,
      className: D(
        "h-12 px-4 text-left align-middle font-medium text-muted-foreground",
        "[&:has([role=checkbox])]:pr-0",
        t
      ),
      "data-refast-id": r,
      children: n
    }
  );
}
function fb({
  id: e,
  className: t,
  colSpan: n,
  rowSpan: r,
  children: o,
  "data-refast-id": s
}) {
  return /* @__PURE__ */ m.jsx(
    "td",
    {
      id: e,
      colSpan: n,
      rowSpan: r,
      className: D("p-4 align-middle [&:has([role=checkbox])]:pr-0", t),
      "data-refast-id": s,
      children: o
    }
  );
}
function pb({
  id: e,
  className: t,
  columns: n = [],
  data: r = [],
  sortable: o = !0,
  filterable: s = !0,
  paginated: a = !0,
  pageSize: i = 10,
  loading: l = !1,
  emptyMessage: c = "No data available",
  currentPage: d,
  onRowClick: f,
  onSortChange: p,
  onFilterChange: u,
  onPageChange: g,
  "data-refast-id": b
}) {
  const [x, v] = P.useState(""), [y, S] = P.useState(null), [C, k] = P.useState(1), E = d !== void 0 ? d : C, w = P.useMemo(() => {
    if (!x) return r;
    const M = x.toLowerCase();
    return r.filter(
      (L) => Object.values(L).some((V) => String(V ?? "").toLowerCase().includes(M))
    );
  }, [r, x]), R = P.useMemo(() => y ? [...w].sort((M, L) => {
    const V = String(M[y.key] ?? ""), W = String(L[y.key] ?? ""), B = V.localeCompare(W);
    return y.direction === "asc" ? B : -B;
  }) : w, [w, y]), T = a ? Math.max(1, Math.ceil(R.length / i)) : 1, I = a ? R.slice((E - 1) * i, E * i) : R, A = (M) => {
    if (!(M.sortable !== void 0 ? M.sortable : o)) return;
    let V;
    !y || y.key !== M.key ? V = { key: M.key, direction: "asc" } : y.direction === "asc" ? V = { key: M.key, direction: "desc" } : V = null, S(V), p == null || p(V);
  }, N = (M) => {
    v(M), d === void 0 && k(1), u == null || u({ value: M });
  }, _ = (M) => {
    d === void 0 && k(M), g == null || g({ page: M });
  }, O = P.useMemo(() => {
    const M = [], L = Math.min(T, 5);
    let V;
    E <= 3 || T <= 5 ? V = 1 : E >= T - 2 ? V = T - 4 : V = E - 2;
    for (let W = 0; W < L; W++) M.push(V + W);
    return M;
  }, [T, E]);
  return /* @__PURE__ */ m.jsxs("div", { id: e, className: D("w-full space-y-4", t), "data-refast-id": b, children: [
    s && /* @__PURE__ */ m.jsx(
      "input",
      {
        type: "text",
        placeholder: "Filter...",
        value: x,
        onChange: (M) => N(M.target.value),
        className: "flex h-9 w-full max-w-sm rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
      }
    ),
    /* @__PURE__ */ m.jsxs("div", { className: "relative w-full overflow-auto rounded-md border", children: [
      l && /* @__PURE__ */ m.jsx("div", { className: "absolute inset-0 z-10 flex items-center justify-center rounded-md bg-background/60", children: /* @__PURE__ */ m.jsx("div", { className: "h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" }) }),
      /* @__PURE__ */ m.jsxs("table", { className: "w-full caption-bottom text-sm", children: [
        /* @__PURE__ */ m.jsx("thead", { className: "[&_tr]:border-b", children: /* @__PURE__ */ m.jsx("tr", { className: "border-b transition-colors", children: n.map((M) => {
          const L = M.sortable !== void 0 ? M.sortable : o, V = (y == null ? void 0 : y.key) === M.key;
          return /* @__PURE__ */ m.jsx(
            "th",
            {
              style: M.width ? { width: M.width } : void 0,
              className: D(
                "h-10 px-4 text-left align-middle font-medium text-muted-foreground [&:has([role=checkbox])]:pr-0",
                M.align === "center" && "text-center",
                M.align === "right" && "text-right",
                L && "cursor-pointer select-none hover:text-foreground"
              ),
              onClick: () => A(M),
              children: /* @__PURE__ */ m.jsxs("span", { className: "inline-flex items-center gap-1", children: [
                M.header,
                L && /* @__PURE__ */ m.jsx("span", { className: "text-xs opacity-60", children: V ? (y == null ? void 0 : y.direction) === "asc" ? "↑" : "↓" : "↕" })
              ] })
            },
            M.key
          );
        }) }) }),
        /* @__PURE__ */ m.jsx("tbody", { className: "[&_tr:last-child]:border-0", children: I.length === 0 ? /* @__PURE__ */ m.jsx("tr", { children: /* @__PURE__ */ m.jsx(
          "td",
          {
            colSpan: n.length || 1,
            className: "py-8 text-center text-sm text-muted-foreground",
            children: c
          }
        ) }) : I.map((M, L) => /* @__PURE__ */ m.jsx(
          "tr",
          {
            className: D(
              "border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted",
              f && "cursor-pointer"
            ),
            onClick: () => f == null ? void 0 : f(M),
            children: n.map((V) => /* @__PURE__ */ m.jsx(
              "td",
              {
                className: D(
                  "p-4 align-middle",
                  V.align === "center" && "text-center",
                  V.align === "right" && "text-right"
                ),
                children: String(M[V.key] ?? "")
              },
              V.key
            ))
          },
          L
        )) })
      ] })
    ] }),
    a && T > 1 && /* @__PURE__ */ m.jsxs("div", { className: "flex items-center justify-between text-sm text-muted-foreground", children: [
      /* @__PURE__ */ m.jsxs("span", { children: [
        "Showing ",
        (E - 1) * i + 1,
        "–",
        Math.min(E * i, R.length),
        " of ",
        R.length
      ] }),
      /* @__PURE__ */ m.jsxs("div", { className: "flex gap-1", children: [
        /* @__PURE__ */ m.jsx(
          "button",
          {
            type: "button",
            disabled: E <= 1,
            onClick: () => _(E - 1),
            className: "inline-flex h-8 items-center justify-center rounded-md border px-3 text-sm disabled:opacity-50 hover:bg-accent",
            children: "Previous"
          }
        ),
        O.map((M) => /* @__PURE__ */ m.jsx(
          "button",
          {
            type: "button",
            onClick: () => _(M),
            className: D(
              "inline-flex h-8 w-8 items-center justify-center rounded-md border text-sm",
              E === M ? "border-primary bg-primary text-primary-foreground" : "hover:bg-accent"
            ),
            children: M
          },
          M
        )),
        /* @__PURE__ */ m.jsx(
          "button",
          {
            type: "button",
            disabled: E >= T,
            onClick: () => _(E + 1),
            className: "inline-flex h-8 items-center justify-center rounded-md border px-3 text-sm disabled:opacity-50 hover:bg-accent",
            children: "Next"
          }
        )
      ] })
    ] })
  ] });
}
function mb({
  id: e,
  className: t,
  src: n,
  alt: r = "",
  fallback: o,
  size: s = "md",
  "data-refast-id": a
}) {
  const i = {
    sm: "h-8 w-8",
    md: "h-10 w-10",
    lg: "h-12 w-12"
  }, [l, c] = P.useState(!1);
  return /* @__PURE__ */ m.jsx(
    "span",
    {
      id: e,
      className: D(
        "relative flex shrink-0 overflow-hidden rounded-full",
        i[s],
        t
      ),
      "data-refast-id": a,
      children: n && !l ? /* @__PURE__ */ m.jsx(
        "img",
        {
          src: n,
          alt: r,
          className: "aspect-square h-full w-full",
          onError: () => c(!0)
        }
      ) : /* @__PURE__ */ m.jsx("span", { className: "flex h-full w-full items-center justify-center rounded-full bg-muted text-sm font-medium uppercase", children: o || (r == null ? void 0 : r.charAt(0)) || "?" })
    }
  );
}
function hb({
  id: e,
  className: t,
  src: n,
  alt: r = "",
  width: o,
  height: s,
  objectFit: a = "cover",
  loading: i = !1,
  fallbackSrc: l,
  fallback: c,
  "data-refast-id": d
}) {
  const [f, p] = P.useState(i), [u, g] = P.useState(!1), [b, x] = P.useState(n);
  P.useEffect(() => {
    x(n), g(!1), i && p(!0);
  }, [n, i]);
  const v = () => {
    p(!1);
  }, y = () => {
    l && b !== l ? (x(l), g(!1)) : (g(!0), p(!1));
  }, S = {
    width: typeof o == "number" ? `${o}px` : o,
    height: typeof s == "number" ? `${s}px` : s,
    objectFit: a
  };
  return u && c ? /* @__PURE__ */ m.jsx(m.Fragment, { children: c }) : u && !l ? /* @__PURE__ */ m.jsx(
    "div",
    {
      id: e,
      className: D(
        "flex items-center justify-center rounded-md bg-muted text-muted-foreground",
        t
      ),
      style: S,
      "data-refast-id": d,
      children: /* @__PURE__ */ m.jsxs(
        "svg",
        {
          xmlns: "http://www.w3.org/2000/svg",
          width: "24",
          height: "24",
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: "currentColor",
          strokeWidth: "2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          className: "opacity-50",
          children: [
            /* @__PURE__ */ m.jsx("rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", ry: "2" }),
            /* @__PURE__ */ m.jsx("circle", { cx: "9", cy: "9", r: "2" }),
            /* @__PURE__ */ m.jsx("path", { d: "m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" })
          ]
        }
      )
    }
  ) : /* @__PURE__ */ m.jsxs("div", { className: "relative inline-block", style: S, children: [
    f && /* @__PURE__ */ m.jsx(
      "div",
      {
        className: D(
          "absolute inset-0 animate-pulse rounded-md bg-muted",
          t
        ),
        style: S
      }
    ),
    /* @__PURE__ */ m.jsx(
      "img",
      {
        id: e,
        src: b,
        alt: r,
        className: D(
          "rounded-md",
          f && "invisible",
          t
        ),
        style: S,
        onLoad: v,
        onError: y,
        "data-refast-id": d
      }
    )
  ] });
}
function gb({
  id: e,
  className: t,
  content: n,
  side: r = "top",
  sideOffset: o,
  children: s,
  "data-refast-id": a
}) {
  const i = P.Children.count(s) === 1 && P.isValidElement(s) ? P.cloneElement(s, { id: e, "data-refast-id": a }) : /* @__PURE__ */ m.jsx("span", { id: e, "data-refast-id": a, children: s });
  return /* @__PURE__ */ m.jsx(Og, { children: /* @__PURE__ */ m.jsxs(_g, { children: [
    /* @__PURE__ */ m.jsx($g, { asChild: !0, children: i }),
    /* @__PURE__ */ m.jsx(Fg, { children: /* @__PURE__ */ m.jsxs(
      Bg,
      {
        side: r,
        sideOffset: typeof o == "number" ? o : 4,
        className: D(
          "z-50 rounded-md bg-foreground text-background text-sm px-3 py-1.5 shadow-md animate-in fade-in-0 zoom-in-95",
          t
        ),
        children: [
          n,
          /* @__PURE__ */ m.jsx(Hg, { className: "fill-foreground" })
        ]
      }
    ) })
  ] }) });
}
const bb = P.createContext(null);
function vb({
  id: e,
  className: t,
  defaultValue: n = "",
  value: r,
  onValueChange: o,
  children: s,
  "data-refast-id": a
}) {
  const [i, l] = P.useState(r || n), c = P.Children.toArray(s), d = [];
  P.Children.forEach(s, (u) => {
    if (P.isValidElement(u)) {
      const g = u.props;
      let b, x, v;
      if ("tree" in g && typeof g.tree == "object" && g.tree !== null) {
        const y = g.tree.props || {};
        b = y.value, x = y.label, v = y.disabled;
      } else
        b = g.value, x = g.label, v = g.disabled;
      b !== void 0 && d.push({
        value: String(b || ""),
        label: String(x || b || ""),
        disabled: !!v
      });
    }
  }), P.useEffect(() => {
    !i && d.length > 0 && l(d[0].value);
  }, [i, d]);
  const f = (u) => {
    l(u), o == null || o(u);
  }, p = P.useMemo(
    () => ({ activeTab: i, setActiveTab: f }),
    [i]
  );
  return /* @__PURE__ */ m.jsx(bb.Provider, { value: p, children: /* @__PURE__ */ m.jsxs("div", { id: e, className: D("w-full", t), "data-refast-id": a, children: [
    /* @__PURE__ */ m.jsx("div", { className: "inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground", children: d.map((u) => {
      const g = i === u.value;
      return /* @__PURE__ */ m.jsx(
        "button",
        {
          type: "button",
          onClick: () => !u.disabled && f(u.value),
          disabled: u.disabled,
          className: D(
            "inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
            g ? "bg-background text-foreground shadow-sm" : "hover:bg-background/50"
          ),
          children: u.label
        },
        u.value
      );
    }) }),
    /* @__PURE__ */ m.jsx("div", { className: "mt-2", children: c.map((u, g) => {
      if (P.isValidElement(u)) {
        const b = u.props;
        let x;
        "tree" in b && typeof b.tree == "object" && b.tree !== null ? x = (b.tree.props || {}).value : x = b.value;
        const v = String(x || "");
        return v !== i ? null : /* @__PURE__ */ m.jsx(P.Fragment, { children: u }, v || g);
      }
      return null;
    }) })
  ] }) });
}
function xb({
  id: e,
  className: t,
  value: n,
  label: r,
  disabled: o = !1,
  children: s,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ m.jsx(
    "div",
    {
      id: e,
      className: D("ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", t),
      role: "tabpanel",
      "data-value": n,
      "data-label": r,
      "data-disabled": o,
      "data-refast-id": a,
      children: s
    }
  );
}
var yb = Symbol.for("react.lazy"), An = Dn[" use ".trim().toString()];
function wb(e) {
  return typeof e == "object" && e !== null && "then" in e;
}
function tl(e) {
  return e != null && typeof e == "object" && "$$typeof" in e && e.$$typeof === yb && "_payload" in e && wb(e._payload);
}
// @__NO_SIDE_EFFECTS__
function nl(e) {
  const t = /* @__PURE__ */ Cb(e), n = h.forwardRef((r, o) => {
    let { children: s, ...a } = r;
    tl(s) && typeof An == "function" && (s = An(s._payload));
    const i = h.Children.toArray(s), l = i.find(Eb);
    if (l) {
      const c = l.props.children, d = i.map((f) => f === l ? h.Children.count(c) > 1 ? h.Children.only(null) : h.isValidElement(c) ? c.props.children : null : f);
      return /* @__PURE__ */ m.jsx(t, { ...a, ref: o, children: h.isValidElement(c) ? h.cloneElement(c, void 0, d) : null });
    }
    return /* @__PURE__ */ m.jsx(t, { ...a, ref: o, children: s });
  });
  return n.displayName = `${e}.Slot`, n;
}
// @__NO_SIDE_EFFECTS__
function Cb(e) {
  const t = h.forwardRef((n, r) => {
    let { children: o, ...s } = n;
    if (tl(o) && typeof An == "function" && (o = An(o._payload)), h.isValidElement(o)) {
      const a = Pb(o), i = kb(s, o.props);
      return o.type !== h.Fragment && (i.ref = r ? On(r, a) : a), h.cloneElement(o, i);
    }
    return h.Children.count(o) > 1 ? h.Children.only(null) : null;
  });
  return t.displayName = `${e}.SlotClone`, t;
}
var Sb = Symbol("radix.slottable");
function Eb(e) {
  return h.isValidElement(e) && typeof e.type == "function" && "__radixId" in e.type && e.type.__radixId === Sb;
}
function kb(e, t) {
  const n = { ...t };
  for (const r in t) {
    const o = e[r], s = t[r];
    /^on[A-Z]/.test(r) ? o && s ? n[r] = (...i) => {
      const l = s(...i);
      return o(...i), l;
    } : o && (n[r] = o) : r === "style" ? n[r] = { ...o, ...s } : r === "className" && (n[r] = [o, s].filter(Boolean).join(" "));
  }
  return { ...e, ...n };
}
function Pb(e) {
  var r, o;
  let t = (r = Object.getOwnPropertyDescriptor(e.props, "ref")) == null ? void 0 : r.get, n = t && "isReactWarning" in t && t.isReactWarning;
  return n ? e.ref : (t = (o = Object.getOwnPropertyDescriptor(e, "ref")) == null ? void 0 : o.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
var Rb = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "select",
  "span",
  "svg",
  "ul"
], Ab = Rb.reduce((e, t) => {
  const n = /* @__PURE__ */ nl(`Primitive.${t}`), r = h.forwardRef((o, s) => {
    const { asChild: a, ...i } = o, l = a ? n : t;
    return typeof window < "u" && (window[Symbol.for("radix-ui")] = !0), /* @__PURE__ */ m.jsx(l, { ...i, ref: s });
  });
  return r.displayName = `Primitive.${t}`, { ...e, [t]: r };
}, {}), Nb = "Separator", _s = "horizontal", Tb = ["horizontal", "vertical"], rl = h.forwardRef((e, t) => {
  const { decorative: n, orientation: r = _s, ...o } = e, s = jb(r) ? r : _s, i = n ? { role: "none" } : { "aria-orientation": s === "vertical" ? s : void 0, role: "separator" };
  return /* @__PURE__ */ m.jsx(
    Ab.div,
    {
      "data-orientation": s,
      ...i,
      ...o,
      ref: t
    }
  );
});
rl.displayName = Nb;
function jb(e) {
  return Tb.includes(e);
}
var Ib = rl, Mb = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "select",
  "span",
  "svg",
  "ul"
], Lb = Mb.reduce((e, t) => {
  const n = /* @__PURE__ */ nl(`Primitive.${t}`), r = h.forwardRef((o, s) => {
    const { asChild: a, ...i } = o, l = a ? n : t;
    return typeof window < "u" && (window[Symbol.for("radix-ui")] = !0), /* @__PURE__ */ m.jsx(l, { ...i, ref: s });
  });
  return r.displayName = `Primitive.${t}`, { ...e, [t]: r };
}, {}), Db = "AspectRatio", ol = h.forwardRef(
  (e, t) => {
    const { ratio: n = 1 / 1, style: r, ...o } = e;
    return /* @__PURE__ */ m.jsx(
      "div",
      {
        style: {
          // ensures inner element is contained
          position: "relative",
          // ensures padding bottom trick maths works
          width: "100%",
          paddingBottom: `${100 / n}%`
        },
        "data-radix-aspect-ratio-wrapper": "",
        children: /* @__PURE__ */ m.jsx(
          Lb.div,
          {
            ...o,
            ref: t,
            style: {
              ...r,
              // ensures children expand in ratio
              position: "absolute",
              top: 0,
              right: 0,
              bottom: 0,
              left: 0
            }
          }
        )
      }
    );
  }
);
ol.displayName = Db;
var zb = ol;
function Ob(e, [t, n]) {
  return Math.min(n, Math.max(t, e));
}
function _b(e, t) {
  return h.useReducer((n, r) => t[n][r] ?? n, e);
}
var po = "ScrollArea", [sl] = We(po), [$b, Ae] = sl(po), al = h.forwardRef(
  (e, t) => {
    const {
      __scopeScrollArea: n,
      type: r = "hover",
      dir: o,
      scrollHideDelay: s = 600,
      ...a
    } = e, [i, l] = h.useState(null), [c, d] = h.useState(null), [f, p] = h.useState(null), [u, g] = h.useState(null), [b, x] = h.useState(null), [v, y] = h.useState(0), [S, C] = h.useState(0), [k, E] = h.useState(!1), [w, R] = h.useState(!1), T = pe(t, (A) => l(A)), I = Fn(o);
    return /* @__PURE__ */ m.jsx(
      $b,
      {
        scope: n,
        type: r,
        dir: I,
        scrollHideDelay: s,
        scrollArea: i,
        viewport: c,
        onViewportChange: d,
        content: f,
        onContentChange: p,
        scrollbarX: u,
        onScrollbarXChange: g,
        scrollbarXEnabled: k,
        onScrollbarXEnabledChange: E,
        scrollbarY: b,
        onScrollbarYChange: x,
        scrollbarYEnabled: w,
        onScrollbarYEnabledChange: R,
        onCornerWidthChange: y,
        onCornerHeightChange: C,
        children: /* @__PURE__ */ m.jsx(
          le.div,
          {
            dir: I,
            ...a,
            ref: T,
            style: {
              position: "relative",
              // Pass corner sizes as CSS vars to reduce re-renders of context consumers
              "--radix-scroll-area-corner-width": v + "px",
              "--radix-scroll-area-corner-height": S + "px",
              ...e.style
            }
          }
        )
      }
    );
  }
);
al.displayName = po;
var il = "ScrollAreaViewport", ll = h.forwardRef(
  (e, t) => {
    const { __scopeScrollArea: n, children: r, nonce: o, ...s } = e, a = Ae(il, n), i = h.useRef(null), l = pe(t, i, a.onViewportChange);
    return /* @__PURE__ */ m.jsxs(m.Fragment, { children: [
      /* @__PURE__ */ m.jsx(
        "style",
        {
          dangerouslySetInnerHTML: {
            __html: "[data-radix-scroll-area-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-scroll-area-viewport]::-webkit-scrollbar{display:none}"
          },
          nonce: o
        }
      ),
      /* @__PURE__ */ m.jsx(
        le.div,
        {
          "data-radix-scroll-area-viewport": "",
          ...s,
          ref: l,
          style: {
            /**
             * We don't support `visible` because the intention is to have at least one scrollbar
             * if this component is used and `visible` will behave like `auto` in that case
             * https://developer.mozilla.org/en-US/docs/Web/CSS/overflow#description
             *
             * We don't handle `auto` because the intention is for the native implementation
             * to be hidden if using this component. We just want to ensure the node is scrollable
             * so could have used either `scroll` or `auto` here. We picked `scroll` to prevent
             * the browser from having to work out whether to render native scrollbars or not,
             * we tell it to with the intention of hiding them in CSS.
             */
            overflowX: a.scrollbarXEnabled ? "scroll" : "hidden",
            overflowY: a.scrollbarYEnabled ? "scroll" : "hidden",
            ...e.style
          },
          children: /* @__PURE__ */ m.jsx("div", { ref: a.onContentChange, style: { minWidth: "100%", display: "table" }, children: r })
        }
      )
    ] });
  }
);
ll.displayName = il;
var Ke = "ScrollAreaScrollbar", cl = h.forwardRef(
  (e, t) => {
    const { forceMount: n, ...r } = e, o = Ae(Ke, e.__scopeScrollArea), { onScrollbarXEnabledChange: s, onScrollbarYEnabledChange: a } = o, i = e.orientation === "horizontal";
    return h.useEffect(() => (i ? s(!0) : a(!0), () => {
      i ? s(!1) : a(!1);
    }), [i, s, a]), o.type === "hover" ? /* @__PURE__ */ m.jsx(Fb, { ...r, ref: t, forceMount: n }) : o.type === "scroll" ? /* @__PURE__ */ m.jsx(Bb, { ...r, ref: t, forceMount: n }) : o.type === "auto" ? /* @__PURE__ */ m.jsx(ul, { ...r, ref: t, forceMount: n }) : o.type === "always" ? /* @__PURE__ */ m.jsx(mo, { ...r, ref: t }) : null;
  }
);
cl.displayName = Ke;
var Fb = h.forwardRef((e, t) => {
  const { forceMount: n, ...r } = e, o = Ae(Ke, e.__scopeScrollArea), [s, a] = h.useState(!1);
  return h.useEffect(() => {
    const i = o.scrollArea;
    let l = 0;
    if (i) {
      const c = () => {
        window.clearTimeout(l), a(!0);
      }, d = () => {
        l = window.setTimeout(() => a(!1), o.scrollHideDelay);
      };
      return i.addEventListener("pointerenter", c), i.addEventListener("pointerleave", d), () => {
        window.clearTimeout(l), i.removeEventListener("pointerenter", c), i.removeEventListener("pointerleave", d);
      };
    }
  }, [o.scrollArea, o.scrollHideDelay]), /* @__PURE__ */ m.jsx(Ge, { present: n || s, children: /* @__PURE__ */ m.jsx(
    ul,
    {
      "data-state": s ? "visible" : "hidden",
      ...r,
      ref: t
    }
  ) });
}), Bb = h.forwardRef((e, t) => {
  const { forceMount: n, ...r } = e, o = Ae(Ke, e.__scopeScrollArea), s = e.orientation === "horizontal", a = Qn(() => l("SCROLL_END"), 100), [i, l] = _b("hidden", {
    hidden: {
      SCROLL: "scrolling"
    },
    scrolling: {
      SCROLL_END: "idle",
      POINTER_ENTER: "interacting"
    },
    interacting: {
      SCROLL: "interacting",
      POINTER_LEAVE: "idle"
    },
    idle: {
      HIDE: "hidden",
      SCROLL: "scrolling",
      POINTER_ENTER: "interacting"
    }
  });
  return h.useEffect(() => {
    if (i === "idle") {
      const c = window.setTimeout(() => l("HIDE"), o.scrollHideDelay);
      return () => window.clearTimeout(c);
    }
  }, [i, o.scrollHideDelay, l]), h.useEffect(() => {
    const c = o.viewport, d = s ? "scrollLeft" : "scrollTop";
    if (c) {
      let f = c[d];
      const p = () => {
        const u = c[d];
        f !== u && (l("SCROLL"), a()), f = u;
      };
      return c.addEventListener("scroll", p), () => c.removeEventListener("scroll", p);
    }
  }, [o.viewport, s, l, a]), /* @__PURE__ */ m.jsx(Ge, { present: n || i !== "hidden", children: /* @__PURE__ */ m.jsx(
    mo,
    {
      "data-state": i === "hidden" ? "hidden" : "visible",
      ...r,
      ref: t,
      onPointerEnter: ae(e.onPointerEnter, () => l("POINTER_ENTER")),
      onPointerLeave: ae(e.onPointerLeave, () => l("POINTER_LEAVE"))
    }
  ) });
}), ul = h.forwardRef((e, t) => {
  const n = Ae(Ke, e.__scopeScrollArea), { forceMount: r, ...o } = e, [s, a] = h.useState(!1), i = e.orientation === "horizontal", l = Qn(() => {
    if (n.viewport) {
      const c = n.viewport.offsetWidth < n.viewport.scrollWidth, d = n.viewport.offsetHeight < n.viewport.scrollHeight;
      a(i ? c : d);
    }
  }, 10);
  return Mt(n.viewport, l), Mt(n.content, l), /* @__PURE__ */ m.jsx(Ge, { present: r || s, children: /* @__PURE__ */ m.jsx(
    mo,
    {
      "data-state": s ? "visible" : "hidden",
      ...o,
      ref: t
    }
  ) });
}), mo = h.forwardRef((e, t) => {
  const { orientation: n = "vertical", ...r } = e, o = Ae(Ke, e.__scopeScrollArea), s = h.useRef(null), a = h.useRef(0), [i, l] = h.useState({
    content: 0,
    viewport: 0,
    scrollbar: { size: 0, paddingStart: 0, paddingEnd: 0 }
  }), c = hl(i.viewport, i.content), d = {
    ...r,
    sizes: i,
    onSizesChange: l,
    hasThumb: c > 0 && c < 1,
    onThumbChange: (p) => s.current = p,
    onThumbPointerUp: () => a.current = 0,
    onThumbPointerDown: (p) => a.current = p
  };
  function f(p, u) {
    return Kb(p, a.current, i, u);
  }
  return n === "horizontal" ? /* @__PURE__ */ m.jsx(
    Hb,
    {
      ...d,
      ref: t,
      onThumbPositionChange: () => {
        if (o.viewport && s.current) {
          const p = o.viewport.scrollLeft, u = $s(p, i, o.dir);
          s.current.style.transform = `translate3d(${u}px, 0, 0)`;
        }
      },
      onWheelScroll: (p) => {
        o.viewport && (o.viewport.scrollLeft = p);
      },
      onDragScroll: (p) => {
        o.viewport && (o.viewport.scrollLeft = f(p, o.dir));
      }
    }
  ) : n === "vertical" ? /* @__PURE__ */ m.jsx(
    Vb,
    {
      ...d,
      ref: t,
      onThumbPositionChange: () => {
        if (o.viewport && s.current) {
          const p = o.viewport.scrollTop, u = $s(p, i);
          s.current.style.transform = `translate3d(0, ${u}px, 0)`;
        }
      },
      onWheelScroll: (p) => {
        o.viewport && (o.viewport.scrollTop = p);
      },
      onDragScroll: (p) => {
        o.viewport && (o.viewport.scrollTop = f(p));
      }
    }
  ) : null;
}), Hb = h.forwardRef((e, t) => {
  const { sizes: n, onSizesChange: r, ...o } = e, s = Ae(Ke, e.__scopeScrollArea), [a, i] = h.useState(), l = h.useRef(null), c = pe(t, l, s.onScrollbarXChange);
  return h.useEffect(() => {
    l.current && i(getComputedStyle(l.current));
  }, [l]), /* @__PURE__ */ m.jsx(
    fl,
    {
      "data-orientation": "horizontal",
      ...o,
      ref: c,
      sizes: n,
      style: {
        bottom: 0,
        left: s.dir === "rtl" ? "var(--radix-scroll-area-corner-width)" : 0,
        right: s.dir === "ltr" ? "var(--radix-scroll-area-corner-width)" : 0,
        "--radix-scroll-area-thumb-width": Zn(n) + "px",
        ...e.style
      },
      onThumbPointerDown: (d) => e.onThumbPointerDown(d.x),
      onDragScroll: (d) => e.onDragScroll(d.x),
      onWheelScroll: (d, f) => {
        if (s.viewport) {
          const p = s.viewport.scrollLeft + d.deltaX;
          e.onWheelScroll(p), bl(p, f) && d.preventDefault();
        }
      },
      onResize: () => {
        l.current && s.viewport && a && r({
          content: s.viewport.scrollWidth,
          viewport: s.viewport.offsetWidth,
          scrollbar: {
            size: l.current.clientWidth,
            paddingStart: Tn(a.paddingLeft),
            paddingEnd: Tn(a.paddingRight)
          }
        });
      }
    }
  );
}), Vb = h.forwardRef((e, t) => {
  const { sizes: n, onSizesChange: r, ...o } = e, s = Ae(Ke, e.__scopeScrollArea), [a, i] = h.useState(), l = h.useRef(null), c = pe(t, l, s.onScrollbarYChange);
  return h.useEffect(() => {
    l.current && i(getComputedStyle(l.current));
  }, [l]), /* @__PURE__ */ m.jsx(
    fl,
    {
      "data-orientation": "vertical",
      ...o,
      ref: c,
      sizes: n,
      style: {
        top: 0,
        right: s.dir === "ltr" ? 0 : void 0,
        left: s.dir === "rtl" ? 0 : void 0,
        bottom: "var(--radix-scroll-area-corner-height)",
        "--radix-scroll-area-thumb-height": Zn(n) + "px",
        ...e.style
      },
      onThumbPointerDown: (d) => e.onThumbPointerDown(d.y),
      onDragScroll: (d) => e.onDragScroll(d.y),
      onWheelScroll: (d, f) => {
        if (s.viewport) {
          const p = s.viewport.scrollTop + d.deltaY;
          e.onWheelScroll(p), bl(p, f) && d.preventDefault();
        }
      },
      onResize: () => {
        l.current && s.viewport && a && r({
          content: s.viewport.scrollHeight,
          viewport: s.viewport.offsetHeight,
          scrollbar: {
            size: l.current.clientHeight,
            paddingStart: Tn(a.paddingTop),
            paddingEnd: Tn(a.paddingBottom)
          }
        });
      }
    }
  );
}), [Wb, dl] = sl(Ke), fl = h.forwardRef((e, t) => {
  const {
    __scopeScrollArea: n,
    sizes: r,
    hasThumb: o,
    onThumbChange: s,
    onThumbPointerUp: a,
    onThumbPointerDown: i,
    onThumbPositionChange: l,
    onDragScroll: c,
    onWheelScroll: d,
    onResize: f,
    ...p
  } = e, u = Ae(Ke, n), [g, b] = h.useState(null), x = pe(t, (T) => b(T)), v = h.useRef(null), y = h.useRef(""), S = u.viewport, C = r.content - r.viewport, k = Re(d), E = Re(l), w = Qn(f, 10);
  function R(T) {
    if (v.current) {
      const I = T.clientX - v.current.left, A = T.clientY - v.current.top;
      c({ x: I, y: A });
    }
  }
  return h.useEffect(() => {
    const T = (I) => {
      const A = I.target;
      (g == null ? void 0 : g.contains(A)) && k(I, C);
    };
    return document.addEventListener("wheel", T, { passive: !1 }), () => document.removeEventListener("wheel", T, { passive: !1 });
  }, [S, g, C, k]), h.useEffect(E, [r, E]), Mt(g, w), Mt(u.content, w), /* @__PURE__ */ m.jsx(
    Wb,
    {
      scope: n,
      scrollbar: g,
      hasThumb: o,
      onThumbChange: Re(s),
      onThumbPointerUp: Re(a),
      onThumbPositionChange: E,
      onThumbPointerDown: Re(i),
      children: /* @__PURE__ */ m.jsx(
        le.div,
        {
          ...p,
          ref: x,
          style: { position: "absolute", ...p.style },
          onPointerDown: ae(e.onPointerDown, (T) => {
            T.button === 0 && (T.target.setPointerCapture(T.pointerId), v.current = g.getBoundingClientRect(), y.current = document.body.style.webkitUserSelect, document.body.style.webkitUserSelect = "none", u.viewport && (u.viewport.style.scrollBehavior = "auto"), R(T));
          }),
          onPointerMove: ae(e.onPointerMove, R),
          onPointerUp: ae(e.onPointerUp, (T) => {
            const I = T.target;
            I.hasPointerCapture(T.pointerId) && I.releasePointerCapture(T.pointerId), document.body.style.webkitUserSelect = y.current, u.viewport && (u.viewport.style.scrollBehavior = ""), v.current = null;
          })
        }
      )
    }
  );
}), Nn = "ScrollAreaThumb", pl = h.forwardRef(
  (e, t) => {
    const { forceMount: n, ...r } = e, o = dl(Nn, e.__scopeScrollArea);
    return /* @__PURE__ */ m.jsx(Ge, { present: n || o.hasThumb, children: /* @__PURE__ */ m.jsx(Gb, { ref: t, ...r }) });
  }
), Gb = h.forwardRef(
  (e, t) => {
    const { __scopeScrollArea: n, style: r, ...o } = e, s = Ae(Nn, n), a = dl(Nn, n), { onThumbPositionChange: i } = a, l = pe(
      t,
      (f) => a.onThumbChange(f)
    ), c = h.useRef(void 0), d = Qn(() => {
      c.current && (c.current(), c.current = void 0);
    }, 100);
    return h.useEffect(() => {
      const f = s.viewport;
      if (f) {
        const p = () => {
          if (d(), !c.current) {
            const u = Yb(f, i);
            c.current = u, i();
          }
        };
        return i(), f.addEventListener("scroll", p), () => f.removeEventListener("scroll", p);
      }
    }, [s.viewport, d, i]), /* @__PURE__ */ m.jsx(
      le.div,
      {
        "data-state": a.hasThumb ? "visible" : "hidden",
        ...o,
        ref: l,
        style: {
          width: "var(--radix-scroll-area-thumb-width)",
          height: "var(--radix-scroll-area-thumb-height)",
          ...r
        },
        onPointerDownCapture: ae(e.onPointerDownCapture, (f) => {
          const u = f.target.getBoundingClientRect(), g = f.clientX - u.left, b = f.clientY - u.top;
          a.onThumbPointerDown({ x: g, y: b });
        }),
        onPointerUp: ae(e.onPointerUp, a.onThumbPointerUp)
      }
    );
  }
);
pl.displayName = Nn;
var ho = "ScrollAreaCorner", ml = h.forwardRef(
  (e, t) => {
    const n = Ae(ho, e.__scopeScrollArea), r = !!(n.scrollbarX && n.scrollbarY);
    return n.type !== "scroll" && r ? /* @__PURE__ */ m.jsx(Ub, { ...e, ref: t }) : null;
  }
);
ml.displayName = ho;
var Ub = h.forwardRef((e, t) => {
  const { __scopeScrollArea: n, ...r } = e, o = Ae(ho, n), [s, a] = h.useState(0), [i, l] = h.useState(0), c = !!(s && i);
  return Mt(o.scrollbarX, () => {
    var f;
    const d = ((f = o.scrollbarX) == null ? void 0 : f.offsetHeight) || 0;
    o.onCornerHeightChange(d), l(d);
  }), Mt(o.scrollbarY, () => {
    var f;
    const d = ((f = o.scrollbarY) == null ? void 0 : f.offsetWidth) || 0;
    o.onCornerWidthChange(d), a(d);
  }), c ? /* @__PURE__ */ m.jsx(
    le.div,
    {
      ...r,
      ref: t,
      style: {
        width: s,
        height: i,
        position: "absolute",
        right: o.dir === "ltr" ? 0 : void 0,
        left: o.dir === "rtl" ? 0 : void 0,
        bottom: 0,
        ...e.style
      }
    }
  ) : null;
});
function Tn(e) {
  return e ? parseInt(e, 10) : 0;
}
function hl(e, t) {
  const n = e / t;
  return isNaN(n) ? 0 : n;
}
function Zn(e) {
  const t = hl(e.viewport, e.content), n = e.scrollbar.paddingStart + e.scrollbar.paddingEnd, r = (e.scrollbar.size - n) * t;
  return Math.max(r, 18);
}
function Kb(e, t, n, r = "ltr") {
  const o = Zn(n), s = o / 2, a = t || s, i = o - a, l = n.scrollbar.paddingStart + a, c = n.scrollbar.size - n.scrollbar.paddingEnd - i, d = n.content - n.viewport, f = r === "ltr" ? [0, d] : [d * -1, 0];
  return gl([l, c], f)(e);
}
function $s(e, t, n = "ltr") {
  const r = Zn(t), o = t.scrollbar.paddingStart + t.scrollbar.paddingEnd, s = t.scrollbar.size - o, a = t.content - t.viewport, i = s - r, l = n === "ltr" ? [0, a] : [a * -1, 0], c = Ob(e, l);
  return gl([0, a], [0, i])(c);
}
function gl(e, t) {
  return (n) => {
    if (e[0] === e[1] || t[0] === t[1]) return t[0];
    const r = (t[1] - t[0]) / (e[1] - e[0]);
    return t[0] + r * (n - e[0]);
  };
}
function bl(e, t) {
  return e > 0 && e < t;
}
var Yb = (e, t = () => {
}) => {
  let n = { left: e.scrollLeft, top: e.scrollTop }, r = 0;
  return function o() {
    const s = { left: e.scrollLeft, top: e.scrollTop }, a = n.left !== s.left, i = n.top !== s.top;
    (a || i) && t(), n = s, r = window.requestAnimationFrame(o);
  }(), () => window.cancelAnimationFrame(r);
};
function Qn(e, t) {
  const n = Re(e), r = h.useRef(0);
  return h.useEffect(() => () => window.clearTimeout(r.current), []), h.useCallback(() => {
    window.clearTimeout(r.current), r.current = window.setTimeout(n, t);
  }, [n, t]);
}
function Mt(e, t) {
  const n = Re(t);
  He(() => {
    let r = 0;
    if (e) {
      const o = new ResizeObserver(() => {
        cancelAnimationFrame(r), r = window.requestAnimationFrame(n);
      });
      return o.observe(e), () => {
        window.cancelAnimationFrame(r), o.unobserve(e);
      };
    }
  }, [e, n]);
}
var Xb = al, qb = ll, Fs = cl, Bs = pl, Jb = ml;
const er = h.createContext(null);
er.displayName = "PanelGroupContext";
const me = {
  group: "data-panel-group",
  groupDirection: "data-panel-group-direction",
  groupId: "data-panel-group-id",
  panel: "data-panel",
  panelCollapsible: "data-panel-collapsible",
  panelId: "data-panel-id",
  panelSize: "data-panel-size",
  resizeHandle: "data-resize-handle",
  resizeHandleActive: "data-resize-handle-active",
  resizeHandleEnabled: "data-panel-resize-handle-enabled",
  resizeHandleId: "data-panel-resize-handle-id",
  resizeHandleState: "data-resize-handle-state"
}, go = 10, bt = h.useLayoutEffect, Hs = Dn.useId, Zb = typeof Hs == "function" ? Hs : () => null;
let Qb = 0;
function bo(e = null) {
  const t = Zb(), n = h.useRef(e || t || null);
  return n.current === null && (n.current = "" + Qb++), e ?? n.current;
}
function vl({
  children: e,
  className: t = "",
  collapsedSize: n,
  collapsible: r,
  defaultSize: o,
  forwardedRef: s,
  id: a,
  maxSize: i,
  minSize: l,
  onCollapse: c,
  onExpand: d,
  onResize: f,
  order: p,
  style: u,
  tagName: g = "div",
  ...b
}) {
  const x = h.useContext(er);
  if (x === null)
    throw Error("Panel components must be rendered within a PanelGroup container");
  const {
    collapsePanel: v,
    expandPanel: y,
    getPanelSize: S,
    getPanelStyle: C,
    groupId: k,
    isPanelCollapsed: E,
    reevaluatePanelConstraints: w,
    registerPanel: R,
    resizePanel: T,
    unregisterPanel: I
  } = x, A = bo(a), N = h.useRef({
    callbacks: {
      onCollapse: c,
      onExpand: d,
      onResize: f
    },
    constraints: {
      collapsedSize: n,
      collapsible: r,
      defaultSize: o,
      maxSize: i,
      minSize: l
    },
    id: A,
    idIsFromProps: a !== void 0,
    order: p
  });
  h.useRef({
    didLogMissingDefaultSizeWarning: !1
  }), bt(() => {
    const {
      callbacks: O,
      constraints: M
    } = N.current, L = {
      ...M
    };
    N.current.id = A, N.current.idIsFromProps = a !== void 0, N.current.order = p, O.onCollapse = c, O.onExpand = d, O.onResize = f, M.collapsedSize = n, M.collapsible = r, M.defaultSize = o, M.maxSize = i, M.minSize = l, (L.collapsedSize !== M.collapsedSize || L.collapsible !== M.collapsible || L.maxSize !== M.maxSize || L.minSize !== M.minSize) && w(N.current, L);
  }), bt(() => {
    const O = N.current;
    return R(O), () => {
      I(O);
    };
  }, [p, A, R, I]), h.useImperativeHandle(s, () => ({
    collapse: () => {
      v(N.current);
    },
    expand: (O) => {
      y(N.current, O);
    },
    getId() {
      return A;
    },
    getSize() {
      return S(N.current);
    },
    isCollapsed() {
      return E(N.current);
    },
    isExpanded() {
      return !E(N.current);
    },
    resize: (O) => {
      T(N.current, O);
    }
  }), [v, y, S, E, A, T]);
  const _ = C(N.current, o);
  return h.createElement(g, {
    ...b,
    children: e,
    className: t,
    id: A,
    style: {
      ..._,
      ...u
    },
    // CSS selectors
    [me.groupId]: k,
    [me.panel]: "",
    [me.panelCollapsible]: r || void 0,
    [me.panelId]: A,
    [me.panelSize]: parseFloat("" + _.flexGrow).toFixed(1)
  });
}
const xl = h.forwardRef((e, t) => h.createElement(vl, {
  ...e,
  forwardedRef: t
}));
vl.displayName = "Panel";
xl.displayName = "forwardRef(Panel)";
let Lr = null, wn = -1, ct = null;
function ev(e, t) {
  if (t) {
    const n = (t & El) !== 0, r = (t & kl) !== 0, o = (t & Pl) !== 0, s = (t & Rl) !== 0;
    if (n)
      return o ? "se-resize" : s ? "ne-resize" : "e-resize";
    if (r)
      return o ? "sw-resize" : s ? "nw-resize" : "w-resize";
    if (o)
      return "s-resize";
    if (s)
      return "n-resize";
  }
  switch (e) {
    case "horizontal":
      return "ew-resize";
    case "intersection":
      return "move";
    case "vertical":
      return "ns-resize";
  }
}
function tv() {
  ct !== null && (document.head.removeChild(ct), Lr = null, ct = null, wn = -1);
}
function gr(e, t) {
  var n, r;
  const o = ev(e, t);
  if (Lr !== o) {
    if (Lr = o, ct === null && (ct = document.createElement("style"), document.head.appendChild(ct)), wn >= 0) {
      var s;
      (s = ct.sheet) === null || s === void 0 || s.removeRule(wn);
    }
    wn = (n = (r = ct.sheet) === null || r === void 0 ? void 0 : r.insertRule(`*{cursor: ${o} !important;}`)) !== null && n !== void 0 ? n : -1;
  }
}
function yl(e) {
  return e.type === "keydown";
}
function wl(e) {
  return e.type.startsWith("pointer");
}
function Cl(e) {
  return e.type.startsWith("mouse");
}
function tr(e) {
  if (wl(e)) {
    if (e.isPrimary)
      return {
        x: e.clientX,
        y: e.clientY
      };
  } else if (Cl(e))
    return {
      x: e.clientX,
      y: e.clientY
    };
  return {
    x: 1 / 0,
    y: 1 / 0
  };
}
function nv() {
  if (typeof matchMedia == "function")
    return matchMedia("(pointer:coarse)").matches ? "coarse" : "fine";
}
function rv(e, t, n) {
  return e.x < t.x + t.width && e.x + e.width > t.x && e.y < t.y + t.height && e.y + e.height > t.y;
}
function ov(e, t) {
  if (e === t) throw new Error("Cannot compare node with itself");
  const n = {
    a: Gs(e),
    b: Gs(t)
  };
  let r;
  for (; n.a.at(-1) === n.b.at(-1); )
    e = n.a.pop(), t = n.b.pop(), r = e;
  ne(r, "Stacking order can only be calculated for elements with a common ancestor");
  const o = {
    a: Ws(Vs(n.a)),
    b: Ws(Vs(n.b))
  };
  if (o.a === o.b) {
    const s = r.childNodes, a = {
      a: n.a.at(-1),
      b: n.b.at(-1)
    };
    let i = s.length;
    for (; i--; ) {
      const l = s[i];
      if (l === a.a) return 1;
      if (l === a.b) return -1;
    }
  }
  return Math.sign(o.a - o.b);
}
const sv = /\b(?:position|zIndex|opacity|transform|webkitTransform|mixBlendMode|filter|webkitFilter|isolation)\b/;
function av(e) {
  var t;
  const n = getComputedStyle((t = Sl(e)) !== null && t !== void 0 ? t : e).display;
  return n === "flex" || n === "inline-flex";
}
function iv(e) {
  const t = getComputedStyle(e);
  return !!(t.position === "fixed" || t.zIndex !== "auto" && (t.position !== "static" || av(e)) || +t.opacity < 1 || "transform" in t && t.transform !== "none" || "webkitTransform" in t && t.webkitTransform !== "none" || "mixBlendMode" in t && t.mixBlendMode !== "normal" || "filter" in t && t.filter !== "none" || "webkitFilter" in t && t.webkitFilter !== "none" || "isolation" in t && t.isolation === "isolate" || sv.test(t.willChange) || t.webkitOverflowScrolling === "touch");
}
function Vs(e) {
  let t = e.length;
  for (; t--; ) {
    const n = e[t];
    if (ne(n, "Missing node"), iv(n)) return n;
  }
  return null;
}
function Ws(e) {
  return e && Number(getComputedStyle(e).zIndex) || 0;
}
function Gs(e) {
  const t = [];
  for (; e; )
    t.push(e), e = Sl(e);
  return t;
}
function Sl(e) {
  const {
    parentNode: t
  } = e;
  return t && t instanceof ShadowRoot ? t.host : t;
}
const El = 1, kl = 2, Pl = 4, Rl = 8, lv = nv() === "coarse";
let De = [], Tt = !1, gt = /* @__PURE__ */ new Map(), nr = /* @__PURE__ */ new Map();
const Jt = /* @__PURE__ */ new Set();
function cv(e, t, n, r, o) {
  var s;
  const {
    ownerDocument: a
  } = t, i = {
    direction: n,
    element: t,
    hitAreaMargins: r,
    setResizeHandlerState: o
  }, l = (s = gt.get(a)) !== null && s !== void 0 ? s : 0;
  return gt.set(a, l + 1), Jt.add(i), jn(), function() {
    var d;
    nr.delete(e), Jt.delete(i);
    const f = (d = gt.get(a)) !== null && d !== void 0 ? d : 1;
    if (gt.set(a, f - 1), jn(), f === 1 && gt.delete(a), De.includes(i)) {
      const p = De.indexOf(i);
      p >= 0 && De.splice(p, 1), xo(), o("up", !0, null);
    }
  };
}
function uv(e) {
  const {
    target: t
  } = e, {
    x: n,
    y: r
  } = tr(e);
  Tt = !0, vo({
    target: t,
    x: n,
    y: r
  }), jn(), De.length > 0 && (In("down", e), e.preventDefault(), Al(t) || e.stopImmediatePropagation());
}
function br(e) {
  const {
    x: t,
    y: n
  } = tr(e);
  if (Tt && e.buttons === 0 && (Tt = !1, In("up", e)), !Tt) {
    const {
      target: r
    } = e;
    vo({
      target: r,
      x: t,
      y: n
    });
  }
  In("move", e), xo(), De.length > 0 && e.preventDefault();
}
function vr(e) {
  const {
    target: t
  } = e, {
    x: n,
    y: r
  } = tr(e);
  nr.clear(), Tt = !1, De.length > 0 && (e.preventDefault(), Al(t) || e.stopImmediatePropagation()), In("up", e), vo({
    target: t,
    x: n,
    y: r
  }), xo(), jn();
}
function Al(e) {
  let t = e;
  for (; t; ) {
    if (t.hasAttribute(me.resizeHandle))
      return !0;
    t = t.parentElement;
  }
  return !1;
}
function vo({
  target: e,
  x: t,
  y: n
}) {
  De.splice(0);
  let r = null;
  (e instanceof HTMLElement || e instanceof SVGElement) && (r = e), Jt.forEach((o) => {
    const {
      element: s,
      hitAreaMargins: a
    } = o, i = s.getBoundingClientRect(), {
      bottom: l,
      left: c,
      right: d,
      top: f
    } = i, p = lv ? a.coarse : a.fine;
    if (t >= c - p && t <= d + p && n >= f - p && n <= l + p) {
      if (r !== null && document.contains(r) && s !== r && !s.contains(r) && !r.contains(s) && // Calculating stacking order has a cost, so we should avoid it if possible
      // That is why we only check potentially intersecting handles,
      // and why we skip if the event target is within the handle's DOM
      ov(r, s) > 0) {
        let g = r, b = !1;
        for (; g && !g.contains(s); ) {
          if (rv(g.getBoundingClientRect(), i)) {
            b = !0;
            break;
          }
          g = g.parentElement;
        }
        if (b)
          return;
      }
      De.push(o);
    }
  });
}
function xr(e, t) {
  nr.set(e, t);
}
function xo() {
  let e = !1, t = !1;
  De.forEach((r) => {
    const {
      direction: o
    } = r;
    o === "horizontal" ? e = !0 : t = !0;
  });
  let n = 0;
  nr.forEach((r) => {
    n |= r;
  }), e && t ? gr("intersection", n) : e ? gr("horizontal", n) : t ? gr("vertical", n) : tv();
}
let yr = new AbortController();
function jn() {
  yr.abort(), yr = new AbortController();
  const e = {
    capture: !0,
    signal: yr.signal
  };
  Jt.size && (Tt ? (De.length > 0 && gt.forEach((t, n) => {
    const {
      body: r
    } = n;
    t > 0 && (r.addEventListener("contextmenu", vr, e), r.addEventListener("pointerleave", br, e), r.addEventListener("pointermove", br, e));
  }), window.addEventListener("pointerup", vr, e), window.addEventListener("pointercancel", vr, e)) : gt.forEach((t, n) => {
    const {
      body: r
    } = n;
    t > 0 && (r.addEventListener("pointerdown", uv, e), r.addEventListener("pointermove", br, e));
  }));
}
function In(e, t) {
  Jt.forEach((n) => {
    const {
      setResizeHandlerState: r
    } = n, o = De.includes(n);
    r(e, o, t);
  });
}
function dv() {
  const [e, t] = h.useState(0);
  return h.useCallback(() => t((n) => n + 1), []);
}
function ne(e, t) {
  if (!e)
    throw console.error(t), Error(t);
}
function yt(e, t, n = go) {
  return e.toFixed(n) === t.toFixed(n) ? 0 : e > t ? 1 : -1;
}
function Je(e, t, n = go) {
  return yt(e, t, n) === 0;
}
function Se(e, t, n) {
  return yt(e, t, n) === 0;
}
function fv(e, t, n) {
  if (e.length !== t.length)
    return !1;
  for (let r = 0; r < e.length; r++) {
    const o = e[r], s = t[r];
    if (!Se(o, s, n))
      return !1;
  }
  return !0;
}
function Rt({
  panelConstraints: e,
  panelIndex: t,
  size: n
}) {
  const r = e[t];
  ne(r != null, `Panel constraints not found for index ${t}`);
  let {
    collapsedSize: o = 0,
    collapsible: s,
    maxSize: a = 100,
    minSize: i = 0
  } = r;
  if (yt(n, i) < 0)
    if (s) {
      const l = (o + i) / 2;
      yt(n, l) < 0 ? n = o : n = i;
    } else
      n = i;
  return n = Math.min(a, n), n = parseFloat(n.toFixed(go)), n;
}
function Wt({
  delta: e,
  initialLayout: t,
  panelConstraints: n,
  pivotIndices: r,
  prevLayout: o,
  trigger: s
}) {
  if (Se(e, 0))
    return t;
  const a = [...t], [i, l] = r;
  ne(i != null, "Invalid first pivot index"), ne(l != null, "Invalid second pivot index");
  let c = 0;
  if (s === "keyboard") {
    {
      const f = e < 0 ? l : i, p = n[f];
      ne(p, `Panel constraints not found for index ${f}`);
      const {
        collapsedSize: u = 0,
        collapsible: g,
        minSize: b = 0
      } = p;
      if (g) {
        const x = t[f];
        if (ne(x != null, `Previous layout not found for panel index ${f}`), Se(x, u)) {
          const v = b - x;
          yt(v, Math.abs(e)) > 0 && (e = e < 0 ? 0 - v : v);
        }
      }
    }
    {
      const f = e < 0 ? i : l, p = n[f];
      ne(p, `No panel constraints found for index ${f}`);
      const {
        collapsedSize: u = 0,
        collapsible: g,
        minSize: b = 0
      } = p;
      if (g) {
        const x = t[f];
        if (ne(x != null, `Previous layout not found for panel index ${f}`), Se(x, b)) {
          const v = x - u;
          yt(v, Math.abs(e)) > 0 && (e = e < 0 ? 0 - v : v);
        }
      }
    }
  }
  {
    const f = e < 0 ? 1 : -1;
    let p = e < 0 ? l : i, u = 0;
    for (; ; ) {
      const b = t[p];
      ne(b != null, `Previous layout not found for panel index ${p}`);
      const v = Rt({
        panelConstraints: n,
        panelIndex: p,
        size: 100
      }) - b;
      if (u += v, p += f, p < 0 || p >= n.length)
        break;
    }
    const g = Math.min(Math.abs(e), Math.abs(u));
    e = e < 0 ? 0 - g : g;
  }
  {
    let p = e < 0 ? i : l;
    for (; p >= 0 && p < n.length; ) {
      const u = Math.abs(e) - Math.abs(c), g = t[p];
      ne(g != null, `Previous layout not found for panel index ${p}`);
      const b = g - u, x = Rt({
        panelConstraints: n,
        panelIndex: p,
        size: b
      });
      if (!Se(g, x) && (c += g - x, a[p] = x, c.toPrecision(3).localeCompare(Math.abs(e).toPrecision(3), void 0, {
        numeric: !0
      }) >= 0))
        break;
      e < 0 ? p-- : p++;
    }
  }
  if (fv(o, a))
    return o;
  {
    const f = e < 0 ? l : i, p = t[f];
    ne(p != null, `Previous layout not found for panel index ${f}`);
    const u = p + c, g = Rt({
      panelConstraints: n,
      panelIndex: f,
      size: u
    });
    if (a[f] = g, !Se(g, u)) {
      let b = u - g, v = e < 0 ? l : i;
      for (; v >= 0 && v < n.length; ) {
        const y = a[v];
        ne(y != null, `Previous layout not found for panel index ${v}`);
        const S = y + b, C = Rt({
          panelConstraints: n,
          panelIndex: v,
          size: S
        });
        if (Se(y, C) || (b -= C - y, a[v] = C), Se(b, 0))
          break;
        e > 0 ? v-- : v++;
      }
    }
  }
  const d = a.reduce((f, p) => p + f, 0);
  return Se(d, 100) ? a : o;
}
function pv({
  layout: e,
  panelsArray: t,
  pivotIndices: n
}) {
  let r = 0, o = 100, s = 0, a = 0;
  const i = n[0];
  ne(i != null, "No pivot index found"), t.forEach((f, p) => {
    const {
      constraints: u
    } = f, {
      maxSize: g = 100,
      minSize: b = 0
    } = u;
    p === i ? (r = b, o = g) : (s += b, a += g);
  });
  const l = Math.min(o, 100 - s), c = Math.max(r, 100 - a), d = e[i];
  return {
    valueMax: l,
    valueMin: c,
    valueNow: d
  };
}
function Zt(e, t = document) {
  return Array.from(t.querySelectorAll(`[${me.resizeHandleId}][data-panel-group-id="${e}"]`));
}
function Nl(e, t, n = document) {
  const o = Zt(e, n).findIndex((s) => s.getAttribute(me.resizeHandleId) === t);
  return o ?? null;
}
function Tl(e, t, n) {
  const r = Nl(e, t, n);
  return r != null ? [r, r + 1] : [-1, -1];
}
function jl(e, t = document) {
  var n;
  if (t instanceof HTMLElement && (t == null || (n = t.dataset) === null || n === void 0 ? void 0 : n.panelGroupId) == e)
    return t;
  const r = t.querySelector(`[data-panel-group][data-panel-group-id="${e}"]`);
  return r || null;
}
function rr(e, t = document) {
  const n = t.querySelector(`[${me.resizeHandleId}="${e}"]`);
  return n || null;
}
function mv(e, t, n, r = document) {
  var o, s, a, i;
  const l = rr(t, r), c = Zt(e, r), d = l ? c.indexOf(l) : -1, f = (o = (s = n[d]) === null || s === void 0 ? void 0 : s.id) !== null && o !== void 0 ? o : null, p = (a = (i = n[d + 1]) === null || i === void 0 ? void 0 : i.id) !== null && a !== void 0 ? a : null;
  return [f, p];
}
function hv({
  committedValuesRef: e,
  eagerValuesRef: t,
  groupId: n,
  layout: r,
  panelDataArray: o,
  panelGroupElement: s,
  setLayout: a
}) {
  h.useRef({
    didWarnAboutMissingResizeHandle: !1
  }), bt(() => {
    if (!s)
      return;
    const i = Zt(n, s);
    for (let l = 0; l < o.length - 1; l++) {
      const {
        valueMax: c,
        valueMin: d,
        valueNow: f
      } = pv({
        layout: r,
        panelsArray: o,
        pivotIndices: [l, l + 1]
      }), p = i[l];
      if (p != null) {
        const u = o[l];
        ne(u, `No panel data found for index "${l}"`), p.setAttribute("aria-controls", u.id), p.setAttribute("aria-valuemax", "" + Math.round(c)), p.setAttribute("aria-valuemin", "" + Math.round(d)), p.setAttribute("aria-valuenow", f != null ? "" + Math.round(f) : "");
      }
    }
    return () => {
      i.forEach((l, c) => {
        l.removeAttribute("aria-controls"), l.removeAttribute("aria-valuemax"), l.removeAttribute("aria-valuemin"), l.removeAttribute("aria-valuenow");
      });
    };
  }, [n, r, o, s]), h.useEffect(() => {
    if (!s)
      return;
    const i = t.current;
    ne(i, "Eager values not found");
    const {
      panelDataArray: l
    } = i, c = jl(n, s);
    ne(c != null, `No group found for id "${n}"`);
    const d = Zt(n, s);
    ne(d, `No resize handles found for group id "${n}"`);
    const f = d.map((p) => {
      const u = p.getAttribute(me.resizeHandleId);
      ne(u, "Resize handle element has no handle id attribute");
      const [g, b] = mv(n, u, l, s);
      if (g == null || b == null)
        return () => {
        };
      const x = (v) => {
        if (!v.defaultPrevented)
          switch (v.key) {
            case "Enter": {
              v.preventDefault();
              const y = l.findIndex((S) => S.id === g);
              if (y >= 0) {
                const S = l[y];
                ne(S, `No panel data found for index ${y}`);
                const C = r[y], {
                  collapsedSize: k = 0,
                  collapsible: E,
                  minSize: w = 0
                } = S.constraints;
                if (C != null && E) {
                  const R = Wt({
                    delta: Se(C, k) ? w - k : k - C,
                    initialLayout: r,
                    panelConstraints: l.map((T) => T.constraints),
                    pivotIndices: Tl(n, u, s),
                    prevLayout: r,
                    trigger: "keyboard"
                  });
                  r !== R && a(R);
                }
              }
              break;
            }
          }
      };
      return p.addEventListener("keydown", x), () => {
        p.removeEventListener("keydown", x);
      };
    });
    return () => {
      f.forEach((p) => p());
    };
  }, [s, e, t, n, r, o, a]);
}
function Us(e, t) {
  if (e.length !== t.length)
    return !1;
  for (let n = 0; n < e.length; n++)
    if (e[n] !== t[n])
      return !1;
  return !0;
}
function Il(e, t) {
  const n = e === "horizontal", {
    x: r,
    y: o
  } = tr(t);
  return n ? r : o;
}
function gv(e, t, n, r, o) {
  const s = n === "horizontal", a = rr(t, o);
  ne(a, `No resize handle element found for id "${t}"`);
  const i = a.getAttribute(me.groupId);
  ne(i, "Resize handle element has no group id attribute");
  let {
    initialCursorPosition: l
  } = r;
  const c = Il(n, e), d = jl(i, o);
  ne(d, `No group element found for id "${i}"`);
  const f = d.getBoundingClientRect(), p = s ? f.width : f.height;
  return (c - l) / p * 100;
}
function bv(e, t, n, r, o, s) {
  if (yl(e)) {
    const a = n === "horizontal";
    let i = 0;
    e.shiftKey ? i = 100 : o != null ? i = o : i = 10;
    let l = 0;
    switch (e.key) {
      case "ArrowDown":
        l = a ? 0 : i;
        break;
      case "ArrowLeft":
        l = a ? -i : 0;
        break;
      case "ArrowRight":
        l = a ? i : 0;
        break;
      case "ArrowUp":
        l = a ? 0 : -i;
        break;
      case "End":
        l = 100;
        break;
      case "Home":
        l = -100;
        break;
    }
    return l;
  } else
    return r == null ? 0 : gv(e, t, n, r, s);
}
function vv({
  panelDataArray: e
}) {
  const t = Array(e.length), n = e.map((s) => s.constraints);
  let r = 0, o = 100;
  for (let s = 0; s < e.length; s++) {
    const a = n[s];
    ne(a, `Panel constraints not found for index ${s}`);
    const {
      defaultSize: i
    } = a;
    i != null && (r++, t[s] = i, o -= i);
  }
  for (let s = 0; s < e.length; s++) {
    const a = n[s];
    ne(a, `Panel constraints not found for index ${s}`);
    const {
      defaultSize: i
    } = a;
    if (i != null)
      continue;
    const l = e.length - r, c = o / l;
    r++, t[s] = c, o -= c;
  }
  return t;
}
function kt(e, t, n) {
  t.forEach((r, o) => {
    const s = e[o];
    ne(s, `Panel data not found for index ${o}`);
    const {
      callbacks: a,
      constraints: i,
      id: l
    } = s, {
      collapsedSize: c = 0,
      collapsible: d
    } = i, f = n[l];
    if (f == null || r !== f) {
      n[l] = r;
      const {
        onCollapse: p,
        onExpand: u,
        onResize: g
      } = a;
      g && g(r, f), d && (p || u) && (u && (f == null || Je(f, c)) && !Je(r, c) && u(), p && (f == null || !Je(f, c)) && Je(r, c) && p());
    }
  });
}
function gn(e, t) {
  if (e.length !== t.length)
    return !1;
  for (let n = 0; n < e.length; n++)
    if (e[n] != t[n])
      return !1;
  return !0;
}
function xv({
  defaultSize: e,
  dragState: t,
  layout: n,
  panelData: r,
  panelIndex: o,
  precision: s = 3
}) {
  const a = n[o];
  let i;
  return a == null ? i = e != null ? e.toPrecision(s) : "1" : r.length === 1 ? i = "1" : i = a.toPrecision(s), {
    flexBasis: 0,
    flexGrow: i,
    flexShrink: 1,
    // Without this, Panel sizes may be unintentionally overridden by their content
    overflow: "hidden",
    // Disable pointer events inside of a panel during resize
    // This avoid edge cases like nested iframes
    pointerEvents: t !== null ? "none" : void 0
  };
}
function yv(e, t = 10) {
  let n = null;
  return (...o) => {
    n !== null && clearTimeout(n), n = setTimeout(() => {
      e(...o);
    }, t);
  };
}
function Ks(e) {
  try {
    if (typeof localStorage < "u")
      e.getItem = (t) => localStorage.getItem(t), e.setItem = (t, n) => {
        localStorage.setItem(t, n);
      };
    else
      throw new Error("localStorage not supported in this environment");
  } catch (t) {
    console.error(t), e.getItem = () => null, e.setItem = () => {
    };
  }
}
function Ml(e) {
  return `react-resizable-panels:${e}`;
}
function Ll(e) {
  return e.map((t) => {
    const {
      constraints: n,
      id: r,
      idIsFromProps: o,
      order: s
    } = t;
    return o ? r : s ? `${s}:${JSON.stringify(n)}` : JSON.stringify(n);
  }).sort((t, n) => t.localeCompare(n)).join(",");
}
function Dl(e, t) {
  try {
    const n = Ml(e), r = t.getItem(n);
    if (r) {
      const o = JSON.parse(r);
      if (typeof o == "object" && o != null)
        return o;
    }
  } catch {
  }
  return null;
}
function wv(e, t, n) {
  var r, o;
  const s = (r = Dl(e, n)) !== null && r !== void 0 ? r : {}, a = Ll(t);
  return (o = s[a]) !== null && o !== void 0 ? o : null;
}
function Cv(e, t, n, r, o) {
  var s;
  const a = Ml(e), i = Ll(t), l = (s = Dl(e, o)) !== null && s !== void 0 ? s : {};
  l[i] = {
    expandToSizes: Object.fromEntries(n.entries()),
    layout: r
  };
  try {
    o.setItem(a, JSON.stringify(l));
  } catch (c) {
    console.error(c);
  }
}
function Ys({
  layout: e,
  panelConstraints: t
}) {
  const n = [...e], r = n.reduce((s, a) => s + a, 0);
  if (n.length !== t.length)
    throw Error(`Invalid ${t.length} panel layout: ${n.map((s) => `${s}%`).join(", ")}`);
  if (!Se(r, 100) && n.length > 0)
    for (let s = 0; s < t.length; s++) {
      const a = n[s];
      ne(a != null, `No layout data found for index ${s}`);
      const i = 100 / r * a;
      n[s] = i;
    }
  let o = 0;
  for (let s = 0; s < t.length; s++) {
    const a = n[s];
    ne(a != null, `No layout data found for index ${s}`);
    const i = Rt({
      panelConstraints: t,
      panelIndex: s,
      size: a
    });
    a != i && (o += a - i, n[s] = i);
  }
  if (!Se(o, 0))
    for (let s = 0; s < t.length; s++) {
      const a = n[s];
      ne(a != null, `No layout data found for index ${s}`);
      const i = a + o, l = Rt({
        panelConstraints: t,
        panelIndex: s,
        size: i
      });
      if (a !== l && (o -= l - a, n[s] = l, Se(o, 0)))
        break;
    }
  return n;
}
const Sv = 100, Gt = {
  getItem: (e) => (Ks(Gt), Gt.getItem(e)),
  setItem: (e, t) => {
    Ks(Gt), Gt.setItem(e, t);
  }
}, Xs = {};
function zl({
  autoSaveId: e = null,
  children: t,
  className: n = "",
  direction: r,
  forwardedRef: o,
  id: s = null,
  onLayout: a = null,
  keyboardResizeBy: i = null,
  storage: l = Gt,
  style: c,
  tagName: d = "div",
  ...f
}) {
  const p = bo(s), u = h.useRef(null), [g, b] = h.useState(null), [x, v] = h.useState([]), y = dv(), S = h.useRef({}), C = h.useRef(/* @__PURE__ */ new Map()), k = h.useRef(0), E = h.useRef({
    autoSaveId: e,
    direction: r,
    dragState: g,
    id: p,
    keyboardResizeBy: i,
    onLayout: a,
    storage: l
  }), w = h.useRef({
    layout: x,
    panelDataArray: [],
    panelDataArrayChanged: !1
  });
  h.useRef({
    didLogIdAndOrderWarning: !1,
    didLogPanelConstraintsWarning: !1,
    prevPanelIds: []
  }), h.useImperativeHandle(o, () => ({
    getId: () => E.current.id,
    getLayout: () => {
      const {
        layout: j
      } = w.current;
      return j;
    },
    setLayout: (j) => {
      const {
        onLayout: F
      } = E.current, {
        layout: U,
        panelDataArray: K
      } = w.current, z = Ys({
        layout: j,
        panelConstraints: K.map((G) => G.constraints)
      });
      Us(U, z) || (v(z), w.current.layout = z, F && F(z), kt(K, z, S.current));
    }
  }), []), bt(() => {
    E.current.autoSaveId = e, E.current.direction = r, E.current.dragState = g, E.current.id = p, E.current.onLayout = a, E.current.storage = l;
  }), hv({
    committedValuesRef: E,
    eagerValuesRef: w,
    groupId: p,
    layout: x,
    panelDataArray: w.current.panelDataArray,
    setLayout: v,
    panelGroupElement: u.current
  }), h.useEffect(() => {
    const {
      panelDataArray: j
    } = w.current;
    if (e) {
      if (x.length === 0 || x.length !== j.length)
        return;
      let F = Xs[e];
      F == null && (F = yv(Cv, Sv), Xs[e] = F);
      const U = [...j], K = new Map(C.current);
      F(e, U, K, x, l);
    }
  }, [e, x, l]), h.useEffect(() => {
  });
  const R = h.useCallback((j) => {
    const {
      onLayout: F
    } = E.current, {
      layout: U,
      panelDataArray: K
    } = w.current;
    if (j.constraints.collapsible) {
      const z = K.map((Z) => Z.constraints), {
        collapsedSize: G = 0,
        panelSize: X,
        pivotIndices: Q
      } = ht(K, j, U);
      if (ne(X != null, `Panel size not found for panel "${j.id}"`), !Je(X, G)) {
        C.current.set(j.id, X);
        const H = Pt(K, j) === K.length - 1 ? X - G : G - X, Y = Wt({
          delta: H,
          initialLayout: U,
          panelConstraints: z,
          pivotIndices: Q,
          prevLayout: U,
          trigger: "imperative-api"
        });
        gn(U, Y) || (v(Y), w.current.layout = Y, F && F(Y), kt(K, Y, S.current));
      }
    }
  }, []), T = h.useCallback((j, F) => {
    const {
      onLayout: U
    } = E.current, {
      layout: K,
      panelDataArray: z
    } = w.current;
    if (j.constraints.collapsible) {
      const G = z.map((oe) => oe.constraints), {
        collapsedSize: X = 0,
        panelSize: Q = 0,
        minSize: Z = 0,
        pivotIndices: H
      } = ht(z, j, K), Y = F ?? Z;
      if (Je(Q, X)) {
        const oe = C.current.get(j.id), ue = oe != null && oe >= Y ? oe : Y, ve = Pt(z, j) === z.length - 1 ? Q - ue : ue - Q, ie = Wt({
          delta: ve,
          initialLayout: K,
          panelConstraints: G,
          pivotIndices: H,
          prevLayout: K,
          trigger: "imperative-api"
        });
        gn(K, ie) || (v(ie), w.current.layout = ie, U && U(ie), kt(z, ie, S.current));
      }
    }
  }, []), I = h.useCallback((j) => {
    const {
      layout: F,
      panelDataArray: U
    } = w.current, {
      panelSize: K
    } = ht(U, j, F);
    return ne(K != null, `Panel size not found for panel "${j.id}"`), K;
  }, []), A = h.useCallback((j, F) => {
    const {
      panelDataArray: U
    } = w.current, K = Pt(U, j);
    return xv({
      defaultSize: F,
      dragState: g,
      layout: x,
      panelData: U,
      panelIndex: K
    });
  }, [g, x]), N = h.useCallback((j) => {
    const {
      layout: F,
      panelDataArray: U
    } = w.current, {
      collapsedSize: K = 0,
      collapsible: z,
      panelSize: G
    } = ht(U, j, F);
    return ne(G != null, `Panel size not found for panel "${j.id}"`), z === !0 && Je(G, K);
  }, []), _ = h.useCallback((j) => {
    const {
      layout: F,
      panelDataArray: U
    } = w.current, {
      collapsedSize: K = 0,
      collapsible: z,
      panelSize: G
    } = ht(U, j, F);
    return ne(G != null, `Panel size not found for panel "${j.id}"`), !z || yt(G, K) > 0;
  }, []), O = h.useCallback((j) => {
    const {
      panelDataArray: F
    } = w.current;
    F.push(j), F.sort((U, K) => {
      const z = U.order, G = K.order;
      return z == null && G == null ? 0 : z == null ? -1 : G == null ? 1 : z - G;
    }), w.current.panelDataArrayChanged = !0, y();
  }, [y]);
  bt(() => {
    if (w.current.panelDataArrayChanged) {
      w.current.panelDataArrayChanged = !1;
      const {
        autoSaveId: j,
        onLayout: F,
        storage: U
      } = E.current, {
        layout: K,
        panelDataArray: z
      } = w.current;
      let G = null;
      if (j) {
        const Q = wv(j, z, U);
        Q && (C.current = new Map(Object.entries(Q.expandToSizes)), G = Q.layout);
      }
      G == null && (G = vv({
        panelDataArray: z
      }));
      const X = Ys({
        layout: G,
        panelConstraints: z.map((Q) => Q.constraints)
      });
      Us(K, X) || (v(X), w.current.layout = X, F && F(X), kt(z, X, S.current));
    }
  }), bt(() => {
    const j = w.current;
    return () => {
      j.layout = [];
    };
  }, []);
  const M = h.useCallback((j) => {
    let F = !1;
    const U = u.current;
    return U && window.getComputedStyle(U, null).getPropertyValue("direction") === "rtl" && (F = !0), function(z) {
      z.preventDefault();
      const G = u.current;
      if (!G)
        return () => null;
      const {
        direction: X,
        dragState: Q,
        id: Z,
        keyboardResizeBy: H,
        onLayout: Y
      } = E.current, {
        layout: oe,
        panelDataArray: ue
      } = w.current, {
        initialLayout: ge
      } = Q ?? {}, ve = Tl(Z, j, G);
      let ie = bv(z, j, X, Q, H, G);
      const be = X === "horizontal";
      be && F && (ie = -ie);
      const Pe = ue.map((Ce) => Ce.constraints), xe = Wt({
        delta: ie,
        initialLayout: ge ?? oe,
        panelConstraints: Pe,
        pivotIndices: ve,
        prevLayout: oe,
        trigger: yl(z) ? "keyboard" : "mouse-or-touch"
      }), Ye = !gn(oe, xe);
      (wl(z) || Cl(z)) && k.current != ie && (k.current = ie, !Ye && ie !== 0 ? be ? xr(j, ie < 0 ? El : kl) : xr(j, ie < 0 ? Pl : Rl) : xr(j, 0)), Ye && (v(xe), w.current.layout = xe, Y && Y(xe), kt(ue, xe, S.current));
    };
  }, []), L = h.useCallback((j, F) => {
    const {
      onLayout: U
    } = E.current, {
      layout: K,
      panelDataArray: z
    } = w.current, G = z.map((oe) => oe.constraints), {
      panelSize: X,
      pivotIndices: Q
    } = ht(z, j, K);
    ne(X != null, `Panel size not found for panel "${j.id}"`);
    const H = Pt(z, j) === z.length - 1 ? X - F : F - X, Y = Wt({
      delta: H,
      initialLayout: K,
      panelConstraints: G,
      pivotIndices: Q,
      prevLayout: K,
      trigger: "imperative-api"
    });
    gn(K, Y) || (v(Y), w.current.layout = Y, U && U(Y), kt(z, Y, S.current));
  }, []), V = h.useCallback((j, F) => {
    const {
      layout: U,
      panelDataArray: K
    } = w.current, {
      collapsedSize: z = 0,
      collapsible: G
    } = F, {
      collapsedSize: X = 0,
      collapsible: Q,
      maxSize: Z = 100,
      minSize: H = 0
    } = j.constraints, {
      panelSize: Y
    } = ht(K, j, U);
    Y != null && (G && Q && Je(Y, z) ? Je(z, X) || L(j, X) : Y < H ? L(j, H) : Y > Z && L(j, Z));
  }, [L]), W = h.useCallback((j, F) => {
    const {
      direction: U
    } = E.current, {
      layout: K
    } = w.current;
    if (!u.current)
      return;
    const z = rr(j, u.current);
    ne(z, `Drag handle element not found for id "${j}"`);
    const G = Il(U, F);
    b({
      dragHandleId: j,
      dragHandleRect: z.getBoundingClientRect(),
      initialCursorPosition: G,
      initialLayout: K
    });
  }, []), B = h.useCallback(() => {
    b(null);
  }, []), te = h.useCallback((j) => {
    const {
      panelDataArray: F
    } = w.current, U = Pt(F, j);
    U >= 0 && (F.splice(U, 1), delete S.current[j.id], w.current.panelDataArrayChanged = !0, y());
  }, [y]), re = h.useMemo(() => ({
    collapsePanel: R,
    direction: r,
    dragState: g,
    expandPanel: T,
    getPanelSize: I,
    getPanelStyle: A,
    groupId: p,
    isPanelCollapsed: N,
    isPanelExpanded: _,
    reevaluatePanelConstraints: V,
    registerPanel: O,
    registerResizeHandle: M,
    resizePanel: L,
    startDragging: W,
    stopDragging: B,
    unregisterPanel: te,
    panelGroupElement: u.current
  }), [R, g, r, T, I, A, p, N, _, V, O, M, L, W, B, te]), J = {
    display: "flex",
    flexDirection: r === "horizontal" ? "row" : "column",
    height: "100%",
    overflow: "hidden",
    width: "100%"
  };
  return h.createElement(er.Provider, {
    value: re
  }, h.createElement(d, {
    ...f,
    children: t,
    className: n,
    id: s,
    ref: u,
    style: {
      ...J,
      ...c
    },
    // CSS selectors
    [me.group]: "",
    [me.groupDirection]: r,
    [me.groupId]: p
  }));
}
const Ol = h.forwardRef((e, t) => h.createElement(zl, {
  ...e,
  forwardedRef: t
}));
zl.displayName = "PanelGroup";
Ol.displayName = "forwardRef(PanelGroup)";
function Pt(e, t) {
  return e.findIndex((n) => n === t || n.id === t.id);
}
function ht(e, t, n) {
  const r = Pt(e, t), s = r === e.length - 1 ? [r - 1, r] : [r, r + 1], a = n[r];
  return {
    ...t.constraints,
    panelSize: a,
    pivotIndices: s
  };
}
function Ev({
  disabled: e,
  handleId: t,
  resizeHandler: n,
  panelGroupElement: r
}) {
  h.useEffect(() => {
    if (e || n == null || r == null)
      return;
    const o = rr(t, r);
    if (o == null)
      return;
    const s = (a) => {
      if (!a.defaultPrevented)
        switch (a.key) {
          case "ArrowDown":
          case "ArrowLeft":
          case "ArrowRight":
          case "ArrowUp":
          case "End":
          case "Home": {
            a.preventDefault(), n(a);
            break;
          }
          case "F6": {
            a.preventDefault();
            const i = o.getAttribute(me.groupId);
            ne(i, `No group element found for id "${i}"`);
            const l = Zt(i, r), c = Nl(i, t, r);
            ne(c !== null, `No resize element found for id "${t}"`);
            const d = a.shiftKey ? c > 0 ? c - 1 : l.length - 1 : c + 1 < l.length ? c + 1 : 0;
            l[d].focus();
            break;
          }
        }
    };
    return o.addEventListener("keydown", s), () => {
      o.removeEventListener("keydown", s);
    };
  }, [r, e, t, n]);
}
function _l({
  children: e = null,
  className: t = "",
  disabled: n = !1,
  hitAreaMargins: r,
  id: o,
  onBlur: s,
  onClick: a,
  onDragging: i,
  onFocus: l,
  onPointerDown: c,
  onPointerUp: d,
  style: f = {},
  tabIndex: p = 0,
  tagName: u = "div",
  ...g
}) {
  var b, x;
  const v = h.useRef(null), y = h.useRef({
    onClick: a,
    onDragging: i,
    onPointerDown: c,
    onPointerUp: d
  });
  h.useEffect(() => {
    y.current.onClick = a, y.current.onDragging = i, y.current.onPointerDown = c, y.current.onPointerUp = d;
  });
  const S = h.useContext(er);
  if (S === null)
    throw Error("PanelResizeHandle components must be rendered within a PanelGroup container");
  const {
    direction: C,
    groupId: k,
    registerResizeHandle: E,
    startDragging: w,
    stopDragging: R,
    panelGroupElement: T
  } = S, I = bo(o), [A, N] = h.useState("inactive"), [_, O] = h.useState(!1), [M, L] = h.useState(null), V = h.useRef({
    state: A
  });
  bt(() => {
    V.current.state = A;
  }), h.useEffect(() => {
    if (n)
      L(null);
    else {
      const re = E(I);
      L(() => re);
    }
  }, [n, I, E]);
  const W = (b = r == null ? void 0 : r.coarse) !== null && b !== void 0 ? b : 15, B = (x = r == null ? void 0 : r.fine) !== null && x !== void 0 ? x : 5;
  h.useEffect(() => {
    if (n || M == null)
      return;
    const re = v.current;
    ne(re, "Element ref not attached");
    let J = !1;
    return cv(I, re, C, {
      coarse: W,
      fine: B
    }, (F, U, K) => {
      if (!U) {
        N("inactive");
        return;
      }
      switch (F) {
        case "down": {
          N("drag"), J = !1, ne(K, 'Expected event to be defined for "down" action'), w(I, K);
          const {
            onDragging: z,
            onPointerDown: G
          } = y.current;
          z == null || z(!0), G == null || G();
          break;
        }
        case "move": {
          const {
            state: z
          } = V.current;
          J = !0, z !== "drag" && N("hover"), ne(K, 'Expected event to be defined for "move" action'), M(K);
          break;
        }
        case "up": {
          N("hover"), R();
          const {
            onClick: z,
            onDragging: G,
            onPointerUp: X
          } = y.current;
          G == null || G(!1), X == null || X(), J || z == null || z();
          break;
        }
      }
    });
  }, [W, C, n, B, E, I, M, w, R]), Ev({
    disabled: n,
    handleId: I,
    resizeHandler: M,
    panelGroupElement: T
  });
  const te = {
    touchAction: "none",
    userSelect: "none"
  };
  return h.createElement(u, {
    ...g,
    children: e,
    className: t,
    id: o,
    onBlur: () => {
      O(!1), s == null || s();
    },
    onFocus: () => {
      O(!0), l == null || l();
    },
    ref: v,
    role: "separator",
    style: {
      ...te,
      ...f
    },
    tabIndex: p,
    // CSS selectors
    [me.groupDirection]: C,
    [me.groupId]: k,
    [me.resizeHandle]: "",
    [me.resizeHandleActive]: A === "drag" ? "pointer" : _ ? "keyboard" : void 0,
    [me.resizeHandleEnabled]: !n,
    [me.resizeHandleId]: I,
    [me.resizeHandleState]: A
  });
}
_l.displayName = "PanelResizeHandle";
function kv(e) {
  return Object.prototype.toString.call(e) === "[object Object]";
}
function qs(e) {
  return kv(e) || Array.isArray(e);
}
function Pv() {
  return !!(typeof window < "u" && window.document && window.document.createElement);
}
function yo(e, t) {
  const n = Object.keys(e), r = Object.keys(t);
  if (n.length !== r.length) return !1;
  const o = JSON.stringify(Object.keys(e.breakpoints || {})), s = JSON.stringify(Object.keys(t.breakpoints || {}));
  return o !== s ? !1 : n.every((a) => {
    const i = e[a], l = t[a];
    return typeof i == "function" ? `${i}` == `${l}` : !qs(i) || !qs(l) ? i === l : yo(i, l);
  });
}
function Js(e) {
  return e.concat().sort((t, n) => t.name > n.name ? 1 : -1).map((t) => t.options);
}
function Rv(e, t) {
  if (e.length !== t.length) return !1;
  const n = Js(e), r = Js(t);
  return n.every((o, s) => {
    const a = r[s];
    return yo(o, a);
  });
}
function wo(e) {
  return typeof e == "number";
}
function Dr(e) {
  return typeof e == "string";
}
function or(e) {
  return typeof e == "boolean";
}
function Zs(e) {
  return Object.prototype.toString.call(e) === "[object Object]";
}
function fe(e) {
  return Math.abs(e);
}
function Co(e) {
  return Math.sign(e);
}
function Kt(e, t) {
  return fe(e - t);
}
function Av(e, t) {
  if (e === 0 || t === 0 || fe(e) <= fe(t)) return 0;
  const n = Kt(fe(e), fe(t));
  return fe(n / e);
}
function Nv(e) {
  return Math.round(e * 100) / 100;
}
function Qt(e) {
  return en(e).map(Number);
}
function ze(e) {
  return e[sn(e)];
}
function sn(e) {
  return Math.max(0, e.length - 1);
}
function So(e, t) {
  return t === sn(e);
}
function Qs(e, t = 0) {
  return Array.from(Array(e), (n, r) => t + r);
}
function en(e) {
  return Object.keys(e);
}
function $l(e, t) {
  return [e, t].reduce((n, r) => (en(r).forEach((o) => {
    const s = n[o], a = r[o], i = Zs(s) && Zs(a);
    n[o] = i ? $l(s, a) : a;
  }), n), {});
}
function zr(e, t) {
  return typeof t.MouseEvent < "u" && e instanceof t.MouseEvent;
}
function Tv(e, t) {
  const n = {
    start: r,
    center: o,
    end: s
  };
  function r() {
    return 0;
  }
  function o(l) {
    return s(l) / 2;
  }
  function s(l) {
    return t - l;
  }
  function a(l, c) {
    return Dr(e) ? n[e](l) : e(t, l, c);
  }
  return {
    measure: a
  };
}
function tn() {
  let e = [];
  function t(o, s, a, i = {
    passive: !0
  }) {
    let l;
    if ("addEventListener" in o)
      o.addEventListener(s, a, i), l = () => o.removeEventListener(s, a, i);
    else {
      const c = o;
      c.addListener(a), l = () => c.removeListener(a);
    }
    return e.push(l), r;
  }
  function n() {
    e = e.filter((o) => o());
  }
  const r = {
    add: t,
    clear: n
  };
  return r;
}
function jv(e, t, n, r) {
  const o = tn(), s = 1e3 / 60;
  let a = null, i = 0, l = 0;
  function c() {
    o.add(e, "visibilitychange", () => {
      e.hidden && g();
    });
  }
  function d() {
    u(), o.clear();
  }
  function f(x) {
    if (!l) return;
    a || (a = x, n(), n());
    const v = x - a;
    for (a = x, i += v; i >= s; )
      n(), i -= s;
    const y = i / s;
    r(y), l && (l = t.requestAnimationFrame(f));
  }
  function p() {
    l || (l = t.requestAnimationFrame(f));
  }
  function u() {
    t.cancelAnimationFrame(l), a = null, i = 0, l = 0;
  }
  function g() {
    a = null, i = 0;
  }
  return {
    init: c,
    destroy: d,
    start: p,
    stop: u,
    update: n,
    render: r
  };
}
function Iv(e, t) {
  const n = t === "rtl", r = e === "y", o = r ? "y" : "x", s = r ? "x" : "y", a = !r && n ? -1 : 1, i = d(), l = f();
  function c(g) {
    const {
      height: b,
      width: x
    } = g;
    return r ? b : x;
  }
  function d() {
    return r ? "top" : n ? "right" : "left";
  }
  function f() {
    return r ? "bottom" : n ? "left" : "right";
  }
  function p(g) {
    return g * a;
  }
  return {
    scroll: o,
    cross: s,
    startEdge: i,
    endEdge: l,
    measureSize: c,
    direction: p
  };
}
function wt(e = 0, t = 0) {
  const n = fe(e - t);
  function r(c) {
    return c < e;
  }
  function o(c) {
    return c > t;
  }
  function s(c) {
    return r(c) || o(c);
  }
  function a(c) {
    return s(c) ? r(c) ? e : t : c;
  }
  function i(c) {
    return n ? c - n * Math.ceil((c - t) / n) : c;
  }
  return {
    length: n,
    max: t,
    min: e,
    constrain: a,
    reachedAny: s,
    reachedMax: o,
    reachedMin: r,
    removeOffset: i
  };
}
function Fl(e, t, n) {
  const {
    constrain: r
  } = wt(0, e), o = e + 1;
  let s = a(t);
  function a(p) {
    return n ? fe((o + p) % o) : r(p);
  }
  function i() {
    return s;
  }
  function l(p) {
    return s = a(p), f;
  }
  function c(p) {
    return d().set(i() + p);
  }
  function d() {
    return Fl(e, i(), n);
  }
  const f = {
    get: i,
    set: l,
    add: c,
    clone: d
  };
  return f;
}
function Mv(e, t, n, r, o, s, a, i, l, c, d, f, p, u, g, b, x, v, y) {
  const {
    cross: S,
    direction: C
  } = e, k = ["INPUT", "SELECT", "TEXTAREA"], E = {
    passive: !1
  }, w = tn(), R = tn(), T = wt(50, 225).constrain(u.measure(20)), I = {
    mouse: 300,
    touch: 400
  }, A = {
    mouse: 500,
    touch: 600
  }, N = g ? 43 : 25;
  let _ = !1, O = 0, M = 0, L = !1, V = !1, W = !1, B = !1;
  function te(H) {
    if (!y) return;
    function Y(ue) {
      (or(y) || y(H, ue)) && K(ue);
    }
    const oe = t;
    w.add(oe, "dragstart", (ue) => ue.preventDefault(), E).add(oe, "touchmove", () => {
    }, E).add(oe, "touchend", () => {
    }).add(oe, "touchstart", Y).add(oe, "mousedown", Y).add(oe, "touchcancel", G).add(oe, "contextmenu", G).add(oe, "click", X, !0);
  }
  function re() {
    w.clear(), R.clear();
  }
  function J() {
    const H = B ? n : t;
    R.add(H, "touchmove", z, E).add(H, "touchend", G).add(H, "mousemove", z, E).add(H, "mouseup", G);
  }
  function j(H) {
    const Y = H.nodeName || "";
    return k.includes(Y);
  }
  function F() {
    return (g ? A : I)[B ? "mouse" : "touch"];
  }
  function U(H, Y) {
    const oe = f.add(Co(H) * -1), ue = d.byDistance(H, !g).distance;
    return g || fe(H) < T ? ue : x && Y ? ue * 0.5 : d.byIndex(oe.get(), 0).distance;
  }
  function K(H) {
    const Y = zr(H, r);
    B = Y, W = g && Y && !H.buttons && _, _ = Kt(o.get(), a.get()) >= 2, !(Y && H.button !== 0) && (j(H.target) || (L = !0, s.pointerDown(H), c.useFriction(0).useDuration(0), o.set(a), J(), O = s.readPoint(H), M = s.readPoint(H, S), p.emit("pointerDown")));
  }
  function z(H) {
    if (!zr(H, r) && H.touches.length >= 2) return G(H);
    const oe = s.readPoint(H), ue = s.readPoint(H, S), ge = Kt(oe, O), ve = Kt(ue, M);
    if (!V && !B && (!H.cancelable || (V = ge > ve, !V)))
      return G(H);
    const ie = s.pointerMove(H);
    ge > b && (W = !0), c.useFriction(0.3).useDuration(0.75), i.start(), o.add(C(ie)), H.preventDefault();
  }
  function G(H) {
    const oe = d.byDistance(0, !1).index !== f.get(), ue = s.pointerUp(H) * F(), ge = U(C(ue), oe), ve = Av(ue, ge), ie = N - 10 * ve, be = v + ve / 50;
    V = !1, L = !1, R.clear(), c.useDuration(ie).useFriction(be), l.distance(ge, !g), B = !1, p.emit("pointerUp");
  }
  function X(H) {
    W && (H.stopPropagation(), H.preventDefault(), W = !1);
  }
  function Q() {
    return L;
  }
  return {
    init: te,
    destroy: re,
    pointerDown: Q
  };
}
function Lv(e, t) {
  let r, o;
  function s(f) {
    return f.timeStamp;
  }
  function a(f, p) {
    const g = `client${(p || e.scroll) === "x" ? "X" : "Y"}`;
    return (zr(f, t) ? f : f.touches[0])[g];
  }
  function i(f) {
    return r = f, o = f, a(f);
  }
  function l(f) {
    const p = a(f) - a(o), u = s(f) - s(r) > 170;
    return o = f, u && (r = f), p;
  }
  function c(f) {
    if (!r || !o) return 0;
    const p = a(o) - a(r), u = s(f) - s(r), g = s(f) - s(o) > 170, b = p / u;
    return u && !g && fe(b) > 0.1 ? b : 0;
  }
  return {
    pointerDown: i,
    pointerMove: l,
    pointerUp: c,
    readPoint: a
  };
}
function Dv() {
  function e(n) {
    const {
      offsetTop: r,
      offsetLeft: o,
      offsetWidth: s,
      offsetHeight: a
    } = n;
    return {
      top: r,
      right: o + s,
      bottom: r + a,
      left: o,
      width: s,
      height: a
    };
  }
  return {
    measure: e
  };
}
function zv(e) {
  function t(r) {
    return e * (r / 100);
  }
  return {
    measure: t
  };
}
function Ov(e, t, n, r, o, s, a) {
  const i = [e].concat(r);
  let l, c, d = [], f = !1;
  function p(x) {
    return o.measureSize(a.measure(x));
  }
  function u(x) {
    if (!s) return;
    c = p(e), d = r.map(p);
    function v(y) {
      for (const S of y) {
        if (f) return;
        const C = S.target === e, k = r.indexOf(S.target), E = C ? c : d[k], w = p(C ? e : r[k]);
        if (fe(w - E) >= 0.5) {
          x.reInit(), t.emit("resize");
          break;
        }
      }
    }
    l = new ResizeObserver((y) => {
      (or(s) || s(x, y)) && v(y);
    }), n.requestAnimationFrame(() => {
      i.forEach((y) => l.observe(y));
    });
  }
  function g() {
    f = !0, l && l.disconnect();
  }
  return {
    init: u,
    destroy: g
  };
}
function _v(e, t, n, r, o, s) {
  let a = 0, i = 0, l = o, c = s, d = e.get(), f = 0;
  function p() {
    const E = r.get() - e.get(), w = !l;
    let R = 0;
    return w ? (a = 0, n.set(r), e.set(r), R = E) : (n.set(e), a += E / l, a *= c, d += a, e.add(a), R = d - f), i = Co(R), f = d, k;
  }
  function u() {
    const E = r.get() - t.get();
    return fe(E) < 1e-3;
  }
  function g() {
    return l;
  }
  function b() {
    return i;
  }
  function x() {
    return a;
  }
  function v() {
    return S(o);
  }
  function y() {
    return C(s);
  }
  function S(E) {
    return l = E, k;
  }
  function C(E) {
    return c = E, k;
  }
  const k = {
    direction: b,
    duration: g,
    velocity: x,
    seek: p,
    settled: u,
    useBaseFriction: y,
    useBaseDuration: v,
    useFriction: C,
    useDuration: S
  };
  return k;
}
function $v(e, t, n, r, o) {
  const s = o.measure(10), a = o.measure(50), i = wt(0.1, 0.99);
  let l = !1;
  function c() {
    return !(l || !e.reachedAny(n.get()) || !e.reachedAny(t.get()));
  }
  function d(u) {
    if (!c()) return;
    const g = e.reachedMin(t.get()) ? "min" : "max", b = fe(e[g] - t.get()), x = n.get() - t.get(), v = i.constrain(b / a);
    n.subtract(x * v), !u && fe(x) < s && (n.set(e.constrain(n.get())), r.useDuration(25).useBaseFriction());
  }
  function f(u) {
    l = !u;
  }
  return {
    shouldConstrain: c,
    constrain: d,
    toggleActive: f
  };
}
function Fv(e, t, n, r, o) {
  const s = wt(-t + e, 0), a = f(), i = d(), l = p();
  function c(g, b) {
    return Kt(g, b) <= 1;
  }
  function d() {
    const g = a[0], b = ze(a), x = a.lastIndexOf(g), v = a.indexOf(b) + 1;
    return wt(x, v);
  }
  function f() {
    return n.map((g, b) => {
      const {
        min: x,
        max: v
      } = s, y = s.constrain(g), S = !b, C = So(n, b);
      return S ? v : C || c(x, y) ? x : c(v, y) ? v : y;
    }).map((g) => parseFloat(g.toFixed(3)));
  }
  function p() {
    if (t <= e + o) return [s.max];
    if (r === "keepSnaps") return a;
    const {
      min: g,
      max: b
    } = i;
    return a.slice(g, b);
  }
  return {
    snapsContained: l,
    scrollContainLimit: i
  };
}
function Bv(e, t, n) {
  const r = t[0], o = n ? r - e : ze(t);
  return {
    limit: wt(o, r)
  };
}
function Hv(e, t, n, r) {
  const s = t.min + 0.1, a = t.max + 0.1, {
    reachedMin: i,
    reachedMax: l
  } = wt(s, a);
  function c(p) {
    return p === 1 ? l(n.get()) : p === -1 ? i(n.get()) : !1;
  }
  function d(p) {
    if (!c(p)) return;
    const u = e * (p * -1);
    r.forEach((g) => g.add(u));
  }
  return {
    loop: d
  };
}
function Vv(e) {
  const {
    max: t,
    length: n
  } = e;
  function r(s) {
    const a = s - t;
    return n ? a / -n : 0;
  }
  return {
    get: r
  };
}
function Wv(e, t, n, r, o) {
  const {
    startEdge: s,
    endEdge: a
  } = e, {
    groupSlides: i
  } = o, l = f().map(t.measure), c = p(), d = u();
  function f() {
    return i(r).map((b) => ze(b)[a] - b[0][s]).map(fe);
  }
  function p() {
    return r.map((b) => n[s] - b[s]).map((b) => -fe(b));
  }
  function u() {
    return i(c).map((b) => b[0]).map((b, x) => b + l[x]);
  }
  return {
    snaps: c,
    snapsAligned: d
  };
}
function Gv(e, t, n, r, o, s) {
  const {
    groupSlides: a
  } = o, {
    min: i,
    max: l
  } = r, c = d();
  function d() {
    const p = a(s), u = !e || t === "keepSnaps";
    return n.length === 1 ? [s] : u ? p : p.slice(i, l).map((g, b, x) => {
      const v = !b, y = So(x, b);
      if (v) {
        const S = ze(x[0]) + 1;
        return Qs(S);
      }
      if (y) {
        const S = sn(s) - ze(x)[0] + 1;
        return Qs(S, ze(x)[0]);
      }
      return g;
    });
  }
  return {
    slideRegistry: c
  };
}
function Uv(e, t, n, r, o) {
  const {
    reachedAny: s,
    removeOffset: a,
    constrain: i
  } = r;
  function l(g) {
    return g.concat().sort((b, x) => fe(b) - fe(x))[0];
  }
  function c(g) {
    const b = e ? a(g) : i(g), x = t.map((y, S) => ({
      diff: d(y - b, 0),
      index: S
    })).sort((y, S) => fe(y.diff) - fe(S.diff)), {
      index: v
    } = x[0];
    return {
      index: v,
      distance: b
    };
  }
  function d(g, b) {
    const x = [g, g + n, g - n];
    if (!e) return g;
    if (!b) return l(x);
    const v = x.filter((y) => Co(y) === b);
    return v.length ? l(v) : ze(x) - n;
  }
  function f(g, b) {
    const x = t[g] - o.get(), v = d(x, b);
    return {
      index: g,
      distance: v
    };
  }
  function p(g, b) {
    const x = o.get() + g, {
      index: v,
      distance: y
    } = c(x), S = !e && s(x);
    if (!b || S) return {
      index: v,
      distance: g
    };
    const C = t[v] - y, k = g + d(C, 0);
    return {
      index: v,
      distance: k
    };
  }
  return {
    byDistance: p,
    byIndex: f,
    shortcut: d
  };
}
function Kv(e, t, n, r, o, s, a) {
  function i(f) {
    const p = f.distance, u = f.index !== t.get();
    s.add(p), p && (r.duration() ? e.start() : (e.update(), e.render(1), e.update())), u && (n.set(t.get()), t.set(f.index), a.emit("select"));
  }
  function l(f, p) {
    const u = o.byDistance(f, p);
    i(u);
  }
  function c(f, p) {
    const u = t.clone().set(f), g = o.byIndex(u.get(), p);
    i(g);
  }
  return {
    distance: l,
    index: c
  };
}
function Yv(e, t, n, r, o, s, a, i) {
  const l = {
    passive: !0,
    capture: !0
  };
  let c = 0;
  function d(u) {
    if (!i) return;
    function g(b) {
      if ((/* @__PURE__ */ new Date()).getTime() - c > 10) return;
      a.emit("slideFocusStart"), e.scrollLeft = 0;
      const y = n.findIndex((S) => S.includes(b));
      wo(y) && (o.useDuration(0), r.index(y, 0), a.emit("slideFocus"));
    }
    s.add(document, "keydown", f, !1), t.forEach((b, x) => {
      s.add(b, "focus", (v) => {
        (or(i) || i(u, v)) && g(x);
      }, l);
    });
  }
  function f(u) {
    u.code === "Tab" && (c = (/* @__PURE__ */ new Date()).getTime());
  }
  return {
    init: d
  };
}
function Ut(e) {
  let t = e;
  function n() {
    return t;
  }
  function r(l) {
    t = a(l);
  }
  function o(l) {
    t += a(l);
  }
  function s(l) {
    t -= a(l);
  }
  function a(l) {
    return wo(l) ? l : l.get();
  }
  return {
    get: n,
    set: r,
    add: o,
    subtract: s
  };
}
function Bl(e, t) {
  const n = e.scroll === "x" ? a : i, r = t.style;
  let o = null, s = !1;
  function a(p) {
    return `translate3d(${p}px,0px,0px)`;
  }
  function i(p) {
    return `translate3d(0px,${p}px,0px)`;
  }
  function l(p) {
    if (s) return;
    const u = Nv(e.direction(p));
    u !== o && (r.transform = n(u), o = u);
  }
  function c(p) {
    s = !p;
  }
  function d() {
    s || (r.transform = "", t.getAttribute("style") || t.removeAttribute("style"));
  }
  return {
    clear: d,
    to: l,
    toggleActive: c
  };
}
function Xv(e, t, n, r, o, s, a, i, l) {
  const d = Qt(o), f = Qt(o).reverse(), p = v().concat(y());
  function u(w, R) {
    return w.reduce((T, I) => T - o[I], R);
  }
  function g(w, R) {
    return w.reduce((T, I) => u(T, R) > 0 ? T.concat([I]) : T, []);
  }
  function b(w) {
    return s.map((R, T) => ({
      start: R - r[T] + 0.5 + w,
      end: R + t - 0.5 + w
    }));
  }
  function x(w, R, T) {
    const I = b(R);
    return w.map((A) => {
      const N = T ? 0 : -n, _ = T ? n : 0, O = T ? "end" : "start", M = I[A][O];
      return {
        index: A,
        loopPoint: M,
        slideLocation: Ut(-1),
        translate: Bl(e, l[A]),
        target: () => i.get() > M ? N : _
      };
    });
  }
  function v() {
    const w = a[0], R = g(f, w);
    return x(R, n, !1);
  }
  function y() {
    const w = t - a[0] - 1, R = g(d, w);
    return x(R, -n, !0);
  }
  function S() {
    return p.every(({
      index: w
    }) => {
      const R = d.filter((T) => T !== w);
      return u(R, t) <= 0.1;
    });
  }
  function C() {
    p.forEach((w) => {
      const {
        target: R,
        translate: T,
        slideLocation: I
      } = w, A = R();
      A !== I.get() && (T.to(A), I.set(A));
    });
  }
  function k() {
    p.forEach((w) => w.translate.clear());
  }
  return {
    canLoop: S,
    clear: k,
    loop: C,
    loopPoints: p
  };
}
function qv(e, t, n) {
  let r, o = !1;
  function s(l) {
    if (!n) return;
    function c(d) {
      for (const f of d)
        if (f.type === "childList") {
          l.reInit(), t.emit("slidesChanged");
          break;
        }
    }
    r = new MutationObserver((d) => {
      o || (or(n) || n(l, d)) && c(d);
    }), r.observe(e, {
      childList: !0
    });
  }
  function a() {
    r && r.disconnect(), o = !0;
  }
  return {
    init: s,
    destroy: a
  };
}
function Jv(e, t, n, r) {
  const o = {};
  let s = null, a = null, i, l = !1;
  function c() {
    i = new IntersectionObserver((g) => {
      l || (g.forEach((b) => {
        const x = t.indexOf(b.target);
        o[x] = b;
      }), s = null, a = null, n.emit("slidesInView"));
    }, {
      root: e.parentElement,
      threshold: r
    }), t.forEach((g) => i.observe(g));
  }
  function d() {
    i && i.disconnect(), l = !0;
  }
  function f(g) {
    return en(o).reduce((b, x) => {
      const v = parseInt(x), {
        isIntersecting: y
      } = o[v];
      return (g && y || !g && !y) && b.push(v), b;
    }, []);
  }
  function p(g = !0) {
    if (g && s) return s;
    if (!g && a) return a;
    const b = f(g);
    return g && (s = b), g || (a = b), b;
  }
  return {
    init: c,
    destroy: d,
    get: p
  };
}
function Zv(e, t, n, r, o, s) {
  const {
    measureSize: a,
    startEdge: i,
    endEdge: l
  } = e, c = n[0] && o, d = g(), f = b(), p = n.map(a), u = x();
  function g() {
    if (!c) return 0;
    const y = n[0];
    return fe(t[i] - y[i]);
  }
  function b() {
    if (!c) return 0;
    const y = s.getComputedStyle(ze(r));
    return parseFloat(y.getPropertyValue(`margin-${l}`));
  }
  function x() {
    return n.map((y, S, C) => {
      const k = !S, E = So(C, S);
      return k ? p[S] + d : E ? p[S] + f : C[S + 1][i] - y[i];
    }).map(fe);
  }
  return {
    slideSizes: p,
    slideSizesWithGaps: u,
    startGap: d,
    endGap: f
  };
}
function Qv(e, t, n, r, o, s, a, i, l) {
  const {
    startEdge: c,
    endEdge: d,
    direction: f
  } = e, p = wo(n);
  function u(v, y) {
    return Qt(v).filter((S) => S % y === 0).map((S) => v.slice(S, S + y));
  }
  function g(v) {
    return v.length ? Qt(v).reduce((y, S, C) => {
      const k = ze(y) || 0, E = k === 0, w = S === sn(v), R = o[c] - s[k][c], T = o[c] - s[S][d], I = !r && E ? f(a) : 0, A = !r && w ? f(i) : 0, N = fe(T - A - (R + I));
      return C && N > t + l && y.push(S), w && y.push(v.length), y;
    }, []).map((y, S, C) => {
      const k = Math.max(C[S - 1] || 0);
      return v.slice(k, y);
    }) : [];
  }
  function b(v) {
    return p ? u(v, n) : g(v);
  }
  return {
    groupSlides: b
  };
}
function ex(e, t, n, r, o, s, a) {
  const {
    align: i,
    axis: l,
    direction: c,
    startIndex: d,
    loop: f,
    duration: p,
    dragFree: u,
    dragThreshold: g,
    inViewThreshold: b,
    slidesToScroll: x,
    skipSnaps: v,
    containScroll: y,
    watchResize: S,
    watchSlides: C,
    watchDrag: k,
    watchFocus: E
  } = s, w = 2, R = Dv(), T = R.measure(t), I = n.map(R.measure), A = Iv(l, c), N = A.measureSize(T), _ = zv(N), O = Tv(i, N), M = !f && !!y, L = f || !!y, {
    slideSizes: V,
    slideSizesWithGaps: W,
    startGap: B,
    endGap: te
  } = Zv(A, T, I, n, L, o), re = Qv(A, N, x, f, T, I, B, te, w), {
    snaps: J,
    snapsAligned: j
  } = Wv(A, O, T, I, re), F = -ze(J) + ze(W), {
    snapsContained: U,
    scrollContainLimit: K
  } = Fv(N, F, j, y, w), z = M ? U : j, {
    limit: G
  } = Bv(F, z, f), X = Fl(sn(z), d, f), Q = X.clone(), Z = Qt(n), H = ({
    dragHandler: Ne,
    scrollBody: $t,
    scrollBounds: St,
    options: {
      loop: et
    }
  }) => {
    et || St.constrain(Ne.pointerDown()), $t.seek();
  }, Y = ({
    scrollBody: Ne,
    translate: $t,
    location: St,
    offsetLocation: et,
    previousLocation: tt,
    scrollLooper: un,
    slideLooper: nt,
    dragHandler: ar,
    animation: ir,
    eventHandler: Ft,
    scrollBounds: dn,
    options: {
      loop: fn
    }
  }, Et) => {
    const Te = Ne.settled(), lr = !dn.shouldConstrain(), q = fn ? Te : Te && lr, se = q && !ar.pointerDown();
    se && ir.stop();
    const ce = St.get() * Et + tt.get() * (1 - Et);
    et.set(ce), fn && (un.loop(Ne.direction()), nt.loop()), $t.to(et.get()), se && Ft.emit("settle"), q || Ft.emit("scroll");
  }, oe = jv(r, o, () => H(_t), (Ne) => Y(_t, Ne)), ue = 0.68, ge = z[X.get()], ve = Ut(ge), ie = Ut(ge), be = Ut(ge), Pe = Ut(ge), xe = _v(ve, be, ie, Pe, p, ue), Ye = Uv(f, z, F, G, Pe), Ce = Kv(oe, X, Q, xe, Ye, Pe, a), ln = Vv(G), cn = tn(), ye = Jv(t, n, a, b), {
    slideRegistry: Xe
  } = Gv(M, y, z, K, re, Z), sr = Yv(e, n, Xe, Ce, xe, cn, a, E), _t = {
    ownerDocument: r,
    ownerWindow: o,
    eventHandler: a,
    containerRect: T,
    slideRects: I,
    animation: oe,
    axis: A,
    dragHandler: Mv(A, e, r, o, Pe, Lv(A, o), ve, oe, Ce, xe, Ye, X, a, _, u, g, v, ue, k),
    eventStore: cn,
    percentOfView: _,
    index: X,
    indexPrevious: Q,
    limit: G,
    location: ve,
    offsetLocation: be,
    previousLocation: ie,
    options: s,
    resizeHandler: Ov(t, a, o, n, A, S, R),
    scrollBody: xe,
    scrollBounds: $v(G, be, Pe, xe, _),
    scrollLooper: Hv(F, G, be, [ve, be, ie, Pe]),
    scrollProgress: ln,
    scrollSnapList: z.map(ln.get),
    scrollSnaps: z,
    scrollTarget: Ye,
    scrollTo: Ce,
    slideLooper: Xv(A, N, F, V, W, J, z, be, n),
    slideFocus: sr,
    slidesHandler: qv(t, a, C),
    slidesInView: ye,
    slideIndexes: Z,
    slideRegistry: Xe,
    slidesToScroll: re,
    target: Pe,
    translate: Bl(A, t)
  };
  return _t;
}
function tx() {
  let e = {}, t;
  function n(c) {
    t = c;
  }
  function r(c) {
    return e[c] || [];
  }
  function o(c) {
    return r(c).forEach((d) => d(t, c)), l;
  }
  function s(c, d) {
    return e[c] = r(c).concat([d]), l;
  }
  function a(c, d) {
    return e[c] = r(c).filter((f) => f !== d), l;
  }
  function i() {
    e = {};
  }
  const l = {
    init: n,
    emit: o,
    off: a,
    on: s,
    clear: i
  };
  return l;
}
const nx = {
  align: "center",
  axis: "x",
  container: null,
  slides: null,
  containScroll: "trimSnaps",
  direction: "ltr",
  slidesToScroll: 1,
  inViewThreshold: 0,
  breakpoints: {},
  dragFree: !1,
  dragThreshold: 10,
  loop: !1,
  skipSnaps: !1,
  duration: 25,
  startIndex: 0,
  active: !0,
  watchDrag: !0,
  watchResize: !0,
  watchSlides: !0,
  watchFocus: !0
};
function rx(e) {
  function t(s, a) {
    return $l(s, a || {});
  }
  function n(s) {
    const a = s.breakpoints || {}, i = en(a).filter((l) => e.matchMedia(l).matches).map((l) => a[l]).reduce((l, c) => t(l, c), {});
    return t(s, i);
  }
  function r(s) {
    return s.map((a) => en(a.breakpoints || {})).reduce((a, i) => a.concat(i), []).map(e.matchMedia);
  }
  return {
    mergeOptions: t,
    optionsAtMedia: n,
    optionsMediaQueries: r
  };
}
function ox(e) {
  let t = [];
  function n(s, a) {
    return t = a.filter(({
      options: i
    }) => e.optionsAtMedia(i).active !== !1), t.forEach((i) => i.init(s, e)), a.reduce((i, l) => Object.assign(i, {
      [l.name]: l
    }), {});
  }
  function r() {
    t = t.filter((s) => s.destroy());
  }
  return {
    init: n,
    destroy: r
  };
}
function Mn(e, t, n) {
  const r = e.ownerDocument, o = r.defaultView, s = rx(o), a = ox(s), i = tn(), l = tx(), {
    mergeOptions: c,
    optionsAtMedia: d,
    optionsMediaQueries: f
  } = s, {
    on: p,
    off: u,
    emit: g
  } = l, b = A;
  let x = !1, v, y = c(nx, Mn.globalOptions), S = c(y), C = [], k, E, w;
  function R() {
    const {
      container: Z,
      slides: H
    } = S;
    E = (Dr(Z) ? e.querySelector(Z) : Z) || e.children[0];
    const oe = Dr(H) ? E.querySelectorAll(H) : H;
    w = [].slice.call(oe || E.children);
  }
  function T(Z) {
    const H = ex(e, E, w, r, o, Z, l);
    if (Z.loop && !H.slideLooper.canLoop()) {
      const Y = Object.assign({}, Z, {
        loop: !1
      });
      return T(Y);
    }
    return H;
  }
  function I(Z, H) {
    x || (y = c(y, Z), S = d(y), C = H || C, R(), v = T(S), f([y, ...C.map(({
      options: Y
    }) => Y)]).forEach((Y) => i.add(Y, "change", A)), S.active && (v.translate.to(v.location.get()), v.animation.init(), v.slidesInView.init(), v.slideFocus.init(Q), v.eventHandler.init(Q), v.resizeHandler.init(Q), v.slidesHandler.init(Q), v.options.loop && v.slideLooper.loop(), E.offsetParent && w.length && v.dragHandler.init(Q), k = a.init(Q, C)));
  }
  function A(Z, H) {
    const Y = re();
    N(), I(c({
      startIndex: Y
    }, Z), H), l.emit("reInit");
  }
  function N() {
    v.dragHandler.destroy(), v.eventStore.clear(), v.translate.clear(), v.slideLooper.clear(), v.resizeHandler.destroy(), v.slidesHandler.destroy(), v.slidesInView.destroy(), v.animation.destroy(), a.destroy(), i.clear();
  }
  function _() {
    x || (x = !0, i.clear(), N(), l.emit("destroy"), l.clear());
  }
  function O(Z, H, Y) {
    !S.active || x || (v.scrollBody.useBaseFriction().useDuration(H === !0 ? 0 : S.duration), v.scrollTo.index(Z, Y || 0));
  }
  function M(Z) {
    const H = v.index.add(1).get();
    O(H, Z, -1);
  }
  function L(Z) {
    const H = v.index.add(-1).get();
    O(H, Z, 1);
  }
  function V() {
    return v.index.add(1).get() !== re();
  }
  function W() {
    return v.index.add(-1).get() !== re();
  }
  function B() {
    return v.scrollSnapList;
  }
  function te() {
    return v.scrollProgress.get(v.offsetLocation.get());
  }
  function re() {
    return v.index.get();
  }
  function J() {
    return v.indexPrevious.get();
  }
  function j() {
    return v.slidesInView.get();
  }
  function F() {
    return v.slidesInView.get(!1);
  }
  function U() {
    return k;
  }
  function K() {
    return v;
  }
  function z() {
    return e;
  }
  function G() {
    return E;
  }
  function X() {
    return w;
  }
  const Q = {
    canScrollNext: V,
    canScrollPrev: W,
    containerNode: G,
    internalEngine: K,
    destroy: _,
    off: u,
    on: p,
    emit: g,
    plugins: U,
    previousScrollSnap: J,
    reInit: b,
    rootNode: z,
    scrollNext: M,
    scrollPrev: L,
    scrollProgress: te,
    scrollSnapList: B,
    scrollTo: O,
    selectedScrollSnap: re,
    slideNodes: X,
    slidesInView: j,
    slidesNotInView: F
  };
  return I(t, n), setTimeout(() => l.emit("init"), 0), Q;
}
Mn.globalOptions = void 0;
function Eo(e = {}, t = []) {
  const n = h.useRef(e), r = h.useRef(t), [o, s] = h.useState(), [a, i] = h.useState(), l = h.useCallback(() => {
    o && o.reInit(n.current, r.current);
  }, [o]);
  return h.useEffect(() => {
    yo(n.current, e) || (n.current = e, l());
  }, [e, l]), h.useEffect(() => {
    Rv(r.current, t) || (r.current = t, l());
  }, [t, l]), h.useEffect(() => {
    if (Pv() && a) {
      Mn.globalOptions = Eo.globalOptions;
      const c = Mn(a, n.current, r.current);
      return s(c), () => c.destroy();
    } else
      s(void 0);
  }, [a, s]), [i, o];
}
Eo.globalOptions = void 0;
var sx = (e) => {
  switch (e) {
    case "success":
      return lx;
    case "info":
      return ux;
    case "warning":
      return cx;
    case "error":
      return dx;
    default:
      return null;
  }
}, ax = Array(12).fill(0), ix = ({ visible: e, className: t }) => P.createElement("div", { className: ["sonner-loading-wrapper", t].filter(Boolean).join(" "), "data-visible": e }, P.createElement("div", { className: "sonner-spinner" }, ax.map((n, r) => P.createElement("div", { className: "sonner-loading-bar", key: `spinner-bar-${r}` })))), lx = P.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 20 20", fill: "currentColor", height: "20", width: "20" }, P.createElement("path", { fillRule: "evenodd", d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z", clipRule: "evenodd" })), cx = P.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", height: "20", width: "20" }, P.createElement("path", { fillRule: "evenodd", d: "M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 2-.29 4.5-2.599 4.5H4.645c-2.309 0-3.752-2.5-2.598-4.5L9.4 3.003zM12 8.25a.75.75 0 01.75.75v3.75a.75.75 0 01-1.5 0V9a.75.75 0 01.75-.75zm0 8.25a.75.75 0 100-1.5.75.75 0 000 1.5z", clipRule: "evenodd" })), ux = P.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 20 20", fill: "currentColor", height: "20", width: "20" }, P.createElement("path", { fillRule: "evenodd", d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a.75.75 0 000 1.5h.253a.25.25 0 01.244.304l-.459 2.066A1.75 1.75 0 0010.747 15H11a.75.75 0 000-1.5h-.253a.25.25 0 01-.244-.304l.459-2.066A1.75 1.75 0 009.253 9H9z", clipRule: "evenodd" })), dx = P.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 20 20", fill: "currentColor", height: "20", width: "20" }, P.createElement("path", { fillRule: "evenodd", d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-5a.75.75 0 01.75.75v4.5a.75.75 0 01-1.5 0v-4.5A.75.75 0 0110 5zm0 10a1 1 0 100-2 1 1 0 000 2z", clipRule: "evenodd" })), fx = P.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "12", height: "12", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round" }, P.createElement("line", { x1: "18", y1: "6", x2: "6", y2: "18" }), P.createElement("line", { x1: "6", y1: "6", x2: "18", y2: "18" })), px = () => {
  let [e, t] = P.useState(document.hidden);
  return P.useEffect(() => {
    let n = () => {
      t(document.hidden);
    };
    return document.addEventListener("visibilitychange", n), () => window.removeEventListener("visibilitychange", n);
  }, []), e;
}, Or = 1, mx = class {
  constructor() {
    this.subscribe = (e) => (this.subscribers.push(e), () => {
      let t = this.subscribers.indexOf(e);
      this.subscribers.splice(t, 1);
    }), this.publish = (e) => {
      this.subscribers.forEach((t) => t(e));
    }, this.addToast = (e) => {
      this.publish(e), this.toasts = [...this.toasts, e];
    }, this.create = (e) => {
      var t;
      let { message: n, ...r } = e, o = typeof (e == null ? void 0 : e.id) == "number" || ((t = e.id) == null ? void 0 : t.length) > 0 ? e.id : Or++, s = this.toasts.find((i) => i.id === o), a = e.dismissible === void 0 ? !0 : e.dismissible;
      return this.dismissedToasts.has(o) && this.dismissedToasts.delete(o), s ? this.toasts = this.toasts.map((i) => i.id === o ? (this.publish({ ...i, ...e, id: o, title: n }), { ...i, ...e, id: o, dismissible: a, title: n }) : i) : this.addToast({ title: n, ...r, dismissible: a, id: o }), o;
    }, this.dismiss = (e) => (this.dismissedToasts.add(e), e || this.toasts.forEach((t) => {
      this.subscribers.forEach((n) => n({ id: t.id, dismiss: !0 }));
    }), this.subscribers.forEach((t) => t({ id: e, dismiss: !0 })), e), this.message = (e, t) => this.create({ ...t, message: e }), this.error = (e, t) => this.create({ ...t, message: e, type: "error" }), this.success = (e, t) => this.create({ ...t, type: "success", message: e }), this.info = (e, t) => this.create({ ...t, type: "info", message: e }), this.warning = (e, t) => this.create({ ...t, type: "warning", message: e }), this.loading = (e, t) => this.create({ ...t, type: "loading", message: e }), this.promise = (e, t) => {
      if (!t) return;
      let n;
      t.loading !== void 0 && (n = this.create({ ...t, promise: e, type: "loading", message: t.loading, description: typeof t.description != "function" ? t.description : void 0 }));
      let r = e instanceof Promise ? e : e(), o = n !== void 0, s, a = r.then(async (l) => {
        if (s = ["resolve", l], P.isValidElement(l)) o = !1, this.create({ id: n, type: "default", message: l });
        else if (gx(l) && !l.ok) {
          o = !1;
          let c = typeof t.error == "function" ? await t.error(`HTTP error! status: ${l.status}`) : t.error, d = typeof t.description == "function" ? await t.description(`HTTP error! status: ${l.status}`) : t.description;
          this.create({ id: n, type: "error", message: c, description: d });
        } else if (t.success !== void 0) {
          o = !1;
          let c = typeof t.success == "function" ? await t.success(l) : t.success, d = typeof t.description == "function" ? await t.description(l) : t.description;
          this.create({ id: n, type: "success", message: c, description: d });
        }
      }).catch(async (l) => {
        if (s = ["reject", l], t.error !== void 0) {
          o = !1;
          let c = typeof t.error == "function" ? await t.error(l) : t.error, d = typeof t.description == "function" ? await t.description(l) : t.description;
          this.create({ id: n, type: "error", message: c, description: d });
        }
      }).finally(() => {
        var l;
        o && (this.dismiss(n), n = void 0), (l = t.finally) == null || l.call(t);
      }), i = () => new Promise((l, c) => a.then(() => s[0] === "reject" ? c(s[1]) : l(s[1])).catch(c));
      return typeof n != "string" && typeof n != "number" ? { unwrap: i } : Object.assign(n, { unwrap: i });
    }, this.custom = (e, t) => {
      let n = (t == null ? void 0 : t.id) || Or++;
      return this.create({ jsx: e(n), id: n, ...t }), n;
    }, this.getActiveToasts = () => this.toasts.filter((e) => !this.dismissedToasts.has(e.id)), this.subscribers = [], this.toasts = [], this.dismissedToasts = /* @__PURE__ */ new Set();
  }
}, we = new mx(), hx = (e, t) => {
  let n = (t == null ? void 0 : t.id) || Or++;
  return we.addToast({ title: e, ...t, id: n }), n;
}, gx = (e) => e && typeof e == "object" && "ok" in e && typeof e.ok == "boolean" && "status" in e && typeof e.status == "number", bx = hx, vx = () => we.toasts, xx = () => we.getActiveToasts(), it = Object.assign(bx, { success: we.success, info: we.info, warning: we.warning, error: we.error, custom: we.custom, message: we.message, promise: we.promise, dismiss: we.dismiss, loading: we.loading }, { getHistory: vx, getToasts: xx });
function yx(e, { insertAt: t } = {}) {
  if (typeof document > "u") return;
  let n = document.head || document.getElementsByTagName("head")[0], r = document.createElement("style");
  r.type = "text/css", t === "top" && n.firstChild ? n.insertBefore(r, n.firstChild) : n.appendChild(r), r.styleSheet ? r.styleSheet.cssText = e : r.appendChild(document.createTextNode(e));
}
yx(`:where(html[dir="ltr"]),:where([data-sonner-toaster][dir="ltr"]){--toast-icon-margin-start: -3px;--toast-icon-margin-end: 4px;--toast-svg-margin-start: -1px;--toast-svg-margin-end: 0px;--toast-button-margin-start: auto;--toast-button-margin-end: 0;--toast-close-button-start: 0;--toast-close-button-end: unset;--toast-close-button-transform: translate(-35%, -35%)}:where(html[dir="rtl"]),:where([data-sonner-toaster][dir="rtl"]){--toast-icon-margin-start: 4px;--toast-icon-margin-end: -3px;--toast-svg-margin-start: 0px;--toast-svg-margin-end: -1px;--toast-button-margin-start: 0;--toast-button-margin-end: auto;--toast-close-button-start: unset;--toast-close-button-end: 0;--toast-close-button-transform: translate(35%, -35%)}:where([data-sonner-toaster]){position:fixed;width:var(--width);font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;--gray1: hsl(0, 0%, 99%);--gray2: hsl(0, 0%, 97.3%);--gray3: hsl(0, 0%, 95.1%);--gray4: hsl(0, 0%, 93%);--gray5: hsl(0, 0%, 90.9%);--gray6: hsl(0, 0%, 88.7%);--gray7: hsl(0, 0%, 85.8%);--gray8: hsl(0, 0%, 78%);--gray9: hsl(0, 0%, 56.1%);--gray10: hsl(0, 0%, 52.3%);--gray11: hsl(0, 0%, 43.5%);--gray12: hsl(0, 0%, 9%);--border-radius: 8px;box-sizing:border-box;padding:0;margin:0;list-style:none;outline:none;z-index:999999999;transition:transform .4s ease}:where([data-sonner-toaster][data-lifted="true"]){transform:translateY(-10px)}@media (hover: none) and (pointer: coarse){:where([data-sonner-toaster][data-lifted="true"]){transform:none}}:where([data-sonner-toaster][data-x-position="right"]){right:var(--offset-right)}:where([data-sonner-toaster][data-x-position="left"]){left:var(--offset-left)}:where([data-sonner-toaster][data-x-position="center"]){left:50%;transform:translate(-50%)}:where([data-sonner-toaster][data-y-position="top"]){top:var(--offset-top)}:where([data-sonner-toaster][data-y-position="bottom"]){bottom:var(--offset-bottom)}:where([data-sonner-toast]){--y: translateY(100%);--lift-amount: calc(var(--lift) * var(--gap));z-index:var(--z-index);position:absolute;opacity:0;transform:var(--y);filter:blur(0);touch-action:none;transition:transform .4s,opacity .4s,height .4s,box-shadow .2s;box-sizing:border-box;outline:none;overflow-wrap:anywhere}:where([data-sonner-toast][data-styled="true"]){padding:16px;background:var(--normal-bg);border:1px solid var(--normal-border);color:var(--normal-text);border-radius:var(--border-radius);box-shadow:0 4px 12px #0000001a;width:var(--width);font-size:13px;display:flex;align-items:center;gap:6px}:where([data-sonner-toast]:focus-visible){box-shadow:0 4px 12px #0000001a,0 0 0 2px #0003}:where([data-sonner-toast][data-y-position="top"]){top:0;--y: translateY(-100%);--lift: 1;--lift-amount: calc(1 * var(--gap))}:where([data-sonner-toast][data-y-position="bottom"]){bottom:0;--y: translateY(100%);--lift: -1;--lift-amount: calc(var(--lift) * var(--gap))}:where([data-sonner-toast]) :where([data-description]){font-weight:400;line-height:1.4;color:inherit}:where([data-sonner-toast]) :where([data-title]){font-weight:500;line-height:1.5;color:inherit}:where([data-sonner-toast]) :where([data-icon]){display:flex;height:16px;width:16px;position:relative;justify-content:flex-start;align-items:center;flex-shrink:0;margin-left:var(--toast-icon-margin-start);margin-right:var(--toast-icon-margin-end)}:where([data-sonner-toast][data-promise="true"]) :where([data-icon])>svg{opacity:0;transform:scale(.8);transform-origin:center;animation:sonner-fade-in .3s ease forwards}:where([data-sonner-toast]) :where([data-icon])>*{flex-shrink:0}:where([data-sonner-toast]) :where([data-icon]) svg{margin-left:var(--toast-svg-margin-start);margin-right:var(--toast-svg-margin-end)}:where([data-sonner-toast]) :where([data-content]){display:flex;flex-direction:column;gap:2px}[data-sonner-toast][data-styled=true] [data-button]{border-radius:4px;padding-left:8px;padding-right:8px;height:24px;font-size:12px;color:var(--normal-bg);background:var(--normal-text);margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end);border:none;cursor:pointer;outline:none;display:flex;align-items:center;flex-shrink:0;transition:opacity .4s,box-shadow .2s}:where([data-sonner-toast]) :where([data-button]):focus-visible{box-shadow:0 0 0 2px #0006}:where([data-sonner-toast]) :where([data-button]):first-of-type{margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end)}:where([data-sonner-toast]) :where([data-cancel]){color:var(--normal-text);background:rgba(0,0,0,.08)}:where([data-sonner-toast][data-theme="dark"]) :where([data-cancel]){background:rgba(255,255,255,.3)}:where([data-sonner-toast]) :where([data-close-button]){position:absolute;left:var(--toast-close-button-start);right:var(--toast-close-button-end);top:0;height:20px;width:20px;display:flex;justify-content:center;align-items:center;padding:0;color:var(--gray12);border:1px solid var(--gray4);transform:var(--toast-close-button-transform);border-radius:50%;cursor:pointer;z-index:1;transition:opacity .1s,background .2s,border-color .2s}[data-sonner-toast] [data-close-button]{background:var(--gray1)}:where([data-sonner-toast]) :where([data-close-button]):focus-visible{box-shadow:0 4px 12px #0000001a,0 0 0 2px #0003}:where([data-sonner-toast]) :where([data-disabled="true"]){cursor:not-allowed}:where([data-sonner-toast]):hover :where([data-close-button]):hover{background:var(--gray2);border-color:var(--gray5)}:where([data-sonner-toast][data-swiping="true"]):before{content:"";position:absolute;left:-50%;right:-50%;height:100%;z-index:-1}:where([data-sonner-toast][data-y-position="top"][data-swiping="true"]):before{bottom:50%;transform:scaleY(3) translateY(50%)}:where([data-sonner-toast][data-y-position="bottom"][data-swiping="true"]):before{top:50%;transform:scaleY(3) translateY(-50%)}:where([data-sonner-toast][data-swiping="false"][data-removed="true"]):before{content:"";position:absolute;inset:0;transform:scaleY(2)}:where([data-sonner-toast]):after{content:"";position:absolute;left:0;height:calc(var(--gap) + 1px);bottom:100%;width:100%}:where([data-sonner-toast][data-mounted="true"]){--y: translateY(0);opacity:1}:where([data-sonner-toast][data-expanded="false"][data-front="false"]){--scale: var(--toasts-before) * .05 + 1;--y: translateY(calc(var(--lift-amount) * var(--toasts-before))) scale(calc(-1 * var(--scale)));height:var(--front-toast-height)}:where([data-sonner-toast])>*{transition:opacity .4s}:where([data-sonner-toast][data-expanded="false"][data-front="false"][data-styled="true"])>*{opacity:0}:where([data-sonner-toast][data-visible="false"]){opacity:0;pointer-events:none}:where([data-sonner-toast][data-mounted="true"][data-expanded="true"]){--y: translateY(calc(var(--lift) * var(--offset)));height:var(--initial-height)}:where([data-sonner-toast][data-removed="true"][data-front="true"][data-swipe-out="false"]){--y: translateY(calc(var(--lift) * -100%));opacity:0}:where([data-sonner-toast][data-removed="true"][data-front="false"][data-swipe-out="false"][data-expanded="true"]){--y: translateY(calc(var(--lift) * var(--offset) + var(--lift) * -100%));opacity:0}:where([data-sonner-toast][data-removed="true"][data-front="false"][data-swipe-out="false"][data-expanded="false"]){--y: translateY(40%);opacity:0;transition:transform .5s,opacity .2s}:where([data-sonner-toast][data-removed="true"][data-front="false"]):before{height:calc(var(--initial-height) + 20%)}[data-sonner-toast][data-swiping=true]{transform:var(--y) translateY(var(--swipe-amount-y, 0px)) translate(var(--swipe-amount-x, 0px));transition:none}[data-sonner-toast][data-swiped=true]{user-select:none}[data-sonner-toast][data-swipe-out=true][data-y-position=bottom],[data-sonner-toast][data-swipe-out=true][data-y-position=top]{animation-duration:.2s;animation-timing-function:ease-out;animation-fill-mode:forwards}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=left]{animation-name:swipe-out-left}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=right]{animation-name:swipe-out-right}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=up]{animation-name:swipe-out-up}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=down]{animation-name:swipe-out-down}@keyframes swipe-out-left{0%{transform:var(--y) translate(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translate(calc(var(--swipe-amount-x) - 100%));opacity:0}}@keyframes swipe-out-right{0%{transform:var(--y) translate(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translate(calc(var(--swipe-amount-x) + 100%));opacity:0}}@keyframes swipe-out-up{0%{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) - 100%));opacity:0}}@keyframes swipe-out-down{0%{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) + 100%));opacity:0}}@media (max-width: 600px){[data-sonner-toaster]{position:fixed;right:var(--mobile-offset-right);left:var(--mobile-offset-left);width:100%}[data-sonner-toaster][dir=rtl]{left:calc(var(--mobile-offset-left) * -1)}[data-sonner-toaster] [data-sonner-toast]{left:0;right:0;width:calc(100% - var(--mobile-offset-left) * 2)}[data-sonner-toaster][data-x-position=left]{left:var(--mobile-offset-left)}[data-sonner-toaster][data-y-position=bottom]{bottom:var(--mobile-offset-bottom)}[data-sonner-toaster][data-y-position=top]{top:var(--mobile-offset-top)}[data-sonner-toaster][data-x-position=center]{left:var(--mobile-offset-left);right:var(--mobile-offset-right);transform:none}}[data-sonner-toaster][data-theme=light]{--normal-bg: #fff;--normal-border: var(--gray4);--normal-text: var(--gray12);--success-bg: hsl(143, 85%, 96%);--success-border: hsl(145, 92%, 91%);--success-text: hsl(140, 100%, 27%);--info-bg: hsl(208, 100%, 97%);--info-border: hsl(221, 91%, 91%);--info-text: hsl(210, 92%, 45%);--warning-bg: hsl(49, 100%, 97%);--warning-border: hsl(49, 91%, 91%);--warning-text: hsl(31, 92%, 45%);--error-bg: hsl(359, 100%, 97%);--error-border: hsl(359, 100%, 94%);--error-text: hsl(360, 100%, 45%)}[data-sonner-toaster][data-theme=light] [data-sonner-toast][data-invert=true]{--normal-bg: #000;--normal-border: hsl(0, 0%, 20%);--normal-text: var(--gray1)}[data-sonner-toaster][data-theme=dark] [data-sonner-toast][data-invert=true]{--normal-bg: #fff;--normal-border: var(--gray3);--normal-text: var(--gray12)}[data-sonner-toaster][data-theme=dark]{--normal-bg: #000;--normal-bg-hover: hsl(0, 0%, 12%);--normal-border: hsl(0, 0%, 20%);--normal-border-hover: hsl(0, 0%, 25%);--normal-text: var(--gray1);--success-bg: hsl(150, 100%, 6%);--success-border: hsl(147, 100%, 12%);--success-text: hsl(150, 86%, 65%);--info-bg: hsl(215, 100%, 6%);--info-border: hsl(223, 100%, 12%);--info-text: hsl(216, 87%, 65%);--warning-bg: hsl(64, 100%, 6%);--warning-border: hsl(60, 100%, 12%);--warning-text: hsl(46, 87%, 65%);--error-bg: hsl(358, 76%, 10%);--error-border: hsl(357, 89%, 16%);--error-text: hsl(358, 100%, 81%)}[data-sonner-toaster][data-theme=dark] [data-sonner-toast] [data-close-button]{background:var(--normal-bg);border-color:var(--normal-border);color:var(--normal-text)}[data-sonner-toaster][data-theme=dark] [data-sonner-toast] [data-close-button]:hover{background:var(--normal-bg-hover);border-color:var(--normal-border-hover)}[data-rich-colors=true][data-sonner-toast][data-type=success],[data-rich-colors=true][data-sonner-toast][data-type=success] [data-close-button]{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}[data-rich-colors=true][data-sonner-toast][data-type=info],[data-rich-colors=true][data-sonner-toast][data-type=info] [data-close-button]{background:var(--info-bg);border-color:var(--info-border);color:var(--info-text)}[data-rich-colors=true][data-sonner-toast][data-type=warning],[data-rich-colors=true][data-sonner-toast][data-type=warning] [data-close-button]{background:var(--warning-bg);border-color:var(--warning-border);color:var(--warning-text)}[data-rich-colors=true][data-sonner-toast][data-type=error],[data-rich-colors=true][data-sonner-toast][data-type=error] [data-close-button]{background:var(--error-bg);border-color:var(--error-border);color:var(--error-text)}.sonner-loading-wrapper{--size: 16px;height:var(--size);width:var(--size);position:absolute;inset:0;z-index:10}.sonner-loading-wrapper[data-visible=false]{transform-origin:center;animation:sonner-fade-out .2s ease forwards}.sonner-spinner{position:relative;top:50%;left:50%;height:var(--size);width:var(--size)}.sonner-loading-bar{animation:sonner-spin 1.2s linear infinite;background:var(--gray11);border-radius:6px;height:8%;left:-10%;position:absolute;top:-3.9%;width:24%}.sonner-loading-bar:nth-child(1){animation-delay:-1.2s;transform:rotate(.0001deg) translate(146%)}.sonner-loading-bar:nth-child(2){animation-delay:-1.1s;transform:rotate(30deg) translate(146%)}.sonner-loading-bar:nth-child(3){animation-delay:-1s;transform:rotate(60deg) translate(146%)}.sonner-loading-bar:nth-child(4){animation-delay:-.9s;transform:rotate(90deg) translate(146%)}.sonner-loading-bar:nth-child(5){animation-delay:-.8s;transform:rotate(120deg) translate(146%)}.sonner-loading-bar:nth-child(6){animation-delay:-.7s;transform:rotate(150deg) translate(146%)}.sonner-loading-bar:nth-child(7){animation-delay:-.6s;transform:rotate(180deg) translate(146%)}.sonner-loading-bar:nth-child(8){animation-delay:-.5s;transform:rotate(210deg) translate(146%)}.sonner-loading-bar:nth-child(9){animation-delay:-.4s;transform:rotate(240deg) translate(146%)}.sonner-loading-bar:nth-child(10){animation-delay:-.3s;transform:rotate(270deg) translate(146%)}.sonner-loading-bar:nth-child(11){animation-delay:-.2s;transform:rotate(300deg) translate(146%)}.sonner-loading-bar:nth-child(12){animation-delay:-.1s;transform:rotate(330deg) translate(146%)}@keyframes sonner-fade-in{0%{opacity:0;transform:scale(.8)}to{opacity:1;transform:scale(1)}}@keyframes sonner-fade-out{0%{opacity:1;transform:scale(1)}to{opacity:0;transform:scale(.8)}}@keyframes sonner-spin{0%{opacity:1}to{opacity:.15}}@media (prefers-reduced-motion){[data-sonner-toast],[data-sonner-toast]>*,.sonner-loading-bar{transition:none!important;animation:none!important}}.sonner-loader{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);transform-origin:center;transition:opacity .2s,transform .2s}.sonner-loader[data-visible=false]{opacity:0;transform:scale(.8) translate(-50%,-50%)}
`);
function bn(e) {
  return e.label !== void 0;
}
var wx = 3, Cx = "32px", Sx = "16px", ea = 4e3, Ex = 356, kx = 14, Px = 20, Rx = 200;
function Le(...e) {
  return e.filter(Boolean).join(" ");
}
function Ax(e) {
  let [t, n] = e.split("-"), r = [];
  return t && r.push(t), n && r.push(n), r;
}
var Nx = (e) => {
  var t, n, r, o, s, a, i, l, c, d, f;
  let { invert: p, toast: u, unstyled: g, interacting: b, setHeights: x, visibleToasts: v, heights: y, index: S, toasts: C, expanded: k, removeToast: E, defaultRichColors: w, closeButton: R, style: T, cancelButtonStyle: I, actionButtonStyle: A, className: N = "", descriptionClassName: _ = "", duration: O, position: M, gap: L, loadingIcon: V, expandByDefault: W, classNames: B, icons: te, closeButtonAriaLabel: re = "Close toast", pauseWhenPageIsHidden: J } = e, [j, F] = P.useState(null), [U, K] = P.useState(null), [z, G] = P.useState(!1), [X, Q] = P.useState(!1), [Z, H] = P.useState(!1), [Y, oe] = P.useState(!1), [ue, ge] = P.useState(!1), [ve, ie] = P.useState(0), [be, Pe] = P.useState(0), xe = P.useRef(u.duration || O || ea), Ye = P.useRef(null), Ce = P.useRef(null), ln = S === 0, cn = S + 1 <= v, ye = u.type, Xe = u.dismissible !== !1, sr = u.className || "", _t = u.descriptionClassName || "", Ne = P.useMemo(() => y.findIndex((q) => q.toastId === u.id) || 0, [y, u.id]), $t = P.useMemo(() => {
    var q;
    return (q = u.closeButton) != null ? q : R;
  }, [u.closeButton, R]), St = P.useMemo(() => u.duration || O || ea, [u.duration, O]), et = P.useRef(0), tt = P.useRef(0), un = P.useRef(0), nt = P.useRef(null), [ar, ir] = M.split("-"), Ft = P.useMemo(() => y.reduce((q, se, ce) => ce >= Ne ? q : q + se.height, 0), [y, Ne]), dn = px(), fn = u.invert || p, Et = ye === "loading";
  tt.current = P.useMemo(() => Ne * L + Ft, [Ne, Ft]), P.useEffect(() => {
    xe.current = St;
  }, [St]), P.useEffect(() => {
    G(!0);
  }, []), P.useEffect(() => {
    let q = Ce.current;
    if (q) {
      let se = q.getBoundingClientRect().height;
      return Pe(se), x((ce) => [{ toastId: u.id, height: se, position: u.position }, ...ce]), () => x((ce) => ce.filter((je) => je.toastId !== u.id));
    }
  }, [x, u.id]), P.useLayoutEffect(() => {
    if (!z) return;
    let q = Ce.current, se = q.style.height;
    q.style.height = "auto";
    let ce = q.getBoundingClientRect().height;
    q.style.height = se, Pe(ce), x((je) => je.find((Ie) => Ie.toastId === u.id) ? je.map((Ie) => Ie.toastId === u.id ? { ...Ie, height: ce } : Ie) : [{ toastId: u.id, height: ce, position: u.position }, ...je]);
  }, [z, u.title, u.description, x, u.id]);
  let Te = P.useCallback(() => {
    Q(!0), ie(tt.current), x((q) => q.filter((se) => se.toastId !== u.id)), setTimeout(() => {
      E(u);
    }, Rx);
  }, [u, E, x, tt]);
  P.useEffect(() => {
    if (u.promise && ye === "loading" || u.duration === 1 / 0 || u.type === "loading") return;
    let q;
    return k || b || J && dn ? (() => {
      if (un.current < et.current) {
        let se = (/* @__PURE__ */ new Date()).getTime() - et.current;
        xe.current = xe.current - se;
      }
      un.current = (/* @__PURE__ */ new Date()).getTime();
    })() : xe.current !== 1 / 0 && (et.current = (/* @__PURE__ */ new Date()).getTime(), q = setTimeout(() => {
      var se;
      (se = u.onAutoClose) == null || se.call(u, u), Te();
    }, xe.current)), () => clearTimeout(q);
  }, [k, b, u, ye, J, dn, Te]), P.useEffect(() => {
    u.delete && Te();
  }, [Te, u.delete]);
  function lr() {
    var q, se, ce;
    return te != null && te.loading ? P.createElement("div", { className: Le(B == null ? void 0 : B.loader, (q = u == null ? void 0 : u.classNames) == null ? void 0 : q.loader, "sonner-loader"), "data-visible": ye === "loading" }, te.loading) : V ? P.createElement("div", { className: Le(B == null ? void 0 : B.loader, (se = u == null ? void 0 : u.classNames) == null ? void 0 : se.loader, "sonner-loader"), "data-visible": ye === "loading" }, V) : P.createElement(ix, { className: Le(B == null ? void 0 : B.loader, (ce = u == null ? void 0 : u.classNames) == null ? void 0 : ce.loader), visible: ye === "loading" });
  }
  return P.createElement("li", { tabIndex: 0, ref: Ce, className: Le(N, sr, B == null ? void 0 : B.toast, (t = u == null ? void 0 : u.classNames) == null ? void 0 : t.toast, B == null ? void 0 : B.default, B == null ? void 0 : B[ye], (n = u == null ? void 0 : u.classNames) == null ? void 0 : n[ye]), "data-sonner-toast": "", "data-rich-colors": (r = u.richColors) != null ? r : w, "data-styled": !(u.jsx || u.unstyled || g), "data-mounted": z, "data-promise": !!u.promise, "data-swiped": ue, "data-removed": X, "data-visible": cn, "data-y-position": ar, "data-x-position": ir, "data-index": S, "data-front": ln, "data-swiping": Z, "data-dismissible": Xe, "data-type": ye, "data-invert": fn, "data-swipe-out": Y, "data-swipe-direction": U, "data-expanded": !!(k || W && z), style: { "--index": S, "--toasts-before": S, "--z-index": C.length - S, "--offset": `${X ? ve : tt.current}px`, "--initial-height": W ? "auto" : `${be}px`, ...T, ...u.style }, onDragEnd: () => {
    H(!1), F(null), nt.current = null;
  }, onPointerDown: (q) => {
    Et || !Xe || (Ye.current = /* @__PURE__ */ new Date(), ie(tt.current), q.target.setPointerCapture(q.pointerId), q.target.tagName !== "BUTTON" && (H(!0), nt.current = { x: q.clientX, y: q.clientY }));
  }, onPointerUp: () => {
    var q, se, ce, je;
    if (Y || !Xe) return;
    nt.current = null;
    let Ie = Number(((q = Ce.current) == null ? void 0 : q.style.getPropertyValue("--swipe-amount-x").replace("px", "")) || 0), rt = Number(((se = Ce.current) == null ? void 0 : se.style.getPropertyValue("--swipe-amount-y").replace("px", "")) || 0), mt = (/* @__PURE__ */ new Date()).getTime() - ((ce = Ye.current) == null ? void 0 : ce.getTime()), Me = j === "x" ? Ie : rt, ot = Math.abs(Me) / mt;
    if (Math.abs(Me) >= Px || ot > 0.11) {
      ie(tt.current), (je = u.onDismiss) == null || je.call(u, u), K(j === "x" ? Ie > 0 ? "right" : "left" : rt > 0 ? "down" : "up"), Te(), oe(!0), ge(!1);
      return;
    }
    H(!1), F(null);
  }, onPointerMove: (q) => {
    var se, ce, je, Ie;
    if (!nt.current || !Xe || ((se = window.getSelection()) == null ? void 0 : se.toString().length) > 0) return;
    let rt = q.clientY - nt.current.y, mt = q.clientX - nt.current.x, Me = (ce = e.swipeDirections) != null ? ce : Ax(M);
    !j && (Math.abs(mt) > 1 || Math.abs(rt) > 1) && F(Math.abs(mt) > Math.abs(rt) ? "x" : "y");
    let ot = { x: 0, y: 0 };
    j === "y" ? (Me.includes("top") || Me.includes("bottom")) && (Me.includes("top") && rt < 0 || Me.includes("bottom") && rt > 0) && (ot.y = rt) : j === "x" && (Me.includes("left") || Me.includes("right")) && (Me.includes("left") && mt < 0 || Me.includes("right") && mt > 0) && (ot.x = mt), (Math.abs(ot.x) > 0 || Math.abs(ot.y) > 0) && ge(!0), (je = Ce.current) == null || je.style.setProperty("--swipe-amount-x", `${ot.x}px`), (Ie = Ce.current) == null || Ie.style.setProperty("--swipe-amount-y", `${ot.y}px`);
  } }, $t && !u.jsx ? P.createElement("button", { "aria-label": re, "data-disabled": Et, "data-close-button": !0, onClick: Et || !Xe ? () => {
  } : () => {
    var q;
    Te(), (q = u.onDismiss) == null || q.call(u, u);
  }, className: Le(B == null ? void 0 : B.closeButton, (o = u == null ? void 0 : u.classNames) == null ? void 0 : o.closeButton) }, (s = te == null ? void 0 : te.close) != null ? s : fx) : null, u.jsx || h.isValidElement(u.title) ? u.jsx ? u.jsx : typeof u.title == "function" ? u.title() : u.title : P.createElement(P.Fragment, null, ye || u.icon || u.promise ? P.createElement("div", { "data-icon": "", className: Le(B == null ? void 0 : B.icon, (a = u == null ? void 0 : u.classNames) == null ? void 0 : a.icon) }, u.promise || u.type === "loading" && !u.icon ? u.icon || lr() : null, u.type !== "loading" ? u.icon || (te == null ? void 0 : te[ye]) || sx(ye) : null) : null, P.createElement("div", { "data-content": "", className: Le(B == null ? void 0 : B.content, (i = u == null ? void 0 : u.classNames) == null ? void 0 : i.content) }, P.createElement("div", { "data-title": "", className: Le(B == null ? void 0 : B.title, (l = u == null ? void 0 : u.classNames) == null ? void 0 : l.title) }, typeof u.title == "function" ? u.title() : u.title), u.description ? P.createElement("div", { "data-description": "", className: Le(_, _t, B == null ? void 0 : B.description, (c = u == null ? void 0 : u.classNames) == null ? void 0 : c.description) }, typeof u.description == "function" ? u.description() : u.description) : null), h.isValidElement(u.cancel) ? u.cancel : u.cancel && bn(u.cancel) ? P.createElement("button", { "data-button": !0, "data-cancel": !0, style: u.cancelButtonStyle || I, onClick: (q) => {
    var se, ce;
    bn(u.cancel) && Xe && ((ce = (se = u.cancel).onClick) == null || ce.call(se, q), Te());
  }, className: Le(B == null ? void 0 : B.cancelButton, (d = u == null ? void 0 : u.classNames) == null ? void 0 : d.cancelButton) }, u.cancel.label) : null, h.isValidElement(u.action) ? u.action : u.action && bn(u.action) ? P.createElement("button", { "data-button": !0, "data-action": !0, style: u.actionButtonStyle || A, onClick: (q) => {
    var se, ce;
    bn(u.action) && ((ce = (se = u.action).onClick) == null || ce.call(se, q), !q.defaultPrevented && Te());
  }, className: Le(B == null ? void 0 : B.actionButton, (f = u == null ? void 0 : u.classNames) == null ? void 0 : f.actionButton) }, u.action.label) : null));
};
function ta() {
  if (typeof window > "u" || typeof document > "u") return "ltr";
  let e = document.documentElement.getAttribute("dir");
  return e === "auto" || !e ? window.getComputedStyle(document.documentElement).direction : e;
}
function Tx(e, t) {
  let n = {};
  return [e, t].forEach((r, o) => {
    let s = o === 1, a = s ? "--mobile-offset" : "--offset", i = s ? Sx : Cx;
    function l(c) {
      ["top", "right", "bottom", "left"].forEach((d) => {
        n[`${a}-${d}`] = typeof c == "number" ? `${c}px` : c;
      });
    }
    typeof r == "number" || typeof r == "string" ? l(r) : typeof r == "object" ? ["top", "right", "bottom", "left"].forEach((c) => {
      r[c] === void 0 ? n[`${a}-${c}`] = i : n[`${a}-${c}`] = typeof r[c] == "number" ? `${r[c]}px` : r[c];
    }) : l(i);
  }), n;
}
var Hl = h.forwardRef(function(e, t) {
  let { invert: n, position: r = "bottom-right", hotkey: o = ["altKey", "KeyT"], expand: s, closeButton: a, className: i, offset: l, mobileOffset: c, theme: d = "light", richColors: f, duration: p, style: u, visibleToasts: g = wx, toastOptions: b, dir: x = ta(), gap: v = kx, loadingIcon: y, icons: S, containerAriaLabel: C = "Notifications", pauseWhenPageIsHidden: k } = e, [E, w] = P.useState([]), R = P.useMemo(() => Array.from(new Set([r].concat(E.filter((J) => J.position).map((J) => J.position)))), [E, r]), [T, I] = P.useState([]), [A, N] = P.useState(!1), [_, O] = P.useState(!1), [M, L] = P.useState(d !== "system" ? d : typeof window < "u" && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"), V = P.useRef(null), W = o.join("+").replace(/Key/g, "").replace(/Digit/g, ""), B = P.useRef(null), te = P.useRef(!1), re = P.useCallback((J) => {
    w((j) => {
      var F;
      return (F = j.find((U) => U.id === J.id)) != null && F.delete || we.dismiss(J.id), j.filter(({ id: U }) => U !== J.id);
    });
  }, []);
  return P.useEffect(() => we.subscribe((J) => {
    if (J.dismiss) {
      w((j) => j.map((F) => F.id === J.id ? { ...F, delete: !0 } : F));
      return;
    }
    setTimeout(() => {
      zn.flushSync(() => {
        w((j) => {
          let F = j.findIndex((U) => U.id === J.id);
          return F !== -1 ? [...j.slice(0, F), { ...j[F], ...J }, ...j.slice(F + 1)] : [J, ...j];
        });
      });
    });
  }), []), P.useEffect(() => {
    if (d !== "system") {
      L(d);
      return;
    }
    if (d === "system" && (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? L("dark") : L("light")), typeof window > "u") return;
    let J = window.matchMedia("(prefers-color-scheme: dark)");
    try {
      J.addEventListener("change", ({ matches: j }) => {
        L(j ? "dark" : "light");
      });
    } catch {
      J.addListener(({ matches: F }) => {
        try {
          L(F ? "dark" : "light");
        } catch (U) {
          console.error(U);
        }
      });
    }
  }, [d]), P.useEffect(() => {
    E.length <= 1 && N(!1);
  }, [E]), P.useEffect(() => {
    let J = (j) => {
      var F, U;
      o.every((K) => j[K] || j.code === K) && (N(!0), (F = V.current) == null || F.focus()), j.code === "Escape" && (document.activeElement === V.current || (U = V.current) != null && U.contains(document.activeElement)) && N(!1);
    };
    return document.addEventListener("keydown", J), () => document.removeEventListener("keydown", J);
  }, [o]), P.useEffect(() => {
    if (V.current) return () => {
      B.current && (B.current.focus({ preventScroll: !0 }), B.current = null, te.current = !1);
    };
  }, [V.current]), P.createElement("section", { ref: t, "aria-label": `${C} ${W}`, tabIndex: -1, "aria-live": "polite", "aria-relevant": "additions text", "aria-atomic": "false", suppressHydrationWarning: !0 }, R.map((J, j) => {
    var F;
    let [U, K] = J.split("-");
    return E.length ? P.createElement("ol", { key: J, dir: x === "auto" ? ta() : x, tabIndex: -1, ref: V, className: i, "data-sonner-toaster": !0, "data-theme": M, "data-y-position": U, "data-lifted": A && E.length > 1 && !s, "data-x-position": K, style: { "--front-toast-height": `${((F = T[0]) == null ? void 0 : F.height) || 0}px`, "--width": `${Ex}px`, "--gap": `${v}px`, ...u, ...Tx(l, c) }, onBlur: (z) => {
      te.current && !z.currentTarget.contains(z.relatedTarget) && (te.current = !1, B.current && (B.current.focus({ preventScroll: !0 }), B.current = null));
    }, onFocus: (z) => {
      z.target instanceof HTMLElement && z.target.dataset.dismissible === "false" || te.current || (te.current = !0, B.current = z.relatedTarget);
    }, onMouseEnter: () => N(!0), onMouseMove: () => N(!0), onMouseLeave: () => {
      _ || N(!1);
    }, onDragEnd: () => N(!1), onPointerDown: (z) => {
      z.target instanceof HTMLElement && z.target.dataset.dismissible === "false" || O(!0);
    }, onPointerUp: () => O(!1) }, E.filter((z) => !z.position && j === 0 || z.position === J).map((z, G) => {
      var X, Q;
      return P.createElement(Nx, { key: z.id, icons: S, index: G, toast: z, defaultRichColors: f, duration: (X = b == null ? void 0 : b.duration) != null ? X : p, className: b == null ? void 0 : b.className, descriptionClassName: b == null ? void 0 : b.descriptionClassName, invert: n, visibleToasts: g, closeButton: (Q = b == null ? void 0 : b.closeButton) != null ? Q : a, interacting: _, position: J, style: b == null ? void 0 : b.style, unstyled: b == null ? void 0 : b.unstyled, classNames: b == null ? void 0 : b.classNames, cancelButtonStyle: b == null ? void 0 : b.cancelButtonStyle, actionButtonStyle: b == null ? void 0 : b.actionButtonStyle, removeToast: re, toasts: E.filter((Z) => Z.position == z.position), heights: T.filter((Z) => Z.position == z.position), setHeights: I, expandByDefault: s, gap: v, loadingIcon: y, expanded: A, pauseWhenPageIsHidden: k, swipeDirections: e.swipeDirections });
    })) : null;
  }));
});
function jx({
  orientation: e = "horizontal",
  decorative: t = !0,
  className: n,
  ...r
}) {
  return /* @__PURE__ */ m.jsx(
    Ib,
    {
      decorative: t,
      orientation: e,
      className: D(
        "shrink-0 bg-border",
        e === "horizontal" ? "h-[1px] w-full" : "h-full w-[1px]",
        n
      ),
      ...r
    }
  );
}
function Ix({
  ratio: e = 16 / 9,
  className: t,
  children: n,
  ...r
}) {
  return /* @__PURE__ */ m.jsx(zb, { ratio: e, className: t, ...r, children: n });
}
function Mx({
  type: e = "hover",
  scrollHideDelay: t = 600,
  className: n,
  children: r,
  ...o
}) {
  return /* @__PURE__ */ m.jsxs(
    Xb,
    {
      type: e,
      scrollHideDelay: t,
      className: D("relative overflow-hidden", n),
      ...o,
      children: [
        /* @__PURE__ */ m.jsx(qb, { className: "h-full w-full rounded-[inherit]", children: r }),
        /* @__PURE__ */ m.jsx(
          Fs,
          {
            orientation: "vertical",
            className: D(
              "flex touch-none select-none transition-colors",
              "h-full w-2.5 border-l border-l-transparent p-[1px]"
            ),
            children: /* @__PURE__ */ m.jsx(
              Bs,
              {
                className: D(
                  "relative flex-1 rounded-full bg-border",
                  "before:absolute before:left-1/2 before:top-1/2",
                  "before:h-full before:min-h-[44px] before:w-full before:min-w-[44px]",
                  'before:-translate-x-1/2 before:-translate-y-1/2 before:content-[""]'
                )
              }
            )
          }
        ),
        /* @__PURE__ */ m.jsx(
          Fs,
          {
            orientation: "horizontal",
            className: D(
              "flex touch-none select-none transition-colors",
              "h-2.5 flex-col border-t border-t-transparent p-[1px]"
            ),
            children: /* @__PURE__ */ m.jsx(
              Bs,
              {
                className: D(
                  "relative flex-1 rounded-full bg-border",
                  "before:absolute before:left-1/2 before:top-1/2",
                  "before:h-full before:min-h-[44px] before:w-full before:min-w-[44px]",
                  'before:-translate-x-1/2 before:-translate-y-1/2 before:content-[""]'
                )
              }
            )
          }
        ),
        /* @__PURE__ */ m.jsx(Jb, {})
      ]
    }
  );
}
const Lx = Bi, Vl = h.forwardRef(({ children: e, ...t }, n) => {
  const r = Array.isArray(e) && e.length === 1 ? e[0] : e;
  return /* @__PURE__ */ m.jsx(io, { ref: n, ...t, children: r });
});
Vl.displayName = io.displayName;
const Wl = h.forwardRef(({ className: e, children: t, ...n }, r) => /* @__PURE__ */ m.jsx(
  lo,
  {
    ref: r,
    className: D(
      "data-[state=closed]:animate-collapsible-up data-[state=open]:animate-collapsible-down overflow-hidden",
      e
    ),
    ...n,
    children: t
  }
));
Wl.displayName = lo.displayName;
const Gl = h.createContext(null);
function ko() {
  const e = h.useContext(Gl);
  if (!e)
    throw new Error("useCarousel must be used within a <Carousel />");
  return e;
}
function Dx({
  orientation: e = "horizontal",
  opts: t,
  className: n,
  children: r,
  ...o
}) {
  const [s, a] = Eo({
    ...t,
    axis: e === "horizontal" ? "x" : "y"
  }), [i, l] = h.useState(!1), [c, d] = h.useState(!1), f = h.useCallback((g) => {
    g && (l(g.canScrollPrev()), d(g.canScrollNext()));
  }, []), p = h.useCallback(() => {
    a == null || a.scrollPrev();
  }, [a]), u = h.useCallback(() => {
    a == null || a.scrollNext();
  }, [a]);
  return h.useEffect(() => {
    if (a)
      return f(a), a.on("reInit", f), a.on("select", f), () => {
        a == null || a.off("select", f);
      };
  }, [a, f]), /* @__PURE__ */ m.jsx(
    Gl.Provider,
    {
      value: {
        carouselRef: s,
        api: a,
        scrollPrev: p,
        scrollNext: u,
        canScrollPrev: i,
        canScrollNext: c
      },
      children: /* @__PURE__ */ m.jsx(
        "div",
        {
          className: D("relative", n),
          role: "region",
          "aria-roledescription": "carousel",
          ...o,
          children: r
        }
      )
    }
  );
}
function zx({
  className: e,
  children: t,
  ...n
}) {
  const { carouselRef: r } = ko();
  return /* @__PURE__ */ m.jsx("div", { ref: r, className: "overflow-hidden", children: /* @__PURE__ */ m.jsx("div", { className: D("flex", e), ...n, children: t }) });
}
function Ox({
  className: e,
  children: t,
  ...n
}) {
  return /* @__PURE__ */ m.jsx(
    "div",
    {
      role: "group",
      "aria-roledescription": "slide",
      className: D("min-w-0 shrink-0 grow-0 basis-full", e),
      ...n,
      children: t
    }
  );
}
function _x({
  className: e,
  onClick: t,
  ...n
}) {
  const { scrollPrev: r, canScrollPrev: o } = ko();
  return /* @__PURE__ */ m.jsxs(
    "button",
    {
      type: "button",
      className: D(
        "absolute left-2 top-1/2 -translate-y-1/2 z-10",
        "inline-flex h-8 w-8 items-center justify-center rounded-full",
        "border bg-background shadow-sm",
        "disabled:pointer-events-none disabled:opacity-50",
        "hover:bg-accent hover:text-accent-foreground",
        e
      ),
      disabled: !o,
      onClick: () => {
        r(), t == null || t();
      },
      ...n,
      children: [
        /* @__PURE__ */ m.jsx(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "h-4 w-4",
            children: /* @__PURE__ */ m.jsx("polyline", { points: "15 18 9 12 15 6" })
          }
        ),
        /* @__PURE__ */ m.jsx("span", { className: "sr-only", children: "Previous slide" })
      ]
    }
  );
}
function $x({
  className: e,
  onClick: t,
  ...n
}) {
  const { scrollNext: r, canScrollNext: o } = ko();
  return /* @__PURE__ */ m.jsxs(
    "button",
    {
      type: "button",
      className: D(
        "absolute right-2 top-1/2 -translate-y-1/2 z-10",
        "inline-flex h-8 w-8 items-center justify-center rounded-full",
        "border bg-background shadow-sm",
        "disabled:pointer-events-none disabled:opacity-50",
        "hover:bg-accent hover:text-accent-foreground",
        e
      ),
      disabled: !o,
      onClick: () => {
        r(), t == null || t();
      },
      ...n,
      children: [
        /* @__PURE__ */ m.jsx(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "h-4 w-4",
            children: /* @__PURE__ */ m.jsx("polyline", { points: "9 18 15 12 9 6" })
          }
        ),
        /* @__PURE__ */ m.jsx("span", { className: "sr-only", children: "Next slide" })
      ]
    }
  );
}
function Fx({
  className: e,
  ...t
}) {
  return /* @__PURE__ */ m.jsx(
    Ol,
    {
      className: D(
        "flex h-full w-full data-[panel-group-direction=vertical]:flex-col",
        e
      ),
      ...t
    }
  );
}
function Bx({
  className: e,
  defaultSize: t,
  minSize: n,
  maxSize: r,
  ...o
}) {
  return /* @__PURE__ */ m.jsx(
    xl,
    {
      className: D(e),
      defaultSize: t ?? void 0,
      minSize: n ?? void 0,
      maxSize: r ?? void 0,
      ...o
    }
  );
}
function Hx({
  withHandle: e,
  className: t,
  ...n
}) {
  return /* @__PURE__ */ m.jsx(
    _l,
    {
      className: D(
        "relative flex w-px items-center justify-center bg-border after:absolute after:inset-y-0 after:left-1/2 after:w-1 after:-translate-x-1/2 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring focus-visible:ring-offset-1 data-[panel-group-direction=vertical]:h-px data-[panel-group-direction=vertical]:w-full data-[panel-group-direction=vertical]:after:left-0 data-[panel-group-direction=vertical]:after:h-1 data-[panel-group-direction=vertical]:after:w-full data-[panel-group-direction=vertical]:after:-translate-y-1/2 data-[panel-group-direction=vertical]:after:translate-x-0 [&[data-panel-group-direction=vertical]>div]:rotate-90",
        t
      ),
      ...n,
      children: e && /* @__PURE__ */ m.jsx("div", { className: "z-10 flex h-4 w-3 items-center justify-center rounded-sm border bg-border", children: /* @__PURE__ */ m.jsx(ca, { className: "h-2.5 w-2.5" }) })
    }
  );
}
function wr({ className: e }) {
  return /* @__PURE__ */ m.jsxs(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      width: "24",
      height: "24",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      className: e,
      children: [
        /* @__PURE__ */ m.jsx("circle", { cx: "12", cy: "12", r: "4" }),
        /* @__PURE__ */ m.jsx("path", { d: "M12 2v2" }),
        /* @__PURE__ */ m.jsx("path", { d: "M12 20v2" }),
        /* @__PURE__ */ m.jsx("path", { d: "m4.93 4.93 1.41 1.41" }),
        /* @__PURE__ */ m.jsx("path", { d: "m17.66 17.66 1.41 1.41" }),
        /* @__PURE__ */ m.jsx("path", { d: "M2 12h2" }),
        /* @__PURE__ */ m.jsx("path", { d: "M20 12h2" }),
        /* @__PURE__ */ m.jsx("path", { d: "m6.34 17.66-1.41 1.41" }),
        /* @__PURE__ */ m.jsx("path", { d: "m19.07 4.93-1.41 1.41" })
      ]
    }
  );
}
function Cr({ className: e }) {
  return /* @__PURE__ */ m.jsx(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      width: "24",
      height: "24",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      className: e,
      children: /* @__PURE__ */ m.jsx("path", { d: "M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" })
    }
  );
}
function Vx({ className: e }) {
  return /* @__PURE__ */ m.jsxs(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      width: "24",
      height: "24",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      className: e,
      children: [
        /* @__PURE__ */ m.jsx("rect", { width: "20", height: "14", x: "2", y: "3", rx: "2" }),
        /* @__PURE__ */ m.jsx("line", { x1: "8", x2: "16", y1: "21", y2: "21" }),
        /* @__PURE__ */ m.jsx("line", { x1: "12", x2: "12", y1: "17", y2: "21" })
      ]
    }
  );
}
function _r() {
  return typeof window > "u" ? "light" : window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}
function na(e) {
  if (typeof document > "u") return;
  const t = e === "system" ? _r() : e, n = document.documentElement;
  n.classList.remove("light", "dark"), n.classList.add(t);
}
function Wx({
  defaultTheme: e = "system",
  storageKey: t = "refast-theme",
  showSystemOption: n = !0,
  mode: r = "toggle",
  onChange: o,
  className: s,
  ...a
}) {
  const [i, l] = h.useState(() => {
    if (typeof window < "u") {
      const x = localStorage.getItem(t);
      if (x && ["light", "dark", "system"].includes(x))
        return x;
    }
    return e;
  }), [c, d] = h.useState(!1), [f, p] = h.useState(!1);
  h.useEffect(() => {
    d(!0), na(i);
  }, [i]), h.useEffect(() => {
    if (i !== "system") return;
    const x = window.matchMedia("(prefers-color-scheme: dark)"), v = () => na("system");
    return x.addEventListener("change", v), () => x.removeEventListener("change", v);
  }, [i]);
  const u = h.useCallback((x) => {
    l(x), typeof window < "u" && localStorage.setItem(t, x), o == null || o(x);
  }, [t, o]), g = h.useCallback(() => {
    const v = (i === "system" ? _r() : i) === "light" ? "dark" : "light";
    u(v);
  }, [i, u]), b = i === "system" ? _r() : i;
  return c ? r === "toggle" ? /* @__PURE__ */ m.jsx(
    "button",
    {
      type: "button",
      onClick: g,
      className: D(
        "inline-flex h-10 w-10 items-center justify-center rounded-md border border-input bg-background",
        "text-sm font-medium ring-offset-background transition-colors",
        "hover:bg-accent hover:text-accent-foreground",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "disabled:pointer-events-none disabled:opacity-50",
        s
      ),
      "aria-label": `Switch to ${b === "light" ? "dark" : "light"} theme`,
      ...a,
      children: b === "light" ? /* @__PURE__ */ m.jsx(wr, { className: "h-5 w-5" }) : /* @__PURE__ */ m.jsx(Cr, { className: "h-5 w-5" })
    }
  ) : /* @__PURE__ */ m.jsxs("div", { className: D("relative", s), ...a, children: [
    /* @__PURE__ */ m.jsx(
      "button",
      {
        type: "button",
        onClick: () => p(!f),
        className: D(
          "inline-flex h-10 w-10 items-center justify-center rounded-md border border-input bg-background",
          "text-sm font-medium ring-offset-background transition-colors",
          "hover:bg-accent hover:text-accent-foreground",
          "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
        ),
        "aria-label": "Select theme",
        "aria-expanded": f,
        "aria-haspopup": "menu",
        children: b === "light" ? /* @__PURE__ */ m.jsx(wr, { className: "h-5 w-5" }) : /* @__PURE__ */ m.jsx(Cr, { className: "h-5 w-5" })
      }
    ),
    f && /* @__PURE__ */ m.jsxs(m.Fragment, { children: [
      /* @__PURE__ */ m.jsx(
        "div",
        {
          className: "fixed inset-0 z-40",
          onClick: () => p(!1)
        }
      ),
      /* @__PURE__ */ m.jsxs(
        "div",
        {
          className: D(
            "absolute right-0 top-full z-50 mt-2 min-w-[8rem]",
            "rounded-md border bg-popover p-1 text-popover-foreground shadow-md",
            "animate-in fade-in-0 zoom-in-95"
          ),
          role: "menu",
          children: [
            /* @__PURE__ */ m.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  u("light"), p(!1);
                },
                className: D(
                  "relative flex w-full cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none",
                  "hover:bg-accent hover:text-accent-foreground",
                  i === "light" && "bg-accent"
                ),
                role: "menuitem",
                children: [
                  /* @__PURE__ */ m.jsx(wr, { className: "h-4 w-4" }),
                  "Light"
                ]
              }
            ),
            /* @__PURE__ */ m.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  u("dark"), p(!1);
                },
                className: D(
                  "relative flex w-full cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none",
                  "hover:bg-accent hover:text-accent-foreground",
                  i === "dark" && "bg-accent"
                ),
                role: "menuitem",
                children: [
                  /* @__PURE__ */ m.jsx(Cr, { className: "h-4 w-4" }),
                  "Dark"
                ]
              }
            ),
            n && /* @__PURE__ */ m.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  u("system"), p(!1);
                },
                className: D(
                  "relative flex w-full cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none",
                  "hover:bg-accent hover:text-accent-foreground",
                  i === "system" && "bg-accent"
                ),
                role: "menuitem",
                children: [
                  /* @__PURE__ */ m.jsx(Vx, { className: "h-4 w-4" }),
                  "System"
                ]
              }
            )
          ]
        }
      )
    ] })
  ] }) : /* @__PURE__ */ m.jsx(
    "button",
    {
      className: D(
        "inline-flex h-10 w-10 items-center justify-center rounded-md border border-input bg-background",
        "text-sm font-medium ring-offset-background transition-colors",
        "hover:bg-accent hover:text-accent-foreground",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "disabled:pointer-events-none disabled:opacity-50",
        s
      ),
      disabled: !0,
      ...a,
      children: /* @__PURE__ */ m.jsx("span", { className: "h-5 w-5" })
    }
  );
}
function Gx({
  className: e,
  position: t = "bottom-right",
  expand: n = !1,
  duration: r = 4e3,
  visibleToasts: o = 3,
  closeButton: s = !1,
  richColors: a = !1,
  theme: i = "system",
  offset: l,
  gap: c = 14,
  dir: d = "auto",
  hotkey: f = ["altKey", "KeyT"],
  invert: p = !1
}) {
  return /* @__PURE__ */ m.jsx(
    Hl,
    {
      className: e,
      position: t,
      expand: n,
      duration: r,
      visibleToasts: o,
      closeButton: s,
      richColors: a,
      theme: i,
      offset: l,
      gap: c,
      dir: d,
      hotkey: f,
      invert: p,
      toastOptions: {
        classNames: {
          toast: "group"
        }
      }
    }
  );
}
class Ux {
  constructor() {
    he(this, "components", /* @__PURE__ */ new Map());
    /** Maps component name → the chunk it belongs to (for lazy resolution) */
    he(this, "lazyMap", /* @__PURE__ */ new Map());
    /** Registered chunk loaders */
    he(this, "chunkLoaders", /* @__PURE__ */ new Map());
    /** Cache of resolved lazy components (wrapped in React.lazy) */
    he(this, "lazyCache", /* @__PURE__ */ new Map());
    /** Chunk load promises (so we don't trigger the same import twice) */
    he(this, "chunkPromises", /* @__PURE__ */ new Map());
    /** Which chunks have been fully resolved */
    he(this, "resolvedChunks", /* @__PURE__ */ new Set());
  }
  // ── Eager registration (unchanged API) ─────────────────────────────
  register(t, n) {
    this.components.set(t, n);
  }
  registerAll(t) {
    for (const [n, r] of Object.entries(t))
      this.register(n, r);
  }
  // ── Lazy registration ──────────────────────────────────────────────
  /**
   * Register a feature chunk whose components will be lazily loaded.
   */
  registerLazyChunk(t) {
    this.chunkLoaders.set(t.name, t.loader);
    for (const n of t.componentNames)
      this.lazyMap.set(n, t.name);
  }
  // ── Component resolution ───────────────────────────────────────────
  /**
   * Get a component by name.
   *
   * 1. If eagerly registered → return immediately.
   * 2. If the component belongs to a lazy chunk → return a `React.lazy()`
   *    wrapper that will trigger the chunk import on first render.
   * 3. Otherwise → return `undefined`.
   */
  get(t) {
    const n = this.components.get(t);
    if (n) return n;
    const r = this.lazyMap.get(t);
    if (!r) return;
    if (this.resolvedChunks.has(r))
      return this.components.get(t);
    let o = this.lazyCache.get(t);
    return o || (o = P.lazy(() => this._loadComponent(t, r)), this.lazyCache.set(t, o)), o;
  }
  has(t) {
    return this.components.has(t) || this.lazyMap.has(t);
  }
  /**
   * Get the chunk name a component belongs to (if any).
   */
  getChunkName(t) {
    return this.lazyMap.get(t);
  }
  /**
   * Check whether a component name is registered as part of a lazy chunk
   * that hasn't been loaded yet.
   */
  isLazy(t) {
    if (this.components.has(t)) return !1;
    const n = this.lazyMap.get(t);
    return n ? !this.resolvedChunks.has(n) : !1;
  }
  list() {
    const t = /* @__PURE__ */ new Set([...this.components.keys(), ...this.lazyMap.keys()]);
    return Array.from(t);
  }
  /**
   * List all registered feature-chunk names.
   */
  listChunks() {
    return Array.from(this.chunkLoaders.keys());
  }
  // ── Internal ───────────────────────────────────────────────────────
  /**
   * Load a single component from its chunk.  Returns in the shape
   * `{ default: Component }` which `React.lazy()` requires.
   */
  async _loadComponent(t, n) {
    let r = this.chunkPromises.get(n);
    if (!r) {
      const a = this.chunkLoaders.get(n);
      if (!a) throw new Error(`No loader for chunk "${n}"`);
      r = a(), this.chunkPromises.set(n, r);
    }
    const o = await r;
    for (const [a, i] of Object.entries(o))
      this.components.set(a, i);
    this.resolvedChunks.add(n);
    const s = o[t];
    if (!s)
      throw new Error(
        `Component "${t}" not found in chunk "${n}". Available: ${Object.keys(o).join(", ")}`
      );
    return { default: s };
  }
}
const $ = new Ux();
$.register("Container", rp);
$.register("Text", op);
$.register("Fragment", sp);
$.register("Slot", Sm);
$.register("Row", Ca);
$.register("Column", Sa);
$.register("Grid", ap);
$.register("Flex", ip);
$.register("Center", lp);
$.register("Button", Hr);
$.register("IconButton", Ea);
$.register("Card", fp);
$.register("CardHeader", pp);
$.register("CardContent", gp);
$.register("CardFooter", bp);
$.register("CardTitle", mp);
$.register("CardDescription", hp);
$.register("Input", hm);
$.register("InputWrapper", Hn);
$.register("Textarea", gm);
$.register("Select", bm);
$.register("SelectOption", vm);
$.register("Checkbox", xm);
$.register("CheckboxGroup", Cm);
$.register("Radio", ym);
$.register("RadioGroup", wm);
$.register("Heading", Em);
$.register("Paragraph", km);
$.register("Link", Pm);
$.register("Code", Rm);
$.register("BlockQuote", Am);
$.register("List", Nm);
$.register("ListItem", Tm);
$.register("Label", jm);
$.register("Markdown", Im);
$.register("Alert", Mm);
$.register("AlertTitle", Za);
$.register("AlertDescription", Qa);
$.register("Badge", Lm);
$.register("Progress", zm);
$.register("Spinner", Om);
$.register("Toast", Gx);
$.register("Skeleton", _m);
$.register("ConnectionStatus", $m);
$.register("Table", ib);
$.register("TableHeader", lb);
$.register("TableBody", cb);
$.register("TableRow", ub);
$.register("TableHead", db);
$.register("TableCell", fb);
$.register("DataTable", pb);
$.register("Avatar", mb);
$.register("Image", hb);
$.register("Tooltip", gb);
$.register("Tabs", vb);
$.register("TabItem", xb);
$.register("Accordion", sb);
$.register("AccordionItem", ab);
$.register("AccordionTrigger", Qi);
$.register("AccordionContent", el);
$.register("Separator", jx);
$.register("AspectRatio", Ix);
$.register("ScrollArea", Mx);
$.register("Collapsible", Lx);
$.register("CollapsibleTrigger", Vl);
$.register("CollapsibleContent", Wl);
$.register("Carousel", Dx);
$.register("CarouselContent", zx);
$.register("CarouselItem", Ox);
$.register("CarouselPrevious", _x);
$.register("CarouselNext", $x);
$.register("ResizablePanelGroup", Fx);
$.register("ResizablePanel", Bx);
$.register("ResizableHandle", Hx);
$.register("ThemeSwitcher", Wx);
$.registerLazyChunk({
  name: "icons",
  componentNames: ["Icon"],
  loader: () => Promise.resolve().then(() => dp).then((e) => ({ Icon: e.Icon }))
});
$.registerLazyChunk({
  name: "controls",
  componentNames: [
    "Switch",
    "Slider",
    "Toggle",
    "ToggleGroup",
    "ToggleGroupItem",
    "DatePicker",
    "Calendar",
    "Combobox",
    "InputOTP",
    "InputOTPGroup",
    "InputOTPSlot",
    "InputOTPSeparator"
  ],
  loader: () => import("./refast-controls-CHO4YvPm.js").then((e) => ({
    Switch: e.Switch,
    Slider: e.Slider,
    Toggle: e.Toggle,
    ToggleGroup: e.ToggleGroup,
    ToggleGroupItem: e.ToggleGroupItem,
    DatePicker: e.DatePicker,
    Calendar: e.Calendar,
    Combobox: e.Combobox,
    InputOTP: e.InputOTP,
    InputOTPGroup: e.InputOTPGroup,
    InputOTPSlot: e.InputOTPSlot,
    InputOTPSeparator: e.InputOTPSeparator
  }))
});
$.registerLazyChunk({
  name: "navigation",
  componentNames: [
    "Breadcrumb",
    "BreadcrumbList",
    "BreadcrumbItem",
    "BreadcrumbLink",
    "BreadcrumbPage",
    "BreadcrumbSeparator",
    "BreadcrumbEllipsis",
    "NavigationMenu",
    "NavigationMenuList",
    "NavigationMenuItem",
    "NavigationMenuTrigger",
    "NavigationMenuContent",
    "NavigationMenuLink",
    "Pagination",
    "PaginationContent",
    "PaginationItem",
    "PaginationLink",
    "PaginationPrevious",
    "PaginationNext",
    "PaginationEllipsis",
    "Menubar",
    "MenubarMenu",
    "MenubarTrigger",
    "MenubarContent",
    "MenubarItem",
    "MenubarSeparator",
    "MenubarCheckboxItem",
    "MenubarRadioGroup",
    "MenubarRadioItem",
    "MenubarSub",
    "MenubarSubTrigger",
    "MenubarSubContent",
    "Command",
    "CommandInput",
    "CommandList",
    "CommandEmpty",
    "CommandGroup",
    "CommandItem",
    "CommandSeparator",
    "CommandShortcut",
    "SidebarProvider",
    "Sidebar",
    "SidebarInset",
    "SidebarHeader",
    "SidebarContent",
    "SidebarFooter",
    "SidebarSeparator",
    "SidebarGroup",
    "SidebarGroupLabel",
    "SidebarGroupAction",
    "SidebarGroupContent",
    "SidebarMenu",
    "SidebarMenuItem",
    "SidebarMenuButton",
    "SidebarMenuAction",
    "SidebarMenuBadge",
    "SidebarMenuSub",
    "SidebarMenuSubItem",
    "SidebarMenuSubButton",
    "SidebarMenuSkeleton",
    "SidebarRail",
    "SidebarTrigger"
  ],
  loader: () => import("./refast-navigation-DhV-XN_Y.js").then((e) => ({
    Breadcrumb: e.Breadcrumb,
    BreadcrumbList: e.BreadcrumbList,
    BreadcrumbItem: e.BreadcrumbItem,
    BreadcrumbLink: e.BreadcrumbLink,
    BreadcrumbPage: e.BreadcrumbPage,
    BreadcrumbSeparator: e.BreadcrumbSeparator,
    BreadcrumbEllipsis: e.BreadcrumbEllipsis,
    NavigationMenu: e.NavigationMenu,
    NavigationMenuList: e.NavigationMenuList,
    NavigationMenuItem: e.NavigationMenuItem,
    NavigationMenuTrigger: e.NavigationMenuTrigger,
    NavigationMenuContent: e.NavigationMenuContent,
    NavigationMenuLink: e.NavigationMenuLink,
    Pagination: e.Pagination,
    PaginationContent: e.PaginationContent,
    PaginationItem: e.PaginationItem,
    PaginationLink: e.PaginationLink,
    PaginationPrevious: e.PaginationPrevious,
    PaginationNext: e.PaginationNext,
    PaginationEllipsis: e.PaginationEllipsis,
    Menubar: e.Menubar,
    MenubarMenu: e.MenubarMenu,
    MenubarTrigger: e.MenubarTrigger,
    MenubarContent: e.MenubarContent,
    MenubarItem: e.MenubarItem,
    MenubarSeparator: e.MenubarSeparator,
    MenubarCheckboxItem: e.MenubarCheckboxItem,
    MenubarRadioGroup: e.MenubarRadioGroup,
    MenubarRadioItem: e.MenubarRadioItem,
    MenubarSub: e.MenubarSub,
    MenubarSubTrigger: e.MenubarSubTrigger,
    MenubarSubContent: e.MenubarSubContent,
    Command: e.Command,
    CommandInput: e.CommandInput,
    CommandList: e.CommandList,
    CommandEmpty: e.CommandEmpty,
    CommandGroup: e.CommandGroup,
    CommandItem: e.CommandItem,
    CommandSeparator: e.CommandSeparator,
    CommandShortcut: e.CommandShortcut,
    SidebarProvider: e.SidebarProvider,
    Sidebar: e.Sidebar,
    SidebarInset: e.SidebarInset,
    SidebarHeader: e.SidebarHeader,
    SidebarContent: e.SidebarContent,
    SidebarFooter: e.SidebarFooter,
    SidebarSeparator: e.SidebarSeparator,
    SidebarGroup: e.SidebarGroup,
    SidebarGroupLabel: e.SidebarGroupLabel,
    SidebarGroupAction: e.SidebarGroupAction,
    SidebarGroupContent: e.SidebarGroupContent,
    SidebarMenu: e.SidebarMenu,
    SidebarMenuItem: e.SidebarMenuItem,
    SidebarMenuButton: e.SidebarMenuButton,
    SidebarMenuAction: e.SidebarMenuAction,
    SidebarMenuBadge: e.SidebarMenuBadge,
    SidebarMenuSub: e.SidebarMenuSub,
    SidebarMenuSubItem: e.SidebarMenuSubItem,
    SidebarMenuSubButton: e.SidebarMenuSubButton,
    SidebarMenuSkeleton: e.SidebarMenuSkeleton,
    SidebarRail: e.SidebarRail,
    SidebarTrigger: e.SidebarTrigger
  }))
});
$.registerLazyChunk({
  name: "overlay",
  componentNames: [
    "Dialog",
    "DialogTrigger",
    "DialogContent",
    "DialogHeader",
    "DialogFooter",
    "DialogTitle",
    "DialogDescription",
    "DialogAction",
    "DialogCancel",
    "Drawer",
    "DrawerTrigger",
    "DrawerContent",
    "DrawerHeader",
    "DrawerFooter",
    "DrawerTitle",
    "DrawerDescription",
    "DrawerClose",
    "Sheet",
    "SheetTrigger",
    "SheetContent",
    "SheetHeader",
    "SheetFooter",
    "SheetTitle",
    "SheetDescription",
    "SheetClose",
    "HoverCard",
    "HoverCardTrigger",
    "HoverCardContent",
    "Popover",
    "PopoverTrigger",
    "PopoverContent",
    "DropdownMenu",
    "DropdownMenuTrigger",
    "DropdownMenuContent",
    "DropdownMenuItem",
    "DropdownMenuLabel",
    "DropdownMenuSeparator",
    "DropdownMenuCheckboxItem",
    "DropdownMenuRadioGroup",
    "DropdownMenuRadioItem",
    "DropdownMenuSub",
    "DropdownMenuSubTrigger",
    "DropdownMenuSubContent",
    "ContextMenu",
    "ContextMenuTrigger",
    "ContextMenuContent",
    "ContextMenuItem",
    "ContextMenuSeparator",
    "ContextMenuCheckboxItem"
  ],
  loader: () => import("./refast-overlay-CpN-nxCe.js").then((e) => ({
    Dialog: e.Dialog,
    DialogTrigger: e.DialogTrigger,
    DialogContent: e.DialogContent,
    DialogHeader: e.DialogHeader,
    DialogFooter: e.DialogFooter,
    DialogTitle: e.DialogTitle,
    DialogDescription: e.DialogDescription,
    DialogAction: e.DialogAction,
    DialogCancel: e.DialogCancel,
    Drawer: e.Drawer,
    DrawerTrigger: e.DrawerTrigger,
    DrawerContent: e.DrawerContent,
    DrawerHeader: e.DrawerHeader,
    DrawerFooter: e.DrawerFooter,
    DrawerTitle: e.DrawerTitle,
    DrawerDescription: e.DrawerDescription,
    DrawerClose: e.DrawerClose,
    Sheet: e.Sheet,
    SheetTrigger: e.SheetTrigger,
    SheetContent: e.SheetContent,
    SheetHeader: e.SheetHeader,
    SheetFooter: e.SheetFooter,
    SheetTitle: e.SheetTitle,
    SheetDescription: e.SheetDescription,
    SheetClose: e.SheetClose,
    HoverCard: e.HoverCard,
    HoverCardTrigger: e.HoverCardTrigger,
    HoverCardContent: e.HoverCardContent,
    Popover: e.Popover,
    PopoverTrigger: e.PopoverTrigger,
    PopoverContent: e.PopoverContent,
    DropdownMenu: e.DropdownMenu,
    DropdownMenuTrigger: e.DropdownMenuTrigger,
    DropdownMenuContent: e.DropdownMenuContent,
    DropdownMenuItem: e.DropdownMenuItem,
    DropdownMenuLabel: e.DropdownMenuLabel,
    DropdownMenuSeparator: e.DropdownMenuSeparator,
    DropdownMenuCheckboxItem: e.DropdownMenuCheckboxItem,
    DropdownMenuRadioGroup: e.DropdownMenuRadioGroup,
    DropdownMenuRadioItem: e.DropdownMenuRadioItem,
    DropdownMenuSub: e.DropdownMenuSub,
    DropdownMenuSubTrigger: e.DropdownMenuSubTrigger,
    DropdownMenuSubContent: e.DropdownMenuSubContent,
    ContextMenu: e.ContextMenu,
    ContextMenuTrigger: e.ContextMenuTrigger,
    ContextMenuContent: e.ContextMenuContent,
    ContextMenuItem: e.ContextMenuItem,
    ContextMenuSeparator: e.ContextMenuSeparator,
    ContextMenuCheckboxItem: e.ContextMenuCheckboxItem
  }))
});
$.registerLazyChunk({
  name: "charts",
  componentNames: [
    "ChartContainer",
    "ChartTooltip",
    "ChartTooltipContent",
    "ChartLegend",
    "ChartLegendContent",
    "AreaChart",
    "Area",
    "BarChart",
    "Bar",
    "LineChart",
    "Line",
    "PieChart",
    "Pie",
    "PieLabel",
    "Sector",
    "RadarChart",
    "Radar",
    "PolarGrid",
    "PolarAngleAxis",
    "PolarRadiusAxis",
    "RadialBarChart",
    "RadialBar",
    "ScatterChart",
    "Scatter",
    "ZAxis",
    "ComposedChart",
    "FunnelChart",
    "Funnel",
    "Treemap",
    "Sankey",
    "XAxis",
    "YAxis",
    "CartesianGrid",
    "ReferenceLine",
    "ReferenceArea",
    "ReferenceDot",
    "Brush",
    "Cell",
    "LabelList",
    "ChartLabel",
    "ErrorBar"
  ],
  loader: async () => {
    const [e, t, n, r, o, s, a, i, l, c, d, f, p] = await Promise.all([
      import("./refast-chart-B-nUWBzP.js"),
      import("./refast-area-chart-D7AM4_oT.js"),
      import("./refast-bar-chart-B0OSIJg-.js"),
      import("./refast-line-chart-BBpoZLtU.js"),
      import("./refast-pie-chart-DXYMRezT.js"),
      import("./refast-radar-chart-zRgps2OE.js"),
      import("./refast-radial-chart-DfrKp3Nl.js"),
      import("./refast-scatter-chart-B-zKIi84.js"),
      import("./refast-composed-chart-bnOTjTBa.js"),
      import("./refast-funnel-chart-TbHBYfit.js"),
      import("./refast-treemap-C5Flq7c4.js"),
      import("./refast-sankey-D1gHTkVP.js"),
      import("./refast-utils-Dsd2xfqd.js")
    ]);
    return {
      ChartContainer: e.ChartContainer,
      ChartTooltip: e.ChartTooltip,
      ChartTooltipContent: e.ChartTooltipContent,
      ChartLegend: e.ChartLegend,
      ChartLegendContent: e.ChartLegendContent,
      AreaChart: t.AreaChart,
      Area: t.Area,
      BarChart: n.BarChart,
      Bar: n.Bar,
      LineChart: r.LineChart,
      Line: r.Line,
      PieChart: o.PieChart,
      Pie: o.Pie,
      PieLabel: o.PieLabel,
      Sector: o.Sector,
      RadarChart: s.RadarChart,
      Radar: s.Radar,
      PolarGrid: s.PolarGrid,
      PolarAngleAxis: s.PolarAngleAxis,
      PolarRadiusAxis: s.PolarRadiusAxis,
      RadialBarChart: a.RadialBarChart,
      RadialBar: a.RadialBar,
      ScatterChart: i.ScatterChart,
      Scatter: i.Scatter,
      ZAxis: i.ZAxis,
      ComposedChart: l.ComposedChart,
      FunnelChart: c.FunnelChart,
      Funnel: c.Funnel,
      Treemap: d.Treemap,
      Sankey: f.Sankey,
      XAxis: p.XAxis,
      YAxis: p.YAxis,
      CartesianGrid: p.CartesianGrid,
      ReferenceLine: p.ReferenceLine,
      ReferenceArea: p.ReferenceArea,
      ReferenceDot: p.ReferenceDot,
      Brush: p.Brush,
      Cell: p.Cell,
      LabelList: p.LabelList,
      ChartLabel: p.Label,
      ErrorBar: p.ErrorBar
    };
  }
});
class Kx {
  constructor() {
    he(this, "store", /* @__PURE__ */ new Map());
    he(this, "listeners", /* @__PURE__ */ new Set());
  }
  /**
   * Set a value in the prop store.
   */
  set(t, n) {
    this.store.set(t, n), this.notifyListeners(t, n);
  }
  /**
   * Get a value from the prop store.
   */
  get(t) {
    return this.store.get(t);
  }
  /**
   * Check if a key exists in the prop store.
   */
  has(t) {
    return this.store.has(t);
  }
  /**
   * Delete a key from the prop store.
   */
  delete(t) {
    this.store.delete(t), this.notifyListeners(t, void 0);
  }
  /**
   * Clear all values from the prop store.
   */
  clear() {
    this.store.clear();
  }
  /**
   * Get all values as a plain object.
   * This is sent to the backend with callback invocations.
   */
  getAll() {
    const t = {};
    return this.store.forEach((n, r) => {
      t[r] = n;
    }), t;
  }
  /**
   * Get all keys in the prop store.
   * Used for regex pattern matching.
   */
  keys() {
    return Array.from(this.store.keys());
  }
  /**
   * Subscribe to prop store changes.
   */
  subscribe(t) {
    return this.listeners.add(t), () => {
      this.listeners.delete(t);
    };
  }
  notifyListeners(t, n) {
    this.listeners.forEach((r) => r(t, n));
  }
}
const ut = new Kx();
function Yx(e, t) {
  if (typeof e == "string")
    ut.set(e, t.value);
  else if (typeof e == "object")
    for (const [n, r] of Object.entries(e))
      n in t && ut.set(r, t[n]);
}
function Ul(e) {
  return typeof e == "object" && e !== null && "callbackId" in e;
}
function Kl(e) {
  return typeof e == "object" && e !== null && "jsFunction" in e;
}
function Yl(e) {
  return typeof e == "object" && e !== null && "boundMethod" in e && typeof e.boundMethod == "object" && "targetId" in e.boundMethod && "methodName" in e.boundMethod;
}
function Xl(e) {
  return typeof e == "object" && e !== null && "saveProp" in e;
}
function ql(e) {
  return typeof e == "object" && e !== null && "chain" in e && Array.isArray(e.chain);
}
function Xx(e) {
  const t = {}, n = ut.keys();
  for (const r of e)
    if (/[\\^$.*+?()[\]{}|]/.test(r))
      try {
        const s = new RegExp(`^${r}$`);
        for (const a of n)
          if (s.test(a)) {
            const i = ut.get(a);
            i !== void 0 && (t[a] = i);
          }
      } catch {
        console.warn(`[Refast] Invalid regex pattern in props: ${r}`);
        const s = ut.get(r);
        s !== void 0 && (t[r] = s);
      }
    else {
      const s = ut.get(r);
      s !== void 0 && (t[r] = s);
    }
  return t;
}
function vn(e, t, n) {
  let r = e;
  return t && t > 0 && (r = ep(r, t)), n && n > 0 && (r = tp(r, n)), r;
}
function Ln(e, t) {
  if (ql(e))
    return qx(e, t);
  if (Xl(e)) {
    const { saveProp: n, debounce: r, throttle: o } = e;
    let s = (a) => {
      Yx(n, a);
    };
    return s = vn(s, r, o), async (a) => {
      s(a);
    };
  }
  if (Ul(e)) {
    const { callbackId: n, boundArgs: r, props: o, debounce: s, throttle: a } = e;
    let i = (l) => {
      let c = {};
      o && o.length > 0 && (c = Xx(o)), t.invokeCallback(n, { ...c, ...r }, l);
    };
    return i = vn(i, s, a), async (l) => {
      i(l);
    };
  }
  if (Kl(e)) {
    const { jsFunction: n, boundArgs: r, debounce: o, throttle: s } = e;
    let a = (i, l) => {
      try {
        let c = null;
        l[0] && typeof l[0] == "object" && "target" in l[0] && (c = l[0].target), new Function("event", "args", "element", "refast", n)(i, r, c, ha);
      } catch (c) {
        console.error("[Refast] Error executing JavaScript callback:", c), console.error("[Refast] Code:", n);
      }
    };
    return a = vn(a, o, s), async (i, l) => {
      a(i, l);
    };
  }
  if (Yl(e)) {
    const { boundMethod: n, debounce: r, throttle: o } = e, { targetId: s, methodName: a, args: i = [], kwargs: l = {} } = n;
    let c = () => {
      try {
        const d = document.getElementById(s);
        if (d) {
          const f = d[a];
          if (typeof f == "function") {
            const u = Object.keys(l).length > 0 ? [...i, l] : i;
            u.length === 0 ? f.call(d) : u.length === 1 ? f.call(d, u[0]) : f.apply(d, u);
          } else
            console.warn(`[Refast] Method '${a}' not found on element '${s}'`);
        } else
          console.warn(`[Refast] Element with id '${s}' not found`);
      } catch (d) {
        console.error("[Refast] Error calling bound method:", d), console.error("[Refast] Target:", s, "Method:", a);
      }
    };
    return c = vn(c, r, o), async () => {
      c();
    };
  }
  return async () => {
  };
}
function qx(e, t) {
  const n = e.chain.map((o) => Ln(o, t)), r = e.mode || "serial";
  return async (o, s) => {
    if (r === "parallel")
      await Promise.all(n.map((a) => a(o, s)));
    else
      for (const a of n)
        await a(o, s);
  };
}
class Jx extends h.Component {
  constructor(t) {
    super(t), this.state = { hasError: !1, errorMessage: "" };
  }
  static getDerivedStateFromError(t) {
    return { hasError: !0, errorMessage: t.message };
  }
  componentDidCatch(t) {
    console.error(`[Refast] Error rendering <${this.props.componentType}>:`, t);
  }
  render() {
    return this.state.hasError ? /* @__PURE__ */ m.jsx(
      "div",
      {
        "data-refast-error": this.props.componentType,
        title: this.state.errorMessage,
        style: {
          display: "inline-block",
          border: "1px dashed #ef4444",
          borderRadius: 4,
          padding: "2px 6px",
          color: "#ef4444",
          fontSize: 11,
          fontFamily: "monospace"
        },
        children: `<${this.props.componentType}>`
      }
    ) : this.props.children;
  }
}
function Zx() {
  return /* @__PURE__ */ m.jsx(
    "div",
    {
      className: "animate-pulse rounded bg-muted/40",
      style: { minHeight: 24, minWidth: 48 }
    }
  );
}
const vt = P.forwardRef(({ tree: e, onUpdate: t, ...n }, r) => e ? typeof e == "string" ? /* @__PURE__ */ m.jsx(m.Fragment, { children: e }) : /* @__PURE__ */ m.jsx(Jl, { tree: e, onUpdate: t, ref: r, ...n }) : null);
vt.displayName = "ComponentRenderer";
const Jl = P.forwardRef(({ tree: e, onUpdate: t, ...n }, r) => {
  const o = Lt();
  if (!e)
    return null;
  const { type: s, id: a, props: i, children: l } = e, c = $.get(s), d = h.useMemo(() => {
    const C = { id: a };
    for (const [k, E] of Object.entries(i)) {
      const w = xn(k);
      Ul(E) ? C[w] = Qx(E, o) : Kl(E) ? C[w] = ey(E) : Yl(E) ? C[w] = ty(E) : Xl(E) ? C[w] = ny(E) : ql(E) ? C[w] = ry(E, o) : ra(k, E) ? C[w] = sa(E) : C[w] = E;
    }
    return oa(C);
  }, [i, a, o]), f = h.useMemo(() => {
    if (!l || l.length === 0)
      return null;
    const C = (w) => $.getChunkName(w) === "charts", k = C(s), E = (w, R) => {
      if (typeof w == "string") return w;
      const T = $.get(w.type);
      if (!T || !C(w.type))
        return /* @__PURE__ */ m.jsx(vt, { tree: w, onUpdate: t }, w.id || R);
      const I = { key: w.id || R };
      for (const [N, _] of Object.entries(w.props || {}))
        ra(N, _) ? I[xn(N)] = sa(_) : typeof _ == "object" && _ !== null && _.type ? I[xn(N)] = /* @__PURE__ */ m.jsx(vt, { tree: _, onUpdate: t }) : I[xn(N)] = _;
      const A = (w.children || []).filter((N) => N != null && N !== "None").map((N, _) => E(N, _));
      return P.createElement(T, oa(I), A.length > 0 ? A : void 0);
    };
    return l.filter((w) => w != null && w !== "None").map((w, R) => typeof w == "string" ? w : k && C(w.type) ? E(w, R) : /* @__PURE__ */ m.jsx(
      vt,
      {
        tree: w,
        onUpdate: t
      },
      typeof w == "string" ? R : w.id || R
    ));
  }, [l, t, s]);
  if (!c)
    return console.warn(`Unknown component type: ${s}`), /* @__PURE__ */ m.jsx("div", { "data-unknown-type": s, children: JSON.stringify(e) });
  const { parentStyle: p, ...u } = d, g = $.isLazy(s), v = !($.getChunkName(s) === "charts") ? /* @__PURE__ */ m.jsx(c, { ...u, ...n, "data-refast-id": a, ref: r, children: f }) : /* @__PURE__ */ m.jsx(c, { ...u, ...n, "data-refast-id": a, children: f }), y = g ? /* @__PURE__ */ m.jsx(h.Suspense, { fallback: /* @__PURE__ */ m.jsx(Zx, {}), children: v }) : v, S = /* @__PURE__ */ m.jsx(Jx, { componentType: s, children: y });
  return p ? /* @__PURE__ */ m.jsx(
    "div",
    {
      style: p,
      className: "refast-component-wrapper",
      "data-wrapper-for": a,
      children: S
    }
  ) : S;
});
Jl.displayName = "ComponentObjectRenderer";
function ra(e, t) {
  return [
    "tickFormatter",
    "tick_formatter",
    "labelFormatter",
    "label_formatter",
    "formatter"
  ].includes(e) && typeof t == "string";
}
function xn(e) {
  return e.replace(/_([a-z])/g, (t, n) => n.toUpperCase());
}
function oa(e) {
  const t = {};
  for (const [n, r] of Object.entries(e))
    r !== null && (t[n] = r);
  return t;
}
function sa(e) {
  return (t, n) => {
    try {
      return t == null ? "" : new Function("value", "index", `return ${e}`)(t, n);
    } catch {
      return String(t);
    }
  };
}
function an(e, t) {
  const n = Ln(e, t);
  return (...r) => {
    const o = oy(r);
    n(o, r);
  };
}
function Qx(e, t) {
  return an(e, t);
}
function ey(e) {
  return an(e, { invokeCallback: () => {
  } });
}
function ty(e) {
  return an(e, { invokeCallback: () => {
  } });
}
function ny(e) {
  return an(e, { invokeCallback: () => {
  } });
}
function ry(e, t) {
  return an(e, t);
}
function oy(e) {
  var n;
  if (e.length === 0) return {};
  const t = e[0];
  if (t instanceof Date)
    return {
      value: t.toISOString(),
      date: t.toISOString()
    };
  if (t && typeof t == "object" && "target" in t) {
    const r = t, o = r.target, s = {}, a = (n = o.tagName) == null ? void 0 : n.toLowerCase();
    if ((a === "input" || a === "select" || a === "textarea") && (s.value = o.value, s.name = o.name, (o.type === "checkbox" || o.type === "radio") && (s.checked = o.checked)), "key" in r) {
      const i = r;
      s.key = i.key, s.code = i.code, i.altKey && (s.altKey = !0), i.ctrlKey && (s.ctrlKey = !0), i.metaKey && (s.metaKey = !0), i.shiftKey && (s.shiftKey = !0), i.repeat && (s.repeat = !0);
    }
    return s;
  }
  return typeof t == "string" || typeof t == "number" || typeof t == "boolean" ? { value: t } : typeof t == "object" ? t : {};
}
function sy(e, t) {
  if (e === t) return !0;
  if (!e || !t) return !1;
  const n = Object.keys(e), r = Object.keys(t);
  if (n.length !== r.length) return !1;
  for (const o of n) {
    const s = e[o], a = t[o];
    if (!((o === "onClick" || o === "onChange" || o === "onSubmit" || o === "onInput") && typeof s == "object" && s !== null && "callbackId" in s && typeof a == "object" && a !== null && "callbackId" in a)) {
      if (typeof s == "object" && typeof a == "object") {
        if (JSON.stringify(s) !== JSON.stringify(a)) return !1;
      } else if (s !== a)
        return !1;
    }
  }
  return !0;
}
function Zl(e, t) {
  if (e.id !== t.id)
    return { tree: t, changed: !0 };
  if (e.type !== t.type)
    return { tree: t, changed: !0 };
  const n = !sy(e.props, t.props);
  let r = !1;
  const o = [], s = e.children || [], a = t.children || [], i = Math.max(s.length, a.length);
  for (let l = 0; l < i; l++) {
    const c = s[l], d = a[l];
    if (d === void 0) {
      r = !0;
      continue;
    }
    if (c === void 0) {
      r = !0, o.push(d);
      continue;
    }
    if (typeof d == "string")
      c !== d && (r = !0), o.push(d);
    else if (typeof c == "string")
      r = !0, o.push(d);
    else {
      const f = Zl(c, d);
      f.changed && (r = !0), o.push(f.tree);
    }
  }
  return !n && !r ? { tree: e, changed: !1 } : {
    tree: {
      ...t,
      // Keep old props reference if unchanged
      props: n ? t.props : e.props,
      children: o
    },
    changed: !0
  };
}
function ay(e) {
  const [t, n] = h.useState({
    componentTree: e || null,
    appState: {}
  }), r = h.useCallback((l) => {
    n((c) => ({ ...c, componentTree: l }));
  }, []), o = h.useCallback(
    (l, c, d = "replace") => {
      n((f) => {
        if (!f.componentTree) return f;
        const p = Po(f.componentTree, l, c, d);
        return { ...f, componentTree: p };
      });
    },
    []
  ), s = h.useCallback((l) => {
    n((c) => ({
      ...c,
      appState: { ...c.appState, ...l }
    }));
  }, []), a = h.useCallback(
    (l, c) => t.appState[l] ?? c,
    [t.appState]
  ), i = h.useCallback(
    (l) => {
      switch (l.type) {
        case "update":
          if (l.targetId && l.operation) {
            let c = l.component || null;
            l.operation === "update_children" && l.children ? c = { type: "", id: "", props: {}, children: l.children } : l.operation === "update_props" && (l.props || l.children) ? (c = { type: "", id: "", props: l.props || {}, children: l.children || [] }, c.__hasChildren = "children" in l, l.props && "value" in l.props && l.targetId && window.dispatchEvent(
              new CustomEvent("refast:force-value-sync", {
                detail: { targetId: l.targetId, value: l.props.value }
              })
            )) : l.operation === "append_prop" && l.propName !== void 0 && (c = { type: "", id: "", props: { __propName: l.propName, __value: l.value }, children: [] }), o(
              l.targetId,
              c,
              l.operation
            );
          }
          break;
        case "state_update":
          l.state && s(l.state);
          break;
        case "navigate":
          l.path && typeof window < "u" && (l.redirect ? l.target ? window.open(l.path, l.target) : window.location.href = l.path : (window.history.pushState({}, "", l.path), window.dispatchEvent(new CustomEvent("refast:navigate", { detail: { path: l.path } }))));
          break;
        case "toast":
          typeof window < "u" && window.dispatchEvent(
            new CustomEvent("refast:toast", {
              detail: {
                message: l.message,
                variant: l.variant,
                duration: l.duration,
                description: l.description,
                position: l.position,
                dismissible: l.dismissible,
                close_button: l.close_button,
                invert: l.invert,
                icon: l.icon,
                action: l.action,
                cancel: l.cancel,
                id: l.id,
                component: l.component
              }
            })
          );
          break;
        case "refresh":
          typeof window < "u" && (l.component ? n((c) => {
            if (!c.componentTree)
              return { ...c, componentTree: l.component };
            const { tree: d, changed: f } = Zl(c.componentTree, l.component);
            return f ? { ...c, componentTree: d } : c;
          }) : window.dispatchEvent(new CustomEvent("refast:refresh")));
          break;
      }
    },
    [o, s]
  );
  return {
    componentTree: t.componentTree,
    appState: t.appState,
    setComponentTree: r,
    updateComponent: o,
    setAppState: s,
    getAppState: a,
    handleUpdate: i
  };
}
function iy(e, t) {
  var r, o;
  const n = ((r = e.props) == null ? void 0 : r.on_change) ?? ((o = e.props) == null ? void 0 : o.onChange);
  if (n && typeof n == "object" && "saveProp" in n) {
    const s = n.saveProp;
    if (typeof s == "string")
      ut.set(s, t);
    else if (typeof s == "object" && s !== null) {
      const a = s;
      "value" in a && ut.set(a.value, t);
    }
  }
}
function Po(e, t, n, r) {
  var s, a;
  if (e.id === t)
    switch (r) {
      case "replace":
        return n || e;
      case "update_props": {
        const i = (n == null ? void 0 : n.props) || {};
        "value" in i && iy(e, i.value);
        const l = {
          ...e,
          props: { ...e.props, ...i }
        };
        return n != null && n.__hasChildren && (l.children = (n == null ? void 0 : n.children) || []), l;
      }
      case "update_children":
        return {
          ...e,
          children: (n == null ? void 0 : n.children) || []
        };
      case "remove":
        return e;
      case "append":
        return n ? {
          ...e,
          children: [...e.children || [], n]
        } : e;
      case "prepend":
        return n ? {
          ...e,
          children: [n, ...e.children || []]
        } : e;
      case "append_prop": {
        const i = (s = n == null ? void 0 : n.props) == null ? void 0 : s.__propName, l = (a = n == null ? void 0 : n.props) == null ? void 0 : a.__value;
        if (!i) return e;
        const c = e.props[i];
        let d;
        return typeof c == "string" && typeof l == "string" ? d = c + l : Array.isArray(c) ? Array.isArray(l) ? d = [...c, ...l] : d = [...c, l] : c == null ? typeof l == "string" || Array.isArray(l) ? d = l : d = [l] : d = l, {
          ...e,
          props: { ...e.props, [i]: d }
        };
      }
      default:
        return e;
    }
  const o = (e.children || []).map((i) => typeof i == "string" ? i : r === "remove" && i.id === t ? null : Po(i, t, n, r)).filter((i) => i !== null);
  return {
    ...e,
    children: o
  };
}
function ly(e, t) {
  if (e.id === t)
    return e;
  for (const n of e.children || [])
    if (typeof n != "string") {
      const r = ly(n, t);
      if (r)
        return r;
    }
  return null;
}
function cy(e, t, n = []) {
  if (e.id === t)
    return [...n, t];
  for (const r of e.children || [])
    if (typeof r != "string") {
      const o = cy(r, t, [...n, e.id]);
      if (o)
        return o;
    }
  return null;
}
function uy({ initialTree: e }) {
  const [t, n] = h.useState(e), r = Lt();
  return h.useEffect(() => r.onUpdate((o) => {
    if (o.type === "update" && o.targetId && o.operation) {
      let s = o.component || null;
      o.operation === "update_children" && o.children ? s = { type: "", id: "", props: {}, children: o.children } : o.operation === "update_props" && (o.props || o.children) ? (s = { type: "", id: "", props: o.props || {}, children: o.children || [] }, s.__hasChildren = "children" in o) : o.operation === "append_prop" && o.propName !== void 0 && (s = { type: "", id: "", props: { __propName: o.propName, __value: o.value } }), n((a) => a && Po(a, o.targetId, s, o.operation));
    }
  }), [r]), /* @__PURE__ */ m.jsx(vt, { tree: t });
}
function dy({
  className: e,
  position: t = "bottom-right",
  richColors: n = !0,
  closeButton: r = !0,
  duration: o = 4e3,
  expand: s = !1,
  visibleToasts: a = 3,
  offset: i,
  gap: l = 14,
  dir: c = "auto",
  hotkey: d = ["altKey", "KeyT"],
  invert: f = !1
}) {
  const p = Lt(), [u, g] = h.useState(() => typeof document < "u" && document.documentElement.classList.contains("dark") ? "dark" : "light");
  return h.useEffect(() => {
    if (typeof document > "u") return;
    const b = new MutationObserver((x) => {
      for (const v of x)
        if (v.type === "attributes" && v.attributeName === "class") {
          const y = document.documentElement.classList.contains("dark");
          g(y ? "dark" : "light");
        }
    });
    return b.observe(document.documentElement, {
      attributes: !0,
      attributeFilter: ["class"]
    }), () => b.disconnect();
  }, []), h.useEffect(() => {
    const b = (x) => {
      const {
        message: v,
        component: y,
        variant: S = "default",
        description: C,
        duration: k,
        position: E,
        dismissible: w = !0,
        close_button: R,
        invert: T,
        action: I,
        cancel: A,
        id: N
      } = x.detail, _ = {
        description: C,
        duration: k,
        position: E,
        dismissible: w,
        closeButton: R,
        invert: T,
        id: N
      };
      if (I) {
        const M = Ln(I.callback, p);
        _.action = {
          label: I.label,
          onClick: () => {
            M({}, []);
          }
        };
      }
      if (A) {
        const M = Ln(A.callback, p);
        _.cancel = {
          label: A.label,
          onClick: () => {
            M({}, []);
          }
        };
      }
      Object.keys(_).forEach((M) => {
        _[M] === void 0 && delete _[M];
      });
      const O = y ? /* @__PURE__ */ m.jsx(uy, { initialTree: y }) : v || "";
      switch (S) {
        case "success":
          it.success(O, _);
          break;
        case "destructive":
        case "error":
          it.error(O, _);
          break;
        case "warning":
          it.warning(O, _);
          break;
        case "info":
          it.info(O, _);
          break;
        case "loading":
          it.loading(O, _);
          break;
        default:
          it(O, _);
          break;
      }
    };
    return window.addEventListener("refast:toast", b), () => {
      window.removeEventListener("refast:toast", b);
    };
  }, [p]), /* @__PURE__ */ m.jsx(
    Hl,
    {
      className: e,
      position: t,
      richColors: n,
      closeButton: r,
      duration: o,
      expand: s,
      visibleToasts: a,
      theme: u,
      offset: i,
      gap: l,
      dir: c,
      hotkey: d,
      invert: f,
      toastOptions: {
        classNames: {
          toast: "group"
        }
      },
      style: {
        fontFamily: "inherit"
      }
    }
  );
}
function ky(e) {
  it.dismiss(e);
}
function Py(e, t) {
  return it.promise(e, t), e;
}
function fy(e) {
  const {
    url: t,
    reconnect: n = !0,
    reconnectInterval: r = 3e3,
    maxReconnectAttempts: o = 5,
    onOpen: s,
    onClose: a,
    onError: i
  } = e, [l, c] = h.useState({
    socket: null,
    isConnected: !1,
    isConnecting: !1,
    reconnectAttempts: 0
  }), d = h.useRef(), f = h.useRef(null), p = h.useRef(0), u = h.useRef(!1), g = h.useRef(!1), b = h.useRef(s), x = h.useRef(a), v = h.useRef(i);
  h.useEffect(() => {
    b.current = s, x.current = a, v.current = i;
  }, [s, a, i]);
  const y = h.useCallback(() => {
    var k, E;
    if (u.current && !g.current && ((k = f.current) == null ? void 0 : k.readyState) !== WebSocket.OPEN && ((E = f.current) == null ? void 0 : E.readyState) !== WebSocket.CONNECTING) {
      f.current && (f.current.close(), f.current = null), g.current = !0, c((w) => ({ ...w, isConnecting: !0 }));
      try {
        const w = new WebSocket(t);
        f.current = w, w.onopen = () => {
          var R;
          if (g.current = !1, !u.current) {
            w.close();
            return;
          }
          p.current = 0, c({
            socket: w,
            isConnected: !0,
            isConnecting: !1,
            reconnectAttempts: 0
          }), (R = b.current) == null || R.call(b);
        }, w.onclose = () => {
          var R;
          if (g.current = !1, !!u.current && (c((T) => ({
            ...T,
            socket: null,
            isConnected: !1,
            isConnecting: !1
          })), (R = x.current) == null || R.call(x), n && p.current < o && u.current)) {
            const T = Math.min(r * Math.pow(2, p.current), 3e4);
            d.current = setTimeout(() => {
              u.current && (p.current += 1, c((I) => ({
                ...I,
                reconnectAttempts: p.current
              })), y());
            }, T);
          }
        }, w.onerror = (R) => {
          var T;
          (T = v.current) == null || T.call(v, R);
        };
      } catch (w) {
        g.current = !1, c((R) => ({
          ...R,
          isConnecting: !1
        })), console.error("WebSocket connection error:", w);
      }
    }
  }, [t, n, r, o]), S = h.useCallback(() => {
    d.current && (clearTimeout(d.current), d.current = void 0), f.current && (f.current.close(), f.current = null), g.current = !1, p.current = 0, c({
      socket: null,
      isConnected: !1,
      isConnecting: !1,
      reconnectAttempts: 0
    });
  }, []), C = h.useCallback((k) => {
    var E;
    return ((E = f.current) == null ? void 0 : E.readyState) === WebSocket.OPEN ? (f.current.send(JSON.stringify(k)), !0) : !1;
  }, []);
  return h.useEffect(() => {
    u.current = !0;
    const k = setTimeout(() => {
      u.current && y();
    }, 100);
    return () => {
      u.current = !1, clearTimeout(k), S();
    };
  }, [t]), {
    socket: l.socket,
    isConnected: l.isConnected,
    isConnecting: l.isConnecting,
    reconnectAttempts: l.reconnectAttempts,
    connect: y,
    disconnect: S,
    send: C
  };
}
function py(e = "/ws") {
  return typeof window > "u" ? `ws://localhost${e}` : `${window.location.protocol === "https:" ? "wss:" : "ws:"}//${window.location.host}${e}`;
}
class Ry {
  constructor(t) {
    he(this, "socket", null);
    he(this, "url");
    he(this, "reconnect");
    he(this, "reconnectInterval");
    he(this, "maxReconnectAttempts");
    he(this, "reconnectAttempts", 0);
    he(this, "reconnectTimeout", null);
    he(this, "messageHandlers", /* @__PURE__ */ new Set());
    he(this, "connectionHandlers", /* @__PURE__ */ new Set());
    this.url = t.url, this.reconnect = t.reconnect ?? !0, this.reconnectInterval = t.reconnectInterval ?? 3e3, this.maxReconnectAttempts = t.maxReconnectAttempts ?? 10;
  }
  connect() {
    this.socket && this.socket.close(), this.socket = new WebSocket(this.url), this.socket.onopen = () => {
      this.reconnectAttempts = 0, this.notifyConnectionChange(!0);
    }, this.socket.onclose = () => {
      this.notifyConnectionChange(!1), this.reconnect && this.reconnectAttempts < this.maxReconnectAttempts && (this.reconnectTimeout = setTimeout(() => {
        this.reconnectAttempts++, this.connect();
      }, this.reconnectInterval));
    }, this.socket.onmessage = (t) => {
      try {
        const n = JSON.parse(t.data);
        this.messageHandlers.forEach((r) => r(n));
      } catch (n) {
        console.error("Error parsing WebSocket message:", n);
      }
    };
  }
  disconnect() {
    this.reconnectTimeout && (clearTimeout(this.reconnectTimeout), this.reconnectTimeout = null), this.socket && (this.socket.close(), this.socket = null), this.reconnectAttempts = 0;
  }
  send(t) {
    var n;
    return ((n = this.socket) == null ? void 0 : n.readyState) === WebSocket.OPEN ? (this.socket.send(JSON.stringify(t)), !0) : !1;
  }
  onMessage(t) {
    return this.messageHandlers.add(t), () => this.messageHandlers.delete(t);
  }
  onConnectionChange(t) {
    return this.connectionHandlers.add(t), () => this.connectionHandlers.delete(t);
  }
  notifyConnectionChange(t) {
    this.connectionHandlers.forEach((n) => n(t));
  }
  get isConnected() {
    var t;
    return ((t = this.socket) == null ? void 0 : t.readyState) === WebSocket.OPEN;
  }
}
function my({ initialTree: e, wsUrl: t, className: n }) {
  const r = h.useMemo(() => e || window.__REFAST_INITIAL_DATA__ || null, [e]), o = h.useMemo(() => window.__REFAST_CONFIG__ || {}, []), { socket: s, isConnected: a, isConnecting: i, reconnectAttempts: l } = fy({
    url: t || o.wsUrl || py("/ws"),
    reconnect: !0,
    maxReconnectAttempts: 10,
    onOpen: () => {
    },
    onClose: () => {
    }
  }), { componentTree: c, setComponentTree: d, updateComponent: f, handleUpdate: p } = ay(r || void 0);
  h.useEffect(() => {
    if (s) {
      lt.setWebSocket(s);
      const b = (x) => {
        try {
          const v = JSON.parse(x.data);
          v.type === "store_ready" && lt.handleStoreReady(), v.type === "store_update" && v.updates && lt.handleUpdates(v.updates), v.type === "page_render" && v.component && d(v.component);
        } catch {
        }
      };
      return s.addEventListener("message", b), () => {
        s.removeEventListener("message", b), lt.reset();
      };
    }
    return () => {
      lt.reset();
    };
  }, [s, d]);
  const u = h.useCallback(async () => {
    try {
      const b = window.location.pathname, x = await fetch(`/api/page?path=${encodeURIComponent(b)}`);
      if (x.ok) {
        const v = await x.json();
        v.component && d(v.component);
      }
    } catch (b) {
      console.error("[Refast] Failed to fetch page:", b);
    }
  }, [d]);
  h.useEffect(() => {
    const b = () => {
      s && s.readyState === WebSocket.OPEN && s.send(
        JSON.stringify({
          type: "navigate",
          path: window.location.pathname
        })
      );
    };
    return window.addEventListener("popstate", b), () => {
      window.removeEventListener("popstate", b);
    };
  }, [s]), h.useEffect(() => {
    const b = () => {
      u();
    };
    return window.addEventListener("refast:refresh", b), () => {
      window.removeEventListener("refast:refresh", b);
    };
  }, [u]);
  const g = h.useCallback(
    (b, x, v) => {
      f(b, x, v || "replace");
    },
    [f]
  );
  return h.useEffect(() => {
    if (c) {
      const b = document.getElementById("refast-loading-overlay");
      b && (b.style.display = "none");
    }
  }, [c]), c ? /* @__PURE__ */ m.jsx(
    wf,
    {
      websocket: s,
      onComponentUpdate: g,
      children: /* @__PURE__ */ m.jsx(
        hy,
        {
          tree: c,
          isConnected: a,
          isConnecting: i,
          reconnectAttempts: l,
          onUpdate: p,
          className: n
        }
      )
    }
  ) : null;
}
function hy({
  tree: e,
  isConnected: t,
  isConnecting: n,
  reconnectAttempts: r,
  onUpdate: o,
  className: s
}) {
  const { onUpdate: a } = Lt();
  return h.useEffect(() => a(o), [a, o]), /* @__PURE__ */ m.jsxs(
    "div",
    {
      className: `refast-app ${s || ""}`,
      "data-connected": t,
      "data-connecting": n,
      "data-reconnect-attempts": r,
      children: [
        /* @__PURE__ */ m.jsx(vt, { tree: e }),
        /* @__PURE__ */ m.jsx(dy, {})
      ]
    }
  );
}
function aa() {
  const e = document.getElementById("refast-root");
  e && fa(e).render(P.createElement(my));
}
document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", aa) : aa();
window.RefastClient = {
  componentRegistry: $,
  React: P,
  ReactDOM: zn,
  version: "0.1.0"
};
window.React = P;
window.ReactDOM = zn;
window.dispatchEvent(new CustomEvent("refast:ready"));
export {
  bm as $,
  pg as A,
  Hr as B,
  mg as C,
  ti as D,
  my as E,
  vt as F,
  $ as G,
  rp as H,
  nm as I,
  sp as J,
  Ca as K,
  Sa as L,
  ap as M,
  ip as N,
  lp as O,
  le as P,
  Ea as Q,
  tm as R,
  fp as S,
  op as T,
  pp as U,
  gp as V,
  bp as W,
  mp as X,
  hp as Y,
  hm as Z,
  gm as _,
  Ct as a,
  vm as a0,
  xm as a1,
  ym as a2,
  wm as a3,
  Sm as a4,
  Em as a5,
  km as a6,
  Pm as a7,
  Rm as a8,
  Am as a9,
  wy as aA,
  fy as aB,
  py as aC,
  Ry as aD,
  ay as aE,
  ly as aF,
  cy as aG,
  ep as aH,
  tp as aI,
  Cy as aJ,
  xs as aK,
  np as aL,
  Nm as aa,
  Tm as ab,
  jm as ac,
  Mm as ad,
  Za as ae,
  Qa as af,
  Lm as ag,
  zm as ah,
  Om as ai,
  _m as aj,
  dy as ak,
  it as al,
  ky as am,
  Py as an,
  ib as ao,
  lb as ap,
  cb as aq,
  ub as ar,
  db as as,
  fb as at,
  mb as au,
  hb as av,
  gb as aw,
  wf as ax,
  Lt as ay,
  yy as az,
  ae as b,
  We as c,
  ka as d,
  Vr as e,
  Ia as f,
  Fn as g,
  Ob as h,
  La as i,
  D as j,
  Hn as k,
  Sy as l,
  Cn as m,
  $n as n,
  On as o,
  Ip as p,
  Ge as q,
  wg as r,
  He as s,
  Re as t,
  pe as u,
  ki as v,
  gi as w,
  fg as x,
  hg as y,
  Ey as z
};
