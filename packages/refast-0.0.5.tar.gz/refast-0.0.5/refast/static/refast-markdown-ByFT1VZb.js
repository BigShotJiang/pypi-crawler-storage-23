import { r as un, R as _e, c as De, g as he } from "./refast-charts-C9YTpQC6.js";
var $i = { exports: {} }, zn = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var _l = un, Fl = Symbol.for("react.element"), Dl = Symbol.for("react.fragment"), Pl = Object.prototype.hasOwnProperty, zl = _l.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, Ml = { key: !0, ref: !0, __self: !0, __source: !0 };
function ji(e, n, t) {
  var r, i = {}, l = null, o = null;
  t !== void 0 && (l = "" + t), n.key !== void 0 && (l = "" + n.key), n.ref !== void 0 && (o = n.ref);
  for (r in n) Pl.call(n, r) && !Ml.hasOwnProperty(r) && (i[r] = n[r]);
  if (e && e.defaultProps) for (r in n = e.defaultProps, n) i[r] === void 0 && (i[r] = n[r]);
  return { $$typeof: Fl, type: e, key: l, ref: o, props: i, _owner: zl.current };
}
zn.Fragment = Dl;
zn.jsx = ji;
zn.jsxs = ji;
$i.exports = zn;
var On = $i.exports;
function $l(e, n) {
  if (e == null) return {};
  var t = {};
  for (var r in e) if ({}.hasOwnProperty.call(e, r)) {
    if (n.indexOf(r) !== -1) continue;
    t[r] = e[r];
  }
  return t;
}
function jl(e, n) {
  if (e == null) return {};
  var t, r, i = $l(e, n);
  if (Object.getOwnPropertySymbols) {
    var l = Object.getOwnPropertySymbols(e);
    for (r = 0; r < l.length; r++) t = l[r], n.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (i[t] = e[t]);
  }
  return i;
}
function st(e, n) {
  (n == null || n > e.length) && (n = e.length);
  for (var t = 0, r = Array(n); t < n; t++) r[t] = e[t];
  return r;
}
function Bl(e) {
  if (Array.isArray(e)) return st(e);
}
function Ul(e) {
  if (typeof Symbol < "u" && e[Symbol.iterator] != null || e["@@iterator"] != null) return Array.from(e);
}
function Hl(e, n) {
  if (e) {
    if (typeof e == "string") return st(e, n);
    var t = {}.toString.call(e).slice(8, -1);
    return t === "Object" && e.constructor && (t = e.constructor.name), t === "Map" || t === "Set" ? Array.from(e) : t === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? st(e, n) : void 0;
  }
}
function Vl() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function ut(e) {
  return Bl(e) || Ul(e) || Hl(e) || Vl();
}
function gn(e) {
  "@babel/helpers - typeof";
  return gn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(n) {
    return typeof n;
  } : function(n) {
    return n && typeof Symbol == "function" && n.constructor === Symbol && n !== Symbol.prototype ? "symbol" : typeof n;
  }, gn(e);
}
function ql(e, n) {
  if (gn(e) != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var r = t.call(e, n);
    if (gn(r) != "object") return r;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (n === "string" ? String : Number)(e);
}
function Gl(e) {
  var n = ql(e, "string");
  return gn(n) == "symbol" ? n : n + "";
}
function Bi(e, n, t) {
  return (n = Gl(n)) in e ? Object.defineProperty(e, n, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[n] = t, e;
}
function ct() {
  return ct = Object.assign ? Object.assign.bind() : function(e) {
    for (var n = 1; n < arguments.length; n++) {
      var t = arguments[n];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (e[r] = t[r]);
    }
    return e;
  }, ct.apply(null, arguments);
}
function Er(e, n) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var r = Object.getOwnPropertySymbols(e);
    n && (r = r.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), t.push.apply(t, r);
  }
  return t;
}
function Ke(e) {
  for (var n = 1; n < arguments.length; n++) {
    var t = arguments[n] != null ? arguments[n] : {};
    n % 2 ? Er(Object(t), !0).forEach(function(r) {
      Bi(e, r, t[r]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Er(Object(t)).forEach(function(r) {
      Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
    });
  }
  return e;
}
function Wl(e) {
  var n = e.length;
  if (n === 0 || n === 1) return e;
  if (n === 2)
    return [e[0], e[1], "".concat(e[0], ".").concat(e[1]), "".concat(e[1], ".").concat(e[0])];
  if (n === 3)
    return [e[0], e[1], e[2], "".concat(e[0], ".").concat(e[1]), "".concat(e[0], ".").concat(e[2]), "".concat(e[1], ".").concat(e[0]), "".concat(e[1], ".").concat(e[2]), "".concat(e[2], ".").concat(e[0]), "".concat(e[2], ".").concat(e[1]), "".concat(e[0], ".").concat(e[1], ".").concat(e[2]), "".concat(e[0], ".").concat(e[2], ".").concat(e[1]), "".concat(e[1], ".").concat(e[0], ".").concat(e[2]), "".concat(e[1], ".").concat(e[2], ".").concat(e[0]), "".concat(e[2], ".").concat(e[0], ".").concat(e[1]), "".concat(e[2], ".").concat(e[1], ".").concat(e[0])];
  if (n >= 4)
    return [e[0], e[1], e[2], e[3], "".concat(e[0], ".").concat(e[1]), "".concat(e[0], ".").concat(e[2]), "".concat(e[0], ".").concat(e[3]), "".concat(e[1], ".").concat(e[0]), "".concat(e[1], ".").concat(e[2]), "".concat(e[1], ".").concat(e[3]), "".concat(e[2], ".").concat(e[0]), "".concat(e[2], ".").concat(e[1]), "".concat(e[2], ".").concat(e[3]), "".concat(e[3], ".").concat(e[0]), "".concat(e[3], ".").concat(e[1]), "".concat(e[3], ".").concat(e[2]), "".concat(e[0], ".").concat(e[1], ".").concat(e[2]), "".concat(e[0], ".").concat(e[1], ".").concat(e[3]), "".concat(e[0], ".").concat(e[2], ".").concat(e[1]), "".concat(e[0], ".").concat(e[2], ".").concat(e[3]), "".concat(e[0], ".").concat(e[3], ".").concat(e[1]), "".concat(e[0], ".").concat(e[3], ".").concat(e[2]), "".concat(e[1], ".").concat(e[0], ".").concat(e[2]), "".concat(e[1], ".").concat(e[0], ".").concat(e[3]), "".concat(e[1], ".").concat(e[2], ".").concat(e[0]), "".concat(e[1], ".").concat(e[2], ".").concat(e[3]), "".concat(e[1], ".").concat(e[3], ".").concat(e[0]), "".concat(e[1], ".").concat(e[3], ".").concat(e[2]), "".concat(e[2], ".").concat(e[0], ".").concat(e[1]), "".concat(e[2], ".").concat(e[0], ".").concat(e[3]), "".concat(e[2], ".").concat(e[1], ".").concat(e[0]), "".concat(e[2], ".").concat(e[1], ".").concat(e[3]), "".concat(e[2], ".").concat(e[3], ".").concat(e[0]), "".concat(e[2], ".").concat(e[3], ".").concat(e[1]), "".concat(e[3], ".").concat(e[0], ".").concat(e[1]), "".concat(e[3], ".").concat(e[0], ".").concat(e[2]), "".concat(e[3], ".").concat(e[1], ".").concat(e[0]), "".concat(e[3], ".").concat(e[1], ".").concat(e[2]), "".concat(e[3], ".").concat(e[2], ".").concat(e[0]), "".concat(e[3], ".").concat(e[2], ".").concat(e[1]), "".concat(e[0], ".").concat(e[1], ".").concat(e[2], ".").concat(e[3]), "".concat(e[0], ".").concat(e[1], ".").concat(e[3], ".").concat(e[2]), "".concat(e[0], ".").concat(e[2], ".").concat(e[1], ".").concat(e[3]), "".concat(e[0], ".").concat(e[2], ".").concat(e[3], ".").concat(e[1]), "".concat(e[0], ".").concat(e[3], ".").concat(e[1], ".").concat(e[2]), "".concat(e[0], ".").concat(e[3], ".").concat(e[2], ".").concat(e[1]), "".concat(e[1], ".").concat(e[0], ".").concat(e[2], ".").concat(e[3]), "".concat(e[1], ".").concat(e[0], ".").concat(e[3], ".").concat(e[2]), "".concat(e[1], ".").concat(e[2], ".").concat(e[0], ".").concat(e[3]), "".concat(e[1], ".").concat(e[2], ".").concat(e[3], ".").concat(e[0]), "".concat(e[1], ".").concat(e[3], ".").concat(e[0], ".").concat(e[2]), "".concat(e[1], ".").concat(e[3], ".").concat(e[2], ".").concat(e[0]), "".concat(e[2], ".").concat(e[0], ".").concat(e[1], ".").concat(e[3]), "".concat(e[2], ".").concat(e[0], ".").concat(e[3], ".").concat(e[1]), "".concat(e[2], ".").concat(e[1], ".").concat(e[0], ".").concat(e[3]), "".concat(e[2], ".").concat(e[1], ".").concat(e[3], ".").concat(e[0]), "".concat(e[2], ".").concat(e[3], ".").concat(e[0], ".").concat(e[1]), "".concat(e[2], ".").concat(e[3], ".").concat(e[1], ".").concat(e[0]), "".concat(e[3], ".").concat(e[0], ".").concat(e[1], ".").concat(e[2]), "".concat(e[3], ".").concat(e[0], ".").concat(e[2], ".").concat(e[1]), "".concat(e[3], ".").concat(e[1], ".").concat(e[0], ".").concat(e[2]), "".concat(e[3], ".").concat(e[1], ".").concat(e[2], ".").concat(e[0]), "".concat(e[3], ".").concat(e[2], ".").concat(e[0], ".").concat(e[1]), "".concat(e[3], ".").concat(e[2], ".").concat(e[1], ".").concat(e[0])];
}
var Gn = {};
function Yl(e) {
  if (e.length === 0 || e.length === 1) return e;
  var n = e.join(".");
  return Gn[n] || (Gn[n] = Wl(e)), Gn[n];
}
function Xl(e) {
  var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, t = arguments.length > 2 ? arguments[2] : void 0, r = e.filter(function(l) {
    return l !== "token";
  }), i = Yl(r);
  return i.reduce(function(l, o) {
    return Ke(Ke({}, l), t[o]);
  }, n);
}
function Cr(e) {
  return e.join(" ");
}
function Kl(e, n) {
  var t = 0;
  return function(r) {
    return t += 1, r.map(function(i, l) {
      return Ui({
        node: i,
        stylesheet: e,
        useInlineStyles: n,
        key: "code-segment-".concat(t, "-").concat(l)
      });
    });
  };
}
function Ui(e) {
  var n = e.node, t = e.stylesheet, r = e.style, i = r === void 0 ? {} : r, l = e.useInlineStyles, o = e.key, a = n.properties, s = n.type, u = n.tagName, p = n.value;
  if (s === "text")
    return p;
  if (u) {
    var c = Kl(t, l), h;
    if (!l)
      h = Ke(Ke({}, a), {}, {
        className: Cr(a.className)
      });
    else {
      var f = Object.keys(t).reduce(function(w, k) {
        return k.split(".").forEach(function(y) {
          w.includes(y) || w.push(y);
        }), w;
      }, []), g = a.className && a.className.includes("token") ? ["token"] : [], v = a.className && g.concat(a.className.filter(function(w) {
        return !f.includes(w);
      }));
      h = Ke(Ke({}, a), {}, {
        className: Cr(v) || void 0,
        style: Xl(a.className, Object.assign({}, a.style, i), t)
      });
    }
    var A = c(n.children);
    return /* @__PURE__ */ _e.createElement(u, ct({
      key: o
    }, h), A);
  }
}
const Zl = function(e, n) {
  var t = e.listLanguages();
  return t.indexOf(n) !== -1;
};
var Ql = ["language", "children", "style", "customStyle", "codeTagProps", "useInlineStyles", "showLineNumbers", "showInlineLineNumbers", "startingLineNumber", "lineNumberContainerStyle", "lineNumberStyle", "wrapLines", "wrapLongLines", "lineProps", "renderer", "PreTag", "CodeTag", "code", "astGenerator"];
function Ar(e, n) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var r = Object.getOwnPropertySymbols(e);
    n && (r = r.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), t.push.apply(t, r);
  }
  return t;
}
function Fe(e) {
  for (var n = 1; n < arguments.length; n++) {
    var t = arguments[n] != null ? arguments[n] : {};
    n % 2 ? Ar(Object(t), !0).forEach(function(r) {
      Bi(e, r, t[r]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Ar(Object(t)).forEach(function(r) {
      Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
    });
  }
  return e;
}
var Jl = /\n/g;
function ea(e) {
  return e.match(Jl);
}
function na(e) {
  var n = e.lines, t = e.startingLineNumber, r = e.style;
  return n.map(function(i, l) {
    var o = l + t;
    return /* @__PURE__ */ _e.createElement("span", {
      key: "line-".concat(l),
      className: "react-syntax-highlighter-line-number",
      style: typeof r == "function" ? r(o) : r
    }, "".concat(o, `
`));
  });
}
function ta(e) {
  var n = e.codeString, t = e.codeStyle, r = e.containerStyle, i = r === void 0 ? {
    float: "left",
    paddingRight: "10px"
  } : r, l = e.numberStyle, o = l === void 0 ? {} : l, a = e.startingLineNumber;
  return /* @__PURE__ */ _e.createElement("code", {
    style: Object.assign({}, t, i)
  }, na({
    lines: n.replace(/\n$/, "").split(`
`),
    style: o,
    startingLineNumber: a
  }));
}
function ra(e) {
  return "".concat(e.toString().length, ".25em");
}
function Hi(e, n) {
  return {
    type: "element",
    tagName: "span",
    properties: {
      key: "line-number--".concat(e),
      className: ["comment", "linenumber", "react-syntax-highlighter-line-number"],
      style: n
    },
    children: [{
      type: "text",
      value: e
    }]
  };
}
function Vi(e, n, t) {
  var r = {
    display: "inline-block",
    minWidth: ra(t),
    paddingRight: "1em",
    textAlign: "right",
    userSelect: "none"
  }, i = typeof e == "function" ? e(n) : e, l = Fe(Fe({}, r), i);
  return l;
}
function Ln(e) {
  var n = e.children, t = e.lineNumber, r = e.lineNumberStyle, i = e.largestLineNumber, l = e.showInlineLineNumbers, o = e.lineProps, a = o === void 0 ? {} : o, s = e.className, u = s === void 0 ? [] : s, p = e.showLineNumbers, c = e.wrapLongLines, h = e.wrapLines, f = h === void 0 ? !1 : h, g = f ? Fe({}, typeof a == "function" ? a(t) : a) : {};
  if (g.className = g.className ? [].concat(ut(g.className.trim().split(/\s+/)), ut(u)) : u, t && l) {
    var v = Vi(r, t, i);
    n.unshift(Hi(t, v));
  }
  return c & p && (g.style = Fe({
    display: "flex"
  }, g.style)), {
    type: "element",
    tagName: "span",
    properties: g,
    children: n
  };
}
function qi(e) {
  for (var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [], t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [], r = 0; r < e.length; r++) {
    var i = e[r];
    if (i.type === "text")
      t.push(Ln({
        children: [i],
        className: ut(new Set(n))
      }));
    else if (i.children) {
      var l = n.concat(i.properties.className);
      qi(i.children, l).forEach(function(o) {
        return t.push(o);
      });
    }
  }
  return t;
}
function ia(e, n, t, r, i, l, o, a, s) {
  var u, p = qi(e.value), c = [], h = -1, f = 0;
  function g(S, m) {
    var I = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [];
    return Ln({
      children: S,
      lineNumber: m,
      lineNumberStyle: a,
      largestLineNumber: o,
      showInlineLineNumbers: i,
      lineProps: t,
      className: I,
      showLineNumbers: r,
      wrapLongLines: s,
      wrapLines: n
    });
  }
  function v(S, m) {
    if (r && m && i) {
      var I = Vi(a, m, o);
      S.unshift(Hi(m, I));
    }
    return S;
  }
  function A(S, m) {
    var I = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [];
    return n || I.length > 0 ? g(S, m, I) : v(S, m);
  }
  for (var w = function() {
    var m = p[f], I = m.children[0].value, N = ea(I);
    if (N) {
      var T = I.split(`
`);
      T.forEach(function(x, L) {
        var _ = r && c.length + l, P = {
          type: "text",
          value: "".concat(x, `
`)
        };
        if (L === 0) {
          var j = p.slice(h + 1, f).concat(Ln({
            children: [P],
            className: m.properties.className
          })), D = A(j, _);
          c.push(D);
        } else if (L === T.length - 1) {
          var W = p[f + 1] && p[f + 1].children && p[f + 1].children[0], X = {
            type: "text",
            value: "".concat(x)
          };
          if (W) {
            var B = Ln({
              children: [X],
              className: m.properties.className
            });
            p.splice(f + 1, 0, B);
          } else {
            var Y = [X], d = A(Y, _, m.properties.className);
            c.push(d);
          }
        } else {
          var z = [P], q = A(z, _, m.properties.className);
          c.push(q);
        }
      }), h = f;
    }
    f++;
  }; f < p.length; )
    w();
  if (h !== p.length - 1) {
    var k = p.slice(h + 1, p.length);
    if (k && k.length) {
      var y = r && c.length + l, E = A(k, y);
      c.push(E);
    }
  }
  return n ? c : (u = []).concat.apply(u, c);
}
function oa(e) {
  var n = e.rows, t = e.stylesheet, r = e.useInlineStyles;
  return n.map(function(i, l) {
    return Ui({
      node: i,
      stylesheet: t,
      useInlineStyles: r,
      key: "code-segment-".concat(l)
    });
  });
}
function Gi(e) {
  return e && typeof e.highlightAuto < "u";
}
function la(e) {
  var n = e.astGenerator, t = e.language, r = e.code, i = e.defaultCodeValue;
  if (Gi(n)) {
    var l = Zl(n, t);
    return t === "text" ? {
      value: i,
      language: "text"
    } : l ? n.highlight(t, r) : n.highlightAuto(r);
  }
  try {
    return t && t !== "text" ? {
      value: n.highlight(r, t)
    } : {
      value: i
    };
  } catch {
    return {
      value: i
    };
  }
}
function aa(e, n) {
  return function(r) {
    var i, l, o = r.language, a = r.children, s = r.style, u = s === void 0 ? n : s, p = r.customStyle, c = p === void 0 ? {} : p, h = r.codeTagProps, f = h === void 0 ? {
      className: o ? "language-".concat(o) : void 0,
      style: Fe(Fe({}, u['code[class*="language-"]']), u['code[class*="language-'.concat(o, '"]')])
    } : h, g = r.useInlineStyles, v = g === void 0 ? !0 : g, A = r.showLineNumbers, w = A === void 0 ? !1 : A, k = r.showInlineLineNumbers, y = k === void 0 ? !0 : k, E = r.startingLineNumber, S = E === void 0 ? 1 : E, m = r.lineNumberContainerStyle, I = r.lineNumberStyle, N = I === void 0 ? {} : I, T = r.wrapLines, x = r.wrapLongLines, L = x === void 0 ? !1 : x, _ = r.lineProps, P = _ === void 0 ? {} : _, j = r.renderer, D = r.PreTag, W = D === void 0 ? "pre" : D, X = r.CodeTag, B = X === void 0 ? "code" : X, Y = r.code, d = Y === void 0 ? (Array.isArray(a) ? a[0] : a) || "" : Y, z = r.astGenerator, q = jl(r, Ql);
    z = z || e;
    var b = w ? /* @__PURE__ */ _e.createElement(ta, {
      containerStyle: m,
      codeStyle: f.style || {},
      numberStyle: N,
      startingLineNumber: S,
      codeString: d
    }) : null, ee = u.hljs || u['pre[class*="language-"]'] || {
      backgroundColor: "#fff"
    }, ie = Gi(z) ? "hljs" : "prismjs", K = v ? Object.assign({}, q, {
      style: Object.assign({}, ee, c)
    }) : Object.assign({}, q, {
      className: q.className ? "".concat(ie, " ").concat(q.className) : ie,
      style: Object.assign({}, c)
    });
    if (L ? f.style = Fe({
      whiteSpace: "pre-wrap"
    }, f.style) : f.style = Fe({
      whiteSpace: "pre"
    }, f.style), !z)
      return /* @__PURE__ */ _e.createElement(W, K, b, /* @__PURE__ */ _e.createElement(B, f, d));
    (T === void 0 && j || L) && (T = !0), j = j || oa;
    var oe = [{
      type: "text",
      value: d
    }], le = la({
      astGenerator: z,
      language: o,
      code: d,
      defaultCodeValue: oe
    });
    le.language === null && (le.value = oe);
    var ve = (i = (l = d.match(/\n/g)) === null || l === void 0 ? void 0 : l.length) !== null && i !== void 0 ? i : 0, ye = S + ve, Se = ia(le, T, P, w, y, S, ye, N, L);
    return /* @__PURE__ */ _e.createElement(W, K, /* @__PURE__ */ _e.createElement(B, f, !y && b, j({
      rows: Se,
      stylesheet: u,
      useInlineStyles: v
    })));
  };
}
var sa = ca, ua = Object.prototype.hasOwnProperty;
function ca() {
  for (var e = {}, n = 0; n < arguments.length; n++) {
    var t = arguments[n];
    for (var r in t)
      ua.call(t, r) && (e[r] = t[r]);
  }
  return e;
}
var Wi = Yi, Ct = Yi.prototype;
Ct.space = null;
Ct.normal = {};
Ct.property = {};
function Yi(e, n, t) {
  this.property = e, this.normal = n, t && (this.space = t);
}
var Tr = sa, pa = Wi, fa = ha;
function ha(e) {
  for (var n = e.length, t = [], r = [], i = -1, l, o; ++i < n; )
    l = e[i], t.push(l.property), r.push(l.normal), o = l.space;
  return new pa(
    Tr.apply(null, t),
    Tr.apply(null, r),
    o
  );
}
var At = da;
function da(e) {
  return e.toLowerCase();
}
var Xi = Ki, we = Ki.prototype;
we.space = null;
we.attribute = null;
we.property = null;
we.boolean = !1;
we.booleanish = !1;
we.overloadedBoolean = !1;
we.number = !1;
we.commaSeparated = !1;
we.spaceSeparated = !1;
we.commaOrSpaceSeparated = !1;
we.mustUseProperty = !1;
we.defined = !1;
function Ki(e, n) {
  this.property = e, this.attribute = n;
}
var Te = {}, ga = 0;
Te.boolean = He();
Te.booleanish = He();
Te.overloadedBoolean = He();
Te.number = He();
Te.spaceSeparated = He();
Te.commaSeparated = He();
Te.commaOrSpaceSeparated = He();
function He() {
  return Math.pow(2, ++ga);
}
var Zi = Xi, Ir = Te, Qi = Tt;
Tt.prototype = new Zi();
Tt.prototype.defined = !0;
var Ji = [
  "boolean",
  "booleanish",
  "overloadedBoolean",
  "number",
  "commaSeparated",
  "spaceSeparated",
  "commaOrSpaceSeparated"
], ma = Ji.length;
function Tt(e, n, t, r) {
  var i = -1, l;
  for (Or(this, "space", r), Zi.call(this, e, n); ++i < ma; )
    l = Ji[i], Or(this, l, (t & Ir[l]) === Ir[l]);
}
function Or(e, n, t) {
  t && (e[n] = t);
}
var Lr = At, ba = Wi, ya = Qi, yn = ka;
function ka(e) {
  var n = e.space, t = e.mustUseProperty || [], r = e.attributes || {}, i = e.properties, l = e.transform, o = {}, a = {}, s, u;
  for (s in i)
    u = new ya(
      s,
      l(r, s),
      i[s],
      n
    ), t.indexOf(s) !== -1 && (u.mustUseProperty = !0), o[s] = u, a[Lr(s)] = s, a[Lr(u.attribute)] = s;
  return new ba(o, a, n);
}
var xa = yn, wa = xa({
  space: "xlink",
  transform: va,
  properties: {
    xLinkActuate: null,
    xLinkArcRole: null,
    xLinkHref: null,
    xLinkRole: null,
    xLinkShow: null,
    xLinkTitle: null,
    xLinkType: null
  }
});
function va(e, n) {
  return "xlink:" + n.slice(5).toLowerCase();
}
var Sa = yn, Ea = Sa({
  space: "xml",
  transform: Ca,
  properties: {
    xmlLang: null,
    xmlBase: null,
    xmlSpace: null
  }
});
function Ca(e, n) {
  return "xml:" + n.slice(3).toLowerCase();
}
var Aa = Ta;
function Ta(e, n) {
  return n in e ? e[n] : n;
}
var Ia = Aa, eo = Oa;
function Oa(e, n) {
  return Ia(e, n.toLowerCase());
}
var La = yn, Ra = eo, Na = La({
  space: "xmlns",
  attributes: {
    xmlnsxlink: "xmlns:xlink"
  },
  transform: Ra,
  properties: {
    xmlns: null,
    xmlnsXLink: null
  }
}), It = Te, _a = yn, pe = It.booleanish, ke = It.number, $e = It.spaceSeparated, Fa = _a({
  transform: Da,
  properties: {
    ariaActiveDescendant: null,
    ariaAtomic: pe,
    ariaAutoComplete: null,
    ariaBusy: pe,
    ariaChecked: pe,
    ariaColCount: ke,
    ariaColIndex: ke,
    ariaColSpan: ke,
    ariaControls: $e,
    ariaCurrent: null,
    ariaDescribedBy: $e,
    ariaDetails: null,
    ariaDisabled: pe,
    ariaDropEffect: $e,
    ariaErrorMessage: null,
    ariaExpanded: pe,
    ariaFlowTo: $e,
    ariaGrabbed: pe,
    ariaHasPopup: null,
    ariaHidden: pe,
    ariaInvalid: null,
    ariaKeyShortcuts: null,
    ariaLabel: null,
    ariaLabelledBy: $e,
    ariaLevel: ke,
    ariaLive: null,
    ariaModal: pe,
    ariaMultiLine: pe,
    ariaMultiSelectable: pe,
    ariaOrientation: null,
    ariaOwns: $e,
    ariaPlaceholder: null,
    ariaPosInSet: ke,
    ariaPressed: pe,
    ariaReadOnly: pe,
    ariaRelevant: null,
    ariaRequired: pe,
    ariaRoleDescription: $e,
    ariaRowCount: ke,
    ariaRowIndex: ke,
    ariaRowSpan: ke,
    ariaSelected: pe,
    ariaSetSize: ke,
    ariaSort: null,
    ariaValueMax: ke,
    ariaValueMin: ke,
    ariaValueNow: ke,
    ariaValueText: null,
    role: null
  }
});
function Da(e, n) {
  return n === "role" ? n : "aria-" + n.slice(4).toLowerCase();
}
var Je = Te, Pa = yn, za = eo, U = Je.boolean, Ma = Je.overloadedBoolean, ln = Je.booleanish, ne = Je.number, ue = Je.spaceSeparated, Sn = Je.commaSeparated, $a = Pa({
  space: "html",
  attributes: {
    acceptcharset: "accept-charset",
    classname: "class",
    htmlfor: "for",
    httpequiv: "http-equiv"
  },
  transform: za,
  mustUseProperty: ["checked", "multiple", "muted", "selected"],
  properties: {
    // Standard Properties.
    abbr: null,
    accept: Sn,
    acceptCharset: ue,
    accessKey: ue,
    action: null,
    allow: null,
    allowFullScreen: U,
    allowPaymentRequest: U,
    allowUserMedia: U,
    alt: null,
    as: null,
    async: U,
    autoCapitalize: null,
    autoComplete: ue,
    autoFocus: U,
    autoPlay: U,
    capture: U,
    charSet: null,
    checked: U,
    cite: null,
    className: ue,
    cols: ne,
    colSpan: null,
    content: null,
    contentEditable: ln,
    controls: U,
    controlsList: ue,
    coords: ne | Sn,
    crossOrigin: null,
    data: null,
    dateTime: null,
    decoding: null,
    default: U,
    defer: U,
    dir: null,
    dirName: null,
    disabled: U,
    download: Ma,
    draggable: ln,
    encType: null,
    enterKeyHint: null,
    form: null,
    formAction: null,
    formEncType: null,
    formMethod: null,
    formNoValidate: U,
    formTarget: null,
    headers: ue,
    height: ne,
    hidden: U,
    high: ne,
    href: null,
    hrefLang: null,
    htmlFor: ue,
    httpEquiv: ue,
    id: null,
    imageSizes: null,
    imageSrcSet: Sn,
    inputMode: null,
    integrity: null,
    is: null,
    isMap: U,
    itemId: null,
    itemProp: ue,
    itemRef: ue,
    itemScope: U,
    itemType: ue,
    kind: null,
    label: null,
    lang: null,
    language: null,
    list: null,
    loading: null,
    loop: U,
    low: ne,
    manifest: null,
    max: null,
    maxLength: ne,
    media: null,
    method: null,
    min: null,
    minLength: ne,
    multiple: U,
    muted: U,
    name: null,
    nonce: null,
    noModule: U,
    noValidate: U,
    onAbort: null,
    onAfterPrint: null,
    onAuxClick: null,
    onBeforePrint: null,
    onBeforeUnload: null,
    onBlur: null,
    onCancel: null,
    onCanPlay: null,
    onCanPlayThrough: null,
    onChange: null,
    onClick: null,
    onClose: null,
    onContextMenu: null,
    onCopy: null,
    onCueChange: null,
    onCut: null,
    onDblClick: null,
    onDrag: null,
    onDragEnd: null,
    onDragEnter: null,
    onDragExit: null,
    onDragLeave: null,
    onDragOver: null,
    onDragStart: null,
    onDrop: null,
    onDurationChange: null,
    onEmptied: null,
    onEnded: null,
    onError: null,
    onFocus: null,
    onFormData: null,
    onHashChange: null,
    onInput: null,
    onInvalid: null,
    onKeyDown: null,
    onKeyPress: null,
    onKeyUp: null,
    onLanguageChange: null,
    onLoad: null,
    onLoadedData: null,
    onLoadedMetadata: null,
    onLoadEnd: null,
    onLoadStart: null,
    onMessage: null,
    onMessageError: null,
    onMouseDown: null,
    onMouseEnter: null,
    onMouseLeave: null,
    onMouseMove: null,
    onMouseOut: null,
    onMouseOver: null,
    onMouseUp: null,
    onOffline: null,
    onOnline: null,
    onPageHide: null,
    onPageShow: null,
    onPaste: null,
    onPause: null,
    onPlay: null,
    onPlaying: null,
    onPopState: null,
    onProgress: null,
    onRateChange: null,
    onRejectionHandled: null,
    onReset: null,
    onResize: null,
    onScroll: null,
    onSecurityPolicyViolation: null,
    onSeeked: null,
    onSeeking: null,
    onSelect: null,
    onSlotChange: null,
    onStalled: null,
    onStorage: null,
    onSubmit: null,
    onSuspend: null,
    onTimeUpdate: null,
    onToggle: null,
    onUnhandledRejection: null,
    onUnload: null,
    onVolumeChange: null,
    onWaiting: null,
    onWheel: null,
    open: U,
    optimum: ne,
    pattern: null,
    ping: ue,
    placeholder: null,
    playsInline: U,
    poster: null,
    preload: null,
    readOnly: U,
    referrerPolicy: null,
    rel: ue,
    required: U,
    reversed: U,
    rows: ne,
    rowSpan: ne,
    sandbox: ue,
    scope: null,
    scoped: U,
    seamless: U,
    selected: U,
    shape: null,
    size: ne,
    sizes: null,
    slot: null,
    span: ne,
    spellCheck: ln,
    src: null,
    srcDoc: null,
    srcLang: null,
    srcSet: Sn,
    start: ne,
    step: null,
    style: null,
    tabIndex: ne,
    target: null,
    title: null,
    translate: null,
    type: null,
    typeMustMatch: U,
    useMap: null,
    value: ln,
    width: ne,
    wrap: null,
    // Legacy.
    // See: https://html.spec.whatwg.org/#other-elements,-attributes-and-apis
    align: null,
    // Several. Use CSS `text-align` instead,
    aLink: null,
    // `<body>`. Use CSS `a:active {color}` instead
    archive: ue,
    // `<object>`. List of URIs to archives
    axis: null,
    // `<td>` and `<th>`. Use `scope` on `<th>`
    background: null,
    // `<body>`. Use CSS `background-image` instead
    bgColor: null,
    // `<body>` and table elements. Use CSS `background-color` instead
    border: ne,
    // `<table>`. Use CSS `border-width` instead,
    borderColor: null,
    // `<table>`. Use CSS `border-color` instead,
    bottomMargin: ne,
    // `<body>`
    cellPadding: null,
    // `<table>`
    cellSpacing: null,
    // `<table>`
    char: null,
    // Several table elements. When `align=char`, sets the character to align on
    charOff: null,
    // Several table elements. When `char`, offsets the alignment
    classId: null,
    // `<object>`
    clear: null,
    // `<br>`. Use CSS `clear` instead
    code: null,
    // `<object>`
    codeBase: null,
    // `<object>`
    codeType: null,
    // `<object>`
    color: null,
    // `<font>` and `<hr>`. Use CSS instead
    compact: U,
    // Lists. Use CSS to reduce space between items instead
    declare: U,
    // `<object>`
    event: null,
    // `<script>`
    face: null,
    // `<font>`. Use CSS instead
    frame: null,
    // `<table>`
    frameBorder: null,
    // `<iframe>`. Use CSS `border` instead
    hSpace: ne,
    // `<img>` and `<object>`
    leftMargin: ne,
    // `<body>`
    link: null,
    // `<body>`. Use CSS `a:link {color: *}` instead
    longDesc: null,
    // `<frame>`, `<iframe>`, and `<img>`. Use an `<a>`
    lowSrc: null,
    // `<img>`. Use a `<picture>`
    marginHeight: ne,
    // `<body>`
    marginWidth: ne,
    // `<body>`
    noResize: U,
    // `<frame>`
    noHref: U,
    // `<area>`. Use no href instead of an explicit `nohref`
    noShade: U,
    // `<hr>`. Use background-color and height instead of borders
    noWrap: U,
    // `<td>` and `<th>`
    object: null,
    // `<applet>`
    profile: null,
    // `<head>`
    prompt: null,
    // `<isindex>`
    rev: null,
    // `<link>`
    rightMargin: ne,
    // `<body>`
    rules: null,
    // `<table>`
    scheme: null,
    // `<meta>`
    scrolling: ln,
    // `<frame>`. Use overflow in the child context
    standby: null,
    // `<object>`
    summary: null,
    // `<table>`
    text: null,
    // `<body>`. Use CSS `color` instead
    topMargin: ne,
    // `<body>`
    valueType: null,
    // `<param>`
    version: null,
    // `<html>`. Use a doctype.
    vAlign: null,
    // Several. Use CSS `vertical-align` instead
    vLink: null,
    // `<body>`. Use CSS `a:visited {color}` instead
    vSpace: ne,
    // `<img>` and `<object>`
    // Non-standard Properties.
    allowTransparency: null,
    autoCorrect: null,
    autoSave: null,
    disablePictureInPicture: U,
    disableRemotePlayback: U,
    prefix: null,
    property: null,
    results: ne,
    security: null,
    unselectable: null
  }
}), ja = fa, Ba = wa, Ua = Ea, Ha = Na, Va = Fa, qa = $a, Ga = ja([Ua, Ba, Ha, Va, qa]), Wa = At, Ya = Qi, Xa = Xi, Ot = "data", Ka = Ja, Za = /^data[-\w.:]+$/i, no = /-[a-z]/g, Qa = /[A-Z]/g;
function Ja(e, n) {
  var t = Wa(n), r = n, i = Xa;
  return t in e.normal ? e.property[e.normal[t]] : (t.length > 4 && t.slice(0, 4) === Ot && Za.test(n) && (n.charAt(4) === "-" ? r = es(n) : n = ns(n), i = Ya), new i(r, n));
}
function es(e) {
  var n = e.slice(5).replace(no, rs);
  return Ot + n.charAt(0).toUpperCase() + n.slice(1);
}
function ns(e) {
  var n = e.slice(4);
  return no.test(n) ? e : (n = n.replace(Qa, ts), n.charAt(0) !== "-" && (n = "-" + n), Ot + n);
}
function ts(e) {
  return "-" + e.toLowerCase();
}
function rs(e) {
  return e.charAt(1).toUpperCase();
}
var is = os, Rr = /[#.]/g;
function os(e, n) {
  for (var t = e || "", r = n || "div", i = {}, l = 0, o, a, s; l < t.length; )
    Rr.lastIndex = l, s = Rr.exec(t), o = t.slice(l, s ? s.index : t.length), o && (a ? a === "#" ? i.id = o : i.className ? i.className.push(o) : i.className = [o] : r = o, l += o.length), s && (a = s[0], l++);
  return { type: "element", tagName: r, properties: i, children: [] };
}
var Lt = {};
Lt.parse = ss;
Lt.stringify = us;
var Nr = "", ls = " ", as = /[ \t\n\r\f]+/g;
function ss(e) {
  var n = String(e || Nr).trim();
  return n === Nr ? [] : n.split(as);
}
function us(e) {
  return e.join(ls).trim();
}
var Rt = {};
Rt.parse = cs;
Rt.stringify = ps;
var pt = ",", _r = " ", cn = "";
function cs(e) {
  for (var n = [], t = String(e || cn), r = t.indexOf(pt), i = 0, l = !1, o; !l; )
    r === -1 && (r = t.length, l = !0), o = t.slice(i, r).trim(), (o || !l) && n.push(o), i = r + 1, r = t.indexOf(pt, i);
  return n;
}
function ps(e, n) {
  var t = n || {}, r = t.padLeft === !1 ? cn : _r, i = t.padRight ? _r : cn;
  return e[e.length - 1] === cn && (e = e.concat(cn)), e.join(i + pt + r).trim();
}
var fs = Ka, Fr = At, hs = is, Dr = Lt.parse, Pr = Rt.parse, ds = ms, gs = {}.hasOwnProperty;
function ms(e, n, t) {
  var r = t ? ws(t) : null;
  return i;
  function i(o, a) {
    var s = hs(o, n), u = Array.prototype.slice.call(arguments, 2), p = s.tagName.toLowerCase(), c;
    if (s.tagName = r && gs.call(r, p) ? r[p] : p, a && bs(a, s) && (u.unshift(a), a = null), a)
      for (c in a)
        l(s.properties, c, a[c]);
    return to(s.children, u), s.tagName === "template" && (s.content = { type: "root", children: s.children }, s.children = []), s;
  }
  function l(o, a, s) {
    var u, p, c;
    s == null || s !== s || (u = fs(e, a), p = u.property, c = s, typeof c == "string" && (u.spaceSeparated ? c = Dr(c) : u.commaSeparated ? c = Pr(c) : u.commaOrSpaceSeparated && (c = Dr(Pr(c).join(" ")))), p === "style" && typeof s != "string" && (c = xs(c)), p === "className" && o.className && (c = o.className.concat(c)), o[p] = ks(u, p, c));
  }
}
function bs(e, n) {
  return typeof e == "string" || "length" in e || ys(n.tagName, e);
}
function ys(e, n) {
  var t = n.type;
  return e === "input" || !t || typeof t != "string" ? !1 : typeof n.children == "object" && "length" in n.children ? !0 : (t = t.toLowerCase(), e === "button" ? t !== "menu" && t !== "submit" && t !== "reset" && t !== "button" : "value" in n);
}
function to(e, n) {
  var t, r;
  if (typeof n == "string" || typeof n == "number") {
    e.push({ type: "text", value: String(n) });
    return;
  }
  if (typeof n == "object" && "length" in n) {
    for (t = -1, r = n.length; ++t < r; )
      to(e, n[t]);
    return;
  }
  if (typeof n != "object" || !("type" in n))
    throw new Error("Expected node, nodes, or string, got `" + n + "`");
  e.push(n);
}
function ks(e, n, t) {
  var r, i, l;
  if (typeof t != "object" || !("length" in t))
    return zr(e, n, t);
  for (i = t.length, r = -1, l = []; ++r < i; )
    l[r] = zr(e, n, t[r]);
  return l;
}
function zr(e, n, t) {
  var r = t;
  return e.number || e.positiveNumber ? !isNaN(r) && r !== "" && (r = Number(r)) : (e.boolean || e.overloadedBoolean) && typeof r == "string" && (r === "" || Fr(t) === Fr(n)) && (r = !0), r;
}
function xs(e) {
  var n = [], t;
  for (t in e)
    n.push([t, e[t]].join(": "));
  return n.join("; ");
}
function ws(e) {
  for (var n = e.length, t = -1, r = {}, i; ++t < n; )
    i = e[t], r[i.toLowerCase()] = i;
  return r;
}
var vs = Ga, Ss = ds, ro = Ss(vs, "div");
ro.displayName = "html";
var Es = ro, Cs = Es;
const As = "Æ", Ts = "&", Is = "Á", Os = "Â", Ls = "À", Rs = "Å", Ns = "Ã", _s = "Ä", Fs = "©", Ds = "Ç", Ps = "Ð", zs = "É", Ms = "Ê", $s = "È", js = "Ë", Bs = ">", Us = "Í", Hs = "Î", Vs = "Ì", qs = "Ï", Gs = "<", Ws = "Ñ", Ys = "Ó", Xs = "Ô", Ks = "Ò", Zs = "Ø", Qs = "Õ", Js = "Ö", eu = '"', nu = "®", tu = "Þ", ru = "Ú", iu = "Û", ou = "Ù", lu = "Ü", au = "Ý", su = "á", uu = "â", cu = "´", pu = "æ", fu = "à", hu = "&", du = "å", gu = "ã", mu = "ä", bu = "¦", yu = "ç", ku = "¸", xu = "¢", wu = "©", vu = "¤", Su = "°", Eu = "÷", Cu = "é", Au = "ê", Tu = "è", Iu = "ð", Ou = "ë", Lu = "½", Ru = "¼", Nu = "¾", _u = ">", Fu = "í", Du = "î", Pu = "¡", zu = "ì", Mu = "¿", $u = "ï", ju = "«", Bu = "<", Uu = "¯", Hu = "µ", Vu = "·", qu = " ", Gu = "¬", Wu = "ñ", Yu = "ó", Xu = "ô", Ku = "ò", Zu = "ª", Qu = "º", Ju = "ø", ec = "õ", nc = "ö", tc = "¶", rc = "±", ic = "£", oc = '"', lc = "»", ac = "®", sc = "§", uc = "­", cc = "¹", pc = "²", fc = "³", hc = "ß", dc = "þ", gc = "×", mc = "ú", bc = "û", yc = "ù", kc = "¨", xc = "ü", wc = "ý", vc = "¥", Sc = "ÿ", Ec = {
  AElig: As,
  AMP: Ts,
  Aacute: Is,
  Acirc: Os,
  Agrave: Ls,
  Aring: Rs,
  Atilde: Ns,
  Auml: _s,
  COPY: Fs,
  Ccedil: Ds,
  ETH: Ps,
  Eacute: zs,
  Ecirc: Ms,
  Egrave: $s,
  Euml: js,
  GT: Bs,
  Iacute: Us,
  Icirc: Hs,
  Igrave: Vs,
  Iuml: qs,
  LT: Gs,
  Ntilde: Ws,
  Oacute: Ys,
  Ocirc: Xs,
  Ograve: Ks,
  Oslash: Zs,
  Otilde: Qs,
  Ouml: Js,
  QUOT: eu,
  REG: nu,
  THORN: tu,
  Uacute: ru,
  Ucirc: iu,
  Ugrave: ou,
  Uuml: lu,
  Yacute: au,
  aacute: su,
  acirc: uu,
  acute: cu,
  aelig: pu,
  agrave: fu,
  amp: hu,
  aring: du,
  atilde: gu,
  auml: mu,
  brvbar: bu,
  ccedil: yu,
  cedil: ku,
  cent: xu,
  copy: wu,
  curren: vu,
  deg: Su,
  divide: Eu,
  eacute: Cu,
  ecirc: Au,
  egrave: Tu,
  eth: Iu,
  euml: Ou,
  frac12: Lu,
  frac14: Ru,
  frac34: Nu,
  gt: _u,
  iacute: Fu,
  icirc: Du,
  iexcl: Pu,
  igrave: zu,
  iquest: Mu,
  iuml: $u,
  laquo: ju,
  lt: Bu,
  macr: Uu,
  micro: Hu,
  middot: Vu,
  nbsp: qu,
  not: Gu,
  ntilde: Wu,
  oacute: Yu,
  ocirc: Xu,
  ograve: Ku,
  ordf: Zu,
  ordm: Qu,
  oslash: Ju,
  otilde: ec,
  ouml: nc,
  para: tc,
  plusmn: rc,
  pound: ic,
  quot: oc,
  raquo: lc,
  reg: ac,
  sect: sc,
  shy: uc,
  sup1: cc,
  sup2: pc,
  sup3: fc,
  szlig: hc,
  thorn: dc,
  times: gc,
  uacute: mc,
  ucirc: bc,
  ugrave: yc,
  uml: kc,
  uuml: xc,
  yacute: wc,
  yen: vc,
  yuml: Sc
}, Cc = {
  0: "�",
  128: "€",
  130: "‚",
  131: "ƒ",
  132: "„",
  133: "…",
  134: "†",
  135: "‡",
  136: "ˆ",
  137: "‰",
  138: "Š",
  139: "‹",
  140: "Œ",
  142: "Ž",
  145: "‘",
  146: "’",
  147: "“",
  148: "”",
  149: "•",
  150: "–",
  151: "—",
  152: "˜",
  153: "™",
  154: "š",
  155: "›",
  156: "œ",
  158: "ž",
  159: "Ÿ"
};
var io = Ac;
function Ac(e) {
  var n = typeof e == "string" ? e.charCodeAt(0) : e;
  return n >= 48 && n <= 57;
}
var Tc = Ic;
function Ic(e) {
  var n = typeof e == "string" ? e.charCodeAt(0) : e;
  return n >= 97 && n <= 102 || n >= 65 && n <= 70 || n >= 48 && n <= 57;
}
var Oc = Lc;
function Lc(e) {
  var n = typeof e == "string" ? e.charCodeAt(0) : e;
  return n >= 97 && n <= 122 || n >= 65 && n <= 90;
}
var Rc = Oc, Nc = io, _c = Fc;
function Fc(e) {
  return Rc(e) || Nc(e);
}
var En, Dc = 59, Pc = zc;
function zc(e) {
  var n = "&" + e + ";", t;
  return En = En || document.createElement("i"), En.innerHTML = n, t = En.textContent, t.charCodeAt(t.length - 1) === Dc && e !== "semi" || t === n ? !1 : t;
}
var Mr = Ec, $r = Cc, Mc = io, $c = Tc, oo = _c, jc = Pc, Bc = ep, Uc = {}.hasOwnProperty, Ge = String.fromCharCode, Hc = Function.prototype, jr = {
  warning: null,
  reference: null,
  text: null,
  warningContext: null,
  referenceContext: null,
  textContext: null,
  position: {},
  additional: null,
  attribute: !1,
  nonTerminated: !0
}, Vc = 9, Br = 10, qc = 12, Gc = 32, Ur = 38, Wc = 59, Yc = 60, Xc = 61, Kc = 35, Zc = 88, Qc = 120, Jc = 65533, Ye = "named", Nt = "hexadecimal", _t = "decimal", Ft = {};
Ft[Nt] = 16;
Ft[_t] = 10;
var Mn = {};
Mn[Ye] = oo;
Mn[_t] = Mc;
Mn[Nt] = $c;
var lo = 1, ao = 2, so = 3, uo = 4, co = 5, ft = 6, po = 7, Pe = {};
Pe[lo] = "Named character references must be terminated by a semicolon";
Pe[ao] = "Numeric character references must be terminated by a semicolon";
Pe[so] = "Named character references cannot be empty";
Pe[uo] = "Numeric character references cannot be empty";
Pe[co] = "Named character references must be known";
Pe[ft] = "Numeric character references cannot be disallowed";
Pe[po] = "Numeric character references cannot be outside the permissible Unicode range";
function ep(e, n) {
  var t = {}, r, i;
  n || (n = {});
  for (i in jr)
    r = n[i], t[i] = r ?? jr[i];
  return (t.position.indent || t.position.start) && (t.indent = t.position.indent || [], t.position = t.position.start), np(e, t);
}
function np(e, n) {
  var t = n.additional, r = n.nonTerminated, i = n.text, l = n.reference, o = n.warning, a = n.textContext, s = n.referenceContext, u = n.warningContext, p = n.position, c = n.indent || [], h = e.length, f = 0, g = -1, v = p.column || 1, A = p.line || 1, w = "", k = [], y, E, S, m, I, N, T, x, L, _, P, j, D, W, X, B, Y, d, z;
  for (typeof t == "string" && (t = t.charCodeAt(0)), B = q(), x = o ? b : Hc, f--, h++; ++f < h; )
    if (I === Br && (v = c[g] || 1), I = e.charCodeAt(f), I === Ur) {
      if (T = e.charCodeAt(f + 1), T === Vc || T === Br || T === qc || T === Gc || T === Ur || T === Yc || T !== T || t && T === t) {
        w += Ge(I), v++;
        continue;
      }
      for (D = f + 1, j = D, z = D, T === Kc ? (z = ++j, T = e.charCodeAt(z), T === Zc || T === Qc ? (W = Nt, z = ++j) : W = _t) : W = Ye, y = "", P = "", m = "", X = Mn[W], z--; ++z < h && (T = e.charCodeAt(z), !!X(T)); )
        m += Ge(T), W === Ye && Uc.call(Mr, m) && (y = m, P = Mr[m]);
      S = e.charCodeAt(z) === Wc, S && (z++, E = W === Ye ? jc(m) : !1, E && (y = m, P = E)), d = 1 + z - D, !S && !r || (m ? W === Ye ? (S && !P ? x(co, 1) : (y !== m && (z = j + y.length, d = 1 + z - j, S = !1), S || (L = y ? lo : so, n.attribute ? (T = e.charCodeAt(z), T === Xc ? (x(L, d), P = null) : oo(T) ? P = null : x(L, d)) : x(L, d))), N = P) : (S || x(ao, d), N = parseInt(m, Ft[W]), tp(N) ? (x(po, d), N = Ge(Jc)) : N in $r ? (x(ft, d), N = $r[N]) : (_ = "", rp(N) && x(ft, d), N > 65535 && (N -= 65536, _ += Ge(N >>> 10 | 55296), N = 56320 | N & 1023), N = _ + Ge(N))) : W !== Ye && x(uo, d)), N ? (ee(), B = q(), f = z - 1, v += z - D + 1, k.push(N), Y = q(), Y.offset++, l && l.call(
        s,
        N,
        { start: B, end: Y },
        e.slice(D - 1, z)
      ), B = Y) : (m = e.slice(D - 1, z), w += m, v += m.length, f = z - 1);
    } else
      I === 10 && (A++, g++, v = 0), I === I ? (w += Ge(I), v++) : ee();
  return k.join("");
  function q() {
    return {
      line: A,
      column: v,
      offset: f + (p.offset || 0)
    };
  }
  function b(ie, K) {
    var oe = q();
    oe.column += K, oe.offset += K, o.call(u, Pe[ie], oe, ie);
  }
  function ee() {
    w && (k.push(w), i && i.call(a, w, { start: B, end: q() }), w = "");
  }
}
function tp(e) {
  return e >= 55296 && e <= 57343 || e > 1114111;
}
function rp(e) {
  return e >= 1 && e <= 8 || e === 11 || e >= 13 && e <= 31 || e >= 127 && e <= 159 || e >= 64976 && e <= 65007 || (e & 65535) === 65535 || (e & 65535) === 65534;
}
var fo = { exports: {} };
(function(e) {
  var n = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(r) {
    var i = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, l = 0, o = {}, a = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: r.Prism && r.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: r.Prism && r.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function k(y) {
          return y instanceof s ? new s(y.type, k(y.content), y.alias) : Array.isArray(y) ? y.map(k) : y.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(k) {
          return Object.prototype.toString.call(k).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(k) {
          return k.__id || Object.defineProperty(k, "__id", { value: ++l }), k.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function k(y, E) {
          E = E || {};
          var S, m;
          switch (a.util.type(y)) {
            case "Object":
              if (m = a.util.objId(y), E[m])
                return E[m];
              S = /** @type {Record<string, any>} */
              {}, E[m] = S;
              for (var I in y)
                y.hasOwnProperty(I) && (S[I] = k(y[I], E));
              return (
                /** @type {any} */
                S
              );
            case "Array":
              return m = a.util.objId(y), E[m] ? E[m] : (S = [], E[m] = S, /** @type {Array} */
              /** @type {any} */
              y.forEach(function(N, T) {
                S[T] = k(N, E);
              }), /** @type {any} */
              S);
            default:
              return y;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(k) {
          for (; k; ) {
            var y = i.exec(k.className);
            if (y)
              return y[1].toLowerCase();
            k = k.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(k, y) {
          k.className = k.className.replace(RegExp(i, "gi"), ""), k.classList.add("language-" + y);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (S) {
            var k = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(S.stack) || [])[1];
            if (k) {
              var y = document.getElementsByTagName("script");
              for (var E in y)
                if (y[E].src == k)
                  return y[E];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(k, y, E) {
          for (var S = "no-" + y; k; ) {
            var m = k.classList;
            if (m.contains(y))
              return !0;
            if (m.contains(S))
              return !1;
            k = k.parentElement;
          }
          return !!E;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: o,
        plaintext: o,
        text: o,
        txt: o,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(k, y) {
          var E = a.util.clone(a.languages[k]);
          for (var S in y)
            E[S] = y[S];
          return E;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(k, y, E, S) {
          S = S || /** @type {any} */
          a.languages;
          var m = S[k], I = {};
          for (var N in m)
            if (m.hasOwnProperty(N)) {
              if (N == y)
                for (var T in E)
                  E.hasOwnProperty(T) && (I[T] = E[T]);
              E.hasOwnProperty(N) || (I[N] = m[N]);
            }
          var x = S[k];
          return S[k] = I, a.languages.DFS(a.languages, function(L, _) {
            _ === x && L != k && (this[L] = I);
          }), I;
        },
        // Traverse a language definition with Depth First Search
        DFS: function k(y, E, S, m) {
          m = m || {};
          var I = a.util.objId;
          for (var N in y)
            if (y.hasOwnProperty(N)) {
              E.call(y, N, y[N], S || N);
              var T = y[N], x = a.util.type(T);
              x === "Object" && !m[I(T)] ? (m[I(T)] = !0, k(T, E, null, m)) : x === "Array" && !m[I(T)] && (m[I(T)] = !0, k(T, E, N, m));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(k, y) {
        a.highlightAllUnder(document, k, y);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(k, y, E) {
        var S = {
          callback: E,
          container: k,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        a.hooks.run("before-highlightall", S), S.elements = Array.prototype.slice.apply(S.container.querySelectorAll(S.selector)), a.hooks.run("before-all-elements-highlight", S);
        for (var m = 0, I; I = S.elements[m++]; )
          a.highlightElement(I, y === !0, S.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(k, y, E) {
        var S = a.util.getLanguage(k), m = a.languages[S];
        a.util.setLanguage(k, S);
        var I = k.parentElement;
        I && I.nodeName.toLowerCase() === "pre" && a.util.setLanguage(I, S);
        var N = k.textContent, T = {
          element: k,
          language: S,
          grammar: m,
          code: N
        };
        function x(_) {
          T.highlightedCode = _, a.hooks.run("before-insert", T), T.element.innerHTML = T.highlightedCode, a.hooks.run("after-highlight", T), a.hooks.run("complete", T), E && E.call(T.element);
        }
        if (a.hooks.run("before-sanity-check", T), I = T.element.parentElement, I && I.nodeName.toLowerCase() === "pre" && !I.hasAttribute("tabindex") && I.setAttribute("tabindex", "0"), !T.code) {
          a.hooks.run("complete", T), E && E.call(T.element);
          return;
        }
        if (a.hooks.run("before-highlight", T), !T.grammar) {
          x(a.util.encode(T.code));
          return;
        }
        if (y && r.Worker) {
          var L = new Worker(a.filename);
          L.onmessage = function(_) {
            x(_.data);
          }, L.postMessage(JSON.stringify({
            language: T.language,
            code: T.code,
            immediateClose: !0
          }));
        } else
          x(a.highlight(T.code, T.grammar, T.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(k, y, E) {
        var S = {
          code: k,
          grammar: y,
          language: E
        };
        if (a.hooks.run("before-tokenize", S), !S.grammar)
          throw new Error('The language "' + S.language + '" has no grammar.');
        return S.tokens = a.tokenize(S.code, S.grammar), a.hooks.run("after-tokenize", S), s.stringify(a.util.encode(S.tokens), S.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(k, y) {
        var E = y.rest;
        if (E) {
          for (var S in E)
            y[S] = E[S];
          delete y.rest;
        }
        var m = new c();
        return h(m, m.head, k), p(k, m, y, m.head, 0), g(m);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(k, y) {
          var E = a.hooks.all;
          E[k] = E[k] || [], E[k].push(y);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(k, y) {
          var E = a.hooks.all[k];
          if (!(!E || !E.length))
            for (var S = 0, m; m = E[S++]; )
              m(y);
        }
      },
      Token: s
    };
    r.Prism = a;
    function s(k, y, E, S) {
      this.type = k, this.content = y, this.alias = E, this.length = (S || "").length | 0;
    }
    s.stringify = function k(y, E) {
      if (typeof y == "string")
        return y;
      if (Array.isArray(y)) {
        var S = "";
        return y.forEach(function(x) {
          S += k(x, E);
        }), S;
      }
      var m = {
        type: y.type,
        content: k(y.content, E),
        tag: "span",
        classes: ["token", y.type],
        attributes: {},
        language: E
      }, I = y.alias;
      I && (Array.isArray(I) ? Array.prototype.push.apply(m.classes, I) : m.classes.push(I)), a.hooks.run("wrap", m);
      var N = "";
      for (var T in m.attributes)
        N += " " + T + '="' + (m.attributes[T] || "").replace(/"/g, "&quot;") + '"';
      return "<" + m.tag + ' class="' + m.classes.join(" ") + '"' + N + ">" + m.content + "</" + m.tag + ">";
    };
    function u(k, y, E, S) {
      k.lastIndex = y;
      var m = k.exec(E);
      if (m && S && m[1]) {
        var I = m[1].length;
        m.index += I, m[0] = m[0].slice(I);
      }
      return m;
    }
    function p(k, y, E, S, m, I) {
      for (var N in E)
        if (!(!E.hasOwnProperty(N) || !E[N])) {
          var T = E[N];
          T = Array.isArray(T) ? T : [T];
          for (var x = 0; x < T.length; ++x) {
            if (I && I.cause == N + "," + x)
              return;
            var L = T[x], _ = L.inside, P = !!L.lookbehind, j = !!L.greedy, D = L.alias;
            if (j && !L.pattern.global) {
              var W = L.pattern.toString().match(/[imsuy]*$/)[0];
              L.pattern = RegExp(L.pattern.source, W + "g");
            }
            for (var X = L.pattern || L, B = S.next, Y = m; B !== y.tail && !(I && Y >= I.reach); Y += B.value.length, B = B.next) {
              var d = B.value;
              if (y.length > k.length)
                return;
              if (!(d instanceof s)) {
                var z = 1, q;
                if (j) {
                  if (q = u(X, Y, k, P), !q || q.index >= k.length)
                    break;
                  var K = q.index, b = q.index + q[0].length, ee = Y;
                  for (ee += B.value.length; K >= ee; )
                    B = B.next, ee += B.value.length;
                  if (ee -= B.value.length, Y = ee, B.value instanceof s)
                    continue;
                  for (var ie = B; ie !== y.tail && (ee < b || typeof ie.value == "string"); ie = ie.next)
                    z++, ee += ie.value.length;
                  z--, d = k.slice(Y, ee), q.index -= Y;
                } else if (q = u(X, 0, d, P), !q)
                  continue;
                var K = q.index, oe = q[0], le = d.slice(0, K), ve = d.slice(K + oe.length), ye = Y + d.length;
                I && ye > I.reach && (I.reach = ye);
                var Se = B.prev;
                le && (Se = h(y, Se, le), Y += le.length), f(y, Se, z);
                var qn = new s(N, _ ? a.tokenize(oe, _) : oe, D, oe);
                if (B = h(y, Se, qn), ve && h(y, B, ve), z > 1) {
                  var tn = {
                    cause: N + "," + x,
                    reach: ye
                  };
                  p(k, y, E, B.prev, Y, tn), I && tn.reach > I.reach && (I.reach = tn.reach);
                }
              }
            }
          }
        }
    }
    function c() {
      var k = { value: null, prev: null, next: null }, y = { value: null, prev: k, next: null };
      k.next = y, this.head = k, this.tail = y, this.length = 0;
    }
    function h(k, y, E) {
      var S = y.next, m = { value: E, prev: y, next: S };
      return y.next = m, S.prev = m, k.length++, m;
    }
    function f(k, y, E) {
      for (var S = y.next, m = 0; m < E && S !== k.tail; m++)
        S = S.next;
      y.next = S, S.prev = y, k.length -= m;
    }
    function g(k) {
      for (var y = [], E = k.head.next; E !== k.tail; )
        y.push(E.value), E = E.next;
      return y;
    }
    if (!r.document)
      return r.addEventListener && (a.disableWorkerMessageHandler || r.addEventListener("message", function(k) {
        var y = JSON.parse(k.data), E = y.language, S = y.code, m = y.immediateClose;
        r.postMessage(a.highlight(S, a.languages[E], E)), m && r.close();
      }, !1)), a;
    var v = a.util.currentScript();
    v && (a.filename = v.src, v.hasAttribute("data-manual") && (a.manual = !0));
    function A() {
      a.manual || a.highlightAll();
    }
    if (!a.manual) {
      var w = document.readyState;
      w === "loading" || w === "interactive" && v && v.defer ? document.addEventListener("DOMContentLoaded", A) : window.requestAnimationFrame ? window.requestAnimationFrame(A) : window.setTimeout(A, 16);
    }
    return a;
  }(n);
  e.exports && (e.exports = t), typeof De < "u" && (De.Prism = t);
})(fo);
var ip = fo.exports, op = Dt;
Dt.displayName = "markup";
Dt.aliases = ["html", "mathml", "svg", "xml", "ssml", "atom", "rss"];
function Dt(e) {
  e.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              /"|'/
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, e.languages.markup.tag.inside["attr-value"].inside.entity = e.languages.markup.entity, e.languages.markup.doctype.inside["internal-subset"].inside = e.languages.markup, e.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.value.replace(/&amp;/, "&"));
  }), Object.defineProperty(e.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(t, r) {
      var i = {};
      i["language-" + r] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: e.languages[r]
      }, i.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var l = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: i
        }
      };
      l["language-" + r] = {
        pattern: /[\s\S]+/,
        inside: e.languages[r]
      };
      var o = {};
      o[t] = {
        pattern: RegExp(
          /(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(
            /__/g,
            function() {
              return t;
            }
          ),
          "i"
        ),
        lookbehind: !0,
        greedy: !0,
        inside: l
      }, e.languages.insertBefore("markup", "cdata", o);
    }
  }), Object.defineProperty(e.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, t) {
      e.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [t, "language-" + t],
                inside: e.languages[t]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), e.languages.html = e.languages.markup, e.languages.mathml = e.languages.markup, e.languages.svg = e.languages.markup, e.languages.xml = e.languages.extend("markup", {}), e.languages.ssml = e.languages.xml, e.languages.atom = e.languages.xml, e.languages.rss = e.languages.xml;
}
var ho = Pt;
Pt.displayName = "css";
Pt.aliases = [];
function Pt(e) {
  (function(n) {
    var t = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: /@[\w-](?:[^;{\s]|\s+(?![\s{]))*(?:;|(?=\s*\{))/,
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp(
          "\\burl\\((?:" + t.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)",
          "i"
        ),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + t.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(
          `(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + t.source + ")*(?=\\s*\\{)"
        ),
        lookbehind: !0
      },
      string: {
        pattern: t,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var r = n.languages.markup;
    r && (r.tag.addInlined("style", "css"), r.tag.addAttribute("style", "css"));
  })(e);
}
const lp = /* @__PURE__ */ he(ho);
var ap = zt;
zt.displayName = "clike";
zt.aliases = [];
function zt(e) {
  e.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  };
}
var go = Mt;
Mt.displayName = "javascript";
Mt.aliases = ["js"];
function Mt(e) {
  e.languages.javascript = e.languages.extend("clike", {
    "class-name": [
      e.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), e.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, e.languages.insertBefore("javascript", "keyword", {
    regex: {
      // eslint-disable-next-line regexp/no-dupe-characters-character-class
      pattern: /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)\/(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/,
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: e.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: e.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: e.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: e.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: e.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), e.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: e.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), e.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), e.languages.markup && (e.languages.markup.tag.addInlined("script", "javascript"), e.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), e.languages.js = e.languages.javascript;
}
const sp = /* @__PURE__ */ he(go);
var pn = typeof globalThis == "object" ? globalThis : typeof self == "object" ? self : typeof window == "object" ? window : typeof De == "object" ? De : {}, up = Cp();
pn.Prism = { manual: !0, disableWorkerMessageHandler: !0 };
var cp = Cs, pp = Bc, mo = ip, fp = op, hp = ho, dp = ap, gp = go;
up();
var $t = {}.hasOwnProperty;
function bo() {
}
bo.prototype = mo;
var re = new bo(), mp = re;
re.highlight = yp;
re.register = kn;
re.alias = bp;
re.registered = kp;
re.listLanguages = xp;
kn(fp);
kn(hp);
kn(dp);
kn(gp);
re.util.encode = Sp;
re.Token.stringify = wp;
function kn(e) {
  if (typeof e != "function" || !e.displayName)
    throw new Error("Expected `function` for `grammar`, got `" + e + "`");
  re.languages[e.displayName] === void 0 && e(re);
}
function bp(e, n) {
  var t = re.languages, r = e, i, l, o, a;
  n && (r = {}, r[e] = n);
  for (i in r)
    for (l = r[i], l = typeof l == "string" ? [l] : l, o = l.length, a = -1; ++a < o; )
      t[l[a]] = t[i];
}
function yp(e, n) {
  var t = mo.highlight, r;
  if (typeof e != "string")
    throw new Error("Expected `string` for `value`, got `" + e + "`");
  if (re.util.type(n) === "Object")
    r = n, n = null;
  else {
    if (typeof n != "string")
      throw new Error("Expected `string` for `name`, got `" + n + "`");
    if ($t.call(re.languages, n))
      r = re.languages[n];
    else
      throw new Error("Unknown language: `" + n + "` is not registered");
  }
  return t.call(this, e, r, n);
}
function kp(e) {
  if (typeof e != "string")
    throw new Error("Expected `string` for `language`, got `" + e + "`");
  return $t.call(re.languages, e);
}
function xp() {
  var e = re.languages, n = [], t;
  for (t in e)
    $t.call(e, t) && typeof e[t] == "object" && n.push(t);
  return n;
}
function wp(e, n, t) {
  var r;
  return typeof e == "string" ? { type: "text", value: e } : re.util.type(e) === "Array" ? vp(e, n) : (r = {
    type: e.type,
    content: re.Token.stringify(e.content, n, t),
    tag: "span",
    classes: ["token", e.type],
    attributes: {},
    language: n,
    parent: t
  }, e.alias && (r.classes = r.classes.concat(e.alias)), re.hooks.run("wrap", r), cp(
    r.tag + "." + r.classes.join("."),
    Ep(r.attributes),
    r.content
  ));
}
function vp(e, n) {
  for (var t = [], r = e.length, i = -1, l; ++i < r; )
    l = e[i], l !== "" && l !== null && l !== void 0 && t.push(l);
  for (i = -1, r = t.length; ++i < r; )
    l = t[i], t[i] = re.Token.stringify(l, n, t);
  return t;
}
function Sp(e) {
  return e;
}
function Ep(e) {
  var n;
  for (n in e)
    e[n] = pp(e[n]);
  return e;
}
function Cp() {
  var e = "Prism" in pn, n = e ? pn.Prism : void 0;
  return t;
  function t() {
    e ? pn.Prism = n : delete pn.Prism, e = void 0, n = void 0;
  }
}
const jt = /* @__PURE__ */ he(mp);
var Bt = aa(jt, {});
Bt.registerLanguage = function(e, n) {
  return jt.register(n);
};
Bt.alias = function(e, n) {
  return jt.alias(e, n);
};
const zy = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Bt
}, Symbol.toStringTag, { value: "Module" })), Ap = {
  'code[class*="language-"]': {
    background: "hsl(220, 13%, 18%)",
    color: "hsl(220, 14%, 71%)",
    textShadow: "0 1px rgba(0, 0, 0, 0.3)",
    fontFamily: '"Fira Code", "Fira Mono", Menlo, Consolas, "DejaVu Sans Mono", monospace',
    direction: "ltr",
    textAlign: "left",
    whiteSpace: "pre",
    wordSpacing: "normal",
    wordBreak: "normal",
    lineHeight: "1.5",
    MozTabSize: "2",
    OTabSize: "2",
    tabSize: "2",
    WebkitHyphens: "none",
    MozHyphens: "none",
    msHyphens: "none",
    hyphens: "none"
  },
  'pre[class*="language-"]': {
    background: "hsl(220, 13%, 18%)",
    color: "hsl(220, 14%, 71%)",
    textShadow: "0 1px rgba(0, 0, 0, 0.3)",
    fontFamily: '"Fira Code", "Fira Mono", Menlo, Consolas, "DejaVu Sans Mono", monospace',
    direction: "ltr",
    textAlign: "left",
    whiteSpace: "pre",
    wordSpacing: "normal",
    wordBreak: "normal",
    lineHeight: "1.5",
    MozTabSize: "2",
    OTabSize: "2",
    tabSize: "2",
    WebkitHyphens: "none",
    MozHyphens: "none",
    msHyphens: "none",
    hyphens: "none",
    padding: "1em",
    margin: "0.5em 0",
    overflow: "auto",
    borderRadius: "0.3em"
  },
  'code[class*="language-"]::-moz-selection': {
    background: "hsl(220, 13%, 28%)",
    color: "inherit",
    textShadow: "none"
  },
  'code[class*="language-"] *::-moz-selection': {
    background: "hsl(220, 13%, 28%)",
    color: "inherit",
    textShadow: "none"
  },
  'pre[class*="language-"] *::-moz-selection': {
    background: "hsl(220, 13%, 28%)",
    color: "inherit",
    textShadow: "none"
  },
  'code[class*="language-"]::selection': {
    background: "hsl(220, 13%, 28%)",
    color: "inherit",
    textShadow: "none"
  },
  'code[class*="language-"] *::selection': {
    background: "hsl(220, 13%, 28%)",
    color: "inherit",
    textShadow: "none"
  },
  'pre[class*="language-"] *::selection': {
    background: "hsl(220, 13%, 28%)",
    color: "inherit",
    textShadow: "none"
  },
  ':not(pre) > code[class*="language-"]': {
    padding: "0.2em 0.3em",
    borderRadius: "0.3em",
    whiteSpace: "normal"
  },
  comment: {
    color: "hsl(220, 10%, 40%)",
    fontStyle: "italic"
  },
  prolog: {
    color: "hsl(220, 10%, 40%)"
  },
  cdata: {
    color: "hsl(220, 10%, 40%)"
  },
  doctype: {
    color: "hsl(220, 14%, 71%)"
  },
  punctuation: {
    color: "hsl(220, 14%, 71%)"
  },
  entity: {
    color: "hsl(220, 14%, 71%)",
    cursor: "help"
  },
  "attr-name": {
    color: "hsl(29, 54%, 61%)"
  },
  "class-name": {
    color: "hsl(29, 54%, 61%)"
  },
  boolean: {
    color: "hsl(29, 54%, 61%)"
  },
  constant: {
    color: "hsl(29, 54%, 61%)"
  },
  number: {
    color: "hsl(29, 54%, 61%)"
  },
  atrule: {
    color: "hsl(29, 54%, 61%)"
  },
  keyword: {
    color: "hsl(286, 60%, 67%)"
  },
  property: {
    color: "hsl(355, 65%, 65%)"
  },
  tag: {
    color: "hsl(355, 65%, 65%)"
  },
  symbol: {
    color: "hsl(355, 65%, 65%)"
  },
  deleted: {
    color: "hsl(355, 65%, 65%)"
  },
  important: {
    color: "hsl(355, 65%, 65%)"
  },
  selector: {
    color: "hsl(95, 38%, 62%)"
  },
  string: {
    color: "hsl(95, 38%, 62%)"
  },
  char: {
    color: "hsl(95, 38%, 62%)"
  },
  builtin: {
    color: "hsl(95, 38%, 62%)"
  },
  inserted: {
    color: "hsl(95, 38%, 62%)"
  },
  regex: {
    color: "hsl(95, 38%, 62%)"
  },
  "attr-value": {
    color: "hsl(95, 38%, 62%)"
  },
  "attr-value > .token.punctuation": {
    color: "hsl(95, 38%, 62%)"
  },
  variable: {
    color: "hsl(207, 82%, 66%)"
  },
  operator: {
    color: "hsl(207, 82%, 66%)"
  },
  function: {
    color: "hsl(207, 82%, 66%)"
  },
  url: {
    color: "hsl(187, 47%, 55%)"
  },
  "attr-value > .token.punctuation.attr-equals": {
    color: "hsl(220, 14%, 71%)"
  },
  "special-attr > .token.attr-value > .token.value.css": {
    color: "hsl(220, 14%, 71%)"
  },
  ".language-css .token.selector": {
    color: "hsl(355, 65%, 65%)"
  },
  ".language-css .token.property": {
    color: "hsl(220, 14%, 71%)"
  },
  ".language-css .token.function": {
    color: "hsl(187, 47%, 55%)"
  },
  ".language-css .token.url > .token.function": {
    color: "hsl(187, 47%, 55%)"
  },
  ".language-css .token.url > .token.string.url": {
    color: "hsl(95, 38%, 62%)"
  },
  ".language-css .token.important": {
    color: "hsl(286, 60%, 67%)"
  },
  ".language-css .token.atrule .token.rule": {
    color: "hsl(286, 60%, 67%)"
  },
  ".language-javascript .token.operator": {
    color: "hsl(286, 60%, 67%)"
  },
  ".language-javascript .token.template-string > .token.interpolation > .token.interpolation-punctuation.punctuation": {
    color: "hsl(5, 48%, 51%)"
  },
  ".language-json .token.operator": {
    color: "hsl(220, 14%, 71%)"
  },
  ".language-json .token.null.keyword": {
    color: "hsl(29, 54%, 61%)"
  },
  ".language-markdown .token.url": {
    color: "hsl(220, 14%, 71%)"
  },
  ".language-markdown .token.url > .token.operator": {
    color: "hsl(220, 14%, 71%)"
  },
  ".language-markdown .token.url-reference.url > .token.string": {
    color: "hsl(220, 14%, 71%)"
  },
  ".language-markdown .token.url > .token.content": {
    color: "hsl(207, 82%, 66%)"
  },
  ".language-markdown .token.url > .token.url": {
    color: "hsl(187, 47%, 55%)"
  },
  ".language-markdown .token.url-reference.url": {
    color: "hsl(187, 47%, 55%)"
  },
  ".language-markdown .token.blockquote.punctuation": {
    color: "hsl(220, 10%, 40%)",
    fontStyle: "italic"
  },
  ".language-markdown .token.hr.punctuation": {
    color: "hsl(220, 10%, 40%)",
    fontStyle: "italic"
  },
  ".language-markdown .token.code-snippet": {
    color: "hsl(95, 38%, 62%)"
  },
  ".language-markdown .token.bold .token.content": {
    color: "hsl(29, 54%, 61%)"
  },
  ".language-markdown .token.italic .token.content": {
    color: "hsl(286, 60%, 67%)"
  },
  ".language-markdown .token.strike .token.content": {
    color: "hsl(355, 65%, 65%)"
  },
  ".language-markdown .token.strike .token.punctuation": {
    color: "hsl(355, 65%, 65%)"
  },
  ".language-markdown .token.list.punctuation": {
    color: "hsl(355, 65%, 65%)"
  },
  ".language-markdown .token.title.important > .token.punctuation": {
    color: "hsl(355, 65%, 65%)"
  },
  bold: {
    fontWeight: "bold"
  },
  italic: {
    fontStyle: "italic"
  },
  namespace: {
    Opacity: "0.8"
  },
  "token.tab:not(:empty):before": {
    color: "hsla(220, 14%, 71%, 0.15)",
    textShadow: "none"
  },
  "token.cr:before": {
    color: "hsla(220, 14%, 71%, 0.15)",
    textShadow: "none"
  },
  "token.lf:before": {
    color: "hsla(220, 14%, 71%, 0.15)",
    textShadow: "none"
  },
  "token.space:before": {
    color: "hsla(220, 14%, 71%, 0.15)",
    textShadow: "none"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item": {
    marginRight: "0.4em"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item > button": {
    background: "hsl(220, 13%, 26%)",
    color: "hsl(220, 9%, 55%)",
    padding: "0.1em 0.4em",
    borderRadius: "0.3em"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item > a": {
    background: "hsl(220, 13%, 26%)",
    color: "hsl(220, 9%, 55%)",
    padding: "0.1em 0.4em",
    borderRadius: "0.3em"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item > span": {
    background: "hsl(220, 13%, 26%)",
    color: "hsl(220, 9%, 55%)",
    padding: "0.1em 0.4em",
    borderRadius: "0.3em"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item > button:hover": {
    background: "hsl(220, 13%, 28%)",
    color: "hsl(220, 14%, 71%)"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item > button:focus": {
    background: "hsl(220, 13%, 28%)",
    color: "hsl(220, 14%, 71%)"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item > a:hover": {
    background: "hsl(220, 13%, 28%)",
    color: "hsl(220, 14%, 71%)"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item > a:focus": {
    background: "hsl(220, 13%, 28%)",
    color: "hsl(220, 14%, 71%)"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item > span:hover": {
    background: "hsl(220, 13%, 28%)",
    color: "hsl(220, 14%, 71%)"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item > span:focus": {
    background: "hsl(220, 13%, 28%)",
    color: "hsl(220, 14%, 71%)"
  },
  ".line-highlight.line-highlight": {
    background: "hsla(220, 100%, 80%, 0.04)"
  },
  ".line-highlight.line-highlight:before": {
    background: "hsl(220, 13%, 26%)",
    color: "hsl(220, 14%, 71%)",
    padding: "0.1em 0.6em",
    borderRadius: "0.3em",
    boxShadow: "0 2px 0 0 rgba(0, 0, 0, 0.2)"
  },
  ".line-highlight.line-highlight[data-end]:after": {
    background: "hsl(220, 13%, 26%)",
    color: "hsl(220, 14%, 71%)",
    padding: "0.1em 0.6em",
    borderRadius: "0.3em",
    boxShadow: "0 2px 0 0 rgba(0, 0, 0, 0.2)"
  },
  "pre[id].linkable-line-numbers.linkable-line-numbers span.line-numbers-rows > span:hover:before": {
    backgroundColor: "hsla(220, 100%, 80%, 0.04)"
  },
  ".line-numbers.line-numbers .line-numbers-rows": {
    borderRightColor: "hsla(220, 14%, 71%, 0.15)"
  },
  ".command-line .command-line-prompt": {
    borderRightColor: "hsla(220, 14%, 71%, 0.15)"
  },
  ".line-numbers .line-numbers-rows > span:before": {
    color: "hsl(220, 14%, 45%)"
  },
  ".command-line .command-line-prompt > span:before": {
    color: "hsl(220, 14%, 45%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-1": {
    color: "hsl(355, 65%, 65%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-5": {
    color: "hsl(355, 65%, 65%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-9": {
    color: "hsl(355, 65%, 65%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-2": {
    color: "hsl(95, 38%, 62%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-6": {
    color: "hsl(95, 38%, 62%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-10": {
    color: "hsl(95, 38%, 62%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-3": {
    color: "hsl(207, 82%, 66%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-7": {
    color: "hsl(207, 82%, 66%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-11": {
    color: "hsl(207, 82%, 66%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-4": {
    color: "hsl(286, 60%, 67%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-8": {
    color: "hsl(286, 60%, 67%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-12": {
    color: "hsl(286, 60%, 67%)"
  },
  "pre.diff-highlight > code .token.token.deleted:not(.prefix)": {
    backgroundColor: "hsla(353, 100%, 66%, 0.15)"
  },
  "pre > code.diff-highlight .token.token.deleted:not(.prefix)": {
    backgroundColor: "hsla(353, 100%, 66%, 0.15)"
  },
  "pre.diff-highlight > code .token.token.deleted:not(.prefix)::-moz-selection": {
    backgroundColor: "hsla(353, 95%, 66%, 0.25)"
  },
  "pre.diff-highlight > code .token.token.deleted:not(.prefix) *::-moz-selection": {
    backgroundColor: "hsla(353, 95%, 66%, 0.25)"
  },
  "pre > code.diff-highlight .token.token.deleted:not(.prefix)::-moz-selection": {
    backgroundColor: "hsla(353, 95%, 66%, 0.25)"
  },
  "pre > code.diff-highlight .token.token.deleted:not(.prefix) *::-moz-selection": {
    backgroundColor: "hsla(353, 95%, 66%, 0.25)"
  },
  "pre.diff-highlight > code .token.token.deleted:not(.prefix)::selection": {
    backgroundColor: "hsla(353, 95%, 66%, 0.25)"
  },
  "pre.diff-highlight > code .token.token.deleted:not(.prefix) *::selection": {
    backgroundColor: "hsla(353, 95%, 66%, 0.25)"
  },
  "pre > code.diff-highlight .token.token.deleted:not(.prefix)::selection": {
    backgroundColor: "hsla(353, 95%, 66%, 0.25)"
  },
  "pre > code.diff-highlight .token.token.deleted:not(.prefix) *::selection": {
    backgroundColor: "hsla(353, 95%, 66%, 0.25)"
  },
  "pre.diff-highlight > code .token.token.inserted:not(.prefix)": {
    backgroundColor: "hsla(137, 100%, 55%, 0.15)"
  },
  "pre > code.diff-highlight .token.token.inserted:not(.prefix)": {
    backgroundColor: "hsla(137, 100%, 55%, 0.15)"
  },
  "pre.diff-highlight > code .token.token.inserted:not(.prefix)::-moz-selection": {
    backgroundColor: "hsla(135, 73%, 55%, 0.25)"
  },
  "pre.diff-highlight > code .token.token.inserted:not(.prefix) *::-moz-selection": {
    backgroundColor: "hsla(135, 73%, 55%, 0.25)"
  },
  "pre > code.diff-highlight .token.token.inserted:not(.prefix)::-moz-selection": {
    backgroundColor: "hsla(135, 73%, 55%, 0.25)"
  },
  "pre > code.diff-highlight .token.token.inserted:not(.prefix) *::-moz-selection": {
    backgroundColor: "hsla(135, 73%, 55%, 0.25)"
  },
  "pre.diff-highlight > code .token.token.inserted:not(.prefix)::selection": {
    backgroundColor: "hsla(135, 73%, 55%, 0.25)"
  },
  "pre.diff-highlight > code .token.token.inserted:not(.prefix) *::selection": {
    backgroundColor: "hsla(135, 73%, 55%, 0.25)"
  },
  "pre > code.diff-highlight .token.token.inserted:not(.prefix)::selection": {
    backgroundColor: "hsla(135, 73%, 55%, 0.25)"
  },
  "pre > code.diff-highlight .token.token.inserted:not(.prefix) *::selection": {
    backgroundColor: "hsla(135, 73%, 55%, 0.25)"
  },
  ".prism-previewer.prism-previewer:before": {
    borderColor: "hsl(224, 13%, 17%)"
  },
  ".prism-previewer-gradient.prism-previewer-gradient div": {
    borderColor: "hsl(224, 13%, 17%)",
    borderRadius: "0.3em"
  },
  ".prism-previewer-color.prism-previewer-color:before": {
    borderRadius: "0.3em"
  },
  ".prism-previewer-easing.prism-previewer-easing:before": {
    borderRadius: "0.3em"
  },
  ".prism-previewer.prism-previewer:after": {
    borderTopColor: "hsl(224, 13%, 17%)"
  },
  ".prism-previewer-flipped.prism-previewer-flipped.after": {
    borderBottomColor: "hsl(224, 13%, 17%)"
  },
  ".prism-previewer-angle.prism-previewer-angle:before": {
    background: "hsl(219, 13%, 22%)"
  },
  ".prism-previewer-time.prism-previewer-time:before": {
    background: "hsl(219, 13%, 22%)"
  },
  ".prism-previewer-easing.prism-previewer-easing": {
    background: "hsl(219, 13%, 22%)"
  },
  ".prism-previewer-angle.prism-previewer-angle circle": {
    stroke: "hsl(220, 14%, 71%)",
    strokeOpacity: "1"
  },
  ".prism-previewer-time.prism-previewer-time circle": {
    stroke: "hsl(220, 14%, 71%)",
    strokeOpacity: "1"
  },
  ".prism-previewer-easing.prism-previewer-easing circle": {
    stroke: "hsl(220, 14%, 71%)",
    fill: "transparent"
  },
  ".prism-previewer-easing.prism-previewer-easing path": {
    stroke: "hsl(220, 14%, 71%)"
  },
  ".prism-previewer-easing.prism-previewer-easing line": {
    stroke: "hsl(220, 14%, 71%)"
  }
}, My = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Ap
}, Symbol.toStringTag, { value: "Module" })), Tp = {
  'code[class*="language-"]': {
    background: "hsl(230, 1%, 98%)",
    color: "hsl(230, 8%, 24%)",
    fontFamily: '"Fira Code", "Fira Mono", Menlo, Consolas, "DejaVu Sans Mono", monospace',
    direction: "ltr",
    textAlign: "left",
    whiteSpace: "pre",
    wordSpacing: "normal",
    wordBreak: "normal",
    lineHeight: "1.5",
    MozTabSize: "2",
    OTabSize: "2",
    tabSize: "2",
    WebkitHyphens: "none",
    MozHyphens: "none",
    msHyphens: "none",
    hyphens: "none"
  },
  'pre[class*="language-"]': {
    background: "hsl(230, 1%, 98%)",
    color: "hsl(230, 8%, 24%)",
    fontFamily: '"Fira Code", "Fira Mono", Menlo, Consolas, "DejaVu Sans Mono", monospace',
    direction: "ltr",
    textAlign: "left",
    whiteSpace: "pre",
    wordSpacing: "normal",
    wordBreak: "normal",
    lineHeight: "1.5",
    MozTabSize: "2",
    OTabSize: "2",
    tabSize: "2",
    WebkitHyphens: "none",
    MozHyphens: "none",
    msHyphens: "none",
    hyphens: "none",
    padding: "1em",
    margin: "0.5em 0",
    overflow: "auto",
    borderRadius: "0.3em"
  },
  'code[class*="language-"]::-moz-selection': {
    background: "hsl(230, 1%, 90%)",
    color: "inherit"
  },
  'code[class*="language-"] *::-moz-selection': {
    background: "hsl(230, 1%, 90%)",
    color: "inherit"
  },
  'pre[class*="language-"] *::-moz-selection': {
    background: "hsl(230, 1%, 90%)",
    color: "inherit"
  },
  'code[class*="language-"]::selection': {
    background: "hsl(230, 1%, 90%)",
    color: "inherit"
  },
  'code[class*="language-"] *::selection': {
    background: "hsl(230, 1%, 90%)",
    color: "inherit"
  },
  'pre[class*="language-"] *::selection': {
    background: "hsl(230, 1%, 90%)",
    color: "inherit"
  },
  ':not(pre) > code[class*="language-"]': {
    padding: "0.2em 0.3em",
    borderRadius: "0.3em",
    whiteSpace: "normal"
  },
  comment: {
    color: "hsl(230, 4%, 64%)",
    fontStyle: "italic"
  },
  prolog: {
    color: "hsl(230, 4%, 64%)"
  },
  cdata: {
    color: "hsl(230, 4%, 64%)"
  },
  doctype: {
    color: "hsl(230, 8%, 24%)"
  },
  punctuation: {
    color: "hsl(230, 8%, 24%)"
  },
  entity: {
    color: "hsl(230, 8%, 24%)",
    cursor: "help"
  },
  "attr-name": {
    color: "hsl(35, 99%, 36%)"
  },
  "class-name": {
    color: "hsl(35, 99%, 36%)"
  },
  boolean: {
    color: "hsl(35, 99%, 36%)"
  },
  constant: {
    color: "hsl(35, 99%, 36%)"
  },
  number: {
    color: "hsl(35, 99%, 36%)"
  },
  atrule: {
    color: "hsl(35, 99%, 36%)"
  },
  keyword: {
    color: "hsl(301, 63%, 40%)"
  },
  property: {
    color: "hsl(5, 74%, 59%)"
  },
  tag: {
    color: "hsl(5, 74%, 59%)"
  },
  symbol: {
    color: "hsl(5, 74%, 59%)"
  },
  deleted: {
    color: "hsl(5, 74%, 59%)"
  },
  important: {
    color: "hsl(5, 74%, 59%)"
  },
  selector: {
    color: "hsl(119, 34%, 47%)"
  },
  string: {
    color: "hsl(119, 34%, 47%)"
  },
  char: {
    color: "hsl(119, 34%, 47%)"
  },
  builtin: {
    color: "hsl(119, 34%, 47%)"
  },
  inserted: {
    color: "hsl(119, 34%, 47%)"
  },
  regex: {
    color: "hsl(119, 34%, 47%)"
  },
  "attr-value": {
    color: "hsl(119, 34%, 47%)"
  },
  "attr-value > .token.punctuation": {
    color: "hsl(119, 34%, 47%)"
  },
  variable: {
    color: "hsl(221, 87%, 60%)"
  },
  operator: {
    color: "hsl(221, 87%, 60%)"
  },
  function: {
    color: "hsl(221, 87%, 60%)"
  },
  url: {
    color: "hsl(198, 99%, 37%)"
  },
  "attr-value > .token.punctuation.attr-equals": {
    color: "hsl(230, 8%, 24%)"
  },
  "special-attr > .token.attr-value > .token.value.css": {
    color: "hsl(230, 8%, 24%)"
  },
  ".language-css .token.selector": {
    color: "hsl(5, 74%, 59%)"
  },
  ".language-css .token.property": {
    color: "hsl(230, 8%, 24%)"
  },
  ".language-css .token.function": {
    color: "hsl(198, 99%, 37%)"
  },
  ".language-css .token.url > .token.function": {
    color: "hsl(198, 99%, 37%)"
  },
  ".language-css .token.url > .token.string.url": {
    color: "hsl(119, 34%, 47%)"
  },
  ".language-css .token.important": {
    color: "hsl(301, 63%, 40%)"
  },
  ".language-css .token.atrule .token.rule": {
    color: "hsl(301, 63%, 40%)"
  },
  ".language-javascript .token.operator": {
    color: "hsl(301, 63%, 40%)"
  },
  ".language-javascript .token.template-string > .token.interpolation > .token.interpolation-punctuation.punctuation": {
    color: "hsl(344, 84%, 43%)"
  },
  ".language-json .token.operator": {
    color: "hsl(230, 8%, 24%)"
  },
  ".language-json .token.null.keyword": {
    color: "hsl(35, 99%, 36%)"
  },
  ".language-markdown .token.url": {
    color: "hsl(230, 8%, 24%)"
  },
  ".language-markdown .token.url > .token.operator": {
    color: "hsl(230, 8%, 24%)"
  },
  ".language-markdown .token.url-reference.url > .token.string": {
    color: "hsl(230, 8%, 24%)"
  },
  ".language-markdown .token.url > .token.content": {
    color: "hsl(221, 87%, 60%)"
  },
  ".language-markdown .token.url > .token.url": {
    color: "hsl(198, 99%, 37%)"
  },
  ".language-markdown .token.url-reference.url": {
    color: "hsl(198, 99%, 37%)"
  },
  ".language-markdown .token.blockquote.punctuation": {
    color: "hsl(230, 4%, 64%)",
    fontStyle: "italic"
  },
  ".language-markdown .token.hr.punctuation": {
    color: "hsl(230, 4%, 64%)",
    fontStyle: "italic"
  },
  ".language-markdown .token.code-snippet": {
    color: "hsl(119, 34%, 47%)"
  },
  ".language-markdown .token.bold .token.content": {
    color: "hsl(35, 99%, 36%)"
  },
  ".language-markdown .token.italic .token.content": {
    color: "hsl(301, 63%, 40%)"
  },
  ".language-markdown .token.strike .token.content": {
    color: "hsl(5, 74%, 59%)"
  },
  ".language-markdown .token.strike .token.punctuation": {
    color: "hsl(5, 74%, 59%)"
  },
  ".language-markdown .token.list.punctuation": {
    color: "hsl(5, 74%, 59%)"
  },
  ".language-markdown .token.title.important > .token.punctuation": {
    color: "hsl(5, 74%, 59%)"
  },
  bold: {
    fontWeight: "bold"
  },
  italic: {
    fontStyle: "italic"
  },
  namespace: {
    Opacity: "0.8"
  },
  "token.tab:not(:empty):before": {
    color: "hsla(230, 8%, 24%, 0.2)"
  },
  "token.cr:before": {
    color: "hsla(230, 8%, 24%, 0.2)"
  },
  "token.lf:before": {
    color: "hsla(230, 8%, 24%, 0.2)"
  },
  "token.space:before": {
    color: "hsla(230, 8%, 24%, 0.2)"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item": {
    marginRight: "0.4em"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item > button": {
    background: "hsl(230, 1%, 90%)",
    color: "hsl(230, 6%, 44%)",
    padding: "0.1em 0.4em",
    borderRadius: "0.3em"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item > a": {
    background: "hsl(230, 1%, 90%)",
    color: "hsl(230, 6%, 44%)",
    padding: "0.1em 0.4em",
    borderRadius: "0.3em"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item > span": {
    background: "hsl(230, 1%, 90%)",
    color: "hsl(230, 6%, 44%)",
    padding: "0.1em 0.4em",
    borderRadius: "0.3em"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item > button:hover": {
    background: "hsl(230, 1%, 78%)",
    color: "hsl(230, 8%, 24%)"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item > button:focus": {
    background: "hsl(230, 1%, 78%)",
    color: "hsl(230, 8%, 24%)"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item > a:hover": {
    background: "hsl(230, 1%, 78%)",
    color: "hsl(230, 8%, 24%)"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item > a:focus": {
    background: "hsl(230, 1%, 78%)",
    color: "hsl(230, 8%, 24%)"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item > span:hover": {
    background: "hsl(230, 1%, 78%)",
    color: "hsl(230, 8%, 24%)"
  },
  "div.code-toolbar > .toolbar.toolbar > .toolbar-item > span:focus": {
    background: "hsl(230, 1%, 78%)",
    color: "hsl(230, 8%, 24%)"
  },
  ".line-highlight.line-highlight": {
    background: "hsla(230, 8%, 24%, 0.05)"
  },
  ".line-highlight.line-highlight:before": {
    background: "hsl(230, 1%, 90%)",
    color: "hsl(230, 8%, 24%)",
    padding: "0.1em 0.6em",
    borderRadius: "0.3em",
    boxShadow: "0 2px 0 0 rgba(0, 0, 0, 0.2)"
  },
  ".line-highlight.line-highlight[data-end]:after": {
    background: "hsl(230, 1%, 90%)",
    color: "hsl(230, 8%, 24%)",
    padding: "0.1em 0.6em",
    borderRadius: "0.3em",
    boxShadow: "0 2px 0 0 rgba(0, 0, 0, 0.2)"
  },
  "pre[id].linkable-line-numbers.linkable-line-numbers span.line-numbers-rows > span:hover:before": {
    backgroundColor: "hsla(230, 8%, 24%, 0.05)"
  },
  ".line-numbers.line-numbers .line-numbers-rows": {
    borderRightColor: "hsla(230, 8%, 24%, 0.2)"
  },
  ".command-line .command-line-prompt": {
    borderRightColor: "hsla(230, 8%, 24%, 0.2)"
  },
  ".line-numbers .line-numbers-rows > span:before": {
    color: "hsl(230, 1%, 62%)"
  },
  ".command-line .command-line-prompt > span:before": {
    color: "hsl(230, 1%, 62%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-1": {
    color: "hsl(5, 74%, 59%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-5": {
    color: "hsl(5, 74%, 59%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-9": {
    color: "hsl(5, 74%, 59%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-2": {
    color: "hsl(119, 34%, 47%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-6": {
    color: "hsl(119, 34%, 47%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-10": {
    color: "hsl(119, 34%, 47%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-3": {
    color: "hsl(221, 87%, 60%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-7": {
    color: "hsl(221, 87%, 60%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-11": {
    color: "hsl(221, 87%, 60%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-4": {
    color: "hsl(301, 63%, 40%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-8": {
    color: "hsl(301, 63%, 40%)"
  },
  ".rainbow-braces .token.token.punctuation.brace-level-12": {
    color: "hsl(301, 63%, 40%)"
  },
  "pre.diff-highlight > code .token.token.deleted:not(.prefix)": {
    backgroundColor: "hsla(353, 100%, 66%, 0.15)"
  },
  "pre > code.diff-highlight .token.token.deleted:not(.prefix)": {
    backgroundColor: "hsla(353, 100%, 66%, 0.15)"
  },
  "pre.diff-highlight > code .token.token.deleted:not(.prefix)::-moz-selection": {
    backgroundColor: "hsla(353, 95%, 66%, 0.25)"
  },
  "pre.diff-highlight > code .token.token.deleted:not(.prefix) *::-moz-selection": {
    backgroundColor: "hsla(353, 95%, 66%, 0.25)"
  },
  "pre > code.diff-highlight .token.token.deleted:not(.prefix)::-moz-selection": {
    backgroundColor: "hsla(353, 95%, 66%, 0.25)"
  },
  "pre > code.diff-highlight .token.token.deleted:not(.prefix) *::-moz-selection": {
    backgroundColor: "hsla(353, 95%, 66%, 0.25)"
  },
  "pre.diff-highlight > code .token.token.deleted:not(.prefix)::selection": {
    backgroundColor: "hsla(353, 95%, 66%, 0.25)"
  },
  "pre.diff-highlight > code .token.token.deleted:not(.prefix) *::selection": {
    backgroundColor: "hsla(353, 95%, 66%, 0.25)"
  },
  "pre > code.diff-highlight .token.token.deleted:not(.prefix)::selection": {
    backgroundColor: "hsla(353, 95%, 66%, 0.25)"
  },
  "pre > code.diff-highlight .token.token.deleted:not(.prefix) *::selection": {
    backgroundColor: "hsla(353, 95%, 66%, 0.25)"
  },
  "pre.diff-highlight > code .token.token.inserted:not(.prefix)": {
    backgroundColor: "hsla(137, 100%, 55%, 0.15)"
  },
  "pre > code.diff-highlight .token.token.inserted:not(.prefix)": {
    backgroundColor: "hsla(137, 100%, 55%, 0.15)"
  },
  "pre.diff-highlight > code .token.token.inserted:not(.prefix)::-moz-selection": {
    backgroundColor: "hsla(135, 73%, 55%, 0.25)"
  },
  "pre.diff-highlight > code .token.token.inserted:not(.prefix) *::-moz-selection": {
    backgroundColor: "hsla(135, 73%, 55%, 0.25)"
  },
  "pre > code.diff-highlight .token.token.inserted:not(.prefix)::-moz-selection": {
    backgroundColor: "hsla(135, 73%, 55%, 0.25)"
  },
  "pre > code.diff-highlight .token.token.inserted:not(.prefix) *::-moz-selection": {
    backgroundColor: "hsla(135, 73%, 55%, 0.25)"
  },
  "pre.diff-highlight > code .token.token.inserted:not(.prefix)::selection": {
    backgroundColor: "hsla(135, 73%, 55%, 0.25)"
  },
  "pre.diff-highlight > code .token.token.inserted:not(.prefix) *::selection": {
    backgroundColor: "hsla(135, 73%, 55%, 0.25)"
  },
  "pre > code.diff-highlight .token.token.inserted:not(.prefix)::selection": {
    backgroundColor: "hsla(135, 73%, 55%, 0.25)"
  },
  "pre > code.diff-highlight .token.token.inserted:not(.prefix) *::selection": {
    backgroundColor: "hsla(135, 73%, 55%, 0.25)"
  },
  ".prism-previewer.prism-previewer:before": {
    borderColor: "hsl(0, 0, 95%)"
  },
  ".prism-previewer-gradient.prism-previewer-gradient div": {
    borderColor: "hsl(0, 0, 95%)",
    borderRadius: "0.3em"
  },
  ".prism-previewer-color.prism-previewer-color:before": {
    borderRadius: "0.3em"
  },
  ".prism-previewer-easing.prism-previewer-easing:before": {
    borderRadius: "0.3em"
  },
  ".prism-previewer.prism-previewer:after": {
    borderTopColor: "hsl(0, 0, 95%)"
  },
  ".prism-previewer-flipped.prism-previewer-flipped.after": {
    borderBottomColor: "hsl(0, 0, 95%)"
  },
  ".prism-previewer-angle.prism-previewer-angle:before": {
    background: "hsl(0, 0%, 100%)"
  },
  ".prism-previewer-time.prism-previewer-time:before": {
    background: "hsl(0, 0%, 100%)"
  },
  ".prism-previewer-easing.prism-previewer-easing": {
    background: "hsl(0, 0%, 100%)"
  },
  ".prism-previewer-angle.prism-previewer-angle circle": {
    stroke: "hsl(230, 8%, 24%)",
    strokeOpacity: "1"
  },
  ".prism-previewer-time.prism-previewer-time circle": {
    stroke: "hsl(230, 8%, 24%)",
    strokeOpacity: "1"
  },
  ".prism-previewer-easing.prism-previewer-easing circle": {
    stroke: "hsl(230, 8%, 24%)",
    fill: "transparent"
  },
  ".prism-previewer-easing.prism-previewer-easing path": {
    stroke: "hsl(230, 8%, 24%)"
  },
  ".prism-previewer-easing.prism-previewer-easing line": {
    stroke: "hsl(230, 8%, 24%)"
  }
}, $y = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Tp
}, Symbol.toStringTag, { value: "Module" })), jy = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: sp
}, Symbol.toStringTag, { value: "Module" }));
var yo = Ut;
Ut.displayName = "typescript";
Ut.aliases = ["ts"];
function Ut(e) {
  (function(n) {
    n.languages.typescript = n.languages.extend("javascript", {
      "class-name": {
        pattern: /(\b(?:class|extends|implements|instanceof|interface|new|type)\s+)(?!keyof\b)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?:\s*<(?:[^<>]|<(?:[^<>]|<[^<>]*>)*>)*>)?/,
        lookbehind: !0,
        greedy: !0,
        inside: null
        // see below
      },
      builtin: /\b(?:Array|Function|Promise|any|boolean|console|never|number|string|symbol|unknown)\b/
    }), n.languages.typescript.keyword.push(
      /\b(?:abstract|declare|is|keyof|readonly|require)\b/,
      // keywords that have to be followed by an identifier
      /\b(?:asserts|infer|interface|module|namespace|type)\b(?=\s*(?:[{_$a-zA-Z\xA0-\uFFFF]|$))/,
      // This is for `import type *, {}`
      /\btype\b(?=\s*(?:[\{*]|$))/
    ), delete n.languages.typescript.parameter, delete n.languages.typescript["literal-property"];
    var t = n.languages.extend("typescript", {});
    delete t["class-name"], n.languages.typescript["class-name"].inside = t, n.languages.insertBefore("typescript", "function", {
      decorator: {
        pattern: /@[$\w\xA0-\uFFFF]+/,
        inside: {
          at: {
            pattern: /^@/,
            alias: "operator"
          },
          function: /^[\s\S]+/
        }
      },
      "generic-function": {
        // e.g. foo<T extends "bar" | "baz">( ...
        pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*<(?:[^<>]|<(?:[^<>]|<[^<>]*>)*>)*>(?=\s*\()/,
        greedy: !0,
        inside: {
          function: /^#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*/,
          generic: {
            pattern: /<[\s\S]+/,
            // everything after the first <
            alias: "class-name",
            inside: t
          }
        }
      }
    }), n.languages.ts = n.languages.typescript;
  })(e);
}
const Ip = /* @__PURE__ */ he(yo), By = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Ip
}, Symbol.toStringTag, { value: "Module" }));
var Op = Ht;
Ht.displayName = "python";
Ht.aliases = ["py"];
function Ht(e) {
  e.languages.python = {
    comment: {
      pattern: /(^|[^\\])#.*/,
      lookbehind: !0,
      greedy: !0
    },
    "string-interpolation": {
      pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
      greedy: !0,
      inside: {
        interpolation: {
          // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
          pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
          lookbehind: !0,
          inside: {
            "format-spec": {
              pattern: /(:)[^:(){}]+(?=\}$)/,
              lookbehind: !0
            },
            "conversion-option": {
              pattern: /![sra](?=[:}]$)/,
              alias: "punctuation"
            },
            rest: null
          }
        },
        string: /[\s\S]+/
      }
    },
    "triple-quoted-string": {
      pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
      greedy: !0,
      alias: "string"
    },
    string: {
      pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
      greedy: !0
    },
    function: {
      pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
      lookbehind: !0
    },
    "class-name": {
      pattern: /(\bclass\s+)\w+/i,
      lookbehind: !0
    },
    decorator: {
      pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
      lookbehind: !0,
      alias: ["annotation", "punctuation"],
      inside: {
        punctuation: /\./
      }
    },
    keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
    builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
    boolean: /\b(?:False|None|True)\b/,
    number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
    operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
    punctuation: /[{}[\];(),.:]/
  }, e.languages.python["string-interpolation"].inside.interpolation.inside.rest = e.languages.python, e.languages.py = e.languages.python;
}
const Lp = /* @__PURE__ */ he(Op), Uy = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Lp
}, Symbol.toStringTag, { value: "Module" }));
var Rp = Vt;
Vt.displayName = "bash";
Vt.aliases = ["shell"];
function Vt(e) {
  (function(n) {
    var t = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", r = {
      pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
      lookbehind: !0,
      alias: "punctuation",
      // this looks reasonably well in all themes
      inside: null
      // see below
    }, i = {
      bash: r,
      environment: {
        pattern: RegExp("\\$" + t),
        alias: "constant"
      },
      variable: [
        // [0]: Arithmetic Environment
        {
          pattern: /\$?\(\([\s\S]+?\)\)/,
          greedy: !0,
          inside: {
            // If there is a $ sign at the beginning highlight $(( and )) as variable
            variable: [
              {
                pattern: /(^\$\(\([\s\S]+)\)\)/,
                lookbehind: !0
              },
              /^\$\(\(/
            ],
            number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
            // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
            operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
            // If there is no $ sign at the beginning highlight (( and )) as punctuation
            punctuation: /\(\(?|\)\)?|,|;/
          }
        },
        // [1]: Command Substitution
        {
          pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
          greedy: !0,
          inside: {
            variable: /^\$\(|^`|\)$|`$/
          }
        },
        // [2]: Brace expansion
        {
          pattern: /\$\{[^}]+\}/,
          greedy: !0,
          inside: {
            operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
            punctuation: /[\[\]]/,
            environment: {
              pattern: RegExp("(\\{)" + t),
              lookbehind: !0,
              alias: "constant"
            }
          }
        },
        /\$(?:\w+|[#?*!@$])/
      ],
      // Escape sequences from echo and printf's manuals, and escaped quotes.
      entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
    };
    n.languages.bash = {
      shebang: {
        pattern: /^#!\s*\/.*/,
        alias: "important"
      },
      comment: {
        pattern: /(^|[^"{\\$])#.*/,
        lookbehind: !0
      },
      "function-name": [
        // a) function foo {
        // b) foo() {
        // c) function foo() {
        // but not “foo {”
        {
          // a) and c)
          pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
          lookbehind: !0,
          alias: "function"
        },
        {
          // b)
          pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
          alias: "function"
        }
      ],
      // Highlight variable names as variables in for and select beginnings.
      "for-or-select": {
        pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
        alias: "variable",
        lookbehind: !0
      },
      // Highlight variable names as variables in the left-hand part
      // of assignments (“=” and “+=”).
      "assign-left": {
        pattern: /(^|[\s;|&]|[<>]\()\w+(?=\+?=)/,
        inside: {
          environment: {
            pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + t),
            lookbehind: !0,
            alias: "constant"
          }
        },
        alias: "variable",
        lookbehind: !0
      },
      string: [
        // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
        {
          pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
          lookbehind: !0,
          greedy: !0,
          inside: i
        },
        // Here-document with quotes around the tag
        // → No expansion (so no “inside”).
        {
          pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
          lookbehind: !0,
          greedy: !0,
          inside: {
            bash: r
          }
        },
        // “Normal” string
        {
          // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
          pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
          lookbehind: !0,
          greedy: !0,
          inside: i
        },
        {
          // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
          pattern: /(^|[^$\\])'[^']*'/,
          lookbehind: !0,
          greedy: !0
        },
        {
          // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
          pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
          greedy: !0,
          inside: {
            entity: i.entity
          }
        }
      ],
      environment: {
        pattern: RegExp("\\$?" + t),
        alias: "constant"
      },
      variable: i.variable,
      function: {
        pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
        lookbehind: !0
      },
      keyword: {
        pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
        lookbehind: !0
      },
      // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
      builtin: {
        pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
        lookbehind: !0,
        // Alias added to make those easier to distinguish from strings.
        alias: "class-name"
      },
      boolean: {
        pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
        lookbehind: !0
      },
      "file-descriptor": {
        pattern: /\B&\d\b/,
        alias: "important"
      },
      operator: {
        // Lots of redirections here, but not just that.
        pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
        inside: {
          "file-descriptor": {
            pattern: /^\d/,
            alias: "important"
          }
        }
      },
      punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
      number: {
        pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
        lookbehind: !0
      }
    }, r.inside = n.languages.bash;
    for (var l = [
      "comment",
      "function-name",
      "for-or-select",
      "assign-left",
      "string",
      "environment",
      "function",
      "keyword",
      "builtin",
      "boolean",
      "file-descriptor",
      "operator",
      "punctuation",
      "number"
    ], o = i.variable[1].inside, a = 0; a < l.length; a++)
      o[l[a]] = n.languages.bash[l[a]];
    n.languages.shell = n.languages.bash;
  })(e);
}
const Np = /* @__PURE__ */ he(Rp), Hy = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Np
}, Symbol.toStringTag, { value: "Module" }));
var _p = qt;
qt.displayName = "json";
qt.aliases = ["webmanifest"];
function qt(e) {
  e.languages.json = {
    property: {
      pattern: /(^|[^\\])"(?:\\.|[^\\"\r\n])*"(?=\s*:)/,
      lookbehind: !0,
      greedy: !0
    },
    string: {
      pattern: /(^|[^\\])"(?:\\.|[^\\"\r\n])*"(?!\s*:)/,
      lookbehind: !0,
      greedy: !0
    },
    comment: {
      pattern: /\/\/.*|\/\*[\s\S]*?(?:\*\/|$)/,
      greedy: !0
    },
    number: /-?\b\d+(?:\.\d+)?(?:e[+-]?\d+)?\b/i,
    punctuation: /[{}[\],]/,
    operator: /:/,
    boolean: /\b(?:false|true)\b/,
    null: {
      pattern: /\bnull\b/,
      alias: "keyword"
    }
  }, e.languages.webmanifest = e.languages.json;
}
const Fp = /* @__PURE__ */ he(_p), Vy = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Fp
}, Symbol.toStringTag, { value: "Module" })), qy = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: lp
}, Symbol.toStringTag, { value: "Module" }));
var ko = Gt;
Gt.displayName = "jsx";
Gt.aliases = [];
function Gt(e) {
  (function(n) {
    var t = n.util.clone(n.languages.javascript), r = /(?:\s|\/\/.*(?!.)|\/\*(?:[^*]|\*(?!\/))\*\/)/.source, i = /(?:\{(?:\{(?:\{[^{}]*\}|[^{}])*\}|[^{}])*\})/.source, l = /(?:\{<S>*\.{3}(?:[^{}]|<BRACES>)*\})/.source;
    function o(u, p) {
      return u = u.replace(/<S>/g, function() {
        return r;
      }).replace(/<BRACES>/g, function() {
        return i;
      }).replace(/<SPREAD>/g, function() {
        return l;
      }), RegExp(u, p);
    }
    l = o(l).source, n.languages.jsx = n.languages.extend("markup", t), n.languages.jsx.tag.pattern = o(
      /<\/?(?:[\w.:-]+(?:<S>+(?:[\w.:$-]+(?:=(?:"(?:\\[\s\S]|[^\\"])*"|'(?:\\[\s\S]|[^\\'])*'|[^\s{'"/>=]+|<BRACES>))?|<SPREAD>))*<S>*\/?)?>/.source
    ), n.languages.jsx.tag.inside.tag.pattern = /^<\/?[^\s>\/]*/, n.languages.jsx.tag.inside["attr-value"].pattern = /=(?!\{)(?:"(?:\\[\s\S]|[^\\"])*"|'(?:\\[\s\S]|[^\\'])*'|[^\s'">]+)/, n.languages.jsx.tag.inside.tag.inside["class-name"] = /^[A-Z]\w*(?:\.[A-Z]\w*)*$/, n.languages.jsx.tag.inside.comment = t.comment, n.languages.insertBefore(
      "inside",
      "attr-name",
      {
        spread: {
          pattern: o(/<SPREAD>/.source),
          inside: n.languages.jsx
        }
      },
      n.languages.jsx.tag
    ), n.languages.insertBefore(
      "inside",
      "special-attr",
      {
        script: {
          // Allow for two levels of nesting
          pattern: o(/=<BRACES>/.source),
          alias: "language-javascript",
          inside: {
            "script-punctuation": {
              pattern: /^=(?=\{)/,
              alias: "punctuation"
            },
            rest: n.languages.jsx
          }
        }
      },
      n.languages.jsx.tag
    );
    var a = function(u) {
      return u ? typeof u == "string" ? u : typeof u.content == "string" ? u.content : u.content.map(a).join("") : "";
    }, s = function(u) {
      for (var p = [], c = 0; c < u.length; c++) {
        var h = u[c], f = !1;
        if (typeof h != "string" && (h.type === "tag" && h.content[0] && h.content[0].type === "tag" ? h.content[0].content[0].content === "</" ? p.length > 0 && p[p.length - 1].tagName === a(h.content[0].content[1]) && p.pop() : h.content[h.content.length - 1].content === "/>" || p.push({
          tagName: a(h.content[0].content[1]),
          openedBraces: 0
        }) : p.length > 0 && h.type === "punctuation" && h.content === "{" ? p[p.length - 1].openedBraces++ : p.length > 0 && p[p.length - 1].openedBraces > 0 && h.type === "punctuation" && h.content === "}" ? p[p.length - 1].openedBraces-- : f = !0), (f || typeof h == "string") && p.length > 0 && p[p.length - 1].openedBraces === 0) {
          var g = a(h);
          c < u.length - 1 && (typeof u[c + 1] == "string" || u[c + 1].type === "plain-text") && (g += a(u[c + 1]), u.splice(c + 1, 1)), c > 0 && (typeof u[c - 1] == "string" || u[c - 1].type === "plain-text") && (g = a(u[c - 1]) + g, u.splice(c - 1, 1), c--), u[c] = new n.Token(
            "plain-text",
            g,
            null,
            g
          );
        }
        h.content && typeof h.content != "string" && s(h.content);
      }
    };
    n.hooks.add("after-tokenize", function(u) {
      u.language !== "jsx" && u.language !== "tsx" || s(u.tokens);
    });
  })(e);
}
const Dp = /* @__PURE__ */ he(ko), Gy = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Dp
}, Symbol.toStringTag, { value: "Module" }));
var Pp = ko, zp = yo, Mp = Wt;
Wt.displayName = "tsx";
Wt.aliases = [];
function Wt(e) {
  e.register(Pp), e.register(zp), function(n) {
    var t = n.util.clone(n.languages.typescript);
    n.languages.tsx = n.languages.extend("jsx", t), delete n.languages.tsx.parameter, delete n.languages.tsx["literal-property"];
    var r = n.languages.tsx.tag;
    r.pattern = RegExp(
      /(^|[^\w$]|(?=<\/))/.source + "(?:" + r.pattern.source + ")",
      r.pattern.flags
    ), r.lookbehind = !0;
  }(e);
}
const $p = /* @__PURE__ */ he(Mp), Wy = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $p
}, Symbol.toStringTag, { value: "Module" }));
var jp = Yt;
Yt.displayName = "sql";
Yt.aliases = [];
function Yt(e) {
  e.languages.sql = {
    comment: {
      pattern: /(^|[^\\])(?:\/\*[\s\S]*?\*\/|(?:--|\/\/|#).*)/,
      lookbehind: !0
    },
    variable: [
      {
        pattern: /@(["'`])(?:\\[\s\S]|(?!\1)[^\\])+\1/,
        greedy: !0
      },
      /@[\w.$]+/
    ],
    string: {
      pattern: /(^|[^@\\])("|')(?:\\[\s\S]|(?!\2)[^\\]|\2\2)*\2/,
      greedy: !0,
      lookbehind: !0
    },
    identifier: {
      pattern: /(^|[^@\\])`(?:\\[\s\S]|[^`\\]|``)*`/,
      greedy: !0,
      lookbehind: !0,
      inside: {
        punctuation: /^`|`$/
      }
    },
    function: /\b(?:AVG|COUNT|FIRST|FORMAT|LAST|LCASE|LEN|MAX|MID|MIN|MOD|NOW|ROUND|SUM|UCASE)(?=\s*\()/i,
    // Should we highlight user defined functions too?
    keyword: /\b(?:ACTION|ADD|AFTER|ALGORITHM|ALL|ALTER|ANALYZE|ANY|APPLY|AS|ASC|AUTHORIZATION|AUTO_INCREMENT|BACKUP|BDB|BEGIN|BERKELEYDB|BIGINT|BINARY|BIT|BLOB|BOOL|BOOLEAN|BREAK|BROWSE|BTREE|BULK|BY|CALL|CASCADED?|CASE|CHAIN|CHAR(?:ACTER|SET)?|CHECK(?:POINT)?|CLOSE|CLUSTERED|COALESCE|COLLATE|COLUMNS?|COMMENT|COMMIT(?:TED)?|COMPUTE|CONNECT|CONSISTENT|CONSTRAINT|CONTAINS(?:TABLE)?|CONTINUE|CONVERT|CREATE|CROSS|CURRENT(?:_DATE|_TIME|_TIMESTAMP|_USER)?|CURSOR|CYCLE|DATA(?:BASES?)?|DATE(?:TIME)?|DAY|DBCC|DEALLOCATE|DEC|DECIMAL|DECLARE|DEFAULT|DEFINER|DELAYED|DELETE|DELIMITERS?|DENY|DESC|DESCRIBE|DETERMINISTIC|DISABLE|DISCARD|DISK|DISTINCT|DISTINCTROW|DISTRIBUTED|DO|DOUBLE|DROP|DUMMY|DUMP(?:FILE)?|DUPLICATE|ELSE(?:IF)?|ENABLE|ENCLOSED|END|ENGINE|ENUM|ERRLVL|ERRORS|ESCAPED?|EXCEPT|EXEC(?:UTE)?|EXISTS|EXIT|EXPLAIN|EXTENDED|FETCH|FIELDS|FILE|FILLFACTOR|FIRST|FIXED|FLOAT|FOLLOWING|FOR(?: EACH ROW)?|FORCE|FOREIGN|FREETEXT(?:TABLE)?|FROM|FULL|FUNCTION|GEOMETRY(?:COLLECTION)?|GLOBAL|GOTO|GRANT|GROUP|HANDLER|HASH|HAVING|HOLDLOCK|HOUR|IDENTITY(?:COL|_INSERT)?|IF|IGNORE|IMPORT|INDEX|INFILE|INNER|INNODB|INOUT|INSERT|INT|INTEGER|INTERSECT|INTERVAL|INTO|INVOKER|ISOLATION|ITERATE|JOIN|KEYS?|KILL|LANGUAGE|LAST|LEAVE|LEFT|LEVEL|LIMIT|LINENO|LINES|LINESTRING|LOAD|LOCAL|LOCK|LONG(?:BLOB|TEXT)|LOOP|MATCH(?:ED)?|MEDIUM(?:BLOB|INT|TEXT)|MERGE|MIDDLEINT|MINUTE|MODE|MODIFIES|MODIFY|MONTH|MULTI(?:LINESTRING|POINT|POLYGON)|NATIONAL|NATURAL|NCHAR|NEXT|NO|NONCLUSTERED|NULLIF|NUMERIC|OFF?|OFFSETS?|ON|OPEN(?:DATASOURCE|QUERY|ROWSET)?|OPTIMIZE|OPTION(?:ALLY)?|ORDER|OUT(?:ER|FILE)?|OVER|PARTIAL|PARTITION|PERCENT|PIVOT|PLAN|POINT|POLYGON|PRECEDING|PRECISION|PREPARE|PREV|PRIMARY|PRINT|PRIVILEGES|PROC(?:EDURE)?|PUBLIC|PURGE|QUICK|RAISERROR|READS?|REAL|RECONFIGURE|REFERENCES|RELEASE|RENAME|REPEAT(?:ABLE)?|REPLACE|REPLICATION|REQUIRE|RESIGNAL|RESTORE|RESTRICT|RETURN(?:ING|S)?|REVOKE|RIGHT|ROLLBACK|ROUTINE|ROW(?:COUNT|GUIDCOL|S)?|RTREE|RULE|SAVE(?:POINT)?|SCHEMA|SECOND|SELECT|SERIAL(?:IZABLE)?|SESSION(?:_USER)?|SET(?:USER)?|SHARE|SHOW|SHUTDOWN|SIMPLE|SMALLINT|SNAPSHOT|SOME|SONAME|SQL|START(?:ING)?|STATISTICS|STATUS|STRIPED|SYSTEM_USER|TABLES?|TABLESPACE|TEMP(?:ORARY|TABLE)?|TERMINATED|TEXT(?:SIZE)?|THEN|TIME(?:STAMP)?|TINY(?:BLOB|INT|TEXT)|TOP?|TRAN(?:SACTIONS?)?|TRIGGER|TRUNCATE|TSEQUAL|TYPES?|UNBOUNDED|UNCOMMITTED|UNDEFINED|UNION|UNIQUE|UNLOCK|UNPIVOT|UNSIGNED|UPDATE(?:TEXT)?|USAGE|USE|USER|USING|VALUES?|VAR(?:BINARY|CHAR|CHARACTER|YING)|VIEW|WAITFOR|WARNINGS|WHEN|WHERE|WHILE|WITH(?: ROLLUP|IN)?|WORK|WRITE(?:TEXT)?|YEAR)\b/i,
    boolean: /\b(?:FALSE|NULL|TRUE)\b/i,
    number: /\b0x[\da-f]+\b|\b\d+(?:\.\d*)?|\B\.\d+\b/i,
    operator: /[-+*\/=%^~]|&&?|\|\|?|!=?|<(?:=>?|<|>)?|>[>=]?|\b(?:AND|BETWEEN|DIV|ILIKE|IN|IS|LIKE|NOT|OR|REGEXP|RLIKE|SOUNDS LIKE|XOR)\b/i,
    punctuation: /[;[\]()`,.]/
  };
}
const Bp = /* @__PURE__ */ he(jp), Yy = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Bp
}, Symbol.toStringTag, { value: "Module" }));
var Up = Xt;
Xt.displayName = "yaml";
Xt.aliases = ["yml"];
function Xt(e) {
  (function(n) {
    var t = /[*&][^\s[\]{},]+/, r = /!(?:<[\w\-%#;/?:@&=+$,.!~*'()[\]]+>|(?:[a-zA-Z\d-]*!)?[\w\-%#;/?:@&=+$.~*'()]+)?/, i = "(?:" + r.source + "(?:[ 	]+" + t.source + ")?|" + t.source + "(?:[ 	]+" + r.source + ")?)", l = /(?:[^\s\x00-\x08\x0e-\x1f!"#%&'*,\-:>?@[\]`{|}\x7f-\x84\x86-\x9f\ud800-\udfff\ufffe\uffff]|[?:-]<PLAIN>)(?:[ \t]*(?:(?![#:])<PLAIN>|:<PLAIN>))*/.source.replace(
      /<PLAIN>/g,
      function() {
        return /[^\s\x00-\x08\x0e-\x1f,[\]{}\x7f-\x84\x86-\x9f\ud800-\udfff\ufffe\uffff]/.source;
      }
    ), o = /"(?:[^"\\\r\n]|\\.)*"|'(?:[^'\\\r\n]|\\.)*'/.source;
    function a(s, u) {
      u = (u || "").replace(/m/g, "") + "m";
      var p = /([:\-,[{]\s*(?:\s<<prop>>[ \t]+)?)(?:<<value>>)(?=[ \t]*(?:$|,|\]|\}|(?:[\r\n]\s*)?#))/.source.replace(/<<prop>>/g, function() {
        return i;
      }).replace(/<<value>>/g, function() {
        return s;
      });
      return RegExp(p, u);
    }
    n.languages.yaml = {
      scalar: {
        pattern: RegExp(
          /([\-:]\s*(?:\s<<prop>>[ \t]+)?[|>])[ \t]*(?:((?:\r?\n|\r)[ \t]+)\S[^\r\n]*(?:\2[^\r\n]+)*)/.source.replace(
            /<<prop>>/g,
            function() {
              return i;
            }
          )
        ),
        lookbehind: !0,
        alias: "string"
      },
      comment: /#.*/,
      key: {
        pattern: RegExp(
          /((?:^|[:\-,[{\r\n?])[ \t]*(?:<<prop>>[ \t]+)?)<<key>>(?=\s*:\s)/.source.replace(/<<prop>>/g, function() {
            return i;
          }).replace(/<<key>>/g, function() {
            return "(?:" + l + "|" + o + ")";
          })
        ),
        lookbehind: !0,
        greedy: !0,
        alias: "atrule"
      },
      directive: {
        pattern: /(^[ \t]*)%.+/m,
        lookbehind: !0,
        alias: "important"
      },
      datetime: {
        pattern: a(
          /\d{4}-\d\d?-\d\d?(?:[tT]|[ \t]+)\d\d?:\d{2}:\d{2}(?:\.\d*)?(?:[ \t]*(?:Z|[-+]\d\d?(?::\d{2})?))?|\d{4}-\d{2}-\d{2}|\d\d?:\d{2}(?::\d{2}(?:\.\d*)?)?/.source
        ),
        lookbehind: !0,
        alias: "number"
      },
      boolean: {
        pattern: a(/false|true/.source, "i"),
        lookbehind: !0,
        alias: "important"
      },
      null: {
        pattern: a(/null|~/.source, "i"),
        lookbehind: !0,
        alias: "important"
      },
      string: {
        pattern: a(o),
        lookbehind: !0,
        greedy: !0
      },
      number: {
        pattern: a(
          /[+-]?(?:0x[\da-f]+|0o[0-7]+|(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?|\.inf|\.nan)/.source,
          "i"
        ),
        lookbehind: !0
      },
      tag: r,
      important: t,
      punctuation: /---|[:[\]{}\-,|>?]|\.\.\./
    }, n.languages.yml = n.languages.yaml;
  })(e);
}
const Hp = /* @__PURE__ */ he(Up), Xy = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Hp
}, Symbol.toStringTag, { value: "Module" }));
var Vp = Kt;
Kt.displayName = "markdown";
Kt.aliases = ["md"];
function Kt(e) {
  (function(n) {
    var t = /(?:\\.|[^\\\n\r]|(?:\n|\r\n?)(?![\r\n]))/.source;
    function r(c) {
      return c = c.replace(/<inner>/g, function() {
        return t;
      }), RegExp(/((?:^|[^\\])(?:\\{2})*)/.source + "(?:" + c + ")");
    }
    var i = /(?:\\.|``(?:[^`\r\n]|`(?!`))+``|`[^`\r\n]+`|[^\\|\r\n`])+/.source, l = /\|?__(?:\|__)+\|?(?:(?:\n|\r\n?)|(?![\s\S]))/.source.replace(
      /__/g,
      function() {
        return i;
      }
    ), o = /\|?[ \t]*:?-{3,}:?[ \t]*(?:\|[ \t]*:?-{3,}:?[ \t]*)+\|?(?:\n|\r\n?)/.source;
    n.languages.markdown = n.languages.extend("markup", {}), n.languages.insertBefore("markdown", "prolog", {
      "front-matter-block": {
        pattern: /(^(?:\s*[\r\n])?)---(?!.)[\s\S]*?[\r\n]---(?!.)/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          punctuation: /^---|---$/,
          "front-matter": {
            pattern: /\S+(?:\s+\S+)*/,
            alias: ["yaml", "language-yaml"],
            inside: n.languages.yaml
          }
        }
      },
      blockquote: {
        // > ...
        pattern: /^>(?:[\t ]*>)*/m,
        alias: "punctuation"
      },
      table: {
        pattern: RegExp(
          "^" + l + o + "(?:" + l + ")*",
          "m"
        ),
        inside: {
          "table-data-rows": {
            pattern: RegExp(
              "^(" + l + o + ")(?:" + l + ")*$"
            ),
            lookbehind: !0,
            inside: {
              "table-data": {
                pattern: RegExp(i),
                inside: n.languages.markdown
              },
              punctuation: /\|/
            }
          },
          "table-line": {
            pattern: RegExp("^(" + l + ")" + o + "$"),
            lookbehind: !0,
            inside: {
              punctuation: /\||:?-{3,}:?/
            }
          },
          "table-header-row": {
            pattern: RegExp("^" + l + "$"),
            inside: {
              "table-header": {
                pattern: RegExp(i),
                alias: "important",
                inside: n.languages.markdown
              },
              punctuation: /\|/
            }
          }
        }
      },
      code: [
        {
          // Prefixed by 4 spaces or 1 tab and preceded by an empty line
          pattern: /((?:^|\n)[ \t]*\n|(?:^|\r\n?)[ \t]*\r\n?)(?: {4}|\t).+(?:(?:\n|\r\n?)(?: {4}|\t).+)*/,
          lookbehind: !0,
          alias: "keyword"
        },
        {
          // ```optional language
          // code block
          // ```
          pattern: /^```[\s\S]*?^```$/m,
          greedy: !0,
          inside: {
            "code-block": {
              pattern: /^(```.*(?:\n|\r\n?))[\s\S]+?(?=(?:\n|\r\n?)^```$)/m,
              lookbehind: !0
            },
            "code-language": {
              pattern: /^(```).+/,
              lookbehind: !0
            },
            punctuation: /```/
          }
        }
      ],
      title: [
        {
          // title 1
          // =======
          // title 2
          // -------
          pattern: /\S.*(?:\n|\r\n?)(?:==+|--+)(?=[ \t]*$)/m,
          alias: "important",
          inside: {
            punctuation: /==+$|--+$/
          }
        },
        {
          // # title 1
          // ###### title 6
          pattern: /(^\s*)#.+/m,
          lookbehind: !0,
          alias: "important",
          inside: {
            punctuation: /^#+|#+$/
          }
        }
      ],
      hr: {
        // ***
        // ---
        // * * *
        // -----------
        pattern: /(^\s*)([*-])(?:[\t ]*\2){2,}(?=\s*$)/m,
        lookbehind: !0,
        alias: "punctuation"
      },
      list: {
        // * item
        // + item
        // - item
        // 1. item
        pattern: /(^\s*)(?:[*+-]|\d+\.)(?=[\t ].)/m,
        lookbehind: !0,
        alias: "punctuation"
      },
      "url-reference": {
        // [id]: http://example.com "Optional title"
        // [id]: http://example.com 'Optional title'
        // [id]: http://example.com (Optional title)
        // [id]: <http://example.com> "Optional title"
        pattern: /!?\[[^\]]+\]:[\t ]+(?:\S+|<(?:\\.|[^>\\])+>)(?:[\t ]+(?:"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\((?:\\.|[^)\\])*\)))?/,
        inside: {
          variable: {
            pattern: /^(!?\[)[^\]]+/,
            lookbehind: !0
          },
          string: /(?:"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\((?:\\.|[^)\\])*\))$/,
          punctuation: /^[\[\]!:]|[<>]/
        },
        alias: "url"
      },
      bold: {
        // **strong**
        // __strong__
        // allow one nested instance of italic text using the same delimiter
        pattern: r(
          /\b__(?:(?!_)<inner>|_(?:(?!_)<inner>)+_)+__\b|\*\*(?:(?!\*)<inner>|\*(?:(?!\*)<inner>)+\*)+\*\*/.source
        ),
        lookbehind: !0,
        greedy: !0,
        inside: {
          content: {
            pattern: /(^..)[\s\S]+(?=..$)/,
            lookbehind: !0,
            inside: {}
            // see below
          },
          punctuation: /\*\*|__/
        }
      },
      italic: {
        // *em*
        // _em_
        // allow one nested instance of bold text using the same delimiter
        pattern: r(
          /\b_(?:(?!_)<inner>|__(?:(?!_)<inner>)+__)+_\b|\*(?:(?!\*)<inner>|\*\*(?:(?!\*)<inner>)+\*\*)+\*/.source
        ),
        lookbehind: !0,
        greedy: !0,
        inside: {
          content: {
            pattern: /(^.)[\s\S]+(?=.$)/,
            lookbehind: !0,
            inside: {}
            // see below
          },
          punctuation: /[*_]/
        }
      },
      strike: {
        // ~~strike through~~
        // ~strike~
        // eslint-disable-next-line regexp/strict
        pattern: r(/(~~?)(?:(?!~)<inner>)+\2/.source),
        lookbehind: !0,
        greedy: !0,
        inside: {
          content: {
            pattern: /(^~~?)[\s\S]+(?=\1$)/,
            lookbehind: !0,
            inside: {}
            // see below
          },
          punctuation: /~~?/
        }
      },
      "code-snippet": {
        // `code`
        // ``code``
        pattern: /(^|[^\\`])(?:``[^`\r\n]+(?:`[^`\r\n]+)*``(?!`)|`[^`\r\n]+`(?!`))/,
        lookbehind: !0,
        greedy: !0,
        alias: ["code", "keyword"]
      },
      url: {
        // [example](http://example.com "Optional title")
        // [example][id]
        // [example] [id]
        pattern: r(
          /!?\[(?:(?!\])<inner>)+\](?:\([^\s)]+(?:[\t ]+"(?:\\.|[^"\\])*")?\)|[ \t]?\[(?:(?!\])<inner>)+\])/.source
        ),
        lookbehind: !0,
        greedy: !0,
        inside: {
          operator: /^!/,
          content: {
            pattern: /(^\[)[^\]]+(?=\])/,
            lookbehind: !0,
            inside: {}
            // see below
          },
          variable: {
            pattern: /(^\][ \t]?\[)[^\]]+(?=\]$)/,
            lookbehind: !0
          },
          url: {
            pattern: /(^\]\()[^\s)]+/,
            lookbehind: !0
          },
          string: {
            pattern: /(^[ \t]+)"(?:\\.|[^"\\])*"(?=\)$)/,
            lookbehind: !0
          }
        }
      }
    }), ["url", "bold", "italic", "strike"].forEach(function(c) {
      ["url", "bold", "italic", "strike", "code-snippet"].forEach(function(h) {
        c !== h && (n.languages.markdown[c].inside.content.inside[h] = n.languages.markdown[h]);
      });
    }), n.hooks.add("after-tokenize", function(c) {
      if (c.language !== "markdown" && c.language !== "md")
        return;
      function h(f) {
        if (!(!f || typeof f == "string"))
          for (var g = 0, v = f.length; g < v; g++) {
            var A = f[g];
            if (A.type !== "code") {
              h(A.content);
              continue;
            }
            var w = A.content[1], k = A.content[3];
            if (w && k && w.type === "code-language" && k.type === "code-block" && typeof w.content == "string") {
              var y = w.content.replace(/\b#/g, "sharp").replace(/\b\+\+/g, "pp");
              y = (/[a-z][\w-]*/i.exec(y) || [""])[0].toLowerCase();
              var E = "language-" + y;
              k.alias ? typeof k.alias == "string" ? k.alias = [k.alias, E] : k.alias.push(E) : k.alias = [E];
            }
          }
      }
      h(c.tokens);
    }), n.hooks.add("wrap", function(c) {
      if (c.type === "code-block") {
        for (var h = "", f = 0, g = c.classes.length; f < g; f++) {
          var v = c.classes[f], A = /language-(.+)/.exec(v);
          if (A) {
            h = A[1];
            break;
          }
        }
        var w = n.languages[h];
        if (w)
          c.content = n.highlight(
            p(c.content.value),
            w,
            h
          );
        else if (h && h !== "none" && n.plugins.autoloader) {
          var k = "md-" + (/* @__PURE__ */ new Date()).valueOf() + "-" + Math.floor(Math.random() * 1e16);
          c.attributes.id = k, n.plugins.autoloader.loadLanguages(h, function() {
            var y = document.getElementById(k);
            y && (y.innerHTML = n.highlight(
              y.textContent,
              n.languages[h],
              h
            ));
          });
        }
      }
    });
    var a = RegExp(n.languages.markup.tag.pattern.source, "gi"), s = {
      amp: "&",
      lt: "<",
      gt: ">",
      quot: '"'
    }, u = String.fromCodePoint || String.fromCharCode;
    function p(c) {
      var h = c.replace(a, "");
      return h = h.replace(/&(\w{1,8}|#x?[\da-f]{1,8});/gi, function(f, g) {
        if (g = g.toLowerCase(), g[0] === "#") {
          var v;
          return g[1] === "x" ? v = parseInt(g.slice(2), 16) : v = Number(g.slice(1)), u(v);
        } else {
          var A = s[g];
          return A || f;
        }
      }), h;
    }
    n.languages.md = n.languages.markdown;
  })(e);
}
const qp = /* @__PURE__ */ he(Vp), Ky = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: qp
}, Symbol.toStringTag, { value: "Module" }));
function Zy() {
}
function Qy(e) {
  const n = [], t = String(e || "");
  let r = t.indexOf(","), i = 0, l = !1;
  for (; !l; ) {
    r === -1 && (r = t.length, l = !0);
    const o = t.slice(i, r).trim();
    (o || !l) && n.push(o), i = r + 1, r = t.indexOf(",", i);
  }
  return n;
}
function Gp(e, n) {
  const t = {};
  return (e[e.length - 1] === "" ? [...e, ""] : e).join(
    (t.padRight ? " " : "") + "," + (t.padLeft === !1 ? "" : " ")
  ).trim();
}
const Wp = /^[$_\p{ID_Start}][$_\u{200C}\u{200D}\p{ID_Continue}]*$/u, Yp = /^[$_\p{ID_Start}][-$_\u{200C}\u{200D}\p{ID_Continue}]*$/u, Xp = {};
function Hr(e, n) {
  return (Xp.jsx ? Yp : Wp).test(e);
}
const Kp = /[ \t\n\f\r]/g;
function Zp(e) {
  return typeof e == "object" ? e.type === "text" ? Vr(e.value) : !1 : Vr(e);
}
function Vr(e) {
  return e.replace(Kp, "") === "";
}
class xn {
  /**
   * @param {SchemaType['property']} property
   *   Property.
   * @param {SchemaType['normal']} normal
   *   Normal.
   * @param {Space | undefined} [space]
   *   Space.
   * @returns
   *   Schema.
   */
  constructor(n, t, r) {
    this.normal = t, this.property = n, r && (this.space = r);
  }
}
xn.prototype.normal = {};
xn.prototype.property = {};
xn.prototype.space = void 0;
function xo(e, n) {
  const t = {}, r = {};
  for (const i of e)
    Object.assign(t, i.property), Object.assign(r, i.normal);
  return new xn(t, r, n);
}
function ht(e) {
  return e.toLowerCase();
}
class de {
  /**
   * @param {string} property
   *   Property.
   * @param {string} attribute
   *   Attribute.
   * @returns
   *   Info.
   */
  constructor(n, t) {
    this.attribute = t, this.property = n;
  }
}
de.prototype.attribute = "";
de.prototype.booleanish = !1;
de.prototype.boolean = !1;
de.prototype.commaOrSpaceSeparated = !1;
de.prototype.commaSeparated = !1;
de.prototype.defined = !1;
de.prototype.mustUseProperty = !1;
de.prototype.number = !1;
de.prototype.overloadedBoolean = !1;
de.prototype.property = "";
de.prototype.spaceSeparated = !1;
de.prototype.space = void 0;
let Qp = 0;
const $ = Ve(), te = Ve(), dt = Ve(), O = Ve(), J = Ve(), Ze = Ve(), me = Ve();
function Ve() {
  return 2 ** ++Qp;
}
const gt = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  boolean: $,
  booleanish: te,
  commaOrSpaceSeparated: me,
  commaSeparated: Ze,
  number: O,
  overloadedBoolean: dt,
  spaceSeparated: J
}, Symbol.toStringTag, { value: "Module" })), Wn = (
  /** @type {ReadonlyArray<keyof typeof types>} */
  Object.keys(gt)
);
class Zt extends de {
  /**
   * @constructor
   * @param {string} property
   *   Property.
   * @param {string} attribute
   *   Attribute.
   * @param {number | null | undefined} [mask]
   *   Mask.
   * @param {Space | undefined} [space]
   *   Space.
   * @returns
   *   Info.
   */
  constructor(n, t, r, i) {
    let l = -1;
    if (super(n, t), qr(this, "space", i), typeof r == "number")
      for (; ++l < Wn.length; ) {
        const o = Wn[l];
        qr(this, Wn[l], (r & gt[o]) === gt[o]);
      }
  }
}
Zt.prototype.defined = !0;
function qr(e, n, t) {
  t && (e[n] = t);
}
function en(e) {
  const n = {}, t = {};
  for (const [r, i] of Object.entries(e.properties)) {
    const l = new Zt(
      r,
      e.transform(e.attributes || {}, r),
      i,
      e.space
    );
    e.mustUseProperty && e.mustUseProperty.includes(r) && (l.mustUseProperty = !0), n[r] = l, t[ht(r)] = r, t[ht(l.attribute)] = r;
  }
  return new xn(n, t, e.space);
}
const wo = en({
  properties: {
    ariaActiveDescendant: null,
    ariaAtomic: te,
    ariaAutoComplete: null,
    ariaBusy: te,
    ariaChecked: te,
    ariaColCount: O,
    ariaColIndex: O,
    ariaColSpan: O,
    ariaControls: J,
    ariaCurrent: null,
    ariaDescribedBy: J,
    ariaDetails: null,
    ariaDisabled: te,
    ariaDropEffect: J,
    ariaErrorMessage: null,
    ariaExpanded: te,
    ariaFlowTo: J,
    ariaGrabbed: te,
    ariaHasPopup: null,
    ariaHidden: te,
    ariaInvalid: null,
    ariaKeyShortcuts: null,
    ariaLabel: null,
    ariaLabelledBy: J,
    ariaLevel: O,
    ariaLive: null,
    ariaModal: te,
    ariaMultiLine: te,
    ariaMultiSelectable: te,
    ariaOrientation: null,
    ariaOwns: J,
    ariaPlaceholder: null,
    ariaPosInSet: O,
    ariaPressed: te,
    ariaReadOnly: te,
    ariaRelevant: null,
    ariaRequired: te,
    ariaRoleDescription: J,
    ariaRowCount: O,
    ariaRowIndex: O,
    ariaRowSpan: O,
    ariaSelected: te,
    ariaSetSize: O,
    ariaSort: null,
    ariaValueMax: O,
    ariaValueMin: O,
    ariaValueNow: O,
    ariaValueText: null,
    role: null
  },
  transform(e, n) {
    return n === "role" ? n : "aria-" + n.slice(4).toLowerCase();
  }
});
function vo(e, n) {
  return n in e ? e[n] : n;
}
function So(e, n) {
  return vo(e, n.toLowerCase());
}
const Jp = en({
  attributes: {
    acceptcharset: "accept-charset",
    classname: "class",
    htmlfor: "for",
    httpequiv: "http-equiv"
  },
  mustUseProperty: ["checked", "multiple", "muted", "selected"],
  properties: {
    // Standard Properties.
    abbr: null,
    accept: Ze,
    acceptCharset: J,
    accessKey: J,
    action: null,
    allow: null,
    allowFullScreen: $,
    allowPaymentRequest: $,
    allowUserMedia: $,
    alt: null,
    as: null,
    async: $,
    autoCapitalize: null,
    autoComplete: J,
    autoFocus: $,
    autoPlay: $,
    blocking: J,
    capture: null,
    charSet: null,
    checked: $,
    cite: null,
    className: J,
    cols: O,
    colSpan: null,
    content: null,
    contentEditable: te,
    controls: $,
    controlsList: J,
    coords: O | Ze,
    crossOrigin: null,
    data: null,
    dateTime: null,
    decoding: null,
    default: $,
    defer: $,
    dir: null,
    dirName: null,
    disabled: $,
    download: dt,
    draggable: te,
    encType: null,
    enterKeyHint: null,
    fetchPriority: null,
    form: null,
    formAction: null,
    formEncType: null,
    formMethod: null,
    formNoValidate: $,
    formTarget: null,
    headers: J,
    height: O,
    hidden: dt,
    high: O,
    href: null,
    hrefLang: null,
    htmlFor: J,
    httpEquiv: J,
    id: null,
    imageSizes: null,
    imageSrcSet: null,
    inert: $,
    inputMode: null,
    integrity: null,
    is: null,
    isMap: $,
    itemId: null,
    itemProp: J,
    itemRef: J,
    itemScope: $,
    itemType: J,
    kind: null,
    label: null,
    lang: null,
    language: null,
    list: null,
    loading: null,
    loop: $,
    low: O,
    manifest: null,
    max: null,
    maxLength: O,
    media: null,
    method: null,
    min: null,
    minLength: O,
    multiple: $,
    muted: $,
    name: null,
    nonce: null,
    noModule: $,
    noValidate: $,
    onAbort: null,
    onAfterPrint: null,
    onAuxClick: null,
    onBeforeMatch: null,
    onBeforePrint: null,
    onBeforeToggle: null,
    onBeforeUnload: null,
    onBlur: null,
    onCancel: null,
    onCanPlay: null,
    onCanPlayThrough: null,
    onChange: null,
    onClick: null,
    onClose: null,
    onContextLost: null,
    onContextMenu: null,
    onContextRestored: null,
    onCopy: null,
    onCueChange: null,
    onCut: null,
    onDblClick: null,
    onDrag: null,
    onDragEnd: null,
    onDragEnter: null,
    onDragExit: null,
    onDragLeave: null,
    onDragOver: null,
    onDragStart: null,
    onDrop: null,
    onDurationChange: null,
    onEmptied: null,
    onEnded: null,
    onError: null,
    onFocus: null,
    onFormData: null,
    onHashChange: null,
    onInput: null,
    onInvalid: null,
    onKeyDown: null,
    onKeyPress: null,
    onKeyUp: null,
    onLanguageChange: null,
    onLoad: null,
    onLoadedData: null,
    onLoadedMetadata: null,
    onLoadEnd: null,
    onLoadStart: null,
    onMessage: null,
    onMessageError: null,
    onMouseDown: null,
    onMouseEnter: null,
    onMouseLeave: null,
    onMouseMove: null,
    onMouseOut: null,
    onMouseOver: null,
    onMouseUp: null,
    onOffline: null,
    onOnline: null,
    onPageHide: null,
    onPageShow: null,
    onPaste: null,
    onPause: null,
    onPlay: null,
    onPlaying: null,
    onPopState: null,
    onProgress: null,
    onRateChange: null,
    onRejectionHandled: null,
    onReset: null,
    onResize: null,
    onScroll: null,
    onScrollEnd: null,
    onSecurityPolicyViolation: null,
    onSeeked: null,
    onSeeking: null,
    onSelect: null,
    onSlotChange: null,
    onStalled: null,
    onStorage: null,
    onSubmit: null,
    onSuspend: null,
    onTimeUpdate: null,
    onToggle: null,
    onUnhandledRejection: null,
    onUnload: null,
    onVolumeChange: null,
    onWaiting: null,
    onWheel: null,
    open: $,
    optimum: O,
    pattern: null,
    ping: J,
    placeholder: null,
    playsInline: $,
    popover: null,
    popoverTarget: null,
    popoverTargetAction: null,
    poster: null,
    preload: null,
    readOnly: $,
    referrerPolicy: null,
    rel: J,
    required: $,
    reversed: $,
    rows: O,
    rowSpan: O,
    sandbox: J,
    scope: null,
    scoped: $,
    seamless: $,
    selected: $,
    shadowRootClonable: $,
    shadowRootDelegatesFocus: $,
    shadowRootMode: null,
    shape: null,
    size: O,
    sizes: null,
    slot: null,
    span: O,
    spellCheck: te,
    src: null,
    srcDoc: null,
    srcLang: null,
    srcSet: null,
    start: O,
    step: null,
    style: null,
    tabIndex: O,
    target: null,
    title: null,
    translate: null,
    type: null,
    typeMustMatch: $,
    useMap: null,
    value: te,
    width: O,
    wrap: null,
    writingSuggestions: null,
    // Legacy.
    // See: https://html.spec.whatwg.org/#other-elements,-attributes-and-apis
    align: null,
    // Several. Use CSS `text-align` instead,
    aLink: null,
    // `<body>`. Use CSS `a:active {color}` instead
    archive: J,
    // `<object>`. List of URIs to archives
    axis: null,
    // `<td>` and `<th>`. Use `scope` on `<th>`
    background: null,
    // `<body>`. Use CSS `background-image` instead
    bgColor: null,
    // `<body>` and table elements. Use CSS `background-color` instead
    border: O,
    // `<table>`. Use CSS `border-width` instead,
    borderColor: null,
    // `<table>`. Use CSS `border-color` instead,
    bottomMargin: O,
    // `<body>`
    cellPadding: null,
    // `<table>`
    cellSpacing: null,
    // `<table>`
    char: null,
    // Several table elements. When `align=char`, sets the character to align on
    charOff: null,
    // Several table elements. When `char`, offsets the alignment
    classId: null,
    // `<object>`
    clear: null,
    // `<br>`. Use CSS `clear` instead
    code: null,
    // `<object>`
    codeBase: null,
    // `<object>`
    codeType: null,
    // `<object>`
    color: null,
    // `<font>` and `<hr>`. Use CSS instead
    compact: $,
    // Lists. Use CSS to reduce space between items instead
    declare: $,
    // `<object>`
    event: null,
    // `<script>`
    face: null,
    // `<font>`. Use CSS instead
    frame: null,
    // `<table>`
    frameBorder: null,
    // `<iframe>`. Use CSS `border` instead
    hSpace: O,
    // `<img>` and `<object>`
    leftMargin: O,
    // `<body>`
    link: null,
    // `<body>`. Use CSS `a:link {color: *}` instead
    longDesc: null,
    // `<frame>`, `<iframe>`, and `<img>`. Use an `<a>`
    lowSrc: null,
    // `<img>`. Use a `<picture>`
    marginHeight: O,
    // `<body>`
    marginWidth: O,
    // `<body>`
    noResize: $,
    // `<frame>`
    noHref: $,
    // `<area>`. Use no href instead of an explicit `nohref`
    noShade: $,
    // `<hr>`. Use background-color and height instead of borders
    noWrap: $,
    // `<td>` and `<th>`
    object: null,
    // `<applet>`
    profile: null,
    // `<head>`
    prompt: null,
    // `<isindex>`
    rev: null,
    // `<link>`
    rightMargin: O,
    // `<body>`
    rules: null,
    // `<table>`
    scheme: null,
    // `<meta>`
    scrolling: te,
    // `<frame>`. Use overflow in the child context
    standby: null,
    // `<object>`
    summary: null,
    // `<table>`
    text: null,
    // `<body>`. Use CSS `color` instead
    topMargin: O,
    // `<body>`
    valueType: null,
    // `<param>`
    version: null,
    // `<html>`. Use a doctype.
    vAlign: null,
    // Several. Use CSS `vertical-align` instead
    vLink: null,
    // `<body>`. Use CSS `a:visited {color}` instead
    vSpace: O,
    // `<img>` and `<object>`
    // Non-standard Properties.
    allowTransparency: null,
    autoCorrect: null,
    autoSave: null,
    disablePictureInPicture: $,
    disableRemotePlayback: $,
    prefix: null,
    property: null,
    results: O,
    security: null,
    unselectable: null
  },
  space: "html",
  transform: So
}), ef = en({
  attributes: {
    accentHeight: "accent-height",
    alignmentBaseline: "alignment-baseline",
    arabicForm: "arabic-form",
    baselineShift: "baseline-shift",
    capHeight: "cap-height",
    className: "class",
    clipPath: "clip-path",
    clipRule: "clip-rule",
    colorInterpolation: "color-interpolation",
    colorInterpolationFilters: "color-interpolation-filters",
    colorProfile: "color-profile",
    colorRendering: "color-rendering",
    crossOrigin: "crossorigin",
    dataType: "datatype",
    dominantBaseline: "dominant-baseline",
    enableBackground: "enable-background",
    fillOpacity: "fill-opacity",
    fillRule: "fill-rule",
    floodColor: "flood-color",
    floodOpacity: "flood-opacity",
    fontFamily: "font-family",
    fontSize: "font-size",
    fontSizeAdjust: "font-size-adjust",
    fontStretch: "font-stretch",
    fontStyle: "font-style",
    fontVariant: "font-variant",
    fontWeight: "font-weight",
    glyphName: "glyph-name",
    glyphOrientationHorizontal: "glyph-orientation-horizontal",
    glyphOrientationVertical: "glyph-orientation-vertical",
    hrefLang: "hreflang",
    horizAdvX: "horiz-adv-x",
    horizOriginX: "horiz-origin-x",
    horizOriginY: "horiz-origin-y",
    imageRendering: "image-rendering",
    letterSpacing: "letter-spacing",
    lightingColor: "lighting-color",
    markerEnd: "marker-end",
    markerMid: "marker-mid",
    markerStart: "marker-start",
    navDown: "nav-down",
    navDownLeft: "nav-down-left",
    navDownRight: "nav-down-right",
    navLeft: "nav-left",
    navNext: "nav-next",
    navPrev: "nav-prev",
    navRight: "nav-right",
    navUp: "nav-up",
    navUpLeft: "nav-up-left",
    navUpRight: "nav-up-right",
    onAbort: "onabort",
    onActivate: "onactivate",
    onAfterPrint: "onafterprint",
    onBeforePrint: "onbeforeprint",
    onBegin: "onbegin",
    onCancel: "oncancel",
    onCanPlay: "oncanplay",
    onCanPlayThrough: "oncanplaythrough",
    onChange: "onchange",
    onClick: "onclick",
    onClose: "onclose",
    onCopy: "oncopy",
    onCueChange: "oncuechange",
    onCut: "oncut",
    onDblClick: "ondblclick",
    onDrag: "ondrag",
    onDragEnd: "ondragend",
    onDragEnter: "ondragenter",
    onDragExit: "ondragexit",
    onDragLeave: "ondragleave",
    onDragOver: "ondragover",
    onDragStart: "ondragstart",
    onDrop: "ondrop",
    onDurationChange: "ondurationchange",
    onEmptied: "onemptied",
    onEnd: "onend",
    onEnded: "onended",
    onError: "onerror",
    onFocus: "onfocus",
    onFocusIn: "onfocusin",
    onFocusOut: "onfocusout",
    onHashChange: "onhashchange",
    onInput: "oninput",
    onInvalid: "oninvalid",
    onKeyDown: "onkeydown",
    onKeyPress: "onkeypress",
    onKeyUp: "onkeyup",
    onLoad: "onload",
    onLoadedData: "onloadeddata",
    onLoadedMetadata: "onloadedmetadata",
    onLoadStart: "onloadstart",
    onMessage: "onmessage",
    onMouseDown: "onmousedown",
    onMouseEnter: "onmouseenter",
    onMouseLeave: "onmouseleave",
    onMouseMove: "onmousemove",
    onMouseOut: "onmouseout",
    onMouseOver: "onmouseover",
    onMouseUp: "onmouseup",
    onMouseWheel: "onmousewheel",
    onOffline: "onoffline",
    onOnline: "ononline",
    onPageHide: "onpagehide",
    onPageShow: "onpageshow",
    onPaste: "onpaste",
    onPause: "onpause",
    onPlay: "onplay",
    onPlaying: "onplaying",
    onPopState: "onpopstate",
    onProgress: "onprogress",
    onRateChange: "onratechange",
    onRepeat: "onrepeat",
    onReset: "onreset",
    onResize: "onresize",
    onScroll: "onscroll",
    onSeeked: "onseeked",
    onSeeking: "onseeking",
    onSelect: "onselect",
    onShow: "onshow",
    onStalled: "onstalled",
    onStorage: "onstorage",
    onSubmit: "onsubmit",
    onSuspend: "onsuspend",
    onTimeUpdate: "ontimeupdate",
    onToggle: "ontoggle",
    onUnload: "onunload",
    onVolumeChange: "onvolumechange",
    onWaiting: "onwaiting",
    onZoom: "onzoom",
    overlinePosition: "overline-position",
    overlineThickness: "overline-thickness",
    paintOrder: "paint-order",
    panose1: "panose-1",
    pointerEvents: "pointer-events",
    referrerPolicy: "referrerpolicy",
    renderingIntent: "rendering-intent",
    shapeRendering: "shape-rendering",
    stopColor: "stop-color",
    stopOpacity: "stop-opacity",
    strikethroughPosition: "strikethrough-position",
    strikethroughThickness: "strikethrough-thickness",
    strokeDashArray: "stroke-dasharray",
    strokeDashOffset: "stroke-dashoffset",
    strokeLineCap: "stroke-linecap",
    strokeLineJoin: "stroke-linejoin",
    strokeMiterLimit: "stroke-miterlimit",
    strokeOpacity: "stroke-opacity",
    strokeWidth: "stroke-width",
    tabIndex: "tabindex",
    textAnchor: "text-anchor",
    textDecoration: "text-decoration",
    textRendering: "text-rendering",
    transformOrigin: "transform-origin",
    typeOf: "typeof",
    underlinePosition: "underline-position",
    underlineThickness: "underline-thickness",
    unicodeBidi: "unicode-bidi",
    unicodeRange: "unicode-range",
    unitsPerEm: "units-per-em",
    vAlphabetic: "v-alphabetic",
    vHanging: "v-hanging",
    vIdeographic: "v-ideographic",
    vMathematical: "v-mathematical",
    vectorEffect: "vector-effect",
    vertAdvY: "vert-adv-y",
    vertOriginX: "vert-origin-x",
    vertOriginY: "vert-origin-y",
    wordSpacing: "word-spacing",
    writingMode: "writing-mode",
    xHeight: "x-height",
    // These were camelcased in Tiny. Now lowercased in SVG 2
    playbackOrder: "playbackorder",
    timelineBegin: "timelinebegin"
  },
  properties: {
    about: me,
    accentHeight: O,
    accumulate: null,
    additive: null,
    alignmentBaseline: null,
    alphabetic: O,
    amplitude: O,
    arabicForm: null,
    ascent: O,
    attributeName: null,
    attributeType: null,
    azimuth: O,
    bandwidth: null,
    baselineShift: null,
    baseFrequency: null,
    baseProfile: null,
    bbox: null,
    begin: null,
    bias: O,
    by: null,
    calcMode: null,
    capHeight: O,
    className: J,
    clip: null,
    clipPath: null,
    clipPathUnits: null,
    clipRule: null,
    color: null,
    colorInterpolation: null,
    colorInterpolationFilters: null,
    colorProfile: null,
    colorRendering: null,
    content: null,
    contentScriptType: null,
    contentStyleType: null,
    crossOrigin: null,
    cursor: null,
    cx: null,
    cy: null,
    d: null,
    dataType: null,
    defaultAction: null,
    descent: O,
    diffuseConstant: O,
    direction: null,
    display: null,
    dur: null,
    divisor: O,
    dominantBaseline: null,
    download: $,
    dx: null,
    dy: null,
    edgeMode: null,
    editable: null,
    elevation: O,
    enableBackground: null,
    end: null,
    event: null,
    exponent: O,
    externalResourcesRequired: null,
    fill: null,
    fillOpacity: O,
    fillRule: null,
    filter: null,
    filterRes: null,
    filterUnits: null,
    floodColor: null,
    floodOpacity: null,
    focusable: null,
    focusHighlight: null,
    fontFamily: null,
    fontSize: null,
    fontSizeAdjust: null,
    fontStretch: null,
    fontStyle: null,
    fontVariant: null,
    fontWeight: null,
    format: null,
    fr: null,
    from: null,
    fx: null,
    fy: null,
    g1: Ze,
    g2: Ze,
    glyphName: Ze,
    glyphOrientationHorizontal: null,
    glyphOrientationVertical: null,
    glyphRef: null,
    gradientTransform: null,
    gradientUnits: null,
    handler: null,
    hanging: O,
    hatchContentUnits: null,
    hatchUnits: null,
    height: null,
    href: null,
    hrefLang: null,
    horizAdvX: O,
    horizOriginX: O,
    horizOriginY: O,
    id: null,
    ideographic: O,
    imageRendering: null,
    initialVisibility: null,
    in: null,
    in2: null,
    intercept: O,
    k: O,
    k1: O,
    k2: O,
    k3: O,
    k4: O,
    kernelMatrix: me,
    kernelUnitLength: null,
    keyPoints: null,
    // SEMI_COLON_SEPARATED
    keySplines: null,
    // SEMI_COLON_SEPARATED
    keyTimes: null,
    // SEMI_COLON_SEPARATED
    kerning: null,
    lang: null,
    lengthAdjust: null,
    letterSpacing: null,
    lightingColor: null,
    limitingConeAngle: O,
    local: null,
    markerEnd: null,
    markerMid: null,
    markerStart: null,
    markerHeight: null,
    markerUnits: null,
    markerWidth: null,
    mask: null,
    maskContentUnits: null,
    maskUnits: null,
    mathematical: null,
    max: null,
    media: null,
    mediaCharacterEncoding: null,
    mediaContentEncodings: null,
    mediaSize: O,
    mediaTime: null,
    method: null,
    min: null,
    mode: null,
    name: null,
    navDown: null,
    navDownLeft: null,
    navDownRight: null,
    navLeft: null,
    navNext: null,
    navPrev: null,
    navRight: null,
    navUp: null,
    navUpLeft: null,
    navUpRight: null,
    numOctaves: null,
    observer: null,
    offset: null,
    onAbort: null,
    onActivate: null,
    onAfterPrint: null,
    onBeforePrint: null,
    onBegin: null,
    onCancel: null,
    onCanPlay: null,
    onCanPlayThrough: null,
    onChange: null,
    onClick: null,
    onClose: null,
    onCopy: null,
    onCueChange: null,
    onCut: null,
    onDblClick: null,
    onDrag: null,
    onDragEnd: null,
    onDragEnter: null,
    onDragExit: null,
    onDragLeave: null,
    onDragOver: null,
    onDragStart: null,
    onDrop: null,
    onDurationChange: null,
    onEmptied: null,
    onEnd: null,
    onEnded: null,
    onError: null,
    onFocus: null,
    onFocusIn: null,
    onFocusOut: null,
    onHashChange: null,
    onInput: null,
    onInvalid: null,
    onKeyDown: null,
    onKeyPress: null,
    onKeyUp: null,
    onLoad: null,
    onLoadedData: null,
    onLoadedMetadata: null,
    onLoadStart: null,
    onMessage: null,
    onMouseDown: null,
    onMouseEnter: null,
    onMouseLeave: null,
    onMouseMove: null,
    onMouseOut: null,
    onMouseOver: null,
    onMouseUp: null,
    onMouseWheel: null,
    onOffline: null,
    onOnline: null,
    onPageHide: null,
    onPageShow: null,
    onPaste: null,
    onPause: null,
    onPlay: null,
    onPlaying: null,
    onPopState: null,
    onProgress: null,
    onRateChange: null,
    onRepeat: null,
    onReset: null,
    onResize: null,
    onScroll: null,
    onSeeked: null,
    onSeeking: null,
    onSelect: null,
    onShow: null,
    onStalled: null,
    onStorage: null,
    onSubmit: null,
    onSuspend: null,
    onTimeUpdate: null,
    onToggle: null,
    onUnload: null,
    onVolumeChange: null,
    onWaiting: null,
    onZoom: null,
    opacity: null,
    operator: null,
    order: null,
    orient: null,
    orientation: null,
    origin: null,
    overflow: null,
    overlay: null,
    overlinePosition: O,
    overlineThickness: O,
    paintOrder: null,
    panose1: null,
    path: null,
    pathLength: O,
    patternContentUnits: null,
    patternTransform: null,
    patternUnits: null,
    phase: null,
    ping: J,
    pitch: null,
    playbackOrder: null,
    pointerEvents: null,
    points: null,
    pointsAtX: O,
    pointsAtY: O,
    pointsAtZ: O,
    preserveAlpha: null,
    preserveAspectRatio: null,
    primitiveUnits: null,
    propagate: null,
    property: me,
    r: null,
    radius: null,
    referrerPolicy: null,
    refX: null,
    refY: null,
    rel: me,
    rev: me,
    renderingIntent: null,
    repeatCount: null,
    repeatDur: null,
    requiredExtensions: me,
    requiredFeatures: me,
    requiredFonts: me,
    requiredFormats: me,
    resource: null,
    restart: null,
    result: null,
    rotate: null,
    rx: null,
    ry: null,
    scale: null,
    seed: null,
    shapeRendering: null,
    side: null,
    slope: null,
    snapshotTime: null,
    specularConstant: O,
    specularExponent: O,
    spreadMethod: null,
    spacing: null,
    startOffset: null,
    stdDeviation: null,
    stemh: null,
    stemv: null,
    stitchTiles: null,
    stopColor: null,
    stopOpacity: null,
    strikethroughPosition: O,
    strikethroughThickness: O,
    string: null,
    stroke: null,
    strokeDashArray: me,
    strokeDashOffset: null,
    strokeLineCap: null,
    strokeLineJoin: null,
    strokeMiterLimit: O,
    strokeOpacity: O,
    strokeWidth: null,
    style: null,
    surfaceScale: O,
    syncBehavior: null,
    syncBehaviorDefault: null,
    syncMaster: null,
    syncTolerance: null,
    syncToleranceDefault: null,
    systemLanguage: me,
    tabIndex: O,
    tableValues: null,
    target: null,
    targetX: O,
    targetY: O,
    textAnchor: null,
    textDecoration: null,
    textRendering: null,
    textLength: null,
    timelineBegin: null,
    title: null,
    transformBehavior: null,
    type: null,
    typeOf: me,
    to: null,
    transform: null,
    transformOrigin: null,
    u1: null,
    u2: null,
    underlinePosition: O,
    underlineThickness: O,
    unicode: null,
    unicodeBidi: null,
    unicodeRange: null,
    unitsPerEm: O,
    values: null,
    vAlphabetic: O,
    vMathematical: O,
    vectorEffect: null,
    vHanging: O,
    vIdeographic: O,
    version: null,
    vertAdvY: O,
    vertOriginX: O,
    vertOriginY: O,
    viewBox: null,
    viewTarget: null,
    visibility: null,
    width: null,
    widths: null,
    wordSpacing: null,
    writingMode: null,
    x: null,
    x1: null,
    x2: null,
    xChannelSelector: null,
    xHeight: O,
    y: null,
    y1: null,
    y2: null,
    yChannelSelector: null,
    z: null,
    zoomAndPan: null
  },
  space: "svg",
  transform: vo
}), Eo = en({
  properties: {
    xLinkActuate: null,
    xLinkArcRole: null,
    xLinkHref: null,
    xLinkRole: null,
    xLinkShow: null,
    xLinkTitle: null,
    xLinkType: null
  },
  space: "xlink",
  transform(e, n) {
    return "xlink:" + n.slice(5).toLowerCase();
  }
}), Co = en({
  attributes: { xmlnsxlink: "xmlns:xlink" },
  properties: { xmlnsXLink: null, xmlns: null },
  space: "xmlns",
  transform: So
}), Ao = en({
  properties: { xmlBase: null, xmlLang: null, xmlSpace: null },
  space: "xml",
  transform(e, n) {
    return "xml:" + n.slice(3).toLowerCase();
  }
}), nf = {
  classId: "classID",
  dataType: "datatype",
  itemId: "itemID",
  strokeDashArray: "strokeDasharray",
  strokeDashOffset: "strokeDashoffset",
  strokeLineCap: "strokeLinecap",
  strokeLineJoin: "strokeLinejoin",
  strokeMiterLimit: "strokeMiterlimit",
  typeOf: "typeof",
  xLinkActuate: "xlinkActuate",
  xLinkArcRole: "xlinkArcrole",
  xLinkHref: "xlinkHref",
  xLinkRole: "xlinkRole",
  xLinkShow: "xlinkShow",
  xLinkTitle: "xlinkTitle",
  xLinkType: "xlinkType",
  xmlnsXLink: "xmlnsXlink"
}, tf = /[A-Z]/g, Gr = /-[a-z]/g, rf = /^data[-\w.:]+$/i;
function of(e, n) {
  const t = ht(n);
  let r = n, i = de;
  if (t in e.normal)
    return e.property[e.normal[t]];
  if (t.length > 4 && t.slice(0, 4) === "data" && rf.test(n)) {
    if (n.charAt(4) === "-") {
      const l = n.slice(5).replace(Gr, af);
      r = "data" + l.charAt(0).toUpperCase() + l.slice(1);
    } else {
      const l = n.slice(4);
      if (!Gr.test(l)) {
        let o = l.replace(tf, lf);
        o.charAt(0) !== "-" && (o = "-" + o), n = "data" + o;
      }
    }
    i = Zt;
  }
  return new i(r, n);
}
function lf(e) {
  return "-" + e.toLowerCase();
}
function af(e) {
  return e.charAt(1).toUpperCase();
}
const sf = xo([wo, Jp, Eo, Co, Ao], "html"), Qt = xo([wo, ef, Eo, Co, Ao], "svg");
function Jy(e) {
  const n = String(e || "").trim();
  return n ? n.split(/[ \t\n\r\f]+/g) : [];
}
function uf(e) {
  return e.join(" ").trim();
}
var Jt = {}, Wr = /\/\*[^*]*\*+([^/*][^*]*\*+)*\//g, cf = /\n/g, pf = /^\s*/, ff = /^(\*?[-#/*\\\w]+(\[[0-9a-z_-]+\])?)\s*/, hf = /^:\s*/, df = /^((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^)]*?\)|[^};])+)/, gf = /^[;\s]*/, mf = /^\s+|\s+$/g, bf = `
`, Yr = "/", Xr = "*", Be = "", yf = "comment", kf = "declaration";
function xf(e, n) {
  if (typeof e != "string")
    throw new TypeError("First argument must be a string");
  if (!e) return [];
  n = n || {};
  var t = 1, r = 1;
  function i(g) {
    var v = g.match(cf);
    v && (t += v.length);
    var A = g.lastIndexOf(bf);
    r = ~A ? g.length - A : r + g.length;
  }
  function l() {
    var g = { line: t, column: r };
    return function(v) {
      return v.position = new o(g), u(), v;
    };
  }
  function o(g) {
    this.start = g, this.end = { line: t, column: r }, this.source = n.source;
  }
  o.prototype.content = e;
  function a(g) {
    var v = new Error(
      n.source + ":" + t + ":" + r + ": " + g
    );
    if (v.reason = g, v.filename = n.source, v.line = t, v.column = r, v.source = e, !n.silent) throw v;
  }
  function s(g) {
    var v = g.exec(e);
    if (v) {
      var A = v[0];
      return i(A), e = e.slice(A.length), v;
    }
  }
  function u() {
    s(pf);
  }
  function p(g) {
    var v;
    for (g = g || []; v = c(); )
      v !== !1 && g.push(v);
    return g;
  }
  function c() {
    var g = l();
    if (!(Yr != e.charAt(0) || Xr != e.charAt(1))) {
      for (var v = 2; Be != e.charAt(v) && (Xr != e.charAt(v) || Yr != e.charAt(v + 1)); )
        ++v;
      if (v += 2, Be === e.charAt(v - 1))
        return a("End of comment missing");
      var A = e.slice(2, v - 2);
      return r += 2, i(A), e = e.slice(v), r += 2, g({
        type: yf,
        comment: A
      });
    }
  }
  function h() {
    var g = l(), v = s(ff);
    if (v) {
      if (c(), !s(hf)) return a("property missing ':'");
      var A = s(df), w = g({
        type: kf,
        property: Kr(v[0].replace(Wr, Be)),
        value: A ? Kr(A[0].replace(Wr, Be)) : Be
      });
      return s(gf), w;
    }
  }
  function f() {
    var g = [];
    p(g);
    for (var v; v = h(); )
      v !== !1 && (g.push(v), p(g));
    return g;
  }
  return u(), f();
}
function Kr(e) {
  return e ? e.replace(mf, Be) : Be;
}
var wf = xf, vf = De && De.__importDefault || function(e) {
  return e && e.__esModule ? e : { default: e };
};
Object.defineProperty(Jt, "__esModule", { value: !0 });
Jt.default = Ef;
const Sf = vf(wf);
function Ef(e, n) {
  let t = null;
  if (!e || typeof e != "string")
    return t;
  const r = (0, Sf.default)(e), i = typeof n == "function";
  return r.forEach((l) => {
    if (l.type !== "declaration")
      return;
    const { property: o, value: a } = l;
    i ? n(o, a, l) : a && (t = t || {}, t[o] = a);
  }), t;
}
var $n = {};
Object.defineProperty($n, "__esModule", { value: !0 });
$n.camelCase = void 0;
var Cf = /^--[a-zA-Z0-9_-]+$/, Af = /-([a-z])/g, Tf = /^[^-]+$/, If = /^-(webkit|moz|ms|o|khtml)-/, Of = /^-(ms)-/, Lf = function(e) {
  return !e || Tf.test(e) || Cf.test(e);
}, Rf = function(e, n) {
  return n.toUpperCase();
}, Zr = function(e, n) {
  return "".concat(n, "-");
}, Nf = function(e, n) {
  return n === void 0 && (n = {}), Lf(e) ? e : (e = e.toLowerCase(), n.reactCompat ? e = e.replace(Of, Zr) : e = e.replace(If, Zr), e.replace(Af, Rf));
};
$n.camelCase = Nf;
var _f = De && De.__importDefault || function(e) {
  return e && e.__esModule ? e : { default: e };
}, Ff = _f(Jt), Df = $n;
function mt(e, n) {
  var t = {};
  return !e || typeof e != "string" || (0, Ff.default)(e, function(r, i) {
    r && i && (t[(0, Df.camelCase)(r, n)] = i);
  }), t;
}
mt.default = mt;
var Pf = mt;
const zf = /* @__PURE__ */ he(Pf), To = Io("end"), er = Io("start");
function Io(e) {
  return n;
  function n(t) {
    const r = t && t.position && t.position[e] || {};
    if (typeof r.line == "number" && r.line > 0 && typeof r.column == "number" && r.column > 0)
      return {
        line: r.line,
        column: r.column,
        offset: typeof r.offset == "number" && r.offset > -1 ? r.offset : void 0
      };
  }
}
function Mf(e) {
  const n = er(e), t = To(e);
  if (n && t)
    return { start: n, end: t };
}
function fn(e) {
  return !e || typeof e != "object" ? "" : "position" in e || "type" in e ? Qr(e.position) : "start" in e || "end" in e ? Qr(e) : "line" in e || "column" in e ? bt(e) : "";
}
function bt(e) {
  return Jr(e && e.line) + ":" + Jr(e && e.column);
}
function Qr(e) {
  return bt(e && e.start) + "-" + bt(e && e.end);
}
function Jr(e) {
  return e && typeof e == "number" ? e : 1;
}
class se extends Error {
  /**
   * Create a message for `reason`.
   *
   * > 🪦 **Note**: also has obsolete signatures.
   *
   * @overload
   * @param {string} reason
   * @param {Options | null | undefined} [options]
   * @returns
   *
   * @overload
   * @param {string} reason
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns
   *
   * @overload
   * @param {string} reason
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns
   *
   * @overload
   * @param {string} reason
   * @param {string | null | undefined} [origin]
   * @returns
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {string | null | undefined} [origin]
   * @returns
   *
   * @param {Error | VFileMessage | string} causeOrReason
   *   Reason for message, should use markdown.
   * @param {Node | NodeLike | Options | Point | Position | string | null | undefined} [optionsOrParentOrPlace]
   *   Configuration (optional).
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (example:
   *   `'my-package:my-rule'` or `'my-rule'`).
   * @returns
   *   Instance of `VFileMessage`.
   */
  // eslint-disable-next-line complexity
  constructor(n, t, r) {
    super(), typeof t == "string" && (r = t, t = void 0);
    let i = "", l = {}, o = !1;
    if (t && ("line" in t && "column" in t ? l = { place: t } : "start" in t && "end" in t ? l = { place: t } : "type" in t ? l = {
      ancestors: [t],
      place: t.position
    } : l = { ...t }), typeof n == "string" ? i = n : !l.cause && n && (o = !0, i = n.message, l.cause = n), !l.ruleId && !l.source && typeof r == "string") {
      const s = r.indexOf(":");
      s === -1 ? l.ruleId = r : (l.source = r.slice(0, s), l.ruleId = r.slice(s + 1));
    }
    if (!l.place && l.ancestors && l.ancestors) {
      const s = l.ancestors[l.ancestors.length - 1];
      s && (l.place = s.position);
    }
    const a = l.place && "start" in l.place ? l.place.start : l.place;
    this.ancestors = l.ancestors || void 0, this.cause = l.cause || void 0, this.column = a ? a.column : void 0, this.fatal = void 0, this.file = "", this.message = i, this.line = a ? a.line : void 0, this.name = fn(l.place) || "1:1", this.place = l.place || void 0, this.reason = this.message, this.ruleId = l.ruleId || void 0, this.source = l.source || void 0, this.stack = o && l.cause && typeof l.cause.stack == "string" ? l.cause.stack : "", this.actual = void 0, this.expected = void 0, this.note = void 0, this.url = void 0;
  }
}
se.prototype.file = "";
se.prototype.name = "";
se.prototype.reason = "";
se.prototype.message = "";
se.prototype.stack = "";
se.prototype.column = void 0;
se.prototype.line = void 0;
se.prototype.ancestors = void 0;
se.prototype.cause = void 0;
se.prototype.fatal = void 0;
se.prototype.place = void 0;
se.prototype.ruleId = void 0;
se.prototype.source = void 0;
const nr = {}.hasOwnProperty, $f = /* @__PURE__ */ new Map(), jf = /[A-Z]/g, Bf = /* @__PURE__ */ new Set(["table", "tbody", "thead", "tfoot", "tr"]), Uf = /* @__PURE__ */ new Set(["td", "th"]), Oo = "https://github.com/syntax-tree/hast-util-to-jsx-runtime";
function Hf(e, n) {
  if (!n || n.Fragment === void 0)
    throw new TypeError("Expected `Fragment` in options");
  const t = n.filePath || void 0;
  let r;
  if (n.development) {
    if (typeof n.jsxDEV != "function")
      throw new TypeError(
        "Expected `jsxDEV` in options when `development: true`"
      );
    r = Zf(t, n.jsxDEV);
  } else {
    if (typeof n.jsx != "function")
      throw new TypeError("Expected `jsx` in production options");
    if (typeof n.jsxs != "function")
      throw new TypeError("Expected `jsxs` in production options");
    r = Kf(t, n.jsx, n.jsxs);
  }
  const i = {
    Fragment: n.Fragment,
    ancestors: [],
    components: n.components || {},
    create: r,
    elementAttributeNameCase: n.elementAttributeNameCase || "react",
    evaluater: n.createEvaluater ? n.createEvaluater() : void 0,
    filePath: t,
    ignoreInvalidStyle: n.ignoreInvalidStyle || !1,
    passKeys: n.passKeys !== !1,
    passNode: n.passNode || !1,
    schema: n.space === "svg" ? Qt : sf,
    stylePropertyNameCase: n.stylePropertyNameCase || "dom",
    tableCellAlignToStyle: n.tableCellAlignToStyle !== !1
  }, l = Lo(i, e, void 0);
  return l && typeof l != "string" ? l : i.create(
    e,
    i.Fragment,
    { children: l || void 0 },
    void 0
  );
}
function Lo(e, n, t) {
  if (n.type === "element")
    return Vf(e, n, t);
  if (n.type === "mdxFlowExpression" || n.type === "mdxTextExpression")
    return qf(e, n);
  if (n.type === "mdxJsxFlowElement" || n.type === "mdxJsxTextElement")
    return Wf(e, n, t);
  if (n.type === "mdxjsEsm")
    return Gf(e, n);
  if (n.type === "root")
    return Yf(e, n, t);
  if (n.type === "text")
    return Xf(e, n);
}
function Vf(e, n, t) {
  const r = e.schema;
  let i = r;
  n.tagName.toLowerCase() === "svg" && r.space === "html" && (i = Qt, e.schema = i), e.ancestors.push(n);
  const l = No(e, n.tagName, !1), o = Qf(e, n);
  let a = rr(e, n);
  return Bf.has(n.tagName) && (a = a.filter(function(s) {
    return typeof s == "string" ? !Zp(s) : !0;
  })), Ro(e, o, l, n), tr(o, a), e.ancestors.pop(), e.schema = r, e.create(n, l, o, t);
}
function qf(e, n) {
  if (n.data && n.data.estree && e.evaluater) {
    const r = n.data.estree.body[0];
    return r.type, /** @type {Child | undefined} */
    e.evaluater.evaluateExpression(r.expression);
  }
  mn(e, n.position);
}
function Gf(e, n) {
  if (n.data && n.data.estree && e.evaluater)
    return (
      /** @type {Child | undefined} */
      e.evaluater.evaluateProgram(n.data.estree)
    );
  mn(e, n.position);
}
function Wf(e, n, t) {
  const r = e.schema;
  let i = r;
  n.name === "svg" && r.space === "html" && (i = Qt, e.schema = i), e.ancestors.push(n);
  const l = n.name === null ? e.Fragment : No(e, n.name, !0), o = Jf(e, n), a = rr(e, n);
  return Ro(e, o, l, n), tr(o, a), e.ancestors.pop(), e.schema = r, e.create(n, l, o, t);
}
function Yf(e, n, t) {
  const r = {};
  return tr(r, rr(e, n)), e.create(n, e.Fragment, r, t);
}
function Xf(e, n) {
  return n.value;
}
function Ro(e, n, t, r) {
  typeof t != "string" && t !== e.Fragment && e.passNode && (n.node = r);
}
function tr(e, n) {
  if (n.length > 0) {
    const t = n.length > 1 ? n : n[0];
    t && (e.children = t);
  }
}
function Kf(e, n, t) {
  return r;
  function r(i, l, o, a) {
    const u = Array.isArray(o.children) ? t : n;
    return a ? u(l, o, a) : u(l, o);
  }
}
function Zf(e, n) {
  return t;
  function t(r, i, l, o) {
    const a = Array.isArray(l.children), s = er(r);
    return n(
      i,
      l,
      o,
      a,
      {
        columnNumber: s ? s.column - 1 : void 0,
        fileName: e,
        lineNumber: s ? s.line : void 0
      },
      void 0
    );
  }
}
function Qf(e, n) {
  const t = {};
  let r, i;
  for (i in n.properties)
    if (i !== "children" && nr.call(n.properties, i)) {
      const l = eh(e, i, n.properties[i]);
      if (l) {
        const [o, a] = l;
        e.tableCellAlignToStyle && o === "align" && typeof a == "string" && Uf.has(n.tagName) ? r = a : t[o] = a;
      }
    }
  if (r) {
    const l = (
      /** @type {Style} */
      t.style || (t.style = {})
    );
    l[e.stylePropertyNameCase === "css" ? "text-align" : "textAlign"] = r;
  }
  return t;
}
function Jf(e, n) {
  const t = {};
  for (const r of n.attributes)
    if (r.type === "mdxJsxExpressionAttribute")
      if (r.data && r.data.estree && e.evaluater) {
        const l = r.data.estree.body[0];
        l.type;
        const o = l.expression;
        o.type;
        const a = o.properties[0];
        a.type, Object.assign(
          t,
          e.evaluater.evaluateExpression(a.argument)
        );
      } else
        mn(e, n.position);
    else {
      const i = r.name;
      let l;
      if (r.value && typeof r.value == "object")
        if (r.value.data && r.value.data.estree && e.evaluater) {
          const a = r.value.data.estree.body[0];
          a.type, l = e.evaluater.evaluateExpression(a.expression);
        } else
          mn(e, n.position);
      else
        l = r.value === null ? !0 : r.value;
      t[i] = /** @type {Props[keyof Props]} */
      l;
    }
  return t;
}
function rr(e, n) {
  const t = [];
  let r = -1;
  const i = e.passKeys ? /* @__PURE__ */ new Map() : $f;
  for (; ++r < n.children.length; ) {
    const l = n.children[r];
    let o;
    if (e.passKeys) {
      const s = l.type === "element" ? l.tagName : l.type === "mdxJsxFlowElement" || l.type === "mdxJsxTextElement" ? l.name : void 0;
      if (s) {
        const u = i.get(s) || 0;
        o = s + "-" + u, i.set(s, u + 1);
      }
    }
    const a = Lo(e, l, o);
    a !== void 0 && t.push(a);
  }
  return t;
}
function eh(e, n, t) {
  const r = of(e.schema, n);
  if (!(t == null || typeof t == "number" && Number.isNaN(t))) {
    if (Array.isArray(t) && (t = r.commaSeparated ? Gp(t) : uf(t)), r.property === "style") {
      let i = typeof t == "object" ? t : nh(e, String(t));
      return e.stylePropertyNameCase === "css" && (i = th(i)), ["style", i];
    }
    return [
      e.elementAttributeNameCase === "react" && r.space ? nf[r.property] || r.property : r.attribute,
      t
    ];
  }
}
function nh(e, n) {
  try {
    return zf(n, { reactCompat: !0 });
  } catch (t) {
    if (e.ignoreInvalidStyle)
      return {};
    const r = (
      /** @type {Error} */
      t
    ), i = new se("Cannot parse `style` attribute", {
      ancestors: e.ancestors,
      cause: r,
      ruleId: "style",
      source: "hast-util-to-jsx-runtime"
    });
    throw i.file = e.filePath || void 0, i.url = Oo + "#cannot-parse-style-attribute", i;
  }
}
function No(e, n, t) {
  let r;
  if (!t)
    r = { type: "Literal", value: n };
  else if (n.includes(".")) {
    const i = n.split(".");
    let l = -1, o;
    for (; ++l < i.length; ) {
      const a = Hr(i[l]) ? { type: "Identifier", name: i[l] } : { type: "Literal", value: i[l] };
      o = o ? {
        type: "MemberExpression",
        object: o,
        property: a,
        computed: !!(l && a.type === "Literal"),
        optional: !1
      } : a;
    }
    r = o;
  } else
    r = Hr(n) && !/^[a-z]/.test(n) ? { type: "Identifier", name: n } : { type: "Literal", value: n };
  if (r.type === "Literal") {
    const i = (
      /** @type {string | number} */
      r.value
    );
    return nr.call(e.components, i) ? e.components[i] : i;
  }
  if (e.evaluater)
    return e.evaluater.evaluateExpression(r);
  mn(e);
}
function mn(e, n) {
  const t = new se(
    "Cannot handle MDX estrees without `createEvaluater`",
    {
      ancestors: e.ancestors,
      place: n,
      ruleId: "mdx-estree",
      source: "hast-util-to-jsx-runtime"
    }
  );
  throw t.file = e.filePath || void 0, t.url = Oo + "#cannot-handle-mdx-estrees-without-createevaluater", t;
}
function th(e) {
  const n = {};
  let t;
  for (t in e)
    nr.call(e, t) && (n[rh(t)] = e[t]);
  return n;
}
function rh(e) {
  let n = e.replace(jf, ih);
  return n.slice(0, 3) === "ms-" && (n = "-" + n), n;
}
function ih(e) {
  return "-" + e.toLowerCase();
}
const Yn = {
  action: ["form"],
  cite: ["blockquote", "del", "ins", "q"],
  data: ["object"],
  formAction: ["button", "input"],
  href: ["a", "area", "base", "link"],
  icon: ["menuitem"],
  itemId: null,
  manifest: ["html"],
  ping: ["a", "area"],
  poster: ["video"],
  src: [
    "audio",
    "embed",
    "iframe",
    "img",
    "input",
    "script",
    "source",
    "track",
    "video"
  ]
}, oh = {};
function ir(e, n) {
  const t = oh, r = typeof t.includeImageAlt == "boolean" ? t.includeImageAlt : !0, i = typeof t.includeHtml == "boolean" ? t.includeHtml : !0;
  return _o(e, r, i);
}
function _o(e, n, t) {
  if (lh(e)) {
    if ("value" in e)
      return e.type === "html" && !t ? "" : e.value;
    if (n && "alt" in e && e.alt)
      return e.alt;
    if ("children" in e)
      return ei(e.children, n, t);
  }
  return Array.isArray(e) ? ei(e, n, t) : "";
}
function ei(e, n, t) {
  const r = [];
  let i = -1;
  for (; ++i < e.length; )
    r[i] = _o(e[i], n, t);
  return r.join("");
}
function lh(e) {
  return !!(e && typeof e == "object");
}
const ni = document.createElement("i");
function or(e) {
  const n = "&" + e + ";";
  ni.innerHTML = n;
  const t = ni.textContent;
  return (
    // @ts-expect-error: TypeScript is wrong that `textContent` on elements can
    // yield `null`.
    t.charCodeAt(t.length - 1) === 59 && e !== "semi" || t === n ? !1 : t
  );
}
function be(e, n, t, r) {
  const i = e.length;
  let l = 0, o;
  if (n < 0 ? n = -n > i ? 0 : i + n : n = n > i ? i : n, t = t > 0 ? t : 0, r.length < 1e4)
    o = Array.from(r), o.unshift(n, t), e.splice(...o);
  else
    for (t && e.splice(n, t); l < r.length; )
      o = r.slice(l, l + 1e4), o.unshift(n, 0), e.splice(...o), l += 1e4, n += 1e4;
}
function xe(e, n) {
  return e.length > 0 ? (be(e, e.length, 0, n), e) : n;
}
const ti = {}.hasOwnProperty;
function Fo(e) {
  const n = {};
  let t = -1;
  for (; ++t < e.length; )
    ah(n, e[t]);
  return n;
}
function ah(e, n) {
  let t;
  for (t in n) {
    const i = (ti.call(e, t) ? e[t] : void 0) || (e[t] = {}), l = n[t];
    let o;
    if (l)
      for (o in l) {
        ti.call(i, o) || (i[o] = []);
        const a = l[o];
        sh(
          // @ts-expect-error Looks like a list.
          i[o],
          Array.isArray(a) ? a : a ? [a] : []
        );
      }
  }
}
function sh(e, n) {
  let t = -1;
  const r = [];
  for (; ++t < n.length; )
    (n[t].add === "after" ? e : r).push(n[t]);
  be(e, 0, 0, r);
}
function Do(e, n) {
  const t = Number.parseInt(e, n);
  return (
    // C0 except for HT, LF, FF, CR, space.
    t < 9 || t === 11 || t > 13 && t < 32 || // Control character (DEL) of C0, and C1 controls.
    t > 126 && t < 160 || // Lone high surrogates and low surrogates.
    t > 55295 && t < 57344 || // Noncharacters.
    t > 64975 && t < 65008 || /* eslint-disable no-bitwise */
    (t & 65535) === 65535 || (t & 65535) === 65534 || /* eslint-enable no-bitwise */
    // Out of range
    t > 1114111 ? "�" : String.fromCodePoint(t)
  );
}
function Ce(e) {
  return e.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase();
}
const ce = ze(/[A-Za-z]/), ae = ze(/[\dA-Za-z]/), uh = ze(/[#-'*+\--9=?A-Z^-~]/);
function _n(e) {
  return (
    // Special whitespace codes (which have negative values), C0 and Control
    // character DEL
    e !== null && (e < 32 || e === 127)
  );
}
const yt = ze(/\d/), ch = ze(/[\dA-Fa-f]/), ph = ze(/[!-/:-@[-`{-~]/);
function F(e) {
  return e !== null && e < -2;
}
function Q(e) {
  return e !== null && (e < 0 || e === 32);
}
function H(e) {
  return e === -2 || e === -1 || e === 32;
}
const jn = ze(new RegExp("\\p{P}|\\p{S}", "u")), Ue = ze(/\s/);
function ze(e) {
  return n;
  function n(t) {
    return t !== null && t > -1 && e.test(String.fromCharCode(t));
  }
}
function nn(e) {
  const n = [];
  let t = -1, r = 0, i = 0;
  for (; ++t < e.length; ) {
    const l = e.charCodeAt(t);
    let o = "";
    if (l === 37 && ae(e.charCodeAt(t + 1)) && ae(e.charCodeAt(t + 2)))
      i = 2;
    else if (l < 128)
      /[!#$&-;=?-Z_a-z~]/.test(String.fromCharCode(l)) || (o = String.fromCharCode(l));
    else if (l > 55295 && l < 57344) {
      const a = e.charCodeAt(t + 1);
      l < 56320 && a > 56319 && a < 57344 ? (o = String.fromCharCode(l, a), i = 1) : o = "�";
    } else
      o = String.fromCharCode(l);
    o && (n.push(e.slice(r, t), encodeURIComponent(o)), r = t + i + 1, o = ""), i && (t += i, i = 0);
  }
  return n.join("") + e.slice(r);
}
function G(e, n, t, r) {
  const i = r ? r - 1 : Number.POSITIVE_INFINITY;
  let l = 0;
  return o;
  function o(s) {
    return H(s) ? (e.enter(t), a(s)) : n(s);
  }
  function a(s) {
    return H(s) && l++ < i ? (e.consume(s), a) : (e.exit(t), n(s));
  }
}
const fh = {
  tokenize: hh
};
function hh(e) {
  const n = e.attempt(this.parser.constructs.contentInitial, r, i);
  let t;
  return n;
  function r(a) {
    if (a === null) {
      e.consume(a);
      return;
    }
    return e.enter("lineEnding"), e.consume(a), e.exit("lineEnding"), G(e, n, "linePrefix");
  }
  function i(a) {
    return e.enter("paragraph"), l(a);
  }
  function l(a) {
    const s = e.enter("chunkText", {
      contentType: "text",
      previous: t
    });
    return t && (t.next = s), t = s, o(a);
  }
  function o(a) {
    if (a === null) {
      e.exit("chunkText"), e.exit("paragraph"), e.consume(a);
      return;
    }
    return F(a) ? (e.consume(a), e.exit("chunkText"), l) : (e.consume(a), o);
  }
}
const dh = {
  tokenize: gh
}, ri = {
  tokenize: mh
};
function gh(e) {
  const n = this, t = [];
  let r = 0, i, l, o;
  return a;
  function a(y) {
    if (r < t.length) {
      const E = t[r];
      return n.containerState = E[1], e.attempt(E[0].continuation, s, u)(y);
    }
    return u(y);
  }
  function s(y) {
    if (r++, n.containerState._closeFlow) {
      n.containerState._closeFlow = void 0, i && k();
      const E = n.events.length;
      let S = E, m;
      for (; S--; )
        if (n.events[S][0] === "exit" && n.events[S][1].type === "chunkFlow") {
          m = n.events[S][1].end;
          break;
        }
      w(r);
      let I = E;
      for (; I < n.events.length; )
        n.events[I][1].end = {
          ...m
        }, I++;
      return be(n.events, S + 1, 0, n.events.slice(E)), n.events.length = I, u(y);
    }
    return a(y);
  }
  function u(y) {
    if (r === t.length) {
      if (!i)
        return h(y);
      if (i.currentConstruct && i.currentConstruct.concrete)
        return g(y);
      n.interrupt = !!(i.currentConstruct && !i._gfmTableDynamicInterruptHack);
    }
    return n.containerState = {}, e.check(ri, p, c)(y);
  }
  function p(y) {
    return i && k(), w(r), h(y);
  }
  function c(y) {
    return n.parser.lazy[n.now().line] = r !== t.length, o = n.now().offset, g(y);
  }
  function h(y) {
    return n.containerState = {}, e.attempt(ri, f, g)(y);
  }
  function f(y) {
    return r++, t.push([n.currentConstruct, n.containerState]), h(y);
  }
  function g(y) {
    if (y === null) {
      i && k(), w(0), e.consume(y);
      return;
    }
    return i = i || n.parser.flow(n.now()), e.enter("chunkFlow", {
      _tokenizer: i,
      contentType: "flow",
      previous: l
    }), v(y);
  }
  function v(y) {
    if (y === null) {
      A(e.exit("chunkFlow"), !0), w(0), e.consume(y);
      return;
    }
    return F(y) ? (e.consume(y), A(e.exit("chunkFlow")), r = 0, n.interrupt = void 0, a) : (e.consume(y), v);
  }
  function A(y, E) {
    const S = n.sliceStream(y);
    if (E && S.push(null), y.previous = l, l && (l.next = y), l = y, i.defineSkip(y.start), i.write(S), n.parser.lazy[y.start.line]) {
      let m = i.events.length;
      for (; m--; )
        if (
          // The token starts before the line ending…
          i.events[m][1].start.offset < o && // …and either is not ended yet…
          (!i.events[m][1].end || // …or ends after it.
          i.events[m][1].end.offset > o)
        )
          return;
      const I = n.events.length;
      let N = I, T, x;
      for (; N--; )
        if (n.events[N][0] === "exit" && n.events[N][1].type === "chunkFlow") {
          if (T) {
            x = n.events[N][1].end;
            break;
          }
          T = !0;
        }
      for (w(r), m = I; m < n.events.length; )
        n.events[m][1].end = {
          ...x
        }, m++;
      be(n.events, N + 1, 0, n.events.slice(I)), n.events.length = m;
    }
  }
  function w(y) {
    let E = t.length;
    for (; E-- > y; ) {
      const S = t[E];
      n.containerState = S[1], S[0].exit.call(n, e);
    }
    t.length = y;
  }
  function k() {
    i.write([null]), l = void 0, i = void 0, n.containerState._closeFlow = void 0;
  }
}
function mh(e, n, t) {
  return G(e, e.attempt(this.parser.constructs.document, n, t), "linePrefix", this.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4);
}
function Qe(e) {
  if (e === null || Q(e) || Ue(e))
    return 1;
  if (jn(e))
    return 2;
}
function Bn(e, n, t) {
  const r = [];
  let i = -1;
  for (; ++i < e.length; ) {
    const l = e[i].resolveAll;
    l && !r.includes(l) && (n = l(n, t), r.push(l));
  }
  return n;
}
const kt = {
  name: "attention",
  resolveAll: bh,
  tokenize: yh
};
function bh(e, n) {
  let t = -1, r, i, l, o, a, s, u, p;
  for (; ++t < e.length; )
    if (e[t][0] === "enter" && e[t][1].type === "attentionSequence" && e[t][1]._close) {
      for (r = t; r--; )
        if (e[r][0] === "exit" && e[r][1].type === "attentionSequence" && e[r][1]._open && // If the markers are the same:
        n.sliceSerialize(e[r][1]).charCodeAt(0) === n.sliceSerialize(e[t][1]).charCodeAt(0)) {
          if ((e[r][1]._close || e[t][1]._open) && (e[t][1].end.offset - e[t][1].start.offset) % 3 && !((e[r][1].end.offset - e[r][1].start.offset + e[t][1].end.offset - e[t][1].start.offset) % 3))
            continue;
          s = e[r][1].end.offset - e[r][1].start.offset > 1 && e[t][1].end.offset - e[t][1].start.offset > 1 ? 2 : 1;
          const c = {
            ...e[r][1].end
          }, h = {
            ...e[t][1].start
          };
          ii(c, -s), ii(h, s), o = {
            type: s > 1 ? "strongSequence" : "emphasisSequence",
            start: c,
            end: {
              ...e[r][1].end
            }
          }, a = {
            type: s > 1 ? "strongSequence" : "emphasisSequence",
            start: {
              ...e[t][1].start
            },
            end: h
          }, l = {
            type: s > 1 ? "strongText" : "emphasisText",
            start: {
              ...e[r][1].end
            },
            end: {
              ...e[t][1].start
            }
          }, i = {
            type: s > 1 ? "strong" : "emphasis",
            start: {
              ...o.start
            },
            end: {
              ...a.end
            }
          }, e[r][1].end = {
            ...o.start
          }, e[t][1].start = {
            ...a.end
          }, u = [], e[r][1].end.offset - e[r][1].start.offset && (u = xe(u, [["enter", e[r][1], n], ["exit", e[r][1], n]])), u = xe(u, [["enter", i, n], ["enter", o, n], ["exit", o, n], ["enter", l, n]]), u = xe(u, Bn(n.parser.constructs.insideSpan.null, e.slice(r + 1, t), n)), u = xe(u, [["exit", l, n], ["enter", a, n], ["exit", a, n], ["exit", i, n]]), e[t][1].end.offset - e[t][1].start.offset ? (p = 2, u = xe(u, [["enter", e[t][1], n], ["exit", e[t][1], n]])) : p = 0, be(e, r - 1, t - r + 3, u), t = r + u.length - p - 2;
          break;
        }
    }
  for (t = -1; ++t < e.length; )
    e[t][1].type === "attentionSequence" && (e[t][1].type = "data");
  return e;
}
function yh(e, n) {
  const t = this.parser.constructs.attentionMarkers.null, r = this.previous, i = Qe(r);
  let l;
  return o;
  function o(s) {
    return l = s, e.enter("attentionSequence"), a(s);
  }
  function a(s) {
    if (s === l)
      return e.consume(s), a;
    const u = e.exit("attentionSequence"), p = Qe(s), c = !p || p === 2 && i || t.includes(s), h = !i || i === 2 && p || t.includes(r);
    return u._open = !!(l === 42 ? c : c && (i || !h)), u._close = !!(l === 42 ? h : h && (p || !c)), n(s);
  }
}
function ii(e, n) {
  e.column += n, e.offset += n, e._bufferIndex += n;
}
const kh = {
  name: "autolink",
  tokenize: xh
};
function xh(e, n, t) {
  let r = 0;
  return i;
  function i(f) {
    return e.enter("autolink"), e.enter("autolinkMarker"), e.consume(f), e.exit("autolinkMarker"), e.enter("autolinkProtocol"), l;
  }
  function l(f) {
    return ce(f) ? (e.consume(f), o) : f === 64 ? t(f) : u(f);
  }
  function o(f) {
    return f === 43 || f === 45 || f === 46 || ae(f) ? (r = 1, a(f)) : u(f);
  }
  function a(f) {
    return f === 58 ? (e.consume(f), r = 0, s) : (f === 43 || f === 45 || f === 46 || ae(f)) && r++ < 32 ? (e.consume(f), a) : (r = 0, u(f));
  }
  function s(f) {
    return f === 62 ? (e.exit("autolinkProtocol"), e.enter("autolinkMarker"), e.consume(f), e.exit("autolinkMarker"), e.exit("autolink"), n) : f === null || f === 32 || f === 60 || _n(f) ? t(f) : (e.consume(f), s);
  }
  function u(f) {
    return f === 64 ? (e.consume(f), p) : uh(f) ? (e.consume(f), u) : t(f);
  }
  function p(f) {
    return ae(f) ? c(f) : t(f);
  }
  function c(f) {
    return f === 46 ? (e.consume(f), r = 0, p) : f === 62 ? (e.exit("autolinkProtocol").type = "autolinkEmail", e.enter("autolinkMarker"), e.consume(f), e.exit("autolinkMarker"), e.exit("autolink"), n) : h(f);
  }
  function h(f) {
    if ((f === 45 || ae(f)) && r++ < 63) {
      const g = f === 45 ? h : c;
      return e.consume(f), g;
    }
    return t(f);
  }
}
const wn = {
  partial: !0,
  tokenize: wh
};
function wh(e, n, t) {
  return r;
  function r(l) {
    return H(l) ? G(e, i, "linePrefix")(l) : i(l);
  }
  function i(l) {
    return l === null || F(l) ? n(l) : t(l);
  }
}
const Po = {
  continuation: {
    tokenize: Sh
  },
  exit: Eh,
  name: "blockQuote",
  tokenize: vh
};
function vh(e, n, t) {
  const r = this;
  return i;
  function i(o) {
    if (o === 62) {
      const a = r.containerState;
      return a.open || (e.enter("blockQuote", {
        _container: !0
      }), a.open = !0), e.enter("blockQuotePrefix"), e.enter("blockQuoteMarker"), e.consume(o), e.exit("blockQuoteMarker"), l;
    }
    return t(o);
  }
  function l(o) {
    return H(o) ? (e.enter("blockQuotePrefixWhitespace"), e.consume(o), e.exit("blockQuotePrefixWhitespace"), e.exit("blockQuotePrefix"), n) : (e.exit("blockQuotePrefix"), n(o));
  }
}
function Sh(e, n, t) {
  const r = this;
  return i;
  function i(o) {
    return H(o) ? G(e, l, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(o) : l(o);
  }
  function l(o) {
    return e.attempt(Po, n, t)(o);
  }
}
function Eh(e) {
  e.exit("blockQuote");
}
const zo = {
  name: "characterEscape",
  tokenize: Ch
};
function Ch(e, n, t) {
  return r;
  function r(l) {
    return e.enter("characterEscape"), e.enter("escapeMarker"), e.consume(l), e.exit("escapeMarker"), i;
  }
  function i(l) {
    return ph(l) ? (e.enter("characterEscapeValue"), e.consume(l), e.exit("characterEscapeValue"), e.exit("characterEscape"), n) : t(l);
  }
}
const Mo = {
  name: "characterReference",
  tokenize: Ah
};
function Ah(e, n, t) {
  const r = this;
  let i = 0, l, o;
  return a;
  function a(c) {
    return e.enter("characterReference"), e.enter("characterReferenceMarker"), e.consume(c), e.exit("characterReferenceMarker"), s;
  }
  function s(c) {
    return c === 35 ? (e.enter("characterReferenceMarkerNumeric"), e.consume(c), e.exit("characterReferenceMarkerNumeric"), u) : (e.enter("characterReferenceValue"), l = 31, o = ae, p(c));
  }
  function u(c) {
    return c === 88 || c === 120 ? (e.enter("characterReferenceMarkerHexadecimal"), e.consume(c), e.exit("characterReferenceMarkerHexadecimal"), e.enter("characterReferenceValue"), l = 6, o = ch, p) : (e.enter("characterReferenceValue"), l = 7, o = yt, p(c));
  }
  function p(c) {
    if (c === 59 && i) {
      const h = e.exit("characterReferenceValue");
      return o === ae && !or(r.sliceSerialize(h)) ? t(c) : (e.enter("characterReferenceMarker"), e.consume(c), e.exit("characterReferenceMarker"), e.exit("characterReference"), n);
    }
    return o(c) && i++ < l ? (e.consume(c), p) : t(c);
  }
}
const oi = {
  partial: !0,
  tokenize: Ih
}, li = {
  concrete: !0,
  name: "codeFenced",
  tokenize: Th
};
function Th(e, n, t) {
  const r = this, i = {
    partial: !0,
    tokenize: S
  };
  let l = 0, o = 0, a;
  return s;
  function s(m) {
    return u(m);
  }
  function u(m) {
    const I = r.events[r.events.length - 1];
    return l = I && I[1].type === "linePrefix" ? I[2].sliceSerialize(I[1], !0).length : 0, a = m, e.enter("codeFenced"), e.enter("codeFencedFence"), e.enter("codeFencedFenceSequence"), p(m);
  }
  function p(m) {
    return m === a ? (o++, e.consume(m), p) : o < 3 ? t(m) : (e.exit("codeFencedFenceSequence"), H(m) ? G(e, c, "whitespace")(m) : c(m));
  }
  function c(m) {
    return m === null || F(m) ? (e.exit("codeFencedFence"), r.interrupt ? n(m) : e.check(oi, v, E)(m)) : (e.enter("codeFencedFenceInfo"), e.enter("chunkString", {
      contentType: "string"
    }), h(m));
  }
  function h(m) {
    return m === null || F(m) ? (e.exit("chunkString"), e.exit("codeFencedFenceInfo"), c(m)) : H(m) ? (e.exit("chunkString"), e.exit("codeFencedFenceInfo"), G(e, f, "whitespace")(m)) : m === 96 && m === a ? t(m) : (e.consume(m), h);
  }
  function f(m) {
    return m === null || F(m) ? c(m) : (e.enter("codeFencedFenceMeta"), e.enter("chunkString", {
      contentType: "string"
    }), g(m));
  }
  function g(m) {
    return m === null || F(m) ? (e.exit("chunkString"), e.exit("codeFencedFenceMeta"), c(m)) : m === 96 && m === a ? t(m) : (e.consume(m), g);
  }
  function v(m) {
    return e.attempt(i, E, A)(m);
  }
  function A(m) {
    return e.enter("lineEnding"), e.consume(m), e.exit("lineEnding"), w;
  }
  function w(m) {
    return l > 0 && H(m) ? G(e, k, "linePrefix", l + 1)(m) : k(m);
  }
  function k(m) {
    return m === null || F(m) ? e.check(oi, v, E)(m) : (e.enter("codeFlowValue"), y(m));
  }
  function y(m) {
    return m === null || F(m) ? (e.exit("codeFlowValue"), k(m)) : (e.consume(m), y);
  }
  function E(m) {
    return e.exit("codeFenced"), n(m);
  }
  function S(m, I, N) {
    let T = 0;
    return x;
    function x(D) {
      return m.enter("lineEnding"), m.consume(D), m.exit("lineEnding"), L;
    }
    function L(D) {
      return m.enter("codeFencedFence"), H(D) ? G(m, _, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(D) : _(D);
    }
    function _(D) {
      return D === a ? (m.enter("codeFencedFenceSequence"), P(D)) : N(D);
    }
    function P(D) {
      return D === a ? (T++, m.consume(D), P) : T >= o ? (m.exit("codeFencedFenceSequence"), H(D) ? G(m, j, "whitespace")(D) : j(D)) : N(D);
    }
    function j(D) {
      return D === null || F(D) ? (m.exit("codeFencedFence"), I(D)) : N(D);
    }
  }
}
function Ih(e, n, t) {
  const r = this;
  return i;
  function i(o) {
    return o === null ? t(o) : (e.enter("lineEnding"), e.consume(o), e.exit("lineEnding"), l);
  }
  function l(o) {
    return r.parser.lazy[r.now().line] ? t(o) : n(o);
  }
}
const Xn = {
  name: "codeIndented",
  tokenize: Lh
}, Oh = {
  partial: !0,
  tokenize: Rh
};
function Lh(e, n, t) {
  const r = this;
  return i;
  function i(u) {
    return e.enter("codeIndented"), G(e, l, "linePrefix", 5)(u);
  }
  function l(u) {
    const p = r.events[r.events.length - 1];
    return p && p[1].type === "linePrefix" && p[2].sliceSerialize(p[1], !0).length >= 4 ? o(u) : t(u);
  }
  function o(u) {
    return u === null ? s(u) : F(u) ? e.attempt(Oh, o, s)(u) : (e.enter("codeFlowValue"), a(u));
  }
  function a(u) {
    return u === null || F(u) ? (e.exit("codeFlowValue"), o(u)) : (e.consume(u), a);
  }
  function s(u) {
    return e.exit("codeIndented"), n(u);
  }
}
function Rh(e, n, t) {
  const r = this;
  return i;
  function i(o) {
    return r.parser.lazy[r.now().line] ? t(o) : F(o) ? (e.enter("lineEnding"), e.consume(o), e.exit("lineEnding"), i) : G(e, l, "linePrefix", 5)(o);
  }
  function l(o) {
    const a = r.events[r.events.length - 1];
    return a && a[1].type === "linePrefix" && a[2].sliceSerialize(a[1], !0).length >= 4 ? n(o) : F(o) ? i(o) : t(o);
  }
}
const Nh = {
  name: "codeText",
  previous: Fh,
  resolve: _h,
  tokenize: Dh
};
function _h(e) {
  let n = e.length - 4, t = 3, r, i;
  if ((e[t][1].type === "lineEnding" || e[t][1].type === "space") && (e[n][1].type === "lineEnding" || e[n][1].type === "space")) {
    for (r = t; ++r < n; )
      if (e[r][1].type === "codeTextData") {
        e[t][1].type = "codeTextPadding", e[n][1].type = "codeTextPadding", t += 2, n -= 2;
        break;
      }
  }
  for (r = t - 1, n++; ++r <= n; )
    i === void 0 ? r !== n && e[r][1].type !== "lineEnding" && (i = r) : (r === n || e[r][1].type === "lineEnding") && (e[i][1].type = "codeTextData", r !== i + 2 && (e[i][1].end = e[r - 1][1].end, e.splice(i + 2, r - i - 2), n -= r - i - 2, r = i + 2), i = void 0);
  return e;
}
function Fh(e) {
  return e !== 96 || this.events[this.events.length - 1][1].type === "characterEscape";
}
function Dh(e, n, t) {
  let r = 0, i, l;
  return o;
  function o(c) {
    return e.enter("codeText"), e.enter("codeTextSequence"), a(c);
  }
  function a(c) {
    return c === 96 ? (e.consume(c), r++, a) : (e.exit("codeTextSequence"), s(c));
  }
  function s(c) {
    return c === null ? t(c) : c === 32 ? (e.enter("space"), e.consume(c), e.exit("space"), s) : c === 96 ? (l = e.enter("codeTextSequence"), i = 0, p(c)) : F(c) ? (e.enter("lineEnding"), e.consume(c), e.exit("lineEnding"), s) : (e.enter("codeTextData"), u(c));
  }
  function u(c) {
    return c === null || c === 32 || c === 96 || F(c) ? (e.exit("codeTextData"), s(c)) : (e.consume(c), u);
  }
  function p(c) {
    return c === 96 ? (e.consume(c), i++, p) : i === r ? (e.exit("codeTextSequence"), e.exit("codeText"), n(c)) : (l.type = "codeTextData", u(c));
  }
}
class Ph {
  /**
   * @param {ReadonlyArray<T> | null | undefined} [initial]
   *   Initial items (optional).
   * @returns
   *   Splice buffer.
   */
  constructor(n) {
    this.left = n ? [...n] : [], this.right = [];
  }
  /**
   * Array access;
   * does not move the cursor.
   *
   * @param {number} index
   *   Index.
   * @return {T}
   *   Item.
   */
  get(n) {
    if (n < 0 || n >= this.left.length + this.right.length)
      throw new RangeError("Cannot access index `" + n + "` in a splice buffer of size `" + (this.left.length + this.right.length) + "`");
    return n < this.left.length ? this.left[n] : this.right[this.right.length - n + this.left.length - 1];
  }
  /**
   * The length of the splice buffer, one greater than the largest index in the
   * array.
   */
  get length() {
    return this.left.length + this.right.length;
  }
  /**
   * Remove and return `list[0]`;
   * moves the cursor to `0`.
   *
   * @returns {T | undefined}
   *   Item, optional.
   */
  shift() {
    return this.setCursor(0), this.right.pop();
  }
  /**
   * Slice the buffer to get an array;
   * does not move the cursor.
   *
   * @param {number} start
   *   Start.
   * @param {number | null | undefined} [end]
   *   End (optional).
   * @returns {Array<T>}
   *   Array of items.
   */
  slice(n, t) {
    const r = t ?? Number.POSITIVE_INFINITY;
    return r < this.left.length ? this.left.slice(n, r) : n > this.left.length ? this.right.slice(this.right.length - r + this.left.length, this.right.length - n + this.left.length).reverse() : this.left.slice(n).concat(this.right.slice(this.right.length - r + this.left.length).reverse());
  }
  /**
   * Mimics the behavior of Array.prototype.splice() except for the change of
   * interface necessary to avoid segfaults when patching in very large arrays.
   *
   * This operation moves cursor is moved to `start` and results in the cursor
   * placed after any inserted items.
   *
   * @param {number} start
   *   Start;
   *   zero-based index at which to start changing the array;
   *   negative numbers count backwards from the end of the array and values
   *   that are out-of bounds are clamped to the appropriate end of the array.
   * @param {number | null | undefined} [deleteCount=0]
   *   Delete count (default: `0`);
   *   maximum number of elements to delete, starting from start.
   * @param {Array<T> | null | undefined} [items=[]]
   *   Items to include in place of the deleted items (default: `[]`).
   * @return {Array<T>}
   *   Any removed items.
   */
  splice(n, t, r) {
    const i = t || 0;
    this.setCursor(Math.trunc(n));
    const l = this.right.splice(this.right.length - i, Number.POSITIVE_INFINITY);
    return r && an(this.left, r), l.reverse();
  }
  /**
   * Remove and return the highest-numbered item in the array, so
   * `list[list.length - 1]`;
   * Moves the cursor to `length`.
   *
   * @returns {T | undefined}
   *   Item, optional.
   */
  pop() {
    return this.setCursor(Number.POSITIVE_INFINITY), this.left.pop();
  }
  /**
   * Inserts a single item to the high-numbered side of the array;
   * moves the cursor to `length`.
   *
   * @param {T} item
   *   Item.
   * @returns {undefined}
   *   Nothing.
   */
  push(n) {
    this.setCursor(Number.POSITIVE_INFINITY), this.left.push(n);
  }
  /**
   * Inserts many items to the high-numbered side of the array.
   * Moves the cursor to `length`.
   *
   * @param {Array<T>} items
   *   Items.
   * @returns {undefined}
   *   Nothing.
   */
  pushMany(n) {
    this.setCursor(Number.POSITIVE_INFINITY), an(this.left, n);
  }
  /**
   * Inserts a single item to the low-numbered side of the array;
   * Moves the cursor to `0`.
   *
   * @param {T} item
   *   Item.
   * @returns {undefined}
   *   Nothing.
   */
  unshift(n) {
    this.setCursor(0), this.right.push(n);
  }
  /**
   * Inserts many items to the low-numbered side of the array;
   * moves the cursor to `0`.
   *
   * @param {Array<T>} items
   *   Items.
   * @returns {undefined}
   *   Nothing.
   */
  unshiftMany(n) {
    this.setCursor(0), an(this.right, n.reverse());
  }
  /**
   * Move the cursor to a specific position in the array. Requires
   * time proportional to the distance moved.
   *
   * If `n < 0`, the cursor will end up at the beginning.
   * If `n > length`, the cursor will end up at the end.
   *
   * @param {number} n
   *   Position.
   * @return {undefined}
   *   Nothing.
   */
  setCursor(n) {
    if (!(n === this.left.length || n > this.left.length && this.right.length === 0 || n < 0 && this.left.length === 0))
      if (n < this.left.length) {
        const t = this.left.splice(n, Number.POSITIVE_INFINITY);
        an(this.right, t.reverse());
      } else {
        const t = this.right.splice(this.left.length + this.right.length - n, Number.POSITIVE_INFINITY);
        an(this.left, t.reverse());
      }
  }
}
function an(e, n) {
  let t = 0;
  if (n.length < 1e4)
    e.push(...n);
  else
    for (; t < n.length; )
      e.push(...n.slice(t, t + 1e4)), t += 1e4;
}
function $o(e) {
  const n = {};
  let t = -1, r, i, l, o, a, s, u;
  const p = new Ph(e);
  for (; ++t < p.length; ) {
    for (; t in n; )
      t = n[t];
    if (r = p.get(t), t && r[1].type === "chunkFlow" && p.get(t - 1)[1].type === "listItemPrefix" && (s = r[1]._tokenizer.events, l = 0, l < s.length && s[l][1].type === "lineEndingBlank" && (l += 2), l < s.length && s[l][1].type === "content"))
      for (; ++l < s.length && s[l][1].type !== "content"; )
        s[l][1].type === "chunkText" && (s[l][1]._isInFirstContentOfListItem = !0, l++);
    if (r[0] === "enter")
      r[1].contentType && (Object.assign(n, zh(p, t)), t = n[t], u = !0);
    else if (r[1]._container) {
      for (l = t, i = void 0; l--; )
        if (o = p.get(l), o[1].type === "lineEnding" || o[1].type === "lineEndingBlank")
          o[0] === "enter" && (i && (p.get(i)[1].type = "lineEndingBlank"), o[1].type = "lineEnding", i = l);
        else if (!(o[1].type === "linePrefix" || o[1].type === "listItemIndent")) break;
      i && (r[1].end = {
        ...p.get(i)[1].start
      }, a = p.slice(i, t), a.unshift(r), p.splice(i, t - i + 1, a));
    }
  }
  return be(e, 0, Number.POSITIVE_INFINITY, p.slice(0)), !u;
}
function zh(e, n) {
  const t = e.get(n)[1], r = e.get(n)[2];
  let i = n - 1;
  const l = [];
  let o = t._tokenizer;
  o || (o = r.parser[t.contentType](t.start), t._contentTypeTextTrailing && (o._contentTypeTextTrailing = !0));
  const a = o.events, s = [], u = {};
  let p, c, h = -1, f = t, g = 0, v = 0;
  const A = [v];
  for (; f; ) {
    for (; e.get(++i)[1] !== f; )
      ;
    l.push(i), f._tokenizer || (p = r.sliceStream(f), f.next || p.push(null), c && o.defineSkip(f.start), f._isInFirstContentOfListItem && (o._gfmTasklistFirstContentOfListItem = !0), o.write(p), f._isInFirstContentOfListItem && (o._gfmTasklistFirstContentOfListItem = void 0)), c = f, f = f.next;
  }
  for (f = t; ++h < a.length; )
    // Find a void token that includes a break.
    a[h][0] === "exit" && a[h - 1][0] === "enter" && a[h][1].type === a[h - 1][1].type && a[h][1].start.line !== a[h][1].end.line && (v = h + 1, A.push(v), f._tokenizer = void 0, f.previous = void 0, f = f.next);
  for (o.events = [], f ? (f._tokenizer = void 0, f.previous = void 0) : A.pop(), h = A.length; h--; ) {
    const w = a.slice(A[h], A[h + 1]), k = l.pop();
    s.push([k, k + w.length - 1]), e.splice(k, 2, w);
  }
  for (s.reverse(), h = -1; ++h < s.length; )
    u[g + s[h][0]] = g + s[h][1], g += s[h][1] - s[h][0] - 1;
  return u;
}
const Mh = {
  resolve: jh,
  tokenize: Bh
}, $h = {
  partial: !0,
  tokenize: Uh
};
function jh(e) {
  return $o(e), e;
}
function Bh(e, n) {
  let t;
  return r;
  function r(a) {
    return e.enter("content"), t = e.enter("chunkContent", {
      contentType: "content"
    }), i(a);
  }
  function i(a) {
    return a === null ? l(a) : F(a) ? e.check($h, o, l)(a) : (e.consume(a), i);
  }
  function l(a) {
    return e.exit("chunkContent"), e.exit("content"), n(a);
  }
  function o(a) {
    return e.consume(a), e.exit("chunkContent"), t.next = e.enter("chunkContent", {
      contentType: "content",
      previous: t
    }), t = t.next, i;
  }
}
function Uh(e, n, t) {
  const r = this;
  return i;
  function i(o) {
    return e.exit("chunkContent"), e.enter("lineEnding"), e.consume(o), e.exit("lineEnding"), G(e, l, "linePrefix");
  }
  function l(o) {
    if (o === null || F(o))
      return t(o);
    const a = r.events[r.events.length - 1];
    return !r.parser.constructs.disable.null.includes("codeIndented") && a && a[1].type === "linePrefix" && a[2].sliceSerialize(a[1], !0).length >= 4 ? n(o) : e.interrupt(r.parser.constructs.flow, t, n)(o);
  }
}
function jo(e, n, t, r, i, l, o, a, s) {
  const u = s || Number.POSITIVE_INFINITY;
  let p = 0;
  return c;
  function c(w) {
    return w === 60 ? (e.enter(r), e.enter(i), e.enter(l), e.consume(w), e.exit(l), h) : w === null || w === 32 || w === 41 || _n(w) ? t(w) : (e.enter(r), e.enter(o), e.enter(a), e.enter("chunkString", {
      contentType: "string"
    }), v(w));
  }
  function h(w) {
    return w === 62 ? (e.enter(l), e.consume(w), e.exit(l), e.exit(i), e.exit(r), n) : (e.enter(a), e.enter("chunkString", {
      contentType: "string"
    }), f(w));
  }
  function f(w) {
    return w === 62 ? (e.exit("chunkString"), e.exit(a), h(w)) : w === null || w === 60 || F(w) ? t(w) : (e.consume(w), w === 92 ? g : f);
  }
  function g(w) {
    return w === 60 || w === 62 || w === 92 ? (e.consume(w), f) : f(w);
  }
  function v(w) {
    return !p && (w === null || w === 41 || Q(w)) ? (e.exit("chunkString"), e.exit(a), e.exit(o), e.exit(r), n(w)) : p < u && w === 40 ? (e.consume(w), p++, v) : w === 41 ? (e.consume(w), p--, v) : w === null || w === 32 || w === 40 || _n(w) ? t(w) : (e.consume(w), w === 92 ? A : v);
  }
  function A(w) {
    return w === 40 || w === 41 || w === 92 ? (e.consume(w), v) : v(w);
  }
}
function Bo(e, n, t, r, i, l) {
  const o = this;
  let a = 0, s;
  return u;
  function u(f) {
    return e.enter(r), e.enter(i), e.consume(f), e.exit(i), e.enter(l), p;
  }
  function p(f) {
    return a > 999 || f === null || f === 91 || f === 93 && !s || // To do: remove in the future once we’ve switched from
    // `micromark-extension-footnote` to `micromark-extension-gfm-footnote`,
    // which doesn’t need this.
    // Hidden footnotes hook.
    /* c8 ignore next 3 */
    f === 94 && !a && "_hiddenFootnoteSupport" in o.parser.constructs ? t(f) : f === 93 ? (e.exit(l), e.enter(i), e.consume(f), e.exit(i), e.exit(r), n) : F(f) ? (e.enter("lineEnding"), e.consume(f), e.exit("lineEnding"), p) : (e.enter("chunkString", {
      contentType: "string"
    }), c(f));
  }
  function c(f) {
    return f === null || f === 91 || f === 93 || F(f) || a++ > 999 ? (e.exit("chunkString"), p(f)) : (e.consume(f), s || (s = !H(f)), f === 92 ? h : c);
  }
  function h(f) {
    return f === 91 || f === 92 || f === 93 ? (e.consume(f), a++, c) : c(f);
  }
}
function Uo(e, n, t, r, i, l) {
  let o;
  return a;
  function a(h) {
    return h === 34 || h === 39 || h === 40 ? (e.enter(r), e.enter(i), e.consume(h), e.exit(i), o = h === 40 ? 41 : h, s) : t(h);
  }
  function s(h) {
    return h === o ? (e.enter(i), e.consume(h), e.exit(i), e.exit(r), n) : (e.enter(l), u(h));
  }
  function u(h) {
    return h === o ? (e.exit(l), s(o)) : h === null ? t(h) : F(h) ? (e.enter("lineEnding"), e.consume(h), e.exit("lineEnding"), G(e, u, "linePrefix")) : (e.enter("chunkString", {
      contentType: "string"
    }), p(h));
  }
  function p(h) {
    return h === o || h === null || F(h) ? (e.exit("chunkString"), u(h)) : (e.consume(h), h === 92 ? c : p);
  }
  function c(h) {
    return h === o || h === 92 ? (e.consume(h), p) : p(h);
  }
}
function hn(e, n) {
  let t;
  return r;
  function r(i) {
    return F(i) ? (e.enter("lineEnding"), e.consume(i), e.exit("lineEnding"), t = !0, r) : H(i) ? G(e, r, t ? "linePrefix" : "lineSuffix")(i) : n(i);
  }
}
const Hh = {
  name: "definition",
  tokenize: qh
}, Vh = {
  partial: !0,
  tokenize: Gh
};
function qh(e, n, t) {
  const r = this;
  let i;
  return l;
  function l(f) {
    return e.enter("definition"), o(f);
  }
  function o(f) {
    return Bo.call(
      r,
      e,
      a,
      // Note: we don’t need to reset the way `markdown-rs` does.
      t,
      "definitionLabel",
      "definitionLabelMarker",
      "definitionLabelString"
    )(f);
  }
  function a(f) {
    return i = Ce(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1)), f === 58 ? (e.enter("definitionMarker"), e.consume(f), e.exit("definitionMarker"), s) : t(f);
  }
  function s(f) {
    return Q(f) ? hn(e, u)(f) : u(f);
  }
  function u(f) {
    return jo(
      e,
      p,
      // Note: we don’t need to reset the way `markdown-rs` does.
      t,
      "definitionDestination",
      "definitionDestinationLiteral",
      "definitionDestinationLiteralMarker",
      "definitionDestinationRaw",
      "definitionDestinationString"
    )(f);
  }
  function p(f) {
    return e.attempt(Vh, c, c)(f);
  }
  function c(f) {
    return H(f) ? G(e, h, "whitespace")(f) : h(f);
  }
  function h(f) {
    return f === null || F(f) ? (e.exit("definition"), r.parser.defined.push(i), n(f)) : t(f);
  }
}
function Gh(e, n, t) {
  return r;
  function r(a) {
    return Q(a) ? hn(e, i)(a) : t(a);
  }
  function i(a) {
    return Uo(e, l, t, "definitionTitle", "definitionTitleMarker", "definitionTitleString")(a);
  }
  function l(a) {
    return H(a) ? G(e, o, "whitespace")(a) : o(a);
  }
  function o(a) {
    return a === null || F(a) ? n(a) : t(a);
  }
}
const Wh = {
  name: "hardBreakEscape",
  tokenize: Yh
};
function Yh(e, n, t) {
  return r;
  function r(l) {
    return e.enter("hardBreakEscape"), e.consume(l), i;
  }
  function i(l) {
    return F(l) ? (e.exit("hardBreakEscape"), n(l)) : t(l);
  }
}
const Xh = {
  name: "headingAtx",
  resolve: Kh,
  tokenize: Zh
};
function Kh(e, n) {
  let t = e.length - 2, r = 3, i, l;
  return e[r][1].type === "whitespace" && (r += 2), t - 2 > r && e[t][1].type === "whitespace" && (t -= 2), e[t][1].type === "atxHeadingSequence" && (r === t - 1 || t - 4 > r && e[t - 2][1].type === "whitespace") && (t -= r + 1 === t ? 2 : 4), t > r && (i = {
    type: "atxHeadingText",
    start: e[r][1].start,
    end: e[t][1].end
  }, l = {
    type: "chunkText",
    start: e[r][1].start,
    end: e[t][1].end,
    contentType: "text"
  }, be(e, r, t - r + 1, [["enter", i, n], ["enter", l, n], ["exit", l, n], ["exit", i, n]])), e;
}
function Zh(e, n, t) {
  let r = 0;
  return i;
  function i(p) {
    return e.enter("atxHeading"), l(p);
  }
  function l(p) {
    return e.enter("atxHeadingSequence"), o(p);
  }
  function o(p) {
    return p === 35 && r++ < 6 ? (e.consume(p), o) : p === null || Q(p) ? (e.exit("atxHeadingSequence"), a(p)) : t(p);
  }
  function a(p) {
    return p === 35 ? (e.enter("atxHeadingSequence"), s(p)) : p === null || F(p) ? (e.exit("atxHeading"), n(p)) : H(p) ? G(e, a, "whitespace")(p) : (e.enter("atxHeadingText"), u(p));
  }
  function s(p) {
    return p === 35 ? (e.consume(p), s) : (e.exit("atxHeadingSequence"), a(p));
  }
  function u(p) {
    return p === null || p === 35 || Q(p) ? (e.exit("atxHeadingText"), a(p)) : (e.consume(p), u);
  }
}
const Qh = [
  "address",
  "article",
  "aside",
  "base",
  "basefont",
  "blockquote",
  "body",
  "caption",
  "center",
  "col",
  "colgroup",
  "dd",
  "details",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "fieldset",
  "figcaption",
  "figure",
  "footer",
  "form",
  "frame",
  "frameset",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hr",
  "html",
  "iframe",
  "legend",
  "li",
  "link",
  "main",
  "menu",
  "menuitem",
  "nav",
  "noframes",
  "ol",
  "optgroup",
  "option",
  "p",
  "param",
  "search",
  "section",
  "summary",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "title",
  "tr",
  "track",
  "ul"
], ai = ["pre", "script", "style", "textarea"], Jh = {
  concrete: !0,
  name: "htmlFlow",
  resolveTo: td,
  tokenize: rd
}, ed = {
  partial: !0,
  tokenize: od
}, nd = {
  partial: !0,
  tokenize: id
};
function td(e) {
  let n = e.length;
  for (; n-- && !(e[n][0] === "enter" && e[n][1].type === "htmlFlow"); )
    ;
  return n > 1 && e[n - 2][1].type === "linePrefix" && (e[n][1].start = e[n - 2][1].start, e[n + 1][1].start = e[n - 2][1].start, e.splice(n - 2, 2)), e;
}
function rd(e, n, t) {
  const r = this;
  let i, l, o, a, s;
  return u;
  function u(b) {
    return p(b);
  }
  function p(b) {
    return e.enter("htmlFlow"), e.enter("htmlFlowData"), e.consume(b), c;
  }
  function c(b) {
    return b === 33 ? (e.consume(b), h) : b === 47 ? (e.consume(b), l = !0, v) : b === 63 ? (e.consume(b), i = 3, r.interrupt ? n : d) : ce(b) ? (e.consume(b), o = String.fromCharCode(b), A) : t(b);
  }
  function h(b) {
    return b === 45 ? (e.consume(b), i = 2, f) : b === 91 ? (e.consume(b), i = 5, a = 0, g) : ce(b) ? (e.consume(b), i = 4, r.interrupt ? n : d) : t(b);
  }
  function f(b) {
    return b === 45 ? (e.consume(b), r.interrupt ? n : d) : t(b);
  }
  function g(b) {
    const ee = "CDATA[";
    return b === ee.charCodeAt(a++) ? (e.consume(b), a === ee.length ? r.interrupt ? n : _ : g) : t(b);
  }
  function v(b) {
    return ce(b) ? (e.consume(b), o = String.fromCharCode(b), A) : t(b);
  }
  function A(b) {
    if (b === null || b === 47 || b === 62 || Q(b)) {
      const ee = b === 47, ie = o.toLowerCase();
      return !ee && !l && ai.includes(ie) ? (i = 1, r.interrupt ? n(b) : _(b)) : Qh.includes(o.toLowerCase()) ? (i = 6, ee ? (e.consume(b), w) : r.interrupt ? n(b) : _(b)) : (i = 7, r.interrupt && !r.parser.lazy[r.now().line] ? t(b) : l ? k(b) : y(b));
    }
    return b === 45 || ae(b) ? (e.consume(b), o += String.fromCharCode(b), A) : t(b);
  }
  function w(b) {
    return b === 62 ? (e.consume(b), r.interrupt ? n : _) : t(b);
  }
  function k(b) {
    return H(b) ? (e.consume(b), k) : x(b);
  }
  function y(b) {
    return b === 47 ? (e.consume(b), x) : b === 58 || b === 95 || ce(b) ? (e.consume(b), E) : H(b) ? (e.consume(b), y) : x(b);
  }
  function E(b) {
    return b === 45 || b === 46 || b === 58 || b === 95 || ae(b) ? (e.consume(b), E) : S(b);
  }
  function S(b) {
    return b === 61 ? (e.consume(b), m) : H(b) ? (e.consume(b), S) : y(b);
  }
  function m(b) {
    return b === null || b === 60 || b === 61 || b === 62 || b === 96 ? t(b) : b === 34 || b === 39 ? (e.consume(b), s = b, I) : H(b) ? (e.consume(b), m) : N(b);
  }
  function I(b) {
    return b === s ? (e.consume(b), s = null, T) : b === null || F(b) ? t(b) : (e.consume(b), I);
  }
  function N(b) {
    return b === null || b === 34 || b === 39 || b === 47 || b === 60 || b === 61 || b === 62 || b === 96 || Q(b) ? S(b) : (e.consume(b), N);
  }
  function T(b) {
    return b === 47 || b === 62 || H(b) ? y(b) : t(b);
  }
  function x(b) {
    return b === 62 ? (e.consume(b), L) : t(b);
  }
  function L(b) {
    return b === null || F(b) ? _(b) : H(b) ? (e.consume(b), L) : t(b);
  }
  function _(b) {
    return b === 45 && i === 2 ? (e.consume(b), W) : b === 60 && i === 1 ? (e.consume(b), X) : b === 62 && i === 4 ? (e.consume(b), z) : b === 63 && i === 3 ? (e.consume(b), d) : b === 93 && i === 5 ? (e.consume(b), Y) : F(b) && (i === 6 || i === 7) ? (e.exit("htmlFlowData"), e.check(ed, q, P)(b)) : b === null || F(b) ? (e.exit("htmlFlowData"), P(b)) : (e.consume(b), _);
  }
  function P(b) {
    return e.check(nd, j, q)(b);
  }
  function j(b) {
    return e.enter("lineEnding"), e.consume(b), e.exit("lineEnding"), D;
  }
  function D(b) {
    return b === null || F(b) ? P(b) : (e.enter("htmlFlowData"), _(b));
  }
  function W(b) {
    return b === 45 ? (e.consume(b), d) : _(b);
  }
  function X(b) {
    return b === 47 ? (e.consume(b), o = "", B) : _(b);
  }
  function B(b) {
    if (b === 62) {
      const ee = o.toLowerCase();
      return ai.includes(ee) ? (e.consume(b), z) : _(b);
    }
    return ce(b) && o.length < 8 ? (e.consume(b), o += String.fromCharCode(b), B) : _(b);
  }
  function Y(b) {
    return b === 93 ? (e.consume(b), d) : _(b);
  }
  function d(b) {
    return b === 62 ? (e.consume(b), z) : b === 45 && i === 2 ? (e.consume(b), d) : _(b);
  }
  function z(b) {
    return b === null || F(b) ? (e.exit("htmlFlowData"), q(b)) : (e.consume(b), z);
  }
  function q(b) {
    return e.exit("htmlFlow"), n(b);
  }
}
function id(e, n, t) {
  const r = this;
  return i;
  function i(o) {
    return F(o) ? (e.enter("lineEnding"), e.consume(o), e.exit("lineEnding"), l) : t(o);
  }
  function l(o) {
    return r.parser.lazy[r.now().line] ? t(o) : n(o);
  }
}
function od(e, n, t) {
  return r;
  function r(i) {
    return e.enter("lineEnding"), e.consume(i), e.exit("lineEnding"), e.attempt(wn, n, t);
  }
}
const ld = {
  name: "htmlText",
  tokenize: ad
};
function ad(e, n, t) {
  const r = this;
  let i, l, o;
  return a;
  function a(d) {
    return e.enter("htmlText"), e.enter("htmlTextData"), e.consume(d), s;
  }
  function s(d) {
    return d === 33 ? (e.consume(d), u) : d === 47 ? (e.consume(d), S) : d === 63 ? (e.consume(d), y) : ce(d) ? (e.consume(d), N) : t(d);
  }
  function u(d) {
    return d === 45 ? (e.consume(d), p) : d === 91 ? (e.consume(d), l = 0, g) : ce(d) ? (e.consume(d), k) : t(d);
  }
  function p(d) {
    return d === 45 ? (e.consume(d), f) : t(d);
  }
  function c(d) {
    return d === null ? t(d) : d === 45 ? (e.consume(d), h) : F(d) ? (o = c, X(d)) : (e.consume(d), c);
  }
  function h(d) {
    return d === 45 ? (e.consume(d), f) : c(d);
  }
  function f(d) {
    return d === 62 ? W(d) : d === 45 ? h(d) : c(d);
  }
  function g(d) {
    const z = "CDATA[";
    return d === z.charCodeAt(l++) ? (e.consume(d), l === z.length ? v : g) : t(d);
  }
  function v(d) {
    return d === null ? t(d) : d === 93 ? (e.consume(d), A) : F(d) ? (o = v, X(d)) : (e.consume(d), v);
  }
  function A(d) {
    return d === 93 ? (e.consume(d), w) : v(d);
  }
  function w(d) {
    return d === 62 ? W(d) : d === 93 ? (e.consume(d), w) : v(d);
  }
  function k(d) {
    return d === null || d === 62 ? W(d) : F(d) ? (o = k, X(d)) : (e.consume(d), k);
  }
  function y(d) {
    return d === null ? t(d) : d === 63 ? (e.consume(d), E) : F(d) ? (o = y, X(d)) : (e.consume(d), y);
  }
  function E(d) {
    return d === 62 ? W(d) : y(d);
  }
  function S(d) {
    return ce(d) ? (e.consume(d), m) : t(d);
  }
  function m(d) {
    return d === 45 || ae(d) ? (e.consume(d), m) : I(d);
  }
  function I(d) {
    return F(d) ? (o = I, X(d)) : H(d) ? (e.consume(d), I) : W(d);
  }
  function N(d) {
    return d === 45 || ae(d) ? (e.consume(d), N) : d === 47 || d === 62 || Q(d) ? T(d) : t(d);
  }
  function T(d) {
    return d === 47 ? (e.consume(d), W) : d === 58 || d === 95 || ce(d) ? (e.consume(d), x) : F(d) ? (o = T, X(d)) : H(d) ? (e.consume(d), T) : W(d);
  }
  function x(d) {
    return d === 45 || d === 46 || d === 58 || d === 95 || ae(d) ? (e.consume(d), x) : L(d);
  }
  function L(d) {
    return d === 61 ? (e.consume(d), _) : F(d) ? (o = L, X(d)) : H(d) ? (e.consume(d), L) : T(d);
  }
  function _(d) {
    return d === null || d === 60 || d === 61 || d === 62 || d === 96 ? t(d) : d === 34 || d === 39 ? (e.consume(d), i = d, P) : F(d) ? (o = _, X(d)) : H(d) ? (e.consume(d), _) : (e.consume(d), j);
  }
  function P(d) {
    return d === i ? (e.consume(d), i = void 0, D) : d === null ? t(d) : F(d) ? (o = P, X(d)) : (e.consume(d), P);
  }
  function j(d) {
    return d === null || d === 34 || d === 39 || d === 60 || d === 61 || d === 96 ? t(d) : d === 47 || d === 62 || Q(d) ? T(d) : (e.consume(d), j);
  }
  function D(d) {
    return d === 47 || d === 62 || Q(d) ? T(d) : t(d);
  }
  function W(d) {
    return d === 62 ? (e.consume(d), e.exit("htmlTextData"), e.exit("htmlText"), n) : t(d);
  }
  function X(d) {
    return e.exit("htmlTextData"), e.enter("lineEnding"), e.consume(d), e.exit("lineEnding"), B;
  }
  function B(d) {
    return H(d) ? G(e, Y, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(d) : Y(d);
  }
  function Y(d) {
    return e.enter("htmlTextData"), o(d);
  }
}
const lr = {
  name: "labelEnd",
  resolveAll: pd,
  resolveTo: fd,
  tokenize: hd
}, sd = {
  tokenize: dd
}, ud = {
  tokenize: gd
}, cd = {
  tokenize: md
};
function pd(e) {
  let n = -1;
  const t = [];
  for (; ++n < e.length; ) {
    const r = e[n][1];
    if (t.push(e[n]), r.type === "labelImage" || r.type === "labelLink" || r.type === "labelEnd") {
      const i = r.type === "labelImage" ? 4 : 2;
      r.type = "data", n += i;
    }
  }
  return e.length !== t.length && be(e, 0, e.length, t), e;
}
function fd(e, n) {
  let t = e.length, r = 0, i, l, o, a;
  for (; t--; )
    if (i = e[t][1], l) {
      if (i.type === "link" || i.type === "labelLink" && i._inactive)
        break;
      e[t][0] === "enter" && i.type === "labelLink" && (i._inactive = !0);
    } else if (o) {
      if (e[t][0] === "enter" && (i.type === "labelImage" || i.type === "labelLink") && !i._balanced && (l = t, i.type !== "labelLink")) {
        r = 2;
        break;
      }
    } else i.type === "labelEnd" && (o = t);
  const s = {
    type: e[l][1].type === "labelLink" ? "link" : "image",
    start: {
      ...e[l][1].start
    },
    end: {
      ...e[e.length - 1][1].end
    }
  }, u = {
    type: "label",
    start: {
      ...e[l][1].start
    },
    end: {
      ...e[o][1].end
    }
  }, p = {
    type: "labelText",
    start: {
      ...e[l + r + 2][1].end
    },
    end: {
      ...e[o - 2][1].start
    }
  };
  return a = [["enter", s, n], ["enter", u, n]], a = xe(a, e.slice(l + 1, l + r + 3)), a = xe(a, [["enter", p, n]]), a = xe(a, Bn(n.parser.constructs.insideSpan.null, e.slice(l + r + 4, o - 3), n)), a = xe(a, [["exit", p, n], e[o - 2], e[o - 1], ["exit", u, n]]), a = xe(a, e.slice(o + 1)), a = xe(a, [["exit", s, n]]), be(e, l, e.length, a), e;
}
function hd(e, n, t) {
  const r = this;
  let i = r.events.length, l, o;
  for (; i--; )
    if ((r.events[i][1].type === "labelImage" || r.events[i][1].type === "labelLink") && !r.events[i][1]._balanced) {
      l = r.events[i][1];
      break;
    }
  return a;
  function a(h) {
    return l ? l._inactive ? c(h) : (o = r.parser.defined.includes(Ce(r.sliceSerialize({
      start: l.end,
      end: r.now()
    }))), e.enter("labelEnd"), e.enter("labelMarker"), e.consume(h), e.exit("labelMarker"), e.exit("labelEnd"), s) : t(h);
  }
  function s(h) {
    return h === 40 ? e.attempt(sd, p, o ? p : c)(h) : h === 91 ? e.attempt(ud, p, o ? u : c)(h) : o ? p(h) : c(h);
  }
  function u(h) {
    return e.attempt(cd, p, c)(h);
  }
  function p(h) {
    return n(h);
  }
  function c(h) {
    return l._balanced = !0, t(h);
  }
}
function dd(e, n, t) {
  return r;
  function r(c) {
    return e.enter("resource"), e.enter("resourceMarker"), e.consume(c), e.exit("resourceMarker"), i;
  }
  function i(c) {
    return Q(c) ? hn(e, l)(c) : l(c);
  }
  function l(c) {
    return c === 41 ? p(c) : jo(e, o, a, "resourceDestination", "resourceDestinationLiteral", "resourceDestinationLiteralMarker", "resourceDestinationRaw", "resourceDestinationString", 32)(c);
  }
  function o(c) {
    return Q(c) ? hn(e, s)(c) : p(c);
  }
  function a(c) {
    return t(c);
  }
  function s(c) {
    return c === 34 || c === 39 || c === 40 ? Uo(e, u, t, "resourceTitle", "resourceTitleMarker", "resourceTitleString")(c) : p(c);
  }
  function u(c) {
    return Q(c) ? hn(e, p)(c) : p(c);
  }
  function p(c) {
    return c === 41 ? (e.enter("resourceMarker"), e.consume(c), e.exit("resourceMarker"), e.exit("resource"), n) : t(c);
  }
}
function gd(e, n, t) {
  const r = this;
  return i;
  function i(a) {
    return Bo.call(r, e, l, o, "reference", "referenceMarker", "referenceString")(a);
  }
  function l(a) {
    return r.parser.defined.includes(Ce(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1))) ? n(a) : t(a);
  }
  function o(a) {
    return t(a);
  }
}
function md(e, n, t) {
  return r;
  function r(l) {
    return e.enter("reference"), e.enter("referenceMarker"), e.consume(l), e.exit("referenceMarker"), i;
  }
  function i(l) {
    return l === 93 ? (e.enter("referenceMarker"), e.consume(l), e.exit("referenceMarker"), e.exit("reference"), n) : t(l);
  }
}
const bd = {
  name: "labelStartImage",
  resolveAll: lr.resolveAll,
  tokenize: yd
};
function yd(e, n, t) {
  const r = this;
  return i;
  function i(a) {
    return e.enter("labelImage"), e.enter("labelImageMarker"), e.consume(a), e.exit("labelImageMarker"), l;
  }
  function l(a) {
    return a === 91 ? (e.enter("labelMarker"), e.consume(a), e.exit("labelMarker"), e.exit("labelImage"), o) : t(a);
  }
  function o(a) {
    return a === 94 && "_hiddenFootnoteSupport" in r.parser.constructs ? t(a) : n(a);
  }
}
const kd = {
  name: "labelStartLink",
  resolveAll: lr.resolveAll,
  tokenize: xd
};
function xd(e, n, t) {
  const r = this;
  return i;
  function i(o) {
    return e.enter("labelLink"), e.enter("labelMarker"), e.consume(o), e.exit("labelMarker"), e.exit("labelLink"), l;
  }
  function l(o) {
    return o === 94 && "_hiddenFootnoteSupport" in r.parser.constructs ? t(o) : n(o);
  }
}
const Kn = {
  name: "lineEnding",
  tokenize: wd
};
function wd(e, n) {
  return t;
  function t(r) {
    return e.enter("lineEnding"), e.consume(r), e.exit("lineEnding"), G(e, n, "linePrefix");
  }
}
const Rn = {
  name: "thematicBreak",
  tokenize: vd
};
function vd(e, n, t) {
  let r = 0, i;
  return l;
  function l(u) {
    return e.enter("thematicBreak"), o(u);
  }
  function o(u) {
    return i = u, a(u);
  }
  function a(u) {
    return u === i ? (e.enter("thematicBreakSequence"), s(u)) : r >= 3 && (u === null || F(u)) ? (e.exit("thematicBreak"), n(u)) : t(u);
  }
  function s(u) {
    return u === i ? (e.consume(u), r++, s) : (e.exit("thematicBreakSequence"), H(u) ? G(e, a, "whitespace")(u) : a(u));
  }
}
const fe = {
  continuation: {
    tokenize: Ad
  },
  exit: Id,
  name: "list",
  tokenize: Cd
}, Sd = {
  partial: !0,
  tokenize: Od
}, Ed = {
  partial: !0,
  tokenize: Td
};
function Cd(e, n, t) {
  const r = this, i = r.events[r.events.length - 1];
  let l = i && i[1].type === "linePrefix" ? i[2].sliceSerialize(i[1], !0).length : 0, o = 0;
  return a;
  function a(f) {
    const g = r.containerState.type || (f === 42 || f === 43 || f === 45 ? "listUnordered" : "listOrdered");
    if (g === "listUnordered" ? !r.containerState.marker || f === r.containerState.marker : yt(f)) {
      if (r.containerState.type || (r.containerState.type = g, e.enter(g, {
        _container: !0
      })), g === "listUnordered")
        return e.enter("listItemPrefix"), f === 42 || f === 45 ? e.check(Rn, t, u)(f) : u(f);
      if (!r.interrupt || f === 49)
        return e.enter("listItemPrefix"), e.enter("listItemValue"), s(f);
    }
    return t(f);
  }
  function s(f) {
    return yt(f) && ++o < 10 ? (e.consume(f), s) : (!r.interrupt || o < 2) && (r.containerState.marker ? f === r.containerState.marker : f === 41 || f === 46) ? (e.exit("listItemValue"), u(f)) : t(f);
  }
  function u(f) {
    return e.enter("listItemMarker"), e.consume(f), e.exit("listItemMarker"), r.containerState.marker = r.containerState.marker || f, e.check(
      wn,
      // Can’t be empty when interrupting.
      r.interrupt ? t : p,
      e.attempt(Sd, h, c)
    );
  }
  function p(f) {
    return r.containerState.initialBlankLine = !0, l++, h(f);
  }
  function c(f) {
    return H(f) ? (e.enter("listItemPrefixWhitespace"), e.consume(f), e.exit("listItemPrefixWhitespace"), h) : t(f);
  }
  function h(f) {
    return r.containerState.size = l + r.sliceSerialize(e.exit("listItemPrefix"), !0).length, n(f);
  }
}
function Ad(e, n, t) {
  const r = this;
  return r.containerState._closeFlow = void 0, e.check(wn, i, l);
  function i(a) {
    return r.containerState.furtherBlankLines = r.containerState.furtherBlankLines || r.containerState.initialBlankLine, G(e, n, "listItemIndent", r.containerState.size + 1)(a);
  }
  function l(a) {
    return r.containerState.furtherBlankLines || !H(a) ? (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, o(a)) : (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, e.attempt(Ed, n, o)(a));
  }
  function o(a) {
    return r.containerState._closeFlow = !0, r.interrupt = void 0, G(e, e.attempt(fe, n, t), "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(a);
  }
}
function Td(e, n, t) {
  const r = this;
  return G(e, i, "listItemIndent", r.containerState.size + 1);
  function i(l) {
    const o = r.events[r.events.length - 1];
    return o && o[1].type === "listItemIndent" && o[2].sliceSerialize(o[1], !0).length === r.containerState.size ? n(l) : t(l);
  }
}
function Id(e) {
  e.exit(this.containerState.type);
}
function Od(e, n, t) {
  const r = this;
  return G(e, i, "listItemPrefixWhitespace", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 5);
  function i(l) {
    const o = r.events[r.events.length - 1];
    return !H(l) && o && o[1].type === "listItemPrefixWhitespace" ? n(l) : t(l);
  }
}
const si = {
  name: "setextUnderline",
  resolveTo: Ld,
  tokenize: Rd
};
function Ld(e, n) {
  let t = e.length, r, i, l;
  for (; t--; )
    if (e[t][0] === "enter") {
      if (e[t][1].type === "content") {
        r = t;
        break;
      }
      e[t][1].type === "paragraph" && (i = t);
    } else
      e[t][1].type === "content" && e.splice(t, 1), !l && e[t][1].type === "definition" && (l = t);
  const o = {
    type: "setextHeading",
    start: {
      ...e[r][1].start
    },
    end: {
      ...e[e.length - 1][1].end
    }
  };
  return e[i][1].type = "setextHeadingText", l ? (e.splice(i, 0, ["enter", o, n]), e.splice(l + 1, 0, ["exit", e[r][1], n]), e[r][1].end = {
    ...e[l][1].end
  }) : e[r][1] = o, e.push(["exit", o, n]), e;
}
function Rd(e, n, t) {
  const r = this;
  let i;
  return l;
  function l(u) {
    let p = r.events.length, c;
    for (; p--; )
      if (r.events[p][1].type !== "lineEnding" && r.events[p][1].type !== "linePrefix" && r.events[p][1].type !== "content") {
        c = r.events[p][1].type === "paragraph";
        break;
      }
    return !r.parser.lazy[r.now().line] && (r.interrupt || c) ? (e.enter("setextHeadingLine"), i = u, o(u)) : t(u);
  }
  function o(u) {
    return e.enter("setextHeadingLineSequence"), a(u);
  }
  function a(u) {
    return u === i ? (e.consume(u), a) : (e.exit("setextHeadingLineSequence"), H(u) ? G(e, s, "lineSuffix")(u) : s(u));
  }
  function s(u) {
    return u === null || F(u) ? (e.exit("setextHeadingLine"), n(u)) : t(u);
  }
}
const Nd = {
  tokenize: _d
};
function _d(e) {
  const n = this, t = e.attempt(
    // Try to parse a blank line.
    wn,
    r,
    // Try to parse initial flow (essentially, only code).
    e.attempt(this.parser.constructs.flowInitial, i, G(e, e.attempt(this.parser.constructs.flow, i, e.attempt(Mh, i)), "linePrefix"))
  );
  return t;
  function r(l) {
    if (l === null) {
      e.consume(l);
      return;
    }
    return e.enter("lineEndingBlank"), e.consume(l), e.exit("lineEndingBlank"), n.currentConstruct = void 0, t;
  }
  function i(l) {
    if (l === null) {
      e.consume(l);
      return;
    }
    return e.enter("lineEnding"), e.consume(l), e.exit("lineEnding"), n.currentConstruct = void 0, t;
  }
}
const Fd = {
  resolveAll: Vo()
}, Dd = Ho("string"), Pd = Ho("text");
function Ho(e) {
  return {
    resolveAll: Vo(e === "text" ? zd : void 0),
    tokenize: n
  };
  function n(t) {
    const r = this, i = this.parser.constructs[e], l = t.attempt(i, o, a);
    return o;
    function o(p) {
      return u(p) ? l(p) : a(p);
    }
    function a(p) {
      if (p === null) {
        t.consume(p);
        return;
      }
      return t.enter("data"), t.consume(p), s;
    }
    function s(p) {
      return u(p) ? (t.exit("data"), l(p)) : (t.consume(p), s);
    }
    function u(p) {
      if (p === null)
        return !0;
      const c = i[p];
      let h = -1;
      if (c)
        for (; ++h < c.length; ) {
          const f = c[h];
          if (!f.previous || f.previous.call(r, r.previous))
            return !0;
        }
      return !1;
    }
  }
}
function Vo(e) {
  return n;
  function n(t, r) {
    let i = -1, l;
    for (; ++i <= t.length; )
      l === void 0 ? t[i] && t[i][1].type === "data" && (l = i, i++) : (!t[i] || t[i][1].type !== "data") && (i !== l + 2 && (t[l][1].end = t[i - 1][1].end, t.splice(l + 2, i - l - 2), i = l + 2), l = void 0);
    return e ? e(t, r) : t;
  }
}
function zd(e, n) {
  let t = 0;
  for (; ++t <= e.length; )
    if ((t === e.length || e[t][1].type === "lineEnding") && e[t - 1][1].type === "data") {
      const r = e[t - 1][1], i = n.sliceStream(r);
      let l = i.length, o = -1, a = 0, s;
      for (; l--; ) {
        const u = i[l];
        if (typeof u == "string") {
          for (o = u.length; u.charCodeAt(o - 1) === 32; )
            a++, o--;
          if (o) break;
          o = -1;
        } else if (u === -2)
          s = !0, a++;
        else if (u !== -1) {
          l++;
          break;
        }
      }
      if (n._contentTypeTextTrailing && t === e.length && (a = 0), a) {
        const u = {
          type: t === e.length || s || a < 2 ? "lineSuffix" : "hardBreakTrailing",
          start: {
            _bufferIndex: l ? o : r.start._bufferIndex + o,
            _index: r.start._index + l,
            line: r.end.line,
            column: r.end.column - a,
            offset: r.end.offset - a
          },
          end: {
            ...r.end
          }
        };
        r.end = {
          ...u.start
        }, r.start.offset === r.end.offset ? Object.assign(r, u) : (e.splice(t, 0, ["enter", u, n], ["exit", u, n]), t += 2);
      }
      t++;
    }
  return e;
}
const Md = {
  42: fe,
  43: fe,
  45: fe,
  48: fe,
  49: fe,
  50: fe,
  51: fe,
  52: fe,
  53: fe,
  54: fe,
  55: fe,
  56: fe,
  57: fe,
  62: Po
}, $d = {
  91: Hh
}, jd = {
  [-2]: Xn,
  [-1]: Xn,
  32: Xn
}, Bd = {
  35: Xh,
  42: Rn,
  45: [si, Rn],
  60: Jh,
  61: si,
  95: Rn,
  96: li,
  126: li
}, Ud = {
  38: Mo,
  92: zo
}, Hd = {
  [-5]: Kn,
  [-4]: Kn,
  [-3]: Kn,
  33: bd,
  38: Mo,
  42: kt,
  60: [kh, ld],
  91: kd,
  92: [Wh, zo],
  93: lr,
  95: kt,
  96: Nh
}, Vd = {
  null: [kt, Fd]
}, qd = {
  null: [42, 95]
}, Gd = {
  null: []
}, Wd = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  attentionMarkers: qd,
  contentInitial: $d,
  disable: Gd,
  document: Md,
  flow: Bd,
  flowInitial: jd,
  insideSpan: Vd,
  string: Ud,
  text: Hd
}, Symbol.toStringTag, { value: "Module" }));
function Yd(e, n, t) {
  let r = {
    _bufferIndex: -1,
    _index: 0,
    line: t && t.line || 1,
    column: t && t.column || 1,
    offset: t && t.offset || 0
  };
  const i = {}, l = [];
  let o = [], a = [];
  const s = {
    attempt: I(S),
    check: I(m),
    consume: k,
    enter: y,
    exit: E,
    interrupt: I(m, {
      interrupt: !0
    })
  }, u = {
    code: null,
    containerState: {},
    defineSkip: v,
    events: [],
    now: g,
    parser: e,
    previous: null,
    sliceSerialize: h,
    sliceStream: f,
    write: c
  };
  let p = n.tokenize.call(u, s);
  return n.resolveAll && l.push(n), u;
  function c(L) {
    return o = xe(o, L), A(), o[o.length - 1] !== null ? [] : (N(n, 0), u.events = Bn(l, u.events, u), u.events);
  }
  function h(L, _) {
    return Kd(f(L), _);
  }
  function f(L) {
    return Xd(o, L);
  }
  function g() {
    const {
      _bufferIndex: L,
      _index: _,
      line: P,
      column: j,
      offset: D
    } = r;
    return {
      _bufferIndex: L,
      _index: _,
      line: P,
      column: j,
      offset: D
    };
  }
  function v(L) {
    i[L.line] = L.column, x();
  }
  function A() {
    let L;
    for (; r._index < o.length; ) {
      const _ = o[r._index];
      if (typeof _ == "string")
        for (L = r._index, r._bufferIndex < 0 && (r._bufferIndex = 0); r._index === L && r._bufferIndex < _.length; )
          w(_.charCodeAt(r._bufferIndex));
      else
        w(_);
    }
  }
  function w(L) {
    p = p(L);
  }
  function k(L) {
    F(L) ? (r.line++, r.column = 1, r.offset += L === -3 ? 2 : 1, x()) : L !== -1 && (r.column++, r.offset++), r._bufferIndex < 0 ? r._index++ : (r._bufferIndex++, r._bufferIndex === // Points w/ non-negative `_bufferIndex` reference
    // strings.
    /** @type {string} */
    o[r._index].length && (r._bufferIndex = -1, r._index++)), u.previous = L;
  }
  function y(L, _) {
    const P = _ || {};
    return P.type = L, P.start = g(), u.events.push(["enter", P, u]), a.push(P), P;
  }
  function E(L) {
    const _ = a.pop();
    return _.end = g(), u.events.push(["exit", _, u]), _;
  }
  function S(L, _) {
    N(L, _.from);
  }
  function m(L, _) {
    _.restore();
  }
  function I(L, _) {
    return P;
    function P(j, D, W) {
      let X, B, Y, d;
      return Array.isArray(j) ? (
        /* c8 ignore next 1 */
        q(j)
      ) : "tokenize" in j ? (
        // Looks like a construct.
        q([
          /** @type {Construct} */
          j
        ])
      ) : z(j);
      function z(K) {
        return oe;
        function oe(le) {
          const ve = le !== null && K[le], ye = le !== null && K.null, Se = [
            // To do: add more extension tests.
            /* c8 ignore next 2 */
            ...Array.isArray(ve) ? ve : ve ? [ve] : [],
            ...Array.isArray(ye) ? ye : ye ? [ye] : []
          ];
          return q(Se)(le);
        }
      }
      function q(K) {
        return X = K, B = 0, K.length === 0 ? W : b(K[B]);
      }
      function b(K) {
        return oe;
        function oe(le) {
          return d = T(), Y = K, K.partial || (u.currentConstruct = K), K.name && u.parser.constructs.disable.null.includes(K.name) ? ie() : K.tokenize.call(
            // If we do have fields, create an object w/ `context` as its
            // prototype.
            // This allows a “live binding”, which is needed for `interrupt`.
            _ ? Object.assign(Object.create(u), _) : u,
            s,
            ee,
            ie
          )(le);
        }
      }
      function ee(K) {
        return L(Y, d), D;
      }
      function ie(K) {
        return d.restore(), ++B < X.length ? b(X[B]) : W;
      }
    }
  }
  function N(L, _) {
    L.resolveAll && !l.includes(L) && l.push(L), L.resolve && be(u.events, _, u.events.length - _, L.resolve(u.events.slice(_), u)), L.resolveTo && (u.events = L.resolveTo(u.events, u));
  }
  function T() {
    const L = g(), _ = u.previous, P = u.currentConstruct, j = u.events.length, D = Array.from(a);
    return {
      from: j,
      restore: W
    };
    function W() {
      r = L, u.previous = _, u.currentConstruct = P, u.events.length = j, a = D, x();
    }
  }
  function x() {
    r.line in i && r.column < 2 && (r.column = i[r.line], r.offset += i[r.line] - 1);
  }
}
function Xd(e, n) {
  const t = n.start._index, r = n.start._bufferIndex, i = n.end._index, l = n.end._bufferIndex;
  let o;
  if (t === i)
    o = [e[t].slice(r, l)];
  else {
    if (o = e.slice(t, i), r > -1) {
      const a = o[0];
      typeof a == "string" ? o[0] = a.slice(r) : o.shift();
    }
    l > 0 && o.push(e[i].slice(0, l));
  }
  return o;
}
function Kd(e, n) {
  let t = -1;
  const r = [];
  let i;
  for (; ++t < e.length; ) {
    const l = e[t];
    let o;
    if (typeof l == "string")
      o = l;
    else switch (l) {
      case -5: {
        o = "\r";
        break;
      }
      case -4: {
        o = `
`;
        break;
      }
      case -3: {
        o = `\r
`;
        break;
      }
      case -2: {
        o = n ? " " : "	";
        break;
      }
      case -1: {
        if (!n && i) continue;
        o = " ";
        break;
      }
      default:
        o = String.fromCharCode(l);
    }
    i = l === -2, r.push(o);
  }
  return r.join("");
}
function Zd(e) {
  const r = {
    constructs: (
      /** @type {FullNormalizedExtension} */
      Fo([Wd, ...(e || {}).extensions || []])
    ),
    content: i(fh),
    defined: [],
    document: i(dh),
    flow: i(Nd),
    lazy: {},
    string: i(Dd),
    text: i(Pd)
  };
  return r;
  function i(l) {
    return o;
    function o(a) {
      return Yd(r, l, a);
    }
  }
}
function Qd(e) {
  for (; !$o(e); )
    ;
  return e;
}
const ui = /[\0\t\n\r]/g;
function Jd() {
  let e = 1, n = "", t = !0, r;
  return i;
  function i(l, o, a) {
    const s = [];
    let u, p, c, h, f;
    for (l = n + (typeof l == "string" ? l.toString() : new TextDecoder(o || void 0).decode(l)), c = 0, n = "", t && (l.charCodeAt(0) === 65279 && c++, t = void 0); c < l.length; ) {
      if (ui.lastIndex = c, u = ui.exec(l), h = u && u.index !== void 0 ? u.index : l.length, f = l.charCodeAt(h), !u) {
        n = l.slice(c);
        break;
      }
      if (f === 10 && c === h && r)
        s.push(-3), r = void 0;
      else
        switch (r && (s.push(-5), r = void 0), c < h && (s.push(l.slice(c, h)), e += h - c), f) {
          case 0: {
            s.push(65533), e++;
            break;
          }
          case 9: {
            for (p = Math.ceil(e / 4) * 4, s.push(-2); e++ < p; ) s.push(-1);
            break;
          }
          case 10: {
            s.push(-4), e = 1;
            break;
          }
          default:
            r = !0, e = 1;
        }
      c = h + 1;
    }
    return a && (r && s.push(-5), n && s.push(n), s.push(null)), s;
  }
}
const eg = /\\([!-/:-@[-`{-~])|&(#(?:\d{1,7}|x[\da-f]{1,6})|[\da-z]{1,31});/gi;
function ng(e) {
  return e.replace(eg, tg);
}
function tg(e, n, t) {
  if (n)
    return n;
  if (t.charCodeAt(0) === 35) {
    const i = t.charCodeAt(1), l = i === 120 || i === 88;
    return Do(t.slice(l ? 2 : 1), l ? 16 : 10);
  }
  return or(t) || e;
}
const qo = {}.hasOwnProperty;
function rg(e, n, t) {
  return typeof n != "string" && (t = n, n = void 0), ig(t)(Qd(Zd(t).document().write(Jd()(e, n, !0))));
}
function ig(e) {
  const n = {
    transforms: [],
    canContainEols: ["emphasis", "fragment", "heading", "paragraph", "strong"],
    enter: {
      autolink: l(vr),
      autolinkProtocol: T,
      autolinkEmail: T,
      atxHeading: l(kr),
      blockQuote: l(ye),
      characterEscape: T,
      characterReference: T,
      codeFenced: l(Se),
      codeFencedFenceInfo: o,
      codeFencedFenceMeta: o,
      codeIndented: l(Se, o),
      codeText: l(qn, o),
      codeTextData: T,
      data: T,
      codeFlowValue: T,
      definition: l(tn),
      definitionDestinationString: o,
      definitionLabelString: o,
      definitionTitleString: o,
      emphasis: l(Al),
      hardBreakEscape: l(xr),
      hardBreakTrailing: l(xr),
      htmlFlow: l(wr, o),
      htmlFlowData: T,
      htmlText: l(wr, o),
      htmlTextData: T,
      image: l(Tl),
      label: o,
      link: l(vr),
      listItem: l(Il),
      listItemValue: h,
      listOrdered: l(Sr, c),
      listUnordered: l(Sr),
      paragraph: l(Ol),
      reference: b,
      referenceString: o,
      resourceDestinationString: o,
      resourceTitleString: o,
      setextHeading: l(kr),
      strong: l(Ll),
      thematicBreak: l(Nl)
    },
    exit: {
      atxHeading: s(),
      atxHeadingSequence: S,
      autolink: s(),
      autolinkEmail: ve,
      autolinkProtocol: le,
      blockQuote: s(),
      characterEscapeValue: x,
      characterReferenceMarkerHexadecimal: ie,
      characterReferenceMarkerNumeric: ie,
      characterReferenceValue: K,
      characterReference: oe,
      codeFenced: s(A),
      codeFencedFence: v,
      codeFencedFenceInfo: f,
      codeFencedFenceMeta: g,
      codeFlowValue: x,
      codeIndented: s(w),
      codeText: s(D),
      codeTextData: x,
      data: x,
      definition: s(),
      definitionDestinationString: E,
      definitionLabelString: k,
      definitionTitleString: y,
      emphasis: s(),
      hardBreakEscape: s(_),
      hardBreakTrailing: s(_),
      htmlFlow: s(P),
      htmlFlowData: x,
      htmlText: s(j),
      htmlTextData: x,
      image: s(X),
      label: Y,
      labelText: B,
      lineEnding: L,
      link: s(W),
      listItem: s(),
      listOrdered: s(),
      listUnordered: s(),
      paragraph: s(),
      referenceString: ee,
      resourceDestinationString: d,
      resourceTitleString: z,
      resource: q,
      setextHeading: s(N),
      setextHeadingLineSequence: I,
      setextHeadingText: m,
      strong: s(),
      thematicBreak: s()
    }
  };
  Go(n, (e || {}).mdastExtensions || []);
  const t = {};
  return r;
  function r(C) {
    let R = {
      type: "root",
      children: []
    };
    const M = {
      stack: [R],
      tokenStack: [],
      config: n,
      enter: a,
      exit: u,
      buffer: o,
      resume: p,
      data: t
    }, V = [];
    let Z = -1;
    for (; ++Z < C.length; )
      if (C[Z][1].type === "listOrdered" || C[Z][1].type === "listUnordered")
        if (C[Z][0] === "enter")
          V.push(Z);
        else {
          const Ee = V.pop();
          Z = i(C, Ee, Z);
        }
    for (Z = -1; ++Z < C.length; ) {
      const Ee = n[C[Z][0]];
      qo.call(Ee, C[Z][1].type) && Ee[C[Z][1].type].call(Object.assign({
        sliceSerialize: C[Z][2].sliceSerialize
      }, M), C[Z][1]);
    }
    if (M.tokenStack.length > 0) {
      const Ee = M.tokenStack[M.tokenStack.length - 1];
      (Ee[1] || ci).call(M, void 0, Ee[0]);
    }
    for (R.position = {
      start: Ne(C.length > 0 ? C[0][1].start : {
        line: 1,
        column: 1,
        offset: 0
      }),
      end: Ne(C.length > 0 ? C[C.length - 2][1].end : {
        line: 1,
        column: 1,
        offset: 0
      })
    }, Z = -1; ++Z < n.transforms.length; )
      R = n.transforms[Z](R) || R;
    return R;
  }
  function i(C, R, M) {
    let V = R - 1, Z = -1, Ee = !1, Me, Oe, rn, on;
    for (; ++V <= M; ) {
      const ge = C[V];
      switch (ge[1].type) {
        case "listUnordered":
        case "listOrdered":
        case "blockQuote": {
          ge[0] === "enter" ? Z++ : Z--, on = void 0;
          break;
        }
        case "lineEndingBlank": {
          ge[0] === "enter" && (Me && !on && !Z && !rn && (rn = V), on = void 0);
          break;
        }
        case "linePrefix":
        case "listItemValue":
        case "listItemMarker":
        case "listItemPrefix":
        case "listItemPrefixWhitespace":
          break;
        default:
          on = void 0;
      }
      if (!Z && ge[0] === "enter" && ge[1].type === "listItemPrefix" || Z === -1 && ge[0] === "exit" && (ge[1].type === "listUnordered" || ge[1].type === "listOrdered")) {
        if (Me) {
          let qe = V;
          for (Oe = void 0; qe--; ) {
            const Le = C[qe];
            if (Le[1].type === "lineEnding" || Le[1].type === "lineEndingBlank") {
              if (Le[0] === "exit") continue;
              Oe && (C[Oe][1].type = "lineEndingBlank", Ee = !0), Le[1].type = "lineEnding", Oe = qe;
            } else if (!(Le[1].type === "linePrefix" || Le[1].type === "blockQuotePrefix" || Le[1].type === "blockQuotePrefixWhitespace" || Le[1].type === "blockQuoteMarker" || Le[1].type === "listItemIndent")) break;
          }
          rn && (!Oe || rn < Oe) && (Me._spread = !0), Me.end = Object.assign({}, Oe ? C[Oe][1].start : ge[1].end), C.splice(Oe || V, 0, ["exit", Me, ge[2]]), V++, M++;
        }
        if (ge[1].type === "listItemPrefix") {
          const qe = {
            type: "listItem",
            _spread: !1,
            start: Object.assign({}, ge[1].start),
            // @ts-expect-error: we’ll add `end` in a second.
            end: void 0
          };
          Me = qe, C.splice(V, 0, ["enter", qe, ge[2]]), V++, M++, rn = void 0, on = !0;
        }
      }
    }
    return C[R][1]._spread = Ee, M;
  }
  function l(C, R) {
    return M;
    function M(V) {
      a.call(this, C(V), V), R && R.call(this, V);
    }
  }
  function o() {
    this.stack.push({
      type: "fragment",
      children: []
    });
  }
  function a(C, R, M) {
    this.stack[this.stack.length - 1].children.push(C), this.stack.push(C), this.tokenStack.push([R, M || void 0]), C.position = {
      start: Ne(R.start),
      // @ts-expect-error: `end` will be patched later.
      end: void 0
    };
  }
  function s(C) {
    return R;
    function R(M) {
      C && C.call(this, M), u.call(this, M);
    }
  }
  function u(C, R) {
    const M = this.stack.pop(), V = this.tokenStack.pop();
    if (V)
      V[0].type !== C.type && (R ? R.call(this, C, V[0]) : (V[1] || ci).call(this, C, V[0]));
    else throw new Error("Cannot close `" + C.type + "` (" + fn({
      start: C.start,
      end: C.end
    }) + "): it’s not open");
    M.position.end = Ne(C.end);
  }
  function p() {
    return ir(this.stack.pop());
  }
  function c() {
    this.data.expectingFirstListItemValue = !0;
  }
  function h(C) {
    if (this.data.expectingFirstListItemValue) {
      const R = this.stack[this.stack.length - 2];
      R.start = Number.parseInt(this.sliceSerialize(C), 10), this.data.expectingFirstListItemValue = void 0;
    }
  }
  function f() {
    const C = this.resume(), R = this.stack[this.stack.length - 1];
    R.lang = C;
  }
  function g() {
    const C = this.resume(), R = this.stack[this.stack.length - 1];
    R.meta = C;
  }
  function v() {
    this.data.flowCodeInside || (this.buffer(), this.data.flowCodeInside = !0);
  }
  function A() {
    const C = this.resume(), R = this.stack[this.stack.length - 1];
    R.value = C.replace(/^(\r?\n|\r)|(\r?\n|\r)$/g, ""), this.data.flowCodeInside = void 0;
  }
  function w() {
    const C = this.resume(), R = this.stack[this.stack.length - 1];
    R.value = C.replace(/(\r?\n|\r)$/g, "");
  }
  function k(C) {
    const R = this.resume(), M = this.stack[this.stack.length - 1];
    M.label = R, M.identifier = Ce(this.sliceSerialize(C)).toLowerCase();
  }
  function y() {
    const C = this.resume(), R = this.stack[this.stack.length - 1];
    R.title = C;
  }
  function E() {
    const C = this.resume(), R = this.stack[this.stack.length - 1];
    R.url = C;
  }
  function S(C) {
    const R = this.stack[this.stack.length - 1];
    if (!R.depth) {
      const M = this.sliceSerialize(C).length;
      R.depth = M;
    }
  }
  function m() {
    this.data.setextHeadingSlurpLineEnding = !0;
  }
  function I(C) {
    const R = this.stack[this.stack.length - 1];
    R.depth = this.sliceSerialize(C).codePointAt(0) === 61 ? 1 : 2;
  }
  function N() {
    this.data.setextHeadingSlurpLineEnding = void 0;
  }
  function T(C) {
    const M = this.stack[this.stack.length - 1].children;
    let V = M[M.length - 1];
    (!V || V.type !== "text") && (V = Rl(), V.position = {
      start: Ne(C.start),
      // @ts-expect-error: we’ll add `end` later.
      end: void 0
    }, M.push(V)), this.stack.push(V);
  }
  function x(C) {
    const R = this.stack.pop();
    R.value += this.sliceSerialize(C), R.position.end = Ne(C.end);
  }
  function L(C) {
    const R = this.stack[this.stack.length - 1];
    if (this.data.atHardBreak) {
      const M = R.children[R.children.length - 1];
      M.position.end = Ne(C.end), this.data.atHardBreak = void 0;
      return;
    }
    !this.data.setextHeadingSlurpLineEnding && n.canContainEols.includes(R.type) && (T.call(this, C), x.call(this, C));
  }
  function _() {
    this.data.atHardBreak = !0;
  }
  function P() {
    const C = this.resume(), R = this.stack[this.stack.length - 1];
    R.value = C;
  }
  function j() {
    const C = this.resume(), R = this.stack[this.stack.length - 1];
    R.value = C;
  }
  function D() {
    const C = this.resume(), R = this.stack[this.stack.length - 1];
    R.value = C;
  }
  function W() {
    const C = this.stack[this.stack.length - 1];
    if (this.data.inReference) {
      const R = this.data.referenceType || "shortcut";
      C.type += "Reference", C.referenceType = R, delete C.url, delete C.title;
    } else
      delete C.identifier, delete C.label;
    this.data.referenceType = void 0;
  }
  function X() {
    const C = this.stack[this.stack.length - 1];
    if (this.data.inReference) {
      const R = this.data.referenceType || "shortcut";
      C.type += "Reference", C.referenceType = R, delete C.url, delete C.title;
    } else
      delete C.identifier, delete C.label;
    this.data.referenceType = void 0;
  }
  function B(C) {
    const R = this.sliceSerialize(C), M = this.stack[this.stack.length - 2];
    M.label = ng(R), M.identifier = Ce(R).toLowerCase();
  }
  function Y() {
    const C = this.stack[this.stack.length - 1], R = this.resume(), M = this.stack[this.stack.length - 1];
    if (this.data.inReference = !0, M.type === "link") {
      const V = C.children;
      M.children = V;
    } else
      M.alt = R;
  }
  function d() {
    const C = this.resume(), R = this.stack[this.stack.length - 1];
    R.url = C;
  }
  function z() {
    const C = this.resume(), R = this.stack[this.stack.length - 1];
    R.title = C;
  }
  function q() {
    this.data.inReference = void 0;
  }
  function b() {
    this.data.referenceType = "collapsed";
  }
  function ee(C) {
    const R = this.resume(), M = this.stack[this.stack.length - 1];
    M.label = R, M.identifier = Ce(this.sliceSerialize(C)).toLowerCase(), this.data.referenceType = "full";
  }
  function ie(C) {
    this.data.characterReferenceType = C.type;
  }
  function K(C) {
    const R = this.sliceSerialize(C), M = this.data.characterReferenceType;
    let V;
    M ? (V = Do(R, M === "characterReferenceMarkerNumeric" ? 10 : 16), this.data.characterReferenceType = void 0) : V = or(R);
    const Z = this.stack[this.stack.length - 1];
    Z.value += V;
  }
  function oe(C) {
    const R = this.stack.pop();
    R.position.end = Ne(C.end);
  }
  function le(C) {
    x.call(this, C);
    const R = this.stack[this.stack.length - 1];
    R.url = this.sliceSerialize(C);
  }
  function ve(C) {
    x.call(this, C);
    const R = this.stack[this.stack.length - 1];
    R.url = "mailto:" + this.sliceSerialize(C);
  }
  function ye() {
    return {
      type: "blockquote",
      children: []
    };
  }
  function Se() {
    return {
      type: "code",
      lang: null,
      meta: null,
      value: ""
    };
  }
  function qn() {
    return {
      type: "inlineCode",
      value: ""
    };
  }
  function tn() {
    return {
      type: "definition",
      identifier: "",
      label: null,
      title: null,
      url: ""
    };
  }
  function Al() {
    return {
      type: "emphasis",
      children: []
    };
  }
  function kr() {
    return {
      type: "heading",
      // @ts-expect-error `depth` will be set later.
      depth: 0,
      children: []
    };
  }
  function xr() {
    return {
      type: "break"
    };
  }
  function wr() {
    return {
      type: "html",
      value: ""
    };
  }
  function Tl() {
    return {
      type: "image",
      title: null,
      url: "",
      alt: null
    };
  }
  function vr() {
    return {
      type: "link",
      title: null,
      url: "",
      children: []
    };
  }
  function Sr(C) {
    return {
      type: "list",
      ordered: C.type === "listOrdered",
      start: null,
      spread: C._spread,
      children: []
    };
  }
  function Il(C) {
    return {
      type: "listItem",
      spread: C._spread,
      checked: null,
      children: []
    };
  }
  function Ol() {
    return {
      type: "paragraph",
      children: []
    };
  }
  function Ll() {
    return {
      type: "strong",
      children: []
    };
  }
  function Rl() {
    return {
      type: "text",
      value: ""
    };
  }
  function Nl() {
    return {
      type: "thematicBreak"
    };
  }
}
function Ne(e) {
  return {
    line: e.line,
    column: e.column,
    offset: e.offset
  };
}
function Go(e, n) {
  let t = -1;
  for (; ++t < n.length; ) {
    const r = n[t];
    Array.isArray(r) ? Go(e, r) : og(e, r);
  }
}
function og(e, n) {
  let t;
  for (t in n)
    if (qo.call(n, t))
      switch (t) {
        case "canContainEols": {
          const r = n[t];
          r && e[t].push(...r);
          break;
        }
        case "transforms": {
          const r = n[t];
          r && e[t].push(...r);
          break;
        }
        case "enter":
        case "exit": {
          const r = n[t];
          r && Object.assign(e[t], r);
          break;
        }
      }
}
function ci(e, n) {
  throw e ? new Error("Cannot close `" + e.type + "` (" + fn({
    start: e.start,
    end: e.end
  }) + "): a different token (`" + n.type + "`, " + fn({
    start: n.start,
    end: n.end
  }) + ") is open") : new Error("Cannot close document, a token (`" + n.type + "`, " + fn({
    start: n.start,
    end: n.end
  }) + ") is still open");
}
function lg(e) {
  const n = this;
  n.parser = t;
  function t(r) {
    return rg(r, {
      ...n.data("settings"),
      ...e,
      // Note: these options are not in the readme.
      // The goal is for them to be set by plugins on `data` instead of being
      // passed by users.
      extensions: n.data("micromarkExtensions") || [],
      mdastExtensions: n.data("fromMarkdownExtensions") || []
    });
  }
}
function ag(e, n) {
  const t = {
    type: "element",
    tagName: "blockquote",
    properties: {},
    children: e.wrap(e.all(n), !0)
  };
  return e.patch(n, t), e.applyData(n, t);
}
function sg(e, n) {
  const t = { type: "element", tagName: "br", properties: {}, children: [] };
  return e.patch(n, t), [e.applyData(n, t), { type: "text", value: `
` }];
}
function ug(e, n) {
  const t = n.value ? n.value + `
` : "", r = {}, i = n.lang ? n.lang.split(/\s+/) : [];
  i.length > 0 && (r.className = ["language-" + i[0]]);
  let l = {
    type: "element",
    tagName: "code",
    properties: r,
    children: [{ type: "text", value: t }]
  };
  return n.meta && (l.data = { meta: n.meta }), e.patch(n, l), l = e.applyData(n, l), l = { type: "element", tagName: "pre", properties: {}, children: [l] }, e.patch(n, l), l;
}
function cg(e, n) {
  const t = {
    type: "element",
    tagName: "del",
    properties: {},
    children: e.all(n)
  };
  return e.patch(n, t), e.applyData(n, t);
}
function pg(e, n) {
  const t = {
    type: "element",
    tagName: "em",
    properties: {},
    children: e.all(n)
  };
  return e.patch(n, t), e.applyData(n, t);
}
function fg(e, n) {
  const t = typeof e.options.clobberPrefix == "string" ? e.options.clobberPrefix : "user-content-", r = String(n.identifier).toUpperCase(), i = nn(r.toLowerCase()), l = e.footnoteOrder.indexOf(r);
  let o, a = e.footnoteCounts.get(r);
  a === void 0 ? (a = 0, e.footnoteOrder.push(r), o = e.footnoteOrder.length) : o = l + 1, a += 1, e.footnoteCounts.set(r, a);
  const s = {
    type: "element",
    tagName: "a",
    properties: {
      href: "#" + t + "fn-" + i,
      id: t + "fnref-" + i + (a > 1 ? "-" + a : ""),
      dataFootnoteRef: !0,
      ariaDescribedBy: ["footnote-label"]
    },
    children: [{ type: "text", value: String(o) }]
  };
  e.patch(n, s);
  const u = {
    type: "element",
    tagName: "sup",
    properties: {},
    children: [s]
  };
  return e.patch(n, u), e.applyData(n, u);
}
function hg(e, n) {
  const t = {
    type: "element",
    tagName: "h" + n.depth,
    properties: {},
    children: e.all(n)
  };
  return e.patch(n, t), e.applyData(n, t);
}
function dg(e, n) {
  if (e.options.allowDangerousHtml) {
    const t = { type: "raw", value: n.value };
    return e.patch(n, t), e.applyData(n, t);
  }
}
function Wo(e, n) {
  const t = n.referenceType;
  let r = "]";
  if (t === "collapsed" ? r += "[]" : t === "full" && (r += "[" + (n.label || n.identifier) + "]"), n.type === "imageReference")
    return [{ type: "text", value: "![" + n.alt + r }];
  const i = e.all(n), l = i[0];
  l && l.type === "text" ? l.value = "[" + l.value : i.unshift({ type: "text", value: "[" });
  const o = i[i.length - 1];
  return o && o.type === "text" ? o.value += r : i.push({ type: "text", value: r }), i;
}
function gg(e, n) {
  const t = String(n.identifier).toUpperCase(), r = e.definitionById.get(t);
  if (!r)
    return Wo(e, n);
  const i = { src: nn(r.url || ""), alt: n.alt };
  r.title !== null && r.title !== void 0 && (i.title = r.title);
  const l = { type: "element", tagName: "img", properties: i, children: [] };
  return e.patch(n, l), e.applyData(n, l);
}
function mg(e, n) {
  const t = { src: nn(n.url) };
  n.alt !== null && n.alt !== void 0 && (t.alt = n.alt), n.title !== null && n.title !== void 0 && (t.title = n.title);
  const r = { type: "element", tagName: "img", properties: t, children: [] };
  return e.patch(n, r), e.applyData(n, r);
}
function bg(e, n) {
  const t = { type: "text", value: n.value.replace(/\r?\n|\r/g, " ") };
  e.patch(n, t);
  const r = {
    type: "element",
    tagName: "code",
    properties: {},
    children: [t]
  };
  return e.patch(n, r), e.applyData(n, r);
}
function yg(e, n) {
  const t = String(n.identifier).toUpperCase(), r = e.definitionById.get(t);
  if (!r)
    return Wo(e, n);
  const i = { href: nn(r.url || "") };
  r.title !== null && r.title !== void 0 && (i.title = r.title);
  const l = {
    type: "element",
    tagName: "a",
    properties: i,
    children: e.all(n)
  };
  return e.patch(n, l), e.applyData(n, l);
}
function kg(e, n) {
  const t = { href: nn(n.url) };
  n.title !== null && n.title !== void 0 && (t.title = n.title);
  const r = {
    type: "element",
    tagName: "a",
    properties: t,
    children: e.all(n)
  };
  return e.patch(n, r), e.applyData(n, r);
}
function xg(e, n, t) {
  const r = e.all(n), i = t ? wg(t) : Yo(n), l = {}, o = [];
  if (typeof n.checked == "boolean") {
    const p = r[0];
    let c;
    p && p.type === "element" && p.tagName === "p" ? c = p : (c = { type: "element", tagName: "p", properties: {}, children: [] }, r.unshift(c)), c.children.length > 0 && c.children.unshift({ type: "text", value: " " }), c.children.unshift({
      type: "element",
      tagName: "input",
      properties: { type: "checkbox", checked: n.checked, disabled: !0 },
      children: []
    }), l.className = ["task-list-item"];
  }
  let a = -1;
  for (; ++a < r.length; ) {
    const p = r[a];
    (i || a !== 0 || p.type !== "element" || p.tagName !== "p") && o.push({ type: "text", value: `
` }), p.type === "element" && p.tagName === "p" && !i ? o.push(...p.children) : o.push(p);
  }
  const s = r[r.length - 1];
  s && (i || s.type !== "element" || s.tagName !== "p") && o.push({ type: "text", value: `
` });
  const u = { type: "element", tagName: "li", properties: l, children: o };
  return e.patch(n, u), e.applyData(n, u);
}
function wg(e) {
  let n = !1;
  if (e.type === "list") {
    n = e.spread || !1;
    const t = e.children;
    let r = -1;
    for (; !n && ++r < t.length; )
      n = Yo(t[r]);
  }
  return n;
}
function Yo(e) {
  const n = e.spread;
  return n ?? e.children.length > 1;
}
function vg(e, n) {
  const t = {}, r = e.all(n);
  let i = -1;
  for (typeof n.start == "number" && n.start !== 1 && (t.start = n.start); ++i < r.length; ) {
    const o = r[i];
    if (o.type === "element" && o.tagName === "li" && o.properties && Array.isArray(o.properties.className) && o.properties.className.includes("task-list-item")) {
      t.className = ["contains-task-list"];
      break;
    }
  }
  const l = {
    type: "element",
    tagName: n.ordered ? "ol" : "ul",
    properties: t,
    children: e.wrap(r, !0)
  };
  return e.patch(n, l), e.applyData(n, l);
}
function Sg(e, n) {
  const t = {
    type: "element",
    tagName: "p",
    properties: {},
    children: e.all(n)
  };
  return e.patch(n, t), e.applyData(n, t);
}
function Eg(e, n) {
  const t = { type: "root", children: e.wrap(e.all(n)) };
  return e.patch(n, t), e.applyData(n, t);
}
function Cg(e, n) {
  const t = {
    type: "element",
    tagName: "strong",
    properties: {},
    children: e.all(n)
  };
  return e.patch(n, t), e.applyData(n, t);
}
function Ag(e, n) {
  const t = e.all(n), r = t.shift(), i = [];
  if (r) {
    const o = {
      type: "element",
      tagName: "thead",
      properties: {},
      children: e.wrap([r], !0)
    };
    e.patch(n.children[0], o), i.push(o);
  }
  if (t.length > 0) {
    const o = {
      type: "element",
      tagName: "tbody",
      properties: {},
      children: e.wrap(t, !0)
    }, a = er(n.children[1]), s = To(n.children[n.children.length - 1]);
    a && s && (o.position = { start: a, end: s }), i.push(o);
  }
  const l = {
    type: "element",
    tagName: "table",
    properties: {},
    children: e.wrap(i, !0)
  };
  return e.patch(n, l), e.applyData(n, l);
}
function Tg(e, n, t) {
  const r = t ? t.children : void 0, l = (r ? r.indexOf(n) : 1) === 0 ? "th" : "td", o = t && t.type === "table" ? t.align : void 0, a = o ? o.length : n.children.length;
  let s = -1;
  const u = [];
  for (; ++s < a; ) {
    const c = n.children[s], h = {}, f = o ? o[s] : void 0;
    f && (h.align = f);
    let g = { type: "element", tagName: l, properties: h, children: [] };
    c && (g.children = e.all(c), e.patch(c, g), g = e.applyData(c, g)), u.push(g);
  }
  const p = {
    type: "element",
    tagName: "tr",
    properties: {},
    children: e.wrap(u, !0)
  };
  return e.patch(n, p), e.applyData(n, p);
}
function Ig(e, n) {
  const t = {
    type: "element",
    tagName: "td",
    // Assume body cell.
    properties: {},
    children: e.all(n)
  };
  return e.patch(n, t), e.applyData(n, t);
}
const pi = 9, fi = 32;
function Og(e) {
  const n = String(e), t = /\r?\n|\r/g;
  let r = t.exec(n), i = 0;
  const l = [];
  for (; r; )
    l.push(
      hi(n.slice(i, r.index), i > 0, !0),
      r[0]
    ), i = r.index + r[0].length, r = t.exec(n);
  return l.push(hi(n.slice(i), i > 0, !1)), l.join("");
}
function hi(e, n, t) {
  let r = 0, i = e.length;
  if (n) {
    let l = e.codePointAt(r);
    for (; l === pi || l === fi; )
      r++, l = e.codePointAt(r);
  }
  if (t) {
    let l = e.codePointAt(i - 1);
    for (; l === pi || l === fi; )
      i--, l = e.codePointAt(i - 1);
  }
  return i > r ? e.slice(r, i) : "";
}
function Lg(e, n) {
  const t = { type: "text", value: Og(String(n.value)) };
  return e.patch(n, t), e.applyData(n, t);
}
function Rg(e, n) {
  const t = {
    type: "element",
    tagName: "hr",
    properties: {},
    children: []
  };
  return e.patch(n, t), e.applyData(n, t);
}
const Ng = {
  blockquote: ag,
  break: sg,
  code: ug,
  delete: cg,
  emphasis: pg,
  footnoteReference: fg,
  heading: hg,
  html: dg,
  imageReference: gg,
  image: mg,
  inlineCode: bg,
  linkReference: yg,
  link: kg,
  listItem: xg,
  list: vg,
  paragraph: Sg,
  // @ts-expect-error: root is different, but hard to type.
  root: Eg,
  strong: Cg,
  table: Ag,
  tableCell: Ig,
  tableRow: Tg,
  text: Lg,
  thematicBreak: Rg,
  toml: Cn,
  yaml: Cn,
  definition: Cn,
  footnoteDefinition: Cn
};
function Cn() {
}
const Xo = -1, Un = 0, dn = 1, Fn = 2, ar = 3, sr = 4, ur = 5, cr = 6, Ko = 7, Zo = 8, di = typeof self == "object" ? self : globalThis, _g = (e, n) => {
  const t = (i, l) => (e.set(l, i), i), r = (i) => {
    if (e.has(i))
      return e.get(i);
    const [l, o] = n[i];
    switch (l) {
      case Un:
      case Xo:
        return t(o, i);
      case dn: {
        const a = t([], i);
        for (const s of o)
          a.push(r(s));
        return a;
      }
      case Fn: {
        const a = t({}, i);
        for (const [s, u] of o)
          a[r(s)] = r(u);
        return a;
      }
      case ar:
        return t(new Date(o), i);
      case sr: {
        const { source: a, flags: s } = o;
        return t(new RegExp(a, s), i);
      }
      case ur: {
        const a = t(/* @__PURE__ */ new Map(), i);
        for (const [s, u] of o)
          a.set(r(s), r(u));
        return a;
      }
      case cr: {
        const a = t(/* @__PURE__ */ new Set(), i);
        for (const s of o)
          a.add(r(s));
        return a;
      }
      case Ko: {
        const { name: a, message: s } = o;
        return t(new di[a](s), i);
      }
      case Zo:
        return t(BigInt(o), i);
      case "BigInt":
        return t(Object(BigInt(o)), i);
      case "ArrayBuffer":
        return t(new Uint8Array(o).buffer, o);
      case "DataView": {
        const { buffer: a } = new Uint8Array(o);
        return t(new DataView(a), o);
      }
    }
    return t(new di[l](o), i);
  };
  return r;
}, gi = (e) => _g(/* @__PURE__ */ new Map(), e)(0), We = "", { toString: Fg } = {}, { keys: Dg } = Object, sn = (e) => {
  const n = typeof e;
  if (n !== "object" || !e)
    return [Un, n];
  const t = Fg.call(e).slice(8, -1);
  switch (t) {
    case "Array":
      return [dn, We];
    case "Object":
      return [Fn, We];
    case "Date":
      return [ar, We];
    case "RegExp":
      return [sr, We];
    case "Map":
      return [ur, We];
    case "Set":
      return [cr, We];
    case "DataView":
      return [dn, t];
  }
  return t.includes("Array") ? [dn, t] : t.includes("Error") ? [Ko, t] : [Fn, t];
}, An = ([e, n]) => e === Un && (n === "function" || n === "symbol"), Pg = (e, n, t, r) => {
  const i = (o, a) => {
    const s = r.push(o) - 1;
    return t.set(a, s), s;
  }, l = (o) => {
    if (t.has(o))
      return t.get(o);
    let [a, s] = sn(o);
    switch (a) {
      case Un: {
        let p = o;
        switch (s) {
          case "bigint":
            a = Zo, p = o.toString();
            break;
          case "function":
          case "symbol":
            if (e)
              throw new TypeError("unable to serialize " + s);
            p = null;
            break;
          case "undefined":
            return i([Xo], o);
        }
        return i([a, p], o);
      }
      case dn: {
        if (s) {
          let h = o;
          return s === "DataView" ? h = new Uint8Array(o.buffer) : s === "ArrayBuffer" && (h = new Uint8Array(o)), i([s, [...h]], o);
        }
        const p = [], c = i([a, p], o);
        for (const h of o)
          p.push(l(h));
        return c;
      }
      case Fn: {
        if (s)
          switch (s) {
            case "BigInt":
              return i([s, o.toString()], o);
            case "Boolean":
            case "Number":
            case "String":
              return i([s, o.valueOf()], o);
          }
        if (n && "toJSON" in o)
          return l(o.toJSON());
        const p = [], c = i([a, p], o);
        for (const h of Dg(o))
          (e || !An(sn(o[h]))) && p.push([l(h), l(o[h])]);
        return c;
      }
      case ar:
        return i([a, o.toISOString()], o);
      case sr: {
        const { source: p, flags: c } = o;
        return i([a, { source: p, flags: c }], o);
      }
      case ur: {
        const p = [], c = i([a, p], o);
        for (const [h, f] of o)
          (e || !(An(sn(h)) || An(sn(f)))) && p.push([l(h), l(f)]);
        return c;
      }
      case cr: {
        const p = [], c = i([a, p], o);
        for (const h of o)
          (e || !An(sn(h))) && p.push(l(h));
        return c;
      }
    }
    const { message: u } = o;
    return i([a, { name: s, message: u }], o);
  };
  return l;
}, mi = (e, { json: n, lossy: t } = {}) => {
  const r = [];
  return Pg(!(n || t), !!n, /* @__PURE__ */ new Map(), r)(e), r;
}, Dn = typeof structuredClone == "function" ? (
  /* c8 ignore start */
  (e, n) => n && ("json" in n || "lossy" in n) ? gi(mi(e, n)) : structuredClone(e)
) : (e, n) => gi(mi(e, n));
function zg(e, n) {
  const t = [{ type: "text", value: "↩" }];
  return n > 1 && t.push({
    type: "element",
    tagName: "sup",
    properties: {},
    children: [{ type: "text", value: String(n) }]
  }), t;
}
function Mg(e, n) {
  return "Back to reference " + (e + 1) + (n > 1 ? "-" + n : "");
}
function $g(e) {
  const n = typeof e.options.clobberPrefix == "string" ? e.options.clobberPrefix : "user-content-", t = e.options.footnoteBackContent || zg, r = e.options.footnoteBackLabel || Mg, i = e.options.footnoteLabel || "Footnotes", l = e.options.footnoteLabelTagName || "h2", o = e.options.footnoteLabelProperties || {
    className: ["sr-only"]
  }, a = [];
  let s = -1;
  for (; ++s < e.footnoteOrder.length; ) {
    const u = e.footnoteById.get(
      e.footnoteOrder[s]
    );
    if (!u)
      continue;
    const p = e.all(u), c = String(u.identifier).toUpperCase(), h = nn(c.toLowerCase());
    let f = 0;
    const g = [], v = e.footnoteCounts.get(c);
    for (; v !== void 0 && ++f <= v; ) {
      g.length > 0 && g.push({ type: "text", value: " " });
      let k = typeof t == "string" ? t : t(s, f);
      typeof k == "string" && (k = { type: "text", value: k }), g.push({
        type: "element",
        tagName: "a",
        properties: {
          href: "#" + n + "fnref-" + h + (f > 1 ? "-" + f : ""),
          dataFootnoteBackref: "",
          ariaLabel: typeof r == "string" ? r : r(s, f),
          className: ["data-footnote-backref"]
        },
        children: Array.isArray(k) ? k : [k]
      });
    }
    const A = p[p.length - 1];
    if (A && A.type === "element" && A.tagName === "p") {
      const k = A.children[A.children.length - 1];
      k && k.type === "text" ? k.value += " " : A.children.push({ type: "text", value: " " }), A.children.push(...g);
    } else
      p.push(...g);
    const w = {
      type: "element",
      tagName: "li",
      properties: { id: n + "fn-" + h },
      children: e.wrap(p, !0)
    };
    e.patch(u, w), a.push(w);
  }
  if (a.length !== 0)
    return {
      type: "element",
      tagName: "section",
      properties: { dataFootnotes: !0, className: ["footnotes"] },
      children: [
        {
          type: "element",
          tagName: l,
          properties: {
            ...Dn(o),
            id: "footnote-label"
          },
          children: [{ type: "text", value: i }]
        },
        { type: "text", value: `
` },
        {
          type: "element",
          tagName: "ol",
          properties: {},
          children: e.wrap(a, !0)
        },
        { type: "text", value: `
` }
      ]
    };
}
const Hn = (
  // Note: overloads in JSDoc can’t yet use different `@template`s.
  /**
   * @type {(
   *   (<Condition extends string>(test: Condition) => (node: unknown, index?: number | null | undefined, parent?: Parent | null | undefined, context?: unknown) => node is Node & {type: Condition}) &
   *   (<Condition extends Props>(test: Condition) => (node: unknown, index?: number | null | undefined, parent?: Parent | null | undefined, context?: unknown) => node is Node & Condition) &
   *   (<Condition extends TestFunction>(test: Condition) => (node: unknown, index?: number | null | undefined, parent?: Parent | null | undefined, context?: unknown) => node is Node & Predicate<Condition, Node>) &
   *   ((test?: null | undefined) => (node?: unknown, index?: number | null | undefined, parent?: Parent | null | undefined, context?: unknown) => node is Node) &
   *   ((test?: Test) => Check)
   * )}
   */
  /**
   * @param {Test} [test]
   * @returns {Check}
   */
  function(e) {
    if (e == null)
      return Hg;
    if (typeof e == "function")
      return Vn(e);
    if (typeof e == "object")
      return Array.isArray(e) ? jg(e) : (
        // Cast because `ReadonlyArray` goes into the above but `isArray`
        // narrows to `Array`.
        Bg(
          /** @type {Props} */
          e
        )
      );
    if (typeof e == "string")
      return Ug(e);
    throw new Error("Expected function, string, or object as test");
  }
);
function jg(e) {
  const n = [];
  let t = -1;
  for (; ++t < e.length; )
    n[t] = Hn(e[t]);
  return Vn(r);
  function r(...i) {
    let l = -1;
    for (; ++l < n.length; )
      if (n[l].apply(this, i)) return !0;
    return !1;
  }
}
function Bg(e) {
  const n = (
    /** @type {Record<string, unknown>} */
    e
  );
  return Vn(t);
  function t(r) {
    const i = (
      /** @type {Record<string, unknown>} */
      /** @type {unknown} */
      r
    );
    let l;
    for (l in e)
      if (i[l] !== n[l]) return !1;
    return !0;
  }
}
function Ug(e) {
  return Vn(n);
  function n(t) {
    return t && t.type === e;
  }
}
function Vn(e) {
  return n;
  function n(t, r, i) {
    return !!(Vg(t) && e.call(
      this,
      t,
      typeof r == "number" ? r : void 0,
      i || void 0
    ));
  }
}
function Hg() {
  return !0;
}
function Vg(e) {
  return e !== null && typeof e == "object" && "type" in e;
}
const Qo = [], qg = !0, xt = !1, Gg = "skip";
function Jo(e, n, t, r) {
  let i;
  typeof n == "function" && typeof t != "function" ? (r = t, t = n) : i = n;
  const l = Hn(i), o = r ? -1 : 1;
  a(e, void 0, [])();
  function a(s, u, p) {
    const c = (
      /** @type {Record<string, unknown>} */
      s && typeof s == "object" ? s : {}
    );
    if (typeof c.type == "string") {
      const f = (
        // `hast`
        typeof c.tagName == "string" ? c.tagName : (
          // `xast`
          typeof c.name == "string" ? c.name : void 0
        )
      );
      Object.defineProperty(h, "name", {
        value: "node (" + (s.type + (f ? "<" + f + ">" : "")) + ")"
      });
    }
    return h;
    function h() {
      let f = Qo, g, v, A;
      if ((!n || l(s, u, p[p.length - 1] || void 0)) && (f = Wg(t(s, p)), f[0] === xt))
        return f;
      if ("children" in s && s.children) {
        const w = (
          /** @type {UnistParent} */
          s
        );
        if (w.children && f[0] !== Gg)
          for (v = (r ? w.children.length : -1) + o, A = p.concat(w); v > -1 && v < w.children.length; ) {
            const k = w.children[v];
            if (g = a(k, v, A)(), g[0] === xt)
              return g;
            v = typeof g[1] == "number" ? g[1] : v + o;
          }
      }
      return f;
    }
  }
}
function Wg(e) {
  return Array.isArray(e) ? e : typeof e == "number" ? [qg, e] : e == null ? Qo : [e];
}
function pr(e, n, t, r) {
  let i, l, o;
  typeof n == "function" && typeof t != "function" ? (l = void 0, o = n, i = t) : (l = n, o = t, i = r), Jo(e, l, a, i);
  function a(s, u) {
    const p = u[u.length - 1], c = p ? p.children.indexOf(s) : void 0;
    return o(s, c, p);
  }
}
const wt = {}.hasOwnProperty, Yg = {};
function Xg(e, n) {
  const t = n || Yg, r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Map(), o = { ...Ng, ...t.handlers }, a = {
    all: u,
    applyData: Zg,
    definitionById: r,
    footnoteById: i,
    footnoteCounts: l,
    footnoteOrder: [],
    handlers: o,
    one: s,
    options: t,
    patch: Kg,
    wrap: Jg
  };
  return pr(e, function(p) {
    if (p.type === "definition" || p.type === "footnoteDefinition") {
      const c = p.type === "definition" ? r : i, h = String(p.identifier).toUpperCase();
      c.has(h) || c.set(h, p);
    }
  }), a;
  function s(p, c) {
    const h = p.type, f = a.handlers[h];
    if (wt.call(a.handlers, h) && f)
      return f(a, p, c);
    if (a.options.passThrough && a.options.passThrough.includes(h)) {
      if ("children" in p) {
        const { children: v, ...A } = p, w = Dn(A);
        return w.children = a.all(p), w;
      }
      return Dn(p);
    }
    return (a.options.unknownHandler || Qg)(a, p, c);
  }
  function u(p) {
    const c = [];
    if ("children" in p) {
      const h = p.children;
      let f = -1;
      for (; ++f < h.length; ) {
        const g = a.one(h[f], p);
        if (g) {
          if (f && h[f - 1].type === "break" && (!Array.isArray(g) && g.type === "text" && (g.value = bi(g.value)), !Array.isArray(g) && g.type === "element")) {
            const v = g.children[0];
            v && v.type === "text" && (v.value = bi(v.value));
          }
          Array.isArray(g) ? c.push(...g) : c.push(g);
        }
      }
    }
    return c;
  }
}
function Kg(e, n) {
  e.position && (n.position = Mf(e));
}
function Zg(e, n) {
  let t = n;
  if (e && e.data) {
    const r = e.data.hName, i = e.data.hChildren, l = e.data.hProperties;
    if (typeof r == "string")
      if (t.type === "element")
        t.tagName = r;
      else {
        const o = "children" in t ? t.children : [t];
        t = { type: "element", tagName: r, properties: {}, children: o };
      }
    t.type === "element" && l && Object.assign(t.properties, Dn(l)), "children" in t && t.children && i !== null && i !== void 0 && (t.children = i);
  }
  return t;
}
function Qg(e, n) {
  const t = n.data || {}, r = "value" in n && !(wt.call(t, "hProperties") || wt.call(t, "hChildren")) ? { type: "text", value: n.value } : {
    type: "element",
    tagName: "div",
    properties: {},
    children: e.all(n)
  };
  return e.patch(n, r), e.applyData(n, r);
}
function Jg(e, n) {
  const t = [];
  let r = -1;
  for (n && t.push({ type: "text", value: `
` }); ++r < e.length; )
    r && t.push({ type: "text", value: `
` }), t.push(e[r]);
  return n && e.length > 0 && t.push({ type: "text", value: `
` }), t;
}
function bi(e) {
  let n = 0, t = e.charCodeAt(n);
  for (; t === 9 || t === 32; )
    n++, t = e.charCodeAt(n);
  return e.slice(n);
}
function yi(e, n) {
  const t = Xg(e, n), r = t.one(e, void 0), i = $g(t), l = Array.isArray(r) ? { type: "root", children: r } : r || { type: "root", children: [] };
  return i && l.children.push({ type: "text", value: `
` }, i), l;
}
function em(e, n) {
  return e && "run" in e ? async function(t, r) {
    const i = (
      /** @type {HastRoot} */
      yi(t, { file: r, ...n })
    );
    await e.run(i, r);
  } : function(t, r) {
    return (
      /** @type {HastRoot} */
      yi(t, { file: r, ...e || n })
    );
  };
}
function ki(e) {
  if (e)
    throw e;
}
var Nn = Object.prototype.hasOwnProperty, el = Object.prototype.toString, xi = Object.defineProperty, wi = Object.getOwnPropertyDescriptor, vi = function(n) {
  return typeof Array.isArray == "function" ? Array.isArray(n) : el.call(n) === "[object Array]";
}, Si = function(n) {
  if (!n || el.call(n) !== "[object Object]")
    return !1;
  var t = Nn.call(n, "constructor"), r = n.constructor && n.constructor.prototype && Nn.call(n.constructor.prototype, "isPrototypeOf");
  if (n.constructor && !t && !r)
    return !1;
  var i;
  for (i in n)
    ;
  return typeof i > "u" || Nn.call(n, i);
}, Ei = function(n, t) {
  xi && t.name === "__proto__" ? xi(n, t.name, {
    enumerable: !0,
    configurable: !0,
    value: t.newValue,
    writable: !0
  }) : n[t.name] = t.newValue;
}, Ci = function(n, t) {
  if (t === "__proto__")
    if (Nn.call(n, t)) {
      if (wi)
        return wi(n, t).value;
    } else return;
  return n[t];
}, nm = function e() {
  var n, t, r, i, l, o, a = arguments[0], s = 1, u = arguments.length, p = !1;
  for (typeof a == "boolean" && (p = a, a = arguments[1] || {}, s = 2), (a == null || typeof a != "object" && typeof a != "function") && (a = {}); s < u; ++s)
    if (n = arguments[s], n != null)
      for (t in n)
        r = Ci(a, t), i = Ci(n, t), a !== i && (p && i && (Si(i) || (l = vi(i))) ? (l ? (l = !1, o = r && vi(r) ? r : []) : o = r && Si(r) ? r : {}, Ei(a, { name: t, newValue: e(p, o, i) })) : typeof i < "u" && Ei(a, { name: t, newValue: i }));
  return a;
};
const Zn = /* @__PURE__ */ he(nm);
function vt(e) {
  if (typeof e != "object" || e === null)
    return !1;
  const n = Object.getPrototypeOf(e);
  return (n === null || n === Object.prototype || Object.getPrototypeOf(n) === null) && !(Symbol.toStringTag in e) && !(Symbol.iterator in e);
}
function tm() {
  const e = [], n = { run: t, use: r };
  return n;
  function t(...i) {
    let l = -1;
    const o = i.pop();
    if (typeof o != "function")
      throw new TypeError("Expected function as last argument, not " + o);
    a(null, ...i);
    function a(s, ...u) {
      const p = e[++l];
      let c = -1;
      if (s) {
        o(s);
        return;
      }
      for (; ++c < i.length; )
        (u[c] === null || u[c] === void 0) && (u[c] = i[c]);
      i = u, p ? rm(p, a)(...u) : o(null, ...u);
    }
  }
  function r(i) {
    if (typeof i != "function")
      throw new TypeError(
        "Expected `middelware` to be a function, not " + i
      );
    return e.push(i), n;
  }
}
function rm(e, n) {
  let t;
  return r;
  function r(...o) {
    const a = e.length > o.length;
    let s;
    a && o.push(i);
    try {
      s = e.apply(this, o);
    } catch (u) {
      const p = (
        /** @type {Error} */
        u
      );
      if (a && t)
        throw p;
      return i(p);
    }
    a || (s && s.then && typeof s.then == "function" ? s.then(l, i) : s instanceof Error ? i(s) : l(s));
  }
  function i(o, ...a) {
    t || (t = !0, n(o, ...a));
  }
  function l(o) {
    i(null, o);
  }
}
const Ae = { basename: im, dirname: om, extname: lm, join: am, sep: "/" };
function im(e, n) {
  if (n !== void 0 && typeof n != "string")
    throw new TypeError('"ext" argument must be a string');
  vn(e);
  let t = 0, r = -1, i = e.length, l;
  if (n === void 0 || n.length === 0 || n.length > e.length) {
    for (; i--; )
      if (e.codePointAt(i) === 47) {
        if (l) {
          t = i + 1;
          break;
        }
      } else r < 0 && (l = !0, r = i + 1);
    return r < 0 ? "" : e.slice(t, r);
  }
  if (n === e)
    return "";
  let o = -1, a = n.length - 1;
  for (; i--; )
    if (e.codePointAt(i) === 47) {
      if (l) {
        t = i + 1;
        break;
      }
    } else
      o < 0 && (l = !0, o = i + 1), a > -1 && (e.codePointAt(i) === n.codePointAt(a--) ? a < 0 && (r = i) : (a = -1, r = o));
  return t === r ? r = o : r < 0 && (r = e.length), e.slice(t, r);
}
function om(e) {
  if (vn(e), e.length === 0)
    return ".";
  let n = -1, t = e.length, r;
  for (; --t; )
    if (e.codePointAt(t) === 47) {
      if (r) {
        n = t;
        break;
      }
    } else r || (r = !0);
  return n < 0 ? e.codePointAt(0) === 47 ? "/" : "." : n === 1 && e.codePointAt(0) === 47 ? "//" : e.slice(0, n);
}
function lm(e) {
  vn(e);
  let n = e.length, t = -1, r = 0, i = -1, l = 0, o;
  for (; n--; ) {
    const a = e.codePointAt(n);
    if (a === 47) {
      if (o) {
        r = n + 1;
        break;
      }
      continue;
    }
    t < 0 && (o = !0, t = n + 1), a === 46 ? i < 0 ? i = n : l !== 1 && (l = 1) : i > -1 && (l = -1);
  }
  return i < 0 || t < 0 || // We saw a non-dot character immediately before the dot.
  l === 0 || // The (right-most) trimmed path component is exactly `..`.
  l === 1 && i === t - 1 && i === r + 1 ? "" : e.slice(i, t);
}
function am(...e) {
  let n = -1, t;
  for (; ++n < e.length; )
    vn(e[n]), e[n] && (t = t === void 0 ? e[n] : t + "/" + e[n]);
  return t === void 0 ? "." : sm(t);
}
function sm(e) {
  vn(e);
  const n = e.codePointAt(0) === 47;
  let t = um(e, !n);
  return t.length === 0 && !n && (t = "."), t.length > 0 && e.codePointAt(e.length - 1) === 47 && (t += "/"), n ? "/" + t : t;
}
function um(e, n) {
  let t = "", r = 0, i = -1, l = 0, o = -1, a, s;
  for (; ++o <= e.length; ) {
    if (o < e.length)
      a = e.codePointAt(o);
    else {
      if (a === 47)
        break;
      a = 47;
    }
    if (a === 47) {
      if (!(i === o - 1 || l === 1)) if (i !== o - 1 && l === 2) {
        if (t.length < 2 || r !== 2 || t.codePointAt(t.length - 1) !== 46 || t.codePointAt(t.length - 2) !== 46) {
          if (t.length > 2) {
            if (s = t.lastIndexOf("/"), s !== t.length - 1) {
              s < 0 ? (t = "", r = 0) : (t = t.slice(0, s), r = t.length - 1 - t.lastIndexOf("/")), i = o, l = 0;
              continue;
            }
          } else if (t.length > 0) {
            t = "", r = 0, i = o, l = 0;
            continue;
          }
        }
        n && (t = t.length > 0 ? t + "/.." : "..", r = 2);
      } else
        t.length > 0 ? t += "/" + e.slice(i + 1, o) : t = e.slice(i + 1, o), r = o - i - 1;
      i = o, l = 0;
    } else a === 46 && l > -1 ? l++ : l = -1;
  }
  return t;
}
function vn(e) {
  if (typeof e != "string")
    throw new TypeError(
      "Path must be a string. Received " + JSON.stringify(e)
    );
}
const cm = { cwd: pm };
function pm() {
  return "/";
}
function St(e) {
  return !!(e !== null && typeof e == "object" && "href" in e && e.href && "protocol" in e && e.protocol && // @ts-expect-error: indexing is fine.
  e.auth === void 0);
}
function fm(e) {
  if (typeof e == "string")
    e = new URL(e);
  else if (!St(e)) {
    const n = new TypeError(
      'The "path" argument must be of type string or an instance of URL. Received `' + e + "`"
    );
    throw n.code = "ERR_INVALID_ARG_TYPE", n;
  }
  if (e.protocol !== "file:") {
    const n = new TypeError("The URL must be of scheme file");
    throw n.code = "ERR_INVALID_URL_SCHEME", n;
  }
  return hm(e);
}
function hm(e) {
  if (e.hostname !== "") {
    const r = new TypeError(
      'File URL host must be "localhost" or empty on darwin'
    );
    throw r.code = "ERR_INVALID_FILE_URL_HOST", r;
  }
  const n = e.pathname;
  let t = -1;
  for (; ++t < n.length; )
    if (n.codePointAt(t) === 37 && n.codePointAt(t + 1) === 50) {
      const r = n.codePointAt(t + 2);
      if (r === 70 || r === 102) {
        const i = new TypeError(
          "File URL path must not include encoded / characters"
        );
        throw i.code = "ERR_INVALID_FILE_URL_PATH", i;
      }
    }
  return decodeURIComponent(n);
}
const Qn = (
  /** @type {const} */
  [
    "history",
    "path",
    "basename",
    "stem",
    "extname",
    "dirname"
  ]
);
class nl {
  /**
   * Create a new virtual file.
   *
   * `options` is treated as:
   *
   * *   `string` or `Uint8Array` — `{value: options}`
   * *   `URL` — `{path: options}`
   * *   `VFile` — shallow copies its data over to the new file
   * *   `object` — all fields are shallow copied over to the new file
   *
   * Path related fields are set in the following order (least specific to
   * most specific): `history`, `path`, `basename`, `stem`, `extname`,
   * `dirname`.
   *
   * You cannot set `dirname` or `extname` without setting either `history`,
   * `path`, `basename`, or `stem` too.
   *
   * @param {Compatible | null | undefined} [value]
   *   File value.
   * @returns
   *   New instance.
   */
  constructor(n) {
    let t;
    n ? St(n) ? t = { path: n } : typeof n == "string" || dm(n) ? t = { value: n } : t = n : t = {}, this.cwd = "cwd" in t ? "" : cm.cwd(), this.data = {}, this.history = [], this.messages = [], this.value, this.map, this.result, this.stored;
    let r = -1;
    for (; ++r < Qn.length; ) {
      const l = Qn[r];
      l in t && t[l] !== void 0 && t[l] !== null && (this[l] = l === "history" ? [...t[l]] : t[l]);
    }
    let i;
    for (i in t)
      Qn.includes(i) || (this[i] = t[i]);
  }
  /**
   * Get the basename (including extname) (example: `'index.min.js'`).
   *
   * @returns {string | undefined}
   *   Basename.
   */
  get basename() {
    return typeof this.path == "string" ? Ae.basename(this.path) : void 0;
  }
  /**
   * Set basename (including extname) (`'index.min.js'`).
   *
   * Cannot contain path separators (`'/'` on unix, macOS, and browsers, `'\'`
   * on windows).
   * Cannot be nullified (use `file.path = file.dirname` instead).
   *
   * @param {string} basename
   *   Basename.
   * @returns {undefined}
   *   Nothing.
   */
  set basename(n) {
    et(n, "basename"), Jn(n, "basename"), this.path = Ae.join(this.dirname || "", n);
  }
  /**
   * Get the parent path (example: `'~'`).
   *
   * @returns {string | undefined}
   *   Dirname.
   */
  get dirname() {
    return typeof this.path == "string" ? Ae.dirname(this.path) : void 0;
  }
  /**
   * Set the parent path (example: `'~'`).
   *
   * Cannot be set if there’s no `path` yet.
   *
   * @param {string | undefined} dirname
   *   Dirname.
   * @returns {undefined}
   *   Nothing.
   */
  set dirname(n) {
    Ai(this.basename, "dirname"), this.path = Ae.join(n || "", this.basename);
  }
  /**
   * Get the extname (including dot) (example: `'.js'`).
   *
   * @returns {string | undefined}
   *   Extname.
   */
  get extname() {
    return typeof this.path == "string" ? Ae.extname(this.path) : void 0;
  }
  /**
   * Set the extname (including dot) (example: `'.js'`).
   *
   * Cannot contain path separators (`'/'` on unix, macOS, and browsers, `'\'`
   * on windows).
   * Cannot be set if there’s no `path` yet.
   *
   * @param {string | undefined} extname
   *   Extname.
   * @returns {undefined}
   *   Nothing.
   */
  set extname(n) {
    if (Jn(n, "extname"), Ai(this.dirname, "extname"), n) {
      if (n.codePointAt(0) !== 46)
        throw new Error("`extname` must start with `.`");
      if (n.includes(".", 1))
        throw new Error("`extname` cannot contain multiple dots");
    }
    this.path = Ae.join(this.dirname, this.stem + (n || ""));
  }
  /**
   * Get the full path (example: `'~/index.min.js'`).
   *
   * @returns {string}
   *   Path.
   */
  get path() {
    return this.history[this.history.length - 1];
  }
  /**
   * Set the full path (example: `'~/index.min.js'`).
   *
   * Cannot be nullified.
   * You can set a file URL (a `URL` object with a `file:` protocol) which will
   * be turned into a path with `url.fileURLToPath`.
   *
   * @param {URL | string} path
   *   Path.
   * @returns {undefined}
   *   Nothing.
   */
  set path(n) {
    St(n) && (n = fm(n)), et(n, "path"), this.path !== n && this.history.push(n);
  }
  /**
   * Get the stem (basename w/o extname) (example: `'index.min'`).
   *
   * @returns {string | undefined}
   *   Stem.
   */
  get stem() {
    return typeof this.path == "string" ? Ae.basename(this.path, this.extname) : void 0;
  }
  /**
   * Set the stem (basename w/o extname) (example: `'index.min'`).
   *
   * Cannot contain path separators (`'/'` on unix, macOS, and browsers, `'\'`
   * on windows).
   * Cannot be nullified (use `file.path = file.dirname` instead).
   *
   * @param {string} stem
   *   Stem.
   * @returns {undefined}
   *   Nothing.
   */
  set stem(n) {
    et(n, "stem"), Jn(n, "stem"), this.path = Ae.join(this.dirname || "", n + (this.extname || ""));
  }
  // Normal prototypal methods.
  /**
   * Create a fatal message for `reason` associated with the file.
   *
   * The `fatal` field of the message is set to `true` (error; file not usable)
   * and the `file` field is set to the current file path.
   * The message is added to the `messages` field on `file`.
   *
   * > 🪦 **Note**: also has obsolete signatures.
   *
   * @overload
   * @param {string} reason
   * @param {MessageOptions | null | undefined} [options]
   * @returns {never}
   *
   * @overload
   * @param {string} reason
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns {never}
   *
   * @overload
   * @param {string} reason
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns {never}
   *
   * @overload
   * @param {string} reason
   * @param {string | null | undefined} [origin]
   * @returns {never}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns {never}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns {never}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {string | null | undefined} [origin]
   * @returns {never}
   *
   * @param {Error | VFileMessage | string} causeOrReason
   *   Reason for message, should use markdown.
   * @param {Node | NodeLike | MessageOptions | Point | Position | string | null | undefined} [optionsOrParentOrPlace]
   *   Configuration (optional).
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (example:
   *   `'my-package:my-rule'` or `'my-rule'`).
   * @returns {never}
   *   Never.
   * @throws {VFileMessage}
   *   Message.
   */
  fail(n, t, r) {
    const i = this.message(n, t, r);
    throw i.fatal = !0, i;
  }
  /**
   * Create an info message for `reason` associated with the file.
   *
   * The `fatal` field of the message is set to `undefined` (info; change
   * likely not needed) and the `file` field is set to the current file path.
   * The message is added to the `messages` field on `file`.
   *
   * > 🪦 **Note**: also has obsolete signatures.
   *
   * @overload
   * @param {string} reason
   * @param {MessageOptions | null | undefined} [options]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {string} reason
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {string} reason
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {string} reason
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @param {Error | VFileMessage | string} causeOrReason
   *   Reason for message, should use markdown.
   * @param {Node | NodeLike | MessageOptions | Point | Position | string | null | undefined} [optionsOrParentOrPlace]
   *   Configuration (optional).
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (example:
   *   `'my-package:my-rule'` or `'my-rule'`).
   * @returns {VFileMessage}
   *   Message.
   */
  info(n, t, r) {
    const i = this.message(n, t, r);
    return i.fatal = void 0, i;
  }
  /**
   * Create a message for `reason` associated with the file.
   *
   * The `fatal` field of the message is set to `false` (warning; change may be
   * needed) and the `file` field is set to the current file path.
   * The message is added to the `messages` field on `file`.
   *
   * > 🪦 **Note**: also has obsolete signatures.
   *
   * @overload
   * @param {string} reason
   * @param {MessageOptions | null | undefined} [options]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {string} reason
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {string} reason
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {string} reason
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @param {Error | VFileMessage | string} causeOrReason
   *   Reason for message, should use markdown.
   * @param {Node | NodeLike | MessageOptions | Point | Position | string | null | undefined} [optionsOrParentOrPlace]
   *   Configuration (optional).
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (example:
   *   `'my-package:my-rule'` or `'my-rule'`).
   * @returns {VFileMessage}
   *   Message.
   */
  message(n, t, r) {
    const i = new se(
      // @ts-expect-error: the overloads are fine.
      n,
      t,
      r
    );
    return this.path && (i.name = this.path + ":" + i.name, i.file = this.path), i.fatal = !1, this.messages.push(i), i;
  }
  /**
   * Serialize the file.
   *
   * > **Note**: which encodings are supported depends on the engine.
   * > For info on Node.js, see:
   * > <https://nodejs.org/api/util.html#whatwg-supported-encodings>.
   *
   * @param {string | null | undefined} [encoding='utf8']
   *   Character encoding to understand `value` as when it’s a `Uint8Array`
   *   (default: `'utf-8'`).
   * @returns {string}
   *   Serialized file.
   */
  toString(n) {
    return this.value === void 0 ? "" : typeof this.value == "string" ? this.value : new TextDecoder(n || void 0).decode(this.value);
  }
}
function Jn(e, n) {
  if (e && e.includes(Ae.sep))
    throw new Error(
      "`" + n + "` cannot be a path: did not expect `" + Ae.sep + "`"
    );
}
function et(e, n) {
  if (!e)
    throw new Error("`" + n + "` cannot be empty");
}
function Ai(e, n) {
  if (!e)
    throw new Error("Setting `" + n + "` requires `path` to be set too");
}
function dm(e) {
  return !!(e && typeof e == "object" && "byteLength" in e && "byteOffset" in e);
}
const gm = (
  /**
   * @type {new <Parameters extends Array<unknown>, Result>(property: string | symbol) => (...parameters: Parameters) => Result}
   */
  /** @type {unknown} */
  /**
   * @this {Function}
   * @param {string | symbol} property
   * @returns {(...parameters: Array<unknown>) => unknown}
   */
  function(e) {
    const r = (
      /** @type {Record<string | symbol, Function>} */
      // Prototypes do exist.
      // type-coverage:ignore-next-line
      this.constructor.prototype
    ), i = r[e], l = function() {
      return i.apply(l, arguments);
    };
    return Object.setPrototypeOf(l, r), l;
  }
), mm = {}.hasOwnProperty;
class fr extends gm {
  /**
   * Create a processor.
   */
  constructor() {
    super("copy"), this.Compiler = void 0, this.Parser = void 0, this.attachers = [], this.compiler = void 0, this.freezeIndex = -1, this.frozen = void 0, this.namespace = {}, this.parser = void 0, this.transformers = tm();
  }
  /**
   * Copy a processor.
   *
   * @deprecated
   *   This is a private internal method and should not be used.
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *   New *unfrozen* processor ({@linkcode Processor}) that is
   *   configured to work the same as its ancestor.
   *   When the descendant processor is configured in the future it does not
   *   affect the ancestral processor.
   */
  copy() {
    const n = (
      /** @type {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>} */
      new fr()
    );
    let t = -1;
    for (; ++t < this.attachers.length; ) {
      const r = this.attachers[t];
      n.use(...r);
    }
    return n.data(Zn(!0, {}, this.namespace)), n;
  }
  /**
   * Configure the processor with info available to all plugins.
   * Information is stored in an object.
   *
   * Typically, options can be given to a specific plugin, but sometimes it
   * makes sense to have information shared with several plugins.
   * For example, a list of HTML elements that are self-closing, which is
   * needed during all phases.
   *
   * > **Note**: setting information cannot occur on *frozen* processors.
   * > Call the processor first to create a new unfrozen processor.
   *
   * > **Note**: to register custom data in TypeScript, augment the
   * > {@linkcode Data} interface.
   *
   * @example
   *   This example show how to get and set info:
   *
   *   ```js
   *   import {unified} from 'unified'
   *
   *   const processor = unified().data('alpha', 'bravo')
   *
   *   processor.data('alpha') // => 'bravo'
   *
   *   processor.data() // => {alpha: 'bravo'}
   *
   *   processor.data({charlie: 'delta'})
   *
   *   processor.data() // => {charlie: 'delta'}
   *   ```
   *
   * @template {keyof Data} Key
   *
   * @overload
   * @returns {Data}
   *
   * @overload
   * @param {Data} dataset
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *
   * @overload
   * @param {Key} key
   * @returns {Data[Key]}
   *
   * @overload
   * @param {Key} key
   * @param {Data[Key]} value
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *
   * @param {Data | Key} [key]
   *   Key to get or set, or entire dataset to set, or nothing to get the
   *   entire dataset (optional).
   * @param {Data[Key]} [value]
   *   Value to set (optional).
   * @returns {unknown}
   *   The current processor when setting, the value at `key` when getting, or
   *   the entire dataset when getting without key.
   */
  data(n, t) {
    return typeof n == "string" ? arguments.length === 2 ? (rt("data", this.frozen), this.namespace[n] = t, this) : mm.call(this.namespace, n) && this.namespace[n] || void 0 : n ? (rt("data", this.frozen), this.namespace = n, this) : this.namespace;
  }
  /**
   * Freeze a processor.
   *
   * Frozen processors are meant to be extended and not to be configured
   * directly.
   *
   * When a processor is frozen it cannot be unfrozen.
   * New processors working the same way can be created by calling the
   * processor.
   *
   * It’s possible to freeze processors explicitly by calling `.freeze()`.
   * Processors freeze automatically when `.parse()`, `.run()`, `.runSync()`,
   * `.stringify()`, `.process()`, or `.processSync()` are called.
   *
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *   The current processor.
   */
  freeze() {
    if (this.frozen)
      return this;
    const n = (
      /** @type {Processor} */
      /** @type {unknown} */
      this
    );
    for (; ++this.freezeIndex < this.attachers.length; ) {
      const [t, ...r] = this.attachers[this.freezeIndex];
      if (r[0] === !1)
        continue;
      r[0] === !0 && (r[0] = void 0);
      const i = t.call(n, ...r);
      typeof i == "function" && this.transformers.use(i);
    }
    return this.frozen = !0, this.freezeIndex = Number.POSITIVE_INFINITY, this;
  }
  /**
   * Parse text to a syntax tree.
   *
   * > **Note**: `parse` freezes the processor if not already *frozen*.
   *
   * > **Note**: `parse` performs the parse phase, not the run phase or other
   * > phases.
   *
   * @param {Compatible | undefined} [file]
   *   file to parse (optional); typically `string` or `VFile`; any value
   *   accepted as `x` in `new VFile(x)`.
   * @returns {ParseTree extends undefined ? Node : ParseTree}
   *   Syntax tree representing `file`.
   */
  parse(n) {
    this.freeze();
    const t = Tn(n), r = this.parser || this.Parser;
    return nt("parse", r), r(String(t), t);
  }
  /**
   * Process the given file as configured on the processor.
   *
   * > **Note**: `process` freezes the processor if not already *frozen*.
   *
   * > **Note**: `process` performs the parse, run, and stringify phases.
   *
   * @overload
   * @param {Compatible | undefined} file
   * @param {ProcessCallback<VFileWithOutput<CompileResult>>} done
   * @returns {undefined}
   *
   * @overload
   * @param {Compatible | undefined} [file]
   * @returns {Promise<VFileWithOutput<CompileResult>>}
   *
   * @param {Compatible | undefined} [file]
   *   File (optional); typically `string` or `VFile`]; any value accepted as
   *   `x` in `new VFile(x)`.
   * @param {ProcessCallback<VFileWithOutput<CompileResult>> | undefined} [done]
   *   Callback (optional).
   * @returns {Promise<VFile> | undefined}
   *   Nothing if `done` is given.
   *   Otherwise a promise, rejected with a fatal error or resolved with the
   *   processed file.
   *
   *   The parsed, transformed, and compiled value is available at
   *   `file.value` (see note).
   *
   *   > **Note**: unified typically compiles by serializing: most
   *   > compilers return `string` (or `Uint8Array`).
   *   > Some compilers, such as the one configured with
   *   > [`rehype-react`][rehype-react], return other values (in this case, a
   *   > React tree).
   *   > If you’re using a compiler that doesn’t serialize, expect different
   *   > result values.
   *   >
   *   > To register custom results in TypeScript, add them to
   *   > {@linkcode CompileResultMap}.
   *
   *   [rehype-react]: https://github.com/rehypejs/rehype-react
   */
  process(n, t) {
    const r = this;
    return this.freeze(), nt("process", this.parser || this.Parser), tt("process", this.compiler || this.Compiler), t ? i(void 0, t) : new Promise(i);
    function i(l, o) {
      const a = Tn(n), s = (
        /** @type {HeadTree extends undefined ? Node : HeadTree} */
        /** @type {unknown} */
        r.parse(a)
      );
      r.run(s, a, function(p, c, h) {
        if (p || !c || !h)
          return u(p);
        const f = (
          /** @type {CompileTree extends undefined ? Node : CompileTree} */
          /** @type {unknown} */
          c
        ), g = r.stringify(f, h);
        km(g) ? h.value = g : h.result = g, u(
          p,
          /** @type {VFileWithOutput<CompileResult>} */
          h
        );
      });
      function u(p, c) {
        p || !c ? o(p) : l ? l(c) : t(void 0, c);
      }
    }
  }
  /**
   * Process the given file as configured on the processor.
   *
   * An error is thrown if asynchronous transforms are configured.
   *
   * > **Note**: `processSync` freezes the processor if not already *frozen*.
   *
   * > **Note**: `processSync` performs the parse, run, and stringify phases.
   *
   * @param {Compatible | undefined} [file]
   *   File (optional); typically `string` or `VFile`; any value accepted as
   *   `x` in `new VFile(x)`.
   * @returns {VFileWithOutput<CompileResult>}
   *   The processed file.
   *
   *   The parsed, transformed, and compiled value is available at
   *   `file.value` (see note).
   *
   *   > **Note**: unified typically compiles by serializing: most
   *   > compilers return `string` (or `Uint8Array`).
   *   > Some compilers, such as the one configured with
   *   > [`rehype-react`][rehype-react], return other values (in this case, a
   *   > React tree).
   *   > If you’re using a compiler that doesn’t serialize, expect different
   *   > result values.
   *   >
   *   > To register custom results in TypeScript, add them to
   *   > {@linkcode CompileResultMap}.
   *
   *   [rehype-react]: https://github.com/rehypejs/rehype-react
   */
  processSync(n) {
    let t = !1, r;
    return this.freeze(), nt("processSync", this.parser || this.Parser), tt("processSync", this.compiler || this.Compiler), this.process(n, i), Ii("processSync", "process", t), r;
    function i(l, o) {
      t = !0, ki(l), r = o;
    }
  }
  /**
   * Run *transformers* on a syntax tree.
   *
   * > **Note**: `run` freezes the processor if not already *frozen*.
   *
   * > **Note**: `run` performs the run phase, not other phases.
   *
   * @overload
   * @param {HeadTree extends undefined ? Node : HeadTree} tree
   * @param {RunCallback<TailTree extends undefined ? Node : TailTree>} done
   * @returns {undefined}
   *
   * @overload
   * @param {HeadTree extends undefined ? Node : HeadTree} tree
   * @param {Compatible | undefined} file
   * @param {RunCallback<TailTree extends undefined ? Node : TailTree>} done
   * @returns {undefined}
   *
   * @overload
   * @param {HeadTree extends undefined ? Node : HeadTree} tree
   * @param {Compatible | undefined} [file]
   * @returns {Promise<TailTree extends undefined ? Node : TailTree>}
   *
   * @param {HeadTree extends undefined ? Node : HeadTree} tree
   *   Tree to transform and inspect.
   * @param {(
   *   RunCallback<TailTree extends undefined ? Node : TailTree> |
   *   Compatible
   * )} [file]
   *   File associated with `node` (optional); any value accepted as `x` in
   *   `new VFile(x)`.
   * @param {RunCallback<TailTree extends undefined ? Node : TailTree>} [done]
   *   Callback (optional).
   * @returns {Promise<TailTree extends undefined ? Node : TailTree> | undefined}
   *   Nothing if `done` is given.
   *   Otherwise, a promise rejected with a fatal error or resolved with the
   *   transformed tree.
   */
  run(n, t, r) {
    Ti(n), this.freeze();
    const i = this.transformers;
    return !r && typeof t == "function" && (r = t, t = void 0), r ? l(void 0, r) : new Promise(l);
    function l(o, a) {
      const s = Tn(t);
      i.run(n, s, u);
      function u(p, c, h) {
        const f = (
          /** @type {TailTree extends undefined ? Node : TailTree} */
          c || n
        );
        p ? a(p) : o ? o(f) : r(void 0, f, h);
      }
    }
  }
  /**
   * Run *transformers* on a syntax tree.
   *
   * An error is thrown if asynchronous transforms are configured.
   *
   * > **Note**: `runSync` freezes the processor if not already *frozen*.
   *
   * > **Note**: `runSync` performs the run phase, not other phases.
   *
   * @param {HeadTree extends undefined ? Node : HeadTree} tree
   *   Tree to transform and inspect.
   * @param {Compatible | undefined} [file]
   *   File associated with `node` (optional); any value accepted as `x` in
   *   `new VFile(x)`.
   * @returns {TailTree extends undefined ? Node : TailTree}
   *   Transformed tree.
   */
  runSync(n, t) {
    let r = !1, i;
    return this.run(n, t, l), Ii("runSync", "run", r), i;
    function l(o, a) {
      ki(o), i = a, r = !0;
    }
  }
  /**
   * Compile a syntax tree.
   *
   * > **Note**: `stringify` freezes the processor if not already *frozen*.
   *
   * > **Note**: `stringify` performs the stringify phase, not the run phase
   * > or other phases.
   *
   * @param {CompileTree extends undefined ? Node : CompileTree} tree
   *   Tree to compile.
   * @param {Compatible | undefined} [file]
   *   File associated with `node` (optional); any value accepted as `x` in
   *   `new VFile(x)`.
   * @returns {CompileResult extends undefined ? Value : CompileResult}
   *   Textual representation of the tree (see note).
   *
   *   > **Note**: unified typically compiles by serializing: most compilers
   *   > return `string` (or `Uint8Array`).
   *   > Some compilers, such as the one configured with
   *   > [`rehype-react`][rehype-react], return other values (in this case, a
   *   > React tree).
   *   > If you’re using a compiler that doesn’t serialize, expect different
   *   > result values.
   *   >
   *   > To register custom results in TypeScript, add them to
   *   > {@linkcode CompileResultMap}.
   *
   *   [rehype-react]: https://github.com/rehypejs/rehype-react
   */
  stringify(n, t) {
    this.freeze();
    const r = Tn(t), i = this.compiler || this.Compiler;
    return tt("stringify", i), Ti(n), i(n, r);
  }
  /**
   * Configure the processor to use a plugin, a list of usable values, or a
   * preset.
   *
   * If the processor is already using a plugin, the previous plugin
   * configuration is changed based on the options that are passed in.
   * In other words, the plugin is not added a second time.
   *
   * > **Note**: `use` cannot be called on *frozen* processors.
   * > Call the processor first to create a new unfrozen processor.
   *
   * @example
   *   There are many ways to pass plugins to `.use()`.
   *   This example gives an overview:
   *
   *   ```js
   *   import {unified} from 'unified'
   *
   *   unified()
   *     // Plugin with options:
   *     .use(pluginA, {x: true, y: true})
   *     // Passing the same plugin again merges configuration (to `{x: true, y: false, z: true}`):
   *     .use(pluginA, {y: false, z: true})
   *     // Plugins:
   *     .use([pluginB, pluginC])
   *     // Two plugins, the second with options:
   *     .use([pluginD, [pluginE, {}]])
   *     // Preset with plugins and settings:
   *     .use({plugins: [pluginF, [pluginG, {}]], settings: {position: false}})
   *     // Settings only:
   *     .use({settings: {position: false}})
   *   ```
   *
   * @template {Array<unknown>} [Parameters=[]]
   * @template {Node | string | undefined} [Input=undefined]
   * @template [Output=Input]
   *
   * @overload
   * @param {Preset | null | undefined} [preset]
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *
   * @overload
   * @param {PluggableList} list
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *
   * @overload
   * @param {Plugin<Parameters, Input, Output>} plugin
   * @param {...(Parameters | [boolean])} parameters
   * @returns {UsePlugin<ParseTree, HeadTree, TailTree, CompileTree, CompileResult, Input, Output>}
   *
   * @param {PluggableList | Plugin | Preset | null | undefined} value
   *   Usable value.
   * @param {...unknown} parameters
   *   Parameters, when a plugin is given as a usable value.
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *   Current processor.
   */
  use(n, ...t) {
    const r = this.attachers, i = this.namespace;
    if (rt("use", this.frozen), n != null) if (typeof n == "function")
      s(n, t);
    else if (typeof n == "object")
      Array.isArray(n) ? a(n) : o(n);
    else
      throw new TypeError("Expected usable value, not `" + n + "`");
    return this;
    function l(u) {
      if (typeof u == "function")
        s(u, []);
      else if (typeof u == "object")
        if (Array.isArray(u)) {
          const [p, ...c] = (
            /** @type {PluginTuple<Array<unknown>>} */
            u
          );
          s(p, c);
        } else
          o(u);
      else
        throw new TypeError("Expected usable value, not `" + u + "`");
    }
    function o(u) {
      if (!("plugins" in u) && !("settings" in u))
        throw new Error(
          "Expected usable value but received an empty preset, which is probably a mistake: presets typically come with `plugins` and sometimes with `settings`, but this has neither"
        );
      a(u.plugins), u.settings && (i.settings = Zn(!0, i.settings, u.settings));
    }
    function a(u) {
      let p = -1;
      if (u != null) if (Array.isArray(u))
        for (; ++p < u.length; ) {
          const c = u[p];
          l(c);
        }
      else
        throw new TypeError("Expected a list of plugins, not `" + u + "`");
    }
    function s(u, p) {
      let c = -1, h = -1;
      for (; ++c < r.length; )
        if (r[c][0] === u) {
          h = c;
          break;
        }
      if (h === -1)
        r.push([u, ...p]);
      else if (p.length > 0) {
        let [f, ...g] = p;
        const v = r[h][1];
        vt(v) && vt(f) && (f = Zn(!0, v, f)), r[h] = [u, f, ...g];
      }
    }
  }
}
const bm = new fr().freeze();
function nt(e, n) {
  if (typeof n != "function")
    throw new TypeError("Cannot `" + e + "` without `parser`");
}
function tt(e, n) {
  if (typeof n != "function")
    throw new TypeError("Cannot `" + e + "` without `compiler`");
}
function rt(e, n) {
  if (n)
    throw new Error(
      "Cannot call `" + e + "` on a frozen processor.\nCreate a new processor first, by calling it: use `processor()` instead of `processor`."
    );
}
function Ti(e) {
  if (!vt(e) || typeof e.type != "string")
    throw new TypeError("Expected node, got `" + e + "`");
}
function Ii(e, n, t) {
  if (!t)
    throw new Error(
      "`" + e + "` finished async. Use `" + n + "` instead"
    );
}
function Tn(e) {
  return ym(e) ? e : new nl(e);
}
function ym(e) {
  return !!(e && typeof e == "object" && "message" in e && "messages" in e);
}
function km(e) {
  return typeof e == "string" || xm(e);
}
function xm(e) {
  return !!(e && typeof e == "object" && "byteLength" in e && "byteOffset" in e);
}
const wm = "https://github.com/remarkjs/react-markdown/blob/main/changelog.md", Oi = [], Li = { allowDangerousHtml: !0 }, vm = /^(https?|ircs?|mailto|xmpp)$/i, Sm = [
  { from: "astPlugins", id: "remove-buggy-html-in-markdown-parser" },
  { from: "allowDangerousHtml", id: "remove-buggy-html-in-markdown-parser" },
  {
    from: "allowNode",
    id: "replace-allownode-allowedtypes-and-disallowedtypes",
    to: "allowElement"
  },
  {
    from: "allowedTypes",
    id: "replace-allownode-allowedtypes-and-disallowedtypes",
    to: "allowedElements"
  },
  {
    from: "disallowedTypes",
    id: "replace-allownode-allowedtypes-and-disallowedtypes",
    to: "disallowedElements"
  },
  { from: "escapeHtml", id: "remove-buggy-html-in-markdown-parser" },
  { from: "includeElementIndex", id: "#remove-includeelementindex" },
  {
    from: "includeNodeIndex",
    id: "change-includenodeindex-to-includeelementindex"
  },
  { from: "linkTarget", id: "remove-linktarget" },
  { from: "plugins", id: "change-plugins-to-remarkplugins", to: "remarkPlugins" },
  { from: "rawSourcePos", id: "#remove-rawsourcepos" },
  { from: "renderers", id: "change-renderers-to-components", to: "components" },
  { from: "source", id: "change-source-to-children", to: "children" },
  { from: "sourcePos", id: "#remove-sourcepos" },
  { from: "transformImageUri", id: "#add-urltransform", to: "urlTransform" },
  { from: "transformLinkUri", id: "#add-urltransform", to: "urlTransform" }
];
function Em(e) {
  const n = hr(e), t = dr(e);
  return gr(n.runSync(n.parse(t), t), e);
}
async function Cm(e) {
  const n = hr(e), t = dr(e), r = await n.run(n.parse(t), t);
  return gr(r, e);
}
function Am(e) {
  const n = hr(e), [t, r] = un.useState(
    /** @type {Error | undefined} */
    void 0
  ), [i, l] = un.useState(
    /** @type {Root | undefined} */
    void 0
  );
  if (un.useEffect(
    /* c8 ignore next 7 -- hooks are client-only. */
    function() {
      const o = dr(e);
      n.run(n.parse(o), o, function(a, s) {
        r(a), l(s);
      });
    },
    [
      e.children,
      e.rehypePlugins,
      e.remarkPlugins,
      e.remarkRehypeOptions
    ]
  ), t) throw t;
  return i ? gr(i, e) : un.createElement(On.Fragment);
}
function hr(e) {
  const n = e.rehypePlugins || Oi, t = e.remarkPlugins || Oi, r = e.remarkRehypeOptions ? { ...e.remarkRehypeOptions, ...Li } : Li;
  return bm().use(lg).use(t).use(em, r).use(n);
}
function dr(e) {
  const n = e.children || "", t = new nl();
  return typeof n == "string" && (t.value = n), t;
}
function gr(e, n) {
  const t = n.allowedElements, r = n.allowElement, i = n.components, l = n.disallowedElements, o = n.skipHtml, a = n.unwrapDisallowed, s = n.urlTransform || tl;
  for (const p of Sm)
    Object.hasOwn(n, p.from) && ("" + p.from + (p.to ? "use `" + p.to + "` instead" : "remove it") + wm + p.id, void 0);
  return n.className && (e = {
    type: "element",
    tagName: "div",
    properties: { className: n.className },
    // Assume no doctypes.
    children: (
      /** @type {Array<ElementContent>} */
      e.type === "root" ? e.children : [e]
    )
  }), pr(e, u), Hf(e, {
    Fragment: On.Fragment,
    // @ts-expect-error
    // React components are allowed to return numbers,
    // but not according to the types in hast-util-to-jsx-runtime
    components: i,
    ignoreInvalidStyle: !0,
    jsx: On.jsx,
    jsxs: On.jsxs,
    passKeys: !0,
    passNode: !0
  });
  function u(p, c, h) {
    if (p.type === "raw" && h && typeof c == "number")
      return o ? h.children.splice(c, 1) : h.children[c] = { type: "text", value: p.value }, c;
    if (p.type === "element") {
      let f;
      for (f in Yn)
        if (Object.hasOwn(Yn, f) && Object.hasOwn(p.properties, f)) {
          const g = p.properties[f], v = Yn[f];
          (v === null || v.includes(p.tagName)) && (p.properties[f] = s(String(g || ""), f, p));
        }
    }
    if (p.type === "element") {
      let f = t ? !t.includes(p.tagName) : l ? l.includes(p.tagName) : !1;
      if (!f && r && typeof c == "number" && (f = !r(p, c, h)), f && h && typeof c == "number")
        return a && p.children ? h.children.splice(c, 1, ...p.children) : h.children.splice(c, 1), c;
    }
  }
}
function tl(e) {
  const n = e.indexOf(":"), t = e.indexOf("?"), r = e.indexOf("#"), i = e.indexOf("/");
  return (
    // If there is no protocol, it’s relative.
    n === -1 || // If the first colon is after a `?`, `#`, or `/`, it’s not a protocol.
    i !== -1 && n > i || t !== -1 && n > t || r !== -1 && n > r || // It is a protocol, it should be allowed.
    vm.test(e.slice(0, n)) ? e : ""
  );
}
const ek = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  MarkdownAsync: Cm,
  MarkdownHooks: Am,
  default: Em,
  defaultUrlTransform: tl
}, Symbol.toStringTag, { value: "Module" }));
function Ri(e, n) {
  const t = String(e);
  if (typeof n != "string")
    throw new TypeError("Expected character");
  let r = 0, i = t.indexOf(n);
  for (; i !== -1; )
    r++, i = t.indexOf(n, i + n.length);
  return r;
}
function Tm(e) {
  if (typeof e != "string")
    throw new TypeError("Expected a string");
  return e.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d");
}
function Im(e, n, t) {
  const i = Hn((t || {}).ignore || []), l = Om(n);
  let o = -1;
  for (; ++o < l.length; )
    Jo(e, "text", a);
  function a(u, p) {
    let c = -1, h;
    for (; ++c < p.length; ) {
      const f = p[c], g = h ? h.children : void 0;
      if (i(
        f,
        g ? g.indexOf(f) : void 0,
        h
      ))
        return;
      h = f;
    }
    if (h)
      return s(u, p);
  }
  function s(u, p) {
    const c = p[p.length - 1], h = l[o][0], f = l[o][1];
    let g = 0;
    const A = c.children.indexOf(u);
    let w = !1, k = [];
    h.lastIndex = 0;
    let y = h.exec(u.value);
    for (; y; ) {
      const E = y.index, S = {
        index: y.index,
        input: y.input,
        stack: [...p, u]
      };
      let m = f(...y, S);
      if (typeof m == "string" && (m = m.length > 0 ? { type: "text", value: m } : void 0), m === !1 ? h.lastIndex = E + 1 : (g !== E && k.push({
        type: "text",
        value: u.value.slice(g, E)
      }), Array.isArray(m) ? k.push(...m) : m && k.push(m), g = E + y[0].length, w = !0), !h.global)
        break;
      y = h.exec(u.value);
    }
    return w ? (g < u.value.length && k.push({ type: "text", value: u.value.slice(g) }), c.children.splice(A, 1, ...k)) : k = [u], A + k.length;
  }
}
function Om(e) {
  const n = [];
  if (!Array.isArray(e))
    throw new TypeError("Expected find and replace tuple or list of tuples");
  const t = !e[0] || Array.isArray(e[0]) ? e : [e];
  let r = -1;
  for (; ++r < t.length; ) {
    const i = t[r];
    n.push([Lm(i[0]), Rm(i[1])]);
  }
  return n;
}
function Lm(e) {
  return typeof e == "string" ? new RegExp(Tm(e), "g") : e;
}
function Rm(e) {
  return typeof e == "function" ? e : function() {
    return e;
  };
}
const it = "phrasing", ot = ["autolink", "link", "image", "label"];
function Nm() {
  return {
    transforms: [$m],
    enter: {
      literalAutolink: Fm,
      literalAutolinkEmail: lt,
      literalAutolinkHttp: lt,
      literalAutolinkWww: lt
    },
    exit: {
      literalAutolink: Mm,
      literalAutolinkEmail: zm,
      literalAutolinkHttp: Dm,
      literalAutolinkWww: Pm
    }
  };
}
function _m() {
  return {
    unsafe: [
      {
        character: "@",
        before: "[+\\-.\\w]",
        after: "[\\-.\\w]",
        inConstruct: it,
        notInConstruct: ot
      },
      {
        character: ".",
        before: "[Ww]",
        after: "[\\-.\\w]",
        inConstruct: it,
        notInConstruct: ot
      },
      {
        character: ":",
        before: "[ps]",
        after: "\\/",
        inConstruct: it,
        notInConstruct: ot
      }
    ]
  };
}
function Fm(e) {
  this.enter({ type: "link", title: null, url: "", children: [] }, e);
}
function lt(e) {
  this.config.enter.autolinkProtocol.call(this, e);
}
function Dm(e) {
  this.config.exit.autolinkProtocol.call(this, e);
}
function Pm(e) {
  this.config.exit.data.call(this, e);
  const n = this.stack[this.stack.length - 1];
  n.type, n.url = "http://" + this.sliceSerialize(e);
}
function zm(e) {
  this.config.exit.autolinkEmail.call(this, e);
}
function Mm(e) {
  this.exit(e);
}
function $m(e) {
  Im(
    e,
    [
      [/(https?:\/\/|www(?=\.))([-.\w]+)([^ \t\r\n]*)/gi, jm],
      [new RegExp("(?<=^|\\s|\\p{P}|\\p{S})([-.\\w+]+)@([-\\w]+(?:\\.[-\\w]+)+)", "gu"), Bm]
    ],
    { ignore: ["link", "linkReference"] }
  );
}
function jm(e, n, t, r, i) {
  let l = "";
  if (!rl(i) || (/^w/i.test(n) && (t = n + t, n = "", l = "http://"), !Um(t)))
    return !1;
  const o = Hm(t + r);
  if (!o[0]) return !1;
  const a = {
    type: "link",
    title: null,
    url: l + n + o[0],
    children: [{ type: "text", value: n + o[0] }]
  };
  return o[1] ? [a, { type: "text", value: o[1] }] : a;
}
function Bm(e, n, t, r) {
  return (
    // Not an expected previous character.
    !rl(r, !0) || // Label ends in not allowed character.
    /[-\d_]$/.test(t) ? !1 : {
      type: "link",
      title: null,
      url: "mailto:" + n + "@" + t,
      children: [{ type: "text", value: n + "@" + t }]
    }
  );
}
function Um(e) {
  const n = e.split(".");
  return !(n.length < 2 || n[n.length - 1] && (/_/.test(n[n.length - 1]) || !/[a-zA-Z\d]/.test(n[n.length - 1])) || n[n.length - 2] && (/_/.test(n[n.length - 2]) || !/[a-zA-Z\d]/.test(n[n.length - 2])));
}
function Hm(e) {
  const n = /[!"&'),.:;<>?\]}]+$/.exec(e);
  if (!n)
    return [e, void 0];
  e = e.slice(0, n.index);
  let t = n[0], r = t.indexOf(")");
  const i = Ri(e, "(");
  let l = Ri(e, ")");
  for (; r !== -1 && i > l; )
    e += t.slice(0, r + 1), t = t.slice(r + 1), r = t.indexOf(")"), l++;
  return [e, t];
}
function rl(e, n) {
  const t = e.input.charCodeAt(e.index - 1);
  return (e.index === 0 || Ue(t) || jn(t)) && // If it’s an email, the previous character should not be a slash.
  (!n || t !== 47);
}
il.peek = Qm;
function Vm() {
  this.buffer();
}
function qm(e) {
  this.enter({ type: "footnoteReference", identifier: "", label: "" }, e);
}
function Gm() {
  this.buffer();
}
function Wm(e) {
  this.enter(
    { type: "footnoteDefinition", identifier: "", label: "", children: [] },
    e
  );
}
function Ym(e) {
  const n = this.resume(), t = this.stack[this.stack.length - 1];
  t.type, t.identifier = Ce(
    this.sliceSerialize(e)
  ).toLowerCase(), t.label = n;
}
function Xm(e) {
  this.exit(e);
}
function Km(e) {
  const n = this.resume(), t = this.stack[this.stack.length - 1];
  t.type, t.identifier = Ce(
    this.sliceSerialize(e)
  ).toLowerCase(), t.label = n;
}
function Zm(e) {
  this.exit(e);
}
function Qm() {
  return "[";
}
function il(e, n, t, r) {
  const i = t.createTracker(r);
  let l = i.move("[^");
  const o = t.enter("footnoteReference"), a = t.enter("reference");
  return l += i.move(
    t.safe(t.associationId(e), { after: "]", before: l })
  ), a(), o(), l += i.move("]"), l;
}
function Jm() {
  return {
    enter: {
      gfmFootnoteCallString: Vm,
      gfmFootnoteCall: qm,
      gfmFootnoteDefinitionLabelString: Gm,
      gfmFootnoteDefinition: Wm
    },
    exit: {
      gfmFootnoteCallString: Ym,
      gfmFootnoteCall: Xm,
      gfmFootnoteDefinitionLabelString: Km,
      gfmFootnoteDefinition: Zm
    }
  };
}
function eb(e) {
  let n = !1;
  return e && e.firstLineBlank && (n = !0), {
    handlers: { footnoteDefinition: t, footnoteReference: il },
    // This is on by default already.
    unsafe: [{ character: "[", inConstruct: ["label", "phrasing", "reference"] }]
  };
  function t(r, i, l, o) {
    const a = l.createTracker(o);
    let s = a.move("[^");
    const u = l.enter("footnoteDefinition"), p = l.enter("label");
    return s += a.move(
      l.safe(l.associationId(r), { before: s, after: "]" })
    ), p(), s += a.move("]:"), r.children && r.children.length > 0 && (a.shift(4), s += a.move(
      (n ? `
` : " ") + l.indentLines(
        l.containerFlow(r, a.current()),
        n ? ol : nb
      )
    )), u(), s;
  }
}
function nb(e, n, t) {
  return n === 0 ? e : ol(e, n, t);
}
function ol(e, n, t) {
  return (t ? "" : "    ") + e;
}
const tb = [
  "autolink",
  "destinationLiteral",
  "destinationRaw",
  "reference",
  "titleQuote",
  "titleApostrophe"
];
ll.peek = ab;
function rb() {
  return {
    canContainEols: ["delete"],
    enter: { strikethrough: ob },
    exit: { strikethrough: lb }
  };
}
function ib() {
  return {
    unsafe: [
      {
        character: "~",
        inConstruct: "phrasing",
        notInConstruct: tb
      }
    ],
    handlers: { delete: ll }
  };
}
function ob(e) {
  this.enter({ type: "delete", children: [] }, e);
}
function lb(e) {
  this.exit(e);
}
function ll(e, n, t, r) {
  const i = t.createTracker(r), l = t.enter("strikethrough");
  let o = i.move("~~");
  return o += t.containerPhrasing(e, {
    ...i.current(),
    before: o,
    after: "~"
  }), o += i.move("~~"), l(), o;
}
function ab() {
  return "~";
}
function sb(e) {
  return e.length;
}
function ub(e, n) {
  const t = n || {}, r = (t.align || []).concat(), i = t.stringLength || sb, l = [], o = [], a = [], s = [];
  let u = 0, p = -1;
  for (; ++p < e.length; ) {
    const v = [], A = [];
    let w = -1;
    for (e[p].length > u && (u = e[p].length); ++w < e[p].length; ) {
      const k = cb(e[p][w]);
      if (t.alignDelimiters !== !1) {
        const y = i(k);
        A[w] = y, (s[w] === void 0 || y > s[w]) && (s[w] = y);
      }
      v.push(k);
    }
    o[p] = v, a[p] = A;
  }
  let c = -1;
  if (typeof r == "object" && "length" in r)
    for (; ++c < u; )
      l[c] = Ni(r[c]);
  else {
    const v = Ni(r);
    for (; ++c < u; )
      l[c] = v;
  }
  c = -1;
  const h = [], f = [];
  for (; ++c < u; ) {
    const v = l[c];
    let A = "", w = "";
    v === 99 ? (A = ":", w = ":") : v === 108 ? A = ":" : v === 114 && (w = ":");
    let k = t.alignDelimiters === !1 ? 1 : Math.max(
      1,
      s[c] - A.length - w.length
    );
    const y = A + "-".repeat(k) + w;
    t.alignDelimiters !== !1 && (k = A.length + k + w.length, k > s[c] && (s[c] = k), f[c] = k), h[c] = y;
  }
  o.splice(1, 0, h), a.splice(1, 0, f), p = -1;
  const g = [];
  for (; ++p < o.length; ) {
    const v = o[p], A = a[p];
    c = -1;
    const w = [];
    for (; ++c < u; ) {
      const k = v[c] || "";
      let y = "", E = "";
      if (t.alignDelimiters !== !1) {
        const S = s[c] - (A[c] || 0), m = l[c];
        m === 114 ? y = " ".repeat(S) : m === 99 ? S % 2 ? (y = " ".repeat(S / 2 + 0.5), E = " ".repeat(S / 2 - 0.5)) : (y = " ".repeat(S / 2), E = y) : E = " ".repeat(S);
      }
      t.delimiterStart !== !1 && !c && w.push("|"), t.padding !== !1 && // Don’t add the opening space if we’re not aligning and the cell is
      // empty: there will be a closing space.
      !(t.alignDelimiters === !1 && k === "") && (t.delimiterStart !== !1 || c) && w.push(" "), t.alignDelimiters !== !1 && w.push(y), w.push(k), t.alignDelimiters !== !1 && w.push(E), t.padding !== !1 && w.push(" "), (t.delimiterEnd !== !1 || c !== u - 1) && w.push("|");
    }
    g.push(
      t.delimiterEnd === !1 ? w.join("").replace(/ +$/, "") : w.join("")
    );
  }
  return g.join(`
`);
}
function cb(e) {
  return e == null ? "" : String(e);
}
function Ni(e) {
  const n = typeof e == "string" ? e.codePointAt(0) : 0;
  return n === 67 || n === 99 ? 99 : n === 76 || n === 108 ? 108 : n === 82 || n === 114 ? 114 : 0;
}
const _i = {}.hasOwnProperty;
function nk(e, n) {
  const t = n || {};
  function r(i, ...l) {
    let o = r.invalid;
    const a = r.handlers;
    if (i && _i.call(i, e)) {
      const s = String(i[e]);
      o = _i.call(a, s) ? a[s] : r.unknown;
    }
    if (o)
      return o.call(this, i, ...l);
  }
  return r.handlers = t.handlers || {}, r.invalid = t.invalid, r.unknown = t.unknown, r;
}
function pb(e, n, t, r) {
  const i = t.enter("blockquote"), l = t.createTracker(r);
  l.move("> "), l.shift(2);
  const o = t.indentLines(
    t.containerFlow(e, l.current()),
    fb
  );
  return i(), o;
}
function fb(e, n, t) {
  return ">" + (t ? "" : " ") + e;
}
function hb(e, n) {
  return Fi(e, n.inConstruct, !0) && !Fi(e, n.notInConstruct, !1);
}
function Fi(e, n, t) {
  if (typeof n == "string" && (n = [n]), !n || n.length === 0)
    return t;
  let r = -1;
  for (; ++r < n.length; )
    if (e.includes(n[r]))
      return !0;
  return !1;
}
function Di(e, n, t, r) {
  let i = -1;
  for (; ++i < t.unsafe.length; )
    if (t.unsafe[i].character === `
` && hb(t.stack, t.unsafe[i]))
      return /[ \t]/.test(r.before) ? "" : " ";
  return `\\
`;
}
function db(e, n) {
  const t = String(e);
  let r = t.indexOf(n), i = r, l = 0, o = 0;
  if (typeof n != "string")
    throw new TypeError("Expected substring");
  for (; r !== -1; )
    r === i ? ++l > o && (o = l) : l = 1, i = r + n.length, r = t.indexOf(n, i);
  return o;
}
function gb(e, n) {
  return !!(n.options.fences === !1 && e.value && // If there’s no info…
  !e.lang && // And there’s a non-whitespace character…
  /[^ \r\n]/.test(e.value) && // And the value doesn’t start or end in a blank…
  !/^[\t ]*(?:[\r\n]|$)|(?:^|[\r\n])[\t ]*$/.test(e.value));
}
function mb(e) {
  const n = e.options.fence || "`";
  if (n !== "`" && n !== "~")
    throw new Error(
      "Cannot serialize code with `" + n + "` for `options.fence`, expected `` ` `` or `~`"
    );
  return n;
}
function bb(e, n, t, r) {
  const i = mb(t), l = e.value || "", o = i === "`" ? "GraveAccent" : "Tilde";
  if (gb(e, t)) {
    const c = t.enter("codeIndented"), h = t.indentLines(l, yb);
    return c(), h;
  }
  const a = t.createTracker(r), s = i.repeat(Math.max(db(l, i) + 1, 3)), u = t.enter("codeFenced");
  let p = a.move(s);
  if (e.lang) {
    const c = t.enter(`codeFencedLang${o}`);
    p += a.move(
      t.safe(e.lang, {
        before: p,
        after: " ",
        encode: ["`"],
        ...a.current()
      })
    ), c();
  }
  if (e.lang && e.meta) {
    const c = t.enter(`codeFencedMeta${o}`);
    p += a.move(" "), p += a.move(
      t.safe(e.meta, {
        before: p,
        after: `
`,
        encode: ["`"],
        ...a.current()
      })
    ), c();
  }
  return p += a.move(`
`), l && (p += a.move(l + `
`)), p += a.move(s), u(), p;
}
function yb(e, n, t) {
  return (t ? "" : "    ") + e;
}
function mr(e) {
  const n = e.options.quote || '"';
  if (n !== '"' && n !== "'")
    throw new Error(
      "Cannot serialize title with `" + n + "` for `options.quote`, expected `\"`, or `'`"
    );
  return n;
}
function kb(e, n, t, r) {
  const i = mr(t), l = i === '"' ? "Quote" : "Apostrophe", o = t.enter("definition");
  let a = t.enter("label");
  const s = t.createTracker(r);
  let u = s.move("[");
  return u += s.move(
    t.safe(t.associationId(e), {
      before: u,
      after: "]",
      ...s.current()
    })
  ), u += s.move("]: "), a(), // If there’s no url, or…
  !e.url || // If there are control characters or whitespace.
  /[\0- \u007F]/.test(e.url) ? (a = t.enter("destinationLiteral"), u += s.move("<"), u += s.move(
    t.safe(e.url, { before: u, after: ">", ...s.current() })
  ), u += s.move(">")) : (a = t.enter("destinationRaw"), u += s.move(
    t.safe(e.url, {
      before: u,
      after: e.title ? " " : `
`,
      ...s.current()
    })
  )), a(), e.title && (a = t.enter(`title${l}`), u += s.move(" " + i), u += s.move(
    t.safe(e.title, {
      before: u,
      after: i,
      ...s.current()
    })
  ), u += s.move(i), a()), o(), u;
}
function xb(e) {
  const n = e.options.emphasis || "*";
  if (n !== "*" && n !== "_")
    throw new Error(
      "Cannot serialize emphasis with `" + n + "` for `options.emphasis`, expected `*`, or `_`"
    );
  return n;
}
function bn(e) {
  return "&#x" + e.toString(16).toUpperCase() + ";";
}
function Pn(e, n, t) {
  const r = Qe(e), i = Qe(n);
  return r === void 0 ? i === void 0 ? (
    // Letter inside:
    // we have to encode *both* letters for `_` as it is looser.
    // it already forms for `*` (and GFMs `~`).
    t === "_" ? { inside: !0, outside: !0 } : { inside: !1, outside: !1 }
  ) : i === 1 ? (
    // Whitespace inside: encode both (letter, whitespace).
    { inside: !0, outside: !0 }
  ) : (
    // Punctuation inside: encode outer (letter)
    { inside: !1, outside: !0 }
  ) : r === 1 ? i === void 0 ? (
    // Letter inside: already forms.
    { inside: !1, outside: !1 }
  ) : i === 1 ? (
    // Whitespace inside: encode both (whitespace).
    { inside: !0, outside: !0 }
  ) : (
    // Punctuation inside: already forms.
    { inside: !1, outside: !1 }
  ) : i === void 0 ? (
    // Letter inside: already forms.
    { inside: !1, outside: !1 }
  ) : i === 1 ? (
    // Whitespace inside: encode inner (whitespace).
    { inside: !0, outside: !1 }
  ) : (
    // Punctuation inside: already forms.
    { inside: !1, outside: !1 }
  );
}
al.peek = wb;
function al(e, n, t, r) {
  const i = xb(t), l = t.enter("emphasis"), o = t.createTracker(r), a = o.move(i);
  let s = o.move(
    t.containerPhrasing(e, {
      after: i,
      before: a,
      ...o.current()
    })
  );
  const u = s.charCodeAt(0), p = Pn(
    r.before.charCodeAt(r.before.length - 1),
    u,
    i
  );
  p.inside && (s = bn(u) + s.slice(1));
  const c = s.charCodeAt(s.length - 1), h = Pn(r.after.charCodeAt(0), c, i);
  h.inside && (s = s.slice(0, -1) + bn(c));
  const f = o.move(i);
  return l(), t.attentionEncodeSurroundingInfo = {
    after: h.outside,
    before: p.outside
  }, a + s + f;
}
function wb(e, n, t) {
  return t.options.emphasis || "*";
}
function vb(e, n) {
  let t = !1;
  return pr(e, function(r) {
    if ("value" in r && /\r?\n|\r/.test(r.value) || r.type === "break")
      return t = !0, xt;
  }), !!((!e.depth || e.depth < 3) && ir(e) && (n.options.setext || t));
}
function Sb(e, n, t, r) {
  const i = Math.max(Math.min(6, e.depth || 1), 1), l = t.createTracker(r);
  if (vb(e, t)) {
    const p = t.enter("headingSetext"), c = t.enter("phrasing"), h = t.containerPhrasing(e, {
      ...l.current(),
      before: `
`,
      after: `
`
    });
    return c(), p(), h + `
` + (i === 1 ? "=" : "-").repeat(
      // The whole size…
      h.length - // Minus the position of the character after the last EOL (or
      // 0 if there is none)…
      (Math.max(h.lastIndexOf("\r"), h.lastIndexOf(`
`)) + 1)
    );
  }
  const o = "#".repeat(i), a = t.enter("headingAtx"), s = t.enter("phrasing");
  l.move(o + " ");
  let u = t.containerPhrasing(e, {
    before: "# ",
    after: `
`,
    ...l.current()
  });
  return /^[\t ]/.test(u) && (u = bn(u.charCodeAt(0)) + u.slice(1)), u = u ? o + " " + u : o, t.options.closeAtx && (u += " " + o), s(), a(), u;
}
sl.peek = Eb;
function sl(e) {
  return e.value || "";
}
function Eb() {
  return "<";
}
ul.peek = Cb;
function ul(e, n, t, r) {
  const i = mr(t), l = i === '"' ? "Quote" : "Apostrophe", o = t.enter("image");
  let a = t.enter("label");
  const s = t.createTracker(r);
  let u = s.move("![");
  return u += s.move(
    t.safe(e.alt, { before: u, after: "]", ...s.current() })
  ), u += s.move("]("), a(), // If there’s no url but there is a title…
  !e.url && e.title || // If there are control characters or whitespace.
  /[\0- \u007F]/.test(e.url) ? (a = t.enter("destinationLiteral"), u += s.move("<"), u += s.move(
    t.safe(e.url, { before: u, after: ">", ...s.current() })
  ), u += s.move(">")) : (a = t.enter("destinationRaw"), u += s.move(
    t.safe(e.url, {
      before: u,
      after: e.title ? " " : ")",
      ...s.current()
    })
  )), a(), e.title && (a = t.enter(`title${l}`), u += s.move(" " + i), u += s.move(
    t.safe(e.title, {
      before: u,
      after: i,
      ...s.current()
    })
  ), u += s.move(i), a()), u += s.move(")"), o(), u;
}
function Cb() {
  return "!";
}
cl.peek = Ab;
function cl(e, n, t, r) {
  const i = e.referenceType, l = t.enter("imageReference");
  let o = t.enter("label");
  const a = t.createTracker(r);
  let s = a.move("![");
  const u = t.safe(e.alt, {
    before: s,
    after: "]",
    ...a.current()
  });
  s += a.move(u + "]["), o();
  const p = t.stack;
  t.stack = [], o = t.enter("reference");
  const c = t.safe(t.associationId(e), {
    before: s,
    after: "]",
    ...a.current()
  });
  return o(), t.stack = p, l(), i === "full" || !u || u !== c ? s += a.move(c + "]") : i === "shortcut" ? s = s.slice(0, -1) : s += a.move("]"), s;
}
function Ab() {
  return "!";
}
pl.peek = Tb;
function pl(e, n, t) {
  let r = e.value || "", i = "`", l = -1;
  for (; new RegExp("(^|[^`])" + i + "([^`]|$)").test(r); )
    i += "`";
  for (/[^ \r\n]/.test(r) && (/^[ \r\n]/.test(r) && /[ \r\n]$/.test(r) || /^`|`$/.test(r)) && (r = " " + r + " "); ++l < t.unsafe.length; ) {
    const o = t.unsafe[l], a = t.compilePattern(o);
    let s;
    if (o.atBreak)
      for (; s = a.exec(r); ) {
        let u = s.index;
        r.charCodeAt(u) === 10 && r.charCodeAt(u - 1) === 13 && u--, r = r.slice(0, u) + " " + r.slice(s.index + 1);
      }
  }
  return i + r + i;
}
function Tb() {
  return "`";
}
function fl(e, n) {
  const t = ir(e);
  return !!(!n.options.resourceLink && // If there’s a url…
  e.url && // And there’s a no title…
  !e.title && // And the content of `node` is a single text node…
  e.children && e.children.length === 1 && e.children[0].type === "text" && // And if the url is the same as the content…
  (t === e.url || "mailto:" + t === e.url) && // And that starts w/ a protocol…
  /^[a-z][a-z+.-]+:/i.test(e.url) && // And that doesn’t contain ASCII control codes (character escapes and
  // references don’t work), space, or angle brackets…
  !/[\0- <>\u007F]/.test(e.url));
}
hl.peek = Ib;
function hl(e, n, t, r) {
  const i = mr(t), l = i === '"' ? "Quote" : "Apostrophe", o = t.createTracker(r);
  let a, s;
  if (fl(e, t)) {
    const p = t.stack;
    t.stack = [], a = t.enter("autolink");
    let c = o.move("<");
    return c += o.move(
      t.containerPhrasing(e, {
        before: c,
        after: ">",
        ...o.current()
      })
    ), c += o.move(">"), a(), t.stack = p, c;
  }
  a = t.enter("link"), s = t.enter("label");
  let u = o.move("[");
  return u += o.move(
    t.containerPhrasing(e, {
      before: u,
      after: "](",
      ...o.current()
    })
  ), u += o.move("]("), s(), // If there’s no url but there is a title…
  !e.url && e.title || // If there are control characters or whitespace.
  /[\0- \u007F]/.test(e.url) ? (s = t.enter("destinationLiteral"), u += o.move("<"), u += o.move(
    t.safe(e.url, { before: u, after: ">", ...o.current() })
  ), u += o.move(">")) : (s = t.enter("destinationRaw"), u += o.move(
    t.safe(e.url, {
      before: u,
      after: e.title ? " " : ")",
      ...o.current()
    })
  )), s(), e.title && (s = t.enter(`title${l}`), u += o.move(" " + i), u += o.move(
    t.safe(e.title, {
      before: u,
      after: i,
      ...o.current()
    })
  ), u += o.move(i), s()), u += o.move(")"), a(), u;
}
function Ib(e, n, t) {
  return fl(e, t) ? "<" : "[";
}
dl.peek = Ob;
function dl(e, n, t, r) {
  const i = e.referenceType, l = t.enter("linkReference");
  let o = t.enter("label");
  const a = t.createTracker(r);
  let s = a.move("[");
  const u = t.containerPhrasing(e, {
    before: s,
    after: "]",
    ...a.current()
  });
  s += a.move(u + "]["), o();
  const p = t.stack;
  t.stack = [], o = t.enter("reference");
  const c = t.safe(t.associationId(e), {
    before: s,
    after: "]",
    ...a.current()
  });
  return o(), t.stack = p, l(), i === "full" || !u || u !== c ? s += a.move(c + "]") : i === "shortcut" ? s = s.slice(0, -1) : s += a.move("]"), s;
}
function Ob() {
  return "[";
}
function br(e) {
  const n = e.options.bullet || "*";
  if (n !== "*" && n !== "+" && n !== "-")
    throw new Error(
      "Cannot serialize items with `" + n + "` for `options.bullet`, expected `*`, `+`, or `-`"
    );
  return n;
}
function Lb(e) {
  const n = br(e), t = e.options.bulletOther;
  if (!t)
    return n === "*" ? "-" : "*";
  if (t !== "*" && t !== "+" && t !== "-")
    throw new Error(
      "Cannot serialize items with `" + t + "` for `options.bulletOther`, expected `*`, `+`, or `-`"
    );
  if (t === n)
    throw new Error(
      "Expected `bullet` (`" + n + "`) and `bulletOther` (`" + t + "`) to be different"
    );
  return t;
}
function Rb(e) {
  const n = e.options.bulletOrdered || ".";
  if (n !== "." && n !== ")")
    throw new Error(
      "Cannot serialize items with `" + n + "` for `options.bulletOrdered`, expected `.` or `)`"
    );
  return n;
}
function gl(e) {
  const n = e.options.rule || "*";
  if (n !== "*" && n !== "-" && n !== "_")
    throw new Error(
      "Cannot serialize rules with `" + n + "` for `options.rule`, expected `*`, `-`, or `_`"
    );
  return n;
}
function Nb(e, n, t, r) {
  const i = t.enter("list"), l = t.bulletCurrent;
  let o = e.ordered ? Rb(t) : br(t);
  const a = e.ordered ? o === "." ? ")" : "." : Lb(t);
  let s = n && t.bulletLastUsed ? o === t.bulletLastUsed : !1;
  if (!e.ordered) {
    const p = e.children ? e.children[0] : void 0;
    if (
      // Bullet could be used as a thematic break marker:
      (o === "*" || o === "-") && // Empty first list item:
      p && (!p.children || !p.children[0]) && // Directly in two other list items:
      t.stack[t.stack.length - 1] === "list" && t.stack[t.stack.length - 2] === "listItem" && t.stack[t.stack.length - 3] === "list" && t.stack[t.stack.length - 4] === "listItem" && // That are each the first child.
      t.indexStack[t.indexStack.length - 1] === 0 && t.indexStack[t.indexStack.length - 2] === 0 && t.indexStack[t.indexStack.length - 3] === 0 && (s = !0), gl(t) === o && p
    ) {
      let c = -1;
      for (; ++c < e.children.length; ) {
        const h = e.children[c];
        if (h && h.type === "listItem" && h.children && h.children[0] && h.children[0].type === "thematicBreak") {
          s = !0;
          break;
        }
      }
    }
  }
  s && (o = a), t.bulletCurrent = o;
  const u = t.containerFlow(e, r);
  return t.bulletLastUsed = o, t.bulletCurrent = l, i(), u;
}
function _b(e) {
  const n = e.options.listItemIndent || "one";
  if (n !== "tab" && n !== "one" && n !== "mixed")
    throw new Error(
      "Cannot serialize items with `" + n + "` for `options.listItemIndent`, expected `tab`, `one`, or `mixed`"
    );
  return n;
}
function Fb(e, n, t, r) {
  const i = _b(t);
  let l = t.bulletCurrent || br(t);
  n && n.type === "list" && n.ordered && (l = (typeof n.start == "number" && n.start > -1 ? n.start : 1) + (t.options.incrementListMarker === !1 ? 0 : n.children.indexOf(e)) + l);
  let o = l.length + 1;
  (i === "tab" || i === "mixed" && (n && n.type === "list" && n.spread || e.spread)) && (o = Math.ceil(o / 4) * 4);
  const a = t.createTracker(r);
  a.move(l + " ".repeat(o - l.length)), a.shift(o);
  const s = t.enter("listItem"), u = t.indentLines(
    t.containerFlow(e, a.current()),
    p
  );
  return s(), u;
  function p(c, h, f) {
    return h ? (f ? "" : " ".repeat(o)) + c : (f ? l : l + " ".repeat(o - l.length)) + c;
  }
}
function Db(e, n, t, r) {
  const i = t.enter("paragraph"), l = t.enter("phrasing"), o = t.containerPhrasing(e, r);
  return l(), i(), o;
}
const Pb = (
  /** @type {(node?: unknown) => node is Exclude<PhrasingContent, Html>} */
  Hn([
    "break",
    "delete",
    "emphasis",
    // To do: next major: removed since footnotes were added to GFM.
    "footnote",
    "footnoteReference",
    "image",
    "imageReference",
    "inlineCode",
    // Enabled by `mdast-util-math`:
    "inlineMath",
    "link",
    "linkReference",
    // Enabled by `mdast-util-mdx`:
    "mdxJsxTextElement",
    // Enabled by `mdast-util-mdx`:
    "mdxTextExpression",
    "strong",
    "text",
    // Enabled by `mdast-util-directive`:
    "textDirective"
  ])
);
function zb(e, n, t, r) {
  return (e.children.some(function(o) {
    return Pb(o);
  }) ? t.containerPhrasing : t.containerFlow).call(t, e, r);
}
function Mb(e) {
  const n = e.options.strong || "*";
  if (n !== "*" && n !== "_")
    throw new Error(
      "Cannot serialize strong with `" + n + "` for `options.strong`, expected `*`, or `_`"
    );
  return n;
}
ml.peek = $b;
function ml(e, n, t, r) {
  const i = Mb(t), l = t.enter("strong"), o = t.createTracker(r), a = o.move(i + i);
  let s = o.move(
    t.containerPhrasing(e, {
      after: i,
      before: a,
      ...o.current()
    })
  );
  const u = s.charCodeAt(0), p = Pn(
    r.before.charCodeAt(r.before.length - 1),
    u,
    i
  );
  p.inside && (s = bn(u) + s.slice(1));
  const c = s.charCodeAt(s.length - 1), h = Pn(r.after.charCodeAt(0), c, i);
  h.inside && (s = s.slice(0, -1) + bn(c));
  const f = o.move(i + i);
  return l(), t.attentionEncodeSurroundingInfo = {
    after: h.outside,
    before: p.outside
  }, a + s + f;
}
function $b(e, n, t) {
  return t.options.strong || "*";
}
function jb(e, n, t, r) {
  return t.safe(e.value, r);
}
function Bb(e) {
  const n = e.options.ruleRepetition || 3;
  if (n < 3)
    throw new Error(
      "Cannot serialize rules with repetition `" + n + "` for `options.ruleRepetition`, expected `3` or more"
    );
  return n;
}
function Ub(e, n, t) {
  const r = (gl(t) + (t.options.ruleSpaces ? " " : "")).repeat(Bb(t));
  return t.options.ruleSpaces ? r.slice(0, -1) : r;
}
const bl = {
  blockquote: pb,
  break: Di,
  code: bb,
  definition: kb,
  emphasis: al,
  hardBreak: Di,
  heading: Sb,
  html: sl,
  image: ul,
  imageReference: cl,
  inlineCode: pl,
  link: hl,
  linkReference: dl,
  list: Nb,
  listItem: Fb,
  paragraph: Db,
  root: zb,
  strong: ml,
  text: jb,
  thematicBreak: Ub
};
function Hb() {
  return {
    enter: {
      table: Vb,
      tableData: Pi,
      tableHeader: Pi,
      tableRow: Gb
    },
    exit: {
      codeText: Wb,
      table: qb,
      tableData: at,
      tableHeader: at,
      tableRow: at
    }
  };
}
function Vb(e) {
  const n = e._align;
  this.enter(
    {
      type: "table",
      align: n.map(function(t) {
        return t === "none" ? null : t;
      }),
      children: []
    },
    e
  ), this.data.inTable = !0;
}
function qb(e) {
  this.exit(e), this.data.inTable = void 0;
}
function Gb(e) {
  this.enter({ type: "tableRow", children: [] }, e);
}
function at(e) {
  this.exit(e);
}
function Pi(e) {
  this.enter({ type: "tableCell", children: [] }, e);
}
function Wb(e) {
  let n = this.resume();
  this.data.inTable && (n = n.replace(/\\([\\|])/g, Yb));
  const t = this.stack[this.stack.length - 1];
  t.type, t.value = n, this.exit(e);
}
function Yb(e, n) {
  return n === "|" ? n : e;
}
function Xb(e) {
  const n = e || {}, t = n.tableCellPadding, r = n.tablePipeAlign, i = n.stringLength, l = t ? " " : "|";
  return {
    unsafe: [
      { character: "\r", inConstruct: "tableCell" },
      { character: `
`, inConstruct: "tableCell" },
      // A pipe, when followed by a tab or space (padding), or a dash or colon
      // (unpadded delimiter row), could result in a table.
      { atBreak: !0, character: "|", after: "[	 :-]" },
      // A pipe in a cell must be encoded.
      { character: "|", inConstruct: "tableCell" },
      // A colon must be followed by a dash, in which case it could start a
      // delimiter row.
      { atBreak: !0, character: ":", after: "-" },
      // A delimiter row can also start with a dash, when followed by more
      // dashes, a colon, or a pipe.
      // This is a stricter version than the built in check for lists, thematic
      // breaks, and setex heading underlines though:
      // <https://github.com/syntax-tree/mdast-util-to-markdown/blob/51a2038/lib/unsafe.js#L57>
      { atBreak: !0, character: "-", after: "[:|-]" }
    ],
    handlers: {
      inlineCode: h,
      table: o,
      tableCell: s,
      tableRow: a
    }
  };
  function o(f, g, v, A) {
    return u(p(f, v, A), f.align);
  }
  function a(f, g, v, A) {
    const w = c(f, v, A), k = u([w]);
    return k.slice(0, k.indexOf(`
`));
  }
  function s(f, g, v, A) {
    const w = v.enter("tableCell"), k = v.enter("phrasing"), y = v.containerPhrasing(f, {
      ...A,
      before: l,
      after: l
    });
    return k(), w(), y;
  }
  function u(f, g) {
    return ub(f, {
      align: g,
      // @ts-expect-error: `markdown-table` types should support `null`.
      alignDelimiters: r,
      // @ts-expect-error: `markdown-table` types should support `null`.
      padding: t,
      // @ts-expect-error: `markdown-table` types should support `null`.
      stringLength: i
    });
  }
  function p(f, g, v) {
    const A = f.children;
    let w = -1;
    const k = [], y = g.enter("table");
    for (; ++w < A.length; )
      k[w] = c(A[w], g, v);
    return y(), k;
  }
  function c(f, g, v) {
    const A = f.children;
    let w = -1;
    const k = [], y = g.enter("tableRow");
    for (; ++w < A.length; )
      k[w] = s(A[w], f, g, v);
    return y(), k;
  }
  function h(f, g, v) {
    let A = bl.inlineCode(f, g, v);
    return v.stack.includes("tableCell") && (A = A.replace(/\|/g, "\\$&")), A;
  }
}
function Kb() {
  return {
    exit: {
      taskListCheckValueChecked: zi,
      taskListCheckValueUnchecked: zi,
      paragraph: Qb
    }
  };
}
function Zb() {
  return {
    unsafe: [{ atBreak: !0, character: "-", after: "[:|-]" }],
    handlers: { listItem: Jb }
  };
}
function zi(e) {
  const n = this.stack[this.stack.length - 2];
  n.type, n.checked = e.type === "taskListCheckValueChecked";
}
function Qb(e) {
  const n = this.stack[this.stack.length - 2];
  if (n && n.type === "listItem" && typeof n.checked == "boolean") {
    const t = this.stack[this.stack.length - 1];
    t.type;
    const r = t.children[0];
    if (r && r.type === "text") {
      const i = n.children;
      let l = -1, o;
      for (; ++l < i.length; ) {
        const a = i[l];
        if (a.type === "paragraph") {
          o = a;
          break;
        }
      }
      o === t && (r.value = r.value.slice(1), r.value.length === 0 ? t.children.shift() : t.position && r.position && typeof r.position.start.offset == "number" && (r.position.start.column++, r.position.start.offset++, t.position.start = Object.assign({}, r.position.start)));
    }
  }
  this.exit(e);
}
function Jb(e, n, t, r) {
  const i = e.children[0], l = typeof e.checked == "boolean" && i && i.type === "paragraph", o = "[" + (e.checked ? "x" : " ") + "] ", a = t.createTracker(r);
  l && a.move(o);
  let s = bl.listItem(e, n, t, {
    ...r,
    ...a.current()
  });
  return l && (s = s.replace(/^(?:[*+-]|\d+\.)([\r\n]| {1,3})/, u)), s;
  function u(p) {
    return p + o;
  }
}
function ey() {
  return [
    Nm(),
    Jm(),
    rb(),
    Hb(),
    Kb()
  ];
}
function ny(e) {
  return {
    extensions: [
      _m(),
      eb(e),
      ib(),
      Xb(e),
      Zb()
    ]
  };
}
const ty = {
  tokenize: sy,
  partial: !0
}, yl = {
  tokenize: uy,
  partial: !0
}, kl = {
  tokenize: cy,
  partial: !0
}, xl = {
  tokenize: py,
  partial: !0
}, ry = {
  tokenize: fy,
  partial: !0
}, wl = {
  name: "wwwAutolink",
  tokenize: ly,
  previous: Sl
}, vl = {
  name: "protocolAutolink",
  tokenize: ay,
  previous: El
}, Re = {
  name: "emailAutolink",
  tokenize: oy,
  previous: Cl
}, Ie = {};
function iy() {
  return {
    text: Ie
  };
}
let je = 48;
for (; je < 123; )
  Ie[je] = Re, je++, je === 58 ? je = 65 : je === 91 && (je = 97);
Ie[43] = Re;
Ie[45] = Re;
Ie[46] = Re;
Ie[95] = Re;
Ie[72] = [Re, vl];
Ie[104] = [Re, vl];
Ie[87] = [Re, wl];
Ie[119] = [Re, wl];
function oy(e, n, t) {
  const r = this;
  let i, l;
  return o;
  function o(c) {
    return !Et(c) || !Cl.call(r, r.previous) || yr(r.events) ? t(c) : (e.enter("literalAutolink"), e.enter("literalAutolinkEmail"), a(c));
  }
  function a(c) {
    return Et(c) ? (e.consume(c), a) : c === 64 ? (e.consume(c), s) : t(c);
  }
  function s(c) {
    return c === 46 ? e.check(ry, p, u)(c) : c === 45 || c === 95 || ae(c) ? (l = !0, e.consume(c), s) : p(c);
  }
  function u(c) {
    return e.consume(c), i = !0, s;
  }
  function p(c) {
    return l && i && ce(r.previous) ? (e.exit("literalAutolinkEmail"), e.exit("literalAutolink"), n(c)) : t(c);
  }
}
function ly(e, n, t) {
  const r = this;
  return i;
  function i(o) {
    return o !== 87 && o !== 119 || !Sl.call(r, r.previous) || yr(r.events) ? t(o) : (e.enter("literalAutolink"), e.enter("literalAutolinkWww"), e.check(ty, e.attempt(yl, e.attempt(kl, l), t), t)(o));
  }
  function l(o) {
    return e.exit("literalAutolinkWww"), e.exit("literalAutolink"), n(o);
  }
}
function ay(e, n, t) {
  const r = this;
  let i = "", l = !1;
  return o;
  function o(c) {
    return (c === 72 || c === 104) && El.call(r, r.previous) && !yr(r.events) ? (e.enter("literalAutolink"), e.enter("literalAutolinkHttp"), i += String.fromCodePoint(c), e.consume(c), a) : t(c);
  }
  function a(c) {
    if (ce(c) && i.length < 5)
      return i += String.fromCodePoint(c), e.consume(c), a;
    if (c === 58) {
      const h = i.toLowerCase();
      if (h === "http" || h === "https")
        return e.consume(c), s;
    }
    return t(c);
  }
  function s(c) {
    return c === 47 ? (e.consume(c), l ? u : (l = !0, s)) : t(c);
  }
  function u(c) {
    return c === null || _n(c) || Q(c) || Ue(c) || jn(c) ? t(c) : e.attempt(yl, e.attempt(kl, p), t)(c);
  }
  function p(c) {
    return e.exit("literalAutolinkHttp"), e.exit("literalAutolink"), n(c);
  }
}
function sy(e, n, t) {
  let r = 0;
  return i;
  function i(o) {
    return (o === 87 || o === 119) && r < 3 ? (r++, e.consume(o), i) : o === 46 && r === 3 ? (e.consume(o), l) : t(o);
  }
  function l(o) {
    return o === null ? t(o) : n(o);
  }
}
function uy(e, n, t) {
  let r, i, l;
  return o;
  function o(u) {
    return u === 46 || u === 95 ? e.check(xl, s, a)(u) : u === null || Q(u) || Ue(u) || u !== 45 && jn(u) ? s(u) : (l = !0, e.consume(u), o);
  }
  function a(u) {
    return u === 95 ? r = !0 : (i = r, r = void 0), e.consume(u), o;
  }
  function s(u) {
    return i || r || !l ? t(u) : n(u);
  }
}
function cy(e, n) {
  let t = 0, r = 0;
  return i;
  function i(o) {
    return o === 40 ? (t++, e.consume(o), i) : o === 41 && r < t ? l(o) : o === 33 || o === 34 || o === 38 || o === 39 || o === 41 || o === 42 || o === 44 || o === 46 || o === 58 || o === 59 || o === 60 || o === 63 || o === 93 || o === 95 || o === 126 ? e.check(xl, n, l)(o) : o === null || Q(o) || Ue(o) ? n(o) : (e.consume(o), i);
  }
  function l(o) {
    return o === 41 && r++, e.consume(o), i;
  }
}
function py(e, n, t) {
  return r;
  function r(a) {
    return a === 33 || a === 34 || a === 39 || a === 41 || a === 42 || a === 44 || a === 46 || a === 58 || a === 59 || a === 63 || a === 95 || a === 126 ? (e.consume(a), r) : a === 38 ? (e.consume(a), l) : a === 93 ? (e.consume(a), i) : (
      // `<` is an end.
      a === 60 || // So is whitespace.
      a === null || Q(a) || Ue(a) ? n(a) : t(a)
    );
  }
  function i(a) {
    return a === null || a === 40 || a === 91 || Q(a) || Ue(a) ? n(a) : r(a);
  }
  function l(a) {
    return ce(a) ? o(a) : t(a);
  }
  function o(a) {
    return a === 59 ? (e.consume(a), r) : ce(a) ? (e.consume(a), o) : t(a);
  }
}
function fy(e, n, t) {
  return r;
  function r(l) {
    return e.consume(l), i;
  }
  function i(l) {
    return ae(l) ? t(l) : n(l);
  }
}
function Sl(e) {
  return e === null || e === 40 || e === 42 || e === 95 || e === 91 || e === 93 || e === 126 || Q(e);
}
function El(e) {
  return !ce(e);
}
function Cl(e) {
  return !(e === 47 || Et(e));
}
function Et(e) {
  return e === 43 || e === 45 || e === 46 || e === 95 || ae(e);
}
function yr(e) {
  let n = e.length, t = !1;
  for (; n--; ) {
    const r = e[n][1];
    if ((r.type === "labelLink" || r.type === "labelImage") && !r._balanced) {
      t = !0;
      break;
    }
    if (r._gfmAutolinkLiteralWalkedInto) {
      t = !1;
      break;
    }
  }
  return e.length > 0 && !t && (e[e.length - 1][1]._gfmAutolinkLiteralWalkedInto = !0), t;
}
const hy = {
  tokenize: wy,
  partial: !0
};
function dy() {
  return {
    document: {
      91: {
        name: "gfmFootnoteDefinition",
        tokenize: yy,
        continuation: {
          tokenize: ky
        },
        exit: xy
      }
    },
    text: {
      91: {
        name: "gfmFootnoteCall",
        tokenize: by
      },
      93: {
        name: "gfmPotentialFootnoteCall",
        add: "after",
        tokenize: gy,
        resolveTo: my
      }
    }
  };
}
function gy(e, n, t) {
  const r = this;
  let i = r.events.length;
  const l = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
  let o;
  for (; i--; ) {
    const s = r.events[i][1];
    if (s.type === "labelImage") {
      o = s;
      break;
    }
    if (s.type === "gfmFootnoteCall" || s.type === "labelLink" || s.type === "label" || s.type === "image" || s.type === "link")
      break;
  }
  return a;
  function a(s) {
    if (!o || !o._balanced)
      return t(s);
    const u = Ce(r.sliceSerialize({
      start: o.end,
      end: r.now()
    }));
    return u.codePointAt(0) !== 94 || !l.includes(u.slice(1)) ? t(s) : (e.enter("gfmFootnoteCallLabelMarker"), e.consume(s), e.exit("gfmFootnoteCallLabelMarker"), n(s));
  }
}
function my(e, n) {
  let t = e.length;
  for (; t--; )
    if (e[t][1].type === "labelImage" && e[t][0] === "enter") {
      e[t][1];
      break;
    }
  e[t + 1][1].type = "data", e[t + 3][1].type = "gfmFootnoteCallLabelMarker";
  const r = {
    type: "gfmFootnoteCall",
    start: Object.assign({}, e[t + 3][1].start),
    end: Object.assign({}, e[e.length - 1][1].end)
  }, i = {
    type: "gfmFootnoteCallMarker",
    start: Object.assign({}, e[t + 3][1].end),
    end: Object.assign({}, e[t + 3][1].end)
  };
  i.end.column++, i.end.offset++, i.end._bufferIndex++;
  const l = {
    type: "gfmFootnoteCallString",
    start: Object.assign({}, i.end),
    end: Object.assign({}, e[e.length - 1][1].start)
  }, o = {
    type: "chunkString",
    contentType: "string",
    start: Object.assign({}, l.start),
    end: Object.assign({}, l.end)
  }, a = [
    // Take the `labelImageMarker` (now `data`, the `!`)
    e[t + 1],
    e[t + 2],
    ["enter", r, n],
    // The `[`
    e[t + 3],
    e[t + 4],
    // The `^`.
    ["enter", i, n],
    ["exit", i, n],
    // Everything in between.
    ["enter", l, n],
    ["enter", o, n],
    ["exit", o, n],
    ["exit", l, n],
    // The ending (`]`, properly parsed and labelled).
    e[e.length - 2],
    e[e.length - 1],
    ["exit", r, n]
  ];
  return e.splice(t, e.length - t + 1, ...a), e;
}
function by(e, n, t) {
  const r = this, i = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
  let l = 0, o;
  return a;
  function a(c) {
    return e.enter("gfmFootnoteCall"), e.enter("gfmFootnoteCallLabelMarker"), e.consume(c), e.exit("gfmFootnoteCallLabelMarker"), s;
  }
  function s(c) {
    return c !== 94 ? t(c) : (e.enter("gfmFootnoteCallMarker"), e.consume(c), e.exit("gfmFootnoteCallMarker"), e.enter("gfmFootnoteCallString"), e.enter("chunkString").contentType = "string", u);
  }
  function u(c) {
    if (
      // Too long.
      l > 999 || // Closing brace with nothing.
      c === 93 && !o || // Space or tab is not supported by GFM for some reason.
      // `\n` and `[` not being supported makes sense.
      c === null || c === 91 || Q(c)
    )
      return t(c);
    if (c === 93) {
      e.exit("chunkString");
      const h = e.exit("gfmFootnoteCallString");
      return i.includes(Ce(r.sliceSerialize(h))) ? (e.enter("gfmFootnoteCallLabelMarker"), e.consume(c), e.exit("gfmFootnoteCallLabelMarker"), e.exit("gfmFootnoteCall"), n) : t(c);
    }
    return Q(c) || (o = !0), l++, e.consume(c), c === 92 ? p : u;
  }
  function p(c) {
    return c === 91 || c === 92 || c === 93 ? (e.consume(c), l++, u) : u(c);
  }
}
function yy(e, n, t) {
  const r = this, i = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
  let l, o = 0, a;
  return s;
  function s(g) {
    return e.enter("gfmFootnoteDefinition")._container = !0, e.enter("gfmFootnoteDefinitionLabel"), e.enter("gfmFootnoteDefinitionLabelMarker"), e.consume(g), e.exit("gfmFootnoteDefinitionLabelMarker"), u;
  }
  function u(g) {
    return g === 94 ? (e.enter("gfmFootnoteDefinitionMarker"), e.consume(g), e.exit("gfmFootnoteDefinitionMarker"), e.enter("gfmFootnoteDefinitionLabelString"), e.enter("chunkString").contentType = "string", p) : t(g);
  }
  function p(g) {
    if (
      // Too long.
      o > 999 || // Closing brace with nothing.
      g === 93 && !a || // Space or tab is not supported by GFM for some reason.
      // `\n` and `[` not being supported makes sense.
      g === null || g === 91 || Q(g)
    )
      return t(g);
    if (g === 93) {
      e.exit("chunkString");
      const v = e.exit("gfmFootnoteDefinitionLabelString");
      return l = Ce(r.sliceSerialize(v)), e.enter("gfmFootnoteDefinitionLabelMarker"), e.consume(g), e.exit("gfmFootnoteDefinitionLabelMarker"), e.exit("gfmFootnoteDefinitionLabel"), h;
    }
    return Q(g) || (a = !0), o++, e.consume(g), g === 92 ? c : p;
  }
  function c(g) {
    return g === 91 || g === 92 || g === 93 ? (e.consume(g), o++, p) : p(g);
  }
  function h(g) {
    return g === 58 ? (e.enter("definitionMarker"), e.consume(g), e.exit("definitionMarker"), i.includes(l) || i.push(l), G(e, f, "gfmFootnoteDefinitionWhitespace")) : t(g);
  }
  function f(g) {
    return n(g);
  }
}
function ky(e, n, t) {
  return e.check(wn, n, e.attempt(hy, n, t));
}
function xy(e) {
  e.exit("gfmFootnoteDefinition");
}
function wy(e, n, t) {
  const r = this;
  return G(e, i, "gfmFootnoteDefinitionIndent", 5);
  function i(l) {
    const o = r.events[r.events.length - 1];
    return o && o[1].type === "gfmFootnoteDefinitionIndent" && o[2].sliceSerialize(o[1], !0).length === 4 ? n(l) : t(l);
  }
}
function vy(e) {
  let t = (e || {}).singleTilde;
  const r = {
    name: "strikethrough",
    tokenize: l,
    resolveAll: i
  };
  return t == null && (t = !0), {
    text: {
      126: r
    },
    insideSpan: {
      null: [r]
    },
    attentionMarkers: {
      null: [126]
    }
  };
  function i(o, a) {
    let s = -1;
    for (; ++s < o.length; )
      if (o[s][0] === "enter" && o[s][1].type === "strikethroughSequenceTemporary" && o[s][1]._close) {
        let u = s;
        for (; u--; )
          if (o[u][0] === "exit" && o[u][1].type === "strikethroughSequenceTemporary" && o[u][1]._open && // If the sizes are the same:
          o[s][1].end.offset - o[s][1].start.offset === o[u][1].end.offset - o[u][1].start.offset) {
            o[s][1].type = "strikethroughSequence", o[u][1].type = "strikethroughSequence";
            const p = {
              type: "strikethrough",
              start: Object.assign({}, o[u][1].start),
              end: Object.assign({}, o[s][1].end)
            }, c = {
              type: "strikethroughText",
              start: Object.assign({}, o[u][1].end),
              end: Object.assign({}, o[s][1].start)
            }, h = [["enter", p, a], ["enter", o[u][1], a], ["exit", o[u][1], a], ["enter", c, a]], f = a.parser.constructs.insideSpan.null;
            f && be(h, h.length, 0, Bn(f, o.slice(u + 1, s), a)), be(h, h.length, 0, [["exit", c, a], ["enter", o[s][1], a], ["exit", o[s][1], a], ["exit", p, a]]), be(o, u - 1, s - u + 3, h), s = u + h.length - 2;
            break;
          }
      }
    for (s = -1; ++s < o.length; )
      o[s][1].type === "strikethroughSequenceTemporary" && (o[s][1].type = "data");
    return o;
  }
  function l(o, a, s) {
    const u = this.previous, p = this.events;
    let c = 0;
    return h;
    function h(g) {
      return u === 126 && p[p.length - 1][1].type !== "characterEscape" ? s(g) : (o.enter("strikethroughSequenceTemporary"), f(g));
    }
    function f(g) {
      const v = Qe(u);
      if (g === 126)
        return c > 1 ? s(g) : (o.consume(g), c++, f);
      if (c < 2 && !t) return s(g);
      const A = o.exit("strikethroughSequenceTemporary"), w = Qe(g);
      return A._open = !w || w === 2 && !!v, A._close = !v || v === 2 && !!w, a(g);
    }
  }
}
class Sy {
  /**
   * Create a new edit map.
   */
  constructor() {
    this.map = [];
  }
  /**
   * Create an edit: a remove and/or add at a certain place.
   *
   * @param {number} index
   * @param {number} remove
   * @param {Array<Event>} add
   * @returns {undefined}
   */
  add(n, t, r) {
    Ey(this, n, t, r);
  }
  // To do: add this when moving to `micromark`.
  // /**
  //  * Create an edit: but insert `add` before existing additions.
  //  *
  //  * @param {number} index
  //  * @param {number} remove
  //  * @param {Array<Event>} add
  //  * @returns {undefined}
  //  */
  // addBefore(index, remove, add) {
  //   addImplementation(this, index, remove, add, true)
  // }
  /**
   * Done, change the events.
   *
   * @param {Array<Event>} events
   * @returns {undefined}
   */
  consume(n) {
    if (this.map.sort(function(l, o) {
      return l[0] - o[0];
    }), this.map.length === 0)
      return;
    let t = this.map.length;
    const r = [];
    for (; t > 0; )
      t -= 1, r.push(n.slice(this.map[t][0] + this.map[t][1]), this.map[t][2]), n.length = this.map[t][0];
    r.push(n.slice()), n.length = 0;
    let i = r.pop();
    for (; i; ) {
      for (const l of i)
        n.push(l);
      i = r.pop();
    }
    this.map.length = 0;
  }
}
function Ey(e, n, t, r) {
  let i = 0;
  if (!(t === 0 && r.length === 0)) {
    for (; i < e.map.length; ) {
      if (e.map[i][0] === n) {
        e.map[i][1] += t, e.map[i][2].push(...r);
        return;
      }
      i += 1;
    }
    e.map.push([n, t, r]);
  }
}
function Cy(e, n) {
  let t = !1;
  const r = [];
  for (; n < e.length; ) {
    const i = e[n];
    if (t) {
      if (i[0] === "enter")
        i[1].type === "tableContent" && r.push(e[n + 1][1].type === "tableDelimiterMarker" ? "left" : "none");
      else if (i[1].type === "tableContent") {
        if (e[n - 1][1].type === "tableDelimiterMarker") {
          const l = r.length - 1;
          r[l] = r[l] === "left" ? "center" : "right";
        }
      } else if (i[1].type === "tableDelimiterRow")
        break;
    } else i[0] === "enter" && i[1].type === "tableDelimiterRow" && (t = !0);
    n += 1;
  }
  return r;
}
function Ay() {
  return {
    flow: {
      null: {
        name: "table",
        tokenize: Ty,
        resolveAll: Iy
      }
    }
  };
}
function Ty(e, n, t) {
  const r = this;
  let i = 0, l = 0, o;
  return a;
  function a(x) {
    let L = r.events.length - 1;
    for (; L > -1; ) {
      const j = r.events[L][1].type;
      if (j === "lineEnding" || // Note: markdown-rs uses `whitespace` instead of `linePrefix`
      j === "linePrefix") L--;
      else break;
    }
    const _ = L > -1 ? r.events[L][1].type : null, P = _ === "tableHead" || _ === "tableRow" ? m : s;
    return P === m && r.parser.lazy[r.now().line] ? t(x) : P(x);
  }
  function s(x) {
    return e.enter("tableHead"), e.enter("tableRow"), u(x);
  }
  function u(x) {
    return x === 124 || (o = !0, l += 1), p(x);
  }
  function p(x) {
    return x === null ? t(x) : F(x) ? l > 1 ? (l = 0, r.interrupt = !0, e.exit("tableRow"), e.enter("lineEnding"), e.consume(x), e.exit("lineEnding"), f) : t(x) : H(x) ? G(e, p, "whitespace")(x) : (l += 1, o && (o = !1, i += 1), x === 124 ? (e.enter("tableCellDivider"), e.consume(x), e.exit("tableCellDivider"), o = !0, p) : (e.enter("data"), c(x)));
  }
  function c(x) {
    return x === null || x === 124 || Q(x) ? (e.exit("data"), p(x)) : (e.consume(x), x === 92 ? h : c);
  }
  function h(x) {
    return x === 92 || x === 124 ? (e.consume(x), c) : c(x);
  }
  function f(x) {
    return r.interrupt = !1, r.parser.lazy[r.now().line] ? t(x) : (e.enter("tableDelimiterRow"), o = !1, H(x) ? G(e, g, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(x) : g(x));
  }
  function g(x) {
    return x === 45 || x === 58 ? A(x) : x === 124 ? (o = !0, e.enter("tableCellDivider"), e.consume(x), e.exit("tableCellDivider"), v) : S(x);
  }
  function v(x) {
    return H(x) ? G(e, A, "whitespace")(x) : A(x);
  }
  function A(x) {
    return x === 58 ? (l += 1, o = !0, e.enter("tableDelimiterMarker"), e.consume(x), e.exit("tableDelimiterMarker"), w) : x === 45 ? (l += 1, w(x)) : x === null || F(x) ? E(x) : S(x);
  }
  function w(x) {
    return x === 45 ? (e.enter("tableDelimiterFiller"), k(x)) : S(x);
  }
  function k(x) {
    return x === 45 ? (e.consume(x), k) : x === 58 ? (o = !0, e.exit("tableDelimiterFiller"), e.enter("tableDelimiterMarker"), e.consume(x), e.exit("tableDelimiterMarker"), y) : (e.exit("tableDelimiterFiller"), y(x));
  }
  function y(x) {
    return H(x) ? G(e, E, "whitespace")(x) : E(x);
  }
  function E(x) {
    return x === 124 ? g(x) : x === null || F(x) ? !o || i !== l ? S(x) : (e.exit("tableDelimiterRow"), e.exit("tableHead"), n(x)) : S(x);
  }
  function S(x) {
    return t(x);
  }
  function m(x) {
    return e.enter("tableRow"), I(x);
  }
  function I(x) {
    return x === 124 ? (e.enter("tableCellDivider"), e.consume(x), e.exit("tableCellDivider"), I) : x === null || F(x) ? (e.exit("tableRow"), n(x)) : H(x) ? G(e, I, "whitespace")(x) : (e.enter("data"), N(x));
  }
  function N(x) {
    return x === null || x === 124 || Q(x) ? (e.exit("data"), I(x)) : (e.consume(x), x === 92 ? T : N);
  }
  function T(x) {
    return x === 92 || x === 124 ? (e.consume(x), N) : N(x);
  }
}
function Iy(e, n) {
  let t = -1, r = !0, i = 0, l = [0, 0, 0, 0], o = [0, 0, 0, 0], a = !1, s = 0, u, p, c;
  const h = new Sy();
  for (; ++t < e.length; ) {
    const f = e[t], g = f[1];
    f[0] === "enter" ? g.type === "tableHead" ? (a = !1, s !== 0 && (Mi(h, n, s, u, p), p = void 0, s = 0), u = {
      type: "table",
      start: Object.assign({}, g.start),
      // Note: correct end is set later.
      end: Object.assign({}, g.end)
    }, h.add(t, 0, [["enter", u, n]])) : g.type === "tableRow" || g.type === "tableDelimiterRow" ? (r = !0, c = void 0, l = [0, 0, 0, 0], o = [0, t + 1, 0, 0], a && (a = !1, p = {
      type: "tableBody",
      start: Object.assign({}, g.start),
      // Note: correct end is set later.
      end: Object.assign({}, g.end)
    }, h.add(t, 0, [["enter", p, n]])), i = g.type === "tableDelimiterRow" ? 2 : p ? 3 : 1) : i && (g.type === "data" || g.type === "tableDelimiterMarker" || g.type === "tableDelimiterFiller") ? (r = !1, o[2] === 0 && (l[1] !== 0 && (o[0] = o[1], c = In(h, n, l, i, void 0, c), l = [0, 0, 0, 0]), o[2] = t)) : g.type === "tableCellDivider" && (r ? r = !1 : (l[1] !== 0 && (o[0] = o[1], c = In(h, n, l, i, void 0, c)), l = o, o = [l[1], t, 0, 0])) : g.type === "tableHead" ? (a = !0, s = t) : g.type === "tableRow" || g.type === "tableDelimiterRow" ? (s = t, l[1] !== 0 ? (o[0] = o[1], c = In(h, n, l, i, t, c)) : o[1] !== 0 && (c = In(h, n, o, i, t, c)), i = 0) : i && (g.type === "data" || g.type === "tableDelimiterMarker" || g.type === "tableDelimiterFiller") && (o[3] = t);
  }
  for (s !== 0 && Mi(h, n, s, u, p), h.consume(n.events), t = -1; ++t < n.events.length; ) {
    const f = n.events[t];
    f[0] === "enter" && f[1].type === "table" && (f[1]._align = Cy(n.events, t));
  }
  return e;
}
function In(e, n, t, r, i, l) {
  const o = r === 1 ? "tableHeader" : r === 2 ? "tableDelimiter" : "tableData", a = "tableContent";
  t[0] !== 0 && (l.end = Object.assign({}, Xe(n.events, t[0])), e.add(t[0], 0, [["exit", l, n]]));
  const s = Xe(n.events, t[1]);
  if (l = {
    type: o,
    start: Object.assign({}, s),
    // Note: correct end is set later.
    end: Object.assign({}, s)
  }, e.add(t[1], 0, [["enter", l, n]]), t[2] !== 0) {
    const u = Xe(n.events, t[2]), p = Xe(n.events, t[3]), c = {
      type: a,
      start: Object.assign({}, u),
      end: Object.assign({}, p)
    };
    if (e.add(t[2], 0, [["enter", c, n]]), r !== 2) {
      const h = n.events[t[2]], f = n.events[t[3]];
      if (h[1].end = Object.assign({}, f[1].end), h[1].type = "chunkText", h[1].contentType = "text", t[3] > t[2] + 1) {
        const g = t[2] + 1, v = t[3] - t[2] - 1;
        e.add(g, v, []);
      }
    }
    e.add(t[3] + 1, 0, [["exit", c, n]]);
  }
  return i !== void 0 && (l.end = Object.assign({}, Xe(n.events, i)), e.add(i, 0, [["exit", l, n]]), l = void 0), l;
}
function Mi(e, n, t, r, i) {
  const l = [], o = Xe(n.events, t);
  i && (i.end = Object.assign({}, o), l.push(["exit", i, n])), r.end = Object.assign({}, o), l.push(["exit", r, n]), e.add(t + 1, 0, l);
}
function Xe(e, n) {
  const t = e[n], r = t[0] === "enter" ? "start" : "end";
  return t[1][r];
}
const Oy = {
  name: "tasklistCheck",
  tokenize: Ry
};
function Ly() {
  return {
    text: {
      91: Oy
    }
  };
}
function Ry(e, n, t) {
  const r = this;
  return i;
  function i(s) {
    return (
      // Exit if there’s stuff before.
      r.previous !== null || // Exit if not in the first content that is the first child of a list
      // item.
      !r._gfmTasklistFirstContentOfListItem ? t(s) : (e.enter("taskListCheck"), e.enter("taskListCheckMarker"), e.consume(s), e.exit("taskListCheckMarker"), l)
    );
  }
  function l(s) {
    return Q(s) ? (e.enter("taskListCheckValueUnchecked"), e.consume(s), e.exit("taskListCheckValueUnchecked"), o) : s === 88 || s === 120 ? (e.enter("taskListCheckValueChecked"), e.consume(s), e.exit("taskListCheckValueChecked"), o) : t(s);
  }
  function o(s) {
    return s === 93 ? (e.enter("taskListCheckMarker"), e.consume(s), e.exit("taskListCheckMarker"), e.exit("taskListCheck"), a) : t(s);
  }
  function a(s) {
    return F(s) ? n(s) : H(s) ? e.check({
      tokenize: Ny
    }, n, t)(s) : t(s);
  }
}
function Ny(e, n, t) {
  return G(e, r, "whitespace");
  function r(i) {
    return i === null ? t(i) : n(i);
  }
}
function _y(e) {
  return Fo([
    iy(),
    dy(),
    vy(e),
    Ay(),
    Ly()
  ]);
}
const Fy = {};
function Dy(e) {
  const n = (
    /** @type {Processor<Root>} */
    this
  ), t = e || Fy, r = n.data(), i = r.micromarkExtensions || (r.micromarkExtensions = []), l = r.fromMarkdownExtensions || (r.fromMarkdownExtensions = []), o = r.toMarkdownExtensions || (r.toMarkdownExtensions = []);
  i.push(_y(t)), l.push(ey()), o.push(ny(t));
}
const tk = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Dy
}, Symbol.toStringTag, { value: "Module" }));
export {
  Yy as A,
  Xy as B,
  Ky as C,
  ek as D,
  tk as E,
  Qy as a,
  Gp as b,
  uf as c,
  er as d,
  To as e,
  of as f,
  Dn as g,
  sf as h,
  zy as i,
  On as j,
  My as k,
  $y as l,
  jy as m,
  ht as n,
  Zy as o,
  Jy as p,
  Uy as q,
  Hy as r,
  Qt as s,
  By as t,
  Vy as u,
  pr as v,
  qy as w,
  Gy as x,
  Wy as y,
  nk as z
};
