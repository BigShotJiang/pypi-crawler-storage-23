import { j as y } from "./refast-markdown-ByFT1VZb.js";
import { r as C, R as g } from "./refast-charts-C9YTpQC6.js";
import { u as me, a as _e, c as it, P as se, b as he, d as Gt, e as zt, f as Cr, g as Vt, h as $t, i as qt, I as Nr, R as Wr, j as P, k as Re, l as Ot, m as Kt, B as Pr } from "./refast-index-iXHSFA1L.js";
import { cI as Er, cH as _r, cF as Tr } from "./refast-icons-C3hKXcni.js";
var He = "Switch", [Yr] = it(He), [jr, Ir] = Yr(He), Ut = C.forwardRef(
  (e, t) => {
    const {
      __scopeSwitch: n,
      name: r,
      checked: o,
      defaultChecked: a,
      required: s,
      disabled: i,
      value: c = "on",
      onCheckedChange: u,
      form: d,
      ...l
    } = e, [h, b] = C.useState(null), M = me(t, (f) => b(f)), p = C.useRef(!1), v = h ? d || !!h.closest("form") : !0, [w, D] = _e({
      prop: o,
      defaultProp: a ?? !1,
      onChange: u,
      caller: He
    });
    return /* @__PURE__ */ y.jsxs(jr, { scope: n, checked: w, disabled: i, children: [
      /* @__PURE__ */ y.jsx(
        se.button,
        {
          type: "button",
          role: "switch",
          "aria-checked": w,
          "aria-required": s,
          "data-state": Zt(w),
          "data-disabled": i ? "" : void 0,
          disabled: i,
          value: c,
          ...l,
          ref: M,
          onClick: he(e.onClick, (f) => {
            D((k) => !k), v && (p.current = f.isPropagationStopped(), p.current || f.stopPropagation());
          })
        }
      ),
      v && /* @__PURE__ */ y.jsx(
        Jt,
        {
          control: h,
          bubbles: !p.current,
          name: r,
          value: c,
          checked: w,
          required: s,
          disabled: i,
          form: d,
          style: { transform: "translateX(-100%)" }
        }
      )
    ] });
  }
);
Ut.displayName = He;
var Xt = "SwitchThumb", Qt = C.forwardRef(
  (e, t) => {
    const { __scopeSwitch: n, ...r } = e, o = Ir(Xt, n);
    return /* @__PURE__ */ y.jsx(
      se.span,
      {
        "data-state": Zt(o.checked),
        "data-disabled": o.disabled ? "" : void 0,
        ...r,
        ref: t
      }
    );
  }
);
Qt.displayName = Xt;
var Br = "SwitchBubbleInput", Jt = C.forwardRef(
  ({
    __scopeSwitch: e,
    control: t,
    checked: n,
    bubbles: r = !0,
    ...o
  }, a) => {
    const s = C.useRef(null), i = me(s, a), c = Gt(n), u = zt(t);
    return C.useEffect(() => {
      const d = s.current;
      if (!d) return;
      const l = window.HTMLInputElement.prototype, b = Object.getOwnPropertyDescriptor(
        l,
        "checked"
      ).set;
      if (c !== n && b) {
        const M = new Event("click", { bubbles: r });
        b.call(d, n), d.dispatchEvent(M);
      }
    }, [c, n, r]), /* @__PURE__ */ y.jsx(
      "input",
      {
        type: "checkbox",
        "aria-hidden": !0,
        defaultChecked: n,
        ...o,
        tabIndex: -1,
        ref: i,
        style: {
          ...o.style,
          ...u,
          position: "absolute",
          pointerEvents: "none",
          opacity: 0,
          margin: 0
        }
      }
    );
  }
);
Jt.displayName = Br;
function Zt(e) {
  return e ? "checked" : "unchecked";
}
var Fr = Ut, Ar = Qt, Lt = ["PageUp", "PageDown"], en = ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"], tn = {
  "from-left": ["Home", "PageDown", "ArrowDown", "ArrowLeft"],
  "from-right": ["Home", "PageDown", "ArrowDown", "ArrowRight"],
  "from-bottom": ["Home", "PageDown", "ArrowDown", "ArrowLeft"],
  "from-top": ["Home", "PageDown", "ArrowUp", "ArrowLeft"]
}, Me = "Slider", [rt, Rr, Hr] = Cr(Me), [nn] = it(Me, [
  Hr
]), [Gr, Ge] = nn(Me), rn = C.forwardRef(
  (e, t) => {
    const {
      name: n,
      min: r = 0,
      max: o = 100,
      step: a = 1,
      orientation: s = "horizontal",
      disabled: i = !1,
      minStepsBetweenThumbs: c = 0,
      defaultValue: u = [r],
      value: d,
      onValueChange: l = () => {
      },
      onValueCommit: h = () => {
      },
      inverted: b = !1,
      form: M,
      ...p
    } = e, v = C.useRef(/* @__PURE__ */ new Set()), w = C.useRef(0), f = s === "horizontal" ? zr : Vr, [k = [], x] = _e({
      prop: d,
      defaultProp: u,
      onChange: (j) => {
        var I;
        (I = [...v.current][w.current]) == null || I.focus(), l(j);
      }
    }), m = C.useRef(k);
    function O(j) {
      const W = Xr(k, j);
      F(j, W);
    }
    function B(j) {
      F(j, w.current);
    }
    function Y() {
      const j = m.current[w.current];
      k[w.current] !== j && h(k);
    }
    function F(j, W, { commit: I } = { commit: !1 }) {
      const S = Lr(a), A = eo(Math.round((j - r) / a) * a + r, S), X = $t(A, [r, o]);
      x((_ = []) => {
        const K = Kr(_, X, W);
        if (Zr(K, c * a)) {
          w.current = K.indexOf(X);
          const $ = String(K) !== String(_);
          return $ && I && h(K), $ ? K : _;
        } else
          return _;
      });
    }
    return /* @__PURE__ */ y.jsx(
      Gr,
      {
        scope: e.__scopeSlider,
        name: n,
        disabled: i,
        min: r,
        max: o,
        valueIndexToChangeRef: w,
        thumbs: v.current,
        values: k,
        orientation: s,
        form: M,
        children: /* @__PURE__ */ y.jsx(rt.Provider, { scope: e.__scopeSlider, children: /* @__PURE__ */ y.jsx(rt.Slot, { scope: e.__scopeSlider, children: /* @__PURE__ */ y.jsx(
          f,
          {
            "aria-disabled": i,
            "data-disabled": i ? "" : void 0,
            ...p,
            ref: t,
            onPointerDown: he(p.onPointerDown, () => {
              i || (m.current = k);
            }),
            min: r,
            max: o,
            inverted: b,
            onSlideStart: i ? void 0 : O,
            onSlideMove: i ? void 0 : B,
            onSlideEnd: i ? void 0 : Y,
            onHomeKeyDown: () => !i && F(r, 0, { commit: !0 }),
            onEndKeyDown: () => !i && F(o, k.length - 1, { commit: !0 }),
            onStepKeyDown: ({ event: j, direction: W }) => {
              if (!i) {
                const A = Lt.includes(j.key) || j.shiftKey && en.includes(j.key) ? 10 : 1, X = w.current, _ = k[X], K = a * A * W;
                F(_ + K, X, { commit: !0 });
              }
            }
          }
        ) }) })
      }
    );
  }
);
rn.displayName = Me;
var [on, an] = nn(Me, {
  startEdge: "left",
  endEdge: "right",
  size: "width",
  direction: 1
}), zr = C.forwardRef(
  (e, t) => {
    const {
      min: n,
      max: r,
      dir: o,
      inverted: a,
      onSlideStart: s,
      onSlideMove: i,
      onSlideEnd: c,
      onStepKeyDown: u,
      ...d
    } = e, [l, h] = C.useState(null), b = me(t, (f) => h(f)), M = C.useRef(void 0), p = Vt(o), v = p === "ltr", w = v && !a || !v && a;
    function D(f) {
      const k = M.current || l.getBoundingClientRect(), x = [0, k.width], O = ct(x, w ? [n, r] : [r, n]);
      return M.current = k, O(f - k.left);
    }
    return /* @__PURE__ */ y.jsx(
      on,
      {
        scope: e.__scopeSlider,
        startEdge: w ? "left" : "right",
        endEdge: w ? "right" : "left",
        direction: w ? 1 : -1,
        size: "width",
        children: /* @__PURE__ */ y.jsx(
          sn,
          {
            dir: p,
            "data-orientation": "horizontal",
            ...d,
            ref: b,
            style: {
              ...d.style,
              "--radix-slider-thumb-transform": "translateX(-50%)"
            },
            onSlideStart: (f) => {
              const k = D(f.clientX);
              s == null || s(k);
            },
            onSlideMove: (f) => {
              const k = D(f.clientX);
              i == null || i(k);
            },
            onSlideEnd: () => {
              M.current = void 0, c == null || c();
            },
            onStepKeyDown: (f) => {
              const x = tn[w ? "from-left" : "from-right"].includes(f.key);
              u == null || u({ event: f, direction: x ? -1 : 1 });
            }
          }
        )
      }
    );
  }
), Vr = C.forwardRef(
  (e, t) => {
    const {
      min: n,
      max: r,
      inverted: o,
      onSlideStart: a,
      onSlideMove: s,
      onSlideEnd: i,
      onStepKeyDown: c,
      ...u
    } = e, d = C.useRef(null), l = me(t, d), h = C.useRef(void 0), b = !o;
    function M(p) {
      const v = h.current || d.current.getBoundingClientRect(), w = [0, v.height], f = ct(w, b ? [r, n] : [n, r]);
      return h.current = v, f(p - v.top);
    }
    return /* @__PURE__ */ y.jsx(
      on,
      {
        scope: e.__scopeSlider,
        startEdge: b ? "bottom" : "top",
        endEdge: b ? "top" : "bottom",
        size: "height",
        direction: b ? 1 : -1,
        children: /* @__PURE__ */ y.jsx(
          sn,
          {
            "data-orientation": "vertical",
            ...u,
            ref: l,
            style: {
              ...u.style,
              "--radix-slider-thumb-transform": "translateY(50%)"
            },
            onSlideStart: (p) => {
              const v = M(p.clientY);
              a == null || a(v);
            },
            onSlideMove: (p) => {
              const v = M(p.clientY);
              s == null || s(v);
            },
            onSlideEnd: () => {
              h.current = void 0, i == null || i();
            },
            onStepKeyDown: (p) => {
              const w = tn[b ? "from-bottom" : "from-top"].includes(p.key);
              c == null || c({ event: p, direction: w ? -1 : 1 });
            }
          }
        )
      }
    );
  }
), sn = C.forwardRef(
  (e, t) => {
    const {
      __scopeSlider: n,
      onSlideStart: r,
      onSlideMove: o,
      onSlideEnd: a,
      onHomeKeyDown: s,
      onEndKeyDown: i,
      onStepKeyDown: c,
      ...u
    } = e, d = Ge(Me, n);
    return /* @__PURE__ */ y.jsx(
      se.span,
      {
        ...u,
        ref: t,
        onKeyDown: he(e.onKeyDown, (l) => {
          l.key === "Home" ? (s(l), l.preventDefault()) : l.key === "End" ? (i(l), l.preventDefault()) : Lt.concat(en).includes(l.key) && (c(l), l.preventDefault());
        }),
        onPointerDown: he(e.onPointerDown, (l) => {
          const h = l.target;
          h.setPointerCapture(l.pointerId), l.preventDefault(), d.thumbs.has(h) ? h.focus() : r(l);
        }),
        onPointerMove: he(e.onPointerMove, (l) => {
          l.target.hasPointerCapture(l.pointerId) && o(l);
        }),
        onPointerUp: he(e.onPointerUp, (l) => {
          const h = l.target;
          h.hasPointerCapture(l.pointerId) && (h.releasePointerCapture(l.pointerId), a(l));
        })
      }
    );
  }
), cn = "SliderTrack", un = C.forwardRef(
  (e, t) => {
    const { __scopeSlider: n, ...r } = e, o = Ge(cn, n);
    return /* @__PURE__ */ y.jsx(
      se.span,
      {
        "data-disabled": o.disabled ? "" : void 0,
        "data-orientation": o.orientation,
        ...r,
        ref: t
      }
    );
  }
);
un.displayName = cn;
var ot = "SliderRange", ln = C.forwardRef(
  (e, t) => {
    const { __scopeSlider: n, ...r } = e, o = Ge(ot, n), a = an(ot, n), s = C.useRef(null), i = me(t, s), c = o.values.length, u = o.values.map(
      (h) => hn(h, o.min, o.max)
    ), d = c > 1 ? Math.min(...u) : 0, l = 100 - Math.max(...u);
    return /* @__PURE__ */ y.jsx(
      se.span,
      {
        "data-orientation": o.orientation,
        "data-disabled": o.disabled ? "" : void 0,
        ...r,
        ref: i,
        style: {
          ...e.style,
          [a.startEdge]: d + "%",
          [a.endEdge]: l + "%"
        }
      }
    );
  }
);
ln.displayName = ot;
var at = "SliderThumb", dn = C.forwardRef(
  (e, t) => {
    const n = Rr(e.__scopeSlider), [r, o] = C.useState(null), a = me(t, (i) => o(i)), s = C.useMemo(
      () => r ? n().findIndex((i) => i.ref.current === r) : -1,
      [n, r]
    );
    return /* @__PURE__ */ y.jsx($r, { ...e, ref: a, index: s });
  }
), $r = C.forwardRef(
  (e, t) => {
    const { __scopeSlider: n, index: r, name: o, ...a } = e, s = Ge(at, n), i = an(at, n), [c, u] = C.useState(null), d = me(t, (D) => u(D)), l = c ? s.form || !!c.closest("form") : !0, h = zt(c), b = s.values[r], M = b === void 0 ? 0 : hn(b, s.min, s.max), p = Ur(r, s.values.length), v = h == null ? void 0 : h[i.size], w = v ? Qr(v, M, i.direction) : 0;
    return C.useEffect(() => {
      if (c)
        return s.thumbs.add(c), () => {
          s.thumbs.delete(c);
        };
    }, [c, s.thumbs]), /* @__PURE__ */ y.jsxs(
      "span",
      {
        style: {
          transform: "var(--radix-slider-thumb-transform)",
          position: "absolute",
          [i.startEdge]: `calc(${M}% + ${w}px)`
        },
        children: [
          /* @__PURE__ */ y.jsx(rt.ItemSlot, { scope: e.__scopeSlider, children: /* @__PURE__ */ y.jsx(
            se.span,
            {
              role: "slider",
              "aria-label": e["aria-label"] || p,
              "aria-valuemin": s.min,
              "aria-valuenow": b,
              "aria-valuemax": s.max,
              "aria-orientation": s.orientation,
              "data-orientation": s.orientation,
              "data-disabled": s.disabled ? "" : void 0,
              tabIndex: s.disabled ? void 0 : 0,
              ...a,
              ref: d,
              style: b === void 0 ? { display: "none" } : e.style,
              onFocus: he(e.onFocus, () => {
                s.valueIndexToChangeRef.current = r;
              })
            }
          ) }),
          l && /* @__PURE__ */ y.jsx(
            fn,
            {
              name: o ?? (s.name ? s.name + (s.values.length > 1 ? "[]" : "") : void 0),
              form: s.form,
              value: b
            },
            r
          )
        ]
      }
    );
  }
);
dn.displayName = at;
var qr = "RadioBubbleInput", fn = C.forwardRef(
  ({ __scopeSlider: e, value: t, ...n }, r) => {
    const o = C.useRef(null), a = me(o, r), s = Gt(t);
    return C.useEffect(() => {
      const i = o.current;
      if (!i) return;
      const c = window.HTMLInputElement.prototype, d = Object.getOwnPropertyDescriptor(c, "value").set;
      if (s !== t && d) {
        const l = new Event("input", { bubbles: !0 });
        d.call(i, t), i.dispatchEvent(l);
      }
    }, [s, t]), /* @__PURE__ */ y.jsx(
      se.input,
      {
        style: { display: "none" },
        ...n,
        ref: a,
        defaultValue: t
      }
    );
  }
);
fn.displayName = qr;
function Kr(e = [], t, n) {
  const r = [...e];
  return r[n] = t, r.sort((o, a) => o - a);
}
function hn(e, t, n) {
  const a = 100 / (n - t) * (e - t);
  return $t(a, [0, 100]);
}
function Ur(e, t) {
  return t > 2 ? `Value ${e + 1} of ${t}` : t === 2 ? ["Minimum", "Maximum"][e] : void 0;
}
function Xr(e, t) {
  if (e.length === 1) return 0;
  const n = e.map((o) => Math.abs(o - t)), r = Math.min(...n);
  return n.indexOf(r);
}
function Qr(e, t, n) {
  const r = e / 2, a = ct([0, 50], [0, r]);
  return (r - a(t) * n) * n;
}
function Jr(e) {
  return e.slice(0, -1).map((t, n) => e[n + 1] - t);
}
function Zr(e, t) {
  if (t > 0) {
    const n = Jr(e);
    return Math.min(...n) >= t;
  }
  return !0;
}
function ct(e, t) {
  return (n) => {
    if (e[0] === e[1] || t[0] === t[1]) return t[0];
    const r = (t[1] - t[0]) / (e[1] - e[0]);
    return t[0] + r * (n - e[0]);
  };
}
function Lr(e) {
  return (String(e).split(".")[1] || "").length;
}
function eo(e, t) {
  const n = Math.pow(10, t);
  return Math.round(e * n) / n;
}
var to = rn, no = un, ro = ln, oo = dn, mn = "Toggle", ut = C.forwardRef((e, t) => {
  const { pressed: n, defaultPressed: r, onPressedChange: o, ...a } = e, [s, i] = _e({
    prop: n,
    onChange: o,
    defaultProp: r ?? !1,
    caller: mn
  });
  return /* @__PURE__ */ y.jsx(
    se.button,
    {
      type: "button",
      "aria-pressed": s,
      "data-state": s ? "on" : "off",
      "data-disabled": e.disabled ? "" : void 0,
      ...a,
      ref: t,
      onClick: he(e.onClick, () => {
        e.disabled || i(!s);
      })
    }
  );
});
ut.displayName = mn;
var ao = ut, ge = "ToggleGroup", [gn] = it(ge, [
  qt
]), yn = qt(), lt = g.forwardRef((e, t) => {
  const { type: n, ...r } = e;
  if (n === "single") {
    const o = r;
    return /* @__PURE__ */ y.jsx(so, { ...o, ref: t });
  }
  if (n === "multiple") {
    const o = r;
    return /* @__PURE__ */ y.jsx(io, { ...o, ref: t });
  }
  throw new Error(`Missing prop \`type\` expected on \`${ge}\``);
});
lt.displayName = ge;
var [bn, wn] = gn(ge), so = g.forwardRef((e, t) => {
  const {
    value: n,
    defaultValue: r,
    onValueChange: o = () => {
    },
    ...a
  } = e, [s, i] = _e({
    prop: n,
    defaultProp: r ?? "",
    onChange: o,
    caller: ge
  });
  return /* @__PURE__ */ y.jsx(
    bn,
    {
      scope: e.__scopeToggleGroup,
      type: "single",
      value: g.useMemo(() => s ? [s] : [], [s]),
      onItemActivate: i,
      onItemDeactivate: g.useCallback(() => i(""), [i]),
      children: /* @__PURE__ */ y.jsx(pn, { ...a, ref: t })
    }
  );
}), io = g.forwardRef((e, t) => {
  const {
    value: n,
    defaultValue: r,
    onValueChange: o = () => {
    },
    ...a
  } = e, [s, i] = _e({
    prop: n,
    defaultProp: r ?? [],
    onChange: o,
    caller: ge
  }), c = g.useCallback(
    (d) => i((l = []) => [...l, d]),
    [i]
  ), u = g.useCallback(
    (d) => i((l = []) => l.filter((h) => h !== d)),
    [i]
  );
  return /* @__PURE__ */ y.jsx(
    bn,
    {
      scope: e.__scopeToggleGroup,
      type: "multiple",
      value: s,
      onItemActivate: c,
      onItemDeactivate: u,
      children: /* @__PURE__ */ y.jsx(pn, { ...a, ref: t })
    }
  );
});
lt.displayName = ge;
var [co, uo] = gn(ge), pn = g.forwardRef(
  (e, t) => {
    const {
      __scopeToggleGroup: n,
      disabled: r = !1,
      rovingFocus: o = !0,
      orientation: a,
      dir: s,
      loop: i = !0,
      ...c
    } = e, u = yn(n), d = Vt(s), l = { role: "group", dir: d, ...c };
    return /* @__PURE__ */ y.jsx(co, { scope: n, rovingFocus: o, disabled: r, children: o ? /* @__PURE__ */ y.jsx(
      Wr,
      {
        asChild: !0,
        ...u,
        orientation: a,
        dir: d,
        loop: i,
        children: /* @__PURE__ */ y.jsx(se.div, { ...l, ref: t })
      }
    ) : /* @__PURE__ */ y.jsx(se.div, { ...l, ref: t }) });
  }
), Ae = "ToggleGroupItem", vn = g.forwardRef(
  (e, t) => {
    const n = wn(Ae, e.__scopeToggleGroup), r = uo(Ae, e.__scopeToggleGroup), o = yn(e.__scopeToggleGroup), a = n.value.includes(e.value), s = r.disabled || e.disabled, i = { ...e, pressed: a, disabled: s }, c = g.useRef(null);
    return r.rovingFocus ? /* @__PURE__ */ y.jsx(
      Nr,
      {
        asChild: !0,
        ...o,
        focusable: !s,
        active: a,
        ref: c,
        children: /* @__PURE__ */ y.jsx(Ct, { ...i, ref: t })
      }
    ) : /* @__PURE__ */ y.jsx(Ct, { ...i, ref: t });
  }
);
vn.displayName = Ae;
var Ct = g.forwardRef(
  (e, t) => {
    const { __scopeToggleGroup: n, value: r, ...o } = e, a = wn(Ae, n), s = { role: "radio", "aria-checked": e.pressed, "aria-pressed": void 0 }, i = a.type === "single" ? s : void 0;
    return /* @__PURE__ */ y.jsx(
      ut,
      {
        ...i,
        ...o,
        ref: t,
        onPressedChange: (c) => {
          c ? a.onItemActivate(r) : a.onItemDeactivate(r);
        }
      }
    );
  }
), Nt = lt, lo = vn;
function fo(e, t, n = "long") {
  return new Intl.DateTimeFormat("en-US", {
    // Enforces engine to render the time. Without the option JavaScriptCore omits it.
    hour: "numeric",
    timeZone: e,
    timeZoneName: n
  }).format(t).split(/\s/g).slice(2).join(" ");
}
const Qe = {}, Ne = {};
function be(e, t) {
  try {
    const r = (Qe[e] || (Qe[e] = new Intl.DateTimeFormat("en-US", {
      timeZone: e,
      timeZoneName: "longOffset"
    }).format))(t).split("GMT")[1];
    return r in Ne ? Ne[r] : Wt(r, r.split(":"));
  } catch {
    if (e in Ne) return Ne[e];
    const n = e == null ? void 0 : e.match(ho);
    return n ? Wt(e, n.slice(1)) : NaN;
  }
}
const ho = /([+-]\d\d):?(\d\d)?/;
function Wt(e, t) {
  const n = +(t[0] || 0), r = +(t[1] || 0), o = +(t[2] || 0) / 60;
  return Ne[e] = n * 60 + r > 0 ? n * 60 + r + o : n * 60 - r - o;
}
class ae extends Date {
  //#region static
  constructor(...t) {
    super(), t.length > 1 && typeof t[t.length - 1] == "string" && (this.timeZone = t.pop()), this.internal = /* @__PURE__ */ new Date(), isNaN(be(this.timeZone, this)) ? this.setTime(NaN) : t.length ? typeof t[0] == "number" && (t.length === 1 || t.length === 2 && typeof t[1] != "number") ? this.setTime(t[0]) : typeof t[0] == "string" ? this.setTime(+new Date(t[0])) : t[0] instanceof Date ? this.setTime(+t[0]) : (this.setTime(+new Date(...t)), kn(this), st(this)) : this.setTime(Date.now());
  }
  static tz(t, ...n) {
    return n.length ? new ae(...n, t) : new ae(Date.now(), t);
  }
  //#endregion
  //#region time zone
  withTimeZone(t) {
    return new ae(+this, t);
  }
  getTimezoneOffset() {
    const t = -be(this.timeZone, this);
    return t > 0 ? Math.floor(t) : Math.ceil(t);
  }
  //#endregion
  //#region time
  setTime(t) {
    return Date.prototype.setTime.apply(this, arguments), st(this), +this;
  }
  //#endregion
  //#region date-fns integration
  [Symbol.for("constructDateFrom")](t) {
    return new ae(+new Date(t), this.timeZone);
  }
  //#endregion
}
const Pt = /^(get|set)(?!UTC)/;
Object.getOwnPropertyNames(Date.prototype).forEach((e) => {
  if (!Pt.test(e)) return;
  const t = e.replace(Pt, "$1UTC");
  ae.prototype[t] && (e.startsWith("get") ? ae.prototype[e] = function() {
    return this.internal[t]();
  } : (ae.prototype[e] = function() {
    return Date.prototype[t].apply(this.internal, arguments), mo(this), +this;
  }, ae.prototype[t] = function() {
    return Date.prototype[t].apply(this, arguments), st(this), +this;
  }));
});
function st(e) {
  e.internal.setTime(+e), e.internal.setUTCSeconds(e.internal.getUTCSeconds() - Math.round(-be(e.timeZone, e) * 60));
}
function mo(e) {
  Date.prototype.setFullYear.call(e, e.internal.getUTCFullYear(), e.internal.getUTCMonth(), e.internal.getUTCDate()), Date.prototype.setHours.call(e, e.internal.getUTCHours(), e.internal.getUTCMinutes(), e.internal.getUTCSeconds(), e.internal.getUTCMilliseconds()), kn(e);
}
function kn(e) {
  const t = be(e.timeZone, e), n = t > 0 ? Math.floor(t) : Math.ceil(t), r = /* @__PURE__ */ new Date(+e);
  r.setUTCHours(r.getUTCHours() - 1);
  const o = -(/* @__PURE__ */ new Date(+e)).getTimezoneOffset(), a = -(/* @__PURE__ */ new Date(+r)).getTimezoneOffset(), s = o - a, i = Date.prototype.getHours.apply(e) !== e.internal.getUTCHours();
  s && i && e.internal.setUTCMinutes(e.internal.getUTCMinutes() + s);
  const c = o - n;
  c && Date.prototype.setUTCMinutes.call(e, Date.prototype.getUTCMinutes.call(e) + c);
  const u = /* @__PURE__ */ new Date(+e);
  u.setUTCSeconds(0);
  const d = o > 0 ? u.getSeconds() : (u.getSeconds() - 60) % 60, l = Math.round(-(be(e.timeZone, e) * 60)) % 60;
  (l || d) && (e.internal.setUTCSeconds(e.internal.getUTCSeconds() + l), Date.prototype.setUTCSeconds.call(e, Date.prototype.getUTCSeconds.call(e) + l + d));
  const h = be(e.timeZone, e), b = h > 0 ? Math.floor(h) : Math.ceil(h), p = -(/* @__PURE__ */ new Date(+e)).getTimezoneOffset() - b, v = b !== n, w = p - c;
  if (v && w) {
    Date.prototype.setUTCMinutes.call(e, Date.prototype.getUTCMinutes.call(e) + w);
    const D = be(e.timeZone, e), f = D > 0 ? Math.floor(D) : Math.ceil(D), k = b - f;
    k && (e.internal.setUTCMinutes(e.internal.getUTCMinutes() + k), Date.prototype.setUTCMinutes.call(e, Date.prototype.getUTCMinutes.call(e) + k));
  }
}
class Q extends ae {
  //#region static
  static tz(t, ...n) {
    return n.length ? new Q(...n, t) : new Q(Date.now(), t);
  }
  //#endregion
  //#region representation
  toISOString() {
    const [t, n, r] = this.tzComponents(), o = `${t}${n}:${r}`;
    return this.internal.toISOString().slice(0, -1) + o;
  }
  toString() {
    return `${this.toDateString()} ${this.toTimeString()}`;
  }
  toDateString() {
    const [t, n, r, o] = this.internal.toUTCString().split(" ");
    return `${t == null ? void 0 : t.slice(0, -1)} ${r} ${n} ${o}`;
  }
  toTimeString() {
    const t = this.internal.toUTCString().split(" ")[4], [n, r, o] = this.tzComponents();
    return `${t} GMT${n}${r}${o} (${fo(this.timeZone, this)})`;
  }
  toLocaleString(t, n) {
    return Date.prototype.toLocaleString.call(this, t, {
      ...n,
      timeZone: (n == null ? void 0 : n.timeZone) || this.timeZone
    });
  }
  toLocaleDateString(t, n) {
    return Date.prototype.toLocaleDateString.call(this, t, {
      ...n,
      timeZone: (n == null ? void 0 : n.timeZone) || this.timeZone
    });
  }
  toLocaleTimeString(t, n) {
    return Date.prototype.toLocaleTimeString.call(this, t, {
      ...n,
      timeZone: (n == null ? void 0 : n.timeZone) || this.timeZone
    });
  }
  //#endregion
  //#region private
  tzComponents() {
    const t = this.getTimezoneOffset(), n = t > 0 ? "-" : "+", r = String(Math.floor(Math.abs(t) / 60)).padStart(2, "0"), o = String(Math.abs(t) % 60).padStart(2, "0");
    return [n, r, o];
  }
  //#endregion
  withTimeZone(t) {
    return new Q(+this, t);
  }
  //#region date-fns integration
  [Symbol.for("constructDateFrom")](t) {
    return new Q(+new Date(t), this.timeZone);
  }
  //#endregion
}
const Mn = 6048e5, go = 864e5, Et = Symbol.for("constructDateFrom");
function U(e, t) {
  return typeof e == "function" ? e(t) : e && typeof e == "object" && Et in e ? e[Et](t) : e instanceof Date ? new e.constructor(t) : new Date(t);
}
function V(e, t) {
  return U(t || e, e);
}
function xn(e, t, n) {
  const r = V(e, n == null ? void 0 : n.in);
  return isNaN(t) ? U(e, NaN) : (t && r.setDate(r.getDate() + t), r);
}
function Dn(e, t, n) {
  const r = V(e, n == null ? void 0 : n.in);
  if (isNaN(t)) return U(e, NaN);
  if (!t)
    return r;
  const o = r.getDate(), a = U(e, r.getTime());
  a.setMonth(r.getMonth() + t + 1, 0);
  const s = a.getDate();
  return o >= s ? a : (r.setFullYear(
    a.getFullYear(),
    a.getMonth(),
    o
  ), r);
}
let yo = {};
function Te() {
  return yo;
}
function ke(e, t) {
  var i, c, u, d;
  const n = Te(), r = (t == null ? void 0 : t.weekStartsOn) ?? ((c = (i = t == null ? void 0 : t.locale) == null ? void 0 : i.options) == null ? void 0 : c.weekStartsOn) ?? n.weekStartsOn ?? ((d = (u = n.locale) == null ? void 0 : u.options) == null ? void 0 : d.weekStartsOn) ?? 0, o = V(e, t == null ? void 0 : t.in), a = o.getDay(), s = (a < r ? 7 : 0) + a - r;
  return o.setDate(o.getDate() - s), o.setHours(0, 0, 0, 0), o;
}
function Pe(e, t) {
  return ke(e, { ...t, weekStartsOn: 1 });
}
function Sn(e, t) {
  const n = V(e, t == null ? void 0 : t.in), r = n.getFullYear(), o = U(n, 0);
  o.setFullYear(r + 1, 0, 4), o.setHours(0, 0, 0, 0);
  const a = Pe(o), s = U(n, 0);
  s.setFullYear(r, 0, 4), s.setHours(0, 0, 0, 0);
  const i = Pe(s);
  return n.getTime() >= a.getTime() ? r + 1 : n.getTime() >= i.getTime() ? r : r - 1;
}
function _t(e) {
  const t = V(e), n = new Date(
    Date.UTC(
      t.getFullYear(),
      t.getMonth(),
      t.getDate(),
      t.getHours(),
      t.getMinutes(),
      t.getSeconds(),
      t.getMilliseconds()
    )
  );
  return n.setUTCFullYear(t.getFullYear()), +e - +n;
}
function xe(e, ...t) {
  const n = U.bind(
    null,
    t.find((r) => typeof r == "object")
  );
  return t.map(n);
}
function Ee(e, t) {
  const n = V(e, t == null ? void 0 : t.in);
  return n.setHours(0, 0, 0, 0), n;
}
function dt(e, t, n) {
  const [r, o] = xe(
    n == null ? void 0 : n.in,
    e,
    t
  ), a = Ee(r), s = Ee(o), i = +a - _t(a), c = +s - _t(s);
  return Math.round((i - c) / go);
}
function bo(e, t) {
  const n = Sn(e, t), r = U(e, 0);
  return r.setFullYear(n, 0, 4), r.setHours(0, 0, 0, 0), Pe(r);
}
function wo(e, t, n) {
  return xn(e, t * 7, n);
}
function po(e, t, n) {
  return Dn(e, t * 12, n);
}
function vo(e, t) {
  let n, r = t == null ? void 0 : t.in;
  return e.forEach((o) => {
    !r && typeof o == "object" && (r = U.bind(null, o));
    const a = V(o, r);
    (!n || n < a || isNaN(+a)) && (n = a);
  }), U(r, n || NaN);
}
function ko(e, t) {
  let n, r = t == null ? void 0 : t.in;
  return e.forEach((o) => {
    !r && typeof o == "object" && (r = U.bind(null, o));
    const a = V(o, r);
    (!n || n > a || isNaN(+a)) && (n = a);
  }), U(r, n || NaN);
}
function Mo(e, t, n) {
  const [r, o] = xe(
    n == null ? void 0 : n.in,
    e,
    t
  );
  return +Ee(r) == +Ee(o);
}
function On(e) {
  return e instanceof Date || typeof e == "object" && Object.prototype.toString.call(e) === "[object Date]";
}
function xo(e) {
  return !(!On(e) && typeof e != "number" || isNaN(+V(e)));
}
function Cn(e, t, n) {
  const [r, o] = xe(
    n == null ? void 0 : n.in,
    e,
    t
  ), a = r.getFullYear() - o.getFullYear(), s = r.getMonth() - o.getMonth();
  return a * 12 + s;
}
function Do(e, t) {
  const n = V(e, t == null ? void 0 : t.in), r = n.getMonth();
  return n.setFullYear(n.getFullYear(), r + 1, 0), n.setHours(23, 59, 59, 999), n;
}
function Nn(e, t) {
  const [n, r] = xe(e, t.start, t.end);
  return { start: n, end: r };
}
function So(e, t) {
  const { start: n, end: r } = Nn(t == null ? void 0 : t.in, e);
  let o = +n > +r;
  const a = o ? +n : +r, s = o ? r : n;
  s.setHours(0, 0, 0, 0), s.setDate(1);
  let i = 1;
  const c = [];
  for (; +s <= a; )
    c.push(U(n, s)), s.setMonth(s.getMonth() + i);
  return o ? c.reverse() : c;
}
function Oo(e, t) {
  const n = V(e, t == null ? void 0 : t.in);
  return n.setDate(1), n.setHours(0, 0, 0, 0), n;
}
function Co(e, t) {
  const n = V(e, t == null ? void 0 : t.in), r = n.getFullYear();
  return n.setFullYear(r + 1, 0, 0), n.setHours(23, 59, 59, 999), n;
}
function Wn(e, t) {
  const n = V(e, t == null ? void 0 : t.in);
  return n.setFullYear(n.getFullYear(), 0, 1), n.setHours(0, 0, 0, 0), n;
}
function No(e, t) {
  const { start: n, end: r } = Nn(t == null ? void 0 : t.in, e);
  let o = +n > +r;
  const a = o ? +n : +r, s = o ? r : n;
  s.setHours(0, 0, 0, 0), s.setMonth(0, 1);
  let i = 1;
  const c = [];
  for (; +s <= a; )
    c.push(U(n, s)), s.setFullYear(s.getFullYear() + i);
  return o ? c.reverse() : c;
}
function Pn(e, t) {
  var i, c, u, d;
  const n = Te(), r = (t == null ? void 0 : t.weekStartsOn) ?? ((c = (i = t == null ? void 0 : t.locale) == null ? void 0 : i.options) == null ? void 0 : c.weekStartsOn) ?? n.weekStartsOn ?? ((d = (u = n.locale) == null ? void 0 : u.options) == null ? void 0 : d.weekStartsOn) ?? 0, o = V(e, t == null ? void 0 : t.in), a = o.getDay(), s = (a < r ? -7 : 0) + 6 - (a - r);
  return o.setDate(o.getDate() + s), o.setHours(23, 59, 59, 999), o;
}
function Wo(e, t) {
  return Pn(e, { ...t, weekStartsOn: 1 });
}
const Po = {
  lessThanXSeconds: {
    one: "less than a second",
    other: "less than {{count}} seconds"
  },
  xSeconds: {
    one: "1 second",
    other: "{{count}} seconds"
  },
  halfAMinute: "half a minute",
  lessThanXMinutes: {
    one: "less than a minute",
    other: "less than {{count}} minutes"
  },
  xMinutes: {
    one: "1 minute",
    other: "{{count}} minutes"
  },
  aboutXHours: {
    one: "about 1 hour",
    other: "about {{count}} hours"
  },
  xHours: {
    one: "1 hour",
    other: "{{count}} hours"
  },
  xDays: {
    one: "1 day",
    other: "{{count}} days"
  },
  aboutXWeeks: {
    one: "about 1 week",
    other: "about {{count}} weeks"
  },
  xWeeks: {
    one: "1 week",
    other: "{{count}} weeks"
  },
  aboutXMonths: {
    one: "about 1 month",
    other: "about {{count}} months"
  },
  xMonths: {
    one: "1 month",
    other: "{{count}} months"
  },
  aboutXYears: {
    one: "about 1 year",
    other: "about {{count}} years"
  },
  xYears: {
    one: "1 year",
    other: "{{count}} years"
  },
  overXYears: {
    one: "over 1 year",
    other: "over {{count}} years"
  },
  almostXYears: {
    one: "almost 1 year",
    other: "almost {{count}} years"
  }
}, Eo = (e, t, n) => {
  let r;
  const o = Po[e];
  return typeof o == "string" ? r = o : t === 1 ? r = o.one : r = o.other.replace("{{count}}", t.toString()), n != null && n.addSuffix ? n.comparison && n.comparison > 0 ? "in " + r : r + " ago" : r;
};
function Je(e) {
  return (t = {}) => {
    const n = t.width ? String(t.width) : e.defaultWidth;
    return e.formats[n] || e.formats[e.defaultWidth];
  };
}
const _o = {
  full: "EEEE, MMMM do, y",
  long: "MMMM do, y",
  medium: "MMM d, y",
  short: "MM/dd/yyyy"
}, To = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a"
}, Yo = {
  full: "{{date}} 'at' {{time}}",
  long: "{{date}} 'at' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, jo = {
  date: Je({
    formats: _o,
    defaultWidth: "full"
  }),
  time: Je({
    formats: To,
    defaultWidth: "full"
  }),
  dateTime: Je({
    formats: Yo,
    defaultWidth: "full"
  })
}, Io = {
  lastWeek: "'last' eeee 'at' p",
  yesterday: "'yesterday at' p",
  today: "'today at' p",
  tomorrow: "'tomorrow at' p",
  nextWeek: "eeee 'at' p",
  other: "P"
}, Bo = (e, t, n, r) => Io[e];
function Oe(e) {
  return (t, n) => {
    const r = n != null && n.context ? String(n.context) : "standalone";
    let o;
    if (r === "formatting" && e.formattingValues) {
      const s = e.defaultFormattingWidth || e.defaultWidth, i = n != null && n.width ? String(n.width) : s;
      o = e.formattingValues[i] || e.formattingValues[s];
    } else {
      const s = e.defaultWidth, i = n != null && n.width ? String(n.width) : e.defaultWidth;
      o = e.values[i] || e.values[s];
    }
    const a = e.argumentCallback ? e.argumentCallback(t) : t;
    return o[a];
  };
}
const Fo = {
  narrow: ["B", "A"],
  abbreviated: ["BC", "AD"],
  wide: ["Before Christ", "Anno Domini"]
}, Ao = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["Q1", "Q2", "Q3", "Q4"],
  wide: ["1st quarter", "2nd quarter", "3rd quarter", "4th quarter"]
}, Ro = {
  narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
  abbreviated: [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ],
  wide: [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ]
}, Ho = {
  narrow: ["S", "M", "T", "W", "T", "F", "S"],
  short: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
  abbreviated: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
  wide: [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
  ]
}, Go = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "mi",
    noon: "n",
    morning: "morning",
    afternoon: "afternoon",
    evening: "evening",
    night: "night"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "midnight",
    noon: "noon",
    morning: "morning",
    afternoon: "afternoon",
    evening: "evening",
    night: "night"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "midnight",
    noon: "noon",
    morning: "morning",
    afternoon: "afternoon",
    evening: "evening",
    night: "night"
  }
}, zo = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "mi",
    noon: "n",
    morning: "in the morning",
    afternoon: "in the afternoon",
    evening: "in the evening",
    night: "at night"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "midnight",
    noon: "noon",
    morning: "in the morning",
    afternoon: "in the afternoon",
    evening: "in the evening",
    night: "at night"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "midnight",
    noon: "noon",
    morning: "in the morning",
    afternoon: "in the afternoon",
    evening: "in the evening",
    night: "at night"
  }
}, Vo = (e, t) => {
  const n = Number(e), r = n % 100;
  if (r > 20 || r < 10)
    switch (r % 10) {
      case 1:
        return n + "st";
      case 2:
        return n + "nd";
      case 3:
        return n + "rd";
    }
  return n + "th";
}, $o = {
  ordinalNumber: Vo,
  era: Oe({
    values: Fo,
    defaultWidth: "wide"
  }),
  quarter: Oe({
    values: Ao,
    defaultWidth: "wide",
    argumentCallback: (e) => e - 1
  }),
  month: Oe({
    values: Ro,
    defaultWidth: "wide"
  }),
  day: Oe({
    values: Ho,
    defaultWidth: "wide"
  }),
  dayPeriod: Oe({
    values: Go,
    defaultWidth: "wide",
    formattingValues: zo,
    defaultFormattingWidth: "wide"
  })
};
function Ce(e) {
  return (t, n = {}) => {
    const r = n.width, o = r && e.matchPatterns[r] || e.matchPatterns[e.defaultMatchWidth], a = t.match(o);
    if (!a)
      return null;
    const s = a[0], i = r && e.parsePatterns[r] || e.parsePatterns[e.defaultParseWidth], c = Array.isArray(i) ? Ko(i, (l) => l.test(s)) : (
      // [TODO] -- I challenge you to fix the type
      qo(i, (l) => l.test(s))
    );
    let u;
    u = e.valueCallback ? e.valueCallback(c) : c, u = n.valueCallback ? (
      // [TODO] -- I challenge you to fix the type
      n.valueCallback(u)
    ) : u;
    const d = t.slice(s.length);
    return { value: u, rest: d };
  };
}
function qo(e, t) {
  for (const n in e)
    if (Object.prototype.hasOwnProperty.call(e, n) && t(e[n]))
      return n;
}
function Ko(e, t) {
  for (let n = 0; n < e.length; n++)
    if (t(e[n]))
      return n;
}
function Uo(e) {
  return (t, n = {}) => {
    const r = t.match(e.matchPattern);
    if (!r) return null;
    const o = r[0], a = t.match(e.parsePattern);
    if (!a) return null;
    let s = e.valueCallback ? e.valueCallback(a[0]) : a[0];
    s = n.valueCallback ? n.valueCallback(s) : s;
    const i = t.slice(o.length);
    return { value: s, rest: i };
  };
}
const Xo = /^(\d+)(th|st|nd|rd)?/i, Qo = /\d+/i, Jo = {
  narrow: /^(b|a)/i,
  abbreviated: /^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,
  wide: /^(before christ|before common era|anno domini|common era)/i
}, Zo = {
  any: [/^b/i, /^(a|c)/i]
}, Lo = {
  narrow: /^[1234]/i,
  abbreviated: /^q[1234]/i,
  wide: /^[1234](th|st|nd|rd)? quarter/i
}, ea = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, ta = {
  narrow: /^[jfmasond]/i,
  abbreviated: /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,
  wide: /^(january|february|march|april|may|june|july|august|september|october|november|december)/i
}, na = {
  narrow: [
    /^j/i,
    /^f/i,
    /^m/i,
    /^a/i,
    /^m/i,
    /^j/i,
    /^j/i,
    /^a/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ],
  any: [
    /^ja/i,
    /^f/i,
    /^mar/i,
    /^ap/i,
    /^may/i,
    /^jun/i,
    /^jul/i,
    /^au/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ]
}, ra = {
  narrow: /^[smtwf]/i,
  short: /^(su|mo|tu|we|th|fr|sa)/i,
  abbreviated: /^(sun|mon|tue|wed|thu|fri|sat)/i,
  wide: /^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i
}, oa = {
  narrow: [/^s/i, /^m/i, /^t/i, /^w/i, /^t/i, /^f/i, /^s/i],
  any: [/^su/i, /^m/i, /^tu/i, /^w/i, /^th/i, /^f/i, /^sa/i]
}, aa = {
  narrow: /^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,
  any: /^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i
}, sa = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^mi/i,
    noon: /^no/i,
    morning: /morning/i,
    afternoon: /afternoon/i,
    evening: /evening/i,
    night: /night/i
  }
}, ia = {
  ordinalNumber: Uo({
    matchPattern: Xo,
    parsePattern: Qo,
    valueCallback: (e) => parseInt(e, 10)
  }),
  era: Ce({
    matchPatterns: Jo,
    defaultMatchWidth: "wide",
    parsePatterns: Zo,
    defaultParseWidth: "any"
  }),
  quarter: Ce({
    matchPatterns: Lo,
    defaultMatchWidth: "wide",
    parsePatterns: ea,
    defaultParseWidth: "any",
    valueCallback: (e) => e + 1
  }),
  month: Ce({
    matchPatterns: ta,
    defaultMatchWidth: "wide",
    parsePatterns: na,
    defaultParseWidth: "any"
  }),
  day: Ce({
    matchPatterns: ra,
    defaultMatchWidth: "wide",
    parsePatterns: oa,
    defaultParseWidth: "any"
  }),
  dayPeriod: Ce({
    matchPatterns: aa,
    defaultMatchWidth: "any",
    parsePatterns: sa,
    defaultParseWidth: "any"
  })
}, ve = {
  code: "en-US",
  formatDistance: Eo,
  formatLong: jo,
  formatRelative: Bo,
  localize: $o,
  match: ia,
  options: {
    weekStartsOn: 0,
    firstWeekContainsDate: 1
  }
};
function ca(e, t) {
  const n = V(e, t == null ? void 0 : t.in);
  return dt(n, Wn(n)) + 1;
}
function ft(e, t) {
  const n = V(e, t == null ? void 0 : t.in), r = +Pe(n) - +bo(n);
  return Math.round(r / Mn) + 1;
}
function En(e, t) {
  var d, l, h, b;
  const n = V(e, t == null ? void 0 : t.in), r = n.getFullYear(), o = Te(), a = (t == null ? void 0 : t.firstWeekContainsDate) ?? ((l = (d = t == null ? void 0 : t.locale) == null ? void 0 : d.options) == null ? void 0 : l.firstWeekContainsDate) ?? o.firstWeekContainsDate ?? ((b = (h = o.locale) == null ? void 0 : h.options) == null ? void 0 : b.firstWeekContainsDate) ?? 1, s = U((t == null ? void 0 : t.in) || e, 0);
  s.setFullYear(r + 1, 0, a), s.setHours(0, 0, 0, 0);
  const i = ke(s, t), c = U((t == null ? void 0 : t.in) || e, 0);
  c.setFullYear(r, 0, a), c.setHours(0, 0, 0, 0);
  const u = ke(c, t);
  return +n >= +i ? r + 1 : +n >= +u ? r : r - 1;
}
function ua(e, t) {
  var i, c, u, d;
  const n = Te(), r = (t == null ? void 0 : t.firstWeekContainsDate) ?? ((c = (i = t == null ? void 0 : t.locale) == null ? void 0 : i.options) == null ? void 0 : c.firstWeekContainsDate) ?? n.firstWeekContainsDate ?? ((d = (u = n.locale) == null ? void 0 : u.options) == null ? void 0 : d.firstWeekContainsDate) ?? 1, o = En(e, t), a = U((t == null ? void 0 : t.in) || e, 0);
  return a.setFullYear(o, 0, r), a.setHours(0, 0, 0, 0), ke(a, t);
}
function ht(e, t) {
  const n = V(e, t == null ? void 0 : t.in), r = +ke(n, t) - +ua(n, t);
  return Math.round(r / Mn) + 1;
}
function z(e, t) {
  const n = e < 0 ? "-" : "", r = Math.abs(e).toString().padStart(t, "0");
  return n + r;
}
const fe = {
  // Year
  y(e, t) {
    const n = e.getFullYear(), r = n > 0 ? n : 1 - n;
    return z(t === "yy" ? r % 100 : r, t.length);
  },
  // Month
  M(e, t) {
    const n = e.getMonth();
    return t === "M" ? String(n + 1) : z(n + 1, 2);
  },
  // Day of the month
  d(e, t) {
    return z(e.getDate(), t.length);
  },
  // AM or PM
  a(e, t) {
    const n = e.getHours() / 12 >= 1 ? "pm" : "am";
    switch (t) {
      case "a":
      case "aa":
        return n.toUpperCase();
      case "aaa":
        return n;
      case "aaaaa":
        return n[0];
      case "aaaa":
      default:
        return n === "am" ? "a.m." : "p.m.";
    }
  },
  // Hour [1-12]
  h(e, t) {
    return z(e.getHours() % 12 || 12, t.length);
  },
  // Hour [0-23]
  H(e, t) {
    return z(e.getHours(), t.length);
  },
  // Minute
  m(e, t) {
    return z(e.getMinutes(), t.length);
  },
  // Second
  s(e, t) {
    return z(e.getSeconds(), t.length);
  },
  // Fraction of second
  S(e, t) {
    const n = t.length, r = e.getMilliseconds(), o = Math.trunc(
      r * Math.pow(10, n - 3)
    );
    return z(o, t.length);
  }
}, we = {
  midnight: "midnight",
  noon: "noon",
  morning: "morning",
  afternoon: "afternoon",
  evening: "evening",
  night: "night"
}, Tt = {
  // Era
  G: function(e, t, n) {
    const r = e.getFullYear() > 0 ? 1 : 0;
    switch (t) {
      case "G":
      case "GG":
      case "GGG":
        return n.era(r, { width: "abbreviated" });
      case "GGGGG":
        return n.era(r, { width: "narrow" });
      case "GGGG":
      default:
        return n.era(r, { width: "wide" });
    }
  },
  // Year
  y: function(e, t, n) {
    if (t === "yo") {
      const r = e.getFullYear(), o = r > 0 ? r : 1 - r;
      return n.ordinalNumber(o, { unit: "year" });
    }
    return fe.y(e, t);
  },
  // Local week-numbering year
  Y: function(e, t, n, r) {
    const o = En(e, r), a = o > 0 ? o : 1 - o;
    if (t === "YY") {
      const s = a % 100;
      return z(s, 2);
    }
    return t === "Yo" ? n.ordinalNumber(a, { unit: "year" }) : z(a, t.length);
  },
  // ISO week-numbering year
  R: function(e, t) {
    const n = Sn(e);
    return z(n, t.length);
  },
  // Extended year. This is a single number designating the year of this calendar system.
  // The main difference between `y` and `u` localizers are B.C. years:
  // | Year | `y` | `u` |
  // |------|-----|-----|
  // | AC 1 |   1 |   1 |
  // | BC 1 |   1 |   0 |
  // | BC 2 |   2 |  -1 |
  // Also `yy` always returns the last two digits of a year,
  // while `uu` pads single digit years to 2 characters and returns other years unchanged.
  u: function(e, t) {
    const n = e.getFullYear();
    return z(n, t.length);
  },
  // Quarter
  Q: function(e, t, n) {
    const r = Math.ceil((e.getMonth() + 1) / 3);
    switch (t) {
      case "Q":
        return String(r);
      case "QQ":
        return z(r, 2);
      case "Qo":
        return n.ordinalNumber(r, { unit: "quarter" });
      case "QQQ":
        return n.quarter(r, {
          width: "abbreviated",
          context: "formatting"
        });
      case "QQQQQ":
        return n.quarter(r, {
          width: "narrow",
          context: "formatting"
        });
      case "QQQQ":
      default:
        return n.quarter(r, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // Stand-alone quarter
  q: function(e, t, n) {
    const r = Math.ceil((e.getMonth() + 1) / 3);
    switch (t) {
      case "q":
        return String(r);
      case "qq":
        return z(r, 2);
      case "qo":
        return n.ordinalNumber(r, { unit: "quarter" });
      case "qqq":
        return n.quarter(r, {
          width: "abbreviated",
          context: "standalone"
        });
      case "qqqqq":
        return n.quarter(r, {
          width: "narrow",
          context: "standalone"
        });
      case "qqqq":
      default:
        return n.quarter(r, {
          width: "wide",
          context: "standalone"
        });
    }
  },
  // Month
  M: function(e, t, n) {
    const r = e.getMonth();
    switch (t) {
      case "M":
      case "MM":
        return fe.M(e, t);
      case "Mo":
        return n.ordinalNumber(r + 1, { unit: "month" });
      case "MMM":
        return n.month(r, {
          width: "abbreviated",
          context: "formatting"
        });
      case "MMMMM":
        return n.month(r, {
          width: "narrow",
          context: "formatting"
        });
      case "MMMM":
      default:
        return n.month(r, { width: "wide", context: "formatting" });
    }
  },
  // Stand-alone month
  L: function(e, t, n) {
    const r = e.getMonth();
    switch (t) {
      case "L":
        return String(r + 1);
      case "LL":
        return z(r + 1, 2);
      case "Lo":
        return n.ordinalNumber(r + 1, { unit: "month" });
      case "LLL":
        return n.month(r, {
          width: "abbreviated",
          context: "standalone"
        });
      case "LLLLL":
        return n.month(r, {
          width: "narrow",
          context: "standalone"
        });
      case "LLLL":
      default:
        return n.month(r, { width: "wide", context: "standalone" });
    }
  },
  // Local week of year
  w: function(e, t, n, r) {
    const o = ht(e, r);
    return t === "wo" ? n.ordinalNumber(o, { unit: "week" }) : z(o, t.length);
  },
  // ISO week of year
  I: function(e, t, n) {
    const r = ft(e);
    return t === "Io" ? n.ordinalNumber(r, { unit: "week" }) : z(r, t.length);
  },
  // Day of the month
  d: function(e, t, n) {
    return t === "do" ? n.ordinalNumber(e.getDate(), { unit: "date" }) : fe.d(e, t);
  },
  // Day of year
  D: function(e, t, n) {
    const r = ca(e);
    return t === "Do" ? n.ordinalNumber(r, { unit: "dayOfYear" }) : z(r, t.length);
  },
  // Day of week
  E: function(e, t, n) {
    const r = e.getDay();
    switch (t) {
      case "E":
      case "EE":
      case "EEE":
        return n.day(r, {
          width: "abbreviated",
          context: "formatting"
        });
      case "EEEEE":
        return n.day(r, {
          width: "narrow",
          context: "formatting"
        });
      case "EEEEEE":
        return n.day(r, {
          width: "short",
          context: "formatting"
        });
      case "EEEE":
      default:
        return n.day(r, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // Local day of week
  e: function(e, t, n, r) {
    const o = e.getDay(), a = (o - r.weekStartsOn + 8) % 7 || 7;
    switch (t) {
      case "e":
        return String(a);
      case "ee":
        return z(a, 2);
      case "eo":
        return n.ordinalNumber(a, { unit: "day" });
      case "eee":
        return n.day(o, {
          width: "abbreviated",
          context: "formatting"
        });
      case "eeeee":
        return n.day(o, {
          width: "narrow",
          context: "formatting"
        });
      case "eeeeee":
        return n.day(o, {
          width: "short",
          context: "formatting"
        });
      case "eeee":
      default:
        return n.day(o, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // Stand-alone local day of week
  c: function(e, t, n, r) {
    const o = e.getDay(), a = (o - r.weekStartsOn + 8) % 7 || 7;
    switch (t) {
      case "c":
        return String(a);
      case "cc":
        return z(a, t.length);
      case "co":
        return n.ordinalNumber(a, { unit: "day" });
      case "ccc":
        return n.day(o, {
          width: "abbreviated",
          context: "standalone"
        });
      case "ccccc":
        return n.day(o, {
          width: "narrow",
          context: "standalone"
        });
      case "cccccc":
        return n.day(o, {
          width: "short",
          context: "standalone"
        });
      case "cccc":
      default:
        return n.day(o, {
          width: "wide",
          context: "standalone"
        });
    }
  },
  // ISO day of week
  i: function(e, t, n) {
    const r = e.getDay(), o = r === 0 ? 7 : r;
    switch (t) {
      case "i":
        return String(o);
      case "ii":
        return z(o, t.length);
      case "io":
        return n.ordinalNumber(o, { unit: "day" });
      case "iii":
        return n.day(r, {
          width: "abbreviated",
          context: "formatting"
        });
      case "iiiii":
        return n.day(r, {
          width: "narrow",
          context: "formatting"
        });
      case "iiiiii":
        return n.day(r, {
          width: "short",
          context: "formatting"
        });
      case "iiii":
      default:
        return n.day(r, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // AM or PM
  a: function(e, t, n) {
    const o = e.getHours() / 12 >= 1 ? "pm" : "am";
    switch (t) {
      case "a":
      case "aa":
        return n.dayPeriod(o, {
          width: "abbreviated",
          context: "formatting"
        });
      case "aaa":
        return n.dayPeriod(o, {
          width: "abbreviated",
          context: "formatting"
        }).toLowerCase();
      case "aaaaa":
        return n.dayPeriod(o, {
          width: "narrow",
          context: "formatting"
        });
      case "aaaa":
      default:
        return n.dayPeriod(o, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // AM, PM, midnight, noon
  b: function(e, t, n) {
    const r = e.getHours();
    let o;
    switch (r === 12 ? o = we.noon : r === 0 ? o = we.midnight : o = r / 12 >= 1 ? "pm" : "am", t) {
      case "b":
      case "bb":
        return n.dayPeriod(o, {
          width: "abbreviated",
          context: "formatting"
        });
      case "bbb":
        return n.dayPeriod(o, {
          width: "abbreviated",
          context: "formatting"
        }).toLowerCase();
      case "bbbbb":
        return n.dayPeriod(o, {
          width: "narrow",
          context: "formatting"
        });
      case "bbbb":
      default:
        return n.dayPeriod(o, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // in the morning, in the afternoon, in the evening, at night
  B: function(e, t, n) {
    const r = e.getHours();
    let o;
    switch (r >= 17 ? o = we.evening : r >= 12 ? o = we.afternoon : r >= 4 ? o = we.morning : o = we.night, t) {
      case "B":
      case "BB":
      case "BBB":
        return n.dayPeriod(o, {
          width: "abbreviated",
          context: "formatting"
        });
      case "BBBBB":
        return n.dayPeriod(o, {
          width: "narrow",
          context: "formatting"
        });
      case "BBBB":
      default:
        return n.dayPeriod(o, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // Hour [1-12]
  h: function(e, t, n) {
    if (t === "ho") {
      let r = e.getHours() % 12;
      return r === 0 && (r = 12), n.ordinalNumber(r, { unit: "hour" });
    }
    return fe.h(e, t);
  },
  // Hour [0-23]
  H: function(e, t, n) {
    return t === "Ho" ? n.ordinalNumber(e.getHours(), { unit: "hour" }) : fe.H(e, t);
  },
  // Hour [0-11]
  K: function(e, t, n) {
    const r = e.getHours() % 12;
    return t === "Ko" ? n.ordinalNumber(r, { unit: "hour" }) : z(r, t.length);
  },
  // Hour [1-24]
  k: function(e, t, n) {
    let r = e.getHours();
    return r === 0 && (r = 24), t === "ko" ? n.ordinalNumber(r, { unit: "hour" }) : z(r, t.length);
  },
  // Minute
  m: function(e, t, n) {
    return t === "mo" ? n.ordinalNumber(e.getMinutes(), { unit: "minute" }) : fe.m(e, t);
  },
  // Second
  s: function(e, t, n) {
    return t === "so" ? n.ordinalNumber(e.getSeconds(), { unit: "second" }) : fe.s(e, t);
  },
  // Fraction of second
  S: function(e, t) {
    return fe.S(e, t);
  },
  // Timezone (ISO-8601. If offset is 0, output is always `'Z'`)
  X: function(e, t, n) {
    const r = e.getTimezoneOffset();
    if (r === 0)
      return "Z";
    switch (t) {
      case "X":
        return jt(r);
      case "XXXX":
      case "XX":
        return ye(r);
      case "XXXXX":
      case "XXX":
      default:
        return ye(r, ":");
    }
  },
  // Timezone (ISO-8601. If offset is 0, output is `'+00:00'` or equivalent)
  x: function(e, t, n) {
    const r = e.getTimezoneOffset();
    switch (t) {
      case "x":
        return jt(r);
      case "xxxx":
      case "xx":
        return ye(r);
      case "xxxxx":
      case "xxx":
      default:
        return ye(r, ":");
    }
  },
  // Timezone (GMT)
  O: function(e, t, n) {
    const r = e.getTimezoneOffset();
    switch (t) {
      case "O":
      case "OO":
      case "OOO":
        return "GMT" + Yt(r, ":");
      case "OOOO":
      default:
        return "GMT" + ye(r, ":");
    }
  },
  // Timezone (specific non-location)
  z: function(e, t, n) {
    const r = e.getTimezoneOffset();
    switch (t) {
      case "z":
      case "zz":
      case "zzz":
        return "GMT" + Yt(r, ":");
      case "zzzz":
      default:
        return "GMT" + ye(r, ":");
    }
  },
  // Seconds timestamp
  t: function(e, t, n) {
    const r = Math.trunc(+e / 1e3);
    return z(r, t.length);
  },
  // Milliseconds timestamp
  T: function(e, t, n) {
    return z(+e, t.length);
  }
};
function Yt(e, t = "") {
  const n = e > 0 ? "-" : "+", r = Math.abs(e), o = Math.trunc(r / 60), a = r % 60;
  return a === 0 ? n + String(o) : n + String(o) + t + z(a, 2);
}
function jt(e, t) {
  return e % 60 === 0 ? (e > 0 ? "-" : "+") + z(Math.abs(e) / 60, 2) : ye(e, t);
}
function ye(e, t = "") {
  const n = e > 0 ? "-" : "+", r = Math.abs(e), o = z(Math.trunc(r / 60), 2), a = z(r % 60, 2);
  return n + o + t + a;
}
const It = (e, t) => {
  switch (e) {
    case "P":
      return t.date({ width: "short" });
    case "PP":
      return t.date({ width: "medium" });
    case "PPP":
      return t.date({ width: "long" });
    case "PPPP":
    default:
      return t.date({ width: "full" });
  }
}, _n = (e, t) => {
  switch (e) {
    case "p":
      return t.time({ width: "short" });
    case "pp":
      return t.time({ width: "medium" });
    case "ppp":
      return t.time({ width: "long" });
    case "pppp":
    default:
      return t.time({ width: "full" });
  }
}, la = (e, t) => {
  const n = e.match(/(P+)(p+)?/) || [], r = n[1], o = n[2];
  if (!o)
    return It(e, t);
  let a;
  switch (r) {
    case "P":
      a = t.dateTime({ width: "short" });
      break;
    case "PP":
      a = t.dateTime({ width: "medium" });
      break;
    case "PPP":
      a = t.dateTime({ width: "long" });
      break;
    case "PPPP":
    default:
      a = t.dateTime({ width: "full" });
      break;
  }
  return a.replace("{{date}}", It(r, t)).replace("{{time}}", _n(o, t));
}, da = {
  p: _n,
  P: la
}, fa = /^D+$/, ha = /^Y+$/, ma = ["D", "DD", "YY", "YYYY"];
function ga(e) {
  return fa.test(e);
}
function ya(e) {
  return ha.test(e);
}
function ba(e, t, n) {
  const r = wa(e, t, n);
  if (console.warn(r), ma.includes(e)) throw new RangeError(r);
}
function wa(e, t, n) {
  const r = e[0] === "Y" ? "years" : "days of the month";
  return `Use \`${e.toLowerCase()}\` instead of \`${e}\` (in \`${t}\`) for formatting ${r} to the input \`${n}\`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md`;
}
const pa = /[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g, va = /P+p+|P+|p+|''|'(''|[^'])+('|$)|./g, ka = /^'([^]*?)'?$/, Ma = /''/g, xa = /[a-zA-Z]/;
function We(e, t, n) {
  var d, l, h, b, M, p, v, w;
  const r = Te(), o = (n == null ? void 0 : n.locale) ?? r.locale ?? ve, a = (n == null ? void 0 : n.firstWeekContainsDate) ?? ((l = (d = n == null ? void 0 : n.locale) == null ? void 0 : d.options) == null ? void 0 : l.firstWeekContainsDate) ?? r.firstWeekContainsDate ?? ((b = (h = r.locale) == null ? void 0 : h.options) == null ? void 0 : b.firstWeekContainsDate) ?? 1, s = (n == null ? void 0 : n.weekStartsOn) ?? ((p = (M = n == null ? void 0 : n.locale) == null ? void 0 : M.options) == null ? void 0 : p.weekStartsOn) ?? r.weekStartsOn ?? ((w = (v = r.locale) == null ? void 0 : v.options) == null ? void 0 : w.weekStartsOn) ?? 0, i = V(e, n == null ? void 0 : n.in);
  if (!xo(i))
    throw new RangeError("Invalid time value");
  let c = t.match(va).map((D) => {
    const f = D[0];
    if (f === "p" || f === "P") {
      const k = da[f];
      return k(D, o.formatLong);
    }
    return D;
  }).join("").match(pa).map((D) => {
    if (D === "''")
      return { isToken: !1, value: "'" };
    const f = D[0];
    if (f === "'")
      return { isToken: !1, value: Da(D) };
    if (Tt[f])
      return { isToken: !0, value: D };
    if (f.match(xa))
      throw new RangeError(
        "Format string contains an unescaped latin alphabet character `" + f + "`"
      );
    return { isToken: !1, value: D };
  });
  o.localize.preprocessor && (c = o.localize.preprocessor(i, c));
  const u = {
    firstWeekContainsDate: a,
    weekStartsOn: s,
    locale: o
  };
  return c.map((D) => {
    if (!D.isToken) return D.value;
    const f = D.value;
    (!(n != null && n.useAdditionalWeekYearTokens) && ya(f) || !(n != null && n.useAdditionalDayOfYearTokens) && ga(f)) && ba(f, t, String(e));
    const k = Tt[f[0]];
    return k(i, f, o.localize, u);
  }).join("");
}
function Da(e) {
  const t = e.match(ka);
  return t ? t[1].replace(Ma, "'") : e;
}
function Sa(e, t) {
  const n = V(e, t == null ? void 0 : t.in), r = n.getFullYear(), o = n.getMonth(), a = U(n, 0);
  return a.setFullYear(r, o + 1, 0), a.setHours(0, 0, 0, 0), a.getDate();
}
function Oa(e, t) {
  return V(e, t == null ? void 0 : t.in).getMonth();
}
function Ca(e, t) {
  return V(e, t == null ? void 0 : t.in).getFullYear();
}
function Na(e, t) {
  return +V(e) > +V(t);
}
function Wa(e, t) {
  return +V(e) < +V(t);
}
function Pa(e, t, n) {
  const [r, o] = xe(
    n == null ? void 0 : n.in,
    e,
    t
  );
  return r.getFullYear() === o.getFullYear() && r.getMonth() === o.getMonth();
}
function Ea(e, t, n) {
  const [r, o] = xe(
    n == null ? void 0 : n.in,
    e,
    t
  );
  return r.getFullYear() === o.getFullYear();
}
function _a(e, t, n) {
  const r = V(e, n == null ? void 0 : n.in), o = r.getFullYear(), a = r.getDate(), s = U(e, 0);
  s.setFullYear(o, t, 15), s.setHours(0, 0, 0, 0);
  const i = Sa(s);
  return r.setMonth(t, Math.min(a, i)), r;
}
function Ta(e, t, n) {
  const r = V(e, n == null ? void 0 : n.in);
  return isNaN(+r) ? U(e, NaN) : (r.setFullYear(t), r);
}
const Bt = 5, Ya = 4;
function ja(e, t) {
  const n = t.startOfMonth(e), r = n.getDay() > 0 ? n.getDay() : 7, o = t.addDays(e, -r + 1), a = t.addDays(o, Bt * 7 - 1);
  return t.getMonth(e) === t.getMonth(a) ? Bt : Ya;
}
function Tn(e, t) {
  const n = t.startOfMonth(e), r = n.getDay();
  return r === 1 ? n : r === 0 ? t.addDays(n, -1 * 6) : t.addDays(n, -1 * (r - 1));
}
function Ia(e, t) {
  const n = Tn(e, t), r = ja(e, t);
  return t.addDays(n, r * 7 - 1);
}
const Yn = {
  ...ve,
  labels: {
    labelDayButton: (e, t, n, r) => {
      let o;
      r && typeof r.format == "function" ? o = r.format.bind(r) : o = (s, i) => We(s, i, { locale: ve, ...n });
      let a = o(e, "PPPP");
      return t.today && (a = `Today, ${a}`), t.selected && (a = `${a}, selected`), a;
    },
    labelMonthDropdown: "Choose the Month",
    labelNext: "Go to the Next Month",
    labelPrevious: "Go to the Previous Month",
    labelWeekNumber: (e) => `Week ${e}`,
    labelYearDropdown: "Choose the Year",
    labelGrid: (e, t, n) => {
      let r;
      return n && typeof n.format == "function" ? r = n.format.bind(n) : r = (o, a) => We(o, a, { locale: ve, ...t }), r(e, "LLLL yyyy");
    },
    labelGridcell: (e, t, n, r) => {
      let o;
      r && typeof r.format == "function" ? o = r.format.bind(r) : o = (s, i) => We(s, i, { locale: ve, ...n });
      let a = o(e, "PPPP");
      return t != null && t.today && (a = `Today, ${a}`), a;
    },
    labelNav: "Navigation bar",
    labelWeekNumberHeader: "Week Number",
    labelWeekday: (e, t, n) => {
      let r;
      return n && typeof n.format == "function" ? r = n.format.bind(n) : r = (o, a) => We(o, a, { locale: ve, ...t }), r(e, "cccc");
    }
  }
};
class L {
  /**
   * Creates an instance of `DateLib`.
   *
   * @param options Configuration options for the date library.
   * @param overrides Custom overrides for the date library functions.
   */
  constructor(t, n) {
    this.Date = Date, this.today = () => {
      var r;
      return (r = this.overrides) != null && r.today ? this.overrides.today() : this.options.timeZone ? Q.tz(this.options.timeZone) : new this.Date();
    }, this.newDate = (r, o, a) => {
      var s;
      return (s = this.overrides) != null && s.newDate ? this.overrides.newDate(r, o, a) : this.options.timeZone ? new Q(r, o, a, this.options.timeZone) : new Date(r, o, a);
    }, this.addDays = (r, o) => {
      var a;
      return (a = this.overrides) != null && a.addDays ? this.overrides.addDays(r, o) : xn(r, o);
    }, this.addMonths = (r, o) => {
      var a;
      return (a = this.overrides) != null && a.addMonths ? this.overrides.addMonths(r, o) : Dn(r, o);
    }, this.addWeeks = (r, o) => {
      var a;
      return (a = this.overrides) != null && a.addWeeks ? this.overrides.addWeeks(r, o) : wo(r, o);
    }, this.addYears = (r, o) => {
      var a;
      return (a = this.overrides) != null && a.addYears ? this.overrides.addYears(r, o) : po(r, o);
    }, this.differenceInCalendarDays = (r, o) => {
      var a;
      return (a = this.overrides) != null && a.differenceInCalendarDays ? this.overrides.differenceInCalendarDays(r, o) : dt(r, o);
    }, this.differenceInCalendarMonths = (r, o) => {
      var a;
      return (a = this.overrides) != null && a.differenceInCalendarMonths ? this.overrides.differenceInCalendarMonths(r, o) : Cn(r, o);
    }, this.eachMonthOfInterval = (r) => {
      var o;
      return (o = this.overrides) != null && o.eachMonthOfInterval ? this.overrides.eachMonthOfInterval(r) : So(r);
    }, this.eachYearOfInterval = (r) => {
      var i;
      const o = (i = this.overrides) != null && i.eachYearOfInterval ? this.overrides.eachYearOfInterval(r) : No(r), a = new Set(o.map((c) => this.getYear(c)));
      if (a.size === o.length)
        return o;
      const s = [];
      return a.forEach((c) => {
        s.push(new Date(c, 0, 1));
      }), s;
    }, this.endOfBroadcastWeek = (r) => {
      var o;
      return (o = this.overrides) != null && o.endOfBroadcastWeek ? this.overrides.endOfBroadcastWeek(r) : Ia(r, this);
    }, this.endOfISOWeek = (r) => {
      var o;
      return (o = this.overrides) != null && o.endOfISOWeek ? this.overrides.endOfISOWeek(r) : Wo(r);
    }, this.endOfMonth = (r) => {
      var o;
      return (o = this.overrides) != null && o.endOfMonth ? this.overrides.endOfMonth(r) : Do(r);
    }, this.endOfWeek = (r, o) => {
      var a;
      return (a = this.overrides) != null && a.endOfWeek ? this.overrides.endOfWeek(r, o) : Pn(r, this.options);
    }, this.endOfYear = (r) => {
      var o;
      return (o = this.overrides) != null && o.endOfYear ? this.overrides.endOfYear(r) : Co(r);
    }, this.format = (r, o, a) => {
      var i;
      const s = (i = this.overrides) != null && i.format ? this.overrides.format(r, o, this.options) : We(r, o, this.options);
      return this.options.numerals && this.options.numerals !== "latn" ? this.replaceDigits(s) : s;
    }, this.getISOWeek = (r) => {
      var o;
      return (o = this.overrides) != null && o.getISOWeek ? this.overrides.getISOWeek(r) : ft(r);
    }, this.getMonth = (r, o) => {
      var a;
      return (a = this.overrides) != null && a.getMonth ? this.overrides.getMonth(r, this.options) : Oa(r, this.options);
    }, this.getYear = (r, o) => {
      var a;
      return (a = this.overrides) != null && a.getYear ? this.overrides.getYear(r, this.options) : Ca(r, this.options);
    }, this.getWeek = (r, o) => {
      var a;
      return (a = this.overrides) != null && a.getWeek ? this.overrides.getWeek(r, this.options) : ht(r, this.options);
    }, this.isAfter = (r, o) => {
      var a;
      return (a = this.overrides) != null && a.isAfter ? this.overrides.isAfter(r, o) : Na(r, o);
    }, this.isBefore = (r, o) => {
      var a;
      return (a = this.overrides) != null && a.isBefore ? this.overrides.isBefore(r, o) : Wa(r, o);
    }, this.isDate = (r) => {
      var o;
      return (o = this.overrides) != null && o.isDate ? this.overrides.isDate(r) : On(r);
    }, this.isSameDay = (r, o) => {
      var a;
      return (a = this.overrides) != null && a.isSameDay ? this.overrides.isSameDay(r, o) : Mo(r, o);
    }, this.isSameMonth = (r, o) => {
      var a;
      return (a = this.overrides) != null && a.isSameMonth ? this.overrides.isSameMonth(r, o) : Pa(r, o);
    }, this.isSameYear = (r, o) => {
      var a;
      return (a = this.overrides) != null && a.isSameYear ? this.overrides.isSameYear(r, o) : Ea(r, o);
    }, this.max = (r) => {
      var o;
      return (o = this.overrides) != null && o.max ? this.overrides.max(r) : vo(r);
    }, this.min = (r) => {
      var o;
      return (o = this.overrides) != null && o.min ? this.overrides.min(r) : ko(r);
    }, this.setMonth = (r, o) => {
      var a;
      return (a = this.overrides) != null && a.setMonth ? this.overrides.setMonth(r, o) : _a(r, o);
    }, this.setYear = (r, o) => {
      var a;
      return (a = this.overrides) != null && a.setYear ? this.overrides.setYear(r, o) : Ta(r, o);
    }, this.startOfBroadcastWeek = (r, o) => {
      var a;
      return (a = this.overrides) != null && a.startOfBroadcastWeek ? this.overrides.startOfBroadcastWeek(r, this) : Tn(r, this);
    }, this.startOfDay = (r) => {
      var o;
      return (o = this.overrides) != null && o.startOfDay ? this.overrides.startOfDay(r) : Ee(r);
    }, this.startOfISOWeek = (r) => {
      var o;
      return (o = this.overrides) != null && o.startOfISOWeek ? this.overrides.startOfISOWeek(r) : Pe(r);
    }, this.startOfMonth = (r) => {
      var o;
      return (o = this.overrides) != null && o.startOfMonth ? this.overrides.startOfMonth(r) : Oo(r);
    }, this.startOfWeek = (r, o) => {
      var a;
      return (a = this.overrides) != null && a.startOfWeek ? this.overrides.startOfWeek(r, this.options) : ke(r, this.options);
    }, this.startOfYear = (r) => {
      var o;
      return (o = this.overrides) != null && o.startOfYear ? this.overrides.startOfYear(r) : Wn(r);
    }, this.options = { locale: Yn, ...t }, this.overrides = n;
  }
  /**
   * Generates a mapping of Arabic digits (0-9) to the target numbering system
   * digits.
   *
   * @since 9.5.0
   * @returns A record mapping Arabic digits to the target numerals.
   */
  getDigitMap() {
    const { numerals: t = "latn" } = this.options, n = new Intl.NumberFormat("en-US", {
      numberingSystem: t
    }), r = {};
    for (let o = 0; o < 10; o++)
      r[o.toString()] = n.format(o);
    return r;
  }
  /**
   * Replaces Arabic digits in a string with the target numbering system digits.
   *
   * @since 9.5.0
   * @param input The string containing Arabic digits.
   * @returns The string with digits replaced.
   */
  replaceDigits(t) {
    const n = this.getDigitMap();
    return t.replace(/\d/g, (r) => n[r] || r);
  }
  /**
   * Formats a number using the configured numbering system.
   *
   * @since 9.5.0
   * @param value The number to format.
   * @returns The formatted number as a string.
   */
  formatNumber(t) {
    return this.replaceDigits(t.toString());
  }
  /**
   * Returns the preferred ordering for month and year labels for the current
   * locale.
   */
  getMonthYearOrder() {
    var n;
    const t = (n = this.options.locale) == null ? void 0 : n.code;
    return t && L.yearFirstLocales.has(t) ? "year-first" : "month-first";
  }
  /**
   * Formats the month/year pair respecting locale conventions.
   *
   * @since 9.11.0
   */
  formatMonthYear(t) {
    const { locale: n, timeZone: r, numerals: o } = this.options, a = n == null ? void 0 : n.code;
    if (a && L.yearFirstLocales.has(a))
      try {
        return new Intl.DateTimeFormat(a, {
          month: "long",
          year: "numeric",
          timeZone: r,
          numberingSystem: o
        }).format(t);
      } catch {
      }
    const s = this.getMonthYearOrder() === "year-first" ? "y LLLL" : "LLLL y";
    return this.format(t, s);
  }
}
L.yearFirstLocales = /* @__PURE__ */ new Set([
  "eu",
  "hu",
  "ja",
  "ja-Hira",
  "ja-JP",
  "ko",
  "ko-KR",
  "lt",
  "lt-LT",
  "lv",
  "lv-LV",
  "mn",
  "mn-MN",
  "zh",
  "zh-CN",
  "zh-HK",
  "zh-TW"
]);
const ie = new L();
class jn {
  constructor(t, n, r = ie) {
    this.date = t, this.displayMonth = n, this.outside = !!(n && !r.isSameMonth(t, n)), this.dateLib = r, this.isoDate = r.format(t, "yyyy-MM-dd"), this.displayMonthId = r.format(n, "yyyy-MM"), this.dateMonthId = r.format(t, "yyyy-MM");
  }
  /**
   * Checks if this day is equal to another `CalendarDay`, considering both the
   * date and the displayed month.
   *
   * @param day The `CalendarDay` to compare with.
   * @returns `true` if the days are equal, otherwise `false`.
   */
  isEqualTo(t) {
    return this.dateLib.isSameDay(t.date, this.date) && this.dateLib.isSameMonth(t.displayMonth, this.displayMonth);
  }
}
class Ba {
  constructor(t, n) {
    this.date = t, this.weeks = n;
  }
}
class Fa {
  constructor(t, n) {
    this.days = n, this.weekNumber = t;
  }
}
function Aa(e) {
  return g.createElement("button", { ...e });
}
function Ra(e) {
  return g.createElement("span", { ...e });
}
function Ha(e) {
  const { size: t = 24, orientation: n = "left", className: r } = e;
  return (
    // biome-ignore lint/a11y/noSvgWithoutTitle: handled by the parent component
    g.createElement(
      "svg",
      { className: r, width: t, height: t, viewBox: "0 0 24 24" },
      n === "up" && g.createElement("polygon", { points: "6.77 17 12.5 11.43 18.24 17 20 15.28 12.5 8 5 15.28" }),
      n === "down" && g.createElement("polygon", { points: "6.77 8 12.5 13.57 18.24 8 20 9.72 12.5 17 5 9.72" }),
      n === "left" && g.createElement("polygon", { points: "16 18.112 9.81111111 12 16 5.87733333 14.0888889 4 6 12 14.0888889 20" }),
      n === "right" && g.createElement("polygon", { points: "8 18.112 14.18888889 12 8 5.87733333 9.91111111 4 18 12 9.91111111 20" })
    )
  );
}
function Ga(e) {
  const { day: t, modifiers: n, ...r } = e;
  return g.createElement("td", { ...r });
}
function za(e) {
  const { day: t, modifiers: n, ...r } = e, o = g.useRef(null);
  return g.useEffect(() => {
    var a;
    n.focused && ((a = o.current) == null || a.focus());
  }, [n.focused]), g.createElement("button", { ref: o, ...r });
}
var N;
(function(e) {
  e.Root = "root", e.Chevron = "chevron", e.Day = "day", e.DayButton = "day_button", e.CaptionLabel = "caption_label", e.Dropdowns = "dropdowns", e.Dropdown = "dropdown", e.DropdownRoot = "dropdown_root", e.Footer = "footer", e.MonthGrid = "month_grid", e.MonthCaption = "month_caption", e.MonthsDropdown = "months_dropdown", e.Month = "month", e.Months = "months", e.Nav = "nav", e.NextMonthButton = "button_next", e.PreviousMonthButton = "button_previous", e.Week = "week", e.Weeks = "weeks", e.Weekday = "weekday", e.Weekdays = "weekdays", e.WeekNumber = "week_number", e.WeekNumberHeader = "week_number_header", e.YearsDropdown = "years_dropdown";
})(N || (N = {}));
var q;
(function(e) {
  e.disabled = "disabled", e.hidden = "hidden", e.outside = "outside", e.focused = "focused", e.today = "today";
})(q || (q = {}));
var re;
(function(e) {
  e.range_end = "range_end", e.range_middle = "range_middle", e.range_start = "range_start", e.selected = "selected";
})(re || (re = {}));
var Z;
(function(e) {
  e.weeks_before_enter = "weeks_before_enter", e.weeks_before_exit = "weeks_before_exit", e.weeks_after_enter = "weeks_after_enter", e.weeks_after_exit = "weeks_after_exit", e.caption_after_enter = "caption_after_enter", e.caption_after_exit = "caption_after_exit", e.caption_before_enter = "caption_before_enter", e.caption_before_exit = "caption_before_exit";
})(Z || (Z = {}));
function Va(e) {
  const { options: t, className: n, components: r, classNames: o, ...a } = e, s = [o[N.Dropdown], n].join(" "), i = t == null ? void 0 : t.find(({ value: c }) => c === a.value);
  return g.createElement(
    "span",
    { "data-disabled": a.disabled, className: o[N.DropdownRoot] },
    g.createElement(r.Select, { className: s, ...a }, t == null ? void 0 : t.map(({ value: c, label: u, disabled: d }) => g.createElement(r.Option, { key: c, value: c, disabled: d }, u))),
    g.createElement(
      "span",
      { className: o[N.CaptionLabel], "aria-hidden": !0 },
      i == null ? void 0 : i.label,
      g.createElement(r.Chevron, { orientation: "down", size: 18, className: o[N.Chevron] })
    )
  );
}
function $a(e) {
  return g.createElement("div", { ...e });
}
function qa(e) {
  return g.createElement("div", { ...e });
}
function Ka(e) {
  const { calendarMonth: t, displayIndex: n, ...r } = e;
  return g.createElement("div", { ...r }, e.children);
}
function Ua(e) {
  const { calendarMonth: t, displayIndex: n, ...r } = e;
  return g.createElement("div", { ...r });
}
function Xa(e) {
  return g.createElement("table", { ...e });
}
function Qa(e) {
  return g.createElement("div", { ...e });
}
const In = C.createContext(void 0);
function Ye() {
  const e = C.useContext(In);
  if (e === void 0)
    throw new Error("useDayPicker() must be used within a custom component.");
  return e;
}
function Ja(e) {
  const { components: t } = Ye();
  return g.createElement(t.Dropdown, { ...e });
}
function Za(e) {
  const { onPreviousClick: t, onNextClick: n, previousMonth: r, nextMonth: o, ...a } = e, { components: s, classNames: i, labels: { labelPrevious: c, labelNext: u } } = Ye(), d = C.useCallback((h) => {
    o && (n == null || n(h));
  }, [o, n]), l = C.useCallback((h) => {
    r && (t == null || t(h));
  }, [r, t]);
  return g.createElement(
    "nav",
    { ...a },
    g.createElement(
      s.PreviousMonthButton,
      { type: "button", className: i[N.PreviousMonthButton], tabIndex: r ? void 0 : -1, "aria-disabled": r ? void 0 : !0, "aria-label": c(r), onClick: l },
      g.createElement(s.Chevron, { disabled: r ? void 0 : !0, className: i[N.Chevron], orientation: "left" })
    ),
    g.createElement(
      s.NextMonthButton,
      { type: "button", className: i[N.NextMonthButton], tabIndex: o ? void 0 : -1, "aria-disabled": o ? void 0 : !0, "aria-label": u(o), onClick: d },
      g.createElement(s.Chevron, { disabled: o ? void 0 : !0, orientation: "right", className: i[N.Chevron] })
    )
  );
}
function La(e) {
  const { components: t } = Ye();
  return g.createElement(t.Button, { ...e });
}
function es(e) {
  return g.createElement("option", { ...e });
}
function ts(e) {
  const { components: t } = Ye();
  return g.createElement(t.Button, { ...e });
}
function ns(e) {
  const { rootRef: t, ...n } = e;
  return g.createElement("div", { ...n, ref: t });
}
function rs(e) {
  return g.createElement("select", { ...e });
}
function os(e) {
  const { week: t, ...n } = e;
  return g.createElement("tr", { ...n });
}
function as(e) {
  return g.createElement("th", { ...e });
}
function ss(e) {
  return g.createElement(
    "thead",
    { "aria-hidden": !0 },
    g.createElement("tr", { ...e })
  );
}
function is(e) {
  const { week: t, ...n } = e;
  return g.createElement("th", { ...n });
}
function cs(e) {
  return g.createElement("th", { ...e });
}
function us(e) {
  return g.createElement("tbody", { ...e });
}
function ls(e) {
  const { components: t } = Ye();
  return g.createElement(t.Dropdown, { ...e });
}
const ds = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Button: Aa,
  CaptionLabel: Ra,
  Chevron: Ha,
  Day: Ga,
  DayButton: za,
  Dropdown: Va,
  DropdownNav: $a,
  Footer: qa,
  Month: Ka,
  MonthCaption: Ua,
  MonthGrid: Xa,
  Months: Qa,
  MonthsDropdown: Ja,
  Nav: Za,
  NextMonthButton: La,
  Option: es,
  PreviousMonthButton: ts,
  Root: ns,
  Select: rs,
  Week: os,
  WeekNumber: is,
  WeekNumberHeader: cs,
  Weekday: as,
  Weekdays: ss,
  Weeks: us,
  YearsDropdown: ls
}, Symbol.toStringTag, { value: "Module" }));
function ue(e, t, n = !1, r = ie) {
  let { from: o, to: a } = e;
  const { differenceInCalendarDays: s, isSameDay: i } = r;
  return o && a ? (s(a, o) < 0 && ([o, a] = [a, o]), s(t, o) >= (n ? 1 : 0) && s(a, t) >= (n ? 1 : 0)) : !n && a ? i(a, t) : !n && o ? i(o, t) : !1;
}
function mt(e) {
  return !!(e && typeof e == "object" && "before" in e && "after" in e);
}
function ze(e) {
  return !!(e && typeof e == "object" && "from" in e);
}
function gt(e) {
  return !!(e && typeof e == "object" && "after" in e);
}
function yt(e) {
  return !!(e && typeof e == "object" && "before" in e);
}
function Bn(e) {
  return !!(e && typeof e == "object" && "dayOfWeek" in e);
}
function Fn(e, t) {
  return Array.isArray(e) && e.every(t.isDate);
}
function le(e, t, n = ie) {
  const r = Array.isArray(t) ? t : [t], { isSameDay: o, differenceInCalendarDays: a, isAfter: s } = n;
  return r.some((i) => {
    if (typeof i == "boolean")
      return i;
    if (n.isDate(i))
      return o(e, i);
    if (Fn(i, n))
      return i.some((c) => o(e, c));
    if (ze(i))
      return ue(i, e, !1, n);
    if (Bn(i))
      return Array.isArray(i.dayOfWeek) ? i.dayOfWeek.includes(e.getDay()) : i.dayOfWeek === e.getDay();
    if (mt(i)) {
      const c = a(i.before, e), u = a(i.after, e), d = c > 0, l = u < 0;
      return s(i.before, i.after) ? l && d : d || l;
    }
    return gt(i) ? a(e, i.after) > 0 : yt(i) ? a(i.before, e) > 0 : typeof i == "function" ? i(e) : !1;
  });
}
function fs(e, t, n, r, o) {
  const { disabled: a, hidden: s, modifiers: i, showOutsideDays: c, broadcastCalendar: u, today: d = o.today() } = t, { isSameDay: l, isSameMonth: h, startOfMonth: b, isBefore: M, endOfMonth: p, isAfter: v } = o, w = n && b(n), D = r && p(r), f = {
    [q.focused]: [],
    [q.outside]: [],
    [q.disabled]: [],
    [q.hidden]: [],
    [q.today]: []
  }, k = {};
  for (const x of e) {
    const { date: m, displayMonth: O } = x, B = !!(O && !h(m, O)), Y = !!(w && M(m, w)), F = !!(D && v(m, D)), j = !!(a && le(m, a, o)), W = !!(s && le(m, s, o)) || Y || F || // Broadcast calendar will show outside days as default
    !u && !c && B || u && c === !1 && B, I = l(m, d);
    B && f.outside.push(x), j && f.disabled.push(x), W && f.hidden.push(x), I && f.today.push(x), i && Object.keys(i).forEach((S) => {
      const A = i == null ? void 0 : i[S];
      A && le(m, A, o) && (k[S] ? k[S].push(x) : k[S] = [x]);
    });
  }
  return (x) => {
    const m = {
      [q.focused]: !1,
      [q.disabled]: !1,
      [q.hidden]: !1,
      [q.outside]: !1,
      [q.today]: !1
    }, O = {};
    for (const B in f) {
      const Y = f[B];
      m[B] = Y.some((F) => F === x);
    }
    for (const B in k)
      O[B] = k[B].some((Y) => Y === x);
    return {
      ...m,
      // custom modifiers should override all the previous ones
      ...O
    };
  };
}
function hs(e, t, n = {}) {
  return Object.entries(e).filter(([, o]) => o === !0).reduce((o, [a]) => (n[a] ? o.push(n[a]) : t[q[a]] ? o.push(t[q[a]]) : t[re[a]] && o.push(t[re[a]]), o), [t[N.Day]]);
}
function ms(e) {
  return {
    ...ds,
    ...e
  };
}
function gs(e) {
  const t = {
    "data-mode": e.mode ?? void 0,
    "data-required": "required" in e ? e.required : void 0,
    "data-multiple-months": e.numberOfMonths && e.numberOfMonths > 1 || void 0,
    "data-week-numbers": e.showWeekNumber || void 0,
    "data-broadcast-calendar": e.broadcastCalendar || void 0,
    "data-nav-layout": e.navLayout || void 0
  };
  return Object.entries(e).forEach(([n, r]) => {
    n.startsWith("data-") && (t[n] = r);
  }), t;
}
function bt() {
  const e = {};
  for (const t in N)
    e[N[t]] = `rdp-${N[t]}`;
  for (const t in q)
    e[q[t]] = `rdp-${q[t]}`;
  for (const t in re)
    e[re[t]] = `rdp-${re[t]}`;
  for (const t in Z)
    e[Z[t]] = `rdp-${Z[t]}`;
  return e;
}
function An(e, t, n) {
  return (n ?? new L(t)).formatMonthYear(e);
}
const ys = An;
function bs(e, t, n) {
  return (n ?? new L(t)).format(e, "d");
}
function ws(e, t = ie) {
  return t.format(e, "LLLL");
}
function ps(e, t, n) {
  return (n ?? new L(t)).format(e, "cccccc");
}
function vs(e, t = ie) {
  return e < 10 ? t.formatNumber(`0${e.toLocaleString()}`) : t.formatNumber(`${e.toLocaleString()}`);
}
function ks() {
  return "";
}
function Rn(e, t = ie) {
  return t.format(e, "yyyy");
}
const Ms = Rn, xs = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  formatCaption: An,
  formatDay: bs,
  formatMonthCaption: ys,
  formatMonthDropdown: ws,
  formatWeekNumber: vs,
  formatWeekNumberHeader: ks,
  formatWeekdayName: ps,
  formatYearCaption: Ms,
  formatYearDropdown: Rn
}, Symbol.toStringTag, { value: "Module" }));
function Ds(e) {
  return e != null && e.formatMonthCaption && !e.formatCaption && (e.formatCaption = e.formatMonthCaption), e != null && e.formatYearCaption && !e.formatYearDropdown && (e.formatYearDropdown = e.formatYearCaption), {
    ...xs,
    ...e
  };
}
function wt(e, t, n, r) {
  let o = (r ?? new L(n)).format(e, "PPPP");
  return t.today && (o = `Today, ${o}`), t.selected && (o = `${o}, selected`), o;
}
const Ss = wt;
function pt(e, t, n) {
  return (n ?? new L(t)).formatMonthYear(e);
}
const Os = pt;
function Hn(e, t, n, r) {
  let o = (r ?? new L(n)).format(e, "PPPP");
  return t != null && t.today && (o = `Today, ${o}`), o;
}
function Gn(e) {
  return "Choose the Month";
}
function zn() {
  return "";
}
const Cs = "Go to the Next Month";
function Vn(e, t) {
  return Cs;
}
function $n(e) {
  return "Go to the Previous Month";
}
function qn(e, t, n) {
  return (n ?? new L(t)).format(e, "cccc");
}
function Kn(e, t) {
  return `Week ${e}`;
}
function Un(e) {
  return "Week Number";
}
function Xn(e) {
  return "Choose the Year";
}
const Ns = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  labelCaption: Os,
  labelDay: Ss,
  labelDayButton: wt,
  labelGrid: pt,
  labelGridcell: Hn,
  labelMonthDropdown: Gn,
  labelNav: zn,
  labelNext: Vn,
  labelPrevious: $n,
  labelWeekNumber: Kn,
  labelWeekNumberHeader: Un,
  labelWeekday: qn,
  labelYearDropdown: Xn
}, Symbol.toStringTag, { value: "Module" })), ne = (e, t, n) => t || (n ? typeof n == "function" ? n : (...r) => n : e);
function Ws(e, t) {
  var r;
  const n = ((r = t.locale) == null ? void 0 : r.labels) ?? {};
  return {
    ...Ns,
    ...e ?? {},
    labelDayButton: ne(wt, e == null ? void 0 : e.labelDayButton, n.labelDayButton),
    labelMonthDropdown: ne(Gn, e == null ? void 0 : e.labelMonthDropdown, n.labelMonthDropdown),
    labelNext: ne(Vn, e == null ? void 0 : e.labelNext, n.labelNext),
    labelPrevious: ne($n, e == null ? void 0 : e.labelPrevious, n.labelPrevious),
    labelWeekNumber: ne(Kn, e == null ? void 0 : e.labelWeekNumber, n.labelWeekNumber),
    labelYearDropdown: ne(Xn, e == null ? void 0 : e.labelYearDropdown, n.labelYearDropdown),
    labelGrid: ne(pt, e == null ? void 0 : e.labelGrid, n.labelGrid),
    labelGridcell: ne(Hn, e == null ? void 0 : e.labelGridcell, n.labelGridcell),
    labelNav: ne(zn, e == null ? void 0 : e.labelNav, n.labelNav),
    labelWeekNumberHeader: ne(Un, e == null ? void 0 : e.labelWeekNumberHeader, n.labelWeekNumberHeader),
    labelWeekday: ne(qn, e == null ? void 0 : e.labelWeekday, n.labelWeekday)
  };
}
function Ps(e, t, n, r, o) {
  const { startOfMonth: a, startOfYear: s, endOfYear: i, eachMonthOfInterval: c, getMonth: u } = o;
  return c({
    start: s(e),
    end: i(e)
  }).map((h) => {
    const b = r.formatMonthDropdown(h, o), M = u(h), p = t && h < a(t) || n && h > a(n) || !1;
    return { value: M, label: b, disabled: p };
  });
}
function Es(e, t = {}, n = {}) {
  let r = { ...t == null ? void 0 : t[N.Day] };
  return Object.entries(e).filter(([, o]) => o === !0).forEach(([o]) => {
    r = {
      ...r,
      ...n == null ? void 0 : n[o]
    };
  }), r;
}
function _s(e, t, n, r) {
  const o = r ?? e.today(), a = n ? e.startOfBroadcastWeek(o, e) : t ? e.startOfISOWeek(o) : e.startOfWeek(o), s = [];
  for (let i = 0; i < 7; i++) {
    const c = e.addDays(a, i);
    s.push(c);
  }
  return s;
}
function Ts(e, t, n, r, o = !1) {
  if (!e || !t)
    return;
  const { startOfYear: a, endOfYear: s, eachYearOfInterval: i, getYear: c } = r, u = a(e), d = s(t), l = i({ start: u, end: d });
  return o && l.reverse(), l.map((h) => {
    const b = n.formatYearDropdown(h, r);
    return {
      value: c(h),
      label: b,
      disabled: !1
    };
  });
}
function Ys(e, t = {}) {
  var i;
  const { weekStartsOn: n, locale: r } = t, o = n ?? ((i = r == null ? void 0 : r.options) == null ? void 0 : i.weekStartsOn) ?? 0, a = (c) => {
    const u = typeof c == "number" || typeof c == "string" ? new Date(c) : c;
    return new Q(u.getFullYear(), u.getMonth(), u.getDate(), 12, 0, 0, e);
  }, s = (c) => {
    const u = a(c);
    return new Date(u.getFullYear(), u.getMonth(), u.getDate(), 0, 0, 0, 0);
  };
  return {
    today: () => a(Q.tz(e)),
    newDate: (c, u, d) => new Q(c, u, d, 12, 0, 0, e),
    startOfDay: (c) => a(c),
    startOfWeek: (c, u) => {
      const d = a(c), l = (u == null ? void 0 : u.weekStartsOn) ?? o, h = (d.getDay() - l + 7) % 7;
      return d.setDate(d.getDate() - h), d;
    },
    startOfISOWeek: (c) => {
      const u = a(c), d = (u.getDay() - 1 + 7) % 7;
      return u.setDate(u.getDate() - d), u;
    },
    startOfMonth: (c) => {
      const u = a(c);
      return u.setDate(1), u;
    },
    startOfYear: (c) => {
      const u = a(c);
      return u.setMonth(0, 1), u;
    },
    endOfWeek: (c, u) => {
      const d = a(c), b = ((((u == null ? void 0 : u.weekStartsOn) ?? o) + 6) % 7 - d.getDay() + 7) % 7;
      return d.setDate(d.getDate() + b), d;
    },
    endOfISOWeek: (c) => {
      const u = a(c), d = (7 - u.getDay()) % 7;
      return u.setDate(u.getDate() + d), u;
    },
    endOfMonth: (c) => {
      const u = a(c);
      return u.setMonth(u.getMonth() + 1, 0), u;
    },
    endOfYear: (c) => {
      const u = a(c);
      return u.setMonth(11, 31), u;
    },
    eachMonthOfInterval: (c) => {
      const u = a(c.start), d = a(c.end), l = [], h = new Q(u.getFullYear(), u.getMonth(), 1, 12, 0, 0, e), b = d.getFullYear() * 12 + d.getMonth();
      for (; h.getFullYear() * 12 + h.getMonth() <= b; )
        l.push(new Q(h, e)), h.setMonth(h.getMonth() + 1, 1);
      return l;
    },
    // Normalize to noon once before arithmetic (avoid DST/midnight edge cases),
    // mutate the same TZDate, and return it.
    addDays: (c, u) => {
      const d = a(c);
      return d.setDate(d.getDate() + u), d;
    },
    addWeeks: (c, u) => {
      const d = a(c);
      return d.setDate(d.getDate() + u * 7), d;
    },
    addMonths: (c, u) => {
      const d = a(c);
      return d.setMonth(d.getMonth() + u), d;
    },
    addYears: (c, u) => {
      const d = a(c);
      return d.setFullYear(d.getFullYear() + u), d;
    },
    eachYearOfInterval: (c) => {
      const u = a(c.start), d = a(c.end), l = [], h = new Q(u.getFullYear(), 0, 1, 12, 0, 0, e);
      for (; h.getFullYear() <= d.getFullYear(); )
        l.push(new Q(h, e)), h.setFullYear(h.getFullYear() + 1, 0, 1);
      return l;
    },
    getWeek: (c, u) => {
      var l;
      const d = s(c);
      return ht(d, {
        weekStartsOn: (u == null ? void 0 : u.weekStartsOn) ?? o,
        firstWeekContainsDate: (u == null ? void 0 : u.firstWeekContainsDate) ?? ((l = r == null ? void 0 : r.options) == null ? void 0 : l.firstWeekContainsDate) ?? 1
      });
    },
    getISOWeek: (c) => {
      const u = s(c);
      return ft(u);
    },
    differenceInCalendarDays: (c, u) => {
      const d = s(c), l = s(u);
      return dt(d, l);
    },
    differenceInCalendarMonths: (c, u) => {
      const d = s(c), l = s(u);
      return Cn(d, l);
    }
  };
}
const je = (e) => e instanceof HTMLElement ? e : null, Ze = (e) => [
  ...e.querySelectorAll("[data-animated-month]") ?? []
], js = (e) => je(e.querySelector("[data-animated-month]")), Le = (e) => je(e.querySelector("[data-animated-caption]")), et = (e) => je(e.querySelector("[data-animated-weeks]")), Is = (e) => je(e.querySelector("[data-animated-nav]")), Bs = (e) => je(e.querySelector("[data-animated-weekdays]"));
function Fs(e, t, { classNames: n, months: r, focused: o, dateLib: a }) {
  const s = C.useRef(null), i = C.useRef(r), c = C.useRef(!1);
  C.useLayoutEffect(() => {
    const u = i.current;
    if (i.current = r, !t || !e.current || // safety check because the ref can be set to anything by consumers
    !(e.current instanceof HTMLElement) || // validation required for the animation to work as expected
    r.length === 0 || u.length === 0 || r.length !== u.length)
      return;
    const d = a.isSameMonth(r[0].date, u[0].date), l = a.isAfter(r[0].date, u[0].date), h = l ? n[Z.caption_after_enter] : n[Z.caption_before_enter], b = l ? n[Z.weeks_after_enter] : n[Z.weeks_before_enter], M = s.current, p = e.current.cloneNode(!0);
    if (p instanceof HTMLElement ? (Ze(p).forEach((f) => {
      if (!(f instanceof HTMLElement))
        return;
      const k = js(f);
      k && f.contains(k) && f.removeChild(k);
      const x = Le(f);
      x && x.classList.remove(h);
      const m = et(f);
      m && m.classList.remove(b);
    }), s.current = p) : s.current = null, c.current || d || // skip animation if a day is focused because it can cause issues to the animation and is better for a11y
    o)
      return;
    const v = M instanceof HTMLElement ? Ze(M) : [], w = Ze(e.current);
    if (w != null && w.every((D) => D instanceof HTMLElement) && v && v.every((D) => D instanceof HTMLElement)) {
      c.current = !0, e.current.style.isolation = "isolate";
      const D = Is(e.current);
      D && (D.style.zIndex = "1"), w.forEach((f, k) => {
        const x = v[k];
        if (!x)
          return;
        f.style.position = "relative", f.style.overflow = "hidden";
        const m = Le(f);
        m && m.classList.add(h);
        const O = et(f);
        O && O.classList.add(b);
        const B = () => {
          c.current = !1, e.current && (e.current.style.isolation = ""), D && (D.style.zIndex = ""), m && m.classList.remove(h), O && O.classList.remove(b), f.style.position = "", f.style.overflow = "", f.contains(x) && f.removeChild(x);
        };
        x.style.pointerEvents = "none", x.style.position = "absolute", x.style.overflow = "hidden", x.setAttribute("aria-hidden", "true");
        const Y = Bs(x);
        Y && (Y.style.opacity = "0");
        const F = Le(x);
        F && (F.classList.add(l ? n[Z.caption_before_exit] : n[Z.caption_after_exit]), F.addEventListener("animationend", B));
        const j = et(x);
        j && j.classList.add(l ? n[Z.weeks_before_exit] : n[Z.weeks_after_exit]), f.insertBefore(x, f.firstChild);
      });
    }
  });
}
function As(e, t, n, r) {
  const o = e[0], a = e[e.length - 1], { ISOWeek: s, fixedWeeks: i, broadcastCalendar: c } = n ?? {}, { addDays: u, differenceInCalendarDays: d, differenceInCalendarMonths: l, endOfBroadcastWeek: h, endOfISOWeek: b, endOfMonth: M, endOfWeek: p, isAfter: v, startOfBroadcastWeek: w, startOfISOWeek: D, startOfWeek: f } = r, k = c ? w(o, r) : s ? D(o) : f(o), x = c ? h(a) : s ? b(M(a)) : p(M(a)), m = t && (c ? h(t) : s ? b(t) : p(t)), O = m && v(x, m) ? m : x, B = d(O, k), Y = l(a, o) + 1, F = [];
  for (let I = 0; I <= B; I++) {
    const S = u(k, I);
    F.push(S);
  }
  const W = (c ? 35 : 42) * Y;
  if (i && F.length < W) {
    const I = W - F.length;
    for (let S = 0; S < I; S++) {
      const A = u(F[F.length - 1], 1);
      F.push(A);
    }
  }
  return F;
}
function Rs(e) {
  const t = [];
  return e.reduce((n, r) => {
    const o = r.weeks.reduce((a, s) => a.concat(s.days.slice()), t.slice());
    return n.concat(o.slice());
  }, t.slice());
}
function Hs(e, t, n, r) {
  const { numberOfMonths: o = 1 } = n, a = [];
  for (let s = 0; s < o; s++) {
    const i = r.addMonths(e, s);
    if (t && i > t)
      break;
    a.push(i);
  }
  return a;
}
function Ft(e, t, n, r) {
  const { month: o, defaultMonth: a, today: s = r.today(), numberOfMonths: i = 1 } = e;
  let c = o || a || s;
  const { differenceInCalendarMonths: u, addMonths: d, startOfMonth: l } = r;
  if (n && u(n, c) < i - 1) {
    const h = -1 * (i - 1);
    c = d(n, h);
  }
  return t && u(c, t) < 0 && (c = t), l(c);
}
function Gs(e, t, n, r) {
  const { addDays: o, endOfBroadcastWeek: a, endOfISOWeek: s, endOfMonth: i, endOfWeek: c, getISOWeek: u, getWeek: d, startOfBroadcastWeek: l, startOfISOWeek: h, startOfWeek: b } = r, M = e.reduce((p, v) => {
    const w = n.broadcastCalendar ? l(v, r) : n.ISOWeek ? h(v) : b(v), D = n.broadcastCalendar ? a(v) : n.ISOWeek ? s(i(v)) : c(i(v)), f = t.filter((O) => O >= w && O <= D), k = n.broadcastCalendar ? 35 : 42;
    if (n.fixedWeeks && f.length < k) {
      const O = t.filter((B) => {
        const Y = k - f.length;
        return B > D && B <= o(D, Y);
      });
      f.push(...O);
    }
    const x = f.reduce((O, B) => {
      const Y = n.ISOWeek ? u(B) : d(B), F = O.find((W) => W.weekNumber === Y), j = new jn(B, v, r);
      return F ? F.days.push(j) : O.push(new Fa(Y, [j])), O;
    }, []), m = new Ba(v, x);
    return p.push(m), p;
  }, []);
  return n.reverseMonths ? M.reverse() : M;
}
function zs(e, t) {
  let { startMonth: n, endMonth: r } = e;
  const { startOfYear: o, startOfDay: a, startOfMonth: s, endOfMonth: i, addYears: c, endOfYear: u, newDate: d, today: l } = t, { fromYear: h, toYear: b, fromMonth: M, toMonth: p } = e;
  !n && M && (n = M), !n && h && (n = t.newDate(h, 0, 1)), !r && p && (r = p), !r && b && (r = d(b, 11, 31));
  const v = e.captionLayout === "dropdown" || e.captionLayout === "dropdown-years";
  return n ? n = s(n) : h ? n = d(h, 0, 1) : !n && v && (n = o(c(e.today ?? l(), -100))), r ? r = i(r) : b ? r = d(b, 11, 31) : !r && v && (r = u(e.today ?? l())), [
    n && a(n),
    r && a(r)
  ];
}
function Vs(e, t, n, r) {
  if (n.disableNavigation)
    return;
  const { pagedNavigation: o, numberOfMonths: a = 1 } = n, { startOfMonth: s, addMonths: i, differenceInCalendarMonths: c } = r, u = o ? a : 1, d = s(e);
  if (!t)
    return i(d, u);
  if (!(c(t, e) < a))
    return i(d, u);
}
function $s(e, t, n, r) {
  if (n.disableNavigation)
    return;
  const { pagedNavigation: o, numberOfMonths: a } = n, { startOfMonth: s, addMonths: i, differenceInCalendarMonths: c } = r, u = o ? a ?? 1 : 1, d = s(e);
  if (!t)
    return i(d, -u);
  if (!(c(d, t) <= 0))
    return i(d, -u);
}
function qs(e) {
  const t = [];
  return e.reduce((n, r) => n.concat(r.weeks.slice()), t.slice());
}
function Ve(e, t) {
  const [n, r] = C.useState(e);
  return [t === void 0 ? n : t, r];
}
function Ks(e, t) {
  var k;
  const [n, r] = zs(e, t), { startOfMonth: o, endOfMonth: a } = t, s = Ft(e, n, r, t), [i, c] = Ve(
    s,
    // initialMonth is always computed from props.month if provided
    e.month ? s : void 0
  );
  C.useEffect(() => {
    const x = Ft(e, n, r, t);
    c(x);
  }, [e.timeZone]);
  const { months: u, weeks: d, days: l, previousMonth: h, nextMonth: b } = C.useMemo(() => {
    const x = Hs(i, r, { numberOfMonths: e.numberOfMonths }, t), m = As(x, e.endMonth ? a(e.endMonth) : void 0, {
      ISOWeek: e.ISOWeek,
      fixedWeeks: e.fixedWeeks,
      broadcastCalendar: e.broadcastCalendar
    }, t), O = Gs(x, m, {
      broadcastCalendar: e.broadcastCalendar,
      fixedWeeks: e.fixedWeeks,
      ISOWeek: e.ISOWeek,
      reverseMonths: e.reverseMonths
    }, t), B = qs(O), Y = Rs(O), F = $s(i, n, e, t), j = Vs(i, r, e, t);
    return {
      months: O,
      weeks: B,
      days: Y,
      previousMonth: F,
      nextMonth: j
    };
  }, [
    t,
    i.getTime(),
    r == null ? void 0 : r.getTime(),
    n == null ? void 0 : n.getTime(),
    e.disableNavigation,
    e.broadcastCalendar,
    (k = e.endMonth) == null ? void 0 : k.getTime(),
    e.fixedWeeks,
    e.ISOWeek,
    e.numberOfMonths,
    e.pagedNavigation,
    e.reverseMonths
  ]), { disableNavigation: M, onMonthChange: p } = e, v = (x) => d.some((m) => m.days.some((O) => O.isEqualTo(x))), w = (x) => {
    if (M)
      return;
    let m = o(x);
    n && m < o(n) && (m = o(n)), r && m > o(r) && (m = o(r)), c(m), p == null || p(m);
  };
  return {
    months: u,
    weeks: d,
    days: l,
    navStart: n,
    navEnd: r,
    previousMonth: h,
    nextMonth: b,
    goToMonth: w,
    goToDay: (x) => {
      v(x) || w(x.date);
    }
  };
}
var oe;
(function(e) {
  e[e.Today = 0] = "Today", e[e.Selected = 1] = "Selected", e[e.LastFocused = 2] = "LastFocused", e[e.FocusedModifier = 3] = "FocusedModifier";
})(oe || (oe = {}));
function At(e) {
  return !e[q.disabled] && !e[q.hidden] && !e[q.outside];
}
function Us(e, t, n, r) {
  let o, a = -1;
  for (const s of e) {
    const i = t(s);
    At(i) && (i[q.focused] && a < oe.FocusedModifier ? (o = s, a = oe.FocusedModifier) : r != null && r.isEqualTo(s) && a < oe.LastFocused ? (o = s, a = oe.LastFocused) : n(s.date) && a < oe.Selected ? (o = s, a = oe.Selected) : i[q.today] && a < oe.Today && (o = s, a = oe.Today));
  }
  return o || (o = e.find((s) => At(t(s)))), o;
}
function Xs(e, t, n, r, o, a, s) {
  const { ISOWeek: i, broadcastCalendar: c } = a, { addDays: u, addMonths: d, addWeeks: l, addYears: h, endOfBroadcastWeek: b, endOfISOWeek: M, endOfWeek: p, max: v, min: w, startOfBroadcastWeek: D, startOfISOWeek: f, startOfWeek: k } = s;
  let m = {
    day: u,
    week: l,
    month: d,
    year: h,
    startOfWeek: (O) => c ? D(O, s) : i ? f(O) : k(O),
    endOfWeek: (O) => c ? b(O) : i ? M(O) : p(O)
  }[e](n, t === "after" ? 1 : -1);
  return t === "before" && r ? m = v([r, m]) : t === "after" && o && (m = w([o, m])), m;
}
function Qn(e, t, n, r, o, a, s, i = 0) {
  if (i > 365)
    return;
  const c = Xs(e, t, n.date, r, o, a, s), u = !!(a.disabled && le(c, a.disabled, s)), d = !!(a.hidden && le(c, a.hidden, s)), l = c, h = new jn(c, l, s);
  return !u && !d ? h : Qn(e, t, h, r, o, a, s, i + 1);
}
function Qs(e, t, n, r, o) {
  const { autoFocus: a } = e, [s, i] = C.useState(), c = Us(t.days, n, r || (() => !1), s), [u, d] = C.useState(a ? c : void 0);
  return {
    isFocusTarget: (p) => !!(c != null && c.isEqualTo(p)),
    setFocused: d,
    focused: u,
    blur: () => {
      i(u), d(void 0);
    },
    moveFocus: (p, v) => {
      if (!u)
        return;
      const w = Qn(p, v, u, t.navStart, t.navEnd, e, o);
      w && (e.disableNavigation && !t.days.some((f) => f.isEqualTo(w)) || (t.goToDay(w), d(w)));
    }
  };
}
function Js(e, t) {
  const { selected: n, required: r, onSelect: o } = e, [a, s] = Ve(n, o ? n : void 0), i = o ? n : a, { isSameDay: c } = t, u = (b) => (i == null ? void 0 : i.some((M) => c(M, b))) ?? !1, { min: d, max: l } = e;
  return {
    selected: i,
    select: (b, M, p) => {
      let v = [...i ?? []];
      if (u(b)) {
        if ((i == null ? void 0 : i.length) === d || r && (i == null ? void 0 : i.length) === 1)
          return;
        v = i == null ? void 0 : i.filter((w) => !c(w, b));
      } else
        (i == null ? void 0 : i.length) === l ? v = [b] : v = [...v, b];
      return o || s(v), o == null || o(v, b, M, p), v;
    },
    isSelected: u
  };
}
function Zs(e, t, n = 0, r = 0, o = !1, a = ie) {
  const { from: s, to: i } = t || {}, { isSameDay: c, isAfter: u, isBefore: d } = a;
  let l;
  if (!s && !i)
    l = { from: e, to: n > 0 ? void 0 : e };
  else if (s && !i)
    c(s, e) ? n === 0 ? l = { from: s, to: e } : o ? l = { from: s, to: void 0 } : l = void 0 : d(e, s) ? l = { from: e, to: s } : l = { from: s, to: e };
  else if (s && i)
    if (c(s, e) && c(i, e))
      o ? l = { from: s, to: i } : l = void 0;
    else if (c(s, e))
      l = { from: s, to: n > 0 ? void 0 : e };
    else if (c(i, e))
      l = { from: e, to: n > 0 ? void 0 : e };
    else if (d(e, s))
      l = { from: e, to: i };
    else if (u(e, s))
      l = { from: s, to: e };
    else if (u(e, i))
      l = { from: s, to: e };
    else
      throw new Error("Invalid range");
  if (l != null && l.from && (l != null && l.to)) {
    const h = a.differenceInCalendarDays(l.to, l.from);
    r > 0 && h > r ? l = { from: e, to: void 0 } : n > 1 && h < n && (l = { from: e, to: void 0 });
  }
  return l;
}
function Ls(e, t, n = ie) {
  const r = Array.isArray(t) ? t : [t];
  let o = e.from;
  const a = n.differenceInCalendarDays(e.to, e.from), s = Math.min(a, 6);
  for (let i = 0; i <= s; i++) {
    if (r.includes(o.getDay()))
      return !0;
    o = n.addDays(o, 1);
  }
  return !1;
}
function Rt(e, t, n = ie) {
  return ue(e, t.from, !1, n) || ue(e, t.to, !1, n) || ue(t, e.from, !1, n) || ue(t, e.to, !1, n);
}
function ei(e, t, n = ie) {
  const r = Array.isArray(t) ? t : [t];
  if (r.filter((i) => typeof i != "function").some((i) => typeof i == "boolean" ? i : n.isDate(i) ? ue(e, i, !1, n) : Fn(i, n) ? i.some((c) => ue(e, c, !1, n)) : ze(i) ? i.from && i.to ? Rt(e, { from: i.from, to: i.to }, n) : !1 : Bn(i) ? Ls(e, i.dayOfWeek, n) : mt(i) ? n.isAfter(i.before, i.after) ? Rt(e, {
    from: n.addDays(i.after, 1),
    to: n.addDays(i.before, -1)
  }, n) : le(e.from, i, n) || le(e.to, i, n) : gt(i) || yt(i) ? le(e.from, i, n) || le(e.to, i, n) : !1))
    return !0;
  const s = r.filter((i) => typeof i == "function");
  if (s.length) {
    let i = e.from;
    const c = n.differenceInCalendarDays(e.to, e.from);
    for (let u = 0; u <= c; u++) {
      if (s.some((d) => d(i)))
        return !0;
      i = n.addDays(i, 1);
    }
  }
  return !1;
}
function ti(e, t) {
  const { disabled: n, excludeDisabled: r, selected: o, required: a, onSelect: s } = e, [i, c] = Ve(o, s ? o : void 0), u = s ? o : i;
  return {
    selected: u,
    select: (h, b, M) => {
      const { min: p, max: v } = e, w = h ? Zs(h, u, p, v, a, t) : void 0;
      return r && n && (w != null && w.from) && w.to && ei({ from: w.from, to: w.to }, n, t) && (w.from = h, w.to = void 0), s || c(w), s == null || s(w, h, b, M), w;
    },
    isSelected: (h) => u && ue(u, h, !1, t)
  };
}
function ni(e, t) {
  const { selected: n, required: r, onSelect: o } = e, [a, s] = Ve(n, o ? n : void 0), i = o ? n : a, { isSameDay: c } = t;
  return {
    selected: i,
    select: (l, h, b) => {
      let M = l;
      return !r && i && i && c(l, i) && (M = void 0), o || s(M), o == null || o(M, l, h, b), M;
    },
    isSelected: (l) => i ? c(i, l) : !1
  };
}
function ri(e, t) {
  const n = ni(e, t), r = Js(e, t), o = ti(e, t);
  switch (e.mode) {
    case "single":
      return n;
    case "multiple":
      return r;
    case "range":
      return o;
    default:
      return;
  }
}
function ee(e, t) {
  return e instanceof Q && e.timeZone === t ? e : new Q(e, t);
}
function pe(e, t, n) {
  return ee(e, t);
}
function Ht(e, t, n) {
  return typeof e == "boolean" || typeof e == "function" ? e : e instanceof Date ? pe(e, t) : Array.isArray(e) ? e.map((r) => r instanceof Date ? pe(r, t) : r) : ze(e) ? {
    ...e,
    from: e.from ? ee(e.from, t) : e.from,
    to: e.to ? ee(e.to, t) : e.to
  } : mt(e) ? {
    before: pe(e.before, t),
    after: pe(e.after, t)
  } : gt(e) ? {
    after: pe(e.after, t)
  } : yt(e) ? {
    before: pe(e.before, t)
  } : e;
}
function tt(e, t, n) {
  return e && (Array.isArray(e) ? e.map((r) => Ht(r, t)) : Ht(e, t));
}
function oi(e) {
  var St;
  let t = e;
  const n = t.timeZone;
  if (n && (t = {
    ...e,
    timeZone: n
  }, t.today && (t.today = ee(t.today, n)), t.month && (t.month = ee(t.month, n)), t.defaultMonth && (t.defaultMonth = ee(t.defaultMonth, n)), t.startMonth && (t.startMonth = ee(t.startMonth, n)), t.endMonth && (t.endMonth = ee(t.endMonth, n)), t.mode === "single" && t.selected ? t.selected = ee(t.selected, n) : t.mode === "multiple" && t.selected ? t.selected = (St = t.selected) == null ? void 0 : St.map((T) => ee(T, n)) : t.mode === "range" && t.selected && (t.selected = {
    from: t.selected.from ? ee(t.selected.from, n) : t.selected.from,
    to: t.selected.to ? ee(t.selected.to, n) : t.selected.to
  }), t.disabled !== void 0 && (t.disabled = tt(t.disabled, n)), t.hidden !== void 0 && (t.hidden = tt(t.hidden, n)), t.modifiers)) {
    const T = {};
    Object.keys(t.modifiers).forEach((G) => {
      var E;
      T[G] = tt((E = t.modifiers) == null ? void 0 : E[G], n);
    }), t.modifiers = T;
  }
  const { components: r, formatters: o, labels: a, dateLib: s, locale: i, classNames: c } = C.useMemo(() => {
    const T = { ...Yn, ...t.locale }, G = t.broadcastCalendar ? 1 : t.weekStartsOn, E = t.noonSafe && t.timeZone ? Ys(t.timeZone, {
      weekStartsOn: G,
      locale: T
    }) : void 0, H = t.dateLib && E ? { ...E, ...t.dateLib } : t.dateLib ?? E, J = new L({
      locale: T,
      weekStartsOn: G,
      firstWeekContainsDate: t.firstWeekContainsDate,
      useAdditionalWeekYearTokens: t.useAdditionalWeekYearTokens,
      useAdditionalDayOfYearTokens: t.useAdditionalDayOfYearTokens,
      timeZone: t.timeZone,
      numerals: t.numerals
    }, H);
    return {
      dateLib: J,
      components: ms(t.components),
      formatters: Ds(t.formatters),
      labels: Ws(t.labels, J.options),
      locale: T,
      classNames: { ...bt(), ...t.classNames }
    };
  }, [
    t.locale,
    t.broadcastCalendar,
    t.weekStartsOn,
    t.firstWeekContainsDate,
    t.useAdditionalWeekYearTokens,
    t.useAdditionalDayOfYearTokens,
    t.timeZone,
    t.numerals,
    t.dateLib,
    t.noonSafe,
    t.components,
    t.formatters,
    t.labels,
    t.classNames
  ]);
  t.today || (t = { ...t, today: s.today() });
  const { captionLayout: u, mode: d, navLayout: l, numberOfMonths: h = 1, onDayBlur: b, onDayClick: M, onDayFocus: p, onDayKeyDown: v, onDayMouseEnter: w, onDayMouseLeave: D, onNextClick: f, onPrevClick: k, showWeekNumber: x, styles: m } = t, { formatCaption: O, formatDay: B, formatMonthDropdown: Y, formatWeekNumber: F, formatWeekNumberHeader: j, formatWeekdayName: W, formatYearDropdown: I } = o, S = Ks(t, s), { days: A, months: X, navStart: _, navEnd: K, previousMonth: $, nextMonth: te, goToMonth: ce } = S, $e = fs(A, t, _, K, s), { isSelected: De, select: Se, selected: Ie } = ri(t, s) ?? {}, { blur: vt, focused: Be, isFocusTarget: er, moveFocus: kt, setFocused: Fe } = Qs(t, S, $e, De ?? (() => !1), s), { labelDayButton: tr, labelGridcell: nr, labelGrid: rr, labelMonthDropdown: or, labelNav: Mt, labelPrevious: ar, labelNext: sr, labelWeekday: ir, labelWeekNumber: cr, labelWeekNumberHeader: ur, labelYearDropdown: lr } = a, dr = C.useMemo(() => _s(s, t.ISOWeek, t.broadcastCalendar, t.today), [s, t.ISOWeek, t.broadcastCalendar, t.today]), xt = d !== void 0 || M !== void 0, qe = C.useCallback(() => {
    $ && (ce($), k == null || k($));
  }, [$, ce, k]), Ke = C.useCallback(() => {
    te && (ce(te), f == null || f(te));
  }, [ce, te, f]), fr = C.useCallback((T, G) => (E) => {
    E.preventDefault(), E.stopPropagation(), Fe(T), !G.disabled && (Se == null || Se(T.date, G, E), M == null || M(T.date, G, E));
  }, [Se, M, Fe]), hr = C.useCallback((T, G) => (E) => {
    Fe(T), p == null || p(T.date, G, E);
  }, [p, Fe]), mr = C.useCallback((T, G) => (E) => {
    vt(), b == null || b(T.date, G, E);
  }, [vt, b]), gr = C.useCallback((T, G) => (E) => {
    const H = {
      ArrowLeft: [
        E.shiftKey ? "month" : "day",
        t.dir === "rtl" ? "after" : "before"
      ],
      ArrowRight: [
        E.shiftKey ? "month" : "day",
        t.dir === "rtl" ? "before" : "after"
      ],
      ArrowDown: [E.shiftKey ? "year" : "week", "after"],
      ArrowUp: [E.shiftKey ? "year" : "week", "before"],
      PageUp: [E.shiftKey ? "year" : "month", "before"],
      PageDown: [E.shiftKey ? "year" : "month", "after"],
      Home: ["startOfWeek", "before"],
      End: ["endOfWeek", "after"]
    };
    if (H[E.key]) {
      E.preventDefault(), E.stopPropagation();
      const [J, R] = H[E.key];
      kt(J, R);
    }
    v == null || v(T.date, G, E);
  }, [kt, v, t.dir]), yr = C.useCallback((T, G) => (E) => {
    w == null || w(T.date, G, E);
  }, [w]), br = C.useCallback((T, G) => (E) => {
    D == null || D(T.date, G, E);
  }, [D]), wr = C.useCallback((T) => (G) => {
    const E = Number(G.target.value), H = s.setMonth(s.startOfMonth(T), E);
    ce(H);
  }, [s, ce]), pr = C.useCallback((T) => (G) => {
    const E = Number(G.target.value), H = s.setYear(s.startOfMonth(T), E);
    ce(H);
  }, [s, ce]), { className: vr, style: kr } = C.useMemo(() => ({
    className: [c[N.Root], t.className].filter(Boolean).join(" "),
    style: { ...m == null ? void 0 : m[N.Root], ...t.style }
  }), [c, t.className, t.style, m]), Mr = gs(t), Dt = C.useRef(null);
  Fs(Dt, !!t.animate, {
    classNames: c,
    months: X,
    focused: Be,
    dateLib: s
  });
  const xr = {
    dayPickerProps: t,
    selected: Ie,
    select: Se,
    isSelected: De,
    months: X,
    nextMonth: te,
    previousMonth: $,
    goToMonth: ce,
    getModifiers: $e,
    components: r,
    classNames: c,
    styles: m,
    labels: a,
    formatters: o
  };
  return g.createElement(
    In.Provider,
    { value: xr },
    g.createElement(
      r.Root,
      { rootRef: t.animate ? Dt : void 0, className: vr, style: kr, dir: t.dir, id: t.id, lang: t.lang, nonce: t.nonce, title: t.title, role: t.role, "aria-label": t["aria-label"], "aria-labelledby": t["aria-labelledby"], ...Mr },
      g.createElement(
        r.Months,
        { className: c[N.Months], style: m == null ? void 0 : m[N.Months] },
        !t.hideNavigation && !l && g.createElement(r.Nav, { "data-animated-nav": t.animate ? "true" : void 0, className: c[N.Nav], style: m == null ? void 0 : m[N.Nav], "aria-label": Mt(), onPreviousClick: qe, onNextClick: Ke, previousMonth: $, nextMonth: te }),
        X.map((T, G) => g.createElement(
          r.Month,
          {
            "data-animated-month": t.animate ? "true" : void 0,
            className: c[N.Month],
            style: m == null ? void 0 : m[N.Month],
            // biome-ignore lint/suspicious/noArrayIndexKey: breaks animation
            key: G,
            displayIndex: G,
            calendarMonth: T
          },
          l === "around" && !t.hideNavigation && G === 0 && g.createElement(
            r.PreviousMonthButton,
            { type: "button", className: c[N.PreviousMonthButton], tabIndex: $ ? void 0 : -1, "aria-disabled": $ ? void 0 : !0, "aria-label": ar($), onClick: qe, "data-animated-button": t.animate ? "true" : void 0 },
            g.createElement(r.Chevron, { disabled: $ ? void 0 : !0, className: c[N.Chevron], orientation: t.dir === "rtl" ? "right" : "left" })
          ),
          g.createElement(r.MonthCaption, { "data-animated-caption": t.animate ? "true" : void 0, className: c[N.MonthCaption], style: m == null ? void 0 : m[N.MonthCaption], calendarMonth: T, displayIndex: G }, u != null && u.startsWith("dropdown") ? g.createElement(
            r.DropdownNav,
            { className: c[N.Dropdowns], style: m == null ? void 0 : m[N.Dropdowns] },
            (() => {
              const E = u === "dropdown" || u === "dropdown-months" ? g.createElement(r.MonthsDropdown, { key: "month", className: c[N.MonthsDropdown], "aria-label": or(), classNames: c, components: r, disabled: !!t.disableNavigation, onChange: wr(T.date), options: Ps(T.date, _, K, o, s), style: m == null ? void 0 : m[N.Dropdown], value: s.getMonth(T.date) }) : g.createElement("span", { key: "month" }, Y(T.date, s)), H = u === "dropdown" || u === "dropdown-years" ? g.createElement(r.YearsDropdown, { key: "year", className: c[N.YearsDropdown], "aria-label": lr(s.options), classNames: c, components: r, disabled: !!t.disableNavigation, onChange: pr(T.date), options: Ts(_, K, o, s, !!t.reverseYears), style: m == null ? void 0 : m[N.Dropdown], value: s.getYear(T.date) }) : g.createElement("span", { key: "year" }, I(T.date, s));
              return s.getMonthYearOrder() === "year-first" ? [H, E] : [E, H];
            })(),
            g.createElement("span", { role: "status", "aria-live": "polite", style: {
              border: 0,
              clip: "rect(0 0 0 0)",
              height: "1px",
              margin: "-1px",
              overflow: "hidden",
              padding: 0,
              position: "absolute",
              width: "1px",
              whiteSpace: "nowrap",
              wordWrap: "normal"
            } }, O(T.date, s.options, s))
          ) : g.createElement(r.CaptionLabel, { className: c[N.CaptionLabel], role: "status", "aria-live": "polite" }, O(T.date, s.options, s))),
          l === "around" && !t.hideNavigation && G === h - 1 && g.createElement(
            r.NextMonthButton,
            { type: "button", className: c[N.NextMonthButton], tabIndex: te ? void 0 : -1, "aria-disabled": te ? void 0 : !0, "aria-label": sr(te), onClick: Ke, "data-animated-button": t.animate ? "true" : void 0 },
            g.createElement(r.Chevron, { disabled: te ? void 0 : !0, className: c[N.Chevron], orientation: t.dir === "rtl" ? "left" : "right" })
          ),
          G === h - 1 && l === "after" && !t.hideNavigation && g.createElement(r.Nav, { "data-animated-nav": t.animate ? "true" : void 0, className: c[N.Nav], style: m == null ? void 0 : m[N.Nav], "aria-label": Mt(), onPreviousClick: qe, onNextClick: Ke, previousMonth: $, nextMonth: te }),
          g.createElement(
            r.MonthGrid,
            { role: "grid", "aria-multiselectable": d === "multiple" || d === "range", "aria-label": rr(T.date, s.options, s) || void 0, className: c[N.MonthGrid], style: m == null ? void 0 : m[N.MonthGrid] },
            !t.hideWeekdays && g.createElement(
              r.Weekdays,
              { "data-animated-weekdays": t.animate ? "true" : void 0, className: c[N.Weekdays], style: m == null ? void 0 : m[N.Weekdays] },
              x && g.createElement(r.WeekNumberHeader, { "aria-label": ur(s.options), className: c[N.WeekNumberHeader], style: m == null ? void 0 : m[N.WeekNumberHeader], scope: "col" }, j()),
              dr.map((E) => g.createElement(r.Weekday, { "aria-label": ir(E, s.options, s), className: c[N.Weekday], key: String(E), style: m == null ? void 0 : m[N.Weekday], scope: "col" }, W(E, s.options, s)))
            ),
            g.createElement(r.Weeks, { "data-animated-weeks": t.animate ? "true" : void 0, className: c[N.Weeks], style: m == null ? void 0 : m[N.Weeks] }, T.weeks.map((E) => g.createElement(
              r.Week,
              { className: c[N.Week], key: E.weekNumber, style: m == null ? void 0 : m[N.Week], week: E },
              x && g.createElement(r.WeekNumber, { week: E, style: m == null ? void 0 : m[N.WeekNumber], "aria-label": cr(E.weekNumber, {
                locale: i
              }), className: c[N.WeekNumber], scope: "row", role: "rowheader" }, F(E.weekNumber, s)),
              E.days.map((H) => {
                const { date: J } = H, R = $e(H);
                if (R[q.focused] = !R.hidden && !!(Be != null && Be.isEqualTo(H)), R[re.selected] = (De == null ? void 0 : De(J)) || R.selected, ze(Ie)) {
                  const { from: Ue, to: Xe } = Ie;
                  R[re.range_start] = !!(Ue && Xe && s.isSameDay(J, Ue)), R[re.range_end] = !!(Ue && Xe && s.isSameDay(J, Xe)), R[re.range_middle] = ue(Ie, J, !0, s);
                }
                const Dr = Es(R, m, t.modifiersStyles), Sr = hs(R, c, t.modifiersClassNames), Or = !xt && !R.hidden ? nr(J, R, s.options, s) : void 0;
                return g.createElement(r.Day, { key: `${H.isoDate}_${H.displayMonthId}`, day: H, modifiers: R, className: Sr.join(" "), style: Dr, role: "gridcell", "aria-selected": R.selected || void 0, "aria-label": Or, "data-day": H.isoDate, "data-month": H.outside ? H.dateMonthId : void 0, "data-selected": R.selected || void 0, "data-disabled": R.disabled || void 0, "data-hidden": R.hidden || void 0, "data-outside": H.outside || void 0, "data-focused": R.focused || void 0, "data-today": R.today || void 0 }, !R.hidden && xt ? g.createElement(r.DayButton, { className: c[N.DayButton], style: m == null ? void 0 : m[N.DayButton], type: "button", day: H, modifiers: R, disabled: !R.focused && R.disabled || void 0, "aria-disabled": R.focused && R.disabled || void 0, tabIndex: er(H) ? 0 : -1, "aria-label": tr(J, R, s.options, s), onClick: fr(H, R), onBlur: mr(H, R), onFocus: hr(H, R), onKeyDown: gr(H, R), onMouseEnter: yr(H, R), onMouseLeave: br(H, R) }, B(J, s.options, s)) : !R.hidden && B(H.date, s.options, s));
              })
            )))
          )
        ))
      ),
      t.footer && g.createElement(r.Footer, { className: c[N.Footer], style: m == null ? void 0 : m[N.Footer], role: "status", "aria-live": "polite" }, t.footer)
    )
  );
}
function di({
  id: e,
  className: t,
  checked: n,
  defaultChecked: r,
  disabled: o = !1,
  name: a,
  onCheckedChange: s,
  "data-refast-id": i
}) {
  return /* @__PURE__ */ y.jsx(
    Fr,
    {
      id: e,
      checked: n,
      defaultChecked: r,
      disabled: o,
      name: a,
      onCheckedChange: s,
      className: P(
        "peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent",
        "transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50",
        "data-[state=checked]:bg-primary data-[state=unchecked]:bg-input",
        t
      ),
      "data-refast-id": i,
      children: /* @__PURE__ */ y.jsx(
        Ar,
        {
          className: P(
            "pointer-events-none block h-5 w-5 rounded-full bg-background shadow-lg ring-0 transition-transform",
            "data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0"
          )
        }
      )
    }
  );
}
function fi({
  id: e,
  className: t,
  label: n,
  description: r,
  required: o = !1,
  error: a,
  value: s,
  defaultValue: i = [0],
  min: c = 0,
  max: u = 100,
  step: d = 1,
  disabled: l = !1,
  orientation: h = "horizontal",
  onValueChange: b,
  onValueCommit: M,
  "data-refast-id": p
}) {
  const v = /* @__PURE__ */ y.jsxs(
    to,
    {
      id: e,
      value: s,
      defaultValue: i,
      min: c,
      max: u,
      step: d,
      disabled: l,
      orientation: h,
      onValueChange: b,
      onValueCommit: M,
      className: P(
        "relative flex w-full touch-none select-none items-center",
        h === "vertical" && "flex-col h-full w-auto",
        t
      ),
      children: [
        /* @__PURE__ */ y.jsx(
          no,
          {
            className: P(
              "relative grow overflow-hidden rounded-full bg-secondary",
              h === "horizontal" ? "h-2 w-full" : "h-full w-2"
            ),
            children: /* @__PURE__ */ y.jsx(ro, { className: "absolute bg-primary h-full" })
          }
        ),
        (s || i).map((w, D) => /* @__PURE__ */ y.jsx(
          oo,
          {
            className: P(
              "block h-5 w-5 rounded-full border-2 border-primary bg-background ring-offset-background",
              "transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
              "disabled:pointer-events-none disabled:opacity-50"
            )
          },
          D
        ))
      ]
    }
  );
  return n || r || a ? /* @__PURE__ */ y.jsx(
    Re,
    {
      id: e,
      label: n,
      description: r,
      required: o,
      error: a,
      "data-refast-id": p,
      children: v
    }
  ) : /* @__PURE__ */ y.jsx("div", { "data-refast-id": p, children: v });
}
const Jn = {
  default: "bg-transparent",
  outline: "border border-input bg-transparent hover:bg-accent hover:text-accent-foreground"
}, Zn = {
  sm: "h-9 px-2.5",
  default: "h-10 px-3",
  lg: "h-11 px-5"
};
function hi({
  id: e,
  className: t,
  label: n,
  icon: r,
  pressed: o,
  defaultPressed: a,
  disabled: s = !1,
  variant: i = "default",
  size: c = "default",
  onPressedChange: u,
  children: d,
  "data-refast-id": l
}) {
  return /* @__PURE__ */ y.jsx(
    ao,
    {
      id: e,
      pressed: o,
      defaultPressed: a,
      disabled: s,
      onPressedChange: u,
      className: P(
        "inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors",
        "hover:bg-muted hover:text-muted-foreground focus-visible:outline-none focus-visible:ring-2",
        "focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
        "data-[state=on]:bg-accent data-[state=on]:text-accent-foreground",
        Jn[i],
        Zn[c],
        t
      ),
      "data-refast-id": l,
      children: d || r && /* @__PURE__ */ y.jsx(Kt, { name: r, size: c === "lg" ? 20 : c === "sm" ? 14 : 16 }) || n
    }
  );
}
function mi({
  id: e,
  className: t,
  type: n = "single",
  value: r,
  defaultValue: o,
  disabled: a = !1,
  variant: s = "default",
  size: i = "default",
  onValueChange: c,
  children: u,
  "data-refast-id": d
}) {
  const l = r, h = o;
  if (n === "multiple") {
    const b = (M) => {
      if (!c) return;
      const p = /* @__PURE__ */ new Set();
      g.Children.forEach(u, (w) => {
        var k, x;
        if (!g.isValidElement(w)) return;
        const D = w.props, f = ((x = (k = D.tree) == null ? void 0 : k.props) == null ? void 0 : x.value) || D.value;
        f && p.add(f);
      }), M.forEach((w) => p.add(w));
      const v = {};
      p.forEach((w) => {
        v[w] = M.includes(w);
      }), c(v);
    };
    return /* @__PURE__ */ y.jsx(
      Nt,
      {
        id: e,
        type: "multiple",
        value: l,
        defaultValue: h,
        disabled: a,
        onValueChange: b,
        className: P(
          "inline-flex items-center justify-center gap-1",
          t
        ),
        "data-refast-id": d,
        children: g.Children.map(u, (M) => g.isValidElement(M) ? g.cloneElement(M, {
          variant: s,
          size: i
        }) : M)
      }
    );
  }
  return /* @__PURE__ */ y.jsx(
    Nt,
    {
      id: e,
      type: "single",
      value: l,
      defaultValue: h,
      disabled: a,
      onValueChange: c,
      className: P(
        "inline-flex items-center justify-center gap-1",
        t
      ),
      "data-refast-id": d,
      children: g.Children.map(u, (b) => g.isValidElement(b) ? g.cloneElement(b, {
        variant: s,
        size: i
      }) : b)
    }
  );
}
function gi({
  id: e,
  className: t,
  label: n,
  icon: r,
  value: o,
  disabled: a = !1,
  variant: s = "default",
  size: i = "default",
  children: c,
  "data-refast-id": u
}) {
  return /* @__PURE__ */ y.jsx(
    lo,
    {
      id: e,
      value: o,
      disabled: a,
      className: P(
        "inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors",
        "hover:bg-muted hover:text-muted-foreground focus-visible:outline-none focus-visible:ring-2",
        "focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
        "data-[state=on]:bg-accent data-[state=on]:text-accent-foreground",
        Jn[s],
        Zn[i],
        t
      ),
      "data-refast-id": u,
      children: c || r && /* @__PURE__ */ y.jsx(Kt, { name: r, size: i === "lg" ? 20 : i === "sm" ? 14 : 16 }) || n
    }
  );
}
function de(e) {
  if (e) {
    if (e instanceof Date) return e;
    if (typeof e == "string") {
      const t = new Date(e);
      return isNaN(t.getTime()) ? void 0 : t;
    }
  }
}
function ai(e) {
  if (e) {
    if (Array.isArray(e))
      return e.length === 0 ? void 0 : {
        from: de(e[0]),
        to: de(e[1])
      };
    if (typeof e == "object" && "from" in e)
      return {
        from: de(e.from),
        to: de(e.to)
      };
  }
}
function Ln(e) {
  if (!(!e || !Array.isArray(e)))
    return e.map((t) => de(t)).filter((t) => t !== void 0);
}
function nt({
  id: e,
  className: t,
  classNames: n,
  mode: r = "single",
  showOutsideDays: o = !0,
  captionLayout: a = "label",
  buttonVariant: s = "ghost",
  formatters: i,
  components: c,
  selected: u,
  defaultMonth: d,
  disabled: l,
  minDate: h,
  maxDate: b,
  numberOfMonths: M,
  onSelect: p,
  onMonthChange: v,
  showWeekNumber: w,
  ...D
}) {
  const f = bt(), k = g.useMemo(() => r === "range" ? ai(
    u
  ) : r === "multiple" ? Ln(u) : de(u), [r, u]), [x, m] = g.useState(k);
  g.useEffect(() => {
    m(k);
  }, [k]);
  const O = g.useMemo(() => de(d), [d]), B = g.useMemo(() => de(h), [h]), Y = g.useMemo(() => de(b), [b]), F = g.useMemo(() => {
    const S = [];
    return B && S.push({ before: B }), Y && S.push({ after: Y }), typeof l == "function" ? S.push(l) : l === !0 && S.push(() => !0), S.length > 0 ? S : void 0;
  }, [B, Y, l]), j = g.useCallback((S) => {
    if (!S) {
      if (m(void 0), !p) return;
      p(void 0);
      return;
    }
    if (r === "range" && typeof S == "object" && "from" in S) {
      const A = S;
      if (m(A), !p) return;
      p({
        from: A.from,
        to: A.to
      });
      return;
    }
    if (r === "multiple" && Array.isArray(S)) {
      if (m(S), !p) return;
      p(S);
      return;
    }
    m(S), p && p(S);
  }, [r, p]), W = g.useCallback((S) => {
    v && v(S);
  }, [v]), I = g.useMemo(() => r === "range" ? {
    mode: "range",
    selected: x,
    onSelect: j
  } : r === "multiple" ? {
    mode: "multiple",
    selected: x,
    onSelect: j
  } : {
    mode: "single",
    selected: x,
    onSelect: j
  }, [r, x, j]);
  return /* @__PURE__ */ y.jsx(
    oi,
    {
      showOutsideDays: o,
      className: P(
        "bg-background group/calendar p-3 [--cell-size:2.5rem] [[data-slot=card-content]_&]:bg-transparent [[data-slot=popover-content]_&]:bg-transparent",
        String.raw`rtl:**:[.rdp-button\_next>svg]:rotate-180`,
        String.raw`rtl:**:[.rdp-button\_previous>svg]:rotate-180`,
        t
      ),
      captionLayout: a,
      defaultMonth: O,
      disabled: F,
      numberOfMonths: M,
      onMonthChange: W,
      formatters: {
        formatMonthDropdown: (S) => S.toLocaleString("default", { month: "short" }),
        ...i
      },
      classNames: {
        root: P("w-fit", f.root),
        months: P(
          "flex gap-4 flex-col md:flex-row relative",
          f.months
        ),
        month: P("flex flex-col w-full gap-4", f.month),
        nav: P(
          "flex items-center gap-1 w-full absolute top-0 inset-x-0 justify-between",
          f.nav
        ),
        button_previous: P(
          Ot({ variant: s }),
          "size-[var(--cell-size)] aria-disabled:opacity-50 p-0 select-none",
          f.button_previous
        ),
        button_next: P(
          Ot({ variant: s }),
          "size-[var(--cell-size)] aria-disabled:opacity-50 p-0 select-none",
          f.button_next
        ),
        month_caption: P(
          "flex items-center justify-center h-[var(--cell-size)] w-full px-[var(--cell-size)]",
          f.month_caption
        ),
        dropdowns: P(
          "w-full flex items-center text-sm font-medium justify-center h-[var(--cell-size)] gap-2",
          f.dropdowns
        ),
        dropdown_root: P(
          "relative",
          f.dropdown_root
        ),
        dropdown: P(
          "absolute inset-0 cursor-pointer opacity-0 z-10 w-full h-full",
          f.dropdown
        ),
        months_dropdown: P(
          "inline-flex items-center justify-center gap-1 rounded-md border border-input bg-background px-3 py-1.5 text-sm font-medium shadow-sm transition-colors hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring cursor-pointer"
        ),
        years_dropdown: P(
          "inline-flex items-center justify-center gap-1 rounded-md border border-input bg-background px-3 py-1.5 text-sm font-medium shadow-sm transition-colors hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring cursor-pointer"
        ),
        caption_label: P(
          "select-none font-medium",
          a === "label" ? "text-sm" : "rounded-md px-2 flex items-center gap-1 text-sm h-8 [&>svg]:text-muted-foreground [&>svg]:size-3.5",
          f.caption_label
        ),
        table: "w-full border-collapse",
        weekdays: P("flex", f.weekdays),
        weekday: P(
          "text-muted-foreground rounded-md flex-1 font-normal text-sm select-none w-[var(--cell-size)] h-[var(--cell-size)] flex items-center justify-center",
          f.weekday
        ),
        week: P("flex w-full mt-2", f.week),
        week_number_header: P(
          "select-none w-[var(--cell-size)]",
          f.week_number_header
        ),
        week_number: P(
          "text-sm select-none text-muted-foreground",
          f.week_number
        ),
        day: P(
          "relative w-[var(--cell-size)] h-[var(--cell-size)] p-0 text-center [&:last-child[data-selected=true]_button]:rounded-r-md group/day select-none",
          w ? "[&:nth-child(2)[data-selected=true]_button]:rounded-l-md" : "[&:first-child[data-selected=true]_button]:rounded-l-md",
          f.day
        ),
        range_start: P(
          "rounded-l-md bg-accent",
          f.range_start
        ),
        range_middle: P("rounded-none", f.range_middle),
        range_end: P("rounded-r-md bg-accent", f.range_end),
        today: P(
          "bg-accent text-accent-foreground rounded-md data-[selected=true]:rounded-none",
          f.today
        ),
        outside: P(
          "text-muted-foreground aria-selected:text-muted-foreground",
          f.outside
        ),
        disabled: P(
          "text-muted-foreground opacity-50",
          f.disabled
        ),
        hidden: P("invisible", f.hidden),
        ...n
      },
      components: {
        Root: ({ className: S, rootRef: A, ...X }) => /* @__PURE__ */ y.jsx(
          "div",
          {
            "data-slot": "calendar",
            ref: A,
            className: P(S),
            ...X
          }
        ),
        Chevron: ({ className: S, orientation: A, ...X }) => A === "left" ? /* @__PURE__ */ y.jsx(Er, { className: P("size-4", S), ...X }) : A === "right" ? /* @__PURE__ */ y.jsx(
          _r,
          {
            className: P("size-4", S),
            ...X
          }
        ) : /* @__PURE__ */ y.jsx(Tr, { className: P("size-4", S), ...X }),
        DayButton: si,
        WeekNumber: ({ children: S, ...A }) => /* @__PURE__ */ y.jsx("td", { ...A, children: /* @__PURE__ */ y.jsx("div", { className: "flex size-[var(--cell-size)] items-center justify-center text-center", children: S }) }),
        ...c
      },
      ...I,
      ...D
    }
  );
}
function si({
  className: e,
  day: t,
  modifiers: n,
  ...r
}) {
  const o = bt(), a = g.useRef(null);
  return g.useEffect(() => {
    var s;
    n.focused && ((s = a.current) == null || s.focus());
  }, [n.focused]), /* @__PURE__ */ y.jsx(
    Pr,
    {
      ref: a,
      variant: "ghost",
      size: "icon",
      "data-day": t.date.toLocaleDateString(),
      "data-selected-single": n.selected && !n.range_start && !n.range_end && !n.range_middle,
      "data-range-start": n.range_start,
      "data-range-end": n.range_end,
      "data-range-middle": n.range_middle,
      className: P(
        "data-[selected-single=true]:bg-primary data-[selected-single=true]:text-primary-foreground",
        "data-[range-middle=true]:bg-accent data-[range-middle=true]:text-accent-foreground",
        "data-[range-start=true]:bg-primary data-[range-start=true]:text-primary-foreground",
        "data-[range-end=true]:bg-primary data-[range-end=true]:text-primary-foreground",
        "group-data-[focused=true]/day:border-ring group-data-[focused=true]/day:ring-ring/50",
        "dark:hover:text-accent-foreground",
        "flex size-[var(--cell-size)] items-center justify-center",
        "leading-none font-normal text-sm",
        "group-data-[focused=true]/day:relative group-data-[focused=true]/day:z-10 group-data-[focused=true]/day:ring-[3px]",
        "data-[range-end=true]:rounded-md data-[range-end=true]:rounded-r-md",
        "data-[range-middle=true]:rounded-none",
        "data-[range-start=true]:rounded-md data-[range-start=true]:rounded-l-md",
        o.day,
        e
      ),
      ...r
    }
  );
}
function yi({
  id: e,
  className: t,
  label: n,
  description: r,
  required: o = !1,
  error: a,
  value: s,
  placeholder: i = "Pick a date",
  disabled: c = !1,
  mode: u = "single",
  captionLayout: d = "label",
  minDate: l,
  maxDate: h,
  numberOfMonths: b,
  onChange: M,
  "data-refast-id": p
}) {
  const [v, w] = g.useState(!1), D = g.useRef(null), f = g.useRef(null), k = g.useMemo(() => {
    if (u === "range")
      return s && typeof s == "object" && ("from" in s || "to" in s) ? {
        from: s.from ? new Date(s.from) : void 0,
        to: s.to ? new Date(s.to) : void 0
      } : void 0;
    if (u === "multiple")
      return s ? Array.isArray(s) ? Ln(s) || [] : [] : [];
    if (!s) return;
    if (typeof s == "string") {
      const _ = new Date(s);
      return isNaN(_.getTime()) ? void 0 : _;
    }
  }, [u, s]), [x, m] = g.useState(
    u === "single" ? k : void 0
  ), [O, B] = g.useState(
    u === "range" ? k : void 0
  ), [Y, F] = g.useState(
    u === "multiple" ? k || [] : []
  );
  g.useEffect(() => {
    u === "single" ? m(k) : u === "range" ? B(k) : F(k || []);
  }, [u, k]), g.useEffect(() => {
    !v && D.current !== null && (M && M(D.current), D.current = null);
  }, [v, M]), g.useEffect(() => {
    const _ = ($) => {
      f.current && !f.current.contains($.target) && w(!1);
    }, K = ($) => {
      $.key === "Escape" && w(!1);
    };
    return v && (document.addEventListener("mousedown", _), document.addEventListener("keydown", K)), () => {
      document.removeEventListener("mousedown", _), document.removeEventListener("keydown", K);
    };
  }, [v]);
  const j = g.useMemo(() => u === "range" ? O != null && O.from ? O.to ? `${O.from.toLocaleDateString()} - ${O.to.toLocaleDateString()}` : O.from.toLocaleDateString() : i : u === "multiple" ? Y.length ? Y.length <= 2 ? Y.map((_) => _.toLocaleDateString()).join(", ") : `${Y[0].toLocaleDateString()}, ${Y[1].toLocaleDateString()} +${Y.length - 2} more` : i : x ? x.toLocaleDateString() : i, [u, x, O, Y, i]), W = (_) => {
    m(_), w(!1), M && M(_ ? _.toISOString() : void 0);
  }, I = (_) => {
    var K, $;
    B(_), _ != null && _.from && (_ != null && _.to) && _.from.getTime() !== _.to.getTime() && w(!1), M && M(_ ? {
      from: (K = _.from) == null ? void 0 : K.toISOString(),
      to: ($ = _.to) == null ? void 0 : $.toISOString()
    } : void 0);
  }, S = (_) => {
    const K = _ || [];
    F(K), D.current = K.map(($) => $.toISOString());
  }, A = u === "range" ? !!(O != null && O.from) : u === "multiple" ? Y.length > 0 : !!x, X = /* @__PURE__ */ y.jsxs("div", { ref: f, className: P("relative", t), children: [
    /* @__PURE__ */ y.jsxs(
      "button",
      {
        id: e,
        type: "button",
        disabled: c,
        onClick: () => w(!v),
        className: P(
          "flex h-10 w-full items-center justify-between rounded-md border bg-background px-3 py-2 text-sm",
          "ring-offset-background placeholder:text-muted-foreground",
          "focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
          "disabled:cursor-not-allowed disabled:opacity-50",
          a ? "border-destructive" : "border-input",
          !A && "text-muted-foreground"
        ),
        children: [
          /* @__PURE__ */ y.jsx("span", { className: "truncate", children: j }),
          /* @__PURE__ */ y.jsxs(
            "svg",
            {
              xmlns: "http://www.w3.org/2000/svg",
              width: "16",
              height: "16",
              viewBox: "0 0 24 24",
              fill: "none",
              stroke: "currentColor",
              strokeWidth: "2",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              className: "ml-2 h-4 w-4 shrink-0 opacity-50",
              children: [
                /* @__PURE__ */ y.jsx("rect", { width: "18", height: "18", x: "3", y: "4", rx: "2", ry: "2" }),
                /* @__PURE__ */ y.jsx("line", { x1: "16", x2: "16", y1: "2", y2: "6" }),
                /* @__PURE__ */ y.jsx("line", { x1: "8", x2: "8", y1: "2", y2: "6" }),
                /* @__PURE__ */ y.jsx("line", { x1: "3", x2: "21", y1: "10", y2: "10" })
              ]
            }
          )
        ]
      }
    ),
    v && /* @__PURE__ */ y.jsx("div", { className: "absolute top-full left-0 z-50 mt-2 rounded-md border bg-popover p-0 text-popover-foreground shadow-md", children: u === "range" ? /* @__PURE__ */ y.jsx(
      nt,
      {
        mode: "range",
        captionLayout: d,
        selected: O,
        onSelect: (_) => I(_),
        minDate: l,
        maxDate: h,
        numberOfMonths: b || 2
      }
    ) : u === "multiple" ? /* @__PURE__ */ y.jsx(
      nt,
      {
        mode: "multiple",
        captionLayout: d,
        selected: Y,
        onSelect: (_) => S(_),
        minDate: l,
        maxDate: h,
        numberOfMonths: b
      }
    ) : /* @__PURE__ */ y.jsx(
      nt,
      {
        mode: "single",
        captionLayout: d,
        selected: x,
        onSelect: (_) => W(_),
        minDate: l,
        maxDate: h
      }
    ) })
  ] });
  return n || r || a ? /* @__PURE__ */ y.jsx(
    Re,
    {
      id: e,
      label: n,
      description: r,
      required: o,
      error: a,
      "data-refast-id": p,
      children: X
    }
  ) : /* @__PURE__ */ y.jsx("div", { "data-refast-id": p, children: X });
}
function bi({
  id: e,
  className: t,
  label: n,
  description: r,
  required: o = !1,
  error: a,
  options: s = [],
  value: i,
  placeholder: c = "Select...",
  searchPlaceholder: u = "Search...",
  emptyText: d = "No results found.",
  multiselect: l = !1,
  disabled: h = !1,
  onSelect: b,
  "data-refast-id": M
}) {
  var j;
  const [p, v] = g.useState(!1), [w, D] = g.useState(""), [f, k] = g.useState(
    i !== void 0 ? i : l ? [] : ""
  ), x = g.useRef(null);
  g.useEffect(() => {
    const W = (S) => {
      x.current && !x.current.contains(S.target) && v(!1);
    }, I = (S) => {
      S.key === "Escape" && v(!1);
    };
    return p && (document.addEventListener("mousedown", W), document.addEventListener("keydown", I)), () => {
      document.removeEventListener("mousedown", W), document.removeEventListener("keydown", I);
    };
  }, [p]), g.useEffect(() => {
    i !== void 0 && k(i);
  }, [i]), g.useEffect(() => {
    const W = (I) => {
      const { targetId: S, value: A } = I.detail;
      S === e && A !== void 0 && k(A);
    };
    return window.addEventListener("refast:force-value-sync", W), () => window.removeEventListener("refast:force-value-sync", W);
  }, [e]), g.useEffect(() => {
    l && !Array.isArray(f) && k(f ? [f] : []);
  }, [l]);
  const m = s.filter((W) => !W || typeof W.label != "string" ? !1 : W.label.toLowerCase().includes(w.toLowerCase())), O = (W) => l && Array.isArray(f) ? f.includes(W) : f === W, B = (W) => {
    if (l) {
      const I = Array.isArray(f) ? f : [];
      let S;
      I.includes(W) ? S = I.filter((A) => A !== W) : S = [...I, W], k(S), b && b(S);
    } else
      k(W), b && b(W), v(!1), D("");
  }, Y = (W, I) => {
    if (W.stopPropagation(), l && Array.isArray(f)) {
      const S = f.filter((A) => A !== I);
      k(S), b && b(S);
    }
  }, F = /* @__PURE__ */ y.jsxs(
    "div",
    {
      ref: x,
      className: P("relative", t),
      children: [
        /* @__PURE__ */ y.jsxs(
          "button",
          {
            id: e,
            type: "button",
            disabled: h,
            onClick: () => v(!p),
            className: P(
              "flex min-h-[2.5rem] w-full items-center justify-between rounded-md border bg-background px-3 py-2 text-sm",
              "ring-offset-background placeholder:text-muted-foreground",
              "focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
              "disabled:cursor-not-allowed disabled:opacity-50",
              a ? "border-destructive" : "border-input"
            ),
            children: [
              l && Array.isArray(f) && f.length > 0 ? /* @__PURE__ */ y.jsx("div", { className: "flex flex-wrap gap-1", children: f.map((W) => {
                var S;
                const I = ((S = s.find((A) => A.value === W)) == null ? void 0 : S.label) || W;
                return /* @__PURE__ */ y.jsxs(
                  "div",
                  {
                    className: "flex items-center gap-1 rounded bg-secondary px-1.5 py-0.5 text-xs font-medium text-secondary-foreground",
                    children: [
                      I,
                      /* @__PURE__ */ y.jsx(
                        "div",
                        {
                          role: "button",
                          className: "ml-1 cursor-pointer rounded-full p-0.5 hover:bg-secondary-foreground/20",
                          onClick: (A) => Y(A, W),
                          children: /* @__PURE__ */ y.jsxs(
                            "svg",
                            {
                              xmlns: "http://www.w3.org/2000/svg",
                              width: "12",
                              height: "12",
                              viewBox: "0 0 24 24",
                              fill: "none",
                              stroke: "currentColor",
                              strokeWidth: "2",
                              strokeLinecap: "round",
                              strokeLinejoin: "round",
                              children: [
                                /* @__PURE__ */ y.jsx("path", { d: "M18 6 6 18" }),
                                /* @__PURE__ */ y.jsx("path", { d: "m6 6 12 12" })
                              ]
                            }
                          )
                        }
                      )
                    ]
                  },
                  W
                );
              }) }) : /* @__PURE__ */ y.jsx("span", { className: !f || Array.isArray(f) && f.length === 0 ? "text-muted-foreground" : "", children: !l && typeof f == "string" && ((j = s.find((W) => W.value === f)) == null ? void 0 : j.label) || c }),
              /* @__PURE__ */ y.jsxs(
                "svg",
                {
                  xmlns: "http://www.w3.org/2000/svg",
                  width: "16",
                  height: "16",
                  viewBox: "0 0 24 24",
                  fill: "none",
                  stroke: "currentColor",
                  strokeWidth: "2",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  className: "ml-2 h-4 w-4 shrink-0 opacity-50",
                  children: [
                    /* @__PURE__ */ y.jsx("path", { d: "m7 15 5 5 5-5" }),
                    /* @__PURE__ */ y.jsx("path", { d: "m7 9 5-5 5 5" })
                  ]
                }
              )
            ]
          }
        ),
        p && /* @__PURE__ */ y.jsxs("div", { className: "absolute top-full left-0 z-50 mt-2 w-full rounded-md border bg-popover text-popover-foreground shadow-md", children: [
          /* @__PURE__ */ y.jsxs("div", { className: "flex items-center border-b px-3", children: [
            /* @__PURE__ */ y.jsxs(
              "svg",
              {
                xmlns: "http://www.w3.org/2000/svg",
                width: "16",
                height: "16",
                viewBox: "0 0 24 24",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: "2",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                className: "mr-2 h-4 w-4 shrink-0 opacity-50",
                children: [
                  /* @__PURE__ */ y.jsx("circle", { cx: "11", cy: "11", r: "8" }),
                  /* @__PURE__ */ y.jsx("path", { d: "m21 21-4.3-4.3" })
                ]
              }
            ),
            /* @__PURE__ */ y.jsx(
              "input",
              {
                type: "text",
                value: w,
                onChange: (W) => D(W.target.value),
                placeholder: u,
                className: "flex h-10 w-full bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground"
              }
            )
          ] }),
          /* @__PURE__ */ y.jsx("div", { className: "max-h-[300px] overflow-y-auto p-1", children: m.length === 0 ? /* @__PURE__ */ y.jsx("div", { className: "py-6 text-center text-sm text-muted-foreground", children: d }) : m.map((W) => {
            const I = O(W.value);
            return /* @__PURE__ */ y.jsxs(
              "button",
              {
                type: "button",
                onClick: () => B(W.value),
                className: P(
                  "relative flex w-full cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none",
                  "hover:bg-accent hover:text-accent-foreground",
                  I && "bg-accent text-accent-foreground"
                ),
                children: [
                  I && /* @__PURE__ */ y.jsx(
                    "svg",
                    {
                      xmlns: "http://www.w3.org/2000/svg",
                      width: "16",
                      height: "16",
                      viewBox: "0 0 24 24",
                      fill: "none",
                      stroke: "currentColor",
                      strokeWidth: "2",
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      className: "mr-2 h-4 w-4",
                      children: /* @__PURE__ */ y.jsx("polyline", { points: "20 6 9 17 4 12" })
                    }
                  ),
                  /* @__PURE__ */ y.jsx("span", { className: I ? "" : "pl-6", children: W.label })
                ]
              },
              W.value
            );
          }) })
        ] })
      ]
    }
  );
  return n || r || a ? /* @__PURE__ */ y.jsx(
    Re,
    {
      id: e,
      label: n,
      description: r,
      required: o,
      error: a,
      "data-refast-id": M,
      children: F
    }
  ) : /* @__PURE__ */ y.jsx("div", { "data-refast-id": M, children: F });
}
function wi({
  id: e,
  className: t,
  label: n,
  description: r,
  required: o = !1,
  error: a,
  maxLength: s = 6,
  value: i,
  disabled: c = !1,
  onChange: u,
  onComplete: d,
  children: l,
  "data-refast-id": h
}) {
  const [b, M] = g.useState(i !== void 0 ? i : ""), p = g.useRef([]);
  g.useEffect(() => {
    i !== void 0 && M(i);
  }, [i]), g.useEffect(() => {
    const f = (k) => {
      const { targetId: x, value: m } = k.detail;
      x === e && m !== void 0 && M(m);
    };
    return window.addEventListener("refast:force-value-sync", f), () => window.removeEventListener("refast:force-value-sync", f);
  }, [e]);
  const v = (f, k) => {
    var O;
    const x = b.split("");
    x[f] = k;
    const m = x.join("").slice(0, s);
    M(m), u && u(m), k && f < s - 1 && ((O = p.current[f + 1]) == null || O.focus()), m.length === s && d && d(m);
  }, w = (f, k) => {
    var x;
    k.key === "Backspace" && !b[f] && f > 0 && ((x = p.current[f - 1]) == null || x.focus());
  }, D = l ? /* @__PURE__ */ y.jsx(
    "div",
    {
      id: e,
      className: P("flex items-center gap-2", t),
      children: l
    }
  ) : /* @__PURE__ */ y.jsx(
    "div",
    {
      id: e,
      className: P("flex items-center gap-2", t),
      children: Array.from({ length: s }).map((f, k) => /* @__PURE__ */ y.jsx(
        "input",
        {
          ref: (x) => {
            p.current[k] = x;
          },
          type: "text",
          inputMode: "numeric",
          maxLength: 1,
          value: b[k] || "",
          disabled: c,
          onChange: (x) => v(k, x.target.value),
          onKeyDown: (x) => w(k, x),
          className: P(
            "h-10 w-10 rounded-md border bg-background text-center text-sm",
            "focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
            "disabled:cursor-not-allowed disabled:opacity-50",
            a ? "border-destructive" : "border-input"
          )
        },
        k
      ))
    }
  );
  return n || r || a ? /* @__PURE__ */ y.jsx(
    Re,
    {
      id: e,
      label: n,
      description: r,
      required: o,
      error: a,
      "data-refast-id": h,
      children: D
    }
  ) : /* @__PURE__ */ y.jsx("div", { "data-refast-id": h, children: D });
}
function pi({
  id: e,
  className: t,
  children: n,
  "data-refast-id": r
}) {
  return /* @__PURE__ */ y.jsx(
    "div",
    {
      id: e,
      className: P("flex items-center", t),
      "data-refast-id": r,
      children: n
    }
  );
}
function vi({
  id: e,
  className: t,
  index: n,
  "data-refast-id": r
}) {
  return /* @__PURE__ */ y.jsx(
    "div",
    {
      id: e,
      className: P(
        "relative flex h-10 w-10 items-center justify-center border-y border-r border-input text-sm transition-all",
        "first:rounded-l-md first:border-l last:rounded-r-md",
        t
      ),
      "data-refast-id": r,
      children: /* @__PURE__ */ y.jsx("span", { className: "text-muted-foreground", children: "-" })
    }
  );
}
function ki({
  id: e,
  className: t,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ y.jsx(
    "div",
    {
      id: e,
      role: "separator",
      className: P("flex items-center justify-center", t),
      "data-refast-id": n,
      children: /* @__PURE__ */ y.jsx("span", { className: "text-muted-foreground", children: "-" })
    }
  );
}
export {
  nt as Calendar,
  bi as Combobox,
  yi as DatePicker,
  wi as InputOTP,
  pi as InputOTPGroup,
  ki as InputOTPSeparator,
  vi as InputOTPSlot,
  fi as Slider,
  di as Switch,
  hi as Toggle,
  mi as ToggleGroup,
  gi as ToggleGroupItem
};
