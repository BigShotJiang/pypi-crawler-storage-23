import { A as r, h as a } from "./refast-charts-C9YTpQC6.js";
const e = r, o = a;
export {
  o as Area,
  e as AreaChart
};
