import { B as r, i as a } from "./refast-charts-C9YTpQC6.js";
const o = r, B = a;
export {
  B as Bar,
  o as BarChart
};
