import { r as c } from "./refast-charts-C9YTpQC6.js";
import { t as te, u as k, P as T, o as Ae, c as it, b as x, q as G, v as st, a as pn, n as ee, D as ut, z as mn, f as hn, w as lt, i as dt, x as ft, A as gn, g as Cn, R as yn, C as En, I as Sn, p as bn, y as xn } from "./refast-index-iXHSFA1L.js";
import { j as l } from "./refast-markdown-ByFT1VZb.js";
var xe = "focusScope.autoFocusOnMount", we = "focusScope.autoFocusOnUnmount", ze = { bubbles: !1, cancelable: !0 }, wn = "FocusScope", Oe = c.forwardRef((e, t) => {
  const {
    loop: n = !1,
    trapped: r = !1,
    onMountAutoFocus: o,
    onUnmountAutoFocus: a,
    ...s
  } = e, [i, p] = c.useState(null), f = te(o), v = te(a), u = c.useRef(null), m = k(t, (d) => p(d)), h = c.useRef({
    paused: !1,
    pause() {
      this.paused = !0;
    },
    resume() {
      this.paused = !1;
    }
  }).current;
  c.useEffect(() => {
    if (r) {
      let d = function(b) {
        if (h.paused || !i) return;
        const w = b.target;
        i.contains(w) ? u.current = w : L(u.current, { select: !0 });
      }, g = function(b) {
        if (h.paused || !i) return;
        const w = b.relatedTarget;
        w !== null && (i.contains(w) || L(u.current, { select: !0 }));
      }, y = function(b) {
        if (document.activeElement === document.body)
          for (const R of b)
            R.removedNodes.length > 0 && L(i);
      };
      document.addEventListener("focusin", d), document.addEventListener("focusout", g);
      const S = new MutationObserver(y);
      return i && S.observe(i, { childList: !0, subtree: !0 }), () => {
        document.removeEventListener("focusin", d), document.removeEventListener("focusout", g), S.disconnect();
      };
    }
  }, [r, i, h.paused]), c.useEffect(() => {
    if (i) {
      Qe.add(h);
      const d = document.activeElement;
      if (!i.contains(d)) {
        const y = new CustomEvent(xe, ze);
        i.addEventListener(xe, f), i.dispatchEvent(y), y.defaultPrevented || (Rn(Tn(vt(i)), { select: !0 }), document.activeElement === d && L(i));
      }
      return () => {
        i.removeEventListener(xe, f), setTimeout(() => {
          const y = new CustomEvent(we, ze);
          i.addEventListener(we, v), i.dispatchEvent(y), y.defaultPrevented || L(d ?? document.body, { select: !0 }), i.removeEventListener(we, v), Qe.remove(h);
        }, 0);
      };
    }
  }, [i, f, v, h]);
  const E = c.useCallback(
    (d) => {
      if (!n && !r || h.paused) return;
      const g = d.key === "Tab" && !d.altKey && !d.ctrlKey && !d.metaKey, y = document.activeElement;
      if (g && y) {
        const S = d.currentTarget, [b, w] = Mn(S);
        b && w ? !d.shiftKey && y === w ? (d.preventDefault(), n && L(b, { select: !0 })) : d.shiftKey && y === b && (d.preventDefault(), n && L(w, { select: !0 })) : y === S && d.preventDefault();
      }
    },
    [n, r, h.paused]
  );
  return /* @__PURE__ */ l.jsx(T.div, { tabIndex: -1, ...s, ref: m, onKeyDown: E });
});
Oe.displayName = wn;
function Rn(e, { select: t = !1 } = {}) {
  const n = document.activeElement;
  for (const r of e)
    if (L(r, { select: t }), document.activeElement !== n) return;
}
function Mn(e) {
  const t = vt(e), n = qe(t, e), r = qe(t.reverse(), e);
  return [n, r];
}
function vt(e) {
  const t = [], n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (r) => {
      const o = r.tagName === "INPUT" && r.type === "hidden";
      return r.disabled || r.hidden || o ? NodeFilter.FILTER_SKIP : r.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }
  });
  for (; n.nextNode(); ) t.push(n.currentNode);
  return t;
}
function qe(e, t) {
  for (const n of e)
    if (!_n(n, { upTo: t })) return n;
}
function _n(e, { upTo: t }) {
  if (getComputedStyle(e).visibility === "hidden") return !0;
  for (; e; ) {
    if (t !== void 0 && e === t) return !1;
    if (getComputedStyle(e).display === "none") return !0;
    e = e.parentElement;
  }
  return !1;
}
function Pn(e) {
  return e instanceof HTMLInputElement && "select" in e;
}
function L(e, { select: t = !1 } = {}) {
  if (e && e.focus) {
    const n = document.activeElement;
    e.focus({ preventScroll: !0 }), e !== n && Pn(e) && t && e.select();
  }
}
var Qe = In();
function In() {
  let e = [];
  return {
    add(t) {
      const n = e[0];
      t !== n && (n == null || n.pause()), e = Je(e, t), e.unshift(t);
    },
    remove(t) {
      var n;
      e = Je(e, t), (n = e[0]) == null || n.resume();
    }
  };
}
function Je(e, t) {
  const n = [...e], r = n.indexOf(t);
  return r !== -1 && n.splice(r, 1), n;
}
function Tn(e) {
  return e.filter((t) => t.tagName !== "A");
}
var Re = 0;
function pt() {
  c.useEffect(() => {
    const e = document.querySelectorAll("[data-radix-focus-guard]");
    return document.body.insertAdjacentElement("afterbegin", e[0] ?? et()), document.body.insertAdjacentElement("beforeend", e[1] ?? et()), Re++, () => {
      Re === 1 && document.querySelectorAll("[data-radix-focus-guard]").forEach((t) => t.remove()), Re--;
    };
  }, []);
}
function et() {
  const e = document.createElement("span");
  return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.outline = "none", e.style.opacity = "0", e.style.position = "fixed", e.style.pointerEvents = "none", e;
}
var O = function() {
  return O = Object.assign || function(t) {
    for (var n, r = 1, o = arguments.length; r < o; r++) {
      n = arguments[r];
      for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (t[a] = n[a]);
    }
    return t;
  }, O.apply(this, arguments);
};
function mt(e, t) {
  var n = {};
  for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
  if (e != null && typeof Object.getOwnPropertySymbols == "function")
    for (var o = 0, r = Object.getOwnPropertySymbols(e); o < r.length; o++)
      t.indexOf(r[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[o]) && (n[r[o]] = e[r[o]]);
  return n;
}
function Dn(e, t, n) {
  if (n || arguments.length === 2) for (var r = 0, o = t.length, a; r < o; r++)
    (a || !(r in t)) && (a || (a = Array.prototype.slice.call(t, 0, r)), a[r] = t[r]);
  return e.concat(a || Array.prototype.slice.call(t));
}
var fe = "right-scroll-bar-position", ve = "width-before-scroll-bar", An = "with-scroll-bars-hidden", On = "--removed-body-scroll-bar-size";
function Me(e, t) {
  return typeof e == "function" ? e(t) : e && (e.current = t), e;
}
function Nn(e, t) {
  var n = c.useState(function() {
    return {
      // value
      value: e,
      // last callback
      callback: t,
      // "memoized" public interface
      facade: {
        get current() {
          return n.value;
        },
        set current(r) {
          var o = n.value;
          o !== r && (n.value = r, n.callback(r, o));
        }
      }
    };
  })[0];
  return n.callback = t, n.facade;
}
var kn = typeof window < "u" ? c.useLayoutEffect : c.useEffect, tt = /* @__PURE__ */ new WeakMap();
function jn(e, t) {
  var n = Nn(null, function(r) {
    return e.forEach(function(o) {
      return Me(o, r);
    });
  });
  return kn(function() {
    var r = tt.get(n);
    if (r) {
      var o = new Set(r), a = new Set(e), s = n.current;
      o.forEach(function(i) {
        a.has(i) || Me(i, null);
      }), a.forEach(function(i) {
        o.has(i) || Me(i, s);
      });
    }
    tt.set(n, e);
  }, [e]), n;
}
function Fn(e) {
  return e;
}
function Ln(e, t) {
  t === void 0 && (t = Fn);
  var n = [], r = !1, o = {
    read: function() {
      if (r)
        throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
      return n.length ? n[n.length - 1] : e;
    },
    useMedium: function(a) {
      var s = t(a, r);
      return n.push(s), function() {
        n = n.filter(function(i) {
          return i !== s;
        });
      };
    },
    assignSyncMedium: function(a) {
      for (r = !0; n.length; ) {
        var s = n;
        n = [], s.forEach(a);
      }
      n = {
        push: function(i) {
          return a(i);
        },
        filter: function() {
          return n;
        }
      };
    },
    assignMedium: function(a) {
      r = !0;
      var s = [];
      if (n.length) {
        var i = n;
        n = [], i.forEach(a), s = n;
      }
      var p = function() {
        var v = s;
        s = [], v.forEach(a);
      }, f = function() {
        return Promise.resolve().then(p);
      };
      f(), n = {
        push: function(v) {
          s.push(v), f();
        },
        filter: function(v) {
          return s = s.filter(v), n;
        }
      };
    }
  };
  return o;
}
function Wn(e) {
  e === void 0 && (e = {});
  var t = Ln(null);
  return t.options = O({ async: !0, ssr: !1 }, e), t;
}
var ht = function(e) {
  var t = e.sideCar, n = mt(e, ["sideCar"]);
  if (!t)
    throw new Error("Sidecar: please provide `sideCar` property to import the right car");
  var r = t.read();
  if (!r)
    throw new Error("Sidecar medium not found");
  return c.createElement(r, O({}, n));
};
ht.isSideCarExport = !0;
function Kn(e, t) {
  return e.useMedium(t), ht;
}
var gt = Wn(), _e = function() {
}, ge = c.forwardRef(function(e, t) {
  var n = c.useRef(null), r = c.useState({
    onScrollCapture: _e,
    onWheelCapture: _e,
    onTouchMoveCapture: _e
  }), o = r[0], a = r[1], s = e.forwardProps, i = e.children, p = e.className, f = e.removeScrollBar, v = e.enabled, u = e.shards, m = e.sideCar, h = e.noRelative, E = e.noIsolation, d = e.inert, g = e.allowPinchZoom, y = e.as, S = y === void 0 ? "div" : y, b = e.gapMode, w = mt(e, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noRelative", "noIsolation", "inert", "allowPinchZoom", "as", "gapMode"]), R = m, I = jn([n, t]), M = O(O({}, w), o);
  return c.createElement(
    c.Fragment,
    null,
    v && c.createElement(R, { sideCar: gt, removeScrollBar: f, shards: u, noRelative: h, noIsolation: E, inert: d, setCallbacks: a, allowPinchZoom: !!g, lockRef: n, gapMode: b }),
    s ? c.cloneElement(c.Children.only(i), O(O({}, M), { ref: I })) : c.createElement(S, O({}, M, { className: p, ref: I }), i)
  );
});
ge.defaultProps = {
  enabled: !0,
  removeScrollBar: !0,
  inert: !1
};
ge.classNames = {
  fullWidth: ve,
  zeroRight: fe
};
var Gn = function() {
  if (typeof __webpack_nonce__ < "u")
    return __webpack_nonce__;
};
function Bn() {
  if (!document)
    return null;
  var e = document.createElement("style");
  e.type = "text/css";
  var t = Gn();
  return t && e.setAttribute("nonce", t), e;
}
function Vn(e, t) {
  e.styleSheet ? e.styleSheet.cssText = t : e.appendChild(document.createTextNode(t));
}
function Un(e) {
  var t = document.head || document.getElementsByTagName("head")[0];
  t.appendChild(e);
}
var $n = function() {
  var e = 0, t = null;
  return {
    add: function(n) {
      e == 0 && (t = Bn()) && (Vn(t, n), Un(t)), e++;
    },
    remove: function() {
      e--, !e && t && (t.parentNode && t.parentNode.removeChild(t), t = null);
    }
  };
}, Hn = function() {
  var e = $n();
  return function(t, n) {
    c.useEffect(function() {
      return e.add(t), function() {
        e.remove();
      };
    }, [t && n]);
  };
}, Ct = function() {
  var e = Hn(), t = function(n) {
    var r = n.styles, o = n.dynamic;
    return e(r, o), null;
  };
  return t;
}, Yn = {
  left: 0,
  top: 0,
  right: 0,
  gap: 0
}, Pe = function(e) {
  return parseInt(e || "", 10) || 0;
}, Xn = function(e) {
  var t = window.getComputedStyle(document.body), n = t[e === "padding" ? "paddingLeft" : "marginLeft"], r = t[e === "padding" ? "paddingTop" : "marginTop"], o = t[e === "padding" ? "paddingRight" : "marginRight"];
  return [Pe(n), Pe(r), Pe(o)];
}, Zn = function(e) {
  if (e === void 0 && (e = "margin"), typeof window > "u")
    return Yn;
  var t = Xn(e), n = document.documentElement.clientWidth, r = window.innerWidth;
  return {
    left: t[0],
    top: t[1],
    right: t[2],
    gap: Math.max(0, r - n + t[2] - t[0])
  };
}, zn = Ct(), q = "data-scroll-locked", qn = function(e, t, n, r) {
  var o = e.left, a = e.top, s = e.right, i = e.gap;
  return n === void 0 && (n = "margin"), `
  .`.concat(An, ` {
   overflow: hidden `).concat(r, `;
   padding-right: `).concat(i, "px ").concat(r, `;
  }
  body[`).concat(q, `] {
    overflow: hidden `).concat(r, `;
    overscroll-behavior: contain;
    `).concat([
    t && "position: relative ".concat(r, ";"),
    n === "margin" && `
    padding-left: `.concat(o, `px;
    padding-top: `).concat(a, `px;
    padding-right: `).concat(s, `px;
    margin-left:0;
    margin-top:0;
    margin-right: `).concat(i, "px ").concat(r, `;
    `),
    n === "padding" && "padding-right: ".concat(i, "px ").concat(r, ";")
  ].filter(Boolean).join(""), `
  }
  
  .`).concat(fe, ` {
    right: `).concat(i, "px ").concat(r, `;
  }
  
  .`).concat(ve, ` {
    margin-right: `).concat(i, "px ").concat(r, `;
  }
  
  .`).concat(fe, " .").concat(fe, ` {
    right: 0 `).concat(r, `;
  }
  
  .`).concat(ve, " .").concat(ve, ` {
    margin-right: 0 `).concat(r, `;
  }
  
  body[`).concat(q, `] {
    `).concat(On, ": ").concat(i, `px;
  }
`);
}, nt = function() {
  var e = parseInt(document.body.getAttribute(q) || "0", 10);
  return isFinite(e) ? e : 0;
}, Qn = function() {
  c.useEffect(function() {
    return document.body.setAttribute(q, (nt() + 1).toString()), function() {
      var e = nt() - 1;
      e <= 0 ? document.body.removeAttribute(q) : document.body.setAttribute(q, e.toString());
    };
  }, []);
}, Jn = function(e) {
  var t = e.noRelative, n = e.noImportant, r = e.gapMode, o = r === void 0 ? "margin" : r;
  Qn();
  var a = c.useMemo(function() {
    return Zn(o);
  }, [o]);
  return c.createElement(zn, { styles: qn(a, !t, o, n ? "" : "!important") });
}, Te = !1;
if (typeof window < "u")
  try {
    var se = Object.defineProperty({}, "passive", {
      get: function() {
        return Te = !0, !0;
      }
    });
    window.addEventListener("test", se, se), window.removeEventListener("test", se, se);
  } catch {
    Te = !1;
  }
var X = Te ? { passive: !1 } : !1, er = function(e) {
  return e.tagName === "TEXTAREA";
}, yt = function(e, t) {
  if (!(e instanceof Element))
    return !1;
  var n = window.getComputedStyle(e);
  return (
    // not-not-scrollable
    n[t] !== "hidden" && // contains scroll inside self
    !(n.overflowY === n.overflowX && !er(e) && n[t] === "visible")
  );
}, tr = function(e) {
  return yt(e, "overflowY");
}, nr = function(e) {
  return yt(e, "overflowX");
}, rt = function(e, t) {
  var n = t.ownerDocument, r = t;
  do {
    typeof ShadowRoot < "u" && r instanceof ShadowRoot && (r = r.host);
    var o = Et(e, r);
    if (o) {
      var a = St(e, r), s = a[1], i = a[2];
      if (s > i)
        return !0;
    }
    r = r.parentNode;
  } while (r && r !== n.body);
  return !1;
}, rr = function(e) {
  var t = e.scrollTop, n = e.scrollHeight, r = e.clientHeight;
  return [
    t,
    n,
    r
  ];
}, or = function(e) {
  var t = e.scrollLeft, n = e.scrollWidth, r = e.clientWidth;
  return [
    t,
    n,
    r
  ];
}, Et = function(e, t) {
  return e === "v" ? tr(t) : nr(t);
}, St = function(e, t) {
  return e === "v" ? rr(t) : or(t);
}, ar = function(e, t) {
  return e === "h" && t === "rtl" ? -1 : 1;
}, cr = function(e, t, n, r, o) {
  var a = ar(e, window.getComputedStyle(t).direction), s = a * r, i = n.target, p = t.contains(i), f = !1, v = s > 0, u = 0, m = 0;
  do {
    if (!i)
      break;
    var h = St(e, i), E = h[0], d = h[1], g = h[2], y = d - g - a * E;
    (E || y) && Et(e, i) && (u += y, m += E);
    var S = i.parentNode;
    i = S && S.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? S.host : S;
  } while (
    // portaled content
    !p && i !== document.body || // self content
    p && (t.contains(i) || t === i)
  );
  return (v && Math.abs(u) < 1 || !v && Math.abs(m) < 1) && (f = !0), f;
}, ue = function(e) {
  return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0];
}, ot = function(e) {
  return [e.deltaX, e.deltaY];
}, at = function(e) {
  return e && "current" in e ? e.current : e;
}, ir = function(e, t) {
  return e[0] === t[0] && e[1] === t[1];
}, sr = function(e) {
  return `
  .block-interactivity-`.concat(e, ` {pointer-events: none;}
  .allow-interactivity-`).concat(e, ` {pointer-events: all;}
`);
}, ur = 0, Z = [];
function lr(e) {
  var t = c.useRef([]), n = c.useRef([0, 0]), r = c.useRef(), o = c.useState(ur++)[0], a = c.useState(Ct)[0], s = c.useRef(e);
  c.useEffect(function() {
    s.current = e;
  }, [e]), c.useEffect(function() {
    if (e.inert) {
      document.body.classList.add("block-interactivity-".concat(o));
      var d = Dn([e.lockRef.current], (e.shards || []).map(at), !0).filter(Boolean);
      return d.forEach(function(g) {
        return g.classList.add("allow-interactivity-".concat(o));
      }), function() {
        document.body.classList.remove("block-interactivity-".concat(o)), d.forEach(function(g) {
          return g.classList.remove("allow-interactivity-".concat(o));
        });
      };
    }
  }, [e.inert, e.lockRef.current, e.shards]);
  var i = c.useCallback(function(d, g) {
    if ("touches" in d && d.touches.length === 2 || d.type === "wheel" && d.ctrlKey)
      return !s.current.allowPinchZoom;
    var y = ue(d), S = n.current, b = "deltaX" in d ? d.deltaX : S[0] - y[0], w = "deltaY" in d ? d.deltaY : S[1] - y[1], R, I = d.target, M = Math.abs(b) > Math.abs(w) ? "h" : "v";
    if ("touches" in d && M === "h" && I.type === "range")
      return !1;
    var ie = window.getSelection(), j = ie && ie.anchorNode, V = j ? j === I || j.contains(I) : !1;
    if (V)
      return !1;
    var U = rt(M, I);
    if (!U)
      return !0;
    if (U ? R = M : (R = M === "v" ? "h" : "v", U = rt(M, I)), !U)
      return !1;
    if (!r.current && "changedTouches" in d && (b || w) && (r.current = R), !R)
      return !0;
    var $ = r.current || R;
    return cr($, g, d, $ === "h" ? b : w);
  }, []), p = c.useCallback(function(d) {
    var g = d;
    if (!(!Z.length || Z[Z.length - 1] !== a)) {
      var y = "deltaY" in g ? ot(g) : ue(g), S = t.current.filter(function(R) {
        return R.name === g.type && (R.target === g.target || g.target === R.shadowParent) && ir(R.delta, y);
      })[0];
      if (S && S.should) {
        g.cancelable && g.preventDefault();
        return;
      }
      if (!S) {
        var b = (s.current.shards || []).map(at).filter(Boolean).filter(function(R) {
          return R.contains(g.target);
        }), w = b.length > 0 ? i(g, b[0]) : !s.current.noIsolation;
        w && g.cancelable && g.preventDefault();
      }
    }
  }, []), f = c.useCallback(function(d, g, y, S) {
    var b = { name: d, delta: g, target: y, should: S, shadowParent: dr(y) };
    t.current.push(b), setTimeout(function() {
      t.current = t.current.filter(function(w) {
        return w !== b;
      });
    }, 1);
  }, []), v = c.useCallback(function(d) {
    n.current = ue(d), r.current = void 0;
  }, []), u = c.useCallback(function(d) {
    f(d.type, ot(d), d.target, i(d, e.lockRef.current));
  }, []), m = c.useCallback(function(d) {
    f(d.type, ue(d), d.target, i(d, e.lockRef.current));
  }, []);
  c.useEffect(function() {
    return Z.push(a), e.setCallbacks({
      onScrollCapture: u,
      onWheelCapture: u,
      onTouchMoveCapture: m
    }), document.addEventListener("wheel", p, X), document.addEventListener("touchmove", p, X), document.addEventListener("touchstart", v, X), function() {
      Z = Z.filter(function(d) {
        return d !== a;
      }), document.removeEventListener("wheel", p, X), document.removeEventListener("touchmove", p, X), document.removeEventListener("touchstart", v, X);
    };
  }, []);
  var h = e.removeScrollBar, E = e.inert;
  return c.createElement(
    c.Fragment,
    null,
    E ? c.createElement(a, { styles: sr(o) }) : null,
    h ? c.createElement(Jn, { noRelative: e.noRelative, gapMode: e.gapMode }) : null
  );
}
function dr(e) {
  for (var t = null; e !== null; )
    e instanceof ShadowRoot && (t = e.host, e = e.host), e = e.parentNode;
  return t;
}
const fr = Kn(gt, lr);
var Ne = c.forwardRef(function(e, t) {
  return c.createElement(ge, O({}, e, { ref: t, sideCar: fr }));
});
Ne.classNames = ge.classNames;
var vr = function(e) {
  if (typeof document > "u")
    return null;
  var t = Array.isArray(e) ? e[0] : e;
  return t.ownerDocument.body;
}, z = /* @__PURE__ */ new WeakMap(), le = /* @__PURE__ */ new WeakMap(), de = {}, Ie = 0, bt = function(e) {
  return e && (e.host || bt(e.parentNode));
}, pr = function(e, t) {
  return t.map(function(n) {
    if (e.contains(n))
      return n;
    var r = bt(n);
    return r && e.contains(r) ? r : (console.error("aria-hidden", n, "in not contained inside", e, ". Doing nothing"), null);
  }).filter(function(n) {
    return !!n;
  });
}, mr = function(e, t, n, r) {
  var o = pr(t, Array.isArray(e) ? e : [e]);
  de[n] || (de[n] = /* @__PURE__ */ new WeakMap());
  var a = de[n], s = [], i = /* @__PURE__ */ new Set(), p = new Set(o), f = function(u) {
    !u || i.has(u) || (i.add(u), f(u.parentNode));
  };
  o.forEach(f);
  var v = function(u) {
    !u || p.has(u) || Array.prototype.forEach.call(u.children, function(m) {
      if (i.has(m))
        v(m);
      else
        try {
          var h = m.getAttribute(r), E = h !== null && h !== "false", d = (z.get(m) || 0) + 1, g = (a.get(m) || 0) + 1;
          z.set(m, d), a.set(m, g), s.push(m), d === 1 && E && le.set(m, !0), g === 1 && m.setAttribute(n, "true"), E || m.setAttribute(r, "true");
        } catch (y) {
          console.error("aria-hidden: cannot operate on ", m, y);
        }
    });
  };
  return v(t), i.clear(), Ie++, function() {
    s.forEach(function(u) {
      var m = z.get(u) - 1, h = a.get(u) - 1;
      z.set(u, m), a.set(u, h), m || (le.has(u) || u.removeAttribute(r), le.delete(u)), h || u.removeAttribute(n);
    }), Ie--, Ie || (z = /* @__PURE__ */ new WeakMap(), z = /* @__PURE__ */ new WeakMap(), le = /* @__PURE__ */ new WeakMap(), de = {});
  };
}, xt = function(e, t, n) {
  n === void 0 && (n = "data-aria-hidden");
  var r = Array.from(Array.isArray(e) ? e : [e]), o = vr(e);
  return o ? (r.push.apply(r, Array.from(o.querySelectorAll("[aria-live], script"))), mr(r, o, n, "aria-hidden")) : function() {
    return null;
  };
};
// @__NO_SIDE_EFFECTS__
function hr(e) {
  const t = /* @__PURE__ */ gr(e), n = c.forwardRef((r, o) => {
    const { children: a, ...s } = r, i = c.Children.toArray(a), p = i.find(yr);
    if (p) {
      const f = p.props.children, v = i.map((u) => u === p ? c.Children.count(f) > 1 ? c.Children.only(null) : c.isValidElement(f) ? f.props.children : null : u);
      return /* @__PURE__ */ l.jsx(t, { ...s, ref: o, children: c.isValidElement(f) ? c.cloneElement(f, void 0, v) : null });
    }
    return /* @__PURE__ */ l.jsx(t, { ...s, ref: o, children: a });
  });
  return n.displayName = `${e}.Slot`, n;
}
// @__NO_SIDE_EFFECTS__
function gr(e) {
  const t = c.forwardRef((n, r) => {
    const { children: o, ...a } = n;
    if (c.isValidElement(o)) {
      const s = Sr(o), i = Er(a, o.props);
      return o.type !== c.Fragment && (i.ref = r ? Ae(r, s) : s), c.cloneElement(o, i);
    }
    return c.Children.count(o) > 1 ? c.Children.only(null) : null;
  });
  return t.displayName = `${e}.SlotClone`, t;
}
var Cr = Symbol("radix.slottable");
function yr(e) {
  return c.isValidElement(e) && typeof e.type == "function" && "__radixId" in e.type && e.type.__radixId === Cr;
}
function Er(e, t) {
  const n = { ...t };
  for (const r in t) {
    const o = e[r], a = t[r];
    /^on[A-Z]/.test(r) ? o && a ? n[r] = (...i) => {
      const p = a(...i);
      return o(...i), p;
    } : o && (n[r] = o) : r === "style" ? n[r] = { ...o, ...a } : r === "className" && (n[r] = [o, a].filter(Boolean).join(" "));
  }
  return { ...e, ...n };
}
function Sr(e) {
  var r, o;
  let t = (r = Object.getOwnPropertyDescriptor(e.props, "ref")) == null ? void 0 : r.get, n = t && "isReactWarning" in t && t.isReactWarning;
  return n ? e.ref : (t = (o = Object.getOwnPropertyDescriptor(e, "ref")) == null ? void 0 : o.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
var Ce = "Dialog", [wt] = it(Ce), [br, D] = wt(Ce), Rt = (e) => {
  const {
    __scopeDialog: t,
    children: n,
    open: r,
    defaultOpen: o,
    onOpenChange: a,
    modal: s = !0
  } = e, i = c.useRef(null), p = c.useRef(null), [f, v] = pn({
    prop: r,
    defaultProp: o ?? !1,
    onChange: a,
    caller: Ce
  });
  return /* @__PURE__ */ l.jsx(
    br,
    {
      scope: t,
      triggerRef: i,
      contentRef: p,
      contentId: ee(),
      titleId: ee(),
      descriptionId: ee(),
      open: f,
      onOpenChange: v,
      onOpenToggle: c.useCallback(() => v((u) => !u), [v]),
      modal: s,
      children: n
    }
  );
};
Rt.displayName = Ce;
var Mt = "DialogTrigger", _t = c.forwardRef(
  (e, t) => {
    const { __scopeDialog: n, ...r } = e, o = D(Mt, n), a = k(t, o.triggerRef);
    return /* @__PURE__ */ l.jsx(
      T.button,
      {
        type: "button",
        "aria-haspopup": "dialog",
        "aria-expanded": o.open,
        "aria-controls": o.contentId,
        "data-state": Fe(o.open),
        ...r,
        ref: a,
        onClick: x(e.onClick, o.onOpenToggle)
      }
    );
  }
);
_t.displayName = Mt;
var ke = "DialogPortal", [xr, Pt] = wt(ke, {
  forceMount: void 0
}), It = (e) => {
  const { __scopeDialog: t, forceMount: n, children: r, container: o } = e, a = D(ke, t);
  return /* @__PURE__ */ l.jsx(xr, { scope: t, forceMount: n, children: c.Children.map(r, (s) => /* @__PURE__ */ l.jsx(G, { present: n || a.open, children: /* @__PURE__ */ l.jsx(st, { asChild: !0, container: o, children: s }) })) });
};
It.displayName = ke;
var pe = "DialogOverlay", Tt = c.forwardRef(
  (e, t) => {
    const n = Pt(pe, e.__scopeDialog), { forceMount: r = n.forceMount, ...o } = e, a = D(pe, e.__scopeDialog);
    return a.modal ? /* @__PURE__ */ l.jsx(G, { present: r || a.open, children: /* @__PURE__ */ l.jsx(Rr, { ...o, ref: t }) }) : null;
  }
);
Tt.displayName = pe;
var wr = /* @__PURE__ */ hr("DialogOverlay.RemoveScroll"), Rr = c.forwardRef(
  (e, t) => {
    const { __scopeDialog: n, ...r } = e, o = D(pe, n);
    return (
      // Make sure `Content` is scrollable even when it doesn't live inside `RemoveScroll`
      // ie. when `Overlay` and `Content` are siblings
      /* @__PURE__ */ l.jsx(Ne, { as: wr, allowPinchZoom: !0, shards: [o.contentRef], children: /* @__PURE__ */ l.jsx(
        T.div,
        {
          "data-state": Fe(o.open),
          ...r,
          ref: t,
          style: { pointerEvents: "auto", ...r.style }
        }
      ) })
    );
  }
), K = "DialogContent", Dt = c.forwardRef(
  (e, t) => {
    const n = Pt(K, e.__scopeDialog), { forceMount: r = n.forceMount, ...o } = e, a = D(K, e.__scopeDialog);
    return /* @__PURE__ */ l.jsx(G, { present: r || a.open, children: a.modal ? /* @__PURE__ */ l.jsx(Mr, { ...o, ref: t }) : /* @__PURE__ */ l.jsx(_r, { ...o, ref: t }) });
  }
);
Dt.displayName = K;
var Mr = c.forwardRef(
  (e, t) => {
    const n = D(K, e.__scopeDialog), r = c.useRef(null), o = k(t, n.contentRef, r);
    return c.useEffect(() => {
      const a = r.current;
      if (a) return xt(a);
    }, []), /* @__PURE__ */ l.jsx(
      At,
      {
        ...e,
        ref: o,
        trapFocus: n.open,
        disableOutsidePointerEvents: !0,
        onCloseAutoFocus: x(e.onCloseAutoFocus, (a) => {
          var s;
          a.preventDefault(), (s = n.triggerRef.current) == null || s.focus();
        }),
        onPointerDownOutside: x(e.onPointerDownOutside, (a) => {
          const s = a.detail.originalEvent, i = s.button === 0 && s.ctrlKey === !0;
          (s.button === 2 || i) && a.preventDefault();
        }),
        onFocusOutside: x(
          e.onFocusOutside,
          (a) => a.preventDefault()
        )
      }
    );
  }
), _r = c.forwardRef(
  (e, t) => {
    const n = D(K, e.__scopeDialog), r = c.useRef(!1), o = c.useRef(!1);
    return /* @__PURE__ */ l.jsx(
      At,
      {
        ...e,
        ref: t,
        trapFocus: !1,
        disableOutsidePointerEvents: !1,
        onCloseAutoFocus: (a) => {
          var s, i;
          (s = e.onCloseAutoFocus) == null || s.call(e, a), a.defaultPrevented || (r.current || (i = n.triggerRef.current) == null || i.focus(), a.preventDefault()), r.current = !1, o.current = !1;
        },
        onInteractOutside: (a) => {
          var p, f;
          (p = e.onInteractOutside) == null || p.call(e, a), a.defaultPrevented || (r.current = !0, a.detail.originalEvent.type === "pointerdown" && (o.current = !0));
          const s = a.target;
          ((f = n.triggerRef.current) == null ? void 0 : f.contains(s)) && a.preventDefault(), a.detail.originalEvent.type === "focusin" && o.current && a.preventDefault();
        }
      }
    );
  }
), At = c.forwardRef(
  (e, t) => {
    const { __scopeDialog: n, trapFocus: r, onOpenAutoFocus: o, onCloseAutoFocus: a, ...s } = e, i = D(K, n), p = c.useRef(null), f = k(t, p);
    return pt(), /* @__PURE__ */ l.jsxs(l.Fragment, { children: [
      /* @__PURE__ */ l.jsx(
        Oe,
        {
          asChild: !0,
          loop: !0,
          trapped: r,
          onMountAutoFocus: o,
          onUnmountAutoFocus: a,
          children: /* @__PURE__ */ l.jsx(
            ut,
            {
              role: "dialog",
              id: i.contentId,
              "aria-describedby": i.descriptionId,
              "aria-labelledby": i.titleId,
              "data-state": Fe(i.open),
              ...s,
              ref: f,
              onDismiss: () => i.onOpenChange(!1)
            }
          )
        }
      ),
      /* @__PURE__ */ l.jsxs(l.Fragment, { children: [
        /* @__PURE__ */ l.jsx(Pr, { titleId: i.titleId }),
        /* @__PURE__ */ l.jsx(Tr, { contentRef: p, descriptionId: i.descriptionId })
      ] })
    ] });
  }
), je = "DialogTitle", Ot = c.forwardRef(
  (e, t) => {
    const { __scopeDialog: n, ...r } = e, o = D(je, n);
    return /* @__PURE__ */ l.jsx(T.h2, { id: o.titleId, ...r, ref: t });
  }
);
Ot.displayName = je;
var Nt = "DialogDescription", kt = c.forwardRef(
  (e, t) => {
    const { __scopeDialog: n, ...r } = e, o = D(Nt, n);
    return /* @__PURE__ */ l.jsx(T.p, { id: o.descriptionId, ...r, ref: t });
  }
);
kt.displayName = Nt;
var jt = "DialogClose", Ft = c.forwardRef(
  (e, t) => {
    const { __scopeDialog: n, ...r } = e, o = D(jt, n);
    return /* @__PURE__ */ l.jsx(
      T.button,
      {
        type: "button",
        ...r,
        ref: t,
        onClick: x(e.onClick, () => o.onOpenChange(!1))
      }
    );
  }
);
Ft.displayName = jt;
function Fe(e) {
  return e ? "open" : "closed";
}
var Lt = "DialogTitleWarning", [po, Wt] = mn(Lt, {
  contentName: K,
  titleName: je,
  docsSlug: "dialog"
}), Pr = ({ titleId: e }) => {
  const t = Wt(Lt), n = `\`${t.contentName}\` requires a \`${t.titleName}\` for the component to be accessible for screen reader users.

If you want to hide the \`${t.titleName}\`, you can wrap it with our VisuallyHidden component.

For more information, see https://radix-ui.com/primitives/docs/components/${t.docsSlug}`;
  return c.useEffect(() => {
    e && (document.getElementById(e) || console.error(n));
  }, [n, e]), null;
}, Ir = "DialogDescriptionWarning", Tr = ({ contentRef: e, descriptionId: t }) => {
  const r = `Warning: Missing \`Description\` or \`aria-describedby={undefined}\` for {${Wt(Ir).contentName}}.`;
  return c.useEffect(() => {
    var a;
    const o = (a = e.current) == null ? void 0 : a.getAttribute("aria-describedby");
    t && o && (document.getElementById(t) || console.warn(r));
  }, [r, e, t]), null;
}, mo = Rt, ho = _t, go = It, Co = Tt, yo = Dt, Eo = Ot, So = kt, bo = Ft;
// @__NO_SIDE_EFFECTS__
function Dr(e) {
  const t = /* @__PURE__ */ Ar(e), n = c.forwardRef((r, o) => {
    const { children: a, ...s } = r, i = c.Children.toArray(a), p = i.find(Nr);
    if (p) {
      const f = p.props.children, v = i.map((u) => u === p ? c.Children.count(f) > 1 ? c.Children.only(null) : c.isValidElement(f) ? f.props.children : null : u);
      return /* @__PURE__ */ l.jsx(t, { ...s, ref: o, children: c.isValidElement(f) ? c.cloneElement(f, void 0, v) : null });
    }
    return /* @__PURE__ */ l.jsx(t, { ...s, ref: o, children: a });
  });
  return n.displayName = `${e}.Slot`, n;
}
// @__NO_SIDE_EFFECTS__
function Ar(e) {
  const t = c.forwardRef((n, r) => {
    const { children: o, ...a } = n;
    if (c.isValidElement(o)) {
      const s = jr(o), i = kr(a, o.props);
      return o.type !== c.Fragment && (i.ref = r ? Ae(r, s) : s), c.cloneElement(o, i);
    }
    return c.Children.count(o) > 1 ? c.Children.only(null) : null;
  });
  return t.displayName = `${e}.SlotClone`, t;
}
var Or = Symbol("radix.slottable");
function Nr(e) {
  return c.isValidElement(e) && typeof e.type == "function" && "__radixId" in e.type && e.type.__radixId === Or;
}
function kr(e, t) {
  const n = { ...t };
  for (const r in t) {
    const o = e[r], a = t[r];
    /^on[A-Z]/.test(r) ? o && a ? n[r] = (...i) => {
      const p = a(...i);
      return o(...i), p;
    } : o && (n[r] = o) : r === "style" ? n[r] = { ...o, ...a } : r === "className" && (n[r] = [o, a].filter(Boolean).join(" "));
  }
  return { ...e, ...n };
}
function jr(e) {
  var r, o;
  let t = (r = Object.getOwnPropertyDescriptor(e.props, "ref")) == null ? void 0 : r.get, n = t && "isReactWarning" in t && t.isReactWarning;
  return n ? e.ref : (t = (o = Object.getOwnPropertyDescriptor(e, "ref")) == null ? void 0 : o.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
var De = ["Enter", " "], Fr = ["ArrowDown", "PageUp", "Home"], Kt = ["ArrowUp", "PageDown", "End"], Lr = [...Fr, ...Kt], Wr = {
  ltr: [...De, "ArrowRight"],
  rtl: [...De, "ArrowLeft"]
}, Kr = {
  ltr: ["ArrowLeft"],
  rtl: ["ArrowRight"]
}, oe = "Menu", [ne, Gr, Br] = hn(oe), [B, xo] = it(oe, [
  Br,
  lt,
  dt
]), ae = lt(), Gt = dt(), [Bt, W] = B(oe), [Vr, ce] = B(oe), Vt = (e) => {
  const { __scopeMenu: t, open: n = !1, children: r, dir: o, onOpenChange: a, modal: s = !0 } = e, i = ae(t), [p, f] = c.useState(null), v = c.useRef(!1), u = te(a), m = Cn(o);
  return c.useEffect(() => {
    const h = () => {
      v.current = !0, document.addEventListener("pointerdown", E, { capture: !0, once: !0 }), document.addEventListener("pointermove", E, { capture: !0, once: !0 });
    }, E = () => v.current = !1;
    return document.addEventListener("keydown", h, { capture: !0 }), () => {
      document.removeEventListener("keydown", h, { capture: !0 }), document.removeEventListener("pointerdown", E, { capture: !0 }), document.removeEventListener("pointermove", E, { capture: !0 });
    };
  }, []), /* @__PURE__ */ l.jsx(ft, { ...i, children: /* @__PURE__ */ l.jsx(
    Bt,
    {
      scope: t,
      open: n,
      onOpenChange: u,
      content: p,
      onContentChange: f,
      children: /* @__PURE__ */ l.jsx(
        Vr,
        {
          scope: t,
          onClose: c.useCallback(() => u(!1), [u]),
          isUsingKeyboardRef: v,
          dir: m,
          modal: s,
          children: r
        }
      )
    }
  ) });
};
Vt.displayName = oe;
var Ur = "MenuAnchor", Le = c.forwardRef(
  (e, t) => {
    const { __scopeMenu: n, ...r } = e, o = ae(n);
    return /* @__PURE__ */ l.jsx(gn, { ...o, ...r, ref: t });
  }
);
Le.displayName = Ur;
var We = "MenuPortal", [$r, Ut] = B(We, {
  forceMount: void 0
}), $t = (e) => {
  const { __scopeMenu: t, forceMount: n, children: r, container: o } = e, a = W(We, t);
  return /* @__PURE__ */ l.jsx($r, { scope: t, forceMount: n, children: /* @__PURE__ */ l.jsx(G, { present: n || a.open, children: /* @__PURE__ */ l.jsx(st, { asChild: !0, container: o, children: r }) }) });
};
$t.displayName = We;
var P = "MenuContent", [Hr, Ke] = B(P), Ht = c.forwardRef(
  (e, t) => {
    const n = Ut(P, e.__scopeMenu), { forceMount: r = n.forceMount, ...o } = e, a = W(P, e.__scopeMenu), s = ce(P, e.__scopeMenu);
    return /* @__PURE__ */ l.jsx(ne.Provider, { scope: e.__scopeMenu, children: /* @__PURE__ */ l.jsx(G, { present: r || a.open, children: /* @__PURE__ */ l.jsx(ne.Slot, { scope: e.__scopeMenu, children: s.modal ? /* @__PURE__ */ l.jsx(Yr, { ...o, ref: t }) : /* @__PURE__ */ l.jsx(Xr, { ...o, ref: t }) }) }) });
  }
), Yr = c.forwardRef(
  (e, t) => {
    const n = W(P, e.__scopeMenu), r = c.useRef(null), o = k(t, r);
    return c.useEffect(() => {
      const a = r.current;
      if (a) return xt(a);
    }, []), /* @__PURE__ */ l.jsx(
      Ge,
      {
        ...e,
        ref: o,
        trapFocus: n.open,
        disableOutsidePointerEvents: n.open,
        disableOutsideScroll: !0,
        onFocusOutside: x(
          e.onFocusOutside,
          (a) => a.preventDefault(),
          { checkForDefaultPrevented: !1 }
        ),
        onDismiss: () => n.onOpenChange(!1)
      }
    );
  }
), Xr = c.forwardRef((e, t) => {
  const n = W(P, e.__scopeMenu);
  return /* @__PURE__ */ l.jsx(
    Ge,
    {
      ...e,
      ref: t,
      trapFocus: !1,
      disableOutsidePointerEvents: !1,
      disableOutsideScroll: !1,
      onDismiss: () => n.onOpenChange(!1)
    }
  );
}), Zr = /* @__PURE__ */ Dr("MenuContent.ScrollLock"), Ge = c.forwardRef(
  (e, t) => {
    const {
      __scopeMenu: n,
      loop: r = !1,
      trapFocus: o,
      onOpenAutoFocus: a,
      onCloseAutoFocus: s,
      disableOutsidePointerEvents: i,
      onEntryFocus: p,
      onEscapeKeyDown: f,
      onPointerDownOutside: v,
      onFocusOutside: u,
      onInteractOutside: m,
      onDismiss: h,
      disableOutsideScroll: E,
      ...d
    } = e, g = W(P, n), y = ce(P, n), S = ae(n), b = Gt(n), w = Gr(n), [R, I] = c.useState(null), M = c.useRef(null), ie = k(t, M, g.onContentChange), j = c.useRef(0), V = c.useRef(""), U = c.useRef(0), $ = c.useRef(null), He = c.useRef("right"), Ee = c.useRef(0), dn = E ? Ne : c.Fragment, fn = E ? { as: Zr, allowPinchZoom: !0 } : void 0, vn = (C) => {
      var Y, Xe;
      const _ = V.current + C, A = w().filter((N) => !N.disabled), F = document.activeElement, Se = (Y = A.find((N) => N.ref.current === F)) == null ? void 0 : Y.textValue, be = A.map((N) => N.textValue), Ye = io(be, _, Se), Q = (Xe = A.find((N) => N.textValue === Ye)) == null ? void 0 : Xe.ref.current;
      (function N(Ze) {
        V.current = Ze, window.clearTimeout(j.current), Ze !== "" && (j.current = window.setTimeout(() => N(""), 1e3));
      })(_), Q && setTimeout(() => Q.focus());
    };
    c.useEffect(() => () => window.clearTimeout(j.current), []), pt();
    const H = c.useCallback((C) => {
      var A, F;
      return He.current === ((A = $.current) == null ? void 0 : A.side) && uo(C, (F = $.current) == null ? void 0 : F.area);
    }, []);
    return /* @__PURE__ */ l.jsx(
      Hr,
      {
        scope: n,
        searchRef: V,
        onItemEnter: c.useCallback(
          (C) => {
            H(C) && C.preventDefault();
          },
          [H]
        ),
        onItemLeave: c.useCallback(
          (C) => {
            var _;
            H(C) || ((_ = M.current) == null || _.focus(), I(null));
          },
          [H]
        ),
        onTriggerLeave: c.useCallback(
          (C) => {
            H(C) && C.preventDefault();
          },
          [H]
        ),
        pointerGraceTimerRef: U,
        onPointerGraceIntentChange: c.useCallback((C) => {
          $.current = C;
        }, []),
        children: /* @__PURE__ */ l.jsx(dn, { ...fn, children: /* @__PURE__ */ l.jsx(
          Oe,
          {
            asChild: !0,
            trapped: o,
            onMountAutoFocus: x(a, (C) => {
              var _;
              C.preventDefault(), (_ = M.current) == null || _.focus({ preventScroll: !0 });
            }),
            onUnmountAutoFocus: s,
            children: /* @__PURE__ */ l.jsx(
              ut,
              {
                asChild: !0,
                disableOutsidePointerEvents: i,
                onEscapeKeyDown: f,
                onPointerDownOutside: v,
                onFocusOutside: u,
                onInteractOutside: m,
                onDismiss: h,
                children: /* @__PURE__ */ l.jsx(
                  yn,
                  {
                    asChild: !0,
                    ...b,
                    dir: y.dir,
                    orientation: "vertical",
                    loop: r,
                    currentTabStopId: R,
                    onCurrentTabStopIdChange: I,
                    onEntryFocus: x(p, (C) => {
                      y.isUsingKeyboardRef.current || C.preventDefault();
                    }),
                    preventScrollOnEntryFocus: !0,
                    children: /* @__PURE__ */ l.jsx(
                      En,
                      {
                        role: "menu",
                        "aria-orientation": "vertical",
                        "data-state": ln(g.open),
                        "data-radix-menu-content": "",
                        dir: y.dir,
                        ...S,
                        ...d,
                        ref: ie,
                        style: { outline: "none", ...d.style },
                        onKeyDown: x(d.onKeyDown, (C) => {
                          const A = C.target.closest("[data-radix-menu-content]") === C.currentTarget, F = C.ctrlKey || C.altKey || C.metaKey, Se = C.key.length === 1;
                          A && (C.key === "Tab" && C.preventDefault(), !F && Se && vn(C.key));
                          const be = M.current;
                          if (C.target !== be || !Lr.includes(C.key)) return;
                          C.preventDefault();
                          const Q = w().filter((Y) => !Y.disabled).map((Y) => Y.ref.current);
                          Kt.includes(C.key) && Q.reverse(), ao(Q);
                        }),
                        onBlur: x(e.onBlur, (C) => {
                          C.currentTarget.contains(C.target) || (window.clearTimeout(j.current), V.current = "");
                        }),
                        onPointerMove: x(
                          e.onPointerMove,
                          re((C) => {
                            const _ = C.target, A = Ee.current !== C.clientX;
                            if (C.currentTarget.contains(_) && A) {
                              const F = C.clientX > Ee.current ? "right" : "left";
                              He.current = F, Ee.current = C.clientX;
                            }
                          })
                        )
                      }
                    )
                  }
                )
              }
            )
          }
        ) })
      }
    );
  }
);
Ht.displayName = P;
var zr = "MenuGroup", Be = c.forwardRef(
  (e, t) => {
    const { __scopeMenu: n, ...r } = e;
    return /* @__PURE__ */ l.jsx(T.div, { role: "group", ...r, ref: t });
  }
);
Be.displayName = zr;
var qr = "MenuLabel", Yt = c.forwardRef(
  (e, t) => {
    const { __scopeMenu: n, ...r } = e;
    return /* @__PURE__ */ l.jsx(T.div, { ...r, ref: t });
  }
);
Yt.displayName = qr;
var me = "MenuItem", ct = "menu.itemSelect", ye = c.forwardRef(
  (e, t) => {
    const { disabled: n = !1, onSelect: r, ...o } = e, a = c.useRef(null), s = ce(me, e.__scopeMenu), i = Ke(me, e.__scopeMenu), p = k(t, a), f = c.useRef(!1), v = () => {
      const u = a.current;
      if (!n && u) {
        const m = new CustomEvent(ct, { bubbles: !0, cancelable: !0 });
        u.addEventListener(ct, (h) => r == null ? void 0 : r(h), { once: !0 }), bn(u, m), m.defaultPrevented ? f.current = !1 : s.onClose();
      }
    };
    return /* @__PURE__ */ l.jsx(
      Xt,
      {
        ...o,
        ref: p,
        disabled: n,
        onClick: x(e.onClick, v),
        onPointerDown: (u) => {
          var m;
          (m = e.onPointerDown) == null || m.call(e, u), f.current = !0;
        },
        onPointerUp: x(e.onPointerUp, (u) => {
          var m;
          f.current || (m = u.currentTarget) == null || m.click();
        }),
        onKeyDown: x(e.onKeyDown, (u) => {
          const m = i.searchRef.current !== "";
          n || m && u.key === " " || De.includes(u.key) && (u.currentTarget.click(), u.preventDefault());
        })
      }
    );
  }
);
ye.displayName = me;
var Xt = c.forwardRef(
  (e, t) => {
    const { __scopeMenu: n, disabled: r = !1, textValue: o, ...a } = e, s = Ke(me, n), i = Gt(n), p = c.useRef(null), f = k(t, p), [v, u] = c.useState(!1), [m, h] = c.useState("");
    return c.useEffect(() => {
      const E = p.current;
      E && h((E.textContent ?? "").trim());
    }, [a.children]), /* @__PURE__ */ l.jsx(
      ne.ItemSlot,
      {
        scope: n,
        disabled: r,
        textValue: o ?? m,
        children: /* @__PURE__ */ l.jsx(Sn, { asChild: !0, ...i, focusable: !r, children: /* @__PURE__ */ l.jsx(
          T.div,
          {
            role: "menuitem",
            "data-highlighted": v ? "" : void 0,
            "aria-disabled": r || void 0,
            "data-disabled": r ? "" : void 0,
            ...a,
            ref: f,
            onPointerMove: x(
              e.onPointerMove,
              re((E) => {
                r ? s.onItemLeave(E) : (s.onItemEnter(E), E.defaultPrevented || E.currentTarget.focus({ preventScroll: !0 }));
              })
            ),
            onPointerLeave: x(
              e.onPointerLeave,
              re((E) => s.onItemLeave(E))
            ),
            onFocus: x(e.onFocus, () => u(!0)),
            onBlur: x(e.onBlur, () => u(!1))
          }
        ) })
      }
    );
  }
), Qr = "MenuCheckboxItem", Zt = c.forwardRef(
  (e, t) => {
    const { checked: n = !1, onCheckedChange: r, ...o } = e;
    return /* @__PURE__ */ l.jsx(en, { scope: e.__scopeMenu, checked: n, children: /* @__PURE__ */ l.jsx(
      ye,
      {
        role: "menuitemcheckbox",
        "aria-checked": he(n) ? "mixed" : n,
        ...o,
        ref: t,
        "data-state": $e(n),
        onSelect: x(
          o.onSelect,
          () => r == null ? void 0 : r(he(n) ? !0 : !n),
          { checkForDefaultPrevented: !1 }
        )
      }
    ) });
  }
);
Zt.displayName = Qr;
var zt = "MenuRadioGroup", [Jr, eo] = B(
  zt,
  { value: void 0, onValueChange: () => {
  } }
), qt = c.forwardRef(
  (e, t) => {
    const { value: n, onValueChange: r, ...o } = e, a = te(r);
    return /* @__PURE__ */ l.jsx(Jr, { scope: e.__scopeMenu, value: n, onValueChange: a, children: /* @__PURE__ */ l.jsx(Be, { ...o, ref: t }) });
  }
);
qt.displayName = zt;
var Qt = "MenuRadioItem", Jt = c.forwardRef(
  (e, t) => {
    const { value: n, ...r } = e, o = eo(Qt, e.__scopeMenu), a = n === o.value;
    return /* @__PURE__ */ l.jsx(en, { scope: e.__scopeMenu, checked: a, children: /* @__PURE__ */ l.jsx(
      ye,
      {
        role: "menuitemradio",
        "aria-checked": a,
        ...r,
        ref: t,
        "data-state": $e(a),
        onSelect: x(
          r.onSelect,
          () => {
            var s;
            return (s = o.onValueChange) == null ? void 0 : s.call(o, n);
          },
          { checkForDefaultPrevented: !1 }
        )
      }
    ) });
  }
);
Jt.displayName = Qt;
var Ve = "MenuItemIndicator", [en, to] = B(
  Ve,
  { checked: !1 }
), tn = c.forwardRef(
  (e, t) => {
    const { __scopeMenu: n, forceMount: r, ...o } = e, a = to(Ve, n);
    return /* @__PURE__ */ l.jsx(
      G,
      {
        present: r || he(a.checked) || a.checked === !0,
        children: /* @__PURE__ */ l.jsx(
          T.span,
          {
            ...o,
            ref: t,
            "data-state": $e(a.checked)
          }
        )
      }
    );
  }
);
tn.displayName = Ve;
var no = "MenuSeparator", nn = c.forwardRef(
  (e, t) => {
    const { __scopeMenu: n, ...r } = e;
    return /* @__PURE__ */ l.jsx(
      T.div,
      {
        role: "separator",
        "aria-orientation": "horizontal",
        ...r,
        ref: t
      }
    );
  }
);
nn.displayName = no;
var ro = "MenuArrow", rn = c.forwardRef(
  (e, t) => {
    const { __scopeMenu: n, ...r } = e, o = ae(n);
    return /* @__PURE__ */ l.jsx(xn, { ...o, ...r, ref: t });
  }
);
rn.displayName = ro;
var Ue = "MenuSub", [oo, on] = B(Ue), an = (e) => {
  const { __scopeMenu: t, children: n, open: r = !1, onOpenChange: o } = e, a = W(Ue, t), s = ae(t), [i, p] = c.useState(null), [f, v] = c.useState(null), u = te(o);
  return c.useEffect(() => (a.open === !1 && u(!1), () => u(!1)), [a.open, u]), /* @__PURE__ */ l.jsx(ft, { ...s, children: /* @__PURE__ */ l.jsx(
    Bt,
    {
      scope: t,
      open: r,
      onOpenChange: u,
      content: f,
      onContentChange: v,
      children: /* @__PURE__ */ l.jsx(
        oo,
        {
          scope: t,
          contentId: ee(),
          triggerId: ee(),
          trigger: i,
          onTriggerChange: p,
          children: n
        }
      )
    }
  ) });
};
an.displayName = Ue;
var J = "MenuSubTrigger", cn = c.forwardRef(
  (e, t) => {
    const n = W(J, e.__scopeMenu), r = ce(J, e.__scopeMenu), o = on(J, e.__scopeMenu), a = Ke(J, e.__scopeMenu), s = c.useRef(null), { pointerGraceTimerRef: i, onPointerGraceIntentChange: p } = a, f = { __scopeMenu: e.__scopeMenu }, v = c.useCallback(() => {
      s.current && window.clearTimeout(s.current), s.current = null;
    }, []);
    return c.useEffect(() => v, [v]), c.useEffect(() => {
      const u = i.current;
      return () => {
        window.clearTimeout(u), p(null);
      };
    }, [i, p]), /* @__PURE__ */ l.jsx(Le, { asChild: !0, ...f, children: /* @__PURE__ */ l.jsx(
      Xt,
      {
        id: o.triggerId,
        "aria-haspopup": "menu",
        "aria-expanded": n.open,
        "aria-controls": o.contentId,
        "data-state": ln(n.open),
        ...e,
        ref: Ae(t, o.onTriggerChange),
        onClick: (u) => {
          var m;
          (m = e.onClick) == null || m.call(e, u), !(e.disabled || u.defaultPrevented) && (u.currentTarget.focus(), n.open || n.onOpenChange(!0));
        },
        onPointerMove: x(
          e.onPointerMove,
          re((u) => {
            a.onItemEnter(u), !u.defaultPrevented && !e.disabled && !n.open && !s.current && (a.onPointerGraceIntentChange(null), s.current = window.setTimeout(() => {
              n.onOpenChange(!0), v();
            }, 100));
          })
        ),
        onPointerLeave: x(
          e.onPointerLeave,
          re((u) => {
            var h, E;
            v();
            const m = (h = n.content) == null ? void 0 : h.getBoundingClientRect();
            if (m) {
              const d = (E = n.content) == null ? void 0 : E.dataset.side, g = d === "right", y = g ? -5 : 5, S = m[g ? "left" : "right"], b = m[g ? "right" : "left"];
              a.onPointerGraceIntentChange({
                area: [
                  // Apply a bleed on clientX to ensure that our exit point is
                  // consistently within polygon bounds
                  { x: u.clientX + y, y: u.clientY },
                  { x: S, y: m.top },
                  { x: b, y: m.top },
                  { x: b, y: m.bottom },
                  { x: S, y: m.bottom }
                ],
                side: d
              }), window.clearTimeout(i.current), i.current = window.setTimeout(
                () => a.onPointerGraceIntentChange(null),
                300
              );
            } else {
              if (a.onTriggerLeave(u), u.defaultPrevented) return;
              a.onPointerGraceIntentChange(null);
            }
          })
        ),
        onKeyDown: x(e.onKeyDown, (u) => {
          var h;
          const m = a.searchRef.current !== "";
          e.disabled || m && u.key === " " || Wr[r.dir].includes(u.key) && (n.onOpenChange(!0), (h = n.content) == null || h.focus(), u.preventDefault());
        })
      }
    ) });
  }
);
cn.displayName = J;
var sn = "MenuSubContent", un = c.forwardRef(
  (e, t) => {
    const n = Ut(P, e.__scopeMenu), { forceMount: r = n.forceMount, ...o } = e, a = W(P, e.__scopeMenu), s = ce(P, e.__scopeMenu), i = on(sn, e.__scopeMenu), p = c.useRef(null), f = k(t, p);
    return /* @__PURE__ */ l.jsx(ne.Provider, { scope: e.__scopeMenu, children: /* @__PURE__ */ l.jsx(G, { present: r || a.open, children: /* @__PURE__ */ l.jsx(ne.Slot, { scope: e.__scopeMenu, children: /* @__PURE__ */ l.jsx(
      Ge,
      {
        id: i.contentId,
        "aria-labelledby": i.triggerId,
        ...o,
        ref: f,
        align: "start",
        side: s.dir === "rtl" ? "left" : "right",
        disableOutsidePointerEvents: !1,
        disableOutsideScroll: !1,
        trapFocus: !1,
        onOpenAutoFocus: (v) => {
          var u;
          s.isUsingKeyboardRef.current && ((u = p.current) == null || u.focus()), v.preventDefault();
        },
        onCloseAutoFocus: (v) => v.preventDefault(),
        onFocusOutside: x(e.onFocusOutside, (v) => {
          v.target !== i.trigger && a.onOpenChange(!1);
        }),
        onEscapeKeyDown: x(e.onEscapeKeyDown, (v) => {
          s.onClose(), v.preventDefault();
        }),
        onKeyDown: x(e.onKeyDown, (v) => {
          var h;
          const u = v.currentTarget.contains(v.target), m = Kr[s.dir].includes(v.key);
          u && m && (a.onOpenChange(!1), (h = i.trigger) == null || h.focus(), v.preventDefault());
        })
      }
    ) }) }) });
  }
);
un.displayName = sn;
function ln(e) {
  return e ? "open" : "closed";
}
function he(e) {
  return e === "indeterminate";
}
function $e(e) {
  return he(e) ? "indeterminate" : e ? "checked" : "unchecked";
}
function ao(e) {
  const t = document.activeElement;
  for (const n of e)
    if (n === t || (n.focus(), document.activeElement !== t)) return;
}
function co(e, t) {
  return e.map((n, r) => e[(t + r) % e.length]);
}
function io(e, t, n) {
  const o = t.length > 1 && Array.from(t).every((f) => f === t[0]) ? t[0] : t, a = n ? e.indexOf(n) : -1;
  let s = co(e, Math.max(a, 0));
  o.length === 1 && (s = s.filter((f) => f !== n));
  const p = s.find(
    (f) => f.toLowerCase().startsWith(o.toLowerCase())
  );
  return p !== n ? p : void 0;
}
function so(e, t) {
  const { x: n, y: r } = e;
  let o = !1;
  for (let a = 0, s = t.length - 1; a < t.length; s = a++) {
    const i = t[a], p = t[s], f = i.x, v = i.y, u = p.x, m = p.y;
    v > r != m > r && n < (u - f) * (r - v) / (m - v) + f && (o = !o);
  }
  return o;
}
function uo(e, t) {
  if (!t) return !1;
  const n = { x: e.clientX, y: e.clientY };
  return so(n, t);
}
function re(e) {
  return (t) => t.pointerType === "mouse" ? e(t) : void 0;
}
var wo = Vt, Ro = Le, Mo = $t, _o = Ht, Po = Be, Io = Yt, To = ye, Do = Zt, Ao = qt, Oo = Jt, No = tn, ko = nn, jo = rn, Fo = an, Lo = cn, Wo = un;
export {
  Ro as A,
  yo as C,
  So as D,
  Oe as F,
  Po as G,
  No as I,
  Io as L,
  Co as O,
  go as P,
  mo as R,
  Wo as S,
  Eo as T,
  Mo as a,
  Lo as b,
  xo as c,
  Fo as d,
  Oo as e,
  Ao as f,
  Do as g,
  ko as h,
  To as i,
  _o as j,
  wo as k,
  jo as l,
  xt as m,
  Ne as n,
  bo as o,
  ho as p,
  pt as u
};
