"""Unit tests for Refast."""
