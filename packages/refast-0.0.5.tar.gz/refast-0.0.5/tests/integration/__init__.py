"""Integration tests for Refast."""
