"""Core components for Praval framework."""
