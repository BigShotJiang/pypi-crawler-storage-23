import os
import ast
import xarray as xr
import numpy as np
import pandas as pd
import concurrent.futures
import logging
import matplotlib.pyplot as plt
from io import BytesIO
from PIL import Image

logger = logging.getLogger(__name__)


class XPlotter:
    def __init__(self, data, **kwargs):
        """
        Initialize the xarray processor.

        Parameters:
        - data: xarray Dataset, xarray DataArray, or string path to netCDF file.
        - kwargs: Additional configuration parameters.
        """
        self.data = self.validate_data_type(data)
        self.style = None
        for key, value in kwargs.items():
            setattr(self, key, value)

    def kwargs_from_column(self, data, column, arg_name='linestyle', mapping=None, default=None):
        """
        Build keyword arguments for ``matplotlib.pyplot.plot`` based on values in a data column.

        This helper inspects the provided data structure (xarray Dataset/DataArray or
        pandas DataFrame/Series) and extracts the values contained in ``column``.
        It then optionally maps those values through ``mapping`` and returns a dictionary
        suitable for unpacking directly into a ``plt.plot`` call.

        Example::

            # data is a pandas DataFrame with a "category" column
            kwargs = xp.kwargs_from_column(data, 'category', arg_name='linestyle',
                                           mapping={'A':'--', 'B':'-.'})
            plt.plot(x, y, **kwargs)

        Parameters:
        - data: xarray.Dataset, xarray.DataArray, pandas.DataFrame/Series.
        - column: name of the variable/column containing styling information.
        - arg_name: the matplotlib argument to populate (``linestyle``, ``color``, etc.).
        - mapping: optional dict mapping original values to argument values; if
          omitted, a default mapping will be generated automatically.  The default
          is created by cycling through a small palette appropriate for the
          requested ``arg_name`` (e.g. standard linestyles for ``linestyle`` or
          colors from the current seaborn palette for ``color``).
        - default: value to use when a key is missing from ``mapping``; if ``None`` the
          original value is used.

        Returns:
        - dict with a single key ``arg_name`` mapping to a list/array of values.
        """
        # convert xarray to pandas if necessary
        if isinstance(data, xr.Dataset):
            if column not in data.data_vars and column not in data.coords:
                raise KeyError(f"Column '{column}' not found in Dataset")
            series = data[column].to_series()
        elif isinstance(data, xr.DataArray):
            # convert coordinates or data to series
            if column in data.coords:
                series = data.coords[column].to_series()
            else:
                try:
                    df = data.to_dataframe().reset_index()
                    series = df[column]
                except Exception:
                    raise KeyError(f"Column '{column}' not available in DataArray")
        elif isinstance(data, pd.DataFrame):
            if column not in data.columns:
                raise KeyError(f"Column '{column}' not found in DataFrame")
            series = data[column]
        elif isinstance(data, pd.Series):
            if data.name != column:
                raise KeyError(f"Series name '{data.name}' does not match '{column}'")
            series = data
        else:
            raise TypeError(f"Unsupported data type: {type(data)}")

        unique_vals = list(pd.unique(series.values))

        # create a default mapping if none provided
        if mapping is None:
            mapping = {}
            if arg_name == 'linestyle':
                styles = ['-', '--', '-.', ':']
            elif arg_name == 'marker':
                styles = ['o', 's', '^', 'D', 'x', '+']
            elif arg_name == 'alpha':
                styles = [1.0, 0.75, 0.5, 0.25]
            elif arg_name == 'linewidth':
                styles = [1, 2, 3, 4]
            elif arg_name == 'color':
                # use matplotlib's default color cycle
                cycle = plt.rcParams['axes.prop_cycle'].by_key().get('color', [])
                # repeat cycle to match number of unique values
                styles = [cycle[i % len(cycle)] for i in range(len(unique_vals))]
            else:
                # fallback to cycling the unique values themselves
                styles = unique_vals

            for i, val in enumerate(unique_vals):
                mapping[val] = styles[i % len(styles)]

        values = list(series.values)
        values = [mapping.get(v, default if default is not None else v) for v in values]

        return {arg_name: values}
    
    @staticmethod
    def validate_data_type(data):
        """
        Check data type.
        Allowed types are: str (path to netCDF file), xarray.Dataset, or xarray.DataArray
        """
        if isinstance(data, (xr.Dataset, xr.DataArray)):
            return data
        elif isinstance(data, pd.DataFrame):
            data = data.to_xarray()
            return data
        elif isinstance(data, str) and os.path.exists(data):
            try:
                data = xr.open_dataset(data)
                return data
            except Exception as e0:
                try:
                    data = pd.read_csv(data)
                    data = data.to_xarray()
                    return data
                except Exception as e:
                    logger.error(
                        f"Failed to read dataset from {data}.\n{e0}\n\n{e}")
                    return None
        else:
            raise TypeError(
                f'Data format not accepted ({type(data)}). '
                'Expected xarray.Dataset, xarray.DataArray, or string path to netCDF file.'
            )

    @staticmethod
    def literal_eval(config):
        """Evaluate literal string as Python code"""
        def safe_literal_eval(x):
            if isinstance(x, str) and '[' in x:
                try:
                    return ast.literal_eval(x)
                except (ValueError, SyntaxError):
                    return x
            return x
        
        for p in ['variables', 'dims', 'coords', 'y_var', 'y_var_label']:
            if p in config:
                config[p] = config[p].replace({None: "[]"}).apply(safe_literal_eval)
        
        return config

    @staticmethod
    def __read_config__(config):
        """Read CSV and return configuration"""
        # Read the configuration CSV file
        if isinstance(config, str) and os.path.exists(config):
            config = pd.read_csv(config).fillna(
                'None').replace({float('nan'): None, np.nan: None, 'None': None})
        else:
            config = pd.DataFrame(config)

        # Convert columns to Python objects
        config = XPlotter.literal_eval(config)
        return config

    def extract_variables(self, config, data=None):
        """
        Extract specified variables from xarray Dataset/DataArray.

        Parameters:
        - config: Dictionary containing 'variables' key with list of variable names.
        - data: Optional xarray Dataset. If None, uses self.data.

        Returns:
        - xarray Dataset containing only specified variables.
        """
        if data is None:
            data = self.data

        if data is None:
            logger.error("No data available for extraction")
            return None

        variables = config.get('variables', [])
        if isinstance(variables, str):
            variables = [variables]

        # Filter variables that exist in the dataset
        if isinstance(data, xr.Dataset):
            available_vars = [v for v in variables if v in data.data_vars]
            if available_vars:
                return data[available_vars]
            else:
                logger.warning(f"No specified variables found in dataset")
                return None
        elif isinstance(data, xr.DataArray):
            logger.info("Data is a DataArray, returning as is")
            return data

    def select_data(self, config, data=None):
        """
        Select data based on dimensions and coordinates.

        Parameters:
        - config: Dictionary containing 'dims' and selection criteria.
        - data: Optional xarray Dataset/DataArray. If None, uses self.data.

        Returns:
        - Subset of the xarray data.
        """
        if data is None:
            data = self.data

        if data is None:
            logger.error("No data available for selection")
            return None

        # Extract selection criteria from config
        selection_dict = {k: v for k, v in config.items() 
                         if k not in ['variables', 'dims', 'coords', 'kind']}

        try:
            if selection_dict:
                return data.sel(selection_dict, method='nearest')
            else:
                return data
        except Exception as e:
            logger.error(f"Selection failed: {e}")
            return None

    def aggregate_data(self, config, data=None):
        """
        Aggregate data along specified dimensions.

        Parameters:
        - config: Dictionary containing 'agg_func' and 'dims' for aggregation.
        - data: Optional xarray Dataset/DataArray. If None, uses self.data.

        Returns:
        - Aggregated xarray data.
        """
        if data is None:
            data = self.data

        if data is None:
            logger.error("No data available for aggregation")
            return None

        agg_func = config.get('agg_func', 'mean')
        dims = config.get('dims', [])

        if isinstance(dims, str):
            dims = [dims]

        try:
            if agg_func == 'mean':
                return data.mean(dim=dims)
            elif agg_func == 'sum':
                return data.sum(dim=dims)
            elif agg_func == 'std':
                return data.std(dim=dims)
            elif agg_func == 'min':
                return data.min(dim=dims)
            elif agg_func == 'max':
                return data.max(dim=dims)
            else:
                logger.warning(f"Unknown aggregation function: {agg_func}")
                return data
        except Exception as e:
            logger.error(f"Aggregation failed: {e}")
            return None

    def serial_plot(self, config, data=None, multi_process=False, **kwargs):
        """
        Create plots from multiple configurations sequentially or in parallel.

        Parameters:
        - config: DataFrame, Series, dict, or list of dicts with plot config.
        - data: Optional xarray Dataset/DataArray to plot.
        - multi_process: Whether to use multiprocessing.
        - kwargs: Additional arguments to pass to plot_wrapper.

        Returns:
        - List of results from plotting operations.
        """
        # Normalize config to DataFrame
        if isinstance(config, pd.DataFrame):
            pass  # already DataFrame
        elif isinstance(config, pd.Series):
            config = config.to_frame().T
        elif isinstance(config, dict):
            config = pd.DataFrame([config])
        elif isinstance(config, list) and config and isinstance(config[0], dict):
            config = pd.DataFrame(config)
        else:
            raise TypeError("config must be DataFrame, Series, dict, or list of dicts")
        
        # Apply literal_eval to handle string literals
        config = XPlotter.literal_eval(config)
        
        # Convert back to list of dicts
        config = list(config.T.to_dict().values())
        
        # Prepare the list of jobs for multi-processing
        jobs = []
        results = []
        for row in config:
            cfg = dict(row)  # Convert row to dictionary
            
            kwargs_copy = dict(data=data, **kwargs)
            if multi_process:
                jobs.append((cfg, kwargs_copy.copy()))
            else:
                results.append(self.plot_wrapper(cfg, **kwargs_copy))

        if multi_process:
            with concurrent.futures.ProcessPoolExecutor() as executor:
                results = list(executor.map(self.plot_multiprocess_wrapper, jobs))
        
        return results

    def plot_from_csv(self, config, **kwargs):
        """
        Read configuration from CSV and create plots for all rows.

        Parameters:
        - config: Path to CSV configuration file.
        - kwargs: Additional arguments to pass to serial_plot.

        Returns:
        - List of results from all plotting operations.
        """
        config = XPlotter.__read_config__(config)
        results = self.serial_plot(config, **kwargs)
        return results

    def to_dataset(self, data=None):
        """
        Convert data to xarray Dataset if it's a DataArray.

        Parameters:
        - data: Optional xarray data. If None, uses self.data.

        Returns:
        - xarray Dataset.
        """
        if data is None:
            data = self.data

        if isinstance(data, xr.DataArray):
            return data.to_dataset()
        elif isinstance(data, xr.Dataset):
            return data
        else:
            logger.error("Data is not an xarray object")
            return None

    def to_dataframe(self, data=None):
        """
        Convert xarray Dataset/DataArray to pandas DataFrame.

        Parameters:
        - data: Optional xarray data. If None, uses self.data.

        Returns:
        - pandas DataFrame.
        """
        if data is None:
            data = self.data

        try:
            if isinstance(data, xr.Dataset):
                return data.to_array().to_pandas()
            elif isinstance(data, xr.DataArray):
                return data.to_pandas()
            else:
                logger.error("Data is not an xarray object")
                return None
        except Exception as e:
            logger.error(f"Conversion to DataFrame failed: {e}")
            return None

    def get_info(self, data=None):
        """
        Get information about the xarray Dataset/DataArray.

        Parameters:
        - data: Optional xarray data. If None, uses self.data.

        Returns:
        - Dictionary with dataset information.
        """
        if data is None:
            data = self.data

        if data is None:
            return None

        info = {
            'type': str(type(data)),
            'shape': data.shape,
            'dims': dict(data.dims) if hasattr(data, 'dims') else None,
            'coords': list(data.coords) if hasattr(data, 'coords') else None,
            'data_vars': list(data.data_vars) if isinstance(data, xr.Dataset) else None,
            'attrs': data.attrs if hasattr(data, 'attrs') else None,
        }
        return info

    @staticmethod
    def apply_style(style):
        """
        Apply the selected matplotlib style.
        """
        try:
            if style is not None:
                plt.style.use(style)
        except:
            logger.warning(f"Style '{style}' not found. Using default style.")
            plt.style.use("fivethirtyeight")


    @staticmethod
    def _get_figure_size(aspect):
        """Return figure size based on aspect ratio"""
        if isinstance(aspect, tuple):
            return aspect
        else:
            aspect_dict = {
                'small': (6, 4),
                'medium': (8, 6),
                'big': (10, 8),
                'wide': (12, 6),
                'very-wide': (24, 4)
            }
            return aspect_dict.get(aspect, (8, 6))

    def _save_or_display(self, fig, save_as, dpi):
        """
        Helper method to save the figure to file or display it and return PIL image.
        
        Parameters:
        - fig: Matplotlib figure object.
        - save_as: Path to save the figure. If None, displays the plot.
        - dpi: Dots per inch for saved figure.
        
        Returns:
        - PIL Image if not saved, otherwise None.
        """
        if save_as:
            plt.savefig(save_as, dpi=dpi)
            plt.close()
        else:
            buffer = BytesIO()
            fig.savefig(buffer, format='png', dpi=100, bbox_inches='tight')
            buffer.seek(0)
            pil_image = Image.open(buffer)
            plt.show()
            plt.close()
            return pil_image
        return None

    def lineplot(self, config, save_as=None, data=None, dpi=None, 
                 legend_kwargs={}, **kwargs):
        """
        Create a line plot from xarray data.

        Parameters:
        - config: Dictionary containing plot configuration (x_dim, y_var, etc).
        - save_as: Path to save the figure. If None, displays the plot.
        - data: Optional xarray Dataset/DataArray. If None, uses self.data.
        - dpi: Dots per inch for saved figure.
        - legend_kwargs: Additional kwargs for legend.
        - kwargs: Additional configuration parameters.

          Some special keys are recognised to drive matplotlib styling from
          data columns.  If a config contains ``<arg>_var`` (e.g. ``linestyle_var``),
          the values of that column will be translated into the corresponding
          matplotlib argument via :meth:`kwargs_from_column`.  You can also
          supply ``<arg>_map`` to provide a custom mapping dictionary.  Supported
          arguments include ``linestyle``, ``color``, ``marker``, ``linewidth``
          and ``alpha``.

        Returns:
        - PIL Image if not saved, otherwise None.
        """
        config.update(kwargs)

        if data is None:
            data = self.data

        if data is None:
            logger.error("No data available for plotting")
            return None

        # Apply style
        self.apply_style(self.style or config.get('style', 'default'))

        # Get plot configuration
        x_dim = config.get('x_dim', None)
        y_var = config.get('y_var', [])
        if isinstance(y_var, str):
            y_var = [y_var]

        # Create figure
        fig = plt.figure(figsize=self._get_figure_size(config.get('aspect', 'wide')))

        # Operate directly on xarray structures without full DataFrame conversion
        try:
            if isinstance(data, xr.Dataset):
                available_vars = [v for v in y_var if v in data.data_vars]
                if not available_vars:
                    logger.error("No specified variables found in dataset")
                    plt.close()
                    return None
            else:
                available_vars = [None]

            # determine x-axis values
            if x_dim:
                if x_dim not in data.coords and x_dim not in data.dims:
                    logger.error(f"x_dim '{x_dim}' not present in data")
                    plt.close()
                    return None
                x_vals = data[x_dim].values
            else:
                first_dim = data[available_vars[0]].dims[0] if isinstance(data, xr.Dataset) else list(data.dims)[0]
                x_dim = first_dim
                x_vals = data[first_dim].values

            # gather style information
            style_attrs = ['linestyle', 'color', 'marker', 'linewidth', 'alpha']
            style_values = {}
            style_maps = {}
            for attr in style_attrs:
                var_key = f"{attr}_var"
                map_key = f"{attr}_map"
                if config.get(var_key):
                    sty_arr = data[config[var_key]].values
                    style_values[attr] = sty_arr
                    mapping = config.get(map_key)
                    if mapping is None:
                        uniques = list(np.unique(sty_arr))
                        temp = self.kwargs_from_column(pd.DataFrame({config[var_key]: uniques}),
                                                       config[var_key],
                                                       arg_name=attr)
                        mapping = {u: temp[attr][i] for i, u in enumerate(uniques)}
                    style_maps[attr] = mapping

            # get color cycle for variables (used only if color_var not specified)
            color_cycle = plt.rcParams['axes.prop_cycle'].by_key().get('color', ['blue', 'red', 'green', 'orange', 'purple'])

            # plotting loop
            for i, var in enumerate(available_vars):
                arr = data[var] if var is not None else data
                # reduce multi-dimensional variables to 1D along x_dim
                if arr.ndim > 1:
                    sel = {d: 0 for d in arr.dims if d != x_dim}
                    try:
                        arr = arr.isel(sel)
                    except Exception:
                        pass
                y_vals = arr.values
                if y_vals.ndim > 1:
                    y_vals = y_vals.flatten()
                
                # Set default color if color_var is not specified
                if 'color' not in style_values:
                    default_color = color_cycle[i % len(color_cycle)]
                else:
                    default_color = None
                
                if style_values:
                    n = len(x_vals)
                    # build tuple keys per index
                    keys_list = [tuple(style_values[attr].flatten()[i] for attr in style_values) for i in range(n)]
                    unique_keys = list(dict.fromkeys(keys_list))
                    for key in unique_keys:
                        mask = np.ones(n, dtype=bool)
                        for j, attr in enumerate(style_values):
                            mask &= (style_values[attr].flatten() == key[j])
                        if not mask.any():
                            continue
                        xx = x_vals[mask]
                        yy = y_vals.flatten()[mask]
                        plot_kwargs = {attr: style_maps[attr].get(key[j], key[j])
                                       for j, attr in enumerate(style_values)}
                        if default_color is not None and 'color' not in plot_kwargs:
                            plot_kwargs['color'] = default_color
                        label = var or ''
                        if key != (): label += f" {key}"
                        plt.plot(xx, yy, label=label, **plot_kwargs)
                else:
                    if default_color is not None:
                        plt.plot(x_vals, y_vals, label=var or '', color=default_color)
                    else:
                        plt.plot(x_vals, y_vals, label=var or '')
        except Exception as e:
            logger.error(f"Plotting failed: {e}")
            plt.close()
            return None

        # Set labels and title
        if config.get('x_label', None):
            plt.xlabel(config['x_label'])
        if config.get('y_label', None):
            plt.ylabel(config['y_label'])
        if config.get('title', None):
            plt.title(config['title'])

        # Set limits
        if config.get('xlim', None):
            plt.xlim(config['xlim'])
        if config.get('ylim', None):
            plt.ylim(config['ylim'])

        # Add legend
        plt.legend(**legend_kwargs)

        # Adjust layout
        plt.tight_layout()

        return self._save_or_display(fig, save_as, dpi)

    def heatmap(self, config, save_as=None, data=None, dpi=None, **kwargs):
        """
        Create a heatmap/contour plot from xarray data.

        Parameters:
        - config: Dictionary containing plot configuration (variable, dims, etc).
        - save_as: Path to save the figure. If None, displays the plot.
        - data: Optional xarray Dataset/DataArray. If None, uses self.data.
        - dpi: Dots per inch for saved figure.
        - kwargs: Additional configuration parameters.

        Returns:
        - PIL Image if not saved, otherwise None.
        """
        config.update(kwargs)

        if data is None:
            data = self.data

        if data is None:
            logger.error("No data available for plotting")
            return None

        # Apply style
        self.apply_style(config.get('style', 'default'))

        # Get plot configuration
        variable = config.get('variable', None)
        cmap = config.get('cmap', 'viridis')

        # Create figure
        fig = plt.figure(figsize=self._get_figure_size(config.get('aspect', 'big')))

        try:
            if isinstance(data, xr.Dataset):
                if variable is None:
                    logger.error("Variable must be specified for Dataset heatmap")
                    plt.close()
                    return None

                if variable not in data.data_vars:
                    logger.error(f"Variable '{variable}' not found in dataset")
                    plt.close()
                    return None

                data_plot = data[variable]
            else:
                data_plot = data

            # Plot using xarray's built-in plotting
            if len(data_plot.dims) == 2:
                data_plot.plot(cmap=cmap, ax=plt.gca())
            elif len(data_plot.dims) == 1:
                data_plot.plot(ax=plt.gca())
            else:
                logger.warning(f"Data has {len(data_plot.dims)} dimensions, expected 1-2")
                plt.close()
                return None

        except Exception as e:
            logger.error(f"Heatmap plotting failed: {e}")
            plt.close()
            return None

        # Set labels and title
        if config.get('title', None):
            plt.title(config['title'])

        # Adjust layout
        plt.tight_layout()

        return self._save_or_display(fig, save_as, dpi)

    def plot_wrapper(self, config, error=None, *args, **kwargs):
        """Wrapper for plotting operations with error handling"""
        try:
            kind = config.get('kind', 'lineplot')

            if kind == 'lineplot':
                return self.lineplot(config, *args, **kwargs)
            elif kind == 'heatmap':
                return self.heatmap(config, *args, **kwargs)
            elif kind == 'extract':
                return self.extract_variables(config, *args, **kwargs)
            elif kind == 'select':
                return self.select_data(config, *args, **kwargs)
            elif kind == 'aggregate':
                return self.aggregate_data(config, *args, **kwargs)
            else:
                logger.warning(f"Unknown operation kind: {kind}")
                return None
        except Exception as e:
            if error == 'ignore':
                pass
            elif error == 'raise':
                raise e
            else:
                logger.error(f"Error: {e}")
        return None

    def plot_multiprocess_wrapper(self, args):
        """Wrapper for multiprocessing of plotting operations"""
        config, kwargs = args
        return self.plot_wrapper(config, **kwargs)
