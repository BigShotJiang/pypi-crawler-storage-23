from . import version
from . import xplotter
from .xplotter import XPlotter

try:
    from . import plotter
    from .plotter import Plotter
except ImportError:
    plotter = None
    Plotter = None

__all__ = ['version', 'XPlotter', 'Plotter', 'plotter', 'xplotter']
