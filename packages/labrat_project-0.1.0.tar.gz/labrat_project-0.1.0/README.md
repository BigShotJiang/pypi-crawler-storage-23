# Programme to take data from various sensors and save 

Choose the way you wish to log the data and where you want to get it from.

Then run the appropriate script with command line options.

To run needs a secrets file with the path given as option to the scrpt

so if you want to log from a MQTT server use
e.g

```bash
python labrat_mqtt.py -secrets "mypath\secrets.toml"
```

the secrets is a toml in the following form

```toml
"MQTT_USERNAME" = ""
"MQTT_KEY" = ""
"MQTT_BROKER" = ""
"MQTT_PORT" = 
"MQTT_TOPIC" = ""
"INATOR_NAME" = ""

```

if using an sqlite database need a device file in json format
Below is the schema
More information is [here](https://inator-project.org/Protocols/pro_database.html)
```json
{
    "$schema": "http://json-schema.org/draft-04/schema#",
    "type": "object",
    "properties": {
        "devices": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "device_name": {"type": "string"},
                    "device_guid": {"type": "string"},
                    "num_sensors": {"type": "integer"},
                    "device_info": {"type": "string"},
                    "device_type": {"type": "string"},
                    "device_location": {"type": "string"},
                    "device_active": {"type": "integer"},
                    "connection": {
                        "type": "string",
                        "enum": ["Serial", "MQTT", "Other"],
                    },
                    "sensors": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "sens_name": {"type": "string"},
                                "measures": {"type": "string"},
                                "returns": {"type": "string"},
                                "calib": {"type": "string"},
                                "range": {"type": "string"},
                                "info": {"type": "string"},
                                "comments": {"type": "string"},
                            },
                            "required": [
                                "sens_name",
                                "measures",
                                "returns",
                                "calib",
                                "range",
                                "info",
                                "comments",
                            ],
                        },
                    },
                },
                "required": [
                    "device_name",
                    "device_guid",
                    "num_sensors",
                    "device_info",
                    "device_type",
                    "device_location",
                    "device_active",
                    "connection",
                    "sensors",
                ],
            },
        }
    },
    "required": ["devices"],
}

```

To run as a daemon supervisord can be used and an example configuration file is provided.

To install (if not already installed)

```bash
sudo apt update && sudo apt install supervisor
```
Edit the config file making sure to change:

* command= \<make sure all the paths are correct to database and secrets file\>

* user= \<make sure the correct user name is used\>

* stdout_logfile = \<give and appropriate path and filename to log output of programme to \>

* directory = \<make sure the correct home directory for MQTT is set \>

Then run using

```bash
supervisord -c <path to the configuration file>
```

To monitor and control the program use [supervisorctl](https://supervisord.org/running.html#running-supervisorctl)