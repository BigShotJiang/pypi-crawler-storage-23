"""Functions to log out information"""

import datetime


def get_datetime():
    """function to return a datetime for further use in logging

    Returns
    -------
    datetime
        returns the datetime object and its cast to int
    """
    ct = datetime.datetime.now()
    ct = ct.astimezone()
    int_ct = int(ct.timestamp())

    return ct, int_ct


def get_formatted_datetime(cur_date=None):
    """Function to get a datetime in the isoformat. If not timestamp provided is generated

    Parameters
    ----------
    cur_date : datetime, optional
        the datetime that needs formating, by default None

    Returns
    -------
    string
        the formatted date time string
    """
    if cur_date is None:
        cur_date = get_datetime()[0]

    out = cur_date.isoformat(timespec="seconds")

    return out
