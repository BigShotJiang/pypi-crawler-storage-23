"""The CLI code to interface"""

import argparse as arg


def parsing():
    """Argument Parser for coincidence analysis

    Returns
    -------
    parse
        The argument parser object
    """

    parse = arg.ArgumentParser(
        description="Purpose: Connect sensors and log to DB",
        formatter_class=arg.RawTextHelpFormatter,
    )

    parse.add_argument(
        "conn",
        metavar="CONN",
        type=str,
        default="mqtt",
        help=(
            "Which connection will be monitored. Can be: \n"
            "✅ - mqtt for a MQTT connection \n"
            "✅ - serial for a wired Serial Connection\n"
            "✅ - flask for a Flask based API\n"
            "✅ - quick_start to run a set up wizard\n"
        ),
    )

    parse.add_argument(
        "-sql",
        metavar="SQL",
        type=str,
        help=("The SQL database path. Should be absolute"),
    )

    parse.add_argument(
        "-secrets",
        metavar="SECRETS",
        type=str,
        default=None,
        help=("The path to the toml fil with secrets, such as log ins are kept"),
    )

    parse.add_argument(
        "-setupsql",
        action="store_true",
        help=(
            "If added this flag will run the create Inator DB function."
            "This will then require extra flags such as the device info file location"
        ),
    )

    parse.add_argument(
        "--createdb",
        action="store_true",
        help=(
            "If setup flag added this will create a new DB if the given db doesn't exist"
        ),
    )

    parse.add_argument(
        "--dev_file",
        metavar="DEVFILE",
        type=str,
        help=(
            "If the setup flag is added this will load the device information"
            "This is the path to the JSON file that contains the device"
            "information to be loaded into the SQL"
        ),
    )

    parse.add_argument(
        "-file",
        metavar="FILE",
        type=str,
        help=(
            "If set this is the file path to a text file where data can be logged."
            "Should be an absolute path"
        ),
    )

    # Serial only arguments
    parse.add_argument(
        "--setfile",
        action="store_true",
        help=("If set this will run a set up file function, for headers etc..."),
    )

    parse.add_argument(
        "-ser_port",
        metavar="SER_PORT",
        type=str,
        help="The COM port to connect to for serial",
    )

    parse.add_argument(
        "-baud",
        metavar="BAUD",
        type=int,
        default=115200,
        help="The Baud rate for the serial connection",
    )

    return parse
