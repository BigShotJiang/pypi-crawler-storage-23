"""A simple Flask page that will set up a database and add sensors"""

import datetime

from flask import Flask, request, current_app, jsonify, render_template

from src.in_io import sqlite as pysql
from src.in_io import in_io as inio


def create_app(handler, api_key):
    """Main app handling function

    Parameters
    ----------
    handler : _type_
        The object for saving, handles sql, file etc...
    api_key : string
        the key used to launch the flask app, needed to connect

    Returns
    -------
    flask app
        the app instance
    """
    app = Flask(__name__)
    app.handler = handler  # attach handler safely to app
    app.config["API_KEY"] = api_key

    return app


def run(handler, auth, host="127.0.0.1", port=5000):
    """
    Runs small test server to receive logging data.
    Not production safe.
    """
    api_key = auth["API_key"]
    app = create_app(handler, api_key)
    app.run(debug=True, host=host, port=port)


if __name__ == "__main__":
    raise RuntimeError("Use run(handler) instead of executing directly.")
