"""Module to contain authorization functions for flask server

Returns
-------
_type_
    _description_
"""

from flask import request, current_app, jsonify


def verify_api_key():
    """Function checks that api key is valid

    Returns
    -------
    _type_
        _description_
    """
    client_key = request.headers.get("X-API-KEY")
    if not client_key or client_key != current_app.config["API_KEY"]:
        return jsonify({"error": "Unauthorized"}), 401
