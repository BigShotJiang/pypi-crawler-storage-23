"""All the flask functions for the logger

Returns
-------
_type_
    _description_

Raises
------
RuntimeError
    _description_
"""

import os

from flask import Flask

from src.http.routes.datalog import register_datalog
from src.http.routes.setup import register_setup
from src.http.routes.data_get import register_dataget


def create_app(handler, api_key, topics):
    """Main app handling function"""
    app = Flask(__name__)
    app.handler = handler
    app.config["API_KEY"] = api_key
    app.config["SECRET_KEY"] = os.urandom(32)

    route_name = topics.get("route", "/datalog")
    if not route_name.startswith("/"):
        route_name = "/" + route_name

    register_setup(app)
    register_datalog(app, route_name)
    register_dataget(app, route_name)

    return app


def run(handler, auth, topics, host="127.0.0.1", port=5000):
    """Entry to flask app"""
    api_key = auth["API_key"]
    app = create_app(handler, api_key, topics)
    app.run(debug=True, host=host, port=port)


if __name__ == "__main__":
    raise RuntimeError("Use run(handler) instead of executing directly.")
