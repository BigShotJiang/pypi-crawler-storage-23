"""File with the schemas for inator set up in"""

# The JSON Schema
JSON_SCHEMA = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "type": "object",
    "properties": {
        "devices": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "device_name": {"type": "string"},
                    "device_guid": {"type": "string"},
                    "num_sensors": {"type": "integer"},
                    "device_info": {"type": "string"},
                    "device_type": {"type": "string"},
                    "device_location": {"type": "string"},
                    "device_active": {"type": "integer"},
                    "connection": {
                        "type": "string",
                        "enum": ["Serial", "MQTT", "http", "Other"],
                    },
                    "sensors": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "sens_name": {"type": "string"},
                                "measures": {"type": "string"},
                                "returns": {"type": "string"},
                                "calib": {"type": "string"},
                                "range": {"type": "string"},
                                "info": {"type": "string"},
                                "comments": {"type": "string"},
                            },
                            "required": [
                                "sens_name",
                                "measures",
                                "returns",
                                "calib",
                                "range",
                                "info",
                                "comments",
                            ],
                        },
                    },
                },
                "required": [
                    "device_name",
                    "device_guid",
                    "num_sensors",
                    "device_info",
                    "device_type",
                    "device_location",
                    "device_active",
                    "connection",
                    "sensors",
                ],
            },
        }
    },
    "required": ["devices"],
}
