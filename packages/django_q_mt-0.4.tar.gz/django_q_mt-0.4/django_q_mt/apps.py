from django.apps import AppConfig


class DjangoQMtConfig(AppConfig):
    name = 'django_q_mt'
