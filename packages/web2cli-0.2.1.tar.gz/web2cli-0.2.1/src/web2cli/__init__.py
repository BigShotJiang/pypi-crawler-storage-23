"""web2cli — Every website is a command."""

__version__ = "0.2.1"
