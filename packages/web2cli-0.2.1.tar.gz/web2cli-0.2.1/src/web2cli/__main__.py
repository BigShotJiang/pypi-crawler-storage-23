"""Support `python -m web2cli`."""

from web2cli.cli import app

app()
