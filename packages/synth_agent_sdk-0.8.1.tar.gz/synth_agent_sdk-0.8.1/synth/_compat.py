"""Sync/async compatibility utilities.

Provides ``run_sync()`` — the single bridge used by all synchronous wrappers
(``Agent.run``, ``Agent.stream``, ``Pipeline.run``, etc.) to execute an async
coroutine from a synchronous context.

The function detects whether an event loop is already running (e.g. inside
Jupyter notebooks or other async frameworks) and chooses the appropriate
execution strategy:

1. **No running loop** — delegates to ``asyncio.run()``.
2. **Running loop + nest_asyncio available** — patches the loop with
   ``nest_asyncio.apply()`` and runs the coroutine on the current loop.
3. **Running loop, no nest_asyncio** — runs the coroutine in a new thread
   with its own event loop to avoid blocking the caller's loop.
"""

from __future__ import annotations

import asyncio
import threading
from typing import Any, TypeVar

T = TypeVar("T")


def run_sync(coro: Any) -> T:
    """Run an async coroutine from a synchronous context.

    Parameters
    ----------
    coro:
        An awaitable coroutine object (e.g. ``agent.arun(...)``).

    Returns
    -------
    T
        The value returned by the coroutine.

    Raises
    ------
    Exception
        Re-raises any exception thrown inside the coroutine.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        # No event loop running — safe to use asyncio.run().
        return asyncio.run(coro)  # type: ignore[return-value]

    # An event loop is already running (Jupyter, uvicorn, etc.).
    # Try nest_asyncio first for the simplest experience.
    try:
        import nest_asyncio  # type: ignore[import-untyped]

        nest_asyncio.apply(loop)
        return loop.run_until_complete(coro)  # type: ignore[return-value]
    except ImportError:
        pass

    # Fallback: run in a dedicated thread with its own event loop.
    result: T | None = None
    exception: BaseException | None = None

    def _run_in_thread() -> None:
        nonlocal result, exception
        try:
            result = asyncio.run(coro)
        except BaseException as exc:  # noqa: BLE001
            exception = exc

    thread = threading.Thread(target=_run_in_thread, daemon=True)
    thread.start()
    thread.join()

    if exception is not None:
        raise exception

    return result  # type: ignore[return-value]
