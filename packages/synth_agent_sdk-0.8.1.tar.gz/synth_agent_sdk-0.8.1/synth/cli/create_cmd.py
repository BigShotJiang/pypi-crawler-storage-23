﻿"""``synth create`` command group — scaffold agents, tools, MCPs, and UIs.

Provides interactive project scaffolding with provider selection for agents,
MCP server templates, standalone tool files, multi-agent teams, and a local
testing UI.
"""

from __future__ import annotations

import os
import sys
from typing import Any

import click


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _write(path: str, content: str) -> None:
    """Write *content* to *path* with UTF-8 encoding."""
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


def _ensure_dir(name: str) -> None:
    """Create project directory or exit if it already exists."""
    if os.path.exists(name):
        click.echo(
            click.style(f"Directory '{name}' already exists.", fg="red"),
        )
        raise SystemExit(1)
    os.makedirs(name)


def _success_banner(name: str, files: list[tuple[str, str]]) -> None:
    """Print a consistent success banner with file listing."""
    click.echo(click.style("Project created successfully!", fg="green"))
    click.echo("")
    click.echo(f"  {click.style(name + '/', fg='cyan')}")
    for fname, desc in files:
        click.echo(f"    {fname:<20s} {desc}")
    click.echo("")


def _next_steps(steps: list[str]) -> None:
    """Print next-steps block."""
    click.echo("  Next steps:")
    for step in steps:
        click.echo(f"    {click.style('>', dim=True)} {step}")
    click.echo("")


# ---------------------------------------------------------------------------
# Provider configuration map
# ---------------------------------------------------------------------------

_PROVIDERS: dict[str, dict[str, str]] = {
    "anthropic": {
        "model": "claude-sonnet-4-5",
        "extra": "anthropic",
        "env_var": "ANTHROPIC_API_KEY",
        "display": "Anthropic (Claude)",
    },
    "openai": {
        "model": "gpt-4o",
        "extra": "openai",
        "env_var": "OPENAI_API_KEY",
        "display": "OpenAI (GPT)",
    },
    "llama": {
        "model": "ollama/llama3.2",
        "extra": "ollama",
        "env_var": "",
        "display": "Llama (via Ollama)",
    },
    "gemini": {
        "model": "gemini/gemini-2.0-flash",
        "extra": "google",
        "env_var": "GOOGLE_API_KEY",
        "display": "Google Gemini",
    },
    "agentcore": {
        "model": "bedrock/us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        "extra": "agentcore",
        "env_var": "",
        "display": "AWS AgentCore (Bedrock)",
    },
}


# ---------------------------------------------------------------------------
# synth create agent
# ---------------------------------------------------------------------------

_AGENT_TEMPLATE = '''"""{display} agent built with SynthAgentSDK."""

from synth import Agent, tool


@tool
def greet(name: str) -> str:
    """Greet a user by name."""
    return f"Hello, {{name}}!"


@tool
def get_current_time() -> str:
    """Get the current date and time."""
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()


agent = Agent(
    model="{model}",
    instructions=(
        "You are a helpful assistant. Use your tools when appropriate."
    ),
    tools=[greet, get_current_time],
)


if __name__ == "__main__":
    result = agent.run("Hello! What time is it?")
    print(result.text)
'''

_AGENTCORE_AGENT_TEMPLATE = '''"""{display} agent deployed to AWS AgentCore.

This agent uses:
- AgentCore Gateway for Lambda-backed tools via MCP
- AgentCore Code Interpreter for secure Python execution
- Secure user identity extraction from JWT (via RequestContext)
- SSM Parameter Store for runtime configuration
"""

from __future__ import annotations

import json
import traceback

from bedrock_agentcore.runtime import BedrockAgentCoreApp, RequestContext

from synth import tool
from synth.deploy.agentcore import (
    CodeInterpreterTools,
    create_gateway_client,
    extract_user_id,
)


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@tool
def greet(name: str) -> str:
    """Greet a user by name."""
    return f"Hello, {{name}}! Welcome aboard."


# Code Interpreter - secure Python execution in AgentCore sandbox
_code_interpreter = CodeInterpreterTools()


@tool
def execute_python(code: str) -> str:
    """Execute Python code securely in the AgentCore sandbox.

    The sandbox persists state across calls within a session.
    """
    return _code_interpreter.execute_python(code)


# ---------------------------------------------------------------------------
# AgentCore entrypoint
# ---------------------------------------------------------------------------

app = BedrockAgentCoreApp()


@app.entrypoint
async def agent_stream(payload: dict, context: RequestContext):
    """Main AgentCore entrypoint - streams responses token by token."""
    user_query = payload.get("prompt")
    session_id = payload.get("runtimeSessionId")

    if not user_query or not session_id:
        yield {"status": "error", "error": "Missing required fields: prompt or runtimeSessionId"}
        return

    try:
        # Extract user ID securely from the validated JWT token.
        # Never trust the payload body for identity - prompt injection risk.
        user_id = extract_user_id(context)

        # Gateway MCP client - connects to Lambda-backed tools via MCP.
        # Credentials are fetched automatically from SSM + Secrets Manager.
        gateway = create_gateway_client()
        gateway_tools = gateway.as_mcp_client()

        from synth import Agent
        agent = Agent(
            model="{model}",
            instructions=(
                "You are a helpful assistant with access to tools via the Gateway "
                "and a secure Python code interpreter. Use them when appropriate."
            ),
            tools=[gateway_tools, greet, execute_python],
        )

        async for event in agent.astream(user_query):
            yield json.loads(json.dumps(dict(event), default=str))

    except Exception as exc:
        traceback.print_exc()
        yield {"status": "error", "error": str(exc)}


if __name__ == "__main__":
    app.run()
'''

_AGENTCORE_REQUIREMENTS = '''# SynthAgentSDK with AgentCore support
synth-agent-sdk[agentcore]>=0.5.7

# Add your additional dependencies here
# httpx>=0.27
# pydantic>=2.0
'''

_AGENTCORE_CONFIG = '''# AgentCore Deployment Configuration
#
# This file is used by: synth deploy --target agentcore
#
# Agent Metadata
agent_name: {name}
agent_description: "AI agent deployed to AWS AgentCore"

# AWS Configuration
aws_region: us-east-1

# IAM Permissions (least-privilege)
# Add only the permissions your agent's tools actually need
permissions:
  - "bedrock:InvokeModel"
  - "bedrock:InvokeModelWithResponseStream"
  - "bedrock-agentcore:*"           # AgentCore Memory + Code Interpreter
  - "ssm:GetParameter"              # Runtime config from SSM
  - "secretsmanager:GetSecretValue" # Gateway credentials
  # - "s3:GetObject"
  # - "dynamodb:GetItem"
  # - "lambda:InvokeFunction"

# Runtime Configuration
runtime:
  memory_mb: 512
  timeout_seconds: 300

# Environment Variables (non-sensitive only)
# Sensitive values should be set via AWS Secrets Manager
environment:
  SYNTH_NO_BANNER: "1"
  # STACK_NAME: "your-stack-name"    # Set this to enable Gateway + SSM config
  # MEMORY_ID: "your-memory-id"      # Set this to enable AgentCore Memory
  # SYNTH_TRACE_ENDPOINT: "https://your-otel-collector/v1/traces"
'''

_AGENT_README = '''# {name}

A {display} agent built with [SynthAgentSDK](https://pypi.org/project/synth-agent-sdk/).

## Setup

```bash
pip install synth-agent-sdk[{extra}]
{env_setup}```

## Run

```bash
# Interactive shell — no synth prefix needed
synth
> run agent.py "Hello, who are you?"
> dev agent.py

# Or run commands directly
synth run agent.py "Hello, who are you?"
synth dev agent.py
synth doctor
```
'''

_AGENTCORE_README = '''# {name}

An AI agent built with [SynthAgentSDK](https://pypi.org/project/synth-agent-sdk/) and deployed to AWS AgentCore.

## What's included

- **AgentCore Gateway** — Lambda-backed tools exposed via MCP, authenticated with Cognito OAuth2
- **Code Interpreter** — Secure Python execution in an isolated AgentCore sandbox
- **JWT identity extraction** — User ID taken from the validated JWT token, not the payload body
- **SSM config**  Runtime configuration (Gateway URL, Cognito endpoints) fetched from SSM

## Prerequisites

- Python 3.10+
- AWS account with AgentCore access
- AWS CLI configured (`aws configure`)

## Setup

```bash
pip install -r requirements.txt
```

## Environment variables

Set these before running locally or in your AgentCore deployment config:

```bash
export STACK_NAME="your-stack-name"   # Enables Gateway + SSM config lookup
export MEMORY_ID="your-memory-id"     # Enables AgentCore Memory (optional)
export AWS_DEFAULT_REGION="us-east-1"
```

## Local development

```bash
# Run once
synth run agent.py "Hello, who are you?"

# Interactive dev with streaming + tool visualization
synth dev agent.py

# Check your setup
synth doctor
```

## Deploy to AgentCore

```bash
# Validate first (no actual deployment)
synth deploy --target agentcore --dry-run agent.py

# Deploy
synth deploy --target agentcore agent.py
```

## Project structure

```
{name}/
 agent.py          # Agent with Gateway tools, Code Interpreter, JWT auth
 requirements.txt  # Python dependencies
├── agentcore.yaml    # IAM permissions + runtime config
└── README.md
```

## Adding Gateway tools

Gateway tools are Lambda functions registered in your CDK stack. The agent
discovers them automatically via MCP when `STACK_NAME` is set:

```python
gateway = create_gateway_client()   # reads STACK_NAME from env
gateway_tools = gateway.as_mcp_client()

agent = Agent(model="...", tools=[gateway_tools])
```

## Adding custom tools

```python
from synth import tool

@tool
def my_tool(param: str) -> str:
    """Description shown to the LLM."""
    return "result"

agent = Agent(model="...", tools=[gateway_tools, my_tool])
```

## Code Interpreter

The agent includes a secure Python sandbox out of the box:

```python
# Ask the agent:
# "Calculate the first 20 Fibonacci numbers"
# "Analyse this CSV data: ..."
```

## IAM permissions

Edit `agentcore.yaml` to add only what your tools need:

```yaml
permissions:
  - "bedrock:InvokeModel"
  - "bedrock-agentcore:*"
  - "ssm:GetParameter"
  - "secretsmanager:GetSecretValue"
  - "s3:GetObject"       # only if your tools need S3
```

## Troubleshooting

- **Import errors** — check all deps are in `requirements.txt`
- **Gateway auth fails**  verify `STACK_NAME` and Cognito credentials in SSM
- **Permission denied**  check IAM permissions in `agentcore.yaml`
- **Deployment fails**  run `synth doctor` to verify your setup

## Learn more

- [SynthAgentSDK docs](https://pypi.org/project/synth-agent-sdk/)
- [AWS AgentCore docs](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/)
- [AgentCore Gateway](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/gateway.html)
- [AgentCore Code Interpreter](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/code-interpreter-tool.html)
'''



def _build_agentcore_yaml(name: str, setup: dict[str, Any]) -> str:
    """Build agentcore.yaml content with region/model/CRIS/profile fields.

    Parameters
    ----------
    name:
        The project/agent name.
    setup:
        Dict from ``_run_agentcore_setup()`` with keys ``aws_region``,
        ``model_id``, ``cris_enabled``, ``aws_profile``.

    Returns
    -------
    str
        YAML content for ``agentcore.yaml``.
    """
    aws_region = setup.get("aws_region", "us-east-1")
    model_id = setup.get("model_id", "us.anthropic.claude-sonnet-4-5-20250929-v1:0")
    cris_enabled = setup.get("cris_enabled", False)
    aws_profile = setup.get("aws_profile")

    lines = [
        "# AgentCore Deployment Configuration",
        "#",
        "# This file is used by: synth deploy --target agentcore",
        "#",
        "# Agent Metadata",
        f"agent_name: {name}",
        'agent_description: "AI agent deployed to AWS AgentCore"',
        "",
        "# AWS Configuration",
        f"aws_region: {aws_region}",
        f"model_id: {model_id}",
        f"cris_enabled: {'true' if cris_enabled else 'false'}",
    ]

    if aws_profile:
        lines.append(f"aws_profile: {aws_profile}")

    lines.extend([
        "",
        "# IAM Permissions (least-privilege)",
        "permissions:",
        '  - "bedrock:InvokeModel"',
        '  - "bedrock:InvokeModelWithResponseStream"',
        '  - "bedrock-agentcore:*"',
        '  - "ssm:GetParameter"',
        '  - "secretsmanager:GetSecretValue"',
        "",
        "# Runtime Configuration",
        "runtime:",
        "  memory_mb: 512",
        "  timeout_seconds: 300",
        "",
        "# Environment Variables (non-sensitive only)",
        "environment:",
        '  SYNTH_NO_BANNER: "1"',
        "",
    ])

    return "\n".join(lines)


def _create_agent(name: str, provider: str) -> None:
    """Scaffold an agent project for the given provider."""
    cfg = _PROVIDERS[provider]
    is_agentcore = provider == "agentcore"

    # Pre-flight checks for AgentCore
    if is_agentcore:
        try:
            import boto3  # noqa: F401
        except ImportError:
            click.echo(click.style(
                "boto3 is not installed. Install it with:\n"
                "  pip install synth-agent-sdk[agentcore]",
                fg="yellow",
            ))
            click.echo("")

    # Llama/Ollama check
    if provider == "llama":
        click.echo(click.style(
            "Llama runs locally via Ollama. Make sure Ollama is installed:\n"
            "  https://ollama.com/download\n"
            "  ollama pull llama3.2",
            fg="yellow",
        ))
        click.echo("")

    # AgentCore-specific: credential + region + model setup
    agentcore_setup: dict[str, Any] = {}
    if is_agentcore:
        from synth.cli.init_cmd import (
            _run_model_selection,
            _run_credential_check,
        )
        agentcore_state: dict[str, Any] = {}
        model_id = _run_model_selection("agentcore", cfg, agentcore_state)
        cred_result = _run_credential_check()
        agentcore_setup = {
            "aws_region": agentcore_state.get("aws_region", "us-east-1"),
            "model_id": model_id,
            "cris_enabled": agentcore_state.get("cris_enabled", False),
            "aws_profile": cred_result.get("aws_profile"),
        }
        cfg = dict(cfg)
        cfg["model"] = agentcore_setup["model_id"]

    _ensure_dir(name)

    # Write agent file
    if is_agentcore:
        _write(
            os.path.join(name, "agent.py"),
            _AGENTCORE_AGENT_TEMPLATE.format(**cfg),
        )
        _write(
            os.path.join(name, "requirements.txt"),
            _AGENTCORE_REQUIREMENTS,
        )
        _write(
            os.path.join(name, "agentcore.yaml"),
            _build_agentcore_yaml(name, agentcore_setup),
        )
        _write(
            os.path.join(name, "README.md"),
            _AGENTCORE_README.format(name=name),
        )
    else:
        _write(
            os.path.join(name, "agent.py"),
            _AGENT_TEMPLATE.format(**cfg),
        )
        env_setup = (
            f'export {cfg["env_var"]}="your-key-here"\n'
            if cfg["env_var"]
            else ""
        )
        _write(
            os.path.join(name, "README.md"),
            _AGENT_README.format(name=name, env_setup=env_setup, **cfg),
        )

    # Success output
    files = [("agent.py", f'{cfg["display"]} agent')]
    if is_agentcore:
        files.append(("requirements.txt", "Python dependencies"))
        files.append(("agentcore.yaml", "Deployment configuration"))
    files.append(("README.md", "Getting started guide"))
    _success_banner(name, files)

    steps = [f"cd {name}"]
    if is_agentcore:
        steps.append("pip install -r requirements.txt")
        steps.append("aws configure  # Set up AWS credentials")
    else:
        steps.append(f"pip install synth-agent-sdk[{cfg['extra']}]")
    if cfg["env_var"]:
        steps.append(f'export {cfg["env_var"]}="your-key"')
    if provider == "llama":
        steps.append("ollama pull llama3.2")
    steps.append('synth run agent.py "Hello"')
    if is_agentcore:
        steps.append("synth deploy --target agentcore --dry-run agent.py")
        steps.append("synth deploy --target agentcore agent.py")
    _next_steps(steps)


# ---------------------------------------------------------------------------
# synth create tool
# ---------------------------------------------------------------------------

_TOOL_TEMPLATE = '''"""Custom tools for SynthAgentSDK agents.

Each function decorated with ``@tool`` becomes available to the agent.
Rules:
  - Every parameter needs a type annotation.
  - Must have a docstring (this is sent to the LLM as the tool description).
  - Can be sync or async.
"""

from __future__ import annotations

from synth import tool


# ---------------------------------------------------------------------------
# Search & retrieval
# ---------------------------------------------------------------------------

@tool
def search(query: str, limit: int = 5) -> list[str]:
    """Search for information matching the query.

    Parameters
    ----------
    query:
        The search term.
    limit:
        Maximum number of results to return.
    """
    # TODO: Replace with your real search implementation
    return [f"Result {{i + 1}} for '{{query}}'" for i in range(limit)]


@tool
async def fetch_url(url: str) -> str:
    """Fetch the text content of a URL (async example).

    Parameters
    ----------
    url:
        The URL to fetch.
    """
    import httpx
    async with httpx.AsyncClient() as client:
        resp = await client.get(url, follow_redirects=True, timeout=10.0)
        resp.raise_for_status()
        return resp.text[:2000]


# ---------------------------------------------------------------------------
# Math & computation
# ---------------------------------------------------------------------------

@tool
def calculate(expression: str) -> str:
    """Evaluate a mathematical expression safely.

    Parameters
    ----------
    expression:
        A numeric expression like ``2 + 2`` or ``sqrt(16)``.
    """
    import math
    allowed_names = {{k: v for k, v in math.__dict__.items() if not k.startswith("_")}}
    try:
        result = eval(expression, {{"__builtins__": {{}}}}, allowed_names)  # noqa: S307
        return str(result)
    except Exception as e:
        return f"Error: {{e}}"


# ---------------------------------------------------------------------------
# File & data operations
# ---------------------------------------------------------------------------

@tool
def read_file(path: str) -> str:
    """Read and return the text content of a local file.

    Parameters
    ----------
    path:
        Path to the file to read.
    """
    with open(path, encoding="utf-8") as fh:
        return fh.read()


@tool
def write_file(path: str, content: str) -> str:
    """Write content to a local file.

    Parameters
    ----------
    path:
        Destination file path.
    content:
        Text content to write.
    """
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(content)
    return f"Wrote {{len(content)}} chars to {{path}}"


@tool
def read_csv(path: str, limit: int = 50) -> list[dict]:
    """Read a CSV file and return rows as a list of dicts.

    Parameters
    ----------
    path:
        Path to the CSV file.
    limit:
        Maximum number of rows to return.
    """
    import csv
    with open(path, encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        return [row for _, row in zip(range(limit), reader)]


@tool
def read_json(path: str) -> str:
    """Read a JSON file and return its contents as a formatted string.

    Parameters
    ----------
    path:
        Path to the JSON file.
    """
    import json
    with open(path, encoding="utf-8") as fh:
        data = json.load(fh)
    return json.dumps(data, indent=2)


# ---------------------------------------------------------------------------
# Text processing
# ---------------------------------------------------------------------------

@tool
def regex_extract(text: str, pattern: str) -> list[str]:
    """Extract all matches of a regex pattern from the given text.

    Parameters
    ----------
    text:
        The input text to search.
    pattern:
        A Python regex pattern string.
    """
    import re
    return re.findall(pattern, text)


@tool
def text_diff(old_text: str, new_text: str) -> str:
    """Return a unified diff between two text strings.

    Parameters
    ----------
    old_text:
        The original text.
    new_text:
        The modified text.
    """
    import difflib
    diff = difflib.unified_diff(
        old_text.splitlines(keepends=True),
        new_text.splitlines(keepends=True),
        fromfile="old", tofile="new",
    )
    return "".join(diff) or "No differences found."


# ---------------------------------------------------------------------------
# System & environment
# ---------------------------------------------------------------------------

@tool
def get_current_datetime() -> str:
    """Return the current UTC date and time in ISO 8601 format."""
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()


@tool
def run_shell(command: str, timeout: int = 30) -> str:
    """Run a shell command and return its stdout.

    Parameters
    ----------
    command:
        The shell command to execute.
    timeout:
        Maximum seconds to wait for the command.
    """
    import subprocess
    result = subprocess.run(
        command, shell=True, capture_output=True, text=True,
        timeout=timeout,
    )
    output = result.stdout.strip()
    if result.returncode != 0:
        output += f"\\nSTDERR: {{result.stderr.strip()}}"
    return output


@tool
def sql_query(db_path: str, query: str) -> list[dict]:
    """Execute a read-only SQL query against a SQLite database.

    Parameters
    ----------
    db_path:
        Path to the SQLite database file.
    query:
        The SQL query to execute.
    """
    import sqlite3
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = [dict(r) for r in conn.execute(query).fetchall()]
    finally:
        conn.close()
    return rows
'''


def _create_tool(name: str) -> None:
    """Scaffold a standalone tools file."""
    filename = f"{name}.py" if not name.endswith(".py") else name

    if os.path.exists(filename):
        click.echo(
            click.style(f"File '{filename}' already exists.", fg="red"),
        )
        raise SystemExit(1)

    _write(filename, _TOOL_TEMPLATE)

    click.echo(click.style(f"Tool file created: {filename}", fg="green"))
    click.echo("")
    click.echo("  Use it in your agent:")
    click.echo("")
    click.echo(f"    from {name.replace('.py', '')} import search, calculate, fetch_url, read_file")
    click.echo("")
    click.echo("    agent = Agent(")
    click.echo("        model=\"claude-sonnet-4-5\",")
    click.echo("        tools=[search, calculate, fetch_url, read_file],")
    click.echo("    )")
    click.echo("")


# ---------------------------------------------------------------------------
# synth create mcp
# ---------------------------------------------------------------------------

_MCP_SERVER_TEMPLATE = '''"""MCP server built with FastMCP.

Run this server:
    python server.py            # stdio transport (default)
    python server.py --sse      # SSE transport for web clients

Register in your MCP config (.kiro/settings/mcp.json):
    {{
        "mcpServers": {{
            "{name}": {{
                "command": "python",
                "args": ["{name}/server.py"]
            }}
        }}
    }}
"""

from __future__ import annotations

import json
import os

try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    raise SystemExit(
        "mcp package is not installed. Install it with:\\n"
        "  pip install mcp"
    )

mcp = FastMCP("{name}")


# ---------------------------------------------------------------------------
# Tools — callable functions the LLM can invoke
# ---------------------------------------------------------------------------

@mcp.tool()
def greet(name: str) -> str:
    """Greet a user by name."""
    return f"Hello, {{name}}!"


@mcp.tool()
def add(a: int, b: int) -> int:
    """Add two numbers together."""
    return a + b


@mcp.tool()
def read_file(path: str) -> str:
    """Read the text content of a local file."""
    with open(path, encoding="utf-8") as fh:
        return fh.read()


@mcp.tool()
def write_file(path: str, content: str) -> str:
    """Write text content to a local file."""
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(content)
    return f"Wrote {{len(content)}} chars to {{path}}"


@mcp.tool()
def list_directory(path: str = ".") -> list[str]:
    """List files and directories at the given path."""
    return os.listdir(path)


@mcp.tool()
def search_files(directory: str, pattern: str) -> list[str]:
    """Recursively search for files matching a glob pattern."""
    import glob
    return glob.glob(os.path.join(directory, "**", pattern), recursive=True)


@mcp.tool()
def run_command(command: str, timeout: int = 30) -> str:
    """Run a shell command and return its output."""
    import subprocess
    result = subprocess.run(
        command, shell=True, capture_output=True, text=True,
        timeout=timeout,
    )
    output = result.stdout.strip()
    if result.returncode != 0:
        output += f"\\nSTDERR: {{result.stderr.strip()}}"
    return output


@mcp.tool()
def fetch_url(url: str, max_chars: int = 5000) -> str:
    """Fetch a URL and return its text content."""
    import httpx
    resp = httpx.get(url, follow_redirects=True, timeout=15.0)
    resp.raise_for_status()
    return resp.text[:max_chars]


@mcp.tool()
def json_query(data: str, path: str) -> str:
    """Extract a value from a JSON string using dot-notation path.

    Example: path "users.0.name" extracts the name of the first user.
    """
    obj = json.loads(data)
    for key in path.split("."):
        if isinstance(obj, list):
            obj = obj[int(key)]
        else:
            obj = obj[key]
    return json.dumps(obj, indent=2) if isinstance(obj, (dict, list)) else str(obj)


# ---------------------------------------------------------------------------
# Resources — data the LLM can read
# ---------------------------------------------------------------------------

@mcp.resource("info://status")
def get_status() -> str:
    """Return the current server status."""
    return "Server is running."


@mcp.resource("info://env")
def get_environment() -> str:
    """Return a summary of the server environment."""
    import platform
    return json.dumps({{
        "python": platform.python_version(),
        "platform": platform.platform(),
        "cwd": os.getcwd(),
    }}, indent=2)


# ---------------------------------------------------------------------------
# Prompts — reusable prompt templates
# ---------------------------------------------------------------------------

@mcp.prompt()
def summarize(text: str) -> str:
    """Generate a prompt to summarize the given text."""
    return f"Please summarize the following text concisely:\\n\\n{{text}}"


@mcp.prompt()
def code_review(code: str, language: str = "python") -> str:
    """Generate a prompt to review code."""
    return (
        f"Please review the following {{language}} code for bugs, "
        f"style issues, and potential improvements:\\n\\n```{{language}}\\n{{code}}\\n```"
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    transport = "sse" if "--sse" in sys.argv else "stdio"
    mcp.run(transport=transport)
'''

_MCP_README = '''# {name}

An MCP (Model Context Protocol) server built with [FastMCP](https://github.com/jlowin/fastmcp).

## Setup

```bash
pip install mcp httpx
```

## Run

```bash
python server.py          # stdio (for CLI / IDE integration)
python server.py --sse    # SSE (for web clients)
```

## Register

Add to your MCP config (`.kiro/settings/mcp.json`):

```json
{{
    "mcpServers": {{
        "{name}": {{
            "command": "python",
            "args": ["{name}/server.py"]
        }}
    }}
}}
```

## Included Tools

| Tool | Description |
|------|-------------|
| `greet` | Greet a user by name |
| `add` | Add two numbers |
| `read_file` | Read a local file |
| `write_file` | Write content to a file |
| `list_directory` | List directory contents |
| `search_files` | Recursive glob file search |
| `run_command` | Execute a shell command |
| `fetch_url` | Fetch a URL's content |
| `json_query` | Extract values from JSON with dot-notation |

## Included Resources

| Resource | Description |
|----------|-------------|
| `info://status` | Server status check |
| `info://env` | Server environment info |

## Included Prompts

| Prompt | Description |
|--------|-------------|
| `summarize` | Summarize text concisely |
| `code_review` | Review code for issues |

## Adding Tools

```python
@mcp.tool()
def my_tool(param: str) -> str:
    """Description shown to the LLM."""
    return "result"
```

## Adding Resources

```python
@mcp.resource("data://my-resource")
def my_resource() -> str:
    """A readable data source for the LLM."""
    return "resource content"
```

## Adding Prompts

```python
@mcp.prompt()
def my_prompt(topic: str) -> str:
    """A reusable prompt template."""
    return f"Tell me about {{topic}}"
```
'''


def _create_mcp(name: str) -> None:
    """Scaffold an MCP server project."""
    _ensure_dir(name)

    _write(os.path.join(name, "server.py"), _MCP_SERVER_TEMPLATE.format(name=name))
    _write(os.path.join(name, "README.md"), _MCP_README.format(name=name))

    _success_banner(name, [
        ("server.py", "MCP server with tools, resources, and prompts"),
        ("README.md", "Getting started guide"),
    ])
    _next_steps([
        f"cd {name}",
        "pip install mcp httpx",
        "python server.py",
    ])


# ---------------------------------------------------------------------------
# synth create team
# ---------------------------------------------------------------------------

_TEAM_PY = '''"""SynthAgentSDK multi-agent team architecture."""

from synth import Agent, AgentTeam, tool


# --- Specialist agents ---

@tool
def search_web(query: str) -> str:
    """Search the web for information."""
    # TODO: Replace with your real search implementation
    return f"Search results for: {{query}}"


@tool
def write_file(filename: str, content: str) -> str:
    """Write content to a file."""
    # TODO: Replace with your real file writing logic
    return f"Wrote {{len(content)}} chars to {{filename}}"


researcher = Agent(
    model="claude-sonnet-4-5",
    instructions=(
        "You are an expert researcher. Find accurate, up-to-date "
        "information on any topic using your search tool."
    ),
    tools=[search_web],
)

writer = Agent(
    model="claude-sonnet-4-5",
    instructions=(
        "You are a skilled technical writer. Turn research notes into "
        "clear, well-structured documents."
    ),
    tools=[write_file],
)

reviewer = Agent(
    model="claude-sonnet-4-5",
    instructions=(
        "You are a thorough reviewer. Check for accuracy, clarity, "
        "and completeness. Suggest improvements."
    ),
)


# --- Team orchestration ---

team = AgentTeam(
    orchestrator="claude-sonnet-4-5",
    agents=[researcher, writer, reviewer],
    strategy="auto",
)


if __name__ == "__main__":
    result = team.run(
        "Research Python async best practices and write a short guide."
    )
    print(result.answer)
'''

_PIPELINE_PY = '''"""SynthAgentSDK sequential pipeline example."""

from synth import Agent, Pipeline


researcher = Agent(
    model="claude-sonnet-4-5",
    instructions="You research topics and produce detailed notes.",
)

writer = Agent(
    model="claude-sonnet-4-5",
    instructions="You turn research notes into a well-written article.",
)

editor = Agent(
    model="claude-sonnet-4-5",
    instructions="You edit text for grammar, clarity, and conciseness.",
)

pipeline = Pipeline([researcher, writer, editor])


if __name__ == "__main__":
    result = pipeline.run("The future of AI agents in software development")
    print(result.text)
'''

_TEAM_README = '''# {name}

A multi-agent system built with [SynthAgentSDK](https://pypi.org/project/synth-agent-sdk/).

## Setup

```bash
pip install synth-agent-sdk[anthropic]
export ANTHROPIC_API_KEY="your-key-here"
```

## Run

Team mode (orchestrator decides routing):

```bash
synth run team.py "Research and write a guide on Python testing"
```

Pipeline mode (linear chain):

```bash
synth run pipeline.py "The history of open source software"
```
'''


def _create_team(name: str) -> None:
    """Scaffold a multi-agent team project."""
    _ensure_dir(name)

    _write(os.path.join(name, "team.py"), _TEAM_PY)
    _write(os.path.join(name, "pipeline.py"), _PIPELINE_PY)
    _write(os.path.join(name, "README.md"), _TEAM_README.format(name=name))

    _success_banner(name, [
        ("team.py", "Agent team (researcher + writer + reviewer)"),
        ("pipeline.py", "Sequential pipeline (research > write > edit)"),
        ("README.md", "Getting started guide"),
    ])
    _next_steps([
        f"cd {name}",
        "pip install synth-agent-sdk[anthropic]",
        'export ANTHROPIC_API_KEY="your-key"',
        'synth run team.py "Build a REST API guide"',
    ])


# ---------------------------------------------------------------------------
# synth create ui — local testing UI
# ---------------------------------------------------------------------------


def _create_ui(name: str) -> None:
    """Scaffold a local agent testing UI with a FastAPI bridge."""
    from synth.cli._ui_templates import (
        UI_CSS,
        UI_HTML,
        UI_JS,
        UI_README,
        UI_SERVER,
    )

    _ensure_dir(name)

    _write(os.path.join(name, "server.py"), UI_SERVER)
    os.makedirs(os.path.join(name, "static"))
    _write(os.path.join(name, "static", "index.html"), UI_HTML)
    _write(os.path.join(name, "static", "style.css"), UI_CSS)
    _write(os.path.join(name, "static", "app.js"), UI_JS)
    _write(os.path.join(name, "README.md"), UI_README.format(name=name))

    _success_banner(name, [
        ("server.py", "FastAPI bridge (connects UI to your agent)"),
        ("static/", "Dashboard UI (HTML + CSS + JS)"),
        ("README.md", "Getting started guide"),
    ])
    _next_steps([
        f"cd {name}",
        "pip install uvicorn fastapi",
        "# Edit server.py to point AGENT_FILE at your agent",
        "python server.py",
        "# Open http://localhost:8420 in your browser",
    ])
