"""Rich terminal UI for ``synth dev`` — Fallout-inspired agent interface.

Requires ``rich`` and ``prompt_toolkit`` (included in core dependencies).
Provides streaming responses, slash commands, tool call visualization,
a persistent status bar, and markdown rendering.
"""

from __future__ import annotations

import importlib.util
import json
import os
import sys
import time
from dataclasses import dataclass, field

from rich.console import Console, Group
from rich.markdown import Markdown
from rich.panel import Panel
from rich.rule import Rule
from rich.spinner import Spinner
from rich.style import Style
from rich.table import Table
from rich.text import Text
from prompt_toolkit import PromptSession
from prompt_toolkit.history import InMemoryHistory
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.styles import Style as PTStyle

from synth.errors import SynthError


# ------------------------------------------------------------------
# Theme constants
# ------------------------------------------------------------------

_GREEN = "#39ff14"
_GREEN_DIM = "#1a7a0a"
_AMBER = "#ffb627"
_RED = "#ff4444"
_CYAN = "#00e5ff"
_DIM = "#6a7a8a"

_PT_STYLE = PTStyle.from_dict({
    "prompt": f"{_GREEN} bold",
    "continuation": _DIM,
})


# ------------------------------------------------------------------
# Session state
# ------------------------------------------------------------------

@dataclass
class _SessionState:
    """Mutable state for the TUI session."""

    agent: object | None = None
    agent_file: str = ""
    model_name: str = ""
    thread_id: str = ""
    total_tokens: int = 0
    total_cost: float = 0.0
    turn_count: int = 0
    last_latency_ms: float = 0.0
    last_trace: object | None = None
    tool_names: list[str] = field(default_factory=list)


# ------------------------------------------------------------------
# Slash commands
# ------------------------------------------------------------------

_SLASH_COMMANDS: dict[str, str] = {
    "/help": "Show available commands",
    "/tools": "List registered tools",
    "/reload": "Hot-reload the agent from disk",
    "/trace": "Show the last run's trace summary",
    "/export": "Export the last trace to JSON",
    "/clear": "Clear the conversation",
    "/model": "Show current model info",
    "/cost": "Show cumulative session cost",
    "/quit": "Exit dev mode",
}


def _handle_slash(
    cmd: str,
    console: Console,
    state: _SessionState,
) -> bool:
    """Handle a slash command. Return True if the REPL should exit."""
    parts = cmd.strip().split(maxsplit=1)
    command = parts[0].lower()

    if command == "/quit" or command == "/exit":
        return True

    if command == "/help":
        _show_help(console)
    elif command == "/tools":
        _show_tools(console, state)
    elif command == "/reload":
        _reload_agent(console, state)
    elif command == "/trace":
        _show_trace(console, state)
    elif command == "/export":
        _export_trace(console, state)
    elif command == "/clear":
        console.clear()
        _print_header(console, state)
    elif command == "/model":
        _show_model(console, state)
    elif command == "/cost":
        _show_cost(console, state)
    else:
        console.print(
            f"  Unknown command: {command}. Type /help for options.",
            style=f"bold {_RED}",
        )

    return False


def _show_help(console: Console) -> None:
    """Display slash command reference."""
    table = Table(
        show_header=False,
        box=None,
        padding=(0, 2),
        style=_DIM,
    )
    table.add_column("Command", style=f"bold {_CYAN}")
    table.add_column("Description")
    for cmd, desc in _SLASH_COMMANDS.items():
        table.add_row(cmd, desc)
    console.print("")
    console.print(
        Panel(
            table,
            title="[bold]Commands[/bold]",
            border_style=_GREEN_DIM,
            padding=(1, 2),
        ),
    )
    console.print(
        "  [dim]Tip: Use \\\\ at end of line for multi-line input[/dim]",
    )
    console.print("")


def _show_tools(console: Console, state: _SessionState) -> None:
    """List registered tools with their descriptions."""
    if not state.tool_names:
        console.print(
            "  No tools registered.",
            style=_DIM,
        )
        return

    table = Table(
        show_header=True,
        header_style=f"bold {_GREEN}",
        box=None,
        padding=(0, 2),
    )
    table.add_column("Tool", style=f"bold {_AMBER}")
    table.add_column("Description", style=_DIM)
    table.add_column("Params", style=_DIM)

    agent = state.agent
    tools = getattr(agent, "_registered_tools", {})
    for name, fn in tools.items():
        schema = getattr(fn, "_tool_schema", {})
        desc = schema.get("description", "")[:60]
        params = schema.get("parameters", {}).get("properties", {})
        param_str = ", ".join(params.keys()) if params else "-"
        table.add_row(name, desc, param_str)

    console.print("")
    console.print(
        Panel(
            table,
            title=f"[bold]Registered Tools ({len(state.tool_names)})[/bold]",
            border_style=_GREEN_DIM,
            padding=(1, 2),
        ),
    )
    console.print("")


def _reload_agent(console: Console, state: _SessionState) -> None:
    """Hot-reload the agent from disk."""
    console.print(
        "  Reloading agent...",
        style=f"bold {_AMBER}",
    )
    try:
        agent = _load_agent_module(state.agent_file)
        state.agent = agent
        state.model_name = getattr(agent, "model", "unknown")
        tools = getattr(agent, "_registered_tools", {})
        state.tool_names = list(tools.keys())
        console.print(
            f"  Agent reloaded. Model: {state.model_name}, "
            f"Tools: {len(state.tool_names)}",
            style=f"bold {_GREEN}",
        )
    except Exception as exc:
        console.print(f"  Reload failed: {exc}", style=f"bold {_RED}")


def _show_trace(console: Console, state: _SessionState) -> None:
    """Show the last run's trace summary."""
    trace = state.last_trace
    if trace is None:
        console.print("  No trace available yet.", style=_DIM)
        return

    spans = getattr(trace, "spans", [])
    if not spans:
        console.print("  Trace has no spans.", style=_DIM)
        return

    table = Table(
        show_header=True,
        header_style=f"bold {_GREEN}",
        box=None,
        padding=(0, 2),
    )
    table.add_column("Span", style=f"bold {_CYAN}")
    table.add_column("Type", style=_DIM)
    table.add_column("Duration", style=_AMBER)

    for span in spans:
        name = getattr(span, "name", "?")
        stype = getattr(span, "span_type", "?")
        dur = getattr(span, "duration_ms", 0.0)
        table.add_row(name, stype, f"{dur:.0f}ms")

    console.print("")
    console.print(
        Panel(
            table,
            title="[bold]Last Trace[/bold]",
            border_style=_GREEN_DIM,
            padding=(1, 2),
        ),
    )
    console.print("")


def _export_trace(console: Console, state: _SessionState) -> None:
    """Export the last trace to a JSON file."""
    trace = state.last_trace
    if trace is None:
        console.print("  No trace to export.", style=_DIM)
        return

    try:
        trace.export()
        console.print(
            "  Trace exported.",
            style=f"bold {_GREEN}",
        )
    except Exception as exc:
        console.print(f"  Export failed: {exc}", style=f"bold {_RED}")


def _show_model(console: Console, state: _SessionState) -> None:
    """Show current model information."""
    console.print(f"  Model:  {state.model_name}", style=_CYAN)
    console.print(f"  File:   {state.agent_file}", style=_DIM)
    console.print(
        f"  Tools:  {len(state.tool_names)}",
        style=_DIM,
    )


def _show_cost(console: Console, state: _SessionState) -> None:
    """Show cumulative session cost."""
    console.print(
        f"  Session: {state.turn_count} turns, "
        f"{state.total_tokens} tokens, "
        f"${state.total_cost:.4f}",
        style=_CYAN,
    )


# ------------------------------------------------------------------
# Agent loading
# ------------------------------------------------------------------

def _load_agent_module(file: str) -> object:
    """Import a Python file and return the ``agent`` variable."""
    spec = importlib.util.spec_from_file_location("_agent_module", file)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load '{file}'")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if not hasattr(module, "agent"):
        raise RuntimeError(
            f"'{file}' must define an 'agent' variable.",
        )
    return module.agent


# ------------------------------------------------------------------
# Response rendering
# ------------------------------------------------------------------

def _render_tool_call(
    console: Console,
    name: str,
    args: dict,
    result: str,
    latency_ms: float,
) -> None:
    """Render a tool call block in the terminal."""
    args_str = json.dumps(args, indent=2) if args else "{}"

    tool_text = Text()
    tool_text.append("  ⚡ ", style=f"bold {_AMBER}")
    tool_text.append(name, style=f"bold {_AMBER}")
    tool_text.append(f"  ({latency_ms:.0f}ms)", style=_DIM)
    console.print(tool_text)

    # Args
    if args:
        for line in args_str.split("\n"):
            console.print(f"    {line}", style=_DIM)

    # Result (truncated)
    result_preview = str(result)
    if len(result_preview) > 200:
        result_preview = result_preview[:200] + "..."
    console.print(f"    → {result_preview}", style=_GREEN_DIM)
    console.print("")


def _render_response(
    console: Console,
    result: object,
    state: _SessionState,
) -> None:
    """Render the full agent response with tool calls and metrics."""
    # Tool calls first
    tool_calls = getattr(result, "tool_calls", [])
    if tool_calls:
        console.print("")
        for tc in tool_calls:
            _render_tool_call(
                console,
                tc.name,
                tc.args,
                str(tc.result),
                tc.latency_ms,
            )

    # Response text as markdown
    text = getattr(result, "text", "")
    if text:
        console.print("")
        console.print(
            Panel(
                Markdown(text),
                border_style=_GREEN_DIM,
                padding=(1, 2),
                title="[bold green]AGENT[/bold green]",
                title_align="left",
            ),
        )

    # Metrics line
    tokens = getattr(result, "tokens", None)
    total = getattr(tokens, "total_tokens", 0) if tokens else 0
    cost = getattr(result, "cost", 0.0)
    latency = getattr(result, "latency_ms", 0.0)

    state.total_tokens += total
    state.total_cost += cost
    state.turn_count += 1
    state.last_latency_ms = latency
    state.last_trace = getattr(result, "trace", None)

    metrics = Text()
    metrics.append("  ", style="")
    metrics.append(f"{total} tokens", style=_DIM)
    metrics.append("  │  ", style=_DIM)
    metrics.append(f"${cost:.4f}", style=_DIM)
    metrics.append("  │  ", style=_DIM)
    metrics.append(f"{latency:.0f}ms", style=_DIM)
    metrics.append("  │  ", style=_DIM)
    metrics.append(f"{len(tool_calls)} tool calls", style=_DIM)
    console.print(metrics)
    console.print("")


def _render_streaming_response(
    console: Console,
    agent: object,
    prompt: str,
    state: _SessionState,
) -> None:
    """Stream the agent response with live token rendering."""
    from synth.types import (
        DoneEvent,
        ErrorEvent,
        ThinkingEvent,
        TokenEvent,
        ToolCallEvent,
        ToolResultEvent,
    )

    console.print("")
    accumulated = ""
    tool_calls_rendered = 0

    try:
        for event in agent.stream(prompt, thread_id=state.thread_id):  # type: ignore[union-attr]
            if isinstance(event, TokenEvent):
                # Print tokens as they arrive — green text typing effect
                console.print(
                    event.text,
                    end="",
                    style=_GREEN,
                    highlight=False,
                )
                accumulated += event.text

            elif isinstance(event, ThinkingEvent):
                console.print(
                    event.text,
                    end="",
                    style=f"italic {_DIM}",
                    highlight=False,
                )

            elif isinstance(event, ToolCallEvent):
                # End any in-progress text line
                if accumulated and not accumulated.endswith("\n"):
                    console.print("")
                tool_text = Text()
                tool_text.append("\n  ⚡ ", style=f"bold {_AMBER}")
                tool_text.append(event.name, style=f"bold {_AMBER}")
                args_str = json.dumps(event.args) if event.args else ""
                if args_str:
                    tool_text.append(f"  {args_str}", style=_DIM)
                console.print(tool_text)

            elif isinstance(event, ToolResultEvent):
                result_preview = str(event.result)
                if len(result_preview) > 200:
                    result_preview = result_preview[:200] + "..."
                console.print(
                    f"    → {result_preview}",
                    style=_GREEN_DIM,
                )
                console.print("")
                tool_calls_rendered += 1

            elif isinstance(event, DoneEvent):
                # Final newline after streaming text
                if accumulated and not accumulated.endswith("\n"):
                    console.print("")

                result = event.result
                tokens = getattr(result, "tokens", None)
                total = (
                    getattr(tokens, "total_tokens", 0)
                    if tokens else 0
                )
                cost = getattr(result, "cost", 0.0)
                latency = getattr(result, "latency_ms", 0.0)
                tc_count = len(getattr(result, "tool_calls", []))

                state.total_tokens += total
                state.total_cost += cost
                state.turn_count += 1
                state.last_latency_ms = latency
                state.last_trace = getattr(result, "trace", None)

                metrics = Text()
                metrics.append("\n  ", style="")
                metrics.append(f"{total} tokens", style=_DIM)
                metrics.append("  │  ", style=_DIM)
                metrics.append(f"${cost:.4f}", style=_DIM)
                metrics.append("  │  ", style=_DIM)
                metrics.append(f"{latency:.0f}ms", style=_DIM)
                metrics.append("  │  ", style=_DIM)
                metrics.append(
                    f"{tc_count} tool calls",
                    style=_DIM,
                )
                console.print(metrics)
                console.print("")
                return

            elif isinstance(event, ErrorEvent):
                console.print(
                    f"\n  Error: {event.error}",
                    style=f"bold {_RED}",
                )
                console.print("")
                return

    except SynthError as exc:
        console.print(
            f"\n  Error: {exc}",
            style=f"bold {_RED}",
        )
        if hasattr(exc, "suggestion"):
            console.print(
                f"  Suggestion: {exc.suggestion}",
                style=_AMBER,
            )
        console.print("")
    except Exception as exc:
        console.print(
            f"\n  Unexpected error: {exc}",
            style=f"bold {_RED}",
        )
        console.print("")


# ------------------------------------------------------------------
# Header / status bar
# ------------------------------------------------------------------

_MINI_LOGO = r"""[bold #39ff14]
 ███████╗██╗   ██╗███╗   ██╗████████╗██╗  ██╗     █████╗  ██████╗ ███████╗███╗   ██╗████████╗    ███████╗██████╗ ██╗  ██╗
 ██╔════╝╚██╗ ██╔╝████╗  ██║╚══██╔══╝██║  ██║    ██╔══██╗██╔════╝ ██╔════╝████╗  ██║╚══██╔══╝    ██╔════╝██╔══██╗██║ ██╔╝
 ███████╗ ╚████╔╝ ██╔██╗ ██║   ██║   ███████║    ███████║██║  ███╗█████╗  ██╔██╗ ██║   ██║       ███████╗██║  ██║█████╔╝
 ╚════██║  ╚██╔╝  ██║╚██╗██║   ██║   ██╔══██║    ██╔══██║██║   ██║██╔══╝  ██║╚██╗██║   ██║       ╚════██║██║  ██║██╔═██╗
 ███████║   ██║   ██║ ╚████║   ██║   ██║  ██║    ██║  ██║╚██████╔╝███████╗██║ ╚████║   ██║       ███████║██████╔╝██║  ██╗
 ╚══════╝   ╚═╝   ╚═╝  ╚═══╝   ╚═╝   ╚═╝  ╚═╝    ╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝       ╚══════╝╚═════╝ ╚═╝  ╚═╝[/bold #39ff14]"""


def _print_header(console: Console, state: _SessionState) -> None:
    """Print the TUI header with logo and session info."""
    console.print(_MINI_LOGO)
    console.print("")

    info = Text()
    info.append("  DEV MODE", style=f"bold {_GREEN}")
    info.append("  │  ", style=_DIM)
    info.append(f"Model: {state.model_name}", style=_CYAN)
    info.append("  │  ", style=_DIM)
    info.append(f"Tools: {len(state.tool_names)}", style=_DIM)
    info.append("  │  ", style=_DIM)
    info.append(f"File: {state.agent_file}", style=_DIM)
    console.print(info)

    console.print(
        Rule(style=_GREEN_DIM),
    )
    console.print(
        "  [dim]Type a prompt to chat with your agent. "
        "Use /help for commands. Ctrl+C to exit.[/dim]",
    )
    console.print("")


def _print_status_bar(console: Console, state: _SessionState) -> None:
    """Print the bottom status bar."""
    bar = Text()
    bar.append(" ● ", style=f"bold {_GREEN}")
    bar.append(state.model_name, style=_CYAN)
    bar.append("  │  ", style=_DIM)
    bar.append(f"Turns: {state.turn_count}", style=_DIM)
    bar.append("  │  ", style=_DIM)
    bar.append(f"Tokens: {state.total_tokens}", style=_DIM)
    bar.append("  │  ", style=_DIM)
    bar.append(f"Cost: ${state.total_cost:.4f}", style=_DIM)
    if state.last_latency_ms > 0:
        bar.append("  │  ", style=_DIM)
        bar.append(
            f"Last: {state.last_latency_ms:.0f}ms",
            style=_DIM,
        )
    console.print(Rule(style=_GREEN_DIM))
    console.print(bar)


# ------------------------------------------------------------------
# Main TUI loop
# ------------------------------------------------------------------

def launch_tui(file: str) -> None:
    """Launch the rich terminal UI for interactive agent development.

    Parameters
    ----------
    file:
        Path to the Python file containing the ``agent`` variable.
    """
    import uuid

    console = Console()
    state = _SessionState(
        agent_file=file,
        thread_id=f"synth-dev-{uuid.uuid4().hex[:12]}",
    )

    # Load agent
    console.print("")
    with console.status(
        "[bold green]Loading agent...[/bold green]",
        spinner="dots",
        spinner_style=_GREEN,
    ):
        try:
            agent = _load_agent_module(file)
            state.agent = agent
            state.model_name = getattr(agent, "model", "unknown")
            tools = getattr(agent, "_registered_tools", {})
            state.tool_names = list(tools.keys())
        except Exception as exc:
            console.print(
                f"\n  Failed to load agent: {exc}",
                style=f"bold {_RED}",
            )
            console.print(
                "  Fix the error and run again, or use "
                "/reload after fixing.",
                style=_AMBER,
            )
            state.model_name = "not loaded"

    # Print header
    _print_header(console, state)

    # Set up prompt_toolkit session
    session: PromptSession[str] = PromptSession(
        history=InMemoryHistory(),
        style=_PT_STYLE,
        multiline=False,
    )

    # Main loop
    while True:
        try:
            # Status bar before prompt
            _print_status_bar(console, state)
            console.print("")

            # Read input with prompt_toolkit
            raw = session.prompt(
                HTML(
                    '<style fg="#39ff14" bold="true">'
                    "synth&gt; "
                    "</style>"
                ),
            )

            # Multi-line continuation: lines ending with \
            while raw.rstrip().endswith("\\"):
                raw = raw.rstrip()[:-1] + "\n"
                cont = session.prompt(
                    HTML(
                        '<style fg="#6a7a8a">'
                        "  ...  "
                        "</style>"
                    ),
                )
                raw += cont

            text = raw.strip()
            if not text:
                continue

            # Slash commands
            if text.startswith("/"):
                should_exit = _handle_slash(text, console, state)
                if should_exit:
                    break
                continue

            # Agent not loaded
            if state.agent is None:
                console.print(
                    "  Agent not loaded. Use /reload to try again.",
                    style=f"bold {_RED}",
                )
                continue

            # Print user message
            console.print("")
            user_text = Text()
            user_text.append("  YOU ", style=f"bold {_CYAN}")
            user_text.append(text, style="white")
            console.print(user_text)

            # Stream response
            _render_streaming_response(
                console, state.agent, text, state,
            )

        except KeyboardInterrupt:
            console.print("")
            break
        except EOFError:
            break

    # Exit message
    console.print("")
    console.print(
        Rule(
            title="[bold green]SESSION TERMINATED[/bold green]",
            style=_GREEN_DIM,
        ),
    )
    _show_cost(console, state)
    console.print(
        "  [dim]War. War never changes.[/dim]",
    )
    console.print("")
