"""Trace, TraceSpan, and TraceCollector for the Synth SDK.

Provides structured observability for every agent run.  A ``TraceCollector``
context manager accumulates ``TraceSpan`` objects during execution and
finalises them into a ``Trace`` attached to the ``RunResult``.
"""

from __future__ import annotations

import time
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, AsyncGenerator, Literal


# ---------------------------------------------------------------------------
# TraceSpan
# ---------------------------------------------------------------------------


@dataclass
class TraceSpan:
    """A single span within a trace.

    Parameters
    ----------
    name:
        Human-readable label (e.g. tool name, provider model string).
    type:
        Category of work this span represents.
    start_time:
        UTC timestamp when the span began.
    end_time:
        UTC timestamp when the span completed.
    metadata:
        Arbitrary key-value pairs (token counts, cost, args, etc.).
    """

    name: str
    type: Literal["llm_call", "tool_call", "guard_check", "node_execution"]
    start_time: datetime
    end_time: datetime
    metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Trace
# ---------------------------------------------------------------------------


@dataclass
class Trace:
    """Structured record of all work performed during a single run.

    Attributes
    ----------
    spans:
        Ordered list of spans collected during the run.
    total_tokens:
        Sum of tokens across all LLM call spans.
    total_cost:
        Sum of cost across all LLM call spans.
    total_latency_ms:
        Wall-clock duration of the entire run in milliseconds.
    """

    spans: list[TraceSpan] = field(default_factory=list)
    total_tokens: int = 0
    total_cost: float = 0.0
    total_latency_ms: float = 0.0

    # Convenience methods delegated to the exporter module (Task 9.2).

    def show(self) -> None:
        """Open a visual trace timeline in the default browser."""
        from synth.tracing.exporter import show_trace

        show_trace(self)

    def export(self, path: str | None = None) -> str:
        """Write an OpenTelemetry-compatible JSON file to disk.

        Parameters
        ----------
        path:
            Destination file path.  When ``None`` a timestamped file is
            created in the current directory.

        Returns
        -------
        str
            The absolute path of the written file.
        """
        from synth.tracing.exporter import export_trace

        return export_trace(self, path=path)


# ---------------------------------------------------------------------------
# TraceCollector
# ---------------------------------------------------------------------------


class TraceCollector:
    """Accumulates spans during an agent run and finalises into a Trace.

    Usage::

        collector = TraceCollector()
        collector.start()
        # ... record spans ...
        trace = collector.finalise()
    """

    def __init__(self) -> None:
        self._spans: list[TraceSpan] = []
        self._start_ns: int = 0

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Mark the beginning of the traced run."""
        self._start_ns = time.perf_counter_ns()

    def finalise(self) -> Trace:
        """Finalise collection and return the completed Trace."""
        elapsed_ms = (time.perf_counter_ns() - self._start_ns) / 1_000_000

        total_tokens = 0
        total_cost = 0.0
        for span in self._spans:
            if span.type == "llm_call":
                total_tokens += span.metadata.get("total_tokens", 0)
                total_cost += span.metadata.get("cost", 0.0)

        return Trace(
            spans=list(self._spans),
            total_tokens=total_tokens,
            total_cost=total_cost,
            total_latency_ms=elapsed_ms,
        )

    # ------------------------------------------------------------------
    # Span recording helpers
    # ------------------------------------------------------------------

    def record_span(self, span: TraceSpan) -> None:
        """Append a pre-built span."""
        self._spans.append(span)

    @asynccontextmanager
    async def span(
        self,
        name: str,
        span_type: Literal[
            "llm_call", "tool_call", "guard_check", "node_execution"
        ],
        **extra_metadata: Any,
    ) -> AsyncGenerator[dict[str, Any], None]:
        """Async context manager that times a block and records a span.

        Yields a mutable *metadata* dict so callers can attach results
        (token counts, cost, etc.) discovered during execution.

        Parameters
        ----------
        name:
            Human-readable span label.
        span_type:
            Span category.
        **extra_metadata:
            Initial metadata entries.
        """
        metadata: dict[str, Any] = dict(extra_metadata)
        start = datetime.now(timezone.utc)
        try:
            yield metadata
        finally:
            end = datetime.now(timezone.utc)
            self._spans.append(
                TraceSpan(
                    name=name,
                    type=span_type,
                    start_time=start,
                    end_time=end,
                    metadata=metadata,
                )
            )
