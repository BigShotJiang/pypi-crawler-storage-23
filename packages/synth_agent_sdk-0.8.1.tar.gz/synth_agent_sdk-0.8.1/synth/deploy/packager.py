"""Deployment artifact packaging for the Synth SDK.

Packages agent code, dependencies, and configuration into a deployment
artifact suitable for AWS AgentCore.  Supports ``--dry-run`` validation.
"""

from __future__ import annotations

import json
import os
import re
import shutil
from pathlib import Path
from typing import Any

from synth.deploy.agentcore.manifest import generate_manifest
from synth.errors import SynthConfigError


# Directories/files excluded from deployment artifacts
_EXCLUDED = {
    ".env", ".synth", ".hypothesis", ".pytest_cache",
    "__pycache__", ".git", ".venv", "venv",
}

# Patterns that match AWS credential strings
_AWS_ACCESS_KEY_RE = re.compile(r"(?:AKIA|ASIA)[A-Z0-9]{16}")
_AWS_SECRET_KEY_RE = re.compile(r"[A-Za-z0-9+/]{40}")


def _scan_for_credentials(text: str) -> bool:
    """Return True if *text* contains an AWS access key or secret key pattern."""
    if _AWS_ACCESS_KEY_RE.search(text):
        return True
    if _AWS_SECRET_KEY_RE.search(text):
        return True
    return False


def package(
    agent_or_graph: Any,
    *,
    source_dir: str = ".",
    output_dir: str = "dist",
    dry_run: bool = False,
    name: str | None = None,
    description: str | None = None,
    permissions: list[str] | None = None,
) -> dict[str, Any]:
    """Package an agent for AgentCore deployment.

    Parameters
    ----------
    agent_or_graph:
        The Synth Agent or Graph to package.
    source_dir:
        Root directory of the agent source code.
    output_dir:
        Directory to write the deployment artifact to.
    dry_run:
        If ``True``, validate without creating the artifact.
    name:
        Agent name for the manifest.
    description:
        Agent description for the manifest.
    permissions:
        IAM permissions for the manifest.

    Returns
    -------
    dict
        The generated manifest.

    Raises
    ------
    SynthConfigError
        If validation fails.
    """
    manifest = generate_manifest(
        agent_or_graph,
        name=name,
        description=description,
        permissions=permissions,
    )

    if dry_run:
        return manifest

    src = Path(source_dir)

    # Scan agentcore.yaml for credential patterns before packaging (Req 7.6, 8.4)
    agentcore_yaml = src / "agentcore.yaml"
    if agentcore_yaml.exists():
        content = agentcore_yaml.read_text(encoding="utf-8")
        if _scan_for_credentials(content):
            raise SynthConfigError(
                "agentcore.yaml contains AWS credential patterns. "
                "Remove any access keys or secret keys from the config file.",
                component="Packager",
                suggestion=(
                    "Remove AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, and any "
                    "credential values from agentcore.yaml. Use aws_profile instead."
                ),
            )
    dest = Path(output_dir)
    dest.mkdir(parents=True, exist_ok=True)

    # Copy source files, excluding sensitive/unnecessary dirs
    safe_name = re.sub(r'[:/\\*?"<>|]', "-", manifest["name"])
    artifact_dir = dest / safe_name
    if artifact_dir.exists():
        shutil.rmtree(artifact_dir)
    artifact_dir.mkdir(parents=True)

    # Resolve output dir to avoid copying it into itself
    dest_resolved = dest.resolve()

    for item in src.iterdir():
        if item.name in _EXCLUDED:
            continue
        # Skip the output directory itself to prevent recursive self-copy
        if item.resolve() == dest_resolved:
            continue
        target = artifact_dir / item.name
        if item.is_dir():
            shutil.copytree(item, target, ignore=shutil.ignore_patterns(
                *_EXCLUDED, "*.pyc",
            ))
        else:
            shutil.copy2(item, target)

    # Write manifest
    manifest_path = artifact_dir / "agentcore_manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, indent=2), encoding="utf-8",
    )

    return manifest
