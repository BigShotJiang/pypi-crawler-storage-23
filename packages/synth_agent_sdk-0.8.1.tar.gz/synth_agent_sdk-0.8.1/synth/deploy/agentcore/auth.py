"""AgentCore authentication utilities.

Provides secure user identity extraction from JWT tokens in the AgentCore
Runtime ``RequestContext``, and OAuth2 client credentials flow for
machine-to-machine Gateway authentication.

Security note: user identity is always extracted from the validated JWT
token in the request context, never from the payload body, to prevent
impersonation via prompt injection.
"""

from __future__ import annotations

import base64
import logging
import os
from typing import Any

from synth.errors import SynthConfigError

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# User identity extraction
# ---------------------------------------------------------------------------

def extract_user_id(context: Any) -> str:
    """Extract the user ID from the JWT token in the AgentCore RequestContext.

    AgentCore Runtime validates the JWT before passing it to the agent, so
    signature verification is skipped here.  The ``sub`` claim is used as
    the user identifier rather than any value from the payload body, which
    prevents impersonation via prompt injection.

    Parameters
    ----------
    context:
        The ``RequestContext`` provided by AgentCore Runtime.

    Returns
    -------
    str
        The ``sub`` claim from the validated JWT token.

    Raises
    ------
    SynthConfigError
        If the Authorization header is missing or the JWT has no ``sub``.

    Examples
    --------
    >>> user_id = extract_user_id(context)
    """
    try:
        import jwt as pyjwt
    except ImportError:
        raise SynthConfigError(
            message="PyJWT is not installed. Run: pip install synth-agent-sdk[agentcore]",
            component="extract_user_id",
            suggestion="pip install synth-agent-sdk[agentcore]",
        )

    request_headers = getattr(context, "request_headers", None) or {}

    auth_header = request_headers.get("Authorization") or request_headers.get(
        "authorization"
    )
    if not auth_header:
        raise SynthConfigError(
            message=(
                "No Authorization header found in AgentCore RequestContext. "
                "Ensure the Runtime is configured with JWT inbound auth and "
                "the Authorization header is in the request header allowlist."
            ),
            component="extract_user_id",
            suggestion=(
                "Configure the AgentCore Runtime with JWT inbound authentication."
            ),
        )

    token = (
        auth_header[len("Bearer "):] if auth_header.startswith("Bearer ") else auth_header
    )

    # Runtime already validated the token — skip signature verification.
    claims = pyjwt.decode(
        jwt=token,
        options={"verify_signature": False},
        algorithms=["RS256"],
    )

    user_id = claims.get("sub")
    if not user_id:
        raise SynthConfigError(
            message="JWT token does not contain a 'sub' claim.",
            component="extract_user_id",
            suggestion="Ensure the Cognito user pool includes the 'sub' claim in tokens.",
        )

    logger.debug("Extracted user_id from JWT: %s", user_id)
    return user_id


# ---------------------------------------------------------------------------
# Gateway OAuth2 token
# ---------------------------------------------------------------------------

def get_gateway_token(stack_name: str | None = None) -> str:
    """Obtain an OAuth2 access token for AgentCore Gateway authentication.

    Uses the client credentials flow (machine-to-machine) with Cognito
    credentials stored in SSM Parameter Store and Secrets Manager.

    Parameters
    ----------
    stack_name:
        The deployed stack name.  Defaults to the ``STACK_NAME`` env var.

    Returns
    -------
    str
        A valid OAuth2 Bearer token for Gateway requests.

    Raises
    ------
    SynthConfigError
        If ``STACK_NAME`` is not set or credentials cannot be retrieved.

    Examples
    --------
    >>> token = get_gateway_token()
    """
    try:
        import requests as _requests
    except ImportError:
        raise SynthConfigError(
            message="requests is not installed. Run: pip install synth-agent-sdk[agentcore]",
            component="get_gateway_token",
            suggestion="pip install synth-agent-sdk[agentcore]",
        )

    from synth.deploy.agentcore.ssm import get_ssm_parameter

    _stack = stack_name or os.environ.get("STACK_NAME")
    if not _stack:
        raise SynthConfigError(
            message="STACK_NAME environment variable is required for Gateway auth.",
            component="get_gateway_token",
            suggestion="Set the STACK_NAME environment variable to your deployed stack name.",
        )

    region = os.environ.get("AWS_REGION", os.environ.get("AWS_DEFAULT_REGION", "us-east-1"))

    cognito_domain = get_ssm_parameter(f"/{_stack}/cognito_provider")
    client_id = get_ssm_parameter(f"/{_stack}/machine_client_id")
    client_secret = _get_secret(f"/{_stack}/machine_client_secret", region)

    token_url = f"https://{cognito_domain}/oauth2/token"
    credentials = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()

    response = _requests.post(
        url=token_url,
        headers={
            "Authorization": f"Basic {credentials}",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        data={
            "grant_type": "client_credentials",
            "scope": f"{_stack}-gateway/read {_stack}-gateway/write",
        },
        timeout=30,
    )

    if response.status_code != 200:
        raise SynthConfigError(
            message=f"Gateway token request failed: {response.status_code}",
            component="get_gateway_token",
            suggestion="Check Cognito client credentials in SSM and Secrets Manager.",
        )

    token_data = response.json()
    access_token = token_data.get("access_token")
    if not access_token:
        raise SynthConfigError(
            message="No access_token in Cognito response.",
            component="get_gateway_token",
            suggestion="Verify the Cognito machine client is configured correctly.",
        )

    logger.debug("Gateway access token obtained successfully.")
    return access_token


def _get_secret(secret_name: str, region: str) -> str:
    """Fetch a secret from AWS Secrets Manager."""
    try:
        import boto3
    except ImportError:
        raise SynthConfigError(
            message="boto3 is not installed. Run: pip install synth-agent-sdk[agentcore]",
            component="_get_secret",
            suggestion="pip install synth-agent-sdk[agentcore]",
        )

    client = boto3.client("secretsmanager", region_name=region)
    try:
        return client.get_secret_value(SecretId=secret_name)["SecretString"]
    except Exception as exc:
        raise SynthConfigError(
            message=f"Failed to retrieve secret '{secret_name}': {exc}",
            component="_get_secret",
            suggestion="Ensure the secret exists in Secrets Manager and IAM permissions allow access.",
        ) from exc
