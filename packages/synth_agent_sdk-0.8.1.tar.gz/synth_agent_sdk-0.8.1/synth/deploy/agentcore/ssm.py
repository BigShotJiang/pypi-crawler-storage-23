"""AWS SSM Parameter Store utilities for AgentCore deployments.

Provides a helper for fetching runtime configuration values (Gateway URLs,
Cognito endpoints, etc.) from SSM Parameter Store — the correct pattern
for AgentCore deployments where config is set during CDK deployment.
"""

from __future__ import annotations

import logging
import os

from synth.errors import SynthConfigError

logger = logging.getLogger(__name__)


def get_ssm_parameter(parameter_name: str) -> str:
    """Fetch a parameter value from AWS SSM Parameter Store.

    Parameters
    ----------
    parameter_name:
        The full SSM parameter path, e.g. ``/my-stack/gateway_url``.

    Returns
    -------
    str
        The parameter value.

    Raises
    ------
    SynthConfigError
        If the parameter is not found or cannot be retrieved.

    Examples
    --------
    >>> gateway_url = get_ssm_parameter("/my-stack/gateway_url")
    """
    try:
        import boto3
    except ImportError:
        raise SynthConfigError(
            message="boto3 is not installed. Run: pip install synth-agent-sdk[agentcore]",
            component="get_ssm_parameter",
            suggestion="pip install synth-agent-sdk[agentcore]",
        )

    region = os.environ.get("AWS_REGION", os.environ.get("AWS_DEFAULT_REGION", "us-east-1"))
    ssm = boto3.client("ssm", region_name=region)

    try:
        response = ssm.get_parameter(Name=parameter_name)
        value: str = response["Parameter"]["Value"]
        logger.debug("SSM parameter retrieved: %s", parameter_name)
        return value
    except ssm.exceptions.ParameterNotFound:
        raise SynthConfigError(
            message=f"SSM parameter not found: '{parameter_name}'",
            component="get_ssm_parameter",
            suggestion=(
                f"Ensure the parameter '{parameter_name}' exists in SSM. "
                "It is typically created by the CDK deployment."
            ),
        )
    except Exception as exc:
        raise SynthConfigError(
            message=f"Failed to retrieve SSM parameter '{parameter_name}': {exc}",
            component="get_ssm_parameter",
            suggestion="Check IAM permissions allow ssm:GetParameter for this parameter.",
        ) from exc
