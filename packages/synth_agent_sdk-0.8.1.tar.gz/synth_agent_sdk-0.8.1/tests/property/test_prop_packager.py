"""Property-based tests for packager credential scanning.

**Property 15: Packager credential scan rejects credential patterns**
**Validates: Requirements 7.6, 8.4**

For any ``agentcore.yaml`` content that contains a string matching an AWS
access key (AKIA/ASIA + 16 alphanumeric chars) or secret key (40-char
base64-like string), the Packager should raise a ``SynthConfigError`` and
not produce a deployment artifact.

# Feature: agentcore-init-enhancements, Property 15: Packager credential scan rejects credential patterns
"""

from __future__ import annotations

import string
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from synth.deploy.packager import _scan_for_credentials
from synth.errors import SynthConfigError


# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------

_ALPHANUM_UPPER = string.ascii_uppercase + string.digits

# Generate valid AKIA/ASIA access key IDs (prefix + 16 uppercase alphanumeric)
_ACCESS_KEY_STRATEGY = st.builds(
    lambda prefix, suffix: prefix + suffix,
    prefix=st.sampled_from(["AKIA", "ASIA"]),
    suffix=st.text(alphabet=_ALPHANUM_UPPER, min_size=16, max_size=16),
)

# Generate 40-char base64-like secret keys
_SECRET_KEY_STRATEGY = st.text(
    alphabet=string.ascii_letters + string.digits + "+/",
    min_size=40,
    max_size=40,
)

# Surrounding context (yaml-like noise that doesn't itself match)
_YAML_NOISE = st.text(
    alphabet=string.ascii_lowercase + string.digits + "_: -\n",
    max_size=50,
)


# ---------------------------------------------------------------------------
# Property 15: Packager credential scan rejects credential patterns
# ---------------------------------------------------------------------------


class TestPackagerCredentialScanProperty:
    """Property 15: Packager credential scan rejects credential patterns.

    **Validates: Requirements 7.6, 8.4**
    """

    @given(key=_ACCESS_KEY_STRATEGY, noise=_YAML_NOISE)
    @settings(max_examples=100)
    def test_access_key_always_detected(self, key: str, noise: str) -> None:
        """For any AKIA/ASIA access key embedded in text, scan returns True.

        **Property 15: Packager credential scan rejects credential patterns**
        **Validates: Requirements 7.6, 8.4**
        """
        text = f"{noise}access_key: {key}\n{noise}"
        assert _scan_for_credentials(text) is True, (
            f"Expected credential detected in: {text!r}"
        )

    @given(secret=_SECRET_KEY_STRATEGY, noise=_YAML_NOISE)
    @settings(max_examples=100)
    def test_secret_key_always_detected(self, secret: str, noise: str) -> None:
        """For any 40-char base64-like secret embedded in text, scan returns True.

        **Property 15: Packager credential scan rejects credential patterns**
        **Validates: Requirements 7.6, 8.4**
        """
        text = f"{noise}secret: {secret}\n{noise}"
        assert _scan_for_credentials(text) is True, (
            f"Expected credential detected in: {text!r}"
        )

    @given(key=_ACCESS_KEY_STRATEGY, noise=_YAML_NOISE)
    @settings(max_examples=100)
    def test_package_raises_synth_config_error_for_access_key(
        self, key: str, noise: str
    ) -> None:
        """package() raises SynthConfigError for any agentcore.yaml with an access key.

        **Property 15: Packager credential scan rejects credential patterns**
        **Validates: Requirements 7.6, 8.4**
        """
        yaml_content = f"aws_region: us-east-1\naccess_key: {key}\n"

        manifest = {
            "name": "test-agent",
            "description": "test",
            "permissions": [],
            "runtime": {},
            "environment": {},
        }
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            (tmp_path / "agentcore.yaml").write_text(yaml_content, encoding="utf-8")

            with patch(
                "synth.deploy.packager.generate_manifest", return_value=manifest
            ):
                from synth.deploy.packager import package

                with pytest.raises(SynthConfigError) as exc_info:
                    package(
                        object(),
                        source_dir=str(tmp_path),
                        output_dir=str(tmp_path / "dist"),
                    )

            assert exc_info.value.component == "Packager"
            # No artifact directory should have been created
            assert not (tmp_path / "dist" / "test-agent").exists()
