"""Property-based tests for the tracing system.

**Property 24: Trace completeness**
**Validates: Requirements 10.1**

**Property 25: Trace export produces valid OTEL JSON**
**Validates: Requirements 10.3**
"""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from pathlib import Path

from hypothesis import given, settings
from hypothesis import strategies as st

from synth.tracing.trace import Trace, TraceCollector, TraceSpan


# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------

_SPAN_TYPES = st.sampled_from(["llm_call", "tool_call", "guard_check", "node_execution"])


def _span_strategy():
    """Generate a random TraceSpan."""
    return st.builds(
        TraceSpan,
        name=st.text(min_size=1, max_size=20),
        type=_SPAN_TYPES,
        start_time=st.just(datetime.now(timezone.utc)),
        end_time=st.just(datetime.now(timezone.utc)),
        metadata=st.fixed_dictionaries({
            "total_tokens": st.integers(min_value=0, max_value=1000),
            "cost": st.floats(min_value=0.0, max_value=1.0, allow_nan=False),
        }),
    )


# ---------------------------------------------------------------------------
# Property 24: Trace completeness
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    n_llm=st.integers(min_value=0, max_value=5),
    n_tool=st.integers(min_value=0, max_value=5),
)
def test_trace_completeness(n_llm: int, n_tool: int):
    """Property 24: Trace completeness.

    For any completed run, the RunResult.trace should contain one span
    for each LLM call and one span for each tool call made during the
    run, with valid timestamps and token counts.

    **Validates: Requirements 10.1**
    """
    collector = TraceCollector()
    collector.start()

    now = datetime.now(timezone.utc)

    for i in range(n_llm):
        collector.record_span(TraceSpan(
            name=f"llm_{i}", type="llm_call",
            start_time=now, end_time=now,
            metadata={"total_tokens": 50, "cost": 0.01},
        ))

    for i in range(n_tool):
        collector.record_span(TraceSpan(
            name=f"tool_{i}", type="tool_call",
            start_time=now, end_time=now,
            metadata={"latency_ms": 5.0},
        ))

    trace = collector.finalise()

    # Span count matches
    assert len(trace.spans) == n_llm + n_tool

    # LLM spans counted in totals
    llm_spans = [s for s in trace.spans if s.type == "llm_call"]
    tool_spans = [s for s in trace.spans if s.type == "tool_call"]
    assert len(llm_spans) == n_llm
    assert len(tool_spans) == n_tool

    # Token totals are correct
    assert trace.total_tokens == n_llm * 50
    assert trace.total_latency_ms >= 0


# ---------------------------------------------------------------------------
# Property 25: Trace export produces valid OTEL JSON
# ---------------------------------------------------------------------------


@settings(max_examples=50)
@given(
    n_spans=st.integers(min_value=0, max_value=5),
)
def test_trace_export_produces_valid_otel_json(
    n_spans: int, tmp_path_factory,
):
    """Property 25: Trace export produces valid OTEL JSON.

    For any Trace object, calling trace.export() should produce a JSON
    file that conforms to the OpenTelemetry trace data model.

    **Validates: Requirements 10.3**
    """
    tmp_path = tmp_path_factory.mktemp("otel")
    now = datetime.now(timezone.utc)

    spans = [
        TraceSpan(
            name=f"span_{i}", type="llm_call",
            start_time=now, end_time=now,
            metadata={"total_tokens": 10},
        )
        for i in range(n_spans)
    ]

    trace = Trace(
        spans=spans,
        total_tokens=n_spans * 10,
        total_cost=0.0,
        total_latency_ms=1.0,
    )

    dest = tmp_path / "trace.json"
    result_path = trace.export(path=str(dest))

    # File exists and is valid JSON
    assert Path(result_path).exists()
    data = json.loads(Path(result_path).read_text(encoding="utf-8"))

    # OTEL structure
    assert "resourceSpans" in data
    resource_spans = data["resourceSpans"]
    assert len(resource_spans) == 1

    scope_spans = resource_spans[0]["scopeSpans"]
    assert len(scope_spans) == 1

    otel_spans = scope_spans[0]["spans"]
    assert len(otel_spans) == n_spans

    # Each span has required OTEL fields
    for span in otel_spans:
        assert "traceId" in span
        assert "spanId" in span
        assert "name" in span
        assert "startTimeUnixNano" in span
        assert "endTimeUnixNano" in span
