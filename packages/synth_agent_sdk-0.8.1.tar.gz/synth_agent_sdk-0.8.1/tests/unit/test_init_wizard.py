"""Tests for ``synth.cli.init_cmd`` — project initializer.

Covers ``_build_agentcore_yaml`` and the ``agentcore_setup`` parameter
added to ``_generate_project`` in the agentcore-init-enhancements spec.
"""
from __future__ import annotations

import os
import tempfile

import pytest

from synth.cli.init_cmd import _build_agentcore_yaml, _generate_project

# ---------------------------------------------------------------------------
# _build_agentcore_yaml
# ---------------------------------------------------------------------------


class TestBuildAgentcoreYaml:
    """Unit tests for ``_build_agentcore_yaml``."""

    def test_defaults_when_setup_empty(self) -> None:
        """Empty setup dict produces sensible defaults."""
        yaml = _build_agentcore_yaml("my-agent", {})
        assert "aws_region: us-east-1" in yaml
        assert "us.anthropic.claude-sonnet-4-5-20250929-v1:0" in yaml
        assert "cris_enabled: false" in yaml
        assert "agent_name: my-agent" in yaml

    def test_all_fields_written(self) -> None:
        """All four setup fields are reflected in the output."""
        setup = {
            "aws_region": "eu-west-1",
            "model_id": "anthropic.claude-3-5-haiku-20241022-v1:0",
            "cris_enabled": False,
            "aws_profile": "my-profile",
        }
        yaml = _build_agentcore_yaml("proj", setup)
        assert "aws_region: eu-west-1" in yaml
        assert "anthropic.claude-3-5-haiku-20241022-v1:0" in yaml
        assert "cris_enabled: false" in yaml
        assert "aws_profile: my-profile" in yaml

    def test_cris_enabled_true(self) -> None:
        """``cris_enabled: true`` is written when setup flag is True."""
        setup = {
            "aws_region": "ap-southeast-1",
            "model_id": "us.anthropic.claude-opus-4-20250514-v1:0",
            "cris_enabled": True,
        }
        yaml = _build_agentcore_yaml("proj", setup)
        assert "cris_enabled: true" in yaml

    def test_aws_profile_omitted_when_none(self) -> None:
        """``aws_profile`` line is absent when not provided."""
        yaml = _build_agentcore_yaml("proj", {"aws_profile": None})
        assert "aws_profile" not in yaml

    def test_aws_profile_omitted_when_missing_from_setup(self) -> None:
        """``aws_profile`` line is absent when key not in setup dict."""
        yaml = _build_agentcore_yaml("proj", {})
        assert "aws_profile" not in yaml

    def test_required_iam_permissions_present(self) -> None:
        """Generated YAML includes the required IAM permission entries."""
        yaml = _build_agentcore_yaml("proj", {})
        assert "bedrock:InvokeModel" in yaml
        assert "bedrock-agentcore:*" in yaml

    def test_agent_name_in_output(self) -> None:
        """The project name is embedded in the YAML."""
        yaml = _build_agentcore_yaml("cool-bot", {})
        assert "agent_name: cool-bot" in yaml

    @pytest.mark.parametrize("region", ["us-east-1", "us-west-2", "eu-central-1"])
    def test_region_written_correctly(self, region: str) -> None:
        """Any region string is written verbatim."""
        yaml = _build_agentcore_yaml("proj", {"aws_region": region})
        assert f"aws_region: {region}" in yaml

    def test_no_credential_values_in_output(self) -> None:
        """Credential key values must never appear in the YAML output."""
        setup = {
            "aws_region": "us-east-1",
            "model_id": "some-model",
            "cris_enabled": False,
            "aws_profile": "default",
        }
        yaml = _build_agentcore_yaml("proj", setup)
        # Access key patterns must not appear
        assert "AKIA" not in yaml
        assert "ASIA" not in yaml


# ---------------------------------------------------------------------------
# _generate_project — agentcore_setup integration
# ---------------------------------------------------------------------------


class TestGenerateProjectAgentcoreSetup:
    """Tests for the ``agentcore_setup`` parameter in ``_generate_project``."""

    _BASE_CFG: dict = {
        "display": "AWS AgentCore",
        "model": "us.anthropic.claude-sonnet-4-5-20250514-v1:0",
        "extra": "agentcore",
        "env_var": "",
    }

    def _run(
        self,
        tmp_path: str,
        name: str,
        agentcore_setup: dict | None,
    ) -> None:
        orig = os.getcwd()
        os.chdir(tmp_path)
        try:
            _generate_project(
                name=name,
                description="Test agent",
                provider="agentcore",
                cfg=self._BASE_CFG,
                features=[],
                instructions="You are helpful.",
                agentcore_setup=agentcore_setup,
            )
        finally:
            os.chdir(orig)

    def test_agentcore_yaml_created_for_agentcore_provider(
        self, tmp_path: pytest.TempPathFactory
    ) -> None:
        """``agentcore.yaml`` is written when provider is agentcore."""
        self._run(str(tmp_path), "myagent", {})
        assert os.path.exists(os.path.join(str(tmp_path), "myagent", "agentcore.yaml"))

    def test_agentcore_yaml_contains_setup_region(
        self, tmp_path: pytest.TempPathFactory
    ) -> None:
        """Region from ``agentcore_setup`` appears in ``agentcore.yaml``."""
        setup = {
            "aws_region": "ap-northeast-1",
            "model_id": "anthropic.claude-3-5-haiku-20241022-v1:0",
            "cris_enabled": False,
        }
        self._run(str(tmp_path), "myagent", setup)
        with open(os.path.join(str(tmp_path), "myagent", "agentcore.yaml")) as fh:
            content = fh.read()
        assert "aws_region: ap-northeast-1" in content

    def test_agentcore_yaml_defaults_when_setup_none(
        self, tmp_path: pytest.TempPathFactory
    ) -> None:
        """``agentcore_setup=None`` falls back to defaults without error."""
        self._run(str(tmp_path), "myagent", None)
        with open(os.path.join(str(tmp_path), "myagent", "agentcore.yaml")) as fh:
            content = fh.read()
        assert "aws_region: us-east-1" in content

    def test_env_template_also_created(
        self, tmp_path: pytest.TempPathFactory
    ) -> None:
        """``.env.template`` is still written alongside ``agentcore.yaml``."""
        self._run(str(tmp_path), "myagent", {})
        assert os.path.exists(
            os.path.join(str(tmp_path), "myagent", ".env.template")
        )

    def test_agentcore_yaml_not_created_for_other_providers(
        self, tmp_path: pytest.TempPathFactory
    ) -> None:
        """``agentcore.yaml`` is NOT written for non-agentcore providers."""
        orig = os.getcwd()
        os.chdir(str(tmp_path))
        try:
            _generate_project(
                name="myagent",
                description="Test",
                provider="anthropic",
                cfg={
                    "display": "Anthropic",
                    "model": "claude-3-5-sonnet-20241022",
                    "extra": "anthropic",
                    "env_var": "ANTHROPIC_API_KEY",
                },
                features=[],
                instructions="You are helpful.",
                agentcore_setup=None,
            )
        finally:
            os.chdir(orig)
        assert not os.path.exists(
            os.path.join(str(tmp_path), "myagent", "agentcore.yaml")
        )

    def test_agentcore_yaml_contains_cris_profile_id(
        self, tmp_path: pytest.TempPathFactory
    ) -> None:
        """CRIS profile ID is written to ``agentcore.yaml`` when cris_enabled."""
        setup = {
            "aws_region": "eu-west-1",
            "model_id": "us.anthropic.claude-opus-4-20250514-v1:0",
            "cris_enabled": True,
        }
        self._run(str(tmp_path), "myagent", setup)
        with open(os.path.join(str(tmp_path), "myagent", "agentcore.yaml")) as fh:
            content = fh.read()
        assert "cris_enabled: true" in content
        assert "us.anthropic.claude-opus-4-20250514-v1:0" in content


# ---------------------------------------------------------------------------
# _run_model_selection and _run_credential_check
# ---------------------------------------------------------------------------

from dataclasses import dataclass
from unittest.mock import MagicMock, patch

import click
from click.testing import CliRunner

from synth.cli.init_cmd import _run_model_selection, _run_credential_check
from synth.deploy.agentcore.model_catalog import ModelEntry

# Patch targets — imports are lazy (inside function body), so patch the source modules
_RESOLVER_PATH = "synth.deploy.agentcore.credentials.CredentialResolver"
_CATALOG_PATH = "synth.deploy.agentcore.model_catalog.ModelCatalog"
_VALIDATOR_PATH = "synth.deploy.agentcore.model_catalog.RegionValidator"

# Default single-model list used when tests don't need specific models
_DEFAULT_MODELS = [
    ModelEntry(
        model_id="anthropic.claude-3-5-haiku-20241022-v1:0",
        display_name="Claude 3.5 Haiku",
        native_regions=["us-east-1"],
        cris_regions=["eu-central-1"],
        cris_profile_id="us.anthropic.claude-3-5-haiku-20241022-v1:0",
    ),
]


@dataclass
class _FakeCreds:
    source: str
    account_id: str
    profile_name: str | None


def _make_model_selection_cmd(
    provider: str = "agentcore",
    cfg: dict | None = None,
) -> click.BaseCommand:
    """Wrap ``_run_model_selection`` in a Click command for CliRunner."""
    if cfg is None:
        cfg = {
            "display": "AWS AgentCore",
            "model": "us.anthropic.claude-sonnet-4-5-20250514-v1:0",
            "extra": "agentcore",
            "env_var": "",
        }

    @click.command()
    def cmd():
        agentcore_state: dict = {}
        model_id = _run_model_selection(provider, cfg, agentcore_state)
        click.echo(f"model_id={model_id}")
        for k, v in agentcore_state.items():
            click.echo(f"{k}={v}")

    return cmd


def _make_credential_check_cmd() -> click.BaseCommand:
    """Wrap ``_run_credential_check`` in a Click command for CliRunner."""
    @click.command()
    def cmd():
        result = _run_credential_check()
        for k, v in result.items():
            click.echo(f"{k}={v}")

    return cmd


def _mock_resolver(creds=None) -> MagicMock:
    mock = MagicMock()
    mock.return_value.resolve.return_value = creds
    mock.return_value.mask_account_id.return_value = "****1234"
    mock.return_value.resolve_profile.return_value = creds
    mock.return_value.list_available_profiles.return_value = []
    return mock


def _mock_catalog_and_validator(
    models=None,
    requires_cris: bool = False,
    effective_id: str | None = None,
) -> tuple[MagicMock, MagicMock]:
    models = models or _DEFAULT_MODELS
    mock_catalog = MagicMock()
    mock_catalog.return_value.MODELS = models

    mock_validator = MagicMock()
    inst = mock_validator.return_value
    inst.models_for_region.return_value = models
    inst.availability_unknown_for_region.return_value = False
    inst.requires_cris.return_value = requires_cris
    inst.effective_model_id.return_value = effective_id or models[0].model_id
    return mock_catalog, mock_validator


class TestRunModelSelection:
    """Unit tests for ``_run_model_selection`` interactive flow."""

    def test_agentcore_region_prompt_defaults_to_us_east_1(self) -> None:
        """Accepting the default region prompt yields us-east-1."""
        mock_catalog, mock_validator = _mock_catalog_and_validator()

        with patch(_CATALOG_PATH, mock_catalog), \
             patch(_VALIDATOR_PATH, mock_validator):
            out = CliRunner().invoke(
                _make_model_selection_cmd(), input="\n1\n",
            )

        assert out.exit_code == 0, out.output
        assert "aws_region=us-east-1" in out.output

    def test_agentcore_model_list_displayed(self) -> None:
        """Model selection list shows a numbered entry per catalog model."""
        models = [
            ModelEntry("m1", "Model Alpha", ["us-east-1"], [], ""),
            ModelEntry("m2", "Model Beta", ["us-east-1"], [], ""),
        ]
        mock_catalog, mock_validator = _mock_catalog_and_validator(models)

        with patch(_CATALOG_PATH, mock_catalog), \
             patch(_VALIDATOR_PATH, mock_validator):
            out = CliRunner().invoke(
                _make_model_selection_cmd(), input="us-east-1\n1\n",
            )

        assert out.exit_code == 0, out.output
        assert "Model Alpha" in out.output
        assert "Model Beta" in out.output

    def test_agentcore_cris_notice_shown(self) -> None:
        """CRIS notice is displayed and cris_enabled=True in agentcore_state."""
        models = [
            ModelEntry(
                "anthropic.claude-opus-4-20250514-v1:0",
                "Claude Opus 4",
                ["us-east-1"],
                ["eu-central-1"],
                "us.anthropic.claude-opus-4-20250514-v1:0",
            ),
        ]
        mock_catalog, mock_validator = _mock_catalog_and_validator(
            models,
            requires_cris=True,
            effective_id="us.anthropic.claude-opus-4-20250514-v1:0",
        )

        with patch(_CATALOG_PATH, mock_catalog), \
             patch(_VALIDATOR_PATH, mock_validator):
            out = CliRunner().invoke(
                _make_model_selection_cmd(), input="eu-central-1\n1\n",
            )

        assert out.exit_code == 0, out.output
        assert "CRIS" in out.output or "cris" in out.output.lower()
        assert "cris_enabled=True" in out.output

    def test_agentcore_bedrock_prefix_applied(self) -> None:
        """Returned model ID has the bedrock/ prefix."""
        mock_catalog, mock_validator = _mock_catalog_and_validator()

        with patch(_CATALOG_PATH, mock_catalog), \
             patch(_VALIDATOR_PATH, mock_validator):
            out = CliRunner().invoke(
                _make_model_selection_cmd(), input="us-east-1\n1\n",
            )

        assert out.exit_code == 0, out.output
        assert "model_id=bedrock/" in out.output

    def test_agentcore_populates_agentcore_state(self) -> None:
        """agentcore_state receives aws_region and cris_enabled."""
        mock_catalog, mock_validator = _mock_catalog_and_validator()

        with patch(_CATALOG_PATH, mock_catalog), \
             patch(_VALIDATOR_PATH, mock_validator):
            out = CliRunner().invoke(
                _make_model_selection_cmd(), input="us-east-1\n1\n",
            )

        assert out.exit_code == 0, out.output
        assert "aws_region=" in out.output
        assert "cris_enabled=" in out.output

    def test_agentcore_unknown_region_shows_warning(self) -> None:
        """Unknown region triggers the availability-unknown warning."""
        mock_catalog, mock_validator = _mock_catalog_and_validator()
        mock_validator.return_value.availability_unknown_for_region.return_value = True

        with patch(_CATALOG_PATH, mock_catalog), \
             patch(_VALIDATOR_PATH, mock_validator):
            out = CliRunner().invoke(
                _make_model_selection_cmd(), input="xx-unknown-9\n1\n",
            )

        assert out.exit_code == 0, out.output
        assert "could not be verified" in out.output or "Warning" in out.output

    def test_non_agentcore_returns_cfg_model(self) -> None:
        """Non-AgentCore providers return cfg['model'] directly."""
        cfg = {"model": "claude-3-5-sonnet-20241022", "display": "Anthropic"}
        cmd = _make_model_selection_cmd(provider="anthropic", cfg=cfg)
        out = CliRunner().invoke(cmd)

        assert out.exit_code == 0, out.output
        assert "model_id=claude-3-5-sonnet-20241022" in out.output


class TestRunCredentialCheck:
    """Unit tests for ``_run_credential_check`` interactive flow."""

    def test_credentials_found_user_confirms(self) -> None:
        """When credentials are found and user confirms, profile_name is used."""
        creds = _FakeCreds(
            source="aws_file", account_id="123456781234",
            profile_name="default",
        )
        mock_resolver = _mock_resolver(creds)

        with patch(_RESOLVER_PATH, mock_resolver):
            out = CliRunner().invoke(
                _make_credential_check_cmd(), input="y\n",
            )

        assert out.exit_code == 0, out.output
        assert "aws_profile=default" in out.output

    def test_credentials_found_user_declines_enters_profile(self) -> None:
        """When user declines detected creds, they can enter a custom profile."""
        creds = _FakeCreds(
            source="env", account_id="123456781234",
            profile_name=None,
        )
        mock_resolver = _mock_resolver(creds)

        with patch(_RESOLVER_PATH, mock_resolver):
            out = CliRunner().invoke(
                _make_credential_check_cmd(),
                input="n\nmy-custom-profile\n",
            )

        assert out.exit_code == 0, out.output
        assert "aws_profile=my-custom-profile" in out.output

    def test_no_credentials_found_shows_warning(self) -> None:
        """When no credentials are found, a warning with aws configure is shown."""
        mock_resolver = _mock_resolver(None)

        with patch(_RESOLVER_PATH, mock_resolver):
            out = CliRunner().invoke(
                _make_credential_check_cmd(), input="\n",
            )

        assert out.exit_code == 0, out.output
        assert "aws configure" in out.output


# ---------------------------------------------------------------------------
# _run_tool_wizard
# ---------------------------------------------------------------------------

from synth.cli.init_cmd import (
    ToolWizardResult,
    McpWizardResult,
    _run_tool_wizard,
    _run_mcp_wizard,
    _TOOL_CATALOG,
    _MCP_CATALOG,
    _build_agent_code,
)


def _invoke_tool_wizard(input_str: str) -> ToolWizardResult:
    """Run ``_run_tool_wizard`` via CliRunner and return the result object."""
    result_holder: list[ToolWizardResult] = []

    @click.command()
    def cmd():
        result_holder.append(_run_tool_wizard())

    CliRunner().invoke(cmd, input=input_str)
    return result_holder[0] if result_holder else ToolWizardResult()


def _invoke_mcp_wizard(input_str: str) -> McpWizardResult:
    """Run ``_run_mcp_wizard`` via CliRunner and return the result object."""
    result_holder: list[McpWizardResult] = []

    @click.command()
    def cmd():
        result_holder.append(_run_mcp_wizard())

    CliRunner().invoke(cmd, input=input_str)
    return result_holder[0] if result_holder else McpWizardResult()


class TestRunToolWizard:
    """Unit tests for ``_run_tool_wizard``."""

    def test_no_tools_when_user_declines(self) -> None:
        """Answering 'no' returns an empty ToolWizardResult."""
        result = _invoke_tool_wizard("n\n")
        assert result.tools_code == ""
        assert result.agent_imports == []
        assert result.files_created == []

    def test_prebuilt_selection_returns_tools_code(self) -> None:
        """Selecting a pre-built tool produces non-empty tools_code."""
        # yes, select tool 1 (web_search)
        result = _invoke_tool_wizard("y\n1\n")
        assert "web_search" in result.tools_code
        assert "web_search" in result.agent_imports
        assert "tools.py" in result.files_created

    def test_multiple_prebuilt_selections(self) -> None:
        """Selecting multiple tools includes all of them in tools_code."""
        # yes, select tools 1 and 2 (web_search, calculator)
        result = _invoke_tool_wizard("y\n1,2\n")
        assert "web_search" in result.tools_code
        assert "calculate" in result.tools_code
        assert "web_search" in result.agent_imports
        assert "calculate" in result.agent_imports

    def test_custom_scaffolding_generates_stub(self) -> None:
        """Custom scaffolding option generates a @tool stub for the given name."""
        custom_idx = len(_TOOL_CATALOG) + 1
        # yes, select custom, provide one tool name + description, then stop
        result = _invoke_tool_wizard(f"y\n{custom_idx}\nmy_tool\nDoes something\n\n")
        assert "@tool" in result.tools_code
        assert "my_tool" in result.tools_code
        assert "my_tool" in result.agent_imports

    def test_custom_scaffolding_up_to_3_tools(self) -> None:
        """Custom scaffolding accepts up to 3 tool names."""
        custom_idx = len(_TOOL_CATALOG) + 1
        result = _invoke_tool_wizard(
            f"y\n{custom_idx}\ntool_a\nDesc A\ntool_b\nDesc B\ntool_c\nDesc C\n\n"
        )
        assert "tool_a" in result.tools_code
        assert "tool_b" in result.tools_code
        assert "tool_c" in result.tools_code
        assert len(result.agent_imports) == 3

    def test_empty_selection_returns_empty_result(self) -> None:
        """Pressing Enter without selecting anything returns empty result."""
        result = _invoke_tool_wizard("y\n\n")
        assert result.tools_code == ""
        assert result.files_created == []

    def test_tools_code_has_synth_import(self) -> None:
        """Generated tools.py always imports from synth."""
        result = _invoke_tool_wizard("y\n1\n")
        assert "from synth import tool" in result.tools_code

    def test_default_is_no(self) -> None:
        """Default answer (empty Enter) declines tool creation."""
        result = _invoke_tool_wizard("\n")
        assert result.tools_code == ""


class TestRunMcpWizard:
    """Unit tests for ``_run_mcp_wizard``."""

    def test_no_mcp_when_user_declines(self) -> None:
        """Answering 'no' returns an empty McpWizardResult."""
        result = _invoke_mcp_wizard("n\n")
        assert result.server_dir == ""
        assert result.server_code == ""
        assert result.files_created == []

    def test_prebuilt_selection_returns_server_code(self) -> None:
        """Selecting a pre-built MCP server produces non-empty server_code."""
        # yes, select server 1 (filesystem)
        result = _invoke_mcp_wizard("y\n1\n")
        assert result.server_dir == "filesystem"
        assert "FastMCP" in result.server_code
        assert "filesystem/server.py" in result.files_created

    def test_custom_scaffolding_generates_stub(self) -> None:
        """Custom scaffolding generates @mcp.tool() stubs for given names."""
        custom_idx = len(_MCP_CATALOG) + 1
        result = _invoke_mcp_wizard(
            f"y\n{custom_idx}\nmy-server\nmy_tool\nDoes something\n\n"
        )
        assert "@mcp.tool()" in result.server_code
        assert "my_tool" in result.server_code
        assert "my-server/server.py" in result.files_created

    def test_custom_scaffolding_up_to_3_mcp_tools(self) -> None:
        """Custom scaffolding accepts up to 3 MCP tool names."""
        custom_idx = len(_MCP_CATALOG) + 1
        result = _invoke_mcp_wizard(
            f"y\n{custom_idx}\nmy-server\n"
            "tool_a\nDesc A\ntool_b\nDesc B\ntool_c\nDesc C\n\n"
        )
        assert "tool_a" in result.server_code
        assert "tool_b" in result.server_code
        assert "tool_c" in result.server_code

    def test_default_is_no(self) -> None:
        """Default answer (empty Enter) declines MCP creation."""
        result = _invoke_mcp_wizard("\n")
        assert result.server_dir == ""

    def test_agent_mcp_registration_non_empty_on_selection(self) -> None:
        """A selected MCP server produces a non-empty registration snippet."""
        result = _invoke_mcp_wizard("y\n1\n")
        assert result.agent_mcp_registration != ""


class TestBuildAgentCodeWithWizardResults:
    """Tests for ``_build_agent_code`` with tool_imports and mcp_registration."""

    _CFG = {
        "display": "Anthropic (Claude)",
        "model": "claude-sonnet-4-5",
        "extra": "anthropic",
        "env_var": "ANTHROPIC_API_KEY",
    }

    def test_tool_imports_appear_in_agent_code(self) -> None:
        """Tool names from wizard are imported and added to tools list."""
        code = _build_agent_code(
            "anthropic", self._CFG, [], "Be helpful.",
            tool_imports=["web_search", "calculate"],
        )
        assert "from tools import web_search, calculate" in code
        assert "tools=[web_search, calculate]" in code

    def test_no_tool_imports_no_tools_list(self) -> None:
        """Without tool_imports and no 'tools' feature, tools list is absent."""
        code = _build_agent_code("anthropic", self._CFG, [], "Be helpful.")
        assert "tools=[" not in code

    def test_mcp_registration_appended(self) -> None:
        """MCP registration snippet is appended to agent.py."""
        code = _build_agent_code(
            "anthropic", self._CFG, [], "Be helpful.",
            mcp_registration="\n# MCP registration\n# mcp_client = ...\n",
        )
        assert "# MCP registration" in code

    def test_legacy_tools_feature_still_works(self) -> None:
        """The legacy 'tools' feature flag still generates search/calculate imports."""
        code = _build_agent_code("anthropic", self._CFG, ["tools"], "Be helpful.")
        assert "from tools import search, calculate" in code
        assert "tools=[search, calculate]" in code


class TestGenerateProjectWithWizards:
    """Integration tests for ``_generate_project`` with wizard results."""

    _BASE_CFG: dict = {
        "display": "Anthropic (Claude)",
        "model": "claude-sonnet-4-5",
        "extra": "anthropic",
        "env_var": "ANTHROPIC_API_KEY",
    }

    def _run(
        self,
        tmp_path: str,
        name: str,
        tool_result: ToolWizardResult | None = None,
        mcp_result: McpWizardResult | None = None,
    ) -> None:
        orig = os.getcwd()
        os.chdir(tmp_path)
        try:
            _generate_project(
                name=name,
                description="Test",
                provider="anthropic",
                cfg=self._BASE_CFG,
                features=[],
                instructions="Be helpful.",
                tool_result=tool_result,
                mcp_result=mcp_result,
            )
        finally:
            os.chdir(orig)

    def test_tools_py_written_when_tool_result_provided(
        self, tmp_path: pytest.TempPathFactory
    ) -> None:
        """tools.py is written when ToolWizardResult has tools_code."""
        tool_res = ToolWizardResult(
            tools_code="# tools\n",
            agent_imports=["my_tool"],
            files_created=["tools.py"],
        )
        self._run(str(tmp_path), "proj", tool_result=tool_res)
        assert os.path.exists(os.path.join(str(tmp_path), "proj", "tools.py"))

    def test_mcp_server_dir_written_when_mcp_result_provided(
        self, tmp_path: pytest.TempPathFactory
    ) -> None:
        """MCP server.py is written inside the server directory."""
        mcp_res = McpWizardResult(
            server_dir="my-mcp",
            server_code="# server\n",
            agent_mcp_registration="",
            files_created=["my-mcp/server.py"],
        )
        self._run(str(tmp_path), "proj", mcp_result=mcp_res)
        assert os.path.exists(
            os.path.join(str(tmp_path), "proj", "my-mcp", "server.py")
        )

    def test_no_extra_files_when_no_wizard_results(
        self, tmp_path: pytest.TempPathFactory
    ) -> None:
        """Without wizard results, tools.py and MCP dir are not created."""
        self._run(str(tmp_path), "proj")
        proj = os.path.join(str(tmp_path), "proj")
        assert not os.path.exists(os.path.join(proj, "tools.py"))
        # No unexpected directories beyond the project itself
        entries = os.listdir(proj)
        assert "my-mcp" not in entries


# ---------------------------------------------------------------------------
# run_init — redesigned flow integration tests
# ---------------------------------------------------------------------------

from synth.cli.init_cmd import run_init, _FEATURES


def _make_run_init_cmd() -> click.BaseCommand:
    """Wrap ``run_init`` in a Click command for CliRunner."""

    @click.command()
    def cmd():
        run_init()

    return cmd


# Patch targets for run_init tests
_MODEL_SEL_PATH = "synth.cli.init_cmd._run_model_selection"
_CRED_CHECK_PATH = "synth.cli.init_cmd._run_credential_check"
_TOOL_WIZARD_PATH = "synth.cli.init_cmd._run_tool_wizard"
_MCP_WIZARD_PATH = "synth.cli.init_cmd._run_mcp_wizard"
_GEN_PROJECT_PATH = "synth.cli.init_cmd._generate_project"
_DEPLOY_PATH = "synth.cli.deploy_cmd.run_deploy"
_CHECK_DEPS_PATH = "synth.cli.init_cmd._check_provider_deps"
_TESTING_MODE_PATH = "synth.cli.init_cmd._prompt_testing_mode"


def _base_agentcore_input() -> str:
    """Input sequence for a minimal AgentCore run_init flow.

    Assumes ``_run_model_selection`` is mocked (no region/model prompts).
    Steps: project type → name → description → provider → instructions →
    (features: all no) → summary confirm → deploy decline → testing mode.
    """
    return (
        "single\n"          # 0. project type (single agent)
        "myproj\n"          # 1. project name
        "A test agent\n"    # 2. description
        "agentcore\n"       # 3. provider
        "\n"                # 5. agent instructions (default)
        # 8. features — decline all (memory, guards, structured, eval, deploy)
        "n\nn\nn\nn\nn\n"
        # 10. summary confirm
        "y\n"
        # 12. deploy prompt — decline
        "n\n"
        # 13. testing mode — cli (default, won't launch)
        "cli\n"
    )


def _base_anthropic_input() -> str:
    """Input sequence for a minimal Anthropic (non-AgentCore) run_init flow."""
    return (
        "single\n"          # 0. project type (single agent)
        "myproj\n"          # 1. project name
        "A test agent\n"    # 2. description
        "anthropic\n"       # 3. provider
        "\n"                # 5. agent instructions (default)
        # 8. features — decline all (memory, guards, structured, eval)
        "n\nn\nn\nn\n"
        # 10. summary confirm
        "y\n"
        # 13. testing mode — cli (default, won't launch)
        "cli\n"
    )


class TestRunInitStepOrder:
    """Integration tests for the redesigned ``run_init()`` step order."""

    def test_tools_not_in_features_dict(self) -> None:
        """The ``_FEATURES`` dict does not contain a 'tools' key (Req 3.2)."""
        assert "tools" not in _FEATURES

    def test_features_prompt_excludes_tools(self) -> None:
        """Feature selection does not present 'Custom tool functions' (Req 3.2)."""
        with (
            patch(
                _MODEL_SEL_PATH,
                return_value="bedrock/anthropic.claude-3-5-haiku-20241022-v1:0",
            ),
            patch(_CRED_CHECK_PATH, return_value={"aws_profile": None}),
            patch(_TOOL_WIZARD_PATH, return_value=ToolWizardResult()),
            patch(_MCP_WIZARD_PATH, return_value=McpWizardResult()),
            patch(_GEN_PROJECT_PATH),
            patch(_CHECK_DEPS_PATH),
            patch(_TESTING_MODE_PATH),
        ):
            out = CliRunner().invoke(
                _make_run_init_cmd(),
                input=_base_agentcore_input(),
            )

        assert out.exit_code == 0, out.output
        assert "Custom tool functions" not in out.output

    def test_credential_check_called_for_agentcore(self) -> None:
        """``_run_credential_check`` is called when provider is AgentCore (Req 3.4)."""
        mock_cred = MagicMock(return_value={"aws_profile": "default"})

        with (
            patch(
                _MODEL_SEL_PATH,
                return_value="bedrock/anthropic.claude-3-5-haiku-20241022-v1:0",
            ),
            patch(_CRED_CHECK_PATH, mock_cred),
            patch(_TOOL_WIZARD_PATH, return_value=ToolWizardResult()),
            patch(_MCP_WIZARD_PATH, return_value=McpWizardResult()),
            patch(_GEN_PROJECT_PATH),
            patch(_CHECK_DEPS_PATH),
            patch(_TESTING_MODE_PATH),
        ):
            out = CliRunner().invoke(
                _make_run_init_cmd(),
                input=_base_agentcore_input(),
            )

        assert out.exit_code == 0, out.output
        mock_cred.assert_called_once()

    def test_credential_check_skipped_for_non_agentcore(self) -> None:
        """``_run_credential_check`` is NOT called for non-AgentCore (Req 3.3)."""
        mock_cred = MagicMock(return_value={"aws_profile": None})

        with (
            patch(_CRED_CHECK_PATH, mock_cred),
            patch(_TOOL_WIZARD_PATH, return_value=ToolWizardResult()),
            patch(_MCP_WIZARD_PATH, return_value=McpWizardResult()),
            patch(_GEN_PROJECT_PATH),
            patch(_TESTING_MODE_PATH),
        ):
            out = CliRunner().invoke(
                _make_run_init_cmd(),
                input=_base_anthropic_input(),
            )

        assert out.exit_code == 0, out.output
        mock_cred.assert_not_called()

    def test_model_selection_called_for_all_providers(self) -> None:
        """``_run_model_selection`` is called at step 4 for any provider (Req 3.5)."""
        mock_model_sel = MagicMock(return_value="claude-sonnet-4-5")

        with (
            patch(_MODEL_SEL_PATH, mock_model_sel),
            patch(_TOOL_WIZARD_PATH, return_value=ToolWizardResult()),
            patch(_MCP_WIZARD_PATH, return_value=McpWizardResult()),
            patch(_GEN_PROJECT_PATH),
            patch(_TESTING_MODE_PATH),
        ):
            out = CliRunner().invoke(
                _make_run_init_cmd(),
                input=_base_anthropic_input(),
            )

        assert out.exit_code == 0, out.output
        mock_model_sel.assert_called_once()
        call_args = mock_model_sel.call_args
        assert call_args[0][0] == "anthropic"


class TestRunInitDeployPrompt:
    """Tests for the post-generation deploy prompt (Req 4.x)."""

    def test_deploy_prompt_shown_for_agentcore(self) -> None:
        """'Deploy now?' appears after generation for AgentCore (Req 4.1)."""
        with (
            patch(
                _MODEL_SEL_PATH,
                return_value="bedrock/anthropic.claude-3-5-haiku-20241022-v1:0",
            ),
            patch(_CRED_CHECK_PATH, return_value={"aws_profile": None}),
            patch(_TOOL_WIZARD_PATH, return_value=ToolWizardResult()),
            patch(_MCP_WIZARD_PATH, return_value=McpWizardResult()),
            patch(_GEN_PROJECT_PATH),
            patch(_CHECK_DEPS_PATH),
            patch(_TESTING_MODE_PATH),
        ):
            out = CliRunner().invoke(
                _make_run_init_cmd(),
                input=_base_agentcore_input(),
            )

        assert out.exit_code == 0, out.output
        assert "Deploy now?" in out.output

    def test_deploy_prompt_not_shown_for_non_agentcore(self) -> None:
        """'Deploy now?' does NOT appear for non-AgentCore providers (Req 4.4)."""
        with (
            patch(_TOOL_WIZARD_PATH, return_value=ToolWizardResult()),
            patch(_MCP_WIZARD_PATH, return_value=McpWizardResult()),
            patch(_GEN_PROJECT_PATH),
            patch(_TESTING_MODE_PATH),
        ):
            out = CliRunner().invoke(
                _make_run_init_cmd(),
                input=_base_anthropic_input(),
            )

        assert out.exit_code == 0, out.output
        assert "Deploy now?" not in out.output

    def test_deploy_invoked_when_user_confirms(self) -> None:
        """``run_deploy`` is called with correct args on 'yes' (Req 4.2)."""
        mock_deploy = MagicMock()

        # Same as base but answer 'y' to deploy prompt
        deploy_yes_input = (
            "single\n"
            "myproj\n"
            "A test agent\n"
            "agentcore\n"
            "\n"
            "n\nn\nn\nn\nn\n"
            "y\n"
            "y\n"  # deploy: yes
            "cli\n"  # testing mode
        )

        with (
            patch(
                _MODEL_SEL_PATH,
                return_value="bedrock/anthropic.claude-3-5-haiku-20241022-v1:0",
            ),
            patch(_CRED_CHECK_PATH, return_value={"aws_profile": None}),
            patch(_TOOL_WIZARD_PATH, return_value=ToolWizardResult()),
            patch(_MCP_WIZARD_PATH, return_value=McpWizardResult()),
            patch(_GEN_PROJECT_PATH),
            patch(_DEPLOY_PATH, mock_deploy),
            patch(_CHECK_DEPS_PATH),
            patch(_TESTING_MODE_PATH),
        ):
            out = CliRunner().invoke(
                _make_run_init_cmd(),
                input=deploy_yes_input,
            )

        assert out.exit_code == 0, out.output
        mock_deploy.assert_called_once_with(
            target="agentcore",
            dry_run=False,
            file=os.path.join("myproj", "agent.py"),
        )

    def test_deploy_decline_shows_later_message(self) -> None:
        """Declining deploy prints the 'deploy later' hint (Req 4.3)."""
        with (
            patch(
                _MODEL_SEL_PATH,
                return_value="bedrock/anthropic.claude-3-5-haiku-20241022-v1:0",
            ),
            patch(_CRED_CHECK_PATH, return_value={"aws_profile": None}),
            patch(_TOOL_WIZARD_PATH, return_value=ToolWizardResult()),
            patch(_MCP_WIZARD_PATH, return_value=McpWizardResult()),
            patch(_GEN_PROJECT_PATH),
            patch(_CHECK_DEPS_PATH),
            patch(_TESTING_MODE_PATH),
        ):
            out = CliRunner().invoke(
                _make_run_init_cmd(),
                input=_base_agentcore_input(),
            )

        assert out.exit_code == 0, out.output
        assert "synth deploy --target agentcore agent.py" in out.output


class TestRunInitAgentcoreSetupDict:
    """Tests for the ``agentcore_setup`` dict passed to ``_generate_project`` (Req 5.5)."""

    def test_agentcore_setup_has_bedrock_prefixed_model_id(self) -> None:
        """The model_id in agentcore_setup starts with 'bedrock/' (Req 1.2)."""
        gen_mock = MagicMock()

        def _fake_model_sel(
            provider: str,
            cfg: dict,
            agentcore_state: dict | None = None,
        ) -> str:
            if agentcore_state is not None:
                agentcore_state["aws_region"] = "us-east-1"
                agentcore_state["cris_enabled"] = False
            return "bedrock/anthropic.claude-3-5-haiku-20241022-v1:0"

        with (
            patch(_MODEL_SEL_PATH, side_effect=_fake_model_sel),
            patch(_CRED_CHECK_PATH, return_value={"aws_profile": "dev"}),
            patch(_TOOL_WIZARD_PATH, return_value=ToolWizardResult()),
            patch(_MCP_WIZARD_PATH, return_value=McpWizardResult()),
            patch(_GEN_PROJECT_PATH, gen_mock),
            patch(_CHECK_DEPS_PATH),
            patch(_TESTING_MODE_PATH),
        ):
            out = CliRunner().invoke(
                _make_run_init_cmd(),
                input=_base_agentcore_input(),
            )

        assert out.exit_code == 0, out.output
        gen_mock.assert_called_once()
        call_kwargs = gen_mock.call_args[1]
        setup = call_kwargs["agentcore_setup"]
        assert setup is not None
        assert setup["model_id"].startswith("bedrock/")

    def test_agentcore_setup_contains_all_expected_keys(self) -> None:
        """The dict has aws_region, model_id, cris_enabled, aws_profile."""
        gen_mock = MagicMock()

        def _fake_model_sel(
            provider: str,
            cfg: dict,
            agentcore_state: dict | None = None,
        ) -> str:
            if agentcore_state is not None:
                agentcore_state["aws_region"] = "eu-west-1"
                agentcore_state["cris_enabled"] = True
            return "bedrock/us.anthropic.claude-opus-4-20250514-v1:0"

        with (
            patch(_MODEL_SEL_PATH, side_effect=_fake_model_sel),
            patch(
                _CRED_CHECK_PATH,
                return_value={"aws_profile": "my-profile"},
            ),
            patch(_TOOL_WIZARD_PATH, return_value=ToolWizardResult()),
            patch(_MCP_WIZARD_PATH, return_value=McpWizardResult()),
            patch(_GEN_PROJECT_PATH, gen_mock),
            patch(_CHECK_DEPS_PATH),
            patch(_TESTING_MODE_PATH),
        ):
            out = CliRunner().invoke(
                _make_run_init_cmd(),
                input=_base_agentcore_input(),
            )

        assert out.exit_code == 0, out.output
        setup = gen_mock.call_args[1]["agentcore_setup"]
        assert "aws_region" in setup
        assert "model_id" in setup
        assert "cris_enabled" in setup
        assert "aws_profile" in setup
        assert setup["aws_region"] == "eu-west-1"
        assert setup["cris_enabled"] is True
        assert setup["aws_profile"] == "my-profile"

    def test_agentcore_setup_none_for_non_agentcore(self) -> None:
        """Non-AgentCore providers pass ``agentcore_setup=None``."""
        gen_mock = MagicMock()

        with (
            patch(_TOOL_WIZARD_PATH, return_value=ToolWizardResult()),
            patch(_MCP_WIZARD_PATH, return_value=McpWizardResult()),
            patch(_GEN_PROJECT_PATH, gen_mock),
            patch(_TESTING_MODE_PATH),
        ):
            out = CliRunner().invoke(
                _make_run_init_cmd(),
                input=_base_anthropic_input(),
            )

        assert out.exit_code == 0, out.output
        assert gen_mock.call_args[1]["agentcore_setup"] is None


# ---------------------------------------------------------------------------
# Multi-agent configuration data models
# ---------------------------------------------------------------------------

from synth.cli.init_cmd import (
    AgentConfig,
    AgentTeamConfig,
    EdgeConfig,
    GraphConfig,
    HumanInLoopConfig,
    McpWizardResult,
    OrchestrationConfig,
    PipelineConfig,
    ToolWizardResult,
)


class TestAgentConfig:
    """Tests for the ``AgentConfig`` dataclass."""

    def test_required_fields(self) -> None:
        cfg = AgentConfig(
            name="researcher",
            description="Researches topics",
            provider="anthropic",
            provider_cfg={"model": "claude-sonnet-4-5", "extra": "anthropic"},
            model="claude-sonnet-4-5",
            instructions="You research.",
            tool_result=ToolWizardResult(),
            mcp_result=McpWizardResult(),
        )
        assert cfg.name == "researcher"
        assert cfg.description == "Researches topics"
        assert cfg.provider == "anthropic"
        assert cfg.model == "claude-sonnet-4-5"

    def test_defaults(self) -> None:
        cfg = AgentConfig(
            name="a",
            description="d",
            provider="openai",
            provider_cfg={},
            model="gpt-4o",
            instructions="hi",
            tool_result=ToolWizardResult(),
            mcp_result=McpWizardResult(),
        )
        assert cfg.is_agentcore is False
        assert cfg.agentcore_state == {}

    def test_agentcore_state_mutable_default_isolation(self) -> None:
        """Each instance gets its own ``agentcore_state`` dict."""
        a = AgentConfig(
            name="a", description="", provider="p", provider_cfg={},
            model="m", instructions="", tool_result=ToolWizardResult(),
            mcp_result=McpWizardResult(),
        )
        b = AgentConfig(
            name="b", description="", provider="p", provider_cfg={},
            model="m", instructions="", tool_result=ToolWizardResult(),
            mcp_result=McpWizardResult(),
        )
        a.agentcore_state["region"] = "us-west-2"
        assert b.agentcore_state == {}

    def test_is_agentcore_flag(self) -> None:
        cfg = AgentConfig(
            name="ac",
            description="",
            provider="agentcore",
            provider_cfg={},
            model="bedrock/us.anthropic.claude-sonnet-4-5-20250929-v1:0",
            instructions="",
            tool_result=ToolWizardResult(),
            mcp_result=McpWizardResult(),
            is_agentcore=True,
            agentcore_state={"aws_region": "eu-west-1"},
        )
        assert cfg.is_agentcore is True
        assert cfg.agentcore_state["aws_region"] == "eu-west-1"


class TestPipelineConfig:
    """Tests for the ``PipelineConfig`` dataclass."""

    def test_default_empty_order(self) -> None:
        pc = PipelineConfig()
        assert pc.agent_order == []

    def test_agent_order_set(self) -> None:
        pc = PipelineConfig(agent_order=["a", "b", "c"])
        assert pc.agent_order == ["a", "b", "c"]

    def test_mutable_default_isolation(self) -> None:
        a = PipelineConfig()
        b = PipelineConfig()
        a.agent_order.append("x")
        assert b.agent_order == []


class TestEdgeConfig:
    """Tests for the ``EdgeConfig`` dataclass."""

    def test_required_fields(self) -> None:
        e = EdgeConfig(source="classify", target="handle")
        assert e.source == "classify"
        assert e.target == "handle"
        assert e.condition is None

    def test_with_condition(self) -> None:
        e = EdgeConfig(source="a", target="b", condition="priority == high")
        assert e.condition == "priority == high"

    def test_end_target(self) -> None:
        e = EdgeConfig(source="final", target="END")
        assert e.target == "END"


class TestGraphConfig:
    """Tests for the ``GraphConfig`` dataclass."""

    def test_defaults(self) -> None:
        gc = GraphConfig()
        assert gc.entry_node == ""
        assert gc.edges == []

    def test_with_edges(self) -> None:
        edges = [
            EdgeConfig(source="a", target="b"),
            EdgeConfig(source="b", target="END"),
        ]
        gc = GraphConfig(entry_node="a", edges=edges)
        assert gc.entry_node == "a"
        assert len(gc.edges) == 2

    def test_mutable_default_isolation(self) -> None:
        a = GraphConfig()
        b = GraphConfig()
        a.edges.append(EdgeConfig(source="x", target="y"))
        assert b.edges == []


class TestAgentTeamConfig:
    """Tests for the ``AgentTeamConfig`` dataclass."""

    def test_defaults(self) -> None:
        tc = AgentTeamConfig()
        assert tc.strategy == "auto"
        assert tc.orchestrator_model == ""

    @pytest.mark.parametrize("strategy", ["auto", "parallel"])
    def test_strategy_values(self, strategy: str) -> None:
        tc = AgentTeamConfig(strategy=strategy, orchestrator_model="gpt-4o")
        assert tc.strategy == strategy
        assert tc.orchestrator_model == "gpt-4o"


class TestHumanInLoopConfig:
    """Tests for the ``HumanInLoopConfig`` dataclass."""

    def test_defaults(self) -> None:
        h = HumanInLoopConfig()
        assert isinstance(h.graph, GraphConfig)
        assert h.pause_nodes == []
        assert h.timeout is None
        assert h.fallback_node is None

    def test_full_config(self) -> None:
        gc = GraphConfig(
            entry_node="start",
            edges=[EdgeConfig(source="start", target="review")],
        )
        h = HumanInLoopConfig(
            graph=gc,
            pause_nodes=["review"],
            timeout=3600.0,
            fallback_node="abort",
        )
        assert h.graph.entry_node == "start"
        assert h.pause_nodes == ["review"]
        assert h.timeout == 3600.0
        assert h.fallback_node == "abort"

    def test_mutable_default_isolation(self) -> None:
        a = HumanInLoopConfig()
        b = HumanInLoopConfig()
        a.pause_nodes.append("node1")
        assert b.pause_nodes == []

    def test_graph_default_isolation(self) -> None:
        """Each instance gets its own default ``GraphConfig``."""
        a = HumanInLoopConfig()
        b = HumanInLoopConfig()
        a.graph.entry_node = "modified"
        assert b.graph.entry_node == ""


class TestOrchestrationConfig:
    """Tests for the ``OrchestrationConfig`` dataclass."""

    def test_defaults(self) -> None:
        oc = OrchestrationConfig()
        assert oc.pattern == ""
        assert oc.pipeline is None
        assert oc.graph is None
        assert oc.agent_team is None
        assert oc.human_in_loop is None

    def test_pipeline_pattern(self) -> None:
        oc = OrchestrationConfig(
            pattern="pipeline",
            pipeline=PipelineConfig(agent_order=["a", "b"]),
        )
        assert oc.pattern == "pipeline"
        assert oc.pipeline is not None
        assert oc.pipeline.agent_order == ["a", "b"]
        assert oc.graph is None

    def test_graph_pattern(self) -> None:
        gc = GraphConfig(
            entry_node="start",
            edges=[EdgeConfig(source="start", target="END")],
        )
        oc = OrchestrationConfig(pattern="graph", graph=gc)
        assert oc.pattern == "graph"
        assert oc.graph is not None
        assert oc.graph.entry_node == "start"

    def test_agent_team_pattern(self) -> None:
        oc = OrchestrationConfig(
            pattern="agent_team",
            agent_team=AgentTeamConfig(
                strategy="parallel",
                orchestrator_model="claude-sonnet-4-5",
            ),
        )
        assert oc.agent_team is not None
        assert oc.agent_team.strategy == "parallel"

    def test_human_in_loop_pattern(self) -> None:
        gc = GraphConfig(entry_node="a")
        hil = HumanInLoopConfig(
            graph=gc, pause_nodes=["a"], timeout=60.0,
        )
        oc = OrchestrationConfig(pattern="human_in_loop", human_in_loop=hil)
        assert oc.human_in_loop is not None
        assert oc.human_in_loop.pause_nodes == ["a"]
        assert oc.human_in_loop.timeout == 60.0
