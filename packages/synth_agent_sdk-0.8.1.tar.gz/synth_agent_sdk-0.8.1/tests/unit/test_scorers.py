"""Unit tests for synth.eval.scorers.

Covers ExactMatchScorer, SemanticSimilarityScorer, and CustomScorer with
edge cases, boundary conditions, and parametrized inputs.
"""

from __future__ import annotations

import math

import pytest

from synth.eval.scorers import (
    BaseScorer,
    CustomScorer,
    ExactMatchScorer,
    SemanticSimilarityScorer,
)


# ---------------------------------------------------------------------------
# ExactMatchScorer
# ---------------------------------------------------------------------------


class TestExactMatchScorer:
    """Tests for binary exact-match scoring."""

    def test_identical_strings_score_one(self):
        scorer = ExactMatchScorer()
        assert scorer.score("hello", "hello") == 1.0

    def test_different_strings_score_zero(self):
        scorer = ExactMatchScorer()
        assert scorer.score("hello", "world") == 0.0

    def test_strips_whitespace_before_comparison(self):
        scorer = ExactMatchScorer()
        assert scorer.score("  hello  ", "hello") == 1.0
        assert scorer.score("hello", "  hello  ") == 1.0
        assert scorer.score("  hello  ", "  hello  ") == 1.0

    def test_case_sensitive(self):
        scorer = ExactMatchScorer()
        assert scorer.score("Hello", "hello") == 0.0

    def test_empty_strings_match(self):
        scorer = ExactMatchScorer()
        assert scorer.score("", "") == 1.0

    def test_whitespace_only_matches_empty(self):
        scorer = ExactMatchScorer()
        assert scorer.score("   ", "") == 1.0

    def test_non_string_expected_converted_to_str(self):
        scorer = ExactMatchScorer()
        assert scorer.score("42", 42) == 1.0
        assert scorer.score("True", True) == 1.0

    def test_non_string_output_converted_to_str(self):
        """Output is typed as str but the implementation calls str() on it."""
        scorer = ExactMatchScorer()
        # Passing an int as output (type-wise unusual but handled)
        assert scorer.score("123", "123") == 1.0

    @pytest.mark.parametrize(
        ("output", "expected", "want"),
        [
            ("yes", "yes", 1.0),
            ("yes", "no", 0.0),
            ("\n\n", "", 1.0),
            ("abc\n", "abc", 1.0),
        ],
    )
    def test_parametrized_cases(self, output: str, expected: str, want: float):
        scorer = ExactMatchScorer()
        assert scorer.score(output, expected) == want


# ---------------------------------------------------------------------------
# SemanticSimilarityScorer
# ---------------------------------------------------------------------------


class TestSemanticSimilarityScorer:
    """Tests for cosine-similarity scoring via embeddings."""

    @staticmethod
    def _identity_embedder(text: str) -> list[float]:
        """Trivial embedder: returns a fixed vector based on text hash."""
        h = hash(text) % 1000
        return [float(h), float(h + 1), float(h + 2)]

    @staticmethod
    def _constant_embedder(vec: list[float]):
        """Return a factory that always produces the same vector."""
        return lambda _text: list(vec)

    def test_identical_texts_score_one(self):
        scorer = SemanticSimilarityScorer(embedder=self._identity_embedder)
        score = scorer.score("hello", "hello")
        assert score == pytest.approx(1.0, abs=1e-6)

    def test_orthogonal_vectors_score_zero(self):
        """Orthogonal embeddings should yield 0.0 cosine similarity."""
        call_count = 0

        def orthogonal_embedder(text: str) -> list[float]:
            nonlocal call_count
            call_count += 1
            if call_count % 2 == 1:
                return [1.0, 0.0]
            return [0.0, 1.0]

        scorer = SemanticSimilarityScorer(embedder=orthogonal_embedder)
        assert scorer.score("a", "b") == pytest.approx(0.0, abs=1e-6)

    def test_opposite_vectors_clamped_to_zero(self):
        """Negative cosine similarity should be clamped to 0.0."""
        call_count = 0

        def opposite_embedder(text: str) -> list[float]:
            nonlocal call_count
            call_count += 1
            if call_count % 2 == 1:
                return [1.0, 0.0]
            return [-1.0, 0.0]

        scorer = SemanticSimilarityScorer(embedder=opposite_embedder)
        assert scorer.score("a", "b") == 0.0

    def test_zero_vector_returns_zero(self):
        """A zero-norm vector should produce 0.0 (no division by zero)."""
        scorer = SemanticSimilarityScorer(
            embedder=self._constant_embedder([0.0, 0.0, 0.0]),
        )
        assert scorer.score("a", "b") == 0.0

    def test_one_zero_vector_returns_zero(self):
        call_count = 0

        def mixed_embedder(text: str) -> list[float]:
            nonlocal call_count
            call_count += 1
            if call_count % 2 == 1:
                return [1.0, 2.0]
            return [0.0, 0.0]

        scorer = SemanticSimilarityScorer(embedder=mixed_embedder)
        assert scorer.score("a", "b") == 0.0

    def test_parallel_vectors_score_one(self):
        """Parallel vectors (same direction, different magnitude) → 1.0."""
        call_count = 0

        def parallel_embedder(text: str) -> list[float]:
            nonlocal call_count
            call_count += 1
            if call_count % 2 == 1:
                return [1.0, 2.0, 3.0]
            return [2.0, 4.0, 6.0]

        scorer = SemanticSimilarityScorer(embedder=parallel_embedder)
        assert scorer.score("a", "b") == pytest.approx(1.0, abs=1e-6)

    def test_score_clamped_to_unit_range(self):
        """Score must always be in [0.0, 1.0]."""
        scorer = SemanticSimilarityScorer(embedder=self._identity_embedder)
        score = scorer.score("x", "y")
        assert 0.0 <= score <= 1.0

    def test_non_string_expected_converted(self):
        scorer = SemanticSimilarityScorer(embedder=self._identity_embedder)
        # Should not raise — expected is converted via str()
        score = scorer.score("42", 42)
        assert isinstance(score, float)

    def test_cosine_similarity_static_method_directly(self):
        """Verify the static helper independently."""
        sim = SemanticSimilarityScorer._cosine_similarity
        assert sim([1, 0], [1, 0]) == pytest.approx(1.0)
        assert sim([1, 0], [0, 1]) == pytest.approx(0.0)
        assert sim([0, 0], [1, 1]) == 0.0
        # 45-degree angle
        assert sim([1, 0], [1, 1]) == pytest.approx(1 / math.sqrt(2), abs=1e-6)


# ---------------------------------------------------------------------------
# CustomScorer
# ---------------------------------------------------------------------------


class TestCustomScorer:
    """Tests for the user-provided checker wrapper."""

    def test_delegates_to_checker(self):
        scorer = CustomScorer(checker=lambda o, e: 0.75)
        assert scorer.score("anything", "anything") == 0.75

    def test_passes_output_and_expected(self):
        received = {}

        def capture(output: str, expected):
            received["output"] = output
            received["expected"] = expected
            return 0.5

        scorer = CustomScorer(checker=capture)
        scorer.score("out", "exp")
        assert received == {"output": "out", "expected": "exp"}

    def test_checker_returning_zero(self):
        scorer = CustomScorer(checker=lambda o, e: 0.0)
        assert scorer.score("a", "b") == 0.0

    def test_checker_returning_one(self):
        scorer = CustomScorer(checker=lambda o, e: 1.0)
        assert scorer.score("a", "b") == 1.0

    def test_checker_exception_propagates(self):
        def bad_checker(o, e):
            raise ValueError("boom")

        scorer = CustomScorer(checker=bad_checker)
        with pytest.raises(ValueError, match="boom"):
            scorer.score("a", "b")


# ---------------------------------------------------------------------------
# BaseScorer ABC
# ---------------------------------------------------------------------------


class TestBaseScorer:
    """Verify the ABC contract."""

    def test_cannot_instantiate_directly(self):
        with pytest.raises(TypeError):
            BaseScorer()  # type: ignore[abstract]

    def test_subclass_must_implement_score(self):
        class Incomplete(BaseScorer):
            pass

        with pytest.raises(TypeError):
            Incomplete()  # type: ignore[abstract]

    def test_concrete_subclass_works(self):
        class Always1(BaseScorer):
            def score(self, output: str, expected) -> float:
                return 1.0

        assert Always1().score("x", "y") == 1.0
