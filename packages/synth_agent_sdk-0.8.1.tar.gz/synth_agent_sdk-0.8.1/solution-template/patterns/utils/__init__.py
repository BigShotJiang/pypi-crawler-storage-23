# Shared utilities for agent patterns
