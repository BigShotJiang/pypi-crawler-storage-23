# Requirements Document

## Introduction

Synth is a Python SDK for building production-grade AI agents and multi-agent systems. Inspired by the autonomous synthetic agents of Fallout 4, Synth gives developers a layered API that scales from a 3-line single agent up to complex, stateful, resumable multi-agent graphs — with model-agnostic provider support, built-in streaming, observability, evaluation, and guardrails out of the box.

- **Package:** `pip install synth-agent-sdk`
- **Imports:** `from synth import Agent, tool, Graph, Pipeline`
- **CLI:** `synth dev`, `synth run`, `synth eval`, `synth trace`, `synth doctor`
- **Tagline:** "Autonomous agents, engineered."

## Glossary

- **Agent**: A single autonomous unit that wraps an LLM model, optional tools, memory, and guardrails into a callable object capable of processing prompts and returning structured results.
- **Tool**: A Python function decorated with `@tool` that the Agent can invoke during a run to perform side effects or retrieve information.
- **ToolKit**: A grouping construct that bundles multiple `@tool` functions into a single unit passable to an Agent.
- **Pipeline**: A linear orchestration construct that chains multiple Agents sequentially, passing each Agent's output as the next Agent's input.
- **Graph**: A directed-graph orchestration construct where nodes represent processing steps and edges (optionally conditional) define control flow, supporting loops, branching, and concurrency.
- **Node**: A processing step within a Graph, defined via the `@node` decorator, that receives and returns state.
- **Memory**: A pluggable conversation-history backend attached to an Agent, supporting thread-scoped, persistent, and semantic retrieval strategies.
- **Guard**: A declarative constraint applied to an Agent's input or output that enforces safety, cost, or policy rules.
- **RunResult**: The response object returned by `agent.run()`, containing the model's reply, token usage, latency, cost, and trace.
- **Trace**: A structured record of all LLM calls, tool calls, timestamps, token counts, and costs produced during a single run.
- **EvalReport**: The output of an evaluation run, containing per-case pass/fail results, overall score, latency, and cost.
- **Checkpoint**: A persisted snapshot of execution state after each node or step, enabling resumable runs.
- **PausedRun**: An object returned when graph execution is paused for human-in-the-loop approval, exposing a `resume()` method.
- **AgentTeam**: An orchestration construct where a coordinator model delegates sub-tasks to specialised Agents.
- **Provider**: An LLM backend (e.g., Anthropic, OpenAI, Google, Ollama, AWS Bedrock) that the SDK routes requests to based on the model string.
- **Bedrock**: AWS's fully managed service that provides access to foundation models from multiple providers (Anthropic, Meta, Mistral, etc.) through a unified API, using AWS credentials for authentication.
- **SynthConfigError**: An error raised when SDK configuration is invalid, including missing API keys, invalid model strings, or missing provider packages.
- **ToolExecutionError**: An error raised when a tool function throws an exception during agent execution.
- **ToolDefinitionError**: An error raised at decoration time when a `@tool` function is missing type annotations or a docstring.
- **GuardViolationError**: An error raised when a Guard constraint is violated, containing the guard name, violating content, and suggested remediation.
- **AWS_AgentCore**: AWS's managed service for deploying, managing, and scaling AI agents in production, providing runtime infrastructure, identity, memory, and observability without self-managed servers.
- **AgentCore_Runtime**: The execution environment within AWS AgentCore that hosts and runs agent code, handling invocation, scaling, and lifecycle management.

## Requirements

### Requirement 1: Minimal Agent Instantiation

**User Story:** As a developer, I want to create a working AI agent in 3 lines of code, so that I can get immediate value without reading extensive documentation.

#### Acceptance Criteria

1. WHEN a developer imports `Agent` from `synth` and instantiates it with a `model` string and `instructions` string THEN the Agent SHALL create a runnable agent instance with no further configuration required.
2. WHEN a developer calls `agent.run("prompt")` THEN the Agent SHALL return a RunResult object containing the model's text reply, token usage, latency, and cost.
3. WHEN the `model` string does not match any known Provider THEN the Agent SHALL raise a SynthConfigError stating the invalid model string and listing available providers.
4. WHEN the Provider API key is missing from the environment THEN the Agent SHALL raise a SynthConfigError naming the expected environment variable and a link to obtain the key.
5. WHEN no `model` string is provided THEN the Agent SHALL default to a pre-configured model and create a runnable instance without raising an error.

### Requirement 2: Tool Registration via Decorator

**User Story:** As a developer, I want to attach tools to my agent using a simple decorator, so that the agent can call my functions without boilerplate schema definitions.

#### Acceptance Criteria

1. WHEN a developer applies the `@tool` decorator to a Python function with type annotations and a docstring THEN the Tool decorator SHALL automatically derive a valid JSON schema from the function's signature and docstring.
2. WHEN a developer passes a list of decorated functions to `Agent(tools=[...])` THEN the Agent SHALL make those tools available for invocation during a run.
3. WHEN the Agent decides to call a tool during a run THEN the Agent SHALL execute the corresponding Python function with the model-provided arguments, capture the return value, and feed it back into the conversation.
4. WHEN a tool function raises an exception during execution THEN the Agent SHALL raise a ToolExecutionError containing the tool name, the arguments passed, and the underlying exception message.
5. WHEN a function decorated with `@tool` is missing type annotations or a docstring THEN the Tool decorator SHALL raise a ToolDefinitionError at decoration time, not at runtime.
6. WHEN a developer instantiates a ToolKit with a list of `@tool` functions and passes it to `Agent(tools=[toolkit])` THEN the Agent SHALL register all tools in the ToolKit as available tools for the run.

### Requirement 3: Streaming

**User Story:** As a developer, I want to stream agent responses token-by-token and receive typed events, so that I can build responsive real-time UIs and pipelines.

#### Acceptance Criteria

1. WHEN a developer calls `agent.stream("prompt")` THEN the Agent SHALL return an async generator that yields typed event objects.
2. WHEN the model emits a text token THEN the Agent SHALL yield a `TokenEvent(text: str)` object.
3. WHEN the Agent decides to invoke a tool during streaming THEN the Agent SHALL yield a `ToolCallEvent(name: str, args: dict)` before execution and a `ToolResultEvent(name: str, result: Any)` after execution.
4. WHEN the model emits a reasoning or thinking token THEN the Agent SHALL yield a `ThinkingEvent(text: str)` object.
5. WHEN the streaming run completes THEN the Agent SHALL yield a `DoneEvent(result: RunResult)` as the final event containing the full result, cost, and latency.
6. WHEN a streaming run is interrupted by an exception THEN the Agent SHALL yield an `ErrorEvent(error: Exception)` and close the generator cleanly without hanging.

### Requirement 4: Model-Agnostic Provider Support

**User Story:** As a developer, I want to switch between LLM providers with a single string change, so that I am not locked into one vendor and can compare models easily.

#### Acceptance Criteria

1. WHEN a developer specifies a model string such as `"claude-sonnet-4-5"`, `"gpt-4o"`, `"gemini-2.0-flash"`, or `"ollama/llama3"` THEN the Provider router SHALL route the request to the correct Provider without requiring any other code change.
2. WHEN a developer specifies a model string prefixed with `"bedrock/"` (e.g., `"bedrock/claude-sonnet-4-5"` or `"bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0"`) THEN the Provider router SHALL route the request through the AWS Bedrock Runtime API using the Bedrock model identifier.
3. WHEN a Provider package is not installed THEN the Provider router SHALL raise a SynthConfigError naming the missing package and the exact `pip install synth-agent-sdk[provider]` command needed.
4. WHEN a developer passes a `base_url` parameter to the Agent THEN the Provider router SHALL use that endpoint for all requests, enabling support for local models or proxy servers.
5. WHEN streaming is requested THEN the Provider router SHALL honour streaming for every supported Provider, returning the same typed event interface regardless of which Provider is used.
6. WHEN a Provider returns a rate-limit (HTTP 429) or transient server error (HTTP 5xx) THEN the Provider router SHALL automatically retry with configurable exponential backoff up to a configurable maximum number of retries before surfacing the error to the caller.

### Requirement 5: Thread-Scoped Conversation Memory

**User Story:** As a developer, I want agents to remember the conversation within a thread, so that users do not need to repeat context across multiple turns.

#### Acceptance Criteria

1. WHEN a developer passes `memory=Memory.thread()` to the Agent and supplies a `thread_id` on each `run()` call THEN the Memory SHALL maintain full message history within that thread.
2. WHEN the same `thread_id` is used across separate `run()` calls THEN the Memory SHALL include the prior conversation in the context sent to the model.
3. WHEN a `thread_id` is not provided THEN the Agent SHALL treat the call as a stateless, single-turn interaction with no memory retrieval.
4. WHEN a developer passes `memory=Memory.persistent("redis://...")` THEN the Memory SHALL store and retrieve thread history from that external Redis backend.
5. WHEN a developer passes `memory=Memory.semantic(embedder=...)` THEN the Memory SHALL store turns as vector embeddings and retrieve only the most relevant context chunks at each call.
6. WHEN a thread's token count approaches the model's context limit THEN the Memory SHALL automatically summarise or truncate older messages and emit a warning to the caller.

### Requirement 6: Sequential Pipeline Orchestration

**User Story:** As a developer, I want to chain multiple agents into a linear pipeline, so that each agent's output becomes the next agent's input without manual wiring.

#### Acceptance Criteria

1. WHEN a developer instantiates `Pipeline([agent_a, agent_b, agent_c])` and calls `pipeline.run("input")` THEN the Pipeline SHALL pass the output of each Agent as the input to the next Agent in declaration order.
2. WHEN any Agent in the Pipeline raises an error THEN the Pipeline SHALL halt execution, report which step failed including the step index and Agent name, and return the partial results from all successful prior steps.
3. WHEN streaming is requested on a Pipeline THEN the Pipeline SHALL yield events from each stage in sequence, with each event labelled with the stage name.
4. WHEN a developer passes `parallel=True` to a subset of Agents in the Pipeline THEN the Pipeline SHALL execute those Agents concurrently and merge their outputs before continuing to the next sequential step.

### Requirement 7: Stateful Graph Execution

**User Story:** As a developer, I want to define agent workflows as a directed graph with conditional edges and loops, so that I can model complex multi-step reasoning and review cycles.

#### Acceptance Criteria

1. WHEN a developer defines nodes with the `@node` decorator and edges with `graph.add_edges()` THEN the Graph SHALL execute starting from the entry node and follow edges based on the returned state.
2. WHEN an edge is defined with a `when=lambda state: bool` condition THEN the Graph SHALL only traverse that edge when the condition evaluates to `True`.
3. WHEN a node returns a state where no outbound edge condition is met THEN the Graph SHALL raise a `GraphRoutingError` identifying the stuck node and the current state.
4. WHEN a Graph is configured with `.with_checkpointing()` THEN the Graph SHALL persist state after each node execution so that a run can be resumed after interruption.
5. WHEN a Graph defines `Graph.END` as an edge target THEN the Graph SHALL terminate execution and return the final state as the RunResult.
6. WHEN two or more nodes have no dependency on each other in the Graph THEN the Graph SHALL execute them concurrently by default.
7. WHEN a developer calls `graph.visualise()` THEN the Graph SHALL render a Mermaid diagram string of the graph structure.

### Requirement 8: Human-in-the-Loop

**User Story:** As a developer, I want to pause graph or pipeline execution to collect human approval or input, so that I can build safe, auditable agentic workflows.

#### Acceptance Criteria

1. WHEN a Graph is configured with `.with_human_in_the_loop(pause_at=["node_name"])` THEN the Graph SHALL pause execution after that node and return a PausedRun object to the caller.
2. WHEN a PausedRun is returned THEN the PausedRun SHALL expose a `resume(human_input)` method that continues execution from the paused state.
3. WHEN a `timeout` is configured on the human-in-the-loop and the timeout elapses before `resume()` is called THEN the Graph SHALL either abort the run or route to a configured fallback node.
4. WHEN a run is paused THEN the Graph SHALL persist the full Checkpoint so that `resume()` can be called from a different process, server, or session.

### Requirement 9: Multi-Agent Teams

**User Story:** As a developer, I want to define a team of specialised agents orchestrated by a coordinator, so that I can solve complex tasks by delegating sub-tasks to the best-suited agent.

#### Acceptance Criteria

1. WHEN a developer instantiates `AgentTeam(orchestrator="model", agents=[...])` THEN the AgentTeam SHALL use the orchestrator model to decide which Agent handles each step.
2. WHEN `strategy="auto"` is set on the AgentTeam THEN the AgentTeam SHALL let the orchestrator model decide routing dynamically based on the task content.
3. WHEN `strategy="parallel"` is set on the AgentTeam THEN the AgentTeam SHALL dispatch the task to all Agents concurrently and return aggregated results.
4. WHEN an Agent in the team explicitly invokes `handoff(target_agent, context)` THEN the AgentTeam SHALL transfer execution to the named Agent with the supplied context.
5. WHEN an Agent in the team fails during execution THEN the AgentTeam SHALL log the failure, notify the orchestrator, and allow the orchestrator to route to a different Agent or surface the error.
6. WHEN a developer calls `team.run(task)` THEN the AgentTeam SHALL return a `TeamResult` containing each Agent's contribution, the full message trace, and the final synthesised answer.

### Requirement 10: Built-In Observability and Tracing

**User Story:** As a developer, I want every agent run to automatically produce a structured trace, so that I can debug failures and understand cost and performance without adding extra code.

#### Acceptance Criteria

1. WHEN any `run()` or `stream()` call completes THEN the Agent SHALL attach a `trace` attribute to the RunResult containing all LLM calls, tool calls, timestamps, token counts, and costs.
2. WHEN a developer calls `result.trace.show()` THEN the Trace SHALL open a visual trace view in the default browser with a timeline view.
3. WHEN a developer calls `result.trace.export()` THEN the Trace SHALL write an OpenTelemetry-compatible JSON file to disk.
4. WHEN the environment variable `SYNTH_TRACE_ENDPOINT` is set THEN the Agent SHALL automatically forward all traces to that OTEL collector endpoint without any code change.
5. WHEN a developer configures an integration with Langfuse, Datadog, or Honeycomb THEN the Trace system SHALL provide a one-line configuration option to enable that integration.

### Requirement 11: Built-In Evaluation Framework

**User Story:** As a developer, I want to run structured evaluations against my agent, so that I can detect regressions and measure quality automatically in CI/CD.

#### Acceptance Criteria

1. WHEN a developer creates an `Eval(agent=my_agent)` instance and adds cases with `eval.add_case(input, expected)` THEN the Eval SHALL run each case against the live Agent and score the results.
2. WHEN an expected value is a string THEN the Eval SHALL use exact-match and semantic-similarity scoring by default.
3. WHEN a developer provides a `checker=fn` callable THEN the Eval SHALL use that function to score the output, enabling custom evaluation logic.
4. WHEN `eval.run()` is called THEN the Eval SHALL return an EvalReport containing pass/fail per case, overall score, latency per case, and cost per case.
5. WHEN an EvalReport is compared to a prior report via `eval.compare(baseline_report)` THEN the Eval SHALL highlight regressions and improvements with per-case deltas.
6. WHEN a developer runs `synth eval my_agent.py --dataset cases.json` from the CLI THEN the CLI SHALL execute the evaluation and exit with a non-zero code if the pass rate falls below a configurable threshold.

### Requirement 12: Guardrails

**User Story:** As a developer, I want to apply input and output guardrails declaratively, so that I can enforce safety, cost, and policy constraints without writing custom middleware.

#### Acceptance Criteria

1. WHEN `Guard.no_pii_output()` is added to an Agent THEN the Guard SHALL scan every response before returning it and raise a GuardViolationError if PII is detected.
2. WHEN `Guard.max_cost(dollars=0.10)` is added to an Agent THEN the Guard SHALL track cumulative cost for the run and abort with a `CostLimitError` if the limit is exceeded.
3. WHEN `Guard.no_tool_calls(["delete_*"])` is added to an Agent THEN the Guard SHALL block any tool call whose name matches the glob pattern and raise a GuardViolationError with the tool name.
4. WHEN `Guard.custom(fn)` is added to an Agent THEN the Guard SHALL call `fn(input_or_output)` and raise a GuardViolationError if the function returns `False` or raises an exception.
5. WHEN a GuardViolationError is raised THEN the Guard SHALL include the guard name, the violating content snippet, and a suggested remediation in the error message.
6. WHEN multiple Guards are configured on an Agent THEN the Agent SHALL evaluate them in declaration order and stop at the first violation.

### Requirement 13: Resumable Runs and Checkpointing

**User Story:** As a developer, I want interrupted runs to be resumable, so that long-running agentic workflows can recover from failures without starting over.

#### Acceptance Criteria

1. WHEN a run is started with `run_id="abc123"` THEN the Checkpoint system SHALL persist a Checkpoint after each node or step completes.
2. WHEN a developer calls `graph.resume("abc123")` THEN the Checkpoint system SHALL restore the last Checkpoint and continue execution from that point.
3. WHEN no Checkpoint exists for the given `run_id` THEN the Checkpoint system SHALL raise a `RunNotFoundError` with the supplied ID.
4. WHEN a checkpoint store backend is not configured THEN the Checkpoint system SHALL default to local disk storage in a `.synth/checkpoints/` directory.
5. WHEN a developer configures `checkpoint_store="redis://..."` THEN the Checkpoint system SHALL use Redis for distributed checkpoint storage, enabling multi-process and multi-host resume.

### Requirement 14: CLI Developer Experience

**User Story:** As a developer, I want a CLI tool that runs my agent locally with hot-reload and a trace UI, so that I can iterate quickly without deploying to a server.

#### Acceptance Criteria

1. WHEN a developer runs `synth dev my_agent.py` THEN the CLI SHALL start the Agent in a local REPL with hot-reload on file save and open the Trace UI in the browser.
2. WHEN a developer runs `synth run my_agent.py "prompt"` THEN the CLI SHALL execute the Agent with that prompt and print the RunResult plus trace summary to stdout.
3. WHEN a developer runs `synth eval my_agent.py --dataset cases.json` THEN the CLI SHALL run the evaluation suite and print a pass/fail report with a summary score.
4. WHEN a developer runs `synth trace <run_id>` THEN the CLI SHALL open the stored Trace for that run ID in the browser trace viewer.
5. WHEN the `synth dev` server is running and an agent file is saved THEN the CLI SHALL automatically reload the Agent without restarting the process.

### Requirement 15: Error Clarity and Developer Experience

**User Story:** As a developer, I want clear, actionable error messages throughout the SDK, so that I can resolve problems without having to search documentation or source code.

#### Acceptance Criteria

1. WHEN any SDK error is raised THEN the error SHALL include: what went wrong, which component raised it, the inputs that caused it, and a suggested fix.
2. WHEN a model call fails due to an invalid API key THEN the error SHALL state the Provider name, the environment variable expected, and a link to obtain the key.
3. WHEN a Graph enters an infinite loop detected by exceeding a configurable `max_iterations` THEN the Graph SHALL raise a `GraphLoopError` with the node execution history.
4. WHEN a Tool returns a value whose type does not match the declared return annotation THEN the Agent SHALL emit a warning with the tool name, expected type, and actual type.
5. WHEN a developer runs `synth doctor` THEN the CLI SHALL check environment variables, Provider credentials, and dependency versions, and report any issues with fix instructions.

### Requirement 16: Async and Sync Support

**User Story:** As a developer, I want to use the SDK in both synchronous and asynchronous contexts, so that I can integrate it into scripts, web servers, and notebooks without friction.

#### Acceptance Criteria

1. WHEN a developer calls `agent.run("prompt")` in a synchronous context THEN the Agent SHALL block and return the RunResult without requiring the developer to manage an event loop.
2. WHEN a developer calls `await agent.arun("prompt")` in an async context THEN the Agent SHALL execute asynchronously without blocking the event loop.
3. WHEN a developer calls `agent.stream("prompt")` in a synchronous context THEN the Agent SHALL return a synchronous generator of typed events.
4. WHEN a developer calls `agent.astream("prompt")` in an async context THEN the Agent SHALL return an async generator of typed events.

### Requirement 17: Structured Output

**User Story:** As a developer, I want the agent to return validated, typed output objects, so that I can integrate agent responses directly into my application logic without parsing strings.

#### Acceptance Criteria

1. WHEN a developer passes `output_schema=MyPydanticModel` to the Agent THEN the Agent SHALL instruct the model to produce output conforming to that schema and parse the response automatically.
2. WHEN the model's output cannot be parsed into the schema THEN the Agent SHALL retry up to a configurable number of times with a corrective prompt before raising a `SynthParseError`.
3. WHEN the output is successfully parsed THEN `result.output` SHALL be an instance of the specified Pydantic model, not a raw string.
4. WHEN a developer passes `output_schema` to a Pipeline THEN only the final stage's output SHALL be validated against the schema.

### Requirement 18: Package and Dependency Design

**User Story:** As a developer, I want the core SDK to have minimal dependencies, so that I can install it quickly without unnecessary bloat.

#### Acceptance Criteria

1. WHEN a developer runs `pip install synth-agent-sdk` THEN the package SHALL install only the core package with fewer than 5 required runtime dependencies.
2. WHEN a developer needs a specific Provider THEN the package SHALL support optional installs such as `pip install synth-agent-sdk[anthropic]`, `pip install synth-agent-sdk[openai]`, `pip install synth-agent-sdk[bedrock]`, and `pip install synth-agent-sdk[all]`.
3. WHEN a developer installs a Provider extra THEN the package SHALL install only the SDK for that Provider and not install SDKs for other Providers.
4. WHEN the package version is updated THEN the package SHALL adhere to semantic versioning and maintain a CHANGELOG documenting breaking changes.

### Requirement 19: Terminal Branding and Boot Sequence

**User Story:** As a developer, I want Synth to display an immersive, Fallout-inspired terminal boot sequence when first initialised, so that the SDK has a memorable and distinctive identity that reflects its character from the moment of installation.

#### Acceptance Criteria

1. WHEN a developer runs `synth` or `synth dev` for the first time after installation THEN the CLI SHALL display a full boot sequence in the terminal before any other output.
2. WHEN the boot sequence renders THEN the CLI SHALL display the following elements in order: a top border of `=` characters spanning the terminal width in dim green, a large ASCII art Synth logo on the left in dim green, the word `SynthSDK` in large ASCII block letters to the right in bright green, the text `[ AUTHENTICATION: GRANTED ]` in bright green, and a bottom border of `=` characters in dim green.
3. WHEN the logo section has rendered THEN the CLI SHALL display boot status lines in order: three `[   OK   ]` lines in bright green for agent kernel, vector embeddings, and tool-use permissions, followed by a `[ ERROR  ]` line with red background white text badge and bold yellow message text with a simulated flicker effect, followed by a `>> SYSTEM READY` line in bright green.
4. WHEN the boot status lines render THEN the CLI SHALL introduce a randomised delay of between 40ms and 120ms between each line to simulate a real system initialisation sequence.
5. WHEN the `[ ERROR  ]` line renders THEN the CLI SHALL apply a flicker effect by rapidly toggling bold on the line text 3 times before settling, using bold yellow.
6. WHEN the full sequence has rendered THEN the CLI SHALL display a closing divider of `-` characters spanning the terminal width in dim green, followed by a blank line before any SDK output begins.
7. WHEN the terminal width cannot be determined THEN the CLI SHALL default to a width of 80 characters for all borders and dividers.
8. WHEN the environment variable `SYNTH_NO_BANNER=1` is set THEN the CLI SHALL skip the boot sequence entirely, outputting no decorative terminal content.
9. WHEN the terminal does not support colour (detected via `NO_COLOR` env var or non-TTY stdout) THEN the CLI SHALL render the boot sequence in plain monochrome ASCII without any colour codes or flicker effects.
10. WHEN the boot sequence has been displayed once in a session THEN the CLI SHALL not display it again for subsequent commands or agent runs within the same process.
11. WHEN the CLI renders the colour scheme THEN the CLI SHALL use the following palette consistently: main text and borders in bright green, border and logo fill in dim green, warning and flicker text in bold yellow, error badge background in red with white text, and closing divider in dim green.

### Requirement 20: AWS AgentCore Deployment

**User Story:** As a developer, I want to deploy my Synth agents directly to AWS AgentCore with minimal configuration, so that I can run production agents at scale without managing infrastructure.

#### Acceptance Criteria

1. WHEN a developer decorates an Agent or Graph with `@agentcore_handler` THEN the SDK SHALL produce an AWS AgentCore-compatible request handler that conforms to the AgentCore runtime invocation contract.
2. WHEN a developer runs `synth deploy --target agentcore` THEN the CLI SHALL package the agent code, dependencies, and configuration into a deployment artifact suitable for AWS AgentCore.
3. WHEN deploying to AgentCore THEN the SDK SHALL generate or update an AgentCore agent descriptor (agent manifest) that declares the agent's name, description, supported actions, and required IAM permissions.
4. WHEN the agent is invoked within the AgentCore runtime THEN the SDK SHALL translate the AgentCore invocation payload into the standard Synth `run()` input format and translate the Synth RunResult back into the AgentCore response format.
5. WHEN the agent uses tools that require AWS service access THEN the SDK SHALL integrate with the AgentCore identity and authorization model, using the runtime-provided credentials rather than requiring separate credential configuration.
6. WHEN the agent is configured with Memory THEN the SDK SHALL integrate with AgentCore's managed memory service for session and long-term memory, falling back to the Synth-native Memory backend if AgentCore memory is unavailable.
7. WHEN the agent produces Traces THEN the SDK SHALL forward trace data to AgentCore's built-in observability infrastructure in addition to any Synth-configured trace endpoints.
8. WHEN a developer runs `synth deploy --target agentcore --dry-run` THEN the CLI SHALL validate the deployment configuration, check IAM permissions, and report any issues without actually deploying.
9. WHEN the `synth-agent-sdk[agentcore]` extra is not installed THEN the CLI SHALL raise a SynthConfigError with the exact `pip install synth-agent-sdk[agentcore]` command needed.
10. WHEN an agent deployed to AgentCore uses Graph-based orchestration with checkpointing THEN the SDK SHALL use AgentCore's managed state persistence for Checkpoints instead of local disk or self-managed Redis.

## Non-Functional Requirements

### NFR-1: Performance

1. WHEN an Agent with no tools is called THEN the SDK SHALL add no more than 10ms of overhead to the raw Provider API call latency.
2. WHEN a Pipeline with 5 Agents is run THEN the SDK SHALL introduce no more than 50ms of orchestration overhead per step.

### NFR-2: Reliability

1. WHEN a Provider returns an HTTP 5xx error THEN the SDK SHALL retry automatically with exponential backoff up to 3 times before surfacing the error.
2. WHEN a Checkpoint is written THEN the Checkpoint system SHALL use atomic writes to prevent corrupt state.

### NFR-3: Test Coverage

1. WHEN the repository is checked out and `pytest` is run THEN the test suite SHALL achieve at least 90% line coverage across the core and orchestration modules.
2. WHEN Provider integrations are tested THEN the SDK SHALL support a mock Provider mode that makes no live API calls, enabling full CI without API keys.

### NFR-4: Documentation

1. WHEN a new public API symbol is added THEN the symbol SHALL include a docstring and at least one usage example.
2. WHEN the documentation site is built THEN the documentation SHALL include a Getting Started guide that a new developer can complete end-to-end in under 5 minutes.

### NFR-5: Python Version Support

1. WHEN a developer installs the package THEN the SDK SHALL support Python 3.10, 3.11, 3.12, and 3.13.
