# Implementation Plan: Multi-Agent Init Flow

## Overview

Extend `synth init` with a fork that lets users choose between single-agent (existing flow) and multi-agent project scaffolding. The multi-agent path guides users through configuring multiple agents, selecting/configuring an orchestration pattern, and generating a complete working project.

## Tasks

- [x] 1. Add data models and the single/multi fork to `run_init()`
  - [x] 1.1 Add `AgentConfig`, `PipelineConfig`, `EdgeConfig`, `GraphConfig`, `AgentTeamConfig`, `HumanInLoopConfig`, `OrchestrationConfig` dataclasses to `init_cmd.py`
    - Place after existing `McpWizardResult` dataclass
    - Follow SDK conventions: `@dataclass`, `field(default_factory=...)` for mutable defaults
    - _Requirements: 1, 2, 3, 4, 5, 6, 7, 8_

  - [x] 1.2 Add the single/multi fork at the top of `run_init()`
    - After the welcome banner, prompt for "single" or "multi" project type
    - If "multi", call `_run_multi_agent_init()` and return
    - If "single", continue with existing flow unchanged
    - _Requirements: 1.1, 1.2, 1.3, 13.1_

- [x] 2. Implement `_configure_agent()` helper
  - [x] 2.1 Create `_configure_agent(index, existing_names)` function
    - Prompt for agent name (unique, non-empty), description, provider, model, instructions
    - Reuse `_check_provider_deps()`, `_run_model_selection()`, `_run_tool_wizard()`, `_run_mcp_wizard()`
    - Return `AgentConfig` dataclass
    - Reject duplicate names
    - _Requirements: 3.1–3.10, 13.2_

- [x] 3. Implement orchestration selection and pattern-specific configurators
  - [x] 3.1 Create `_select_orchestration(agents)` function
    - Display all four patterns with descriptions matching the requirements spec
    - Delegate to pattern-specific configurator based on selection
    - Return `OrchestrationConfig`
    - _Requirements: 4.1–4.7_

  - [x] 3.2 Create `_configure_pipeline(agents)` function
    - Display agent names, prompt for execution order
    - Default to configuration order
    - _Requirements: 5.1–5.4_

  - [x] 3.3 Create `_configure_graph(agents)` function
    - Assign agents as nodes, prompt for entry node, edges (source/target/condition)
    - Allow `END` as target
    - _Requirements: 6.1–6.6_

  - [x] 3.4 Create `_configure_agent_team(agents)` function
    - Prompt for strategy (auto/parallel) with descriptions
    - Prompt for orchestrator model
    - _Requirements: 7.1–7.5_

  - [x] 3.5 Create `_configure_human_in_loop(agents)` function
    - Run graph configuration first, then prompt for pause nodes, timeout, fallback
    - _Requirements: 8.1–8.5_

- [x] 4. Implement `_run_multi_agent_init()` main flow
  - [x] 4.1 Create `_run_multi_agent_init()` function
    - Project name + description
    - Agent count (min 2)
    - Agent configuration loop calling `_configure_agent()`
    - Orchestration selection
    - Feature selection (reuse existing)
    - Credential check if any agent is AgentCore
    - Summary + confirm
    - Project generation
    - Deploy prompt if any agent is AgentCore
    - _Requirements: 2, 9, 10, 12_

- [x] 5. Implement multi-agent project generation
  - [x] 5.1 Create `_generate_multi_agent_project()` function
    - Create project directory
    - Generate one agent file per agent (`agent_<name>.py`)
    - Generate `main.py` with orchestration wiring
    - Generate README, synth.toml, tool files, MCP dirs
    - Generate agentcore.yaml + .env.template if any agent uses AgentCore
    - _Requirements: 11.1–11.11_

  - [x] 5.2 Create code generation helpers
    - `_build_multi_agent_code()` — single agent file in multi-agent project
    - `_build_orchestration_code()` — main.py dispatcher
    - `_build_pipeline_code()`, `_build_graph_code()`, `_build_team_code()`, `_build_human_in_loop_code()`
    - `_build_multi_agent_readme()`
    - _Requirements: 11.2–11.10_

- [x] 6. Verify implementation
  - Run diagnostics on init_cmd.py to check for syntax/type errors
  - Verify the single-agent flow is unchanged
  - _Requirements: 13.1–13.3_

## Notes

- All changes are scoped to `synth/cli/init_cmd.py`
- Existing helper functions are reused without modification
- The single-agent flow remains completely unchanged
- Code generation templates follow the patterns established by `_build_agent_code()`
