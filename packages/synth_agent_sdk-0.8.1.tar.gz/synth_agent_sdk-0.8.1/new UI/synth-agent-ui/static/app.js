/* Synth Agent UI — app.js */

// ------------------------------------------------------------------ //
// DOM refs                                                            //
// ------------------------------------------------------------------ //
const chatArea       = document.getElementById("chat-area");
const chatForm       = document.getElementById("chat-form");
const promptInput    = document.getElementById("prompt-input");
const btnSend        = document.getElementById("btn-send");
const btnClear       = document.getElementById("btn-clear");
const btnReload      = document.getElementById("btn-reload");
const statusBadge    = document.getElementById("status");
const toolDrawer     = document.getElementById("tool-drawer");
const toolSelect     = document.getElementById("tool-select");
const toolDesc       = document.getElementById("tool-description");
const toolArgsEditor = document.getElementById("tool-args-editor");
const toolOutput     = document.getElementById("tool-output");
const convList       = document.getElementById("conv-list");
const topbarTitle    = document.getElementById("topbar-title");
const sidebar        = document.getElementById("sidebar");
const telemetryContent = document.getElementById("telemetry-content");
const telemetryEmpty   = document.getElementById("telemetry-empty");
const elapsedTimer     = document.getElementById("elapsed-timer");
const varBar           = document.getElementById("var-bar");

// ------------------------------------------------------------------ //
// State                                                               //
// ------------------------------------------------------------------ //
let isLoading      = false;
let currentConv    = "default";
let toolSchemas    = {};
let sessionTokens  = 0;
let sessionCost    = 0;
let turnCount      = 0;
let costHistory    = [];
let promptHistory  = [];
let historyIndex   = -1;
let reconnectTimer = null;
let elapsedInterval = null;
let activeTab      = "chat";
let editingScenarioId = null;

// ------------------------------------------------------------------ //
// Init                                                                //
// ------------------------------------------------------------------ //
async function init() {
    await Promise.all([loadAgentInfo(), loadTools(), loadConversations()]);
    autoResizeTextarea();
    initResizeHandle();
    initKeyboardShortcuts();
    initTabs();
    startHealthCheck();
    loadPrompts();
    loadEvals();
    loadScenarios();
    populateReplaySelect();
}

// ------------------------------------------------------------------ //
// Tabs                                                                //
// ------------------------------------------------------------------ //
function initTabs() {
    document.querySelectorAll(".tab").forEach(btn => {
        btn.addEventListener("click", () => switchTab(btn.dataset.tab));
    });
}

function switchTab(name) {
    activeTab = name;
    document.querySelectorAll(".tab").forEach(b => b.classList.toggle("active", b.dataset.tab === name));
    document.querySelectorAll(".tab-content").forEach(c => c.classList.toggle("active", c.id === "tab-" + name));
    if (name === "observe") populateReplaySelect();
}

// ------------------------------------------------------------------ //
// Agent info / health                                                 //
// ------------------------------------------------------------------ //
async function loadAgentInfo() {
    try {
        const r = await fetch("/api/info");
        const d = await r.json();
        document.getElementById("info-model").textContent = d.model;
        document.getElementById("info-tools").textContent = d.tools;
        const statusEl = document.getElementById("info-status");
        if (d.status && d.status.loaded) {
            statusEl.textContent = "OK"; statusEl.className = "info-value ok";
        } else {
            statusEl.textContent = d.status && d.status.error ? "ERROR" : "—";
            statusEl.className = "info-value err";
        }
    } catch (e) { /* ignore */ }
}

async function loadTools() {
    try {
        const r = await fetch("/api/tools");
        const d = await r.json();
        toolSelect.innerHTML = '<option value="">Select a tool...</option>';
        for (const t of d.tools) {
            toolSchemas[t.name] = t;
            const opt = document.createElement("option");
            opt.value = t.name; opt.textContent = t.name;
            toolSelect.appendChild(opt);
        }
    } catch (e) { /* ignore */ }
}

async function loadConversations() {
    try {
        const r = await fetch("/api/conversations");
        const d = await r.json();
        renderConvList(d.conversations, d.current);
    } catch (e) { /* ignore */ }
}

function startHealthCheck() {
    setInterval(async () => {
        try {
            const r = await fetch("/api/health");
            if (r.ok && reconnectTimer) {
                clearTimeout(reconnectTimer); reconnectTimer = null;
                setStatus("CONNECTED", true); await loadAgentInfo();
            }
        } catch (e) {
            if (!reconnectTimer && !isLoading) {
                setStatus("DISCONNECTED", false);
                reconnectTimer = setTimeout(() => { reconnectTimer = null; }, 5000);
            }
        }
    }, 5000);
}

// ------------------------------------------------------------------ //
// Resize handle                                                       //
// ------------------------------------------------------------------ //
function initResizeHandle() {
    const handle = document.getElementById("resize-handle");
    const panel  = document.getElementById("telemetry-panel");
    let dragging = false, startX = 0, startW = 0;
    handle.addEventListener("mousedown", e => {
        dragging = true; startX = e.clientX; startW = panel.offsetWidth;
        handle.classList.add("dragging");
        document.body.style.cursor = "col-resize";
        document.body.style.userSelect = "none";
    });
    document.addEventListener("mousemove", e => {
        if (!dragging) return;
        const newW = Math.max(200, Math.min(600, startW + (startX - e.clientX)));
        panel.style.width = newW + "px";
    });
    document.addEventListener("mouseup", () => {
        if (!dragging) return;
        dragging = false; handle.classList.remove("dragging");
        document.body.style.cursor = ""; document.body.style.userSelect = "";
    });
}

// ------------------------------------------------------------------ //
// Keyboard shortcuts                                                  //
// ------------------------------------------------------------------ //
function initKeyboardShortcuts() {
    document.addEventListener("keydown", e => {
        if (e.key === "/" && document.activeElement !== promptInput) {
            e.preventDefault(); promptInput.focus();
        }
    });
}

// ------------------------------------------------------------------ //
// Helpers                                                             //
// ------------------------------------------------------------------ //
function esc(text) {
    const d = document.createElement("div");
    d.textContent = String(text); return d.innerHTML;
}
function renderMarkdown(text) {
    if (typeof marked === "undefined") return "<p>" + esc(text) + "</p>";
    try { return marked.parse(text, { breaks: true, gfm: true }); }
    catch (e) { return "<p>" + esc(text) + "</p>"; }
}
function clearWelcome() { const w = document.getElementById("welcome"); if (w) w.remove(); }
function scrollToBottom() { chatArea.scrollTop = chatArea.scrollHeight; }
function setStatus(text, ok) {
    const dot   = statusBadge.querySelector(".status-dot");
    const label = statusBadge.querySelector(".status-text");
    label.textContent = text;
    const color = ok ? "var(--green)" : "var(--red)";
    dot.style.background = color; dot.style.boxShadow = "0 0 6px " + color;
    statusBadge.style.borderColor = ok ? "var(--green-dim)" : "var(--red)";
    statusBadge.style.color = color;
}
function startElapsedTimer() {
    let secs = 0; elapsedTimer.classList.remove("hidden"); elapsedTimer.textContent = "0s";
    elapsedInterval = setInterval(() => { secs++; elapsedTimer.textContent = secs + "s"; }, 1000);
}
function stopElapsedTimer() { clearInterval(elapsedInterval); elapsedTimer.classList.add("hidden"); }
function autoResizeTextarea() {
    promptInput.addEventListener("input", () => {
        promptInput.style.height = "auto";
        promptInput.style.height = Math.min(promptInput.scrollHeight, 120) + "px";
        detectVariables();
    });
}
function fmt(n)     { return typeof n === "number" ? n.toLocaleString() : "—"; }
function fmtCost(n) { return typeof n === "number" ? "$" + n.toFixed(6) : "—"; }
function fmtMs(n)   { return typeof n === "number" ? n.toFixed(0) + "ms" : "—"; }

// ------------------------------------------------------------------ //
// Variable injection                                                  //
// ------------------------------------------------------------------ //
function detectVariables() {
    const text = promptInput.value;
    const vars = [...new Set([...text.matchAll(/\{\{(\w+)\}\}/g)].map(m => m[1]))];
    varBar.innerHTML = "";
    for (const v of vars) {
        const chip = document.createElement("div");
        chip.className = "var-chip";
        chip.innerHTML = `<span class="var-chip-label">{{${v}}}</span>`;
        const inp = document.createElement("input");
        inp.className = "var-chip-input"; inp.placeholder = "value..."; inp.dataset.var = v;
        chip.appendChild(inp); varBar.appendChild(chip);
    }
}

function resolveVariables(text) {
    return text.replace(/\{\{(\w+)\}\}/g, (_, name) => {
        const inp = varBar.querySelector(`[data-var="${name}"]`);
        return inp ? inp.value || `{{${name}}}` : `{{${name}}}`;
    });
}

// ------------------------------------------------------------------ //
// Conversations                                                       //
// ------------------------------------------------------------------ //
function renderConvList(ids, active) {
    convList.innerHTML = "";
    for (const id of ids) {
        const el = document.createElement("div");
        el.className = "conv-item" + (id === active ? " active" : "");
        const name = document.createElement("span");
        name.className = "conv-item-name"; name.textContent = id;
        name.onclick = () => switchConv(id);
        el.appendChild(name);
        if (id !== "default") {
            const del = document.createElement("button");
            del.className = "conv-delete"; del.textContent = "x"; del.title = "Delete";
            del.onclick = e => { e.stopPropagation(); deleteConv(id); };
            el.appendChild(del);
        }
        convList.appendChild(el);
    }
    currentConv = active; topbarTitle.textContent = active;
}

async function switchConv(id) {
    currentConv = id; topbarTitle.textContent = id;
    document.querySelectorAll(".conv-item").forEach(el => {
        const n = el.querySelector(".conv-item-name");
        el.classList.toggle("active", n && n.textContent === id);
    });
    chatArea.innerHTML = "";
    sessionTokens = 0; sessionCost = 0; turnCount = 0; costHistory = [];
    try {
        const r = await fetch("/api/conversations/" + id);
        const d = await r.json();
        for (const msg of d.messages) {
            if (msg.role === "user") addUserMessage(msg.content);
            else if (msg.role === "agent") addAgentMessage(msg.data, false);
        }
    } catch (e) { /* ignore */ }
}

async function newConversation() {
    try {
        const r = await fetch("/api/conversations", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({}),
        });
        await r.json(); await loadConversations();
        chatArea.innerHTML = "";
        sessionTokens = 0; sessionCost = 0; turnCount = 0; costHistory = [];
        telemetryContent.classList.add("hidden"); telemetryEmpty.classList.remove("hidden");
    } catch (e) { /* ignore */ }
}

async function deleteConv(id) {
    try {
        await fetch("/api/conversations/" + id, { method: "DELETE" });
        if (currentConv === id) { currentConv = "default"; chatArea.innerHTML = ""; }
        await loadConversations();
    } catch (e) { /* ignore */ }
}

// ------------------------------------------------------------------ //
// Messages                                                            //
// ------------------------------------------------------------------ //
function addUserMessage(text) {
    clearWelcome();
    const div = document.createElement("div");
    div.className = "message msg-user";
    const copyBtn = `<button class="msg-copy" onclick="copyMsg(this, ${JSON.stringify(esc(text))})">copy</button>`;
    div.innerHTML = `<div class="msg-header"><span class="msg-label msg-label-user">YOU</span>${copyBtn}</div><div class="msg-body">${esc(text)}</div>`;
    chatArea.appendChild(div); scrollToBottom();
}

function addAgentMessage(data, animate = true) {
    clearWelcome();
    const div = document.createElement("div");
    div.className = "message msg-agent";
    let bodyHtml = data.output && typeof data.output === "object"
        ? `<span class="msg-structured">STRUCTURED OUTPUT</span><br><pre style="white-space:pre-wrap;font-size:12px;margin-top:6px;">${esc(JSON.stringify(data.output, null, 2))}</pre>`
        : renderMarkdown(data.text || "");
    const copyText = data.output ? JSON.stringify(data.output, null, 2) : (data.text || "");
    const copyBtn = `<button class="msg-copy" onclick="copyMsg(this, ${JSON.stringify(esc(copyText))})">copy</button>`;
    div.innerHTML = `<div class="msg-header"><span class="msg-label msg-label-agent">AGENT</span>${copyBtn}</div><div class="msg-body">${bodyHtml}</div>`;
    chatArea.appendChild(div); scrollToBottom();
    if (animate) updateTelemetry(data);
}

function addStreamingMessage() {
    clearWelcome();
    const div = document.createElement("div");
    div.className = "message msg-agent"; div.id = "streaming-msg";
    div.innerHTML =
        `<div class="msg-header"><span class="msg-label msg-label-agent">AGENT</span></div>` +
        `<div id="thinking-block" class="thinking-block hidden">` +
            `<div class="thinking-header" onclick="toggleThinking()">&#x1F9E0; <span class="thinking-label">Thinking</span><span class="thinking-toggle">&#x25BC;</span></div>` +
            `<div class="thinking-body" id="thinking-body"></div>` +
        `</div>` +
        `<div class="msg-body" id="streaming-body"><span class="stream-cursor"></span></div>`;
    chatArea.appendChild(div); scrollToBottom(); return div;
}

function updateStreamingMessage(text) {
    const body = document.getElementById("streaming-body");
    if (body) { body.innerHTML = renderMarkdown(text) + '<span class="stream-cursor"></span>'; scrollToBottom(); }
}

function updateThinking(text) {
    const block = document.getElementById("thinking-block");
    const body  = document.getElementById("thinking-body");
    if (!block || !body) return;
    block.classList.remove("hidden"); body.textContent = text; scrollToBottom();
}

function toggleThinking() {
    const body   = document.getElementById("thinking-body");
    const toggle = document.querySelector(".thinking-toggle");
    if (!body) return;
    const collapsed = body.classList.toggle("hidden");
    if (toggle) toggle.textContent = collapsed ? "▶" : "▼";
}

function collapseThinking() {
    const body   = document.getElementById("thinking-body");
    const toggle = document.querySelector(".thinking-toggle");
    const label  = document.querySelector(".thinking-label");
    if (body)   body.classList.add("hidden");
    if (toggle) toggle.textContent = "▶";
    if (label)  label.textContent = "Thinking (click to expand)";
}

function finalizeStreamingMessage(data) {
    const div  = document.getElementById("streaming-msg");
    if (div) div.removeAttribute("id");
    const body = document.getElementById("streaming-body");
    if (body) {
        body.removeAttribute("id");
        const cursor = body.querySelector(".stream-cursor");
        if (cursor) cursor.remove();
        if (data.output && typeof data.output === "object") {
            body.innerHTML = `<span class="msg-structured">STRUCTURED OUTPUT</span><br><pre style="white-space:pre-wrap;font-size:12px;margin-top:6px;">${esc(JSON.stringify(data.output, null, 2))}</pre>`;
        }
        if (div) {
            const header = div.querySelector(".msg-header");
            if (header) {
                const copyText = data.output ? JSON.stringify(data.output, null, 2) : (data.text || "");
                const btn = document.createElement("button");
                btn.className = "msg-copy"; btn.textContent = "copy";
                btn.onclick = () => copyMsg(btn, copyText);
                header.appendChild(btn);
            }
        }
    }
    updateTelemetry(data);
}

function addErrorMessage(text) {
    const div = document.createElement("div");
    div.className = "message msg-error";
    div.innerHTML = `<div class="msg-header"><span class="msg-label msg-label-error">ERROR</span></div><div class="msg-body">${esc(text)}</div>`;
    chatArea.appendChild(div); scrollToBottom();
}

function copyMsg(btn, text) {
    navigator.clipboard.writeText(text).then(() => {
        btn.textContent = "copied!"; btn.classList.add("copied");
        setTimeout(() => { btn.textContent = "copy"; btn.classList.remove("copied"); }, 1500);
    });
}

// ------------------------------------------------------------------ //
// Telemetry                                                           //
// ------------------------------------------------------------------ //
function updateTelemetry(data) {
    sessionTokens += (data.tokens && data.tokens.total) || 0;
    sessionCost   += data.cost || 0;
    turnCount++;
    costHistory.push(data.cost || 0);

    telemetryEmpty.classList.add("hidden");
    telemetryContent.classList.remove("hidden");

    document.getElementById("t-tokens-in").textContent    = fmt(data.tokens && data.tokens.input);
    document.getElementById("t-tokens-out").textContent   = fmt(data.tokens && data.tokens.output);
    document.getElementById("t-tokens-total").textContent = fmt(data.tokens && data.tokens.total);
    document.getElementById("t-cost").textContent         = fmtCost(data.cost);
    document.getElementById("t-latency").textContent      = fmtMs(data.latency_ms);
    document.getElementById("t-turns").textContent        = turnCount;
    document.getElementById("t-session-tokens").textContent = fmt(sessionTokens);
    document.getElementById("t-session-cost").textContent   = fmtCost(sessionCost);

    drawCostChart();

    const confSection = document.getElementById("telem-confidence-section");
    if (data.output && typeof data.output.confidence === "number") {
        confSection.classList.remove("hidden");
        const pct = Math.round(data.output.confidence * 100);
        document.getElementById("confidence-bar").style.width = pct + "%";
        document.getElementById("confidence-value").textContent = pct + "%";
    } else {
        confSection.classList.add("hidden");
    }

    const toolsEl = document.getElementById("t-tool-calls");
    if (data.tool_calls && data.tool_calls.length > 0) {
        toolsEl.innerHTML = data.tool_calls.map(tc =>
            `<div class="telem-tool-call">
                <div class="telem-tool-name">${esc(tc.name)}</div>
                <div class="telem-tool-args">Args: ${esc(JSON.stringify(tc.args))}</div>
                <div class="telem-tool-result">Result: ${esc(String(tc.result).substring(0, 200))}</div>
                <div class="telem-tool-latency">${fmtMs(tc.latency_ms)}</div>
            </div>`
        ).join("");
    } else {
        toolsEl.innerHTML = '<p class="empty-state">No tool calls.</p>';
    }

    const traceEl = document.getElementById("t-trace-spans");
    if (data.trace && data.trace.length > 0) {
        traceEl.innerHTML = data.trace.map(s =>
            `<div class="telem-span" data-type="${esc(s.type)}">
                <span class="span-name">${esc(s.name)}</span>
                <span class="span-type">${esc(s.type)}</span>
                <span class="span-duration">${fmtMs(s.duration_ms)}</span>
                ${s.metadata && Object.keys(s.metadata).length > 0
                    ? `<div class="span-meta">${esc(Object.entries(s.metadata).map(([k,v]) => k+": "+v).join(" | "))}</div>`
                    : ""}
            </div>`
        ).join("");
    } else {
        traceEl.innerHTML = '<p class="empty-state">No trace data.</p>';
    }
}

function drawCostChart() {
    const canvas = document.getElementById("cost-chart");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const w = canvas.offsetWidth || 280;
    canvas.width = w; canvas.height = 50;
    ctx.clearRect(0, 0, w, 50);
    if (costHistory.length < 2) {
        ctx.fillStyle = "#6a7a8a"; ctx.font = "10px monospace";
        ctx.fillText("Need 2+ turns for chart", 8, 28); return;
    }
    const max  = Math.max(...costHistory) || 1;
    const step = w / (costHistory.length - 1);
    ctx.beginPath(); ctx.strokeStyle = "#39ff14"; ctx.lineWidth = 1.5;
    costHistory.forEach((v, i) => {
        const x = i * step, y = 46 - (v / max) * 40;
        i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.stroke();
    ctx.lineTo((costHistory.length - 1) * step, 50); ctx.lineTo(0, 50); ctx.closePath();
    ctx.fillStyle = "rgba(57,255,20,0.06)"; ctx.fill();
    costHistory.forEach((v, i) => {
        const x = i * step, y = 46 - (v / max) * 40;
        ctx.beginPath(); ctx.arc(x, y, 2.5, 0, Math.PI * 2);
        ctx.fillStyle = "#39ff14"; ctx.fill();
    });
}

function exportTelemetry() {
    const rows = [["turn", "cost_usd"]];
    costHistory.forEach((c, i) => rows.push([i + 1, c.toFixed(8)]));
    const csv  = rows.map(r => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const a    = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = "synth-telemetry.csv"; a.click();
}

// ------------------------------------------------------------------ //
// Tool playground                                                     //
// ------------------------------------------------------------------ //
function renderToolArgs(name) {
    const schema = toolSchemas[name];
    if (!schema) { toolArgsEditor.innerHTML = ""; toolDesc.textContent = ""; return; }
    toolDesc.textContent = schema.description;
    const props    = schema.parameters.properties || {};
    const required = schema.parameters.required   || [];
    let html = "";
    for (const [pname, pschema] of Object.entries(props)) {
        const req = required.includes(pname) ? " *" : "";
        html += `<div class="tool-arg-row">
            <span class="tool-arg-label">${pname}${req}</span>
            <input class="tool-arg-input" data-arg="${pname}" placeholder="${pschema.type || "string"}">
            <span class="tool-arg-type">${pschema.type || "?"}</span>
        </div>`;
    }
    toolArgsEditor.innerHTML = html; toolOutput.textContent = "";
}

async function runTool() {
    const name = toolSelect.value; if (!name) return;
    const args = {};
    toolArgsEditor.querySelectorAll(".tool-arg-input").forEach(input => {
        let val = input.value;
        const schema = toolSchemas[name];
        const ptype  = schema.parameters.properties[input.dataset.arg] && schema.parameters.properties[input.dataset.arg].type;
        if (ptype === "integer") val = parseInt(val, 10);
        else if (ptype === "number")  val = parseFloat(val);
        else if (ptype === "boolean") val = val === "true";
        if (val !== "" && val !== undefined && !Number.isNaN(val)) args[input.dataset.arg] = val;
    });
    toolOutput.textContent = "Running..."; toolOutput.style.color = "var(--text-dim)";
    try {
        const r = await fetch("/api/tools/test", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, args }),
        });
        const d = await r.json();
        if (d.error) { toolOutput.textContent = "Error: " + d.error; toolOutput.style.color = "var(--red)"; }
        else { toolOutput.textContent = d.result + "\n\n(" + fmtMs(d.latency_ms) + ")"; toolOutput.style.color = "var(--green)"; }
    } catch (e) { toolOutput.textContent = "Network error: " + e.message; toolOutput.style.color = "var(--red)"; }
}

// ------------------------------------------------------------------ //
// Send prompt (SSE streaming)                                         //
// ------------------------------------------------------------------ //
async function sendPrompt(rawPrompt) {
    if (isLoading) return;
    const prompt = resolveVariables(rawPrompt);
    isLoading = true; btnSend.disabled = true;
    promptHistory.unshift(rawPrompt);
    if (promptHistory.length > 50) promptHistory.pop();
    historyIndex = -1;

    addUserMessage(prompt);
    startElapsedTimer();
    setStatus("THINKING", true);

    let streamDiv = null, accText = "";

    try {
        const resp = await fetch("/api/chat/stream", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ prompt, conversation: currentConv }),
        });
        if (!resp.ok) throw new Error("Server error " + resp.status);

        streamDiv = addStreamingMessage();
        const reader  = resp.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n"); buffer = lines.pop();
            for (const line of lines) {
                if (!line.startsWith("data: ")) continue;
                try {
                    const event = JSON.parse(line.slice(6));
                    if (event.type === "thinking") {
                        updateThinking(event.text);
                    } else if (event.type === "token") {
                        accText += event.text; updateStreamingMessage(accText);
                    } else if (event.type === "done") {
                        collapseThinking(); finalizeStreamingMessage(event); setStatus("CONNECTED", true);
                    } else if (event.type === "error") {
                        if (streamDiv) { streamDiv.remove(); streamDiv = null; }
                        addErrorMessage(event.error); setStatus("ERROR", false);
                    }
                } catch (e) { /* skip malformed */ }
            }
        }
    } catch (err) {
        if (streamDiv) { streamDiv.remove(); streamDiv = null; }
        addErrorMessage("Network error: " + err.message); setStatus("DISCONNECTED", false);
    } finally {
        stopElapsedTimer(); isLoading = false; btnSend.disabled = false; promptInput.focus();
    }
}

async function reloadAgent() {
    try {
        const r = await fetch("/api/reload", { method: "POST" });
        const d = await r.json();
        if (d.error) addErrorMessage("Reload failed: " + d.error);
        else { setStatus("RELOADED", true); await loadAgentInfo(); await loadTools(); setTimeout(() => setStatus("CONNECTED", true), 2000); }
    } catch (e) { addErrorMessage("Reload error: " + e.message); setStatus("DISCONNECTED", false); }
}

// ------------------------------------------------------------------ //
// PROMPTS TAB                                                         //
// ------------------------------------------------------------------ //
async function loadPrompts() {
    try {
        const r = await fetch("/api/prompts");
        const d = await r.json();
        renderPromptList(d.prompts);
    } catch (e) { /* ignore */ }
}

function renderPromptList(prompts) {
    const el = document.getElementById("prompt-list");
    const entries = Object.entries(prompts);
    if (!entries.length) { el.innerHTML = '<p class="empty-state">No saved prompts.</p>'; return; }
    el.innerHTML = "";
    for (const [name, versions] of entries) {
        const item = document.createElement("div");
        item.className = "prompt-item";
        const latest = versions[versions.length - 1];
        item.innerHTML = `<div class="prompt-item-name">${esc(name)}</div>
            <div class="prompt-item-meta">${versions.length} version${versions.length !== 1 ? "s" : ""} · ${latest.notes ? esc(latest.notes) : "no notes"}</div>`;
        const versionsDiv = document.createElement("div");
        versionsDiv.className = "prompt-versions";
        for (const v of [...versions].reverse()) {
            const row = document.createElement("div");
            row.className = "prompt-version";
            row.innerHTML = `<span>v${v.version}</span>
                <span class="prompt-version-label">${v.notes ? esc(v.notes) : ""}</span>
                <div class="prompt-version-actions">
                    <button class="btn-tiny use" title="Load into editor">use</button>
                    <button class="btn-tiny" title="Load into A/B A">→A</button>
                    <button class="btn-tiny" title="Load into A/B B">→B</button>
                    <button class="btn-tiny" title="Delete">del</button>
                </div>`;
            row.querySelectorAll(".btn-tiny")[0].onclick = () => {
                document.getElementById("prompt-name").value = name;
                document.getElementById("prompt-text").value = v.text;
            };
            row.querySelectorAll(".btn-tiny")[1].onclick = () => { document.getElementById("ab-prompt-a").value = v.text; };
            row.querySelectorAll(".btn-tiny")[2].onclick = () => { document.getElementById("ab-prompt-b").value = v.text; };
            row.querySelectorAll(".btn-tiny")[3].onclick = async () => {
                await fetch(`/api/prompts/${encodeURIComponent(name)}/${v.version}`, { method: "DELETE" });
                loadPrompts();
            };
            versionsDiv.appendChild(row);
        }
        item.appendChild(versionsDiv);
        el.appendChild(item);
    }
}

async function savePrompt() {
    const name  = document.getElementById("prompt-name").value.trim();
    const text  = document.getElementById("prompt-text").value.trim();
    const notes = document.getElementById("prompt-notes").value.trim();
    if (!name || !text) return;
    await fetch("/api/prompts", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, text, notes }),
    });
    loadPrompts();
}

async function runABTest() {
    const input   = document.getElementById("ab-input").value.trim();
    const promptA = document.getElementById("ab-prompt-a").value.trim();
    const promptB = document.getElementById("ab-prompt-b").value.trim();
    if (!input) return;

    const btn = document.getElementById("btn-run-ab");
    btn.textContent = "RUNNING..."; btn.disabled = true;

    try {
        const r = await fetch("/api/ab-test", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ input, prompt_a: promptA, prompt_b: promptB }),
        });
        const d = await r.json();
        const results = d.results || [];
        const a = results.find(r => r.label === "A") || {};
        const b = results.find(r => r.label === "B") || {};

        document.getElementById("ab-a-latency").textContent = fmtMs(a.latency_ms);
        document.getElementById("ab-a-cost").textContent    = fmtCost(a.cost);
        document.getElementById("ab-b-latency").textContent = fmtMs(b.latency_ms);
        document.getElementById("ab-b-cost").textContent    = fmtCost(b.cost);

        const aOut = document.getElementById("ab-a-output");
        const bOut = document.getElementById("ab-b-output");
        aOut.textContent = a.error ? "Error: " + a.error : (a.text || "");
        bOut.textContent = b.error ? "Error: " + b.error : (b.text || "");

        document.getElementById("ab-results").classList.remove("hidden");

        // Diff
        if (a.text && b.text) {
            renderDiff(a.text, b.text);
            document.getElementById("diff-wrap").classList.remove("hidden");
        }
    } catch (e) {
        alert("A/B test error: " + e.message);
    } finally {
        btn.textContent = "RUN A/B"; btn.disabled = false;
    }
}

function renderDiff(textA, textB) {
    const wordsA = textA.split(/\s+/);
    const wordsB = textB.split(/\s+/);
    const setA   = new Set(wordsA);
    const setB   = new Set(wordsB);
    const html   = wordsB.map(w => setA.has(w) ? esc(w) : `<span class="diff-add">${esc(w)}</span>`).join(" ")
        + " " + wordsA.filter(w => !setB.has(w)).map(w => `<span class="diff-del">${esc(w)}</span>`).join(" ");
    document.getElementById("diff-view").innerHTML = html;
}

// ------------------------------------------------------------------ //
// EVALS TAB                                                           //
// ------------------------------------------------------------------ //
let _evalCases = [];

async function loadEvals() {
    try {
        const r = await fetch("/api/evals");
        const d = await r.json();
        _evalCases = d.evals || [];
        renderEvalList();
    } catch (e) { /* ignore */ }
}

function renderEvalList() {
    const el = document.getElementById("eval-list");
    if (!_evalCases.length) { el.innerHTML = '<p class="empty-state">No test cases.</p>'; return; }
    el.innerHTML = "";
    for (const c of _evalCases) {
        const item = document.createElement("div");
        item.className = "eval-case-item";
        item.innerHTML = `<div>
            <div class="eval-case-name">${esc(c.name)}</div>
            <div class="eval-case-input">${esc(c.input)}</div>
            ${c.golden ? '<div style="font-size:10px;color:var(--green);margin-top:2px;">&#x2605; golden set</div>' : ""}
        </div>
        <button class="btn-tiny" title="Delete">&#x2715;</button>`;
        item.querySelector(".btn-tiny").onclick = async () => {
            await fetch("/api/evals/" + c.id, { method: "DELETE" });
            loadEvals();
        };
        el.appendChild(item);
    }
}

async function addEvalCase() {
    const name     = document.getElementById("eval-name").value.trim();
    const input    = document.getElementById("eval-input").value.trim();
    const expected = document.getElementById("eval-expected").value.trim();
    if (!name || !input) return;
    await fetch("/api/evals", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, input, expected }),
    });
    document.getElementById("eval-name").value     = "";
    document.getElementById("eval-input").value    = "";
    document.getElementById("eval-expected").value = "";
    loadEvals();
}

async function runEvals() {
    if (!_evalCases.length) return;
    const btn = document.getElementById("btn-run-evals");
    btn.textContent = "RUNNING..."; btn.disabled = true;
    const useLLM = document.getElementById("eval-llm-judge").checked;

    try {
        const r = await fetch("/api/evals/run", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ llm_judge: useLLM }),
        });
        const d = await r.json();
        renderEvalResults(d.results || []);
    } catch (e) {
        document.getElementById("eval-results").innerHTML = `<p class="empty-state" style="color:var(--red)">Error: ${esc(e.message)}</p>`;
    } finally {
        btn.textContent = "&#x25B6; RUN ALL"; btn.disabled = false;
    }
}

function renderEvalResults(results) {
    const el      = document.getElementById("eval-results");
    const passed  = results.filter(r => r.pass).length;
    const summary = document.getElementById("eval-summary");
    summary.textContent = `${passed}/${results.length} passed`;
    summary.style.color = passed === results.length ? "var(--green)" : passed > 0 ? "var(--amber)" : "var(--red)";

    if (!results.length) { el.innerHTML = '<p class="empty-state">No results.</p>'; return; }
    el.innerHTML = "";
    for (const r of results) {
        const card = document.createElement("div");
        const cls  = r.error ? "error" : r.pass ? "pass" : "fail";
        card.className = "eval-result-card " + cls;

        const score    = r.score != null ? Math.round(r.score * 100) : null;
        const barClass = score >= 70 ? "high" : score >= 40 ? "mid" : "low";

        card.innerHTML = `
            <div class="eval-result-header">
                <span class="eval-result-name">${esc(r.name)}</span>
                <span class="eval-badge ${cls}">${r.error ? "ERROR" : r.pass ? "PASS" : "FAIL"}</span>
            </div>
            ${score != null ? `<div class="eval-score-bar-wrap"><div class="eval-score-bar ${barClass}" style="width:${score}%"></div></div>` : ""}
            <div class="eval-result-row">Input: <span>${esc(r.input || "")}</span></div>
            ${r.expected ? `<div class="eval-result-row">Expected: <span>${esc(r.expected)}</span></div>` : ""}
            ${r.actual   ? `<div class="eval-result-row">Actual: <span>${esc(r.actual.substring(0, 200))}</span></div>` : ""}
            ${r.error    ? `<div class="eval-result-row" style="color:var(--red)">Error: <span>${esc(r.error)}</span></div>` : ""}
            ${score != null ? `<div class="eval-result-row">Score: <span style="color:var(--green)">${score}%</span>${r.latency_ms ? ` · ${fmtMs(r.latency_ms)}` : ""}</div>` : ""}
            ${r.llm_score != null ? `<div class="eval-result-row">LLM Judge: <span style="color:var(--cyan)">${Math.round(r.llm_score*100)}%</span> — ${esc(r.llm_reason || "")}</div>` : ""}
            ${r.regression_score != null ? `<div class="eval-result-row">Regression vs golden: <span style="color:var(--purple)">${Math.round(r.regression_score*100)}%</span></div>` : ""}
            <div class="eval-result-actions">
                ${r.actual ? `<button class="btn btn-ghost btn-sm" onclick="setGolden('${r.id}', ${JSON.stringify(esc(r.actual))})">&#x2605; Set as Golden</button>` : ""}
            </div>`;
        el.appendChild(card);
    }
}

async function setGolden(id, text) {
    await fetch(`/api/evals/${id}/set-golden`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
    });
    loadEvals();
}

// ------------------------------------------------------------------ //
// OBSERVE TAB                                                         //
// ------------------------------------------------------------------ //
async function populateReplaySelect() {
    try {
        const r = await fetch("/api/conversations");
        const d = await r.json();
        const sel = document.getElementById("replay-conv-select");
        sel.innerHTML = "";
        for (const id of d.conversations) {
            const opt = document.createElement("option");
            opt.value = id; opt.textContent = id; sel.appendChild(opt);
        }
    } catch (e) { /* ignore */ }
}

async function loadReplay() {
    const id = document.getElementById("replay-conv-select").value;
    if (!id) return;
    try {
        const r = await fetch("/api/conversations/" + id);
        const d = await r.json();
        renderTimeline(d.messages || []);
    } catch (e) { /* ignore */ }
}

function renderTimeline(messages) {
    const wrap     = document.getElementById("timeline-wrap");
    const anomalies = [];
    wrap.innerHTML = "";

    if (!messages.length) {
        wrap.innerHTML = '<p class="empty-state">No messages in this conversation.</p>'; return;
    }

    // Compute stats for anomaly detection
    const agentMsgs = messages.filter(m => m.role === "agent" && m.data);
    const latencies = agentMsgs.map(m => m.data.latency_ms || 0).filter(Boolean);
    const costs     = agentMsgs.map(m => m.data.cost || 0).filter(Boolean);
    const texts     = agentMsgs.map(m => (m.data.text || "").length);
    const avgLat    = latencies.length ? latencies.reduce((a,b) => a+b, 0) / latencies.length : 0;
    const avgCost   = costs.length    ? costs.reduce((a,b) => a+b, 0) / costs.length : 0;
    const avgLen    = texts.length    ? texts.reduce((a,b) => a+b, 0) / texts.length : 0;

    messages.forEach((msg, idx) => {
        const entry = document.createElement("div");
        entry.className = "timeline-entry";
        const isUser  = msg.role === "user";
        const data    = msg.data || {};
        const flags   = [];

        if (!isUser) {
            if (data.latency_ms && avgLat && data.latency_ms > avgLat * 2)
                flags.push({ type: "SLOW", desc: `Latency ${fmtMs(data.latency_ms)} (avg ${fmtMs(avgLat)})` });
            if (data.cost && avgCost && data.cost > avgCost * 2)
                flags.push({ type: "EXPENSIVE", desc: `Cost ${fmtCost(data.cost)} (avg ${fmtCost(avgCost)})` });
            if (data.text && avgLen && data.text.length < avgLen * 0.2)
                flags.push({ type: "SHORT", desc: `Response only ${data.text.length} chars (avg ${Math.round(avgLen)})` });
            flags.forEach(f => anomalies.push({ turn: idx + 1, ...f }));
        }

        const preview = isUser ? (msg.content || "").substring(0, 80) : (data.text || "").substring(0, 80);
        const metaHtml = !isUser && data.latency_ms
            ? `<span>${fmtMs(data.latency_ms)}</span><span>${fmtCost(data.cost)}</span>${flags.length ? `<span class="anomaly">&#x26A0; ${flags.map(f=>f.type).join(", ")}</span>` : ""}`
            : "";

        entry.innerHTML = `
            <div class="timeline-dot ${isUser ? "user" : "agent"}"></div>
            <div class="timeline-body">
                <div class="timeline-role ${isUser ? "user" : "agent"}">${isUser ? "YOU" : "AGENT"}</div>
                <div class="timeline-preview">${esc(preview)}${preview.length >= 80 ? "…" : ""}</div>
                ${metaHtml ? `<div class="timeline-meta">${metaHtml}</div>` : ""}
            </div>`;

        entry.addEventListener("click", () => {
            document.querySelectorAll(".timeline-entry").forEach(e => e.classList.remove("selected"));
            entry.classList.add("selected");
            // Show detail below
            const existing = document.getElementById("timeline-detail");
            if (existing) existing.remove();
            const detail = document.createElement("div");
            detail.id = "timeline-detail"; detail.className = "timeline-detail";
            detail.textContent = isUser ? (msg.content || "") : (data.text || JSON.stringify(data, null, 2));
            entry.after(detail);
        });

        wrap.appendChild(entry);
    });

    // Heatmap
    renderTokenHeatmap(agentMsgs);

    // Anomalies
    const anomalyList = document.getElementById("anomaly-list");
    if (!anomalies.length) {
        anomalyList.innerHTML = '<p class="empty-state">No anomalies detected.</p>';
    } else {
        anomalyList.innerHTML = anomalies.map(a =>
            `<div class="anomaly-item">
                <div class="anomaly-type">&#x26A0; ${esc(a.type)} — Turn ${a.turn}</div>
                <div class="anomaly-desc">${esc(a.desc)}</div>
            </div>`
        ).join("");
    }
}

function renderTokenHeatmap(agentMsgs) {
    const wrap = document.getElementById("token-heatmap");
    wrap.innerHTML = "";
    if (!agentMsgs.length) return;
    const totals = agentMsgs.map(m => (m.data.tokens && m.data.tokens.total) || 0);
    const max    = Math.max(...totals) || 1;
    totals.forEach((t, i) => {
        const intensity = t / max;
        const r = Math.round(57  + (255 - 57)  * intensity);
        const g = Math.round(255 * intensity);
        const b = Math.round(20  * intensity);
        const cell = document.createElement("div");
        cell.className = "heatmap-cell";
        cell.style.background = `rgb(${r},${g},${b})`;
        cell.style.opacity = 0.3 + intensity * 0.7;
        cell.title = `Turn ${i+1}: ${fmt(t)} tokens`;
        cell.textContent = t > 999 ? Math.round(t/1000) + "k" : t;
        wrap.appendChild(cell);
    });
}

// ------------------------------------------------------------------ //
// SCENARIOS TAB                                                       //
// ------------------------------------------------------------------ //
let _scenarios = [];

async function loadScenarios() {
    try {
        const r = await fetch("/api/scenarios");
        const d = await r.json();
        _scenarios = d.scenarios || [];
        renderScenarioList();
    } catch (e) { /* ignore */ }
}

function renderScenarioList() {
    const el = document.getElementById("scenario-list");
    if (!_scenarios.length) { el.innerHTML = '<p class="empty-state">No scenarios.</p>'; return; }
    el.innerHTML = "";
    for (const s of _scenarios) {
        const item = document.createElement("div");
        item.className = "scenario-item";
        item.innerHTML = `
            <div>
                <div class="scenario-item-name">${esc(s.name)}</div>
                <div class="scenario-item-meta">${s.turns.length} turn${s.turns.length !== 1 ? "s" : ""}</div>
            </div>
            <div class="scenario-item-actions">
                <button class="btn-tiny use" title="Load">edit</button>
                <button class="btn btn-send btn-sm" style="font-size:10px;padding:3px 8px;">&#x25B6;</button>
                <button class="btn-tiny" title="Delete">&#x2715;</button>
            </div>`;
        item.querySelectorAll(".btn-tiny")[0].onclick = () => loadScenarioIntoEditor(s);
        item.querySelectorAll(".btn")[0].onclick      = () => runScenario(s.id);
        item.querySelectorAll(".btn-tiny")[1].onclick = async () => {
            await fetch("/api/scenarios/" + s.id, { method: "DELETE" });
            loadScenarios();
        };
        el.appendChild(item);
    }
}

function newScenario() {
    editingScenarioId = null;
    document.getElementById("scenario-name").value = "";
    document.getElementById("scenario-turns").innerHTML = "";
    addTurn();
}

function loadScenarioIntoEditor(s) {
    editingScenarioId = s.id;
    document.getElementById("scenario-name").value = s.name;
    const turnsEl = document.getElementById("scenario-turns");
    turnsEl.innerHTML = "";
    for (const t of s.turns) addTurn(t.role, t.content);
}

function addTurn(role = "user", content = "") {
    const turnsEl = document.getElementById("scenario-turns");
    const row = document.createElement("div");
    row.className = "scenario-turn";
    row.innerHTML = `
        <select class="turn-role-select">
            <option value="user" ${role === "user" ? "selected" : ""}>user</option>
            <option value="assistant" ${role === "assistant" ? "selected" : ""}>assistant</option>
        </select>
        <input class="turn-content-input" placeholder="Turn content..." value="${esc(content)}" />
        <button class="btn-remove-turn" title="Remove">&#x2715;</button>`;
    row.querySelector(".btn-remove-turn").onclick = () => row.remove();
    turnsEl.appendChild(row);
}

async function saveScenario() {
    const name  = document.getElementById("scenario-name").value.trim();
    if (!name) return;
    const turns = [...document.querySelectorAll("#scenario-turns .scenario-turn")].map(row => ({
        role:    row.querySelector(".turn-role-select").value,
        content: row.querySelector(".turn-content-input").value,
    }));

    if (editingScenarioId) {
        await fetch("/api/scenarios/" + editingScenarioId, {
            method: "PUT", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, turns }),
        });
    } else {
        await fetch("/api/scenarios", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, turns }),
        });
    }
    loadScenarios();
}

async function runScenario(id) {
    const btn = document.querySelector(`.scenario-item-actions .btn`);
    const resultsEl = document.getElementById("scenario-results");
    const bodyEl    = document.getElementById("scenario-results-body");
    resultsEl.classList.remove("hidden");
    bodyEl.innerHTML = '<p class="empty-state">Running...</p>';

    try {
        const r = await fetch("/api/scenarios/" + id + "/run", { method: "POST" });
        const d = await r.json();
        if (d.error) { bodyEl.innerHTML = `<p class="empty-state" style="color:var(--red)">${esc(d.error)}</p>`; return; }
        bodyEl.innerHTML = (d.results || []).map(t =>
            `<div class="scenario-turn-result">
                <div class="scenario-turn-input">&#x25B6; ${esc(t.input)}</div>
                ${t.error
                    ? `<div style="color:var(--red);font-size:12px;">${esc(t.error)}</div>`
                    : `<div class="scenario-turn-output">${esc(t.output || "")}</div>
                       <div class="scenario-turn-meta">${fmtMs(t.latency_ms)} · ${fmtCost(t.cost)} · ${fmt(t.tokens && t.tokens.total)} tokens</div>`}
            </div>`
        ).join("");
    } catch (e) {
        bodyEl.innerHTML = `<p class="empty-state" style="color:var(--red)">Error: ${esc(e.message)}</p>`;
    }
}

// ------------------------------------------------------------------ //
// Event listeners                                                     //
// ------------------------------------------------------------------ //
chatForm.addEventListener("submit", e => {
    e.preventDefault();
    const text = promptInput.value.trim(); if (!text) return;
    promptInput.value = ""; promptInput.style.height = "auto";
    varBar.innerHTML = "";
    sendPrompt(text);
});

promptInput.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault(); chatForm.dispatchEvent(new Event("submit"));
    } else if (e.key === "ArrowUp" && promptInput.value === "") {
        e.preventDefault();
        if (historyIndex < promptHistory.length - 1) { historyIndex++; promptInput.value = promptHistory[historyIndex]; }
    } else if (e.key === "ArrowDown") {
        e.preventDefault();
        if (historyIndex > 0) { historyIndex--; promptInput.value = promptHistory[historyIndex]; }
        else { historyIndex = -1; promptInput.value = ""; }
    }
});

btnClear.addEventListener("click", () => {
    chatArea.innerHTML = '<div class="welcome" id="welcome"><p class="welcome-text">Chat cleared.</p></div>';
    telemetryContent.classList.add("hidden"); telemetryEmpty.classList.remove("hidden");
    sessionTokens = 0; sessionCost = 0; turnCount = 0; costHistory = [];
});

btnReload.addEventListener("click", reloadAgent);
document.getElementById("btn-new-chat").addEventListener("click", newConversation);
document.getElementById("btn-toggle-tools").addEventListener("click", () => toolDrawer.classList.toggle("hidden"));
document.getElementById("btn-close-tools").addEventListener("click", () => toolDrawer.classList.add("hidden"));
document.getElementById("btn-sidebar-toggle").addEventListener("click", () => sidebar.classList.toggle("collapsed"));
document.getElementById("btn-export").addEventListener("click", exportTelemetry);
toolSelect.addEventListener("change", () => renderToolArgs(toolSelect.value));
document.getElementById("btn-run-tool").addEventListener("click", runTool);

// Prompts tab
document.getElementById("btn-save-prompt").addEventListener("click", savePrompt);
document.getElementById("btn-run-ab").addEventListener("click", runABTest);

// Evals tab
document.getElementById("btn-add-eval").addEventListener("click", addEvalCase);
document.getElementById("btn-run-evals").addEventListener("click", runEvals);

// Observe tab
document.getElementById("btn-load-replay").addEventListener("click", loadReplay);

// Scenarios tab
document.getElementById("btn-new-scenario").addEventListener("click", newScenario);
document.getElementById("btn-add-turn").addEventListener("click", () => addTurn());
document.getElementById("btn-save-scenario").addEventListener("click", saveScenario);

init();
