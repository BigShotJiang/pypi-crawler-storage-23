"""CLI package for QueryClaw."""

from queryclaw.cli.commands import app

__all__ = ["app"]
