"""
CMakeHub CLI - Command line interface for CMakeHub module manager
"""

__version__ = "0.1.0"
__author__ = "CMakeHub Team"
