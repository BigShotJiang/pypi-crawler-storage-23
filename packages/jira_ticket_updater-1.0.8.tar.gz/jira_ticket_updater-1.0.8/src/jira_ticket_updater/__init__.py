"""Jira Ticket Updater v1.0.8 - A command-line tool for updating Jira ticket status."""

__version__ = "1.0.8"
__author__ = "Pandiyaraj Karuppasamy"
__email__ = "pandiyarajk@live.com"
__description__ = "A command-line tool for updating Jira ticket status"

from .jira_api import add_comment_to_issue, get_issue_comments, get_ticket_details
from .jira_operations import (display_issue_comments, display_issue_status,
                              update_jira_status)
from .jira_intelligence import JiraIssueIntelligence
