from _typeshed import Incomplete

BASE_FOLDER: Incomplete

def run(namespace: str, app_data: dict = {}, debug: bool = False, fullscreen: bool = False, show_refresh: bool = False, size: list[int] | None = None, user: dict = {'username': 'localuser'}, window_title: str = '<title>'):
    """Start the Simian Web app from the given namespace and show it in a pywebview window.

    Creates a pywebview component and ties it to the formio source.

    Args:
        namespace:      The namespace of the wrapper functions.
        app_data:       (optional) Application data dictionary. Available as 'application_data'
            in the meta data dict. Set by the Portal when deployed. May contain list of strings
            and scalar numeric, text, and boolean values.
        debug:          (optional) Application debug flag.
        fullscreen:     (optional) Set the window full screen when true.
        show_refresh:   (optional) Shows the refresh button to update the form without closing the
            window. This option is meant for use during development only.
        size:           (optional) Set the window size [width, height].
        user:           (optional) Authenticated user dict. Available as 'authenticated_user'
            in the 'client_data' part of the meta data dict. Set by the Portal when deployed.
            May contain a 'username' and 'user_displayname' field.
        window_title:   (optional) Title to be shown in the application window.
    """

class Uiformio:
    """Combines a callback wrapper with a PyWebView component that holds the form.

    The callback wrapper calls form-specific functions with predefined names.
    All communication between the form and the python code behind it, flows through this class.
    """
    fig_handle: Incomplete
    pywebview: Incomplete
    proc: Incomplete
    session_id: Incomplete
    progress: Incomplete
    cancel: Incomplete
    def __init__(self, namespace: str, app_data: dict = {}, debug: bool = False, fullscreen: bool = False, show_refresh: bool = False, size: list[int] | None = None, user: dict = {'username': 'localuser'}, window_title: str = '<title>') -> None:
        """Create a pywebview component and tie it to the formio source.

        Args:
            namespace:      The namespace of the wrapper functions.
            app_data:       (optional) Application data dictionary. Available as 'application_data'
                in the meta data dict. Set by the Portal when deployed. May contain list of strings
                and scalar numeric, text, and boolean values.
            debug:          (optional) Application debug flag.
            fullscreen:     (optional) Set the window full screen when true.
            show_refresh:   (optional) Shows the refresh button to update the form without closing
                the window. This option is meant for use during development only.
            size:           (optional) Set the window size [width, height].
            user:           (optional) Authenticated user dict. Available as 'authenticated_user'
                in the 'client_data' part of the meta data dict. Set by the Portal when deployed.
                May contain a 'username' and 'user_displayname' field.
            window_title:   (optional) Title to be shown in the application window.
        """
