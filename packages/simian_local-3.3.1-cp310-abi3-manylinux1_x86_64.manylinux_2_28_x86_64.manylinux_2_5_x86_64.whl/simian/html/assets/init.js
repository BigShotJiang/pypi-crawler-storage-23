const appBuild = 'pywebview';
let setupTriggered = false;
let appLoaded = false;

/**
 * Function that triggers the angular function loadFormAngular.
 */
function loadForm() {
    window.angularComponentReference.zone.run(() => {
        window.angularComponentReference.loadFormAngular();
    });
}

/**
 * Function that is triggered by MATLAB to start the form.
 */
function setup(htmlComponentInput) {
    setupTriggered = true;
    htmlComponent = htmlComponentInput;
    // if app loaded
    if (appLoaded) {
        loadForm();
    }
}

/**
 * Function that is triggered by the angular app if it's done loading and ready to use.
 */
function setAppLoaded() {
    appLoaded = true;
    // if setup already triggered load form
    if (setupTriggered) {
        loadForm();
    }
}

if (appBuild === 'pywebview') {
    // The pywebview app can only be loaded when its window is ready.
    window.addEventListener('pywebviewready', function () {
        setupTriggered = true;
        // if app loaded
        if (appLoaded) {
            loadForm();
        }
    })
} else if (appBuild === 'browser') {
    setupTriggered = true;
    if (appLoaded) {
        loadForm();
    }
}
