import numpy as np
import matplotlib.pyplot as plt


def draw_triangle(vertices, show=True):
    """
    Draw triangle using 3 vertices.

    Parameters:
    vertices : list of tuples
        [(x1,y1), (x2,y2), (x3,y3)]
    """

    triangle = np.array(vertices)

    # close triangle
    triangle = np.vstack([triangle, triangle[0]])

    plt.plot(triangle[:, 0], triangle[:, 1])
    plt.fill(triangle[:, 0], triangle[:, 1], alpha=0.3)

    plt.axis("equal")

    if show:
        plt.show()


def equilateral(side=5):

    h = np.sqrt(3) / 2 * side

    vertices = [
        (0, 0),
        (side, 0),
        (side / 2, h)
    ]

    draw_triangle(vertices)


def right_triangle(base=5, height=4):

    vertices = [
        (0, 0),
        (base, 0),
        (0, height)
    ]

    draw_triangle(vertices)

def isosceles(base=6, height=5):

    vertices = [
        (0, 0),
        (base, 0),
        (base / 2, height)
    ]

    draw_triangle(vertices)

    