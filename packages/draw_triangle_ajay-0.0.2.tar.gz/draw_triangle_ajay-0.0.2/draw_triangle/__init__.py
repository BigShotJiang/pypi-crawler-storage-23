from .triangle import equilateral
from .triangle import right_triangle
from .triangle import isosceles
from .triangle import draw_triangle