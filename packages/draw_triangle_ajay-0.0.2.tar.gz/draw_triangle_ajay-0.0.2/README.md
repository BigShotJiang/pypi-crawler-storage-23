# draw_triangle

Python library to draw geometric triangle shapes using numpy and matplotlib.

## Features

- Equilateral triangle
- Right triangle
- Isosceles triangle
- Custom triangle using vertices

---

## Installation

pip install draw-triangle-ajay

---

## Usage

### Equilateral Triangle

```python
from draw_triangle import equilateral
equilateral(5)
```

### Right Triangle

```python
from draw_triangle import right_triangle
right_triangle(5, 4)
```

---

### Isosceles Triangle

```python
from draw_triangle import isosceles
isosceles(6, 5)
```

---

### Custom Triangle

```python
from draw_triangle import draw_triangle

draw_triangle([(0, 0), (4, 0), (2, 3)])
```

---


## Dependencies

- numpy
- matplotlib

---

## Author

Ajay Kumar
