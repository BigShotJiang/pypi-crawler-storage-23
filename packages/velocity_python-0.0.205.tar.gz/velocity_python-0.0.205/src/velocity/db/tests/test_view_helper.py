import unittest
from types import SimpleNamespace

from velocity.db.core.view import View


class FakeResult:
    def __init__(self, rows):
        self._rows = rows

    def as_dict(self):
        return self

    def all(self):
        return list(self._rows)


class FakeTx:
    def __init__(self):
        self.executed = []
        self.engine = SimpleNamespace(
            schema_locked=False,
            sql=SimpleNamespace(default_schema="public"),
        )

        # Toggleable responses
        self._view_exists = False
        self._has_priv = False

    def execute(self, sql, parms=None, *args, **kwargs):
        self.executed.append((sql, parms))

        text = str(sql)
        if "information_schema.views" in text:
            return FakeResult([{"ok": True}]) if self._view_exists else FakeResult([])

        if "has_table_privilege" in text:
            return FakeResult([{"ok": bool(self._has_priv)}])

        return FakeResult([])


class TestViewHelper(unittest.TestCase):
    def test_ensure_creates_missing_view_and_grants(self):
        tx = FakeTx()
        v = View(tx, "my_view")

        tx._view_exists = False
        tx._has_priv = False

        v.ensure("select 1 as one")

        statements = "\n".join(s for s, _ in tx.executed)
        self.assertIn("CREATE OR REPLACE VIEW", statements)
        self.assertIn('"public"."my_view"', statements)
        self.assertIn("GRANT SELECT ON", statements)

    def test_ensure_existing_view_does_not_replace_by_default(self):
        tx = FakeTx()
        v = View(tx, "my_view")

        tx._view_exists = True
        tx._has_priv = False

        v.ensure("select 1 as one")

        statements = "\n".join(s for s, _ in tx.executed)
        self.assertNotIn("CREATE OR REPLACE VIEW", statements)
        self.assertIn("GRANT SELECT ON", statements)

    def test_ensure_existing_view_replaces_when_requested(self):
        tx = FakeTx()
        v = View(tx, "my_view")

        tx._view_exists = True
        tx._has_priv = True

        v.ensure("select 1 as one", replace_existing=True)

        statements = "\n".join(s for s, _ in tx.executed)
        self.assertIn("CREATE OR REPLACE VIEW", statements)

    def test_ensure_skips_grant_if_already_present(self):
        tx = FakeTx()
        v = View(tx, "my_view")

        tx._view_exists = True
        tx._has_priv = True

        v.ensure("select 1 as one")

        statements = "\n".join(s for s, _ in tx.executed)
        self.assertNotIn("GRANT SELECT ON", statements)


if __name__ == "__main__":
    unittest.main()
