The files in this directory are generated and copied in, don't edit by hand. See
repository justfile `gen-extensions` command.
