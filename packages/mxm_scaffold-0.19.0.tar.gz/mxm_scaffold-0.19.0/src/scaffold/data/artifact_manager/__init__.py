from scaffold.data.artifact_manager.artifact_logger import ModelLogger

__all__ = ("ModelLogger",)
