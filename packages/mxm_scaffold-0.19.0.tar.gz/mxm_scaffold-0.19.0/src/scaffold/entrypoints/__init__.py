from scaffold.entrypoints.entrypoint import Entrypoint  # noqa: F401

__all__ = ["Entrypoint"]
