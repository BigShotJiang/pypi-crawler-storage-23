"""Simple API access based on the generated API interface."""

from .types import (
    Address,
    BillingDetails,
    CreateOrder,
    CreateOrders,
    Dimensions,
    LabelGeneration,
    ManifestDetailsResponse,
    ManifestEligibleOrders,
    PostageDetails,
    ProductItem,
    RecipientDetails,
    SenderDetails,
    ShipmentPackage,
    Tag,
    UpdateOrderStatus,
    UpdateOrderStatusResponse,
    UpdateOrdersStatus,
)
from .api import ClickAndDrop
from .package_sizes import (
    PackageSize,
    packages_sizes,
    get_package_size,
    choose_package_size_by_weight,
    get_package_sizes,
)
from .shipping_options import (
    ShippingOption,
    list_service_codes,
    check_service_codes,
)
from .errors import InvalidWeight, InvalidDimensions

__all__ = [
    "ClickAndDrop",
    "CreateOrder",
    "InvalidWeight",
    "InvalidDimensions",
    "check_service_codes",
    "RecipientDetails",
    "list_service_codes",
    "Address",
    "get_package_sizes",
    "PackageSize",
    "packages_sizes",
    "ShippingOption",
    "choose_package_size_by_weight",
    "get_package_size",
    "CreateOrders",
    "UpdateOrdersStatus",
    "UpdateOrderStatus",
    "UpdateOrderStatusResponse",
    "LabelGeneration",
    "ManifestEligibleOrders",
    "ManifestDetailsResponse",
    "PostageDetails",
    "ProductItem",
    "SenderDetails",
    "ShipmentPackage",
    "Tag",
    "Dimensions",
    "BillingDetails",
]
