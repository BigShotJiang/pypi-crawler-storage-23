# Copyright 2026 Randy W
# Licensed under the Apache License, Version 2.0

"""
Github Author: https://github.com/TeamKillerX/
Code: @zxyeor

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Generic, List, Literal, Optional, Tuple, Type, TypeVar

import httpx

T = TypeVar("T")

_PATH_PARAM_RE = re.compile(r"\{([a-zA-Z_][a-zA-Z0-9_]*)\}")
MediaType = Literal["photo", "video", "animation", "document"]

def _extract_path_param_keys(path: str) -> list[str]:
    return _PATH_PARAM_RE.findall(path)

def _format_path_and_pop_params(path: str, params: Dict[str, Any]) -> str:
    keys = _extract_path_param_keys(path)
    for k in keys:
        if k not in params:
            raise ValueError(f"Missing path param: {k} for path {path}")
        path = path.replace("{" + k + "}", str(params[k]))
        params.pop(k, None)
    return path

def _is_file_like(x: Any) -> bool:
    return hasattr(x, "read") and callable(x.read)

def _extract_files(payload: Dict[str, Any]) -> Dict[str, Any]:
    files: Dict[str, Any] = {}
    to_pop = []

    for k, v in payload.items():
        if v is None:
            continue
        if _is_file_like(v):
            files[k] = v
            to_pop.append(k)
        elif isinstance(v, (bytes, bytearray)):
            files[k] = (f"{k}.bin", bytes(v))
            to_pop.append(k)
        elif isinstance(v, tuple) and len(v) in (2, 3):
            second = v[1]
            if hasattr(second, "read") or isinstance(second, (bytes, bytearray)):
                files[k] = v
                to_pop.append(k)

    for k in to_pop:
        payload.pop(k, None)

    return files

def _normalize_form_data(payload: Dict[str, Any]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for k, v in payload.items():
        if v is None:
            continue
        if isinstance(v, (dict, list)):
            out[k] = json.dumps(v, ensure_ascii=False)
        elif isinstance(v, bool):
            out[k] = "true" if v else "false"
        else:
            out[k] = str(v)
    return out

class InputMedia:
    def __init__(self, client, type_, media):
        self._client = client
        self._data = {
            "type": type_,
            "media": media
        }

    def caption(self, text: str):
        self._data["caption"] = text
        return self

    def parse_mode(self, mode: str):
        self._data["parse_mode"] = mode
        return self

    def build(self):
        return self._data

class MediaFactory:
    def __init__(self, client: "CoreBotAuth"):
        self._client = client

    def photo(self, file: str | bytes):
        return InputMedia(self._client, "photo", file)

    def video(self, file: str | bytes):
        return InputMedia(self._client, "video", file)

@dataclass
class KeyboardBuilder:
    _rows: List[List[Dict[str, Any]]] = field(default_factory=list)
    _current_row: List[Dict[str, Any]] = field(default_factory=list)

    def _add(self, btn: Dict[str, Any]):
        self._current_row.append(btn)
        return self

    def url(self, text: str, url: str):
        return self._add({"text": text, "url": url})

    def style(self, text: str, style: str, **kw):
        return self._add({"text": text, "style": style, **kw})

    def callback(self, text: str, data: str):
        if len(data.encode()) > 64:
            raise ValueError("callback_data max 64 bytes")
        return self._add({"text": text, "callback_data": data})

    def copy_text(self, text: str, copy_text: str):
        return self._add({
            "text": text,
            "copy_text": {"text": copy_text}
        })

    def switch_inline_query_chosen_chat(self, text: str, **kw):
        _ALLOWED = {
            "query",
            "allow_user_chats",
            "allow_bot_chats",
            "allow_group_chats",
            "allow_channel_chats"
        }
        data = {k: v for k, v in kw.items() if k in _ALLOWED}
        return self._add({
            "text": text,
            "switch_inline_query_chosen_chat": data
        })

    def login(self, text: str, url: str):
        return self._add({
            "text": text,
            "login_url": {"url": url}
        })

    def pay(self, text: str, pay=False):
        return self._add({"text": text, "pay": pay})

    def webapp(self, text: str, url: str):
        return self._add({
            "text": text,
            "web_app": {"url": url}
        })

    def row(self):
        if self._current_row:
            self._rows.append(self._current_row)
            self._current_row = []
        return self

    def build(self):
        if self._current_row:
            self.row()
        return {"inline_keyboard": self._rows}

@dataclass
class RequestCall(Generic[T]):
    _client: "CoreBotAuth"
    _method: str
    _path: str
    _params: Dict[str, Any]
    _response_model: Optional[Type[T]] = None

    async def execute(self) -> T:
        raw = await (
            self._client._get(self._path, self._params)
            if self._method.upper() == "GET"
            else self._client._post(self._path, self._params)
        )

        if self._response_model is None:
            return raw  # type: ignore

        return self._response_model.model_validate(raw)  # type: ignore

    async def json(self) -> Any:
        return await self.execute()

    async def pretty(self, indent: int = 2) -> str:
        data = await self.execute()
        if hasattr(data, "model_dump"):
            return json.dumps(data.model_dump(), indent=indent, ensure_ascii=False)
        return json.dumps(data, indent=indent, ensure_ascii=False)

@dataclass
class CoreBotAuth:
    api_key: str
    base_url: str = "https://services-pro.ryzenths.dpdns.org"
    user_agent: str = "tgcore/1.0"
    timeout: float = 30.0

    _extra_headers: Dict[str, str] = field(default_factory=dict)
    _client: Optional[httpx.AsyncClient] = field(default=None, init=False, repr=False)

    def _ensure_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self.timeout)
        return self._client

    async def aclose(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    def _headers(self, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        h = {
            "x-api-key": self.api_key,
            "accept": "application/json",
            "user-agent": self.user_agent,
        }
        for k, v in self._extra_headers.items():
            h[k.lower()] = v
        if extra:
            for k, v in extra.items():
                h[k.lower()] = v
        return h

    def set_header(self, key: str, value: str) -> "CoreBotAuth":
        self._extra_headers[key.lower()] = value
        return self

    def _raise_http_error(self, r: httpx.Response) -> None:
        if r.is_success:
            return
        try:
            payload = r.json()
        except Exception:
            payload = r.text[:800]
        raise RuntimeError(f"HTTP {r.status_code}: {payload}")

    async def _post(
        self,
        path: str,
        payload: Dict[str, Any],
        headers: Dict[str, str] | None = None,
    ) -> Dict[str, Any]:
        payload = dict(payload or {})
        path = _format_path_and_pop_params(path, payload)

        c = self._ensure_client()
        url = self.base_url.rstrip("/") + path

        files = _extract_files(payload)

        if files:
            data = _normalize_form_data(payload)
            r = await c.post(url, data=data, files=files, headers=self._headers(headers))
        else:
            r = await c.post(url, json=payload, headers=self._headers(headers))

        self._raise_http_error(r)
        return r.json()

    async def _get(
        self,
        path: str,
        params: Dict[str, Any],
        headers: Dict[str, str] | None = None,
    ) -> Dict[str, Any]:
        params = dict(params or {})
        path = _format_path_and_pop_params(path, params)

        c = self._ensure_client()
        url = self.base_url.rstrip("/") + path
        r = await c.get(url, params=params, headers=self._headers(headers))

        self._raise_http_error(r)
        return r.json()
