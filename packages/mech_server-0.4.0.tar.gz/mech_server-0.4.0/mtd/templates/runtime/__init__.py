# -*- coding: utf-8 -*-
"""Runtime template assets."""
