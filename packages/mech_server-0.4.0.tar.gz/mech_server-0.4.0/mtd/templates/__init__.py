# -*- coding: utf-8 -*-
"""Template assets."""
