"""CLI executors for data management commands."""
from .migrate_activations import execute_migrate_activations

__all__ = ["execute_migrate_activations"]
