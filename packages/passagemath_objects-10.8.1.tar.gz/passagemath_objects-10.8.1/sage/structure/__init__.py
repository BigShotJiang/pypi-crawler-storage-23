# sage_setup: distribution = sagemath-objects
# delvewheel: patch
# Resolve a cyclic import
import sage.structure.element
