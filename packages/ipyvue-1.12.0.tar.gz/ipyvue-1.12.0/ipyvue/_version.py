__version__ = "1.12.0"
semver = "^" + __version__
