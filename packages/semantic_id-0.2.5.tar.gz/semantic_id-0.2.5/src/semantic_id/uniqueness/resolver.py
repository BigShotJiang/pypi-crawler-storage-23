from abc import ABC, abstractmethod
from typing import Any, List, Optional

import numpy as np

from semantic_id.uniqueness.stores import CollisionStore, InMemoryCollisionStore

_DEFAULT_SK_EPSILON = 0.003


class BaseResolver(ABC):
    """Abstract base class for collision resolvers."""

    @abstractmethod
    def assign(self, semantic_ids: List[str], **kwargs: Any) -> List[str]:
        """
        Resolve collisions in a list of semantic IDs.

        Args:
            semantic_ids: List of raw semantic ID strings.

        Returns:
            List of unique IDs.
        """
        pass


class UniqueIdResolver(BaseResolver):
    """
    Resolves collisions by appending suffixes to semantic IDs.

    First occurrence: no suffix.
    Second occurrence: ``-1``.
    Third occurrence: ``-2``, etc.

    When *item_ids* are provided via ``assign()``, the item's own
    identifier is appended instead of an auto-incremented counter.
    """

    def __init__(self, store: Optional[CollisionStore] = None) -> None:
        self.store: CollisionStore
        if store is None:
            self.store = InMemoryCollisionStore()
        else:
            self.store = store

    def assign(self, semantic_ids: List[str], **kwargs: Any) -> List[str]:
        """
        Assign unique IDs for a list of semantic IDs.

        Args:
            semantic_ids: List of raw semantic ID strings.
            item_ids: Optional list of external identifiers (e.g. database
                primary keys).  When provided, collisions are resolved by
                appending the item's own ID instead of an auto-incremented
                counter: ``"3-9-1-SKU123"`` instead of ``"3-9-1-1"``.
            sep: Separator between the base ID and the suffix (default
                ``"-"``).

        Returns:
            List of unique IDs (potentially with suffixes).
        """
        item_ids: Optional[List[str]] = kwargs.get("item_ids")
        sep: str = kwargs.get("sep", "-")

        unique_ids = []
        for i, sid in enumerate(semantic_ids):
            idx = self.store.next_suffix(sid)

            if idx == 0:
                unique_ids.append(sid)
            elif item_ids is not None:
                unique_ids.append(f"{sid}{sep}{item_ids[i]}")
            else:
                unique_ids.append(f"{sid}{sep}{idx}")

        return unique_ids


class SinkhornResolver(BaseResolver):
    """
    Resolves collisions by re-encoding colliding items with Sinkhorn-Knopp
    balanced assignment enabled on the last VQ layer.

    This is based on the approach in the reference ``generate_indices.py`` from
    the MiniOneRec project. Instead of appending suffixes, it iteratively
    re-encodes colliding items so they get different codes from the quantizer itself,
    producing more semantically meaningful unique IDs.

    Requires an RQVAE model with accessible VQ layers.

    Args:
        max_iterations: Maximum number of Sinkhorn re-encoding iterations.
        sk_epsilon: Sinkhorn epsilon for the last VQ layer during re-encoding.
            If None, uses 0.003 as default.
        fallback_suffix: If True, falls back to suffix-based resolution for any
            remaining collisions after max_iterations. If False, returns results
            with remaining collisions unresolved.
    """

    def __init__(
        self,
        max_iterations: int = 20,
        sk_epsilon: Optional[float] = None,
        fallback_suffix: bool = True,
    ):
        self.max_iterations = max_iterations
        self.sk_epsilon = sk_epsilon if sk_epsilon is not None else _DEFAULT_SK_EPSILON
        self.fallback_suffix = fallback_suffix

    def assign(self, semantic_ids: List[str], **kwargs: Any) -> List[str]:
        """
        Resolve collisions using Sinkhorn re-encoding.

        Requires ``embeddings``, ``model``, and ``device`` to be passed as kwargs.

        Args:
            semantic_ids: List of raw semantic ID strings.
            embeddings: Original embedding tensor (N, D) on the target device.
            model: RQVAEModule instance (must have ``rq.vq_layers`` and ``get_indices``).
            device: Device string.
            sep: Separator used in semantic IDs.

        Returns:
            List of unique IDs.
        """
        import torch

        embeddings = kwargs.get("embeddings")
        model = kwargs.get("model")
        sep = kwargs.get("sep", "-")

        if embeddings is None or model is None:
            raise ValueError(
                "SinkhornResolver.assign() requires 'embeddings' and 'model' kwargs. "
                "Use SemanticIdEngine with an RQVAE encoder for Sinkhorn resolution."
            )

        # Convert to mutable arrays for in-place updates
        all_ids = list(semantic_ids)
        all_ids_str = np.array([str(s) for s in all_ids])

        original_epsilons = []
        for vq in model.rq.vq_layers:
            original_epsilons.append(vq.sk_epsilon)

        try:
            for vq in model.rq.vq_layers[:-1]:
                vq.sk_epsilon = 0.0

            last_vq = model.rq.vq_layers[-1]
            if last_vq.sk_epsilon <= 0:
                last_vq.sk_epsilon = self.sk_epsilon

            model.eval()

            for iteration in range(self.max_iterations):
                collision_groups = self._find_collision_groups(all_ids_str)

                if not collision_groups:
                    break

                with torch.no_grad():
                    for group_indices in collision_groups:
                        group_emb = embeddings[group_indices]

                        new_indices = model.get_indices(group_emb, use_sk=True)
                        new_indices_np = new_indices.cpu().numpy()

                        for local_idx, global_idx in enumerate(group_indices):
                            new_code = new_indices_np[local_idx]
                            new_sid = sep.join(map(str, new_code))
                            all_ids[global_idx] = new_sid
                            all_ids_str[global_idx] = new_sid
        finally:
            for vq, eps in zip(model.rq.vq_layers, original_epsilons):
                vq.sk_epsilon = eps

        # Fallback: if still collisions, use suffix resolution
        if self.fallback_suffix:
            suffix_store = InMemoryCollisionStore()
            item_ids: Optional[List[str]] = kwargs.get("item_ids")
            final_ids = []
            for i, sid in enumerate(all_ids):
                idx = suffix_store.next_suffix(sid)
                if idx == 0:
                    final_ids.append(sid)
                elif item_ids is not None:
                    final_ids.append(f"{sid}{sep}{item_ids[i]}")
                else:
                    final_ids.append(f"{sid}{sep}{idx}")
            return final_ids

        return all_ids

    @staticmethod
    def _find_collision_groups(ids_array: np.ndarray) -> List[List[int]]:
        """Find groups of indices that share the same ID string."""
        index_map: dict = {}
        for i, sid in enumerate(ids_array):
            if sid not in index_map:
                index_map[sid] = []
            index_map[sid].append(i)

        return [indices for indices in index_map.values() if len(indices) > 1]
