from typing import List, Literal, Optional, Union

import numpy as np
import torch
from tqdm import tqdm

from semantic_id.exceptions import NotFittedError
from semantic_id.utils.clustering import (
    _DEFAULT_SINKHORN_EPSILON,
    _DEFAULT_SINKHORN_ITERATIONS,
    center_distance_for_constraint,
    kmeans_torch,
    sinkhorn_algorithm,
)

# For constrained clustering fallback
try:
    from k_means_constrained import KMeansConstrained

    HAS_CONSTRAINED = True
except (ImportError, ValueError):
    HAS_CONSTRAINED = False


class RQKMeansTorch:
    """
    PyTorch-based backend for RQ-KMeans.
    Provides GPU acceleration for encode() and standard K-Means fit().
    For Constrained K-Means fit(), it currently falls back to CPU implementation,
    but moves centroids to GPU for fast inference.
    """

    def __init__(
        self,
        n_levels: int,
        n_clusters: List[int],
        metric: Literal["l2", "cosine"],
        implementation: Literal["kmeans", "constrained"],
        max_iter: int,
        tol: float,
        random_state: Optional[int],
        verbose: bool,
        device: str,
        n_init: Optional[int] = None,
    ) -> None:
        """
        Args:
            n_levels: Number of residual quantization levels.
            n_clusters: Codebook size per level.
            metric: Distance metric (``"l2"`` only).
            implementation: ``"kmeans"`` or ``"constrained"``.
            max_iter: Maximum K-Means iterations per level.
            tol: Convergence tolerance.
            random_state: Seed for reproducibility.
            verbose: Show progress bars.
            device: PyTorch device string (e.g. ``"cuda"``).
            n_init: Number of K-Means initialisations.
        """
        self.n_levels = n_levels
        self.n_clusters = n_clusters
        self.metric = metric
        self.implementation = implementation
        self.max_iter = max_iter
        self.tol = tol
        self.random_state = random_state
        self.verbose = verbose
        self.device = device
        self.n_init = n_init

        self.codebooks_: List[torch.Tensor] = []
        self.D_: Optional[int] = None

    def fit(self, X: Union[np.ndarray, torch.Tensor]) -> "RQKMeansTorch":
        """
        Train the encoder on embeddings *X*.

        Args:
            X: Input embeddings of shape ``(N, D)``.

        Returns:
            self
        """
        if isinstance(X, np.ndarray):
            X = torch.from_numpy(X).to(self.device, dtype=torch.float32)
        else:
            X = X.to(self.device, dtype=torch.float32)

        N, D = X.shape
        self.D_ = D
        self.codebooks_ = []

        # Residuals start as X
        residuals = X.clone()

        level_iter = range(self.n_levels)
        if self.verbose:
            level_iter = tqdm(
                level_iter, desc=f"RQ-KMeans fit ({self.device})", unit="level"
            )

        for lvl in level_iter:
            K = self.n_clusters[lvl]

            # Seed handling - match CPU backend's seed generation for reproducibility
            seed = None
            if self.random_state is not None:
                seed = int(
                    np.random.RandomState(self.random_state + lvl).randint(0, 2**31 - 1)
                )

            centers = None
            labels = None

            if self.implementation == "constrained":
                # Attempt to use GPU-based Sinkhorn Constrained K-Means first
                try:
                    centers, labels = self._constrained_kmeans_torch(residuals, K, seed)
                except (RuntimeError, ValueError) as e:
                    if self.verbose:
                        print(
                            f"GPU Constrained K-Means failed ({e}), falling back to CPU..."
                        )

                    # FALLBACK to CPU for Constrained Fit
                    # k-means-constrained library is CPU only.
                    # Move residuals to CPU numpy
                    residuals_cpu = residuals.cpu().numpy()

                    min_size = max(1, N // K - 1)
                    max_size = N // K + 1

                    if not HAS_CONSTRAINED:
                        raise ImportError(
                            "k-means-constrained is required for implementation='constrained'"
                        )

                    # Determine n_init (same logic as RQKMeans)
                    if self.n_init is not None:
                        current_n_init = self.n_init
                    else:
                        current_n_init = 3

                    kmeans = KMeansConstrained(
                        n_clusters=K,
                        size_min=min_size,
                        size_max=max_size,
                        max_iter=self.max_iter,
                        tol=self.tol,
                        random_state=seed,
                        n_init=current_n_init,
                        n_jobs=-1,
                    )
                    kmeans.fit(residuals_cpu)

                    # Convert results back to Torch/GPU
                    centers = torch.from_numpy(kmeans.cluster_centers_).to(
                        self.device, dtype=torch.float32
                    )
                    labels = torch.from_numpy(kmeans.labels_).to(
                        self.device, dtype=torch.long
                    )

            else:
                # Standard K-Means on GPU
                centers, labels = self._kmeans_torch(residuals, K, seed)

            self.codebooks_.append(centers)

            # Update residuals
            # residuals -= centers[labels]
            # Gather centers using labels
            selected_centers = centers[labels]
            residuals = residuals - selected_centers

        return self

    def encode(
        self, X: Union[np.ndarray, torch.Tensor], batch_size: Optional[int] = None
    ) -> np.ndarray:
        """
        Encode embeddings into discrete codes.

        Args:
            X: Input embeddings of shape ``(N, D)``.
            batch_size: Optional batch size for large datasets.

        Returns:
            Integer codes of shape ``(N, L)`` with dtype ``int32``.

        Raises:
            RuntimeError: If the model has not been fitted yet.
        """
        if not self.codebooks_:
            raise NotFittedError("Model is not fitted yet. Call fit() first.")

        if isinstance(X, np.ndarray):
            X = torch.from_numpy(X).to(self.device, dtype=torch.float32)
        else:
            X = X.to(self.device, dtype=torch.float32)

        N = X.shape[0]
        if batch_size is None:
            batch_size = N

        # Output codes (on CPU numpy at the end)
        # We collect them on CPU to avoid OOM for large N
        codes = np.zeros((N, self.n_levels), dtype=np.int32)

        batch_starts = range(0, N, batch_size)
        if self.verbose and N > batch_size:
            batch_starts = tqdm(
                batch_starts, desc=f"RQ-KMeans encode ({self.device})", unit="batch"
            )

        for start_idx in batch_starts:
            end_idx = min(start_idx + batch_size, N)
            batch_X = X[start_idx:end_idx]  # (B, D)

            residuals = batch_X.clone()  # We modify residuals

            for lvl in range(self.n_levels):
                codebook = self.codebooks_[lvl]  # (K, D) on device

                # Compute distances (B, K)
                # dist = ||x - c||^2
                # torch.cdist computes p-norm. squared euclidean needs manual or **2
                # For K-Means, we just need argmin, so squared vs not-squared doesn't change order.
                # cdist is efficient.
                dists = torch.cdist(residuals, codebook, p=2.0)  # (B, K)

                # Argmin
                batch_codes = torch.argmin(dists, dim=1)  # (B,)

                # Store codes (move to CPU)
                codes[start_idx:end_idx, lvl] = batch_codes.cpu().numpy()

                # Update residuals
                # selected_centers = codebook[batch_codes]
                # residuals -= selected_centers
                # We can do this in place
                residuals -= codebook[batch_codes]

        return codes

    def _kmeans_torch(
        self, X: torch.Tensor, K: int, seed: Optional[int]
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Simple K-Means implementation in PyTorch using shared utils.
        """
        centers = kmeans_torch(
            X, num_clusters=K, max_iter=self.max_iter, tol=self.tol, seed=seed
        )

        # Compute labels for residual update
        dists = torch.cdist(X, centers, p=2.0)
        labels = torch.argmin(dists, dim=1)

        return centers, labels

    def _constrained_kmeans_torch(
        self, X: torch.Tensor, K: int, seed: Optional[int]
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Constrained K-Means using Sinkhorn-Knopp algorithm for balanced assignment.
        This runs entirely on GPU.
        """
        N, D = X.shape

        if seed is not None:
            torch.manual_seed(seed)

        # Initialize centers randomly
        indices = torch.randperm(N, device=self.device)[:K]
        centers = X[indices].clone()

        for i in range(self.max_iter):
            # E-step: Assign labels with Sinkhorn balancing
            dists = torch.cdist(X, centers, p=2.0)  # (N, K)
            dists_sq = dists**2

            d_centered = center_distance_for_constraint(dists_sq)
            Q = sinkhorn_algorithm(
                d_centered,
                epsilon=_DEFAULT_SINKHORN_EPSILON,
                sinkhorn_iterations=_DEFAULT_SINKHORN_ITERATIONS,
            )

            # Hard assignment from Q
            labels = torch.argmax(Q, dim=1)

            # M-step: Update centers (same as standard KMeans)
            new_centers = torch.zeros_like(centers)
            for k in range(K):
                mask = labels == k
                if mask.any():
                    new_centers[k] = X[mask].mean(dim=0)
                else:
                    new_centers[k] = centers[
                        k
                    ]  # Keep old if empty (rare with Sinkhorn)

            shift = torch.norm(centers - new_centers)
            centers = new_centers

            if shift < self.tol:
                break

        return centers, labels
