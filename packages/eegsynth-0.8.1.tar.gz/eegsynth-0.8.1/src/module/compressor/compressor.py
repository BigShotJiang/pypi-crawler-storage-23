#!/usr/bin/env python

# Compressor and expander module changes the dynamic range
#
# This software is part of the EEGsynth project, see <https://github.com/eegsynth/eegsynth>.
#
# Copyright (C) 2017-2024 EEGsynth project
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import os
import sys
import time

if hasattr(sys, "frozen"):
    path = os.path.split(sys.executable)[0]
    file = os.path.split(__file__)[-1]
    name = os.path.splitext(file)[0]
elif __name__ == "__main__" and sys.argv[0] != "":
    path = os.path.split(sys.argv[0])[0]
    file = os.path.split(sys.argv[0])[-1]
    name = os.path.splitext(file)[0]
elif __name__ == "__main__":
    path = os.path.abspath("")
    file = os.path.split(path)[-1] + ".py"
    name = os.path.splitext(file)[0]
else:
    path = os.path.split(__file__)[0]
    file = os.path.split(__file__)[-1]
    name = os.path.splitext(file)[0]

# the lib directory contains shared code
sys.path.append(os.path.join(path, '../../lib'))
import EEGsynth


def _setup():
    """Initialize the module
    This adds a set of global variables
    """
    global patch, name, path, monitor

    # configure and start the patch, this will parse the command-line arguments and the ini file
    patch = EEGsynth.patch(name=name, path=path)

    # this shows the splash screen and can be used to track parameters that have changed
    monitor = EEGsynth.monitor(name=name, patch=patch, debug=patch.getint('general', 'debug', default=1), target=patch.get('general', 'logging', default=None))

    # there should not be any local variables in this function, they should all be global
    if len(locals()):
        print("LOCALS: " + ", ".join(locals().keys()))


def _start():
    """Start the module
    This uses the global variables from setup and adds a set of global variables
    """
    global patch, name, path, monitor
    global delay, prefix, input_name, input_variable

    # get the options from the configuration file
    delay = patch.getfloat('general', 'delay')
    prefix = patch.getstring('output', 'prefix')

    # get the input options
    input_name, input_variable = list(zip(*patch.config.items('input')))

    for name, variable in zip(input_name, input_variable):
        monitor.info("%s = %s" % (name, variable))

    # there should not be any local variables in this function, they should all be global
    if len(locals()):
        print("LOCALS: " + ", ".join(locals().keys()))


def _loop_once():
    """Run the main loop once
    This uses the global variables from setup and start, and adds a set of global variables
    """
    global patch, name, path, monitor
    global delay, prefix, input_name, input_variable

    if patch.getint('processing', 'enable', default=1):
        # the compressor/expander applies to all channels and must exist as float or redis key
        scale = patch.getfloat('scale', 'lo', default=1.)
        offset = patch.getfloat('offset', 'lo', default=0.)
        lo = patch.getfloat('processing', 'lo')
        lo = EEGsynth.rescale(lo, slope=scale, offset=offset)

        scale = patch.getfloat('scale', 'hi', default=1.)
        offset = patch.getfloat('offset', 'hi', default=0.)
        hi = patch.getfloat('processing', 'hi')
        hi = EEGsynth.rescale(hi, slope=scale, offset=offset)

        monitor.update('lo', lo)
        monitor.update('hi', hi)

        if lo is None or hi is None:
            monitor.debug("cannot apply compressor/expander")
            return

        for name, variable in zip(input_name, input_variable):
            scale = patch.getfloat('scale', name, default=1)
            offset = patch.getfloat('offset', name, default=0)
            val = patch.getfloat('input', name)

            if val == None:
                # the value is not present in redis, skip it
                continue

            val = EEGsynth.rescale(val, slope=scale, offset=offset)
            val = EEGsynth.compress(val, lo, hi)

            key = prefix + "." + variable
            patch.setvalue(key, val)
            monitor.update(key, val)


def _loop_forever():
    """Run the main loop forever
    """
    global monitor, patch
    while True:
        monitor.loop()
        _loop_once()
        time.sleep(patch.getfloat('general', 'delay'))


def _stop():
    """Stop and clean up on SystemExit, KeyboardInterrupt, RuntimeError
    """
    pass


if __name__ == "__main__":
    _setup()
    _start()
    try:
        _loop_forever()
    except (SystemExit, KeyboardInterrupt, RuntimeError):
        _stop()
    sys.exit()
