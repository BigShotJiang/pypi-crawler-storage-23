# Copyright (c) 2022-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# See LICENSE for license information.

"""Single tensor operations supported by the operation fuser."""

from .activation import (
    GELU,
    GEGLU,
    QGELU,
    QGEGLU,
    ReLU,
    ReGLU,
    SReLU,
    SReGLU,
    SiLU,
    SwiGLU,
    ClampedSwiGLU,
)
from .add_extra_input import AddExtraInput
from .all_gather import AllGather
from .all_reduce import AllReduce
from .basic_linear import BasicLinear
from .bias import Bias
from .constant_scale import ConstantScale
from .dropout import Dropout
from .identity import Identity
from .l2normalization import L2Normalization
from .layer_norm import LayerNorm
from .make_extra_output import MakeExtraOutput
from .quantize import Quantize
from .reduce_scatter import ReduceScatter
from .reshape import Reshape
from .rmsnorm import RMSNorm
