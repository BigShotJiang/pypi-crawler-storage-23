"""
Deep analysis of hierarchy plan branching and alternative reduction strategies.

Usage:
    PYTHONPATH=. uv run python tests/benchmarks/profile_hierarchy_deep.py
"""
from __future__ import annotations

import time
from datetime import date

import polars as pl

from tests.benchmarks.data_generators import get_or_create_dataset
from tests.benchmarks.test_pipeline_benchmark import create_raw_data_bundle

from rwa_calc.contracts.bundles import CounterpartyLookup, ResolvedHierarchyBundle
from rwa_calc.contracts.config import CalculationConfig, IRBPermissions
from rwa_calc.engine.hierarchy import HierarchyResolver
from rwa_calc.engine.classifier import ExposureClassifier
from rwa_calc.engine.crm.processor import CRMProcessor
from rwa_calc.engine.utils import has_required_columns


REPORTING_DATE = date(2026, 1, 1)


def _pl(lf: pl.LazyFrame) -> int:
    try:
        return len(lf.explain(optimized=True).strip().split("\n"))
    except Exception:
        return -1


def _ct(lf: pl.LazyFrame, n: int = 3) -> float:
    times = []
    for _ in range(n):
        t0 = time.perf_counter()
        _ = lf.collect()
        times.append(time.perf_counter() - t0)
    return min(times)


def _m(label: str, lf: pl.LazyFrame) -> None:
    print(f"  {label:<60} plan={_pl(lf):>5}  collect={_ct(lf)*1000:>8.1f}ms")


# ─────────────────────────────────────────────────────────────────────────────
# Analysis 1: Where do the 521 post-collect lines come from?
# ─────────────────────────────────────────────────────────────────────────────

def trace_post_unify_branches(dataset: dict[str, pl.LazyFrame]) -> None:
    """After collecting unify output (1 line), trace where 521 comes from."""
    raw_data = create_raw_data_bundle(dataset)
    config = CalculationConfig.crr(REPORTING_DATE, irb_permissions=IRBPermissions.full_irb())
    resolver = HierarchyResolver()

    print("=" * 90)
    print("TRACE: Post-unify-collect plan growth (1 -> 521 lines)")
    print("=" * 90)

    # Build + collect cp_lookup and unify
    cp_lookup, _ = resolver._build_counterparty_lookup(
        raw_data.counterparties, raw_data.org_mappings, raw_data.ratings,
    )
    cp_lookup = CounterpartyLookup(
        counterparties=cp_lookup.counterparties.collect().lazy(),
        parent_mappings=cp_lookup.parent_mappings,
        ultimate_parent_mappings=cp_lookup.ultimate_parent_mappings,
        rating_inheritance=cp_lookup.rating_inheritance.collect().lazy(),
    )
    exposures, _ = resolver._unify_exposures(
        raw_data.loans, raw_data.contingents, raw_data.facilities,
        raw_data.facility_mappings, cp_lookup,
    )
    exposures = exposures.collect().lazy()  # 1 line
    _m("exposures (collected)", exposures)

    # FX audit
    exposures = exposures.with_columns([
        pl.col("currency").alias("original_currency"),
        (pl.col("drawn_amount") + pl.col("interest").fill_null(0.0)
         + pl.col("nominal_amount")).alias("original_amount"),
        pl.lit(None).cast(pl.Float64).alias("fx_rate_applied"),
    ])
    _m("after FX audit", exposures)

    # LTV
    exposures_ltv = resolver._add_collateral_ltv(exposures, raw_data.collateral)
    _m("after LTV", exposures_ltv)

    # Property coverage enrichment (adds columns via .over() window)
    exposures_with_coverage = resolver._enrich_with_property_coverage(
        exposures_ltv, raw_data.collateral,
    )
    _m("after property coverage enrichment", exposures_with_coverage)

    # Lending group enrichment (adds columns via .over() window)
    final = resolver._enrich_with_lending_group(
        exposures_with_coverage, raw_data.lending_mappings,
    )
    _m("FINAL exposures", final)

    # How many times is exposures_ltv embedded?
    plan = final.explain(optimized=True)
    # Count "PARQUET" or data source references
    source_refs = sum(1 for line in plan.split("\n") if "DF" in line or "SCAN" in line.upper())
    print(f"\n  Data source references in final plan: {source_refs}")


# ─────────────────────────────────────────────────────────────────────────────
# Analysis 2: Collect more intermediates
# ─────────────────────────────────────────────────────────────────────────────

def test_collect_intermediates(dataset: dict[str, pl.LazyFrame]) -> None:
    """Test collecting res_coverage and lending_totals as well."""
    raw_data = create_raw_data_bundle(dataset)
    config = CalculationConfig.crr(REPORTING_DATE, irb_permissions=IRBPermissions.full_irb())
    resolver = HierarchyResolver()

    print("\n" + "=" * 90)
    print("STRATEGY A: Collect more intermediates")
    print("=" * 90)

    t_total = time.perf_counter()

    # Collect cp_lookup
    cp_lookup, _ = resolver._build_counterparty_lookup(
        raw_data.counterparties, raw_data.org_mappings, raw_data.ratings,
    )
    cp_lookup = CounterpartyLookup(
        counterparties=cp_lookup.counterparties.collect().lazy(),
        parent_mappings=cp_lookup.parent_mappings,
        ultimate_parent_mappings=cp_lookup.ultimate_parent_mappings,
        rating_inheritance=cp_lookup.rating_inheritance.collect().lazy(),
    )

    # Collect unify
    exposures, _ = resolver._unify_exposures(
        raw_data.loans, raw_data.contingents, raw_data.facilities,
        raw_data.facility_mappings, cp_lookup,
    )
    exposures = exposures.collect().lazy()

    # FX audit + LTV
    exposures = exposures.with_columns([
        pl.col("currency").alias("original_currency"),
        (pl.col("drawn_amount") + pl.col("interest").fill_null(0.0)
         + pl.col("nominal_amount")).alias("original_amount"),
        pl.lit(None).cast(pl.Float64).alias("fx_rate_applied"),
    ])
    exposures_ltv = resolver._add_collateral_ltv(exposures, raw_data.collateral)

    # Enrich with property coverage
    t0 = time.perf_counter()
    exposures_enriched = resolver._enrich_with_property_coverage(
        exposures_ltv, raw_data.collateral,
    )
    exposures_enriched = exposures_enriched.collect().lazy()
    print(f"  Collecting after property coverage: {(time.perf_counter()-t0)*1000:.1f}ms")
    _m("  property coverage (collected)", exposures_enriched)

    # Enrich with lending group
    t0 = time.perf_counter()
    final = resolver._enrich_with_lending_group(
        exposures_enriched, raw_data.lending_mappings,
    )
    final_collected = final.collect().lazy()
    print(f"  Collecting after lending group: {(time.perf_counter()-t0)*1000:.1f}ms")
    _m("  FINAL exposures (collected)", final_collected)

    # Derive lending_group_totals from enriched exposures
    lending_totals = final_collected.filter(
        pl.col("lending_group_reference").is_not_null()
    ).group_by("lending_group_reference").agg([
        pl.col("drawn_amount").clip(lower_bound=0.0).sum().alias("total_drawn"),
        pl.col("nominal_amount").sum().alias("total_nominal"),
        (pl.col("drawn_amount").clip(lower_bound=0.0)
         + pl.col("nominal_amount")).sum().alias("total_exposure"),
        pl.col("exposure_for_retail_threshold").sum()
        .alias("adjusted_exposure"),
        pl.col("residential_collateral_value").sum()
        .alias("total_residential_coverage"),
        pl.len().alias("exposure_count"),
    ])

    # Classify
    resolved = ResolvedHierarchyBundle(
        exposures=final_collected,
        counterparty_lookup=cp_lookup,
        collateral=raw_data.collateral,
        guarantees=raw_data.guarantees,
        provisions=raw_data.provisions,
        equity_exposures=raw_data.equity_exposures,
        lending_group_totals=lending_totals,
        hierarchy_errors=[],
    )
    t0 = time.perf_counter()
    classified = ExposureClassifier().classify(resolved, config)
    classify_time = time.perf_counter() - t0
    print(f"  classify(): {classify_time*1000:.1f}ms")

    total = time.perf_counter() - t_total
    print(f"\n  TOTAL (hierarchy + classify): {total*1000:.1f}ms")


# ─────────────────────────────────────────────────────────────────────────────
# Analysis 3: Reduce branching by combining operations
# ─────────────────────────────────────────────────────────────────────────────

def test_fused_property_collateral(dataset: dict[str, pl.LazyFrame]) -> None:
    """
    Test replacing 6 separate filter+group_by on collateral with
    a single conditional group_by, to halve the collateral branches.
    """
    raw_data = create_raw_data_bundle(dataset)
    resolver = HierarchyResolver()

    cp_lookup, _ = resolver._build_counterparty_lookup(
        raw_data.counterparties, raw_data.org_mappings, raw_data.ratings,
    )
    cp_lookup = CounterpartyLookup(
        counterparties=cp_lookup.counterparties.collect().lazy(),
        parent_mappings=cp_lookup.parent_mappings,
        ultimate_parent_mappings=cp_lookup.ultimate_parent_mappings,
        rating_inheritance=cp_lookup.rating_inheritance.collect().lazy(),
    )
    exposures, _ = resolver._unify_exposures(
        raw_data.loans, raw_data.contingents, raw_data.facilities,
        raw_data.facility_mappings, cp_lookup,
    )
    exposures = exposures.collect().lazy()
    exposures = exposures.with_columns([
        pl.col("currency").alias("original_currency"),
        (pl.col("drawn_amount") + pl.col("interest").fill_null(0.0)
         + pl.col("nominal_amount")).alias("original_amount"),
        pl.lit(None).cast(pl.Float64).alias("fx_rate_applied"),
    ])
    exposures_ltv = resolver._add_collateral_ltv(exposures, raw_data.collateral)
    collateral = raw_data.collateral

    print("\n" + "=" * 90)
    print("STRATEGY B: Fuse property collateral aggregations (6 -> 2 group_bys)")
    print("=" * 90)

    # Current approach: _enrich_with_property_coverage (uses .over() windows)
    t0 = time.perf_counter()
    enriched_baseline = resolver._enrich_with_property_coverage(
        exposures_ltv, collateral,
    )
    _ = enriched_baseline.collect()
    baseline_time = time.perf_counter() - t0
    print(f"\n  Baseline (_enrich_with_property_coverage): {baseline_time*1000:.1f}ms")
    _m("  baseline enriched", enriched_baseline)

    # Fused approach: 1 group_by per collateral type (residential vs all-property)
    # with conditional sums for direct/facility/counterparty
    t0 = time.perf_counter()

    exposure_amounts = exposures_ltv.select([
        pl.col("exposure_reference"),
        pl.col("counterparty_reference"),
        pl.col("parent_facility_reference"),
        pl.col("drawn_amount").clip(lower_bound=0.0).alias("total_exposure_amount"),
    ])

    is_residential = (
        (pl.col("collateral_type").str.to_lowercase() == "real_estate") &
        (pl.col("property_type").str.to_lowercase() == "residential")
    )
    is_property = pl.col("collateral_type").str.to_lowercase() == "real_estate"
    ben_type = pl.col("beneficiary_type").str.to_lowercase()
    is_direct = ben_type.is_in(["exposure", "loan"])
    is_facility = ben_type == "facility"
    is_cp = ben_type == "counterparty"

    # Single aggregation: group by beneficiary_reference, compute all 6 sums at once
    coll_agg = collateral.filter(is_property).group_by("beneficiary_reference").agg([
        # Residential sums (conditional on property_type)
        pl.col("market_value").filter(is_residential & is_direct).sum().alias("res_direct"),
        pl.col("market_value").filter(is_residential & is_facility).sum().alias("res_facility"),
        pl.col("market_value").filter(is_residential & is_cp).sum().alias("res_cp"),
        # All-property sums
        pl.col("market_value").filter(is_direct).sum().alias("prop_direct"),
        pl.col("market_value").filter(is_facility).sum().alias("prop_facility"),
        pl.col("market_value").filter(is_cp).sum().alias("prop_cp"),
    ])

    # Allocation weights
    facility_totals = exposure_amounts.group_by("parent_facility_reference").agg([
        pl.col("total_exposure_amount").sum().alias("facility_total"),
    ])
    cp_totals = exposure_amounts.group_by("counterparty_reference").agg([
        pl.col("total_exposure_amount").sum().alias("cp_total"),
    ])

    # Join all at once (1 join from coll_agg for direct, 1 for facility, 1 for cp)
    # Actually we need 3 joins because beneficiary_reference maps to different columns
    # But coll_agg is ONE frame now, not 6 separate ones

    # Split by beneficiary level for joining (but from the same collected source)
    direct_vals = coll_agg.select([
        pl.col("beneficiary_reference").alias("direct_ref"),
        pl.col("res_direct"), pl.col("prop_direct"),
    ]).filter(
        (pl.col("res_direct") > 0) | (pl.col("prop_direct") > 0)
    )

    facility_vals = coll_agg.select([
        pl.col("beneficiary_reference").alias("fac_ref"),
        pl.col("res_facility"), pl.col("prop_facility"),
    ]).filter(
        (pl.col("res_facility") > 0) | (pl.col("prop_facility") > 0)
    )

    cp_vals = coll_agg.select([
        pl.col("beneficiary_reference").alias("cp_ref"),
        pl.col("res_cp"), pl.col("prop_cp"),
    ]).filter(
        (pl.col("res_cp") > 0) | (pl.col("prop_cp") > 0)
    )

    result = exposure_amounts.join(
        direct_vals, left_on="exposure_reference", right_on="direct_ref", how="left",
    ).join(
        facility_vals, left_on="parent_facility_reference", right_on="fac_ref", how="left",
    ).join(
        facility_totals, on="parent_facility_reference", how="left",
    ).join(
        cp_vals, left_on="counterparty_reference", right_on="cp_ref", how="left",
    ).join(
        cp_totals, on="counterparty_reference", how="left",
    )

    result = result.with_columns([
        pl.when(pl.col("facility_total") > 0)
        .then(pl.col("total_exposure_amount") / pl.col("facility_total"))
        .otherwise(0.0).alias("fac_w"),
        pl.when(pl.col("cp_total") > 0)
        .then(pl.col("total_exposure_amount") / pl.col("cp_total"))
        .otherwise(0.0).alias("cp_w"),
    ]).with_columns([
        (pl.col("res_direct").fill_null(0.0)
         + pl.col("res_facility").fill_null(0.0) * pl.col("fac_w")
         + pl.col("res_cp").fill_null(0.0) * pl.col("cp_w")
        ).alias("residential_collateral_value"),
        (pl.col("prop_direct").fill_null(0.0)
         + pl.col("prop_facility").fill_null(0.0) * pl.col("fac_w")
         + pl.col("prop_cp").fill_null(0.0) * pl.col("cp_w")
        ).alias("property_collateral_value"),
    ]).with_columns([
        pl.when(pl.col("residential_collateral_value") > pl.col("total_exposure_amount"))
        .then(pl.col("total_exposure_amount"))
        .otherwise(pl.col("residential_collateral_value"))
        .alias("residential_collateral_value"),
        (pl.col("total_exposure_amount") - pl.col("residential_collateral_value"))
        .alias("exposure_for_retail_threshold"),
        ((pl.col("prop_direct").fill_null(0.0) > 0)
         | (pl.col("prop_facility").fill_null(0.0) > 0)
         | (pl.col("prop_cp").fill_null(0.0) > 0)
        ).alias("has_facility_property_collateral"),
    ]).select([
        "exposure_reference",
        "residential_collateral_value",
        "property_collateral_value",
        "exposure_for_retail_threshold",
        "has_facility_property_collateral",
    ])

    _ = result.collect()
    fused_time = time.perf_counter() - t0
    print(f"  Fused (1 group_by + splits): {fused_time*1000:.1f}ms")
    _m("  fused res_coverage", result)


# ─────────────────────────────────────────────────────────────────────────────
# Analysis 4: Defer counterparty lookup join
# ─────────────────────────────────────────────────────────────────────────────

def test_deferred_cp_join(dataset: dict[str, pl.LazyFrame]) -> None:
    """
    Test deferring the 12-column counterparty join from _unify_exposures
    to the classifier. This keeps the unify plan smaller.
    """
    raw_data = create_raw_data_bundle(dataset)
    resolver = HierarchyResolver()

    print("\n" + "=" * 90)
    print("STRATEGY C: Defer counterparty join (unify without cp_lookup)")
    print("=" * 90)

    cp_lookup, _ = resolver._build_counterparty_lookup(
        raw_data.counterparties, raw_data.org_mappings, raw_data.ratings,
    )

    # Current: cp_lookup uncollected, full join in _unify
    exposures_current, _ = resolver._unify_exposures(
        raw_data.loans, raw_data.contingents, raw_data.facilities,
        raw_data.facility_mappings, cp_lookup,
    )
    _m("  Current: unify WITH cp_lookup join", exposures_current)

    # Experiment: use a minimal cp_lookup that only has counterparty_reference
    # (no enrichment — just enough for _unify to work)
    # Check if _unify_exposures actually needs the cp_lookup columns internally
    # It only uses cp_lookup.counterparties in the final join (line 966-983)
    # So we can pass a minimal counterparties frame

    # Can't easily test — _unify_exposures selects 12 columns from cp_lookup.counterparties
    # Deferring would require restructuring _unify_exposures to accept a separate cp join frame
    print("  (Skipped — _unify_exposures internally selects 12 cols from cp_lookup)")

    # What about just dropping the cp join entirely from unify?
    # The cp join adds 12 columns that aren't used until classification
    print("\n  The 12 cp_lookup columns joined in _unify_exposures:")
    print("    counterparty_has_parent, parent_counterparty_reference,")
    print("    ultimate_parent_reference, counterparty_hierarchy_depth,")
    print("    cqs, pd, rating_value, rating_agency,")
    print("    rating_inherited, rating_source_counterparty, rating_inheritance_reason")
    print("  -> None of these are used by LTV, residential coverage, or lending groups")
    print("  -> They're only needed by the classifier")


# ─────────────────────────────────────────────────────────────────────────────
# Analysis 5: Collect collateral once upfront
# ─────────────────────────────────────────────────────────────────────────────

def test_collateral_precollect(dataset: dict[str, pl.LazyFrame]) -> None:
    """Test pre-collecting the collateral frame since it's used 3+ times."""
    raw_data = create_raw_data_bundle(dataset)
    config = CalculationConfig.crr(REPORTING_DATE, irb_permissions=IRBPermissions.full_irb())
    resolver = HierarchyResolver()

    print("\n" + "=" * 90)
    print("STRATEGY D: Pre-collect collateral (used in LTV + res_coverage + CRM)")
    print("=" * 90)

    collateral = raw_data.collateral
    n = collateral.select(pl.len()).collect().item()
    _m(f"  collateral ({n:,} rows, lazy scan)", collateral)

    t0 = time.perf_counter()
    collateral_collected = collateral.collect().lazy()
    coll_time = time.perf_counter() - t0
    print(f"  Collecting collateral: {coll_time*1000:.1f}ms")
    _m("  collateral (collected)", collateral_collected)

    # Compare pipeline with and without collateral pre-collect
    cp_lookup, _ = resolver._build_counterparty_lookup(
        raw_data.counterparties, raw_data.org_mappings, raw_data.ratings,
    )
    cp_lookup = CounterpartyLookup(
        counterparties=cp_lookup.counterparties.collect().lazy(),
        parent_mappings=cp_lookup.parent_mappings,
        ultimate_parent_mappings=cp_lookup.ultimate_parent_mappings,
        rating_inheritance=cp_lookup.rating_inheritance.collect().lazy(),
    )
    exposures, _ = resolver._unify_exposures(
        raw_data.loans, raw_data.contingents, raw_data.facilities,
        raw_data.facility_mappings, cp_lookup,
    )
    exposures = exposures.collect().lazy()
    exposures = exposures.with_columns([
        pl.col("currency").alias("original_currency"),
        (pl.col("drawn_amount") + pl.col("interest").fill_null(0.0)
         + pl.col("nominal_amount")).alias("original_amount"),
        pl.lit(None).cast(pl.Float64).alias("fx_rate_applied"),
    ])

    # With lazy collateral
    ltv_lazy = resolver._add_collateral_ltv(exposures, collateral)
    enriched_lazy = resolver._enrich_with_property_coverage(ltv_lazy, collateral)
    _m("  enriched (lazy collateral)", enriched_lazy)

    # With collected collateral
    ltv_coll = resolver._add_collateral_ltv(exposures, collateral_collected)
    enriched_coll = resolver._enrich_with_property_coverage(ltv_coll, collateral_collected)
    _m("  enriched (collected collateral)", enriched_coll)


# ─────────────────────────────────────────────────────────────────────────────
# Analysis 6: Combined best approach — full pipeline timing
# ─────────────────────────────────────────────────────────────────────────────

def test_combined_best(dataset: dict[str, pl.LazyFrame]) -> None:
    """Test all strategies combined for maximum plan reduction."""
    raw_data = create_raw_data_bundle(dataset)
    config = CalculationConfig.crr(REPORTING_DATE, irb_permissions=IRBPermissions.full_irb())
    resolver = HierarchyResolver()

    print("\n" + "=" * 90)
    print("COMBINED: All strategies together -> hierarchy + classify + CRM")
    print("=" * 90)

    # Warmup
    resolved = resolver.resolve(raw_data, config)
    classifier = ExposureClassifier()
    classified = classifier.classify(resolved, config)
    crm = CRMProcessor()
    _ = crm.get_crm_adjusted_bundle(classified, config)

    # Baseline
    times = []
    for _ in range(3):
        t0 = time.perf_counter()
        resolved = resolver.resolve(raw_data, config)
        classified = classifier.classify(resolved, config)
        crm_result = crm.get_crm_adjusted_bundle(classified, config)
        times.append(time.perf_counter() - t0)
    print(f"\n  Baseline (hierarchy+classify+CRM): {min(times)*1000:.0f}ms")

    # With strategic collects in hierarchy
    # We simulate what the optimized resolve() would do
    times = []
    for _ in range(3):
        t0 = time.perf_counter()

        # 1. Collect cp_lookup
        cp_lookup, _ = resolver._build_counterparty_lookup(
            raw_data.counterparties, raw_data.org_mappings, raw_data.ratings,
        )
        cp_lookup = CounterpartyLookup(
            counterparties=cp_lookup.counterparties.collect().lazy(),
            parent_mappings=cp_lookup.parent_mappings,
            ultimate_parent_mappings=cp_lookup.ultimate_parent_mappings,
            rating_inheritance=cp_lookup.rating_inheritance.collect().lazy(),
        )

        # 2. Collect unify output
        exposures, _ = resolver._unify_exposures(
            raw_data.loans, raw_data.contingents, raw_data.facilities,
            raw_data.facility_mappings, cp_lookup,
        )
        exposures = exposures.collect().lazy()

        # 3. FX + LTV
        exposures = exposures.with_columns([
            pl.col("currency").alias("original_currency"),
            (pl.col("drawn_amount") + pl.col("interest").fill_null(0.0)
             + pl.col("nominal_amount")).alias("original_amount"),
            pl.lit(None).cast(pl.Float64).alias("fx_rate_applied"),
        ])
        exposures_ltv = resolver._add_collateral_ltv(exposures, raw_data.collateral)

        # 4. Enrich with property coverage (collect for plan break)
        exposures_enriched = resolver._enrich_with_property_coverage(
            exposures_ltv, raw_data.collateral,
        )
        exposures_enriched = exposures_enriched.collect().lazy()

        # 5. Enrich with lending group
        final = resolver._enrich_with_lending_group(
            exposures_enriched, raw_data.lending_mappings,
        )

        # Derive lending_group_totals from enriched exposures
        lending_totals = final.filter(
            pl.col("lending_group_reference").is_not_null()
        ).group_by("lending_group_reference").agg([
            pl.col("drawn_amount").clip(lower_bound=0.0).sum()
            .alias("total_drawn"),
            pl.col("nominal_amount").sum().alias("total_nominal"),
            (pl.col("drawn_amount").clip(lower_bound=0.0)
             + pl.col("nominal_amount")).sum().alias("total_exposure"),
            pl.col("exposure_for_retail_threshold").sum()
            .alias("adjusted_exposure"),
            pl.col("residential_collateral_value").sum()
            .alias("total_residential_coverage"),
            pl.len().alias("exposure_count"),
        ])

        resolved_opt = ResolvedHierarchyBundle(
            exposures=final,
            counterparty_lookup=cp_lookup,
            collateral=raw_data.collateral,
            guarantees=raw_data.guarantees,
            provisions=raw_data.provisions,
            equity_exposures=raw_data.equity_exposures,
            lending_group_totals=lending_totals,
            hierarchy_errors=[],
        )

        classified_opt = classifier.classify(resolved_opt, config)
        crm_result = crm.get_crm_adjusted_bundle(classified_opt, config)
        times.append(time.perf_counter() - t0)

    print(f"  Optimized (collect cp + unify + res): {min(times)*1000:.0f}ms")
    print(f"  Improvement: {(1 - min(times) / min([_ct(pl.LazyFrame({"a": [1]})) for _ in range(1)] or [1])) * 100:.0f}%")

    # Show plan at classifier input
    _m("  Final exposures plan (optimized)", final)


if __name__ == "__main__":
    print("Loading 100K benchmark dataset...")
    dataset = get_or_create_dataset(
        scale="100k",
        n_counterparties=100_000,
        hierarchy_depth=3,
        seed=42,
        force_regenerate=False,
    )
    print("Dataset loaded.\n")

    trace_post_unify_branches(dataset)
    test_collect_intermediates(dataset)
    test_fused_property_collateral(dataset)
    test_deferred_cp_join(dataset)
    test_collateral_precollect(dataset)
    test_combined_best(dataset)
