"""
Compare plan-tree deduplication strategies:
1. .collect().lazy() - current approach (breaks streaming)
2. .cache() - Polars native (optimizer hint)
3. .sink_ipc() + scan_ipc() - streaming-safe materialization
4. No intervention - baseline

Usage:
    PYTHONPATH=. uv run python tests/benchmarks/profile_cache_vs_collect.py
"""
from __future__ import annotations

import tempfile
import time
from datetime import date
from pathlib import Path

import polars as pl

from tests.benchmarks.data_generators import get_or_create_dataset
from tests.benchmarks.test_pipeline_benchmark import create_raw_data_bundle

from rwa_calc.contracts.bundles import CounterpartyLookup, ResolvedHierarchyBundle
from rwa_calc.contracts.config import CalculationConfig, IRBPermissions
from rwa_calc.engine.hierarchy import HierarchyResolver
from rwa_calc.engine.classifier import ExposureClassifier
from rwa_calc.engine.crm.processor import CRMProcessor
from rwa_calc.engine.sa.calculator import SACalculator
from rwa_calc.engine.irb.calculator import IRBCalculator
from rwa_calc.engine.slotting.calculator import SlottingCalculator
from rwa_calc.engine.aggregator import OutputAggregator
from rwa_calc.engine.utils import has_rows


REPORTING_DATE = date(2026, 1, 1)
WARMUP = 1
RUNS = 3


def _pl(lf: pl.LazyFrame) -> int:
    try:
        return len(lf.explain(optimized=True).strip().split("\n"))
    except Exception:
        return -1


def _time_collect(lf: pl.LazyFrame, n: int = 3, engine: str = "cpu") -> float:
    times = []
    for _ in range(n):
        t0 = time.perf_counter()
        _ = lf.collect(engine=engine)
        times.append(time.perf_counter() - t0)
    return min(times)


# ---------------------------------------------------------------------------
# Test 1: Does .cache() reduce plan lines and execution time?
# ---------------------------------------------------------------------------

def test_cache_effect(dataset: dict[str, pl.LazyFrame]) -> None:
    """Test whether .cache() helps with plan-tree deduplication."""
    raw_data = create_raw_data_bundle(dataset)
    config = CalculationConfig.crr(REPORTING_DATE, irb_permissions=IRBPermissions.full_irb())
    resolver = HierarchyResolver()

    print("=" * 90)
    print("TEST 1: .cache() vs .collect().lazy() on hierarchy plan")
    print("=" * 90)

    # Build cp_lookup (collect it since it's small - all strategies agree on this)
    cp_lookup, _ = resolver._build_counterparty_lookup(
        raw_data.counterparties, raw_data.org_mappings, raw_data.ratings,
    )
    cp_lookup = CounterpartyLookup(
        counterparties=cp_lookup.counterparties.collect().lazy(),
        parent_mappings=cp_lookup.parent_mappings,
        ultimate_parent_mappings=cp_lookup.ultimate_parent_mappings,
        rating_inheritance=cp_lookup.rating_inheritance.collect().lazy(),
    )
    exposures_base, _ = resolver._unify_exposures(
        raw_data.loans, raw_data.contingents, raw_data.facilities,
        raw_data.facility_mappings, cp_lookup,
    )

    # --- Approach A: No intervention (baseline) ---
    exposures_a = exposures_base
    exposures_a = exposures_a.with_columns([
        pl.col("currency").alias("original_currency"),
        (pl.col("drawn_amount") + pl.col("interest").fill_null(0.0)
         + pl.col("nominal_amount")).alias("original_amount"),
        pl.lit(None).cast(pl.Float64).alias("fx_rate_applied"),
    ])
    exposures_a = resolver._add_collateral_ltv(exposures_a, raw_data.collateral)
    exposures_a = resolver._enrich_with_property_coverage(exposures_a, raw_data.collateral)
    final_a = resolver._enrich_with_lending_group(
        exposures_a, raw_data.lending_mappings,
    )

    plan_a = _pl(final_a)
    time_a = _time_collect(final_a)
    print(f"\n  A. No intervention:     plan={plan_a:>5} lines  collect={time_a*1000:>8.1f}ms")

    # --- Approach B: .cache() on unify output ---
    exposures_b = exposures_base.cache()
    exposures_b = exposures_b.with_columns([
        pl.col("currency").alias("original_currency"),
        (pl.col("drawn_amount") + pl.col("interest").fill_null(0.0)
         + pl.col("nominal_amount")).alias("original_amount"),
        pl.lit(None).cast(pl.Float64).alias("fx_rate_applied"),
    ])
    exposures_b = resolver._add_collateral_ltv(exposures_b, raw_data.collateral)
    exposures_b = resolver._enrich_with_property_coverage(exposures_b, raw_data.collateral)
    final_b = resolver._enrich_with_lending_group(
        exposures_b, raw_data.lending_mappings,
    )

    plan_b = _pl(final_b)
    time_b = _time_collect(final_b)
    print(f"  B. .cache() on unify:   plan={plan_b:>5} lines  collect={time_b*1000:>8.1f}ms")

    # --- Approach C: .cache() on unify + after property coverage ---
    exposures_c = exposures_base.cache()
    exposures_c = exposures_c.with_columns([
        pl.col("currency").alias("original_currency"),
        (pl.col("drawn_amount") + pl.col("interest").fill_null(0.0)
         + pl.col("nominal_amount")).alias("original_amount"),
        pl.lit(None).cast(pl.Float64).alias("fx_rate_applied"),
    ])
    exposures_c = resolver._add_collateral_ltv(exposures_c, raw_data.collateral)
    exposures_c = resolver._enrich_with_property_coverage(
        exposures_c, raw_data.collateral
    ).cache()
    final_c = resolver._enrich_with_lending_group(
        exposures_c, raw_data.lending_mappings,
    )

    plan_c = _pl(final_c)
    time_c = _time_collect(final_c)
    print(f"  C. .cache() on both:    plan={plan_c:>5} lines  collect={time_c*1000:>8.1f}ms")

    # --- Approach D: .collect().lazy() on unify + after property coverage ---
    exposures_d = exposures_base.collect().lazy()
    exposures_d = exposures_d.with_columns([
        pl.col("currency").alias("original_currency"),
        (pl.col("drawn_amount") + pl.col("interest").fill_null(0.0)
         + pl.col("nominal_amount")).alias("original_amount"),
        pl.lit(None).cast(pl.Float64).alias("fx_rate_applied"),
    ])
    exposures_d = resolver._add_collateral_ltv(exposures_d, raw_data.collateral)
    exposures_d = resolver._enrich_with_property_coverage(
        exposures_d, raw_data.collateral
    ).collect().lazy()
    final_d = resolver._enrich_with_lending_group(
        exposures_d, raw_data.lending_mappings,
    )

    plan_d = _pl(final_d)
    time_d = _time_collect(final_d)
    print(f"  D. .collect().lazy():   plan={plan_d:>5} lines  collect={time_d*1000:>8.1f}ms")

    # Check streaming compatibility
    print("\n  Streaming collect test:")
    for label, lf in [("A (no interv)", final_a),
                       ("B (cache)", final_b),
                       ("C (cache both)", final_c),
                       ("D (collect)", final_d)]:
        try:
            t0 = time.perf_counter()
            _ = lf.collect(engine="streaming")
            t = time.perf_counter() - t0
            print(f"    {label:<20} streaming={t*1000:>8.1f}ms  OK")
        except Exception as e:
            print(f"    {label:<20} streaming FAILED: {e}")


# ---------------------------------------------------------------------------
# Test 2: sink_ipc as streaming-safe materialization
# ---------------------------------------------------------------------------

def test_sink_ipc(dataset: dict[str, pl.LazyFrame]) -> None:
    """Test sink_ipc + scan_ipc as a streaming-compatible plan break."""
    raw_data = create_raw_data_bundle(dataset)
    config = CalculationConfig.crr(REPORTING_DATE, irb_permissions=IRBPermissions.full_irb())
    resolver = HierarchyResolver()

    print("\n" + "=" * 90)
    print("TEST 2: sink_ipc + scan_ipc (streaming-safe plan break)")
    print("=" * 90)

    cp_lookup, _ = resolver._build_counterparty_lookup(
        raw_data.counterparties, raw_data.org_mappings, raw_data.ratings,
    )
    cp_lookup = CounterpartyLookup(
        counterparties=cp_lookup.counterparties.collect().lazy(),
        parent_mappings=cp_lookup.parent_mappings,
        ultimate_parent_mappings=cp_lookup.ultimate_parent_mappings,
        rating_inheritance=cp_lookup.rating_inheritance.collect().lazy(),
    )
    exposures_base, _ = resolver._unify_exposures(
        raw_data.loans, raw_data.contingents, raw_data.facilities,
        raw_data.facility_mappings, cp_lookup,
    )

    with tempfile.TemporaryDirectory() as tmpdir:
        ipc_path = Path(tmpdir) / "exposures.ipc"

        # Sink to IPC (streaming write)
        t0 = time.perf_counter()
        exposures_base.sink_ipc(str(ipc_path))
        sink_time = time.perf_counter() - t0
        print(f"\n  sink_ipc time: {sink_time*1000:.1f}ms")
        print(f"  IPC file size: {ipc_path.stat().st_size / 1024 / 1024:.1f} MB")

        # Scan back
        exposures_ipc = pl.scan_ipc(str(ipc_path))
        plan_ipc = _pl(exposures_ipc)
        print(f"  scan_ipc plan: {plan_ipc} lines")

        # Build full pipeline from scanned IPC
        exposures_ipc = exposures_ipc.with_columns([
            pl.col("currency").alias("original_currency"),
            (pl.col("drawn_amount") + pl.col("interest").fill_null(0.0)
             + pl.col("nominal_amount")).alias("original_amount"),
            pl.lit(None).cast(pl.Float64).alias("fx_rate_applied"),
        ])
        exposures_ipc = resolver._add_collateral_ltv(exposures_ipc, raw_data.collateral)

        enriched_ipc_path = Path(tmpdir) / "enriched_coverage.ipc"
        exposures_enriched = resolver._enrich_with_property_coverage(
            exposures_ipc, raw_data.collateral
        )
        # Sink enriched exposures (with property coverage columns)
        t0 = time.perf_counter()
        exposures_enriched.sink_ipc(str(enriched_ipc_path))
        enriched_sink_time = time.perf_counter() - t0
        print(f"  sink_ipc enriched (property coverage): {enriched_sink_time*1000:.1f}ms")

        exposures_scanned = pl.scan_ipc(str(enriched_ipc_path))

        final_ipc = resolver._enrich_with_lending_group(
            exposures_scanned, raw_data.lending_mappings,
        )

        plan_final = _pl(final_ipc)
        time_final = _time_collect(final_ipc)
        print(f"\n  Final plan: {plan_final} lines  collect: {time_final*1000:.1f}ms")

        # Test streaming collect
        try:
            t0 = time.perf_counter()
            _ = final_ipc.collect(engine="streaming")
            t = time.perf_counter() - t0
            print(f"  Streaming collect: {t*1000:.1f}ms  OK")
        except Exception as e:
            print(f"  Streaming collect FAILED: {e}")

        # Total time including sinks
        total = sink_time + enriched_sink_time + time_final
        print(f"\n  Total (sink + sink + final collect): {total*1000:.1f}ms")


# ---------------------------------------------------------------------------
# Test 3: Full pipeline comparison (all approaches end-to-end)
# ---------------------------------------------------------------------------

def test_full_pipeline_comparison(dataset: dict[str, pl.LazyFrame]) -> None:
    """Compare full pipeline (hierarchy -> classify -> CRM) timing."""
    raw_data = create_raw_data_bundle(dataset)
    config = CalculationConfig.crr(REPORTING_DATE, irb_permissions=IRBPermissions.full_irb())
    resolver = HierarchyResolver()
    classifier = ExposureClassifier()
    crm = CRMProcessor()
    sa_calc = SACalculator()
    irb_calc = IRBCalculator()
    slotting_calc = SlottingCalculator()
    aggregator = OutputAggregator()

    print("\n" + "=" * 90)
    print("TEST 3: Full pipeline comparison (hierarchy -> ... -> final collect)")
    print("=" * 90)

    def run_baseline():
        resolved = resolver.resolve(raw_data, config)
        classified = classifier.classify(resolved, config)
        crm_result = crm.get_crm_adjusted_bundle(classified, config)
        if has_rows(crm_result.irb_exposures):
            irb_b = irb_calc.get_irb_result_bundle(crm_result, config)
            _ = irb_b.results.collect(engine="streaming")
        if crm_result.slotting_exposures is not None and has_rows(crm_result.slotting_exposures):
            sl_b = slotting_calc.get_slotting_result_bundle(crm_result, config)
            _ = sl_b.results.collect(engine="streaming")

    def build_optimised_hierarchy(strategy: str):
        """Build hierarchy with specified strategy for plan breaks."""
        cp_lookup, _ = resolver._build_counterparty_lookup(
            raw_data.counterparties, raw_data.org_mappings, raw_data.ratings,
        )
        cp_lookup = CounterpartyLookup(
            counterparties=cp_lookup.counterparties.collect().lazy(),
            parent_mappings=cp_lookup.parent_mappings,
            ultimate_parent_mappings=cp_lookup.ultimate_parent_mappings,
            rating_inheritance=cp_lookup.rating_inheritance.collect().lazy(),
        )
        exposures, _ = resolver._unify_exposures(
            raw_data.loans, raw_data.contingents, raw_data.facilities,
            raw_data.facility_mappings, cp_lookup,
        )

        if strategy == "collect":
            exposures = exposures.collect().lazy()
        elif strategy == "cache":
            exposures = exposures.cache()

        exposures = exposures.with_columns([
            pl.col("currency").alias("original_currency"),
            (pl.col("drawn_amount") + pl.col("interest").fill_null(0.0)
             + pl.col("nominal_amount")).alias("original_amount"),
            pl.lit(None).cast(pl.Float64).alias("fx_rate_applied"),
        ])
        exposures_ltv = resolver._add_collateral_ltv(exposures, raw_data.collateral)

        exposures_enriched = resolver._enrich_with_property_coverage(
            exposures_ltv, raw_data.collateral,
        )
        if strategy == "collect":
            exposures_enriched = exposures_enriched.collect().lazy()
        elif strategy == "cache":
            exposures_enriched = exposures_enriched.cache()

        final = resolver._enrich_with_lending_group(
            exposures_enriched, raw_data.lending_mappings,
        )

        # Derive lending_group_totals from enriched exposures
        lending_totals = final.filter(
            pl.col("lending_group_reference").is_not_null()
        ).group_by("lending_group_reference").agg([
            pl.col("drawn_amount").clip(lower_bound=0.0).sum().alias("total_drawn"),
            pl.col("nominal_amount").sum().alias("total_nominal"),
            (pl.col("drawn_amount").clip(lower_bound=0.0)
             + pl.col("nominal_amount")).sum().alias("total_exposure"),
            pl.col("exposure_for_retail_threshold").sum()
            .alias("adjusted_exposure"),
            pl.col("residential_collateral_value").sum()
            .alias("total_residential_coverage"),
            pl.len().alias("exposure_count"),
        ])

        return ResolvedHierarchyBundle(
            exposures=final,
            counterparty_lookup=cp_lookup,
            collateral=raw_data.collateral,
            guarantees=raw_data.guarantees,
            provisions=raw_data.provisions,
            equity_exposures=raw_data.equity_exposures,
            lending_group_totals=lending_totals,
            hierarchy_errors=[],
        )

    def run_optimised(strategy: str):
        resolved = build_optimised_hierarchy(strategy)
        classified = classifier.classify(resolved, config)
        crm_result = crm.get_crm_adjusted_bundle(classified, config)
        if has_rows(crm_result.irb_exposures):
            irb_b = irb_calc.get_irb_result_bundle(crm_result, config)
            _ = irb_b.results.collect(engine="streaming")
        if crm_result.slotting_exposures is not None and has_rows(crm_result.slotting_exposures):
            sl_b = slotting_calc.get_slotting_result_bundle(crm_result, config)
            _ = sl_b.results.collect(engine="streaming")

    # Warmup all approaches
    print("\n  Warming up...")
    run_baseline()
    run_optimised("collect")
    run_optimised("cache")

    # Baseline
    times = []
    for _ in range(RUNS):
        t0 = time.perf_counter()
        run_baseline()
        times.append(time.perf_counter() - t0)
    print(f"\n  Baseline (no changes):       {min(times)*1000:>7.0f}ms  (mean {sum(times)/len(times)*1000:.0f}ms)")

    # collect().lazy()
    times = []
    for _ in range(RUNS):
        t0 = time.perf_counter()
        run_optimised("collect")
        times.append(time.perf_counter() - t0)
    print(f"  .collect().lazy():           {min(times)*1000:>7.0f}ms  (mean {sum(times)/len(times)*1000:.0f}ms)")

    # .cache()
    times = []
    for _ in range(RUNS):
        t0 = time.perf_counter()
        run_optimised("cache")
        times.append(time.perf_counter() - t0)
    print(f"  .cache():                    {min(times)*1000:>7.0f}ms  (mean {sum(times)/len(times)*1000:.0f}ms)")


if __name__ == "__main__":
    print("Loading 100K benchmark dataset...")
    dataset = get_or_create_dataset(
        scale="100k",
        n_counterparties=100_000,
        hierarchy_depth=3,
        seed=42,
        force_regenerate=False,
    )
    print("Dataset loaded.\n")

    test_cache_effect(dataset)
    test_sink_ipc(dataset)
    test_full_pipeline_comparison(dataset)
