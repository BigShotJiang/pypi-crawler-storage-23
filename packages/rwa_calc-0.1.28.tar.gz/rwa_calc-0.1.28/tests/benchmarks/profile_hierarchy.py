"""
Profile hierarchy plan complexity to identify plan-tree duplication sources.

Maps which LazyFrames are referenced multiple times, causing plan duplication.

Usage:
    PYTHONPATH=. uv run python tests/benchmarks/profile_hierarchy.py
"""
from __future__ import annotations

import time
from datetime import date

import polars as pl

from tests.benchmarks.data_generators import get_or_create_dataset
from tests.benchmarks.test_pipeline_benchmark import create_raw_data_bundle

from rwa_calc.contracts.config import CalculationConfig, IRBPermissions
from rwa_calc.engine.hierarchy import HierarchyResolver
from rwa_calc.engine.classifier import ExposureClassifier
from rwa_calc.engine.utils import has_required_columns


REPORTING_DATE = date(2026, 1, 1)


def _plan_lines(lf: pl.LazyFrame) -> int:
    try:
        return len(lf.explain(optimized=True).strip().split("\n"))
    except Exception:
        return -1


def _measure(label: str, lf: pl.LazyFrame) -> None:
    """Print plan size and collect time for a LazyFrame."""
    lines = _plan_lines(lf)
    times = []
    for _ in range(3):
        t0 = time.perf_counter()
        _ = lf.collect()
        times.append(time.perf_counter() - t0)
    best = min(times)
    print(f"  {label:<55} plan={lines:>5} lines  collect={best*1000:>8.1f}ms")


def profile_resolve_steps(dataset: dict[str, pl.LazyFrame]) -> None:
    """Profile each step inside HierarchyResolver.resolve()."""
    raw_data = create_raw_data_bundle(dataset)
    config = CalculationConfig.crr(REPORTING_DATE, irb_permissions=IRBPermissions.full_irb())
    resolver = HierarchyResolver()

    print("=" * 90)
    print("HIERARCHY RESOLVE — STEP-BY-STEP PLAN COMPLEXITY")
    print("=" * 90)

    # Step 1: Build counterparty lookup (this does eager graph traversal internally)
    t0 = time.perf_counter()
    cp_lookup, _ = resolver._build_counterparty_lookup(
        raw_data.counterparties, raw_data.org_mappings, raw_data.ratings,
    )
    cp_time = time.perf_counter() - t0
    print(f"\n  _build_counterparty_lookup:           {cp_time*1000:.1f}ms")
    _measure("  cp_lookup.counterparties", cp_lookup.counterparties)
    _measure("  cp_lookup.rating_inheritance", cp_lookup.rating_inheritance)

    # Step 2: Unify exposures
    t0 = time.perf_counter()
    exposures, _ = resolver._unify_exposures(
        raw_data.loans, raw_data.contingents, raw_data.facilities,
        raw_data.facility_mappings, cp_lookup,
    )
    unify_time = time.perf_counter() - t0
    print(f"\n  _unify_exposures (plan build):        {unify_time*1000:.1f}ms")
    _measure("  exposures after unify", exposures)

    # Step 2a: FX / no-FX audit columns
    exposures_fx = exposures.with_columns([
        pl.col("currency").alias("original_currency"),
        (pl.col("drawn_amount") + pl.col("interest").fill_null(0.0)
         + pl.col("nominal_amount")).alias("original_amount"),
        pl.lit(None).cast(pl.Float64).alias("fx_rate_applied"),
    ])
    _measure("  after FX audit columns", exposures_fx)

    # Step 2b: Add collateral LTV
    exposures_ltv = resolver._add_collateral_ltv(exposures_fx, raw_data.collateral)
    _measure("  after _add_collateral_ltv", exposures_ltv)

    # Step 3: Enrich with property coverage (.over() window functions)
    exposures_prop = resolver._enrich_with_property_coverage(
        exposures_ltv, raw_data.collateral,
    )
    _measure("  after _enrich_with_property_coverage", exposures_prop)

    # Step 3b: Enrich with lending group (.over() window functions)
    final_exposures = resolver._enrich_with_lending_group(
        exposures_prop, raw_data.lending_mappings,
    )
    _measure("  FINAL exposures (full hierarchy)", final_exposures)


def profile_unify_internals(dataset: dict[str, pl.LazyFrame]) -> None:
    """Profile _unify_exposures internals to find plan branching."""
    raw_data = create_raw_data_bundle(dataset)
    config = CalculationConfig.crr(REPORTING_DATE, irb_permissions=IRBPermissions.full_irb())
    resolver = HierarchyResolver()

    cp_lookup, _ = resolver._build_counterparty_lookup(
        raw_data.counterparties, raw_data.org_mappings, raw_data.ratings,
    )

    print("\n" + "=" * 90)
    print("_UNIFY_EXPOSURES — INTERNAL PLAN COMPLEXITY")
    print("=" * 90)

    loans = raw_data.loans
    contingents = raw_data.contingents
    facilities = raw_data.facilities
    facility_mappings = raw_data.facility_mappings

    # Source frame sizes
    for name, lf in [("loans", loans), ("contingents", contingents),
                      ("facilities", facilities), ("facility_mappings", facility_mappings)]:
        n = lf.select(pl.len()).collect().item()
        lines = _plan_lines(lf)
        print(f"  Input {name:<25} {n:>10,} rows  plan={lines} lines")

    # Loan unification
    loan_schema = loans.collect_schema()
    loan_cols = set(loan_schema.names())
    has_interest = "interest" in loan_cols
    loans_unified = loans.select([
        pl.col("loan_reference").alias("exposure_reference"),
        pl.lit("loan").alias("exposure_type"),
        pl.col("product_type"),
        pl.col("book_code").cast(pl.String, strict=False),
        pl.col("counterparty_reference"),
        pl.col("value_date"), pl.col("maturity_date"), pl.col("currency"),
        pl.col("drawn_amount"),
        pl.col("interest").fill_null(0.0) if has_interest else pl.lit(0.0).alias("interest"),
        pl.lit(0.0).alias("undrawn_amount"),
        pl.lit(0.0).alias("nominal_amount"),
        pl.col("lgd").cast(pl.Float64, strict=False),
        pl.col("beel").cast(pl.Float64, strict=False).fill_null(0.0) if "beel" in loan_cols else pl.lit(0.0).alias("beel"),
        pl.col("seniority"),
        pl.lit(None).cast(pl.String).alias("risk_type"),
        pl.lit(None).cast(pl.Float64).alias("ccf_modelled"),
        pl.lit(None).cast(pl.Boolean).alias("is_short_term_trade_lc"),
        pl.col("is_buy_to_let").fill_null(False) if "is_buy_to_let" in loan_cols else pl.lit(False).alias("is_buy_to_let"),
    ])
    _measure("loans_unified", loans_unified)

    # Facility root lookup (this collects internally — small)
    t0 = time.perf_counter()
    facility_root_lookup = resolver._build_facility_root_lookup(facility_mappings)
    frl_time = time.perf_counter() - t0
    print(f"\n  _build_facility_root_lookup:           {frl_time*1000:.1f}ms")
    _measure("  facility_root_lookup", facility_root_lookup)

    # Facility undrawn
    facility_undrawn = resolver._calculate_facility_undrawn(
        facilities, loans, contingents, facility_mappings, facility_root_lookup,
    )
    _measure("  facility_undrawn", facility_undrawn)

    # Concat
    cont_cols = set(contingents.collect_schema().names())
    has_bs_type = "bs_type" in cont_cols
    is_drawn = (
        pl.col("bs_type").fill_null("OFB").str.to_uppercase() == "ONB"
        if has_bs_type else pl.lit(False)
    )
    contingents_unified = contingents.select([
        pl.col("contingent_reference").alias("exposure_reference"),
        pl.lit("contingent").alias("exposure_type"),
        pl.col("product_type"),
        pl.col("book_code").cast(pl.String, strict=False),
        pl.col("counterparty_reference"),
        pl.col("value_date"), pl.col("maturity_date"), pl.col("currency"),
        pl.when(is_drawn).then(pl.col("nominal_amount")).otherwise(pl.lit(0.0)).alias("drawn_amount"),
        pl.lit(0.0).alias("interest"),
        pl.lit(0.0).alias("undrawn_amount"),
        pl.when(is_drawn).then(pl.lit(0.0)).otherwise(pl.col("nominal_amount")).alias("nominal_amount"),
        pl.col("lgd").cast(pl.Float64, strict=False),
        pl.col("beel").cast(pl.Float64, strict=False).fill_null(0.0) if "beel" in cont_cols else pl.lit(0.0).alias("beel"),
        pl.col("seniority"),
        pl.when(is_drawn).then(pl.lit(None).cast(pl.String)).otherwise(pl.col("risk_type")).alias("risk_type"),
        pl.when(is_drawn).then(pl.lit(None).cast(pl.Float64)).otherwise(pl.col("ccf_modelled").cast(pl.Float64, strict=False)).alias("ccf_modelled"),
        pl.when(is_drawn).then(pl.lit(None).cast(pl.Boolean)).otherwise(pl.col("is_short_term_trade_lc")).alias("is_short_term_trade_lc"),
        pl.lit(False).alias("is_buy_to_let"),
    ])
    _measure("contingents_unified", contingents_unified)

    exposures = pl.concat([loans_unified, contingents_unified, facility_undrawn], how="diagonal_relaxed")
    _measure("after concat (loans+contingents+undrawn)", exposures)

    # exposure_level_mappings
    mapping_cols = set(facility_mappings.collect_schema().names())
    if "child_type" in mapping_cols:
        type_col = "child_type"
    elif "node_type" in mapping_cols:
        type_col = "node_type"
    else:
        type_col = None

    if type_col is not None:
        exposure_level_mappings = facility_mappings.filter(
            pl.col(type_col).fill_null("").str.to_lowercase() != "facility"
        ).select([
            pl.col("child_reference"),
            pl.col("parent_facility_reference").alias("mapped_parent_facility"),
        ]).unique(subset=["child_reference"], keep="first")
    else:
        exposure_level_mappings = facility_mappings.select([
            pl.col("child_reference"),
            pl.col("parent_facility_reference").alias("mapped_parent_facility"),
        ]).unique(subset=["child_reference"], keep="first")
    _measure("exposure_level_mappings", exposure_level_mappings)

    # Join exposures with mappings
    exposures = exposures.join(
        exposure_level_mappings,
        left_on="exposure_reference",
        right_on="child_reference",
        how="left",
    )
    _measure("after join with exposure_level_mappings", exposures)

    # Add facility hierarchy fields
    schema_names = set(exposures.collect_schema().names())
    if "source_facility_reference" in schema_names:
        exposures = exposures.with_columns([
            pl.coalesce(
                pl.col("mapped_parent_facility"),
                pl.col("source_facility_reference"),
            ).alias("parent_facility_reference"),
        ])
    else:
        exposures = exposures.with_columns([
            pl.col("mapped_parent_facility").alias("parent_facility_reference"),
        ])
    exposures = exposures.with_columns([
        pl.col("parent_facility_reference").is_not_null().alias("exposure_has_parent"),
    ])
    _measure("after parent_facility_reference", exposures)

    # Join with facility root lookup
    exposures = exposures.join(
        facility_root_lookup.select([
            pl.col("child_facility_reference").alias("_frl_child"),
            pl.col("root_facility_reference").alias("_frl_root"),
            pl.col("facility_hierarchy_depth").alias("_frl_depth"),
        ]),
        left_on="parent_facility_reference",
        right_on="_frl_child",
        how="left",
    ).with_columns([
        pl.when(pl.col("_frl_root").is_not_null())
        .then(pl.col("_frl_root"))
        .when(pl.col("parent_facility_reference").is_not_null())
        .then(pl.col("parent_facility_reference"))
        .otherwise(pl.lit(None).cast(pl.String))
        .alias("root_facility_reference"),
        pl.when(pl.col("_frl_depth").is_not_null())
        .then((pl.col("_frl_depth") + 1).cast(pl.Int8))
        .when(pl.col("parent_facility_reference").is_not_null())
        .then(pl.lit(1).cast(pl.Int8))
        .otherwise(pl.lit(0).cast(pl.Int8))
        .alias("facility_hierarchy_depth"),
    ]).drop(["_frl_root", "_frl_depth"])
    _measure("after facility_root_lookup join", exposures)

    # Join with counterparty lookup
    exposures = exposures.join(
        cp_lookup.counterparties.select([
            pl.col("counterparty_reference"),
            pl.col("counterparty_has_parent"),
            pl.col("parent_counterparty_reference"),
            pl.col("ultimate_parent_reference"),
            pl.col("counterparty_hierarchy_depth"),
            pl.col("cqs"), pl.col("pd"),
            pl.col("rating_value"), pl.col("rating_agency"),
            pl.col("rating_inherited"),
            pl.col("rating_source_counterparty"),
            pl.col("rating_inheritance_reason"),
        ]),
        on="counterparty_reference",
        how="left",
    )
    _measure("after counterparty_lookup join (END of _unify)", exposures)


def profile_with_strategic_collects(dataset: dict[str, pl.LazyFrame]) -> None:
    """Test the effect of collecting intermediate frames to cut plan size."""
    raw_data = create_raw_data_bundle(dataset)
    config = CalculationConfig.crr(REPORTING_DATE, irb_permissions=IRBPermissions.full_irb())
    resolver = HierarchyResolver()

    print("\n" + "=" * 90)
    print("STRATEGIC COLLECT EXPERIMENTS")
    print("=" * 90)

    # Baseline: full resolve + classifier collect
    print("\n--- Baseline (no changes) ---")
    t0 = time.perf_counter()
    resolved = resolver.resolve(raw_data, config)
    resolve_time = time.perf_counter() - t0
    print(f"  resolve() plan build: {resolve_time*1000:.1f}ms")

    classifier = ExposureClassifier()
    t0 = time.perf_counter()
    classified = classifier.classify(resolved, config)
    classify_time = time.perf_counter() - t0
    print(f"  classify() (includes collect): {classify_time*1000:.1f}ms")
    print(f"  TOTAL hierarchy+classifier: {(resolve_time + classify_time)*1000:.1f}ms")

    # Experiment 1: Collect cp_lookup before unify
    print("\n--- Exp 1: Collect cp_lookup.counterparties before _unify_exposures ---")
    cp_lookup, _ = resolver._build_counterparty_lookup(
        raw_data.counterparties, raw_data.org_mappings, raw_data.ratings,
    )
    # Collect the counterparties lookup
    from rwa_calc.contracts.bundles import CounterpartyLookup
    t0 = time.perf_counter()
    cp_collected = CounterpartyLookup(
        counterparties=cp_lookup.counterparties.collect().lazy(),
        parent_mappings=cp_lookup.parent_mappings,
        ultimate_parent_mappings=cp_lookup.ultimate_parent_mappings,
        rating_inheritance=cp_lookup.rating_inheritance.collect().lazy(),
    )
    collect_time = time.perf_counter() - t0
    print(f"  Collecting cp_lookup: {collect_time*1000:.1f}ms")

    exposures, _ = resolver._unify_exposures(
        raw_data.loans, raw_data.contingents, raw_data.facilities,
        raw_data.facility_mappings, cp_collected,
    )
    _measure("  exposures after unify (with collected cp)", exposures)

    # Experiment 2: Also collect facility_mappings lookups
    print("\n--- Exp 2: Collect cp_lookup + facility_mappings filter ---")
    facility_mappings = raw_data.facility_mappings
    mapping_cols = set(facility_mappings.collect_schema().names())
    type_col = "child_type" if "child_type" in mapping_cols else (
        "node_type" if "node_type" in mapping_cols else None
    )

    t0 = time.perf_counter()
    if type_col is not None:
        exposure_level_mappings = facility_mappings.filter(
            pl.col(type_col).fill_null("").str.to_lowercase() != "facility"
        ).select([
            pl.col("child_reference"),
            pl.col("parent_facility_reference").alias("mapped_parent_facility"),
        ]).unique(subset=["child_reference"], keep="first").collect().lazy()
    else:
        exposure_level_mappings = facility_mappings.select([
            pl.col("child_reference"),
            pl.col("parent_facility_reference").alias("mapped_parent_facility"),
        ]).unique(subset=["child_reference"], keep="first").collect().lazy()
    elm_collect_time = time.perf_counter() - t0
    print(f"  Collecting exposure_level_mappings: {elm_collect_time*1000:.1f}ms")
    _measure("  exposure_level_mappings (collected)", exposure_level_mappings)

    # Experiment 3: Full pipeline with all strategic collects
    print("\n--- Exp 3: Full pipeline with ALL strategic collects ---")
    t0 = time.perf_counter()

    # Collect cp_lookup
    cp_lookup2, _ = resolver._build_counterparty_lookup(
        raw_data.counterparties, raw_data.org_mappings, raw_data.ratings,
    )
    cp_collected2 = CounterpartyLookup(
        counterparties=cp_lookup2.counterparties.collect().lazy(),
        parent_mappings=cp_lookup2.parent_mappings,
        ultimate_parent_mappings=cp_lookup2.ultimate_parent_mappings,
        rating_inheritance=cp_lookup2.rating_inheritance.collect().lazy(),
    )

    # Run resolve with collected cp_lookup (hack: temporarily swap)
    resolved2 = resolver.resolve(raw_data, config)
    # Can't easily swap, so just measure the classify with pre-collected exposures
    resolve2_time = time.perf_counter() - t0

    # Instead, manually build the pipeline with collects
    t0 = time.perf_counter()
    exposures2, _ = resolver._unify_exposures(
        raw_data.loans, raw_data.contingents, raw_data.facilities,
        raw_data.facility_mappings, cp_collected2,
    )
    # Collect exposures before LTV/lending group
    exposures2 = exposures2.collect().lazy()
    unify_collect_time = time.perf_counter() - t0
    print(f"  Build+collect unify_exposures: {unify_collect_time*1000:.1f}ms")
    _measure("  exposures after unify+collect", exposures2)

    # FX audit columns
    exposures2 = exposures2.with_columns([
        pl.col("currency").alias("original_currency"),
        (pl.col("drawn_amount") + pl.col("interest").fill_null(0.0)
         + pl.col("nominal_amount")).alias("original_amount"),
        pl.lit(None).cast(pl.Float64).alias("fx_rate_applied"),
    ])

    # LTV
    exposures2 = resolver._add_collateral_ltv(exposures2, raw_data.collateral)

    # Property coverage + lending group (.over() window functions)
    exposures2 = resolver._enrich_with_property_coverage(exposures2, raw_data.collateral)
    final2 = resolver._enrich_with_lending_group(exposures2, raw_data.lending_mappings)
    _measure("  FINAL exposures (with strategic collects)", final2)

    # Derive lending group totals for bundle
    lending_totals2 = final2.filter(
        pl.col("lending_group_reference").is_not_null()
    ).group_by("lending_group_reference").agg([
        pl.col("drawn_amount").clip(lower_bound=0.0).sum().alias("total_drawn"),
        pl.col("nominal_amount").sum().alias("total_nominal"),
        (pl.col("drawn_amount").clip(lower_bound=0.0) + pl.col("nominal_amount")).sum().alias("total_exposure"),
        pl.col("exposure_for_retail_threshold").sum().alias("adjusted_exposure"),
        pl.col("residential_collateral_value").sum().alias("total_residential_coverage"),
        pl.len().alias("exposure_count"),
    ])

    # Now classify
    from rwa_calc.contracts.bundles import ResolvedHierarchyBundle
    resolved_bundle = ResolvedHierarchyBundle(
        exposures=final2,
        counterparty_lookup=cp_collected2,
        collateral=raw_data.collateral,
        guarantees=raw_data.guarantees,
        provisions=raw_data.provisions,
        equity_exposures=raw_data.equity_exposures,
        lending_group_totals=lending_totals2,
        hierarchy_errors=[],
    )
    t0 = time.perf_counter()
    classified2 = ExposureClassifier().classify(resolved_bundle, config)
    classify2_time = time.perf_counter() - t0
    print(f"  classify() with pre-collected: {classify2_time*1000:.1f}ms")
    print(f"\n  TOTAL with strategic collects: {(unify_collect_time + classify2_time)*1000:.1f}ms")


if __name__ == "__main__":
    print("Loading 100K benchmark dataset...")
    dataset = get_or_create_dataset(
        scale="100k",
        n_counterparties=100_000,
        hierarchy_depth=3,
        seed=42,
        force_regenerate=False,
    )
    print("Dataset loaded.\n")

    profile_resolve_steps(dataset)
    profile_unify_internals(dataset)
    profile_with_strategic_collects(dataset)
