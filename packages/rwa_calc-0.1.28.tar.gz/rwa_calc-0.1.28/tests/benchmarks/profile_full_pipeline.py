"""
Profile full CRR pipeline at 100K scale to identify bottlenecks.

Profiles each top-level stage with incremental collects to isolate
real compute cost, plus plan complexity at each stage boundary.

Usage:
    PYTHONPATH=. uv run python tests/benchmarks/profile_full_pipeline.py
"""
from __future__ import annotations

import time
from datetime import date

import polars as pl

from tests.benchmarks.data_generators import get_or_create_dataset
from tests.benchmarks.test_pipeline_benchmark import create_raw_data_bundle

from rwa_calc.contracts.config import CalculationConfig, IRBPermissions
from rwa_calc.engine.hierarchy import HierarchyResolver
from rwa_calc.engine.classifier import ExposureClassifier
from rwa_calc.engine.crm.processor import CRMProcessor
from rwa_calc.engine.sa.calculator import SACalculator
from rwa_calc.engine.irb.calculator import IRBCalculator
from rwa_calc.engine.slotting.calculator import SlottingCalculator
from rwa_calc.engine.equity.calculator import EquityCalculator
from rwa_calc.engine.aggregator import OutputAggregator
from rwa_calc.engine.utils import has_rows
from rwa_calc.domain.enums import ApproachType


REPORTING_DATE = date(2026, 1, 1)
WARMUP_RUNS = 1
TIMED_RUNS = 3


def _plan_lines(lf: pl.LazyFrame) -> int:
    """Count lines in the optimized query plan."""
    try:
        return len(lf.explain(optimized=True).strip().split("\n"))
    except Exception:
        return -1


def _print_timings(timings: dict[str, list[float]], total_key: str = "TOTAL") -> None:
    """Print timing results with percentages."""
    if total_key in timings:
        total_mean = sum(timings[total_key]) / len(timings[total_key])
    else:
        total_mean = sum(sum(t) / len(t) for t in timings.values())

    print(f"\n{'Stage':<40} {'Min':>10} {'Mean':>10} {'Max':>10} {'%Total':>8}")
    print("-" * 80)

    for stage, times in timings.items():
        mean = sum(times) / len(times)
        mn = min(times)
        mx = max(times)
        pct = (mean / total_mean) * 100 if total_mean > 0 else 0
        marker = " <--" if pct > 20.0 and stage != total_key else ""
        bold = ">>> " if stage == total_key else "    "
        print(
            f"{bold}{stage:<36} {mn*1000:>9.1f}ms {mean*1000:>9.1f}ms "
            f"{mx*1000:>9.1f}ms {pct:>7.1f}%{marker}"
        )


def profile_end_to_end(dataset: dict[str, pl.LazyFrame]) -> None:
    """Profile the full pipeline as the benchmark runs it."""
    raw_data = create_raw_data_bundle(dataset)
    config = CalculationConfig.crr(REPORTING_DATE, irb_permissions=IRBPermissions.full_irb())

    from tests.benchmarks.test_pipeline_benchmark import create_pipeline as create_bench_pipeline
    pipeline = create_bench_pipeline(raw_data)

    print("=" * 80)
    print("END-TO-END PIPELINE (as benchmark runs it)")
    print("=" * 80)

    # Warmup
    for _ in range(WARMUP_RUNS):
        result = pipeline.run(config)
        if result.sa_results is not None:
            _ = result.sa_results.collect(engine="streaming")
        if result.irb_results is not None:
            _ = result.irb_results.collect(engine="streaming")

    times = []
    for _ in range(TIMED_RUNS):
        t0 = time.perf_counter()
        result = pipeline.run(config)
        if result.sa_results is not None:
            _ = result.sa_results.collect(engine="streaming")
        if result.irb_results is not None:
            _ = result.irb_results.collect(engine="streaming")
        times.append(time.perf_counter() - t0)

    mean = sum(times) / len(times)
    print(f"\n  Min: {min(times)*1000:.0f}ms  Mean: {mean*1000:.0f}ms  Max: {max(times)*1000:.0f}ms")


def profile_stages_incremental(dataset: dict[str, pl.LazyFrame]) -> None:
    """
    Profile each pipeline stage with incremental collects.

    Collects after each stage so the timing reflects real compute cost
    of that stage alone (no plan-tree duplication across stages).
    """
    raw_data = create_raw_data_bundle(dataset)
    config = CalculationConfig.crr(REPORTING_DATE, irb_permissions=IRBPermissions.full_irb())

    hierarchy_resolver = HierarchyResolver()
    classifier = ExposureClassifier()
    crm = CRMProcessor()
    sa_calc = SACalculator()
    irb_calc = IRBCalculator()
    slotting_calc = SlottingCalculator()
    equity_calc = EquityCalculator()
    aggregator = OutputAggregator()

    print("\n" + "=" * 80)
    print("STAGE-BY-STAGE INCREMENTAL PROFILE (100K, CRR + full IRB)")
    print("Each stage is collected before the next to isolate real cost.")
    print("=" * 80)

    # Warmup
    for _ in range(WARMUP_RUNS):
        resolved = hierarchy_resolver.resolve(raw_data, config)
        classified = classifier.classify(resolved, config)
        crm_adjusted = crm.get_crm_adjusted_bundle(classified, config)
        if has_rows(crm_adjusted.sa_exposures):
            sa_bundle = sa_calc.get_sa_result_bundle(crm_adjusted, config)
            _ = sa_bundle.results.collect(engine="streaming")
        if has_rows(crm_adjusted.irb_exposures):
            irb_bundle = irb_calc.get_irb_result_bundle(crm_adjusted, config)
            _ = irb_bundle.results.collect(engine="streaming")

    timings: dict[str, list[float]] = {
        "1. hierarchy_resolve": [],
        "2. classifier": [],
        "3. crm_processor": [],
        "4. sa_calculator + collect": [],
        "5. irb_calculator + collect": [],
        "6. slotting_calculator + collect": [],
        "7. aggregator + collect": [],
        "TOTAL": [],
    }

    for run in range(TIMED_RUNS):
        t_total = time.perf_counter()

        # Stage 1: Hierarchy
        t0 = time.perf_counter()
        resolved = hierarchy_resolver.resolve(raw_data, config)
        timings["1. hierarchy_resolve"].append(time.perf_counter() - t0)

        # Stage 2: Classifier
        t0 = time.perf_counter()
        classified = classifier.classify(resolved, config)
        timings["2. classifier"].append(time.perf_counter() - t0)

        # Stage 3: CRM
        t0 = time.perf_counter()
        crm_adjusted = crm.get_crm_adjusted_bundle(classified, config)
        timings["3. crm_processor"].append(time.perf_counter() - t0)

        # Stage 4: SA Calculator + collect
        t0 = time.perf_counter()
        if has_rows(crm_adjusted.sa_exposures):
            sa_bundle = sa_calc.get_sa_result_bundle(crm_adjusted, config)
            _ = sa_bundle.results.collect(engine="streaming")
        timings["4. sa_calculator + collect"].append(time.perf_counter() - t0)

        # Stage 5: IRB Calculator + collect
        t0 = time.perf_counter()
        if has_rows(crm_adjusted.irb_exposures):
            irb_bundle = irb_calc.get_irb_result_bundle(crm_adjusted, config)
            _ = irb_bundle.results.collect(engine="streaming")
        timings["5. irb_calculator + collect"].append(time.perf_counter() - t0)

        # Stage 6: Slotting Calculator + collect
        t0 = time.perf_counter()
        if crm_adjusted.slotting_exposures is not None and has_rows(
            crm_adjusted.slotting_exposures
        ):
            slotting_bundle = slotting_calc.get_slotting_result_bundle(crm_adjusted, config)
            _ = slotting_bundle.results.collect(engine="streaming")
        timings["6. slotting_calculator + collect"].append(time.perf_counter() - t0)

        # Stage 7: Aggregator + collect
        t0 = time.perf_counter()
        agg_result = aggregator.aggregate_with_audit(
            sa_bundle=sa_bundle if has_rows(crm_adjusted.sa_exposures) else None,
            irb_bundle=irb_bundle if has_rows(crm_adjusted.irb_exposures) else None,
            slotting_bundle=(
                slotting_bundle
                if crm_adjusted.slotting_exposures is not None
                and has_rows(crm_adjusted.slotting_exposures)
                else None
            ),
            config=config,
        )
        _ = agg_result.results.collect(engine="streaming")
        timings["7. aggregator + collect"].append(time.perf_counter() - t0)

        timings["TOTAL"].append(time.perf_counter() - t_total)

    _print_timings(timings)


def profile_plan_complexity(dataset: dict[str, pl.LazyFrame]) -> None:
    """Show plan complexity at each stage boundary."""
    raw_data = create_raw_data_bundle(dataset)
    config = CalculationConfig.crr(REPORTING_DATE, irb_permissions=IRBPermissions.full_irb())

    hierarchy_resolver = HierarchyResolver()
    classifier = ExposureClassifier()
    crm = CRMProcessor()
    sa_calc = SACalculator()
    irb_calc = IRBCalculator()

    print("\n" + "=" * 80)
    print("QUERY PLAN COMPLEXITY AT STAGE BOUNDARIES")
    print("=" * 80)

    resolved = hierarchy_resolver.resolve(raw_data, config)
    print(f"\n  After hierarchy:   exposures plan = {_plan_lines(resolved.exposures)} lines")

    classified = classifier.classify(resolved, config)
    print(f"  After classifier:  all_exposures plan = {_plan_lines(classified.all_exposures)} lines")

    crm_adjusted = crm.get_crm_adjusted_bundle(classified, config)
    sa_lines = _plan_lines(crm_adjusted.sa_exposures)
    irb_lines = _plan_lines(crm_adjusted.irb_exposures)
    sl_lines = (
        _plan_lines(crm_adjusted.slotting_exposures)
        if crm_adjusted.slotting_exposures is not None
        else 0
    )
    print(f"  After CRM:         sa_exposures plan = {sa_lines} lines")
    print(f"                     irb_exposures plan = {irb_lines} lines")
    print(f"                     slotting_exposures plan = {sl_lines} lines")

    if has_rows(crm_adjusted.sa_exposures):
        sa_bundle = sa_calc.get_sa_result_bundle(crm_adjusted, config)
        print(f"  After SA calc:     results plan = {_plan_lines(sa_bundle.results)} lines")

    if has_rows(crm_adjusted.irb_exposures):
        irb_bundle = irb_calc.get_irb_result_bundle(crm_adjusted, config)
        print(f"  After IRB calc:    results plan = {_plan_lines(irb_bundle.results)} lines")


def profile_crm_substeps(dataset: dict[str, pl.LazyFrame]) -> None:
    """Profile CRM sub-steps with incremental collects."""
    raw_data = create_raw_data_bundle(dataset)
    config = CalculationConfig.crr(REPORTING_DATE, irb_permissions=IRBPermissions.full_irb())

    hierarchy_resolver = HierarchyResolver()
    classifier = ExposureClassifier()
    crm = CRMProcessor()

    resolved = hierarchy_resolver.resolve(raw_data, config)
    classified = classifier.classify(resolved, config)
    data = classified

    has_provisions = False  # Empty provisions in benchmark
    has_collateral = True
    has_guarantees = False  # Empty guarantees in benchmark

    n_exposures = data.all_exposures.select(pl.len()).collect().item()
    n_coll = data.collateral.select(pl.len()).collect().item() if has_collateral else 0

    print("\n" + "=" * 80)
    print(f"CRM SUB-STEPS (100K: {n_exposures:,} exposures, {n_coll:,} collateral)")
    print("=" * 80)

    # Warmup
    for _ in range(WARMUP_RUNS):
        _ = crm.get_crm_adjusted_bundle(classified, config)

    timings: dict[str, list[float]] = {
        "1. resolve_provisions": [],
        "2. apply_ccf": [],
        "3. initialize_ead": [],
        "4. apply_collateral": [],
        "5. apply_guarantees": [],
        "6. finalize_ead + audit": [],
        "7. collect + split": [],
        "CRM TOTAL": [],
    }

    for _ in range(TIMED_RUNS):
        t_total = time.perf_counter()
        exposures = data.all_exposures

        t0 = time.perf_counter()
        if has_provisions:
            exposures = crm.resolve_provisions(exposures, data.provisions, config)
        timings["1. resolve_provisions"].append(time.perf_counter() - t0)

        t0 = time.perf_counter()
        exposures = crm._apply_ccf(exposures, config)
        timings["2. apply_ccf"].append(time.perf_counter() - t0)

        t0 = time.perf_counter()
        exposures = crm._initialize_ead(exposures)
        timings["3. initialize_ead"].append(time.perf_counter() - t0)

        t0 = time.perf_counter()
        if has_collateral:
            exposures = crm.apply_collateral(exposures, data.collateral, config)
        else:
            exposures = crm._apply_firb_supervisory_lgd_no_collateral(exposures)
        timings["4. apply_collateral"].append(time.perf_counter() - t0)

        t0 = time.perf_counter()
        if has_guarantees:
            exposures = crm.apply_guarantees(
                exposures, data.guarantees,
                data.counterparty_lookup.counterparties, config,
                data.counterparty_lookup.rating_inheritance,
            )
        timings["5. apply_guarantees"].append(time.perf_counter() - t0)

        t0 = time.perf_counter()
        exposures = crm._finalize_ead(exposures)
        exposures = crm._add_crm_audit(exposures)
        timings["6. finalize_ead + audit"].append(time.perf_counter() - t0)

        t0 = time.perf_counter()
        collected = exposures.collect()
        exposures_lf = collected.lazy()
        sa_exp = exposures_lf.filter(pl.col("approach") == ApproachType.SA.value)
        irb_exp = exposures_lf.filter(
            (pl.col("approach") == ApproachType.FIRB.value)
            | (pl.col("approach") == ApproachType.AIRB.value)
        )
        slotting_exp = exposures_lf.filter(
            pl.col("approach") == ApproachType.SLOTTING.value
        )
        _ = sa_exp.select(pl.len()).collect().item()
        _ = irb_exp.select(pl.len()).collect().item()
        _ = slotting_exp.select(pl.len()).collect().item()
        timings["7. collect + split"].append(time.perf_counter() - t0)

        timings["CRM TOTAL"].append(time.perf_counter() - t_total)

    _print_timings(timings, total_key="CRM TOTAL")


def profile_row_counts(dataset: dict[str, pl.LazyFrame]) -> None:
    """Show row counts at each stage to understand data volumes."""
    raw_data = create_raw_data_bundle(dataset)
    config = CalculationConfig.crr(REPORTING_DATE, irb_permissions=IRBPermissions.full_irb())

    hierarchy_resolver = HierarchyResolver()
    classifier = ExposureClassifier()
    crm = CRMProcessor()

    print("\n" + "=" * 80)
    print("ROW COUNTS AT EACH STAGE")
    print("=" * 80)

    # Input tables
    for name, lf in [
        ("counterparties", raw_data.counterparties),
        ("facilities", raw_data.facilities),
        ("loans", raw_data.loans),
        ("contingents", raw_data.contingents),
        ("collateral", raw_data.collateral),
        ("ratings", raw_data.ratings),
        ("facility_mappings", raw_data.facility_mappings),
        ("org_mappings", raw_data.org_mappings),
    ]:
        n = lf.select(pl.len()).collect().item()
        print(f"  Input {name:<25} {n:>10,} rows")

    resolved = hierarchy_resolver.resolve(raw_data, config)
    n = resolved.exposures.select(pl.len()).collect().item()
    print(f"\n  After hierarchy:    exposures    {n:>10,} rows")

    classified = classifier.classify(resolved, config)
    n = classified.all_exposures.select(pl.len()).collect().item()
    print(f"  After classifier:   all_exposures{n:>10,} rows")

    crm_adjusted = crm.get_crm_adjusted_bundle(classified, config)
    sa_n = crm_adjusted.sa_exposures.select(pl.len()).collect().item()
    irb_n = crm_adjusted.irb_exposures.select(pl.len()).collect().item()
    sl_n = (
        crm_adjusted.slotting_exposures.select(pl.len()).collect().item()
        if crm_adjusted.slotting_exposures is not None
        else 0
    )
    eq_n = (
        crm_adjusted.equity_exposures.select(pl.len()).collect().item()
        if crm_adjusted.equity_exposures is not None
        else 0
    )
    print(f"  After CRM:          sa_exposures {sa_n:>10,} rows")
    print(f"                      irb_exposures{irb_n:>10,} rows")
    print(f"                      slotting     {sl_n:>10,} rows")
    print(f"                      equity       {eq_n:>10,} rows")
    print(f"                      TOTAL        {sa_n + irb_n + sl_n + eq_n:>10,} rows")


if __name__ == "__main__":
    print("Loading 100K benchmark dataset...")
    dataset = get_or_create_dataset(
        scale="100k",
        n_counterparties=100_000,
        hierarchy_depth=3,
        seed=42,
        force_regenerate=False,
    )
    print("Dataset loaded.\n")

    profile_row_counts(dataset)
    profile_plan_complexity(dataset)
    profile_end_to_end(dataset)
    profile_stages_incremental(dataset)
    profile_crm_substeps(dataset)
