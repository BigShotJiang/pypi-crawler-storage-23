"""status — Display account info."""

from . import Command, register

cmd = register(Command(
    name="status",
    description="Display account info: username, plan, storage, and file count.",
))


def run(shell, args_str):
    from cli.session import api_get, check_auth
    from cli.ui import spinner

    if not check_auth(shell):
        return

    with spinner("Loading..."):
        resp = api_get("/api/v1/auth/status/")
    if resp.status_code != 200:
        shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
        return

    d = resp.json()

    def _fmt(n):
        for unit in ("B", "KB", "MB", "GB"):
            if n < 1024:
                return f"{n:.1f} {unit}"
            n /= 1024
        return f"{n:.1f} TB"

    shell.poutput(f"user:     @{d['username']}")
    shell.poutput(f"email:    {d['email']}")
    shell.poutput(f"plan:     {d['plan']}")
    shell.poutput(f"storage:  {_fmt(d['storage_used'])} / {_fmt(d['storage_limit'])}")
    shell.poutput(f"keys:     {d['key_count']}")
