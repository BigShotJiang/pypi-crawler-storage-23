"""get — Download a file to disk."""

import os

from . import Arg, Command, register

cmd = register(Command(
    name="get",
    description="Download a file to disk.",
    args=(
        Arg("ref",
            "Filename, drive key, or full URL.",
            required=True),
        Arg("--key",
            "Treat ref as a drive key, skip filename lookup.",
            type="bool"),
        Arg("--name",
            "Save with a different filename instead of the original."),
        Arg("--password",
            "Password for a protected file.",
            type="passphrase"),
        Arg("--encryption-key",
            "Passphrase for client-side encrypted content. Decrypts after download.",
            type="passphrase"),
        Arg("--fork",
            "Fork the file into your account instead of downloading.",
            type="bool"),
        Arg("--stdout",
            "Write content to stdout instead of a file.",
            type="bool"),
    ),
))


def run(shell, args_str):
    from cli.commands import parse_args
    from cli.session import api_get, api_post, check_auth, resolve_ref
    from cli.ui import download_to_file, spinner

    if not check_auth(shell):
        return

    flags, positional = parse_args(cmd, args_str)
    ref = positional[0]

    # Strip full URL down to bare key
    if ref.startswith("http"):
        ref = ref.rstrip("/").rsplit("/", 1)[-1]

    key = ref if flags.get("key") else resolve_ref(shell, ref)

    if flags.get("fork"):
        with spinner("Forking..."):
            resp = api_post(f"/api/v1/keys/{key}/fork/",
                            data={"folder": shell.cwd.strip("/")})
        if resp.status_code in (200, 201):
            d = resp.json()
            shell.poutput(f"forked: {d['url']}  ({d.get('filename', key)})")
        else:
            shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
        return

    extra = {}
    if flags.get("password"):
        extra["headers"] = {"X-Drop-Password": flags["password"]}

    with spinner("Resolving..."):
        resp = api_get(f"/api/v1/keys/{key}/", **extra)
    if resp.status_code != 200:
        shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
        return

    data = resp.json()
    download_url = data.get("download_url")
    if not download_url:
        shell.poutput("error: no download URL available")
        return

    filename = flags.get("name") or data.get("filename", key)

    with spinner("Downloading..."):
        r = api_get(download_url)
    if r.status_code != 200:
        shell.poutput(f"error: download failed ({r.status_code})")
        return

    # Decrypt if needed
    if data.get("encrypted"):
        enc_key = flags.get("encryption_key")
        if not enc_key:
            from cli.keystore import get_key
            enc_key = get_key(key)
        if not enc_key:
            shell.poutput("file is encrypted — supply --encryption-key <passphrase> to decrypt")
            shell.poutput(f"saving ciphertext as {filename} — WARNING: content is encrypted")
        else:
            try:
                from cli.crypto import decrypt
                content = decrypt(r.text, enc_key)
                if flags.get("stdout"):
                    import sys
                    sys.stdout.write(content)
                    return
                dest = os.path.join(shell.local_cwd, filename)
                with open(dest, "w") as f:
                    f.write(content)
                shell.poutput(f"saved: {dest}")
                return
            except ValueError:
                from cli.keystore import remove_key
                remove_key(key)
                shell.poutput("error: decryption failed — wrong passphrase? Removed saved key.")
                return

    if flags.get("stdout"):
        import sys
        for chunk in r.iter_content(8192):
            sys.stdout.buffer.write(chunk)
        return

    dest = os.path.join(shell.local_cwd, filename)
    size = download_to_file(r, dest, filename=filename)
    shell.poutput(f"saved: {dest} ({size} bytes)")
