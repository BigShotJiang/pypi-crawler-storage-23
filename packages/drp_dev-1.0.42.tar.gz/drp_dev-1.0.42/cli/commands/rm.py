"""rm — Delete a file or folder."""

from . import Arg, Command, register

cmd = register(Command(
    name="rm",
    description="Delete a file or folder.",
    args=(
        Arg("ref",
            "Filename, drive key, or folder name.",
            required=True),
        Arg("--key",
            "Treat ref as a drive key, skip filename lookup.",
            type="bool"),
        Arg("-r/--recursive",
            "Required to delete a non-empty folder.",
            type="bool"),
    ),
))


def run(shell, args_str):
    from cli.commands import parse_args
    from cli.session import api_delete, api_get, check_auth, resolve_ref
    from cli.ui import spinner

    if not check_auth(shell):
        return

    flags, positional = parse_args(cmd, args_str)
    ref = positional[0]
    recursive = flags.get("recursive", False)

    # Check if ref is a folder in current cwd first
    path = shell.cwd.strip("/")
    with spinner("Resolving..."):
        ls_resp = api_get("/api/v1/folders/", params={"path": path} if path else {})

    if ls_resp.status_code == 200:
        for folder in ls_resp.json().get("folders", []):
            if folder.get("name") == ref or folder.get("slug") == ref:
                url = f"/api/v1/folders/{folder['id']}/"
                if recursive:
                    url += "?recursive=true"
                with spinner("Deleting folder..."):
                    resp = api_delete(url)
                if resp.status_code == 200:
                    shell.poutput(f"deleted folder: {ref}")
                else:
                    shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
                return

    key = ref if flags.get("key") else resolve_ref(shell, ref)

    with spinner("Deleting..."):
        resp = api_delete(f"/api/v1/keys/{key}/")
    if resp.status_code == 200:
        from cli.keystore import remove_key
        remove_key(key)
        shell.poutput(f"deleted: {ref}")
    else:
        shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
