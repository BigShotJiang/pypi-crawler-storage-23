"""cd — Change directory, local or into the drive via @username."""

from . import Arg, Command, register

cmd = register(Command(
    name="cd",
    description="Change directory. Use @username to enter the drive.",
    aliases=("chdir",),
    args=(
        Arg("path",
            "Local path, .., ~, /, or @username[/subfolder] for drive.",
            required=True),
    ),
))


def run(shell, args_str):
    import os
    from cli.commands import parse_args

    _, positional = parse_args(cmd, args_str)
    target = positional[0]

    new_path = _resolve_path(shell, target)

    if _is_drive_path(new_path, shell.username):
        _cd_drive(shell, new_path)
    else:
        _cd_local(shell, new_path)


def _resolve_path(shell, target: str) -> str:
    """Resolve *target* relative to the current unified path."""
    import os

    current = shell.unified_cwd

    if target == "~":
        return os.path.expanduser("~")

    if target.startswith("~/"):
        return os.path.expanduser(target)

    if target.startswith("/"):
        return target

    # Relative resolution — walk segment by segment
    parts = current.rstrip("/").split("/")
    for segment in target.split("/"):
        if segment == "..":
            if parts:
                parts.pop()
        elif segment and segment != ".":
            parts.append(segment)

    return "/".join(parts) or "/"


def _is_drive_path(path: str, username: str) -> bool:
    """True if *path* passes through @username."""
    return f"@{username}" in path.split("/")


def _drive_subpath(path: str, username: str) -> str:
    """Return the drive-relative subpath after @username."""
    parts = path.split("/")
    idx = parts.index(f"@{username}")
    return "/".join(parts[idx + 1:])


def _cd_drive(shell, new_path: str):
    from cli.session import api_get, check_auth
    from cli.ui import spinner

    if not check_auth(shell):
        return

    subpath = _drive_subpath(new_path, shell.username)
    if subpath:
        with spinner("Checking..."):
            resp = api_get("/api/v1/folders/", params={"path": subpath})
        if resp.status_code != 200:
            shell.poutput(f"folder not found: {subpath}")
            return

    shell.unified_cwd = new_path
    shell._update_prompt()


def _cd_local(shell, new_path: str):
    import os

    expanded = os.path.expanduser(new_path)
    if not os.path.isdir(expanded):
        shell.poutput(f"not a directory: {new_path}")
        return

    os.chdir(expanded)
    shell.local_cwd = expanded
    shell.unified_cwd = expanded
    shell._update_prompt()