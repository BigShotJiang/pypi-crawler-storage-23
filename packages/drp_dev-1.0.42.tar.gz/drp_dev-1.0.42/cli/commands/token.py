"""token — Manage account-level API tokens."""

from . import Arg, Command, register

cmd = register(Command(
    name="token",
    description="Manage account-level API tokens for scripts and integrations.",
    args=(
        Arg("action",
            "Subcommand: create, list, or revoke.",
            required=True, choices=("create", "list", "revoke")),
        Arg("target",
            "Token ID (for revoke)."),
        Arg("--label",
            "Human-readable label for a new token."),
    ),
))


def run(shell, args_str):
    from cli.commands import parse_args
    from cli.session import api_delete, api_get, api_post, check_auth
    from cli.ui import spinner

    if not check_auth(shell):
        return

    flags, positional = parse_args(cmd, args_str)
    action = positional[0]

    if action == "list":
        with spinner("Loading tokens..."):
            resp = api_get("/api/v1/tokens/")
        if resp.status_code != 200:
            shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
            return
        tokens = resp.json().get("tokens", [])
        if not tokens:
            shell.poutput("no tokens")
            return
        for t in tokens:
            label = t.get("label") or "(no label)"
            created = str(t.get("created_at", ""))[:10]
            shell.poutput(f"  #{t['id']}  {label:<20s}  created: {created}")

    elif action == "create":
        with spinner("Creating token..."):
            resp = api_post("/api/v1/tokens/", json={"label": flags.get("label", "")})
        if resp.status_code in (200, 201):
            d = resp.json()
            shell.poutput(f"token: {d['token']}")
            shell.poutput(f"id:    {d['id']}")
            shell.poutput("(save this — it won't be shown again)")
        else:
            shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")

    elif action == "revoke":
        if len(positional) < 2:
            shell.poutput("usage: token revoke <TOKEN_ID>")
            return
        token_id = positional[1]
        with spinner("Revoking..."):
            resp = api_delete(f"/api/v1/tokens/{token_id}/")
        if resp.status_code == 200:
            shell.poutput(f"revoked token #{token_id}")
        else:
            shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")

    else:
        shell.poutput(f"unknown action: {action} (use create, list, or revoke)")
