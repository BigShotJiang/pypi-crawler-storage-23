"""ls — List files and folders."""

import os

from . import Arg, Command, register

cmd = register(Command(
    name="ls",
    description="List files and folders at the current location.",
    args=(
        Arg("path",
            "Path to list. Defaults to current location.",
            default="."),
        Arg("--export",
            "Output as JSON for scripting.",
            type="bool"),
        Arg("--sort",
            "Sort by field.",
            choices=("name", "size", "exp")),
    ),
))


def run(shell, args_str):
    import json as _json
    from cli.commands import parse_args
    from cli.session import api_get, check_auth
    from cli.ui import spinner

    flags, positional = parse_args(cmd, args_str)
    export = flags.get("export", False)
    sort_field = flags.get("sort")
    target = positional[0] if positional and positional[0] != "." else None

    # Local listing
    from cli.shell import _in_drive
    if not _in_drive(shell.unified_cwd, shell.username):
        local_path = target or shell.local_cwd
        try:
            entries = sorted(os.scandir(local_path), key=lambda e: e.name)
            for e in entries:
                if e.is_dir():
                    shell.poutput(f"  \033[34m{e.name}/\033[0m")
                else:
                    size = e.stat().st_size
                    shell.poutput(f"  {e.name:<30s}  {_fmt_size(size):>8s}")
        except PermissionError:
            shell.poutput(f"permission denied: {local_path}")
        except FileNotFoundError:
            shell.poutput(f"not found: {local_path}")
        return

    # Drive listing
    if not check_auth(shell):
        return

    if target:
        path = target.strip("/")
    else:
        path = shell.cwd.strip("/")

    with spinner("Listing..."):
        resp = api_get("/api/v1/folders/", params={"path": path} if path else {})
    if resp.status_code != 200:
        shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
        return

    data = resp.json()
    folders = data.get("folders", [])
    files = data.get("files", [])

    if export:
        shell.poutput(_json.dumps(data, indent=2, default=str))
        return

    if sort_field == "name":
        folders.sort(key=lambda f: f["name"])
        files.sort(key=lambda f: f["filename"])
    elif sort_field == "size":
        files.sort(key=lambda f: f.get("filesize", 0), reverse=True)

    if not folders and not files:
        shell.poutput("(empty)")
        return

    for f in folders:
        shell.poutput(f"  \033[34m{f['name']}/\033[0m")
    for f in files:
        size = f.get("filesize", 0)
        key = f.get("key", "")
        enc = " \033[33m[enc]\033[0m" if f.get("encrypted") else ""
        shell.poutput(f"  {f['filename']:<30s}  {_fmt_size(size):>8s}  {key}{enc}")


def _fmt_size(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f}{unit}" if unit == "B" else f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}TB"
