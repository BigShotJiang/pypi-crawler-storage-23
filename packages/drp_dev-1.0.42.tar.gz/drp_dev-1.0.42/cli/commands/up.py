"""up — Upload a file, directory, glob, or text."""

from . import Arg, Command, register

cmd = register(Command(
    name="up",
    description="Upload a file, directory, glob, or text.",
    args=(
        Arg("target",
            "Local file path, glob (\"*.py\"), - for stdin, or literal text with --text.",
            required=True, type="path"),
        Arg("--key",
            "Custom key. Format: [a-zA-Z0-9_-]{1,64}. Rejected if taken."),
        Arg("--name",
            "Override the filename for text uploads."),
        Arg("--expires",
            "Key expiry: 7d, 24h, 30m. Capped at plan max.",
            type="duration"),
        Arg("--publish",
            "List the file on /explore/ and your profile.",
            type="bool"),
        Arg("--burn",
            "Invalidate the key after the first view.",
            type="bool"),
        Arg("--password",
            "Require a password to access the key.",
            type="passphrase"),
        Arg("--encryption-key",
            "Client-side AES-256-GCM encryption. Server never sees plaintext.",
            type="passphrase"),
        Arg("--tag",
            "Add a tag. Repeatable: --tag python --tag snippet.",
            repeatable=True),
        Arg("--text",
            "Treat target as literal text content, not a filename.",
            type="bool"),
    ),
))


def run(shell, args_str):
    import glob
    import os
    from cli.commands import parse_args
    from cli.session import api_post, check_auth
    from cli.ui import spinner, upload_file as ui_upload

    if not check_auth(shell):
        return

    flags, positional = parse_args(cmd, args_str)
    target = " ".join(positional)
    folder = shell.cwd.strip("/") or ""

    if flags.get("text") or target == "-":
        if target == "-":
            import sys
            text = sys.stdin.read()
        else:
            text = target

        enc_key = flags.get("encryption_key")
        if enc_key:
            from cli.crypto import encrypt
            text = encrypt(text, enc_key)

        payload = {
            "text": text,
            "folder": folder,
            "key": flags.get("key", ""),
            "name": flags.get("name", ""),
            "expires": flags.get("expires", ""),
            "burn": flags.get("burn", False),
            "publish": flags.get("publish", False),
            "password": flags.get("password", ""),
            "tags": flags.get("tag", []),
            "encrypted": bool(enc_key),
        }
        with spinner("Uploading..."):
            resp = api_post("/api/v1/keys/", json=payload)
        if resp.status_code in (200, 201):
            d = resp.json()
            shell.poutput(f"{d['url']}  ({d['filename']}, {d.get('filesize', 0)} bytes)")
            if enc_key:
                from cli.keystore import prompt_save
                prompt_save(d["key"], enc_key)
        else:
            shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
        return

    # File upload — expand globs
    paths = glob.glob(target) or glob.glob(os.path.join(shell.local_cwd, target))
    if not paths:
        shell.poutput(f"file not found: {target}")
        return

    for path in sorted(paths):
        if os.path.isdir(path):
            for root, _dirs, filenames in os.walk(path):
                for fname in filenames:
                    _upload_file(shell, os.path.join(root, fname), flags, folder)
        else:
            _upload_file(shell, path, flags, folder)


def _upload_file(shell, path, flags, folder):
    import os
    from cli.session import api_post
    from cli.ui import upload_file as ui_upload

    fname = os.path.basename(path)
    enc_key = flags.get("encryption_key")

    if enc_key:
        # Read, encrypt, upload as text payload
        from cli.crypto import encrypt
        from cli.session import api_post
        from cli.ui import spinner
        with open(path, "r", errors="replace") as f:
            content = f.read()
        blob = encrypt(content, enc_key)
        payload = {
            "text": blob,
            "folder": folder,
            "key": flags.get("key", ""),
            "expires": flags.get("expires", ""),
            "burn": "true" if flags.get("burn") else "",
            "publish": "true" if flags.get("publish") else "",
            "password": flags.get("password", ""),
            "tags": ",".join(flags.get("tag", [])),
            "filename": fname,
            "encrypted": True,
        }
        with spinner(f"Uploading {fname}..."):
            resp = api_post("/api/v1/keys/", json=payload)
    else:
        data = {
            "folder": folder,
            "key": flags.get("key", ""),
            "expires": flags.get("expires", ""),
            "burn": "true" if flags.get("burn") else "",
            "publish": "true" if flags.get("publish") else "",
            "password": flags.get("password", ""),
            "tags": ",".join(flags.get("tag", [])),
        }
        resp = ui_upload(api_post, "/api/v1/keys/", path, filename=fname, extra_data=data)

    if resp.status_code in (200, 201):
        d = resp.json()
        shell.poutput(f"{d['url']}  ({fname}, {d.get('filesize', 0)} bytes)")
        if enc_key:
            from cli.keystore import prompt_save
            prompt_save(d["key"], enc_key)
    else:
        shell.poutput(f"error uploading {fname}: {resp.json().get('error', resp.status_code)}")
