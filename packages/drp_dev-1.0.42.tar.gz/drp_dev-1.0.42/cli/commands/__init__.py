"""
Command registry — single source of truth for every CLI command.

Each command file in this package calls ``register()`` with a ``Command``
that carries the canonical name, description, arguments, and flags.
The shell, help page, and help bot all read from this registry.

    from cli.commands import all_commands, get_command

    for name, cmd in all_commands().items():
        print(cmd.name, cmd.description)
"""

from __future__ import annotations

import getpass
import sys
from dataclasses import dataclass, field
from typing import Any


# ── Spec dataclasses ──────────────────────────────────────────────────────────


@dataclass(frozen=True)
class Arg:
    """A positional argument or flag on a command."""

    name: str
    description: str
    required: bool = False
    default: Any = None
    type: str = "str"
    choices: tuple[str, ...] | None = None
    repeatable: bool = False


@dataclass(frozen=True)
class Command:
    """Canonical definition of a CLI command."""

    name: str
    description: str
    args: tuple[Arg, ...] = ()
    aliases: tuple[str, ...] = ()


# ── Registry ──────────────────────────────────────────────────────────────────

_COMMANDS: dict[str, Command] = {}


def _auto_short(long: str, taken: set[str]) -> str | None:
    """Return -X for --long-flag if that letter isn't already taken."""
    letter = long.lstrip("-")[0]
    candidate = f"-{letter}"
    return candidate if candidate not in taken else None


def _normalize_args(args: tuple[Arg, ...]) -> tuple[Arg, ...]:
    """
    Walk args once, auto-assigning short flags to any --long flag that
    doesn't already have one, skipping collisions silently.
    Positional args are left untouched.
    """
    taken: set[str] = set()

    # First pass: reserve explicitly declared short flags.
    for arg in args:
        for part in arg.name.split("/"):
            part = part.strip()
            if len(part) == 2 and part.startswith("-"):
                taken.add(part)

    # Second pass: auto-add short flags where unambiguous.
    normalized = []
    for arg in args:
        parts = [n.strip() for n in arg.name.split("/")]
        long_names = [n for n in parts if n.startswith("--")]
        has_short = any(len(n) == 2 and n.startswith("-") for n in parts)
        if long_names and not has_short:
            auto = _auto_short(long_names[-1], taken)
            if auto:
                taken.add(auto)
                arg = Arg(
                    name="/".join(parts + [auto]),
                    description=arg.description,
                    required=arg.required,
                    default=arg.default,
                    type=arg.type,
                    choices=arg.choices,
                    repeatable=arg.repeatable,
                )
        normalized.append(arg)

    return tuple(normalized)


def register(cmd: Command) -> Command:
    """Normalize args, add to registry under name and all aliases."""
    cmd = Command(
        name=cmd.name,
        description=cmd.description,
        args=_normalize_args(cmd.args),
        aliases=cmd.aliases,
    )
    _COMMANDS[cmd.name] = cmd
    for alias in cmd.aliases:
        _COMMANDS[alias] = cmd
    return cmd


def _ensure_loaded() -> None:
    if _COMMANDS:
        return
    import importlib
    import pkgutil
    for _finder, _name, _ispkg in pkgutil.iter_modules(__path__):
        importlib.import_module(f"{__name__}.{_name}")


def all_commands() -> dict[str, Command]:
    _ensure_loaded()
    return {n: c for n, c in _COMMANDS.items() if c.name == n}


def get_command(name: str) -> Command | None:
    _ensure_loaded()
    return _COMMANDS.get(name)


# ── Arg prompting ─────────────────────────────────────────────────────────────


def _is_tty() -> bool:
    return sys.stdin.isatty()


def _prompt_arg(arg: Arg) -> str:
    # Pick the longest part (e.g. "--server" beats "-s") for a readable label
    parts = [n.strip() for n in arg.name.split("/")]
    longest = max(parts, key=len)
    label = longest.lstrip("-").replace("-", " ").capitalize()
    prompt = f"{label}: "
    return getpass.getpass(prompt) if arg.type == "passphrase" else input(prompt).strip()


# ── Parsing ───────────────────────────────────────────────────────────────────


class _Args:
    """Simple namespace returned by parse_args, accessible via dot notation."""
    def __init__(self, flags: dict[str, Any], positional: list[str]):
        self._flags = flags
        self._positional = positional
        for k, v in flags.items():
            setattr(self, k, v)

    def __getitem__(self, key):
        return self._flags.get(key)

    def positionals(self) -> list[str]:
        return self._positional


def parse_args(cmd: Command, args_str: str) -> _Args:
    tokens = args_str.strip().split() if args_str.strip() else []

    flag_map: dict[str, tuple[str, Arg]] = {}
    pos_specs: list[Arg] = []

    for arg in cmd.args:
        parts = [n.strip() for n in arg.name.split("/")]
        if not any(n.startswith("-") for n in parts):
            pos_specs.append(arg)
            continue
        canonical = parts[-1].lstrip("-").replace("-", "_")
        for n in parts:
            flag_map[n] = (canonical, arg)

    flags: dict[str, Any] = {}
    positional: list[str] = []
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        if tok in flag_map:
            canonical, spec = flag_map[tok]
            if spec.type == "bool":
                flags[canonical] = True
                i += 1
            elif i + 1 < len(tokens) and not tokens[i + 1].startswith("-"):
                val = tokens[i + 1]
                if spec.repeatable:
                    flags.setdefault(canonical, []).append(val)
                else:
                    flags[canonical] = val
                i += 2
            else:
                # Dangling flag — prompt or mark missing
                if _is_tty():
                    flags[canonical] = _prompt_arg(spec)
                else:
                    flags[canonical] = None
                i += 1
        else:
            tok = tok.strip("\"'")
            positional.append(tok)
            i += 1

    # Resolve flags: prompt/default/error
    missing = []
    for arg in cmd.args:
        parts = [n.strip() for n in arg.name.split("/")]
        if not any(n.startswith("-") for n in parts):
            continue
        canonical = parts[-1].lstrip("-").replace("-", "_")
        if flags.get(canonical) is None:
            if arg.required:
                if _is_tty():
                    flags[canonical] = _prompt_arg(arg)
                else:
                    missing.append(parts[-1])
            elif arg.default is not None:
                flags[canonical] = arg.default

    # Resolve positionals: prompt/default/error
    for idx, spec in enumerate(pos_specs):
        if idx >= len(positional):
            if spec.required:
                if _is_tty():
                    positional.append(_prompt_arg(spec))
                else:
                    missing.append(spec.name)
            elif spec.default is not None:
                positional.append(str(spec.default))

    if missing:
        raise ValueError("Missing required arguments: " + ", ".join(missing))

    return _Args(flags, positional)


# ── Dispatch ──────────────────────────────────────────────────────────────────


def _run_command(shell, spec: Command, statement) -> None:
    import importlib
    try:
        mod = importlib.import_module(f"cli.commands.{spec.name}")
    except ModuleNotFoundError:
        shell.poutput(f"[stub] {spec.name} — not yet implemented")
        return
    run_fn = getattr(mod, "run", None)
    if run_fn is None:
        shell.poutput(f"[stub] {spec.name} — not yet implemented")
        return
    try:
        run_fn(shell, statement.args)
    except Exception as exc:
        from cli.crash.reporter import report, user_message
        fp = report(spec.name, exc)
        shell.perror(user_message(spec.name, fp))