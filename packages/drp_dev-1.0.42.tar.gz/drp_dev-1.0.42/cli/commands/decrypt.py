"""decrypt — Decrypt a file on the drive in place."""

from . import Arg, Command, register

cmd = register(Command(
    name="decrypt",
    description="Decrypt a file on the drive in place.",
    args=(
        Arg("ref",
            "Filename or drive key.",
            required=True),
        Arg("--key",
            "Treat ref as a drive key, skip filename lookup.",
            type="bool"),
        Arg("--encryption-key",
            "Passphrase to decrypt with. Falls back to keystore if saved.",
            type="passphrase"),
    ),
))


def run(shell, args_str):
    from cli.commands import parse_args
    from cli.crypto import decrypt, is_encrypted
    from cli.keystore import get_key, remove_key
    from cli.session import api_get, api_post, check_auth, resolve_ref
    from cli.ui import spinner

    if not check_auth(shell):
        return

    flags, positional = parse_args(cmd, args_str)
    ref = positional[0]
    key = ref if flags.get("key") else resolve_ref(shell, ref)

    with spinner("Fetching..."):
        resp = api_get(f"/api/v1/keys/{key}/raw/")
    if resp.status_code != 200:
        shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
        return

    data = resp.json()
    content = data.get("content")
    if content is None:
        shell.poutput("error: no content to decrypt")
        return

    if not is_encrypted(content):
        shell.poutput("file is not encrypted")
        return

    passphrase = flags.get("encryption_key") or get_key(key)
    if not passphrase:
        shell.poutput("no passphrase supplied and none saved — use --encryption-key")
        return

    try:
        plaintext = decrypt(content, passphrase)
    except ValueError:
        remove_key(key)
        shell.poutput("error: decryption failed — wrong passphrase? Removed saved key.")
        return

    with spinner("Uploading..."):
        resp2 = api_post(f"/api/v1/keys/{key}/", json={"content": plaintext, "encrypted": False})
    if resp2.status_code != 200:
        shell.poutput(f"error: {resp2.json().get('error', resp2.status_code)}")
        return

    remove_key(key)
    shell.poutput(f"decrypted: {key}")