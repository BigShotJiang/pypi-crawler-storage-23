"""cp — Copy files between the real filesystem and the drive, or within the drive."""

import os

from . import Arg, Command, register

cmd = register(Command(
    name="cp",
    description="Copy files between the real filesystem and the drive, or within the drive.",
    args=(
        Arg("src",
            "Source path. ./ for local files; bare names are drive filenames or keys.",
            required=True, type="path"),
        Arg("dest",
            "Destination path. ./ for local; bare names are drive paths.",
            required=True, type="path"),
        Arg("--key",
            "Treat src as a drive key, skip filename lookup.",
            type="bool"),
    ),
))


def run(shell, args_str):
    from cli.commands import parse_args
    from cli.session import api_get, api_post, check_auth, resolve_ref
    from cli.ui import download_to_file, spinner, upload_file

    if not check_auth(shell):
        return

    flags, positional = parse_args(cmd, args_str)
    src, dest = positional[0], positional[1]

    src_local = src.startswith("./") or src.startswith("/") or os.path.exists(
        os.path.join(shell.local_cwd, src))
    dest_local = dest.startswith("./") or dest.startswith("/")

    if src_local and dest_local:
        shell.poutput("local-to-local copy not supported — use system cp")
        return

    if src_local:
        path = src if os.path.isabs(src) else os.path.join(shell.local_cwd, src)
        if not os.path.exists(path):
            shell.poutput(f"file not found: {src}")
            return
        resp = upload_file(
            api_post, "/api/v1/keys/", path,
            filename=os.path.basename(path),
            extra_data={"folder": shell.cwd.strip("/")},
        )
        if resp.status_code in (200, 201):
            shell.poutput(f"uploaded: {resp.json()['url']}")
        else:
            shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
        return

    key = src if flags.get("key") else resolve_ref(shell, src)

    with spinner("Fetching..."):
        resp = api_get(f"/api/v1/keys/{key}/")
    if resp.status_code != 200:
        shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
        return
    data = resp.json()
    url = data.get("download_url")
    if not url:
        shell.poutput("no download URL")
        return

    if dest_local:
        dest_path = dest if os.path.isabs(dest) else os.path.join(shell.local_cwd, dest)
        if os.path.isdir(dest_path):
            dest_path = os.path.join(dest_path, data.get("filename", key))
        with spinner("Downloading..."):
            r = api_get(url)
        download_to_file(r, dest_path, filename=data.get("filename", key))
        shell.poutput(f"saved: {dest_path}")
    else:
        # Drive → drive: server-side fork, no download/re-upload
        with spinner("Forking..."):
            resp2 = api_post(f"/api/v1/keys/{key}/fork/",
                             data={"folder": shell.cwd.strip("/")})
        if resp2.status_code in (200, 201):
            shell.poutput(f"copied: {resp2.json()['url']}")
        else:
            shell.poutput(f"error: {resp2.json().get('error', resp2.status_code)}")