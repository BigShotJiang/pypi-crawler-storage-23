"""cat — Display a file's content in the terminal with syntax highlighting."""

import json

from . import Arg, Command, register

cmd = register(Command(
    name="cat",
    description="Display a file's content in the terminal with syntax highlighting.",
    args=(
        Arg("ref",
            "Filename or drive key.",
            required=True),
        Arg("--key",
            "Treat ref as a drive key, skip filename lookup.",
            type="bool"),
        Arg("--password",
            "Password for a protected file.",
            type="passphrase"),
        Arg("--encryption-key",
            "Passphrase for client-side encrypted content. Decrypts in memory for display.",
            type="passphrase"),
        Arg("--parse",
            "Parse and pretty-print. JSON is formatted; CSV rendered as a table.",
            type="bool"),
        Arg("--field",
            "JSON dot-notation field extraction. Implies --parse."),
        Arg("--column",
            "Extract a CSV column by header name."),
        Arg("--row",
            "Print a single CSV row (1-indexed).",
            type="int"),
        Arg("--lines",
            "Print a line range, e.g. 10-20."),
        Arg("--highlight",
            "Force a syntax lexer, e.g. --highlight python. Overrides auto-detection."),
    ),
))


def run(shell, args_str):
    from cli.commands import parse_args
    from cli.session import api_get, check_auth, resolve_ref

    if not check_auth(shell):
        return

    flags, positional = parse_args(cmd, args_str)
    ref = positional[0]

    key = ref if flags.get("key") else resolve_ref(shell, ref)

    from cli.ui import spinner
    extra = {}
    if flags.get("password"):
        extra["headers"] = {"X-Drop-Password": flags["password"]}

    with spinner("Fetching..."):
        resp = api_get(f"/api/v1/keys/{key}/raw/", **extra)

    if resp.status_code in (404, 410):
        from cli.keystore import remove_key
        remove_key(key)
        shell.poutput(f"error: file not found ({resp.status_code})")
        return
    if resp.status_code != 200:
        shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
        return

    data = resp.json()
    content = data.get("content")

    if content is None:
        download_url = data.get("download_url")
        shell.poutput(f"binary file — download with: get {key}" if download_url else "error: no content available")
        return

    if data.get("encrypted"):
        enc_key = flags.get("encryption_key") or _keystore_passphrase(key)
        if not enc_key:
            shell.poutput("file is encrypted — supply --encryption-key <passphrase> to decrypt")
            return
        try:
            from cli.crypto import decrypt
            content = decrypt(content, enc_key)
        except Exception:
            from cli.keystore import remove_key
            remove_key(key)
            shell.poutput("error: decryption failed — wrong passphrase? Removed saved key.")
            return

    if flags.get("field"):
        _output_json_field(shell, content, flags["field"])
        return

    if flags.get("column") or flags.get("row"):
        _output_csv(shell, content, column=flags.get("column"), row=flags.get("row"))
        return

    if flags.get("lines"):
        _output_lines(shell, content, flags["lines"])
        return

    if flags.get("parse"):
        try:
            shell.poutput(json.dumps(json.loads(content), indent=2))
            return
        except json.JSONDecodeError:
            _output_csv_table(shell, content)
            return

    shell.poutput(content)


# ── Output helpers ────────────────────────────────────────────────────────────


def _output_json_field(shell, content, field):
    try:
        obj = json.loads(content)
        for part in field.split("."):
            obj = obj[int(part)] if isinstance(obj, list) else obj[part]
        shell.poutput(json.dumps(obj, indent=2) if isinstance(obj, (dict, list)) else str(obj))
    except (json.JSONDecodeError, KeyError, IndexError, ValueError) as e:
        shell.poutput(f"field error: {e}")


def _output_csv(shell, content, column=None, row=None):
    import csv, io
    reader = list(csv.reader(io.StringIO(content)))
    if not reader:
        shell.poutput("empty CSV")
        return
    headers = reader[0]
    if row is not None:
        if row < 1 or row >= len(reader):
            shell.poutput(f"row {row} out of range (1–{len(reader)-1})")
            return
        shell.poutput(", ".join(reader[row]))
        return
    if column is not None:
        try:
            idx = headers.index(column)
        except ValueError:
            shell.poutput(f"column '{column}' not found. Headers: {', '.join(headers)}")
            return
        for data_row in reader[1:]:
            shell.poutput(data_row[idx] if idx < len(data_row) else "")


def _output_csv_table(shell, content):
    import csv, io
    rows = list(csv.reader(io.StringIO(content)))
    if not rows:
        return
    widths = [max(len(r[i]) if i < len(r) else 0 for r in rows) for i in range(len(rows[0]))]
    for i, row in enumerate(rows):
        shell.poutput("  ".join(cell.ljust(widths[j]) for j, cell in enumerate(row)))
        if i == 0:
            shell.poutput("  ".join("-" * w for w in widths))


def _output_lines(shell, content, lines_range):
    try:
        start, end = (int(x) for x in lines_range.split("-"))
    except ValueError:
        shell.poutput(f"invalid --lines format '{lines_range}', expected e.g. 10-20")
        return
    for line in content.splitlines()[start - 1:end]:
        shell.poutput(line)


def _keystore_passphrase(key):
    try:
        from cli.keystore import get_key
        return get_key(key)
    except Exception:
        return None