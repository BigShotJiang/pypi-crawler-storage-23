"""fork — Fork a file into your account (server-side, no re-upload)."""

from . import Arg, Command, register

cmd = register(Command(
    name="fork",
    description="Fork a file into your account. Server keeps one copy; forks just reference it.",
    args=(
        Arg("ref",
            "Filename or drive key to fork.",
            required=True),
        Arg("--key",
            "Treat ref as a drive key, skip filename lookup.",
            type="bool"),
    ),
))


def run(shell, args_str):
    from cli.commands import parse_args
    from cli.session import api_post, check_auth, resolve_ref
    from cli.ui import spinner

    if not check_auth(shell):
        return

    flags, positional = parse_args(cmd, args_str)
    ref = positional[0]
    key = ref if flags.get("key") else resolve_ref(shell, ref)

    with spinner("Forking..."):
        resp = api_post(f"/api/v1/keys/{key}/fork/",
                        data={"folder": shell.cwd.strip("/")})
    if resp.status_code in (200, 201):
        d = resp.json()
        shell.poutput(f"forked: {d['url']}  ({d.get('filename', key)})")
    else:
        shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
