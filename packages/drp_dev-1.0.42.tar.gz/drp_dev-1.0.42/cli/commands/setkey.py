"""setkey — Change a file's drive key."""

from . import Arg, Command, register

cmd = register(Command(
    name="setkey",
    description="Change a file's drive key. The old key stops working immediately.",
    args=(
        Arg("ref",
            "Filename or current key.",
            required=True),
        Arg("newkey",
            "New key. Format: [a-zA-Z0-9_-]{1,64}.",
            required=True),
        Arg("--key",
            "Treat ref as a drive key, skip filename lookup.",
            type="bool"),
    ),
))


def run(shell, args_str):
    from cli.commands import parse_args
    from cli.session import api_patch, check_auth, resolve_ref
    from cli.ui import spinner

    if not check_auth(shell):
        return

    flags, positional = parse_args(cmd, args_str)
    ref, newkey = positional[0], positional[1]

    key = ref if flags.get("key") else resolve_ref(shell, ref)

    with spinner("Setting key..."):
        resp = api_patch(f"/api/v1/keys/{key}/", json={"key": newkey})
    if resp.status_code == 200:
        shell.poutput(f"{key} → {newkey}")
    else:
        shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
