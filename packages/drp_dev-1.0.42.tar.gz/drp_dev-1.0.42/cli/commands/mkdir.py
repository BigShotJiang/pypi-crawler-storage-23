"""mkdir — Create a folder at the current location."""

from . import Arg, Command, register

cmd = register(Command(
    name="mkdir",
    description="Create a folder at the current location, local or drive.",
    args=(
        Arg("name",
            "Name for the new folder.",
            required=True),
    ),
))


def run(shell, args_str):
    import os
    from cli.commands import parse_args
    from cli.shell import _in_drive

    _, positional = parse_args(cmd, args_str)
    name = positional[0]

    if not _in_drive(shell.unified_cwd, shell.username):
        path = os.path.join(shell.local_cwd, name)
        try:
            os.mkdir(path)
            shell.poutput(f"created: {path}")
        except FileExistsError:
            shell.poutput(f"already exists: {path}")
        except OSError as e:
            shell.poutput(f"error: {e}")
        return

    from cli.session import api_post, check_auth
    from cli.ui import spinner

    if not check_auth(shell):
        return

    parent = shell.cwd.strip("/")
    payload = {"name": name}
    if parent:
        payload["parent"] = parent

    with spinner("Creating folder..."):
        resp = api_post("/api/v1/folders/", json=payload)
    if resp.status_code in (200, 201):
        shell.poutput(f"created: {resp.json().get('path', name)}")
    else:
        shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
