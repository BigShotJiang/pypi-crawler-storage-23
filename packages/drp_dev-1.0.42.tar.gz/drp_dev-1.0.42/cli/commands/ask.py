"""ask — Ask the drp help bot a question."""

from . import Arg, Command, register, parse_args

cmd = register(Command(
    name="ask",
    description="Ask the drp help bot a question.",
    args=(
        Arg("question",
            "Your question, in quotes.",
            required=True),
    ),
))


def run(shell, args_str):
    from cli.session import api_post, check_auth
    if not check_auth(shell):
        return
    _, positional = parse_args(cmd, args_str)
    question = positional[0]  # guaranteed present by parse_args

    from cli.ui import spinner
    with spinner("Thinking..."):
        resp = api_post("/api/v1/helpbot/", json={"question": question})
    if resp.status_code != 200:
        shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
        return
    shell.poutput(resp.json().get("answer", ""))