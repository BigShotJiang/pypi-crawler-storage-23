"""getkey — Print the drive key for a file looked up by filename."""

from . import Arg, Command, register

cmd = register(Command(
    name="getkey",
    description="Print the drive key for a file in the current folder.",
    args=(
        Arg("ref",
            "Filename or @username/path to look up.",
            required=True),
    ),
))


def run(shell, args_str):
    from cli.commands import parse_args
    from cli.session import api_get, check_auth, resolve_ref
    from cli.ui import spinner

    if not check_auth(shell):
        return

    _, positional = parse_args(cmd, args_str)
    ref = positional[0]
    key = resolve_ref(shell, ref)

    if key == ref:
        # resolve_ref fell back — ref itself may already be a key, just print it
        shell.poutput(key)
        return

    shell.poutput(key)
