"""edit — Open a drive file in $EDITOR and re-upload if changed."""

import hashlib
import os
import subprocess
import tempfile

from . import Arg, Command, register

cmd = register(Command(
    name="edit",
    description="Fetch a drive file, open in $EDITOR, re-upload if changed.",
    args=(
        Arg("ref",
            "Filename or drive key.",
            required=True),
        Arg("--key",
            "Treat ref as a drive key, skip filename lookup.",
            type="bool"),
        Arg("--editor",
            "Override $EDITOR, e.g. --editor nano."),
        Arg("--encryption-key",
            "Passphrase for client-side encrypted content. Decrypts for editing, re-encrypts on save.",
            type="passphrase"),
    ),
))


def run(shell, args_str):
    from cli.commands import parse_args
    from cli.session import api_get, api_post, check_auth, resolve_ref
    from cli.ui import spinner

    if not check_auth(shell):
        return

    flags, positional = parse_args(cmd, args_str)
    ref = positional[0]
    key = ref if flags.get("key") else resolve_ref(shell, ref)
    editor = flags.get("editor") or os.environ.get("EDITOR", "nano")

    with spinner("Fetching..."):
        resp = api_get(f"/api/v1/keys/{key}/raw/")
    if resp.status_code != 200:
        shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
        return

    data = resp.json()
    content = data.get("content")
    if content is None:
        shell.poutput("binary files cannot be edited in terminal")
        return

    # Decrypt if needed
    enc_key = flags.get("encryption_key")
    if data.get("encrypted"):
        if not enc_key:
            from cli.keystore import get_key
            enc_key = get_key(key)
        if not enc_key:
            shell.poutput("file is encrypted — supply --encryption-key <passphrase>")
            return
        try:
            from cli.crypto import decrypt
            content = decrypt(content, enc_key)
        except ValueError:
            shell.poutput("error: decryption failed — wrong passphrase?")
            return

    suffix = os.path.splitext(data.get("filename", ref))[1] or ".txt"
    with tempfile.NamedTemporaryFile(mode="w", suffix=suffix, delete=False) as tmp:
        tmp.write(content)
        tmp_path = tmp.name

    before = hashlib.sha256(content.encode()).hexdigest()

    try:
        subprocess.run([editor, tmp_path], check=True)
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        shell.poutput(f"editor error: {e}")
        os.unlink(tmp_path)
        return

    with open(tmp_path) as f:
        new_content = f.read()
    os.unlink(tmp_path)

    if hashlib.sha256(new_content.encode()).hexdigest() == before:
        shell.poutput("no changes")
        return

    # Re-encrypt if file was encrypted
    upload_content = new_content
    if data.get("encrypted") and enc_key:
        from cli.crypto import encrypt
        upload_content = encrypt(new_content, enc_key)

    with spinner("Saving..."):
        resp2 = api_post(f"/api/v1/keys/{key}/", json={
            "content": upload_content,
            "filename": data.get("filename", ref),
            "folder": shell.cwd.strip("/"),
            "encrypted": data.get("encrypted", False),
        })

    if resp2.status_code in (200, 201):
        shell.poutput(f"saved: {resp2.json().get('url', key)}")
    else:
        shell.poutput(f"error: {resp2.json().get('error', resp2.status_code)}")