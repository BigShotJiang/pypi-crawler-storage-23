"""encrypt — Encrypt a file on the drive in place."""

from . import Arg, Command, register

cmd = register(Command(
    name="encrypt",
    description="Encrypt a file on the drive in place.",
    args=(
        Arg("ref",
            "Filename or drive key.",
            required=True),
        Arg("--key",
            "Treat ref as a drive key, skip filename lookup.",
            type="bool"),
        Arg("--encryption-key",
            "Passphrase to encrypt with.",
            type="passphrase",
            required=True),
    ),
))


def run(shell, args_str):
    from cli.commands import parse_args
    from cli.crypto import encrypt, is_encrypted
    from cli.keystore import prompt_save
    from cli.session import api_get, api_post, check_auth, resolve_ref
    from cli.ui import spinner

    if not check_auth(shell):
        return

    flags, positional = parse_args(cmd, args_str)
    ref = positional[0]
    key = ref if flags.get("key") else resolve_ref(shell, ref)

    with spinner("Fetching..."):
        resp = api_get(f"/api/v1/keys/{key}/raw/")
    if resp.status_code != 200:
        shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
        return

    data = resp.json()
    content = data.get("content")
    if content is None:
        shell.poutput("error: binary files cannot be encrypted this way — download, encrypt locally, re-upload")
        return

    if is_encrypted(content):
        shell.poutput("file is already encrypted")
        return

    passphrase = flags["encryption_key"]
    blob = encrypt(content, passphrase)

    with spinner("Uploading..."):
        resp2 = api_post(f"/api/v1/keys/{key}/", json={"content": blob, "encrypted": True})
    if resp2.status_code != 200:
        shell.poutput(f"error: {resp2.json().get('error', resp2.status_code)}")
        return

    shell.poutput(f"encrypted: {key}")
    prompt_save(key, passphrase)