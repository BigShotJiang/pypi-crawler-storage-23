"""mv — Rename or move a file or folder within the drive."""

from . import Arg, Command, register

cmd = register(Command(
    name="mv",
    description="Rename or move a file or folder within the drive. Server-side, no re-upload.",
    args=(
        Arg("src",
            "Current filename, drive key, or folder name.",
            required=True),
        Arg("dest",
            "New filename, path, or folder name.",
            required=True),
        Arg("--key",
            "Treat src as a drive key, skip filename lookup.",
            type="bool"),
    ),
))


def run(shell, args_str):
    from cli.commands import parse_args
    from cli.session import api_get, api_patch, check_auth, resolve_ref
    from cli.ui import spinner

    if not check_auth(shell):
        return

    flags, positional = parse_args(cmd, args_str)
    src, dest = positional[0], positional[1]

    # Check if src is a folder name in current cwd
    path = shell.cwd.strip("/")
    with spinner("Resolving..."):
        resp = api_get("/api/v1/folders/", params={"path": path} if path else {})

    if resp.status_code == 200:
        for folder in resp.json().get("folders", []):
            if folder.get("name") == src or folder.get("slug") == src:
                with spinner("Moving..."):
                    resp2 = api_patch(f"/api/v1/folders/{folder['id']}/",
                                      json={"name": dest})
                if resp2.status_code == 200:
                    shell.poutput(f"renamed: {src} → {dest}")
                else:
                    shell.poutput(f"error: {resp2.json().get('error', resp2.status_code)}")
                return

    # File move
    key = src if flags.get("key") else resolve_ref(shell, src)

    payload = {}
    if "/" in dest:
        folder_part, filename_part = dest.rsplit("/", 1)
        payload["folder"] = folder_part
        if filename_part:
            payload["filename"] = filename_part
    else:
        payload["filename"] = dest

    with spinner("Moving..."):
        resp2 = api_patch(f"/api/v1/keys/{key}/", json=payload)
    if resp2.status_code == 200:
        shell.poutput(f"moved: {src} → {resp2.json().get('filename', dest)}")
    else:
        shell.poutput(f"error: {resp2.json().get('error', resp2.status_code)}")
