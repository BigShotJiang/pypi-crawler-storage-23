"""cli/crypto.py — AES-256-GCM client-side encryption shared by up, cat, get, encrypt, decrypt."""

import base64
import os

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt


_MAGIC = b"drpenc1:"
_SALT_LEN = 16
_NONCE_LEN = 12
_SCRYPT_N = 2 ** 14
_SCRYPT_R = 8
_SCRYPT_P = 1


def _derive_key(passphrase: str, salt: bytes) -> bytes:
    kdf = Scrypt(salt=salt, length=32, n=_SCRYPT_N, r=_SCRYPT_R, p=_SCRYPT_P)
    return kdf.derive(passphrase.encode())


def is_encrypted(blob: str) -> bool:
    """Return True if blob was produced by encrypt()."""
    try:
        return base64.b64decode(blob.encode())[:len(_MAGIC)] == _MAGIC
    except Exception:
        return False


def encrypt(content: str, passphrase: str) -> str:
    """Encrypt *content* with *passphrase* using AES-256-GCM.

    Raises ValueError if content is already encrypted.
    Returns a base64 blob: magic + salt + nonce + ciphertext.
    """
    if is_encrypted(content):
        raise ValueError("content is already encrypted")
    salt = os.urandom(_SALT_LEN)
    nonce = os.urandom(_NONCE_LEN)
    key = _derive_key(passphrase, salt)
    ct = AESGCM(key).encrypt(nonce, content.encode(), None)
    return base64.b64encode(_MAGIC + salt + nonce + ct).decode()


def decrypt(blob: str, passphrase: str) -> str:
    """Decrypt a blob produced by encrypt().

    Raises ValueError if blob is not encrypted or passphrase is wrong.
    """
    if not is_encrypted(blob):
        raise ValueError("content is not encrypted")
    try:
        raw = base64.b64decode(blob.encode())[len(_MAGIC):]
        salt, nonce, ct = raw[:_SALT_LEN], raw[_SALT_LEN:_SALT_LEN + _NONCE_LEN], raw[_SALT_LEN + _NONCE_LEN:]
        return AESGCM(_derive_key(passphrase, salt)).decrypt(nonce, ct, None).decode()
    except Exception as e:
        raise ValueError("decryption failed") from e