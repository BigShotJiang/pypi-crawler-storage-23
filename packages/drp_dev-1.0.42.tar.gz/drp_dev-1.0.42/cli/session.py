"""
Authenticated HTTP session for the CLI.

    from cli.session import api_get, api_post
    resp = api_get("/api/v1/ping/")
    resp = api_post("/api/v1/keys/", json={...})
"""

from __future__ import annotations

import requests

from cli import config


def current_username() -> str:
    return config.get("username")


def _session() -> tuple[requests.Session, dict]:
    username = current_username()
    cfg = config.load(username)
    s = requests.Session()
    token = cfg.get("token", "")
    if token:
        s.headers["Authorization"] = f"Bearer {token}"
    s.headers["User-Agent"] = "drp-cli"
    return s, cfg


def api_url(path: str) -> str:
    cfg = config.load(current_username())
    host = cfg.get("host", "https://drp.fyi").rstrip("/")
    return f"{host}{path}" if path.startswith("/") else f"{host}/{path}"


def api_get(path: str, **kwargs) -> requests.Response:
    s, _ = _session()
    return s.get(api_url(path), **kwargs)


def api_post(path: str, **kwargs) -> requests.Response:
    s, _ = _session()
    return s.post(api_url(path), **kwargs)


def api_delete(path: str, **kwargs) -> requests.Response:
    s, _ = _session()
    return s.delete(api_url(path), **kwargs)


def api_patch(path: str, **kwargs) -> requests.Response:
    s, _ = _session()
    return s.patch(api_url(path), **kwargs)


def is_logged_in() -> bool:
    return bool(config.load(current_username()).get("token"))


def check_auth(shell) -> bool:
    if not config.is_setup():
        shell.poutput("not set up — run 'drp setup' to get started")
        return False
    if not is_logged_in():
        shell.poutput("not logged in — run 'drp login'")
        return False
    return True


def save_session(token: str, username: str = "", email: str = "") -> None:
    cfg = config.load(username)
    cfg["token"] = token
    if username:
        cfg["username"] = username
    if email:
        cfg["email"] = email
    config.save(cfg, username)


def clear_session() -> None:
    username = current_username()
    cfg = config.load(username)
    cfg["token"] = ""
    cfg["username"] = ""
    cfg["email"] = ""
    config.save(cfg, username)


def _in_drive_cwd(shell) -> bool:
    return f"@{shell.username}" in shell.unified_cwd.split("/")


def resolve_ref(shell, ref: str) -> str:
    """Resolve a filename or @username/path to a drive key.

    Handles:
      - bare filename when already inside @username cwd
      - @username/folder/filename from anywhere
      - folder/filename relative to current drive cwd
    Falls back to ref as-is (key) if not found.
    """
    from cli.ui import spinner

    # Strip @username/ prefix if present
    drive_prefix = f"@{shell.username}/"
    if ref.startswith(drive_prefix):
        ref = ref[len(drive_prefix):]

    # Split into folder subpath and filename
    if "/" in ref:
        subpath, filename = ref.rsplit("/", 1)
    else:
        subpath = shell.cwd.strip("/") if _in_drive_cwd(shell) else ""
        filename = ref

    with spinner("Resolving..."):
        resp = api_get("/api/v1/folders/", params={"path": subpath} if subpath else {})
    if resp.status_code == 200:
        for f in resp.json().get("files", []):
            if f.get("filename") == filename:
                return f.get("key")
    return ref