"""Entry point for the drp CLI."""

from __future__ import annotations

import sys


def main(argv: list[str] | None = None) -> int:
    from cli import config
    from cli.shell import DrpShell

    shell = DrpShell(username=config.get("username"))

    if not config.is_setup():
        shell.intro += "First time? Run 'setup' to get started.\n"

    try:
        shell.cmdloop()
    except KeyboardInterrupt:
        return 130

    return 0


if __name__ == "__main__":
    raise SystemExit(main())