"""cli/keystore.py — Per-user passphrase store backed by keys.toml.

Keys are stored in plain text.  The file is private to the user (chmod 600).
"""

import os
import stat
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib  # type: ignore

import tomli_w

from cli.config import keys_path
from cli.session import current_username


def _path() -> Path:
    return keys_path(current_username())


def _load() -> dict:
    p = _path()
    if not p.exists():
        return {}
    with p.open("rb") as f:
        return tomllib.load(f)


def _save(data: dict) -> None:
    p = _path()
    with p.open("wb") as f:
        tomli_w.dump(data, f)
    p.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 600 — owner read/write only


def get_key(key: str) -> str | None:
    """Return saved passphrase for *key*, or None."""
    return _load().get(key)


def set_key(key: str, passphrase: str) -> None:
    """Save *passphrase* for *key*."""
    data = _load()
    data[key] = passphrase
    _save(data)


def remove_key(key: str) -> None:
    """Remove *key* from the store if present. Silent if absent."""
    data = _load()
    if key in data:
        del data[key]
        _save(data)


def prompt_save(key: str, passphrase: str) -> None:
    """After a successful encrypted upload, offer to save the passphrase.

    Skipped silently in non-interactive contexts.
    """
    import sys
    if not sys.stdin.isatty():
        return
    p = _path()
    print(f"\nSave passphrase to keystore? [y/N]")
    print(f"(will be stored in plain text at {p} — keep this file private)")
    answer = input("> ").strip().lower()
    if answer == "y":
        set_key(key, passphrase)
        print("Saved.")