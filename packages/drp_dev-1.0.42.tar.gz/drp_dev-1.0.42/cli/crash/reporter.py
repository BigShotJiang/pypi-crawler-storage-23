"""
CLI crash reporter.

    from cli.crash.reporter import report, user_message
    try:
        run_command(...)
    except Exception as exc:
        fp = report("up", exc)
        print(user_message("up", fp))
"""

from __future__ import annotations

import hashlib
import json
import platform
import threading
import traceback
import urllib.request

from cli import __version__
from com.issue import scrub


_DEFAULT_HOST = "https://drp.fyi"


def _fingerprint(exc: BaseException) -> str:
    tb = traceback.extract_tb(exc.__traceback__)
    frames = "|".join(
        f"{f.filename.rsplit('/', 1)[-1]}:{f.lineno}:{f.name}" for f in tb
    )
    raw = f"{type(exc).__qualname__}|{frames}"
    return hashlib.sha256(raw.encode()).hexdigest()


def report(command: str, exc: BaseException) -> str:
    """Scrub, fingerprint, and POST the crash in a background thread.

    Returns the fingerprint immediately.
    """
    tb_text = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    fp = _fingerprint(exc)
    payload = json.dumps({
        "fingerprint": fp,
        "command": command,
        "exc_type": type(exc).__qualname__,
        # Scrub here (client-side) so sensitive data never leaves the user's machine.
        # com.issue.create also scrubs server-side before posting to GitHub,
        # but that only protects the GitHub issue — not the network request itself.
        "exc_message": scrub(str(exc)),
        "traceback": scrub(tb_text),
        "cli_version": __version__,
        "python_version": platform.python_version(),
        "platform": platform.platform(),
    }).encode()

    try:
        from cli import config
        host = config.load().get("host", "").rstrip("/") or _DEFAULT_HOST
    except Exception:
        host = _DEFAULT_HOST

    def _send():
        try:
            req = urllib.request.Request(
                f"{host}/api/v1/crash/",
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            urllib.request.urlopen(req, timeout=5)  # noqa: S310
        except Exception:
            pass

    threading.Thread(target=_send, daemon=True).start()
    return fp


def user_message(command: str, fp: str) -> str:
    """One-line message shown to the user after a crash."""
    return (
        f"drp: '{command}' crashed (ref {fp[:8]}). "
        "Report at https://github.com/vicnasdev/drp/issues if this persists."
    )
