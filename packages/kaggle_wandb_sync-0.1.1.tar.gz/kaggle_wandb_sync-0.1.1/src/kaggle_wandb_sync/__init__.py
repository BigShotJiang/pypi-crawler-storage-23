"""kaggle-wandb-sync: Sync W&B offline runs from Kaggle Notebooks via GitHub Actions."""

__version__ = "0.1.1"
