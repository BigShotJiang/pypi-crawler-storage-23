import logging
from xteam import call_py, bot as client

logger = logging.getLogger(__name__)


@call_py.on_update()
async def log_updates(client, update):
    logger.debug(f"Update diterima: {type(update).__name__}")
    
