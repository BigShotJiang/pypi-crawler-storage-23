"""Package for managing sensitive data."""
