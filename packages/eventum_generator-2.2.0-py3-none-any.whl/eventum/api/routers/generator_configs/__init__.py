"""Generator configs router package."""

from eventum.api.routers.generator_configs.routes import router

__all__ = ['router']
