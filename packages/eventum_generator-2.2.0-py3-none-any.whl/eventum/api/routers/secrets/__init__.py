"""Keyring router package."""

from eventum.api.routers.secrets.routes import router

__all__ = ['router']
