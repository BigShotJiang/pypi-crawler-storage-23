"""Package that implements REST API for managing app."""
