"""Parameter models for different parts of application."""
