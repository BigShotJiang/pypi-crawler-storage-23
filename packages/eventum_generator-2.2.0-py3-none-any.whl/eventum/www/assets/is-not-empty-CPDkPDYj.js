function i(n){const t=n||!0;return r=>typeof r=="string"?r.trim().length>0?null:t:Array.isArray(r)?r.length>0?null:t:r==null||r===!1?t:null}export{i};
