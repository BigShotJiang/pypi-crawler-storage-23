import{g as a}from"./index-BOY9uB10.js";/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"M21 17h-5.397a5 5 0 0 1 -4.096 -2.133l-.514 -.734a5 5 0 0 0 -4.096 -2.133h-3.897",key:"svg-0"}],["path",{d:"M21 7h-5.395a5 5 0 0 0 -4.098 2.135l-.51 .73a5 5 0 0 1 -4.097 2.135h-3.9",key:"svg-1"}],["path",{d:"M18 10l3 -3l-3 -3",key:"svg-2"}],["path",{d:"M18 20l3 -3l-3 -3",key:"svg-3"}]],c=a("outline","arrows-split-2","ArrowsSplit2",e);/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=[["path",{d:"M12 7v5l2 2",key:"svg-0"}],["path",{d:"M17 22l5 -3l-5 -3z",key:"svg-1"}],["path",{d:"M13.017 20.943a9 9 0 1 1 7.831 -7.292",key:"svg-2"}]],h=a("outline","clock-play","ClockPlay",o);/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=[["path",{d:"M21 16.008v-8.018a1.98 1.98 0 0 0 -1 -1.717l-7 -4.008a2.016 2.016 0 0 0 -2 0l-7 4.008c-.619 .355 -1 1.01 -1 1.718v8.018c0 .709 .381 1.363 1 1.717l7 4.008a2.016 2.016 0 0 0 2 0l7 -4.008c.619 -.355 1 -1.01 1 -1.718z",key:"svg-0"}],["path",{d:"M12 22v-10",key:"svg-1"}],["path",{d:"M12 12l8.73 -5.04",key:"svg-2"}],["path",{d:"M3.27 6.96l8.73 5.04",key:"svg-3"}]],n=a("outline","cube","Cube",s);/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=[["path",{d:"M20 11a8.1 8.1 0 0 0 -15.5 -2m-.5 -4v4h4",key:"svg-0"}],["path",{d:"M4 13a8.1 8.1 0 0 0 15.5 2m.5 4v-4h-4",key:"svg-1"}]],p=a("outline","refresh","Refresh",t);export{h as I,n as a,c as b,p as c};
