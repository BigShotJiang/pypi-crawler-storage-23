"""Package defines the runtime server responsible for backend services
like REST API and web UI.
"""
