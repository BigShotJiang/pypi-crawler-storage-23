"""Package with REST API service definition."""
