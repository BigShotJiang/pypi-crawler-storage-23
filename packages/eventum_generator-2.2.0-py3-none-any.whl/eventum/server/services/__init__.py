"""Package with services definition."""
