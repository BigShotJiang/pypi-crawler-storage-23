"""Package with linspace input plugin implementation."""
