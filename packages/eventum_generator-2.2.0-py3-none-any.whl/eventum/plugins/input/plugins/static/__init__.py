"""Package with static input plugin implementation."""
