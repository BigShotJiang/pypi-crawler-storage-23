"""Package with time_patterns input plugin implementation."""
