"""Package with definition of base input plugin."""
