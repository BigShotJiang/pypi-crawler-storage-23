"""Package with stdout output plugin implementation."""
