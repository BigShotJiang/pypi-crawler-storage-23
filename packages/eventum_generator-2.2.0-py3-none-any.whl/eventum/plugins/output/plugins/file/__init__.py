"""Package with file output plugin implementation."""
