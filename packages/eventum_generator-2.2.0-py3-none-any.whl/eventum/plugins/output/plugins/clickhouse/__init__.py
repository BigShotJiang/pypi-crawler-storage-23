"""Package with clickhouse output plugin implementation."""
