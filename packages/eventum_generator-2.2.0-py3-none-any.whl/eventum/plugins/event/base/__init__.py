"""Package with definition of base event plugin."""
