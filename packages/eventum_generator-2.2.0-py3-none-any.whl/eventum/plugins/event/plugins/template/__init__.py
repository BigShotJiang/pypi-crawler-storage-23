"""Package with Template event plugin implementation."""
