"""Package with custom modules accessible from templates."""
