"""Event plugins definition package."""
