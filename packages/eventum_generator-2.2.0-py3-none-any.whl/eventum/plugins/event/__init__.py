"""Event plugins package."""
