"""PyCareTaker — A smart Python package manager companion."""
__version__ = "0.1.0"
