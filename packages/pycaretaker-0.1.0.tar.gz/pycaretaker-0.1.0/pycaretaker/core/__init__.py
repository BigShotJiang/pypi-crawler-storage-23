"""Core non-AI features for PyCareTaker."""
