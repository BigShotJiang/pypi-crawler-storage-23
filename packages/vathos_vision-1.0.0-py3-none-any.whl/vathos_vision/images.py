# -*- coding: utf-8 -*-
################################################################################
#
# Copyright (c) 2019-2025, Vathos GmbH
#
# All rights reserved.
#
################################################################################
"""Image retrieval."""

import requests
from imageio import imread

from vathos_vision import BASE_URL
from vathos_vision.files import get_file
from vathos_vision.io.packing import unpack_short, unpack_float


def get_image_metadata(image_id, token):
  """Download image data.

  Args:
    image_id (str): image id
    token (str): API access token

  Returns:
    dict: image data
  """
  url = f'{BASE_URL}/images/{image_id}'
  image_response = requests.get(
    url, headers={'Authorization': 'Bearer ' + token}, timeout=5
  )
  return image_response.json()


def get_images(
  token,
  session=None,
  product=None,
  device=None,
  t_start=None,
  t_end=None,
  content_type=None,
  limit=100,
):
  """Retrieve images based on different search criteria."""
  url = f'{BASE_URL}/images?%24sort%5Btimestamp%5D=1&$limit={limit}'
  if session is not None:
    url += f'&session={session}'
  if product is not None:
    url += f'&product={product}'
  if device is not None:
    url += f'&device={device}'
  if t_start is not None:
    url += f'&timestamp%5B%24gt%5D={t_start}'
  if t_end is not None:
    url += f'&timestamp%5B%24lt%5D={t_end}'
  if content_type is not None:
    url += f'&type={content_type}'

  http_request = requests.get(
    url, headers={'Authorization': 'Bearer ' + token}, timeout=10
  )
  http_request.raise_for_status()

  return http_request.json()


def get_detections(image_id, token):
  """Download detections for a given image."""
  url = f'{BASE_URL}/detections?image={image_id}'
  detection_response = requests.get(
    url, headers={'Authorization': 'Bearer ' + token}, timeout=10
  )
  return detection_response.json()


def get_image(file_id, token, mode='RGB'):
  """Load and decode an RGB image."""
  data = get_file(file_id, token)
  return imread(data, format='PNG', mode=mode)


def get_ir_image(file_id, token):
  """Load and decode an IR image."""
  data = get_file(file_id, token)
  rgb = imread(data, format='PNG')
  temperature_ck = unpack_short(rgb)
  return 0.01 * temperature_ck.astype('f') - 273.15


def get_ir_image_from_disk(path):
  """Load and decode an IR image."""
  # data = get_file(file_id, token)
  rgb = imread(path, format='PNG')
  temperature_ck = unpack_short(rgb)
  return 0.01 * temperature_ck.astype('f') - 273.15


def get_depth_image(file_id, token):
  """Load and decode a depth image."""
  data = get_file(file_id, token)
  rgb = imread(data, format='PNG')
  depth_mm = unpack_float(rgb)
  return 0.001 * depth_mm
