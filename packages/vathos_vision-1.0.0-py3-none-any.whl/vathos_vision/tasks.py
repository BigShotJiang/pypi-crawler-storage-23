# -*- coding: utf-8 -*-
################################################################################
#
# Copyright (c) 2019-2025, Vathos GmbH
#
# All rights reserved.
#
################################################################################
"""Tasks creation and administration."""

import requests

from vathos_vision import BASE_URL


def get_task(product_id, service, token, device=None):
  """Download task result data.

  Args:
    product_id (str): product id
    product_id (str): product id
    token (str): API access token

  Returns:
    dict: Task result.
  """
  url = f'{BASE_URL}/tasks?product={product_id}&service={service}'
  if device is not None:
    url += f'&device={device}'
  http_request = requests.get(
    url, headers={'Authorization': 'Bearer ' + token}, timeout=10
  )
  http_request.raise_for_status()
  tasks = http_request.json()
  if len(tasks) == 0:
    return None
  else:
    # last is the newest
    return tasks[-1]
