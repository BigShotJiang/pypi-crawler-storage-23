#!/usr/bin/env python
# -*- coding: utf-8 -*-
###############################################################################
#
# Copyright (c) 2019-2020, Vathos GmbH
#
# All rights reserved.
#
###############################################################################

import requests


class RPCClient(object):
  """JSON RPC 2.0 client."""

  def __init__(self, base_url):
    """Set up the client."""
    super().__init__()
    self.base_url = base_url

  def send_request(self, method, group, *args):
    """Fire the request."""
    body = {'jsonrpc': '2.0', 'method': method, 'params': list(args)}
    http_request = requests.post(
      f'{self.base_url}?routing_key={group}', json=body
    )
    if http_request.status_code < 200 or http_request.status_code >= 300:
      raise Exception(http_request.text)
    response = http_request.json()
    if 'error' in response:
      raise Exception(response['error'])
    if response['result'] == 'null':
      return None
    else:
      return response['result']
