# -*- coding: utf-8 -*-
################################################################################
#
# Copyright (c) 2019-2025, Vathos GmbH
#
# All rights reserved.
#
################################################################################

import logging

import requests

from vathos_vision import BASE_URL


def get_configuration(configuration_id, token):
  """Get configuration by id."""
  url = f'{BASE_URL}/configurations/{configuration_id}'
  response = requests.get(
    url, headers={'Authorization': 'Bearer ' + token}, timeout=5
  )
  return response.json()


def get_configurations(product_id, workflow, token):
  """Query a list of configurations.

  Args:
    product_id (str): id of the product for which the configuration was created
    workflow (str): name of the workflow
    token (str): API access token

  Returns:
    list: configurations
  """
  url = f'{BASE_URL}/configurations?product={product_id}&workflow={workflow}'
  response = requests.get(
    url, headers={'Authorization': 'Bearer ' + token}, timeout=5
  )
  return response.json()


def get_configuration_data(product_id, service, workflow, token):
  """Get the most recent inference configuration.

  Args:
    product_id (str): id of the product for which the configuration was created
    service (str): name of the inference service for which the configuraton was
      created
    workflow (str): name of the workflow
    token (str): API access token

  Returns:
    dict: configuration data
  """
  url = f'{BASE_URL}/configurations?product={product_id}&service={service}&workflow={workflow}'
  response = requests.get(
    url, headers={'Authorization': 'Bearer ' + token}, timeout=5
  )
  configurations = response.json()

  if len(configurations) == 0:
    return None
  else:
    # last is the newest
    logging.info(
      'Getting config created at %s', configurations[-1]['createdAt']
    )
    return configurations[-1]['data']
