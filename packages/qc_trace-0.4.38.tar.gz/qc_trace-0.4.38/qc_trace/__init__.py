"""QC Trace - Multi-CLI session tracking and normalization."""

__version__ = "0.4.38"
