i need to build a client that will be silent and will keep running on a developer's laptop and will push the data from various coding agents to a central server.

for now mimic this central server with local server or db, it can be postgres, probably use postgres that's best.

create worktrees inside this project for each coding agent, worktress/<agent-name-work_name>/

you should also figure out how to merge all the independent worktrees into a single project.

i need proper logging and monitoring for this project, where i can see logs and statuses of the project

write in /home/sagar/trace/project_logs/agent-name-work_name_progress.json file. come up with schema for this json file.

Whenever an agent is blocked on other agent, the agent should wait for other agent to give context in these json files itself.

use quickcall mcp tools to create issues for this and you can comment and see comments of each issue latest and all as well.

assign all issues to me (sagarsrc)

you can use docker to run postgres or something else  - i have installed docker for you.

you should put your plan in docs/plan-relevant_name-ddmmyyyy.md file.