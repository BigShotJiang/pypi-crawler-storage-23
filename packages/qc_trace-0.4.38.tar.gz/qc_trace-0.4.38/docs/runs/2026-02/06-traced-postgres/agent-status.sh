#!/bin/bash
# Dashboard: show status of all parallel agents
# Usage: watch -n 15 bash scripts/agent-status.sh

LOGS_DIR="/home/sagar/trace/project_logs"
WORKTREE_ROOT="/home/sagar/trace/worktrees"

echo "=== Agent Status Dashboard ==="
echo "$(date '+%Y-%m-%d %H:%M:%S')"
echo ""

for f in "$LOGS_DIR"/*_progress.json; do
  [ -f "$f" ] || continue
  basename_f=$(basename "$f" _progress.json)
  echo "--- $basename_f ---"
  python3 << PYEOF
import json
try:
    d = json.load(open("$f"))
    status = d.get("status", "?")
    icons = {"completed": "[done]", "in_progress": "[....]", "blocked": "[wait]", "pending": "[----]"}
    icon = icons.get(status, "[????]")
    print(f"  Status:  {icon} {status}")
    print(f"  Branch:  {d.get('branch', '?')}")
    print(f"  Task:    {d.get('current_task', '-')}")
    done = d.get("completed_tasks", [])
    print(f"  Done:    {len(done)} task(s)")
    blocked = d.get("blocked_by", [])
    if blocked:
        print(f"  Blocked: {', '.join(blocked)}")
    errors = d.get("errors", [])
    if errors:
        print(f"  Errors:  {len(errors)}")
except Exception as e:
    print(f"  Error reading: {e}")
PYEOF
  echo ""
done

echo "=== Git Activity ==="
echo ""
for dir in "$WORKTREE_ROOT"/*/; do
  [ -d "$dir" ] || continue
  name=$(basename "$dir")
  branch=$(git -C "$dir" branch --show-current 2>/dev/null)
  commits=$(git -C "$dir" log main..HEAD --oneline 2>/dev/null | wc -l)
  last=$(git -C "$dir" log --oneline -1 2>/dev/null)
  echo "  $name ($branch): $commits commit(s)"
  [ -n "$last" ] && echo "    latest: $last"
done
