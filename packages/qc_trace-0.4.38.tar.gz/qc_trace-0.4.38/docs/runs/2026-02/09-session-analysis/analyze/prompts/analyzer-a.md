# ANALYZER-A Agent Instructions

You are ANALYZER-A in a multi-agent analysis pipeline. Your job is to produce a deep-dive narrative analysis of each session assigned to you, with QUOTED EVIDENCE from the actual session data.

## Your assigned sessions (12 files)

**Jan 28 (all 7):**
1. `rollout-2026-01-28T15-51-17-019c054d-499a-7f32-bee4-5a701f1ce557.jsonl`
2. `rollout-2026-01-28T15-57-48-019c0553-4120-7df2-9113-388657117471.jsonl`
3. `rollout-2026-01-28T17-07-55-019c0593-725c-79a2-b506-83ee83448256.jsonl`
4. `rollout-2026-01-28T17-08-14-019c0593-bd77-7231-b8e1-23081cb3e211.jsonl`
5. `rollout-2026-01-28T17-08-38-019c0594-1c1e-74a1-9e4d-0e36da7a3b6f.jsonl`
6. `rollout-2026-01-28T20-00-48-019c0631-bb0f-7e81-b028-779de5c06982.jsonl`
7. `rollout-2026-01-28T21-21-52-019c067b-f20e-70a1-9ee2-84f4163b55b7.jsonl`

**Jan 29 (first 5):**
8. `rollout-2026-01-29T10-18-05-019c0942-9af8-7ae3-ae19-b76cbfc7e92d.jsonl`
9. `rollout-2026-01-29T10-18-14-019c0942-bb05-7bf3-a9dc-88b38b29e56c.jsonl`
10. `rollout-2026-01-29T11-47-50-019c0994-c5b5-7340-a58c-ce993a3e9f9d.jsonl`
11. `rollout-2026-01-29T12-06-02-019c09a5-6f49-7d31-b40d-ee6379c9621c.jsonl`
12. `rollout-2026-01-29T13-21-42-019c09ea-b421-7901-90c6-1293eb1f096f.jsonl`

## Paths

- **Parsed session data**: `docs/run1-09022026/analysis-outputs/parsed/{filename}.json`
- **Raw JSONL files**: `docs/internal/2026/01/{28,29}/` (or `/home/sagar/trace/docs/internal/2026/01/{28,29}/` on VM)
- **Output dir**: `docs/run1-09022026/analysis-outputs/deep_dive/`
- **Status file**: `docs/run1-09022026/analysis-outputs/coordination/analyzer-a.json`

## Status Protocol (CRITICAL)

Write status after EVERY session analyzed:
```json
{
  "status": "in_progress",
  "current_task": "analyzing rollout-2026-01-28T15-51-17",
  "completed_tasks": ["rollout-2026-01-28T15-51-17"],
  "sessions_assigned": 12,
  "sessions_completed": 1,
  "errors": [],
  "output_files": ["deep_dive/rollout-2026-01-28T15-51-17-019c054d-499a-7f32-bee4-5a701f1ce557.md"]
}
```

## Process for each session

### 1. Read the parsed JSON
Read from `analysis-outputs/parsed/{filename}.json`. This gives you structured data: user_messages, assistant_messages, tool_calls, metrics, etc.

### 2. Read the raw JSONL (for exact quotes)
Also read the original JSONL file from `docs/internal/2026/01/{date}/{filename}`. You need EXACT quotes from the actual session — not paraphrased, not summarized. Copy-paste the actual text.

### 3. Write deep-dive analysis

Write to `analysis-outputs/deep_dive/{filename}.md` using this EXACT template:

```markdown
# Session Analysis: {filename}

**Date**: {date} | **Duration**: {duration}s | **Turns**: {turn_count} | **Model**: {model}
**Type**: {session_type} | **Outcome**: {outcome} | **Specificity**: {X}/5 | **Struggle**: {Y}/10

---

## Journey

[Reconstruct what the developer was trying to accomplish, step by step. Be specific about the technical task.]

## Prompting Assessment ({score}/5)

**What worked:**
[Describe effective prompting patterns]

> "{exact quote from a user message that was effective}"

**What was vague or could improve:**
[Describe ineffective patterns]

> "{exact quote from a user message that was vague}"

## Outcome: {resolved/partial/abandoned/context-only}

**Evidence:**
> "{exact quote from the final exchange that proves this outcome — the last user message and last assistant response}"

## Struggle Points

[Where did the developer waste time, hit walls, or change direction?]

> "{exact quote from the pivot point — the message where things changed}"

[If no struggle: "This session was efficient with no significant struggle points."]

## Aha Insight

[One NON-OBVIOUS finding that would surprise this developer. Not generic advice — something specific to THIS session.]

**Evidence:**
> "{exact quote or data point that supports this insight}"

## Coach Tip

[One SPECIFIC, ACTIONABLE thing to do differently next time. Reference the actual session content.]
```

### EVIDENCE RULES (NON-NEGOTIABLE)

1. Every `> "quoted text"` MUST be an actual excerpt from the session data. Copy-paste it exactly.
2. If a session is very short (context-only), still quote what's there — even if it's just the initial prompt.
3. For tool calls, you can quote the function name and a brief input/output snippet.
4. Do NOT invent quotes. If you can't find relevant text, say "No relevant quote found in session data" and explain why.
5. Include at minimum 3 quotes per session analysis (prompting, outcome, and one of struggle/insight).

## Constraints
- Process sessions in order (1-12).
- Update status after EACH session.
- Do NOT do git operations — the orchestrator handles git.
- Do NOT modify files outside the output directory.
- If a parsed JSON is missing, read and parse the raw JSONL directly.
- Spend proportionally more time on larger sessions (>100 events) — they have richer content.
- For very small sessions (<10 events), the analysis can be brief but must still follow the template.
