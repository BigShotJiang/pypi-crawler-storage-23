// Full-page PNG export using html2canvas
async function exportPNG() {
  const btn = document.querySelector('.export-btn');
  const nav = document.querySelector('.nav');
  const original = btn.textContent;

  // Hide UI elements
  btn.style.display = 'none';
  if (nav) nav.style.display = 'none';

  // Dynamically load html2canvas
  if (!window.html2canvas) {
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js';
    document.head.appendChild(script);
    await new Promise(r => script.onload = r);
  }

  const canvas = await html2canvas(document.body, {
    backgroundColor: '#09090b', // zinc-950
    scale: 2,
    useCORS: true,
    logging: false,
  });

  // Restore UI
  btn.style.display = '';
  if (nav) nav.style.display = '';

  // Download
  const link = document.createElement('a');
  const name = document.title.replace(/[^a-zA-Z0-9]/g, '-').toLowerCase();
  link.download = `${name}.png`;
  link.href = canvas.toDataURL('image/png');
  link.click();
}
