cp /Users/sagar/work/all-things-quickcall/trace/scripts/install.sh /Users/sagar/work/all-things-quickcall/quick-call-dev/frontend-quickcall-dev/public/trace/install.sh

cp /Users/sagar/work/all-things-quickcall/trace/scripts/uninstall.sh /Users/sagar/work/all-things-quickcall/quick-call-dev/frontend-quickcall-dev/public/trace/uninstall.sh