#!/usr/bin/env bash
set -euo pipefail

# QuickCall Trace — uninstaller
# Usage: curl -fsSL https://quickcall.dev/trace/uninstall.sh | sh

QC_TRACE_DIR="$HOME/.quickcall-trace"

RED='\033[0;31m'
GREEN='\033[0;32m'
BOLD='\033[1m'
RESET='\033[0m'

info()  { echo -e "${BOLD}==>${RESET} $*"; }
ok()    { echo -e "${GREEN}✓${RESET} $*"; }

info "QuickCall Trace uninstaller"

OS="$(uname -s)"

# ─── Step 1: Stop and remove service ─────────────────────────────────────────

case "$OS" in
    Linux)
        if systemctl --user is-active --quiet quickcall 2>/dev/null; then
            systemctl --user stop quickcall
            ok "Stopped quickcall service"
        fi

        if systemctl --user is-enabled --quiet quickcall 2>/dev/null; then
            systemctl --user disable quickcall
            ok "Disabled quickcall service"
        fi

        SERVICE_FILE="$HOME/.config/systemd/user/quickcall.service"
        if [ -f "$SERVICE_FILE" ]; then
            rm "$SERVICE_FILE"
            systemctl --user daemon-reload
            ok "Removed $SERVICE_FILE"
        fi
        ;;

    Darwin)
        PLIST="$HOME/Library/LaunchAgents/com.quickcall.traced.plist"
        if [ -f "$PLIST" ]; then
            DOMAIN_TARGET="gui/$(id -u)"
            launchctl bootout "$DOMAIN_TARGET/com.quickcall.traced" 2>/dev/null || true
            rm "$PLIST"
            ok "Removed launchd agent"
        fi

        ;;

    *)
        echo "Unsupported OS: $OS"
        exit 1
        ;;
esac

# ─── Step 2: Kill daemon if still running ────────────────────────────────────

PID_FILE="$QC_TRACE_DIR/quickcall.pid"
if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if kill -0 "$PID" 2>/dev/null; then
        kill "$PID" 2>/dev/null || true
        ok "Stopped daemon (PID $PID)"
    fi
    rm "$PID_FILE"
fi

# Kill any remaining quickcall processes (wrapper + daemon + run)
pkill -9 -f "quickcall-daemon" 2>/dev/null || true
pkill -9 -f "quickcall run" 2>/dev/null || true
pkill -9 -f "quickcall start" 2>/dev/null || true

# ─── Step 3: Remove shell config block ───────────────────────────────────────

MARKER_BEGIN="# >>> quickcall-trace >>>"
MARKER_END="# <<< quickcall-trace <<<"

for RC in "$HOME/.zshrc" "$HOME/.bashrc" "$HOME/.bash_profile"; do
    if [ -f "$RC" ] && grep -q "$MARKER_BEGIN" "$RC" 2>/dev/null; then
        LC_ALL=C sed -i.bak "/$MARKER_BEGIN/,/$MARKER_END/d" "$RC"
        rm -f "${RC}.bak"
        ok "Removed shell config from $RC"
    fi
done

# ─── Step 4: Uninstall CLI + clean uv cache ──────────────────────────────────

if command -v uv >/dev/null 2>&1; then
    uv tool uninstall qc-trace 2>/dev/null || true
    uv cache clean qc-trace --force >/dev/null 2>&1 || true
    ok "Uninstalled qc-trace CLI and cleaned cache"
fi

# ─── Step 5: Remove app bundle ────────────────────────────────────────────

APP_DIR="$QC_TRACE_DIR/QuickCall.app"
if [ -d "$APP_DIR" ]; then
    rm -rf "$APP_DIR"
    ok "Removed app bundle"
fi

# Remove wrapper script
rm -f "$QC_TRACE_DIR/quickcall-daemon"

# ─── Done ─────────────────────────────────────────────────────────────────────

# Clear shell command cache so 'quickcall' isn't found in current session
hash -r 2>/dev/null || true

echo ""
ok "QuickCall Trace uninstalled"
echo ""
echo "Data directory preserved at $QC_TRACE_DIR/"
echo "To remove all data: rm -rf $QC_TRACE_DIR"
echo ""
echo -e "Run ${BOLD}exec \$SHELL${RESET} or open a new terminal to complete cleanup."
echo ""
