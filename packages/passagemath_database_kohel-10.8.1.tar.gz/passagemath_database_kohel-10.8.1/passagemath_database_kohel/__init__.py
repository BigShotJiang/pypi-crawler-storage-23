# sage_setup: distribution = sagemath-database-kohel

from sage.all__sagemath_database_kohel import *
