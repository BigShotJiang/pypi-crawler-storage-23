"""Allow running the CLI via ``python -m nativ``."""

from nativ._cli import cli_entry

cli_entry()
