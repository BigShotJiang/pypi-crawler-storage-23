use anyhow::{bail, Context, Result};
use std::collections::{HashMap, HashSet};
use std::fs::{self, File};
use std::path::{Path, PathBuf};

use rayon::prelude::*;

use csv::ReaderBuilder;

use crate::core::config::{created_by_string, CsvdbConfig, CURRENT_FORMAT_VERSION};
use crate::TableFilter;

/// Inferred column type from CSV data.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum InferredType {
    Boolean,
    Integer,
    Real,
    Date,
    Timestamp,
    Text,
}

impl InferredType {
    fn as_sql(&self) -> &'static str {
        match self {
            InferredType::Boolean => "BOOLEAN",
            InferredType::Integer => "INTEGER",
            InferredType::Real => "REAL",
            InferredType::Date => "DATE",
            InferredType::Timestamp => "TIMESTAMP",
            InferredType::Text => "TEXT",
        }
    }

    /// Widen type to accommodate a new value.
    fn widen(self, other: InferredType) -> InferredType {
        use InferredType::*;
        match (self, other) {
            // Same type stays same
            (Boolean, Boolean) => Boolean,
            (Integer, Integer) => Integer,
            (Real, Real) => Real,
            (Date, Date) => Date,
            (Timestamp, Timestamp) => Timestamp,
            (Text, Text) => Text,

            // Boolean + numeric = numeric
            (Boolean, Integer) | (Integer, Boolean) => Integer,
            (Boolean, Real) | (Real, Boolean) => Real,

            // Integer + Real = Real
            (Integer, Real) | (Real, Integer) => Real,

            // Date + Timestamp = Timestamp
            (Date, Timestamp) | (Timestamp, Date) => Timestamp,

            // All other mismatches = Text
            _ => Text,
        }
    }
}

/// Inferred column metadata.
#[derive(Debug, Clone)]
pub struct InferredColumn {
    pub name: String,
    pub col_type: InferredType,
    pub nullable: bool,
    pub unique_values: Option<HashSet<String>>, // None if too many values to track
}

/// A suggested foreign key relationship.
#[derive(Debug, Clone)]
pub struct SuggestedForeignKey {
    pub column: String,
    pub references_table: String,
    pub references_column: String,
}

/// Inferred table schema.
#[derive(Debug, Clone)]
pub struct InferredTable {
    pub name: String,
    pub columns: Vec<InferredColumn>,
    pub row_count: usize,
    pub suggested_pk: Option<String>,
    pub suggested_fks: Vec<SuggestedForeignKey>,
}

impl InferredTable {
    /// Generate CREATE TABLE DDL.
    pub fn to_ddl(&self) -> String {
        let mut ddl = format!("CREATE TABLE \"{}\" (\n", self.name);

        for (i, col) in self.columns.iter().enumerate() {
            let is_pk = self.suggested_pk.as_ref() == Some(&col.name);

            ddl.push_str(&format!("    \"{}\" {}", col.name, col.col_type.as_sql()));

            if is_pk {
                ddl.push_str(" PRIMARY KEY");
            } else if !col.nullable {
                ddl.push_str(" NOT NULL");
            }

            // Add REFERENCES clause if this column has a suggested FK
            if let Some(fk) = self.suggested_fks.iter().find(|fk| fk.column == col.name) {
                ddl.push_str(&format!(
                    " REFERENCES \"{}\"(\"{}\")",
                    fk.references_table, fk.references_column
                ));
            }

            if i < self.columns.len() - 1 {
                ddl.push(',');
            }
            ddl.push('\n');
        }

        ddl.push(')');
        ddl
    }
}

/// Configuration for schema inference.
#[derive(Debug, Clone)]
pub struct InferConfig {
    /// Maximum unique values to track for PK detection (0 = disable)
    pub max_unique_track: usize,
    /// Sample size for type inference (0 = all rows)
    pub sample_size: usize,
    /// Auto-detect primary key columns
    pub detect_pk: bool,
    /// Auto-detect foreign key relationships
    pub detect_fk: bool,
}

impl Default for InferConfig {
    fn default() -> Self {
        Self {
            max_unique_track: 100_000,
            sample_size: 0, // all rows
            detect_pk: true,
            detect_fk: true,
        }
    }
}

/// Infer the type of a single value.
fn infer_value_type(value: &str) -> InferredType {
    if value.is_empty() {
        return InferredType::Text; // Will be treated as nullable
    }

    // Boolean: true/false/yes/no/t/f (case-insensitive). NOT "1"/"0" (those stay Integer)
    let lower = value.to_lowercase();
    if matches!(lower.as_str(), "true" | "false" | "yes" | "no" | "t" | "f") {
        return InferredType::Boolean;
    }

    // Try integer
    if value.parse::<i64>().is_ok() {
        return InferredType::Integer;
    }

    // Try float
    if value.parse::<f64>().is_ok() {
        return InferredType::Real;
    }

    // Timestamp: YYYY-MM-DD[T ]HH:MM:SS (length >= 19, date prefix + separator + time)
    if value.len() >= 19 && is_timestamp(value) {
        return InferredType::Timestamp;
    }

    // Date: YYYY-MM-DD (exactly 10 chars, digits-dash-digits-dash-digits)
    if value.len() == 10 && is_date(value) {
        return InferredType::Date;
    }

    InferredType::Text
}

/// Check if a value looks like a date: YYYY-MM-DD
fn is_date(value: &str) -> bool {
    let bytes = value.as_bytes();
    if bytes.len() != 10 {
        return false;
    }
    // YYYY-MM-DD
    bytes[0..4].iter().all(|b| b.is_ascii_digit())
        && bytes[4] == b'-'
        && bytes[5..7].iter().all(|b| b.is_ascii_digit())
        && bytes[7] == b'-'
        && bytes[8..10].iter().all(|b| b.is_ascii_digit())
}

/// Check if a value looks like a timestamp: YYYY-MM-DD[T ]HH:MM:SS...
fn is_timestamp(value: &str) -> bool {
    if value.len() < 19 {
        return false;
    }
    let bytes = value.as_bytes();
    // Check date prefix: YYYY-MM-DD
    if !is_date(&value[..10]) {
        return false;
    }
    // Separator: T or space
    if bytes[10] != b'T' && bytes[10] != b' ' {
        return false;
    }
    // HH:MM:SS
    bytes[11..13].iter().all(|b| b.is_ascii_digit())
        && bytes[13] == b':'
        && bytes[14..16].iter().all(|b| b.is_ascii_digit())
        && bytes[16] == b':'
        && bytes[17..19].iter().all(|b| b.is_ascii_digit())
}

/// Infer schema for a single CSV file.
pub fn infer_table_schema(path: &Path, config: &InferConfig) -> Result<InferredTable> {
    let file =
        File::open(path).with_context(|| format!("Failed to open CSV: {}", path.display()))?;

    let mut reader = ReaderBuilder::new().has_headers(true).from_reader(file);

    let headers = reader.headers()?.clone();
    if headers.is_empty() {
        bail!("CSV file has no columns: {}", path.display());
    }

    // Initialize column metadata
    let mut columns: Vec<InferredColumn> = headers
        .iter()
        .map(|name| InferredColumn {
            name: name.to_string(),
            col_type: InferredType::Integer, // Start with most restrictive
            nullable: false,
            unique_values: if config.max_unique_track > 0 {
                Some(HashSet::new())
            } else {
                None
            },
        })
        .collect();

    let mut row_count = 0;
    let mut first_row = true;

    for result in reader.records() {
        let record = result?;
        row_count += 1;

        // Stop if we've hit sample size limit
        if config.sample_size > 0 && row_count > config.sample_size {
            break;
        }

        for (i, value) in record.iter().enumerate() {
            if i >= columns.len() {
                continue;
            }

            let col = &mut columns[i];

            // Check for nullability
            if value.is_empty() {
                col.nullable = true;
            } else {
                // Infer type (widen if needed)
                let value_type = infer_value_type(value);
                if first_row {
                    col.col_type = value_type;
                } else {
                    col.col_type = col.col_type.widen(value_type);
                }

                // Track unique values for PK detection
                if let Some(ref mut unique) = col.unique_values {
                    if unique.len() < config.max_unique_track {
                        unique.insert(value.to_string());
                    } else {
                        // Too many values, stop tracking
                        col.unique_values = None;
                    }
                }
            }
        }

        first_row = false;
    }

    // Determine table name from filename
    let table_name = path
        .file_stem()
        .and_then(|s| s.to_str())
        .unwrap_or("table")
        .to_string();

    // Suggest primary key
    let suggested_pk = if config.detect_pk {
        suggest_primary_key(&columns, row_count)
    } else {
        None
    };

    Ok(InferredTable {
        name: table_name,
        columns,
        row_count,
        suggested_pk,
        suggested_fks: Vec::new(), // Populated later by suggest_foreign_keys()
    })
}

/// Suggest a primary key column based on heuristics.
fn suggest_primary_key(columns: &[InferredColumn], row_count: usize) -> Option<String> {
    if row_count == 0 {
        return None;
    }

    // Priority 1: Column named "id" or ending with "_id" that has all unique values
    for col in columns {
        let name_lower = col.name.to_lowercase();
        if (name_lower == "id" || name_lower.ends_with("_id")) && !col.nullable {
            if let Some(ref unique) = col.unique_values {
                if unique.len() == row_count {
                    return Some(col.name.clone());
                }
            }
        }
    }

    // Priority 2: First INTEGER column with all unique values
    for col in columns {
        if col.col_type == InferredType::Integer && !col.nullable {
            if let Some(ref unique) = col.unique_values {
                if unique.len() == row_count {
                    return Some(col.name.clone());
                }
            }
        }
    }

    // Priority 3: Any column with all unique values (prefer non-nullable)
    for col in columns {
        if !col.nullable {
            if let Some(ref unique) = col.unique_values {
                if unique.len() == row_count {
                    return Some(col.name.clone());
                }
            }
        }
    }

    None
}

/// Suggest foreign key relationships based on naming conventions.
///
/// Heuristics:
/// - Column named `<table>_id` where `<table>` (singular or plural) matches another table name
/// - Column named `<table>_id` where `<table>s` matches another table name (singular -> plural)
/// - Only suggests FK if the referenced table has a matching PK column
fn suggest_foreign_keys(tables: &[InferredTable]) -> Vec<(usize, Vec<SuggestedForeignKey>)> {
    // Build lookup: table name -> (index, pk column name)
    let mut table_lookup: HashMap<String, (usize, String)> = HashMap::new();
    for (i, table) in tables.iter().enumerate() {
        if let Some(ref pk) = table.suggested_pk {
            // Map both the exact name and common variations
            table_lookup.insert(table.name.to_lowercase(), (i, pk.clone()));
        }
    }

    let mut results = Vec::new();

    for (table_idx, table) in tables.iter().enumerate() {
        let mut fks = Vec::new();

        for col in &table.columns {
            let col_lower = col.name.to_lowercase();

            // Skip if this is the table's own PK
            if table.suggested_pk.as_ref().map(|pk| pk.to_lowercase()) == Some(col_lower.clone()) {
                continue;
            }

            // Pattern: column ends with "_id"
            if let Some(prefix) = col_lower.strip_suffix("_id") {
                if prefix.is_empty() {
                    continue;
                }

                // Try matching against table names:
                // 1. Exact match: user_id -> user (table)
                // 2. Plural forms: user -> users, address -> addresses, category -> categories
                let mut candidates = vec![
                    prefix.to_string(),
                    format!("{}s", prefix),  // user -> users
                    format!("{}es", prefix), // address -> addresses
                ];
                // Handle y -> ies: category -> categories
                if prefix.ends_with('y') {
                    candidates.push(format!("{}ies", prefix.strip_suffix('y').unwrap()));
                }

                for candidate in &candidates {
                    if let Some((ref_idx, ref ref_pk)) = table_lookup.get(candidate.as_str()) {
                        // Don't create self-referencing FKs from naming alone
                        if *ref_idx != table_idx {
                            fks.push(SuggestedForeignKey {
                                column: col.name.clone(),
                                references_table: tables[*ref_idx].name.clone(),
                                references_column: ref_pk.clone(),
                            });
                            break; // Take first match
                        }
                    }
                }
            }
        }

        if !fks.is_empty() {
            results.push((table_idx, fks));
        }
    }

    results
}

/// Initialize a .csvdb directory from raw CSV files.
///
/// If `source_dir` contains CSV files, infers schema and creates schema.sql.
/// If `source_dir` is a .csvdb directory, just validates/regenerates schema.
pub fn init_csvdb(
    source: &Path,
    output: Option<&Path>,
    force: bool,
    filter: &TableFilter,
    config: &InferConfig,
) -> Result<InitResult> {
    // Accept a single CSV file or a directory of CSV files
    let (source_dir, csv_files) = if source.is_file() {
        let ext = source.extension().and_then(|e| e.to_str()).unwrap_or("");
        if !ext.eq_ignore_ascii_case("csv") {
            bail!("Expected a .csv file, got: {}", source.display());
        }
        let dir = source.parent().unwrap_or(Path::new("."));
        (dir.to_path_buf(), vec![source.to_path_buf()])
    } else {
        let files: Vec<PathBuf> = fs::read_dir(source)?
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .filter(|p| {
                p.extension()
                    .and_then(|e| e.to_str())
                    .map(|e| e.eq_ignore_ascii_case("csv"))
                    .unwrap_or(false)
            })
            .collect();
        if files.is_empty() {
            bail!("No CSV files found in {}", source.display());
        }
        (source.to_path_buf(), files)
    };

    // Filter CSV files by table name
    let csv_files: Vec<PathBuf> = csv_files
        .into_iter()
        .filter(|p| {
            let table_name = p.file_stem().and_then(|s| s.to_str()).unwrap_or("");
            filter.matches(table_name)
        })
        .collect();
    if csv_files.is_empty() {
        bail!("No CSV files match the specified table filter");
    }

    // Infer schema for each CSV (parallel)
    let inferred: Vec<Result<InferredTable>> = csv_files
        .par_iter()
        .map(|csv_path| infer_table_schema(csv_path, config))
        .collect();

    let mut tables = Vec::new();
    let mut warnings = Vec::new();

    for result in inferred {
        let table = result?;
        if table.suggested_pk.is_none() {
            warnings.push(format!(
                "Table '{}': no primary key detected. Consider adding one manually.",
                table.name
            ));
        }
        tables.push(table);
    }

    // Sort tables by name for deterministic output
    tables.sort_by(|a, b| a.name.cmp(&b.name));

    // Infer foreign keys across tables
    if config.detect_fk {
        let fk_suggestions = suggest_foreign_keys(&tables);
        for (table_idx, fks) in fk_suggestions {
            for fk in &fks {
                warnings.push(format!(
                    "Table '{}': inferred foreign key {}.{} -> {}.{}",
                    tables[table_idx].name,
                    tables[table_idx].name,
                    fk.column,
                    fk.references_table,
                    fk.references_column,
                ));
            }
            tables[table_idx].suggested_fks = fks;
        }
    }

    // Generate schema.sql
    let schema_sql = generate_schema_sql(&tables);

    // Determine output directory
    let output_dir = if let Some(out) = output {
        out.to_path_buf()
    } else if source_dir.extension().and_then(|e| e.to_str()) == Some("csvdb") {
        source_dir.to_path_buf()
    } else if source.is_file() {
        // Single file: use file stem for .csvdb directory name
        let stem = source
            .file_stem()
            .and_then(|n| n.to_str())
            .unwrap_or("data");
        source_dir.join(format!("{stem}.csvdb"))
    } else {
        // Directory: use directory name for .csvdb directory name
        let dir_name = source_dir
            .file_name()
            .and_then(|n| n.to_str())
            .unwrap_or("data");
        source_dir
            .parent()
            .unwrap_or(Path::new("."))
            .join(format!("{dir_name}.csvdb"))
    };

    // Check for existing output (skip when writing back into source)
    if output_dir.exists() && output_dir != source_dir && !force {
        bail!(
            "Output directory already exists: {}\nUse --force to overwrite.",
            output_dir.display()
        );
    }

    // Create directory if needed
    if !output_dir.exists() {
        fs::create_dir_all(&output_dir)?;
    }

    // Write schema.sql
    let schema_path = output_dir.join("schema.sql");
    fs::write(&schema_path, &schema_sql)
        .with_context(|| "Failed to write schema.sql".to_string())?;

    // Copy CSV files if source != output
    if source_dir != output_dir {
        for csv_path in &csv_files {
            let dest = output_dir.join(csv_path.file_name().unwrap());
            if csv_path != &dest {
                fs::copy(csv_path, &dest)?;
            }
        }
    }

    // Write csvdb.toml
    let config = CsvdbConfig {
        format_version: Some(CURRENT_FORMAT_VERSION.to_string()),
        created_by: Some(created_by_string()),
        null_mode: Some("marker".to_string()),
        ..Default::default()
    };
    config.write(&output_dir)?;

    Ok(InitResult {
        output_dir,
        tables,
        warnings,
    })
}

/// Generate schema.sql content from inferred tables.
fn generate_schema_sql(tables: &[InferredTable]) -> String {
    // Sort tables by FK dependency: referenced tables before referencing tables.
    // This ensures schema.sql can be executed in order without FK errors.
    let sorted = sort_tables_by_fk_dep(tables);

    let mut sql = String::new();
    for (i, table) in sorted.iter().enumerate() {
        if i > 0 {
            sql.push('\n');
        }
        sql.push_str(&table.to_ddl());
        sql.push_str(";\n");
    }

    sql
}

/// Sort InferredTables so that FK-referenced tables come first (Kahn's algorithm).
fn sort_tables_by_fk_dep(tables: &[InferredTable]) -> Vec<&InferredTable> {
    if tables.len() <= 1 {
        return tables.iter().collect();
    }

    let name_to_idx: HashMap<&str, usize> = tables
        .iter()
        .enumerate()
        .map(|(i, t)| (t.name.as_str(), i))
        .collect();

    let mut dependents: Vec<Vec<usize>> = vec![Vec::new(); tables.len()];
    let mut in_degree: Vec<usize> = vec![0; tables.len()];

    for (i, table) in tables.iter().enumerate() {
        let mut deps: HashSet<usize> = HashSet::new();
        for fk in &table.suggested_fks {
            if let Some(&dep_idx) = name_to_idx.get(fk.references_table.as_str()) {
                if dep_idx != i {
                    deps.insert(dep_idx);
                }
            }
        }
        for dep_idx in deps {
            dependents[dep_idx].push(i);
            in_degree[i] += 1;
        }
    }

    let mut queue: std::collections::VecDeque<usize> = in_degree
        .iter()
        .enumerate()
        .filter(|(_, &d)| d == 0)
        .map(|(i, _)| i)
        .collect();

    let mut sorted = Vec::with_capacity(tables.len());
    while let Some(idx) = queue.pop_front() {
        sorted.push(&tables[idx]);
        for &dep in &dependents[idx] {
            in_degree[dep] -= 1;
            if in_degree[dep] == 0 {
                queue.push_back(dep);
            }
        }
    }

    // If cycle detected, just return original order
    if sorted.len() < tables.len() {
        return tables.iter().collect();
    }

    sorted
}

/// Result of initializing a csvdb directory.
#[derive(Debug)]
pub struct InitResult {
    pub output_dir: PathBuf,
    pub tables: Vec<InferredTable>,
    pub warnings: Vec<String>,
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::tempdir;

    #[test]
    fn test_infer_value_type() {
        assert_eq!(infer_value_type("123"), InferredType::Integer);
        assert_eq!(infer_value_type("-456"), InferredType::Integer);
        assert_eq!(infer_value_type("3.14"), InferredType::Real);
        assert_eq!(infer_value_type("-0.5"), InferredType::Real);
        assert_eq!(infer_value_type("hello"), InferredType::Text);
        assert_eq!(infer_value_type(""), InferredType::Text);
        assert_eq!(infer_value_type("123abc"), InferredType::Text);
    }

    #[test]
    fn test_infer_value_type_boolean() {
        assert_eq!(infer_value_type("true"), InferredType::Boolean);
        assert_eq!(infer_value_type("false"), InferredType::Boolean);
        assert_eq!(infer_value_type("True"), InferredType::Boolean);
        assert_eq!(infer_value_type("FALSE"), InferredType::Boolean);
        assert_eq!(infer_value_type("yes"), InferredType::Boolean);
        assert_eq!(infer_value_type("no"), InferredType::Boolean);
        assert_eq!(infer_value_type("t"), InferredType::Boolean);
        assert_eq!(infer_value_type("f"), InferredType::Boolean);
        // "1" and "0" stay Integer
        assert_eq!(infer_value_type("1"), InferredType::Integer);
        assert_eq!(infer_value_type("0"), InferredType::Integer);
    }

    #[test]
    fn test_infer_value_type_date() {
        assert_eq!(infer_value_type("2024-01-15"), InferredType::Date);
        assert_eq!(infer_value_type("1999-12-31"), InferredType::Date);
        assert_eq!(infer_value_type("2024-1-15"), InferredType::Text); // not zero-padded
        assert_eq!(infer_value_type("2024/01/15"), InferredType::Text); // wrong separator
    }

    #[test]
    fn test_infer_value_type_timestamp() {
        assert_eq!(
            infer_value_type("2024-01-15T10:30:00"),
            InferredType::Timestamp
        );
        assert_eq!(
            infer_value_type("2024-01-15 10:30:00"),
            InferredType::Timestamp
        );
        assert_eq!(
            infer_value_type("2024-01-15T10:30:00.123Z"),
            InferredType::Timestamp
        );
        assert_eq!(
            infer_value_type("2024-01-15T10:30:00+05:00"),
            InferredType::Timestamp
        );
        assert_eq!(infer_value_type("2024-01-15T10"), InferredType::Text); // too short
    }

    #[test]
    fn test_type_widening() {
        use InferredType::*;
        assert_eq!(Integer.widen(Integer), Integer);
        assert_eq!(Integer.widen(Real), Real);
        assert_eq!(Real.widen(Integer), Real);
        assert_eq!(Integer.widen(Text), Text);
        assert_eq!(Real.widen(Text), Text);
        assert_eq!(Text.widen(Integer), Text);
    }

    #[test]
    fn test_type_widening_new_types() {
        use InferredType::*;
        // Boolean + numeric = numeric
        assert_eq!(Boolean.widen(Integer), Integer);
        assert_eq!(Integer.widen(Boolean), Integer);
        assert_eq!(Boolean.widen(Real), Real);
        assert_eq!(Real.widen(Boolean), Real);
        // Date + Timestamp = Timestamp
        assert_eq!(Date.widen(Timestamp), Timestamp);
        assert_eq!(Timestamp.widen(Date), Timestamp);
        // Date + Integer = Text (mismatch)
        assert_eq!(Date.widen(Integer), Text);
        assert_eq!(Integer.widen(Date), Text);
        // Boolean + Text = Text
        assert_eq!(Boolean.widen(Text), Text);
        // Date + Date = Date
        assert_eq!(Date.widen(Date), Date);
        // Boolean + Date = Text
        assert_eq!(Boolean.widen(Date), Text);
    }

    #[test]
    fn test_infer_table_schema() -> Result<()> {
        let dir = tempdir()?;
        let csv_path = dir.path().join("users.csv");

        let mut file = File::create(&csv_path)?;
        writeln!(file, "id,name,age,score")?;
        writeln!(file, "1,Alice,30,95.5")?;
        writeln!(file, "2,Bob,25,87.0")?;
        writeln!(file, "3,Charlie,35,92.5")?;

        let config = InferConfig::default();
        let table = infer_table_schema(&csv_path, &config)?;

        assert_eq!(table.name, "users");
        assert_eq!(table.columns.len(), 4);
        assert_eq!(table.columns[0].col_type, InferredType::Integer); // id
        assert_eq!(table.columns[1].col_type, InferredType::Text); // name
        assert_eq!(table.columns[2].col_type, InferredType::Integer); // age
        assert_eq!(table.columns[3].col_type, InferredType::Real); // score
        assert_eq!(table.suggested_pk, Some("id".to_string()));
        assert_eq!(table.row_count, 3);

        Ok(())
    }

    #[test]
    fn test_infer_nullable_column() -> Result<()> {
        let dir = tempdir()?;
        let csv_path = dir.path().join("data.csv");

        let mut file = File::create(&csv_path)?;
        writeln!(file, "id,value")?;
        writeln!(file, "1,hello")?;
        writeln!(file, "2,")?; // empty value
        writeln!(file, "3,world")?;

        let config = InferConfig::default();
        let table = infer_table_schema(&csv_path, &config)?;

        assert!(!table.columns[0].nullable); // id
        assert!(table.columns[1].nullable); // value has empty

        Ok(())
    }

    #[test]
    fn test_pk_detection_id_column() -> Result<()> {
        let dir = tempdir()?;
        let csv_path = dir.path().join("items.csv");

        let mut file = File::create(&csv_path)?;
        writeln!(file, "item_id,name")?;
        writeln!(file, "1,Apple")?;
        writeln!(file, "2,Banana")?;

        let config = InferConfig::default();
        let table = infer_table_schema(&csv_path, &config)?;

        assert_eq!(table.suggested_pk, Some("item_id".to_string()));

        Ok(())
    }

    #[test]
    fn test_pk_detection_unique_column() -> Result<()> {
        let dir = tempdir()?;
        let csv_path = dir.path().join("codes.csv");

        let mut file = File::create(&csv_path)?;
        writeln!(file, "code,description")?;
        writeln!(file, "A001,First")?;
        writeln!(file, "A002,Second")?;

        let config = InferConfig::default();
        let table = infer_table_schema(&csv_path, &config)?;

        // 'code' should be detected as PK (unique, non-nullable)
        assert_eq!(table.suggested_pk, Some("code".to_string()));

        Ok(())
    }

    #[test]
    fn test_no_pk_with_duplicates() -> Result<()> {
        let dir = tempdir()?;
        let csv_path = dir.path().join("logs.csv");

        let mut file = File::create(&csv_path)?;
        writeln!(file, "timestamp,message")?;
        writeln!(file, "2024-01-01,hello")?;
        writeln!(file, "2024-01-01,hello")?; // duplicate

        let config = InferConfig::default();
        let table = infer_table_schema(&csv_path, &config)?;

        // No PK because no unique column
        assert_eq!(table.suggested_pk, None);

        Ok(())
    }

    #[test]
    fn test_generate_ddl() -> Result<()> {
        let table = InferredTable {
            name: "users".to_string(),
            columns: vec![
                InferredColumn {
                    name: "id".to_string(),
                    col_type: InferredType::Integer,
                    nullable: false,
                    unique_values: None,
                },
                InferredColumn {
                    name: "name".to_string(),
                    col_type: InferredType::Text,
                    nullable: false,
                    unique_values: None,
                },
                InferredColumn {
                    name: "email".to_string(),
                    col_type: InferredType::Text,
                    nullable: true,
                    unique_values: None,
                },
            ],
            row_count: 10,
            suggested_pk: Some("id".to_string()),
            suggested_fks: Vec::new(),
        };

        let ddl = table.to_ddl();
        assert!(ddl.contains("CREATE TABLE \"users\""));
        assert!(ddl.contains("\"id\" INTEGER PRIMARY KEY"));
        assert!(ddl.contains("\"name\" TEXT NOT NULL"));
        assert!(ddl.contains("\"email\" TEXT\n")); // nullable, no NOT NULL

        Ok(())
    }

    #[test]
    fn test_generate_ddl_with_fk() -> Result<()> {
        let table = InferredTable {
            name: "orders".to_string(),
            columns: vec![
                InferredColumn {
                    name: "id".to_string(),
                    col_type: InferredType::Integer,
                    nullable: false,
                    unique_values: None,
                },
                InferredColumn {
                    name: "user_id".to_string(),
                    col_type: InferredType::Integer,
                    nullable: false,
                    unique_values: None,
                },
            ],
            row_count: 10,
            suggested_pk: Some("id".to_string()),
            suggested_fks: vec![SuggestedForeignKey {
                column: "user_id".to_string(),
                references_table: "users".to_string(),
                references_column: "id".to_string(),
            }],
        };

        let ddl = table.to_ddl();
        assert!(ddl.contains("\"user_id\" INTEGER NOT NULL REFERENCES \"users\"(\"id\")"));

        Ok(())
    }

    #[test]
    fn test_init_csvdb() -> Result<()> {
        let dir = tempdir()?;
        let source = dir.path().join("mydata");
        fs::create_dir(&source)?;

        // Create CSV files
        let mut users = File::create(source.join("users.csv"))?;
        writeln!(users, "id,name")?;
        writeln!(users, "1,Alice")?;
        writeln!(users, "2,Bob")?;

        let mut orders = File::create(source.join("orders.csv"))?;
        writeln!(orders, "order_id,user_id,amount")?;
        writeln!(orders, "100,1,99.99")?;
        writeln!(orders, "101,2,49.50")?;

        let config = InferConfig::default();
        let result = init_csvdb(
            &source,
            None,
            true,
            &TableFilter::new(vec![], vec![]),
            &config,
        )?;

        // Check output
        assert!(result.output_dir.to_string_lossy().ends_with(".csvdb"));
        assert!(result.output_dir.join("schema.sql").exists());
        assert!(result.output_dir.join("users.csv").exists());
        assert!(result.output_dir.join("orders.csv").exists());

        // Check schema content
        let schema = fs::read_to_string(result.output_dir.join("schema.sql"))?;
        assert!(schema.contains("CREATE TABLE \"orders\""));
        assert!(schema.contains("CREATE TABLE \"users\""));
        assert!(schema.contains("\"id\" INTEGER PRIMARY KEY"));
        assert!(schema.contains("\"order_id\" INTEGER PRIMARY KEY"));

        Ok(())
    }

    #[test]
    fn test_type_inference_mixed_column() -> Result<()> {
        let dir = tempdir()?;
        let csv_path = dir.path().join("mixed.csv");

        let mut file = File::create(&csv_path)?;
        writeln!(file, "id,value")?;
        writeln!(file, "1,100")?; // looks like integer
        writeln!(file, "2,hello")?; // text - should widen
        writeln!(file, "3,300")?;

        let config = InferConfig::default();
        let table = infer_table_schema(&csv_path, &config)?;

        // 'value' should be TEXT because of mixed types
        assert_eq!(table.columns[1].col_type, InferredType::Text);

        Ok(())
    }

    #[test]
    fn test_init_no_csv_files_error() -> Result<()> {
        let dir = tempdir()?;
        let source = dir.path().join("empty_dir");
        fs::create_dir(&source)?;

        let config = InferConfig::default();
        let result = init_csvdb(
            &source,
            None,
            true,
            &TableFilter::new(vec![], vec![]),
            &config,
        );

        assert!(result.is_err());
        let err = result.unwrap_err().to_string();
        assert!(err.contains("No CSV files"));

        Ok(())
    }

    #[test]
    fn test_init_creates_csvdb_toml() -> Result<()> {
        let dir = tempdir()?;
        let source = dir.path().join("data");
        fs::create_dir(&source)?;

        let mut file = File::create(source.join("test.csv"))?;
        writeln!(file, "id,value")?;
        writeln!(file, "1,hello")?;

        let config = InferConfig::default();
        let result = init_csvdb(
            &source,
            None,
            true,
            &TableFilter::new(vec![], vec![]),
            &config,
        )?;

        // Check csvdb.toml was created
        let toml_path = result.output_dir.join("csvdb.toml");
        assert!(toml_path.exists());

        let toml_content = fs::read_to_string(&toml_path)?;
        assert!(toml_content.contains("format_version"));
        assert!(toml_content.contains("created_by"));

        Ok(())
    }

    #[test]
    fn test_init_reinit_existing_csvdb() -> Result<()> {
        let dir = tempdir()?;
        let csvdb_dir = dir.path().join("existing.csvdb");
        fs::create_dir(&csvdb_dir)?;

        // Create a CSV in the .csvdb directory
        let mut file = File::create(csvdb_dir.join("data.csv"))?;
        writeln!(file, "id,name")?;
        writeln!(file, "1,Alice")?;

        let config = InferConfig::default();
        let result = init_csvdb(
            &csvdb_dir,
            None,
            true,
            &TableFilter::new(vec![], vec![]),
            &config,
        )?;

        // Should write schema in same directory (not create nested .csvdb)
        assert_eq!(result.output_dir, csvdb_dir);
        assert!(csvdb_dir.join("schema.sql").exists());

        Ok(())
    }

    #[test]
    fn test_init_single_row_pk_detection() -> Result<()> {
        let dir = tempdir()?;
        let csv_path = dir.path().join("single.csv");

        let mut file = File::create(&csv_path)?;
        writeln!(file, "id,value")?;
        writeln!(file, "1,hello")?;

        let config = InferConfig::default();
        let table = infer_table_schema(&csv_path, &config)?;

        // Single row should still detect id as PK
        assert_eq!(table.suggested_pk, Some("id".to_string()));
        assert_eq!(table.row_count, 1);

        Ok(())
    }

    #[test]
    fn test_init_null_marker_handling() -> Result<()> {
        let dir = tempdir()?;
        let csv_path = dir.path().join("nulls.csv");

        let mut file = File::create(&csv_path)?;
        writeln!(file, "id,value")?;
        writeln!(file, "1,hello")?;
        writeln!(file, "2,\\N")?; // \N is null marker
        writeln!(file, "3,world")?;

        let config = InferConfig::default();
        let table = infer_table_schema(&csv_path, &config)?;

        // \N should be treated as a value (nullable detection happens via empty)
        assert_eq!(table.columns[1].col_type, InferredType::Text);

        Ok(())
    }

    #[test]
    fn test_init_numeric_strings() -> Result<()> {
        let dir = tempdir()?;
        let csv_path = dir.path().join("phones.csv");

        let mut file = File::create(&csv_path)?;
        writeln!(file, "id,phone")?;
        writeln!(file, "1,0123456789")?; // Leading zero - should stay TEXT
        writeln!(file, "2,9876543210")?;

        let config = InferConfig::default();
        let table = infer_table_schema(&csv_path, &config)?;

        // Phone numbers with leading zeros need TEXT (would lose leading zero as INT)
        // Actually the current implementation would see this as INTEGER
        // This test documents current behavior - leading zeros are lost
        // (A future enhancement could detect this)
        assert_eq!(table.columns[1].col_type, InferredType::Integer);

        Ok(())
    }

    #[test]
    fn test_init_pk_disabled() -> Result<()> {
        let dir = tempdir()?;
        let csv_path = dir.path().join("data.csv");

        let mut file = File::create(&csv_path)?;
        writeln!(file, "id,value")?;
        writeln!(file, "1,hello")?;
        writeln!(file, "2,world")?;

        let config = InferConfig {
            detect_pk: false,
            ..Default::default()
        };
        let table = infer_table_schema(&csv_path, &config)?;

        // PK detection disabled
        assert_eq!(table.suggested_pk, None);

        Ok(())
    }

    #[test]
    fn test_init_all_null_column() -> Result<()> {
        let dir = tempdir()?;
        let csv_path = dir.path().join("nullcol.csv");

        let mut file = File::create(&csv_path)?;
        writeln!(file, "id,empty_col")?;
        writeln!(file, "1,")?;
        writeln!(file, "2,")?;

        let config = InferConfig::default();
        let table = infer_table_schema(&csv_path, &config)?;

        // Column with all empty values stays at default type (INTEGER)
        // and is marked nullable
        assert_eq!(table.columns[1].col_type, InferredType::Integer);
        assert!(table.columns[1].nullable);

        Ok(())
    }

    #[test]
    fn test_init_float_to_int_widening() -> Result<()> {
        let dir = tempdir()?;
        let csv_path = dir.path().join("widening.csv");

        let mut file = File::create(&csv_path)?;
        writeln!(file, "id,amount")?;
        writeln!(file, "1,100")?; // integer
        writeln!(file, "2,50.5")?; // float - should widen column to REAL

        let config = InferConfig::default();
        let table = infer_table_schema(&csv_path, &config)?;

        // Integer + Real = Real
        assert_eq!(table.columns[1].col_type, InferredType::Real);

        Ok(())
    }

    #[test]
    fn test_init_warning_for_no_pk() -> Result<()> {
        let dir = tempdir()?;
        let source = dir.path().join("no_pk_data");
        fs::create_dir(&source)?;

        // CSV with no unique column (duplicates in all columns)
        let mut file = File::create(source.join("events.csv"))?;
        writeln!(file, "timestamp,message")?;
        writeln!(file, "2024-01-01,event1")?;
        writeln!(file, "2024-01-01,event1")?; // completely duplicate row

        let config = InferConfig::default();
        let result = init_csvdb(
            &source,
            None,
            true,
            &TableFilter::new(vec![], vec![]),
            &config,
        )?;

        // Should have a warning about no PK
        assert!(!result.warnings.is_empty());
        assert!(result.warnings.iter().any(|w| w.contains("no primary key")));

        Ok(())
    }

    #[test]
    fn test_init_unicode_values() -> Result<()> {
        let dir = tempdir()?;
        let csv_path = dir.path().join("unicode.csv");

        let mut file = File::create(&csv_path)?;
        writeln!(file, "id,name")?;
        writeln!(file, "1,北京")?;
        writeln!(file, "2,東京")?;
        writeln!(file, "3,München")?;

        let config = InferConfig::default();
        let table = infer_table_schema(&csv_path, &config)?;

        assert_eq!(table.row_count, 3);
        assert_eq!(table.columns[1].col_type, InferredType::Text);

        Ok(())
    }

    #[test]
    fn test_fk_detection_basic() -> Result<()> {
        let dir = tempdir()?;
        let source = dir.path().join("fk_data");
        fs::create_dir(&source)?;

        let mut users = File::create(source.join("users.csv"))?;
        writeln!(users, "id,name")?;
        writeln!(users, "1,Alice")?;
        writeln!(users, "2,Bob")?;

        let mut orders = File::create(source.join("orders.csv"))?;
        writeln!(orders, "id,user_id,amount")?;
        writeln!(orders, "100,1,99.99")?;
        writeln!(orders, "101,2,49.50")?;

        let config = InferConfig::default();
        let result = init_csvdb(
            &source,
            None,
            true,
            &TableFilter::new(vec![], vec![]),
            &config,
        )?;

        // orders.user_id should reference users.id
        let orders_table = result.tables.iter().find(|t| t.name == "orders").unwrap();
        assert_eq!(orders_table.suggested_fks.len(), 1);
        assert_eq!(orders_table.suggested_fks[0].column, "user_id");
        assert_eq!(orders_table.suggested_fks[0].references_table, "users");
        assert_eq!(orders_table.suggested_fks[0].references_column, "id");

        // users should have no FKs
        let users_table = result.tables.iter().find(|t| t.name == "users").unwrap();
        assert!(users_table.suggested_fks.is_empty());

        // Check schema.sql contains REFERENCES
        let schema = fs::read_to_string(result.output_dir.join("schema.sql"))?;
        assert!(schema.contains("REFERENCES \"users\"(\"id\")"));

        Ok(())
    }

    #[test]
    fn test_fk_detection_plural_table() -> Result<()> {
        // Test: category_id -> categories (plural with -es suffix)
        let dir = tempdir()?;
        let source = dir.path().join("plural_data");
        fs::create_dir(&source)?;

        let mut categories = File::create(source.join("categories.csv"))?;
        writeln!(categories, "id,name")?;
        writeln!(categories, "1,Electronics")?;
        writeln!(categories, "2,Books")?;

        let mut products = File::create(source.join("products.csv"))?;
        writeln!(products, "id,category_id,name")?;
        writeln!(products, "1,1,Laptop")?;
        writeln!(products, "2,2,Novel")?;

        let config = InferConfig::default();
        let result = init_csvdb(
            &source,
            None,
            true,
            &TableFilter::new(vec![], vec![]),
            &config,
        )?;

        let products_table = result.tables.iter().find(|t| t.name == "products").unwrap();
        assert_eq!(products_table.suggested_fks.len(), 1);
        assert_eq!(products_table.suggested_fks[0].column, "category_id");
        assert_eq!(
            products_table.suggested_fks[0].references_table,
            "categories"
        );

        Ok(())
    }

    #[test]
    fn test_fk_detection_no_match() -> Result<()> {
        let dir = tempdir()?;
        let source = dir.path().join("no_fk_data");
        fs::create_dir(&source)?;

        let mut items = File::create(source.join("items.csv"))?;
        writeln!(items, "id,name,widget_id")?;
        writeln!(items, "1,Foo,42")?;
        writeln!(items, "2,Bar,43")?;

        let config = InferConfig::default();
        let result = init_csvdb(
            &source,
            None,
            true,
            &TableFilter::new(vec![], vec![]),
            &config,
        )?;

        // widget_id doesn't match any table, so no FK
        let items_table = result.tables.iter().find(|t| t.name == "items").unwrap();
        assert!(items_table.suggested_fks.is_empty());

        Ok(())
    }

    #[test]
    fn test_fk_detection_disabled() -> Result<()> {
        let dir = tempdir()?;
        let source = dir.path().join("fk_disabled");
        fs::create_dir(&source)?;

        let mut users = File::create(source.join("users.csv"))?;
        writeln!(users, "id,name")?;
        writeln!(users, "1,Alice")?;

        let mut orders = File::create(source.join("orders.csv"))?;
        writeln!(orders, "id,user_id,amount")?;
        writeln!(orders, "100,1,99.99")?;

        let config = InferConfig {
            detect_fk: false,
            ..Default::default()
        };
        let result = init_csvdb(
            &source,
            None,
            true,
            &TableFilter::new(vec![], vec![]),
            &config,
        )?;

        // FK detection disabled - no FKs
        let orders_table = result.tables.iter().find(|t| t.name == "orders").unwrap();
        assert!(orders_table.suggested_fks.is_empty());

        Ok(())
    }

    #[test]
    fn test_fk_detection_no_self_reference() -> Result<()> {
        // A column like employee_id in an employees table should not self-reference
        let dir = tempdir()?;
        let source = dir.path().join("self_ref");
        fs::create_dir(&source)?;

        let mut employees = File::create(source.join("employees.csv"))?;
        writeln!(employees, "id,name,employee_id")?;
        writeln!(employees, "1,Alice,1")?;
        writeln!(employees, "2,Bob,2")?;

        let config = InferConfig::default();
        let result = init_csvdb(
            &source,
            None,
            true,
            &TableFilter::new(vec![], vec![]),
            &config,
        )?;

        let emp_table = result
            .tables
            .iter()
            .find(|t| t.name == "employees")
            .unwrap();
        // employee_id would match "employees" via plural heuristic, but self-ref is skipped
        assert!(emp_table.suggested_fks.is_empty());

        Ok(())
    }

    #[test]
    fn test_fk_detection_multiple_fks() -> Result<()> {
        let dir = tempdir()?;
        let source = dir.path().join("multi_fk");
        fs::create_dir(&source)?;

        let mut users = File::create(source.join("users.csv"))?;
        writeln!(users, "id,name")?;
        writeln!(users, "1,Alice")?;
        writeln!(users, "2,Bob")?;

        let mut products = File::create(source.join("products.csv"))?;
        writeln!(products, "id,name")?;
        writeln!(products, "1,Widget")?;
        writeln!(products, "2,Gadget")?;

        let mut orders = File::create(source.join("orders.csv"))?;
        writeln!(orders, "id,user_id,product_id,amount")?;
        writeln!(orders, "100,1,1,99.99")?;
        writeln!(orders, "101,2,2,49.50")?;

        let config = InferConfig::default();
        let result = init_csvdb(
            &source,
            None,
            true,
            &TableFilter::new(vec![], vec![]),
            &config,
        )?;

        let orders_table = result.tables.iter().find(|t| t.name == "orders").unwrap();
        assert_eq!(orders_table.suggested_fks.len(), 2);

        let fk_cols: Vec<&str> = orders_table
            .suggested_fks
            .iter()
            .map(|fk| fk.column.as_str())
            .collect();
        assert!(fk_cols.contains(&"user_id"));
        assert!(fk_cols.contains(&"product_id"));

        Ok(())
    }

    #[test]
    fn test_fk_detection_requires_pk_on_target() -> Result<()> {
        let dir = tempdir()?;
        let source = dir.path().join("no_pk_target");
        fs::create_dir(&source)?;

        // Table with all duplicates (no PK detectable)
        let mut items = File::create(source.join("items.csv"))?;
        writeln!(items, "name,value")?;
        writeln!(items, "foo,1")?;
        writeln!(items, "foo,1")?;

        // Table referencing items
        let mut refs = File::create(source.join("refs.csv"))?;
        writeln!(refs, "id,item_id")?;
        writeln!(refs, "1,1")?;

        let config = InferConfig::default();
        let result = init_csvdb(
            &source,
            None,
            true,
            &TableFilter::new(vec![], vec![]),
            &config,
        )?;

        // items has no PK, so item_id -> items should NOT be inferred
        let items_table = result.tables.iter().find(|t| t.name == "items").unwrap();
        assert!(items_table.suggested_pk.is_none());

        let refs_table = result.tables.iter().find(|t| t.name == "refs").unwrap();
        assert!(refs_table.suggested_fks.is_empty());

        Ok(())
    }

    #[test]
    fn test_fk_detection_warns() -> Result<()> {
        let dir = tempdir()?;
        let source = dir.path().join("fk_warn");
        fs::create_dir(&source)?;

        let mut users = File::create(source.join("users.csv"))?;
        writeln!(users, "id,name")?;
        writeln!(users, "1,Alice")?;
        writeln!(users, "2,Bob")?;

        let mut orders = File::create(source.join("orders.csv"))?;
        writeln!(orders, "id,user_id,amount")?;
        writeln!(orders, "100,1,99.99")?;
        writeln!(orders, "101,2,49.50")?;

        let config = InferConfig::default();
        let result = init_csvdb(
            &source,
            None,
            true,
            &TableFilter::new(vec![], vec![]),
            &config,
        )?;

        // Should have a warning about inferred FK
        assert!(result
            .warnings
            .iter()
            .any(|w| w.contains("inferred foreign key")));
        assert!(result
            .warnings
            .iter()
            .any(|w| w.contains("user_id") && w.contains("users.id")));

        Ok(())
    }
}
