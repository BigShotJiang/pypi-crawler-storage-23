"""Dataset classes for handling graph edges, covariates, and sparse data."""
