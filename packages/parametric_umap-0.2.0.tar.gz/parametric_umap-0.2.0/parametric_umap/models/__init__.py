"""Neural network model architectures for parametric UMAP."""
