"""Utility functions for graph construction, loss computation, and helpers."""
