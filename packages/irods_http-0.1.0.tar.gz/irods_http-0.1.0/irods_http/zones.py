"""Zone operations for iRODS HTTP API."""

import requests

from . import common
from .irods_http import IRODSHTTPSession  # noqa: TC001


def add(session: IRODSHTTPSession, name: str, connection_info: str = "", comment: str = ""):
	"""
	Add a remote zone to the local zone. Requires rodsadmin privileges.

	Args:
	    session: An IRODSHTTPSession instance.
	    name: The name of the zone to be added.
	    connection_info: The host and port to connect to. If included, must be in the format <host>:<port>.
	    comment: The comment to attach to the zone.

	Returns:
	    A dict containing the HTTP status code and iRODS response.
	    The iRODS response is only valid if no error occurred during HTTP communication.
	"""
	common.validate_instance(name, str)
	common.validate_instance(connection_info, str)
	common.validate_instance(comment, str)

	data = {"op": "add", "name": name}

	if connection_info != "":
		data["connection-info"] = connection_info
	if comment != "":
		data["comment"] = comment

	r = requests.post(session.url_base + "/zones", headers=session.post_headers, data=data)  # noqa: S113
	return common.process_response(r)


def remove(session: IRODSHTTPSession, name: str):
	"""
	Remove a remote zone from the local zone. Requires rodsadmin privileges.

	Args:
	    session: An IRODSHTTPSession instance.
	    name: The zone to be removed.

	Returns:
	    A dict containing the HTTP status code and iRODS response.
	    The iRODS response is only valid if no error occurred during HTTP communication.
	"""
	common.validate_instance(name, str)

	data = {"op": "remove", "name": name}

	r = requests.post(session.url_base + "/zones", headers=session.post_headers, data=data)  # noqa: S113
	return common.process_response(r)


def modify(session: IRODSHTTPSession, name: str, property_: str, value: str):
	"""
	Modify properties of a remote zone. Requires rodsadmin privileges.

	Args:
	    session: An IRODSHTTPSession instance.
	    name: The name of the zone to be modified.
	    property_: The property to be modified. Can be set to 'name', 'connection_info', or 'comment'.
	              The value for 'connection_info' must be in the format <host>:<port>.
	    value: The new value to be set.

	Returns:
	    A dict containing the HTTP status code and iRODS response.
	    The iRODS response is only valid if no error occurred during HTTP communication.
	"""
	common.validate_instance(name, str)
	common.validate_instance(property_, str)
	common.validate_instance(value, str)

	data = {"op": "modify", "name": name, "property": property_, "value": value}

	r = requests.post(session.url_base + "/zones", headers=session.post_headers, data=data)  # noqa: S113
	return common.process_response(r)


def report(session: IRODSHTTPSession):
	"""
	Return information about the iRODS zone. Requires rodsadmin privileges.

	Args:
	    session: An IRODSHTTPSession instance.

	Returns:
	    A dict containing the HTTP status code and iRODS response.
	    The iRODS response is only valid if no error occurred during HTTP communication.
	"""
	params = {"op": "report"}

	r = requests.get(session.url_base + "/zones", headers=session.get_headers, params=params)  # noqa: S113
	return common.process_response(r)


def stat(session: IRODSHTTPSession, name: str):
	"""
	Return information about a named iRODS zone. Requires rodsadmin privileges.

	Args:
	    session: An IRODSHTTPSession instance.
	    name: The name of the zone.

	Returns:
	    A dict containing the HTTP status code and iRODS response.
	    The iRODS response is only valid if no error occurred during HTTP communication.
	"""
	common.validate_instance(name, str)

	params = {"op": "stat", "name": name}

	r = requests.get(session.url_base + "/zones", headers=session.get_headers, params=params)  # noqa: S113
	return common.process_response(r)
