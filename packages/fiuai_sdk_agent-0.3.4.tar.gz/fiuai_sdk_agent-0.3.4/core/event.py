# -- coding: utf-8 --
# Project: fiuai_sdk_agent
# Created Date: 2026-02-04
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2026 FiuAI

"""
EventBus - 事件总线抽象基类

设计要点:
- 抽象类: 只定义接口, 不实现业务逻辑
- 核心接口: 只有 publish(Event) 方法
- 业务层实现: EventPublisher 继承并实现

SDK EventBus 设计原则:
- EventBus 只暴露 publish(Event) 方法
- Helper 方法 (chunk, plan, interrupt 等) 在业务层实现
- 上下文管理 (set_context, clear_context) 在业务层实现

使用示例:
    # 业务层实现
    class EventPublisher(EventBus):
        def publish(self, event: Event) -> None:
            # 发送到 Redis Stream
            # 发送到 LangGraph Writer
            ...

        # Helper 方法 (业务层扩展)
        def chunk(self, content: str, done: bool = False) -> None:
            event = Event(type=EventType.CHUNK, data=ChunkData(...))
            self.publish(event)
"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..agents.types.event_type import Event


class EventBus(ABC):
    """
    事件总线抽象基类

    定义事件发布的核心接口, 业务层需要继承并实现具体逻辑

    设计原则:
    - SDK 层只定义 publish(Event) 核心接口
    - Helper 方法和上下文管理在业务层实现
    - 保持 SDK 层的简洁性和通用性
    """

    @abstractmethod
    def publish(self, event: "Event") -> None:
        """
        发布事件 (核心方法)

        这是 EventBus 唯一的抽象方法, 业务层必须实现

        Args:
            event: Event 对象, 包含:
                - type: EventType (CHUNK, PLAN, INTERRUPT, TASK, ARTIFACT, HEARTBEAT)
                - data: 类型化事件数据
                - context: 可选的 EventContext (路由上下文)
        """
        pass
