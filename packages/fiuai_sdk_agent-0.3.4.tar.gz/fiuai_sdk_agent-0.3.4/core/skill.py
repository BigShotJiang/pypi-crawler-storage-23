# -- coding: utf-8 --
# Project: fiuai_sdk_agent
# Created Date: 2026-02-04
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2026 FiuAI

"""
SkillRegistry - Skill 注册中心

设计要点:
- 装饰器注册: @SkillRegistry.register(...)
- 按领域组织: domain 字段
- 自动导出: 导出为 OpenAI Tool 格式

职责:
- 注册 Skill 定义
- 按名称/领域查询 Skill
- 导出 Tool Schema

使用示例:
    # 定义 Skill
    @SkillRegistry.register(
        name="verify_invoice",
        description="验证发票真伪",
        input_model=VerifyInvoiceInput,
        output_model=VerifyInvoiceOutput,
        domain="tax",
        tags=["invoice", "verification"],
    )
    async def verify_invoice(
        input: VerifyInvoiceInput,
        runtime: AgentRuntime
    ) -> VerifyInvoiceOutput:
        ...

    # 查询 Skill
    skill = SkillRegistry.get("verify_invoice")
    skills = SkillRegistry.get_by_domain("tax")

    # 导出为 OpenAI Tool
    tools = SkillRegistry.to_openai_tools(domain="tax")
"""

from typing import (
    TypeVar,
    Generic,
    Optional,
    List,
    Dict,
    Any,
    Callable,
    Type,
    Awaitable,
    Union,
)
from dataclasses import dataclass, field
from pydantic import BaseModel

from ..utils.logger import get_logger

logger = get_logger(__name__)

# 类型变量
InputT = TypeVar("InputT", bound=BaseModel)
OutputT = TypeVar("OutputT", bound=BaseModel)


@dataclass
class SkillDefinition:
    """
    Skill 定义

    Attributes:
        name: Skill 名称 (唯一标识)
        description: Skill 描述
        domain: 所属领域 (如 "tax", "finance", "data")
        tags: 标签列表
        input_model: 输入 Pydantic Model
        output_model: 输出 Pydantic Model
        func: Skill 函数
    """

    name: str
    description: str
    domain: str
    tags: List[str]
    input_model: Type[BaseModel]
    output_model: Type[BaseModel]
    func: Callable[..., Awaitable[Any]]

    def to_openai_tool(self) -> dict:
        """
        导出为 OpenAI Tool Schema

        Returns:
            OpenAI Function Calling 格式的 Tool 定义
        """
        # 从 Pydantic Model 生成 JSON Schema
        input_schema = self.input_model.model_json_schema()

        # 移除 title 和 description (已在外层定义)
        properties = input_schema.get("properties", {})
        required = input_schema.get("required", [])

        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required,
                },
            },
        }

    async def execute(self, input_data: Union[dict, BaseModel], runtime: Any) -> Any:
        """
        执行 Skill

        Args:
            input_data: 输入数据 (dict 或 Pydantic Model)
            runtime: AgentRuntime 实例

        Returns:
            Skill 执行结果
        """
        # 如果是 dict, 转换为 Pydantic Model
        if isinstance(input_data, dict):
            input_obj = self.input_model.model_validate(input_data)
        else:
            input_obj = input_data

        # 执行 Skill 函数
        return await self.func(input_obj, runtime)


class SkillRegistry:
    """
    Skill 注册中心 (单例模式)

    使用类方法实现全局注册, 支持装饰器方式注册 Skill
    """

    # 全局 Skill 存储
    _skills: Dict[str, SkillDefinition] = {}

    @classmethod
    def register(
        cls,
        name: str,
        description: str,
        input_model: Type[BaseModel],
        output_model: Type[BaseModel],
        domain: str = "common",
        tags: Optional[List[str]] = None,
    ) -> Callable:
        """
        注册 Skill 的装饰器

        Args:
            name: Skill 名称 (唯一标识)
            description: Skill 描述
            input_model: 输入 Pydantic Model
            output_model: 输出 Pydantic Model
            domain: 所属领域, 默认 "common"
            tags: 标签列表

        Returns:
            装饰器函数

        Usage:
            @SkillRegistry.register(
                name="verify_invoice",
                description="验证发票真伪",
                input_model=VerifyInvoiceInput,
                output_model=VerifyInvoiceOutput,
                domain="tax",
            )
            async def verify_invoice(input, runtime):
                ...
        """

        def decorator(func: Callable[..., Awaitable[Any]]) -> Callable:
            # 创建 SkillDefinition
            skill_def = SkillDefinition(
                name=name,
                description=description,
                domain=domain,
                tags=tags or [],
                input_model=input_model,
                output_model=output_model,
                func=func,
            )

            # 注册到全局存储
            if name in cls._skills:
                logger.warning(f"Skill '{name}' already registered, overwriting")
            cls._skills[name] = skill_def

            logger.debug(f"Registered skill: {name} (domain: {domain})")

            # 返回原函数 (不修改)
            return func

        return decorator

    @classmethod
    def get(cls, name: str) -> Optional[SkillDefinition]:
        """
        按名称获取 Skill

        Args:
            name: Skill 名称

        Returns:
            SkillDefinition 或 None
        """
        return cls._skills.get(name)

    @classmethod
    def get_by_domain(cls, domain: str) -> List[SkillDefinition]:
        """
        按领域获取 Skills

        Args:
            domain: 领域名称

        Returns:
            该领域下的 SkillDefinition 列表
        """
        return [s for s in cls._skills.values() if s.domain == domain]

    @classmethod
    def get_all(cls) -> List[SkillDefinition]:
        """
        获取所有 Skills

        Returns:
            所有 SkillDefinition 列表
        """
        return list(cls._skills.values())

    @classmethod
    def to_openai_tools(cls, domain: Optional[str] = None) -> List[dict]:
        """
        导出为 OpenAI Tool Schema 列表

        Args:
            domain: 领域名称, 如果为 None 则返回所有

        Returns:
            OpenAI Tool Schema 列表
        """
        if domain:
            skills = cls.get_by_domain(domain)
        else:
            skills = cls.get_all()

        return [s.to_openai_tool() for s in skills]

    @classmethod
    def clear(cls) -> None:
        """
        清空所有注册的 Skills (主要用于测试)
        """
        cls._skills.clear()

    @classmethod
    def count(cls) -> int:
        """
        获取注册的 Skill 数量

        Returns:
            Skill 数量
        """
        return len(cls._skills)
