# -- coding: utf-8 --
# Project: fiuai_sdk_agent
# Created Date: 2026-02-04
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2026 FiuAI

"""
PlanEngine - Plan 引擎抽象基类

设计要点:
- 抽象类: 只定义接口, 不实现业务逻辑
- 业务层实现: PlanManager 继承并实现
- 支持动态 Replan

职责:
- 定义计划管理的标准接口
- 提供计划生成、步骤管理的抽象方法

使用示例:
    # 业务层实现
    class PlanManager(PlanEngine):
        def generate_plan(self, goal, context) -> Plan:
            # 具体实现
            ...

        def replan(self, plan, step_result) -> Plan:
            # 具体实现
            ...
"""

from abc import ABC, abstractmethod
from typing import Optional, Dict, Any, List, TYPE_CHECKING

if TYPE_CHECKING:
    from ..agents.types.plan_type import Plan, PlanStep


class PlanEngine(ABC):
    """
    Plan 引擎抽象基类

    定义计划管理的标准接口, 业务层需要继承并实现具体逻辑
    """

    @abstractmethod
    def generate_plan(
        self,
        goal: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> "Plan":
        """
        生成计划

        Args:
            goal: 任务目标描述
            context: 上下文信息 (可选)

        Returns:
            Plan 对象
        """
        pass

    @abstractmethod
    def replan(
        self,
        plan: "Plan",
        step_result: Dict[str, Any],
    ) -> "Plan":
        """
        根据执行结果重新规划

        Args:
            plan: 当前计划
            step_result: 上一步的执行结果

        Returns:
            更新后的 Plan 对象
        """
        pass

    @abstractmethod
    def start_step(
        self,
        plan: "Plan",
        step_id: str,
    ) -> "Plan":
        """
        开始执行步骤

        Args:
            plan: 计划对象
            step_id: 步骤 ID

        Returns:
            更新后的 Plan 对象
        """
        pass

    @abstractmethod
    def complete_step(
        self,
        plan: "Plan",
        step_id: str,
        result: Optional[Dict[str, Any]] = None,
    ) -> "Plan":
        """
        完成步骤

        Args:
            plan: 计划对象
            step_id: 步骤 ID
            result: 执行结果 (可选)

        Returns:
            更新后的 Plan 对象
        """
        pass

    @abstractmethod
    def fail_step(
        self,
        plan: "Plan",
        step_id: str,
        error: str,
    ) -> "Plan":
        """
        标记步骤失败

        Args:
            plan: 计划对象
            step_id: 步骤 ID
            error: 错误信息

        Returns:
            更新后的 Plan 对象
        """
        pass

    def skip_step(
        self,
        plan: "Plan",
        step_id: str,
        reason: str = "",
    ) -> "Plan":
        """
        跳过步骤 (可选实现)

        Args:
            plan: 计划对象
            step_id: 步骤 ID
            reason: 跳过原因

        Returns:
            更新后的 Plan 对象
        """
        raise NotImplementedError("skip_step is optional, implement if needed")

    def add_step(
        self,
        plan: "Plan",
        step: "PlanStep",
        after_step_id: Optional[str] = None,
    ) -> "Plan":
        """
        动态添加步骤 (可选实现)

        Args:
            plan: 计划对象
            step: 要添加的步骤
            after_step_id: 在哪个步骤之后添加 (可选)

        Returns:
            更新后的 Plan 对象
        """
        raise NotImplementedError("add_step is optional, implement if needed")

    def get_executable_steps(self, plan: "Plan") -> List["PlanStep"]:
        """
        获取可执行的步骤 (可选实现)

        返回当前可以执行的步骤列表 (考虑依赖关系)

        Args:
            plan: 计划对象

        Returns:
            可执行的 PlanStep 列表
        """
        raise NotImplementedError(
            "get_executable_steps is optional, implement if needed"
        )
