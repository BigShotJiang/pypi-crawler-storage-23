# -- coding: utf-8 --
# Project: fiuai_sdk_agent
# Created Date: 2026-02-04
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2026 FiuAI

"""
AgentRuntime - 泛型运行时上下文容器

设计要点:
- 泛型设计: AgentRuntime[T], T 是业务上下文类型
- 依赖注入: 所有服务通过 Runtime 访问
- 不可变: 创建后不修改

职责:
- 持有业务上下文 (context)
- 提供 LLM 访问 (llm_manager)
- 提供 Skill 访问 (skill_registry)
- 持有可选服务 (context_manager, prompt_service)

使用示例:
    # 定义业务上下文
    class FiuaiContext:
        plan_manager: PlanManager
        event_publisher: EventPublisher
        ...

    # 创建 Runtime
    runtime = AgentRuntime(
        context=fiuai_context,
        llm_manager=llm_manager,
        skill_registry=skill_registry,
    )

    # 在 Node 中使用
    async def some_node(state: State, runtime: AgentRuntime[FiuaiContext]) -> dict:
        ctx = runtime.context
        await ctx.event_publisher.chunk("处理中...")
        llm = runtime.get_llm()
        ...
"""

from typing import TypeVar, Generic, Optional, List, TYPE_CHECKING
from dataclasses import dataclass, field

if TYPE_CHECKING:
    from ..pkg.llm.manager import LLMManager
    from ..agents.context.context_manager import AgentContextManager
    from ..agents.prompts.load import PromptService
    from .skill import SkillRegistry, SkillDefinition

# 泛型类型变量, 用于业务上下文
T = TypeVar("T")


@dataclass(frozen=True)
class AgentRuntime(Generic[T]):
    """
    泛型运行时上下文容器

    使用 dataclass(frozen=True) 确保不可变性

    Attributes:
        context: 业务上下文 (泛型 T)
        llm_manager: LLM 管理器
        skill_registry: Skill 注册中心
        context_manager: 上下文管理器 (可选)
        prompt_service: Prompt 服务 (可选)
    """

    # 业务上下文 (泛型)
    context: T

    # LLM 管理器
    llm_manager: "LLMManager"

    # Skill 注册中心
    skill_registry: "SkillRegistry"

    # 可选服务
    context_manager: Optional["AgentContextManager"] = field(default=None)
    prompt_service: Optional["PromptService"] = field(default=None)

    def get_llm(self, model: Optional[str] = None, **kwargs):
        """
        获取 LLM 实例

        Args:
            model: 模型名称, 如果为 None 则使用默认模型
            **kwargs: 其他 LLM 配置参数

        Returns:
            ChatOpenAI 实例
        """
        if model is None:
            return self.llm_manager.get_default_llm(**kwargs)
        return self.llm_manager.get_llm(model=model, **kwargs)

    def get_skill(self, name: str) -> Optional["SkillDefinition"]:
        """
        获取 Skill 定义

        Args:
            name: Skill 名称

        Returns:
            SkillDefinition 或 None
        """
        return self.skill_registry.get(name)

    def get_skills_by_domain(self, domain: str) -> List["SkillDefinition"]:
        """
        获取领域下的所有 Skills

        Args:
            domain: 领域名称 (如 "tax", "finance", "data")

        Returns:
            SkillDefinition 列表
        """
        return self.skill_registry.get_by_domain(domain)

    def get_skills_as_tools(self, domain: Optional[str] = None) -> List[dict]:
        """
        获取 Skills 的 OpenAI Tool Schema

        Args:
            domain: 领域名称, 如果为 None 则返回所有

        Returns:
            OpenAI Tool Schema 列表
        """
        return self.skill_registry.to_openai_tools(domain=domain)
