# -- coding: utf-8 --
# Project: llm
# Created Date: 2025 12 Sa
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI


class FiuaiLLMError(Exception):
    """
    LLM异常
    """
    pass