# -- coding: utf-8 --
# Project: prompts
# Created Date: 2025-01-30
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

from .load import (
    PromptService
)

__all__ = ["PromptService"]

