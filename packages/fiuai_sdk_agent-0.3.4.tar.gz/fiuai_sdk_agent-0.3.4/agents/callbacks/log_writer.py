# -- coding: utf-8 --
# Project: fiuai-ai
# Created Date: 2025-01-30
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

from typing import Optional, Callable, Any
from datetime import datetime
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_result

from fiuai_sdk_agent.utils.logger import get_logger
from fiuai_sdk_python.utils.ids import gen_id

from fiuai_sdk_agent.agents.callbacks.types import LLMUsageLog
from fiuai_sdk_agent.pkg.llm.price_config import get_model_price_config

logger = get_logger(__name__)

# 调用方注入的 session factory, 返回 sqlalchemy.orm.Session
SessionFactory = Callable[[], Any]

# 兼容旧版: 尝试加载 pkg.db 作为 fallback
try:
    from pkg.db import get_db_manager
    _LEGACY_DB_AVAILABLE = True
except ImportError:
    _LEGACY_DB_AVAILABLE = False
    get_db_manager = None


def _get_legacy_session() -> Any:
    """从 pkg.db 获取 session (兼容旧版, 无 session_factory 时 fallback)"""
    if not _LEGACY_DB_AVAILABLE or get_db_manager is None:
        return None
    db_manager = get_db_manager()
    if db_manager.engine is None:
        logger.warning("Database engine not initialized, please call init_db_from_settings first")
        return None
    return db_manager.get_session()


def _build_log_entry(
    task_id: Optional[str],
    task_name: Optional[str],
    agent_name: Optional[str],
    agent_type: Optional[str],
    caller: Optional[str],
    model: Optional[str],
    input_token: int,
    output_token: int,
    start_time: Optional[datetime],
    end_time: Optional[datetime],
    user_id: Optional[str],
    auth_tenant_id: Optional[str],
    auth_company_id: Optional[str],
) -> LLMUsageLog:
    """构建 LLMUsageLog 记录对象"""
    price_config = get_model_price_config()
    price = price_config.get_price(model) if model else None

    input_price = 0.0
    output_price = 0.0
    input_cost = 0.0
    output_cost = 0.0
    if price:
        input_price = price.input_price_per_1k
        output_price = price.output_price_per_1k
        input_cost = (input_token / 1000.0) * input_price
        output_cost = (output_token / 1000.0) * output_price

    now = datetime.now()
    record_time = int(now.timestamp() * 1000)
    start_time_ms = int(start_time.timestamp() * 1000) if start_time else record_time
    end_time_ms = int(end_time.timestamp() * 1000) if end_time else record_time

    return LLMUsageLog(
        name=gen_id(),
        creation=now,
        modified=now,
        owner=user_id or "",
        docstatus=0,
        idx=0,
        task_id=task_id or "",
        task_name=task_name or "",
        agent_name=agent_name or "",
        agent_type=agent_type or "",
        caller=caller or "",
        record_time=record_time,
        model=model or "",
        input_token=input_token,
        input_price=input_price,
        input_cost=input_cost,
        output_token=output_token,
        output_price=output_price,
        output_cost=output_cost,
        user_id=user_id or "",
        auth_tenant_id=auth_tenant_id or "",
        auth_company_id=auth_company_id or "",
        start_time=start_time_ms,
        end_time=end_time_ms,
    )


@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=4, max=15),
    retry=retry_if_result(lambda result: result is False)
)
async def write_llm_usage_log(
    task_id: Optional[str] = None,
    task_name: Optional[str] = None,
    agent_name: Optional[str] = None,
    agent_type: Optional[str] = None,
    caller: Optional[str] = None,
    model: Optional[str] = None,
    input_token: int = 0,
    output_token: int = 0,
    start_time: Optional[datetime] = None,
    end_time: Optional[datetime] = None,
    user_id: Optional[str] = None,
    auth_tenant_id: Optional[str] = None,
    auth_company_id: Optional[str] = None,
    session_factory: Optional[SessionFactory] = None,
) -> bool:
    """
    异步写入 LLM 使用日志到数据库

    session_factory 由调用方注入, 返回 sqlalchemy.orm.Session 实例。
    未传入时 fallback 到 pkg.db (兼容旧版)。

    Args:
        task_id: 任务 ID
        task_name: 任务名称
        agent_name: Agent 名称
        agent_type: Agent 类型 (supervisor/expert)
        caller: 调用者标识 (agent 内的具体操作)
        model: 模型名称
        input_token: 输入 token 数
        output_token: 输出 token 数
        start_time: 开始时间
        end_time: 结束时间
        user_id: 用户 ID
        auth_tenant_id: 租户 ID
        auth_company_id: 公司 ID
        session_factory: 可选的 session 工厂函数, 返回 sqlalchemy.orm.Session

    Returns:
        bool: 写入是否成功
    """
    try:
        session = session_factory() if session_factory else _get_legacy_session()
        if session is None:
            logger.warning("No database session available, skipping llm_usage_log write")
            return False

        log_entry = _build_log_entry(
            task_id=task_id,
            task_name=task_name,
            agent_name=agent_name,
            agent_type=agent_type,
            caller=caller,
            model=model,
            input_token=input_token,
            output_token=output_token,
            start_time=start_time,
            end_time=end_time,
            user_id=user_id,
            auth_tenant_id=auth_tenant_id,
            auth_company_id=auth_company_id,
        )

        logger.info(
            "[write_llm_usage_log] insert: name=%s task_id=%s agent=%s(%s) caller=%s model=%s "
            "input_token=%s output_token=%s input_cost=%.6f output_cost=%.6f",
            log_entry.name, task_id, agent_name, agent_type, caller, model,
            input_token, output_token, log_entry.input_cost, log_entry.output_cost,
        )

        try:
            session.add(log_entry)
            session.commit()
            logger.info(
                "[write_llm_usage_log] success: name=%s task_id=%s model=%s",
                log_entry.name, task_id, model,
            )
            return True
        except Exception as e:
            session.rollback()
            raise e
        finally:
            session.close()

    except Exception as e:
        logger.error(
            "[write_llm_usage_log] exception: %s, task_id=%s, model=%s",
            e, task_id, model,
        )
        import traceback
        logger.error("[write_llm_usage_log] traceback: %s", traceback.format_exc())
        return False
