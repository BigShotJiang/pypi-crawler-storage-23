# -- coding: utf-8 --
# Project: fiuai-ai
# Created Date: 2025-01-30
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

from sqlalchemy import Column, String, Integer, Float, BigInteger, DateTime
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


class LLMUsageLog(Base):
    """
    LLM 使用日志表模型
    对应数据库表: tabllm_usage_log
    """
    __tablename__ = "tabllm_usage_log"

    # Frappe 标准字段
    name = Column(String, primary_key=True, comment="唯一标识")
    creation = Column(DateTime, nullable=True, comment="创建时间")
    modified = Column(DateTime, nullable=True, comment="修改时间")
    owner = Column(String, nullable=True, comment="所有者")
    docstatus = Column(Integer, default=0, comment="文档状态")
    idx = Column(Integer, default=0, comment="索引")

    # 业务字段
    task_id = Column(String, nullable=True, comment="任务 ID")
    task_name = Column(String, nullable=True, comment="任务名称")
    record_time = Column(BigInteger, nullable=True, comment="记录时间（毫秒时间戳）")
    model = Column(String, nullable=True, comment="模型名称")

    # Token 和价格相关
    input_token = Column(Integer, default=0, comment="输入 token 数")
    input_price = Column(Float, default=0.0, comment="输入价格（元/千 token）")
    input_cost = Column(Float, default=0.0, comment="输入费用（元）")

    output_token = Column(Integer, default=0, comment="输出 token 数")
    output_price = Column(Float, default=0.0, comment="输出价格（元/千 token）")
    output_cost = Column(Float, default=0.0, comment="输出费用（元）")

    # Agent 信息
    agent_name = Column(String, nullable=True, default="", comment="Agent 名称")
    agent_type = Column(String, nullable=True, default="", comment="Agent 类型 (supervisor/expert)")
    caller = Column(String, nullable=True, default="", comment="调用者标识 (agent 内的具体操作)")

    # 用户和租户信息
    user_id = Column(String, nullable=True, comment="用户 ID")
    auth_tenant_id = Column(String, nullable=True, comment="租户 ID")
    auth_company_id = Column(String, nullable=True, comment="公司 ID")

    # 时间字段
    start_time = Column(BigInteger, nullable=True, comment="开始时间（毫秒时间戳）")
    end_time = Column(BigInteger, nullable=True, comment="结束时间（毫秒时间戳）")

    def __repr__(self):
        return (
            f"<LLMUsageLog(name='{self.name}', task_id='{self.task_id}', "
            f"model='{self.model}', input_token={self.input_token}, "
            f"output_token={self.output_token})>"
        )
