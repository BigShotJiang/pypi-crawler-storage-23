# -- coding: utf-8 --
# Project: fiuai-ai
# Created Date: 2025-01-30
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

import asyncio
from typing import Dict, Any, List, Optional, Callable
from datetime import datetime

from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.messages import BaseMessage
from langchain_core.outputs import LLMResult

from fiuai_sdk_agent.utils.logger import get_logger
from fiuai_sdk_agent.agents.callbacks.log_writer import write_llm_usage_log, SessionFactory

logger = get_logger(__name__)


class LLMDatabaseLogCallback(BaseCallbackHandler):
    """
    数据库日志回调函数

    将 LLM 使用情况写入数据库。
    session_factory 由调用方注入, 使 SDK 不耦合具体的数据库基础设施。
    """

    def __init__(
        self,
        task_id: Optional[str] = None,
        task_name: Optional[str] = None,
        agent_name: Optional[str] = None,
        agent_type: Optional[str] = None,
        caller: Optional[str] = None,
        user_id: Optional[str] = None,
        auth_tenant_id: Optional[str] = None,
        auth_company_id: Optional[str] = None,
        session_factory: Optional[SessionFactory] = None,
    ):
        """
        初始化回调函数

        Args:
            task_id: 任务 ID
            task_name: 任务名称
            agent_name: Agent 名称
            agent_type: Agent 类型 (supervisor/expert)
            caller: 调用者标识 (agent 内的具体操作)
            user_id: 用户 ID
            auth_tenant_id: 租户 ID
            auth_company_id: 公司 ID
            session_factory: 数据库 session 工厂, 返回 sqlalchemy.orm.Session
        """
        super().__init__()
        self.task_id = task_id
        self.task_name = task_name
        self.agent_name = agent_name or ""
        self.agent_type = agent_type or ""
        self.caller = caller or ""
        self.user_id = user_id
        self.auth_tenant_id = auth_tenant_id
        self.auth_company_id = auth_company_id
        self.session_factory = session_factory
        self.model = "unknown"
        self.start_time: Optional[datetime] = None
        self.end_time: Optional[datetime] = None

    def on_chat_model_start(
        self, serialized: Dict[str, Any], messages: List[List[BaseMessage]], **kwargs
    ) -> None:
        """LLM 请求开始"""
        self.start_time = datetime.now()

        if "invocation_params" in kwargs:
            invocation_params = kwargs.get("invocation_params", {})
            self.model = invocation_params.get("model", "unknown")

    def _build_write_kwargs(self, prompt_tokens: int, completion_tokens: int) -> Dict[str, Any]:
        """构建 write_llm_usage_log 的调用参数"""
        return dict(
            task_id=self.task_id,
            task_name=self.task_name,
            agent_name=self.agent_name,
            agent_type=self.agent_type,
            caller=self.caller,
            model=self.model,
            input_token=prompt_tokens,
            output_token=completion_tokens,
            start_time=self.start_time,
            end_time=self.end_time,
            user_id=self.user_id,
            auth_tenant_id=self.auth_tenant_id,
            auth_company_id=self.auth_company_id,
            session_factory=self.session_factory,
        )

    def on_llm_end(self, response: LLMResult, **kwargs) -> None:
        """LLM 请求结束"""
        self.end_time = datetime.now()

        try:
            serialized_response = response.model_dump(mode="json")
            llm_output = serialized_response.get("llm_output", {})
            token_usage = llm_output.get("token_usage", {}) if isinstance(llm_output, dict) else {}

            prompt_tokens = token_usage.get("prompt_tokens", 0)
            completion_tokens = token_usage.get("completion_tokens", 0)
            write_kwargs = self._build_write_kwargs(prompt_tokens, completion_tokens)

            self._dispatch_write(write_kwargs)

        except Exception as e:
            logger.warning("[LLM DB Log] failed to write database log: %s", e)

    # ------------------------------------------------------------------
    # 异步调度: 适配不同的事件循环状态
    # ------------------------------------------------------------------

    def _dispatch_write(self, write_kwargs: Dict[str, Any]) -> None:
        """根据当前事件循环状态选择写入方式"""
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                task = asyncio.create_task(write_llm_usage_log(**write_kwargs))
                task.add_done_callback(self._on_write_done)
                return
            loop.run_until_complete(write_llm_usage_log(**write_kwargs))
            return
        except RuntimeError:
            pass

        # fallback: 没有事件循环, 新开线程
        import threading

        def _run():
            try:
                new_loop = asyncio.new_event_loop()
                asyncio.set_event_loop(new_loop)
                new_loop.run_until_complete(write_llm_usage_log(**write_kwargs))
                new_loop.close()
            except Exception as e:
                logger.error(
                    "[LLM DB Log] thread fallback failed: %s, model=%s, task_id=%s",
                    e, self.model, self.task_id,
                )

        threading.Thread(target=_run, daemon=True).start()

    def _on_write_done(self, t: asyncio.Task) -> None:
        """异步任务完成回调"""
        try:
            exc = t.exception()
            if exc:
                logger.error(
                    "[LLM DB Log] async task failed: %s, model=%s, task_id=%s",
                    exc, self.model, self.task_id,
                )
        except Exception as e:
            logger.warning("[LLM DB Log] error in task callback: %s", e)
