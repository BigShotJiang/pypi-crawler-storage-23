# -- coding: utf-8 --
# Project: types
# Created Date: 2025 12 Tu
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List, Any
from langchain_core.messages import BaseMessage

from fiuai_sdk_python.auth.type import AuthData
from fiuai_sdk_python.profile import UserProfileInfo

from .intent_type import UserIntent
from .plan_type import BasePlan


class BasicUserContext(BaseModel):
    """
    薄类型用户上下文，由 SDK get_auth_data/get_trace_id/get_user_profile_info 组装。
    兼容原 user_simple_auth_info 访问：user_simple_auth_info 即 auth_data。
    """
    model_config = ConfigDict(arbitrary_types_allowed=True)

    auth_data: Optional[AuthData] = Field(default=None, description="认证数据")
    trace_id: str = Field(default="", description="追踪ID")
    user_profile_info: Optional[UserProfileInfo] = None

    @property
    def user_simple_auth_info(self) -> Optional[AuthData]:
        """兼容模板与 state 中 user_context.user_simple_auth_info 的访问"""
        return self.auth_data

    @property
    def user_id(self) -> Optional[str]:
        return self.auth_data.user_id if self.auth_data else None

    @property
    def auth_tenant_id(self) -> Optional[str]:
        return self.auth_data.auth_tenant_id if self.auth_data else None

    @property
    def auth_company_id(self) -> Optional[str]:
        return (self.auth_data.current_company if self.auth_data else None) or None


class BasicStateInfo(BaseModel):
    """基础状态信息,所有任务状态都需要实现"""
    model_config = ConfigDict(
        arbitrary_types_allowed=True,
        # 允许序列化复杂类型
        ser_json_timedelta='iso8601',
    )
    
    thread_id: str = Field(description="会话线程ID")
    user_context: BasicUserContext = Field(
        default_factory=BasicUserContext,
        description="用户上下文",
    )
    user_input: str = Field(description="用户本轮输入")
    chat_log_id: str = Field(description="聊天日志ID,对应AIChatLog.name")
    chat_history: List[BaseMessage] = Field(description="用户交互消息列表,仅包含用户提问和agent回答,不包含系统消息")

    intent: Optional[UserIntent] = Field(default=None, description="用户意图")
    plan: Optional[BasePlan] = Field(default=None, description="任务计划, 简单任务可以没有计划对象")

