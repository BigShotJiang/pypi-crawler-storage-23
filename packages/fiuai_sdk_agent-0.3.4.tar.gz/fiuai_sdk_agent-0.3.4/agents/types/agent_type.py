# -- coding: utf-8 --
# Project: agents
# Created Date: 2025-01-29
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

from enum import StrEnum


class AgentType(StrEnum):
    """
    Agent 类型
    
    架构层级:
    - SUPERVISOR: 调度层, 负责任务规划和 Expert 调度
    - EXPERT: 专家层, 领域专家, 负责领域决策和 Skill 编排
    - SERVICE: 服务层, 不参与编排的独立 Agent (如文档摘要、数据清洗等)
    """
    SUPERVISOR = "supervisor"
    EXPERT = "expert"
    SERVICE = "service"


class ExpertType(StrEnum):
    """
    Expert 类型 (领域专家)
    """
    DATA = "data"
    TAX = "tax"
    FINANCE = "finance"
    CASH = "cash"
    IDP = "idp"

