# -- coding: utf-8 --
# Project: fiuai-sdk-agent
# Created Date: 2026-02-04
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2026 FiuAI

"""
Artifact 类型定义

Artifact 是统一的内容展示对象, 用于在前端渲染各类内容

设计原则:
- artifact_type 可自由扩展
- artifact_data 是类型化 Dict, 不是字符串
- 不同类型有不同的 data 结构
"""

from enum import StrEnum
from typing import Optional, Dict, List, Any
from pydantic import BaseModel, Field


class ArtifactType(StrEnum):
    """
    Artifact 类型枚举
    
    可扩展: 新增类型只需添加枚举值, 不影响 EventType
    """
    # 平台文档(Frappe DocType)
    PLATFORM_DOCUMENT = "platform_document"
    # 图片
    IMAGE = "image"
    # PDF 文件
    PDF = "pdf"
    # 纯文本
    TEXT = "text"
    # JSON 数据
    JSON = "json"
    # Markdown
    MARKDOWN = "markdown"
    # HTML
    HTML = "html"
    # CSV/表格数据
    CSV = "csv"
    DATASET = "dataset"
    # 图表
    CHART = "chart"
    # 代码
    CODE = "code"
    # Python 代码(特殊处理)
    PYTHON = "python"


class Artifact(BaseModel):
    """
    Artifact 内容展示对象
    
    通过 ARTIFACT 事件发送给前端, 前端根据 artifact_type 渲染不同的 UI
    """
    artifact_type: str = Field(description="artifact 类型")
    artifact_name: str = Field(description="显示名称")
    artifact_data: Dict[str, Any] = Field(description="类型化数据(不是字符串)")


# ============================================================================
# 各类型的 artifact_data 结构定义
# ============================================================================

class PlatformDocumentData(BaseModel):
    """平台文档数据"""
    doctype: str = Field(description="文档类型")
    doc_id: str = Field(description="文档 ID")


class ImageData(BaseModel):
    """图片数据"""
    url: str = Field(description="图片 URL")
    thumbnail_url: Optional[str] = Field(default=None, description="缩略图 URL")
    width: Optional[int] = Field(default=None, description="宽度")
    height: Optional[int] = Field(default=None, description="高度")
    alt: Optional[str] = Field(default=None, description="替代文本")


class PdfData(BaseModel):
    """PDF 数据"""
    url: str = Field(description="PDF URL")
    page_count: Optional[int] = Field(default=None, description="页数")


class TextData(BaseModel):
    """文本数据"""
    content: str = Field(description="文本内容")


class MarkdownData(BaseModel):
    """Markdown 数据"""
    content: str = Field(description="Markdown 内容")


class JsonData(BaseModel):
    """JSON 数据"""
    data: Any = Field(description="JSON 数据")
    expandable: bool = Field(default=True, description="是否可展开")
    default_expand_level: int = Field(default=2, description="默认展开层级")


class TableColumn(BaseModel):
    """表格列定义"""
    key: str = Field(description="列 key")
    title: str = Field(description="列标题")
    data_index: str = Field(description="数据索引")
    width: Optional[int] = Field(default=None, description="列宽")


class DatasetData(BaseModel):
    """表格/数据集数据"""
    columns: List[TableColumn] = Field(description="列定义")
    rows: List[Dict[str, Any]] = Field(description="行数据")
    total: Optional[int] = Field(default=None, description="总行数")


class ChartSeries(BaseModel):
    """图表系列"""
    name: str = Field(description="系列名称")
    data: List[Any] = Field(description="系列数据")


class ChartData(BaseModel):
    """图表数据"""
    chart_type: str = Field(description="图表类型: bar, line, pie, ...")
    title: Optional[str] = Field(default=None, description="图表标题")
    x_axis: Optional[List[str]] = Field(default=None, description="X 轴标签")
    series: List[ChartSeries] = Field(description="数据系列")


class CodeData(BaseModel):
    """代码数据"""
    language: str = Field(description="编程语言")
    content: str = Field(description="代码内容")
    editable: bool = Field(default=False, description="是否可编辑")


# ============================================================================
# 便捷工厂函数
# ============================================================================

def create_platform_document_artifact(
    name: str,
    doctype: str,
    doc_id: str,
) -> Artifact:
    """创建平台文档 Artifact"""
    return Artifact(
        artifact_type=ArtifactType.PLATFORM_DOCUMENT,
        artifact_name=name,
        artifact_data=PlatformDocumentData(doctype=doctype, doc_id=doc_id).model_dump(),
    )


def create_image_artifact(
    name: str,
    url: str,
    width: Optional[int] = None,
    height: Optional[int] = None,
) -> Artifact:
    """创建图片 Artifact"""
    return Artifact(
        artifact_type=ArtifactType.IMAGE,
        artifact_name=name,
        artifact_data=ImageData(url=url, width=width, height=height).model_dump(),
    )


def create_text_artifact(name: str, content: str) -> Artifact:
    """创建文本 Artifact"""
    return Artifact(
        artifact_type=ArtifactType.TEXT,
        artifact_name=name,
        artifact_data=TextData(content=content).model_dump(),
    )


def create_markdown_artifact(name: str, content: str) -> Artifact:
    """创建 Markdown Artifact"""
    return Artifact(
        artifact_type=ArtifactType.MARKDOWN,
        artifact_name=name,
        artifact_data=MarkdownData(content=content).model_dump(),
    )


def create_json_artifact(name: str, data: Any) -> Artifact:
    """创建 JSON Artifact"""
    return Artifact(
        artifact_type=ArtifactType.JSON,
        artifact_name=name,
        artifact_data=JsonData(data=data).model_dump(),
    )


def create_dataset_artifact(
    name: str,
    columns: List[Dict[str, str]],
    rows: List[Dict[str, Any]],
    total: Optional[int] = None,
) -> Artifact:
    """创建表格/数据集 Artifact"""
    table_columns = [
        TableColumn(
            key=col.get("key", col.get("title", "")),
            title=col.get("title", ""),
            data_index=col.get("data_index", col.get("key", "")),
        )
        for col in columns
    ]
    return Artifact(
        artifact_type=ArtifactType.DATASET,
        artifact_name=name,
        artifact_data=DatasetData(
            columns=table_columns,
            rows=rows,
            total=total or len(rows),
        ).model_dump(),
    )


def create_chart_artifact(
    name: str,
    chart_type: str,
    series: List[Dict[str, Any]],
    x_axis: Optional[List[str]] = None,
    title: Optional[str] = None,
) -> Artifact:
    """创建图表 Artifact"""
    chart_series = [
        ChartSeries(name=s.get("name", ""), data=s.get("data", []))
        for s in series
    ]
    return Artifact(
        artifact_type=ArtifactType.CHART,
        artifact_name=name,
        artifact_data=ChartData(
            chart_type=chart_type,
            title=title,
            x_axis=x_axis,
            series=chart_series,
        ).model_dump(),
    )


def create_code_artifact(
    name: str,
    language: str,
    content: str,
    editable: bool = False,
) -> Artifact:
    """创建代码 Artifact"""
    return Artifact(
        artifact_type=ArtifactType.CODE if language != "python" else ArtifactType.PYTHON,
        artifact_name=name,
        artifact_data=CodeData(
            language=language,
            content=content,
            editable=editable,
        ).model_dump(),
    )
