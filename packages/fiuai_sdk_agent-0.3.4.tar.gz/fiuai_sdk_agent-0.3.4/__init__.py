# -- coding: utf-8 --
# Project: fiuai-sdk-agent
# Created Date: 2025-01-30
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
FiuAI SDK Agent

A framework for building AI agents with LLM support, context management, and event handling.

架构分层:
- core/: 核心抽象层 (AgentRuntime, SkillRegistry, PlanEngine, EventBus)
- graph/: LangGraph 辅助 (BaseAgentState, create_node)
- agents/: Agent 基础设施 (保留兼容, 将迁移到 infra/)
- pkg/: 基础包 (保留兼容, 将迁移到 infra/)
"""

__version__ = "0.3.1"

# ============================================================================
# Core - 核心抽象层
# ============================================================================
from fiuai_sdk_agent.core import (
    AgentRuntime,
    SkillRegistry,
    SkillDefinition,
    PlanEngine,
    EventBus,
)

# ============================================================================
# Infra - 基础设施抽象层
# ============================================================================
from fiuai_sdk_agent.infra.embedding import EmbeddingEngine, OpenAICompatibleEmbeddingEngine
from fiuai_sdk_agent.infra.vector import VectorStoreEngine, QdrantVectorStore, VectorSearchResult

# ============================================================================
# Prompting - Prompt 模板引擎
# ============================================================================
from fiuai_sdk_agent.prompting import PromptTemplate

# ============================================================================
# Graph - LangGraph 辅助
# ============================================================================
from fiuai_sdk_agent.graph import (
    BaseAgentState,
    create_node,
    NodeFunc,
)

# ============================================================================
# Legacy - 保留兼容 (将在后续版本重构)
# ============================================================================
from fiuai_sdk_agent.agents import Agent, AgentType
from fiuai_sdk_agent.pkg.llm import LLMManager, LLMRequestConfig, LLMResponse
from fiuai_sdk_agent.pkg.llm.types import LLMModel

__all__ = [
    # Core
    "AgentRuntime",
    "SkillRegistry",
    "SkillDefinition",
    "PlanEngine",
    "EventBus",
    # Infra
    "EmbeddingEngine",
    "OpenAICompatibleEmbeddingEngine",
    "VectorStoreEngine",
    "QdrantVectorStore",
    "VectorSearchResult",
    # Prompting
    "PromptTemplate",
    # Graph
    "BaseAgentState",
    "create_node",
    "NodeFunc",
    # Legacy
    "Agent",
    "AgentType",
    "LLMManager",
    "LLMRequestConfig",
    "LLMResponse",
    "LLMModel",
]
