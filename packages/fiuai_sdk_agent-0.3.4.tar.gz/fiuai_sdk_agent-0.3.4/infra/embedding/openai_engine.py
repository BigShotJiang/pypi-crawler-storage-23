# -- coding: utf-8 --
# Project: fiuai-ai
# Created Date: 2026-02-26
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
OpenAICompatibleEmbeddingEngine - 基于 OpenAI 兼容 API 的 Embedding 实现

支持阿里云 DashScope / OpenAI / 本地 Ollama 等兼容 API
"""

import logging
from typing import List, Optional

from fiuai_sdk_agent.infra.embedding.engine import EmbeddingEngine

logger = logging.getLogger(__name__)


class OpenAICompatibleEmbeddingEngine(EmbeddingEngine):
    """基于 OpenAI 兼容 API 的 Embedding 实现"""

    def __init__(
        self,
        api_key: str,
        base_url: str,
        model: str = "text-embedding-v3",
        dimensions: int = 1024,
        timeout: Optional[float] = 60.0,
    ):
        if not api_key:
            raise ValueError("api_key is required")
        if not base_url:
            raise ValueError("base_url is required")

        self._api_key = api_key
        self._base_url = base_url
        self._model = model
        self._dimensions = dimensions
        self._timeout = timeout
        self._client = None

    @property
    def client(self):
        """延迟初始化 AsyncOpenAI client"""
        if self._client is None:
            try:
                from openai import AsyncOpenAI
            except ImportError as e:
                raise ImportError(
                    "openai package is required for OpenAICompatibleEmbeddingEngine. "
                    "Install it with: pip install openai"
                ) from e

            self._client = AsyncOpenAI(
                api_key=self._api_key,
                base_url=self._base_url,
                timeout=self._timeout,
            )
        return self._client

    @property
    def dimension(self) -> int:
        return self._dimensions

    async def embed_text(self, text: str) -> List[float]:
        if not text or not text.strip():
            raise ValueError("Input text cannot be empty")

        text = text.strip()
        try:
            response = await self.client.embeddings.create(
                model=self._model,
                input=text,
            )
            return response.data[0].embedding
        except Exception as e:
            logger.error("Failed to embed text: model=%s err=%s", self._model, e)
            raise

    async def embed_texts(self, texts: List[str]) -> List[List[float]]:
        if not texts:
            return []

        cleaned = [t.strip() for t in texts if t and t.strip()]
        if not cleaned:
            return []

        try:
            response = await self.client.embeddings.create(
                model=self._model,
                input=cleaned,
            )
            return [item.embedding for item in response.data]
        except Exception as e:
            logger.error("Failed to embed %d texts: model=%s err=%s", len(cleaned), self._model, e)
            raise
