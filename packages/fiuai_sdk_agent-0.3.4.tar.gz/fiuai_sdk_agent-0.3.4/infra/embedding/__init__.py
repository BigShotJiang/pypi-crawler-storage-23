# -- coding: utf-8 --
# Project: fiuai-ai
# Created Date: 2026-02-26
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
Embedding Engine - 文本向量化引擎抽象

提供统一的 Embedding 接口, 业务项目可直接使用
"""

from fiuai_sdk_agent.infra.embedding.engine import EmbeddingEngine
from fiuai_sdk_agent.infra.embedding.openai_engine import OpenAICompatibleEmbeddingEngine

__all__ = [
    "EmbeddingEngine",
    "OpenAICompatibleEmbeddingEngine",
]
