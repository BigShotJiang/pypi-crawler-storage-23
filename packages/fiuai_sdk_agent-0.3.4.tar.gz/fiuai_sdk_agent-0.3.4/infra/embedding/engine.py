# -- coding: utf-8 --
# Project: fiuai-ai
# Created Date: 2026-02-26
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
EmbeddingEngine - Embedding 抽象基类
"""

from abc import ABC, abstractmethod
from typing import List


class EmbeddingEngine(ABC):
    """Embedding 抽象, 业务项目可直接使用"""

    @abstractmethod
    async def embed_text(self, text: str) -> List[float]:
        """将单条文本转换为向量"""
        ...

    @abstractmethod
    async def embed_texts(self, texts: List[str]) -> List[List[float]]:
        """批量将文本转换为向量"""
        ...

    @property
    @abstractmethod
    def dimension(self) -> int:
        """返回向量维度"""
        ...
