# -- coding: utf-8 --
# Project: fiuai-ai
# Created Date: 2026-02-26
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
QdrantVectorStore - 基于 Qdrant 的向量存储实现
"""

import logging
from typing import Any, Dict, List, Optional

from fiuai_sdk_agent.infra.vector.engine import VectorStoreEngine, VectorSearchResult

logger = logging.getLogger(__name__)

_DISTANCE_MAP = {
    "cosine": "Cosine",
    "euclid": "Euclid",
    "dot": "Dot",
}


def _get_qdrant_client_class():
    """延迟导入 qdrant_client, 避免未安装时 import 报错"""
    try:
        from qdrant_client import QdrantClient
        return QdrantClient
    except ImportError as e:
        raise ImportError(
            "qdrant-client package is required for QdrantVectorStore. "
            "Install it with: pip install qdrant-client"
        ) from e


def _get_qdrant_models():
    try:
        from qdrant_client import models
        return models
    except ImportError as e:
        raise ImportError(
            "qdrant-client package is required for QdrantVectorStore. "
            "Install it with: pip install qdrant-client"
        ) from e


class QdrantVectorStore(VectorStoreEngine):
    """Qdrant 向量存储实现"""

    def __init__(
        self,
        url: Optional[str] = None,
        host: str = "localhost",
        port: int = 6333,
        api_key: Optional[str] = None,
        prefer_grpc: bool = False,
        https: bool = False,
    ):
        self._url = url
        self._host = host
        self._port = port
        self._api_key = api_key
        self._prefer_grpc = prefer_grpc
        self._https = https
        self._client = None

    @property
    def client(self):
        if self._client is None:
            QdrantClient = _get_qdrant_client_class()
            if self._url:
                self._client = QdrantClient(
                    url=self._url,
                    api_key=self._api_key,
                    prefer_grpc=self._prefer_grpc,
                )
            else:
                self._client = QdrantClient(
                    host=self._host,
                    port=self._port,
                    api_key=self._api_key,
                    prefer_grpc=self._prefer_grpc,
                    https=self._https,
                )
        return self._client

    async def ensure_collection(
        self,
        name: str,
        dimension: int,
        distance: str = "cosine",
    ) -> None:
        models = _get_qdrant_models()
        distance_enum = getattr(models.Distance, _DISTANCE_MAP.get(distance, "Cosine"))
        try:
            self.client.get_collection(name)
        except Exception:
            self.client.create_collection(
                collection_name=name,
                vectors_config=models.VectorParams(
                    size=dimension,
                    distance=distance_enum,
                ),
            )
            logger.info("Created collection: %s (dim=%d, dist=%s)", name, dimension, distance)

    async def upsert(
        self,
        collection: str,
        id: str,
        vector: List[float],
        payload: Optional[Dict[str, Any]] = None,
    ) -> None:
        models = _get_qdrant_models()
        self.client.upsert(
            collection_name=collection,
            points=[
                models.PointStruct(
                    id=id,
                    vector=vector,
                    payload=payload or {},
                ),
            ],
        )

    async def upsert_batch(
        self,
        collection: str,
        ids: List[str],
        vectors: List[List[float]],
        payloads: Optional[List[Dict[str, Any]]] = None,
    ) -> None:
        if not ids:
            return
        if len(ids) != len(vectors):
            raise ValueError(f"ids length ({len(ids)}) != vectors length ({len(vectors)})")

        models = _get_qdrant_models()
        _payloads = payloads or [{} for _ in ids]
        points = [
            models.PointStruct(id=id_, vector=vec, payload=pl)
            for id_, vec, pl in zip(ids, vectors, _payloads)
        ]
        self.client.upsert(collection_name=collection, points=points)

    async def search(
        self,
        collection: str,
        vector: List[float],
        limit: int = 10,
        score_threshold: Optional[float] = None,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[VectorSearchResult]:
        models = _get_qdrant_models()

        query_filter = None
        if filters:
            conditions = []
            for key, value in filters.items():
                conditions.append(
                    models.FieldCondition(
                        key=key,
                        match=models.MatchValue(value=value),
                    )
                )
            query_filter = models.Filter(must=conditions)

        response = self.client.query_points(
            collection_name=collection,
            query=vector,
            limit=limit,
            score_threshold=score_threshold,
            query_filter=query_filter,
        )
        points = response.points if hasattr(response, "points") else response

        return [
            VectorSearchResult(
                id=str(p.id),
                score=p.score if hasattr(p, "score") else 0.0,
                payload=p.payload or {},
            )
            for p in points
        ]

    async def delete(self, collection: str, ids: List[str]) -> None:
        if not ids:
            return
        models = _get_qdrant_models()
        self.client.delete(
            collection_name=collection,
            points_selector=models.PointIdsList(points=ids),
        )

    async def collection_exists(self, name: str) -> bool:
        try:
            self.client.get_collection(name)
            return True
        except Exception:
            return False
