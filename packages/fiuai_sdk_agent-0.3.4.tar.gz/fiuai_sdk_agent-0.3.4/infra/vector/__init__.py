# -- coding: utf-8 --
# Project: fiuai-ai
# Created Date: 2026-02-26
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
Vector Store Engine - 向量存储引擎抽象

提供统一的向量存储接口, collection 名称和 payload schema 由业务方决定
"""

from fiuai_sdk_agent.infra.vector.engine import VectorStoreEngine, VectorSearchResult
from fiuai_sdk_agent.infra.vector.qdrant_store import QdrantVectorStore

__all__ = [
    "VectorStoreEngine",
    "VectorSearchResult",
    "QdrantVectorStore",
]
