# -- coding: utf-8 --
# Project: fiuai-ai
# Created Date: 2026-02-26
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
VectorStoreEngine - 向量存储抽象基类
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class VectorSearchResult:
    """向量搜索结果"""
    id: str
    score: float
    payload: Dict[str, Any] = field(default_factory=dict)


class VectorStoreEngine(ABC):
    """向量存储抽象, collection 名称/payload schema 由业务方决定"""

    @abstractmethod
    async def ensure_collection(
        self,
        name: str,
        dimension: int,
        distance: str = "cosine",
    ) -> None:
        """确保 collection 存在, 不存在则创建"""
        ...

    @abstractmethod
    async def upsert(
        self,
        collection: str,
        id: str,
        vector: List[float],
        payload: Optional[Dict[str, Any]] = None,
    ) -> None:
        """插入或更新单条向量"""
        ...

    @abstractmethod
    async def upsert_batch(
        self,
        collection: str,
        ids: List[str],
        vectors: List[List[float]],
        payloads: Optional[List[Dict[str, Any]]] = None,
    ) -> None:
        """批量插入或更新向量"""
        ...

    @abstractmethod
    async def search(
        self,
        collection: str,
        vector: List[float],
        limit: int = 10,
        score_threshold: Optional[float] = None,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[VectorSearchResult]:
        """向量相似搜索"""
        ...

    @abstractmethod
    async def delete(self, collection: str, ids: List[str]) -> None:
        """按 ID 列表删除向量"""
        ...

    @abstractmethod
    async def collection_exists(self, name: str) -> bool:
        """检查 collection 是否存在"""
        ...
