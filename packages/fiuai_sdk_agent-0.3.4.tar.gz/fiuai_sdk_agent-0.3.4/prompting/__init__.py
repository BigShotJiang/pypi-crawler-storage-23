# -- coding: utf-8 --
# Project: fiuai-ai
# Created Date: 2026-02-26
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
Prompting - Prompt 模板引擎

提供变量替换的 Prompt 模板, 业务项目可注入自己的 prompt 模板
"""

from fiuai_sdk_agent.prompting.template import PromptTemplate

__all__ = [
    "PromptTemplate",
]
