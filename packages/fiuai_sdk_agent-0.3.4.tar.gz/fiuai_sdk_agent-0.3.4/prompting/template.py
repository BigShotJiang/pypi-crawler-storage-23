# -- coding: utf-8 --
# Project: fiuai-ai
# Created Date: 2026-02-26
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
PromptTemplate - 支持变量替换的 Prompt 模板

使用 Jinja2 作为模板引擎 (已在 SDK 依赖中), 支持 {{variable}} 占位符风格
"""

import os

from jinja2 import BaseLoader, Environment, TemplateError


_ENV = Environment(
    loader=BaseLoader(),
    keep_trailing_newline=True,
)


class _LenientUndefined:
    """对未提供的变量保留原始占位符, 而非报错"""

    def __init__(self, name: str):
        self._name = name

    def __str__(self) -> str:
        return "{{" + self._name + "}}"

    def __repr__(self) -> str:
        return str(self)


class PromptTemplate:
    """支持变量替换的 Prompt 模板

    两种占位符风格均支持:
    - Jinja2 风格: {{ variable }}
    - 简单风格: {{variable}} (被转换为 Jinja2 风格)

    用法:
        tpl = PromptTemplate.from_string("你好, {{ name }}")
        result = tpl.render(name="世界")
    """

    def __init__(self, template: str):
        if not template:
            raise ValueError("Template string cannot be empty")
        self._raw = template

    @property
    def raw(self) -> str:
        """原始模板文本"""
        return self._raw

    def render(self, strict: bool = False, **variables: str) -> str:
        """渲染模板, 替换变量

        Args:
            strict: 为 True 时, 未提供的变量会抛 TemplateError; 为 False 时保留占位符原样
            **variables: 要替换的变量键值对

        Returns:
            渲染后的字符串
        """
        text = self._raw
        if strict:
            try:
                tpl = _ENV.from_string(text)
                return tpl.render(**variables)
            except TemplateError:
                raise
        else:
            # 非严格模式: 简单 str.replace, 未提供的变量保留原样
            for key, value in variables.items():
                text = text.replace("{{" + key + "}}", str(value))
                text = text.replace("{{ " + key + " }}", str(value))
            return text

    @classmethod
    def from_file(cls, path: str, encoding: str = "utf-8") -> "PromptTemplate":
        """从文件加载模板

        Args:
            path: 模板文件路径
            encoding: 文件编码

        Returns:
            PromptTemplate 实例

        Raises:
            FileNotFoundError: 文件不存在
        """
        if not os.path.isfile(path):
            raise FileNotFoundError(f"Prompt template file not found: {path}")
        with open(path, "r", encoding=encoding) as f:
            return cls(f.read())

    @classmethod
    def from_string(cls, template: str) -> "PromptTemplate":
        """从字符串创建模板"""
        return cls(template)

    def __repr__(self) -> str:
        preview = self._raw[:60] + "..." if len(self._raw) > 60 else self._raw
        return f"PromptTemplate({preview!r})"
