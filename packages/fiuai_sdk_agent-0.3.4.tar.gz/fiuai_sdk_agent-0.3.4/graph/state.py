# -- coding: utf-8 --
# Project: fiuai_sdk_agent
# Created Date: 2026-02-04
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2026 FiuAI

"""
BaseAgentState - Graph State 基类

设计要点:
- 使用 TypedDict 定义 State (LangGraph 推荐方式)
- 包含通用字段
- 支持 Reducer (如 add_messages)

字段说明:
- user_input: 用户输入
- messages: 对话历史 (使用 add_messages reducer)
- plan: 当前计划 (可选)
- next_node: 下一个节点名称 (用于路由控制)
- previous_node: 上一个节点名称 (用于路由控制)

使用示例:
    # 继承 BaseAgentState 定义业务 State
    class FiuaiTaskState(BaseAgentState):
        # 添加业务字段
        intent: Optional[UserIntent]
        data_agent_input: Optional[DataAgentInput]
        raw_data_set: Optional[RawDataSet]
        ...

    # 在 Graph 中使用
    graph = StateGraph(state_schema=FiuaiTaskState)
"""

from typing import TypedDict, Optional, List, Annotated, Any
from operator import add
from langchain_core.messages import BaseMessage


def add_messages(
    existing: Optional[List[BaseMessage]],
    new: Optional[List[BaseMessage]],
) -> List[BaseMessage]:
    """
    消息合并 Reducer

    用于合并对话历史, 追加新消息到现有列表

    Args:
        existing: 现有消息列表
        new: 新增消息列表

    Returns:
        合并后的消息列表
    """
    if existing is None:
        existing = []
    if new is None:
        return existing
    return existing + new


class BaseAgentState(TypedDict, total=False):
    """
    Graph State 基类

    使用 TypedDict 定义, 支持 LangGraph 的状态管理

    Attributes:
        user_input: 用户输入
        messages: 对话历史 (使用 add_messages reducer)
        plan: 当前计划对象 (可选)
        plan_id: 计划 ID (可选, 用于快速查找)
        next_node: 下一个节点名称 (用于路由控制)
        previous_node: 上一个节点名称 (用于路由控制)

    Note:
        - total=False 表示所有字段都是可选的
        - 子类可以添加业务特定的字段
        - messages 字段使用 Annotated 声明 reducer
    """

    # 用户输入 (必需)
    user_input: str

    # 对话历史 (使用 add_messages reducer 合并)
    messages: Annotated[List[BaseMessage], add_messages]

    # 计划相关 (可选)
    plan: Optional[Any]  # 实际类型是 BasePlan, 这里用 Any 避免循环导入
    plan_id: Optional[str]

    # 路由控制 (可选)
    next_node: Optional[str]
    previous_node: Optional[str]
