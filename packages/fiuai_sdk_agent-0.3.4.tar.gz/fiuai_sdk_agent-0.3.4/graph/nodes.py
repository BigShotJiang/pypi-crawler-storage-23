# -- coding: utf-8 --
# Project: fiuai_sdk_agent
# Created Date: 2026-02-04
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2026 FiuAI

"""
Node 工厂函数 - 简化 LangGraph Node 的依赖注入

设计目标:
- 将普通函数包装为 LangGraph Node
- 自动处理 Runtime 注入
- 保持函数签名和元数据

Node 函数规范:
- 签名: async def node(state: State, runtime: Runtime) -> dict
- 必须是纯函数, 无副作用
- 通过 runtime.context 访问业务服务
- 返回状态更新字典 (只包含需要更新的字段)

重要:
- 不使用 @wraps(func), 因为 @wraps 会复制 __wrapped__ 和签名
- LangGraph RunnableCallable 会用 inspect.signature() 检查函数签名
- 如果签名中有 runtime 参数, LangGraph 会自动注入 runtime 作为 kwarg
- 我们的包装函数签名是 (state, config), 不能暴露原始的 (state, runtime)

使用示例:
    # 定义纯函数 Node
    async def intent_node(state: TaskState, runtime: FiuaiRuntime) -> dict:
        ctx = runtime.context
        ctx.event_publisher.chunk_text("分析中...")
        intent = analyze_intent(state.user_input)
        return {"intent": intent}

    # 创建 LangGraph Node (自动注入 runtime)
    runtime = RuntimeFactory.create(...)
    intent_lg_node = create_node(intent_node, runtime)

    # 在 Graph 中使用
    graph.add_node("intent", intent_lg_node)
"""

from typing import TypeVar, Callable, Awaitable, Dict, Any, TYPE_CHECKING

from ..utils.logger import get_logger

if TYPE_CHECKING:
    from langchain_core.runnables import RunnableConfig
    from ..core.runtime import AgentRuntime

logger = get_logger(__name__)

# 类型变量
StateT = TypeVar("StateT")
RuntimeT = TypeVar("RuntimeT")

# Node 函数类型: async def node(state, runtime) -> dict
NodeFunc = Callable[[StateT, "AgentRuntime"], Awaitable[Dict[str, Any]]]

# LangGraph Node 类型: async def node(state, config) -> dict
LangGraphNode = Callable[[StateT, "RunnableConfig"], Awaitable[Dict[str, Any]]]


def create_node(
    func: NodeFunc,
    runtime: "AgentRuntime",
) -> LangGraphNode:
    """
    创建 LangGraph Node (包装函数, 注入 Runtime)

    将纯函数 Node 包装为 LangGraph 可用的格式, 自动注入 Runtime

    注意: 不使用 @wraps(func), 避免 LangGraph 通过 inspect.signature()
    发现原始函数的 runtime 参数并自动注入导致冲突

    Args:
        func: 纯函数 Node, 签名为 async def node(state, runtime) -> dict
        runtime: AgentRuntime 实例

    Returns:
        LangGraph Node 函数, 签名为 async def node(state, config) -> dict
    """

    async def wrapped_node(state: StateT, config: "RunnableConfig") -> Dict[str, Any]:
        try:
            return await func(state, runtime)
        except Exception as e:
            # Defense-in-depth: 记录节点级异常
            # 业务节点应自行 try/except, 这里是最后一层保护
            logger.error(
                f"Node {func.__name__} raised unhandled exception: {e}",
                exc_info=True,
            )
            raise

    # 手动保留原函数名和文档(不使用 @wraps 以避免复制 __wrapped__ 和签名)
    wrapped_node.__name__ = func.__name__
    wrapped_node.__qualname__ = func.__qualname__
    wrapped_node.__doc__ = func.__doc__
    wrapped_node.__module__ = func.__module__
    return wrapped_node


def create_node_with_runtime_factory(
    func: NodeFunc,
    runtime_factory: Callable[[], "AgentRuntime"],
) -> LangGraphNode:
    """
    创建 LangGraph Node (使用 Runtime 工厂)

    每次调用时通过工厂函数获取 Runtime, 适用于需要动态创建 Runtime 的场景

    Args:
        func: 纯函数 Node
        runtime_factory: Runtime 工厂函数, 每次调用返回 AgentRuntime

    Returns:
        LangGraph Node 函数
    """

    async def wrapped_node(state: StateT, config: "RunnableConfig") -> Dict[str, Any]:
        try:
            rt = runtime_factory()
            return await func(state, rt)
        except Exception as e:
            logger.error(
                f"Node {func.__name__} raised unhandled exception: {e}",
                exc_info=True,
            )
            raise

    wrapped_node.__name__ = func.__name__
    wrapped_node.__qualname__ = func.__qualname__
    wrapped_node.__doc__ = func.__doc__
    wrapped_node.__module__ = func.__module__
    return wrapped_node


def create_node_from_config(
    func: NodeFunc,
    runtime_key: str = "runtime",
) -> LangGraphNode:
    """
    创建 LangGraph Node (从 config 获取 Runtime)

    从 LangGraph config 的 configurable 中获取 Runtime

    Args:
        func: 纯函数 Node
        runtime_key: config.configurable 中 runtime 的 key

    Returns:
        LangGraph Node 函数
    """

    async def wrapped_node(state: StateT, config: "RunnableConfig") -> Dict[str, Any]:
        try:
            configurable = config.get("configurable", {})
            rt = configurable.get(runtime_key)
            if rt is None:
                raise ValueError(
                    f"Runtime not found in config.configurable['{runtime_key}']. "
                    f"Please pass runtime in config when invoking the graph."
                )
            return await func(state, rt)
        except Exception as e:
            logger.error(
                f"Node {func.__name__} raised unhandled exception: {e}",
                exc_info=True,
            )
            raise

    wrapped_node.__name__ = func.__name__
    wrapped_node.__qualname__ = func.__qualname__
    wrapped_node.__doc__ = func.__doc__
    wrapped_node.__module__ = func.__module__
    return wrapped_node
