"""JSON-RPC client package facade.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from mcp_proxy_adapter.client.jsonrpc_client.client import JsonRpcClient
from mcp_proxy_adapter.client.jsonrpc_client.openapi_validator import OpenAPIValidator
from mcp_proxy_adapter.client.jsonrpc_client.schema_generator import (
    SchemaRequestGenerator,
    MethodInfo,
    ParameterInfo,
)
from mcp_proxy_adapter.client.jsonrpc_client.exceptions import (
    ClientError,
    SchemaGeneratorError,
    MethodNotFoundError,
    RequiredParameterMissingError,
    InvalidParameterTypeError,
    InvalidParameterValueError,
    ClientConnectionError,
    ClientRequestError,
    SchemaValidationError,
)
from mcp_proxy_adapter.client.jsonrpc_client.queue_status import QueueJobStatus
from mcp_proxy_adapter.client.jsonrpc_client.ws_job_status import (
    BidirectionalWsChannel,
    open_bidirectional_ws_channel,
    wait_for_job_via_websocket,
)

__all__ = [
    "JsonRpcClient",
    "OpenAPIValidator",
    "SchemaRequestGenerator",
    "MethodInfo",
    "ParameterInfo",
    "ClientError",
    "SchemaGeneratorError",
    "MethodNotFoundError",
    "RequiredParameterMissingError",
    "InvalidParameterTypeError",
    "InvalidParameterValueError",
    "ClientConnectionError",
    "ClientRequestError",
    "SchemaValidationError",
    "QueueJobStatus",
    "wait_for_job_via_websocket",
    "BidirectionalWsChannel",
    "open_bidirectional_ws_channel",
]
