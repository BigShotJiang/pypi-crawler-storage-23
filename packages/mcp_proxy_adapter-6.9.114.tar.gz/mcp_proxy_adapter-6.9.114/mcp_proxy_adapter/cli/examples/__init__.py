"""
CLI Examples Module (legacy).

Examples have been moved to mcp_proxy_adapter.examples.cli_config_examples.
Use: python -m mcp_proxy_adapter.examples.cli_config_examples.http_basic (etc.)

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""
