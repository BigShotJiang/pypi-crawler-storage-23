"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Job push configuration validator.
"""

from __future__ import annotations

from typing import List

from .base_validator import BaseValidator, ValidationError
from ..simple_config import SimpleConfigModel


class JobPushValidator(BaseValidator):
    """Validator for job_push configuration (WebSocket /ws, registry, poll loop)."""

    def validate(self, model: SimpleConfigModel) -> List[ValidationError]:
        """
        Validate job_push configuration.

        Args:
            model: Configuration model

        Returns:
            List of validation errors for job_push section
        """
        errors: List[ValidationError] = []
        jp = model.job_push
        if not isinstance(jp.enabled, bool):
            errors.append(ValidationError("job_push.enabled must be a boolean"))
        return errors
