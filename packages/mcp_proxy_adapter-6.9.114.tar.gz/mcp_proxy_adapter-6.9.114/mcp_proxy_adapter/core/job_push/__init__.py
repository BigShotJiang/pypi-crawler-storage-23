"""
Job push: event schema, subscriber registry, notifier, and hooks.

Single source of truth for job-push event names and payload schema (events.py).
Registry and push flow: subscriptions.py, notifier.py, hooks.py.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from mcp_proxy_adapter.core.job_push.events import (
    EVENT_JOB_QUEUED,
    EVENT_JOB_PROGRESS,
    EVENT_JOB_COMPLETED,
    EVENT_JOB_FAILED,
    EVENT_JOB_STOPPED,
    build_push_message,
)
from mcp_proxy_adapter.core.job_push.subscriptions import (
    SubscriberRegistry,
    Subscriber,
)
from mcp_proxy_adapter.core.job_push.notifier import notify_job_state_changed
from mcp_proxy_adapter.core.job_push.hooks import (
    register_job_push_handler,
    get_job_push_handlers,
    run_job_push_handlers,
)

__all__ = [
    "EVENT_JOB_QUEUED",
    "EVENT_JOB_PROGRESS",
    "EVENT_JOB_COMPLETED",
    "EVENT_JOB_FAILED",
    "EVENT_JOB_STOPPED",
    "build_push_message",
    "SubscriberRegistry",
    "Subscriber",
    "notify_job_state_changed",
    "register_job_push_handler",
    "get_job_push_handlers",
    "run_job_push_handlers",
]
