#!/usr/bin/env python3
"""
NAME
    http_basic_ws – test /ws WebSocket over HTTP with no authentication

SYNOPSIS
    python -m mcp_proxy_adapter.examples.ws_examples.http_basic_ws [--port PORT]
    python mcp_proxy_adapter/examples/ws_examples/http_basic_ws.py [--port 8080]

DESCRIPTION
    Connects to the server's /ws endpoint over plain HTTP (ws://host:port/ws).
    No token or client certificate is sent. The /ws path is public, so the
    upgrade request is not blocked by security middleware.

    Use this mode when the server is started with configs such as
    full_application/configs/http_basic.json (protocol http, security disabled).

PROTOCOL
    HTTP only. WebSocket URL: ws://localhost:PORT/ws.

SECURITY
    None. No X-API-Key or Authorization header; no TLS.

OPTIONS
    --host   Server host (default: localhost).
    --port   Server port (default: 8080).

EXIT STATUS
    0 on success (connect, subscribe, unsubscribe, close).
    1 on connection error or failure.

EXAMPLES
    # Start server first (from project root):
    #   python mcp_proxy_adapter/examples/full_application/main.py \\
    #     --config mcp_proxy_adapter/examples/full_application/configs/http_basic.json --port 8080
    # Then run this example:
    python -m mcp_proxy_adapter.examples.ws_examples.http_basic_ws --port 8080

SEE ALSO
    ws_example_runner.py, http_token_ws.py, https_basic_ws.py,
    full_application/configs/http_basic.json

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import argparse
import sys
from pathlib import Path

# Add project root for standalone run
_root = Path(__file__).resolve().parent.parent.parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

from mcp_proxy_adapter.examples.ws_examples.ws_example_runner import run_ws_example_sync


def main() -> int:
    parser = argparse.ArgumentParser(description="Test /ws over HTTP (no auth)")
    parser.add_argument("--host", default="localhost")
    parser.add_argument("--port", type=int, default=8080)
    args = parser.parse_args()
    return run_ws_example_sync("http", host=args.host, port=args.port)


if __name__ == "__main__":
    sys.exit(main())
