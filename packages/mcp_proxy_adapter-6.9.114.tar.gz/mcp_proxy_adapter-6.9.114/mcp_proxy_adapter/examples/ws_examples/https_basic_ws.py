#!/usr/bin/env python3
"""
NAME
    https_basic_ws – test /ws WebSocket over HTTPS with no client cert or token

SYNOPSIS
    python -m mcp_proxy_adapter.examples.ws_examples.https_basic_ws [--port PORT]

DESCRIPTION
    Connects to the server's /ws endpoint over HTTPS (wss://host:port/ws).
    Server TLS is used; hostname verification is disabled for local testing.
    No client certificate and no API key. The /ws path is public.

    Use when the server is started with full_application/configs/https_basic.json
    (protocol https, no client cert, no token).

PROTOCOL
    HTTPS. WebSocket URL: wss://localhost:PORT/ws.

SECURITY
    Server TLS only. No client certificate, no token. Verify disabled for examples.

OPTIONS
    --host   Server host (default: localhost).
    --port   Server port (default: 8443).

EXIT STATUS
    0 on success, 1 on failure.

EXAMPLES
    python -m mcp_proxy_adapter.examples.ws_examples.https_basic_ws --port 8443

SEE ALSO
    ws_example_runner.py, https_token_ws.py, mtls_basic_ws.py,
    full_application/configs/https_basic.json

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import argparse
import sys
from pathlib import Path

_root = Path(__file__).resolve().parent.parent.parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

from mcp_proxy_adapter.examples.ws_examples.ws_example_runner import run_ws_example_sync


def main() -> int:
    parser = argparse.ArgumentParser(description="Test /ws over HTTPS (no auth)")
    parser.add_argument("--host", default="localhost")
    parser.add_argument("--port", type=int, default=8443)
    args = parser.parse_args()
    return run_ws_example_sync("https", host=args.host, port=args.port)


if __name__ == "__main__":
    sys.exit(main())
