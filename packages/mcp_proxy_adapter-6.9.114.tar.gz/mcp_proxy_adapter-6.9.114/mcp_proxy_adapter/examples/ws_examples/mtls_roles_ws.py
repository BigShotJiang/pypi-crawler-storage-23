#!/usr/bin/env python3
"""
NAME
    mtls_roles_ws – test /ws WebSocket over mTLS with token and roles

SYNOPSIS
    python -m mcp_proxy_adapter.examples.ws_examples.mtls_roles_ws [--port PORT] [--cert PATH] [--key PATH] [--ca PATH] [--token TOKEN]

DESCRIPTION
    Connects to the server's /ws endpoint over mTLS (wss://host:port/ws) with
    client certificate and API key. Roles may be applied by the server for
    subscribe authorization. /ws is public; cert and token identify the client.

    Use when the server uses full_application/configs/mtls_with_roles_correct.json
    (protocol mtls, client cert + token + roles).

PROTOCOL
    mTLS. WebSocket URL: wss://localhost:PORT/ws.

SECURITY
    Server TLS + client certificate + token + roles. Same cert/key/ca as
    mtls_basic_ws; default token: admin-secret-key-mtls.

OPTIONS
    --host   Server host (default: localhost).
    --port   Server port (default: 8443).
    --token  API key (default: admin-secret-key-mtls).
    --cert   Client certificate path.
    --key    Client key path.
    --ca     CA certificate path.

EXIT STATUS
    0 on success, 1 on failure.

EXAMPLES
    python -m mcp_proxy_adapter.examples.ws_examples.mtls_roles_ws --port 8443

SEE ALSO
    ws_example_runner.py, mtls_basic_ws.py, https_token_roles_ws.py,
    full_application/configs/mtls_with_roles_correct.json

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import argparse
import sys
from pathlib import Path

_root = Path(__file__).resolve().parent.parent.parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

from mcp_proxy_adapter.examples.ws_examples.ws_example_runner import run_ws_example_sync


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Test /ws over mTLS with token and roles"
    )
    parser.add_argument("--host", default="localhost")
    parser.add_argument("--port", type=int, default=8443)
    parser.add_argument("--token", default="admin-secret-key-mtls")
    parser.add_argument("--cert", default=None)
    parser.add_argument("--key", default=None)
    parser.add_argument("--ca", default=None)
    args = parser.parse_args()
    cert = args.cert or str(_root / "mtls_certificates" / "client" / "test-client.crt")
    key = args.key or str(_root / "mtls_certificates" / "client" / "test-client.key")
    ca = args.ca or str(_root / "mtls_certificates" / "ca" / "ca.crt")
    return run_ws_example_sync(
        "mtls",
        host=args.host,
        port=args.port,
        token=args.token,
        cert=cert,
        key=key,
        ca=ca,
    )


if __name__ == "__main__":
    sys.exit(main())
