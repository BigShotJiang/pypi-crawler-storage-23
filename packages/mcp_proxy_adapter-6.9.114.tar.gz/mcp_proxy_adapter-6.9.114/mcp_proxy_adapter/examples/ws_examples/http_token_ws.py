#!/usr/bin/env python3
"""
NAME
    http_token_ws – test /ws WebSocket over HTTP with API key authentication

SYNOPSIS
    python -m mcp_proxy_adapter.examples.ws_examples.http_token_ws [--port PORT] [--token TOKEN]

DESCRIPTION
    Connects to the server's /ws endpoint over HTTP (ws://host:port/ws) and
    sends the given API key in the X-API-Key header on the WebSocket upgrade
    request. The /ws path is public, so the upgrade is not blocked even if
    the server requires token for other endpoints; the token is optional here
    and can be used by the server for identity in subscribe authorization.

    Use when the server is started with configs such as
    full_application/configs/http_token.json (protocol http, security with token).

PROTOCOL
    HTTP. WebSocket URL: ws://localhost:PORT/ws.

SECURITY
    Token only. Header X-API-Key (or --token-header) with value from --token.
    Default token matches example config: admin-secret-key.

OPTIONS
    --host   Server host (default: localhost).
    --port   Server port (default: 8080).
    --token  API key (default: admin-secret-key).
    --token-header  Header name (default: X-API-Key).

EXIT STATUS
    0 on success, 1 on failure.

EXAMPLES
    python -m mcp_proxy_adapter.examples.ws_examples.http_token_ws --port 8080
    python -m mcp_proxy_adapter.examples.ws_examples.http_token_ws --token my-key

SEE ALSO
    ws_example_runner.py, http_basic_ws.py, http_token_roles_ws.py,
    full_application/configs/http_token.json

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import argparse
import sys
from pathlib import Path

_root = Path(__file__).resolve().parent.parent.parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

from mcp_proxy_adapter.examples.ws_examples.ws_example_runner import run_ws_example_sync


def main() -> int:
    parser = argparse.ArgumentParser(description="Test /ws over HTTP with token")
    parser.add_argument("--host", default="localhost")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--token", default="admin-secret-key")
    parser.add_argument("--token-header", default="X-API-Key")
    args = parser.parse_args()
    return run_ws_example_sync(
        "http",
        host=args.host,
        port=args.port,
        token=args.token,
        token_header=args.token_header,
    )


if __name__ == "__main__":
    sys.exit(main())
