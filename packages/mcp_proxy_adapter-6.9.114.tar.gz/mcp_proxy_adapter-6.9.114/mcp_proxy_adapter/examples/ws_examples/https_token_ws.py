#!/usr/bin/env python3
"""
NAME
    https_token_ws – test /ws WebSocket over HTTPS with API key

SYNOPSIS
    python -m mcp_proxy_adapter.examples.ws_examples.https_token_ws [--port PORT] [--token TOKEN]

DESCRIPTION
    Connects to the server's /ws endpoint over HTTPS (wss://host:port/ws) and
    sends the API key in X-API-Key on the WebSocket upgrade. /ws is public;
    token is optional and used for identity.

    Use when the server uses full_application/configs/https_token.json
    (protocol https, token auth).

PROTOCOL
    HTTPS. WebSocket URL: wss://localhost:PORT/ws.

SECURITY
    Server TLS + token (X-API-Key). Default token: admin-secret-key-https.

OPTIONS
    --host   Server host (default: localhost).
    --port   Server port (default: 8443).
    --token  API key (default: admin-secret-key-https).

EXIT STATUS
    0 on success, 1 on failure.

EXAMPLES
    python -m mcp_proxy_adapter.examples.ws_examples.https_token_ws --port 8443

SEE ALSO
    ws_example_runner.py, https_basic_ws.py, https_token_roles_ws.py,
    full_application/configs/https_token.json

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import argparse
import sys
from pathlib import Path

_root = Path(__file__).resolve().parent.parent.parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

from mcp_proxy_adapter.examples.ws_examples.ws_example_runner import run_ws_example_sync


def main() -> int:
    parser = argparse.ArgumentParser(description="Test /ws over HTTPS with token")
    parser.add_argument("--host", default="localhost")
    parser.add_argument("--port", type=int, default=8443)
    parser.add_argument("--token", default="admin-secret-key-https")
    args = parser.parse_args()
    return run_ws_example_sync(
        "https",
        host=args.host,
        port=args.port,
        token=args.token,
    )


if __name__ == "__main__":
    sys.exit(main())
