#!/usr/bin/env python3
"""
NAME
    http_token_roles_ws – test /ws WebSocket over HTTP with token and roles

SYNOPSIS
    python -m mcp_proxy_adapter.examples.ws_examples.http_token_roles_ws [--port PORT] [--token TOKEN]

DESCRIPTION
    Connects to the server's /ws endpoint over HTTP (ws://host:port/ws) with
    API key and optional role context. The /ws endpoint is public; the token
    is sent on upgrade for identity. Role-based checks may be applied by the
    server when authorizing subscribe requests.

    Use when the server uses full_application/configs/http_token_roles.json
    (protocol http, security with token and roles).

PROTOCOL
    HTTP. WebSocket URL: ws://localhost:PORT/ws.

SECURITY
    Token + roles. Same token as http_token_ws; roles are determined by server
    from config (e.g. admin-secret-key -> mcpproxy, techsup).

OPTIONS
    --host   Server host (default: localhost).
    --port   Server port (default: 8080).
    --token  API key (default: admin-secret-key).

EXIT STATUS
    0 on success, 1 on failure.

EXAMPLES
    python -m mcp_proxy_adapter.examples.ws_examples.http_token_roles_ws --port 8080

SEE ALSO
    ws_example_runner.py, http_token_ws.py, https_token_roles_ws.py,
    full_application/configs/http_token_roles.json

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import argparse
import sys
from pathlib import Path

_root = Path(__file__).resolve().parent.parent.parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

from mcp_proxy_adapter.examples.ws_examples.ws_example_runner import run_ws_example_sync


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Test /ws over HTTP with token and roles"
    )
    parser.add_argument("--host", default="localhost")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--token", default="admin-secret-key")
    args = parser.parse_args()
    return run_ws_example_sync(
        "http",
        host=args.host,
        port=args.port,
        token=args.token,
    )


if __name__ == "__main__":
    sys.exit(main())
