"""
WebSocket /ws examples for all protocol and security combinations.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""
