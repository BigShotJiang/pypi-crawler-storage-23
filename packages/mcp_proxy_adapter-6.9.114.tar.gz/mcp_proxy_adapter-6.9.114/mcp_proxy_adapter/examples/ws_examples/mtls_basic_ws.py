#!/usr/bin/env python3
"""
NAME
    mtls_basic_ws – test /ws WebSocket over mTLS (client certificate)

SYNOPSIS
    python -m mcp_proxy_adapter.examples.ws_examples.mtls_basic_ws [--port PORT] [--cert PATH] [--key PATH] [--ca PATH]

DESCRIPTION
    Connects to the server's /ws endpoint over HTTPS with mutual TLS (wss://host:port/ws).
    The client presents a certificate and key; the server may require client cert
    verification. /ws is in public paths so the upgrade is not blocked; the
    client cert is used for identity in subscribe checks if configured.

    Use when the server uses full_application/configs/mtls_no_roles_correct.json
    (protocol mtls, server TLS + client cert verification, optional token).

PROTOCOL
    mTLS (HTTPS with client certificate). WebSocket URL: wss://localhost:PORT/ws.

SECURITY
    Server TLS + client certificate (+ optional token). Default cert/key/ca
    paths point to mtls_certificates under project root. Run from project root
    or pass --cert, --key, --ca.

OPTIONS
    --host   Server host (default: localhost).
    --port   Server port (default: 8443).
    --token  Optional API key (default: admin-secret-key-mtls).
    --cert   Client certificate path (default: mtls_certificates/client/test-client.crt).
    --key    Client key path (default: mtls_certificates/client/test-client.key).
    --ca     CA certificate path (default: mtls_certificates/ca/ca.crt).

EXIT STATUS
    0 on success, 1 on failure.

EXAMPLES
    # From project root (cert paths relative to cwd):
    python -m mcp_proxy_adapter.examples.ws_examples.mtls_basic_ws --port 8443
    python -m mcp_proxy_adapter.examples.ws_examples.mtls_basic_ws --cert ./mtls_certificates/client/test-client.crt --key ./mtls_certificates/client/test-client.key --ca ./mtls_certificates/ca/ca.crt

SEE ALSO
    ws_example_runner.py, mtls_roles_ws.py, https_token_ws.py,
    full_application/configs/mtls_no_roles_correct.json

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import argparse
import sys
from pathlib import Path

_root = Path(__file__).resolve().parent.parent.parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

from mcp_proxy_adapter.examples.ws_examples.ws_example_runner import run_ws_example_sync


def main() -> int:
    parser = argparse.ArgumentParser(description="Test /ws over mTLS (client cert)")
    parser.add_argument("--host", default="localhost")
    parser.add_argument("--port", type=int, default=8443)
    parser.add_argument("--token", default="admin-secret-key-mtls")
    parser.add_argument(
        "--cert",
        default=None,
        help="Client cert path (default: mtls_certificates/client/test-client.crt)",
    )
    parser.add_argument("--key", default=None)
    parser.add_argument("--ca", default=None)
    args = parser.parse_args()
    cert = args.cert or str(_root / "mtls_certificates" / "client" / "test-client.crt")
    key = args.key or str(_root / "mtls_certificates" / "client" / "test-client.key")
    ca = args.ca or str(_root / "mtls_certificates" / "ca" / "ca.crt")
    return run_ws_example_sync(
        "mtls",
        host=args.host,
        port=args.port,
        token=args.token,
        cert=cert,
        key=key,
        ca=ca,
    )


if __name__ == "__main__":
    sys.exit(main())
