"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Test client for MCP Proxy Adapter framework.
This client demonstrates how to use JsonRpcClient to connect to MCP Proxy Adapter servers.
"""

