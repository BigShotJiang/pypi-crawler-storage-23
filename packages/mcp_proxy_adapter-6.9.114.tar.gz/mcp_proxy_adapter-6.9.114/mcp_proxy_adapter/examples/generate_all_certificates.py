"""
Entry point for generate_certificates: generate test certificates for examples.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path


def main() -> int:
    """Generate certificates; delegates to setup_test_environment when available."""
    parser = argparse.ArgumentParser(
        description="Generate SSL/certificates for MCP Proxy Adapter examples"
    )
    parser.add_argument(
        "-o",
        "--output-dir",
        default=".",
        help="Output directory (default: current)",
    )
    parser.add_argument(
        "--no-certs",
        action="store_true",
        help="Skip certificate generation (no-op)",
    )
    args = parser.parse_args()
    if args.no_certs:
        print("Skipping certificate generation (--no-certs)")
        return 0
    try:
        from mcp_proxy_adapter.examples.setup import generate_certificates_with_framework
        out = Path(args.output_dir)
        out.mkdir(parents=True, exist_ok=True)
        generate_certificates_with_framework(str(out))
        print("Certificates generated successfully")
        return 0
    except ImportError:
        print(
            "Setup modules not available; use setup_test_environment for full setup.",
            file=sys.stderr,
        )
        return 0


if __name__ == "__main__":
    sys.exit(main())
