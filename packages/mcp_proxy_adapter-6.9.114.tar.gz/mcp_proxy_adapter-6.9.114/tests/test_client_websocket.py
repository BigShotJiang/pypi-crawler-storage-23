#!/usr/bin/env python3
"""
Tests for client WebSocket support (ws_url, wait_for_job_via_websocket).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import pytest

from mcp_proxy_adapter.client.jsonrpc_client import JsonRpcClient
from mcp_proxy_adapter.client.jsonrpc_client.transport import JsonRpcTransport


def test_ws_url_http() -> None:
    """HTTP base URL yields ws://.../ws."""
    t = JsonRpcTransport(protocol="http", host="localhost", port=8080)
    assert t.ws_url == "ws://localhost:8080/ws"


def test_ws_url_https() -> None:
    """HTTPS base URL yields wss://.../ws."""
    t = JsonRpcTransport(protocol="https", host="localhost", port=8443)
    assert t.ws_url == "wss://localhost:8443/ws"


def test_ws_url_via_client() -> None:
    """JsonRpcClient exposes ws_url from transport."""
    c = JsonRpcClient(protocol="http", host="127.0.0.1", port=9000)
    assert c.ws_url == "ws://127.0.0.1:9000/ws"


def test_get_ws_ssl_context_http_is_none() -> None:
    """HTTP transport returns None for WebSocket SSL context."""
    t = JsonRpcTransport(protocol="http", host="localhost", port=8080)
    assert t.get_ws_ssl_context() is None


def test_open_bidirectional_ws_channel_returns_channel() -> None:
    """open_bidirectional_ws_channel returns BidirectionalWsChannel."""
    from mcp_proxy_adapter.client.jsonrpc_client import (
        BidirectionalWsChannel,
        open_bidirectional_ws_channel,
    )

    c = JsonRpcClient(protocol="http", host="127.0.0.1", port=8080)
    ch = open_bidirectional_ws_channel(c)
    assert isinstance(ch, BidirectionalWsChannel)
    assert hasattr(ch, "send_json")
    assert hasattr(ch, "receive_iter")


def test_client_has_open_bidirectional_ws_channel() -> None:
    """JsonRpcClient has open_bidirectional_ws_channel method."""
    c = JsonRpcClient(protocol="http", host="127.0.0.1", port=8080)
    ch = c.open_bidirectional_ws_channel(receive_timeout=30.0)
    from mcp_proxy_adapter.client.jsonrpc_client import BidirectionalWsChannel

    assert isinstance(ch, BidirectionalWsChannel)
