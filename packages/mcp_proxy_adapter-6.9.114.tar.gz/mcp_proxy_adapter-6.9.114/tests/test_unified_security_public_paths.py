#!/usr/bin/env python3
"""
Tests for configurable public paths in UnifiedSecurityMiddleware.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import pytest

from mcp_proxy_adapter.api.middleware.unified_security import (
    _DEFAULT_PUBLIC_PATHS,
    _resolve_public_paths,
)


def test_resolve_public_paths_empty_config() -> None:
    """When config has no public_paths, only defaults are returned."""
    paths = _resolve_public_paths({})
    assert paths == _DEFAULT_PUBLIC_PATHS


def test_resolve_public_paths_security_public_paths() -> None:
    """security.public_paths from config are merged with defaults."""
    config = {"public_paths": ["/ws", "/custom"]}
    paths = _resolve_public_paths(config)
    assert paths >= _DEFAULT_PUBLIC_PATHS
    assert "/ws" in paths
    assert "/custom" in paths


def test_resolve_public_paths_auth_public_paths() -> None:
    """security.auth.public_paths (AuthConfig-style) are merged with defaults."""
    config = {"auth": {"public_paths": ["/ws"]}}
    paths = _resolve_public_paths(config)
    assert paths >= _DEFAULT_PUBLIC_PATHS
    assert "/ws" in paths


def test_resolve_public_paths_both_sources() -> None:
    """Both security.public_paths and security.auth.public_paths are merged."""
    config = {
        "public_paths": ["/ws"],
        "auth": {"public_paths": ["/push"]},
    }
    paths = _resolve_public_paths(config)
    assert "/ws" in paths
    assert "/push" in paths
    assert paths >= _DEFAULT_PUBLIC_PATHS


def test_resolve_public_paths_skips_non_strings() -> None:
    """Non-string entries in config lists are skipped."""
    config = {"public_paths": ["/ws", None, 1, ""]}
    paths = _resolve_public_paths(config)
    assert "/ws" in paths
    assert paths >= _DEFAULT_PUBLIC_PATHS
