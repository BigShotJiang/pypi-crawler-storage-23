# PutAgentsResponse

Response body for creating or updating agents.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agents** | [**List[AgentResponse]**](AgentResponse.md) | List of agents that were created or updated. | 

## Example

```python
from arthur_client.api_bindings.models.put_agents_response import PutAgentsResponse

# TODO update the JSON string below
json = "{}"
# create an instance of PutAgentsResponse from a JSON string
put_agents_response_instance = PutAgentsResponse.from_json(json)
# print the JSON string representation of the object
print(PutAgentsResponse.to_json())

# convert the object into a dict
put_agents_response_dict = put_agents_response_instance.to_dict()
# create an instance of PutAgentsResponse from a dict
put_agents_response_from_dict = PutAgentsResponse.from_dict(put_agents_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


