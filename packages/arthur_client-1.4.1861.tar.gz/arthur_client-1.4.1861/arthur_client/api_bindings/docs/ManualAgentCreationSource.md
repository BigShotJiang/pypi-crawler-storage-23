# ManualAgentCreationSource

Creation source for manually created tasks.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** |  | [optional] [default to 'MANUAL']

## Example

```python
from arthur_client.api_bindings.models.manual_agent_creation_source import ManualAgentCreationSource

# TODO update the JSON string below
json = "{}"
# create an instance of ManualAgentCreationSource from a JSON string
manual_agent_creation_source_instance = ManualAgentCreationSource.from_json(json)
# print the JSON string representation of the object
print(ManualAgentCreationSource.to_json())

# convert the object into a dict
manual_agent_creation_source_dict = manual_agent_creation_source_instance.to_dict()
# create an instance of ManualAgentCreationSource from a dict
manual_agent_creation_source_from_dict = ManualAgentCreationSource.from_dict(manual_agent_creation_source_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


