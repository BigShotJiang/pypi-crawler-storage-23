import json
import os
from dataclasses import dataclass
from types import MappingProxyType
from canopy.core.field import Field

@dataclass
class TestDataInfo:
    description: str = ""
    file_format: str = ""
    grid_type: str = ""
    source: str = ""

_test_data_info = {}


def _load_test_data_registry():

    with open(f'{os.path.dirname(__file__)}/registry.json') as f:
        test_data = json.load(f)
    for fname, data in test_data.items():
        td = TestDataInfo(description=data['description'],
                          file_format=data['file_format'],
                          grid_type=data['grid_type'],
                          source=data['source']
                          )
        _test_data_info[fname] = td


def load_test_data(fname: str) -> Field:
    '''Load a test data field

    Parameters
    ----------
    fname : str | None
        The name of the data file to load.

    Returns
    -------
        A Field object derived from the data file.
    '''
    path = f'{os.path.dirname(__file__)}'
    tdi = _test_data_info[fname]
    field = Field.from_file(f'{path}/{fname}', grid_type=tdi.grid_type, source=tdi.source)

    return field


def list_test_data():
    return MappingProxyType(_test_data_info)


_load_test_data_registry()


