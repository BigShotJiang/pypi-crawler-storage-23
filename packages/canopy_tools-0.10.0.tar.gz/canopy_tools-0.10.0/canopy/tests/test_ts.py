# -----------------------------------------------
# | Tests for time series plotting using canopy |
# -----------------------------------------------

import pytest
import matplotlib
matplotlib.use('Agg')  # Set non-GUI backend before pyplot import
import canopy as cp
import canopy.visualization as cv


field_a = cp.load_test_data("anpp_spain_1990_2010.out.gz")
field_b = cp.load_test_data("anpp_spain_1990_2010_mod.out.gz")
field_sites = cp.load_test_data("aaet_global_sites.out.gz")


@pytest.mark.filterwarnings("ignore:FigureCanvasAgg is non-interactive, and thus cannot be shown:UserWarning")
def test_case_1_one_field_one_layer_reduced_grid():
    """Case 1: one field, one layer, reduced grid"""
    cv.make_time_series(field_a, layers=["Total"], gridop="av", rolling_size=5, title="Case 1")


@pytest.mark.filterwarnings("ignore:FigureCanvasAgg is non-interactive, and thus cannot be shown:UserWarning")
@pytest.mark.filterwarnings("ignore:Number of gridcells.*exceeds maximum.*:UserWarning")
def test_case_2_one_field_one_layer_multiple_gridcells():
    """Case 2: one field, one layer, multiple (lon, lat)"""
    cv.make_time_series(field_a, layers=["Total"], gridop=None, title="Case 2")


@pytest.mark.filterwarnings("ignore:FigureCanvasAgg is non-interactive, and thus cannot be shown:UserWarning")
@pytest.mark.filterwarnings("ignore:Number of gridcells.*exceeds maximum.*:UserWarning")
def test_case_2b_one_field_one_layer_multiple_sites():
    """Case 2b: one field, one layer, multiple sites"""
    cv.make_time_series(field_sites, layers=["Total"], gridop=None, title="Case 2b")


@pytest.mark.filterwarnings("ignore:FigureCanvasAgg is non-interactive, and thus cannot be shown:UserWarning")
def test_case_3_one_field_multiple_layers_reduced_grid():
    """Case 3: one field, multiple layers, reduced grid"""
    cv.make_time_series(field_a, layers=["Total", "C3_gr"], rolling_size=5, gridop="av", title="Case 3")


@pytest.mark.filterwarnings("ignore:FigureCanvasAgg is non-interactive, and thus cannot be shown:UserWarning")
@pytest.mark.filterwarnings("ignore:Number of gridcells.*exceeds maximum.*:UserWarning")
def test_case_4_one_field_multiple_layers_multiple_gridcells():
    """Case 4: one field, multiple layers, multiple (lon, lat)"""
    cv.make_time_series(
        field_a, layers=["Total", "C3_gr"], gridop=None, reverse_hue_style=True, title="Case 4"
    )


@pytest.mark.filterwarnings("ignore:FigureCanvasAgg is non-interactive, and thus cannot be shown:UserWarning")
def test_case_5_multiple_fields_one_layer_reduced_grid():
    """Case 5: multiple fields, one layer each, reduced grid"""
    cv.make_time_series(
        [field_a, field_b],
        field_labels=["Field A", "Field B"],
        layers=["Total"],
        gridop="av",
        title="Case 5",
    )


@pytest.mark.filterwarnings("ignore:FigureCanvasAgg is non-interactive, and thus cannot be shown:UserWarning")
@pytest.mark.filterwarnings("ignore:Number of gridcells.*exceeds maximum.*:UserWarning")
def test_case_6_multiple_fields_one_layer_multiple_gridcells():
    """Case 6: multiple fields, one layer each, multiple (lon, lat)"""
    cv.make_time_series(
        [field_a, field_b],
        field_labels=["Field A", "Field B"],
        layers=["Total"],
        gridop=None,
        title="Case 6",
    )


@pytest.mark.filterwarnings("ignore:FigureCanvasAgg is non-interactive, and thus cannot be shown:UserWarning")
def test_case_7_multiple_fields_multiple_layers_reduced_grid():
    """Case 7: multiple fields, multiple layers each, reduced grid"""
    cv.make_time_series(
        [field_a, field_b],
        field_labels=["Field A", "Field B"],
        layers=["Total", "C3_gr"],
        gridop="av",
        title="Case 7",
    )


@pytest.mark.filterwarnings("ignore:FigureCanvasAgg is non-interactive, and thus cannot be shown:UserWarning")
def test_case_8_pre_reduced_grid():
    """Case 8: one field with pre-reduced grid (passed directly, no gridop)"""
    field_red = field_a.reduce_grid("av")
    cv.make_time_series(fields=field_red, layers=["Total"], title="Case 8")