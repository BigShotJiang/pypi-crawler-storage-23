import warnings

# Suppress pyproj warning about PROJ database path (temporary fix)
warnings.filterwarnings("ignore", category=UserWarning, module="pyproj.network")

try:
    from ._version import __version__
except ImportError:
    __version__ = "unknown"

def version():
    return __version__

from canopy.core.field import Field
from canopy.core.raster import Raster
from canopy.core.redspec import RedSpec
from canopy.core.constants import *
from canopy.sources import get_source
from canopy.util.fieldops import make_raster, make_lines, filter_region
from canopy.util.compare_ts import compare_ts
from canopy.util.overlap import overlap
from canopy.util.unite import unite
from canopy.util.join import join
from canopy.json.run_json import run_json
from canopy.tests.test_data.registry import list_test_data, load_test_data
