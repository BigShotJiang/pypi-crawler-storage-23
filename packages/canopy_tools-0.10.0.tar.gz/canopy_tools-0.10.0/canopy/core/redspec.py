from typing import Optional
from dataclasses import dataclass

@dataclass
class RedSpec:
    layers: Optional[list[str] | str] = None
    slices: dict[str,tuple] | None = None
    gridop: str | None = None
    axis: str = 'both'
    timeop: str | None = None
    freq: str | None = None

    def __post_init__(self):
        if isinstance(self.layers, str):
            self.layers = [self.layers]
