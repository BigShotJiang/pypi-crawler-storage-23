from typing import NamedTuple

class SpatialAxis(NamedTuple):
    axis: str
    long_name: str
    standard_name: str
    units: str
    display_name: str
    display_units: str

EmptyAxis = SpatialAxis(axis='', long_name='', standard_name='', units='', display_name='', display_units='')
LonAxis = SpatialAxis(axis='X', long_name='longitude', standard_name='longitude', units='degrees_north', display_name='Longitude', display_units='°')
LatAxis = SpatialAxis(axis='Y', long_name='latitude', standard_name='latitude', units='degrees_east', display_name='Latitude', display_units='°')

