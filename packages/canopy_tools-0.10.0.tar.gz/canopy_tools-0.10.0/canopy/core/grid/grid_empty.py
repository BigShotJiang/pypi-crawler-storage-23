import copy
import warnings
import pandas as pd
from typing_extensions import Self
from canopy.core.grid.spatial_axis import SpatialAxis, EmptyAxis
from canopy.core.grid.grid_abc import Grid
from canopy.core.grid.registry import register_grid

grid_type = 'empty'

@register_grid
class GridEmpty(Grid):
    """Grid associated to an empty DataFrame."""

    _grid_type: str = grid_type
    _xaxis_key: str = '(X, emtpy)'
    _yaxis_key: str = '(Y, emtpy)'
    _xaxis: SpatialAxis = EmptyAxis
    _yaxis: SpatialAxis = EmptyAxis

    def __init__(self):
        super().__init__(xaxis_gridop=None, yaxis_gridop=None)

    @classmethod
    def from_frame(cls, df: pd.DataFrame) -> Self:
        raise ValueError("GridEmpty does not support construction from a pandas DataFrame")

    def validate_frame(self, df: pd.DataFrame) -> bool:
        if df.empty or (len(df.index.names) == 1 and 'time' in df.index.names):
            return True
        else:
            warnings.warn("An empty grid can only be associated to an empty DataFrame or time-series data.")
            return False

    def crop(self, df: pd.DataFrame) -> Grid:
        return GridEmpty()

    def reduce(self, gridop: str, axis: str) -> Grid:
        return GridEmpty()

    def is_compatible(self, other) -> bool:
        return True

    def __add__(self, other):
        return copy.deepcopy(other)

