canopy.source\_data
===================

canopy.source\_data.registry
----------------------------

.. automodule:: canopy.source_data.registry
   :members:
   :show-inheritance:
   :undoc-members: