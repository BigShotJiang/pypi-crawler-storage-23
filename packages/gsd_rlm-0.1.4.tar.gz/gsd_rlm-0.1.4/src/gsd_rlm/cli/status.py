"""Status command for GSD-RLM CLI."""

from pathlib import Path

import typer


def status():
    """Show current GSD-RLM project status."""
    cwd = Path.cwd()
    planning_dir = cwd / ".planning"

    if not planning_dir.exists():
        typer.secho(
            "Not a GSD-RLM project (no .planning/ directory)", fg=typer.colors.YELLOW
        )
        return

    state_file = planning_dir / "STATE.md"
    if not state_file.exists():
        typer.secho("GSD-RLM project found but no STATE.md", fg=typer.colors.YELLOW)
        return

    # Read and parse STATE.md for key info
    content = state_file.read_text(encoding="utf-8")

    typer.secho("GSD-RLM Project", fg=typer.colors.GREEN)
    typer.echo("-" * 40)

    # Extract key fields from STATE.md
    for line in content.split("\n"):
        if line.startswith("Phase:"):
            typer.secho(f"  {line}", fg=typer.colors.CYAN)
        elif line.startswith("Plan:"):
            typer.secho(f"  {line}", fg=typer.colors.CYAN)
        elif line.startswith("Status:"):
            typer.secho(f"  {line}", fg=typer.colors.CYAN)
