"""
GSD-RLM CLI module with typer framework.

Provides command-line interface for GSD-RLM operations.
"""

import typer

from gsd_rlm.cli import version, status, init, install, setup

app = typer.Typer(
    name="gsd-rlm",
    help="Get Shit Done with Reinforcement Learning for Multi-Agent Systems",
    no_args_is_help=True,
)

# Register subcommands
app.command("version")(version.version)
app.command("status")(status.status)
app.command("init")(init.init)
app.command("install-commands")(install.install_commands)
app.command("setup")(setup.setup)


def main():
    """Entry point called by pip-installed script."""
    app()
