"""Version command for GSD-RLM CLI."""

import typer

from gsd_rlm import __version__


def version():
    """Show GSD-RLM version information."""
    typer.secho(f"GSD-RLM version: {__version__}", fg=typer.colors.CYAN)
    typer.echo("Get Shit Done with Reinforcement Learning for Multi-Agent Systems")
    typer.echo("Documentation: https://github.com/gsd-rlm/gsd-rlm")
