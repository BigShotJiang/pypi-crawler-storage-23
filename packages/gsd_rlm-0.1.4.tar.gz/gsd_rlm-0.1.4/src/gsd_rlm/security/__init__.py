"""
Security module for agent memory encryption and trust zones.

This module provides:
- MemoryEncryptor: AES-256-GCM encryption for agent memories
- TrustZone: Security level classification for agents
- ZoneAssignment: Agent-to-zone mapping
- AccessGrant: Explicit cross-zone access permissions
- ZoneAccessManager: Grant/revoke and validation for cross-zone access
- ViolationLog: Audit trail for trust zone violations
- EncryptedEpisodeStore: Transparent encryption wrapper for EpisodeStore
- SecureAgent: Agent wrapper with trust zone enforcement and encrypted memories
- SecureAgentConfig: Configuration for SecureAgent

Requirements: SEC-01 (encryption), SEC-02 (trust zones),
              SEC-03 (grant/revoke), SEC-04 (access validation)
"""

from .encryption import MemoryEncryptor, EncryptedData
from .trust_zones import TrustZone, ZoneAssignment
from .access_control import AccessGrant, ZoneAccessManager, ViolationLog
from .secure_storage import EncryptedEpisodeStore
from .agent import SecureAgent, SecureAgentConfig

__all__ = [
    # Encryption
    "MemoryEncryptor",
    "EncryptedData",
    # Trust Zones
    "TrustZone",
    "ZoneAssignment",
    # Access Control
    "AccessGrant",
    "ZoneAccessManager",
    "ViolationLog",
    # Secure Storage
    "EncryptedEpisodeStore",
    # Secure Agent
    "SecureAgent",
    "SecureAgentConfig",
]
