"""
GSD-RLM: Get Shit Done with Reinforcement Learning for Multi-Agent Systems

A YAML-based agent definition system with automatic validation, per-agent tool
whitelisting, and multi-provider LLM configuration. Built on RLM-Toolkit.
"""

__version__ = "0.1.0"

from gsd_rlm.agents.definition import AgentDefinition, ToolSpec, LLMProvider
from gsd_rlm.agents.loader import AgentLoader, load_agent

__all__ = [
    "AgentDefinition",
    "ToolSpec",
    "LLMProvider",
    "AgentLoader",
    "load_agent",
]
