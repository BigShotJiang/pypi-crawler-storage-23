"""
GSD-RLM Self-Improvement and Optimization Module.

Provides execution trace collection, DSPy prompt optimization,
R-Zero self-refinement, and optimization scheduling.

Requirements: SEC-05, SEC-06, SEC-07, SEC-08
"""

from gsd_rlm.optimization.traces import ExecutionTrace, TraceCollector
from gsd_rlm.optimization.metrics import (
    task_success_metric,
    quality_metric,
    latency_metric,
    composite_metric,
    MetricRegistry,
)
from gsd_rlm.optimization.optimizer import AgentOptimizer, OptimizationResult
from gsd_rlm.optimization.rzero import (
    ChallengerFeedback,
    RefinementStatus,
    RefinementResult,
    RZeroLoop,
    ChallengerSignature,
)
from gsd_rlm.optimization.scheduler import (
    OptimizationRun,
    OptimizationMetricsTracker,
    OptimizationScheduler,
)

__all__ = [
    # Traces (from 06-01)
    "ExecutionTrace",
    "TraceCollector",
    # Metrics (from 06-02)
    "task_success_metric",
    "quality_metric",
    "latency_metric",
    "composite_metric",
    "MetricRegistry",
    # Optimizer (from 06-02)
    "AgentOptimizer",
    "OptimizationResult",
    # R-Zero self-refinement (from 06-03)
    "ChallengerFeedback",
    "RefinementStatus",
    "RefinementResult",
    "RZeroLoop",
    "ChallengerSignature",
    # Optimization Scheduling (from 06-04)
    "OptimizationRun",
    "OptimizationMetricsTracker",
    "OptimizationScheduler",
]
