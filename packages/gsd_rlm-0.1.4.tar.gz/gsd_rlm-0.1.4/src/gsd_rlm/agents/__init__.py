"""
Agent definition and loading system.

Provides:
- AgentDefinition: Pydantic model for YAML agent definitions
- ToolSpec: Tool specification with optional config
- LLMProvider: Supported LLM provider types
- AgentLoader: YAML file loading with validation
"""

from gsd_rlm.agents.definition import AgentDefinition, ToolSpec, LLMProvider
from gsd_rlm.agents.loader import AgentLoader, AgentLoaderError, load_agent

__all__ = [
    "AgentDefinition",
    "ToolSpec",
    "LLMProvider",
    "AgentLoader",
    "AgentLoaderError",
    "load_agent",
]
