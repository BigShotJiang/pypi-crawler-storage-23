"""
Session management for GSD-RLM.

Provides file-based session memory for persistent conversation history.
"""

from gsd_rlm.session.memory import (
    FileSessionMemory,
    SessionState,
    SessionMessage,
    TaskOutput,
)
from gsd_rlm.session.persistence import (
    save_json,
    load_json,
    SessionFileManager,
)

__all__ = [
    # Memory
    "FileSessionMemory",
    "SessionState",
    "SessionMessage",
    "TaskOutput",
    # Persistence
    "save_json",
    "load_json",
    "SessionFileManager",
]
