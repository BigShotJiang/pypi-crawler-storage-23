"""
GSD-RLM Configuration System

Provides global and per-agent configuration for LLM providers,
project settings, and execution parameters.
"""

from gsd_rlm.config.settings import GSDConfig, LLMConfig
from gsd_rlm.config.global_config import (
    GlobalConfig,
    get_config_dir,
    get_data_dir,
    get_config_path,
    load_global_config,
    save_global_config,
)

__all__ = [
    # Per-project configuration
    "GSDConfig",
    "LLMConfig",
    # Global user configuration
    "GlobalConfig",
    "get_config_dir",
    "get_data_dir",
    "get_config_path",
    "load_global_config",
    "save_global_config",
]
