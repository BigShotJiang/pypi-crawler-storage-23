---
name: gsd-rlm-memory
description: Show RLM memory system status (H-MEM, Memory Bridge, InfiniRetri)
argument-hint: "[store] [--stats]"
allowed-tools:
  - read
  - bash
  - glob
---

<objective>
Display RLM memory system status and statistics.

**Memory Stores:**
- H-MEM: Hierarchical episodic memory (episodes → traces → categories → domain)
- Memory Bridge: Project facts at L0-L3 hierarchy
- InfiniRetri: Semantic chunking and compression for large documents

**Usage:**
- `/gsd-rlm-memory` — Show all stores summary
- `/gsd-rlm-memory hmem` — Show H-MEM details
- `/gsd-rlm-memory bridge` — Show Memory Bridge details
- `/gsd-rlm-memory --stats` — Show statistics
</objective>

<context>
Store: $ARGUMENTS (optional — shows all if omitted)

**Flags:**
- `--stats` — Include detailed statistics
</context>

<process>

## 1. Check Memory Directory

```bash
MEMORY_DIR=~/.gsd-rlm/memory
ls -la $MEMORY_DIR/ 2>/dev/null || echo "Memory directory not found"
```

## 2. H-MEM Status

Check H-MEM SQLite database:
```bash
if [ -f ~/.gsd-rlm/memory/hmem.db ]; then
  echo "H-MEM Database: Found"
  sqlite3 ~/.gsd-rlm/memory/hmem.db "SELECT COUNT(*) as episodes FROM episodes;" 2>/dev/null || echo "Unable to query"
else
  echo "H-MEM Database: Not initialized"
fi
```

## 3. Memory Bridge Status

Check Memory Bridge facts:
```bash
if [ -d ~/.gsd-rlm/memory/bridge ]; then
  echo "Memory Bridge: Found"
  find ~/.gsd-rlm/memory/bridge -name "*.json" | wc -l
else
  echo "Memory Bridge: Not initialized"
fi
```

## 4. InfiniRetri Cache

Check InfiniRetri cache:
```bash
if [ -d ~/.gsd-rlm/memory/infiniretri ]; then
  echo "InfiniRetri Cache: Found"
  du -sh ~/.gsd-rlm/memory/infiniretri 2>/dev/null
else
  echo "InfiniRetri Cache: Not initialized"
fi
```

## 5. Display Summary

Show formatted summary with recommendations.

</process>

<success_criteria>
- [ ] Memory directory checked
- [ ] H-MEM status displayed
- [ ] Memory Bridge status displayed
- [ ] InfiniRetri cache status displayed
- [ ] Summary with recommendations provided
</success_criteria>
