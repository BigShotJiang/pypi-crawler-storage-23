---
name: gsd-health
description: Diagnose planning directory health and optionally repair issues
argument-hint: [--repair]
allowed-tools:
  - read
  - bash
  - write
  - question
---
<objective>
Validate `.planning/` directory integrity and report actionable issues. Checks for missing files, invalid configurations, inconsistent state, and orphaned plans.
</objective>

<execution_context>
@~\.config\opencode/gsd-rlm/workflows/health.md
</execution_context>

<process>
Execute the health workflow from @~\.config\opencode/gsd-rlm/workflows/health.md end-to-end.
Parse --repair flag from arguments and pass to workflow.
</process>
