"""
Git integration module for atomic commits with traceability.

This module provides functionality for creating git commits that are
traceable to their originating phase, plan, and task.

Requirements: INT-14 (atomic commits), INT-15 (traceability)
"""

from gsd_rlm.git.commits import (
    CommitMetadata,
    CommitType,
    GitError,
    GitCommandError,
    NotAGitRepositoryError,
    create_atomic_commit,
    get_commit_hash,
    get_staged_files,
    get_uncommitted_changes,
    is_git_repository,
    stage_files,
)
from gsd_rlm.git.traceability import (
    COMMIT_PATTERN,
    TraceabilityInfo,
    extract_traceability,
    generate_commit_report,
    get_commit_history,
    get_commits_by_plan,
    get_commits_by_task,
    get_phase_summary,
    validate_commit_message,
)

__all__ = [
    # CommitMetadata and types
    "CommitMetadata",
    "CommitType",
    # Exceptions
    "GitError",
    "GitCommandError",
    "NotAGitRepositoryError",
    # Commit functions
    "create_atomic_commit",
    "get_commit_hash",
    "get_staged_files",
    "get_uncommitted_changes",
    "is_git_repository",
    "stage_files",
    # Traceability
    "COMMIT_PATTERN",
    "TraceabilityInfo",
    "extract_traceability",
    "generate_commit_report",
    "get_commit_history",
    "get_commits_by_plan",
    "get_commits_by_task",
    "get_phase_summary",
    "validate_commit_message",
]
