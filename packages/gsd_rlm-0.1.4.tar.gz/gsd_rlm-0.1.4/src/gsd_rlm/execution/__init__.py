"""
Execution engine for sequential task processing.

Provides:
- SequentialTaskRunner: Execute tasks in sequence with full context passing
- TaskResult: Result of a single task execution
- RetryableAgent: Agent wrapper with retry and fallback logic
- ProgressReporter: Real-time progress reporting
- validate_input/validate_output: Input/output validation guardrails
- GracefulDegradation: Handle partial failures gracefully
- PartialResult: Track task success/failure/skipped status
- TaskStatus: Status enum for task execution states

Requirements: AGENT-02 (sequential execution), AGENT-06 (validation),
             AGENT-07 (progress), AGENT-08 (retry/fallback),
             EXEC-13 (retry), EXEC-14 (fallback), EXEC-15 (partial results)
"""

from gsd_rlm.execution.runner import SequentialTaskRunner, TaskResult
from gsd_rlm.execution.retry import (
    RetryableAgent,
    RetryConfig,
    AgentExecutionError,
    FallbackExhaustedError,
    with_retry,
)
from gsd_rlm.execution.progress import (
    ProgressReporter,
    ProgressStatus,
    ProgressEvent,
    ProgressCallback,
    simple_progress_callback,
)
from gsd_rlm.execution.validation import (
    validate_input,
    validate_output,
    ValidationError,
    ValidationRule,
    create_custom_validator,
)
from gsd_rlm.execution.degradation import (
    TaskStatus,
    PartialResult,
    GracefulDegradation,
    DependencyGraphProtocol,
)

__all__ = [
    # Runner
    "SequentialTaskRunner",
    "TaskResult",
    # Retry
    "RetryableAgent",
    "RetryConfig",
    "AgentExecutionError",
    "FallbackExhaustedError",
    "with_retry",
    # Progress
    "ProgressReporter",
    "ProgressStatus",
    "ProgressEvent",
    "ProgressCallback",
    "simple_progress_callback",
    # Validation
    "validate_input",
    "validate_output",
    "ValidationError",
    "ValidationRule",
    "create_custom_validator",
    # Degradation
    "TaskStatus",
    "PartialResult",
    "GracefulDegradation",
    "DependencyGraphProtocol",
]
