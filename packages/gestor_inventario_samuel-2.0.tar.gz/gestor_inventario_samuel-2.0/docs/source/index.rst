Documentación do Xestor de Inventario
=====================================

Benvido/a á documentación oficial do Xestor de Inventario. Unha aplicación de escritorio desenvolvida en Python utilizando GTK3 para a interface gráfica e SQLite para a persistencia de datos.

.. toctree::
   :maxdepth: 2
   :caption: Contidos Principais:

   api_reference
   guias/01_instalacion_y_uso
   guias/02_arquitectura