"""bicep-whatif-advisor: Azure What-If deployment analyzer using LLMs."""

__version__ = "2.5.3"
