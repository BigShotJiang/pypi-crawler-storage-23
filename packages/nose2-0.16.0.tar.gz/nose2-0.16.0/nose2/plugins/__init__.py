from nose2.plugins._constants import DEFAULT_PLUGINS

__all__ = ("DEFAULT_PLUGINS",)
