# statement run at import time should be covered
foo = 1


# so should an ordinary function body
def func():
    return 2
