import unittest

raise ImportError("booms")


def test():
    pass


class Test(unittest.TestCase):
    def test(self):
        pass
