def test_demo():
    x = 1
    y = 2
    # fmt: off
    assert (x
            >
            y), "oh noez, x <= y"
    # fmt: on
