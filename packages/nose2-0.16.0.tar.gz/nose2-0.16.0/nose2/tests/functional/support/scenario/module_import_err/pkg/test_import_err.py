raise ValueError("booms")

import unittest  # noqa: E402


def test():
    pass


class Test(unittest.TestCase):
    def test(self):
        pass
