"""
The __init__ file is loaded *before* the testsuite starts running in test
scenarios.
Therefore, even though it would be *great* if we could check that it gets
counted correctly by coverage, it's better to leave it out.
"""
