def some_other_func():
    """This is a function with an inline doctest.

    >>> a = 1
    >>> b = 2
    >>> a == b
    False
    """
    pass
