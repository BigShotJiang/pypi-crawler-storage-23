import unittest

import nose2


class Test(unittest.TestCase):
    def test(self):
        pass


if __name__ == "__main__":
    nose2.main()
