import unittest


def test_foo():
    pass


class TestFoo(unittest.TestCase):
    def test_foo(self):
        pass
