from nose2.main import discover, main

__version__ = "0.16.0"

__all__ = ("__version__", "discover", "main")
