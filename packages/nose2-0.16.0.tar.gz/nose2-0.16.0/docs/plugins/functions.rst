======================
Loader: Test Functions
======================

.. autoplugin :: nose2.plugins.loader.functions.Functions
