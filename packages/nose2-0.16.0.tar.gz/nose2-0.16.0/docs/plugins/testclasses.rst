====================
Loader: Test Classes
====================

.. autoplugin :: nose2.plugins.loader.testclasses.TestClassLoader
