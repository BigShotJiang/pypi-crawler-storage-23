================================
Default filter: :attr:`__test__`
================================

.. autoplugin :: nose2.plugins.dundertest.DunderTestFilter
