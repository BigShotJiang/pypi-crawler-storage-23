==========================
Dropping Into the Debugger
==========================

.. autoplugin :: nose2.plugins.debugger.Debugger
