Event reference
===============

.. automodule :: nose2.events
   :members:
   :undoc-members:
   :exclude-members: Hook, Plugin, PluginInterface, PluginMeta
