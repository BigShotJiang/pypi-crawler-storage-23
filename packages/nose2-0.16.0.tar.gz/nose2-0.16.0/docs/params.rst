===================
Parameterized tests
===================

.. autofunction :: nose2.tools.params

See also: :doc:`plugins/parameters`
