import random
import math
from Passio import *
import datetime
import json


class Dlearnm:
    def __init__(self):
        self.memory = []
        self.history = []
        self.modules = []
        self.passio = Passio("")
        self.random = random
        self.start_time = datetime.datetime.now()


    def add_module(self, anem, module):
        self.modules[name] = module


    def use_module(self, name, *args, **kwargs):
        if name in self.modules:
            return self.modules[name] (*args, **kwargs)
        else:
            return f"Module {name} not found."




    def remember(self, data):
        self.memory.append(data)


    def recall(self):
        return self.memory


    def save_history(self, data):
        self.history.append(data)


    def load_memory(self):
        return self.history


    def interact(self, input_data,):
        self.remember({"input": input_data})
        return f"Recieved: {input_data}"
    def learn(self, data):
        self.remember(data)
        return f"Learned: {data}"
    def uptime(self):
        return datetime.datetime.now() - self.start_time
    def save_memory_to_file(self, filename = "memory.json"):
        with open(filename, "w") as f:
            json.dump(self.memory, f)
    def load_memory_from_file(self, filename="memory.json"):
        try:
            with open(filename, "r") as f:
                self.memory = json.load(f)
        except:
            self.memory = []
