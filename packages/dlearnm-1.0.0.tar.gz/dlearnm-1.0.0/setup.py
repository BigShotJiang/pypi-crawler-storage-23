from setuptools import setup, find_packages
setup(
    name="Dlearnm",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "Passio",
    ],
    python_requires=">=3.8",
    description="a simple ai engine with Passio integration",
    author = "Ez__iO",
    url="https://github.com/ezioauditore206c-blip/passio",
)
