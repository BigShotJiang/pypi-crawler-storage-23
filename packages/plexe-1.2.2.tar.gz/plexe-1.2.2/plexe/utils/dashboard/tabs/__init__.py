"""Dashboard tabs."""
