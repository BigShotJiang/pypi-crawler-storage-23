"""
Ad Inventory Forecast Library.

A production-grade Python library for predicting ad inventory (impressions)
using hybrid forecasting: Growth-Seasonality Decomposition for organic traffic
and Analog "Copy" Model for event-driven spikes.
"""

from ad_inventory_forecast.models.decomposition import InventoryForecaster
from ad_inventory_forecast.models.analog import AnalogEventForecaster
from ad_inventory_forecast.models.auto import AutoForecaster
from ad_inventory_forecast.models.yoy_copy import YoYCopyForecaster
from ad_inventory_forecast.reconciliation.demographic import DemographicReconciler
from ad_inventory_forecast.tuning.auto_tuner import AutoTuner
from ad_inventory_forecast.core.advisor import ModelAdvisor, ModelAdvice
from ad_inventory_forecast.backtesting.metrics import (
    calculate_mase,
    calculate_smape,
    calculate_mape,
    calculate_rmse,
    calculate_mae,
)
from ad_inventory_forecast.pipeline import ForecastPipeline

__version__ = "0.1.0"

__all__ = [
    "InventoryForecaster",
    "AnalogEventForecaster",
    "AutoForecaster",
    "YoYCopyForecaster",
    "DemographicReconciler",
    "AutoTuner",
    "ModelAdvisor",
    "ModelAdvice",
    "calculate_mase",
    "calculate_smape",
    "calculate_mape",
    "calculate_rmse",
    "calculate_mae",
    "ForecastPipeline",
]
