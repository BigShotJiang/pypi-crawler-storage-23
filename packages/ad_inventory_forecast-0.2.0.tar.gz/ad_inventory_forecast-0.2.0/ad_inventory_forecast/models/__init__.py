"""Forecasting models module."""

from ad_inventory_forecast.models.decomposition import InventoryForecaster
from ad_inventory_forecast.models.analog import AnalogEventForecaster
from ad_inventory_forecast.models.ets import ETSForecaster
from ad_inventory_forecast.models.sarima import SARIMAForecaster
from ad_inventory_forecast.models.auto import AutoForecaster

__all__ = [
    "InventoryForecaster",
    "AnalogEventForecaster",
    "ETSForecaster",
    "SARIMAForecaster",
    "AutoForecaster",
]

# Optional imports for models with additional dependencies
try:
    from ad_inventory_forecast.models.prophet import ProphetForecaster
    __all__.append("ProphetForecaster")
except Exception:
    ProphetForecaster = None

try:
    from ad_inventory_forecast.models.ml_ensemble import MLEnsembleForecaster
    __all__.append("MLEnsembleForecaster")
except Exception:
    MLEnsembleForecaster = None
