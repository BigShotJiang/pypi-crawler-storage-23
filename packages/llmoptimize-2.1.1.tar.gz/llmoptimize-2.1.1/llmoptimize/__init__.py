"""
LLMOptimize - AI Cost Optimization Made Easy

Just import and use OpenAI as normal. LLMOptimize tracks everything automatically!
"""

__version__ = "2.1.1"
__author__ = "LLMOptimize Team"

import requests
import os
import uuid
import sys

SERVER_URL = "https://aioptimize.up.railway.app"

class Colors:
    PURPLE = '\033[95m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BOLD = '\033[1m'
    END = '\033[0m'

def _get_session_id():
    """Get or create persistent session ID"""
    session_file = os.path.expanduser("~/.llmoptimize_session")
    if os.path.exists(session_file):
        with open(session_file, 'r') as f:
            return f.read().strip()
    session_id = str(uuid.uuid4())
    try:
        with open(session_file, 'w') as f:
            f.write(session_id)
    except:
        pass
    return session_id

SESSION_ID = _get_session_id()

def _track_call(model, prompt_tokens, completion_tokens):
    """Automatically track API call to server"""
    try:
        requests.post(
            f"{SERVER_URL}/track",
            json={
                "model": model,
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "session_id": SESSION_ID
            },
            timeout=3
        )
    except:
        pass

def _patch_openai():
    """Patch OpenAI client to automatically track usage"""
    try:
        import openai
        original_create = openai.resources.chat.completions.Completions.create
        
        def tracked_create(self, *args, **kwargs):
            response = original_create(self, *args, **kwargs)
            if hasattr(response, 'usage') and response.usage:
                model = kwargs.get('model', 'unknown')
                _track_call(
                    model=model,
                    prompt_tokens=response.usage.prompt_tokens,
                    completion_tokens=response.usage.completion_tokens
                )
            return response
        
        openai.resources.chat.completions.Completions.create = tracked_create
    except ImportError:
        pass
    except Exception:
        pass

_patch_openai()

def report():
    """Show your beautiful cost optimization report!"""
    print(f"{Colors.PURPLE}{Colors.BOLD}")
    print("╔══════════════════════════════════════════╗")
    print("║     🎉  LLMOptimize Report  🎉          ║")
    print("╚══════════════════════════════════════════╝")
    print(f"{Colors.END}\n")
    
    try:
        response = requests.get(f"{SERVER_URL}/session/{SESSION_ID}", timeout=10)
        if response.status_code == 200:
            data = response.json()
        else:
            data = _get_demo_data()
            print(f"{Colors.YELLOW}ℹ️  No data yet. Make some API calls first!{Colors.END}\n")
    except:
        data = _get_demo_data()
        print(f"{Colors.YELLOW}ℹ️  Using demo data{Colors.END}\n")
    
    total_calls = data.get('total_calls', 0)
    total_cost = data.get('total_cost', 0)
    total_savings = data.get('total_savings', 0)
    avg_pct = data.get('avg_savings_pct', 0)
    
    print(f"{Colors.CYAN}📊 USAGE SUMMARY{Colors.END}")
    print(f"   Total API Calls: {Colors.BOLD}{total_calls}{Colors.END}")
    print(f"   Total Cost: {Colors.BOLD}${total_cost:.2f}{Colors.END}\n")
    
    if total_savings > 0:
        print(f"{Colors.GREEN}💰 POTENTIAL SAVINGS{Colors.END}")
        print(f"   You could save: {Colors.BOLD}${total_savings:.2f}{Colors.END}")
        print(f"   That's {Colors.BOLD}{avg_pct}%{Colors.END} less!\n")
    
    recommendations = data.get('recommendations', [])
    if recommendations:
        print(f"{Colors.PURPLE}💡 RECOMMENDATIONS{Colors.END}")
        for i, rec in enumerate(recommendations[:2], 1):
            model = rec.get('model', 'gpt-3.5-turbo')
            savings = rec.get('savings_text', '90%')
            print(f"   {i}. {Colors.BOLD}{model}{Colors.END} - Save {Colors.GREEN}{savings}{Colors.END}")
        print()
    
    print(f"{Colors.GREEN}✨ Keep tracking to see more insights!{Colors.END}\n")

def _get_demo_data():
    """Demo data for new users"""
    return {
        "total_calls": 0,
        "total_cost": 0.00,
        "total_savings": 0.00,
        "avg_savings_pct": 0,
        "recommendations": [
            {"model": "gpt-3.5-turbo", "savings_text": "90%"},
            {"model": "claude-3-haiku", "savings_text": "85%"}
        ]
    }

def track(model, prompt_tokens, completion_tokens):
    """Manually track an API call (for non-OpenAI APIs)"""
    _track_call(model, prompt_tokens, completion_tokens)
    return {"status": "tracked"}

__all__ = ['report', 'track', '__version__']