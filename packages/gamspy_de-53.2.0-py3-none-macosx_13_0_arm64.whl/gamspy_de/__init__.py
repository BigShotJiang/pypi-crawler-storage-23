import os
from pathlib import Path
from .version import __version__
directory = str(Path(__file__).resolve().parent)

files = ['optde.def', 'libsptdclib64.dylib']

file_paths = [directory + os.sep + file for file in files]
verbatim = 'DE 102011 5 00010203040506070809 0 0 2 EMP\ngmsgenus.run\ngmsgenux.out\nlibsptdclib64.dylib spq 1 0'
