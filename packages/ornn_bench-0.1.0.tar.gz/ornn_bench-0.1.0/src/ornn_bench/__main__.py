"""Allow running ornn-bench as ``python -m ornn_bench``."""

from ornn_bench.cli import app_entry

app_entry()
