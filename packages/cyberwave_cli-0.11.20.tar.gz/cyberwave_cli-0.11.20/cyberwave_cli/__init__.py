"""Cyberwave CLI - The official command-line interface for Cyberwave."""

__version__ = "0.11.7"
