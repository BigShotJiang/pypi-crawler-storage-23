# Theodolite Scanner — Cloud Shell Quick Start

The fastest way to run a scan with **zero egress fees**. Paste one command
into your cloud provider's browser-based shell. No software to install on
your computer, no VM to provision.

---

## AWS — CloudShell

1. Open [AWS CloudShell](https://console.aws.amazon.com/cloudshell/)
2. Paste:

```bash
pip install -q theodolite-scanner[aws] && theodolite-scan -p aws --upload https://api.theodolite.io --token YOUR_TOKEN -o findings.json
```

CloudShell is already authenticated with your AWS session. The scanner
auto-discovers all S3 buckets and scans them. No access keys needed.

To scan a specific bucket:

```bash
pip install -q theodolite-scanner[aws] && theodolite-scan -p aws --bucket my-bucket --upload https://api.theodolite.io --token YOUR_TOKEN -o findings.json
```

---

## Azure — Cloud Shell

1. Open [Azure Cloud Shell](https://shell.azure.com/) (select Bash)
2. Paste:

```bash
pip install -q theodolite-scanner[azure] && theodolite-scan -p azure --client-id YOUR_CLIENT_ID --tenant-id YOUR_TENANT_ID --client-secret YOUR_SECRET --upload https://api.theodolite.io --token YOUR_TOKEN -o findings.json
```

Azure Cloud Shell runs inside your subscription, so data stays in-region.

To scan a specific container:

```bash
pip install -q theodolite-scanner[azure] && theodolite-scan -p azure --account-url https://ACCOUNT.blob.core.windows.net --container CONTAINER --upload https://api.theodolite.io --token YOUR_TOKEN -o findings.json
```

---

## GCP — Cloud Shell

1. Open [GCP Cloud Shell](https://shell.cloud.google.com/)
2. Paste:

```bash
pip install -q theodolite-scanner[gcp] && theodolite-scan -p gcp --project YOUR_PROJECT_ID --upload https://api.theodolite.io --token YOUR_TOKEN -o findings.json
```

Cloud Shell uses your default credentials and runs in-region.

To scan a specific bucket:

```bash
pip install -q theodolite-scanner[gcp] && theodolite-scan -p gcp --bucket my-bucket --upload https://api.theodolite.io --token YOUR_TOKEN -o findings.json
```

---

## Why Cloud Shell?

| | From laptop | From Cloud Shell |
|---|---|---|
| Egress cost | $0.09/GB | **$0** |
| Install needed | Python + pip | Nothing (pre-installed) |
| Credentials | Access keys / JSON file | Already authenticated |
| 50 GB scan cost | ~$4.50 | **$0** |

---

## For larger environments

Cloud Shell sessions timeout after 20-30 minutes of inactivity. For large
environments (100+ GB), use the deployment templates in this directory:

- `aws-cloudformation.yaml` — Launches a spot EC2 instance (~$0.003/hr)
- `azure-container.sh` — Runs an Azure Container Instance
- `gcp-cloudrun.sh` — Runs a GCP Cloud Run job

These run to completion regardless of session timeout and self-terminate
when done.

---

## Weekly scheduled scans

For recurring scans, add the one-liner to:

- **AWS**: EventBridge rule → Lambda / ECS task
- **Azure**: Logic App timer → Container Instance
- **GCP**: Cloud Scheduler → Cloud Run job

Or use any CI/CD tool (GitHub Actions, Jenkins, etc.) with a cron schedule.
