#!/bin/bash
#
# Theodolite Scanner — Azure Container Instance deployment
#
# Runs the scanner in a container in your Azure subscription.
# The container runs in the same region as your storage accounts,
# so there are no egress fees. It auto-deletes when done.
#
# Usage:
#   chmod +x azure-container.sh
#   ./azure-container.sh
#
# Or paste the 'az container create' command below into Azure Cloud Shell.
#
# Prerequisites:
#   - Azure CLI (az) logged in, or run from Azure Cloud Shell
#   - A resource group to deploy into
#

set -e

echo "=== Theodolite Scanner — Azure Deployment ==="
echo ""

# Collect inputs
read -p "Resource group name: " RESOURCE_GROUP
read -p "Region (e.g. centralus, eastus): " LOCATION
read -p "Theodolite API token: " -s API_TOKEN
echo ""
read -p "Scan type [full/quick] (default: full): " SCAN_TYPE
SCAN_TYPE=${SCAN_TYPE:-full}

# Azure credentials — the container inherits the managed identity
# For service principal auth, provide these:
read -p "Tenant ID (from App Registration): " TENANT_ID
read -p "Client ID (from App Registration): " CLIENT_ID
read -p "Client Secret: " -s CLIENT_SECRET
echo ""

read -p "Subscription ID (leave blank for all): " SUBSCRIPTION_ID

echo ""
echo "Deploying scanner container..."

# Build the scan command
SCAN_CMD="pip install -q theodolite-scanner[azure] && theodolite-scan -p azure --client-id $CLIENT_ID --tenant-id $TENANT_ID --client-secret \$CLIENT_SECRET --scan-type $SCAN_TYPE --upload https://api.theodolite.io --token \$API_TOKEN -o /tmp/findings.json"

if [ -n "$SUBSCRIPTION_ID" ]; then
    SCAN_CMD="$SCAN_CMD --subscription-id $SUBSCRIPTION_ID"
fi

az container create \
    --resource-group "$RESOURCE_GROUP" \
    --name theodolite-scanner \
    --image python:3.12-slim \
    --location "$LOCATION" \
    --cpu 1 \
    --memory 2 \
    --restart-policy Never \
    --environment-variables \
        CLIENT_SECRET="$CLIENT_SECRET" \
        API_TOKEN="$API_TOKEN" \
    --command-line "/bin/bash -c '$SCAN_CMD'" \
    --no-wait

echo ""
echo "Scanner deployed. It will run in the background and upload results"
echo "to your Theodolite dashboard when complete."
echo ""
echo "Monitor progress:"
echo "  az container logs --resource-group $RESOURCE_GROUP --name theodolite-scanner --follow"
echo ""
echo "Clean up after completion:"
echo "  az container delete --resource-group $RESOURCE_GROUP --name theodolite-scanner -y"
