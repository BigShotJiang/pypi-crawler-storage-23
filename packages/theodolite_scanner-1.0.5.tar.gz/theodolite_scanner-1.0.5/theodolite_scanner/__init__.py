"""Theodolite CLI Scanner — runs inside customer environments."""

__version__ = "1.0.0"
