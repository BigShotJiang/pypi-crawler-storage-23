"""PII (Personally Identifiable Information) detection patterns.

Comprehensive patterns for detecting PII across multiple jurisdictions:
- United States (SSN, Driver's License, Passport)
- Canada (SIN, Health Card, Driver's License)
- United Kingdom (NI Number, NHS Number, Passport)
- European Union (National IDs, VAT numbers)
- General (Email, Phone, Address, Names)
"""

from __future__ import annotations

import re

from theodolite_scanner.classifier import DataCategory, DataType, Pattern


# =============================================================================
# Validation Functions
# =============================================================================

def validate_ssn(ssn: str) -> bool:
    """Validate US Social Security Number format and known invalid patterns."""
    digits = re.sub(r"[^0-9]", "", ssn)

    if len(digits) != 9:
        return False

    area = digits[:3]
    group = digits[3:5]
    serial = digits[5:]

    # Invalid area numbers
    if area == "000" or area == "666" or area[0] == "9":
        return False

    # Invalid group numbers
    if group == "00":
        return False

    # Invalid serial numbers
    if serial == "0000":
        return False

    # Reject if it looks like a date (last 4 digits are a year)
    # This catches patterns like XX-XX-2022 being mistaken for SSN
    # Only reject if ALL parts look like a date (very strict check)
    last_four = int(serial)
    if 1950 <= last_four <= 2030:  # Narrower year range
        middle = int(group)
        # Only reject if middle looks like month AND first looks like day
        if 1 <= middle <= 12:
            first_two = int(area[:2]) if area[:2].isdigit() else 0
            # Require the third digit to be 0-3 for a day pattern
            third_digit = int(area[2]) if area[2].isdigit() else 9
            if 1 <= first_two <= 31 and third_digit <= 3:
                return False  # Likely a date, not SSN

    # Reject sequential patterns
    if digits in ["123456789", "234567890", "012345678"]:
        return False

    # Known test/invalid SSNs
    invalid_ssns = [
        "123456789", "111111111", "222222222", "333333333",
        "444444444", "555555555", "777777777", "888888888",
        "123121234", "219099999", "078051120",  # Famous invalid
    ]
    if digits in invalid_ssns:
        return False

    return True


def validate_sin(sin: str) -> bool:
    """Validate Canadian Social Insurance Number using Luhn algorithm."""
    digits = re.sub(r"[^0-9]", "", sin)

    if len(digits) != 9:
        return False

    # SIN cannot start with 0 or 8
    if digits[0] in ("0", "8"):
        return False

    # Luhn checksum validation
    total = 0
    for i, digit in enumerate(digits):
        d = int(digit)
        if i % 2 == 1:  # Double every second digit
            d *= 2
            if d > 9:
                d -= 9
        total += d

    return total % 10 == 0


def validate_uk_nino(nino: str) -> bool:
    """Validate UK National Insurance Number format."""
    nino = nino.upper().replace(" ", "")

    if len(nino) != 9:
        return False

    # First two characters must be letters (except certain combinations)
    invalid_prefixes = ["BG", "GB", "NK", "KN", "TN", "NT", "ZZ"]
    prefix = nino[:2]
    if not prefix.isalpha() or prefix in invalid_prefixes:
        return False

    # Characters D, F, I, Q, U, V not used as first letter
    if nino[0] in "DFIQUV":
        return False

    # Character O not used as second letter
    if nino[1] == "O":
        return False

    # Next 6 characters must be digits
    if not nino[2:8].isdigit():
        return False

    # Last character must be A, B, C, or D
    if nino[8] not in "ABCD":
        return False

    return True


def validate_uk_nhs(nhs: str) -> bool:
    """Validate UK NHS Number using modulus 11 checksum."""
    digits = re.sub(r"[^0-9]", "", nhs)

    if len(digits) != 10:
        return False

    # Calculate checksum
    total = 0
    for i, digit in enumerate(digits[:-1]):
        total += int(digit) * (10 - i)

    remainder = total % 11
    check_digit = 11 - remainder

    if check_digit == 11:
        check_digit = 0
    elif check_digit == 10:
        return False  # Invalid NHS number

    return int(digits[-1]) == check_digit


def validate_itin(itin: str) -> bool:
    """Validate US Individual Taxpayer Identification Number."""
    digits = re.sub(r"[^0-9]", "", itin)

    if len(digits) != 9:
        return False

    # ITIN starts with 9 and has 70-88, 90-92, 94-99 in positions 4-5
    if digits[0] != "9":
        return False

    middle = int(digits[3:5])
    valid_middle = (70 <= middle <= 88) or (90 <= middle <= 92) or (94 <= middle <= 99)

    return valid_middle


# =============================================================================
# Pattern Definitions
# =============================================================================

def get_patterns() -> list[Pattern]:
    """Get all PII detection patterns."""
    return [
        # =====================================================================
        # US Patterns
        # =====================================================================

        # Social Security Number
        Pattern(
            name="ssn_us",
            data_type=DataType.SSN,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b(?!000|666|9\d{2})\d{3}[-\s]?(?!00)\d{2}[-\s]?(?!0000)\d{4}\b"
            ),
            validator=validate_ssn,
            confidence_base=0.88,
            context_patterns=[
                r"ssn",
                r"social\s*security",
                r"tax\s*id",
                r"taxpayer",
                r"ss\s*#",
                r"social\s*sec",
                r"employee",
                r"applicant",
                r"patient",
                r"member",
                r"customer",
                r"personal",
            ],
        ),

        # Individual Taxpayer Identification Number (ITIN)
        Pattern(
            name="itin_us",
            data_type=DataType.TAX_ID,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b9\d{2}[-\s]?(?:7[0-8]|8[0-8]|9[0-2]|9[4-9])[-\s]?\d{4}\b"
            ),
            validator=validate_itin,
            confidence_base=0.80,
            context_patterns=[
                r"itin",
                r"taxpayer",
                r"tax\s*id",
                r"individual\s*taxpayer",
            ],
        ),

        # US Passport Number
        Pattern(
            name="passport_us",
            data_type=DataType.PASSPORT,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b[A-Z]?\d{8,9}\b"
            ),
            confidence_base=0.40,
            context_patterns=[
                r"passport",
                r"travel\s*document",
                r"passport\s*#",
                r"passport\s*number",
            ],
        ),

        # US Driver's License (state-specific patterns)
        # California
        Pattern(
            name="drivers_license_ca",
            data_type=DataType.DRIVERS_LICENSE,
            category=DataCategory.PII,
            regex=re.compile(r"\b[A-Z]\d{7}\b"),
            confidence_base=0.50,
            context_patterns=[
                r"driver'?s?\s*licen[sc]e",
                r"dl\s*#?",
                r"license\s*number",
                r"california",
            ],
        ),
        # New York
        Pattern(
            name="drivers_license_ny",
            data_type=DataType.DRIVERS_LICENSE,
            category=DataCategory.PII,
            regex=re.compile(r"\b\d{9}\b"),
            confidence_base=0.35,
            context_patterns=[
                r"driver'?s?\s*licen[sc]e",
                r"dl\s*#?",
                r"new\s*york",
                r"ny\s*dl",
            ],
        ),
        # Florida
        Pattern(
            name="drivers_license_fl",
            data_type=DataType.DRIVERS_LICENSE,
            category=DataCategory.PII,
            regex=re.compile(r"\b[A-Z]\d{12}\b"),
            confidence_base=0.60,
            context_patterns=[
                r"driver'?s?\s*licen[sc]e",
                r"dl\s*#?",
                r"florida",
            ],
        ),
        # Texas
        Pattern(
            name="drivers_license_tx",
            data_type=DataType.DRIVERS_LICENSE,
            category=DataCategory.PII,
            regex=re.compile(r"\b\d{8}\b"),
            confidence_base=0.30,
            context_patterns=[
                r"driver'?s?\s*licen[sc]e",
                r"dl\s*#?",
                r"texas",
                r"tx\s*dl",
            ],
        ),

        # =====================================================================
        # Canadian Patterns
        # =====================================================================

        # Social Insurance Number (SIN)
        Pattern(
            name="sin_ca",
            data_type=DataType.SSN,  # Reusing SSN type for national ID
            category=DataCategory.PII,
            regex=re.compile(
                r"\b\d{3}[-\s]?\d{3}[-\s]?\d{3}\b"
            ),
            validator=validate_sin,
            confidence_base=0.75,
            context_patterns=[
                r"sin\b",
                r"social\s*insurance",
                r"canada",
                r"canadian",
            ],
        ),

        # Ontario Health Insurance Plan (OHIP)
        Pattern(
            name="ohip_ca",
            data_type=DataType.HEALTH_INSURANCE_ID,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b\d{4}[-\s]?\d{3}[-\s]?\d{3}[-\s]?[A-Z]{2}\b"
            ),
            confidence_base=0.80,
            context_patterns=[
                r"ohip",
                r"health\s*card",
                r"ontario",
                r"health\s*insurance",
            ],
        ),

        # =====================================================================
        # UK Patterns
        # =====================================================================

        # National Insurance Number (NINO)
        Pattern(
            name="nino_uk",
            data_type=DataType.SSN,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b[A-CEGHJ-PR-TW-Z]{2}\d{6}[A-D]\b",
                re.IGNORECASE,
            ),
            validator=validate_uk_nino,
            confidence_base=0.85,
            context_patterns=[
                r"national\s*insurance",
                r"ni\s*number",
                r"nino",
                r"uk",
                r"britain",
            ],
        ),

        # NHS Number
        Pattern(
            name="nhs_uk",
            data_type=DataType.HEALTH_INSURANCE_ID,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b\d{3}[-\s]?\d{3}[-\s]?\d{4}\b"
            ),
            validator=validate_uk_nhs,
            confidence_base=0.80,
            context_patterns=[
                r"nhs",
                r"national\s*health",
                r"health\s*service",
                r"uk",
            ],
        ),

        # UK Passport
        Pattern(
            name="passport_uk",
            data_type=DataType.PASSPORT,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b\d{9}\b"
            ),
            confidence_base=0.35,
            context_patterns=[
                r"passport",
                r"uk",
                r"british",
                r"travel\s*document",
            ],
        ),

        # UK Driving License
        Pattern(
            name="drivers_license_uk",
            data_type=DataType.DRIVERS_LICENSE,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b[A-Z]{5}\d{6}[A-Z\d]{5}\b"
            ),
            confidence_base=0.75,
            context_patterns=[
                r"driving\s*licen[sc]e",
                r"uk",
                r"british",
                r"dvla",
            ],
        ),

        # =====================================================================
        # European Union Patterns
        # =====================================================================

        # German Tax ID (Steuer-ID)
        Pattern(
            name="steuer_id_de",
            data_type=DataType.TAX_ID,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b\d{11}\b"
            ),
            confidence_base=0.40,
            context_patterns=[
                r"steuer",
                r"tax\s*id",
                r"german",
                r"deutschland",
            ],
        ),

        # French INSEE/NIR (Social Security)
        Pattern(
            name="nir_fr",
            data_type=DataType.SSN,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b[12]\d{2}(?:0[1-9]|1[0-2])\d{2}\d{3}\d{3}\d{2}\b"
            ),
            confidence_base=0.80,
            context_patterns=[
                r"insee",
                r"nir",
                r"s[eé]curit[eé]\s*sociale",
                r"france",
                r"french",
            ],
        ),

        # Spanish DNI/NIE
        Pattern(
            name="dni_es",
            data_type=DataType.SSN,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b(?:\d{8}[A-Z]|[XYZ]\d{7}[A-Z])\b"
            ),
            confidence_base=0.80,
            context_patterns=[
                r"dni",
                r"nie",
                r"spain",
                r"espa[ñn]a",
                r"spanish",
            ],
        ),

        # Italian Codice Fiscale
        Pattern(
            name="codice_fiscale_it",
            data_type=DataType.TAX_ID,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b[A-Z]{6}\d{2}[A-EHLMPRST]\d{2}[A-Z]\d{3}[A-Z]\b",
                re.IGNORECASE,
            ),
            confidence_base=0.85,
            context_patterns=[
                r"codice\s*fiscale",
                r"italy",
                r"italian",
                r"italia",
            ],
        ),

        # =====================================================================
        # General/Universal Patterns
        # =====================================================================

        # Email addresses
        Pattern(
            name="email",
            data_type=DataType.EMAIL,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"
            ),
            confidence_base=0.90,
            context_patterns=[
                r"email",
                r"e-mail",
                r"contact",
                r"mailto",
            ],
        ),

        # Phone numbers - US/Canada
        Pattern(
            name="phone_us_ca",
            data_type=DataType.PHONE,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b(?:\+1[-.\s]?)?"
                r"(?:\(?\d{3}\)?[-.\s]?)"
                r"\d{3}[-.\s]?"
                r"\d{4}\b"
            ),
            confidence_base=0.70,
            context_patterns=[
                r"phone",
                r"tel",
                r"mobile",
                r"cell",
                r"fax",
                r"contact",
                r"call",
            ],
        ),

        # Phone numbers - UK
        Pattern(
            name="phone_uk",
            data_type=DataType.PHONE,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b(?:\+44[-.\s]?|0)"
                r"(?:\d{4}[-.\s]?\d{6}|\d{3}[-.\s]?\d{4}[-.\s]?\d{4})\b"
            ),
            confidence_base=0.70,
            context_patterns=[
                r"phone",
                r"tel",
                r"mobile",
                r"uk",
            ],
        ),

        # Phone numbers - International E.164
        Pattern(
            name="phone_intl",
            data_type=DataType.PHONE,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b\+[1-9]\d{6,14}\b"
            ),
            confidence_base=0.75,
            context_patterns=[
                r"phone",
                r"tel",
                r"mobile",
                r"international",
            ],
        ),

        # Date of birth
        Pattern(
            name="date_of_birth",
            data_type=DataType.DATE_OF_BIRTH,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b(?:"
                r"(?:0?[1-9]|1[0-2])[-/](?:0?[1-9]|[12]\d|3[01])[-/](?:19|20)\d{2}"  # MM/DD/YYYY
                r"|(?:0?[1-9]|[12]\d|3[01])[-/](?:0?[1-9]|1[0-2])[-/](?:19|20)\d{2}"  # DD/MM/YYYY
                r"|(?:19|20)\d{2}[-/](?:0?[1-9]|1[0-2])[-/](?:0?[1-9]|[12]\d|3[01])"  # YYYY-MM-DD
                r")\b"
            ),
            confidence_base=0.50,
            context_patterns=[
                r"dob",
                r"date\s*of\s*birth",
                r"birth\s*date",
                r"born",
                r"birthday",
                r"d\.?o\.?b\.?",
            ],
        ),

        # Address - US
        # Fixed: street suffixes must be preceded by space to avoid matching "pytest", "const", etc.
        Pattern(
            name="address_us",
            data_type=DataType.ADDRESS,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b\d{1,5}\s+[A-Za-z][A-Za-z ]{2,30}"
                r"\s(?:street|avenue|road|drive|lane|boulevard|way|court|place|circle|highway|parkway|terrace)"
                r"\.?(?:\s+(?:apt|suite|unit|#|apartment|ste)\.?\s*\w+)?\b"
                r"|\b\d{1,5}\s+[A-Za-z][A-Za-z ]{2,30}"
                r"\s(?:st|ave|rd|dr|ln|blvd|ct|pl|cir|hwy|pkwy|ter)\."
                r"(?:\s+(?:apt|suite|unit|#|apartment|ste)\.?\s*\w+)?\b",
                re.IGNORECASE,
            ),
            confidence_base=0.65,  # Lowered slightly
            context_patterns=[
                r"address",
                r"residence",
                r"location",
                r"mail",
                r"ship",
            ],
        ),

        # ZIP codes - US
        Pattern(
            name="zipcode_us",
            data_type=DataType.ADDRESS,
            category=DataCategory.PII,
            regex=re.compile(r"\b\d{5}(?:-\d{4})?\b"),
            confidence_base=0.30,
            context_patterns=[
                r"zip",
                r"postal",
                r"address",
            ],
        ),

        # Postal code - UK
        Pattern(
            name="postcode_uk",
            data_type=DataType.ADDRESS,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}\b",
                re.IGNORECASE,
            ),
            confidence_base=0.70,
            context_patterns=[
                r"postcode",
                r"post\s*code",
                r"address",
                r"uk",
            ],
        ),

        # Postal code - Canada
        Pattern(
            name="postcode_ca",
            data_type=DataType.ADDRESS,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b[A-Z]\d[A-Z]\s*\d[A-Z]\d\b",
                re.IGNORECASE,
            ),
            confidence_base=0.70,
            context_patterns=[
                r"postal\s*code",
                r"address",
                r"canada",
            ],
        ),

        # IP Address v4
        Pattern(
            name="ipv4_address",
            data_type=DataType.ADDRESS,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}"
                r"(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\b"
            ),
            confidence_base=0.50,
            context_patterns=[
                r"ip\s*address",
                r"client\s*ip",
                r"source\s*ip",
                r"remote\s*addr",
            ],
        ),

        # MAC Address
        Pattern(
            name="mac_address",
            data_type=DataType.CUSTOM,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\b"
            ),
            confidence_base=0.60,
            context_patterns=[
                r"mac\s*address",
                r"hardware\s*address",
                r"physical\s*address",
            ],
        ),

        # IBAN (International Bank Account Number)
        Pattern(
            name="iban",
            data_type=DataType.BANK_ACCOUNT,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b[A-Z]{2}\d{2}[A-Z0-9]{4,30}\b"
            ),
            confidence_base=0.80,
            context_patterns=[
                r"iban",
                r"bank\s*account",
                r"international\s*bank",
            ],
        ),

        # Vehicle Identification Number (VIN)
        Pattern(
            name="vin",
            data_type=DataType.CUSTOM,
            category=DataCategory.PII,
            regex=re.compile(
                r"\b[A-HJ-NPR-Z0-9]{17}\b"
            ),
            confidence_base=0.60,
            context_patterns=[
                r"vin",
                r"vehicle\s*identification",
                r"chassis",
            ],
        ),
    ]
