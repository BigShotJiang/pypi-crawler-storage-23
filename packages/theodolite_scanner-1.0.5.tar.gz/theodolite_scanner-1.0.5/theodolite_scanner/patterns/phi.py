"""PHI (Protected Health Information) detection patterns.

Comprehensive patterns for detecting Protected Health Information as defined by HIPAA:
- Medical Record Numbers
- Health Insurance IDs (Medicare, Medicaid, Private)
- Diagnosis Codes (ICD-10, ICD-9)
- Procedure Codes (CPT, HCPCS)
- Drug Codes (NDC)
- Provider Identifiers (NPI, DEA)
- Health Plan Numbers
- Medical Device Identifiers
- Lab Result Patterns
- Clinical Terms and Conditions
"""

from __future__ import annotations

import re

from theodolite_scanner.classifier import DataCategory, DataType, Pattern


# =============================================================================
# Validation Functions
# =============================================================================

def validate_npi(npi: str) -> bool:
    """Validate National Provider Identifier using Luhn algorithm with prefix."""
    digits = re.sub(r"[^0-9]", "", npi)

    if len(digits) != 10:
        return False

    # NPI uses Luhn algorithm with prefix 80840
    full_number = "80840" + digits
    digits_list = [int(d) for d in full_number]

    total = 0
    for i, digit in enumerate(reversed(digits_list)):
        if i % 2 == 1:
            digit *= 2
            if digit > 9:
                digit -= 9
        total += digit

    return total % 10 == 0


def validate_medicare_mbi(mbi: str) -> bool:
    """Validate Medicare Beneficiary Identifier format."""
    mbi = mbi.upper().replace("-", "").replace(" ", "")

    if len(mbi) != 11:
        return False

    # Position patterns:
    # 1: 1-9
    # 2: A-Z (except S,L,O,I,B,Z)
    # 3: A-Z or 0-9 (except S,L,O,I,B,Z)
    # 4: 0-9
    # 5: A-Z (except S,L,O,I,B,Z)
    # 6: A-Z or 0-9 (except S,L,O,I,B,Z)
    # 7: 0-9
    # 8-9: A-Z (except S,L,O,I,B,Z)
    # 10-11: 0-9

    excluded = set("SLOBIZ")
    valid_alpha = set("ACDEFGHJKMNPQRTUVWXY")
    valid_alphanum = valid_alpha | set("0123456789")

    if mbi[0] not in "123456789":
        return False
    if mbi[1] not in valid_alpha:
        return False
    if mbi[2] not in valid_alphanum:
        return False
    if not mbi[3].isdigit():
        return False
    if mbi[4] not in valid_alpha:
        return False
    if mbi[5] not in valid_alphanum:
        return False
    if not mbi[6].isdigit():
        return False
    if mbi[7] not in valid_alpha:
        return False
    if mbi[8] not in valid_alpha:
        return False
    if not mbi[9:11].isdigit():
        return False

    return True


def validate_dea_number(dea: str) -> bool:
    """Validate DEA Number checksum."""
    dea = dea.upper().replace("-", "").replace(" ", "")

    if len(dea) != 9:
        return False

    # First char: registrant type (A, B, C, D, E, F, G, H, J, K, L, M, P, R, S, T, U, X)
    # Second char: first letter of registrant's last name or 9 for practitioners
    # Remaining 7 chars: numbers

    valid_first = set("ABCDEFGHJKLMPRSTUX")
    if dea[0] not in valid_first:
        return False

    if not dea[1].isalpha() and dea[1] != "9":
        return False

    if not dea[2:].isdigit():
        return False

    # Checksum validation
    digits = [int(d) for d in dea[2:]]
    sum1 = digits[0] + digits[2] + digits[4]
    sum2 = (digits[1] + digits[3] + digits[5]) * 2
    total = sum1 + sum2
    check_digit = total % 10

    return check_digit == digits[6]


# =============================================================================
# Pattern Definitions
# =============================================================================

def get_patterns() -> list[Pattern]:
    """Get all PHI detection patterns."""
    return [
        # =====================================================================
        # Medical Record Numbers
        # =====================================================================

        # Generic Medical Record Number
        Pattern(
            name="medical_record_number",
            data_type=DataType.MEDICAL_RECORD,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b(?:MRN|MR#|Medical\s*Record|Patient\s*ID)?\s*[:#]?\s*"
                r"[A-Z]{0,4}\d{6,12}\b",
                re.IGNORECASE,
            ),
            confidence_base=0.55,
            context_patterns=[
                r"mrn",
                r"medical\s*record",
                r"patient\s*(?:id|number|#)",
                r"chart\s*number",
                r"encounter",
                r"visit\s*(?:id|number)",
                r"admission",
                r"hospital",
                r"clinic",
                r"healthcare",
                r"medical",
                r"health",
            ],
        ),

        # Account Number (billing)
        Pattern(
            name="patient_account_number",
            data_type=DataType.MEDICAL_RECORD,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b(?:Account|Acct)?\s*[:#]?\s*\d{8,15}\b",
                re.IGNORECASE,
            ),
            confidence_base=0.40,
            context_patterns=[
                r"account\s*(?:number|#)",
                r"billing",
                r"patient\s*account",
                r"hospital\s*account",
            ],
        ),

        # =====================================================================
        # Health Insurance IDs
        # =====================================================================

        # Medicare Beneficiary Identifier (MBI) - new format since 2018
        Pattern(
            name="medicare_mbi",
            data_type=DataType.HEALTH_INSURANCE_ID,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b[1-9][AC-HJKMNP-RT-Y][AC-HJKMNP-RT-Y0-9]\d"
                r"[AC-HJKMNP-RT-Y][AC-HJKMNP-RT-Y0-9]\d"
                r"[AC-HJKMNP-RT-Y]{2}\d{2}\b"
            ),
            validator=validate_medicare_mbi,
            confidence_base=0.85,
            context_patterns=[
                r"medicare",
                r"mbi",
                r"cms",
                r"beneficiary",
                r"part\s*[abcd]",
            ],
        ),

        # Old Medicare HICN format (phased out but still in records)
        Pattern(
            name="medicare_hicn",
            data_type=DataType.HEALTH_INSURANCE_ID,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b\d{3}-?\d{2}-?\d{4}[A-Z]{1,2}\b"
            ),
            confidence_base=0.75,
            context_patterns=[
                r"medicare",
                r"hicn",
                r"health\s*insurance\s*claim",
            ],
        ),

        # Medicaid ID (state-specific, general pattern)
        Pattern(
            name="medicaid_id",
            data_type=DataType.HEALTH_INSURANCE_ID,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b[A-Z]{0,2}\d{8,12}\b"
            ),
            confidence_base=0.40,
            context_patterns=[
                r"medicaid",
                r"medi-cal",
                r"state\s*insurance",
                r"public\s*assistance",
            ],
        ),

        # Generic Health Insurance ID
        Pattern(
            name="health_insurance_id",
            data_type=DataType.HEALTH_INSURANCE_ID,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b[A-Z]{2,4}\d{8,12}\b"
            ),
            confidence_base=0.55,
            context_patterns=[
                r"insurance",
                r"member\s*id",
                r"subscriber",
                r"policy",
                r"group\s*number",
                r"beneficiary",
                r"coverage",
                r"carrier",
                r"health\s*plan",
                r"bcbs",
                r"blue\s*cross",
                r"aetna",
                r"cigna",
                r"united\s*health",
                r"anthem",
                r"humana",
                r"kaiser",
            ],
        ),

        # Group Number
        Pattern(
            name="insurance_group_number",
            data_type=DataType.HEALTH_INSURANCE_ID,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b(?:GRP|Group)\s*[:#]?\s*[A-Z0-9]{6,15}\b",
                re.IGNORECASE,
            ),
            confidence_base=0.60,
            context_patterns=[
                r"group",
                r"insurance",
                r"employer",
                r"plan",
            ],
        ),

        # =====================================================================
        # Diagnosis and Procedure Codes
        # =====================================================================

        # ICD-10-CM Diagnosis Codes
        # More restrictive: requires letter + 2 digits + decimal + at least 1 char
        # Examples: A00.0, B15.9, Z23, M54.5, E11.9
        Pattern(
            name="icd10_cm",
            data_type=DataType.DIAGNOSIS_CODE,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b[A-TV-Z]\d{2}\.\d[A-Z0-9]{0,3}\b"
            ),
            confidence_base=0.60,
            context_patterns=[
                r"icd-?10",
                r"diagnosis",
                r"dx\s*code",
                r"condition",
                r"disease",
                r"disorder",
                r"medical",
                r"health",
                r"patient",
                r"clinical",
                r"code",
            ],
        ),

        # ICD-10-PCS Procedure Codes
        Pattern(
            name="icd10_pcs",
            data_type=DataType.DIAGNOSIS_CODE,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b[0-9A-HJ-NP-Z]{7}\b"  # 7 alphanumeric characters
            ),
            confidence_base=0.50,
            context_patterns=[
                r"icd-?10-?pcs",
                r"procedure\s*code",
                r"surgical",
                r"operation",
            ],
        ),

        # ICD-9 Diagnosis Codes (legacy, still in historical records)
        # Require decimal part for numeric codes to avoid matching simple numbers
        # Examples: V12.52, 250.00, E850.0
        Pattern(
            name="icd9_code",
            data_type=DataType.DIAGNOSIS_CODE,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b(?:V\d{2}\.\d{1,2}|\d{3}\.\d{1,2}|E\d{3}\.\d)\b"
            ),
            confidence_base=0.50,  # Lowered - requires context
            context_patterns=[
                r"icd-?9",
                r"diagnosis",
                r"dx",
                r"legacy",
            ],
        ),

        # CPT Codes (Current Procedural Terminology)
        # Lower confidence - too generic (just 5 digits)
        Pattern(
            name="cpt_code",
            data_type=DataType.DIAGNOSIS_CODE,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b(?:99\d{3}|[0-8]\d{4})[A-Z]?\b"  # 5 digits, optional modifier
            ),
            confidence_base=0.35,  # Lowered - requires strong context
            context_patterns=[
                r"cpt\b",
                r"procedure\s*code",
                r"billing\s*code",
                r"service\s*code",
                r"evaluation\s*and\s*management",
                r"e/?m\s*code",
            ],
        ),

        # HCPCS Codes (Healthcare Common Procedure Coding System)
        Pattern(
            name="hcpcs_code",
            data_type=DataType.DIAGNOSIS_CODE,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b[A-V]\d{4}(?:[A-Z]{1,2})?\b"
            ),
            confidence_base=0.55,
            context_patterns=[
                r"hcpcs",
                r"dme",
                r"durable\s*medical",
                r"supply",
                r"ambulance",
            ],
        ),

        # =====================================================================
        # Drug and Medication Codes
        # =====================================================================

        # National Drug Code (NDC)
        Pattern(
            name="ndc_code",
            data_type=DataType.MEDICAL_RECORD,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b\d{4,5}[-\s]?\d{3,4}[-\s]?\d{1,2}\b"
            ),
            confidence_base=0.55,
            context_patterns=[
                r"ndc",
                r"drug\s*code",
                r"medication",
                r"prescription",
                r"pharmacy",
                r"formulary",
            ],
        ),

        # RxNorm Concept ID
        # Very low confidence - just 5-7 digits is too generic
        Pattern(
            name="rxnorm_id",
            data_type=DataType.MEDICAL_RECORD,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b\d{5,7}\b"
            ),
            confidence_base=0.15,  # Very low - requires rxnorm/rxcui context
            context_patterns=[
                r"rxnorm",
                r"rxcui",
                r"drug\s*id",
                r"medication\s*id",
            ],
        ),

        # =====================================================================
        # Provider Identifiers
        # =====================================================================

        # National Provider Identifier (NPI)
        Pattern(
            name="npi",
            data_type=DataType.MEDICAL_RECORD,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b[12]\d{9}\b"  # 10 digits starting with 1 or 2
            ),
            validator=validate_npi,
            confidence_base=0.70,
            context_patterns=[
                r"npi",
                r"national\s*provider",
                r"provider\s*(?:id|identifier|number)",
                r"rendering",
                r"billing\s*provider",
            ],
        ),

        # DEA Number
        Pattern(
            name="dea_number",
            data_type=DataType.MEDICAL_RECORD,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b[ABCDEFGHJKLMPRSTUX][A-Z9]\d{7}\b"
            ),
            validator=validate_dea_number,
            confidence_base=0.80,
            context_patterns=[
                r"dea",
                r"prescriber",
                r"controlled\s*substance",
                r"schedule\s*[ii]+",
                r"narcotic",
            ],
        ),

        # State License Number
        Pattern(
            name="medical_license",
            data_type=DataType.MEDICAL_RECORD,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b(?:MD|DO|NP|PA|RN|LPN)\s*[:#]?\s*[A-Z]?\d{5,10}\b",
                re.IGNORECASE,
            ),
            confidence_base=0.55,
            context_patterns=[
                r"licen[sc]e",
                r"medical\s*board",
                r"state\s*registration",
                r"practitioner",
            ],
        ),

        # =====================================================================
        # Medical Device Identifiers
        # =====================================================================

        # Unique Device Identifier (UDI)
        Pattern(
            name="udi",
            data_type=DataType.MEDICAL_RECORD,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b\(01\)\d{14}(?:\(10\)[A-Z0-9]+)?(?:\(17\)\d{6})?\b"
            ),
            confidence_base=0.80,
            context_patterns=[
                r"udi",
                r"device\s*identifier",
                r"implant",
                r"medical\s*device",
            ],
        ),

        # Serial Number (medical device)
        Pattern(
            name="device_serial",
            data_type=DataType.MEDICAL_RECORD,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b(?:SN|Serial)\s*[:#]?\s*[A-Z0-9]{6,20}\b",
                re.IGNORECASE,
            ),
            confidence_base=0.45,
            context_patterns=[
                r"serial",
                r"device",
                r"implant",
                r"equipment",
                r"pump",
                r"pacemaker",
            ],
        ),

        # =====================================================================
        # Lab and Clinical Data Patterns
        # =====================================================================

        # Lab Test Result with Value
        Pattern(
            name="lab_result",
            data_type=DataType.MEDICAL_RECORD,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b(?:glucose|creatinine|hba1c|cholesterol|ldl|hdl|triglycerides|"
                r"hemoglobin|hematocrit|wbc|rbc|platelet|bun|sodium|potassium|"
                r"chloride|co2|calcium|albumin|bilirubin|alt|ast|gfr|egfr|psa|tsh|"
                r"t3|t4|inr|pt|ptt|d-dimer|bnp|troponin)\s*[:]?\s*"
                r"[\d.]+\s*(?:mg/dl|mmol/l|g/dl|%|u/l|ng/ml|pg/ml|miu/ml|iu/l|"
                r"meq/l|cells/mcl|x10\^9/l|x10\^3/ul)?\b",
                re.IGNORECASE,
            ),
            confidence_base=0.75,
            context_patterns=[
                r"lab",
                r"result",
                r"test",
                r"specimen",
                r"blood",
                r"urine",
            ],
        ),

        # Vital Signs Pattern
        Pattern(
            name="vital_signs",
            data_type=DataType.MEDICAL_RECORD,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b(?:BP|blood\s*pressure)\s*[:]?\s*\d{2,3}/\d{2,3}\s*(?:mmhg)?\b|"
                r"\b(?:HR|pulse|heart\s*rate)\s*[:]?\s*\d{2,3}\s*(?:bpm)?\b|"
                r"\b(?:temp|temperature)\s*[:]?\s*\d{2,3}(?:\.\d)?\s*[°]?[cf]\b|"
                r"\b(?:RR|resp|respiratory\s*rate)\s*[:]?\s*\d{1,2}\s*(?:/min)?\b|"
                r"\b(?:spo2|o2\s*sat|oxygen\s*saturation)\s*[:]?\s*\d{2,3}\s*%?\b",
                re.IGNORECASE,
            ),
            confidence_base=0.70,
            context_patterns=[
                r"vital",
                r"patient",
                r"exam",
                r"clinical",
                r"nursing",
            ],
        ),

        # LOINC Codes (Logical Observation Identifiers Names and Codes)
        Pattern(
            name="loinc_code",
            data_type=DataType.DIAGNOSIS_CODE,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b\d{4,5}-\d\b"
            ),
            confidence_base=0.60,
            context_patterns=[
                r"loinc",
                r"lab\s*code",
                r"observation",
                r"test\s*code",
            ],
        ),

        # SNOMED CT Codes
        # Require SNOMED context - too generic otherwise
        # Real SNOMED IDs are typically 6-18 digits
        Pattern(
            name="snomed_code",
            data_type=DataType.DIAGNOSIS_CODE,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b\d{6,18}\b"
            ),
            confidence_base=0.15,  # Very low - absolutely requires context
            context_patterns=[
                r"snomed",
                r"sct\b",
                r"clinical\s*term",
                r"concept\s*id",
            ],
        ),

        # =====================================================================
        # Clinical Text Patterns (high-sensitivity keywords)
        # =====================================================================

        # Diagnosis/Condition mentions
        Pattern(
            name="diagnosis_mention",
            data_type=DataType.DIAGNOSIS_CODE,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b(?:diagnosed\s*with|dx\s*of|diagnosis\s*[:]|"
                r"impression\s*[:]|assessment\s*[:])\s*[\w\s,]{1,200}\b",
                re.IGNORECASE,
            ),
            confidence_base=0.65,
            context_patterns=[
                r"patient",
                r"history",
                r"clinical",
            ],
        ),

        # Allergy Information
        Pattern(
            name="allergy_info",
            data_type=DataType.MEDICAL_RECORD,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b(?:allergies?\s*[:]|allergic\s*to|"
                r"allergy\s*(?:to|list)|nkda|nka)\s*[\w\s,/]{1,200}\b",
                re.IGNORECASE,
            ),
            confidence_base=0.70,
            context_patterns=[
                r"allergy",
                r"adverse",
                r"reaction",
                r"medication",
            ],
        ),

        # Medication/Prescription Pattern
        Pattern(
            name="medication_pattern",
            data_type=DataType.MEDICAL_RECORD,
            category=DataCategory.PHI,
            regex=re.compile(
                r"\b[\w]+\s+\d+\s*(?:mg|mcg|ml|g|units?)\s*"
                r"(?:po|iv|im|sq|pr|sl|top)?\s*"
                r"(?:qd|bid|tid|qid|prn|qhs|qam|qpm|q\d+h?)?\b",
                re.IGNORECASE,
            ),
            confidence_base=0.60,
            context_patterns=[
                r"medication",
                r"rx",
                r"prescription",
                r"take",
                r"dispense",
            ],
        ),
    ]
