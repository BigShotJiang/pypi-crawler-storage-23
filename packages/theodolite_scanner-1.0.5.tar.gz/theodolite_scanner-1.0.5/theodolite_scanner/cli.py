"""CLI entry point for the Theodolite data discovery scanner."""

from __future__ import annotations

import json
import logging
import sys

import click

from theodolite_scanner import __version__


def _interactive_setup() -> dict:
    """Walk the user through setting up a scan interactively."""
    click.echo()
    click.echo("=" * 60)
    click.echo("  Theodolite Scanner — Interactive Setup")
    click.echo("=" * 60)
    click.echo()

    # Provider
    click.echo("Supported providers:")
    click.echo("  1) Azure Blob Storage")
    click.echo("  2) AWS S3")
    click.echo("  3) Google Cloud Storage")
    click.echo()
    provider_choice = click.prompt("Choose provider", type=click.IntRange(1, 3), default=1)
    provider_map = {1: "azure", 2: "aws", 3: "gcp"}
    provider = provider_map[provider_choice]
    click.echo(f"  Using: {provider.upper()}")
    click.echo()

    # Mode
    click.echo("Scan modes:")
    click.echo("  1) Auto-discover — find all buckets/containers automatically")
    click.echo("  2) Single bucket/container — scan one specific target")
    click.echo()
    mode = click.prompt("Choose mode", type=click.IntRange(1, 2), default=1)
    click.echo()

    config: dict = {"provider": provider}

    if provider == "azure":
        if mode == 1:
            config["mode"] = "discover"
            click.echo("Azure credentials (from App Registration):")
            config["tenant_id"] = click.prompt("  Tenant ID (Directory ID)")
            config["client_id"] = click.prompt("  Client ID (Application ID)")
            config["client_secret"] = click.prompt("  Client Secret", hide_input=True)
            click.echo()
            sub = click.prompt(
                "  Subscription ID (leave blank to scan all)",
                default="",
                show_default=False,
            )
            config["subscription_id"] = sub if sub else None
        else:
            config["mode"] = "explicit"
            config["account_url"] = click.prompt(
                "  Storage account URL",
                default="https://myaccount.blob.core.windows.net",
            )
            config["container"] = click.prompt("  Container name")

    elif provider == "aws":
        if mode == 1:
            config["mode"] = "discover"
        else:
            config["mode"] = "explicit"
            config["bucket"] = click.prompt("  S3 bucket name")
            prefix = click.prompt("  Key prefix (leave blank for all)", default="", show_default=False)
            config["prefix"] = prefix if prefix else None

        click.echo()
        click.echo("AWS credentials (leave blank to use default credential chain):")
        ak = click.prompt("  Access Key ID", default="", show_default=False)
        sk = click.prompt("  Secret Access Key", default="", show_default=False, hide_input=True)
        config["access_key_id"] = ak if ak else None
        config["secret_access_key"] = sk if sk else None
        region = click.prompt("  Region", default="us-east-1")
        config["region"] = region

    elif provider == "gcp":
        if mode == 1:
            config["mode"] = "discover"
        else:
            config["mode"] = "explicit"
            config["bucket"] = click.prompt("  GCS bucket name")
            prefix = click.prompt("  Object prefix (leave blank for all)", default="", show_default=False)
            config["prefix"] = prefix if prefix else None

        click.echo()
        project = click.prompt("  GCP project ID (leave blank to auto-detect)", default="", show_default=False)
        config["project"] = project if project else None
        creds = click.prompt(
            "  Service account JSON file (leave blank for default credentials)",
            default="",
            show_default=False,
        )
        config["credentials_file"] = creds if creds else None

    click.echo()

    # Scan type
    click.echo("Scan types:")
    click.echo("  full  — scan all files (100%)")
    click.echo("  quick — sample 5% of files")
    click.echo()
    config["scan_type"] = click.prompt(
        "Scan type", type=click.Choice(["full", "quick"]), default="full"
    )
    click.echo()

    # Categories
    click.echo("Categories: pii, phi, financial, credentials")
    cats = click.prompt(
        "Filter categories (comma-separated, or 'all')", default="all"
    )
    config["categories"] = None if cats == "all" else cats
    click.echo()

    # Output
    config["output"] = click.prompt("Output file", default="findings.json")
    click.echo()

    # Upload
    if click.confirm("Upload results to Theodolite API?", default=False):
        config["upload"] = click.prompt(
            "  API URL", default="https://api.theodolite.io"
        )
        config["token"] = click.prompt("  API token", hide_input=True)
    else:
        config["upload"] = None
        config["token"] = None

    click.echo()
    return config


@click.command()
@click.option("--provider", "-p", type=click.Choice(["azure", "aws", "gcp"]), default=None, help="Cloud provider to scan")
@click.option("--container", "-c", default=None, help="Azure container name (explicit mode)")
@click.option("--bucket", "-b", default=None, help="S3/GCS bucket name (explicit mode)")
@click.option("--prefix", default=None, help="Key/object prefix filter (AWS/GCP)")
@click.option("--account-url", default=None, help="Azure storage account URL (explicit mode)")
# Azure credentials
@click.option("--client-id", default=None, help="Azure App Registration client ID")
@click.option("--tenant-id", default=None, help="Azure tenant/directory ID")
@click.option("--client-secret", default=None, help="Azure client secret")
@click.option("--subscription-id", default=None, help="Azure subscription ID (optional)")
# AWS credentials
@click.option("--access-key-id", default=None, help="AWS access key ID")
@click.option("--secret-access-key", default=None, help="AWS secret access key")
@click.option("--region", default="us-east-1", help="AWS region (default: us-east-1)")
@click.option("--profile", default=None, help="AWS profile name")
# GCP credentials
@click.option("--project", default=None, help="GCP project ID")
@click.option("--credentials-file", default=None, help="GCP service account JSON file path")
# Common options
@click.option("--output", "-o", default=None, help="Output file path for findings JSON")
@click.option("--upload", "-u", default=None, help="Theodolite API URL to upload results to")
@click.option("--token", "-t", default=None, help="Bearer token for API authentication")
@click.option("--scan-type", default="full", type=click.Choice(["quick", "full", "random"]), help="Scan type")
@click.option("--sample-percentage", default=5, type=click.IntRange(1, 100), help="Sample %% for random scan type")
@click.option("--categories", default=None, help="Comma-separated categories (pii,phi,financial,credentials)")
@click.option("--max-file-size", default=100, type=int, help="Max file size in MB (default: 100)")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose logging")
@click.option("--interactive", "-i", is_flag=True, help="Interactive setup wizard")
@click.version_option(__version__)
def main(
    provider: str | None,
    container: str | None,
    bucket: str | None,
    prefix: str | None,
    account_url: str | None,
    client_id: str | None,
    tenant_id: str | None,
    client_secret: str | None,
    subscription_id: str | None,
    access_key_id: str | None,
    secret_access_key: str | None,
    region: str,
    profile: str | None,
    project: str | None,
    credentials_file: str | None,
    output: str | None,
    upload: str | None,
    token: str | None,
    scan_type: str,
    sample_percentage: int,
    categories: str | None,
    max_file_size: int,
    verbose: bool,
    interactive: bool,
) -> None:
    """Theodolite Scanner — scan cloud storage for sensitive data."""

    # If no provider given and no args, enter interactive mode
    if provider is None and not interactive:
        if client_id is None and container is None and bucket is None and access_key_id is None and credentials_file is None:
            interactive = True

    if interactive:
        config = _interactive_setup()
        provider = config["provider"]
        scan_type = config["scan_type"]
        output = config.get("output", output)
        upload = config.get("upload")
        token = config.get("token")
        categories = config.get("categories")

        if provider == "azure":
            if config["mode"] == "discover":
                client_id = config["client_id"]
                tenant_id = config["tenant_id"]
                client_secret = config["client_secret"]
                subscription_id = config.get("subscription_id")
            else:
                account_url = config["account_url"]
                container = config["container"]
        elif provider == "aws":
            access_key_id = config.get("access_key_id")
            secret_access_key = config.get("secret_access_key")
            region = config.get("region", "us-east-1")
            if config["mode"] == "explicit":
                bucket = config["bucket"]
                prefix = config.get("prefix")
        elif provider == "gcp":
            project = config.get("project")
            credentials_file = config.get("credentials_file")
            if config["mode"] == "explicit":
                bucket = config["bucket"]
                prefix = config.get("prefix")

    # Default provider
    if provider is None:
        provider = "azure"

    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(levelname)s %(name)s: %(message)s",
    )

    # Silence noisy SDK HTTP logs unless --verbose
    if not verbose:
        for noisy in (
            "azure", "azure.core", "azure.identity", "azure.storage",
            "azure.mgmt", "urllib3", "msal",
            "botocore", "boto3", "s3transfer",
            "google", "google.auth", "google.cloud",
        ):
            logging.getLogger(noisy).setLevel(logging.WARNING)

    category_list = [c.strip() for c in categories.split(",")] if categories else None

    # Progress callback
    def on_progress(scanned: int, total: int, name: str) -> None:
        pct = int(scanned / total * 100) if total > 0 else 0
        click.echo(f"\r  [{pct:3d}%] {scanned}/{total} — {name[:60]}", nl=False)

    # ── Dispatch by provider ──────────────────────────────────────────

    source = ""
    findings = []
    total_discovered = 0
    assets_scanned = 0

    if provider == "azure":
        findings, total_discovered, assets_scanned, source = _run_azure(
            client_id=client_id, tenant_id=tenant_id, client_secret=client_secret,
            subscription_id=subscription_id, account_url=account_url,
            container=container, scan_type=scan_type,
            sample_percentage=sample_percentage, category_list=category_list,
            max_file_size=max_file_size, on_progress=on_progress,
        )
    elif provider == "aws":
        findings, total_discovered, assets_scanned, source = _run_aws(
            access_key_id=access_key_id, secret_access_key=secret_access_key,
            region=region, profile=profile, bucket=bucket, prefix=prefix,
            scan_type=scan_type, sample_percentage=sample_percentage,
            category_list=category_list, max_file_size=max_file_size,
            on_progress=on_progress,
        )
    elif provider == "gcp":
        findings, total_discovered, assets_scanned, source = _run_gcp(
            project=project, credentials_file=credentials_file,
            bucket=bucket, prefix=prefix, scan_type=scan_type,
            sample_percentage=sample_percentage, category_list=category_list,
            max_file_size=max_file_size, on_progress=on_progress,
        )

    # ── Build results ─────────────────────────────────────────────────

    from theodolite_scanner.output import build_results_json, write_results_file

    results_dict = build_results_json(
        provider=provider,
        source=source,
        findings=findings,
        total_assets_discovered=total_discovered,
        assets_scanned=assets_scanned,
        scan_type=scan_type,
    )

    # Summary
    click.echo()
    click.echo(f"Scan complete:")
    click.echo(f"  Assets discovered: {total_discovered}")
    click.echo(f"  Assets scanned:    {assets_scanned}")
    click.echo(f"  Findings:          {len(findings)}")
    if findings:
        click.echo(f"  By category:       {results_dict['findings_by_category']}")
        click.echo(f"  By severity:       {results_dict['findings_by_severity']}")
        click.echo(f"  Est. breach cost:  ${results_dict['estimated_breach_cost']:,}")
    click.echo()

    # Save locally
    if output:
        write_results_file(results_dict, output)
        click.echo(f"Results saved to {output}")

    # Upload to API
    if upload:
        if not token:
            click.echo("Error: --token is required when using --upload", err=True)
            sys.exit(1)

        from theodolite_scanner.upload import upload_results

        click.echo(f"Uploading to {upload}...")
        resp = upload_results(results_dict, upload, token)
        click.echo(f"Import successful:")
        click.echo(f"  Scan ID:       {resp.get('scan_id')}")
        click.echo(f"  Connector ID:  {resp.get('connector_id')}")
        click.echo(f"  Total findings: {resp.get('total_findings', 0)}")

    if not output and not upload:
        click.echo(json.dumps(results_dict, indent=2))


# ── Provider dispatch helpers ─────────────────────────────────────────


def _run_azure(
    client_id, tenant_id, client_secret, subscription_id,
    account_url, container, scan_type, sample_percentage,
    category_list, max_file_size, on_progress,
) -> tuple[list, int, int, str]:
    """Run Azure scan (discover or explicit)."""
    is_discover = client_id is not None and tenant_id is not None and client_secret is not None

    if is_discover:
        click.echo(f"Auto-discovering AZURE storage...")
        if subscription_id:
            click.echo(f"  Subscription: {subscription_id}")
        else:
            click.echo(f"  Scanning all accessible subscriptions")
        click.echo(f"  Scan type: {scan_type}")
        if category_list:
            click.echo(f"  Categories: {', '.join(category_list)}")
        click.echo()

        from theodolite_scanner.runner import run_azure_discover_scan

        findings, total_discovered, assets_scanned, containers_found = run_azure_discover_scan(
            client_id=client_id, tenant_id=tenant_id, client_secret=client_secret,
            subscription_id=subscription_id, scan_type=scan_type,
            sample_percentage=sample_percentage, categories=category_list,
            max_file_size_mb=max_file_size, on_progress=on_progress,
        )

        click.echo()
        accounts = sorted(set(c["storage_account"] for c in containers_found))
        source = ", ".join(f"https://{a}.blob.core.windows.net" for a in accounts)

        click.echo()
        click.echo(f"Containers discovered: {len(containers_found)}")
        for c in containers_found:
            click.echo(f"  • {c['storage_account']}/{c['container_name']}")

        return findings, total_discovered, assets_scanned, source
    else:
        if not container or not account_url:
            click.echo(
                "Error: for Azure, provide --client-id/--tenant-id/--client-secret for auto-discover,\n"
                "       or --container and --account-url for single container scan,\n"
                "       or use --interactive for the setup wizard.",
                err=True,
            )
            sys.exit(1)

        click.echo(f"Scanning AZURE container: {container}")
        click.echo(f"  Account:   {account_url}")
        click.echo(f"  Scan type: {scan_type}")
        if category_list:
            click.echo(f"  Categories: {', '.join(category_list)}")
        click.echo()

        from theodolite_scanner.runner import run_azure_scan

        findings, total_discovered, assets_scanned = run_azure_scan(
            account_url=account_url, container=container, scan_type=scan_type,
            sample_percentage=sample_percentage, categories=category_list,
            max_file_size_mb=max_file_size, on_progress=on_progress,
        )
        click.echo()
        return findings, total_discovered, assets_scanned, f"{account_url}/{container}"


def _run_aws(
    access_key_id, secret_access_key, region, profile,
    bucket, prefix, scan_type, sample_percentage,
    category_list, max_file_size, on_progress,
) -> tuple[list, int, int, str]:
    """Run AWS scan (discover or explicit)."""
    is_discover = bucket is None

    if is_discover:
        click.echo(f"Auto-discovering AWS S3 buckets...")
        click.echo(f"  Region: {region}")
        click.echo(f"  Scan type: {scan_type}")
        if category_list:
            click.echo(f"  Categories: {', '.join(category_list)}")
        click.echo()

        from theodolite_scanner.runner import run_aws_discover_scan

        findings, total_discovered, assets_scanned, buckets_found = run_aws_discover_scan(
            access_key_id=access_key_id, secret_access_key=secret_access_key,
            region=region, profile=profile, prefix=prefix, scan_type=scan_type,
            sample_percentage=sample_percentage, categories=category_list,
            max_file_size_mb=max_file_size, on_progress=on_progress,
        )

        click.echo()
        names = [b["bucket_name"] for b in buckets_found]
        source = ", ".join(f"s3://{n}" for n in names)

        click.echo()
        click.echo(f"Buckets discovered: {len(buckets_found)}")
        for b in buckets_found:
            click.echo(f"  • s3://{b['bucket_name']}")

        return findings, total_discovered, assets_scanned, source
    else:
        click.echo(f"Scanning AWS S3 bucket: {bucket}")
        click.echo(f"  Region:    {region}")
        if prefix:
            click.echo(f"  Prefix:    {prefix}")
        click.echo(f"  Scan type: {scan_type}")
        if category_list:
            click.echo(f"  Categories: {', '.join(category_list)}")
        click.echo()

        from theodolite_scanner.runner import run_aws_scan

        findings, total_discovered, assets_scanned = run_aws_scan(
            bucket=bucket, region=region, access_key_id=access_key_id,
            secret_access_key=secret_access_key, profile=profile, prefix=prefix,
            scan_type=scan_type, sample_percentage=sample_percentage,
            categories=category_list, max_file_size_mb=max_file_size,
            on_progress=on_progress,
        )
        click.echo()
        source = f"s3://{bucket}"
        if prefix:
            source += f"/{prefix}"
        return findings, total_discovered, assets_scanned, source


def _run_gcp(
    project, credentials_file, bucket, prefix,
    scan_type, sample_percentage, category_list,
    max_file_size, on_progress,
) -> tuple[list, int, int, str]:
    """Run GCP scan (discover or explicit)."""
    is_discover = bucket is None

    if is_discover:
        click.echo(f"Auto-discovering GCP Cloud Storage buckets...")
        if project:
            click.echo(f"  Project: {project}")
        click.echo(f"  Scan type: {scan_type}")
        if category_list:
            click.echo(f"  Categories: {', '.join(category_list)}")
        click.echo()

        from theodolite_scanner.runner import run_gcp_discover_scan

        findings, total_discovered, assets_scanned, buckets_found = run_gcp_discover_scan(
            project=project, credentials_file=credentials_file, prefix=prefix,
            scan_type=scan_type, sample_percentage=sample_percentage,
            categories=category_list, max_file_size_mb=max_file_size,
            on_progress=on_progress,
        )

        click.echo()
        names = [b["bucket_name"] for b in buckets_found]
        source = ", ".join(f"gs://{n}" for n in names)

        click.echo()
        click.echo(f"Buckets discovered: {len(buckets_found)}")
        for b in buckets_found:
            click.echo(f"  • gs://{b['bucket_name']}")

        return findings, total_discovered, assets_scanned, source
    else:
        click.echo(f"Scanning GCP bucket: {bucket}")
        if project:
            click.echo(f"  Project:   {project}")
        if prefix:
            click.echo(f"  Prefix:    {prefix}")
        click.echo(f"  Scan type: {scan_type}")
        if category_list:
            click.echo(f"  Categories: {', '.join(category_list)}")
        click.echo()

        from theodolite_scanner.runner import run_gcp_scan

        findings, total_discovered, assets_scanned = run_gcp_scan(
            bucket=bucket, project=project, credentials_file=credentials_file,
            prefix=prefix, scan_type=scan_type, sample_percentage=sample_percentage,
            categories=category_list, max_file_size_mb=max_file_size,
            on_progress=on_progress,
        )
        click.echo()
        source = f"gs://{bucket}"
        if prefix:
            source += f"/{prefix}"
        return findings, total_discovered, assets_scanned, source


if __name__ == "__main__":
    main()
