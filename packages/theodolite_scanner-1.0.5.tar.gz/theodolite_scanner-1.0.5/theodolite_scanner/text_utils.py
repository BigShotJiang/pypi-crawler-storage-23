"""Shared text utilities for data discovery.

Provides standardized text processing to ensure consistent results
across all file sources. Extracted from the Theodolite server-side code.
"""

from __future__ import annotations

import logging
import re
from typing import Optional

logger = logging.getLogger(__name__)

# Standardized supported extensions
SUPPORTED_TEXT_EXTENSIONS = frozenset([
    # Plain text
    ".txt", ".text",
    # Data formats
    ".csv", ".tsv", ".psv", ".json", ".jsonl", ".ndjson",
    ".xml", ".yaml", ".yml",
    # Markup
    ".md", ".markdown", ".rst", ".html", ".htm", ".xhtml",
    # Configuration
    ".env", ".ini", ".cfg", ".conf", ".config", ".properties",
    # Logs
    ".log", ".logs",
    # Code (may contain secrets/credentials)
    ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".cs", ".go",
    ".rb", ".php", ".pl", ".sh", ".bash", ".zsh", ".ps1",
    ".c", ".cpp", ".h", ".hpp", ".rs", ".swift", ".kt",
    # Web
    ".css", ".scss", ".sass", ".less",
    # Database
    ".sql", ".ddl", ".dml",
    # Other
    ".rtf", ".tex",
])

# Binary order mark bytes
UTF8_BOM = b'\xef\xbb\xbf'
UTF16_LE_BOM = b'\xff\xfe'
UTF16_BE_BOM = b'\xfe\xff'
UTF32_LE_BOM = b'\xff\xfe\x00\x00'
UTF32_BE_BOM = b'\x00\x00\xfe\xff'

# Encoding detection order
ENCODING_PRIORITY = [
    "utf-8",
    "utf-8-sig",
    "utf-16",
    "utf-16-le",
    "utf-16-be",
    "ascii",
    "latin-1",
    "cp1252",
    "iso-8859-15",
]


def get_supported_extensions() -> frozenset[str]:
    """Get the standardized set of supported text file extensions."""
    return SUPPORTED_TEXT_EXTENSIONS


def is_supported_extension(filename: str) -> bool:
    """Check if a filename has a supported extension."""
    if "." not in filename:
        return False
    ext = "." + filename.rsplit(".", 1)[-1].lower()
    return ext in SUPPORTED_TEXT_EXTENSIONS


def detect_encoding_from_bom(data: bytes) -> Optional[str]:
    """Detect encoding from Byte Order Mark."""
    if data.startswith(UTF32_LE_BOM):
        return "utf-32-le"
    if data.startswith(UTF32_BE_BOM):
        return "utf-32-be"
    if data.startswith(UTF8_BOM):
        return "utf-8-sig"
    if data.startswith(UTF16_LE_BOM):
        return "utf-16-le"
    if data.startswith(UTF16_BE_BOM):
        return "utf-16-be"
    return None


def decode_binary_content(
    data: bytes,
    detected_encoding: Optional[str] = None,
) -> tuple[str, str]:
    """Decode binary content to text with encoding detection."""
    if not data:
        return "", "utf-8"

    bom_encoding = detect_encoding_from_bom(data)

    encodings_to_try = []
    if bom_encoding:
        encodings_to_try.append(bom_encoding)
    if detected_encoding and detected_encoding not in encodings_to_try:
        encodings_to_try.append(detected_encoding)
    for enc in ENCODING_PRIORITY:
        if enc not in encodings_to_try:
            encodings_to_try.append(enc)

    last_error = None
    for encoding in encodings_to_try:
        try:
            text = data.decode(encoding)
            return text, encoding
        except (UnicodeDecodeError, LookupError) as e:
            last_error = e
            continue

    raise UnicodeDecodeError(
        "all-encodings",
        data[:100],
        0,
        min(100, len(data)),
        f"Failed to decode with any of: {encodings_to_try}"
    )


def normalize_text(text: str) -> str:
    """Normalize text content for consistent pattern matching."""
    if not text:
        return ""

    text = text.lstrip('\ufeff')
    text = text.lstrip('\ufffe')
    text = text.replace('\x00', '')
    text = text.replace('\r\n', '\n')
    text = text.replace('\r', '\n')

    lines = text.split('\n')
    lines = [line.rstrip() for line in lines]
    text = '\n'.join(lines)

    return text


def extract_text_from_binary(
    data: bytes,
    encoding_hint: Optional[str] = None,
) -> tuple[str, str, str]:
    """Extract and normalize text from binary content."""
    if not data:
        return "", "utf-8", "utf-8"

    bom_encoding = detect_encoding_from_bom(data)
    try:
        text, encoding_used = decode_binary_content(data, encoding_hint)
    except UnicodeDecodeError:
        text = data.decode('utf-8', errors='replace')
        encoding_used = 'utf-8 (with replacements)'

    normalized = normalize_text(text)
    original_encoding = bom_encoding or encoding_hint or encoding_used

    return normalized, encoding_used, original_encoding


def truncate_for_scanning(text: str, max_chars: int = 10_000_000) -> str:
    """Truncate text to a maximum size for scanning."""
    if len(text) <= max_chars:
        return text

    truncated = text[:max_chars]
    last_newline = truncated.rfind('\n')

    if last_newline > max_chars * 0.9:
        truncated = truncated[:last_newline]

    logger.warning(f"Truncated text from {len(text)} to {len(truncated)} characters")
    return truncated
