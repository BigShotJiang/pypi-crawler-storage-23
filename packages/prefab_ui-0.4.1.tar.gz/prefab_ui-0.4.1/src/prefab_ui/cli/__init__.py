"""Prefab CLI package."""

from prefab_ui.cli.cli import app

__all__ = ["app"]
