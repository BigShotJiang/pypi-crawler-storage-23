"""visualcheck package

On import we try to load a repo-level .env (if present) so python-decouple
and other config readers pick up project-specific environment variables
when visualcheck is used programmatically (e.g., from examples/python_*).
"""
from pathlib import Path

__all__ = ["__version__"]

# Try to load a local .env adjacent to the package root. We do this here so a
# simple `import visualcheck` will make project-level .env values visible to
# python-decouple's config() calls. This is best-effort and never raises.
try:
    from dotenv import load_dotenv

    # package root: src/visualcheck/.. -> project root
    pkg_root = Path(__file__).resolve().parent.parent
    env_path = pkg_root / ".env"
    if env_path.exists():
        load_dotenv(str(env_path))
    else:
        # fallback to default loader which searches CWD and parent dirs
        load_dotenv()
except Exception:
    # avoid breaking import if dotenv not installed
    pass

__version__ = "0.3.24"
