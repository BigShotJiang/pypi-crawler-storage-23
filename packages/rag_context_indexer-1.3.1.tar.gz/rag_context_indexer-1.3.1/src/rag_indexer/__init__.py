"""
@RAG_CONTEXT
{
  "archivo": "src/rag_indexer/__init__.py",
  "lineas": 0,
  "tokens_estimados": 0,
  "hash_contenido": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
  "creacion": "2026-03-04",
  "modificacion": "2026-03-04",
  "tags": [],
  "descripcion_corta": "",
  "descripcion_larga": ""
}
"""
