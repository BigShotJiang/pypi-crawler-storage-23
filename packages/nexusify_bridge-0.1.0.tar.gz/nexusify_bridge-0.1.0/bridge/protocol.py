"""
Shared protocol constants for the Local MCP Bridge relay.

Mirrors ``openai_agents.bridge_protocol`` on the backend so both sides
use the same message types and envelope helpers.
"""

from __future__ import annotations

import uuid
from typing import Any, Optional


# ---------------------------------------------------------------------------
# Message types: Bridge -> Relay
# ---------------------------------------------------------------------------
MSG_AUTH = "auth"
MSG_REGISTER_SERVERS = "register_servers"
MSG_MCP_RESPONSE = "mcp_response"
MSG_HEARTBEAT = "heartbeat"

# ---------------------------------------------------------------------------
# Message types: Relay -> Bridge
# ---------------------------------------------------------------------------
MSG_AUTH_OK = "auth_ok"
MSG_AUTH_ERROR = "auth_error"
MSG_MCP_REQUEST = "mcp_request"
MSG_HEARTBEAT_ACK = "heartbeat_ack"
MSG_ERROR = "error"

# ---------------------------------------------------------------------------
# Timing
# ---------------------------------------------------------------------------
HEARTBEAT_INTERVAL_SEC = 30


# ---------------------------------------------------------------------------
# Envelope helpers
# ---------------------------------------------------------------------------

def build_auth_message(token: str) -> dict:
    return {"type": MSG_AUTH, "token": token}


def build_register_servers_message(servers: list[dict]) -> dict:
    return {"type": MSG_REGISTER_SERVERS, "servers": servers}


def build_mcp_response_message(
    request_id: str,
    server_name: str,
    payload: dict,
) -> dict:
    return {
        "type": MSG_MCP_RESPONSE,
        "request_id": request_id,
        "server_name": server_name,
        "payload": payload,
    }


def build_heartbeat_message() -> dict:
    return {"type": MSG_HEARTBEAT}
