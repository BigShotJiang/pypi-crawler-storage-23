Nexus Bridge
============

Local MCP Bridge daemon that connects MCP servers running on your machine to the Nexus production relay.

Install
-------

.. code-block:: bash

   pip install nexusify-bridge

Quick start
-----------

1. Initialize config:

.. code-block:: bash

   nexus-bridge init

2. Open the generated config and enable your local MCP servers.

3. Start the bridge:

.. code-block:: bash

   nexus-bridge start --token <TOKEN>

You can override the relay URL if needed:

.. code-block:: bash

   nexus-bridge start --token <TOKEN> --relay-url wss://nexusify.ai/ws/bridge/

Bridge token lifecycle
----------------------

- Bridge tokens are **lifetime tokens** with explicit server-side revocation.
- Only one token can be active per user at a time.
- Generating a new token rotates and invalidates the previous token.
- If a token is exposed, revoke it immediately from the MCP Servers UI, then issue a new one.

Production tuning knobs
-----------------------

The daemon supports environment variables for reliability and throughput hardening:

- ``NEXUS_BRIDGE_RECONNECT_BASE_SEC`` (default: ``1.0``)
- ``NEXUS_BRIDGE_RECONNECT_MAX_SEC`` (default: ``60.0``)
- ``NEXUS_BRIDGE_MAX_INFLIGHT_PER_SERVER`` (default: ``16``)

Example:

.. code-block:: bash

   NEXUS_BRIDGE_MAX_INFLIGHT_PER_SERVER=32 nexus-bridge start --token <TOKEN>
