"""Time-periodic orbit handling."""

from __future__ import annotations

from typing import cast

import matplotlib.pyplot as plt
import numpy as np
import scipy.linalg
import scipy.sparse as sp

from bice.core.equation import Equation
from bice.core.profiling import profile
from bice.core.types import Array, Axes, DataDict, Matrix, RealArray

# TODO: make this work for multiple variables, regarding ref_eq.shape


class TimePeriodicOrbitHandler(Equation):
    """
    Handles equations with implicit time-stepping on a periodic time-mesh.

    The TimePeriodicOrbitHandler is an Equation that has an implicit
    time-stepping on a periodic time-mesh of (unknown) period length T.
    In a Problem, it can be used for solving periodic orbits, e.g. in a
    Hopf continuation. The referenced equation *should not* simultaneously
    be part of the problem.
    """

    # reference equation, initial guess for period length, initial number of points in
    # time
    def __init__(self, reference_equation: Equation, T: float, Nt: int) -> None:
        """
        Initialize the TimePeriodicOrbitHandler.

        Parameters
        ----------
        reference_equation
            The equation to solve the orbit for.
        T
            Initial guess for the period.
        Nt
            Initial number of time steps.
        """
        super().__init__(shape=(Nt * reference_equation.ndofs + 1))
        # which equation to treat?
        self.ref_eq = reference_equation
        # the list of considered timesteps (in normalized time t' = t / T)
        self.dt: RealArray = np.repeat(1.0 / Nt, Nt)
        # the vector of unknowns: unknowns of the reference equation for every timestep
        u1 = np.tile(self.ref_eq.u, Nt)
        # the period is also an unknown, append it to u
        # TODO: a good guess for T is 2pi / Im(lambda), with the unstable eigenvalue
        #       lambda
        self.u = np.append(u1, T)
        # the finite differences matrix to compute the temporal derivative du/dt from
        # given u[t]
        self.ddt = self.build_ddt_matrix()
        # cache for storing the Jacobians J[u, t_i] = d(ref_eq.rhs)/du for each point
        # in time t_i
        self._jacobian_cache: list[Matrix] = []

    @property
    def T(self) -> float:
        """
        Access the period length.

        Returns
        -------
        float
            The period length.
        """
        return float(self.u[-1])

    @T.setter
    def T(self, v: float) -> None:
        """
        Set the period length.

        Parameters
        ----------
        v
            The new period length.
        """
        self.u[-1] = v

    @property
    def t(self) -> RealArray:
        """
        Return the temporal domain vector.

        Returns
        -------
        RealArray
            The accumulated time steps.
        """
        return np.cumsum(self.dt)

    @property
    def Nt(self) -> int:
        """
        Return the number of points in time.

        Returns
        -------
        int
            Number of time steps.
        """
        return len(self.dt)

    def u_orbit(self) -> Array:
        """
        Return the unknowns in separate arrays for each point in time.

        Returns
        -------
        Array
            The reshaped unknowns array of shape (Nt, ...).
        """
        # split the period and reshape to (Nt, *ref_eq.shape)
        return self.u[:-1].reshape((self.Nt, *self.ref_eq.shape))

    def build_ddt_matrix(self) -> sp.csr_matrix:
        """
        Build the time-derivative operator ddt, using periodic finite differences.

        Returns
        -------
        sp.csr_matrix
            The finite difference matrix.
        """
        # time-derivative operator
        # TODO: build using FinDiff or numdifftoos.fornberg
        #       then we can also support non-uniform time-grids
        Nt = self.Nt
        identity = np.eye(Nt)
        dt = self.dt[0]
        ddt = np.zeros((Nt, Nt))
        ddt += -3 * np.roll(identity, -4, axis=1)
        ddt += 32 * np.roll(identity, -3, axis=1)
        ddt += -168 * np.roll(identity, -2, axis=1)
        ddt += 672 * np.roll(identity, -1, axis=1)
        ddt -= 672 * np.roll(identity, 1, axis=1)
        ddt -= -168 * np.roll(identity, 2, axis=1)
        ddt -= 32 * np.roll(identity, 3, axis=1)
        ddt -= -3 * np.roll(identity, 4, axis=1)
        # TODO: the minus should not be here!
        ddt /= -dt * 840
        # convert to sparse
        return sp.csr_matrix(ddt)

    @profile
    def rhs(self, u: Array) -> Array:
        """
        Calculate the rhs of the full system of equations.

        Parameters
        ----------
        u
            The vector of unknowns (including period T).

        Returns
        -------
        Array
            The residuals.
        """
        # number of unknowns of a single equation
        N = self.ref_eq.ndofs
        # split the unknowns into:
        # ... period length
        T = u[-1]
        # ... u's per timestep
        u = u[:-1].reshape((self.Nt, *self.ref_eq.shape))
        # calculate the time derivative using FD
        dudt = self.ddt.dot(u) / T
        # same for the old variables
        T_old = self.u[-1]
        u_old = self.u[:-1].reshape((self.Nt, *self.ref_eq.shape))
        dudt_old = self.ddt.dot(u_old) / T_old
        # mass matrix
        M = self.ref_eq.mass_matrix()
        # setup empty result vector
        res = np.zeros(self.ndofs)
        # add the rhs contributions for each timestep
        for i in range(self.Nt):
            # 0 = rhs(u) - dudt for each u(t_i)
            # TODO: .ravel() will be required somewhere here
            res[i * N : (i + 1) * N] = self.ref_eq.rhs(u[i]) - M.dot(dudt[i])
            # phase condition: \int_0^1 dt <u, dudt_old> = 0
            # TODO: use a better approximation for dt in integral?
            res[-1] += np.dot(u[i], dudt_old[i]) * self.dt[i]
        # return the result
        return res

    @profile
    def jacobian(self, u: Array) -> sp.csr_matrix:
        """
        Calculate the Jacobian of rhs(u).

        Parameters
        ----------
        u
            The vector of unknowns.

        Returns
        -------
        sp.csr_matrix
            The Jacobian matrix.
        """
        # split the unknowns into:
        # ... period length
        T = u[-1]
        # ... u's per timestep
        u = u[:-1].reshape((self.Nt, *self.ref_eq.shape))
        # calculate the time derivative
        dudt = self.ddt.dot(u) / T
        # same for the old variables
        T_old = self.u[-1]
        u_old = self.u[:-1].reshape((self.Nt, *self.ref_eq.shape))
        dudt_old = self.ddt.dot(u_old) / T_old
        # mass matrix
        M = self.ref_eq.mass_matrix()
        # Jacobian of reference equation for each time step
        # also, cache the Jacobians for later Floquet multiplier computation
        self._jacobian_cache = [sp.csr_matrix(self.ref_eq.jacobian(u[i])) for i in range(self.Nt)]
        # The different contributions to the jacobian: ((#1, #2), (#3, #4))
        # 1.: bulk equations du: d ( rhs(u) - M*dudt ) / du
        # jacobian of M.dot(dudt) w.r.t. u
        d_bulk_du = sp.block_diag([self._jacobian_cache[i] for i in range(self.Nt)]) - sp.kron(self.ddt, M) / T
        # 2.: bulk equations dT: d ( rhs(u) - M*dudt ) / dT
        d_bulk_dT = sp.csr_matrix(np.concatenate([M.dot(dudt[i]) / T for i in range(self.Nt)])).T
        # 3.: constraint equation du: d ( \int_0^1 dt <u, dudt_old> = 0 ) / du
        d_cnst_du = sp.csr_matrix(np.concatenate([dudt_old[i] * self.dt[i] for i in range(self.Nt)]))
        # 4.: cnst equation dT: d ( \int_0^1 dt <u, dudt_old> = 0 ) / du = 0
        d_cnst_dT = 0 * sp.csr_matrix((1, 1))
        # combine the contributions to the full jacobian and return
        final_jac = sp.bmat([[d_bulk_du, d_bulk_dT], [d_cnst_du, d_cnst_dT]])
        return sp.csr_matrix(final_jac)

    def monodromy_matrix(self, use_cache: bool = True) -> sp.csr_matrix:
        """
        Calculate the monodromy matrix A.

        Used to calculate the stability of the orbit using the Floquet multipliers
        (eigenvalues of A).

        The matrix is computed as the product of the reference equations's Jacobians
        for each point in time, i.e.:
        A = J[u(t_N), t_N] * J[u(t_{N-1}), t_{N-1}] * ... * J[u(t_0), t_0]

        Parameters
        ----------
        use_cache
            Whether to use cached Jacobians from the last solving step.

        Returns
        -------
        sp.csr_matrix
            The monodromy matrix.
        """
        # store whether there was something cached
        had_cache = len(self._jacobian_cache) > 0
        # check if the number of cached Jacobians matches the number of time steps
        if len(self._jacobian_cache) != self.Nt:
            # if not, we will definitely need to regenerate the Jacobians
            use_cache = False
        # If we are not using the cached Jacobians, regenerate Jacobians by computing
        # the orbit handlers Jacobian (this method updates the cache)
        if not use_cache:
            _ = self.jacobian(self.u)
        # Cache should now be up to date
        # multiply the Jacobians in reversed order
        jacs = self._jacobian_cache[::-1]
        mon_mat = jacs[0]
        for i in range(1, self.Nt):
            mon_mat = mon_mat.dot(jacs[i])
        # If there was no cache, it is likely that we are using some matrix free method
        # (e.g. Krylov subspace methods) for Jacobian estimation that does not
        # generate a cache. If so, invalidate the cache:
        if not had_cache:
            self._jacobian_cache = []
        # return the monodromy matrix
        return mon_mat

    def floquet_multipliers(self, k: int = 20, use_cache: bool = True) -> RealArray:
        """
        Calculate the Floquet multipliers to obtain the stability of the orbit.

        The Floquet multipliers are the eigenvalues of the monodromy matrix.

        Parameters
        ----------
        k
            Number of desired Floquet multipliers to be calculated by the iterative
            eigensolver.
        use_cache
            Whether to use cached Jacobians.

        Returns
        -------
        RealArray
            The Floquet multipliers (eigenvalues).
        """
        # obtain the monodromy matrix and mass matrix
        A = self.monodromy_matrix(use_cache)
        M = self.ref_eq.mass_matrix()
        # number of degrees of freedom of the original equation (--> matrices are NxN)
        N = self.ref_eq.ndofs
        # make sure we do not request more Floquet multipliers than degrees of freedom
        k = min(k, N)
        # if N is very small, fallback to dense matrices
        if N < 100:
            # make sure both are dense
            if isinstance(A, sp.spmatrix):
                A_dense = A.todense()
            else:
                A_dense = A
            if isinstance(M, sp.spmatrix):
                M_dense = M.todense()
            else:
                M_dense = M
            # calculate eigenvalues and return
            eigval, _ = scipy.linalg.eig(A_dense, M_dense)
            return cast(RealArray, np.asarray(eigval[:k], dtype=np.float64))
        else:
            # make sure both are sparse
            if not sp.issparse(A):
                A = sp.csr_matrix(A)
            if not sp.issparse(M):
                M = sp.csr_matrix(M)
            # calculate eigenvalues and return
            eigval, _ = sp.linalg.eigs(A, k=k, M=M, sigma=1)
            return cast(RealArray, np.asarray(eigval, dtype=np.float64))

    # TODO: test this
    # TODO: ddt does currently not support non-uniform time, make uniform?
    def adapt(self) -> tuple[float, float]:
        """
        Adapt the time mesh to the solution.

        Returns
        -------
        tuple
            (min_error, max_error) estimates.
        """
        # number of unknowns of a single equation
        N = self.ref_eq.ndofs
        # split the unknowns into:
        # ... period length
        T = self.u[-1]
        # ... u's per timestep
        u = self.u[:-1].reshape((self.Nt, *self.ref_eq.shape))
        # calculate the time derivative
        dudt = self.ddt.dot(u)
        # estimate for the relative error in the time derivative
        # TODO: maybe there is something better than this
        error_estimate = np.array([np.linalg.norm(dudt[i]) / np.linalg.norm(u[i]) for i in range(self.Nt)])
        # define error tolerances
        min_error = 1e-5
        max_error = 1e-3
        min_steps = 10
        max_steps = 1e4
        # (un)refinement loop
        i = 0
        dt = self.dt.copy()
        while i < len(dt):
            e = error_estimate[i]
            # unrefinement
            if e < min_error and len(dt) > min_steps:
                u = np.delete(u, i, axis=0)
                dt = np.delete(dt, i)
                error_estimate = np.delete(error_estimate, i)
                i += 1
            # refinement
            if e > max_error and len(dt) < max_steps:
                i2 = (i + 1) % len(dt)
                u = np.insert(u, i, 0.5 * (u[i] + u[i2]), axis=0)
                dt = np.insert(dt, i, 0.5 * (dt[i] + dt[i2]))
                error_estimate = np.insert(error_estimate, i, 0.5 * (min_error + max_error))
                i += 1
            i += 1
        # build new u
        u = np.append(u.ravel(), [T])
        # update shape of equation
        self.reshape(len(dt) * N + 1)
        # assign new variables and timesteps
        self.u = u
        self.dt = dt
        # if the equation belongs to a group of equations, redo it's mapping of the
        # unknowns
        if self.group is not None:
            self.group.map_unknowns()
        # rebuild FD time-derivative matrix
        self.ddt = self.build_ddt_matrix()
        # invalidate the cached Jacobians
        self._jacobian_cache = []
        # return min/max error estimates
        return (float(min(error_estimate)), float(max(error_estimate)))

    def save(self) -> DataDict:
        """
        Save the state of the equation, including the dt-values.

        Returns
        -------
        dict
            The state dictionary.
        """
        data = super().save()
        data.update({"dt": self.dt})
        return data

    def load(self, data: DataDict) -> None:
        """
        Load the state of the equation, including the dt-values.

        Parameters
        ----------
        data
            The state dictionary.
        """
        self.dt = data["dt"]
        # rebuild FD time-derivative matrix
        self.ddt = self.build_ddt_matrix()
        # invalidate the cached Jacobians
        self._jacobian_cache = []

        super().load(data)

    def plot(self, ax: Axes) -> None:
        """
        Plot the solutions for different timesteps.

        Parameters
        ----------
        ax
            The matplotlib axes.
        """
        orbit = self.u_orbit().T
        num_plots = min(40, self.Nt)
        cmap = plt.get_cmap("viridis")
        ax.set_prop_cycle(plt.cycler("color", cmap(np.linspace(0, 1, num_plots))))
        for i in range(0, self.Nt, self.Nt // num_plots):
            self.ref_eq.u = orbit.T[i]
            self.ref_eq.plot(ax)
