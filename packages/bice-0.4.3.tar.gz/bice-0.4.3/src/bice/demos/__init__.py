"""bice demos."""
