Core libraries that are shared across all imbue projects.
