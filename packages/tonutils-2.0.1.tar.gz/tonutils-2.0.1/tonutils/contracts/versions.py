from enum import Enum


class ContractVersion(str, Enum):
    """Standard TON smart contract version identifier."""

    WalletV1R1 = "wallet_v1r1"
    WalletV1R2 = "wallet_v1r2"
    WalletV1R3 = "wallet_v1r3"
    WalletV2R1 = "wallet_v2r1"
    WalletV2R2 = "wallet_v2r2"
    WalletV3R1 = "wallet_v3r1"
    WalletV3R2 = "wallet_v3r2"
    WalletV4R1 = "wallet_v4r1"
    WalletV4R2 = "wallet_v4r2"
    WalletV5Beta = "wallet_v5_beta"
    WalletV5R1 = "wallet_v5r1"

    WalletHighloadV2 = "wallet_highloadv_v2"
    WalletHighloadV3R1 = "wallet_highload_v3r1"

    WalletPreprocessedV2 = "wallet_preprocessed_v2"

    NFTCollectionStandard = "nft_collection_standard"
    NFTCollectionEditable = "nft_collection_editable"
    NFTItemStandard = "nft_item_standard"
    NFTItemEditable = "nft_item_editable"
    NFTItemSoulbound = "nft_item_soulbound"

    JettonMasterStandard = "jetton_master_standard"
    JettonMasterStablecoin = "jetton_master_stablecoin"
    JettonMasterStablecoinV2 = "jetton_master_stablecoin_v2"
    JettonWalletStandard = "jetton_wallet_standard"
    JettonWalletStablecoin = "jetton_wallet_stablecoin"
    JettonWalletStablecoinV2 = "jetton_wallet_stablecoin_v2"

    TelegramUsernamesCollection = "telegram_usernames_collection"
    TelegramGiftsCollection = "telegram_gifts_collection"
    TelegramUsernameItem = "telegram_username_item"
    TelegramGiftItem = "telegram_gift_item"

    TONDNSCollection = "ton_dns_collection"
    TONDNSItem = "ton_dns_item"
