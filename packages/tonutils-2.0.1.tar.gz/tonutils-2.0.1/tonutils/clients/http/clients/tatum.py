import typing as t

from aiohttp import ClientSession

from tonutils.clients.http.clients.toncenter import ToncenterClient
from tonutils.exceptions import NetworkNotSupportedError
from tonutils.types import NetworkGlobalID, RetryPolicy


class TatumClient(ToncenterClient):
    """Toncenter-compatible client using Tatum as backend."""

    def __init__(
        self,
        network: NetworkGlobalID,
        *,
        api_key: str,
        base_url: t.Optional[str] = None,
        timeout: float = 10.0,
        session: t.Optional[ClientSession] = None,
        headers: t.Optional[t.Dict[str, str]] = None,
        cookies: t.Optional[t.Dict[str, str]] = None,
        rps_limit: t.Optional[int] = None,
        rps_period: float = 1.0,
        retry_policy: t.Optional[RetryPolicy] = None,
    ) -> None:
        """
        :param network: Target TON network.
        :param api_key: Tatum API key.
            You can get an API key on the Tatum website: https://tatum.io/.
        :param base_url: Custom endpoint base URL, or `None`.
        :param timeout: Request timeout in seconds.
        :param session: External aiohttp session, or `None`.
        :param headers: Default headers for owned session.
        :param cookies: Default cookies for owned session.
        :param rps_limit: Requests-per-period limit, or `None`.
        :param rps_period: Rate limit period in seconds.
        :param retry_policy: Retry policy with per-error-code rules, or `None`.
        """
        urls = {
            NetworkGlobalID.MAINNET: "https://ton-mainnet.gateway.tatum.io",
            NetworkGlobalID.TESTNET: "https://ton-testnet.gateway.tatum.io",
        }
        base_url = base_url or urls.get(network)
        if base_url is None:
            raise NetworkNotSupportedError(network, provider="Tatum")

        super().__init__(
            network=network,
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            session=session,
            headers=headers,
            cookies=cookies,
            rps_limit=rps_limit,
            rps_period=rps_period,
            retry_policy=retry_policy,
        )
