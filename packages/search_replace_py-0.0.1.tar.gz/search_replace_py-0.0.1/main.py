def main():
    print("Hello from search-replace-py!")


if __name__ == "__main__":
    main()
