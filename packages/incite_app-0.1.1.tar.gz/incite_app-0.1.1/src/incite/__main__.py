"""Allow running incite as ``python -m incite``."""

from incite.cli import main

main()
