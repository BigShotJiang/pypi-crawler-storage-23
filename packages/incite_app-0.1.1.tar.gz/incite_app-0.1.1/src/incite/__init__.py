"""inCite: Local-first citation recommendation system."""

__version__ = "0.1.1"
