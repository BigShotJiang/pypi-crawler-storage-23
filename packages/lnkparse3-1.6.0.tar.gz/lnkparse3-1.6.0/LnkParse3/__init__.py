__all__ = ["lnk_file"]

from LnkParse3.lnk_file import LnkFile as lnk_file
