"""Allow running the installer via `python -m recruit_crm_mcp`."""

from recruit_crm_mcp.install import main

if __name__ == "__main__":
    main()
