"""django-apcore: Django App bridging the apcore protocol to Django."""

__version__ = "0.1.0"
