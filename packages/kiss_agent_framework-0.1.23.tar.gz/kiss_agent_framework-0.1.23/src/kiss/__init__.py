# Author: Koushik Sen (ksen@berkeley.edu)
# Contributors:
# Koushik Sen (ksen@berkeley.edu)
# add your name here

"""Top-level Kiss module for the project."""

from kiss._version import __version__

__all__ = ["__version__"]
