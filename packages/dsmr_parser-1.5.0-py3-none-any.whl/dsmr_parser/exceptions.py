class ParseError(Exception):
    pass


class InvalidChecksumError(ParseError):
    pass
