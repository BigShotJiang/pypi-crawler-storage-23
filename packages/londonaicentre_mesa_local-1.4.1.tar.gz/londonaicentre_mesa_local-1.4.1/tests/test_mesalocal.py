from unittest.mock import MagicMock, Mock, mock_open, patch
from pathlib import Path

import pytest
from pytest import MonkeyPatch
from httpx import HTTPStatusError, RequestError

from tests.mesalocal import TestWeights
from mesalocal.aws import AWS
from mesalocal.settings import WeightsConfig


@pytest.fixture
def server(monkeypatch: MonkeyPatch) -> TestWeights:
    monkeypatch.setenv("WEIGHTS_ID", "foo")
    monkeypatch.setenv("WEIGHTS_KEY", "bar")
    return TestWeights(WeightsConfig())


@pytest.fixture
def mock_httpx_get(monkeypatch: MonkeyPatch) -> Mock:
    mock: Mock = Mock(return_value=Mock(json=Mock(return_value={"url": "foobar"})))
    monkeypatch.setattr("httpx.get", mock)
    return mock


@pytest.fixture
def mock_httpx_stream(monkeypatch: MonkeyPatch) -> MagicMock:
    chunks = [b"foo", b"bar", b"baz"]
    mock: MagicMock = MagicMock(
        raise_for_status=MagicMock(return_value=None),
        headers={"content-length": str(sum(len(chunk) for chunk in chunks))},
        iter_bytes=MagicMock(return_value=chunks),
    )
    monkeypatch.setattr("httpx.stream", mock)
    mock_pbar = MagicMock()
    monkeypatch.setattr("tqdm.tqdm", mock_pbar)
    return mock


@pytest.fixture
def mock_file(monkeypatch: MonkeyPatch) -> Mock:
    mock: Mock = mock_open()
    monkeypatch.setattr("builtins.open", mock)
    return mock


def test_get_weights(
    monkeypatch: MonkeyPatch,
    server: TestWeights,
    mock_httpx_get: Mock,
    mock_httpx_stream: MagicMock,
    mock_file: Mock,
) -> None:
    monkeypatch.setattr("os.path.isfile", Mock(return_value=False))
    server.get_weights("foo")
    mock_httpx_get.assert_any_call(
        server.get_presigned_generation_url(), headers={"x-api-key": "foo"}
    )
    mock_httpx_stream.assert_any_call("GET", "foobar")
    mock_file.assert_called_once_with(server.get_weights_path(), "wb")


def test_api_key(
    monkeypatch: MonkeyPatch, server: TestWeights, mock_httpx_get: Mock
) -> None:
    monkeypatch.setattr("os.path.isfile", Mock(return_value=False))
    mock_httpx_get.side_effect = HTTPStatusError(
        "401 Unauthorized", request=Mock(), response=Mock(status_code=401)
    )
    assert not server.get_weights("foo")


def test_exceptions(
    monkeypatch: MonkeyPatch, server: TestWeights, mock_httpx_get: Mock
) -> None:
    monkeypatch.setattr("os.path.isfile", Mock(return_value=False))
    mock_httpx_get.side_effect = RequestError("Network failure")
    assert not server.get_weights("foo")


def test_weights_exist(
    monkeypatch: MonkeyPatch, server: TestWeights, mock_httpx_get: Mock
) -> None:
    monkeypatch.setattr("os.path.isfile", Mock(return_value=True))
    assert server._get_weights("foo")
    mock_httpx_get.assert_not_called()


@pytest.fixture
def uri_server(
    monkeypatch: MonkeyPatch, server: TestWeights, tmp_path: Path
) -> TestWeights:
    monkeypatch.setattr("os.path.isfile", Mock(return_value=False))
    monkeypatch.setattr(server, "get_model_folder", Mock(return_value=str(tmp_path)))
    return server


def test_get_weights_from_uri_downloads_files(
    uri_server: TestWeights, tmp_path: Path
) -> None:
    """Test that _get_weights downloads all files from S3 when URI is configured."""
    with (
        patch.object(AWS, "list_s3_directory") as mock_list,
        patch.object(AWS, "download_s3_file") as mock_download,
    ):
        mock_list.return_value = ["model.bin", "config.json", "tokenizer.json"]

        uri_server.get_weights(
            uri="s3://my-bucket/models/my-model/", region="eu-west-2"
        )

        assert mock_download.call_count == 3
        mock_download.assert_any_call(
            "my-bucket",
            "models/my-model/model.bin",
            tmp_path / "model.bin",
            "eu-west-2",
        )


def test_get_weights_from_uri_skips_existing_files(
    uri_server: TestWeights, tmp_path: Path
) -> None:
    """Test that existing files are not re-downloaded."""
    (tmp_path / "model.bin").touch()

    with (
        patch.object(AWS, "list_s3_directory") as mock_list,
        patch.object(AWS, "download_s3_file") as mock_download,
    ):
        mock_list.return_value = ["model.bin", "config.json"]

        uri_server.get_weights(
            uri="s3://my-bucket/models/my-model/", region="eu-west-2"
        )

        assert mock_download.call_count == 1
        mock_download.assert_called_once_with(
            "my-bucket",
            "models/my-model/config.json",
            tmp_path / "config.json",
            "eu-west-2",
        )


def test_get_weights_from_uri_empty_directory(uri_server: TestWeights) -> None:
    """Test that _get_weights handles an empty S3 directory."""
    with (
        patch.object(AWS, "list_s3_directory") as mock_list,
        patch.object(AWS, "download_s3_file") as mock_download,
    ):
        mock_list.return_value = []

        assert uri_server.get_weights(
            uri="s3://my-bucket/models/my-model/", region="eu-west-2"
        )
        mock_download.assert_not_called()
