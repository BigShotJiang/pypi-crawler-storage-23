# Originally authored by Lawrence Adams (https://github.com/lawrenceadams)
# From: https://github.com/londonaicentre/mesa-runner

import datetime
from pathlib import Path
from unittest.mock import patch

import pytest
from dateutil.tz import tzutc

from mesalocal.aws import AWS, S3Location


class TestListLocalDirectory:
    def test_list_local_directory_invalid_path(self, tmp_path: Path) -> None:
        with pytest.raises(ValueError, match="Provided path is not a valid directory"):
            AWS.list_directories_at_path(str(tmp_path / "nonexistent"))

    def test_list_local_directory_file_not_directory(self, tmp_path: Path) -> None:
        file_path = tmp_path / "file.txt"
        file_path.touch()
        with pytest.raises(ValueError, match="Provided path is not a valid directory"):
            AWS.list_directories_at_path(str(file_path))

    def test_list_local_directory_empty(self, tmp_path: Path) -> None:
        result = AWS.list_directories_at_path(str(tmp_path))
        assert result == []

    def test_list_local_directory_with_contents(self, tmp_path: Path) -> None:
        (tmp_path / "file1.txt").touch()
        (tmp_path / "file2.json").touch()
        (tmp_path / "subdir").mkdir()

        result = AWS.list_directories_at_path(str(tmp_path))

        assert sorted(result) == ["subdir"]


class TestModelSyncOps:
    def test_s3_list_directory_invalid_uri(self) -> None:
        with pytest.raises(ValueError, match="Bucket URI must start with 's3://'"):
            AWS.list_s3_directory("invalid_uri")

    def test_s3_list_directory_missing_trailing_slash(self) -> None:
        with pytest.raises(
            ValueError, match="Bucket URI must end with a '/' to indicate a directory"
        ):
            AWS.list_s3_directory("s3://my-bucket/path/to/directory")

    def test_s3_list_directory_valid_uri(self) -> None:
        """
        Test that list_directory correctly parses the S3 URI and returns the expected list of
        objects. We do not want the highest level directory itself to be returned, only the contents
        """
        with patch("boto3.client") as mock_boto_client:
            mock_s3_client = mock_boto_client.return_value
            mock_s3_client.list_objects_v2.return_value = {
                "ResponseMetadata": {
                    "RequestId": "...",
                    "HostId": "...",
                    "HTTPStatusCode": 200,
                    "HTTPHeaders": {},
                    "RetryAttempts": 0,
                },
                "IsTruncated": False,
                "Contents": [
                    {
                        "Key": "models/oncoqwen/oncoqwen_1/",
                        "LastModified": datetime.datetime(
                            2026, 2, 4, 12, 58, 14, tzinfo=tzutc()
                        ),
                        "ETag": '"d41d8cd98f00b204e9800998ecf8427e"',
                        "ChecksumAlgorithm": ["CRC64NVME"],
                        "ChecksumType": "FULL_OBJECT",
                        "Size": 0,
                        "StorageClass": "STANDARD",
                    },
                    {
                        "Key": "models/oncoqwen/oncoqwen_1/added_tokens.json",
                        "LastModified": datetime.datetime(
                            2026, 2, 4, 12, 59, 1, tzinfo=tzutc()
                        ),
                        "ETag": '"4e6d7381b084bb04b0d35f8fd4b0d185"',
                        "ChecksumAlgorithm": ["CRC64NVME"],
                        "ChecksumType": "FULL_OBJECT",
                        "Size": 707,
                        "StorageClass": "STANDARD",
                    },
                    {
                        "Key": "models/oncoqwen/oncoqwen_1/chat_template.jinja",
                        "LastModified": datetime.datetime(
                            2026, 2, 4, 12, 59, 1, tzinfo=tzutc()
                        ),
                        "ETag": '"5795f12e815eef069e10dd289b80ad4c"',
                        "ChecksumAlgorithm": ["CRC64NVME"],
                        "ChecksumType": "FULL_OBJECT",
                        "Size": 2630,
                        "StorageClass": "STANDARD",
                    },
                ],
                "Name": "aicentre-nlpteam-mesa-build",
                "Prefix": "models/oncoqwen/oncoqwen_1/",
                "Delimiter": "/",
                "MaxKeys": 1000,
                "EncodingType": "url",
                "KeyCount": 13,
            }

            result = AWS.list_s3_directory("s3://my-bucket/models/oncoqwen/oncoqwen_1/")
        assert result == ["added_tokens.json", "chat_template.jinja"]


class TestS3Location:
    def test_from_uri_valid(self) -> None:
        location = S3Location.from_uri("s3://my-bucket/path/to/dir/")
        assert location.bucket == "my-bucket"
        assert location.prefix == "path/to/dir/"

    def test_from_uri_invalid_scheme(self) -> None:
        with pytest.raises(ValueError, match="Bucket URI must start with 's3://'"):
            S3Location.from_uri("http://my-bucket/path/")

    def test_from_uri_missing_trailing_slash(self) -> None:
        with pytest.raises(ValueError, match="Bucket URI must end with a '/'"):
            S3Location.from_uri("s3://my-bucket/path/to/dir")

    def test_from_uri_no_trailing_slash_required(self) -> None:
        location = S3Location.from_uri(
            "s3://my-bucket/path/to/file.txt", require_trailing_slash=False
        )
        assert location.bucket == "my-bucket"
        assert location.prefix == "path/to/file.txt"

    def test_uri_property(self) -> None:
        location = S3Location(bucket="my-bucket", prefix="path/to/dir/")
        assert location.uri == "s3://my-bucket/path/to/dir/"
