import logging
import uuid
from argparse import Namespace
from typing import AsyncGenerator

from vllm import AsyncLLMEngine, RequestOutput, SamplingParams
from vllm.engine.arg_utils import AsyncEngineArgs

from mesalocal.settings import VLLMConfig


class VLLM:
    """Infer with MESA models"""

    def __init__(
        self, model_path: str, config: VLLMConfig = VLLMConfig(), verbose: bool = False
    ) -> None:
        self.__logger: logging.Logger = logging.getLogger()
        if not self.__logger.hasHandlers():
            self.__logger.addHandler(logging.StreamHandler())
        self.__logger.setLevel(logging.DEBUG if verbose else logging.INFO)
        self.__model_path: str = model_path
        self.__config: VLLMConfig = config
        self.__engine: AsyncLLMEngine | None = None

    def __get_engine(self) -> AsyncLLMEngine:
        if self.__engine is None:
            self.__engine = AsyncLLMEngine.from_engine_args(
                AsyncEngineArgs(
                    model=self.__model_path,
                    **self.__config.model_dump(exclude={"model", "served_model_name"}),
                )
            )
        return self.__engine

    async def serve(self, port: int) -> None:
        from vllm.entrypoints.openai.api_server import run_server
        from vllm.entrypoints.openai.cli_args import make_arg_parser
        from vllm.utils.argparse_utils import FlexibleArgumentParser

        parser: FlexibleArgumentParser = make_arg_parser(FlexibleArgumentParser())  # type: ignore[no-untyped-call]
        args: Namespace = parser.parse_args([])
        args.model = self.__model_path
        vars(args).update(self.__config.model_dump(exclude={"model"}))
        args.port = port
        await run_server(args)

    def generate(
        self,
        prompt: str,
        sampling_params: SamplingParams = SamplingParams(),
        request_id: str = "",
    ) -> AsyncGenerator[RequestOutput, None]:
        return self.__get_engine().generate(
            prompt, sampling_params, request_id=request_id or str(uuid.uuid4())
        )

    async def log_stats(self) -> None:
        await self.__get_engine().do_log_stats()
