import os
import logging
from pathlib import Path

import httpx
from httpx import Response, HTTPStatusError, RequestError
from tqdm import tqdm

from mesalocal.settings import WeightsConfig
from mesalocal.utils import Utils
from mesalocal.aws import AWS, S3Location


class Weights:
    """Interact with MESA model weights"""

    def __init__(
        self,
        model_name: str,
        verbose: bool = False,
        weights_config: WeightsConfig | None = None,
    ) -> None:
        self.__logger: logging.Logger = logging.getLogger()
        if not self.__logger.hasHandlers():
            self.__logger.addHandler(logging.StreamHandler())
        self.__logger.setLevel(logging.DEBUG if verbose else logging.INFO)
        self.__weights_config: WeightsConfig = weights_config or WeightsConfig()
        self.__model_name: str = model_name

    def download(self) -> bool:
        """
        Download (and extract) model weights from S3

        Returns:
            bool: whether both operations were successful

        """
        if self.__weights_config.uri:
            return self._get_weights(
                uri=self.__weights_config.uri, region=self.__weights_config.region
            )
        else:
            return self.__unpack()

    def __unpack(self) -> bool:
        return self._get_weights(self.__weights_config.key) and self.__unzip_weights()

    def get_weights_path(self) -> str:
        return f"assets/weights/{self.__model_name}/model.tar.gz"

    def get_model_folder(self) -> str:
        return str(Path(self.get_weights_path()).parent)

    def _get_presigned_generation_url(self) -> str:
        return f"https://{self.__weights_config.id}.execute-api.{self.__weights_config.region}.amazonaws.com/dist/{self.__model_name}/model.tar.gz"

    def _get_weights(
        self, key: str | None = None, uri: str | None = None, region: str = "eu-west-2"
    ) -> bool:
        if not os.path.isfile(self.get_weights_path()):
            if key is None and uri is not None:
                location = S3Location.from_uri(uri, require_trailing_slash=True)

                files = AWS.list_s3_directory(uri, region)
                self.__logger.info(
                    f"Syncing {len(files)} files from {uri} to {self.get_model_folder()}"
                )

                for file_name in files:
                    s3_key = location.prefix + file_name
                    local_path = Path(self.get_model_folder()) / file_name

                    if local_path.exists():
                        self.__logger.debug(f"Skipping {file_name} (already exists)")
                        continue

                    AWS.download_s3_file(location.bucket, s3_key, local_path, region)
            elif key is not None:
                try:
                    self.__logger.info("Fetching signed S3 URL...")
                    presigned_url_response: Response = httpx.get(
                        self._get_presigned_generation_url(),
                        headers={"x-api-key": key},
                    )
                    presigned_url_response.raise_for_status()
                    self.__logger.info("Fetching weights...")
                    os.makedirs(os.path.dirname(self.get_weights_path()), exist_ok=True)
                    with httpx.stream(
                        "GET", presigned_url_response.json()["url"]
                    ) as weights_response:
                        weights_response.raise_for_status()
                        total: int = int(
                            weights_response.headers.get("content-length", 0)
                        )
                        with (
                            open(self.get_weights_path(), "wb") as file,
                            tqdm(
                                total=total, unit_scale=True, unit="B"
                            ) as progress_bar,
                        ):
                            for chunk in weights_response.iter_bytes():
                                file.write(chunk)
                                progress_bar.update(len(chunk))
                except HTTPStatusError as e:
                    self.__logger.error(
                        f"Unable to download weights (details: HTTP error {e.response.status_code}: {e.response.text})"
                    )
                    return False
                except RequestError as e:
                    self.__logger.error(
                        f"Unable to download weights (details: Request failed: {e})"
                    )
                    return False
                except Exception as e:
                    self.__logger.error(f"Unable to download weights (details: {e})")
                    return False
            self.__logger.info("Weights fetched")
        else:
            self.__logger.info("Existing weights found")
        return True

    def __unzip_weights(self) -> bool:
        if Utils.one_file(self.get_weights_path()):
            try:
                self.__logger.debug(
                    f"Unpacking weights at {self.get_weights_path()}..."
                )
                Utils.untar(self.get_weights_path())
                self.__logger.debug("Weights unpacked")
            except Exception as e:
                self.__logger.error(f"Unable to extract weights (details: {e})")
                return False
        return True
