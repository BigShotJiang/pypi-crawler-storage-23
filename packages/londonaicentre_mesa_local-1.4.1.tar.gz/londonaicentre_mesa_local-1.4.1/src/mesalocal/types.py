from pydantic import BaseModel


class MESALocalArguments(BaseModel):
    verbose: bool
