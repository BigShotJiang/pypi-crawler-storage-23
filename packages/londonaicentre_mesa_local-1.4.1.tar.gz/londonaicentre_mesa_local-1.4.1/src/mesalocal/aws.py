# Originally authored by Lawrence Adams (https://github.com/lawrenceadams)
# From: https://github.com/londonaicentre/mesa-runner

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

import boto3

if TYPE_CHECKING:
    from types_boto3_s3 import S3Client

logger = logging.getLogger(__name__)


@dataclass
class S3Location:
    """Parsed S3 URI components."""

    bucket: str
    prefix: str

    @classmethod
    def from_uri(cls, s3_uri: str, require_trailing_slash: bool = True) -> "S3Location":
        """
        Parse an S3 URI into bucket and prefix components.

        Args:
            s3_uri: S3 URI in the format "s3://bucket-name/path/to/object"
            require_trailing_slash: If True, raises ValueError if URI doesn't end with "/"

        Returns:
            S3Location with bucket and prefix

        Raises:
            ValueError: If URI is not properly formatted
        """
        if not s3_uri.startswith("s3://"):
            raise ValueError("Bucket URI must start with 's3://'")

        if require_trailing_slash and not s3_uri.endswith("/"):
            raise ValueError("Bucket URI must end with a '/' to indicate a directory")

        path_part = s3_uri[5:]  # Remove "s3://"
        bucket = path_part.split("/")[0]
        prefix = path_part[len(bucket) + 1 :]

        return cls(bucket=bucket, prefix=prefix)

    @property
    def uri(self) -> str:
        """Reconstruct the S3 URI."""
        return f"s3://{self.bucket}/{self.prefix}"


class AWS:
    @staticmethod
    def _get_s3_client(region_name: str = "eu-west-2") -> "S3Client":
        """Get a configured S3 client."""
        return boto3.client("s3", region_name=region_name)

    @staticmethod
    def list_s3_directory(
        bucket_s3_uri: str, region_name: str = "eu-west-2"
    ) -> list[str]:
        """
        Lists the contents of a directory in S3.
        The bucket_s3_uri should be in the format "s3://bucket-name/path/to/directory/"

        Does not return the root directory itself, only the contents.

        Note: the trailing slash is important to indicate it's a directory.
        Returns a list of object keys within the specified directory.
        Raises ValueError if the URI is not properly formatted.
        """
        location = S3Location.from_uri(bucket_s3_uri, require_trailing_slash=True)
        s3 = AWS._get_s3_client(region_name)

        response = s3.list_objects_v2(
            Bucket=location.bucket, Prefix=location.prefix, Delimiter="/"
        )

        if "Contents" not in response:
            return []

        objects = [
            obj["Key"].split(location.prefix, 1)[1]
            for obj in response["Contents"]
            if "Key" in obj and obj["Key"] != location.prefix
        ]

        return objects

    @staticmethod
    def download_s3_file(
        bucket: str, key: str, destination: Path, region_name: str = "eu-west-2"
    ) -> Path:
        """
        Download a single file from S3 to the specified destination.

        Args:
            bucket: S3 bucket name
            key: S3 object key
            destination: Local file path to save the file

        Returns:
            Path to the downloaded file
        """
        s3 = AWS._get_s3_client(region_name)
        destination.parent.mkdir(parents=True, exist_ok=True)
        s3.download_file(bucket, key, str(destination))
        logger.debug(f"Downloaded s3://{bucket}/{key} to {destination}")
        return destination

    @staticmethod
    def list_directories_at_path(directory_path: str) -> list[str]:
        """
        Lists the contents of a local directory.
        Returns a list of file and subdirectory names within the specified directory.
        Raises ValueError if the path is not a valid directory.
        """
        if not Path(directory_path).is_dir():
            raise ValueError("Provided path is not a valid directory")

        return [
            entry.name for entry in Path(directory_path).iterdir() if entry.is_dir()
        ]
