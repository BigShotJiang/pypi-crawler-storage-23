"""cortex-mem: Always-On Memory Service with Progressive Disclosure."""

from cortex_mem.__version__ import __version__

__all__ = ["__version__"]
