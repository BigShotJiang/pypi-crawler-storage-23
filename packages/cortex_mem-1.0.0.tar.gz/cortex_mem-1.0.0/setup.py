"""Backwards-compatible setup.py — delegates to pyproject.toml."""

from setuptools import setup

setup()
