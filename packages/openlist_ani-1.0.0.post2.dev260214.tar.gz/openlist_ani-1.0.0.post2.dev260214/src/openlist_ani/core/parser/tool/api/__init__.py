"""External API clients for parser tools."""
