"""Parser tool module for handling LLM tools and external API interactions."""
