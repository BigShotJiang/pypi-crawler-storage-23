Usage
=====

Basic Usage
-----------

Here's a simple example of how to use powersensor_local:

.. code-block:: python

   import powersensor_local

   # Add your usage examples here

Advanced Usage
--------------

More detailed examples and advanced features will be documented here.
