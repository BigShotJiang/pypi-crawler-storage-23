"""Subject commands for iFlow CLI."""

import asyncio

import click

from iflow.api import APIError, MinerAPIClient
from iflow.config import require_project
from iflow.curl import miner_curl


@click.group()
def subjects():
    """Manage subjects (patients)."""
    pass


@subjects.command("list")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.option("--limit", default=20, help="Maximum subjects to display")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def list_subjects(project: str | None, limit: int, curl: bool):
    """List subjects for a project.

    \b
    Examples:
      iflow subjects list
      iflow subjects list --limit 50
    """
    project_id = require_project(project)

    if curl:
        params = {"limit": str(limit)}
        print(miner_curl("GET", "/subjects", project_id, params=params))
        return

    async def _list():
        client = MinerAPIClient()
        try:
            subjects_list = await client.list_subjects(
                project_id=project_id,
                limit=limit,
            )

            if not subjects_list:
                click.echo("No subjects found.")
                return

            click.echo(f"{'SUBJECT_ID':<25} {'EXTERNAL ID':<20} {'SEX':<10}")
            click.echo("-" * 55)

            for s in subjects_list:
                did = s.display_id or "-"
                ext_id = s.external_id or "-"
                click.echo(f"{did:<25} {ext_id:<20} {s.sex:<10}")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_list())


# Model column keys that get promoted to top-level API fields
SUBJECT_MODEL_FIELDS = {"sex", "date_of_birth", "external_id", "diagnosis", "clinical_notes"}


def _parse_properties(properties: tuple[str, ...], model_fields: set[str]) -> tuple[dict, dict]:
    """Split --property key=value pairs into model fields and JSONB properties."""
    data: dict = {}
    props: dict = {}
    for kv in properties:
        if "=" not in kv:
            raise click.BadParameter(
                f"Invalid format: '{kv}'. Use key=value",
                param_hint="--property",
            )
        k, v = kv.split("=", 1)
        if k in model_fields:
            data[k] = v
        else:
            props[k] = v
    return data, props


@subjects.command("create")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.option("-n", "--subject-id", help="Subject ID (auto-generated if not provided)")
@click.option(
    "-P", "--property", "properties", multiple=True,
    help="Property key=value (repeatable). "
    "Model keys: sex, date_of_birth, external_id, diagnosis",
)
@click.option("--tag", "-t", multiple=True, help="Tag for the subject")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def create_subject(
    project: str | None,
    subject_id: str | None,
    properties: tuple[str, ...],
    tag: tuple[str, ...],
    curl: bool,
):
    """Create a new subject (patient).

    \b
    --subject-id (-n) is optional (auto-generated as SUBJ-N if not provided).
    All other fields are passed via --property/-P key=value:
      iflow subjects create --subject-id "Patient_Smith" -P sex=male -P surname=Smith
      iflow subjects create -P external_id=MRN-12345 -P diagnosis="Hereditary cancer"

    \b
    Known model keys (stored as columns):
    sex, date_of_birth, external_id, diagnosis, clinical_notes
    All dates use YYYY-MM-DD format (e.g., 2026-01-15).
    Other keys are stored in properties JSONB: first_name, surname, gender, etc.
    """
    project_id = require_project(project)

    model_data, props = _parse_properties(properties, SUBJECT_MODEL_FIELDS)
    data: dict = {**model_data}
    if subject_id:
        data["subject_id"] = subject_id
    if tag:
        data["tags"] = list(tag)
    if props:
        data["properties"] = props

    if curl:
        print(miner_curl("POST", "/subjects", project_id, data=data))
        return

    async def _create():
        client = MinerAPIClient()
        try:
            subject = await client.create_subject(
                project_id=project_id,
                display_id=subject_id,
                external_id=model_data.get("external_id"),
                sex=model_data.get("sex", "unknown"),
                date_of_birth=model_data.get("date_of_birth"),
                diagnosis=model_data.get("diagnosis"),
                clinical_notes=model_data.get("clinical_notes"),
                tags=list(tag) if tag else None,
                properties=props or None,
            )

            click.echo("Subject created successfully!")
            click.echo(f"  Subject ID: {subject.display_id}")
            if subject.external_id:
                click.echo(f"  External ID: {subject.external_id}")
            click.echo(f"  Sex: {subject.sex}")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_create())


@subjects.command("get")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.argument("subject_id")
@click.option("--uuid", "use_uuid", is_flag=True, help="Treat identifier as UUID")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def get_subject(project: str | None, subject_id: str, use_uuid: bool, curl: bool):
    """Get details of a subject.

    SUBJECT_ID is the subject identifier (display_id, slug, or UUID).
    Use --uuid to force UUID lookup.
    """
    project_id = require_project(project)
    lookup = "uuid" if use_uuid else None

    if curl:
        suffix = "?lookup=uuid" if use_uuid else ""
        print(miner_curl("GET", f"/subjects/{subject_id}{suffix}", project_id))
        return

    async def _get():
        client = MinerAPIClient()
        try:
            subject = await client.get_subject(project_id, subject_id, lookup=lookup)

            click.echo(f"Subject: {subject.display_id or subject.id}")
            click.echo(f"  Subject ID: {subject.display_id}")
            if subject.external_id:
                click.echo(f"  External ID: {subject.external_id}")
            click.echo(f"  Sex: {subject.sex}")
            if subject.date_of_birth:
                click.echo(f"  Date of Birth: {subject.date_of_birth}")
            if subject.diagnosis:
                click.echo(f"  Diagnosis: {subject.diagnosis}")
            if subject.created_at:
                click.echo(f"  Created: {subject.created_at}")
            if subject.tags:
                click.echo(f"  Tags: {', '.join(subject.tags)}")
            if subject.properties:
                click.echo("  Properties:")
                for k, v in subject.properties.items():
                    click.echo(f"    {k}: {v}")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_get())


@subjects.command("update")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.argument("subject_id")
@click.option("-n", "--subject-id", "new_subject_id", help="New subject ID")
@click.option(
    "-P", "--property", "properties", multiple=True,
    help="Property key=value (repeatable). Model keys: sex, date_of_birth (YYYY-MM-DD), "
    "external_id, diagnosis, clinical_notes",
)
@click.option("--uuid", "use_uuid", is_flag=True, help="Treat identifier as UUID")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def update_subject(
    project: str | None,
    subject_id: str,
    new_subject_id: str | None,
    properties: tuple[str, ...],
    use_uuid: bool,
    curl: bool,
):
    """Update a subject's fields.

    \b
    SUBJECT_ID is the subject identifier (accepts display_id or UUID).

    \b
    Examples:
        iflow subjects update Patient_Smith -n "Patient_Jones"
        iflow subjects update Patient_Smith -P sex=female -P diagnosis="Type 2 Diabetes"
    """
    project_id = require_project(project)

    model_fields = SUBJECT_MODEL_FIELDS | {"clinical_notes"}
    model_data, extra_props = _parse_properties(properties, model_fields)

    payload: dict = {}
    if new_subject_id:
        payload["subject_id"] = new_subject_id
    payload.update(model_data)
    if extra_props:
        payload["properties"] = extra_props

    if not payload:
        click.echo("Nothing to update. Use -n or -P to specify changes.", err=True)
        raise SystemExit(1)

    lookup = "uuid" if use_uuid else None

    if curl:
        import json
        suffix = "?lookup=uuid" if use_uuid else ""
        print(miner_curl(
            "PATCH", f"/subjects/{subject_id}{suffix}", project_id, json.dumps(payload)
        ))
        return

    async def _update():
        client = MinerAPIClient()
        try:
            subject = await client.update_subject(
                project_id, subject_id, payload, lookup=lookup
            )
            click.echo(f"Subject updated: {subject.display_id or subject.id}")
        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_update())


@subjects.command("delete")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.argument("subject_id")
@click.option("--uuid", "use_uuid", is_flag=True, help="Treat identifier as UUID")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
@click.confirmation_option(prompt="Are you sure you want to delete this subject?")
def delete_subject(project: str | None, subject_id: str, use_uuid: bool, curl: bool):
    """Delete a subject (cascades to samples).

    SUBJECT_ID is the subject identifier (display_id, slug, or UUID).
    Use --uuid to force UUID lookup.
    """
    project_id = require_project(project)
    lookup = "uuid" if use_uuid else None

    if curl:
        suffix = "?lookup=uuid" if use_uuid else ""
        print(miner_curl("DELETE", f"/subjects/{subject_id}{suffix}", project_id))
        return

    async def _delete():
        client = MinerAPIClient()
        try:
            await client.delete_subject(project_id, subject_id, lookup=lookup)
            click.echo(f"Subject {subject_id} deleted.")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_delete())
