"""Order commands for iFlow CLI."""

import asyncio

import click

from iflow.api import APIError, MinerAPIClient
from iflow.config import require_project
from iflow.curl import miner_curl


@click.group()
def orders():
    """Manage clinical orders."""
    pass


@orders.command("list")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.option("--status", help="Filter by status (created, analyzing, reviewed, etc.)")
@click.option("--priority", help="Filter by priority (routine, urgent, stat)")
@click.option("-a", "--all", "show_all", is_flag=True, help="Show all columns")
@click.option("--limit", default=20, help="Maximum orders to display")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def list_orders(
    project: str | None,
    status: str | None,
    priority: str | None,
    show_all: bool,
    limit: int,
    curl: bool,
):
    """List orders for a project.

    \b
    Examples:
      iflow orders list
      iflow orders list --status created
      iflow orders list --priority urgent
      iflow orders list --all
    """
    project_id = require_project(project)

    if curl:
        params = {"limit": str(limit)}
        if status:
            params["status"] = status
        if priority:
            params["priority"] = priority
        print(miner_curl("GET", "/orders", project_id, params=params))
        return

    async def _list():
        client = MinerAPIClient()
        try:
            orders_list = await client.list_orders(
                project_id=project_id,
                status=status,
                priority=priority,
                limit=limit,
            )

            if not orders_list:
                click.echo("No orders found.")
                return

            if show_all:
                # Extended columns
                click.echo(
                    f"{'ORDER_ID':<25} {'STATUS':<18} {'PRIORITY':<10} "
                    f"{'ACCESSION':<15} {'EXTERNAL_ID':<15} {'TEST_TYPE':<15} "
                    f"{'INDICATION':<20} {'CREATED':<20}"
                )
                click.echo("-" * 140)
                for o in orders_list:
                    created = (o.created_at or "")[:19]
                    click.echo(
                        f"{(o.display_id or ''):<25} {o.status:<18} "
                        f"{o.priority:<10} {(o.accession_number or ''):<15} "
                        f"{(o.external_id or ''):<15} {(o.test_type or ''):<15} "
                        f"{(o.indication or ''):<20} {created:<20}"
                    )
            else:
                # Default compact columns
                click.echo(
                    f"{'ORDER_ID':<30} {'STATUS':<18} {'PRIORITY':<10}"
                )
                click.echo("-" * 60)
                for o in orders_list:
                    click.echo(
                        f"{o.display_id:<30} {o.status:<18} {o.priority:<10}"
                    )

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_list())


@orders.command("create")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.option("-n", "--order-id", help="Order ID (auto-generated if not provided)")
@click.option("--accession", help="Lab accession number")
@click.option("--external-id", help="External system reference")
@click.option("--description", help="Order description")
@click.option(
    "--priority",
    type=click.Choice(["routine", "urgent", "stat"]),
    default="routine",
    help="Priority level",
)
@click.option("--indication", help="Clinical indication / reason for testing")
@click.option("--test-type", help="Type of genetic test")
@click.option("--provider", help="Ordering provider name")
@click.option("--facility", help="Ordering facility name")
@click.option("--tag", "-t", multiple=True, help="Tag for the order")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def create_order(
    project: str | None,
    order_id: str | None,
    accession: str | None,
    external_id: str | None,
    description: str | None,
    priority: str,
    indication: str | None,
    test_type: str | None,
    provider: str | None,
    facility: str | None,
    tag: tuple[str, ...],
    curl: bool,
):
    """Create a new order.

    \b
    --order-id (-n) is optional (auto-generated as ORD-N if not provided).
    Examples:
      iflow orders create -n "Patient Smith Case"
      iflow orders create --priority urgent \\
        --accession ACC-001 --indication "Family history of cancer"
    """
    project_id = require_project(project)

    data: dict = {"priority": priority}
    if order_id:
        data["order_id"] = order_id
    if accession:
        data["accession_number"] = accession
    if external_id:
        data["external_id"] = external_id
    if description:
        data["description"] = description
    if indication:
        data["indication"] = indication
    if test_type:
        data["test_type"] = test_type
    if provider:
        data["ordering_provider"] = provider
    if facility:
        data["ordering_facility"] = facility
    if tag:
        data["tags"] = list(tag)

    if curl:
        print(miner_curl("POST", "/orders", project_id, data=data))
        return

    async def _create():
        client = MinerAPIClient()
        try:
            order = await client.create_order(
                project_id=project_id,
                display_id=order_id,
                accession_number=accession,
                external_id=external_id,
                description=description,
                priority=priority,
                indication=indication,
                test_type=test_type,
                ordering_provider=provider,
                ordering_facility=facility,
                tags=list(tag) if tag else None,
            )

            click.echo("Order created successfully!")
            click.echo(f"  Order ID: {order.display_id}")
            click.echo(f"  Status: {order.status}")
            click.echo(f"  Priority: {order.priority}")
            if order.accession_number:
                click.echo(f"  Accession: {order.accession_number}")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_create())


@orders.command("get")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.argument("order_id")
@click.option("--uuid", "use_uuid", is_flag=True, help="Treat identifier as UUID")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def get_order(project: str | None, order_id: str, use_uuid: bool, curl: bool):
    """Get details of an order.

    ORDER_ID is the order identifier.
    """
    project_id = require_project(project)
    lookup = "uuid" if use_uuid else None

    if curl:
        url = f"/orders/{order_id}"
        if use_uuid:
            url += "?lookup=uuid"
        print(miner_curl("GET", url, project_id))
        return

    async def _get():
        client = MinerAPIClient()
        try:
            order = await client.get_order(project_id, order_id, lookup=lookup)

            click.echo(f"Order: {order.display_id}")
            click.echo(f"  Order ID: {order.display_id}")
            click.echo(f"  Status: {order.status}")
            click.echo(f"  Priority: {order.priority}")

            if order.accession_number:
                click.echo(f"  Accession: {order.accession_number}")
            if order.external_id:
                click.echo(f"  External ID: {order.external_id}")
            if order.description:
                click.echo(f"  Description: {order.description}")
            if order.indication:
                click.echo(f"  Indication: {order.indication}")
            if order.test_type:
                click.echo(f"  Test Type: {order.test_type}")
            if order.ordering_provider:
                click.echo(f"  Provider: {order.ordering_provider}")
            if order.ordering_facility:
                click.echo(f"  Facility: {order.ordering_facility}")

            if order.created_at:
                click.echo(f"  Created: {order.created_at}")
            if order.updated_at:
                click.echo(f"  Updated: {order.updated_at}")

            if order.tags:
                click.echo(f"  Tags: {', '.join(order.tags)}")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_get())


@orders.command("transition")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.argument("order_id")
@click.argument(
    "status",
    type=click.Choice([
        "created",
        "analyzing",
        "reviewed",
        "signed_off",
        "completed",
        "amended",
        "cancelled",
    ]),
)
@click.option("--uuid", "use_uuid", is_flag=True, help="Treat identifier as UUID")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def transition_order(project: str | None, order_id: str, status: str, use_uuid: bool, curl: bool):
    """Transition order to a new status.

    \b
    ORDER_ID is the order identifier.
    STATUS is the target status.

    \b
    Status flow:
      created -> analyzing -> reviewed -> signed_off -> completed
                                                          -> amended

    \b
    Examples:
      iflow orders transition ORDER_ID analyzing
      iflow orders transition ORDER_ID reviewed
    """
    project_id = require_project(project)
    lookup = "uuid" if use_uuid else None

    if curl:
        data = {"status": status}
        url = f"/orders/{order_id}/transition"
        if use_uuid:
            url += "?lookup=uuid"
        print(miner_curl("POST", url, project_id, data=data))
        return

    async def _transition():
        client = MinerAPIClient()
        try:
            order = await client.transition_order(project_id, order_id, status, lookup=lookup)

            click.echo("Order transitioned successfully!")
            click.echo(f"  Order ID: {order.display_id}")
            click.echo(f"  Status: {order.status}")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_transition())


@orders.command("delete")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.argument("order_id")
@click.option("--uuid", "use_uuid", is_flag=True, help="Treat identifier as UUID")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
@click.confirmation_option(prompt="Are you sure you want to delete this order?")
def delete_order(project: str | None, order_id: str, use_uuid: bool, curl: bool):
    """Delete an order.

    ORDER_ID is the order identifier.
    """
    project_id = require_project(project)
    lookup = "uuid" if use_uuid else None

    if curl:
        url = f"/orders/{order_id}"
        if use_uuid:
            url += "?lookup=uuid"
        print(miner_curl("DELETE", url, project_id))
        return

    async def _delete():
        client = MinerAPIClient()
        try:
            await client.delete_order(project_id, order_id, lookup=lookup)
            click.echo(f"Order {order_id} deleted.")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_delete())


@orders.command("samples")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.argument("order_id")
@click.option("--uuid", "use_uuid", is_flag=True, help="Treat identifier as UUID")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def list_order_samples(project: str | None, order_id: str, use_uuid: bool, curl: bool):
    """List samples in an order.

    ORDER_ID is the order identifier.
    """
    project_id = require_project(project)

    if curl:
        url = f"/orders/{order_id}/samples"
        if use_uuid:
            url += "?lookup=uuid"
        print(miner_curl("GET", url, project_id))
        return

    async def _samples():
        client = MinerAPIClient()
        try:
            samples = await client.get_order_samples(project_id, order_id)

            if not samples:
                click.echo("No samples in this order.")
                return

            click.echo(f"{'SAMPLE_ID':<30} {'STATUS':<15}")
            click.echo("-" * 45)

            for s in samples:
                click.echo(f"{s.display_id:<30} {s.status:<15}")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_samples())


@orders.command("add-sample")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.argument("order_id")
@click.argument("sample_id", required=False)
@click.option(
    "--sample-display-id",
    help="Find sample by display ID (alternative to SAMPLE_ID)",
)
@click.option(
    "--sample-uuid",
    help="Find sample by UUID (alternative to SAMPLE_ID)",
)
@click.option("--uuid", "use_uuid", is_flag=True, help="Treat identifier as UUID")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def add_sample_to_order(
    project: str | None,
    order_id: str,
    sample_id: str | None,
    sample_display_id: str | None,
    sample_uuid: str | None,
    use_uuid: bool,
    curl: bool,
):
    """Add a sample to an order.

    \b
    ORDER_ID is the order identifier (accepts display_id or UUID).
    SAMPLE_ID is the sample identifier (accepts display_id or UUID).

    \b
    Full workflow:
      iflow subjects create --subject-id "Patient_Smith"
      iflow samples create --subject-id Patient_Smith --sample-id "NA12878"
      iflow orders add-sample ORD-1 NA12878
    """
    if not sample_id and not sample_display_id and not sample_uuid:
        click.echo(
            "Error: SAMPLE_ID, --sample-display-id, or --sample-uuid is required.", err=True
        )
        raise SystemExit(1)

    project_id = require_project(project)

    if curl:
        if sample_id or sample_uuid:
            resolved = sample_uuid if sample_uuid else sample_id
            data = {"sample_id": resolved}
            url = f"/orders/{order_id}/samples"
            if use_uuid:
                url += "?lookup=uuid"
            print(miner_curl("POST", url, project_id, data=data))
        else:
            click.echo(
                "Error: --curl requires SAMPLE_ID or --sample-uuid "
                "(not --sample-display-id).",
                err=True,
            )
            raise SystemExit(1)
        return

    async def _add():
        client = MinerAPIClient()
        try:
            resolved_id = sample_uuid if sample_uuid else sample_id
            if not resolved_id and sample_display_id:
                # Resolve sample display_id to UUID by listing and filtering
                samples = await client.list_samples(project_id=project_id, limit=500)
                matches = [s for s in samples if s.display_id == sample_display_id]
                if not matches:
                    click.echo(
                        f"Error: No sample found with display ID "
                        f"'{sample_display_id}'.",
                        err=True,
                    )
                    raise SystemExit(1)
                if len(matches) > 1:
                    click.echo(
                        f"Error: Multiple samples found with display ID "
                        f"'{sample_display_id}'. Use SAMPLE_ID instead.",
                        err=True,
                    )
                    for m in matches:
                        click.echo(f"  {m.id}  {m.display_id}", err=True)
                    raise SystemExit(1)
                resolved_id = matches[0].id
                click.echo(f"Resolved '{sample_display_id}' -> {resolved_id}")

            await client.add_sample_to_order(project_id, order_id, resolved_id)
            click.echo(f"Sample {resolved_id} added to order {order_id}.")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_add())


@orders.command("remove-sample")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.argument("order_id")
@click.argument("sample_id")
@click.option("--uuid", "use_uuid", is_flag=True, help="Treat identifier as UUID")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def remove_sample_from_order(
    project: str | None, order_id: str, sample_id: str, use_uuid: bool, curl: bool
):
    """Remove a sample from an order.

    \b
    ORDER_ID is the order identifier.
    SAMPLE_ID is the sample identifier.
    """
    project_id = require_project(project)

    if curl:
        url = f"/orders/{order_id}/samples/{sample_id}"
        if use_uuid:
            url += "?lookup=uuid"
        print(miner_curl("DELETE", url, project_id))
        return

    async def _remove():
        client = MinerAPIClient()
        try:
            await client.remove_sample_from_order(project_id, order_id, sample_id)
            click.echo(f"Sample {sample_id} removed from order {order_id}.")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_remove())


@orders.command("samplesheet")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.argument("order_id")
@click.option("--uuid", "use_uuid", is_flag=True, help="Treat identifier as UUID")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def get_samplesheet(project: str | None, order_id: str, use_uuid: bool, curl: bool):
    """Generate nf-core samplesheet CSV for all samples in an order.

    \b
    Returns CSV to stdout with columns: sample, fastq_1, fastq_2, strandedness,
    specimen_type, sex, accession_id.

    \b
    Examples:
      iflow orders samplesheet ORDER_ID
      iflow orders samplesheet ORDER_ID > samplesheet.csv
    """
    project_id = require_project(project)

    if curl:
        url = f"/orders/{order_id}/samplesheet"
        if use_uuid:
            url += "?lookup=uuid"
        print(miner_curl("GET", url, project_id))
        return

    async def _samplesheet():
        client = MinerAPIClient()
        try:
            csv_content = await client.get_order_samplesheet(project_id, order_id)
            click.echo(csv_content, nl=False)
        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_samplesheet())
