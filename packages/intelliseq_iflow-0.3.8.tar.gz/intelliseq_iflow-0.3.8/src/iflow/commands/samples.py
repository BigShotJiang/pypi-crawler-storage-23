"""Sample commands for iFlow CLI."""

import asyncio
import json

import click

from iflow.api import APIError, MinerAPIClient
from iflow.config import require_project
from iflow.curl import miner_curl


@click.group()
def samples():
    """Manage samples (VCF columns)."""
    pass


@samples.command("list")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.option(
    "--sample-type",
    help="Filter by type (e.g., germline, somatic, ffpe, liquid_biopsy, or any custom type)",
)
@click.option("--limit", default=20, help="Maximum samples to display")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def list_samples(
    project: str | None,
    sample_type: str | None,
    limit: int,
    curl: bool,
):
    """List samples for a project.

    \b
    Examples:
      iflow samples list
      iflow samples list --sample-type germline
    """
    project_id = require_project(project)

    if curl:
        params: dict = {"limit": str(limit)}
        if sample_type:
            params["sample_type"] = sample_type
        print(miner_curl("GET", "/samples", project_id, params=params))
        return

    async def _list():
        client = MinerAPIClient()
        try:
            samples_list = await client.list_samples(
                project_id=project_id,
                sample_type=sample_type,
                limit=limit,
            )

            if not samples_list:
                click.echo("No samples found.")
                return

            click.echo(
                f"{'SAMPLE_ID':<25} {'TYPE':<15} {'SUBJECT_ID':<25}"
            )
            click.echo("-" * 65)

            for s in samples_list:
                click.echo(
                    f"{s.display_id:<25} {s.sample_type:<15} {s.subject_id:<25}"
                )

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_list())


# Model column keys that get promoted to top-level API fields
SAMPLE_MODEL_FIELDS = {
    "sample_type", "external_id", "barcode",
    "tissue", "collection_date", "notes",
}


def _parse_properties(properties: tuple[str, ...], model_fields: set[str]) -> tuple[dict, dict]:
    """Split --property key=value pairs into model fields and JSONB properties."""
    data: dict = {}
    props: dict = {}
    for kv in properties:
        if "=" not in kv:
            raise click.BadParameter(
                f"Invalid format: '{kv}'. Use key=value",
                param_hint="--property",
            )
        k, v = kv.split("=", 1)
        if k in model_fields:
            data[k] = v
        else:
            props[k] = v
    return data, props


@samples.command("create")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.option("--subject-id", help="Parent subject ID (display_id or slug)")
@click.option("--subject-uuid", help="Parent subject UUID (bypasses display_id resolution)")
@click.option("-n", "--sample-id", help="Sample ID (auto-generated if not provided)")
@click.option(
    "-P", "--property", "properties", multiple=True,
    help="Property key=value (repeatable). Model keys: sample_type, "
    "external_id, barcode, tissue, collection_date (YYYY-MM-DD), notes",
)
@click.option("--tag", "-t", multiple=True, help="Tag for the sample")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def create_sample(
    project: str | None,
    subject_id: str | None,
    subject_uuid: str | None,
    sample_id: str | None,
    properties: tuple[str, ...],
    tag: tuple[str, ...],
    curl: bool,
):
    """Create a new sample linked to a subject.

    \b
    --subject-id accepts display_id, slug, or UUID (e.g., "Patient_Smith").
    --subject-uuid accepts only UUID (bypasses display_id resolution).
    --sample-id (-n) is optional (auto-generated as SMPL-N if not provided).
    All other fields are passed via --property/-P key=value:
      iflow samples create --subject-id Patient_Smith -n "NA12878" -P sample_type=germline
      iflow samples create --subject-uuid <UUID> -P sample_type=somatic

    \b
    Known model keys (stored as columns): sample_type, external_id,
    barcode, tissue, collection_date (YYYY-MM-DD), notes
    All dates use YYYY-MM-DD format (e.g., 2026-01-15).
    Other keys are stored in properties JSONB: specimen_id, specimen_type, sequencing_date, etc.
    """
    if subject_uuid and subject_id:
        raise click.UsageError("Cannot use both --subject-id and --subject-uuid")
    effective_subject = subject_uuid or subject_id
    if not effective_subject:
        raise click.UsageError("Either --subject-id or --subject-uuid is required")

    project_id = require_project(project)

    model_data, props = _parse_properties(properties, SAMPLE_MODEL_FIELDS)
    data: dict = {"subject_id": effective_subject, **model_data}
    if sample_id:
        data["sample_id"] = sample_id
    if tag:
        data["tags"] = list(tag)
    if props:
        data["properties"] = props

    if curl:
        print(miner_curl("POST", "/samples", project_id, data=data))
        return

    async def _create():
        client = MinerAPIClient()
        try:
            sample = await client.create_sample(
                project_id=project_id,
                subject_id=effective_subject,
                display_id=sample_id,
                sample_type=model_data.get("sample_type", "unknown"),
                external_id=model_data.get("external_id"),
                barcode=model_data.get("barcode"),
                tissue=model_data.get("tissue"),
                notes=model_data.get("notes"),
                tags=list(tag) if tag else None,
                properties=props or None,
            )

            click.echo("Sample created successfully!")
            click.echo(f"  Sample ID: {sample.display_id}")
            click.echo(f"  Type: {sample.sample_type}")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_create())


@samples.command("get")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.argument("sample_id")
@click.option("--uuid", "use_uuid", is_flag=True, help="Treat identifier as UUID")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def get_sample(project: str | None, sample_id: str, use_uuid: bool, curl: bool):
    """Get details of a sample.

    SAMPLE_ID is the sample identifier (display_id, slug, or UUID).
    Use --uuid to force UUID lookup.
    """
    project_id = require_project(project)
    lookup = "uuid" if use_uuid else None

    if curl:
        suffix = "?lookup=uuid" if use_uuid else ""
        print(miner_curl("GET", f"/samples/{sample_id}{suffix}", project_id))
        return

    async def _get():
        client = MinerAPIClient()
        try:
            sample = await client.get_sample(project_id, sample_id, lookup=lookup)

            click.echo(f"Sample: {sample.display_id}")
            click.echo(f"  Sample ID: {sample.display_id}")
            click.echo(f"  Subject ID: {sample.subject_id}")
            click.echo(f"  Type: {sample.sample_type}")

            if sample.external_id:
                click.echo(f"  External ID: {sample.external_id}")
            if sample.barcode:
                click.echo(f"  Barcode: {sample.barcode}")
            if sample.tissue:
                click.echo(f"  Tissue: {sample.tissue}")
            if sample.notes:
                click.echo(f"  Notes: {sample.notes}")
            if sample.created_at:
                click.echo(f"  Created: {sample.created_at}")
            if sample.tags:
                click.echo(f"  Tags: {', '.join(sample.tags)}")
            if sample.properties:
                click.echo("  Properties:")
                for k, v in sample.properties.items():
                    click.echo(f"    {k}: {v}")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_get())


@samples.command("delete")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.argument("sample_id")
@click.option("--uuid", "use_uuid", is_flag=True, help="Treat identifier as UUID")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
@click.confirmation_option(prompt="Are you sure you want to delete this sample?")
def delete_sample(project: str | None, sample_id: str, use_uuid: bool, curl: bool):
    """Delete a sample.

    SAMPLE_ID is the sample identifier (display_id, slug, or UUID).
    Use --uuid to force UUID lookup.
    """
    project_id = require_project(project)
    lookup = "uuid" if use_uuid else None

    if curl:
        suffix = "?lookup=uuid" if use_uuid else ""
        print(miner_curl("DELETE", f"/samples/{sample_id}{suffix}", project_id))
        return

    async def _delete():
        client = MinerAPIClient()
        try:
            await client.delete_sample(project_id, sample_id, lookup=lookup)
            click.echo(f"Sample {sample_id} deleted.")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_delete())


@samples.command("sampleinfo")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.argument("sample_id")
@click.option("--order-id", help="Order ID for additional context")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def get_sampleinfo(project: str | None, sample_id: str, order_id: str | None, curl: bool):
    """Generate sampleinfo JSON for pipeline submission.

    \b
    Returns flat dict of pipeline optional_inputs from subject + sample metadata.
    Output can be piped into iflow runs submit --input-json.

    \b
    Examples:
      iflow samples sampleinfo SAMPLE_ID
      iflow samples sampleinfo SAMPLE_ID --order-id ORDER_ID
      iflow runs submit --pipeline hereditary-mock \\
        --input-json "$(iflow samples sampleinfo SAMPLE_ID)"
    """
    project_id = require_project(project)

    if curl:
        params = {}
        if order_id:
            params["order_id"] = order_id
        print(miner_curl("GET", f"/samples/{sample_id}/sampleinfo", project_id, params=params))
        return

    async def _sampleinfo():
        client = MinerAPIClient()
        try:
            data = await client.get_sampleinfo(project_id, sample_id, order_id=order_id)
            click.echo(json.dumps(data, indent=2))
        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_sampleinfo())
