"""iseq-flow - CLI tool for IntelliSeq Flow cloud file management."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("intelliseq-iflow")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"
