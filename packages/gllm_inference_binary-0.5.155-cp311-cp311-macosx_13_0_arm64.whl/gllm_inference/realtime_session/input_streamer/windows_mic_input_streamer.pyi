from _typeshed import Incomplete
from gllm_inference.realtime_session.constants import InputAudioConfig as InputAudioConfig
from gllm_inference.realtime_session.input_streamer.input_streamer import BaseInputStreamer as BaseInputStreamer
from gllm_inference.realtime_session.schema import RealtimeEvent as RealtimeEvent

PCM_16_MAX: Incomplete

class WindowsMicInputStreamer(BaseInputStreamer):
    """[BETA] A Windows microphone input streamer that reads the input audio from the microphone.

    Attributes:
        state (RealtimeState): The state of the input streamer.
        stream (InputStream): The sounddevice input stream.
        input_queue (asyncio.Queue[RealtimeEvent]): The queue to put the input events.
    """
    stream: Incomplete
    def __init__(self) -> None:
        """Initializes the WindowsMicInputStreamer.

        Raises:
            OSError: If the current system is not Windows.
        """
    async def stream_input(self) -> None:
        """Streams the input audio from the Windows system microphone.

        This method is used to stream the recorded input audio from the Windows system microphone to the input queue.
        """
    async def close(self) -> None:
        """Closes the WindowsMicInputStreamer.

        This method is used to close the WindowsMicInputStreamer.
        It is used to clean up the recording process.
        """
