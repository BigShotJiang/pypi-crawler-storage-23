from _typeshed import Incomplete
from gllm_inference.realtime_session.constants import InputAudioConfig as InputAudioConfig
from gllm_inference.realtime_session.input_streamer.input_streamer import BaseInputStreamer as BaseInputStreamer
from gllm_inference.realtime_session.schema import RealtimeDataType as RealtimeDataType, RealtimeEvent as RealtimeEvent

AUDIO_FORMAT: str
AUDIO_LAYOUT: str
STREAMING_BUFFER_FACTOR: float

class FileInputStreamer(BaseInputStreamer):
    """[BETA] An input streamer that reads input text or audio from a file.

    Attributes:
        file_path (str): The path to the input file.
        silence_duration (float): The duration of silence padding for audio input in seconds. Defaults to 5.
    """
    file_path: Incomplete
    silence_duration: Incomplete
    def __init__(self, file_path: str, silence_duration: float = 5.0) -> None:
        """Initializes a new instance of the FileInputStreamer class.

        Args:
            file_path (str): The path to the input file.
            silence_duration (float, optional): The duration of silence padding for audio input in seconds.
                Defaults to 5.

        Raises:
            FileNotFoundError: If the specified file does not exist.
        """
    async def stream_input(self) -> None:
        """Streams the input text or audio from a file.

        This method is used to read the file and push its contents into the input queue.
        For text files, it reads the entire file at once. For audio files, it streams PCM chunks.

        Raises:
            AttributeError: If input streamer is not initialized.
            RuntimeError: If the file streaming fails.
        """
