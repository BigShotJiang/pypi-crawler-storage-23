from gllm_inference.lm_invoker.build_lm_invoker import BaseLMInvoker, PROVIDER_TO_LM_INVOKER_MAP as PROVIDER_TO_LM_INVOKER_MAP
from gllm_inference.schema import ModelId
from typing import Any

__all__ = ['PROVIDER_TO_LM_INVOKER_MAP', 'build_lm_invoker']

def build_lm_invoker(model_id: str | ModelId, credentials: str | dict[str, Any] | None = None, config: dict[str, Any] | None = None) -> BaseLMInvoker:
    """Deprecated function to build a language model invoker.

    This function is deprecated and will be removed in v0.6.0. Use
    `from gllm_inference.lm_invoker.build_lm_invoker` instead.

    Args:
        model_id (str | ModelId): The model id.
        credentials (str | dict[str, Any] | None, optional): The credentials.
        config (dict[str, Any] | None, optional): Additional configuration.

    Returns:
        BaseLMInvoker: The initialized language model invoker.
    """
