from pydantic import BaseModel
from typing import Any

class Skill(BaseModel):
    """Represents a skill in the language model provider.

    Attributes:
        id (str): Unique identifier for the skill returned by the API.
        name (str | None): Display name of the skill provided by the user. Defaults to None.
        provider (str): Provider of the skill.
        skill_type (str): Type of the skill.
        version (str | None): Version of the skill. Defaults to None.
        metadata (dict[str, Any]): Metadata for the skill. Defaults to empty dict.
    """
    id: str
    name: str | None
    provider: str
    skill_type: str
    version: str | None
    metadata: dict[str, Any]
