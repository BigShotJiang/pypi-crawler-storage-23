ELLIPSIS: str
ASTERISK: str

def truncate_text(value: str, max_length: int) -> str: ...
def redact_url(url: str, max_length: int = 50) -> str:
    """Redact sensitive information from URL for safe logging.

    Removes userinfo (username:password) and replaces query parameters and fragments
    with placeholder markers to prevent exposure of API keys, tokens, and other
    sensitive data in logs.

    Args:
        url (str): The URL to redact.
        max_length (int, optional): Maximum length of returned string. Defaults to 50.

    Returns:
        str: Redacted URL safe for logging:
            1. For valid URL: scheme://host[:port]/path[?***][#***]
            2. For invalid URLs: truncated string.

    """
