from gllm_inference.schema.credentials import OAuthCredentials as OAuthCredentials
from gllm_inference.schema.enums import NativeToolType as NativeToolType
from gllm_inference.schema.skill import Skill as Skill
from gllm_inference.utils.validation import validate_enum as validate_enum
from pydantic import BaseModel
from typing import Any, Awaitable, Callable

class Key:
    """Defines valid keys in native tool."""
    ALLOWED_TOOLS: str
    AUTH: str
    CONNECTOR_ID: str
    EXTRA_PARAMS: str
    NAME: str
    SKILL_ID: str
    TYPE: str
    URL: str
    VERSION: str

class NativeTool(BaseModel):
    """Defines the native tool schema.

    Attributes:
        type (NativeToolType): The type of the native tool.
        kwargs (dict[str, Any]): The additional keyword arguments of the native tool.
    """
    type: NativeToolType
    kwargs: dict[str, Any]
    @classmethod
    def code_interpreter(cls, **kwargs: Any) -> NativeTool:
        """Create a code interpreter native tool.

        Args:
            **kwargs (Any): Additional configuration for the code interpreter native tool.

        Returns:
            NativeTool: A new code interpreter native tool.
        """
    @classmethod
    def web_search(cls, **kwargs: Any) -> NativeTool:
        """Create a web search native tool.

        Args:
            **kwargs (Any): Additional configuration for the web search native tool.

        Returns:
            NativeTool: A new web search native tool.
        """
    @classmethod
    def mcp_server(cls, url: str, name: str, allowed_tools: list[str] | None = None, **kwargs: Any) -> NativeTool:
        """Create a MCP server native tool.

        Args:
            url (str): The URL of the MCP server.
            name (str): The name of the MCP server.
            allowed_tools (list[str] | None, optional): The allowed tools of the MCP server. Defaults to None.
            **kwargs (Any): Additional configuration for the MCP server native tool.

        Returns:
            NativeTool: A new MCP server native tool.
        """
    @classmethod
    def mcp_connector(cls, connector_id: str, name: str, auth: str | OAuthCredentials | Callable[[], Awaitable[str]] | None = None, **kwargs: Any) -> NativeTool:
        """Create a MCP connector native tool.

        Args:
            connector_id (str): The ID of the MCP connector.
            name (str): The name of the MCP connector.
            auth (str | OAuthCredentials | Callable[[], Awaitable[str]] | None, optional): The authentication
                for the MCP connector. Supports the following types:
                1. str: A static access token.
                2. OAuthCredentials: An OAuth credentials object.
                3. Callable[[], Awaitable[str]]: An asynchronous function that returns the access token.
                Defaults to None.
            **kwargs (Any): Additional configuration for the MCP connector native tool.

        Returns:
            NativeTool: A new MCP connector native tool.
        """
    @classmethod
    def skill(cls, skill: Skill | None = None, *, skill_id: str | None = None, type_: str | None = None, version: str | None = None, **kwargs: Any) -> NativeTool:
        """Create a skill native tool.

        Args:
            skill (Skill | None): A Skill object. If provided, extracts skill_id, type_, and version from it.
            skill_id (str | None): The skill identifier. Required if skill is not provided.
            type_ (str | None): Skill type. Required if skill is not provided.
            version (str | None, optional): Optional specific version to use. Defaults to None.
            **kwargs (Any): Additional provider-specific parameters.

        Returns:
            NativeTool: A skill native tool instance.

        Raises:
            ValueError: If neither skill nor both skill_id and type_ are provided.
        """
    @classmethod
    def from_str_or_dict(cls, data: str | dict[str, Any]) -> NativeTool:
        """Create a native tool from a string or a dictionary.

        Args:
            data (str | dict[str, Any]): The string or dictionary that represents the native tool.

        Returns:
            NativeTool: A new native tool.
        """
