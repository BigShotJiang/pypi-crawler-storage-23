from abc import ABC, abstractmethod
from gllm_inference.schema.message import Message as Message

class BaseInputTransformer(ABC):
    """A base class for input transformers used in Gen AI applications.

    The `BaseInputTransformer` class defines the interface for transforming the input (messages) of language models.
    Subclasses must implement the `transform` method.
    """
    def __init__(self) -> None:
        """Initializes a new instance of the BaseInputTransformer class."""
    @abstractmethod
    def transform(self, messages: list[Message]) -> list[Message]:
        """Transforms the input messages for a language model.

        This abstract method must be implemented by subclasses to
        define the logic for transforming the input messages.

        Args:
            messages (list[Message]): The input messages for the language model.

        Returns:
            list[Message]: The transformed input messages for the language model.

        Raises:
            NotImplementedError: If the method is not implemented in a subclass.
        """
