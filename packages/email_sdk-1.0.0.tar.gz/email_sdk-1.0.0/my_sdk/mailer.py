import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders

PROVIDERS = {
    "gmail":   {"host": "smtp.gmail.com",      "port": 587},
}

class Mailer:
    def __init__(self, email: str, password: str, provider: str = "gmail"):
        self.email    = email
        self.password = password
        cfg           = PROVIDERS.get(provider, PROVIDERS["gmail"])
        self.host     = cfg["host"]
        self.port     = cfg["port"]
        self._conn    = None

    #  Connection
    def connect(self):
        self._conn = smtplib.SMTP(self.host, self.port)
        self._conn.ehlo()
        self._conn.starttls()
        self._conn.login(self.email, self.password)
        print(f" Connected: {self.host}")
        return self

    def disconnect(self):
        if self._conn:
            self._conn.quit()
            self._conn = None
            print(" Disconnected.")

    #  Core Send
    def send(self, to, subject: str, body: str,
             html=False, cc=None, bcc=None, attachments=None) -> dict:
        try:
            msg            = MIMEMultipart()
            msg["From"]    = self.email
            msg["To"]      = ", ".join(to) if isinstance(to, list) else to
            msg["Subject"] = subject
            if cc:  msg["Cc"]  = ", ".join(cc)
            if bcc: msg["Bcc"] = ", ".join(bcc)

            msg.attach(MIMEText(body, "html" if html else "plain"))

            for path in (attachments or []):
                with open(path, "rb") as f:
                    part = MIMEBase("application", "octet-stream")
                    part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header("Content-Disposition", f"attachment; filename={path.split('/')[-1]}")
                msg.attach(part)

            recipients = (to if isinstance(to, list) else [to]) + (cc or []) + (bcc or [])
            self._conn.sendmail(self.email, recipients, msg.as_string())
            print(f"Sent → {recipients}")
            return {"success": True, "to": recipients}

        except Exception as e:
            print(f" Failed: {e}")
            return {"success": False, "error": str(e)}

    # Helpers
    def send_html(self, to, subject: str, body: str) -> dict:
        """Send an HTML email."""
        return self.send(to, subject, body, html=True)

    def send_bulk(self, recipients: list, subject: str, body: str, html=False) -> dict:
        """Send individually to each recipient."""
        results = [{"to": r, **self.send(r, subject, body, html=html)} for r in recipients]
        sent    = sum(1 for r in results if r["success"])
        print(f"Bulk: {sent}/{len(recipients)} sent")
        return {"sent": sent, "total": len(recipients), "details": results}

    def send_template(self, to, subject: str, template: str, context: dict) -> dict:
        """Fill {{key}} placeholders and send as HTML."""
        body = template
        for key, val in context.items():
            body = body.replace(f"{{{{{key}}}}}", str(val))
        return self.send_html(to, subject, body)

    # Context Manager
    def __enter__(self):
        return self.connect()

    def __exit__(self, *args):
        self.disconnect()
