# My Foo SDK
The most minimal SDK you'll ever find.

## Installation
```bash
pip install myfoo-sdk