# Youtube Autonomous Main Editor Nodes CPU module

The main Editor module related to nodes handled with CPU.