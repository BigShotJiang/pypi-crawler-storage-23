from saboteur.domain.base.strategies import BaseStrategy
from saboteur.domain.mutation.contexts import MutationContext


class MutationStrategy(BaseStrategy[MutationContext]): ...
