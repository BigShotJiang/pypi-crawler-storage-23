from saboteur.domain.base.results import BaseResult


class MutationResult(BaseResult): ...
