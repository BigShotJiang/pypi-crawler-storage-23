"""
Test suite for Team Memory — SharedPool with RBAC, conflict resolution, and cross-agent recall.

Tests cover:
- Agent registration with different roles
- Role-based access control (READER, WRITER, COORDINATOR)
- Write permissions enforcement
- Read permissions for all registered agents
- Cross-agent recall with permission checks
- Conflict resolution (trust score, timestamp, coordinator override)
- Trust score updates and clamping
- Pool state persistence across instances
- Concurrent access simulation
- BM25 search vs recent entries
- Pool isolation (different pool names don't share data)
- Unregistered agent restrictions
"""

import json
import os
import tempfile
import shutil
import time
from unittest import TestCase

from antaris_memory.team_memory import SharedPool, AgentRole, AgentConfig
from antaris_memory.entry import MemoryEntry


class TestTeamMemory(TestCase):
    """Test suite for SharedPool team memory system."""
    
    def setUp(self):
        """Create temporary workspace for each test."""
        self.temp_dir = tempfile.mkdtemp()
        self.workspace = self.temp_dir
        self.pool_name = "test-pool"
        self.pool = SharedPool(self.workspace, self.pool_name)
        
        # Create test agents
        self.reader_config = AgentConfig("reader_agent", AgentRole.READER, 0.5)
        self.writer_config = AgentConfig("writer_agent", AgentRole.WRITER, 0.8)
        self.coordinator_config = AgentConfig("coordinator_agent", AgentRole.COORDINATOR, 1.0)
    
    def tearDown(self):
        """Clean up temporary workspace."""
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_01_register_agent_reader(self):
        """Test registering an agent with READER role."""
        self.pool.register_agent(self.reader_config)
        
        config = self.pool.get_agent_config("reader_agent")
        self.assertIsNotNone(config)
        self.assertEqual(config.role, AgentRole.READER)
        self.assertEqual(config.trust_score, 0.5)
    
    def test_02_register_agent_writer(self):
        """Test registering an agent with WRITER role."""
        self.pool.register_agent(self.writer_config)
        
        config = self.pool.get_agent_config("writer_agent")
        self.assertIsNotNone(config)
        self.assertEqual(config.role, AgentRole.WRITER)
        self.assertEqual(config.trust_score, 0.8)
    
    def test_03_register_agent_coordinator(self):
        """Test registering an agent with COORDINATOR role."""
        self.pool.register_agent(self.coordinator_config)
        
        config = self.pool.get_agent_config("coordinator_agent")
        self.assertIsNotNone(config)
        self.assertEqual(config.role, AgentRole.COORDINATOR)
        self.assertEqual(config.trust_score, 1.0)
    
    def test_04_reader_cannot_write(self):
        """Test that READER agents cannot write (returns None)."""
        self.pool.register_agent(self.reader_config)
        
        result = self.pool.write("reader_agent", "Test content")
        self.assertIsNone(result)
        
        # Verify no entries were created
        entries = self.pool.read("reader_agent")
        self.assertEqual(len(entries), 0)
    
    def test_05_writer_can_write(self):
        """Test that WRITER agents can write."""
        self.pool.register_agent(self.writer_config)
        
        entry_id = self.pool.write("writer_agent", "Test content from writer")
        self.assertIsNotNone(entry_id)
        
        # Verify entry was created
        entries = self.pool.read("writer_agent")
        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0].content, "Test content from writer")
    
    def test_06_coordinator_can_write(self):
        """Test that COORDINATOR agents can write."""
        self.pool.register_agent(self.coordinator_config)
        
        entry_id = self.pool.write("coordinator_agent", "Test content from coordinator")
        self.assertIsNotNone(entry_id)
        
        # Verify entry was created
        entries = self.pool.read("coordinator_agent")
        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0].content, "Test content from coordinator")
    
    def test_07_all_agents_can_read(self):
        """Test that all registered agents can read regardless of role."""
        # Register all agent types
        self.pool.register_agent(self.reader_config)
        self.pool.register_agent(self.writer_config)
        self.pool.register_agent(self.coordinator_config)
        
        # Writer creates content
        self.pool.write("writer_agent", "Shared knowledge")
        
        # All agents should be able to read
        reader_entries = self.pool.read("reader_agent")
        writer_entries = self.pool.read("writer_agent") 
        coordinator_entries = self.pool.read("coordinator_agent")
        
        self.assertEqual(len(reader_entries), 1)
        self.assertEqual(len(writer_entries), 1)
        self.assertEqual(len(coordinator_entries), 1)
        
        # Content should be the same for all
        self.assertEqual(reader_entries[0].content, "Shared knowledge")
        self.assertEqual(writer_entries[0].content, "Shared knowledge")
        self.assertEqual(coordinator_entries[0].content, "Shared knowledge")
    
    def test_08_cross_agent_recall_requires_coordinator(self):
        """Test that cross_agent_recall requires COORDINATOR role."""
        self.pool.register_agent(self.writer_config)
        self.pool.register_agent(self.coordinator_config)
        
        # WRITER tries cross_agent_recall - should fail
        results = self.pool.cross_agent_recall("writer_agent", "target_agent", self.workspace, "test query")
        self.assertEqual(len(results), 0)
        
        # COORDINATOR tries cross_agent_recall - should work (even if no results)
        results = self.pool.cross_agent_recall("coordinator_agent", "target_agent", self.workspace, "test query")
        self.assertIsInstance(results, list)  # Should return list, even if empty
    
    def test_09_conflict_resolution_higher_trust_wins(self):
        """Test conflict resolution: higher trust score wins."""
        # Register agents with different trust scores
        low_trust = AgentConfig("low_trust", AgentRole.WRITER, 0.3)
        high_trust = AgentConfig("high_trust", AgentRole.WRITER, 0.9)
        
        self.pool.register_agent(low_trust)
        self.pool.register_agent(high_trust)
        
        # Create identical content (same hash)
        content = "Identical content for conflict"
        
        # Low trust writes first
        entry1 = MemoryEntry(content, agent_id="low_trust")
        # High trust writes second
        entry2 = MemoryEntry(content, agent_id="high_trust")
        
        # Resolve conflict - high trust should win
        resolved = self.pool.resolve_conflict(entry1.hash, entry2, entry1)
        self.assertEqual(resolved.agent_id, "high_trust")
    
    def test_10_conflict_resolution_equal_trust_newer_wins(self):
        """Test conflict resolution: equal trust, newer timestamp wins."""
        # Register agents with equal trust
        agent1 = AgentConfig("agent1", AgentRole.WRITER, 0.7)
        agent2 = AgentConfig("agent2", AgentRole.WRITER, 0.7)
        
        self.pool.register_agent(agent1)
        self.pool.register_agent(agent2)
        
        content = "Identical content for timestamp test"
        
        # Create entries with different timestamps
        time.sleep(0.01)  # Ensure different timestamps
        entry1 = MemoryEntry(content, agent_id="agent1")
        time.sleep(0.01)
        entry2 = MemoryEntry(content, agent_id="agent2")
        
        # Newer entry should win
        resolved = self.pool.resolve_conflict(entry1.hash, entry2, entry1)
        self.assertEqual(resolved.agent_id, "agent2")
    
    def test_11_coordinator_writes_always_win(self):
        """Test that coordinator writes always win regardless of trust."""
        # Register coordinator with lower trust than writer
        low_trust_coordinator = AgentConfig("coordinator", AgentRole.COORDINATOR, 0.1)
        high_trust_writer = AgentConfig("writer", AgentRole.WRITER, 0.9)
        
        self.pool.register_agent(low_trust_coordinator)
        self.pool.register_agent(high_trust_writer)
        
        content = "Coordinator override test"
        
        entry_writer = MemoryEntry(content, agent_id="writer")
        entry_coordinator = MemoryEntry(content, agent_id="coordinator")
        
        # Coordinator should win despite lower trust
        resolved = self.pool.resolve_conflict(entry_writer.hash, entry_coordinator, entry_writer)
        self.assertEqual(resolved.agent_id, "coordinator")
    
    def test_12_update_trust_only_works_for_coordinators(self):
        """Test that update_trust only works for COORDINATOR agents."""
        self.pool.register_agent(self.writer_config)
        self.pool.register_agent(self.coordinator_config)
        
        # Writer tries to update trust - should fail
        result = self.pool.update_trust("writer_agent", "writer_agent", 0.1)
        self.assertFalse(result)
        
        # Coordinator tries to update trust - should work
        result = self.pool.update_trust("coordinator_agent", "writer_agent", 0.1)
        self.assertTrue(result)
        
        # Verify trust was updated
        config = self.pool.get_agent_config("writer_agent")
        self.assertEqual(config.trust_score, 0.9)  # 0.8 + 0.1
    
    def test_13_update_trust_clamps_to_range(self):
        """Test that update_trust clamps values to [0.0, 1.0]."""
        self.pool.register_agent(self.coordinator_config)
        self.pool.register_agent(self.writer_config)  # trust_score = 0.8
        
        # Try to increase above 1.0
        result = self.pool.update_trust("coordinator_agent", "writer_agent", 0.5)
        self.assertTrue(result)
        
        config = self.pool.get_agent_config("writer_agent")
        self.assertEqual(config.trust_score, 1.0)  # Clamped to 1.0
        
        # Try to decrease below 0.0
        result = self.pool.update_trust("coordinator_agent", "writer_agent", -2.0)
        self.assertTrue(result)
        
        config = self.pool.get_agent_config("writer_agent")
        self.assertEqual(config.trust_score, 0.0)  # Clamped to 0.0
    
    def test_14_pool_state_persists_across_instances(self):
        """Test that pool state persists when SharedPool is recreated."""
        # Register agent and write content
        self.pool.register_agent(self.writer_config)
        entry_id = self.pool.write("writer_agent", "Persistent content")
        self.assertIsNotNone(entry_id)
        
        # Create new pool instance for same workspace/name
        new_pool = SharedPool(self.workspace, self.pool_name)
        
        # Agent config should persist
        config = new_pool.get_agent_config("writer_agent")
        self.assertIsNotNone(config)
        self.assertEqual(config.role, AgentRole.WRITER)
        self.assertEqual(config.trust_score, 0.8)
        
        # Content should persist
        entries = new_pool.read("writer_agent")
        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0].content, "Persistent content")
    
    def test_15_concurrent_writes_simulation(self):
        """Test multiple agents writing concurrently (simulated with 2 instances)."""
        # Register writers
        self.pool.register_agent(self.writer_config)
        writer2_config = AgentConfig("writer2", AgentRole.WRITER, 0.6)
        self.pool.register_agent(writer2_config)
        
        # Create second pool instance to simulate concurrency
        pool2 = SharedPool(self.workspace, self.pool_name)
        
        # Both instances write content
        entry1 = self.pool.write("writer_agent", "Content from pool 1")
        entry2 = pool2.write("writer2", "Content from pool 2")
        
        self.assertIsNotNone(entry1)
        self.assertIsNotNone(entry2)
        
        # Both entries should be readable from either instance
        entries1 = self.pool.read("writer_agent")
        entries2 = pool2.read("writer2")
        
        self.assertEqual(len(entries1), 2)
        self.assertEqual(len(entries2), 2)
    
    def test_16_read_without_query_returns_recent_entries(self):
        """Test that read(query=None) returns recent entries (no search)."""
        self.pool.register_agent(self.writer_config)
        
        # Write entries with different timestamps
        self.pool.write("writer_agent", "First entry")
        time.sleep(0.01)
        self.pool.write("writer_agent", "Second entry")
        time.sleep(0.01) 
        self.pool.write("writer_agent", "Third entry")
        
        # Read without query should return in reverse chronological order
        entries = self.pool.read("writer_agent", query=None, limit=2)
        self.assertEqual(len(entries), 2)
        # Most recent should be first
        self.assertEqual(entries[0].content, "Third entry")
        self.assertEqual(entries[1].content, "Second entry")
    
    def test_17_read_with_query_returns_bm25_searched_entries(self):
        """Test that read(query="X") returns BM25-searched entries."""
        self.pool.register_agent(self.writer_config)
        
        # Write entries with different content
        self.pool.write("writer_agent", "Python programming language")
        self.pool.write("writer_agent", "Java programming tutorial")
        self.pool.write("writer_agent", "Database design patterns")
        
        # Search for programming-related content
        entries = self.pool.read("writer_agent", query="programming")
        self.assertEqual(len(entries), 2)
        
        # Should contain the programming-related entries
        contents = [entry.content for entry in entries]
        self.assertIn("Python programming language", contents)
        self.assertIn("Java programming tutorial", contents)
        self.assertNotIn("Database design patterns", contents)
    
    def test_18_get_stats_returns_correct_counts(self):
        """Test that get_stats() returns correct pool statistics."""
        # Initially empty
        stats = self.pool.get_stats()
        self.assertEqual(stats["entry_count"], 0)
        self.assertEqual(stats["agent_count"], 0)
        
        # Register agents and write content
        self.pool.register_agent(self.writer_config)
        self.pool.register_agent(self.reader_config)
        
        self.pool.write("writer_agent", "First entry")
        self.pool.write("writer_agent", "Second entry")
        
        # Check updated stats
        stats = self.pool.get_stats()
        self.assertEqual(stats["pool_name"], "test-pool")
        self.assertEqual(stats["entry_count"], 2)
        self.assertEqual(stats["agent_count"], 2)
        self.assertIn("writer_agent", stats["agents"])
        self.assertIn("reader_agent", stats["agents"])
        self.assertEqual(stats["agents"]["writer_agent"]["role"], "writer")
        self.assertEqual(stats["agents"]["reader_agent"]["role"], "reader")
    
    def test_19_unregistered_agent_cannot_write(self):
        """Test that unregistered agents cannot write."""
        result = self.pool.write("unregistered_agent", "Should not work")
        self.assertIsNone(result)
        
        # Verify no entries were created
        # Note: unregistered agent also can't read, so we use a registered one
        self.pool.register_agent(self.reader_config)
        entries = self.pool.read("reader_agent")
        self.assertEqual(len(entries), 0)
    
    def test_20_unregistered_agent_cannot_read(self):
        """Test that unregistered agents cannot read (returns empty)."""
        # Create some content first
        self.pool.register_agent(self.writer_config)
        self.pool.write("writer_agent", "Secret content")
        
        # Unregistered agent tries to read
        entries = self.pool.read("unregistered_agent")
        self.assertEqual(len(entries), 0)
    
    def test_21_pool_name_isolation(self):
        """Test that two pools with different names don't share entries."""
        pool1 = SharedPool(self.workspace, "pool1")
        pool2 = SharedPool(self.workspace, "pool2")
        
        # Register same agent in both pools
        pool1.register_agent(self.writer_config)
        pool2.register_agent(self.writer_config)
        
        # Write different content to each pool
        pool1.write("writer_agent", "Content in pool1")
        pool2.write("writer_agent", "Content in pool2")
        
        # Each pool should only see its own content
        entries1 = pool1.read("writer_agent")
        entries2 = pool2.read("writer_agent")
        
        self.assertEqual(len(entries1), 1)
        self.assertEqual(len(entries2), 1)
        self.assertEqual(entries1[0].content, "Content in pool1")
        self.assertEqual(entries2[0].content, "Content in pool2")
    
    def test_22_cross_agent_recall_with_writer_returns_empty(self):
        """Test that cross_agent_recall with WRITER role returns empty (permission denied)."""
        self.pool.register_agent(self.writer_config)
        
        results = self.pool.cross_agent_recall("writer_agent", "target", self.workspace, "query")
        self.assertEqual(len(results), 0)
    
    def test_23_metadata_handling_in_write(self):
        """Test that metadata parameter in write() is handled correctly."""
        self.pool.register_agent(self.writer_config)
        
        metadata = {
            "importance": 0.9,
            "category": "strategic",
            "tags": ["important", "decision"]
        }
        
        entry_id = self.pool.write("writer_agent", "Important decision", metadata)
        self.assertIsNotNone(entry_id)
        
        entries = self.pool.read("writer_agent")
        self.assertEqual(len(entries), 1)
        
        entry = entries[0]
        self.assertEqual(entry.importance, 0.9)
        self.assertEqual(entry.category, "strategic")
        self.assertEqual(entry.tags, ["important", "decision"])
    
    def test_24_trust_score_clamping_on_registration(self):
        """Test that trust scores are clamped to [0,1] during registration."""
        # Test negative trust score
        negative_config = AgentConfig("negative", AgentRole.WRITER, -0.5)
        self.pool.register_agent(negative_config)
        
        config = self.pool.get_agent_config("negative")
        self.assertEqual(config.trust_score, 0.0)
        
        # Test trust score > 1.0
        high_config = AgentConfig("high", AgentRole.WRITER, 1.5)
        self.pool.register_agent(high_config)
        
        config = self.pool.get_agent_config("high")
        self.assertEqual(config.trust_score, 1.0)
    
    def test_25_cross_agent_recall_file_scanning(self):
        """Test cross_agent_recall performs filesystem scanning for matches."""
        # Create mock target workspace with memory files
        target_workspace = os.path.join(self.temp_dir, "target_agent_workspace")
        os.makedirs(target_workspace, exist_ok=True)
        
        # Create mock memory file for target agent
        mock_entries = [
            {
                "hash": "abc123",
                "content": "Python is a programming language used for web development",
                "agent_id": "target_agent",
                "created": "2024-01-01T00:00:00",
                "source": "notes.md",
                "category": "tech"
            },
            {
                "hash": "def456", 
                "content": "Java is also used for enterprise applications",
                "agent_id": "target_agent",
                "created": "2024-01-01T01:00:00",
                "source": "notes.md",
                "category": "tech"
            }
        ]
        
        mock_file = os.path.join(target_workspace, "target_agent_memories.jsonl")
        with open(mock_file, 'w') as f:
            for entry in mock_entries:
                json.dump(entry, f)
                f.write('\n')
        
        # Register coordinator and perform cross-agent recall
        self.pool.register_agent(self.coordinator_config)
        
        results = self.pool.cross_agent_recall(
            "coordinator_agent", 
            "target_agent", 
            target_workspace, 
            "programming language"
        )
        
        # Should find the Python-related entry
        self.assertGreater(len(results), 0)
        found_contents = [entry.content for entry in results]
        self.assertTrue(
            any("Python" in content for content in found_contents)
        )
    
    def test_26_pool_directories_created_automatically(self):
        """Test that .shared_pools directory is created automatically."""
        # Use a fresh workspace
        fresh_workspace = os.path.join(self.temp_dir, "fresh")
        
        # Directory shouldn't exist initially
        shared_pools_dir = os.path.join(fresh_workspace, ".shared_pools")
        self.assertFalse(os.path.exists(shared_pools_dir))
        
        # Creating a SharedPool should create the directory
        pool = SharedPool(fresh_workspace, "auto-create-test")
        self.assertTrue(os.path.exists(shared_pools_dir))
    
    def test_27_entry_replacement_on_conflict(self):
        """Test that conflicting entries are properly replaced in storage."""
        self.pool.register_agent(self.writer_config)
        self.pool.register_agent(self.coordinator_config)
        
        # Write initial content
        content = "This content will be updated"
        entry_id1 = self.pool.write("writer_agent", content)
        self.assertIsNotNone(entry_id1)
        
        # Coordinator writes same content (same hash) - should replace
        entry_id2 = self.pool.write("coordinator_agent", content)
        self.assertIsNotNone(entry_id2)
        
        # Should still only have one entry
        entries = self.pool.read("coordinator_agent")
        self.assertEqual(len(entries), 1)
        
        # Entry should be from coordinator (due to role override)
        self.assertEqual(entries[0].agent_id, "coordinator_agent")
    
    def test_28_get_agent_config_returns_none_for_unregistered(self):
        """Test that get_agent_config returns None for unregistered agents."""
        config = self.pool.get_agent_config("non_existent_agent")
        self.assertIsNone(config)
    
    def test_29_update_trust_fails_for_nonexistent_target(self):
        """Test that update_trust returns False for non-existent target agent."""
        self.pool.register_agent(self.coordinator_config)
        
        result = self.pool.update_trust("coordinator_agent", "non_existent", 0.1)
        self.assertFalse(result)


if __name__ == '__main__':
    import unittest
    unittest.main()