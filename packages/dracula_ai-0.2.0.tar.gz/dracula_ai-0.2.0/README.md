# Dracula 🧛

A simple Python library for Google Gemini with conversation memory.

## Installation

pip install dracula-ai

## Usage

from dracula import Dracula

ai = Dracula(
    api_key="your-api-key",
    prompt="You are a helpful assistant.",
    temperature=1.0,
    max_output_tokens=1024,
    max_messages=10
)

# Chat
response = ai.chat("Hello, who are you?")
print(response)

# Change prompt anytime
ai.set_prompt("You are a pirate.")

# Change temperature anytime
ai.set_temperature(0.5)

# Save and load conversation history
ai.save_history("conversation.json")
ai.load_history("conversation.json")

# Clear memory
ai.clear_memory()