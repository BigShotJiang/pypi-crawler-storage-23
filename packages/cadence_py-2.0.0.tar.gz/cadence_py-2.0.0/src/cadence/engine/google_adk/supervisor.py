"""Google ADK supervisor orchestrator implementation.

This module implements supervisor mode using Google ADK with a single
LlmAgent that has access to all plugin tools.
"""

import logging
from typing import Any, AsyncIterator, Dict, List

from cadence_sdk.types.sdk_state import UvState

from cadence.engine.base import BaseOrchestrator, StreamEvent
from cadence.engine.google_adk.adapter import GoogleADKAdapter
from cadence.engine.google_adk.streaming import GoogleADKStreamingWrapper
from cadence.engine.modes import SupervisorMode
from cadence.infrastructure.plugins import SDKPluginManager

logger = logging.getLogger(__name__)


class GoogleADKSupervisor(BaseOrchestrator):
    """Google ADK supervisor mode orchestrator.

    In supervisor mode, a single LlmAgent has access to all plugin tools
    and decides which tools to call based on the user query.

    Attributes:
        plugin_manager: Plugin manager instance
        llm_factory: LLM model factory
        resolved_config: Resolved configuration
        adapter: Google ADK adapter
        streaming_wrapper: Streaming wrapper
        mode_config: Supervisor mode configuration
        _plugin_bundles: Dict of plugin bundles
    """

    def __init__(
        self,
        plugin_manager: SDKPluginManager,
        llm_factory: Any,
        resolved_config: Dict[str, Any],
        adapter: GoogleADKAdapter,
        streaming_wrapper: GoogleADKStreamingWrapper,
    ):
        """Initialize Google ADK supervisor orchestrator.

        Args:
            plugin_manager: Plugin manager instance
            llm_factory: LLM model factory
            resolved_config: Resolved configuration dictionary
            adapter: Google ADK adapter
            streaming_wrapper: Streaming wrapper
        """
        super().__init__(
            plugin_manager=plugin_manager,
            llm_factory=llm_factory,
            resolved_config=resolved_config,
            adapter=adapter,
            streaming_wrapper=streaming_wrapper,
        )

        self.mode_config = SupervisorMode(resolved_config.get("mode_config", {}))
        self._plugin_bundles = plugin_manager.bundles
        self._is_ready = False

        self._initialize()

    def _initialize(self) -> None:
        """Initialize orchestrator resources."""
        try:
            all_tools = []
            for bundle in self._plugin_bundles.values():
                for tool in bundle.uvtools:
                    all_tools.append(self.adapter.uvtool_to_orchestrator(tool))

            model_config = self.resolved_config.get("model_config", {})
            self.model_name = model_config.get("model_name", "gemini-1.5-pro")
            self.api_key = model_config.get("api_key", "")

            system_prompt = self._build_system_prompt()

            self.agent_config = {
                "name": "supervisor",
                "model": self.model_name,
                "instructions": system_prompt,
                "tools": all_tools,
            }

            self._is_ready = True
            logger.info("Google ADK supervisor initialized successfully")

        except Exception as e:
            logger.error(
                f"Failed to initialize Google ADK supervisor: {e}", exc_info=True
            )
            raise

    async def ask(self, state: UvState) -> UvState:
        """Execute single-shot orchestration.

        Args:
            state: Input state with messages

        Returns:
            Updated state with response
        """
        if not self._is_ready:
            raise RuntimeError("Orchestrator not ready")

        messages = state.get("messages", [])
        google_messages = [
            self.adapter.sdk_message_to_orchestrator(msg) for msg in messages
        ]

        logger.info(
            f"Processing {len(google_messages)} messages with Google ADK supervisor"
        )

        response_text = f"[Google ADK Supervisor] Processed query with {len(self._plugin_bundles)} plugins"

        from cadence_sdk.types.sdk_messages import UvAIMessage

        result_messages = messages + [UvAIMessage(content=response_text)]

        output_state = state.copy()
        output_state["messages"] = result_messages
        output_state["agent_hops"] = 1
        output_state["current_agent"] = "supervisor"

        return output_state

    async def astream(self, state: UvState) -> AsyncIterator[StreamEvent]:
        """Execute streaming orchestration.

        Args:
            state: Input state with messages

        Yields:
            StreamEvent instances
        """
        if not self._is_ready:
            raise RuntimeError("Orchestrator not ready")

        yield StreamEvent.agent_start("supervisor")

        final_state = await self.ask(state)

        last_message = final_state.get("messages", [])[-1]
        yield StreamEvent.message(last_message.content, role="assistant")

        yield StreamEvent.agent_end("supervisor")

    async def rebuild(self, config: Dict[str, Any]) -> None:
        """Hot-reload orchestrator with new configuration.

        Args:
            config: New configuration dictionary
        """
        logger.info("Rebuilding Google ADK supervisor")

        await self.cleanup()

        self.resolved_config = config
        self.mode_config = SupervisorMode(config.get("mode_config", {}))

        self._initialize()

        logger.info("Google ADK supervisor rebuilt successfully")

    async def cleanup(self) -> None:
        """Release resources and cleanup."""
        logger.info("Cleaning up Google ADK supervisor")

        await self.plugin_manager.cleanup_all()

        self.agent_config = None
        self._is_ready = False

    async def health_check(self) -> Dict[str, Any]:
        """Check orchestrator health.

        Returns:
            Health status dictionary
        """
        return {
            "framework_type": self.framework_type,
            "mode": self.mode,
            "is_ready": self._is_ready,
            "plugin_count": len(self._plugin_bundles),
            "plugins": list(self._plugin_bundles.keys()),
            "model": self.model_name,
        }

    @property
    def mode(self) -> str:
        """Get orchestration mode.

        Returns:
            Mode identifier
        """
        return "supervisor"

    @property
    def framework_type(self) -> str:
        """Get framework type.

        Returns:
            Framework type identifier
        """
        return "google_adk"

    @property
    def plugin_pids(self) -> List[str]:
        """Get list of active plugin pids.

        Returns:
            List of reverse-domain plugin identifiers
        """
        return list(self._plugin_bundles.keys())

    @property
    def is_ready(self) -> bool:
        """Check if orchestrator is ready.

        Returns:
            True if ready, False otherwise
        """
        return self._is_ready

    def _build_system_prompt(self) -> str:
        """Build system prompt for supervisor.

        Returns:
            System prompt text
        """
        prompt = (
            "You are a helpful AI assistant with access to the following tools:\n\n"
        )

        for name, bundle in self._plugin_bundles.items():
            prompt += f"Plugin: {name}\n"
            prompt += f"Description: {bundle.metadata.description}\n"
            prompt += f"Tools: {', '.join(tool.name for tool in bundle.uvtools)}\n\n"

        prompt += "Use the available tools to help answer user questions."

        return prompt
