"""Google ADK coordinator orchestrator implementation.

This module implements coordinator mode using Google ADK with a parent
agent and specialized sub-agents.
"""

import logging
from typing import Any, AsyncIterator, Dict, List

from cadence_sdk.types.sdk_state import UvState

from cadence.engine.base import BaseOrchestrator, StreamEvent
from cadence.engine.google_adk.adapter import GoogleADKAdapter
from cadence.engine.google_adk.streaming import GoogleADKStreamingWrapper
from cadence.engine.modes import CoordinatorMode
from cadence.infrastructure.plugins import SDKPluginManager

logger = logging.getLogger(__name__)


class GoogleADKCoordinator(BaseOrchestrator):
    """Google ADK coordinator mode orchestrator.

    In coordinator mode, a parent agent routes queries to specialized
    plugin sub-agents.

    Attributes:
        plugin_manager: Plugin manager instance
        llm_factory: LLM model factory
        resolved_config: Resolved configuration
        adapter: Google ADK adapter
        streaming_wrapper: Streaming wrapper
        mode_config: Coordinator mode configuration
        _plugin_bundles: Dict of plugin bundles
    """

    def __init__(
        self,
        plugin_manager: SDKPluginManager,
        llm_factory: Any,
        resolved_config: Dict[str, Any],
        adapter: GoogleADKAdapter,
        streaming_wrapper: GoogleADKStreamingWrapper,
    ):
        """Initialize Google ADK coordinator orchestrator.

        Args:
            plugin_manager: Plugin manager instance
            llm_factory: LLM model factory
            resolved_config: Resolved configuration dictionary
            adapter: Google ADK adapter
            streaming_wrapper: Streaming wrapper
        """
        super().__init__(
            plugin_manager=plugin_manager,
            llm_factory=llm_factory,
            resolved_config=resolved_config,
            adapter=adapter,
            streaming_wrapper=streaming_wrapper,
        )

        self.mode_config = CoordinatorMode(
            "coordinator", resolved_config.get("mode_config", {})
        )
        self._plugin_bundles = plugin_manager.bundles
        self._is_ready = False

        self._initialize()

    def _initialize(self) -> None:
        """Initialize orchestrator resources."""
        try:
            model_config = self.resolved_config.get("model_config", {})
            self.model_name = model_config.get("model_name", "gemini-1.5-pro")

            self._is_ready = True
            logger.info("Google ADK coordinator initialized successfully")

        except Exception as e:
            logger.error(
                f"Failed to initialize Google ADK coordinator: {e}", exc_info=True
            )
            raise

    async def ask(self, state: UvState) -> UvState:
        """Execute single-shot orchestration.

        Args:
            state: Input state with messages

        Returns:
            Updated state with response
        """
        if not self._is_ready:
            raise RuntimeError("Orchestrator not ready")

        messages = state.get("messages", [])

        logger.info(
            f"Processing with Google ADK coordinator ({len(self._plugin_bundles)} plugins)"
        )

        response_text = f"[Google ADK Coordinator] Routed through {len(self._plugin_bundles)} plugin agents"

        from cadence_sdk.types.sdk_messages import UvAIMessage

        result_messages = messages + [UvAIMessage(content=response_text)]

        output_state = state.copy()
        output_state["messages"] = result_messages
        output_state["agent_hops"] = 2
        output_state["current_agent"] = "coordinator"

        return output_state

    async def astream(self, state: UvState) -> AsyncIterator[StreamEvent]:
        """Execute streaming orchestration.

        Args:
            state: Input state with messages

        Yields:
            StreamEvent instances
        """
        if not self._is_ready:
            raise RuntimeError("Orchestrator not ready")

        yield StreamEvent.agent_start("coordinator")

        final_state = await self.ask(state)

        last_message = final_state.get("messages", [])[-1]
        yield StreamEvent.message(last_message.content, role="assistant")

        yield StreamEvent.agent_end("coordinator")

    async def rebuild(self, config: Dict[str, Any]) -> None:
        """Hot-reload orchestrator with new configuration.

        Args:
            config: New configuration dictionary
        """
        logger.info("Rebuilding Google ADK coordinator")

        await self.cleanup()

        self.resolved_config = config
        self.mode_config = CoordinatorMode("coordinator", config.get("mode_config", {}))

        self._initialize()

        logger.info("Google ADK coordinator rebuilt successfully")

    async def cleanup(self) -> None:
        """Release resources and cleanup."""
        logger.info("Cleaning up Google ADK coordinator")

        await self.plugin_manager.cleanup_all()

        self._is_ready = False

    async def health_check(self) -> Dict[str, Any]:
        """Check orchestrator health.

        Returns:
            Health status dictionary
        """
        return {
            "framework_type": self.framework_type,
            "mode": self.mode,
            "is_ready": self._is_ready,
            "plugin_count": len(self._plugin_bundles),
            "plugins": list(self._plugin_bundles.keys()),
        }

    @property
    def mode(self) -> str:
        """Get orchestration mode.

        Returns:
            Mode identifier
        """
        return "coordinator"

    @property
    def framework_type(self) -> str:
        """Get framework type.

        Returns:
            Framework type identifier
        """
        return "google_adk"

    @property
    def plugin_pids(self) -> List[str]:
        """Get list of active plugin pids.

        Returns:
            List of reverse-domain plugin identifiers
        """
        return list(self._plugin_bundles.keys())

    @property
    def is_ready(self) -> bool:
        """Check if orchestrator is ready.

        Returns:
            True if ready, False otherwise
        """
        return self._is_ready
