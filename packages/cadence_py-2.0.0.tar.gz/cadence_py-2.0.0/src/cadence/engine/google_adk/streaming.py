"""Google ADK streaming wrapper.

This module provides conversion from Google ADK stream events to unified StreamEvent format.
"""

import logging
from typing import Any, AsyncIterator

from cadence.engine.base import StreamEvent

logger = logging.getLogger(__name__)


class GoogleADKStreamingWrapper:
    """Streaming wrapper for Google ADK.

    Converts Google ADK stream events to unified StreamEvent format.
    """

    async def wrap_stream(
        self, google_stream: AsyncIterator[Any]
    ) -> AsyncIterator[StreamEvent]:
        """Wrap Google ADK stream with StreamEvent conversion.

        Args:
            google_stream: Google ADK async stream

        Yields:
            StreamEvent instances
        """
        try:
            async for event in google_stream:
                stream_event = self._convert_event(event)
                if stream_event:
                    yield stream_event

        except Exception as e:
            logger.error(f"Google ADK streaming error: {e}", exc_info=True)
            yield StreamEvent.error(str(e), type=type(e).__name__)

    def _convert_event(self, event: Any) -> StreamEvent:
        """Convert Google ADK event to StreamEvent.

        Args:
            event: Google ADK event

        Returns:
            StreamEvent or None
        """
        if not isinstance(event, dict):
            return None

        event_type = event.get("type")

        if event_type == "agent_start":
            return StreamEvent.agent_start(event.get("agent_name", "unknown"))

        elif event_type == "agent_end":
            return StreamEvent.agent_end(event.get("agent_name", "unknown"))

        elif event_type == "text":
            return StreamEvent.message(
                event.get("content", ""),
                role="assistant",
            )

        elif event_type == "function_call_start":
            return StreamEvent.tool_start(
                event.get("name", "unknown"),
                tool_id=event.get("id"),
            )

        elif event_type == "function_call_end":
            return StreamEvent.tool_end(
                event.get("name", "unknown"),
                event.get("result"),
                tool_id=event.get("id"),
            )

        elif event_type == "metadata":
            return StreamEvent.metadata(event.get("data", {}))

        else:
            logger.debug(f"Unknown Google ADK event type: {event_type}")
            return None
