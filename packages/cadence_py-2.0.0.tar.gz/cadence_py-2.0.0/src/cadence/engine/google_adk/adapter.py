"""Google ADK adapter for type conversions.

This module provides an adapter for converting between framework-agnostic SDK types
and Google ADK native types (Content, Part, Event, Session).
"""

import logging
from typing import Any, Dict, List

from cadence_sdk.types.sdk_messages import (
    UvAIMessage,
    UvHumanMessage,
    UvMessage,
    UvSystemMessage,
    UvToolMessage,
)
from cadence_sdk.types.sdk_state import UvState
from cadence_sdk.types.sdk_tools import UvTool

from cadence.engine.base import OrchestratorAdapter

logger = logging.getLogger(__name__)


class GoogleADKAdapter(OrchestratorAdapter):
    """Adapter for Google ADK.

    Converts between SDK types and Google ADK native message/tool formats.
    """

    def __init__(self):
        """Initialize Google ADK adapter."""
        super().__init__(framework_type="google_adk")

    def sdk_message_to_orchestrator(self, sdk_msg: UvMessage) -> dict:
        """Convert SDK message to Google ADK Content format.

        Args:
            sdk_msg: SDK message

        Returns:
            Google ADK message dict
        """
        if isinstance(sdk_msg, UvHumanMessage):
            return {
                "role": "user",
                "parts": [{"text": sdk_msg.content}],
            }

        elif isinstance(sdk_msg, UvAIMessage):
            parts = []

            if sdk_msg.content:
                parts.append({"text": sdk_msg.content})

            if sdk_msg.tool_calls:
                for tc in sdk_msg.tool_calls:
                    parts.append(
                        {
                            "function_call": {
                                "id": tc.id,
                                "name": tc.name,
                                "args": tc.args,
                            }
                        }
                    )

            return {
                "role": "model",
                "parts": parts,
            }

        elif isinstance(sdk_msg, UvSystemMessage):
            return {
                "role": "system",
                "content": sdk_msg.content,
            }

        elif isinstance(sdk_msg, UvToolMessage):
            return {
                "role": "function",
                "parts": [
                    {
                        "function_response": {
                            "id": sdk_msg.tool_call_id,
                            "name": sdk_msg.tool_name,
                            "response": sdk_msg.content,
                        }
                    }
                ],
            }

        raise ValueError(f"Unknown message type: {type(sdk_msg)}")

    def orchestrator_message_to_sdk(self, orch_msg: dict) -> UvMessage:
        """Convert Google ADK message to SDK message.

        Args:
            orch_msg: Google ADK message dict

        Returns:
            SDK message
        """
        role = orch_msg.get("role")
        parts = orch_msg.get("parts", [])

        if role == "user":
            content = parts[0].get("text", "") if parts else ""
            return UvHumanMessage(content=content)

        elif role == "model":
            text_parts = [p.get("text", "") for p in parts if "text" in p]
            content = " ".join(text_parts) if text_parts else ""

            tool_calls = []
            for part in parts:
                if "function_call" in part:
                    fc = part["function_call"]
                    tool_calls.append(
                        {
                            "id": fc.get("id"),
                            "name": fc.get("name"),
                            "args": fc.get("args", {}),
                        }
                    )

            return UvAIMessage(
                content=content, tool_calls=tool_calls if tool_calls else None
            )

        elif role == "system":
            return UvSystemMessage(content=orch_msg.get("content", ""))

        elif role == "function":
            if parts and "function_response" in parts[0]:
                fr = parts[0]["function_response"]
                return UvToolMessage(
                    content=str(fr.get("response", "")),
                    tool_call_id=fr.get("id"),
                    tool_name=fr.get("name"),
                )

        raise ValueError(f"Unknown Google ADK message format: {orch_msg}")

    def uvtool_to_orchestrator(self, uvtool: UvTool) -> Any:
        """Convert UvTool to Google ADK function.

        Google ADK auto-wraps plain functions as FunctionTool.

        Args:
            uvtool: SDK tool

        Returns:
            Function descriptor dict for Google ADK
        """
        schema = {
            "name": uvtool.name,
            "description": uvtool.description or f"Execute {uvtool.name}",
        }

        if uvtool.args_schema:
            schema["parameters"] = self._pydantic_to_google_schema(uvtool.args_schema)
        else:
            schema["parameters"] = {
                "type": "object",
                "properties": {},
                "required": [],
            }

        return {
            "type": "function",
            "function": schema,
            "callable": uvtool.func,
        }

    def _pydantic_to_google_schema(self, model_class: type) -> dict:
        """Convert Pydantic model to Google function parameters schema.

        Args:
            model_class: Pydantic model class

        Returns:
            Google function parameters schema
        """
        if hasattr(model_class, "model_json_schema"):
            json_schema = model_class.model_json_schema()
        elif hasattr(model_class, "schema"):
            json_schema = model_class.schema()
        else:
            return {"type": "object", "properties": {}, "required": []}

        properties = json_schema.get("properties", {})
        required = json_schema.get("required", [])

        google_properties = {}
        for prop_name, prop_schema in properties.items():
            google_properties[prop_name] = {
                "type": prop_schema.get("type", "string"),
                "description": prop_schema.get("description", ""),
            }

        return {
            "type": "object",
            "properties": google_properties,
            "required": required,
        }

    def bind_tools_to_model(self, model: Any, tools: List[UvTool], **kwargs) -> Any:
        """Bind tools to model.

        For Google ADK, binding happens at agent construction, not on model.
        Returns tools list.

        Args:
            model: LLM model (ignored for Google ADK)
            tools: List of UvTool instances
            **kwargs: Additional parameters (ignored)

        Returns:
            List of tool dicts for Google ADK
        """
        return [self.uvtool_to_orchestrator(tool) for tool in tools]

    def create_tool_node(self, tools: List[UvTool]) -> Any:
        """Create tool execution node.

        Google ADK Runner handles tool execution internally.

        Args:
            tools: List of tools (ignored)

        Returns:
            None (Google ADK doesn't use separate tool nodes)
        """
        return None

    def sync_state_to_session(self, state: UvState) -> Dict[str, Any]:
        """Sync UvState to Google ADK session state.

        Maps UvState fields to session.state with 'app:' prefix.

        Args:
            state: SDK state

        Returns:
            Dict for session.state
        """
        session_state = {}

        if "agent_hops" in state:
            session_state["app:agent_hops"] = state["agent_hops"]

        if "current_agent" in state:
            session_state["app:current_agent"] = state["current_agent"]

        if "plugin_context" in state:
            session_state["app:plugin_context"] = state["plugin_context"]

        if "metadata" in state:
            session_state["app:metadata"] = state["metadata"]

        return session_state

    def sync_session_to_state(
        self, session_state: Dict[str, Any], state: UvState
    ) -> UvState:
        """Sync Google ADK session state back to UvState.

        Extracts 'app:' prefixed fields from session.state.

        Args:
            session_state: Session state dict
            state: SDK state to update

        Returns:
            Updated SDK state
        """
        updated_state = state.copy()

        if "app:agent_hops" in session_state:
            updated_state["agent_hops"] = session_state["app:agent_hops"]

        if "app:current_agent" in session_state:
            updated_state["current_agent"] = session_state["app:current_agent"]

        if "app:plugin_context" in session_state:
            updated_state["plugin_context"] = session_state["app:plugin_context"]

        if "app:metadata" in session_state:
            updated_state["metadata"] = session_state["app:metadata"]

        return updated_state
