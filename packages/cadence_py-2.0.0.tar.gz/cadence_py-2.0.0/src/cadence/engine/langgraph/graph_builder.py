"""LangGraph StateGraph builder for orchestration modes.

This module builds LangGraph StateGraphs for different orchestration modes.
"""

import logging
from typing import Annotated, Any, Dict, List, Literal

from langchain_core.messages import BaseMessage
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from typing_extensions import TypedDict

from cadence.engine.modes import CoordinatorMode, HandoffMode, SupervisorMode
from cadence.infrastructure.plugins import SDKPluginBundle

logger = logging.getLogger(__name__)


class GraphState(TypedDict):
    """State type for LangGraph v1.0+.

    Attributes:
        messages: List of messages with add_messages reducer (v1.0+ pattern)
        agent_hops: Number of agent iterations
        current_agent: Current agent name
    """

    messages: Annotated[List[BaseMessage], add_messages]
    agent_hops: int
    current_agent: str


def _sanitize_pid_for_node_name(pid: str) -> str:
    """Convert a reverse-domain pid to a valid LangGraph node or tool name.

    LangGraph node names and LangChain tool names must not contain dots
    or hyphens. This replaces those characters with underscores.

    Args:
        pid: Reverse-domain plugin identifier (e.g., "io.cadence.system.search")

    Returns:
        Sanitized name safe for use as a LangGraph node or tool identifier
    """
    return pid.replace(".", "_").replace("-", "_")


class StateGraphBuilder:
    """Builder for LangGraph StateGraph instances.

    Creates StateGraphs for different orchestration modes with appropriate
    nodes, edges, and routing logic.
    """

    def __init__(self):
        """Initialize graph builder."""
        pass

    def build_supervisor_graph(
        self,
        bundles: Dict[str, SDKPluginBundle],
        model: Any,
        mode_config: SupervisorMode,
    ) -> Any:
        """Build supervisor mode StateGraph.

        Graph structure:
        - START → supervisor
        - supervisor → control_tools (if tool_calls)
        - supervisor → synthesizer (if no tool_calls and within hop limit)
        - supervisor → END (if hop limit exceeded)
        - control_tools → supervisor (continue loop)
        - synthesizer → END

        Args:
            bundles: Dict of plugin bundles keyed by pid
            model: LLM model with tools bound
            mode_config: Supervisor mode configuration

        Returns:
            Compiled StateGraph
        """
        from langgraph.prebuilt import ToolNode

        all_tools = []
        for bundle in bundles.values():
            all_tools.extend(bundle.orchestrator_tools)

        tool_node = ToolNode(all_tools)

        workflow = StateGraph(GraphState)

        system_prompt = self._build_supervisor_prompt(bundles)

        def supervisor_node(state: GraphState) -> GraphState:
            """Supervisor node that calls model with all tools."""
            messages = state["messages"]
            agent_hops = state.get("agent_hops", 0)

            from langchain_core.messages import SystemMessage

            full_messages = [SystemMessage(content=system_prompt)] + messages

            response = model.invoke(full_messages)

            return {
                "messages": [response],
                "agent_hops": agent_hops + 1,
                "current_agent": "supervisor",
            }

        def synthesizer_node(state: GraphState) -> GraphState:
            """Synthesizer node that generates final response."""
            messages = state["messages"]

            from langchain_core.messages import SystemMessage

            synth_prompt = (
                "Provide a clear, concise final response based on the conversation."
            )
            full_messages = [SystemMessage(content=synth_prompt)] + messages

            synth_model = (
                model.without_tools() if hasattr(model, "without_tools") else model
            )
            response = synth_model.invoke(full_messages)

            return {
                "messages": [response],
                "current_agent": "synthesizer",
            }

        def route_supervisor_next(
            state: GraphState,
        ) -> Literal["tools", "synthesizer", "end"]:
            """Determine the next step after the supervisor node."""
            messages = state["messages"]
            agent_hops = state.get("agent_hops", 0)
            last_message = messages[-1]

            if agent_hops >= mode_config.max_agent_hops:
                logger.warning(f"Max agent hops ({mode_config.max_agent_hops}) reached")
                return "end"

            if hasattr(last_message, "tool_calls") and last_message.tool_calls:
                return "tools"

            if mode_config.enable_synthesizer:
                return "synthesizer"

            return "end"

        workflow.add_node("supervisor", supervisor_node)
        workflow.add_node("control_tools", tool_node)

        if mode_config.enable_synthesizer:
            workflow.add_node("synthesizer", synthesizer_node)

        workflow.add_edge(START, "supervisor")
        workflow.add_conditional_edges(
            "supervisor",
            route_supervisor_next,
            {
                "tools": "control_tools",
                "synthesizer": "synthesizer" if mode_config.enable_synthesizer else END,
                "end": END,
            },
        )
        workflow.add_edge("control_tools", "supervisor")

        if mode_config.enable_synthesizer:
            workflow.add_edge("synthesizer", END)

        return workflow.compile()

    def _build_supervisor_prompt(self, bundles: Dict[str, SDKPluginBundle]) -> str:
        """Build system prompt for supervisor.

        Args:
            bundles: Plugin bundles keyed by pid

        Returns:
            System prompt text
        """
        prompt = (
            "You are a helpful AI assistant with access to the following tools:\n\n"
        )

        for pid, bundle in bundles.items():
            prompt += f"Plugin: {bundle.metadata.name} ({pid})\n"
            prompt += f"Description: {bundle.metadata.description}\n"
            prompt += f"Tools: {', '.join(tool.name for tool in bundle.uvtools)}\n\n"

        prompt += "Use the available tools to help answer user questions. "
        prompt += "Call tools when needed, and provide clear, helpful responses."

        return prompt

    def build_coordinator_graph(
        self,
        bundles: Dict[str, SDKPluginBundle],
        routing_model: Any,
        mode_config: CoordinatorMode,
    ) -> Any:
        """Build coordinator mode StateGraph.

        Graph structure:
        - START → coordinator
        - coordinator → {node_name}_agent (via routing tools)
        - {node_name}_agent → {node_name}_tools (if tool calls)
        - {node_name}_tools → {node_name}_agent
        - {node_name}_agent → coordinator (return control)
        - coordinator → synthesizer (via goto_synthesize)
        - coordinator → suspend (if consecutive limit hit)
        - synthesizer → END
        - suspend → END

        Node names are derived from plugin pids via _sanitize_pid_for_node_name().

        Args:
            bundles: Dict of plugin bundles keyed by pid
            routing_model: Model for coordinator routing decisions
            mode_config: Coordinator mode configuration

        Returns:
            Compiled StateGraph
        """
        from langchain_core.messages import AIMessage, SystemMessage
        from langchain_core.tools import tool as tool_decorator
        from langgraph.prebuilt import ToolNode

        class CoordinatorState(TypedDict):
            """State for coordinator graph."""

            messages: Annotated[List[BaseMessage], add_messages]
            agent_hops: int
            current_agent: str
            consecutive_agent_routes: Dict[str, int]

        workflow = StateGraph(CoordinatorState)

        routing_tools = []

        for pid in bundles.keys():
            node_name = _sanitize_pid_for_node_name(pid)

            @tool_decorator(name=f"goto_{node_name}")
            def goto_plugin(query: str, _node_name=node_name) -> str:
                f"""Transfer to {_node_name} agent.

                Args:
                    query: Task for the agent

                Returns:
                    Transfer confirmation
                """
                return f"Transferring to {_node_name}"

            routing_tools.append(goto_plugin)

        @tool_decorator(name="goto_synthesize")
        def goto_synthesize(summary: str) -> str:
            """Complete task and synthesize final response.

            Args:
                summary: Summary of completed work

            Returns:
                Synthesis confirmation
            """
            return "Synthesizing final response"

        routing_tools.append(goto_synthesize)

        routing_model_with_tools = routing_model.bind_tools(routing_tools)

        coordinator_prompt = self._build_coordinator_prompt(bundles)

        def coordinator_node(state: CoordinatorState) -> CoordinatorState:
            """Central routing node."""
            messages = state["messages"]
            agent_hops = state.get("agent_hops", 0)

            full_messages = [SystemMessage(content=coordinator_prompt)] + messages
            response = routing_model_with_tools.invoke(full_messages)

            return {
                "messages": [response],
                "agent_hops": agent_hops + 1,
                "current_agent": "coordinator",
            }

        def route_coordinator(state: CoordinatorState) -> str:
            """Route from coordinator based on tool calls."""
            last_message = state["messages"][-1]
            agent_hops = state.get("agent_hops", 0)

            if agent_hops >= mode_config.max_agent_hops:
                return "suspend"

            if hasattr(last_message, "tool_calls") and last_message.tool_calls:
                tool_call = last_message.tool_calls[0]
                tool_name = tool_call.get("name", "")

                if tool_name == "goto_synthesize":
                    return "synthesizer"

                for pid in bundles.keys():
                    node_name = _sanitize_pid_for_node_name(pid)
                    if tool_name == f"goto_{node_name}":
                        return f"{node_name}_agent"

            return "suspend"

        for pid, bundle in bundles.items():
            node_name = _sanitize_pid_for_node_name(pid)
            plugin_model = bundle.bound_model
            plugin_tools = bundle.orchestrator_tools

            if plugin_tools:
                tool_node = ToolNode(plugin_tools)

                def make_agent_node(node_name, plugin_model):
                    def agent_node(state: CoordinatorState) -> CoordinatorState:
                        messages = state["messages"]
                        response = plugin_model.invoke(messages)
                        return {
                            "messages": [response],
                            "current_agent": node_name,
                        }

                    return agent_node

                def make_plugin_route(node_name):
                    def route_plugin_next(
                        state: CoordinatorState,
                    ) -> Literal["tools", "coordinator"]:
                        """Determine whether this plugin node should call tools or return to coordinator."""
                        last_message = state["messages"][-1]
                        if (
                            hasattr(last_message, "tool_calls")
                            and last_message.tool_calls
                        ):
                            return "tools"
                        return "coordinator"

                    return route_plugin_next

                workflow.add_node(
                    f"{node_name}_agent", make_agent_node(node_name, plugin_model)
                )
                workflow.add_node(f"{node_name}_tools", tool_node)

                workflow.add_conditional_edges(
                    f"{node_name}_agent",
                    make_plugin_route(node_name),
                    {
                        "tools": f"{node_name}_tools",
                        "coordinator": "coordinator",
                    },
                )
                workflow.add_edge(f"{node_name}_tools", f"{node_name}_agent")

        def synthesizer_node(state: CoordinatorState) -> CoordinatorState:
            """Generate final response."""
            messages = state["messages"]
            synth_prompt = "Provide a clear, concise final response."
            full_messages = [SystemMessage(content=synth_prompt)] + messages

            synth_model = (
                routing_model.without_tools()
                if hasattr(routing_model, "without_tools")
                else routing_model
            )
            response = synth_model.invoke(full_messages)

            return {"messages": [response], "current_agent": "synthesizer"}

        def suspend_node(state: CoordinatorState) -> CoordinatorState:
            """Ask user to clarify or narrow their request."""
            return {
                "messages": [
                    AIMessage(
                        content="Task suspended. Need more information or clarification."
                    )
                ],
                "current_agent": "suspend",
            }

        workflow.add_node("coordinator", coordinator_node)
        workflow.add_node("synthesizer", synthesizer_node)
        workflow.add_node("suspend", suspend_node)

        workflow.add_edge(START, "coordinator")
        workflow.add_conditional_edges("coordinator", route_coordinator)
        workflow.add_edge("synthesizer", END)
        workflow.add_edge("suspend", END)

        return workflow.compile()

    def build_handoff_graph(
        self,
        bundles: Dict[str, SDKPluginBundle],
        mode_config: HandoffMode,
    ) -> Any:
        """Build handoff mode StateGraph.

        Graph structure (peer-to-peer):
        - START → entry_agent
        - Each agent can transfer to any other agent via handoff tools
        - Agents route to END when task complete

        Node names are derived from plugin pids via _sanitize_pid_for_node_name().

        Args:
            bundles: Dict of plugin bundles keyed by pid
            mode_config: Handoff mode configuration

        Returns:
            Compiled StateGraph
        """
        from langchain_core.messages import SystemMessage
        from langchain_core.tools import tool as tool_decorator
        from langgraph.prebuilt import ToolNode

        class HandoffState(TypedDict):
            """State for handoff graph."""

            messages: Annotated[List[BaseMessage], add_messages]
            handoff_count: int
            current_agent: str

        workflow = StateGraph(HandoffState)

        for pid, bundle in bundles.items():
            node_name = _sanitize_pid_for_node_name(pid)
            plugin_model = bundle.bound_model
            plugin_tools = list(bundle.orchestrator_tools)

            handoff_tools = []
            for other_pid in bundles.keys():
                if other_pid != pid:
                    other_node = _sanitize_pid_for_node_name(other_pid)

                    @tool_decorator(name=f"transfer_to_{other_node}")
                    def transfer(reason: str, _target=other_node) -> str:
                        f"""Transfer task to {_target} agent.

                        Args:
                            reason: Why transferring to this agent

                        Returns:
                            Transfer confirmation
                        """
                        return f"Transferring to {_target}"

                    handoff_tools.append(transfer)

            @tool_decorator(name="complete_task")
            def complete_task(summary: str) -> str:
                """Mark task as complete.

                Args:
                    summary: Summary of completed work

                Returns:
                    Completion confirmation
                """
                return "Task completed"

            handoff_tools.append(complete_task)

            all_tools = plugin_tools + handoff_tools
            model_with_handoffs = plugin_model.bind_tools(all_tools)

            agent_prompt = self._build_handoff_agent_prompt(
                node_name,
                bundle,
                bundles,
                mode_config,
            )

            def make_agent_node(node_name, model_with_handoffs, agent_prompt):
                def agent_node(state: HandoffState) -> HandoffState:
                    messages = state["messages"]
                    full_messages = [SystemMessage(content=agent_prompt)] + messages
                    response = model_with_handoffs.invoke(full_messages)
                    return {
                        "messages": [response],
                        "current_agent": node_name,
                    }

                return agent_node

            def make_route_agent(node_name):
                def route_agent(state: HandoffState) -> str:
                    last_message = state["messages"][-1]
                    handoff_count = state.get("handoff_count", 0)

                    if handoff_count >= mode_config.max_handoffs:
                        return "end"

                    if hasattr(last_message, "tool_calls") and last_message.tool_calls:
                        tool_call = last_message.tool_calls[0]
                        tool_name = tool_call.get("name", "")

                        if tool_name == "complete_task":
                            return "end"

                        for other_pid in bundles.keys():
                            other_node = _sanitize_pid_for_node_name(other_pid)
                            if tool_name == f"transfer_to_{other_node}":
                                return f"{other_node}_agent"

                    return f"{node_name}_tools"

                return route_agent

            if plugin_tools:
                tool_node = ToolNode(all_tools)
                workflow.add_node(f"{node_name}_tools", tool_node)
                workflow.add_edge(f"{node_name}_tools", f"{node_name}_agent")

            workflow.add_node(
                f"{node_name}_agent",
                make_agent_node(node_name, model_with_handoffs, agent_prompt),
            )
            workflow.add_conditional_edges(
                f"{node_name}_agent", make_route_agent(node_name)
            )

        entry_node = _sanitize_pid_for_node_name(mode_config.entry_agent)
        workflow.add_edge(START, f"{entry_node}_agent")

        return workflow.compile()

    def _build_coordinator_prompt(self, bundles: Dict[str, SDKPluginBundle]) -> str:
        """Build system prompt for coordinator.

        Args:
            bundles: Plugin bundles keyed by pid

        Returns:
            System prompt text
        """
        prompt = (
            "You are a coordinator agent that routes tasks to specialized agents.\n\n"
        )
        prompt += "Available agents:\n\n"

        for pid, bundle in bundles.items():
            node_name = _sanitize_pid_for_node_name(pid)
            prompt += f"- {node_name} ({bundle.metadata.name}): {bundle.metadata.description}\n"

        prompt += "\nUse goto_{agent_name} to route to an agent. "
        prompt += "Use goto_synthesize when the task is complete."

        return prompt

    def _build_handoff_agent_prompt(
        self,
        node_name: str,
        bundle: SDKPluginBundle,
        all_bundles: Dict[str, SDKPluginBundle],
        mode_config: HandoffMode,
    ) -> str:
        """Build system prompt for handoff agent.

        Args:
            node_name: This agent's sanitized node name
            bundle: This agent's bundle
            all_bundles: All plugin bundles keyed by pid
            mode_config: Handoff mode configuration

        Returns:
            System prompt text
        """
        prompt = f"You are {node_name} agent ({bundle.metadata.name}).\n"
        prompt += f"Expertise: {bundle.metadata.description}\n\n"
        prompt += f"Instructions: {mode_config.handoff_instructions}\n\n"
        prompt += "Other agents you can transfer to:\n\n"

        for other_pid, other_bundle in all_bundles.items():
            other_node = _sanitize_pid_for_node_name(other_pid)
            if other_node != node_name:
                prompt += f"- {other_node} ({other_bundle.metadata.name}): {other_bundle.metadata.description}\n"

        prompt += "\nUse transfer_to_{agent_name} to hand off to another agent. "
        prompt += "Use complete_task when finished."

        return prompt
