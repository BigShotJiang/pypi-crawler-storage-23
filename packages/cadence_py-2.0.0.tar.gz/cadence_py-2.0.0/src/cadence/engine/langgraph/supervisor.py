"""LangGraph supervisor orchestrator implementation (v1.0+).

This module implements the supervisor mode orchestrator using LangGraph v1.0+.

IMPORTANT: This code requires LangChain v1.0+ and is NOT backward compatible
with pre-v1.0 versions. Key v1.0+ features used:
- Annotated message reducers (add_messages)
- Model.bind_tools() with v1.0+ tool format
- StateGraph with v1.0+ API
"""

import logging
from typing import Any, AsyncIterator, Dict, List

from cadence_sdk.types.sdk_state import UvState

from cadence.constants import DEFAULT_MAX_TOKENS, DEFAULT_TEMPERATURE
from cadence.engine.base import BaseOrchestrator, StreamEvent
from cadence.engine.langgraph.adapter import LangChainAdapter
from cadence.engine.langgraph.graph_builder import StateGraphBuilder
from cadence.engine.langgraph.streaming import LangGraphStreamingWrapper
from cadence.engine.modes import SupervisorMode
from cadence.infrastructure.plugins import SDKPluginManager

logger = logging.getLogger(__name__)


class LangGraphSupervisor(BaseOrchestrator):
    """LangGraph supervisor mode orchestrator.

    In supervisor mode, all plugin tools are bound to a single model.
    The supervisor decides which tools to call based on the user query.

    Attributes:
        plugin_manager: Plugin manager instance
        llm_factory: LLM model factory
        resolved_config: Resolved configuration
        adapter: LangChain adapter
        streaming_wrapper: Streaming wrapper
        mode_config: Supervisor mode configuration
        graph: Compiled StateGraph
        primary_model: Primary LLM model with tools
        _plugin_bundles: Dict of plugin bundles
    """

    def __init__(
        self,
        plugin_manager: SDKPluginManager,
        llm_factory: Any,
        resolved_config: Dict[str, Any],
        adapter: LangChainAdapter,
        streaming_wrapper: LangGraphStreamingWrapper,
    ):
        """Initialize LangGraph supervisor orchestrator.

        Args:
            plugin_manager: Plugin manager instance
            llm_factory: LLM model factory
            resolved_config: Resolved configuration dictionary
            adapter: LangChain adapter
            streaming_wrapper: Streaming wrapper
        """
        super().__init__(
            plugin_manager=plugin_manager,
            llm_factory=llm_factory,
            resolved_config=resolved_config,
            adapter=adapter,
            streaming_wrapper=streaming_wrapper,
        )

        self.mode_config = SupervisorMode(resolved_config.get("mode_config", {}))
        self._plugin_bundles = plugin_manager.bundles
        self._is_ready = False

        self._initialize()

    def _initialize(self) -> None:
        """Initialize orchestrator resources."""
        try:
            all_uvtools = []
            for bundle in self._plugin_bundles.values():
                all_uvtools.extend(bundle.uvtools)

            model_config = self.resolved_config.get("model_config", {})
            self.primary_model = self.llm_factory.create_model_with_fallback(
                model_config=model_config,
                temperature=self.resolved_config.get(
                    "temperature", DEFAULT_TEMPERATURE
                ),
                max_tokens=self.resolved_config.get("max_tokens", DEFAULT_MAX_TOKENS),
            )

            self.primary_model = self.adapter.bind_tools_to_model(
                self.primary_model,
                all_uvtools,
            )

            graph_builder = StateGraphBuilder()
            self.graph = graph_builder.build_supervisor_graph(
                bundles=self._plugin_bundles,
                model=self.primary_model,
                mode_config=self.mode_config,
            )

            self._is_ready = True
            logger.info("LangGraph supervisor initialized successfully")

        except Exception as e:
            logger.error(
                f"Failed to initialize LangGraph supervisor: {e}", exc_info=True
            )
            raise

    async def ask(self, state: UvState) -> UvState:
        """Execute single-shot orchestration.

        Args:
            state: Input state with messages

        Returns:
            Updated state with response
        """
        if not self._is_ready:
            raise RuntimeError("Orchestrator not ready")

        messages = state.get("messages", [])
        lc_messages = [
            self.adapter.sdk_message_to_orchestrator(msg) for msg in messages
        ]

        graph_state = {
            "messages": lc_messages,
            "agent_hops": 0,
            "current_agent": "",
        }

        config = {
            "recursion_limit": self.mode_config.max_agent_hops + 10,
        }

        result = await self.graph.ainvoke(graph_state, config=config)

        result_messages = result.get("messages", [])
        sdk_messages = [
            self.adapter.orchestrator_message_to_sdk(msg) for msg in result_messages
        ]

        output_state = state.copy()
        output_state["messages"] = sdk_messages
        output_state["agent_hops"] = result.get("agent_hops", 0)
        output_state["current_agent"] = result.get("current_agent", "")

        return output_state

    async def astream(self, state: UvState) -> AsyncIterator[StreamEvent]:
        """Execute streaming orchestration.

        Args:
            state: Input state with messages

        Yields:
            StreamEvent instances
        """
        if not self._is_ready:
            raise RuntimeError("Orchestrator not ready")

        messages = state.get("messages", [])
        lc_messages = [
            self.adapter.sdk_message_to_orchestrator(msg) for msg in messages
        ]

        graph_state = {
            "messages": lc_messages,
            "agent_hops": 0,
            "current_agent": "",
        }

        config = {
            "recursion_limit": self.mode_config.max_agent_hops + 10,
        }

        langgraph_stream = self.graph.astream(graph_state, config=config)

        async for event in self.streaming_wrapper.wrap_stream(langgraph_stream):
            yield event

    async def rebuild(self, config: Dict[str, Any]) -> None:
        """Hot-reload orchestrator with new configuration.

        Args:
            config: New configuration dictionary
        """
        logger.info("Rebuilding LangGraph supervisor")

        await self.cleanup()

        self.resolved_config = config
        self.mode_config = SupervisorMode(config.get("mode_config", {}))

        self._initialize()

        logger.info("LangGraph supervisor rebuilt successfully")

    async def cleanup(self) -> None:
        """Release resources and cleanup."""
        logger.info("Cleaning up LangGraph supervisor")

        await self.plugin_manager.cleanup_all()

        self.primary_model = None
        self.graph = None
        self._is_ready = False

    async def health_check(self) -> Dict[str, Any]:
        """Check orchestrator health.

        Returns:
            Health status dictionary
        """
        return {
            "framework_type": self.framework_type,
            "mode": self.mode,
            "is_ready": self._is_ready,
            "plugin_count": len(self._plugin_bundles),
            "plugins": list(self._plugin_bundles.keys()),
            "max_agent_hops": self.mode_config.max_agent_hops,
        }

    @property
    def mode(self) -> str:
        """Get orchestration mode.

        Returns:
            Mode identifier
        """
        return "supervisor"

    @property
    def framework_type(self) -> str:
        """Get framework type.

        Returns:
            Framework type identifier
        """
        return "langgraph"

    @property
    def plugin_pids(self) -> List[str]:
        """Get list of active plugin pids.

        Returns:
            List of reverse-domain plugin identifiers
        """
        return list(self._plugin_bundles.keys())

    @property
    def is_ready(self) -> bool:
        """Check if orchestrator is ready.

        Returns:
            True if ready, False otherwise
        """
        return self._is_ready
