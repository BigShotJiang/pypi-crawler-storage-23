"""OpenAI Agents SDK streaming wrapper.

This module wraps OpenAI Agents SDK streaming events and converts them
to framework-agnostic StreamEvent format.
"""

import logging
from typing import AsyncIterator

from cadence.infrastructure.streaming import StreamEvent

logger = logging.getLogger(__name__)


class OpenAIAgentsStreamingWrapper:
    """Streaming wrapper for OpenAI Agents SDK.

    Converts OpenAI Agents stream events to framework-agnostic StreamEvent format.
    """

    async def wrap_stream(
        self, openai_stream: AsyncIterator
    ) -> AsyncIterator[StreamEvent]:
        """Wrap OpenAI Agents stream.

        Args:
            openai_stream: OpenAI Agents async iterator

        Yields:
            StreamEvent instances
        """
        try:
            async for event in openai_stream:
                yield self._convert_event(event)

        except Exception as e:
            logger.error(f"Stream error: {e}", exc_info=True)
            yield StreamEvent.error(str(e))

    def _convert_event(self, event: dict) -> StreamEvent:
        """Convert OpenAI event to StreamEvent.

        Args:
            event: OpenAI event dict

        Returns:
            StreamEvent
        """
        event_type = event.get("type", "unknown")

        if event_type == "message":
            return StreamEvent.message(
                event.get("content", ""),
                role=event.get("role", "assistant"),
            )

        elif event_type == "tool_call_start":
            return StreamEvent.tool_start(
                event.get("name", ""),
                tool_call_id=event.get("id", ""),
            )

        elif event_type == "tool_call_end":
            return StreamEvent.tool_end(
                event.get("name", ""),
                event.get("result", ""),
            )

        elif event_type == "agent_start":
            return StreamEvent.agent_start(event.get("agent", ""))

        elif event_type == "agent_end":
            return StreamEvent.agent_end(event.get("agent", ""))

        else:
            return StreamEvent.metadata(event)
