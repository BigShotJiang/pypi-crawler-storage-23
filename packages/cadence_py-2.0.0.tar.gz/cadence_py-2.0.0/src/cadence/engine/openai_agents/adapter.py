"""OpenAI Agents SDK adapter for type conversions.

This module provides an adapter for converting between framework-agnostic SDK types
and OpenAI Agents SDK native types.
"""

import logging
from typing import Any, List

from cadence_sdk.types.sdk_messages import (
    UvAIMessage,
    UvHumanMessage,
    UvMessage,
    UvSystemMessage,
    UvToolMessage,
)
from cadence_sdk.types.sdk_tools import UvTool

from cadence.engine.base import OrchestratorAdapter

logger = logging.getLogger(__name__)


class OpenAIAgentsAdapter(OrchestratorAdapter):
    """Adapter for OpenAI Agents SDK.

    Converts between SDK types and OpenAI native message/tool formats.
    """

    def __init__(self):
        """Initialize OpenAI Agents adapter."""
        super().__init__(framework_type="openai_agents")

    def sdk_message_to_orchestrator(self, sdk_msg: UvMessage) -> dict:
        """Convert SDK message to OpenAI format.

        Args:
            sdk_msg: SDK message

        Returns:
            OpenAI message dict
        """
        if isinstance(sdk_msg, UvHumanMessage):
            return {
                "role": "user",
                "content": sdk_msg.content,
            }

        elif isinstance(sdk_msg, UvAIMessage):
            message = {
                "role": "assistant",
                "content": sdk_msg.content or "",
            }

            if sdk_msg.tool_calls:
                message["tool_calls"] = [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.name,
                            "arguments": tc.args,
                        },
                    }
                    for tc in sdk_msg.tool_calls
                ]

            return message

        elif isinstance(sdk_msg, UvSystemMessage):
            return {
                "role": "system",
                "content": sdk_msg.content,
            }

        elif isinstance(sdk_msg, UvToolMessage):
            return {
                "role": "tool",
                "tool_call_id": sdk_msg.tool_call_id,
                "content": sdk_msg.content,
            }

        else:
            logger.warning(f"Unknown message type: {type(sdk_msg)}")
            return {
                "role": "user",
                "content": str(sdk_msg.content),
            }

    def orchestrator_message_to_sdk(self, orch_msg: dict) -> UvMessage:
        """Convert OpenAI message to SDK format.

        Args:
            orch_msg: OpenAI message dict

        Returns:
            SDK message
        """
        role = orch_msg.get("role", "user")
        content = orch_msg.get("content", "")

        if role == "user":
            return UvHumanMessage(content=content)

        elif role == "assistant":
            tool_calls = []
            if "tool_calls" in orch_msg:
                from cadence_sdk.types.sdk_messages import ToolCall

                for tc in orch_msg["tool_calls"]:
                    tool_calls.append(
                        ToolCall(
                            id=tc.get("id", ""),
                            name=tc["function"]["name"],
                            args=tc["function"]["arguments"],
                        )
                    )

            return UvAIMessage(content=content, tool_calls=tool_calls)

        elif role == "system":
            return UvSystemMessage(content=content)

        elif role == "tool":
            return UvToolMessage(
                content=content,
                tool_call_id=orch_msg.get("tool_call_id", ""),
                tool_name=orch_msg.get("name", ""),
            )

        else:
            logger.warning(f"Unknown message role: {role}")
            return UvHumanMessage(content=content)

    def uvtool_to_orchestrator(self, uvtool: UvTool) -> dict:
        """Convert SDK tool to OpenAI function format.

        Args:
            uvtool: SDK tool

        Returns:
            OpenAI function dict
        """
        function_def = {
            "name": uvtool.name,
            "description": uvtool.description or "",
        }

        if uvtool.args_schema:
            try:
                function_def["parameters"] = uvtool.args_schema.model_json_schema()
            except Exception as e:
                logger.warning(f"Failed to convert args_schema for {uvtool.name}: {e}")
                function_def["parameters"] = {
                    "type": "object",
                    "properties": {},
                }

        return {"type": "function", "function": function_def}

    def bind_tools_to_model(self, model: Any, tools: List[UvTool], **kwargs) -> list:
        """Convert tools to OpenAI format.

        For OpenAI Agents, tools are not bound to model directly.
        Returns tool list for Agent construction.

        Args:
            model: Model instance (unused for OpenAI)
            tools: List of SDK tools
            **kwargs: Additional arguments

        Returns:
            List of OpenAI tool dicts
        """
        return [self.uvtool_to_orchestrator(tool) for tool in tools]

    def create_tool_node(self, tools: List[UvTool]) -> None:
        """Create tool execution node.

        OpenAI Agents SDK handles tool execution internally via Runner.
        Returns None since no explicit tool node is needed.

        Args:
            tools: List of SDK tools

        Returns:
            None (not used for OpenAI Agents)
        """
        return None
