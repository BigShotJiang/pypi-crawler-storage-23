"""OpenAI Agents SDK orchestrator backend.

This package provides OpenAI Agents SDK integration for all three orchestration modes:
supervisor, coordinator, and handoff.
"""

from cadence.engine.openai_agents.adapter import OpenAIAgentsAdapter
from cadence.engine.openai_agents.coordinator import OpenAICoordinator
from cadence.engine.openai_agents.handoff import OpenAIHandoff
from cadence.engine.openai_agents.streaming import OpenAIAgentsStreamingWrapper
from cadence.engine.openai_agents.supervisor import OpenAISupervisor

__all__ = [
    "OpenAIAgentsAdapter",
    "OpenAICoordinator",
    "OpenAIHandoff",
    "OpenAIAgentsStreamingWrapper",
    "OpenAISupervisor",
]
