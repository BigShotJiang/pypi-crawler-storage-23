"""Supervisor mode specification.

In supervisor mode, a central supervisor agent has access to all plugin tools
and decides which tools to call based on user queries.
"""

from typing import Any, Dict, Optional

from cadence.engine.modes.mode_base import OrchestratorMode


class SupervisorMode(OrchestratorMode):
    """Supervisor orchestration mode configuration.

    The supervisor has all plugin tools bound to a single model and decides
    which tools to call in response to user queries. Tool execution happens
    in a dedicated tool node, then control returns to the supervisor.

    Configuration:
        max_agent_hops: Maximum number of supervisor iterations (default: 10)
        parallel_tool_calls: Allow parallel tool execution (default: True)
        invoke_timeout: Timeout in seconds for tool execution (default: 60)
        use_llm_validation: Use LLM to validate tool results (default: False)
        enable_synthesizer: Use synthesizer for final response (default: True)
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize supervisor mode.

        Args:
            config: Optional configuration dictionary
        """
        defaults = {
            "max_agent_hops": 10,
            "parallel_tool_calls": True,
            "invoke_timeout": 60,
            "use_llm_validation": False,
            "enable_synthesizer": True,
        }

        merged_config = {**defaults, **(config or {})}
        super().__init__(mode_name="supervisor", config=merged_config)

    @property
    def max_agent_hops(self) -> int:
        """Get maximum agent hops.

        Returns:
            Max hops value
        """
        return self.config["max_agent_hops"]

    @property
    def parallel_tool_calls(self) -> bool:
        """Get parallel tool calls setting.

        Returns:
            True if parallel calls enabled
        """
        return self.config["parallel_tool_calls"]

    @property
    def invoke_timeout(self) -> int:
        """Get tool invocation timeout.

        Returns:
            Timeout in seconds
        """
        return self.config["invoke_timeout"]

    @property
    def use_llm_validation(self) -> bool:
        """Get LLM validation setting.

        Returns:
            True if LLM validation enabled
        """
        return self.config["use_llm_validation"]

    @property
    def enable_synthesizer(self) -> bool:
        """Get synthesizer setting.

        Returns:
            True if synthesizer enabled
        """
        return self.config["enable_synthesizer"]
