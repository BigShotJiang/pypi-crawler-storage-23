"""Shared model pool for memory-efficient LLM instance reuse.

This module provides a shared registry for LLM models with reference counting,
allowing multiple orchestrator instances to share the same model object.
"""

import hashlib
import logging
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger(__name__)


class SharedModelPool:
    """Shared pool for LLM model instances with reference counting.

    Models are keyed by (provider, model_name, api_key_hash, base_url) tuple.
    Reference counting ensures models are only cleaned up when no longer used.

    Attributes:
        _registry: Dict mapping model key to (model, ref_count) tuple
        _lock: Thread lock for concurrent access safety
    """

    def __init__(self):
        """Initialize shared model pool."""
        self._registry: Dict[Tuple, Tuple[Any, int]] = {}
        import asyncio

        self._lock = asyncio.Lock()

    def _compute_key(
        self,
        provider: str,
        model_name: str,
        api_key: str,
        base_url: Optional[str],
        **params: Any,
    ) -> Tuple:
        """Compute cache key for model.

        Args:
            provider: Provider name (openai, anthropic, etc.)
            model_name: Model name
            api_key: API key
            base_url: Optional base URL
            **params: Additional parameters (ignored for now)

        Returns:
            Cache key tuple
        """
        api_key_hash = hashlib.sha256(api_key.encode()).hexdigest()[:16]
        return (provider, model_name, api_key_hash, base_url or "")

    async def get_or_create(
        self,
        provider: str,
        model_name: str,
        api_key: str,
        base_url: Optional[str],
        factory: Any,
        **params: Any,
    ) -> Any:
        """Get existing model or create new one.

        Args:
            provider: Provider name
            model_name: Model name
            api_key: API key
            base_url: Optional base URL
            factory: LLM factory for creating models
            **params: Additional model parameters

        Returns:
            LLM model instance
        """
        key = self._compute_key(provider, model_name, api_key, base_url, **params)

        async with self._lock:
            if key in self._registry:
                model, ref_count = self._registry[key]
                self._registry[key] = (model, ref_count + 1)
                logger.debug(
                    f"Reusing model {provider}/{model_name}, ref_count={ref_count + 1}"
                )
                return model

            logger.info(f"Creating new model {provider}/{model_name}")
            model = factory.create_model(
                provider=provider,
                model_name=model_name,
                api_key=api_key,
                base_url=base_url,
                **params,
            )

            self._registry[key] = (model, 1)
            return model

    async def increment_ref(
        self,
        provider: str,
        model_name: str,
        api_key: str,
        base_url: Optional[str],
    ) -> None:
        """Increment reference count for model.

        Args:
            provider: Provider name
            model_name: Model name
            api_key: API key
            base_url: Optional base URL
        """
        key = self._compute_key(provider, model_name, api_key, base_url)

        async with self._lock:
            if key in self._registry:
                model, ref_count = self._registry[key]
                self._registry[key] = (model, ref_count + 1)
                logger.debug(
                    f"Incremented ref for {provider}/{model_name}, ref_count={ref_count + 1}"
                )

    async def decrement_ref(
        self,
        provider: str,
        model_name: str,
        api_key: str,
        base_url: Optional[str],
    ) -> None:
        """Decrement reference count and cleanup if zero.

        Args:
            provider: Provider name
            model_name: Model name
            api_key: API key
            base_url: Optional base URL
        """
        key = self._compute_key(provider, model_name, api_key, base_url)

        async with self._lock:
            if key not in self._registry:
                return

            model, ref_count = self._registry[key]
            new_count = ref_count - 1

            if new_count <= 0:
                logger.info(f"Removing model {provider}/{model_name} (ref_count=0)")
                del self._registry[key]
            else:
                self._registry[key] = (model, new_count)
                logger.debug(
                    f"Decremented ref for {provider}/{model_name}, ref_count={new_count}"
                )

    async def cleanup(self) -> None:
        """Force cleanup of all models."""
        async with self._lock:
            count = len(self._registry)
            self._registry.clear()
            logger.info(f"Cleaned up {count} models from pool")

    def get_stats(self) -> Dict[str, Any]:
        """Get pool statistics.

        Returns:
            Statistics dictionary
        """
        total_models = len(self._registry)
        total_refs = sum(ref_count for _, ref_count in self._registry.values())

        return {
            "total_models": total_models,
            "total_references": total_refs,
            "average_refs_per_model": (
                total_refs / total_models if total_models > 0 else 0
            ),
        }
