"""Settings service for managing configuration across all tiers.

This module provides settings management for Global settings, Organization
settings, and Instance config, with hot-reload support for instance updates.
"""

import hashlib
import json
import logging
from typing import Any, Dict, List, Optional
from uuid import UUID, uuid4

logger = logging.getLogger(__name__)


class SettingsService:
    """Service for managing settings across all tiers.

    Attributes:
        global_settings_repo: Global settings repository (Tier 2)
        org_settings_repo: Organization settings repository (Tier 3)
        instance_repo: Orchestrator instance repository (Instance config)
        pool: Orchestrator pool (for triggering reloads)
    """

    def __init__(
        self,
        global_settings_repo: Any,
        org_settings_repo: Any,
        instance_repo: Any,
        pool: Optional[Any] = None,
    ):
        """Initialize settings service.

        Args:
            global_settings_repo: Global settings repository
            org_settings_repo: Organization settings repository
            instance_repo: Orchestrator instance repository
            pool: Optional orchestrator pool
        """
        self.global_settings_repo = global_settings_repo
        self.org_settings_repo = org_settings_repo
        self.instance_repo = instance_repo
        self.pool = pool

    async def get_global_setting(self, key: str) -> Optional[Any]:
        """Get global setting value (Tier 2).

        Args:
            key: Setting key

        Returns:
            Setting value or None if not found
        """
        setting = await self.global_settings_repo.get_by_key(key)
        return setting.value if setting else None

    async def set_global_setting(
        self,
        key: str,
        value: Any,
        description: Optional[str] = None,
    ) -> None:
        """Set global setting (Tier 2).

        Args:
            key: Setting key
            value: Setting value
            description: Optional description
        """
        logger.info(f"Setting global setting: {key}")

        await self.global_settings_repo.upsert(
            key=key,
            value=value,
            description=description,
        )

    async def list_global_settings(self) -> list:
        """List all global settings (Tier 2).

        Returns:
            List of setting dictionaries
        """
        settings = await self.global_settings_repo.get_all()
        return [
            {
                "key": s.key,
                "value": s.value,
                "value_type": s.value_type,
                "description": s.description or "",
            }
            for s in settings
        ]

    async def update_global_setting(
        self, key: str, value: Any
    ) -> Optional[dict[str, Any]]:
        """Update existing global setting (Tier 2).

        Args:
            key: Setting key
            value: New setting value

        Returns:
            Updated setting or None if not found
        """
        existing = await self.global_settings_repo.get_by_key(key)

        if not existing:
            return None

        await self.set_global_setting(key, value, existing.description)

        return await self.global_settings_repo.get_by_key(key)

    async def delete_global_setting(self, key: str) -> None:
        """Delete global setting (Tier 2).

        Args:
            key: Setting key
        """
        logger.info(f"Deleting global setting: {key}")

        await self.global_settings_repo.delete(key)

    async def get_tenant_setting(self, org_id: str, key: str) -> Optional[Any]:
        """Get tenant setting value (Tier 3).

        Args:
            org_id: Organization ID
            key: Setting key

        Returns:
            Setting value or None if not found
        """
        setting = await self.org_settings_repo.get_by_key(org_id, key)
        return setting.value if setting else None

    async def set_tenant_setting(
        self,
        org_id: str,
        key: str,
        value: Any,
    ) -> None:
        """Set tenant setting (Tier 3).

        Args:
            org_id: Organization ID
            key: Setting key
            value: Setting value
        """
        logger.info(f"Setting tenant setting: {org_id}/{key}")

        await self.org_settings_repo.upsert(
            org_id=org_id,
            key=key,
            value=value,
        )

    async def list_tenant_settings(self, org_id: str) -> dict[str, Any]:
        """List all tenant settings (Tier 3).

        Args:
            org_id: Organization ID

        Returns:
            Dict mapping setting keys to values
        """
        settings = await self.org_settings_repo.get_all_for_org(org_id)

        return {s.key: s.value for s in settings}

    async def delete_tenant_setting(self, org_id: str, key: str) -> None:
        """Delete tenant setting (Tier 3).

        Args:
            org_id: Organization ID
            key: Setting key
        """
        logger.info(f"Deleting tenant setting: {org_id}/{key}")

        await self.org_settings_repo.delete(org_id, key)

    async def create_instance(
        self,
        org_id: str,
        instance_id: str,
        framework_type: str,
        mode: str,
        instance_config: dict[str, Any],
        tier: str = "cold",
        plugin_settings: Optional[dict[str, Any]] = None,
        config_hash: Optional[str] = None,
        caller_id: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create new orchestrator instance.

        Args:
            org_id: Organization ID
            instance_id: Instance ID (unused by repo — repo generates UUID)
            framework_type: Orchestration framework (immutable after creation)
            mode: Orchestration mode (immutable after creation)
            instance_config: Mutable instance configuration
            tier: Pool tier (hot/warm/cold)
            plugin_settings: Per-plugin default settings
            config_hash: SHA-256 hash of config+plugin_settings
            caller_id: User ID performing the operation

        Returns:
            Created instance data
        """
        logger.info(
            f"Creating instance for org {org_id} with framework={framework_type} mode={mode} tier={tier}"
        )

        clean_config = {
            k: v
            for k, v in instance_config.items()
            if k not in ("framework_type", "mode", "instance_id", "org_id", "status")
        }

        return await self.instance_repo.create(
            org_id=org_id,
            name=instance_config.get("name", ""),
            framework_type=framework_type,
            mode=mode,
            config=clean_config,
            tier=tier,
            plugin_settings=plugin_settings or {},
            config_hash=config_hash,
            caller_id=caller_id,
        )

    async def list_instances_for_org(self, org_id: str) -> list:
        """List all instances for organization.

        Args:
            org_id: Organization ID

        Returns:
            List of instance dictionaries
        """
        return await self.instance_repo.list_for_org(org_id)

    async def get_instance_config(self, instance_id: str) -> Optional[dict[str, Any]]:
        """Get instance configuration (Instance config).

        Args:
            instance_id: Instance ID

        Returns:
            Instance data or None if not found
        """
        return await self.instance_repo.get_by_id(instance_id)

    async def delete_instance(self, instance_id: str) -> None:
        """Soft-delete orchestrator instance (sets status to 'deleted').

        Args:
            instance_id: Instance ID
        """
        logger.info(f"Soft-deleting instance: {instance_id}")
        await self.update_instance_status(instance_id, "deleted")

    async def update_instance_status(
        self,
        instance_id: str,
        status: str,
        caller_id: Optional[str] = None,
    ) -> dict[str, Any]:
        """Update instance status (active, suspended, deleted).

        Soft-delete (status='deleted') removes the instance from the pool.

        Args:
            instance_id: Instance ID
            status: New status
            caller_id: User ID performing the operation

        Returns:
            Updated instance data
        """
        logger.info(f"Updating instance {instance_id} status to {status}")

        if status == "deleted" and self.pool:
            try:
                await self.pool.remove_instance(instance_id)
            except Exception:
                pass

        await self.instance_repo.update_status(instance_id, status, caller_id=caller_id)
        return await self.instance_repo.get_by_id(instance_id)

    async def update_instance_config(
        self,
        instance_id: str,
        new_config: dict[str, Any],
        trigger_reload: bool = True,
        caller_id: Optional[str] = None,
    ) -> dict[str, Any]:
        """Update instance configuration (Instance config).

        framework_type and mode are immutable and cannot be changed via this method.
        Triggers orchestrator reload if pool is available.

        Args:
            instance_id: Instance ID
            new_config: New configuration
            trigger_reload: Whether to trigger pool reload (default: True)
            caller_id: User ID performing the operation

        Returns:
            Updated instance data

        Raises:
            ValueError: If new_config contains immutable fields (framework_type, mode)
        """
        immutable = {"framework_type", "mode"} & new_config.keys()
        if immutable:
            raise ValueError(f"Cannot modify immutable fields: {sorted(immutable)}")

        logger.info(f"Updating instance config: {instance_id}")

        await self.instance_repo.update_config(
            instance_id, new_config, caller_id=caller_id
        )

        if trigger_reload and self.pool:
            instance = await self.instance_repo.get_by_id(instance_id)

            if instance:
                from cadence.config.settings_resolver import SettingsResolver

                resolver = SettingsResolver(
                    instance_id=UUID(instance_id),
                    global_settings_repo=self.global_settings_repo,
                    org_settings_repo=self.org_settings_repo,
                    instance_repo=self.instance_repo,
                )

                resolved_config = await resolver.get_all()

                await self.pool.reload_instance(
                    instance_id=instance_id,
                    org_id=instance["org_id"],
                    framework_type=instance["framework_type"],
                    mode=instance["mode"],
                    instance_config=instance["config"],
                    resolved_config=resolved_config,
                )

        return await self.instance_repo.get_by_id(instance_id)

    @staticmethod
    def compute_config_hash(
        config: Dict[str, Any], plugin_settings: Dict[str, Any]
    ) -> str:
        """Compute SHA-256[:16] hash of config + plugin_settings.

        Args:
            config: Instance mutable configuration
            plugin_settings: Per-plugin settings dict

        Returns:
            16-character hex hash string
        """
        payload = json.dumps(
            {"config": config, "plugin_settings": plugin_settings},
            sort_keys=True,
            default=str,
        )
        return hashlib.sha256(payload.encode()).hexdigest()[:16]

    async def update_instance_plugin_settings(
        self,
        instance_id: str,
        plugin_settings: dict[str, Any],
        config_hash: str,
        caller_id: Optional[str] = None,
    ) -> dict[str, Any]:
        """Update plugin_settings and config_hash on an instance.

        Args:
            instance_id: Instance identifier
            plugin_settings: New plugin settings dict
            config_hash: New config hash
            caller_id: User ID performing the operation

        Returns:
            Updated instance dict
        """
        return await self.instance_repo.update_plugin_settings(
            instance_id=instance_id,
            plugin_settings=plugin_settings,
            config_hash=config_hash,
            caller_id=caller_id,
        )

    async def create_orchestrator_instance(
        self,
        org_id: str,
        framework_type: str,
        mode: str,
        active_plugins: List[str],
        tier: str,
        name: str,
        extra_config: Optional[Dict[str, Any]],
        plugin_service: Any,
        caller_id: Optional[str] = None,
        event_publisher: Optional[Any] = None,
    ) -> dict[str, Any]:
        """Create an orchestrator instance with plugin settings and optional load event.

        Args:
            org_id: Organization identifier
            framework_type: Orchestration framework (immutable)
            mode: Orchestration mode (immutable)
            active_plugins: List of plugin PIDs
            tier: Pool tier (hot/warm/cold)
            name: Instance name
            extra_config: Additional mutable config fields
            plugin_service: PluginService instance for resolving plugin rows
            caller_id: User ID performing the operation
            event_publisher: Optional event publisher for hot-tier load events

        Returns:
            Created instance dict
        """
        mutable_config = {
            "name": name,
            "active_plugins": active_plugins,
            **(extra_config or {}),
        }
        mutable_config.pop("framework_type", None)
        mutable_config.pop("mode", None)

        system_rows, org_rows = await plugin_service.resolve_plugin_rows(
            active_plugins, org_id
        )
        plugin_settings = plugin_service.build_initial_plugin_settings(
            active_plugins=active_plugins,
            system_repo_rows=system_rows,
            org_repo_rows=org_rows,
        )

        config_hash = self.compute_config_hash(mutable_config, plugin_settings)

        created_instance = await self.create_instance(
            org_id=org_id,
            instance_id=str(uuid4()),
            framework_type=framework_type,
            mode=mode,
            instance_config=mutable_config,
            tier=tier,
            plugin_settings=plugin_settings,
            config_hash=config_hash,
            caller_id=caller_id,
        )

        if tier == "hot" and event_publisher:
            try:
                await event_publisher.publish_load(
                    instance_id=created_instance["instance_id"],
                    org_id=org_id,
                    tier="hot",
                )
            except Exception as e:
                logger.warning(f"Failed to publish load event: {e}")

        return created_instance

    async def update_orchestrator_config(
        self,
        instance_id: str,
        org_id: str,
        new_config: dict[str, Any],
        caller_id: Optional[str] = None,
        event_publisher: Optional[Any] = None,
    ) -> dict[str, Any]:
        """Update orchestrator config, recompute hash, and publish reload event.

        Args:
            instance_id: Instance identifier
            org_id: Expected organization owner (access control)
            new_config: Full new mutable configuration
            caller_id: User ID performing the operation
            event_publisher: Optional event publisher for reload events

        Returns:
            Updated instance dict

        Raises:
            ValueError: If instance not found, deleted, wrong org, or immutable fields present
        """
        instance = await self.get_instance_config(instance_id)
        if not instance:
            raise ValueError(f"Instance {instance_id} not found")
        if instance.get("status") == "deleted":
            raise ValueError(f"Instance {instance_id} has been deleted")
        if instance.get("org_id") != org_id:
            raise ValueError("Access denied to this instance")

        updated_instance = await self.update_instance_config(
            instance_id=instance_id,
            new_config=new_config,
            trigger_reload=False,
            caller_id=caller_id,
        )

        plugin_settings = updated_instance.get("plugin_settings", {})
        new_hash = self.compute_config_hash(new_config, plugin_settings)

        updated_instance = await self.update_instance_plugin_settings(
            instance_id=instance_id,
            plugin_settings=plugin_settings,
            config_hash=new_hash,
            caller_id=caller_id,
        )

        if event_publisher:
            try:
                await event_publisher.publish_reload(
                    instance_id=instance_id,
                    org_id=org_id,
                    config_hash=new_hash,
                )
            except Exception as e:
                logger.warning(f"Failed to publish reload event: {e}")

        return updated_instance

    async def update_orchestrator_plugin_settings(
        self,
        instance_id: str,
        org_id: str,
        plugin_settings_override: dict[str, Any],
        caller_id: Optional[str] = None,
        event_publisher: Optional[Any] = None,
    ) -> dict[str, Any]:
        """Merge plugin setting overrides, recompute hash, and publish reload if hot.

        Args:
            instance_id: Instance identifier
            org_id: Expected organization owner (access control)
            plugin_settings_override: Map of pid -> {key: value} to merge
            caller_id: User ID performing the operation
            event_publisher: Optional event publisher for reload events

        Returns:
            Updated instance dict

        Raises:
            ValueError: If instance not found or access denied
        """
        instance = await self.get_instance_config(instance_id)
        if not instance:
            raise ValueError(f"Instance {instance_id} not found")
        if instance.get("org_id") != org_id:
            raise ValueError("Access denied to this instance")

        from cadence.service.plugin_service import PluginService

        merged = PluginService.merge_plugin_settings(
            instance.get("plugin_settings"), plugin_settings_override
        )
        new_hash = self.compute_config_hash(instance["config"], merged)

        updated = await self.update_instance_plugin_settings(
            instance_id=instance_id,
            plugin_settings=merged,
            config_hash=new_hash,
            caller_id=caller_id,
        )

        if event_publisher and instance.get("tier") == "hot":
            try:
                await event_publisher.publish_reload(
                    instance_id=instance_id,
                    org_id=org_id,
                    config_hash=new_hash,
                )
            except Exception as e:
                logger.warning(f"Failed to publish reload event: {e}")

        return updated

    async def sync_orchestrator_plugin_settings(
        self,
        instance_id: str,
        org_id: str,
        plugin_service: Any,
        caller_id: Optional[str] = None,
        event_publisher: Optional[Any] = None,
    ) -> dict[str, Any]:
        """Re-fetch latest plugin defaults, overwrite plugin_settings, recompute hash.

        Args:
            instance_id: Instance identifier
            org_id: Expected organization owner (access control)
            plugin_service: PluginService instance for resolving plugin rows
            caller_id: User ID performing the operation
            event_publisher: Optional event publisher for reload events

        Returns:
            Updated instance dict

        Raises:
            ValueError: If instance not found or access denied
        """
        instance = await self.get_instance_config(instance_id)
        if not instance:
            raise ValueError(f"Instance {instance_id} not found")
        if instance.get("org_id") != org_id:
            raise ValueError("Access denied to this instance")

        active_plugins = instance.get("config", {}).get("active_plugins", [])
        system_rows, org_rows = await plugin_service.resolve_plugin_rows(
            active_plugins, org_id
        )
        fresh_settings = plugin_service.build_initial_plugin_settings(
            active_plugins=active_plugins,
            system_repo_rows=system_rows,
            org_repo_rows=org_rows,
        )
        new_hash = self.compute_config_hash(instance["config"], fresh_settings)

        updated = await self.update_instance_plugin_settings(
            instance_id=instance_id,
            plugin_settings=fresh_settings,
            config_hash=new_hash,
            caller_id=caller_id,
        )

        if event_publisher and instance.get("tier") == "hot":
            try:
                await event_publisher.publish_reload(
                    instance_id=instance_id,
                    org_id=org_id,
                    config_hash=new_hash,
                )
            except Exception as e:
                logger.warning(f"Failed to publish reload event: {e}")

        logger.info(f"Plugin settings synced for {instance_id}")
        return updated
