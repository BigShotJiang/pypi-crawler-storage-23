"""Tenant service for managing organizations, settings, and user memberships.

Provides organization CRUD, org settings, LLM configurations, and
user/membership management for the multi-tenant platform.
"""

import logging
from typing import Any, Dict, List, Optional

from cadence.infrastructure.persistence.postgresql.models import UserOrgMembership
from cadence.repository.repositories import (
    OrchestratorInstanceRepository,
    UserOrgMembershipRepository,
    UserRepository,
)

logger = logging.getLogger(__name__)


def _org_to_dict(org: Any) -> Dict[str, Any]:
    """Convert Organization ORM instance to API response dict.

    Args:
        org: Organization ORM instance

    Returns:
        Dict with org_id, name, status, created_at (ISO string)
    """
    return {
        "org_id": org.org_id,
        "name": org.name,
        "status": org.status,
        "created_at": org.created_at.isoformat() if org.created_at else "",
    }


def _setting_to_response(setting: Any) -> Dict[str, Any]:
    """Convert OrganizationSettings ORM to API response format.

    Args:
        setting: OrganizationSettings instance (key, value attributes)

    Returns:
        Dict with key, value, value_type for TenantSettingResponse
    """
    key = setting.key if hasattr(setting, "key") else setting["key"]
    value = setting.value if hasattr(setting, "value") else setting["value"]
    value_type = _infer_value_type(value)
    return {"key": key, "value": value, "value_type": value_type}


def _infer_value_type(value: Any) -> str:
    """Infer API value_type from Python type."""
    type_map = {
        str: "string",
        int: "number",
        float: "number",
        bool: "boolean",
        dict: "object",
        list: "array",
    }
    return type_map.get(type(value), "string")


class TenantService:
    """Service for managing organizations and user memberships.

    Attributes:
        org_repo: Organization repository
        org_settings_repo: Organization settings repository
        org_llm_config_repo: Organization LLM config repository
        user_repo: User repository
        membership_repo: User-org membership repository
        instance_repo: Orchestrator instance repository (used for LLM in-use checks)
    """

    def __init__(
        self,
        org_repo: Any,
        org_settings_repo: Any,
        org_llm_config_repo: Any,
        user_repo: UserRepository = None,
        membership_repo: UserOrgMembershipRepository = None,
        instance_repo: OrchestratorInstanceRepository = None,
    ):
        self.org_repo = org_repo
        self.org_settings_repo = org_settings_repo
        self.org_llm_config_repo = org_llm_config_repo
        self.user_repo = user_repo
        self.membership_repo = membership_repo
        self.instance_repo = instance_repo

    async def create_org(
        self,
        name: str,
        org_id: Optional[str] = None,
        caller_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a new organization.

        Args:
            name: Organization display name
            org_id: Organization identifier (auto-generated if not provided)
            caller_id: User ID performing the operation

        Returns:
            Created organization data
        """
        if org_id is None:
            from uuid import uuid4

            org_id = str(uuid4())
        logger.info(f"Creating organization: {org_id}")
        org = await self.org_repo.create(org_id=org_id, name=name, caller_id=caller_id)
        return _org_to_dict(org)

    async def get_org(self, org_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve organization by ID.

        Args:
            org_id: Organization identifier

        Returns:
            Organization data or None if not found
        """
        org = await self.org_repo.get_by_id(org_id)
        return _org_to_dict(org) if org else None

    async def list_orgs(self) -> List[Dict[str, Any]]:
        """List all organizations.

        Returns:
            List of organization data
        """
        orgs = await self.org_repo.get_all()
        return [_org_to_dict(o) for o in orgs]

    async def list_orgs_for_user(self, user_id: str) -> List[Dict[str, Any]]:
        """List active orgs the given user belongs to, including their role.

        Args:
            user_id: User identifier

        Returns:
            List of org dicts with an extra 'role' key ('org_admin' or 'member'),
            sorted by org_id
        """
        memberships = await self.membership_repo.list_for_user(user_id)
        result = []
        for m in memberships:
            org = await self.org_repo.get_by_id(m.org_id)
            if org and org.status == "active":
                entry = _org_to_dict(org)
                entry["role"] = "org_admin" if m.is_admin else "member"
                result.append(entry)
        return sorted(result, key=lambda x: x["org_id"])

    async def update_org(
        self,
        org_id: str,
        updates: Dict[str, Any],
        caller_id: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Update organization with partial updates.

        Args:
            org_id: Organization identifier
            updates: Dictionary of fields to update
            caller_id: User ID performing the operation

        Returns:
            Updated organization data or None
        """
        logger.info(f"Updating organization: {org_id}")
        org = await self.org_repo.update(org_id, updates)
        return _org_to_dict(org) if org else None

    async def delete_org(self, org_id: str) -> None:
        """Delete organization permanently.

        Args:
            org_id: Organization identifier
        """
        logger.info(f"Deleting organization: {org_id}")
        await self.org_repo.delete(org_id)

    async def get_setting(self, org_id: str, key: str) -> Optional[Any]:
        """Get a single organization setting value.

        Args:
            org_id: Organization identifier
            key: Setting key

        Returns:
            Setting value or None if not found
        """
        setting = await self.org_settings_repo.get_by_key(org_id, key)
        if not setting:
            return None
        return setting.value if hasattr(setting, "value") else setting.get("value")

    async def set_setting(
        self,
        org_id: str,
        key: str,
        value: Any,
        caller_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create or update an organization setting.

        Args:
            org_id: Organization identifier
            key: Setting key
            value: Setting value
            caller_id: User ID performing the operation

        Returns:
            Created or updated setting data (key, value, value_type)
        """
        logger.info(f"Setting organization setting: {org_id}/{key}")
        setting = await self.org_settings_repo.upsert(
            org_id=org_id,
            key=key,
            value=value,
            caller_id=caller_id,
        )
        return _setting_to_response(setting)

    async def list_settings(self, org_id: str) -> List[Dict[str, Any]]:
        """List all organization settings.

        Args:
            org_id: Organization identifier

        Returns:
            List of setting dicts with key, value, value_type
        """
        settings = await self.org_settings_repo.get_all_for_org(org_id)
        return [_setting_to_response(s) for s in settings]

    async def delete_setting(self, org_id: str, key: str) -> None:
        """Delete an organization setting.

        Args:
            org_id: Organization identifier
            key: Setting key
        """
        logger.info(f"Deleting organization setting: {org_id}/{key}")
        await self.org_settings_repo.delete(org_id, key)

    async def add_llm_config(
        self,
        org_id: str,
        name: str,
        provider: str,
        api_key: str,
        base_url: Optional[str] = None,
        additional_config: Optional[Dict[str, Any]] = None,
        caller_id: Optional[str] = None,
    ) -> Any:
        """Add LLM configuration for organization.

        Args:
            org_id: Organization ID
            name: Config name
            provider: Provider name (openai, anthropic, google, etc.)
            api_key: API key
            base_url: Optional base URL for provider
            additional_config: Optional provider-specific extra settings
            caller_id: User ID performing the operation

        Returns:
            Created LLM config ORM object
        """
        logger.info(f"Adding LLM config for org {org_id}: {provider}/{name}")
        return await self.org_llm_config_repo.create(
            org_id=org_id,
            name=name,
            provider=provider,
            api_key=api_key,
            base_url=base_url,
            additional_config=additional_config or {},
            caller_id=caller_id,
        )

    async def list_llm_configs(self, org_id: str) -> List[Any]:
        """List organization's LLM configurations (API key masked at controller).

        Args:
            org_id: Organization ID

        Returns:
            List of LLM config ORM objects (non-deleted only)
        """
        return await self.org_llm_config_repo.get_all_for_org(
            org_id, include_deleted=False
        )

    async def delete_llm_config(
        self,
        org_id: str,
        name: str,
        caller_id: Optional[str] = None,
    ) -> bool:
        """Soft-delete an LLM configuration.

        Raises ValueError if any active orchestrator instance in the org
        still references this config by name.

        Args:
            org_id: Organization ID
            name: Config name
            caller_id: User ID performing the operation

        Returns:
            True if deleted

        Raises:
            ValueError: If the config is still referenced by active orchestrators
        """
        logger.info(f"Deleting LLM config: {org_id}/{name}")

        if self.instance_repo is not None:
            count = await self.instance_repo.count_using_llm_config(org_id, name)
            if count > 0:
                raise ValueError(
                    f"LLM config '{name}' is still referenced by {count} active "
                    "orchestrator instance(s). Remove or update those instances first."
                )

        return await self.org_llm_config_repo.soft_delete(
            org_id=org_id, name=name, caller_id=caller_id
        )

    # ------------------------------------------------------------------
    # User management
    # ------------------------------------------------------------------

    @staticmethod
    def serialize_user(user: Any) -> Dict[str, Any]:
        """Serialize a User ORM instance to a plain dict."""
        return {
            "user_id": user.user_id,
            "username": user.username,
            "email": user.email,
            "is_sys_admin": bool(user.is_sys_admin),
            "is_deleted": bool(user.is_deleted),
            "deleted_at": (user.deleted_at.isoformat() if user.deleted_at else None),
            "created_at": (user.created_at.isoformat() if user.created_at else None),
        }

    @staticmethod
    def _serialize_membership(membership: UserOrgMembership) -> Dict[str, Any]:
        """Serialize a UserOrgMembership ORM instance to a plain dict."""
        return {
            "user_id": membership.user_id,
            "org_id": membership.org_id,
            "is_admin": bool(membership.is_admin),
            "created_at": (
                membership.created_at.isoformat() if membership.created_at else None
            ),
        }

    async def create_user(
        self,
        username: str,
        user_id: Optional[str] = None,
        email: Optional[str] = None,
        password: Optional[str] = None,
        is_sys_admin: bool = False,
        caller_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a new platform user (not bound to any org).

        Args:
            username: Globally unique username
            user_id: User identifier (auto-generated if not provided)
            email: Optional email address
            password: Raw password string
            is_sys_admin: Platform-wide admin flag
            caller_id: User ID performing the operation

        Returns:
            Created user data (serialized)
        """
        if user_id is None:
            from uuid import uuid4

            user_id = str(uuid4())
        logger.info(f"Creating user {username}")
        password_hash = self._create_password_hash(password)

        user = await self.user_repo.create(
            user_id=user_id,
            username=username,
            email=email,
            is_sys_admin=is_sys_admin,
            password_hash=password_hash,
            caller_id=caller_id,
        )
        return self.serialize_user(user)

    @staticmethod
    def _create_password_hash(password: str | None) -> Any:
        password_hash = None
        if password:
            from passlib.context import CryptContext

            ctx = CryptContext(schemes=["argon2"], deprecated="auto")
            password_hash = ctx.hash(password)
        return password_hash

    async def add_user_to_org(
        self,
        user_id: str,
        org_id: str,
        is_admin: bool = False,
        caller_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Add an existing user to an organization.

        Args:
            user_id: User identifier
            org_id: Organization identifier
            is_admin: Whether the user should be an org admin
            caller_id: User ID performing the operation

        Returns:
            Membership data (serialized)
        """
        logger.info(f"Adding user {user_id} to org {org_id} is_admin={is_admin}")
        membership = await self.membership_repo.create(
            user_id=user_id,
            org_id=org_id,
            is_admin=is_admin,
            caller_id=caller_id,
        )
        return self._serialize_membership(membership)

    async def update_org_membership(
        self,
        user_id: str,
        org_id: str,
        is_admin: bool,
        caller_id: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Update the admin flag for an existing org membership.

        Args:
            user_id: User identifier
            org_id: Organization identifier
            is_admin: New admin value
            caller_id: User ID performing the operation

        Returns:
            Updated membership data or None if not found
        """
        logger.info(f"Updating membership {user_id}/{org_id} is_admin={is_admin}")
        membership = await self.membership_repo.update_admin_flag(
            user_id=user_id,
            org_id=org_id,
            is_admin=is_admin,
            caller_id=caller_id,
        )
        return self._serialize_membership(membership) if membership else None

    async def remove_user_from_org(self, user_id: str, org_id: str) -> bool:
        """Hard-delete the user's membership in this org.

        Args:
            user_id: User identifier
            org_id: Organization identifier

        Returns:
            True if removed, False if not found
        """
        logger.info(f"Removing user {user_id} from org {org_id}")
        return await self.membership_repo.delete(user_id=user_id, org_id=org_id)

    async def list_org_members(self, org_id: str) -> List[Dict[str, Any]]:
        """List all members of an organization with their user details.

        Only returns entries where the user account is not soft-deleted.

        Args:
            org_id: Organization identifier

        Returns:
            List of dicts with user + membership data
        """
        memberships = await self.membership_repo.list_for_org(org_id)
        result = []
        for m in memberships:
            user = await self.user_repo.get_by_id(m.user_id)
            if user and not user.is_deleted:
                entry = self.serialize_user(user)
                entry["is_admin"] = m.is_admin
                result.append(entry)
        return result

    async def delete_user(self, user_id: str, caller_id: Optional[str] = None) -> bool:
        """Soft-delete a user and hard-delete all their org memberships.

        Args:
            user_id: User identifier
            caller_id: User ID performing the operation

        Returns:
            True if deleted, False if not found
        """
        logger.info(f"Soft-deleting user {user_id}")
        deleted = await self.user_repo.delete(user_id, caller_id=caller_id)
        if deleted and self.membership_repo:
            await self.membership_repo.delete_all_for_user(user_id)
        return deleted

    async def search_user(
        self,
        user_id: Optional[str] = None,
        email: Optional[str] = None,
        username: Optional[str] = None,
        requester_is_sys_admin: bool = False,
    ) -> Optional[Dict[str, Any]]:
        """Look up a single user by id, email, or username (first non-None wins).

        Args:
            user_id: Exact user ID to look up
            email: Exact email address to look up
            username: Exact username to look up
            requester_is_sys_admin: Whether the requester has sys_admin rights

        Returns:
            Serialized user dict with is_admin=False, or None if not found/hidden
        """
        if user_id:
            user = await self.user_repo.get_by_id(user_id)
        elif email:
            user = await self.user_repo.get_by_email(email)
        else:
            user = await self.user_repo.get_by_username(username)

        if not user or user.is_deleted:
            return None
        if user.is_sys_admin and not requester_is_sys_admin:
            return None

        user_dict = self.serialize_user(user)
        user_dict["is_admin"] = False
        return user_dict

    async def list_all_users(self) -> List[Dict[str, Any]]:
        """List all non-deleted platform users.

        Returns:
            List of serialized user dicts with is_admin=False
        """
        users = await self.user_repo.list_all()
        result = []
        for u in users:
            user_dict = self.serialize_user(u)
            user_dict["is_admin"] = False
            result.append(user_dict)
        return result

    async def update_user(
        self,
        user_id: str,
        username: Optional[str] = None,
        email: Optional[str] = None,
        is_sys_admin: Optional[bool] = None,
        caller_id: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Update a platform user's username, email, or sys_admin flag.

        Args:
            user_id: User identifier
            username: New username or None to leave unchanged
            email: New email or None to leave unchanged
            is_sys_admin: New sys_admin flag or None to leave unchanged
            caller_id: User ID performing the operation

        Returns:
            Updated user dict with is_admin=False, or None if not found
        """
        user = await self.user_repo.update(
            user_id=user_id,
            username=username,
            email=email,
            is_sys_admin=is_sys_admin,
            caller_id=caller_id,
        )
        if not user:
            return None
        user_dict = self.serialize_user(user)
        user_dict["is_admin"] = False
        return user_dict

    async def add_existing_user_to_org(
        self,
        org_id: str,
        user_id: str,
        is_admin: bool = False,
        caller_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Validate that a user exists and add them to an organization.

        Args:
            org_id: Organization identifier
            user_id: Existing user identifier
            is_admin: Whether the user should be an org admin
            caller_id: User ID performing the operation

        Returns:
            Serialized user dict with is_admin set

        Raises:
            ValueError: If user not found or soft-deleted
        """
        user = await self.user_repo.get_by_id(user_id)
        if not user or user.is_deleted:
            raise ValueError(f"User {user_id} not found")

        await self.add_user_to_org(
            user_id=user_id,
            org_id=org_id,
            is_admin=is_admin,
            caller_id=caller_id,
        )
        user_dict = self.serialize_user(user)
        user_dict["is_admin"] = is_admin
        return user_dict

    async def get_org_member(
        self, org_id: str, user_id: str
    ) -> Optional[Dict[str, Any]]:
        """Get a user's details and their admin flag within an org.

        Args:
            org_id: Organization identifier
            user_id: User identifier

        Returns:
            Serialized user dict with is_admin set, or None if not found
        """
        user = await self.user_repo.get_by_id(user_id)
        if not user:
            return None
        memberships = await self.membership_repo.list_for_user(user_id)
        membership = next((m for m in memberships if m.org_id == org_id), None)
        if not membership:
            return None
        user_dict = self.serialize_user(user)
        user_dict["is_admin"] = membership.is_admin
        return user_dict
