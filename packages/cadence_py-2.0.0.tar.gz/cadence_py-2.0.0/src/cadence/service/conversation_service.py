"""Conversation service for managing conversation history.

This module provides conversation management using MongoDB for messages
and PostgreSQL for conversation metadata.
"""

import logging
from typing import Any, Dict, List
from uuid import uuid4

from cadence_sdk.types.sdk_messages import UvMessage

from cadence.constants import DEFAULT_MESSAGES_LIMIT
from cadence.repository.conversation_store import (
    ConversationStore,
)

logger = logging.getLogger(__name__)


class ConversationService:
    """Service for managing conversations and message history.

    Attributes:
        mongo_store: MongoDB conversation store
        postgres_repo: PostgreSQL conversation repository
    """

    def __init__(
        self,
        mongo_store: ConversationStore,
        postgres_repo: Any,
    ):
        """Initialize conversation service.

        Args:
            mongo_store: MongoDB conversation store
            postgres_repo: PostgreSQL conversation repository
        """
        self.mongo_store = mongo_store
        self.postgres_repo = postgres_repo

    async def get_history(
        self,
        org_id: str,
        conversation_id: str,
        limit: int = DEFAULT_MESSAGES_LIMIT,
    ) -> List[UvMessage]:
        """Get conversation message history.

        Args:
            org_id: Organization ID
            conversation_id: Conversation ID
            limit: Maximum messages to retrieve

        Returns:
            List of messages in chronological order
        """
        logger.debug(
            f"Loading conversation history: {conversation_id} (limit: {limit})"
        )

        messages = await self.mongo_store.get_messages(
            org_id=org_id,
            conversation_id=conversation_id,
            limit=limit,
        )

        return messages

    async def save_message(
        self,
        org_id: str,
        conversation_id: str,
        message: UvMessage,
    ) -> None:
        """Save message to conversation history.

        Args:
            org_id: Organization ID
            conversation_id: Conversation ID
            message: Message to save
        """
        logger.debug(f"Saving message to conversation: {conversation_id}")

        await self.mongo_store.save_message(
            org_id=org_id,
            conversation_id=conversation_id,
            message=message,
        )

    async def create_conversation(
        self,
        org_id: str,
        user_id: str,
        instance_id: str,
    ) -> str:
        """Create new conversation.

        Args:
            org_id: Organization ID
            user_id: User ID
            instance_id: Orchestrator instance ID

        Returns:
            Created conversation ID
        """
        conversation_id = str(uuid4())

        logger.info(f"Creating conversation: {conversation_id}")

        await self.postgres_repo.create(
            conversation_id=conversation_id,
            org_id=org_id,
            user_id=user_id,
            instance_id=instance_id,
        )

        return conversation_id

    async def list_conversations(
        self,
        org_id: str,
        user_id: str,
    ) -> List[Dict[str, Any]]:
        """List user's conversations.

        Args:
            org_id: Organization ID
            user_id: User ID

        Returns:
            List of conversation metadata
        """
        logger.debug(f"Listing conversations for user: {user_id}")

        conversations = await self.postgres_repo.list_for_user(
            org_id=org_id,
            user_id=user_id,
        )

        return conversations

    async def delete_conversation(
        self,
        org_id: str,
        conversation_id: str,
    ) -> None:
        """Delete conversation and all messages.

        Args:
            org_id: Organization ID
            conversation_id: Conversation ID
        """
        logger.info(f"Deleting conversation: {conversation_id}")

        await self.mongo_store.delete_conversation(
            org_id=org_id,
            conversation_id=conversation_id,
        )

        await self.postgres_repo.delete(conversation_id)
