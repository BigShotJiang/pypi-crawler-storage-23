"""Settings resolution across 3-tier hierarchy.

Resolves configuration settings from three tiers with cascade:
Instance config → Organization settings → Global settings (DB)

Higher tiers override lower tiers. This enables flexible configuration
where instance-specific settings can override organization defaults,
which can override global settings (platform floor).
"""

from typing import Any, Optional
from uuid import UUID

from cadence.constants import (
    SETTINGS_TIER_GLOBAL,
    SETTINGS_TIER_INSTANCE,
    SETTINGS_TIER_ORG,
)


class SettingsResolver:
    """Resolves settings across 3-tier hierarchy.

    Cascade order (highest → lowest priority):
    - Instance config: per-instance overrides stored in orchestrator_instances.config
    - Organization settings: per-tenant overrides in organization_settings table
    - Global settings: platform floor, DB-backed, admin-editable via RabbitMQ broadcast

    Attributes:
        instance_id: Orchestrator instance identifier
        org_id: Organization identifier, derived lazily from instance if not provided
        global_repo: Global settings repository
        org_repo: Organization settings repository
        instance_repo: Orchestrator instance repository
    """

    def __init__(
        self,
        instance_id: UUID,
        global_settings_repo: Any,
        org_settings_repo: Any,
        instance_repo: Any,
        org_id: Optional[str] = None,
    ):
        self.instance_id = instance_id
        self.org_id = org_id
        self.global_repo = global_settings_repo
        self.org_repo = org_settings_repo
        self.instance_repo = instance_repo

        self._instance_cache: Optional[dict[str, Any]] = None
        self._org_cache: Optional[dict[str, Any]] = None
        self._global_cache: Optional[dict[str, Any]] = None

    async def get(self, key: str, default: Any = None) -> Any:
        """Get setting value with cascade resolution.

        Checks tiers in order: Instance → Organization → Global
        Returns first match found, or default if not found in any tier.

        Args:
            key: Setting key
            default: Default value if not found

        Returns:
            Setting value from highest priority tier
        """
        value = await self._get_from_instance(key)
        if value is not None:
            return value

        value = await self._get_from_org(key)
        if value is not None:
            return value

        value = await self._get_from_global(key)
        if value is not None:
            return value

        return default

    async def get_all(self) -> dict[str, Any]:
        """Get all settings merged from all tiers.

        Tiers are merged with priority: Instance > Organization > Global

        Returns:
            Dictionary of all settings
        """
        global_settings = await self._get_all_from_global()
        org_settings = await self._get_all_from_org()
        instance_settings = await self._get_all_from_instance()

        merged = {**global_settings, **org_settings, **instance_settings}
        return merged

    async def _get_from_instance(self, key: str) -> Optional[Any]:
        """Get from Instance config (highest priority)."""
        if self._instance_cache is None:
            await self._load_instance()

        return self._instance_cache.get(key)

    async def _get_from_org(self, key: str) -> Optional[Any]:
        """Get from Organization settings."""
        if self._org_cache is None:
            await self._load_org()

        return self._org_cache.get(key)

    async def _get_from_global(self, key: str) -> Optional[Any]:
        """Get from Global settings (platform floor)."""
        if self._global_cache is None:
            await self._load_global()

        return self._global_cache.get(key)

    async def _get_all_from_instance(self) -> dict[str, Any]:
        """Get all settings from Instance config."""
        if self._instance_cache is None:
            await self._load_instance()

        return self._instance_cache.copy()

    async def _get_all_from_org(self) -> dict[str, Any]:
        """Get all settings from Organization settings."""
        if self._org_cache is None:
            await self._load_org()

        return self._org_cache.copy()

    async def _get_all_from_global(self) -> dict[str, Any]:
        """Get all settings from Global settings."""
        if self._global_cache is None:
            await self._load_global()

        return self._global_cache.copy()

    async def _load_instance(self) -> None:
        """Load Instance config into cache."""
        instance = await self.instance_repo.get_by_id(self.instance_id)

        if instance:
            if self.org_id is None:
                self.org_id = instance.get("org_id")
            self._instance_cache = instance.get("config") or {}
        else:
            self._instance_cache = {}

    async def _load_org(self) -> None:
        """Load Organization settings into cache."""
        settings = await self.org_repo.get_all_for_org(self.org_id)

        self._org_cache = {setting.key: setting.value for setting in settings}

    async def _load_global(self) -> None:
        """Load Global settings into cache."""
        settings = await self.global_repo.get_all()

        self._global_cache = {setting.key: setting.value for setting in settings}

    def invalidate_cache(self, tier: Optional[str] = None) -> None:
        """Invalidate cached settings.

        Args:
            tier: Tier to invalidate ("instance", "org", "global"), or None for all tiers
        """
        if tier is None or tier == SETTINGS_TIER_INSTANCE:
            self._instance_cache = None

        if tier is None or tier == SETTINGS_TIER_ORG:
            self._org_cache = None

        if tier is None or tier == SETTINGS_TIER_GLOBAL:
            self._global_cache = None
