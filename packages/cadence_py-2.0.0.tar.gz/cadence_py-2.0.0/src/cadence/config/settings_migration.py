"""Settings migration for Global settings defaults.

Automatically inserts missing Global settings with default values
when new settings are added to the codebase. This ensures backward
compatibility when new configuration options are introduced.

Global settings are the platform floor — admin-editable via the API,
broadcast to all nodes via RabbitMQ on change. All operational defaults
live here; .env is infrastructure config only (immutable).
"""

from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from cadence.repository.repositories import (
    GlobalSettingsRepository,
)


class SettingsMigration:
    """Migrates Global settings from code-defined defaults.

    Compares code-defined settings schema against database,
    inserting missing keys with default values.

    Attributes:
        repository: Global settings repository
    """

    def __init__(self, repository: GlobalSettingsRepository):
        self.repository = repository

    async def migrate(
        self, schema: dict[str, dict[str, Any]]
    ) -> tuple[list[str], list[str]]:
        """Migrate settings from schema to database.

        Args:
            schema: Settings schema dictionary where key is setting name
                and value is dict with 'default', 'type', 'description'

        Returns:
            Tuple of (inserted_keys, updated_keys)
        """
        existing_settings = await self.repository.get_all()
        existing_keys = {setting.key for setting in existing_settings}

        inserted_keys = []
        updated_keys = []

        for key, config in schema.items():
            if key not in existing_keys:
                await self.repository.upsert(
                    key=key,
                    value=config["default"],
                    value_type=config["type"],
                    description=config.get("description"),
                )
                inserted_keys.append(key)

        return inserted_keys, updated_keys

    async def run(self) -> None:
        """Run settings migration with default schema.

        This is a convenience method for the most common use case.
        """
        schema = self.get_default_schema()
        inserted, updated = await self.migrate(schema)

        if inserted:
            print(f"Settings migration: inserted {len(inserted)} new settings")

        if updated:
            print(f"Settings migration: updated {len(updated)} settings")

    @staticmethod
    def get_default_schema() -> dict[str, dict[str, Any]]:
        """Get default Tier 2 settings schema.

        Returns:
            Dictionary mapping setting keys to their configuration
        """
        return {
            "max_agent_hops": {
                "default": 10,
                "type": "int",
                "description": "Maximum number of agent routing hops",
            },
            "max_tool_execution_time": {
                "default": 30,
                "type": "int",
                "description": "Maximum tool execution time in seconds",
            },
            "enable_semantic_cache": {
                "default": False,
                "type": "bool",
                "description": "Enable semantic caching for tool results",
            },
            "semantic_cache_similarity_threshold": {
                "default": 0.7,
                "type": "float",
                "description": "Similarity threshold for semantic cache matches",
            },
            "default_llm_temperature": {
                "default": 0.7,
                "type": "float",
                "description": "Default temperature for LLM requests",
            },
            "default_llm_max_tokens": {
                "default": 4096,
                "type": "int",
                "description": "Default max tokens for LLM responses",
            },
            "max_hot_pool_size": {
                "default": 200,
                "type": "int",
                "description": "Maximum number of orchestrators in hot tier",
            },
            "prewarm_strategy": {
                "default": "recent",
                "type": "str",
                "description": "Pool prewarming strategy (recent, all, none)",
            },
            "prewarm_count": {
                "default": 100,
                "type": "int",
                "description": "Number of instances to prewarm when using 'recent' strategy",
            },
            "warm_tier_ttl": {
                "default": 3600,
                "type": "int",
                "description": "Warm tier TTL in seconds before eviction to cold",
            },
            "health_check_interval": {
                "default": 60,
                "type": "int",
                "description": "Health check interval in seconds",
            },
            "rate_limit_requests_per_minute": {
                "default": 60,
                "type": "int",
                "description": "Default rate limit for API requests",
            },
            "consecutive_agent_route_limit": {
                "default": 3,
                "type": "int",
                "description": "Max consecutive routes to same agent before suspension",
            },
            "message_compaction_threshold": {
                "default": 10000,
                "type": "int",
                "description": "Character threshold for message compaction",
            },
            "enable_message_compaction": {
                "default": False,
                "type": "bool",
                "description": "Enable automatic message compaction",
            },
            # Pool operational settings
            "pool_refresh_interval": {
                "default": 300,
                "type": "int",
                "description": "Pool config refresh interval in seconds",
            },
            # LLM defaults
            "default_llm_provider": {
                "default": "openai",
                "type": "str",
                "description": "Default LLM provider",
            },
            "default_model_name": {
                "default": "gpt-4o",
                "type": "str",
                "description": "Default model name",
            },
            "llm_request_timeout": {
                "default": 60,
                "type": "int",
                "description": "LLM request timeout in seconds",
            },
            "llm_max_retries": {
                "default": 3,
                "type": "int",
                "description": "LLM retry attempts",
            },
            "llm_retry_delay": {
                "default": 1,
                "type": "int",
                "description": "Delay between retries in seconds",
            },
            # Caching
            "semantic_cache_provider": {
                "default": "redis",
                "type": "str",
                "description": "Cache backend (redis/mongodb)",
            },
            "semantic_cache_ttl": {
                "default": 3600,
                "type": "int",
                "description": "Cache TTL in seconds",
            },
            "embedding_provider": {
                "default": "openai",
                "type": "str",
                "description": "Embedding model provider",
            },
            "embedding_model": {
                "default": "text-embedding-3-small",
                "type": "str",
                "description": "Embedding model name",
            },
            # Rate limiting
            "enable_rate_limiting": {
                "default": True,
                "type": "bool",
                "description": "Enable API rate limiting",
            },
            "rate_limit_window": {
                "default": 60,
                "type": "int",
                "description": "Rate limit window in seconds",
            },
            "rate_limit_burst": {
                "default": 10,
                "type": "int",
                "description": "Burst allowance on top of base rate",
            },
            # Conversation management
            "max_conversation_history": {
                "default": 100,
                "type": "int",
                "description": "Max messages in conversation history",
            },
            "message_compaction_mode": {
                "default": "tool",
                "type": "str",
                "description": "Compaction mode (none/tool/system/all)",
            },
            "conversation_retention_days": {
                "default": 90,
                "type": "int",
                "description": "Conversation data retention in days",
            },
            # Orchestrator settings
            "default_invoke_timeout": {
                "default": 300,
                "type": "int",
                "description": "Default orchestrator invoke timeout in seconds",
            },
            "default_parallel_tool_calls": {
                "default": True,
                "type": "bool",
                "description": "Enable parallel tool execution by default",
            },
            "enable_llm_validation": {
                "default": False,
                "type": "bool",
                "description": "Enable LLM validation node",
            },
            # Streaming
            "sse_heartbeat_interval": {
                "default": 30,
                "type": "int",
                "description": "SSE heartbeat interval in seconds",
            },
            "sse_timeout": {
                "default": 300,
                "type": "int",
                "description": "SSE connection timeout in seconds",
            },
            "default_enable_streaming": {
                "default": True,
                "type": "bool",
                "description": "Enable streaming by default",
            },
            # Checkpointing
            "enable_checkpointing": {
                "default": False,
                "type": "bool",
                "description": "Enable automatic LangGraph checkpointing",
            },
            "checkpoint_storage": {
                "default": "postgres",
                "type": "str",
                "description": "Checkpoint storage backend",
            },
            "checkpoint_retention": {
                "default": 10,
                "type": "int",
                "description": "Number of checkpoints to retain per conversation",
            },
            # Feature flags
            "enable_multi_tier_pool": {
                "default": True,
                "type": "bool",
                "description": "Enable hot/warm/cold pool optimization",
            },
            "enable_shared_resources": {
                "default": True,
                "type": "bool",
                "description": "Enable shared model/bundle registries",
            },
            "enable_hot_reload": {
                "default": True,
                "type": "bool",
                "description": "Enable hot-reload via API",
            },
            "enable_tenant_isolation": {
                "default": True,
                "type": "bool",
                "description": "Enable tenant isolation checks",
            },
        }


async def run_settings_migration(session: AsyncSession) -> None:
    """Run settings migration with default schema.

    This should be called during application startup.

    Args:
        session: Database session
    """
    migration = SettingsMigration(session)
    schema = SettingsMigration.get_default_schema()

    inserted, updated = await migration.migrate(schema)

    if inserted:
        print(f"Settings migration: inserted {len(inserted)} new settings: {inserted}")

    if updated:
        print(f"Settings migration: updated {len(updated)} settings: {updated}")
