"""Orchestrator instance management API endpoints.

Provides CRUD endpoints for managing orchestrator instances including
creation with tier support, configuration updates, load/unload, and
plugin settings management.
"""

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field

from cadence.middleware.permissions import require_org_admin_access, require_org_member
from cadence.middleware.tenant_context_middleware import TenantContext
from cadence.service.settings_service import SettingsService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/orgs/{org_id}/orchestrators", tags=["orchestrators"])


class CreateOrchestratorRequest(BaseModel):
    """Create orchestrator instance request."""

    name: str = Field(
        ...,
        min_length=10,
        max_length=200,
        description="Instance name",
    )
    framework_type: str = Field(
        ...,
        pattern="^(langgraph|openai_agents|google_adk)$",
        description="Orchestration framework — immutable after creation",
    )
    mode: str = Field(
        ...,
        pattern="^(supervisor|coordinator|handoff)$",
        description="Orchestration mode — immutable after creation",
    )
    active_plugins: List[str] = Field(
        ...,
        min_length=1,
        description=(
            "List of plugin PIDs to activate. "
            "Use plain 'pid' for latest or 'pid@version' to pin."
        ),
    )
    tier: str = Field(
        default="cold",
        pattern="^(hot|warm|cold)$",
        description="Pool tier — hot instances are loaded immediately",
    )
    config: Optional[Dict[str, Any]] = Field(
        default_factory=dict,
        description="Mutable instance-specific configuration (Tier 4 settings)",
    )

    class Config:
        json_schema_extra = {
            "example": {
                "name": "customer-support",
                "framework_type": "langgraph",
                "mode": "supervisor",
                "active_plugins": ["com.example.search"],
                "tier": "cold",
                "config": {
                    "primary_model": {
                        "llm_config_name": "primary",
                        "model_name": "gpt-4",
                        "temperature": 0.7,
                    },
                    "max_agent_hops": 10,
                },
            }
        }


class UpdateOrchestratorConfigRequest(BaseModel):
    """Update orchestrator configuration request."""

    config: Dict[str, Any] = Field(..., description="New mutable configuration")


class UpdateOrchestratorStatusRequest(BaseModel):
    """Update orchestrator status request."""

    status: str = Field(
        ...,
        pattern="^(active|suspended)$",
        description="New status — use DELETE endpoint for soft-delete",
    )


class LoadOrchestratorRequest(BaseModel):
    """Manual load orchestrator request."""

    tier: str = Field(
        default="hot",
        pattern="^(hot|warm|cold)$",
        description="Target tier for loading",
    )


class UpdatePluginSettingsRequest(BaseModel):
    """Partial update of plugin settings."""

    plugin_settings: Dict[str, Any] = Field(
        ...,
        description="Map of pid -> {id, name, settings: [{key, name, value}]} to merge into existing plugin_settings",
    )


class OrchestratorResponse(BaseModel):
    """Orchestrator instance response."""

    instance_id: str
    org_id: str
    name: str
    framework_type: str
    mode: str
    status: str
    config: Dict[str, Any]
    tier: str = "cold"
    plugin_settings: Dict[str, Any] = {}
    config_hash: Optional[str] = None
    created_at: str
    updated_at: str


@router.post(
    "",
    response_model=OrchestratorResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create Orchestrator Instance",
)
async def create_orchestrator(
    create_request: CreateOrchestratorRequest,
    request: Request,
    context: TenantContext = Depends(require_org_admin_access),
):
    """Create new orchestrator instance.

    Builds plugin_settings from catalog defaults and computes config_hash.
    If tier='hot', publishes a load event to RabbitMQ.

    Args:
        create_request: Instance configuration including name, framework_type, mode, plugins, and tier
        request: FastAPI request
        context: org_admin or sys_admin context

    Returns:
        Created orchestrator instance

    Raises:
        HTTPException: 500 if creation fails
    """
    settings_service: SettingsService = request.app.state.settings_service
    plugin_service = request.app.state.plugin_service
    event_publisher = getattr(request.app.state, "event_publisher", None)

    try:
        created_instance = await settings_service.create_orchestrator_instance(
            org_id=context.org_id,
            framework_type=create_request.framework_type,
            mode=create_request.mode,
            active_plugins=create_request.active_plugins,
            tier=create_request.tier,
            name=create_request.name,
            extra_config=create_request.config,
            plugin_service=plugin_service,
            caller_id=context.user_id,
            event_publisher=event_publisher,
        )
        return OrchestratorResponse(**created_instance)

    except Exception as e:
        logger.error(f"Failed to create orchestrator: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create orchestrator instance",
        )


@router.get("", response_model=List[OrchestratorResponse])
async def list_orchestrators(
    request: Request,
    context: TenantContext = Depends(require_org_member),
):
    """List all orchestrator instances for this organization.

    Args:
        request: FastAPI request
        context: org_admin or sys_admin context

    Returns:
        List of orchestrator instances

    Raises:
        HTTPException: 500 if retrieval fails
    """
    settings_service: SettingsService = request.app.state.settings_service

    try:
        instances = await settings_service.list_instances_for_org(context.org_id)
        return [OrchestratorResponse(**instance) for instance in instances]
    except Exception as e:
        logger.error(f"Failed to list orchestrators: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list orchestrator instances",
        )


@router.get("/{instance_id}", response_model=OrchestratorResponse)
async def get_orchestrator(
    instance_id: str,
    request: Request,
    context: TenantContext = Depends(require_org_admin_access),
):
    """Get orchestrator instance details.

    Args:
        instance_id: Instance identifier
        request: FastAPI request
        context: org_admin or sys_admin context

    Returns:
        Orchestrator instance details

    Raises:
        HTTPException: 403 if access denied, 404 if not found, 410 if deleted, 500 on failure
    """
    settings_service: SettingsService = request.app.state.settings_service

    try:
        instance = await settings_service.get_instance_config(instance_id)

        if not instance:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Instance {instance_id} not found",
            )
        if instance["status"] == "deleted":
            raise HTTPException(
                status_code=status.HTTP_410_GONE,
                detail=f"Instance {instance_id} has been deleted",
            )
        if instance["org_id"] != context.org_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to this instance",
            )

        return OrchestratorResponse(**instance)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get orchestrator: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve orchestrator instance",
        )


@router.patch("/{instance_id}/config", response_model=OrchestratorResponse)
async def update_orchestrator_config(
    instance_id: str,
    update_request: UpdateOrchestratorConfigRequest,
    request: Request,
    context: TenantContext = Depends(require_org_admin_access),
):
    """Update orchestrator configuration.

    Recomputes config_hash and publishes orchestrator.reload event.

    Args:
        instance_id: Instance identifier
        update_request: New configuration dict
        request: FastAPI request
        context: org_admin or sys_admin context

    Returns:
        Updated orchestrator instance

    Raises:
        HTTPException: 422 if config is invalid, 500 on failure
    """
    settings_service: SettingsService = request.app.state.settings_service
    event_publisher = getattr(request.app.state, "event_publisher", None)

    try:
        updated = await settings_service.update_orchestrator_config(
            instance_id=instance_id,
            org_id=context.org_id,
            new_config=update_request.config,
            caller_id=context.user_id,
            event_publisher=event_publisher,
        )
        logger.info(f"Orchestrator {instance_id} configuration updated")
        return OrchestratorResponse(**updated)

    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Failed to update orchestrator config: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update orchestrator configuration",
        )


@router.patch("/{instance_id}/status", response_model=OrchestratorResponse)
async def update_orchestrator_status(
    instance_id: str,
    status_request: UpdateOrchestratorStatusRequest,
    request: Request,
    context: TenantContext = Depends(require_org_admin_access),
):
    """Update orchestrator status (active or suspended).

    Args:
        instance_id: Instance identifier
        status_request: New status value
        request: FastAPI request
        context: org_admin or sys_admin context

    Returns:
        Updated orchestrator instance

    Raises:
        HTTPException: 403 if access denied, 404 if not found, 410 if deleted, 500 on failure
    """
    settings_service: SettingsService = request.app.state.settings_service

    try:
        instance = await settings_service.get_instance_config(instance_id)

        if not instance:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Instance {instance_id} not found",
            )
        if instance["status"] == "deleted":
            raise HTTPException(
                status_code=status.HTTP_410_GONE,
                detail=f"Instance {instance_id} has been deleted",
            )
        if instance["org_id"] != context.org_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to this instance",
            )

        updated = await settings_service.update_instance_status(
            instance_id, status_request.status, caller_id=context.user_id
        )

        logger.info(
            f"Orchestrator {instance_id} status updated to {status_request.status}"
        )
        return OrchestratorResponse(**updated)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to update orchestrator status: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update orchestrator status",
        )


@router.delete("/{instance_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_orchestrator(
    instance_id: str,
    request: Request,
    context: TenantContext = Depends(require_org_admin_access),
):
    """Soft-delete orchestrator instance (sets status to 'deleted').

    Args:
        instance_id: Instance identifier
        request: FastAPI request
        context: org_admin or sys_admin context

    Raises:
        HTTPException: 403 if access denied, 404 if not found, 410 if already deleted, 500 on failure
    """
    settings_service: SettingsService = request.app.state.settings_service

    try:
        instance = await settings_service.get_instance_config(instance_id)

        if not instance:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Instance {instance_id} not found",
            )
        if instance["status"] == "deleted":
            raise HTTPException(
                status_code=status.HTTP_410_GONE,
                detail=f"Instance {instance_id} is already deleted",
            )
        if instance["org_id"] != context.org_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to this instance",
            )

        await settings_service.delete_instance(instance_id)
        logger.info(f"Orchestrator {instance_id} soft-deleted")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to delete orchestrator: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete orchestrator instance",
        )


@router.post("/{instance_id}/load", status_code=status.HTTP_202_ACCEPTED)
async def load_orchestrator(
    instance_id: str,
    load_request: LoadOrchestratorRequest = None,
    request: Request = None,
    context: TenantContext = Depends(require_org_admin_access),
):
    """Fire-and-forget: publish orchestrator.load event.

    Args:
        instance_id: Instance ID
        load_request: Optional load parameters (tier)
        request: FastAPI request
        context: Tenant context from JWT

    Returns:
        202 Accepted
    """
    settings_service: SettingsService = request.app.state.settings_service

    try:
        instance = await settings_service.get_instance_config(instance_id)

        if not instance:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Instance {instance_id} not found",
            )
        if instance["org_id"] != context.org_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to this instance",
            )

        tier = (load_request.tier if load_request else None) or instance.get(
            "tier", "hot"
        )

        event_publisher = getattr(request.app.state, "event_publisher", None)
        if event_publisher:
            await event_publisher.publish_load(
                instance_id=instance_id,
                org_id=context.org_id,
                tier=tier,
            )
        else:
            logger.warning("No event_publisher available — load event not published")

        return {"message": "Load event published", "instance_id": instance_id}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Failed to publish load event for {instance_id}: {e}", exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to publish load event",
        )


@router.post("/{instance_id}/unload", status_code=status.HTTP_202_ACCEPTED)
async def unload_orchestrator(
    instance_id: str,
    request: Request,
    context: TenantContext = Depends(require_org_admin_access),
):
    """Fire-and-forget: publish orchestrator.unload event.

    Args:
        instance_id: Instance ID
        request: FastAPI request
        context: Tenant context from JWT

    Returns:
        202 Accepted
    """
    settings_service: SettingsService = request.app.state.settings_service

    try:
        instance = await settings_service.get_instance_config(instance_id)

        if not instance:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Instance {instance_id} not found",
            )
        if instance["org_id"] != context.org_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to this instance",
            )

        event_publisher = getattr(request.app.state, "event_publisher", None)
        if event_publisher:
            await event_publisher.publish_unload(instance_id=instance_id)
        else:
            logger.warning("No event_publisher available — unload event not published")

        return {"message": "Unload event published", "instance_id": instance_id}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Failed to publish unload event for {instance_id}: {e}", exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to publish unload event",
        )


@router.patch("/{instance_id}/plugin-settings", response_model=OrchestratorResponse)
async def update_plugin_settings(
    instance_id: str,
    update_request: UpdatePluginSettingsRequest,
    request: Request,
    context: TenantContext = Depends(require_org_admin_access),
):
    """Partial update of plugin settings (merge into existing).

    Recomputes config_hash and publishes reload event if instance is hot.

    Args:
        instance_id: Instance identifier
        update_request: Plugin settings override map (pid -> {key: value})
        request: FastAPI request
        context: org_admin or sys_admin context

    Returns:
        Updated orchestrator instance

    Raises:
        HTTPException: 422 if settings are invalid, 500 on failure
    """
    settings_service: SettingsService = request.app.state.settings_service
    event_publisher = getattr(request.app.state, "event_publisher", None)

    try:
        updated = await settings_service.update_orchestrator_plugin_settings(
            instance_id=instance_id,
            org_id=context.org_id,
            plugin_settings_override=update_request.plugin_settings,
            caller_id=context.user_id,
            event_publisher=event_publisher,
        )
        return OrchestratorResponse(**updated)

    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail=str(e),
        )
    except Exception as e:
        logger.error(
            f"Failed to update plugin settings for {instance_id}: {e}", exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update plugin settings",
        )


@router.put("/{instance_id}/plugin-settings/sync", response_model=OrchestratorResponse)
async def sync_plugin_settings(
    instance_id: str,
    request: Request,
    context: TenantContext = Depends(require_org_admin_access),
):
    """Re-fetch latest default_settings for all active plugins and overwrite plugin_settings.

    User customizations are lost. Recomputes config_hash and publishes reload if hot.

    Args:
        instance_id: Instance identifier
        request: FastAPI request
        context: org_admin or sys_admin context

    Returns:
        Updated orchestrator instance with synced plugin settings

    Raises:
        HTTPException: 422 if sync fails validation, 500 on failure
    """
    settings_service: SettingsService = request.app.state.settings_service
    plugin_service = request.app.state.plugin_service
    event_publisher = getattr(request.app.state, "event_publisher", None)

    try:
        updated = await settings_service.sync_orchestrator_plugin_settings(
            instance_id=instance_id,
            org_id=context.org_id,
            plugin_service=plugin_service,
            caller_id=context.user_id,
            event_publisher=event_publisher,
        )
        return OrchestratorResponse(**updated)

    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail=str(e),
        )
    except Exception as e:
        logger.error(
            f"Failed to sync plugin settings for {instance_id}: {e}", exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to sync plugin settings",
        )
