"""Messaging infrastructure for Cadence."""
