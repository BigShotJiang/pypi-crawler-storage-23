"""LLM provider registry and configuration classes.

Defines provider-specific configuration and instantiation for
all supported LLM providers. Each provider class knows how to
create LangChain chat model instances with provider-specific parameters.
"""

from abc import ABC, abstractmethod
from typing import Dict, Optional, Type

from langchain_core.language_models import BaseChatModel


class LLMProvider(ABC):
    """Base class for LLM provider configuration.

    Each provider implementation knows how to create chat models
    for that specific provider with correct parameters.
    """

    @staticmethod
    @abstractmethod
    def create_model(
        model_name: str,
        api_key: str,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **kwargs,
    ) -> BaseChatModel:
        """Create chat model instance.

        Args:
            model_name: Model identifier
            api_key: API key for authentication
            temperature: Sampling temperature
            max_tokens: Maximum tokens in response
            **kwargs: Provider-specific parameters

        Returns:
            BaseChatModel instance
        """
        pass


class OpenAIProvider(LLMProvider):
    """OpenAI provider (GPT-4, GPT-3.5, etc.)."""

    @staticmethod
    def create_model(
        model_name: str,
        api_key: str,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        base_url: Optional[str] = None,
        **kwargs,
    ) -> BaseChatModel:
        """Create OpenAI chat model."""
        from langchain_openai import ChatOpenAI

        return ChatOpenAI(
            model=model_name,
            api_key=api_key,
            temperature=temperature,
            max_tokens=max_tokens,
            base_url=base_url,
            **kwargs,
        )


class AnthropicProvider(LLMProvider):
    """Anthropic provider (Claude models)."""

    @staticmethod
    def create_model(
        model_name: str,
        api_key: str,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **kwargs,
    ) -> BaseChatModel:
        """Create Anthropic chat model."""
        from langchain_anthropic import ChatAnthropic

        return ChatAnthropic(
            model=model_name,
            api_key=api_key,
            temperature=temperature,
            max_tokens=max_tokens,
            **kwargs,
        )


class GoogleProvider(LLMProvider):
    """Google AI provider (Gemini models)."""

    @staticmethod
    def create_model(
        model_name: str,
        api_key: str,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **kwargs,
    ) -> BaseChatModel:
        """Create Google AI chat model."""
        from langchain_google_genai import ChatGoogleGenerativeAI

        return ChatGoogleGenerativeAI(
            model=model_name,
            google_api_key=api_key,
            temperature=temperature,
            max_output_tokens=max_tokens,
            **kwargs,
        )


class AzureProvider(LLMProvider):
    """Azure OpenAI provider."""

    @staticmethod
    def create_model(
        model_name: str,
        api_key: str,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        azure_endpoint: Optional[str] = None,
        deployment_name: Optional[str] = None,
        api_version: str = "2024-02-15-preview",
        **kwargs,
    ) -> BaseChatModel:
        """Create Azure OpenAI chat model."""
        from langchain_openai import AzureChatOpenAI

        return AzureChatOpenAI(
            deployment_name=deployment_name or model_name,
            azure_endpoint=azure_endpoint,
            api_key=api_key,
            api_version=api_version,
            temperature=temperature,
            max_tokens=max_tokens,
            **kwargs,
        )


class GroqProvider(LLMProvider):
    """Groq provider (fast inference)."""

    @staticmethod
    def create_model(
        model_name: str,
        api_key: str,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **kwargs,
    ) -> BaseChatModel:
        """Create Groq chat model."""
        from langchain_groq import ChatGroq

        return ChatGroq(
            model=model_name,
            api_key=api_key,
            temperature=temperature,
            max_tokens=max_tokens,
            **kwargs,
        )


class OpenAICompatibleProvider(LLMProvider):
    """OpenAI-compatible provider (for custom endpoints)."""

    @staticmethod
    def create_model(
        model_name: str,
        api_key: str,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        base_url: Optional[str] = None,
        **kwargs,
    ) -> BaseChatModel:
        """Create OpenAI-compatible chat model."""
        from langchain_openai import ChatOpenAI

        if not base_url:
            raise ValueError("base_url is required for OpenAI-compatible provider")

        return ChatOpenAI(
            model=model_name,
            api_key=api_key,
            temperature=temperature,
            max_tokens=max_tokens,
            base_url=base_url,
            **kwargs,
        )


PROVIDER_REGISTRY: Dict[str, Type[LLMProvider]] = {
    "openai": OpenAIProvider,
    "anthropic": AnthropicProvider,
    "google": GoogleProvider,
    "azure": AzureProvider,
    "groq": GroqProvider,
    "openai_compatible": OpenAICompatibleProvider,
}


def get_provider_class(provider_name: str) -> Type[LLMProvider]:
    """Get provider class by name.

    Args:
        provider_name: Provider identifier

    Returns:
        LLMProvider class

    Raises:
        ValueError: If provider not found
    """
    provider_class = PROVIDER_REGISTRY.get(provider_name.lower())

    if provider_class is None:
        available = ", ".join(PROVIDER_REGISTRY.keys())
        raise ValueError(
            f"Unknown provider: {provider_name}. " f"Available providers: {available}"
        )

    return provider_class


def register_provider(name: str, provider_class: Type[LLMProvider]) -> None:
    """Register custom provider.

    Args:
        name: Provider identifier
        provider_class: LLMProvider implementation
    """
    PROVIDER_REGISTRY[name.lower()] = provider_class
