"""LLM model factory with BYOK (Bring Your Own Key).

Creates LLM model instances from tenant-provided configurations.
The platform provides NO default API keys - tenants must provide their own.

Supports fallback chains for reliability and multi-provider setups.
"""

from typing import Any, Dict, Optional

from langchain_core.language_models import BaseChatModel

from cadence.repository.repositories import (
    OrganizationLLMConfigRepository,
)

from .providers import get_provider_class


class LLMModelFactory:
    """Factory for creating LLM model instances with BYOK.

    Resolves API keys from organization LLM configurations and
    creates chat model instances with provider-specific parameters.

    Attributes:
        llm_config_repo: Repository for LLM configurations
    """

    def __init__(self, llm_config_repo: OrganizationLLMConfigRepository):
        self.llm_config_repo = llm_config_repo

    async def create_model(
        self,
        org_id: str,
        provider: str,
        model_name: str,
        api_key: Optional[str] = None,
        config_name: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **provider_params,
    ) -> BaseChatModel:
        """Create LLM model instance.

        Args:
            org_id: Organization identifier
            provider: Provider name (openai, anthropic, google, etc.)
            model_name: Model identifier
            api_key: Optional API key (if not provided, loads from config_name)
            config_name: Configuration name in organization LLM configs
            temperature: Sampling temperature
            max_tokens: Maximum tokens in response
            **provider_params: Provider-specific parameters

        Returns:
            BaseChatModel instance

        Raises:
            ValueError: If API key not provided and config not found
        """
        resolved_api_key = await self._resolve_api_key(
            org_id, api_key, config_name, provider
        )

        provider_class = get_provider_class(provider)

        model = provider_class.create_model(
            model_name=model_name,
            api_key=resolved_api_key,
            temperature=temperature,
            max_tokens=max_tokens,
            **provider_params,
        )

        return model

    async def create_model_with_fallback(
        self,
        model_config: Dict[str, Any],
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> BaseChatModel:
        """Create model from a config dict with temperature and token overrides.

        Args:
            model_config: Model configuration dict with keys: org_id, provider,
                model_name, and optionally api_key / config_name
            temperature: Sampling temperature
            max_tokens: Maximum tokens in response

        Returns:
            BaseChatModel instance
        """
        return await self.create_model(
            org_id=model_config.get("org_id", ""),
            provider=model_config.get("provider", ""),
            model_name=model_config.get("model_name", ""),
            api_key=model_config.get("api_key"),
            config_name=model_config.get("config_name"),
            temperature=temperature,
            max_tokens=max_tokens,
        )

    async def _resolve_api_key(
        self,
        org_id: str,
        api_key: Optional[str],
        config_name: Optional[str],
        provider: str,
    ) -> str:
        """Resolve API key from multiple sources.

        Args:
            org_id: Organization identifier
            api_key: Directly provided API key
            config_name: Configuration name to load from database
            provider: Provider name for error messaging

        Returns:
            Resolved API key

        Raises:
            ValueError: If API key cannot be resolved
        """
        if api_key:
            return api_key

        if config_name:
            config = await self.llm_config_repo.get_by_name(org_id, config_name)

            if not config:
                raise ValueError(
                    f"LLM configuration '{config_name}' not found for organization {org_id}"
                )

            return self._decrypt_api_key(config.api_key)

        active_configs = await self.llm_config_repo.get_all_for_org(
            org_id, include_deleted=False
        )

        for config in active_configs:
            if config.provider.lower() == provider.lower():
                return self._decrypt_api_key(config.api_key)

        raise ValueError(
            f"No API key provided and no active {provider} configuration found "
            f"for organization {org_id}. "
            "BYOK (Bring Your Own Key) is required - please configure your API key."
        )

    def _decrypt_api_key(self, encrypted_key: str) -> str:
        """Decrypt API key from storage.

        For MVP, this is a placeholder. In production, implement
        proper encryption/decryption using a key management service.

        Args:
            encrypted_key: Encrypted API key

        Returns:
            Decrypted API key
        """
        return encrypted_key

    def _encrypt_api_key(self, api_key: str) -> str:
        """Encrypt API key for storage.

        For MVP, this is a placeholder. In production, implement
        proper encryption using a key management service.

        Args:
            api_key: Plain API key

        Returns:
            Encrypted API key
        """
        return api_key
