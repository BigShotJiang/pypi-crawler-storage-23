"""S3/MinIO object storage persistence layer."""

from .client import S3Client

__all__ = ["S3Client"]
