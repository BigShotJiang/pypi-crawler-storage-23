"""Persistence layer.

This package provides database adapters for PostgreSQL, MongoDB, and Redis.
"""
