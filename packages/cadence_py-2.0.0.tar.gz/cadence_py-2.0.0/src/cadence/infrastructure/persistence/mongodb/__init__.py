"""MongoDB database layer for conversation storage.

Uses database-per-organization strategy for tenant isolation.
Each organization gets its own MongoDB database: cadence_{org_id}
"""

from cadence.repository.conversation_store import ConversationStore

from .client import MongoDBClient

__all__ = [
    "MongoDBClient",
    "ConversationStore",
]
