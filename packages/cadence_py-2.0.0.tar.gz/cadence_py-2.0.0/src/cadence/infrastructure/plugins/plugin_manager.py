"""Plugin discovery, validation, and bundle management.

This module provides the SDKPluginManager for loading and managing plugin bundles.
Each bundle contains all resources needed for a plugin to execute in an orchestrator.
"""

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from cadence_sdk.base.agent import BaseAgent
from cadence_sdk.base.metadata import PluginMetadata
from cadence_sdk.registry.contracts import PluginContract
from cadence_sdk.types.sdk_tools import UvTool
from cadence_sdk.utils.directory_discovery import DirectoryPluginDiscovery
from cadence_sdk.utils.validation import validate_plugin_structure

from cadence.constants import DEFAULT_MAX_TOKENS, DEFAULT_TEMPERATURE
from cadence.engine.base import OrchestratorAdapter
from cadence.infrastructure.plugins.plugin_settings_resolver import (
    PluginSettingsResolver,
)

logger = logging.getLogger(__name__)


def _parse_plugin_spec(spec: str) -> tuple[str, str | None]:
    """Parse 'pid@version' or plain 'pid' spec.

    Returns (pid, version) where version is None if not specified.
    """
    if "@" in spec:
        pid, ver = spec.rsplit("@", 1)
        return pid.strip(), ver.strip()
    return spec, None


@dataclass
class SDKPluginBundle:
    """Complete plugin bundle ready for orchestrator use.

    Contains all resolved resources for a plugin including agent, tools,
    bound model, and orchestrator-native tools.

    Attributes:
        contract: Plugin contract from registry
        metadata: Plugin metadata
        agent: Initialized agent instance
        bound_model: LLM model with tools bound (for LangGraph)
        uvtools: List of SDK UvTool instances
        orchestrator_tools: List of orchestrator-native tools
        adapter: Adapter used for conversion
        tool_node: ToolNode for LangGraph (None for others)
        agent_node: Optional callable agent node
    """

    contract: PluginContract
    metadata: PluginMetadata
    agent: BaseAgent
    bound_model: Any
    uvtools: List[UvTool]
    orchestrator_tools: List[Any]
    adapter: OrchestratorAdapter
    tool_node: Optional[Any] = None
    agent_node: Optional[Any] = None


class SDKPluginManager:
    """Manager for plugin discovery, validation, and bundle creation.

    Handles complete plugin lifecycle:
    1. Discovery from environment, system, and tenant directories
    2. Validation (shallow, dependencies, deep, custom)
    3. Bundle creation with resolved settings and bound models

    Plugins are identified by their reverse-domain `pid`
    (e.g., `io.cadence.system.product_search`). All bundles and registry
    lookups use `pid` as the primary key.

    Attributes:
        adapter: Orchestrator adapter for type conversion
        llm_factory: LLM model factory
        org_id: Organization ID for tenant isolation
        tenant_plugins_root: Root directory for tenant plugins
        system_plugins_dir: System-wide plugins directory
        plugin_store: Optional PluginStore for S3-backed plugin downloads
        bundles: Dict mapping plugin pid to bundle
    """

    def __init__(
        self,
        adapter: OrchestratorAdapter,
        llm_factory: Any,
        org_id: str,
        tenant_plugins_root: str,
        system_plugins_dir: Optional[str] = None,
        plugin_store: Optional[Any] = None,
    ):
        """Initialize plugin manager.

        Args:
            adapter: Orchestrator adapter instance
            llm_factory: LLM model factory
            org_id: Organization ID
            tenant_plugins_root: Root directory for tenant plugins
            system_plugins_dir: Optional system plugins directory
            plugin_store: Optional PluginStore for S3-backed plugin downloads
        """
        self.adapter = adapter
        self.llm_factory = llm_factory
        self.org_id = org_id
        self.tenant_plugins_root = tenant_plugins_root
        self.system_plugins_dir = system_plugins_dir
        self.plugin_store = plugin_store
        self.bundles: Dict[str, SDKPluginBundle] = {}

    def discover_plugins(self) -> List[str]:
        """Discover plugins from all sources.

        Discovery order (with precedence by pid namespace):
        1. Tenant directory (highest priority)
        2. System directory
        3. Environment (pip-installed packages)

        Returns:
            List of discovered plugin pids
        """
        from cadence_sdk.registry.plugin_registry import PluginRegistry

        registry = PluginRegistry.instance()
        discovered: set = set()

        tenant_dir = Path(self.tenant_plugins_root) / self.org_id
        if tenant_dir.exists():
            tenant_discovery = DirectoryPluginDiscovery(str(tenant_dir))
            tenant_plugins = tenant_discovery.discover()
            discovered.update(plugin.pid for plugin in tenant_plugins)
            logger.info(
                f"Discovered {len(tenant_plugins)} tenant plugins for {self.org_id}"
            )

        if self.system_plugins_dir:
            system_dir = Path(self.system_plugins_dir)
            if system_dir.exists():
                system_discovery = DirectoryPluginDiscovery(str(system_dir))
                system_plugins = system_discovery.discover()
                system_pids = {plugin.pid for plugin in system_plugins}
                discovered.update(system_pids - discovered)
                logger.info(f"Discovered {len(system_plugins)} system plugins")

        env_plugins = registry.list_registered_plugins()
        env_pids = {plugin.pid for plugin in env_plugins}
        discovered.update(env_pids - discovered)

        logger.info(f"Total unique plugins discovered: {len(discovered)}")
        return list(discovered)

    async def load_plugins(
        self,
        plugin_pids: List[str],
        instance_config: Dict[str, Any],
    ) -> Dict[str, "SDKPluginBundle"]:
        """Load and create bundles for specified plugins.

        Args:
            plugin_pids: List of plugin pids to load (reverse-domain format)
            instance_config: Instance configuration dictionary

        Returns:
            Dict mapping plugin pid to bundle

        Raises:
            ValueError: If plugin validation fails or pid not found in registry
        """
        from cadence_sdk.registry.plugin_registry import PluginRegistry

        registry = PluginRegistry.instance()
        settings_resolver = PluginSettingsResolver(instance_config)

        for spec in plugin_pids:
            pid, requested_version = _parse_plugin_spec(spec)

            if pid in self.bundles:
                logger.debug(f"Plugin '{pid}' already loaded")
                continue

            if requested_version:
                contract = registry.get_plugin_by_version(pid, requested_version)
                if not contract:
                    logger.info(
                        f"Plugin '{pid}' v{requested_version} not in registry, "
                        f"trying filesystem"
                    )
                    contract = await self._load_versioned_plugin_from_filesystem(
                        pid, requested_version
                    )
                if not contract:
                    raise ValueError(
                        f"Plugin '{pid}' version '{requested_version}' not found "
                        f"in registry or plugin store"
                    )
            else:
                contract = registry.get_plugin(pid)
                if not contract:
                    raise ValueError(f"Plugin '{pid}' not found in registry")

                if self.plugin_store and self.plugin_store.s3_enabled:
                    try:
                        await self.plugin_store.ensure_local(
                            pid=pid,
                            version=contract.version,
                            org_id=self.org_id,
                        )
                    except FileNotFoundError:
                        logger.warning(
                            f"Plugin '{pid}' v{contract.version} not found in S3, "
                            f"using locally cached version"
                        )

            self._validate_plugin(contract)
            bundle = self._create_bundle(contract, settings_resolver)
            self.bundles[pid] = bundle
            logger.info(f"Loaded plugin bundle: {pid} v{contract.version}")

        return self.bundles

    async def _load_versioned_plugin_from_filesystem(
        self, pid: str, ver: str
    ) -> Optional["PluginContract"]:
        """Load a specific plugin version from the plugin store or local filesystem.

        Search order: tenant PluginStore → system PluginStore → tenant local dir
        → system local dir. Registers the loaded contract in the registry for
        future lookups.

        Args:
            pid: Plugin identifier
            ver: Exact version string

        Returns:
            PluginContract if found and loaded successfully, None otherwise
        """
        import importlib.util
        import sys

        from cadence_sdk.base import BasePlugin
        from cadence_sdk.registry.contracts import PluginContract as _PluginContract
        from cadence_sdk.registry.plugin_registry import PluginRegistry

        local_dir = None

        if self.plugin_store:
            try:
                local_dir = await self.plugin_store.ensure_local(pid, ver, self.org_id)
            except FileNotFoundError:
                try:
                    local_dir = await self.plugin_store.ensure_local(pid, ver, None)
                except FileNotFoundError:
                    pass

        if local_dir is None:
            tenant_path = Path(self.tenant_plugins_root) / self.org_id / pid / ver
            if tenant_path.exists() and any(tenant_path.iterdir()):
                local_dir = tenant_path
            elif self.system_plugins_dir:
                system_path = Path(self.system_plugins_dir) / pid / ver
                if system_path.exists() and any(system_path.iterdir()):
                    local_dir = system_path

        if local_dir is None:
            return None

        plugin_file = Path(local_dir) / "plugin.py"
        if not plugin_file.exists():
            return None

        module_name = f"_cadence_plugin_{pid.replace('.', '_')}_{ver.replace('.', '_')}"
        spec = importlib.util.spec_from_file_location(module_name, plugin_file)
        if spec is None or spec.loader is None:
            return None

        module = importlib.util.module_from_spec(spec)
        parent_dir = str(Path(local_dir).parent)
        sys.path.insert(0, parent_dir)
        try:
            spec.loader.exec_module(module)
        finally:
            if parent_dir in sys.path:
                sys.path.remove(parent_dir)

        plugin_class = None
        for attr_name in dir(module):
            attr = getattr(module, attr_name)
            if (
                isinstance(attr, type)
                and issubclass(attr, BasePlugin)
                and attr is not BasePlugin
            ):
                plugin_class = attr
                break

        if plugin_class is None:
            return None

        contract = _PluginContract(plugin_class)
        PluginRegistry.instance().register(plugin_class, override=False)
        return contract

    def get_bundle(self, pid: str) -> Optional["SDKPluginBundle"]:
        """Get loaded plugin bundle by pid.

        Args:
            pid: Reverse-domain plugin identifier

        Returns:
            Plugin bundle or None if not loaded
        """
        return self.bundles.get(pid)

    async def cleanup_all(self) -> None:
        """Cleanup all loaded plugins."""
        for pid, bundle in self.bundles.items():
            if hasattr(bundle.agent, "cleanup"):
                await bundle.agent.cleanup()
                logger.debug(f"Cleaned up plugin: {pid}")

        self.bundles.clear()

    def _validate_plugin(self, contract: PluginContract) -> None:
        """Validate plugin structure and dependencies.

        Args:
            contract: Plugin contract

        Raises:
            ValueError: If validation fails
        """
        is_valid, errors = validate_plugin_structure(contract.plugin_class)
        if not is_valid:
            raise ValueError(
                f"Plugin '{contract.pid}' validation failed: {'; '.join(errors)}"
            )

        if hasattr(contract.plugin_class, "validate_dependencies"):
            custom_errors = contract.plugin_class.validate_dependencies()
            if custom_errors:
                raise ValueError(
                    f"Plugin '{contract.pid}' dependency validation failed: {'; '.join(custom_errors)}"
                )

    def _create_bundle(
        self,
        contract: PluginContract,
        settings_resolver: PluginSettingsResolver,
    ) -> "SDKPluginBundle":
        """Create plugin bundle with all resources.

        Args:
            contract: Plugin contract
            settings_resolver: Settings resolver

        Returns:
            Complete plugin bundle
        """
        metadata = contract.plugin_class.get_metadata()
        agent = contract.plugin_class.create_agent()

        resolved_settings = settings_resolver.resolve(contract.pid, agent)
        if hasattr(agent, "initialize"):
            agent.initialize(resolved_settings)

        uvtools = agent.get_tools()
        orchestrator_tools = [
            self.adapter.uvtool_to_orchestrator(tool) for tool in uvtools
        ]

        model = self.llm_factory.create_model_with_fallback(
            model_config=resolved_settings.get("model_config", {}),
            temperature=resolved_settings.get("temperature", DEFAULT_TEMPERATURE),
            max_tokens=resolved_settings.get("max_tokens", DEFAULT_MAX_TOKENS),
        )

        bound_model = self.adapter.bind_tools_to_model(model, uvtools)

        tool_node = None
        if self.adapter.framework_type == "langgraph":
            tool_node = self.adapter.create_tool_node(uvtools)

        return SDKPluginBundle(
            contract=contract,
            metadata=metadata,
            agent=agent,
            bound_model=bound_model,
            uvtools=uvtools,
            orchestrator_tools=orchestrator_tools,
            adapter=self.adapter,
            tool_node=tool_node,
        )
