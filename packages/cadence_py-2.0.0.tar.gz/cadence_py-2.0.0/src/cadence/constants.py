"""Shared constants for Cadence framework.

Provides named constants for magic numbers and strings used across the codebase,
following CLEANCODE guidelines to avoid unexplained literals.
"""

DEFAULT_MAX_TOKENS = 2048
DEFAULT_TEMPERATURE = 0.7
DEFAULT_CONVERSATION_HISTORY_LIMIT = 50
DEFAULT_MESSAGES_LIMIT = 100
DEFAULT_CONVERSATIONS_LIST_LIMIT = 50
DEFAULT_MAX_TOOL_CHARS = 1000
REDIS_SCAN_BATCH_SIZE = 100
COLD_TIER_ENTRY_BYTES_ESTIMATE = 100
DEFAULT_PREWARM_COUNT = 100

# Environment names
ENV_PRODUCTION = "production"
ENV_DEVELOPMENT = "development"

# Settings resolver tier names
SETTINGS_TIER_INSTANCE = "instance"
SETTINGS_TIER_ORG = "org"
SETTINGS_TIER_GLOBAL = "global"

# Production validation
DEV_SECRET_KEY_PLACEHOLDER = "dev-secret-key-change-in-production"
LOCALHOST = "localhost"
