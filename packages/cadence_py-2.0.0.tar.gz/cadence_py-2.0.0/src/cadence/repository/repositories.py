"""Async repositories for PostgreSQL database operations.

Provides repository classes with CRUD operations for all models.
All operations are async and use SQLAlchemy async sessions.
All repositories now use client-based pattern with per-operation sessions.
"""

from typing import TYPE_CHECKING, Any, Dict, List, Optional
from uuid import UUID

from sqlalchemy import delete, func, select

if TYPE_CHECKING:
    from cadence.infrastructure.persistence.postgresql.client import PostgreSQLClient

from cadence.infrastructure.persistence.postgresql.models import (
    Conversation,
    GlobalSettings,
    OrchestratorInstance,
    Organization,
    OrganizationLLMConfig,
    OrganizationPlugin,
    OrganizationSettings,
    OrgPlugin,
    SystemPlugin,
    User,
    UserOrgMembership,
    utc_now,
)


class GlobalSettingsRepository:
    """Repository for global settings operations (Tier 2).

    Attributes:
        client: PostgreSQL client for database access
    """

    def __init__(self, client: "PostgreSQLClient"):
        self.client = client

    async def get_all(self) -> List[GlobalSettings]:
        """Retrieve all global settings.

        Returns:
            List of GlobalSettings instances
        """
        async with self.client.session() as session:
            result = await session.execute(select(GlobalSettings))
            return list(result.scalars().all())

    async def get_by_key(self, key: str) -> Optional[GlobalSettings]:
        """Retrieve setting by key.

        Args:
            key: Setting key

        Returns:
            GlobalSettings instance or None
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(GlobalSettings).where(GlobalSettings.key == key)
            )
            return result.scalar_one_or_none()

    async def health_check(self) -> None:
        """Verify PostgreSQL connection is alive."""
        async with self.client.session() as session:
            await session.execute(select(GlobalSettings).limit(1))

    async def upsert(
        self,
        key: str,
        value: Any,
        value_type: str,
        description: Optional[str] = None,
        caller_id: Optional[str] = None,
    ) -> GlobalSettings:
        """Create or update global setting.

        Args:
            key: Setting key
            value: Setting value
            value_type: Type of the value
            description: Optional description
            caller_id: User ID performing the operation

        Returns:
            Created or updated GlobalSettings instance
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(GlobalSettings).where(GlobalSettings.key == key)
            )
            existing = result.scalar_one_or_none()

            if existing:
                existing.value = value
                existing.value_type = value_type
                existing.updated_at = utc_now()
                existing.updated_by = caller_id
                if description:
                    existing.description = description
                await session.flush()
                return existing

            setting = GlobalSettings(
                key=key,
                value=value,
                value_type=value_type,
                description=description,
                created_by=caller_id,
            )
            session.add(setting)
            await session.flush()
            return setting

    async def delete(self, key: str) -> bool:
        """Delete global setting.

        Args:
            key: Setting key

        Returns:
            True if deleted, False if not found
        """
        async with self.client.session() as session:
            result = await session.execute(
                delete(GlobalSettings).where(GlobalSettings.key == key)
            )
            return result.rowcount > 0


class OrganizationRepository:
    """Repository for organization operations.

    Attributes:
        client: PostgreSQL client for database access
    """

    def __init__(self, client: "PostgreSQLClient"):
        self.client = client

    async def create(
        self, org_id: str, name: str, caller_id: Optional[str] = None
    ) -> Organization:
        """Create new organization.

        Args:
            org_id: Organization identifier
            name: Organization name
            caller_id: User ID performing the operation

        Returns:
            Created Organization instance
        """
        async with self.client.session() as session:
            org = Organization(
                org_id=org_id,
                name=name,
                status="active",
                created_by=caller_id,
            )
            session.add(org)
            await session.flush()
            return org

    async def get_by_id(self, org_id: str) -> Optional[Organization]:
        """Retrieve organization by ID.

        Args:
            org_id: Organization identifier

        Returns:
            Organization instance or None
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(Organization).where(Organization.org_id == org_id)
            )
            return result.scalar_one_or_none()

    async def get_all(self) -> List[Organization]:
        """Retrieve all organizations.

        Returns:
            List of Organization instances
        """
        async with self.client.session() as session:
            result = await session.execute(select(Organization))
            return list(result.scalars().all())

    async def update_status(
        self, org_id: str, status: str, caller_id: Optional[str] = None
    ) -> Optional[Organization]:
        """Update organization status.

        Args:
            org_id: Organization identifier
            status: New status
            caller_id: User ID performing the operation

        Returns:
            Updated Organization instance or None
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(Organization).where(Organization.org_id == org_id)
            )
            org = result.scalar_one_or_none()

            if org:
                org.status = status
                org.updated_at = utc_now()
                org.updated_by = caller_id
                await session.flush()
            return org

    async def delete(self, org_id: str) -> bool:
        """Delete organization.

        Args:
            org_id: Organization identifier

        Returns:
            True if deleted, False if not found
        """
        async with self.client.session() as session:
            result = await session.execute(
                delete(Organization).where(Organization.org_id == org_id)
            )
            return result.rowcount > 0


class OrganizationSettingsRepository:
    """Repository for organization settings operations (Tier 3).

    Attributes:
        client: PostgreSQL client for database access
    """

    def __init__(self, client: "PostgreSQLClient"):
        self.client = client

    async def get_all_for_org(self, org_id: str) -> List[OrganizationSettings]:
        """Retrieve all settings for an organization.

        Args:
            org_id: Organization identifier

        Returns:
            List of OrganizationSettings instances
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(OrganizationSettings).where(
                    OrganizationSettings.org_id == org_id
                )
            )
            return list(result.scalars().all())

    async def get_by_key(self, org_id: str, key: str) -> Optional[OrganizationSettings]:
        """Retrieve setting by key for organization.

        Args:
            org_id: Organization identifier
            key: Setting key

        Returns:
            OrganizationSettings instance or None
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(OrganizationSettings).where(
                    OrganizationSettings.org_id == org_id,
                    OrganizationSettings.key == key,
                )
            )
            return result.scalar_one_or_none()

    async def upsert(
        self,
        org_id: str,
        key: str,
        value: Any,
        caller_id: Optional[str] = None,
    ) -> OrganizationSettings:
        """Create or update organization setting.

        Args:
            org_id: Organization identifier
            key: Setting key
            value: Setting value
            caller_id: User ID performing the operation

        Returns:
            Created or updated OrganizationSettings instance
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(OrganizationSettings).where(
                    OrganizationSettings.org_id == org_id,
                    OrganizationSettings.key == key,
                )
            )
            existing = result.scalar_one_or_none()

            if existing:
                existing.value = value
                existing.updated_at = utc_now()
                existing.updated_by = caller_id
                await session.flush()
                return existing

            setting = OrganizationSettings(
                org_id=org_id,
                key=key,
                value=value,
                created_by=caller_id,
            )
            session.add(setting)
            await session.flush()
            return setting

    async def delete(self, org_id: str, key: str) -> bool:
        """Delete organization setting.

        Args:
            org_id: Organization identifier
            key: Setting key

        Returns:
            True if deleted, False if not found
        """
        async with self.client.session() as session:
            result = await session.execute(
                delete(OrganizationSettings).where(
                    OrganizationSettings.org_id == org_id,
                    OrganizationSettings.key == key,
                )
            )
            return result.rowcount > 0


class OrganizationLLMConfigRepository:
    """Repository for organization LLM configuration operations.

    All mutations are soft-delete only. Queries exclude soft-deleted rows by
    default (include_deleted=False). The api_key column stores the raw (or
    service-encrypted) key; masking happens at the controller layer.
    """

    def __init__(self, client: "PostgreSQLClient"):
        self.client = client

    async def get_all_for_org(
        self, org_id: str, include_deleted: bool = False
    ) -> List[OrganizationLLMConfig]:
        """Retrieve LLM configs for an organization.

        Args:
            org_id: Organization identifier
            include_deleted: If True, include soft-deleted rows

        Returns:
            List of OrganizationLLMConfig instances
        """
        async with self.client.session() as session:
            query = select(OrganizationLLMConfig).where(
                OrganizationLLMConfig.org_id == org_id
            )
            if not include_deleted:
                query = query.where(~OrganizationLLMConfig.is_deleted)
            result = await session.execute(query)
            return list(result.scalars().all())

    async def get_by_name(
        self, org_id: str, name: str
    ) -> Optional[OrganizationLLMConfig]:
        """Retrieve active (non-deleted) LLM config by name.

        Args:
            org_id: Organization identifier
            name: Configuration name

        Returns:
            OrganizationLLMConfig instance or None
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(OrganizationLLMConfig).where(
                    OrganizationLLMConfig.org_id == org_id,
                    OrganizationLLMConfig.name == name,
                    ~OrganizationLLMConfig.is_deleted,
                )
            )
            return result.scalar_one_or_none()

    async def create(
        self,
        org_id: str,
        name: str,
        provider: str,
        api_key: str,
        base_url: Optional[str] = None,
        additional_config: Optional[Dict[str, Any]] = None,
        caller_id: Optional[str] = None,
    ) -> OrganizationLLMConfig:
        """Create new LLM configuration.

        Args:
            org_id: Organization identifier
            name: Configuration name (unique within org among non-deleted rows)
            provider: LLM provider
            api_key: API key
            base_url: Optional custom base URL
            additional_config: Optional provider-specific extra settings (JSONB)
            caller_id: User ID performing the operation

        Returns:
            Created OrganizationLLMConfig instance
        """
        async with self.client.session() as session:
            config = OrganizationLLMConfig(
                org_id=org_id,
                name=name,
                provider=provider,
                api_key=api_key,
                base_url=base_url,
                additional_config=additional_config or {},
                created_by=caller_id,
            )
            session.add(config)
            await session.flush()
            return config

    async def update(
        self,
        org_id: str,
        name: str,
        caller_id: Optional[str] = None,
        **updates,
    ) -> Optional[OrganizationLLMConfig]:
        """Update an active LLM configuration.

        Args:
            org_id: Organization identifier
            name: Configuration name
            caller_id: User ID performing the operation
            **updates: Fields to update

        Returns:
            Updated OrganizationLLMConfig instance or None
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(OrganizationLLMConfig).where(
                    OrganizationLLMConfig.org_id == org_id,
                    OrganizationLLMConfig.name == name,
                    ~OrganizationLLMConfig.is_deleted,
                )
            )
            config = result.scalar_one_or_none()

            if config:
                for key, value in updates.items():
                    setattr(config, key, value)
                config.updated_by = caller_id
                await session.flush()
            return config

    async def soft_delete(
        self, org_id: str, name: str, caller_id: Optional[str] = None
    ) -> bool:
        """Soft-delete an LLM configuration.

        Sets is_deleted=True, deleted_at, deleted_by. The row is retained for
        audit purposes but invisible to the LLM factory and normal queries.

        Args:
            org_id: Organization identifier
            name: Configuration name
            caller_id: User ID performing the operation

        Returns:
            True if the row was found and soft-deleted, False otherwise
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(OrganizationLLMConfig).where(
                    OrganizationLLMConfig.org_id == org_id,
                    OrganizationLLMConfig.name == name,
                    ~OrganizationLLMConfig.is_deleted,
                )
            )
            config = result.scalar_one_or_none()

            if not config:
                return False

            config.is_deleted = True
            config.deleted_at = utc_now()
            config.deleted_by = caller_id
            await session.flush()
            return True


class OrganizationPluginRepository:
    """Repository for organization plugin operations.

    Attributes:
        client: PostgreSQL client for database access
    """

    def __init__(self, client: "PostgreSQLClient"):
        self.client = client

    async def get_all_for_org(
        self, org_id: str, active_only: bool = False
    ) -> List[OrganizationPlugin]:
        """Retrieve all plugins for an organization.

        Args:
            org_id: Organization identifier
            active_only: If True, return only active plugins

        Returns:
            List of OrganizationPlugin instances
        """
        async with self.client.session() as session:
            query = select(OrganizationPlugin).where(
                OrganizationPlugin.org_id == org_id
            )

            if active_only:
                query = query.where(OrganizationPlugin.status == "active")

            result = await session.execute(query)
            return list(result.scalars().all())

    async def get_by_pid(
        self, org_id: str, plugin_pid: str
    ) -> Optional[OrganizationPlugin]:
        """Retrieve plugin by PID.

        Args:
            org_id: Organization identifier
            plugin_pid: Plugin PID

        Returns:
            OrganizationPlugin instance or None
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(OrganizationPlugin).where(
                    OrganizationPlugin.org_id == org_id,
                    OrganizationPlugin.plugin_pid == plugin_pid,
                )
            )
            return result.scalar_one_or_none()

    async def create(
        self,
        org_id: str,
        plugin_pid: str,
        status: str = "active",
        config: Optional[Dict[str, Any]] = None,
        caller_id: Optional[str] = None,
    ) -> OrganizationPlugin:
        """Create new plugin activation.

        Args:
            org_id: Organization identifier
            plugin_pid: Plugin PID
            status: Plugin status (default: active)
            config: Plugin configuration
            caller_id: User ID performing the operation

        Returns:
            Created OrganizationPlugin instance
        """
        async with self.client.session() as session:
            plugin = OrganizationPlugin(
                org_id=org_id,
                plugin_pid=plugin_pid,
                status=status,
                config=config or {},
                created_by=caller_id,
            )
            session.add(plugin)
            await session.flush()
            return plugin

    async def update_status(
        self,
        org_id: str,
        plugin_pid: str,
        status: str,
        caller_id: Optional[str] = None,
    ) -> Optional[OrganizationPlugin]:
        """Update plugin status.

        Args:
            org_id: Organization identifier
            plugin_pid: Plugin PID
            status: New status
            caller_id: User ID performing the operation

        Returns:
            Updated OrganizationPlugin instance or None
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(OrganizationPlugin).where(
                    OrganizationPlugin.org_id == org_id,
                    OrganizationPlugin.plugin_pid == plugin_pid,
                )
            )
            plugin = result.scalar_one_or_none()

            if plugin:
                plugin.status = status
                plugin.updated_by = caller_id
                await session.flush()
            return plugin

    async def update_config(
        self,
        org_id: str,
        plugin_pid: str,
        config: Dict[str, Any],
        caller_id: Optional[str] = None,
    ) -> Optional[OrganizationPlugin]:
        """Update plugin configuration.

        Args:
            org_id: Organization identifier
            plugin_pid: Plugin PID
            config: New configuration
            caller_id: User ID performing the operation

        Returns:
            Updated OrganizationPlugin instance or None
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(OrganizationPlugin).where(
                    OrganizationPlugin.org_id == org_id,
                    OrganizationPlugin.plugin_pid == plugin_pid,
                )
            )
            plugin = result.scalar_one_or_none()

            if plugin:
                plugin.config = config
                plugin.updated_by = caller_id
                await session.flush()
            return plugin

    async def delete(self, org_id: str, plugin_pid: str) -> bool:
        """Delete plugin activation.

        Args:
            org_id: Organization identifier
            plugin_pid: Plugin PID

        Returns:
            True if deleted, False if not found
        """
        async with self.client.session() as session:
            result = await session.execute(
                delete(OrganizationPlugin).where(
                    OrganizationPlugin.org_id == org_id,
                    OrganizationPlugin.plugin_pid == plugin_pid,
                )
            )
            return result.rowcount > 0


class SystemPluginRepository:
    """Repository for system-wide plugin catalog.

    Attributes:
        client: PostgreSQL client for database access
    """

    def __init__(self, client: "PostgreSQLClient"):
        self.client = client

    async def upload(
        self,
        *,
        pid: str,
        version: str,
        name: str,
        description: Optional[str] = None,
        tag: Optional[str] = None,
        s3_path: Optional[str] = None,
        default_settings: Optional[Dict[str, Any]] = None,
        capabilities: Optional[List[Any]] = None,
        agent_type: str = "specialized",
        stateless: bool = True,
        caller_id: Optional[str] = None,
    ) -> SystemPlugin:
        """Insert a new system plugin version, flipping is_latest atomically."""
        async with self.client.session() as session:
            prev_result = await session.execute(
                select(SystemPlugin).where(
                    SystemPlugin.pid == pid,
                    SystemPlugin.is_latest == True,  # noqa: E712
                )
            )
            for prev in prev_result.scalars().all():
                prev.is_latest = False
                prev.updated_at = utc_now()
                prev.updated_by = caller_id

            plugin = SystemPlugin(
                pid=pid,
                version=version,
                name=name,
                description=description,
                tag=tag,
                is_latest=True,
                s3_path=s3_path,
                default_settings=default_settings or {},
                capabilities=capabilities or [],
                agent_type=agent_type,
                stateless=stateless,
                created_by=caller_id,
            )
            session.add(plugin)
            await session.flush()
            return plugin

    async def get_latest(self, pid: str) -> Optional[SystemPlugin]:
        """Retrieve the latest active version of a system plugin."""
        async with self.client.session() as session:
            result = await session.execute(
                select(SystemPlugin).where(
                    SystemPlugin.pid == pid,
                    SystemPlugin.is_latest == True,  # noqa: E712
                    SystemPlugin.is_active == True,  # noqa: E712
                )
            )
            return result.scalar_one_or_none()

    async def get_by_version(self, pid: str, version: str) -> Optional[SystemPlugin]:
        """Retrieve a specific version of a system plugin."""
        async with self.client.session() as session:
            result = await session.execute(
                select(SystemPlugin).where(
                    SystemPlugin.pid == pid,
                    SystemPlugin.version == version,
                )
            )
            return result.scalar_one_or_none()

    async def get_by_id(self, plugin_id: int) -> Optional[SystemPlugin]:
        """Retrieve a system plugin by primary key."""
        async with self.client.session() as session:
            result = await session.execute(
                select(SystemPlugin).where(SystemPlugin.id == plugin_id)
            )
            return result.scalar_one_or_none()

    async def list_all(self, tag: Optional[str] = None) -> List[SystemPlugin]:
        """List all active system plugins, optionally filtered by tag."""
        async with self.client.session() as session:
            query = select(SystemPlugin).where(
                SystemPlugin.is_active == True  # noqa: E712
            )
            if tag:
                query = query.where(SystemPlugin.tag == tag)
            query = query.order_by(SystemPlugin.pid, SystemPlugin.version)
            result = await session.execute(query)
            return list(result.scalars().all())

    async def soft_delete(
        self, plugin_id: int, caller_id: Optional[str] = None
    ) -> bool:
        """Soft-delete a system plugin by setting is_active=False."""
        async with self.client.session() as session:
            result = await session.execute(
                select(SystemPlugin).where(SystemPlugin.id == plugin_id)
            )
            plugin = result.scalar_one_or_none()
            if not plugin:
                return False
            plugin.is_active = False
            plugin.updated_at = utc_now()
            plugin.updated_by = caller_id
            if plugin.is_latest:
                plugin.is_latest = False
            await session.flush()
            return True


class OrgPluginRepository:
    """Repository for organization-specific plugin catalog.

    Attributes:
        client: PostgreSQL client for database access
    """

    def __init__(self, client: "PostgreSQLClient"):
        self.client = client

    async def upload(
        self,
        *,
        org_id: str,
        pid: str,
        version: str,
        name: str,
        description: Optional[str] = None,
        tag: Optional[str] = None,
        s3_path: Optional[str] = None,
        default_settings: Optional[Dict[str, Any]] = None,
        capabilities: Optional[List[Any]] = None,
        agent_type: str = "specialized",
        stateless: bool = True,
        caller_id: Optional[str] = None,
    ) -> OrgPlugin:
        """Insert a new org plugin version, flipping is_latest atomically."""
        async with self.client.session() as session:
            prev_result = await session.execute(
                select(OrgPlugin).where(
                    OrgPlugin.org_id == org_id,
                    OrgPlugin.pid == pid,
                    OrgPlugin.is_latest == True,  # noqa: E712
                )
            )
            for prev in prev_result.scalars().all():
                prev.is_latest = False
                prev.updated_at = utc_now()
                prev.updated_by = caller_id

            plugin = OrgPlugin(
                org_id=org_id,
                pid=pid,
                version=version,
                name=name,
                description=description,
                tag=tag,
                is_latest=True,
                s3_path=s3_path,
                default_settings=default_settings or {},
                capabilities=capabilities or [],
                agent_type=agent_type,
                stateless=stateless,
                created_by=caller_id,
            )
            session.add(plugin)
            await session.flush()
            return plugin

    async def get_latest(self, org_id: str, pid: str) -> Optional[OrgPlugin]:
        """Retrieve the latest active version of an org plugin."""
        async with self.client.session() as session:
            result = await session.execute(
                select(OrgPlugin).where(
                    OrgPlugin.org_id == org_id,
                    OrgPlugin.pid == pid,
                    OrgPlugin.is_latest == True,  # noqa: E712
                    OrgPlugin.is_active == True,  # noqa: E712
                )
            )
            return result.scalar_one_or_none()

    async def get_by_version(
        self, org_id: str, pid: str, version: str
    ) -> Optional[OrgPlugin]:
        """Retrieve a specific version of an org plugin."""
        async with self.client.session() as session:
            result = await session.execute(
                select(OrgPlugin).where(
                    OrgPlugin.org_id == org_id,
                    OrgPlugin.pid == pid,
                    OrgPlugin.version == version,
                )
            )
            return result.scalar_one_or_none()

    async def get_by_id(self, plugin_id: int) -> Optional[OrgPlugin]:
        """Retrieve an org plugin by primary key."""
        async with self.client.session() as session:
            result = await session.execute(
                select(OrgPlugin).where(OrgPlugin.id == plugin_id)
            )
            return result.scalar_one_or_none()

    async def list_available(
        self, org_id: str, tag: Optional[str] = None
    ) -> List[OrgPlugin]:
        """List all active org plugins, optionally filtered by tag."""
        async with self.client.session() as session:
            query = select(OrgPlugin).where(
                OrgPlugin.org_id == org_id,
                OrgPlugin.is_active == True,  # noqa: E712
            )
            if tag:
                query = query.where(OrgPlugin.tag == tag)
            query = query.order_by(OrgPlugin.pid, OrgPlugin.version)
            result = await session.execute(query)
            return list(result.scalars().all())

    async def soft_delete(
        self, plugin_id: int, org_id: str, caller_id: Optional[str] = None
    ) -> bool:
        """Soft-delete an org plugin by setting is_active=False."""
        async with self.client.session() as session:
            result = await session.execute(
                select(OrgPlugin).where(
                    OrgPlugin.id == plugin_id,
                    OrgPlugin.org_id == org_id,
                )
            )
            plugin = result.scalar_one_or_none()
            if not plugin:
                return False
            plugin.is_active = False
            plugin.updated_at = utc_now()
            plugin.updated_by = caller_id
            if plugin.is_latest:
                plugin.is_latest = False
            await session.flush()
            return True


class OrchestratorInstanceRepository:
    """Repository for orchestrator instance operations (Tier 4).

    Attributes:
        client: PostgreSQL client for database access
    """

    def __init__(self, client: "PostgreSQLClient"):
        self.client = client

    def _serialize(self, instance: OrchestratorInstance) -> Dict[str, Any]:
        """Serialize ORM instance to dict.

        Args:
            instance: OrchestratorInstance ORM object

        Returns:
            Instance data dictionary
        """
        return {
            "instance_id": str(instance.instance_id),
            "org_id": instance.org_id,
            "name": instance.name,
            "framework_type": instance.framework_type,
            "mode": instance.mode,
            "status": instance.status,
            "config": instance.config,
            "tier": instance.tier,
            "plugin_settings": instance.plugin_settings or {},
            "config_hash": instance.config_hash,
            "last_accessed_at": (
                instance.last_accessed_at.isoformat()
                if instance.last_accessed_at
                else None
            ),
            "created_at": instance.created_at.isoformat(),
            "updated_at": instance.updated_at.isoformat(),
            "created_by": instance.created_by,
            "updated_by": instance.updated_by,
        }

    async def create(
        self,
        org_id: str,
        name: str,
        framework_type: str,
        mode: str,
        config: Dict[str, Any],
        tier: str = "cold",
        plugin_settings: Optional[Dict[str, Any]] = None,
        config_hash: Optional[str] = None,
        caller_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create new orchestrator instance.

        Args:
            org_id: Organization identifier
            name: Instance name
            framework_type: Orchestration framework (immutable after creation)
            mode: Orchestration mode (immutable after creation)
            config: Mutable instance configuration (must not include framework_type or mode)
            tier: Pool tier (hot/warm/cold)
            plugin_settings: Per-plugin default settings overrides
            config_hash: SHA-256 hash of config+plugin_settings
            caller_id: User ID performing the operation

        Returns:
            Created instance as dictionary
        """
        async with self.client.session() as session:
            instance = OrchestratorInstance(
                org_id=org_id,
                name=name,
                framework_type=framework_type,
                mode=mode,
                status="active",
                config=config,
                tier=tier,
                plugin_settings=plugin_settings or {},
                config_hash=config_hash,
                created_by=caller_id,
            )
            session.add(instance)
            await session.flush()
            return self._serialize(instance)

    async def get_by_id(self, instance_id) -> Optional[Dict[str, Any]]:
        """Retrieve instance by ID.

        Args:
            instance_id: Instance identifier (UUID or str)

        Returns:
            Instance dictionary or None
        """
        if isinstance(instance_id, str):
            instance_id = UUID(instance_id)
        async with self.client.session() as session:
            result = await session.execute(
                select(OrchestratorInstance).where(
                    OrchestratorInstance.instance_id == instance_id
                )
            )
            instance = result.scalar_one_or_none()
            return self._serialize(instance) if instance else None

    async def list_for_org(
        self, org_id: str, include_deleted: bool = False
    ) -> List[Dict[str, Any]]:
        """Retrieve all instances for an organization.

        Args:
            org_id: Organization identifier
            include_deleted: If False (default), exclude status='deleted' instances

        Returns:
            List of instance dictionaries
        """
        async with self.client.session() as session:
            query = select(OrchestratorInstance).where(
                OrchestratorInstance.org_id == org_id
            )

            if not include_deleted:
                query = query.where(OrchestratorInstance.status != "deleted")

            result = await session.execute(query)
            return [self._serialize(i) for i in result.scalars().all()]

    async def list_all(self) -> List[Dict[str, Any]]:
        """List all non-deleted instances (for pool loading).

        Returns:
            List of instance dictionaries
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(OrchestratorInstance).where(
                    OrchestratorInstance.status != "deleted"
                )
            )
            return [self._serialize(i) for i in result.scalars().all()]

    async def list_by_tier(
        self, tier: str, status: str = "active"
    ) -> List[Dict[str, Any]]:
        """List instances by tier and status.

        Args:
            tier: Pool tier (hot/warm/cold)
            status: Instance status filter

        Returns:
            List of instance dictionaries
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(OrchestratorInstance).where(
                    OrchestratorInstance.tier == tier,
                    OrchestratorInstance.status == status,
                    ~OrchestratorInstance.is_deleted,
                )
            )
            return [self._serialize(i) for i in result.scalars().all()]

    async def update_plugin_settings(
        self,
        instance_id,
        plugin_settings: Dict[str, Any],
        config_hash: Optional[str] = None,
        caller_id: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Update plugin_settings and config_hash on an instance.

        Args:
            instance_id: Instance identifier (UUID or str)
            plugin_settings: New plugin settings dict
            config_hash: New config hash
            caller_id: User ID performing the operation

        Returns:
            Updated instance dict or None
        """
        if isinstance(instance_id, str):
            from uuid import UUID

            instance_id = UUID(instance_id)
        async with self.client.session() as session:
            result = await session.execute(
                select(OrchestratorInstance).where(
                    OrchestratorInstance.instance_id == instance_id
                )
            )
            instance = result.scalar_one_or_none()
            if instance:
                instance.plugin_settings = plugin_settings
                instance.config_hash = config_hash
                instance.updated_at = utc_now()
                instance.updated_by = caller_id
                await session.flush()
                return self._serialize(instance)
            return None

    async def update_config(
        self,
        instance_id,
        config: Dict[str, Any],
        caller_id: Optional[str] = None,
    ) -> Optional[OrchestratorInstance]:
        """Update instance configuration.

        Args:
            instance_id: Instance identifier (UUID or str)
            config: New configuration
            caller_id: User ID performing the operation

        Returns:
            Updated OrchestratorInstance or None
        """
        if isinstance(instance_id, str):
            instance_id = UUID(instance_id)
        async with self.client.session() as session:
            result = await session.execute(
                select(OrchestratorInstance).where(
                    OrchestratorInstance.instance_id == instance_id
                )
            )
            instance = result.scalar_one_or_none()

            if instance:
                instance.config = config
                instance.updated_at = utc_now()
                instance.updated_by = caller_id
                await session.flush()
            return instance

    async def update_status(
        self,
        instance_id,
        status: str,
        caller_id: Optional[str] = None,
    ) -> Optional[OrchestratorInstance]:
        """Update instance status.

        Args:
            instance_id: Instance identifier (UUID or str)
            status: New status
            caller_id: User ID performing the operation

        Returns:
            Updated OrchestratorInstance or None
        """
        if isinstance(instance_id, str):
            instance_id = UUID(instance_id)
        async with self.client.session() as session:
            result = await session.execute(
                select(OrchestratorInstance).where(
                    OrchestratorInstance.instance_id == instance_id
                )
            )
            instance = result.scalar_one_or_none()

            if instance:
                instance.status = status
                instance.updated_at = utc_now()
                instance.updated_by = caller_id
                await session.flush()
            return instance

    async def update_last_accessed(self, instance_id: UUID) -> bool:
        """Update last accessed timestamp (for LRU).

        Args:
            instance_id: Instance identifier

        Returns:
            True if updated, False if not found
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(OrchestratorInstance).where(
                    OrchestratorInstance.instance_id == instance_id
                )
            )
            instance = result.scalar_one_or_none()

            if instance:
                instance.last_accessed_at = utc_now()
                await session.flush()
                return True
            return False

    async def delete(self, instance_id: UUID) -> bool:
        """Delete orchestrator instance.

        Args:
            instance_id: Instance identifier

        Returns:
            True if deleted, False if not found
        """
        async with self.client.session() as session:
            result = await session.execute(
                delete(OrchestratorInstance).where(
                    OrchestratorInstance.instance_id == instance_id
                )
            )
            return result.rowcount > 0

    async def count_using_llm_config(self, org_id: str, config_name: str) -> int:
        """Count active instances in the org that reference an LLM config by name.

        Searches the config JSONB for references via primary_model.llm_config_name.
        Used to block deletion of an LLM config that is still in use.

        Args:
            org_id: Organization identifier
            config_name: LLM configuration name to search for

        Returns:
            Number of active (non-deleted, non-status-deleted) instances
            that reference this config
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(func.count()).where(
                    OrchestratorInstance.org_id == org_id,
                    OrchestratorInstance.status != "deleted",
                    ~OrchestratorInstance.is_deleted,
                    OrchestratorInstance.config["primary_model"][
                        "llm_config_name"
                    ].astext
                    == config_name,
                )
            )
            return result.scalar() or 0


class UserRepository:
    """Repository for user operations.

    Users are platform-level entities. Org membership is tracked separately
    in UserOrgMembershipRepository.

    Attributes:
        client: PostgreSQL client for database access
    """

    def __init__(self, client: "PostgreSQLClient"):
        self.client = client

    async def create(
        self,
        user_id: str,
        username: str,
        email: Optional[str] = None,
        is_sys_admin: bool = False,
        password_hash: Optional[str] = None,
        caller_id: Optional[str] = None,
    ) -> User:
        """Create new user.

        Args:
            user_id: User identifier
            username: Globally unique username (among non-deleted users)
            email: Optional email address
            is_sys_admin: Platform-wide admin flag
            password_hash: Pre-hashed password string
            caller_id: User ID performing the operation

        Returns:
            Created User instance
        """
        async with self.client.session() as session:
            user = User(
                user_id=user_id,
                username=username,
                email=email,
                is_sys_admin=is_sys_admin,
                password_hash=password_hash,
                created_by=caller_id,
            )
            session.add(user)
            await session.flush()
            return user

    async def get_by_id(self, user_id: str) -> Optional[User]:
        """Retrieve user by ID.

        Args:
            user_id: User identifier

        Returns:
            User instance or None
        """
        async with self.client.session() as session:
            result = await session.execute(select(User).where(User.user_id == user_id))
            return result.scalar_one_or_none()

    async def get_by_username(self, username: str) -> Optional[User]:
        """Retrieve active user by username (globally unique).

        Args:
            username: Username

        Returns:
            User instance or None
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(User).where(
                    User.username == username,
                    ~User.is_deleted,
                )
            )
            return result.scalar_one_or_none()

    async def list_all(self) -> List[User]:
        """Retrieve all non-deleted users ordered by creation date.

        Returns:
            List of User instances
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(User).where(~User.is_deleted).order_by(User.created_at.desc())
            )
            return list(result.scalars().all())

    async def update(
        self,
        user_id: str,
        username: Optional[str] = None,
        email: Optional[str] = None,
        is_sys_admin: Optional[bool] = None,
        caller_id: Optional[str] = None,
    ) -> Optional[User]:
        """Update user fields (username, email, is_sys_admin).

        Args:
            user_id: User identifier
            username: New username or None to leave unchanged
            email: New email or None to leave unchanged
            is_sys_admin: New sys_admin flag or None to leave unchanged
            caller_id: User ID performing the operation

        Returns:
            Updated User instance or None if not found
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(User).where(User.user_id == user_id, ~User.is_deleted)
            )
            user = result.scalar_one_or_none()
            if user:
                if username is not None:
                    user.username = username
                if email is not None:
                    user.email = email
                if is_sys_admin is not None:
                    user.is_sys_admin = is_sys_admin
                user.updated_by = caller_id
                user.updated_at = utc_now()
                await session.flush()
            return user

    async def get_by_email(self, email: str) -> Optional[User]:
        """Retrieve active user by email address.

        Args:
            email: Email address

        Returns:
            User instance or None
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(User).where(
                    User.email == email,
                    ~User.is_deleted,
                )
            )
            return result.scalar_one_or_none()

    async def update_sys_admin_flag(
        self, user_id: str, is_sys_admin: bool, caller_id: Optional[str] = None
    ) -> Optional[User]:
        """Update platform-wide admin flag for a user.

        Args:
            user_id: User identifier
            is_sys_admin: New sys_admin value
            caller_id: User ID performing the operation

        Returns:
            Updated User instance or None
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(User).where(User.user_id == user_id, ~User.is_deleted)
            )
            user = result.scalar_one_or_none()
            if user:
                user.is_sys_admin = is_sys_admin
                user.updated_by = caller_id
                user.updated_at = utc_now()
                await session.flush()
            return user

    async def delete(self, user_id: str, caller_id: Optional[str] = None) -> bool:
        """Soft-delete a user.

        Sets is_deleted=True, deleted_at, deleted_by. The user record is
        retained for audit purposes.

        Args:
            user_id: User identifier
            caller_id: User ID performing the operation

        Returns:
            True if found and soft-deleted, False if not found or already deleted
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(User).where(User.user_id == user_id, ~User.is_deleted)
            )
            user = result.scalar_one_or_none()

            if not user:
                return False

            user.is_deleted = True
            user.deleted_at = utc_now()
            user.deleted_by = caller_id
            await session.flush()
            return True


class UserOrgMembershipRepository:
    """Repository for user-organization membership operations.

    Manages which organizations users belong to and their admin status
    within each organization.

    Attributes:
        client: PostgreSQL client for database access
    """

    def __init__(self, client: "PostgreSQLClient"):
        self.client = client

    async def create(
        self,
        user_id: str,
        org_id: str,
        is_admin: bool = False,
        caller_id: Optional[str] = None,
    ) -> UserOrgMembership:
        """Add a user to an organization.

        Args:
            user_id: User identifier
            org_id: Organization identifier
            is_admin: Whether the user is an admin of this org
            caller_id: User ID performing the operation

        Returns:
            Created UserOrgMembership instance
        """
        async with self.client.session() as session:
            membership = UserOrgMembership(
                user_id=user_id,
                org_id=org_id,
                is_admin=is_admin,
                created_by=caller_id,
            )
            session.add(membership)
            await session.flush()
            return membership

    async def get(self, user_id: str, org_id: str) -> Optional[UserOrgMembership]:
        """Retrieve active membership for a user/org pair.

        Args:
            user_id: User identifier
            org_id: Organization identifier

        Returns:
            UserOrgMembership instance or None
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(UserOrgMembership).where(
                    UserOrgMembership.user_id == user_id,
                    UserOrgMembership.org_id == org_id,
                )
            )
            return result.scalar_one_or_none()

    async def list_for_user(self, user_id: str) -> List[UserOrgMembership]:
        """List all org memberships for a user.

        Args:
            user_id: User identifier

        Returns:
            List of UserOrgMembership instances
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(UserOrgMembership).where(UserOrgMembership.user_id == user_id)
            )
            return list(result.scalars().all())

    async def list_for_org(self, org_id: str) -> List[UserOrgMembership]:
        """List all user memberships in an organization.

        Args:
            org_id: Organization identifier

        Returns:
            List of UserOrgMembership instances
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(UserOrgMembership).where(UserOrgMembership.org_id == org_id)
            )
            return list(result.scalars().all())

    async def update_admin_flag(
        self,
        user_id: str,
        org_id: str,
        is_admin: bool,
        caller_id: Optional[str] = None,
    ) -> Optional[UserOrgMembership]:
        """Update the admin flag for an existing membership.

        Args:
            user_id: User identifier
            org_id: Organization identifier
            is_admin: New admin value
            caller_id: User ID performing the operation

        Returns:
            Updated UserOrgMembership or None if not found
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(UserOrgMembership).where(
                    UserOrgMembership.user_id == user_id,
                    UserOrgMembership.org_id == org_id,
                )
            )
            membership = result.scalar_one_or_none()
            if membership:
                membership.is_admin = is_admin
                membership.updated_by = caller_id
                membership.updated_at = utc_now()
                await session.flush()
            return membership

    async def delete(self, user_id: str, org_id: str) -> bool:
        """Hard-delete a membership row (remove user from org).

        Args:
            user_id: User identifier
            org_id: Organization identifier

        Returns:
            True if a row was deleted, False if not found
        """
        async with self.client.session() as session:
            result = await session.execute(
                delete(UserOrgMembership).where(
                    UserOrgMembership.user_id == user_id,
                    UserOrgMembership.org_id == org_id,
                )
            )
            return result.rowcount > 0

    async def delete_all_for_user(self, user_id: str) -> int:
        """Hard-delete all memberships for a user.

        Called when a user account is soft-deleted so stale memberships
        are removed and the user loses all org access.

        Args:
            user_id: User identifier

        Returns:
            Number of rows deleted
        """
        async with self.client.session() as session:
            result = await session.execute(
                delete(UserOrgMembership).where(UserOrgMembership.user_id == user_id)
            )
            return result.rowcount


class ConversationRepository:
    """Repository for conversation metadata operations.

    Attributes:
        client: PostgreSQL client for database access
    """

    def __init__(self, client: "PostgreSQLClient"):
        self.client = client

    async def create(
        self,
        conversation_id: str,
        org_id: str,
        user_id: str,
        instance_id: Optional[UUID] = None,
    ) -> Conversation:
        """Create new conversation.

        Args:
            conversation_id: Conversation identifier
            org_id: Organization identifier
            user_id: User identifier
            instance_id: Optional orchestrator instance ID

        Returns:
            Created Conversation instance
        """
        async with self.client.session() as session:
            conversation = Conversation(
                conversation_id=conversation_id,
                org_id=org_id,
                user_id=user_id,
                instance_id=instance_id,
            )
            session.add(conversation)
            await session.flush()
            return conversation

    async def get_by_id(self, conversation_id: str) -> Optional[Conversation]:
        """Retrieve conversation by ID.

        Args:
            conversation_id: Conversation identifier

        Returns:
            Conversation instance or None
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(Conversation).where(
                    Conversation.conversation_id == conversation_id
                )
            )
            return result.scalar_one_or_none()

    async def list_for_user(self, user_id: str) -> List[Conversation]:
        """List conversations for user.

        Args:
            user_id: User identifier

        Returns:
            List of Conversation instances
        """
        async with self.client.session() as session:
            result = await session.execute(
                select(Conversation).where(Conversation.user_id == user_id)
            )
            return list(result.scalars().all())
