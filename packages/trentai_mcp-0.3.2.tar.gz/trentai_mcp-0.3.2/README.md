# Trent MCP Server

MCP (Model Context Protocol) server that integrates Trent\ with Claude Code.

## Quick Start

```bash
pip install trentai-mcp
cd /path/to/your/project
trent-mcp-setup              # External: installs trent:appsec skill only
# or
trent-mcp-setup --all        # Internal: installs all 4 skills
```

Restart Claude Code:
- **VS Code**: Run `Developer: Reload Window`
- **Terminal**: Exit and re-enter `claude`

First time you use the tool, it will open your browser to authenticate via Auth0. Tokens are stored securely in your OS keychain.

### Upgrading

```bash
pip install --upgrade trentai-mcp
```

## Uninstall

```bash
trent-mcp-uninstall       # Remove config, skills, and keychain tokens
pip uninstall trentai-mcp   # Remove the package
```

Run `trent-mcp-uninstall` first (before `pip uninstall`) so the command is still available.

