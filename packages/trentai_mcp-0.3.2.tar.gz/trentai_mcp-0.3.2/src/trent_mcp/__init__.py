# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""Trent MCP Server for Claude Code integration."""

__version__ = "0.3.2"
