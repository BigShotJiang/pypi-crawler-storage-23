# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""API Client for Trent REST API."""

from trent_mcp.client.trent_api import TrentAPIClient

__all__ = ["TrentAPIClient"]
