# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""Async client for Trent REST API with streaming support."""

import json
import logging
import os
import subprocess
from urllib.parse import urlparse, urlunparse

import httpx

from trent_mcp import __version__
from trent_mcp.auth.token_manager import TokenManager
from trent_mcp.config import get_config

logger = logging.getLogger(__name__)


class TrentAPIClient:
    """
    Async client for Trent REST API.

    Handles authentication and API calls to the Trent chat endpoint
    using OAuth PKCE token management.
    """

    def __init__(self):
        """Initialize the API client with configuration."""
        self._config = get_config()
        self._token_manager = TokenManager(
            auth0_domain=self._config.auth0_domain,
            client_id=self._config.auth0_client_id,
            audience=self._config.auth0_audience,
        )
        self._thread_id: str | None = None
        # Connection-pooled client for performance
        self._client: httpx.AsyncClient | None = None

    def _build_client_info(self, resolved_project_name: str | None = None) -> dict:
        """Build client_info metadata for chat API requests."""
        info: dict[str, str] = {
            "client_type": "mcp",
            "client_version": __version__,
        }
        if self._config.claude_model:
            info["claude_model"] = self._config.claude_model
        project_name = resolved_project_name or self._config.project_name
        if project_name:
            info["client_project"] = project_name

        # Best-effort: detect working directory
        try:
            info["client_project_path"] = os.getcwd()
        except OSError:
            pass

        # Best-effort: detect git remote URL (strip credentials if present)
        try:
            result = subprocess.run(
                ["git", "config", "--get", "remote.origin.url"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip():
                remote_url = result.stdout.strip()
                # Strip embedded credentials from HTTPS URLs
                # e.g. https://token@github.com/org/repo -> https://github.com/org/repo
                if remote_url.startswith(("http://", "https://")):
                    parsed = urlparse(remote_url)
                    if parsed.username or parsed.password:
                        sanitized = parsed._replace(
                            netloc=parsed.hostname + (f":{parsed.port}" if parsed.port else "")
                        )
                        remote_url = urlunparse(sanitized)
                info["client_project_remote"] = remote_url
        except (OSError, subprocess.TimeoutExpired):
            pass

        return info

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create connection-pooled async client."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(300.0),  # Security analysis can take time
                limits=httpx.Limits(max_connections=10, max_keepalive_connections=5),
            )
        return self._client

    async def close(self):
        """Close the HTTP client connection pool."""
        if self._client:
            await self._client.aclose()
            self._client = None

    async def chat(
        self,
        message: str,
        context: str | None = None,
        resolved_project_name: str | None = None,
    ) -> dict:
        """
        Send a chat message to Trent API using streaming.

        Uses streaming to avoid API Gateway 30-second timeout.

        Args:
            message: The message to send to AppSec Advisor
            context: Optional additional context for the message
            resolved_project_name: Auto-detected or explicit project name for client_info

        Returns:
            dict with keys:
                - content: The response content from AppSec Advisor
                - thread_id: Conversation thread ID for continuity
                - error: True if an error occurred (optional)
        """
        try:
            token = self._token_manager.get_token_or_authenticate()
        except Exception as e:
            logger.error(f"Authentication failed: {e}")
            return {
                "content": f"Authentication failed: {e}",
                "error": True,
            }

        client = await self._get_client()
        content_chunks: list[str] = []
        thread_id = None

        try:
            async with client.stream(
                "POST",
                f"{self._config.chat_api_url}/v1/chat",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json",
                    "Accept": "text/event-stream",
                },
                json={
                    "message": message,
                    "context": context,
                    "thread_id": self._thread_id,
                    "stream": True,
                    "client_info": self._build_client_info(resolved_project_name),
                },
            ) as response:
                response.raise_for_status()

                async for line in response.aiter_lines():
                    if not line:
                        continue

                    # SSE format: "data: {...}"
                    if line.startswith("data: "):
                        data_str = line[6:]  # Remove "data: " prefix

                        # Handle [DONE] marker
                        if data_str.strip() == "[DONE]":
                            break

                        try:
                            data = json.loads(data_str)

                            # Extract content chunk
                            if "content" in data:
                                content_chunks.append(data["content"])
                            elif "delta" in data and "content" in data["delta"]:
                                content_chunks.append(data["delta"]["content"])

                            # Capture thread_id if present
                            if "thread_id" in data:
                                thread_id = data["thread_id"]

                        except json.JSONDecodeError:
                            logger.debug(f"Skipping non-JSON SSE line: {data_str}")
                            continue

            # Update thread_id for conversation continuity
            if thread_id:
                self._thread_id = thread_id

            return {
                "content": "".join(content_chunks),
                "thread_id": self._thread_id,
            }

        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error: {e.response.status_code} - {e.response.text}")
            if e.response.status_code == 401:
                self._token_manager.clear_token()
                return {
                    "content": "Session expired. Please re-authenticate.",
                    "error": True,
                }
            return {
                "content": f"API error: {e.response.status_code}",
                "error": True,
            }

        except httpx.TimeoutException:
            logger.error("Request timed out")
            return {
                "content": "Request timed out. Please try again.",
                "error": True,
            }

        except Exception as e:
            logger.error(f"Unexpected error: {e}", exc_info=True)
            return {
                "content": f"An error occurred: {e}",
                "error": True,
            }

    async def _make_request(
        self,
        method: str,
        endpoint: str,
        json_data: dict | None = None,
        params: dict | None = None,
    ) -> dict:
        """
        Make authenticated request to Trent API.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE, PATCH)
            endpoint: API endpoint path (e.g., "/projects", "/analyse")
            json_data: JSON body for POST/PUT/PATCH
            params: Query parameters

        Returns:
            dict: JSON response

        Raises:
            httpx.HTTPStatusError: If request fails
        """
        token = self._token_manager.get_token_or_authenticate()
        client = await self._get_client()

        # Construct full URL with base path
        url = f"{self._config.agent_api_url}/v1/humber-agent{endpoint}"

        response = await client.request(
            method,
            url,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            json=json_data,
            params=params,
        )
        response.raise_for_status()
        return response.json()

    async def list_projects(self) -> list[dict]:
        """List all projects for the authenticated tenant."""
        response = await self._make_request("GET", "/projects")
        return response.get("projects", [])

    async def get_project(self, project_id: str) -> dict:
        """Get detailed project information."""
        return await self._make_request("GET", f"/projects/{project_id}")

    async def trigger_analysis(
        self,
        project_id: str,
        commit_sha: str | None = None,
        enable_incremental: bool = True,
        enable_multi_source: bool = False,
        enable_local_incremental: bool = False,
    ) -> dict:
        """Trigger a new security analysis (async operation)."""
        request_data = {
            "project_id": project_id,
            "commit_sha": commit_sha,
            "enable_incremental_analysis": enable_incremental,
            "enable_multi_source_analysis": enable_multi_source,
            "enable_local_incremental_analysis": enable_local_incremental,
        }
        return await self._make_request("POST", "/analyse", json_data=request_data)

    async def get_threats(
        self,
        project_id: str,
        job_id: str | None = None,
    ) -> list[dict]:
        """Get threats/vulnerabilities from analysis."""
        params = {"job_id": job_id} if job_id else {}
        response = await self._make_request(
            "GET",
            f"/analyse/project-id/{project_id}",
            params=params,
        )
        return response.get("threats", [])

    async def get_tasks(
        self,
        project_id: str,
        job_id: str | None = None,
    ) -> list[dict]:
        """Get remediation tasks from analysis."""
        params = {"job_id": job_id} if job_id else {}
        response = await self._make_request(
            "GET",
            f"/analyse/project-id/{project_id}/tasks",
            params=params,
        )
        return response.get("tasks", [])

    async def prepare_document_upload(
        self,
        name: str,
        doc_type: str,
        doc_format: str,
        digest: str | None = None,
    ) -> dict:
        """
        Prepare a presigned S3 URL for document upload.

        Args:
            name: Document name
            doc_type: Document type (e.g., "code_diff", "source_code", "design_doc")
            doc_format: Document format (e.g., "diff", "zip", "pdf")
            digest: Optional SHA256 digest for deduplication (format: 'sha256:hexdigest')

        Returns:
            dict with keys: s3_url, upload_url, version, skipped_upload, expires_at, max_size_bytes
        """
        json_data: dict = {"name": name, "type": doc_type, "format": doc_format}
        if digest:
            json_data["digest"] = digest
        return await self._make_request("POST", "/documents/upload", json_data=json_data)

    async def upload_content_to_presigned_url(
        self,
        upload_url: str,
        content: bytes,
        content_type: str = "text/x-diff",
    ) -> None:
        """
        Upload content to a presigned S3 URL.

        Does NOT add Authorization headers (presigned URLs have auth in query params).
        Does NOT log the upload_url to avoid credential leakage.

        Args:
            upload_url: Presigned PUT URL from prepare_document_upload
            content: Raw bytes to upload
            content_type: MIME type of the content

        Raises:
            httpx.HTTPStatusError: If upload fails
        """
        client = await self._get_client()
        response = await client.put(
            upload_url,
            content=content,
            headers={"Content-Type": content_type},
        )
        response.raise_for_status()

    async def create_project(
        self,
        repositories: list[dict],
        compliance: list[str],
        name: str | None = None,
        description: str | None = None,
    ) -> dict:
        """
        Create a new security analysis project.

        Args:
            repositories: List of {"owner": str, "repository": str} dicts
            compliance: List of compliance type strings (e.g., ["OWASP", "THREAT_MODEL"])
            name: Optional project name (defaults to server-side auto-name)
            description: Optional project description

        Returns:
            Created project dict with project_id, status, etc.
        """
        project_data: dict = {
            "repositories": repositories,
            "compliance": compliance,
        }
        if name:
            project_data["name"] = name
        if description:
            project_data["description"] = description

        return await self._make_request("POST", "/projects", json_data=project_data)

    async def update_project(self, project_id: str, project_data: dict) -> dict:
        """
        Update a project's configuration.

        Only name, description, crawler_config, and documents changes are allowed.

        Args:
            project_id: Project identifier
            project_data: Dict with fields to update

        Returns:
            Updated project data
        """
        return await self._make_request("PUT", f"/projects/{project_id}", json_data=project_data)

    async def update_task_statuses(
        self,
        project_id: str,
        updates: list[dict],
    ) -> dict:
        """
        Update task statuses in batch.

        Args:
            project_id: Project identifier
            updates: List of {task_id, control_status, reason?}
        """
        request_data = {"updates": updates}
        return await self._make_request(
            "PATCH",
            f"/analyse/project-id/{project_id}/tasks",
            json_data=request_data,
        )
