# trent:threats

View and manage Trent security analysis projects.

## When to Use

- User wants to see their Trent or security projects
- User wants to start a security analysis
- User wants to view identified threats or vulnerabilities
- User wants to track remediation progress

## Instructions

### Step 1: Understand Intent

Determine what the user wants:
- Browse projects → use `list_projects`
- View specific project → use `get_project`
- Start analysis → use `trigger_analysis`
- See vulnerabilities → use `get_threats`
- Track tasks → use `get_tasks`
- Update progress → use `update_tasks`

### Step 2: Call Appropriate Tool

Use the MCP tools directly based on intent. No need to ask for additional context unless the operation requires specific IDs.

### Step 3: Present Results

Format results clearly:
- **For projects**: Show name, status, threat count
- **For threats**: Group by severity, highlight CRITICAL/HIGH vulnerabilities first
- **For tasks**: Show status breakdown, prioritize IN_REVIEW items

## Examples

```
User: Show me my security projects

Claude: [Calls list_projects]
You have 3 security analysis projects:

1. Backend API
   - Status: COMPLETED
   - 5 high-severity threats found

2. Frontend App
   - Status: COMPLETED
   - 2 medium-severity threats found

3. Mobile App
   - Status: PENDING
   - Analysis not yet run
```

```
User: Start security analysis for project abc-123

Claude: [Calls trigger_analysis with project_id=abc-123]
Security analysis started successfully.

Job ID: job-456
Status: RUNNING

The analysis typically takes 5-10 minutes. Use /trent:threats to check status.
```

```
User: What threats were found in project abc-123?

Claude: [Calls get_threats with project_id=abc-123]
Found 7 vulnerabilities in 3 threat categories:

CRITICAL (2):
- SQL Injection in user authentication endpoint
- Hardcoded AWS credentials in configuration file

HIGH (3):
- Cross-site scripting vulnerability in search function
- Missing authentication on admin API endpoints
- Insecure session management

MEDIUM (2):
- Missing input validation on user profile updates
- Weak password policy enforcement
```
