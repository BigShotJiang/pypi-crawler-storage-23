# trent:repo

Automatically detect the current repository and fetch security analysis from Trent.

## When to Use

- User asks about threats/vulnerabilities in "this repo" or "current repo"
- User says "What are my threats?" without specifying a project
- User mentions they're "working on X repo" and wants security info
- User asks about security status of the codebase they're in

## Instructions

### Step 1: Detect Current Repository

Run this bash command to get the current git remote:
```bash
git remote -v | grep origin | head -1 | awk '{print $2}'
```

Parse the output to extract the repository identifier:
- From `git@github.com:trnt-ai/HumberAgent.git` → `trnt-ai/HumberAgent`
- From `https://github.com/trnt-ai/HumberAgent.git` → `trnt-ai/HumberAgent`

### Step 2: Find Matching Project in Trent

Call `list_projects` to get all projects, then find one that matches the repository:
- Look in each project's `repositories` array
- Match by repository name or URL containing the detected repo identifier
- If multiple matches, prefer exact matches

If no matching project is found:
- Inform the user that no Trent project is configured for this repository
- Offer to create one using `create_project` with the detected owner and repository name
- After creation, guide the user to install the Trent GitHub App using the provided link
- They can check analysis status with `get_project` and view results with `get_threats`

### Step 3: Fetch Requested Information

Based on the user's question, call the appropriate tool:
- "threats" or "vulnerabilities" → `get_threats`
- "tasks" or "remediation" → `get_tasks`
- "project details" or "status" → `get_project`
- "start analysis" → `trigger_analysis`

Use the `project_id` from the matched project.

### Step 4: Present Results

Format the results clearly:
- Show the detected repository and matched project name
- For threats: Group by severity (CRITICAL, HIGH, MEDIUM, LOW)
- For tasks: Show status breakdown
- Include a note about when the last analysis was run

## Examples

```
User: What are the threats in my current repo?

Claude:
1. [Runs git remote -v to detect "trnt-ai/HumberAgent"]
2. [Calls list_projects to find matching project]
3. [Calls get_threats with the project_id]

Response:
Detected repository: trnt-ai/HumberAgent
Matched Trent project: HumberAgent

Found 7 vulnerabilities across 3 threat categories:

CRITICAL (2):
- SQL Injection in authentication endpoint
- Hardcoded credentials in config

HIGH (3):
- XSS vulnerability in search function
...
```

```
User: I'm working on the HumberAgent repo. Show me my security tasks.

Claude:
1. [Detects "HumberAgent" from user message + git remote]
2. [Finds matching project]
3. [Calls get_tasks]

Response:
Project: HumberAgent (trnt-ai/HumberAgent)

Remediation Tasks:
- 3 IN_REVIEW (need attention)
- 2 IN_PROGRESS (being worked on)
- 5 COMPLETED
...
```

```
User: Run a security scan on this codebase

Claude:
1. [Detects current repository]
2. [Finds matching project]
3. [Calls trigger_analysis]

Response:
Starting security analysis for HumberAgent...
Analysis job started (ID: job-abc123).
This typically takes 5-10 minutes. I'll let you know when it's ready.
```

## Tips

- If the user mentions a partial repo name like "HumberAgent", try to match it
- Always confirm which project was matched before showing results
- If git remote detection fails, ask the user for the repository name
- Cache the detected repo/project mapping for the conversation to avoid repeated lookups
