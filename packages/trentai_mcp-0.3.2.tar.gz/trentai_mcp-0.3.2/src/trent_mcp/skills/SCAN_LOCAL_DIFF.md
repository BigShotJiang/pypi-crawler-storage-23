# trent:scan

Scan local uncommitted code changes for security vulnerabilities using Trent.

## When to Use

- User asks to "scan my changes" or "check my diff for security issues"
- User wants to know if their local changes introduce vulnerabilities
- User says "run a security scan" while they have uncommitted changes
- Before committing, user wants a security review of their diff

## Instructions

### Step 1: Detect Repository and Project

Run this bash command to get the current git remote:
```bash
git remote -v | grep origin | head -1 | awk '{print $2}'
```

Parse the output to extract the repository identifier:
- From `git@github.com:owner/repo.git` -> `owner/repo`
- From `https://github.com/owner/repo.git` -> `owner/repo`

Then call `list_projects` to get all projects and find one that matches this repository.
Look in each project's `repositories` array for a matching owner/repository pair.

If no matching project is found:
- Inform the user that no Trent project is configured for this repository
- Offer to create one using `create_project` with the detected owner and repository name
- After creation, guide the user to install the Trent GitHub App using the provided link
- Once the GitHub App is installed and analysis completes, they can re-run the scan

### Step 2: Generate the Diff

First, call `get_project` with the matched project name to get the project details.
Check the response for `latest_commit_sha` — this is the commit that Trent last analyzed.

**If `latest_commit_sha` is available:**
Generate a diff against that commit to capture ALL changes since the last analysis
(including local commits not yet analyzed by Trent):
```bash
git diff <latest_commit_sha>
```

**If `latest_commit_sha` is not available** (first scan, or no previous analysis):
Fall back to diffing against HEAD for uncommitted changes only:
```bash
git diff HEAD
```

If the output is empty, check for untracked files:
```bash
git status --porcelain
```

If there are only untracked files but no diff, inform the user:
"No modified files detected. Trent scans changes to existing tracked files.
For new files, commit them first and use /trent:repo to run a full analysis."

### Step 3: Trigger the Scan

Call `scan_local_diff` with:
- `diff_content`: The output from `git diff <latest_commit_sha>` (or `git diff HEAD` as fallback)
- `project_name`: The matched project name (or `project_id`)

**IMPORTANT**: Do NOT pass `wait_for_completion=True`. The default (False) returns
immediately after uploading the diff and triggering analysis. This prevents blocking
the conversation while the scan runs (which can take 3-8 minutes or longer).

The tool will return a response with `status: "running"`, `project_id`, and `job_id`.

### Step 4: Inform the User

After the scan is triggered, tell the user:

1. The scan has been triggered and is running in the background
2. It typically takes 3-8 minutes to complete
3. They can continue working on other tasks
4. When ready to check results, they can:
   - Ask "check my scan results" or "are my scan results ready?"
   - Run `get_project` with the project name to check status
   - Run `get_threats` with the project name to get vulnerability results

### Step 5: Check Results (when user asks)

When the user asks for scan results, call `get_project` to check the status:
- If `status` is `COMPLETED`: Call `get_threats` to fetch results and present them
- If `status` is `RUNNING`: Tell the user the scan is still in progress with the current progress percentage
- If `status` is `FAILED`: Show the error message

**If vulnerabilities found:**
- Group by severity (CRITICAL, HIGH, MEDIUM, LOW)
- For each vulnerability, show title, description, and recommendation
- Highlight any CRITICAL or HIGH severity issues prominently
- Suggest using `get_tasks` for actionable remediation steps

**If no vulnerabilities found:**
- Confirm the changes look clean from a security perspective
- Note that this is an incremental scan of the diff only

## Examples

```
User: Scan my local changes for security issues

Claude:
1. [Runs git remote -v to detect "owner/my-app"]
2. [Calls list_projects to find matching project "my-app"]
3. [Calls get_project to get latest_commit_sha]
4. [Runs git diff <latest_commit_sha> to capture all changes since last analysis]
5. [Calls scan_local_diff with diff content and project name]

Response:
Security scan triggered for your local changes in owner/my-app.
The scan is running in the background and typically takes 3-8 minutes.

You can continue working -- just ask "check my scan results" when you're ready
to see the findings.

---

User: Check my scan results

Claude:
1. [Calls get_project to check status -> COMPLETED]
2. [Calls get_threats to get vulnerability results]

Response:
Scan complete! Found 3 vulnerabilities in your local changes:

CRITICAL (1):
- SQL Injection in new query builder
  Recommendation: Use parameterized queries instead of string concatenation

HIGH (1):
- Missing input validation on user profile endpoint
  Recommendation: Add schema validation for all user inputs

MEDIUM (1):
- Verbose error messages exposing stack traces
  Recommendation: Use generic error messages in production

Use /trent:threats to see all project vulnerabilities, or
get_tasks for remediation steps.
```

## Tips

- The diff content is uploaded securely via presigned S3 URLs
- Incremental analysis focuses on changes, so results are specific to your diff
- The scan runs asynchronously -- you can keep working and check results later
- For a full repository scan, use /trent:repo instead
- If you want to wait for results inline (blocking), pass `wait_for_completion=True`
