# trent:appsec

Security review from Trent's AppSec Advisor.

## When to Use

- User asks for security review of code, plans, or configs
- User asks "Is this secure?"

## Instructions

### Step 1: Gather Context

Before calling the tool, briefly ask about security context if not already provided:
- What security controls already exist? (API Gateway auth, WAF, etc.)
- Is anything intentionally public by design?

Skip if context is obvious from the code or user already provided it.

**If user wants to skip**: Proceed and note assumptions in your response.

**If gathered context conflicts with code** (e.g., user says "no PII" but code handles SSNs): Flag the discrepancy and ask for clarification.

### Step 2: Call the Tool

Use `mcp__trent__appsec` with:
- `content`: The code/plan to review (required)
- `context`: Security context gathered above (recommended)
- `question`: Specific question if user asked one (optional)

### Step 3: Present Results

Attribute to "HumberAgent AppSec Advisor" with severity ratings (CRITICAL/HIGH/MEDIUM/LOW).

### If No Project Found

If the tool response includes `project_not_found: true`, inform the user:
1. No Trent project was found for their repository (`detected_repository`).
2. Offer to create one using `create_project` with the detected owner and repository.
3. After creation, guide the user to install the Trent GitHub App using the provided link.
4. They can check analysis status with `get_project` and view results with `get_threats`.

## Example

```
User: /trent:appsec [selects code]

Claude: Quick question - are there existing security controls (like API Gateway auth)?

User: Yes, API Gateway handles JWT validation

Claude: [Calls tool with context: "API Gateway handles JWT auth"]
```
