# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""Auto-detection of Trent project name from git remote URL."""

import logging
import re
import subprocess
from dataclasses import dataclass
from urllib.parse import urlparse

from trent_mcp.config import get_config

logger = logging.getLogger(__name__)

# Sentinel for "we tried and found nothing" vs "we haven't tried yet"
_NOT_RESOLVED = object()


@dataclass
class ResolvedProject:
    """Result of project name resolution with full context."""

    project_name: str | None  # Matched Trent project name, or None
    owner: str | None  # Detected git remote owner (org/user), or None
    repo: str | None  # Detected git remote repo name, or None

    @property
    def has_match(self) -> bool:
        """True if a Trent project was found for this repo."""
        return self.project_name is not None

    @property
    def has_repo(self) -> bool:
        """True if a git remote was detected (even without a project match)."""
        return self.owner is not None and self.repo is not None


class ProjectNameResolver:
    """
    Resolves the Trent project name for the current working directory.

    Resolution order:
    1. Explicit TRENT_PROJECT_NAME env var (immediate, no API call)
    2. Git remote URL matched against Trent projects (lazy, cached per session)

    Instantiate once per MCP server session and reuse across all tool calls.
    The first call that triggers auto-detection makes one list_projects API call;
    subsequent calls return the cached result.
    """

    def __init__(self) -> None:
        self._cached_result: object | ResolvedProject = _NOT_RESOLVED

    async def resolve(self, client) -> str | None:
        """
        Resolve project name. Returns cached result after first call.

        Args:
            client: TrentAPIClient instance (needed for list_projects)

        Returns:
            Project name string, or None if not resolvable.
        """
        result = await self.resolve_detailed(client)
        return result.project_name

    async def resolve_detailed(self, client) -> ResolvedProject:
        """
        Resolve project with full context. Returns cached result after first call.

        Args:
            client: TrentAPIClient instance (needed for list_projects)

        Returns:
            ResolvedProject with project_name, owner, and repo fields.
        """
        # Priority 1: Explicit env var
        env_name = get_config().project_name
        if env_name:
            return ResolvedProject(project_name=env_name, owner=None, repo=None)

        # Priority 2: Cached auto-detection result
        if self._cached_result is not _NOT_RESOLVED:
            return self._cached_result  # type: ignore[return-value]

        # Priority 3: Auto-detect via git remote + project list
        self._cached_result = await self._auto_detect_detailed(client)
        return self._cached_result  # type: ignore[return-value]

    def reset_cache(self) -> None:
        """Reset the cached resolution result. Call after project creation."""
        self._cached_result = _NOT_RESOLVED

    async def _auto_detect_detailed(self, client) -> ResolvedProject:
        """One-time detection: extract git remote, match against projects."""
        owner_repo = _extract_owner_repo_from_git()
        if not owner_repo:
            logger.debug("No git remote detected, skipping project auto-detection")
            return ResolvedProject(project_name=None, owner=None, repo=None)

        owner, repo = owner_repo
        logger.info(f"Auto-detecting Trent project for {owner}/{repo}")

        try:
            projects = await client.list_projects()
        except Exception as e:
            logger.warning(f"Failed to list projects for auto-detection: {e}")
            return ResolvedProject(project_name=None, owner=owner, repo=repo)

        name = _match_project(projects, owner, repo)
        if name:
            logger.info(f"Auto-detected Trent project: {name}")
        else:
            logger.debug(f"No Trent project found matching {owner}/{repo}")
        return ResolvedProject(project_name=name, owner=owner, repo=repo)


def _extract_owner_repo_from_git() -> tuple[str, str] | None:
    """Extract (owner, repo) from git remote origin URL."""
    try:
        result = subprocess.run(
            ["git", "config", "--get", "remote.origin.url"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0 or not result.stdout.strip():
            return None
        return _parse_git_remote_url(result.stdout.strip())
    except (OSError, subprocess.TimeoutExpired):
        return None


def _parse_git_remote_url(url: str) -> tuple[str, str] | None:
    """
    Parse owner and repo from various git remote URL formats.

    Handles:
      git@github.com:owner/repo.git
      https://github.com/owner/repo.git
      https://github.com/owner/repo
      ssh://git@github.com/owner/repo.git
    """
    # SSH format: git@github.com:owner/repo.git
    ssh_match = re.match(r"^[\w.-]+@[\w.-]+:([\w._-]+)/([\w._-]+?)(?:\.git)?$", url)
    if ssh_match:
        return ssh_match.group(1), ssh_match.group(2)

    # HTTPS or SSH:// format
    try:
        parsed = urlparse(url)
        path = parsed.path.strip("/")
        if path.endswith(".git"):
            path = path[:-4]
        parts = path.split("/")
        if len(parts) >= 2:
            return parts[0], parts[1]
    except Exception:
        pass

    return None


def _match_project(projects: list[dict], owner: str, repo: str) -> str | None:
    """
    Find a single unambiguous project matching the given owner/repo.

    Returns project name if exactly one match, None otherwise.
    """
    matches: list[str] = []
    for project in projects:
        repositories = project.get("repositories", [])
        for r in repositories:
            proj_owner = r.get("owner", "")
            proj_repo = r.get("repository", "")
            if proj_owner.lower() == owner.lower() and proj_repo.lower() == repo.lower():
                name = project.get("name")
                if name:
                    matches.append(name)
                break  # Don't double-count if same repo listed twice

    if len(matches) == 1:
        return matches[0]

    if len(matches) > 1:
        logger.warning(
            f"Multiple Trent projects match {owner}/{repo}: {matches}. "
            "Set TRENT_PROJECT_NAME to disambiguate."
        )

    return None
