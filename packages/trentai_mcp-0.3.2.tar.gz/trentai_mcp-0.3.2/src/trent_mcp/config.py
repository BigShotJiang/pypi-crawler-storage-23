# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""Configuration management for Trent MCP Server."""

import os
from dataclasses import dataclass


@dataclass
class MCPConfig:
    """Configuration for the MCP server."""

    chat_api_url: str
    agent_api_url: str
    auth0_domain: str
    auth0_client_id: str
    auth0_audience: str
    project_name: str | None
    claude_model: str | None


def get_config() -> MCPConfig:
    """
    Load configuration from environment variables.

    Environment Variables:
        TRENT_CHAT_API_URL (or HUMBER_CHAT_API_URL): Chat/AppSec Advisor API URL (streaming, default: https://chat.trent.ai)
        TRENT_AGENT_API_URL (or HUMBER_AGENT_API_URL): Project/Analysis API URL (REST, default: https://api.trent.ai)
        AUTH0_DOMAIN: Auth0 domain for OAuth
        AUTH0_CLIENT_ID: Auth0 client ID for OAuth
        AUTH0_AUDIENCE: Auth0 audience for OAuth
        TRENT_PROJECT_NAME: Override auto-detected project name (optional).
            When not set, the server auto-detects by matching git remote URL
            against Trent projects.
        CLAUDE_MODEL: Claude model identifier (e.g., "claude-opus-4-6") for logging
    """
    return MCPConfig(
        chat_api_url=os.environ.get("TRENT_CHAT_API_URL")
        or os.environ.get("HUMBER_CHAT_API_URL", "https://chat.trent.ai"),
        agent_api_url=os.environ.get("TRENT_AGENT_API_URL")
        or os.environ.get("HUMBER_AGENT_API_URL", "https://api.trent.ai"),
        auth0_domain=os.getenv("AUTH0_DOMAIN", ""),
        auth0_client_id=os.getenv("AUTH0_CLIENT_ID", ""),
        auth0_audience=os.getenv("AUTH0_AUDIENCE", ""),
        project_name=os.getenv("TRENT_PROJECT_NAME"),
        claude_model=os.getenv("CLAUDE_MODEL"),
    )
