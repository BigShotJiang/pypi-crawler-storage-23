# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""JWT Token management with secure OS keychain storage and automatic refresh."""

import json
import logging
import time
from dataclasses import dataclass

import httpx
import keyring

logger = logging.getLogger(__name__)


@dataclass
class TokenInfo:
    """Token information stored in keychain."""

    access_token: str
    refresh_token: str | None
    expires_at: float
    tenant: str


class AuthenticationRequired(Exception):
    """Raised when user needs to authenticate via OAuth flow."""

    pass


class TokenManager:
    """
    Manages JWT tokens with secure OS keychain storage and automatic refresh.

    Authentication flow:
    1. User invokes MCP tool
    2. get_valid_token() finds no token → raises AuthenticationRequired
    3. Caller catches exception and calls authenticate()
    4. authenticate() opens browser for OAuth PKCE login
    5. User logs in, callback received, tokens stored in keychain
    6. Subsequent calls use cached/refreshed token
    """

    SERVICE_NAME = "trent-appsec-mcp"

    def __init__(
        self,
        auth0_domain: str,
        client_id: str,
        audience: str,
    ):
        """
        Initialize the token manager.

        Args:
            auth0_domain: Auth0 domain for OAuth
            client_id: Auth0 client ID
            audience: Auth0 audience
        """
        self.auth0_domain = auth0_domain
        self.client_id = client_id
        self.audience = audience
        self._token_info: TokenInfo | None = None

    def get_valid_token(self) -> str:
        """
        Get a valid token, refreshing if necessary.

        Returns:
            str: Valid JWT access token

        Raises:
            AuthenticationRequired: If no valid token and user needs to authenticate
        """
        # Load from keychain if not cached
        if not self._token_info:
            self._token_info = self._load_token()

        # Check if token is valid (with 5 min buffer for safety)
        if self._token_info and self._token_info.expires_at > time.time() + 300:
            return self._token_info.access_token

        # Try refresh if we have a refresh token
        if self._token_info and self._token_info.refresh_token:
            try:
                logger.info("Refreshing expired token...")
                self._token_info = self._refresh_token()
                self._save_token()
                return self._token_info.access_token
            except Exception as e:
                logger.warning(f"Token refresh failed: {e}")
                # Fall through to require re-auth

        # Need full authentication - caller should call authenticate()
        raise AuthenticationRequired("Authentication required. Initiating login...")

    def authenticate(self) -> str:
        """
        Run OAuth PKCE flow to get initial tokens.

        Opens browser for user to log in to Auth0.
        Waits for callback with authorization code.
        Exchanges code for tokens and stores them.

        Returns:
            str: Valid JWT access token

        Raises:
            Exception: If authentication fails
        """
        from trent_mcp.auth.oauth_flow import PKCEAuthFlow

        logger.info("Starting OAuth PKCE authentication flow...")

        flow = PKCEAuthFlow(
            auth0_domain=self.auth0_domain,
            client_id=self.client_id,
            audience=self.audience,
        )

        # This opens browser and waits for callback
        token_data = flow.authenticate()

        # Store the tokens
        self.store_token(token_data)

        return self._token_info.access_token

    def get_token_or_authenticate(self) -> str:
        """
        Get valid token, automatically authenticating if needed.

        Convenience method that combines get_valid_token() and authenticate().

        Returns:
            str: Valid JWT access token
        """
        try:
            return self.get_valid_token()
        except AuthenticationRequired:
            return self.authenticate()

    def store_token(self, token_data: dict):
        """
        Store token from OAuth flow.

        Args:
            token_data: OAuth token response with access_token, refresh_token, expires_in
        """
        import jwt

        # Decode without verification to get claims (tenant info)
        claims = jwt.decode(
            token_data["access_token"],
            options={"verify_signature": False},
        )

        self._token_info = TokenInfo(
            access_token=token_data["access_token"],
            refresh_token=token_data.get("refresh_token"),
            expires_at=time.time() + token_data.get("expires_in", 3600),
            tenant=claims.get("sub", "unknown"),
        )
        self._save_token()
        logger.info("Token stored successfully")

    _OLD_SERVICE_NAME = "humber-appsec-mcp"

    def _load_token(self) -> TokenInfo | None:
        """Load token from OS keychain, with migration from old service name."""
        try:
            data = keyring.get_password(self.SERVICE_NAME, "token_info")
            if data:
                info = json.loads(data)
                logger.debug("Loaded token from keychain")
                return TokenInfo(**info)
        except Exception as e:
            logger.debug(f"No stored token found under {self.SERVICE_NAME}: {e}")

        # Migration: try loading from old service name
        try:
            old_data = keyring.get_password(self._OLD_SERVICE_NAME, "token_info")
            if old_data:
                info = json.loads(old_data)
                logger.info("Migrating token from old service name to new service name")
                token_info = TokenInfo(**info)
                # Save under new service name
                self._token_info = token_info
                self._save_token()
                # Delete from old service name
                try:
                    keyring.delete_password(self._OLD_SERVICE_NAME, "token_info")
                    logger.info("Deleted token from old service name")
                except keyring.errors.PasswordDeleteError:
                    pass
                return token_info
        except Exception as e:
            logger.debug(f"No stored token found under old service name: {e}")

        return None

    def _save_token(self):
        """Save token to OS keychain."""
        if self._token_info:
            keyring.set_password(
                self.SERVICE_NAME,
                "token_info",
                json.dumps(
                    {
                        "access_token": self._token_info.access_token,
                        "refresh_token": self._token_info.refresh_token,
                        "expires_at": self._token_info.expires_at,
                        "tenant": self._token_info.tenant,
                    }
                ),
            )
            logger.debug("Token saved to keychain")

    def _refresh_token(self) -> TokenInfo:
        """
        Refresh the access token using refresh token.

        Returns:
            TokenInfo: New token information

        Raises:
            Exception: If refresh fails
        """
        if not self._token_info or not self._token_info.refresh_token:
            raise Exception("No refresh token available")

        response = httpx.post(
            f"https://{self.auth0_domain}/oauth/token",
            data={
                "grant_type": "refresh_token",
                "client_id": self.client_id,
                "refresh_token": self._token_info.refresh_token,
            },
            timeout=30.0,
        )
        response.raise_for_status()
        data = response.json()

        return TokenInfo(
            access_token=data["access_token"],
            refresh_token=data.get("refresh_token", self._token_info.refresh_token),
            expires_at=time.time() + data.get("expires_in", 3600),
            tenant=self._token_info.tenant,
        )

    def clear_token(self):
        """Clear stored token (for logout or re-auth)."""
        try:
            keyring.delete_password(self.SERVICE_NAME, "token_info")
            logger.info("Token cleared from keychain")
        except keyring.errors.PasswordDeleteError:
            pass
        self._token_info = None
