# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""OAuth 2.1 with PKCE for secure authentication."""

import base64
import hashlib
import html
import logging
import secrets
import sys
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlencode, urlparse

import httpx

logger = logging.getLogger(__name__)


class PKCEAuthFlow:
    """
    OAuth 2.1 with PKCE (Proof Key for Code Exchange) for secure authentication.

    Flow:
    1. Generate PKCE verifier and challenge
    2. Open browser to Auth0 authorization URL
    3. User logs in and grants permission
    4. Auth0 redirects to localhost callback with authorization code
    5. Exchange code + verifier for tokens

    This is more secure than basic OAuth because:
    - Code verifier is never sent over the network until token exchange
    - Prevents authorization code interception attacks
    """

    def __init__(self, auth0_domain: str, client_id: str, audience: str):
        """
        Initialize the PKCE auth flow.

        Args:
            auth0_domain: Auth0 domain (e.g., "your-tenant.auth0.com")
            client_id: Auth0 application client ID
            audience: Auth0 API audience
        """
        self.auth0_domain = auth0_domain
        self.client_id = client_id
        self.audience = audience
        self.redirect_uri = "http://localhost:8765/callback"

    def authenticate(self) -> dict:
        """
        Run OAuth PKCE flow and return tokens.

        Opens browser for user login, waits for callback with authorization code,
        then exchanges code for tokens.

        Returns:
            dict: Token response with access_token, refresh_token, expires_in

        Raises:
            Exception: If authentication fails
        """
        print("Opening browser for authentication...", file=sys.stderr)

        # Step 1: Generate PKCE verifier and challenge
        verifier = secrets.token_urlsafe(32)
        challenge = (
            base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest())
            .decode()
            .rstrip("=")
        )

        # Step 2: Generate state for CSRF protection
        state = secrets.token_urlsafe(16)

        # Step 3: Build authorization URL
        auth_url = f"https://{self.auth0_domain}/authorize?" + urlencode(
            {
                "response_type": "code",
                "client_id": self.client_id,
                "redirect_uri": self.redirect_uri,
                "scope": "openid profile offline_access",
                "audience": self.audience,
                "state": state,
                "code_challenge": challenge,
                "code_challenge_method": "S256",
            }
        )

        # Step 4: Open browser for user login
        webbrowser.open(auth_url)
        print(f"If browser doesn't open, visit: {auth_url}", file=sys.stderr)
        print("Please complete login in your browser...", file=sys.stderr)

        # Step 5: Start local server to receive callback
        code = self._wait_for_callback(state)

        print("Authentication successful!", file=sys.stderr)

        # Step 6: Exchange code for tokens
        return self._exchange_code(code, verifier)

    def _wait_for_callback(self, expected_state: str) -> str:
        """
        Start local HTTP server and wait for OAuth callback.

        Args:
            expected_state: State parameter to validate (CSRF protection)

        Returns:
            str: Authorization code from callback

        Raises:
            Exception: If callback fails or times out
        """
        result = {"code": None, "error": None}

        class CallbackHandler(BaseHTTPRequestHandler):
            def do_GET(handler_self):
                query = parse_qs(urlparse(handler_self.path).query)

                # Validate state to prevent CSRF attacks
                received_state = query.get("state", [None])[0]
                if received_state != expected_state:
                    result["error"] = "State mismatch - possible CSRF attack"
                elif "error" in query:
                    result["error"] = query["error"][0]
                    error_desc = query.get("error_description", [""])[0]
                    if error_desc:
                        result["error"] += f": {error_desc}"
                else:
                    result["code"] = query.get("code", [None])[0]

                # Send response to browser
                handler_self.send_response(200)
                handler_self.send_header("Content-Type", "text/html")
                handler_self.end_headers()

                if result["code"]:
                    handler_self.wfile.write(self._success_html())
                else:
                    handler_self.wfile.write(self._error_html(result["error"]))

            def log_message(handler_self, *args):
                pass  # Suppress HTTP request logs

        server = HTTPServer(("localhost", 8765), CallbackHandler)
        server.timeout = 120  # 2 minute timeout for user to complete login

        logger.info("Waiting for OAuth callback on localhost:8765...")
        server.handle_request()

        if result["error"]:
            raise Exception(f"OAuth error: {result['error']}")
        if not result["code"]:
            raise Exception("No authorization code received (timeout?)")

        return result["code"]

    def _exchange_code(self, code: str, verifier: str) -> dict:
        """
        Exchange authorization code for tokens.

        Args:
            code: Authorization code from callback
            verifier: PKCE code verifier

        Returns:
            dict: Token response with access_token, refresh_token, expires_in

        Raises:
            Exception: If token exchange fails
        """
        logger.info("Exchanging authorization code for tokens...")

        response = httpx.post(
            f"https://{self.auth0_domain}/oauth/token",
            data={
                "grant_type": "authorization_code",
                "client_id": self.client_id,
                "code": code,
                "redirect_uri": self.redirect_uri,
                "code_verifier": verifier,
            },
            timeout=30.0,
        )

        if response.status_code != 200:
            error_data = response.json()
            error_msg = error_data.get(
                "error_description", error_data.get("error", "Unknown error")
            )
            raise Exception(f"Token exchange failed: {error_msg}")

        return response.json()

    def _success_html(self) -> bytes:
        """Generate success HTML page for browser."""
        return b"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Authentication Successful</title>
            <style>
                body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    margin: 0;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                }
                .container {
                    text-align: center;
                    background: white;
                    padding: 40px 60px;
                    border-radius: 16px;
                    box-shadow: 0 10px 40px rgba(0,0,0,0.2);
                }
                h1 { color: #22c55e; margin-bottom: 16px; }
                p { color: #666; margin: 8px 0; }
                .brand { color: #764ba2; font-weight: 600; }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Authentication Successful!</h1>
                <p>You can close this window and return to Claude Code.</p>
                <p class="brand">Trent AppSec Advisor is now connected.</p>
            </div>
        </body>
        </html>
        """

    def _error_html(self, error: str) -> bytes:
        """Generate error HTML page for browser."""
        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Authentication Failed</title>
            <style>
                body {{
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    margin: 0;
                    background: #f3f4f6;
                }}
                .container {{
                    text-align: center;
                    background: white;
                    padding: 40px 60px;
                    border-radius: 16px;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
                }}
                h1 {{ color: #ef4444; margin-bottom: 16px; }}
                p {{ color: #666; margin: 8px 0; }}
                .error {{ color: #ef4444; font-family: monospace; }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Authentication Failed</h1>
                <p class="error">{html.escape(error)}</p>
                <p>Please try again from Claude Code.</p>
            </div>
        </body>
        </html>
        """.encode()
