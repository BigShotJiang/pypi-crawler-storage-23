# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""Security review tool for Trent MCP Server."""

from typing import Annotated

from mcp.server.fastmcp import Context
from pydantic import Field

from trent_mcp.client.trent_api import TrentAPIClient
from trent_mcp.project_resolver import ProjectNameResolver
from trent_mcp.server import mcp

# Module-level shared state for the entire Claude Code session.
# The MCP server runs as a single process (stdio transport), so these
# persist across all tool calls.
_shared_client: TrentAPIClient | None = None
_resolver: ProjectNameResolver | None = None


def _get_shared_client() -> TrentAPIClient:
    global _shared_client
    if _shared_client is None:
        _shared_client = TrentAPIClient()
    return _shared_client


def _get_resolver() -> ProjectNameResolver:
    global _resolver
    if _resolver is None:
        _resolver = ProjectNameResolver()
    return _resolver


@mcp.tool()
async def appsec(
    content: Annotated[
        str,
        Field(description="Plan, code, config, or any content to review for security"),
    ],
    context: Annotated[
        str | None,
        Field(
            description="Security context (e.g., 'API behind Gateway auth, intentionally public endpoint')"
        ),
    ] = None,
    question: Annotated[
        str | None,
        Field(
            description="Specific security question to answer (e.g., 'Is this auth flow secure?')"
        ),
    ] = None,
    project_name: Annotated[
        str | None,
        Field(
            description="Trent project name to include relevant existing findings. "
            "Auto-detected from git remote if not provided."
        ),
    ] = None,
    ctx: Context | None = None,
) -> dict:
    """
    Review content for security vulnerabilities and get recommendations.

    For best results, include security context about existing controls
    and anything intentionally public by design.
    """
    if ctx:
        await ctx.info("HumberAgent AppSec Advisor reviewing content...")
        await ctx.report_progress(progress=20, total=100)

    client = _get_shared_client()

    # Build message
    message_parts = []
    if question:
        message_parts.append(question)
    else:
        message_parts.append(
            "Review this content for security vulnerabilities and provide recommendations."
        )

    if context and context.strip():
        message_parts.append(f"\n\nSecurity Context:\n{context}")

    # Use explicit param, fall back to auto-detection (env var → git remote match)
    resolved_project = None
    if project_name:
        resolved_name = project_name
    else:
        resolver = _get_resolver()
        resolved_project = await resolver.resolve_detailed(client)
        resolved_name = resolved_project.project_name
    if resolved_name:
        resolved_name = resolved_name.strip()[:200]
        if resolved_name:
            message_parts.append(f"\n\n[TRENT_PROJECT: {resolved_name}]")

    message_parts.append(f"\n\nContent to review:\n{content}")
    message = "".join(message_parts)

    if ctx:
        await ctx.info("Analyzing for security issues...")
        await ctx.report_progress(progress=50, total=100)

    response = await client.chat(message=message, resolved_project_name=resolved_name)

    if ctx:
        await ctx.info("Security review complete")
        await ctx.report_progress(progress=100, total=100)

    if response.get("error"):
        return {
            "source": "HumberAgent AppSec Advisor",
            "error": True,
            "message": response["content"],
        }

    result = {
        "source": "HumberAgent AppSec Advisor",
        "review": response["content"],
        "thread_id": response.get("thread_id"),
    }

    # Surface onboarding hint when no project matched but a repo was detected
    if resolved_project and not resolved_project.has_match and resolved_project.has_repo:
        detected_repo = f"{resolved_project.owner}/{resolved_project.repo}"
        result["project_not_found"] = True
        result["detected_repository"] = detected_repo
        result["onboarding_hint"] = (
            f"No Trent project found for {detected_repo}. "
            "Use create_project to set up continuous security monitoring for this repository."
        )

    return result
