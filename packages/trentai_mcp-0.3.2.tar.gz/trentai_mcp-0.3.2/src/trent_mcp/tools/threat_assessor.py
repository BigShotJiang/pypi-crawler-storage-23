# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""Threat assessment and project management tools for Trent MCP Server."""

from typing import Annotated

from mcp.server.fastmcp import Context
from pydantic import Field

from trent_mcp.client.trent_api import TrentAPIClient
from trent_mcp.server import mcp


async def _resolve_project_id(
    client: TrentAPIClient, project_id: str | None = None, project_name: str | None = None
) -> str:
    """
    Resolve project name to project ID.

    Args:
        client: TrentAPIClient instance
        project_id: Project ID (if provided, returns as-is)
        project_name: Project name (if provided, looks up ID)

    Returns:
        str: Project ID

    Raises:
        ValueError: If neither ID nor name provided, or project not found
    """
    if project_id:
        return project_id

    if not project_name:
        raise ValueError("Either project_id or project_name must be provided")

    # List all projects and find by name
    projects = await client.list_projects()
    for project in projects:
        if project.get("name") == project_name:
            return project.get("project_id") or project.get("id")

    raise ValueError(f"Project not found with name: {project_name}")


@mcp.tool()
async def list_projects(ctx: Context | None = None) -> dict:
    """
    List all security analysis projects for the authenticated user.

    Returns project information including:
    - Project ID, name, and description
    - Analysis status (NO_ANALYSIS, PENDING, RUNNING, COMPLETED, FAILED)
    - Threat count from latest completed analysis
    - Last update timestamp

    Use this to browse existing projects or find a specific project to analyze.
    """
    if ctx:
        await ctx.info("Fetching your security projects...")
        await ctx.report_progress(progress=30, total=100)

    client = TrentAPIClient()
    try:
        projects = await client.list_projects()

        if ctx:
            await ctx.info(f"Found {len(projects)} project(s)")
            await ctx.report_progress(progress=100, total=100)

        return {
            "source": "HumberAgent Threat Assessor",
            "projects": projects,
            "count": len(projects),
        }
    except Exception as e:
        return {
            "source": "HumberAgent Threat Assessor",
            "error": True,
            "message": f"Failed to list projects: {str(e)}",
        }
    finally:
        await client.close()


@mcp.tool()
async def get_project(
    project_id: Annotated[
        str | None,
        Field(description="Project ID (provide either project_id or project_name)"),
    ] = None,
    project_name: Annotated[
        str | None,
        Field(description="Project name (provide either project_id or project_name)"),
    ] = None,
    ctx: Context | None = None,
) -> dict:
    """
    Get detailed information about a specific security project.

    Specify either project_id OR project_name to identify the project.

    Returns:
    - Project metadata (name, description, created date)
    - Data sources (repositories, websites, documents)
    - Compliance types being analyzed (OWASP, SOC2, AWS)
    - Latest analysis status and progress
    - Threat count from latest completed analysis
    - Error details if analysis failed

    Use this to check project configuration and analysis results.
    """
    client = TrentAPIClient()
    try:
        # Resolve project ID from name if needed
        resolved_id = await _resolve_project_id(client, project_id, project_name)

        if ctx:
            await ctx.info(f"Fetching project {resolved_id}...")
            await ctx.report_progress(progress=40, total=100)

        project = await client.get_project(resolved_id)

        if ctx:
            await ctx.info("Project details retrieved")
            await ctx.report_progress(progress=100, total=100)

        return {
            "source": "HumberAgent Threat Assessor",
            "project": project,
        }
    except Exception as e:
        return {
            "source": "HumberAgent Threat Assessor",
            "error": True,
            "message": f"Failed to get project: {str(e)}",
        }
    finally:
        await client.close()


@mcp.tool()
async def trigger_analysis(
    project_id: Annotated[
        str | None,
        Field(description="Project ID (provide either project_id or project_name)"),
    ] = None,
    project_name: Annotated[
        str | None,
        Field(description="Project name (provide either project_id or project_name)"),
    ] = None,
    commit_sha: Annotated[
        str | None,
        Field(description="Git commit SHA to analyze (optional - uses HEAD if not provided)"),
    ] = None,
    enable_incremental: Annotated[
        bool,
        Field(description="Enable incremental analysis (analyzes only changes since last run)"),
    ] = True,
    ctx: Context | None = None,
) -> dict:
    """
    Trigger a new security analysis for a project.

    Specify either project_id OR project_name to identify the project.

    This is an asynchronous operation that starts a background analysis job.
    Returns a job_id that can be used to check status and retrieve results.

    The analysis will:
    - Scan code for OWASP vulnerabilities
    - Check SOC2 compliance controls
    - Generate threat models and data flow diagrams
    - Identify security risks and mitigation strategies

    Use get_threats to retrieve results once analysis completes.
    """
    client = TrentAPIClient()
    try:
        # Resolve project ID from name if needed
        resolved_id = await _resolve_project_id(client, project_id, project_name)

        if ctx:
            await ctx.info(f"Starting analysis for project {resolved_id}...")
            await ctx.report_progress(progress=20, total=100)

        result = await client.trigger_analysis(
            project_id=resolved_id,
            commit_sha=commit_sha,
            enable_incremental=enable_incremental,
        )

        job_id = result.get("job_id")

        if ctx:
            await ctx.info(f"Analysis started with job ID: {job_id}")
            await ctx.report_progress(progress=100, total=100)

        return {
            "source": "HumberAgent Threat Assessor",
            "job_id": job_id,
            "message": "Analysis started successfully. Use get_project to check progress.",
        }
    except Exception as e:
        return {
            "source": "HumberAgent Threat Assessor",
            "error": True,
            "message": f"Failed to trigger analysis: {str(e)}",
        }
    finally:
        await client.close()


@mcp.tool()
async def get_threats(
    project_id: Annotated[
        str | None,
        Field(description="Project ID (provide either project_id or project_name)"),
    ] = None,
    project_name: Annotated[
        str | None,
        Field(description="Project name (provide either project_id or project_name)"),
    ] = None,
    job_id: Annotated[
        str | None,
        Field(
            description="Specific job ID (optional - uses latest completed analysis if not provided)"
        ),
    ] = None,
    ctx: Context | None = None,
) -> dict:
    """
    Get security threats and vulnerabilities identified in the analysis.

    Specify either project_id OR project_name to identify the project.

    Returns two separate lists:
    1. Vulnerabilities - specific security issues with details:
       - id, vulnerability_title, description, severity, likelihood, recommendation
    2. Threats - high-level threat categories (deduplicated):
       - threat_id, threat_title

    Multiple vulnerabilities can belong to the same threat category.
    Use this to review security findings and prioritize remediation.
    """
    client = TrentAPIClient()
    try:
        # Resolve project ID from name if needed
        resolved_id = await _resolve_project_id(client, project_id, project_name)

        if ctx:
            await ctx.info(f"Fetching threats for project {resolved_id}...")
            await ctx.report_progress(progress=30, total=100)

        raw_vulnerabilities = await client.get_threats(project_id=resolved_id, job_id=job_id)

        if ctx:
            await ctx.info(f"Found {len(raw_vulnerabilities)} vulnerability(ies)")
            await ctx.report_progress(progress=100, total=100)

        # Parse vulnerabilities
        vulnerabilities = []
        for vuln in raw_vulnerabilities:
            vulnerabilities.append(
                {
                    "id": vuln.get("id"),
                    "vulnerability_title": vuln.get("title"),  # Vulnerability-specific title
                    "description": vuln.get("description"),
                    "severity": vuln.get("severity"),
                    "likelihood": vuln.get("likelihood"),
                    "recommendation": vuln.get("recommendation"),
                }
            )

        # Extract and deduplicate threats
        threats_dict = {}
        for vuln in raw_vulnerabilities:
            threat_id = vuln.get("threat_id", "")
            threat_title = vuln.get("threat_title", "")
            if threat_id and threat_id not in threats_dict:
                threats_dict[threat_id] = {
                    "threat_id": threat_id,
                    "threat_title": threat_title,
                }

        threats = list(threats_dict.values())

        # Group vulnerabilities by severity
        severity_counts = {}
        for vuln in vulnerabilities:
            severity = vuln.get("severity", "UNKNOWN")
            severity_counts[severity] = severity_counts.get(severity, 0) + 1

        return {
            "source": "HumberAgent Threat Assessor",
            "vulnerabilities": vulnerabilities,
            "threats": threats,
            "vulnerability_count": len(vulnerabilities),
            "threat_count": len(threats),
            "severity_breakdown": severity_counts,
        }
    except Exception as e:
        return {
            "source": "HumberAgent Threat Assessor",
            "error": True,
            "message": f"Failed to get threats: {str(e)}",
        }
    finally:
        await client.close()


@mcp.tool()
async def get_tasks(
    project_id: Annotated[
        str | None,
        Field(description="Project ID (provide either project_id or project_name)"),
    ] = None,
    project_name: Annotated[
        str | None,
        Field(description="Project name (provide either project_id or project_name)"),
    ] = None,
    job_id: Annotated[
        str | None,
        Field(
            description="Specific job ID (optional - uses latest completed analysis if not provided)"
        ),
    ] = None,
    ctx: Context | None = None,
) -> dict:
    """
    Get actionable remediation tasks from the threat analysis.

    Specify either project_id OR project_name to identify the project.

    Returns deduplicated, prioritized mitigation controls including:
    - Task ID (e.g., MT-001)
    - Description of the mitigation control
    - Priority level
    - Effort estimate
    - Current status (IN_REVIEW, IN_PROGRESS, BYPASSED, COMPLETED, INVALIDATED)

    Use this to track remediation progress and manage security tasks.
    Use update_tasks to mark tasks as completed or in progress.
    """
    client = TrentAPIClient()
    try:
        # Resolve project ID from name if needed
        resolved_id = await _resolve_project_id(client, project_id, project_name)

        if ctx:
            await ctx.info(f"Fetching remediation tasks for project {resolved_id}...")
            await ctx.report_progress(progress=30, total=100)

        tasks = await client.get_tasks(project_id=resolved_id, job_id=job_id)

        if ctx:
            await ctx.info(f"Found {len(tasks)} task(s)")
            await ctx.report_progress(progress=100, total=100)

        # Group by status
        status_counts = {}
        for task in tasks:
            status = task.get("control_status", "UNKNOWN")
            status_counts[status] = status_counts.get(status, 0) + 1

        return {
            "source": "HumberAgent Threat Assessor",
            "tasks": tasks,
            "total_count": len(tasks),
            "status_breakdown": status_counts,
        }
    except Exception as e:
        return {
            "source": "HumberAgent Threat Assessor",
            "error": True,
            "message": f"Failed to get tasks: {str(e)}",
        }
    finally:
        await client.close()


@mcp.tool()
async def update_tasks(
    updates: Annotated[
        list[dict],
        Field(
            description="List of task updates. Each update must have: task_id (string), "
            "control_status (IN_REVIEW|IN_PROGRESS|BYPASSED|COMPLETED|INVALIDATED), "
            "and optional reason (string, max 50 chars)"
        ),
    ],
    project_id: Annotated[
        str | None,
        Field(description="Project ID (provide either project_id or project_name)"),
    ] = None,
    project_name: Annotated[
        str | None,
        Field(description="Project name (provide either project_id or project_name)"),
    ] = None,
    ctx: Context | None = None,
) -> dict:
    """
    Update the status of remediation tasks in batch.

    Specify either project_id OR project_name to identify the project.

    Use this to track progress on security remediation:
    - Mark tasks as IN_PROGRESS when you start working on them
    - Mark as COMPLETED when mitigation is implemented
    - Mark as BYPASSED if accepting the risk
    - Mark as INVALIDATED if the threat is not applicable

    All updates are atomic - either all succeed or all fail.
    Status changes are preserved during re-analysis.

    Example updates:
    [
        {"task_id": "MT-001", "control_status": "IN_PROGRESS", "reason": "Started implementation"},
        {"task_id": "MT-002", "control_status": "COMPLETED", "reason": "Fix deployed"}
    ]
    """
    client = TrentAPIClient()
    try:
        # Resolve project ID from name if needed
        resolved_id = await _resolve_project_id(client, project_id, project_name)

        if ctx:
            await ctx.info(f"Updating {len(updates)} task(s) for project {resolved_id}...")
            await ctx.report_progress(progress=40, total=100)

        result = await client.update_task_statuses(
            project_id=resolved_id,
            updates=updates,
        )

        if ctx:
            await ctx.info("Tasks updated successfully")
            await ctx.report_progress(progress=100, total=100)

        return {
            "source": "HumberAgent Threat Assessor",
            "updated_at": result.get("updated_at"),
            "results": result.get("results", []),
            "message": f"Successfully updated {len(updates)} task(s)",
        }
    except Exception as e:
        return {
            "source": "HumberAgent Threat Assessor",
            "error": True,
            "message": f"Failed to update tasks: {str(e)}",
        }
    finally:
        await client.close()
