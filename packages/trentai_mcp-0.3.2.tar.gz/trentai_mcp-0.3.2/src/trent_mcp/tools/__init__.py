# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""MCP Tools for Trent."""

# Import modules to trigger @mcp.tool() decorator registration.
# We import modules (not functions) to avoid shadowing module names
# with same-named functions (e.g. appsec module vs appsec function).
from trent_mcp.tools import (  # noqa: F401
    appsec,
    local_scan,
    project_onboarding,
    threat_assessor,
)
