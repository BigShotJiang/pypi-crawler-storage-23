# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""Local diff scanning tool for Trent MCP Server."""

import asyncio
import hashlib
import logging
import time
from typing import Annotated

from mcp.server.fastmcp import Context
from pydantic import Field

from trent_mcp.client.trent_api import TrentAPIClient
from trent_mcp.server import mcp
from trent_mcp.tools.threat_assessor import _resolve_project_id

logger = logging.getLogger(__name__)

# Constants
MAX_DIFF_SIZE_BYTES = 10 * 1024 * 1024  # 10MB client-side limit
POLL_INTERVAL_SECONDS = 15
DEFAULT_TIMEOUT_SECONDS = 3600  # 1 hour
DOCUMENT_NAME = "local-diff"


def _compute_sha256(content: bytes) -> str:
    """Compute SHA256 digest in the format expected by the backend."""
    return f"sha256:{hashlib.sha256(content).hexdigest()}"


async def _poll_for_completion(
    client: TrentAPIClient,
    project_id: str,
    timeout_seconds: int,
    ctx: Context | None,
) -> dict:
    """
    Poll project status until analysis completes, fails, or times out.

    Args:
        client: API client
        project_id: Project to poll
        timeout_seconds: Maximum wait time
        ctx: MCP context for progress reporting

    Returns:
        Final project dict

    Raises:
        TimeoutError: If analysis does not complete within timeout
        RuntimeError: If analysis fails
    """
    start = time.monotonic()

    while True:
        elapsed = time.monotonic() - start
        if elapsed >= timeout_seconds:
            raise TimeoutError(
                f"Analysis did not complete within {timeout_seconds}s. "
                f"Use get_project to check status."
            )

        project = await client.get_project(project_id)
        status = project.get("status", "UNKNOWN")
        progress = project.get("progress", 0)
        phase = project.get("phase")

        if ctx:
            phase_msg = f" ({phase})" if phase else ""
            await ctx.info(f"Analysis status: {status}{phase_msg} - {progress}%")
            # Map backend 0-100 to tool 20-90 range (reserves room for setup/results)
            mapped_progress = 20 + int(progress * 0.7)
            await ctx.report_progress(progress=mapped_progress, total=100)

        if status == "COMPLETED":
            return project
        elif status == "FAILED":
            error_msg = project.get("error", "Unknown error")
            raise RuntimeError(f"Analysis failed: {error_msg}")
        elif status not in ("PENDING", "RUNNING"):
            raise RuntimeError(f"Unexpected analysis status: {status}")

        await asyncio.sleep(POLL_INTERVAL_SECONDS)


@mcp.tool()
async def scan_local_diff(
    diff_content: Annotated[
        str,
        Field(
            description="Git diff content to scan for security vulnerabilities. "
            "Generate this by running 'git diff <latest_commit_sha>' (preferred, using the "
            "latest_commit_sha from get_project) or 'git diff HEAD' as a fallback."
        ),
    ],
    project_id: Annotated[
        str | None,
        Field(description="Trent project ID (provide either project_id or project_name)"),
    ] = None,
    project_name: Annotated[
        str | None,
        Field(description="Trent project name (provide either project_id or project_name)"),
    ] = None,
    timeout_seconds: Annotated[
        int,
        Field(
            description="Maximum seconds to wait for analysis completion (default: 3600). "
            "Only used when wait_for_completion=True. "
            "If not complete by this time, returns current status with job_id for follow-up."
        ),
    ] = DEFAULT_TIMEOUT_SECONDS,
    wait_for_completion: Annotated[
        bool,
        Field(
            description="Whether to wait for analysis to complete before returning. "
            "Default is False (fire-and-forget): uploads diff, triggers analysis, "
            "and returns immediately with job_id. Set to True to poll until completion "
            "and return vulnerability results inline."
        ),
    ] = False,
    ctx: Context | None = None,
) -> dict:
    """
    Scan local uncommitted code changes for security vulnerabilities.

    This tool uploads a git diff to the Trent project as a CODE_DIFF document,
    triggers an incremental security analysis, waits for completion, and returns
    the vulnerability findings.

    Workflow:
    1. Upload the diff content to S3 via presigned URL
    2. Attach the CODE_DIFF document to the project
    3. Trigger incremental analysis
    4. (If wait_for_completion=True) Poll for completion and return results
    5. (If wait_for_completion=False) Return immediately with job_id for follow-up

    By default, returns immediately after triggering analysis. Use
    get_project to check status and get_threats to fetch results.

    Use the /trent:scan skill for guided usage, or call directly with diff content
    from 'git diff <latest_commit_sha>' (preferred) or 'git diff HEAD'.
    """
    client = TrentAPIClient()
    try:
        # --- Validation ---
        if ctx:
            await ctx.info("Validating diff content...")
            await ctx.report_progress(progress=5, total=100)

        diff_content_stripped = diff_content.strip()
        if not diff_content_stripped:
            return {
                "source": "HumberAgent Local Scan",
                "error": True,
                "message": "No changes detected. The diff content is empty.",
            }

        diff_bytes = diff_content_stripped.encode("utf-8")
        if len(diff_bytes) > MAX_DIFF_SIZE_BYTES:
            size_mb = len(diff_bytes) / (1024 * 1024)
            return {
                "source": "HumberAgent Local Scan",
                "error": True,
                "message": (
                    f"Diff too large: {size_mb:.1f} MB. "
                    f"Maximum: {MAX_DIFF_SIZE_BYTES / (1024 * 1024):.0f} MB. "
                    "Consider committing some changes first and using commit-based analysis."
                ),
            }

        # --- Resolve project ---
        if ctx:
            await ctx.info("Resolving project...")
            await ctx.report_progress(progress=8, total=100)

        resolved_id = await _resolve_project_id(client, project_id, project_name)

        # Fetch current project to get existing documents
        project = await client.get_project(resolved_id)

        if ctx:
            project_display = project.get("name", resolved_id)
            await ctx.info(f"Using project: {project_display}")

        # --- Upload diff ---
        if ctx:
            await ctx.info("Preparing diff upload...")
            await ctx.report_progress(progress=10, total=100)

        digest = _compute_sha256(diff_bytes)

        upload_info = await client.prepare_document_upload(
            name=DOCUMENT_NAME,
            doc_type="code_diff",
            doc_format="diff",
            digest=digest,
        )

        s3_url = upload_info["s3_url"]

        if not upload_info.get("skipped_upload"):
            if ctx:
                await ctx.info("Uploading diff to S3...")
                await ctx.report_progress(progress=13, total=100)
            await client.upload_content_to_presigned_url(
                upload_url=upload_info["upload_url"],
                content=diff_bytes,
                content_type="text/x-diff",
            )
        else:
            if ctx:
                await ctx.info("Diff unchanged since last scan, skipping upload")

        # --- Update project with CODE_DIFF document ---
        if ctx:
            await ctx.info("Attaching diff to project...")
            await ctx.report_progress(progress=15, total=100)

        # Build updated documents list: keep existing non-code-diff docs,
        # replace or add the CODE_DIFF document
        existing_documents = project.get("documents") or []
        updated_documents = [doc for doc in existing_documents if doc.get("type") != "code_diff"]
        updated_documents.append(
            {
                "name": DOCUMENT_NAME,
                "type": "code_diff",
                "s3_url": s3_url,
            }
        )

        # Build update payload preserving existing fields to avoid
        # false-positive change detection in backend's DeepDiff check
        update_payload: dict = {
            "name": project.get("name"),
            "documents": updated_documents,
        }
        if project.get("repositories"):
            update_payload["repositories"] = project["repositories"]
        if project.get("websites"):
            update_payload["websites"] = project["websites"]
        if project.get("compliance"):
            update_payload["compliance"] = project["compliance"]

        await client.update_project(resolved_id, update_payload)

        # --- Trigger analysis ---
        if ctx:
            await ctx.info("Triggering incremental security analysis...")
            await ctx.report_progress(progress=18, total=100)

        analysis_result = await client.trigger_analysis(
            project_id=resolved_id,
            enable_incremental=True,
            enable_local_incremental=True,
        )
        job_id = analysis_result.get("job_id")

        # --- Return early if not waiting ---
        if not wait_for_completion:
            if ctx:
                await ctx.info(
                    f"Analysis triggered (job: {job_id}). "
                    "Use get_project to check status, "
                    "get_threats to fetch results when complete."
                )
                await ctx.report_progress(progress=100, total=100)

            return {
                "source": "HumberAgent Local Scan",
                "status": "running",
                "project_id": resolved_id,
                "project_name": project.get("name"),
                "job_id": job_id,
                "message": (
                    "Analysis triggered successfully. The scan runs in the background "
                    "and typically takes 3-8 minutes. "
                    "Use get_project to check status, "
                    "or get_threats to fetch vulnerability results when complete."
                ),
            }

        if ctx:
            await ctx.info(f"Analysis started (job: {job_id}). Waiting for completion...")
            await ctx.report_progress(progress=20, total=100)

        # --- Poll for completion ---
        try:
            await _poll_for_completion(
                client=client,
                project_id=resolved_id,
                timeout_seconds=timeout_seconds,
                ctx=ctx,
            )
        except TimeoutError:
            return {
                "source": "HumberAgent Local Scan",
                "status": "timeout",
                "project_id": resolved_id,
                "job_id": job_id,
                "message": (
                    f"Analysis still running after {timeout_seconds}s. "
                    "Use get_project or get_threats to check results later."
                ),
            }
        except RuntimeError as e:
            return {
                "source": "HumberAgent Local Scan",
                "error": True,
                "project_id": resolved_id,
                "job_id": job_id,
                "message": str(e),
            }

        # --- Fetch results ---
        if ctx:
            await ctx.info("Fetching vulnerability results...")
            await ctx.report_progress(progress=92, total=100)

        raw_vulnerabilities = await client.get_threats(
            project_id=resolved_id,
            job_id=job_id,
        )

        vulnerabilities = []
        for vuln in raw_vulnerabilities:
            vulnerabilities.append(
                {
                    "id": vuln.get("id"),
                    "vulnerability_title": vuln.get("title"),
                    "description": vuln.get("description"),
                    "severity": vuln.get("severity"),
                    "likelihood": vuln.get("likelihood"),
                    "recommendation": vuln.get("recommendation"),
                }
            )

        severity_counts: dict = {}
        for vuln in vulnerabilities:
            severity = vuln.get("severity", "UNKNOWN")
            severity_counts[severity] = severity_counts.get(severity, 0) + 1

        if ctx:
            await ctx.info(f"Scan complete: {len(vulnerabilities)} vulnerability(ies) found")
            await ctx.report_progress(progress=100, total=100)

        return {
            "source": "HumberAgent Local Scan",
            "status": "completed",
            "project_id": resolved_id,
            "project_name": project.get("name"),
            "job_id": job_id,
            "vulnerabilities": vulnerabilities,
            "vulnerability_count": len(vulnerabilities),
            "severity_breakdown": severity_counts,
        }

    except ValueError as e:
        return {
            "source": "HumberAgent Local Scan",
            "error": True,
            "message": str(e),
        }
    except Exception as e:
        logger.error(f"Local scan failed: {e}", exc_info=True)
        return {
            "source": "HumberAgent Local Scan",
            "error": True,
            "message": f"Scan failed: {str(e)}",
        }
    finally:
        await client.close()
