# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""Project onboarding tool for Trent MCP Server."""

import logging
import re
from typing import Annotated

from mcp.server.fastmcp import Context
from pydantic import Field

from trent_mcp.client.trent_api import TrentAPIClient
from trent_mcp.server import mcp

logger = logging.getLogger(__name__)

# GitHub naming rules: alphanumeric, hyphens, underscores, periods
_GITHUB_NAME_PATTERN = re.compile(r"^[a-zA-Z0-9._-]+$")

# Valid compliance types (mirrors backend ComplianceType enum)
VALID_COMPLIANCE_TYPES = {"OWASP", "SOC2", "AWS", "FIRMWARE_OWASP", "THREAT_MODEL"}

GITHUB_APP_INSTALL_URL = "https://github.com/apps/trent-ai-code-connector/installations/new"


def _validate_github_name(value: str, field_name: str) -> str | None:
    """Validate a GitHub owner or repository name. Returns error message or None."""
    if not value or not value.strip():
        return f"{field_name} cannot be empty"
    if len(value) > 100:
        return f"{field_name} exceeds maximum length of 100 characters"
    if not _GITHUB_NAME_PATTERN.match(value):
        return (
            f"{field_name} contains invalid characters. "
            "Only alphanumeric, hyphens, underscores, and periods are allowed."
        )
    return None


@mcp.tool()
async def create_project(
    owner: Annotated[
        str,
        Field(description="GitHub repository owner (organization or username)"),
    ],
    repository: Annotated[
        str,
        Field(description="GitHub repository name"),
    ],
    name: Annotated[
        str | None,
        Field(description="Project name (optional, defaults to 'owner/repository')"),
    ] = None,
    compliance: Annotated[
        list[str] | None,
        Field(
            description="Compliance frameworks to analyze. "
            "Valid values: OWASP, SOC2, AWS, FIRMWARE_OWASP, THREAT_MODEL. "
            "Defaults to ['OWASP', 'THREAT_MODEL']."
        ),
    ] = None,
    trigger_analysis: Annotated[
        bool,
        Field(
            description="Whether to trigger the initial security analysis after creation. "
            "Default is True. Requires GitHub App to be installed for code access."
        ),
    ] = True,
    ctx: Context | None = None,
) -> dict:
    """
    Create a new Trent security analysis project for a GitHub repository.

    This sets up continuous security monitoring for the repository including
    OWASP vulnerability scanning, threat modeling, and compliance checks.

    After creation, you'll need to install the Trent GitHub App on the
    repository for code access. The tool provides the installation link.

    Use get_project to check project status and get_threats
    to view results after analysis completes.
    """
    # --- Input Validation ---
    owner_error = _validate_github_name(owner, "owner")
    if owner_error:
        return {"source": "HumberAgent Project Onboarding", "error": True, "message": owner_error}

    repo_error = _validate_github_name(repository, "repository")
    if repo_error:
        return {"source": "HumberAgent Project Onboarding", "error": True, "message": repo_error}

    # Default compliance
    if compliance is None:
        compliance = ["OWASP", "THREAT_MODEL"]

    # Validate compliance types
    invalid_types = [c for c in compliance if c not in VALID_COMPLIANCE_TYPES]
    if invalid_types:
        return {
            "source": "HumberAgent Project Onboarding",
            "error": True,
            "message": (
                f"Invalid compliance type(s): {invalid_types}. "
                f"Valid values: {sorted(VALID_COMPLIANCE_TYPES)}"
            ),
        }

    if ctx:
        await ctx.info(f"Creating Trent project for {owner}/{repository}...")
        await ctx.report_progress(progress=10, total=100)

    client = TrentAPIClient()
    try:
        project_name = name or f"{owner}/{repository}"

        project = await client.create_project(
            repositories=[{"owner": owner, "repository": repository}],
            compliance=compliance,
            name=project_name,
        )

        project_id = project.get("project_id")

        if ctx:
            await ctx.info(f"Project created: {project_name} (ID: {project_id})")
            await ctx.report_progress(progress=50, total=100)

        result: dict = {
            "source": "HumberAgent Project Onboarding",
            "project_id": project_id,
            "project_name": project.get("name"),
            "status": project.get("status"),
            "compliance": compliance,
            "repository": f"{owner}/{repository}",
            "github_app_install_url": GITHUB_APP_INSTALL_URL,
            "next_steps": [
                f"Install the Trent GitHub App on your repository: {GITHUB_APP_INSTALL_URL}",
                "Select the repository to grant Trent code access.",
            ],
        }

        # Invalidate the shared resolver cache so subsequent appsec calls
        # pick up the newly created project.
        try:
            from trent_mcp.tools.appsec import _get_resolver

            _get_resolver().reset_cache()
        except Exception:
            pass  # Best-effort; resolver may not be initialized yet

        # Optionally trigger initial analysis
        if trigger_analysis:
            if ctx:
                await ctx.info("Triggering initial security analysis...")
                await ctx.report_progress(progress=70, total=100)

            try:
                analysis_result = await client.trigger_analysis(
                    project_id=project_id,
                    enable_incremental=False,
                )
                job_id = analysis_result.get("job_id")

                result["analysis_triggered"] = True
                result["job_id"] = job_id
                result["next_steps"].extend(
                    [
                        "Initial analysis has been triggered and runs in the background "
                        "(typically 5-10 minutes).",
                        "Use get_project to check analysis status.",
                        "Use get_threats to view vulnerability results when complete.",
                    ]
                )
            except Exception as e:
                logger.warning(f"Failed to trigger initial analysis: {e}")
                result["analysis_triggered"] = False
                result["analysis_error"] = str(e)
                result["next_steps"].append(
                    "Could not trigger initial analysis automatically. "
                    "Ensure the GitHub App is installed, then use trigger_analysis."
                )
        else:
            result["analysis_triggered"] = False
            result["next_steps"].append(
                "Use trigger_analysis to start the first security analysis when ready."
            )

        if ctx:
            await ctx.info("Project onboarding complete")
            await ctx.report_progress(progress=100, total=100)

        return result

    except Exception as e:
        error_msg = str(e)
        if "409" in error_msg or "conflict" in error_msg.lower():
            return {
                "source": "HumberAgent Project Onboarding",
                "error": True,
                "message": (
                    f"A project for {owner}/{repository} may already exist. "
                    "Use list_projects to check."
                ),
            }
        return {
            "source": "HumberAgent Project Onboarding",
            "error": True,
            "message": f"Failed to create project: {error_msg}",
        }
    finally:
        await client.close()
