# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""FastMCP Server for Trent AppSec Advisor integration with Claude Code."""

import logging
import sys

from mcp.server.fastmcp import FastMCP

# Critical: Log to stderr for stdio transport (stdout is reserved for MCP protocol)
logging.basicConfig(
    level=logging.INFO,
    stream=sys.stderr,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# Create the MCP server instance
mcp = FastMCP(
    name="trent",
    instructions="""
    HumberAgent AppSec Advisor - A Principal Security Engineer that helps
    developers discover vulnerabilities, understand security best practices,
    and build secure systems.

    ## When to Use appsec

    **Proactive (Automatic):**
    - Before presenting ANY implementation plan
    - When reviewing or editing plan files (plans/*.md, *-plan.md, *_plan.md)
    - When creating code that handles auth, data, or APIs
    - Infrastructure or CDK/IaC changes
    - Configuration changes (env vars, secrets, permissions)

    **Skip when:**
    - Trivial single-line fixes or typo corrections
    - Pure README updates
    - User explicitly says "skip security review"

    **Reactive (User Request):**
    - User asks "Is this secure?" or "Is this plan secure?"
    - User wants security review of plans, code, configs, or architecture
    - User asks about security considerations for a feature
    - User runs /trent:appsec explicitly

    ## Project Context

    The server automatically detects the Trent project for the current
    repository by matching the git remote URL against your Trent projects.
    This provides context-filtered findings without any configuration.

    To override auto-detection, set TRENT_PROJECT_NAME in the server environment.

    ## What AppSec Advisor Can Do

    - Provide security recommendations for plans and designs
    - Identify security vulnerabilities in code and configs
    - Explain security concepts (OWASP, STRIDE, CWE)
    - Suggest secure implementation patterns
    - Search security knowledge base for guidance

    ## What AppSec Advisor Does NOT Do

    - General coding/debugging unrelated to security
    - Performance optimization (unless security-related)
    - Automated code fixing or remediation
    - UI/UX design or business logic

    ## Response Format

    Attribute findings to HumberAgent:
    "Based on security review from HumberAgent AppSec Advisor:"

    Include severity ratings: CRITICAL, HIGH, MEDIUM, LOW

    ## Other Tools (Use When Explicitly Requested)

    ### Project Management
    - **list_projects**: Browse all security analysis projects
    - **get_project**: View detailed project information and status

    ### Threat Analysis
    - **trigger_analysis**: Start new security analysis (async operation)
    - **get_threats**: View identified vulnerabilities and threat categories
    - **get_tasks**: Get actionable remediation tasks
    - **update_tasks**: Track remediation progress

    Use these when user mentions "Trent", "projects", "threats", or "tasks".

    ### Local Change Scanning
    - **scan_local_diff**: Upload local git diff and run incremental security analysis

    Use this when user mentions "scan my changes", "check my diff", or "/trent:scan".

    ### Project Onboarding
    - **create_project**: Create a new Trent project for a GitHub repository

    Use this when:
    - appsec returns `project_not_found: true` — inform the user that no Trent project
      exists for their repository and offer to create one using create_project.
    - User explicitly asks to create or set up a Trent project.

    After project creation:
    1. Tell the user to install the Trent GitHub App using the provided `github_app_install_url`.
    2. Explain they can check analysis status with `get_project`.
    3. Once analysis completes, they can view results with `get_threats` and `get_tasks`.
    """,
)


def main():
    """Run the MCP server with stdio transport."""
    logger.info("Starting Trent MCP Server...")

    # Import tools package to register them with the server.
    # This triggers the @mcp.tool() decorators via __init__.py.
    import trent_mcp.tools  # noqa: F401

    logger.info("Tools registered, starting server...")
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
