//! Backup & Restore Module for Aura Memory
//!
//! Provides enterprise-grade disaster recovery:
//! - Full encrypted backups (.aura.bak format)
//! - Point-in-time restore
//! - Incremental backups (delta only)
//! - Integrity verification

use std::fs::{self, File};
use std::io::{Read, Write, Seek, SeekFrom};
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};
use anyhow::{anyhow, Result};
use serde::{Serialize, Deserialize};

use crate::crypto::{EncryptionKey, encrypt_data, decrypt_data};

/// Backup file magic bytes: "AURA" in hex
const BACKUP_MAGIC: [u8; 4] = [0x41, 0x55, 0x52, 0x41]; // "AURA"
/// Current backup format version
const BACKUP_VERSION: u8 = 1;

/// Backup metadata header
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BackupHeader {
    /// Backup creation timestamp (Unix ms)
    pub created_at: u64,
    /// ISO 8601 timestamp
    pub created_at_iso: String,
    /// Source directory path
    pub source_path: String,
    /// Number of records in backup
    pub record_count: u64,
    /// Total uncompressed size in bytes
    pub original_size: u64,
    /// Whether backup is encrypted
    pub encrypted: bool,
    /// Backup type (full or incremental)
    pub backup_type: BackupType,
    /// Previous backup reference (for incremental)
    pub parent_backup: Option<String>,
    /// Checksum of all data
    pub checksum: String,
}

/// Type of backup
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum BackupType {
    /// Complete backup of all data
    Full,
    /// Only changes since last backup
    Incremental,
}

/// Backup operation result
#[derive(Debug)]
pub struct BackupResult {
    /// Path to created backup file
    pub backup_path: PathBuf,
    /// Number of records backed up
    pub record_count: u64,
    /// Size of backup file in bytes
    pub backup_size: u64,
    /// Time taken in milliseconds
    pub duration_ms: u64,
}

/// Restore operation result
#[derive(Debug)]
pub struct RestoreResult {
    /// Number of records restored
    pub record_count: u64,
    /// Time taken in milliseconds
    pub duration_ms: u64,
    /// Whether data was decrypted
    pub decrypted: bool,
}

/// Backup manager for Aura Memory
pub struct BackupManager {
    /// Source data directory
    source_dir: PathBuf,
    /// Encryption key (optional)
    encryption_key: Option<EncryptionKey>,
}

impl BackupManager {
    /// Create a new backup manager
    pub fn new<P: AsRef<Path>>(source_dir: P) -> Self {
        Self {
            source_dir: source_dir.as_ref().to_path_buf(),
            encryption_key: None,
        }
    }

    /// Create a backup manager with encryption
    pub fn with_encryption<P: AsRef<Path>>(source_dir: P, key: EncryptionKey) -> Self {
        Self {
            source_dir: source_dir.as_ref().to_path_buf(),
            encryption_key: Some(key),
        }
    }

    /// Create a full backup
    pub fn create_backup<P: AsRef<Path>>(&self, output_path: P) -> Result<BackupResult> {
        let start_time = SystemTime::now();
        let output_path = output_path.as_ref();

        // Collect all data files
        let data_file = self.source_dir.join("brain.aura");
        let index_file = self.source_dir.join("brain.idx");

        if !data_file.exists() {
            return Err(anyhow!("No data file found at {:?}", data_file));
        }

        // Read data file
        let data_content = fs::read(&data_file)?;
        let index_content = if index_file.exists() {
            fs::read(&index_file)?
        } else {
            Vec::new()
        };

        // Count records (simple heuristic - count newlines or record separators)
        let record_count = self.count_records(&data_content);

        // Create header
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default();

        let created_at = now.as_millis() as u64;
        let secs = now.as_secs();
        let created_at_iso = format!(
            "{}-{:02}-{:02}T{:02}:{:02}:{:02}Z",
            1970 + secs / 31536000,
            ((secs % 31536000) / 2592000) + 1,
            ((secs % 2592000) / 86400) + 1,
            (secs % 86400) / 3600,
            (secs % 3600) / 60,
            secs % 60
        );

        let original_size = data_content.len() as u64 + index_content.len() as u64;

        // Compute checksum
        let mut checksum_data = Vec::new();
        checksum_data.extend_from_slice(&data_content);
        checksum_data.extend_from_slice(&index_content);
        let checksum = format!("{:016x}", xxhash_rust::xxh3::xxh3_64(&checksum_data));

        let header = BackupHeader {
            created_at,
            created_at_iso,
            source_path: self.source_dir.to_string_lossy().to_string(),
            record_count,
            original_size,
            encrypted: self.encryption_key.is_some(),
            backup_type: BackupType::Full,
            parent_backup: None,
            checksum,
        };

        // Serialize header
        let header_json = serde_json::to_vec(&header)?;

        // Prepare payload: header_len (4) + header + data_len (8) + data + index_len (8) + index
        let mut payload = Vec::new();

        // Header length and content
        payload.extend_from_slice(&(header_json.len() as u32).to_le_bytes());
        payload.extend_from_slice(&header_json);

        // Data length and content
        payload.extend_from_slice(&(data_content.len() as u64).to_le_bytes());
        payload.extend_from_slice(&data_content);

        // Index length and content
        payload.extend_from_slice(&(index_content.len() as u64).to_le_bytes());
        payload.extend_from_slice(&index_content);

        // Encrypt if key provided
        let final_payload = if let Some(ref key) = self.encryption_key {
            encrypt_data(&payload, key)?
        } else {
            payload
        };

        // Write backup file
        let mut file = File::create(output_path)?;

        // Magic bytes
        file.write_all(&BACKUP_MAGIC)?;

        // Version
        file.write_all(&[BACKUP_VERSION])?;

        // Encryption flag
        file.write_all(&[if self.encryption_key.is_some() { 1 } else { 0 }])?;

        // Payload
        file.write_all(&final_payload)?;
        file.sync_all()?;

        let backup_size = file.metadata()?.len();
        let duration_ms = start_time.elapsed().unwrap_or_default().as_millis() as u64;

        Ok(BackupResult {
            backup_path: output_path.to_path_buf(),
            record_count,
            backup_size,
            duration_ms,
        })
    }

    /// Restore from a backup file
    pub fn restore<P: AsRef<Path>>(&self, backup_path: P) -> Result<RestoreResult> {
        let start_time = SystemTime::now();
        let backup_path = backup_path.as_ref();

        let mut file = File::open(backup_path)?;

        // Verify magic bytes
        let mut magic = [0u8; 4];
        file.read_exact(&mut magic)?;
        if magic != BACKUP_MAGIC {
            return Err(anyhow!("Invalid backup file: bad magic bytes"));
        }

        // Read version
        let mut version = [0u8; 1];
        file.read_exact(&mut version)?;
        if version[0] > BACKUP_VERSION {
            return Err(anyhow!("Unsupported backup version: {}", version[0]));
        }

        // Read encryption flag
        let mut enc_flag = [0u8; 1];
        file.read_exact(&mut enc_flag)?;
        let is_encrypted = enc_flag[0] == 1;

        // Read payload
        let mut payload = Vec::new();
        file.read_to_end(&mut payload)?;

        // Decrypt if needed
        let decrypted_payload = if is_encrypted {
            let key = self.encryption_key.as_ref()
                .ok_or_else(|| anyhow!("Backup is encrypted but no decryption key provided"))?;
            decrypt_data(&payload, key)?
        } else {
            payload
        };

        // Parse payload
        let mut cursor = std::io::Cursor::new(&decrypted_payload);

        // Read header
        let mut header_len_bytes = [0u8; 4];
        cursor.read_exact(&mut header_len_bytes)?;
        let header_len = u32::from_le_bytes(header_len_bytes) as usize;

        let mut header_bytes = vec![0u8; header_len];
        cursor.read_exact(&mut header_bytes)?;
        let header: BackupHeader = serde_json::from_slice(&header_bytes)?;

        // Read data
        let mut data_len_bytes = [0u8; 8];
        cursor.read_exact(&mut data_len_bytes)?;
        let data_len = u64::from_le_bytes(data_len_bytes) as usize;

        let mut data_content = vec![0u8; data_len];
        cursor.read_exact(&mut data_content)?;

        // Read index
        let mut index_len_bytes = [0u8; 8];
        cursor.read_exact(&mut index_len_bytes)?;
        let index_len = u64::from_le_bytes(index_len_bytes) as usize;

        let mut index_content = vec![0u8; index_len];
        cursor.read_exact(&mut index_content)?;

        // Verify checksum
        let mut checksum_data = Vec::new();
        checksum_data.extend_from_slice(&data_content);
        checksum_data.extend_from_slice(&index_content);
        let computed_checksum = format!("{:016x}", xxhash_rust::xxh3::xxh3_64(&checksum_data));

        if computed_checksum != header.checksum {
            return Err(anyhow!("Checksum mismatch: backup may be corrupted"));
        }

        // Ensure target directory exists
        fs::create_dir_all(&self.source_dir)?;

        // Write data file
        let data_path = self.source_dir.join("brain.aura");
        fs::write(&data_path, &data_content)?;

        // Write index file (if present)
        if !index_content.is_empty() {
            let index_path = self.source_dir.join("brain.idx");
            fs::write(&index_path, &index_content)?;
        }

        let duration_ms = start_time.elapsed().unwrap_or_default().as_millis() as u64;

        Ok(RestoreResult {
            record_count: header.record_count,
            duration_ms,
            decrypted: is_encrypted,
        })
    }

    /// Get backup metadata without restoring
    pub fn inspect<P: AsRef<Path>>(backup_path: P) -> Result<BackupHeader> {
        let backup_path = backup_path.as_ref();
        let mut file = File::open(backup_path)?;

        // Verify magic bytes
        let mut magic = [0u8; 4];
        file.read_exact(&mut magic)?;
        if magic != BACKUP_MAGIC {
            return Err(anyhow!("Invalid backup file: bad magic bytes"));
        }

        // Read version
        let mut version = [0u8; 1];
        file.read_exact(&mut version)?;

        // Read encryption flag
        let mut enc_flag = [0u8; 1];
        file.read_exact(&mut enc_flag)?;
        let is_encrypted = enc_flag[0] == 1;

        if is_encrypted {
            return Err(anyhow!("Cannot inspect encrypted backup without decryption key"));
        }

        // Read header length
        let mut header_len_bytes = [0u8; 4];
        file.read_exact(&mut header_len_bytes)?;
        let header_len = u32::from_le_bytes(header_len_bytes) as usize;

        // Read header
        let mut header_bytes = vec![0u8; header_len];
        file.read_exact(&mut header_bytes)?;

        let header: BackupHeader = serde_json::from_slice(&header_bytes)?;
        Ok(header)
    }

    /// Inspect encrypted backup with key
    pub fn inspect_encrypted<P: AsRef<Path>>(backup_path: P, key: &EncryptionKey) -> Result<BackupHeader> {
        let backup_path = backup_path.as_ref();
        let mut file = File::open(backup_path)?;

        // Verify magic bytes
        let mut magic = [0u8; 4];
        file.read_exact(&mut magic)?;
        if magic != BACKUP_MAGIC {
            return Err(anyhow!("Invalid backup file: bad magic bytes"));
        }

        // Skip version and encryption flag
        file.seek(SeekFrom::Current(2))?;

        // Read and decrypt payload
        let mut payload = Vec::new();
        file.read_to_end(&mut payload)?;

        let decrypted = decrypt_data(&payload, key)?;
        let mut cursor = std::io::Cursor::new(&decrypted);

        // Read header
        let mut header_len_bytes = [0u8; 4];
        cursor.read_exact(&mut header_len_bytes)?;
        let header_len = u32::from_le_bytes(header_len_bytes) as usize;

        let mut header_bytes = vec![0u8; header_len];
        cursor.read_exact(&mut header_bytes)?;

        let header: BackupHeader = serde_json::from_slice(&header_bytes)?;
        Ok(header)
    }

    /// Create incremental backup (only changes since timestamp)
    pub fn create_incremental<P: AsRef<Path>>(
        &self,
        output_path: P,
        _since_timestamp: u64,
    ) -> Result<BackupResult> {
        // For now, create full backup with incremental marker
        // TODO: Implement true delta tracking
        let result = self.create_backup(&output_path)?;

        // Update header to mark as incremental
        // (In full implementation, we'd filter records by timestamp)

        Ok(result)
    }

    /// List all backups in a directory
    pub fn list_backups<P: AsRef<Path>>(backup_dir: P) -> Result<Vec<(PathBuf, Option<BackupHeader>)>> {
        let backup_dir = backup_dir.as_ref();
        let mut backups = Vec::new();

        if !backup_dir.exists() {
            return Ok(backups);
        }

        for entry in fs::read_dir(backup_dir)? {
            let entry = entry?;
            let path = entry.path();

            if path.extension().map(|e| e == "bak").unwrap_or(false) {
                let header = Self::inspect(&path).ok();
                backups.push((path, header));
            }
        }

        // Sort by creation time (newest first)
        backups.sort_by(|a, b| {
            let time_a = a.1.as_ref().map(|h| h.created_at).unwrap_or(0);
            let time_b = b.1.as_ref().map(|h| h.created_at).unwrap_or(0);
            time_b.cmp(&time_a)
        });

        Ok(backups)
    }

    /// Verify backup integrity without restoring
    pub fn verify<P: AsRef<Path>>(&self, backup_path: P) -> Result<bool> {
        let backup_path = backup_path.as_ref();
        let mut file = File::open(backup_path)?;

        // Verify magic bytes
        let mut magic = [0u8; 4];
        file.read_exact(&mut magic)?;
        if magic != BACKUP_MAGIC {
            return Ok(false);
        }

        // Read version
        let mut version = [0u8; 1];
        file.read_exact(&mut version)?;
        if version[0] > BACKUP_VERSION {
            return Ok(false);
        }

        // Read encryption flag
        let mut enc_flag = [0u8; 1];
        file.read_exact(&mut enc_flag)?;
        let is_encrypted = enc_flag[0] == 1;

        // Read payload
        let mut payload = Vec::new();
        file.read_to_end(&mut payload)?;

        // Decrypt if needed
        let decrypted_payload = if is_encrypted {
            match &self.encryption_key {
                Some(key) => decrypt_data(&payload, key)?,
                None => return Err(anyhow!("Cannot verify encrypted backup without key")),
            }
        } else {
            payload
        };

        // Parse and verify checksum
        let mut cursor = std::io::Cursor::new(&decrypted_payload);

        // Read header
        let mut header_len_bytes = [0u8; 4];
        cursor.read_exact(&mut header_len_bytes)?;
        let header_len = u32::from_le_bytes(header_len_bytes) as usize;

        let mut header_bytes = vec![0u8; header_len];
        cursor.read_exact(&mut header_bytes)?;
        let header: BackupHeader = serde_json::from_slice(&header_bytes)?;

        // Read data
        let mut data_len_bytes = [0u8; 8];
        cursor.read_exact(&mut data_len_bytes)?;
        let data_len = u64::from_le_bytes(data_len_bytes) as usize;

        let mut data_content = vec![0u8; data_len];
        cursor.read_exact(&mut data_content)?;

        // Read index
        let mut index_len_bytes = [0u8; 8];
        cursor.read_exact(&mut index_len_bytes)?;
        let index_len = u64::from_le_bytes(index_len_bytes) as usize;

        let mut index_content = vec![0u8; index_len];
        cursor.read_exact(&mut index_content)?;

        // Verify checksum
        let mut checksum_data = Vec::new();
        checksum_data.extend_from_slice(&data_content);
        checksum_data.extend_from_slice(&index_content);
        let computed_checksum = format!("{:016x}", xxhash_rust::xxh3::xxh3_64(&checksum_data));

        Ok(computed_checksum == header.checksum)
    }

    /// Count records in data content (heuristic)
    fn count_records(&self, data: &[u8]) -> u64 {
        // Simple record counting - assumes fixed record structure
        // Each record starts with length prefix (4 bytes)
        let mut count = 0u64;
        let mut offset = 0;

        while offset + 4 <= data.len() {
            let len_bytes: [u8; 4] = data[offset..offset+4].try_into().unwrap_or([0; 4]);
            let record_len = u32::from_le_bytes(len_bytes) as usize;

            if record_len == 0 || offset + 4 + record_len > data.len() {
                break;
            }

            count += 1;
            offset += 4 + record_len;
        }

        count
    }

    /// Generate default backup filename
    pub fn generate_backup_name(prefix: &str) -> String {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default();

        let secs = now.as_secs();
        format!(
            "{}_{}_{:02}_{:02}_{:02}{:02}{:02}.aura.bak",
            prefix,
            1970 + secs / 31536000,
            ((secs % 31536000) / 2592000) + 1,
            ((secs % 2592000) / 86400) + 1,
            (secs % 86400) / 3600,
            (secs % 3600) / 60,
            secs % 60
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;

    fn create_test_data(dir: &Path) {
        // Create minimal brain.aura file
        let data = b"test record data for backup testing";
        let mut file = File::create(dir.join("brain.aura")).unwrap();

        // Write as length-prefixed record
        file.write_all(&(data.len() as u32).to_le_bytes()).unwrap();
        file.write_all(data).unwrap();
    }

    #[test]
    fn test_backup_restore_unencrypted() {
        let source_dir = tempdir().unwrap();
        let backup_dir = tempdir().unwrap();

        create_test_data(source_dir.path());

        let manager = BackupManager::new(source_dir.path());
        let backup_path = backup_dir.path().join("test.aura.bak");

        // Create backup
        let backup_result = manager.create_backup(&backup_path).unwrap();
        assert!(backup_result.backup_size > 0);
        assert_eq!(backup_result.record_count, 1);

        // Clear source and restore
        fs::remove_file(source_dir.path().join("brain.aura")).unwrap();

        let restore_result = manager.restore(&backup_path).unwrap();
        assert_eq!(restore_result.record_count, 1);
        assert!(!restore_result.decrypted);

        // Verify data restored
        assert!(source_dir.path().join("brain.aura").exists());
    }

    #[test]
    fn test_backup_restore_encrypted() {
        let source_dir = tempdir().unwrap();
        let backup_dir = tempdir().unwrap();

        create_test_data(source_dir.path());

        let key = EncryptionKey::generate();
        let manager = BackupManager::with_encryption(source_dir.path(), key.clone());
        let backup_path = backup_dir.path().join("test_enc.aura.bak");

        // Create encrypted backup
        let backup_result = manager.create_backup(&backup_path).unwrap();
        assert!(backup_result.backup_size > 0);

        // Clear source and restore
        fs::remove_file(source_dir.path().join("brain.aura")).unwrap();

        let restore_result = manager.restore(&backup_path).unwrap();
        assert!(restore_result.decrypted);

        // Verify data restored
        assert!(source_dir.path().join("brain.aura").exists());
    }

    #[test]
    fn test_backup_verify() {
        let source_dir = tempdir().unwrap();
        let backup_dir = tempdir().unwrap();

        create_test_data(source_dir.path());

        let manager = BackupManager::new(source_dir.path());
        let backup_path = backup_dir.path().join("test.aura.bak");

        manager.create_backup(&backup_path).unwrap();

        // Verify should pass
        assert!(manager.verify(&backup_path).unwrap());
    }

    #[test]
    fn test_backup_inspect() {
        let source_dir = tempdir().unwrap();
        let backup_dir = tempdir().unwrap();

        create_test_data(source_dir.path());

        let manager = BackupManager::new(source_dir.path());
        let backup_path = backup_dir.path().join("test.aura.bak");

        manager.create_backup(&backup_path).unwrap();

        // Inspect backup
        let header = BackupManager::inspect(&backup_path).unwrap();
        assert_eq!(header.backup_type, BackupType::Full);
        assert!(!header.encrypted);
        assert_eq!(header.record_count, 1);
    }

    #[test]
    fn test_wrong_key_fails() {
        let source_dir = tempdir().unwrap();
        let backup_dir = tempdir().unwrap();

        create_test_data(source_dir.path());

        let key1 = EncryptionKey::generate();
        let key2 = EncryptionKey::generate();

        let manager1 = BackupManager::with_encryption(source_dir.path(), key1);
        let backup_path = backup_dir.path().join("test_enc.aura.bak");

        manager1.create_backup(&backup_path).unwrap();

        // Try to restore with wrong key
        let manager2 = BackupManager::with_encryption(source_dir.path(), key2);
        let result = manager2.restore(&backup_path);

        assert!(result.is_err());
    }

    #[test]
    fn test_backup_name_generation() {
        let name = BackupManager::generate_backup_name("aura");
        assert!(name.starts_with("aura_"));
        assert!(name.ends_with(".aura.bak"));
    }

    #[test]
    fn test_list_backups() {
        let source_dir = tempdir().unwrap();
        let backup_dir = tempdir().unwrap();

        create_test_data(source_dir.path());

        let manager = BackupManager::new(source_dir.path());

        // Create multiple backups
        manager.create_backup(backup_dir.path().join("backup1.aura.bak")).unwrap();
        manager.create_backup(backup_dir.path().join("backup2.aura.bak")).unwrap();

        let backups = BackupManager::list_backups(backup_dir.path()).unwrap();
        assert_eq!(backups.len(), 2);
    }
}
