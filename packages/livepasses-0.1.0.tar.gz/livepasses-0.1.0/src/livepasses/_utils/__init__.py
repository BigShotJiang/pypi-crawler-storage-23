"""Internal utilities for the Livepasses SDK."""
