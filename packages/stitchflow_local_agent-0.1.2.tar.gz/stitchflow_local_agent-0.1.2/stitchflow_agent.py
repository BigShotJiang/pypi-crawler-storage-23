#!/usr/bin/env python3
"""Stitchflow local agent (run-once + daemon modes).

This tool polls Stitchflow agent-browser tasks for a workspace and executes
ChatGPT user removals locally through `agent-browser` with a persistent profile.
"""

from __future__ import annotations

import asyncio
import json
import os
import pathlib
import platform
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from typing import Any

try:
    import httpx
except ImportError:
    print("ERROR: httpx is required. Install with: pip install httpx")
    sys.exit(1)

try:
    import keyring
except ImportError:
    keyring = None


LOCAL_ENV_FILE = pathlib.Path.home() / ".stitchflow" / "agent.env"
STITCHFLOW_HOME_DIR = pathlib.Path.home() / ".stitchflow"
ARTIFACTS_DIR = STITCHFLOW_HOME_DIR / "artifacts"
LOGS_DIR = STITCHFLOW_HOME_DIR / "logs"
AUDIT_LOG_PATH = LOGS_DIR / "audit.log"
KEYRING_SERVICE_NAME = "stitchflow-local-agent"


def _load_persisted_env() -> None:
    """Load persisted agent env values into process env if missing."""
    if not LOCAL_ENV_FILE.exists():
        return

    try:
        for raw_line in LOCAL_ENV_FILE.read_text().splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("export "):
                line = line[len("export ") :]
            if "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value
    except Exception as exc:
        print(f"WARNING: Could not load persisted env file: {exc}")


def _get_api_key_from_keyring(workspace_id: str) -> str:
    if not workspace_id or keyring is None:
        return ""
    try:
        return keyring.get_password(KEYRING_SERVICE_NAME, workspace_id) or ""
    except Exception:
        return ""


def _set_api_key_in_keyring(workspace_id: str, api_key: str) -> bool:
    if not workspace_id or keyring is None:
        return False
    try:
        keyring.set_password(KEYRING_SERVICE_NAME, workspace_id, api_key)
        return True
    except Exception as exc:
        print(f"WARNING: Failed to store API key in system keychain: {exc}")
        return False


_load_persisted_env()


API_URL = os.environ.get("STITCHFLOW_API_URL", "http://localhost:3030")
API_KEY = os.environ.get("STITCHFLOW_API_KEY", "")
WORKSPACE_ID = os.environ.get("STITCHFLOW_WORKSPACE_ID", "")
if not API_KEY and WORKSPACE_ID:
    API_KEY = _get_api_key_from_keyring(WORKSPACE_ID)

DEFAULT_PROFILE_PATH = str(pathlib.Path.home() / ".agent-browser-profile")
BROWSER_PROFILE = os.environ.get("AGENT_BROWSER_PROFILE", DEFAULT_PROFILE_PATH)

HEARTBEAT_INTERVAL_SECONDS = 30
POLL_INTERVAL_SECONDS = int(os.environ.get("STITCHFLOW_AGENT_POLL_INTERVAL_SECONDS", "60"))
POLL_MAX_IDLE_SECONDS = int(os.environ.get("STITCHFLOW_AGENT_POLL_MAX_IDLE_SECONDS", "900"))
POLL_MAX_ERROR_SECONDS = int(os.environ.get("STITCHFLOW_AGENT_POLL_MAX_ERROR_SECONDS", "300"))
MACHINE_ID = f"{platform.node()}-{os.getpid()}"

CHATGPT_ADMIN_URL = "https://chatgpt.com/admin/members"
AUTOMATION_LOCK_ELEMENT_ID = "stitchflow-automation-lock-overlay"
BROWSER_CLOSED_ERROR_MARKERS = (
    "target page, context or browser has been closed",
    "browser has been closed",
    "page has been closed",
    "context has been closed",
)


def _command_exists(name: str) -> bool:
    return shutil.which(name) is not None


def _run_checked(cmd: list[str], timeout: int = 300) -> bool:
    print(f"$ {' '.join(cmd)}")
    try:
        result = subprocess.run(cmd, check=False, timeout=timeout)
        return result.returncode == 0
    except Exception as exc:
        print(f"  ! Command failed: {exc}")
        return False


def _is_browser_closed_error(error_text: str | None) -> bool:
    if not error_text:
        return False
    text = error_text.lower()
    return any(marker in text for marker in BROWSER_CLOSED_ERROR_MARKERS)


def _recover_browser_session() -> bool:
    """Try to recreate an active browser page using the persisted profile."""
    print("  ! Browser session closed. Reopening ChatGPT admin page...")
    cmd = ["agent-browser", "--profile", BROWSER_PROFILE, "--headed", "open", CHATGPT_ADMIN_URL]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=45)
        if result.returncode != 0:
            err = result.stderr.strip()
            print(f"  x Failed to recover browser session: {err}")
            return False
        return True
    except Exception as exc:
        print(f"  x Failed to recover browser session: {exc}")
        return False


def _ensure_agent_browser_installed(auto_install: bool = True) -> bool:
    """Ensure agent-browser CLI and Chromium are available.

    We cannot reliably install npm packages during pip installation.
    So we auto-install during first-time setup/login if missing.
    """
    if _command_exists("agent-browser"):
        _run_checked(["agent-browser", "--version"], timeout=20)
    elif auto_install:
        print("agent-browser not found. Attempting automatic install...")
        install_attempts: list[list[str]] = []
        if _command_exists("npm"):
            install_attempts.append(["npm", "install", "-g", "agent-browser"])
        if sys.platform == "darwin" and _command_exists("brew"):
            install_attempts.append(["brew", "install", "agent-browser"])

        installed = False
        for attempt in install_attempts:
            if _run_checked(attempt, timeout=600) and _command_exists("agent-browser"):
                installed = True
                break
        if not installed:
            print("ERROR: Could not install agent-browser automatically.")
            print("Install manually:")
            print("  npm install -g agent-browser")
            if sys.platform == "darwin":
                print("  # or")
                print("  brew install agent-browser")
            return False
    else:
        print("ERROR: agent-browser CLI is not installed.")
        return False

    print("Ensuring browser runtime is installed (Chromium)...")
    if not _run_checked(["agent-browser", "install"], timeout=600):
        print("ERROR: Failed to run `agent-browser install`.")
        print("Try manually: agent-browser install")
        return False
    return True


def run_agent_browser(
    args: list[str],
    timeout: int = 60,
    headed: bool = True,
    _allow_recovery_retry: bool = True,
) -> dict[str, Any]:
    """Execute an agent-browser command and parse output."""
    cmd = ["agent-browser", "--profile", BROWSER_PROFILE]
    if headed:
        cmd.append("--headed")
    cmd.extend(args)
    print(f"  -> {' '.join(cmd)}")

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode != 0:
            err = result.stderr.strip()
            print(f"  x agent-browser error (exit {result.returncode}): {err}")
            if (
                _allow_recovery_retry
                and args
                and args[0] != "open"
                and _is_browser_closed_error(err)
                and _recover_browser_session()
            ):
                print("  ... retrying command after browser recovery")
                return run_agent_browser(args, timeout=timeout, headed=headed, _allow_recovery_retry=False)
            return {"error": err, "exit_code": result.returncode}

        stdout = result.stdout.strip()
        try:
            parsed = json.loads(stdout)
            if isinstance(parsed, dict):
                return parsed
            return {"output": parsed}
        except json.JSONDecodeError:
            return {"output": stdout}
    except subprocess.TimeoutExpired:
        return {"error": f"Timed out after {timeout}s"}
    except FileNotFoundError:
        return {"error": "agent-browser CLI not found. Install with: npm install -g agent-browser"}


def _snapshot_text(snapshot: dict[str, Any]) -> str:
    return snapshot.get("data", {}).get("snapshot", "") or snapshot.get("snapshot", "")


def _snapshot_refs(snapshot: dict[str, Any]) -> dict[str, Any]:
    refs = snapshot.get("data", {}).get("refs", {})
    if not refs:
        refs = snapshot.get("refs", {})
    return refs


def _check_current_url() -> str:
    result = run_agent_browser(["eval", "(() => window.location.href)()"], timeout=10)
    return str(result.get("output", ""))


def _is_on_admin_page(url: str) -> bool:
    return "/admin" in url


def _set_browser_interaction_lock(enabled: bool) -> None:
    """Add/remove a page overlay that blocks user interactions."""
    if enabled:
        js_lock = (
            "(() => {"
            f"  const id = '{AUTOMATION_LOCK_ELEMENT_ID}';"
            "  if (document.getElementById(id)) return 'already_locked';"
            "  const overlay = document.createElement('div');"
            "  overlay.id = id;"
            "  overlay.style.position = 'fixed';"
            "  overlay.style.inset = '0';"
            "  overlay.style.zIndex = '2147483647';"
            "  overlay.style.background = 'rgba(0, 0, 0, 0.12)';"
            "  overlay.style.display = 'flex';"
            "  overlay.style.alignItems = 'flex-start';"
            "  overlay.style.justifyContent = 'center';"
            "  overlay.style.paddingTop = '12px';"
            "  overlay.style.pointerEvents = 'auto';"
            "  overlay.style.cursor = 'wait';"
            "  overlay.innerHTML = \"<div style='background:#111827;color:#fff;padding:8px 12px;border-radius:8px;"
            "font:600 12px/1.3 -apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;opacity:.95;'>"
            "stitchflow-automation-lock-overlay: Stitchflow automation in progress</div>\";"
            "  const stop = (e) => { e.preventDefault(); e.stopPropagation(); };"
            "  overlay.addEventListener('click', stop, true);"
            "  overlay.addEventListener('mousedown', stop, true);"
            "  overlay.addEventListener('mouseup', stop, true);"
            "  overlay.addEventListener('pointerdown', stop, true);"
            "  overlay.addEventListener('pointerup', stop, true);"
            "  window.__stitchflowLockKeyHandler = stop;"
            "  document.addEventListener('keydown', window.__stitchflowLockKeyHandler, true);"
            "  document.body.appendChild(overlay);"
            "  return 'locked';"
            "})()"
        )
        run_agent_browser(["eval", js_lock], timeout=15)
        return

    js_unlock = (
        "(() => {"
        f"  const overlay = document.getElementById('{AUTOMATION_LOCK_ELEMENT_ID}');"
        "  if (overlay) overlay.remove();"
        "  if (window.__stitchflowLockKeyHandler) {"
        "    document.removeEventListener('keydown', window.__stitchflowLockKeyHandler, true);"
        "    delete window.__stitchflowLockKeyHandler;"
        "  }"
        "  return 'unlocked';"
        "})()"
    )
    run_agent_browser(["eval", js_unlock], timeout=10)


async def _ensure_authenticated() -> dict[str, Any] | None:
    """Ensure the current profile can access ChatGPT admin page."""
    result = run_agent_browser(["open", CHATGPT_ADMIN_URL], timeout=30)
    if result.get("error"):
        return {"status": "error", "error": result["error"]}

    await asyncio.sleep(5)
    current_url = _check_current_url()
    if _is_on_admin_page(current_url):
        return None

    print("  ! Session expired. Please re-login in opened browser.")
    login_cmd = ["agent-browser", "--profile", BROWSER_PROFILE, "--headed", "open", CHATGPT_ADMIN_URL]
    subprocess.run(login_cmd)

    result = run_agent_browser(["open", CHATGPT_ADMIN_URL], timeout=30)
    if result.get("error"):
        return {"status": "error", "error": result["error"]}
    await asyncio.sleep(5)
    current_url = _check_current_url()
    if not _is_on_admin_page(current_url):
        return {
            "status": "error",
            "error": f"Still not authenticated after re-login (at {current_url})",
        }
    return None


async def _wait_for_member_table() -> dict[str, Any]:
    snapshot: dict[str, Any] = {}
    for attempt in range(1, 6):
        await asyncio.sleep(4 + (attempt * 2))
        snapshot = run_agent_browser(["snapshot", "--json"], timeout=30)
        if snapshot.get("error"):
            return snapshot
        if "@" in _snapshot_text(snapshot):
            print(f"  ✓ Page loaded on attempt {attempt}")
            return snapshot
        print("  ... waiting for members page")
    return snapshot


async def _search_for_email(email: str) -> dict[str, Any]:
    email_json = json.dumps(email)
    js = (
        "(() => {"
        "  const input = document.querySelector("
        "    'input[placeholder*=\"Filter\"], input[placeholder*=\"filter\"],"
        "     input[placeholder*=\"Search\"], input[placeholder*=\"search\"],"
        "     input[type=\"search\"]'"
        "  );"
        "  if (!input) return 'no_search_input';"
        "  const nativeSet = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;"
        f"  nativeSet.call(input, {email_json});"
        "  input.dispatchEvent(new Event('input', { bubbles: true }));"
        "  input.dispatchEvent(new Event('change', { bubbles: true }));"
        "  return 'filled';"
        "})()"
    )
    run_agent_browser(["eval", js], timeout=15)
    await asyncio.sleep(2)
    return run_agent_browser(["snapshot", "--json"], timeout=30)


async def _clear_search_filter() -> None:
    js = (
        "(() => {"
        "  const input = document.querySelector("
        "    'input[placeholder*=\"Filter\"], input[placeholder*=\"filter\"],"
        "     input[placeholder*=\"Search\"], input[placeholder*=\"search\"],"
        "     input[type=\"search\"]'"
        "  );"
        "  if (!input) return 'no_input';"
        "  const nativeSet = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;"
        "  nativeSet.call(input, '');"
        "  input.dispatchEvent(new Event('input', { bubbles: true }));"
        "  input.dispatchEvent(new Event('change', { bubbles: true }));"
        "  return 'cleared';"
        "})()"
    )
    run_agent_browser(["eval", js], timeout=10)
    await asyncio.sleep(1)


async def _refresh_members_page() -> bool:
    hard_refresh_js = (
        "(() => {"
        "  const url = new URL(window.location.href);"
        "  url.searchParams.set('__stitchflow_hard_refresh', Date.now().toString());"
        "  window.location.replace(url.toString());"
        "  return 'hard_reloading';"
        "})()"
    )
    run_agent_browser(["eval", hard_refresh_js], timeout=10)
    await asyncio.sleep(5)
    if not _is_on_admin_page(_check_current_url()):
        auth_err = await _ensure_authenticated()
        if auth_err:
            return False
    snapshot = await _wait_for_member_table()
    return not snapshot.get("error")


def _js_click_row_menu_button(email: str) -> str:
    email_json = json.dumps(email.lower())
    return (
        "(() => {"
        f"  const email = {email_json};"
        "  const rows = document.querySelectorAll('tr, [role=\"row\"]');"
        "  for (const row of rows) {"
        "    const text = (row.textContent || '').toLowerCase();"
        "    if (!text.includes(email)) continue;"
        "    const btn = row.querySelector('[aria-haspopup=\"menu\"]') ||"
        "      row.querySelector('button[data-state]') ||"
        "      row.querySelector('td:last-child button, button');"
        "    if (!btn) return 'not_found_trigger';"
        "    btn.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, button: 0, pointerType: 'mouse' }));"
        "    btn.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, button: 0 }));"
        "    btn.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, button: 0 }));"
        "    btn.dispatchEvent(new MouseEvent('click', { bubbles: true, button: 0 }));"
        "    return 'opened_attempted';"
        "  }"
        "  return 'not_found_row';"
        "})()"
    )


def _safe_name(value: str) -> str:
    return "".join(ch if ch.isalnum() or ch in ("-", "_", ".") else "_" for ch in value)


def _artifact_dir_for_task(task_id: str, email: str) -> pathlib.Path:
    date_prefix = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    task_part = _safe_name(task_id or "unknown-task")
    email_part = _safe_name(email or "unknown-email")
    artifact_dir = ARTIFACTS_DIR / f"{date_prefix}_{task_part}_{email_part}"
    artifact_dir.mkdir(parents=True, exist_ok=True)
    return artifact_dir


def _capture_screenshot(path: pathlib.Path) -> bool:
    result = run_agent_browser(["screenshot", str(path)], timeout=30)
    return not result.get("error")


def _append_audit_log(entry: dict[str, Any]) -> None:
    try:
        LOGS_DIR.mkdir(parents=True, exist_ok=True)
        with AUDIT_LOG_PATH.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=True) + "\n")
    except Exception as exc:
        print(f"WARNING: Failed to append audit log: {exc}")


async def remove_chatgpt_user(email: str, task_id: str = "", page_ready: bool = False) -> dict[str, Any]:
    print(f"\n  Looking up {email} in ChatGPT...")
    artifact_dir = _artifact_dir_for_task(task_id, email)
    audit_file = artifact_dir / "audit.json"
    before_screenshot = artifact_dir / "before.png"
    after_screenshot = artifact_dir / "after.png"
    audit: dict[str, Any] = {
        "task_id": task_id,
        "email": email,
        "started_at": datetime.now(timezone.utc).isoformat(),
        "artifact_dir": str(artifact_dir),
        "before_screenshot": str(before_screenshot),
        "after_screenshot": str(after_screenshot),
        "events": [],
    }
    final_status = "unknown"

    def add_event(message: str, **extra: Any) -> None:
        event = {"ts": datetime.now(timezone.utc).isoformat(), "message": message}
        event.update(extra)
        audit["events"].append(event)

    if not page_ready:
        auth_err = await _ensure_authenticated()
        if auth_err:
            add_event("authentication_failed", error=auth_err.get("error"))
            final_status = "error"
            return {**auth_err, "email": email}
        snapshot = await _wait_for_member_table()
        if snapshot.get("error"):
            add_event("member_table_load_failed", error=snapshot.get("error"))
            final_status = "error"
            return {"status": "error", "error": snapshot["error"], "email": email}

    _set_browser_interaction_lock(True)
    try:
        add_event("browser_interaction_lock_enabled")
        snapshot = await _search_for_email(email)
        if snapshot.get("error"):
            add_event("email_search_failed", error=snapshot.get("error"))
            final_status = "error"
            return {"status": "error", "error": snapshot["error"], "email": email}
        add_event("email_search_completed")

        text = _snapshot_text(snapshot).lower()
        refs = _snapshot_refs(snapshot)
        in_snapshot = email.lower() in text or any(email.lower() in str(v).lower() for v in refs.values())
        if not in_snapshot:
            await _clear_search_filter()
            add_event("user_not_found")
            final_status = "skipped"
            return {
                "status": "skipped",
                "reason": "User not found in ChatGPT team",
                "email": email,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        before_ok = _capture_screenshot(before_screenshot)
        add_event("before_screenshot_captured", success=before_ok)
        menu_result = run_agent_browser(["eval", _js_click_row_menu_button(email)], timeout=15)
        if menu_result.get("error") or "not_found" in str(menu_result.get("output", "")).lower():
            await _clear_search_filter()
            add_event("open_menu_failed", output=menu_result.get("output"), error=menu_result.get("error"))
            final_status = "error"
            return {"status": "error", "error": "Could not open user actions menu", "email": email}
        add_event("open_menu_succeeded")

        await asyncio.sleep(2)
        js_remove = (
            "(() => {"
            "  const root = document.querySelector('[data-state=\"open\"][role=\"menu\"]') ||"
            "    document.querySelector('[data-radix-popper-content-wrapper] [role=\"menu\"]') || document;"
            "  const items = root.querySelectorAll('[role=\"menuitem\"], [data-radix-collection-item], [role=\"option\"], button, a');"
            "  for (const el of items) {"
            "    const text = (el.textContent || '').toLowerCase().trim();"
            "    if (text.includes('remove member') || text.includes('remove user') || text === 'remove') {"
            "      el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, button: 0, pointerType: 'mouse' }));"
            "      el.dispatchEvent(new MouseEvent('click', { bubbles: true, button: 0 }));"
            "      return 'clicked';"
            "    }"
            "  }"
            "  return 'not_found';"
            "})()"
        )
        remove_result = run_agent_browser(["eval", js_remove], timeout=15)
        if "not_found" in str(remove_result.get("output", "")).lower():
            await _clear_search_filter()
            add_event("remove_member_option_not_found")
            final_status = "error"
            return {"status": "error", "error": "Could not find Remove member in menu", "email": email}
        add_event("remove_member_option_clicked")

        await asyncio.sleep(2)
        js_confirm = (
            "(() => {"
            "  const dialog = document.querySelector('[role=\"alertdialog\"][data-state=\"open\"]') ||"
            "    document.querySelector('[role=\"dialog\"][data-state=\"open\"]') ||"
            "    document.querySelector('[role=\"alertdialog\"]') || document.querySelector('[role=\"dialog\"]');"
            "  if (!dialog) return 'not_found_dialog';"
            "  const buttons = dialog.querySelectorAll('button, [role=\"button\"]');"
            "  for (const btn of buttons) {"
            "    const text = (btn.textContent || '').toLowerCase().trim();"
            "    if (text === 'delete' || text === 'remove' || text.includes('remove member') || text.includes('delete member')) {"
            "      btn.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, button: 0, pointerType: 'mouse' }));"
            "      btn.dispatchEvent(new MouseEvent('click', { bubbles: true, button: 0 }));"
            "      return 'clicked';"
            "    }"
            "  }"
            "  return 'not_found';"
            "})()"
        )
        confirm_result = run_agent_browser(["eval", js_confirm], timeout=15)
        if "clicked" not in str(confirm_result.get("output", "")).lower():
            await _clear_search_filter()
            add_event("confirm_delete_click_failed", output=confirm_result.get("output"))
            final_status = "error"
            return {"status": "error", "error": "Could not click delete confirm button", "email": email}
        add_event("confirm_delete_clicked")

        await asyncio.sleep(2)
        await _clear_search_filter()
        refreshed = await _refresh_members_page()
        add_event("members_page_hard_refreshed", success=refreshed)
        after_ok = _capture_screenshot(after_screenshot)
        add_event("after_screenshot_captured", success=after_ok)
        final_status = "removed"
        return {
            "status": "removed",
            "email": email,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "ui_refreshed": refreshed,
            "artifacts": {
                "audit_file": str(audit_file),
                "before_screenshot": str(before_screenshot),
                "after_screenshot": str(after_screenshot),
            },
        }
    finally:
        _set_browser_interaction_lock(False)
        add_event("browser_interaction_lock_disabled")
        audit["ended_at"] = datetime.now(timezone.utc).isoformat()
        audit_file.write_text(json.dumps(audit, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
        _append_audit_log(
            {
                "task_id": task_id,
                "email": email,
                "ended_at": audit["ended_at"],
                "status": final_status,
                "artifact_dir": str(artifact_dir),
                "audit_file": str(audit_file),
            }
        )


class StitchflowAPIClient:
    def __init__(self, base_url: str, api_key: str, workspace_id: str) -> None:
        self.base_url = base_url.rstrip("/")
        self.workspace_id = workspace_id
        self.headers = {"Content-Type": "application/json"}
        if api_key:
            self.headers["Authorization"] = f"Bearer {api_key}"

    async def get_pending_tasks(self) -> list[dict[str, Any]]:
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                f"{self.base_url}/agent-browser/tasks",
                headers=self.headers,
                params={"workspace": self.workspace_id, "status": "PENDING"},
                timeout=30,
            )
            resp.raise_for_status()
            return resp.json()

    async def claim_task(self, task_id: str) -> dict[str, Any]:
        async with httpx.AsyncClient() as client:
            resp = await client.patch(
                f"{self.base_url}/agent-browser/tasks/{task_id}?workspace={self.workspace_id}",
                headers=self.headers,
                json={"status": "IN_PROGRESS", "locked_by": MACHINE_ID},
                timeout=30,
            )
            resp.raise_for_status()
            return resp.json()

    async def complete_task(self, task_id: str, result: dict[str, Any]) -> dict[str, Any]:
        async with httpx.AsyncClient() as client:
            resp = await client.patch(
                f"{self.base_url}/agent-browser/tasks/{task_id}?workspace={self.workspace_id}",
                headers=self.headers,
                json={"status": "COMPLETED", "result": result},
                timeout=30,
            )
            resp.raise_for_status()
            return resp.json()

    async def fail_task(self, task_id: str, error_message: str) -> dict[str, Any]:
        async with httpx.AsyncClient() as client:
            resp = await client.patch(
                f"{self.base_url}/agent-browser/tasks/{task_id}?workspace={self.workspace_id}",
                headers=self.headers,
                json={"status": "FAILED", "error_message": error_message},
                timeout=30,
            )
            resp.raise_for_status()
            return resp.json()

    async def send_heartbeat(self, task_id: str) -> None:
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.base_url}/agent-browser/tasks/{task_id}/heartbeat?workspace={self.workspace_id}",
                headers=self.headers,
                timeout=10,
            )
            resp.raise_for_status()


async def heartbeat_loop(api: StitchflowAPIClient, task_id: str, stop_event: asyncio.Event) -> None:
    while not stop_event.is_set():
        try:
            await api.send_heartbeat(task_id)
        except Exception as exc:
            print(f"  ! Heartbeat failed: {exc}")
        await asyncio.sleep(HEARTBEAT_INTERVAL_SECONDS)


async def process_pending_tasks(api: StitchflowAPIClient) -> dict[str, int]:
    print("Fetching pending tasks...")
    try:
        tasks = await api.get_pending_tasks()
    except Exception as exc:
        print(f"ERROR: Failed to fetch tasks: {exc}")
        return {"total": 0, "completed": 0, "failed": 1}

    if not tasks:
        print("No pending tasks.")
        return {"total": 0, "completed": 0, "failed": 0}

    print(f"Found {len(tasks)} task(s)")
    completed = 0
    failed = 0

    # group for ChatGPT batching
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for task in tasks:
        grouped.setdefault((task["integration"], task["action"]), []).append(task)

    idx = 0
    for (integration, action), group_tasks in grouped.items():
        page_ready = False
        if integration == "chatgpt" and action == "remove_user" and len(group_tasks) > 1:
            auth_err = await _ensure_authenticated()
            if auth_err is None:
                page_ready = not (await _wait_for_member_table()).get("error")

        for task in group_tasks:
            idx += 1
            task_id = task["id"]
            email = task.get("parameters", {}).get("email", "unknown")
            print(f"--- Task {idx}/{len(tasks)}: {action} {email} ---")

            try:
                await api.claim_task(task_id)
            except Exception as exc:
                print(f"  x claim failed: {exc}")
                failed += 1
                continue

            stop_event = asyncio.Event()
            hb_task = asyncio.create_task(heartbeat_loop(api, task_id, stop_event))

            try:
                if integration == "chatgpt" and action == "remove_user":
                    result = await remove_chatgpt_user(email, task_id=task_id, page_ready=page_ready)
                else:
                    result = {"status": "error", "error": f"No handler for {integration}/{action}"}

                if result.get("status") in ("removed", "skipped"):
                    await api.complete_task(task_id, result)
                    completed += 1
                    print(f"  ✓ {email}: {result.get('status')}")
                else:
                    err = result.get("error", "Unknown error")
                    await api.fail_task(task_id, err)
                    failed += 1
                    print(f"  x {email}: {err}")
            except Exception as exc:
                failed += 1
                try:
                    await api.fail_task(task_id, str(exc))
                except Exception:
                    pass
                print(f"  x {email}: exception {exc}")
            finally:
                stop_event.set()
                hb_task.cancel()
                try:
                    await hb_task
                except asyncio.CancelledError:
                    pass

    print(f"Summary: {completed} completed, {failed} failed")
    return {"total": len(tasks), "completed": completed, "failed": failed}


async def run_all_tasks() -> None:
    if not WORKSPACE_ID:
        print("ERROR: STITCHFLOW_WORKSPACE_ID not set")
        sys.exit(1)
    if not _ensure_agent_browser_installed(auto_install=False):
        sys.exit(1)
    _ensure_profile_dir()
    api = StitchflowAPIClient(API_URL, API_KEY, WORKSPACE_ID)
    await process_pending_tasks(api)


async def run_daemon() -> None:
    if not WORKSPACE_ID:
        print("ERROR: STITCHFLOW_WORKSPACE_ID not set")
        sys.exit(1)
    if not _ensure_agent_browser_installed(auto_install=False):
        sys.exit(1)
    _ensure_profile_dir()
    api = StitchflowAPIClient(API_URL, API_KEY, WORKSPACE_ID)
    print("Daemon started. Press Ctrl+C to stop.")
    sleep_seconds = POLL_INTERVAL_SECONDS
    cycle = 0
    while True:
        cycle += 1
        print(f"\n-- poll cycle {cycle} --")
        try:
            res = await process_pending_tasks(api)
            total = res.get("total", 0)
            failed = res.get("failed", 0)
            if total > 0:
                sleep_seconds = POLL_INTERVAL_SECONDS
            elif failed > 0:
                sleep_seconds = min(max(POLL_INTERVAL_SECONDS, sleep_seconds * 2), POLL_MAX_ERROR_SECONDS)
            else:
                sleep_seconds = min(max(POLL_INTERVAL_SECONDS, sleep_seconds * 2), POLL_MAX_IDLE_SECONDS)
        except Exception as exc:
            print(f"Daemon cycle error: {exc}")
            sleep_seconds = min(max(POLL_INTERVAL_SECONDS, sleep_seconds * 2), POLL_MAX_ERROR_SECONDS)
        print(f"Sleeping {sleep_seconds}s")
        await asyncio.sleep(sleep_seconds)


def login() -> None:
    if not _ensure_agent_browser_installed(auto_install=True):
        sys.exit(1)
    _ensure_profile_dir()
    cmd = ["agent-browser", "--profile", BROWSER_PROFILE, "--headed", "open", CHATGPT_ADMIN_URL]
    print(f"$ {' '.join(cmd)}")
    subprocess.run(cmd)
    print("Please log in to ChatGPT.")
    print("The script will automatically fetch your profile for the next run.")
    print("Execution screenshots and audit logs are stored under ~/.stitchflow/.")


def setup() -> None:
    """One-time setup: install dependencies then open login."""
    print("Running one-time setup...")
    _configure_agent_env_interactive()
    if not _ensure_agent_browser_installed(auto_install=True):
        sys.exit(1)
    _ensure_profile_dir()
    _start_daemon_background()

    cmd = ["agent-browser", "--profile", BROWSER_PROFILE, "--headed", "open", CHATGPT_ADMIN_URL]
    print(f"$ {' '.join(cmd)}")
    subprocess.run(cmd)
    print()
    print("Please log in to ChatGPT. We will store the profile on your local machine.")
    print("The daemon is running in the background and will pick up new scheduled tasks.")
    print("API key is saved in system keychain when available (Keychain/DPAPI).")


def status() -> None:
    _ensure_profile_dir()
    key_present = bool(API_KEY or _get_api_key_from_keyring(WORKSPACE_ID))
    print(f"Profile path:  {BROWSER_PROFILE}")
    print(f"Profile exists: {pathlib.Path(BROWSER_PROFILE).exists()}")
    print(f"API URL:       {API_URL}")
    print(f"Workspace ID:  {WORKSPACE_ID or '(not set)'}")
    print(f"API key set:   {key_present}")
    print(f"Keyring ready: {bool(keyring)}")
    print(f"Machine ID:    {MACHINE_ID}")


def _ensure_profile_dir() -> None:
    pathlib.Path(BROWSER_PROFILE).parent.mkdir(parents=True, exist_ok=True)


def _persist_agent_env(
    api_url: str,
    workspace_id: str,
    browser_profile: str,
    api_key: str = "",
) -> None:
    """Persist agent config to ~/.stitchflow/agent.env for future runs."""
    LOCAL_ENV_FILE.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        f'export STITCHFLOW_API_URL="{api_url}"',
        f'export STITCHFLOW_WORKSPACE_ID="{workspace_id}"',
        f'export AGENT_BROWSER_PROFILE="{browser_profile}"',
    ]
    if api_key:
        lines.insert(1, f'export STITCHFLOW_API_KEY="{api_key}"')
    LOCAL_ENV_FILE.write_text("\n".join(lines) + "\n")
    os.chmod(LOCAL_ENV_FILE, 0o600)


def _configure_agent_env_interactive() -> tuple[str, str, str, str]:
    """Collect setup values from user and persist them locally."""
    global API_URL, API_KEY, WORKSPACE_ID, BROWSER_PROFILE

    print("Configure Stitchflow agent:")
    api_url_input = input(f"  STITCHFLOW_API_URL [{API_URL}]: ").strip()
    api_url = api_url_input or API_URL

    workspace_default = WORKSPACE_ID or ""
    while True:
        prompt = (
            f"  STITCHFLOW_WORKSPACE_ID [{workspace_default}]: "
            if workspace_default
            else "  STITCHFLOW_WORKSPACE_ID [required]: "
        )
        workspace_id_input = input(prompt).strip()
        workspace_id = workspace_id_input or workspace_default
        if workspace_id:
            break
        print("  STITCHFLOW_WORKSPACE_ID is required.")

    key_prompt = "  STITCHFLOW_API_KEY [stored securely in Keychain/DPAPI; leave blank to keep current]: "
    if not keyring:
        key_prompt = "  STITCHFLOW_API_KEY [optional; keyring unavailable so this stays in env only]: "
    api_key_input = input(key_prompt).strip()
    api_key = api_key_input

    profile_default = BROWSER_PROFILE
    profile_input = input(f"  AGENT_BROWSER_PROFILE [{profile_default}]: ").strip()
    browser_profile = profile_input or profile_default

    API_URL = api_url
    WORKSPACE_ID = workspace_id
    BROWSER_PROFILE = browser_profile

    if api_key:
        if _set_api_key_in_keyring(WORKSPACE_ID, api_key):
            print("Saved API key to system keychain.")
    API_KEY = api_key or _get_api_key_from_keyring(WORKSPACE_ID)

    os.environ["STITCHFLOW_API_URL"] = API_URL
    os.environ["STITCHFLOW_API_KEY"] = API_KEY
    os.environ["STITCHFLOW_WORKSPACE_ID"] = WORKSPACE_ID
    os.environ["AGENT_BROWSER_PROFILE"] = BROWSER_PROFILE

    fallback_api_key = API_KEY if not keyring else ""
    _persist_agent_env(API_URL, WORKSPACE_ID, BROWSER_PROFILE, api_key=fallback_api_key)
    print(f"Saved setup config to: {LOCAL_ENV_FILE}")
    if keyring and not API_KEY:
        print("No API key set. If required, re-run setup to save one to keychain.")
    elif not keyring and API_KEY:
        print("WARNING: keyring not available; API key was saved in ~/.stitchflow/agent.env.")
    return API_URL, API_KEY, WORKSPACE_ID, BROWSER_PROFILE


def _start_daemon_background() -> bool:
    """Start daemon as a detached background process."""
    logs_dir = LOGS_DIR
    logs_dir.mkdir(parents=True, exist_ok=True)
    log_path = logs_dir / "agent-daemon.log"

    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    script_path = pathlib.Path(__file__).resolve()
    cmd = [sys.executable, "-u", str(script_path), "daemon"]

    try:
        with open(log_path, "a") as log_file:
            subprocess.Popen(
                cmd,
                stdout=log_file,
                stderr=log_file,
                env=env,
                start_new_session=True,
            )
        print(f"Daemon started in background. Logs: {log_path}")
        return True
    except Exception as exc:
        print(f"ERROR: Failed to start daemon in background: {exc}")
        return False


def main() -> None:
    try:
        sys.stdout.reconfigure(line_buffering=True)
        sys.stderr.reconfigure(line_buffering=True)
    except Exception:
        pass

    if len(sys.argv) < 2:
        print("Stitchflow Local Agent v0.1")
        print("Usage:")
        print("  stitchflow-agent setup")
        print("  stitchflow-agent login")
        print("  stitchflow-agent run")
        print("  stitchflow-agent daemon")
        print("  stitchflow-agent status")
        return

    command = sys.argv[1]
    if command == "setup":
        setup()
    elif command == "login":
        login()
    elif command == "run":
        asyncio.run(run_all_tasks())
    elif command == "daemon":
        try:
            asyncio.run(run_daemon())
        except KeyboardInterrupt:
            print("\nDaemon stopped.")
    elif command == "status":
        status()
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)


if __name__ == "__main__":
    main()
