# stitchflow-local-agent

Local Stitchflow daemon for browser automation (ChatGPT admin offboarding).

## Install (from GitHub)

```bash
pip install "git+https://github.com/Stitchflow-website-webapps/stitchflow-local-agent.git"
```

This installs the CLI entrypoint:

```bash
stitchflow-agent
```

## First-time setup

```bash
# one-time setup (auto-installs agent-browser + chromium, then opens login)
stitchflow-agent setup

# or direct login (also auto-installs if missing)
stitchflow-agent login

# run once
stitchflow-agent run

# or run as daemon
stitchflow-agent daemon
```

## Daemon setup

See `DAEMON_SETUP.md` for:
- macOS `launchd` install/uninstall
- Windows Task Scheduler install/uninstall
- lightweight polling/backoff tuning
- proof artifacts and audit logs
- API key security (Keychain/DPAPI via `keyring`)

## Security and proof of execution

- The agent stores API keys in the OS credential manager when available:
  - macOS: Keychain
  - Windows: Credential Manager/DPAPI-backed storage
- If `keyring` is unavailable, the API key falls back to `~/.stitchflow/agent.env`.
- For each task, the agent writes:
  - `before.png` and `after.png` screenshots
  - `audit.json` (detailed task event log)
- Artifact path: `~/.stitchflow/artifacts/`
- Rolling audit log: `~/.stitchflow/logs/audit.log`

## Notes on automatic dependency install

`stitchflow-agent setup`/`login` attempts to install `agent-browser` automatically using:

- `npm install -g agent-browser` (preferred)
- `brew install agent-browser` (macOS fallback)

Then it runs:

- `agent-browser install` (downloads Chromium runtime)
