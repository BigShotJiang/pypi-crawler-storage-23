"""
Safe file operations for beginners.

This module provides safe file handling utilities that prevent common
file-related errors and provide helpful error messages.

Security features:
- Path traversal protection
- Input validation
- Safe defaults
"""

import os
import json
from pathlib import Path
from typing import Union, Optional, List, Any

try:
    import yaml  # type: ignore
    _YAML_AVAILABLE = True
except ImportError:
    _YAML_AVAILABLE = False

try:
    import tomllib as _toml_reader  # Python 3.11+
    _TOML_AVAILABLE = True
except ImportError:
    try:
        import tomli as _toml_reader  # type: ignore
        _TOML_AVAILABLE = True
    except ImportError:
        _TOML_AVAILABLE = False
        _toml_reader = None

try:
    import tomli_w as _toml_writer  # type: ignore
    _TOML_WRITE_AVAILABLE = True
except ImportError:
    try:
        import toml as _toml_writer  # type: ignore
        _TOML_WRITE_AVAILABLE = True
    except ImportError:
        _TOML_WRITE_AVAILABLE = False
        _toml_writer = None


def _validate_safe_path(filepath: Union[str, Path], operation: str = "file operation") -> Path:
    """
    Validate that a file path is safe and doesn't contain path traversal attempts.
    
    Args:
        filepath: Path to validate
        operation: Name of operation for error messages
        
    Returns:
        Resolved Path object
        
    Raises:
        SafeUtilityError: If path is unsafe
    """
    from ..errors.exceptions import SafeUtilityError
    
    if filepath is None:
        raise SafeUtilityError(
            f"Путь не может быть None для {operation}", utility_name=operation
        )
    
    if not isinstance(filepath, (str, Path)):
        raise SafeUtilityError(
            f"Path must be string or Path object, got {type(filepath).__name__}",
            utility_name=operation
        )
    
    try:
        # Convert to Path and resolve
        path = Path(filepath).resolve()
        
        # Security: Check for path traversal attempts
        # Get the current working directory
        cwd = Path.cwd().resolve()
        
        # Check if resolved path tries to escape current directory
        # Allow absolute paths but warn about them
        try:
            # This will raise ValueError if path is not relative to cwd
            relative = path.relative_to(cwd)
            
            # Check for suspicious patterns in the relative path
            parts = relative.parts
            if '..' in parts:
                raise SafeUtilityError(
                    f"Path traversal detected: '..' in path {filepath}",
                    utility_name=operation
                )
        except ValueError:
            # Path is not relative to cwd (absolute path or outside cwd)
            # This is allowed but we validate it doesn't contain ..
            if '..' in str(filepath):
                raise SafeUtilityError(
                    f"Path traversal detected: '..' in path {filepath}",
                    utility_name=operation
                )
        
        return path
        
    except (OSError, ValueError) as e:
        raise SafeUtilityError(
            f"Invalid path for {operation}: {filepath}",
            utility_name=operation
        ) from e


def safe_read_file(filepath: Union[str, Path], encoding: str = 'utf-8', default: str = '') -> str:
    """
    Safely read a file with comprehensive error handling and security checks.
    
    Security features:
    - Path traversal protection
    - Input validation
    - Safe error handling
    
    Предотвращает ошибки FileNotFoundError, PermissionError и UnicodeDecodeError,
    возвращая значение по умолчанию вместо исключения.
    
    Args:
        filepath: Путь к файлу (строка или Path объект)
        encoding: Кодировка файла (по умолчанию utf-8)
        default: Значение по умолчанию при ошибке чтения
        
    Returns:
        Содержимое файла или значение по умолчанию
        
    Raises:
        SafeUtilityError: If filepath is None, invalid type, or contains path traversal
        
    Examples:
        >>> safe_read_file("example.txt")
        'содержимое файла'
        >>> safe_read_file("несуществующий.txt", default="файл не найден")
        'файл не найден'
    """
    from ..api_mode import is_strict_mode
    from ..errors.exceptions import SafeUtilityError
    
    # Validate path security
    try:
        filepath = _validate_safe_path(filepath, "safe_read_file")
    except SafeUtilityError:
        if is_strict_mode():
            raise
        return default
    
    if not isinstance(encoding, str):
        if is_strict_mode():
            raise SafeUtilityError(
                f"Кодировка должна быть строкой, получен {type(encoding).__name__}",
                utility_name="safe_read_file",
            )
        return default

    try:
        with open(filepath, 'r', encoding=encoding) as file:
            return file.read()
    except FileNotFoundError:
        if is_strict_mode():
            raise
        return default
    except PermissionError:
        if is_strict_mode():
            raise
        return default
    except UnicodeDecodeError:
        if is_strict_mode():
            raise
        return default
    except OSError:
        # Covers other OS-related errors
        if is_strict_mode():
            raise
        return default


def safe_write_file(filepath: Union[str, Path], content: str, encoding: str = 'utf-8', 
                   create_dirs: bool = True) -> bool:
    """
    Safely write content to a file with error handling and security checks.
    
    Security features:
    - Path traversal protection
    - Input validation
    - Safe directory creation
    
    Предотвращает ошибки при записи файла и может создавать директории.
    
    Args:
        filepath: Путь к файлу
        content: Содержимое для записи
        encoding: Кодировка файла
        create_dirs: Создавать ли директории если они не существуют
        
    Returns:
        True если запись успешна, False при ошибке
        
    Raises:
        SafeUtilityError: If arguments have invalid types or path is unsafe
        
    Examples:
        >>> safe_write_file("output.txt", "Hello World")
        True
        >>> safe_write_file("/invalid/path/file.txt", "content", create_dirs=False)
        False
    """
    from ..api_mode import is_strict_mode
    from ..errors.exceptions import SafeUtilityError
    
    # Validate path security
    filepath = _validate_safe_path(filepath, "safe_write_file")
    
    if not isinstance(content, str):
        raise SafeUtilityError(f"Содержимое должно быть строкой, получен {type(content).__name__}", 
                             utility_name="safe_write_file")
    
    if not isinstance(encoding, str):
        raise SafeUtilityError(f"Кодировка должна быть строкой, получен {type(encoding).__name__}", 
                             utility_name="safe_write_file")
    
    try:
        # Create directories if requested
        if create_dirs and filepath.parent != filepath:
            filepath.parent.mkdir(parents=True, exist_ok=True)
        
        with open(filepath, 'w', encoding=encoding) as file:
            file.write(content)
        return True
    except (PermissionError, OSError, UnicodeEncodeError):
        if is_strict_mode():
            raise
        return False


def safe_file_exists(filepath: Union[str, Path]) -> bool:
    """
    Safely check if a file exists.
    
    Предотвращает ошибки при проверке существования файла.
    
    Args:
        filepath: Путь к файлу
        
    Returns:
        True если файл существует, False иначе
        
    Raises:
        SafeUtilityError: If filepath is None or invalid type
        
    Examples:
        >>> safe_file_exists("example.txt")
        True
        >>> safe_file_exists("несуществующий.txt")
        False
    """
    from ..api_mode import is_strict_mode
    from ..errors.exceptions import SafeUtilityError
    
    if filepath is None:
        if not is_strict_mode():
            return False
        raise SafeUtilityError("Путь к файлу не может быть None", utility_name="safe_file_exists")
    
    if not isinstance(filepath, (str, Path)):
        if not is_strict_mode():
            return False
        raise SafeUtilityError(f"Путь к файлу должен быть строкой или Path объектом, получен {type(filepath).__name__}", 
                             utility_name="safe_file_exists")
    
    try:
        return Path(filepath).exists() and Path(filepath).is_file()
    except (OSError, ValueError):
        return False


def safe_get_file_size(filepath: Union[str, Path], default: int = 0) -> int:
    """
    Safely get file size in bytes.
    
    Предотвращает ошибки при получении размера файла.
    
    Args:
        filepath: Путь к файлу
        default: Значение по умолчанию при ошибке
        
    Returns:
        Размер файла в байтах или значение по умолчанию
        
    Raises:
        SafeUtilityError: If filepath is None or invalid type
        
    Examples:
        >>> safe_get_file_size("example.txt")
        1024
        >>> safe_get_file_size("несуществующий.txt")
        0
    """
    from ..errors.exceptions import SafeUtilityError

    if filepath is None:
        return default

    if not isinstance(filepath, (str, Path)):
        return default

    try:
        return Path(filepath).stat().st_size
    except (OSError, FileNotFoundError):
        return default


def safe_list_files(directory: Union[str, Path], pattern: str = "*", default: Optional[List[str]] = None) -> List[str]:
    """
    Safely list files in a directory.
    
    Предотвращает ошибки при чтении содержимого директории.
    
    Args:
        directory: Путь к директории
        pattern: Паттерн для фильтрации файлов (например, "*.txt")
        default: Значение по умолчанию при ошибке
        
    Returns:
        Список имен файлов или значение по умолчанию
        
    Raises:
        SafeUtilityError: If directory is None or invalid type
        
    Examples:
        >>> safe_list_files(".")
        ['file1.txt', 'file2.py']
        >>> safe_list_files("несуществующая_папка")
        []
    """
    from ..errors.exceptions import SafeUtilityError
    
    if default is None:
        default = []

    if directory is None:
        return default

    if not isinstance(directory, (str, Path)):
        return default

    if not isinstance(pattern, str):
        return default
    
    try:
        directory_path = Path(directory)
        if not directory_path.exists() or not directory_path.is_dir():
            return default
        
        files = [f.name for f in directory_path.glob(pattern) if f.is_file()]
        return sorted(files)
    except (OSError, ValueError):
        return default


def safe_read_json(
    filepath: Union[str, Path],
    default: Any = None,
    encoding: str = "utf-8"
) -> Any:
    """
    Safely read and parse a JSON file.
    
    Returns default if the file cannot be read or JSON is invalid.
    
    Args:
        filepath: Path to the JSON file
        default: Value to return on error (default: None)
        encoding: Text encoding (default: utf-8)
        
    Returns:
        Parsed JSON data or default on error
        
    Raises:
        SafeUtilityError: If filepath/encoding are invalid or unsafe
    """
    from ..errors.exceptions import SafeUtilityError
    
    try:
        filepath = _validate_safe_path(filepath, "safe_read_json")
    except SafeUtilityError:
        return default
    
    if not isinstance(encoding, str):
        return default

    try:
        with open(filepath, "r", encoding=encoding) as file:
            content = file.read()
    except (FileNotFoundError, PermissionError, OSError, UnicodeDecodeError):
        return default
    
    try:
        return json.loads(content)
    except (json.JSONDecodeError, TypeError, ValueError):
        return default


def safe_write_json(
    filepath: Union[str, Path],
    data: Any,
    encoding: str = "utf-8",
    indent: int = 2,
    ensure_ascii: bool = False,
    sort_keys: bool = False,
    create_dirs: bool = True
) -> bool:
    """
    Safely write data to a JSON file.
    
    Args:
        filepath: Path to the JSON file
        data: JSON-serializable data
        encoding: Text encoding (default: utf-8)
        indent: JSON indentation (default: 2)
        ensure_ascii: Escape non-ASCII characters if True
        sort_keys: Sort dict keys if True
        create_dirs: Create parent directories if needed
        
    Returns:
        True if write succeeded, False otherwise
        
    Raises:
        SafeUtilityError: If filepath/encoding are invalid or unsafe
    """
    from ..errors.exceptions import SafeUtilityError
    
    filepath = _validate_safe_path(filepath, "safe_write_json")
    
    if not isinstance(encoding, str):
        raise SafeUtilityError(
            f"Encoding must be a string, got {type(encoding).__name__}",
            utility_name="safe_write_json"
        )
    
    if not isinstance(indent, int) or indent < 0:
        raise SafeUtilityError(
            "indent must be a non-negative integer",
            utility_name="safe_write_json"
        )
    
    try:
        content = json.dumps(
            data,
            indent=indent,
            ensure_ascii=ensure_ascii,
            sort_keys=sort_keys
        )
    except (TypeError, ValueError):
        return False
    
    try:
        if create_dirs and filepath.parent != filepath:
            filepath.parent.mkdir(parents=True, exist_ok=True)
        with open(filepath, "w", encoding=encoding) as file:
            file.write(content)
        return True
    except (PermissionError, OSError, UnicodeEncodeError):
        return False


def safe_read_yaml(
    filepath: Union[str, Path],
    default: Any = None,
    encoding: str = "utf-8"
) -> Any:
    """
    Safely read and parse a YAML file.
    
    Returns default if YAML support is unavailable, the file cannot be read,
    or content is invalid.
    
    Args:
        filepath: Path to the YAML file
        default: Value to return on error (default: None)
        encoding: Text encoding (default: utf-8)
        
    Returns:
        Parsed YAML data or default on error
        
    Raises:
        SafeUtilityError: If filepath/encoding are invalid or unsafe
    """
    from ..errors.exceptions import SafeUtilityError
    
    try:
        filepath = _validate_safe_path(filepath, "safe_read_yaml")
    except SafeUtilityError:
        return default
    
    if not isinstance(encoding, str):
        return default

    if not _YAML_AVAILABLE:
        return default
    
    try:
        with open(filepath, "r", encoding=encoding) as file:
            content = file.read()
    except (FileNotFoundError, PermissionError, OSError, UnicodeDecodeError):
        return default
    
    try:
        data = yaml.safe_load(content)
        return default if data is None else data
    except Exception:
        return default


def safe_write_yaml(
    filepath: Union[str, Path],
    data: Any,
    encoding: str = "utf-8",
    create_dirs: bool = True
) -> bool:
    """
    Safely write data to a YAML file.
    
    Args:
        filepath: Path to the YAML file
        data: YAML-serializable data
        encoding: Text encoding (default: utf-8)
        create_dirs: Create parent directories if needed
        
    Returns:
        True if write succeeded, False otherwise
        
    Raises:
        SafeUtilityError: If filepath/encoding are invalid or unsafe
    """
    from ..errors.exceptions import SafeUtilityError
    
    filepath = _validate_safe_path(filepath, "safe_write_yaml")
    
    if not isinstance(encoding, str):
        raise SafeUtilityError(
            f"Encoding must be a string, got {type(encoding).__name__}",
            utility_name="safe_write_yaml"
        )
    
    if not _YAML_AVAILABLE:
        return False
    
    try:
        content = yaml.safe_dump(
            data,
            default_flow_style=False,
            allow_unicode=True,
            sort_keys=False
        )
    except Exception:
        return False
    
    try:
        if create_dirs and filepath.parent != filepath:
            filepath.parent.mkdir(parents=True, exist_ok=True)
        with open(filepath, "w", encoding=encoding) as file:
            file.write(content)
        return True
    except (PermissionError, OSError, UnicodeEncodeError):
        return False


def safe_read_toml(
    filepath: Union[str, Path],
    default: Any = None,
    encoding: str = "utf-8"
) -> Any:
    """
    Safely read and parse a TOML file.
    
    Returns default if TOML support is unavailable, the file cannot be read,
    or content is invalid.
    
    Args:
        filepath: Path to the TOML file
        default: Value to return on error (default: None)
        encoding: Text encoding (default: utf-8)
        
    Returns:
        Parsed TOML data or default on error
        
    Raises:
        SafeUtilityError: If filepath/encoding are invalid or unsafe
    """
    from ..errors.exceptions import SafeUtilityError
    
    try:
        filepath = _validate_safe_path(filepath, "safe_read_toml")
    except SafeUtilityError:
        return default
    
    if not isinstance(encoding, str):
        return default

    if not _TOML_AVAILABLE or _toml_reader is None:
        return default
    
    try:
        with open(filepath, "r", encoding=encoding) as file:
            content = file.read()
    except (FileNotFoundError, PermissionError, OSError, UnicodeDecodeError):
        return default
    
    try:
        return _toml_reader.loads(content)
    except Exception:
        return default


def safe_write_toml(
    filepath: Union[str, Path],
    data: Any,
    encoding: str = "utf-8",
    create_dirs: bool = True
) -> bool:
    """
    Safely write data to a TOML file.
    
    Returns False if TOML writer support is unavailable.
    
    Args:
        filepath: Path to the TOML file
        data: TOML-serializable data
        encoding: Text encoding (default: utf-8)
        create_dirs: Create parent directories if needed
        
    Returns:
        True if write succeeded, False otherwise
        
    Raises:
        SafeUtilityError: If filepath/encoding are invalid or unsafe
    """
    from ..errors.exceptions import SafeUtilityError
    
    filepath = _validate_safe_path(filepath, "safe_write_toml")
    
    if not isinstance(encoding, str):
        raise SafeUtilityError(
            f"Encoding must be a string, got {type(encoding).__name__}",
            utility_name="safe_write_toml"
        )
    
    if not _TOML_WRITE_AVAILABLE or _toml_writer is None:
        return False
    
    try:
        if hasattr(_toml_writer, "dumps"):
            content = _toml_writer.dumps(data)
        else:
            return False
    except Exception:
        return False
    
    try:
        if create_dirs and filepath.parent != filepath:
            filepath.parent.mkdir(parents=True, exist_ok=True)
        with open(filepath, "w", encoding=encoding) as file:
            file.write(content)
        return True
    except (PermissionError, OSError, UnicodeEncodeError):
        return False


def project_root(start_dir: Optional[Union[str, Path]] = None) -> str:
    """
    Detect and return the project root directory.
    
    Looks for markers: setup.py, pyproject.toml, .git, .gitignore
    
    Args:
        start_dir: Starting directory (default: current directory)
        
    Returns:
        Path to project root
        
    Raises:
        RuntimeError: If project root cannot be determined
        
    Examples:
        >>> root = project_root()
        >>> root = project_root("/path/to/subdir")
    """
    if start_dir is None:
        start_dir = Path.cwd()
    else:
        start_dir = Path(start_dir)
    
    # Markers that indicate project root
    markers = ['setup.py', 'pyproject.toml', '.git', '.gitignore']
    
    current = start_dir.resolve()
    
    # Walk up the directory tree
    while True:
        # Check if any marker exists in current directory
        for marker in markers:
            if (current / marker).exists():
                return str(current)
        
        # Move to parent directory
        parent = current.parent
        if parent == current:
            # Reached filesystem root without finding project root
            raise RuntimeError(f"Could not determine project root starting from {start_dir}")
        
        current = parent


def find_file(filename: str, start_dir: Optional[Union[str, Path]] = None) -> Optional[str]:
    """
    Search for a file in the project directory tree.
    
    Args:
        filename: Name of file to find
        start_dir: Starting directory (default: project root)
        
    Returns:
        Full path to file if found, None otherwise
        
    Examples:
        >>> path = find_file("setup.py")
        >>> path = find_file("config.json", "/path/to/start")
    """
    if start_dir is None:
        try:
            start_dir = project_root()
        except RuntimeError:
            start_dir = Path.cwd()
    else:
        start_dir = Path(start_dir)
    
    start_dir = Path(start_dir).resolve()
    
    # Search for the file
    for path in start_dir.rglob(filename):
        if path.is_file():
            return str(path)
    
    return None


def safe_open(filepath: Union[str, Path], mode: str = 'r', encoding: str = 'utf-8'):
    """
    Safely open a file with helpful error messages.
    
    Args:
        filepath: Path to file (relative or absolute)
        mode: File open mode ('r', 'w', 'a', etc.)
        encoding: Text encoding (default: utf-8)
        
    Returns:
        File object
        
    Raises:
        FileNotFoundError: With helpful suggestions if file not found
        PermissionError: With helpful suggestions if permission denied
        
    Examples:
        >>> with safe_open("data.txt") as f:
        ...     content = f.read()
    """
    from ..errors.exceptions import SafeUtilityError
    
    filepath = Path(filepath)
    
    # If relative path, try to resolve relative to project root
    if not filepath.is_absolute():
        try:
            root = project_root()
            filepath = Path(root) / filepath
        except RuntimeError:
            # If project root not found, use as-is
            pass
    
    try:
        return open(filepath, mode, encoding=encoding)
    except FileNotFoundError as e:
        raise FileNotFoundError(f"File not found: {filepath}") from e
    except PermissionError as e:
        raise PermissionError(f"Permission denied: {filepath}") from e



# ============================================================================
# New file utility functions for fishertools-file-utils spec
# ============================================================================

import hashlib


def ensure_dir(path: Union[str, Path]) -> Path:
    """
    Создаёт директорию рекурсивно, как os.makedirs с exist_ok=True.
    
    Args:
        path: Путь к директории (str или Path).
    
    Returns:
        Path: Объект pathlib.Path созданной директории.
    
    Raises:
        OSError: Если директория не может быть создана.
        PermissionError: Если нет прав доступа.
        
    Examples:
        >>> ensure_dir("/path/to/directory")
        PosixPath('/path/to/directory')
        >>> ensure_dir("./nested/dir/structure")
        PosixPath('./nested/dir/structure')
    """
    try:
        raw_path = os.fspath(path)
        if any(0xD800 <= ord(ch) <= 0xDFFF for ch in str(raw_path)):
            raise OSError(f"Invalid Unicode path: {path!r}")
        path_obj = Path(path)
        if not str(path_obj):
            raise OSError("Directory path cannot be empty")
        path_obj.mkdir(parents=True, exist_ok=True)
        return path_obj
    except (TypeError, ValueError) as e:
        raise OSError(f"Invalid directory path: {path!r}") from e
    except PermissionError as e:
        raise PermissionError(f"Permission denied creating directory: {path}") from e
    except UnicodeError as e:
        raise OSError(f"Failed to create directory: {path}") from e
    except OSError as e:
        raise OSError(f"Failed to create directory: {path}") from e


def get_file_hash(
    file_path: Union[str, Path],
    algorithm: str = 'sha256'
) -> str:
    """
    Вычисляет хэш файла потоковым методом (8KB чанки).
    
    Args:
        file_path: Путь к файлу (str или Path).
        algorithm: Алгоритм хэширования (md5, sha1, sha256, sha512, blake2b).
    
    Returns:
        str: Хэш файла в hex формате.
    
    Raises:
        FileNotFoundError: Если файл не существует.
        ValueError: Если алгоритм не поддерживается.
        PermissionError: Если нет прав доступа на чтение.
        
    Examples:
        >>> get_file_hash("data.txt")
        'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
        >>> get_file_hash("data.txt", algorithm='md5')
        'd41d8cd98f00b204e9800998ecf8427e'
    """
    # Supported algorithms
    supported_algorithms = {'md5', 'sha1', 'sha256', 'sha512', 'blake2b'}
    
    # Validate algorithm
    if algorithm not in supported_algorithms:
        raise ValueError(
            f"Unsupported algorithm: {algorithm}. "
            f"Supported algorithms: {', '.join(sorted(supported_algorithms))}"
        )
    
    # Convert to Path object
    file_path_obj = Path(file_path)
    
    # Check if file exists
    if not file_path_obj.exists():
        raise FileNotFoundError(f"File not found: {file_path}")
    
    # Create hash object
    if algorithm == 'blake2b':
        hash_obj = hashlib.blake2b()
    else:
        hash_obj = hashlib.new(algorithm)
    
    # Read file in chunks and update hash
    chunk_size = 8192  # 8KB chunks
    try:
        with open(file_path_obj, 'rb') as f:
            while True:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                hash_obj.update(chunk)
    except PermissionError as e:
        raise PermissionError(f"Permission denied reading file: {file_path}") from e
    except OSError as e:
        raise OSError(f"Error reading file: {file_path}") from e
    
    return hash_obj.hexdigest()


def read_last_lines(
    file_path: Union[str, Path],
    n: int = 10
) -> List[str]:
    """
    Читает последние N строк файла буферным алгоритмом от конца.
    
    Args:
        file_path: Путь к файлу (str или Path).
        n: Количество строк для чтения (по умолчанию 10).
    
    Returns:
        List[str]: Список последних N строк без символов новой строки.
    
    Raises:
        FileNotFoundError: Если файл не существует.
        PermissionError: Если нет прав доступа на чтение.
        
    Examples:
        >>> read_last_lines("log.txt", n=5)
        ['line 1', 'line 2', 'line 3', 'line 4', 'line 5']
        >>> read_last_lines("data.txt")
        ['last line']
    """
    # Convert to Path object
    try:
        raw_path = os.fspath(file_path)
        if any(0xD800 <= ord(ch) <= 0xDFFF for ch in str(raw_path)):
            raise OSError(f"Invalid Unicode path: {file_path!r}")
        file_path_obj = Path(file_path)
    except (TypeError, ValueError, UnicodeError) as e:
        raise OSError(f"Invalid file path: {file_path!r}") from e
    
    # Check if file exists
    if not file_path_obj.exists():
        raise FileNotFoundError(f"File not found: {file_path}")
    
    try:
        with open(file_path_obj, 'r', encoding='utf-8', errors='replace') as f:
            all_lines = [line.rstrip('\r\n') for line in f]
        if n <= 0:
            return []
        return all_lines[-n:]

    except PermissionError as e:
        raise PermissionError(f"Permission denied reading file: {file_path}") from e
    except OSError as e:
        raise OSError(f"Error reading file: {file_path}") from e


__all__ = [
    "safe_read_file",
    "safe_write_file",
    "safe_file_exists",
    "safe_get_file_size",
    "safe_list_files",
    "safe_read_json",
    "safe_write_json",
    "safe_read_yaml",
    "safe_write_yaml",
    "safe_read_toml",
    "safe_write_toml",
    "project_root",
    "find_file",
    "safe_open",
    "ensure_dir",
    "get_file_hash",
    "read_last_lines",
]
