"""Hyperwave Community: Open-source photonics simulation toolkit.

This package provides tools for designing and simulating photonic structures with
GPU-accelerated FDTD via API.

Modules:
    structure: Structure creation and density filtering
    absorption: Adiabatic absorbing boundaries
    monitors: Field monitoring and power analysis
    sources: Mode and Gaussian source generation (local + API)
    simulate: FDTD simulation via API and result visualization
    metasurface: Metasurface pattern utilities
    data_io: GDS file import/export and visualization
    api_client: API configuration and authentication

Quick Start:
    >>> import hyperwave_community as hwc
    >>> import jax.numpy as jnp
    >>>
    >>> # Configure API
    >>> hwc.configure_api(api_key='your-key-here')
    >>>
    >>> # Create structure
    >>> theta = jnp.ones((500, 1000))
    >>> density = hwc.density(theta, radius=8)
    >>> layer = hwc.Layer(density, permittivity_values=(1.0, 11.56), layer_thickness=20)
    >>> structure = hwc.create_structure(layers=[layer])
    >>>
    >>> # Create source
    >>> freq_band = (2*jnp.pi/1.6, 2*jnp.pi/1.5, 2)
    >>> source, offset, mode_info = hwc.create_mode_source(
    ...     structure, freq_band, mode_num=0, propagation_axis='x', source_position=80
    ... )
    >>>
    >>> # Setup monitors
    >>> monitors = hwc.MonitorSet()
    >>> monitors.add_monitors_at_position(structure, axis='x', position=100, label='Input')
    >>>
    >>> # Run simulation
    >>> results = hwc.simulate(
    ...     structure=structure,
    ...     source_field=source,
    ...     source_offset=offset,
    ...     freq_band=freq_band,
    ...     monitors=monitors
    ... )
"""

__version__ = "0.1.0"

# Import core structure functions
from .structure import (
    density,
    create_structure,
    view_structure,
    Layer,
    Structure,
    recipe_from_params,
)

# Import absorption functions
from .absorption import (
    absorber_params,
    create_absorption_mask,
    get_optimized_absorber_params,
)

# Import monitor functions
from .monitors import (
    Monitor,
    MonitorSet,
    S_from_slice,
    power_from_a_box,
    get_field_slice,
    get_power_through_plane,
    get_field_intensity,
    get_electric_field_intensity,
    get_magnetic_field_intensity,
    view_monitors,
)

# Import source functions
from .sources import (
    create_gaussian_source,
    generate_gaussian_source,
)
# create_mode_source is in simulate.py (uses mode solver)
from .simulate import create_mode_source

# Import API client functions (SDK-style interface)
from .api_client import (
    # Configuration
    configure_api,
    get_account_info,
    estimate_cost,
    # CPU Steps (free)
    build_recipe,
    build_monitors,
    solve_mode_source,
    compute_freq_band,
    get_default_absorber_params,
    # GPU Step (uses credits)
    run_simulation,
    # Analysis functions (local, free)
    analyze_transmission,
    get_field_intensity_2d,
    compute_poynting_vector,
    compute_monitor_power,
    # Visualization functions
    visualize_structure,
    visualize_mode_source,
    # Utility functions
    encode_array,
    decode_array,
    # Convergence configuration
    ConvergenceConfig,
    CONVERGENCE_PRESETS,
    # Inverse design
    compute_adjoint_gradient,
    run_optimization,
    # Component preview functions
    list_components,
    get_component_params,
    preview_component,
    # Granular workflow functions
    load_component,
    build_recipe_from_theta,
    build_monitors_local,
)

# Import metasurface utilities
from .metasurface import (
    create_circle_array,
    create_circle_grid,
)

# Import data I/O functions
from .data_io import (
    generate_gds_from_density,
    view_gds,
    gds_to_theta,
    component_to_theta,
)


# Import simulation utilities (local versions, for backwards compatibility)
# Note: We import these with explicit names to avoid shadowing the api_client.simulate function
from .simulate import simulate as simulate_local
from .simulate import quick_view_monitors

# Re-import simulate from api_client to ensure it's not shadowed by the module import above
from .api_client import simulate, mode_convert  # noqa: F401

# Define public API
__all__ = [
    # Version
    "__version__",

    # Structure
    "density",
    "create_structure",
    "view_structure",
    "Layer",
    "Structure",
    "recipe_from_params",

    # Absorption
    "absorber_params",
    "create_absorption_mask",
    "get_optimized_absorber_params",

    # Monitors
    "Monitor",
    "MonitorSet",
    "S_from_slice",
    "power_from_a_box",
    "get_field_slice",
    "get_power_through_plane",
    "get_field_intensity",
    "get_electric_field_intensity",
    "get_magnetic_field_intensity",
    "view_monitors",

    # Sources
    "create_mode_source",
    "create_gaussian_source",
    "generate_gaussian_source",

    # Metasurface
    "create_circle_array",
    "create_circle_grid",

    # Data I/O
    "generate_gds_from_density",
    "view_gds",
    "gds_to_theta",
    "component_to_theta",

    # API - Configuration
    "configure_api",
    "get_account_info",
    "estimate_cost",
    "compute_adjoint_gradient",

    # API - CPU Steps (free)
    "build_recipe",
    "build_monitors",
    "solve_mode_source",
    "compute_freq_band",
    "get_default_absorber_params",

    # API - GPU Step (uses credits)
    "run_simulation",
    "run_optimization",

    # API - Analysis (local, free)
    "analyze_transmission",

    # Analysis functions (local)
    "compute_poynting_vector",
    "compute_monitor_power",
    "get_field_intensity_2d",

    # Visualization functions
    "visualize_structure",
    "visualize_mode_source",

    # Utility functions
    "encode_array",
    "decode_array",

    # Convergence configuration
    "ConvergenceConfig",
    "CONVERGENCE_PRESETS",

    # Component preview functions
    "list_components",
    "get_component_params",
    "preview_component",

    # Granular workflow functions
    "load_component",
    "build_recipe_from_theta",
    "build_monitors_local",

    # Mode conversion (cloud GPU)
    "mode_convert",

    # Simulation utilities
    "simulate_local",
    "quick_view_monitors",
]
