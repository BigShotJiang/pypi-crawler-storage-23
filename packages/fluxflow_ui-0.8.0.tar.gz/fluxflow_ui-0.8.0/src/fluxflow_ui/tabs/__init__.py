"""UI tabs."""
