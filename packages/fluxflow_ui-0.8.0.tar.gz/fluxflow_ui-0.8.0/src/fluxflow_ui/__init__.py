"""FluxFlow UI: Web interface for FluxFlow training and generation."""

__version__ = "0.4.0"

# UI modules are available for import
# from fluxflow_ui.app_flask import create_app, main
