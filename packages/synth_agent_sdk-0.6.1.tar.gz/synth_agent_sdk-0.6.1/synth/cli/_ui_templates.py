"""UI template strings for ``synth create ui``.

Separated from create_cmd.py for maintainability. These are the
file contents generated when a user runs ``synth create ui <name>``.
"""

from __future__ import annotations


# ------------------------------------------------------------------
# server.py — FastAPI bridge with enhanced API
# ------------------------------------------------------------------

UI_SERVER = '''"""Local testing UI server — bridges the browser to your Synth agent.

Run:
    python server.py

Then open http://localhost:8420 in your browser.
"""

from __future__ import annotations

import importlib.util
import json
import sys
import time
from pathlib import Path

try:
    from fastapi import FastAPI, Request
    from fastapi.responses import HTMLResponse, JSONResponse
    from fastapi.staticfiles import StaticFiles
    import uvicorn
except ImportError:
    print("Missing dependencies. Install them with:")
    print("  pip install uvicorn fastapi")
    sys.exit(1)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
AGENT_FILE = "../agent.py"


# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------
app = FastAPI(title="Synth Agent UI")
app.mount(
    "/static",
    StaticFiles(directory=Path(__file__).parent / "static"),
    name="static",
)

_agent = None
_conversations: dict[str, list[dict]] = {"default": []}
_current_conv = "default"


def _load_agent():
    """Load (or reload) the agent from AGENT_FILE."""
    global _agent
    spec = importlib.util.spec_from_file_location("_agent_mod", AGENT_FILE)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load agent from \\'{AGENT_FILE}\\'")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    if not hasattr(mod, "agent"):
        raise RuntimeError(f"\\'{AGENT_FILE}\\' must define an \\'agent\\' variable.")
    _agent = mod.agent
    return _agent


@app.on_event("startup")
async def startup():
    """Load the agent on server start."""
    try:
        _load_agent()
        print(f"Agent loaded from {AGENT_FILE}")
    except Exception as exc:
        print(f"Warning: could not load agent: {exc}")


@app.get("/", response_class=HTMLResponse)
async def index():
    """Serve the main UI."""
    html = (Path(__file__).parent / "static" / "index.html").read_text()
    return HTMLResponse(content=html)


@app.post("/api/chat")
async def chat(request: Request):
    """Send a prompt to the agent and return the result."""
    global _agent
    if _agent is None:
        return JSONResponse(
            {"error": "No agent loaded. Check AGENT_FILE in server.py."},
            status_code=503,
        )

    body = await request.json()
    prompt = body.get("prompt", "")
    conv_id = body.get("conversation", "default")
    if not prompt.strip():
        return JSONResponse({"error": "Empty prompt."}, status_code=400)

    start = time.perf_counter()
    try:
        result = _agent.run(prompt)
        elapsed = (time.perf_counter() - start) * 1000

        msg = {
            "text": result.text,
            "tokens": {
                "input": result.tokens.input_tokens,
                "output": result.tokens.output_tokens,
                "total": result.tokens.total_tokens,
            },
            "cost": result.cost,
            "latency_ms": round(elapsed, 1),
            "tool_calls": [
                {
                    "name": tc.name,
                    "args": tc.args,
                    "result": str(tc.result),
                    "latency_ms": round(tc.latency_ms, 1),
                }
                for tc in result.tool_calls
            ],
            "trace": _serialize_trace(result),
        }

        if conv_id not in _conversations:
            _conversations[conv_id] = []
        _conversations[conv_id].append({"role": "user", "content": prompt})
        _conversations[conv_id].append({"role": "agent", "data": msg})

        return JSONResponse(msg)
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=500)


@app.post("/api/reload")
async def reload_agent():
    """Hot-reload the agent from disk."""
    try:
        _load_agent()
        return JSONResponse({"status": "reloaded"})
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=500)


@app.get("/api/tools")
async def list_tools():
    """List all registered tools with schemas."""
    if _agent is None:
        return JSONResponse({"tools": []})
    tools = getattr(_agent, "_registered_tools", {})
    tool_list = []
    for name, fn in tools.items():
        schema = getattr(fn, "_tool_schema", {})
        tool_list.append({
            "name": name,
            "description": schema.get("description", ""),
            "parameters": schema.get("parameters", {}),
        })
    return JSONResponse({"tools": tool_list})


@app.post("/api/tools/test")
async def test_tool(request: Request):
    """Test a single tool with given arguments."""
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)

    body = await request.json()
    tool_name = body.get("name", "")
    tool_args = body.get("args", {})

    tools = getattr(_agent, "_registered_tools", {})
    if tool_name not in tools:
        return JSONResponse(
            {"error": f"Tool \\'{tool_name}\\' not found."},
            status_code=404,
        )

    start = time.perf_counter()
    try:
        import asyncio
        fn = tools[tool_name]
        if asyncio.iscoroutinefunction(fn):
            result = await fn(**tool_args)
        else:
            result = fn(**tool_args)
        elapsed = (time.perf_counter() - start) * 1000
        return JSONResponse({
            "result": str(result),
            "latency_ms": round(elapsed, 1),
        })
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=500)


@app.get("/api/conversations")
async def list_conversations():
    """List all conversation IDs."""
    return JSONResponse({
        "conversations": list(_conversations.keys()),
        "current": _current_conv,
    })


@app.get("/api/conversations/{conv_id}")
async def get_conversation(conv_id: str):
    """Get messages for a conversation."""
    msgs = _conversations.get(conv_id, [])
    return JSONResponse({"messages": msgs})


@app.post("/api/conversations")
async def create_conversation(request: Request):
    """Create a new conversation."""
    global _current_conv
    body = await request.json()
    conv_id = body.get("id", f"chat-{len(_conversations) + 1}")
    _conversations[conv_id] = []
    _current_conv = conv_id
    return JSONResponse({"id": conv_id})


@app.get("/api/info")
async def agent_info():
    """Return agent metadata."""
    if _agent is None:
        return JSONResponse({"model": "not loaded", "tools": 0})
    tools = getattr(_agent, "_registered_tools", {})
    return JSONResponse({
        "model": getattr(_agent, "model", "unknown"),
        "tools": len(tools),
        "instructions": getattr(_agent, "instructions", "")[:200],
    })


def _serialize_trace(result):
    """Extract trace spans for the UI timeline."""
    trace = getattr(result, "trace", None)
    if trace is None:
        return []
    spans = getattr(trace, "spans", [])
    return [
        {
            "name": getattr(s, "name", "?"),
            "type": getattr(s, "span_type", "?"),
            "duration_ms": round(getattr(s, "duration_ms", 0.0), 1),
            "metadata": {
                k: v for k, v in getattr(s, "metadata", {}).items()
            },
        }
        for s in spans
    ]


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8420)
'''


# ------------------------------------------------------------------
# index.html — Dashboard layout
# ------------------------------------------------------------------

UI_HTML = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Synth Agent UI</title>
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
    <div class="scanlines"></div>
    <div class="app">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">SYNTH<span class="logo-dim">SDK</span></div>
                <button class="btn-icon" id="btn-new-chat" title="New conversation">+</button>
            </div>
            <div class="sidebar-section">
                <div class="section-label">CONVERSATIONS</div>
                <div class="conv-list" id="conv-list"></div>
            </div>
            <div class="sidebar-section">
                <div class="section-label">AGENT</div>
                <div class="agent-info" id="agent-info">
                    <div class="info-row"><span class="info-label">Model</span><span class="info-value" id="info-model">—</span></div>
                    <div class="info-row"><span class="info-label">Tools</span><span class="info-value" id="info-tools">—</span></div>
                </div>
            </div>
            <div class="sidebar-footer">
                <button class="btn btn-ghost btn-sm" id="btn-reload">&#x21bb; Reload</button>
                <button class="btn btn-ghost btn-sm" id="btn-toggle-tools">&#x2692; Tools</button>
            </div>
        </aside>

        <!-- Main content -->
        <div class="main">
            <!-- Top bar -->
            <header class="topbar">
                <div class="topbar-left">
                    <button class="btn-icon" id="btn-sidebar-toggle" title="Toggle sidebar">&#9776;</button>
                    <span class="topbar-title" id="topbar-title">default</span>
                    <div class="status-badge" id="status">
                        <span class="status-dot"></span>
                        <span class="status-text">CONNECTED</span>
                    </div>
                </div>
                <div class="topbar-right">
                    <button class="btn btn-ghost btn-sm" id="btn-toggle-trace">&#x23F1; Trace</button>
                    <button class="btn btn-ghost btn-sm" id="btn-clear">&#x2715; Clear</button>
                </div>
            </header>

            <!-- Content area with optional right panel -->
            <div class="content-area">
                <!-- Chat -->
                <main class="chat-area" id="chat-area">
                    <div class="welcome" id="welcome">
                        <pre class="welcome-art">
 ███████╗██╗   ██╗███╗   ██╗████████╗██╗  ██╗
 ██╔════╝╚██╗ ██╔╝████╗  ██║╚══██╔══╝██║  ██║
 ███████╗ ╚████╔╝ ██╔██╗ ██║   ██║   ███████║
 ╚════██║  ╚██╔╝  ██║╚██╗██║   ██║   ██╔══██║
 ███████║   ██║   ██║ ╚████║   ██║   ██║  ██║
 ╚══════╝   ╚═╝   ╚═╝  ╚═══╝   ╚═╝   ╚═╝  ╚═╝
                        </pre>
                        <p class="welcome-text">Agent testing dashboard ready.</p>
                        <p class="welcome-hint">Type a message below to talk to your agent.</p>
                    </div>
                </main>

                <!-- Trace panel (collapsible) -->
                <aside class="trace-panel hidden" id="trace-panel">
                    <div class="panel-header">
                        <span class="panel-title">TRACE TIMELINE</span>
                        <button class="btn-icon btn-close" id="btn-close-trace">&times;</button>
                    </div>
                    <div class="trace-content" id="trace-content">
                        <p class="empty-state">Run a prompt to see the trace.</p>
                    </div>
                    <div class="trace-summary" id="trace-summary"></div>
                </aside>
            </div>

            <!-- Input area -->
            <footer class="input-area">
                <form id="chat-form" autocomplete="off">
                    <div class="input-row">
                        <span class="prompt-caret">&#x25B6;</span>
                        <textarea
                            id="prompt-input"
                            placeholder="Enter a prompt... (Shift+Enter for new line)"
                            rows="1"
                            autofocus
                            aria-label="Chat prompt"
                        ></textarea>
                        <button type="submit" class="btn btn-send" id="btn-send">SEND</button>
                    </div>
                </form>
                <div class="metrics-bar" id="metrics-bar"></div>
            </footer>
        </div>

        <!-- Tool playground drawer -->
        <div class="tool-drawer hidden" id="tool-drawer">
            <div class="panel-header">
                <span class="panel-title">TOOL PLAYGROUND</span>
                <button class="btn-icon btn-close" id="btn-close-tools">&times;</button>
            </div>
            <div class="tool-drawer-content">
                <div class="tool-select-row">
                    <select id="tool-select" class="tool-select" aria-label="Select tool">
                        <option value="">Select a tool...</option>
                    </select>
                    <button class="btn btn-send btn-sm" id="btn-run-tool">RUN</button>
                </div>
                <div class="tool-description" id="tool-description"></div>
                <div class="tool-args-editor" id="tool-args-editor"></div>
                <div class="tool-output" id="tool-output"></div>
            </div>
        </div>
    </div>
    <script src="/static/app.js"></script>
</body>
</html>
'''


# ------------------------------------------------------------------
# style.css — Dashboard theme
# ------------------------------------------------------------------

UI_CSS = '''/* Synth Agent UI — Developer Dashboard */

:root {
    --bg: #0a0e14;
    --bg-surface: #0d1117;
    --bg-elevated: #131920;
    --bg-input: #0d1117;
    --bg-sidebar: #080b10;
    --border: #1e2a35;
    --border-focus: #39ff14;
    --text: #c9d1d9;
    --text-dim: #6a7a8a;
    --text-bright: #e6edf3;
    --green: #39ff14;
    --green-dim: #1a7a0a;
    --green-glow: rgba(57, 255, 20, 0.15);
    --amber: #ffb627;
    --red: #ff4444;
    --cyan: #00e5ff;
    --purple: #b388ff;
    --font-mono: "SF Mono", "Cascadia Code", "Fira Code", "JetBrains Mono", Consolas, monospace;
    --font-sans: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    --radius: 6px;
    --radius-lg: 10px;
    --transition: 150ms ease;
    --sidebar-w: 260px;
    --trace-w: 320px;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

html, body {
    height: 100%; background: var(--bg); color: var(--text);
    font-family: var(--font-mono); font-size: 13px; line-height: 1.6;
    overflow: hidden; -webkit-font-smoothing: antialiased;
}

.scanlines {
    pointer-events: none; position: fixed; inset: 0; z-index: 9999;
    background: repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.03) 2px, rgba(0,0,0,0.03) 4px);
}

/* Layout */
.app { display: flex; height: 100vh; position: relative; }
.main { display: flex; flex-direction: column; flex: 1; min-width: 0; }
.content-area { display: flex; flex: 1; overflow: hidden; }

/* Sidebar */
.sidebar {
    width: var(--sidebar-w); background: var(--bg-sidebar); border-right: 1px solid var(--border);
    display: flex; flex-direction: column; flex-shrink: 0; transition: margin-left var(--transition);
}
.sidebar.collapsed { margin-left: calc(var(--sidebar-w) * -1); }
.sidebar-header { display: flex; align-items: center; justify-content: space-between; padding: 16px; border-bottom: 1px solid var(--border); }
.logo { font-size: 16px; font-weight: 700; color: var(--green); letter-spacing: 2px; text-shadow: 0 0 10px var(--green-glow); }
.logo-dim { color: var(--text-dim); font-weight: 400; }
.sidebar-section { padding: 12px 16px; }
.section-label { font-size: 10px; letter-spacing: 1.5px; color: var(--text-dim); margin-bottom: 8px; font-weight: 600; }
.sidebar-footer { margin-top: auto; padding: 12px 16px; border-top: 1px solid var(--border); display: flex; gap: 8px; }

/* Conversation list */
.conv-list { display: flex; flex-direction: column; gap: 2px; }
.conv-item {
    padding: 8px 12px; border-radius: var(--radius); cursor: pointer;
    font-size: 12px; color: var(--text-dim); transition: all var(--transition);
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.conv-item:hover { background: var(--bg-elevated); color: var(--text); }
.conv-item.active { background: var(--bg-elevated); color: var(--green); border-left: 2px solid var(--green); }

/* Agent info */
.agent-info { display: flex; flex-direction: column; gap: 6px; }
.info-row { display: flex; justify-content: space-between; font-size: 11px; }
.info-label { color: var(--text-dim); }
.info-value { color: var(--text); }

/* Top bar */
.topbar {
    display: flex; align-items: center; justify-content: space-between;
    padding: 10px 16px; border-bottom: 1px solid var(--border); flex-shrink: 0;
}
.topbar-left { display: flex; align-items: center; gap: 12px; }
.topbar-right { display: flex; gap: 8px; }
.topbar-title { font-size: 13px; color: var(--text); font-weight: 600; }

/* Status badge */
.status-badge {
    display: flex; align-items: center; gap: 6px; padding: 3px 8px;
    border: 1px solid var(--green-dim); border-radius: 999px; font-size: 9px;
    letter-spacing: 1px; color: var(--green);
}
.status-dot {
    width: 5px; height: 5px; border-radius: 50%; background: var(--green);
    box-shadow: 0 0 6px var(--green); animation: pulse 2s ease-in-out infinite;
}
@keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }

/* Buttons */
.btn {
    font-family: var(--font-mono); font-size: 11px; letter-spacing: 1px;
    border: none; border-radius: var(--radius); cursor: pointer;
    transition: all var(--transition); padding: 6px 14px;
}
.btn-sm { padding: 4px 10px; font-size: 10px; }
.btn-ghost { background: transparent; color: var(--text-dim); border: 1px solid var(--border); }
.btn-ghost:hover { color: var(--text-bright); border-color: var(--text-dim); background: var(--bg-elevated); }
.btn-send { background: var(--green-dim); color: var(--green); border: 1px solid var(--green); font-weight: 600; min-width: 70px; }
.btn-send:hover { background: var(--green); color: var(--bg); box-shadow: 0 0 16px var(--green-glow); }
.btn-send:disabled { opacity: 0.4; cursor: not-allowed; }
.btn-icon {
    background: transparent; border: 1px solid var(--border); color: var(--text-dim);
    width: 30px; height: 30px; border-radius: var(--radius); cursor: pointer;
    display: flex; align-items: center; justify-content: center; font-size: 16px;
    transition: all var(--transition);
}
.btn-icon:hover { color: var(--text-bright); border-color: var(--text-dim); }
.btn-close { border: none; font-size: 18px; }

/* Chat area */
.chat-area { flex: 1; overflow-y: auto; padding: 20px; scroll-behavior: smooth; }
.chat-area::-webkit-scrollbar { width: 4px; }
.chat-area::-webkit-scrollbar-track { background: transparent; }
.chat-area::-webkit-scrollbar-thumb { background: var(--border); border-radius: 2px; }

/* Welcome */
.welcome { display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; text-align: center; opacity: 0.5; }
.welcome-art { color: var(--green); font-size: 10px; line-height: 1.3; margin-bottom: 16px; text-shadow: 0 0 8px var(--green-glow); }
.welcome-text { color: var(--text); font-size: 14px; margin-bottom: 4px; }
.welcome-hint { color: var(--text-dim); font-size: 12px; }

/* Messages */
.message { margin-bottom: 16px; animation: fadeIn 200ms ease; }
@keyframes fadeIn { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: translateY(0); } }
.msg-label { font-size: 10px; letter-spacing: 1.5px; text-transform: uppercase; margin-bottom: 4px; font-weight: 600; }
.msg-label-user { color: var(--cyan); }
.msg-label-agent { color: var(--green); }
.msg-label-error { color: var(--red); }
.msg-body {
    padding: 12px 16px; border-radius: var(--radius); border: 1px solid var(--border);
    white-space: pre-wrap; word-break: break-word; font-family: var(--font-sans);
    font-size: 14px; line-height: 1.7;
}
.msg-user .msg-body { background: var(--bg-elevated); }
.msg-agent .msg-body { background: var(--bg-surface); border-left: 3px solid var(--green-dim); }
.msg-error .msg-body { background: rgba(255,68,68,0.08); border-color: var(--red); color: var(--red); }

/* Tool calls inline */
.tool-calls { margin-top: 10px; border-top: 1px dashed var(--border); padding-top: 10px; }
.tool-call {
    font-family: var(--font-mono); font-size: 12px; padding: 8px 12px;
    background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius); margin-bottom: 6px;
}
.tool-name { color: var(--amber); font-weight: 600; }
.tool-args { color: var(--text-dim); margin-left: 8px; }
.tool-result { color: var(--text); margin-top: 4px; }
.tool-latency { color: var(--text-dim); font-size: 10px; float: right; }

/* Loading */
.loading { display: inline-flex; gap: 4px; padding: 12px 16px; }
.loading-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--green); animation: bounce 1.2s ease-in-out infinite; }
.loading-dot:nth-child(2) { animation-delay: 0.15s; }
.loading-dot:nth-child(3) { animation-delay: 0.3s; }
@keyframes bounce { 0%, 80%, 100% { transform: scale(0.6); opacity: 0.3; } 40% { transform: scale(1); opacity: 1; } }

/* Input area */
.input-area { flex-shrink: 0; padding: 12px 16px; border-top: 1px solid var(--border); }
.input-row { display: flex; align-items: flex-end; gap: 10px; background: var(--bg-input); border: 1px solid var(--border); border-radius: var(--radius); padding: 4px 8px; transition: border-color var(--transition); }
.input-row:focus-within { border-color: var(--border-focus); box-shadow: 0 0 0 2px var(--green-glow); }
.prompt-caret { color: var(--green); font-size: 12px; flex-shrink: 0; padding: 10px 0 10px 4px; }
#prompt-input {
    flex: 1; background: transparent; border: none; outline: none; color: var(--text-bright);
    font-family: var(--font-mono); font-size: 13px; padding: 10px 4px; caret-color: var(--green);
    resize: none; max-height: 120px; line-height: 1.5;
}
#prompt-input::placeholder { color: var(--text-dim); }
.metrics-bar { display: flex; gap: 16px; padding: 6px 4px 0; font-size: 10px; color: var(--text-dim); letter-spacing: 0.5px; min-height: 18px; }
.metric-item { display: flex; gap: 4px; }
.metric-value { color: var(--text); }

/* Trace panel */
.trace-panel {
    width: var(--trace-w); border-left: 1px solid var(--border); background: var(--bg-sidebar);
    display: flex; flex-direction: column; flex-shrink: 0; overflow: hidden;
}
.trace-panel.hidden { display: none; }
.panel-header {
    display: flex; align-items: center; justify-content: space-between;
    padding: 10px 14px; border-bottom: 1px solid var(--border);
}
.panel-title { font-size: 10px; letter-spacing: 1.5px; color: var(--green); font-weight: 600; }
.trace-content { flex: 1; overflow-y: auto; padding: 12px; }
.trace-content::-webkit-scrollbar { width: 3px; }
.trace-content::-webkit-scrollbar-thumb { background: var(--border); }
.empty-state { color: var(--text-dim); font-size: 12px; text-align: center; padding: 20px; }

/* Trace spans */
.trace-span {
    padding: 8px 10px; border-left: 3px solid var(--border); margin-bottom: 8px;
    font-size: 11px; background: var(--bg-elevated); border-radius: 0 var(--radius) var(--radius) 0;
}
.trace-span[data-type="llm_call"] { border-left-color: var(--cyan); }
.trace-span[data-type="tool_call"] { border-left-color: var(--amber); }
.trace-span[data-type="guard_check"] { border-left-color: var(--purple); }
.span-name { font-weight: 600; color: var(--text-bright); }
.span-type { color: var(--text-dim); font-size: 10px; margin-left: 6px; }
.span-duration { float: right; color: var(--text-dim); }
.span-meta { margin-top: 4px; color: var(--text-dim); font-size: 10px; }

/* Trace summary */
.trace-summary { padding: 10px 14px; border-top: 1px solid var(--border); font-size: 11px; }
.trace-summary-row { display: flex; justify-content: space-between; margin-bottom: 2px; }
.trace-summary-label { color: var(--text-dim); }
.trace-summary-value { color: var(--text); }

/* Tool drawer */
.tool-drawer {
    position: fixed; bottom: 0; left: var(--sidebar-w); right: 0;
    height: 280px; background: var(--bg-sidebar); border-top: 1px solid var(--border);
    z-index: 100; display: flex; flex-direction: column;
}
.tool-drawer.hidden { display: none; }
.tool-drawer-content { flex: 1; padding: 12px 16px; overflow-y: auto; display: flex; flex-direction: column; gap: 10px; }
.tool-select-row { display: flex; gap: 8px; align-items: center; }
.tool-select {
    flex: 1; background: var(--bg-input); border: 1px solid var(--border); color: var(--text);
    font-family: var(--font-mono); font-size: 12px; padding: 6px 10px; border-radius: var(--radius);
    outline: none;
}
.tool-select:focus { border-color: var(--green); }
.tool-description { color: var(--text-dim); font-size: 12px; font-style: italic; }
.tool-args-editor { display: flex; flex-direction: column; gap: 6px; }
.tool-arg-row { display: flex; gap: 8px; align-items: center; font-size: 12px; }
.tool-arg-label { color: var(--amber); min-width: 100px; }
.tool-arg-input {
    flex: 1; background: var(--bg-input); border: 1px solid var(--border); color: var(--text);
    font-family: var(--font-mono); font-size: 12px; padding: 4px 8px; border-radius: var(--radius);
    outline: none;
}
.tool-arg-input:focus { border-color: var(--green); }
.tool-arg-type { color: var(--text-dim); font-size: 10px; min-width: 60px; }
.tool-output {
    background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 10px 12px; font-size: 12px; white-space: pre-wrap; min-height: 40px;
    color: var(--green);
}

/* Responsive */
@media (max-width: 900px) {
    .sidebar { display: none; }
    .tool-drawer { left: 0; }
    .trace-panel { display: none !important; }
}
'''


# ------------------------------------------------------------------
# app.js — Dashboard client logic
# ------------------------------------------------------------------

UI_JS = '''/* Synth Agent UI — Dashboard */

const chatArea = document.getElementById("chat-area");
const chatForm = document.getElementById("chat-form");
const promptInput = document.getElementById("prompt-input");
const btnSend = document.getElementById("btn-send");
const btnClear = document.getElementById("btn-clear");
const btnReload = document.getElementById("btn-reload");
const metricsBar = document.getElementById("metrics-bar");
const statusBadge = document.getElementById("status");
const tracePanel = document.getElementById("trace-panel");
const traceContent = document.getElementById("trace-content");
const traceSummary = document.getElementById("trace-summary");
const toolDrawer = document.getElementById("tool-drawer");
const toolSelect = document.getElementById("tool-select");
const toolDesc = document.getElementById("tool-description");
const toolArgsEditor = document.getElementById("tool-args-editor");
const toolOutput = document.getElementById("tool-output");
const convList = document.getElementById("conv-list");
const topbarTitle = document.getElementById("topbar-title");
const sidebar = document.getElementById("sidebar");

let isLoading = false;
let currentConv = "default";
let toolSchemas = {};
let sessionTokens = 0;
let sessionCost = 0;
let turnCount = 0;

/* ------------------------------------------------------------------ */
/* Init                                                                */
/* ------------------------------------------------------------------ */

async function init() {
    await loadAgentInfo();
    await loadTools();
    await loadConversations();
    autoResizeTextarea();
}

async function loadAgentInfo() {
    try {
        const r = await fetch("/api/info");
        const d = await r.json();
        document.getElementById("info-model").textContent = d.model;
        document.getElementById("info-tools").textContent = d.tools;
    } catch (e) { /* ignore */ }
}

async function loadTools() {
    try {
        const r = await fetch("/api/tools");
        const d = await r.json();
        toolSelect.innerHTML = '<option value="">Select a tool...</option>';
        for (const t of d.tools) {
            toolSchemas[t.name] = t;
            const opt = document.createElement("option");
            opt.value = t.name;
            opt.textContent = t.name;
            toolSelect.appendChild(opt);
        }
    } catch (e) { /* ignore */ }
}

async function loadConversations() {
    try {
        const r = await fetch("/api/conversations");
        const d = await r.json();
        renderConvList(d.conversations, d.current);
    } catch (e) { /* ignore */ }
}

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

function esc(text) {
    const d = document.createElement("div");
    d.textContent = text;
    return d.innerHTML;
}

function clearWelcome() {
    const w = document.getElementById("welcome");
    if (w) w.remove();
}

function scrollToBottom() { chatArea.scrollTop = chatArea.scrollHeight; }

function setStatus(text, ok) {
    const dot = statusBadge.querySelector(".status-dot");
    const label = statusBadge.querySelector(".status-text");
    label.textContent = text;
    const color = ok ? "var(--green)" : "var(--red)";
    dot.style.background = color;
    dot.style.boxShadow = "0 0 6px " + color;
    statusBadge.style.borderColor = ok ? "var(--green-dim)" : "var(--red)";
    statusBadge.style.color = color;
}

function autoResizeTextarea() {
    promptInput.addEventListener("input", () => {
        promptInput.style.height = "auto";
        promptInput.style.height = Math.min(promptInput.scrollHeight, 120) + "px";
    });
}

/* ------------------------------------------------------------------ */
/* Conversations                                                       */
/* ------------------------------------------------------------------ */

function renderConvList(ids, active) {
    convList.innerHTML = "";
    for (const id of ids) {
        const el = document.createElement("div");
        el.className = "conv-item" + (id === active ? " active" : "");
        el.textContent = id;
        el.onclick = () => switchConv(id);
        convList.appendChild(el);
    }
    currentConv = active;
    topbarTitle.textContent = active;
}

async function switchConv(id) {
    currentConv = id;
    topbarTitle.textContent = id;
    document.querySelectorAll(".conv-item").forEach(el => {
        el.classList.toggle("active", el.textContent === id);
    });
    chatArea.innerHTML = "";
    try {
        const r = await fetch("/api/conversations/" + id);
        const d = await r.json();
        for (const msg of d.messages) {
            if (msg.role === "user") addUserMessage(msg.content);
            else if (msg.role === "agent") addAgentMessage(msg.data);
        }
    } catch (e) { /* ignore */ }
}

async function newConversation() {
    try {
        const r = await fetch("/api/conversations", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({}),
        });
        const d = await r.json();
        await loadConversations();
        chatArea.innerHTML = "";
    } catch (e) { /* ignore */ }
}

/* ------------------------------------------------------------------ */
/* Messages                                                            */
/* ------------------------------------------------------------------ */

function addUserMessage(text) {
    clearWelcome();
    const div = document.createElement("div");
    div.className = "message msg-user";
    div.innerHTML = '<div class="msg-label msg-label-user">YOU</div><div class="msg-body">' + esc(text) + "</div>";
    chatArea.appendChild(div);
    scrollToBottom();
}

function addAgentMessage(data) {
    const div = document.createElement("div");
    div.className = "message msg-agent";
    let toolHtml = "";
    if (data.tool_calls && data.tool_calls.length > 0) {
        toolHtml = '<div class="tool-calls">';
        for (const tc of data.tool_calls) {
            toolHtml += '<div class="tool-call"><span class="tool-name">' + esc(tc.name) + '</span><span class="tool-args">' + esc(JSON.stringify(tc.args)) + '</span><span class="tool-latency">' + tc.latency_ms + 'ms</span><div class="tool-result">' + esc(tc.result) + "</div></div>";
        }
        toolHtml += "</div>";
    }
    div.innerHTML = '<div class="msg-label msg-label-agent">AGENT</div><div class="msg-body">' + esc(data.text) + toolHtml + "</div>";
    chatArea.appendChild(div);
    scrollToBottom();

    sessionTokens += data.tokens.total;
    sessionCost += data.cost;
    turnCount++;

    metricsBar.innerHTML =
        '<div class="metric-item"><span>Tokens:</span><span class="metric-value">' + data.tokens.total + '</span></div>' +
        '<div class="metric-item"><span>Cost:</span><span class="metric-value">$' + data.cost.toFixed(4) + '</span></div>' +
        '<div class="metric-item"><span>Latency:</span><span class="metric-value">' + data.latency_ms + 'ms</span></div>' +
        '<div class="metric-item"><span>Tools:</span><span class="metric-value">' + data.tool_calls.length + '</span></div>' +
        '<div class="metric-item"><span>Session:</span><span class="metric-value">' + sessionTokens + ' tok / $' + sessionCost.toFixed(4) + '</span></div>';

    if (data.trace) renderTrace(data.trace, data);
}

function addErrorMessage(text) {
    const div = document.createElement("div");
    div.className = "message msg-error";
    div.innerHTML = '<div class="msg-label msg-label-error">ERROR</div><div class="msg-body">' + esc(text) + "</div>";
    chatArea.appendChild(div);
    scrollToBottom();
}

function showLoading() {
    const div = document.createElement("div");
    div.className = "message msg-agent"; div.id = "loading-msg";
    div.innerHTML = '<div class="msg-label msg-label-agent">AGENT</div><div class="loading"><div class="loading-dot"></div><div class="loading-dot"></div><div class="loading-dot"></div></div>';
    chatArea.appendChild(div);
    scrollToBottom();
}

function hideLoading() { const el = document.getElementById("loading-msg"); if (el) el.remove(); }

/* ------------------------------------------------------------------ */
/* Trace panel                                                         */
/* ------------------------------------------------------------------ */

function renderTrace(spans, data) {
    if (!spans || spans.length === 0) {
        traceContent.innerHTML = '<p class="empty-state">No trace spans.</p>';
        return;
    }
    let html = "";
    for (const s of spans) {
        let metaHtml = "";
        if (s.metadata) {
            const keys = Object.keys(s.metadata);
            if (keys.length > 0) {
                metaHtml = '<div class="span-meta">' + keys.map(k => k + ": " + s.metadata[k]).join(" | ") + "</div>";
            }
        }
        html += '<div class="trace-span" data-type="' + s.type + '"><span class="span-name">' + esc(s.name) + '</span><span class="span-type">' + s.type + '</span><span class="span-duration">' + s.duration_ms + 'ms</span>' + metaHtml + '</div>';
    }
    traceContent.innerHTML = html;

    traceSummary.innerHTML =
        '<div class="trace-summary-row"><span class="trace-summary-label">Spans</span><span class="trace-summary-value">' + spans.length + '</span></div>' +
        '<div class="trace-summary-row"><span class="trace-summary-label">Tokens</span><span class="trace-summary-value">' + data.tokens.total + '</span></div>' +
        '<div class="trace-summary-row"><span class="trace-summary-label">Cost</span><span class="trace-summary-value">$' + data.cost.toFixed(4) + '</span></div>' +
        '<div class="trace-summary-row"><span class="trace-summary-label">Latency</span><span class="trace-summary-value">' + data.latency_ms + 'ms</span></div>';
}

/* ------------------------------------------------------------------ */
/* Tool playground                                                     */
/* ------------------------------------------------------------------ */

function renderToolArgs(name) {
    const schema = toolSchemas[name];
    if (!schema) { toolArgsEditor.innerHTML = ""; toolDesc.textContent = ""; return; }
    toolDesc.textContent = schema.description;
    const props = schema.parameters.properties || {};
    const required = schema.parameters.required || [];
    let html = "";
    for (const [pname, pschema] of Object.entries(props)) {
        const req = required.includes(pname) ? " *" : "";
        html += '<div class="tool-arg-row"><span class="tool-arg-label">' + pname + req + '</span><input class="tool-arg-input" data-arg="' + pname + '" placeholder="' + (pschema.type || "string") + '"><span class="tool-arg-type">' + (pschema.type || "?") + '</span></div>';
    }
    toolArgsEditor.innerHTML = html;
    toolOutput.textContent = "";
}

async function runTool() {
    const name = toolSelect.value;
    if (!name) return;
    const args = {};
    toolArgsEditor.querySelectorAll(".tool-arg-input").forEach(input => {
        let val = input.value;
        const schema = toolSchemas[name];
        const ptype = schema.parameters.properties[input.dataset.arg]?.type;
        if (ptype === "integer") val = parseInt(val, 10);
        else if (ptype === "number") val = parseFloat(val);
        else if (ptype === "boolean") val = val === "true";
        if (val !== "" && val !== undefined && !Number.isNaN(val)) args[input.dataset.arg] = val;
    });
    toolOutput.textContent = "Running...";
    toolOutput.style.color = "var(--text-dim)";
    try {
        const r = await fetch("/api/tools/test", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, args }),
        });
        const d = await r.json();
        if (d.error) {
            toolOutput.textContent = "Error: " + d.error;
            toolOutput.style.color = "var(--red)";
        } else {
            toolOutput.textContent = d.result + "\\n\\n(" + d.latency_ms + "ms)";
            toolOutput.style.color = "var(--green)";
        }
    } catch (e) {
        toolOutput.textContent = "Network error: " + e.message;
        toolOutput.style.color = "var(--red)";
    }
}

/* ------------------------------------------------------------------ */
/* API calls                                                           */
/* ------------------------------------------------------------------ */

async function sendPrompt(prompt) {
    if (isLoading) return;
    isLoading = true;
    btnSend.disabled = true;
    addUserMessage(prompt);
    showLoading();
    try {
        const resp = await fetch("/api/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ prompt, conversation: currentConv }),
        });
        const data = await resp.json();
        hideLoading();
        if (data.error) { addErrorMessage(data.error); setStatus("ERROR", false); }
        else { addAgentMessage(data); setStatus("CONNECTED", true); }
    } catch (err) {
        hideLoading();
        addErrorMessage("Network error: " + err.message);
        setStatus("DISCONNECTED", false);
    } finally {
        isLoading = false;
        btnSend.disabled = false;
        promptInput.focus();
    }
}

async function reloadAgent() {
    try {
        const r = await fetch("/api/reload", { method: "POST" });
        const d = await r.json();
        if (d.error) addErrorMessage("Reload failed: " + d.error);
        else { setStatus("RELOADED", true); await loadAgentInfo(); await loadTools(); setTimeout(() => setStatus("CONNECTED", true), 2000); }
    } catch (e) { addErrorMessage("Reload error: " + e.message); setStatus("DISCONNECTED", false); }
}

/* ------------------------------------------------------------------ */
/* Event listeners                                                     */
/* ------------------------------------------------------------------ */

chatForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const text = promptInput.value.trim();
    if (!text) return;
    promptInput.value = "";
    promptInput.style.height = "auto";
    sendPrompt(text);
});

promptInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); chatForm.dispatchEvent(new Event("submit")); }
});

btnClear.addEventListener("click", () => {
    chatArea.innerHTML = '<div class="welcome" id="welcome"><p class="welcome-text">Chat cleared.</p></div>';
    metricsBar.innerHTML = "";
});

btnReload.addEventListener("click", reloadAgent);
document.getElementById("btn-new-chat").addEventListener("click", newConversation);

document.getElementById("btn-toggle-trace").addEventListener("click", () => tracePanel.classList.toggle("hidden"));
document.getElementById("btn-close-trace").addEventListener("click", () => tracePanel.classList.add("hidden"));

document.getElementById("btn-toggle-tools").addEventListener("click", () => toolDrawer.classList.toggle("hidden"));
document.getElementById("btn-close-tools").addEventListener("click", () => toolDrawer.classList.add("hidden"));

document.getElementById("btn-sidebar-toggle").addEventListener("click", () => sidebar.classList.toggle("collapsed"));

toolSelect.addEventListener("change", () => renderToolArgs(toolSelect.value));
document.getElementById("btn-run-tool").addEventListener("click", runTool);

init();
'''


# ------------------------------------------------------------------
# README.md
# ------------------------------------------------------------------

UI_README = '''# {name}

A developer dashboard for testing your SynthAgentSDK agent locally.

## Setup

```bash
pip install uvicorn fastapi
```

## Usage

1. Edit `server.py` and set `AGENT_FILE` to point at your agent module.
2. Start the server:

```bash
python server.py
```

3. Open http://localhost:8420 in your browser.

## Features

- **Chat interface** — talk to your agent with real-time responses
- **Conversation history** — sidebar with multiple conversations, switch between them
- **Trace timeline** — collapsible right panel showing every span (LLM calls, tool calls, guard checks) with timing
- **Tool playground** — bottom drawer to test individual tools with custom arguments, see results and latency
- **Metrics** — per-response and session-level token count, cost, and latency
- **Hot-reload** — reload your agent from disk without restarting the server
- **Fallout terminal aesthetic** — CRT scanlines, green-on-dark theme matching the Synth boot sequence
'''
