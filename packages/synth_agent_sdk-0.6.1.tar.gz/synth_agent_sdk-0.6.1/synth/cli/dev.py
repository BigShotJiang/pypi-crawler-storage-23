"""``synth dev`` command — rich terminal UI for interactive agent development.

Launches the Fallout-inspired TUI with streaming responses, slash commands,
tool call visualization, and a persistent status bar.
"""

from __future__ import annotations


def run_dev(file: str) -> None:
    """Start the interactive dev environment.

    Parameters
    ----------
    file:
        Path to the Python file containing the ``agent`` variable.
    """
    from synth.cli._tui import launch_tui

    launch_tui(file)
