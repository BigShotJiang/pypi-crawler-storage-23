"""Human-in-the-loop pause/resume logic for graph execution.

The core pause/resume mechanics are implemented directly in
:class:`synth.orchestration.graph.Graph` via:

- ``graph.with_human_in_the_loop(pause_at, timeout, fallback)``
- ``PausedRun`` returned when execution reaches a pause node
- ``graph.resume(run_id, human_input)`` to continue from checkpoint

This module re-exports the relevant types for convenience and documents
the human-in-the-loop workflow.

Workflow
--------
1. Configure: ``graph.with_human_in_the_loop(pause_at=["review"])``
2. Run: ``result = graph.run(state, run_id="abc")``
3. If paused: ``result`` is a ``PausedRun`` with ``paused_at_node``,
   ``state``, and ``checkpoint``.
4. Resume: ``final = graph.resume("abc", human_input="approved")``

The checkpoint is persisted to the configured ``BaseCheckpointStore``
so that ``resume()`` can be called from a different process or session.
"""

from __future__ import annotations

# Re-export for convenience
from synth.types import Checkpoint, PausedRun

__all__ = ["Checkpoint", "PausedRun"]
