"""Bedrock model catalog and region/CRIS validation for AgentCore deployments.

Provides a static, bundled catalog of supported Bedrock models with their
native and Cross-Region Inference (CRIS) availability, plus a
``RegionValidator`` that filters models by region and resolves the correct
model ID (base or CRIS profile) for a given (model, region) pair.

No network calls are made at import time — all data is bundled statically.
"""

from __future__ import annotations

from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class ModelEntry:
    """A single Bedrock model with its regional availability metadata.

    Parameters
    ----------
    model_id:
        The base Bedrock model ID (e.g. ``anthropic.claude-sonnet-4-5-20250514-v1:0``).
    display_name:
        Human-readable name shown in selection prompts.
    native_regions:
        AWS regions where the model is natively available without CRIS.
    cris_regions:
        AWS regions where the model is available only via Cross-Region
        Inference (CRIS).  A CRIS profile ID must be used in these regions.
    cris_profile_id:
        The cross-region inference profile ID to use when CRIS is required
        (e.g. ``us.anthropic.claude-sonnet-4-5-20250514-v1:0``).
    """

    model_id: str
    display_name: str
    native_regions: list[str] = field(default_factory=list)
    cris_regions: list[str] = field(default_factory=list)
    cris_profile_id: str = ""


# ---------------------------------------------------------------------------
# Model catalog
# ---------------------------------------------------------------------------

# Native regions for Claude models (Requirement 4.5)
_CLAUDE_NATIVE = ["us-east-1", "us-west-2", "eu-west-1", "ap-northeast-1"]

# CRIS regions for Claude models
_CLAUDE_CRIS = ["us-east-2", "eu-central-1", "ap-southeast-1", "ap-southeast-2"]

# Native regions for Amazon Nova models
_NOVA_NATIVE = ["us-east-1", "us-west-2"]

# CRIS regions for Amazon Nova models
_NOVA_CRIS = ["eu-west-1", "ap-northeast-1"]


class ModelCatalog:
    """Static catalog of supported Bedrock models.

    All data is bundled at import time — no network calls are made.

    Attributes
    ----------
    MODELS:
        List of all supported ``ModelEntry`` instances.

    Examples
    --------
    >>> catalog = ModelCatalog()
    >>> len(catalog.MODELS) >= 8
    True
    """

    MODELS: list[ModelEntry] = [
        # ----------------------------------------------------------------
        # Anthropic Claude models
        # ----------------------------------------------------------------
        ModelEntry(
            model_id="anthropic.claude-3-5-haiku-20241022-v1:0",
            display_name="Claude 3.5 Haiku",
            native_regions=_CLAUDE_NATIVE,
            cris_regions=_CLAUDE_CRIS,
            cris_profile_id="us.anthropic.claude-3-5-haiku-20241022-v1:0",
        ),
        ModelEntry(
            model_id="anthropic.claude-3-5-sonnet-20241022-v2:0",
            display_name="Claude 3.5 Sonnet",
            native_regions=_CLAUDE_NATIVE,
            cris_regions=_CLAUDE_CRIS,
            cris_profile_id="us.anthropic.claude-3-5-sonnet-20241022-v2:0",
        ),
        ModelEntry(
            model_id="anthropic.claude-3-7-sonnet-20250219-v1:0",
            display_name="Claude 3.7 Sonnet",
            native_regions=_CLAUDE_NATIVE,
            cris_regions=_CLAUDE_CRIS,
            cris_profile_id="us.anthropic.claude-3-7-sonnet-20250219-v1:0",
        ),
        ModelEntry(
            model_id="anthropic.claude-sonnet-4-5-20250514-v1:0",
            display_name="Claude Sonnet 4.5",
            native_regions=_CLAUDE_NATIVE,
            cris_regions=_CLAUDE_CRIS,
            cris_profile_id="us.anthropic.claude-sonnet-4-5-20250514-v1:0",
        ),
        ModelEntry(
            model_id="anthropic.claude-opus-4-20250514-v1:0",
            display_name="Claude Opus 4",
            native_regions=_CLAUDE_NATIVE,
            cris_regions=_CLAUDE_CRIS,
            cris_profile_id="us.anthropic.claude-opus-4-20250514-v1:0",
        ),
        # ----------------------------------------------------------------
        # Amazon Nova models
        # ----------------------------------------------------------------
        ModelEntry(
            model_id="amazon.nova-micro-v1:0",
            display_name="Amazon Nova Micro",
            native_regions=_NOVA_NATIVE,
            cris_regions=_NOVA_CRIS,
            cris_profile_id="us.amazon.nova-micro-v1:0",
        ),
        ModelEntry(
            model_id="amazon.nova-lite-v1:0",
            display_name="Amazon Nova Lite",
            native_regions=_NOVA_NATIVE,
            cris_regions=_NOVA_CRIS,
            cris_profile_id="us.amazon.nova-lite-v1:0",
        ),
        ModelEntry(
            model_id="amazon.nova-pro-v1:0",
            display_name="Amazon Nova Pro",
            native_regions=_NOVA_NATIVE,
            cris_regions=_NOVA_CRIS,
            cris_profile_id="us.amazon.nova-pro-v1:0",
        ),
    ]


# ---------------------------------------------------------------------------
# Region validator
# ---------------------------------------------------------------------------


@dataclass
class _RegionFilterResult:
    """Internal result from ``RegionValidator.models_for_region``.

    Parameters
    ----------
    models:
        Models available in the requested region (native or via CRIS).
    availability_unknown:
        ``True`` when the region was not found in the catalog at all, so
        all models are returned as a fallback (Requirement 4.8).
    """

    models: list[ModelEntry]
    availability_unknown: bool


class RegionValidator:
    """Validate model/region combinations and resolve effective model IDs.

    Parameters
    ----------
    catalog:
        The ``ModelCatalog`` instance to query.

    Examples
    --------
    >>> catalog = ModelCatalog()
    >>> validator = RegionValidator(catalog)
    >>> models = validator.models_for_region("us-east-1")
    >>> len(models) > 0
    True
    """

    def __init__(self, catalog: ModelCatalog) -> None:
        self._catalog = catalog

    def models_for_region(self, region: str) -> list[ModelEntry]:
        """Return models available in *region* (natively or via CRIS).

        If *region* is not present in the catalog at all, all models are
        returned and a warning is emitted (Requirement 4.8).  Callers that
        need to detect this case should use ``_models_for_region_with_flag``
        directly.

        Parameters
        ----------
        region:
            An AWS region string (e.g. ``"us-east-1"``).

        Returns
        -------
        list[ModelEntry]
            Models available in the region.  If the region is unknown,
            returns all models.
        """
        result = self._models_for_region_with_flag(region)
        return result.models

    def availability_unknown_for_region(self, region: str) -> bool:
        """Return ``True`` if *region* is not known to the catalog.

        Parameters
        ----------
        region:
            An AWS region string.

        Returns
        -------
        bool
            ``True`` when the region is not in any model's native or CRIS
            list, meaning availability could not be verified.
        """
        return self._models_for_region_with_flag(region).availability_unknown

    def requires_cris(self, model_id: str, region: str) -> bool:
        """Return ``True`` if *model_id* requires CRIS in *region*.

        A model requires CRIS when *region* is in its ``cris_regions`` list
        and NOT in its ``native_regions`` list.

        Parameters
        ----------
        model_id:
            The base Bedrock model ID.
        region:
            An AWS region string.

        Returns
        -------
        bool
            ``True`` if CRIS is required; ``False`` if the model is natively
            available or not found in the catalog.
        """
        entry = self._find_entry(model_id)
        if entry is None:
            return False
        return region in entry.cris_regions and region not in entry.native_regions

    def effective_model_id(self, model_id: str, region: str) -> str:
        """Return the model ID to use for *model_id* in *region*.

        Returns the CRIS profile ID when CRIS is required, otherwise the
        base model ID (Requirements 4.3, 4.4).

        Parameters
        ----------
        model_id:
            The base Bedrock model ID.
        region:
            An AWS region string.

        Returns
        -------
        str
            The CRIS profile ID if CRIS is required, otherwise *model_id*.
        """
        if self.requires_cris(model_id, region):
            entry = self._find_entry(model_id)
            if entry is not None and entry.cris_profile_id:
                return entry.cris_profile_id
        return model_id

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _models_for_region_with_flag(self, region: str) -> _RegionFilterResult:
        """Filter models by region and return a result with the unknown flag."""
        available: list[ModelEntry] = []
        region_known = False

        for entry in self._catalog.MODELS:
            in_native = region in entry.native_regions
            in_cris = region in entry.cris_regions
            if in_native or in_cris:
                region_known = True
                available.append(entry)

        if not region_known:
            # Region not in catalog — return all models with warning flag
            return _RegionFilterResult(
                models=list(self._catalog.MODELS),
                availability_unknown=True,
            )

        return _RegionFilterResult(models=available, availability_unknown=False)

    def _find_entry(self, model_id: str) -> ModelEntry | None:
        """Look up a ``ModelEntry`` by its base model ID."""
        for entry in self._catalog.MODELS:
            if entry.model_id == model_id:
                return entry
        return None
