# Requirements Document

## Introduction

This feature redesigns the `synth init` CLI flow in `synth/cli/init_cmd.py` to fix two bugs and restructure the interactive wizard step order for a more logical user experience. The changes are scoped entirely to `init_cmd.py` — no modifications to `_generate_project`, `_run_tool_wizard`, `_run_mcp_wizard`, `_build_agent_code`, or other helpers.

Bug 1: The generated `agent.py` receives a Bedrock model ID without the required `bedrock/` prefix, causing runtime failures in the Synth `ProviderRouter`.

Bug 2: The init wizard step order is illogical — model selection is locked inside credential checking, agent instructions come after feature selection, and the tool/MCP wizards run after a features prompt that already asks about tools.

The fix splits `_run_agentcore_setup()` into two focused functions, reorders the wizard steps, and adds a post-generation deploy prompt for AgentCore projects.

## Glossary

- **Init_Wizard**: The interactive CLI flow started by `synth init`, implemented in `run_init()` within `synth/cli/init_cmd.py`.
- **ProviderRouter**: The Synth SDK component that routes model calls to the correct provider based on the model ID prefix (e.g., `bedrock/`, `ollama/`, `gemini/`).
- **Model_Selection**: The new function `_run_model_selection()` responsible for presenting the model list and returning the selected model ID for any provider.
- **Credential_Check**: The new function `_run_credential_check()` responsible for detecting and validating AWS credentials, extracted from the former `_run_agentcore_setup()`.
- **RegionValidator**: The existing component in `synth/deploy/agentcore/model_catalog.py` that filters models by region and returns effective model IDs.
- **CRIS**: Cross-Region Inference — an AWS Bedrock feature that routes model invocations across regions when a model is not natively available in the selected region.

---

## Requirements

### Requirement 1: Bedrock Model ID Prefix

**User Story:** As a developer initializing an AgentCore project, I want the generated `agent.py` to contain a valid model ID with the `bedrock/` prefix, so that the Synth ProviderRouter can route the call correctly at runtime.

#### Acceptance Criteria

1. WHEN Model_Selection returns a model ID for the AgentCore provider, THE Model_Selection SHALL prepend the string `bedrock/` to the effective model ID returned by RegionValidator.
2. WHEN the generated `agent.py` contains an `Agent(model=...)` call for an AgentCore project, THE Init_Wizard SHALL use the `bedrock/`-prefixed model ID in that call.
3. WHEN the `bedrock/` prefix is prepended, THE Model_Selection SHALL NOT double-prefix a model ID that already starts with `bedrock/`.

---

### Requirement 2: Split `_run_agentcore_setup` into Separate Functions

**User Story:** As a developer maintaining the init flow, I want model selection and credential checking to be separate functions, so that they can be called at different points in the wizard and each has a single responsibility.

#### Acceptance Criteria

1. THE Init_Wizard SHALL replace `_run_agentcore_setup()` with two new functions: `_run_model_selection()` for model picking and `_run_credential_check()` for AWS credential detection and region selection.
2. THE `_run_model_selection()` function SHALL accept the provider name as a parameter and return the selected model ID string.
3. WHEN the provider is AgentCore, THE `_run_model_selection()` function SHALL prompt for a target AWS region, display available models filtered by that region using RegionValidator, and return the `bedrock/`-prefixed effective model ID.
4. WHEN the provider is not AgentCore, THE `_run_model_selection()` function SHALL return the default model ID from the provider configuration without additional prompting.
5. THE `_run_credential_check()` function SHALL perform AWS credential detection, profile selection, and region confirmation, and return a dictionary containing `aws_region`, `aws_profile`, and `cris_enabled` fields.
6. THE former `_run_agentcore_setup()` function SHALL be removed from the codebase after the split is complete.

---

### Requirement 3: Redesigned Init Wizard Step Order

**User Story:** As a developer using `synth init`, I want the wizard steps to follow a logical progression — identity first, then model, then behavior, then infrastructure — so that the flow feels natural and avoids redundant prompts.

#### Acceptance Criteria

1. THE Init_Wizard SHALL execute steps in the following order: (1) project name, (2) description, (3) provider selection, (4) model selection, (5) agent instructions, (6) tool wizard, (7) MCP wizard, (8) feature selection, (9) AgentCore credential check (if applicable), (10) summary and confirmation, (11) project generation, (12) deploy prompt (if applicable).
2. WHEN the feature selection step runs, THE Init_Wizard SHALL NOT include "Custom tool functions" in the feature list, because tool configuration is handled by the preceding tool wizard step.
3. WHEN the provider is not AgentCore, THE Init_Wizard SHALL skip step 9 (credential check) and step 12 (deploy prompt).
4. WHEN the provider is AgentCore, THE Init_Wizard SHALL execute step 9 (credential check) after feature selection and before the summary.
5. THE Init_Wizard SHALL call `_run_model_selection()` at step 4 for all providers.

---

### Requirement 4: Post-Generation Deploy Prompt

**User Story:** As a developer who just initialized an AgentCore project with valid credentials, I want to be asked whether to deploy immediately, so that I can go from init to deployment in a single session.

#### Acceptance Criteria

1. WHEN the provider is AgentCore and project generation completes successfully, THE Init_Wizard SHALL prompt the user with a "Deploy now?" confirmation (default: no).
2. WHEN the user confirms the deploy prompt, THE Init_Wizard SHALL invoke the existing `synth deploy` flow targeting the generated `agent.py`.
3. WHEN the user declines the deploy prompt, THE Init_Wizard SHALL print a message indicating the user can deploy later with `synth deploy --target agentcore agent.py`.
4. WHEN the provider is not AgentCore, THE Init_Wizard SHALL NOT display the deploy prompt.

---

### Requirement 5: Preserve Existing Helper Behavior

**User Story:** As a developer maintaining the Synth SDK, I want the init flow redesign to leave all existing helper functions unchanged, so that the refactoring scope is contained and testable.

#### Acceptance Criteria

1. THE Init_Wizard redesign SHALL NOT modify the `_generate_project()` function signature or behavior.
2. THE Init_Wizard redesign SHALL NOT modify the `_run_tool_wizard()` function signature or behavior.
3. THE Init_Wizard redesign SHALL NOT modify the `_run_mcp_wizard()` function signature or behavior.
4. THE Init_Wizard redesign SHALL NOT modify the `_build_agent_code()` function signature or behavior.
5. THE Init_Wizard redesign SHALL pass the same data structures to `_generate_project()` as the current implementation, with the model ID corrected to include the `bedrock/` prefix for AgentCore projects.
