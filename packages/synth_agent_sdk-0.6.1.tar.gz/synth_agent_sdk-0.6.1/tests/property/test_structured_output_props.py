# Feature: synth-agent-sdk, Properties 39-40: Structured output property tests
"""Property-based tests for the Synth structured output system.

**Property 39: Structured output Pydantic parsing**
**Validates: Requirements 17.1**

For any valid Pydantic model and any model output that is valid JSON conforming
to that schema, the handler should parse it into an instance of the Pydantic
model.

**Property 40: Structured output retry on parse failure**
**Validates: Requirements 17.2**

For any model output that cannot be parsed into the specified Pydantic schema,
the handler should retry up to max_retries times with a corrective prompt.
If all retries fail, a SynthParseError should be raised.
"""

from __future__ import annotations

import asyncio
import json

from hypothesis import given, settings
from hypothesis import strategies as st
from pydantic import BaseModel

from synth.errors import SynthParseError
from synth.providers.base import ProviderResponse
from synth.structured.output import StructuredOutputHandler
from synth.types import TokenUsage

from tests.conftest import MockProvider


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_USAGE = TokenUsage(input_tokens=5, output_tokens=10, total_tokens=15)


def _run(coro):
    """Run an async coroutine synchronously in a fresh event loop."""
    import asyncio
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


# ---------------------------------------------------------------------------
# Test Pydantic models
# ---------------------------------------------------------------------------


class SimpleUser(BaseModel):
    name: str
    age: int


class Config(BaseModel):
    enabled: bool
    threshold: float
    label: str


# ---------------------------------------------------------------------------
# Property 39: Structured output Pydantic parsing
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    name=st.text(min_size=1, max_size=50),
    age=st.integers(min_value=0, max_value=150),
)
def test_structured_output_pydantic_parsing(name, age):
    """Property 39: For any valid JSON conforming to the schema, the handler
    should parse it into a Pydantic model instance.

    **Validates: Requirements 17.1**
    """
    handler = StructuredOutputHandler(schema=SimpleUser)
    raw = json.dumps({"name": name, "age": age})
    result = handler.parse(raw)

    assert isinstance(result, SimpleUser)
    assert result.name == name
    assert result.age == age


@settings(max_examples=100)
@given(
    enabled=st.booleans(),
    threshold=st.floats(
        min_value=-1000.0, max_value=1000.0,
        allow_nan=False, allow_infinity=False,
    ),
    label=st.text(min_size=1, max_size=30),
)
def test_structured_output_config_model(enabled, threshold, label):
    """Property 39: Parsing works for different Pydantic model shapes.

    **Validates: Requirements 17.1**
    """
    handler = StructuredOutputHandler(schema=Config)
    raw = json.dumps({"enabled": enabled, "threshold": threshold, "label": label})
    result = handler.parse(raw)

    assert isinstance(result, Config)
    assert result.enabled == enabled
    assert result.label == label


# ---------------------------------------------------------------------------
# Property 40: Structured output retry on parse failure
# ---------------------------------------------------------------------------


@settings(max_examples=50)
@given(
    max_retries=st.integers(min_value=1, max_value=3),
)
def test_structured_output_retry_then_succeed(max_retries):
    """Property 40: When initial parse fails but a retry succeeds, the
    handler returns the parsed model.

    **Validates: Requirements 17.2**
    """
    handler = StructuredOutputHandler(schema=SimpleUser, max_retries=max_retries)

    # First output is invalid, retry output is valid
    valid_json = json.dumps({"name": "Alice", "age": 30})
    retry_response = ProviderResponse(text=valid_json, usage=_USAGE)
    provider = MockProvider(responses=[retry_response])

    messages = [{"role": "user", "content": "give me a user"}]
    result = _run(
        handler.parse_and_validate("not json at all", provider, messages)
    )

    assert isinstance(result, SimpleUser)
    assert result.name == "Alice"
    assert result.age == 30


@settings(max_examples=50)
@given(
    max_retries=st.integers(min_value=1, max_value=3),
)
def test_structured_output_exhausts_retries_raises_parse_error(max_retries):
    """Property 40: When all retries fail, SynthParseError is raised.

    **Validates: Requirements 17.2**
    """
    handler = StructuredOutputHandler(schema=SimpleUser, max_retries=max_retries)

    # All responses are invalid JSON
    bad_responses = [
        ProviderResponse(text="still not json", usage=_USAGE)
        for _ in range(max_retries)
    ]
    provider = MockProvider(responses=bad_responses)

    messages = [{"role": "user", "content": "give me a user"}]
    try:
        _run(handler.parse_and_validate("not json", provider, messages))
        raise AssertionError("Expected SynthParseError")
    except SynthParseError as err:
        assert "SimpleUser" in str(err)
        assert err.component == "StructuredOutputHandler"
        assert err.suggestion  # non-empty

    # Provider should have been called max_retries times (one per retry)
    assert len(provider.call_history) == max_retries
