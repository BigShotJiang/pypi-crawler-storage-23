"""Property-based tests for Pipeline orchestration.

**Property 13: Pipeline sequential data flow**
**Validates: Requirements 6.1**

**Property 14: Pipeline error halts with partial results**
**Validates: Requirements 6.2**

**Property 15: Pipeline streaming labels events with stage name**
**Validates: Requirements 6.3**
"""

from __future__ import annotations

import asyncio
from unittest.mock import patch

from hypothesis import given, settings
from hypothesis import strategies as st

from synth.agent import Agent
from synth.errors import PipelineError
from synth.orchestration.pipeline import Pipeline
from synth.providers.base import ProviderResponse
from synth.types import StageEvent, TokenUsage
from tests.conftest import MockProvider


def _run_async(coro):  # type: ignore[no-untyped-def]
    """Run a coroutine in a fresh event loop (safe inside Hypothesis tests)."""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_USAGE = TokenUsage(input_tokens=5, output_tokens=10, total_tokens=15)


def _make_agent(text: str) -> Agent:
    """Create an Agent backed by a MockProvider returning *text*."""
    provider = MockProvider(
        responses=[ProviderResponse(text=text, usage=_USAGE)],
    )
    with patch("synth.agent.ProviderRouter.resolve", return_value=provider):
        return Agent(instructions=text)


def _make_failing_agent(exc: Exception) -> Agent:
    """Create an Agent whose provider raises *exc*."""
    provider = MockProvider(error=exc)
    with patch("synth.agent.ProviderRouter.resolve", return_value=provider):
        return Agent(instructions="failing")


# ---------------------------------------------------------------------------
# Property 13: Pipeline sequential data flow
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    n_stages=st.integers(min_value=1, max_value=5),
    initial_input=st.text(min_size=1, max_size=50),
)
def test_pipeline_sequential_data_flow(n_stages: int, initial_input: str):
    """Property 13: Pipeline sequential data flow.

    For any Pipeline of N agents, calling pipeline.run(input) should result
    in agent[0] receiving the original input, and each subsequent agent[i]
    receiving agent[i-1]'s output text as its prompt.

    **Validates: Requirements 6.1**
    """
    # Each agent returns a deterministic output based on its index
    agents = [_make_agent(f"output_{i}") for i in range(n_stages)]
    pipeline = Pipeline(agents)

    result = _run_async(pipeline.arun(initial_input))

    # The final result should be the last agent's output
    assert result.text == f"output_{n_stages - 1}"


# ---------------------------------------------------------------------------
# Property 14: Pipeline error halts with partial results
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    n_ok=st.integers(min_value=0, max_value=4),
)
def test_pipeline_error_halts_with_partial_results(n_ok: int):
    """Property 14: Pipeline error halts with partial results.

    For any Pipeline where the agent at step k raises an error, the Pipeline
    should return partial results from steps 0 through k-1, and the error
    should identify step k and the failing agent's name.

    **Validates: Requirements 6.2**
    """
    ok_agents = [_make_agent(f"ok_{i}") for i in range(n_ok)]
    bad_agent = _make_failing_agent(RuntimeError("simulated failure"))
    stages = ok_agents + [bad_agent]
    pipeline = Pipeline(stages)

    try:
        _run_async(pipeline.arun("start"))
        # Should not reach here
        assert False, "Pipeline should have raised PipelineError"
    except PipelineError as err:
        assert err.failed_step == n_ok
        assert len(err.partial_results) == n_ok
        for i, partial in enumerate(err.partial_results):
            assert partial.text == f"ok_{i}"
        assert err.agent_name != ""


# ---------------------------------------------------------------------------
# Property 15: Pipeline streaming labels events with stage name
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    n_stages=st.integers(min_value=1, max_value=4),
)
def test_pipeline_streaming_labels_events_with_stage_name(n_stages: int):
    """Property 15: Pipeline streaming labels events with stage name.

    For any streamed Pipeline run, every yielded event should be wrapped in
    a StageEvent containing the stage name of the agent that produced it.

    **Validates: Requirements 6.3**
    """
    agents = [_make_agent(f"stage_{i}") for i in range(n_stages)]
    pipeline = Pipeline(agents)

    async def _collect():
        return [e async for e in pipeline.astream("input")]

    events = _run_async(_collect())

    # Every event must be a StageEvent
    assert all(isinstance(e, StageEvent) for e in events)

    # Every StageEvent must have a non-empty stage_name
    assert all(e.stage_name != "" for e in events)

    # There should be events from each stage
    stage_names = {e.stage_name for e in events}
    assert len(stage_names) == n_stages
