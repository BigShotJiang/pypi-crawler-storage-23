"""Unit tests for the memory system: BaseMemory, Memory factory, ThreadMemory, SemanticMemory."""

from __future__ import annotations

import asyncio
import warnings

import pytest

from synth.memory.base import BaseMemory, Memory
from synth.memory.semantic import SemanticMemory
from synth.memory.thread import ThreadMemory
from synth.types import Message


# ---------------------------------------------------------------------------
# BaseMemory ABC — cannot be instantiated directly
# ---------------------------------------------------------------------------


class TestBaseMemory:
    """Tests for the BaseMemory abstract base class."""

    def test_cannot_instantiate_directly(self):
        """BaseMemory raises TypeError when instantiated without subclassing."""
        with pytest.raises(TypeError, match="abstract method"):
            BaseMemory()  # type: ignore[abstract]

    def test_subclass_missing_get_messages_raises(self):
        """A subclass that only implements add_messages cannot be instantiated."""

        class Incomplete(BaseMemory):
            async def add_messages(
                self, thread_id: str, messages: list[Message]
            ) -> None:
                pass

        with pytest.raises(TypeError, match="abstract method"):
            Incomplete()  # type: ignore[abstract]

    def test_subclass_missing_add_messages_raises(self):
        """A subclass that only implements get_messages cannot be instantiated."""

        class Incomplete(BaseMemory):
            async def get_messages(self, thread_id: str) -> list[Message]:
                return []

        with pytest.raises(TypeError, match="abstract method"):
            Incomplete()  # type: ignore[abstract]

    def test_complete_subclass_instantiates(self):
        """A subclass implementing both methods can be instantiated."""

        class Complete(BaseMemory):
            async def get_messages(self, thread_id: str) -> list[Message]:
                return []

            async def add_messages(
                self, thread_id: str, messages: list[Message]
            ) -> None:
                pass

        mem = Complete()
        assert isinstance(mem, BaseMemory)


# ---------------------------------------------------------------------------
# Memory factory — static methods
# ---------------------------------------------------------------------------


class TestMemoryFactory:
    """Tests for the Memory factory class."""

    def test_thread_returns_thread_memory(self):
        """Memory.thread() returns a ThreadMemory instance."""
        mem = Memory.thread()
        assert isinstance(mem, ThreadMemory)
        assert isinstance(mem, BaseMemory)

    def test_thread_returns_new_instance_each_call(self):
        """Each call to Memory.thread() returns a distinct instance."""
        a = Memory.thread()
        b = Memory.thread()
        assert a is not b

    def test_thread_is_callable(self):
        """Memory.thread is a callable static method."""
        assert callable(Memory.thread)

    def test_persistent_is_callable(self):
        """Memory.persistent is a callable static method."""
        assert callable(Memory.persistent)

    def test_semantic_is_callable(self):
        """Memory.semantic is a callable static method."""
        assert callable(Memory.semantic)


# ---------------------------------------------------------------------------
# ThreadMemory stub — basic round-trip
# ---------------------------------------------------------------------------


class TestThreadMemoryStub:
    """Tests for the minimal ThreadMemory stub."""

    @pytest.mark.asyncio
    async def test_empty_thread_returns_empty_list(self):
        """Getting messages from a non-existent thread returns []."""
        mem = ThreadMemory()
        result = await mem.get_messages("nonexistent")
        assert result == []

    @pytest.mark.asyncio
    async def test_add_and_get_messages(self):
        """Messages added to a thread are retrievable."""
        mem = ThreadMemory()
        msgs: list[Message] = [
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "hi"},
        ]
        await mem.add_messages("t1", msgs)
        result = await mem.get_messages("t1")
        assert result == msgs

    @pytest.mark.asyncio
    async def test_messages_are_isolated_by_thread(self):
        """Messages in different threads do not leak."""
        mem = ThreadMemory()
        await mem.add_messages("t1", [{"role": "user", "content": "a"}])
        await mem.add_messages("t2", [{"role": "user", "content": "b"}])

        assert await mem.get_messages("t1") == [{"role": "user", "content": "a"}]
        assert await mem.get_messages("t2") == [{"role": "user", "content": "b"}]

    @pytest.mark.asyncio
    async def test_get_messages_returns_copy(self):
        """Returned list is a copy — mutating it doesn't affect stored data."""
        mem = ThreadMemory()
        await mem.add_messages("t1", [{"role": "user", "content": "x"}])
        result = await mem.get_messages("t1")
        result.clear()
        assert await mem.get_messages("t1") == [{"role": "user", "content": "x"}]

    @pytest.mark.asyncio
    async def test_add_messages_appends(self):
        """Successive add_messages calls append to the thread."""
        mem = ThreadMemory()
        await mem.add_messages("t1", [{"role": "user", "content": "first"}])
        await mem.add_messages("t1", [{"role": "assistant", "content": "second"}])
        result = await mem.get_messages("t1")
        assert len(result) == 2
        assert result[0]["content"] == "first"
        assert result[1]["content"] == "second"


from synth.memory.thread import ContextTruncationWarning


# ---------------------------------------------------------------------------
# ThreadMemory — token counting and truncation
# ---------------------------------------------------------------------------


class TestThreadMemoryTokenCounting:
    """Tests for ThreadMemory token estimation."""

    def test_estimate_tokens_empty(self):
        """Empty message list estimates to zero tokens."""
        mem = ThreadMemory()
        assert mem._estimate_tokens([]) == 0

    def test_estimate_tokens_single_message(self):
        """Token estimate uses len(content) // 4."""
        mem = ThreadMemory()
        # 12 chars -> 12 // 4 = 3
        msgs: list[Message] = [{"role": "user", "content": "hello world!"}]
        assert mem._estimate_tokens(msgs) == 3

    def test_estimate_tokens_multiple_messages(self):
        """Token estimate sums across all messages."""
        mem = ThreadMemory()
        msgs: list[Message] = [
            {"role": "user", "content": "abcd"},      # 4 // 4 = 1
            {"role": "assistant", "content": "efghij"},  # 6 // 4 = 1
        ]
        assert mem._estimate_tokens(msgs) == 2


class TestThreadMemoryTruncation:
    """Tests for ThreadMemory truncation when exceeding token limit."""

    @pytest.mark.asyncio
    async def test_no_truncation_under_limit(self):
        """Messages are preserved when under the token limit."""
        mem = ThreadMemory(max_tokens=100)
        msgs: list[Message] = [{"role": "user", "content": "short"}]
        await mem.add_messages("t1", msgs)
        result = await mem.get_messages("t1")
        assert result == msgs

    @pytest.mark.asyncio
    async def test_truncation_removes_oldest_messages(self):
        """Oldest messages are removed when token limit is exceeded."""
        # max_tokens=2 means roughly 8 chars of content allowed
        mem = ThreadMemory(max_tokens=2)
        await mem.add_messages("t1", [
            {"role": "user", "content": "aaaaaaaa"},       # 8 // 4 = 2
            {"role": "assistant", "content": "bbbbbbbb"},   # 8 // 4 = 2
            {"role": "user", "content": "cccc"},            # 4 // 4 = 1
        ])
        result = await mem.get_messages("t1")
        # Only the last message (1 token) should remain
        assert len(result) == 1
        assert result[0]["content"] == "cccc"

    @pytest.mark.asyncio
    async def test_truncation_emits_warning(self):
        """ContextTruncationWarning is emitted when truncation occurs."""
        mem = ThreadMemory(max_tokens=1)
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            await mem.add_messages("t1", [
                {"role": "user", "content": "aaaa"},       # 1 token
                {"role": "assistant", "content": "bbbb"},  # 1 token -> over limit
            ])
        truncation_warnings = [
            w for w in caught if issubclass(w.category, ContextTruncationWarning)
        ]
        assert len(truncation_warnings) == 1
        assert "t1" in str(truncation_warnings[0].message)
        assert "truncated" in str(truncation_warnings[0].message).lower()

    @pytest.mark.asyncio
    async def test_no_warning_when_under_limit(self):
        """No warning is emitted when messages fit within the limit."""
        mem = ThreadMemory(max_tokens=1000)
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            await mem.add_messages("t1", [{"role": "user", "content": "hi"}])
        truncation_warnings = [
            w for w in caught if issubclass(w.category, ContextTruncationWarning)
        ]
        assert len(truncation_warnings) == 0

    @pytest.mark.asyncio
    async def test_truncation_keeps_at_least_one_message(self):
        """Even if a single message exceeds the limit, it is kept."""
        mem = ThreadMemory(max_tokens=1)
        # Single message with 20 chars -> 5 tokens, exceeds limit of 1
        await mem.add_messages("t1", [
            {"role": "user", "content": "a]" * 10},
        ])
        result = await mem.get_messages("t1")
        assert len(result) == 1

    @pytest.mark.asyncio
    async def test_truncation_across_multiple_adds(self):
        """Truncation triggers correctly across successive add_messages calls."""
        mem = ThreadMemory(max_tokens=2)
        await mem.add_messages("t1", [{"role": "user", "content": "aaaaaaaa"}])  # 2 tokens
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            await mem.add_messages("t1", [{"role": "assistant", "content": "bbbb"}])  # +1 = 3 tokens
        truncation_warnings = [
            w for w in caught if issubclass(w.category, ContextTruncationWarning)
        ]
        assert len(truncation_warnings) == 1
        result = await mem.get_messages("t1")
        # Should have truncated the first message
        assert len(result) == 1
        assert result[0]["content"] == "bbbb"


class TestThreadMemoryMaxTokensConfig:
    """Tests for ThreadMemory max_tokens configuration."""

    def test_default_max_tokens(self):
        """Default max_tokens is 100_000."""
        mem = ThreadMemory()
        assert mem._max_tokens == 100_000

    def test_custom_max_tokens(self):
        """Custom max_tokens is stored correctly."""
        mem = ThreadMemory(max_tokens=500)
        assert mem._max_tokens == 500

    def test_factory_forwards_max_tokens(self):
        """Memory.thread(max_tokens=...) forwards to ThreadMemory."""
        mem = Memory.thread(max_tokens=42)
        assert isinstance(mem, ThreadMemory)
        assert mem._max_tokens == 42

# ---------------------------------------------------------------------------
# SemanticMemory tests
# ---------------------------------------------------------------------------


def _char_freq_embedder(text: str) -> list[float]:
    """Simple character-frequency embedder for testing.

    Produces a 26-dimensional vector where each element is the count of
    the corresponding lowercase letter (a-z) in the text.
    """
    vec = [0.0] * 26
    for ch in text.lower():
        idx = ord(ch) - ord("a")
        if 0 <= idx < 26:
            vec[idx] += 1.0
    return vec


class TestSemanticMemoryCreation:
    """Tests for SemanticMemory instantiation."""

    def test_create_with_embedder(self):
        """SemanticMemory can be created with an embedder callable."""
        mem = SemanticMemory(embedder=_char_freq_embedder)
        assert mem._embedder is _char_freq_embedder
        assert mem._top_k == 10

    def test_create_with_custom_top_k(self):
        """SemanticMemory accepts a custom top_k."""
        mem = SemanticMemory(embedder=_char_freq_embedder, top_k=5)
        assert mem._top_k == 5

    def test_factory_returns_semantic_memory(self):
        """Memory.semantic() returns a SemanticMemory instance."""
        mem = Memory.semantic(embedder=_char_freq_embedder)
        assert isinstance(mem, SemanticMemory)


class TestSemanticMemoryStorage:
    """Tests for SemanticMemory add_messages and get_messages."""

    @pytest.mark.asyncio
    async def test_empty_thread_returns_empty_list(self):
        """get_messages on a non-existent thread returns []."""
        mem = SemanticMemory(embedder=_char_freq_embedder)
        result = await mem.get_messages("t1")
        assert result == []

    @pytest.mark.asyncio
    async def test_add_and_get_messages(self):
        """add_messages stores messages retrievable by get_messages."""
        mem = SemanticMemory(embedder=_char_freq_embedder)
        msgs: list[Message] = [
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "hi there"},
        ]
        await mem.add_messages("t1", msgs)
        result = await mem.get_messages("t1")
        assert len(result) == 2
        assert result[0]["content"] == "hello"
        assert result[1]["content"] == "hi there"

    @pytest.mark.asyncio
    async def test_messages_isolated_by_thread(self):
        """Messages in different threads are isolated."""
        mem = SemanticMemory(embedder=_char_freq_embedder)
        await mem.add_messages("t1", [{"role": "user", "content": "alpha"}])
        await mem.add_messages("t2", [{"role": "user", "content": "beta"}])
        assert len(await mem.get_messages("t1")) == 1
        assert len(await mem.get_messages("t2")) == 1
        assert (await mem.get_messages("t1"))[0]["content"] == "alpha"

    @pytest.mark.asyncio
    async def test_add_messages_appends(self):
        """Successive add_messages calls append to the same thread."""
        mem = SemanticMemory(embedder=_char_freq_embedder)
        await mem.add_messages("t1", [{"role": "user", "content": "first"}])
        await mem.add_messages("t1", [{"role": "user", "content": "second"}])
        result = await mem.get_messages("t1")
        assert len(result) == 2


class TestSemanticMemorySearch:
    """Tests for SemanticMemory.search cosine similarity retrieval."""

    @pytest.mark.asyncio
    async def test_search_empty_thread_returns_empty(self):
        """search on a non-existent thread returns []."""
        mem = SemanticMemory(embedder=_char_freq_embedder)
        result = await mem.search("t1", "anything")
        assert result == []

    @pytest.mark.asyncio
    async def test_search_returns_most_relevant(self):
        """search returns messages ordered by similarity to the query."""
        mem = SemanticMemory(embedder=_char_freq_embedder, top_k=2)
        await mem.add_messages("t1", [
            {"role": "user", "content": "aaa"},       # heavy on 'a'
            {"role": "user", "content": "bbb"},       # heavy on 'b'
            {"role": "user", "content": "aaab"},      # mostly 'a'
        ])
        # Query with 'a' — should rank 'aaa' and 'aaab' highest
        results = await mem.search("t1", "aaa", top_k=2)
        contents = [m["content"] for m in results]
        assert "aaa" in contents
        assert "aaab" in contents

    @pytest.mark.asyncio
    async def test_search_respects_top_k(self):
        """search returns at most top_k results."""
        mem = SemanticMemory(embedder=_char_freq_embedder, top_k=1)
        await mem.add_messages("t1", [
            {"role": "user", "content": "aaa"},
            {"role": "user", "content": "bbb"},
            {"role": "user", "content": "ccc"},
        ])
        results = await mem.search("t1", "aaa")
        assert len(results) == 1

    @pytest.mark.asyncio
    async def test_search_top_k_override(self):
        """top_k parameter in search overrides the instance default."""
        mem = SemanticMemory(embedder=_char_freq_embedder, top_k=1)
        await mem.add_messages("t1", [
            {"role": "user", "content": "aaa"},
            {"role": "user", "content": "bbb"},
        ])
        results = await mem.search("t1", "aaa", top_k=2)
        assert len(results) == 2

    @pytest.mark.asyncio
    async def test_search_uses_instance_top_k_when_none(self):
        """search uses instance top_k when top_k arg is None."""
        mem = SemanticMemory(embedder=_char_freq_embedder, top_k=2)
        await mem.add_messages("t1", [
            {"role": "user", "content": "aaa"},
            {"role": "user", "content": "bbb"},
            {"role": "user", "content": "ccc"},
        ])
        results = await mem.search("t1", "aaa", top_k=None)
        assert len(results) == 2


class TestCosineSimlarity:
    """Tests for SemanticMemory._cosine_similarity static method."""

    def test_identical_vectors(self):
        """Identical vectors have similarity 1.0."""
        sim = SemanticMemory._cosine_similarity([1.0, 0.0], [1.0, 0.0])
        assert abs(sim - 1.0) < 1e-9

    def test_orthogonal_vectors(self):
        """Orthogonal vectors have similarity 0.0."""
        sim = SemanticMemory._cosine_similarity([1.0, 0.0], [0.0, 1.0])
        assert abs(sim) < 1e-9

    def test_opposite_vectors(self):
        """Opposite vectors have similarity -1.0."""
        sim = SemanticMemory._cosine_similarity([1.0, 0.0], [-1.0, 0.0])
        assert abs(sim - (-1.0)) < 1e-9

    def test_zero_vector_returns_zero(self):
        """Zero vector produces similarity 0.0."""
        sim = SemanticMemory._cosine_similarity([0.0, 0.0], [1.0, 2.0])
        assert sim == 0.0

    def test_both_zero_vectors_returns_zero(self):
        """Two zero vectors produce similarity 0.0."""
        sim = SemanticMemory._cosine_similarity([0.0, 0.0], [0.0, 0.0])
        assert sim == 0.0
