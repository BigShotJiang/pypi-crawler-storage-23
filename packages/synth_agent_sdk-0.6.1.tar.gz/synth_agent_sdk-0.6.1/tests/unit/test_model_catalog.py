"""Unit tests for ``synth.deploy.agentcore.model_catalog``.

Covers ``ModelCatalog`` contents and ``RegionValidator`` filtering,
CRIS detection, and effective model ID resolution.
"""

from __future__ import annotations

import pytest

from synth.deploy.agentcore.model_catalog import ModelCatalog, RegionValidator


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def catalog() -> ModelCatalog:
    return ModelCatalog()


@pytest.fixture()
def validator(catalog: ModelCatalog) -> RegionValidator:
    return RegionValidator(catalog)


# ---------------------------------------------------------------------------
# ModelCatalog — required models
# ---------------------------------------------------------------------------


class TestModelCatalog:
    """Verify the catalog contains all required models (Requirement 4.5)."""

    _REQUIRED_DISPLAY_KEYWORDS = [
        "haiku",
        "3.5 sonnet",
        "3.7 sonnet",
        "sonnet 4",
        "opus 4",
        "nova micro",
        "nova lite",
        "nova pro",
    ]

    def test_at_least_eight_models(self, catalog: ModelCatalog) -> None:
        assert len(catalog.MODELS) >= 8

    @pytest.mark.parametrize("keyword", _REQUIRED_DISPLAY_KEYWORDS)
    def test_required_model_present(
        self, catalog: ModelCatalog, keyword: str
    ) -> None:
        """Each required model family appears in the catalog display names."""
        names = [e.display_name.lower() for e in catalog.MODELS]
        assert any(keyword in n for n in names), (
            f"No model with '{keyword}' in display_name found in catalog"
        )

    def test_all_entries_have_model_id(self, catalog: ModelCatalog) -> None:
        for entry in catalog.MODELS:
            assert entry.model_id, f"Empty model_id for {entry.display_name}"

    def test_all_entries_have_cris_profile_id(self, catalog: ModelCatalog) -> None:
        for entry in catalog.MODELS:
            assert entry.cris_profile_id, (
                f"Empty cris_profile_id for {entry.model_id}"
            )

    def test_no_duplicate_model_ids(self, catalog: ModelCatalog) -> None:
        ids = [e.model_id for e in catalog.MODELS]
        assert len(ids) == len(set(ids)), "Duplicate model_id entries found"


# ---------------------------------------------------------------------------
# RegionValidator — models_for_region
# ---------------------------------------------------------------------------


class TestModelsForRegion:
    """Tests for ``RegionValidator.models_for_region``."""

    def test_known_region_returns_subset(self, validator: RegionValidator) -> None:
        """A known region returns only models available there."""
        models = validator.models_for_region("us-east-1")
        assert len(models) > 0

    def test_known_region_all_models_available(
        self, validator: RegionValidator, catalog: ModelCatalog
    ) -> None:
        """Every returned model is actually available in the region."""
        region = "us-east-1"
        for entry in validator.models_for_region(region):
            assert region in entry.native_regions or region in entry.cris_regions

    def test_unknown_region_returns_all_models(
        self, validator: RegionValidator, catalog: ModelCatalog
    ) -> None:
        """An unknown region returns all models as fallback (Requirement 4.8)."""
        models = validator.models_for_region("xx-unknown-9")
        assert len(models) == len(catalog.MODELS)

    def test_unknown_region_sets_availability_unknown(
        self, validator: RegionValidator
    ) -> None:
        assert validator.availability_unknown_for_region("xx-unknown-9") is True

    def test_known_region_availability_not_unknown(
        self, validator: RegionValidator
    ) -> None:
        assert validator.availability_unknown_for_region("us-east-1") is False

    def test_cris_only_region_returns_cris_models(
        self, validator: RegionValidator
    ) -> None:
        """A CRIS-only region (eu-central-1) returns models via CRIS."""
        models = validator.models_for_region("eu-central-1")
        assert len(models) > 0
        for entry in models:
            assert (
                "eu-central-1" in entry.native_regions
                or "eu-central-1" in entry.cris_regions
            )


# ---------------------------------------------------------------------------
# RegionValidator — requires_cris
# ---------------------------------------------------------------------------


class TestRequiresCris:
    """Tests for ``RegionValidator.requires_cris``."""

    def test_native_region_does_not_require_cris(
        self, validator: RegionValidator, catalog: ModelCatalog
    ) -> None:
        entry = catalog.MODELS[0]
        native = entry.native_regions[0]
        assert validator.requires_cris(entry.model_id, native) is False

    def test_cris_region_requires_cris(
        self, validator: RegionValidator, catalog: ModelCatalog
    ) -> None:
        entry = catalog.MODELS[0]
        if not entry.cris_regions:
            pytest.skip("No CRIS regions for first model")
        cris_region = entry.cris_regions[0]
        assert validator.requires_cris(entry.model_id, cris_region) is True

    def test_unknown_model_does_not_require_cris(
        self, validator: RegionValidator
    ) -> None:
        assert validator.requires_cris("unknown.model-id", "us-east-1") is False

    def test_unknown_region_does_not_require_cris(
        self, validator: RegionValidator, catalog: ModelCatalog
    ) -> None:
        """A region not in native or CRIS lists returns False."""
        entry = catalog.MODELS[0]
        assert validator.requires_cris(entry.model_id, "xx-unknown-9") is False


# ---------------------------------------------------------------------------
# RegionValidator — effective_model_id
# ---------------------------------------------------------------------------


class TestEffectiveModelId:
    """Tests for ``RegionValidator.effective_model_id``."""

    def test_native_region_returns_base_id(
        self, validator: RegionValidator, catalog: ModelCatalog
    ) -> None:
        entry = catalog.MODELS[0]
        native = entry.native_regions[0]
        assert validator.effective_model_id(entry.model_id, native) == entry.model_id

    def test_cris_region_returns_cris_profile_id(
        self, validator: RegionValidator, catalog: ModelCatalog
    ) -> None:
        entry = catalog.MODELS[0]
        if not entry.cris_regions:
            pytest.skip("No CRIS regions for first model")
        cris_region = entry.cris_regions[0]
        result = validator.effective_model_id(entry.model_id, cris_region)
        assert result == entry.cris_profile_id

    def test_unknown_model_returns_input_unchanged(
        self, validator: RegionValidator
    ) -> None:
        result = validator.effective_model_id("unknown.model", "us-east-1")
        assert result == "unknown.model"

    def test_cris_profile_differs_from_base_id(
        self, validator: RegionValidator, catalog: ModelCatalog
    ) -> None:
        """Sanity check: CRIS profile IDs are distinct from base IDs."""
        for entry in catalog.MODELS:
            if entry.cris_regions:
                cris_region = entry.cris_regions[0]
                effective = validator.effective_model_id(entry.model_id, cris_region)
                assert effective != entry.model_id
