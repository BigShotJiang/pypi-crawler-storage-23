"""Tests for ``synth.cli.create_cmd`` — project creation command."""
