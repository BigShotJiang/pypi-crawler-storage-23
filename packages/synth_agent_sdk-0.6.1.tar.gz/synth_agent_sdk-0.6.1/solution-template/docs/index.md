<!-- This file is only used for the mkdocs documentation hosting webpage -->

# Fullstack AgentCore Solution Template Documentation

Welcome to the Fullstack AgentCore Solution Template (FAST) documentation!

Have a look at the navigation bar on the left hand side of your browser to read through the actual documentation!

_This index.md file exists only because is required for mkdocs to generate an index.html for documentation pages._