# Standard library imports
from __future__ import annotations
from abc import abstractmethod

# Third party imports
import opengeode as og

# Local application imports
from .geode_mesh import GeodeMesh
from .types import ViewerElementsType


class GeodeGrid3D(GeodeMesh):
    @classmethod
    def is_3D(cls) -> bool:
        return True

    @classmethod
    def is_viewable(cls) -> bool:
        return True

    @classmethod
    def viewer_elements_type(cls) -> ViewerElementsType:
        return "polyhedra"

    def builder(self) -> object:
        return None

    def inspect(self) -> object:
        return None

    @abstractmethod
    def cell_attribute_manager(self) -> og.AttributeManager: ...
