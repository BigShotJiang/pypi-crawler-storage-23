![Atscale Logo](https://www.atscale.com/wp-content/uploads/2021/12/AtScale_Logo_RGB_2C.svg)

## Welcome to AI-Link, the programmatic interface to the AtScale Semantic Layer 

To install the package, use the following command:
```
pip install atscale
```

Please find our full documentation here: [AI-Link Documentation](https://documentation.atscale.com/ailink-container/)

If you have any questions or concerns with the codebase, please email: **ailink@atscale.com**
