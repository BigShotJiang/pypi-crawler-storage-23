
from setuptools import setup, find_packages
from torch.utils.cpp_extension import BuildExtension, CUDAExtension
import os

setup(
    name='sylvica',
    version='1.0.1',
    description='Sylvester Vector Inference Core Accelerator (SYLVICA)',
    long_description='A Pure C++ CUDA implementation of Matrix Multiplication using Sylvester Isotropic Diagonal Topology. Supports FP16, Rectangular Matrices, and Batched 3D Tensors.',
    long_description_content_type='text/markdown',
    author='Zero-Class Mathematical Architect',
    packages=find_packages(),
    ext_modules=[
        CUDAExtension(
            name='sylvica._C',
            sources=[os.path.join('csrc', 'interface.cpp'), os.path.join('csrc', 'sidrc_kernel.cu')],
            extra_compile_args={'cxx': ['-O3'], 'nvcc': ['-O3', '--use_fast_math', '-maxrregcount=128']}
        )
    ],
    cmdclass={'build_ext': BuildExtension},
    install_requires=['torch'],
)
