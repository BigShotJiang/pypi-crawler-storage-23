# mini_vision

Simple Python library for **object segmentation in video streams** using YOLO models.

The goal of this library is to provide a modular pipeline to:

- consume video streams
- perform object segmentation
- render contours or masks

The library follows **data-oriented design** and **low coupling principles**, allowing easy replacement of computer vision models.

---

## Installation

```
pip install mini-vision
```

## Usage

Example showing how to use vision-seg to consume a video stream, run YOLO segmentation, and render object contours.

### Import the library

```
from vision_seg import (
    YoloSegmenter,
    SegmentationRenderer,
    WSFrameClient
)
```

### Components:

| Component              | Description                                              |
| ---------------------- | -------------------------------------------------------- |
| `YoloSegmenter`        | Runs object segmentation using a YOLO segmentation model |
| `SegmentationRenderer` | Draws segmentation contours on the frame                 |
| `WSFrameClient`        | Connects to a WebSocket video stream and yields frames   |


#### YoloSegmenter

Runs object segmentation using a YOLO segmentation model.

```
segmenter = YoloSegmenter("yolov8n-seg.pt")
detections = segmenter.segment(frame)
```

#### SegmentationRenderer

Responsible for rendering segmentation contours on frames.

````
renderer = SegmentationRenderer()
frame = renderer.draw_contours(frame, detections)
````

#### WSFrameClient

Connects to a WebSocket video stream and yields frames.

```
client = WSFrameClient("ws://127.0.0.1:8000/ws/frames")
async for frame in client.frames():
```
