#import pytest
import jsondiff as jd
from imlresi import trace


# test format identification
def test_identify_format():
    assert trace.identify_format('tests/data/1-131-withfeed-json.rgp') == 'json'
    assert trace.identify_format('tests/data/1-131-withfeed.rgp') == 'bin'
    assert trace.identify_format('tests/data/1-131-withfeed-txt1.txt') == 'txt1'
    assert trace.identify_format('tests/data/1-131-withfeed-txt2.txt') == 'txt2'
    assert trace.identify_format('tests/data/2-178-withfeed.pdc') == 'pdc'


# test individual format trace parsers
def test_read_xxx():
    # compare the dicts returned by each of the different read formats
    bin = trace.read_bin('tests/data/1-131-withfeed.rgp')
    bin.pop('raw')
    bin['settings'].pop('preselected_depth')

    txt1 = trace.read_txt1('tests/data/1-131-withfeed-txt1.txt')
    txt1.pop('raw')
    txt1['settings'].pop('preselected_depth')

    txt2 = trace.read_txt2('tests/data/1-131-withfeed-txt2.txt')
    txt2.pop('raw')
    txt2['settings'].pop('preselected_depth')

    jsn = trace.read_json('tests/data/1-131-withfeed-json.rgp')
    jsn.pop('raw')
    [jsn['settings'].pop(e) for e in (
        'deviceLength',
        'depthMode',
        'abortState',
        'feedOn',
        'ncOn',
        'ncState',
        'tiltOn',
        'tiltRelOn',
        'tiltRelAngle',
        'tiltAngle',
        'diameter',
        'preselected_depth',
    )]

    assert bin == txt1, f".rgp BIN and .txt TXT1 differ: {jd.diff(bin, txt1, syntax='symmetric')}"
    assert bin == txt2, f".rgp BIN and .txt TXT2 differ: {jd.diff(bin, txt2, syntax='symmetric')}"
    assert bin == jsn, f".rgp BIN and .rgp JSON differ: {jd.diff(bin, jsn, syntax='symmetric')}"

    # todo: add .pdc format to the comparisons





# test the Trace class
def test_Trace():
    tr = trace.Trace()
    trfns = [
        'tests/data/1-131-withfeed-json.rgp',
        'tests/data/1-131-withfeed.rgp',
        'tests/data/1-131-withfeed-txt1.txt',
        'tests/data/1-131-withfeed-txt2.txt',
        'tests/data/2-178-withfeed.pdc',
        'tests/data/1-131-withfeed-pdtools122.rgp',
        'tests/data/1-131-withfeed-pdtools167.rgp',
        'tests/data/3-131-nofeed.rgp',
        'tests/data/4-131-withfeed.rgp',
        'tests/data/5-132-withfeed.rgp',
    ]
    resiIds = [
        'some-identifier',
        'some-identifier',
        'some-identifier',
        'some-identifier',
        'TEST 7',
        'some-identifier',
        'some-identifier',
        'FR121-10-3-24',
        'T01',
        'HVP*6*15',
    ]
    locations = [
        "some-location",
        "some-location",
        "some-location",
        "some-location",
        "26.06952° S, 152.77024° E (± 4.69584 m)",
        "some-location",
        "some-location",
        "",
        "",
        "",
    ]
    hashes = [
        '6b46a40e7b8cee4dc1ebb18516241ca4',
        'f97b94fbd23d45dd22a2b799c0ff68ec',
        'f97b94fbd23d45dd22a2b799c0ff68ec',
        'f97b94fbd23d45dd22a2b799c0ff68ec',
        'a07a37875ff4d4a8881b98d386a33be8',
        'f97b94fbd23d45dd22a2b799c0ff68ec',
        '6b46a40e7b8cee4dc1ebb18516241ca4',
        '131800c773d850cec80b458690a73a87',
        'b382e6e89a721a0f08110d501de1d6bb',
        'c620d76d30b1862599ff3c66a0cd61eb',
    ]
    for trfn, resiId, hash, loc in zip(trfns, resiIds, hashes, locations):
        print(trfn)
        tr.read(trfn)
        assert tr.get_resiId() == resiId
        #assert tr.hash() == hash
        assert tr.header['location']==loc


def test_accessors():
    from datetime import datetime
    tr = trace.Trace()
    tr.read('tests/data/2-178-withfeed.pdc')
    assert tr.get_resiId() == 'TEST 7'
    assert tr.get_drilltime().strftime('%Y%m%dT%H:%M:%S') == '20210330T15:20:05'
    assert tr.get_location() == '26.06952° S, 152.77024° E (± 4.69584 m)'
    assert tr.get_latlon() == (-26.06952, 152.77024, 4.69584)
    assert tr,get_tilt() == 88.8
    assert tr.get_comment() == "00-0-00-01"
    assert tr.get_remark() == "00-0-00-01"
    assert tr.get_instrument() == "PD500-0755"
    assert tr.get_feedspeed() == 200
    assert tr.get_rpm() == 3500
    assert tr.get_measnumber() == 41

    #tr.read('tests/data/1-131-')


# todo: test Trace.__str__()


# todo: test Trace.__repr__()


# todo: test Trace.to_json()
