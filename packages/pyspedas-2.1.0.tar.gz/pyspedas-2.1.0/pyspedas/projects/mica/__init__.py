from .load import load

# Define an alias to the load function
induction = load
