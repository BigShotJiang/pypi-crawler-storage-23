"""Version information for sage-eval."""

__version__ = "0.1.0.2"
__author__ = "IntelliStream Team"
__email__ = "shuhao_zhang@hust.edu.cn"
