"""End-to-end integration tests – Dotprompt render → OpenAI adapter generate.

Covers:
- Basic adapter.generate() with config overrides
- Full Dotprompt → render → generate pipeline
- Multi-turn conversation
- Tool calling (function calling)
- Structured JSON schema output
- Image input (vision)
- Batch execution via run()
- Output format validation (PromptOutputConfig)
- {{SCHEMA}} auto-variable injection
- Dynamic model name via frontmatter variables
- Picoschema → JSON output pipeline
- run() convenience function for single and batch execution
"""

import json
import logging

import jsonschema
import pytest

from dotpromptz.runner import run
from dotpromptz.typing import (
    DataArgument,
    MediaContent,
    MediaPart,
    Message,
    PromptOutputConfig,
    RenderedPrompt,
    Role,
    TextPart,
    ToolDefinition,
)

logger = logging.getLogger(__name__)

pytestmark = pytest.mark.integration

MODEL = 'gpt-4.1'


# ---------------------------------------------------------------------------
# Test A – adapter.generate() with richer config
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_adapter_generate_with_temperature(openai_adapter) -> None:
    """Call generate() with explicit temperature / max_tokens."""
    rendered = RenderedPrompt(
        config={'model': MODEL, 'temperature': 0.0, 'max_tokens': 30},
        messages=[
            Message(role=Role.SYSTEM, content=[TextPart(text='You are a concise assistant.')]),
            Message(role=Role.USER, content=[TextPart(text='What is 2 + 2?')]),
        ],
    )

    response = await openai_adapter.generate(rendered)

    assert response.text is not None
    assert '4' in response.text
    assert response.model is not None
    assert response.usage is not None
    assert response.usage.prompt_tokens > 0
    assert response.usage.completion_tokens > 0
    logger.info('[e2e] model=%s  text=%r', response.model, response.text)


# ---------------------------------------------------------------------------
# Test B – full Dotprompt → render → generate pipeline
# ---------------------------------------------------------------------------

_PROMPT_SOURCE = """\
---
model: gpt-4.1
config:
  temperature: 0
---
{{role "system"}}
You are a geography expert. Answer in one sentence.
{{role "user"}}
What is the capital of {{country}}?
"""


@pytest.mark.asyncio
async def test_dotprompt_render_then_generate(dotprompt_instance, openai_adapter) -> None:
    """Render a .prompt template and send it through the OpenAI adapter."""
    rendered = dotprompt_instance.render(
        _PROMPT_SOURCE,
        data=DataArgument(input={'country': 'France'}),
    )

    # Verify rendering produced the expected messages
    assert len(rendered.messages) >= 2
    assert rendered.messages[0].role == Role.SYSTEM
    assert rendered.messages[-1].role == Role.USER

    # Call the real API
    response = await openai_adapter.generate(rendered)

    assert response.text is not None
    assert 'paris' in response.text.lower()
    logger.info('[e2e] rendered → response: %r', response.text)


# ---------------------------------------------------------------------------
# Test C – multi-turn conversation
# ---------------------------------------------------------------------------

_MULTITURN_SOURCE = """\
---
model: gpt-4.1
config:
  temperature: 0
---
{{role "system"}}
You are a math tutor. Be concise.
{{role "user"}}
What is 10 * 5?
{{role "model"}}
50
{{role "user"}}
Now divide that by 2.
"""


@pytest.mark.asyncio
async def test_multiturn_conversation(dotprompt_instance, openai_adapter) -> None:
    """Render a multi-turn prompt and verify the model follows context."""
    rendered = dotprompt_instance.render(
        _MULTITURN_SOURCE,
        data=DataArgument(),
    )

    # Should have system + user + assistant + user = 4 messages
    assert len(rendered.messages) >= 4

    response = await openai_adapter.generate(rendered)

    assert response.text is not None
    assert '25' in response.text
    logger.info('[e2e] multi-turn response: %r', response.text)


# ---------------------------------------------------------------------------
# Test D – tool calling (function calling)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tool_calling(openai_adapter) -> None:
    """Verify the model returns a tool call when tools are provided."""
    rendered = RenderedPrompt(
        config={'model': MODEL, 'temperature': 0},
        messages=[
            Message(
                role=Role.SYSTEM,
                content=[TextPart(text='You are a helpful assistant. Use the provided tools when appropriate.')],
            ),
            Message(
                role=Role.USER,
                content=[TextPart(text='What is the weather in Tokyo right now?')],
            ),
        ],
        tool_defs=[
            ToolDefinition(
                name='get_weather',
                description='Get the current weather for a city.',
                input_schema={
                    'type': 'object',
                    'properties': {
                        'city': {'type': 'string', 'description': 'The city name'},
                    },
                    'required': ['city'],
                },
            ),
        ],
    )

    response = await openai_adapter.generate(rendered)

    # The model should request the get_weather tool
    assert len(response.tool_calls) > 0
    tc = response.tool_calls[0]
    assert tc.name == 'get_weather'
    assert 'tokyo' in tc.arguments.get('city', '').lower()
    assert response.finish_reason == 'tool_calls'
    logger.info('[e2e] tool_call: %s(%s)', tc.name, tc.arguments)


# ---------------------------------------------------------------------------
# Test E – structured JSON schema output
# ---------------------------------------------------------------------------

# A strict schema with enum constraint to prove enforcement, not guessing.
_PERSON_SCHEMA = {
    'type': 'object',
    'properties': {
        'name': {'type': 'string'},
        'age': {'type': 'integer'},
        'favorite_color': {'type': 'string', 'enum': ['red', 'green', 'blue']},
    },
    'required': ['name', 'age', 'favorite_color'],
    'additionalProperties': False,
}


@pytest.mark.asyncio
async def test_structured_json_schema_output(openai_adapter) -> None:
    """Verify the model response conforms to a strict JSON schema.

    Uses additionalProperties=false and an enum constraint so that
    schema enforcement (not model luck) guarantees conformance.
    """
    rendered = RenderedPrompt(
        config={'model': MODEL, 'temperature': 0},
        messages=[
            Message(
                role=Role.SYSTEM,
                content=[TextPart(text='You are a data extraction assistant. Return ONLY valid JSON.')],
            ),
            Message(
                role=Role.USER,
                content=[TextPart(text=('Extract person info: Alice is 30 years old and her favorite color is blue.'))],
            ),
        ],
        output=PromptOutputConfig(format='json', schema=_PERSON_SCHEMA, file_name='output'),
    )

    response = await openai_adapter.generate(rendered)

    assert response.text is not None
    data = json.loads(response.text)

    # Validate against the JSON schema – this would fail if the provider
    # didn't enforce the schema and the model added extra fields or used
    # wrong types.
    jsonschema.validate(instance=data, schema=_PERSON_SCHEMA)

    # Verify concrete values
    assert data['name'] == 'Alice'
    assert isinstance(data['age'], int)
    assert data['age'] == 30
    assert data['favorite_color'] in ('red', 'green', 'blue')
    assert data['favorite_color'] == 'blue'

    # No extra keys (additionalProperties=false enforced by provider)
    assert set(data.keys()) == {'name', 'age', 'favorite_color'}
    logger.info('[e2e] structured output: %s', data)


# ---------------------------------------------------------------------------
# Test F – image input (vision)
# ---------------------------------------------------------------------------

# 100x100 solid-red PNG (334 bytes) as base64.
_RED_PNG_B64 = 'iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAABFUlEQVR4nO3OUQkAIABEsetfWiv4Nx4IC7Cd7XvkByF+EOIHIX4Q4gchfhDiByF+EOIHIX4Q4gchfhDiByF+EOIHIX4Q4gchfhDiByF+EOIHIX4Q4gchfhDiByF+EOIHIX4Q4gchfhDiByF+EOIHIX4Q4gchfhDiByF+EOIHIX4Q4gchfhDiByF+EOIHIX4Q4gchfhDiByF+EOIHIX4Q4gchfhDiByF+EOIHIX4Q4gchfhDiByF+EOIHIX4Q4gchfhDiByF+EOIHIX4Q4gchfhDiByF+EOIHIX4Q4gchfhDiByF+EOIHIX4Q4gchfhDiByF+EOIHIX4Q4gchfhDiByF+EOIHIX4Q4gchfhDiByF+EOIHIReeLesrH9s1agAAAABJRU5ErkJggg=='


@pytest.mark.asyncio
async def test_image_input_vision(openai_adapter) -> None:
    """Send an image via MediaPart and verify the model describes it."""
    rendered = RenderedPrompt(
        config={'model': MODEL, 'temperature': 0, 'max_tokens': 60},
        messages=[
            Message(
                role=Role.SYSTEM,
                content=[TextPart(text='You are a concise assistant. Describe images in one short sentence.')],
            ),
            Message(
                role=Role.USER,
                content=[
                    MediaPart(
                        media=MediaContent(
                            url=f'data:image/png;base64,{_RED_PNG_B64}',
                            content_type='image/png',
                        ),
                    ),
                    TextPart(text='What color is this image? Answer with just the color name.'),
                ],
            ),
        ],
    )

    response = await openai_adapter.generate(rendered)

    assert response.text is not None
    assert len(response.text.strip()) > 0
    assert response.usage is not None
    assert response.usage.prompt_tokens > 0
    logger.info('[e2e] image input response: %r', response.text)


# ===========================================================================
# NEW TESTS: batch run, output, @{{schema}}, model name, etc.
# ===========================================================================


# ---------------------------------------------------------------------------
# Test G – run() single item
# ---------------------------------------------------------------------------

_RUN_SINGLE_SOURCE = """\
---
model: gpt-4.1
config:
  temperature: 0
  max_tokens: 20
---
{{role "user"}}
What is 3 + 7? Reply with just the number.
"""


@pytest.mark.asyncio
async def test_run_single(openai_adapter) -> None:
    """Verify run() with a single input renders and generates correctly."""
    results = await run(
        _RUN_SINGLE_SOURCE,
        [{}],
        openai_adapter,
    )

    assert len(results) == 1
    assert results[0].status == 'success'
    assert results[0].response is not None
    assert results[0].response.text is not None
    assert '10' in results[0].response.text
    assert results[0].response.usage is not None
    logger.info('[e2e] run single response: %r', results[0].response.text)


# ---------------------------------------------------------------------------
# Test H – run() with multiple inputs
# ---------------------------------------------------------------------------

_BATCH_SOURCE = """\
---
model: gpt-4.1
config:
  temperature: 0
  max_tokens: 30
---
{{role "user"}}
What is the capital of {{country}}? Answer in one word.
"""


@pytest.mark.asyncio
async def test_run_batch(openai_adapter) -> None:
    """Verify run() executes multiple prompts with concurrency control."""
    inputs = [
        {'country': 'Japan'},
        {'country': 'Germany'},
        {'country': 'Brazil'},
    ]

    results = await run(
        _BATCH_SOURCE,
        inputs,
        openai_adapter,
        max_workers=3,
    )

    assert len(results) == 3
    # Results are sorted by index
    assert [r.index for r in results] == [0, 1, 2]

    for r in results:
        assert r.status == 'success', f'Batch item {r.index} failed: {r.error}'
        assert r.response is not None
        assert r.response.text is not None
        assert r.elapsed > 0
        assert r.attempts == 1  # No retries expected
        logger.info('[e2e] batch[%d] country=%s → %r', r.index, r.input['country'], r.response.text)

    # Verify content correctness
    assert 'tokyo' in results[0].response.text.lower()
    assert 'berlin' in results[1].response.text.lower()
    assert 'bras' in results[2].response.text.lower()  # Brasília / Brasilia


# ---------------------------------------------------------------------------
# Test I – run() with on_item_complete callback
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_run_batch_with_callback(openai_adapter) -> None:
    """Verify on_item_complete callback is invoked for each batch item."""
    completed_indices: list[int] = []

    def on_complete(result) -> None:
        completed_indices.append(result.index)

    inputs = [
        {'country': 'France'},
        {'country': 'Italy'},
    ]

    results = await run(
        _BATCH_SOURCE,
        inputs,
        openai_adapter,
        max_workers=2,
        on_item_complete=on_complete,
    )

    assert len(results) == 2
    assert all(r.status == 'success' for r in results)
    # Callback was invoked for each item (order may vary due to concurrency)
    assert sorted(completed_indices) == [0, 1]
    logger.info('[e2e] batch callback indices: %s', completed_indices)


# ---------------------------------------------------------------------------
# Test J – output config: JSON format without schema
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_output_json_format_no_schema(openai_adapter) -> None:
    """Verify output.format='json' without schema returns valid JSON."""
    rendered = RenderedPrompt(
        config={'model': MODEL, 'temperature': 0, 'max_tokens': 100},
        messages=[
            Message(
                role=Role.SYSTEM,
                content=[TextPart(text='You are a helpful assistant. Always respond in valid JSON.')],
            ),
            Message(
                role=Role.USER,
                content=[TextPart(text='List the 3 primary colors as a JSON array with key "colors".')],
            ),
        ],
        output=PromptOutputConfig(format='json', file_name='output'),
    )

    response = await openai_adapter.generate(rendered)

    assert response.text is not None
    data = json.loads(response.text)
    assert 'colors' in data
    assert isinstance(data['colors'], list)
    assert len(data['colors']) == 3
    logger.info('[e2e] json output (no schema): %s', data)


# ---------------------------------------------------------------------------
# Test K – output config: JSON format with complex nested schema
# ---------------------------------------------------------------------------

_BOOK_SCHEMA = {
    'type': 'object',
    'properties': {
        'title': {'type': 'string'},
        'author': {'type': 'string'},
        'year': {'type': 'integer'},
        'genres': {
            'type': 'array',
            'items': {'type': 'string'},
        },
    },
    'required': ['title', 'author', 'year', 'genres'],
    'additionalProperties': False,
}


@pytest.mark.asyncio
async def test_output_json_with_nested_schema(openai_adapter) -> None:
    """Verify structured output with a nested schema (array field)."""
    rendered = RenderedPrompt(
        config={'model': MODEL, 'temperature': 0},
        messages=[
            Message(
                role=Role.SYSTEM,
                content=[TextPart(text='You are a book data extraction assistant.')],
            ),
            Message(
                role=Role.USER,
                content=[
                    TextPart(
                        text=(
                            'Extract book info: "1984" by George Orwell, published in 1949. '
                            'Genres: dystopian, science fiction.'
                        )
                    )
                ],
            ),
        ],
        output=PromptOutputConfig(format='json', schema=_BOOK_SCHEMA, file_name='output'),
    )

    response = await openai_adapter.generate(rendered)

    assert response.text is not None
    data = json.loads(response.text)
    jsonschema.validate(instance=data, schema=_BOOK_SCHEMA)

    assert data['title'] == '1984'
    assert 'orwell' in data['author'].lower()
    assert data['year'] == 1949
    assert isinstance(data['genres'], list)
    assert len(data['genres']) >= 2
    assert set(data.keys()) == {'title', 'author', 'year', 'genres'}
    logger.info('[e2e] nested schema output: %s', data)


# ---------------------------------------------------------------------------
# Test L – {{SCHEMA}} auto-variable in template
# ---------------------------------------------------------------------------

_SCHEMA_VAR_PROMPT = """\
---
model: gpt-4.1
config:
  temperature: 0
  max_tokens: 200
output:
  format: json
  schema:
    type: object
    properties:
      city:
        type: string
      population:
        type: integer
    required:
      - city
      - population
    additionalProperties: false
---
{{role "system"}}
You are a data extraction assistant. Return ONLY valid JSON conforming to this schema:
{{SCHEMA}}
{{role "user"}}
Tell me about {{city}}: what is the city name and its approximate population?
"""


@pytest.mark.asyncio
async def test_schema_auto_variable(dotprompt_instance, openai_adapter) -> None:
    """Verify {{SCHEMA}} is injected into the rendered template and the output conforms."""
    rendered = dotprompt_instance.render(
        _SCHEMA_VAR_PROMPT,
        data=DataArgument(input={'city': 'Tokyo'}),
    )

    # Verify @schema was rendered into the system message
    system_msg = rendered.messages[0]
    assert system_msg.role == Role.SYSTEM
    system_text = ''.join(p.text for p in system_msg.content if hasattr(p, 'text'))
    assert '"city"' in system_text
    assert '"population"' in system_text

    # Call the real API
    response = await openai_adapter.generate(rendered)

    assert response.text is not None
    data = json.loads(response.text)
    assert 'city' in data
    assert 'population' in data
    assert isinstance(data['population'], int)
    assert data['population'] > 0
    logger.info('[e2e] @schema output: %s', data)


# ---------------------------------------------------------------------------
# Test M – dynamic model name via frontmatter variable
# ---------------------------------------------------------------------------

_DYNAMIC_MODEL_PROMPT = """\
---
config:
  model: "{{model_name}}"
  temperature: 0
  max_tokens: 20
---
{{role "user"}}
What is 5 * 5? Reply with just the number.
"""


@pytest.mark.asyncio
async def test_dynamic_model_name(dotprompt_instance, openai_adapter) -> None:
    """Verify model name can be set dynamically via frontmatter variables."""
    rendered = dotprompt_instance.render(
        _DYNAMIC_MODEL_PROMPT,
        data=DataArgument(input={'model_name': MODEL}),
        variables={'model_name': MODEL},
    )

    # Verify the model was resolved in the config
    assert rendered.config is not None
    assert rendered.config.get('model') == MODEL

    response = await openai_adapter.generate(rendered)

    assert response.text is not None
    assert '25' in response.text
    assert response.model is not None
    logger.info('[e2e] dynamic model=%s  text=%r', response.model, response.text)


# ---------------------------------------------------------------------------
# Test N – model name from frontmatter (static)
# ---------------------------------------------------------------------------

_STATIC_MODEL_PROMPT = """\
---
model: gpt-4.1
config:
  temperature: 0
  max_tokens: 20
---
{{role "user"}}
What is 8 + 8? Reply with just the number.
"""


@pytest.mark.asyncio
async def test_static_model_name(dotprompt_instance, openai_adapter) -> None:
    """Verify model name set statically in frontmatter works correctly."""
    rendered = dotprompt_instance.render(
        _STATIC_MODEL_PROMPT,
        data=DataArgument(),
    )

    response = await openai_adapter.generate(rendered)

    assert response.text is not None
    assert '16' in response.text
    # The response model should reflect the requested model family
    assert response.model is not None
    assert 'gpt' in response.model.lower()
    logger.info('[e2e] static model=%s  text=%r', response.model, response.text)


# ---------------------------------------------------------------------------
# Test O – picoschema through Dotprompt → structured output pipeline
# ---------------------------------------------------------------------------

_PICOSCHEMA_PROMPT = """\
---
model: gpt-4.1
config:
  temperature: 0
output:
  format: json
  schema:
    name: string, the person's full name
    age: integer, age in years
    employed: boolean, whether they are employed
---
{{role "system"}}
You are a data extraction assistant. Return structured JSON.
{{role "user"}}
Extract person info: Bob Smith is 42 years old and currently employed.
"""


@pytest.mark.asyncio
async def test_picoschema_to_structured_output(dotprompt_instance, openai_adapter) -> None:
    """Verify picoschema in frontmatter produces valid structured output."""
    rendered = dotprompt_instance.render(
        _PICOSCHEMA_PROMPT,
        data=DataArgument(),
    )

    # Verify the output schema was resolved
    assert rendered.output is not None
    assert rendered.output.format == 'json'
    assert rendered.output.schema is not None

    response = await openai_adapter.generate(rendered)

    assert response.text is not None
    data = json.loads(response.text)
    assert data['name'] == 'Bob Smith'
    assert data['age'] == 42
    assert data['employed'] is True
    logger.info('[e2e] picoschema output: %s', data)


# ---------------------------------------------------------------------------
# Test P – batch run with structured JSON output
# ---------------------------------------------------------------------------

_BATCH_JSON_SOURCE = """\
---
model: gpt-4.1
config:
  temperature: 0
output:
  format: json
  schema:
    type: object
    properties:
      animal:
        type: string
      legs:
        type: integer
    required:
      - animal
      - legs
    additionalProperties: false
---
{{role "user"}}
How many legs does a {{animal}} have? Return as JSON.
"""


@pytest.mark.asyncio
async def test_run_batch_with_json_output(openai_adapter) -> None:
    """Verify batch execution produces structured JSON output for each item."""
    inputs = [
        {'animal': 'cat'},
        {'animal': 'spider'},
    ]

    results = await run(
        _BATCH_JSON_SOURCE,
        inputs,
        openai_adapter,
        max_workers=2,
    )

    assert len(results) == 2
    for r in results:
        assert r.status == 'success', f'Batch item {r.index} failed: {r.error}'
        assert r.response is not None
        assert r.response.text is not None
        data = json.loads(r.response.text)
        assert 'animal' in data
        assert 'legs' in data
        assert isinstance(data['legs'], int)

    # Verify specific values
    cat_data = json.loads(results[0].response.text)
    spider_data = json.loads(results[1].response.text)
    assert cat_data['legs'] == 4
    assert spider_data['legs'] == 8
    logger.info('[e2e] batch json: cat=%s, spider=%s', cat_data, spider_data)


# ---------------------------------------------------------------------------
# Test Q – {{SCHEMA}} combined with batch run
# ---------------------------------------------------------------------------

_BATCH_SCHEMA_VAR_SOURCE = """\
---
model: gpt-4.1
config:
  temperature: 0
  max_tokens: 100
output:
  format: json
  schema:
    type: object
    properties:
      name:
        type: string
      category:
        type: string
        enum: ["fruit", "vegetable", "grain"]
    required:
      - name
      - category
    additionalProperties: false
---
{{role "system"}}
Classify the food item. Output JSON conforming to: {{SCHEMA}}
{{role "user"}}
Classify: {{food}}
"""


@pytest.mark.asyncio
async def test_run_batch_with_schema_variable(openai_adapter) -> None:
    """Verify batch run with {{SCHEMA}} auto-variable produces correct classifications."""
    inputs = [
        {'food': 'apple'},
        {'food': 'carrot'},
    ]

    results = await run(
        _BATCH_SCHEMA_VAR_SOURCE,
        inputs,
        openai_adapter,
        max_workers=2,
    )

    assert len(results) == 2
    for r in results:
        assert r.status == 'success', f'Batch item {r.index} failed: {r.error}'
        data = json.loads(r.response.text)
        assert data['category'] in ('fruit', 'vegetable', 'grain')

    apple_data = json.loads(results[0].response.text)
    carrot_data = json.loads(results[1].response.text)
    assert apple_data['category'] == 'fruit'
    assert carrot_data['category'] == 'vegetable'
    logger.info('[e2e] batch @schema: apple=%s, carrot=%s', apple_data, carrot_data)


# ---------------------------------------------------------------------------
# Test R – response metadata: model and finish_reason
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_response_metadata(openai_adapter) -> None:
    """Verify response contains model name, usage, and finish_reason metadata."""
    rendered = RenderedPrompt(
        config={'model': MODEL, 'temperature': 0, 'max_tokens': 10},
        messages=[
            Message(role=Role.USER, content=[TextPart(text='Say "hello".')]),
        ],
    )

    response = await openai_adapter.generate(rendered)

    assert response.text is not None
    assert response.model is not None
    assert 'gpt' in response.model.lower()
    assert response.finish_reason in ('stop', 'length')
    assert response.usage is not None
    assert response.usage.prompt_tokens > 0
    assert response.usage.completion_tokens > 0
    assert response.usage.total_tokens == response.usage.prompt_tokens + response.usage.completion_tokens
    logger.info(
        '[e2e] metadata: model=%s finish=%s tokens=%d',
        response.model,
        response.finish_reason,
        response.usage.total_tokens,
    )
