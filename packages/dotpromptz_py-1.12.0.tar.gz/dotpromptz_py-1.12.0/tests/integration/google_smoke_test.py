"""Smoke tests – verify basic connectivity to the Google (Gemini) endpoint."""

import logging

import pytest

from dotpromptz.typing import Message, RenderedPrompt, Role, TextPart

pytestmark = pytest.mark.integration

logger = logging.getLogger(__name__)


@pytest.mark.asyncio
async def test_simple_chat_completion(google_adapter) -> None:
    """Send one user message and verify we get a non-empty response."""
    rendered = RenderedPrompt(
        config={'model': 'gemini-2.5-flash'},
        messages=[
            Message(role=Role.USER, content=[TextPart(text='Say hello in one word.')]),
        ],
    )

    response = await google_adapter.generate(rendered)

    assert response.text is not None
    assert len(response.text.strip()) > 0
    assert response.usage is not None
    assert response.usage.total_tokens > 0
    assert 'STOP' in (response.finish_reason or '').upper()
    logger.info('[smoke] response: %r', response.text)
    logger.info('[smoke] tokens:   %s', response.usage.total_tokens)


@pytest.mark.asyncio
async def test_system_and_user_message(google_adapter) -> None:
    """Verify system + user messages work together."""
    rendered = RenderedPrompt(
        config={'model': 'gemini-2.5-flash'},
        messages=[
            Message(
                role=Role.SYSTEM,
                content=[TextPart(text='You are a helpful assistant. Reply in exactly one word.')],
            ),
            Message(
                role=Role.USER,
                content=[TextPart(text='What color is the sky on a clear day?')],
            ),
        ],
    )

    response = await google_adapter.generate(rendered)

    assert response.text is not None
    assert len(response.text.strip()) > 0
    logger.info('[smoke] response: %r', response.text)
