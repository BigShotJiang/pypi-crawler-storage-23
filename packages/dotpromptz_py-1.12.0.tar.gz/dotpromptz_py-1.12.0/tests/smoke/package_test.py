"""Smoke tests for package structure."""


def square(n: int | float) -> int | float:
    return n * n


def test_square() -> None:
    assert square(2) == 4
    assert square(3) == 9
    assert square(4) == 16
