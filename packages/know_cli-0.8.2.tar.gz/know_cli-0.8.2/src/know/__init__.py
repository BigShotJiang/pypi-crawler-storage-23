"""know - Living documentation generator for codebases."""

__version__ = "0.8.2"
__author__ = "Sushil Kumar"

from know.cli import main

__all__ = ["main", "__version__"]
