# Dual-Repo Parallel Benchmark

- Generated at: 2026-02-22T08:53:44.344220+00:00
- Strategies: `grep+read` baseline vs `know workflow` (single daemon RPC)
- Language globs: `py, ts, tsx, js, jsx, go, rs, swift`

## /Users/sushil/Code/Github/know-cli

- know version: `0.8.0`
- Token reduction: `93.3%` | Latency ratio (know/grep): `1.93x` | Tool-call reduction: `93.8%`
- Deep call-graph available: `100.0%` | non-empty edges: `100.0%`

| Query | Grep Tokens | know Tokens | Token Savings | Grep Time (s) | know Time (s) |
|---|---:|---:|---:|---:|---:|
| configuration loading and environment variable handling | 35,781 | 4,659 | 87.0% | 0.122 | 0.145 |
| database schema and persistence layer | 44,291 | 3,107 | 93.0% | 0.046 | 0.133 |
| module dependency graph and call graph tracking | 87,964 | 3,586 | 95.9% | 0.063 | 0.139 |
| error handling and retry logic | 75,983 | 5,038 | 93.4% | 0.058 | 0.141 |

## /Users/sushil/Code/Github/farfield

- know version: `0.8.0`
- Token reduction: `94.8%` | Latency ratio (know/grep): `1.77x` | Tool-call reduction: `93.8%`
- Deep call-graph available: `100.0%` | non-empty edges: `50.0%`

| Query | Grep Tokens | know Tokens | Token Savings | Grep Time (s) | know Time (s) |
|---|---:|---:|---:|---:|---:|
| configuration loading and environment variable handling | 71,889 | 3,975 | 94.5% | 0.202 | 0.369 |
| database schema and persistence layer | 31,431 | 3,290 | 89.5% | 0.124 | 0.258 |
| module dependency graph and call graph tracking | 80,982 | 4,059 | 95.0% | 0.17 | 0.283 |
| error handling and retry logic | 105,944 | 3,651 | 96.6% | 0.15 | 0.235 |
