import click
from snippy_ng.cli.utils import absolute_path_callback
from snippy_ng.cli.utils.globals import CommandWithGlobals, GlobalOption, add_snippy_global_options, create_outdir_callback
from pathlib import Path


@click.command(cls=CommandWithGlobals, context_settings={'show_default': True})
@click.option("--outdir", "-o", default=Path("core"), required=False, type=click.Path(writable=True, readable=True, file_okay=False, dir_okay=True), help="Output directory for the prepared reference", callback=create_outdir_callback, cls=GlobalOption)
@click.option("--prefix", "-p", default="core", help="Prefix for output files", cls=GlobalOption)
@add_snippy_global_options(exclude=['prefix', 'outdir'])
@click.argument("snippy_dirs", required=True, nargs=-1, type=click.Path(exists=True, readable=True), callback=absolute_path_callback)
@click.option("--ref", "reference", type=click.Path(exists=True, readable=True), callback=absolute_path_callback, required=True, help="Reference FASTA used to define contig order")
@click.option("--core", type=click.FLOAT, default=0.95, help="Proportion of samples a site must be present in to be included in the core alignment (0.0-1.0)")
def core(**config):
    """
    Create core alignment from multiple Snippy-NG runs
    """
    from snippy_ng.pipelines.core import CorePipelineBuilder

    if not config.get("snippy_dirs"):
        raise click.UsageError("Please provide at least one snippy directory!")

    # Choose stages to include in the pipeline
    # this will raise ValidationError if config is invalid
    # we let this happen as we want to catch all config errors
    # before starting the pipeline
    pipeline = CorePipelineBuilder(
        snippy_dirs=config["snippy_dirs"],
        reference=Path(config["reference"]),
        core=config["core"],
        tmpdir=config["tmpdir"],
        cpus=config["cpus"],
        ram=config["ram"],
        prefix=config["prefix"],
    ).build()

    # Run the pipeline
    pipeline.run(
        skip_check=config['skip_check'],
        check=config['check'],
        cwd=config['outdir'],
        quiet=config['quiet'],
        create_missing=config['create_missing'],
        keep_incomplete=config['keep_incomplete'],
    )