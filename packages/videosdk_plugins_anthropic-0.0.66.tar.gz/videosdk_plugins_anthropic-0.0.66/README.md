# VideoSDK Anthropic Plugin

Agent Framework plugin for LLM services from Anthropic.

## Installation

```bash
pip install videosdk-plugins-anthropic
```
