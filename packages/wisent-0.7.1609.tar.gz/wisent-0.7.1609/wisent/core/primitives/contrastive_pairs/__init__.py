"""Public interface for contrastive pair utilities."""

# diagnostics MUST be imported before core.set because core/set.py
# uses an absolute import of contrastive_pairs.diagnostics at module level.
from .diagnostics import DiagnosticsConfig, DiagnosticsReport, run_all_diagnostics
from .core.pair import ContrastivePair
from .core.set import ContrastivePairSet
from .core.buliders import from_phrase_pairs

__all__ = [
    "ContrastivePair",
    "ContrastivePairSet",
    "from_phrase_pairs",
    "DiagnosticsConfig",
    "DiagnosticsReport",
    "run_all_diagnostics",
]