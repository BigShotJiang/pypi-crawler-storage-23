# remottxrea/simulator/text_pool.py

import random


class TextPool:

    def __init__(self):

        self.messages = [

            "Hello 👋",
            "Automation test message",
            "Safe mode active",
            "Async loop running",
            "System check completed",
            "Warmup cycle executed",
            "Human simulation active",
            "Profile activity pulse",
            "Session alive ✅",
            "Ping • activity marker"
        ]

        self._last_sent = None

    # ---------- GET RANDOM ----------
    def get(self) -> str:

        pool = [
            m for m in self.messages
            if m != self._last_sent
        ]

        text = random.choice(pool)

        self._last_sent = text

        return text


text_pool = TextPool()
