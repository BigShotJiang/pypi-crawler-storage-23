"""
actions/join_leave.py
Full logging integrated
(Internal Flood Handling Version)
"""

import re
import asyncio
from typing import List, Union

from pyrogram.errors import (
    FloodWait,
    RPCError,
    UserAlreadyParticipant,
    InviteHashInvalid,
    InviteHashExpired,
    ChannelPrivate
)

from ..core.safe_executor import SafeExecutor
from ..core.delay_engine import DelayEngine
from ..core.logger import get_action_logger


INVITE_REGEX = re.compile(
    r"(?:https?://)?t\.me/(?:\+|joinchat/)([\w-]+)"
)

PUBLIC_REGEX = re.compile(
    r"(?:https?://)?t\.me/([\w_]+)"
)


class JoinLeaveManager:

    def __init__(self, client, session_name: str):

        self.client = client
        self.session_name = session_name

        self.logger = get_action_logger(
            action="join_leave",
            session=session_name
        )

    # --------------------------------------------------
    # INTERNAL FLOOD HANDLER
    # --------------------------------------------------

    async def _handle_flood(self, e: FloodWait, action: str):

        wait_time = int(e.value)

        self.logger.warning(
            f"[{self.session_name}] "
            f"FloodWait {wait_time}s → {action}"
        )

        await asyncio.sleep(wait_time)

        self.logger.info(
            f"[{self.session_name}] "
            f"FloodWait finished → {action}"
        )

    # --------------------------------------------------
    # PARSE
    # --------------------------------------------------

    def _parse_chat(self, chat):

        invite_match = INVITE_REGEX.search(str(chat))
        if invite_match:
            return "invite", invite_match.group(1)

        public_match = PUBLIC_REGEX.search(str(chat))
        if public_match:
            return "public", public_match.group(1)

        if isinstance(chat, str):
            return "public", chat.replace("@", "")

        return "id", chat

    # --------------------------------------------------
    # JOIN EXEC
    # --------------------------------------------------

    async def _join_exec(self, chat):

        chat_type, value = self._parse_chat(chat)

        if chat_type == "invite":
            return await self.client.join_chat(
                f"https://t.me/+{value}"
            )

        return await self.client.join_chat(value)

    # --------------------------------------------------
    # LEAVE EXEC
    # --------------------------------------------------

    async def _leave_exec(self, chat):
        return await self.client.leave_chat(chat)

    # --------------------------------------------------
    # NORMALIZE
    # --------------------------------------------------

    def _normalize(
        self,
        chats: Union[str, int, List]
    ) -> List:

        if isinstance(chats, (str, int)):
            return [chats]

        return list(chats)

    # --------------------------------------------------
    # JOIN
    # --------------------------------------------------

    async def join(
        self,
        chats,
        use_delay=True
    ):

        chats = self._normalize(chats)

        result = {"success": 0, "failed": 0}

        for chat in chats:

            try:

                self.logger.info(
                    f"[{self.session_name}] Joining → {chat}"
                )

                if use_delay:
                    await DelayEngine.join_delay()

                await SafeExecutor.run(
                    self._join_exec(chat),
                    session_name=self.session_name,
                    action_name="join_chat"
                )

                self.logger.info(
                    f"[{self.session_name}] Joined → {chat}"
                )

                result["success"] += 1

            except UserAlreadyParticipant:

                self.logger.warning(
                    f"[{self.session_name}] "
                    f"Already joined → {chat}"
                )

                result["success"] += 1

            except FloodWait as e:

                await self._handle_flood(
                    e,
                    action="join_chat"
                )

                result["failed"] += 1

            except (
                InviteHashInvalid,
                InviteHashExpired,
                ChannelPrivate
            ):

                self.logger.error(
                    f"[{self.session_name}] "
                    f"Invalid invite → {chat}"
                )

                result["failed"] += 1

            except RPCError as e:

                self.logger.error(
                    f"[{self.session_name}] "
                    f"RPC Error → {e}"
                )

                result["failed"] += 1

            except Exception as e:

                self.logger.exception(
                    f"[{self.session_name}] "
                    f"Join error → {e}"
                )

                result["failed"] += 1

        self.logger.info(
            f"[{self.session_name}] Join result → {result}"
        )

        return result

    # --------------------------------------------------
    # LEAVE
    # --------------------------------------------------

    async def leave(
        self,
        chats,
        use_delay=True
    ):

        chats = self._normalize(chats)

        result = {"success": 0, "failed": 0}

        for chat in chats:

            try:

                self.logger.info(
                    f"[{self.session_name}] Leaving → {chat}"
                )

                if use_delay:
                    await DelayEngine.leave_delay()

                await SafeExecutor.run(
                    self._leave_exec(chat),
                    session_name=self.session_name,
                    action_name="leave_chat"
                )

                self.logger.info(
                    f"[{self.session_name}] Left → {chat}"
                )

                result["success"] += 1

            except FloodWait as e:

                await self._handle_flood(
                    e,
                    action="leave_chat"
                )

                result["failed"] += 1

            except RPCError as e:

                self.logger.error(
                    f"[{self.session_name}] "
                    f"RPC Error → {e}"
                )

                result["failed"] += 1

            except Exception as e:

                self.logger.exception(
                    f"[{self.session_name}] "
                    f"Leave error → {e}"
                )

                result["failed"] += 1

        self.logger.info(
            f"[{self.session_name}] Leave result → {result}"
        )

        return result