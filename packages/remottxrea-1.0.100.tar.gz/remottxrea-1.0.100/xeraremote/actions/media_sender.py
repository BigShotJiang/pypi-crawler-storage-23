from pyrogram.errors import FloodWait
import asyncio

from ..core.safe_executor import SafeExecutor
from ..core.delay_engine import delay_engine
from ..core.logger import get_action_logger


class MediaSender:

    def __init__(self, client, session):

        self.client = client
        self.session = session
        self.log = get_action_logger(
            "media_sender",
            session
        )

    # --------------------------------------------------
    # INTERNAL FLOOD HANDLER
    # --------------------------------------------------

    async def _handle_flood(self, e: FloodWait):

        wait_time = int(e.value)

        self.log.warning(
            f"[{self.session}] FloodWait → {wait_time}s"
        )

        await asyncio.sleep(wait_time)

        self.log.info(
            f"[{self.session}] FloodWait finished"
        )

    # --------------------------------------------------
    # EXEC
    # --------------------------------------------------

    async def _exec(
        self,
        chat,
        file,
        media_type,
        caption,
        silent
    ):

        if media_type == "photo":

            await self.client.send_photo(
                chat,
                file,
                caption=caption,
                disable_notification=silent
            )

        elif media_type == "video":

            await self.client.send_video(
                chat,
                file,
                caption=caption,
                disable_notification=silent
            )

        elif media_type == "document":

            await self.client.send_document(
                chat,
                file,
                caption=caption,
                disable_notification=silent
            )

        else:
            raise ValueError(
                f"Unsupported media_type: {media_type}"
            )

    # --------------------------------------------------
    # PUBLIC API
    # --------------------------------------------------

    async def send(
        self,
        chat_id,
        file_path,
        media_type="photo",
        caption=None,
        silent=True
    ):

        try:

            await delay_engine.message_delay()

            await SafeExecutor.run(
                self._exec(
                    chat_id,
                    file_path,
                    media_type,
                    caption,
                    silent
                ),
                self.session,
                "media_send"
            )

            self.log.info(
                f"[{self.session}] Media sent → {chat_id}"
            )

            return True

        except FloodWait as e:

            await self._handle_flood(e)
            return False

        except Exception as e:

            self.log.exception(e)
            return False