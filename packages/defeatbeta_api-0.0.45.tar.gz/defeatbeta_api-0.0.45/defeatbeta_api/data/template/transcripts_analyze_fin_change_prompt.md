# Earnings Call Transcript:
`earnings_call_transcripts` = {earnings_call_transcripts}

# Introduction for `earnings_call_transcripts`

`earnings_call_transcripts` is an array organized by paragraphs. 

Each element represents a paragraph in the meeting transcript, and the `sentences` within each paragraph have already been pre-segmented.