from typing import List, Literal, Optional, Dict, Any
from enum import Enum
import requests


class FileType:
    """文件类型常量"""
    IMAGE = 'image'
    AUDIO = 'audio'
    VIDEO = 'video'
    OTHERS = '*'


class CallbackType(Enum):
    """回调类型枚举"""
    GROUP_QRCODE = 0  # 群二维码回调
    COMMAND_RESULT = 1  # 指令结果回调
    ROBOT_ONLINE = 5  # 机器人上线回调
    ROBOT_OFFLINE = 6  # 机器人下线回调


class EncryptType(Enum):
    """加密类型枚举"""
    NONE = 0  # 不加密
    AES = 1  # AES加密


class ReplyStrategy(Enum):
    """回复策略枚举"""
    DISABLED = 0  # 关闭
    ENABLED = 1  # 开启


class WorktoolException(Exception):
    """Worktool SDK 异常基类"""
    pass


class WorktoolAPIException(WorktoolException):
    """API 调用异常"""

    def __init__(self, code: int, message: str, data: Any = None):
        self.code = code
        self.message = message
        self.data = data
        super().__init__(f"API Error {code}: {message}")


class WorktoolAction:
    """
    Worktool 企业微信机器人 SDK

    使用示例:
        # 方式1: 使用上下文管理器（推荐）
        with Worktool(robot_id="your_robot_id") as bot:
            bot.send_text(["张三"], "你好")
            bot.send_file(["李四"], "文件.pdf", "https://example.com/file.pdf", FileType.OTHERS)

        # 方式2: 手动推送
        bot = Worktool(robot_id="your_robot_id")
        bot.send_text(["张三"], "你好")
        bot.push_action()
    """

    def __init__(self, robot_id: str, key: Optional[str] = None, timeout: int = 30, base_url: str = "https://api.worktool.ymdyes.cn"):
        """
        初始化 Worktool 客户端

        Args:
            robot_id: 机器人唯一标识
            key: 可选的校验密钥
            timeout: 请求超时时间（秒）
        """
        self._kwargs = {
            "robot_id": robot_id,
            "key": key,
            "timeout": timeout,
            "base_url": base_url.rstrip("/")
        }
        self._robot_id = robot_id
        self._key = key
        self._timeout = timeout
        self._base_url = base_url.rstrip("/")
        self.action = self.Action(**self._kwargs)

    def _build_params(self, extra_params: Optional[Dict] = None) -> Dict:
            """构建请求参数"""
            params = {"robotId": self._robot_id}
            if self._key:
                params["key"] = self._key
            if extra_params:
                params.update(extra_params)
            return params

    @staticmethod
    def _handle_response(response: requests.Response) -> Dict:
            try:
                result = response.json()
            except ValueError:
                raise WorktoolAPIException(-1, "Invalid JSON response", response.text)

            code = result.get("code")
            message = result.get("message", "Unknown error")
            data = result.get("data")

            if code != 200:
                raise WorktoolAPIException(code, message, data)

            return result

    # ==================== 指令消息 API ====================

    class Action:
        def __init__(self, **kwargs):
            self._robot_id = kwargs["robot_id"]
            self._key = kwargs["key"]
            self._timeout = kwargs["timeout"]
            self._base_url: str = kwargs["base_url"]
            self._context_manager_mode = False
            self.action: List[Dict] = []

        def __enter__(self):
            """进入上下文管理器"""
            self._context_manager_mode = True
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            """退出上下文管理器时自动推送消息"""
            if self.action:
                self.push_action()

        def _build_params(self, extra_params: Optional[Dict] = None) -> Dict:
            """构建请求参数"""
            params = {"robotId": self._robot_id}
            if self._key:
                params["key"] = self._key
            if extra_params:
                params.update(extra_params)
            return params

        @staticmethod
        def _handle_response(response: requests.Response) -> Dict:
            """处理 API 响应"""
            try:
                result = response.json()
            except ValueError:
                raise WorktoolAPIException(-1, "Invalid JSON response", response.text)

            code = result.get("code")
            message = result.get("message", "Unknown error")
            data = result.get("data")

            if code != 200:
                raise WorktoolAPIException(code, message, data)

            return result

        def push_action(self) -> Dict:
            """
            推送待执行的指令队列

            Returns:
                API 响应结果，包含 messageId
            """
            if not self.action:
                raise WorktoolException("No actions to push")

            response = requests.post(
                url=f"{self._base_url}/wework/sendRawMessage",
                params=self._build_params(),
                json={"socketType": 2, "list": self.action},
                timeout=self._timeout
            )

            result = self._handle_response(response)
            self.action.clear()  # 清空已推送的指令
            return result

        def clear_action(self) -> Dict:
            """清空客户端所有待执行指令"""
            response = requests.post(
                url=f"{self._base_url}/wework/sendRawMessage",
                params=self._build_params(),
                json={"socketType": 2, "list": [{"type": 304}]},
                timeout=self._timeout
            )
            return self._handle_response(response)

        def clear_specific_action(self, message_id: str) -> Dict:
            """
            清除指定的客户端指令

            Args:
                message_id: 要清除的消息ID
            """
            response = requests.post(
                url=f"{self._base_url}/wework/sendRawMessage",
                params=self._build_params(),
                json={
                    "socketType": 2,
                    "list": [{"type": 305, "originalContent": message_id}]
                },
                timeout=self._timeout
            )
            return self._handle_response(response)

        def send_text(self, receiver: List[str], msg: str, at_list: Optional[List[str]] = None):
            """
            发送文本消息

            Args:
                receiver: 接收者列表（昵称或群名）
                msg: 消息内容（支持 \\n 换行）
                at_list: 要@的人列表（使用"@所有人"可@全体）
            """
            action = {
                "type": 203,
                "titleList": receiver,
                "receivedContent": msg
            }
            if at_list:
                action["atList"] = at_list
            self.action.append(action)
            if not self._context_manager_mode:
                self.push_action()

        def send_file(
                self,
                receiver: List[str],
                object_name: str,
                object_url: str,
                file_type: str,
                extra_msg: str = ""
        ):
            """
            推送任意图片/音视频/文件

            Args:
                receiver: 接收者列表（最多9个）
                object_name: 文件名称（建议使用有意义的文件名和后缀）
                object_url: 网络文件地址
                file_type: 文件类型（使用 FileType 常量）
                extra_msg: 附加留言
            """
            self.action.append({
                "type": 218,
                "titleList": receiver,
                "objectName": object_name,
                "fileUrl": object_url,
                "fileType": file_type,
                "extraText": extra_msg
            })
            if not self._context_manager_mode:
                self.push_action()

        def forward_message(
                self,
                group_name: str,
                sender_name: str,
                original_content: str,
                receiver_list: List[str],
                text_type: int = 0,
                extra_msg: str = ""
        ):
            """
            转发消息（不推荐使用）

            Args:
                group_name: 转发群群名
                sender_name: 原始消息发送人昵称
                original_content: 原始消息内容
                receiver_list: 待转发姓名列表
                text_type: 消息类型（0=未知 1=文本 2=图片 5=视频 7=小程序 8=链接 9=文件）
                extra_msg: 附加留言
            """
            self.action.append({
                "type": 205,
                "titleList": [group_name],
                "receivedName": sender_name,
                "originalContent": original_content,
                "nameList": receiver_list,
                "textType": text_type,
                "extraText": extra_msg
            })
            if not self._context_manager_mode:
                self.push_action()

        def recall_message(
                self,
                receiver: List[str],
                original_content: str,
                text_type: int
        ):
            """
            撤回消息

            Args:
                receiver: 消息接收者昵称或群名称
                original_content: QA回调里的原始消息内容
                text_type: QA回调里的textType
            """
            self.action.append({
                "type": 226,
                "titleList": receiver,
                "originalContent": original_content,
                "textType": text_type
            })
            if not self._context_manager_mode:
                self.push_action()

        # ==================== 群管理 API ====================

        def create_group(
                self,
                group_name: str,
                members: List[str],
                announcement: str = "",
                remark: str = "",
                template: str = ""
        ):
            """
            创建外部群

            Args:
                group_name: 群名称
                members: 要拉入群的成员昵称列表
                announcement: 群公告
                remark: 群备注
                template: 群模板
            """
            action = {
                "type": 206,
                "groupName": group_name,
                "selectList": members
            }
            if announcement:
                action["groupAnnouncement"] = announcement
            if remark:
                action["groupRemark"] = remark
            if template:
                action["groupTemplate"] = template
            self.action.append(action)
            if not self._context_manager_mode:
                self.push_action()

        def group_member_add(self, group_name: str, members: List[str], show_history: bool = False):
            """
            群拉人

            Args:
                group_name: 群名称（有备注名使用备注名）
                members: 要添加的成员列表
                show_history: 是否显示历史消息
            """
            self.action.append({
                "type": 207,
                "groupName": group_name,
                "selectList": members,
                "showMessageHistory": show_history
            })
            if not self._context_manager_mode:
                self.push_action()

        def group_member_remove(self, group_name: str, members: List[str]):
            """
            群踢人

            Args:
                group_name: 群名称（有备注名使用备注名）
                members: 要移除的成员列表
            """
            self.action.append({
                "type": 207,
                "groupName": group_name,
                "removeList": members
            })
            if not self._context_manager_mode:
                self.push_action()

        def group_member_remark(self, group_name: str, nickname: str, mark_name: str):
            """
            修改群成员备注

            Args:
                group_name: 群名称
                nickname: 成员昵称
                mark_name: 新备注名
            """
            self.action.append({
                "type": 225,
                "groupName": group_name,
                "friend": {
                    "name": nickname,
                    "markName": mark_name
                }
            })
            if not self._context_manager_mode:
                self.push_action()

        def group_notice(self, group_name: str, notice: str):
            """
            修改群公告

            Args:
                group_name: 群名称
                notice: 新公告内容
            """
            self.action.append({
                "type": 207,
                "groupName": group_name,
                "newGroupAnnouncement": notice
            })
            if not self._context_manager_mode:
                self.push_action()

        def group_rename(self, group_name: str, new_group_name: str):
            """
            修改群名称

            Args:
                group_name: 当前群名称
                new_group_name: 新群名称
            """
            self.action.append({
                "type": 207,
                "groupName": group_name,
                "newGroupName": new_group_name
            })
            if not self._context_manager_mode:
                self.push_action()

        def group_remark(self, group_name: str, remark: str):
            """
            修改群备注

            Args:
                group_name: 群名称
                remark: 新备注
            """
            self.action.append({
                "type": 207,
                "groupName": group_name,
                "groupRemark": remark
            })
            if not self._context_manager_mode:
                self.push_action()

        def group_template(self, group_name: str, template: str):
            """
            修改群模板

            Args:
                group_name: 群名称
                template: 群模板
            """
            self.action.append({
                "type": 207,
                "groupName": group_name,
                "groupTemplate": template
            })
            if not self._context_manager_mode:
                self.push_action()

        def group_disband(self, group_name: str):
            """
            解散群（需要是群主，不可撤销！）

            Args:
                group_name: 群名称
            """
            self.action.append({
                "type": 219,
                "groupName": group_name
            })
            if not self._context_manager_mode:
                self.push_action()

        def get_group_members(self, group_name: str):
            """
            获取指定群成员信息

            Args:
                group_name: 群名称（有备注名优先用备注名）
            """
            self.action.append({
                "type": 512,
                "groupName": group_name
            })
            if not self._context_manager_mode:
                self.push_action()

        # ==================== 好友管理 API ====================

        def friend_add_from_phone(
                self,
                phone: str,
                mark_name: Optional[str] = None,
                mark_extra: Optional[str] = None,
                tags: Optional[List[str]] = None,
                extra_msg: Optional[str] = None
        ):
            """
            按手机号添加好友（每天不超过100人）

            Args:
                phone: 手机号
                mark_name: 备注昵称
                mark_extra: 备注其他信息（不推荐）
                tags: 备注标签（推荐）
                extra_msg: 加好友附言
            """
            friend_data: Dict[str, Any]  = {"phone": phone}
            if mark_name:
                friend_data["markName"] = mark_name
            if mark_extra:
                friend_data["markExtra"] = mark_extra
            if tags:
                friend_data["tagList"] = tags
            if extra_msg:
                friend_data["leavingMsg"] = extra_msg

            self.action.append({
                "type": 213,
                "friend": friend_data
            })
            if not self._context_manager_mode:
                self.push_action()

        def friend_add_from_group(
                self,
                group_name: str,
                nickname: str,
                mark_name: Optional[str] = None,
                mark_extra: Optional[str] = None,
                tags: Optional[List[str]] = None,
                extra_msg: Optional[str] = None
        ):
            """
            从外部群添加好友

            Args:
                group_name: 群名称或群备注名
                nickname: 成员昵称或备注名
                mark_name: 备注昵称
                mark_extra: 备注其他信息（不推荐）
                tags: 备注标签（推荐）
                extra_msg: 加好友附言
            """
            friend_data: Dict[str, Any] = {"name": nickname}
            if mark_name:
                friend_data["markName"] = mark_name
            if mark_extra:
                friend_data["markExtra"] = mark_extra
            if tags:
                friend_data["tagList"] = tags
            if extra_msg:
                friend_data["leavingMsg"] = extra_msg

            self.action.append({
                "type": 220,
                "groupName": group_name,
                "friend": friend_data
            })
            if not self._context_manager_mode:
                self.push_action()

        def friend_modify(
                self,
                search: str,
                search_type: Literal["name", "phone"] = "name",
                mark_name: Optional[str] = None,
                mark_extra: Optional[str] = None,
                tags: Optional[List[str]] = None
        ):
            """
            修改好友信息

            Args:
                search: 搜索值（昵称/备注名或手机号）
                search_type: 搜索类型（name 或 phone）
                mark_name: 新备注昵称
                mark_extra: 备注其他信息（不推荐）
                tags: 备注标签（推荐）
            """
            friend_data = {}
            if search_type == "phone":
                friend_data["phone"] = search
            else:
                friend_data["name"] = search

            if mark_name:
                friend_data["markName"] = mark_name
            if mark_extra:
                friend_data["markExtra"] = mark_extra
            if tags:
                friend_data["tagList"] = tags

            self.action.append({
                "type": 213,
                "friend": friend_data
            })
            if not self._context_manager_mode:
                self.push_action()

        def friend_remove(self, nickname: str):
            """
            删除联系人（不可撤回！有备注名应使用备注名）

            Args:
                nickname: 好友昵称或备注名
            """
            self.action.append({
                "type": 234,
                "friend": {"name": nickname}
            })
            if not self._context_manager_mode:
                self.push_action()

        # ==================== 其他功能 API ====================

        def todo(
                self,
                content: str,
                nicknames: Optional[List[str]] = None,
                group_names: Optional[List[str]] = None
        ):
            """
            添加待办（仅可给企业内部成员添加）

            Args:
                content: 待办事项内容
                nicknames: 内部用户昵称列表
                group_names: 内部群名称列表
            """
            if not nicknames and not group_names:
                raise WorktoolException("Must provide at least one of nicknames or group_names")

            title_list = []
            if group_names:
                title_list.extend(group_names)
            if nicknames:
                title_list.extend(nicknames)

            self.action.append({
                "type": 221,
                "titleList": title_list,
                "receivedContent": content
            })
            if not self._context_manager_mode:
                self.push_action()

        def send_tencent_doc(
                self,
                nicknames: List[str],
                object_name: str,
                extra_msg: str = ""
        ):
            """
            推送腾讯文档

            Args:
                nicknames: 接收者昵称列表
                object_name: 文档名称
                extra_msg: 附加留言
            """
            self.action.append({
                "type": 211,
                "titleList": nicknames,
                "objectName": object_name,
                "extraText": extra_msg
            })
            if not self._context_manager_mode:
                self.push_action()
                
    # ==================== 机器人配置 API ====================

    def get_robot_info(self) -> Dict:
        """获取机器人信息"""
        response = requests.get(
            url=f"{self._base_url}/robot/robotInfo/get",
            params=self._build_params(),
            timeout=self._timeout
        )
        result = self._handle_response(response)
        return result.get("data") or None

    def get_online_status(self) -> bool:
        """
        查询机器人是否在线

        Returns:
            True 表示在线，False 表示离线
        """
        try:
            response = requests.get(
                url=f"{self._base_url}/robot/robotInfo/online",
                params=self._build_params(),
                timeout=self._timeout
            )
            result = self._handle_response(response)
            return result.get("data", False)
        except WorktoolAPIException:
            return False

    def get_online_logs(self, date: Optional[str] = None) -> Dict:
        """
        查询机器人登录日志

        Args:
            date: 日期（格式：yyyy-MM-dd）
        """
        params = self._build_params()
        if date:
            params["date"] = date

        response = requests.get(
            url=f"{self._base_url}/robot/robotInfo/onlineInfos",
            params=params,
            timeout=self._timeout
        )
        return self._handle_response(response)

    def get_callbacks(self) -> List[Dict]:
        """
        查询机器人回调配置

        Returns:
            回调配置列表
        """
        response = requests.get(
            url=f"{self._base_url}/robot/robotInfo/callBack/get",
            params=self._build_params(),
            timeout=self._timeout
        )
        result = self._handle_response(response)
        return result.get("data", [])

    def update_encryption(self, secret_key: str, encrypt_type: EncryptType = EncryptType.NONE) -> Dict:
        """
        配置机器人后端通讯加密

        Args:
            secret_key: 密钥
            encrypt_type: 加密类型
        """
        response = requests.post(
            url=f"{self._base_url}/robot/robotInfo/update",
            params=self._build_params(),
            json={
                "secretKey": secret_key,
                "encryptType": encrypt_type.value
            },
            timeout=self._timeout
        )
        return self._handle_response(response)

    # ==================== 回调配置 API ====================

    def update_message_callback(self, open_callback: bool, reply_all: ReplyStrategy, callback_url: Optional[str] = None) -> Dict:
        """
        配置机器人消息回调

        Args:
            open_callback: 是否开启QA回调
            reply_all: 回复策略
            callback_url: QA回调URL
        """
        data:Dict[str, Any] = {
            "openCallback": 1 if open_callback else 0,
            "replyAll": reply_all.value
        }
        if callback_url:
            data["callbackUrl"] = callback_url

        response = requests.post(
            url=f"{self._base_url}/robot/robotInfo/update",
            params=self._build_params(),
            json=data,
            timeout=self._timeout
        )
        return self._handle_response(response)

    def update_other_callback(self, callback_type: CallbackType, callback_url: str) -> Dict:
        """
        绑定机器人回调

        Args:
            callback_type: 回调类型
            callback_url: 回调URL
        """
        response = requests.post(
            url=f"{self._base_url}/robot/robotInfo/callBack/bind",
            params=self._build_params(),
            json={
                "type": callback_type.value,
                "callBackUrl": callback_url
            },
            timeout=self._timeout
        )
        return self._handle_response(response)

    def update_callback_delete(self, callback_type: CallbackType) -> Dict:
        """
        删除机器人回调

        Args:
            callback_type: 回调类型
        """
        response = requests.post(
            url=f"{self._base_url}/robot/robotInfo/callBack/deleteByType",
            params=self._build_params(),
            json={"type": callback_type.value},
            timeout=self._timeout
        )
        return self._handle_response(response)

    # ==================== 历史消息 API ====================

    def get_raw_messages_list(
            self,
            message_id: Optional[str] = None,
            page: int = 1,
            size: int = 10,
            sort: str = "create_time,desc"
    ) -> Dict:
        """
        查询指令消息API调用记录

        Args:
            message_id: 消息ID
            page: 页码
            size: 每页大小
            sort: 排序方式
        """
        params = self._build_params({
            "page": str(page),
            "size": str(size),
            "sort": sort
        })
        if message_id:
            params["messageId"] = message_id

        response = requests.get(
            url=f"{self._base_url}/wework/listRawMessage",
            params=params,
            timeout=self._timeout
        )
        return self._handle_response(response)

    def get_command_results_list(
            self,
            page: int = 1,
            size: int = 10,
            sort: str = "run_time,desc",
            start_time: Optional[str] = None,
            end_time: Optional[str] = None,
            cmd_type: Optional[int] = None,
            message_id: Optional[str] = None
    ) -> Dict:
        """
        查询指令执行结果

        Args:
            page: 页码
            size: 每页大小
            sort: 排序方式
            start_time: 开始时间（格式：2020-12-12 00:00:00）
            end_time: 结束时间
            cmd_type: 指令类型
            message_id: 消息ID
        """
        params = self._build_params({
            "page": str(page),
            "size": str(size),
            "sort": sort
        })
        if start_time:
            params["startTime"] = start_time
        if end_time:
            params["endTime"] = end_time
        if cmd_type is not None:
            params["type"] = str(cmd_type)
        if message_id:
            params["messageId"] = message_id

        response = requests.get(
            url=f"{self._base_url}/robot/rawMsg/list",
            params=params,
            timeout=self._timeout
        )
        return self._handle_response(response)

    def get_callback_logs_list(
            self,
            page: int = 1,
            size: int = 10,
            sort: str = "start_time,desc",
            name: Optional[str] = None,
            start_time: Optional[str] = None,
            end_time: Optional[str] = None
    ) -> Dict:
        """
        查询机器人消息回调日志

        Args:
            page: 页码
            size: 每页大小
            sort: 排序方式
            name: 聊天对象
            start_time: 开始时间
            end_time: 结束时间
        """
        params = self._build_params({
            "page": str(page),
            "size": str(size),
            "sort": sort
        })
        if name:
            params["name"] = name
        if start_time:
            params["startTime"] = start_time
        if end_time:
            params["endTime"] = end_time

        response = requests.get(
            url=f"{self._base_url}/robot/qaLog/list",
            params=params,
            timeout=self._timeout
        )
        return self._handle_response(response)



if __name__ == "__main__":
    bot = WorktoolAction(robot_id="...")
    print(bot.get_online_status())
    print(bot.get_robot_info())
    print(bot.get_callbacks())