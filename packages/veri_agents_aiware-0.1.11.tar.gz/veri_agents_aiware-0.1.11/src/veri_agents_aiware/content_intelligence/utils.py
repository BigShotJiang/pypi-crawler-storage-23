import logging

from langchain_core.messages.utils import count_tokens_approximately
from veri_agents_aiware.content_intelligence.data import format_table_delimited

log = logging.getLogger(__name__)


def format_structured_table_for_context(table_data: dict) -> str:
    """Format structured table data for LLM context."""
    alias = table_data.get("alias", "unknown")
    status = table_data.get("status", "unknown")
    shape = table_data.get("shape", (0, 0))
    was_truncated = table_data.get("was_truncated", False)
    truncation_info = table_data.get("truncation_info")

    if status == "missing":
        return f"{alias}: Table not found"
    elif status == "empty":
        return f"{alias}: Table is empty"
    elif status != "ok":
        return f"{alias}: Table status: {status}"

    # Get the actual polars DataFrame
    df = table_data.get("data")
    if df is None:
        return f"{alias}: No data available"

    formatted_table = format_table_delimited(
        df,
        delimiter="\t",
        text_preview=None,
        round_digits=4,
        add_footer=True,
        limit_rows=10000,  # Large limit for now, we'll handle chunking separately
    )

    # Build the result with truncation warning if applicable
    header = f"{alias} ({shape[0]} rows, {shape[1]} cols)"
    if was_truncated and truncation_info:
        header += f" - ⚠️ DATA TRUNCATED: {truncation_info}"

    return f"{header}:\n{formatted_table}"


def chunk_text_tables(
    formatted_tables: list[str], max_tokens_per_chunk: int = 50000
) -> list[str]:
    """
    Split pre-formatted table strings into manageable chunks for bulk processing.

    Args:
        formatted_tables: List of already formatted table strings
        max_tokens_per_chunk: Maximum tokens per chunk

    Returns:
        List of text chunks, each containing one or more tables
    """
    # Filter out empty/missing table notifications - they add no value
    meaningful_tables = [
        t for t in formatted_tables 
        if not (t.endswith(": Table is empty") or t.endswith(": Table not found") or ": Table status:" in t or ": No data available" in t)
    ]
    
    chunks = []
    current_chunk = ""
    current_tokens = 0
    fitting_tables = []

    # first we have to split tables that are by itself too long already
    for i, table_text in enumerate(meaningful_tables):
        table_tokens = count_tokens_approximately([table_text])
        if table_tokens > max_tokens_per_chunk:
            log.warning(
                f"[Executor] Single table {i} exceeds max tokens per chunk ({table_tokens} > {max_tokens_per_chunk}), splitting it individually."
            )
            # Split this table into smaller parts by lines
            lines = table_text.splitlines()
            header = lines[0] if lines else ""
            part = header + "\n"
            part_tokens = count_tokens_approximately([part])
            for line in lines[1:]:
                line_tokens = count_tokens_approximately([line + "\n"])
                if part_tokens + line_tokens > max_tokens_per_chunk and part:
                    chunks.append(part.strip())
                    part = header + "\n"  # start new part with header
                    part += line + "\n"
                    part_tokens = count_tokens_approximately([part])
                else:
                    part += line + "\n"
                    part_tokens += line_tokens
            if part:
                chunks.append(part.strip())
        else:
            # Keep the table as is for normal processing
            fitting_tables.append(table_text)

    # process the remaining tables that fit, perhaps we can squeeze two or more into one chunk
    for table_text in fitting_tables:
        table_tokens = count_tokens_approximately([table_text])

        # If adding this table would exceed the limit, save current chunk and start new one
        if current_tokens + table_tokens > max_tokens_per_chunk and current_chunk:
            chunks.append(current_chunk.strip())
            current_chunk = table_text
            current_tokens = table_tokens
        else:
            # Add table to current chunk
            if current_chunk:
                current_chunk += "\n\n" + table_text
            else:
                current_chunk = table_text
            current_tokens += table_tokens

    # Add the last chunk if it has content
    if current_chunk:
        chunks.append(current_chunk.strip())

    return chunks
