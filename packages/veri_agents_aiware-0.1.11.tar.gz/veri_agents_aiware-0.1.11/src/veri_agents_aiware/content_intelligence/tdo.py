from datetime import datetime
import logging
import asyncio
import time
import async_lru

from aiware.aion import Aion, AionObjectType, AionSeries, AionObject
from .data import (
    Signal,
    SegmentsTable,
    create_segment_dict,
    new_segments_table,
    TDO_SCHEMA,
)
from .parallel_downloading import adownload_all

from veri_agents_aiware.aiware_client.async_client import AsyncAgentsAiware
from veri_agents_aiware.aiware_client.client_generated.rag_get_tdo_content import (
    RAGGetTDOContentTemporalDataObject,
)
from veri_agents_aiware.aiware_client.client_generated.get_tdos_by_id_with_assets import (
    GetTdosByIdWithAssetsTemporalDataObjectsRecords,
)

logger = logging.getLogger(__name__)

# Module-level cache for TDO records with TTL
# Maps tdo_id -> (timestamp, record)
_tdo_record_cache: dict[str, tuple[float, GetTdosByIdWithAssetsTemporalDataObjectsRecords]] = {}
_TDO_CACHE_TTL = 300  # 5 minutes


def _clean_expired_cache() -> None:
    """Remove expired entries from the TDO record cache."""
    now = time.time()
    expired = [k for k, (ts, _) in _tdo_record_cache.items() if now - ts > _TDO_CACHE_TTL]
    for k in expired:
        del _tdo_record_cache[k]


def _get_cached_tdo_record(tdo_id: str) -> GetTdosByIdWithAssetsTemporalDataObjectsRecords | None:
    """Get a TDO record from cache if not expired."""
    if tdo_id in _tdo_record_cache:
        ts, record = _tdo_record_cache[tdo_id]
        if time.time() - ts < _TDO_CACHE_TTL:
            return record
        else:
            del _tdo_record_cache[tdo_id]
    return None


def _cache_tdo_record(tdo_id: str, record: GetTdosByIdWithAssetsTemporalDataObjectsRecords) -> None:
    """Store a TDO record in cache."""
    _tdo_record_cache[tdo_id] = (time.time(), record)

logger = logging.getLogger(__name__)


def engine_category_in_signals(engine_category: str, signals: list[Signal]) -> bool:
    """Check if the engine category corresponds to any of the requested signals."""
    # Currently this is a straight 1:1 mapping, in case this changes we can expand this function
    if engine_category in signals:
        return True
    return False


class MediaTDO:
    """Simple wrapper around aiWARE TDO data with segments.

    Uses the same field names as TDO_SCHEMA to avoid duplication.
    """

    def __init__(self, **kwargs):
        # Store all TDO fields directly using schema field names
        for field_name in TDO_SCHEMA.keys():
            setattr(self, field_name, kwargs.get(field_name))

        # Segments are separate
        self.segments: dict[str, SegmentsTable] = kwargs.get("segments", {})

    def to_dict(self) -> dict:
        """Convert to dict compatible with TDO_SCHEMA."""
        return {field: getattr(self, field, None) for field in TDO_SCHEMA.keys()}

    def to_table_row(self) -> dict:
        """Get a single row dict for creating a TDO table."""
        return self.to_dict()

    @classmethod
    # disable caching for now, we currently don't see plans fetching the same signal twice in a short time
    # and it needs a lot of memory
    #@async_lru.alru_cache(maxsize=2048, ttl=300)
    async def _fetch_segments(
        cls, aion_uris: list[str], tdo_id: str
    ) -> dict[str, SegmentsTable]:
        aion_jsons = await adownload_all(aion_uris, max_concurrent=50, timeout=120)

        # Parse them to Aion objects, populate segments
        segments_data: dict[str, list[dict]] = {}  # Signal -> list of segment dicts
        for aj in aion_jsons:
            # TODO: hack until OCR is in Aion library
            AionObjectType.OCR = "OCR"  # type: ignore

            try:
                aion = Aion.model_validate(aj, strict=False)
            except Exception as e:
                # logger.error("Failed to parse AION JSON for TDO  %s", str(tdo_id))
                continue

            # Handle top-level objects (e.g., document TEXT chunks)
            if aion.object:
                for idx, obj in enumerate(aion.object):
                    if obj.type == AionObjectType.TEXT:
                        signal = "document"
                        if signal not in segments_data:
                            segments_data[signal] = []
                        
                        segment_dict = create_segment_dict(
                            tdo_id=tdo_id,
                            start_s=0.0,  # Documents don't have time-based positions
                            end_s=0.0,
                            channel="text",
                            signal=signal,
                            score=obj.confidence,
                            label=obj.label,
                            transcript=obj.text,
                            engine_id=aion.source_engine_id,
                            engine_name=aion.source_engine_name,
                            meta={
                                "page": obj.page,
                                "paragraph": obj.paragraph,
                                "chunk_index": idx,
                            },
                        )
                        segments_data[signal].append(segment_dict)

            # Handle series (e.g., transcripts, face/logo/object detections)
            if aion.series:
                for s in aion.series:
                    channel = label = confidence = transcript = None
                    signal: Signal | None = None

                    match s:
                        # Logo detections
                        case AionSeries(
                            object=AionObject(type=AionObjectType.LOGO) as obj
                        ):
                            channel = "video"
                            signal = "logo"
                            label = obj.label
                            confidence = obj.confidence

                        # Object detections
                        case AionSeries(
                            object=AionObject(type=AionObjectType.OBJECT) as obj
                        ):
                            channel = "video"
                            signal = "object"
                            label = obj.label
                            confidence = obj.confidence

                        # Face detections
                        case AionSeries(
                            object=AionObject(type=AionObjectType.FACE) as obj
                        ):
                            channel = "video"
                            signal = "face"
                            label = obj.label
                            confidence = obj.confidence

                        # OCR
                        case AionSeries(
                            object=AionObject(type=AionObjectType.OCR) as obj
                        ):
                            channel = "video"
                            signal = "ocr"
                            label = obj.text  # text instead of label
                            confidence = obj.confidence

                        # Transcript
                        case AionSeries(words=words) if words:
                            channel = "audio"
                            signal = "transcript"
                            transcript = " ".join(
                                w.word for w in words if w.word and w.best_path
                            )

                        # Unhandled cases
                        case _:
                            logger.warning(
                                "Skipping unhandled AionSeries (TDO %s)", tdo_id
                            )
                            continue

                    if signal not in segments_data:
                        segments_data[signal] = []

                    segment_dict = create_segment_dict(
                        tdo_id=tdo_id,
                        start_s=s.start_time_ms / 1000.0,
                        end_s=s.stop_time_ms / 1000.0,
                        channel=channel,
                        signal=signal or "unknown",
                        score=confidence,
                        label=label,
                        transcript=transcript,
                        engine_id=aion.source_engine_id,
                        engine_name=aion.source_engine_name,
                        # abs_start_epoch_s=None,
                        # abs_end_epoch_s=None,
                        # bbox=None,
                        # poly=None,
                        # meta={},
                    )
                    segments_data[signal].append(segment_dict)

        # Convert segment data to DataFrames
        segments: dict[str, SegmentsTable] = {}
        for signal_key, data in segments_data.items():
            segments[signal_key] = new_segments_table(data)
        return segments

    @classmethod
    async def _from_tdo_record(
        cls,
        tdo: GetTdosByIdWithAssetsTemporalDataObjectsRecords | RAGGetTDOContentTemporalDataObject,
        include_segments: bool = True,
        signals: list[Signal] | None = None,
    ) -> "MediaTDO":
        """Create MediaTDO from a TDO record.

        Args:
            tdo: TDO record from either batch or single fetch.
            include_segments: Whether to download and parse segments.
            signals: Optional list of signals to filter segments by.

        Returns:
            MediaTDO instance.
        """
        tdo_id = tdo.id

        # Extract asset type and AION URIs
        asset_type = None
        aion_uris = []
        if tdo.assets and tdo.assets.records:
            for a in tdo.assets.records:
                try:
                    if a and a.assetType == "vtn-standard" and a.signedUri:
                        engine_category = a.sourceData.engine.category.categoryType  # type: ignore
                        if (
                            signals is None
                            or engine_category is None
                            or engine_category_in_signals(engine_category, signals)
                        ):
                            aion_uris.append(a.signedUri)
                    elif a and a.assetType == "media":
                        asset_type = a.contentType
                except Exception as e:
                    logger.warning(
                        "Error processing asset for TDO %s: %s", tdo_id, str(e)
                    )

        segments = {}
        if include_segments:
            segments = await cls._fetch_segments(aion_uris, tdo_id)

        # Calculate duration
        duration_s = None
        if tdo.startDateTime and tdo.stopDateTime:
            duration_s = (tdo.stopDateTime - tdo.startDateTime).total_seconds()

        # Use TDO_SCHEMA field names directly
        return cls(
            tdo_id=tdo.id,
            tdo_name=tdo.name,
            created_datetime=tdo.createdDateTime,
            asset_type=asset_type,
            start_datetime=tdo.startDateTime,
            stop_datetime=tdo.stopDateTime,
            duration_s=duration_s,
            segments=segments,
        )

    @classmethod
    async def _fetch_tdo_records(
        cls,
        aiware: AsyncAgentsAiware,
        tdo_ids: list[str],
        batch_size: int = 100,
    ) -> list[GetTdosByIdWithAssetsTemporalDataObjectsRecords]:
        """Fetch TDO records with caching.

        Checks module-level cache first, only fetches missing TDOs from API.
        Populates cache with fetched records for reuse.

        Args:
            aiware: AsyncAgentsAiware client.
            tdo_ids: List of TDO IDs to fetch.
            batch_size: Number of TDOs to fetch per batch (default 100, API limit).

        Returns:
            List of TDO records.
        """
        # Clean expired cache entries periodically
        _clean_expired_cache()

        unique_tdo_ids = list(set(tdo_ids))
        if not unique_tdo_ids:
            return []

        # Check cache first
        cached_records = []
        missing_ids = []
        for tdo_id in unique_tdo_ids:
            cached = _get_cached_tdo_record(tdo_id)
            if cached:
                cached_records.append(cached)
            else:
                missing_ids.append(tdo_id)

        if not missing_ids:
            logger.debug("All %d TDO records found in cache", len(cached_records))
            return cached_records

        logger.debug(
            "Cache hit: %d, fetching %d missing TDOs",
            len(cached_records),
            len(missing_ids),
        )

        # Fetch missing TDOs in batches
        fetched_records = []
        for i in range(0, len(missing_ids), batch_size):
            batch_ids = missing_ids[i : i + batch_size]
            try:
                ids_param: list[str | None] = list(batch_ids)
                response = await aiware.get_tdos_by_id_with_assets(
                    ids=ids_param, limit=batch_size, timeout=120
                )
                if response.temporalDataObjects and response.temporalDataObjects.records:
                    for rec in response.temporalDataObjects.records:
                        if rec:
                            # Cache the record
                            _cache_tdo_record(rec.id, rec)
                            fetched_records.append(rec)
            except Exception as e:
                logger.error(
                    "Error fetching TDOs batch %d-%d: %s",
                    i,
                    i + len(batch_ids),
                    str(e),
                )

        return cached_records + fetched_records

    @classmethod
    async def get_signal_stats(
        cls,
        aiware: AsyncAgentsAiware,
        tdo_ids: list[str],
        batch_size: int = 100,
    ) -> dict[str, int]:
        """Get signal statistics for TDOs without downloading segments.

        Uses the same cache as from_tdo_ids, so calling this before from_tdo_ids
        will warm the cache and avoid duplicate API calls.

        Args:
            aiware: AsyncAgentsAiware client.
            tdo_ids: List of TDO IDs to analyze.
            batch_size: Number of TDOs to fetch per batch.

        Returns:
            Dict mapping signal types to count of TDOs containing that signal.
            E.g., {"transcript": 15, "face": 10, "logo": 5, "document": 3}
        """
        tdo_records = await cls._fetch_tdo_records(aiware, tdo_ids, batch_size)

        # signal -> set of tdo_ids that have it
        signal_tdos: dict[str, set[str]] = {}

        for tdo in tdo_records:
            if not tdo.assets or not tdo.assets.records:
                continue
            for asset in tdo.assets.records:
                if not asset or asset.assetType != "vtn-standard":
                    continue
                try:
                    category = asset.sourceData.engine.category.categoryType  # type: ignore
                    if category:
                        signal_tdos.setdefault(category, set()).add(tdo.id)
                except (AttributeError, TypeError):
                    pass

        # Convert to counts
        return {signal: len(tdos) for signal, tdos in signal_tdos.items()}

    @classmethod
    async def from_tdo_ids(
        cls,
        aiware: AsyncAgentsAiware,
        tdo_ids: list[str],
        include_segments: bool = True,
        signals: list[Signal] | None = None,
        batch_size: int = 100,
    ) -> list["MediaTDO"]:
        """Fetch multiple TDOs using batch queries with pagination.

        Uses module-level cache to avoid duplicate fetches. If get_signal_stats
        was called first with the same TDO IDs, records will be served from cache.

        Args:
            aiware: AsyncAgentsAiware client.
            tdo_ids: List of TDO IDs to fetch.
            include_segments: Whether to download and parse segments.
            signals: Optional list of signals to filter segments by.
            batch_size: Number of TDOs to fetch per batch (default 100, API limit).
        """
        all_tdo_records = await cls._fetch_tdo_records(aiware, tdo_ids, batch_size)

        if not all_tdo_records:
            return []

        # Process all TDO records in parallel (for segment fetching)
        tasks = [
            cls._from_tdo_record(
                tdo_record,
                include_segments=include_segments,
                signals=signals,
            )
            for tdo_record in all_tdo_records
        ]

        results = await asyncio.gather(*tasks, return_exceptions=True)
        return [tdo for tdo in results if isinstance(tdo, MediaTDO)]

    @classmethod
    @async_lru.alru_cache(maxsize=1024, ttl=300)
    async def _fetch_tdo_content(
        cls, aiware: AsyncAgentsAiware, tdo_id: str
    ) -> RAGGetTDOContentTemporalDataObject | None:
        """Fetch TDO content with caching.

        Args:
            aiware: AsyncAgentsAiware client.
            tdo_id: TDO ID to fetch.

        Returns:
            RAGGetTDOContentTemporalDataObject or None if not found.
        """
        return (
            await aiware.rag_get_tdo_content(tdo_id, timeout=120)
        ).temporalDataObject

    @classmethod
    async def from_tdo_id(
        cls,
        aiware: AsyncAgentsAiware,
        tdo_id: str,
        include_segments: bool = True,
        signals: list[Signal] | None = None,
    ) -> "MediaTDO | None":
        """Fetch a TDO by ID, optionally download and parse its AION assets.

        Args:
            aiware: AsyncAgentsAiware client.
            tdo_id: TDO ID to fetch.
            include_segments: Whether to download and parse segments.
            signals: Optional list of signals to filter segments by.

        Returns:
            MediaTDO instance.
        """
        try:
            tdo = await cls._fetch_tdo_content(aiware, tdo_id)
        except Exception as e:
            logger.error("Error fetching TDO %s: %s", tdo_id, str(e))
            return None
        if tdo is None:
            raise ValueError(f"TDO with id {tdo_id} not found")

        return await cls._from_tdo_record(
            tdo, include_segments=include_segments, signals=signals
        )
