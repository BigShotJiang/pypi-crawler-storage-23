"""Built-in Python web viewer for minitrail traces."""

from minitrail._server.app import create_app

__all__ = ["create_app"]
