"""Single source of truth for model pricing (USD per 1M tokens)."""

MODEL_PRICING: list[tuple[str, float, float]] = [
    # Anthropic (direct API & Bedrock)
    ("claude-opus-4-6",   5,     25),
    ("claude-opus-4-5",   5,     25),
    ("claude-opus-4-1",   15,    75),
    ("claude-opus-4-0",   15,    75),
    ("claude-opus-4",     15,    75),
    ("claude-sonnet-4-6", 3,     15),
    ("claude-sonnet-4-5", 3,     15),
    ("claude-sonnet-4",   3,     15),
    ("claude-3-5-sonnet", 3,     15),
    ("claude-3.5-sonnet", 3,     15),
    ("claude-haiku-4-5",  1,     5),
    ("claude-3-haiku",    0.25,  1.25),
    ("claude-3.5-haiku",  1,     5),
    # Amazon Nova
    ("nova-pro",          0.80,  3.20),
    ("nova-lite",         0.06,  0.24),
    ("nova-micro",        0.035, 0.14),
    # OpenAI
    ("gpt-4o",            2.50,  10),
    ("gpt-4o-mini",       0.15,  0.60),
    ("gpt-4-turbo",       10,    30),
    # Mistral
    ("mistral-large",     2,     6),
    ("mistral-small",     0.2,   0.6),
    # Meta Llama (Bedrock)
    ("llama3-70b",        2.65,  3.50),
    ("llama3-8b",         0.22,  0.22),
]


def cost_per_1m(model: str) -> tuple[float, float] | None:
    """Return (input, output) cost per 1M tokens, or None if model unknown."""
    low = model.lower()
    for pat, pi, po in MODEL_PRICING:
        if pat in low:
            return (pi, po)
    return None


def compute_cost(model: str, inp: int, out: int) -> float:
    """Compute cost in USD for given token counts."""
    pricing = cost_per_1m(model)
    if pricing is None:
        return 0.0
    pi, po = pricing
    return (inp / 1_000_000) * pi + (out / 1_000_000) * po
