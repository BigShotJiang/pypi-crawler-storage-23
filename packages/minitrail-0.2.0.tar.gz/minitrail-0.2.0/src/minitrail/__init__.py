"""Lightweight file-based OTel tracing for AI agent frameworks — with built-in viewer.

Usage (must be called before framework imports for auto-instrumentation):

    from minitrail import setup
    provider = setup()                                      # JSON only
    provider = setup("my-service", "logs", markdown=True)   # JSON + live Markdown
"""

from minitrail._setup import setup
from minitrail._exporter import FilePerTraceExporter
from minitrail._markdown_exporter import MarkdownTraceExporter

__all__ = ["setup", "FilePerTraceExporter", "MarkdownTraceExporter"]
