"""Allow ``python -m minitrail``."""

from minitrail.cli import main

main()
