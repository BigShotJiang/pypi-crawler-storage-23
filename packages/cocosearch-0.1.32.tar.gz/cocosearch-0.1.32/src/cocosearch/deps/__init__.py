"""Dependency graph framework for cocosearch."""
