# Make the protobuf modules importable from ff_jwt.protos
from . import my_pb2, output_pb2