class FFJWTError(Exception):
    """Base exception for ff_jwt."""
    pass

class TokenRetrievalError(FFJWTError):
    """Raised when the token could not be obtained."""
    pass

class InvalidCredentialsError(TokenRetrievalError):
    """Invalid UID/password or access token."""
    pass

class InvalidPlatformError(TokenRetrievalError):
    """Account is registered on another platform."""
    pass