import binascii
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

AES_KEY = b'Yg&tc%DEuh6%Zc^8'      # 16 bytes
AES_IV  = b'6oyZDr22E3ychjM%'      # 16 bytes

def encrypt_message(plaintext: bytes) -> bytes:
    """Encrypt plaintext using AES-128-CBC with PKCS7 padding."""
    cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
    padded = pad(plaintext, AES.block_size)
    return cipher.encrypt(padded)

def bytes_to_hex(data: bytes) -> str:
    return binascii.hexlify(data).decode('utf-8')