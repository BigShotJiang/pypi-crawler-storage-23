# ff_jwt

A Python library to obtain Free Fire JWT tokens.

## Installation

```bash
pip install ff_jwt