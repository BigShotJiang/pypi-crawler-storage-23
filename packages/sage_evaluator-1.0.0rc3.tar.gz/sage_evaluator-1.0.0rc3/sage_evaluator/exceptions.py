"""Custom exceptions for Sage Evaluator."""


class EvaluatorError(Exception):
    """Base exception for all evaluator errors."""


class ValidationError(EvaluatorError):
    """Raised when agent/skill validation fails."""


class DiscoveryError(EvaluatorError):
    """Raised when model discovery fails."""


class BenchmarkError(EvaluatorError):
    """Raised when benchmark execution fails."""


class EvaluationError(EvaluatorError):
    """Raised when LLM-as-judge evaluation fails."""


class SuggestionError(EvaluatorError):
    """Raised when suggestion analysis fails."""


class PricingError(EvaluatorError):
    """Raised when pricing lookup fails."""
