"""Stellar Memory - AI Memory Platform SDK.

Give any AI human-like memory, built on a celestial structure.

v3.0: Clean SDK with 11 core exports. For v2.0 imports, use stellar_memory.compat.
"""

# 1. Main Class
from stellar_memory.stellar import StellarMemory

# 2. Builder
from stellar_memory.builder import StellarBuilder, Preset

# 3. Core Models
from stellar_memory.models import MemoryItem, MemoryStats

# 4. Plugin Interface
from stellar_memory.plugin import MemoryPlugin

# 5. Extension Protocols
from stellar_memory.protocols import (
    StorageBackendProtocol,
    EmbedderProvider,
    ImportanceEvaluator,
    MemoryStore,
)

# 6. Config
from stellar_memory.config import StellarConfig

try:
    from importlib.metadata import version as _pkg_version
    __version__ = _pkg_version("stellar-memory")
except Exception:
    __version__ = "3.0.0"

__all__ = [
    # Main
    "StellarMemory",
    # Builder
    "StellarBuilder",
    "Preset",
    # Models
    "MemoryItem",
    "MemoryStats",
    # Plugin
    "MemoryPlugin",
    # Protocols
    "StorageBackendProtocol",
    "EmbedderProvider",
    "ImportanceEvaluator",
    "MemoryStore",
    # Config
    "StellarConfig",
]


# --- Backward compatibility ---
# v2.0 imports (e.g., `from stellar_memory import EventBus`) are redirected
# to their module-level locations with a deprecation warning.

import importlib as _importlib
import warnings as _warnings

# Lazy-load v2.0 exports with deprecation warnings
_V2_COMPAT_MAP: dict[str, tuple[str, str]] = {
    # Config classes
    "MemoryFunctionConfig": (".config", "MemoryFunctionConfig"),
    "ZoneConfig": (".config", "ZoneConfig"),
    "EmbedderConfig": (".config", "EmbedderConfig"),
    "LLMConfig": (".config", "LLMConfig"),
    "TunerConfig": (".config", "TunerConfig"),
    "ConsolidationConfig": (".config", "ConsolidationConfig"),
    "SessionConfig": (".config", "SessionConfig"),
    "NamespaceConfig": (".config", "NamespaceConfig"),
    "GraphConfig": (".config", "GraphConfig"),
    "DecayConfig": (".config", "DecayConfig"),
    "EventLoggerConfig": (".config", "EventLoggerConfig"),
    "RecallConfig": (".config", "RecallConfig"),
    "VectorIndexConfig": (".config", "VectorIndexConfig"),
    "SummarizationConfig": (".config", "SummarizationConfig"),
    "AdaptiveDecayConfig": (".config", "AdaptiveDecayConfig"),
    "GraphAnalyticsConfig": (".config", "GraphAnalyticsConfig"),
    "StorageConfig": (".config", "StorageConfig"),
    "SyncConfig": (".config", "SyncConfig"),
    "SecurityConfig": (".config", "SecurityConfig"),
    "ConnectorConfig": (".config", "ConnectorConfig"),
    "DashboardConfig": (".config", "DashboardConfig"),
    "EmotionConfig": (".config", "EmotionConfig"),
    "ServerConfig": (".config", "ServerConfig"),
    "MetacognitionConfig": (".config", "MetacognitionConfig"),
    "SelfLearningConfig": (".config", "SelfLearningConfig"),
    "MultimodalConfig": (".config", "MultimodalConfig"),
    "ReasoningConfig": (".config", "ReasoningConfig"),
    "BenchmarkConfig": (".config", "BenchmarkConfig"),
    # Removed in v3.0 (redirect to compat for error messages)
    # "BillingConfig" removed, "OnboardConfig" removed, "KnowledgeBaseConfig" removed
    # Models
    "ScoreBreakdown": (".models", "ScoreBreakdown"),
    "ReorbitResult": (".models", "ReorbitResult"),
    "EvaluationResult": (".models", "EvaluationResult"),
    "FeedbackRecord": (".models", "FeedbackRecord"),
    "ConsolidationResult": (".models", "ConsolidationResult"),
    "SessionInfo": (".models", "SessionInfo"),
    "MemorySnapshot": (".models", "MemorySnapshot"),
    "MemoryEdge": (".models", "MemoryEdge"),
    "DecayResult": (".models", "DecayResult"),
    "HealthStatus": (".models", "HealthStatus"),
    "SummarizationResult": (".models", "SummarizationResult"),
    "ChangeEvent": (".models", "ChangeEvent"),
    "AccessRole": (".models", "AccessRole"),
    "IngestResult": (".models", "IngestResult"),
    "ZoneDistribution": (".models", "ZoneDistribution"),
    "EmotionVector": (".models", "EmotionVector"),
    "TimelineEntry": (".models", "TimelineEntry"),
    "IntrospectionResult": (".models", "IntrospectionResult"),
    "ConfidentRecall": (".models", "ConfidentRecall"),
    "RecallLog": (".models", "RecallLog"),
    "OptimizationReport": (".models", "OptimizationReport"),
    "ReasoningResult": (".models", "ReasoningResult"),
    "Contradiction": (".models", "Contradiction"),
    "BenchmarkReport": (".models", "BenchmarkReport"),
    # Core classes
    "EventBus": (".event_bus", "EventBus"),
    "MemoryGraph": (".memory_graph", "MemoryGraph"),
    "PersistentMemoryGraph": (".persistent_graph", "PersistentMemoryGraph"),
    "NamespaceManager": (".namespace", "NamespaceManager"),
    "DecayManager": (".decay_manager", "DecayManager"),
    "EventLogger": (".event_logger", "EventLogger"),
    "MemoryMiddleware": (".llm_adapter", "MemoryMiddleware"),
    "AnthropicAdapter": (".llm_adapter", "AnthropicAdapter"),
    "VectorIndex": (".vector_index", "VectorIndex"),
    "BruteForceIndex": (".vector_index", "BruteForceIndex"),
    "BallTreeIndex": (".vector_index", "BallTreeIndex"),
    "MemorySummarizer": (".summarizer", "MemorySummarizer"),
    "AdaptiveDecayManager": (".adaptive_decay", "AdaptiveDecayManager"),
    "GraphAnalyzer": (".graph_analyzer", "GraphAnalyzer"),
    "GraphStats": (".graph_analyzer", "GraphStats"),
    "CentralityResult": (".graph_analyzer", "CentralityResult"),
    "ProviderRegistry": (".providers", "ProviderRegistry"),
    "StorageBackend": (".storage", "StorageBackend"),
    "EncryptionManager": (".security.encryption", "EncryptionManager"),
    "AccessControl": (".security.access_control", "AccessControl"),
    "SecurityAudit": (".security.audit", "SecurityAudit"),
    "MemorySyncManager": (".sync", "MemorySyncManager"),
    "EmotionAnalyzer": (".emotion", "EmotionAnalyzer"),
    "MemoryStream": (".stream", "MemoryStream"),
    "Introspector": (".metacognition", "Introspector"),
    "ConfidenceScorer": (".metacognition", "ConfidenceScorer"),
    "ContentTypeHandler": (".multimodal", "ContentTypeHandler"),
    "TextHandler": (".multimodal", "TextHandler"),
    "CodeHandler": (".multimodal", "CodeHandler"),
    "JsonHandler": (".multimodal", "JsonHandler"),
    "get_handler": (".multimodal", "get_handler"),
    "detect_content_type": (".multimodal", "detect_content_type"),
    "PatternCollector": (".self_learning", "PatternCollector"),
    "WeightOptimizer": (".self_learning", "WeightOptimizer"),
    "MemoryReasoner": (".reasoning", "MemoryReasoner"),
    "ContradictionDetector": (".reasoning", "ContradictionDetector"),
    "StandardDataset": (".benchmark", "StandardDataset"),
    "MemoryBenchmark": (".benchmark", "MemoryBenchmark"),
}


def __getattr__(name: str):
    if name in _V2_COMPAT_MAP:
        module_path, attr = _V2_COMPAT_MAP[name]
        _warnings.warn(
            f"Importing '{name}' from stellar_memory is deprecated in v3.0. "
            f"Use 'from stellar_memory{module_path} import {attr}' instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        module = _importlib.import_module(module_path, package="stellar_memory")
        return getattr(module, attr)
    raise AttributeError(f"module 'stellar_memory' has no attribute {name}")
