"""Module which stores the current software version."""

__version__ = "0.10.4"
