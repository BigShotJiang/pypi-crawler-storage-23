"""Detector geometry module."""

from .base import Geometry
from .manager import GeoManager
