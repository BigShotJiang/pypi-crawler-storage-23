"""SocialPay error types."""

from typing import Any, Optional


class SocialPayError(Exception):
    """Raised when a SocialPay API call fails.

    Attributes:
        status_code: HTTP or SocialPay-level error code.
        response: The raw response body, if available.
    """

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response: Optional[Any] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response = response

    def __repr__(self) -> str:
        return (
            f"SocialPayError({self.args[0]!r}, "
            f"status_code={self.status_code!r})"
        )
