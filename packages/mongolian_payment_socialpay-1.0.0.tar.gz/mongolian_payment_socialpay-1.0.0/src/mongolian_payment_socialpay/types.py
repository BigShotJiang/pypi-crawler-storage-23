"""SocialPay data types."""

from dataclasses import dataclass
from typing import Any, Dict, Optional


# ── Configuration ──


@dataclass
class SocialPayConfig:
    """Configuration required to initialise a SocialPay client.

    Attributes:
        terminal: Terminal ID assigned by SocialPay.
        secret: HMAC secret key.
        endpoint: Base URL of the SocialPay API
                  (e.g. ``"https://api.socialpay.mn"``).
    """

    terminal: str
    secret: str
    endpoint: str


# ── Wire-format request types (sent to the API) ──


@dataclass
class SocialPayInvoicePhoneRequest:
    phone: str
    amount: str
    invoice: str
    terminal: str
    checksum: str


@dataclass
class SocialPayInvoiceSimpleRequest:
    amount: str
    invoice: str
    terminal: str
    checksum: str


@dataclass
class SocialPaySettlementRequest:
    settlement_id: str
    checksum: str
    terminal: str


# ── Raw API response envelope ──


@dataclass
class SocialPayRawResponseHeader:
    status: str
    code: int


@dataclass
class SocialPayRawResponseBody:
    response: Dict[str, Any]
    error: Dict[str, Any]


@dataclass
class SocialPayRawResponse:
    header: SocialPayRawResponseHeader
    body: SocialPayRawResponseBody


# ── Parsed response types ──


@dataclass
class SocialPaySimpleResponse:
    """Result of invoice creation or cancellation."""

    description: str
    status: str


@dataclass
class SocialPayTransactionResponse:
    """Result of a transaction check or cancellation."""

    approval_code: str
    amount: float
    card_number: str
    response_description: str
    response_code: str
    terminal: str
    invoice: str
    checksum: str


@dataclass
class SocialPaySettlementResponse:
    """Result of a settlement request."""

    amount: float
    count: int
    status: str


@dataclass
class SocialPayErrorResponse:
    """Error detail returned inside a response body."""

    error_description: str
    error_type: str
