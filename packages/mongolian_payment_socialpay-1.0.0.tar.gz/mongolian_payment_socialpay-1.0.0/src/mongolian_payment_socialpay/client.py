"""SocialPay payment client (sync and async)."""

import hashlib
import hmac
from typing import Any, Dict

import httpx

from .errors import SocialPayError
from .types import (
    SocialPayConfig,
    SocialPayRawResponse,
    SocialPayRawResponseBody,
    SocialPayRawResponseHeader,
    SocialPaySettlementResponse,
    SocialPaySimpleResponse,
    SocialPayTransactionResponse,
)


# ── Shared helpers ──


def _generate_checksum(secret: str, *parts: str) -> str:
    """Generate HMAC-SHA256 checksum.

    All *parts* are concatenated (no separator) and signed with *secret*.
    """
    data = "".join(parts)
    return hmac.new(
        secret.encode("utf-8"),
        data.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


def _validate_config(config: SocialPayConfig) -> None:
    if not config.terminal:
        raise ValueError("SocialPayClient: terminal is required")
    if not config.secret:
        raise ValueError("SocialPayClient: secret is required")
    if not config.endpoint:
        raise ValueError("SocialPayClient: endpoint is required")


def _parse_raw(json_data: Dict[str, Any]) -> SocialPayRawResponse:
    header_data = json_data.get("header", {})
    body_data = json_data.get("body", {})
    return SocialPayRawResponse(
        header=SocialPayRawResponseHeader(
            status=str(header_data.get("status", "")),
            code=int(header_data.get("code", 0)),
        ),
        body=SocialPayRawResponseBody(
            response=body_data.get("response", {}),
            error=body_data.get("error", {}),
        ),
    )


def _check_api_error(raw: SocialPayRawResponse, status_code: int) -> None:
    """Raise :class:`SocialPayError` on HTTP or API-level errors."""
    if status_code < 200 or status_code >= 300:
        raise SocialPayError(
            f"SocialPay API error: HTTP {status_code}",
            status_code=status_code,
            response=raw,
        )

    if raw.header and raw.header.code != 200:
        err_body = raw.body.error if raw.body else {}
        desc = (
            err_body.get("errorDesc")
            or err_body.get("errorType")
            or raw.header.status
        )
        raise SocialPayError(
            f"SocialPay error ({raw.header.code}): {desc}",
            status_code=raw.header.code,
            response=raw,
        )


def _parse_simple(raw: SocialPayRawResponse) -> SocialPaySimpleResponse:
    r = raw.body.response if raw.body else {}
    return SocialPaySimpleResponse(
        description=str(r.get("desc", "")),
        status=str(r.get("status", "") or (raw.header.status if raw.header else "")),
    )


def _parse_transaction(raw: SocialPayRawResponse) -> SocialPayTransactionResponse:
    r = raw.body.response if raw.body else {}
    return SocialPayTransactionResponse(
        approval_code=str(r.get("approval_code", "")),
        amount=float(r.get("amount", 0)),
        card_number=str(r.get("card_number", "")),
        response_description=str(r.get("resp_desc", "")),
        response_code=str(r.get("resp_code", "")),
        terminal=str(r.get("terminal", "")),
        invoice=str(r.get("invoice", "")),
        checksum=str(r.get("checksum", "")),
    )


def _parse_settlement(raw: SocialPayRawResponse) -> SocialPaySettlementResponse:
    r = raw.body.response if raw.body else {}
    return SocialPaySettlementResponse(
        amount=float(r.get("amount", 0)),
        count=int(r.get("count", 0)),
        status=str(r.get("status", "") or (raw.header.status if raw.header else "")),
    )


# ── Synchronous client ──


class SocialPayClient:
    """Synchronous SocialPay payment client.

    All methods automatically compute the required HMAC-SHA256 checksum
    so callers never need to deal with checksum generation.
    """

    def __init__(self, config: SocialPayConfig) -> None:
        _validate_config(config)
        self._terminal = config.terminal
        self._secret = config.secret
        self._endpoint = config.endpoint.rstrip("/")
        self._http = httpx.Client()

    # ── Context manager ──

    def __enter__(self) -> "SocialPayClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._http.close()

    # ── Public API ──

    def invoice_phone(
        self, amount: float, invoice: str, phone: str
    ) -> SocialPaySimpleResponse:
        """Create an invoice and send a push notification to *phone*."""
        checksum = _generate_checksum(
            self._secret, self._terminal, invoice, str(amount), phone
        )
        body = {
            "phone": phone,
            "amount": str(amount),
            "invoice": invoice,
            "terminal": self._terminal,
            "checksum": checksum,
        }
        raw = self._post("/pos/invoice/phone", body)
        return _parse_simple(raw)

    def invoice_qr(
        self, amount: float, invoice: str
    ) -> SocialPaySimpleResponse:
        """Create an invoice and return a QR code payload."""
        checksum = _generate_checksum(
            self._secret, self._terminal, invoice, str(amount)
        )
        body = {
            "amount": str(amount),
            "invoice": invoice,
            "terminal": self._terminal,
            "checksum": checksum,
        }
        raw = self._post("/pos/invoice/qr", body)
        return _parse_simple(raw)

    def check_transaction(
        self, amount: float, invoice: str
    ) -> SocialPayTransactionResponse:
        """Check the status of an existing transaction."""
        checksum = _generate_checksum(
            self._secret, self._terminal, invoice, str(amount)
        )
        body = {
            "amount": str(amount),
            "invoice": invoice,
            "terminal": self._terminal,
            "checksum": checksum,
        }
        raw = self._post("/pos/invoice/check", body)
        return _parse_transaction(raw)

    def cancel_invoice(
        self, amount: float, invoice: str
    ) -> SocialPaySimpleResponse:
        """Cancel a pending invoice."""
        checksum = _generate_checksum(
            self._secret, self._terminal, invoice, str(amount)
        )
        body = {
            "amount": str(amount),
            "invoice": invoice,
            "terminal": self._terminal,
            "checksum": checksum,
        }
        raw = self._post("/pos/invoice/cancel", body)
        return _parse_simple(raw)

    def cancel_transaction(
        self, amount: float, invoice: str
    ) -> SocialPayTransactionResponse:
        """Cancel a completed transaction."""
        checksum = _generate_checksum(
            self._secret, self._terminal, invoice, str(amount)
        )
        body = {
            "amount": str(amount),
            "invoice": invoice,
            "terminal": self._terminal,
            "checksum": checksum,
        }
        raw = self._post("/pos/payment/cancel", body)
        return _parse_transaction(raw)

    def transaction_settlement(
        self, settlement_id: str
    ) -> SocialPaySettlementResponse:
        """Perform a transaction settlement."""
        checksum = _generate_checksum(
            self._secret, self._terminal, settlement_id
        )
        body = {
            "settlementId": settlement_id,
            "checksum": checksum,
            "terminal": self._terminal,
        }
        raw = self._post("/pos/settlement", body)
        return _parse_settlement(raw)

    # ── Private helpers ──

    def _post(self, path: str, body: Dict[str, Any]) -> SocialPayRawResponse:
        url = f"{self._endpoint}{path}"
        try:
            res = self._http.post(
                url,
                json=body,
                headers={"Content-Type": "application/json"},
            )
        except httpx.HTTPError as exc:
            raise SocialPayError(
                f"Network error calling {path}: {exc}"
            ) from exc

        try:
            json_data = res.json()
        except Exception:
            raise SocialPayError(
                f"Invalid JSON response from {path}",
                status_code=res.status_code,
            )

        raw = _parse_raw(json_data)
        _check_api_error(raw, res.status_code)
        return raw


# ── Asynchronous client ──


class AsyncSocialPayClient:
    """Asynchronous SocialPay payment client.

    All methods automatically compute the required HMAC-SHA256 checksum
    so callers never need to deal with checksum generation.
    """

    def __init__(self, config: SocialPayConfig) -> None:
        _validate_config(config)
        self._terminal = config.terminal
        self._secret = config.secret
        self._endpoint = config.endpoint.rstrip("/")
        self._http = httpx.AsyncClient()

    # ── Async context manager ──

    async def __aenter__(self) -> "AsyncSocialPayClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._http.aclose()

    # ── Public API ──

    async def invoice_phone(
        self, amount: float, invoice: str, phone: str
    ) -> SocialPaySimpleResponse:
        """Create an invoice and send a push notification to *phone*."""
        checksum = _generate_checksum(
            self._secret, self._terminal, invoice, str(amount), phone
        )
        body = {
            "phone": phone,
            "amount": str(amount),
            "invoice": invoice,
            "terminal": self._terminal,
            "checksum": checksum,
        }
        raw = await self._post("/pos/invoice/phone", body)
        return _parse_simple(raw)

    async def invoice_qr(
        self, amount: float, invoice: str
    ) -> SocialPaySimpleResponse:
        """Create an invoice and return a QR code payload."""
        checksum = _generate_checksum(
            self._secret, self._terminal, invoice, str(amount)
        )
        body = {
            "amount": str(amount),
            "invoice": invoice,
            "terminal": self._terminal,
            "checksum": checksum,
        }
        raw = await self._post("/pos/invoice/qr", body)
        return _parse_simple(raw)

    async def check_transaction(
        self, amount: float, invoice: str
    ) -> SocialPayTransactionResponse:
        """Check the status of an existing transaction."""
        checksum = _generate_checksum(
            self._secret, self._terminal, invoice, str(amount)
        )
        body = {
            "amount": str(amount),
            "invoice": invoice,
            "terminal": self._terminal,
            "checksum": checksum,
        }
        raw = await self._post("/pos/invoice/check", body)
        return _parse_transaction(raw)

    async def cancel_invoice(
        self, amount: float, invoice: str
    ) -> SocialPaySimpleResponse:
        """Cancel a pending invoice."""
        checksum = _generate_checksum(
            self._secret, self._terminal, invoice, str(amount)
        )
        body = {
            "amount": str(amount),
            "invoice": invoice,
            "terminal": self._terminal,
            "checksum": checksum,
        }
        raw = await self._post("/pos/invoice/cancel", body)
        return _parse_simple(raw)

    async def cancel_transaction(
        self, amount: float, invoice: str
    ) -> SocialPayTransactionResponse:
        """Cancel a completed transaction."""
        checksum = _generate_checksum(
            self._secret, self._terminal, invoice, str(amount)
        )
        body = {
            "amount": str(amount),
            "invoice": invoice,
            "terminal": self._terminal,
            "checksum": checksum,
        }
        raw = await self._post("/pos/payment/cancel", body)
        return _parse_transaction(raw)

    async def transaction_settlement(
        self, settlement_id: str
    ) -> SocialPaySettlementResponse:
        """Perform a transaction settlement."""
        checksum = _generate_checksum(
            self._secret, self._terminal, settlement_id
        )
        body = {
            "settlementId": settlement_id,
            "checksum": checksum,
            "terminal": self._terminal,
        }
        raw = await self._post("/pos/settlement", body)
        return _parse_settlement(raw)

    # ── Private helpers ──

    async def _post(self, path: str, body: Dict[str, Any]) -> SocialPayRawResponse:
        url = f"{self._endpoint}{path}"
        try:
            res = await self._http.post(
                url,
                json=body,
                headers={"Content-Type": "application/json"},
            )
        except httpx.HTTPError as exc:
            raise SocialPayError(
                f"Network error calling {path}: {exc}"
            ) from exc

        try:
            json_data = res.json()
        except Exception:
            raise SocialPayError(
                f"Invalid JSON response from {path}",
                status_code=res.status_code,
            )

        raw = _parse_raw(json_data)
        _check_api_error(raw, res.status_code)
        return raw
