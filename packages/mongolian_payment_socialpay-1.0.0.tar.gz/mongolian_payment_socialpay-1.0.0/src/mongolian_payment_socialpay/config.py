"""SocialPay configuration helpers."""

import os

from .types import SocialPayConfig


def load_config_from_env() -> SocialPayConfig:
    """Load SocialPay configuration from environment variables.

    Required environment variables:
        - ``SOCIALPAY_TERMINAL``
        - ``SOCIALPAY_SECRET``
        - ``SOCIALPAY_ENDPOINT``

    Returns:
        A :class:`SocialPayConfig` populated from the environment.

    Raises:
        EnvironmentError: If any required variable is missing.
    """
    terminal = os.environ.get("SOCIALPAY_TERMINAL")
    secret = os.environ.get("SOCIALPAY_SECRET")
    endpoint = os.environ.get("SOCIALPAY_ENDPOINT")

    if not terminal:
        raise EnvironmentError(
            "Missing environment variable: SOCIALPAY_TERMINAL"
        )
    if not secret:
        raise EnvironmentError(
            "Missing environment variable: SOCIALPAY_SECRET"
        )
    if not endpoint:
        raise EnvironmentError(
            "Missing environment variable: SOCIALPAY_ENDPOINT"
        )

    return SocialPayConfig(terminal=terminal, secret=secret, endpoint=endpoint)
