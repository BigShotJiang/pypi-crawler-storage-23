"""Tests for the SocialPay Python SDK."""

import hashlib
import hmac
import json
from unittest.mock import MagicMock, AsyncMock, patch

import pytest

from mongolian_payment_socialpay import (
    SocialPayClient,
    AsyncSocialPayClient,
    SocialPayError,
    SocialPayConfig,
    load_config_from_env,
)
from mongolian_payment_socialpay.client import _generate_checksum


# ── Fixtures ──

TERMINAL = "TEST_TERMINAL"
SECRET = "test_secret_key"
ENDPOINT = "https://api.socialpay.mn"

CONFIG = SocialPayConfig(terminal=TERMINAL, secret=SECRET, endpoint=ENDPOINT)


def _success_response(response_body: dict) -> dict:
    """Build a successful SocialPay API response envelope."""
    return {
        "header": {"status": "SUCCESS", "code": 200},
        "body": {"response": response_body, "error": {}},
    }


def _error_response(code: int, error_desc: str) -> dict:
    """Build a SocialPay API error response envelope."""
    return {
        "header": {"status": "FAILURE", "code": code},
        "body": {
            "response": {},
            "error": {"errorDesc": error_desc, "errorType": "BUSINESS_ERROR"},
        },
    }


def _mock_httpx_response(json_data: dict, status_code: int = 200) -> MagicMock:
    mock_resp = MagicMock()
    mock_resp.status_code = status_code
    mock_resp.json.return_value = json_data
    return mock_resp


# ── Checksum tests ──


class TestChecksum:
    def test_generate_checksum(self):
        """Checksum should be HMAC-SHA256 of concatenated parts."""
        result = _generate_checksum(SECRET, "A", "B", "C")
        expected = hmac.new(
            SECRET.encode("utf-8"),
            b"ABC",
            hashlib.sha256,
        ).hexdigest()
        assert result == expected

    def test_checksum_matches_js_logic(self):
        """Verify the checksum matches the JS SDK's logic."""
        parts = [TERMINAL, "INV001", "5000"]
        result = _generate_checksum(SECRET, *parts)
        data = "".join(parts).encode("utf-8")
        expected = hmac.new(
            SECRET.encode("utf-8"), data, hashlib.sha256
        ).hexdigest()
        assert result == expected

    def test_checksum_with_phone(self):
        """Checksum for invoice_phone includes the phone number."""
        parts = [TERMINAL, "INV002", "1000", "99001234"]
        result = _generate_checksum(SECRET, *parts)
        data = "".join(parts).encode("utf-8")
        expected = hmac.new(
            SECRET.encode("utf-8"), data, hashlib.sha256
        ).hexdigest()
        assert result == expected


# ── Config validation tests ──


class TestConfig:
    def test_missing_terminal(self):
        with pytest.raises(ValueError, match="terminal is required"):
            SocialPayClient(SocialPayConfig(terminal="", secret=SECRET, endpoint=ENDPOINT))

    def test_missing_secret(self):
        with pytest.raises(ValueError, match="secret is required"):
            SocialPayClient(SocialPayConfig(terminal=TERMINAL, secret="", endpoint=ENDPOINT))

    def test_missing_endpoint(self):
        with pytest.raises(ValueError, match="endpoint is required"):
            SocialPayClient(SocialPayConfig(terminal=TERMINAL, secret=SECRET, endpoint=""))

    def test_load_config_from_env(self, monkeypatch):
        monkeypatch.setenv("SOCIALPAY_TERMINAL", TERMINAL)
        monkeypatch.setenv("SOCIALPAY_SECRET", SECRET)
        monkeypatch.setenv("SOCIALPAY_ENDPOINT", ENDPOINT)
        cfg = load_config_from_env()
        assert cfg.terminal == TERMINAL
        assert cfg.secret == SECRET
        assert cfg.endpoint == ENDPOINT

    def test_load_config_from_env_missing(self, monkeypatch):
        monkeypatch.delenv("SOCIALPAY_TERMINAL", raising=False)
        monkeypatch.delenv("SOCIALPAY_SECRET", raising=False)
        monkeypatch.delenv("SOCIALPAY_ENDPOINT", raising=False)
        with pytest.raises(EnvironmentError, match="SOCIALPAY_TERMINAL"):
            load_config_from_env()


# ── Sync client tests ──


class TestSocialPayClient:
    @patch("mongolian_payment_socialpay.client.httpx.Client")
    def test_invoice_phone(self, mock_client_cls):
        mock_http = MagicMock()
        mock_client_cls.return_value = mock_http
        mock_http.post.return_value = _mock_httpx_response(
            _success_response({"desc": "Invoice sent", "status": "SUCCESS"})
        )

        client = SocialPayClient(CONFIG)
        result = client.invoice_phone(5000, "INV001", "99001234")

        assert result.description == "Invoice sent"
        assert result.status == "SUCCESS"

        call_args = mock_http.post.call_args
        assert "/pos/invoice/phone" in call_args[0][0]
        body = call_args[1]["json"]
        assert body["phone"] == "99001234"
        assert body["amount"] == "5000"
        assert body["invoice"] == "INV001"
        assert body["terminal"] == TERMINAL
        assert body["checksum"] == _generate_checksum(
            SECRET, TERMINAL, "INV001", "5000", "99001234"
        )

    @patch("mongolian_payment_socialpay.client.httpx.Client")
    def test_invoice_qr(self, mock_client_cls):
        mock_http = MagicMock()
        mock_client_cls.return_value = mock_http
        mock_http.post.return_value = _mock_httpx_response(
            _success_response({"desc": "QR generated", "status": "SUCCESS"})
        )

        client = SocialPayClient(CONFIG)
        result = client.invoice_qr(3000, "INV002")

        assert result.description == "QR generated"
        assert result.status == "SUCCESS"

        call_args = mock_http.post.call_args
        assert "/pos/invoice/qr" in call_args[0][0]
        body = call_args[1]["json"]
        assert body["amount"] == "3000"
        assert body["checksum"] == _generate_checksum(
            SECRET, TERMINAL, "INV002", "3000"
        )

    @patch("mongolian_payment_socialpay.client.httpx.Client")
    def test_check_transaction(self, mock_client_cls):
        mock_http = MagicMock()
        mock_client_cls.return_value = mock_http
        mock_http.post.return_value = _mock_httpx_response(
            _success_response({
                "approval_code": "AP123",
                "amount": 5000,
                "card_number": "4111****1111",
                "resp_desc": "Approved",
                "resp_code": "00",
                "terminal": TERMINAL,
                "invoice": "INV001",
                "checksum": "abc123",
            })
        )

        client = SocialPayClient(CONFIG)
        result = client.check_transaction(5000, "INV001")

        assert result.approval_code == "AP123"
        assert result.amount == 5000
        assert result.card_number == "4111****1111"
        assert result.response_description == "Approved"
        assert result.response_code == "00"
        assert result.invoice == "INV001"

    @patch("mongolian_payment_socialpay.client.httpx.Client")
    def test_cancel_invoice(self, mock_client_cls):
        mock_http = MagicMock()
        mock_client_cls.return_value = mock_http
        mock_http.post.return_value = _mock_httpx_response(
            _success_response({"desc": "Cancelled", "status": "SUCCESS"})
        )

        client = SocialPayClient(CONFIG)
        result = client.cancel_invoice(5000, "INV001")

        assert result.description == "Cancelled"
        call_args = mock_http.post.call_args
        assert "/pos/invoice/cancel" in call_args[0][0]

    @patch("mongolian_payment_socialpay.client.httpx.Client")
    def test_cancel_transaction(self, mock_client_cls):
        mock_http = MagicMock()
        mock_client_cls.return_value = mock_http
        mock_http.post.return_value = _mock_httpx_response(
            _success_response({
                "approval_code": "AP456",
                "amount": 2000,
                "card_number": "5200****0000",
                "resp_desc": "Reversed",
                "resp_code": "00",
                "terminal": TERMINAL,
                "invoice": "INV003",
                "checksum": "def456",
            })
        )

        client = SocialPayClient(CONFIG)
        result = client.cancel_transaction(2000, "INV003")

        assert result.approval_code == "AP456"
        assert result.response_description == "Reversed"
        call_args = mock_http.post.call_args
        assert "/pos/payment/cancel" in call_args[0][0]

    @patch("mongolian_payment_socialpay.client.httpx.Client")
    def test_transaction_settlement(self, mock_client_cls):
        mock_http = MagicMock()
        mock_client_cls.return_value = mock_http
        mock_http.post.return_value = _mock_httpx_response(
            _success_response({"amount": 50000, "count": 10, "status": "SETTLED"})
        )

        client = SocialPayClient(CONFIG)
        result = client.transaction_settlement("SETTLE001")

        assert result.amount == 50000
        assert result.count == 10
        assert result.status == "SETTLED"

        call_args = mock_http.post.call_args
        assert "/pos/settlement" in call_args[0][0]
        body = call_args[1]["json"]
        assert body["settlementId"] == "SETTLE001"

    @patch("mongolian_payment_socialpay.client.httpx.Client")
    def test_api_error_code(self, mock_client_cls):
        """API-level error (header.code != 200) should raise SocialPayError."""
        mock_http = MagicMock()
        mock_client_cls.return_value = mock_http
        mock_http.post.return_value = _mock_httpx_response(
            _error_response(400, "Invalid invoice")
        )

        client = SocialPayClient(CONFIG)
        with pytest.raises(SocialPayError) as exc_info:
            client.invoice_qr(1000, "BAD")

        assert exc_info.value.status_code == 400
        assert "Invalid invoice" in str(exc_info.value)

    @patch("mongolian_payment_socialpay.client.httpx.Client")
    def test_http_error(self, mock_client_cls):
        """HTTP-level error should raise SocialPayError."""
        mock_http = MagicMock()
        mock_client_cls.return_value = mock_http
        mock_http.post.return_value = _mock_httpx_response(
            {"header": {"status": "ERROR", "code": 500}, "body": {"response": {}, "error": {}}},
            status_code=500,
        )

        client = SocialPayClient(CONFIG)
        with pytest.raises(SocialPayError) as exc_info:
            client.invoice_qr(1000, "INV")

        assert exc_info.value.status_code == 500

    @patch("mongolian_payment_socialpay.client.httpx.Client")
    def test_network_error(self, mock_client_cls):
        """Network-level error should raise SocialPayError."""
        import httpx as _httpx

        mock_http = MagicMock()
        mock_client_cls.return_value = mock_http
        mock_http.post.side_effect = _httpx.ConnectError("Connection refused")

        client = SocialPayClient(CONFIG)
        with pytest.raises(SocialPayError, match="Network error"):
            client.invoice_qr(1000, "INV")

    @patch("mongolian_payment_socialpay.client.httpx.Client")
    def test_invalid_json(self, mock_client_cls):
        """Non-JSON response should raise SocialPayError."""
        mock_http = MagicMock()
        mock_client_cls.return_value = mock_http
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.side_effect = ValueError("No JSON")
        mock_http.post.return_value = mock_resp

        client = SocialPayClient(CONFIG)
        with pytest.raises(SocialPayError, match="Invalid JSON"):
            client.invoice_qr(1000, "INV")

    @patch("mongolian_payment_socialpay.client.httpx.Client")
    def test_context_manager(self, mock_client_cls):
        mock_http = MagicMock()
        mock_client_cls.return_value = mock_http

        with SocialPayClient(CONFIG) as client:
            assert client is not None
        mock_http.close.assert_called_once()


# ── Async client tests ──


class TestAsyncSocialPayClient:
    @pytest.mark.asyncio
    @patch("mongolian_payment_socialpay.client.httpx.AsyncClient")
    async def test_invoice_phone(self, mock_client_cls):
        mock_http = MagicMock()
        mock_client_cls.return_value = mock_http
        mock_http.post = AsyncMock(
            return_value=_mock_httpx_response(
                _success_response({"desc": "Invoice sent", "status": "SUCCESS"})
            )
        )

        client = AsyncSocialPayClient(CONFIG)
        result = await client.invoice_phone(5000, "INV001", "99001234")

        assert result.description == "Invoice sent"
        assert result.status == "SUCCESS"

    @pytest.mark.asyncio
    @patch("mongolian_payment_socialpay.client.httpx.AsyncClient")
    async def test_invoice_qr(self, mock_client_cls):
        mock_http = MagicMock()
        mock_client_cls.return_value = mock_http
        mock_http.post = AsyncMock(
            return_value=_mock_httpx_response(
                _success_response({"desc": "QR generated", "status": "SUCCESS"})
            )
        )

        client = AsyncSocialPayClient(CONFIG)
        result = await client.invoice_qr(3000, "INV002")

        assert result.description == "QR generated"

    @pytest.mark.asyncio
    @patch("mongolian_payment_socialpay.client.httpx.AsyncClient")
    async def test_check_transaction(self, mock_client_cls):
        mock_http = MagicMock()
        mock_client_cls.return_value = mock_http
        mock_http.post = AsyncMock(
            return_value=_mock_httpx_response(
                _success_response({
                    "approval_code": "AP789",
                    "amount": 10000,
                    "card_number": "4222****2222",
                    "resp_desc": "Approved",
                    "resp_code": "00",
                    "terminal": TERMINAL,
                    "invoice": "INV010",
                    "checksum": "xyz789",
                })
            )
        )

        client = AsyncSocialPayClient(CONFIG)
        result = await client.check_transaction(10000, "INV010")

        assert result.approval_code == "AP789"
        assert result.amount == 10000

    @pytest.mark.asyncio
    @patch("mongolian_payment_socialpay.client.httpx.AsyncClient")
    async def test_settlement(self, mock_client_cls):
        mock_http = MagicMock()
        mock_client_cls.return_value = mock_http
        mock_http.post = AsyncMock(
            return_value=_mock_httpx_response(
                _success_response({"amount": 100000, "count": 25, "status": "SETTLED"})
            )
        )

        client = AsyncSocialPayClient(CONFIG)
        result = await client.transaction_settlement("SETTLE002")

        assert result.amount == 100000
        assert result.count == 25
        assert result.status == "SETTLED"

    @pytest.mark.asyncio
    @patch("mongolian_payment_socialpay.client.httpx.AsyncClient")
    async def test_api_error(self, mock_client_cls):
        mock_http = MagicMock()
        mock_client_cls.return_value = mock_http
        mock_http.post = AsyncMock(
            return_value=_mock_httpx_response(
                _error_response(401, "Unauthorized terminal")
            )
        )

        client = AsyncSocialPayClient(CONFIG)
        with pytest.raises(SocialPayError) as exc_info:
            await client.invoice_qr(1000, "INV")

        assert exc_info.value.status_code == 401
        assert "Unauthorized terminal" in str(exc_info.value)

    @pytest.mark.asyncio
    @patch("mongolian_payment_socialpay.client.httpx.AsyncClient")
    async def test_context_manager(self, mock_client_cls):
        mock_http = MagicMock()
        mock_client_cls.return_value = mock_http
        mock_http.aclose = AsyncMock()

        async with AsyncSocialPayClient(CONFIG) as client:
            assert client is not None
        mock_http.aclose.assert_called_once()
