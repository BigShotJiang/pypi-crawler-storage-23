# mongolian-payment-socialpay

SocialPay payment gateway SDK for Python.

Provides both **synchronous** and **asynchronous** clients with automatic
HMAC-SHA256 checksum generation.

## Installation

```bash
pip install mongolian-payment-socialpay
```

## Quick start

### Synchronous usage

```python
from mongolian_payment_socialpay import SocialPayClient, SocialPayConfig

config = SocialPayConfig(
    terminal="YOUR_TERMINAL",
    secret="YOUR_SECRET",
    endpoint="https://api.socialpay.mn",
)

with SocialPayClient(config) as client:
    # Create an invoice with phone notification
    result = client.invoice_phone(amount=5000, invoice="INV001", phone="99001234")
    print(result.description, result.status)

    # Create an invoice with QR code
    qr = client.invoice_qr(amount=3000, invoice="INV002")

    # Check a transaction
    txn = client.check_transaction(amount=5000, invoice="INV001")
    print(txn.approval_code, txn.response_code)

    # Cancel an invoice
    client.cancel_invoice(amount=5000, invoice="INV001")

    # Cancel a transaction
    client.cancel_transaction(amount=5000, invoice="INV001")

    # Settle transactions
    settlement = client.transaction_settlement(settlement_id="SETTLE001")
    print(settlement.amount, settlement.count)
```

### Asynchronous usage

```python
import asyncio
from mongolian_payment_socialpay import AsyncSocialPayClient, SocialPayConfig

config = SocialPayConfig(
    terminal="YOUR_TERMINAL",
    secret="YOUR_SECRET",
    endpoint="https://api.socialpay.mn",
)

async def main():
    async with AsyncSocialPayClient(config) as client:
        result = await client.invoice_phone(amount=5000, invoice="INV001", phone="99001234")
        print(result.description, result.status)

asyncio.run(main())
```

### Configuration from environment variables

Set the following environment variables:

```bash
export SOCIALPAY_TERMINAL="YOUR_TERMINAL"
export SOCIALPAY_SECRET="YOUR_SECRET"
export SOCIALPAY_ENDPOINT="https://api.socialpay.mn"
```

Then load them:

```python
from mongolian_payment_socialpay import SocialPayClient, load_config_from_env

config = load_config_from_env()
client = SocialPayClient(config)
```

## Error handling

All API errors raise `SocialPayError`, which includes:

- `status_code` -- the HTTP or SocialPay-level error code
- `response` -- the raw response body, if available

```python
from mongolian_payment_socialpay import SocialPayError

try:
    client.invoice_qr(amount=1000, invoice="INV999")
except SocialPayError as e:
    print(e.status_code, e.response)
```

## License

MIT
