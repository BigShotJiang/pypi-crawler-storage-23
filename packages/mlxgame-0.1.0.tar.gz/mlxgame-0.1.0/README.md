<p align="center">
    <img align="center" src="media/mlx_python_engine.jpg">
    <h1 align="center">Mlx Python Engine</h1>
</p>

<p align="center">
This work is published under the terms of <a href="LICENSE"><b>MIT license</b></a>
</p>

<div align="center">
    <img alt="Where MiniLibX meets imagination." src="media/example_of_nodes.jpg">
    <img alt="Like Unity but for 42." src="media/example_of_components.jpg">
</div>

## Overview

Procedural map generation is one of the foundations of all current and not-so-current games. If we analyze any game, we can find these algorithms everywhere, whether in the map or even in the textures.

a_maze_ing is the first Python project in the new 42 curriculum. The idea is to randomly generate a maze according to the parameters you specify and visualize it graphically. In addition, it must store a file with the maze data.

```bash
python3 a_maze_ing.py config.txt...
...
```

## Requirements

As the MiniLibX Python wrapper uses the original C library, the following packages are required:

### Arch Linux

``` bash
sudo pacman -S libxcb xcb-util-keysyms zlib libbsd vulkan-icd-loader vulkan-tools shaderc
```

### Debian/Ubuntu

``` bash
sudo apt install libxcb libxcb-keysyms libvulkan libz libbsd glslc
```

## Usage

- Download from [releases](https://github.com/dde-fite/Mlx_Python_Engine/releases) the last version of Mlx Python Engine.
- Install the wheel from pip.
```bash
pip install mlx_engine-1.0.0-py3-none-any.whl
```
- And import mlx_engine where needed.
```python
from mlx_engine import EngineManager

EngineManager.init("Test",
                   (1920, 1080),
                   [Menu])
```


## Making package
```bash
python -m build
```

## Got any suggestions?

If you find any errors or have any new ideas for improving this
repository, feel free to open an Issue or Pull Request, or contact me at
my email address: nora@defitero.com