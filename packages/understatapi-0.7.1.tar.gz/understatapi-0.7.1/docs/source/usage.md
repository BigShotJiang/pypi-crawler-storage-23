# Usage
An overview of how understatAPI can be used

## Basic Usage

TODO

## Context Manager

TODO

## Player and Match Ids

TODO
