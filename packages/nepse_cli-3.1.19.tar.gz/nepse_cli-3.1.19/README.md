# Nepse CLI - Meroshare IPO Automation & Market Data

[![PyPI version](https://badge.fury.io/py/nepse-cli.svg?cacheSeconds=1)](https://badge.fury.io/py/nepse-cli)
[![Python Version](https://img.shields.io/pypi/pyversions/nepse-cli.svg)](https://pypi.org/project/nepse-cli/)

![Nepse CLI](https://res.cloudinary.com/dzbc5mlm9/image/upload/v1768644603/nepse-cli-image_tcx7tx.png)

A professional command-line tool for NEPSE market analysis and automated Meroshare IPO applications.

**Key Features:**

- Comprehensive market data and technical analysis
- Automated IPO/FPO/Rights application (headless or GUI mode)
- Multi-member portfolio tracking and management
- Real-time stock information, signals, and announcements
- Interactive shell with command palette and autocompletion
- Fast API-based IPO application with concurrent processing

## Requirements

- Python 3.8 or higher
- Windows, Linux, or macOS
- Internet connection
- Playwright (auto-installed)
- Meroshare account for IPO features

## Installation

### PyPI (Recommended)

**Important:** Avoid Microsoft Store Python. Use [python.org](https://www.python.org/downloads/) for proper PATH configuration.

```bash
pip install nepse-cli
```

**Update:**

```bash
pip install --upgrade nepse-cli
```

**Run:**

```bash
nepse
```

If command not found, use: `python -m nepse_cli` or see [Troubleshooting](#troubleshooting).

---

### From Source

**Development Installation:**

```bash
cd "Nepse CLI"
pip install -e .
```

**Windows Quick Start:**
Double-click `start_nepse.bat` to auto-configure and launch.

**Browser Setup:**
Playwright browsers install automatically on first run. Manual installation:

```bash
playwright install chromium
```

## Usage

### Interactive Shell (Recommended)

```bash
nepse
```

Shell features include command palette (`/`), autocompletion, command history, and inline help.

### Command Categories

#### IPO Automation

```bash
nepse apply              # ⚡ Fast API-based application (single member)
nepse apply-all          # ⚡ Fast API-based apply for all members
nepse result             # Check IPO application results

# Legacy browser-based commands (deprecated)
nepse apply-legacy       # Browser-based application (will be removed)
nepse apply-all-legacy   # Browser-based apply all (will be removed)
```

#### Member Management

```bash
nepse add-member         # Add/update family member
nepse list-members       # View all members
nepse edit-member        # Edit member details
nepse delete-member      # Remove a member
nepse manage-members     # Interactive member management
```

#### Portfolio & Authentication

```bash
nepse get-portfolio      # View member portfolio
nepse test-login         # Test Meroshare login
nepse dplist             # List available depository participants
```

#### Market Data & Indices

```bash
nepse ipo                # Open IPOs/FPOs/Rights
nepse nepse              # NEPSE indices
nepse subidx BANKING     # Sector sub-indices
nepse mktsum             # Market summary
nepse topgl              # Top gainers/losers
nepse sectors            # All sector performance
```

#### Stock Analysis

```bash
nepse stonk NABIL        # Stock details and live price
nepse profile NABIL      # Company profile
nepse fundamental NABIL  # Fundamental analysis
nepse depth NABIL        # Market depth (order book)
nepse 52week             # 52-week high/low performers
nepse near52             # Stocks near 52-week marks
```

#### Trading Information

```bash
nepse floor              # Floor sheet (live trades)
nepse floor NABIL        # Filtered by symbol
nepse floor --buyer 58   # Filtered by buyer broker
nepse floor --seller 59  # Filtered by seller broker
nepse brokers            # List all NEPSE brokers (S.N., Broker No., Name)
nepse signals            # Trading signals (strong buy/sell)
nepse announce           # Latest market announcements
nepse holidays           # Upcoming market holidays
```

## Features

### IPO Automation Features

- Automated application for IPO, FPO, and Rights offerings
- Multi-member support for family-wide applications
- Browser-based (Playwright) and API-based (fast) modes
- Headless operation with optional GUI for debugging
- Automatic share quantity calculation and validation
- Result checking and status tracking

### Market Analysis

- Real-time indices (NEPSE, Sensitive, Float, Sector)
- Stock fundamentals, profiles, and technical indicators
- Market depth and order book analysis
- Trading signals and price alerts
- Floor sheet with live trade data
- 52-week performance tracking
- Broker rankings and analysis

### Portfolio Management

- Multi-member portfolio tracking
- Real-time P&L calculation with WACC
- Secure credential storage
- Interactive member management
- Login verification and session handling

### User Interface

- Modern TUI with Rich tables and panels
- Interactive shell with autocompletion
- Command palette for quick navigation
- Progress indicators for long operations
- Formatted output with color coding

## Configuration

Credential data is stored in: `C:\Users\%USERNAME%\Documents\merosharedata\`

**Files:**

- `family_members.json` - Member credentials
- `ipo_config.json` - Application settings
- `nepse_cli_history.txt` - Command history

**Member Data Structure:**

```json
{
  "members": [
    {
      "name": "identifier",
      "dp_value": "139",
      "username": "meroshare_username",
      "password": "meroshare_password",
      "transaction_pin": "1234",
      "applied_kitta": 10,
      "crn_number": "CRN_NUMBER"
    }
  ]
}
```

## Multi-Member Management

Manage credentials for multiple family members to streamline IPO applications.

### Setup

```bash
nepse add-member
```

Required information:

- Name identifier (e.g., "Dad", "Mom", "Self")
- DP number and account credentials
- Meroshare username and password
- Transaction PIN (4-digit)
- Default kitta amount
- CRN number

### Operations

```bash
nepse list-members           # View all members
nepse edit-member            # Modify member details
nepse delete-member          # Remove a member
nepse manage-members         # Interactive management menu
```

### Batch Operations

```bash
nepse apply-all              # Apply IPO for all members
nepse fast-apply-all         # Fast apply for all members
```

## Command Reference

### Most Used Commands

```bash
nepse apply                  # Apply for IPO
nepse fast-apply             # Fast API-based IPO apply
nepse result                 # Check IPO results
nepse stonk <SYMBOL>         # Stock information
nepse mktsum                 # Market overview
nepse ipo                    # Open offerings
nepse get-portfolio          # View portfolio
```

### Available Sector Indices

`BANKING`, `DEVBANK`, `FINANCE`, `HOTELS AND TOURISM`, `HYDROPOWER`, `INVESTMENT`, `LIFE INSURANCE`, `MANUFACTURING AND PROCESSING`, `MICROFINANCE`, `MUTUAL FUND`, `NONLIFE INSURANCE`, `OTHERS`, `TRADING`

### Command Flags

- `--gui`: Show browser window (for browser-based commands)
- `--verbose`: Show detailed output
- Type `help <command>` in shell for command-specific help

## Security

- Credentials stored locally in JSON format
- User-level file permissions (600 on Unix)
- Data stored in user's Documents directory
- Never commit credential files to version control
- Use environment variables for CI/CD if needed

## Troubleshooting

### Windows: 'nepse' Command Not Found

**Most Common Issue:** Microsoft Store Python has PATH configuration problems.

**Recommended Solution:**

1. Uninstall Python from Microsoft Store
2. Install from [python.org](https://www.python.org/downloads/)
3. Check "Add Python to PATH" during installation
4. Reinstall: `pip install nepse-cli`

**Alternative Solutions:**

1. **Use module syntax:**

   ```bash
   python -m nepse_cli
   ```

2. **Add Scripts to PATH manually:**

   ```bash
   # Find Scripts path:
   python -c "import sys; import os; print(os.path.join(sys.prefix, 'Scripts'))"

   # Add output path to System Environment Variables (Win+R → sysdm.cpl → Advanced → Environment Variables)
   ```

3. **Reinstall with --user flag:**

   ```bash
   pip uninstall nepse-cli
   pip install --user nepse-cli
   ```

### Linux/Mac: Command Not Found

- Ensure `~/.local/bin` is in PATH
- Use `pip install --user nepse-cli`
- Restart terminal after installation

### Browser Installation

```bash
playwright install chromium
```

### Login Issues

```bash
nepse test-login         # Verify credentials
nepse list-members       # Check stored data
nepse edit-member        # Update credentials
```

### Common Errors

- **Timeout errors**: Check internet connection or use `--gui` to see what's happening
- **Element not found**: Update playwright browsers or report issue
- **API errors**: Service may be temporarily down, retry later

## Contributing

Contributions are welcome! Please feel free to submit issues, feature requests, or pull requests.

## License

This project is licensed under the MIT License. See [LICENSE](LICENSE) file for details.

## Disclaimer

This tool is for educational and personal use only. Users are responsible for complying with Meroshare's terms of service and applicable regulations. The developers are not liable for any misuse or issues arising from the use of this tool.
