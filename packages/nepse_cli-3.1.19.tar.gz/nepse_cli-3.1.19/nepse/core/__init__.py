"""
Core modules for NEPSE CLI - Authentication, Portfolio, IPO operations
"""
