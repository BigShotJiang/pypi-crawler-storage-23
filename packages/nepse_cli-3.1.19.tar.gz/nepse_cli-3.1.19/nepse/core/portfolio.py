"""
Portfolio Module.
Handles fetching and displaying portfolio data from Meroshare using direct API calls.
Integrates WACC data to calculate Profit & Loss.
"""

import json
import time
from typing import Dict, List, Optional
import requests
from tenacity import retry, stop_after_attempt, wait_fixed

from rich.table import Table
from rich.panel import Panel
from rich import box

from ..utils.formatting import format_rupees, format_number
from ..ui.console import console

# ==========================================
# Constants
# ==========================================
USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0"
MS_API_BASE = "https://webbackend.cdsc.com.np/api"

BASE_HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Content-Type": "application/json",
    "Origin": "https://meroshare.cdsc.com.np",
    "Connection": "keep-alive",
    "Referer": "https://meroshare.cdsc.com.np/",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-site",
    "Pragma": "no-cache",
    "Cache-Control": "no-cache",
}


# ==========================================
# Errors
# ==========================================
class LocalException(Exception):
    """Local exception for portfolio operations."""
    def __init__(self, message: str):
        self.message = message
    
    def __str__(self):
        return self.message


class GlobalError(Exception):
    """Global error for critical failures."""
    def __init__(self, message: str):
        self.message = message
    
    def __str__(self):
        return self.message


# ==========================================
# Portfolio Models
# ==========================================
class PortfolioEntry:
    """Represents a single portfolio holding with P/L data."""
    
    def __init__(self, **kwargs):
        # Basic Portfolio Data
        self.current_balance = float(kwargs.get("currentBalance", 0))
        self.last_transaction_price = float(kwargs.get("lastTransactionPrice", 0))
        self.previous_closing_price = float(kwargs.get("previousClosingPrice", 0))
        self.script = kwargs.get("script", "")
        self.script_desc = kwargs.get("scriptDesc", "")
        self.current_value = float(kwargs.get("valueAsOfLastTransactionPrice", 0))
        
        # WACC / P&L Data (Calculated later)
        self.buy_rate = 0.0
        self.investment = 0.0
        self.profit_loss = 0.0
        self.profit_loss_percent = 0.0
        self.has_wacc = False

    def update_wacc(self, buy_rate: float):
        """Update entry with WACC data and calculate P/L."""
        self.buy_rate = buy_rate
        self.investment = self.current_balance * self.buy_rate
        
        # Calculate P/L
        if self.investment > 0:
            self.profit_loss = self.current_value - self.investment
            self.profit_loss_percent = (self.profit_loss / self.investment) * 100
            self.has_wacc = True
        else:
            # If buy rate is 0 or unknown, we can't calculate real P/L
            self.profit_loss = 0.0
            self.profit_loss_percent = 0.0
            self.has_wacc = False

    def to_json(self):
        return {
            "current_balance": self.current_balance,
            "last_transaction_price": self.last_transaction_price,
            "previous_closing_price": self.previous_closing_price,
            "script": self.script,
            "script_desc": self.script_desc,
            "current_value": self.current_value,
            "buy_rate": self.buy_rate,
            "investment": self.investment,
            "profit_loss": self.profit_loss,
            "profit_loss_percent": self.profit_loss_percent,
        }


class Portfolio:
    """Represents complete portfolio data with totals."""
    
    def __init__(self, entries: List[PortfolioEntry], total_items: int, total_val_ltp: float):
        self.entries = entries
        self.total_items = total_items
        self.total_current_value = total_val_ltp
        
        # Calculate Totals
        self.total_investment = sum(e.investment for e in self.entries)
        
        if self.total_investment > 0:
            self.total_profit_loss = self.total_current_value - self.total_investment
            self.total_profit_loss_percent = (self.total_profit_loss / self.total_investment) * 100
        else:
            self.total_profit_loss = 0.0
            self.total_profit_loss_percent = 0.0

    def to_json(self):
        return {
            "entries": [entry.to_json() for entry in self.entries],
            "total_items": self.total_items,
            "total_current_value": self.total_current_value,
            "total_investment": self.total_investment,
            "total_profit_loss": self.total_profit_loss,
            "total_profit_loss_percent": self.total_profit_loss_percent,
        }


# ==========================================
# Helper Functions
# ==========================================
def fetch_capital_id(dpid_code: str) -> int:
    """
    Fetch Capital ID from DPID Code (e.g. '10900' -> 190).
    
    Args:
        dpid_code: The DPID code to lookup
        
    Returns:
        Capital ID integer
    """
    try:
        response = requests.get(f"{MS_API_BASE}/meroShare/capital/", headers=BASE_HEADERS)
        if response.status_code == 200:
            capitals = response.json()
            for cap in capitals:
                if cap.get('code') == str(dpid_code):
                    return cap.get('id')
    except Exception as e:
        pass
    
    raise GlobalError(f"Could not find Capital ID for DPID {dpid_code}")


# ==========================================
# Account Class
# ==========================================
class Account:
    """Handles Meroshare account operations for Portfolio."""
    
    def __init__(self, username: str, password: str, dpid_code: str, capital_id: int):
        self.username = username
        self.password = password
        self.dpid_code = dpid_code
        self.capital_id = capital_id
        
        self.dmat = None
        self.name = None
        self.auth_token = None

        self.__session = requests.Session()
        self.__session.headers.update(BASE_HEADERS)

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2), reraise=True)
    def login(self) -> str:
        """Perform login and get auth token."""
        data = {
            "clientId": str(self.capital_id),
            "username": self.username,
            "password": self.password,
        }

        headers = BASE_HEADERS.copy()
        headers["Authorization"] = "null"
        headers["Content-Type"] = "application/json"

        login_req = requests.post(f"{MS_API_BASE}/meroShare/auth/", json=data, headers=headers)
        
        if login_req.status_code != 200:
            raise LocalException(f"Login failed with status {login_req.status_code}")

        self.auth_token = login_req.headers.get("Authorization")
        self.__session.headers.update({"Authorization": self.auth_token})
        
        return self.auth_token

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2), reraise=True)
    def fetch_own_details(self):
        """Fetch user details to get Demat number and name."""
        headers = BASE_HEADERS.copy()
        headers["Authorization"] = self.auth_token
        
        response = requests.get(f"{MS_API_BASE}/meroShare/ownDetail/", headers=headers)

        if response.status_code == 200:
            data = response.json()
            self.dmat = data.get('demat')
            self.name = data.get('name')
            return data
        else:
            raise LocalException(f"Failed to fetch own details: {response.status_code}")

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2), reraise=True)
    def fetch_raw_portfolio(self) -> Dict:
        """Fetch raw portfolio data from Meroshare."""
        if not self.dmat:
            self.fetch_own_details()
            
        headers = BASE_HEADERS.copy()
        headers["Authorization"] = self.auth_token
        
        payload = {
            "sortBy": "script",
            "demat": [self.dmat],
            "clientCode": self.dpid_code, 
            "page": 1,
            "size": 200,
            "sortAsc": True,
        }
        
        response = requests.post(
            f"{MS_API_BASE}/meroShareView/myPortfolio/",
            json=payload,
            headers=headers
        )

        if response.status_code != 200:
            raise LocalException(f"Portfolio request failed: {response.status_code}")

        return response.json()

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2), reraise=True)
    def fetch_wacc_report(self) -> List[Dict]:
        """Fetch WACC report to get buy rates."""
        if not self.dmat:
            self.fetch_own_details()
            
        headers = BASE_HEADERS.copy()
        headers["Authorization"] = self.auth_token
        
        payload = {
            "demat": self.dmat,
        }
        
        response = requests.post(
            f"{MS_API_BASE}/myPurchase/waccReport/",
            json=payload,
            headers=headers
        )

        if response.status_code != 200:
            console.print(f"[yellow]⚠ Warning: Could not fetch WACC data ({response.status_code})[/yellow]")
            return []

        return response.json()

    def get_full_portfolio(self) -> Portfolio:
        """
        Fetch both Portfolio and WACC, merge them, and return complete Portfolio object.
        """
        # 1. Fetch Raw Portfolio
        raw_portfolio = self.fetch_raw_portfolio()
        raw_entries = raw_portfolio.get("meroShareMyPortfolio", [])
        
        # 2. Fetch WACC Data
        wacc_data = self.fetch_wacc_report()
        
        # DEBUG: Print type of wacc_data
        # console.print(f"[dim]Debug: WACC data type: {type(wacc_data)}[/dim]")
        
        # Handle if wacc_data is wrapped in a dict (e.g. {'purchaseList': [...]})
        wacc_list = []
        if isinstance(wacc_data, list):
            wacc_list = wacc_data
        elif isinstance(wacc_data, dict):
            # Check for common wrapper keys
            if "waccReport" in wacc_data:
                wacc_list = wacc_data["waccReport"]
            elif "myPurchase" in wacc_data:
                wacc_list = wacc_data["myPurchase"]
            else:
                # If valid dict but structure unknown, try to find the list
                for val in wacc_data.values():
                    if isinstance(val, list):
                        wacc_list = val
                        break
        
        # Create a lookup map for WACC: scrip -> buy_rate
        wacc_map = {}
        for item in wacc_list:
            if not isinstance(item, dict):
                # console.print(f"[yellow]Skipping invalid WACC item: {item}[/yellow]")
                continue
                
            scrip = item.get("scrip")
            # WACC endpoint returns 'averageBuyRate' or 'userDefinedBuyRate'
            # We prefer weighted average
            rate = item.get("averageBuyRate", 0)
            
            # Sometimes rate might be None or empty string
            if rate is None or rate == "":
                rate = 0
            
            if scrip:
                wacc_map[scrip] = float(rate)
        
        # 3. Create Portfolio Entries and Merge
        entries = []
        for item in raw_entries:
            entry = PortfolioEntry(**item)
            
            # Enrich with Buy Rate if available
            scrip = entry.script
            if scrip in wacc_map:
                entry.update_wacc(wacc_map[scrip])
            
            entries.append(entry)
            
        # 4. create Portfolio Object
        portfolio = Portfolio(
            entries=entries,
            total_items=raw_portfolio.get("totalItems", 0),
            total_val_ltp=float(raw_portfolio.get("totalValueAsOfLastTransactionPrice", 0))
        )
        
        return portfolio

    def logout(self):
        """Logout from the session."""
        if self.auth_token:
            try:
                headers = BASE_HEADERS.copy()
                headers["Authorization"] = self.auth_token
                requests.get(f"{MS_API_BASE}/meroShare/auth/logout/", headers=headers)
                self.auth_token = None
            except:
                pass


# ==========================================
# Display Functions
# ==========================================
def display_portfolio(portfolio: Portfolio, member_name: str = "") -> None:
    """Display portfolio in a rich table with P/L."""
    
    title = f"💼 Portfolio: {member_name}" if member_name else "💼 Portfolio Summary"
    
    table = Table(
        title=title,
        box=box.ROUNDED,
        header_style="bold cyan",
        expand=True,
        show_lines=False
    )
    
    table.add_column("Script", style="bold yellow", width=10)
    table.add_column("Qty", justify="right", style="magenta")
    table.add_column("LTP", justify="right")
    table.add_column("Buy Rate", justify="right", style="dim")
    table.add_column("Value", justify="right", style="cyan")
    table.add_column("Investment", justify="right", style="dim")
    table.add_column("P/L", justify="right", style="bold")
    table.add_column("%", justify="right", style="bold")
    
    for entry in portfolio.entries:
        # Determine P/L Color
        pl_color = "green" if entry.profit_loss >= 0 else "red"
        pl_sign = "+" if entry.profit_loss >= 0 else ""
        
        # If no WACC data, show placeholders
        if entry.has_wacc:
            buy_rate_str = f"{entry.buy_rate:,.2f}"
            inv_str = f"{entry.investment:,.2f}"
            pl_str = f"[{pl_color}]{pl_sign}{format_rupees(entry.profit_loss)}[/{pl_color}]"
            pct_str = f"[{pl_color}]{pl_sign}{entry.profit_loss_percent:.2f}%[/{pl_color}]"
        else:
            buy_rate_str = "-"
            inv_str = "-"
            pl_str = "-"
            pct_str = "-"
            
        table.add_row(
            entry.script,
            f"{int(entry.current_balance)}",
            f"{entry.last_transaction_price:,.2f}",
            buy_rate_str,
            f"{format_rupees(entry.current_value)}",
            inv_str,
            pl_str,
            pct_str
        )
    
    # Summary Section
    table.add_section()
    
    # Calculate Total P/L formatting
    total_pl = portfolio.total_profit_loss
    total_pl_pct = portfolio.total_profit_loss_percent
    
    t_color = "green" if total_pl >= 0 else "red"
    t_sign = "+" if total_pl >= 0 else ""
    
    table.add_row(
        "TOTAL",
        "",
        "",
        "",
        f"[bold cyan]{format_rupees(portfolio.total_current_value)}[/bold cyan]",
        f"[dim]{format_rupees(portfolio.total_investment)}[/dim]",
        f"[bold {t_color}]{t_sign}{format_rupees(total_pl)}[/bold {t_color}]",
        f"[bold {t_color}]{t_sign}{total_pl_pct:.2f}%[/bold {t_color}]",
        style="bold"
    )
    
    console.print(table)
    console.print()


def check_portfolio_for_member(member: Dict, headless: bool = True) -> Optional[Portfolio]:
    """
    Check portfolio for a single member using updated P/L logic.
    
    Args:
        member: Member dictionary
        headless: Ignored (kept for compatibility)
        
    Returns:
        Portfolio object or None
    """
    try:
        # Extract DPID code
        dp_value = member.get('dp_value', '')
        dpid_code = member.get('dpid_code')
        
        if not dpid_code and dp_value:
            import re
            match = re.search(r'\((\d+)\)', dp_value)
            if match:
                dpid_code = match.group(1)
            elif dp_value.isdigit():
                dpid_code = dp_value
        
        if not dpid_code:
            console.print("[red]✗ Could not determine DPID code[/red]")
            return None
        
        # Get capital ID and fetch portfolio with single progress indicator
        with console.status("[bold cyan]Fetching portfolio data...", spinner="dots"):
            capital_id = fetch_capital_id(dpid_code)
            
            # Create account and login
            account = Account(
                username=member['username'],
                password=member['password'],
                dpid_code=dpid_code,
                capital_id=capital_id
            )
            
            account.login()
            time.sleep(0.5)
            
            # Use new get_full_portfolio method
            portfolio = account.get_full_portfolio()
            
            account.logout()
        
        # Display immediately if called directly
        if portfolio:
            display_portfolio(portfolio, member['name'])
            
        return portfolio
        
    except Exception as e:
        console.print(f"[red]⚠ Error: {e}[/red]")
        return None

# Alias for compatibility with main.py
get_portfolio_for_member = check_portfolio_for_member
