"""
IPO Application Module.
Handles IPO listing, application, and batch processing.
"""

import time
import re
import json
from typing import Dict, List, Optional, Tuple
from playwright.sync_api import sync_playwright, Page, BrowserContext
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock

from rich.table import Table
from rich.panel import Panel
from rich.rule import Rule
from rich import box

from .auth import MeroshareAuth
from .ipo_result import fetch_capital_id_silent, Account
from ..config import DATA_DIR
from ..ui.console import console


class IPOManager:
    """Handles IPO browsing and application operations."""
    
    ASBA_URL = "https://meroshare.cdsc.com.np/#/asba"
    
    def __init__(self, page: Page):
        """
        Initialize with an authenticated page.
        
        Args:
            page: Authenticated Playwright page
        """
        self.page = page
    
    def fetch_available_ipos(self) -> List[Dict]:
        """
        Fetch available IPOs from Meroshare.
        
        Returns:
            List of available IPO dictionaries
        """
        try:
            self.page.goto(self.ASBA_URL, wait_until="networkidle")
            time.sleep(3)
            
            try:
                self.page.wait_for_selector(".company-list", timeout=10000)
                time.sleep(2)
            except:
                pass
            
            company_rows = self.page.query_selector_all(".company-list")
            if not company_rows:
                return []
            
            available_ipos = []
            for row in company_rows:
                try:
                    company_name_elem = row.query_selector(".company-name span")
                    share_type_elem = row.query_selector(".share-of-type")
                    share_group_elem = row.query_selector(".isin")
                    
                    if company_name_elem and share_type_elem and share_group_elem:
                        company_name = company_name_elem.inner_text().strip()
                        share_type = share_type_elem.inner_text().strip()
                        share_group = share_group_elem.inner_text().strip()
                        
                        if "ipo" in share_type.lower() and "ordinary" in share_group.lower():
                            apply_button = row.query_selector("button.btn-issue")
                            
                            is_applied = False
                            button_text = ""
                            if apply_button:
                                button_text = apply_button.inner_text().strip().lower()
                                is_applied = "edit" in button_text or "view" in button_text
                            
                            if apply_button:
                                available_ipos.append({
                                    "index": len(available_ipos) + 1,
                                    "company_name": company_name,
                                    "share_type": share_type,
                                    "share_group": share_group,
                                    "element": row,
                                    "apply_button": apply_button,
                                    "is_applied": is_applied,
                                    "button_text": button_text
                                })
                except Exception:
                    continue
            
            return available_ipos
            
        except Exception as e:
            console.print(f"[red]Error fetching IPOs: {e}[/red]")
            return []
    
    def apply_for_ipo(
        self, 
        ipo: Dict, 
        member: Dict
    ) -> Tuple[bool, str]:
        """
        Apply for a specific IPO.
        
        Args:
            ipo: IPO dictionary with apply_button
            member: Member dictionary with credentials
            
        Returns:
            Tuple of (success, status_message)
        """
        try:
            # Check if already applied
            if ipo.get('is_applied', False):
                return True, "already_applied"
            
            # Click Apply button
            ipo['apply_button'].click()
            time.sleep(3)
            
            # Fill form
            self.page.wait_for_selector("select#selectBank", timeout=10000)
            time.sleep(2)
            
            # Get minimum quantity from the form
            try:
                labels = self.page.query_selector_all("label")
                min_quantity = member['applied_kitta']  # Default to member's setting
                
                for label in labels:
                    if "Minimum Quantity" in label.inner_text():
                        # Find the sibling form-value div
                        parent = label.evaluate_handle("el => el.closest('.form-group')")
                        form_value = parent.as_element().query_selector(".form-value span")
                        if form_value:
                            form_min_qty = int(form_value.inner_text().strip())
                            # Use the maximum of form minimum and member's default
                            min_quantity = max(min_quantity, form_min_qty)
                            if form_min_qty > member['applied_kitta']:
                                console.print(f"[yellow]⚠ Adjusting quantity from {member['applied_kitta']} to minimum {form_min_qty}[/yellow]")
                            break
            except Exception as e:
                console.print(f"[dim]Could not read minimum quantity, using default: {e}[/dim]")
                min_quantity = member['applied_kitta']
            
            # Select bank
            bank_options = self.page.query_selector_all("select#selectBank option")
            valid_banks = [opt for opt in bank_options if opt.get_attribute("value")]
            if valid_banks:
                self.page.select_option("select#selectBank", valid_banks[0].get_attribute("value"))
            else:
                return False, "No banks found"
            time.sleep(2)
            
            # Select account
            self.page.wait_for_selector("select#accountNumber", timeout=5000)
            account_options = self.page.query_selector_all("select#accountNumber option")
            valid_accounts = [opt for opt in account_options if opt.get_attribute("value")]
            if valid_accounts:
                self.page.select_option("select#accountNumber", valid_accounts[0].get_attribute("value"))
            else:
                return False, "No accounts found"
            time.sleep(2)
            
            # Fill kitta with adjusted quantity
            self.page.fill("input#appliedKitta", str(min_quantity))
            time.sleep(1)
            self.page.fill("input#crnNumber", member['crn_number'])
            time.sleep(1)
            
            # Accept disclaimer
            disclaimer = self.page.query_selector("input#disclaimer")
            if disclaimer:
                disclaimer.check()
            time.sleep(1)
            
            # Click proceed
            proceed_button = self.page.query_selector("button.btn-primary[type='submit']")
            if proceed_button:
                proceed_button.click()
            else:
                return False, "Proceed button not found"
            time.sleep(3)
            
            # Enter PIN
            self.page.wait_for_selector("input#transactionPIN", timeout=10000)
            time.sleep(2)
            self.page.fill("input#transactionPIN", member['transaction_pin'])
            time.sleep(2)
            
            # Submit application
            clicked = self._click_submit_button()
            if not clicked:
                return False, "Failed to click submit button"
            
            time.sleep(5)
            return True, "success"
            
        except Exception as e:
            return False, str(e)
    
    def _click_submit_button(self) -> bool:
        """Try multiple methods to click the Apply/Submit button."""
        # Method 1: Find button with text "Apply"
        try:
            apply_buttons = self.page.query_selector_all("button:has-text('Apply')")
            for btn in apply_buttons:
                if btn.is_visible() and not btn.is_disabled():
                    btn.click()
                    return True
        except:
            pass
        
        # Method 2: Find by class in confirm page
        try:
            submit_button = self.page.query_selector("div.confirm-page-btn button.btn-primary[type='submit']")
            if submit_button and submit_button.is_visible():
                submit_button.click()
                return True
        except:
            pass
        
        # Method 3: Alternative submit button
        try:
            submit_button = self.page.query_selector("button.btn-gap.btn-primary[type='submit']")
            if submit_button and submit_button.is_visible():
                submit_button.click()
                return True
        except:
            pass
        
        # Method 4: JavaScript fallback
        try:
            self.page.evaluate("""
                const buttons = document.querySelectorAll('button');
                for (const btn of buttons) {
                    if (btn.textContent.includes('Apply') && btn.type === 'submit') {
                        btn.click();
                        break;
                    }
                }
            """)
            return True
        except:
            pass
        
        return False


def display_ipo_table(ipos: List[Dict]) -> None:
    """Display available IPOs in a table."""
    table = Table(
        title="Available IPOs (Ordinary Shares)", 
        box=box.ROUNDED,
        header_style="bold cyan"
    )
    table.add_column("No.", justify="right", style="cyan")
    table.add_column("Company", style="bold white")
    table.add_column("Type", style="yellow")
    table.add_column("Group", style="dim")
    table.add_column("Status", justify="center")
    
    for ipo in ipos:
        status = "[yellow]Applied[/yellow]" if ipo.get('is_applied') else "[green]Available[/green]"
        table.add_row(
            str(ipo['index']),
            ipo['company_name'],
            ipo['share_type'],
            ipo['share_group'],
            status
        )
    
    console.print(table)


def apply_ipo(
    auto_load: bool = True, 
    headless: bool = False, 
    member_name: Optional[str] = None
) -> None:
    """
    Apply for IPO with selected member.
    
    Args:
        auto_load: Load credentials from config
        headless: Run browser in headless mode
        member_name: Optional specific member name
    """
    from ..config import get_member_by_name
    from ..ui.member_ui import select_family_member
    
    member = None
    if member_name:
        member = get_member_by_name(member_name)
        if not member:
            console.print(f"\n[red]✗ Member '{member_name}' not found.[/red]")
            return
    
    if not member:
        member = select_family_member()
    
    if not member:
        console.print("\n[red]✗ No member selected. Exiting...[/red]")
        return
    
    if not member.get('crn_number'):
        console.print("[red]✗ CRN number is required![/red]")
        return
    
    console.print(f"\n[bold green]✓ Applying IPO for:[/bold green] {member['name']}")
    console.print(f"[bold green]✓ Kitta:[/bold green] {member['applied_kitta']}")
    
    auth = MeroshareAuth(headless=headless, slow_mo=100)
    success, page = auth.login(member, show_progress=True)
    
    if not success or not page:
        console.print("[red]✗ Login failed[/red]")
        auth.close()
        return
    
    console.print("[bold green]✓ Login successful[/bold green]\n")
    
    # Fetch IPOs
    with console.status("[bold green]Fetching available IPOs...", spinner="dots"):
        ipo_manager = IPOManager(page)
        available_ipos = ipo_manager.fetch_available_ipos()
    
    if not available_ipos:
        console.print("[bold yellow]⚠ No IPOs available[/bold yellow]")
        if not headless:
            time.sleep(20)
        auth.close()
        return
    
    console.print("[bold green]✓ IPOs fetched successfully[/bold green]\n")
    display_ipo_table(available_ipos)
    
    # Auto-select first IPO for both headless and GUI mode
    selected_idx = 0
    console.print(f"\n→ Auto-selecting IPO #1: {available_ipos[0]['company_name']}")
    
    selected_ipo = available_ipos[selected_idx]
    console.print(f"\n[bold green]✓ Selected:[/bold green] {selected_ipo['company_name']}\n")
    
    # Apply
    with console.status("[bold green]Applying for IPO...", spinner="dots"):
        success, status = ipo_manager.apply_for_ipo(selected_ipo, member)
    
    if success:
        if status == "already_applied":
            console.print("[yellow]⚠ IPO already applied for this account[/yellow]")
        else:
            console.print("\n[bold green]✓✓✓ APPLICATION SUBMITTED! ✓✓✓[/bold green]")
    else:
        console.print(f"[red]✗ Application failed: {status}[/red]")
    
    if not headless:
        console.print("\n[dim]Browser will stay open for 30 seconds...[/dim]")
        time.sleep(30)
    
    auth.close()


def apply_ipo_for_all_members(headless: bool = True) -> None:
    """
    Apply IPO for multiple family members using multi-tab browser.
    
    Args:
        headless: Run browser in headless mode
    """
    from ..config import get_all_members
    from ..ui.member_ui import select_members_for_ipo
    
    all_members = get_all_members()
    
    if not all_members:
        console.print(Panel(
            "[bold red]⚠ No family members found. Add members first![/bold red]",
            box=box.ROUNDED, 
            border_style="red"
        ))
        return
    
    # Interactive selection
    console.print()
    members = select_members_for_ipo(all_members)
    
    if not members:
        return
    
    # Show selected members
    console.print()
    table = Table(
        title="✓ Selected Members for IPO Application",
        box=box.ROUNDED,
        header_style="bold green",
        border_style="green"
    )
    table.add_column("No.", justify="right", style="cyan")
    table.add_column("Name", style="bold white")
    table.add_column("Kitta", justify="right", style="yellow")
    
    for idx, member in enumerate(members, 1):
        table.add_row(
            str(idx),
            member['name'],
            str(member['applied_kitta'])
        )
    
    console.print(table)
    console.print()
    
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless, slow_mo=100 if not headless else 0)
        context = browser.new_context()
        
        try:
            # Phase 1: Login all members
            console.print()
            console.print(Rule("[bold cyan]PHASE 1: MULTI-TAB LOGIN[/bold cyan]"))
            console.print()
            
            pages_data = []
            auth = MeroshareAuth(headless=headless)
            
            for idx, member in enumerate(members, 1):
                member_name = member['name']
                console.print(f"[cyan][Tab {idx}][/cyan] Logging in: [bold]{member_name}[/bold]")
                
                with console.status(f"[bold green][Tab {idx}] Logging in...", spinner="dots"):
                    success, page = auth.login_with_context(member, context)
                
                if success:
                    console.print(f"[green]✓ [Tab {idx}] Login successful: {member_name}[/green]")
                    pages_data.append({
                        "success": True,
                        "member": member,
                        "page": page,
                        "tab_index": idx
                    })
                else:
                    console.print(f"[red]✗ [Tab {idx}] Login failed: {member_name}[/red]")
                    pages_data.append({
                        "success": False,
                        "member": member,
                        "page": page,
                        "tab_index": idx,
                        "error": "Login failed"
                    })
            
            successful_logins = [p for p in pages_data if p['success']]
            
            if not successful_logins:
                console.print("[bold red]\n✗ No successful logins. Exiting...[/bold red]")
                return
            
            # Phase 2: Apply IPO
            console.print()
            console.print(Rule("[bold cyan]PHASE 2: IPO APPLICATION[/bold cyan]"))
            console.print()
            
            # Fetch IPOs from first successful login
            first_page = successful_logins[0]['page']
            ipo_manager = IPOManager(first_page)
            
            with console.status("[bold green]Fetching available IPOs...", spinner="dots"):
                available_ipos = ipo_manager.fetch_available_ipos()
            
            if not available_ipos:
                console.print("[bold yellow]⚠ No IPOs available[/bold yellow]")
                return
            
            console.print("[bold green]✓ IPOs fetched successfully[/bold green]\n")
            display_ipo_table(available_ipos)
            
            # Select IPO
            if not headless:
                selection = input(f"\nSelect IPO (1-{len(available_ipos)}): ").strip()
                try:
                    selected_idx = int(selection) - 1
                    if selected_idx < 0 or selected_idx >= len(available_ipos):
                        console.print("[red]✗ Invalid selection![/red]")
                        return
                except ValueError:
                    console.print("[red]✗ Invalid input![/red]")
                    return
            else:
                selected_idx = 0
            
            selected_ipo = available_ipos[selected_idx]
            console.print(Panel(
                f"[bold green]✓ Selected IPO: {selected_ipo['company_name']}[/bold green]\n"
                f"[yellow]⚠ Will apply for {len(successful_logins)} member(s)[/yellow]",
                box=box.ROUNDED
            ))
            
            # Apply for each member
            application_results = []
            
            for page_data in successful_logins:
                member = page_data['member']
                page = page_data['page']
                tab_index = page_data['tab_index']
                
                console.print()
                console.print(Rule(f"[Tab {tab_index}] APPLYING FOR: {member['name']}"))
                
                try:
                    with console.status(f"[bold green][Tab {tab_index}] Navigating...", spinner="dots"):
                        page.goto("https://meroshare.cdsc.com.np/#/asba", wait_until="networkidle")
                        time.sleep(3)
                        page.wait_for_selector(".company-list", timeout=10000)
                        time.sleep(2)
                    
                    # Find and click IPO
                    company_rows = page.query_selector_all(".company-list")
                    ipo_found = False
                    already_applied = False
                    
                    for row in company_rows:
                        try:
                            company_name_elem = row.query_selector(".company-name span")
                            if company_name_elem and selected_ipo['company_name'] in company_name_elem.inner_text():
                                apply_button = row.query_selector("button.btn-issue")
                                if apply_button:
                                    button_text = apply_button.inner_text().strip().lower()
                                    
                                    if "edit" in button_text or "view" in button_text:
                                        already_applied = True
                                        ipo_found = True
                                        break
                                    else:
                                        apply_button.click()
                                        ipo_found = True
                                        break
                        except:
                            continue
                    
                    if already_applied:
                        console.print(f"[green]✓ [Tab {tab_index}] Skipping - already applied[/green]")
                        application_results.append({
                            "member": member['name'],
                            "success": True,
                            "status": "already_applied"
                        })
                        continue
                    
                    if not ipo_found:
                        raise Exception("IPO not found")
                    
                    time.sleep(3)
                    
                    # Fill form
                    with console.status(f"[bold green][Tab {tab_index}] Filling form...", spinner="dots"):
                        page.wait_for_selector("select#selectBank", timeout=10000)
                        time.sleep(2)
                        
                        # Get minimum quantity from the form
                        try:
                            labels = page.query_selector_all("label")
                            min_quantity = member['applied_kitta']  # Default to member's setting
                            
                            for label in labels:
                                if "Minimum Quantity" in label.inner_text():
                                    # Find the sibling form-value div
                                    parent = label.evaluate_handle("el => el.closest('.form-group')")
                                    form_value = parent.as_element().query_selector(".form-value span")
                                    if form_value:
                                        form_min_qty = int(form_value.inner_text().strip())
                                        # Use the maximum of form minimum and member's default
                                        min_quantity = max(min_quantity, form_min_qty)
                                        if form_min_qty > member['applied_kitta']:
                                            console.print(f"[yellow][Tab {tab_index}] Adjusting quantity from {member['applied_kitta']} to minimum {form_min_qty}[/yellow]")
                                        break
                        except Exception:
                            min_quantity = member['applied_kitta']
                        
                        bank_options = page.query_selector_all("select#selectBank option")
                        valid_banks = [opt for opt in bank_options if opt.get_attribute("value")]
                        if valid_banks:
                            page.select_option("select#selectBank", valid_banks[0].get_attribute("value"))
                        time.sleep(2)
                        
                        page.wait_for_selector("select#accountNumber", timeout=5000)
                        account_options = page.query_selector_all("select#accountNumber option")
                        valid_accounts = [opt for opt in account_options if opt.get_attribute("value")]
                        if valid_accounts:
                            page.select_option("select#accountNumber", valid_accounts[0].get_attribute("value"))
                        time.sleep(2)
                        
                        page.fill("input#appliedKitta", str(min_quantity))
                        time.sleep(1)
                        page.fill("input#crnNumber", member['crn_number'])
                        time.sleep(1)
                        
                        disclaimer = page.query_selector("input#disclaimer")
                        if disclaimer:
                            disclaimer.check()
                        time.sleep(1)
                        
                        proceed = page.query_selector("button.btn-primary[type='submit']")
                        if proceed:
                            proceed.click()
                        time.sleep(3)
                    
                    # Enter PIN and submit
                    with console.status(f"[bold green][Tab {tab_index}] Submitting...", spinner="dots"):
                        page.wait_for_selector("input#transactionPIN", timeout=10000)
                        time.sleep(2)
                        page.fill("input#transactionPIN", member['transaction_pin'])
                        time.sleep(2)
                        
                        # Click submit
                        try:
                            apply_buttons = page.query_selector_all("button:has-text('Apply')")
                            for btn in apply_buttons:
                                if btn.is_visible() and not btn.is_disabled():
                                    btn.click()
                                    break
                        except:
                            page.evaluate("""
                                const buttons = document.querySelectorAll('button');
                                for (const btn of buttons) {
                                    if (btn.textContent.includes('Apply') && btn.type === 'submit') {
                                        btn.click();
                                        break;
                                    }
                                }
                            """)
                        
                        time.sleep(5)
                    
                    console.print(f"[bold green]✓ [Tab {tab_index}] Application submitted for {member['name']}![/bold green]")
                    application_results.append({
                        "member": member['name'],
                        "success": True
                    })
                    
                except Exception as e:
                    console.print(f"[bold red]✗ [Tab {tab_index}] Failed: {e}[/bold red]")
                    application_results.append({
                        "member": member['name'],
                        "success": False,
                        "error": str(e)
                    })
                    page.screenshot(path=str(DATA_DIR / f"error_{member['name']}.png"))
            
            # Final summary
            console.print()
            successful = [r for r in application_results if r['success']]
            failed = [r for r in application_results if not r['success']]
            
            summary_table = Table(
                title=f"Final Summary: {selected_ipo['company_name']}",
                box=box.ROUNDED
            )
            summary_table.add_column("Member", style="white")
            summary_table.add_column("Status", style="bold")
            summary_table.add_column("Details", style="dim")
            
            for r in successful:
                status = "[yellow]Already Applied[/yellow]" if r.get('status') == 'already_applied' else "[green]Success[/green]"
                details = "Skipped" if r.get('status') == 'already_applied' else "Applied"
                summary_table.add_row(r['member'], status, details)
            
            for r in failed:
                summary_table.add_row(r['member'], "[red]Failed[/red]", r.get('error', 'Unknown'))
            
            console.print(summary_table)
            
            if not headless:
                console.print("\n[dim]Browser will stay open for 60 seconds...[/dim]")
                time.sleep(60)
            
        except Exception as e:
            console.print(f"\n[bold red]✗ Critical error: {e}[/bold red]")
        finally:
            browser.close()


# ============================================================================
# FAST API-BASED IPO APPLICATION (New Implementation)
# ============================================================================


class IPOApplicationFast:
    """Handle fast API-based IPO application operations for a member account."""
    
    def __init__(self, member: Dict, verbose: bool = False):
        """
        Initialize IPO Application handler.
        
        Args:
            member: Member dict containing credentials
        """
        self.member = member
        self.verbose = verbose
        self.account: Optional[Account] = None
        self.is_logged_in = False
        self._details = None

    def _log(self, message: str) -> None:
        if self.verbose:
            console.print(message)

    def _mask_text(self, value: str) -> str:
        value = str(value or "")
        if len(value) <= 4:
            return "*" * len(value)
        return "*" * (len(value) - 4) + value[-4:]

    def _sanitize_for_log(self, value):
        if isinstance(value, dict):
            sanitized = {}
            for key, raw_val in value.items():
                key_l = str(key).lower()
                if any(secret in key_l for secret in ["pin", "password", "token", "authorization", "crn"]):
                    sanitized[key] = self._mask_text(raw_val)
                else:
                    sanitized[key] = self._sanitize_for_log(raw_val)
            return sanitized
        if isinstance(value, list):
            return [self._sanitize_for_log(item) for item in value]
        return value

    def _normalize_crn(self, value: str) -> str:
        return "".join(ch for ch in str(value or "").strip() if ch.isalnum()).upper()

    def _request(self, method: str, url: str, headers: Dict, json_data: Optional[Dict] = None):
        import requests

        if self.verbose:
            self._log(f"[dim]    HTTP {method.upper()} {url}[/dim]")
            if json_data is not None:
                try:
                    req_preview = json.dumps(self._sanitize_for_log(json_data), ensure_ascii=False)
                except Exception:
                    req_preview = str(self._sanitize_for_log(json_data))
                self._log(f"[dim]    Request body: {req_preview}[/dim]")

        response = requests.request(method=method, url=url, headers=headers, json=json_data)

        if self.verbose:
            self._log(f"[dim]    Response status: {response.status_code}[/dim]")
            body_text = (response.text or "").strip()
            if body_text:
                try:
                    parsed = response.json()
                    body_preview = json.dumps(self._sanitize_for_log(parsed), ensure_ascii=False)
                except Exception:
                    body_preview = body_text
                if len(body_preview) > 900:
                    body_preview = body_preview[:900] + "..."
                self._log(f"[dim]    Response body: {body_preview}[/dim]")

        return response
        
    def login(self) -> bool:
        """Login to member's account."""
        try:
            # Extract DPID code
            dp_value = self.member.get('dp_value', '')
            dpid_code = self.member.get('dpid_code')
            
            if not dpid_code and dp_value:
                match = re.search(r'\((\d+)\)', dp_value)
                if match:
                    dpid_code = match.group(1)
                elif dp_value.isdigit():
                    dpid_code = dp_value
            
            if not dpid_code:
                self._log(f"[red]✗ Could not determine DPID code for {self.member['name']}[/red]")
                return False
            
            # Get capital ID
            capital_id = fetch_capital_id_silent(dpid_code)
            
            # Create account instance
            self.account = Account(
                username=self.member['username'],
                password=self.member['password'],
                dpid_code=dpid_code,
                capital_id=capital_id
            )
            
            # Perform login + fetch account details (silent)
            self.account.login_silent()
            self.account.fetch_own_details_silent()
            
            self.is_logged_in = True
            self._log(f"[green]  ✓ Logged in as: {self.account.name}[/green]")
            return True
            
        except Exception as e:
            self._log(f"[red]  ✗ Login failed for {self.member['name']}: {e}[/red]")
            return False
    
    def logout(self):
        """Logout from account."""
        if self.account and self.is_logged_in:
            try:
                self.account.logout()
                self.is_logged_in = False
                self._log(f"[dim]  → Logged out {self.member['name']}[/dim]")
            except Exception as e:
                self._log(f"[yellow]  ⚠ Logout warning for {self.member['name']}: {e}[/yellow]")
    
    @property
    def api_base(self) -> str:
        """Get API base URL."""
        return "https://webbackend.cdsc.com.np/api"
    
    @property
    def details(self) -> Dict:
        """Get account details."""
        if not self._details:
            self._details = {
                "demat": self.account.dmat or self.account.username,
                "clientCode": "",
                "branchId": "", 
                "crnNumber": "",
                "bankId": "",
            }
        return self._details
    
    @property
    def details_error(self) -> str:
        """Last error while fetching account/bank details (if any)."""
        return getattr(self, "_details_error", "")
        
    def fetch_detailed_info(self) -> bool:
        """
        Fetch detailed account info (bank, branch, etc.) required for applying.
        Returns True if successful.
        """
        if not self.is_logged_in:
            return False
            
        try:
            self._details_error = ""
            self._log(f"[cyan]  → Fetching detailed account info for {self.member['name']}...[/cyan]")
            headers = {
                "Authorization": self.account.auth_token,
                "User-Agent": "Mozilla/5.0"
            }
            
            # 1. Get bank code from myDetail
            demat_for_detail = self.account.dmat or self.account.username
            if not demat_for_detail:
                raise Exception("Missing demat/username; cannot call myDetail")
            my_detail_resp = self._request(
                "GET",
                f"{self.api_base}/meroShareView/myDetail/{demat_for_detail}",
                headers=headers,
            )
            if my_detail_resp.status_code != 200:
                body_preview = (my_detail_resp.text or "").strip()
                raise Exception(f"Failed to get myDetail: HTTP {my_detail_resp.status_code} {body_preview}")
                
            my_detail = my_detail_resp.json() if my_detail_resp.content else {}
            if self.verbose and isinstance(my_detail, dict) and my_detail:
                self._log(f"[dim]    myDetail fields: {', '.join(sorted(list(my_detail.keys())))}[/dim]")
            bank_code = my_detail.get("bankCode") or my_detail.get("bank_code")
            my_detail_account_no = (
                my_detail.get("accountNumber")
                or my_detail.get("accountNo")
                or my_detail.get("account_number")
            )
            my_detail_crn = (
                my_detail.get("crnNumber")
                or my_detail.get("crn")
                or my_detail.get("crn_number")
            )
            if not bank_code and not my_detail_account_no:
                # Some DP types (e.g. Global IME Capital) return only profile fields
                # from myDetail — that is fine; /meroShare/bank/ will provide all
                # required bank/account info.
                self._log(f"[dim]    myDetail has no bankCode/accountNumber — will resolve from /meroShare/bank/[/dim]")

            # 1b. Fetch bankRequest details (often contains customerId/branchId/crnNumber)
            bank_req_data = {}
            if bank_code:
                try:
                    bank_req_resp = self._request(
                        "GET",
                        f"{self.api_base}/bankRequest/{bank_code}",
                        headers=headers,
                    )
                    if bank_req_resp.status_code == 200:
                        bank_req_data = bank_req_resp.json() if bank_req_resp.content else {}
                        if self.verbose and isinstance(bank_req_data, dict) and bank_req_data:
                            self._log(
                                f"[dim]    bankRequest fields: {', '.join(sorted(list(bank_req_data.keys())))}[/dim]"
                            )
                    else:
                        if self.verbose:
                            body_preview = (bank_req_resp.text or "").strip()
                            if len(body_preview) > 200:
                                body_preview = body_preview[:200] + "..."
                            self._log(
                                f"[dim]    bankRequest non-200: HTTP {bank_req_resp.status_code} {body_preview}[/dim]"
                            )
                except Exception as e:
                    if self.verbose:
                        self._log(f"[dim]    bankRequest error: {e}[/dim]")
            
            # 2. Get Account Number (may be None here; will be resolved from bank-specific in step 4)
            account_number = my_detail_account_no
            if not account_number and bank_code:
                account_number = bank_req_data.get("accountNumber") or bank_req_data.get("accountNo")
            # NOTE: account_number CAN be None at this point for accounts whose myDetail
            # does not return bank fields. It will be populated from /meroShare/bank/{id}
            # in step 4, so we do NOT raise here.

            # 3. Get Bank ID
            bank_list_resp = self._request(
                "GET",
                f"{self.api_base}/meroShare/bank/",
                headers=headers,
            )
            if bank_list_resp.status_code != 200:
                body_preview = (bank_list_resp.text or "").strip()
                raise Exception(f"Failed to get bank list: HTTP {bank_list_resp.status_code} {body_preview}")
            
            banks = bank_list_resp.json()
            bank_id = None
            bank_name = ""
            _bank_manually_chosen = False  # track whether user made a manual choice this run

            if not isinstance(banks, list) or not banks:
                raise Exception("Could not determine bankId from /meroShare/bank/")

            if len(banks) == 1:
                # Only one bank linked — use it directly, no prompt
                bank_id   = banks[0].get("id")
                bank_name = str(banks[0].get("name") or banks[0].get("bankName") or "")
            else:
                # Multiple banks — check for a saved default first
                default_bid = str(self.member.get("default_bank_id") or "").strip()
                if default_bid:
                    default_match = next(
                        (b for b in banks if str(b.get("id")) == default_bid), None
                    )
                    if default_match:
                        bank_id   = default_match.get("id")
                        bank_name = str(default_match.get("name") or default_match.get("bankName") or "")
                        console.print(
                            f"[dim]  → Using default bank for {self.member['name']}: "
                            f"{bank_name} (id {bank_id})[/dim]"
                        )

                if bank_id is None:
                    # Interactive selection
                    console.print(
                        f"\n[bold cyan]  {self.member['name']} has {len(banks)} bank(s) linked.[/bold cyan]"
                    )
                    from rich.table import Table as _Table
                    from rich import box as _box
                    _btable = _Table(box=_box.SIMPLE, header_style="bold cyan", show_header=True)
                    _btable.add_column("#",    style="dim",        width=3,  justify="right")
                    _btable.add_column("Bank", style="bold white", min_width=30)
                    _btable.add_column("Code", style="dim",        width=6)
                    for _i, _b in enumerate(banks, 1):
                        _bcode = str(_b.get("bankCode") or _b.get("code") or "")
                        _bname = str(_b.get("name") or _b.get("bankName") or "")
                        _btable.add_row(str(_i), _bname, _bcode)
                    console.print(_btable)

                    while True:
                        try:
                            _pick = console.input(
                                f"  [cyan]Select bank (1-{len(banks)}):[/cyan] "
                            ).strip()
                            _pick_idx = int(_pick) - 1
                            if 0 <= _pick_idx < len(banks):
                                bank_id   = banks[_pick_idx].get("id")
                                bank_name = str(
                                    banks[_pick_idx].get("name")
                                    or banks[_pick_idx].get("bankName") or ""
                                )
                                _bank_manually_chosen = True
                                break
                            else:
                                console.print(f"  [red]Please enter a number between 1 and {len(banks)}[/red]")
                        except (ValueError, KeyboardInterrupt):
                            raise Exception("Bank selection cancelled")

                    # Offer to set as default
                    try:
                        _set_def = console.input(
                            f"  [cyan]Set [bold]{bank_name}[/bold] as default bank for "
                            f"{self.member['name']}? [y/N]:[/cyan] "
                        ).strip().lower()
                        if _set_def in ("y", "yes"):
                            from ..config import set_member_default_bank
                            set_member_default_bank(self.member["name"], bank_id, bank_name)
                            console.print(
                                f"  [green]✓ Default bank saved: {bank_name}[/green]"
                            )
                    except KeyboardInterrupt:
                        pass  # user skipped the prompt

            if not bank_id:
                raise Exception("Could not determine bankId from /meroShare/bank/")

            if self.verbose:
                self._log(f"[dim]    Resolved bank: code={bank_code} id={bank_id} name={bank_name}[/dim]")
            
            # 4. Get Branch, Customer ID, Account Type
            bank_specific_resp = self._request(
                "GET",
                f"{self.api_base}/meroShare/bank/{bank_id}",
                headers=headers,
            )
            if bank_specific_resp.status_code != 200:
                body_preview = (bank_specific_resp.text or "").strip()
                raise Exception(f"Failed to get bank specific: HTTP {bank_specific_resp.status_code} {body_preview}")
            bank_specific_json = bank_specific_resp.json() if bank_specific_resp.content else None
            if isinstance(bank_specific_json, list):
                if not bank_specific_json:
                    raise Exception(f"Bank-specific list empty for bankId={bank_id}")
                
                # Log all available accounts in verbose mode for debugging merged-bank scenarios
                if self.verbose and len(bank_specific_json) > 1:
                    self._log(f"[yellow]    Found {len(bank_specific_json)} account(s) for this bank:[/yellow]")
                    for idx, acct in enumerate(bank_specific_json, 1):
                        acct_num = str(acct.get("accountNumber") or acct.get("accountNo") or "").strip()
                        branch_id = str(acct.get("accountBranchId") or acct.get("branchId") or "").strip()
                        cust_id = str(acct.get("customerId") or acct.get("id") or "").strip()
                        acct_type = str(acct.get("accountTypeName") or acct.get("accountTypeId") or "").strip()
                        self._log(
                            f"[dim]      [{idx}] account={acct_num} branch={branch_id} customer={cust_id} type={acct_type}[/dim]"
                        )

                config_branch_id = str(self.member.get("account_branch_id") or "").strip()
                if config_branch_id:
                    bank_specific = next(
                        (
                            row
                            for row in bank_specific_json
                            if str(row.get("accountBranchId") or row.get("branchId") or "").strip() == config_branch_id
                        ),
                        None,
                    )
                    if bank_specific and self.verbose:
                        self._log(f"[dim]    Matched account by config account_branch_id={config_branch_id}[/dim]")
                else:
                    bank_specific = None
                
                # Try to match by account number from myDetail
                if not bank_specific:
                    account_number_str = str(account_number).strip()
                    bank_specific = next(
                        (
                            row
                            for row in bank_specific_json
                            if str(
                                row.get("accountNumber")
                                or row.get("accountNo")
                                or row.get("account_number")
                                or ""
                            ).strip() == account_number_str
                        ),
                        None,
                    )
                
                # If no match by account number, try by CRN (for unmerged scenarios)
                if not bank_specific:
                    config_crn = self.member.get('crn_number', self.member.get('crn', ''))
                    if config_crn:
                        config_crn_norm = self._normalize_crn(config_crn)
                        bank_specific = next(
                            (
                                row
                                for row in bank_specific_json
                                if self._normalize_crn(row.get("crnNumber") or row.get("crn") or "") == config_crn_norm
                            ),
                            None,
                        )
                        if bank_specific and self.verbose:
                            self._log(f"[dim]    Matched account by config CRN[/dim]")
                
                # Fallback to first
                if bank_specific is None:
                    bank_specific = bank_specific_json[0]
                    if len(bank_specific_json) > 1:
                        self._log(f"[yellow]    ⚠ Using first account. If apply fails, note branch/customer IDs above and add 'account_branch_id' to your config.[/yellow]")
                        
            elif isinstance(bank_specific_json, dict):
                bank_specific = bank_specific_json
            else:
                raise Exception(f"Unexpected bank-specific response type: {type(bank_specific_json)}")
            
            # Store details (prefer the selected bank-specific row to avoid cross-account mismatch)
            customer_id = bank_specific.get("customerId") or bank_specific.get("id")
            branch_id = bank_specific.get("accountBranchId") or bank_specific.get("branchId")
            if not customer_id:
                customer_id = bank_req_data.get("customerId") or bank_req_data.get("customerID")
            if not branch_id:
                branch_id = (
                    bank_req_data.get("accountBranchId")
                    or bank_req_data.get("branchId")
                    or bank_req_data.get("account_branch_id")
                )
            crn_from_api = bank_req_data.get("crnNumber") or bank_req_data.get("crn")
            selected_crn = bank_specific.get("crnNumber") or bank_specific.get("crn")
            selected_account = (
                bank_specific.get("accountNumber")
                or bank_specific.get("accountNo")
                or bank_specific.get("account_number")
            )

            self._details = {
                "demat": self.account.dmat,
                "clientCode": str(customer_id or ""),
                "branchId": str(branch_id or ""),
                "crnNumber": str(selected_crn or my_detail_crn or crn_from_api or "").strip(),
                "bankId": str(bank_id),
                "bankName": bank_name,
                "accountNumber": str(selected_account or account_number or "").strip(),
                "accountTypeId": str(bank_specific.get("accountTypeId") or "1")
            }
            
            # ── CRN resolution (multi-bank aware) ────────────────────────────
            # Priority: per-bank CRN in config > API crn > top-level crn_number > prompt
            if not self._details["crnNumber"]:
                from ..config import get_member_bank_crn, set_member_bank_crn
                crn_from_bank_config = get_member_bank_crn(self.member, bank_id)
                if crn_from_bank_config:
                    self._details["crnNumber"] = crn_from_bank_config
                    self._log(f"[dim]    CRN loaded from config for bank {bank_name}[/dim]")
                else:
                    # Interactive CRN prompt
                    console.print(
                        f"\n  [yellow]⚠  No CRN found for {self.member['name']} / {bank_name}.[/yellow]"
                    )
                    try:
                        _crn_input = console.input(
                            f"  [cyan]Enter CRN for {bank_name}:[/cyan] "
                        ).strip()
                        if _crn_input:
                            self._details["crnNumber"] = _crn_input
                            # Offer to save
                            try:
                                _save_crn = console.input(
                                    f"  [cyan]Save this CRN for {bank_name} permanently? [Y/n]:[/cyan] "
                                ).strip().lower()
                                if _save_crn not in ("n", "no"):
                                    set_member_bank_crn(self.member["name"], bank_id, _crn_input)
                                    console.print(f"  [green]✓ CRN saved for {bank_name}[/green]")
                            except KeyboardInterrupt:
                                pass
                        else:
                            self._log(f"[yellow]    ⚠ CRN skipped for {self.member['name']}[/yellow]")
                    except KeyboardInterrupt:
                        self._log(f"[yellow]    ⚠ CRN entry cancelled for {self.member['name']}[/yellow]")
            else:
                # CRN came from API — also check if per-bank config overrides it
                from ..config import get_member_bank_crn
                crn_override = get_member_bank_crn(self.member, bank_id)
                if crn_override:
                    self._details["crnNumber"] = crn_override
                    self._log(f"[dim]    CRN overridden from config for bank {bank_name}[/dim]")

            if self.verbose:
                selected_acc = str(
                    bank_specific.get("accountNumber")
                    or bank_specific.get("accountNo")
                    or bank_specific.get("account_number")
                    or ""
                ).strip()
                try:
                    keys_preview = sorted(list(bank_specific.keys()))
                except Exception:
                    keys_preview = []
                crn_val = self._details.get("crnNumber", "")
                masked_crn = (
                    "*" * max(0, len(crn_val) - 3) + crn_val[-3:]
                    if crn_val and len(crn_val) > 3
                    else (crn_val or "")
                )
                self._log(
                    f"[dim]    Bank selection: bankName={self._details.get('bankName','')} bankId={self._details.get('bankId')} branchId={self._details.get('branchId')} customerId={self._details.get('clientCode')} account={selected_acc or str(account_number).strip()} crn={masked_crn}[/dim]"
                )
                if keys_preview:
                    self._log(f"[dim]    Bank fields: {', '.join(keys_preview)}[/dim]")
            
            return True
            
        except Exception as e:
            self._details_error = str(e)
            self._log(f"[red]  ✗ Error fetching details: {e}[/red]")
            return False
    
    def fetch_applicable_issues(self) -> Optional[List[Dict]]:
        """
        Fetch list of applicable IPO issues.
        
        Returns:
            List of applicable issues or None on error
        """
        if not self.is_logged_in:
            self._log(f"[red]✗ Not logged in. Call login() first.[/red]")
            return None
        
        try:
            self._log(f"[cyan]→ Fetching applicable issues for {self.member['name']}...[/cyan]")
            self._last_issues_error = ""
            
            data = {
                "filterFieldParams": [
                    {
                        "key": "companyIssue.companyISIN.script",
                        "alias": "Scrip",
                    },
                    {
                        "key": "companyIssue.companyISIN.company.name",
                        "alias": "Company Name",
                    },
                    {
                        "key": "companyIssue.assignedToClient.name",
                        "value": "",
                        "alias": "Issue Manager",
                    },
                ],
                "page": 1,
                "size": 10,
                "searchRoleViewConstants": "VIEW_APPLICABLE_SHARE",
                "filterDateParams": [
                    {
                        "key": "minIssueOpenDate",
                        "condition": "",
                        "alias": "",
                        "value": "",
                    },
                    {
                        "key": "maxIssueCloseDate",
                        "condition": "",
                        "alias": "",
                        "value": "",
                    },
                ],
            }
            
            headers = {
                "Authorization": self.account.auth_token,
                "Content-Type": "application/json",
                "User-Agent": "Mozilla/5.0"
            }
            
            response = self._request(
                "POST",
                f"{self.api_base}/meroShare/companyShare/applicableIssue/",
                headers=headers,
                json_data=data,
            )
            
            if response.status_code != 200:
                body_preview = (response.text or "").strip()
                if len(body_preview) > 400:
                    body_preview = body_preview[:400] + "..."
                self._last_issues_error = f"HTTP {response.status_code} {body_preview}".strip()
                self._log(f"[red]  ✗ Failed to fetch issues: {self._last_issues_error}[/red]")
                return None
            
            issues = response.json().get("object", [])
            self._log(f"[green]  ✓ Found {len(issues)} applicable issue(s)[/green]")
            return issues
            
        except Exception as e:
            self._last_issues_error = str(e)
            self._log(f"[red]  ✗ Error fetching issues: {e}[/red]")
            return None
    
    def find_min_apply_unit(self, company_share_id: int) -> Optional[int]:
        """
        Find minimum apply unit for a company.
        
        Args:
            company_share_id: Company share ID
            
        Returns:
            Minimum unit or None on error
        """
        if not self.is_logged_in:
            self._log(f"[red]✗ Not logged in. Call login() first.[/red]")
            return None
        
        try:
            import requests
            headers = {
                "Authorization": self.account.auth_token,
                "User-Agent": "Mozilla/5.0"
            }
            
            response = requests.get(
                f"{self.api_base}/meroShare/active/{company_share_id}",
                headers=headers
            )
            
            if response.status_code != 200:
                self._log(f"[yellow]  ⚠ Could not fetch min unit, using default (10)[/yellow]")
                return 10
            
            min_unit = int(response.json().get("minUnit", 10))
            self._log(f"[dim]  → Min apply unit: {min_unit}[/dim]")
            return min_unit
            
        except Exception as e:
            self._log(f"[yellow]  ⚠ Error getting min unit: {e}, using default (10)[/yellow]")
            return 10
    
    def apply_for_ipo(self, share_id: int, quantity: int, issue_to_apply: Optional[Dict] = None) -> Dict:
        """
        Apply for IPO shares.
        
        Args:
            share_id: Company share ID
            quantity: Number of shares to apply for
            
        Returns:
            Result dict with status and message
        """
        if not self.is_logged_in:
            return {"status": "FAILED", "message": "Not logged in"}
        
        try:
            self._log(f"[cyan]→ Applying {quantity} units for {self.member['name']}...[/cyan]")
            
            # If caller already has the selected issue (from initial list), reuse it.
            # This avoids re-fetching applicable issues which can intermittently fail.
            if issue_to_apply is None:
                applicable_issues = self.fetch_applicable_issues()
                
                if not applicable_issues:
                    details = getattr(self, "_last_issues_error", "")
                    if details:
                        return {"status": "FAILED", "message": f"Could not fetch applicable issues: {details}"}
                    return {"status": "FAILED", "message": "Could not fetch applicable issues"}
                
                issue_to_apply = None
                for issue in applicable_issues:
                    if issue.get("companyShareId") == share_id:
                        issue_to_apply = issue
                        break
                
                if not issue_to_apply:
                    return {"status": "FAILED", "message": "Share ID not found in applicable issues"}
            
            # Check if already applied
            if issue_to_apply.get("action"):
                return {"status": "CREATED", "message": "Issue already applied!"}
            
            # Prepare application data
            import requests
            headers = {
                "Authorization": self.account.auth_token,
                "Content-Type": "application/json",
                "User-Agent": "Mozilla/5.0",
                "Pragma": "no-cache",
                "Cache-Control": "no-cache"
            }
            
            # Ensure we have details
            if not self.details.get("crnNumber"):
                if not self.fetch_detailed_info():
                    detail_err = self.details_error
                    if detail_err:
                        return {"status": "FAILED", "message": f"Could not fetch necessary account details: {detail_err}"}
                    return {"status": "FAILED", "message": "Could not fetch necessary account details"}
            
            # Get account details
            details = self.details
            boid = self.account.dmat if self.account.dmat else self.account.username
            
            # Check for missing CRN
            if not details.get("crnNumber"):
                return {"status": "FAILED", "message": "CRN Number is required but missing"}

            # Validate transaction PIN — Meroshare requires exactly 4 digits
            _pin_raw = str(self.member.get('transaction_pin', self.member.get('pin', '')) or '')
            if not (_pin_raw.isdigit() and len(_pin_raw) == 4):
                return {
                    "status": "FAILED",
                    "message": (
                        f"Transaction PIN for {self.member.get('name','member')} must be exactly "
                        f"4 digits (got {repr(_pin_raw)}). "
                        f"Please update it in Member Management."
                    )
                }

            # Keep CRN exactly as configured (including bank-specific separators like '-')
            # for the first submit. Only fallback retries will try normalized variants.
            crn_for_apply = str(details.get("crnNumber", "") or "").strip()

            data = {
                "demat": details.get("demat"),
                "boid": boid[-8:] if len(boid) >= 8 else boid,
                "accountNumber": details.get("accountNumber", details.get("demat")),
                "customerId": details.get("clientCode", ""),
                "accountBranchId": details.get("branchId", ""),
                "accountTypeId": details.get("accountTypeId", "1"),
                "appliedKitta": str(quantity),
                "crnNumber": crn_for_apply,
                "transactionPIN": str(self.member.get('transaction_pin', self.member.get('pin', ''))),
                "companyShareId": str(share_id),
                "bankId": details.get("bankId", ""),
            }

            def _post_apply(payload: Dict):
                return self._request(
                    "POST",
                    f"{self.api_base}/meroShare/applicantForm/share/apply",
                    headers=headers,
                    json_data=payload,
                )

            response = _post_apply(data)
            
            if response.status_code == 201:
                result = response.json()
                return {"status": "CREATED", "message": result.get("message", "Success")}
            else:
                def _extract_error_message(resp) -> str:
                    msg = f"Failed with status {resp.status_code}"
                    try:
                        error_data = resp.json()
                        # API may return a list of field-level validation errors
                        if isinstance(error_data, list) and error_data:
                            msg = "; ".join(
                                e.get("message", "") for e in error_data if isinstance(e, dict) and e.get("message")
                            ) or msg
                        elif isinstance(error_data, dict):
                            msg = error_data.get("message", msg)
                    except Exception:
                        pass
                    return msg

                error_msg = _extract_error_message(response)

                if self.verbose:
                    self._log(f"[dim]  ✗ Apply failed: HTTP {response.status_code} {error_msg}[/dim]")

                if isinstance(error_msg, str) and "invalid crn" in error_msg.lower():
                    bank_hint = details.get("bankName") or ""
                    bank_id_hint = details.get("bankId") or ""
                    acct_hint = details.get("accountNumber") or ""
                    hint_bits = []
                    if bank_hint or bank_id_hint:
                        hint_bits.append(f"linked bank: {bank_hint} (id {bank_id_hint})".strip())
                    if acct_hint:
                        hint_bits.append(f"account: {acct_hint}")
                    if hint_bits:
                        error_msg = f"{error_msg}. Possible mismatch with {', '.join(hint_bits)}"

                return {"status": "FAILED", "message": error_msg}
                
        except Exception as e:
            return {"status": "FAILED", "message": str(e)}


def display_ipo_issues_table(issues: List[Dict], auth_token: Optional[str] = None) -> None:
    """Display IPO issues in a formatted table with detailed info."""
    table = Table(
        title="📋 Available IPO Issues",
        box=box.ROUNDED,
        header_style="bold cyan",
        expand=True,
    )
    
    # Determine if we should fetch detailed info
    fetch_details = auth_token is not None
    
    if fetch_details:
        table.add_column("#", style="dim", width=3, justify="center")
        table.add_column("Scrip", style="bold magenta", width=8)
        table.add_column("Company", style="white", width=24)
        table.add_column("Min", style="green", width=5, justify="right")
        table.add_column("Max", style="yellow", width=7, justify="right")
        table.add_column("Shr/Unit", style="dim", width=8, justify="right")
        table.add_column("Opens", style="cyan", width=16)
        table.add_column("Closes", style="red", width=16)
        table.add_column("Remarks", style="green", width=22)
    else:
        table.add_column("#", style="dim", width=4, justify="center")
        table.add_column("Share ID", style="yellow", width=10, justify="center")
        table.add_column("Scrip", style="bold magenta", width=12)
        table.add_column("Company Name", style="white")
        table.add_column("Type", style="cyan", width=15)
        table.add_column("Group", style="green", width=20)
        table.add_column("Close Date", style="dim", width=12)
    
    for idx, issue in enumerate(issues, 1):
        if fetch_details:
            # Fetch detailed info for this IPO
            share_id = issue.get("companyShareId")
            detailed_info = fetch_ipo_detailed_info(share_id, auth_token)
            
            if detailed_info:
                remarks = detailed_info.get("prospectusRemarks") or ""
                if len(remarks) > 22:
                    remarks = remarks[:19] + "..."

                table.add_row(
                    str(idx),
                    detailed_info.get("scrip", ""),
                    (detailed_info.get("companyName") or issue.get("companyName", ""))[:24],
                    str(detailed_info.get("minUnit", "")),
                    f"{detailed_info.get('maxUnit', 0):,}",
                    str(int(detailed_info.get("sharePerUnit", 0) or 0)),
                    detailed_info.get("minIssueOpenDateStr", "") or "",
                    detailed_info.get("maxIssueCloseDateStr", "") or "",
                    remarks,
                )
            else:
                # Fallback to basic info
                table.add_row(
                    str(idx),
                    issue.get("scrip", ""),
                    issue.get("companyName", "")[:24],
                    "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A"
                )
        else:
            # Basic display without auth token
            table.add_row(
                str(idx),
                str(issue.get("companyShareId", "")),
                issue.get("scrip", ""),
                issue.get("companyName", ""),
                issue.get("shareTypeName", ""),
                issue.get("shareGroupName", ""),
                issue.get("issueCloseDate", "")[:10] if issue.get("issueCloseDate") else ""
            )
    
    console.print(table)
    
    # Add helpful legend if detailed view
    if fetch_details:
        console.print("[dim]💡 Detailed view uses /meroShare/active/{companyShareId}: Min/Max/Multiple, shares per unit, open/close, remarks[/dim]")


def fetch_ipo_detailed_info(company_share_id: int, auth_token: str) -> Optional[Dict]:
    """Fetch detailed IPO information including min/max units, price, etc."""
    try:
        import requests
        headers = {
            "Authorization": auth_token,
            "User-Agent": "Mozilla/5.0"
        }
        
        response = requests.get(
            f"https://webbackend.cdsc.com.np/api/meroShare/active/{company_share_id}",
            headers=headers,
            timeout=10
        )
        
        if response.status_code == 200:
            return response.json()
    except Exception:
        pass
    
    return None


def apply_ipo_fast(member_name: Optional[str] = None) -> None:
    """
    Fast API-based IPO application for a single member.
    
    Args:
        member_name: Optional specific member name
    """
    from ..config import get_member_by_name, get_all_members
    from ..ui.member_ui import select_family_member
    
    member = None
    if member_name:
        member = get_member_by_name(member_name)
        if not member:
            console.print(f"\n[red]✗ Member '{member_name}' not found.[/red]")
            return
    
    if not member:
        member = select_family_member()
    
    if not member:
        console.print("\n[red]✗ No member selected. Exiting...[/red]")
        return
    
    # Allow apply if crn_number OR bank_crns are configured; CRN can also be entered
    # interactively at the apply step for multi-bank accounts with no CRN yet saved.
    if not member.get('crn_number') and not member.get('bank_crns'):
        console.print(
            "[yellow]⚠  No CRN configured for this member. "
            "You will be prompted to enter it during the apply step.[/yellow]"
        )
    
    console.print(f"\n[bold green]✓ Fast IPO Application for:[/bold green] {member['name']}")
    console.print(f"[bold green]✓ Kitta:[/bold green] {member['applied_kitta']}\n")
    
    # Initialize and login
    import os
    verbose = os.environ.get("NEPSE_VERBOSE", "").strip().lower() in {"1", "true", "yes", "y"}
    app = IPOApplicationFast(member, verbose=verbose)

    with console.status(f"[bold green]Logging in {member['name']}...[/bold green]", spinner="dots"):
        if not app.login():
            console.print(f"[red]✗ Login failed for {member['name']}[/red]")
            return

    try:
        with console.status("[bold green]Fetching applicable IPOs...[/bold green]", spinner="dots"):
            issues = app.fetch_applicable_issues()

        if not issues:
            console.print("[yellow]⚠ No applicable IPO issues found[/yellow]")
            return

        console.print()
        display_ipo_issues_table(issues, app.account.auth_token)

        # Select IPO
        try:
            choice = console.input("\n[cyan]Select IPO number to apply (or press Enter to skip):[/cyan] ").strip()

            if not choice:
                console.print("[yellow]Cancelled[/yellow]")
                return

            idx = int(choice) - 1
            if not (0 <= idx < len(issues)):
                console.print("[red]Invalid selection[/red]")
                return

            selected_issue = issues[idx]
            share_id = selected_issue.get("companyShareId")
            company_name = selected_issue.get("companyName")

            console.print(f"\n[green]✓ Selected: {company_name}[/green]")
            console.print(f"[dim]Share ID: {share_id}[/dim]\n")

            quantity_input = console.input("[cyan]Enter quantity (or press Enter for minimum unit):[/cyan] ").strip()

            if quantity_input:
                quantity = int(quantity_input)
            else:
                min_unit = app.find_min_apply_unit(share_id)
                quantity = min_unit or member['applied_kitta']
                console.print(f"[cyan]Using minimum quantity: {quantity}[/cyan]\n")

        except (ValueError, KeyboardInterrupt):
            console.print("\n[yellow]Cancelled[/yellow]")
            return

        with console.status(f"[bold green]Applying {quantity} units...[/bold green]", spinner="dots"):
            result = app.apply_for_ipo(share_id, quantity, issue_to_apply=selected_issue)

        console.print()
        if result.get("status") == "CREATED":
            msg = (result.get("message") or "").lower()
            if "already" in msg:
                console.print("[yellow]⚠ Already applied[/yellow]")
            else:
                console.print("[bold green]✓ Application submitted[/bold green]")
        else:
            console.print(f"[red]✗ Application failed: {result.get('message')}[/red]")

    finally:
        app.logout()


def apply_ipo_for_all_members_fast() -> None:
    """Fast API-based IPO application for multiple family members."""
    from ..config import get_all_members
    from ..ui.member_ui import select_members_for_ipo
    
    all_members = get_all_members()
    
    if not all_members:
        console.print(Panel(
            "[bold red]⚠ No family members found. Add members first![/bold red]",
            box=box.ROUNDED, 
            border_style="red"
        ))
        return
    
    # Interactive selection
    console.print()
    members = select_members_for_ipo(all_members)
    
    if not members:
        return
    
    # Show selected members
    console.print()
    table = Table(
        title="✓ Selected Members for Fast IPO Application",
        box=box.ROUNDED,
        header_style="bold green",
        border_style="green"
    )
    table.add_column("No.", justify="right", style="cyan")
    table.add_column("Name", style="bold white")
    table.add_column("Kitta", justify="right", style="yellow")
    
    for idx, member in enumerate(members, 1):
        table.add_row(
            str(idx),
            member['name'],
            str(member['applied_kitta'])
        )
    
    console.print(table)
    console.print()
    
    # Login first member to get available IPOs
    console.print(Rule("[bold cyan]FETCHING AVAILABLE IPOs[/bold cyan]"))
    console.print()
    
    first_app = IPOApplicationFast(members[0], verbose=False)
    with console.status("[bold green]Fetching available IPOs...[/bold green]", spinner="dots"):
        if not first_app.login():
            console.print("[red]✗ Failed to login first member. Cannot proceed.[/red]")
            return
    
    try:
        issues = first_app.fetch_applicable_issues()
        
        if not issues:
            console.print("[yellow]⚠ No applicable IPO issues found[/yellow]")
            return
        
        console.print()
        # Pass auth token to display detailed info
        display_ipo_issues_table(issues, first_app.account.auth_token)
        
        # Select IPO
        try:
            choice = console.input(f"\n[cyan]Select IPO number to apply (1-{len(issues)}):[/cyan] ").strip()
            
            if not choice:
                console.print("[yellow]Cancelled[/yellow]")
                return
            
            idx = int(choice) - 1
            if not (0 <= idx < len(issues)):
                console.print("[red]Invalid selection[/red]")
                return
            
            selected_issue = issues[idx]
            share_id = selected_issue.get("companyShareId")
            company_name = selected_issue.get("companyName")
            
            console.print(f"\n[green]✓ Selected: {company_name}[/green]")
            console.print(f"[dim]Share ID: {share_id}[/dim]\n")
            
            # Get quantity or use minimum
            quantity_input = console.input("[cyan]Enter quantity for all members (or press Enter for minimum):[/cyan] ").strip()
            
            if quantity_input:
                quantity = int(quantity_input)
            else:
                min_unit = first_app.find_min_apply_unit(share_id)
                quantity = min_unit or 10
                console.print(f"[cyan]Using minimum quantity: {quantity}[/cyan]\n")
            
        except (ValueError, KeyboardInterrupt):
            console.print("\n[yellow]Cancelled[/yellow]")
            return
        
    finally:
        first_app.logout()
    
    # Apply for all members in parallel
    console.print()
    console.print(Rule(f"[bold cyan]APPLYING FOR {len(members)} MEMBER(S) IN PARALLEL[/bold cyan]"))
    console.print()
    
    results_table = Table(
        title=f"IPO Application Results - {company_name}",
        box=box.ROUNDED,
        header_style="bold cyan",
        expand=True,
    )
    
    results_table.add_column("Member", style="white")
    results_table.add_column("Quantity", style="cyan", justify="center")
    results_table.add_column("Status", style="bold", justify="center")
    results_table.add_column("Message", style="dim")
    
    results = []
    console_lock = Lock()
    
    def apply_for_member(member: Dict) -> Dict:
        """Worker function to apply IPO for a single member."""
        app = IPOApplicationFast(member, verbose=False)
        result = None
        
        try:
            if not app.login():
                result = {
                    "member": member['name'],
                    "quantity": quantity,
                    "status": "FAILED",
                    "message": "Login failed"
                }
            else:
                try:
                    ipo_result = app.apply_for_ipo(share_id, quantity)
                    result = {
                        "member": member['name'],
                        "quantity": quantity,
                        "status": ipo_result.get("status", "UNKNOWN"),
                        "message": ipo_result.get("message", "")
                    }
                finally:
                    app.logout()
            
            # Print immediate status (thread-safe)
            with console_lock:
                if result:
                    if result.get("status") == "CREATED":
                        msg = (result.get("message") or "").lower()
                        if "already" in msg:
                            console.print(f"[yellow]⚠ {member['name']}: Already applied[/yellow]")
                        else:
                            console.print(f"[green]✓ {member['name']}: Applied successfully[/green]")
                    else:
                        console.print(f"[red]✗ {member['name']}: Failed - {result.get('message', 'Unknown error')}[/red]")
            
            return result
            
        except Exception as e:
            with console_lock:
                console.print(f"[red]✗ {member['name']}: Exception - {str(e)}[/red]")
            return {
                "member": member['name'],
                "quantity": quantity,
                "status": "FAILED",
                "message": str(e)
            }
    
    # Execute applications in parallel
    with console.status("[bold green]Processing applications in parallel...[/bold green]", spinner="dots"):
        with ThreadPoolExecutor(max_workers=len(members)) as executor:
            # Submit all tasks
            future_to_member = {executor.submit(apply_for_member, member): member for member in members}
            
            # Collect results as they complete
            for future in as_completed(future_to_member):
                try:
                    result = future.result()
                    results.append(result)
                except Exception as e:
                    member = future_to_member[future]
                    with console_lock:
                        console.print(f"[red]✗ {member['name']}: Unexpected error - {str(e)}[/red]")
                    results.append({
                        "member": member['name'],
                        "quantity": quantity,
                        "status": "FAILED",
                        "message": str(e)
                    })
    
    # Display results
    console.print()
    
    for result in results:
        status_style = "green" if result["status"] == "CREATED" else "red"
        status_text = "✓ SUCCESS" if result["status"] == "CREATED" else "✗ FAILED"
        
        results_table.add_row(
            result["member"],
            str(result["quantity"]),
            f"[{status_style}]{status_text}[/{status_style}]",
            result["message"]
        )
    
    console.print(results_table)
    
    # Summary
    success_count = sum(1 for r in results if r["status"] == "CREATED")
    console.print(f"\n[bold]Summary:[/bold]")
    console.print(f"  • Successful: [green]{success_count}[/green]")
    console.print(f"  • Failed: [red]{len(results) - success_count}[/red]")
    
    if success_count == len(results):
        console.print("\n[bold green]🎉 ALL APPLICATIONS SUCCESSFUL![/bold green]")
