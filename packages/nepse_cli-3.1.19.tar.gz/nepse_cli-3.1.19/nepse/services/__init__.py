"""
Services modules for external API calls and data fetching.
"""
