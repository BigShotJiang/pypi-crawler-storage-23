"""Tests for MemoryStore — real ChromaDB with temp directory."""

import pytest

from neo_cortex.models import Activity, MemoryRecord, MemoryType
from neo_cortex.store import MemoryStore


class TestMemoryStoreInsertAndQuery:
    def test_insert_and_count(self, tmp_store, sample_record, sample_embedding):
        assert tmp_store.count() == 0
        tmp_store.insert(sample_record, sample_embedding)
        assert tmp_store.count() == 1

    def test_insert_and_query_returns_record(self, tmp_store, sample_record, sample_embedding):
        tmp_store.insert(sample_record, sample_embedding)
        results = tmp_store.query(sample_embedding, n=1)
        assert len(results) == 1
        record, similarity = results[0]
        assert record.id == sample_record.id
        assert record.project == "neo-reloaded"
        assert record.activity == Activity.BUGFIX
        assert similarity > 0.9  # Same embedding should be very similar

    def test_query_empty_store(self, tmp_store, sample_embedding):
        results = tmp_store.query(sample_embedding, n=5)
        assert results == []

    def test_insert_multiple_and_query_top_n(self, tmp_store, sample_embedding, sample_embedding_2):
        rec1 = MemoryRecord(
            id="v3_a_0_1", session_id="s1", question="Q1", answer_preview="A1",
            document="Q: Q1\nA: A1", project="p1",
        )
        rec2 = MemoryRecord(
            id="v3_b_0_2", session_id="s1", question="Q2", answer_preview="A2",
            document="Q: Q2\nA: A2", project="p2",
        )
        tmp_store.insert(rec1, sample_embedding)
        tmp_store.insert(rec2, sample_embedding_2)

        results = tmp_store.query(sample_embedding, n=1)
        assert len(results) == 1
        assert results[0][0].id == "v3_a_0_1"


class TestMemoryStoreEnergy:
    def test_update_energy(self, tmp_store, sample_record, sample_embedding):
        tmp_store.insert(sample_record, sample_embedding)
        tmp_store.update_energy(sample_record.id, 0.5)

        # Verify via metadata
        all_meta = tmp_store.get_all_metadata()
        assert len(all_meta) == 1
        assert all_meta[0]["energy"] == 0.5


class TestMemoryStoreStats:
    def test_stats_empty(self, tmp_store):
        stats = tmp_store.stats(dream_count=0)
        assert stats.total_memories == 0
        assert stats.dream_count == 0

    def test_stats_with_data(self, tmp_store, sample_record, sample_embedding, sample_embedding_2):
        tmp_store.insert(sample_record, sample_embedding)
        rec2 = MemoryRecord(
            id="v3_b_0_2", session_id="s2", question="Q2", answer_preview="A2",
            document="Q: Q2\nA: A2", project="general",
        )
        tmp_store.insert(rec2, sample_embedding_2)

        stats = tmp_store.stats(dream_count=3)
        assert stats.total_memories == 2
        assert stats.sessions == 2
        assert stats.dream_count == 3
        assert stats.avg_energy == 1.0
        assert "neo-reloaded" in stats.projects
        assert "general" in stats.projects


class TestMemoryStoreTimeline:
    def test_timeline_ordered_by_timestamp(self, tmp_store, sample_embedding, sample_embedding_2):
        rec_old = MemoryRecord(
            id="v3_old_0_1", session_id="s1", timestamp=1000.0,
            question="Old", answer_preview="Old answer", document="Q: Old\nA: Old answer",
        )
        rec_new = MemoryRecord(
            id="v3_new_0_2", session_id="s1", timestamp=2000.0,
            question="New", answer_preview="New answer", document="Q: New\nA: New answer",
        )
        tmp_store.insert(rec_old, sample_embedding)
        tmp_store.insert(rec_new, sample_embedding_2)

        timeline = tmp_store.timeline(limit=10)
        assert len(timeline) == 2
        assert timeline[0].id == "v3_new_0_2"  # Newest first
        assert timeline[1].id == "v3_old_0_1"

    def test_timeline_project_filter(self, tmp_store, sample_record, sample_embedding, sample_embedding_2):
        tmp_store.insert(sample_record, sample_embedding)  # project=neo-reloaded
        rec2 = MemoryRecord(
            id="v3_b_0_2", session_id="s2", question="Q2", answer_preview="A2",
            document="Q: Q2\nA: A2", project="general",
        )
        tmp_store.insert(rec2, sample_embedding_2)

        timeline = tmp_store.timeline(limit=10, project="neo-reloaded")
        assert len(timeline) == 1
        assert timeline[0].project == "neo-reloaded"


class TestMemoryStoreMetadataRoundtrip:
    def test_activity_enum_roundtrip(self, tmp_store, sample_embedding):
        rec = MemoryRecord(
            id="v3_rt_0_1", session_id="s1", question="Q", answer_preview="A",
            document="Q: Q\nA: A", activity=Activity.DEPLOY,
            memory_type=MemoryType.PROCEDURAL,
        )
        tmp_store.insert(rec, sample_embedding)

        timeline = tmp_store.timeline()
        assert len(timeline) == 1
        assert timeline[0].activity == Activity.DEPLOY
        assert timeline[0].memory_type == MemoryType.PROCEDURAL

    def test_tools_used_roundtrip(self, tmp_store, sample_embedding):
        rec = MemoryRecord(
            id="v3_tools_0_1", session_id="s1", question="Q", answer_preview="A",
            document="Q: Q\nA: A", tools_used=["Read", "Bash", "Edit"],
        )
        tmp_store.insert(rec, sample_embedding)

        timeline = tmp_store.timeline()
        assert timeline[0].tools_used == ["Read", "Bash", "Edit"]
