"""Shared test fixtures."""

import os
import tempfile

import pytest

from neo_cortex.store import MemoryStore
from neo_cortex.models import Activity, MemoryRecord, MemoryType


@pytest.fixture
def tmp_store(tmp_path):
    """MemoryStore with a temporary directory (real ChromaDB, ephemeral)."""
    return MemoryStore(str(tmp_path), collection_name="test_memories")


@pytest.fixture
def sample_record() -> MemoryRecord:
    """A sample MemoryRecord for testing."""
    return MemoryRecord(
        id="v3_test1234_0_12345",
        session_id="test-session-1234",
        timestamp=1707300000.0,
        turn_number=0,
        question="How do I fix the crash?",
        answer_preview="The crash was caused by InvalidOperationException...",
        document="Q: How do I fix the crash?\nA: The crash was caused by InvalidOperationException in the stdout reader.",
        project="neo-reloaded",
        topic="crash fix",
        activity=Activity.BUGFIX,
        memory_type=MemoryType.EPISODIC,
        energy=1.0,
        model="opus",
        source="neo-cortex",
        tools_used=["Read", "Edit"],
    )


@pytest.fixture
def sample_embedding() -> list[float]:
    """A fake 1024-dim embedding for testing."""
    import random
    random.seed(42)
    return [random.uniform(-1, 1) for _ in range(1024)]


@pytest.fixture
def sample_embedding_2() -> list[float]:
    """A different fake embedding."""
    import random
    random.seed(99)
    return [random.uniform(-1, 1) for _ in range(1024)]
