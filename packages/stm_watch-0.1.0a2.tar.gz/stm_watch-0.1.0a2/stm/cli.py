"""
Docstring for for the client CLI
This module provides a command-line interface for configuring file watchers,
handling user authentication, and submitting file modifications to a server.
It supports commands for configuring directories to watch, logging in and out, and starting the watcher to monitor file changes.
"""

from pathlib import Path
from typing import Optional
import time
import sys
from datetime import datetime, timezone
import argparse
import requests.cookies
from shared.schemas import FileModification
from stm import config
from stm import request as request_api
from stm.watcher import Watcher, WatchConfiguration, SOURCE_FILE_EXTENSIONS

DEFAULT_SERVER = "https://alpha.stopthemadness.ai"

def report_configured_watchers(
        watchers: list[WatchConfiguration],
        show_watched_files: bool = False,
        truncate: bool = True
    ) -> None:
    """Print configured watchers."""
    if not watchers:
        return

    print(f"Configured watchers ({len(watchers)}):")
    for watcher in watchers:
        patterns = ", ".join(watcher.watched_extensions) or "(none)"
        ignores = ", ".join(watcher.ignored_patterns) or "(none)"
        print(f"{watcher.directory}")
        print(f"Patterns: {patterns} | Ignore: {ignores}")
        if show_watched_files:
            files = watcher.collect_watched_files()
            for f in files[:(truncate and 10 or len(files))]:
                print(f"    - {f}")
            if len(files) > 10 and truncate:
                print(f"    - ... and {len(files) - 10} more files")
        print("")

def prompt_email(confirm: bool = False) -> str:
    """Prompt user for email."""
    while True:
        email = input("Email: ").strip()
        confirm_email = input("Confirm email: ").strip() if confirm else None
        if not email:
            print("Email cannot be empty.")
        elif confirm and email != confirm_email:
            print("Emails do not match. Please try again.")
        else:
            return email

def prompt_password(prompt_str: str = "Password: ", confirm: bool = False) -> str:
    """Prompt user for password."""
    import getpass
    first = getpass.getpass(prompt_str)
    if not first:
        print("Password cannot be empty.")
        return prompt_password(prompt_str, confirm)
    if confirm:
        second = getpass.getpass("Confirm password: ")
        if first != second:
            print("Passwords do not match. Please try again.")
            return prompt_password(prompt_str, confirm)
    return first

def prompt(prompt_str: str, can_be_empty: bool = False) -> str:
    """Generic prompt function."""
    while True:
        response = input(prompt_str).strip()
        if not response and not can_be_empty:
            print("Input cannot be empty.")
        else:
            return response

def handle_register_command(server_url: str):
    print(f"Registering with {server_url}...")
    firstname = prompt("First name: ")
    lastname = prompt("Last name: ")
    email = prompt_email(confirm=True)
    password = prompt_password("Password: ", confirm=True)
    city = prompt("City (optional, press Enter to skip): ", can_be_empty=True)
    state = prompt("State (optional, press Enter to skip): ", can_be_empty=True)
    organization = prompt("Organization (optional, press Enter to skip): ", can_be_empty=True)
    request_api.register(
        server_url,
        firstname=firstname,
        lastname=lastname,
        email=email,
        password=password,
        city=city or None,
        state=state or None,
        organization=organization or None,
    )

def on_change_callback(
    session_cookies: Optional[requests.cookies.RequestsCookieJar] = None,
    server_url: str = "",
    offline: bool = False,
):
    """Returns a callback function that can be passed to the Watcher to handle file changes.
    The callback will print the modified file and its contents, and if not in offline mode, submit the changes to the server."""
    def callback(filepath: Path, content: str, prev_content: Optional[str]):
        import difflib
        now = datetime.now(timezone.utc)
        print(f"\n[{now.strftime('%Y-%m-%d-%H:%M:%S.%f')}] [Modified] {filepath}")
        # If there is no previous content recorded, print snippet of current content
        if prev_content is None:
            print("--- File Contents ---")
            lines = content.splitlines(keepends=True)
            print("".join(lines[:15]), "\n..." if len(lines) > 15 else "")
        else:
            # If there is previous content, print a diff of the changes
            diff = difflib.unified_diff(
                prev_content.splitlines(keepends=True),
                content.splitlines(keepends=True),
                fromfile="previous",
                tofile="current",
            )
            print("".join(diff).rstrip("\n"))
        
        if not offline:
            if not session_cookies or not server_url:
                print("  ✗ No session cookies or server URL provided, cannot submit.")
                return
            modification = FileModification(
                filename=filepath.name,
                fullpath=str(filepath.resolve()),
                content=content,
                modified_at=now.timestamp(),
            )
            request_api.submit(modification, server_url, session_cookies)
        print("-" * 40, flush=True)
    return callback

def main():
    session_data = config.load_session()
    server_url = DEFAULT_SERVER if not session_data else session_data.server_url
    
    # Create parent parser with common arguments
    parent_parser = argparse.ArgumentParser(add_help=False)
    parent_parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose output"
    )
    
    parser = argparse.ArgumentParser(description="Watch files for changes and submit modifications.", parents=[parent_parser])
    
    # Create subparsers for commands
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Watch command
    watch_parser = subparsers.add_parser(
        "watch",
        parents=[parent_parser],
        help="Configure a directory to watch",
        usage="stm watch DIRECTORY PATTERN [PATTERN ...] [-i IGNORE [IGNORE ...]] [-v]",
        formatter_class=argparse.RawDescriptionHelpFormatter, # This is so the epilog displays correctly
        epilog="""
Examples:
  stm watch . .py                                   Watch all .py files in current directory tree
  stm watch . .py .java                             Watch .py and .java files
  stm watch /path/to/project .py -i "__*__.py"      Watch .py files, ignore __*__.py
  stm watch . .c .h -i "testspace/*"                Watch .c and .h files, ignore all files in testspace/ file tree
"""
    )
    watch_parser.add_argument("directory", help="Directory path to watch for changes")
    watch_parser.add_argument(
        "patterns",
        nargs="*",
        help="File extensions to watch (e.g., .py .txt). If not provided, defaults to common source code extensions."
    )
    watch_parser.add_argument(
        "-i", "--ignore",
        nargs="+",
        default=[],
        help="file patterns to ignore ( e.g., dir_to_ignore/* or test_*.py) NOTE: UNSTABLE, idk exactly what the semantics of these patterns ought to be yet"
        # TODO How should these ignore patterns work? I like being able to ignore entire directories with dir/*, but should I also support ignoring specific files with patterns like test_*.py?
        # What about ignoring specific files regardless of directory with patterns like __*__.py?
        # Right now the implementation is a bit inconsistent and hacky, need to clean it up and make the semantics clear
        # For now, I'm thinking the pattern will be matched against both the path relative to the watched directory and the filename,
        # and if either match, then it is ignored
        # should we use * to match anything besides a separator and ** to match anything including separators, like in .gitignore? That might be more intuitive
    )

    # Unwatch command
    unwatch_parser = subparsers.add_parser("unwatch", parents=[parent_parser], help="Remove a configured watcher")
    unwatch_parser.add_argument("directory", help="Directory path to stop watching")

    # Login command
    login_parser = subparsers.add_parser("login", parents=[parent_parser], help="Login and cache session")
    login_parser.add_argument(
        "server_url",
        nargs="?",
        default=None,
        help=f"Server URL (default: {server_url})",
    )
    login_parser.add_argument("-u", "--user", help="Email for login (give browser link to login if not provided)")

    # Logout command
    logout_parser = subparsers.add_parser("logout", parents=[parent_parser], help="Logout and clear cached session")
    # logout_parser.add_argument("server_url", nargs="?", default=server_url, help=f"Server URL (default: {server_url})")
    
    # Whoami command
    whoami_parser = subparsers.add_parser("whoami", parents=[parent_parser], help="Show current cached session info")

    # Password change command
    password_parser = subparsers.add_parser("password", parents=[parent_parser], help="Change account password")

    # Register command
    register_parser = subparsers.add_parser("register", parents=[parent_parser], help="Submit a registration request")
    register_parser.add_argument(
        "server_url",
        nargs="?",
        default=None,
        help=f"Server URL (default: {server_url})",
    )

    # Start command
    start_parser = subparsers.add_parser("start", parents=[parent_parser], help="Start watching files")
    start_parser.add_argument("--offline", action="store_true", help="Run watcher in offline mode (no submissions)")

    # Parse args, but allow no command (defaults to files with positional args)
    args = parser.parse_args()
    
    # Handle commands
    if args.command == "login":
        server_url = (args.server_url or server_url).rstrip('/')
        print(f"Logging in to {server_url}...")
        if args.user:
            email = args.user
            password = prompt_password()
            request_api.login(server_url, email=email, password=password)
        else:
            request_api.login(server_url, in_browser=True)
        print("✓ Logged in successfully")
    
    elif args.command == "logout":
        if not session_data:
            print("No active session found")
        else:
            session_cookies = config.session_cookiejar(session_data)
            response = request_api.logout(session_data.server_url, session_cookies)
            print(response.json()["message"])
            config.clear_session()
            print("✓ Logged out and cleared cached session")
    
    elif args.command == "whoami":
        if not session_data:
            print("No active session")
            return
        print("You are", session_data.username)
        print("You like stopping the madness by sending file changes to", session_data.server_url)

    elif args.command == "password":
        if not session_data or not session_data.username or not session_data.server_url:
            print("No cached account details found. Please login first using 'stm login'.")
            sys.exit(1)
        old_password = prompt_password("Old password: ")
        new_password = prompt_password("New password: ", confirm=True)
        request_api.change_password(
            session_data.server_url,
            session_data.username,
            old_password,
            new_password,
        )
    
    elif args.command == "register":
        reg_server_url = (args.server_url or server_url).rstrip('/')
        handle_register_command(reg_server_url)

    elif args.command == "watch":
        directory = Path(args.directory).resolve()
        if not directory.exists():
            print(f"✗ Directory does not exist: {directory}")
            sys.exit(1)
        if not directory.is_dir():
            print(f"✗ Path is not a directory: {directory}")
            sys.exit(1)

        print(f"Configuring watcher for {directory}...")
        watch_config = WatchConfiguration(
            directory=directory,
            watched_extensions=args.patterns if args.patterns else SOURCE_FILE_EXTENSIONS,
            ignored_patterns=args.ignore,
        )
        config.add_configuration(watch_config)
        report_configured_watchers([watch_config], show_watched_files=True, truncate=not args.verbose)
    
    # Remove the watch configuration specified by the user, matching by directory path given
    elif args.command == "unwatch":
        directory = Path(args.directory).resolve()
        if not directory.exists():
            print("That directory does not exist")
            sys.exit(1)
        if not directory.is_dir():
            print("That path is not a directory")
            sys.exit(1)

        watched_dirs = [c.directory for c in config.load_watch_configurations()]
        watched_ancestors = [a for a in watched_dirs if directory.is_relative_to(a) and a != directory]
        dir_has_configuration = directory in watched_dirs
        dir_is_watched_thru_ancestor = bool(watched_ancestors)

        if not dir_has_configuration:
            print(f"A watch configuration is not rooted at {directory}")
            if dir_is_watched_thru_ancestor:
                print("However, that directory is a descendant of the following watched directories:")
                for ancestor in watched_ancestors:
                    print(f"  - {ancestor}")
            sys.exit(1)

        config.delete_configuration(directory)
        print(f"Removed watcher configuration for {directory}")
        if dir_is_watched_thru_ancestor:
            print("Note: That directory might still be watched as a descendant of the following watched directories:")
            for ancestor in watched_ancestors:
                print(f"  - {ancestor}")

    elif args.command == "start":
        if not args.offline:
            if session_data is None:
                print("✗ Please login first using 'stm login' command.")
                sys.exit(1)
            session_data = config.refresh_session()
            if session_data is None:
                print("✗ Session refresh failed. Please login again using 'stm login' command.")
                sys.exit(1)
        session_cookies = None if session_data is None else config.session_cookiejar(session_data)
        server_url = "" if session_data is None else session_data.server_url

        configurations = config.load_watch_configurations()
        if not configurations:
            print("No configured watchers. Run 'stm watch' to configure one.")
            sys.exit(1)
        
        print("Starting watcher...")
        watcher = Watcher(
            configurations=configurations,
            on_change=on_change_callback(
                session_cookies=session_cookies,
                server_url=server_url,
                offline=args.offline)
        )
        print("On startup, there are {} files being watched.".format(len(watcher.collect_watched_files())))
        watcher.start()
        print("Watcher started. Press Ctrl+C to stop.")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("Stopping watcher...")
            watcher.stop()
            watcher.join()
            print("Watcher stopped.")
    else:
        # default behavior if no command is given, report version and configured watchers
        print(f"StopTheMadness CLI, version {config.get_version()}")
        if session_data:
            print(f"configured to send file changes to {session_data.server_url}")
        configurations = config.load_watch_configurations()
        if not configurations:
            print("No configured watchers. Run 'stm watch' to configure one.")
        else:
            report_configured_watchers(configurations, show_watched_files=True, truncate=not args.verbose)
        print("Use 'stm -h' for help on commands.")



if __name__ == "__main__":
    main()
