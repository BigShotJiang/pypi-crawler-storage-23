"""
This module defines a Watcher for monitoring files. It uses the watchdog library.
The user can configure directories to watch and which files to monitor,
and provide a callback that is triggered when those files are modified."""

from pathlib import Path
import sys
from typing import Callable, Optional
from fnmatch import fnmatch
from pydantic import BaseModel
from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer
import os

SOURCE_EXTENSIONS = {
    "PYTHON_EXTENSIONS": [".py"],
    "C_EXTENSIONS": [".c", ".h", ".cpp", ".hpp", ".cc", ".hh", ".cxx", ".hxx"],
    "JAVA_EXTENSIONS": [".java"],
    "JAVASCRIPT_EXTENSIONS": [".js", ".jsx", ".ts", ".tsx"],
    "RUBY_EXTENSIONS": [".rb"],
    "GO_EXTENSIONS": [".go"],
    "PHP_EXTENSIONS": [".php", ".phtml"],
    "RUST_EXTENSIONS": [".rs"],
    "HASKELL_EXTENSIONS": [".hs", ".lhs"],
    "PERL_EXTENSIONS": [".pl", ".pm"],
    "SHELL_EXTENSIONS": [".sh", ".bash", ".zsh", ".ksh"],
    "R_EXTENSIONS": [".r", ".R", ".rmd"],
    "JULIA_EXTENSIONS": [".jl"],
    "WEB_DEV_EXTENSIONS": [".html", ".css", ".js"],
}

SOURCE_FILE_EXTENSIONS = [ext for exts in SOURCE_EXTENSIONS.values() for ext in exts]

class WatchConfiguration(BaseModel):
    """Configuration defining list of files to watch"""
    directory: Path
    watched_extensions: list[str]
    ignored_patterns: list[str] = []

    def model_post_init(self, context) -> None:
        """Ensure directory is resolved to absolute path after initialization."""
        self.directory = self.directory.resolve()
    
    def is_watching(self, filepath: Path) -> bool:
        """Check if a given filepath should be watched based on patterns."""
        absolute_path = filepath.resolve()
        # Ignore directories
        if absolute_path.is_dir():
            return False

        # Check if this file is a descendant of the directory
        if not absolute_path.is_relative_to(self.directory):
            return False

        # Check ignored patterns first using Unix shell-style wildcards
        for pattern in self.ignored_patterns:
            full_pattern = str(self.directory / pattern)
            if fnmatch(str(absolute_path), full_pattern) or fnmatch(absolute_path.name, pattern):
                return False
            
        return absolute_path.suffix in self.watched_extensions
    
    def collect_watched_files(self) -> list[Path]:
        """Collect all files in the directory that should be watched."""
        # using rglob was inefficient for large directories
        # return [f for f in self.directory.rglob('*') if self.is_watching(f)]
        # Do a manual walk to allow pruning ignored directories
        watched_files: list[Path] = []
        for root, dirs, files in os.walk(self.directory):
            root_path = Path(root)

            # Prune ignored directories in-place to skip them completely
            pruned_dirs: list[str] = []
            for dir_name in dirs:
                dir_path = root_path / dir_name
                ignore_dir = False
                for pattern in self.ignored_patterns:
                    full_pattern = str(self.directory / pattern)
                    dir_path_str = str(dir_path).rstrip(os.sep) + os.sep  # Ensure directories end with separator for matching
                    # if fnmatch(str(dir_path), full_pattern) or fnmatch(dir_name, pattern):
                    if fnmatch(dir_path_str, full_pattern):
                        ignore_dir = True
                        break
                if not ignore_dir:
                    pruned_dirs.append(dir_name)
            dirs[:] = pruned_dirs

            for file_name in files:
                file_path = root_path / file_name
                if self.is_watching(file_path):
                    watched_files.append(file_path)

        return watched_files
    
class Watcher():
    """Configure what the watcher pays attention to for a given project."""
    def __init__(self, configurations: list[WatchConfiguration], on_change: Callable[[Path, str, Optional[str]], None]):
        """
        Create a Watcher instance with the given configurations defining which files to watch,
        and a callback function defining what should happen when those files are modified.
        
        :param configurations: List of WatchConfiguration objects defining which files to watch
        :type configurations: list[WatchConfiguration]
        :param on_change: Callback procedure applied to the file path, contents, and previous contents (if any) when that watched file is modified
        :type on_change: Callable[[Path, str, Optional[str]], None]
        """
        self.configurations = configurations
        self.on_change_callback = on_change
        # Dictionary to store previous contents of each file
        self.previous_contents: dict[Path, str] = {}

    def collect_watched_files(self) -> list[Path]:
        """Collect all files across configurations that should be watched."""
        return list({f for c in self.configurations for f in c.collect_watched_files()})

    def should_ignore_path(self, path: Path) -> bool:
        """Determine if a file should be ignored based on the configurations."""
        for config in self.configurations:
            if config.is_watching(path):
                return False
        return True
    
    def _read_file(self, filepath: Path) -> str:
      try:
          return filepath.read_text(encoding='utf-8', errors='replace')
      except FileNotFoundError as e:
          return ""
      except Exception as e:
          print(f"✗ Error reading file {filepath}: {e}", file=sys.stderr)
          return ""
    
    def _mk_event_handler(self, configuration: WatchConfiguration):
      watcher = self
      class Handler(FileSystemEventHandler):
        """Here we define the event handler passed to the watchdog observer"""
        def on_modified(self, event):
            if not configuration.is_watching(Path(event.src_path)):
                return
            abs_path = Path(event.src_path).resolve()
            content = watcher._read_file(abs_path)
            prev_content = watcher.previous_contents.get(abs_path)
            if content != prev_content:
                watcher.previous_contents[abs_path] = content
                watcher.on_change_callback(abs_path, content, prev_content)
      return Handler()

    def start(self):
        self.observer = Observer()
        for config in self.configurations:
            event_handler = self._mk_event_handler(config)
            self.observer.schedule(event_handler, str(config.directory), recursive=True)
        self.observer.start()

    def stop(self):
        self.observer.stop()

    def join(self):
        self.observer.join()