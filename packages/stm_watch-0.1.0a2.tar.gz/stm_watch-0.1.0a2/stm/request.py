"""HTTP request helpers for the watch CLI."""

from typing import Optional, Tuple
import sys
import time
import uuid
import requests
import requests.cookies
from shared.schemas import (
	AuthStatus,
	AuthStatusRequest,
	AuthStatusResponse,
	FileModification,
	LoginRequest,
	LoginResponse,
	PasswordChangeRequest,
	RegisterRequest,
	RegisterResponse,
)
from stm import config

def create_session_with_cookies(
	session_data: config.SessionData,
) -> requests.Session:
	"""Create a requests session with cached cookies pre-loaded."""
	session = requests.Session()
	session.cookies = config.session_cookiejar(session_data)
	return session

def load_cached_session() -> Optional[requests.Session]:
	"""Load cached session and return a requests session with cookies."""
	session_data = config.load_session()
	if session_data is None:
		return None
	return create_session_with_cookies(session_data)

def wait_for_auth(
	server_url: str,
	request_id: str,
	timeout: int = 300,
) -> Tuple[requests.cookies.RequestsCookieJar, str] | None:
	"""Poll server for authenticated session cookie and username."""
	session = requests.Session()
	start = time.time()
	while time.time() - start < timeout:
		response = session.get(
			f"{server_url}/api/auth/status",
			json=AuthStatusRequest(id=request_id).model_dump(),
			timeout=5,
		)
		response.raise_for_status()
		data = AuthStatusResponse.model_validate(response.json())
		if data.status == AuthStatus.AUTHORIZED:
			if not any(c.name == config.SESSION_COOKIE_NAME for c in session.cookies):
				raise RuntimeError("Missing session cookie in response")
			return session.cookies, (data.username or "")
		if data.status == AuthStatus.UNAUTHORIZED:
			return None
		time.sleep(3)
	raise TimeoutError("Authentication timed out")

def browser_auth(server_url: str) -> Tuple[requests.cookies.RequestsCookieJar, str]:
	"""Open browser for user authentication and return session cookie and netid."""
	request_id = str(uuid.uuid4())
	login_url = f"{server_url}/login?id={request_id}"
	print(f"Please sign in: {login_url}")

	cookies_and_name = wait_for_auth(server_url, request_id)
	if not cookies_and_name:
		print("Authentication failed or was unauthorized.")
		sys.exit(1)
	print("✓ Authentication successful for user:", cookies_and_name[1])
	return cookies_and_name

# TODO move error reporting to caller, return type should indicate failure instead of exiting
def login(
	server_url: str,
	in_browser: bool = False,
	email: Optional[str] = None,
	password: Optional[str] = None,
) -> requests.cookies.RequestsCookieJar:
	"""Login to server and return session cookies."""
	try:
		if not in_browser:
			if not email or not password:
				raise ValueError("Email and password are required for direct login")
			session = requests.Session()
			response = session.post(
				f"{server_url}/api/login",
				json=LoginRequest(email=email, password=password).model_dump(),
				timeout=5,
			)
			response.raise_for_status()
			data = LoginResponse.model_validate(response.json())
			if data.verified:
				if not any(c.name == config.SESSION_COOKIE_NAME for c in session.cookies):
					print("✗ Login failed: No session cookie received")
					sys.exit(1)
				config.save_session(session.cookies, email, server_url)
				return session.cookies
			print("✗ Login failed: Unauthorized")
			sys.exit(1)
			
    # If in-browser login, delegate to browser_auth which handles polling for auth status
		cookies, netid = browser_auth(server_url)
		config.save_session(cookies, netid, server_url)
		return cookies
	except requests.exceptions.RequestException as e:
		print(f"✗ Login failed: {e}")
		sys.exit(1)

def logout(server_url: str, session_cookies: requests.cookies.RequestsCookieJar) -> requests.Response:
	"""End session on server."""
	response = requests.post(
		f"{server_url}/api/logout",
		cookies=session_cookies,
		timeout=5,
	)
	response.raise_for_status()
	return response

def submit(
	modification: FileModification,
	server_url: str,
	session_cookies: requests.cookies.RequestsCookieJar,
) -> bool:
	"""Submit file content to server."""
	try:
		response = requests.post(
			f"{server_url.rstrip('/')}/api/event",
			json=modification.model_dump(),
			cookies=session_cookies,
			timeout=5,
		)
		response.raise_for_status()
		print(f"  ✓ Submitted: {modification.filename}")
		print(response.json())
		return True
	except requests.exceptions.RequestException as e:
		print(f"  ✗ Submission failed: {e}")
		return False

def change_password(
	server_url: str,
	email: str,
	old_password: str,
	new_password: str,
) -> bool:
	"""Submit a password change request."""
	try:
		response = requests.post(
			f"{server_url.rstrip('/')}/api/password/change",
			json=PasswordChangeRequest(
				email=email,
				old_password=old_password,
				new_password=new_password,
			).model_dump(),
			timeout=5,
		)
		if response.status_code == 204:
			print("Your password has been changed. Please log in again with your new password.")
			return True
		if response.status_code == 401:
			print("Password change failed. Email or old password are incorrect.")
			return False
		response.raise_for_status()
		print(f"UNEXPECTED FAILURE: {response.status_code}")
		return False
	except requests.exceptions.RequestException as e:
		print(f"Password change failed: {e.response.text if e.response else str(e)}")
		return False

def register(
	server_url: str,
	firstname: str,
	lastname: str,
	email: str,
	password: str,
	city: Optional[str] = None,
	state: Optional[str] = None,
	organization: Optional[str] = None,
) -> bool:
	"""Submit a registration request to the server."""
	try:
		response = requests.post(
			f"{server_url.rstrip('/')}/register",
			json=RegisterRequest(
				firstname=firstname,
				lastname=lastname,
				email=email,
				password=password,
				city=city,
				state=state,
				organization=organization,
			).model_dump(),
			timeout=5,
		)
	except requests.exceptions.RequestException as e:
		print(f"✗ Registration failed: {e}")
		return False
	
	if response.status_code == 200:
		print(f"✓ Registration submitted for {email}. Await admin approval.")
		return True
	
	try:
		err_msg = response.json().get("detail", "Unknown error")
	except Exception:
		err_msg = response.text
	print(f"✗ Registration failed: {err_msg}")
	return False
