"""Configuration and cookie caching for the watch CLI."""
from pathlib import Path
import json
from typing import Optional
from importlib.metadata import PackageNotFoundError, version
from datetime import datetime, timezone
import requests
import requests.cookies
import platformdirs
from pydantic import BaseModel
from stm.watcher import WatchConfiguration

SESSION_COOKIE_NAME = "session"

class SessionCookie(BaseModel):
    name: str
    value: str
    domain: Optional[str] = None
    path: str = "/"
    secure: bool = False
    expires: Optional[int] = None

class SessionData(BaseModel):
    cookies: list[SessionCookie] = []
    username: str
    server_url: str
    created_at: datetime
    session_token: Optional[str] = None

def get_version() -> str:
    """Get the current version of the CLI."""
    try:
        return version("stm-watch")
    except PackageNotFoundError:
        return "0.0.0"

def get_config_dir() -> Path:
    """Get the user's config directory for storing session tokens."""
    config_home = platformdirs.user_config_path(
        "stm", appauthor="stop the madness", ensure_exists=True, 
        )
    return config_home

def get_log_dir() -> Path:
    """"Get the user's log directory for storing logs"""
    log_home = platformdirs.user_log_path(
        "stm", appauthor="stop the madness", ensure_exists=True
    )
    return log_home

def get_session_file() -> Path:
    """Get the path to the session file."""
    return get_config_dir() / "session.json"

def get_watchers_file() -> Path:
    """Get the path to the watchers file."""
    return get_config_dir() / "watchers.json"

def load_watch_configurations() -> list[WatchConfiguration]:
    """Load the projects configuration from file."""
    watchers_file = get_watchers_file()

    if not watchers_file.exists():
        return []

    try:
        raw_data = json.loads(watchers_file.read_text())
        if not isinstance(raw_data, list):
            raise ValueError("Watchers file must contain a list")
        return [WatchConfiguration(**watcher_settings) for watcher_settings in raw_data]
    except (ValueError, TypeError) as e:
        print(f"⚠ Corrupted watchers file, removing: {e}")
        watchers_file.unlink(missing_ok=True)
        return []

def save_watch_configurations(watchers: list[WatchConfiguration]) -> None:
    """Save the list of watchers to the watchers file."""
    watchers_file = get_watchers_file()
    watchers_file.write_text(json.dumps([w.model_dump(mode='json') for w in watchers], indent=2))

def add_configuration(settings: WatchConfiguration) -> None:
    """Add a new watcher to the watchers file."""
    watchers = load_watch_configurations()
    settings.directory = settings.directory.resolve()

    updated_configurations: list[WatchConfiguration] = []
    replaced = False
    for watcher in watchers:
        # if the directory is already being watched, replace its settings
        if watcher.directory == settings.directory:
            updated_configurations.append(settings)
            replaced = True
        else:
            updated_configurations.append(watcher)

    if not replaced:
        updated_configurations.append(settings)

    save_watch_configurations(updated_configurations)

def delete_configuration(directory: Path) -> None:
    """Delete a watcher configuration from the watchers file."""
    configurations = load_watch_configurations()
    target_dir = directory.resolve()
    remaining = [w for w in configurations if w.directory.resolve() != target_dir]

    watchers_file = get_watchers_file()
    if not remaining:
        watchers_file.unlink(missing_ok=True)
        return

    save_watch_configurations(remaining)

def _serialize_cookies(cookiejar: requests.cookies.RequestsCookieJar) -> list[SessionCookie]:
    """Convert a cookie jar to a JSON-serializable list."""
    return [
        SessionCookie(
            name=c.name,
            value=c.value or "",
            domain=c.domain,
            path=c.path or "/",
            secure=bool(c.secure),
            expires=c.expires,
        )
        for c in cookiejar
    ]

def _deserialize_cookies(cookies: list[SessionCookie]) -> requests.cookies.RequestsCookieJar:
    """Rebuild a cookie jar from serialized cookie data."""
    jar = requests.cookies.RequestsCookieJar()
    for cookie in cookies:
        jar.set_cookie(
            requests.cookies.create_cookie(
                name=cookie.name,
                value=cookie.value,
                domain=cookie.domain,
                path=cookie.path,
                secure=cookie.secure,
                expires=cookie.expires,
            )
        )
    return jar

def session_cookiejar(session_data: SessionData) -> requests.cookies.RequestsCookieJar:
    """Get a requests cookie jar for the stored session."""
    return _deserialize_cookies(session_data.cookies)

# def _cookie_from_token(session_token: str, server_url: str) -> SessionCookie:
#     """Create a session cookie from a legacy token and server URL."""
#     parsed = urlparse(server_url)
#     domain = parsed.hostname
#     return SessionCookie(
#         name=SESSION_COOKIE_NAME,
#         value=session_token,
#         domain=domain,
#         path="/",
#         secure=parsed.scheme == "https",
#     )

def save_session(cookies: requests.cookies.RequestsCookieJar, username: str, server_url: str) -> None:
    """Save session cookies to local config file."""
    session_file = get_session_file()
    session_data = {
        "cookies": [c.model_dump() for c in _serialize_cookies(cookies)],
        "username": username,
        "server_url": server_url,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    
    # Set restrictive permissions (user read/write only)
    session_file.touch(mode=0o600, exist_ok=True)
    session_file.write_text(json.dumps(session_data, indent=2))

def load_session() -> Optional[SessionData]:
    """Load cached session from local config file."""
    session_file = get_session_file()
    
    if not session_file.exists():
        return None
    
    try:
        session_data = SessionData.model_validate_json(session_file.read_text())
        return session_data
    except (json.JSONDecodeError, KeyError) as e:
        # Corrupted session file, remove it
        print(f"⚠ Corrupted session file, removing: {e}")
        session_file.unlink(missing_ok=True)
        return None

def clear_session() -> None:
    """Remove cached session from local config file."""
    session_file = get_session_file()
    session_file.unlink(missing_ok=True)

def clear_watchers() -> None:
    """Remove all watchers from local config file."""
    watchers_file = get_watchers_file()
    watchers_file.unlink(missing_ok=True)

def refresh_session() -> Optional[SessionData]:
    """Validate session cookie with server."""
    session_data = load_session()
    if session_data is None:
        # No session data to refresh, user needs to login
        return None
    try:
        session = requests.Session()
        session.cookies = _deserialize_cookies(session_data.cookies)
        response = session.post(
            f"{session_data.server_url.rstrip('/')}/api/auth/refresh",
            timeout=5,
        )
        if response.status_code == 204:
            if not session.cookies:
                return None
            save_session(session.cookies, session_data.username, session_data.server_url)
            return load_session()
        return None
    except requests.exceptions.RequestException:
        return None
    except (json.JSONDecodeError, KeyError) as e:
        # Corrupted session file, remove it
        print(f"⚠ Something went wrong validating session: {e}")
        session_file = get_session_file()
        session_file.unlink(missing_ok=True)
        return None
