"""Skeleton and helper functions for creating EPICS PVAccess server"""
# pylint: disable=invalid-name
__version__= 'v3.0.1 26-02-24'# Major upgrade. Added standard EPICS iocStats PV,
# SPV removed, PvDefs definitions simplified, new features added.
#TODO: add support for autoSave, (feature 'A'), caputLog (feature 'H') and access rights

import sys
import time
from time import perf_counter as timer
import os
import threading
from socket import gethostname
import psutil
from p4p.nt import NTScalar, NTEnum
from p4p.nt.enum import ntenum
from p4p.server import Server
from p4p.server.thread import SharedPV
from p4p.client.thread import Context
from p4p.nt import Type

PeriodicUpdateInterval = 10. # seconds

#``````````````````Module Storage`````````````````````````````````````````````
def _serverStateChanged(newState:str):
    """Dummy serverStateChanged function"""
    return

class C_():
    """Storage for module members"""
    prefix = ''
    verbose = 0
    startTime = 0.
    cycle = 0
    serverState = ''
    PVs = {}
    PVDefs = [] 
    serverStateChanged = _serverStateChanged
    lastCycleTime = timer()
    lastUpdateTime = 0.
    cycleTimeSum = 0.
    cyclesAfterUpdate = 0
#``````````````````Constants
dtype2p4p = {# mapping from numpy dtype to p4p type code
's8':'b', 'u8':'B', 's16':'h', 'u16':'H', 'i32':'i', 'u32':'I', 'i64':'l',
'u64':'L', 'f32':'f', 'f64':'d', str:'s',
}

#```````````````````Helper methods````````````````````````````````````````````
def serverState():
    """Return current server state. That is the value of the server PV, but
    cached in C_ to avoid unnecessary get() calls."""
    return C_.serverState
def _printTime():
    return time.strftime("%m%d:%H%M%S")
def printi(msg):
    """Print info message and publish it to status PV."""
    print(f'inf_@{_printTime()}: {msg}')
def printw(msg):
    """Print warning message and publish it to status PV."""
    txt = f'WAR_@{_printTime()}: {msg}'
    print(txt)
    publish('status',txt)
def printe(msg):
    """Print error message and publish it to status PV."""
    txt = f'ERR_{_printTime()}: {msg}'
    print(txt)
    publish('status',txt)
def _printv(msg, level):
    if C_.verbose >= level: 
        print(f'DBG{level}: {msg}')
def printv(msg):
    """Print debug message if verbosity level >=1."""
    _printv(msg, 1)
def printvv(msg):
    """Print debug message if verbosity level >=2."""
    _printv(msg, 2)
def printv3(msg):
    """Print debug message if verbosity level >=3."""
    _printv(msg, 3)

def pvobj(pvName):
    """Return PV with given name"""
    return C_.PVs[C_.prefix+pvName]

def pvv(pvName:str):
    """Return PV value"""
    return pvobj(pvName).current()

def publish(pvName:str, value, ifChanged=False, t=None):
    """Publish value to PV. If ifChanged is True, then publish only if the 
    value is different from the current value. If t is not None, then use
    it as timestamp, otherwise use current time."""
    #print(f'Publishing {pvName}')
    try:
        pv = pvobj(pvName)
    except KeyError:
        print(f'WARNING: PV {pvName} not found. Cannot publish value.')
        return
    if t is None:
        t = time.time()
    if not ifChanged or pv.current() != value:
        pv.post(value, timestamp=t)

#``````````````````create_PVs()```````````````````````````````````````````````
def _create_PVs(pvDefs):
    """Create PVs from the definitions in pvDefs and add them to the map of PVs."""

    ts = time.time()
    for defs in pvDefs:
        try:
            pname,desc,initial,*extra = defs
        except ValueError:
            printe(f'Invalid PV definition of {defs[0]}')
            sys.exit(1)
        extra = extra[0] if extra else {}

        # Determine PV type and create SharedPV
        iterable  = type(initial) not in (int,float,str)
        vtype = extra.get('type')
        if vtype is None:
            firstItem = initial[0] if iterable else initial
            itype = type(firstItem)
            vtype = {int: 'i32', float: 'f32'}.get(itype,itype)
        tcode = dtype2p4p[vtype]
        allowed_chars = 'WRAD'
        meta = extra.get('features','')
        writable = 'W' in meta
        valueAlarm = extra.get('valueAlarm')
        ntextra = [('features', Type([('writable', '?')]))]
        for ch in meta:
            if ch not in allowed_chars:
                printe(f'Unknown meta character {ch} in SPV definition')
                sys.exit(1)
        if 'D' in meta:
            initial = {'choices': initial, 'index': 0}
            nt = NTEnum(display=True, extra=ntextra)
        else:
            prefix = 'a' if iterable else ''
            nt = NTScalar(prefix+tcode, display=True, control=writable,
                        valueAlarm = valueAlarm is not None, extra=ntextra)
        spv = SharedPV(nt=nt, initial=initial)

        # Set initial value and description and add to the map of PVs
        ivalue = spv.current()
        printv((f'created pv {pname}, initial: {type(ivalue),ivalue},'
               f'extra: {extra}'))
        key = C_.prefix + pname
        if key in C_.PVs:
            printe(f'Duplicate PV name: {pname}')
            sys.exit(1)
        C_.PVs[C_.prefix+pname] = spv
        v = spv._wrap(ivalue, timestamp=ts)
        v['features.writable'] = writable
        v['display.description'] = desc

        # set extra parameters
        for field in extra.keys():
            try:
                if field in ['limitLow','limitHigh','format','units']:
                    v[f'display.{field}'] = extra[field]
                    if field.startswith('limit'):
                        v[f'control.{field}'] = extra[field]
                if field == 'valueAlarm':
                    for key,value in extra[field].items():
                        v[f'valueAlarm.{key}'] = value
            except  KeyError as e:
                print(f'Cannot set {field} for {pname}: {e}')
                sys.exit(1)
        spv.post(v)

        if writable:
            # add new attributes, that will be used in the put handler
            spv.name = pname
            spv.setter = extra.get('setter')

            # add put handler
            @spv.put
            def handle(spv, op):
                ct = time.time()
                vv = op.value()
                vr = vv.raw.value
                current = spv._wrap(spv.current())
                # check limits, if they are defined. That will be a good
                # example of using control structure and valueAlarm.
                try:
                    limitLow = current['control.limitLow']
                    limitHigh = current['control.limitHigh']
                    if limitLow != limitHigh and not (limitLow <= vr <= limitHigh):
                        printw(f'Value {vr} is out of limits [{limitLow}, {limitHigh}]. Ignoring.')
                        op.done(error=f'Value out of limits [{limitLow}, {limitHigh}]')
                        return
                except KeyError:
                    pass
                if isinstance(vv, ntenum):
                    vr = str(vv)
                if spv.setter:
                    spv.setter(vr, spv)
                    # value will be updated by the setter, so get it again
                    vr = pvv(spv.name)
                printv(f'putting {spv.name} = {vr}')
                spv.post(vr, timestamp=ct) # update subscribers
                op.done()
#,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
#``````````````````Setters
def set_verbose(level, *_):
    """Set verbosity level for debugging"""
    C_.verbose = level
    printi(f'Setting verbose to {level}')
    publish('verbose',level)

def set_server(servState, *_):
    """Example of the setter for the server PV.
    servState can be 'Start', 'Stop', 'Exit' or 'Clear'. If servState is None,
    then get the desired state from the server PV."""
    #printv(f'>set_server({servState}), {type(servState)}')
    if servState is None:
        servState = pvv('server')
        printi(f'Setting server state to {servState}')
    servState = str(servState)
    C_.serverStateChanged(servState)
    if servState == 'Start':
        printi('Starting the server')
        publish('server','Started')
        publish('status','Started')
    elif servState == 'Stop':
        printi('server stopped')
        publish('server','Stopped')
        publish('status','Stopped')
    elif servState == 'Exit':
        printi('server is exiting')
        publish('server','Exited')
        publish('status','Exited')
    elif servState == 'Clear':
        publish('status','Cleared')
        # set server to previous servState
        set_server(C_.serverState)
        return
    C_.serverState = servState

def create_PVs(pvDefs=None):
    """Create PVs from the definitions in C_.PVDefs and return the map of PVs.
     pvDefs is a list of PV definitions, that will be appended to C_.PVDefs.
     Each PV definition is a list of 3 or 4 items:
        [pvName:str, description:str, initialValue, extra:dict]
     The extra dict is optional and can have the following keys:
        features: string with characters W (writable),
            D (discrete). For example. By default, PV is read-only scalar.
        type: string with data type, for example 'f32', 'i32', 's8', etc. By default,
            the type is determined from the initial value (float -> 'f32', int -> 'i32').
        units: string with physical units, for example 'V', 'S', 'Mpts/s', etc.
        limitLow: number with low limit for the value. If defined, then the put
            handler will check that the value is not below the low limit.
        limitHigh: number with high limit for the value. If defined, then the put
            handler will check that the value is not above the high limit.
        setter: function to be called when the PV value is changed. The function
            should have the signature:
                def setter(value, spv):
            where value is the new value, and spv is the SharedPV object.
    The PVs defined in C_.PVDefs are created first, then the PVs from pvDefs are
    created and appended to the map of PVs. That allows to have some common PVs 
    defined in C_.PVDefs, and device-specific PVs defined in pvDefs.
    The function returns the map of PVs, where the keys are PV names with prefix,
    and the values are SharedPV objects."""

    F,T,U,LL,LH = 'features','type','units','limitLow','limitHigh'
    C_.PVDefs = [
# iocStats-related PVs
['HOSTNAME',    'Server host name',  gethostname()],
['VERSION',     'Program version',  'epicsdev '+__version__],
['HEARTBEAT',   'Server heartbeat, Increments once per second', 0., {U:'S'}],
['UPTIME',      'Server uptime in seconds', '', {U:'S'}],
['STARTTOD',    'Server start time', time.strftime("%m/%d/%Y %H:%M:%S")],
['CPU_LOAD',    'CPU load in %', 0., {U:'%'}],
['CA_CONN_COUNT', 'Number of TCP connections', 0],
# Other popular stats: CA_CLIENTS, CA_CONN_COUNT, CPU_LOAD, FD_USED, THREAD_COUNT

['status',  'Server status. Features: RWE', '', {F:'W'}],
['server',  'Server control. Features: RWE',
    'Start Stop Clear Exit Started Stopped Exited'.split(),
    {F:'WD', 'setter':set_server}],
['verbose', 'Debugging verbosity',
    C_.verbose, {F:'W', T:'u8', 'setter':set_verbose, LL:0,LH:3}],
['sleep', 'Pause in the main loop, it could be useful for throttling the data output',
    1.0, {F:'W', T:'f32', U:'S', LL:0.001, LH:10.1}],
['cycle',   'Cycle number, published every {PeriodicUpdateInterval} S.',
    0, {T:'u32'}],
['cycleTime','Average cycle time including sleep, published every {PeriodicUpdateInterval} S',
    0., {U:'S'}],
    ]
    # append application's PVs, defined in the pvDefs and create map of
    #  providers
    if pvDefs is not None:
        C_.PVDefs += pvDefs
    _create_PVs(C_.PVDefs)
    return C_.PVs

def get_externalPV(pvName:str, timeout=0.5):
    """Get value of PV from another server. That can be used to check if the
    server is already running, or to get values from other servers."""
    ctxt = Context('pva')
    return ctxt.get(pvName, timeout=timeout)

def init_epicsdev(prefix:str, pvDefs:list, verbose=0,
                serverStateChanged=None, listDir=None):
    """Check if no other server is running with the same prefix.
    Create PVs and return them as a dictionary.
    prefix is a string to be prepended to all PV names.
    pvDefs is a list of PV definitions (see create_PVs()).
    verbose is the verbosity level for debug messages.
    serverStateChanged is a function to be called when the server PV changes.
    The function should have the signature:
        def serverStateChanged(newStatus:str):
    If serverStateChanged is None, then a dummy function is used.
    The listDir is a directory to save list of all generated PVs,
    if no directory is given, then </tmp/pvlist/><prefix> is assumed.
    """
    if not isinstance(verbose, int) or verbose < 0:
        printe('init_epicsdev arguments should be (prefix:str, pvDefs:list, verbose:int, listDir:str)')
        sys.exit(1)
    printi(f'Initializing epicsdev with prefix {prefix}')
    C_.prefix = prefix
    C_.verbose = verbose
    if serverStateChanged is not None:# set custom serverStateChanged function
        C_.serverStateChanged = serverStateChanged
    try: # check if server is already running
        host = repr(get_externalPV(prefix+'HOSTNAME')).replace("'",'')
        print(f'ERROR: Server for {prefix} already running at {host}. Exiting.')
        sys.exit(1)
    except TimeoutError:
        pass

    # No existing server found. Creating PVs.
    pvs = create_PVs(pvDefs)
    # Save list of PVs to a file, if requested
    if listDir != '':
        listDir = '/tmp/pvlist/' if listDir is None else listDir
        if not os.path.exists(listDir):
            os.makedirs(listDir)
        filepath = f'{listDir}{prefix[:-1]}.txt'
        print(f'Writing list of PVs to {filepath}')
        with open(filepath, 'w', encoding="utf-8") as f:
            for _pvname in pvs:
                f.write(_pvname + '\n')
    printi(f'Hosting {len(pvs)} PVs')
    C_.startTime = time.time()
    threading.Thread(target=_heartbeat_thread, daemon=True).start()
    return pvs

def _heartbeat_thread():
    """Thread to update heartbeat and uptime PVs."""
    while True:
        time.sleep(1)
        publish('HEARTBEAT', pvv('HEARTBEAT')+1)
        publish('UPTIME', round(time.time() - C_.startTime, 1))

def sleep():
    """Sleep function to be called in the main loop. It updates cycleTime PV
    and sleeps for the time specified in sleep PV.
    Returns False if a periodic update occurred.
    """
    time.sleep(pvv('sleep'))
    sleeping = True
    if serverState().startswith('Stop'):
        return sleeping
    tnow = timer()
    C_.cycleTimeSum += tnow - C_.lastCycleTime
    C_.lastCycleTime = tnow
    C_.cyclesAfterUpdate += 1
    C_.cycle += 1
    printv(f'cycle {C_.cycle}')
    if tnow - C_.lastUpdateTime > PeriodicUpdateInterval:
        avgCycleTime = C_.cycleTimeSum / C_.cyclesAfterUpdate
        printv(f'Average cycle time: {avgCycleTime:.6f} S.')
        publish('cycle', C_.cycle)
        publish('cycleTime', avgCycleTime)
        publish('CPU_LOAD', round(psutil.cpu_percent(),1))
        publish('CA_CONN_COUNT', len(psutil.net_connections(kind='tcp')))
        C_.lastUpdateTime = tnow
        C_.cycleTimeSum = 0.
        C_.cyclesAfterUpdate = 0
        sleeping = False
    return sleeping

#``````````````````Demo````````````````````````````````````````````````````````
if __name__ == "__main__":
    import numpy as np
    import argparse

    def myPVDefs():
        """Example of PV definitions"""
        F,T,U,LL,LH,SET = 'features','type','units','limitLow','limitHigh','setter'
        alarm = {'valueAlarm':{'lowAlarmLimit':-9., 'highAlarmLimit':9.}}
        return [    # device-specific PVs
['noiseLevel',  'Noise amplitude',  1., {F:'W', U:'V'}],
['tAxis',       'Full scale of horizontal axis', [0.], {U:'S'}],
['recordLength','Max number of points',
    100, {F:'W', T:'u32', LL:4,LH:1000000, SET:set_recordLength}],
['throughput', 'Performance metrics, points per second', 0., {U:'Mpts/s'}],
['c01Offset',   'Offset',                   0., {F:'W', U:'du'}],
['c01VoltsPerDiv',  'Vertical scale',       0.1, {F:'W', U:'V/du'}],
['c01Waveform', 'Waveform array',           [0.], {U:'du'}],
['c01Mean',     'Mean of the waveform',     0., {U:'du'}],
['c01Peak2Peak','Peak-to-peak amplitude',   0., {U:'du', **alarm}],
['alarm',       'PV with alarm',            0, {U:'du', **alarm}],
        ]
    pargs = None
    rng = np.random.default_rng()
    nPoints = 100
    _sum = {'points': 0, 'time': 0.}

    def set_recordLength(value, *_):
        """Record length have changed. The tAxis should be updated
        accordingly."""
        printi(f'Setting tAxis to {value}')
        publish('tAxis', np.arange(value)*1.E-6)
        publish('recordLength', value)

    def init(recordLength):
        """Example of device initialization function"""
        set_recordLength(recordLength)
        #set_noise(pvv('noiseLevel')) # already called from set_recordLength

    def poll():
        """Example of polling function. Called every cycle when server is running.
            It returns time, spent in publishing data"""
        wf = rng.random(pvv('recordLength'))*pvv('noiseLevel')# it takes 5ms for 1M points
        wf /= pvv('c01VoltsPerDiv')
        wf += pvv('c01Offset')
        ts = timer()        
        publish('c01Waveform', wf)
        _sum['time'] += timer() - ts
        _sum['points'] += len(wf)
        publish('c01Peak2Peak', np.ptp(wf))
        publish('c01Mean', np.mean(wf))

    def periodic_update():
        """Perform periodic update"""
        #printi(f'periodic update for {C_.cyclesSinceUpdate} cycles: {ElapsedTime}')
        if state.startswith('Stop'):
            publish('throughput', 0.)
        else:
            pointsPerSecond = _sum['points']/_sum['time']/1.E6
            publish('throughput', round(pointsPerSecond,6))
            printv(f'periodic update. Performance: {pointsPerSecond:.3g} Mpts/s')
            _sum['points'] = 0
            _sum['time'] = 0.

    # Argument parsing
    parser = argparse.ArgumentParser(description = __doc__,
    formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    epilog=f'{__version__}')
    parser.add_argument('-d', '--device', default='epicsDev', help=
'Device name, the PV name will be <device><index>:')
    parser.add_argument('-i', '--index', default='0', help=
'Device index, the PV name will be <device><index>:') 
    parser.add_argument('-l', '--list', nargs='?', help=(
'Directory to save list of all generated PVs, if no directory is given, '
'then </tmp/pvlist/><prefix> is assumed.'))
    # The rest of options are not essential, they can be controlled at runtime using PVs.
    parser.add_argument('-n', '--npoints', type=int, default=nPoints, help=
'Number of points in the waveform')
    parser.add_argument('-v', '--verbose', action='count', default=0, help=
'Show more log messages (-vv: show even more)') 
    pargs = parser.parse_args()
    print(pargs)

    # Initialize epicsdev and PVs
    pargs.prefix = f'{pargs.device}{pargs.index}:'
    PVs = init_epicsdev(pargs.prefix, myPVDefs(), pargs.verbose, None, pargs.list)

    # Initialize the device using pargs if needed.
    init(pargs.npoints)

    # Start the Server. Use your set_server, if needed.
    set_server('Start')

    # Main loop
    # In this example, we just update the waveform and its stats in a loop,
    # but in a real application, the loop can also read data from the device,
    # and update PVs accordingly. The loop can be paused by setting server PV to 'Stop',
    # and exited by setting server PV to 'Exit'. 
    # The performance metrics are updated every {PeriodicUpdateInterval} seconds.
    server = Server(providers=[PVs])
    printi(f'Server started. Sleeping per cycle: {repr(pvv("sleep"))} S.')
    while True:
        state = serverState()
        if state.startswith('Exit'):
            break
        if not state.startswith('Stop'):
            poll()
        if not sleep():# Sleep and update performance metrics periodically
            periodic_update()
    printi('Server is exited')
