# Copilot instructions for epicsdev

## Big picture
- Core EPICS PVAccess helpers live in [epicsdev/epicsdev.py](epicsdev/epicsdev.py). Module state is held in `C_` (prefix, PV map, verbosity, server state), and public helpers include `SPV()`, `publish()`, `pvv()`, `serverState()`, `sleep()`.
- Startup flow: `init_epicsdev(prefix, pvDefs, verbose=0, serverStateChanged=None, listDir=None)` checks for an existing server (via `host` PV), creates PVs, and optionally writes a PV list under `/tmp/pvlist/<prefix>.txt`. Then `Server(providers=[PVs])` runs a polling loop that checks `serverState()`; see [epicsdev/epicsdev.py](epicsdev/epicsdev.py) and the concrete device in [epicsdev/multiadc.py](epicsdev/multiadc.py).
- `create_PVs()` always prepends mandatory PVs (`host`, `version`, `status`, `server`, `verbose`, `sleep`, `cycle`, `cycleTime`) before app PVs; `sleep()` updates `cycle`/`cycleTime` every `PeriodicUpdateInterval` and uses the `sleep` PV as throttle.
- GUI pages for pypeto are defined in [config/epicsdev_pp.py](config/epicsdev_pp.py), [config/multiadc_pp.py](config/multiadc_pp.py), and [config/epicsSimscope_pp.py](config/epicsSimscope_pp.py); their PV names/prefixes must match the servers.

## Project-specific patterns & conventions
- PV definitions are `[name, description, SPV, extra]` and passed to `create_PVs()`; examples: `myPVDefs()` in [epicsdev/epicsdev.py](epicsdev/epicsdev.py) and [epicsdev/multiadc.py](epicsdev/multiadc.py).
- `SPV(initial, meta, vtype)` uses compact `meta`: `W` (writable), `R` (readable), `A` (alarm), `D` (discrete enum). `D` creates an `NTEnum` with `{choices,index}`.
- Writable PVs set `control.limitLow/High` to `0` as a PVAccess writability workaround (see `_create_PVs()` in [epicsdev/epicsdev.py](epicsdev/epicsdev.py)).
- `extra` dict keys commonly used: `setter`, `units`, `limitLow`, `limitHigh`, `format`, `valueAlarm`. `setter` receives `(value, spv)`.
- Prefer `publish()`/`pvv()` instead of direct `SharedPV` access; logging uses `printi/printw/printe`, which also updates the `status` PV.
- In multi-channel templates, don’t pre-create `SPV` objects; use tuples and convert per-channel (see `ChannelTemplates` in [epicsdev/multiadc.py](epicsdev/multiadc.py)).

## External deps & integration points
- Build system is hatchling; package requires Python >=3.7 and `p4p` (see [pyproject.toml](pyproject.toml)). Optional runtime tools: `pypeto`, `pvplot` for GUI/plotting (see [README.md](README.md)).

## Common workflows (from README)
- Run demo server: `python -m epicsdev.epicsdev`
- Control/plot demo (requires `pypeto`, `pvplot`): `python -m pypeto -c config -f epicsdev`
- Run multi-channel waveform generator: `python -m epicsdev.multiadc -c100 -n1000`
- Launch multiadc GUI: `python -m pypeto -c config -f multiadc`
