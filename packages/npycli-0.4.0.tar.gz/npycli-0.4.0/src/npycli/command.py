from __future__ import annotations
from collections.abc import Callable
from typing import Optional, Any, get_type_hints
from dataclasses import dataclass, field
from inspect import signature, Signature, Parameter, getdoc

from .parameters import CommandParameter, ParameterKind, CommandParameterType, parse_parameters
from .errors import ParsingError, CommandArgumentError


@dataclass
class Command:
    __CMD_ATTR__ = '__cmd__'
    __CMD_HOOKS_ATTR__ = '__cmd_hooks__'

    function: Callable[..., Any]
    names: tuple[str, ...]
    help: Optional[str] = field(default=None)
    kwarg_prefix: str = field(default_factory=lambda: '--')

    @staticmethod
    def create(function: Callable[..., Any], name: Optional[str] = None, names: Optional[tuple[str, ...]] = None,
               help: Optional[str] = None, kwarg_prefix: Optional[str] = None) -> Command:
        """
        Create a Command, wrapper for using either `name` or `names`
        :param function: Function to execute `Command` with.
        :param name: Name of `Command`
        :param names: Name and aliases of `Command`. *Cannot be used with `name`*
        :param help: Help string
        :param kwarg_prefix: Prefix of argument to represent next argument is the value of this argument's keyword
        :return: Created `Command`
        """

        if names is None:
            if name:
                names = name,
            else:
                names = function.__name__,

        return Command(function=function, names=names, help=help,
                       kwarg_prefix=kwarg_prefix or "--")

    @property
    def name(self) -> str:
        """
        Primary name of this `Command`
        :return: Name
        """

        return self.names[0]

    @property
    def aliases(self) -> tuple[str, ...]:
        """
        Aliases of this `Command`
        :return: Aliases
        """

        return self.names[1:]

    @property
    def details(self) -> str:
        """
        Details of this command, which include but are not limited to:
        * Name
        * Aliases
        * Arguments
        * Help string
        :return: Details
        """

        return self.basic_command_help()

    @property
    def parameters(self) -> list[CommandParameter]:
        return self._parameters

    def add_detail(self, detail: str) -> None:
        """
        Add details to this `Command`
        :param detail: Specific detail
        :return: `None`
        """

        self._details.append(detail)

    def find_parameter(self, parameter_name: str) -> CommandParameter | None:
        return next(filter(lambda p: parameter_name in p.names, self._parameters), None)

    def exec_with(self, entries: list[str], parsers: Optional[dict[CommandParameterType, Callable[[str], Any]]] = None) -> Any:
        """
        Execute this `Command` with specified arguments and parsers
        :param args: Arguments
        :param parsers: Custom parsers to parse arguments with.
        :return:
        """

#        positionals, keywords = extract_positionals_keywords(args, self.kwarg_prefix)
#        args, kwargs = parse_args_as(positionals, keywords, self._positional_types, self._keyword_types,
#                                     self._var_args_index, self._var_args_parser, parsers)
        args, kwargs = parse_parameters(self._parameters, entries, self.kwarg_prefix, self.kwarg_prefix, parsers or {})
        try:
            return self.function(*args, **kwargs)
        except TypeError as type_error:
            if self._is_argument_error(type_error):
                raise CommandArgumentError(*type_error.args)
            raise type_error
        except ParsingError as parsing_error:
            raise CommandArgumentError(*parsing_error.args)

    def _validate_data(self) -> None:
        if not callable(self.function):
            raise TypeError(f'{Command._validate_data} -> {self.function} is not callable.')
        if not isinstance(self.names, tuple) or not all(isinstance(name, str) for name in self.names): # type: ignore
            raise TypeError(f'{Command} names must be a {tuple} of {str}.')
        if not self.names:
            raise ValueError(f'{Command} names must not be empty.')
        for name in self.names:
            for c in name:
                if c.isspace():
                    raise ValueError(f'Name for {self.function} cannot contain whitespace: {name}')
        if getattr(self.function, Command.__CMD_ATTR__, None) is not None:
            raise TypeError(f'Function {self.function} is already a {Command}.')
        if self.help is not None and not isinstance(self.help, str): # type: ignore
            raise TypeError(f'{Command} help must be a {str}.')

    def _attach_self(self) -> None:
        setattr(self.function, Command.__CMD_ATTR__, self)

    def _extract_signature(self) -> None:
        self._signature: Signature = signature(self.function)
        self._required_parameters: list[Parameter] = []
        self._optional_parameters: list[Parameter] = []
        self._positional_types: list[CommandParameterType] = []
        self._keyword_types: dict[str, CommandParameterType] = {}
        self._has_var_args: bool = False
        self._var_args_index: Optional[int] = None
        self._has_var_kwargs: bool = False
        self._var_args_parser: Optional[CommandParameterType] = None
        self._parameters: list[CommandParameter] = []

        annotations: dict[str, Any] = get_type_hints(self.function, include_extras=True)

        for index, parameter in enumerate(self._signature.parameters.values()):
            self._parameters.append(
                CommandParameter.build(
                    parameter.name,
                    parameter.kind,
                    annotations[parameter.name],
                    default=parameter.default
                )
            )

            if parameter.default == parameter.empty:
                self._required_parameters.append(parameter)
            else:
                self._optional_parameters.append(parameter)

            if parameter.kind == Parameter.VAR_POSITIONAL:
                self._var_args_parser = self._parameters[-1].argument_types[0]
                self._var_args_index = index
                continue
            if parameter.kind == Parameter.VAR_KEYWORD:
                self._has_var_kwargs = True
                continue

            parameter_type: CommandParameterType = self._parameters[-1].argument_types[0]
            self._positional_types.append(parameter_type)
            self._keyword_types[parameter.name] = parameter_type

    def _generate_details(self) -> None:
        self._details: list[str] = []
        if self.help is None and (doc := getdoc(self.function)) is not None:
            self.help = doc

    def _callback_futures(self) -> None:
        if not hasattr(self.function, Command.__CMD_HOOKS_ATTR__):
            return
        for callback in getattr(self.function, Command.__CMD_HOOKS_ATTR__):
            callback(self)

    def __post_init__(self) -> None:
        self._validate_data()
        self._attach_self()
        self._extract_signature()
        self._generate_details()
        self._callback_futures()

    def _is_argument_error(self, type_error: TypeError) -> bool:
        return type_error.args[0].startswith(f'{self.function.__name__}(')

    def basic_command_help(self) -> str:
        out: str = f"{self.name} "
        last_positional_only_index: int = -1
        for i, parameter in enumerate(self.parameters):
            if parameter.kind == ParameterKind.POSITIONAL_ONLY:
                last_positional_only_index = i
            else:
                break

        for i, parameter in enumerate(self.parameters):
            out += parameter.basic_parameter_help()
            if i == last_positional_only_index:
                out += " /"
            if i != len(self.parameters) - 1:
                out += " "
        return out

    def extended_command_help(self) -> str:
        out: str = ""
        for i, name in enumerate(self.names):
            out += name
            if i != len(self.names) - 1:
                out += " "
        out += "\n"

        out += "Parameters:\n"
        for i, parameter in enumerate(self.parameters):
            out += parameter.extended_parameter_help()
            if i != len(self.parameters) - 1:
                out += "\n"

        if self.help:
            out += f"\nDesciption: {self.help}"

        for detail in self._details:
            out += f"\n->{detail}"

        return out

    def __call__(self, args: list[str], parsers: Optional[dict[CommandParameterType, Callable[[str], Any]]] = None) -> Any:
        return self.exec_with(args, parsers)

    def __str__(self) -> str:
        return self.details


def is_cmd(function: Callable[..., Any]) -> bool:
    return hasattr(function, Command.__CMD_ATTR__)


def cmd(function: Callable[..., Any]) -> Command:
    if is_cmd(function):
        return getattr(function, Command.__CMD_ATTR__)
    raise ValueError(f"{function} is not a command. Use {is_cmd}.")


def cmd_hook(function: Callable[..., Any], callback: Callable[[Command], None]) -> None:
    if is_cmd(function):
        raise \
            TypeError(f'function {function} is already not a future command, it is already a command: {cmd(function)}')
    if not hasattr(function, Command.__CMD_HOOKS_ATTR__):
        setattr(function, Command.__CMD_HOOKS_ATTR__, [])
    getattr(function, Command.__CMD_HOOKS_ATTR__).append(callback)
