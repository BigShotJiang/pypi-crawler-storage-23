"""
Novyx SDK - Persistent memory + rollback + audit trail for AI agents.

Quick Start:
    >>> from novyx import Novyx
    >>> nx = Novyx(api_key="nram_your_key_here")
    >>>
    >>> # Store and recall memories
    >>> nx.remember("User prefers dark mode", tags=["ui"])
    >>> memories = nx.recall("user preferences")
    >>>
    >>> # Check audit trail
    >>> audit = nx.audit(limit=10)
    >>>
    >>> # Rollback if needed (Pro+)
    >>> nx.rollback("2 hours ago")
    >>>
    >>> # Trace agent actions (Pro+)
    >>> trace = nx.trace_create("my-agent")
    >>> nx.trace_step(trace["trace_id"], "action", "send_email")
"""

from .client import Novyx, Memory, SearchResult, ListResult
from .exceptions import (
    NovyxError,
    NovyxAuthError,
    NovyxForbiddenError,
    NovyxRateLimitError,
    NovyxNotFoundError,
    NovyxSecurityError,
    NovyxUpgradeRequired,  # Legacy alias
)

__version__ = "2.1.0"
__all__ = [
    "Novyx",
    "Memory",
    "SearchResult",
    "ListResult",
    "NovyxError",
    "NovyxAuthError",
    "NovyxForbiddenError",
    "NovyxRateLimitError",
    "NovyxNotFoundError",
    "NovyxSecurityError",
    "NovyxUpgradeRequired",
]
