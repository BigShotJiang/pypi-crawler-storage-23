def main():
    print("Hello from caldav-event-pusher!")


if __name__ == "__main__":
    main()
