# system modules
import sys
import uuid
import copy
import time
import json
import logging
import argparse
from datetime import datetime, timedelta, timezone
import os
import atexit
from collections import defaultdict, Counter

# external modules
import caldav
import icalendar
import isodate
import dictdiffer
from rich.logging import RichHandler
from rich.console import Console
from rich.text import Text
from rich.table import Table
from rich.panel import Panel
import rich.box
from rich.progress import (
    Progress,
    BarColumn,
    ProgressColumn,
    TaskProgressColumn,
    TextColumn,
    TimeRemainingColumn,
    TimeElapsedColumn,
    MofNCompleteColumn,
)


console = Console(stderr=True)

parser = argparse.ArgumentParser(
    description="Push (or update) events to a CalDAV calendar",
    formatter_class=argparse.ArgumentDefaultsHelpFormatter,
)
logingroup = parser.add_argument_group("CalDAV Options")
logingroup.add_argument(
    "--server",
    default=os.environ.get(envvar := "CALDAV_SERVER"),
    help=f"url to the CalDAV server [envvar:{envvar}]",
)
logingroup.add_argument(
    "--user",
    default=os.environ.get(envvar := "CALDAV_USER"),
    help=f"CalDAV login user [envvar:{envvar}]",
)
logingroup.add_argument(
    "--password",
    default=os.environ.get(envvar := "CALDAV_PASSWORD"),
    help=f"CalDAV login password [envvar:{envvar}]",
)
behaviorgroup = parser.add_argument_group("Behaviour")
behaviorgroup.add_argument(
    "--calendar",
    default=os.environ.get(envvar := "CALDAV_CALENDAR"),
    help=f"which calendar to use. Matched against calendar id and display name. Direct and case-sensitive matches are prioritised over partial and case-insensitive matches. [envvar:{envvar}]",
)
behaviorgroup.add_argument(
    "--no-id-key-check",
    action="store_true",
    help="Skip checking if the --id-key survives an upload to the calendar. Not all CalDAV servers accept arbitrary fields, Radicale does, but Horde for example doesn't. Only provide this option if you are sure that yours does, otherwise you might end up with a lot of duplicate events.",
)
behaviorgroup.add_argument(
    "--full",
    action="store_true",
    help="retrieve all events from the calendar. Without this, only events within the time frame in the --eventsfile are queried. Using this is more thorough (e.g. will correctly update events that have been moved around weirdly), but slower.",
)
behaviorgroup.add_argument(
    "--delete-extra",
    action="store_true",
    help="delete other queried events with an --id-key field value not present in --eventsfile. Obviously be careful with this. Use --full to be thorough.",
)
behaviorgroup.add_argument(
    "-n",
    "--dry-run",
    action="store_true",
    help="Skip any actions that would change data on the server. Combine with some -v to increase verbosity.",
)
behaviorgroup.add_argument(
    "--id-key",
    default=os.environ.get(
        envvar := "CALDAV_ID_KEY",
        DEFAULT_IDENTIFIER_VEVENT_KEY := "X-CALDAV-EVENT-PUSHER-ID",
    ),
    help=f"iCalendar key to store the identifier in. Only change this if you know what you're doing! [envvar:{envvar}]",
)

iogroup = parser.add_argument_group("IO Options")
iogroup.add_argument(
    "--eventsfile",
    type=argparse.FileType("r"),
    help="file containing events to push. JSON object mapping unique identifiers to objects with iCalendar key/value pairs",
    default=sys.stdin,
)
logginggroup = parser.add_argument_group("Logging Options")
logginggroup.add_argument(
    "--no-progress", action="store_true", help="disable progress bar"
)
logginggroup.add_argument(
    "-v", "--verbose", help="more -v → more output", action="count", default=0
)
logginggroup.add_argument(
    "-q", "--quiet", help="more -q → less output", action="count", default=0
)

logger = logging.getLogger(__name__)


def ensuretz(dt):
    match dt:
        case datetime(tzinfo=None):
            logger.warning(f"Assuming {dt} is UTC")
            return dt.replace(tzinfo=timezone.utc)
        case datetime():
            return dt
    return dt


def renderPretty(vobj):
    match vobj:
        case icalendar.prop.vText():
            return str(vobj)
        case icalendar.prop.vDatetime() | icalendar.prop.vDDDTypes():
            match vobj.dt:
                case datetime():
                    return vobj.dt.isoformat()
                case timedelta():
                    return str(vobj.dt)
        case icalendar.prop.vCategory():
            return list(vobj)
    return str(vobj)


# 🐒🩹 monkey-patch VEVENT class for pretty rendering
icalendar.Event.___pretty = property(
    lambda vevent: {k: renderPretty(v) for k, v in vevent.items()}
)


def pretty_event_changes(event1, event2):
    table = Table(
        show_header=False,
        box=None,  # rich.box.MINIMAL,
    )
    table.add_column("type")
    table.add_column("key", justify="right")
    table.add_column("old", style="red")
    table.add_column("arrow")
    table.add_column("new", style="green")
    for changeset in dictdiffer.diff(dict(event1), dict(event2)):
        operation, location, changes = changeset
        if logger.getEffectiveLevel() < logging.DEBUG - 5:
            logger.debug(changes)
        match operation:
            case "add":
                for key, value in changes:
                    table.add_row("➕", key, "", "→", value, style="green")
            case "change":
                table.add_row(
                    "📝",
                    location,
                    Text(changes[0], style="strike"),
                    "→",
                    changes[1],
                )
            case "remove":
                for key, value in changes:
                    table.add_row("➖", key, "", "", value, style="strike red")
    return table


def cli():
    args = parser.parse_args()

    logging.basicConfig(
        level=(level := logging.INFO - (args.verbose - args.quiet) * 5),
        format="%(message)s",
        datefmt="[%X]",
        handlers=[
            RichHandler(
                console=console, rich_tracebacks=True, show_path=level < logging.DEBUG
            )
        ],
    )
    if level >= -10:
        for name, lgr in logging.root.manager.loggerDict.items():
            if not name.startswith(__name__):
                lgr.disabled = True
    if not all({args.server, args.user, args.password, args.calendar}):
        parser.error(
            f"--server --user --password --calendar (or their environment variable counterparts) are all required"
        )

    if args.eventsfile is sys.stdin and sys.stdin.isatty():
        logger.warning(
            f"You didn't specify --eventsfile, so you'll need to paste the JSON here now, then press CTRL-D:"
        )

    try:
        eventsToPushTemplate = json.load(args.eventsfile)
    except json.JSONDecodeError as e:
        parser.error(f"Couldn't parse eventsfile JSON: {e!r}")
    if logger.getEffectiveLevel() < logging.INFO:
        console.log(eventsToPushTemplate)
    if not hasattr(eventsToPushTemplate, "items"):
        logger.critical(
            f"--eventsfile does not contain a JSON object, but instead a {type(eventsToPushTemplate).__name__}:"
        )
        if logger.getEffectiveLevel() <= logging.CRITICAL:
            console.log(eventsToPushTemplate)
        parser.exit(1)

    eventsToPush = []
    for i, (identifier, eventTemplate) in enumerate(eventsToPushTemplate.items()):
        if not hasattr(eventTemplate, "items"):
            logger.error(
                f"Skipping identifier key {identifier!r} as it does not contain a JSON object, but instead a {type(eventTemplate).__name__}:"
            )
            if logger.getEffectiveLevel() <= logging.ERROR:
                console.log(eventTemplate)
            continue
        eventToPush = eventTemplate.copy()
        eventToPush[args.id_key] = identifier
        parsedFields = {}
        failedFields = defaultdict(list)
        for timeparser, keys in (
            timeparsers := {
                datetime.fromisoformat: [
                    "DTSTART",
                    "DTEND",
                    "DTSTAMP",
                    "CREATED",
                    "LAST-MODIFIED",
                ],
                isodate.parse_duration: ["DURATION"],
            }
        ).items():
            for key in keys:
                if value := eventTemplate.get(key):
                    try:
                        eventToPush[key] = (parsed := timeparser(value))
                        parsedFields[key] = (value, parsed)
                        if logger.getEffectiveLevel() < logging.DEBUG:
                            logger.debug(
                                f"{identifier!r}: {key} {value!r} → {eventToPush[key]}"
                            )
                    except Exception as e:
                        failedFields[key].append((timeparser, value, e))
        if logger.getEffectiveLevel() < logging.DEBUG - 5:
            logger.debug(f"{parsedFields=}")
            logger.debug(f"{dict(failedFields)=}")
        for key, attempts in failedFields.items():
            for timeparser, value, e in attempts:
                logger.error(
                    f"{identifier!r}: Couldn't parse timestamp {key}={value!r} with {timeparser.__qualname__}: {e!r}"
                )
        eventsToPush.append(eventToPush)

    minDatetime = dtstart = (datetimeMax := datetime.max.replace(tzinfo=timezone.utc))
    maxDatetime = dtend = (datetimeMin := datetime.min.replace(tzinfo=timezone.utc))
    for event in eventsToPush:
        match ensuretz(event.get("DTSTART")), ensuretz(event.get("DTEND")), event.get(
            "DURATION"
        ):
            case datetime() as DTSTART, datetime() as DTEND, _ as DURATION:
                dtstart = DTSTART
                dtend = DTEND
            case datetime() as DTSTART, None as DTEND, timedelta() as DURATION:
                dtstart = DTSTART
                dtend = DTSTART + DURATION
            case None as DTSTART, datetime() as DTEND, timedelta() as DURATION:
                dtstart = DTEND - DURATION
                dtend = DTEND
            case datetime() as DTSTART, None as DTEND, None as DURATION:
                dtstart = dtend = DTSTART
            case None as DTSTART, datetime() as DTEND, None as DURATION:
                dtstart = dtend = DTEND
            case _ as DTSTART, _ as DTEND, _ as DURATION:
                logger.error(
                    f"{event[args.id_key]!r}: Incomplete combination of {DTSTART = }, {DTEND = }, and {DURATION = }"
                )
                continue
        minDatetime = min(minDatetime, dtstart)
        maxDatetime = max(maxDatetime, dtend)
    if minDatetime == datetimeMax:
        logger.error(f"Couldn't figure out earliest event. Falling back to --full.")
        minDatetime = datetimeMin
        args.full = True
    if maxDatetime == datetimeMin:
        logger.error(f"Couldn't figure out latest event. Falling back to --full.")
        maxDatetime = datetimeMax
        args.full = True

    logger.info(
        f"📤 Will push {len(eventsToPush)}/{len(eventsToPushTemplate)} events between {minDatetime.isoformat()} ⬌ {maxDatetime.isoformat()} to CalDAV server {args.server!r} → {args.user!r} → {args.calendar!r}"
    )
    if logger.getEffectiveLevel() <= logging.DEBUG:
        console.log(eventsToPush)

    logger.info(f"⏳ Connecting to {args.server} with user {args.user}...")
    client = caldav.DAVClient(
        url=args.server, username=args.user, password=args.password
    )
    calendars = client.principal().calendars()

    logger.info(
        f"🔎 Found {len(calendars)} calendars for {args.user}: { {c.id: c.name for c in calendars} }"
    )
    logger.debug(f"🔎 Looking for calendars matching {args.calendar!r}")

    calendar = None
    for matchType, matcher in {
        "direct": lambda calendar: args.calendar in {calendar.name, calendar.id},
        "direct case-insensitive": lambda calendar: args.calendar.lower()
        in {calendar.name.lower(), calendar.id.lower()},
        "partial": lambda calendar: args.calendar in calendar.name
        or args.calendar in calendar.id,
        "partial case-insensitive": lambda calendar: args.calendar.lower()
        in calendar.name.lower()
        or args.calendar.lower() in calendar.id.lower(),
    }.items():
        matchingCalendars = list(filter(matcher, calendars))
        if (n := len(matchingCalendars)) == 1:
            calendar = matchingCalendars[0]
            logger.info(
                f"✅ {args.calendar!r} matches {calendar.name!r} (id:{calendar.id!r}) [{matchType} match]"
            )
            break
        elif len(matchingCalendars) > 1:
            logger.critical(
                f"🤷 {n} calendars match {args.calendar!r} [{matchType} match]:\n{ {c.id: c.name for c in matchingCalendars} }"
            )
            parser.exit(2)
    if calendar is None:
        logger.critical(f"🤷 No calendars match {args.calendar!r}")
        parser.exit(2)

    progress = Progress(
        *[
            MofNCompleteColumn(),
            BarColumn(),
            TaskProgressColumn(),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
            TextColumn("[progress.description]{task.description}"),
        ],
        disable=args.no_progress or logger.getEffectiveLevel() > logging.CRITICAL,
        console=console,
    )
    if not progress.disable:
        progress.start()
        atexit.register(progress.stop)

    if not args.no_id_key_check:
        check_task = progress.add_task(
            description=f"⌛ checking {args.id_key} field...", total=None
        )
        logger.info(
            f"Checking if {args.server} accepts the {args.id_key!r} field. You can skip this check by providing --no-id-key-check if you are sure that the server accepts it."
        )
        event = caldav.Event()
        # ⚠️  _icalendar_instance is a nonpublic API!
        event._icalendar_instance = (cal := icalendar.Calendar())
        cal.add("PRODID", "-//nobodyinperson//caldav-event-pusher//")
        cal.add("VERSION", "2.0")
        cal.add_component(vevent := icalendar.Event())
        vevent.add("UID", str(uuid.uuid4()))
        vevent.add("SUMMARY", "🗑️ DELETE ME! You should not see this canary event!")
        vevent.add("DTSTART", now := datetime.now(timezone.utc).replace(microsecond=0))
        vevent.add("DTEND", now + timedelta(hours=1))
        vevent.add(
            "DESCRIPTION",
            f"This event was created by caldav-event-pusher at {now.isoformat()} to check if this server accepts the {args.id_key!r} field. If it was not cleaned up it is a bug in caldav-event-pusher.",
        )
        if args.id_key in vevent:
            del vevent[args.id_key]
        vevent.add(args.id_key, f"🥹 Please {args.server}, accept me!")
        if logger.getEffectiveLevel() <= logging.DEBUG:
            logger.debug(f"🐦📤 Canary event to upload:")
            console.log(Panel(event.data, expand=False))
            # console.log(dict(event.icalendar_instance.walk("vevent")[0].___pretty))
        if args.dry_run:
            logger.warning(f"Skipping canary event upload due to --dry-run")
        else:

            try:
                calendar.add_event(event.data)
            except Exception as e:
                logger.error(
                    msg := f"💥 Couldn't upload canary test event to check if {args.server} accepts the {args.id_key!r} field: {e!r}"
                )
                raise
                parser.error(msg)
            try:
                event2 = calendar.event_by_uid(vevent["UID"])

                def cleanup_canary():
                    logger.info(
                        f"🧹 Removing canary event from {calendar.canonical_url}"
                    )
                    progress.update(check_task, description=f"🧹 canary cleanup")
                    try:
                        event2.delete()
                    except Exception as e:
                        logger.error(f"Couldn't remove canary event: {e!r}")

                atexit.register(cleanup_canary)
                vevent2 = event2.icalendar_instance.walk("vevent")[0]
                if logger.getEffectiveLevel() <= logging.DEBUG:
                    logger.debug(f"🐦📥 Retrieved canary event:")
                    console.log(Panel(event2.data, expand=False))
            except Exception as e:
                logger.critical(
                    msg := f"💥 Canary event was uploaded to {args.server}, but couldn't be retrieved: {e!r}"
                )
                parser.exit(1)
            if dict(event.icalendar_instance) != dict(event2.icalendar_instance):
                logger.debug(f"⚠️  {args.server} modified the canary event")
                if logger.getEffectiveLevel() <= logging.INFO:
                    table = pretty_event_changes(vevent.___pretty, vevent2.___pretty)
                    console.print(
                        Panel(
                            table,
                            expand=False,
                            title=(f"Changes applied to canary event by {args.server}"),
                        ),
                    )
            atexit.unregister(cleanup_canary)
            cleanup_canary()
            progress.update(check_task, completed=1, total=1)
            if args.id_key in vevent2:
                logger.info(f"✅ {args.server} accepts the {args.id_key!r} field!")
                progress.update(check_task, description=f"✅ {args.id_key} is accepted")
            else:
                logger.critical(
                    f"⚠️  {args.server} does not accept the {args.id_key!r} field. Specify e.g. --id-key=DESCRIPTION to put the identifier into the event's description, but note that this will obviously overwrite your own descriptions. Blame your CalDAV server."
                )
                progress.update(
                    check_task, description=f"❌ {args.id_key} not accepted"
                )
                parser.exit(1)

    fetch_task = progress.add_task(description="📥 retrieving events...", total=None)
    if args.full:
        logger.info(f"📥 Retrieving all events from calendar {calendar.name!r}")
        eventsInCalendar = calendar.events()
    else:
        # enlarge search range a bit just to be sure
        minDatetime -= timedelta(days=1)
        maxDatetime += timedelta(days=1)
        logger.info(
            f"📥 Retrieving events between {minDatetime.isoformat()} ⬌ {maxDatetime.isoformat()} from calendar {calendar.name!r}"
        )
        eventsInCalendar = calendar.date_search(start=minDatetime, end=maxDatetime)
    logger.info(
        f"📅 Retrieved {len(eventsInCalendar)} events from calendar {calendar.name!r}"
    )
    if logger.getEffectiveLevel() < logging.DEBUG - 10:
        for i, event in enumerate(eventsInCalendar, start=1):
            console.log(Panel(event.data, expand=False, title=f"Event #{i}"))
    progress.update(
        fetch_task,
        completed=0,
        total=len(eventsInCalendar),
        description=f"📜 parsing {len(eventsInCalendar)} events...",
    )
    veventsInCalendar = list()
    veventIDs = defaultdict(list)
    for n, eventInCalendar in enumerate(eventsInCalendar, start=1):
        try:
            for vevent in eventInCalendar.icalendar_instance.walk("VEVENT"):
                vevent.___original = copy.deepcopy(vevent)
                vevent.___event = eventInCalendar
                veventsInCalendar.append(vevent)
                if identifier := vevent.get(args.id_key):
                    veventIDs[identifier].append(vevent)
        except Exception as e:
            logger.error(f"Can't parse event #{n}: {e!r}")
        progress.update(fetch_task, completed=n)
    progress.update(
        fetch_task,
        completed=len(eventsInCalendar),
        total=len(eventsInCalendar),
        description=f"✅ parsed {len(veventsInCalendar)} VEVENTs",
    )
    for identifier, vevents in veventIDs.items():
        if (n := len(vevents)) > 1:
            logger.warning(
                f"There are {n} events with {identifier=!r}. This should not happen."
            )

    logger.info(
        f"📜 Planning changes to push our {len(eventsToPush)} events from {args.eventsfile.name} to {calendar.url}"
    )
    plan_task = progress.add_task(description="⏳ planning changes...")
    veventsTouched = list()
    for nPush, eventToPush in enumerate(
        progress.track(eventsToPush, task_id=plan_task),
        start=1,
    ):
        veventsMatchingInCalendar = []
        for nvevent, veventInCalendar in enumerate(veventsInCalendar, start=1):
            if veventInCalendar.get(args.id_key) == eventToPush[args.id_key]:
                veventsMatchingInCalendar.append(veventInCalendar)
        if not veventsMatchingInCalendar:
            logger.debug(
                f"✨ No match for {eventToPush[args.id_key]!r}, will create new"
            )
            event = caldav.Event(client=client, parent=calendar)
            # ⚠️  _icalendar_instance is a nonpublic API!
            event._icalendar_instance = (cal := icalendar.Calendar())
            cal.add("PRODID", "-//nobodyinperson//caldav-event-pusher//")
            cal.add("VERSION", "2.0")
            cal.add_component(vevent := icalendar.Event())
            vevent.add("UID", str(uuid.uuid4()))
            for k, v in eventToPush.items():
                if k in vevent:
                    del vevent[k]
                vevent.add(k, v)
            if "SUMMARY" not in vevent:
                vevent.add("SUMMARY", eventToPush[args.id_key])
            vevent.___event = event
            vevent.___original = icalendar.Event()
            veventsTouched.append(vevent)
        else:
            for vevent in veventsMatchingInCalendar:
                logger.debug(
                    f"📝 vevent {str(vevent["UID"])!r} matches {eventToPush[args.id_key]!r}, will update"
                )
                for k, v in eventToPush.items():
                    if k in vevent:
                        del vevent[k]
                    vevent.add(k, v)
                if "SUMMARY" not in vevent:
                    vevent.add("SUMMARY", eventToPush[args.id_key])
                veventsTouched.append(vevent)
    eventsToProcess = defaultdict(set)
    veventsToSave = list()
    for vevent in progress.track(veventsTouched, task_id=plan_task):
        if vevent != vevent.___original:
            if vevent.___original == icalendar.Event():  # empty
                now = icalendar.vDatetime(datetime.now(timezone.utc))
                vevent["LAST-MODIFIED"] = now
                vevent["DTSTAMP"] = now
                eventsToProcess["create"].add(vevent.___event)
            else:
                eventsToProcess["save"].add(vevent.___event)
            # TODO: if vevent == icalendar.Event() for deletion!?
            if (event := getattr(vevent, "___event", None)) is None:
                logger.error(
                    f"⚠️ {vevent = } has no ___event set, this should not happen! Skipping."
                )
                continue
            logger.debug(
                f"VEVENT {str(vevent["UID"])!r} ({str(vevent[args.id_key])!r}) changed"
            )
            # simulate changes
            # vevent.___original["UID"] = "bla"
            # vevent.___original["I-WAS-HERE-BEFORE"] = "yes!"
            if args.dry_run or logger.getEffectiveLevel() <= logging.INFO:
                table = pretty_event_changes(
                    vevent.___original.___pretty, vevent.___pretty
                )
                console.print(
                    Panel(
                        table,
                        expand=False,
                        title=(
                            f"✨ New event {str(vevent[args.id_key])!r}"
                            if vevent.___original == icalendar.Event()
                            else f"📝 Changes to {str(vevent[args.id_key])!r}"
                        ),
                    ),
                )
            veventsToSave.append(vevent)
        else:
            logger.debug(
                f"No change to {str(vevent["UID"])!r} ({str(vevent[args.id_key])!r})"
            )
    logger.info(
        f"📜 Planned changes to {len(veventsToSave)} VEVENTs, touching {len(eventsToProcess["save"])} existing events"
    )
    progress.update(plan_task, description=f"✅ planned {len(veventsToSave)} changes")

    if args.dry_run:
        logger.info(f"🛑 Not uploading any changes because of --dry-run")
        parser.exit(0)

    uploadStats = Counter()
    nPlannedChanges = len(sum(map(list, eventsToProcess.values()), start=[]))
    if not nPlannedChanges:
        logger.info("😴 Nothing to do.")
        parser.exit(0)

    upload_task = progress.add_task(
        description="📤 Uploading changes...",
        total=nPlannedChanges,
    )
    for event in eventsToProcess["create"]:
        if logger.getEffectiveLevel() < logging.INFO:
            logger.info(f"📤 Creating {event}")
        try:
            calendar.add_event(event.data)
            uploadStats["success"] += 1
        except Exception as e:
            logger.error(f"Couldn't create new event {event}: {e!r}")
            if logger.getEffectiveLevel() <= logging.ERROR:
                console.log(Panel(event.data, expand=False, title="Event data"))
            uploadStats["error"] += 1
        progress.update(upload_task, advance=1)
    for event in eventsToProcess["save"]:
        if logger.getEffectiveLevel() < logging.INFO:
            logger.info(f"📤 Saving {event}")
        try:
            event.save()
            uploadStats["success"] += 1
        except Exception as e:
            logger.error(f"Couldn't modify event {event}: {e!r}")
            if logger.getEffectiveLevel() <= logging.ERROR:
                console.log(Panel(event.data, expand=False, title="Event data"))
            uploadStats["error"] += 1
        progress.update(upload_task, advance=1)
    logger.debug(f"{dict(uploadStats) = }")
    if sum(uploadStats.values()):
        logger.info(
            f"✅ Uploaded {uploadStats["success"]} changes successfully ({uploadStats["error"]} errors)!"
        )
    progress.update(
        upload_task,
        description=f"✅ Uploaded changes ({uploadStats["error"]} errors)",
        total=nPlannedChanges,
    )

    if args.delete_extra:
        logger.warning(f"--delete-extra is not implemented yet")


if __name__ == "__main__":
    cli()
