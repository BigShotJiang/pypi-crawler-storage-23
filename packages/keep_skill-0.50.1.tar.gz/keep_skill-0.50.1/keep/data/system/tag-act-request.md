---
tags:
  category: system
  context: tag-value
---
# act: `request`

A directive speech act — asking someone to do something. Requests create expectations and are tracked with `status` (open, fulfilled, declined, etc.).

Example: "Please review the PR", "Can you update the docs?".
