include!("env_pool/00_types.rs");
include!("env_pool/10_parse.rs");
include!(concat!(env!("OUT_DIR"), "/env_pool_methods.rs"));
include!("env_pool/90_module.rs");
