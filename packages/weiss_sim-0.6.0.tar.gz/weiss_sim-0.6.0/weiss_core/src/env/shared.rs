// Pure shared helpers live here.
