use std::sync::Arc;

#[path = "scenario_support.rs"]
mod scenario_support;

use weiss_core::config::{
    CurriculumConfig, EnvConfig, ErrorPolicy, ObservationVisibility, RewardConfig,
};
use weiss_core::db::{AbilityTemplate, CardColor, CardDb, CardStatic, CardType, TargetTemplate};
use weiss_core::encode::MAX_DECK;
use weiss_core::env::GameEnv;
use weiss_core::legal::{ActionDesc, Decision, DecisionKind};
use weiss_core::replay::{ReplayConfig, ReplayEvent};
use weiss_core::state::{ChoiceReason, ModifierDuration, Phase, TargetZone};

const CARD_BASIC: u32 = 1;
const CARD_ACT_TARGET_POWER: u32 = 40;
const CARD_CONTINUOUS_SELF_BOUNCE: u32 = 41;

fn enable_validate() {
    scenario_support::enable_validate();
}

fn replay_config() -> ReplayConfig {
    scenario_support::replay_config()
}

fn make_db() -> Arc<CardDb> {
    let cards = vec![
        CardStatic {
            id: CARD_BASIC,
            card_set: None,
            card_type: CardType::Character,
            color: CardColor::Red,
            level: 0,
            cost: 0,
            power: 500,
            soul: 1,
            triggers: vec![],
            traits: vec![],
            abilities: vec![],
            ability_defs: vec![],
            counter_timing: false,
            raw_text: None,
        },
        CardStatic {
            id: CARD_ACT_TARGET_POWER,
            card_set: None,
            card_type: CardType::Character,
            color: CardColor::Blue,
            level: 0,
            cost: 0,
            power: 500,
            soul: 1,
            triggers: vec![],
            traits: vec![],
            abilities: vec![AbilityTemplate::ActivatedTargetedPower {
                amount: 1000,
                count: 1,
                target: TargetTemplate::SelfStage,
            }],
            ability_defs: vec![],
            counter_timing: false,
            raw_text: None,
        },
        CardStatic {
            id: CARD_CONTINUOUS_SELF_BOUNCE,
            card_set: None,
            card_type: CardType::Character,
            color: CardColor::Green,
            level: 0,
            cost: 0,
            power: 500,
            soul: 1,
            triggers: vec![],
            traits: vec![],
            abilities: vec![
                AbilityTemplate::ContinuousPower { amount: 1500 },
                AbilityTemplate::ActivatedTargetedMoveToHand {
                    count: 1,
                    target: TargetTemplate::SelfStage,
                },
            ],
            ability_defs: vec![],
            counter_timing: false,
            raw_text: None,
        },
    ];
    scenario_support::make_db(cards)
}

fn make_config(deck_a: Vec<u32>, deck_b: Vec<u32>) -> EnvConfig {
    EnvConfig {
        deck_lists: [deck_a, deck_b],
        deck_ids: [300, 301],
        max_decisions: 500,
        max_ticks: 100_000,
        reward: RewardConfig::default(),
        error_policy: ErrorPolicy::Strict,
        observation_visibility: ObservationVisibility::Public,
        end_condition_policy: Default::default(),
    }
}

fn build_deck_list(size: usize, extras: &[u32]) -> Vec<u32> {
    scenario_support::build_deck_list_with_clone_padding(size, extras, CARD_BASIC, MAX_DECK)
}

#[allow(clippy::too_many_arguments)]
fn setup_player_state(
    env: &mut GameEnv,
    player: usize,
    hand: Vec<u32>,
    stock: Vec<u32>,
    stage_cards: Vec<(usize, u32)>,
    deck_top: Vec<u32>,
    clock: Vec<u32>,
    level: Vec<u32>,
    waiting_room: Vec<u32>,
    memory: Vec<u32>,
    climax: Vec<u32>,
) {
    scenario_support::setup_player_state(
        env,
        player,
        hand,
        stock,
        stage_cards,
        deck_top,
        clock,
        level,
        waiting_room,
        memory,
        climax,
    );
}

fn force_main_decision(env: &mut GameEnv, player: u8) {
    env.state.turn.phase = Phase::Main;
    env.state.turn.active_player = player;
    env.state.turn.starting_player = player;
    env.state.turn.mulligan_done = [true, true];
    env.state.turn.attack = None;
    env.state.turn.pending_level_up = None;
    env.state.turn.encore_queue.clear();
    env.state.turn.pending_triggers.clear();
    env.state.turn.trigger_order = None;
    env.state.turn.choice = None;
    env.state.turn.target_selection = None;
    env.state.turn.priority = None;
    env.state.turn.stack.clear();
    env.state.turn.pending_stack_groups.clear();
    env.state.turn.stack_order = None;
    env.state.turn.derived_attack = None;
    env.state.turn.end_phase_pending = false;
    env.state.turn.main_passed = false;
    env.decision = Some(Decision {
        player,
        kind: DecisionKind::Main,
        focus_slot: None,
    });
}

fn choose_priority_activation(env: &mut GameEnv) {
    scenario_support::choose_priority_activation(env);
}

#[test]
fn activated_targeting_resolves_via_stack() {
    enable_validate();
    let db = make_db();
    let deck_a = build_deck_list(20, &[CARD_ACT_TARGET_POWER]);
    let deck_b = build_deck_list(20, &[]);
    let config = make_config(deck_a, deck_b);
    let curriculum = CurriculumConfig {
        enable_priority_windows: true,
        ..Default::default()
    };
    let mut env = GameEnv::new_or_panic(db, config, curriculum, 120, replay_config(), None, 0);

    setup_player_state(
        &mut env,
        0,
        vec![],
        vec![],
        vec![(0, CARD_ACT_TARGET_POWER), (1, CARD_BASIC)],
        vec![],
        vec![],
        vec![],
        vec![],
        vec![],
        vec![],
    );
    setup_player_state(
        &mut env,
        1,
        vec![],
        vec![],
        vec![],
        vec![],
        vec![],
        vec![],
        vec![],
        vec![],
        vec![],
    );
    force_main_decision(&mut env, 0);
    env.validate_state().unwrap();

    env.apply_action(ActionDesc::Pass).unwrap();
    choose_priority_activation(&mut env);

    let presented = env
        .replay_events
        .iter()
        .rev()
        .find_map(|e| match e {
            ReplayEvent::ChoicePresented {
                reason: ChoiceReason::TargetSelect,
                options,
                ..
            } => Some(options.clone()),
            _ => None,
        })
        .expect("target choice");
    assert_eq!(presented.len(), 2);

    env.apply_action(ActionDesc::ChoiceSelect { index: 1 })
        .unwrap();

    let stack_pushed = env.replay_events.iter().any(|e| matches!(e,
        ReplayEvent::StackPushed { item } if matches!(item.payload.spec.kind, weiss_core::effects::EffectKind::AddModifier { magnitude: 1000, duration: ModifierDuration::UntilEndOfTurn, .. })
            && item.payload.targets.len() == 1
            && item.payload.targets[0].zone == TargetZone::Stage
            && item.payload.targets[0].index == 1
    ));
    assert!(stack_pushed);

    let modifier_added = env.replay_events.iter().any(|e| matches!(e,
        ReplayEvent::ModifierAdded { source, target_slot, magnitude: 1000, duration: ModifierDuration::UntilEndOfTurn, .. }
        if *source == CARD_ACT_TARGET_POWER && *target_slot == 1
    ));
    assert!(modifier_added);
}

#[test]
fn continuous_modifier_applies_and_clears_on_leave() {
    enable_validate();
    let db = make_db();
    let deck_a = build_deck_list(20, &[CARD_CONTINUOUS_SELF_BOUNCE]);
    let deck_b = build_deck_list(20, &[]);
    let config = make_config(deck_a, deck_b);
    let curriculum = CurriculumConfig {
        enable_priority_windows: true,
        ..Default::default()
    };
    let mut env = GameEnv::new_or_panic(db, config, curriculum, 121, replay_config(), None, 0);

    setup_player_state(
        &mut env,
        0,
        vec![CARD_CONTINUOUS_SELF_BOUNCE],
        vec![],
        vec![],
        vec![],
        vec![],
        vec![],
        vec![],
        vec![],
        vec![],
    );
    setup_player_state(
        &mut env,
        1,
        vec![],
        vec![],
        vec![],
        vec![],
        vec![],
        vec![],
        vec![],
        vec![],
        vec![],
    );
    force_main_decision(&mut env, 0);
    env.validate_state().unwrap();

    env.apply_action(ActionDesc::MainPlayCharacter {
        hand_index: 0,
        stage_slot: 0,
    })
    .unwrap();

    let modifier_added = env.replay_events.iter().any(|e| matches!(e,
        ReplayEvent::ModifierAdded { source, target_slot, magnitude: 1500, duration: ModifierDuration::WhileOnStage, .. }
        if *source == CARD_CONTINUOUS_SELF_BOUNCE && *target_slot == 0
    ));
    assert!(modifier_added);

    env.apply_action(ActionDesc::Pass).unwrap();
    choose_priority_activation(&mut env);

    let modifier_removed = env.replay_events.iter().any(|e| matches!(e,
        ReplayEvent::ModifierRemoved { reason, .. } if matches!(reason, weiss_core::events::ModifierRemoveReason::TargetLeftStage)
    ));
    assert!(modifier_removed);
    assert!(env.state.players[0].stage[0].card.is_none());
    assert!(env.state.players[0]
        .hand
        .iter()
        .any(|c| c.id == CARD_CONTINUOUS_SELF_BOUNCE));
}
