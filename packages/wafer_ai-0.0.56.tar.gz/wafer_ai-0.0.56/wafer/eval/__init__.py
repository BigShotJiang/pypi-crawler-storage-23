"""Unified eval primitive: Scorer -> CodeScorer + TrajectoryScorer + discovery.

Public API for eval authors:
    Scorer           Abstract base for all scorers
    CodeScorer       Scores code artifacts on disk (agent tool, runs on work_dir)
    TrajectoryScorer Scores agent trajectory/conversation (LLM judge, post-hoc)
    Score            Return type from scoring
    Metric           Individual metric inside a Score
    TurnScore        A Score anchored to a specific trajectory message
    load_tasks       Load task data from JSON file or list
    load_code_scorer Load a code scorer by builtin name or .py file path
    list_code_scorers List all builtin code scorer names
    extract_eval_result  Parse EVAL_RESULT_JSON: prefix from stdout
    extract_turn_scores  Scan trajectory for per-turn Score JSONs
    best_turn_score      Highest-reward TurnScore from a tuple
"""
from __future__ import annotations

import importlib
import importlib.util
import os
from pathlib import Path
from typing import Any

from wafer.core.rollouts.dtypes import Metric, Score, TurnScore
from wafer.core.rollouts.eval_helpers import load_tasks
from wafer.core.rollouts.scoring import best_turn_score, extract_turn_scores
from wafer.eval.sandbox_runner import sandbox_run

__all__ = [
    "Scorer",
    "CodeScorer",
    "TrajectoryScorer",
    "Score",
    "Metric",
    "TurnScore",
    "extract_eval_result",
    "extract_turn_scores",
    "best_turn_score",
    "load_tasks",
    "load_code_scorer",
    "list_code_scorers",
    "sandbox_run",
]


EVAL_RESULT_PREFIX = "EVAL_RESULT_JSON:"


def extract_eval_result(stdout: str) -> str:
    """Extract JSON from bench script stdout that uses EVAL_RESULT_JSON: prefix."""
    for line in stdout.splitlines():
        if line.startswith(EVAL_RESULT_PREFIX):
            return line[len(EVAL_RESULT_PREFIX):]
    assert False, f"No {EVAL_RESULT_PREFIX} line found in output:\n{stdout[-500:]}"


class Scorer:
    """Abstract base for all scorers.

    Two concrete subclasses:
      CodeScorer       — evaluates code artifacts on disk (work_dir)
      TrajectoryScorer — evaluates agent conversation (sample)
    """

    async def __call__(self, *args: Any, **kwargs: Any) -> Score:
        raise NotImplementedError


class CodeScorer(Scorer):
    """Scores code artifacts on disk — compiled kernels, benchmark results, etc.

    Used by agent via eval tool. Subclasses implement __call__(work_dir, ...) -> Score.
    Simple code scorers can be plain async functions instead of subclasses.
    """

    async def __call__(
        self,
        work_dir: Path,
        *,
        baseline_dir: Path | None = None,
        on_chunk: Any = None,
    ) -> Score:
        raise NotImplementedError


class TrajectoryScorer(Scorer):
    """Scores agent trajectory/conversation via LLM judge or heuristic analysis.

    Used by eval harness post-run. Subclasses implement __call__(sample, ...) -> Score.
    Simple trajectory scorers can be plain async functions instead of subclasses.
    """

    async def __call__(
        self,
        sample: Any,
        *,
        on_chunk: Any = None,
    ) -> Score:
        raise NotImplementedError


_BUILTIN_CODE_SCORERS: dict[str, str] = {
    "kernelbench": "wafer.eval.scorers.kernelbench",
    "gpumode": "wafer.eval.scorers.gpumode",
    "aiter": "wafer.eval.scorers.aiter",
    "hipblaslt-gemm": "wafer.eval.scorers.hipblaslt_gemm",
    "megakernel": "wafer.eval.scorers.megakernel",
}


def load_code_scorer(
    name: str,
    *,
    resolve_from_dir: str | os.PathLike | None = None,
) -> CodeScorer:
    """Load a code scorer by built-in name or file path.

    Discovery order:
    1. A `score` async function in the module
    2. A CodeScorer subclass in the module (instantiated)

    When name is a .py path, resolve it relative to resolve_from_dir.
    """
    if name in _BUILTIN_CODE_SCORERS:
        module = importlib.import_module(_BUILTIN_CODE_SCORERS[name])
    elif name.endswith(".py"):
        if resolve_from_dir is not None:
            path = (Path(resolve_from_dir) / name).resolve()
        else:
            path = Path(name).expanduser().resolve()
        assert path.is_file(), (
            f"CodeScorer file not found: {name!r} (resolved: {path}). "
            f"Ensure the .py file exists."
        )
        spec = importlib.util.spec_from_file_location("user_scorer", str(path))
        assert spec is not None, f"Failed to load spec from {path}"
        assert spec.loader is not None, f"No loader for {path}"
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
    else:
        assert False, (
            f"Unknown code scorer: {name!r}. "
            f"Built-in: {list(_BUILTIN_CODE_SCORERS)}. Or pass a .py file path."
        )

    if hasattr(module, "score") and callable(module.score):
        return _wrap_function_code_scorer(module.score)

    for attr_name in dir(module):
        attr = getattr(module, attr_name)
        if isinstance(attr, type) and issubclass(attr, CodeScorer) and attr is not CodeScorer:
            return attr()

    assert False, (
        f"No code scorer found in {name}. "
        f"Define an async `score(work_dir, ...)` function or a CodeScorer subclass."
    )


def _wrap_function_code_scorer(fn: Any) -> CodeScorer:
    """Wrap a plain async score() function as a CodeScorer instance."""

    class _FnScorer(CodeScorer):
        async def __call__(
            self,
            work_dir: Path,
            *,
            baseline_dir: Path | None = None,
            on_chunk: Any = None,
        ) -> Score:
            import inspect
            sig = inspect.signature(fn)
            kwargs: dict[str, Any] = {}
            if "baseline_dir" in sig.parameters:
                kwargs["baseline_dir"] = baseline_dir
            if "on_chunk" in sig.parameters:
                kwargs["on_chunk"] = on_chunk
            return await fn(work_dir, **kwargs)

    _FnScorer.__name__ = fn.__name__
    _FnScorer.__qualname__ = fn.__qualname__
    return _FnScorer()


def list_code_scorers() -> list[str]:
    """List all built-in code scorer names."""
    return sorted(_BUILTIN_CODE_SCORERS.keys())
