"""CLI for problem set management (KernelBench, GPUMode)."""

import typer

from wafer.cli.problems import (
    download_problems,
    list_problem_sets,
    list_problems,
)

problems_app = typer.Typer(
    help="Download and list kernel optimization problems for wafer tool eval",
)


@problems_app.command("list")
def problems_list(
    name: str | None = typer.Argument(
        None,
        help="Problem set name (kernelbench, gpumode). Omit to list all sets.",
    ),
) -> None:
    """List problem sets or problems within a set.

    Examples:
        wafer tool problems list              # List all problem sets and status
        wafer tool problems list kernelbench  # List problems in kernelbench (requires download first)
    """
    if name is None:
        list_problem_sets(verbose=True)
        return
    if name not in ("kernelbench", "gpumode"):
        typer.echo(f"Error: Unknown problem set '{name}'. Use kernelbench or gpumode.", err=True)
        raise typer.Exit(1)
    try:
        list_problems(name, verbose=True)
    except ValueError as e:
        typer.echo(str(e), err=True)
        raise typer.Exit(1)


@problems_app.command("download")
def problems_download(
    name: str = typer.Argument(
        ...,
        help="Problem set name: kernelbench or gpumode",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Re-download even if already cached",
    ),
) -> None:
    """Download a problem set to ~/.cache/wafer/problems/.

    Examples:
        wafer tool problems download kernelbench
        wafer tool problems download gpumode --force
    """
    if name not in ("kernelbench", "gpumode"):
        typer.echo(f"Error: Unknown problem set '{name}'. Use kernelbench or gpumode.", err=True)
        raise typer.Exit(1)
    try:
        path = download_problems(name, force=force, verbose=True)
        typer.echo(f"\nPath: {path}")
        typer.echo("Use with: wafer tool eval --task kernelbench --after <problem_dir>")
    except ValueError as e:
        typer.echo(str(e), err=True)
        raise typer.Exit(1)
