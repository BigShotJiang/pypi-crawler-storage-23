"""External tool dependency registry and utilities.

Provides DEPS_REGISTRY for checking whether GPU profiling tools (ncu, nsys,
rocprof, etc.) are installed. Used by `wafer status` and by profiling tool
commands that emit hints when a tool is missing.
"""
from __future__ import annotations

import shutil
import sys
from dataclasses import dataclass


@dataclass(frozen=True)
class DepSpec:
    """Specification for an external dependency wafer integrates with."""

    name: str
    check_cmd: str
    install_cmd: str | None
    platform: str  # "amd", "nvidia", or "any"
    description: str


DEPS_REGISTRY: dict[str, DepSpec] = {
    "ncu": DepSpec(
        name="ncu",
        check_cmd="ncu",
        install_cmd="sudo apt install -y nvidia-cuda-toolkit",
        platform="nvidia",
        description="NVIDIA Nsight Compute (part of CUDA toolkit)",
    ),
    "nsys": DepSpec(
        name="nsys",
        check_cmd="nsys",
        install_cmd="sudo apt install -y nvidia-cuda-toolkit",
        platform="nvidia",
        description="NVIDIA Nsight Systems (part of CUDA toolkit)",
    ),
    "nvcc": DepSpec(
        name="nvcc",
        check_cmd="nvcc",
        install_cmd="sudo apt install -y nvidia-cuda-toolkit",
        platform="nvidia",
        description="NVIDIA CUDA compiler",
    ),
    "rocprof": DepSpec(
        name="rocprof",
        check_cmd="rocprof",
        install_cmd=None,
        platform="amd",
        description="AMD kernel profiling (part of ROCm base install)",
    ),
    "rocprof-compute": DepSpec(
        name="rocprof-compute",
        check_cmd="rocprof-compute",
        install_cmd="sudo apt install -y rocprofiler-compute && python3 -m pip install -r /opt/rocm/libexec/rocprofiler-compute/requirements.txt",
        platform="amd",
        description="AMD GPU profiling (roofline, memory) - requires ROCm >= 6.3",
    ),
    "rocprof-systems": DepSpec(
        name="rocprof-systems",
        check_cmd="rocprof-systems",
        install_cmd="sudo apt install -y rocprofiler-systems && python3 -m pip install -r /opt/rocm/libexec/rocprofiler-systems/requirements.txt",
        platform="amd",
        description="AMD system-wide tracing - requires ROCm >= 6.3",
    ),
    "rocprofv3": DepSpec(
        name="rocprofv3",
        check_cmd="rocprofv3",
        install_cmd=None,
        platform="amd",
        description="AMD ROCprofiler SDK v3 (part of ROCm >= 6.0 base install)",
    ),
    "gh": DepSpec(
        name="gh",
        check_cmd="gh",
        install_cmd="brew install gh" if sys.platform == "darwin" else "sudo apt install -y gh",
        platform="any",
        description="GitHub CLI",
    ),
}


def check_dep(name: str) -> bool:
    """Check if a single dep is installed locally.

    For nvidia tools, also searches /usr/local/cuda/bin and
    /usr/local/cuda-*/bin/ (glob catches any installed CUDA version).
    """
    spec = DEPS_REGISTRY[name]
    if shutil.which(spec.check_cmd) is not None:
        return True
    if spec.platform == "nvidia":
        import glob as _glob
        from pathlib import Path
        if Path(f"/usr/local/cuda/bin/{spec.check_cmd}").exists():
            return True
        if _glob.glob(f"/usr/local/cuda-*/bin/{spec.check_cmd}"):
            return True
    return False


def check_all_deps() -> dict[str, bool]:
    """Check all deps, return {name: installed}."""
    return {name: check_dep(name) for name in DEPS_REGISTRY}


def deps_hint() -> str:
    """Return hint when a tool is not found."""
    return "Tip: Run 'wafer status' to check tool dependencies."
