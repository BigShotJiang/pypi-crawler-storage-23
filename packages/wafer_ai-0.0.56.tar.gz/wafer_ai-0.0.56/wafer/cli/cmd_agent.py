# ruff: noqa: PLR0913
"""Agent command and cloud/template helper functions.

Extracted from app.py to reduce module size.
All agent-related helpers live here; the command is registered
via ``register_agent_command(app)``.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import TYPE_CHECKING

import httpx
import typer

if TYPE_CHECKING:
    from wafer.cli.agent_config import AgentConfig


# ---------------------------------------------------------------------------
# Agent template discovery helpers
# ---------------------------------------------------------------------------


def _format_template_variable(
    var_name: str, defaults: dict[str, str]
) -> str | None:
    """Format a single template variable for display.
    Returns None for internal/auto-computed variables (e.g., target_flag).
    """
    # Skip internal auto-computed variables
    # why: these are derived from other args at runtime, not user-facing
    internal_suffixes = ("_flag", "_upper")
    if any(var_name.endswith(suffix) for suffix in internal_suffixes):
        return None
    default = defaults.get(var_name, "")
    if default:
        return f"{var_name} (default: {default})"
    return f"{var_name}"


def _format_template_entry(
    name: str,
    config: AgentConfig,
) -> list[str]:
    """Format a single template for the --list-templates display."""
    lines: list[str] = []
    description = config.description
    cloud_only = config.cloud_only
    cloud_tag = " [cloud-only]" if cloud_only else ""
    lines.append(f"  {name:<24}{description}{cloud_tag}")
    raw_variables = config.get_variables()
    variables = list(dict.fromkeys(raw_variables))
    defaults = config.defaults
    # Show user-facing variables
    formatted_vars = []
    for v in variables:
        fmt = _format_template_variable(v, defaults)
        if fmt is not None:
            formatted_vars.append(fmt)
    if formatted_vars:
        lines.append(f"    Args: {', '.join(formatted_vars)}")
    # Generate example usage
    # why: quote values containing spaces so copy-paste into shell works
    example_args = ""
    for v in variables:
        internal_suffixes = ("_flag", "_upper")
        if any(v.endswith(suffix) for suffix in internal_suffixes):
            continue
        default = defaults.get(v, "")
        if default:
            arg = f"{v}={default}"
            # Shell-quote if value contains spaces or shell metacharacters
            if " " in default or "'" in default or '"' in default:
                example_args += f' --args "{arg}"'
            else:
                example_args += f" --args {arg}"
        else:
            example_args += f" --args {v}=<value>"
    lines.append(f"    Example: wafer agent -t {name}{example_args} \"<prompt>\"")
    return lines


def _handle_list_templates() -> None:
    """Display all available templates and exit.
    Runs before auth or heavy imports — only needs the template loader.
    """
    from wafer.core.rollouts.templates.loader import load_all_templates

    results = load_all_templates()
    assert isinstance(results, list)

    typer.echo("Available agent templates:\n")
    for name, config, err in results:
        if err or config is None:
            typer.echo(f"  {name:<24}(failed to load: {err})")
            typer.echo()
            continue
        for line in _format_template_entry(name, config):
            typer.echo(line)
        typer.echo()

    typer.echo("Use --args KEY=VALUE to pass template arguments (can be repeated).")
    typer.echo("Example: wafer agent -t default \"Optimize this GEMM kernel\"")


def _validate_template_name(template_name: str) -> None:
    """Validate that a template name exists. Exits with helpful error if not.
    Runs before auth or heavy imports — uses lightweight file listing only.
    """
    from pathlib import Path

    from wafer.cli.agent_config import get_bundled_template_path, list_bundled_templates

    if get_bundled_template_path(template_name) is not None:
        return
    if Path(template_name).expanduser().exists():
        return
    all_available = sorted(list_bundled_templates())
    available_str = ", ".join(all_available) if all_available else "(none found)"
    typer.echo(
        f"Error: Unknown template '{template_name}'.\n"
        f"Available: {available_str}\n"
        f"Run 'wafer agent --list-templates' for details.",
        err=True,
    )
    raise typer.Exit(1)


def _agent_resolve_input(
    prompt: str | None, json_output: bool,
) -> tuple[str | None, bool]:
    actual_prompt = prompt
    if not sys.stdin.isatty() and not actual_prompt:
        stdin_input = sys.stdin.read().strip()
        if stdin_input:
            actual_prompt = stdin_input
    has_tty = sys.stdin.isatty() and sys.stdout.isatty()
    use_tui = has_tty and not json_output
    return actual_prompt, use_tui


def _agent_parse_template_args(template_args: list[str] | None) -> dict[str, str] | None:
    assert template_args is None or isinstance(template_args, list), "template_args must be a list or None"
    assert template_args is None or all(isinstance(a, str) for a in template_args), "all template_args must be strings"

    if not template_args:
        return None
    parsed: dict[str, str] = {}
    for arg in template_args:
        if "=" not in arg:
            typer.echo(f"Invalid --args format: {arg!r}. Use KEY=VALUE", err=True)
            raise typer.Exit(1)
        key, value = arg.split("=", 1)
        parsed[key] = os.path.expanduser(value)
    return parsed


# ---------------------------------------------------------------------------
# Cloud agent helpers
# ---------------------------------------------------------------------------


def _resolve_repo_to_clone_url(
    api_base: str, headers: dict[str, str], repo_spec: str,
) -> tuple[str | None, str | None]:
    """Resolve owner/repo to clone_url via GET /v1/github/repos.

    Returns (clone_url, error). Exactly one is non-None:
    - (clone_url, None) on success
    - (None, None) if repo_spec is already a URL (no resolution needed)
    - (None, error_msg) on API failure or repo not found
    """
    if "/" not in repo_spec or repo_spec.startswith("http") or repo_spec.endswith(".git"):
        return None, None
    import httpx

    try:
        resp = httpx.get(f"{api_base}/v1/github/repos", headers=headers, timeout=30.0)
    except httpx.ConnectError:
        return None, f"Cannot reach API at {api_base} to resolve repo '{repo_spec}'."
    except httpx.TimeoutException:
        return None, f"Timed out reaching API at {api_base} to resolve repo '{repo_spec}'."
    if resp.status_code != 200:
        return None, f"GitHub repos API returned {resp.status_code}. Check your connection or run 'wafer login'."
    data = resp.json()
    repos = data.get("repos", [])
    for r in repos:
        if r.get("full_name") == repo_spec:
            return r.get("clone_url"), None
    return None, f"Repo '{repo_spec}' not in your GitHub App installations. Run 'wafer settings github connect'."


def _cloud_auth_headers() -> tuple[str, dict[str, str]]:
    """Return (api_base, headers) for cloud agent API calls.

    Resolution order: WAFER_AUTH_TOKEN env var > ~/.wafer/credentials.json (from wafer login).
    API URL: WAFER_API_URL env var > config (get_api_url) for environment (local/staging/prod).
    Exits cleanly with sign-in instructions if neither is available.
    """
    from .auth import get_valid_token
    from .global_config import get_api_url

    api_base = os.environ.get("WAFER_API_URL") or get_api_url()
    auth_token = os.environ.get("WAFER_AUTH_TOKEN") or get_valid_token()
    if not auth_token:
        typer.echo(
            "\nNot signed in. Run `wafer login` first, or set WAFER_AUTH_TOKEN.\n",
            err=True,
        )
        raise typer.Exit(1)
    return api_base, {"Authorization": f"Bearer {auth_token}"}


def _get_app_url(session_id: str) -> str | None:
    """Build the wafer-app URL for a session. Local → localhost:3001, otherwise → app.wafer.ai."""
    if not session_id:
        return None
    from .global_config import get_api_url
    api_url = get_api_url()
    if "localhost" in api_url or "127.0.0.1" in api_url:
        base = "http://localhost:3001"
    else:
        base = "https://app.wafer.ai"
    return f"{base}/agent?session={session_id}"


def _render_sse_event(event: dict, json_output: bool) -> None:
    """Render a single SSE event to the terminal."""
    etype = event.get("type")

    if json_output:
        print(json.dumps(event), flush=True)
        return

    if etype == "session_started":
        sid = event.get("session_id", "")
        short_id = sid[:8] if sid else ""
        app_url = _get_app_url(sid)
        link = f"\x1b]8;;{app_url}\x1b\\{app_url}\x1b]8;;\x1b\\" if app_url else ""
        sys.stderr.write(f"\x1b[2mSession {short_id} — agent running\x1b[0m\n")
        if link:
            sys.stderr.write(f"\x1b[2m  {link}\x1b[0m\n")
    elif etype == "text_delta":
        sys.stdout.write(event.get("delta", ""))
        sys.stdout.flush()
    elif etype == "thinking_delta":
        sys.stderr.write(f"\x1b[2m{event.get('delta', '')}\x1b[0m")
        sys.stderr.flush()
    elif etype == "tool_call_start":
        sys.stdout.flush()
        sys.stderr.write(f"\n\x1b[36m> {event.get('name', '')}\x1b[0m\n")
    elif etype == "tool_call_delta":
        pass
    elif etype == "tool_result_delta":
        delta = event.get("delta", "")
        if delta:
            sys.stderr.write(f"\x1b[2m{delta}\x1b[0m")
            sys.stderr.flush()
    elif etype == "tool_call_end":
        args = event.get("args", {})
        if args:
            for k, v in args.items():
                val = str(v)[:_MAX_ARG_PREVIEW_LENGTH]
                sys.stderr.write(f"  \x1b[2m{k}: {val}\x1b[0m\n")
    elif etype == "tool_result":
        raw_content = event.get("content", "")
        if not raw_content and event.get("error"):
            raw_content = event["error"]
        truncated = len(raw_content) > _MAX_CONTENT_PREVIEW_LENGTH
        content = raw_content[:_MAX_CONTENT_PREVIEW_LENGTH]
        if truncated:
            content += f"... ({len(raw_content) - _MAX_CONTENT_PREVIEW_LENGTH} chars truncated)"
        if event.get("is_error"):
            sys.stderr.write(f"  \x1b[31m[fail] {content}\x1b[0m\n")
        else:
            sys.stderr.write(f"  \x1b[2m{content}\x1b[0m\n")
    elif etype == "turn_end":
        pass
    elif etype == "session_complete":
        sys.stdout.flush()
        sys.stdout.write("\n")
        sys.stdout.flush()
        sys.stderr.write("\x1b[2mDone.\x1b[0m\n")
    elif etype == "error":
        error_msg = event.get("error", "unknown")
        session_id = event.get("session_id", "")
        parts = [f"\x1b[31mError: {error_msg}\x1b[0m"]
        if session_id:
            parts.append(f"\x1b[2m  session: {session_id}\x1b[0m")
        sys.stderr.write("\n".join(parts) + "\n")


def _cloud_agent_404_error(api_base: str, json_output: bool) -> None:
    """Emit helpful error when cloud agent endpoint returns 404."""
    msg = (
        f"Cloud agent endpoint not found (404).\n"
        f"  API URL: {api_base}\n"
        "  Ensure wafer-api is running and WAFER_API_URL points to a deployment with /v1/cloud-agent routes."
    )
    if json_output:
        from .output import json_error
        typer.echo(json_error(msg))
    else:
        typer.echo(msg, err=True)
    raise typer.Exit(1)


def _cloud_agent_api_error(resp: httpx.Response, operation: str, json_output: bool) -> None:
    """Emit error for non-200 cloud agent API response."""
    status = resp.status_code
    text = resp.text
    _cloud_agent_api_error_raw(status, text, operation, json_output)


def _cloud_agent_api_error_raw(status: int, body: str, operation: str, json_output: bool) -> None:
    """Emit error for cloud agent API failure."""
    msg = f"Cloud agent {operation} failed: {status} {body[:500]}"
    if json_output:
        from .output import json_error
        typer.echo(json_error(msg))
    else:
        typer.echo(f"Error: {msg}", err=True)
    raise typer.Exit(1)


_MAX_UPLOAD_SIZE_MB = 100
_MAX_ARG_PREVIEW_LENGTH = 200
_MAX_CONTENT_PREVIEW_LENGTH = 500
_CLOUD_AGENT_TIMEOUT_SECONDS = 7200


def _create_workspace_tarball(dir_path: Path, out_path: Path) -> int:
    """Create tarball of dir_path respecting .gitignore. Returns size in bytes.

    Uses git archive when in git repo; else pathspec + tarfile.
    Excludes .git, node_modules, __pycache__, .venv, and .gitignore-listed paths.
    """
    import subprocess
    import tarfile

    dir_path = dir_path.resolve()
    assert dir_path.is_dir(), f"Not a directory: {dir_path}"
    git_dir = dir_path / ".git"
    if git_dir.exists():
        result = subprocess.run(
            ["git", "archive", "--format=tar.gz", f"--output={out_path}", "HEAD"],
            cwd=dir_path,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            typer.echo(f"git archive failed: {result.stderr}", err=True)
            raise typer.Exit(1)
        return out_path.stat().st_size

    import pathspec

    gitignore_path = dir_path / ".gitignore"
    spec: pathspec.PathSpec
    if gitignore_path.exists():
        with open(gitignore_path) as f:
            spec = pathspec.PathSpec.from_lines("gitwildmatch", f)
    else:
        spec = pathspec.PathSpec.from_lines("gitwildmatch", [])

    default_excludes = {".git", "node_modules", "__pycache__", ".venv", ".env"}
    excluded = set(default_excludes)

    def _matches(path: str) -> bool:
        rel = path.replace("\\", "/")
        if any(rel.startswith(ex + "/") or rel == ex for ex in excluded):
            return True
        return spec.match_file(rel)

    with tarfile.open(out_path, "w:gz") as tar:
        for root, _dirs, files in os.walk(dir_path, followlinks=True):
            for fname in files:
                entry = Path(root) / fname
                rel = entry.relative_to(dir_path).as_posix()
                if _matches(rel):
                    continue
                tar.add(entry, arcname=rel)

    return out_path.stat().st_size


def _handle_sandbox_agent(
    prompt: str,
    sandbox_id: str,
    template: str,
    json_output: bool,
) -> None:
    """Run agent inside a sandbox on a GPU target via direct SSH streaming.

    SSHs to the target owning the sandbox and runs `wafer agent` with
    --output-format stream-json. Streams NDJSON output back and renders
    events locally. Passes auth/API env vars so the subagent tool works.
    """
    import shlex

    from wafer.cli.sandbox_cli import _get_ssh_creds, _run_async
    from wafer.cli.sandboxes_api import db_get_sandbox, db_touch_sandbox

    row = db_get_sandbox(sandbox_id)
    assert row is not None, (
        f"Sandbox '{sandbox_id}' not found or expired. "
        f"Run: wafer sandbox list"
    )
    target_name = row["target_name"]
    timeout_hours = row.get("timeout_hours", 4)

    ssh_target, ssh_key = _get_ssh_creds(target_name)
    api_base, headers = _cloud_auth_headers()

    import httpx

    resp = httpx.post(
        f"{api_base}/v1/cloud-agent/mint-token",
        headers=headers,
        timeout=30.0,
    )
    if resp.status_code != 200:
        _cloud_agent_api_error(resp, "mint service token", json_output)
        return
    mint_data = resp.json()
    service_token = mint_data["token"]
    target_api_url = mint_data.get("api_url", api_base)

    env_vars = {
        "WAFER_AUTH_TOKEN": service_token,
        "WAFER_API_URL": target_api_url,
        "WAFER_TARGET_NAME": target_name,
    }
    env_prefix = " ".join(f"export {k}={shlex.quote(v)};" for k, v in env_vars.items())
    agent_cmd = (
        f"wafer agent -t {shlex.quote(template)} "
        f"--json "
        f"{shlex.quote(prompt)}"
    )
    # bash -l -c ensures login shell so ~/.local/bin is in PATH
    inner_cmd = f"{env_prefix} {agent_cmd}"
    full_cmd = f"bash -l -c {shlex.quote(inner_cmd)}"

    if not json_output:
        sys.stderr.write(
            f"\x1b[2mRunning agent in sandbox {sandbox_id} on {target_name}...\x1b[0m\n"
        )
        sys.stderr.flush()

    from wafer.core.async_ssh import AsyncSSHClient

    async def _stream():
        async with AsyncSSHClient(ssh_target, ssh_key) as client:
            async for line in client.exec_stream(full_cmd, allocate_pty=False):
                stripped = line.strip()
                if not stripped:
                    continue
                try:
                    event = json.loads(stripped)
                except json.JSONDecodeError:
                    continue
                etype = event.get("type")
                if etype in ("assistant", "system", "result"):
                    continue
                _render_sse_event(event, json_output)
        db_touch_sandbox(sandbox_id, timeout_hours)

    _run_async(_stream)


_MAX_PULL_FILE_SIZE = 300_000_000  # 300MB per file


def _handle_pull_files(
    api_base: str,
    headers: dict[str, str],
    session_id: str,
    out_dir: Path | None,
    json_output: bool,
) -> int:
    """Download workspace files from a cloud agent session to local disk."""
    import urllib.parse

    import httpx

    dest = out_dir or Path(f"./session-{session_id[:8]}")

    resp = httpx.get(
        f"{api_base}/v1/cloud-agent/sessions/{session_id}/files",
        headers=headers,
        timeout=30.0,
    )
    if resp.status_code == 404:
        _cloud_agent_404_error(api_base, json_output)
        return 1
    if resp.status_code != 200:
        _cloud_agent_api_error(resp, "list session files", json_output)
        return 1

    data = resp.json()
    files = [f for f in data.get("files", []) if not f.get("is_dir")]
    source = data.get("source", "unknown")

    if not files:
        if json_output:
            print(json.dumps({"files": [], "source": source, "dest": str(dest)}))
        else:
            print("No files in session workspace.")
        return 0

    pullable = [f for f in files if f.get("size", 0) <= _MAX_PULL_FILE_SIZE]
    skipped = len(files) - len(pullable)

    pulled: list[dict[str, object]] = []
    errors: list[str] = []
    for f in pullable:
        path = f["path"]
        encoded = "/".join(urllib.parse.quote(seg, safe="") for seg in path.split("/"))
        file_resp = httpx.get(
            f"{api_base}/v1/cloud-agent/sessions/{session_id}/files/{encoded}",
            headers=headers,
            timeout=30.0,
        )
        if file_resp.status_code != 200:
            errors.append(f"{path}: HTTP {file_resp.status_code}")
            continue

        file_data = file_resp.json()
        content = file_data.get("content", "")
        encoding = file_data.get("encoding", "utf-8")

        file_dest = dest / path
        file_dest.parent.mkdir(parents=True, exist_ok=True)
        if encoding == "base64":
            import base64 as b64mod
            file_dest.write_bytes(b64mod.b64decode(content))
        else:
            file_dest.write_text(content, encoding="utf-8")
        pulled.append({"path": path, "size": f.get("size", 0)})

    if json_output:
        print(json.dumps({
            "dest": str(dest),
            "source": source,
            "pulled": pulled,
            "errors": errors,
            "skipped_oversized": skipped,
        }, indent=2))
    else:
        print(f"Pulled {len(pulled)} file(s) from session {session_id[:8]} ({source}) -> {dest}/")
        for p in pulled:
            print(f"  {p['path']} ({p['size']}B)")
        if skipped:
            print(f"  ({skipped} file(s) skipped — over {_MAX_PULL_FILE_SIZE // 1_000_000}MB)")
        if errors:
            print(f"  {len(errors)} error(s):")
            for e in errors:
                print(f"    {e}")

    if not pulled:
        return 1
    return 0


def _handle_cloud_agent(
    prompt: str,
    cloud_repo: str | None,
    cloud_dir: Path | None,
    config: str,
    json_output: bool,
    list_sessions: bool,
    get_session: str | None,
    pull_files: str | None,
    pull_out: Path | None,
    session_id: str | None,
    target_name: str | None = None,
) -> None:
    """Dispatch to cloud agent API.

    Calls /v1/cloud-agent/run and streams SSE events to the terminal.
    Read-only operations (list/get) use REST endpoints.
    """
    import httpx

    api_base, headers = _cloud_auth_headers()

    if list_sessions:
        resp = httpx.get(f"{api_base}/v1/cloud-agent/sessions", headers=headers, timeout=30.0)
        if resp.status_code == 404:
            _cloud_agent_404_error(api_base, json_output)
            return
        if resp.status_code != 200:
            _cloud_agent_api_error(resp, "list sessions", json_output)
            return
        data = resp.json()
        if json_output:
            print(json.dumps(data, indent=2))
        else:
            sessions = data.get("sessions", [])
            if not sessions:
                print("No sessions found.")
            else:
                print(f"  {'ID':36s}  {'STATUS':12s}  {'MODEL':30s}  PROMPT")
                print(f"  {'─' * 36}  {'─' * 12}  {'─' * 30}  {'─' * 40}")
                for s in sessions:
                    print(f"  {s['id']}  {s['status']:12s}  {s['model']:30s}  {s['prompt'][:60]}")
        return

    if get_session:
        resp = httpx.get(
            f"{api_base}/v1/cloud-agent/sessions/{get_session}", headers=headers, timeout=30.0,
        )
        if resp.status_code == 404:
            _cloud_agent_404_error(api_base, json_output)
            return
        if resp.status_code != 200:
            _cloud_agent_api_error(resp, f"get session {get_session}", json_output)
            return
        data = resp.json()
        if json_output:
            print(json.dumps(data, indent=2))
        else:
            print(f"Session: {data['id']}")
            print(f"Status:  {data['status']}")
            print(f"Model:   {data['model']}")
            print(f"Mode:    {data['mode']}")
            messages = data.get("messages", [])
            print(f"Messages: {len(messages)}")
            if messages:
                print()
                for msg in messages:
                    role = msg.get("role", "?")
                    raw_content = msg.get("content", "")
                    text = raw_content.get("content", "") if isinstance(raw_content, dict) else str(raw_content)
                    prefix = "\x1b[36m" if role == "assistant" else "\x1b[33m"
                    display = text[:500] if text else "(tool calls only)"
                    print(f"{prefix}[{role}]\x1b[0m {display}")
        return

    if pull_files:
        rc = _handle_pull_files(api_base, headers, pull_files, pull_out, json_output)
        if rc != 0:
            raise typer.Exit(code=rc)
        return

    if not prompt:
        typer.echo(
            "Error: prompt is required for --cloud (use --list-sessions, --get-session, or --pull-files for read-only operations)",
            err=True,
        )
        raise typer.Exit(1)

    if cloud_dir is not None and cloud_repo:
        typer.echo("Error: --dir and --repo are mutually exclusive.", err=True)
        raise typer.Exit(1)

    config_workspace_path: str | None = None
    inline_config_dict: dict[str, object] | None = None
    config_path: Path | None = None
    if config:
        from wafer.cli.agent_config import get_bundled_template_path, load_agent_config

        cfg = Path(config).resolve()
        if cfg.exists() and cfg.is_file() and cfg.suffix == ".toml":
            if cloud_dir is not None:
                config_workspace_path = ".wafer_agent.toml"
                config_path = cfg
            else:
                file_config = load_agent_config(cfg)
                inline_config_dict = file_config.to_dict()
        else:
            template_path = get_bundled_template_path(config)
            assert template_path is not None, f"Template '{config}' not found"
            file_config = load_agent_config(template_path)
            inline_config_dict = file_config.to_dict()

    workspace_storage_path: str | None = None
    if cloud_dir is not None:
        import shutil
        import tempfile

        dir_resolved = cloud_dir.resolve()
        if not dir_resolved.is_dir():
            typer.echo(f"Error: --dir path is not a directory: {cloud_dir}", err=True)
            raise typer.Exit(1)
        if not json_output:
            sys.stderr.write("\x1b[2mCreating workspace tarball...\x1b[0m\n")
            sys.stderr.flush()
        with tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False) as tmp:
            tmp_path = Path(tmp.name)
        try:
            if config_path is not None:
                with tempfile.TemporaryDirectory() as td:
                    work_dir = Path(td)
                    shutil.copytree(dir_resolved, work_dir, symlinks=False, dirs_exist_ok=True)
                    (work_dir / ".wafer_agent.toml").write_text(config_path.read_text())
                    tarball_size = _create_workspace_tarball(work_dir, tmp_path)
            else:
                tarball_size = _create_workspace_tarball(dir_resolved, tmp_path)
            size_mb = tarball_size / (1024 * 1024)
            if size_mb > _MAX_UPLOAD_SIZE_MB:
                typer.echo(
                    f"Error: Tarball size {size_mb:.1f}MB exceeds {_MAX_UPLOAD_SIZE_MB}MB limit.",
                    err=True,
                )
                raise typer.Exit(1)
            if not json_output:
                sys.stderr.write(f"\x1b[2mUploading workspace ({size_mb:.1f}MB)...\x1b[0m\n")
                sys.stderr.flush()
            resp = httpx.post(
                f"{api_base}/v1/cloud-agent/upload-url",
                headers=headers,
                timeout=30.0,
            )
            if resp.status_code != 200:
                _cloud_agent_api_error(resp, "get upload URL", json_output)
                return
            upload_data = resp.json()
            upload_url = upload_data.get("upload_url")
            workspace_storage_path = upload_data.get("storage_path")
            if not upload_url or not workspace_storage_path:
                typer.echo("Error: Invalid upload-url response.", err=True)
                raise typer.Exit(1)
            with open(tmp_path, "rb") as f:
                put_resp = httpx.put(upload_url, content=f.read(), timeout=120.0)
            if put_resp.status_code not in (200, 201, 204):
                _cloud_agent_api_error_raw(
                    put_resp.status_code, put_resp.text, "upload workspace", json_output,
                )
                return
            if not json_output:
                sys.stderr.write(f"\x1b[2mUpload complete ({size_mb:.1f}MB).\x1b[0m\n")
                sys.stderr.flush()
        finally:
            tmp_path.unlink(missing_ok=True)

    if not cloud_repo and workspace_storage_path is None and not json_output:
        sys.stderr.write(
            "\x1b[2mNo repo specified — running in empty mode (no files in /workspace).\n"
            "  To include your code, use one of:\n"
            "    --repo owner/repo   Clone a GitHub repo into the cloud agent\n"
            "    --dir .             Upload current directory to the cloud agent\x1b[0m\n"
        )
        sys.stderr.flush()

    final_repo = cloud_repo
    if cloud_repo:
        clone_url, resolve_err = _resolve_repo_to_clone_url(api_base, headers, cloud_repo)
        if clone_url is not None:
            final_repo = clone_url
        elif resolve_err is not None:
            typer.echo(f"Error: {resolve_err}", err=True)
            raise typer.Exit(1)

    mode = "dir" if workspace_storage_path else ("repo" if final_repo else "empty")

    final_session_id: str | None = session_id
    if session_id == "last":
        resp = httpx.get(f"{api_base}/v1/cloud-agent/sessions", headers=headers, timeout=30.0)
        if resp.status_code == 404:
            _cloud_agent_404_error(api_base, json_output)
            return
        if resp.status_code != 200:
            _cloud_agent_api_error(resp, "list sessions", json_output)
            return
        sessions = resp.json().get("sessions", [])
        if not sessions:
            typer.echo(
                "Error: No sessions to resume. Use --resume <id> with a valid session ID.",
                err=True,
            )
            raise typer.Exit(1)
        final_session_id = sessions[0]["id"]

    body: dict[str, object] = {
        "prompt": prompt,
        "mode": mode,
        "repo_url": final_repo if mode == "repo" else None,
    }
    if inline_config_dict:
        body["inline_config"] = inline_config_dict
    volume_env = os.environ.get("WAFER_VOLUME_ENV")
    if volume_env:
        body["volume_env"] = volume_env
    if config_workspace_path:
        body["config_workspace_path"] = config_workspace_path
    if workspace_storage_path:
        body["workspace_storage_path"] = workspace_storage_path
    if final_session_id:
        body["session_id"] = final_session_id
    if target_name:
        body["target_name"] = target_name

    headers["Content-Type"] = "application/json"

    if not json_output:
        sys.stderr.write("\x1b[2mStarting cloud agent...\x1b[0m\n")
        sys.stderr.flush()

    _stream_session_id: str | None = None
    try:
        with httpx.stream(
            "POST",
            f"{api_base}/v1/cloud-agent/run",
            json=body,
            headers=headers,
            timeout=_CLOUD_AGENT_TIMEOUT_SECONDS,
        ) as response:
            if response.status_code == 404:
                _cloud_agent_404_error(api_base, json_output)
                return
            if response.status_code != 200:
                body_read = response.read().decode()
                _cloud_agent_api_error_raw(response.status_code, body_read, "start cloud agent", json_output)
                return
            from wafer.core.api_client import parse_sse_line
            for line in response.iter_lines():
                event = parse_sse_line(line)
                if event is None:
                    continue
                if event.data.get("type") == "session_started" and event.data.get("session_id"):
                    _stream_session_id = event.data["session_id"]
                _render_sse_event(event.data, json_output)
    except (httpx.RemoteProtocolError, httpx.ReadError, httpx.ConnectError, httpx.TimeoutException) as exc:
        hint = ""
        if _stream_session_id:
            hint = f"\n  Session {_stream_session_id[:8]} may still be running."
            hint += f"\n  Check: wafer agent --cloud --get-session {_stream_session_id}"
        if json_output:
            from .output import json_error
            typer.echo(json_error(f"Connection lost: {exc}{hint}"))
        else:
            typer.echo(f"\x1b[31mConnection lost: {exc}\x1b[0m{hint}", err=True)
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Command registration
# ---------------------------------------------------------------------------


def agent(  # noqa: PLR0913
    prompt: str | None = typer.Argument(
        None,
        help="Prompt to send (reads from stdin if not provided and not interactive)",
    ),
    resume: str | None = typer.Option(
        None,
        "--resume",
        "-r",
        help="Resume session by ID (or 'last' for most recent)",
        rich_help_panel="Session",
    ),
    list_sessions: bool = typer.Option(
        False,
        "--list-sessions",
        help="List recent sessions and exit",
        rich_help_panel="Session",
    ),
    get_session: str | None = typer.Option(
        None,
        "--get-session",
        help="Get session by ID and print details (use with --json for full messages)",
        rich_help_panel="Session",
    ),
    pull_files: str | None = typer.Option(
        None,
        "--pull-files",
        help="Download workspace files from a session to local directory",
        rich_help_panel="Session",
    ),
    pull_out: Path | None = typer.Option(
        None,
        "--out",
        "-o",
        path_type=Path,
        help="Output directory for --pull-files (default: ./session-<id>/)",
        rich_help_panel="Session",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output in JSON format (NDJSON streaming events)",
        rich_help_panel="Output",
    ),
    list_templates: bool = typer.Option(
        False,
        "--list-templates",
        help="List available templates with descriptions and args, then exit",
    ),
    template: str | None = typer.Option(
        None,
        "--template",
        "-t",
        help="Run with template (use --list-templates to see all available)",
    ),
    template_args: list[str] | None = typer.Option(
        None,
        "--args",
        help="Template variable (KEY=VALUE, can be repeated)",
    ),
    output_format: str | None = typer.Option(
        None,
        "--output-format",
        help="Output format: 'stream-json' (Claude Code-compatible NDJSON)",
        rich_help_panel="Output",
    ),
    cloud: bool = typer.Option(
        False,
        "--cloud",
        help="Run agent on remote server via cloud API",
        rich_help_panel="Cloud",
    ),
    cloud_repo: str | None = typer.Option(
        None,
        "--repo",
        help="Clone repo on cloud server (use with --cloud)",
        rich_help_panel="Cloud",
    ),
    cloud_dir: Path | None = typer.Option(
        None,
        "--dir",
        "-d",
        path_type=Path,
        help="Upload local directory to cloud agent (use with --cloud, e.g. --dir . for cwd, respects .gitignore)",
        rich_help_panel="Cloud",
    ),
    target: str | None = typer.Option(
        None,
        "--target",
        help="Run agent directly on a GPU target by name (use with --cloud)",
        rich_help_panel="Cloud",
    ),
    sandbox: str | None = typer.Option(
        None,
        "--sandbox",
        "-s",
        help="Run agent inside a sandbox on a GPU target (direct SSH, no API hop)",
        rich_help_panel="Sandbox",
    ),
) -> None:
    """AI assistant for GPU kernel development

    Examples:
        wafer agent                          # interactive TUI
        wafer agent "optimize this kernel"   # with initial prompt
        wafer agent --cloud -t default ...   # run on cloud
        wafer agent -s <sandbox-id> -t default "prompt"  # run in sandbox
    """
    if list_templates:
        _handle_list_templates()
        return

    if output_format is not None and output_format != "stream-json":
        typer.echo(
            f"Error: Invalid --output-format '{output_format}'. Only 'stream-json' is supported.",
            err=True,
        )
        raise typer.Exit(1)

    if sandbox and cloud:
        typer.echo("Error: --sandbox and --cloud are mutually exclusive.", err=True)
        raise typer.Exit(1)

    if sandbox:
        assert prompt, "Prompt is required with --sandbox"
        _handle_sandbox_agent(
            prompt=prompt,
            sandbox_id=sandbox,
            template=template or "default",
            json_output=json_output,
        )
        from wafer.cli.app import _mark_command_success
        _mark_command_success()
        return

    if pull_files and not cloud:
        typer.echo("Error: --pull-files requires --cloud.", err=True)
        raise typer.Exit(1)

    if cloud:
        if not list_sessions and not get_session and not pull_files and not template:
            template = "default"
        from .global_config import get_defaults
        effective_repo: str | None = None
        if cloud_dir is None:
            effective_repo = cloud_repo
            if not effective_repo:
                default_repo = get_defaults().repo
                if default_repo:
                    effective_repo = default_repo
                    if not json_output:
                        sys.stderr.write(f"\x1b[2mUsing default repo: {default_repo}\x1b[0m\n")
                        sys.stderr.flush()
        _handle_cloud_agent(
            prompt=prompt or "",
            cloud_repo=effective_repo,
            cloud_dir=cloud_dir,
            config=template or "",
            json_output=json_output,
            list_sessions=list_sessions,
            get_session=get_session,
            pull_files=pull_files,
            pull_out=pull_out,
            session_id=resume,
            target_name=target,
        )
        from wafer.cli.app import _mark_command_success
        _mark_command_success()
        return

    if list_sessions or get_session:
        from wafer.cli.wevin_cli import main as wevin_main
        wevin_main(
            list_sessions=list_sessions,
            get_session=get_session,
            json_output=json_output,
        )
        return

    if not template:
        template = "default"

    _validate_template_name(template)

    from wafer.cli.agent_config import get_bundled_template_path, load_agent_config

    effective_template = template
    bundled_toml = get_bundled_template_path(template)
    if bundled_toml is not None:
        file_config = load_agent_config(bundled_toml)
    else:
        template_path = Path(template).expanduser()
        assert template_path.is_file(), f"Template '{template}' is not a bundled template or valid file path"
        file_config = load_agent_config(template_path)

    is_cloud_only = getattr(file_config, "cloud_only", False)
    if is_cloud_only:
        typer.echo(
            f"Error: Template '{template}' requires --cloud.\n"
            f"  Run: wafer agent --cloud -t {template} \"<prompt>\"",
            err=True,
        )
        raise typer.Exit(1)

    actual_prompt, use_tui = _agent_resolve_input(prompt, json_output)
    parsed_template_args = _agent_parse_template_args(template_args)
    from wafer.cli.wevin_cli import main as wevin_main

    wevin_main(
        prompt=actual_prompt,
        interactive=use_tui,
        resume=resume,
        json_output=json_output,
        output_format=output_format,
        file_config=file_config,
        template=effective_template,
        template_args=parsed_template_args,
    )
    from wafer.cli.app import _mark_command_success
    _mark_command_success()


def register_agent_command(app: typer.Typer) -> None:
    """Register the ``agent`` command on the given Typer app."""
    app.command()(agent)
