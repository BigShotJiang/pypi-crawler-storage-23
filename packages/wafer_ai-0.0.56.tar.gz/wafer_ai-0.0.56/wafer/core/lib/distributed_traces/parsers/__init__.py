"""Trace format parsers for distributed traces.

This module provides parsers for various trace formats:
- PyTorch Profiler Chrome trace JSON
- NCCL Inspector JSONL
- rocprofv3 RCCL CSV/JSON
- Nsight Systems SQLite
- ROCm Systems Profiler

Each parser extracts collective operations and compute events into
the unified data model.
"""

from wafer.core.lib.distributed_traces.parsers.nccl_inspector import (
    parse_nccl_inspector,
    parse_nccl_inspector_file,
)
from wafer.core.lib.distributed_traces.parsers.nsys import (
    parse_nsys,
    parse_nsys_file,
)
from wafer.core.lib.distributed_traces.parsers.pytorch_trace import (
    parse_pytorch_trace,
    parse_pytorch_trace_file,
)
from wafer.core.lib.distributed_traces.parsers.rocprofv3 import (
    parse_rocprofv3,
    parse_rocprofv3_file,
)
from wafer.core.lib.distributed_traces.parsers.rocsys import (
    parse_rocsys,
    parse_rocsys_file,
)

__all__ = [
    # PyTorch Profiler
    "parse_pytorch_trace",
    "parse_pytorch_trace_file",
    # NCCL Inspector
    "parse_nccl_inspector",
    "parse_nccl_inspector_file",
    # rocprofv3
    "parse_rocprofv3",
    "parse_rocprofv3_file",
    # Nsight Systems
    "parse_nsys",
    "parse_nsys_file",
    # ROCm Systems
    "parse_rocsys",
    "parse_rocsys_file",
]
