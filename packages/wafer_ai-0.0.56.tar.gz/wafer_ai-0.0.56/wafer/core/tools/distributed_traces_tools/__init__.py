"""Distributed Traces tools for Wevin agent.

Provides tools for analyzing NCCL/RCCL collective operations in distributed training.
Wraps the core library functions in lib/distributed_traces for agent use.
"""

from wafer.core.tools.distributed_traces_tools.distributed_traces_analyze_tool import (
    DISTRIBUTED_TRACES_ANALYZE_TOOL,
    exec_distributed_traces_analyze,
)
from wafer.core.tools.distributed_traces_tools.distributed_traces_compare_tool import (
    DISTRIBUTED_TRACES_COMPARE_TOOL,
    exec_distributed_traces_compare,
)

__all__ = [
    "DISTRIBUTED_TRACES_ANALYZE_TOOL",
    "DISTRIBUTED_TRACES_COMPARE_TOOL",
    "exec_distributed_traces_analyze",
    "exec_distributed_traces_compare",
]
