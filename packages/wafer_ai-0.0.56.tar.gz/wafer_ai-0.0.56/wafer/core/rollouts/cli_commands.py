"""Shared CLI command builders for Claude and Codex.

Used by cli_agents for top-level eval and subagent_tool for subagent execution.
"""
from __future__ import annotations


def build_claude_cli_args(
    prompt: str,
    *,
    model: str | None = None,
    allowed_tools: list[str] | None = None,
) -> list[str]:
    """Build Claude Code CLI command args.
    Returns list suitable for subprocess: ["claude", "-p", prompt, ...]
    """
    cmd = ["claude", "-p", prompt, "--output-format", "stream-json", "--verbose"]
    if allowed_tools:
        cmd.extend(["--allowedTools", ",".join(allowed_tools)])
    if model:
        cmd.extend(["--model", model])
    return cmd


def build_codex_cli_args(
    prompt: str,
    *,
    model: str | None = None,
) -> list[str]:
    """Build Codex CLI command args.
    Returns list suitable for subprocess: ["codex", "exec", prompt, ...]
    """
    cmd = ["codex", "exec", "--json", "--full-auto", "--skip-git-repo-check"]
    if model:
        cmd.extend(["-m", model])
    cmd.append(prompt)
    return cmd
