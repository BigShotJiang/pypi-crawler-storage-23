"""Template system for constrained, task-specific agents.

Templates are loaded from bundled TOML files in wafer/cli/templates/toml/.
"""

from wafer.cli.agent_config import AgentConfig
from .base import DANGEROUS_BASH_COMMANDS, SAFE_BASH_COMMANDS
from .loader import list_templates, load_all_templates, load_template

__all__ = [
    "AgentConfig",
    "DANGEROUS_BASH_COMMANDS",
    "SAFE_BASH_COMMANDS",
    "load_all_templates",
    "load_template",
    "list_templates",
]
