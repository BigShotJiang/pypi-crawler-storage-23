"""Bash command allowlists and denylists for agent sandboxing."""
from __future__ import annotations

# Safe read-only commands with no side effects.
# Templates can extend this with task-specific commands.
# NOTE: The allowlist uses prefix matching, so "git branch" also allows
# "git branch -D" which is destructive. Only include truly read-only commands.
SAFE_BASH_COMMANDS: list[str] = [
    # File inspection
    "ls",
    "cat",
    "head",
    "tail",
    "less",
    "more",
    "file",
    "stat",
    "wc",
    # Search
    "find",
    "grep",
    "rg",
    "fd",
    # Navigation
    "pwd",
    "tree",
    "which",
    "whereis",
    # Comparison/processing
    "diff",
    "sort",
    "uniq",
    # Disk info
    "du",
    "df",
    # Git read-only (only commands with no destructive subcommands)
    "git status",
    "git log",
    "git diff",
    "git show",
    # Data processing
    "jq",
]
# Dangerous commands that should always be denied.
# These can cause irreversible damage or security issues.
DANGEROUS_BASH_COMMANDS: list[str] = [
    # Destructive file operations
    "rm ",
    "rm\t",
    "rmdir",
    "shred",
    "dd ",
    "dd\t",
    "truncate",
    # Moving/overwriting without backup
    "mv ",
    "mv\t",
    # Privilege escalation
    "sudo",
    "su ",
    "su\t",
    "doas",
    # System control
    "reboot",
    "shutdown",
    "poweroff",
    "halt",
    "init ",
    "init\t",
    # Service/process control
    "systemctl start",
    "systemctl stop",
    "systemctl restart",
    "systemctl enable",
    "systemctl disable",
    "service ",
    "kill ",
    "kill\t",
    "killall",
    "pkill",
    # Package managers (system-wide changes)
    "apt install",
    "apt remove",
    "apt purge",
    "apt-get install",
    "apt-get remove",
    "apt-get purge",
    "yum install",
    "yum remove",
    "dnf install",
    "dnf remove",
    "pacman -S",
    "pacman -R",
    "brew install",
    "brew uninstall",
    "pip install",
    "pip uninstall",
    "npm install -g",
    "npm uninstall -g",
    # Disk/filesystem operations
    "mkfs",
    "fdisk",
    "parted",
    "mount ",
    "mount\t",
    "umount",
    # Network danger
    "iptables",
    "ufw ",
    "ufw\t",
    # Chmod/chown (can break permissions)
    "chmod ",
    "chmod\t",
    "chown ",
    "chown\t",
    "chgrp",
]
