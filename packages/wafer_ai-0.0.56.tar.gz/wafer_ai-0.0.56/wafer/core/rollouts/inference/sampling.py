"""Pure functions for sampling.
No state, no side effects. Logits in, tokens out.
"""
import torch
import torch.nn.functional as F


def sample_with_logprobs(
    logits: torch.Tensor,  # [batch, vocab]
    temperatures: torch.Tensor,  # [batch]
) -> tuple[torch.Tensor, torch.Tensor]:
    """Pure function: sample tokens and compute their logprobs.
    Args:
        logits: Raw model output [batch, vocab_size]
        temperatures: Per-sequence temperature [batch]
    Returns:
        tokens: Sampled token IDs [batch]
        logprobs: Log probability of each sampled token [batch]
                  (always from unscaled logits - the true model distribution)
    """
    assert logits.dim() == 2, f"Expected 2D logits, got {logits.dim()}D"
    assert temperatures.dim() == 1, f"Expected 1D temperatures, got {temperatures.dim()}D"
    assert logits.size(0) == temperatures.size(0), "Batch size mismatch"
    batch_size = logits.size(0)

    # This is the actual model distribution, independent of sampling temperature
    log_probs = F.log_softmax(logits, dim=-1)

    greedy_mask = temperatures == 0
    temps_safe = temperatures.clone()
    temps_safe[greedy_mask] = 1.0  # Avoid division by zero
    # Scale by temperature for sampling only
    scaled_logits = logits / temps_safe.unsqueeze(-1)
    scaled_probs = F.softmax(scaled_logits, dim=-1)
    # Sample from temperature-scaled distribution
    sampled_tokens = torch.multinomial(scaled_probs, num_samples=1).squeeze(-1)
    # For greedy, override with argmax
    if greedy_mask.any():
        greedy_tokens = logits.argmax(dim=-1)
        sampled_tokens = torch.where(greedy_mask, greedy_tokens, sampled_tokens)

    sampled_logprobs = log_probs.gather(-1, sampled_tokens.unsqueeze(-1)).squeeze(-1)
    assert sampled_tokens.shape == (batch_size,)
    assert sampled_logprobs.shape == (batch_size,)
    return sampled_tokens, sampled_logprobs
