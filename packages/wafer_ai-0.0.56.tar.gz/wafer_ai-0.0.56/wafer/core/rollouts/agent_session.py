"""Shared agent session — single entry point for all agent runs.

Extracted from wevin_cli._run_noninteractive() and cloud_agent.run_cloud_agent().
All three callers (desktop CLI, cloud agent, eval harness) call run_agent_session().
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .dtypes import AgentState, Environment
    from .frontends.protocol import Frontend
    from .store import SessionStore


from .agents import handle_stop_max_turns
from .dtypes import Endpoint, Message, StopReason, Trajectory
from .frontends import NoneFrontend, RunnerConfig, run_interactive
from .frontends.runner import InteractiveRunner


@dataclass(frozen=True)
class AgentSessionConfig:
    """Configuration for a single agent session run.

    Callers build this from their own CLI flags / API request / eval config,
    then pass it to run_agent_session().
    """

    prompt: str
    system_prompt: str
    endpoint: Endpoint
    environment: Environment
    frontend: Frontend | None = None
    session_store: SessionStore | None = None
    session_id: str | None = None
    single_turn: bool = True
    max_turns: int = 50
    tags: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class AgentSessionResult:
    """Result returned by run_agent_session()."""

    states: list[AgentState]
    session_id: str | None
    trajectory: Trajectory


async def run_agent_session(config: AgentSessionConfig) -> AgentSessionResult:
    """Run an agent session — the single shared core for all agent entry points.

    Builds a Trajectory, wires up RunnerConfig, calls run_interactive(),
    and returns the result.
    """
    assert config.prompt, "prompt must not be empty"
    assert config.system_prompt, "system_prompt must not be empty"
    assert config.endpoint is not None, "endpoint is required"
    assert config.environment is not None, "environment is required"

    if config.session_id and config.session_store:
        existing_session, err = await config.session_store.get(config.session_id)
        assert err is None, f"Failed to load session: {err}"
        assert existing_session is not None
        trajectory = Trajectory(messages=existing_session.messages)
    else:
        trajectory = Trajectory(
            messages=[Message(role="system", content=config.system_prompt)]
        )

    frontend = config.frontend or NoneFrontend(show_tool_calls=True, show_thinking=False)

    runner_config = RunnerConfig(
        session_store=config.session_store,
        session_id=config.session_id,
        initial_prompt=config.prompt,
        single_turn=config.single_turn,
        hide_session_info=True,
    )

    runner = InteractiveRunner(
        trajectory=trajectory,
        endpoint=config.endpoint,
        frontend=frontend,
        environment=config.environment,
        config=runner_config,
    )

    runner._on_stop = handle_stop_max_turns(config.max_turns)

    states = await runner.run()

    session_id = states[-1].session_id if states and states[-1].session_id else None
    final_trajectory = (
        states[-1].actor.trajectory if states else trajectory
    )

    return AgentSessionResult(
        states=states,
        session_id=session_id,
        trajectory=final_trajectory,
    )
