"""Shared parsers for CLI agent output (wafer, Claude Code, Codex).

Used by cli_agents for trajectory building and subagent_tool for text extraction.
"""
from __future__ import annotations

import json
from typing import Any

from .dtypes import Message, TextContent, ToolCallContent


def parse_claude_code_stream_json(output: str) -> list[Message]:
    """Parse Claude Code / JsonFrontend --output-format stream-json into list[Message].
    Claude Code emits NDJSON with event types:
    - {"type": "system", "subtype": "init", ...}
    - {"type": "assistant", "message": {"content": [...]}}
    - {"type": "user", "message": {"content": [{"type": "tool_result", ...}]}}
    - {"type": "result", "subtype": "success", ...}
    JsonFrontend also emits granular tool_result events:
    - {"type": "tool_result", "tool_call_id": ..., "content": ..., "is_error": ...}
    """
    assert isinstance(output, str)
    messages: list[Message] = []
    for line in output.strip().split("\n"):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        event_type = event.get("type")
        if event_type == "assistant":
            content_blocks = _parse_claude_content_blocks(event)
            if content_blocks:
                messages.append(Message(role="assistant", content=content_blocks))
        elif event_type == "user":
            tool_messages = _parse_claude_tool_results(event)
            messages.extend(tool_messages)
        elif event_type == "tool_result":
            content = event.get("content", "")
            if isinstance(content, list):
                content = json.dumps(content)
            messages.append(
                Message(
                    role="tool",
                    content=str(content),
                    tool_call_id=event.get("tool_call_id", ""),
                )
            )
    return messages


def _parse_claude_content_blocks(event: dict[str, Any]) -> list[TextContent | ToolCallContent]:
    """Parse content blocks from Claude Code assistant message."""
    assert "message" in event
    assert "content" in event["message"]
    content_blocks: list[TextContent | ToolCallContent] = []
    raw_content = event["message"]["content"]
    for block in raw_content:
        block_type = block.get("type")
        if block_type == "text":
            content_blocks.append(TextContent(text=block.get("text", "")))
        elif block_type == "tool_use":
            content_blocks.append(
                ToolCallContent(
                    id=block.get("id", ""),
                    name=block.get("name", ""),
                    arguments=block.get("input", {}),
                )
            )
    return content_blocks


def _parse_claude_tool_results(event: dict[str, Any]) -> list[Message]:
    """Parse tool results from Claude Code user message."""
    assert "message" in event
    assert "content" in event["message"]
    messages: list[Message] = []
    raw_content = event["message"]["content"]
    for block in raw_content:
        if block.get("type") == "tool_result":
            messages.append(
                Message(
                    role="tool",
                    content=block.get("content", ""),
                    tool_call_id=block.get("tool_use_id", ""),
                )
            )
    return messages


def parse_wafer_stream_json(output: str) -> list[Message]:
    """Parse wafer agent --output-format stream-json into list[Message].

    Wafer's StreamingChunkFrontend emits NDJSON:
    - {"type": "text_delta", "delta": "..."}
    - {"type": "tool_call_start", "tool_name": "..."}
    - {"type": "tool_call_end", "tool_name": "...", "args": {...}}
    - {"type": "tool_result", "is_error": bool}
    - {"type": "session_end"}
    """
    assert isinstance(output, str)
    messages: list[Message] = []
    text_parts: list[str] = []
    tool_counter = 0

    def _flush_text() -> None:
        if text_parts:
            messages.append(Message(role="assistant", content="".join(text_parts)))
            text_parts.clear()

    for line in output.strip().split("\n"):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        event_type = event.get("type", "")

        if event_type == "text_delta":
            text_parts.append(event.get("delta", ""))
        elif event_type == "tool_call_end":
            _flush_text()
            tool_id = f"wafer_tool_{tool_counter}"
            tool_counter += 1
            messages.append(Message(
                role="assistant",
                content=[ToolCallContent(
                    id=tool_id,
                    name=event.get("tool_name", ""),
                    arguments=event.get("args", {}),
                )],
            ))
        elif event_type == "tool_result":
            tool_content = event.get("content", "(tool result)")
            messages.append(Message(
                role="tool",
                content=tool_content if tool_content else "(tool result)",
                tool_call_id=f"wafer_tool_{tool_counter - 1}" if tool_counter > 0 else "",
            ))
        elif event_type == "session_end":
            break

    _flush_text()
    return messages


def parse_codex_json(output: str) -> list[Message]:
    """Parse Codex ``exec --json`` output into list[Message].

    Codex emits NDJSON with an item-based event stream:
        {"type": "item.completed", "item": {"type": "agent_message", "text": "..."}}
        {"type": "item.completed", "item": {"type": "command_execution", "command": "ls", ...}}
    """
    assert isinstance(output, str)
    messages: list[Message] = []
    for line in output.strip().split("\n"):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get("type") != "item.completed":
            continue
        item = event.get("item", {})
        item_type = item.get("type")
        item_id = item.get("id", "")
        if item_type == "agent_message":
            text = item.get("text", "")
            if text:
                messages.append(Message(role="assistant", content=text))
        elif item_type == "command_execution":
            command = item.get("command", "")
            output_text = item.get("aggregated_output") or item.get("output", "")
            messages.append(Message(
                role="assistant",
                content=[ToolCallContent(id=item_id, name="bash", arguments={"command": command})],
            ))
            messages.append(Message(role="tool", content=output_text, tool_call_id=item_id))
        elif item_type == "file_change":
            for change in item.get("changes", []):
                path = change.get("path", "")
                kind = change.get("kind", "update")
                tool_name = "write" if kind in ("add", "update") else "edit"
                messages.append(Message(
                    role="assistant",
                    content=[ToolCallContent(id=item_id, name=tool_name, arguments={"path": path, "kind": kind})],
                ))
                messages.append(Message(
                    role="tool",
                    content=f"{'Wrote' if kind != 'delete' else 'Deleted'} {path}",
                    tool_call_id=item_id,
                ))
    return messages


def parse_raw_text_fallback(output: str) -> list[Message]:
    """Fallback parser: treat entire output as single assistant message."""
    assert isinstance(output, str)
    if not output.strip():
        return []
    return [Message(role="assistant", content=output.strip())]
