"""Wafer Core - utilities and environments for GPU kernel optimization.

Main exports:
- WaferAiEnvironment: Pi-coding-agent style environment with read/write/edit/bash/wafer tools
- Target configs: ModalTarget, BaremetalTarget, VMTarget
- Logging: setup_logging, ColorFormatter, JSONFormatter
- Retry: retry, async_retry, RetryState
- SSH: SSHClient
- Utils: Remote execution, kernel utilities, etc.
- Tools: Perfetto (trace profiling), NCU (profiler tools)
- rollouts: LLM evaluation and agentic RL framework (wafer.core.rollouts)

Note: Imports are lazy to avoid pulling in heavy dependencies for code that only
needs utility modules (e.g., evaluate.py only needs wafer.core.utils.*).
"""

__all__ = [
    "WaferAiEnvironment",
    "ModalTarget",
    "BaremetalTarget",
    "VMTarget",
    "TargetConfig",
    # Logging
    "setup_logging",
    "ColorFormatter",
    "JSONFormatter",
    # Retry
    "retry",
    "retry_v2",
    "async_retry",
    "RetryState",
    # Tools
    "PerfettoTool",
    "PerfettoConfig",
    "TraceManager",
    "TraceProcessorManager",
]


def __getattr__(name: str):
    """Lazy import to avoid loading rollouts for utility-only usage."""
    if name == "WaferAiEnvironment":
        from wafer.core.environments.wafer_ai import WaferAiEnvironment

        return WaferAiEnvironment

    if name in ("BaremetalTarget", "ModalTarget", "TargetConfig", "VMTarget"):
        from wafer.core.utils.kernel_utils import targets

        return getattr(targets, name)

    if name in ("setup_logging", "ColorFormatter", "JSONFormatter"):
        from wafer.core import logging

        return getattr(logging, name)

    if name in ("retry", "retry_v2", "async_retry", "RetryState"):
        from wafer.core import retry

        return getattr(retry, name)

    # Profiling tools (lib, not tools)
    if name in ("PerfettoTool", "PerfettoConfig"):
        from wafer.core.lib.perfetto import PerfettoConfig, PerfettoTool

        if name == "PerfettoTool":
            return PerfettoTool
        return PerfettoConfig

    if name in ("TraceManager", "TraceProcessorManager"):
        from wafer.core.lib.perfetto import TraceManager, TraceProcessorManager

        if name == "TraceManager":
            return TraceManager
        return TraceProcessorManager

    raise AttributeError(f"module 'wafer.core' has no attribute {name!r}")
