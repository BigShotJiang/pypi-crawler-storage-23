import sys, pathlib

from PyQt5 import QtCore, QtQml, QtGui
from qdrive.GUI.update.models import update_model


def show_update_pop_up():
    app = QtGui.QGuiApplication.instance()
    if not app:
        QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling, True)
        QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_UseHighDpiPixmaps, True)
        app = QtGui.QGuiApplication(sys.argv)

    engine = QtQml.QQmlApplicationEngine()

    update_model_instance = update_model()
    engine.rootContext().setContextProperty("update_model", update_model_instance)
    
    qml_file = pathlib.Path(__file__).parent / './main.qml'
    engine.load(QtCore.QUrl.fromLocalFile(str(qml_file)))

    if not engine.rootObjects():
        sys.exit(-1)

    sys.exit(app.exec_())
    
if __name__ == "__main__":
    show_update_pop_up()
    