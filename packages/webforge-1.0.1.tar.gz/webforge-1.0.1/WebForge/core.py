"""
WebForge Core - Main application engine
"""

import os
import sys
import functools
from pathlib import Path
from typing import Callable, Optional, List, Union

try:
    from flask import (
        Flask, request, session, redirect as flask_redirect,
        abort as flask_abort, send_file
    )
    FLASK_AVAILABLE = True
except ImportError:
    FLASK_AVAILABLE = False


class WebForgeApp:
    """Main WebForge application class"""

    def __init__(self):
        self._routes = {}
        self._security = {}
        self._static_routes = {}
        self._flask_app = None
        self._project_root = None

    def _resolve_project_root(self, caller_file: str) -> Path:
        """Walk up from forge.py until we find the dir that contains public/"""
        p = Path(caller_file).resolve().parent
        for _ in range(6):
            if (p / "public").exists():
                return p
            p = p.parent
        # Fallback: 2 levels up from forge.py  (backend/server/ -> root)
        return Path(caller_file).resolve().parent.parent.parent

    def _build_flask_app(self) -> "Flask":
        if not FLASK_AVAILABLE:
            raise RuntimeError("Flask is required: pip install flask")

        root = self._project_root
        template_folder = str(root / "public" / "pages")
        static_folder   = str(root / "public" / "service")

        print(f"[WebForge] project root   : {root}")
        print(f"[WebForge] template folder: {template_folder}")
        print(f"[WebForge] static folder  : {static_folder}")

        app = Flask(
            __name__,
            template_folder=template_folder,
            static_folder=static_folder,
            static_url_path="/static",
        )
        app.secret_key = os.urandom(32)
        return app

    def _get_flask_app(self) -> "Flask":
        if self._flask_app is None:
            self._flask_app = self._build_flask_app()
            self._register_all_routes()
        return self._flask_app

    # ── Route registration ───────────────────────────────────────────────────

    def _register_all_routes(self):
        for route_path, handler in self._routes.items():
            security_fn = self._security.get(route_path)
            self._register_flask_route(self._flask_app, route_path, handler, security_fn)
        for name, file_path in self._static_routes.items():
            self._register_static_file(self._flask_app, name, file_path)

    def _register_flask_route(self, flask_app, route_path, handler, security_fn):
        safe = route_path.replace("/", "_").strip("_") or "index"
        endpoint = f"wf_{safe}"

        def view_func():
            if security_fn:
                result = security_fn()
                if result is not None:
                    return self._process(result)
            return self._process(handler())

        view_func.__name__ = endpoint
        flask_app.add_url_rule(
            route_path, endpoint=endpoint, view_func=view_func,
            methods=["GET", "POST", "PUT", "DELETE", "PATCH"]
        )

    def _register_static_file(self, flask_app, name, file_path):
        abs_path = str(self._project_root / file_path.lstrip("/"))
        endpoint = f"wf_static_{name}"

        def serve():
            return send_file(abs_path)

        serve.__name__ = endpoint
        flask_app.add_url_rule(f"/static/{name}", endpoint=endpoint, view_func=serve)

    def _process(self, result):
        if result is None:
            return ("", 200)
        return result

    # ── Public API ───────────────────────────────────────────────────────────

    def env(self, key: str, default=None):
        return os.environ.get(key, default)

    def app(self, route_path: str, methods=None):
        def decorator(fn: Callable):
            self._routes[route_path] = fn
            return fn
        return decorator

    def security(self, route_path: str):
        def decorator(fn: Callable):
            self._security[route_path] = fn
            return fn
        return decorator

    def add_static_route(self, name: str, path: str):
        self._static_routes[name] = path

    def render(self, template: str, **context):
        from flask import render_template
        return render_template(template, **context)

    def redirect(self, url: str, code: int = 302):
        return flask_redirect(url, code)

    def abort(self, code: int, message: Optional[str] = None):
        if message:
            from flask import Response
            return Response(message, status=code)
        flask_abort(code)

    def check_password(self, stored_password: str) -> bool:
        return session.get("password") == stored_password

    def check_ip(self, allowed_ip) -> bool:
        client_ip = request.remote_addr
        if isinstance(allowed_ip, str):
            return client_ip == allowed_ip
        return client_ip in allowed_ip

    def run(self, debug: bool = False, port: int = 5000, host: str = "0.0.0.0"):
        # Detect project root from the forge.py that called run()
        frame = sys._getframe(1)
        caller_file = frame.f_globals.get("__file__", "")
        if not caller_file:
            caller_file = str(Path.cwd() / "forge.py")

        self._project_root = self._resolve_project_root(caller_file)

        flask_app = self._get_flask_app()

        print(f"""
╔══════════════════════════════════════════════╗
║           🔥 WebForge Server                  ║
║  http://{host}:{port}                  ║
╚══════════════════════════════════════════════╝""")

        flask_app.run(debug=debug, port=port, host=host)
