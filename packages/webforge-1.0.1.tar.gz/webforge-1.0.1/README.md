# 🔥 WebForge

**Create web applications easily** — a minimal Flask-powered framework with clean syntax.

```bash
pip install WebForge
webforge new mon-site
cd mon-site
python backend/server/forge.py
```

---

## Structure d'un projet WebForge

```
mon-site/
├── backend/
│   ├── requirements.txt
│   └── server/
│       └── forge.py        ← Cœur du serveur
└── public/
    ├── pages/
    │   └── index.html      ← Templates HTML
    ├── script/
    │   └── app.js          ← JavaScript client
    └── service/
        └── style.css       ← Fichiers statiques
```

---

## Écrire `forge.py`

```python
from WebForge import webforge, security, env as web

# Variables d'environnement
password = web.env("PASSWORD")
ip = "192.168.1.123"

# ─── Routes ──────────────────────────────────────
@web.app("/")
def index():
    web.route("style", "/public/service/style.css")
    return web.render("index.html")

@web.app("/login")
def login():
    return web.render("login.html")

# ─── Sécurité ────────────────────────────────────
@web.security("/")
def secure_home():
    if not web.password(password):      # vérif mot de passe en session
        return web.redirect("/login")
    if not web.ip(ip):                  # vérif IP
        return web.abort(403)

# ─── Démarrage ───────────────────────────────────
if __name__ == "__main__":
    web.runapp(debug=True, port=5000, host="0.0.0.0")
```

---

## API complète

### Routes

| Fonction | Description |
|----------|-------------|
| `@web.app("/path")` | Définit une route |
| `@web.security("/path")` | Middleware de sécurité pour une route |
| `web.route("name", "/path/to/file")` | Route vers un fichier statique |

### Réponses

| Fonction | Description |
|----------|-------------|
| `web.render("page.html", **ctx)` | Rend un template HTML |
| `web.redirect("/url")` | Redirige vers une URL |
| `web.abort(403)` | Retourne une erreur HTTP |

### Sécurité

| Fonction | Description |
|----------|-------------|
| `web.password("secret")` | Vérifie le mot de passe en session |
| `web.ip("192.168.1.1")` | Vérifie l'IP du client (accepte aussi une liste) |

### Utilitaires

| Fonction | Description |
|----------|-------------|
| `web.env("VAR")` | Lit une variable d'environnement |
| `web.runapp(debug, port, host)` | Démarre le serveur |

---

## CLI

```bash
webforge new <nom>    # Crée un nouveau projet
webforge run          # Lance le projet courant
```

---

## Installation pour le développement

```bash
git clone https://github.com/yourname/webforge
cd webforge
pip install -e .
```

---

## Licence

MIT
