"""Video Analyst - Analyze videos and produce AI reproduction plans."""

__version__ = "1.6.0"
