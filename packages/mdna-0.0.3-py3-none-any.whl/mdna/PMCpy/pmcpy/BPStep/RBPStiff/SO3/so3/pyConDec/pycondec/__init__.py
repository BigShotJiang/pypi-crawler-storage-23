"""
pyConDec
=====

Module for conditional decorators in python

"""

from .conditional_numba  import conditional_numba    as cond_jit
from .conditional_numba  import conditional_jitclass as cond_jitclass


