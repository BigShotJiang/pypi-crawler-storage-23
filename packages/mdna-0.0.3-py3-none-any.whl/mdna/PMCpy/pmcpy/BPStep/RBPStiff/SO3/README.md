# pySO3
A collection of methods for the rotation group


To clone module including submodules 
```console
git clone --recurse-submodules -j8 git@github.com:eskoruppa/SO3.git
```