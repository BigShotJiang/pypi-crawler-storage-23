from setuptools import find_packages, setup

setup(
    name="<REPO NAME>",
    version="0.0.1",
    description="ADD DESCRIPTION",
    url="https://github.com/eskoruppa/<REPO NAME>",
    author="Enrico Skoruppa",
    author_email="enrico dot skoruppa at gmail dot com",
    license="GNU2",
    packages=find_packages(),
    zip_safe=False,
)
