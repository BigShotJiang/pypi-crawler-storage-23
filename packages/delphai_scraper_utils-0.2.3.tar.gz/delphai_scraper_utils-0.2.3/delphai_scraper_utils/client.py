import asyncio
from collections import namedtuple
from contextlib import asynccontextmanager
from typing import Any, Callable, Optional, Union
from urllib.parse import urljoin

from async_lru import alru_cache
from httpx import (
    USE_CLIENT_DEFAULT,
    AsyncClient,
    Cookies,
    Limits,
    Response,
    StreamError,
    Timeout,
    TimeoutException,
    NetworkError,
    ProtocolError,
    ProxyError,
    HTTPStatusError,
)
from httpx._client import UseClientDefault
from httpx._config import DEFAULT_LIMITS
from httpx._types import (
    AuthTypes,
    CookieTypes,
    HeaderTypes,
    QueryParamTypes,
    RequestContent,
    RequestData,
    RequestFiles,
    TimeoutTypes,
    URLTypes,
)
from protego import Protego
from tenacity import retry as tenacity_retry
from tenacity import (
    retry_if_exception_type,
    retry_if_exception,
    stop_after_attempt,
    wait_random_exponential,
)

from .metrics import register_scraper_client, request_timer

HTTP_RETRY_EXCEPTION_TYPES = (
    TimeoutException,
    NetworkError,
    ProtocolError,
    ProxyError,
    StreamError,
)


def test_response_status_code(exception):
    if not isinstance(exception, HTTPStatusError):
        return False

    if 500 <= exception.response.status_code < 600:
        return True

    return exception.response.status_code in (
        408,  # Request Timeout
        429,  # Too Many Requests
    )


def retry_httpx(
    stop=stop_after_attempt(3),
    wait=wait_random_exponential(multiplier=1, max=60, min=1),
    retry=retry_if_exception_type(tuple(HTTP_RETRY_EXCEPTION_TYPES))
    | retry_if_exception(test_response_status_code),
    reraise=True,
    **kwargs,
):
    return tenacity_retry(stop=stop, wait=wait, retry=retry, reraise=reraise, **kwargs)


TimeoutTuple = namedtuple("TimeoutTuple", ["connect", "read", "write", "pool"])
DEFAULT_TIMEOUT = TimeoutTuple(30.0, 30.0, 30.0, 30.0)

# This default value is adjusted to match most of use cases.
MAKE_ROBOTS_TEXT_PARSER_CACHE_DECORATOR = alru_cache(maxsize=5)


@asynccontextmanager
async def without_restrictions():
    yield


class RobotFileParserTimeoutError(Exception):
    pass


class ScraperClient(AsyncClient):
    def __init__(
        self,
        *,
        persist_cookies: bool = False,
        scraper_id: Union[str, None] = None,
        request_decorator: Optional[Callable] = retry_httpx(),
        ignore_robots_txt: bool = False,
        truncate_after: int = 1024000,  # 1 MB
        total_timeout: int = 180,  # 3 minutes
        make_robots_text_parser_cache_decorator: Optional[
            Callable
        ] = MAKE_ROBOTS_TEXT_PARSER_CACHE_DECORATOR,
        fetch_robots_text_cache_decorator: Optional[Callable] = None,
        **httpx_client_kwargs,
    ):
        limits = httpx_client_kwargs.get("limits", DEFAULT_LIMITS)
        httpx_client_kwargs["limits"] = Limits(
            max_connections=limits.max_connections,
            max_keepalive_connections=limits.max_connections,
            keepalive_expiry=limits.keepalive_expiry,
        )
        super().__init__(**httpx_client_kwargs)
        self.scraper_id = scraper_id
        self.persist_cookies = persist_cookies
        self.ignore_robots_txt = ignore_robots_txt
        self.truncate_after = truncate_after
        self.total_timeout = total_timeout
        if limits.max_connections and limits.max_connections > 0:
            self.max_connections_semaphore = asyncio.Semaphore(limits.max_connections)
        else:
            self.max_connections_semaphore = None

        # Wrap request in retry decorator
        if request_decorator is Callable:
            self.request = request_decorator(self.request)

        if fetch_robots_text_cache_decorator:
            self.fetch_robots_txt = fetch_robots_text_cache_decorator(
                self.fetch_robots_txt
            )

        if make_robots_text_parser_cache_decorator:
            self.make_robots_txt_parser = make_robots_text_parser_cache_decorator(
                self.make_robots_txt_parser
            )

        register_scraper_client(self)

    async def request(
        self,
        method: str,
        url: URLTypes,
        *,
        content: RequestContent = None,
        data: RequestData = None,
        files: RequestFiles = None,
        json: Any = None,
        params: QueryParamTypes = None,
        headers: HeaderTypes = None,
        cookies: CookieTypes = None,
        auth: Union[AuthTypes, UseClientDefault] = USE_CLIENT_DEFAULT,
        follow_redirects: Union[bool, UseClientDefault] = USE_CLIENT_DEFAULT,
        timeout: Union[TimeoutTypes, UseClientDefault] = USE_CLIENT_DEFAULT,
        extensions: dict = None,
        truncate_after: Optional[int] = None,
        ignore_robots_txt: Optional[bool] = None,
    ) -> Response:
        if ignore_robots_txt is None:
            ignore_robots_txt = self.ignore_robots_txt

        if truncate_after is None:
            truncate_after = self.truncate_after

        # we force the hashable timeout to enable cache
        if isinstance(timeout, Timeout):
            timeout = TimeoutTuple(
                timeout.connect, timeout.read, timeout.write, timeout.pool
            )

        async with self.max_connections_semaphore or without_restrictions():
            async with asyncio.timeout(self.total_timeout):
                return await self._request_truncated_content(
                    method,
                    url,
                    content=content,
                    data=data,
                    files=files,
                    json=json,
                    params=params,
                    headers=headers,
                    cookies=cookies,
                    auth=auth,
                    follow_redirects=follow_redirects,
                    timeout=timeout,
                    extensions=extensions,
                    truncate_after=truncate_after,
                    ignore_robots_txt=ignore_robots_txt,
                )

    async def _request_truncated_content(
        self,
        method: str,
        url: URLTypes,
        *,
        content: RequestContent = None,
        data: RequestData = None,
        files: RequestFiles = None,
        json: Any = None,
        params: QueryParamTypes = None,
        headers: HeaderTypes = None,
        cookies: CookieTypes = None,
        auth: Union[AuthTypes, UseClientDefault] = USE_CLIENT_DEFAULT,
        follow_redirects: Union[bool, UseClientDefault] = USE_CLIENT_DEFAULT,
        timeout: Union[TimeoutTypes, UseClientDefault] = USE_CLIENT_DEFAULT,
        extensions: dict = None,
        truncate_after: Optional[int] = None,
        ignore_robots_txt: Optional[bool] = None,
    ):
        """
        Extends the httpx.AsyncClient.request()
        with truncate_after parameter
        """

        if not self.persist_cookies:
            self._cookies = Cookies(None)

        request = self.build_request(
            method=method,
            url=url,
            content=content,
            data=data,
            files=files,
            json=json,
            params=params,
            headers=headers,
            cookies=cookies,
            timeout=timeout,
            extensions=extensions,
        )
        if not ignore_robots_txt:
            user_agent = (headers or {}).get("user-agent", "*")
            if not await self.is_allowed_by_robots_text(
                url, user_agent, timeout=timeout
            ):
                return Response(
                    403,
                    text="403 Forbidden: Access to {url} is disallowed by the site's robots.txt file.",
                    request=request,
                )

        with request_timer(scraper_id=self.scraper_id):
            response = await self.send(
                request, auth=auth, follow_redirects=follow_redirects, stream=True
            )
            content: bytes = b""
            try:
                content_accumulator = bytearray()
                async for chunk in response.aiter_bytes():
                    content_accumulator.extend(chunk)
                    if truncate_after and len(content_accumulator) > truncate_after:
                        break
                response._content = bytes(content_accumulator[:truncate_after])
            finally:
                await response.aclose()

            return response

    async def fetch_robots_txt(
        self,
        base_url: str,
        user_agent: str,
        timeout: Union[TimeoutTypes, UseClientDefault] = USE_CLIENT_DEFAULT,
    ) -> str:
        robots_txt_url = urljoin(base_url, "robots.txt")
        try:
            response = await self._request_truncated_content(
                "GET",
                robots_txt_url,
                headers={"user-agent": user_agent},
                follow_redirects=True,
                # The Robots Exclusion Protocol requires crawlers to parse at least 500 kibibytes (512000 bytes):
                truncate_after=512000,
                timeout=timeout or self.timeout,
                ignore_robots_txt=True,
            )
            if response.status_code == 200:
                robot_txt = response.text
            elif response.status_code in (401, 403):
                robot_txt = "User-agent: *\nDisallow: /"
            else:
                robot_txt = "User-agent: *\nAllow: /"
        except TimeoutException:
            raise RobotFileParserTimeoutError(f"Timeout while loading {robots_txt_url}")
        return robot_txt

    async def make_robots_txt_parser(
        self,
        base_url,
        user_agent: str,
        timeout: Union[TimeoutTypes, UseClientDefault] = USE_CLIENT_DEFAULT,
    ):
        robots_txt = await self.fetch_robots_txt(base_url, user_agent, timeout=timeout)
        return await asyncio.get_running_loop().run_in_executor(
            None, Protego.parse, robots_txt
        )

    async def is_allowed_by_robots_text(
        self,
        url: str,
        user_agent: str,
        timeout: Union[TimeoutTypes, UseClientDefault] = USE_CLIENT_DEFAULT,
    ) -> bool:
        robots_text_parser = await self.make_robots_txt_parser(
            urljoin(url, "/"), user_agent, timeout=timeout
        )
        return robots_text_parser.can_fetch(url=url, user_agent=user_agent)
