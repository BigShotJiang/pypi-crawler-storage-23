from sqlcodec.encoder import compress
from sqlcodec.decoder import decompress

def test_full_cycle():
    sql = """
    CREATE TABLE [dbo].[Account] (
        [AccountKey] INT IDENTITY(1,1) NOT NULL,
        [AccountDescription] NVARCHAR(50) NULL
    );
    """
    
    compressed = compress(sql)
    print("--- Compressed ---")
    print(compressed)
    
    decompressed = decompress(compressed, dialect="sqlserver")
    print("--- Decompressed ---")
    print(decompressed)
    
    assert "IDENTITY" in decompressed
    assert "TABLE" in decompressed
    assert "PRIMARY KEY" not in decompressed # Not in original
    assert "[dbo].[Account]" in decompressed

def test_postgres_dialect():
    sql = "CREATE TABLE users (id SERIAL PRIMARY KEY, name TEXT);"
    compressed = compress(sql, dialect="postgres")
    assert "~ser" in compressed
    
    decompressed = decompress(compressed, dialect="postgres")
    assert "SERIAL" in decompressed

if __name__ == "__main__":
    test_full_cycle()
    test_postgres_dialect()
    print("\nPhase 2 Tests Passed!")
