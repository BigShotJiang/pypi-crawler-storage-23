from sqlcodec import compress
import os

def test_large_sample():
    with open("AWDW2022Tables.txt", "r") as f:
        original_sql = f.read()
    
    compressed = compress(original_sql)
    
    orig_len = len(original_sql)
    comp_len = len(compressed)
    ratio = (orig_len - comp_len) / orig_len * 100
    
    print(f"Original Length: {orig_len} chars")
    print(f"Compressed Length: {comp_len} chars")
    print(f"Reduction: {ratio:.2f}%")
    
    # Save for inspection
    with open("AWDW2022_Compressed2.txt", "w") as f:
        f.write(compressed)
    
    print("\nCompressed file saved to AWDW2022_Compressed.txt")

if __name__ == "__main__":
    test_large_sample()
