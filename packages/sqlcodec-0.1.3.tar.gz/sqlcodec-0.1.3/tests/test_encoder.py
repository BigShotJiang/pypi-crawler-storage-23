from sqlcodec.encoder import compress

def test_basic_compression():
    sql = """
    CREATE TABLE [dbo].[TestTable] (
        [ID] INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
        [Name] NVARCHAR(50) NULL -- This is a name
    );
    /* Block comment 
       multi-line */
    ALTER TABLE [dbo].[TestTable] ADD CONSTRAINT [FK_Test] FOREIGN KEY ([ID]) REFERENCES [Other]([ID]);
    """
    
    compressed = compress(sql)
    print("--- Original ---")
    print(sql)
    print("--- Compressed ---")
    print(compressed)
    
    # Assertions
    assert "~t" in compressed  # TABLE
    assert "~pk" in compressed # PRIMARY KEY
    assert "~cml" in compressed # line comment
    assert "~cm" in compressed # block comment
    assert "~endcml" in compressed
    assert "~endcm" in compressed

if __name__ == "__main__":
    test_basic_compression()
    print("\nPhase 1 Basic Test Passed!")
