# sqlcodec/dialects/sqlserver.py
from .base import BaseDialect

class SQLServerDialect(BaseDialect):
    MAP = {
        "IDENTITY": "~id",
        "SYSNAME": "~sn",
        "CLUSTERED": "~cl",
        "NONCLUSTERED": "~nc",
    }
