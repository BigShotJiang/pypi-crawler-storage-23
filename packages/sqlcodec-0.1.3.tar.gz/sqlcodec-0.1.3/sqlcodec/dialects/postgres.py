# sqlcodec/dialects/postgres.py
from .base import BaseDialect

class PostgresDialect(BaseDialect):
    MAP = {
        "SERIAL": "~ser",
        "BIGSERIAL": "~bser",
        "TIMESTAMPTZ": "~tstz",
        "UUID": "~uuid",
    }
