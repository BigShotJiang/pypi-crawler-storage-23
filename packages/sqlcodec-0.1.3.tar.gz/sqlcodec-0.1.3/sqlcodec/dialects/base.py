# sqlcodec/dialects/base.py
class BaseDialect:
    MAP = {}
