import re
from .mappings import CORE_MAP
from .utils import get_dialect_map

def decompress(compressed_sql, dialect=None):
    """
    Decompresses the SQL tokens back to full keywords.
    Ensures basic readability with newlines.
    """
    # 1. Gather all mappings
    dialect_map = get_dialect_map(dialect)
    full_map = {**CORE_MAP, **dialect_map}
    
    # Reverse the map: token -> keyword
    reverse_map = {v: k for k, v in full_map.items()}
    
    # Add comment wrappers to reverse map
    reverse_map["~cml"] = "-- "
    reverse_map["~endcml"] = ""
    reverse_map["~cm"] = "/* "
    reverse_map["~endcm"] = " */"
    
    decompressed = compressed_sql
    
    # 2. Replace tokens back to keywords
    # Sort tokens by length descending to match longer ones first if applicable
    sorted_tokens = sorted(reverse_map.keys(), key=len, reverse=True)
    for token in sorted_tokens:
        keyword = reverse_map[token]
        # Since tokens usually start with ~, we don't always need \b but let's be safe
        decompressed = decompressed.replace(token, keyword)
    
    # 3. Add header
    header = "-- Reconstructed via sqlcodec; formatting may differ from original.\n"
    
    # 4. Readability: Ensure newline after semicolon if missing
    decompressed = re.sub(r';\s*', ';\n', decompressed)
    
    return header + decompressed.strip()
