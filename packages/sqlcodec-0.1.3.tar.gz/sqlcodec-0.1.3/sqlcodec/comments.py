import re

def wrap_comments(sql, include_comments=True):
    """
    Wraps SQL comments in special tokens for LLM parsing.
    Blocks: /* ... */ -> ~cm ... ~endcm
    Lines: -- ... -> ~cml ... ~endcml
    """
    if not include_comments:
        # Simple removal if not wanted
        sql = re.sub(r'/\*.*?\*/', '', sql, flags=re.DOTALL)
        sql = re.sub(r'--.*', '', sql)
        return sql

    # Handle Block Comments
    sql = re.sub(r'/\*(.*?)\*/', r'~cm \1 ~endcm', sql, flags=re.DOTALL)
    
    # Handle Single Line Comments
    # We wrap them so they don't depend on newlines after minification
    sql = re.sub(r'--\s*(.*)', r'~cml \1 ~endcml', sql)
    
    return sql
