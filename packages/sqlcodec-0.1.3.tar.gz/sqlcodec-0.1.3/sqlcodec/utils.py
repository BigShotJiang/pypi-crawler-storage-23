def detect_dialect(sql):
    """
    Heuristic to detect SQL dialect.
    Returns 'sqlserver', 'postgres', or None.
    """
    if "[" in sql or "GO" in sql.upper() or "IDENTITY" in sql.upper():
        return "sqlserver"
    if "::" in sql or "SERIAL" in sql.upper() or "TIMESTAMPTZ" in sql.upper():
        return "postgres"
    return None

def get_dialect_map(dialect_name):
    from .dialects.sqlserver import SQLServerDialect
    from .dialects.postgres import PostgresDialect
    
    if dialect_name == "sqlserver":
        return SQLServerDialect.MAP
    if dialect_name == "postgres":
        return PostgresDialect.MAP
    return {}
