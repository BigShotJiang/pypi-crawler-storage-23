import re
from .mappings import CORE_MAP
from .comments import wrap_comments
from .utils import detect_dialect, get_dialect_map

def compress(sql, dialect=None, include_comments=True):
    """
    Compresses SQL DDL using Regex mappings.
    - dialect: 'sqlserver', 'postgres', or None (auto-detect).
    - include_comments: Set to False to strip comments entirely.
    """
    # 1. Wrap or strip comments
    sql = wrap_comments(sql, include_comments=include_comments)
    
    # 2. Dialect handling
    if dialect is None:
        dialect = detect_dialect(sql)
    
    dialect_map = get_dialect_map(dialect)
    full_map = {**CORE_MAP, **dialect_map}
    
    # 3. Replace keywords (case-insensitive)
    # Sort keys by length descending
    sorted_keys = sorted(full_map.keys(), key=len, reverse=True)
    for key in sorted_keys:
        token = full_map[key]
        # Use \b to ensure we only replace full words, not parts of identifiers
        pattern = re.compile(rf'\b{re.escape(key)}\b', re.IGNORECASE)
        sql = pattern.sub(token, sql)
    
    # 4. Minification while preserving key newlines
    # Mark semicolons to preserve their newlines later
    sql = sql.replace(";", ";[NEWLINE_MARKER]")
    
    # Replace all other newlines and multiple spaces with a single space
    sql = re.sub(r'[\r\n\t]+', ' ', sql)
    sql = re.sub(r' +', ' ', sql)
    
    # Restore semicolon newlines
    sql = sql.replace("[NEWLINE_MARKER]", "\n")
    
    return sql.strip()
