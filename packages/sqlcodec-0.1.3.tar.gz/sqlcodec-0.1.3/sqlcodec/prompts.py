from .mappings import CORE_MAP
from .utils import get_dialect_map

def get_system_prompt(dialect=None):
    """
    Generates a system prompt to help an LLM interpret compressed SQL.
    """
    dialect_map = get_dialect_map(dialect)
    full_map = {**CORE_MAP, **dialect_map}
    
    # Format the mapping for the LLM
    mapping_str = "\n".join([f"{token}: {keyword}" for keyword, token in full_map.items()])
    
    prompt = f"""
You are a SQL expert. I will provide you with compressed SQL DDL using a tokenized system called 'sqlcodec'.
Please use the following mapping to interpret the tokens:

{mapping_str}

Additional Tokens:
~cml ... ~endcml : Single-line comment
~cm ... ~endcm : Block comment

When I send you compressed DDL, you should treat it as valid SQL for the {dialect or 'standard'} dialect.
""".strip()
    return prompt
