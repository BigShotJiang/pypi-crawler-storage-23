# sysnet_pyutils — veřejné API

# Verze
from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("sysnet-pyutils")
except PackageNotFoundError:
    __version__ = "unknown"

# Utility funkce a třídy
from sysnet_pyutils.barcode import code39_mod36, code39_pid

# Konstanty
from sysnet_pyutils.constants import (
    CONFIG_API_KEYS,
    CONFIG_CERT,
    CONFIG_CRZP,
    CONFIG_DATABASE,
    CONFIG_DDS,
    CONFIG_DOCUMENTS,
    CONFIG_FORM,
    CONFIG_HOST,
    CONFIG_KEY,
    CONFIG_MONGO,
    CONFIG_PASSWD,
    CONFIG_PASSWORD,
    CONFIG_PATH,
    CONFIG_PORT,
    CONFIG_POSTGIS,
    CONFIG_POSTGRES,
    CONFIG_REPID,
    CONFIG_ROOT_PATH,
    CONFIG_TYPE,
    CONFIG_URL,
    CONFIG_USERNAME,
    CONFIG_WSDL,
)

# Data utility
from sysnet_pyutils.data_utils import (
    address_to_string,
    adjust_datetime_to_utc,
    convert_cz_to_date,
    convert_cz_to_datetime,
    convert_iso_to_date,
    convert_iso_to_datetime,
    dict_convert_date_to_str,
    get_dict_code_value_list,
    get_dict_item_value,
    get_dict_item_value_list,
    get_dict_value,
    get_dict_value_as_person_type,
    get_dict_value_bool,
    get_dict_value_code,
    get_dict_value_date,
    get_dict_value_datetime,
    get_dict_value_email,
    get_dict_value_float,
    get_dict_value_int,
    get_dict_value_list,
    get_dict_value_string,
    get_dict_value_uuid,
    get_object_attr,
    paging_to_mongo,
    recursive_update,
)

# Domino
from sysnet_pyutils.domino import DdsDictionaryFactory

# Geo transformace
from sysnet_pyutils.geo import JTSK, Wgs84

# GlobalModel
from sysnet_pyutils.globalmodel import PRAGUE_TZ, GlobalModel, normalize_dt_deep

# Identifikátory a čárové kódy
from sysnet_pyutils.ident import check_pid, correct_pid, generate_id12, generate_pid

# Datové modely
from sysnet_pyutils.models.general import (
    AclLevelEnum,
    AclType,
    ApiError,
    BaseEnum,
    BasinType,
    CodeValueType,
    ContainerHistoryItemType,
    ErrorModel,
    GeoPointJtskType,
    GeoPointType,
    LinkedType,
    ListTypeBase,
    LocationType,
    LogItemType,
    MailAddressType,
    MapSheet50Type,
    MetadataEssentialType,
    MetadataType,
    MetadataTypeBase,
    MetadataTypeEntry,
    PersonBaseType,
    PersonCoreType,
    PersonTypeEnum,
    PhoneNumberType,
    RegionalValueType,
    TimeLimitedType,
    UserType,
    WorkflowType,
)

# Syslog
from sysnet_pyutils.syslog import SyslogFactory
from sysnet_pyutils.utils import (  # API klíče; Konverze; Hashe; Base64; Validace; Datum a čas; LDAP; URL a řetězce; Identifikátory; XML
    Config,
    ConfigError,
    ConfigFlag,
    Context,
    Log,
    LoggedObject,
    Singleton,
    api_key_generate,
    api_key_next,
    api_keys_init,
    cites_to_order,
    convert_hex_to_int,
    cron_to_dict,
    cs_bool,
    date_to_datetime,
    date_to_datetime_utc,
    date_to_iso,
    datetime_now,
    decode_b64_string,
    decode_b64_to_file,
    dict_to_xml,
    encode_file_b64,
    encode_string_b64,
    gmt_now,
    hash_md5,
    hash_sha1,
    hash_sha256,
    hash_sha384,
    id12_next,
    increment_date,
    is_base64,
    is_valid_cz_permit_id,
    is_valid_email,
    is_valid_ico,
    is_valid_pid,
    is_valid_unid,
    is_valid_uuid,
    iso_to_local_datetime,
    local_datetime,
    local_now,
    order_to_cites,
    parse_ldap_name,
    pid_check,
    pid_correct,
    pid_factory,
    pid_next,
    remove_empty,
    repair_ico,
    timestamp,
    to_base64,
    to_camel,
    to_camel_dict,
    to_snake,
    to_snake_dict,
    today,
    tomorrow,
    unique_list,
    url_safe,
    uuid_factory,
    uuid_next,
    who_am_i,
    xml_to_dict,
)
