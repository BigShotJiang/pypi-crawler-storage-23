from __future__ import annotations

from typing import Any

from pydantic import BaseModel, field_validator

from .timeutils import normalize_dt_deep


class GlobalModel(BaseModel):
    """
    Globální model s jednotným pravidlem pro práci s `datetime`:
    - pokud hodnota je naivní (bez tzinfo), považuje ji za Europe/Prague,
    - následně ji vždy převede do UTC,
    - pravidlo se aplikuje rekurzivně uvnitř list/tuple/dict/set.
    """

    @field_validator("*", mode="before")
    @classmethod
    def normalize_datetimes(cls, v: Any):
        return normalize_dt_deep(v)
