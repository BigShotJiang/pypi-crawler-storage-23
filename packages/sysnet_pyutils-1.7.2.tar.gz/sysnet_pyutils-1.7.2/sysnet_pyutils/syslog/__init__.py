from .factory import SyslogFactory
