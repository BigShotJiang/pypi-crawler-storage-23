from __future__ import annotations

from datetime import datetime, timedelta

# from zoneinfo import ZoneInfo
from pytz import timezone, utc

from sysnet_pyutils.globalmodel.models import ExampleModel
from sysnet_pyutils.globalmodel.timeutils import PRAGUE_TZ


def is_utc(dt: datetime) -> bool:
    return dt.tzinfo is not None and dt.utcoffset() == timedelta(0)


def test_recursive_naive_datetime_is_converted_to_utc():
    naive = datetime(2026, 1, 10, 12, 0, 0)  # leden -> CET (UTC+1)
    m = ExampleModel(ts=naive)
    assert is_utc(m.ts)
    assert m.ts == datetime(2026, 1, 10, 11, 0, 0, tzinfo=utc)


def test_recursive_prague_aware_converted_correctly():
    # CEST (UTC+2)
    prg = PRAGUE_TZ.localize(datetime(2026, 6, 10, 12, 0, 0))

    m = ExampleModel(ts=prg)
    assert is_utc(m.ts)
    assert m.ts == datetime(2026, 6, 10, 10, 0, 0, tzinfo=utc)


def test_recursive_other_zones_converted_correctly():

    # ny = datetime(2026, 1, 10, 12, 0, 0, tzinfo=timezone("America/New_York"))
    ny = timezone("America/New_York").localize(datetime(2026, 1, 10, 12, 0, 0))

    m = ExampleModel(ts=ny)
    assert is_utc(m.ts)
    assert m.ts == datetime(2026, 1, 10, 17, 0, 0, tzinfo=utc)


def test_recursive_list_tuple_dict_set_normalization():
    naive_cet = datetime(2026, 1, 10, 12, 0, 0)
    naive_cest = datetime(2026, 6, 10, 12, 0, 0)
    # aware_ny   = datetime(2026, 1, 10, 12, 0, 0, tzinfo=timezone("America/New_York"))
    aware_ny = timezone("America/New_York").localize(datetime(2026, 1, 10, 12, 0, 0))

    m = ExampleModel(
        ts_list=[naive_cet, naive_cest, aware_ny],
        ts_map={"x": naive_cet, "y": naive_cest, "z": aware_ny},
        ts_tuple=(naive_cet, aware_ny),
        ts_set={naive_cet, aware_ny},
    )

    assert all(is_utc(v) for v in m.ts_list)
    assert m.ts_list[0].hour == 11  # CET
    assert m.ts_list[1].hour == 10  # CEST
    assert m.ts_list[2].hour == 17  # NY

    assert all(is_utc(v) for v in m.ts_map.values())

    assert isinstance(m.ts_tuple, tuple)
    assert all(is_utc(v) for v in m.ts_tuple)

    assert isinstance(m.ts_set, set)
    assert all(is_utc(v) for v in m.ts_set)


def test_recursive_nested_structures_any_depth():
    deep = {
        "level1": [
            {"level2": datetime(2026, 1, 10, 12, 0, 0)},  # CET
            [{"level3": datetime(2026, 6, 10, 12, 0, 0)}],  # CEST
        ],
        "another": {"x": [timezone("America/New_York").localize(datetime(2026, 1, 10, 12, 0, 0))]},
    }

    m = ExampleModel(payload=deep)

    dt1 = m.payload["level1"][0]["level2"]
    dt2 = m.payload["level1"][1][0]["level3"]
    dt3 = m.payload["another"]["x"][0]

    for dt in (dt1, dt2, dt3):
        assert is_utc(dt)

    assert dt1.hour == 11  # CET -> 11:00Z
    assert dt2.hour == 10  # CEST -> 10:00Z
    assert dt3.hour == 17  # NY -> 17:00Z


def test_recursive_idempotent_for_already_normalized():
    utc_dt = datetime(2026, 2, 13, 9, 0, 0, tzinfo=utc)
    m1 = ExampleModel(ts=utc_dt)
    m2 = ExampleModel(ts=m1.ts)
    assert m2.ts == utc_dt
    assert is_utc(m2.ts)


def test_recursive_non_datetime_values_untouched():
    for value in (None, 0, 3.14, "hello", True, {"a": 1}, [1, 2]):
        m = ExampleModel(any_value=value)
        assert m.any_value == value
