#!/usr/bin/env python3


from sysnet_pyutils.domino import DdsDictionaryFactory


class TestDominoMissingBranches:
    def test_get_value_float_uses_spare_when_primary_zero(self):
        data = {"a": "0", "b": "1.5"}
        f = DdsDictionaryFactory(data)
        assert f.get_value_float("a", spare_itemname="b") == 1.5

    def test_get_value_date_invalid_returns_none(self):
        data = {"d": "not-a-date"}
        f = DdsDictionaryFactory(data)
        assert f.get_value_date("d") is None

    def test_get_value_datetime_invalid_returns_none(self):
        data = {"dt": "not-a-datetime"}
        f = DdsDictionaryFactory(data)
        assert f.get_value_datetime("dt") is None

    def test_get_value_date_none_returns_none(self):
        data = {"d": None}
        f = DdsDictionaryFactory(data)
        assert f.get_value_date("d") is None

    def test_get_value_datetime_none_returns_none(self):
        data = {"dt": None}
        f = DdsDictionaryFactory(data)
        assert f.get_value_datetime("dt") is None
