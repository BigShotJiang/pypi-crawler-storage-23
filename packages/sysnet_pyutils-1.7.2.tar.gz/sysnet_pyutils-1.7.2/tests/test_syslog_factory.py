"""
Testy pro sysnet_pyutils.syslog.factory — SyslogFactory
Pokrytí: syslog/factory.py (31% → ~95%)

Síťová volání (TCP/UDP socket) jsou mockována přes unittest.mock a pytest-asyncio.
SyslogFactory je Singleton — každý test dostane čerstvou instanci přes fixture.
"""

import asyncio
import logging
import os
import socket
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from sysnet_pyutils.utils import Singleton

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def reset_syslog_singleton():
    """SyslogFactory je Singleton — čistíme před i po každém testu."""
    if hasattr(Singleton, "_instances"):
        Singleton._instances.clear()
    yield
    if hasattr(Singleton, "_instances"):
        Singleton._instances.clear()


@pytest.fixture
def factory():
    """Čerstvá SyslogFactory s výchozím nastavením."""
    from sysnet_pyutils.syslog.factory import SyslogFactory

    return SyslogFactory(server="localhost", port=514, udp=True)


def run_async(coro):
    """Pomocná funkce pro spuštění async kódu v synchronním testu."""
    return asyncio.get_event_loop().run_until_complete(coro)


# ---------------------------------------------------------------------------
# Inicializace
# ---------------------------------------------------------------------------


class TestSyslogFactoryInit:

    def test_vytvoreni_factory(self, factory):
        """SyslogFactory lze vytvořit bez výjimky."""
        assert factory is not None

    def test_factory_ma_server(self, factory):
        """Factory uloží server."""
        assert factory.server == "localhost"

    def test_factory_ma_port(self, factory):
        """Factory uloží port."""
        assert factory.port == 514

    def test_factory_ma_hostname(self, factory):
        """Factory uloží hostname počítače."""
        assert factory.hostname == socket.gethostname()

    def test_factory_ma_pid(self, factory):
        """Factory uloží PID procesu."""
        assert factory.pid == os.getpid()

    def test_factory_vlastni_pid(self):
        """Factory přijme vlastní PID."""
        from sysnet_pyutils.syslog.factory import SyslogFactory

        f = SyslogFactory(pid=9999)
        assert f.pid == 9999

    def test_factory_enabled_default(self, factory):
        """Factory je po inicializaci povolena."""
        assert factory.enabled is True

    def test_factory_tag_default(self, factory):
        """Výchozí tag je 'python-app'."""
        assert factory.tag == "python-app"

    def test_factory_vlastni_tag(self):
        """Factory přijme vlastní tag."""
        from sysnet_pyutils.syslog.factory import SyslogFactory

        f = SyslogFactory(tag="moje-app")
        assert f.tag == "moje-app"

    def test_factory_udp_default(self, factory):
        """Výchozí protokol je UDP."""
        assert factory.udp is True

    def test_factory_tcp_mode(self):
        """Factory lze nastavit na TCP."""
        from sysnet_pyutils.syslog.factory import SyslogFactory

        f = SyslogFactory(udp=False)
        assert f.udp is False

    def test_factory_je_singleton(self):
        """SyslogFactory je Singleton."""
        from sysnet_pyutils.syslog.factory import SyslogFactory

        f1 = SyslogFactory(server="a")
        f2 = SyslogFactory(server="b")
        assert f1 is f2

    def test_factory_ma_log(self, factory):
        """Factory má atribut log (Logger)."""
        assert isinstance(factory.log, logging.Logger)


# ---------------------------------------------------------------------------
# Severity a Facility konstanty
# ---------------------------------------------------------------------------


class TestSyslogConstants:

    def test_severity_konstanty(self, factory):
        """Severity konstanty mají správné hodnoty."""
        from sysnet_pyutils.syslog.factory import SyslogFactory

        assert SyslogFactory.SEVERITY_EMERGENCY == 0
        assert SyslogFactory.SEVERITY_ALERT == 1
        assert SyslogFactory.SEVERITY_CRITICAL == 2
        assert SyslogFactory.SEVERITY_ERROR == 3
        assert SyslogFactory.SEVERITY_WARNING == 4
        assert SyslogFactory.SEVERITY_NOTICE == 5
        assert SyslogFactory.SEVERITY_INFO == 6
        assert SyslogFactory.SEVERITY_DEBUG == 7

    def test_facility_konstanty(self, factory):
        """Facility konstanty mají správné hodnoty."""
        from sysnet_pyutils.syslog.factory import SyslogFactory

        assert SyslogFactory.FACILITY_USER == 1
        assert SyslogFactory.FACILITY_LOCAL0 == 16


# ---------------------------------------------------------------------------
# enable / disable
# ---------------------------------------------------------------------------


class TestSyslogFactoryEnableDisable:

    def test_disable_nastavi_enabled_false(self, factory):
        """disable() nastaví enabled=False."""
        factory.disable()
        assert factory.enabled is False

    def test_enable_nastavi_enabled_true(self, factory):
        """enable() nastaví enabled=True."""
        factory.disable()
        factory.enable()
        assert factory.enabled is True

    def test_enable_kdyz_uz_enabled(self, factory):
        """enable() na již enabled factory nezpůsobí chybu."""
        factory.enable()
        assert factory.enabled is True


# ---------------------------------------------------------------------------
# _format_message
# ---------------------------------------------------------------------------


class TestSyslogFormatMessage:

    def test_format_message_obsahuje_hostname(self, factory):
        """Formátovaná zpráva obsahuje hostname."""
        msg = factory._format_message("test", factory.SEVERITY_INFO)
        assert factory.hostname in msg

    def test_format_message_obsahuje_zpravy(self, factory):
        """Formátovaná zpráva obsahuje původní text."""
        msg = factory._format_message("Ahoj světe", factory.SEVERITY_INFO)
        assert "Ahoj světe" in msg

    def test_format_message_obsahuje_tag(self, factory):
        """Formátovaná zpráva obsahuje výchozí tag."""
        msg = factory._format_message("test", factory.SEVERITY_INFO)
        assert "python-app" in msg

    def test_format_message_vlastni_tag(self, factory):
        """Formátovaná zpráva obsahuje vlastní tag."""
        msg = factory._format_message("test", factory.SEVERITY_INFO, tag="my-app")
        assert "my-app" in msg

    def test_format_message_obsahuje_pid(self, factory):
        """Formátovaná zpráva obsahuje PID."""
        msg = factory._format_message("test", factory.SEVERITY_INFO)
        assert str(factory.pid) in msg

    def test_format_message_vlastni_pid(self, factory):
        """Formátovaná zpráva použije vlastní PID."""
        msg = factory._format_message("test", factory.SEVERITY_INFO, pid=12345)
        assert "12345" in msg

    def test_format_message_priority_format(self, factory):
        """Zpráva začíná <PRI> tagem."""
        pri = factory.facility * 8 + factory.SEVERITY_INFO
        msg = factory._format_message("test", factory.SEVERITY_INFO)
        assert msg.startswith(f"<{pri}>")

    def test_format_message_emergency_pri(self, factory):
        """EMERGENCY severity má správné PRI číslo."""
        pri = factory.facility * 8 + factory.SEVERITY_EMERGENCY
        msg = factory._format_message("test", factory.SEVERITY_EMERGENCY)
        assert msg.startswith(f"<{pri}>")

    def test_format_message_obsahuje_timestamp(self, factory):
        """Formátovaná zpráva obsahuje timestamp."""
        import datetime

        expected_prefix = datetime.datetime.now().strftime("%b")
        msg = factory._format_message("test", factory.SEVERITY_INFO)
        assert expected_prefix in msg


# ---------------------------------------------------------------------------
# send() — UDP (mock)
# ---------------------------------------------------------------------------


class TestSyslogSendUDP:

    def test_send_udp_uspesne_vraci_true(self, factory):
        """send() přes UDP vrátí True při úspěchu."""
        factory._send_udp = AsyncMock(return_value=True)
        factory._send_tcp = AsyncMock(return_value=False)
        result = run_async(factory.send("Test zpráva"))
        assert result is True

    def test_send_disabled_vraci_false(self, factory):
        """send() vrátí False pokud je factory disabled."""
        factory.disable()
        factory._send_udp = AsyncMock(return_value=True)
        result = run_async(factory.send("Test"))
        assert result is False
        factory._send_udp.assert_not_called()

    def test_send_udp_fallback_na_tcp(self, factory):
        """Pokud UDP selže, zkusí TCP."""
        factory._send_udp = AsyncMock(return_value=False)
        factory._send_tcp = AsyncMock(return_value=True)
        result = run_async(factory.send("Test"))
        assert result is True
        factory._send_tcp.assert_called_once()

    def test_send_udp_i_tcp_selze_vraci_false(self, factory):
        """Pokud selže UDP i TCP, vrátí False."""
        factory._send_udp = AsyncMock(return_value=False)
        factory._send_tcp = AsyncMock(return_value=False)
        result = run_async(factory.send("Test"))
        assert result is False

    def test_send_predava_severity(self, factory):
        """send() předá severity do _format_message."""
        factory._send_udp = AsyncMock(return_value=True)
        result = run_async(factory.send("Test", severity=factory.SEVERITY_ERROR))
        assert result is True


# ---------------------------------------------------------------------------
# send() — TCP mode (mock)
# ---------------------------------------------------------------------------


class TestSyslogSendTCP:

    def test_send_tcp_mode_uspesne(self):
        """V TCP módu send() vrátí True při úspěchu."""
        from sysnet_pyutils.syslog.factory import SyslogFactory

        f = SyslogFactory(udp=False)
        f._send_tcp = AsyncMock(return_value=True)
        f._send_udp = AsyncMock(return_value=False)
        result = run_async(f.send("Test"))
        assert result is True
        f._send_tcp.assert_called_once()

    def test_send_tcp_fallback_na_udp(self):
        """V TCP módu, pokud TCP selže, zkusí UDP."""
        from sysnet_pyutils.syslog.factory import SyslogFactory

        f = SyslogFactory(udp=False)
        f._send_tcp = AsyncMock(return_value=False)
        f._send_udp = AsyncMock(return_value=True)
        result = run_async(f.send("Test"))
        assert result is True


# ---------------------------------------------------------------------------
# _send_tcp a _send_udp — skutečné mock socket
# ---------------------------------------------------------------------------


class TestSyslogSendTcpImpl:

    def test_send_tcp_uspesne(self, factory):
        """_send_tcp() vrátí True při úspěšném TCP připojení."""
        mock_writer = MagicMock()  # synchronní write/close
        mock_writer.drain = AsyncMock()  # drain je coroutine
        mock_writer.wait_closed = AsyncMock()  # wait_closed je coroutine
        mock_reader = MagicMock()
        with patch("asyncio.open_connection", new=AsyncMock(return_value=(mock_reader, mock_writer))):
            result = run_async(factory._send_tcp("<14>Jan  1 00:00:00 host tag[1]: msg"))
        assert result is True
        mock_writer.write.assert_called_once()
        mock_writer.close.assert_called_once()

    def test_send_tcp_selze_vraci_false(self, factory):
        """_send_tcp() vrátí False při výjimce."""
        with patch("asyncio.open_connection", side_effect=ConnectionRefusedError("refused")):
            result = run_async(factory._send_tcp("msg"))
        assert result is False

    def test_send_tcp_timeout_vraci_false(self, factory):
        """_send_tcp() vrátí False při TimeoutError."""
        with patch("asyncio.open_connection", side_effect=TimeoutError("timeout")):
            result = run_async(factory._send_tcp("msg"))
        assert result is False


class TestSyslogSendUdpImpl:

    def test_send_udp_uspesne(self, factory):
        """_send_udp() vrátí True při úspěšném UDP odeslání."""
        mock_transport = MagicMock()
        mock_protocol = MagicMock()

        async def mock_create_datagram(*args, **kwargs):
            return mock_transport, mock_protocol

        with patch.object(asyncio.get_event_loop(), "create_datagram_endpoint", new=mock_create_datagram):
            result = run_async(factory._send_udp("<14>msg"))

        assert result is True
        mock_transport.sendto.assert_called_once()
        mock_transport.close.assert_called_once()

    def test_send_udp_selze_vraci_false(self, factory):
        """_send_udp() vrátí False při výjimce."""

        async def mock_fail(*args, **kwargs):
            raise OSError("UDP failed")

        with patch.object(asyncio.get_event_loop(), "create_datagram_endpoint", new=mock_fail):
            result = run_async(factory._send_udp("msg"))

        assert result is False


# ---------------------------------------------------------------------------
# Wrapper metody (log_info, log_error, log_critical, log_debug)
# ---------------------------------------------------------------------------


class TestSyslogWrappers:

    def test_log_info_vola_send(self, factory):
        """log_info() zavolá send() se SEVERITY_INFO."""
        factory.send = AsyncMock(return_value=True)
        run_async(factory.log_info("Info zpráva"))
        factory.send.assert_called_once_with("Info zpráva", severity=factory.SEVERITY_INFO, tag=None, pid=None)

    def test_log_error_vola_send(self, factory):
        """log_error() zavolá send() se SEVERITY_ERROR."""
        factory.send = AsyncMock(return_value=True)
        run_async(factory.log_error("Error zpráva"))
        factory.send.assert_called_once_with("Error zpráva", severity=factory.SEVERITY_ERROR, tag=None, pid=None)

    def test_log_critical_vola_send(self, factory):
        """log_critical() zavolá send() se SEVERITY_CRITICAL."""
        factory.send = AsyncMock(return_value=True)
        run_async(factory.log_critical("Critical zpráva"))
        factory.send.assert_called_once_with("Critical zpráva", severity=factory.SEVERITY_CRITICAL, tag=None, pid=None)

    def test_log_debug_vola_send(self, factory):
        """log_debug() zavolá send() se SEVERITY_DEBUG."""
        factory.send = AsyncMock(return_value=True)
        run_async(factory.log_debug("Debug zpráva"))
        factory.send.assert_called_once_with("Debug zpráva", severity=factory.SEVERITY_DEBUG, tag=None, pid=None)

    def test_log_info_s_tagem(self, factory):
        """log_info() předá vlastní tag."""
        factory.send = AsyncMock(return_value=True)
        run_async(factory.log_info("msg", tag="myapp"))
        factory.send.assert_called_once_with("msg", severity=factory.SEVERITY_INFO, tag="myapp", pid=None)

    def test_log_error_s_pid(self, factory):
        """log_error() předá vlastní pid."""
        factory.send = AsyncMock(return_value=True)
        run_async(factory.log_error("msg", pid=42))
        factory.send.assert_called_once_with("msg", severity=factory.SEVERITY_ERROR, tag=None, pid=42)

    def test_log_info_disabled(self, factory):
        """log_info() nezpůsobí chybu, i když je factory disabled."""
        factory.disable()
        factory.send = AsyncMock(return_value=False)
        run_async(factory.log_info("test"))
        factory.send.assert_called_once()
