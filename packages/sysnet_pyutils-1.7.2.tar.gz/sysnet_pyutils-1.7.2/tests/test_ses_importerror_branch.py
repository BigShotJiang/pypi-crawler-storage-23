#!/usr/bin/env python3

import builtins
import importlib
import sys


def test_ses_module_sets_flag_false_when_boto3_import_fails(monkeypatch):
    """
    Cíl: sysnet_pyutils/ses.py řádky 5-6 (except ImportError → _AWS_AVAILABLE = False)
    Řešení: při importu vynutit ImportError pro 'boto3' (a související moduly).
    """
    real_import = builtins.__import__

    def fake_import(name, *args, **kwargs):
        if name in {"boto3", "botocore", "botocore.exceptions"}:
            raise ImportError("forced for test")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", fake_import)

    sys.modules.pop("sysnet_pyutils.ses", None)
    mod = importlib.import_module("sysnet_pyutils.ses")

    assert mod._AWS_AVAILABLE is False
