"""
Testy pro modul sysnet_pyutils.models.general
"""

from datetime import datetime

import pytest

from sysnet_pyutils.models.general import (
    AclLevelEnum,
    AclType,
    CodeValueType,
    GeoPointType,
    LocationType,
    LogItemType,
    MetadataType,
    PersonBaseType,
    PersonTypeEnum,
    UserType,
)


class TestBaseEnum:
    """Testy pro BaseEnum"""

    def test_has_value_returns_true_for_existing(self):
        assert PersonTypeEnum.has_value("legalEntity") is True
        assert PersonTypeEnum.has_value("naturalPerson") is True

    def test_has_value_returns_false_for_nonexisting(self):
        assert PersonTypeEnum.has_value("invalidValue") is False


class TestPersonTypeEnum:
    """Testy pro PersonTypeEnum"""

    def test_all_person_types_defined(self):
        expected = [
            "legalEntity",
            "legalEntityWithoutIco",
            "foreignLegalEntity",
            "naturalPerson",
            "businessNaturalPerson",
            "foreignNaturalPerson",
            "",
        ]
        for type_val in expected:
            assert PersonTypeEnum.has_value(type_val)


class TestCodeValueType:
    """Testy pro CodeValueType"""

    def test_code_value_type_initialization(self):
        cv = CodeValueType(code="CZ", value="Czech Republic")
        assert cv.code == "CZ"
        assert cv.value == "Czech Republic"

    def test_code_value_type_equality(self):
        cv1 = CodeValueType(code="CZ", value="Czech Republic")
        cv2 = CodeValueType(code="CZ", value="Czech Republic")
        cv3 = CodeValueType(code="SK", value="Slovakia")
        assert cv1 == cv2
        assert cv1 != cv3

    def test_code_value_type_load_data(self):
        cv = CodeValueType()
        cv.load_data(("CZ", "Czech Republic"))
        assert cv.code == "CZ"
        assert cv.value == "Czech Republic"


class TestUserType:
    """Testy pro UserType"""

    def test_user_type_initialization(self):
        user = UserType(identifier="ABC123", name="Jan Novák", email="jan@example.com")
        assert user.identifier == "ABC123"
        assert user.name == "Jan Novák"

    def test_user_type_validation(self):
        user = UserType(email="valid@example.com")
        assert user.email == "valid@example.com"
        with pytest.raises(Exception):
            UserType(email="invalid-email")


class TestAclType:
    """Testy pro AclType"""

    def test_acl_type_initialization(self):
        acl = AclType(name="user@example.com", level=AclLevelEnum.READ, can_delete=False)
        assert acl.name == "user@example.com"
        assert acl.level == AclLevelEnum.READ
        assert acl.can_delete is False


class TestGeoPointType:
    """Testy pro GeoPointType"""

    def test_geo_point_initialization(self):
        point = GeoPointType(lat=50.0755, lon=14.4378)
        assert point.lat == 50.0755
        assert point.lon == 14.4378


class TestLocationType:
    """Testy pro LocationType"""

    def test_location_type_basic(self):
        location = LocationType(street="Main Street 123", city="Prague", zip="110 00")
        assert location.street == "Main Street 123"
        assert location.city == "Prague"

    def test_location_type_with_wgs(self):
        location = LocationType(city="Prague", wgs=GeoPointType(lat=50.0755, lon=14.4378))
        assert location.wgs is not None
        assert location.wgs.lat == 50.0755


class TestPersonBaseType:
    """Testy pro PersonBaseType"""

    def test_person_base_type_basic(self):
        person = PersonBaseType(name="Test Company", ico="12345678", email="info@test.com")
        assert person.name == "Test Company"
        assert person.ico == "12345678"

    def test_make_identifier_from_unid(self):
        person = PersonBaseType(unid="3005277CB984B7FFC12587890060E2BF")
        result = person.make_identifier()
        assert result == "3005277CB984B7FFC12587890060E2BF"

    def test_make_identifier_from_pid(self):
        from sysnet_pyutils.utils import pid_next

        pid = pid_next()
        person = PersonBaseType(pid=pid)
        result = person.make_identifier()
        assert result == pid

    def test_make_identifier_from_uuid(self):
        person = PersonBaseType(uuid="550e8400-e29b-41d4-a716-446655440000")
        result = person.make_identifier()
        assert result == "550e8400-e29b-41d4-a716-446655440000"


class TestLogItemType:
    """Testy pro LogItemType"""

    def test_log_item_type_creation(self):
        log = LogItemType(originator="SYSTEM", message="Test message")
        assert log.originator == "SYSTEM"
        assert log.message == "Test message"
        assert log.timestamp is not None

    def test_log_item_type_str(self):
        log = LogItemType(timestamp=datetime(2023, 5, 15, 12, 30), originator="USER", message="Action")
        str_val = str(log)
        assert "USER" in str_val
        assert "Action" in str_val


class TestMetadataType:
    """Testy pro MetadataType"""

    def test_metadata_type_creation(self):
        metadata = MetadataType(title="Test Document", form="certificate")
        assert metadata.title == "Test Document"
        assert metadata.form == "certificate"
        assert metadata.date_created is not None

    def test_metadata_type_authorized(self):
        metadata = MetadataType(authorized=True, date_authorized=datetime.now())
        assert metadata.authorized is True
        assert metadata.date_authorized is not None


class TestIntegration:
    """Integrační testy"""

    def test_complete_person_with_location(self):
        person = PersonBaseType(
            name="Test Company",
            ico="12345678",
            location=LocationType(
                street="Main Street 123",
                city="Prague",
                wgs=GeoPointType(lat=50.0755, lon=14.4378),
                country=CodeValueType(code="CZ", value="Czech Republic"),
            ),
        )
        assert person.name == "Test Company"
        assert person.location.street == "Main Street 123"
        assert person.location.wgs.lat == 50.0755

    def test_metadata_with_all_features(self):
        metadata = MetadataType(
            title="Important Document",
            id_no="23CZ123456",
            authorized=True,
            acl=[AclType(name="reader", level=AclLevelEnum.READ)],
            contributor=UserType(name="Jan Novák", email="jan@example.com"),
        )
        assert metadata.title == "Important Document"
        assert metadata.authorized is True
        assert len(metadata.acl) == 1
        assert metadata.contributor.name == "Jan Novák"
