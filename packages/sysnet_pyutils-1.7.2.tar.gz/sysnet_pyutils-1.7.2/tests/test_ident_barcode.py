"""
Testy pro moduly sysnet_pyutils.ident a sysnet_pyutils.barcode
"""

from sysnet_pyutils.barcode import code39_mod36, code39_pid
from sysnet_pyutils.ident import (
    DIGITS36,
    check_pid,
    correct_pid,
    generate_id12,
    generate_pid,
    generate_tiny_uuid,
    to_id_string,
)

INVALID_PID = "SNT7ANRSHL6X"
VALID_PID = "SNT7ANRSHL63"


class TestToIdString:
    """Testy pro konverzi čísla na alfanumerický string"""

    def test_to_id_string_converts_zero(self):
        assert to_id_string(0) == "0"

    def test_to_id_string_converts_single_digit(self):
        assert to_id_string(5) == "5"
        assert to_id_string(9) == "9"

    def test_to_id_string_converts_to_letters(self):
        assert to_id_string(10) == "A"
        assert to_id_string(35) == "Z"

    def test_to_id_string_converts_large_numbers(self):
        result = to_id_string(100)
        assert result is not None
        assert len(result) > 0
        for char in result:
            assert char in DIGITS36


class TestGenerateTinyUUID:
    """Testy pro generování 12místného UUID"""

    def test_generate_tiny_uuid_length(self):
        uuid = generate_tiny_uuid()
        assert len(uuid) == 12

    def test_generate_tiny_uuid_contains_valid_chars(self):
        uuid = generate_tiny_uuid()
        for char in uuid:
            assert char in DIGITS36

    def test_generate_tiny_uuid_is_unique(self):
        uuid1 = generate_tiny_uuid()
        uuid2 = generate_tiny_uuid()
        assert uuid1 != uuid2


class TestGenerateId12:
    """Testy pro generování 12místného identifikátoru s prefixem"""

    def test_generate_id12_with_prefix(self):
        id12 = generate_id12("ABC")
        assert len(id12) == 12
        assert id12.startswith("ABC")

    def test_generate_id12_with_none_prefix(self):
        id12 = generate_id12(None)
        assert len(id12) == 12
        assert id12.startswith("SNT")

    def test_generate_id12_truncates_long_prefix(self):
        id12 = generate_id12("ABCDEFG")
        assert len(id12) == 12
        assert id12.startswith("ABC")

    def test_generate_id12_replaces_dollar_sign(self):
        for _ in range(100):
            id12 = generate_id12("TST")
            assert "$" not in id12

    def test_generate_id12_is_valid_pid(self):
        id12 = generate_id12("TST")
        assert check_pid(id12)


class TestCheckPID:
    """Testy pro kontrolu PID"""

    def test_check_pid_accepts_valid(self):
        pid = generate_pid()
        assert check_pid(pid) is True

    def test_check_pid_rejects_wrong_length(self):
        assert check_pid("SHORT") is False
        assert check_pid("TOOLONGSTRING") is False

    def test_check_pid_rejects_bad_checksum(self):
        assert check_pid(INVALID_PID) is False


class TestCorrectPID:
    """Testy pro opravu PID"""

    def test_correct_pid_fixes_checksum(self):
        invalid_pid = INVALID_PID
        corrected = correct_pid(invalid_pid)
        assert check_pid(corrected) is True
        assert corrected[:11] == invalid_pid[:11]

    def test_correct_pid_leaves_valid_unchanged(self):
        valid_pid = generate_pid()
        corrected = correct_pid(valid_pid)
        assert corrected == valid_pid

    def test_correct_pid_converts_lowercase(self):
        lowercase_pid = "abc12345678x"
        corrected = correct_pid(lowercase_pid)
        assert corrected.isupper()
        assert check_pid(corrected)


class TestGeneratePID:
    """Testy pro generování PID"""

    def test_generate_pid_creates_valid_pid(self):
        pid = generate_pid()
        assert isinstance(pid, str)
        assert len(pid) == 12
        assert check_pid(pid)

    def test_generate_pid_creates_unique_pids(self):
        pids = [generate_pid() for _ in range(10)]
        assert len(set(pids)) == 10


class TestCode39PID:
    """Testy pro code39_pid funkci"""

    def test_code39_pid_return_type_0(self):
        result = code39_pid(VALID_PID, 0)
        assert result.startswith("!")
        assert result.endswith("! ")

    def test_code39_pid_return_type_1(self):
        result = code39_pid(VALID_PID, 1)
        assert not result.startswith("!")
        assert not result.endswith("! ")

    def test_code39_pid_return_type_2(self):
        result = code39_pid(VALID_PID, 2)
        assert len(result) == 1


class TestCode39Mod36:
    """Testy pro code39_mod36 funkci"""

    def test_code39_mod36_return_type_0(self):
        result = code39_mod36("ABC123", 0)
        assert result.startswith("!")
        assert result.endswith("! ")
        assert "ABC123" in result

    def test_code39_mod36_return_type_1(self):
        result = code39_mod36("ABC123", 1)
        assert result.startswith("ABC123")
        assert len(result) == 7

    def test_code39_mod36_return_type_2(self):
        result = code39_mod36("ABC123", 2)
        assert len(result) == 1
        assert result.isalnum()

    def test_code39_mod36_invalid_return_type(self):
        result = code39_mod36("ABC123", 99)
        assert result.startswith("!")

    def test_code39_mod36_filters_invalid_chars(self):
        result = code39_mod36("ABC-123-XYZ!@#", 1)
        assert "-" not in result
        assert "!" not in result
        assert "@" not in result
        assert "#" not in result
        assert "ABC123XYZ" in result

    def test_code39_mod36_consistent_checksum(self):
        result1 = code39_mod36("TEST123", 2)
        result2 = code39_mod36("TEST123", 2)
        assert result1 == result2

    def test_code39_mod36_different_data_different_checksum(self):
        result1 = code39_mod36("ABC123", 2)
        result2 = code39_mod36("ABC124", 2)
        assert len(result1) == 1
        assert len(result2) == 1


class TestCode39Integration:
    """Integrační testy pro code39 funkce"""

    def test_code39_roundtrip(self):
        data = "TESTDATA"
        full_code = code39_mod36(data, 1)
        checksum = code39_mod36(data, 2)
        assert full_code.endswith(checksum)

    def test_code39_with_pid(self):
        pid = generate_pid()
        barcode = code39_pid(pid, 0)
        assert "!" in barcode
        assert pid[:11] in barcode
