from __future__ import annotations

from datetime import datetime

from sysnet_pyutils import data_utils


def test_get_dict_value_datetime_iso_none_then_cz_used(monkeypatch):
    """
    Cíl: get_dict_value_datetime -> řádky, kde se volá:
      out = convert_iso_to_datetime(v)
      if out is None: out = convert_cz_to_datetime(v)
    """
    sentinel = datetime(2024, 1, 2, 3, 4, 5)

    monkeypatch.setattr(data_utils, "convert_iso_to_datetime", lambda _v: None)
    monkeypatch.setattr(data_utils, "convert_cz_to_datetime", lambda _v: sentinel)

    out = data_utils.get_dict_value_datetime({"dt": "X"}, "dt")
    assert out is sentinel


def test_get_dict_code_value_list_returns_none_when_codes_falsy(monkeypatch):
    """
    Cíl: get_dict_code_value_list -> if not codes or not values: return None
    Vynutíme codes = [] (falsy), values = ["1"] (truthy).
    """

    def fake_get_list(_data, item_name, spare_item_name=None):
        if item_name == "codes":
            return []
        if item_name == "vals":
            return ["1"]
        return None

    monkeypatch.setattr(data_utils, "get_dict_value_list", fake_get_list)
    assert data_utils.get_dict_code_value_list({"codes": "x", "vals": "y"}, "codes", "vals") is None


def test_get_dict_code_value_list_returns_none_when_values_falsy(monkeypatch):
    """
    Cíl: get_dict_code_value_list -> if not codes or not values: return None
    Vynutíme codes = ["A"] (truthy), values = [] (falsy).
    """

    def fake_get_list(_data, item_name, spare_item_name=None):
        if item_name == "codes":
            return ["A"]
        if item_name == "vals":
            return []
        return None

    monkeypatch.setattr(data_utils, "get_dict_value_list", fake_get_list)
    assert data_utils.get_dict_code_value_list({"codes": "x", "vals": "y"}, "codes", "vals") is None


def test_adjust_datetime_to_utc_none_and_empty_return_as_is():
    """
    Cíl: adjust_datetime_to_utc -> if date_value in [None, '']: return date_value
    """
    assert data_utils.adjust_datetime_to_utc(None, for_store=False) is None
    assert data_utils.adjust_datetime_to_utc("", for_store=True) == ""


def test_get_dict_value_datetime_iso_none_then_cz_used(monkeypatch):
    """
    Kryje větev: out = convert_iso_to_datetime(v) -> None -> out = convert_cz_to_datetime(v)
    """
    sentinel = datetime(2024, 1, 2, 3, 4, 5)

    monkeypatch.setattr(data_utils, "convert_iso_to_datetime", lambda _v: None)
    monkeypatch.setattr(data_utils, "convert_cz_to_datetime", lambda _v: sentinel)

    out = data_utils.get_dict_value_datetime({"dt": "X"}, "dt")
    assert out is sentinel


def test_get_dict_value_datetime_hits_except_branch(monkeypatch):
    """
    Cíl: data_utils.py řádky 239-240 (except ValueError/TypeError -> return None)

    Vynutíme ValueError uvnitř try bloků tím, že convert_iso_to_datetime vyhodí ValueError.
    """

    def boom(_v: str):
        raise ValueError("forced")

    monkeypatch.setattr(data_utils, "convert_iso_to_datetime", boom)

    out = data_utils.get_dict_value_datetime({"dt": "2024-01-02T03:04:05"}, "dt")
    assert out is None


def test_get_dict_code_value_list_hits_not_codes_branch_without_monkeypatch():
    """
    Cíl: data_utils.py řádek 325/327: if not codes or not values: return None

    Zajistíme, že get_dict_value_list(data, 'codes') vrátí None (protože vstup je prázdný string).
    """
    d = {"codes": "", "vals": '["1";"2"]'}
    assert data_utils.get_dict_code_value_list(d, "codes", "vals") is None


def test_get_dict_code_value_list_hits_not_values_branch_without_monkeypatch():
    """
    Cíl: data_utils.py řádek 325/327: if not codes or not values: return None

    Zajistíme, že get_dict_value_list(data, 'vals') vrátí None (protože vstup je prázdný string).
    """
    d = {"codes": '["A";"B"]', "vals": ""}
    assert data_utils.get_dict_code_value_list(d, "codes", "vals") is None


def test_dict_convert_date_to_str_hits_else_pass_branch():
    """
    Cíl: data_utils.py řádek 351: else: pass (větev pro hodnoty, které nejsou datetime/dict/list)
    """
    payload = {
        "a": 123,  # scalar -> spadne do else: pass
        "b": "text",
    }
    data_utils.dict_convert_date_to_str(payload)
    assert payload["a"] == 123
    assert payload["b"] == "text"


def test_adjust_datetime_to_utc_naive_datetime_hits_replace_tzinfo_branch():
    """
    Cíl: data_utils.py ř. 325
    Vstup je naive datetime -> provede se date_value.replace(tzinfo=pytz.UTC)
    a vrátí se date (větev pro datetime).
    """
    naive = datetime(2024, 1, 2, 3, 4, 5)  # tzinfo=None
    out = data_utils.adjust_datetime_to_utc(naive, for_store=False)
    # Funkce pro datetime vrací date
    assert str(out) == "2024-01-02"


def test_adjust_datetime_to_utc_returns_original_for_non_date_non_datetime():
    """
    Cíl: data_utils.py ř. 327
    Vstup není None/'' a není date/datetime -> vrátí se beze změny.
    """
    assert data_utils.adjust_datetime_to_utc("abc", for_store=False) == "abc"
