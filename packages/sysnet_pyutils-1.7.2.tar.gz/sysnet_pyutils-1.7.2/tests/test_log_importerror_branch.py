#!/usr/bin/env python3

import builtins
import importlib
import sys


def test_log_module_sets_flag_true_when_pymongo_import_succeeds():
    """
    Cíl: sysnet_pyutils/log.py řádek 7 (_PYMONGO_AVAILABLE = True)
    Vynutíme čistý import bez monkeypatch import hooků.
    """
    sys.modules.pop("sysnet_pyutils.log", None)
    mod = importlib.import_module("sysnet_pyutils.log")
    assert mod._PYMONGO_AVAILABLE is True


def test_log_module_sets_flag_false_when_pymongo_import_fails(monkeypatch):
    """
    Cíl: sysnet_pyutils/log.py řádky 8-9 (except ImportError → _PYMONGO_AVAILABLE = False)
    Řešení: při importu vynutit ImportError pro 'pymongo'.
    """
    real_import = builtins.__import__

    def fake_import(name, *args, **kwargs):
        if name == "pymongo":
            raise ImportError("forced for test")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", fake_import)

    # zajistit čistý import
    sys.modules.pop("sysnet_pyutils.log", None)
    mod = importlib.import_module("sysnet_pyutils.log")

    assert mod._PYMONGO_AVAILABLE is False
