from __future__ import annotations

from datetime import datetime, timedelta

from pytz import utc

from sysnet_pyutils.globalmodel.models import ExampleModel


def is_utc(dt: datetime) -> bool:
    return dt.tzinfo is not None and dt.utcoffset() == timedelta(0)


def test_cet_winter_to_utc():
    naive = datetime(2026, 1, 15, 12, 0, 0)  # CET -> 11:00Z
    m = ExampleModel(ts=naive)
    assert is_utc(m.ts)
    assert m.ts == datetime(2026, 1, 15, 11, 0, 0, tzinfo=utc)


def test_cest_summer_to_utc():
    naive = datetime(2026, 6, 1, 12, 0, 0)  # CEST -> 10:00Z
    m = ExampleModel(ts=naive)
    assert is_utc(m.ts)
    assert m.ts == datetime(2026, 6, 1, 10, 0, 0, tzinfo=utc)
