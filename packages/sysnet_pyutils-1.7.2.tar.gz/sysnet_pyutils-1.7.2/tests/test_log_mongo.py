"""
Testy pro sysnet_pyutils.log — MongoHandler
Pokrytí: log.py (0% → ~95%)

Všechny MongoDB volání jsou mockována — nepotřebujeme běžící databázi.
"""

import logging
from unittest.mock import MagicMock

import pytest

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_pymongo(monkeypatch):
    """Mockuje celý pymongo modul v log.py."""
    mock_client = MagicMock()
    mock_db = MagicMock()
    mock_collection = MagicMock()

    mock_client.__getitem__ = MagicMock(return_value=mock_db)
    mock_db.list_collection_names.return_value = []
    mock_db.create_collection.return_value = mock_collection
    mock_db.__getitem__ = MagicMock(return_value=mock_collection)

    mock_mongo = MagicMock()
    mock_mongo.MongoClient.return_value = mock_client

    monkeypatch.setattr("sysnet_pyutils.log._PYMONGO_AVAILABLE", True)
    monkeypatch.setattr("sysnet_pyutils.log.pymongo", mock_mongo, raising=False)

    return {
        "pymongo": mock_mongo,
        "client": mock_client,
        "db": mock_db,
        "collection": mock_collection,
    }


@pytest.fixture
def handler(mock_pymongo):
    """Vytvoří MongoHandler s mockovaným pymongo."""
    from sysnet_pyutils.log import MongoHandler

    h = MongoHandler(
        host="localhost", port=27017, database="logging", collection="utils", capped=True, size=100000, drop=False
    )
    return h


@pytest.fixture
def log_record():
    """Vytvoří jednoduchý LogRecord pro testování emit()."""
    record = logging.LogRecord(
        name="test_logger",
        level=logging.ERROR,
        pathname="test.py",
        lineno=42,
        msg="Test chybová zpráva",
        args=(),
        exc_info=None,
    )
    return record


# ---------------------------------------------------------------------------
# Import guard — pymongo není dostupný
# ---------------------------------------------------------------------------


class TestMongoHandlerImportGuard:

    def test_bez_pymongo_vyhodi_import_error(self, monkeypatch):
        """Pokud pymongo není k dispozici, __init__ vyhodí ImportError."""
        monkeypatch.setattr("sysnet_pyutils.log._PYMONGO_AVAILABLE", False)
        from sysnet_pyutils.log import MongoHandler

        with pytest.raises(ImportError, match="MongoDB"):
            MongoHandler()


# ---------------------------------------------------------------------------
# Inicializace
# ---------------------------------------------------------------------------


class TestMongoHandlerInit:

    def test_vytvoreni_handleru(self, handler):
        """MongoHandler lze vytvořit bez výjimky."""
        assert handler is not None

    def test_handler_je_logging_handler(self, handler):
        """MongoHandler dědí od logging.Handler."""
        assert isinstance(handler, logging.Handler)

    def test_handler_ma_client(self, handler):
        """Handler má atribut client (pymongo klient)."""
        assert hasattr(handler, "client")

    def test_handler_ma_database(self, handler):
        """Handler má atribut database."""
        assert hasattr(handler, "database")

    def test_handler_ma_collection(self, handler):
        """Handler má atribut collection."""
        assert hasattr(handler, "collection")

    def test_collection_vytvorena_kdyz_neexistuje(self, mock_pymongo):
        """Pokud kolekce neexistuje, zavolá se create_collection."""
        mock_pymongo["db"].list_collection_names.return_value = []
        from sysnet_pyutils.log import MongoHandler

        MongoHandler(database="logging", collection="new_col")
        mock_pymongo["db"].create_collection.assert_called_once()

    def test_collection_pouzita_kdyz_existuje(self, mock_pymongo):
        """Pokud kolekce existuje a drop=False, použije se existující."""
        mock_pymongo["db"].list_collection_names.return_value = ["utils"]
        from sysnet_pyutils.log import MongoHandler

        MongoHandler(database="logging", collection="utils", drop=False)
        mock_pymongo["db"].drop_collection.assert_not_called()

    def test_collection_dropnuta_kdyz_drop_true(self, mock_pymongo):
        """Pokud kolekce existuje a drop=True, zavolá se drop_collection."""
        mock_pymongo["db"].list_collection_names.return_value = ["utils"]
        from sysnet_pyutils.log import MongoHandler

        MongoHandler(database="logging", collection="utils", drop=True)
        mock_pymongo["db"].drop_collection.assert_called_once_with("utils")

    def test_init_s_username_password(self, mock_pymongo):
        """MongoHandler přijme username a password."""
        from sysnet_pyutils.log import MongoHandler

        h = MongoHandler(username="user", password="pass")
        assert h is not None
        mock_pymongo["pymongo"].MongoClient.assert_called_with(
            host="localhost", port=27017, username="user", password="pass"
        )

    def test_init_vlastni_host_port(self, mock_pymongo):
        """MongoHandler přijme vlastní host a port."""
        from sysnet_pyutils.log import MongoHandler

        MongoHandler(host="mongo-server", port=27018)
        mock_pymongo["pymongo"].MongoClient.assert_called_with(
            host="mongo-server", port=27018, username=None, password=None
        )


# ---------------------------------------------------------------------------
# emit()
# ---------------------------------------------------------------------------


class TestMongoHandlerEmit:

    def test_emit_vlozi_dokument(self, handler, log_record, mock_pymongo):
        """emit() zavolá collection.insert_one() s dokumentem."""
        handler.emit(log_record)
        mock_pymongo["collection"].insert_one.assert_called_once()

    def test_emit_dokument_obsahuje_message(self, handler, log_record, mock_pymongo):
        """Vložený dokument obsahuje klíč 'message' se správnou hodnotou."""
        handler.emit(log_record)
        call_args = mock_pymongo["collection"].insert_one.call_args[0][0]
        assert call_args["message"] == "Test chybová zpráva"

    def test_emit_dokument_obsahuje_levelname(self, handler, log_record, mock_pymongo):
        """Vložený dokument obsahuje 'levelname'."""
        handler.emit(log_record)
        doc = mock_pymongo["collection"].insert_one.call_args[0][0]
        assert doc["levelname"] == "ERROR"

    def test_emit_dokument_obsahuje_levelno(self, handler, log_record, mock_pymongo):
        """Vložený dokument obsahuje 'levelno'."""
        handler.emit(log_record)
        doc = mock_pymongo["collection"].insert_one.call_args[0][0]
        assert doc["levelno"] == logging.ERROR

    def test_emit_dokument_obsahuje_name(self, handler, log_record, mock_pymongo):
        """Vložený dokument obsahuje 'name' loggeru."""
        handler.emit(log_record)
        doc = mock_pymongo["collection"].insert_one.call_args[0][0]
        assert doc["name"] == "test_logger"

    def test_emit_dokument_obsahuje_lineno(self, handler, log_record, mock_pymongo):
        """Vložený dokument obsahuje 'lineno'."""
        handler.emit(log_record)
        doc = mock_pymongo["collection"].insert_one.call_args[0][0]
        assert doc["lineno"] == 42

    def test_emit_dokument_obsahuje_when(self, handler, log_record, mock_pymongo):
        """Vložený dokument obsahuje klíč 'when'."""
        handler.emit(log_record)
        doc = mock_pymongo["collection"].insert_one.call_args[0][0]
        assert "when" in doc

    def test_emit_dokument_obsahuje_created(self, handler, log_record, mock_pymongo):
        """Vložený dokument obsahuje klíč 'created'."""
        handler.emit(log_record)
        doc = mock_pymongo["collection"].insert_one.call_args[0][0]
        assert "created" in doc

    def test_emit_vsechna_ocekavana_pole(self, handler, log_record, mock_pymongo):
        """Vložený dokument obsahuje všechna očekávaná pole."""
        handler.emit(log_record)
        doc = mock_pymongo["collection"].insert_one.call_args[0][0]
        expected_keys = {
            "when",
            "created",
            "levelno",
            "levelname",
            "message",
            "name",
            "module",
            "func_name",
            "filename",
            "lineno",
            "process",
            "process_name",
            "thread",
            "thread_name",
            "stack_info",
        }
        assert expected_keys.issubset(set(doc.keys()))

    def test_emit_vicenarodni_zprava(self, handler, mock_pymongo):
        """emit() zvládne i unicode zprávu s diakritikou."""
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="t.py",
            lineno=1,
            msg="Zpráva s diakritikou: ěščřžýáíé",
            args=(),
            exc_info=None,
        )
        handler.emit(record)
        doc = mock_pymongo["collection"].insert_one.call_args[0][0]
        assert "ěščřžýáíé" in doc["message"]

    def test_emit_debug_uroven(self, handler, mock_pymongo):
        """emit() funguje pro DEBUG záznamy."""
        record = logging.LogRecord(
            name="test",
            level=logging.DEBUG,
            pathname="t.py",
            lineno=1,
            msg="debug zpráva",
            args=(),
            exc_info=None,
        )
        handler.emit(record)
        doc = mock_pymongo["collection"].insert_one.call_args[0][0]
        assert doc["levelname"] == "DEBUG"

    def test_emit_vicenasobne_volani(self, handler, mock_pymongo):
        """Vícenásobné volání emit() vloží více dokumentů."""
        for i in range(5):
            record = logging.LogRecord(
                name="test",
                level=logging.INFO,
                pathname="t.py",
                lineno=i,
                msg=f"zpráva {i}",
                args=(),
                exc_info=None,
            )
            handler.emit(record)
        assert mock_pymongo["collection"].insert_one.call_count == 5


# ---------------------------------------------------------------------------
# Integrace s logging frameworkem
# ---------------------------------------------------------------------------


class TestMongoHandlerIntegrace:

    def test_handler_lze_pridat_k_loggeru(self, handler):
        """MongoHandler lze přidat ke standardnímu loggeru."""
        logger = logging.getLogger("mongo_test_integration")
        logger.addHandler(handler)
        assert handler in logger.handlers
        logger.removeHandler(handler)

    def test_logger_s_handlerem_zapise_zpravu(self, handler, mock_pymongo):
        """Logger s MongoHandler skutečně zavolá insert_one při logování."""
        logger = logging.getLogger("mongo_test_write")
        logger.setLevel(logging.DEBUG)
        logger.addHandler(handler)
        try:
            logger.error("Testovací error")
            mock_pymongo["collection"].insert_one.assert_called()
        finally:
            logger.removeHandler(handler)
