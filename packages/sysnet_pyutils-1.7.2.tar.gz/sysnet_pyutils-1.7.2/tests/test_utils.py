"""
Testy pro modul sysnet_pyutils.utils
"""

import os
import tempfile
from datetime import date, datetime, timedelta
from uuid import UUID

import pytest
import pytz

from sysnet_pyutils.utils import (  # Context; Singleton and Config; API keys and identifiers; Hash functions; Base64 utilities; Validation functions; Date and time utilities; CITES utilities; LDAP utilities; List utilities; ICO utilities; Case conversion; URL and string utilities; XML utilities
    Config,
    ConfigFlag,
    Context,
    Singleton,
    api_key_generate,
    api_key_next,
    api_keys_init,
    cites_to_order,
    convert_hex_to_int,
    cron_to_dict,
    cs_bool,
    date_to_datetime,
    date_to_datetime_utc,
    date_to_iso,
    decode_b64_string,
    decode_b64_to_file,
    dict_to_xml,
    encode_file_b64,
    encode_string_b64,
    gmt_now,
    hash_md5,
    hash_sha1,
    hash_sha256,
    hash_sha384,
    id12_next,
    increment_date,
    is_base64,
    is_valid_cz_permit_id,
    is_valid_email,
    is_valid_ico,
    is_valid_pid,
    is_valid_unid,
    is_valid_uuid,
    iso_to_local_datetime,
    local_now,
    order_to_cites,
    parse_ldap_name,
    pid_check,
    pid_correct,
    pid_next,
    remove_empty,
    repair_ico,
    timestamp,
    to_base64,
    to_camel,
    to_camel_dict,
    to_snake,
    to_snake_dict,
    today,
    tomorrow,
    unique_list,
    url_safe,
    uuid_next,
    who_am_i,
    xml_to_dict,
)


@pytest.fixture
def clean_singleton():
    """Vyčistí singleton registry před a po testu"""
    # Vyčistit před testem
    if hasattr(Singleton, "_instances"):
        Singleton._instances.clear()
    yield
    # Vyčistit po testu
    if hasattr(Singleton, "_instances"):
        Singleton._instances.clear()


class TestSingleton:
    """Testy pro Singleton pattern"""

    def test_singleton_creates_only_one_instance(self, clean_singleton):
        class TestClass(metaclass=Singleton):
            def __init__(self):
                self.value = 42

        instance1 = TestClass()
        instance2 = TestClass()
        assert instance1 is instance2
        assert instance1.value == 42

    def test_config_flag_is_singleton(self, clean_singleton):
        cf1 = ConfigFlag()
        cf2 = ConfigFlag()
        assert cf1 is cf2


class TestConfig:
    """Testy pro Config třídu"""

    def test_config_creates_from_dict(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config_path = os.path.join(tmpdir, "test_config.yml")
            test_dict = {"test_key": "test_value", "number": 42}

            config = Config(config_path=config_path, config_dict=test_dict)
            assert config.loaded
            assert config.config["test_key"] == "test_value"
            assert config.config["number"] == 42

    def test_config_stores_and_loads(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config_path = os.path.join(tmpdir, "test_config2.yml")
            test_dict = {"data": "value"}

            config = Config(config_path=config_path, config_dict=test_dict)
            config.store()

            # Zkontrolujeme, že soubor existuje
            assert os.path.exists(config_path)


class TestURLUtilities:
    """Testy pro URL utility"""

    def test_url_safe_basic(self):
        url = "https://example.com/path with spaces"
        safe_url = url_safe(url)
        assert " " not in safe_url
        assert "https://example.com/path%20with%20spaces" == safe_url

    def test_url_safe_preserves_valid_chars(self):
        url = "https://example.com/path?key=value&foo=bar"
        safe_url = url_safe(url)
        assert "?" in safe_url
        assert "=" in safe_url
        assert "&" in safe_url


class TestListUtilities:
    """Testy pro list utility"""

    def test_unique_list_removes_duplicates(self):
        input_list = [1, 2, 2, 3, 3, 3, 4]
        result = unique_list(input_list)
        assert result == [1, 2, 3, 4]

    def test_unique_list_preserves_order(self):
        input_list = [3, 1, 2, 1, 3]
        result = unique_list(input_list)
        assert result == [3, 1, 2]

    def test_unique_list_returns_non_list_unchanged(self):
        assert unique_list("string") == "string"
        assert unique_list(42) == 42

    def test_remove_empty_removes_none_and_empty_strings(self):
        input_list = ["a", None, "b", "", "c", 0, False]
        result = remove_empty(input_list)
        assert "a" in result
        assert "b" in result
        assert "c" in result
        assert None not in result
        assert "" not in result

    def test_remove_empty_returns_none_for_none_input(self):
        assert remove_empty(None) is None


class TestAPIKeys:
    """Testy pro API klíče"""

    def test_api_key_generate_creates_key(self):
        key = api_key_generate(length=16)
        assert key is not None
        assert isinstance(key, str)
        assert len(key) > 0

    def test_api_key_next_returns_dict(self):
        result = api_key_next("test_name", length=16)
        assert isinstance(result, dict)
        assert len(result) == 1
        key, name = next(iter(result.items()))
        assert name == "test_name"

    def test_api_keys_init_creates_multiple_keys(self):
        keys = api_keys_init(agenda="test", amount=3)
        assert len(keys) == 3
        assert all(isinstance(k, dict) for k in keys)


class TestIdentifiers:
    """Testy pro identifikátory"""

    def test_uuid_next_creates_valid_uuid(self):
        uuid_val = uuid_next()
        assert isinstance(uuid_val, UUID)

    def test_uuid_next_type_4(self):
        uuid_val = uuid_next(uuid_type=4)
        assert uuid_val.version == 4

    def test_uuid_next_type_1(self):
        uuid_val = uuid_next(uuid_type=1)
        assert uuid_val.version == 1

    def test_pid_next_creates_valid_pid(self):
        pid = pid_next()
        assert isinstance(pid, str)
        assert len(pid) == 12
        assert pid_check(pid)

    def test_pid_check_validates_correct_pid(self):
        pid = pid_next()
        assert pid_check(pid) is True

    def test_pid_check_rejects_invalid_pid(self):
        assert pid_check("INVALID123") is False
        assert pid_check("123") is False

    def test_pid_correct_fixes_pid(self):
        incorrect_pid = "SNT12345678X"  # Nesprávný kontrolní součet
        corrected_pid = pid_correct(incorrect_pid)
        assert pid_check(corrected_pid) is True

    def test_id12_next_creates_12_char_id(self):
        id12 = id12_next("ABC")
        assert len(id12) == 12
        assert id12.startswith("ABC")

    def test_id12_next_with_none_prefix_uses_default(self):
        id12 = id12_next(None)
        assert len(id12) == 12


class TestHashFunctions:
    """Testy pro hash funkce"""

    def test_hash_md5_creates_hash(self):
        text = "test string"
        hash_val = hash_md5(text)
        assert hash_val is not None
        assert len(hash_val) == 32  # MD5 produces 32 hex chars

    def test_hash_md5_returns_none_for_none(self):
        assert hash_md5(None) is None

    def test_hash_sha1_creates_hash(self):
        text = "test string"
        hash_val = hash_sha1(text)
        assert hash_val is not None
        assert len(hash_val) == 40  # SHA1 produces 40 hex chars

    def test_hash_sha256_creates_hash(self):
        text = "test string"
        hash_val = hash_sha256(text)
        assert hash_val is not None
        assert len(hash_val) == 64  # SHA256 produces 64 hex chars

    def test_hash_sha384_creates_hash(self):
        text = "test string"
        hash_val = hash_sha384(text)
        assert hash_val is not None
        assert len(hash_val) == 96  # SHA384 produces 96 hex chars

    def test_hash_functions_consistent(self):
        text = "consistent test"
        assert hash_md5(text) == hash_md5(text)
        assert hash_sha1(text) == hash_sha1(text)
        assert hash_sha256(text) == hash_sha256(text)
        assert hash_sha384(text) == hash_sha384(text)


class TestValidationFunctions:
    """Testy pro validační funkce"""

    def test_is_valid_unid_accepts_valid_32_char_hex(self):
        valid_unid = "3005277CB984B7FFC12587890060E2BF"
        assert is_valid_unid(valid_unid) is True

    def test_is_valid_unid_rejects_invalid(self):
        assert is_valid_unid("INVALID") is False
        assert is_valid_unid("") is False
        assert is_valid_unid(None) is False
        assert is_valid_unid("300527") is False  # Too short

    def test_is_valid_uuid_accepts_valid_uuid(self):
        valid_uuid = "550e8400-e29b-41d4-a716-446655440000"
        assert is_valid_uuid(valid_uuid) is True

    def test_is_valid_uuid_accepts_uuid_object(self):
        uuid_obj = uuid_next()
        assert is_valid_uuid(uuid_obj) is True

    def test_is_valid_uuid_rejects_invalid(self):
        assert is_valid_uuid("invalid-uuid") is False
        assert is_valid_uuid("") is False

    def test_is_valid_pid_accepts_valid_format(self):
        pid = pid_next()
        assert is_valid_pid(pid) is True

    def test_is_valid_pid_rejects_invalid_format(self):
        assert is_valid_pid("invalid") is False
        assert is_valid_pid("123") is False

    def test_is_valid_ico_accepts_valid_ico(self):
        assert is_valid_ico("00012343") is True
        assert is_valid_ico("27074358") is True  # Známé platné IČO

    def test_is_valid_ico_rejects_invalid_ico(self):
        assert is_valid_ico("00012345") is False  # Špatný kontrolní součet
        assert is_valid_ico("abc") is False
        assert is_valid_ico("123456789") is False  # Příliš dlouhé

    def test_repair_ico_fixes_checksum(self):
        incorrect_ico = "00012345"  # Špatný kontrolní součet
        repaired = repair_ico(incorrect_ico)
        assert is_valid_ico(repaired) is True

    def test_is_valid_email_accepts_valid_emails(self):
        assert is_valid_email("test@example.com") is True
        assert is_valid_email("user.name@domain.cz") is True

    def test_is_valid_email_rejects_invalid_emails(self):
        assert is_valid_email("invalid") is False
        assert is_valid_email("@example.com") is False
        assert is_valid_email(None) is False

    def test_is_valid_cz_permit_id_accepts_valid_format(self):
        assert is_valid_cz_permit_id("23CZ123456") is True
        assert is_valid_cz_permit_id("23cz123456") is True  # Case insensitive

    def test_is_valid_cz_permit_id_rejects_invalid_format(self):
        assert is_valid_cz_permit_id("invalid") is False
        assert is_valid_cz_permit_id("23SK123456") is False
        assert is_valid_cz_permit_id(None) is False


class TestDateTimeUtilities:
    """Testy pro datum a čas utility"""

    def test_today_returns_iso_date(self):
        result = today()
        assert isinstance(result, str)
        # Should be in format YYYY-MM-DD
        date.fromisoformat(result)  # Raises if invalid

    def test_tomorrow_returns_next_day(self):
        today_date = date.fromisoformat(today())
        tomorrow_date = date.fromisoformat(tomorrow())
        assert tomorrow_date == today_date + timedelta(days=1)

    def test_increment_date_adds_days(self):
        start_date = "2023-01-01"
        result = increment_date(start_date, days=5)
        assert result == "2023-01-06"

    def test_increment_date_returns_none_for_none(self):
        assert increment_date(None) is None

    def test_cs_bool_returns_ano_for_true(self):
        assert cs_bool(True) == "ano"
        assert cs_bool(1) == "ano"
        assert cs_bool("text") == "ano"

    def test_cs_bool_returns_ne_for_false(self):
        assert cs_bool(False) == "ne"
        assert cs_bool(0) == "ne"
        assert cs_bool(None) == "ne"
        assert cs_bool("") == "ne"

    def test_cron_to_dict_parses_correctly(self):
        cron = "35 21 * * *"
        result = cron_to_dict(cron)
        assert result["minute"] == "35"
        assert result["hour"] == "21"
        assert result["day"] == "*"
        assert result["month"] == "*"
        assert result["day_of_week"] == "*"

    def test_cron_to_dict_returns_none_for_invalid(self):
        assert cron_to_dict("invalid") is None
        assert cron_to_dict("* *") is None

    def test_date_to_datetime_converts_date_to_datetime(self):
        d = date(2023, 5, 15)
        result = date_to_datetime(d)
        assert isinstance(result, datetime)
        assert result.year == 2023
        assert result.month == 5
        assert result.day == 15

    def test_date_to_datetime_returns_none_for_none(self):
        assert date_to_datetime(None) is None

    def test_date_to_datetime_utc_converts_to_utc(self):
        d = date(2023, 5, 15)
        result = date_to_datetime_utc(d)
        assert isinstance(result, datetime)
        assert result.tzinfo == pytz.utc

    def test_date_to_iso_converts_date(self):
        d = date(2023, 5, 15)
        result = date_to_iso(d)
        assert result == "2023-05-15"

    def test_date_to_iso_returns_none_for_none(self):
        assert date_to_iso(None) is None

    def test_local_now_returns_datetime_with_timezone(self):
        result = local_now()
        assert isinstance(result, datetime)
        assert result.tzinfo is not None

    def test_gmt_now_returns_utc_datetime(self):
        result = gmt_now()
        assert isinstance(result, datetime)
        assert result.tzinfo == pytz.utc

    def test_timestamp_returns_string(self):
        result = timestamp()
        assert isinstance(result, str)
        assert len(result) == 14  # Format: YYYYMMDDHHMMSS

    def test_convert_hex_to_int_converts_correctly(self):
        assert convert_hex_to_int("FF") == 255
        assert convert_hex_to_int("10") == 16
        assert convert_hex_to_int("0") == 0

    def test_convert_hex_to_int_returns_none_for_invalid(self):
        assert convert_hex_to_int("invalid") is None

    def test_iso_to_local_datetime_converts(self):
        iso_str = "2023-05-15T12:00:00Z"
        result = iso_to_local_datetime(iso_str)
        assert isinstance(result, datetime)

    def test_parse_ldap_name_extracts_cn(self):
        ldap_name = "CN=Jan Novák/O=CITES/C=CZ"
        cn, original = parse_ldap_name(ldap_name)
        assert cn == "Jan Novák"
        assert original == ldap_name

    def test_parse_ldap_name_handles_comma_separator(self):
        ldap_name = "CN=Jan Novák,O=CITES,C=CZ"
        cn, original = parse_ldap_name(ldap_name)
        assert cn == "Jan Novák"

    def test_parse_ldap_name_returns_none_for_none(self):
        cn, original = parse_ldap_name(None)
        assert cn is None
        assert original is None


class TestBase64Utilities:
    """Testy pro Base64 utility"""

    def test_is_base64_recognizes_base64(self):
        base64_str = "SGVsbG8gV29ybGQ="  # "Hello World" in base64
        assert is_base64(base64_str) is True

    def test_is_base64_rejects_non_base64(self):
        assert is_base64("not base64!") is False

    def test_encode_decode_string_b64_roundtrip(self):
        original = "Test string"
        encoded = encode_string_b64(original)
        decoded = decode_b64_string(encoded)
        assert decoded == original

    def test_to_base64_converts_string(self):
        text = "test"
        result = to_base64(text)
        assert result is not None
        assert is_base64(result)

    def test_encode_file_and_decode_to_file_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            # Vytvoříme testovací soubor
            source_file = os.path.join(tmpdir, "source.txt")
            target_file = os.path.join(tmpdir, "target.txt")

            original_content = b"Test file content"
            with open(source_file, "wb") as f:
                f.write(original_content)

            # Zakódujeme
            encoded = encode_file_b64(source_file)

            # Dekódujeme do nového souboru
            decode_b64_to_file(encoded, target_file)

            # Ověříme obsah
            with open(target_file, "rb") as f:
                decoded_content = f.read()

            assert decoded_content == original_content


class TestCaseConversion:
    """Testy pro konverzi případů (snake_case, camelCase)"""

    def test_to_camel_converts_snake_to_camel(self):
        assert to_camel("snake_case_name") == "snakeCaseName"
        assert to_camel("simple") == "simple"
        assert to_camel("one_two_three") == "oneTwoThree"

    def test_to_snake_converts_camel_to_snake(self):
        assert to_snake("camelCase") == "camel_case"
        assert to_snake("CamelCase") == "camel_case"

    def test_to_snake_dict_converts_dict_keys(self):
        input_dict = {"firstName": "John", "lastName": "Doe", "addressInfo": {"streetName": "Main St"}}
        result = to_snake_dict(input_dict)
        assert "first_name" in result
        assert "last_name" in result
        assert "address_info" in result
        assert "street_name" in result["address_info"]

    def test_to_camel_dict_converts_dict_keys(self):
        input_dict = {"first_name": "John", "last_name": "Doe", "address_info": {"street_name": "Main St"}}
        result = to_camel_dict(input_dict)
        assert "firstName" in result
        assert "lastName" in result
        assert "addressInfo" in result
        assert "streetName" in result["addressInfo"]

    def test_to_snake_dict_handles_lists(self):
        input_dict = {"items": [{"itemName": "First"}, {"itemName": "Second"}]}
        result = to_snake_dict(input_dict)
        assert "item_name" in result["items"][0]
        assert "item_name" in result["items"][1]


class TestXMLUtilities:
    """Testy pro XML utility"""

    def test_xml_to_dict_parses_simple_xml(self):
        xml = "<root><n>John</n><age>30</age></root>"
        result = xml_to_dict(xml)
        assert result is not None
        assert "root" in result

    def test_dict_to_xml_creates_xml(self):
        data = {"root": {"name": "John", "age": "30"}}
        xml = dict_to_xml(data)
        assert xml is not None
        assert "<root>" in xml

    def test_xml_dict_roundtrip(self):
        original_dict = {"root": {"name": "John", "age": "30"}}
        xml = dict_to_xml(original_dict)
        parsed_dict = xml_to_dict(xml)
        assert "root" in parsed_dict


class TestCITESUtilities:
    """Testy pro CITES utility"""

    def test_order_to_cites_converts_numbers(self):
        assert order_to_cites(1) == "A"
        assert order_to_cites(26) == "Z"
        assert order_to_cites(27) == "AA"
        assert order_to_cites(1458) == "BDB"

    def test_cites_to_order_converts_letters(self):
        assert cites_to_order("A") == 1
        assert cites_to_order("Z") == 26
        assert cites_to_order("AA") == 27
        assert cites_to_order("BDB") == 1458

    def test_cites_order_roundtrip(self):
        for num in [1, 26, 27, 100, 1000, 1458]:
            cites = order_to_cites(num)
            back = cites_to_order(cites)
            assert back == num

    def test_order_to_cites_raises_for_invalid(self):
        with pytest.raises(ValueError):
            order_to_cites(None)
        with pytest.raises(ValueError):
            order_to_cites(0)
        with pytest.raises(ValueError):
            order_to_cites(-1)

    def test_cites_to_order_raises_for_invalid(self):
        with pytest.raises(ValueError):
            cites_to_order(None)
        with pytest.raises(ValueError):
            cites_to_order("123")
        with pytest.raises(ValueError):
            cites_to_order("")


class TestContext:
    """Testy pro Context třídu"""

    @pytest.fixture(autouse=True)
    def clear_context(self):
        """Vyčistí Context před a po každém testu"""
        # Vyčistit singleton instances
        if hasattr(Context, "_instances"):
            Context._instances.clear()
        yield
        # Vyčistit po testu
        if hasattr(Context, "_instances"):
            Context._instances.clear()

    def test_context_check_api_key_authenticates(self):
        config = {"agenda1": {"api_keys": [{"validkey123": "testuser"}]}}
        ctx = Context(config=config)
        ctx.clear()  # Reset state

        result = ctx.check_api_key("validkey123")
        assert result is True
        assert ctx.authenticated is True
        assert ctx.user_name == "testuser"
        assert ctx.agenda == "agenda1"

    def test_context_check_api_key_rejects_invalid(self):
        config = {"agenda1": {"api_keys": [{"validkey123": "testuser"}]}}
        ctx = Context(config=config)
        ctx.clear()

        result = ctx.check_api_key("invalidkey")
        assert result is False
        assert ctx.authenticated is False

    def test_context_clear_resets_state(self):
        config = {"test": {"api_keys": [{"key1": "user1"}]}}
        ctx = Context(config=config)
        ctx.check_api_key("key1")

        ctx.clear()
        assert ctx.api_key is None
        assert ctx.user_name is None
        assert ctx.authenticated is False


class TestWhoAmI:
    """Test pro who_am_i funkci"""

    def test_who_am_i_returns_function_name(self):
        def test_function():
            return who_am_i()

        result = test_function()
        assert result == "test_function"
