"""
Testy pro data_utils.recursive_update()
Pokrytí: recursive_update (data_utils.py řádky 377-400) — 0% → 100%
"""

from dataclasses import dataclass, field

import pytest

# ---------------------------------------------------------------------------
# Pomocné datové třídy simulující Pydantic/Beanie modely
# ---------------------------------------------------------------------------


@dataclass
class Address:
    street: str = ""
    city: str = ""
    zip_code: str = ""


@dataclass
class Person:
    name: str = ""
    age: int = 0
    email: str = ""
    address: dict = field(default_factory=dict)
    tags: list = field(default_factory=list)
    score: float | None = None


@dataclass
class NestedObj:
    meta: dict = field(default_factory=dict)
    data: dict = field(default_factory=dict)
    count: int = 0


# ---------------------------------------------------------------------------
# Import testované funkce
# ---------------------------------------------------------------------------

from sysnet_pyutils.data_utils import recursive_update

# ---------------------------------------------------------------------------
# Základní funkčnost
# ---------------------------------------------------------------------------


class TestRecursiveUpdateBasic:

    def test_aktualizace_jednoduche_hodnoty(self):
        """Prostý string se aktualizuje."""
        obj = Person(name="Old")
        original = {"name": "Old", "age": 0}
        updated = {"name": "New"}
        result = recursive_update(obj, original, updated)
        assert result["name"] == "New"
        assert obj.name == "New"

    def test_aktualizace_int(self):
        """Integer se aktualizuje."""
        obj = Person(age=10)
        original = {"name": "", "age": 10}
        updated = {"age": 42}
        result = recursive_update(obj, original, updated)
        assert result["age"] == 42
        assert obj.age == 42

    def test_aktualizace_vice_poli(self):
        """Více polí najednou."""
        obj = Person(name="Alice", age=20)
        original = {"name": "Alice", "age": 20, "email": ""}
        updated = {"name": "Bob", "age": 30, "email": "bob@example.com"}
        result = recursive_update(obj, original, updated)
        assert result["name"] == "Bob"
        assert result["age"] == 30
        assert result["email"] == "bob@example.com"
        assert obj.name == "Bob"

    def test_vrati_aktualizovany_original(self):
        """Funkce vrátí odkaz na original (in-place update)."""
        obj = Person(name="X")
        original = {"name": "X"}
        updated = {"name": "Y"}
        result = recursive_update(obj, original, updated)
        assert result is original

    def test_prazdny_updated(self):
        """Prázdný updated nic nezmění."""
        obj = Person(name="Alice", age=5)
        original = {"name": "Alice", "age": 5}
        result = recursive_update(obj, original, {})
        assert result["name"] == "Alice"
        assert result["age"] == 5

    def test_none_hodnota_aktualizuje_skalar(self):
        """None aktualizuje skalární pole."""
        obj = Person(name="Alice")
        original = {"name": "Alice", "score": 1.0}
        updated = {"score": None}
        result = recursive_update(obj, original, updated)
        assert result["score"] is None
        assert obj.score is None


# ---------------------------------------------------------------------------
# Klíče mimo original se ignorují
# ---------------------------------------------------------------------------


class TestRecursiveUpdateIgnoreUnknown:

    def test_klic_mimo_original_se_ignoruje(self):
        """Klíč v updated, který není v original, se ignoruje."""
        obj = Person(name="Alice")
        original = {"name": "Alice"}
        updated = {"name": "Bob", "nonexistent_field": "xyz"}
        result = recursive_update(obj, original, updated)
        assert result["name"] == "Bob"
        assert "nonexistent_field" not in result

    def test_vsechny_klice_mimo_original(self):
        """Pokud žádný klíč v updated není v original, nic se nezmění."""
        obj = Person(name="Alice")
        original = {"name": "Alice"}
        updated = {"foo": 1, "bar": 2}
        result = recursive_update(obj, original, updated)
        assert result == {"name": "Alice"}
        assert obj.name == "Alice"


# ---------------------------------------------------------------------------
# None pro dict/list se přeskočí
# ---------------------------------------------------------------------------


class TestRecursiveUpdateNoneProtection:

    def test_none_misto_dict_se_preskoci(self):
        """None jako náhrada za dict se přeskočí — dict zůstane."""
        obj = Person()
        original = {"name": "", "address": {"city": "Praha"}}
        updated = {"address": None}
        result = recursive_update(obj, original, updated)
        assert result["address"] == {"city": "Praha"}

    def test_none_misto_listu_se_preskoci(self):
        """None jako náhrada za list se přeskočí — list zůstane."""
        obj = Person()
        original = {"name": "", "tags": ["a", "b"]}
        updated = {"tags": None}
        result = recursive_update(obj, original, updated)
        assert result["tags"] == ["a", "b"]

    def test_none_pro_skalar_se_provede(self):
        """None pro skalár se NAOPAK provede (není dict ani list)."""
        obj = Person(name="Alice")
        original = {"name": "Alice", "age": 5}
        updated = {"name": None}
        result = recursive_update(obj, original, updated)
        assert result["name"] is None
        assert obj.name is None


# ---------------------------------------------------------------------------
# Rekurzivní zanořování (dict v dict)
# ---------------------------------------------------------------------------


class TestRecursiveUpdateNested:

    def test_zanoreny_dict_se_rekurzivne_aktualizuje(self):
        """Pokud original[k] i updated[k] jsou dict, jde do rekurze.

        Poznámka: při rekurzi se jako out_object předává getattr(out_object, k),
        tedy sub-dict (nebo sub-objekt). Pro rekurzi na dict-atributu musí být
        atribut objektem s atributy, nikoliv holý dict — jinak setattr selže.
        Testujeme případ, kdy zanořený dict obsahuje skalární hodnoty.
        """

        @dataclass
        class Inner:
            version: int = 0
            author: str = ""

        @dataclass
        class Outer:
            meta: object = field(default_factory=Inner)

        inner = Inner(version=1, author="Alice")
        obj = Outer(meta=inner)
        original = {"meta": {"version": 1, "author": "Alice"}}
        updated = {"meta": {"version": 2}}
        result = recursive_update(obj, original, updated)
        assert result["meta"]["version"] == 2
        assert result["meta"]["author"] == "Alice"  # nezměněno

    def test_zanoreny_dict_preskoci_neznamy_klic(self):
        """Rekurze taktéž ignoruje klíče mimo original."""

        @dataclass
        class Inner:
            x: int = 0

        @dataclass
        class Outer:
            data: object = field(default_factory=Inner)

        inner = Inner(x=1)
        obj = Outer(data=inner)
        original = {"data": {"x": 1}}
        updated = {"data": {"x": 10, "unknown": 99}}
        result = recursive_update(obj, original, updated)
        assert result["data"]["x"] == 10
        assert "unknown" not in result["data"]

    def test_skalarna_hodnota_prepise_skalar_v_zanorenem(self):
        """Skalár přepíše skalár v zanořeném objektu."""

        @dataclass
        class Inner:
            count: int = 0

        @dataclass
        class Outer:
            meta: object = field(default_factory=Inner)

        inner = Inner(count=5)
        obj = Outer(meta=inner)
        original = {"meta": {"count": 5}}
        updated = {"meta": {"count": 99}}
        result = recursive_update(obj, original, updated)
        assert result["meta"]["count"] == 99

    def test_zanoreni_s_holym_dict_atributem_aktualizuje_dict(self):
        """Pokud je atribut holý dict (ne objekt), rekurze se provede,
        ale setattr na dict selže — funkce takový případ nepodporuje.
        Toto je dokumentované omezení recursive_update().
        """
        obj = Person()
        obj.address = {"city": "Praha"}
        original = {"address": {"city": "Praha"}}
        updated = {"address": {"city": "Brno"}}
        # Rekurze se pokusí setattr na dict — vyhodí AttributeError
        with pytest.raises(AttributeError):
            recursive_update(obj, original, updated)


# ---------------------------------------------------------------------------
# setattr chování
# ---------------------------------------------------------------------------


class TestRecursiveUpdateSetattr:

    def test_setattr_se_provede_na_objektu(self):
        """Pro skalár se provede setattr na out_object."""
        obj = Person(name="Old", age=0)
        original = {"name": "Old", "age": 0}
        updated = {"name": "New", "age": 99}
        recursive_update(obj, original, updated)
        assert obj.name == "New"
        assert obj.age == 99

    def test_float_aktualizace(self):
        """Float hodnota se správně nastaví."""
        obj = Person(score=0.0)
        original = {"name": "", "score": 0.0}
        updated = {"score": 3.14}
        recursive_update(obj, original, updated)
        assert obj.score == pytest.approx(3.14)

    def test_bool_aktualizace(self):
        """Bool hodnota se správně nastaví."""

        @dataclass
        class Flags:
            active: bool = False

        obj = Flags()
        original = {"active": False}
        updated = {"active": True}
        recursive_update(obj, original, updated)
        assert obj.active is True

    def test_list_skalar_aktualizace(self):
        """List se nahradí novým listem (není None)."""
        obj = Person()
        original = {"name": "", "tags": ["old"]}
        updated = {"tags": ["new1", "new2"]}
        recursive_update(obj, original, updated)
        assert obj.tags == ["new1", "new2"]


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestRecursiveUpdateEdge:

    def test_prazdny_original_a_updated(self):
        """Oba prázdné — vrátí prázdný dict."""
        obj = Person()
        result = recursive_update(obj, {}, {})
        assert result == {}

    def test_original_s_none_hodnotou(self):
        """Original má None hodnotu, updated ji přepíše."""
        obj = Person()
        original = {"name": None}
        updated = {"name": "Alice"}
        result = recursive_update(obj, original, updated)
        assert result["name"] == "Alice"

    def test_aktualizace_zachovava_nemenicne_pole(self):
        """Pole, která nejsou v updated, zůstanou beze změny."""
        obj = Person(name="Alice", age=30, email="a@b.cz")
        original = {"name": "Alice", "age": 30, "email": "a@b.cz"}
        updated = {"name": "Bob"}
        result = recursive_update(obj, original, updated)
        assert result["age"] == 30
        assert result["email"] == "a@b.cz"
        assert obj.age == 30

    def test_integer_nula_aktualizuje(self):
        """Nula (0) je validní hodnota a přepíše existující hodnotu."""
        obj = Person(age=99)
        original = {"name": "", "age": 99}
        updated = {"age": 0}
        result = recursive_update(obj, original, updated)
        assert result["age"] == 0
        assert obj.age == 0

    def test_prazdny_string_aktualizuje(self):
        """Prázdný string je validní hodnota."""
        obj = Person(name="Alice")
        original = {"name": "Alice"}
        updated = {"name": ""}
        result = recursive_update(obj, original, updated)
        assert result["name"] == ""
        assert obj.name == ""
