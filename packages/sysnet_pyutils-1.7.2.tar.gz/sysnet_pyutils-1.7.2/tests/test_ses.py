"""
Testy pro sysnet_pyutils.ses — SesFactory
Pokrytí: ses.py (0% → ~95%)

Všechna boto3 / botocore volání jsou mockována.
"""

import logging
from unittest.mock import MagicMock

import pytest

from sysnet_pyutils.utils import Singleton

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def reset_ses_singleton():
    """SesFactory je Singleton — čistíme před každým testem."""
    if hasattr(Singleton, "_instances"):
        Singleton._instances.clear()
    yield
    if hasattr(Singleton, "_instances"):
        Singleton._instances.clear()


@pytest.fixture
def mock_boto3(monkeypatch):
    """Mockuje boto3 + botocore v ses.py."""
    mock_client = MagicMock()
    mock_b3 = MagicMock()
    mock_b3.client.return_value = mock_client

    mock_botocore = MagicMock()
    mock_botocore.exceptions.ClientError = Exception

    monkeypatch.setattr("sysnet_pyutils.ses._AWS_AVAILABLE", True)
    monkeypatch.setattr("sysnet_pyutils.ses.boto3", mock_b3, raising=False)
    monkeypatch.setattr("sysnet_pyutils.ses.ClientError", Exception, raising=False)

    return {
        "boto3": mock_b3,
        "ses_client": mock_client,
    }


@pytest.fixture
def factory(mock_boto3):
    """Vytvoří SesFactory s mockovaným boto3."""
    from sysnet_pyutils.ses import SesFactory

    return SesFactory(
        aws_region="eu-central-1",
        aws_access_key="AKIATEST",
        aws_secret_access_key="secret",
        sender="sender@example.com",
    )


# ---------------------------------------------------------------------------
# Import guard
# ---------------------------------------------------------------------------


class TestSesFactoryImportGuard:

    def test_bez_boto3_vyhodi_import_error(self, monkeypatch):
        """Pokud boto3 není dostupné, __init__ vyhodí ImportError."""
        monkeypatch.setattr("sysnet_pyutils.ses._AWS_AVAILABLE", False)
        from sysnet_pyutils.ses import SesFactory

        with pytest.raises(ImportError, match="AWS SES"):
            SesFactory()


# ---------------------------------------------------------------------------
# Inicializace
# ---------------------------------------------------------------------------


class TestSesFactoryInit:

    def test_vytvoreni_factory(self, factory):
        """SesFactory lze vytvořit bez výjimky."""
        assert factory is not None

    def test_factory_ma_aws_region(self, factory):
        """Factory uloží aws_region."""
        assert factory.aws_region == "eu-central-1"

    def test_factory_ma_sender(self, factory):
        """Factory uloží sender."""
        assert factory.sender == "sender@example.com"

    def test_factory_ma_charset(self, factory):
        """Factory má výchozí charset utf-8."""
        assert factory.charset == "utf-8"

    def test_factory_ma_klienta(self, factory, mock_boto3):
        """Factory vytvoří boto3 SES klienta."""
        mock_boto3["boto3"].client.assert_called_once_with(
            service_name="ses",
            region_name="eu-central-1",
            aws_access_key_id="AKIATEST",
            aws_secret_access_key="secret",
        )

    def test_factory_je_singleton(self, mock_boto3):
        """SesFactory je Singleton — dvě instance jsou identické."""
        from sysnet_pyutils.ses import SesFactory

        f1 = SesFactory(aws_access_key="K1")
        f2 = SesFactory(aws_access_key="K2")
        assert f1 is f2

    def test_factory_s_configuration_set(self, mock_boto3):
        """Factory přijme configuration_set."""
        from sysnet_pyutils.ses import SesFactory

        f = SesFactory(configuration_set="my-config")
        assert f.configuration_set == "my-config"

    def test_factory_ma_logger(self, factory):
        """Factory má atribut logger."""
        assert factory.logger is not None
        assert isinstance(factory.logger, logging.Logger)


# ---------------------------------------------------------------------------
# logger property
# ---------------------------------------------------------------------------


class TestSesFactoryLogger:

    def test_logger_getter_vraci_logger(self, factory):
        """Property logger vrátí logging.Logger."""
        assert isinstance(factory.logger, logging.Logger)

    def test_logger_setter_none_ponecha_log(self, factory):
        """Setter s None nastaví nový Log().logger."""
        original = factory.logger
        factory.logger = None
        # Po nastavení None se vytvoří nový logger
        assert factory.logger is not None

    def test_logger_setter_nastaví_ext_logger(self, factory):
        """Setter nastaví externí logger, pokud má jiné jméno."""
        ext = logging.getLogger("external_ses_logger")
        factory.logger = ext
        assert factory.logger.name == "external_ses_logger"

    def test_logger_setter_stejne_jmeno_neprepise(self, factory):
        """Setter se stejným jménem loggeru logger nepřepíše."""
        current_name = factory.logger.name
        same_logger = logging.getLogger(current_name)
        factory.logger = same_logger
        # Jméno zůstane stejné
        assert factory.logger.name == current_name


# ---------------------------------------------------------------------------
# send_email — úspěšné odeslání
# ---------------------------------------------------------------------------


class TestSesFactorySendEmail:

    def test_send_email_uspesne(self, factory, mock_boto3):
        """send_email() vrátí True při úspěchu."""
        mock_boto3["ses_client"].send_email.return_value = {"MessageId": "msg-123"}
        result = factory.send_email(
            recipient="to@example.com",
            subject="Test",
            body_text="Tělo zprávy",
        )
        assert result is True

    def test_send_email_vola_ses_client(self, factory, mock_boto3):
        """send_email() zavolá boto3 ses client.send_email."""
        mock_boto3["ses_client"].send_email.return_value = {"MessageId": "msg-abc"}
        factory.send_email("to@example.com", "Předmět", "Tělo")
        mock_boto3["ses_client"].send_email.assert_called_once()

    def test_send_email_string_recipient_se_prevede_na_list(self, factory, mock_boto3):
        """Stringový recipient se převede na list."""
        mock_boto3["ses_client"].send_email.return_value = {"MessageId": "x"}
        factory.send_email("single@example.com", "Sub", "Body")
        call_kwargs = mock_boto3["ses_client"].send_email.call_args[1]
        assert call_kwargs["Destination"]["ToAddresses"] == ["single@example.com"]

    def test_send_email_list_recipient_se_neprevadi(self, factory, mock_boto3):
        """List recipientů se předá beze změny."""
        mock_boto3["ses_client"].send_email.return_value = {"MessageId": "x"}
        recipients = ["a@example.com", "b@example.com"]
        factory.send_email(recipients, "Sub", "Body")
        call_kwargs = mock_boto3["ses_client"].send_email.call_args[1]
        assert call_kwargs["Destination"]["ToAddresses"] == recipients

    def test_send_email_body_html_none_pouzije_text(self, factory, mock_boto3):
        """Pokud body_html je None, použije se body_text."""
        mock_boto3["ses_client"].send_email.return_value = {"MessageId": "x"}
        factory.send_email("to@example.com", "Sub", "Plain text", body_html=None)
        call_kwargs = mock_boto3["ses_client"].send_email.call_args[1]
        html_data = call_kwargs["Message"]["Body"]["Html"]["Data"]
        assert html_data == "Plain text"

    def test_send_email_s_html_pouzije_html(self, factory, mock_boto3):
        """Pokud body_html je zadán, použije se."""
        mock_boto3["ses_client"].send_email.return_value = {"MessageId": "x"}
        factory.send_email("to@example.com", "Sub", "Plain", body_html="<b>HTML</b>")
        call_kwargs = mock_boto3["ses_client"].send_email.call_args[1]
        assert call_kwargs["Message"]["Body"]["Html"]["Data"] == "<b>HTML</b>"

    def test_send_email_predmet_v_message(self, factory, mock_boto3):
        """Předmět se předá v Message.Subject.Data."""
        mock_boto3["ses_client"].send_email.return_value = {"MessageId": "x"}
        factory.send_email("to@example.com", "Můj předmět", "Tělo")
        call_kwargs = mock_boto3["ses_client"].send_email.call_args[1]
        assert call_kwargs["Message"]["Subject"]["Data"] == "Můj předmět"

    def test_send_email_source_je_sender(self, factory, mock_boto3):
        """Source v boto3 volání odpovídá factory.sender."""
        mock_boto3["ses_client"].send_email.return_value = {"MessageId": "x"}
        factory.send_email("to@example.com", "Sub", "Body")
        call_kwargs = mock_boto3["ses_client"].send_email.call_args[1]
        assert call_kwargs["Source"] == "sender@example.com"

    def test_send_email_charset_v_message(self, factory, mock_boto3):
        """Charset se předá v Body i Subject."""
        mock_boto3["ses_client"].send_email.return_value = {"MessageId": "x"}
        factory.send_email("to@example.com", "Sub", "Body")
        call_kwargs = mock_boto3["ses_client"].send_email.call_args[1]
        assert call_kwargs["Message"]["Body"]["Text"]["Charset"] == "utf-8"
        assert call_kwargs["Message"]["Subject"]["Charset"] == "utf-8"


# ---------------------------------------------------------------------------
# send_email — chybové stavy
# ---------------------------------------------------------------------------


class TestSesFactorySendEmailErrors:

    def test_send_email_message_rejected_vraci_false(self, factory, mock_boto3, monkeypatch):
        """MessageRejected exception vrátí False."""
        err = Exception("MessageRejected")
        err.response = {"Error": {"Code": "MessageRejected", "Message": "Rejected"}}
        mock_boto3["ses_client"].send_email.side_effect = err
        monkeypatch.setattr("sysnet_pyutils.ses.ClientError", Exception)
        result = factory.send_email("to@example.com", "Sub", "Body")
        assert result is False

    def test_send_email_jina_chyba_vraci_false(self, factory, mock_boto3, monkeypatch):
        """Jiná ClientError exception vrátí False."""
        err = Exception("OtherError")
        err.response = {"Error": {"Code": "OtherError", "Message": "Chyba"}}
        mock_boto3["ses_client"].send_email.side_effect = err
        monkeypatch.setattr("sysnet_pyutils.ses.ClientError", Exception)
        result = factory.send_email("to@example.com", "Sub", "Body")
        assert result is False

    def test_send_email_prazdny_recipient_list(self, factory, mock_boto3):
        """Prázdný list recipientů — send_email se zavolá (validaci nedělá factory)."""
        mock_boto3["ses_client"].send_email.return_value = {"MessageId": "x"}
        result = factory.send_email([], "Sub", "Body")
        assert result is True
