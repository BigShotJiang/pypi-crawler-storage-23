"""Documentation about rcx_tk."""

import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())

__author__ = "Zargham Ahmad"
__email__ = "zargham.ahmad@recetox.muni.cz"
__version__ = "0.2.0"
