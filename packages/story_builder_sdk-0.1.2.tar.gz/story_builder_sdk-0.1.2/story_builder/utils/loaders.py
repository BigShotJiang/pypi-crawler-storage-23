import json
from story_builder.core.graph import StoryGraph

def load_graph(path: str) -> StoryGraph:
    """Utility to load a StoryGraph from a JSON file. Supports UTF-8 BOM."""
    try:
        with open(path, 'r', encoding='utf-8-sig') as f:
            data = json.load(f)
        return StoryGraph(**data)
    except json.JSONDecodeError as e:
        raise ValueError(f"Failed to parse JSON file '{path}'. Ensure it is valid JSON and encoded as UTF-8 (BOM supported): {e}")
    except Exception as e:
        raise e
