import argparse
import os
import json
import sys
import time
from story_builder import Engine, StoryGraph, EngineState
from story_builder.utils.loaders import load_graph

def visualize_command(args):
    """Command for story graph visualization."""
    from story_builder.export.render import write_dot, render_dot_to_image, open_file

    if not os.path.exists(args.path):
        print(f"Error: Path {args.path} does not exist.")
        sys.exit(2)

    try:
        with open(args.path, 'r', encoding='utf-8-sig') as f:
            data = json.load(f)
    except Exception as e:
        print(f"Error: Failed to parse JSON file (UTF-8 BOM supported): {e}")
        sys.exit(2)

    try:
        graph = StoryGraph(**data)
        
        # Paths logic
        base, _ = os.path.splitext(args.path)
        out_dot = f"{base}.dot"
        out_img = args.out or f"{base}.{args.format}"
        
        # 1. Output DOT
        write_dot(graph, out_dot)
        
        if getattr(args, 'dot_only', False):
            return
    except Exception as e:
        print(f"Error during DOT export: {e}")
        sys.exit(2)

    try:
        # 2. Render to image
        success = render_dot_to_image(out_dot, out_img, format=args.format, engine=args.engine)
        
        if success:
            print(f"Successfully visualized to: {out_img}")
            if not getattr(args, 'no_open', False):
                open_file(out_img)
        else:
            print("\nHint: Only the .dot file was generated. To render it as an image, please:")
            print("  - pip install 'story-builder[viz]'")
            print("  - Ensure GraphViz system binaries are installed (http://graphviz.org)")
    except Exception as e:
        print(f"Error during rendering: {e}")
        # sys.exit(2) # Don't exit on render fail if DOT was ok

def play_command(args):
    """Command for playing through a story."""
    if not args.path:
        print("Error: path is required for play.")
        sys.exit(2)
        
    if not os.path.exists(args.path):
        print(f"Error: Story file '{args.path}' not found.")
        sys.exit(2)
        
    try:
        story_graph = load_graph(args.path)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(2)
        
    engine = Engine(story_graph)
    
    # Start game
    state = EngineState(current_node_id=story_graph.start_node_id, variables={})
    
    print(f"\nStarting Adventure: {story_graph.metadata.get('title', 'Unknown')}")
    print("-" * 50)
    
    while True:
        node, triggers, _ = engine.run(state.current_node_id, state.variables)
        
        print(f"\nNode: {node.title}")
        print(f"Body: {node.body}")
        
        if not triggers:
            print("\n[GAME OVER] No choices left.")
            break
            
        print("\nAvailable Actions:")
        for i, t in enumerate(triggers, start=1):
            print(f"  {i}. {t}")
        
        try:
            choice = input("\n> ")
            if choice.lower() in ['exit', 'quit']:
                break
            
            # Check for numerical choice
            if choice.isdigit() and 0 < int(choice) <= len(triggers):
                selected_trigger = triggers[int(choice)-1]
            else:
                selected_trigger = choice
            
            # Process trigger
            engine.process_trigger(selected_trigger, state)
            
        except Exception as e:
            print(f"\nError: {e}")
            print("Please try again.")

def init_command(args):
    """Command to generate a starter story template."""
    starter_story = {
        "metadata": {
            "title": "My New Story"
        },
        "nodes": {
            "start": {
                "id": "start",
                "title": "The Beginning",
                "body": "You stand at a crossroads. Where will you go?",
                "choices": [
                    {
                        "trigger": "Go North",
                        "target_node_id": "north_node"
                    },
                    {
                        "trigger": "Go South",
                        "target_node_id": "south_node"
                    }
                ]
            },
            "north_node": {
                "id": "north_node",
                "title": "The North Pole",
                "body": "It is freezing here. You see a polar bear.",
                "choices": []
            },
            "south_node": {
                "id": "south_node",
                "title": "The Sunny South",
                "body": "Beach vibes everywhere. You feel relaxed.",
                "choices": []
            }
        },
        "start_node_id": "start"
    }
    
    filename = "story.json"
    try:
        if os.path.exists(filename) and not getattr(args, 'force', False):
            print(f"Error: {filename} already exists. Use --force to overwrite.")
            sys.exit(1)
            
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(starter_story, f, indent=2)
        print(f"Created starter story: {filename}")
    except Exception as e:
        print(f"Error creating starter story: {e}")
        sys.exit(1)

def validate_command(args):
    """Command to validate a story graph JSON file."""
    if not os.path.exists(args.path):
        print(f"Error: File {args.path} not found.")
        sys.exit(1)
    
    try:
        graph = load_graph(args.path)
        graph.validate_graph()
        print("Graph valid.")
    except Exception as e:
        print(f"Graph validation error: {e}")
        sys.exit(1)

def export_command(args):
    """Command to export a story graph to other formats."""
    if not os.path.exists(args.path):
        print(f"Error: File {args.path} not found.")
        sys.exit(1)

    try:
        graph = load_graph(args.path)
        base, _ = os.path.splitext(args.path)
        
        if args.format == "ink":
            from story_builder.export.ink_exporter import InkExporter
            out_file = f"{base}.ink"
            InkExporter.export(graph, out_file)
            print(f"Exported to {out_file} (Ink format)")
        else:
            print(f"Format {args.format} not implemented or same as source.")
            
    except Exception as e:
        print(f"Export failed: {e}")
        sys.exit(1)

def generate_command(args):
    """Command to generate a whole story from a prompt using AI."""
    print(f"=== Story Builder AI Generator ===")
    
    api_key = args.api_key or os.getenv("OPENROUTER_API_KEY")
    is_mock = not api_key

    if is_mock:
        print("Running in MOCK mode (no API call).")

    try:
        print("[1/4] Generating story outline")
        time.sleep(0.3)
        
        print("[2/4] Creating branching nodes")
        time.sleep(0.3)
        
        if is_mock:
            # Deterministic mock graph
            graph_data = {
                "metadata": {"title": f"MOCK: {args.prompt[:20]}..."},
                "nodes": {
                    "start": {"id": "start", "title": "The Mansion Gate", "body": "You stand before a large, iron-wrought gate.", "choices": [
                        {"trigger": "Search the grounds", "to": "grounds"},
                        {"trigger": "Knock on the door", "to": "foyer"}
                    ]},
                    "grounds": {"id": "grounds", "title": "The Overgrown Garden", "body": "The garden is a wild mess of thorns.", "choices": []},
                    "foyer": {"id": "foyer", "title": "Large Foyer", "body": "Dust mops hang from the ceiling like ghosts.", "choices": []}
                },
                "start_node_id": "start"
            }
            for i in range(max(0, args.nodes - 3)):
                node_id = f"mock_{i}"
                graph_data["nodes"][node_id] = {"id": node_id, "title": f"Mock Node {i}", "body": "Nothing much here.", "choices": []}
            
            graph = StoryGraph(**graph_data)
        else:
            try:
                from story_builder_pro.ai.provider_openrouter import OpenRouterProvider
                provider = OpenRouterProvider(api_key=api_key)
                
                system_prompt = "Generate a branching story graph in JSON. Return JSON only."
                user_prompt = f"Generate a story with at least {args.nodes} nodes about: {args.prompt}. Use format: metadata, nodes (id, title, body, choices: [trigger, to]), start_node_id."
                
                ai_data = provider.generate_json(user_prompt, system_prompt=system_prompt)
                graph = StoryGraph(**ai_data)
            except Exception as e:
                print(f"AI Generation failed: {e}")
                sys.exit(1)

        print("[3/4] Validating story graph")
        time.sleep(0.3)
        graph.validate_graph()

        print("[4/4] Saving story")
        time.sleep(0.3)
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(graph.model_dump_json(indent=2))
        
        print(f"Story saved to {args.output}")
        
        viz_args = argparse.Namespace(path=args.output, dot_only=True, out=None, format="png", no_open=True, engine="dot")
        visualize_command(viz_args)
        
    except Exception as e:
        print(f"Error during generation: {e}")
        sys.exit(1)

def demo_ai_command(args):
    """Command for AI branch generation demo."""
    print("=== Story Builder AI Demo ===")
    
    try:
        import story_builder_pro
        from story_builder_pro.ai.branch_generator import BranchGenerator
        from story_builder_pro.ai.provider_openrouter import OpenRouterProvider
    except ImportError:
        print("This demo requires story_builder_pro")
        sys.exit(1)

    api_key = args.api_key or os.getenv("OPENROUTER_API_KEY")
    is_mock = getattr(args, 'mock', False) or not api_key

    if is_mock:
        print("Running in MOCK mode (no API call).")

    print(f"\n[1/4] Loading base story")
    time.sleep(0.3)
    base_story_path = "examples/minimal_story.json"
    if not os.path.exists(base_story_path):
        print(f"Error: {base_story_path} not found.")
        sys.exit(1)
        
    try:
        graph = load_graph(base_story_path)
        print("Story loaded")
    except Exception as e:
        print(f"Error loading story: {e}")
        sys.exit(1)

    print(f"\n[2/4] Generating AI branches")
    time.sleep(0.3)
    try:
        node_id = "start" if "start" in graph.nodes else graph.start_node_id

        if is_mock:
            mock_ai_data = {
                "choices": [
                    {"trigger": "explore forest", "to": "forest_path"},
                    {"trigger": "enter village", "to": "village_square"},
                    {"trigger": "follow river", "to": "river_bank"}
                ],
                "new_nodes": [
                    {"id": "forest_path", "title": "The Forest Path", "body": "Distant birds chirp in the canopy.", "choices": []},
                    {"id": "village_square", "title": "Village Square", "body": "A bustling market with smells of fresh bread.", "choices": []},
                    {"id": "river_bank", "title": "The River Bank", "body": "The water flows swiftly toward the sea.", "choices": []}
                ]
            }
            generator = BranchGenerator(None)
            updated_graph = generator._merge_and_validate(graph, node_id, mock_ai_data)
            
            print(f"AI created {len(mock_ai_data['choices'])} choices")
            print(f"AI created {len(mock_ai_data['new_nodes'])} nodes")
        else:
            provider = OpenRouterProvider(api_key=api_key)
            generator = BranchGenerator(provider)
            
            nodes_before = len(graph.nodes)
            choices_before = len(graph.nodes[node_id].choices)
            
            updated_graph = generator.generate(
                graph=graph,
                node_id=node_id,
                goal="Add a mysterious branching path in the forest",
                max_choices=3
            )
            
            nodes_after = len(updated_graph.nodes)
            choices_after = len(updated_graph.nodes[node_id].choices)
            
            print(f"AI created {choices_after - choices_before} choices")
            print(f"AI created {nodes_after - nodes_before} nodes")
            
    except Exception as e:
        print(f"Error during AI generation: {e}")
        sys.exit(1)

    print(f"\n[3/4] Saving updated story")
    time.sleep(0.3)
    output_path = "examples/generated_story.json"
    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(updated_graph.model_dump_json(indent=2))
        print(f"Saved to {output_path}")
    except Exception as e:
        print(f"Error saving story: {e}")
        sys.exit(1)

    print(f"\n[4/4] Visualizing graph")
    time.sleep(0.3)
    try:
        viz_args = argparse.Namespace(path=output_path, dot_only=True, out=None, format="png", no_open=True, engine="dot")
        
        base, _ = os.path.splitext(output_path)
        out_dot = f"{base}.dot"
        
        with open(os.devnull, 'w') as f:
            old_stdout = sys.stdout
            sys.stdout = f
            try:
                visualize_command(viz_args)
            finally:
                sys.stdout = old_stdout
                
        print(f"Graph saved to {os.path.basename(out_dot)}")
    except Exception as e:
        print(f"Error during visualization: {e}")

    print(f"\nDemo complete.")

def main():
    parser = argparse.ArgumentParser(description="Story Builder Narrative Engine CLI")
    
    parser.add_argument("--load", type=str, help="Load an example story JSON (deprecated: use 'play' subcommand)")
    parser.add_argument("--play", action="store_true", help="Start a new adventure (deprecated: use 'play' subcommand)")

    subparsers = parser.add_subparsers(dest="subcommand", help="sub-command help")

    # init
    init_parser = subparsers.add_parser("init", help="Generate a starter story template.")
    init_parser.add_argument("--force", action="store_true", help="Overwrite existing story.json if it exists.")

    # generate
    gen_parser = subparsers.add_parser("generate", help="Generate a branching story graph using AI.")
    gen_parser.add_argument("prompt", help="Story theme or prompt.")
    gen_parser.add_argument("--nodes", type=int, default=6, help="Number of nodes to generate (default: 6).")
    gen_parser.add_argument("--output", type=str, default="story.json", help="Output JSON file (default: story.json).")
    gen_parser.add_argument("--api-key", type=str, help="OpenRouter API Key.")

    # validate
    val_parser = subparsers.add_parser("validate", help="Validate a story graph JSON file.")
    val_parser.add_argument("path", help="Path to the story JSON file.")

    # export
    exp_parser = subparsers.add_parser("export", help="Export a story graph to other formats.")
    exp_parser.add_argument("path", help="Path to the story JSON file.")
    exp_parser.add_argument("--format", type=str, default="json", choices=["json", "ink"], help="Export format (default: json).")

    # play
    play_parser = subparsers.add_parser("play", help="Play an interactive story.")
    play_parser.add_argument("path", nargs="?", help="Path to the story JSON file.")

    # visualize
    viz_parser = subparsers.add_parser("visualize", help="Generate a graph visualization from story JSON.")
    viz_parser.add_argument("path", help="Path to the story JSON file.")
    viz_parser.add_argument("--out", type=str, help="Output image path.")
    viz_parser.add_argument("--format", type=str, default="png", choices=["png", "svg"], help="Output format (default: png).")
    viz_parser.add_argument("--no-open", action="store_true", help="Do not auto-open the rendered image.")
    viz_parser.add_argument("--dot-only", action="store_true", help="Only generate the DOT file, skip rendering.")
    viz_parser.add_argument("--engine", type=str, default="dot", choices=["dot", "neato"], help="GraphViz layout engine (default: dot).")

    # demo-ai
    demo_ai_parser = subparsers.add_parser("demo-ai", help="Run an AI demo that generates branches.")
    demo_ai_parser.add_argument("--mock", action="store_true", help="Run in mock mode (no API calls).")
    demo_ai_parser.add_argument("--api-key", type=str, help="OpenRouter API Key.")

    args = parser.parse_args()

    if args.load:
        args.path = args.load
        play_command(args)
        return

    if args.subcommand == "play":
        play_command(args)
    elif args.subcommand == "visualize":
        visualize_command(args)
    elif args.subcommand == "demo-ai":
        demo_ai_command(args)
    elif args.subcommand == "init":
        init_command(args)
    elif args.subcommand == "generate":
        generate_command(args)
    elif args.subcommand == "validate":
        validate_command(args)
    elif args.subcommand == "export":
        export_command(args)
    else:
        parser.print_help()
        sys.exit(0)

if __name__ == "__main__":
    main()
