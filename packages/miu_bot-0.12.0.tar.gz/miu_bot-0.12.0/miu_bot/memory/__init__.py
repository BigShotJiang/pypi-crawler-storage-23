"""BASB 3-tier memory system: Active, Reference, Archive."""
