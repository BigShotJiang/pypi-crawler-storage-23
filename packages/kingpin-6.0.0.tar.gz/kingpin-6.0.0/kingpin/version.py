"""Kingpin version number. You must bump this when creating a new release."""

__version__ = "6.0.0"
