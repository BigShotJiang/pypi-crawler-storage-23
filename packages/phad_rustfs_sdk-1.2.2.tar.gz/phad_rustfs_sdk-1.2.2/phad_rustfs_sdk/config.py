"""
配置管理类

"""
# @Time    :
# @Author  : codelinghu
# @File    :

from typing import Optional


class PhadRustFSConfig:
    """Phad RustFS SDK 配置类"""
    
    def __init__(
        self,
        nacos_server: str,
        service_name: str = "llm-file",
        namespace: str = "public",
        username: Optional[str] = None,
        password: Optional[str] = None,
        default_service_url: Optional[str] = None,
        timeout: int = 30
    ):
        """
        初始化配置
        
        参数:
            nacos_server: Nacos服务器地址，格式为 "host:port"
            service_name: 服务名称，默认为 "llm-file"
            namespace: Nacos命名空间，默认为 "public"
            username: Nacos用户名（可选）
            password: Nacos密码（可选）
            default_service_url: 默认服务地址，当Nacos服务发现失败时使用
            timeout: 请求超时时间（秒），默认为30
        """
        self.nacos_server = nacos_server
        self.service_name = service_name
        self.namespace = namespace
        self.username = username
        self.password = password
        self.default_service_url = default_service_url
        self.timeout = timeout
    
    def validate(self) -> bool:
        """
        验证配置是否有效
        
        返回:
            配置是否有效
        """
        if not self.nacos_server:
            return False
        
        if self.username and not self.password:
            return False
        
        if self.password and not self.username:
            return False
        
        return True
