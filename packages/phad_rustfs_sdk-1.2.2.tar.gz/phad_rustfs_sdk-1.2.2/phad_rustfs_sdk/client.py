"""
客户端类

"""
# @Time    :
# @Author  : codelinghu
# @File    :

import logging
import os
import requests
from typing import Optional, Dict, Any, List

from .config import PhadRustFSConfig
from .exceptions import AuthenticationError, ServiceNotFoundError, APIError, FileNotFoundError


class PhadRustFSClient:
    """Phad RustFS 客户端类"""
    
    def __init__(self, config: PhadRustFSConfig):
        """
        初始化客户端
        
        参数:
            config: PhadRustFSConfig 配置对象
        """
        self.config = config
        self.base_url: Optional[str] = None
        self.access_token: Optional[str] = None
        self.logger = logging.getLogger(__name__)
    
    def _login_to_nacos(self) -> Optional[str]:
        """
        登录Nacos获取访问令牌
        
        返回:
            访问令牌，失败返回None
        """
        if not self.config.username or not self.config.password:
            return None
        
        try:
            login_url = f"http://{self.config.nacos_server}/nacos/v1/auth/login"
            response = requests.post(
                login_url,
                params={"username": self.config.username, "password": self.config.password},
                timeout=5
            )
            
            if response.status_code == 200:
                data = response.json()
                return data.get("accessToken")
            else:
                raise AuthenticationError(f"Nacos登录失败，状态码: {response.status_code}")
        except requests.RequestException as e:
            self.logger.error(f"Nacos登录请求失败: {e}")
            raise AuthenticationError(f"Nacos登录请求失败: {str(e)}")
    
    def _get_service_address(self) -> str:
        """
        从Nacos获取服务地址
        
        返回:
            服务地址，格式为 "http://ip:port"
        
        异常:
            ServiceNotFoundError: 当服务未找到时抛出
        """
        try:
            if not self.access_token and (self.config.username or self.config.password):
                self.access_token = self._login_to_nacos()
            
            nacos_url = f"http://{self.config.nacos_server}/nacos/v1/ns/instance/list"
            params = {
                "serviceName": self.config.service_name,
                "namespaceId": self.config.namespace,
                "healthyOnly": "true"
            }
            
            if self.access_token:
                params["accessToken"] = self.access_token
            
            response = requests.get(nacos_url, params=params, timeout=5)
            
            if response.status_code == 200:
                data = response.json()
                hosts = data.get("hosts", [])
                
                if hosts:
                    instance = hosts[0]
                    ip = instance.get("ip")
                    port = instance.get("port")
                    if ip and port:
                        return f"http://{ip}:{port}"
                
                raise ServiceNotFoundError(f"服务 '{self.config.service_name}' 未找到或没有健康的实例")
            else:
                raise ServiceNotFoundError(f"获取服务地址失败，状态码: {response.status_code}")
        except requests.RequestException as e:
            self.logger.error(f"获取服务地址失败: {e}")
            raise ServiceNotFoundError(f"获取服务地址失败: {str(e)}")
    
    def _ensure_base_url(self) -> str:
        """
        确保base_url已设置
        
        返回:
            base_url
        """
        if not self.base_url:
            self.base_url = self._get_service_address()
        return self.base_url
    
    def get_file_list(self, file_ids: List[int]) -> Dict[str, Any]:
        """
        获取文件列表
        
        参数:
            file_ids: 文件ID列表
        
        返回:
            包含文件列表的字典，格式为:
            {
                "success": bool,
                "data": {
                    "code": int,
                    "msg": str,
                    "data": [
                        {
                            "fileId": int,
                            "name": str,
                            "url": str,
                            "fileSize": int,
                            ...
                        }
                    ]
                }
            }
        
        异常:
            APIError: 当API调用失败时抛出
        """
        try:
            base_url = self._ensure_base_url()
            request_url = f"{base_url}/file/getFileList"
            self.logger.info(f"获取文件列表: {request_url}")
            
            payload = {"fileIds": file_ids}
            self.logger.info(f"请求参数: {payload}")
            
            response = requests.post(
                request_url,
                json=payload,
                timeout=self.config.timeout
            )
            
            self.logger.info(f"响应状态码: {response.status_code}")
            self.logger.info(f"响应内容: {response.text}")
            
            try:
                result = response.json()
                code = result.get("code")
                msg = result.get("msg", "未知错误")
                
                if response.status_code == 200 and (code == 200 or msg == "操作成功"):
                    return {"success": True, "data": result}
                else:
                    raise APIError(
                        f"获取文件列表失败: {msg}",
                        status_code=response.status_code,
                        response_data=result
                    )
            except ValueError as e:
                raise APIError(
                    f"解析响应失败: {response.status_code} - {response.text}",
                    status_code=response.status_code
                )
        except requests.RequestException as e:
            self.logger.error(f"获取文件列表时出错: {e}")
            raise APIError(f"获取文件列表时出错: {str(e)}")
    
    def get_file_info(self, file_id: int) -> Dict[str, Any]:
        """
        获取单个文件信息
        
        参数:
            file_id: 文件ID
        
        返回:
            包含文件信息的字典
        
        异常:
            APIError: 当API调用失败时抛出
        """
        result = self.get_file_list([file_id])
        
        if result["success"]:
            file_list = result["data"].get("data", [])
            if file_list:
                return file_list[0]
            else:
                raise APIError(f"文件ID {file_id} 未找到")
        
        return result
    
    def get_file_url(self, file_id: int) -> str:
        """
        获取文件URL
        
        参数:
            file_id: 文件ID
        
        返回:
            文件URL
        
        异常:
            APIError: 当API调用失败时抛出
        """
        file_info = self.get_file_info(file_id)
        url = file_info.get("url")
        
        if not url:
            raise APIError(f"文件ID {file_id} 没有URL")
        
        return url
    
    def refresh_service_address(self) -> str:
        """
        刷新服务地址（重新从Nacos获取）
        
        返回:
            新的服务地址
        """
        self.base_url = None
        self.access_token = None
        return self._ensure_base_url()
    
    def upload_file(
        self,
        file_path: str,
        source_type: int = 1,
        from_data_id: Optional[str] = None,
        rename: bool = True,
        bucket_name: Optional[str] = None,
        folder_name: Optional[str] = None,
        storage_type: int = 1
    ) -> Dict[str, Any]:
        """
        上传文件到远程服务
        
        参数:
            file_path: 文件路径
            source_type: 文件来源：1-系统, 2-web (默认: 1)
            from_data_id: 数据来源记录ID (可选)
            rename: 重命名标记：true-重命名, false-不重命名 (默认: true)
            bucket_name: 自定义文件桶名称 (可选)
            folder_name: 自定义文件夹名称 (可选)
            storage_type: 存储类型：1-内网, 2-外网 (默认: 1)
        
        返回:
            上传结果字典，格式为:
            {
                "success": bool,
                "data": {
                    "fileId": int,
                    "url": str,
                    ...
                }
            }
        
        异常:
            FileNotFoundError: 当文件不存在时抛出
            APIError: 当API调用失败时抛出
        """
        try:
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"文件不存在: {file_path}")
            
            base_url = self._ensure_base_url()
            upload_url = f"{base_url}/file/uploadFile"
            self.logger.info(f"上传文件到: {upload_url}")
            
            source_type_value = "SYSTEM" if source_type == 1 else "WEB" if source_type == 2 else str(source_type)
            storage_type_value = "INTERNAL_NET" if storage_type == 1 else "EXTERNAL_NET" if storage_type == 2 else str(storage_type)
            
            data = {
                "sourceType": source_type_value,
                "rename": str(rename),
                "storageType": storage_type_value
            }
            
            if from_data_id is not None:
                data["fromDataId"] = str(from_data_id)
            if bucket_name is not None:
                data["bucketName"] = bucket_name
            if folder_name is not None:
                data["folderName"] = folder_name
            
            with open(file_path, "rb") as f:
                files = {
                    "file": (os.path.basename(file_path), f, "application/octet-stream")
                }
                
                response = requests.post(upload_url, data=data, files=files, timeout=self.config.timeout)
                self.logger.info(f"响应状态码: {response.status_code}")
                self.logger.info(f"响应内容: {response.text}")
                
                try:
                    result = response.json()
                    code = result.get("code")
                    msg = result.get("msg", "未知错误")
                    
                    if response.status_code == 200 and (code == 200 or msg == "操作成功"):
                        return {"success": True, "data": result}
                    else:
                        raise APIError(
                            f"上传失败: {msg}",
                            status_code=response.status_code,
                            response_data=result
                        )
                except ValueError as e:
                    raise APIError(
                        f"解析响应失败: {response.status_code} - {response.text}",
                        status_code=response.status_code
                    )
        except requests.RequestException as e:
            self.logger.error(f"上传文件时出错: {e}")
            raise APIError(f"上传文件时出错: {str(e)}")
    
    def delete_file(self, file_id: int) -> Dict[str, Any]:
        """
        删除文件
        
        参数:
            file_id: 文件ID
        
        返回:
            删除结果字典，格式为:
            {
                "success": bool,
                "data": {
                    "code": int,
                    "msg": str,
                    ...
                }
            }
        
        异常:
            APIError: 当API调用失败时抛出
        """
        try:
            base_url = self._ensure_base_url()
            delete_url = f"{base_url}/file/delete/{file_id}"
            self.logger.info(f"删除文件: {delete_url}")
            
            response = requests.delete(delete_url, timeout=self.config.timeout)
            self.logger.info(f"响应状态码: {response.status_code}")
            self.logger.info(f"响应内容: {response.text}")
            
            try:
                result = response.json()
                code = result.get("code")
                msg = result.get("msg", "未知错误")
                
                if response.status_code == 200 and (code == 200 or msg == "操作成功"):
                    return {"success": True, "data": result}
                else:
                    raise APIError(
                        f"删除文件失败: {msg}",
                        status_code=response.status_code,
                        response_data=result
                    )
            except ValueError as e:
                raise APIError(
                    f"解析响应失败: {response.status_code} - {response.text}",
                    status_code=response.status_code
                )
        except requests.RequestException as e:
            self.logger.error(f"删除文件时出错: {e}")
            raise APIError(f"删除文件时出错: {str(e)}")
