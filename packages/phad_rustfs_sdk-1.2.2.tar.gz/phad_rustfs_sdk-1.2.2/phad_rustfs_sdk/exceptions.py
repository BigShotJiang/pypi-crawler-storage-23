"""
异常类定义

"""
# @Time    :
# @Author  : codelinghu
# @File    :


class PhadRustFSError(Exception):
    """Phad RustFS SDK 基础异常类"""
    pass


class AuthenticationError(PhadRustFSError):
    """Nacos认证失败异常"""
    pass


class ServiceNotFoundError(PhadRustFSError):
    """服务未找到异常"""
    pass


class APIError(PhadRustFSError):
    """API调用失败异常"""
    def __init__(self, message: str, status_code: int = None, response_data: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response_data = response_data


class FileNotFoundError(PhadRustFSError):
    """文件未找到异常"""
    pass
