"""Auto-generated file, do not edit by hand. 90 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_90 = [NumberFormat(pattern='(\\d{3})(\\d{3})(\\d{4})', format='\\1 \\2 \\3', leading_digits_pattern=['[2-4]|5(?:[02-79]|1[06])']), NumberFormat(pattern='(\\d{3})(\\d{3})(\\d{2})(\\d{2})', format='\\1 \\2 \\3 \\4', leading_digits_pattern=['512|[89]'])]
