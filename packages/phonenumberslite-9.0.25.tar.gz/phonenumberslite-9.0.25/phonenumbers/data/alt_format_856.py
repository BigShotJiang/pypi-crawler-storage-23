"""Auto-generated file, do not edit by hand. 856 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_856 = [NumberFormat(pattern='(\\d{3})(\\d{3})(\\d{4})', format='\\1 \\2 \\3'), NumberFormat(pattern='(\\d{2})(\\d{4})(\\d{4})', format='\\1 \\2 \\3'), NumberFormat(pattern='(\\d{2})(\\d{8})', format='\\1 \\2')]
