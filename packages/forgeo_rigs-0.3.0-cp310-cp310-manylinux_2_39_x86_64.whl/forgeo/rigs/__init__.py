from forgeo.rigs._version import __version__
from forgeo.rigs.rigs import (
    all_intersections,
    which_domain,
    BSPTree,
    Discontinuities,
    Side,
)
