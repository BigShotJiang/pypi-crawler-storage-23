---
type: agent
model: $system.demo
skills: []
default: true
servers:
  - mcp_sessions_probe
---

Data-layer session probe demo (draft).

Use `session_probe` with a `note` argument, for example:

- "Call session_probe with note=first turn."
- "Call session_probe with note=second turn."

Use `/mcp` to inspect session metadata.
