class LaituriError(Exception):
    """Base class for Laituri errors."""
