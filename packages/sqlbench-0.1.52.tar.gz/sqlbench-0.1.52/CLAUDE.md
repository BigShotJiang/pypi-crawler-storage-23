# Claude Code Instructions

## Git Commits
- NEVER mention Claude, AI, or include Co-Authored-By lines in git commit messages
