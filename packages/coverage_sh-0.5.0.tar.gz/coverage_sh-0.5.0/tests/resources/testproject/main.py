#  SPDX-License-Identifier: MIT
#  Copyright (c) 2023-2024 Kilian Lackhove

import subprocess


def main() -> None:
    subprocess.run(["./test.sh"])


if __name__ == "__main__":
    main()
