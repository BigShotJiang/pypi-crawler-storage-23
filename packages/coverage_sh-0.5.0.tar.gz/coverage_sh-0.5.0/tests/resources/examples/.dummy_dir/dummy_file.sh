#!/usr/bin/bash

#
# SPDX-License-Identifier: MIT
# Copyright (c) 2024 Kilian Lackhove
#

echo "this should not be reported"