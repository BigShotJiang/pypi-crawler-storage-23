#  SPDX-License-Identifier: MIT
#  Copyright (c) 2023 Kilian Lackhove


def main() -> None:
    print("hello world")


if __name__ == "__main__":
    main()
