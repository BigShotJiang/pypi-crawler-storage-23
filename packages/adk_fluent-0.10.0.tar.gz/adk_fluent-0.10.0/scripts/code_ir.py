"""Code IR — backward-compatible shim (vestigial).

The implementation lives in the ``scripts/code_ir/`` package.
When Python sees both code_ir.py and code_ir/ in the same directory,
the package takes precedence.  This file only exists for documentation
and is never actually imported.
"""
