from brisque.brisque import BRISQUE
from brisque.trainer import BRISQUETrainer

__version__ = "0.1.0"
