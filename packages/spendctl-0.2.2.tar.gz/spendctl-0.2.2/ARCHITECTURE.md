# Architecture

This document explains the high-level design of spendctl for contributors and maintainers.

## Overview

spendctl is a Python CLI that tracks personal finances using SQLite. It provides both a command-line interface and a 7-page Streamlit dashboard for visualization.

```
User ──► CLI (argparse) ──► Query Modules ──► SQLite Database
User ──► Dashboard (Streamlit) ──► Query Modules ──► SQLite Database
```

All data operations flow through the query modules — neither the CLI nor the dashboard issue raw SQL directly (except for a few dashboard-specific aggregations in `helpers.py`).

## Directory Structure

```
src/spendctl/
├── __init__.py            # Version string
├── __main__.py            # python -m spendctl entry point
├── cli.py                 # Argparse CLI with 14 commands, --json on every command
├── config.py              # Paths, accounts, categories, budgets, accessor functions
├── db.py                  # Connection management, schema init, backup
├── init_wizard.py         # Interactive setup wizard and config editing
├── models.py              # Dataclasses (Transaction, CheckIn, Subscription)
├── schema.sql             # DDL: 9 tables, 1 view, 9 indexes
├── queries/
│   ├── __init__.py        # Public API re-exports
│   ├── _utils.py          # Shared date utilities (default_month, month_range)
│   ├── budget.py          # budget_vs_actual, remaining_budget, total_income, cushion
│   ├── check_ins.py       # add_check_in, get_latest, reconcile
│   ├── dashboard.py       # account_balance, all_balances, net_worth, debt_progress
│   ├── reports.py         # monthly_summary, cash_flow, spending_by_category
│   ├── subscriptions.py   # CRUD for recurring subscriptions
│   └── transactions.py    # CRUD, filtering, duplicate detection
└── dashboard/
    ├── app.py             # Streamlit entry point (page config + redirect)
    ├── helpers.py         # Shared formatting utilities, month selector widget
    └── pages/
        ├── 1_dashboard.py     # Overview: sparklines, net worth gauge, budget summary
        ├── 2_spending.py      # Category pie/bar charts, budget alerts
        ├── 3_debt.py          # Progress bars, payoff projections, interest savings
        ├── 4_transactions.py  # Filterable transaction table
        ├── 5_subscriptions.py # Active/paused/canceled subscription list
        ├── 6_loans.py         # Student loan payoff tracking
        └── 7_report.py        # Printable monthly budget report
```

## Config System

Config lives at `~/.config/spendctl/config.json` and is created by `spendctl init`. The file defines:

- **accounts** — list of account objects with name, type, institution, APR
- **categories** — list with name, group, and monthly budget amount
- **income_sources** — expected monthly income by name and amount
- **targets** — financial goals (target date, emergency fund target)
- **min_payments** — minimum payments keyed by account name
- **loans** — optional loan detail groups for student loan tracking
- **ai** — Ollama endpoint URL and selected model for `spendctl ask`
- **integrations** — flags for which terminal AI assistants have been auto-configured (Claude Code, Codex CLI, Gemini CLI, Aider)

`config.py` uses lazy loading: the first call to any accessor function reads and caches the JSON file. Subsequent calls return from cache. After `config edit`, `reload_config()` clears the cache and re-reads from disk.

Account type is the config's single source of truth — accessor functions like `get_debt_accounts()` and `get_student_loan_accounts()` derive their results from account types rather than separate config keys.

Data paths are derived from the config directory:

```
~/.config/spendctl/
├── config.json            # User configuration
└── data/
    ├── spendctl.db        # Main database
    └── backups/           # Timestamped database backups
```

## Database Schema

The schema lives in `schema.sql` and is applied via `init_db()` on first connection to a new database.

**Lookup tables** (seeded from config on first init):

| Table | Purpose |
|-------|---------|
| `accounts` | Account name, type, institution, APR, starting balance |
| `categories` | Category name, group, monthly budget amount |
| `transaction_types` | Expense, Income, Transfer, Debt Payment, Interest, Reconciliation |
| `budget_income` | Expected income sources and amounts |

**Core tables:**

| Table | Purpose |
|-------|---------|
| `transactions` | Every financial transaction with date, amount, type, accounts, category |
| `check_ins` | Periodic balance snapshot headers (date, label, notes) |
| `check_in_balances` | Normalized balance values per account per check-in |
| `subscriptions` | Recurring charges with status tracking (Active/Canceled/Paused) |
| `settings` | Key-value store for runtime settings (e.g., baseline date) |

Check-ins use a normalized design: `check_ins` holds the snapshot header, and `check_in_balances` holds one row per account per check-in. This means new accounts can be added without a schema change.

**Views:**

| View | Purpose |
|------|---------|
| `v_monthly_expenses` | Pre-aggregated spending by month and category |

**Indexes:** 9 indexes on transactions (date, category, type, from/to account, date+category) and check-ins (date, check-in ID, account name) for common query patterns.

All queries use parameterized SQL (`?` placeholders) to prevent injection.

## Query Layer

The 6 query modules in `queries/` provide the data access API:

| Module | Key Functions | Purpose |
|--------|--------------|---------|
| `transactions` | `add_transaction`, `list_transactions` | Transaction CRUD and filtering |
| `budget` | `budget_vs_actual`, `remaining_budget`, `total_income` | Budget analysis |
| `check_ins` | `add_check_in`, `get_latest_check_in` | Balance snapshots |
| `dashboard` | `account_balance`, `all_balances`, `net_worth`, `debt_progress` | Live balance computation |
| `reports` | `monthly_summary`, `spending_by_category`, `cash_flow` | Reporting and summaries |
| `subscriptions` | `list_subscriptions`, `active_monthly_total` | Subscription tracking |

All functions accept a `sqlite3.Connection` as the first argument and return plain dicts or lists of dicts. This keeps them easily testable with in-memory databases and JSON-serializable for `--json` output.

## CLI

`cli.py` uses argparse with a subcommand pattern. Each command has a handler function (`cmd_*`) that:

1. Calls `_config_guard()` to verify config exists before doing any work
2. Validates date/month arguments with regex + `date.fromisoformat()`
3. Opens a DB connection via `ensure_db()`
4. Calls the appropriate query function(s)
5. Serializes output: JSON via `json.dumps()` if `--json` is set, otherwise formatted text

The `--json` flag is present on every command. Consumers (AI assistants, shell scripts) can reliably pipe any command to `jq` or a parser without checking first.

The `ask` command is the exception to the query-module pattern: it assembles a financial context snapshot (balance, spending, debt, budget) by calling several query functions, serializes the result as JSON, and forwards it to an Ollama instance via a stdlib `urllib.request` HTTP call. No third-party HTTP library is required. The Ollama endpoint and model are read from the `ai` config key.

## Dashboard

The Streamlit dashboard is a multi-page app launched via `spendctl dashboard`. It requires the optional `[dashboard]` extras (`streamlit`, `plotly`, `pandas`).

- `app.py` sets page config and immediately redirects to the main dashboard page
- Each page in `pages/` is an independent Streamlit script; Streamlit loads them alphabetically from the directory
- `helpers.py` provides shared formatting utilities, a consistent color palette, and the month-selector widget used across pages
- Database connections use `@st.cache_resource` for a single shared connection per server process

All charts use Plotly. The dashboard reads account/category configuration from `config.py` to drive chart labels and budget targets, so adding a new account or category in the config is reflected in the dashboard without code changes.

## Testing

- **Framework:** pytest with in-memory SQLite fixtures
- **Fixture:** `conftest.py` provides a fully seeded in-memory database with sample transactions, check-ins, and subscriptions — no disk I/O in tests
- **Config isolation:** Tests monkeypatch `CONFIG_PATH` to a temp directory and reset `_config_cache` in `autouse` fixtures to prevent state leakage between tests
- **Coverage:** All query modules, CLI argument validation, config loading, init wizard, and database layer
- **Test files:** 10 test modules, 221 tests, all passing
- **Config:** pytest settings and coverage in `pyproject.toml`, lint via ruff
