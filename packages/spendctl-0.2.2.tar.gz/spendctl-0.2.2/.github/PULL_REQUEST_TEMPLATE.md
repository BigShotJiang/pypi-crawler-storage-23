## What does this PR do?

<!-- Brief description of the change -->

## Why is this needed?

<!-- What problem does it solve? Link to related issue if applicable -->

## How was this tested?

- [ ] Existing tests pass (`pytest`)
- [ ] New tests added (if applicable)
- [ ] Manually tested (`spendctl ...`)

## Checklist

- [ ] Code follows existing patterns in the codebase
- [ ] No unnecessary runtime dependencies added
- [ ] Documentation updated (if user-facing change)
- [ ] Lint passes (`ruff check src/ tests/`)
