"""Tests for spendctl.init_wizard module."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

import spendctl.config as cfg_module
import spendctl.init_wizard as wizard_module
from spendctl.init_wizard import (
    DEFAULT_CATEGORIES,
    _collect_ai_integration,
    _collect_dashboard,
    _collect_ollama,
    _upsert_section,
    edit_config,
    reset_config,
    run_init,
    show_config,
)

# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture(autouse=True)
def reset_cache():
    """Reset config cache before each test."""
    cfg_module._config_cache = None
    yield
    cfg_module._config_cache = None


@pytest.fixture()
def tmp_config_path(tmp_path, monkeypatch):
    """Patch CONFIG_PATH to a temp location (file does not yet exist)."""
    cfg_path = tmp_path / "config.json"
    monkeypatch.setattr(cfg_module, "CONFIG_PATH", cfg_path)
    monkeypatch.setattr(wizard_module, "CONFIG_PATH", cfg_path)
    # Also patch CONFIG_DIR for save_config mkdir
    monkeypatch.setattr(cfg_module, "CONFIG_DIR", tmp_path)
    return cfg_path


@pytest.fixture()
def no_new_sections():
    """Patch the three new wizard sections so tests don't need extra inputs."""
    with (
        patch("spendctl.init_wizard._collect_dashboard", return_value=False),
        patch("spendctl.init_wizard._collect_ollama", return_value=None),
        patch("spendctl.init_wizard._collect_ai_integration", return_value=[]),
    ):
        yield


@pytest.fixture()
def existing_config(tmp_config_path):
    """Write a minimal config so config_exists() returns True."""
    data = {
        "accounts": [{"name": "Checking", "type": "checking"}, {"name": "External", "type": "external"}],
        "income_sources": [{"name": "Pay", "amount": 3000.0}],
        "categories": [c.copy() for c in DEFAULT_CATEGORIES],
        "targets": {},
        "min_payments": {},
        "loans": [],
    }
    tmp_config_path.write_text(json.dumps(data))
    return tmp_config_path


# ── run_init ──────────────────────────────────────────────────────────────────


def test_run_init_creates_config_file(tmp_config_path, no_new_sections):
    """run_init with minimal input creates config.json."""
    inputs = [
        # Accounts section
        "Checking",   # account name
        "1",          # type: checking
        "Ally",       # institution
        "",           # description
        "done",       # no more accounts
        # Income section
        "Primary Income",   # income source
        "4500",       # amount
        "done",       # no more income
        # Categories section (just accept defaults)
        "done",
        # Targets section
        "",           # target date (skip)
        "",           # target label (skip)
        "",           # EF target (skip)
        # Min payments — Checking has no debt type so this section won't prompt per-account
        # (no debt accounts added, section just prints "No debt accounts")
        # Loans — no student loan accounts
    ]
    with patch("builtins.input", side_effect=inputs):
        run_init()

    assert tmp_config_path.exists()
    data = json.loads(tmp_config_path.read_text())
    assert "accounts" in data
    assert "categories" in data


def test_run_init_adds_external_automatically(tmp_config_path, no_new_sections):
    """External account is auto-added even if user doesn't mention it."""
    inputs = [
        # Accounts — only add a checking account, skip External
        "Checking",
        "1",   # checking
        "",    # institution
        "",    # description
        "done",
        # Income
        "done",
        # Categories
        "done",
        # Targets
        "", "", "",
        # (no debt, no loans)
    ]
    with patch("builtins.input", side_effect=inputs):
        run_init()

    data = json.loads(tmp_config_path.read_text())
    account_names = [a["name"] for a in data["accounts"]]
    assert "External" in account_names


def test_run_init_aborts_if_user_declines_overwrite(existing_config, capsys):
    """If config exists and user says 'n', wizard aborts without overwriting."""
    original = existing_config.read_text()
    with patch("builtins.input", return_value="n"):
        run_init()
    assert existing_config.read_text() == original
    captured = capsys.readouterr()
    assert "Aborted" in captured.out


# ── Default categories ────────────────────────────────────────────────────────


def test_default_categories_included(tmp_config_path, no_new_sections):
    """All DEFAULT_CATEGORIES names are written to config on init."""
    inputs = [
        "done",   # no accounts (External auto-added)
        "done",   # no income
        "done",   # accept default categories
        "", "", "",  # targets
    ]
    with patch("builtins.input", side_effect=inputs):
        run_init()

    data = json.loads(tmp_config_path.read_text())
    written_names = {c["name"] for c in data["categories"]}
    default_names = {c["name"] for c in DEFAULT_CATEGORIES}
    assert default_names == written_names


# ── show_config ───────────────────────────────────────────────────────────────


def test_show_config_prints_json(existing_config, capsys):
    """show_config prints valid JSON to stdout."""
    show_config()
    captured = capsys.readouterr()
    parsed = json.loads(captured.out)
    assert "accounts" in parsed


def test_show_config_no_config_message(tmp_config_path, capsys):
    """show_config prints a helpful message when no config exists."""
    show_config()
    captured = capsys.readouterr()
    assert "spendctl init" in captured.out


# ── reset_config ──────────────────────────────────────────────────────────────


def test_reset_config_deletes_and_reruns(existing_config, no_new_sections):
    """reset_config removes existing config, then runs the full wizard."""
    inputs = [
        "y",       # confirm deletion
        # run_init inputs (minimal)
        "done",    # no accounts
        "done",    # no income
        "done",    # accept categories
        "", "", "",  # targets
    ]
    with patch("builtins.input", side_effect=inputs):
        reset_config()

    # Config should have been recreated
    assert existing_config.exists()
    data = json.loads(existing_config.read_text())
    assert "categories" in data


def test_reset_config_aborts_on_no(existing_config, capsys):
    """reset_config does nothing if user says n."""
    original = existing_config.read_text()
    with patch("builtins.input", return_value="n"):
        reset_config()
    assert existing_config.read_text() == original
    captured = capsys.readouterr()
    assert "Aborted" in captured.out


# ── edit_config ───────────────────────────────────────────────────────────────


def test_edit_config_no_config_message(tmp_config_path, capsys):
    """edit_config prints helpful message when no config exists."""
    edit_config("income")
    captured = capsys.readouterr()
    assert "spendctl init" in captured.out


def test_edit_config_income_section(existing_config):
    """edit_config with section='income' adds a new income source."""
    inputs = [
        "Side Hustle",  # new income source
        "500",          # amount
        "done",         # no more
    ]
    with patch("builtins.input", side_effect=inputs):
        edit_config("income")

    data = json.loads(existing_config.read_text())
    names = [s["name"] for s in data["income_sources"]]
    assert "Side Hustle" in names
    assert "Pay" in names  # original preserved


# ── Section 7: Dashboard ──────────────────────────────────────────────────────


def test_dashboard_install_prompt_yes(capsys):
    """User says yes — subprocess.run is called and success message printed."""
    mock_result = MagicMock()
    mock_result.returncode = 0
    with (
        patch("builtins.input", return_value="y"),
        patch("spendctl.init_wizard.subprocess.run", return_value=mock_result) as mock_run,
    ):
        result = _collect_dashboard()

    assert result is True
    mock_run.assert_called_once()
    captured = capsys.readouterr()
    assert "installed" in captured.out.lower()


def test_dashboard_install_prompt_no(capsys):
    """User says no — subprocess.run is not called and function returns False."""
    with (
        patch("builtins.input", return_value="n"),
        patch("spendctl.init_wizard.subprocess.run") as mock_run,
    ):
        result = _collect_dashboard()

    assert result is False
    mock_run.assert_not_called()


def test_dashboard_install_pip_failure(capsys):
    """If pip fails, error is shown but function continues (returns False)."""
    mock_result = MagicMock()
    mock_result.returncode = 1
    mock_result.stderr = "Some pip error"
    mock_result.stdout = ""
    with (
        patch("builtins.input", return_value="y"),
        patch("spendctl.init_wizard.subprocess.run", return_value=mock_result),
    ):
        result = _collect_dashboard()

    assert result is False
    captured = capsys.readouterr()
    assert "Error" in captured.out or "error" in captured.out


# ── Section 8: Ollama setup ────────────────────────────────────────────────────


def test_ollama_detection_local(capsys):
    """When local Ollama responds, flow goes straight to model selection."""
    with (
        patch("spendctl.init_wizard._try_ollama_connection", return_value=True),
        patch("spendctl.init_wizard._list_ollama_models", return_value=["llama3.2"]),
        patch("spendctl.init_wizard._test_ollama_model", return_value=True),
        patch("builtins.input", return_value="1"),
    ):
        result = _collect_ollama()

    assert result is not None
    assert result["provider"] == "ollama"
    assert result["model"] == "llama3.2"
    assert result["endpoint"] == "http://localhost:11434"


def test_ollama_detection_remote(capsys):
    """User provides a remote endpoint that connects successfully."""
    call_count = {"n": 0}

    def mock_try_connection(endpoint, timeout=5):
        call_count["n"] += 1
        # First call is localhost (fails), second is the remote endpoint
        return endpoint != "http://localhost:11434"

    inputs_iter = iter(["1", "http://192.168.1.50:11434", "1"])
    with (
        patch("spendctl.init_wizard._try_ollama_connection", side_effect=mock_try_connection),
        patch("spendctl.init_wizard._list_ollama_models", return_value=["mistral"]),
        patch("spendctl.init_wizard._test_ollama_model", return_value=True),
        patch("builtins.input", side_effect=inputs_iter),
    ):
        result = _collect_ollama()

    assert result is not None
    assert result["endpoint"] == "http://192.168.1.50:11434"
    assert result["model"] == "mistral"


def test_ollama_skip(capsys):
    """User chooses to skip Ollama setup."""
    with (
        patch("spendctl.init_wizard._try_ollama_connection", return_value=False),
        patch("builtins.input", return_value="2"),
    ):
        result = _collect_ollama()

    assert result is None
    captured = capsys.readouterr()
    assert "Skip" in captured.out or "Skipping" in captured.out


def test_ollama_no_models(capsys):
    """When no models are available, user can skip."""
    with (
        patch("spendctl.init_wizard._try_ollama_connection", return_value=True),
        patch("spendctl.init_wizard._list_ollama_models", return_value=[]),
        patch("builtins.input", return_value="y"),  # "Skip AI setup? (y/n)" -> yes
    ):
        result = _collect_ollama()

    assert result is None


# ── Section 9: AI integration ─────────────────────────────────────────────────


def test_ai_integration_claude_code(tmp_path, capsys):
    """Claude Code selection appends context to CLAUDE.md."""
    # The wizard writes to Path.home() / ".claude" / "CLAUDE.md"
    claude_md = tmp_path / ".claude" / "CLAUDE.md"
    claude_md.parent.mkdir(parents=True, exist_ok=True)
    claude_md.write_text("# Existing content\n")

    with (
        patch("builtins.input", return_value="1"),
        patch("spendctl.init_wizard.Path.home", side_effect=lambda: tmp_path),
    ):
        result = _collect_ai_integration()

    assert "claude" in result
    content = claude_md.read_text()
    assert "## spendctl" in content
    assert "spendctl add" in content


def test_ai_integration_multi_select(tmp_path, capsys):
    """Multiple selections (1, 2) configure both Claude Code and Codex."""
    # The wizard writes to Path.home() / ".claude" / "CLAUDE.md" and
    # Path.home() / ".codex" / "AGENTS.md"
    claude_md = tmp_path / ".claude" / "CLAUDE.md"
    agents_md = tmp_path / ".codex" / "AGENTS.md"
    claude_md.parent.mkdir(parents=True, exist_ok=True)

    with (
        patch("builtins.input", return_value="1, 2"),
        patch("spendctl.init_wizard.Path.home", side_effect=lambda: tmp_path),
    ):
        result = _collect_ai_integration()

    assert "claude" in result
    assert "codex" in result
    assert claude_md.exists()
    assert agents_md.exists()


def test_ai_integration_none(capsys):
    """Choosing 'none' returns empty list."""
    with patch("builtins.input", return_value="none"):
        result = _collect_ai_integration()

    assert result == []


def test_ai_integration_upsert_replaces_existing_section(tmp_path):
    """_upsert_section replaces an existing ## spendctl block, not duplicates it."""
    md_file = tmp_path / "TEST.md"
    md_file.write_text("# Top\n\n## spendctl\n\nOld content here.\n\n## Other\n\nKeep this.\n")

    _upsert_section(md_file, "## spendctl", "\nNew content.\n")

    content = md_file.read_text()
    assert content.count("## spendctl") == 1
    assert "New content" in content
    assert "Old content" not in content
    # Other section preserved
    assert "## Other" in content
    assert "Keep this" in content
