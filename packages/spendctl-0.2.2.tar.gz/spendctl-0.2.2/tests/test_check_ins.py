"""Tests for spendctl.queries.check_ins — normalized check-in tables."""

from __future__ import annotations

from spendctl.queries.check_ins import (
    add_check_in,
    add_reconciliation_adjustment,
    get_check_in_history,
    get_latest_check_in,
    reconcile_balances,
)
from spendctl.queries.dashboard import account_balance


class TestAddCheckIn:
    def test_returns_int_id(self, db):
        cid = add_check_in(
            db,
            date="2026-02-15",
            check_in_number="CI-002",
            balances={"Checking": 3500.00, "Credit Card": 1200.00},
        )
        assert isinstance(cid, int)
        assert cid > 0

    def test_balances_stored_in_normalized_table(self, db):
        cid = add_check_in(
            db,
            date="2026-02-15",
            balances={"Checking": 4000.00, "Savings": 5500.00},
        )
        rows = db.execute(
            "SELECT account_name, balance FROM check_in_balances WHERE check_in_id = ?",
            (cid,),
        ).fetchall()
        balances = {r["account_name"]: r["balance"] for r in rows}
        assert balances["Checking"] == 4000.00
        assert balances["Savings"] == 5500.00

    def test_none_balances_not_stored(self, db):
        cid = add_check_in(
            db,
            date="2026-02-15",
            balances={"Checking": 4000.00, "Savings": None},
        )
        rows = db.execute(
            "SELECT account_name FROM check_in_balances WHERE check_in_id = ?",
            (cid,),
        ).fetchall()
        names = {r["account_name"] for r in rows}
        assert "Savings" not in names
        assert "Checking" in names

    def test_no_balances_ok(self, db):
        cid = add_check_in(db, date="2026-02-28", notes="End of month")
        assert isinstance(cid, int)
        count = db.execute(
            "SELECT COUNT(*) FROM check_in_balances WHERE check_in_id = ?", (cid,)
        ).fetchone()[0]
        assert count == 0


class TestGetLatestCheckIn:
    def test_returns_most_recent(self, db):
        add_check_in(db, date="2026-02-15", check_in_number="CI-002", balances={"Checking": 3500.00})
        latest = get_latest_check_in(db)
        assert latest is not None
        assert latest["date"] == "2026-02-15"
        assert latest["check_in_number"] == "CI-002"

    def test_returns_seeded_when_only_one(self, db):
        latest = get_latest_check_in(db)
        assert latest is not None
        assert latest["date"] == "2026-02-01"
        assert latest["check_in_number"] == "CI-001"

    def test_includes_balances_dict(self, db):
        latest = get_latest_check_in(db)
        assert "balances" in latest
        assert isinstance(latest["balances"], dict)
        assert "Checking" in latest["balances"]
        assert latest["balances"]["Checking"] == 3200.00

    def test_returns_none_when_empty(self, db):
        db.execute("DELETE FROM check_in_balances")
        db.execute("DELETE FROM check_ins")
        db.commit()
        result = get_latest_check_in(db)
        assert result is None


class TestGetCheckInHistory:
    def test_returns_all_in_order(self, db):
        add_check_in(db, date="2026-03-01", check_in_number="CI-002")
        history = get_check_in_history(db)
        assert len(history) == 2
        dates = [h["date"] for h in history]
        assert dates == sorted(dates)

    def test_each_entry_has_balances(self, db):
        history = get_check_in_history(db)
        for entry in history:
            assert "balances" in entry
            assert isinstance(entry["balances"], dict)


class TestReconcileBalances:
    def test_flags_drift(self, db):
        # Computed Checking = 3200 + 5000 - (87.42 + 17.99 + 112.35 + 500) = 7482.24
        # Provide an actual that differs by more than $1
        discrepancies = reconcile_balances(db, {"Checking": 7400.00})
        assert len(discrepancies) == 1
        assert discrepancies[0]["account"] == "Checking"
        assert abs(discrepancies[0]["difference"]) > 1.0

    def test_no_flags_when_within_threshold(self, db):
        computed = account_balance(db, "Checking")
        # Within $0.50 — below default threshold of $1
        discrepancies = reconcile_balances(db, {"Checking": computed + 0.50})
        assert len(discrepancies) == 0

    def test_sorted_by_largest_drift(self, db):
        # Credit Card debt: starting 1450 + outflows(55) - inflows(0) = 1505
        # Checking: 3200 + 5000 - 717.76 = 7482.24
        discrepancies = reconcile_balances(db, {
            "Checking": 7400.00,      # drift ~82.24
            "Credit Card": 1600.00,  # drift ~95.00
        })
        assert len(discrepancies) == 2
        # Largest drift first
        assert abs(discrepancies[0]["difference"]) >= abs(discrepancies[1]["difference"])

    def test_skips_external_accounts(self, db):
        discrepancies = reconcile_balances(db, {"External": 1000.00})
        assert len(discrepancies) == 0

    def test_skips_unknown_accounts(self, db):
        discrepancies = reconcile_balances(db, {"Unknown Account": 1000.00})
        assert len(discrepancies) == 0

    def test_custom_threshold(self, db):
        computed = account_balance(db, "Checking")
        # $5 drift — above $1 threshold but below $10
        discrepancies = reconcile_balances(db, {"Checking": computed + 5.0}, threshold=10.0)
        assert len(discrepancies) == 0

        discrepancies = reconcile_balances(db, {"Checking": computed + 5.0}, threshold=1.0)
        assert len(discrepancies) == 1


class TestReconciliationAdjustment:
    def test_positive_adjustment_adds_inflow(self, db):
        before = account_balance(db, "Checking")
        add_reconciliation_adjustment(
            db, account_name="Checking", amount=50.00,
            date="2026-02-28", notes="Bank fee refund",
        )
        after = account_balance(db, "Checking")
        assert round(after - before, 2) == 50.00

    def test_negative_adjustment_adds_outflow(self, db):
        before = account_balance(db, "Checking")
        add_reconciliation_adjustment(
            db, account_name="Checking", amount=-25.00,
            date="2026-02-28", notes="Unlogged ATM fee",
        )
        after = account_balance(db, "Checking")
        assert round(before - after, 2) == 25.00

    def test_returns_transaction_id(self, db):
        tx_id = add_reconciliation_adjustment(
            db, account_name="Checking", amount=10.00, date="2026-02-28",
        )
        assert isinstance(tx_id, int)
        assert tx_id > 0
