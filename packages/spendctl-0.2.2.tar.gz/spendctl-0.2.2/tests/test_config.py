"""Tests for spendctl.config module."""

from __future__ import annotations

import json

import pytest

import spendctl.config as cfg_module
from spendctl.config import (
    get_accounts,
    get_categories,
    get_debt_accounts,
    get_default_from_account,
    get_default_to_account,
    get_income_sources,
    get_min_payments,
    get_non_balance_accounts,
    get_student_loan_accounts,
    get_targets,
    load_config,
    reload_config,
    save_config,
)

# ── Fixtures ─────────────────────────────────────────────────────────────────


SAMPLE_CONFIG = {
    "accounts": [
        {"name": "Checking", "type": "checking", "institution": "Ally"},
        {"name": "Savings", "type": "savings", "institution": "Ally"},
        {"name": "Visa", "type": "credit_card", "apr": 24.99},
        {"name": "Car Loan", "type": "loan", "apr": 5.9},
        {"name": "Student Loan", "type": "student_loan", "apr": 4.5},
        {"name": "External", "type": "external"},
    ],
    "categories": [
        {"name": "Groceries", "group": "living_expense", "budget": 400},
        {"name": "Paycheck", "group": "income", "budget": 0},
    ],
    "income_sources": [
        {"name": "Primary Income", "amount": 5000.0},
    ],
    "targets": {
        "target_date": "2027-01-01",
        "target_label": "Debt free",
        "emergency_fund_target": 10000.0,
    },
    "min_payments": {
        "Visa": 25.0,
        "Car Loan": 300.0,
    },
    "loans": [],
}


@pytest.fixture(autouse=True)
def reset_cache():
    """Reset the config cache and CONFIG_PATH before each test."""
    cfg_module._config_cache = None
    yield
    cfg_module._config_cache = None


@pytest.fixture()
def config_file(tmp_path, monkeypatch):
    """Write sample config to a temp file and patch CONFIG_PATH."""
    cfg_path = tmp_path / "config.json"
    cfg_path.write_text(json.dumps(SAMPLE_CONFIG))
    monkeypatch.setattr(cfg_module, "CONFIG_PATH", cfg_path)
    return cfg_path


@pytest.fixture()
def missing_config(tmp_path, monkeypatch):
    """Patch CONFIG_PATH to a non-existent file."""
    cfg_path = tmp_path / "config.json"
    monkeypatch.setattr(cfg_module, "CONFIG_PATH", cfg_path)
    return cfg_path


# ── config_exists ─────────────────────────────────────────────────────────────


def test_config_exists_returns_false_when_missing(missing_config):
    assert cfg_module.config_exists() is False


def test_config_exists_returns_true_when_present(config_file):
    assert cfg_module.config_exists() is True


# ── load_config ───────────────────────────────────────────────────────────────


def test_load_config_raises_on_missing(missing_config):
    with pytest.raises(FileNotFoundError, match="spendctl init"):
        load_config()


def test_load_config_reads_valid_json(config_file):
    result = load_config()
    assert result["targets"]["target_label"] == "Debt free"
    assert len(result["accounts"]) == 6


def test_load_config_caching(config_file):
    first = load_config()
    # Corrupt the file — cache should still return original
    config_file.write_text("{}")
    second = load_config()
    assert first is second


# ── reload_config ─────────────────────────────────────────────────────────────


def test_reload_config_clears_cache(config_file):
    first = load_config()
    # Overwrite with modified config
    modified = dict(SAMPLE_CONFIG)
    modified["targets"] = {"target_label": "Updated"}
    config_file.write_text(json.dumps(modified))
    second = reload_config()
    assert second["targets"]["target_label"] == "Updated"
    assert first is not second


# ── save_config ───────────────────────────────────────────────────────────────


def test_save_config_creates_file(tmp_path, monkeypatch):
    cfg_path = tmp_path / "nested" / "config.json"
    monkeypatch.setattr(cfg_module, "CONFIG_PATH", cfg_path)
    # Also patch CONFIG_DIR so mkdir works
    monkeypatch.setattr(cfg_module, "CONFIG_DIR", cfg_path.parent)

    save_config({"test": True})
    assert cfg_path.is_file()
    data = json.loads(cfg_path.read_text())
    assert data == {"test": True}


# ── get_accounts ──────────────────────────────────────────────────────────────


def test_get_accounts_returns_dict_keyed_by_name(config_file):
    accounts = get_accounts()
    assert "Checking" in accounts
    assert accounts["Checking"]["type"] == "checking"
    assert accounts["Checking"]["institution"] == "Ally"
    assert "Visa" in accounts
    assert accounts["Visa"]["apr"] == 24.99


# ── get_debt_accounts ─────────────────────────────────────────────────────────


def test_get_debt_accounts_derives_from_types(config_file):
    debt = get_debt_accounts()
    assert "Visa" in debt
    assert "Car Loan" in debt
    assert "Checking" not in debt
    assert "Student Loan" not in debt  # student_loan is a separate type


# ── get_student_loan_accounts ─────────────────────────────────────────────────


def test_get_student_loan_accounts_derives_from_types(config_file):
    sl = get_student_loan_accounts()
    assert "Student Loan" in sl
    assert "Visa" not in sl


# ── get_non_balance_accounts ──────────────────────────────────────────────────


def test_get_non_balance_accounts(config_file):
    non_bal = get_non_balance_accounts()
    assert "External" in non_bal
    assert "Checking" not in non_bal


# ── get_default_from_account ──────────────────────────────────────────────────


def test_get_default_from_account_picks_first_checking(config_file):
    result = get_default_from_account()
    assert result == "Checking"


def test_get_default_from_account_falls_back_when_no_checking(tmp_path, monkeypatch):
    cfg_path = tmp_path / "config.json"
    cfg_path.write_text(json.dumps({
        "accounts": [
            {"name": "MySavings", "type": "savings"},
            {"name": "External", "type": "external"},
        ]
    }))
    monkeypatch.setattr(cfg_module, "CONFIG_PATH", cfg_path)
    result = get_default_from_account()
    assert result == "MySavings"


# ── get_default_to_account ────────────────────────────────────────────────────


def test_get_default_to_account_picks_external(config_file):
    result = get_default_to_account()
    assert result == "External"


def test_get_default_to_account_fallback_when_no_external(tmp_path, monkeypatch):
    cfg_path = tmp_path / "config.json"
    cfg_path.write_text(json.dumps({
        "accounts": [
            {"name": "Checking", "type": "checking"},
        ]
    }))
    monkeypatch.setattr(cfg_module, "CONFIG_PATH", cfg_path)
    result = get_default_to_account()
    assert result == "External"


# ── get_categories ────────────────────────────────────────────────────────────


def test_get_categories(config_file):
    cats = get_categories()
    assert "Groceries" in cats
    assert cats["Groceries"]["group"] == "living_expense"
    assert cats["Groceries"]["budget"] == 400


# ── get_income_sources ────────────────────────────────────────────────────────


def test_get_income_sources(config_file):
    sources = get_income_sources()
    assert "Primary Income" in sources
    assert sources["Primary Income"] == 5000.0


# ── get_targets ───────────────────────────────────────────────────────────────


def test_get_targets(config_file):
    targets = get_targets()
    assert targets["target_date"] == "2027-01-01"
    assert targets["emergency_fund_target"] == 10000.0


def test_get_targets_returns_empty_dict_when_missing(tmp_path, monkeypatch):
    cfg_path = tmp_path / "config.json"
    cfg_path.write_text(json.dumps({"accounts": []}))
    monkeypatch.setattr(cfg_module, "CONFIG_PATH", cfg_path)
    assert get_targets() == {}


# ── get_min_payments ──────────────────────────────────────────────────────────


def test_get_min_payments(config_file):
    mp = get_min_payments()
    assert mp["Visa"] == 25.0
    assert mp["Car Loan"] == 300.0
