"""Tests for spendctl.queries.transactions."""

from __future__ import annotations

from spendctl.queries.transactions import (
    add_transaction,
    delete_transaction,
    find_duplicates,
    list_transactions,
    search_transactions,
    update_transaction,
)


class TestAddTransaction:
    def test_returns_int_id(self, db):
        tid = add_transaction(
            db,
            date="2026-02-25",
            description="Test purchase",
            amount_usd=19.99,
            type="Expense",
            from_account="Checking",
            to_account="External",
            category="Groceries",
        )
        assert isinstance(tid, int)
        assert tid > 0

    def test_no_eur_amount_parameter(self, db):
        """add_transaction should not accept eur_amount (removed in spendctl)."""
        import inspect
        sig = inspect.signature(add_transaction)
        assert "eur_amount" not in sig.parameters


class TestListTransactions:
    def test_no_filters_returns_all(self, db):
        rows = list_transactions(db)
        # conftest seeds 6 transactions
        assert len(rows) == 6

    def test_account_filter(self, db):
        rows = list_transactions(db, account="Credit Card")
        assert len(rows) == 1
        assert rows[0]["from_account"] == "Credit Card"

    def test_category_filter(self, db):
        rows = list_transactions(db, category="Groceries")
        assert len(rows) == 2
        for r in rows:
            assert r["category"] == "Groceries"

    def test_date_range_filter(self, db):
        rows = list_transactions(db, start_date="2026-02-10", end_date="2026-02-15")
        assert len(rows) == 2
        dates = {r["date"] for r in rows}
        assert dates == {"2026-02-10", "2026-02-15"}

    def test_type_filter(self, db):
        rows = list_transactions(db, type="Income")
        assert len(rows) == 1
        assert rows[0]["type"] == "Income"

    def test_description_filter(self, db):
        rows = list_transactions(db, description="Grocery")
        assert len(rows) == 2

    def test_limit(self, db):
        rows = list_transactions(db, limit=2)
        assert len(rows) == 2

    def test_ordered_by_date(self, db):
        rows = list_transactions(db)
        dates = [r["date"] for r in rows]
        assert dates == sorted(dates)


class TestSearchTransactions:
    def test_description_match(self, db):
        rows = search_transactions(db, description="Grocery")
        assert len(rows) == 2
        for r in rows:
            assert "Grocery" in r["description"]

    def test_amount_match_within_penny(self, db):
        rows = search_transactions(db, amount=55.00)
        assert len(rows) == 1
        assert abs(rows[0]["amount_usd"] - 55.00) <= 0.01

    def test_date_match(self, db):
        rows = search_transactions(db, date="2026-02-15")
        assert len(rows) == 1
        assert rows[0]["date"] == "2026-02-15"

    def test_account_match(self, db):
        rows = search_transactions(db, account="Credit Card")
        assert len(rows) == 1


class TestUpdateTransaction:
    def test_changes_field(self, db):
        rows = list_transactions(db)
        tid = rows[0]["id"]

        update_transaction(db, tid, description="Updated description")

        updated = search_transactions(db, description="Updated description")
        assert len(updated) == 1
        assert updated[0]["description"] == "Updated description"

    def test_updates_updated_at(self, db):
        rows = list_transactions(db)
        tid = rows[0]["id"]
        original_updated_at = rows[0]["updated_at"]

        import time
        time.sleep(0.01)
        update_transaction(db, tid, amount_usd=99.99)

        updated = search_transactions(db, amount=99.99)
        assert len(updated) == 1
        assert updated[0]["updated_at"] >= original_updated_at

    def test_noop_when_no_fields(self, db):
        rows_before = list_transactions(db)
        tid = rows_before[0]["id"]
        update_transaction(db, tid)  # no-op
        rows_after = list_transactions(db)
        assert len(rows_after) == len(rows_before)


class TestDeleteTransaction:
    def test_removes_record(self, db):
        rows_before = list_transactions(db)
        tid = rows_before[0]["id"]

        delete_transaction(db, tid)

        rows_after = list_transactions(db)
        assert len(rows_after) == len(rows_before) - 1
        assert all(r["id"] != tid for r in rows_after)


class TestFindDuplicates:
    def test_detects_same_date_amount_account(self, db):
        # Insert a duplicate of the first grocery transaction
        add_transaction(
            db,
            date="2026-02-03",
            description="Duplicate grocery",
            amount_usd=87.42,
            type="Expense",
            from_account="Checking",
            to_account="External",
            category="Groceries",
        )

        dupes = find_duplicates(db)
        assert len(dupes) >= 1

        match = [d for d in dupes if d["amount_usd"] == 87.42 and d["date"] == "2026-02-03"]
        assert len(match) == 1
        assert match[0]["count"] == 2

    def test_no_duplicates_initially(self, db):
        dupes = find_duplicates(db)
        assert len(dupes) == 0
