"""Tests for spendctl.queries.dashboard."""

from __future__ import annotations

from spendctl.queries.dashboard import account_balance, all_balances, debt_progress, net_worth


class TestAccountBalance:
    def test_checking_computes_correctly(self, db):
        # starting_balance = 3200.00
        # Inflows (to_account=Checking): 5000.00 (salary on 02-15)
        # Outflows (from_account=Checking): 87.42 + 17.99 + 112.35 + 500.00 = 717.76
        # Expected = 3200 + 5000 - 717.76 = 7482.24
        balance = account_balance(db, "Checking")
        assert balance == 7482.24

    def test_credit_card_debt_account(self, db):
        # Debt account: starting_balance + outflows - inflows
        # starting_balance = 1450.00
        # outflows (from Credit Card): 55.00 (gas on 02-05)
        # inflows (to Credit Card): 0
        # Expected = 1450 + 55 - 0 = 1505.00
        balance = account_balance(db, "Credit Card")
        assert balance == 1505.0

    def test_personal_loan_debt_direction(self, db):
        # Loan account: starting_balance + outflows - inflows
        # starting_balance = 8500.00
        # outflows (from Personal Loan): 0
        # inflows (to Personal Loan): 500.00 (payment on 02-25)
        # Expected = 8500 + 0 - 500 = 8000.00
        balance = account_balance(db, "Personal Loan")
        assert balance == 8000.0

    def test_student_loans_debt_direction(self, db):
        # Student loan: starting_balance = 22000, no transactions
        # Expected = 22000 + 0 - 0 = 22000.00
        balance = account_balance(db, "Student Loans")
        assert balance == 22000.0

    def test_savings_asset_account(self, db):
        # starting_balance = 5000, no transactions
        balance = account_balance(db, "Savings")
        assert balance == 5000.0

    def test_external_returns_zero(self, db):
        balance = account_balance(db, "External")
        assert balance == 0.0

    def test_unknown_account_returns_zero(self, db):
        # Account not in non-balance list, not found in DB: starting defaults to 0
        balance = account_balance(db, "Nonexistent")
        assert balance == 0.0


class TestAllBalances:
    def test_returns_dict_with_trackable_accounts(self, db):
        balances = all_balances(db)
        assert isinstance(balances, dict)
        # Should have entries for all non-external accounts
        assert "Checking" in balances
        assert "Savings" in balances
        assert "Credit Card" in balances
        assert "Personal Loan" in balances
        assert "Student Loans" in balances

    def test_excludes_external_accounts(self, db):
        balances = all_balances(db)
        assert "External" not in balances

    def test_values_are_floats(self, db):
        balances = all_balances(db)
        for name, bal in balances.items():
            assert isinstance(bal, float), f"{name} balance is not float: {bal!r}"


class TestNetWorth:
    def test_returns_expected_keys(self, db):
        result = net_worth(db)
        expected_keys = {"liquid_assets", "investments", "total_debt", "net_worth", "emergency_fund"}
        assert set(result.keys()) == expected_keys

    def test_net_worth_formula(self, db):
        result = net_worth(db)
        computed = result["liquid_assets"] + result["investments"] - result["total_debt"]
        assert abs(result["net_worth"] - computed) < 0.01

    def test_liquid_assets_includes_checking_and_savings(self, db):
        balances = all_balances(db)
        result = net_worth(db, balances=balances)
        # Checking = 7482.24, Savings = 5000.00
        assert result["liquid_assets"] == round(balances.get("Checking", 0) + balances.get("Savings", 0), 2)

    def test_total_debt_includes_student_loans(self, db):
        result = net_worth(db)
        # Student Loans should be included in total_debt
        assert result["total_debt"] > 0

    def test_investments_includes_brokerage_and_retirement(self, db):
        result = net_worth(db)
        # Brokerage = 2800, Retirement = 45000
        assert result["investments"] >= 2800.0 + 45000.0

    def test_accepts_precomputed_balances(self, db):
        balances = all_balances(db)
        result1 = net_worth(db)
        result2 = net_worth(db, balances=balances)
        assert result1 == result2


class TestDebtProgress:
    def test_returns_per_account_keys(self, db):
        result = debt_progress(db)
        assert "Credit Card" in result
        assert "Personal Loan" in result
        assert "Student Loans" in result

    def test_per_account_structure(self, db):
        result = debt_progress(db)
        for acct_name in ["Credit Card", "Personal Loan", "Student Loans"]:
            if acct_name in result:
                entry = result[acct_name]
                assert "starting_balance" in entry
                assert "current_balance" in entry
                assert "amount_paid" in entry
                assert "progress_pct" in entry

    def test_excludes_asset_accounts(self, db):
        result = debt_progress(db)
        assert "Checking" not in result
        assert "Savings" not in result
        assert "Brokerage" not in result

    def test_personal_loan_progress(self, db):
        result = debt_progress(db)
        pl = result["Personal Loan"]
        # starting = 8500, current = 8000, paid = 500
        assert pl["starting_balance"] == 8500.0
        assert pl["current_balance"] == 8000.0
        assert pl["amount_paid"] == 500.0
        assert pl["progress_pct"] == round(500 / 8500 * 100, 1)

    def test_no_debt_plan_table(self, db):
        """debt_progress should not reference a debt_plan table (removed in spendctl)."""
        result = debt_progress(db)
        # No _plan_latest key should be present
        assert "_plan_latest" not in result
