"""Tests for spendctl.queries.subscriptions."""

from __future__ import annotations

from spendctl.queries.subscriptions import (
    active_monthly_total,
    add_subscription,
    cancel_subscription,
    list_subscriptions,
    update_subscription,
)


class TestListSubscriptions:
    def test_returns_all(self, db):
        rows = list_subscriptions(db)
        # conftest seeds 2 subscriptions (Streaming active, Old Service canceled)
        assert len(rows) == 2

    def test_status_filter_active(self, db):
        rows = list_subscriptions(db, status="Active")
        assert len(rows) == 1
        assert rows[0]["name"] == "Streaming"

    def test_status_filter_canceled(self, db):
        rows = list_subscriptions(db, status="Canceled")
        assert len(rows) == 1
        assert rows[0]["name"] == "Old Service"

    def test_ordered_by_status_then_name(self, db):
        add_subscription(db, name="Aardvark", amount=5.99, account="Checking")
        rows = list_subscriptions(db)
        # Active first, then Canceled
        statuses = [r["status"] for r in rows]
        active_positions = [i for i, s in enumerate(statuses) if s == "Active"]
        canceled_positions = [i for i, s in enumerate(statuses) if s == "Canceled"]
        if active_positions and canceled_positions:
            assert max(active_positions) < min(canceled_positions)


class TestAddSubscription:
    def test_returns_id(self, db):
        sid = add_subscription(
            db,
            name="Music",
            amount=10.99,
            account="Checking",
            category="Subscription",
        )
        assert isinstance(sid, int)
        assert sid > 0

    def test_new_sub_is_active(self, db):
        add_subscription(db, name="Music", amount=10.99, account="Checking")
        rows = list_subscriptions(db, status="Active")
        names = {r["name"] for r in rows}
        assert "Music" in names

    def test_defaults_to_monthly_frequency(self, db):
        add_subscription(db, name="Music", amount=10.99, account="Checking")
        rows = list_subscriptions(db, status="Active")
        music = [r for r in rows if r["name"] == "Music"][0]
        assert music["frequency"] == "Monthly"

    def test_billing_day_stored(self, db):
        add_subscription(db, name="Music", amount=10.99, account="Checking", billing_day=15)
        rows = list_subscriptions(db, status="Active")
        music = [r for r in rows if r["name"] == "Music"][0]
        assert music["billing_day"] == 15


class TestCancelSubscription:
    def test_sets_status_and_date(self, db):
        active = list_subscriptions(db, status="Active")
        sid = active[0]["id"]

        cancel_subscription(db, sid, canceled_date="2026-02-28")

        all_subs = list_subscriptions(db)
        canceled = [s for s in all_subs if s["id"] == sid][0]
        assert canceled["status"] == "Canceled"
        assert canceled["canceled_date"] == "2026-02-28"

    def test_defaults_to_today_when_no_date(self, db):
        import re
        active = list_subscriptions(db, status="Active")
        sid = active[0]["id"]

        cancel_subscription(db, sid)

        all_subs = list_subscriptions(db)
        canceled = [s for s in all_subs if s["id"] == sid][0]
        assert canceled["status"] == "Canceled"
        assert re.match(r"\d{4}-\d{2}-\d{2}", canceled["canceled_date"])


class TestUpdateSubscription:
    def test_updates_amount(self, db):
        active = list_subscriptions(db, status="Active")
        sid = active[0]["id"]
        original_amount = active[0]["amount"]

        update_subscription(db, sid, amount=25.99)

        rows = list_subscriptions(db)
        updated = [r for r in rows if r["id"] == sid][0]
        assert updated["amount"] == 25.99
        assert updated["amount"] != original_amount

    def test_noop_when_no_fields(self, db):
        rows_before = list_subscriptions(db)
        sid = rows_before[0]["id"]
        update_subscription(db, sid)  # no-op
        rows_after = list_subscriptions(db)
        assert len(rows_after) == len(rows_before)


class TestActiveMonthlyTotal:
    def test_sums_correctly(self, db):
        total = active_monthly_total(db)
        # Only Streaming at 17.99 is Active+Monthly
        assert total == 17.99

    def test_after_adding_subscription(self, db):
        add_subscription(db, name="Music", amount=10.99, account="Checking")
        total = active_monthly_total(db)
        assert total == round(17.99 + 10.99, 2)

    def test_canceled_not_included(self, db):
        total = active_monthly_total(db)
        # Old Service is Canceled, should not be included
        assert total == 17.99

    def test_zero_when_none_active(self, db):
        # Cancel all active subscriptions
        active = list_subscriptions(db, status="Active")
        for sub in active:
            cancel_subscription(db, sub["id"], canceled_date="2026-01-01")

        total = active_monthly_total(db)
        assert total == 0.0
