"""Shared fixtures for spendctl test suite."""

from __future__ import annotations

import json
import sqlite3

import pytest


@pytest.fixture()
def mock_config(monkeypatch, tmp_path):
    """Provide test config that doesn't touch the real filesystem."""
    test_config = {
        "accounts": [
            {"name": "Checking", "type": "checking", "institution": "Test Bank", "apr": None, "description": "Primary"},
            {"name": "Savings", "type": "savings", "institution": "Test Bank", "apr": 4.5, "description": "Savings"},
            {"name": "Credit Card", "type": "credit_card", "institution": "Test Bank", "apr": 22.99, "description": "CC"},
            {"name": "Personal Loan", "type": "loan", "institution": "Test Bank", "apr": 12.0, "description": "Loan"},
            {"name": "Student Loans", "type": "student_loan", "institution": "Test Lender", "apr": 5.5, "description": "Student"},
            {"name": "Brokerage", "type": "investment", "institution": "Test Broker", "apr": None, "description": "Investments"},
            {"name": "Retirement", "type": "investment", "institution": "Test Broker", "apr": None, "description": "401k"},
            {"name": "External", "type": "external", "institution": None, "apr": None, "description": "External"},
        ],
        "categories": [
            {"name": "Groceries", "group": "living_expense", "budget": 500.0},
            {"name": "Gas", "group": "living_expense", "budget": 200.0},
            {"name": "Subscription", "group": "living_expense", "budget": 50.0},
            {"name": "Debt Payment", "group": "debt", "budget": 1000.0},
            {"name": "Paycheck", "group": "income", "budget": 0},
            {"name": "Reconciliation", "group": "reconciliation", "budget": 0},
            {"name": "Transfer", "group": "savings", "budget": 0},
            {"name": "Emergency Fund", "group": "savings", "budget": 200.0},
            {"name": "Interest Charged", "group": "debt", "budget": 0},
            {"name": "Interest Earned", "group": "income", "budget": 0},
        ],
        "income_sources": [{"name": "Salary", "amount": 5000.0}],
        "targets": {"target_date": "2027-06-01", "target_label": "Debt Free", "emergency_fund_target": 18000.0},
        "min_payments": {"Credit Card": 25.0, "Personal Loan": 200.0},
        "loans": [],
    }

    config_path = tmp_path / "config.json"
    config_path.write_text(json.dumps(test_config))

    import spendctl.config as cfg
    monkeypatch.setattr(cfg, "CONFIG_PATH", config_path)
    monkeypatch.setattr(cfg, "CONFIG_DIR", tmp_path)
    monkeypatch.setattr(cfg, "_config_cache", None)

    return test_config


@pytest.fixture()
def db(mock_config):
    """In-memory SQLite database with schema and sample data."""
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")

    from spendctl.db import init_db
    init_db(conn)

    # Sample transactions (generic)
    txns = [
        ("2026-02-03", "Grocery store", 87.42, "Expense", "Checking", "External", "Groceries"),
        ("2026-02-05", "Gas station", 55.00, "Expense", "Credit Card", "External", "Gas"),
        ("2026-02-10", "Streaming service", 17.99, "Expense", "Checking", "External", "Subscription"),
        ("2026-02-15", "Monthly salary", 5000.00, "Income", "External", "Checking", "Paycheck"),
        ("2026-02-20", "Grocery store", 112.35, "Expense", "Checking", "External", "Groceries"),
        ("2026-02-25", "Loan payment", 500.00, "Debt Payment", "Checking", "Personal Loan", "Debt Payment"),
    ]
    for d, desc, amt, typ, frm, to, cat in txns:
        conn.execute(
            "INSERT INTO transactions (date, description, amount_usd, type, from_account, to_account, category) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (d, desc, amt, typ, frm, to, cat),
        )

    # Sample check-in (normalized)
    conn.execute("INSERT INTO check_ins (date, check_in_number) VALUES ('2026-02-01', 'CI-001')")
    ci_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    check_in_balances = {
        "Checking": 3200.00,
        "Savings": 5000.00,
        "Credit Card": 1450.00,
        "Personal Loan": 8500.00,
        "Student Loans": 22000.00,
        "Brokerage": 2800.00,
        "Retirement": 45000.00,
    }
    for acct, bal in check_in_balances.items():
        conn.execute(
            "INSERT INTO check_in_balances (check_in_id, account_name, balance) VALUES (?, ?, ?)",
            (ci_id, acct, bal),
        )

    # Starting balances
    for acct, bal in check_in_balances.items():
        conn.execute("UPDATE accounts SET starting_balance = ? WHERE name = ?", (bal, acct))

    # Subscriptions
    conn.execute(
        "INSERT INTO subscriptions (name, amount, account, category, frequency, status, billing_day) VALUES ('Streaming', 17.99, 'Checking', 'Subscription', 'Monthly', 'Active', 10)"
    )
    conn.execute(
        "INSERT INTO subscriptions (name, amount, account, category, frequency, status, canceled_date) VALUES ('Old Service', 15.99, 'Checking', 'Subscription', 'Monthly', 'Canceled', '2026-01-15')"
    )

    conn.commit()
    yield conn
    conn.close()
