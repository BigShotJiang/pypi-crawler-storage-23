"""Tests for spendctl.queries.reports."""

from __future__ import annotations

from spendctl.queries.reports import (
    cash_flow,
    monthly_summary,
    spending_by_account,
    spending_by_category,
    yearly_summary,
)


class TestMonthlySummary:
    def test_returns_expected_keys(self, db):
        result = monthly_summary(db, month="2026-02")
        expected_keys = {
            "month", "income", "expenses_by_category", "debt_payments",
            "total_expenses", "cushion", "subscription_total",
        }
        assert set(result.keys()) == expected_keys

    def test_month_matches_input(self, db):
        result = monthly_summary(db, month="2026-02")
        assert result["month"] == "2026-02"

    def test_income_matches_seed(self, db):
        result = monthly_summary(db, month="2026-02")
        assert result["income"] == 5000.00

    def test_total_expenses_matches_seed(self, db):
        result = monthly_summary(db, month="2026-02")
        # 87.42 + 55.00 + 17.99 + 112.35 = 272.76
        assert result["total_expenses"] == 272.76

    def test_debt_payments_matches_seed(self, db):
        result = monthly_summary(db, month="2026-02")
        assert result["debt_payments"] == 500.0

    def test_expenses_by_category_is_list(self, db):
        result = monthly_summary(db, month="2026-02")
        assert isinstance(result["expenses_by_category"], list)
        for entry in result["expenses_by_category"]:
            assert "category" in entry
            assert "total" in entry
            assert "count" in entry

    def test_subscription_total_includes_active(self, db):
        result = monthly_summary(db, month="2026-02")
        # Active Streaming = 17.99
        assert result["subscription_total"] >= 17.99

    def test_cushion_formula(self, db):
        result = monthly_summary(db, month="2026-02")
        computed = result["income"] - result["total_expenses"] - result["debt_payments"]
        assert abs(result["cushion"] - computed) < 0.01


class TestCashFlow:
    def test_returns_expected_keys(self, db):
        result = cash_flow(db, "2026-02-01", "2026-02-28")
        expected_keys = {
            "start_date", "end_date", "money_in", "expenses",
            "debt_payments", "interest", "transfers", "net",
        }
        assert set(result.keys()) == expected_keys

    def test_money_in_matches_seed(self, db):
        result = cash_flow(db, "2026-02-01", "2026-02-28")
        assert result["money_in"] == 5000.00

    def test_expenses_match_seed(self, db):
        result = cash_flow(db, "2026-02-01", "2026-02-28")
        assert result["expenses"] == 272.76

    def test_debt_payments_match_seed(self, db):
        result = cash_flow(db, "2026-02-01", "2026-02-28")
        assert result["debt_payments"] == 500.0

    def test_empty_range_returns_zeros(self, db):
        result = cash_flow(db, "2025-01-01", "2025-01-31")
        assert result["money_in"] == 0.0
        assert result["expenses"] == 0.0

    def test_net_formula(self, db):
        result = cash_flow(db, "2026-02-01", "2026-02-28")
        computed = result["money_in"] - result["expenses"] - result["debt_payments"] - result["interest"]
        assert abs(result["net"] - computed) < 0.01


class TestSpendingByCategory:
    def test_returns_list_sorted_by_total(self, db):
        rows = spending_by_category(db)
        assert isinstance(rows, list)
        totals = [r["total"] for r in rows]
        assert totals == sorted(totals, reverse=True)

    def test_includes_expected_keys(self, db):
        rows = spending_by_category(db)
        for row in rows:
            assert "category" in row
            assert "total" in row
            assert "count" in row
            assert "pct" in row

    def test_percentages_sum_to_100(self, db):
        rows = spending_by_category(db)
        total_pct = sum(r["pct"] for r in rows)
        assert abs(total_pct - 100.0) < 0.1

    def test_date_range_filter(self, db):
        rows = spending_by_category(db, start_date="2026-02-01", end_date="2026-02-10")
        # Range 02-01 to 02-10 covers: Grocery (02-03), Gas (02-05), Subscription (02-10)
        totals = {r["category"]: r["total"] for r in rows}
        assert "Groceries" in totals
        assert "Gas" in totals
        assert "Subscription" in totals
        # Grocery on 02-20 is outside range
        assert totals["Groceries"] == 87.42

    def test_only_expense_type(self, db):
        rows = spending_by_category(db)
        # Should not include Income or Debt Payment categories
        categories = {r["category"] for r in rows}
        assert "Paycheck" not in categories
        assert "Debt Payment" not in categories


class TestSpendingByAccount:
    def test_returns_list(self, db):
        rows = spending_by_account(db)
        assert isinstance(rows, list)

    def test_includes_expected_keys(self, db):
        rows = spending_by_account(db)
        for row in rows:
            assert "account" in row
            assert "total" in row
            assert "count" in row

    def test_checking_is_largest_spender(self, db):
        rows = spending_by_account(db)
        # Checking: 87.42 + 17.99 + 112.35 = 217.76
        # Credit Card: 55.00
        assert rows[0]["account"] == "Checking"

    def test_date_range_filter(self, db):
        rows = spending_by_account(db, start_date="2026-02-05", end_date="2026-02-05")
        # Only the gas station purchase on Credit Card
        assert len(rows) == 1
        assert rows[0]["account"] == "Credit Card"


class TestYearlySummary:
    def test_returns_list(self, db):
        rows = yearly_summary(db, year=2026)
        assert isinstance(rows, list)

    def test_returns_expected_keys(self, db):
        rows = yearly_summary(db, year=2026)
        month_names = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]
        for row in rows:
            assert "category" in row
            assert "ytd" in row
            for m in month_names:
                assert m in row

    def test_feb_groceries_matches_seed(self, db):
        rows = yearly_summary(db, year=2026)
        groceries = [r for r in rows if r["category"] == "Groceries"]
        assert len(groceries) == 1
        assert groceries[0]["feb"] == 199.77

    def test_empty_year_returns_empty_list(self, db):
        rows = yearly_summary(db, year=2020)
        assert rows == []
