"""Allow running with python -m spendctl."""

from spendctl.cli import main

main()
