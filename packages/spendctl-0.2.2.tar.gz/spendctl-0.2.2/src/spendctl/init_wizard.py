"""Interactive setup wizard for spendctl.

Guides the user through creating ~/.config/spendctl/config.json.
Run via `spendctl init`.
"""

from __future__ import annotations

import json
import re
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from spendctl.config import (
    ACCOUNT_TYPES,
    CONFIG_PATH,
    config_exists,
    load_config,
    reload_config,
    save_config,
)

# ── Default categories ──────────────────────────────────────────────────────

DEFAULT_CATEGORIES: list[dict] = [
    {"name": "Rent/Mortgage", "group": "living_expense", "budget": 0},
    {"name": "Utilities", "group": "living_expense", "budget": 0},
    {"name": "Groceries", "group": "living_expense", "budget": 0},
    {"name": "Gas", "group": "living_expense", "budget": 0},
    {"name": "Dining Out", "group": "living_expense", "budget": 0},
    {"name": "Entertainment", "group": "living_expense", "budget": 0},
    {"name": "Shopping", "group": "living_expense", "budget": 0},
    {"name": "Personal Care", "group": "living_expense", "budget": 0},
    {"name": "Phone/Internet", "group": "living_expense", "budget": 0},
    {"name": "Auto Insurance", "group": "living_expense", "budget": 0},
    {"name": "Education", "group": "living_expense", "budget": 0},
    {"name": "Subscription", "group": "living_expense", "budget": 0},
    {"name": "Medical", "group": "living_expense", "budget": 0},
    {"name": "Buffer", "group": "living_expense", "budget": 0},
    {"name": "Miscellaneous", "group": "living_expense", "budget": 0},
    {"name": "Debt Payment", "group": "debt", "budget": 0},
    {"name": "Extra Debt Payment", "group": "debt", "budget": 0},
    {"name": "Interest Charged", "group": "debt", "budget": 0},
    {"name": "Emergency Fund", "group": "savings", "budget": 0},
    {"name": "Transfer", "group": "savings", "budget": 0},
    {"name": "Paycheck", "group": "income", "budget": 0},
    {"name": "Interest Earned", "group": "income", "budget": 0},
    {"name": "Refund", "group": "income", "budget": 0},
    {"name": "Investment", "group": "income", "budget": 0},
    {"name": "Reconciliation", "group": "reconciliation", "budget": 0},
]


# ── Input helpers ───────────────────────────────────────────────────────────


def _prompt(label: str, default: str = "") -> str:
    """Prompt for a string value, showing default if provided."""
    suffix = f" [{default}]" if default else ""
    return input(f"  {label}{suffix}: ").strip() or default


def _prompt_float(label: str, default: float = 0.0) -> float:
    """Prompt for a non-negative float value."""
    while True:
        raw = _prompt(label, str(default))
        try:
            val = float(raw)
            if val < 0:
                print("    Value must be >= 0. Try again.")
                continue
            return val
        except ValueError:
            print("    Invalid number. Try again.")


def _prompt_date(label: str, default: str = "") -> str:
    """Prompt for a YYYY-MM-DD date. Empty string allowed (skips the field)."""
    while True:
        raw = _prompt(label, default)
        if not raw:
            return ""
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", raw):
            return raw
        print("    Date must be YYYY-MM-DD format. Try again.")


def _pick_account_type(default: str = "") -> str:
    """Display a numbered menu and return the chosen account type."""
    print("    Account types:")
    for i, t in enumerate(ACCOUNT_TYPES, 1):
        print(f"      {i}) {t}")
    while True:
        raw = _prompt("Type number", default)
        # Allow typing either the number or the name directly
        if raw in ACCOUNT_TYPES:
            return raw
        try:
            idx = int(raw) - 1
            if 0 <= idx < len(ACCOUNT_TYPES):
                return ACCOUNT_TYPES[idx]
        except ValueError:
            pass
        print("    Invalid choice. Enter a number or type name.")


# ── Wizard sections ─────────────────────────────────────────────────────────


def _collect_accounts(existing: list[dict] | None = None) -> list[dict]:
    """Prompt for account entries. Always ensures External is included."""
    print("\n--- ACCOUNTS ---")
    print("  Enter your accounts (checking, savings, credit cards, loans, etc.).")
    print("  Type 'done' when finished.\n")

    accounts: list[dict] = []
    existing_names: set[str] = set()

    if existing:
        print("  Current accounts:")
        for a in existing:
            print(f"    - {a['name']} ({a['type']})")
            existing_names.add(a["name"])
        print("  Add new accounts below, or type 'done' to keep as-is.\n")

    while True:
        name = _prompt("Account name ('done' to finish)")
        if name.lower() == "done" or not name:
            break
        if name in existing_names or any(a["name"] == name for a in accounts):
            print(f"    Account '{name}' already exists. Use a unique name.")
            continue

        acct_type = _pick_account_type()
        institution = _prompt("Institution (e.g. Chase, Ally)", "")
        description = _prompt("Description (optional)", "")

        apr: float | None = None
        if acct_type in ("credit_card", "loan", "student_loan"):
            raw_apr = _prompt("APR % (e.g. 24.99, press enter to skip)", "")
            if raw_apr:
                try:
                    apr = float(raw_apr)
                except ValueError:
                    print("    Invalid APR, skipping.")

        entry: dict[str, Any] = {"name": name, "type": acct_type}
        if institution:
            entry["institution"] = institution
        if description:
            entry["description"] = description
        if apr is not None:
            entry["apr"] = apr

        accounts.append(entry)
        print(f"    Added: {name} ({acct_type})\n")

    # Merge with existing
    if existing:
        accounts = existing + accounts

    # Always ensure External account exists
    if not any(a["name"] == "External" for a in accounts):
        accounts.append({"name": "External", "type": "external", "description": "Cash / outside system"})
        print("  (Auto-added 'External' account for cash and out-of-system transactions.)")

    return accounts


def _collect_income(existing: list[dict] | None = None) -> list[dict]:
    """Prompt for income sources."""
    print("\n--- INCOME SOURCES ---")
    print("  Enter your monthly income sources (paycheck, side income, etc.).")
    print("  Type 'done' when finished.\n")

    sources: list[dict] = []

    if existing:
        print("  Current income sources:")
        for s in existing:
            print(f"    - {s['name']}: ${s['amount']:,.2f}/mo")
        print("  Add new sources below, or type 'done' to keep as-is.\n")

    while True:
        name = _prompt("Income source name ('done' to finish)")
        if name.lower() == "done" or not name:
            break
        if any(s["name"] == name for s in (existing or []) + sources):
            print(f"    '{name}' already exists.")
            continue
        amount = _prompt_float("Monthly amount ($)")
        sources.append({"name": name, "amount": amount})
        print(f"    Added: {name} = ${amount:,.2f}/mo\n")

    return (existing or []) + sources


def _collect_categories(existing: list[dict] | None = None) -> list[dict]:
    """Present default categories and allow customization."""
    print("\n--- CATEGORIES ---")

    if existing:
        categories = existing[:]
    else:
        categories = [c.copy() for c in DEFAULT_CATEGORIES]

    print("  Current categories:")
    for i, c in enumerate(categories, 1):
        budget_str = f" (budget: ${c['budget']:,.0f}/mo)" if c["budget"] else ""
        print(f"    {i:2}. {c['name']} [{c['group']}]{budget_str}")

    print()
    print("  Options:")
    print("    b <N> <amount> — set budget for category number N")
    print("    a <name> <group> — add category (groups: living_expense/debt/savings/income/reconciliation)")
    print("    d <N> — delete category number N")
    print("    done — continue")
    print()

    while True:
        raw = input("  Command: ").strip()
        if not raw or raw.lower() == "done":
            break

        parts = raw.split(None, 2)
        cmd = parts[0].lower()

        if cmd == "b" and len(parts) >= 3:
            try:
                idx = int(parts[1]) - 1
                amount = float(parts[2])
                if 0 <= idx < len(categories) and amount >= 0:
                    categories[idx]["budget"] = amount
                    print(f"    Set budget for '{categories[idx]['name']}' to ${amount:,.0f}/mo")
                else:
                    print("    Invalid index or amount.")
            except (ValueError, IndexError):
                print("    Usage: b <N> <amount>")

        elif cmd == "a" and len(parts) >= 3:
            name = parts[1]
            group = parts[2]
            valid_groups = ("living_expense", "debt", "savings", "income", "reconciliation")
            if group not in valid_groups:
                print(f"    Invalid group. Choose from: {', '.join(valid_groups)}")
            elif any(c["name"] == name for c in categories):
                print(f"    '{name}' already exists.")
            else:
                categories.append({"name": name, "group": group, "budget": 0})
                print(f"    Added: {name} [{group}]")

        elif cmd == "d" and len(parts) >= 2:
            try:
                idx = int(parts[1]) - 1
                if 0 <= idx < len(categories):
                    removed = categories.pop(idx)
                    print(f"    Removed: {removed['name']}")
                else:
                    print("    Invalid index.")
            except (ValueError, IndexError):
                print("    Usage: d <N>")

        else:
            print("    Unknown command. Try: b <N> <amount>, a <name> <group>, d <N>, or done")

    return categories


def _collect_targets(existing: dict | None = None) -> dict:
    """Prompt for optional financial targets."""
    print("\n--- TARGETS (optional) ---")
    print("  Press enter to skip any field.\n")

    targets: dict = dict(existing or {})

    target_date = _prompt_date("Target date (YYYY-MM-DD)", targets.get("target_date", ""))
    target_label = _prompt("Target label (e.g. 'Debt free by')", targets.get("target_label", ""))
    ef_raw = _prompt("Emergency fund target ($)", str(targets.get("emergency_fund_target", "")) if targets.get("emergency_fund_target") else "")

    if target_date:
        targets["target_date"] = target_date
    if target_label:
        targets["target_label"] = target_label
    if ef_raw:
        try:
            targets["emergency_fund_target"] = float(ef_raw)
        except ValueError:
            print("  Invalid amount, skipping emergency fund target.")

    return targets


def _collect_min_payments(accounts: list[dict], existing: dict | None = None) -> dict:
    """Prompt for minimum monthly payment for each debt account."""
    print("\n--- MINIMUM PAYMENTS ---")

    debt_types = ("credit_card", "loan", "student_loan")
    debt_accounts = [a for a in accounts if a["type"] in debt_types]

    if not debt_accounts:
        print("  No debt accounts found. Skipping.")
        return {}

    print("  Enter minimum monthly payment for each debt account.\n")

    min_payments: dict = dict(existing or {})

    for acct in debt_accounts:
        name = acct["name"]
        current = min_payments.get(name, 0.0)
        amount = _prompt_float(f"Min payment for {name} ($)", current)
        min_payments[name] = amount

    return min_payments


def _collect_loans(accounts: list[dict], existing: list | None = None) -> list:
    """Prompt for detailed loan info for student loan accounts."""
    print("\n--- STUDENT LOAN DETAILS (optional) ---")

    sl_accounts = [a for a in accounts if a["type"] == "student_loan"]

    if not sl_accounts:
        print("  No student loan accounts. Skipping.")
        return []

    loans: list[dict] = list(existing or [])
    existing_names = {lg["name"] for lg in loans}

    print("  Enter loan group details for each student loan account.")
    print("  Press enter to skip any field.\n")

    for acct in sl_accounts:
        if acct["name"] in existing_names:
            print(f"  '{acct['name']}' already has loan details. Skipping.")
            continue

        print(f"  Loan group: {acct['name']}")
        loan_type = _prompt("  Loan type (e.g. Direct Subsidized, PLUS)", "")
        principal_raw = _prompt("  Principal balance ($)", "")
        rate_raw = _prompt("  Interest rate (%)", "")
        daily_raw = _prompt("  Daily accrual ($)", "")
        accrued_raw = _prompt("  Accrued interest ($)", "")

        group: dict[str, Any] = {"name": acct["name"]}
        if loan_type:
            group["type"] = loan_type
        if principal_raw:
            try:
                group["principal"] = float(principal_raw)
            except ValueError:
                pass
        if rate_raw:
            try:
                group["rate"] = float(rate_raw)
            except ValueError:
                pass
        if daily_raw:
            try:
                group["daily_accrual"] = float(daily_raw)
            except ValueError:
                pass
        if accrued_raw:
            try:
                group["accrued_interest"] = float(accrued_raw)
            except ValueError:
                pass

        loans.append(group)

    return loans


# ── AI context content ──────────────────────────────────────────────────────

_AI_CONTEXT = """\
## spendctl

Personal finance CLI. Every command supports `--json` for structured output.

**Config:** `~/.config/spendctl/config.json`
**Database:** `~/.config/spendctl/data/spendctl.db`

### Commands
| Command | Description |
|---------|-------------|
| `spendctl add DATE DESC AMOUNT --category CAT` | Add a transaction |
| `spendctl list [--start DATE] [--end DATE] [--category CAT] [--json]` | List transactions |
| `spendctl balance [ACCOUNT] [--json]` | Show account balances |
| `spendctl spending [--month YYYY-MM] [--json]` | Spending by category |
| `spendctl debt [--json]` | Debt paydown progress |
| `spendctl budget [--month YYYY-MM] [--json]` | Budget vs actual |
| `spendctl summary [--month YYYY-MM] [--json]` | Full monthly summary |
| `spendctl subscriptions [--json]` | Recurring charges |
| `spendctl ask "question"` | Ask your local AI about your finances |

### Examples
```
spendctl add 2024-03-15 "Grocery store" 87.42 --category Groceries
spendctl balance --json
spendctl summary --month 2024-03 --json
spendctl ask "Am I on track with my budget this month?"
```
"""


def _upsert_section(file_path: Path, header: str, content: str) -> None:
    """Insert or replace a section (identified by header) in a file."""
    file_path.parent.mkdir(parents=True, exist_ok=True)
    text = file_path.read_text() if file_path.exists() else ""

    # Check if section already exists and replace it
    if header in text:
        # Find the section start; replace everything from the header until the
        # next same-level heading (## ) or end of file
        lines = text.splitlines(keepends=True)
        start_idx = None
        end_idx = len(lines)
        for i, line in enumerate(lines):
            if line.strip() == header.strip():
                start_idx = i
            elif start_idx is not None and i > start_idx and line.startswith("## ") and line.strip() != header.strip():
                # Stop at the next top-level (##) heading that isn't our own
                end_idx = i
                break
        if start_idx is not None:
            section_text = header + "\n" + content.rstrip("\n") + "\n"
            new_lines = lines[:start_idx] + [section_text] + lines[end_idx:]
            file_path.write_text("".join(new_lines))
            return

    # Append to end with separator
    separator = "\n" if text and not text.endswith("\n\n") else ""
    section_text = header + "\n" + content.rstrip("\n") + "\n"
    file_path.write_text(text + separator + section_text)


def _collect_dashboard() -> bool:
    """Prompt for dashboard install and attempt pip install. Returns True if installed."""
    print("\n\u2500\u2500 Dashboard \u2500" + "\u2500" * 47)
    print()
    print("  spendctl includes an optional visual dashboard (Streamlit).")
    print()
    choice = input("  Install the dashboard? (y/n): ").strip().lower()
    if choice != "y":
        return False

    print()
    print("  Installing dashboard dependencies...")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "spendctl[dashboard]"],
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        print("  \u2713 Dashboard installed. Run: spendctl dashboard")
        return True
    else:
        print(f"  Error installing dashboard: {result.stderr.strip() or result.stdout.strip()}")
        print("  You can install manually later: pip install 'spendctl[dashboard]'")
        return False


def _try_ollama_connection(endpoint: str, timeout: int = 5) -> bool:
    """Return True if Ollama responds at the given endpoint."""
    url = endpoint.rstrip("/") + "/api/version"
    try:
        with urllib.request.urlopen(url, timeout=timeout):
            return True
    except (urllib.error.URLError, TimeoutError, OSError, ValueError):
        return False


def _list_ollama_models(endpoint: str) -> list[str]:
    """Return list of model names from /api/tags, or empty list on error."""
    url = endpoint.rstrip("/") + "/api/tags"
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            return [m["name"] for m in data.get("models", [])]
    except Exception:
        return []


def _test_ollama_model(endpoint: str, model: str) -> bool:
    """Send a trivial prompt to verify the model works. Returns True on success."""
    url = endpoint.rstrip("/") + "/api/generate"
    payload = json.dumps({"model": model, "prompt": "Say OK", "stream": False}).encode()
    req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode())
            return bool(result.get("response"))
    except Exception:
        return False


def _collect_ollama() -> dict | None:
    """Prompt for local AI (Ollama) setup. Returns ai config dict or None."""
    print("\n\u2500\u2500 Local AI (spendctl ask) \u2500" + "\u2500" * 34)
    print()
    print("  spendctl can use a local AI model to analyze your finances.")
    print()

    local_endpoint = "http://localhost:11434"
    endpoint: str | None = None

    # Try local first
    if _try_ollama_connection(local_endpoint):
        print("  \u2713 Ollama found locally")
        endpoint = local_endpoint
    else:
        print("  Ollama not found locally.")
        print()
        print("    1) I have Ollama on another machine (homelab, server, container)")
        print("    2) Skip \u2014 I don't use Ollama")
        print()
        while True:
            choice = input("  > ").strip()
            if choice == "1":
                while True:
                    raw = input("  Ollama endpoint: ").strip()
                    if not raw:
                        print("  Endpoint cannot be empty.")
                        continue
                    if not raw.startswith("http"):
                        raw = "http://" + raw
                    print("  Checking connection...")
                    if _try_ollama_connection(raw):
                        endpoint = raw
                        print(f"  \u2713 Connected to Ollama at {endpoint}")
                        break
                    else:
                        print(f"  Could not connect to {raw}.")
                        retry = input("  Retry with a different endpoint? (y/n): ").strip().lower()
                        if retry != "y":
                            break
                break
            elif choice == "2":
                print("  Skipping local AI setup.")
                return None
            else:
                print("  Enter 1 or 2.")

    if endpoint is None:
        return None

    # List models
    models = _list_ollama_models(endpoint)
    if not models:
        print("  No models found. Pull a model first: ollama pull llama3.2")
        skip = input("  Skip AI setup? (y/n): ").strip().lower()
        if skip != "n":
            return None

    model: str | None = None
    if models:
        print()
        print("  Available models:")
        for i, m in enumerate(models, 1):
            print(f"    {i}) {m}")
        print()
        while True:
            raw = input("  Select model number: ").strip()
            try:
                idx = int(raw) - 1
                if 0 <= idx < len(models):
                    model = models[idx]
                    break
                print(f"  Enter a number between 1 and {len(models)}.")
            except ValueError:
                print("  Enter a number.")

    if model is None:
        return None

    # Test the model
    print(f"  Testing {model}...")
    if _test_ollama_model(endpoint, model):
        print(f"  \u2713 Model '{model}' is working.")
    else:
        print(f"  Warning: model '{model}' did not respond as expected.")
        cont = input("  Continue anyway? (y/n): ").strip().lower()
        if cont != "y":
            return None

    return {"provider": "ollama", "model": model, "endpoint": endpoint}


def _write_integration(assistant: str, context: str) -> str | None:
    """Write context to the appropriate file for the selected assistant.

    Returns a human-readable description of what was written, or None on error.
    """
    try:
        if assistant == "claude":
            target = Path.home() / ".claude" / "CLAUDE.md"
            _upsert_section(target, "## spendctl", context)
            return f"Appended to {target}"
        elif assistant == "codex":
            target = Path.home() / ".codex" / "AGENTS.md"
            _upsert_section(target, "## spendctl", context)
            return f"Appended to {target}"
        elif assistant == "gemini":
            target = Path.home() / ".gemini" / "GEMINI.md"
            _upsert_section(target, "## spendctl", context)
            return f"Appended to {target}"
        elif assistant == "aider":
            ctx_file = Path.cwd() / "spendctl-ai-context.md"
            ctx_file.write_text(context)
            # Add to ~/.aider.conf.yml
            conf_path = Path.home() / ".aider.conf.yml"
            conf_text = conf_path.read_text() if conf_path.exists() else ""
            read_line = "read: spendctl-ai-context.md\n"
            if read_line not in conf_text:
                conf_path.write_text(conf_text + read_line)
            return f"Created {ctx_file} and updated {conf_path}"
        elif assistant == "other":
            ctx_file = Path.cwd() / "spendctl-ai-context.md"
            ctx_file.write_text(context)
            return f"Created {ctx_file}"
    except OSError as exc:
        print(f"  Warning: could not write integration file: {exc}")
        return None
    return None


def _collect_ai_integration() -> list[str]:
    """Prompt for AI assistant integrations. Returns list of configured assistants."""
    print("\n\u2500\u2500 AI Assistant Integration \u2500" + "\u2500" * 33)
    print()
    print("  Which terminal AI assistants should know about spendctl?")
    print("  (Comma-separated, or \"none\" to skip)")
    print()
    print("    1) Claude Code")
    print("    2) Codex CLI (OpenAI)")
    print("    3) Gemini CLI (Google)")
    print("    4) Aider")
    print("    5) Other")
    print()

    raw = input("  > ").strip().lower()
    if not raw or raw == "none":
        print("  Skipping AI assistant integration.")
        return []

    choice_map = {
        "1": "claude",
        "2": "codex",
        "3": "gemini",
        "4": "aider",
        "5": "other",
    }
    label_map = {
        "claude": "Claude Code",
        "codex": "Codex CLI",
        "gemini": "Gemini CLI",
        "aider": "Aider",
        "other": "Other",
    }

    tokens = [t.strip() for t in raw.split(",")]
    selected: list[str] = []
    for token in tokens:
        key = choice_map.get(token)
        if key:
            selected.append(key)

    if not selected:
        print("  No valid selections. Skipping.")
        return []

    configured: list[str] = []
    for assistant in selected:
        result = _write_integration(assistant, _AI_CONTEXT)
        if result:
            print(f"  \u2713 {label_map[assistant]}: {result}")
            configured.append(assistant)

    return configured


# ── Public interface ─────────────────────────────────────────────────────────


def run_init() -> None:
    """Full setup wizard. Creates config.json from scratch."""
    print("=" * 60)
    print("  spendctl — Personal Finance CLI Setup")
    print("=" * 60)
    print()
    print("  This wizard will create your config file at:")
    print(f"  {CONFIG_PATH}")
    print()
    print("  You'll be asked about your:")
    print("    1. Accounts (checking, savings, credit cards, loans)")
    print("    2. Income sources")
    print("    3. Spending categories and budgets")
    print("    4. Financial targets (optional)")
    print("    5. Minimum debt payments")
    print("    6. Student loan details (if applicable)")
    print()
    print("  You can re-run `spendctl init --edit` anytime to update.")
    print()

    if config_exists():
        confirm = input("  Config already exists. Overwrite? [y/N]: ").strip().lower()
        if confirm != "y":
            print("  Aborted. Use `spendctl init --edit` to modify sections.")
            return

    accounts = _collect_accounts()
    income_sources = _collect_income()
    categories = _collect_categories()
    targets = _collect_targets()
    min_payments = _collect_min_payments(accounts)
    loans = _collect_loans(accounts)

    # Section 7: Dashboard
    dashboard_installed = _collect_dashboard()

    # Section 8: Ollama / Local AI
    ai_config = _collect_ollama()

    # Section 9: AI Assistant Integration
    integrations = _collect_ai_integration()

    config: dict = {
        "accounts": accounts,
        "income_sources": income_sources,
        "categories": categories,
        "targets": targets,
        "min_payments": min_payments,
        "loans": loans,
    }
    if ai_config:
        config["ai"] = ai_config
    if integrations:
        config["integrations"] = integrations

    save_config(config)

    # Section 10: Next steps summary
    print()
    print("\u2500\u2500 Setup Complete \u2500" + "\u2500" * 43)
    print()
    print(f"  Config saved to: {CONFIG_PATH}")
    print()
    print("  Next steps:")
    print('    spendctl add 2024-01-15 "Coffee" 4.50 --category "Dining Out"')
    print("    spendctl balance --json")
    if ai_config:
        print('    spendctl ask "How\'s my spending this month?"')
    if dashboard_installed:
        print("    spendctl dashboard")


def edit_config(section: str | None = None) -> None:
    """Edit a specific section of the config interactively."""
    if not config_exists():
        print("No config found. Run `spendctl init` first.")
        return

    cfg = load_config()

    sections = {
        "1": "accounts",
        "2": "income",
        "3": "categories",
        "4": "targets",
        "5": "min_payments",
        "6": "loans",
        "7": "dashboard",
        "8": "ollama",
        "9": "integrations",
    }

    section_labels = {
        "1": "Accounts",
        "2": "Income",
        "3": "Categories",
        "4": "Targets",
        "5": "Min Payments",
        "6": "Loans",
        "7": "Dashboard",
        "8": "Local AI (Ollama)",
        "9": "AI Assistant Integration",
    }

    if section is None:
        print("\nWhich section would you like to edit?")
        for num, label in section_labels.items():
            print(f"  {num}) {label}")
        choice = input("\nChoice: ").strip()
        section = sections.get(choice, choice)

    if section == "accounts":
        cfg["accounts"] = _collect_accounts(existing=cfg.get("accounts", []))
    elif section == "income":
        cfg["income_sources"] = _collect_income(existing=cfg.get("income_sources", []))
    elif section == "categories":
        cfg["categories"] = _collect_categories(existing=cfg.get("categories", []))
    elif section == "targets":
        cfg["targets"] = _collect_targets(existing=cfg.get("targets", {}))
    elif section == "min_payments":
        cfg["min_payments"] = _collect_min_payments(cfg.get("accounts", []), existing=cfg.get("min_payments", {}))
    elif section == "loans":
        cfg["loans"] = _collect_loans(cfg.get("accounts", []), existing=cfg.get("loans", []))
    elif section == "dashboard":
        _collect_dashboard()
    elif section == "ollama":
        ai_cfg = _collect_ollama()
        if ai_cfg:
            cfg["ai"] = ai_cfg
    elif section == "integrations":
        integrations = _collect_ai_integration()
        if integrations:
            cfg["integrations"] = integrations
    else:
        print(f"Unknown section: {section}")
        return

    save_config(cfg)
    reload_config()
    print(f"\n  Section '{section}' updated and saved.")


def show_config() -> None:
    """Pretty-print the current config."""
    if not config_exists():
        print("No config found. Run `spendctl init` first.")
        return
    cfg = load_config()
    print(json.dumps(cfg, indent=2))


def reset_config() -> None:
    """Delete existing config and run the full wizard."""
    if config_exists():
        confirm = input(f"  Delete config at {CONFIG_PATH} and start over? [y/N]: ").strip().lower()
        if confirm != "y":
            print("  Aborted.")
            return
        CONFIG_PATH.unlink()
        print("  Config deleted.")
    run_init()
