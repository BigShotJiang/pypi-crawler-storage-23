"""Subscription queries — list, add, update, cancel, and totals."""

from __future__ import annotations

import sqlite3
from datetime import date


def list_subscriptions(
    conn: sqlite3.Connection,
    status: str | None = None,
) -> list[dict]:
    """List subscriptions, optionally filtered by status.

    Ordered by status (Active first), then name.
    """
    if status is not None:
        rows = conn.execute(
            "SELECT * FROM subscriptions WHERE status = ? ORDER BY status, name",
            (status,),
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM subscriptions ORDER BY status, name").fetchall()

    return [dict(row) for row in rows]


def add_subscription(
    conn: sqlite3.Connection,
    *,
    name: str,
    amount: float,
    account: str,
    category: str = "Subscription",
    frequency: str = "Monthly",
    notes: str | None = None,
    billing_day: int | None = None,
) -> int:
    """Add a new active subscription. Returns the new id."""
    cur = conn.execute(
        """
        INSERT INTO subscriptions (name, amount, account, category, frequency, status, notes, billing_day)
        VALUES (?, ?, ?, ?, ?, 'Active', ?, ?)
        """,
        (name, amount, account, category, frequency, notes, billing_day),
    )
    conn.commit()
    return cur.lastrowid


def update_subscription(
    conn: sqlite3.Connection,
    sub_id: int,
    **fields,
) -> None:
    """Update only the provided fields on a subscription."""
    if not fields:
        return

    set_clause = ", ".join(f"{k} = ?" for k in fields)
    params = list(fields.values()) + [sub_id]
    conn.execute(
        f"UPDATE subscriptions SET {set_clause} WHERE id = ?",
        params,
    )
    conn.commit()


def cancel_subscription(
    conn: sqlite3.Connection,
    sub_id: int,
    canceled_date: str | None = None,
) -> None:
    """Mark a subscription as Canceled with an optional date."""
    if canceled_date is None:
        canceled_date = date.today().isoformat()

    conn.execute(
        "UPDATE subscriptions SET status = 'Canceled', canceled_date = ? WHERE id = ?",
        (canceled_date, sub_id),
    )
    conn.commit()


def active_monthly_total(conn: sqlite3.Connection) -> float:
    """Sum of all active monthly subscriptions."""
    row = conn.execute(
        """
        SELECT COALESCE(SUM(amount), 0) AS total
        FROM subscriptions
        WHERE status = 'Active' AND frequency = 'Monthly'
        """
    ).fetchone()
    return round(row["total"], 2)
