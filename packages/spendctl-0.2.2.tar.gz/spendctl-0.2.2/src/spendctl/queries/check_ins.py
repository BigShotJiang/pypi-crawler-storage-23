"""Check-in queries — add, retrieve, and reconcile balance snapshots."""

from __future__ import annotations

import sqlite3

from spendctl import config


def add_check_in(
    conn: sqlite3.Connection,
    *,
    date: str,
    check_in_number: str | None = None,
    notes: str | None = None,
    balances: dict[str, float | None] | None = None,
) -> int:
    """Insert a check-in with account balances.

    balances is a dict of {account_name: balance_value}.
    """
    cur = conn.execute(
        "INSERT INTO check_ins (date, check_in_number, notes) VALUES (?, ?, ?)",
        (date, check_in_number, notes),
    )
    check_in_id = cur.lastrowid

    if balances:
        for account_name, balance in balances.items():
            if balance is not None:
                conn.execute(
                    "INSERT INTO check_in_balances (check_in_id, account_name, balance) VALUES (?, ?, ?)",
                    (check_in_id, account_name, balance),
                )

    conn.commit()
    return check_in_id


def get_latest_check_in(conn: sqlite3.Connection) -> dict | None:
    """Return the most recent check-in with its balances, or None."""
    row = conn.execute("SELECT * FROM check_ins ORDER BY date DESC, id DESC LIMIT 1").fetchone()
    if row is None:
        return None

    result = dict(row)
    balance_rows = conn.execute(
        "SELECT account_name, balance FROM check_in_balances WHERE check_in_id = ?",
        (result["id"],),
    ).fetchall()
    result["balances"] = {r["account_name"]: r["balance"] for r in balance_rows}
    return result


def get_check_in_history(conn: sqlite3.Connection) -> list[dict]:
    """Return all check-ins with balances, ordered by date."""
    rows = conn.execute("SELECT * FROM check_ins ORDER BY date").fetchall()
    result = []
    for row in rows:
        entry = dict(row)
        balance_rows = conn.execute(
            "SELECT account_name, balance FROM check_in_balances WHERE check_in_id = ?",
            (entry["id"],),
        ).fetchall()
        entry["balances"] = {r["account_name"]: r["balance"] for r in balance_rows}
        result.append(entry)
    return result


def reconcile_balances(
    conn: sqlite3.Connection,
    actual_balances: dict[str, float],
    threshold: float = 1.0,
) -> list[dict]:
    """Compare transaction-derived balances against actual bank balances.

    Args:
        actual_balances: {account_name: actual_balance_from_bank}
        threshold: minimum absolute difference to report (default $1.00)

    Returns:
        List of dicts with keys: account, computed, actual, difference
        Sorted by abs(difference) descending.
        Only accounts where abs(difference) >= threshold are included.
    """
    from spendctl.queries.dashboard import account_balance  # noqa: PLC0415

    accounts = config.get_accounts()
    non_balance = config.get_non_balance_accounts()
    results = []

    for account_name, actual in actual_balances.items():
        if account_name in non_balance or account_name not in accounts:
            continue
        computed = account_balance(conn, account_name)
        difference = actual - computed

        if abs(difference) >= threshold:
            results.append(
                {
                    "account": account_name,
                    "computed": round(computed, 2),
                    "actual": round(actual, 2),
                    "difference": round(difference, 2),
                }
            )

    results.sort(key=lambda r: abs(r["difference"]), reverse=True)
    return results


def add_reconciliation_adjustment(
    conn: sqlite3.Connection,
    *,
    account_name: str,
    amount: float,
    date: str,
    notes: str | None = None,
) -> int:
    """Log a reconciliation adjustment transaction to close a balance gap.

    Positive amount = account had MORE than computed (add inflow).
    Negative amount = account had LESS than computed (add outflow).
    """
    from spendctl.queries.transactions import add_transaction  # noqa: PLC0415

    description = f"Reconciliation adjustment — {account_name}"
    external = config.get_default_to_account()

    if amount >= 0:
        from_account = external
        to_account = account_name
        abs_amount = amount
    else:
        from_account = account_name
        to_account = external
        abs_amount = abs(amount)

    return add_transaction(
        conn,
        date=date,
        description=description,
        amount_usd=round(abs_amount, 2),
        type="Reconciliation",
        from_account=from_account,
        to_account=to_account,
        category="Reconciliation",
        notes=notes,
    )
