"""Report queries — monthly summary, cash flow, spending breakdowns, yearly pivot."""

from __future__ import annotations

import sqlite3
from datetime import date

from spendctl.queries._utils import default_month as _default_month
from spendctl.queries._utils import month_range as _month_range


def monthly_summary(
    conn: sqlite3.Connection,
    month: str | None = None,
) -> dict:
    """Comprehensive monthly report.

    Returns:
        {month, income, expenses_by_category, debt_payments, total_expenses,
         cushion, subscription_total}
    """
    month = _default_month(month)
    start, end = _month_range(month)

    income_row = conn.execute(
        """
        SELECT COALESCE(SUM(amount_usd), 0) AS total
        FROM transactions WHERE type = 'Income' AND date >= ? AND date < ?
        """,
        (start, end),
    ).fetchone()
    income = income_row["total"]

    expense_rows = conn.execute(
        """
        SELECT category, SUM(amount_usd) AS total, COUNT(*) AS count
        FROM transactions
        WHERE type = 'Expense' AND date >= ? AND date < ?
        GROUP BY category
        ORDER BY SUM(amount_usd) DESC
        """,
        (start, end),
    ).fetchall()
    expenses_by_category = [
        {"category": r["category"], "total": round(r["total"], 2), "count": r["count"]}
        for r in expense_rows
    ]

    total_expenses = round(sum(e["total"] for e in expenses_by_category), 2)

    debt_row = conn.execute(
        """
        SELECT COALESCE(SUM(amount_usd), 0) AS total
        FROM transactions WHERE type = 'Debt Payment' AND date >= ? AND date < ?
        """,
        (start, end),
    ).fetchone()
    debt_payments = debt_row["total"]

    sub_row = conn.execute(
        """
        SELECT COALESCE(SUM(amount), 0) AS total
        FROM subscriptions
        WHERE frequency = 'Monthly'
          AND (status = 'Active' OR (status = 'Canceled' AND canceled_date >= ?))
        """,
        (start,),
    ).fetchone()
    subscription_total = sub_row["total"]

    cushion = income - total_expenses - debt_payments

    return {
        "month": month,
        "income": round(income, 2),
        "expenses_by_category": expenses_by_category,
        "debt_payments": round(debt_payments, 2),
        "total_expenses": total_expenses,
        "cushion": round(cushion, 2),
        "subscription_total": round(subscription_total, 2),
    }


def cash_flow(
    conn: sqlite3.Connection,
    start_date: str,
    end_date: str,
) -> dict:
    """Cash-flow breakdown between two dates.

    Returns:
        {start_date, end_date, money_in, expenses, debt_payments, interest, transfers, net}
    """

    def _sum_type(tx_type: str) -> float:
        row = conn.execute(
            """
            SELECT COALESCE(SUM(amount_usd), 0) AS total
            FROM transactions
            WHERE type = ? AND date >= ? AND date <= ?
            """,
            (tx_type, start_date, end_date),
        ).fetchone()
        return row["total"]

    money_in = _sum_type("Income")
    expenses = _sum_type("Expense")
    debt_payments = _sum_type("Debt Payment")
    interest = _sum_type("Interest")
    transfers = _sum_type("Transfer")

    net = money_in - expenses - debt_payments - interest

    return {
        "start_date": start_date,
        "end_date": end_date,
        "money_in": round(money_in, 2),
        "expenses": round(expenses, 2),
        "debt_payments": round(debt_payments, 2),
        "interest": round(interest, 2),
        "transfers": round(transfers, 2),
        "net": round(net, 2),
    }


def spending_by_category(
    conn: sqlite3.Connection,
    start_date: str | None = None,
    end_date: str | None = None,
) -> list[dict]:
    """Spending grouped by category for Expense-type transactions.

    Returns [{category, total, count, pct}] sorted by total descending.
    """
    clauses = ["type = 'Expense'"]
    params: list = []

    if start_date is not None:
        clauses.append("date >= ?")
        params.append(start_date)
    if end_date is not None:
        clauses.append("date <= ?")
        params.append(end_date)

    where = "WHERE " + " AND ".join(clauses)

    rows = conn.execute(
        f"""
        SELECT category, SUM(amount_usd) AS total, COUNT(*) AS count
        FROM transactions
        {where}
        GROUP BY category
        ORDER BY SUM(amount_usd) DESC
        """,
        params,
    ).fetchall()

    grand_total = sum(r["total"] for r in rows) if rows else 0.0

    return [
        {
            "category": r["category"],
            "total": round(r["total"], 2),
            "count": r["count"],
            "pct": round(r["total"] / grand_total * 100, 1) if grand_total else 0.0,
        }
        for r in rows
    ]


def spending_by_account(
    conn: sqlite3.Connection,
    start_date: str | None = None,
    end_date: str | None = None,
) -> list[dict]:
    """Spending grouped by from_account for Expense-type transactions.

    Returns [{account, total, count}].
    """
    clauses = ["type = 'Expense'"]
    params: list = []

    if start_date is not None:
        clauses.append("date >= ?")
        params.append(start_date)
    if end_date is not None:
        clauses.append("date <= ?")
        params.append(end_date)

    where = "WHERE " + " AND ".join(clauses)

    rows = conn.execute(
        f"""
        SELECT from_account AS account, SUM(amount_usd) AS total, COUNT(*) AS count
        FROM transactions
        {where}
        GROUP BY from_account
        ORDER BY SUM(amount_usd) DESC
        """,
        params,
    ).fetchall()

    return [
        {
            "account": r["account"],
            "total": round(r["total"], 2),
            "count": r["count"],
        }
        for r in rows
    ]


def yearly_summary(
    conn: sqlite3.Connection,
    year: int | None = None,
) -> list[dict]:
    """Monthly spending pivot table for a year.

    Returns [{category, jan, feb, ..., dec, ytd}] — one row per category
    that had any Expense-type spending in the year.
    """
    if year is None:
        year = date.today().year

    start = f"{year}-01-01"
    end = f"{year + 1}-01-01"

    rows = conn.execute(
        """
        SELECT category,
               CAST(strftime('%m', date) AS INTEGER) AS month_num,
               SUM(amount_usd) AS total
        FROM transactions
        WHERE type = 'Expense' AND date >= ? AND date < ?
        GROUP BY category, strftime('%m', date)
        ORDER BY category
        """,
        (start, end),
    ).fetchall()

    month_names = [
        "jan", "feb", "mar", "apr", "may", "jun",
        "jul", "aug", "sep", "oct", "nov", "dec",
    ]

    pivot: dict[str, dict[str, float]] = {}
    for r in rows:
        cat = r["category"]
        if cat not in pivot:
            pivot[cat] = {m: 0.0 for m in month_names}
        month_key = month_names[r["month_num"] - 1]
        pivot[cat][month_key] = round(r["total"], 2)

    result: list[dict] = []
    for cat in sorted(pivot):
        entry: dict = {"category": cat}
        ytd = 0.0
        for m in month_names:
            val = pivot[cat][m]
            entry[m] = val
            ytd += val
        entry["ytd"] = round(ytd, 2)
        result.append(entry)

    return result
