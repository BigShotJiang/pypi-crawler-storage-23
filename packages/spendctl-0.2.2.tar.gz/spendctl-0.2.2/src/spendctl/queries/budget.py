"""Budget queries — budget vs actual, remaining, income, and cushion."""

from __future__ import annotations

import sqlite3

from spendctl.queries._utils import default_month as _default_month
from spendctl.queries._utils import month_range as _month_range


def budget_vs_actual(
    conn: sqlite3.Connection,
    month: str | None = None,
) -> list[dict]:
    """Compare budgeted vs actual spending for a month.

    Returns a row for every category that has a budget_amount > 0 OR
    had actual spending in the given month.
    """
    month = _default_month(month)
    start, end = _month_range(month)

    rows = conn.execute(
        """
        SELECT
            c.name          AS category,
            c.budget_amount AS budgeted,
            COALESCE(t.actual, 0) AS actual,
            COALESCE(t.tx_count, 0) AS tx_count
        FROM categories c
        LEFT JOIN (
            SELECT category, SUM(amount_usd) AS actual, COUNT(*) AS tx_count
            FROM transactions
            WHERE type IN ('Expense', 'Transfer', 'Debt Payment') AND date >= ? AND date < ?
            GROUP BY category
        ) t ON c.name = t.category
        WHERE c.budget_amount > 0 OR COALESCE(t.actual, 0) > 0
        ORDER BY c.budget_amount DESC, COALESCE(t.actual, 0) DESC
        """,
        (start, end),
    ).fetchall()

    return [
        {
            "category": row["category"],
            "budgeted": round(row["budgeted"], 2),
            "actual": round(row["actual"], 2),
            "difference": round(row["budgeted"] - row["actual"], 2),
            "tx_count": row["tx_count"],
        }
        for row in rows
    ]


def remaining_budget(
    conn: sqlite3.Connection,
    category: str,
    month: str | None = None,
) -> dict:
    """Return {budgeted, spent, remaining} for a single category."""
    month = _default_month(month)
    start, end = _month_range(month)

    budget_row = conn.execute(
        "SELECT COALESCE(budget_amount, 0) AS budgeted FROM categories WHERE name = ?",
        (category,),
    ).fetchone()
    budgeted = budget_row["budgeted"] if budget_row else 0.0

    spent_row = conn.execute(
        """
        SELECT COALESCE(SUM(amount_usd), 0) AS spent
        FROM transactions
        WHERE type IN ('Expense', 'Transfer') AND category = ? AND date >= ? AND date < ?
        """,
        (category, start, end),
    ).fetchone()
    spent = spent_row["spent"]

    return {
        "budgeted": round(budgeted, 2),
        "spent": round(spent, 2),
        "remaining": round(budgeted - spent, 2),
    }


def total_income(
    conn: sqlite3.Connection,
    month: str | None = None,
) -> dict:
    """Return {budgeted, actual} income for the month."""
    month = _default_month(month)
    start, end = _month_range(month)

    budgeted_row = conn.execute("SELECT COALESCE(SUM(amount), 0) AS total FROM budget_income").fetchone()
    budgeted = budgeted_row["total"]

    actual_row = conn.execute(
        """
        SELECT COALESCE(SUM(amount_usd), 0) AS total
        FROM transactions
        WHERE type = 'Income' AND date >= ? AND date < ?
        """,
        (start, end),
    ).fetchone()
    actual = actual_row["total"]

    return {
        "budgeted": round(budgeted, 2),
        "actual": round(actual, 2),
    }


def monthly_cushion(
    conn: sqlite3.Connection,
    month: str | None = None,
) -> dict:
    """Return {income, expenses, debt_payments, budgeted_transfers, cushion} for the month."""
    month = _default_month(month)
    start, end = _month_range(month)

    income_row = conn.execute(
        """
        SELECT COALESCE(SUM(amount_usd), 0) AS total
        FROM transactions
        WHERE type = 'Income' AND date >= ? AND date < ?
        """,
        (start, end),
    ).fetchone()
    income = income_row["total"]

    expense_row = conn.execute(
        """
        SELECT COALESCE(SUM(amount_usd), 0) AS total
        FROM transactions
        WHERE type = 'Expense' AND date >= ? AND date < ?
        """,
        (start, end),
    ).fetchone()
    expenses = expense_row["total"]

    debt_row = conn.execute(
        """
        SELECT COALESCE(SUM(amount_usd), 0) AS total
        FROM transactions
        WHERE type = 'Debt Payment' AND date >= ? AND date < ?
        """,
        (start, end),
    ).fetchone()
    debt_payments = debt_row["total"]

    transfer_row = conn.execute(
        """
        SELECT COALESCE(SUM(amount_usd), 0) AS total
        FROM transactions
        WHERE type = 'Transfer' AND category IN (
            SELECT name FROM categories WHERE budget_amount > 0
        ) AND date >= ? AND date < ?
        """,
        (start, end),
    ).fetchone()
    budgeted_transfers = transfer_row["total"]

    cushion = income - expenses - debt_payments - budgeted_transfers

    return {
        "income": round(income, 2),
        "expenses": round(expenses, 2),
        "debt_payments": round(debt_payments, 2),
        "budgeted_transfers": round(budgeted_transfers, 2),
        "cushion": round(cushion, 2),
    }
