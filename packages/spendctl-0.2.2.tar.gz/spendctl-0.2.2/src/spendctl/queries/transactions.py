"""Transaction queries — CRUD, search, and duplicate detection."""

from __future__ import annotations

import sqlite3
from datetime import datetime


def add_transaction(
    conn: sqlite3.Connection,
    *,
    date: str,
    description: str,
    amount_usd: float,
    type: str,
    from_account: str,
    to_account: str,
    category: str,
    notes: str | None = None,
) -> int:
    """Insert a new transaction and return its id."""
    now = datetime.now().isoformat(timespec="seconds")
    cur = conn.execute(
        """
        INSERT INTO transactions
            (date, description, amount_usd, type, from_account, to_account,
             category, notes, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (date, description, amount_usd, type, from_account, to_account, category, notes, now),
    )
    conn.commit()
    return cur.lastrowid


def list_transactions(
    conn: sqlite3.Connection,
    *,
    start_date: str | None = None,
    end_date: str | None = None,
    category: str | None = None,
    type: str | None = None,
    account: str | None = None,
    description: str | None = None,
    limit: int = 50,
) -> list[dict]:
    """List transactions with flexible filtering.

    ``account`` matches either from_account or to_account.
    Results are ordered by date, then id.
    """
    clauses: list[str] = []
    params: list = []

    if start_date is not None:
        clauses.append("date >= ?")
        params.append(start_date)
    if end_date is not None:
        clauses.append("date <= ?")
        params.append(end_date)
    if category is not None:
        clauses.append("category = ?")
        params.append(category)
    if type is not None:
        clauses.append("type = ? COLLATE NOCASE")
        params.append(type)
    if account is not None:
        clauses.append("(from_account = ? OR to_account = ?)")
        params.extend([account, account])
    if description is not None:
        clauses.append("description LIKE ? COLLATE NOCASE")
        params.append(f"%{description}%")

    where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    sql = (
        f"SELECT * FROM (SELECT * FROM transactions {where} ORDER BY date DESC, id DESC LIMIT ?)"
        " ORDER BY date, id"
    )
    params.append(limit)

    return [dict(row) for row in conn.execute(sql, params).fetchall()]


def search_transactions(
    conn: sqlite3.Connection,
    *,
    date: str | None = None,
    description: str | None = None,
    amount: float | None = None,
    account: str | None = None,
) -> list[dict]:
    """Search for transactions by exact or fuzzy criteria.

    ``description`` uses fuzzy LIKE matching.
    ``amount`` matches within $0.01.
    """
    clauses: list[str] = []
    params: list = []

    if date is not None:
        clauses.append("date = ?")
        params.append(date)
    if description is not None:
        clauses.append("description LIKE ?")
        params.append(f"%{description}%")
    if amount is not None:
        clauses.append("ABS(amount_usd - ?) <= 0.01")
        params.append(amount)
    if account is not None:
        clauses.append("(from_account = ? OR to_account = ?)")
        params.extend([account, account])

    where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    sql = f"SELECT * FROM transactions {where} ORDER BY date DESC, id DESC"
    return [dict(row) for row in conn.execute(sql, params).fetchall()]


def update_transaction(
    conn: sqlite3.Connection,
    tx_id: int,
    **fields,
) -> None:
    """Update only the provided fields on a transaction.

    Always bumps ``updated_at``.
    """
    if not fields:
        return

    fields["updated_at"] = datetime.now().isoformat(timespec="seconds")

    set_clause = ", ".join(f"{k} = ?" for k in fields)
    params = list(fields.values()) + [tx_id]
    conn.execute(
        f"UPDATE transactions SET {set_clause} WHERE id = ?",
        params,
    )
    conn.commit()


def delete_transaction(conn: sqlite3.Connection, tx_id: int) -> None:
    """Delete a transaction by id."""
    conn.execute("DELETE FROM transactions WHERE id = ?", (tx_id,))
    conn.commit()


def find_duplicates(conn: sqlite3.Connection) -> list[dict]:
    """Find potential duplicate transactions.

    Groups by date, amount_usd, and from_account where more than one
    record matches.
    """
    rows = conn.execute(
        """
        SELECT date, amount_usd, from_account, COUNT(*) AS count,
               GROUP_CONCAT(id) AS ids
        FROM transactions
        GROUP BY date, amount_usd, from_account
        HAVING COUNT(*) > 1
        ORDER BY date DESC
        """
    ).fetchall()
    return [dict(row) for row in rows]
