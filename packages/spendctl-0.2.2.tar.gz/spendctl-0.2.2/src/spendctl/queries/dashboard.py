"""Dashboard queries — live balances, net worth, and debt progress."""

from __future__ import annotations

import sqlite3

from spendctl import config


def account_balance(conn: sqlite3.Connection, account_name: str) -> float:
    """Compute current balance for an account.

    For asset accounts: balance = starting_balance + inflows - outflows
    For debt accounts:  balance = starting_balance + outflows - inflows
    """
    non_balance = config.get_non_balance_accounts()
    if account_name in non_balance:
        return 0.0

    row = conn.execute(
        "SELECT starting_balance FROM accounts WHERE name = ?",
        (account_name,),
    ).fetchone()
    starting = row["starting_balance"] if row and row["starting_balance"] else 0.0

    inflow = conn.execute(
        "SELECT COALESCE(SUM(amount_usd), 0) AS total FROM transactions WHERE to_account = ?",
        (account_name,),
    ).fetchone()["total"]

    outflow = conn.execute(
        "SELECT COALESCE(SUM(amount_usd), 0) AS total FROM transactions WHERE from_account = ?",
        (account_name,),
    ).fetchone()["total"]

    accounts = config.get_accounts()
    acct_info = accounts.get(account_name, {})
    acct_type = acct_info.get("type", "")

    debt_types = {"credit_card", "loan", "student_loan"}
    if acct_type in debt_types:
        return round(starting + outflow - inflow, 2)
    else:
        return round(starting + inflow - outflow, 2)


def all_balances(conn: sqlite3.Connection) -> dict[str, float]:
    """Return current balance for every trackable account."""
    accounts = config.get_accounts()
    non_balance = config.get_non_balance_accounts()
    return {
        name: account_balance(conn, name)
        for name in accounts
        if name not in non_balance
    }


def net_worth(conn: sqlite3.Connection, balances: dict[str, float] | None = None) -> dict:
    """Compute net-worth snapshot grouped by account type.

    Returns:
        {liquid_assets, investments, total_debt, net_worth, emergency_fund}
    """
    if balances is None:
        balances = all_balances(conn)

    accounts = config.get_accounts()

    liquid_assets = sum(
        balances.get(name, 0)
        for name, info in accounts.items()
        if info["type"] in ("checking", "savings")
    )

    investments = sum(
        balances.get(name, 0)
        for name, info in accounts.items()
        if info["type"] == "investment"
    )

    total_debt = sum(
        balances.get(name, 0)
        for name, info in accounts.items()
        if info["type"] in ("credit_card", "loan", "student_loan")
    )

    emergency_fund = sum(
        balances.get(name, 0)
        for name, info in accounts.items()
        if info["type"] == "savings"
    )

    return {
        "liquid_assets": round(liquid_assets, 2),
        "investments": round(investments, 2),
        "total_debt": round(total_debt, 2),
        "net_worth": round(liquid_assets + investments - total_debt, 2),
        "emergency_fund": round(emergency_fund, 2),
    }


def debt_progress(conn: sqlite3.Connection, balances: dict[str, float] | None = None) -> dict:
    """Compute debt paydown progress per account.

    For each debt account (credit_card, loan, student_loan), returns:
      starting_balance, current_balance, amount_paid, progress_pct
    """
    if balances is None:
        balances = all_balances(conn)

    accounts = config.get_accounts()
    debt_types = {"credit_card", "loan", "student_loan"}

    result = {}
    for acct_name, info in accounts.items():
        if info["type"] not in debt_types:
            continue

        row = conn.execute(
            "SELECT starting_balance FROM accounts WHERE name = ?", (acct_name,)
        ).fetchone()
        starting = row["starting_balance"] if row and row["starting_balance"] else 0.0

        current = balances.get(acct_name, 0.0)
        amount_paid = starting - current
        progress_pct = (amount_paid / starting * 100) if starting else 0.0

        result[acct_name] = {
            "starting_balance": round(starting, 2),
            "current_balance": round(current, 2),
            "amount_paid": round(amount_paid, 2),
            "progress_pct": round(progress_pct, 1),
        }

    return result
