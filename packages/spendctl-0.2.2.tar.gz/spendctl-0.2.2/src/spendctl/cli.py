"""spendctl CLI entry point."""

from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import date

from spendctl import __version__
from spendctl.config import config_exists
from spendctl.db import backup, ensure_db

_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_MONTH_RE = re.compile(r"^\d{4}-\d{2}$")


def _validate_date(value: str | None, flag: str) -> None:
    """Exit with an error if value is not a valid YYYY-MM-DD date."""
    if value is None:
        return
    if not _DATE_RE.match(value):
        print(f"Invalid date for {flag}: '{value}'. Expected YYYY-MM-DD.")
        sys.exit(1)
    try:
        date.fromisoformat(value)
    except ValueError:
        print(f"Invalid date for {flag}: '{value}'. Expected YYYY-MM-DD.")
        sys.exit(1)


def _validate_month(value: str | None, flag: str = "--month") -> None:
    """Exit with an error if value is not a valid YYYY-MM month."""
    if value is None:
        return
    if not _MONTH_RE.match(value):
        print(f"Invalid month for {flag}: '{value}'. Expected YYYY-MM.")
        sys.exit(1)
    month_num = int(value[5:7])
    if not (1 <= month_num <= 12):
        print(f"Invalid month for {flag}: '{value}'. Month must be 01-12.")
        sys.exit(1)


def _config_guard() -> None:
    """Exit with a helpful message if config doesn't exist."""
    if not config_exists():
        print("No config found. Run `spendctl init` to set up.")
        sys.exit(1)


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="spendctl", description="Personal finance CLI built for AI workflows")
    parser.add_argument("--version", action="version", version=f"spendctl {__version__}")
    sub = parser.add_subparsers(dest="command")

    # ── init ───────────────────────────────────────────────────────────
    sub.add_parser("init", help="Run the setup wizard to create your config")

    # ── config ─────────────────────────────────────────────────────────
    config_parser = sub.add_parser("config", help="Manage spendctl configuration")
    config_sub = config_parser.add_subparsers(dest="config_command")
    config_sub.add_parser("show", help="Show current config")
    config_sub.add_parser("edit", help="Edit a config section interactively")
    config_sub.add_parser("reset", help="Delete config and re-run wizard")

    # ── list ───────────────────────────────────────────────────────────
    p = sub.add_parser("list", help="List transactions")
    p.add_argument("--start", help="Start date (YYYY-MM-DD)")
    p.add_argument("--end", help="End date (YYYY-MM-DD)")
    p.add_argument("--category", help="Filter by category")
    p.add_argument("--type", help="Filter by type (Expense, Income, etc.)")
    p.add_argument("--account", help="Filter by account (from or to)")
    p.add_argument("--description", help="Filter by description (partial match)")
    p.add_argument("--limit", type=int, default=25, help="Max results (default: 25)")
    p.add_argument("--json", action="store_true", help="JSON output")

    # ── add ────────────────────────────────────────────────────────────
    p = sub.add_parser("add", help="Add a transaction")
    p.add_argument("date", help="Date (YYYY-MM-DD)")
    p.add_argument("description", help="Description")
    p.add_argument("amount", type=float, help="Amount in USD")
    p.add_argument("--type", default="Expense", help="Type (default: Expense)")
    p.add_argument("--from", dest="from_account", default=None, help="From account")
    p.add_argument("--to", dest="to_account", default=None, help="To account")
    p.add_argument("--category", required=True, help="Category")
    p.add_argument("--notes", help="Notes")
    p.add_argument("--json", action="store_true", help="JSON output")

    # ── balance ────────────────────────────────────────────────────────
    p = sub.add_parser("balance", help="Show account balance(s)")
    p.add_argument("account", nargs="?", help="Specific account (default: all)")
    p.add_argument("--json", action="store_true", help="JSON output")

    # ── spending ───────────────────────────────────────────────────────
    p = sub.add_parser("spending", help="Spending breakdown by category")
    p.add_argument("--month", help="Month (YYYY-MM, default: current)")
    p.add_argument("--json", action="store_true", help="JSON output")

    # ── debt ───────────────────────────────────────────────────────────
    p = sub.add_parser("debt", help="Debt progress dashboard")
    p.add_argument("--json", action="store_true", help="JSON output")

    # ── budget ─────────────────────────────────────────────────────────
    p = sub.add_parser("budget", help="Budget vs actual comparison")
    p.add_argument("--month", help="Month (YYYY-MM, default: current)")
    p.add_argument("--json", action="store_true", help="JSON output")

    # ── summary ────────────────────────────────────────────────────────
    p = sub.add_parser("summary", help="Full monthly summary")
    p.add_argument("--month", help="Month (YYYY-MM, default: current)")
    p.add_argument("--json", action="store_true", help="JSON output")

    # ── subscriptions ──────────────────────────────────────────────────
    p = sub.add_parser("subscriptions", help="List subscriptions")
    p.add_argument("--status", choices=["Active", "Canceled", "Paused"], help="Filter by status")
    p.add_argument("--json", action="store_true", help="JSON output")

    # ── backup ─────────────────────────────────────────────────────────
    sub.add_parser("backup", help="Create a database backup")

    # ── dashboard ──────────────────────────────────────────────────────
    sub.add_parser("dashboard", help="Launch the Streamlit dashboard")

    # ── export-csv ─────────────────────────────────────────────────────
    p = sub.add_parser("export-csv", help="Export transactions to CSV")
    p.add_argument("--output", "-o", help="Output file path (default: stdout)")

    # ── ask ────────────────────────────────────────────────────────────
    p = sub.add_parser("ask", help="Ask your local AI about your finances")
    p.add_argument("question", help="Question about your finances")

    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        sys.exit(1)

    commands = {
        "init": cmd_init,
        "config": cmd_config,
        "list": cmd_list,
        "add": cmd_add,
        "balance": cmd_balance,
        "spending": cmd_spending,
        "debt": cmd_debt,
        "budget": cmd_budget,
        "summary": cmd_summary,
        "subscriptions": cmd_subscriptions,
        "backup": cmd_backup,
        "dashboard": cmd_dashboard,
        "export-csv": cmd_export_csv,
        "ask": cmd_ask,
    }
    commands[args.command](args)


# ── Command Handlers ───────────────────────────────────────────────────


def cmd_init(args):
    from spendctl.init_wizard import run_init

    run_init()


def cmd_config(args):
    from spendctl.init_wizard import edit_config, reset_config, show_config

    config_command = getattr(args, "config_command", None)
    if config_command == "show":
        show_config()
    elif config_command == "edit":
        edit_config()
    elif config_command == "reset":
        reset_config()
    else:
        print("Usage: spendctl config [show|edit|reset]")
        sys.exit(1)


def cmd_list(args):
    from spendctl.queries.transactions import list_transactions

    _config_guard()
    _validate_date(args.start, "--start")
    _validate_date(args.end, "--end")

    conn = ensure_db()
    txns = list_transactions(
        conn,
        start_date=args.start,
        end_date=args.end,
        category=args.category,
        type=args.type,
        account=args.account,
        description=args.description,
        limit=args.limit,
    )
    conn.close()

    if args.json:
        print(json.dumps(txns, indent=2))
        return

    if not txns:
        print("No transactions found.")
        return

    print(f"{'Date':<12} {'Description':<28} {'Amount':>10} {'Account':<20} {'Category':<22} {'Notes'}")
    print("-" * 110)
    for t in txns:
        notes = (t.get("notes") or "")[:30]
        print(f"{t['date']:<12} {t['description']:<28} ${t['amount_usd']:>9,.2f} {t['from_account']:<20} {t['category']:<22} {notes}")
    print(f"\n{len(txns)} transaction(s)")


def cmd_add(args):
    from spendctl.queries.transactions import add_transaction

    _config_guard()
    _validate_date(args.date, "date")

    if args.from_account is None:
        from spendctl.config import get_default_from_account

        args.from_account = get_default_from_account()
    if args.to_account is None:
        from spendctl.config import get_default_to_account

        args.to_account = get_default_to_account()

    conn = ensure_db()
    tx_id = add_transaction(
        conn,
        date=args.date,
        description=args.description,
        amount_usd=args.amount,
        type=args.type,
        from_account=args.from_account,
        to_account=args.to_account,
        category=args.category,
        notes=args.notes,
    )
    conn.close()

    if args.json:
        print(json.dumps({"id": tx_id, "status": "added"}))
    else:
        print(f"Added transaction #{tx_id}: {args.description} ${args.amount:.2f}")


def cmd_balance(args):
    from spendctl.queries.dashboard import account_balance, all_balances

    _config_guard()

    conn = ensure_db()

    if args.account:
        from spendctl.config import get_accounts

        valid_accounts = get_accounts()
        if args.account not in valid_accounts:
            conn.close()
            valid = ", ".join(sorted(valid_accounts))
            print(f"Unknown account: '{args.account}'")
            print(f"Valid accounts: {valid}")
            sys.exit(1)
        bal = account_balance(conn, args.account)
        conn.close()
        if args.json:
            print(json.dumps({"account": args.account, "balance": bal}))
        else:
            print(f"{args.account}: ${bal:,.2f}")
        return

    bals = all_balances(conn)
    conn.close()

    if args.json:
        print(json.dumps(bals, indent=2))
        return

    print(f"{'Account':<25} {'Balance':>12}")
    print("-" * 39)
    for acct, bal in bals.items():
        print(f"{acct:<25} ${bal:>11,.2f}")


def cmd_spending(args):
    from datetime import timedelta

    from spendctl.queries.reports import spending_by_category

    _config_guard()
    _validate_month(args.month)

    month = args.month or date.today().strftime("%Y-%m")
    start = f"{month}-01"
    y, m = int(month[:4]), int(month[5:])
    if m == 12:
        end = f"{y + 1}-01-01"
    else:
        end = f"{y}-{m + 1:02d}-01"
    end_date = date.fromisoformat(end) - timedelta(days=1)
    end = end_date.isoformat()

    conn = ensure_db()
    cats = spending_by_category(conn, start_date=start, end_date=end)
    conn.close()

    if args.json:
        print(json.dumps(cats, indent=2))
        return

    if not cats:
        print(f"No spending data for {month}.")
        return

    total = sum(c["total"] for c in cats)
    print(f"Spending for {month}")
    print(f"{'Category':<25} {'Amount':>10} {'Count':>6} {'Pct':>6}")
    print("-" * 50)
    for c in cats:
        print(f"{c['category']:<25} ${c['total']:>9,.2f} {c['count']:>6} {c['pct']:>5.1f}%")
    print("-" * 50)
    print(f"{'Total':<25} ${total:>9,.2f}")


def cmd_debt(args):
    from spendctl.queries.dashboard import debt_progress

    _config_guard()

    conn = ensure_db()
    dp = debt_progress(conn)
    conn.close()

    if args.json:
        print(json.dumps(dp, indent=2))
        return

    print("Debt Progress")
    print(f"{'Account':<25} {'Starting':>12} {'Current':>12} {'Paid':>12} {'Progress':>9}")
    print("-" * 73)
    for acct, info in dp.items():
        if acct.startswith("_"):
            continue
        print(
            f"{acct:<25} ${info['starting_balance']:>11,.2f} ${info['current_balance']:>11,.2f} "
            f"${info['amount_paid']:>11,.2f} {info['progress_pct']:>7.1f}%"
        )


def cmd_budget(args):
    from spendctl.queries.budget import budget_vs_actual

    _config_guard()
    _validate_month(args.month)

    conn = ensure_db()
    bva = budget_vs_actual(conn, month=args.month)
    conn.close()

    if args.json:
        print(json.dumps(bva, indent=2))
        return

    month = args.month or date.today().strftime("%Y-%m")
    print(f"Budget vs Actual — {month}")
    print(f"{'Category':<25} {'Budget':>10} {'Actual':>10} {'Diff':>10} {'Txns':>5}")
    print("-" * 63)
    for row in bva:
        diff = row["difference"]
        sign = "+" if diff >= 0 else ""
        print(f"{row['category']:<25} ${row['budgeted']:>9,.2f} ${row['actual']:>9,.2f} {sign}${diff:>8,.2f} {row['tx_count']:>5}")


def cmd_summary(args):
    from spendctl.queries.reports import monthly_summary

    _config_guard()
    _validate_month(args.month)

    conn = ensure_db()
    s = monthly_summary(conn, month=args.month)
    conn.close()

    if args.json:
        print(json.dumps(s, indent=2))
        return

    month = args.month or date.today().strftime("%Y-%m")
    print(f"Monthly Summary — {month}")
    print("=" * 50)
    print(f"  Income:         ${s['income']:>10,.2f}")
    print(f"  Expenses:       ${s['total_expenses']:>10,.2f}")
    print(f"  Debt Payments:  ${s['debt_payments']:>10,.2f}")
    print(f"  Subscriptions:  ${s['subscription_total']:>10,.2f}")
    print(f"  Cushion:        ${s['cushion']:>10,.2f}")
    print()
    if s.get("expenses_by_category"):
        print("Expenses by Category:")
        for c in s["expenses_by_category"]:
            print(f"  {c['category']:<25} ${c['total']:>9,.2f} ({c['count']} txns)")


def cmd_subscriptions(args):
    from spendctl.queries.subscriptions import active_monthly_total, list_subscriptions

    _config_guard()

    conn = ensure_db()
    subs = list_subscriptions(conn, status=args.status)
    total = active_monthly_total(conn)
    conn.close()

    if args.json:
        print(json.dumps({"subscriptions": subs, "active_monthly_total": total}, indent=2))
        return

    def ordinal(n):
        if n is None:
            return "\u2014"
        n = int(n)
        suffix = "th" if 11 <= (n % 100) <= 13 else {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")
        return f"{n}{suffix}"

    print(f"{'Name':<30} {'Amount':>8} {'Account':<20} {'Status':<10} {'Bills On':>8}")
    print("-" * 82)
    for s in subs:
        bills_on = ordinal(s.get("billing_day"))
        print(f"{s['name']:<30} ${s['amount']:>7,.2f} {s['account']:<20} {s['status']:<10} {bills_on:>8}")
    print(f"\nActive monthly total: ${total:,.2f}")


def cmd_dashboard(args):
    import subprocess
    from pathlib import Path

    _config_guard()

    app_path = Path(__file__).parent / "dashboard" / "app.py"
    subprocess.run([sys.executable, "-m", "streamlit", "run", str(app_path)])


def cmd_backup(args):
    _config_guard()
    dest = backup()
    print(f"Backup created: {dest}")


def cmd_export_csv(args):
    import csv
    import io

    from spendctl.queries.transactions import list_transactions

    _config_guard()

    conn = ensure_db()
    txns = list_transactions(conn, limit=10000)
    conn.close()

    fields = ["id", "date", "description", "amount_usd", "type", "from_account", "to_account", "category", "notes"]

    if args.output:
        with open(args.output, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            for t in txns:
                writer.writerow(t)
        print(f"Exported {len(txns)} transactions to {args.output}")
    else:
        f = io.StringIO()
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for t in txns:
            writer.writerow(t)
        print(f.getvalue())


def cmd_ask(args):
    """Ask a local AI model about your finances."""
    import urllib.error
    import urllib.request

    from spendctl.config import get_ai_config

    if not config_exists():
        print("No config found. Run `spendctl init` to set up.")
        sys.exit(1)

    ai_config = get_ai_config()
    if not ai_config:
        print("No AI model configured. Run `spendctl config edit` to set up Ollama.")
        sys.exit(1)

    endpoint = ai_config.get("endpoint", "http://localhost:11434")
    model = ai_config.get("model")

    if not model:
        print("No AI model configured. Run `spendctl config edit` to set up Ollama.")
        sys.exit(1)

    # Gather financial context
    conn = ensure_db()

    from spendctl.queries.dashboard import all_balances, debt_progress, net_worth
    from spendctl.queries.reports import monthly_summary
    from spendctl.queries.subscriptions import active_monthly_total

    bals = all_balances(conn)
    nw = net_worth(conn, balances=bals)
    dp = debt_progress(conn, balances=bals)
    summary = monthly_summary(conn)
    sub_total = active_monthly_total(conn)
    conn.close()

    context = json.dumps(
        {
            "balances": bals,
            "net_worth": nw,
            "debt_progress": dp,
            "monthly_summary": summary,
            "subscription_total": sub_total,
        },
        indent=2,
    )

    prompt = f"""You are a helpful financial advisor. The user tracks their personal finances with spendctl.

Here is their current financial data:

{context}

User question: {args.question}

Provide a clear, concise answer based on the data above. Use specific numbers from the data. Keep your response under 200 words unless the question requires more detail."""

    url = f"{endpoint.rstrip('/')}/api/generate"
    payload = json.dumps({"model": model, "prompt": prompt, "stream": False}).encode()

    req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})

    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            result = json.loads(resp.read().decode())
            print(result.get("response", "No response from model."))
    except urllib.error.URLError as e:
        print(f"Could not connect to Ollama at {endpoint}: {e.reason}")
        print("Make sure Ollama is running and the endpoint is correct.")
        sys.exit(1)
    except Exception as e:
        print(f"Error communicating with Ollama: {e}")
        sys.exit(1)
