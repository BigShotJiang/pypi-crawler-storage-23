"""Transaction entry and browser page."""

from __future__ import annotations

from datetime import date

import streamlit as st

from spendctl import config
from spendctl.dashboard.helpers import fmt_usd, get_conn
from spendctl.db import backup
from spendctl.queries.transactions import (
    add_transaction,
    delete_transaction,
    list_transactions,
    update_transaction,
)

st.set_page_config(page_title="Transactions — spendctl", layout="wide", page_icon="💰")
st.title("Transactions")

conn = get_conn()

accounts = config.get_accounts()
account_names = list(accounts.keys())
categories = config.get_categories()
category_names = list(categories.keys())
TRANSACTION_TYPES = config.TRANSACTION_TYPES

# ---------------------------------------------------------------------------
# Smart defaults per transaction type (derived from config)
# ---------------------------------------------------------------------------
first_checking = next((n for n, i in accounts.items() if i["type"] == "checking"), None)
first_savings = next((n for n, i in accounts.items() if i["type"] == "savings"), None)
first_cc = next((n for n, i in accounts.items() if i["type"] == "credit_card"), None)
first_external = next((n for n, i in accounts.items() if i["type"] == "external"), None)

TYPE_DEFAULTS: dict[str, dict[str, str | None]] = {
    "Expense": {"from": first_checking, "to": first_external},
    "Income": {"from": first_external, "to": first_checking},
    "Transfer": {"from": first_checking, "to": first_savings or first_checking},
    "Debt Payment": {"from": first_checking, "to": first_cc or first_external},
    "Interest": {"from": first_cc or first_external, "to": first_external},
    "Reconciliation": {"from": first_checking, "to": first_external},
}

# ---------------------------------------------------------------------------
# Tabs
# ---------------------------------------------------------------------------
tab_add, tab_browse = st.tabs(["Add Transaction", "Browse Transactions"])

# ===========================================================================
# Tab 1 — Add Transaction
# ===========================================================================
with tab_add:
    if "add_tx_type" not in st.session_state:
        st.session_state["add_tx_type"] = "Expense"

    def _type_changed() -> None:
        st.session_state["add_tx_type"] = st.session_state["_add_type_select"]

    with st.form("add_transaction_form"):
        col_left, col_right = st.columns(2)

        with col_left:
            tx_date = st.date_input("Date", value=date.today())
            description = st.text_input("Description")
            amount_usd = st.number_input(
                "Amount (USD)",
                min_value=0.00,
                step=0.01,
                format="%.2f",
                value=0.00,
            )

        with col_right:
            selected_type = st.session_state["add_tx_type"]
            defaults = TYPE_DEFAULTS.get(selected_type, TYPE_DEFAULTS["Expense"])

            tx_type = st.selectbox(
                "Type",
                options=TRANSACTION_TYPES,
                index=TRANSACTION_TYPES.index(selected_type) if selected_type in TRANSACTION_TYPES else 0,
                key="_add_type_select",
            )

            from_default = defaults["from"]
            to_default = defaults["to"]
            from_idx = account_names.index(from_default) if from_default in account_names else 0
            to_idx = account_names.index(to_default) if to_default in account_names else 0

            from_account = st.selectbox("From Account", options=account_names, index=from_idx)
            to_account = st.selectbox("To Account", options=account_names, index=to_idx)
            category = st.selectbox("Category", options=category_names)

        notes = st.text_input("Notes (optional)")

        submitted = st.form_submit_button("Add Transaction", type="primary")

    if tx_type != st.session_state["add_tx_type"]:
        st.session_state["add_tx_type"] = tx_type

    if submitted:
        if not description.strip():
            st.error("Description is required.")
        else:
            try:
                backup()
                tx_id = add_transaction(
                    conn,
                    date=tx_date.isoformat(),
                    description=description.strip(),
                    amount_usd=amount_usd,
                    type=tx_type,
                    from_account=from_account,
                    to_account=to_account,
                    category=category,
                    notes=notes.strip() if notes.strip() else None,
                )
                st.cache_data.clear()
                st.success(f"Added transaction #{tx_id}: {description.strip()} {fmt_usd(amount_usd)}")
            except Exception as e:
                st.error(str(e))

# ===========================================================================
# Tab 2 — Browse Transactions
# ===========================================================================
with tab_browse:
    # -----------------------------------------------------------------------
    # Filters
    # -----------------------------------------------------------------------
    with st.expander("Filters", expanded=True):
        f_col1, f_col2 = st.columns(2)
        with f_col1:
            f_start = st.date_input("Start Date", value=None, key="f_start")
        with f_col2:
            f_end = st.date_input("End Date", value=None, key="f_end")

        f_col3, f_col4, f_col5 = st.columns(3)
        with f_col3:
            f_account = st.selectbox("Account", options=["All"] + account_names, key="f_account")
        with f_col4:
            f_category = st.selectbox("Category", options=["All"] + category_names, key="f_category")
        with f_col5:
            f_type = st.selectbox("Type", options=["All"] + list(TRANSACTION_TYPES), key="f_type")

        f_col6, f_col7 = st.columns([2, 1])
        with f_col6:
            f_desc = st.text_input("Description search", key="f_desc")
        with f_col7:
            f_limit = st.number_input("Limit", min_value=1, max_value=1000, value=750, key="f_limit")

    filter_kwargs: dict = {"limit": int(f_limit)}
    if f_start:
        filter_kwargs["start_date"] = f_start.isoformat()
    if f_end:
        filter_kwargs["end_date"] = f_end.isoformat()
    if f_account != "All":
        filter_kwargs["account"] = f_account
    if f_category != "All":
        filter_kwargs["category"] = f_category
    if f_type != "All":
        filter_kwargs["type"] = f_type
    if f_desc.strip():
        filter_kwargs["description"] = f_desc.strip()

    txns = list_transactions(conn, **filter_kwargs)

    # -----------------------------------------------------------------------
    # Results table
    # -----------------------------------------------------------------------
    st.subheader(f"Results ({len(txns)} transaction{'s' if len(txns) != 1 else ''})")

    if txns:
        display_rows = [
            {
                "ID": t["id"],
                "Date": t["date"],
                "Description": t["description"],
                "Amount": fmt_usd(t["amount_usd"]),
                "Type": t["type"],
                "From": t["from_account"],
                "To": t["to_account"],
                "Category": t["category"],
                "Notes": t["notes"] or "",
            }
            for t in txns
        ]
        st.dataframe(
            display_rows,
            use_container_width=True,
            hide_index=True,
            column_config={
                "ID": st.column_config.NumberColumn("ID", width="small"),
                "Date": st.column_config.TextColumn("Date", width="small"),
                "Description": st.column_config.TextColumn("Description", width="medium"),
                "Amount": st.column_config.TextColumn("Amount", width="small"),
                "Type": st.column_config.TextColumn("Type", width="small"),
                "From": st.column_config.TextColumn("From", width="medium"),
                "To": st.column_config.TextColumn("To", width="medium"),
                "Category": st.column_config.TextColumn("Category", width="medium"),
                "Notes": st.column_config.TextColumn("Notes", width="medium"),
            },
        )
    else:
        st.info("No transactions match the current filters.")

    # -----------------------------------------------------------------------
    # Edit / Delete
    # -----------------------------------------------------------------------
    with st.expander("Edit or Delete Transaction"):
        if "edit_tx" not in st.session_state:
            st.session_state["edit_tx"] = None

        load_col, _ = st.columns([1, 3])
        with load_col:
            edit_id = st.number_input(
                "Transaction ID",
                min_value=1,
                step=1,
                value=1,
                key="edit_tx_id_input",
            )
            load_btn = st.button("Load Transaction")

        if load_btn:
            result = conn.execute("SELECT * FROM transactions WHERE id = ?", (int(edit_id),)).fetchone()
            if result:
                st.session_state["edit_tx"] = dict(result)
            else:
                st.session_state["edit_tx"] = None
                st.warning(f"No transaction found with ID {edit_id}.")

        loaded = st.session_state.get("edit_tx")

        if loaded:
            st.caption(f"Editing transaction #{loaded['id']}: {loaded['description']}")

            with st.form("edit_transaction_form"):
                e_col1, e_col2 = st.columns(2)

                with e_col1:
                    e_date = st.date_input(
                        "Date",
                        value=date.fromisoformat(loaded["date"]),
                        key="e_date",
                    )
                    e_desc = st.text_input("Description", value=loaded["description"], key="e_desc")
                    e_amount = st.number_input(
                        "Amount (USD)",
                        min_value=0.01,
                        step=0.01,
                        format="%.2f",
                        value=float(loaded["amount_usd"]),
                        key="e_amount",
                    )

                with e_col2:
                    e_type = st.selectbox(
                        "Type",
                        options=TRANSACTION_TYPES,
                        index=TRANSACTION_TYPES.index(loaded["type"]) if loaded["type"] in TRANSACTION_TYPES else 0,
                        key="e_type",
                    )
                    from_idx_e = account_names.index(loaded["from_account"]) if loaded["from_account"] in account_names else 0
                    to_idx_e = account_names.index(loaded["to_account"]) if loaded["to_account"] in account_names else 0
                    e_from = st.selectbox("From Account", options=account_names, index=from_idx_e, key="e_from")
                    e_to = st.selectbox("To Account", options=account_names, index=to_idx_e, key="e_to")
                    cat_idx_e = category_names.index(loaded["category"]) if loaded["category"] in category_names else 0
                    e_category = st.selectbox("Category", options=category_names, index=cat_idx_e, key="e_category")

                e_notes = st.text_input("Notes", value=loaded["notes"] or "", key="e_notes")

                update_btn, delete_btn = st.columns(2)
                with update_btn:
                    do_update = st.form_submit_button("Update Transaction", type="primary")
                with delete_btn:
                    do_delete = st.form_submit_button("Delete Transaction", type="secondary")

            if do_update:
                if not e_desc.strip():
                    st.error("Description is required.")
                else:
                    try:
                        backup()
                        update_transaction(
                            conn,
                            loaded["id"],
                            date=e_date.isoformat(),
                            description=e_desc.strip(),
                            amount_usd=e_amount,
                            type=e_type,
                            from_account=e_from,
                            to_account=e_to,
                            category=e_category,
                            notes=e_notes.strip() if e_notes.strip() else None,
                        )
                        st.cache_data.clear()
                        st.session_state["edit_tx"] = None
                        st.success(f"Transaction #{loaded['id']} updated.")
                    except Exception as e:
                        st.error(str(e))

            if do_delete:
                st.warning(
                    f"Are you sure you want to delete transaction #{loaded['id']}: "
                    f"{loaded['description']} {fmt_usd(loaded['amount_usd'])}? "
                    "This cannot be undone. Click Delete again to confirm."
                )
                if "confirm_delete_id" not in st.session_state:
                    st.session_state["confirm_delete_id"] = None

                if st.session_state.get("confirm_delete_id") == loaded["id"]:
                    try:
                        backup()
                        delete_transaction(conn, loaded["id"])
                        st.cache_data.clear()
                        st.session_state["edit_tx"] = None
                        st.session_state["confirm_delete_id"] = None
                        st.success(f"Transaction #{loaded['id']} deleted.")
                    except Exception as e:
                        st.error(str(e))
                else:
                    st.session_state["confirm_delete_id"] = loaded["id"]
                    st.rerun()
