"""Spending Analysis page — category breakdowns, account usage, budget alerts."""

from __future__ import annotations

import calendar

import pandas as pd
import plotly.express as px
import streamlit as st

from spendctl.dashboard.helpers import (
    COLORS,
    fmt_usd,
    get_conn,
    month_selector,
)
from spendctl.queries.budget import budget_vs_actual
from spendctl.queries.reports import (
    monthly_summary,
    spending_by_account,
    spending_by_category,
)

st.set_page_config(page_title="Spending — spendctl", layout="wide", page_icon="💰")
st.title("Spending Analysis")

conn = get_conn()

# ── Month selector ────────────────────────────────────────────────────────────

selected_month = month_selector(conn, key="spending_month")

# ── Date range for the selected month ─────────────────────────────────────────

year_int = int(selected_month[:4])
month_int = int(selected_month[5:7])
last_day = calendar.monthrange(year_int, month_int)[1]
start_date = f"{selected_month}-01"
end_date = f"{selected_month}-{last_day:02d}"

# ── Load data ──────────────────────────────────────────────────────────────────

cats = spending_by_category(conn, start_date=start_date, end_date=end_date)
accts = spending_by_account(conn, start_date=start_date, end_date=end_date)
bva = budget_vs_actual(conn, month=selected_month)
summary = monthly_summary(conn, month=selected_month)

# ── Row 1: Metric cards ───────────────────────────────────────────────────────

total_spending = summary["total_expenses"]
budgeted_total = sum(row["budgeted"] for row in bva)
over_under = budgeted_total - total_spending

col1, col2, col3 = st.columns(3)

with col1:
    st.metric("Total Spending", fmt_usd(total_spending))

with col2:
    st.metric("Budgeted Total", fmt_usd(budgeted_total))

with col3:
    st.metric(
        "Over / Under Budget",
        fmt_usd(abs(over_under)),
        delta=f"{'Under' if over_under >= 0 else 'Over'} by {fmt_usd(abs(over_under))}",
        delta_color="normal" if over_under >= 0 else "inverse",
    )

st.divider()

# ── Row 2: Category pie + bar ─────────────────────────────────────────────────

col_left, col_right = st.columns(2)

with col_left:
    st.subheader("Spending by Category")
    if cats:
        df_cats = pd.DataFrame(cats)
        fig_pie = px.pie(
            df_cats,
            names="category",
            values="total",
            hole=0.35,
            color_discrete_sequence=px.colors.qualitative.Set2,
        )
        fig_pie.update_traces(
            textposition="inside",
            textinfo="percent+label",
            hovertemplate="<b>%{label}</b><br>$%{value:,.2f}<br>%{percent}<extra></extra>",
        )
        fig_pie.update_layout(
            showlegend=False,
            margin={"t": 20, "b": 20, "l": 20, "r": 20},
        )
        st.plotly_chart(fig_pie, use_container_width=True)
    else:
        st.info("No expense transactions for this month.")

with col_right:
    st.subheader("Category Totals")
    if cats:
        df_cats_bar = pd.DataFrame(cats).sort_values("total", ascending=True)
        fig_bar = px.bar(
            df_cats_bar,
            x="total",
            y="category",
            orientation="h",
            text=df_cats_bar["total"].apply(fmt_usd),
            color="total",
            color_continuous_scale=["#3498db", "#e74c3c"],
        )
        fig_bar.update_traces(
            textposition="outside",
            hovertemplate="<b>%{y}</b><br>%{x:$,.2f}<extra></extra>",
        )
        fig_bar.update_layout(
            xaxis_title="Amount (USD)",
            yaxis_title=None,
            coloraxis_showscale=False,
            margin={"t": 20, "b": 20, "l": 20, "r": 80},
        )
        st.plotly_chart(fig_bar, use_container_width=True)
    else:
        st.info("No expense transactions for this month.")

st.divider()

# ── Row 3: Budget Alerts (over-budget categories only) ───────────────────────

st.subheader("Budget Alerts")

over_budget = [r for r in bva if r["budgeted"] > 0 and r["actual"] > r["budgeted"]]
over_budget.sort(key=lambda r: r["difference"])

if over_budget:
    for item in over_budget:
        overage = abs(item["difference"])
        overage_pct = (overage / item["budgeted"] * 100) if item["budgeted"] > 0 else 0
        color = COLORS["red"]

        st.markdown(
            f"""<div style="
                border-left: 4px solid {color};
                padding: 10px 16px;
                margin-bottom: 8px;
                background: #2c1a1a;
                border-radius: 4px;
            ">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="font-size: 1rem; font-weight: 600;">{item["category"]}</span>
                    <span style="font-size: 0.9rem; color: {color}; font-weight: 600;">
                        {fmt_usd(overage)} over ({overage_pct:.0f}%)
                    </span>
                </div>
                <div style="font-size: 0.85rem; color: #aaa; margin-top: 4px;">
                    Budget: {fmt_usd(item["budgeted"])} — Spent: {fmt_usd(item["actual"])} ({item["tx_count"]} transactions)
                </div>
            </div>""",
            unsafe_allow_html=True,
        )
else:
    st.success("All budgeted categories are within budget this month.")

st.divider()

# ── Row 4: Spending by Account ────────────────────────────────────────────────

st.subheader("Spending by Account")
if accts:
    df_accts = pd.DataFrame(accts)
    fig_acct_pie = px.pie(
        df_accts,
        names="account",
        values="total",
        hole=0.35,
        color_discrete_sequence=px.colors.qualitative.Pastel,
    )
    fig_acct_pie.update_traces(
        textposition="inside",
        textinfo="percent+label+value",
        texttemplate="%{label}<br>%{percent}<br>$%{value:,.2f}",
        hovertemplate="<b>%{label}</b><br>$%{value:,.2f}<br>%{percent}<extra></extra>",
    )
    fig_acct_pie.update_layout(
        showlegend=False,
        margin={"t": 20, "b": 20, "l": 20, "r": 20},
        height=350,
    )
    st.plotly_chart(fig_acct_pie, use_container_width=True)
else:
    st.info("No account data for this month.")
