"""Debt Tracking page — progress, payment history, and payoff projections."""

from __future__ import annotations

from datetime import date, timedelta

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from spendctl import config
from spendctl.dashboard.helpers import (
    COLORS,
    MONTH_NAMES,
    auto_assign_colors,
    fmt_pct,
    fmt_usd,
    get_conn,
    hex_to_rgba,
    months_to_payoff,
)
from spendctl.queries.dashboard import debt_progress
from spendctl.queries.transactions import list_transactions

st.set_page_config(page_title="Debt — spendctl", layout="wide", page_icon="💰")
st.title("Debt Tracking")

# ── Load data ──────────────────────────────────────────────────────────────────

conn = get_conn()
accounts = config.get_accounts()
student_loan_accounts = config.get_student_loan_accounts()
min_payments = config.get_min_payments()

dp = debt_progress(conn)
# Separate active paydown debts from student loans
dp_active = {k: v for k, v in dp.items() if not k.startswith("_") and k not in student_loan_accounts}
dp_all = {k: v for k, v in dp.items() if not k.startswith("_")}

# Auto-assign colors to all debt accounts
debt_colors = auto_assign_colors(list(dp_all.keys()))

payments = list_transactions(conn, type="Debt Payment", limit=1000)

# ── Row 1: Metric cards ───────────────────────────────────────────────────────

total_current_all = sum(v["current_balance"] for v in dp_all.values())
total_paid_active = sum(v["amount_paid"] for v in dp_active.values())
total_starting_active = sum(v["starting_balance"] for v in dp_active.values())
overall_progress = (total_paid_active / total_starting_active * 100) if total_starting_active else 0.0

col1, col2, col3 = st.columns(3)

with col1:
    sl_balance = sum(v["current_balance"] for k, v in dp_all.items() if k in student_loan_accounts)
    active_balance = total_current_all - sl_balance
    st.metric(
        "Total Debt",
        fmt_usd(total_current_all),
        delta=f"Active: {fmt_usd(active_balance)} + Student Loans: {fmt_usd(sl_balance)}",
        delta_color="off",
    )

with col2:
    st.metric("Paid (Active Debts)", fmt_usd(total_paid_active))

with col3:
    st.metric("Paydown Progress", fmt_pct(overall_progress))

st.divider()

# ── Row 2: Debt progress horizontal bar (active debts only) ──────────────────

st.subheader("Debt Progress by Account")

if dp_active:
    accounts_list = list(dp_active.keys())
    starting_balances = [dp_active[a]["starting_balance"] for a in accounts_list]
    current_balances = [dp_active[a]["current_balance"] for a in accounts_list]
    amounts_paid = [dp_active[a]["amount_paid"] for a in accounts_list]
    progress_pcts = [dp_active[a]["progress_pct"] for a in accounts_list]

    fig_progress = go.Figure()

    fig_progress.add_trace(
        go.Bar(
            y=accounts_list,
            x=starting_balances,
            name="Starting Balance",
            orientation="h",
            marker_color=[
                hex_to_rgba(debt_colors.get(a, COLORS["gray"]), 0.3)
                for a in accounts_list
            ],
            hovertemplate="<b>%{y}</b><br>Starting: $%{x:,.2f}<extra></extra>",
        )
    )

    fig_progress.add_trace(
        go.Bar(
            y=accounts_list,
            x=current_balances,
            name="Current Balance",
            orientation="h",
            marker_color=[debt_colors.get(a, COLORS["gray"]) for a in accounts_list],
            text=[f"{fmt_usd(amounts_paid[i])} paid ({fmt_pct(progress_pcts[i])})" for i in range(len(accounts_list))],
            textposition="outside",
            hovertemplate="<b>%{y}</b><br>Current: $%{x:,.2f}<extra></extra>",
        )
    )

    fig_progress.update_layout(
        barmode="overlay",
        xaxis_title="Balance (USD)",
        yaxis_title=None,
        legend={"orientation": "h", "yanchor": "bottom", "y": 1.02, "xanchor": "right", "x": 1},
        margin={"t": 40, "b": 20, "l": 20, "r": 200},
        height=max(300, len(accounts_list) * 70),
    )
    st.plotly_chart(fig_progress, use_container_width=True)
else:
    st.info("No active debt account data available.")

st.divider()

# ── Row 3: Payment history + debt composition ─────────────────────────────────

col_hist, col_comp = st.columns(2)

with col_hist:
    st.subheader("Payment History")
    if payments:
        df_payments = pd.DataFrame(payments)
        df_payments["month"] = df_payments["date"].str[:7]
        df_monthly = df_payments.groupby("month")["amount_usd"].sum().reset_index().sort_values("month")
        df_monthly.columns = ["Month", "Total Paid"]

        df_monthly["Month Label"] = df_monthly["Month"].apply(lambda m: f"{MONTH_NAMES[int(m[5:7]) - 1]} {m[:4]}")

        fig_hist = px.bar(
            df_monthly,
            x="Month Label",
            y="Total Paid",
            text=df_monthly["Total Paid"].apply(fmt_usd),
            color_discrete_sequence=[COLORS["blue"]],
        )
        fig_hist.update_traces(
            textposition="outside",
            hovertemplate="<b>%{x}</b><br>Paid: $%{y:,.2f}<extra></extra>",
        )
        fig_hist.update_layout(
            xaxis_title=None,
            xaxis_type="category",
            yaxis_title="Amount (USD)",
            yaxis_tickformat="$,.0f",
            margin={"t": 20, "b": 20, "l": 20, "r": 20},
        )
        st.plotly_chart(fig_hist, use_container_width=True)
    else:
        st.info("No debt payment transactions found.")

with col_comp:
    st.subheader("Debt Composition (Current)")
    if dp_active:
        active_debts_comp = {k: v for k, v in dp_active.items() if v["current_balance"] > 0}
        if active_debts_comp:
            df_comp = pd.DataFrame([{"account": acct, "balance": data["current_balance"]} for acct, data in active_debts_comp.items()])
            account_color_map = {a: debt_colors.get(a, COLORS["gray"]) for a in df_comp["account"]}
            fig_comp = px.pie(
                df_comp,
                names="account",
                values="balance",
                hole=0.35,
                color="account",
                color_discrete_map=account_color_map,
            )
            fig_comp.update_traces(
                textposition="inside",
                textinfo="percent+label",
                hovertemplate="<b>%{label}</b><br>$%{value:,.2f}<br>%{percent}<extra></extra>",
            )
            fig_comp.update_layout(
                showlegend=False,
                margin={"t": 20, "b": 20, "l": 20, "r": 20},
            )
            st.plotly_chart(fig_comp, use_container_width=True)
        else:
            st.success("All active debts paid off!")
    else:
        st.info("No debt account data available.")

st.divider()

# ── Row 4: Projected payoff with comparison line charts ───────────────────────

st.subheader("Projected Payoff")


def _build_payoff_curve(balance, apr, monthly_payment, max_months=120):
    """Build month-by-month balance curve for a given payment amount."""
    monthly_rate = apr / 100 / 12
    balances = [balance]
    for _ in range(max_months):
        interest = balances[-1] * monthly_rate
        new_balance = balances[-1] + interest - monthly_payment
        if new_balance <= 0:
            balances.append(0)
            break
        balances.append(new_balance)
    return balances


if dp_active and payments:
    df_payments_all = pd.DataFrame(payments)

    def _avg_monthly_payment(account_name: str) -> float:
        acct_payments = df_payments_all[df_payments_all["to_account"] == account_name]
        if acct_payments.empty:
            return 0.0
        acct_payments = acct_payments.copy()
        acct_payments["month"] = acct_payments["date"].str[:7]
        monthly_totals = acct_payments.groupby("month")["amount_usd"].sum()
        return float(monthly_totals.mean()) if not monthly_totals.empty else 0.0

    active_debts = {k: v for k, v in dp_active.items() if v["current_balance"] > 0}

    if active_debts:
        today = date.today()

        debt_cards = []
        for acct_name, data in active_debts.items():
            acct_info = accounts.get(acct_name, {})
            apr = acct_info.get("apr") or 0.0
            avg_payment = _avg_monthly_payment(acct_name)
            current_balance = data["current_balance"]
            min_payment = min_payments.get(acct_name, 25.0)
            color = debt_colors.get(acct_name, COLORS["gray"])

            card = {
                "name": acct_name,
                "apr": apr,
                "avg_payment": avg_payment,
                "balance": current_balance,
                "min_payment": min_payment,
                "color": color,
            }

            if avg_payment > 0:
                card["aggressive_curve"] = _build_payoff_curve(current_balance, apr, avg_payment)
                card["minimum_curve"] = _build_payoff_curve(current_balance, apr, min_payment)
                card["months_aggressive"] = months_to_payoff(current_balance, apr, avg_payment)
                card["months_minimum"] = months_to_payoff(current_balance, apr, min_payment)

                if card["months_aggressive"] and card["months_aggressive"] > 0:
                    payoff_date = today + timedelta(days=card["months_aggressive"] * 30)
                    card["payoff_str"] = payoff_date.strftime("%B %Y")
                else:
                    card["payoff_str"] = "Already paid off"

                ma, mm = card["months_aggressive"], card["months_minimum"]
                if mm and ma and mm > ma:
                    interest_min = min_payment * mm - current_balance
                    interest_agg = avg_payment * ma - current_balance
                    card["savings_str"] = (
                        f"Saving ~{fmt_usd(max(interest_min - interest_agg, 0))} in interest and {mm - ma} months vs minimum"
                    )
            debt_cards.append(card)

        cols = st.columns(len(debt_cards))

        for i, card in enumerate(debt_cards):
            with cols[i]:
                color = card["color"]
                acct_name = card["name"]

                if card.get("avg_payment", 0) <= 0:
                    st.markdown(
                        f"""<div style="border-left: 4px solid {color}; padding: 10px 14px; margin-bottom: 8px;
                        background: #1e2329; border-radius: 4px;">
                        <div style="font-size: 0.95rem; font-weight: 600;">{acct_name}</div>
                        <div style="font-size: 0.8rem; color: #aaa;">{fmt_usd(card["balance"])} — No payment history</div>
                        </div>""",
                        unsafe_allow_html=True,
                    )
                    continue

                months_agg = card.get("months_aggressive")
                st.markdown(
                    f"""<div style="border-left: 4px solid {color}; padding: 10px 14px; margin-bottom: 4px;
                    background: #1e2329; border-radius: 4px;">
                    <div style="font-size: 0.95rem; font-weight: 600; margin-bottom: 4px;">{acct_name}</div>
                    <div style="font-size: 0.8rem; color: #aaa;">
                        {fmt_usd(card["balance"])} @ {card["apr"]:.1f}% APR
                    </div>
                    <div style="font-size: 0.8rem; color: #aaa;">
                        Payment: {fmt_usd(card["avg_payment"])}/mo
                    </div>
                    <div style="font-size: 0.8rem; color: #aaa;">
                        Payoff: <strong style="color: {color};">{card["payoff_str"]}</strong>
                        {f" ({months_agg} mo)" if isinstance(months_agg, int) and months_agg > 0 else ""}
                    </div>
                    {f'<div style="font-size: 0.75rem; color: {COLORS["green"]}; margin-top: 4px;">{card["savings_str"]}</div>' if card.get("savings_str") else ""}
                    </div>""",
                    unsafe_allow_html=True,
                )

                aggressive_curve = card["aggressive_curve"]
                minimum_curve = card["minimum_curve"]
                max_len = max(len(aggressive_curve), len(minimum_curve))
                agg_padded = aggressive_curve + [0] * (max_len - len(aggressive_curve))
                min_padded = minimum_curve[:max_len]
                labels = [(today + timedelta(days=j * 30)).strftime("%b %y") for j in range(max_len)]

                fig = go.Figure()
                fig.add_trace(
                    go.Scatter(
                        x=labels,
                        y=min_padded,
                        mode="lines",
                        name="Min Payments",
                        line={"color": COLORS["red"], "width": 1.5, "dash": "dash"},
                        fill="tozeroy",
                        fillcolor="rgba(231, 76, 60, 0.05)",
                    )
                )
                fig.add_trace(
                    go.Scatter(
                        x=labels,
                        y=agg_padded,
                        mode="lines",
                        name="Your Payments",
                        line={"color": color, "width": 2.5},
                        fill="tozeroy",
                        fillcolor=hex_to_rgba(color, 0.1),
                    )
                )

                tick_interval = max(1, max_len // 5)
                fig.update_layout(
                    yaxis_tickformat="$,.0f",
                    xaxis={"tickmode": "array", "tickvals": labels[::tick_interval], "tickangle": -45, "tickfont": {"size": 9}},
                    yaxis={"tickfont": {"size": 9}},
                    legend={"orientation": "h", "y": 1.1, "font": {"size": 9}},
                    height=220,
                    margin={"t": 25, "b": 35, "l": 5, "r": 5},
                )
                st.plotly_chart(fig, use_container_width=True)

    else:
        st.success("All active debts paid off!")
elif not dp_active:
    st.info("No active debt account data available.")
else:
    st.info("No payment history found. Payoff projections require at least one Debt Payment transaction.")
