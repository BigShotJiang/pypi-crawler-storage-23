"""Shared utilities for all dashboard pages."""

from __future__ import annotations

import math
from datetime import date

import streamlit as st

from spendctl.db import ensure_db


@st.cache_resource
def get_conn():
    """Cached database connection. One per Streamlit server process."""
    return ensure_db()


def fmt_usd(amount: float) -> str:
    """Format as $1,234.56 or -$1,234.56"""
    if amount < 0:
        return f"-${abs(amount):,.2f}"
    return f"${amount:,.2f}"


def fmt_pct(pct: float) -> str:
    return f"{pct:.1f}%"


def months_to_payoff(balance: float, apr: float, monthly_payment: float) -> int | None:
    """Estimate months to pay off a debt at current payment rate."""
    if balance <= 0 or monthly_payment <= 0:
        return 0
    monthly_rate = apr / 100 / 12
    if monthly_rate == 0:
        return math.ceil(balance / monthly_payment)
    if monthly_payment <= balance * monthly_rate:
        return None
    months = -math.log(1 - (balance * monthly_rate / monthly_payment)) / math.log(1 + monthly_rate)
    return math.ceil(months)


# Color palette
COLORS = {
    "green": "#2ecc71",
    "red": "#e74c3c",
    "blue": "#3498db",
    "orange": "#f39c12",
    "purple": "#9b59b6",
    "gray": "#95a5a6",
    "dark": "#2c3e50",
}

# Color palette for auto-assignment
COLOR_PALETTE = [
    "#e74c3c",
    "#3498db",
    "#f39c12",
    "#9b59b6",
    "#95a5a6",
    "#1abc9c",
    "#e67e22",
    "#2ecc71",
    "#d35400",
    "#8e44ad",
]


def auto_assign_colors(names: list[str]) -> dict[str, str]:
    """Assign colors from palette to a list of names, cycling if needed."""
    return {name: COLOR_PALETTE[i % len(COLOR_PALETTE)] for i, name in enumerate(names)}


# ── Month formatting ──────────────────────────────────────────────────────

MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def fmt_month(ym: str) -> str:
    """Convert '2026-02' to 'Feb 2026'."""
    y, m = ym.split("-")
    return f"{MONTH_NAMES[int(m) - 1]} {y}"


def month_selector(conn, *, key: str = "month", label: str = "Month") -> str:
    """Render a month selectbox and return the selected YYYY-MM string."""
    rows = conn.execute(
        "SELECT DISTINCT strftime('%Y-%m', date) AS month FROM transactions ORDER BY month"
    ).fetchall()
    month_keys = [r["month"] for r in rows]
    current = date.today().strftime("%Y-%m")
    if current not in month_keys:
        month_keys.append(current)
    month_keys.sort(reverse=True)

    idx = st.selectbox(
        label,
        options=range(len(month_keys)),
        index=0,
        format_func=lambda i: fmt_month(month_keys[i]),
        key=key,
    )
    return month_keys[idx]


def hex_to_rgba(hex_color: str, alpha: float = 0.1) -> str:
    """Convert '#2ecc71' to 'rgba(46, 204, 113, 0.1)'."""
    r = int(hex_color[1:3], 16)
    g = int(hex_color[3:5], 16)
    b = int(hex_color[5:7], 16)
    return f"rgba({r}, {g}, {b}, {alpha})"
