"""spendctl Dashboard — entry point.

Sets global page config and redirects to the main Dashboard page.
All pages live in pages/ and appear automatically in the sidebar.
"""

import streamlit as st

st.set_page_config(
    page_title="spendctl Dashboard",
    page_icon="💰",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.switch_page("pages/1_dashboard.py")
