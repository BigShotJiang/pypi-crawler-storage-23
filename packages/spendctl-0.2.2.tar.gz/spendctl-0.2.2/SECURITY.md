# Security Policy

## Reporting a Vulnerability

If you discover a security vulnerability in this project, please report it responsibly.

**Do not open a public issue for security vulnerabilities.**

Instead, please use GitHub's private vulnerability reporting feature:

1. Go to the [Security tab](https://github.com/Jscoats/spendctl/security)
2. Click "Report a vulnerability"
3. Provide details about the issue

## What to Include

- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if any)

## Response

You can expect an initial response within 7 days. We will work with you to understand and address the issue before any public disclosure.

## Scope

This project runs locally and stores personal financial data in a local SQLite database. Security concerns most likely relate to:

- Unsafe handling of user-supplied data (SQL injection, path traversal)
- Exposure of financial data via config files or database backups
- Insecure permissions on the config directory (`~/.config/spendctl/`)
