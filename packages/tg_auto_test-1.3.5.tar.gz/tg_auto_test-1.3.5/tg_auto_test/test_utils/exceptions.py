class BotNoResponseError(Exception):
    """Raised when the bot does not produce a message response to an update."""
