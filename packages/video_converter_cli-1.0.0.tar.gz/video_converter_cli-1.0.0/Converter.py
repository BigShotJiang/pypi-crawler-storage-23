#!/usr/bin/env python3
"""
Video and Image Converter
Converts between video and image formats using FFmpeg and Pillow.
"""

import subprocess
import argparse
import sys
from pathlib import Path
from typing import Optional

try:
    from PIL import Image
except ImportError:
    Image = None


# Supported video formats
VIDEO_FORMATS = {'.avi', '.mp4', '.mov', '.mkv', '.webm', '.flv', '.wmv', '.m4v'}
# Supported image formats
IMAGE_FORMATS = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif', '.webp', '.gif'}


def convert_video(input_path: str, output_path: Optional[str] = None,
                  quality: str = "medium", crf: int = 22) -> str:
    """
    Convert a video to another format using FFmpeg.
    """
    inp = Path(input_path)

    if not inp.exists():
        raise FileNotFoundError(f"File not found: {input_path}")

    if inp.suffix.lower() not in VIDEO_FORMATS:
        raise ValueError(f"Unsupported video format: {inp.suffix}")

    if output_path is None:
        out = inp.with_suffix(".mp4")
    else:
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)

    cmd = [
        "ffmpeg", "-y", "-i", str(inp),
        "-c:v", "libx264", "-preset", quality, "-crf", str(crf),
        "-c:a", "aac", "-b:a", "192k",
        "-movflags", "+faststart",
        str(out)
    ]

    print(f"Converting video: {inp.name} -> {out.name}")
    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.returncode != 0:
        raise RuntimeError(f"FFmpeg failed:\n{result.stderr}")

    print(f"✓ Video converted successfully: {out}")
    return str(out)


def convert_image(input_path: str, output_path: Optional[str] = None,
                  format: Optional[str] = None) -> str:
    """
    Convert an image to another format using Pillow.
    """
    if Image is None:
        raise ImportError("Pillow is not installed. Install with: pip install Pillow")

    inp = Path(input_path)

    if not inp.exists():
        raise FileNotFoundError(f"File not found: {input_path}")

    if inp.suffix.lower() not in IMAGE_FORMATS:
        raise ValueError(f"Unsupported image format: {inp.suffix}")

    if output_path is None:
        if inp.suffix.lower() in {'.jpg', '.jpeg'}:
            out = inp.with_suffix(".png")
            output_format = "PNG"
        else:
            out = inp.with_suffix(".jpg")
            output_format = "JPEG"
    else:
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        if format:
            output_format = format.upper()
        else:
            ext = out.suffix.lower()
            format_map = {
                '.png': 'PNG',
                '.jpg': 'JPEG',
                '.jpeg': 'JPEG',
                '.bmp': 'BMP',
                '.tiff': 'TIFF',
                '.tif': 'TIFF',
                '.webp': 'WEBP',
                '.gif': 'GIF'
            }
            output_format = format_map.get(ext, 'PNG')

    print(f"Converting image: {inp.name} -> {out.name} ({output_format})")

    try:
        with Image.open(inp) as img:
            if output_format == 'JPEG' and img.mode in ('RGBA', 'LA', 'P'):
                rgb_img = Image.new('RGB', img.size, (255, 255, 255))
                if img.mode == 'P':
                    img = img.convert('RGBA')
                rgb_img.paste(img, mask=img.split()[-1] if img.mode == 'RGBA' else None)
                img = rgb_img
            elif output_format == 'JPEG' and img.mode != 'RGB':
                img = img.convert('RGB')

            img.save(out, format=output_format, quality=95)

        print(f"✓ Image converted successfully: {out}")
        return str(out)
    except Exception as e:
        raise RuntimeError(f"Error converting image: {str(e)}")


def detect_file_type(file_path: Path) -> str:
    """Detect whether a file is video or image by extension."""
    ext = file_path.suffix.lower()
    if ext in VIDEO_FORMATS:
        return "video"
    elif ext in IMAGE_FORMATS:
        return "image"
    else:
        return "unknown"


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="converter",
        description="Convert videos and images between formats. Videos require FFmpeg; images use Pillow (included). Developed by L3CHUGU1T4.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
INPUT FILES
  One or more video or image files. Formats are detected by extension.

  Video: .avi .mp4 .mov .mkv .webm .flv .wmv .m4v
  Image: .jpg .jpeg .png .bmp .tiff .tif .webp .gif

OUTPUT
  If -o/--output is omitted:
    • Videos are written as <name>.mp4 in the same directory.
    • JPEG/JPG → <name>.png; other images → <name>.jpg

  Use -o/--output to set an explicit output path (only when converting a single file).

VIDEO OPTIONS
  --quality   Encoding speed vs compression: ultrafast | fast | medium | slow | veryslow (default: medium).
  --crf       Quality (18–28). Lower = better quality, larger file (default: 22).

EXAMPLES
  converter video.avi
  converter video.avi -o output.mov
  converter image.jpg
  converter image.png -o output.jpg
  converter video.avi --quality slow --crf 18
  converter file1.avi file2.jpg file3.png

  Developed by L3CHUGU1T4
        """,
    )

    parser.add_argument(
        "files",
        nargs="+",
        help="One or more files to convert (paths to video or image files)",
    )

    parser.add_argument(
        "-o", "--output",
        metavar="PATH",
        help="Output file path (allowed only when converting a single file)",
    )

    parser.add_argument(
        "--quality",
        choices=["ultrafast", "fast", "medium", "slow", "veryslow"],
        default="medium",
        help="Video encoding preset: faster encoding = larger file (default: medium)",
    )

    parser.add_argument(
        "--crf",
        type=int,
        default=22,
        metavar="N",
        help="Video quality constant, 18–28; lower = better quality (default: 22)",
    )

    args = parser.parse_args()

    if args.output and len(args.files) > 1:
        parser.error("--output may only be used when converting a single file")

    success_count = 0
    error_count = 0

    for file_path in args.files:
        try:
            inp = Path(file_path)
            file_type = detect_file_type(inp)

            if file_type == "video":
                convert_video(
                    str(inp),
                    args.output if args.output else None,
                    quality=args.quality,
                    crf=args.crf
                )
                success_count += 1
            elif file_type == "image":
                convert_image(
                    str(inp),
                    args.output if args.output else None
                )
                success_count += 1
            else:
                print(f"✗ Unsupported format: {inp.name} (extension: {inp.suffix})")
                error_count += 1

        except FileNotFoundError as e:
            print(f"✗ Error: {e}")
            error_count += 1
        except ValueError as e:
            print(f"✗ Error: {e}")
            error_count += 1
        except RuntimeError as e:
            print(f"✗ Error: {e}")
            error_count += 1
        except Exception as e:
            print(f"✗ Unexpected error processing {file_path}: {e}")
            error_count += 1

    total = success_count + error_count
    print(f"\n{'='*50}")
    print(f"Processed: {total} | Ok: {success_count} | Errors: {error_count}")

    sys.exit(0 if error_count == 0 else 1)


if __name__ == "__main__":
    main()
