"""Test collection type decoding."""

import struct
import pytest
from nippy_decoder import NippyDecoder


def test_vector_fixed():
    decoder = NippyDecoder()
    
    # 2-element vector (type 19)
    data = b'NPY\x00\x13\x07' + struct.pack('>i', 1) + b'\x07' + struct.pack('>i', 2)
    assert decoder.decode(data) == [1, 2]


def test_vector_variable():
    decoder = NippyDecoder()
    
    # Vector with 1-byte count (type 21)
    data = b'NPY\x00\x15\x03\x07' + struct.pack('>i', 1) + b'\x07' + struct.pack('>i', 2) + b'\x07' + struct.pack('>i', 3)
    assert decoder.decode(data) == [1, 2, 3]


def test_map_simple():
    decoder = NippyDecoder()
    
    # Map with 1-byte count (type 24)
    # {:name "test" :age 25}
    data = b'NPY\x00\x18\x02\x21\x04name\x0c\x04test\x21\x03age\x07' + struct.pack('>i', 25)
    result = decoder.decode(data)
    assert result == {'name': 'test', 'age': 25}


def test_map_nested():
    decoder = NippyDecoder()
    
    # {:user {:name "alice" :id 1}}
    # Outer map (type 24, count=1)
    # Inner map (type 24, count=2)
    inner = b'\x18\x02\x21\x04name\x0c\x05alice\x21\x02id\x07' + struct.pack('>i', 1)
    data = b'NPY\x00\x18\x01\x21\x04user' + inner
    
    result = decoder.decode(data)
    assert result == {'user': {'name': 'alice', 'id': 1}}


def test_set():
    decoder = NippyDecoder()
    
    # Set with 1-byte count (type 27)
    data = b'NPY\x00\x1b\x03\x07' + struct.pack('>i', 1) + b'\x07' + struct.pack('>i', 2) + b'\x07' + struct.pack('>i', 3)
    result = decoder.decode(data)
    assert result == {1, 2, 3}


def test_empty_collections():
    decoder = NippyDecoder()
    
    # Empty vector
    data = b'NPY\x00\x15\x00'
    assert decoder.decode(data) == []
    
    # Empty map
    data = b'NPY\x00\x18\x00'
    assert decoder.decode(data) == {}
    
    # Empty set
    data = b'NPY\x00\x1b\x00'
    assert decoder.decode(data) == set()


def test_mixed_types_vector():
    decoder = NippyDecoder()
    
    # [42 "hello" true nil]
    data = (
        b'NPY\x00\x15\x04'  # vector, count=4
        b'\x07' + struct.pack('>i', 42) +  # 42
        b'\x0c\x05hello' +  # "hello"
        b'\x01' +  # true
        b'\x03'    # nil
    )
    assert decoder.decode(data) == [42, "hello", True, None]


def test_map_unhashable_key():
    decoder = NippyDecoder()
    
    # Map with list as key -> should convert to string
    data = (
        b'NPY\x00\x18\x01'  # map, count=1
        b'\x15\x02\x07' + struct.pack('>i', 1) + b'\x07' + struct.pack('>i', 2) +  # key: [1, 2]
        b'\x0c\x05value'  # value: "value"
    )
    result = decoder.decode(data)
    assert result == {'[1, 2]': 'value'}
