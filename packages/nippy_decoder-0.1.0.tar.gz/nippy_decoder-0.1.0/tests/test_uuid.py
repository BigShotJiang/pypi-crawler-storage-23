"""Test UUID decoding."""

import struct
import uuid
import pytest
from nippy_decoder import NippyDecoder


def test_uuid_decoding():
    decoder = NippyDecoder()
    
    # Create a known UUID
    test_uuid = uuid.UUID('550e8400-e29b-41d4-a716-446655440000')
    
    # Encode as two signed 64-bit longs (big-endian)
    msb = (test_uuid.int >> 64) & 0xFFFFFFFFFFFFFFFF
    lsb = test_uuid.int & 0xFFFFFFFFFFFFFFFF
    
    # Convert to signed
    if msb >= 2**63:
        msb -= 2**64
    if lsb >= 2**63:
        lsb -= 2**64
    
    data = b'NPY\x00\x24' + struct.pack('>qq', msb, lsb)  # type 36 = 0x24
    result = decoder.decode(data)
    
    assert result == str(test_uuid)


def test_uuid_in_map():
    decoder = NippyDecoder()
    
    # {:id <uuid>}
    test_uuid = uuid.UUID('ba8feab4-9efb-4635-97d2-be648a141fb4')
    
    msb = (test_uuid.int >> 64) & 0xFFFFFFFFFFFFFFFF
    lsb = test_uuid.int & 0xFFFFFFFFFFFFFFFF
    
    if msb >= 2**63:
        msb -= 2**64
    if lsb >= 2**63:
        lsb -= 2**64
    
    uuid_bytes = struct.pack('>qq', msb, lsb)
    
    data = (
        b'NPY\x00\x18\x01'  # map, count=1
        b'\x21\x02id'  # key: :id
        b'\x24' + uuid_bytes  # value: uuid
    )
    
    result = decoder.decode(data)
    assert result == {'id': 'ba8feab4-9efb-4635-97d2-be648a141fb4'}
