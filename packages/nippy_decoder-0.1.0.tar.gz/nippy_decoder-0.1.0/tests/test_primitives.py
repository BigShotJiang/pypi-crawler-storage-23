"""Test primitive type decoding."""

import struct
import pytest
from nippy_decoder import NippyDecoder


def test_null():
    decoder = NippyDecoder()
    data = b'NPY\x00\x03'  # type 3 = nil
    assert decoder.decode(data) is None


def test_boolean():
    decoder = NippyDecoder()
    assert decoder.decode(b'NPY\x00\x01') is True   # type 1
    assert decoder.decode(b'NPY\x00\x02') is False  # type 2


def test_integers():
    decoder = NippyDecoder()
    
    # Zero
    assert decoder.decode(b'NPY\x00\x00') == 0
    
    # Small positive (type 4 = u8)
    assert decoder.decode(b'NPY\x00\x04\x2a') == 42
    
    # Small negative (type 5 = -u8)
    assert decoder.decode(b'NPY\x00\x05\x0f') == -15
    
    # i32 (type 7)
    data = b'NPY\x00\x07' + struct.pack('>i', 100000)
    assert decoder.decode(data) == 100000
    
    # i64 (type 8)
    data = b'NPY\x00\x08' + struct.pack('>q', 9999999999)
    assert decoder.decode(data) == 9999999999


def test_floats():
    decoder = NippyDecoder()
    
    # f32 (type 9)
    data = b'NPY\x00\x09' + struct.pack('>f', 3.14)
    result = decoder.decode(data)
    assert abs(result - 3.14) < 0.01
    
    # f64 (type 10)
    data = b'NPY\x00\x0a' + struct.pack('>d', 2.718281828)
    result = decoder.decode(data)
    assert abs(result - 2.718281828) < 0.000001


def test_strings():
    decoder = NippyDecoder()
    
    # Empty string (type 11)
    assert decoder.decode(b'NPY\x00\x0b') == ""
    
    # Short string (type 12, 1-byte length)
    data = b'NPY\x00\x0c\x05hello'
    assert decoder.decode(data) == "hello"
    
    # Medium string (type 13, 2-byte length)
    text = "x" * 300
    data = b'NPY\x00\x0d' + struct.pack('>H', 300) + text.encode('utf-8')
    assert decoder.decode(data) == text


def test_keywords():
    decoder = NippyDecoder()
    
    # Keyword (type 33, converted to string without :)
    data = b'NPY\x00\x21\x06status'
    assert decoder.decode(data) == "status"
    
    data = b'NPY\x00\x21\x04name'
    assert decoder.decode(data) == "name"


def test_invalid_header():
    decoder = NippyDecoder()
    
    with pytest.raises(ValueError, match="invalid nippy header"):
        decoder.decode(b'XXX\x00\x01')


def test_invalid_version():
    decoder = NippyDecoder()
    
    with pytest.raises(ValueError, match="unsupported nippy version"):
        decoder.decode(b'NPY\x99\x01')


def test_empty_data():
    decoder = NippyDecoder()
    assert decoder.decode(b'') is None
    assert decoder.decode(None) is None
