"""Pure Python decoder for Clojure Nippy-encoded data.

Supports:
- Primitives: null, bool, integers, floats
- Strings and Clojure keywords
- Collections: vectors, maps, sets, lists
- Binary: byte arrays, UUIDs
- Extended types 44-127

Reference: https://github.com/taoensso/nippy
"""

import struct
import uuid
import json
from io import BytesIO
from typing import Any, Union


class NippyDecoder:
    """Decoder for Nippy format (Clojure serialization)."""
    
    MAGIC_HEADER = b'NPY'
    VERSION = 0
    
    def decode(self, data: Union[bytes, memoryview]) -> Any:
        """Decode nippy-encoded bytes to Python objects.
        
        Args:
            data: Nippy-encoded bytes
            
        Returns:
            Decoded Python object (dict, list, str, int, float, etc.)
            
        Raises:
            ValueError: If data is invalid or unsupported
        """
        if isinstance(data, memoryview):
            data = bytes(data)
        
        if not data or len(data) < 4:
            return None
        
        if data[:3] != self.MAGIC_HEADER:
            raise ValueError("invalid nippy header")
        
        if data[3] != self.VERSION:
            raise ValueError(f"unsupported nippy version: {data[3]}")
        
        stream = BytesIO(data[4:])
        return self._read(stream)
    
    def _read(self, stream: BytesIO) -> Any:
        """Read one value from stream."""
        type_byte = stream.read(1)
        if not type_byte:
            raise ValueError("unexpected end of stream")
        
        type_code = type_byte[0]
        
        # Primitives
        if type_code == 0: return 0
        if type_code == 1: return True
        if type_code == 2: return False
        if type_code == 3: return None
        
        # Integers
        if type_code == 4: return stream.read(1)[0]
        if type_code == 5: return -stream.read(1)[0]
        if type_code == 6: return struct.unpack('>h', stream.read(2))[0]
        if type_code == 7: return struct.unpack('>i', stream.read(4))[0]
        if type_code == 8: return struct.unpack('>q', stream.read(8))[0]
        if type_code == 40: return struct.unpack('>b', stream.read(1))[0]
        if type_code == 41: return struct.unpack('>h', stream.read(2))[0]
        if type_code == 42: return struct.unpack('>i', stream.read(4))[0]
        if type_code == 43: return struct.unpack('>q', stream.read(8))[0]
        
        # Floats
        if type_code == 9: return struct.unpack('>f', stream.read(4))[0]
        if type_code == 10: return struct.unpack('>d', stream.read(8))[0]
        
        # Strings
        if type_code == 11: return ""
        if type_code == 12: return self._read_str(stream, 1)
        if type_code == 13: return self._read_str(stream, 2)
        if type_code == 14: return self._read_str(stream, 4)
        if type_code == 105: return self._read_str(stream, 1)
        
        # Keywords (Clojure :keyword -> "keyword" string)
        if type_code in [33, 106]: return self._read_str(stream, 1)
        if type_code == 34: return self._read_str(stream, 2)
        if type_code == 35: return self._read_str(stream, 4)
        
        # Byte arrays
        if type_code == 15: return b""
        if type_code == 16: return self._read_bytes(stream, 2)
        if type_code == 17: return self._read_vec(stream, 2)
        if type_code == 18: return set(self._read_vec(stream, 2))
        
        # UUID
        if type_code == 36: return self._read_uuid(stream)
        
        # Vectors
        if type_code == 19: return [self._read(stream), self._read(stream)]
        if type_code == 20: return [self._read(stream), self._read(stream), self._read(stream)]
        if type_code == 21: return self._read_vec(stream, 1)
        if type_code == 22: return self._read_vec(stream, 2)
        if type_code == 23: return self._read_vec(stream, 4)
        
        # Maps
        if type_code == 24: return self._read_map(stream, 1)
        if type_code == 25: return self._read_map(stream, 2)
        if type_code == 26: return self._read_map(stream, 4)
        if type_code == 112: return self._read_map(stream, 1)
        
        # Sets
        if type_code == 27: return set(self._read_vec(stream, 1))
        if type_code == 28: return set(self._read_vec(stream, 2))
        if type_code == 29: return set(self._read_vec(stream, 4))
        
        # Lists
        if type_code == 30: return self._read_vec(stream, 1)
        if type_code == 31: return self._read_vec(stream, 2)
        if type_code == 32: return self._read_vec(stream, 4)
        
        # Metadata (skip and read next)
        if type_code == 37:
            self._read(stream)
            return self._read(stream)
        
        # Legacy collection types (44-127)
        if 44 <= type_code <= 127 and type_code not in [105, 106, 112]:
            return self._read_vec(stream, 1)
        
        raise ValueError(f"unsupported type: {type_code}")
    
    def _read_str(self, stream: BytesIO, len_bytes: int) -> str:
        """Read UTF-8 string with length prefix."""
        if len_bytes == 1:
            length = stream.read(1)[0]
        elif len_bytes == 2:
            length = struct.unpack('>H', stream.read(2))[0]
        else:
            length = struct.unpack('>I', stream.read(4))[0]
        return stream.read(length).decode('utf-8')
    
    def _read_bytes(self, stream: BytesIO, len_bytes: int) -> bytes:
        """Read byte array with length prefix."""
        if len_bytes == 1:
            length = stream.read(1)[0]
        elif len_bytes == 2:
            length = struct.unpack('>H', stream.read(2))[0]
        else:
            length = struct.unpack('>I', stream.read(4))[0]
        data = stream.read(length)
        # Auto-parse JSON if detected
        if data and data[0:1] in (b'{', b'['):
            try:
                return json.loads(data.decode('utf-8'))
            except:
                pass
        return data
    
    def _read_uuid(self, stream: BytesIO) -> str:
        """Read UUID as two signed 64-bit longs."""
        msb = struct.unpack('>q', stream.read(8))[0]
        lsb = struct.unpack('>q', stream.read(8))[0]
        # Convert signed to unsigned
        if msb < 0: msb += 2**64
        if lsb < 0: lsb += 2**64
        return str(uuid.UUID(int=(msb << 64) | lsb))
    
    def _read_vec(self, stream: BytesIO, count_bytes: int) -> list:
        """Read vector with count prefix."""
        if count_bytes == 1:
            count = stream.read(1)[0]
        elif count_bytes == 2:
            count = struct.unpack('>H', stream.read(2))[0]
        else:
            count = struct.unpack('>I', stream.read(4))[0]
        return [self._read(stream) for _ in range(count)]
    
    def _read_map(self, stream: BytesIO, count_bytes: int) -> dict:
        """Read map with count prefix."""
        if count_bytes == 1:
            count = stream.read(1)[0]
        elif count_bytes == 2:
            count = struct.unpack('>H', stream.read(2))[0]
        else:
            count = struct.unpack('>I', stream.read(4))[0]
        
        result = {}
        for _ in range(count):
            key = self._read(stream)
            value = self._read(stream)
            
            # Make key hashable
            if isinstance(key, (list, dict, set)):
                key = str(key)
            
            result[key] = value
        
        return result
