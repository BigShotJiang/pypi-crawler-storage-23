# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2025-02-26

### Added
- Initial release
- Pure Python Nippy decoder implementation
- Support for all standard Nippy types:
  - Primitives (null, bool, int, float)
  - Strings and keywords
  - Collections (vector, map, set, list)
  - UUIDs
  - Byte arrays with auto-JSON parsing
- Zero external dependencies
- Python 3.8+ support
- Comprehensive test suite
- Usage examples
