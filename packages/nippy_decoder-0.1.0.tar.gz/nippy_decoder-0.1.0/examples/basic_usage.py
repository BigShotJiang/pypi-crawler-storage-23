#!/usr/bin/env python3
"""Basic usage examples for nippy-decoder.

This example demonstrates decoding common Nippy data types that you might
encounter when reading data from Clojure services.
"""

import struct
from nippy_decoder import NippyDecoder


def example_primitives():
    """Decode basic primitive types."""
    print("=== Primitive Types ===\n")
    
    decoder = NippyDecoder()
    
    # Boolean
    print("Boolean:")
    print(f"  True  → {decoder.decode(b'NPY\x00\x01')}")
    print(f"  False → {decoder.decode(b'NPY\x00\x02')}")
    print(f"  None  → {decoder.decode(b'NPY\x00\x03')}\n")
    
    # Integer
    print("Integer:")
    data = b'NPY\x00\x07' + struct.pack('>i', 42)
    print(f"  42 → {decoder.decode(data)}\n")
    
    # Float
    print("Float:")
    data = b'NPY\x00\x0a' + struct.pack('>d', 3.14159)
    print(f"  3.14159 → {decoder.decode(data)}\n")


def example_strings():
    """Decode strings and Clojure keywords."""
    print("=== Strings & Keywords ===\n")
    
    decoder = NippyDecoder()
    
    # String
    print("String:")
    data = b'NPY\x00\x0c\x05hello'
    print(f"  'hello' → {decoder.decode(data)!r}\n")
    
    # Clojure keyword (becomes string without colon)
    print("Clojure Keyword:")
    data = b'NPY\x00\x21\x06status'
    print(f"  :status → {decoder.decode(data)!r}")
    print(f"  (Note: colon is removed in Python)\n")


def example_collections():
    """Decode collections: vectors, maps, and sets."""
    print("=== Collections ===\n")
    
    decoder = NippyDecoder()
    
    # Vector (Clojure) → List (Python)
    print("Vector → List:")
    data = b'NPY\x00\x15\x03\x07' + struct.pack('>i', 1) + b'\x07' + struct.pack('>i', 2) + b'\x07' + struct.pack('>i', 3)
    result = decoder.decode(data)
    print(f"  [1 2 3] → {result}\n")
    
    # Map (Clojure) → Dict (Python)
    print("Map → Dict:")
    data = b'NPY\x00\x18\x02\x21\x04name\x0c\x05alice\x21\x03age\x07' + struct.pack('>i', 30)
    result = decoder.decode(data)
    print(f"  {{:name 'alice' :age 30}} → {result}\n")
    
    # Set
    print("Set:")
    data = b'NPY\x00\x1b\x03\x07' + struct.pack('>i', 1) + b'\x07' + struct.pack('>i', 2) + b'\x07' + struct.pack('>i', 3)
    result = decoder.decode(data)
    print(f"  #{{1 2 3}} → {result}\n")


def example_nested_data():
    """Decode nested structures (common in real-world usage)."""
    print("=== Nested Data ===\n")
    
    decoder = NippyDecoder()
    
    # Nested map: {:user {:name "alice" :active true}}
    print("Nested Map:")
    inner_map = b'\x18\x02\x21\x04name\x0c\x05alice\x21\x06active\x01'
    data = b'NPY\x00\x18\x01\x21\x04user' + inner_map
    result = decoder.decode(data)
    print(f"  Clojure: {{:user {{:name 'alice' :active true}}}}")
    print(f"  Python:  {result}\n")
    
    # List of maps (common database pattern)
    print("Vector of Maps:")
    map1 = b'\x18\x01\x21\x02id\x07' + struct.pack('>i', 1)
    map2 = b'\x18\x01\x21\x02id\x07' + struct.pack('>i', 2)
    data = b'NPY\x00\x15\x02' + map1 + map2
    result = decoder.decode(data)
    print(f"  [{{'id': 1}} {{'id': 2}}] → {result}\n")


def example_real_world():
    """Simulate real-world database record."""
    print("=== Real-World Example ===\n")
    
    decoder = NippyDecoder()
    
    print("Decoding a record from database:")
    print("(This represents a typical Clojure service record)\n")
    
    # Simulated database record:
    # {:id 12345
    #  :status "ACTIVE"
    #  :amount 150.50}
    
    data = (
        b'NPY\x00\x18\x03'  # map with 3 entries
        b'\x21\x02id\x07' + struct.pack('>i', 12345) +
        b'\x21\x06status\x0c\x06ACTIVE' +
        b'\x21\x06amount\x0a' + struct.pack('>d', 150.50)
    )
    
    result = decoder.decode(data)
    
    print("Decoded record:")
    for key, value in result.items():
        print(f"  {key}: {value}")
    
    print("\nAccessing fields:")
    print(f"  ID: {result['id']}")
    print(f"  Status: {result['status']}")
    print(f"  Amount: ${result['amount']:.2f}")
    print()


def example_error_handling():
    """Demonstrate error handling."""
    print("=== Error Handling ===\n")
    
    decoder = NippyDecoder()
    
    # Invalid header
    print("1. Invalid header:")
    try:
        decoder.decode(b'INVALID_DATA')
    except ValueError as e:
        print(f"   Error: {e}\n")
    
    # Unsupported version
    print("2. Unsupported version:")
    try:
        decoder.decode(b'NPY\x99\x00')  # version 0x99 doesn't exist
    except ValueError as e:
        print(f"   Error: {e}\n")
    
    # Empty data
    print("3. Empty data:")
    result = decoder.decode(b'')
    print(f"   Result: {result} (returns None)\n")


def main():
    """Run all examples."""
    print("\n" + "="*60)
    print("NIPPY DECODER - BASIC USAGE EXAMPLES")
    print("="*60 + "\n")
    
    example_primitives()
    example_strings()
    example_collections()
    example_nested_data()
    example_real_world()
    example_error_handling()
    
    print("="*60)
    print("For database integration examples, see README.md")
    print("="*60 + "\n")


if __name__ == '__main__':
    main()
