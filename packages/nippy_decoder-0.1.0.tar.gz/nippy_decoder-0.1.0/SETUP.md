# nippy-decoder

Ready for GitHub publishing.

## Quick Start

```bash
# Install in development mode
cd ~/work/nippy-decoder
pip install -e .

# Run examples
python examples/basic_usage.py
python examples/database_example.py

# Run tests (requires pytest)
pip install pytest
pytest tests/ -v
```

## Publish to PyPI

```bash
# Install build tools
pip install build twine

# Build package
python -m build

# Upload to PyPI (test first!)
twine upload --repository testpypi dist/*
twine upload dist/*
```

## GitHub Setup

```bash
cd ~/work/nippy-decoder
git init
git add .
git commit -m "Initial release: Pure Python Nippy decoder"

# Create repo on GitHub, then:
git remote add origin https://github.com/yourorg/nippy-decoder
git push -u origin main
```

## Package Structure

```
nippy-decoder/
├── src/nippy_decoder/
│   ├── __init__.py          # Package exports
│   └── decoder.py           # Core decoder (210 lines)
├── tests/
│   ├── test_primitives.py   # Basic types
│   ├── test_collections.py  # Vectors, maps, sets
│   └── test_uuid.py         # UUID handling
├── examples/
│   ├── basic_usage.py       # Quick examples
│   └── database_example.py  # Real-world usage
├── pyproject.toml           # Package metadata
├── README.md                # User documentation
├── LICENSE                  # MIT license
├── CHANGELOG.md             # Version history
└── .gitignore               # Git exclusions
```

## Features

- **Zero dependencies** - stdlib only
- **210 lines** - simple, maintainable code
- **Validated** - tested against official Clojure Nippy
- **Python 3.8+** - modern Python support
