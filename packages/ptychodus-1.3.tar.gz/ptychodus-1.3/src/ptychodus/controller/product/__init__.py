from .core import ProductController

__all__ = [
    'ProductController',
]
