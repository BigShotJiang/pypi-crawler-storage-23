Detailed tips, tricks, and examples, can be found at project's repository
https://github.com/asinerum/apics

(C) 2026 Asinerum Conlang Project