# sage_setup: distribution = sagemath-categories
from sage.rings.semirings.non_negative_integer_semiring import NonNegativeIntegerSemiring, NN
from sage.rings.semirings.tropical_semiring import TropicalSemiring
