# sage_setup: distribution = sagemath-categories

from sage.misc.lazy_import import lazy_import

from sage.databases.sql_db import SQLQuery, SQLDatabase

del lazy_import
