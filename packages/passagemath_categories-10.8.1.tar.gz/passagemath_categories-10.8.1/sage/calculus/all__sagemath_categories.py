# sage_setup: distribution = sagemath-categories
from sage.calculus.functional import diff, derivative, expand, simplify, taylor
