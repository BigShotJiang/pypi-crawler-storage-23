# sage_setup: distribution = sagemath-categories

from sage.all__sagemath_categories import *
