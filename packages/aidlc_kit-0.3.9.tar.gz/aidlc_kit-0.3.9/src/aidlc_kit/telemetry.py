"""Anonymous usage telemetry (opt-out).

Privacy:
  - Tracks command name, flags, version, OS, Python version only
  - No project names, intent names, bolt names, or file paths
  - Anonymous UUID with no relation to the user
  - Opt-out: AIDLC_TELEMETRY=0 or DO_NOT_TRACK=1
  - Auto-disabled in CI
"""

from __future__ import annotations

import json
import os
import platform
import sys
import threading
import uuid
from pathlib import Path
from urllib.request import Request, urlopen

def _load_config() -> tuple[str, str]:
    try:
        from importlib.resources import files
        cfg = json.loads(files("aidlc_kit").joinpath("ph.json").read_text())
        return cfg.get("posthog_key", ""), cfg.get("posthog_host", "")
    except Exception:
        return "", ""

_POSTHOG_KEY, _POSTHOG_HOST = _load_config()
_CONFIG_PATH = Path.home() / ".config" / "aidlc-kit" / "config.json"
_TIMEOUT = 2


def is_enabled() -> bool:
    return bool(_POSTHOG_KEY) and not (
        os.environ.get("AIDLC_TELEMETRY") == "0"
        or os.environ.get("DO_NOT_TRACK") == "1"
        or os.environ.get("CI", "").lower() == "true"
    )


def _read_config() -> dict:
    try:
        return json.loads(_CONFIG_PATH.read_text())
    except Exception:
        return {}


def _write_config(updates: dict) -> None:
    cfg = _read_config()
    cfg.update(updates)
    _CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    _CONFIG_PATH.write_text(json.dumps(cfg, indent=2) + "\n")


def _get_anonymous_id() -> str:
    cfg = _read_config()
    aid = cfg.get("anonymous_id")
    if aid:
        return aid
    aid = str(uuid.uuid4())
    _write_config({"anonymous_id": aid})
    return aid


def maybe_show_notice() -> None:
    if not is_enabled():
        return
    cfg = _read_config()
    if cfg.get("notice_seen"):
        return
    print(
        "Note: aidlc-kit collects anonymous usage stats "
        "(command + version only). Opt out: AIDLC_TELEMETRY=0"
    )
    _write_config({"notice_seen": True})


_pending: threading.Thread | None = None


def track(command: str, version: str, props: dict | None = None) -> None:
    global _pending
    if not is_enabled():
        return

    def _send():
        try:
            body = json.dumps({
                "api_key": _POSTHOG_KEY,
                "event": "command_executed",
                "distinct_id": _get_anonymous_id(),
                "properties": {
                    "command": command,
                    "version": version,
                    "os": sys.platform,
                    "python": platform.python_version(),
                    "$ip": None,
                    **(props or {}),
                },
            }).encode()
            req = Request(
                f"{_POSTHOG_HOST}/capture/",
                data=body,
                headers={"Content-Type": "application/json"},
            )
            urlopen(req, timeout=_TIMEOUT)
        except Exception:
            pass  # telemetry must never break CLI

    t = threading.Thread(target=_send, daemon=True)
    t.start()
    _pending = t


def flush() -> None:
    """Wait for pending telemetry. Call from atexit."""
    if _pending is not None:
        _pending.join(timeout=_TIMEOUT)
