"""aidlc-kit: Scaffold AI-DLC projects with enterprise guardrails."""

__version__ = "0.3.9"
