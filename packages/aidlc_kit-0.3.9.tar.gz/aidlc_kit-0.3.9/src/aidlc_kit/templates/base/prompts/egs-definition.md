# EGS Definition — Guided Setup

> **Purpose:** Create your organization's Enterprise Guardrails Specification (EGS) through a guided conversation. The result is a platform-neutral EGS file that teams import into their AI-DLC projects.
>
> **Run with:** `aidlc-kit egs-init` or paste this prompt into your AI coding assistant.
>
> **Time:** 30-45 minutes for a thorough definition. You can stop and resume.

---

## Instructions for the AI

You are helping define an organization's Enterprise Guardrails Specification.
The output is a single markdown file that will be shared across all projects.

**Important:** Keep all guardrails platform-neutral. Use generic terms like
"managed key service", "serverless compute", "managed container orchestration",
"identity provider" instead of AWS/Azure/GCP-specific names. Teams will resolve
these to their target platform when they import the EGS into a project.

### Process

1. **Context gathering.** Ask:
   - Organization name
   - Primary industries served (affects compliance scope)
   - Team size and maturity level (affects how strict vs. flexible)
   - Any existing compliance frameworks (SOC2, HIPAA, PCI, ISO 27001, none)
   - Any existing security policies or standards to incorporate

2. **Walk through each of the 10 categories below, one at a time.**
   For each category:
   - Explain what the category covers in 1-2 sentences.
   - Present the default guardrails from the template.
   - Ask: "Do these defaults work for your org? Anything to add, remove, or
     change severity?"
   - For each [bracketed placeholder], ask the user for their org's standard.
     Suggest a sensible default they can accept or modify.
   - Update the category with their answers.
   - Confirm: "Here's category N. Good?" before moving to the next.

3. **After all 10 categories:**
   - Present a one-line summary per category.
   - Ask for category ownership assignments (or skip for later).
   - Ask for review cadence (quarterly, semi-annually).
   - Write the complete EGS to the output file.
   - Tell the user: "Your org EGS is ready. Teams can import it with:
     `aidlc-kit import-egs <path> <project-dir>`"

### The 10 Categories

1. **Security Baseline** — Encryption, IAM, secrets, network security
2. **Compliance Constraints** — Regulatory frameworks, data residency, audit
3. **Architectural Guardrails** — Patterns, boundaries, integration standards
4. **Coding Standards** — Languages, conventions, testing, documentation
5. **Operational Readiness** — Observability, alerting, runbooks, deployment
6. **Cost Guardrails** — Budgets, tagging, right-sizing, approval thresholds
7. **AI/GenAI Guardrails** — Model usage, prompt safety, human oversight
8. **Reliability Guardrails** — Availability targets, failover, backup, DR
9. **Performance Efficiency** — Latency budgets, scaling, capacity planning
10. **Sustainability** — Resource efficiency, waste reduction, green practices

### Template

Read the EGS template file to get the full structure with all guardrails and
placeholders. The template is at the output path (it will be pre-populated
with the platform-agnostic template).

### Rules

- Never use platform-specific service names (no "KMS", "Key Vault", "Lambda",
  "Azure Functions"). Use generic terms.
- Every guardrail must have a severity: Mandatory, Required, or Recommended.
- If the user says "skip" for a category, keep the template defaults.
- If the user wants to stop mid-way, save progress and note which category
  to resume from.
- Be concise in questions. Don't lecture about security basics.
