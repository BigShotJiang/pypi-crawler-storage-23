# AI-DLC State Tracking

> **Maintained by the AI agent during sessions.** Do not edit manually unless
> recovering from a corrupted state (see `standards/error-handling.md`).

## Project

| Field | Value |
|-------|-------|
| Mode | [greenfield/brownfield] |
| Started | [YYYY-MM-DD] |
| Current Ritual | [Code Elevation / Mob Elaboration / Mob Construction] |
| Current Position | [Phase N / Bolt X Stage N] |
| Depth Profile | [THOROUGH / STANDARD / LIGHTWEIGHT] |
| Next Step | [Description of what comes next] |
| Intent Branch | |
| Parent Branch | |
| Last Updated | [YYYY-MM-DD HH:MM] |

## Ritual Progress

{{RITUAL_PROGRESS}}

## Skipped Phases

| Phase | Reason | Date |
|-------|--------|------|
| — | — | — |

## Session Log

| Date | Ritual | What was done | Where it stopped |
|------|--------|---------------|------------------|
| — | — | — | — |

## Archive History
<!-- Appended automatically by `aidlc-kit archive`. Do not edit. -->

| # | Intent | Archived On |
|---|--------|-------------|
| — | — | — |
