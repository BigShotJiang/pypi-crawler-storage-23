{{#enterprise}}
# AI-DLC Session Retrospective Template — Enterprise (with EGS)
{{/enterprise}}
{{#standard}}
# AI-DLC Session Retrospective Template
{{/standard}}

> **Version:** 2.0 | **Last Updated:** 2026-02-24  
> **Usage:** Complete after each AI-DLC session (Mob Elaboration, Mob Construction, or Code Elevation). Focus on improving the practice, not the product.  
{{#enterprise}}
> **Standard:** For sessions without EGS enforcement, use `AIDLC_Session_Retrospective_Template.md` instead.
{{/enterprise}}

---

## Session Info

| Field | Value |
|-------|-------|
| **Session Type** | [Mob Elaboration / Mob Construction / Code Elevation] |
| **Intent/Unit** | [Brief description] |
| **Date** | [YYYY-MM-DD] |
| **Duration (planned)** | [X hours] |
| **Duration (actual)** | [X hours] |
| **Facilitator** | [Name] |
| **Participants** | [Count] |

---

## AI Collaboration

| Question | Answer |
|----------|--------|
| Did AI lead the conversation effectively? | [Yes / Partially / No — explain] |
| Did AI generate useful artifacts on first pass? | [Yes / Needed significant rework / No] |
| Where did AI struggle or produce poor output? | [Describe] |
| Did we validate AI output thoroughly or rubber-stamp? | [Honest assessment] |
| What prompts worked well? | [Copy effective prompts] |
| What prompts needed rework? | [Describe what failed and how you fixed it] |

---

## Session Effectiveness

| Question | Answer |
|----------|--------|
| Did we complete all planned phases/stages? | [Yes / No — which were skipped?] |
| Was the timeboxing respected? | [Yes / No — which phases ran over?] |
| Was everyone engaged throughout? | [Yes / No — who disengaged and when?] |
| Were the right people in the session? | [Yes / No — who was missing? Who was unnecessary?] |
| Did the facilitator manage the session well? | [Honest assessment] |

---

## Output Quality

| Question | Answer |
|----------|--------|
| Are the outputs usable as-is for the next phase? | [Yes / Need minor cleanup / Need significant rework] |
| Were trade-offs documented? | [Yes / Partially / No] |
| Is there anything we agreed on verbally but didn't document? | [List items] |

---

## What to Change Next Time

| Category | Keep Doing | Stop Doing | Start Doing |
|----------|-----------|------------|-------------|
| **AI Interaction** | | | |
| **Facilitation** | | | |
| **Participation** | | | |
| **Timeboxing** | | | |
| **Artifacts** | | | |

---

## Action Items

| # | Action | Owner | Due |
|---|--------|-------|-----|
| 1 | | | |
| 2 | | | |
| 3 | | | |

---

## Brownfield Session Additions (skip if Greenfield)

| Question | Answer |
|----------|--------|
| Was the compatibility impact map accurate? | [Yes / Partially / No — what was missed?] |
| Did regression tests catch real issues? | [Yes / No regressions found / Tests were insufficient] |
| Did adapter/wrapper patterns work, or was direct modification needed? | [Describe] |
| Was the minimal intrusion principle followed? | [Yes / No — where did we over-modify?] |
| Was the Code Elevation model accurate enough for this session? | [Yes / Needed corrections — list them] |

---

{{#enterprise}}
## Enterprise Guardrails Additions

| Question | Answer |
|----------|--------|
{{/enterprise}}
{{#enterprise}}
| Were guardrail violations caught early (during elaboration) or late (during testing)? | [Early / Late — which ones were late?] |
{{/enterprise}}
{{#enterprise}}
| Was the Guardrails Compliance Matrix useful during the session? | [Yes / Too detailed / Too vague / Not referenced] |
{{/enterprise}}
{{#enterprise}}
| How much time did EGS validation add to each phase/stage? | [Estimate per phase] |
{{/enterprise}}
{{#enterprise}}
| Were there guardrail conflicts that required exception requests? | [Yes — list / No] |
{{/enterprise}}
{{#enterprise}}
| Was the Guardrails Gap Analysis (Brownfield) accurate? | [Yes / Needed corrections — list them] |
{{/enterprise}}
{{#enterprise}}
| Did the remediation triage priorities hold, or did we need to re-prioritize? | [Held / Changed — describe] |
{{/enterprise}}
{{#enterprise}}
| Is the Guardrails Compliance Report complete and accurate? | [Yes / Missing items — list them] |
{{/enterprise}}

---

## Notes

- Complete this within 24 hours of the session while memory is fresh.
- This retro is about the *practice*, not the *product*. Don't discuss features or architecture here.
- Share findings with other facilitators to build collective knowledge.
- Keep it short — 15 minutes to fill out, not a 1-hour meeting.
- Brownfield section is optional — skip if the session was purely Greenfield.
{{#enterprise}}
- Enterprise Guardrails section helps calibrate EGS validation overhead across sessions. Track trends over time.
{{/enterprise}}
