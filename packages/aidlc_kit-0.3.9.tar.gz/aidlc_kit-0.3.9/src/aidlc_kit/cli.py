"""CLI entry point for aidlc-kit."""

import atexit
import json
import re
import shutil
import time
from pathlib import Path
from urllib.request import urlopen

import click

from aidlc_kit import __version__
from aidlc_kit.scaffold import IDES, TIERS, archive_project, check_project, consistency_check, install_extension, list_extensions, remove_extension, scaffold_project, status_project, update_project

_CACHE_DIR = Path.home() / ".aidlc-kit"
_CACHE_FILE = _CACHE_DIR / "last-update-check"
_CHECK_INTERVAL = 86400  # 24 hours
_PYPI_URL = "https://pypi.org/pypi/aidlc-kit/json"
_TIMEOUT = 2


_UPDATE_MSG = "\n⚠ Update available: {} → {}\n  pip install --upgrade aidlc-kit  |  uv tool upgrade aidlc-kit  |  uvx aidlc-kit@latest"


def _check_for_update() -> None:
    """Print a notice if a newer version is available on PyPI. Cached daily, never errors."""
    try:
        from packaging.version import Version
        if _CACHE_FILE.exists():
            data = json.loads(_CACHE_FILE.read_text())
            if time.time() - data.get("ts", 0) < _CHECK_INTERVAL:
                latest = data.get("v", __version__)
                if Version(latest) > Version(__version__):
                    click.echo(_UPDATE_MSG.format(__version__, latest))
                return
        resp = urlopen(_PYPI_URL, timeout=_TIMEOUT)
        latest = json.loads(resp.read()).get("info", {}).get("version", __version__)
        _CACHE_DIR.mkdir(parents=True, exist_ok=True)
        _CACHE_FILE.write_text(json.dumps({"v": latest, "ts": time.time()}))
        if Version(latest) > Version(__version__):
            click.echo(_UPDATE_MSG.format(__version__, latest))
    except Exception:
        pass

atexit.register(_check_for_update)


def _flush_telemetry() -> None:
    try:
        from aidlc_kit.telemetry import flush
        flush()
    except Exception:
        pass

atexit.register(_flush_telemetry)

# Safe parameters to track (everything except project/intent/bolt names)
_SAFE_PARAMS = {"mode", "platform", "tier", "force", "yes", "output_json", "output"}


def _track(command: str, **params) -> None:
    """Fire telemetry for a command. Only sends safe params."""
    from aidlc_kit.telemetry import track
    props = {k: v for k, v in params.items() if k in _SAFE_PARAMS and v is not None}
    track(command, __version__, props)


@click.group()
@click.version_option(version=__version__)
def main():
    """AI-DLC project scaffolding tool."""
    from aidlc_kit.telemetry import maybe_show_notice
    maybe_show_notice()


def _parse_ides(raw: tuple[str, ...]) -> list[str] | None:
    """Flatten comma-separated and repeated --ide values; validate each."""
    if not raw:
        return None
    names: list[str] = []
    for token in raw:
        names.extend(t.strip().lower() for t in token.split(",") if t.strip())
    if "all" in names:
        return list(IDES)
    invalid = [n for n in names if n not in IDES]
    if invalid:
        raise click.ClickException(
            f"Unknown IDE(s): {', '.join(invalid)}. Choose from: {', '.join(IDES)}, or 'all'."
        )
    # deduplicate preserving order
    seen: set[str] = set()
    return [n for n in names if not (n in seen or seen.add(n))]


_IDE_HELP = (
    "IDE router configs to generate. Repeat or comma-separate: "
    "--ide kiro --ide cursor or --ide kiro,cursor. "
    f"Use 'all' for every IDE. Supported: {', '.join(IDES)}."
)


_MODES = ["greenfield", "brownfield"]
_PLATFORMS = ["aws", "azure", "gcp", "onprem", "agnostic"]
_TIERS = ["enterprise", "standard"]


def _pick(label: str, options: list[str], descriptions: dict[str, str] | None = None) -> str:
    """Numbered picker — returns chosen value."""
    click.echo(f"\n{label}:")
    for i, opt in enumerate(options, 1):
        desc = f"  — {descriptions[opt]}" if descriptions and opt in descriptions else ""
        click.echo(f"  {i}. {opt}{desc}")
    while True:
        raw = click.prompt(">", prompt_suffix=" ").strip().lower()
        if raw in options:
            return raw
        if raw.isdigit() and 1 <= int(raw) <= len(options):
            return options[int(raw) - 1]
        click.echo(f"  Invalid choice. Enter 1-{len(options)} or a name.")


def _pick_ides() -> list[str] | None:
    """IDE picker — returns list, empty list for none, or full list for all."""
    ide_list = list(IDES)
    click.echo("\nIDE config (required — pick one or more, comma-separate for multiple):")
    cols = 3
    for i, name in enumerate(ide_list, 1):
        end = "\n" if i % cols == 0 else ""
        click.echo(f"  {i:>2}. {name:<16}", nl=False)
        if end:
            click.echo()
    if len(ide_list) % cols:
        click.echo()
    click.echo(f"   a. all — every IDE")
    click.echo(f"   n. none — skip (add later with 'aidlc-kit update --ide')")
    while True:
        raw = click.prompt(">", prompt_suffix=" ").strip().lower()
        if raw == "n" or raw == "none":
            click.echo("  ℹ No IDE config generated. Run 'aidlc-kit update --ide <name>' to add later.")
            return None
        if raw == "a" or raw == "all":
            return list(IDES)
        tokens = [t.strip() for t in raw.replace(",", " ").split() if t.strip()]
        resolved: list[str] = []
        bad = False
        for t in tokens:
            if t in ide_list:
                resolved.append(t)
            elif t.isdigit() and 1 <= int(t) <= len(ide_list):
                resolved.append(ide_list[int(t) - 1])
            else:
                click.echo(f"  Unknown: '{t}'. Enter numbers, names, 'a', or 'n'.")
                bad = True
                break
        if bad:
            continue
        if not resolved:
            click.echo("  Pick at least one, 'a' for all, or 'n' for none.")
            continue
        seen: set[str] = set()
        return [r for r in resolved if not (r in seen or seen.add(r))]


@main.command()
@click.argument("target", default=".")
@click.option("--mode", default=None,
              help="Project mode: greenfield (new) or brownfield (existing codebase).")
@click.option("--platform", default=None,
              help="Deployment platform: aws, azure, gcp, onprem, agnostic.")
@click.option("--name", default=None, help="Project name. Defaults to target directory name.")
@click.option("--force", is_flag=True, help="Overwrite existing aidlc-docs/ if present.")
@click.option("--ide", multiple=True, default=None,
              help=_IDE_HELP)
@click.option("--tier", default=None,
              help="Prompt tier: enterprise (with EGS guardrails) or standard (no guardrails). Default: standard.")
def init(target: str, mode: str | None, platform: str | None, name: str | None, force: bool, ide: tuple[str, ...], tier: str | None):
    """Scaffold an AI-DLC project at TARGET directory.

    TARGET defaults to the current directory (.).
    """
    _track("init", mode=mode, platform=platform, tier=tier, force=force)
    # Validate if passed on CLI
    if mode and mode.lower() not in _MODES:
        raise click.ClickException(f"Invalid mode '{mode}'. Choose from: {', '.join(_MODES)}")
    if platform and platform.lower() not in _PLATFORMS:
        raise click.ClickException(f"Invalid platform '{platform}'. Choose from: {', '.join(_PLATFORMS)}")
    if tier and tier.lower() not in _TIERS:
        raise click.ClickException(f"Invalid tier '{tier}'. Choose from: {', '.join(_TIERS)}")
    if mode:
        mode = mode.lower()
    if platform:
        platform = platform.lower()
    if tier:
        tier = tier.lower()

    wizard = mode is None or platform is None
    if wizard:
        click.echo("🔧 aidlc-kit init — project setup")
    if mode is None:
        mode = _pick("Mode (required)", _MODES, {
            "greenfield": "new project, no existing code",
            "brownfield": "existing codebase to improve",
        })
    if platform is None:
        platform = _pick("Platform (required)", _PLATFORMS)
    if tier is None and wizard:
        pass  # tier stays None, resolved to "standard" below
    tier = tier or "standard"
    ides = _parse_ides(ide)
    if ides is None and wizard:
        ides = _pick_ides()
    scaffold_project(target, mode, name, force, platform, ides, tier)


@main.command()
@click.argument("target", default=".")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
@click.option(
    "--platform",
    type=click.Choice(["aws", "azure", "gcp", "onprem", "agnostic"], case_sensitive=False),
    default=None,
    help="Deployment platform. Auto-detected from README; required if README lacks Platform row.",
)
@click.option("--ide", multiple=True, default=None,
              help=f"Regenerate {_IDE_HELP}")
@click.option("--tier", default=None,
              help="Override tier: enterprise or standard. Auto-detected from README.")
def update(target: str, yes: bool, platform: str | None, ide: tuple[str, ...], tier: str | None):
    """Update kit-owned templates in an existing AI-DLC project.

    Overwrites prompts, blank templates, and completion criteria.
    Preserves user content: intents, archive, and README.
    """
    _track("update", platform=platform, tier=tier, yes=yes)
    ides = _parse_ides(ide)
    update_project(target, yes, platform, ides, tier)


@main.command()
@click.argument("target", default=".")
@click.option("--name", default=None, help="Archive folder name. Defaults to intent name.")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
def archive(target: str, name: str | None, yes: bool):
    """Archive completed intent and reset workspace for the next one.

    Moves intents, elaboration, construction, decisions, and retrospectives
    into archive/<name>-<date>/. Restores blank templates.
    """
    _track("archive", yes=yes)
    archive_project(target, name, yes)


@main.command()
@click.argument("target", default=".")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON.")
def check(target: str, output_json: bool):
    """Check health of an existing AI-DLC project.

    Validates required files, customization status, plan progress,
    and template drift.
    """
    _track("check", output_json=output_json)
    check_project(target, as_json=output_json)


@main.command()
@click.argument("target", default=".")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON.")
def status(target: str, output_json: bool):
    """Show current project status dashboard."""
    _track("status", output_json=output_json)
    status_project(target, as_json=output_json)


@main.command()
@click.argument("target", default=".")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON.")
def consistency(target: str, output_json: bool):
    """Run structural consistency checks across project artifacts.

    Checks stories↔bolts, dependencies, decision log, EGS structure,
    retro action items, unit mapping, bolt plan completeness, and audit log.
    """
    _track("consistency", output_json=output_json)
    consistency_check(target, as_json=output_json)


@main.command(name="egs-init")
@click.argument("output", default="org-egs.md")
def egs_init(output: str):
    """Create an org-level EGS definition (guided setup).

    \b
    Examples:
      aidlc-kit egs-init                    # creates org-egs.md + egs-definition-prompt.md
      aidlc-kit egs-init /shared/org-egs.md
    """
    _track("egs-init")
    from aidlc_kit.scaffold import TEMPLATES
    out = Path(output).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    # Copy agnostic template as starting point
    src = TEMPLATES / "base" / "egs_variants" / "egs_definition_agnostic.md"
    shutil.copy2(src, out)
    # Copy prompt alongside it
    prompt_src = TEMPLATES / "base" / "prompts" / "egs-definition.md"
    prompt_dst = out.parent / "egs-definition-prompt.md"
    shutil.copy2(prompt_src, prompt_dst)
    click.echo(f"✓ EGS template created at {out}")
    click.echo(f"✓ Setup prompt created at {prompt_dst}")
    click.echo()
    click.echo("Next steps:")
    click.echo(f"  1. Open {prompt_dst} in your AI coding assistant")
    click.echo(f"     (the AI will walk you through all 10 categories)")
    click.echo(f"  2. When done, teams import it: aidlc-kit import-egs {out} <project-dir>")


@main.command(name="export-egs")
@click.argument("target", default=".")
@click.argument("output", default="egs_definition.md")
def export_egs(target: str, output: str):
    """Export the project's EGS definition to a file.

    \b
    Usage examples:
      aidlc-kit export-egs myproject /tmp/shared-egs.md
      aidlc-kit export-egs myproject                      # saves to ./egs_definition.md
    """
    _track("export-egs")
    src = Path(target).resolve() / "aidlc-docs" / "egs_definition.md"
    if not src.exists():
        raise click.ClickException(
            f"No EGS found at {src}.\n\n"
            "Usage: aidlc-kit export-egs <project-dir> [output-file]\n"
            "  Example: aidlc-kit export-egs myproject /tmp/shared-egs.md"
        )
    dst = Path(output).resolve()
    shutil.copy2(src, dst)
    click.echo(f"✓ EGS exported to {dst}")
    click.echo(f"\nTo import into another project:")
    click.echo(f"  aidlc-kit import-egs {dst} /path/to/project")


@main.command(name="import-egs")
@click.argument("source", required=False, default=None)
@click.argument("target", default=".")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
def import_egs(source: str | None, target: str, yes: bool):
    """Import an external EGS definition into the project.

    \b
    Usage examples:
      aidlc-kit import-egs /tmp/shared-egs.md myproject
      aidlc-kit import-egs /tmp/shared-egs.md              # imports into current dir
    """
    _track("import-egs", yes=yes)
    if source is None:
        raise click.ClickException(
            "Missing SOURCE file.\n\n"
            "Usage: aidlc-kit import-egs <egs-file> [project-dir]\n"
            "  Example: aidlc-kit import-egs /tmp/shared-egs.md myproject"
        )
    src = Path(source).resolve()
    if not src.exists():
        raise click.ClickException(f"Source file not found: {src}")
    dst = Path(target).resolve() / "aidlc-docs" / "egs_definition.md"
    if not dst.parent.is_dir():
        raise click.ClickException(f"No aidlc-docs/ found at {dst.parent}. Run 'init' first.")
    if dst.exists() and not yes:
        text = dst.read_text(encoding="utf-8")
        if "Generic Template" not in text:
            click.confirm("EGS is already customized. Overwrite?", abort=True)
    shutil.copy2(src, dst)
    click.echo(f"✓ EGS imported from {src}")
    click.echo(f"\nNext steps:")
    click.echo(f"  1. Review {dst} and adjust org name, thresholds, and policies for this project")
    click.echo(f"  2. Run 'aidlc-kit check {target}' to validate EGS structure")


# ---------------------------------------------------------------------------
# Extensions
# ---------------------------------------------------------------------------

@main.group()
def extensions():
    """Manage project extensions."""
    pass


@extensions.command(name="list")
@click.argument("target", default=".")
def ext_list(target: str):
    """Show available extensions and install status."""
    _track("extensions list")
    for ext in list_extensions(target):
        status = "✓ installed" if ext["installed"] else "  available"
        click.echo(f"  {status}  {ext['name']:20s} {ext['description']}")


@extensions.command()
@click.argument("name")
@click.argument("target", default=".")
def install(name: str, target: str):
    """Install an extension into the project."""
    _track("extensions install")
    dst = install_extension(name, target)
    click.echo(f"✓ Extension '{name}' installed to {dst}")


@extensions.command()
@click.argument("name")
@click.argument("target", default=".")
def remove(name: str, target: str):
    """Remove an extension from the project."""
    _track("extensions remove")
    remove_extension(name, target)
    click.echo(f"✓ Extension '{name}' removed")


# ---------------------------------------------------------------------------
# Intent (parallel intents via git branching)
# ---------------------------------------------------------------------------

def _require_git(target: Path) -> None:
    from aidlc_kit.git import is_git_repo
    if not is_git_repo(target):
        raise click.ClickException("Git repository required. Run 'git init' first.")


def _require_clean(target: Path) -> None:
    from aidlc_kit.git import is_clean
    if not is_clean(target):
        raise click.ClickException("Working tree has uncommitted changes. Commit or stash first.")


def _update_state_branch(docs_path: Path, intent_branch: str, parent_branch: str) -> None:
    state = docs_path / "aidlc-state.md"
    if not state.exists():
        return
    txt = state.read_text(encoding="utf-8")
    txt = re.sub(r"(\|\s*Intent Branch\s*\|)[^|]*\|", rf"\1 {intent_branch} |", txt)
    txt = re.sub(r"(\|\s*Parent Branch\s*\|)[^|]*\|", rf"\1 {parent_branch} |", txt)
    state.write_text(txt, encoding="utf-8")


@main.group()
def intent():
    """Manage parallel intents via git branches."""
    pass


@intent.command()
@click.argument("name")
@click.argument("target", default=".")
def create(name: str, target: str):
    """Create a new intent branch and switch to it."""
    _track("intent create")
    from aidlc_kit.git import commit_all, create_and_switch, current_branch, slugify, intent_branch_name

    target_path = Path(target).resolve()
    _require_git(target_path)
    _require_clean(target_path)

    parent = current_branch(target_path)
    slug = slugify(name)
    branch = intent_branch_name(slug)

    try:
        create_and_switch(branch, target_path)
    except RuntimeError as e:
        raise click.ClickException(str(e))

    # Seed intent file title
    docs = target_path / "aidlc-docs"
    intent_file = docs / "intents" / "intent-primary.md"
    if intent_file.exists():
        txt = intent_file.read_text(encoding="utf-8")
        txt = txt.replace("[Name]", name, 1)
        intent_file.write_text(txt, encoding="utf-8")

    # Update state file with branch info
    _update_state_branch(docs, branch, parent)

    commit_all(f"aidlc: create intent {slug}", target_path)
    click.echo(f"✓ Created intent branch '{branch}'. Start your AI session.")


@intent.command(name="list")
@click.argument("target", default=".")
def intent_list(target: str):
    """Show all active intent branches."""
    _track("intent list")
    from aidlc_kit.git import current_branch, list_branches, INTENT_PREFIX, is_intent_branch

    target_path = Path(target).resolve()
    _require_git(target_path)

    cur = current_branch(target_path)
    branches = [b for b in list_branches(INTENT_PREFIX, target_path) if is_intent_branch(b)]

    if not branches:
        click.echo("No active intent branches.")
        return

    for b in sorted(branches):
        marker = " *" if b == cur else "  "
        slug = b[len(INTENT_PREFIX):]
        click.echo(f"{marker} {slug:30s} ({b})")


@intent.command(name="switch")
@click.argument("name")
@click.argument("target", default=".")
def intent_switch(name: str, target: str):
    """Switch to an existing intent branch."""
    _track("intent switch")
    from aidlc_kit.git import switch, slugify, intent_branch_name

    target_path = Path(target).resolve()
    _require_git(target_path)
    _require_clean(target_path)

    branch = intent_branch_name(slugify(name))
    try:
        switch(branch, target_path)
    except RuntimeError as e:
        raise click.ClickException(str(e))
    click.echo(f"✓ Switched to '{branch}'.")


@intent.command(name="archive")
@click.argument("target", default=".")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompts.")
def intent_archive(target: str, yes: bool):
    """Archive current intent, merge to parent branch, and clean up."""
    _track("intent archive", yes=yes)
    from aidlc_kit.git import (
        commit_all, current_branch, delete_branch, is_intent_branch,
        merge, parse_intent_slug, switch,
    )

    target_path = Path(target).resolve()
    _require_git(target_path)

    cur = current_branch(target_path)
    if not is_intent_branch(cur):
        raise click.ClickException(f"Not on an intent branch (current: {cur}). Switch to one first.")

    # Check for unmerged bolt branches
    from aidlc_kit.git import list_branches
    bolt_branches = [b for b in list_branches(cur + "--bolt-", target_path)]
    if bolt_branches:
        names = ", ".join(b.rsplit("--bolt-", 1)[-1] for b in bolt_branches)
        click.echo(f"⚠ Unmerged bolt branches: {names}")
        if not yes:
            click.confirm("Archive anyway? (unmerged bolt work will be lost)", abort=True)

    # Read parent branch from state file
    docs = target_path / "aidlc-docs"
    parent = "main"
    state = docs / "aidlc-state.md"
    if state.exists():
        m = re.search(r"\|\s*Parent Branch\s*\|\s*(\S+)\s*\|", state.read_text(encoding="utf-8"))
        if m:
            parent = m.group(1)

    # Run normal archive
    archive_project(target, yes=yes)

    # Commit archived state
    commit_all(f"aidlc: archive intent {parse_intent_slug(cur)}", target_path)

    # Merge to parent
    try:
        switch(parent, target_path)
    except RuntimeError as e:
        raise click.ClickException(f"Cannot switch to parent branch '{parent}': {e}")

    if not merge(cur, target_path):
        click.echo(f"⚠ Merge conflicts. Resolve them, then delete the branch manually:")
        click.echo(f"  git branch -d {cur}")
        return

    delete_branch(cur, target_path)
    # Clean up bolt branches
    for bb in bolt_branches:
        delete_branch(bb, target_path)

    slug = parse_intent_slug(cur)
    click.echo(f"✓ Intent '{slug}' archived and merged to '{parent}'.")


# ---------------------------------------------------------------------------
# Bolt (parallel bolts via git branching)
# ---------------------------------------------------------------------------

def _parse_bolt_deps(docs_path: Path) -> dict[str, list[str]]:
    """Parse bolt dependencies from elaboration plan. Returns {bolt_id: [dep_ids]}."""
    for plan_name in ("mob_elaboration_plan.md",):
        plan = docs_path / "mob-elaboration" / plan_name
        if not plan.exists():
            continue
        txt = plan.read_text(encoding="utf-8")
        deps: dict[str, list[str]] = {}
        for m in re.finditer(
            r"\|\s*((?:Bolt\s+)?[Bb]?\d+)\s*\|[^|]*\|[^|]*\|\s*([^|]*)\|", txt
        ):
            bolt_id = re.sub(r"[Bb]olt\s*", "", m.group(1)).strip().lower()
            raw_deps = m.group(2).strip()
            if raw_deps in ("", "—", "-", "None", "none"):
                deps[bolt_id] = []
            else:
                deps[bolt_id] = [
                    re.sub(r"[Bb]olt\s*", "", d).strip().lower()
                    for d in re.split(r"[,;]", raw_deps)
                    if d.strip()
                ]
        return deps
    return {}


@main.group()
def bolt():
    """Manage parallel bolts via git branches."""
    pass


@bolt.command(name="branch")
@click.argument("bolt_id")
@click.argument("target", default=".")
def bolt_branch(bolt_id: str, target: str):
    """Create a bolt branch for parallel construction."""
    _track("bolt branch")
    from aidlc_kit.git import (
        create_and_switch, current_branch, is_intent_branch,
        parse_intent_slug, bolt_branch_name, list_branches,
    )

    target_path = Path(target).resolve()
    _require_git(target_path)
    _require_clean(target_path)

    cur = current_branch(target_path)
    if not is_intent_branch(cur):
        raise click.ClickException(
            f"Must be on an intent branch (current: {cur}). "
            "Run 'aidlc-kit intent create <name>' first."
        )

    slug = parse_intent_slug(cur)
    docs = target_path / "aidlc-docs"

    # Validate dependencies
    deps = _parse_bolt_deps(docs)
    bid = bolt_id.lower()
    if deps and bid in deps:
        merged_bolts = {
            b.rsplit("--bolt-", 1)[-1]
            for b in list_branches(cur + "--bolt-", target_path)
        }
        # A dependency is met if its branch doesn't exist (already merged) or was never branched
        # We check the plan status instead
        plan = docs / "mob-elaboration" / "mob_elaboration_plan.md"
        plan_txt = plan.read_text(encoding="utf-8") if plan.exists() else ""
        for dep in deps[bid]:
            # Check if dependency bolt is marked done in plan
            if not re.search(rf"\|\s*(?:Bolt\s+)?{re.escape(dep)}\s*\|.*✅", plan_txt, re.IGNORECASE):
                raise click.ClickException(
                    f"Bolt {bolt_id} depends on Bolt {dep}. Complete and merge Bolt {dep} first."
                )

    branch = bolt_branch_name(slug, bolt_id)
    try:
        create_and_switch(branch, target_path)
    except RuntimeError as e:
        raise click.ClickException(str(e))

    click.echo(f"✓ Created bolt branch '{branch}'. Start Mob Construction for Bolt {bolt_id}.")


@bolt.command(name="list")
@click.argument("target", default=".")
def bolt_list(target: str):
    """Show bolt branches for the current intent."""
    _track("bolt list")
    from aidlc_kit.git import (
        current_branch, is_bolt_branch, is_intent_branch,
        list_branches, parse_intent_slug, INTENT_PREFIX,
    )

    target_path = Path(target).resolve()
    _require_git(target_path)

    cur = current_branch(target_path)
    slug = parse_intent_slug(cur)
    if not slug:
        raise click.ClickException("Not on an intent or bolt branch.")

    prefix = f"{INTENT_PREFIX}{slug}--bolt-"
    branches = list_branches(prefix, target_path)

    if not branches:
        click.echo("No bolt branches.")
        return

    for b in sorted(branches):
        marker = " *" if b == cur else "  "
        bid = b.rsplit("--bolt-", 1)[-1]
        click.echo(f"{marker} bolt-{bid:10s} ({b})")


@bolt.command(name="merge")
@click.argument("bolt_id")
@click.argument("target", default=".")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation.")
def bolt_merge(bolt_id: str, target: str, yes: bool):
    """Merge a completed bolt branch back to the intent branch."""
    _track("bolt merge", yes=yes)
    from aidlc_kit.git import (
        current_branch, delete_branch, is_intent_branch,
        merge, parse_intent_slug, bolt_branch_name,
    )

    target_path = Path(target).resolve()
    _require_git(target_path)
    _require_clean(target_path)

    cur = current_branch(target_path)
    if not is_intent_branch(cur):
        raise click.ClickException(
            f"Must be on the intent branch to merge bolts (current: {cur})."
        )

    slug = parse_intent_slug(cur)
    branch = bolt_branch_name(slug, bolt_id)

    if not merge(branch, target_path):
        click.echo("⚠ Merge conflicts detected. Resolve them manually, then run:")
        click.echo(f"  git add -A && git commit")
        click.echo(f"  git branch -d {branch}")
        return

    delete_branch(branch, target_path)
    click.echo(f"✓ Bolt {bolt_id} merged into intent branch.")
