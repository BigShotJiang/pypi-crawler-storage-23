"""Git operations for parallel intents and bolts."""

from __future__ import annotations

import re
import subprocess
from pathlib import Path


def _run(*args: str, cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args], capture_output=True, text=True, cwd=cwd,
    )


def _clean_error(msg: str) -> str:
    return msg.removeprefix("fatal:").removeprefix("error:").strip()


def is_git_repo(cwd: Path | None = None) -> bool:
    return _run("rev-parse", "--is-inside-work-tree", cwd=cwd).returncode == 0


def current_branch(cwd: Path | None = None) -> str:
    r = _run("rev-parse", "--abbrev-ref", "HEAD", cwd=cwd)
    return r.stdout.strip() if r.returncode == 0 else ""


def is_clean(cwd: Path | None = None) -> bool:
    return _run("diff", "--quiet", "HEAD", cwd=cwd).returncode == 0


def create_and_switch(name: str, cwd: Path | None = None) -> None:
    r = _run("checkout", "-b", name, cwd=cwd)
    if r.returncode != 0:
        raise RuntimeError(_clean_error(r.stderr.strip()))


def switch(name: str, cwd: Path | None = None) -> None:
    r = _run("checkout", name, cwd=cwd)
    if r.returncode != 0:
        raise RuntimeError(_clean_error(r.stderr.strip()))


def merge(source: str, cwd: Path | None = None) -> bool:
    """Merge source into current branch. Returns True if clean, False if conflicts."""
    r = _run("merge", source, "--no-edit", cwd=cwd)
    return r.returncode == 0


def delete_branch(name: str, cwd: Path | None = None) -> None:
    _run("branch", "-d", name, cwd=cwd)


def list_branches(prefix: str, cwd: Path | None = None) -> list[str]:
    r = _run("branch", "--list", f"{prefix}*", "--format=%(refname:short)", cwd=cwd)
    if r.returncode != 0:
        return []
    return [b.strip() for b in r.stdout.splitlines() if b.strip()]


def commit_all(message: str, cwd: Path | None = None) -> None:
    _run("add", "-A", cwd=cwd)
    _run("commit", "-m", message, "--allow-empty", cwd=cwd)


def slugify(name: str) -> str:
    s = name.lower().strip()
    s = re.sub(r"[^a-z0-9]+", "-", s)
    return s.strip("-")


# --- Branch convention helpers ---

INTENT_PREFIX = "aidlc/intent/"


def intent_branch_name(slug: str) -> str:
    return f"{INTENT_PREFIX}{slug}"


def bolt_branch_name(intent_slug: str, bolt_id: str) -> str:
    return f"{INTENT_PREFIX}{intent_slug}--bolt-{bolt_id}"


def parse_intent_slug(branch: str) -> str | None:
    """Extract intent slug from an intent or bolt branch name."""
    if not branch.startswith(INTENT_PREFIX):
        return None
    rest = branch[len(INTENT_PREFIX):]
    # If it's a bolt branch: slug--bolt-N → return slug
    if "--bolt-" in rest:
        return rest.split("--bolt-")[0]
    return rest


def is_intent_branch(branch: str) -> bool:
    return branch.startswith(INTENT_PREFIX) and "--bolt-" not in branch


def is_bolt_branch(branch: str) -> bool:
    return branch.startswith(INTENT_PREFIX) and "--bolt-" in branch
