"""LLM client layer for Riverse."""
