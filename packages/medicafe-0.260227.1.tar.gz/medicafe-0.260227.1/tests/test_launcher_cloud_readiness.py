#!/usr/bin/env python
"""
Unit tests for launcher Cloud Readiness flows.
Tests ensure_lab_ready wiring and Phase F advanced menu prompt/validation/confirm.
"""
from __future__ import print_function

import os
import sys
import unittest

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def _make_orchestrator():
    """Create MediCafeOrchestrator with minimal session config."""
    from MediCafe.launcher import MediCafeOrchestrator, SessionConfig
    args = MagicMock()
    args.skip_csv = False
    args.direct_action = None
    args.debug_mode = False
    args.auto_choice = None
    session = SessionConfig(args)
    return MediCafeOrchestrator(session)


class TestStrictRebuildFlow(unittest.TestCase):
    """Strict rebuild (Phase F advanced option 2) prompt/validation/confirm."""

    def test_strict_empty_input_cancels(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', '', '', '0']
                orch = _make_orchestrator()
                orch._phase_f_advanced_menu()
        cr.run_phase_f_manual_for_run_id.assert_not_called()

    def test_strict_valid_run_id_calls_service(self):
        from MediCafe import launcher as launcher_mod
        valid_rid = '20250216-120000-abc12345'
        cr = MagicMock()
        cr.run_phase_f_manual_for_run_id = MagicMock(return_value=(True, '', None))
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', valid_rid, '', '0']
                orch = _make_orchestrator()
                orch._phase_f_advanced_menu()
            cr.run_phase_f_manual_for_run_id.assert_called_once()
            call_args = cr.run_phase_f_manual_for_run_id.call_args[0]
            self.assertEqual(call_args[3], valid_rid)

    def test_strict_non_standard_decline_cancels(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.run_phase_f_manual_for_run_id = MagicMock()
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', 'non-standard-id', 'n', '', '0']
                orch = _make_orchestrator()
                orch._phase_f_advanced_menu()
            cr.run_phase_f_manual_for_run_id.assert_not_called()

    def test_strict_non_standard_accept_calls_service(self):
        from MediCafe import launcher as launcher_mod
        non_standard_rid = 'custom-run-123'
        cr = MagicMock()
        cr.run_phase_f_manual_for_run_id = MagicMock(return_value=(True, '', None))
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', non_standard_rid, 'y', '', '0']
                orch = _make_orchestrator()
                orch._phase_f_advanced_menu()
            cr.run_phase_f_manual_for_run_id.assert_called_once()
            call_args = cr.run_phase_f_manual_for_run_id.call_args[0]
            self.assertEqual(call_args[3], non_standard_rid)


class TestCloudReadinessAdvancedMenuEnsureLabReady(unittest.TestCase):
    """_cloud_readiness_advanced_menu calls ensure_lab_ready before rendering."""

    def test_calls_ensure_lab_ready_once_before_rendering(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['0']
                orch = _make_orchestrator()
                orch._cloud_readiness_advanced_menu()
        cr.ensure_lab_ready.assert_called_once()
        call_args = cr.ensure_lab_ready.call_args[0]
        self.assertEqual(call_args[0], orch.repo_root)
        self.assertEqual(call_args[1], orch.python_exe)
        self.assertEqual(call_args[2], orch.environment)

    def test_menu_renders_on_failure_warning_printed(self):
        from MediCafe import launcher as launcher_mod
        printed = []

        def _capture_print(*args, **kwargs):
            printed.append(' '.join(str(a) for a in args))

        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(False, 'Phase A bootstrap failed', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                with patch.object(launcher_mod.MediCafeOrchestrator, '_clear_console'):
                    with patch.object(launcher_mod.MediCafeOrchestrator, '_print_legacy_banner'):
                        with patch.object(launcher_mod.MediCafeOrchestrator, '_print_troubleshooting_group'):
                            with patch('__builtin__.print' if sys.version_info[0] < 3 else 'builtins.print', side_effect=_capture_print):
                                mock_prompt.side_effect = ['0']
                                orch = _make_orchestrator()
                                orch._cloud_readiness_advanced_menu()
        cr.get_health_lines.assert_called()
        warning_lines = [p for p in printed if '[WARNING]' in p and 'Phase A bootstrap failed' in p]
        self.assertEqual(len(warning_lines), 1)

    def test_manual_pipeline_letter_alias_b_triggers_phase_b(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._run_phase_b_discovery_manual = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['B', '', '0']
                orch._cloud_readiness_advanced_menu()
        orch._run_phase_b_discovery_manual.assert_called_once()


    def test_triage_option_runs_and_prints_hints(self):
        from MediCafe import launcher as launcher_mod
        printed = []

        def _capture_print(*args, **kwargs):
            printed.append(' '.join(str(a) for a in args))

        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        cr.run_system_health_triage = MagicMock(return_value=(
            True,
            'System health triage completed.',
            {'hints': ['XP QA reject ratio: 0.21 (warn)', 'Hint: review latest qa_reject_samples_*.jsonl for unresolved QA rejects.']},
        ))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                with patch('__builtin__.print' if sys.version_info[0] < 3 else 'builtins.print', side_effect=_capture_print):
                    mock_prompt.side_effect = ['1', '', '0']
                    orch = _make_orchestrator()
                    orch._cloud_readiness_advanced_menu()
        cr.run_system_health_triage.assert_called_once()
        rendered = '\n'.join(printed)
        self.assertIn('Manual validation quick hints', rendered)
        self.assertIn('unresolved QA rejects', rendered)

    def test_send_pack_failure_opens_delivery_diagnostics(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        cr.send_latest_system_health_pack = MagicMock(return_value=(False, 'send failed', {}))
        cr.open_report_delivery_status = MagicMock(return_value=(True, '', os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'report_delivery_status.txt')))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['3', '', '0']
                orch._cloud_readiness_advanced_menu()
        cr.send_latest_system_health_pack.assert_called_once()
        cr.open_report_delivery_status.assert_called()

    def test_guided_patient_completeness_option_runs_letter_flow(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        cr.get_guided_patient_completeness_options = MagicMock(return_value=(
            True,
            'Guided patient completeness options ready.',
            {
                'runbook_lines': ['Guided Patient Completeness Runbook:', ' - data_plane_status=WARN'],
                'options': [{
                    'code': 'A',
                    'title': 'Highest-Risk Completeness Gap',
                    'display_id': '12345',
                    'risk_label': 'HIGH',
                    'reason': 'Highest risk score across chain completeness.',
                    'context_run_id': '20260219-071129-5d5c869f',
                }],
            },
        ))
        cr.open_guided_patient_completeness_runbook = MagicMock(return_value=(
            True,
            'Patient completeness runbook generated.',
            os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'patient_completeness_runbook_latest.txt'),
        ))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['4', 'A', '', '0']
                orch._cloud_readiness_advanced_menu()
        cr.get_guided_patient_completeness_options.assert_called_once()
        cr.open_guided_patient_completeness_runbook.assert_called_once_with(orch.repo_root, 'A')
        orch._launch_viewer.assert_called_once()

    def test_guided_patient_completeness_no_patient_rows_prints_guidance(self):
        from MediCafe import launcher as launcher_mod
        printed = []

        def _capture_print(*args, **kwargs):
            printed.append(' '.join(str(a) for a in args))

        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        cr.get_guided_patient_completeness_options = MagicMock(return_value=(
            False,
            'Guided patient completeness unavailable due to current data-state (0 patient rows). Launcher is healthy; review runbook actions below.',
            {
                'condition': 'no_patient_rows',
                'runbook_lines': [
                    'Guided Patient Completeness Runbook:',
                    ' - patient_count=0',
                    ' - qa_reject_count=4',
                    ' - replay_pending_count=4',
                    ' - projection_success_count=0',
                    'What To Do Now:',
                    ' 1) Review QA rejects/replay queue first.',
                    ' 2) Re-open option 4 after data-state changes are applied.',
                ],
                'actions': [
                    'Review QA rejects/replay queue first.',
                    'Re-open option 4 after data-state changes are applied.',
                ],
                'options': [],
            },
        ))
        cr.open_guided_patient_completeness_runbook = MagicMock()
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                with patch('__builtin__.print' if sys.version_info[0] < 3 else 'builtins.print', side_effect=_capture_print):
                    mock_prompt.side_effect = ['4', '', '0']
                    orch = _make_orchestrator()
                    orch._cloud_readiness_advanced_menu()
        cr.get_guided_patient_completeness_options.assert_called_once()
        cr.open_guided_patient_completeness_runbook.assert_not_called()
        rendered = '\n'.join(printed)
        self.assertIn('Guided runbook context:', rendered)
        self.assertIn('patient_count=0', rendered)
        self.assertIn('What To Do Now:', rendered)
        self.assertIn('Re-open option 4', rendered)
        self.assertEqual(rendered.count('What To Do Now:'), 1)



    def test_patient_flow_runbook_option_opens_for_reference(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        cr.get_patient_flow_reference_options = MagicMock(return_value=(
            True,
            'Patient flow reference options ready.',
            {'options': [{
                'index': 1,
                'display_id': '33333',
                'patient_ref': '33333',
                'risk_label': 'HIGH',
                'risk_score': 80,
            }]},
        ))
        cr.open_patient_flow_runbook = MagicMock(return_value=(
            True,
            'Patient flow runbook generated.',
            os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'patient_completeness_runbook_latest.txt'),
        ))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['5', '1', '', '0']
                orch._cloud_readiness_advanced_menu()
        cr.get_patient_flow_reference_options.assert_called_once_with(orch.repo_root, limit=12)
        cr.open_patient_flow_runbook.assert_called_once_with(orch.repo_root, '33333')
        orch._launch_viewer.assert_called_once()

    def test_artifact_tools_letter_a_opens_latest_triage_pack(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._open_latest_artifact_triage_pack = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['A', '', '0']
                orch._cloud_phase_artifacts_menu()
        orch._open_latest_artifact_triage_pack.assert_called_once()

    def test_artifact_tools_letter_d_opens_run_id_index(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._open_run_artifact_index_for_run_id = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['D', '20260219-064740-157a78b1', '', '0']
                orch._cloud_phase_artifacts_menu()
        orch._open_run_artifact_index_for_run_id.assert_called_once_with('20260219-064740-157a78b1')

    def test_manual_pipeline_letter_alias_a_triggers_full_pipeline(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._run_shadow_pipeline = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['a', '', '0']
                orch._cloud_readiness_advanced_menu()
        orch._run_shadow_pipeline.assert_called_once()


if __name__ == '__main__':
    unittest.main()
