#!/usr/bin/env python
"""
Test Configuration
Centralized configuration for all MediCafe tests.
"""

import os
import sys

# Project paths
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TESTS_DIR = os.path.join(PROJECT_ROOT, "tests")

# Test categories
TEST_CATEGORIES = {
    "api": os.path.join(TESTS_DIR, "api"),
    "validation": os.path.join(TESTS_DIR, "validation"),
    "integration": os.path.join(TESTS_DIR, "integration"),
    "utils": os.path.join(TESTS_DIR, "utils")
}

# Test settings
TEST_TIMEOUT = 300  # seconds
TEST_OUTPUT_DIR = os.path.join(TESTS_DIR, "output")
TEST_LOG_DIR = os.path.join(TESTS_DIR, "logs")

# Ensure output directories exist
for directory in [TEST_OUTPUT_DIR, TEST_LOG_DIR]:
    if not os.path.exists(directory):
        os.makedirs(directory)

# Test data paths
TEST_DATA_DIR = os.path.join(TESTS_DIR, "test_data")
SAMPLE_DOCX_PATH = os.path.join(TEST_DATA_DIR, "sample.docx")

# API test settings
API_TEST_SETTINGS = {
    "test_payer_id": "87726",
    "test_provider_npi": "1234567890",
    "test_provider_tax_id": "123456789",
    "test_patient_info": {
        "payerId": "TEST_PAYER_ID",
        "providerLastName": "Doe",
        "providerFirstName": "John",
        "providerNpi": "1234567890",
        "providerTaxId": "123456789",
        "patientLastName": "Smith",
        "patientFirstName": "Jane",
        "patientBirthDate": "1980-01-01",
        "patientGender": "F"
    }
}

# Logging settings
LOG_LEVELS = ["DEBUG", "INFO", "WARNING", "ERROR"]
DEFAULT_LOG_LEVEL = "INFO"

def setup_test_environment():
    """Setup the test environment"""
    # Add project root to Python path
    if PROJECT_ROOT not in sys.path:
        sys.path.insert(0, PROJECT_ROOT)
    
    # Add MediLink and MediBot directories
    medilink_dir = os.path.join(PROJECT_ROOT, "MediLink")
    medicare_dir = os.path.join(PROJECT_ROOT, "MediBot")
    
    for directory in [medilink_dir, medicare_dir]:
        if directory not in sys.path and os.path.exists(directory):
            sys.path.insert(0, directory)

def get_test_file_path(category, filename):
    """Get the full path to a test file"""
    if category not in TEST_CATEGORIES:
        raise ValueError("Unknown test category: {}".format(category))
    
    return os.path.join(TEST_CATEGORIES[category], filename)

def get_test_files(category):
    """Get all test files in a category"""
    if category not in TEST_CATEGORIES:
        return []
    
    category_dir = TEST_CATEGORIES[category]
    if not os.path.exists(category_dir):
        return []
    
    test_files = []
    for filename in os.listdir(category_dir):
        if filename.endswith('.py') and not filename.startswith('__'):
            test_files.append(filename)
    
    return sorted(test_files)
