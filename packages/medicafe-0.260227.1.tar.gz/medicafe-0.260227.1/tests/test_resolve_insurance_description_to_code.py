# tests/test_resolve_insurance_description_to_code.py
"""
Unit tests for resolve_insurance_description_to_code (MediLink_insurance_utils).
Tests exact match, starts_with, contains, no match, and empty/config missing.
Python 3.4.4 compatible; uses unittest.mock.
"""

import os
import sys
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# Minimal insurance_options used when load_configuration is patched
TEST_INSURANCE_OPTIONS = {
    "12": "Preferred Provider Organization (PPO)",
    "13": "Point of Service (POS)",
    "CI": "Commercial Insurance Co.",
    "HM": "Health Maintenance Organization",
}
TEST_CONFIG = {"MediLink_Config": {"insurance_options": TEST_INSURANCE_OPTIONS}}

def _mock_load_configuration():
    return (TEST_CONFIG, None)


def _mock_load_configuration_empty():
    return ({"MediLink_Config": {}}, None)


@unittest.skipUnless(
    __import__("sys").version_info >= (3, 4),
    "unittest.mock or mock required"
)
class TestResolveInsuranceDescriptionToCode(unittest.TestCase):
    """Unit tests for resolve_insurance_description_to_code."""

    @patch("MediLink.MediLink_insurance_utils.MediLink_ConfigLoader.load_configuration", side_effect=_mock_load_configuration)
    def test_exact_match_returns_code(self, _mock_load):
        """Exact match e.g. 'Preferred Provider Organization (PPO)' -> '12'."""
        from MediLink.MediLink_insurance_utils import resolve_insurance_description_to_code
        code, ok = resolve_insurance_description_to_code("Preferred Provider Organization (PPO)")
        self.assertTrue(ok)
        self.assertEqual(code, "12")

    @patch("MediLink.MediLink_insurance_utils.MediLink_ConfigLoader.load_configuration", side_effect=_mock_load_configuration)
    def test_exact_match_case_insensitive(self, _mock_load):
        """Exact match is case-insensitive."""
        from MediLink.MediLink_insurance_utils import resolve_insurance_description_to_code
        code, ok = resolve_insurance_description_to_code("preferred provider organization (ppo)")
        self.assertTrue(ok)
        self.assertEqual(code, "12")

    @patch("MediLink.MediLink_insurance_utils.MediLink_ConfigLoader.load_configuration", side_effect=_mock_load_configuration)
    def test_starts_with_returns_code(self, _mock_load):
        """starts_with e.g. 'Commercial' -> 'CI' (Commercial Insurance Co.)."""
        from MediLink.MediLink_insurance_utils import resolve_insurance_description_to_code
        code, ok = resolve_insurance_description_to_code("Commercial")
        self.assertTrue(ok)
        self.assertEqual(code, "CI")

    @patch("MediLink.MediLink_insurance_utils.MediLink_ConfigLoader.load_configuration", side_effect=_mock_load_configuration)
    def test_contains_returns_code(self, _mock_load):
        """contains e.g. 'PPO' in description -> '12'."""
        from MediLink.MediLink_insurance_utils import resolve_insurance_description_to_code
        code, ok = resolve_insurance_description_to_code("PPO")
        self.assertTrue(ok)
        self.assertEqual(code, "12")

    @patch("MediLink.MediLink_insurance_utils.MediLink_ConfigLoader.load_configuration", side_effect=_mock_load_configuration)
    def test_no_match_returns_none(self, _mock_load):
        """Unknown description returns (None, False)."""
        from MediLink.MediLink_insurance_utils import resolve_insurance_description_to_code
        code, ok = resolve_insurance_description_to_code("Unknown Plan")
        self.assertFalse(ok)
        self.assertIsNone(code)

    @patch("MediLink.MediLink_insurance_utils.MediLink_ConfigLoader.load_configuration", side_effect=_mock_load_configuration)
    def test_empty_input_returns_none(self, _mock_load):
        """Empty or whitespace input returns (None, False)."""
        from MediLink.MediLink_insurance_utils import resolve_insurance_description_to_code
        for value in ("", "   ", None):
            code, ok = resolve_insurance_description_to_code(value)
            self.assertFalse(ok)
            self.assertIsNone(code)

    @patch("MediLink.MediLink_insurance_utils.MediLink_ConfigLoader.load_configuration", side_effect=_mock_load_configuration_empty)
    def test_config_missing_insurance_options_returns_none(self, _mock_load):
        """Missing or empty insurance_options returns (None, False)."""
        from MediLink.MediLink_insurance_utils import resolve_insurance_description_to_code
        code, ok = resolve_insurance_description_to_code("PPO")
        self.assertFalse(ok)
        self.assertIsNone(code)


if __name__ == "__main__":
    unittest.main()
