import os
import json
import tempfile
import unittest

from MediCafe.cloud_readiness_health import build_cloud_health_lines


class TestCloudReadinessHealthPhaseF(unittest.TestCase):
    def test_phase_f_detail_includes_lock_diag_suffix(self):
        lab_root = tempfile.mkdtemp()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "pipeline_state": "failed",
                        "last_shadow_pipeline_run_id": "run-1",
                        "last_shadow_pipeline_failed_phase": "F",
                        "last_shadow_pipeline_error_code": "PHASE_F_LOCK_FAIL",
                        "last_phase_f_lock_diag_path": os.path.join(lab_root, "reports", "phase_f_lock_diag_run-1_20260101T000000Z.json"),
                    },
                    f,
                    indent=2,
                )
            lines = build_cloud_health_lines(lab_root, auto_pipeline=True, auto_health=True)
            joined = "\n".join(lines)
            self.assertIn("err=PHASE_F_LOCK_FAIL", joined)
            self.assertIn("lock_diag=phase_f_lock_diag_run-1_20260101T000000Z.json", joined)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_rows_use_v2_phase_run_id_map(self):
        lab_root = tempfile.mkdtemp()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_shadow_pipeline_phase_run_ids": {
                            "B": "rid-b",
                            "C": "rid-c",
                            "D": "rid-d",
                            "E": "rid-e",
                        },
                        "last_shadow_pipeline_ok": False,
                        "last_shadow_pipeline_failed_phase": "E",
                        "last_shadow_pipeline_error_code": "PHASE_E_DB_WRITE_ERROR",
                    },
                    f,
                    indent=2,
                )
            lines = build_cloud_health_lines(lab_root, auto_pipeline=True, auto_health=True)
            joined = "\n".join(lines)
            self.assertIn("B:?", joined)
            self.assertIn("run_id=rid-b", joined)
            self.assertIn("C:?", joined)
            self.assertIn("run_id=rid-c", joined)
            self.assertIn("D:?", joined)
            self.assertIn("run_id=rid-d", joined)
            self.assertIn("E:?", joined)
            self.assertIn("run_id=rid-e", joined)
            self.assertNotIn("state=not_run", joined)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_pending_phase_rows_render_as_running_during_active_pipeline(self):
        lab_root = tempfile.mkdtemp()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "pipeline_state": "running",
                        "active_phase": "C",
                        "active_run_id": "rid-active",
                        "last_shadow_pipeline_run_id": "rid-active",
                        "last_shadow_pipeline_phase_run_ids": {"B": "rid-b"},
                    },
                    f,
                    indent=2,
                )
            lines = build_cloud_health_lines(lab_root, auto_pipeline=True, auto_health=True)
            joined = "\n".join(lines)
            self.assertIn("state=awaiting_phase_write", joined)
            self.assertNotIn("PHASE_D_NOT_RUN", joined)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
