# tests/test_reconciliation.py
"""
Unit tests for reconciliation gate (submission vs remittance).
Tests normalization, adapters, classification, severity, and robustness.
Python 3.4.4 compatible.
"""
import os
import sys
import tempfile
import unittest

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from MediCafe.reconciliation import (
    normalize_patient_id,
    normalize_payer_id,
    normalize_dos,
    adapter_submission_index,
    adapter_submission_attempt,
    adapter_remittance,
    load_submission_index,
    load_remittance_parsed,
    evaluate_gate_severity,
    run_reconciliation,
    SEVERITY_PASS,
    SEVERITY_WARN,
    SEVERITY_FAIL,
)

# claim_key format: 4 parts (patient|payer_or_primary|dos|service_hash) per submission_index.compute_claim_key
FIXTURE_SUBMISSION_INDEX = [
    {"claim_key": "12345|62308|20250101|00142", "patient_id": "12345", "payer_id": "62308", "dos": "20250101", "notes": ""},
]
FIXTURE_REMITTANCE_PARSED = [
    {"patid": "12345", "dos": "20250101", "payer_id": "62308", "claim_number": "CHART12320250101", "status": "Accepted", "paid": "60.00"},
]


class TestNormalizeDos(unittest.TestCase):
    """Tests for normalize_dos."""

    def test_normalize_dos_yyyymmdd(self):
        self.assertEqual(normalize_dos('20250101'), '20250101')

    def test_normalize_dos_iso(self):
        self.assertEqual(normalize_dos('2025-01-01'), '20250101')

    def test_normalize_dos_slash(self):
        self.assertEqual(normalize_dos('01/15/2025'), '20250115')

    def test_normalize_dos_invalid_empty(self):
        self.assertEqual(normalize_dos(''), '')
        self.assertEqual(normalize_dos(None), '')

    def test_normalize_dos_invalid_string(self):
        self.assertEqual(normalize_dos('x'), '')


class TestAdapters(unittest.TestCase):
    """Tests for record adapters."""

    def test_adapter_submission_index(self):
        raw = FIXTURE_SUBMISSION_INDEX[0]
        result = adapter_submission_index(raw)
        self.assertIsNotNone(result)
        key, enriched = result
        self.assertEqual(key, ('12345', '20250101', '62308'))
        self.assertEqual(enriched.get('source'), 'submission_index')

    def test_adapter_remittance(self):
        raw = FIXTURE_REMITTANCE_PARSED[0]
        result = adapter_remittance(raw)
        self.assertIsNotNone(result)
        key, enriched = result
        self.assertEqual(key, ('12345', '20250101', '62308'))
        self.assertEqual(enriched.get('source'), 'remittance_parsed')

    def test_adapter_submission_attempt(self):
        claim_key = "12345|62308|20250101|00142"
        raw = {"claim_key": claim_key, "status": "submitted", "attempt_at": 1234567890}
        result = adapter_submission_attempt(claim_key, raw, {})
        self.assertIsNotNone(result)
        key, enriched = result
        self.assertEqual(key, ('12345', '20250101', '62308'))


class TestClassification(unittest.TestCase):
    """Tests for classification logic via run_reconciliation."""

    def test_classify_missing_remittance(self):
        """Submission only -> missing_remittance."""
        with tempfile.TemporaryDirectory() as tmp:
            receipts = os.path.join(tmp, 'receipts')
            storage = os.path.join(tmp, 'storage')
            os.makedirs(receipts)
            os.makedirs(storage)
            idx_path = os.path.join(receipts, 'submission_index.jsonl')
            with open(idx_path, 'w') as f:
                f.write('{"claim_key":"12345|62308|20250101|00142","patient_id":"12345","payer_id":"62308","dos":"20250101","notes":""}\n')
            config = {"MediLink_Config": {"local_claims_path": receipts, "local_storage_path": storage}}
            result = run_reconciliation(config, receipts, storage)
            self.assertEqual(len(result['findings']['missing_remittance']), 1)
            self.assertEqual(result['findings']['missing_remittance'][0]['patient_id'], '12345')

    def test_classify_orphan_remittance(self):
        """Remittance only -> orphan_remittance."""
        with tempfile.TemporaryDirectory() as tmp:
            receipts = os.path.join(tmp, 'receipts')
            storage = os.path.join(tmp, 'storage')
            os.makedirs(receipts)
            os.makedirs(storage)
            rem_path = os.path.join(storage, 'remittance_parsed.jsonl')
            with open(rem_path, 'w') as f:
                f.write('{"patid":"99999","dos":"20250101","payer_id":"62308","claim_number":"CHART99920250101"}\n')
            config = {"MediLink_Config": {"local_claims_path": receipts, "local_storage_path": storage}}
            result = run_reconciliation(config, receipts, storage)
            self.assertEqual(len(result['findings']['orphan_remittance']), 1)
            self.assertEqual(result['findings']['orphan_remittance'][0]['patient_id'], '99999')

    def test_classify_duplicate_remittance(self):
        """2 remittance records same key -> duplicate_remittance."""
        with tempfile.TemporaryDirectory() as tmp:
            receipts = os.path.join(tmp, 'receipts')
            storage = os.path.join(tmp, 'storage')
            os.makedirs(receipts)
            os.makedirs(storage)
            rem_path = os.path.join(storage, 'remittance_parsed.jsonl')
            with open(rem_path, 'w') as f:
                f.write('{"patid":"12345","dos":"20250101","payer_id":"62308","claim_number":"CHART12320250101"}\n')
                f.write('{"patid":"12345","dos":"20250101","payer_id":"62308","claim_number":"CHART12320250101"}\n')
            config = {"MediLink_Config": {"local_claims_path": receipts, "local_storage_path": storage}}
            result = run_reconciliation(config, receipts, storage)
            self.assertEqual(len(result['findings']['duplicate_remittance']), 1)


class TestSeverity(unittest.TestCase):
    """Tests for evaluate_gate_severity."""

    def test_severity_pass(self):
        findings = {'missing_remittance': [], 'duplicate_remittance': [], 'amount_status_mismatch': [], 'orphan_remittance': []}
        totals = {'submissions': 5, 'remittances': 5}
        self.assertEqual(evaluate_gate_severity(findings, totals), SEVERITY_PASS)

    def test_severity_warn(self):
        findings = {'missing_remittance': [{}], 'duplicate_remittance': [], 'amount_status_mismatch': [], 'orphan_remittance': []}
        totals = {'submissions': 10, 'remittances': 9}
        self.assertEqual(evaluate_gate_severity(findings, totals), SEVERITY_WARN)

    def test_severity_fail(self):
        findings = {'missing_remittance': [{}, {}, {}, {}, {}], 'duplicate_remittance': [], 'amount_status_mismatch': [], 'orphan_remittance': []}
        totals = {'submissions': 10, 'remittances': 5}
        self.assertEqual(evaluate_gate_severity(findings, totals), SEVERITY_FAIL)


class TestRobustness(unittest.TestCase):
    """Robustness tests."""

    def test_missing_submission_index_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            receipts = os.path.join(tmp, 'empty_receipts')
            storage = os.path.join(tmp, 'storage')
            os.makedirs(receipts)
            os.makedirs(storage)
            config = {"MediLink_Config": {"local_claims_path": receipts, "local_storage_path": storage}}
            result = run_reconciliation(config, receipts, storage)
            self.assertEqual(result['totals']['submissions'], 0)
            self.assertIn('severity', result)

    def test_missing_remittance_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            receipts = os.path.join(tmp, 'receipts')
            storage = os.path.join(tmp, 'storage')
            os.makedirs(receipts)
            os.makedirs(storage)
            config = {"MediLink_Config": {"local_claims_path": receipts, "local_storage_path": storage}}
            result = run_reconciliation(config, receipts, storage)
            self.assertEqual(result['totals']['remittances'], 0)

    def test_malformed_jsonl_row(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, 'submission_index.jsonl')
            with open(path, 'w') as f:
                f.write('{"valid": true}\n')
                f.write('{invalid json}\n')
                f.write('{"claim_key":"1|2|3|4","patient_id":"1","dos":"20250101","notes":""}\n')
            records = load_submission_index(tmp)
            self.assertEqual(len(records), 2)

    def test_deterministic_ordering(self):
        with tempfile.TemporaryDirectory() as tmp:
            storage = os.path.join(tmp, 'storage')
            os.makedirs(storage)
            rem_path = os.path.join(storage, 'remittance_parsed.jsonl')
            with open(rem_path, 'w') as f:
                f.write('{"patid":"B","dos":"20250102","payer_id":"2"}\n')
                f.write('{"patid":"A","dos":"20250101","payer_id":"1"}\n')
            config = {"MediLink_Config": {"local_claims_path": tmp, "local_storage_path": storage}}
            result1 = run_reconciliation(config, tmp, storage)
            result2 = run_reconciliation(config, tmp, storage)
            all1 = []
            for cat in ('missing_remittance', 'duplicate_remittance', 'amount_status_mismatch', 'orphan_remittance'):
                all1.extend(result1['findings'][cat])
            all2 = []
            for cat in ('missing_remittance', 'duplicate_remittance', 'amount_status_mismatch', 'orphan_remittance'):
                all2.extend(result2['findings'][cat])
            keys1 = [(f['category'], f['patient_id'], f['dos']) for f in sorted(all1, key=lambda x: (x['category'], x['patient_id'], x['dos']))]
            keys2 = [(f['category'], f['patient_id'], f['dos']) for f in sorted(all2, key=lambda x: (x['category'], x['patient_id'], x['dos']))]
            self.assertEqual(keys1, keys2)


if __name__ == '__main__':
    unittest.main()
