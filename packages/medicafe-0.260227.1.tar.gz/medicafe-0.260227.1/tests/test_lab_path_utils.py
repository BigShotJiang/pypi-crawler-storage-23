#!/usr/bin/env python
from __future__ import print_function

import os
import unittest

from scripts.unified_model.lab_path_utils import normalize_medicafe_lab_dir, resolve_lab_root


class TestLabPathUtils(unittest.TestCase):

    def test_normalize_repairs_windows_prefixed_value(self):
        got = normalize_medicafe_lab_dir('C: C:\\Python34\\Lib\\site-packages\\lab')
        self.assertEqual(got, 'C:\\Python34\\Lib\\site-packages\\lab')

    def test_normalize_appends_lab_for_site_packages(self):
        got = normalize_medicafe_lab_dir('C:/Python34/Lib/site-packages')
        self.assertEqual(got, os.path.normpath('C:/Python34/Lib/site-packages/lab'))

    def test_normalize_appends_lab_for_medicafe_package_dir(self):
        got = normalize_medicafe_lab_dir('C:/Python34/Lib/site-packages/MediCafe')
        self.assertEqual(got, os.path.normpath('C:/Python34/Lib/site-packages/MediCafe/lab'))


    def test_normalize_appends_lab_for_windows_backslash_medicafe_dir(self):
        got = normalize_medicafe_lab_dir(r'C:\Python34\Lib\site-packages\MediCafe')
        self.assertEqual(got, os.path.normpath(r'C:\Python34\Lib\site-packages\MediCafe/lab'))

    def test_resolve_prefers_explicit_arg(self):
        got = resolve_lab_root('tmp/labx', '/workspace/MediCafe')
        self.assertTrue(got.endswith(os.path.normpath('tmp/labx')))


if __name__ == '__main__':
    unittest.main()
