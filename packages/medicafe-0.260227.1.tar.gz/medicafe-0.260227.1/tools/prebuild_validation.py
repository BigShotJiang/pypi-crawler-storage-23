#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Strict pre-build validation for MediCafe packaging continuity.

Checks:
1) setup.py console entry points resolve to callable targets.
2) Top-level packages declared via find_packages(include=...) import cleanly.
3) Critical MediLink_DataMgmt contract attributes exist.

This script is read-only and exits non-zero on any failure.
"""

from __future__ import print_function

import argparse
import ast
import importlib
import os
import sys

# Ensure project root is in path for tools.build_colors
_script_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.dirname(_script_dir)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)
from tools.build_colors import bold, dim, fail, green_bold, pass_, step


REQUIRED_DATAMGMT_ATTRS = [
    'read_general_fixed_width_data',
    'read_fixed_width_data',
    'parse_fixed_width_data',
]


def _node_to_text(node):
    if isinstance(node, ast.Str):
        return node.s
    if hasattr(ast, 'Constant') and isinstance(node, ast.Constant):
        if isinstance(node.value, str):
            return node.value
    return None


def _func_name(call_node):
    fn = call_node.func
    if isinstance(fn, ast.Name):
        return fn.id
    if isinstance(fn, ast.Attribute):
        return fn.attr
    return None


def _extract_string_list(node):
    if not isinstance(node, (ast.List, ast.Tuple)):
        return []
    values = []
    for elt in node.elts:
        text = _node_to_text(elt)
        if text is not None:
            values.append(text)
    return values


class SetupSpecExtractor(ast.NodeVisitor):
    def __init__(self):
        self.console_scripts = []
        self.package_include_patterns = []

    def visit_Call(self, node):
        name = _func_name(node)
        if name == 'setup':
            self._extract_setup_keywords(node)
        self.generic_visit(node)

    def _extract_setup_keywords(self, node):
        for kw in getattr(node, 'keywords', []):
            if kw.arg == 'entry_points':
                self.console_scripts = self._extract_console_scripts(kw.value)
            elif kw.arg == 'packages':
                self.package_include_patterns = self._extract_package_patterns(kw.value)

    def _extract_console_scripts(self, node):
        scripts = []
        if not isinstance(node, ast.Dict):
            return scripts

        for key_node, val_node in zip(node.keys, node.values):
            key_text = _node_to_text(key_node)
            if key_text == 'console_scripts':
                scripts.extend(_extract_string_list(val_node))
        return scripts

    def _extract_package_patterns(self, node):
        patterns = []
        if not isinstance(node, ast.Call):
            return patterns
        if _func_name(node) != 'find_packages':
            return patterns

        for kw in getattr(node, 'keywords', []):
            if kw.arg == 'include':
                patterns.extend(_extract_string_list(kw.value))
        return patterns


def parse_setup_spec(setup_path):
    try:
        with open(setup_path, 'r') as f:
            src = f.read()
    except Exception as exc:
        raise RuntimeError("Failed to read setup.py: {}".format(exc))

    try:
        tree = ast.parse(src, filename=setup_path)
    except SyntaxError as exc:
        raise RuntimeError("Failed to parse setup.py: {}".format(exc))

    extractor = SetupSpecExtractor()
    extractor.visit(tree)
    return extractor.console_scripts, extractor.package_include_patterns


def top_level_packages_from_patterns(patterns):
    tops = []
    seen = set()
    for pattern in patterns:
        if not pattern:
            continue
        top = pattern.split('.')[0]
        if '*' in top:
            top = top.replace('*', '')
        top = top.strip()
        if not top:
            continue
        if top not in seen:
            seen.add(top)
            tops.append(top)
    return tops


def validate_entry_points(console_scripts):
    if not console_scripts:
        raise RuntimeError("No console_scripts found in setup.py")

    print(step("[1/3]") + " Validating console entry points...")
    for spec in console_scripts:
        if '=' not in spec:
            raise RuntimeError("Invalid entry point format (missing '='): {}".format(spec))
        name, target = [part.strip() for part in spec.split('=', 1)]
        if ':' not in target:
            raise RuntimeError("Invalid entry point target (missing ':'): {}".format(spec))
        module_name, func_name = [part.strip() for part in target.split(':', 1)]
        if not module_name or not func_name:
            raise RuntimeError("Invalid entry point target in: {}".format(spec))

        try:
            module = importlib.import_module(module_name)
        except Exception as exc:
            raise RuntimeError("Entry point '{}' failed module import '{}': {}".format(name, module_name, exc))

        if not hasattr(module, func_name):
            raise RuntimeError("Entry point '{}' missing attribute '{}.{}'".format(name, module_name, func_name))
        func = getattr(module, func_name)
        if not callable(func):
            raise RuntimeError("Entry point '{}' target not callable '{}.{}'".format(name, module_name, func_name))

        print("  " + pass_("PASS") + " {} -> {}:{}".format(name, module_name, func_name))


def validate_packages(top_packages):
    if not top_packages:
        raise RuntimeError("No top-level packages derived from setup.py find_packages(include=...)")

    print(step("[2/3]") + " Validating package imports...")
    for package_name in top_packages:
        try:
            importlib.import_module(package_name)
        except Exception as exc:
            raise RuntimeError("Package import failed '{}': {}".format(package_name, exc))
        print("  " + pass_("PASS") + " import {}".format(package_name))


def validate_critical_contract():
    print(step("[3/3]") + " Validating critical module contract...")
    try:
        mod = importlib.import_module('MediLink.MediLink_DataMgmt')
    except Exception as exc:
        raise RuntimeError("Critical module import failed 'MediLink.MediLink_DataMgmt': {}".format(exc))

    missing = []
    for attr in REQUIRED_DATAMGMT_ATTRS:
        if not hasattr(mod, attr):
            missing.append(attr)
    if missing:
        raise RuntimeError("Critical module contract missing attributes: {}".format(", ".join(missing)))

    print("  " + pass_("PASS") + " MediLink.MediLink_DataMgmt contract")


def resolve_default_project_root(script_file):
    tools_dir = os.path.dirname(os.path.abspath(script_file))
    return os.path.dirname(tools_dir)


def main():
    parser = argparse.ArgumentParser(description="MediCafe strict pre-build validation")
    parser.add_argument('--project-root', default=None, help='Project root path (defaults to parent of tools/)')
    args = parser.parse_args()

    project_root = args.project_root or resolve_default_project_root(__file__)
    project_root = os.path.abspath(project_root)
    setup_path = os.path.join(project_root, 'setup.py')

    if not os.path.isfile(setup_path):
        print(fail("FAIL") + " setup.py not found at {}".format(setup_path))
        return 1

    if project_root not in sys.path:
        sys.path.insert(0, project_root)

    print(bold("MediCafe Pre-Build Validation"))
    print(dim("Project root: {}".format(project_root)))
    print(dim("Setup path: {}".format(setup_path)))

    try:
        console_scripts, package_patterns = parse_setup_spec(setup_path)
        top_packages = top_level_packages_from_patterns(package_patterns)

        validate_entry_points(console_scripts)
        validate_packages(top_packages)
        validate_critical_contract()

    except RuntimeError as exc:
        print(fail("FAIL") + " {}".format(exc))
        return 1
    except Exception as exc:
        print(fail("FAIL") + " Unexpected error: {}".format(exc))
        return 1

    print(green_bold("PASS All pre-build validation checks passed."))
    return 0


if __name__ == '__main__':
    sys.exit(main())
