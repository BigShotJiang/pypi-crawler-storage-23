﻿import os
from google.auth import default as get_default_credentials

print('=== ADC Credentials Check ===')
creds, project = get_default_credentials()
print('Project:', project)
print('Credentials type:', type(creds))
print('Has _refresh_token:', hasattr(creds, '_refresh_token'))
if hasattr(creds, '_refresh_token'):
    print('_refresh_token type:', type(creds._refresh_token))
    print('_refresh_token value:', repr(creds._refresh_token)[:100])
