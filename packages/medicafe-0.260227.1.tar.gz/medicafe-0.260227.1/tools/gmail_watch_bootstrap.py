#!/usr/bin/env python3
"""Register a Gmail watch using a service account with domain-wide delegation.

Use this when your setup uses a service account that impersonates the mailbox user
(domain-wide delegation). You need:
  - A service account JSON key file
  - The mailbox user (e.g. user@domain.com)
  - The full Pub/Sub topic name (projects/PROJECT_ID/topics/TOPIC_NAME)

For the more common user-OAuth flow (client_id, client_secret, refresh_token in
Secret Manager), use cloud/orchestrator/validate_and_complete_setup.py instead;
it will register the watch automatically when all three secrets are present and
Cloud Run is deployed.
"""

import argparse
import json
import sys

from google.oauth2 import service_account
from googleapiclient.discovery import build


SCOPES = [
    "https://www.googleapis.com/auth/gmail.modify",
    "https://www.googleapis.com/auth/gmail.readonly",
]


def parse_args(argv):
    parser = argparse.ArgumentParser(description="Bootstrap Gmail watch")
    parser.add_argument("--project", required=True, help="GCP project id")
    parser.add_argument("--service-account", required=True, help="Path to service account JSON")
    parser.add_argument("--mailbox", required=True, help="Mailbox to watch (user@domain)")
    parser.add_argument("--topic", required=True, help="Pub/Sub topic full name")
    parser.add_argument("--label", action="append", help="Optional Gmail label ids to filter")
    parser.add_argument("--label-filter-action", default="include", choices=["include", "exclude"], help="Filter behaviour")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv or sys.argv[1:])

    credentials = service_account.Credentials.from_service_account_file(
        args.service_account, scopes=SCOPES
    ).with_subject(args.mailbox)

    gmail = build("gmail", "v1", credentials=credentials, cache_discovery=False)

    body = {
        "topicName": args.topic,
        "labelFilterAction": args.label_filter_action,
    }
    if args.label:
        body["labelIds"] = args.label

    response = gmail.users().watch(userId="me", body=body).execute()
    print(json.dumps(response, indent=2))
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())

