#!/usr/bin/env python
"""
Cloud Readiness Pipeline service module.

Service-only: no UI. Launcher delegates phase actions here.
Returns (ok, message, data); no exceptions to caller.
Python 3.4 compatible.
"""
from __future__ import print_function

import json
import os
import re
import calendar
import sqlite3
import subprocess
import sys
import time
from MediCafe import shadow_orchestrator
from MediCafe import cloud_readiness_artifact_tools as _artifact_tools
from MediCafe import cloud_readiness_patient_tools as _patient_tools
from MediCafe import cloud_readiness_runbooks as _runbook_tools

try:
    from MediCafe.MediLink_ConfigLoader import log as mc_log
except Exception:
    mc_log = None

try:
    from MediCafe.cloud_readiness_health import build_cloud_health_lines
except Exception:
    build_cloud_health_lines = None

try:
    from MediCafe.error_reporter import (
        collect_support_bundle,
        submit_support_bundle_email,
        get_error_reporting_delivery_readiness,
    )
except Exception:
    collect_support_bundle = None
    submit_support_bundle_email = None
    get_error_reporting_delivery_readiness = None

try:
    from subprocess import DEVNULL
except ImportError:
    DEVNULL = open(os.devnull, 'wb')


_HEALTH_TRACKER_FILENAME = 'cloud_health_tracker.json'
_HEALTH_ALERT_STATE_FILENAME = 'cloud_health_alert_state.json'
_ORCHESTRATOR_ALERT_STATE_FILENAME = 'orchestrator_failure_alert_state.json'
_ORCHESTRATOR_ALERT_DEDUP_WINDOW_SEC = 10 * 60
_WARN_ESCALATION_MIN_COUNT = 3
_WARN_ESCALATION_MIN_AGE_SEC = 120
_ALERT_DEDUP_WINDOW_SEC = 6 * 60 * 60
# Bootstrap-only warn codes: expected before any pipeline run; do not escalate to incident alerts.
_WARN_NON_ESCALATING_CODES = frozenset([
    'DIAGNOSTICS_STATE_MISSING',
    'PHASE_B_NOT_RUN', 'PHASE_C_NOT_RUN', 'PHASE_D_NOT_RUN',
    'PHASE_E_NOT_RUN', 'PHASE_F_NOT_RUN',
])
_PHASE_ORDER = {'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5, 'F': 6}


def _seed_diagnostics_state_if_missing(state_path):
    """Best-effort bootstrap of diagnostics_state.json when absent."""
    if not state_path or os.path.exists(state_path):
        return False
    now_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    seed = {
        'version': 2,
        'updated_at_utc': now_utc,
        'last_phase_a_run_id': '',
        'last_phase_a_ok': None,
        'last_schema_sha256': '',
        'last_discovery_ok': None,
        'last_phase_c_ok': None,
        'last_phase_d_ok': None,
        'last_phase_e_ok': None,
        'last_shadow_pipeline_ok': None,
        'pipeline_state': 'idle',
        'active_run_id': '',
        'active_phase': '',
        'last_error_code': '',
        'started_at_utc': now_utc,
        'heartbeat_at_utc': None,
        'finished_at_utc': None,
    }
    return _save_json_dict(state_path, seed)


def _tail_parts_cross_platform(path_value):
    """Return (tail, parent_tail) while treating "\\" and "/" as path separators."""
    normalized = str(path_value or '').replace('\\', '/')
    parts = [p for p in normalized.split('/') if p]
    tail = parts[-1].lower() if parts else ''
    parent_tail = parts[-2].lower() if len(parts) >= 2 else ''
    return tail, parent_tail


def _log_health(level, message):
    """Best-effort logger for cloud readiness diagnostics."""
    try:
        if mc_log is not None:
            mc_log(message, level=level)
            return
    except Exception:
        pass
    try:
        print('{0}: {1}'.format(level, message))
    except Exception:
        pass


def _load_json_dict(path):
    if not path or not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except (IOError, OSError, ValueError):
        pass
    return {}


def _save_json_dict(path, data):
    try:
        parent = os.path.dirname(path)
        if parent and not os.path.exists(parent):
            os.makedirs(parent)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, sort_keys=True)
        return True
    except Exception:
        return False


def _collect_delivery_diagnostics():
    """Best-effort sender readiness snapshot for support-bundle telemetry."""
    diagnostics = {'token_available': None, 'recipient_count': None}
    if get_error_reporting_delivery_readiness is None:
        diagnostics['helper_unavailable'] = True
        return diagnostics
    try:
        shared = get_error_reporting_delivery_readiness(
            quiet_token=True,
            include_queue_paths=True,
        )
        if isinstance(shared, dict):
            diagnostics.update(shared)
    except Exception as e:
        diagnostics['helper_error'] = str(e)
    return diagnostics


def _format_epoch_utc(epoch_value):
    try:
        if epoch_value is None:
            return ''
        return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(int(epoch_value)))
    except Exception:
        return ''


def _parse_iso_utc_epoch(text_value):
    """Best-effort parse for %Y-%m-%dT%H:%M:%SZ timestamps."""
    try:
        text = str(text_value or '').strip()
        if not text:
            return None
        return int(calendar.timegm(time.strptime(text, '%Y-%m-%dT%H:%M:%SZ')))
    except Exception:
        return None


def _collect_failed_or_warned_signals(audit_payload):
    return _runbook_tools.collect_failed_or_warned_signals(audit_payload)


def _build_system_health_triage_runbook(audit_ok, audit_data, pack_ok, pack_path, report_path):
    return _runbook_tools.build_system_health_triage_runbook(
        audit_ok,
        audit_data,
        pack_ok,
        pack_path,
        report_path,
        collect_failed_or_warned_signals_fn=_collect_failed_or_warned_signals,
    )


def _build_system_health_pack_runbook(lab_root, audit_payload, artifacts):
    return _runbook_tools.build_system_health_pack_runbook(
        lab_root,
        audit_payload,
        artifacts,
        parse_iso_utc_epoch_fn=_parse_iso_utc_epoch,
        load_json_dict_fn=_load_json_dict,
    )


def _build_delivery_runbook_lines(delivery_diag):
    return _runbook_tools.build_delivery_runbook_lines(delivery_diag)


def _safe_json_loads(value, default=None):
    return _patient_tools.safe_json_loads(value, default=default)


def _safe_int(value, fallback=0):
    return _patient_tools.safe_int(value, fallback=fallback)


def _slug_token(value, fallback='unknown'):
    return _patient_tools.slug_token(value, fallback=fallback)


def _collect_data_plane_snapshot(lab_root):
    return _patient_tools.collect_data_plane_snapshot(
        lab_root,
        safe_int_fn=_safe_int,
    )


def _score_patient_chain_row(row):
    return _patient_tools.score_patient_chain_row(row, safe_int_fn=_safe_int)


def _collect_patient_chain_rows(conn, limit=200):
    return _patient_tools.collect_patient_chain_rows(
        conn,
        limit=limit,
        safe_int_fn=_safe_int,
        score_patient_chain_row_fn=_score_patient_chain_row,
    )


def _patient_display_id(row):
    return _patient_tools.patient_display_id(row)


def _build_guided_patient_options(rows, diagnostics_state):
    return _patient_tools.build_guided_patient_options(
        rows,
        diagnostics_state,
        safe_int_fn=_safe_int,
        patient_display_id_fn=_patient_display_id,
    )


def _find_patient_option_by_reference(rows, patient_ref):
    return _patient_tools.find_patient_option_by_reference(
        rows,
        patient_ref,
        safe_int_fn=_safe_int,
    )


def _build_guided_options_runbook_lines(snapshot, options):
    return _patient_tools.build_guided_options_runbook_lines(snapshot, options)


def _build_patient_reference_options(rows, limit=25):
    return _patient_tools.build_patient_reference_options(
        rows,
        limit=limit,
        safe_int_fn=_safe_int,
        patient_display_id_fn=_patient_display_id,
    )


def _build_no_patient_guidance_payload(snapshot, diagnostics_state, lab_root, db_path):
    """Build actionable runbook payload when guided patient rows are unavailable."""
    snap = snapshot if isinstance(snapshot, dict) else {}
    state = diagnostics_state if isinstance(diagnostics_state, dict) else {}
    counts = snap.get('counts', {}) if isinstance(snap.get('counts', {}), dict) else {}
    patient_count = _safe_int(counts.get('patient'), 0)
    qa_reject_count = _safe_int(snap.get('qa_reject_count'), 0)
    replay_pending_count = _safe_int(snap.get('replay_pending_count'), 0)
    projection_success_count = _safe_int(snap.get('projection_success_count'), 0)
    active_run_id = str(state.get('active_run_id', '') or '').strip()
    last_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    pipeline_state = str(state.get('pipeline_state', '') or '').strip().lower() or 'unknown'

    runbook_lines = [
        'Guided Patient Completeness Runbook:',
        ' - condition=no_patient_rows',
        ' - data_plane_status={0}'.format(snap.get('status', 'unknown')),
        ' - patient_count={0}'.format(patient_count),
        ' - qa_reject_count={0}'.format(qa_reject_count),
        ' - replay_pending_count={0}'.format(replay_pending_count),
        ' - projection_success_count={0}'.format(projection_success_count),
        ' - pipeline_state={0}'.format(pipeline_state),
        ' - active_run_id={0}'.format(active_run_id or '-'),
        ' - last_shadow_pipeline_run_id={0}'.format(last_run_id or '-'),
    ]

    actions = []
    actions.append(
        'No patient rows are currently materialized in the local XP DB. This is a data-state condition, not a launcher failure.'
    )
    if qa_reject_count > 0 or replay_pending_count > 0:
        actions.append(
            'Review QA rejects/replay queue first (qa_reject_count={0}, replay_pending_count={1}) and clear pending replay items.'.format(
                qa_reject_count, replay_pending_count
            )
        )
    if projection_success_count <= 0:
        actions.append(
            'Inspect latest Phase E projection/parity outputs for zero patient projections before rerunning guided completeness.'
        )
    if active_run_id:
        actions.append(
            'Pipeline is active (run_id={0}); wait for completion, then reopen Guided Patient Completeness Runbook.'.format(
                active_run_id
            )
        )
    elif last_run_id:
        actions.append(
            'Inspect run-scoped evidence for run_id={0} via Cloud Phase Artifact Tools (A/B), then re-run full shadow pipeline (A->F) if still empty.'.format(
                last_run_id
            )
        )
    else:
        actions.append(
            'No prior pipeline run ID is recorded; trigger full shadow pipeline (A->F), then reopen Guided Patient Completeness Runbook.'
        )
    actions.append('Re-open option 4 after data-state changes are applied.')
    action_lines = ['What To Do Now:']
    step = 1
    for item in actions:
        action_lines.append(' {0}) {1}'.format(step, item))
        step += 1
    runbook_lines.extend(action_lines)

    return {
        'condition': 'no_patient_rows',
        'lab_root': lab_root,
        'db_path': db_path,
        'snapshot': snap,
        'diagnostics_state': state,
        'options': [],
        'runbook_lines': runbook_lines,
        'actions': actions,
    }


def get_guided_patient_completeness_options(repo_root):
    """Return enriched letter options for patient completeness runbook flow."""
    lab_root = resolve_lab_root(repo_root)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    snapshot = _collect_data_plane_snapshot(lab_root)
    if not snapshot.get('ok'):
        return (False, snapshot.get('error') or 'Unable to read lab DB.', None)
    db_path = snapshot.get('db_path')
    rows = []
    conn = None
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        rows = _collect_patient_chain_rows(conn, limit=250)
    except Exception as e:
        return (False, 'DB query failed: {0}'.format(e), None)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
    if not rows:
        diagnostics_state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
        guidance = _build_no_patient_guidance_payload(snapshot, diagnostics_state, lab_root, db_path)
        return (
            False,
            'Guided patient completeness unavailable due to current data-state (0 patient rows). '
            'Launcher is healthy; review runbook actions below.',
            guidance,
        )
    diagnostics_state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
    options = _build_guided_patient_options(rows, diagnostics_state)
    runbook_lines = _build_guided_options_runbook_lines(snapshot, options)
    return (True, 'Guided patient completeness options ready.', {
        'lab_root': lab_root,
        'db_path': db_path,
        'snapshot': snapshot,
        'options': options,
        'runbook_lines': runbook_lines,
    })




def get_patient_flow_reference_options(repo_root, limit=25):
    """Return auto-populated patient reference options for flow runbook selection."""
    lab_root = resolve_lab_root(repo_root)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    snapshot = _collect_data_plane_snapshot(lab_root)
    if not snapshot.get('ok'):
        return (False, snapshot.get('error') or 'Unable to read lab DB.', None)
    db_path = snapshot.get('db_path')
    rows = []
    conn = None
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        rows = _collect_patient_chain_rows(conn, limit=max(25, _safe_int(limit, 25)))
    except Exception as e:
        return (False, 'DB query failed: {0}'.format(e), None)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass

    if not rows:
        diagnostics_state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
        guidance = _build_no_patient_guidance_payload(snapshot, diagnostics_state, lab_root, db_path)
        return (
            False,
            'Patient flow options unavailable due to current data-state (0 patient rows).',
            guidance,
        )

    options = _build_patient_reference_options(rows, limit=_safe_int(limit, 25))
    return (True, 'Patient flow reference options ready.', {
        'lab_root': lab_root,
        'db_path': db_path,
        'snapshot': snapshot,
        'options': options,
    })


def _query_rows_for_ids(conn, sql_prefix, ids, sql_suffix='', max_rows=120):
    return _patient_tools.query_rows_for_ids(
        conn,
        sql_prefix,
        ids,
        sql_suffix=sql_suffix,
        max_rows=max_rows,
        safe_int_fn=_safe_int,
    )


def _build_patient_trace_payload(conn, reports_dir, selected):
    return _patient_tools.build_patient_trace_payload(
        conn,
        reports_dir,
        selected,
        find_latest_by_prefix_fn=_find_latest_by_prefix,
        safe_int_fn=_safe_int,
        safe_json_loads_fn=_safe_json_loads,
        query_rows_for_ids_fn=_query_rows_for_ids,
    )


def _build_patient_trace_decision(selected, trace, diagnostics_state):
    return _patient_tools.build_patient_trace_decision(
        selected,
        trace,
        diagnostics_state,
        safe_int_fn=_safe_int,
    )


def _write_patient_trace_runbook_report(reports_dir, payload):
    return _patient_tools.write_patient_trace_runbook_report(
        reports_dir,
        payload,
        safe_int_fn=_safe_int,
        slug_token_fn=_slug_token,
    )


def open_guided_patient_completeness_runbook(repo_root, option_code):
    """Generate one patient completeness runbook report from lettered enriched options."""
    code = str(option_code or '').strip().upper()
    if not code:
        return (False, 'Option code is required.', None)
    ok, msg, data = get_guided_patient_completeness_options(repo_root)
    if not ok:
        return (False, msg, None)
    options = data.get('options', []) if isinstance(data, dict) else []
    selected = None
    for item in options:
        if str(item.get('code', '')).upper() == code:
            selected = item
            break
    if not isinstance(selected, dict):
        valid = ','.join([str(x.get('code', '')).upper() for x in options]) or '(none)'
        return (False, 'Invalid option code: {0}. valid={1}'.format(code, valid), None)

    lab_root = data.get('lab_root') if isinstance(data, dict) else resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    db_path = data.get('db_path') if isinstance(data, dict) else os.path.join(lab_root, 'unified_model_xp.db')
    diagnostics_state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
    snapshot = data.get('snapshot', {}) if isinstance(data, dict) else {}

    conn = None
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        trace = _build_patient_trace_payload(conn, reports_dir, selected)
    except Exception as e:
        return (False, 'Unable to build patient trace: {0}'.format(e), None)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass

    decision = _build_patient_trace_decision(selected, trace, diagnostics_state)
    payload = {
        'generated_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'selected': selected,
        'snapshot': snapshot,
        'artifact_ids': trace.get('artifact_ids', []),
        'artifact_pointers': trace.get('artifact_pointers', {}),
        'rows': trace.get('rows', {}),
        'decision': decision,
    }
    try:
        path_txt, _ = _write_patient_trace_runbook_report(reports_dir, payload)
    except Exception as e:
        return (False, 'Failed to write patient runbook report: {0}'.format(e), None)
    msg_out = 'Patient completeness runbook generated. verdict={0} patient={1}'.format(
        decision.get('verdict', 'UNKNOWN'),
        selected.get('display_id', selected.get('patient_key', '')),
    )
    return (True, msg_out, path_txt)


def open_patient_flow_runbook(repo_root, patient_ref):
    """Generate a patient flow runbook for an explicit patient reference."""
    ref = str(patient_ref or '').strip()
    if not ref:
        return (False, 'Patient reference is required (patient_id/external_patient_id/patient_key).', None)
    ok, msg, data = get_patient_flow_reference_options(repo_root, limit=250)
    if not ok or not isinstance(data, dict):
        return (False, msg or 'Patient flow unavailable.', None)

    options = data.get('options', []) if isinstance(data.get('options', []), list) else []
    selected = _find_patient_option_by_reference(options, ref)
    if not isinstance(selected, dict):
        return (
            False,
            'Patient reference not found in available patient options: {0}. '
            'Open patient flow options (menu option 5) to pick an auto-populated reference.'.format(ref),
            None,
        )

    lab_root = data.get('lab_root') if isinstance(data, dict) else resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    db_path = data.get('db_path') if isinstance(data, dict) else os.path.join(lab_root, 'unified_model_xp.db')
    diagnostics_state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
    snapshot = data.get('snapshot', {}) if isinstance(data, dict) else {}

    conn = None
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        trace = _build_patient_trace_payload(conn, reports_dir, selected)
    except Exception as e:
        return (False, 'Unable to build patient flow trace: {0}'.format(e), None)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass

    decision = _build_patient_trace_decision(selected, trace, diagnostics_state)
    payload = {
        'generated_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'selected': selected,
        'snapshot': snapshot,
        'artifact_ids': trace.get('artifact_ids', []),
        'artifact_pointers': trace.get('artifact_pointers', {}),
        'rows': trace.get('rows', {}),
        'decision': decision,
    }
    try:
        path_txt, _ = _write_patient_trace_runbook_report(reports_dir, payload)
    except Exception as e:
        return (False, 'Failed to write patient flow runbook report: {0}'.format(e), None)
    msg_out = 'Patient flow runbook generated. verdict={0} patient={1}'.format(
        decision.get('verdict', 'UNKNOWN'),
        selected.get('display_id', selected.get('patient_key', '')),
    )
    return (True, msg_out, path_txt)


def get_report_delivery_status_lines(lab_root):
    """
    Build compact delivery-status lines for operator triage.
    Includes sender readiness, queue snapshot, and last auto-report attempts.
    """
    lines = []
    stamp = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    lines.append('Report Delivery Status')
    lines.append('generated_at_utc={0}'.format(stamp))
    lines.append('lab_root={0}'.format(lab_root or '(unset)'))
    lines.append('')

    delivery = _collect_delivery_diagnostics()
    lines.append('Sender readiness:')
    lines.append(' - token_available={0}'.format(delivery.get('token_available')))
    lines.append(' - recipient_count={0}'.format(delivery.get('recipient_count')))
    lines.append(' - queued_bundle_count={0}'.format(delivery.get('queued_bundle_count', '?')))
    if delivery.get('config_probe_error'):
        lines.append(' - config_probe_error={0}'.format(delivery.get('config_probe_error')))
    if delivery.get('token_probe_error'):
        lines.append(' - token_probe_error={0}'.format(delivery.get('token_probe_error')))
    if delivery.get('queue_probe_error'):
        lines.append(' - queue_probe_error={0}'.format(delivery.get('queue_probe_error')))
    lines.append('')

    lines.append('Queued bundles (up to 5 newest):')
    queued = delivery.get('queued_bundle_paths', [])
    if not isinstance(queued, list):
        queued = []
    try:
        queued = sorted(queued, key=lambda p: os.path.getmtime(p), reverse=True)
    except Exception:
        try:
            queued = sorted(queued, reverse=True)
        except Exception:
            pass
    if queued:
        for path in queued[:5]:
            try:
                age_sec = int(max(0, time.time() - os.path.getmtime(path)))
            except Exception:
                age_sec = None
            if age_sec is None:
                lines.append(' - {0}'.format(path))
            else:
                lines.append(' - {0} (age_sec={1})'.format(path, age_sec))
        if len(queued) > 5:
            lines.append(' - ... {0} more'.format(len(queued) - 5))
    else:
        lines.append(' - none')
    lines.append('')

    def _append_alert_state(label, path):
        state = _load_json_dict(path)
        lines.append('{0}:'.format(label))
        if not state:
            lines.append(' - none')
            return
        for key in (
            'last_attempt_ok',
            'last_error_code',
            'last_trigger',
            'last_issue_key',
            'last_sent_epoch',
            'last_attempt_epoch',
        ):
            if key in state:
                val = state.get(key)
                if key.endswith('_epoch'):
                    utc_val = _format_epoch_utc(val)
                    if utc_val:
                        lines.append(' - {0}={1} ({2})'.format(key, val, utc_val))
                        continue
                lines.append(' - {0}={1}'.format(key, val))
        diag = state.get('last_delivery_diag', {})
        if isinstance(diag, dict):
            if 'token_available' in diag:
                lines.append(' - delivery.token_available={0}'.format(diag.get('token_available')))
            if 'recipient_count' in diag:
                lines.append(' - delivery.recipient_count={0}'.format(diag.get('recipient_count')))
            if 'queued_bundle_count' in diag:
                lines.append(' - delivery.queued_bundle_count={0}'.format(diag.get('queued_bundle_count')))

    _append_alert_state('Cloud health auto-report', os.path.join(lab_root or '.', _HEALTH_ALERT_STATE_FILENAME))
    lines.append('')
    _append_alert_state('Orchestrator auto-report', os.path.join(lab_root or '.', _ORCHESTRATOR_ALERT_STATE_FILENAME))
    lines.append('')
    lines.append('Remediation Playbook:')
    for line in _build_delivery_runbook_lines(delivery):
        lines.append(line)
    return lines


def _format_delivery_failure_message(delivery_diag):
    reason = 'email submission failed'
    recipient_count = delivery_diag.get('recipient_count')
    token_available = delivery_diag.get('token_available')
    if isinstance(recipient_count, int) and recipient_count <= 0:
        reason = 'no valid recipients configured'
    elif token_available is False:
        reason = 'gmail token unavailable'
    msg = 'Report queued or failed ({0}).'.format(reason)
    queued_count = delivery_diag.get('queued_bundle_count')
    if isinstance(queued_count, int):
        msg += ' queued_bundle_count={0}.'.format(queued_count)
    return msg


def _submit_bundle_with_delivery_diagnostics(zip_path, allow_interactive_reauth):
    """Send bundle and return (ok, msg, delivery_diag)."""
    if submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', {})
    delivery_diag = _collect_delivery_diagnostics()
    delivery_diag['allow_interactive_reauth'] = bool(allow_interactive_reauth)
    try:
        ok = submit_support_bundle_email(
            zip_path=zip_path,
            include_traceback=False,
            skip_interactive_reauth=not allow_interactive_reauth,
        )
    except Exception as e:
        ok = False
        delivery_diag['send_exception'] = str(e)
    if ok:
        return (True, 'Report sent.', delivery_diag)
    refreshed_diag = _collect_delivery_diagnostics()
    for key, value in refreshed_diag.items():
        delivery_diag[key] = value
    return (False, _format_delivery_failure_message(delivery_diag), delivery_diag)


def _maybe_send_orchestrator_failure_report(repo_root, lab_root, orchestration_result, trigger):
    """Best-effort auto-report for typed orchestrator failures (non-interactive)."""
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return False
    if not isinstance(orchestration_result, dict):
        return False
    if orchestration_result.get('status') != shadow_orchestrator.STATUS_FAILED:
        return False

    error_code = str(orchestration_result.get('error_code', '') or '').strip() or 'UNKNOWN_ORCHESTRATOR_FAILURE'
    message = str(orchestration_result.get('message', '') or '').strip()
    payload = orchestration_result.get('payload', {}) if isinstance(orchestration_result.get('payload', {}), dict) else {}
    diagnostic_path = str(orchestration_result.get('diagnostic_path', '') or '').strip()
    report_path = str(orchestration_result.get('report_path', '') or '').strip()

    alert_root = lab_root if lab_root and str(lab_root).strip() else os.path.join(repo_root or os.getcwd(), 'lab')
    alert_state_path = os.path.join(alert_root, _ORCHESTRATOR_ALERT_STATE_FILENAME)
    issue_key = '{0}|{1}|{2}'.format(error_code, message, diagnostic_path)
    now_epoch = int(time.time())
    try:
        alert_state = _load_json_dict(alert_state_path)
        last_key = str(alert_state.get('last_issue_key', '') or '')
        last_epoch = int(alert_state.get('last_attempt_epoch', 0) or 0)
        if last_key == issue_key and (now_epoch - last_epoch) < _ORCHESTRATOR_ALERT_DEDUP_WINDOW_SEC:
            return False
    except Exception:
        pass

    extra_files = [('orchestrator_result.json', orchestration_result)]
    if payload:
        extra_files.append(('orchestrator_payload.json', payload))
    for candidate in (diagnostic_path, report_path):
        if candidate and os.path.isfile(candidate):
            extra_files.append((os.path.basename(candidate), candidate))
    for ctx_name in ('diagnostics_state.json', 'run_cursor.json', _HEALTH_TRACKER_FILENAME):
        ctx_path = os.path.join(alert_root, ctx_name)
        if os.path.isfile(ctx_path):
            extra_files.append((ctx_name, ctx_path))

    extra_meta = {
        'orchestrator_failure_auto_report': True,
        'orchestrator_trigger': trigger,
        'error_code': error_code,
        'error_summary': message or error_code,
        'repo_root': repo_root,
        'lab_root': alert_root,
    }
    try:
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta=extra_meta,
            extra_files=extra_files,
        )
        if not zip_path:
            return False
        ok, msg, delivery_diag = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=False,
        )
        state_payload = {
            'last_issue_key': issue_key,
            'last_attempt_epoch': now_epoch,
            'last_attempt_ok': bool(ok),
            'last_error_code': error_code,
            'last_trigger': trigger,
        }
        if isinstance(delivery_diag, dict):
            state_payload['last_delivery_diag'] = delivery_diag
        _save_json_dict(alert_state_path, state_payload)
        if not ok:
            _log_health('WARNING', 'Auto-report failed for {0}: {1}'.format(error_code, msg))
        return ok
    except Exception as e:
        _log_health('ERROR', 'Auto-report exception for {0}: {1}'.format(error_code, e))
        return False


def _collect_health_diagnostics(lab_root, auto_resolve=True):
    """Collect cloud readiness diagnostics and small auto-resolve actions."""
    diagnostics = {
        'severity': 'ok',
        'issues': [],
        'auto_resolved': [],
    }

    def _add_issue(severity, code, message):
        diagnostics['issues'].append({
            'severity': severity,
            'code': code,
            'message': message,
        })
        if severity == 'fail':
            diagnostics['severity'] = 'fail'
        elif severity == 'warn' and diagnostics['severity'] == 'ok':
            diagnostics['severity'] = 'warn'

    if not lab_root:
        _add_issue('fail', 'LAB_ROOT_MISSING', 'Lab root is empty and cannot be evaluated.')
        return diagnostics
    if not os.path.isdir(lab_root):
        _add_issue('fail', 'LAB_ROOT_NOT_FOUND', _describe_lab_root_issue(lab_root))
        return diagnostics

    reports_dir = os.path.join(lab_root, 'reports')
    if not os.path.exists(reports_dir) and auto_resolve:
        try:
            os.makedirs(reports_dir)
            diagnostics['auto_resolved'].append('Created missing reports directory: {0}'.format(reports_dir))
        except (IOError, OSError) as e:
            _add_issue('warn', 'REPORTS_DIR_CREATE_FAILED', 'Failed to create reports directory: {0}'.format(e))

    lock_path = os.path.join(lab_root, 'shadow_pipeline.lock')
    if os.path.exists(lock_path):
        running = is_pipeline_running(lab_root)
        if not running and auto_resolve:
            try:
                os.remove(lock_path)
                diagnostics['auto_resolved'].append('Removed stale pipeline lock: {0}'.format(lock_path))
            except (IOError, OSError) as e:
                _add_issue('warn', 'STALE_LOCK_REMOVE_FAILED', 'Failed to remove stale lock: {0}'.format(e))

    state_path = os.path.join(lab_root, 'diagnostics_state.json')
    if not os.path.exists(state_path):
        if auto_resolve and _seed_diagnostics_state_if_missing(state_path):
            diagnostics['auto_resolved'].append('Seeded missing diagnostics_state.json: {0}'.format(state_path))
        else:
            _add_issue('warn', 'DIAGNOSTICS_STATE_MISSING', 'diagnostics_state.json was not found: {0}'.format(state_path))
            return diagnostics
    try:
        with open(state_path, 'r', encoding='utf-8') as f:
            state = json.load(f)
    except (IOError, OSError) as e:
        _add_issue('fail', 'DIAGNOSTICS_STATE_READ_FAILED', 'Could not read diagnostics_state.json: {0}'.format(e))
        return diagnostics
    except ValueError as e:
        _add_issue('fail', 'DIAGNOSTICS_STATE_INVALID_JSON', 'diagnostics_state.json has invalid JSON: {0}'.format(e))
        return diagnostics
    if not isinstance(state, dict):
        _add_issue('fail', 'DIAGNOSTICS_STATE_INVALID_TYPE', 'diagnostics_state.json root must be an object/dict.')
        return diagnostics

    phase_specs = [
        ('B', 'last_phase_b_run_id', 'last_discovery_ok', 'last_discovery_error_code'),
        ('C', 'last_phase_c_run_id', 'last_phase_c_ok', 'last_phase_c_error_code'),
        ('D', 'last_phase_d_run_id', 'last_phase_d_ok', 'last_phase_d_error_code'),
        ('E', 'last_phase_e_run_id', 'last_phase_e_ok', 'last_phase_e_error_code'),
        ('F', 'last_shadow_pipeline_run_id', 'last_shadow_pipeline_ok', 'last_shadow_pipeline_error_code'),
    ]
    lifecycle_state = str(state.get('pipeline_state', '') or '').strip().lower()
    active_phase = str(state.get('active_phase', '') or '').strip().upper()
    phase_run_ids = state.get('last_shadow_pipeline_phase_run_ids', {})
    if not isinstance(phase_run_ids, dict):
        phase_run_ids = {}
    for phase, run_key, ok_key, err_key in phase_specs:
        run_id = ''
        if phase in ('B', 'C', 'D', 'E'):
            run_id = str(phase_run_ids.get(phase, '') or '').strip()
        if not run_id:
            run_id = str(state.get(run_key, '') or '').strip()
        ok_value = state.get(ok_key, None)
        err_value = str(state.get(err_key, '') or '').strip()
        pending_write = (
            lifecycle_state in ('bootstrapping', 'running')
            and not run_id
            and ok_value is None
            and not err_value
            and bool(active_phase)
            and _PHASE_ORDER.get(phase, 99) >= _PHASE_ORDER.get(active_phase, 0)
        )
        if not run_id and ok_value is None:
            if pending_write:
                continue
            _add_issue('warn', 'PHASE_{0}_NOT_RUN'.format(phase),
                       'Phase {0} has no run id and no completion state.'.format(phase))
        elif ok_value is False and not err_value:
            _add_issue('warn', 'PHASE_{0}_ERROR_CODE_MISSING'.format(phase),
                       'Phase {0} failed with no error code.'.format(phase))
    return diagnostics


def _update_health_issue_tracker(lab_root, diagnostics, now_epoch=None):
    """Track intermittent/repeated issues across checks and identify escalation candidates."""
    now_epoch = int(now_epoch or time.time())
    # TODO(agent-followup): Consider a bounded "recent history" ring-buffer per issue code
    # so we can include cadence details (e.g., bursty vs steady failures) in support bundles
    # without growing this tracker file indefinitely over long-lived installations.
    tracker_path = os.path.join(lab_root or '.', _HEALTH_TRACKER_FILENAME)
    tracker = _load_json_dict(tracker_path)
    issues = tracker.get('issues', {}) if isinstance(tracker.get('issues', {}), dict) else {}
    current_keys = []
    escalated_codes = []

    for issue in diagnostics.get('issues', []):
        code = str(issue.get('code', '') or '').strip()
        severity = str(issue.get('severity', 'warn') or 'warn').strip().lower()
        if not code:
            continue
        current_keys.append(code)
        rec = issues.get(code, {}) if isinstance(issues.get(code, {}), dict) else {}
        count = int(rec.get('count', 0) or 0) + 1
        first_seen = int(rec.get('first_seen_epoch', now_epoch) or now_epoch)
        rec.update({
            'severity': severity,
            'count': count,
            'first_seen_epoch': first_seen,
            'last_seen_epoch': now_epoch,
            'message': issue.get('message', ''),
        })
        issues[code] = rec
        age = now_epoch - first_seen
        if severity == 'fail':
            escalated_codes.append(code)
        elif (severity == 'warn' and code not in _WARN_NON_ESCALATING_CODES
              and count >= _WARN_ESCALATION_MIN_COUNT and age >= _WARN_ESCALATION_MIN_AGE_SEC):
            escalated_codes.append(code)

    resolved = []
    for code in list(issues.keys()):
        if code not in current_keys:
            rec = issues.get(code, {})
            if isinstance(rec, dict):
                resolved.append(code)
            issues.pop(code, None)

    tracker['issues'] = issues
    tracker['last_updated_epoch'] = now_epoch
    _save_json_dict(tracker_path, tracker)
    return {
        'tracker_path': tracker_path,
        'escalated_codes': sorted(set(escalated_codes)),
        'resolved_codes': sorted(set(resolved)),
    }


def _maybe_send_cloud_health_failure_report(lab_root, diagnostics, tracker_info):
    """Send deduplicated support bundle for fail or sustained warn diagnostics."""
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return False
    # TODO(agent-followup): If lab_root is empty/invalid, skip persistence and surface an
    # explicit diagnostic for this pathing condition instead of falling back to cwd ('.').
    # That hardening would prevent accidental artifact writes outside expected lab scope.
    escalated_codes = tracker_info.get('escalated_codes', []) if isinstance(tracker_info, dict) else []
    if not escalated_codes:
        return False
    issues = diagnostics.get('issues', []) if isinstance(diagnostics, dict) else []
    issue_key = '|'.join(['{0}:{1}'.format(i.get('code', ''), i.get('message', '')) for i in issues if i.get('code') in escalated_codes])
    if not issue_key:
        return False

    alert_state_path = os.path.join(lab_root or '.', _HEALTH_ALERT_STATE_FILENAME)
    now_epoch = int(time.time())
    alert_state = _load_json_dict(alert_state_path)
    last_key = alert_state.get('last_issue_key')
    last_epoch = int(alert_state.get('last_sent_epoch', 0) or 0)
    if last_key == issue_key and (now_epoch - last_epoch) < _ALERT_DEDUP_WINDOW_SEC:
        return False

    try:
        delivery_preflight = _collect_delivery_diagnostics()
        extra_files = [('cloud_health_diagnostics.json', diagnostics)]
        for name in (_HEALTH_TRACKER_FILENAME, 'diagnostics_state.json', 'run_cursor.json'):
            p = os.path.join(lab_root, name)
            if os.path.isfile(p):
                extra_files.append((name, p))
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta={
                'cloud_health_failure': True,
                'escalated_codes': escalated_codes,
                'lab_root': lab_root,
                'email_delivery_preflight': delivery_preflight,
            },
            extra_files=extra_files,
        )
        if not zip_path:
            return False
        ok, msg, _ = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=False,
        )
        if not ok:
            _log_health('WARNING', 'Cloud health report submission fallback: {0}'.format(msg))
            return False
        _save_json_dict(alert_state_path, {'last_issue_key': issue_key, 'last_sent_epoch': now_epoch})
        return True
    except Exception as e:
        _log_health('ERROR', 'Cloud health report send failed: {0}'.format(e))
        return False


def resolve_lab_root(repo_root):
    """Resolve lab root: MEDICAFE_LAB_DIR > repo_root/lab."""
    env_lab = os.environ.get('MEDICAFE_LAB_DIR', '').strip()
    if env_lab:
        # Accept quoted values from .bat/.ini wrappers and expand shell vars.
        if len(env_lab) >= 2 and env_lab[0] == env_lab[-1] and env_lab[0] in ('"', "'"):
            env_lab = env_lab[1:-1]
        env_lab = os.path.expandvars(os.path.expanduser(env_lab))
        # Auto-heal malformed Windows bootstrap values like:
        #   "C: C:\\Python34\\Lib\\site-packages\\lab"
        # Keep only the real absolute drive path fragment.
        malformed_prefix = re.match(r'^([A-Za-z]:)\s+([A-Za-z]:[\\/].+)$', env_lab)
        if malformed_prefix:
            env_lab = malformed_prefix.group(2)

        # Auto-heal common XP launcher drift where MEDICAFE_LAB_DIR points to
        # site-packages (or site-packages\MediCafe) instead of a dedicated
        # lab root directory.
        env_lab_norm = os.path.normpath(env_lab)
        env_lab_tail, env_lab_parent_tail = _tail_parts_cross_platform(env_lab_norm)
        if env_lab_tail in ('site-packages', 'medicafe') and (
                env_lab_tail == 'site-packages' or env_lab_parent_tail == 'site-packages'):
            env_lab = os.path.join(env_lab_norm, 'lab')

        # If a Windows absolute drive path is provided, do not run posix abspath
        # on it (would incorrectly prefix cwd when tests run on non-Windows hosts).
        if re.match(r'^[A-Za-z]:[\\/]', env_lab):
            return os.path.normpath(env_lab)

        # Re-check after unquoting/expansion: empty value must fall back to repo_root/lab
        # (os.path.abspath('') resolves to cwd, which would mask bad config and corrupt placement)
        if env_lab and env_lab.strip():
            return os.path.abspath(env_lab)
    return os.path.join(repo_root, 'lab')


def _describe_lab_root_issue(lab_root):
    """Return a richer LAB_ROOT_NOT_FOUND explanation to speed operator triage."""
    parts = ['Lab root does not exist: {0}'.format(lab_root)]
    env_raw = os.environ.get('MEDICAFE_LAB_DIR', '')
    if env_raw:
        parts.append('MEDICAFE_LAB_DIR(raw)={0!r}'.format(env_raw))
    try:
        normalized = os.path.abspath(os.path.expandvars(os.path.expanduser(str(lab_root))))
        if normalized != lab_root:
            parts.append('normalized={0}'.format(normalized))
    except Exception:
        pass
    try:
        parent = os.path.dirname(lab_root)
        if parent:
            parts.append('parent_exists={0}'.format(os.path.isdir(parent)))
            parts.append('parent_writable={0}'.format(os.access(parent, os.W_OK)))
    except Exception:
        pass
    return ' | '.join(parts)


def _lab_has_core_artifacts(lab_root):
    """True if lab has db and cursor (bootstrap completed successfully)."""
    if not lab_root:
        return False
    db = os.path.join(lab_root, 'unified_model_xp.db')
    cursor = os.path.join(lab_root, 'run_cursor.json')
    return os.path.isfile(db) and os.path.isfile(cursor)


def _write_bootstrap_diag(repo_root, lab_root, reason, extra=None):
    """Best-effort write of opportunistic bootstrap diagnostics for in-situ triage."""
    try:
        fallback_lab = os.path.join(repo_root, 'lab')
        base_lab = lab_root if lab_root and str(lab_root).strip() else fallback_lab
        reports_dir = os.path.join(base_lab, 'reports')
        if not os.path.isdir(reports_dir):
            os.makedirs(reports_dir)
        stamp = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())
        unique = '{0}-{1}-{2}'.format(stamp, os.getpid(), int((time.time() % 1) * 1000))
        path = os.path.join(reports_dir, 'bootstrap_autofix_diag_{0}.json'.format(unique))
        payload = {
            'reason': reason,
            'lab_root': lab_root,
            'repo_root': repo_root,
            'medicafe_lab_dir_raw': os.environ.get('MEDICAFE_LAB_DIR', ''),
            'timestamp_utc': stamp,
        }
        if isinstance(extra, dict):
            payload.update(extra)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return path
    except Exception:
        return None


def _probe_lab_root(path):
    """Collect lightweight filesystem/pipeline facts for bootstrap diagnostics."""
    probe = {
        'path': path,
        'exists': False,
        'is_dir': False,
        'parent': None,
        'parent_exists': False,
        'parent_writable': False,
        'has_core_artifacts': False,
        'pipeline_running': False,
    }
    try:
        if not path:
            return probe
        probe['exists'] = os.path.exists(path)
        probe['is_dir'] = os.path.isdir(path)
        parent = os.path.dirname(path)
        probe['parent'] = parent
        if parent:
            probe['parent_exists'] = os.path.isdir(parent)
            probe['parent_writable'] = os.access(parent, os.W_OK)
        if probe['is_dir']:
            probe['has_core_artifacts'] = _lab_has_core_artifacts(path)
        probe['pipeline_running'] = is_pipeline_running(path)
    except Exception:
        pass
    return probe


def _bootstrap_fail_message(code, message, diag_path=None):
    """Standardized bootstrap failure message with code and optional diag path."""
    msg = '{0}: {1}'.format(code, message)
    if diag_path:
        msg = '{0} (diagnostics: {1})'.format(msg, diag_path)
    return msg


def _bootstrap_creationflags():
    """Windows-only process-group mitigation for bootstrap child."""
    if os.name == 'nt':
        return getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0)
    return 0


def _orchestrator_ops():
    return {
        "resolve_lab_root": resolve_lab_root,
        "lab_has_core_artifacts": _lab_has_core_artifacts,
        "write_bootstrap_diag": _write_bootstrap_diag,
        "bootstrap_fail_message": _bootstrap_fail_message,
        "devnull": DEVNULL,
    }


def _coerce_orchestrator_result_to_legacy(result, default_running_message='Initialization in progress.'):
    status = (result or {}).get("status", "")
    code = (result or {}).get("error_code", "")
    msg = (result or {}).get("message", "") or ""
    payload = result or {}
    if status == shadow_orchestrator.STATUS_FAILED:
        return (False, msg or code or "Coordinator failed.", payload)
    if status == shadow_orchestrator.STATUS_ALREADY_RUNNING:
        return (True, default_running_message, payload)
    if code == shadow_orchestrator.ERROR_READY_NOOP:
        return (True, "", payload)
    return (True, msg, payload)


def ensure_lab_ready(repo_root, python_exe, env, env_flag_fn):
    """
    Gate before Cloud Readiness UI: ensure lab exists or run Phase A bootstrap.
    Returns (ok, message, None). Avoids concurrent Phase A (lock rejection) by
    checking pipeline running and respecting MEDICAFE_PHASE_A_AUTO_VALIDATE.
    """
    lab_root = resolve_lab_root(repo_root)
    if not lab_root or not str(lab_root).strip():
        diag_path = _write_bootstrap_diag(repo_root, lab_root, 'LAB_ROOT_EMPTY', {
            'flow_stage': 'resolve_lab_root',
        })
        return (False, _bootstrap_fail_message('LAB_ROOT_EMPTY', 'Lab root could not be resolved', diag_path), None)
    candidate_roots = [lab_root]
    default_lab = os.path.join(repo_root, 'lab')
    if default_lab not in candidate_roots:
        candidate_roots.append(default_lab)
    selected_root = lab_root
    selected_from_fallback = False
    for idx, candidate in enumerate(candidate_roots):
        probe = _probe_lab_root(candidate)
        if probe.get('is_dir') and probe.get('has_core_artifacts'):
            if candidate != lab_root:
                os.environ['MEDICAFE_LAB_DIR'] = candidate
            return (True, '', None)
        if probe.get('pipeline_running'):
            if candidate != lab_root:
                os.environ['MEDICAFE_LAB_DIR'] = candidate
            return (True, 'Initialization in progress.', None)
        if probe.get('is_dir'):
            selected_root = candidate
            selected_from_fallback = (idx > 0)
            break
    if selected_from_fallback and selected_root:
        os.environ['MEDICAFE_LAB_DIR'] = selected_root
    env_with_root = dict(env or {})
    env_with_root['MEDICAFE_LAB_DIR'] = selected_root
    baseline_needed = not _lab_has_core_artifacts(selected_root)
    try:
        baseline_result = shadow_orchestrator.start_or_attach_shadow_pipeline(
            action_id=shadow_orchestrator.ACTION_ENSURE_PHASE_A_ONLY,
            entrypoint=shadow_orchestrator.ENTRYPOINT_MENU,
            repo_root=repo_root,
            python_exe=python_exe,
            env=env_with_root,
            env_flag_fn=env_flag_fn,
            ops=_orchestrator_ops(),
        )
        ok, msg, payload = _coerce_orchestrator_result_to_legacy(baseline_result)
        if not ok:
            _maybe_send_orchestrator_failure_report(
                repo_root=repo_root,
                lab_root=selected_root,
                orchestration_result=baseline_result,
                trigger='ensure_lab_ready_baseline',
            )
            return (ok, msg, payload)

        # When baseline had to be reconciled, continue into full pipeline start-or-attach
        # so users are not stranded at B-F "not_run" after lab regeneration/degradation repair.
        if baseline_needed:
            pipeline_result = shadow_orchestrator.start_or_attach_shadow_pipeline(
                action_id=shadow_orchestrator.ACTION_MANUAL_FULL_PIPELINE,
                entrypoint=shadow_orchestrator.ENTRYPOINT_MENU,
                repo_root=repo_root,
                python_exe=python_exe,
                env=env_with_root,
                env_flag_fn=env_flag_fn,
                ops=_orchestrator_ops(),
            )
            ok, msg, payload = _coerce_orchestrator_result_to_legacy(
                pipeline_result, default_running_message='Initialization in progress.'
            )
            if not ok:
                _maybe_send_orchestrator_failure_report(
                    repo_root=repo_root,
                    lab_root=selected_root,
                    orchestration_result=pipeline_result,
                    trigger='ensure_lab_ready_pipeline',
                )
            return (ok, msg, payload)

        if ok and (baseline_result.get("error_code") == shadow_orchestrator.ERROR_READY_NOOP or not msg):
            msg = ''
        return (ok, msg, payload)
    except Exception as e:
        diag_path = _write_bootstrap_diag(repo_root, lab_root, 'BOOTSTRAP_EXCEPTION', {
            'flow_stage': 'bootstrap_execute',
            'exception': str(e),
            'python_exe': python_exe,
            'target_folder': env.get('target_folder', ''),
            'source_folder': env.get('source_folder', ''),
        })
        return (False, _bootstrap_fail_message('BOOTSTRAP_EXCEPTION', str(e), diag_path), None)


def is_pipeline_running(lab_root):
    """Check if shadow pipeline is running. Returns bool. Exception-safe."""
    try:
        from MediCafe.cloud_readiness_health import is_pipeline_running as _health_check
        return _health_check(lab_root)
    except Exception:
        return False


def check_pipeline_running_for_action(repo_root, action_name):
    """Returns (is_running, warning_msg). warning_msg set when is_running."""
    lab_root = resolve_lab_root(repo_root)
    running = is_pipeline_running(lab_root)
    msg = 'Note: Pipeline is running. {0} may reflect stale data.'.format(action_name) if running else None
    return (running, msg)


def run_pipeline(repo_root, python_exe, env, env_flag_fn):
    """
    When shadow_auto=1: spawn run_shadow_pipeline.py (non-blocking).
    When shadow_auto=0: Phase A blocks (subprocess.call), then B/C/D spawn via Popen.
    Env from os.environ.copy() + overlay MEDICAFE_LAB_DIR, target_folder, source_folder.
    """
    try:
        orchestration = shadow_orchestrator.start_or_attach_shadow_pipeline(
            action_id=shadow_orchestrator.ACTION_STARTUP,
            entrypoint=shadow_orchestrator.ENTRYPOINT_STARTUP,
            repo_root=repo_root,
            python_exe=python_exe,
            env=env,
            env_flag_fn=env_flag_fn,
            ops=_orchestrator_ops(),
        )
        ok, msg, data = _coerce_orchestrator_result_to_legacy(orchestration)
        if not ok:
            _maybe_send_orchestrator_failure_report(
                repo_root=repo_root,
                lab_root=resolve_lab_root(repo_root),
                orchestration_result=orchestration,
                trigger='run_pipeline_startup',
            )
        return (ok, msg, data)
    except Exception as e:
        return (False, str(e), None)


def _find_latest_run_id_by_prefix(reports_dir, prefix, suffix_choices):
    """
    Find latest file by prefix (mtime). Parse run_id from filename.
    Returns (run_id, path) or (None, None).
    Filename pattern: {prefix}{run_id}.{ext}
    """
    if not reports_dir or not os.path.exists(reports_dir):
        return (None, None)
    try:
        items = os.listdir(reports_dir)
    except (IOError, OSError):
        return (None, None)
    candidates = []
    prefix_len = len(prefix)
    for item in items:
        if not item.startswith(prefix):
            continue
        for suf in suffix_choices:
            if item.endswith(suf):
                path = os.path.join(reports_dir, item)
                if os.path.isfile(path):
                    rest = item[prefix_len:]
                    if '.' in rest:
                        run_id = rest.rsplit('.', 1)[0]
                    else:
                        run_id = rest
                    if run_id and len(run_id) >= 17 and '-' in run_id:
                        candidates.append((run_id, path))
                break
    if not candidates:
        return (None, None)
    try:
        return max(candidates, key=lambda x: os.path.getmtime(x[1]))
    except (IOError, OSError, ValueError):
        return (None, None)


def _reports_dir_access_error(lab_root):
    """Return readable error string when reports dir exists but is unreadable; else None."""
    reports_dir = os.path.join(lab_root, 'reports')
    if not reports_dir or not os.path.exists(reports_dir):
        return None
    try:
        os.listdir(reports_dir)
    except (IOError, OSError) as e:
        return 'Unable to read reports directory: {0}'.format(e)
    return None


def _select_latest_evidence_files(lab_root, prefix_specs):
    """
    Select latest coherent run's evidence files per prefix_specs.
    prefix_specs: [(prefix, suffix), ...] where suffix is None for (.txt, .json) or e.g. '.jsonl'.
    Returns [(basename, fullpath), ...].
    """
    reports_dir = os.path.join(lab_root, 'reports')
    if not reports_dir or not os.path.exists(reports_dir):
        return []
    if not prefix_specs:
        return []
    primary_prefix, primary_suffix = prefix_specs[0]
    suffix_choices = ('.txt', '.json') if primary_suffix is None else (primary_suffix,)
    run_id, _ = _find_latest_run_id_by_prefix(reports_dir, primary_prefix, suffix_choices)
    if not run_id:
        return []
    extra_files = []
    seen = set()
    for prefix, suffix in prefix_specs:
        if suffix is None:
            for ext in ('.json', '.txt'):
                basename = prefix + run_id + ext
                path = os.path.join(reports_dir, basename)
                if os.path.isfile(path) and basename not in seen:
                    extra_files.append((basename, path))
                    seen.add(basename)
        else:
            basename = prefix + run_id + suffix
            path = os.path.join(reports_dir, basename)
            if os.path.isfile(path) and basename not in seen:
                extra_files.append((basename, path))
                seen.add(basename)
    return extra_files


def _find_latest_by_prefix(reports_dir, prefix, suffix_choices):
    """Find latest file by prefix. Returns (path, None) or (None, message)."""
    if not reports_dir or not os.path.exists(reports_dir):
        return (None, 'No reports directory: {0}'.format(reports_dir))
    try:
        items = os.listdir(reports_dir)
    except (IOError, OSError) as e:
        return (None, 'Unable to read reports directory: {0}'.format(e))
    candidates = []
    for item in items:
        if item.startswith(prefix):
            for suf in suffix_choices:
                if item.endswith(suf):
                    path = os.path.join(reports_dir, item)
                    if os.path.isfile(path):
                        candidates.append(path)
                    break
    if not candidates:
        return (None, None)
    try:
        return (max(candidates, key=os.path.getmtime), None)
    except (IOError, OSError, ValueError):
        return (None, 'Unable to resolve latest report file.')


def open_phase_b_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'artifact_discovery_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No artifact discovery summaries found.', None)


def open_manifest_location(repo_root):
    """Return manifest file path for explorer /select. Launcher opens explorer, not viewer."""
    lab_root = resolve_lab_root(repo_root)
    cursor_path = os.path.join(lab_root, 'run_cursor.json')
    manifest_path = None
    if os.path.exists(cursor_path):
        try:
            with open(cursor_path, 'r', encoding='utf-8') as f:
                cursor = json.load(f)
            manifest_path = cursor.get('last_manifest_path')
        except (IOError, OSError, ValueError):
            pass
    if not manifest_path or not os.path.exists(manifest_path):
        reports_dir = os.path.join(lab_root, 'reports')
        if os.path.exists(reports_dir):
            try:
                report_items = os.listdir(reports_dir)
            except (IOError, OSError) as e:
                return (False, 'Unable to read reports directory: {0}'.format(e), None)
            manifests = [
                os.path.join(reports_dir, x) for x in report_items
                if x.startswith('artifact_manifest_') and x.endswith('.jsonl')
                and os.path.isfile(os.path.join(reports_dir, x))
            ]
            if manifests:
                try:
                    manifest_path = max(manifests, key=os.path.getmtime)
                except (IOError, OSError, ValueError):
                    return (False, 'Unable to resolve latest manifest file.', None)
    if manifest_path and os.path.exists(manifest_path):
        return (True, '', manifest_path)
    return (False, 'No manifest found. Run discovery from Cloud Readiness first.', None)


def _resolve_unified_model_script(repo_root, python_exe, script_name):
    script_repo_root, script_path, script_checks = shadow_orchestrator._find_unified_model_script(
        repo_root, script_name, python_exe=python_exe
    )
    if os.path.exists(script_path):
        return (True, '', script_repo_root, script_path, script_checks)
    checked_paths = [c.get('script_path', '') for c in script_checks if c.get('script_path')]
    detail = ', '.join(checked_paths) if checked_paths else script_path
    msg = '{0} not found. checked: {1}'.format(script_name, detail)
    _log_health('WARNING', 'Cloud Readiness script resolution failure: {0}'.format(msg))
    return (False, msg, script_repo_root, script_path, script_checks)


def run_phase_b_manual(repo_root, python_exe, env):
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'discover_artifacts.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        proc_env['target_folder'] = env.get('target_folder', '')
        proc_env['source_folder'] = env.get('source_folder', '')
        subprocess.Popen([python_exe, script], cwd=script_repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def _send_phase_evidence(lab_root, prefix_specs, extra_meta_key, no_attach_msg):
    """
    Send latest coherent run's evidence. prefix_specs: [(prefix, suffix), ...].
    Requires at least one phase artifact; context files are additive only.
    """
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', None)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    phase_files = _select_latest_evidence_files(lab_root, prefix_specs)
    if not phase_files:
        return (False, no_attach_msg, None)
    extra_files = list(phase_files)
    for ctx_name in ('diagnostics_state.json', 'run_cursor.json'):
        ctx_path = os.path.join(lab_root, ctx_name)
        if os.path.isfile(ctx_path):
            extra_files.append((ctx_name, ctx_path))
    try:
        delivery_preflight = _collect_delivery_diagnostics()
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta={
                extra_meta_key: True,
                'lab_root': lab_root,
                'email_delivery_preflight': delivery_preflight,
            },
            extra_files=extra_files,
        )
        if not zip_path:
            return (False, 'Failed to create support bundle.', None)
        ok, msg, _ = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=True,
        )
        return (ok, msg, None)
    except Exception as e:
        return (False, 'Error: {0}'.format(e), None)


def send_phase_b_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('artifact_discovery_summary_', None)],
        'phase_b_evidence',
        'No discovery summaries to attach.',
    )


def open_phase_c_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'ingest_write_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase C ingest summaries found.', None)


def run_phase_c_manual(repo_root, python_exe, env):
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'ingest_from_manifest.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        subprocess.Popen([python_exe, script], cwd=script_repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def send_phase_c_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('ingest_write_summary_', None), ('ingest_write_anomalies_', '.jsonl')],
        'phase_c_evidence',
        'No Phase C summaries or anomalies to attach.',
    )


def open_phase_d_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'qa_canonical_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase D summaries found.', None)


def open_phase_d_reject_sample(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'qa_reject_samples_', ('.jsonl',))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase D reject sample files found.', None)


def run_phase_d_manual(repo_root, python_exe, env):
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'run_qa_canonical.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        subprocess.Popen([python_exe, script], cwd=script_repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def send_phase_d_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('qa_canonical_summary_', None), ('qa_reject_samples_', '.jsonl')],
        'phase_d_evidence',
        'No Phase D summaries or reject samples to attach.',
    )


def open_phase_e_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'projection_parity_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase E summaries found.', None)


def open_phase_e_deviation_samples(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'projection_deviation_samples_', ('.jsonl',))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase E deviation sample files found.', None)


def run_phase_e_manual(repo_root, python_exe, env):
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'run_projection_parity.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        subprocess.Popen([python_exe, script], cwd=script_repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def send_phase_e_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('projection_parity_summary_', None), ('projection_deviation_samples_', '.jsonl')],
        'phase_e_evidence',
        'No Phase E summaries or deviation samples to attach.',
    )


def run_shadow_pipeline(repo_root, python_exe, env):
    try:
        def _env_flag(name, default):
            raw = env.get(name)
            if raw is None:
                raw = os.environ.get(name)
            if raw is None:
                return default
            return str(raw).strip().lower() in ('1', 'true', 'yes', 'on', 'y')

        orchestration = shadow_orchestrator.start_or_attach_shadow_pipeline(
            action_id=shadow_orchestrator.ACTION_MANUAL_FULL_PIPELINE,
            entrypoint=shadow_orchestrator.ENTRYPOINT_MANUAL,
            repo_root=repo_root,
            python_exe=python_exe,
            env=env,
            env_flag_fn=_env_flag,
            ops=_orchestrator_ops(),
        )
        ok, msg, data = _coerce_orchestrator_result_to_legacy(orchestration)
        if not ok:
            _maybe_send_orchestrator_failure_report(
                repo_root=repo_root,
                lab_root=resolve_lab_root(repo_root),
                orchestration_result=orchestration,
                trigger='run_shadow_pipeline_manual',
            )
        return (ok, msg, data)
    except Exception as e:
        return (False, str(e), None)


def open_phase_f_shadow_report(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'shadow_run_report_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Shadow Health reports found yet.', None)


def open_phase_f_evidence_index(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'shadow_evidence_index_', ('.json',))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase F evidence indexes found.', None)


def run_phase_f_manual(repo_root, python_exe, env, pipeline_running=None):
    """
    Rebuild Phase F (latest-at-execution). Does not pass --pipeline-run-id.
    Returns (ok, msg, pipeline_running).
    """
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'package_shadow_run_report.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    try:
        def _env_flag(name, default):
            raw = env.get(name)
            if raw is None:
                raw = os.environ.get(name)
            if raw is None:
                return default
            return str(raw).strip().lower() in ('1', 'true', 'yes', 'on', 'y')

        ready_ok, ready_msg, _ = ensure_lab_ready(repo_root, python_exe, env, _env_flag)
        if not ready_ok:
            return (False, ready_msg or 'Phase A bootstrap failed.', None)

        lab_root = resolve_lab_root(repo_root)
        if pipeline_running is None:
            pipeline_running = is_pipeline_running(lab_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        cmd = [python_exe, script, '--auto-report', '0']
        subprocess.Popen(cmd, cwd=script_repo_root, env=proc_env, stdout=DEVNULL)
        return (True, '', pipeline_running)
    except Exception as e:
        return (False, str(e), None)


def run_phase_f_manual_for_run_id(repo_root, python_exe, env, run_id):
    """
    Rebuild Phase F for explicit run_id (strict). Always passes --pipeline-run-id.
    Does NOT read state. Returns (ok, msg, None).
    """
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'package_shadow_run_report.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    run_id = (run_id or '').strip()
    if not run_id:
        return (False, 'run_id is required.', None)
    try:
        def _env_flag(name, default):
            raw = env.get(name)
            if raw is None:
                raw = os.environ.get(name)
            if raw is None:
                return default
            return str(raw).strip().lower() in ('1', 'true', 'yes', 'on', 'y')

        ready_ok, ready_msg, _ = ensure_lab_ready(repo_root, python_exe, env, _env_flag)
        if not ready_ok:
            return (False, ready_msg or 'Phase A bootstrap failed.', None)

        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        cmd = [python_exe, script, '--pipeline-run-id', run_id, '--auto-report', '0']
        subprocess.Popen(cmd, cwd=script_repo_root, env=proc_env, stdout=DEVNULL)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def send_phase_f_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    no_attach_msg = 'No Shadow Health report/evidence files found to attach.'
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', None)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    phase_files = _select_latest_evidence_files(lab_root, [
        ('shadow_run_report_', None),
        ('shadow_evidence_index_', '.json'),
        ('phase_f_mismatch_', '.txt'),
    ])
    if not phase_files:
        reports_dir = os.path.join(lab_root, 'reports')
        mismatch_path, _ = _find_latest_by_prefix(reports_dir, 'phase_f_mismatch_', ('.txt',))
        if mismatch_path:
            basename = os.path.basename(mismatch_path)
            phase_files = [(basename, mismatch_path)]
    if not phase_files:
        return (False, no_attach_msg, None)
    extra_files = list(phase_files)
    for ctx_name in ('diagnostics_state.json', 'run_cursor.json'):
        ctx_path = os.path.join(lab_root, ctx_name)
        if os.path.isfile(ctx_path):
            extra_files.append((ctx_name, ctx_path))
    try:
        delivery_preflight = _collect_delivery_diagnostics()
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta={
                'phase_f_evidence': True,
                'lab_root': lab_root,
                'email_delivery_preflight': delivery_preflight,
            },
            extra_files=extra_files,
        )
        if not zip_path:
            return (False, 'Failed to create support bundle.', None)
        ok, msg, _ = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=True,
        )
        return (ok, msg, None)
    except Exception as e:
        return (False, 'Error: {0}'.format(e), None)


def open_report_delivery_status(repo_root):
    """
    Write and return a compact delivery-status snapshot for support bundle sends.
    Returns (ok, message, path).
    """
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    try:
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir, exist_ok=True)
        path = os.path.join(reports_dir, 'report_delivery_status.txt')
        lines = get_report_delivery_status_lines(lab_root)
        with open(path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)


def open_consolidated_health_report(repo_root, env_flag_fn):
    """
    Generate and return path to consolidated health report (all phases B-F).
    Writes Pipeline Health Snapshot to lab/reports/consolidated_health_snapshot.txt,
    appending latest shadow_run_report content if available.
    Returns (ok, message, path).
    """
    lab_root = resolve_lab_root(repo_root)
    lines = get_health_lines(lab_root, env_flag_fn)
    reports_dir = os.path.join(lab_root, 'reports')
    try:
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir, exist_ok=True)
        path = os.path.join(reports_dir, 'consolidated_health_snapshot.txt')
        content = '\n'.join(lines) + '\n'
        # Append latest shadow_run_report for full phase details
        shadow_path, _ = _find_latest_by_prefix(
            reports_dir, 'shadow_run_report_', ('.txt', '.json'))
        if shadow_path and shadow_path.endswith('.txt'):
            try:
                with open(shadow_path, 'r', encoding='utf-8') as f:
                    shadow_content = f.read()
                content += '\n--- Phase F detailed report ---\n'
                content += shadow_content
            except (IOError, OSError):
                pass
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)


def _audit_script_path(repo_root, python_exe=None):
    ok_script, script_msg, script_repo_root, script_path, script_checks = _resolve_unified_model_script(
        repo_root, python_exe, 'audit_migration_health.py'
    )
    return {
        'ok': ok_script,
        'message': script_msg,
        'cwd': script_repo_root,
        'path': script_path,
        'checks': script_checks,
    }


def _extract_json_object_from_text(raw_text):
    """Best-effort JSON object extraction from mixed stdout text."""
    text = str(raw_text or '').strip()
    if not text:
        return {}
    # Fast path: entire payload is JSON.
    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            return obj
    except ValueError:
        pass
    # Fallback: parse line-by-line and return first JSON object line.
    for line in text.splitlines():
        line = line.strip()
        if not line or not line.startswith('{'):
            continue
        try:
            obj = json.loads(line)
            if isinstance(obj, dict):
                return obj
        except ValueError:
            continue
    return {}


def _audit_hint_lines_from_payload(payload):
    """Return compact operator hints from audit payload."""
    hints = []
    if not isinstance(payload, dict):
        return hints
    stage = str(payload.get('migration_stage', '') or '').strip().lower()
    overall = payload.get('overall', {}) if isinstance(payload.get('overall', {}), dict) else {}
    status = str(overall.get('status', '') or '').lower()
    score = overall.get('score', '?')
    exit_code = overall.get('exit_code', '?')
    hints.append('Migration audit: status={0}, score={1}, exit_code={2}'.format(status or 'unknown', score, exit_code))
    if stage:
        hints.append('Migration stage: {0}'.format(stage))
    gating = payload.get('gating', {}) if isinstance(payload.get('gating', {}), dict) else {}
    excluded = gating.get('excluded_surfaces', []) if isinstance(gating.get('excluded_surfaces', []), list) else []
    if 'cloud' in excluded:
        hints.append('Cloud surface is informational-only for this migration stage.')

    surfaces = payload.get('surfaces', {}) if isinstance(payload.get('surfaces', {}), dict) else {}
    xp = surfaces.get('xp_local', {}) if isinstance(surfaces.get('xp_local', {}), dict) else {}
    cloud = surfaces.get('cloud', {}) if isinstance(surfaces.get('cloud', {}), dict) else {}

    def _metric(surface, key):
        metrics = surface.get('metrics', []) if isinstance(surface.get('metrics', []), list) else []
        for m in metrics:
            if isinstance(m, dict) and m.get('key') == key:
                return m
        return {}

    # XP fidelity hints (manual validation cues)
    qa_ratio = _metric(xp, 'xp.phase_d_reject_ratio')
    if qa_ratio:
        val = qa_ratio.get('value')
        st = qa_ratio.get('status')
        hints.append('XP QA reject ratio: {0} ({1})'.format(val, st))
        if st in ('warn', 'fail'):
            hints.append('Hint: review latest qa_reject_samples_*.jsonl for unresolved QA rejects.')

    projection_cov = _metric(xp, 'xp.phase_e_projection_coverage')
    if projection_cov:
        st = projection_cov.get('status')
        cov_val = projection_cov.get('value')
        if str(cov_val).lower() == 'not_applicable':
            hints.append('XP projection coverage: not_applicable (eligible_count=0)')
        else:
            hints.append('XP projection coverage: {0} ({1})'.format(cov_val, st))
        if st == 'fail':
            hints.append('Hint: potential projection drop/defer risk; inspect projection_deviation_samples_*.jsonl.')

    alignment = _metric(xp, 'xp.cursor_state_run_alignment')
    if alignment:
        st = alignment.get('status')
        align_val = alignment.get('value')
        hints.append('XP cursor/state run alignment: {0} ({1})'.format(align_val, st))
        if st in ('warn', 'fail') or str(align_val).lower() != 'aligned':
            hints.append('Hint: reconcile diagnostics_state and run_cursor run IDs after standalone phase reruns.')

    parity = _metric(xp, 'xp.phase_e_contract_parity')
    if parity and str(parity.get('value', '')).lower() == 'fail':
        hints.append('Hint: contract parity failed; treat as potential data-fidelity blocker before cutover.')

    # Cloud fidelity hints
    unacked = _metric(cloud, 'cloud.unacked_queue_count')
    oldest = _metric(cloud, 'cloud.oldest_unacked_age_minutes')
    if unacked:
        hints.append('Cloud backlog: unacked={0} ({1})'.format(unacked.get('value'), unacked.get('status')))
    if oldest:
        hints.append('Cloud oldest unacked age (min): {0} ({1})'.format(oldest.get('value'), oldest.get('status')))

    unknown_codes = _metric(cloud, 'cloud.unknown_reject_code_count_24h')
    if unknown_codes and int(unknown_codes.get('value') or 0) > 0:
        hints.append('Hint: unknown reject codes detected; validate reject taxonomy before migration decisions.')

    machine_missing = _metric(cloud, 'cloud.machine_id_missing_count')
    if machine_missing and int(machine_missing.get('value') or 0) > 0:
        hints.append('Hint: missing machine_id records may indicate routing/data-loss risk.')

    degradations = payload.get('degradations', []) if isinstance(payload.get('degradations', []), list) else []
    cloud_degradations = [d for d in degradations if isinstance(d, dict) and d.get('surface') == 'cloud']
    if cloud_degradations:
        reasons = []
        for item in cloud_degradations:
            reason = str(item.get('reason', '') or '').strip()
            if reason:
                reasons.append(reason)
        if reasons:
            hints.append('Cloud degradation reasons: {0}'.format(','.join(reasons)))
        runbook_path = getattr(
            _runbook_tools,
            'CLOUD_DEGRADED_VALIDATION_RUNBOOK',
            'docs/runbooks/Cloud_Readiness_Cloud_Degraded_Validation.md',
        )
        hints.append('Runbook: {0}'.format(runbook_path))
        if stage == 'xp_validation':
            hints.append('Note: degraded collection mode active for deferred cloud scope; complete manual checks before dual-run/cutover.')
        else:
            hints.append('Note: degraded collection mode active; complete manual checks before GO decisions.')

    return hints


def run_migration_health_audit(
        repo_root,
        python_exe,
        env,
        scope='both',
        write_report=False,
        cloud_required=False,
        migration_stage='xp_validation'):
    """Run audit_migration_health synchronously and return parsed summary payload.

    Returns (ok, msg, data) where data includes parsed payload + operator hints.
    """
    script_info = _audit_script_path(repo_root, python_exe=python_exe)
    if not script_info.get('ok'):
        return (False, script_info.get('message') or 'audit_migration_health.py not found.', None)
    script = script_info.get('path')
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        if env and isinstance(env, dict):
            for k in ('GOOGLE_CLOUD_PROJECT', 'MEDICAFE_HEALTH_URL'):
                if env.get(k):
                    proc_env[k] = str(env.get(k))

        stage = str(migration_stage or 'xp_validation').strip().lower() or 'xp_validation'
        cmd = [
            python_exe,
            script,
            '--scope',
            scope,
            '--migration-stage',
            stage,
            '--json',
            '--no-text',
            '--output-mode',
            'write' if write_report else 'stdout',
        ]
        if cloud_required:
            cmd.append('--cloud-required')
        p = subprocess.Popen(cmd, cwd=script_info.get('cwd') or repo_root, env=proc_env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out_b, err_b = p.communicate()
        out = out_b.decode('utf-8', 'replace') if hasattr(out_b, 'decode') else str(out_b)
        err = err_b.decode('utf-8', 'replace') if hasattr(err_b, 'decode') else str(err_b)
        payload = _extract_json_object_from_text(out)
        if not payload:
            return (False, 'Audit did not return parseable JSON. {0}'.format(err.strip() or 'No stderr.'), None)
        hints = _audit_hint_lines_from_payload(payload)
        data = {'payload': payload, 'hints': hints, 'stdout': out, 'stderr': err, 'returncode': int(p.returncode)}
        msg = 'Audit completed with status={0}, score={1}, exit_code={2}'.format(
            payload.get('overall', {}).get('status', '?'),
            payload.get('overall', {}).get('score', '?'),
            payload.get('overall', {}).get('exit_code', p.returncode),
        )
        return (True, msg, data)
    except Exception as e:
        return (False, str(e), None)


def open_latest_migration_health_report(repo_root):
    """Open latest audit_migration_health summary report (txt preferred, then json)."""
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'audit_migration_health_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No migration health audit summaries found. Run an audit first.', None)


def _add_unique_file(extra_files, seen, path, alias=None):
    """Append existing file path once to support-bundle file list."""
    if not path or not os.path.isfile(path):
        return
    try:
        norm = os.path.normcase(os.path.abspath(path))
    except Exception:
        norm = str(path)
    if norm in seen:
        return
    seen.add(norm)
    extra_files.append((alias or os.path.basename(path), path))


def _collect_system_health_artifacts(repo_root, env_flag_fn, include_delivery_status=False):
    """Resolve latest system-health artifact paths; refresh consolidated snapshot first."""
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    if reports_dir and not os.path.exists(reports_dir):
        os.makedirs(reports_dir, exist_ok=True)

    consolidated_ok, consolidated_msg, consolidated_path = open_consolidated_health_report(
        repo_root, env_flag_fn)
    if not consolidated_ok:
        consolidated_path = ''

    audit_summary_txt, _ = _find_latest_by_prefix(
        reports_dir, 'audit_migration_health_summary_', ('.txt',))
    audit_summary_json, _ = _find_latest_by_prefix(
        reports_dir, 'audit_migration_health_summary_', ('.json',))
    audit_metrics_json, _ = _find_latest_by_prefix(
        reports_dir, 'audit_migration_health_metrics_', ('.json',))
    shadow_report_path, _ = _find_latest_by_prefix(
        reports_dir, 'shadow_run_report_', ('.txt', '.json'))
    shadow_index_path, _ = _find_latest_by_prefix(
        reports_dir, 'shadow_evidence_index_', ('.json',))
    phase_f_mismatch_path, _ = _find_latest_by_prefix(
        reports_dir, 'phase_f_mismatch_', ('.txt',))

    delivery_status_path = os.path.join(reports_dir, 'report_delivery_status.txt')
    if include_delivery_status:
        delivery_ok, _, delivery_path = open_report_delivery_status(repo_root)
        if delivery_ok and delivery_path:
            delivery_status_path = delivery_path
    if not os.path.isfile(delivery_status_path):
        delivery_status_path = ''

    return {
        'lab_root': lab_root,
        'reports_dir': reports_dir,
        'consolidated_ok': bool(consolidated_ok),
        'consolidated_message': consolidated_msg or '',
        'consolidated_path': consolidated_path or '',
        'audit_summary_txt': audit_summary_txt or '',
        'audit_summary_json': audit_summary_json or '',
        'audit_metrics_json': audit_metrics_json or '',
        'shadow_report_path': shadow_report_path or '',
        'shadow_index_path': shadow_index_path or '',
        'phase_f_mismatch_path': phase_f_mismatch_path or '',
        'delivery_status_path': delivery_status_path or '',
    }


def open_latest_system_health_pack(repo_root, env_flag_fn, include_delivery_status=False):
    """
    Build and return latest combined system-health pack text snapshot.
    Includes current pipeline health, latest migration-audit hints, and artifact pointers.
    """
    try:
        artifacts = _collect_system_health_artifacts(
            repo_root, env_flag_fn, include_delivery_status=include_delivery_status)
        lab_root = artifacts.get('lab_root')
        reports_dir = artifacts.get('reports_dir')

        health_lines = get_health_lines(lab_root, env_flag_fn)
        hints = []
        audit_payload = _load_json_dict(artifacts.get('audit_summary_json'))
        if audit_payload:
            hints = _audit_hint_lines_from_payload(audit_payload)

        lines = []
        lines.append('System Health Pack')
        lines.append('generated_at_utc={0}'.format(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())))
        lines.append('lab_root={0}'.format(lab_root or '(unset)'))
        lines.append('')
        lines.append('Latest artifacts:')
        lines.append(' - consolidated_snapshot={0}'.format(artifacts.get('consolidated_path') or '(missing)'))
        lines.append(' - migration_audit_summary_txt={0}'.format(artifacts.get('audit_summary_txt') or '(missing)'))
        lines.append(' - migration_audit_summary_json={0}'.format(artifacts.get('audit_summary_json') or '(missing)'))
        lines.append(' - migration_audit_metrics_json={0}'.format(artifacts.get('audit_metrics_json') or '(missing)'))
        lines.append(' - shadow_run_report={0}'.format(artifacts.get('shadow_report_path') or '(missing)'))
        lines.append(' - shadow_evidence_index={0}'.format(artifacts.get('shadow_index_path') or '(missing)'))
        lines.append(' - phase_f_mismatch={0}'.format(artifacts.get('phase_f_mismatch_path') or '(missing)'))
        if artifacts.get('delivery_status_path'):
            lines.append(' - report_delivery_status={0}'.format(artifacts.get('delivery_status_path')))
        if artifacts.get('consolidated_message') and not artifacts.get('consolidated_ok'):
            lines.append(' - consolidated_snapshot_refresh_error={0}'.format(artifacts.get('consolidated_message')))

        lines.append('')
        lines.append('Pipeline health snapshot:')
        lines.extend(health_lines or [])

        lines.append('')
        lines.append('Migration audit quick hints:')
        if hints:
            for hint in hints:
                lines.append(' - {0}'.format(hint))
        else:
            lines.append(' - none (run migration health audit to populate hints)')
        lines.append('')
        lines.append('Data plane snapshot:')
        snap = _collect_data_plane_snapshot(lab_root)
        if snap.get('ok'):
            lines.append(' - db_status={0}'.format(snap.get('status', 'unknown')))
            lines.append(' - patient_count={0}'.format(snap.get('counts', {}).get('patient', 0)))
            lines.append(' - qa_reject_count={0}'.format(snap.get('qa_reject_count', 0)))
            lines.append(' - replay_pending_count={0}'.format(snap.get('replay_pending_count', 0)))
            lines.append(' - projection_success_count={0}'.format(snap.get('projection_success_count', 0)))
            lines.append(' - projection_reject_count={0}'.format(snap.get('projection_reject_count', 0)))
            lines.append(' - orphan_claim_lines={0}'.format(snap.get('orphan_claim_lines', 0)))
            opt_preview = []
            conn = None
            try:
                conn = sqlite3.connect(snap.get('db_path', ''))
                conn.execute("PRAGMA foreign_keys = ON")
                rows = _collect_patient_chain_rows(conn, limit=120)
                opts = _build_guided_patient_options(
                    rows,
                    _load_json_dict(os.path.join(lab_root or '.', 'diagnostics_state.json')),
                )
                for item in opts[:3]:
                    opt_preview.append(
                        '{0}:{1}(risk={2},missing={3})'.format(
                            item.get('code', '?'),
                            item.get('display_id', '-'),
                            item.get('risk_label', 'UNKNOWN'),
                            item.get('missing_count', 0),
                        )
                    )
            except Exception:
                pass
            finally:
                if conn is not None:
                    try:
                        conn.close()
                    except Exception:
                        pass
            if opt_preview:
                lines.append(' - guided_patient_options={0}'.format('; '.join(opt_preview)))
            else:
                lines.append(' - guided_patient_options=none')
        else:
            lines.append(' - db_status=FAIL ({0})'.format(snap.get('error', 'unknown')))
        lines.append('')
        for line in _build_system_health_pack_runbook(lab_root, audit_payload, artifacts):
            lines.append(line)

        path = os.path.join(reports_dir, 'system_health_pack_latest.txt')
        with open(path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)


def run_system_health_triage(
        repo_root,
        python_exe,
        env,
        env_flag_fn,
        scope='both',
        cloud_required=False,
        migration_stage='xp_validation'):
    """
    Run migration audit and refresh latest system-health pack in one action.
    Returns (ok, msg, data) where data has hints and generated artifact paths.
    """
    audit_ok, audit_msg, audit_data = run_migration_health_audit(
        repo_root,
        python_exe,
        env,
        scope=scope,
        write_report=True,
        cloud_required=cloud_required,
        migration_stage=migration_stage,
    )
    pack_ok, pack_msg, pack_path = open_latest_system_health_pack(
        repo_root, env_flag_fn, include_delivery_status=False)

    hints = []
    if isinstance(audit_data, dict):
        hints = audit_data.get('hints', []) if isinstance(audit_data.get('hints', []), list) else []

    artifacts = []
    if pack_path:
        artifacts.append(pack_path)
    report_ok, _, report_path = open_latest_migration_health_report(repo_root)
    if report_ok and report_path:
        artifacts.append(report_path)

    overall_ok = bool(audit_ok and pack_ok)
    status_label = 'completed' if overall_ok else 'completed with issues'
    msg_parts = ['System health triage {0}.'.format(status_label)]
    if audit_msg:
        msg_parts.append(audit_msg)
    if pack_msg and not pack_ok:
        msg_parts.append(pack_msg)
    runbook = _build_system_health_triage_runbook(
        audit_ok=audit_ok,
        audit_data=audit_data if isinstance(audit_data, dict) else {},
        pack_ok=pack_ok,
        pack_path=pack_path,
        report_path=report_path if report_ok else '',
    )
    msg_parts.append('decision={0}'.format(runbook.get('decision', 'NO_GO')))
    if runbook.get('top_blocker'):
        msg_parts.append('blocker={0}'.format(runbook.get('top_blocker')))
    msg = ' '.join(msg_parts)
    return (overall_ok, msg, {
        'hints': hints,
        'artifacts': artifacts,
        'audit_ok': bool(audit_ok),
        'pack_ok': bool(pack_ok),
        'runbook': runbook,
        'runbook_lines': runbook.get('lines', []),
    })


def send_latest_system_health_pack(repo_root, env_flag_fn):
    """
    Send latest consolidated system-health pack and related artifacts.
    On send failure, caller can open returned delivery_status_path for diagnostics.
    """
    lab_root = resolve_lab_root(repo_root)
    delivery_path = ''
    preflight_diag = _collect_delivery_diagnostics()
    preflight_runbook = _build_delivery_runbook_lines(preflight_diag)
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', {
            'delivery_status_path': delivery_path,
            'pre_send_runbook_lines': preflight_runbook,
            'delivery_diag': preflight_diag,
        })

    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, {
            'delivery_status_path': delivery_path,
            'pre_send_runbook_lines': preflight_runbook,
            'delivery_diag': preflight_diag,
        })

    ok_pack, msg_pack, pack_path = open_latest_system_health_pack(
        repo_root, env_flag_fn, include_delivery_status=True)
    if not ok_pack:
        return (False, msg_pack or 'Unable to build system health pack.', {
            'delivery_status_path': delivery_path,
            'pre_send_runbook_lines': preflight_runbook,
            'delivery_diag': preflight_diag,
        })

    artifacts = _collect_system_health_artifacts(
        repo_root, env_flag_fn, include_delivery_status=True)
    delivery_path = artifacts.get('delivery_status_path') or ''

    extra_files = []
    seen = set()
    _add_unique_file(extra_files, seen, pack_path, alias='system_health_pack_latest.txt')
    _add_unique_file(extra_files, seen, artifacts.get('consolidated_path'))
    _add_unique_file(extra_files, seen, artifacts.get('audit_summary_txt'))
    _add_unique_file(extra_files, seen, artifacts.get('audit_summary_json'))
    _add_unique_file(extra_files, seen, artifacts.get('audit_metrics_json'))
    _add_unique_file(extra_files, seen, artifacts.get('delivery_status_path'))

    phase_files = _select_latest_evidence_files(lab_root, [
        ('shadow_run_report_', None),
        ('shadow_evidence_index_', '.json'),
        ('phase_f_mismatch_', '.txt'),
    ])
    if not phase_files and artifacts.get('phase_f_mismatch_path'):
        phase_files = [(os.path.basename(artifacts.get('phase_f_mismatch_path')), artifacts.get('phase_f_mismatch_path'))]
    for basename, fullpath in phase_files:
        _add_unique_file(extra_files, seen, fullpath, alias=basename)

    for ctx_name in ('diagnostics_state.json', 'run_cursor.json'):
        _add_unique_file(extra_files, seen, os.path.join(lab_root, ctx_name), alias=ctx_name)

    if not extra_files:
        return (False, 'No system health artifacts found to attach.', {
            'delivery_status_path': delivery_path,
            'pre_send_runbook_lines': preflight_runbook,
            'delivery_diag': preflight_diag,
        })

    try:
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta={
                'system_health_pack': True,
                'lab_root': lab_root,
                'email_delivery_preflight': preflight_diag,
            },
            extra_files=extra_files,
        )
        if not zip_path:
            return (False, 'Failed to create support bundle.', {
                'delivery_status_path': delivery_path,
                'pre_send_runbook_lines': preflight_runbook,
                'delivery_diag': preflight_diag,
            })
        ok_send, msg_send, _ = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=True,
        )
        return (ok_send, msg_send, {
            'delivery_status_path': delivery_path,
            'pre_send_runbook_lines': preflight_runbook,
            'delivery_diag': preflight_diag,
        })
    except Exception as e:
        return (False, 'Error: {0}'.format(e), {
            'delivery_status_path': delivery_path,
            'pre_send_runbook_lines': preflight_runbook,
            'delivery_diag': preflight_diag,
        })


_ARTIFACT_PHASE_LAYOUT = _artifact_tools.ARTIFACT_PHASE_LAYOUT


def _append_unique_path(paths, seen, path):
    return _artifact_tools.append_unique_path(paths, seen, path)


def _safe_run_token(run_id):
    return _artifact_tools.safe_run_token(run_id)


def _collect_group_paths_for_run(reports_dir, run_id, group):
    return _artifact_tools.collect_group_paths_for_run(reports_dir, run_id, group)


def _collect_artifact_run_candidates(reports_dir):
    return _artifact_tools.collect_artifact_run_candidates(
        reports_dir,
        artifact_phase_layout=_ARTIFACT_PHASE_LAYOUT,
    )


def _recent_artifact_run_ids(reports_dir, limit=20):
    return _artifact_tools.recent_artifact_run_ids(
        reports_dir,
        limit=limit,
        collect_artifact_run_candidates_fn=_collect_artifact_run_candidates,
    )


def _run_has_required_artifacts(reports_dir, run_id):
    return _artifact_tools.run_has_required_artifacts(
        reports_dir,
        run_id,
        artifact_phase_layout=_ARTIFACT_PHASE_LAYOUT,
        collect_group_paths_for_run_fn=_collect_group_paths_for_run,
    )


def _find_latest_complete_artifact_run_id(reports_dir, exclude_run_id=''):
    return _artifact_tools.find_latest_complete_artifact_run_id(
        reports_dir,
        exclude_run_id=exclude_run_id,
        recent_artifact_run_ids_fn=_recent_artifact_run_ids,
        run_has_required_artifacts_fn=_run_has_required_artifacts,
    )


def _find_latest_artifact_run_id(reports_dir):
    return _artifact_tools.find_latest_artifact_run_id(
        reports_dir,
        collect_artifact_run_candidates_fn=_collect_artifact_run_candidates,
    )


def _build_run_artifact_snapshot(repo_root, run_id=''):
    return _artifact_tools.build_run_artifact_snapshot(
        repo_root,
        run_id=run_id,
        resolve_lab_root_fn=resolve_lab_root,
        reports_dir_access_error_fn=_reports_dir_access_error,
        find_latest_artifact_run_id_fn=_find_latest_artifact_run_id,
        load_json_dict_fn=_load_json_dict,
        find_latest_complete_artifact_run_id_fn=_find_latest_complete_artifact_run_id,
        recent_artifact_run_ids_fn=_recent_artifact_run_ids,
        is_pipeline_running_fn=is_pipeline_running,
        artifact_phase_layout=_ARTIFACT_PHASE_LAYOUT,
        collect_group_paths_for_run_fn=_collect_group_paths_for_run,
        append_unique_path_fn=_append_unique_path,
    )


def _write_run_artifact_index(snapshot, latest_alias=False):
    return _artifact_tools.write_run_artifact_index(snapshot, latest_alias=latest_alias)


def _write_artifact_triage_pack(snapshot, latest_alias=False):
    return _artifact_tools.write_artifact_triage_pack(snapshot, latest_alias=latest_alias)


def _artifact_bundle_quality(snapshot):
    return _artifact_tools.artifact_bundle_quality(snapshot)


def _build_run_id_diagnostics(snapshot, requested_run_id):
    return _artifact_tools.build_run_id_diagnostics(snapshot, requested_run_id)


def open_latest_artifact_triage_pack(repo_root):
    """Generate and return triage pack for latest run-scoped artifact set."""
    ok, msg, snapshot = _build_run_artifact_snapshot(repo_root, run_id='')
    if not ok:
        return (False, msg, None)
    try:
        path = _write_artifact_triage_pack(snapshot, latest_alias=True)
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)


def open_latest_run_artifact_index(repo_root):
    """Generate and return run artifact index for latest run-scoped artifact set."""
    ok, msg, snapshot = _build_run_artifact_snapshot(repo_root, run_id='')
    if not ok:
        return (False, msg, None)
    try:
        path = _write_run_artifact_index(snapshot, latest_alias=True)
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)


def open_run_artifact_index_for_run_id(repo_root, run_id):
    """Generate and return run artifact index for explicit run_id."""
    run_id = str(run_id or '').strip()
    if not run_id:
        return (False, 'Run ID is required.', None)
    ok, msg, snapshot = _build_run_artifact_snapshot(repo_root, run_id=run_id)
    if not ok:
        lab_root = resolve_lab_root(repo_root)
        reports_dir = os.path.join(lab_root, 'reports')
        diag_snapshot = {
            'recent_run_ids': _recent_artifact_run_ids(reports_dir, limit=12),
            'nearest_complete_run_id': _find_latest_complete_artifact_run_id(reports_dir, exclude_run_id=''),
            'diagnostics_state': _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json')),
        }
        diag_msg = _build_run_id_diagnostics(diag_snapshot, run_id)
        full_msg = '{0} {1}'.format(msg, diag_msg).strip()
        return (False, full_msg, None)
    try:
        path = _write_run_artifact_index(snapshot, latest_alias=False)
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)


def send_latest_run_evidence_bundle(repo_root):
    """Send latest coherent run-scoped evidence bundle across phases B..F."""
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', None)

    ok, msg, snapshot = _build_run_artifact_snapshot(repo_root, run_id='')
    if not ok:
        return (False, msg, None)
    quality = _artifact_bundle_quality(snapshot)
    runbook_lines = [
        'Run-evidence bundle quality: score={0} label={1}'.format(
            quality.get('score'), quality.get('label')),
        'Phase coverage: complete={0} partial={1} missing={2}'.format(
            quality.get('complete'), quality.get('partial'), quality.get('missing')),
        'Recommendation: {0}'.format(quality.get('recommendation')),
    ]
    if quality.get('recommendation') == 'prefer_nearest_complete' and snapshot.get('nearest_complete_run_id'):
        runbook_lines.append('Consider inspecting/sending nearest complete run_id={0}.'.format(
            snapshot.get('nearest_complete_run_id')))

    lab_root = snapshot.get('lab_root', '')
    try:
        triage_path = _write_artifact_triage_pack(snapshot, latest_alias=False)
        index_path = _write_run_artifact_index(snapshot, latest_alias=False)
    except Exception as e:
        return (False, str(e), None)

    delivery_path = ''
    delivery_ok, _, delivery_candidate = open_report_delivery_status(repo_root)
    if delivery_ok and delivery_candidate:
        delivery_path = delivery_candidate

    extra_files = []
    seen = set()
    _add_unique_file(extra_files, seen, triage_path)
    _add_unique_file(extra_files, seen, index_path)
    _add_unique_file(extra_files, seen, delivery_path)
    for path in snapshot.get('artifact_files', []):
        _add_unique_file(extra_files, seen, path)
    for path in snapshot.get('context_files', []):
        _add_unique_file(extra_files, seen, path)

    if not extra_files:
        return (False, 'No run artifacts found to attach.', None)

    try:
        delivery_preflight = _collect_delivery_diagnostics()
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta={
                'run_evidence_bundle': True,
                'artifact_run_id': snapshot.get('run_id', ''),
                'lab_root': lab_root,
                'email_delivery_preflight': delivery_preflight,
            },
            extra_files=extra_files,
        )
        if not zip_path:
            return (False, 'Failed to create support bundle.', {
                'run_id': snapshot.get('run_id', ''),
                'bundle_quality': quality,
                'runbook_lines': runbook_lines,
                'delivery_status_path': delivery_path,
            })
        ok_send, msg_send, _ = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=True,
        )
        return (ok_send, msg_send, {
            'run_id': snapshot.get('run_id', ''),
            'triage_path': triage_path,
            'index_path': index_path,
            'delivery_status_path': delivery_path,
            'bundle_quality': quality,
            'runbook_lines': runbook_lines,
        })
    except Exception as e:
        return (False, 'Error: {0}'.format(e), {
            'run_id': snapshot.get('run_id', ''),
            'bundle_quality': quality,
            'runbook_lines': runbook_lines,
            'delivery_status_path': delivery_path,
        })


def _has_invalid_lab_root(diagnostics):
    """True if diagnostics indicate lab root is missing or not found (read-only path)."""
    codes = {str(i.get('code', '') or '').strip() for i in diagnostics.get('issues', [])}
    return bool(codes & {'LAB_ROOT_MISSING', 'LAB_ROOT_NOT_FOUND'})


def get_health_lines(lab_root, env_flag_fn):
    """Return list of health lines. Uses build_cloud_health_lines or diagnostics_state fallback."""
    diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=True)
    # TODO(agent-followup): Add lightweight log-throttling keyed by diagnostic signature so
    # repeated menu refreshes do not spam identical WARNING/ERROR lines in operator logs.
    if _has_invalid_lab_root(diagnostics):
        tracker_info = {'escalated_codes': [], 'resolved_codes': []}
    else:
        tracker_info = _update_health_issue_tracker(lab_root, diagnostics)

    for issue in diagnostics.get('issues', []):
        level = 'ERROR' if str(issue.get('severity', '')).lower() == 'fail' else 'WARNING'
        _log_health(level, 'Cloud readiness diagnostics [{0}] count-tracked: {1}'.format(
            issue.get('code', 'UNKNOWN_ISSUE'), issue.get('message', '')))
    for resolved_code in tracker_info.get('resolved_codes', []):
        _log_health('INFO', 'Cloud readiness diagnostics resolved: {0}'.format(resolved_code))
    for fix in diagnostics.get('auto_resolved', []):
        _log_health('INFO', 'Cloud readiness auto-resolve: {0}'.format(fix))

    if tracker_info.get('escalated_codes'):
        _log_health('WARNING', 'Cloud readiness escalation triggered for: {0}'.format(
            ', '.join(tracker_info.get('escalated_codes', []))))
        if _maybe_send_cloud_health_failure_report(lab_root, diagnostics, tracker_info):
            _log_health('WARNING', 'Cloud readiness escalation report submitted (or queued).')

    diagnostics_lines = []
    if diagnostics.get('issues'):
        diagnostics_lines.append('-' * 80)
        diagnostics_lines.append('Diagnostics Summary:')
        for issue in diagnostics.get('issues', []):
            diagnostics_lines.append(' - [{0}] {1}: {2}'.format(
                str(issue.get('severity', 'warn')).upper(),
                issue.get('code', 'UNKNOWN_ISSUE'),
                issue.get('message', ''),
            ))
    if diagnostics.get('auto_resolved'):
        diagnostics_lines.append('Auto-resolved:')
        for fix in diagnostics.get('auto_resolved', []):
            diagnostics_lines.append(' - {0}'.format(fix))
    if tracker_info.get('escalated_codes'):
        diagnostics_lines.append('Escalated diagnostics: {0}'.format(', '.join(tracker_info.get('escalated_codes', []))))

    if build_cloud_health_lines:
        try:
            lines = build_cloud_health_lines(
                lab_root,
                auto_pipeline=env_flag_fn('MEDICAFE_SHADOW_AUTO_PIPELINE', True),
                auto_health=env_flag_fn('MEDICAFE_SHADOW_SEND_HEALTH', True),
            )
            if diagnostics_lines:
                lines.extend(diagnostics_lines)
            return lines
        except Exception as e:
            _log_health('ERROR', 'build_cloud_health_lines failed; using fallback: {0}'.format(e))
    state_path = os.path.join(lab_root, 'diagnostics_state.json')
    if not os.path.exists(state_path):
        auto_pipeline = env_flag_fn('MEDICAFE_SHADOW_AUTO_PIPELINE', True)
        auto_health = env_flag_fn('MEDICAFE_SHADOW_SEND_HEALTH', True)
        lines = [
            'No diagnostics state found yet: {0}'.format(state_path),
            'Automation: pipeline_auto={0}, health_telemetry_auto={1}'.format(
                auto_pipeline, auto_health),
        ]
        if diagnostics_lines:
            lines.extend(diagnostics_lines)
        return lines
    try:
        with open(state_path, 'r', encoding='utf-8') as f:
            state = json.load(f)
        rid = state.get('last_shadow_pipeline_run_id', '')
        ok = state.get('last_shadow_pipeline_ok', False)
        failed = state.get('last_shadow_pipeline_failed_phase', '')
        parity = state.get('last_contract_parity_status', '')
        auto_pipeline = env_flag_fn('MEDICAFE_SHADOW_AUTO_PIPELINE', True)
        auto_health = env_flag_fn('MEDICAFE_SHADOW_SEND_HEALTH', True)
        lines = [
            'Last run: {0}, ok={1}, failed_phase={2}, parity={3}'.format(
                rid or '(none)', ok, failed or '-', parity or '-'),
            'Automation: pipeline_auto={0}, health_telemetry_auto={1}'.format(
                auto_pipeline, auto_health),
        ]
        if diagnostics_lines:
            lines.extend(diagnostics_lines)
        return lines
    except (IOError, OSError, ValueError) as e:
        _log_health('ERROR', 'Fallback diagnostics_state parse failed: {0}'.format(e))
        return diagnostics_lines
