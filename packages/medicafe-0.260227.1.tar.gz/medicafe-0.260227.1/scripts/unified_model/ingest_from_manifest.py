#!/usr/bin/env python
"""
Phase C ingest: manifest-to-ingest_artifact write pass.
Deterministic, idempotent INSERT OR IGNORE. XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import argparse
import json
import os
import re
import sqlite3
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_c_common import (
    INGEST_KEY_POLICY_VERSION,
    PHASE_C_DB_WRITE_ERROR,
    PHASE_C_INGEST_KEY_ERROR,
    PHASE_C_LOCK_FAIL,
    PHASE_C_MANIFEST_INVALID,
    PHASE_C_MANIFEST_MISSING,
    PHASE_C_STATE_WRITE_ERROR,
    PHASE_C_UNKNOWN_ARTIFACT_CLASS,
    XP_SOURCE_SYSTEM,
    artifact_class_to_source_type,
    compute_ingest_key_v1,
    iso_utc_now,
    run_id,
)
from lab_lock import acquire_lock, release_lock, replace_safe_write
from lab_path_utils import resolve_lab_root

REQUIRED_FIELDS = (
    "artifact_class",
    "normalized_path",
    "size_bytes",
    "mtime_epoch",
    "sha256",
    "hash_mode",
    "source_id",
    "scope",
)


def _workspace_root():
    return os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))


def _resolve_lab_root(args):
    return resolve_lab_root(args.lab_dir, _workspace_root())


def resolve_manifest_path(lab_root, manifest_arg):
    """Resolve manifest path: --manifest > run_cursor.json.last_manifest_path > latest by mtime."""
    if manifest_arg and os.path.exists(manifest_arg):
        return manifest_arg
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    if os.path.exists(cursor_path):
        try:
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
            path = cursor.get("last_manifest_path")
            if path and os.path.exists(path):
                return path
        except Exception:
            pass
    reports_dir = os.path.join(lab_root, "reports")
    if not os.path.isdir(reports_dir):
        return None
    manifests = []
    for name in os.listdir(reports_dir):
        if name.startswith("artifact_manifest_") and name.endswith(".jsonl"):
            manifests.append(os.path.join(reports_dir, name))
    if not manifests:
        return None
    return max(manifests, key=os.path.getmtime)


def extract_manifest_run_id(manifest_path):
    """Parse artifact_manifest_<run_id>.jsonl; return run_id or None."""
    if not manifest_path:
        return None
    name = os.path.basename(manifest_path)
    match = re.match(r"artifact_manifest_([^.]+)\.jsonl", name)
    return match.group(1) if match else None


def read_manifest_rows(manifest_path):
    """Yield (row_dict, line_num). Malformed line yields (None, line_num)."""
    if not manifest_path or not os.path.exists(manifest_path):
        return
    with open(manifest_path, "r", encoding="utf-8") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
                yield (row, line_num)
            except (ValueError, TypeError):
                yield (None, line_num)


def load_phase_b_summary_lineage(lab_root, manifest_run_id):
    """Load Phase B summary lineage. Returns dict with empty values if missing."""
    result = {
        "manifest_sha256": "",
        "config_hash": "",
        "crosswalk_hash": "",
        "counts_by_class": {},
    }
    if not manifest_run_id:
        return result
    path = os.path.join(lab_root, "reports", "artifact_discovery_summary_{0}.json".format(manifest_run_id))
    if not os.path.exists(path):
        try:
            import logging
            logging.getLogger(__name__).warning("Phase B summary missing: {0}".format(path))
        except Exception:
            pass
        return result
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        result["manifest_sha256"] = data.get("manifest_sha256", "") or ""
        result["config_hash"] = data.get("config_hash", "") or ""
        result["crosswalk_hash"] = data.get("crosswalk_hash", "") or ""
        result["counts_by_class"] = data.get("counts_by_class", {}) or {}
    except Exception:
        pass
    return result


def validate_manifest_row(row, line_num):
    """Return (True, None) if valid; (False, anomaly_dict) if invalid."""
    if row is None:
        return (False, {"line_num": line_num, "error_code": "malformed_json", "message": "Malformed JSON line", "row_snippet": None})
    for k in REQUIRED_FIELDS:
        if k not in row:
            return (False, {"line_num": line_num, "error_code": "missing_field", "message": "Missing required: {0}".format(k), "row_snippet": dict(row)})
    try:
        mtime = row.get("mtime_epoch")
        size = row.get("size_bytes")
        if mtime is None or (not isinstance(mtime, (int, float)) and not str(mtime).strip()):
            return (False, {"line_num": line_num, "error_code": "invalid_type", "message": "mtime_epoch invalid", "row_snippet": dict(row)})
        if size is None or (not isinstance(size, (int, float)) and not str(size).strip()):
            return (False, {"line_num": line_num, "error_code": "invalid_type", "message": "size_bytes invalid", "row_snippet": dict(row)})
    except Exception:
        return (False, {"line_num": line_num, "error_code": "invalid_type", "message": "mtime_epoch/size_bytes invalid", "row_snippet": dict(row)})
    return (True, None)


def manifest_row_to_ingest_row(row, lineage):
    """Build ingest row from manifest row. Returns None if invalid (unknown class or key error)."""
    source_type = artifact_class_to_source_type(row.get("artifact_class"))
    if source_type is None:
        return None
    try:
        ingest_key = compute_ingest_key_v1(row)
    except ValueError:
        return None
    source_id = str(row.get("source_id", ""))
    normalized_path = str(row.get("normalized_path", ""))
    source_ref = source_id + chr(124) + normalized_path
    attachment_name = os.path.basename(normalized_path) if normalized_path else ""
    payload = {
        "phase_b_manifest_run_id": lineage.get("manifest_run_id", ""),
        "phase_b_manifest_sha256": lineage.get("manifest_sha256", ""),
        "config_hash": lineage.get("config_hash", ""),
        "crosswalk_hash": lineage.get("crosswalk_hash", ""),
        "artifact_class": row.get("artifact_class"),
        "normalized_path": normalized_path,
        "mtime_epoch": row.get("mtime_epoch"),
        "size_bytes": row.get("size_bytes"),
        "hash_mode": row.get("hash_mode"),
        "scope": row.get("scope"),
        "locator": row.get("locator", ""),
        "warnings": row.get("warnings", []),
    }
    return {
        "ingest_key": ingest_key,
        "source_system": XP_SOURCE_SYSTEM,
        "source_type": source_type,
        "source_ref": source_ref,
        "message_id": None,
        "attachment_name": attachment_name,
        "attachment_sha256": str(row.get("sha256", "")),
        "payload_json": json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
        "ingest_status": "ingested",
    }


def _verify_schema(conn):
    """Verify ingest_artifact exists with required columns."""
    cur = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='ingest_artifact'"
    )
    if not cur.fetchone():
        return False
    cur = conn.execute("PRAGMA table_info(ingest_artifact)")
    cols = {row[1] for row in cur.fetchall()}
    required = {"ingest_key", "source_system", "source_type", "source_ref", "payload_json", "ingest_status"}
    return required.issubset(cols)


def write_ingest_rows(conn, ingest_rows):
    """INSERT OR IGNORE each row. Return (rows_inserted, rows_skipped_duplicate, rows_failed)."""
    if not _verify_schema(conn):
        raise RuntimeError("ingest_artifact table missing or invalid schema")
    inserted = 0
    skipped = 0
    failed = 0
    stmt = (
        "INSERT OR IGNORE INTO ingest_artifact "
        "(ingest_key, source_system, source_type, source_ref, message_id, attachment_name, "
        "attachment_sha256, payload_json, ingest_status) VALUES (?,?,?,?,?,?,?,?,?)"
    )
    for r in ingest_rows:
        try:
            cur = conn.execute(stmt, (
                r["ingest_key"],
                r["source_system"],
                r["source_type"],
                r["source_ref"],
                r["message_id"],
                r["attachment_name"],
                r["attachment_sha256"],
                r["payload_json"],
                r["ingest_status"],
            ))
            if cur.rowcount > 0:
                inserted += 1
            else:
                skipped += 1
        except Exception:
            failed += 1
    return (inserted, skipped, failed)


def _write_summary_json(summary, path):
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)


def _write_summary_txt(summary, path):
    lines = [
        "Phase C Ingest Write Summary",
        "run_id: {0}".format(summary.get("run_id", "")),
        "generated_at_utc: {0}".format(summary.get("generated_at_utc", "")),
        "ok: {0}".format(summary.get("ok", False)),
        "manifest_path: {0}".format(summary.get("manifest_path", "")),
        "manifest_run_id: {0}".format(summary.get("manifest_run_id", "")),
        "manifest_rows_read: {0}".format(summary.get("manifest_rows_read", 0)),
        "rows_inserted: {0}".format(summary.get("rows_inserted", 0)),
        "rows_skipped_duplicate: {0}".format(summary.get("rows_skipped_duplicate", 0)),
        "rows_failed: {0}".format(summary.get("rows_failed", 0)),
        "has_row_anomalies: {0}".format(summary.get("has_row_anomalies", False)),
        "anomaly_count: {0}".format(summary.get("anomaly_count", 0)),
        "error_code: {0}".format(summary.get("error_code", "")),
    ]
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def persist_phase_c_state(lab_root, rid, ok, error_code, manifest_path, manifest_sha256,
                          rows_inserted, rows_failed, has_row_anomalies, anomaly_count):
    """Update run_cursor.json and diagnostics_state.json with Phase C outcome."""
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    now = iso_utc_now()
    cursor = {}
    if os.path.exists(cursor_path):
        try:
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
        except Exception:
            pass
    cursor["last_phase_c_run_id"] = rid
    cursor["last_phase_c_ok"] = ok
    cursor["last_ingest_manifest_path"] = manifest_path
    cursor["last_ingest_manifest_sha256"] = manifest_sha256
    cursor["last_ingest_key_policy_version"] = INGEST_KEY_POLICY_VERSION
    cursor["last_ingest_rows_inserted"] = rows_inserted
    cursor["last_ingest_rows_failed"] = rows_failed
    cursor["last_phase_c_has_row_anomalies"] = has_row_anomalies
    cursor["last_phase_c_anomaly_count"] = anomaly_count
    cursor["last_phase_c_error_code"] = error_code
    cursor["last_phase_c_at_utc"] = now
    replace_safe_write(cursor_path, cursor)
    state = {}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    state["last_phase_c_run_id"] = rid
    state["last_phase_c_ok"] = ok
    state["last_ingest_manifest_path"] = manifest_path
    state["last_ingest_manifest_sha256"] = manifest_sha256
    state["last_ingest_key_policy_version"] = INGEST_KEY_POLICY_VERSION
    state["last_ingest_rows_inserted"] = rows_inserted
    state["last_ingest_rows_failed"] = rows_failed
    state["last_phase_c_has_row_anomalies"] = has_row_anomalies
    state["last_phase_c_anomaly_count"] = anomaly_count
    state["last_phase_c_error_code"] = error_code
    state["last_phase_c_at_utc"] = now
    replace_safe_write(state_path, state)


def run_ingest(lab_root, manifest_arg=None):
    """Main flow. Returns (ok, run_id, summary, error_code)."""
    rid = run_id()
    reports_dir = os.path.join(lab_root, "reports")
    summary_json = os.path.join(reports_dir, "ingest_write_summary_{0}.json".format(rid))
    summary_txt = os.path.join(reports_dir, "ingest_write_summary_{0}.txt".format(rid))
    anomalies_path = os.path.join(reports_dir, "ingest_write_anomalies_{0}.jsonl".format(rid))
    db_path = os.path.join(lab_root, "unified_model_xp.db")

    manifest_path = resolve_manifest_path(lab_root, manifest_arg)
    if not manifest_path or not os.path.exists(manifest_path):
        summary_fail = {
            "phase": "phase_c",
            "ok": False,
            "run_id": rid,
            "generated_at_utc": iso_utc_now(),
            "manifest_path": manifest_path or "",
            "manifest_run_id": "",
            "manifest_sha256": "",
            "config_hash": "",
            "crosswalk_hash": "",
            "ingest_key_policy_version": INGEST_KEY_POLICY_VERSION,
            "manifest_rows_read": 0,
            "rows_inserted": 0,
            "rows_updated": 0,
            "rows_skipped_duplicate": 0,
            "rows_failed": 0,
            "has_row_anomalies": False,
            "anomaly_count": 0,
            "counts_by_class": {},
            "error_code": PHASE_C_MANIFEST_MISSING,
        }
        try:
            acquire_lock(lab_root)
            try:
                if reports_dir and not os.path.exists(reports_dir):
                    os.makedirs(reports_dir, exist_ok=True)
                _write_summary_json(summary_fail, summary_json)
                _write_summary_txt(summary_fail, summary_txt)
                try:
                    persist_phase_c_state(lab_root, rid, False, PHASE_C_MANIFEST_MISSING,
                                         None, None, 0, 0, False, 0)
                except Exception as persist_err:
                    summary_fail["error_code"] = PHASE_C_STATE_WRITE_ERROR
                    summary_fail["error_detail"] = str(persist_err)[:200]
                    _write_summary_json(summary_fail, summary_json)
                    _write_summary_txt(summary_fail, summary_txt)
            finally:
                release_lock(lab_root, owner_pid=os.getpid())
            try:
                from phase_c_auto_report import submit_phase_c_failure_report
                submit_phase_c_failure_report(lab_root, {
                    "error_code": summary_fail.get("error_code", PHASE_C_MANIFEST_MISSING),
                    "run_id": rid,
                    "first_failed": "manifest_missing",
                    "lab_root": lab_root,
                    "report_json_path": summary_json,
                    "report_txt_path": summary_txt,
                    "summary": summary_fail,
                })
            except Exception:
                pass
        except SystemExit:
            return False, rid, None, PHASE_C_LOCK_FAIL
        return False, rid, summary_fail, summary_fail.get("error_code", PHASE_C_MANIFEST_MISSING)

    manifest_run_id = extract_manifest_run_id(manifest_path)
    lineage = load_phase_b_summary_lineage(lab_root, manifest_run_id)
    lineage["manifest_run_id"] = manifest_run_id

    ingest_rows = []
    anomalies = []
    manifest_rows_read = 0
    counts_by_class = {}

    for row, line_num in read_manifest_rows(manifest_path):
        manifest_rows_read += 1
        valid, anomaly = validate_manifest_row(row, line_num)
        if not valid:
            if anomaly:
                anomaly["error_code"] = anomaly.get("error_code", "malformed_json")
                anomalies.append(anomaly)
            continue
        ingest_row = manifest_row_to_ingest_row(row, lineage)
        if ingest_row is None:
            source_type = artifact_class_to_source_type(row.get("artifact_class")) if row else None
            if source_type is None:
                anomalies.append({
                    "line_num": line_num,
                    "error_code": PHASE_C_UNKNOWN_ARTIFACT_CLASS,
                    "message": "Unknown artifact_class",
                    "row_snippet": dict(row) if row else None,
                })
            else:
                anomalies.append({
                    "line_num": line_num,
                    "error_code": PHASE_C_INGEST_KEY_ERROR,
                    "message": "Ingest key computation failed",
                    "row_snippet": dict(row) if row else None,
                })
            continue
        ingest_rows.append(ingest_row)
        ac = row.get("artifact_class", "unknown")
        counts_by_class[ac] = counts_by_class.get(ac, 0) + 1

    if not os.path.exists(db_path):
        summary_fail = {
            "phase": "phase_c",
            "ok": False,
            "run_id": rid,
            "generated_at_utc": iso_utc_now(),
            "manifest_path": manifest_path,
            "manifest_run_id": manifest_run_id or "",
            "manifest_sha256": lineage.get("manifest_sha256", ""),
            "config_hash": lineage.get("config_hash", ""),
            "crosswalk_hash": lineage.get("crosswalk_hash", ""),
            "ingest_key_policy_version": INGEST_KEY_POLICY_VERSION,
            "manifest_rows_read": manifest_rows_read,
            "rows_inserted": 0,
            "rows_updated": 0,
            "rows_skipped_duplicate": 0,
            "rows_failed": len(ingest_rows),
            "has_row_anomalies": len(anomalies) > 0,
            "anomaly_count": len(anomalies),
            "counts_by_class": counts_by_class,
            "error_code": PHASE_C_MANIFEST_INVALID,
        }
        try:
            acquire_lock(lab_root)
            try:
                if reports_dir and not os.path.exists(reports_dir):
                    os.makedirs(reports_dir, exist_ok=True)
                _write_summary_json(summary_fail, summary_json)
                _write_summary_txt(summary_fail, summary_txt)
                try:
                    persist_phase_c_state(lab_root, rid, False, PHASE_C_MANIFEST_INVALID,
                                         manifest_path, lineage.get("manifest_sha256", ""),
                                         0, len(ingest_rows), len(anomalies) > 0, len(anomalies))
                except Exception as persist_err:
                    summary_fail["error_code"] = PHASE_C_STATE_WRITE_ERROR
                    summary_fail["error_detail"] = str(persist_err)[:200]
                    _write_summary_json(summary_fail, summary_json)
                    _write_summary_txt(summary_fail, summary_txt)
            finally:
                release_lock(lab_root, owner_pid=os.getpid())
            try:
                from phase_c_auto_report import submit_phase_c_failure_report
                submit_phase_c_failure_report(lab_root, {
                    "error_code": summary_fail.get("error_code", PHASE_C_MANIFEST_INVALID),
                    "run_id": rid,
                    "first_failed": "db_missing",
                    "lab_root": lab_root,
                    "report_json_path": summary_json,
                    "report_txt_path": summary_txt,
                    "summary": summary_fail,
                })
            except Exception:
                pass
        except SystemExit:
            return False, rid, None, PHASE_C_LOCK_FAIL
        return False, rid, summary_fail, summary_fail.get("error_code", PHASE_C_MANIFEST_INVALID)

    db_error_result = None
    db_error_report_ctx = None
    try:
        acquire_lock(lab_root)
    except SystemExit:
        return False, rid, None, PHASE_C_LOCK_FAIL

    try:
        conn = sqlite3.connect(db_path)
        try:
            conn.execute("BEGIN")
            rows_inserted, rows_skipped, rows_failed = write_ingest_rows(conn, ingest_rows)
            conn.commit()
        except Exception as e:
            conn.rollback()
            summary_fail = {
                "phase": "phase_c",
                "ok": False,
                "run_id": rid,
                "generated_at_utc": iso_utc_now(),
                "manifest_path": manifest_path,
                "manifest_run_id": manifest_run_id or "",
                "manifest_sha256": lineage.get("manifest_sha256", ""),
                "config_hash": lineage.get("config_hash", ""),
                "crosswalk_hash": lineage.get("crosswalk_hash", ""),
                "ingest_key_policy_version": INGEST_KEY_POLICY_VERSION,
                "manifest_rows_read": manifest_rows_read,
                "rows_inserted": 0,
                "rows_updated": 0,
                "rows_skipped_duplicate": 0,
                "rows_failed": len(ingest_rows),
                "has_row_anomalies": len(anomalies) > 0,
                "anomaly_count": len(anomalies),
                "counts_by_class": counts_by_class,
                "error_code": PHASE_C_DB_WRITE_ERROR,
            }
            _write_summary_json(summary_fail, summary_json)
            _write_summary_txt(summary_fail, summary_txt)
            try:
                persist_phase_c_state(lab_root, rid, False, PHASE_C_DB_WRITE_ERROR,
                                      manifest_path, lineage.get("manifest_sha256", ""),
                                      0, len(ingest_rows), len(anomalies) > 0, len(anomalies))
            except Exception as persist_err:
                summary_fail["error_code"] = PHASE_C_STATE_WRITE_ERROR
                summary_fail["error_detail"] = str(persist_err)[:200]
                _write_summary_json(summary_fail, summary_json)
                _write_summary_txt(summary_fail, summary_txt)
            db_error_report_ctx = {
                "error_code": summary_fail.get("error_code", PHASE_C_DB_WRITE_ERROR),
                "run_id": rid,
                "first_failed": str(e)[:100],
                "lab_root": lab_root,
                "report_json_path": summary_json,
                "report_txt_path": summary_txt,
                "summary": summary_fail,
            }
            db_error_result = (False, rid, summary_fail, summary_fail.get("error_code", PHASE_C_DB_WRITE_ERROR))
        finally:
            conn.close()

        if db_error_result is not None:
            pass
        else:
            summary = {
                "phase": "phase_c",
                "ok": True,
                "run_id": rid,
                "generated_at_utc": iso_utc_now(),
                "manifest_path": manifest_path,
                "manifest_run_id": manifest_run_id or "",
                "manifest_sha256": lineage.get("manifest_sha256", ""),
                "config_hash": lineage.get("config_hash", ""),
                "crosswalk_hash": lineage.get("crosswalk_hash", ""),
                "ingest_key_policy_version": INGEST_KEY_POLICY_VERSION,
                "manifest_rows_read": manifest_rows_read,
                "rows_inserted": rows_inserted,
                "rows_updated": 0,
                "rows_skipped_duplicate": rows_skipped,
                "rows_failed": rows_failed,
                "has_row_anomalies": len(anomalies) > 0,
                "anomaly_count": len(anomalies),
                "counts_by_class": counts_by_class,
                "error_code": None,
            }
            if reports_dir and not os.path.exists(reports_dir):
                os.makedirs(reports_dir, exist_ok=True)
            _write_summary_json(summary, summary_json)
            _write_summary_txt(summary, summary_txt)
            if anomalies:
                with open(anomalies_path, "w", encoding="utf-8") as f:
                    for a in anomalies:
                        f.write(json.dumps(a, ensure_ascii=False) + "\n")
            try:
                persist_phase_c_state(lab_root, rid, True, None,
                                     manifest_path, lineage.get("manifest_sha256", ""),
                                     rows_inserted, rows_failed, len(anomalies) > 0, len(anomalies))
            except Exception as persist_err:
                state_error_summary = dict(summary, ok=False, error_code=PHASE_C_STATE_WRITE_ERROR, error_detail=str(persist_err)[:200])
                _write_summary_json(state_error_summary, summary_json)
                _write_summary_txt(state_error_summary, summary_txt)
                db_error_report_ctx = {
                    "error_code": PHASE_C_STATE_WRITE_ERROR,
                    "run_id": rid,
                    "first_failed": str(persist_err)[:100],
                    "lab_root": lab_root,
                    "report_json_path": summary_json,
                    "report_txt_path": summary_txt,
                    "summary": state_error_summary,
                }
                db_error_result = (False, rid, state_error_summary, PHASE_C_STATE_WRITE_ERROR)
            else:
                return True, rid, summary, None
    finally:
        release_lock(lab_root, owner_pid=os.getpid())

    if db_error_report_ctx is not None:
        try:
            from phase_c_auto_report import submit_phase_c_failure_report
            submit_phase_c_failure_report(lab_root, db_error_report_ctx)
        except Exception:
            pass
        return db_error_result[0], db_error_result[1], db_error_result[2], db_error_result[3]


def main():
    parser = argparse.ArgumentParser(description="Phase C manifest-to-ingest ingest")
    parser.add_argument("--lab-dir", help="Override lab root")
    parser.add_argument("--manifest", help="Override manifest path")
    args = parser.parse_args()
    lab_root = _resolve_lab_root(args)
    if not os.path.exists(lab_root):
        os.makedirs(lab_root, exist_ok=True)
    ok, rid, summary, error_code = run_ingest(lab_root, args.manifest)
    if not ok:
        print("Phase C ingest failed: {0}".format(error_code), file=sys.stderr)
        sys.exit(1)
    print("Phase C ingest ok: {0} inserted, {1} skipped".format(
        summary.get("rows_inserted", 0), summary.get("rows_skipped_duplicate", 0)))


if __name__ == "__main__":
    main()
