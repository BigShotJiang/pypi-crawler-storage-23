#!/usr/bin/env python
"""
Extended diagnostics for Phase A: validate_prototype + concurrent-lock test.
Invocable standalone or by launcher after bootstrap success.
Uses lab_lock for lock coordination; child bootstrap runs with
MEDICAFE_PHASE_A_EXPECTED_LOCK_REJECT=1 to suppress false report.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import json
import os
import subprocess
import sys
import time

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_WORKSPACE_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_a_common import BOOTSTRAP_VERSION, iso_utc_now, run_id
from lab_path_utils import resolve_lab_root

STALE_THRESHOLD_SEC = 24 * 3600  # 24h for extended diagnostics policy
LOCK_TEST_TIMEOUT_SEC = 30


def _should_run_extended(state_path, lab_root, bootstrap_version, schema_sha256):
    """
    Run extended diagnostics when:
    (a) first run per (bootstrap_version, schema_sha256), or
    (b) last_success_at_utc older than STALE_THRESHOLD_SEC.
    """
    if not os.path.exists(state_path):
        return True
    try:
        with open(state_path, "r", encoding="utf-8") as f:
            state = json.load(f)
    except Exception:
        return True
    last_ver = state.get("last_bootstrap_version")
    last_sha = state.get("last_schema_sha256")
    if last_ver != bootstrap_version or last_sha != schema_sha256:
        return True
    last_success = state.get("last_success_at_utc")
    if not last_success:
        return True
    try:
        import calendar
        struct = time.strptime(last_success.replace("Z", ""), "%Y-%m-%dT%H:%M:%S")
        epoch = calendar.timegm(struct)
        return (time.time() - epoch) > STALE_THRESHOLD_SEC
    except Exception:
        return True


def _run_validate_prototype(db_path):
    """Run validate_prototype.py --db <path>. Returns (exit_code, checks_dict)."""
    validate_script = os.path.join(_SCRIPT_DIR, "validate_prototype.py")
    if not os.path.exists(validate_script):
        return -1, {"error": "validate_prototype.py not found"}
    python_exe = sys.executable
    try:
        proc = subprocess.Popen(
            [python_exe, validate_script, "--db", db_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=_WORKSPACE_ROOT,
        )
        stdout, stderr = proc.communicate(timeout=LOCK_TEST_TIMEOUT_SEC)
        exit_code = proc.returncode
        if exit_code == 0:
            try:
                checks = json.loads(stdout.decode("utf-8"))
            except Exception:
                checks = {"raw": stdout.decode("utf-8", "replace")}
        else:
            checks = {"exit_code": exit_code, "stderr": stderr.decode("utf-8", "replace")}
        return exit_code, checks
    except subprocess.TimeoutExpired:
        try:
            proc.kill()
        except Exception:
            pass
        return -2, {"error": "validate_prototype timeout"}
    except Exception as e:
        return -3, {"error": str(e)}


def _run_concurrent_lock_test(lab_root):
    """
    Parent holds lab/shadow.lock; child runs bootstrap with
    MEDICAFE_PHASE_A_EXPECTED_LOCK_REJECT=1. Expect child exit 1.
    Returns (ok, child_exit_code, detail).
    """
    try:
        import lab_lock
    except ImportError:
        if _SCRIPT_DIR not in sys.path:
            sys.path.insert(0, _SCRIPT_DIR)
        try:
            import lab_lock
        except ImportError:
            return False, None, "lab_lock unavailable"

    bootstrap_script = os.path.join(_SCRIPT_DIR, "bootstrap_lab.py")
    if not os.path.exists(bootstrap_script):
        return False, None, "bootstrap_lab.py not found"

    lock_acquired = False
    try:
        lab_lock.acquire_lock(lab_root)
        lock_acquired = True
    except SystemExit:
        return False, None, "parent failed to acquire lock"
    except Exception as e:
        return False, None, "parent acquire_lock: {0}".format(e)

    try:
        env = os.environ.copy()
        env["MEDICAFE_PHASE_A_EXPECTED_LOCK_REJECT"] = "1"
        env["MEDICAFE_LAB_DIR"] = lab_root
        creationflags = 0
        if os.name == "nt":
            creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        proc = subprocess.Popen(
            [sys.executable, bootstrap_script],
            cwd=_WORKSPACE_ROOT,
            env=env,
            creationflags=creationflags,
        )
        try:
            proc.wait(timeout=LOCK_TEST_TIMEOUT_SEC)
        except KeyboardInterrupt:
            try:
                proc.terminate()
            except Exception:
                pass
            return False, None, "child bootstrap interrupted by control event; source unknown"
        except subprocess.TimeoutExpired:
            try:
                proc.kill()
            except Exception:
                pass
            return False, None, "child bootstrap timeout"

        child_exit = proc.returncode
        expected_rejection = child_exit == 1
        return expected_rejection, child_exit, "expected_rejection={0}".format(expected_rejection)
    finally:
        if lock_acquired:
            try:
                lab_lock.release_lock(lab_root, owner_pid=str(os.getpid()))
            except Exception:
                pass


def run_extended_diagnostics(lab_root, db_path, bootstrap_version, schema_sha256):
    """
    Run validate_prototype + concurrent-lock test; write extended_diagnostics_<run_id>.json.
    Returns (ok, report_path).
    """
    reports_dir = os.path.join(lab_root, "reports")
    state_path = os.path.join(lab_root, "diagnostics_state.json")

    if not os.path.exists(reports_dir):
        os.makedirs(reports_dir, exist_ok=True)

    ext_run_id = run_id()
    report_path = os.path.join(reports_dir, "extended_diagnostics_{0}.json".format(ext_run_id))

    vp_exit, vp_result = _run_validate_prototype(db_path)
    validate_ok = vp_exit == 0
    validate_prototype = {
        "exit_code": vp_exit,
        "table_count": vp_result.get("table_count"),
        "orphan_claim_lines": vp_result.get("orphan_claim_lines"),
    }
    if not validate_ok:
        validate_prototype["error"] = vp_result.get("error", vp_result.get("stderr", str(vp_result)))

    lock_ok, child_exit, lock_detail = _run_concurrent_lock_test(lab_root)
    concurrent_lock_test = {
        "ok": lock_ok,
        "child_exit_code": child_exit,
        "expected_rejection": lock_ok,
        "detail": lock_detail,
    }

    overall_ok = validate_ok and lock_ok
    report = {
        "phase": "A",
        "extended": True,
        "run_id": ext_run_id,
        "generated_at_utc": iso_utc_now(),
        "ok": overall_ok,
        "bootstrap_version": bootstrap_version,
        "schema_sql_sha256": schema_sha256,
        "validate_prototype": validate_prototype,
        "concurrent_lock_test": concurrent_lock_test,
    }
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    # Update diagnostics_state
    state = {}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    state["last_extended_run_id"] = ext_run_id
    state["version"] = state.get("version", 1)
    try:
        import lab_lock
        lab_lock.replace_safe_write(state_path, state)
    except Exception:
        pass

    return overall_ok, report_path


def main():
    import argparse
    p = argparse.ArgumentParser(description="Phase A extended diagnostics")
    p.add_argument("--lab-dir", dest="lab_dir", default=None)
    args = p.parse_args()

    lab_root = resolve_lab_root(args.lab_dir, _WORKSPACE_ROOT)

    db_path = os.path.join(lab_root, "unified_model_xp.db")
    if not os.path.exists(db_path):
        print("DB not found: {0}".format(db_path), file=sys.stderr)
        sys.exit(1)

    # Read schema_sha from model_metadata or state
    schema_sha256 = ""
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
            schema_sha256 = state.get("last_schema_sha256", "")
        except Exception:
            pass
    if not schema_sha256 and os.path.exists(db_path):
        try:
            import sqlite3
            conn = sqlite3.connect(db_path)
            row = conn.execute("SELECT value FROM model_metadata WHERE key='schema_sql_sha256'").fetchone()
            if row:
                schema_sha256 = row[0]
            conn.close()
        except Exception:
            pass

    if not _should_run_extended(state_path, lab_root, BOOTSTRAP_VERSION, schema_sha256):
        print("Extended diagnostics skipped (policy: not stale)")
        sys.exit(0)

    ok, report_path = run_extended_diagnostics(
        lab_root, db_path, BOOTSTRAP_VERSION, schema_sha256
    )
    print("Extended diagnostics: {0}".format("PASS" if ok else "FAIL"))
    print("Report: {0}".format(report_path))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
