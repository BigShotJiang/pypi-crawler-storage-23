Apps Script Relink & Redeploy
=============================

Purpose
-------
Attach the legacy GAS project (`webapp.html` + `main.js`) to the GCP project created by `setup_gcp.sh`, then publish fresh deployments for both the web application and the Execution API.

Prerequisites
-------------
- Completed `setup_gcp.sh` with the target Cloud project (e.g., `email-de-carol-421600`).
- `web_client_secret.json` generated in this folder.
- OAuth consent screen configured (Internal or External per domain policy).

Steps
-----
1. **Open the Apps Script project**
   - Navigate to https://script.google.com/home
   - Open the project that serves MediLink (`webapp.html` / `main.js`).

2. **Link to the Cloud project**
   - In the editor, click the gear icon ? *Project Settings*.
   - Under *Google Cloud Platform (GCP) Project*, click *Change project*.
   - Choose *Change project* again, then enter the numeric project number displayed by `setup_gcp.sh`.
   - Save. The Script project now uses the Cloud project containing the new OAuth brand and API configuration.

3. **Verify advanced services**
   - Still on Project Settings, ensure *Google Cloud Platform (GCP) Project* shows the expected project name.
   - Optional: open *Resources ? Advanced Google services* and confirm `Drive API`, `Gmail API`, and `Apps Script API` are enabled if the project uses toggles.

4. **Redeploy the web app**
   - Click *Deploy ? Test deployments ? Manage deployments*.
   - Delete any stale deployments pointing to older projects, if appropriate.
   - Choose *New deployment*, select *Web app*.
   - Description: `Baseline dual-flow restore` (or similar).
   - *Execute as*: **Me**.
   - *Who has access*: **Anyone within domain** (or appropriate setting).
   - Deploy. Authorize if prompted (use the same account that owns the Cloud project).
   - Copy the Web App URL for later testing (OTP/manual flow).

5. **Publish Execution API deployment**
   - From *Deploy ? Manage deployments*, create another deployment with type *Execution API*.
   - Note the *Deployment ID* displayed; the local XP helper uses it when calling the Execution API.
   - Confirm the *Scopes* list includes Gmail read/send and Drive; if the dialog warns about restricted scopes, ensure the consent screen is already in place.

6. **Authorize scripts manually (optional sanity check)**
   - In the editor, run `setDownloadedEmails` and `process_docx` once. Accept the OAuth prompt referencing the newly created OAuth client.
   - Verify the runs complete successfully and that the *Execution log* shows calls to Drive/Gmail.

Outputs
-------
- Web App URL and Execution API Deployment ID referencing the new Cloud project.
- OAuth token cached against the correct client for the script owner account.

Next Steps
----------
- Update the local XP environment (`MediLink_Gmail.py`) with the new credentials (`MediLink/json/credentials.json`).
- Continue with `local_token_refresh.md` to clear old tokens and reauthorize the desktop flow.
