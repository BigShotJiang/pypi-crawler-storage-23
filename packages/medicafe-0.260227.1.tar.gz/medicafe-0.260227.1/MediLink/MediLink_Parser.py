# MediLink_Parser.py
import re

# Pre-compile regex patterns for better performance
_EBT_KEY_VALUE_PATTERN = re.compile(r'([^:]+):\s*(.+?)(?=\s{2,}[^:]+:|$)')
_ERA_SEGMENT_PATTERN = re.compile(r'\*')
_277_SEGMENT_PATTERN = re.compile(r'\*')

def parse_era_content(content, debug=False):
    extracted_data = []
    normalized_content = content.replace('~\n', '~')  # Normalize line endings
    lines = normalized_content.split('~')

    record = {}
    check_eft, payer_address = None, None
    allowed_amount, write_off, patient_responsibility, adjustment_amount = 0, 0, 0, 0
    is_payer_section = False

    for line in lines:
        segments = _ERA_SEGMENT_PATTERN.split(line)

        if segments[0] == 'TRN' and len(segments) > 2:
            check_eft = segments[2]  # Extract check/EFT number

        if segments[0] == 'N1':
            if segments[1] == 'PR':
                is_payer_section = True  # Enter payer section
            elif segments[1] == 'PE':
                is_payer_section = False  # Exit payer section

        if is_payer_section and segments[0] == 'N3' and len(segments) > 1:
            payer_address = segments[1]  # Extract payer address

        if segments[0] == 'CLP' and len(segments) >= 5:
            if record:
                # Calculate adjustment amount if not explicitly provided
                if adjustment_amount == 0 and (write_off > 0 or patient_responsibility > 0):
                    adjustment_amount = write_off + patient_responsibility

                # Update record with calculated amounts
                record.update({
                    'Payer Address': payer_address,
                    'Allowed Amount': allowed_amount,
                    'Write Off': write_off,
                    'Patient Responsibility': patient_responsibility,
                    'Adjustment Amount': adjustment_amount,
                })
                extracted_data.append(record)

                # Reset counters for next record
                allowed_amount, write_off, patient_responsibility, adjustment_amount = 0, 0, 0, 0

            # Start new record
            record = {
                'Check EFT': check_eft,
                'Chart Number': segments[1],
                'Payer Address': payer_address,
                'Amount Paid': segments[4],
                'Charge': segments[3],
            }

        elif segments[0] == 'CAS':
            try:
                if segments[1] == 'CO':
                    write_off += float(segments[3])  # Contractual obligation
                elif segments[1] == 'PR':
                    patient_responsibility += float(segments[3])  # Patient responsibility
                elif segments[1] == 'OA':
                    adjustment_amount += float(segments[3])  # Other adjustments
            except (ValueError, IndexError):
                # Skip malformed CAS segments
                continue

        elif segments[0] == 'AMT' and segments[1] == 'B6':
            try:
                allowed_amount += float(segments[2])  # Allowed amount
            except (ValueError, IndexError):
                # Skip malformed AMT segments
                continue

        elif segments[0] == 'DTM' and (segments[1] == '232' or segments[1] == '472'):
            record['Date of Service'] = segments[2]  # Service date

    # Process final record
    if record:
        if adjustment_amount == 0 and (write_off > 0 or patient_responsibility > 0):
            adjustment_amount = write_off + patient_responsibility
        record.update({
            'Allowed Amount': allowed_amount,
            'Write Off': write_off,
            'Patient Responsibility': patient_responsibility,
            'Adjustment Amount': adjustment_amount,
        })
        extracted_data.append(record)

    if debug:
        print("Parsed ERA Content:")
        for data in extracted_data:
            print(data)

    return extracted_data

def parse_277_content(content, debug=False):
    segments = content.split('~')
    records = []
    current_record = {}
    segment_buffer = []

    def _append_message(target, text):
        if not text:
            return
        target.setdefault('messages', [])
        target['messages'].append(text)

    for segment in segments:
        segment = segment.strip()
        if not segment:
            continue
        parts = _277_SEGMENT_PATTERN.split(segment)
        tag = parts[0] if parts else ''
        if not tag:
            continue

        segment_buffer.append(segment)
        
        # Use TRN*2 segments as claim record boundaries (TRN*2 contains claim control number)
        if tag == 'TRN' and len(parts) > 1 and parts[1] == '2':
            # This is a claim-level TRN segment - save previous record if it has a claim number
            if current_record and current_record.get('Claim #'):
                # Save the previous record (excluding current TRN segment from its buffer)
                prev_buffer = segment_buffer[:-1] if len(segment_buffer) > 1 else []
                current_record['raw_segments'] = prev_buffer
                records.append(current_record)
                current_record = {}
                segment_buffer = [segment]  # Start new buffer with current TRN segment
            # Extract claim number from TRN*2 for the new record
            if len(parts) > 2:
                current_record['Claim #'] = parts[2]
        
        if tag == 'HL':
            # Also check for patient-level HL segments (HL*4*3*PT) as record completion marker
            is_patient_level = len(parts) > 3 and parts[3] == 'PT'
            if is_patient_level and current_record and current_record.get('Claim #'):
                # Mark that we've reached patient level - record is complete
                # Don't save yet, wait for next TRN*2 or end of file
                pass

        if tag == 'NM1':
            if len(parts) > 3:
                if parts[1] == 'QC':
                    current_record['Patient'] = ' '.join([parts[3], parts[4]]) if len(parts) > 4 else parts[3]
                elif parts[1] == '41':
                    current_record['Clearing House'] = parts[3]
                elif parts[1] == 'PR':
                    current_record['Payer'] = parts[3]
                    for idx in range(4, len(parts)):
                        if parts[idx] == 'PI' and idx + 1 < len(parts):
                            current_record['Payer ID'] = parts[idx + 1]
                            current_record['payer_id'] = parts[idx + 1]
                            break
        elif tag == 'TRN' and len(parts) > 2:
            # TRN*1 is transaction set level, TRN*2 is claim level (already handled above)
            if len(parts) > 1 and parts[1] == '1':
                # Transaction set level TRN
                if len(parts) > 2:
                    current_record['Transaction ID'] = parts[2]
            elif len(parts) > 1 and parts[1] != '2':
                # Other TRN types
                if len(parts) > 2:
                    current_record['Control ID'] = parts[2]
        elif tag == 'STC' and len(parts) > 1:
            current_record['Status'] = parts[1]
            _append_message(current_record, "STC status: {}".format(parts[1]))
            if len(parts) > 4:
                current_record['Paid'] = parts[4]
                _append_message(current_record, "Paid amount: {}".format(parts[4]))
        elif tag == 'DTP' and len(parts) > 3:
            if parts[1] == '472':
                current_record['Serv.'] = parts[3]
            elif parts[1] == '050':
                current_record['Proc.'] = parts[3]
        elif tag == 'AMT' and len(parts) > 2:
            if parts[1] == 'YU':
                current_record['Charged'] = parts[2]
        elif tag == 'REF' and len(parts) > 2:
            qualifier = parts[1]
            value = parts[2]
            if qualifier == '1K':
                current_record['payer_claim_number'] = value
                _append_message(current_record, "Payer claim #: {}".format(value))
            elif qualifier == 'TJ':
                current_record['Trace'] = value
            elif qualifier == 'D9':
                current_record['Claim ID'] = value
        elif tag == 'QTY' and len(parts) > 2:
            if parts[1] == '90':
                current_record['Quantity'] = parts[2]
            elif parts[1] == 'QA':
                current_record['Adjudicated Quantity'] = parts[2]

    if current_record:
        current_record['raw_segments'] = segment_buffer[:]
        records.append(current_record)

    if debug:
        print("Parsed 277 Content:")
        for record in records:
            print(record)

    return records

def parse_277IBR_content(content, debug=False):
    return parse_277_content(content, debug)

def parse_277EBR_content(content, debug=False):
    return parse_277_content(content, debug)

def parse_277DPR_content(content, debug=False):
    return parse_277_content(content, debug)

def parse_dpt_content(content, debug=False):
    extracted_data = []
    lines = content.splitlines()
    record = {}
    
    for line in lines:
        if 'Patient Account Number:' in line:
            if record and record.get('Patient Account Number'):
                # Only save if we have a claim record (has Patient Account Number)
                extracted_data.append(record)
            record = {}  # Start new record
        
        # Use regex pattern like EBT to find multiple key-value pairs per line
        matches = _EBT_KEY_VALUE_PATTERN.findall(line)
        if matches:
            for key, value in matches:
                key = key.strip()
                value = value.strip()
                record[key] = value  # Add key-value pair to current record
    
    if record and record.get('Patient Account Number'):
        extracted_data.append(record)  # Add final record only if it has claim data

    if debug:
        print("Parsed DPT Content:")
        for data in extracted_data:
            print(data)

    return extracted_data

def parse_ebt_content(content, debug=False):
    extracted_data = []  # List to hold all extracted records
    lines = content.splitlines()  # Split the content into individual lines
    record = {}  # Dictionary to hold the current record being processed
    
    for line in lines:
        # Check for the start of a new record based on the presence of 'Patient Name'
        if 'Patient Name:' in line and record:
            ebt_post_processor(record)  # Process the current record before adding it to the list
            extracted_data.append(record)  # Add the completed record to the list
            record = {}  # Reset the record for the next entry

        # Find all key-value pairs in the current line
        matches = _EBT_KEY_VALUE_PATTERN.findall(line)
        for key, value in matches:
            key = key.strip()  # Remove leading/trailing whitespace from the key
            value = value.strip()  # Remove leading/trailing whitespace from the value
            record[key] = value  # Add the key-value pair to the current record

    # Process and add the last record if it exists
    if record:
        ebt_post_processor(record)  # Final processing of the last record
        extracted_data.append(record)  # Add the last record to the list

    # Debug output to show parsed data if debugging is enabled
    if debug:
        print("Parsed EBT Content:")
        for data in extracted_data:
            print(data)

    return extracted_data  # Return the list of extracted records

def ebt_post_processor(record):
    # Process the 'Message Initiator' field to separate it from 'Message Type'
    if 'Message Initiator' in record and 'Message Type:' in record['Message Initiator']:
        parts = record['Message Initiator'].split('Message Type:')  # Split the string into parts
        record['Message Initiator'] = parts[0].strip()  # Clean up the 'Message Initiator'
        record['Message Type'] = parts[1].strip()  # Clean up the 'Message Type'

def parse_ibt_content(content, debug=False):
    extracted_data = []
    lines = content.splitlines()
    record = {}
    pending_value_continuation = None  # Track if we're waiting for a value continuation
    
    for i, line in enumerate(lines):
        line = line.strip()
        if not line:
            # Handle continuation: if we have a pending value and this is an empty/whitespace line,
            # check if next line continues the value
            if pending_value_continuation and i + 1 < len(lines):
                next_line = lines[i + 1].strip()
                if next_line and ':' not in next_line:
                    # Next line continues the value
                    continue
            pending_value_continuation = None
            continue
            
        # Check for the start of a new record based on 'Submitter Batch ID:'
        if 'Submitter Batch ID:' in line:
            if record and record.get('Patient Control Number'):
                # Only save if we have a claim record (has Patient Control Number)
                extracted_data.append(record)
            record = {}  # Start new record
            pending_value_continuation = None
        
        # Use regex pattern like EBT to find multiple key-value pairs per line
        matches = _EBT_KEY_VALUE_PATTERN.findall(line)
        if matches:
            for key, value in matches:
                key = key.strip()
                value = value.strip()
                # Check if this might be a continuation of previous value
                if pending_value_continuation:
                    record[pending_value_continuation] = record[pending_value_continuation] + value
                    pending_value_continuation = None
                else:
                    record[key] = value
                    # Check if value looks incomplete (short numeric value that might continue)
                    if value and value[-1].isdigit() and len(value) < 15 and i + 1 < len(lines):
                        next_line = lines[i + 1].strip() if i + 1 < len(lines) else ''
                        if next_line and ':' not in next_line and next_line.isdigit():
                            pending_value_continuation = key
        elif pending_value_continuation:
            # This line continues the previous value
            record[pending_value_continuation] = record[pending_value_continuation] + line
            pending_value_continuation = None
    
    if record and record.get('Patient Control Number'):
        extracted_data.append(record)  # Add final record only if it has claim data

    if debug:
        print("Parsed IBT Content:")
        for data in extracted_data:
            print(data)

    return extracted_data

def parse_999_content(content, debug=False):
    """
    Minimal 999 Implementation Acknowledgment parser.
    Extracts overall transaction set acknowledgment (AK9) and per-set (AK5) statuses when available.
    Returns a list with a single summary dict plus optional per-set entries.
    """
    records = []
    segments = content.split('~')
    overall_status = None
    functional_id = None
    control_numbers = []  # AK2 ST02 values
    per_set_statuses = []  # List of {'set_control': str, 'status': str}

    for seg in segments:
        parts = seg.split('*')
        if not parts or not parts[0]:
            continue
        tag = parts[0]
        if tag == 'AK1' and len(parts) > 1:
            functional_id = parts[1]
        elif tag == 'AK2' and len(parts) > 2:
            # Transaction Set Acknowledgment - capture ST02 control number
            control_numbers.append(parts[2])
        elif tag == 'AK5' and len(parts) > 1:
            # Transaction Set Response Trailer - status code in AK5-01 (A, E, R)
            status_code = parts[1]
            per_set_statuses.append({'status': status_code})
        elif tag == 'AK9' and len(parts) > 1:
            # Functional Group Response Trailer - overall status in AK9-01
            overall_status = parts[1]

    # Map X12 codes to friendly text
    status_map = {'A': 'Accepted', 'E': 'Accepted with Errors', 'R': 'Rejected'}
    overall_text = status_map.get(overall_status, overall_status or '')

    summary = {
        'Ack Type': '999',
        'Functional ID': functional_id or '',
        'Status': overall_text,
        'Sets Acknowledged': len(control_numbers) if control_numbers else 0,
    }
    records.append(summary)

    # Optionally include per-set detail rows
    for idx, st in enumerate(per_set_statuses):
        detail = {
            'Ack Type': '999',
            'Functional ID': functional_id or '',
            'Set #': str(idx + 1),
            'Status': status_map.get(st.get('status', ''), st.get('status', '')),
        }
        # Claim # not available in 999; leave out
        records.append(detail)

    if debug:
        print('Parsed 999 Content:')
        for r in records:
            print(r)
    return records

def determine_file_type(file_path):
    file_extensions = {
        '.era': 'ERA',
        '.277': '277',
        '.277ibr': '277IBR',
        '.277ebr': '277EBR',
        '.277dpr': '277DPR',
        '.dpt': 'DPT',
        '.ebt': 'EBT',
        '.ibt': 'IBT',
        '.999': '999'
    }
    
    for ext, file_type in file_extensions.items():
        if file_path.endswith(ext):
            return file_type
            
    log("Unsupported file type for file: {}".format(file_path))
    return None