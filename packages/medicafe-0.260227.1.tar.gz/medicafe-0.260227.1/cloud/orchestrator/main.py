"""Entrypoint for Cloud Run deployment."""

import sys
import os

# Ensure the current directory is in the Python path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

# Import the FastAPI app
from api import APP as app

__all__ = ["app"]

