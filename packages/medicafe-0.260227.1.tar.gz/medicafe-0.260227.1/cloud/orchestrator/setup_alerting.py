from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Dict, List, Optional, Tuple

RUNBOOK_LINK = "docs/runbooks/MediLink_Gmail_Orchestrator_Operations.md"
_GCLOUD_EXE_CACHE: Optional[str] = None

EXPECTED_POLICY_DISPLAY_NAMES = (
    "MediLink Orchestrator - Cloud Run 5xx errors",
    "MediLink Orchestrator - Cloud Run startup or crash logs",
    "MediLink Orchestrator - Scheduler refresh failures",
    "MediLink Orchestrator - PubSub undelivered backlog",
    "MediLink Orchestrator - PubSub oldest unacked age",
    "MediLink Orchestrator - Watch refresh stale",
)


def _emit_decision(msg: str) -> None:
    """Emit a decision trace line for operator transparency."""
    print("DECISION: {}".format(msg))


def _gcloud_exe() -> str:
    """Resolve a callable gcloud executable across Windows/Linux shells."""
    global _GCLOUD_EXE_CACHE
    if _GCLOUD_EXE_CACHE:
        return _GCLOUD_EXE_CACHE
    for name in ("gcloud", "gcloud.cmd", "gcloud.exe"):
        path = shutil.which(name)
        if path:
            _GCLOUD_EXE_CACHE = path
            return path
    _GCLOUD_EXE_CACHE = "gcloud"
    return _GCLOUD_EXE_CACHE


def _gcloud_available() -> bool:
    for name in ("gcloud", "gcloud.cmd", "gcloud.exe"):
        if shutil.which(name):
            return True
    return False


def _run(cmd: List[str]) -> str:
    cmd_list = list(cmd)
    if cmd_list and cmd_list[0] == "gcloud":
        cmd_list[0] = _gcloud_exe()
    try:
        proc = subprocess.run(cmd_list, capture_output=True, text=True)
    except FileNotFoundError as exc:
        raise RuntimeError("Executable not found: {}".format(cmd_list[0])) from exc
    if proc.returncode != 0:
        raise RuntimeError(
            "Command failed ({}): {}".format(" ".join(cmd_list), proc.stderr.strip() or proc.stdout.strip())
        )
    return proc.stdout.strip()


def _access_token(explicit: Optional[str]) -> str:
    if explicit:
        return explicit
    return _run(["gcloud", "auth", "print-access-token"])


def _request_json(method: str, url: str, token: str, body: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    payload = None
    headers = {
        "Authorization": "Bearer {}".format(token),
        "Content-Type": "application/json",
    }
    if body is not None:
        payload = json.dumps(body).encode("utf-8")

    req = urllib.request.Request(url, data=payload, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        err = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError("HTTP {} for {} {}: {}".format(exc.code, method, url, err)) from exc


def _list_alert_policies(project_id: str, token: str) -> List[Dict[str, Any]]:
    url = "https://monitoring.googleapis.com/v3/projects/{}/alertPolicies?pageSize=100".format(project_id)
    policies: List[Dict[str, Any]] = []
    while url:
        payload = _request_json("GET", url, token)
        policies.extend(payload.get("alertPolicies", []))
        next_page = payload.get("nextPageToken")
        if next_page:
            url = (
                "https://monitoring.googleapis.com/v3/projects/{}/alertPolicies?pageSize=100&pageToken={}".format(
                    project_id, urllib.parse.quote(next_page)
                )
            )
        else:
            url = ""
    return policies


def _list_notification_channels(project_id: str, token: str) -> List[Dict[str, Any]]:
    url = "https://monitoring.googleapis.com/v3/projects/{}/notificationChannels?pageSize=100".format(project_id)
    channels: List[Dict[str, Any]] = []
    while url:
        payload = _request_json("GET", url, token)
        channels.extend(payload.get("notificationChannels", []))
        next_page = payload.get("nextPageToken")
        if next_page:
            url = (
                "https://monitoring.googleapis.com/v3/projects/{}/notificationChannels?pageSize=100&pageToken={}".format(
                    project_id, urllib.parse.quote(next_page)
                )
            )
        else:
            url = ""
    return channels


def _active_gcloud_account() -> str:
    """Best-effort active gcloud account email for standalone setup_alerting runs."""
    try:
        return _run(["gcloud", "auth", "list", "--filter=status:ACTIVE", "--format=value(account)"]).strip()
    except Exception:
        return ""


def _ensure_email_notification_channel(
    project_id: str,
    token: str,
    email: str,
    dry_run: bool,
) -> Tuple[Optional[str], str, bool]:
    """
    Ensure an email notification channel exists for the target email.
    Returns (channel_name_or_none, message, verified).
    """
    target = (email or "").strip().lower()
    if not target:
        return None, "INFO: Notification email not set; channel auto-attach skipped.", False

    channels = _list_notification_channels(project_id, token)
    best: Optional[Dict[str, Any]] = None
    for ch in channels:
        if str(ch.get("type") or "").lower() != "email":
            continue
        labels = ch.get("labels") or {}
        addr = str(labels.get("email_address") or "").strip().lower()
        if addr != target:
            continue
        if best is None:
            best = ch
        if str(ch.get("verificationStatus") or "").upper() == "VERIFIED":
            best = ch
            break

    if best is not None:
        name = str(best.get("name") or "")
        verified = str(best.get("verificationStatus") or "").upper() == "VERIFIED"
        msg = "INFO: Using existing email notification channel for {}{}".format(
            target,
            "" if verified else " (UNVERIFIED: verify in Monitoring channels)",
        )
        return name, msg, verified

    if dry_run:
        return None, "DRY-RUN create email notification channel for {}".format(target), False

    body = {
        "type": "email",
        "displayName": "MediLink Alerts ({})".format(target),
        "enabled": True,
        "labels": {"email_address": target},
    }
    created = _request_json(
        "POST",
        "https://monitoring.googleapis.com/v3/projects/{}/notificationChannels".format(project_id),
        token,
        body,
    )
    name = str(created.get("name") or "")
    verified = str(created.get("verificationStatus") or "").upper() == "VERIFIED"
    msg = "CREATED email notification channel for {}{}".format(
        target,
        "" if verified else " (verification pending)",
    )
    return name, msg, verified


def _find_email_notification_channel_name(channels: List[Dict[str, Any]], email: str) -> Optional[str]:
    """Find an existing Monitoring email notification channel by email address."""
    target = (email or "").strip().lower()
    if not target:
        return None
    best_name: Optional[str] = None
    for ch in channels:
        if str(ch.get("type") or "").lower() != "email":
            continue
        labels = ch.get("labels") or {}
        addr = str(labels.get("email_address") or "").strip().lower()
        if addr != target:
            continue
        name = str(ch.get("name") or "")
        if not name:
            continue
        if best_name is None:
            best_name = name
        if str(ch.get("verificationStatus") or "").upper() == "VERIFIED":
            return name
    return best_name


def _upsert_alert_policy(
    project_id: str,
    token: str,
    desired: Dict[str, Any],
    existing_by_display_name: Dict[str, Dict[str, Any]],
    dry_run: bool,
    channels_explicitly_provided: bool = False,
    apply_channels_when_missing: bool = False,
) -> str:
    """
    Create or update an alert policy.
    Channel safety:
    - explicit channels: allow replace/update
    - auto channels: only fill channels when a policy currently has none
    """
    display_name = desired["displayName"]
    existing = existing_by_display_name.get(display_name)

    if existing:
        policy_name = existing["name"]
        payload = dict(desired)
        payload["name"] = policy_name
        if dry_run:
            return "DRY-RUN update {} ({})".format(display_name, policy_name)

        update_fields = [
            "display_name",
            "documentation",
            "user_labels",
            "conditions",
            "combiner",
            "enabled",
            "alert_strategy",
            "severity",
        ]
        # Hard guardrail:
        # - explicit channels can replace/update
        # - auto channel mode can only fill missing channels (never replace)
        # - when no channels provided: never touch notification_channels (preserve existing)
        if "notificationChannels" in desired and (
            channels_explicitly_provided
            or (apply_channels_when_missing and not existing.get("notificationChannels"))
        ):
            update_fields.append("notification_channels")
        else:
            # Preserve existing channels: omit from payload so we never overwrite with []
            payload.pop("notificationChannels", None)
        update_mask = urllib.parse.quote(",".join(update_fields))
        _request_json(
            "PATCH",
            "https://monitoring.googleapis.com/v3/{}?updateMask={}".format(policy_name, update_mask),
            token,
            payload,
        )
        return "UPDATED {}".format(display_name)

    if dry_run:
        return "DRY-RUN create {}".format(display_name)

    _request_json(
        "POST",
        "https://monitoring.googleapis.com/v3/projects/{}/alertPolicies".format(project_id),
        token,
        desired,
    )
    return "CREATED {}".format(display_name)


def _upsert_log_metric(
    project_id: str,
    token: str,
    metric_name: str,
    description: str,
    filter_text: str,
    dry_run: bool,
) -> str:
    metric_url = "https://logging.googleapis.com/v2/projects/{}/metrics/{}".format(project_id, metric_name)
    create_url = "https://logging.googleapis.com/v2/projects/{}/metrics".format(project_id)
    body = {
        "name": metric_name,
        "description": description,
        "filter": filter_text,
    }

    try:
        _request_json("GET", metric_url, token)
        if dry_run:
            return "DRY-RUN update log metric {}".format(metric_name)
        _request_json("PUT", metric_url, token, body)
        return "UPDATED log metric {}".format(metric_name)
    except RuntimeError as exc:
        if "HTTP 404" not in str(exc):
            raise

    if dry_run:
        return "DRY-RUN create log metric {}".format(metric_name)

    _request_json("POST", create_url, token, body)
    return "CREATED log metric {}".format(metric_name)


def _policy_specs(args: argparse.Namespace) -> List[Dict[str, Any]]:
    channels = args.notification_channel
    labels = {
        "component": "medilink-gmail-orchestrator",
        "managed_by": "setup_alerting_py",
    }

    run_5xx_filter = (
        'resource.type="cloud_run_revision" '
        'AND metric.type="run.googleapis.com/request_count" '
        'AND metric.labels.response_code_class="5xx" '
        'AND resource.labels.service_name="{}"'.format(args.service_name)
    )
    run_crash_log_filter = (
        'resource.type="cloud_run_revision" '
        'AND resource.labels.service_name="{}" '
        'AND (textPayload:("Traceback" OR "Container failed to start" OR "failed to listen" OR "CrashLoopBackOff") '
        'OR jsonPayload.message:("Traceback" OR "Container failed to start" OR "failed to listen" OR "CrashLoopBackOff"))'
    ).format(args.service_name)

    scheduler_failure_log_filter = (
        'resource.type="cloud_scheduler_job" '
        'AND resource.labels.job_id="{}" '
        'AND jsonPayload."@type"="type.googleapis.com/google.cloud.scheduler.logging.AttemptFinished" '
        'AND (jsonPayload.status!="OK" OR httpRequest.status>=400)'
    ).format(args.scheduler_job)

    pubsub_backlog_filter = (
        'resource.type="pubsub_subscription" '
        'AND metric.type="pubsub.googleapis.com/subscription/num_undelivered_messages" '
        'AND resource.labels.subscription_id="{}"'
    ).format(args.subscription)

    pubsub_oldest_age_filter = (
        'resource.type="pubsub_subscription" '
        'AND metric.type="pubsub.googleapis.com/subscription/oldest_unacked_message_age" '
        'AND resource.labels.subscription_id="{}"'
    ).format(args.subscription)

    watch_stale_metric_filter = (
        'metric.type="logging.googleapis.com/user/medilink_resume_history_success_count" '
        'AND resource.type="cloud_run_revision" '
        'AND resource.labels.service_name="{}"'
    ).format(args.service_name)

    policies = [
        {
            "displayName": "MediLink Orchestrator - Cloud Run 5xx errors",
            "documentation": {
                "content": (
                    "Cloud Run returned 5xx responses for service {}. "
                    "Start with runtime verify and /admin/resume-history request logs. "
                    "Runbook: {}"
                ).format(args.service_name, RUNBOOK_LINK),
                "mimeType": "text/markdown",
            },
            "combiner": "OR",
            "enabled": True,
            "severity": "ERROR",
            "userLabels": labels,
            "notificationChannels": channels,
            "conditions": [
                {
                    "displayName": "5xx request count > 0 for 10m",
                    "conditionThreshold": {
                        "filter": run_5xx_filter,
                        "comparison": "COMPARISON_GT",
                        "thresholdValue": 0,
                        "duration": "600s",
                        "aggregations": [
                            {
                                "alignmentPeriod": "300s",
                                "perSeriesAligner": "ALIGN_SUM",
                            }
                        ],
                        "trigger": {"count": 1},
                    },
                }
            ],
            "alertStrategy": {"autoClose": "1800s"},
        },
        {
            "displayName": "MediLink Orchestrator - Cloud Run startup or crash logs",
            "documentation": {
                "content": (
                    "Cloud Run startup/crash error patterns detected in logs for {}. "
                    "Inspect latest revision logs and rollback/fix env if needed. "
                    "Runbook: {}"
                ).format(args.service_name, RUNBOOK_LINK),
                "mimeType": "text/markdown",
            },
            "combiner": "OR",
            "enabled": True,
            "severity": "ERROR",
            "userLabels": labels,
            "notificationChannels": channels,
            "conditions": [
                {
                    "displayName": "Startup/crash log entries",
                    "conditionMatchedLog": {
                        "filter": run_crash_log_filter,
                    },
                }
            ],
            "alertStrategy": {
                "autoClose": "3600s",
                # Required by Monitoring API for conditionMatchedLog policies.
                "notificationRateLimit": {"period": "300s"},
            },
        },
        {
            "displayName": "MediLink Orchestrator - Scheduler refresh failures",
            "documentation": {
                "content": (
                    "Cloud Scheduler job {} failed (non-OK status or non-2xx HTTP). "
                    "Check execution logs and verify OIDC audience + ADMIN_SHARED_SECRET. "
                    "Runbook: {}"
                ).format(args.scheduler_job, RUNBOOK_LINK),
                "mimeType": "text/markdown",
            },
            "combiner": "OR",
            "enabled": True,
            "severity": "ERROR",
            "userLabels": labels,
            "notificationChannels": channels,
            "conditions": [
                {
                    "displayName": "Scheduler attempt failure logs",
                    "conditionMatchedLog": {
                        "filter": scheduler_failure_log_filter,
                    },
                }
            ],
            "alertStrategy": {
                "autoClose": "3600s",
                # Required by Monitoring API for conditionMatchedLog policies.
                "notificationRateLimit": {"period": "300s"},
            },
        },
        {
            "displayName": "MediLink Orchestrator - PubSub undelivered backlog",
            "documentation": {
                "content": (
                    "Subscription {} has sustained undelivered messages above threshold. "
                    "Review push delivery and processor health. Runbook: {}"
                ).format(args.subscription, RUNBOOK_LINK),
                "mimeType": "text/markdown",
            },
            "combiner": "OR",
            "enabled": True,
            "severity": "WARNING",
            "userLabels": labels,
            "notificationChannels": channels,
            "conditions": [
                {
                    "displayName": "Undelivered messages > {}".format(args.backlog_threshold),
                    "conditionThreshold": {
                        "filter": pubsub_backlog_filter,
                        "comparison": "COMPARISON_GT",
                        "thresholdValue": float(args.backlog_threshold),
                        "duration": "{}s".format(args.backlog_duration_minutes * 60),
                        "aggregations": [
                            {
                                "alignmentPeriod": "300s",
                                "perSeriesAligner": "ALIGN_MEAN",
                            }
                        ],
                        "trigger": {"count": 1},
                    },
                }
            ],
            "alertStrategy": {"autoClose": "3600s"},
        },
        {
            "displayName": "MediLink Orchestrator - PubSub oldest unacked age",
            "documentation": {
                "content": (
                    "Subscription {} has old unacked messages (stale ingestion). "
                    "Review Cloud Run push path and queue processing logs. Runbook: {}"
                ).format(args.subscription, RUNBOOK_LINK),
                "mimeType": "text/markdown",
            },
            "combiner": "OR",
            "enabled": True,
            "severity": "ERROR",
            "userLabels": labels,
            "notificationChannels": channels,
            "conditions": [
                {
                    "displayName": "Oldest unacked age > {}m".format(args.oldest_unacked_age_minutes),
                    "conditionThreshold": {
                        "filter": pubsub_oldest_age_filter,
                        "comparison": "COMPARISON_GT",
                        "thresholdValue": float(args.oldest_unacked_age_minutes * 60),
                        "duration": "900s",
                        "aggregations": [
                            {
                                "alignmentPeriod": "300s",
                                "perSeriesAligner": "ALIGN_MAX",
                            }
                        ],
                        "trigger": {"count": 1},
                    },
                }
            ],
            "alertStrategy": {"autoClose": "3600s"},
        },
        {
            "displayName": "MediLink Orchestrator - Watch refresh stale",
            "documentation": {
                "content": (
                    "No successful /admin/resume-history refresh in expected interval for {}. "
                    "Check scheduler health and resume-history request logs. Runbook: {}"
                ).format(args.service_name, RUNBOOK_LINK),
                "mimeType": "text/markdown",
            },
            "combiner": "OR",
            "enabled": True,
            "severity": "WARNING",
            "userLabels": labels,
            "notificationChannels": channels,
            "conditions": [
                {
                    "displayName": "No refresh success in {}h".format(args.watch_stale_hours),
                    "conditionAbsent": {
                        "filter": watch_stale_metric_filter,
                        "duration": "{}s".format(args.watch_stale_hours * 3600),
                        "aggregations": [
                            {
                                "alignmentPeriod": "3600s",
                                "perSeriesAligner": "ALIGN_SUM",
                            }
                        ],
                        "trigger": {"count": 1},
                    },
                }
            ],
            "alertStrategy": {"autoClose": "7200s"},
        },
    ]

    if channels is None:
        for policy in policies:
            policy.pop("notificationChannels", None)

    return policies


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Create or update MediLink Gmail orchestrator alert policies.")
    parser.add_argument("--project-id", required=True)
    parser.add_argument("--service-name", default="medilink-gmail-orchestrator")
    parser.add_argument("--scheduler-job", default="gmail-watch-refresh")
    parser.add_argument("--subscription", default="gmail-new-emails-sub")
    parser.add_argument("--backlog-threshold", type=int, default=20)
    parser.add_argument("--backlog-duration-minutes", type=int, default=15)
    parser.add_argument("--oldest-unacked-age-minutes", type=int, default=30)
    parser.add_argument("--watch-stale-hours", type=int, default=8)
    parser.add_argument(
        "--notification-channel",
        action="append",
        help="Monitoring channel resource name. Repeat for multiple channels.",
    )
    parser.add_argument(
        "--notification-email",
        default="",
        help=(
            "Email target for automatic channel management. When provided (or inferable from active gcloud account), "
            "the script can create/reuse an email channel and attach it only to policies missing channels."
        ),
    )
    parser.add_argument(
        "--access-token",
        help="Optional OAuth2 bearer token. If omitted, script tries gcloud auth print-access-token.",
    )
    parser.add_argument("--dry-run", action="store_true", help="Show create/update actions without writing resources.")
    parser.add_argument(
        "--plan-only",
        action="store_true",
        help="Print computed policy and metric definitions without any API calls.",
    )
    parser.add_argument(
        "--check-drift",
        action="store_true",
        help="Check alert policy drift; exit 0=no drift, 1=drift, 2=cannot assess. Does not modify resources.",
    )
    return parser


def _is_ci_environment() -> bool:
    for name in ("CI", "GITHUB_ACTIONS", "BUILD_BUILDID", "TF_BUILD", "TEAMCITY_VERSION"):
        if os.environ.get(name):
            return True
    return False


def _print_guidance(args: argparse.Namespace) -> None:
    print("INFO: To apply policies (instead of plan output):")
    print("  1) gcloud auth login")
    print("  2) py -3.11 cloud/orchestrator/setup_alerting.py --project-id {}".format(args.project_id))
    print("  3) Optional non-gcloud path: --access-token <TOKEN>")
    print("  4) Runbook: {}".format(RUNBOOK_LINK))


def _resolve_execution_path(args: argparse.Namespace) -> Tuple[bool, Optional[str]]:
    """
    Return (effective_plan_only, access_token).

    Safety behavior:
    - If --plan-only is set, always plan-only.
    - If --access-token is set, attempt API path with that token.
    - Else auto-detect gcloud availability/auth; if unavailable, auto-fallback to plan-only.
    """
    if args.plan_only:
        return True, None

    if args.access_token:
        return False, args.access_token

    if not _gcloud_available():
        print("WARN: gcloud is not installed; auto-switching to --plan-only for safe output.")
        _print_guidance(args)
        return True, None

    try:
        token = _access_token(None)
        return False, token
    except Exception as exc:
        if _is_ci_environment():
            print("WARN: Could not get gcloud access token in CI ({}).".format(exc))
            print("WARN: Auto-switching to --plan-only to keep CI non-destructive.")
            _print_guidance(args)
            return True, None
        raise


def _check_drift(args: argparse.Namespace) -> int:
    """
    Check for alert policy drift.
    Exit 0: no drift; 1: drift (missing/disabled); 2: cannot assess (token/permission failure).
    Drift detection: policy presence and enabled state. Config drift (thresholds, filters) not yet compared.
    """
    if not args.access_token and (not _gcloud_available()):
        _emit_decision("Cannot get access token -> cannot check drift: gcloud executable not found in PATH")
        return 2
    try:
        token = _access_token(args.access_token)
    except Exception as exc:
        _emit_decision("Cannot get access token -> cannot check drift: {}".format(exc))
        return 2
    try:
        existing = _list_alert_policies(args.project_id, token)
    except RuntimeError as exc:
        err_str = str(exc)
        if "403" in err_str or "PERMISSION_DENIED" in err_str:
            _emit_decision("Monitoring API permission denied -> cannot check drift; run with monitoring.admin or monitoring.alertPolicyViewer")
            return 2
        raise
    by_name = {p.get("displayName", ""): p for p in existing if p.get("displayName")}
    missing = [n for n in EXPECTED_POLICY_DISPLAY_NAMES if n not in by_name]
    disabled = [n for n in EXPECTED_POLICY_DISPLAY_NAMES if n in by_name and not by_name[n].get("enabled", True)]

    channel_gap = []
    channel_note = "not checked"
    target_email = (args.notification_email or "").strip().lower() or _active_gcloud_account()
    if args.notification_channel:
        for display_name in EXPECTED_POLICY_DISPLAY_NAMES:
            existing_policy = by_name.get(display_name)
            if not existing_policy or not existing_policy.get("enabled", True):
                continue
            current = set(existing_policy.get("notificationChannels") or [])
            if not any(ch in current for ch in args.notification_channel):
                channel_gap.append(display_name)
        channel_note = "explicit channels checked"
    elif target_email:
        try:
            channels = _list_notification_channels(args.project_id, token)
        except RuntimeError as exc:
            err_str = str(exc)
            if "403" in err_str or "PERMISSION_DENIED" in err_str:
                _emit_decision("Monitoring API permission denied -> cannot check notification channel drift")
                return 2
            raise
        channel_name = _find_email_notification_channel_name(channels, target_email)
        if not channel_name:
            channel_note = "email channel missing for {}".format(target_email)
            for display_name in EXPECTED_POLICY_DISPLAY_NAMES:
                existing_policy = by_name.get(display_name)
                if not existing_policy or not existing_policy.get("enabled", True):
                    continue
                if not (existing_policy.get("notificationChannels") or []):
                    channel_gap.append(display_name)
        else:
            channel_note = "email channel resolved for {}".format(target_email)
            for display_name in EXPECTED_POLICY_DISPLAY_NAMES:
                existing_policy = by_name.get(display_name)
                if not existing_policy or not existing_policy.get("enabled", True):
                    continue
                if not (existing_policy.get("notificationChannels") or []):
                    channel_gap.append(display_name)
    else:
        channel_note = "no target email/channel provided"

    if missing or disabled or channel_gap:
        _emit_decision(
            "alert policy drift detected -> missing: {}; disabled: {}; channel_gap: {}; channels: {}".format(
                missing or "none",
                disabled or "none",
                channel_gap or "none",
                channel_note,
            )
        )
        return 1
    _emit_decision("no drift -> skipping alert reconcile")
    return 0


def main() -> int:
    args = _build_parser().parse_args()

    if args.check_drift:
        return _check_drift(args)

    try:
        metric_filter = (
            'resource.type="cloud_run_revision" '
            'AND resource.labels.service_name="{}" '
            'AND httpRequest.requestUrl:"/admin/resume-history" '
            'AND httpRequest.status=200'
        ).format(args.service_name)

        policies = _policy_specs(args)
        plan_only, token = _resolve_execution_path(args)

        if plan_only:
            print("PLAN-ONLY: no API calls made.")
            print(
                json.dumps(
                    {
                        "project_id": args.project_id,
                        "log_metric": {
                            "name": "medilink_resume_history_success_count",
                            "description": "MediLink orchestrator watch refresh success counter.",
                            "filter": metric_filter,
                        },
                        "policies": policies,
                    },
                    indent=2,
                )
            )
            return 0

        print("Using project {}".format(args.project_id))
        print(
            _upsert_log_metric(
                args.project_id,
                str(token),
                "medilink_resume_history_success_count",
                "MediLink orchestrator watch refresh success counter.",
                metric_filter,
                args.dry_run,
            )
        )

        existing = _list_alert_policies(args.project_id, str(token))
        by_name = {p.get("displayName", ""): p for p in existing if p.get("displayName")}

        auto_channels_added = False
        if not args.notification_channel:
            auto_email = (args.notification_email or "").strip() or _active_gcloud_account()
            if auto_email:
                channel_name, channel_msg, verified = _ensure_email_notification_channel(
                    args.project_id,
                    str(token),
                    auto_email,
                    args.dry_run,
                )
                print(channel_msg)
                if channel_name:
                    args.notification_channel = [channel_name]
                    auto_channels_added = True
                    _emit_decision(
                        "auto notification channel selected for {} -> apply to policies missing channels only".format(
                            auto_email
                        )
                    )
                    if not verified:
                        print("WARN: Notification channel is not yet verified. Confirm verification in Cloud Monitoring channels.")

        if not args.notification_channel:
            _emit_decision("no notification channels provided -> create=no channels; update=preserve existing; never remove/replace")
            print("INFO: No notification channels specified. Existing policy channels will be preserved.")
            print("INFO: Add one or more --notification-channel flags to set/replace paging/email targets.")

        channels_provided = bool(args.notification_channel) and (not auto_channels_added)
        apply_channels_when_missing = auto_channels_added
        if channels_provided:
            _emit_decision("high-impact action (notification channel replace) -> explicit --notification-channel provided")
        for policy in policies:
            print(_upsert_alert_policy(
                args.project_id, str(token), policy, by_name, args.dry_run,
                channels_explicitly_provided=channels_provided,
                apply_channels_when_missing=apply_channels_when_missing,
            ))

        print("Done.")
        return 0
    except Exception as exc:
        print("ERROR: {}".format(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
