# Cloud Orchestrator Documentation Archive

This directory contains previous versions of setup documentation that have been consolidated into the main Setup Guide.

## 📋 Archived Documents

### November 2025 Consolidation

**Consolidated Into**: [../SETUP_GUIDE.md](../SETUP_GUIDE.md)

**Archived Files**:
- `FRESH_SETUP_GUIDE.md` - Fresh setup instructions (direct service account approach)
- `QUICK_START.md` - Quick start guide for experienced users
- `SETUP_GUIDE.md` (old) - Comprehensive setup guide (domain-wide delegation approach)

## 🔄 What Changed

**Previously**: Three separate setup guides with overlapping content and some contradictory information
- Different setup approaches (domain-wide delegation vs. direct access)
- Redundant instructions
- Unclear which guide to follow

**Now**: Single authoritative [SETUP_GUIDE.md](../SETUP_GUIDE.md)
- Clear progression: Overview → Quick Start → Detailed Setup
- Single approach (direct service account access - simpler and more secure)
- Consolidated troubleshooting section
- No contradictory information

## 📚 Key Differences

### Old Approach (Archived SETUP_GUIDE.md)
- Required domain-wide delegation in Google Workspace Admin
- Used service account keys (security risk)
- Complex OAuth flow with user impersonation
- Difficult to troubleshoot

### New Approach (Current SETUP_GUIDE.md)
- Direct service account access (no domain-wide delegation)
- Uses Workload Identity Federation (no keys stored)
- Service account owns its own Gmail inbox
- Simple ADC authentication
- Clear error messages

## 🔍 Finding Information

### If You Need...

| Topic | Location |
|-------|----------|
| **Current Setup Instructions** | [../SETUP_GUIDE.md](../SETUP_GUIDE.md) |
| **Quick Start** | [../SETUP_GUIDE.md#quick-start](../SETUP_GUIDE.md#quick-start) |
| **Detailed Setup** | [../SETUP_GUIDE.md#detailed-setup-process](../SETUP_GUIDE.md#detailed-setup-process) |
| **Troubleshooting** | [../SETUP_GUIDE.md#troubleshooting](../SETUP_GUIDE.md#troubleshooting) |
| **Historical Reference** | This archive directory |

## 📝 Why These Were Archived

1. **Consolidation**: Three overlapping guides merged into one comprehensive guide
2. **Approach Change**: Moved from domain-wide delegation to direct access (simpler, more secure)
3. **Clarity**: Eliminated conflicting information
4. **Maintenance**: Easier to maintain single authoritative guide

## 🔧 Accessing Archived Versions

To view archived documentation:

```bash
# From orchestrator directory
cd archive/
ls -la

# View specific file
cat FRESH_SETUP_GUIDE.md
```

Or via git history:
```bash
git log -- cloud/orchestrator/FRESH_SETUP_GUIDE.md
git show <commit-hash>:cloud/orchestrator/FRESH_SETUP_GUIDE.md
```

---

**Archive Created**: 2025-11-21  
**Current Guide**: [../SETUP_GUIDE.md](../SETUP_GUIDE.md)  
**Status**: ✅ Consolidated and Organized
