"""Authentication helpers for verifying XP agent tokens."""

from __future__ import annotations

import time
from typing import Any, Dict

import jwt
import requests

from config import Config


class AuthError(Exception):
    """Raised when an incoming request fails authentication."""


_JWKS_CACHE: Dict[str, Any] = {}
_JWKS_CACHE_EXPIRY = 0


def _load_public_key_from_jwks(token: str, jwks_url: str) -> Any:
    global _JWKS_CACHE_EXPIRY
    if _JWKS_CACHE and time.time() < _JWKS_CACHE_EXPIRY:
        jwks = _JWKS_CACHE
    else:
        response = requests.get(jwks_url, timeout=10)
        response.raise_for_status()
        jwks = response.json()
        _JWKS_CACHE.clear()
        _JWKS_CACHE.update(jwks)
        _JWKS_CACHE_EXPIRY = int(time.time()) + 600

    headers = jwt.get_unverified_header(token)
    kid = headers.get("kid")
    for key_obj in jwks.get("keys", []):
        if key_obj.get("kid") == kid:
            return jwt.algorithms.RSAAlgorithm.from_jwk(key_obj)
    raise AuthError("No matching JWK for key id {}".format(kid))


def _determine_verification_key(token: str, config: Config) -> Any:
    if config.xp_public_key_pem:
        return config.xp_public_key_pem
    if config.jwks_url:
        return _load_public_key_from_jwks(token, config.jwks_url)
    if config.service_account_info and config.service_account_info.get("private_key"):
        return config.service_account_info["private_key"]
    raise AuthError("No verification key configured for agent JWTs")


def verify_agent_jwt(token: str, config: Config) -> Dict[str, Any]:
    if not token:
        raise AuthError("Missing bearer token")

    key = _determine_verification_key(token, config)

    try:
        decoded = jwt.decode(
            token,
            key=key,
            algorithms=[config.xp_jwt_algorithm],
            audience=config.jwt_audience,
            issuer=config.jwt_issuer,
            options={"require": ["exp", "iat", "nbf", config.client_machine_claim]},
        )
    except jwt.PyJWTError as exc:
        raise AuthError("Token verification failed: {}".format(exc)) from exc

    now = int(time.time())
    if decoded.get("nbf", 0) > now + 60:
        raise AuthError("Token not valid yet")

    machine_id = decoded.get(config.client_machine_claim)
    if not machine_id:
        raise AuthError("Token missing machine claim {}".format(config.client_machine_claim))

    return decoded


def validate_machine_id(claims: Dict[str, Any], machine_id: str, config: Config) -> None:
    expected = claims.get(config.client_machine_claim)
    if not expected:
        raise AuthError("Authenticated token missing machine id claim")
    if machine_id != expected:
        raise AuthError("Machine id mismatch: {} != {}".format(machine_id, expected))

