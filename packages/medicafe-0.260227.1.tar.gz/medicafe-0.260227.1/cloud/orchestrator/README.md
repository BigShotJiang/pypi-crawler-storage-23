# MediLink Gmail Orchestrator

Cloud Run service for processing Gmail notifications and managing email attachments for MediLink clinics.

## Recent Improvements

- **Enhanced Startup Logging**: `startup.py` provides detailed logs during container startup
- **Lazy Configuration Loading**: Configuration loads when needed, not at import time
- **Extended Health Checks**: Health endpoint provides detailed diagnostic information
- **Environment Validation**: Validates required environment variables on startup

## Deployment

Canonical deployment and operations path:

```bash
py -3.11 cloud/orchestrator/validate_and_complete_setup.py
```

Use this script for build/deploy/remediation/verification because it keeps Cloud Run, Scheduler, auth mode, and runtime checks aligned.

Deprecated helpers such as `build_and_deploy.ps1` are retired to avoid drift from the validator-managed baseline.

### Nominal baseline (authoritative)

- Runtime steady state: `AUTH_MODE=dwd_required` (keyless DWD verified in logs).
- Setup fallback: validator watch registration may still use OAuth credentials from Secret Manager in operator/local contexts.
- Runtime watch/admin endpoints: use runtime auth path (`services.gmail_client(config)`) and require `ADMIN_SHARED_SECRET`.
- Break-glass posture: OAuth secrets are retained for rollback/recovery; this does not change runtime steady state.
- Routing in single-machine mode: when `DEFAULT_MACHINE_ID` is set, it is authoritative.

## Local Testing

To sanity-check local imports/startup with Python 3.11:

```powershell
cd cloud/orchestrator
py -3.11 -c "import main; print('ok')"
```

### Running Unit Tests

Minimal regression tests for core endpoints and decision logic:

```powershell
# From the cloud/orchestrator directory
py -3.11 -m unittest discover -s tests

# Or run specific test file
py -3.11 -m unittest tests.test_admin_resume_history
py -3.11 -m unittest tests.test_auth_mode_oauth
py -3.11 -m unittest tests.test_alert_reconcile
py -3.11 -m unittest tests.test_preprocessor
```

Note: Tests require `httpx` for FastAPI TestClient. Install with `py -3.11 -m pip install httpx` if running tests locally.

### Syntax verification

```powershell
py -3.11 cloud/orchestrator/verify_syntax.py
```

Uses py_compile primary; falls back to ast.parse when py_compile fails (e.g. __pycache__ permissions).

## Health Check

The service provides a detailed health check at `/health`:

```json
{
  "status": "ok",
  "service": "medilink-gmail-orchestrator",
  "version": "1.0.0",
  "config_loaded": "true|false",
  "project_id": "...",
  "mailbox_user": "...",
  "python_version": "3.x.x"
}
```

## Pub/Sub Push Reliability

`POST /pubsub/push` now uses retry-safe semantics:

- Permanent malformed push payload (`invalid_envelope_json`, `invalid_base64`, `invalid_json`, etc.): return `200` with `status=acked_permanent_error` to avoid poison-message loops.
- Processing/downstream failures (Gmail/Firestore/network/service): return `503` with `status=retryable_error` so Pub/Sub retries and then routes to DLQ after max delivery attempts.
- Success: return `200` with `status=ok`.

Handler logs include deterministic classification fields:

- `outcome`
- `message_id`
- `error_class`
- `retryable`

No behavior change is made to `/admin/resume-history` request verification flow.

### Backlog backfill

`POST /admin/backfill-backlog` processes labeled messages with attachments that accumulated before Pub/Sub notifications. Use when migrating to Cloud or after a watch gap. The validator offers an interactive prompt after preprocessor gate when backlog is detected; with `--no-interactive` it prints a manual `curl` command. Idempotent by `message_id`; re-run is safe. Existing queue docs (acked or unacked) are skipped before fetch to avoid duplicate GCS downloads. Evidence written to `docs/runbooks/evidence/`. See runbook "Backlog catch-up run" for count definitions and usage.

## Environment Variables

Required:
- `PROJECT_ID`: GCP Project ID
- `MAILBOX_USER`: Workspace mailbox being monitored (for this deployment: `daniel@strategicimplementation.us`)
- `GCS_BUCKET`: Cloud Storage bucket for attachments

Optional:
- `PORT`: Port to listen on (default: 8080)
- `AUTH_MODE`: `dwd_preferred` (try domain-wide delegation first, then user OAuth fallback), `dwd_required` (fail if DWD unavailable), or `user_oauth_only`
- `GMAIL_AUTH_METHOD`: Legacy; use `AUTH_MODE` instead. `user_oauth` maps to `user_oauth_only`.
- `GMAIL_OAUTH_CLIENT_ID_SECRET`, `GMAIL_OAUTH_CLIENT_SECRET_SECRET`, `GMAIL_OAUTH_REFRESH_TOKEN_SECRET`: Secret Manager secret names for Gmail OAuth (used when DWD is not used or as fallback)
- `GMAIL_PUBSUB_TOPIC`: Pub/Sub topic for Gmail watch (default `gmail-new-emails`)

### Auth Strategy Labels (important)

Use these labels consistently in code, docs, and runbooks:

- Runtime auth fallback:
  - Controlled by `AUTH_MODE`.
  - `dwd_required`: no runtime user OAuth fallback.
  - `dwd_preferred`: runtime DWD first, user OAuth fallback allowed.
- Setup fallback (validator/watch registration):
  - Setup tool may use OAuth-based watch registration in local/operator runs.
  - This is an operational setup path, not the runtime message-processing auth path.
- Break-glass posture:
  - Keep OAuth secrets in Secret Manager for rollback/recovery.
  - This does not mean runtime steady state is OAuth; steady state remains DWD with `AUTH_MODE=dwd_required`.

## Filter Configuration

The orchestrator provides GAS (Google Apps Script) parity filters to control which emails and attachments are processed.

### Gmail Label Filtering

- `GMAIL_LABEL_IDS`: Comma-separated list of Gmail label IDs to filter messages by
  - Example: `GMAIL_LABEL_IDS=Label_123456789,Label_987654321`
  - If not set, defaults to `INBOX`
  - To find label IDs: Use the Gmail API `users().labels().list()` or check Gmail UI settings
  - For the canonical `AkerKasten` label, look up its ID and set it here

### Attachment Filetype Filtering

- `ALLOWED_ATTACHMENT_EXTENSIONS`: Comma-separated list of allowed file extensions
  - Example: `ALLOWED_ATTACHMENT_EXTENSIONS=docx,csv,tsv,txt`
  - Default: `docx,csv` (matches GAS behavior)
  - Extensions are case-insensitive and should not include the dot

### Sender Filtering (Optional)

- `ALLOWED_SENDER_DOMAINS`: Comma-separated list of allowed sender domains/addresses
  - Example: `ALLOWED_SENDER_DOMAINS=healthplan.com,provider.org,specific@email.com`
  - If not set, all senders are allowed
  - Matching is case-insensitive substring match on the From header

### Single-Machine Routing

- `DEFAULT_MACHINE_ID`: Machine ID for single-machine deployments
  - Example: `DEFAULT_MACHINE_ID=clinic-001`
  - When set (non-empty), **DEFAULT_MACHINE_ID is authoritative**; X-MediLink-Clinic header is ignored (removes header spoof risk).
  - When empty: header wins, then Firestore routing.
  - Skips Firestore routing document lookup when set.
  - Required for small-scale deployments (<=3 users).
  - Future: multi-clinic header override can be reintroduced as explicit opt-in config mode.

**Best Practice**: For small-scale deployments, always set `DEFAULT_MACHINE_ID` to avoid unnecessary Firestore reads and simplify routing.

### Preprocessor (Metadata Validation)

- `PREPROCESSOR_MODE`: `shadow` (default) or `enforce`
  - **shadow**: Log reject + persist `ingest_errors`, still write queue item (no disruption).
  - **enforce**: Reject invalid candidates; skip queue write; best-effort GCS cleanup; persist `ingest_errors`.
- `FIRESTORE_INGEST_ERRORS_COLLECTION`: Collection for reject telemetry (default `ingest_errors`).

**Reject codes** (see `reject_codes.py`): Preprocessor: `missing_machine_id`, `missing_message_id`, `missing_received_at`, `empty_files_not_otp`, `invalid_files_item`, `unhandled_exception`. Processor-stage: `machine_id_resolution_failure`, `processor_unhandled_exception`.

**Promotion gate**: Promote shadow -> enforce when `unique_shadow_processed_count >= 50` and zero quality issues. Validator prints `PREPROCESSOR_GATE: pass` or `fail` with reason. Use `--promote-preprocessor-enforce` when gate passes. Requires interactive confirmation; `--validate-only` produces no mutation. Gate snapshot written to `docs/runbooks/evidence/`. See runbook for full promote/rollback steps.
Note: `dropped_without_repair_record_count` is computed from the shadow cohort (`preprocessor_reject_code` queue markers + `ingest_errors` correlation).

**Rollback**: `gcloud run services update <service> --project <project> --region <region> --update-env-vars PREPROCESSOR_MODE=shadow`


## Setup Script Coverage

### What this script can automate

`validate_and_complete_setup.py` auto-detects state and automatically creates/fixes when safe:
- gcloud auth/project context
- required GCP APIs
- orchestrator service account + baseline IAM roles
- Cloud Storage bucket
- Pub/Sub topics (primary + DLQ), push subscription dead-letter policy, and max delivery attempts
- Pub/Sub IAM for Gmail publisher and Pub/Sub service-agent DLQ publisher
- Cloud Run env vars for mailbox/OAuth wiring
- Gmail watch registration (when OAuth secrets are present)
- Cloud Scheduler refresh job when `ADMIN_SHARED_SECRET` is present

Pub/Sub reliability behavior:

- By default, the validator auto-detects and preserves the current subscription dead-letter policy (`deadLetterTopic`, `maxDeliveryAttempts`) when the subscription already exists.
- `--dlq-topic` and `--subscription-max-delivery-attempts` are explicit overrides when you intentionally want to change policy.

### What remains manual (with guided output)

The script now prints step-by-step beginner instructions when these are missing:
- Cloud Run deployment (image build/deploy)
- Firestore Native database initialization + composite index
- OAuth Secret Manager values (`gmail_oauth_client_id`, `gmail_oauth_client_secret`, `gmail_oauth_refresh_token`)
- `ADMIN_SHARED_SECRET` setup when needed for scheduler creation
