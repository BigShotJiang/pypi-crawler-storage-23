"""Omni Cortex MCP - Universal Memory System for Claude Code."""

__version__ = "1.20.0"
