from django.db import models

from ichec_django_core.models import TimesStampMixin

# https://spdx.org/licenses/


class License(TimesStampMixin):

    full_name = models.CharField(max_length=250)
    identifier = models.CharField(max_length=250)
    url = models.CharField(max_length=250)
    fsf_approved = models.BooleanField(default=False)
    osi_approved = models.BooleanField(default=False)
    vocab_url = models.CharField(max_length=250, null=True)
    full_text = models.TextField(null=True)
