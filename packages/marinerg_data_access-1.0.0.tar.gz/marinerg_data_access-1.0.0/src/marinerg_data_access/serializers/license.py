from rest_framework import serializers

from ..models import License


class LicenseSerializer(serializers.HyperlinkedModelSerializer):

    class Meta:
        model = License
        fields = (
            "id",
            "url",
            "full_name",
            "identifier",
            "url",
            "fsf_approved",
            "osi_approved",
            "vocab_url",
            "full_text",
        )
