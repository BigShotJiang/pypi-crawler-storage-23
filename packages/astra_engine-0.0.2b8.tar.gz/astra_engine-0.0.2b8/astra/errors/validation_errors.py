# -----------------------------------------------------------
# Astra - WhatsApp Client Framework
# Licensed under the Apache License 2.0.
# -----------------------------------------------------------

"""Validation errors — imported from main exceptions module for compat."""

from .exceptions import InvalidInputError, InvalidJIDError, InvalidPhoneError

__all__ = ["InvalidInputError", "InvalidJIDError", "InvalidPhoneError"]
