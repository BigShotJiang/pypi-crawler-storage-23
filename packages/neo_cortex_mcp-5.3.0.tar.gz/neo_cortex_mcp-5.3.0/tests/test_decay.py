"""Tests for Ebbinghaus decay model."""

import pytest

from neo_cortex.decay import ebbinghaus_weight, reinforce


class TestEbbinghausWeight:
    def test_fresh_memory_high_weight(self):
        """Just-created memory → weight ~1.0."""
        w = ebbinghaus_weight(oldness_days=0, stability=1.0)
        assert w > 0.99

    def test_old_memory_low_weight(self):
        """Old memory + low stability → low weight."""
        w = ebbinghaus_weight(oldness_days=30, stability=1.0)
        assert w < 0.5

    def test_stable_memory_resists_decay(self):
        """High stability → decays more slowly."""
        w_unstable = ebbinghaus_weight(oldness_days=3, stability=1.0)
        w_stable = ebbinghaus_weight(oldness_days=3, stability=10.0)
        assert w_stable > w_unstable

    def test_weight_never_below_floor(self):
        """Minimum weight is 0.05."""
        w = ebbinghaus_weight(oldness_days=365, stability=0.1)
        assert w >= 0.05

    def test_weight_never_above_one(self):
        w = ebbinghaus_weight(oldness_days=0, stability=100.0)
        assert w <= 1.0

    def test_zero_stability_returns_floor(self):
        w = ebbinghaus_weight(oldness_days=10, stability=0)
        assert w == 0.05

    def test_negative_stability_returns_floor(self):
        w = ebbinghaus_weight(oldness_days=10, stability=-1.0)
        assert w == 0.05


class TestReinforce:
    def test_basic_reinforcement(self):
        assert reinforce(stability=2.0) == 3.0

    def test_custom_increment(self):
        assert reinforce(stability=2.0, increment=0.5) == 2.5
