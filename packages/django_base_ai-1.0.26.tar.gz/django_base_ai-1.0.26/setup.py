#!/usr/bin/env python
# 以 pyproject.toml 为单一数据源，此处仅保留 setuptools 构建所需的最小配置
from setuptools import find_packages, setup

setup(
    packages=find_packages(exclude=["DjangoBaseAi", "DjangoBaseAi.*"]),
    include_package_data=True,
)
