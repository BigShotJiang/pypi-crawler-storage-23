"""IM 问题分组 IMChatQuestionGroupViewSet 接口单元测试。"""

import pytest
from rest_framework import status

from tests.assertions import assert_unauthorized

pytestmark = [pytest.mark.django_db]

API = "/base/api/system/im_chat_question_group"


def test_im_chat_question_group_list_requires_auth(api_client):
    """GET /im_chat_question_group/ 未认证返回 401。"""
    response = api_client.get(API + "/")
    assert_unauthorized(response)


def test_im_chat_question_group_list_ok(authenticated_client):
    """GET /im_chat_question_group/ 已认证返回 200。"""
    response = authenticated_client.get(API + "/")
    assert response.status_code == status.HTTP_200_OK
    assert response.json().get("code") == 2000
