# 测试说明

- 根目录下为通用/工具测试：`test_import.py`、`test_ai_base.py`、`test_ai_settings.py`、`test_ai_clients.py`。
- **按 view 分目录**：每个系统 view 对应一个文件夹，内含该 view 的 API 单元测试，便于区分与维护。

## 目录与 view 对应关系

| 目录 | 对应 View / 接口 |
|------|------------------|
| `login/` | 登录、登出、验证码、Token 刷新、init/dictionary、init/settings |
| `menu/` | MenuViewSet |
| `menu_button/` | MenuButtonViewSet |
| `role/` | RoleViewSet |
| `dept/` | DeptViewSet、dept_lazy_tree |
| `user/` | UserViewSet |
| `dictionary/` | DictionaryViewSet |
| `operation_log/` | OperationLogViewSet |
| `area/` | AreaViewSet |
| `folder/` | FolderViewSet |
| `file_list/` | FileViewSet |
| `api_white_list/` | ApiWhiteListViewSet |
| `system_config/` | SystemConfigViewSet |
| `message_center/` | MessageCenterViewSet |
| `message_center_target_user/` | MessageCenterTargetUserViewSet |
| `frequently_used_contacts/` | FrequentlyUsedContactsViewSet |
| `datav/` | DataVViewSet |
| `task/` | BaseTaskViewSet |
| `task_run_history/` | TaskRunHistoryViewSet |
| `apps/` | AppsViewSet |
| `tags/` | TagsViewSet |
| `collaborator/` | CollaboratorViewSet |
| `my_superiors/` | MySuperiorsViewSet |
| `ai_desk_app_manage/` | AIDeskAppManageViewSet |
| `im_session/` | IMSessionViewSet |
| `im_chat_to_user/` | IMChatToUserViewSet |
| `im_chat_question_group/` | IMChatQuestionGroupViewSet |
| `im_chat_question/` | IMChatQuestionViewSet |
| `im_chat_to_group/` | IMChatToGroupViewSet |
| `im_chat_to_group_message/` | IMChatToGroupMessageViewSet |
| `im_chat_qa/` | IMChatQAViewSet |
| `im_chat_record_form/` | IMChatRecordFormViewSet |
| `login_log/` | LoginLogViewSet |
| `base_analyze/` | AnalyzeView |
| `ai_chat_session/` | AIChatSessionViewSet |
| `holiday/` | HolidayView |

## 运行方式

**一键运行全部测试**（推荐）：

```bash
./tests/run_all_tests.sh
```

或传入 pytest 参数，例如：

```bash
./tests/run_all_tests.sh -x                    # 首次失败即停
./tests/run_all_tests.sh tests/login/ -v       # 只测 login
./tests/run_all_tests.sh --tb=long             # 详细 traceback
```

也可在项目根目录直接执行 pytest：

```bash
pytest                          # 运行全部
pytest tests/login/ -v          # 仅登录相关
pytest tests/menu/ tests/role/ -v  # 指定多个目录
```

## Fixture（conftest.py）

- `api_client`：未认证的 `APIClient`
- `test_user`：测试用户（username=test_api_user, password=TestPassword123）
- `authenticated_client`：已 `force_authenticate(user=test_user)` 的 client
- `API_BASE`：`/base/api/system`（常量，按需引用）
