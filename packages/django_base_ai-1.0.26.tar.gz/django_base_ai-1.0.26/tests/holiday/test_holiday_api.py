"""节假日 HolidayView 接口单元测试。"""

import pytest
from rest_framework import status


pytestmark = [pytest.mark.django_db]

API = "/base/api/system/holiday/"


def test_holiday_get_200(api_client):
    """GET holiday/ 无需认证，返回 200 且 code=2000（依赖 holidays 模块与数据正常）。"""
    response = api_client.get(API)
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert data.get("code") == 2000, data
    assert "data" in data
