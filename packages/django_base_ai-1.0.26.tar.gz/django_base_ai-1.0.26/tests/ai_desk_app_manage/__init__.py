# ai_desk_app_manage 相关 API 单元测试
