"""部门 DeptViewSet 及 dept_lazy_tree 接口单元测试。"""

import pytest
from rest_framework import status

from tests.assertions import assert_unauthorized

pytestmark = [pytest.mark.django_db]

API = "/base/api/system/dept"
DEPT_LAZY_TREE = "/base/api/system/dept_lazy_tree/"


def test_dept_list_requires_auth(api_client):
    """GET /dept/ 未认证返回 401。"""
    response = api_client.get(API + "/")
    assert_unauthorized(response)


def test_dept_list_ok(authenticated_client):
    """GET /dept/ 已认证返回 200。"""
    response = authenticated_client.get(API + "/")
    assert response.status_code == status.HTTP_200_OK
    assert response.json().get("code") == 2000


def test_dept_lazy_tree_requires_auth(api_client):
    """GET dept_lazy_tree/ 未认证返回 401。"""
    response = api_client.get(DEPT_LAZY_TREE)
    assert_unauthorized(response)


def test_dept_lazy_tree_ok(authenticated_client):
    """GET dept_lazy_tree/ 已认证返回 200。"""
    response = authenticated_client.get(DEPT_LAZY_TREE)
    assert response.status_code == status.HTTP_200_OK
