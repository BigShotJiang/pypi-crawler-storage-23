"""消息中心目标用户 MessageCenterTargetUserViewSet 接口单元测试。"""

import pytest
from rest_framework import status

from tests.assertions import assert_unauthorized

pytestmark = [pytest.mark.django_db]

API = "/base/api/system/message_center_target_user"


def test_message_center_target_user_list_requires_auth(api_client):
    """GET /message_center_target_user/ 未认证返回 401。"""
    response = api_client.get(API + "/")
    assert_unauthorized(response)


def test_message_center_target_user_list_ok(authenticated_client):
    """GET /message_center_target_user/ 已认证返回 200。"""
    response = authenticated_client.get(API + "/")
    assert response.status_code == status.HTTP_200_OK
    assert response.json().get("code") == 2000
