"""菜单按钮 MenuButtonViewSet 接口单元测试。"""

import pytest
from rest_framework import status


pytestmark = [pytest.mark.django_db]

API = "/base/api/system/menu_button"


def test_menu_button_list_ok(api_client):
    """GET /menu_button/ 可能无需认证，检查可访问。"""
    response = api_client.get(API + "/")
    assert response.status_code in (status.HTTP_200_OK, status.HTTP_401_UNAUTHORIZED)


def test_menu_button_list_authenticated_ok(authenticated_client):
    """GET /menu_button/ 已认证返回 200。"""
    response = authenticated_client.get(API + "/")
    assert response.status_code == status.HTTP_200_OK
    assert response.json().get("code") == 2000
