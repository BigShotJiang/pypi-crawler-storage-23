# DjangoBaseAi 测试包（Rules/python.mdc: pytest）
