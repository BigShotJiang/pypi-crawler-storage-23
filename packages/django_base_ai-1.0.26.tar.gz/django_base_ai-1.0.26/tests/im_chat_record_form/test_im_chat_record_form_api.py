"""IM 聊天记录表单 IMChatRecordFormViewSet 接口单元测试。"""

import pytest
from rest_framework import status

from tests.assertions import assert_unauthorized

pytestmark = [pytest.mark.django_db]

API = "/base/api/system/im_chat_record_form"


def test_im_chat_record_form_list_requires_auth(api_client):
    """GET /im_chat_record_form/ 未认证返回 401。"""
    response = api_client.get(API + "/")
    assert_unauthorized(response)


def test_im_chat_record_form_list_ok(authenticated_client):
    """GET /im_chat_record_form/ 已认证返回 200。"""
    response = authenticated_client.get(API + "/")
    assert response.status_code == status.HTTP_200_OK
    assert response.json().get("code") == 2000
