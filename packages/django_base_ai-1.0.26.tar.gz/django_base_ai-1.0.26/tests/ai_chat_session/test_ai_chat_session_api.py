"""AI 会话 AIChatSessionViewSet 接口单元测试。"""

import pytest
from rest_framework import status

from tests.assertions import assert_unauthorized

pytestmark = [pytest.mark.django_db]

API = "/base/api/system/ai_chat_session"


def test_ai_chat_session_list_requires_auth(api_client):
    """GET /ai_chat_session/ 未认证返回 401。"""
    response = api_client.get(API + "/")
    assert_unauthorized(response)


def test_ai_chat_session_list_ok(authenticated_client):
    """GET /ai_chat_session/ 已认证返回 200。"""
    response = authenticated_client.get(API + "/")
    assert response.status_code == status.HTTP_200_OK
    assert response.json().get("code") == 2000


def test_ai_chat_session_chat_action_requires_message(authenticated_client):
    """POST /ai_chat_session/chat/ 无 message 返回 400。"""
    response = authenticated_client.post(API + "/chat/", {}, format="json")
    assert response.status_code == status.HTTP_400_BAD_REQUEST
