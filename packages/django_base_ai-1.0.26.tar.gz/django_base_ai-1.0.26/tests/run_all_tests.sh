#!/usr/bin/env bash
# 一键运行全部测试（与 pyproject.toml 中 pytest 配置一致）
# 若存在项目根目录下 .venv，则自动激活后执行 pytest
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_ROOT"

# 激活 .venv（存在则 source）
if [ -d ".venv" ]; then
  if [ -f ".venv/bin/activate" ]; then
    echo ">>> 激活虚拟环境: .venv"
    # shellcheck source=../.venv/bin/activate
    source .venv/bin/activate
  elif [ -f ".venv/Scripts/activate" ]; then
    echo ">>> 激活虚拟环境: .venv (Windows)"
    # shellcheck source=../.venv/Scripts/activate
    source .venv/Scripts/activate
  fi
fi

export DJANGO_SETTINGS_MODULE="${DJANGO_SETTINGS_MODULE:-DjangoBaseAi.settings}"
export PYTHONPATH="${PYTHONPATH:-.}"

echo ">>> 项目根目录: $PROJECT_ROOT"
echo ">>> Python: $(command -v python)"
echo ">>> DJANGO_SETTINGS_MODULE: $DJANGO_SETTINGS_MODULE"
echo ">>> 运行全部测试: pytest tests/ -v --tb=short"
echo ">>> 提示: 若出现表不存在，请先执行: python manage.py migrate"
echo ""

python -m pytest tests/ -v --tb=short "$@"
