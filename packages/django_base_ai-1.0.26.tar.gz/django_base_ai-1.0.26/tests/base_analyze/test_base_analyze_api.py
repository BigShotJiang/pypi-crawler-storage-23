"""数据分析 AnalyzeView 接口单元测试。"""

import pytest
from rest_framework import status


pytestmark = [pytest.mark.django_db]

API = "/base/api/system/base_analyze"


def test_base_analyze_list_or_actions_ok(api_client):
    """GET /base_analyze/ 可能 AllowAny，检查可访问。"""
    response = api_client.get(API + "/")
    assert response.status_code in (status.HTTP_200_OK, status.HTTP_401_UNAUTHORIZED, status.HTTP_404_NOT_FOUND)


def test_base_analyze_with_auth_ok(authenticated_client):
    """GET /base_analyze/ 已认证返回 200 或 404（无 action 时）。"""
    response = authenticated_client.get(API + "/")
    assert response.status_code in (status.HTTP_200_OK, status.HTTP_404_NOT_FOUND)
