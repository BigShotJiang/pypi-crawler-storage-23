"""
pytest 配置与 fixture（Rules/python.mdc: 使用 pytest 做测试）。
"""

import os
import sys

import django

# 确保项目根在 path 中，并配置 Django
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "DjangoBaseAi.settings")
django.setup()


import pytest
from rest_framework.test import APIClient

from django_base_ai.system.models import Users


# API 根路径（与 DjangoBaseAi/urls.py 中 path 一致）
API_BASE = "/base/api/system"


@pytest.fixture
def api_client():
    """未认证的 DRF APIClient。"""
    return APIClient()


@pytest.fixture
def test_user(db):
    """测试用用户，用于需要登录的接口。"""
    user = Users(
        username="test_api_user",
        name="测试用户",
        is_staff=False,
        is_active=True,
    )
    user.set_password("TestPassword123")
    user.save()
    return user


@pytest.fixture
def authenticated_client(api_client, test_user):
    """已认证的 APIClient（force_authenticate）。"""
    api_client.force_authenticate(user=test_user)
    return api_client
