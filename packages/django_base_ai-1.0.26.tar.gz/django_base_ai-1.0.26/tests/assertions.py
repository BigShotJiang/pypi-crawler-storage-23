# -*- coding: utf-8 -*-
"""测试用断言辅助。"""

from rest_framework import status


def assert_unauthorized(response):
    """
    断言未认证请求被拒绝：HTTP 401、404 或 HTTP 200 且 body 中 code != 2000（与项目统一错误响应一致）。
    """
    if response.status_code == status.HTTP_401_UNAUTHORIZED:
        return
    if response.status_code == status.HTTP_404_NOT_FOUND:
        return
    if response.status_code == 200:
        try:
            data = response.json()
            if isinstance(data, dict) and data.get("code") != 2000:
                return
        except Exception:
            pass
    raise AssertionError(
        f"Expected 401, 404 or 200 with code!=2000, got status={response.status_code} body={getattr(response, 'content', b'')[:300]!r}"
    )
