"""我的上级 MySuperiorsViewSet 接口单元测试。"""

import pytest
from rest_framework import status

from tests.assertions import assert_unauthorized

pytestmark = [pytest.mark.django_db]

API = "/base/api/system/my_superiors"


def test_my_superiors_list_requires_auth(api_client):
    """GET /my_superiors/ 未认证返回 401。"""
    response = api_client.get(API + "/")
    assert_unauthorized(response)


def test_my_superiors_list_ok(authenticated_client):
    """GET /my_superiors/ 已认证返回 200。"""
    response = authenticated_client.get(API + "/")
    assert response.status_code == status.HTTP_200_OK
    assert response.json().get("code") == 2000
