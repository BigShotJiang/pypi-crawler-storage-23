"""
django_base_ai 包入口。

版本号由 setuptools-scm 在打包时注入，未安装时回退为 0.0.1。
"""

from __future__ import annotations

import pymysql

pymysql.install_as_MySQLdb()  # 提供与 mysqlclient 兼容的 API

__version__: str
try:
    from importlib.metadata import version as _pkg_version

    __version__ = _pkg_version("django_base_ai")
except Exception:  # noqa: S110
    __version__ = "0.0.1"
