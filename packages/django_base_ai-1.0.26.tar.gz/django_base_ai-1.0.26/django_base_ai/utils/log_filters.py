# -*- coding: UTF-8 -*-
"""
仅含 logging 与 contextvars，供 LOGGING 配置在 Django 应用未完全加载时即可导入。
Trace-Id 由 middleware 写入 trace_id_ctx，本 Filter 注入到每条 LogRecord。
"""
import logging
from contextvars import ContextVar

trace_id_ctx: ContextVar[str] = ContextVar("trace_id", default="")


class TraceIdFilter(logging.Filter):
    """为每条 LogRecord 注入 trace_id，便于错误日志排查时按请求串联。"""

    def filter(self, record: logging.LogRecord) -> bool:
        record.trace_id = trace_id_ctx.get() or "-"
        return True
