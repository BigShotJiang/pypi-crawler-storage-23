#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：django_base_ai
@File    ：__init__.py
@Author  ：congxing.wang
@Date    ：2026/02/25
@Desc    ：工具包初始化
"""
