#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：django_base_ai
@File    ：settings_conf.py
@Desc    ：从 conf/ Django settings 读取 AI 相关配置（api_key 等）
"""

import logging

from django.conf import settings

logger = logging.getLogger(__name__)


def _get_setting(key: str, default: str = "") -> str:
    return (getattr(settings, key, None) or default) or ""


def get_ai_config(provider: str) -> dict:
    """
    从 conf 注入的 Django settings 中读取指定供应商的配置。
    约定：在 conf/env.py、conf/pro.py 等中设置 AI_<PROVIDER>_API_KEY 等。
    :param provider: deepseek / tencent / openai / openai_custom
    :return: dict 含 api_key, base_url(可选), default_model(可选)
    """
    prefix = f"AI_{provider.upper()}_"
    api_key = _get_setting(f"{prefix}API_KEY")
    base_url = _get_setting(f"{prefix}BASE_URL")
    default_model = _get_setting(f"{prefix}DEFAULT_MODEL")
    logger.debug("get_ai_config provider=%s base_url=%s", provider, base_url or "(default)")
    return {
        "api_key": api_key,
        "base_url": base_url or None,
        "default_model": default_model or None,
    }
