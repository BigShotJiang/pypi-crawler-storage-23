#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：django_base_ai
@File    ：tencent.py
@Desc    ：腾讯云混元大模型调用封装（OpenAI 兼容接口）
"""

from django_base_ai.utils.ai.openai_compat import OpenAICompatClient

# 腾讯混元 OpenAI 兼容端点
TENCENT_HUNYUAN_BASE_URL = "https://api.hunyuan.cloud.tencent.com/v1"

# 常用模型
TENCENT_MODELS = ("hunyuan-lite", "hunyuan-standard", "hunyuan-pro")


class TencentCloudAIClient(OpenAICompatClient):
    """
    腾讯云混元大模型客户端。
    使用腾讯云提供的 OpenAI 兼容接口，需在控制台申请 API Key（sk- 开头）。
    """

    def __init__(
        self,
        api_key: str,
        default_model: str = "hunyuan-lite",
        timeout: int = 60,
    ):
        super().__init__(
            api_key=api_key,
            base_url=TENCENT_HUNYUAN_BASE_URL,
            default_model=default_model,
            timeout=timeout,
        )
