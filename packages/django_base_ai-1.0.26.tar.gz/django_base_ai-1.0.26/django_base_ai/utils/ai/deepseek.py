#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：django_base_ai
@File    ：deepseek.py
@Desc    ：DeepSeek 大模型调用工具类（OpenAI 兼容接口）
"""

from django_base_ai.utils.ai.openai_compat import OpenAICompatClient

# DeepSeek 官方 API 端点
DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1"

# 常用模型（纯文本 + 视觉）
# deepseek-vl-7b-chat 为视觉语言模型，支持图像输入，需自建或第三方推理；官方 API 若开放 VL 也可用同名
DEEPSEEK_MODELS = (
    "deepseek-chat",
    "deepseek-reasoner",
    "deepseek-coder",
    "deepseek-vl-7b-chat",
)


class DeepSeekClient(OpenAICompatClient):
    """
    DeepSeek 官方大模型客户端。
    使用 OpenAI 兼容接口，需在 DeepSeek 开放平台申请 API Key。
    视觉模型 deepseek-vl-7b-chat：可传 default_model 使用；若官方未开放，需自建/第三方
    兼容接口并设置 base_url，请求体传 model 即可。
    """

    def __init__(
        self,
        api_key: str,
        default_model: str = "deepseek-chat",
        timeout: int = 60,
    ):
        super().__init__(
            api_key=api_key,
            base_url=DEEPSEEK_BASE_URL,
            default_model=default_model,
            timeout=timeout,
        )
