#!/usr/bin/env python
"""
@Project ：django_base_ai
@File    ：scan_qr_cv.py
@Author  ：congxing.wang
@Date    ：2026/02/25
@Desc    ：二维码与验证码识别（OpenCV）
"""


class ScanQR:
    def __init__(self):
        pass

    def info(self, file_path):
        import cv2

        detector = cv2.wechat_qrcode_WeChatQRCode(
            "./opencv_3rdparty/detect.prototxt",
            "./opencv_3rdparty/detect.caffemodel",
            "./opencv_3rdparty/sr.prototxt",
            "./opencv_3rdparty/sr.caffemodel",
        )
        img = cv2.imread(file_path)
        res, points = detector.detectAndDecode(img)
        return res, points


if __name__ == "__main__":
    scan_qr = ScanQR()
    print(scan_qr.info("./opencv_3rdparty/img.jpg"))
