#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
一键生成 RSA 私钥和公钥

用法（在项目根目录执行）:
    python django_base_ai/utils/keys/generate_rsa_keys.py

或进入 keys 目录后:
    python generate_rsa_keys.py

生成文件（与 rsa_util.py 使用的路径一致）:
    - company_rsa_private_key.pem  私钥
    - company_rsa_public_key.pem   公钥

若密钥文件已存在，会先备份为 .bak_YYYYMMDD_HHMMSS 再生成新密钥，不直接覆盖。
"""

import os
import shutil
import subprocess
import sys
from datetime import datetime

KEYS_DIR = os.path.dirname(os.path.abspath(__file__))
PRIVATE_KEY_PATH = os.path.join(KEYS_DIR, "company_rsa_private_key.pem")
PUBLIC_KEY_PATH = os.path.join(KEYS_DIR, "company_rsa_public_key.pem")
KEY_SIZE = 2048


def generate_rsa_keys():
    """使用 OpenSSL 生成 RSA 密钥对（PEM 格式，与 rsa_util 兼容）。"""
    try:
        # 生成私钥
        subprocess.run(
            ["openssl", "genrsa", "-out", PRIVATE_KEY_PATH, str(KEY_SIZE)],
            check=True,
            capture_output=True,
            text=True,
        )
        # 从私钥导出公钥
        subprocess.run(
            [
                "openssl",
                "rsa",
                "-in",
                PRIVATE_KEY_PATH,
                "-pubout",
                "-out",
                PUBLIC_KEY_PATH,
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        return True
    except FileNotFoundError:
        print("错误: 未找到 openssl，请先安装 OpenSSL（macOS/Linux 通常已预装）", file=sys.stderr)
        return False
    except subprocess.CalledProcessError as e:
        print(f"错误: OpenSSL 执行失败: {e.stderr or e}", file=sys.stderr)
        return False


def backup_existing_keys():
    """若密钥文件已存在，先备份再生成新的。备份文件名带时间戳。"""
    suffix = datetime.now().strftime("%Y%m%d_%H%M%S")
    backed = []
    if os.path.isfile(PRIVATE_KEY_PATH):
        backup_path = f"{PRIVATE_KEY_PATH}.bak_{suffix}"
        shutil.copy2(PRIVATE_KEY_PATH, backup_path)
        backed.append(("私钥", backup_path))
    if os.path.isfile(PUBLIC_KEY_PATH):
        backup_path = f"{PUBLIC_KEY_PATH}.bak_{suffix}"
        shutil.copy2(PUBLIC_KEY_PATH, backup_path)
        backed.append(("公钥", backup_path))
    return backed


def main():
    backed = backup_existing_keys()
    if backed:
        print("已存在密钥文件，已备份：")
        for name, path in backed:
            print(f"  {name}: {path}")
        print("提示：使用旧密钥加密的历史数据需用备份的私钥解密。")
    print("正在生成新的 RSA 密钥对 ...")
    if not generate_rsa_keys():
        sys.exit(1)
    print("生成成功！")
    print(f"  私钥: {PRIVATE_KEY_PATH}")
    print(f"  公钥: {PUBLIC_KEY_PATH}")
    print("请妥善保管私钥，勿提交到版本库。")


if __name__ == "__main__":
    main()
