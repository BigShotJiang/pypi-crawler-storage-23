#!/usr/bin/env python
"""
@Project ：django_base_ai
@File    ：datetime_range_generator.py
@Author  ：congxing.wang
@Date    ：2026/02/25
@Desc    ：日期范围与月份列表生成
"""

from datetime import datetime, timedelta


def get_date_range(start_month=None, end_month=None):
    """
    获取日期范围及月份列表（不处理异常，调用方需自行捕获 ValueError）

    参数:
        start_month (str): 起始月份，格式为'YYYY-MM'（如 '2025-01'）
        end_month (str): 结束月份，格式为'YYYY-MM'（如 '2025-08'）

    返回:
        tuple: (start_date, end_date, months, start_month, end_month)
            - start_date: datetime 起始日期（精确到天）
            - end_date: datetime 结束日期（精确到天）
            - months: list[str] 月份列表（如 ['2025-01', '2025-02', ...]）
            - start_month: str 起始月份（如 '2025-01'）
            - end_month: str 结束月份（如 '2025-08'）

    异常:
        ValueError: 如果传入的 start_month 或 end_month 格式不正确

    示例:
        start_date, end_date, months, start_month, end_month = get_date_range('2025-01', '2025-08')
        或
        start_date, end_date, months, start_month, end_month = get_date_range()  # 默认最近12个月
    """
    if start_month and end_month:
        # 解析日期
        start_date = datetime.strptime(start_month, "%Y-%m")
        end_date = datetime.strptime(end_month, "%Y-%m") + timedelta(days=31)  # 确保包含整个月
        end_date = end_date.replace(day=1) - timedelta(days=1)  # 调整为月末
    else:
        # 默认最近12个月
        end_date = datetime.now()
        start_date = end_date - timedelta(days=365)
        start_month = start_date.strftime("%Y-%m")
        end_month = end_date.strftime("%Y-%m")

    # 生成月份范围
    months = []
    current = start_date
    while current <= end_date:
        months.append(current.strftime("%Y-%m"))
        # 下个月
        if current.month == 12:
            current = current.replace(year=current.year + 1, month=1)
        else:
            current = current.replace(month=current.month + 1)

    return start_date, end_date, months, start_month, end_month
