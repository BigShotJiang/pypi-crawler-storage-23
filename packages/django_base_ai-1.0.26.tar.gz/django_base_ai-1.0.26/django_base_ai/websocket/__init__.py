#!/usr/bin/env python
"""
@Project ：django_base_ai
@File    ：__init__.py
@Author  ：congxing.wang
@Date    ：2026/02/25
@Desc    ：WebSocket 包初始化
"""
