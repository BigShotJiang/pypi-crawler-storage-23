#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import logging

from django.urls import path

from django_base_ai.websocket.websocket_config import BaseWebSocketCenter

logger = logging.getLogger(__name__)

websocket_urlpatterns = [path("ws/base/<str:service_uid>/<int:nid>/", BaseWebSocketCenter.as_asgi())]
