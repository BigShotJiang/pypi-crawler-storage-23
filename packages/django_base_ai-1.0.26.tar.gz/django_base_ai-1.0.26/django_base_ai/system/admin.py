#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""system 应用 Django Admin 入口，可按需在此注册 ModelAdmin。"""
import logging

logger = logging.getLogger(__name__)

# Register your models here.
