#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""system 应用配置：Django 启动时 ready() 会加载本应用并执行 signals 等。"""
import logging

from django.apps import AppConfig

logger = logging.getLogger(__name__)


class SystemConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_base_ai.system"

    def ready(self):
        """应用就绪时调用，用于注册信号等。"""
        logger.info("正在初始化 django_base_ai.system 应用")
        logger.info("django_base_ai.system 应用初始化完成")
