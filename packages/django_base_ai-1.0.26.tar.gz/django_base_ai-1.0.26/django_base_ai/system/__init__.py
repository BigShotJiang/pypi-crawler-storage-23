#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
system 应用：Django 通用底座（主推 AI）的核心应用，包含主推 AI 能力（对话、PPT、文本润色）、
底座能力（认证、RBAC、组织、配置、日志、文件、消息、任务）及其他扩展（IM、数据分析等）。
详见项目 help/ARCHITECTURE.md。
"""
