#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
system 应用 URL 配置：登录/登出/Token、初始化接口、各 ViewSet 路由。
模块加载时执行 dispatch 初始化系统配置与字典（仅首次）。
"""
import logging

from django.urls import path
from rest_framework import routers

from django_base_ai import dispatch

logger = logging.getLogger(__name__)

# ---------- 模块加载时初始化系统配置与字典 ----------
from django_base_ai.system.views.ai_desk_app_manage import AIDeskAppManageViewSet
from django_base_ai.system.views.ai_chat import AIChatSessionViewSet
from django_base_ai.system.views.api_white_list import ApiWhiteListViewSet
from django_base_ai.system.views.apps import AppsViewSet
from django_base_ai.system.views.area import AreaViewSet
from django_base_ai.system.views.base_analyze import AnalyzeView
from django_base_ai.system.views.base_task import BaseTaskViewSet
from django_base_ai.system.views.collaborator import CollaboratorViewSet
from django_base_ai.system.views.datav import DataVViewSet
from django_base_ai.system.views.dept import DeptViewSet
from django_base_ai.system.views.dictionary import DictionaryViewSet, InitDictionaryViewSet
from django_base_ai.system.views.file_list import FileViewSet
from django_base_ai.system.views.folder_list import FolderViewSet
from django_base_ai.system.views.frequently_used_contacts import FrequentlyUsedContactsViewSet
from django_base_ai.system.views.holiday import HolidayView
from django_base_ai.system.views.im_chat_qa import IMChatQAViewSet
from django_base_ai.system.views.im_chat_question import IMChatQuestionViewSet
from django_base_ai.system.views.im_chat_question_group import IMChatQuestionGroupViewSet
from django_base_ai.system.views.im_chat_record_form import IMChatRecordFormViewSet
from django_base_ai.system.views.im_chat_to_group import IMChatToGroupViewSet
from django_base_ai.system.views.im_chat_to_group_message import IMChatToGroupMessageViewSet
from django_base_ai.system.views.im_chat_to_user import IMChatToUserViewSet
from django_base_ai.system.views.im_session import IMSessionViewSet
from django_base_ai.system.views.login import (
    CaptchaView,
    CustomTokenRefreshView,
    LoginView,
    LogoutView,
)
from django_base_ai.system.views.login_log import LoginLogViewSet
from django_base_ai.system.views.logins.custome_login import CustomeLoginJWTAPIView
from django_base_ai.system.views.logins.login import LoginJWTAPIView
from django_base_ai.system.views.menu import MenuViewSet
from django_base_ai.system.views.menu_button import MenuButtonViewSet
from django_base_ai.system.views.message_center import MessageCenterViewSet, websocket_view
from django_base_ai.system.views.message_center_target_user import MessageCenterTargetUserViewSet
from django_base_ai.system.views.my_superiors import MySuperiorsViewSet
from django_base_ai.system.views.operation_log import OperationLogViewSet
from django_base_ai.system.views.role import RoleViewSet
from django_base_ai.system.views.system_config import InitSettingsViewSet, SystemConfigViewSet
from django_base_ai.system.views.tags import TagsViewSet
from django_base_ai.system.views.task_run_history import TaskRunHistoryViewSet
from django_base_ai.system.views.user import UserViewSet

logger.info("开始初始化系统配置与字典")
dispatch.init_system_config()
dispatch.init_dictionary()
logger.info("系统配置与字典初始化完成")

# ---------- ViewSet 路由注册 ----------
# 底座核心：认证、RBAC、组织、配置、日志、文件、消息、任务等（见 help/ARCHITECTURE.md）
# 可选扩展：AI 对话、IM、数据分析等（ai_chat_session、im_*、base_analyze、ai_desk_app_manage）
system_url = routers.SimpleRouter()
# --- 底座：RBAC 与组织 ---
system_url.register(r"menu", MenuViewSet)
system_url.register(r"menu_button", MenuButtonViewSet)
system_url.register(r"role", RoleViewSet)
system_url.register(r"dept", DeptViewSet)
system_url.register(r"user", UserViewSet)
system_url.register(r"operation_log", OperationLogViewSet)
system_url.register(r"dictionary", DictionaryViewSet)
system_url.register(r"area", AreaViewSet)
system_url.register(r"folder", FolderViewSet)
system_url.register(r"file", FileViewSet)
system_url.register(r"api_white_list", ApiWhiteListViewSet)
system_url.register(r"system_config", SystemConfigViewSet)
system_url.register(r"message_center", MessageCenterViewSet)
system_url.register(r"message_center_target_user", MessageCenterTargetUserViewSet)
system_url.register(r"frequently_used_contacts", FrequentlyUsedContactsViewSet)
system_url.register(r"datav", DataVViewSet)
system_url.register(r"task", BaseTaskViewSet)
system_url.register(r"task_run_history", TaskRunHistoryViewSet)
system_url.register(r"apps", AppsViewSet)
system_url.register(r"tags", TagsViewSet)
system_url.register(r"collaborator", CollaboratorViewSet)
system_url.register(r"my_superiors", MySuperiorsViewSet)
# --- 可选扩展：AI 工作台、IM ---
system_url.register(r"ai_desk_app_manage", AIDeskAppManageViewSet)
system_url.register(r"im_session", IMSessionViewSet)
system_url.register(r"im_chat_to_user", IMChatToUserViewSet)
system_url.register(r"im_chat_question_group", IMChatQuestionGroupViewSet)
system_url.register(r"im_chat_question", IMChatQuestionViewSet)
system_url.register(r"im_chat_to_group", IMChatToGroupViewSet)
system_url.register(r"im_chat_to_group_message", IMChatToGroupMessageViewSet)
system_url.register(r"im_chat_qa", IMChatQAViewSet)
system_url.register(r"im_chat_record_form", IMChatRecordFormViewSet)
system_url.register(r"login_log", LoginLogViewSet, basename="login_log")
# --- 可选扩展：数据分析、AI ---
system_url.register(r"base_analyze", AnalyzeView, basename="base_analyze")
system_url.register(r"ai_chat_session", AIChatSessionViewSet)

# ---------- 非 REST 风格路径（登录、登出、初始化、WebSocket 等）----------
urlpatterns = [
    path("login/", LoginView.as_view(), name="token_obtain_pair"),
    path("sign_login/", LoginJWTAPIView.as_view()),  # 单点登录-第三方集成
    path("custome_login/", CustomeLoginJWTAPIView.as_view()),  # 自定义登录
    path("logout/", LogoutView.as_view(), name="logout"),
    path("token/refresh/", CustomTokenRefreshView.as_view(), name="token_refresh"),
    path("captcha/", CaptchaView.as_view()),
    path("init/dictionary/", InitDictionaryViewSet.as_view()),
    path("init/settings/", InitSettingsViewSet.as_view()),
    path("system_config/save_content/", SystemConfigViewSet.as_view({"put": "save_content"})),
    path("system_config/get_association_table/", SystemConfigViewSet.as_view({"get": "get_association_table"})),
    path("system_config/get_table_data/<int:pk>/", SystemConfigViewSet.as_view({"get": "get_table_data"})),
    path("system_config/get_relation_info/", SystemConfigViewSet.as_view({"get": "get_relation_info"})),
    path("dept_lazy_tree/", DeptViewSet.as_view({"get": "dept_lazy_tree"})),
    path("holiday/", HolidayView.as_view()),  # 节假日
    # path('pdf/', ConvertPdfView.as_view()),  # PDF
    path("ws", websocket_view),
]
urlpatterns += system_url.urls
