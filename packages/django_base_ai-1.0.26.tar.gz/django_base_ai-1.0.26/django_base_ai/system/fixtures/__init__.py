#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""fixtures 包：存放 initialize 等初始化逻辑与 init_*.json 引用。"""
