#!/usr/bin/env python
"""
@Project ：django_base_ai
@File    ：core_base_auth.py
@Author  ：congxing.wang
@Date    ：2026/02/25
@Desc    ：权限相关 JSON 扩展字段。存库为 { nid: CoreBaseAuth.id }，读库时按 nid 查 target_data 转成前端所需结构。
"""

import json
import logging

from django.db import models

from django_base_ai.utils import format_core_base_auth

logger = logging.getLogger(__name__)


class CoreBaseAuthField(models.JSONField):
    """存储协作人/可见范围等权限配置，值为 CoreBaseAuth 的 id（nid），读时展开为 target_data。"""

    def __init__(self, *args, db_collation=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.db_collation = db_collation
        self.args = args
        self.kwargs = kwargs

    def get_db_prep_value(self, value, connection, prepared=False):
        """写入 DB 前：转为统一 JSON 结构（含 nid）。"""
        if prepared:
            return connection.ops.adapt_json(value, self.encoder)
        return json.dumps(format_core_base_auth.create_update_auth_json(value))

    def from_db_value(self, value, expression, connection):
        """从 DB 读出：按 nid 查 CoreBaseAuth，将 target_data 转为前端 auth JSON。"""
        if value:
            from django_base_ai.system.models import CoreBaseAuth

            try:
                nid = json.loads(value).get("nid", 0)
                django_base_ai_auth = CoreBaseAuth.objects.filter(id=nid).first()
                value = format_core_base_auth.get_auth_json(
                    django_base_ai_auth.target_data if django_base_ai_auth else [], nid
                )
            except (json.JSONDecodeError, TypeError) as e:
                logger.warning("CoreBaseAuthField from_db_value 解析失败: %s", e)
        return value
