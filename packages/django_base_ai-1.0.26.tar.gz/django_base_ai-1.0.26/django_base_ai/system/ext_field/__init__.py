#!/usr/bin/env python
"""
@Project ：django_base_ai
@File    ：__init__.py
@Author  ：congxing.wang
@Date    ：2026/02/25
@Desc    ：扩展字段包初始化
"""
