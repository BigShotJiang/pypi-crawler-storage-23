#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
AI 生成 Word 文档相关：根据描述/大纲生成 docx、段落处理（续写/润色/翻译等）。
本模块提供 AIDocxMixin，可混入 ViewSet 使用；依赖 view 提供 _parse_body、_get_client。
"""

import logging
from typing import Any

from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.request import Request
from rest_framework.response import Response

from django_base_ai.utils.ai import ChatMessage
from django_base_ai.utils.json_response import DetailResponse, ErrorResponse

logger = logging.getLogger(__name__)


# 段落处理：operation -> (system_prompt 模板, 中文说明)
TEXT_REFINE_OPERATIONS: dict[str, tuple[str, str]] = {
    "continue": (
        "你是一个写作助手。用户会给出一段文字，请在其基础上自然续写一段，风格与篇幅与原段协调，只输出续写内容，不要重复原文。",
        "续写",
    ),
    "rewrite": (
        "你是一个写作助手。用户会给出一段文字，请用不同表述重写该段，保持原意与信息量，语气可略作调整，只输出重写后的段落。",
        "重写",
    ),
    "summarize": (
        "你是一个写作助手。用户会给出一段文字，请将其缩写/概括为更短的段落，保留核心信息，只输出缩写后的内容。",
        "缩写",
    ),
    "expand": (
        "你是一个写作助手。用户会给出一段文字，请在其基础上扩写，增加细节、论据或展开说明，保持主题一致，只输出扩写后的完整段落。",
        "扩写",
    ),
    "polish": (
        "你是一个写作助手。用户会给出一段文字，请在不改变原意的前提下润色表达，使语句更流畅、用词更恰当，只输出润色后的段落。",
        "润色",
    ),
    "proofread": (
        "你是一个写作与校对助手。用户会给出一段文字，请进行校对与润色：纠正错别字、语病、标点，并适当优化表述，只输出校润后的段落。",
        "校润",
    ),
    "translate": (
        "你是一个翻译助手。用户会给出一段文字及目标语言，请将其翻译成目标语言，保持专业、流畅，只输出译文，不要加说明。",
        "翻译",
    ),
}

TARGET_LANG_NAMES: dict[str, str] = {
    "en": "英语", "english": "英语", "zh": "中文", "zh-cn": "简体中文", "zh-tw": "繁体中文",
    "ja": "日语", "japanese": "日语", "ko": "韩语", "korean": "韩语",
    "fr": "法语", "de": "德语", "es": "西班牙语", "ru": "俄语",
}


def _get_text_refine_system_user(operation: str, text: str, target_lang: str) -> tuple[str, str] | None:
    """返回 (system, user) 消息内容；不支持的操作返回 None。"""
    if operation not in TEXT_REFINE_OPERATIONS:
        return None
    system, _ = TEXT_REFINE_OPERATIONS[operation]
    if operation == "translate":
        lang_hint = TARGET_LANG_NAMES.get((target_lang or "").strip().lower()) or (target_lang or "英语")
        user = f"请将以下内容翻译成{lang_hint}：\n\n{text}"
    else:
        user = f"请对以下段落进行{TEXT_REFINE_OPERATIONS[operation][1]}：\n\n{text}"
    return system, user


class AIDocxMixin:
    """AI Word 文档相关 action 混入；挂到 ViewSet 上使用。依赖 _parse_body、_get_client。"""

    @action(detail=False, methods=["post"], permission_classes=[IsAuthenticated])
    def text_refine(self, request: Request) -> Response:
        """
        段落处理：续写、重写、缩写、扩写、润色、校润、翻译。
        请求体: text（必填）, operation（必填）, target_lang（选填，翻译时目标语言，如 en/zh/ja）,
               provider, model, use_settings, api_key, base_url。
        operation: continue=续写, rewrite=重写, summarize=缩写, expand=扩写, polish=润色, proofread=校润, translate=翻译。
        响应: { content, operation, operation_name, model, usage }。
        """
        body = self._parse_body(request)
        text = (body.get("text") or "").strip()
        if not text:
            return ErrorResponse(msg="text 不能为空")
        operation = (body.get("operation") or "").strip().lower()
        if not operation:
            return ErrorResponse(msg="operation 不能为空")
        target_lang = (body.get("target_lang") or "").strip()
        pair = _get_text_refine_system_user(operation, text, target_lang)
        if pair is None:
            valid = ", ".join(TEXT_REFINE_OPERATIONS.keys())
            return ErrorResponse(msg=f"operation 不支持，可选: {valid}")
        system_content, user_content = pair
        client, err = self._get_client(body)
        if err:
            return ErrorResponse(msg=err)
        model = body.get("model")
        messages = [
            ChatMessage(role="system", content=system_content),
            ChatMessage(role="user", content=user_content),
        ]
        try:
            result = client.chat(messages, model=model)
        except Exception as e:
            logger.exception("Text refine failed: %s", e)
            return ErrorResponse(msg=f"处理失败: {e}")
        _, operation_name = TEXT_REFINE_OPERATIONS[operation]
        return DetailResponse(
            data={
                "content": result.content or "",
                "operation": operation,
                "operation_name": operation_name,
                "model": result.model or "",
                "usage": result.usage or {},
            }
        )

    @action(detail=False, methods=["post"], permission_classes=[IsAuthenticated])
    def generate_docx(self, request: Request) -> Response:
        """
        根据描述或大纲生成 Word 文档（预留接口）。
        请求体: description（描述）, outline（可选，标题列表）, title（可选）,
               provider, model, use_settings, api_key, base_url。
        响应: { file_url, filename, saved_path }。
        """
        body = self._parse_body(request)
        # TODO: 实现 AI 生成 docx 逻辑，保存到 media 并返回 URL
        return DetailResponse(
            data={
                "message": "AI Docx 功能待实现",
                "file_url": "",
                "filename": "",
                "saved_path": "",
            }
        )
