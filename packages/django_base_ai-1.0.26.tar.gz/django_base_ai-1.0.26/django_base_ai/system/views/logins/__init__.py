#!/usr/bin/env python
# @Project ：django_base_ai
# @File    : __init__.py
# @Author  : cx
# @Time    : 11/2/2025
# @Desc    : 登录相关视图包初始化
