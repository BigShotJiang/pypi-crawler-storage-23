#!/usr/bin/env python
# @Project ：django_base_ai
# @File    : my_superiors.py
# @Author  : cx
# @Time    : 11/2/2025
# @Desc    : 我的上级领导管理接口
import logging

from django_base_ai.system.models import MySuperiors
from django_base_ai.utils.serializers import CustomModelSerializer
from django_base_ai.utils.viewset import CustomModelViewSet

logger = logging.getLogger(__name__)


class MySuperiorsSerializer(CustomModelSerializer):
    class Meta:
        model = MySuperiors
        fields = "__all__"
        read_only_fields = ["id"]


class MySuperiorsCreateUpdateSerializer(CustomModelSerializer):
    class Meta:
        model = MySuperiors
        fields = "__all__"


class MySuperiorsViewSet(CustomModelViewSet):
    """
    协作人
    list:查询
    create:新增
    update:修改
    retrieve:单例
    destroy:删除
    """

    queryset = MySuperiors.objects.all()
    serializer_class = MySuperiorsSerializer
