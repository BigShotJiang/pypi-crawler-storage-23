#!/usr/bin/env python
# @Project ：django_base_ai
# @File    : collaborator.py
# @Author  : cx
# @Time    : 11/2/2025
# @Desc    : 协作人（秘书）管理接口
import logging

from rest_framework import serializers

from django_base_ai.system.models import Collaborator
from django_base_ai.utils.serializers import CustomModelSerializer
from django_base_ai.utils.viewset import CustomModelViewSet

logger = logging.getLogger(__name__)


class CollaboratorSerializer(CustomModelSerializer):
    uid = serializers.CharField(source="user_info.id", read_only=True)
    username = serializers.CharField(source="user_info.username", read_only=True)
    name = serializers.CharField(source="user_info.name", read_only=True)
    avatar = serializers.CharField(source="user_info.avatar", read_only=True)
    employee_no = serializers.CharField(source="user_info.employee_no", read_only=True)

    class Meta:
        model = Collaborator
        fields = "__all__"
        read_only_fields = ["id"]


class CollaboratorCreateUpdateSerializer(CustomModelSerializer):
    class Meta:
        model = Collaborator
        fields = "__all__"


class CollaboratorViewSet(CustomModelViewSet):
    """
    协作人管理接口
    list:查询
    create:新增
    update:修改
    retrieve:单例
    destroy:删除
    """

    queryset = Collaborator.objects.all()
    serializer_class = CollaboratorSerializer
    # extra_filter_backends = []
