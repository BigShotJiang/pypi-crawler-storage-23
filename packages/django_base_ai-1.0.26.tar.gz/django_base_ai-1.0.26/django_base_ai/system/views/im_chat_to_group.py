#!/usr/bin/env python
# @Project ：django_base_ai
# @File    : im_chat_to_group.py
# @Author  : cx
# @Time    : 11/2/2025
# @Desc    : IM 群组会话与成员管理。

import logging

from django_base_ai.system.models import IMChatToGroup
from django_base_ai.utils.serializers import CustomModelSerializer
from django_base_ai.utils.viewset import CustomModelViewSet

logger = logging.getLogger(__name__)


class IMChatToGroupSerializer(CustomModelSerializer):
    class Meta:
        model = IMChatToGroup
        fields = "__all__"
        read_only_fields = ["id"]


class IMChatToGroupCreateUpdateSerializer(CustomModelSerializer):
    class Meta:
        model = IMChatToGroup
        fields = "__all__"


class IMChatToGroupViewSet(CustomModelViewSet):
    """
    群聊
    list:查询
    create:新增
    update:修改
    retrieve:单例
    destroy:删除
    """

    queryset = IMChatToGroup.objects.all()
    serializer_class = IMChatToGroupSerializer
    # extra_filter_backends = []
    filter_fields = ["im_session"]
