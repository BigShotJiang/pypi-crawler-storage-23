#!/usr/bin/env python
# @Project ：django_base_ai
# @File    : api_white_list.py
# @Author  : cx
# @Time    : 11/2/2025
# @Desc    : 接口白名单 CRUD 与初始化序列化器（用于 generate_init_json）。
import logging

from django_base_ai.system.models import ApiWhiteList
from django_base_ai.utils.serializers import CustomModelSerializer
from django_base_ai.utils.viewset import CustomModelViewSet

logger = logging.getLogger(__name__)


class ApiWhiteListSerializer(CustomModelSerializer):
    """
    接口白名单-序列化器
    """

    class Meta:
        model = ApiWhiteList
        fields = "__all__"
        read_only_fields = ["id"]


class ApiWhiteListInitSerializer(CustomModelSerializer):
    """
    初始化获取数信息(用于生成初始化json文件)
    """

    class Meta:
        model = ApiWhiteList
        fields = ["url", "method", "enable_datasource", "creator", "dept_belong_id"]
        read_only_fields = ["id"]
        extra_kwargs = {"creator": {"write_only": True}, "dept_belong_id": {"write_only": True}}


class ApiWhiteListViewSet(CustomModelViewSet):
    """
    接口白名单
    list:查询
    create:新增
    update:修改
    retrieve:单例
    destroy:删除
    """

    queryset = ApiWhiteList.objects.all()
    serializer_class = ApiWhiteListSerializer
    # permission_classes = []
