#!/usr/bin/env python
# @Project ：django_base_ai
# @File    : convert_pdf.py
# @Author  : cx
# @Time    : 11/2/2025
# @Desc    : 根据 URL 生成 PDF 接口
# import pdfkit
import logging

from rest_framework.views import APIView

from django_base_ai.utils.json_response import DetailResponse

logger = logging.getLogger(__name__)


class ConvertPdfView(APIView):
    authentication_classes = []
    permission_classes = []

    def get(self, request):
        # pdfkit.from_url('https://www.baidu.com/', 'out.pdf')
        return DetailResponse(msg="成功")
