#!/usr/bin/env python
# @Project ：django_base_ai
# @File    : im_chat_qa.py
# @Author  : cx
# @Time    : 11/2/2025
# @Desc    : QA 问答记录表

import logging

from django_base_ai.system.models import IMChatQA
from django_base_ai.utils.serializers import CustomModelSerializer
from django_base_ai.utils.viewset import CustomModelViewSet

logger = logging.getLogger(__name__)


class IMChatQASerializer(CustomModelSerializer):
    class Meta:
        model = IMChatQA
        fields = "__all__"
        read_only_fields = ["id"]


class IMChatQACreateUpdateSerializer(CustomModelSerializer):
    class Meta:
        model = IMChatQA
        fields = ["is_it_solved"]
        read_only_fields = ["id", "ai_desk_app_manage"]


class IMChatQAViewSet(CustomModelViewSet):
    """
    QA问答表
    list:查询
    create:新增
    update:修改
    retrieve:单例
    destroy:删除
    """

    queryset = IMChatQA.objects.all()
    serializer_class = IMChatQASerializer
    create_serializer_class = IMChatQACreateUpdateSerializer
    update_serializer_class = IMChatQACreateUpdateSerializer
    # extra_filter_backends = []
    filter_fields = ["ai_desk_app_manage"]
