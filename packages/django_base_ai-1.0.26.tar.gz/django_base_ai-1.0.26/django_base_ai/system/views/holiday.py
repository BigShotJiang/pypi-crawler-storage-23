#!/usr/bin/env python
# @Project ：django_base_ai
# @File    : holiday.py
# @Author  : cx
# @Time    : 11/2/2025
# @Desc    : 节假日查询接口
import logging

from rest_framework.views import APIView

from django_base_ai.utils import holidays
from django_base_ai.utils.json_response import DetailResponse

logger = logging.getLogger(__name__)


class HolidayView(APIView):
    authentication_classes = []
    permission_classes = []

    def get(self, request):
        """
        type 0表示当天 1表示指定日期 2返回所有节假日
        :param request:
        :return:
        """
        holiday = holidays.Holiday()
        t = int(request.GET.get("type", 2))
        day = request.GET.get("day", None)
        if t == 1:
            return DetailResponse(holiday.today(day))
        return DetailResponse(holiday.day_infos)
