#!/usr/bin/env python
# @Project ：django_base_ai
# @File    : im_chat_question_group.py
# @Author  : cx
# @Time    : 11/2/2025
# @Desc    : 热门问题分组
import logging

from rest_framework import serializers

from django_base_ai.system.models import IMChatQuestion, IMChatQuestionGroup
from django_base_ai.utils.serializers import CustomModelSerializer
from django_base_ai.utils.viewset import CustomModelViewSet

logger = logging.getLogger(__name__)


class IMChatQuestionGroupSerializer(CustomModelSerializer):
    question_count = serializers.SerializerMethodField()

    def get_question_count(self, obj):
        return IMChatQuestion.objects.filter(im_chat_question_group=obj).count()

    class Meta:
        model = IMChatQuestionGroup
        fields = ["id", "title", "question_count"]
        read_only_fields = ["id"]


class IMChatQuestionCreateUpdateSerializer(CustomModelSerializer):
    class Meta:
        model = IMChatQuestionGroup
        fields = "__all__"
        read_only_fields = ["id"]


class IMChatQuestionGroupViewSet(CustomModelViewSet):
    """
    员工服务的热门问题分组
    list:查询
    create:新增
    update:修改
    retrieve:单例
    destroy:删除
    """

    queryset = IMChatQuestionGroup.objects.all().order_by("sort")
    serializer_class = IMChatQuestionGroupSerializer
    filter_fields = ["ai_desk_app_manage"]
    search_fields = ["title"]
    create_serializer_class = IMChatQuestionCreateUpdateSerializer
    update_serializer_class = IMChatQuestionCreateUpdateSerializer
    # extra_filter_backends = []
