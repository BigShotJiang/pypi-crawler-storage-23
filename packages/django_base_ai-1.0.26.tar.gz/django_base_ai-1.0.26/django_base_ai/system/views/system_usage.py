#!/usr/bin/env python
# @Project ：django_base_ai
# @File    : system_usage.py
# @Author  : cx
# @Time    : 11/2/2025
# @Desc    : 系统使用统计量接口
import logging

from rest_framework.decorators import action
from rest_framework.permissions import AllowAny

from django_base_ai.system.models import SystemUsage
from django_base_ai.utils.json_response import DetailResponse
from django_base_ai.utils.serializers import CustomModelSerializer
from django_base_ai.utils.viewset import CustomModelViewSet

logger = logging.getLogger(__name__)


class SystemUsageSerializer(CustomModelSerializer):
    class Meta:
        model = SystemUsage
        fields = "__all__"
        read_only_fields = ["id"]


class SystemUsageCreateUpdateSerializer(CustomModelSerializer):
    class Meta:
        model = SystemUsage
        fields = "__all__"


class SystemUsageViewSet(CustomModelViewSet):
    """
    统计量
    list:查询
    create:新增
    update:修改
    retrieve:单例
    destroy:删除
    """

    queryset = SystemUsage.objects.all()
    serializer_class = SystemUsageSerializer
    create_serializer_class = SystemUsageCreateUpdateSerializer
    update_serializer_class = SystemUsageCreateUpdateSerializer
    # extra_filter_backends = []

    @action(methods=["post"], detail=False, permission_classes=[AllowAny], authentication_classes=[])
    def allow_usage(self, request, *args, **kwargs):
        return DetailResponse()
