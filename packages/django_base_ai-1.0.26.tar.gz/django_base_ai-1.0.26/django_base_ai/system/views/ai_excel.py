#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
AI 生成 Excel 相关：根据描述/表格数据生成 xlsx、解析与补全等。
本模块提供 AIExcelMixin，可混入 ViewSet 使用；依赖 view 提供 _parse_body、_get_client。
"""

import logging
from typing import Any

from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.request import Request
from rest_framework.response import Response

from django_base_ai.utils.json_response import DetailResponse, ErrorResponse

logger = logging.getLogger(__name__)


class AIExcelMixin:
    """AI Excel 相关 action 混入；挂到 ViewSet 上使用。依赖 _parse_body、_get_client。"""

    @action(detail=False, methods=["post"], permission_classes=[IsAuthenticated])
    def generate_excel(self, request: Request) -> Response:
        """
        根据描述或结构化数据生成 Excel 文件（预留接口）。
        请求体: description（描述）, data（可选，二维数组）, filename（可选）,
               provider, model, use_settings, api_key, base_url。
        响应: { file_url, filename, saved_path }。
        """
        body = self._parse_body(request)
        # TODO: 实现 AI 生成 / 填充 Excel 逻辑，保存到 media 并返回 URL
        return DetailResponse(
            data={
                "message": "AI Excel 功能待实现",
                "file_url": "",
                "filename": "",
                "saved_path": "",
            }
        )
