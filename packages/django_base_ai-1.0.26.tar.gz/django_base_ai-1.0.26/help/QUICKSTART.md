# 快速开始（约 5 分钟）

使用 **pip install django-base-ai** 安装后，在新建或已有 Django 项目中按下列步骤配置即可跑通，无需 MySQL/Redis（SQLite + 内存缓存）。

---

## 1. 安装

```bash
pip install django-base-ai
```

---

## 2. 创建项目（若无已有项目）

若已有 Django 项目，可跳过本步，直接进入步骤 3 在现有 `settings.py` 与 `urls.py` 中配置。

```bash
django-admin startproject myproject
cd myproject
```

---

## 3. 配置 settings.py

在项目的 `settings.py` 中**先**引入底座默认配置，**再**覆盖或追加以下项（最小可运行配置，无需 MySQL/Redis）：

```python
from pathlib import Path

# 先引入底座默认配置（DRF、JWT、认证、分页等）
from django_base_ai.settings import *

# 以下为项目必选与快速开始配置（覆盖底座中的同名项）
BASE_DIR = Path(__file__).resolve().parent.parent
# SECRET_KEY：底座已从环境变量 SECRET_KEY 读取；多应用共用同一底座时可不覆盖，统一在部署层设置 SECRET_KEY 即可共用底座能力
# 若需本项目独立密钥，可在此覆盖：SECRET_KEY = "你的随机字符串"
DEBUG = True
ALLOWED_HOSTS = ["*"]

# 数据库：SQLite（无需 MySQL）
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": str(BASE_DIR / "db.sqlite3"),
    }
}

# 缓存与 Channel：内存（无需 Redis）
REDIS_MODE = "memory"
CACHES = {"default": {"BACKEND": "django.core.cache.backends.locmem.LocMemCache"}}
CHANNEL_LAYERS = {"default": {"BACKEND": "channels.layers.InMemoryChannelLayer"}}
DISPATCH_DB_TYPE = "memory"

# 应用与中间件（底座依赖）
INSTALLED_APPS = [
    "daphne",
    "guardian",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "django_comment_migrate",
    "rest_framework",
    "django_filters",
    "corsheaders",
    "rest_framework_simplejwt.token_blacklist",
    "django_base_ai.system",
    "captcha",
    "channels",
    "django_celery_beat",
    "django_celery_results",
]
MIDDLEWARE = [
    "django_base_ai.utils.middleware.HealthCheckMiddleware",
    "django_base_ai.utils.middleware.TraceIdMiddleware",
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "corsheaders.middleware.CorsMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "django_base_ai.utils.middleware.ApiLoggingMiddleware",
]

AUTH_USER_MODEL = "system.Users"
ROOT_URLCONF = "myproject.urls"  # 若项目名为 myproject
WSGI_APPLICATION = "myproject.wsgi.application"
ASGI_APPLICATION = "myproject.asgi.application"

# 登录体验：开发阶段可关闭验证码
LOGIN_NO_CAPTCHA_AUTH = True
```

若项目名不是 `myproject`，请将 `ROOT_URLCONF`、`WSGI_APPLICATION`、`ASGI_APPLICATION` 中的 `myproject` 改为实际项目名。

---

## 4. 配置路由 urls.py

在项目的 `urls.py`（如 `myproject/urls.py`）中挂载底座路由：

```python
from django.urls import include, path

urlpatterns = [
    path("base/api/system/", include("django_base_ai.system.urls")),
]
```

---

## 5. 迁移与启动

```bash
python manage.py migrate
python manage.py runserver
```

浏览器访问 <http://127.0.0.1:8000/base/api/system/> 可确认接口已挂载。

---

## 6. 初始化数据（可选，建议执行）

底座提供 `init` 命令，用于生成菜单、角色、字典等基础数据：

```bash
python manage.py init
```

若无初始用户，可再执行 `python manage.py createsuperuser` 创建管理员。登录接口：**POST** `/base/api/system/login/`（用户名/密码）。

---

## 7. 使用 AI 能力（主推）

AI 接口已随底座挂载，调用前需配置**至少一个**供应商的 API Key。在项目 `settings.py` 末尾增加（或使用环境变量）：

```python
# AI 供应商（主推 DeepSeek，可按需改为腾讯/OpenAI 等）
AI_DEFAULT_PROVIDER = "deepseek"
AI_DEEPSEEK_API_KEY = "sk-你的key"
AI_DEEPSEEK_DEFAULT_MODEL = "deepseek-chat"
```

配置后即可调用 **POST** `/base/api/system/ai_chat_session/chat/` 等进行对话，或使用 PPT、文本润色等接口。更多 key 说明见 [README](../README.md)。

---

## 常见问题

| 问题 | 处理 |
|------|------|
| 引入 django_base_ai.settings 后报错 | 确保已 `pip install django-base-ai`，且 Python 与 Django 版本满足要求（见 README）。 |
| 登录 401 / 无用户 | 执行 `python manage.py init` 或 `createsuperuser`，确认用户名密码。 |
| AI 接口报错或未返回 | 在 settings 或环境变量中配置对应供应商的 API Key。 |
| 想用 MySQL/Redis | 在 settings 中改为配置 `DATABASES`（MySQL）、`REDIS_MODE` 与 `REDIS_URL`、`CACHES`/`CHANNEL_LAYERS`，并设置 `DISPATCH_DB_TYPE`。 |
| 多应用共用同一底座（统一会话/JWT） | 子项目不要覆盖 `SECRET_KEY`，在部署/平台层统一设置环境变量 `SECRET_KEY`，所有基于该底座的应用即共用同一密钥。 |

更多集成与配置见 [README](../README.md) 与 [ARCHITECTURE.md](ARCHITECTURE.md)。
