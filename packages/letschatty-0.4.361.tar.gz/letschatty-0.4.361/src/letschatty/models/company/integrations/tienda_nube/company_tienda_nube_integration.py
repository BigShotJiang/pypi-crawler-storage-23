from typing import List, Optional
from datetime import datetime
from zoneinfo import ZoneInfo
from pydantic import BaseModel, Field

class TiendaNubeWebhookSubscription(BaseModel):
    """Represents a single webhook subscription"""
    topic: str = Field(description="Webhook topic (e.g., 'product/created')")
    webhook_id: Optional[str] = Field(default=None, description="Tienda Nube webhook ID")
    subscribed_at: datetime = Field(default_factory=lambda: datetime.now(tz=ZoneInfo("UTC")))
    is_active: bool = Field(default=True, description="Whether subscription is active")

class TiendaNubeIntegration(BaseModel):
    """Tienda Nube integration for the company"""
    store_id: str = Field(default="")
    oauth_state: str = Field(default="")
    oauth_state_at: datetime = Field(default_factory=lambda: datetime.now(tz=ZoneInfo("UTC")))
    access_token: Optional[str] = Field(default=None)
    connected_at: Optional[datetime] = Field(default=None)
    scope: Optional[str] = Field(default=None)
    
    # Webhook subscriptions
    webhook_subscriptions: List[TiendaNubeWebhookSubscription] = Field(
        default_factory=list,
        description="List of active webhook subscriptions"
    )
    
    # Scheduled sync settings
    product_sync_enabled: bool = Field(
        default=False,
        description="Whether scheduled product sync is enabled"
    )
    product_sync_interval_hours: int = Field(
        default=24,
        description="Interval in hours for scheduled product sync"
    )
    last_product_sync_at: Optional[datetime] = Field(
        default=None,
        description="Timestamp of last product sync"
    )
    
    @property
    def is_connected(self) -> bool:
        """Check if the integration is fully connected"""
        return bool(self.access_token and self.store_id)
    
    def get_subscribed_topics(self) -> List[str]:
        """Get list of currently subscribed webhook topics"""
        return [sub.topic for sub in self.webhook_subscriptions if sub.is_active]
    
    def reset(self) -> None:
        """Reset integration to disconnected state"""
        self.store_id = ""
        self.oauth_state = ""
        self.oauth_state_at = datetime.now(tz=ZoneInfo("UTC"))
        self.access_token = None
        self.connected_at = None
        self.scope = None
        self.webhook_subscriptions = []
        self.product_sync_enabled = False
        self.product_sync_interval_hours = 24
        self.last_product_sync_at = None
