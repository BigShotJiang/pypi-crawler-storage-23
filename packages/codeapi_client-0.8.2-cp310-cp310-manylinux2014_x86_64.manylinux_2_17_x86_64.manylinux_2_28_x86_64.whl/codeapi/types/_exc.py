from fastapi import HTTPException

from ._enums import CodeAPIError


class CodeAPIException(HTTPException):
    def __init__(self, error: CodeAPIError, message: str = ""):
        self.error: CodeAPIError = error
        self.message: str = message

        status_code = self._get_status_code()
        detail = {"error": self.error.name, "message": message}
        super().__init__(status_code=status_code, detail=detail)

    _STATUS_CODES: dict[CodeAPIError, int] = {
        CodeAPIError.CODE_NOT_FOUND: 404,
        CodeAPIError.CODE_TYPE_MISMATCH: 400,
        CodeAPIError.HIVE_NOT_FOUND: 404,
        CodeAPIError.JOB_FAILED: 500,
        CodeAPIError.JOB_NOT_FINISHED: 400,
        CodeAPIError.JOB_NOT_FOUND: 404,
        CodeAPIError.JOB_POST_RUNNING: 409,
        CodeAPIError.JOB_RESULT_UNAVAILABLE: 422,
        CodeAPIError.JOB_STILL_QUEUED: 503,
        CodeAPIError.JOB_TIMED_OUT: 408,
        CodeAPIError.NO_ASSOCIATED_CODE_ID: 404,
        CodeAPIError.NO_CODE_INFO: 404,
        CodeAPIError.NO_JOB_META: 404,
        CodeAPIError.NO_STORAGE_BACKEND: 501,
    }

    def _get_status_code(self) -> int:
        return self._STATUS_CODES.get(self.error, 500)
