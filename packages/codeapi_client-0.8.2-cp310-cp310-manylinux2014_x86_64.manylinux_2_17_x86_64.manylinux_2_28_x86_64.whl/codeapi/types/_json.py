from __future__ import annotations

import json
from io import BytesIO, IOBase
from pathlib import Path
from typing import Any, BinaryIO, OrderedDict

from pydantic import GetCoreSchemaHandler, GetJsonSchemaHandler
from pydantic.json_schema import JsonSchemaValue
from pydantic_core import CoreSchema, core_schema


class JSONData(dict):
    @classmethod
    def __get_pydantic_core_schema__(
        cls, source_type: Any, handler: GetCoreSchemaHandler
    ) -> CoreSchema:
        return core_schema.no_info_plain_validator_function(
            cls._pydantic_validate,
            serialization=core_schema.plain_serializer_function_ser_schema(
                dict, info_arg=False
            ),
        )

    @classmethod
    def __get_pydantic_json_schema__(
        cls, core_schema: CoreSchema, handler: GetJsonSchemaHandler
    ) -> JsonSchemaValue:
        return {"type": "object"}

    @staticmethod
    def _pydantic_validate(value: Any) -> JSONData:
        if isinstance(value, JSONData):
            return value
        if isinstance(value, dict):
            return JSONData(value)
        if isinstance(value, (str, bytes)):
            return JSONData(json.loads(value))
        raise ValueError(f"Cannot convert {type(value)} to JSONData")

    def __init__(self, data: dict | Path | str | bytes | None = None):
        super().__init__()
        if data is None:
            pass
        elif isinstance(data, (str, bytes)):
            self.update(json.loads(data))
        elif isinstance(data, Path):
            if data.is_file():
                self.update(json.loads(data.read_text()))
            else:
                raise ValueError(f"{data} is not a file")
        elif isinstance(data, dict):
            self.update(data)
        else:
            raise TypeError("Invalid data type for JSONData")

    @property
    def json_str(self) -> str:
        return json.dumps(self)

    def dump(self) -> str:
        return self.json_str

    def print(self, indent: int = 4) -> None:
        print(json.dumps(self, indent=indent))

    def add_key(self, key: Any, value: Any, prepend: bool = False) -> None:
        new_data = OrderedDict()
        if prepend:
            new_data[key] = value
            new_data.update(self)
        else:
            new_data.update(self)
            new_data[key] = value
        self.clear()
        self.update(new_data)

    def remove_key(self, key: Any) -> None:
        self.pop(key, None)

    @classmethod
    def from_file(cls, path: Path | str) -> "JSONData":
        return cls(json.loads(Path(path).read_text()))

    @classmethod
    def from_str(cls, json_str: str) -> "JSONData":
        return cls(json_str)

    @classmethod
    def from_bytes(cls, data_bytes: bytes | BinaryIO) -> "JSONData":
        if isinstance(data_bytes, (BinaryIO, IOBase)):
            data_bytes.seek(0)
            data_bytes = data_bytes.read()
        return cls(json.loads(data_bytes))

    def to_file(self, path: Path | str) -> None:
        Path(path).write_text(json.dumps(self, indent=4))

    def to_bytesio(self) -> BytesIO:
        return BytesIO(json.dumps(self).encode())
