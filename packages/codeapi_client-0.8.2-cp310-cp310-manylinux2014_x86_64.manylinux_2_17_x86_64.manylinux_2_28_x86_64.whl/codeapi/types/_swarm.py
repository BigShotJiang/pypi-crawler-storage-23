from __future__ import annotations

from pydantic import BaseModel, Field, computed_field

from codeapi.types._enums import HiveMode, HiveStatus


class HiveHeartbeat(BaseModel):
    hive_id: str
    hostname: str
    host: str
    timestamp: float
    status: HiveStatus
    mode: HiveMode = HiveMode.SHARED
    worker_count: int = 0

    cpu_count: int = Field(description="Number of CPU cores")
    cpu_usage: float = Field(description="Current CPU usage percentage")

    memory_total: float = Field(description="Total RAM in GB")
    memory_used: float = Field(description="Used RAM in GB")
    memory_free: float = Field(description="Free RAM in GB")
    memory_usage: float = Field(description="Memory usage percentage")

    disk_total: float = Field(description="Total disk space in GB")
    disk_used: float = Field(description="Used disk space in GB")
    disk_free: float = Field(description="Free disk space in GB")
    disk_usage: float = Field(description="Disk usage percentage")

    @computed_field  # type: ignore[prop-decorator]
    @property
    def alive(self) -> bool:
        return self.status in (HiveStatus.IDLE, HiveStatus.BUSY)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def idle(self) -> bool:
        return self.status == HiveStatus.IDLE

    @computed_field  # type: ignore[prop-decorator]
    @property
    def busy(self) -> bool:
        return self.status == HiveStatus.BUSY

    @computed_field  # type: ignore[prop-decorator]
    @property
    def exclusive(self) -> bool:
        return self.mode == HiveMode.EXCLUSIVE

    @computed_field  # type: ignore[prop-decorator]
    @property
    def shared(self) -> bool:
        return self.mode == HiveMode.SHARED

    @classmethod
    def create(
        cls,
        hive_id: str,
        hostname: str,
        host: str,
        timestamp: float,
        worker_count: int = 0,
        mode: HiveMode = HiveMode.SHARED,
        shutting_down: bool = False,
    ) -> HiveHeartbeat:
        import psutil

        from codeapi.core.cgroup import get_cpu_limit, get_memory_limit

        cpu_usage = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage("/")

        cpu_limit = get_cpu_limit()
        cpu_count = cpu_limit if cpu_limit is not None else (psutil.cpu_count() or 1)

        mem_limit = get_memory_limit()
        if mem_limit is not None:
            mem_total, mem_used, mem_free, mem_usage = mem_limit
        else:
            mem_total = memory.total / (1024**3)
            mem_used = memory.used / (1024**3)
            mem_free = memory.available / (1024**3)
            mem_usage = memory.percent

        if shutting_down:
            status = HiveStatus.DEAD
        elif worker_count > 0:
            status = HiveStatus.BUSY
        else:
            status = HiveStatus.IDLE

        return cls(
            hive_id=hive_id,
            hostname=hostname,
            host=host,
            timestamp=timestamp,
            status=status,
            mode=mode,
            worker_count=worker_count,
            cpu_count=cpu_count,
            cpu_usage=cpu_usage,
            memory_total=mem_total,
            memory_used=mem_used,
            memory_free=mem_free,
            memory_usage=mem_usage,
            disk_total=disk.total / (1024**3),
            disk_used=disk.used / (1024**3),
            disk_free=disk.free / (1024**3),
            disk_usage=disk.percent,
        )


class SwarmMetrics(BaseModel):
    alive_hives: int = 0
    exclusive_hives: int = 0
    shared_hives: int = 0
    busy_hives: int = 0
    busy_exclusive_hives: int = 0
    busy_shared_hives: int = 0
    idle_hives: int = 0
    idle_exclusive_hives: int = 0
    idle_shared_hives: int = 0
    selectable_hives: int = 0
    pending_jobs: int = 0
    delayed_jobs: int = 0
    total_workers: int = 0
    avg_workers_per_hive: float = 0.0
    total_cpu_cores: int = 0
    avg_cpu_usage: float = 0.0
    total_memory: float = 0.0
    avg_memory_usage: float = 0.0
    hives: list[HiveHeartbeat] = []
