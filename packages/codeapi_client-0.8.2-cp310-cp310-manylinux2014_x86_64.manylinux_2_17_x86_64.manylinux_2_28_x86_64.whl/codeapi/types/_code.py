from pydantic import BaseModel

from ._enums import CodeType
from ._json import JSONData


class CodeInfo(BaseModel):
    code_id: str
    code_name: str
    code_type: CodeType
    metadata: JSONData

    def __str__(self):
        fields = self.__class__.__pydantic_fields__
        field_values = ", ".join(
            f"{k}={repr(v)}" for k, v in self.model_dump().items() if fields[k].repr
        )
        return f"{self.__class__.__name__}({field_values})"
