from pydantic import BaseModel


class MCPInspectionResult(BaseModel):
    server_info: dict
    tools: list[dict]
    resources: list[dict]
    resource_templates: list[dict]
    prompts: list[dict]
