"""onit-office: Standalone MCP server for Microsoft Office document creation."""

__version__ = "0.1.0"
