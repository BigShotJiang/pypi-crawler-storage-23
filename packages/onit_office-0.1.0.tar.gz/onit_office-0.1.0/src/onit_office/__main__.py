"""Allow running as python -m onit_office."""
from .cli import main

main()
