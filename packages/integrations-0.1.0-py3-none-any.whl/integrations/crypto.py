"""Credential encryption and decryption utilities.

Uses Fernet symmetric encryption from the `cryptography` library behind
a thin protocol so callers are not coupled to the concrete implementation.
"""

from __future__ import annotations

import json
from typing import Any, Protocol, runtime_checkable

from cryptography.fernet import Fernet


@runtime_checkable
class CredentialEncryptor(Protocol):
    """Protocol for encrypting / decrypting credential payloads."""

    def encrypt(self, data: dict[str, Any]) -> bytes: ...
    def decrypt(self, token: bytes) -> dict[str, Any]: ...


class FernetEncryptor:
    """Fernet-based credential encryptor.

    Args:
        key: A URL-safe base64-encoded 32-byte key (``Fernet.generate_key()``).
    """

    def __init__(self, key: str) -> None:
        self._fernet = Fernet(key.encode() if isinstance(key, str) else key)

    def encrypt(self, data: dict[str, Any]) -> bytes:
        """Serialize *data* to JSON and return the Fernet-encrypted token."""
        return self._fernet.encrypt(json.dumps(data).encode())

    def decrypt(self, token: bytes) -> dict[str, Any]:
        """Decrypt a Fernet token and deserialize the JSON payload."""
        return json.loads(self._fernet.decrypt(token).decode())
