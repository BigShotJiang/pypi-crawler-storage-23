"""Integration connection manager -- orchestrates connect/disconnect/refresh flows."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any
from urllib.parse import urlencode

from integrations.config import IntegrationsConfig
from integrations.crypto import FernetEncryptor
from integrations.models import (
    APIKeyCredentials,
    AuthType,
    ConnectionStatus,
    Integration,
    IntegrationStatus,
    OAuthCredentials,
)
from integrations.registry import ProviderRegistry
from integrations.store import IntegrationStore


class IntegrationManager:
    """High-level manager for creating, refreshing, and checking integrations.

    Args:
        config: Module-level configuration (encryption key, redirect URL).
        registry: Provider definitions catalogue.
        store: Persistence backend for integration records.
    """

    def __init__(
        self,
        config: IntegrationsConfig,
        registry: ProviderRegistry,
        store: IntegrationStore,
    ) -> None:
        self._config = config
        self._registry = registry
        self._store = store
        self._encryptor = FernetEncryptor(config.encryption_key)

    # ── Properties ──────────────────────────────────────────────────────────

    @property
    def registry(self) -> ProviderRegistry:
        return self._registry

    @property
    def store(self) -> IntegrationStore:
        return self._store

    # ── OAuth helpers ───────────────────────────────────────────────────────

    def generate_auth_url(
        self,
        provider_name: str,
        *,
        client_id: str,
        state: str | None = None,
        extra_params: dict[str, str] | None = None,
    ) -> str:
        """Build the OAuth authorization redirect URL for a provider.

        Args:
            provider_name: Registered provider name.
            client_id: OAuth application client ID.
            state: Opaque state for CSRF protection.
            extra_params: Additional query parameters.

        Returns:
            Full authorization URL ready for redirect.

        Raises:
            KeyError: If the provider is not registered.
            ValueError: If the provider does not support OAuth.
        """
        provider = self._registry.get(provider_name)
        if provider.auth_type != AuthType.OAUTH or not provider.oauth_authorize_url:
            raise ValueError(f"Provider '{provider_name}' does not support OAuth")

        params: dict[str, str] = {
            "client_id": client_id,
            "redirect_uri": f"{self._config.oauth_redirect_base_url}/{provider_name}",
            "response_type": "code",
        }
        if provider.required_scopes:
            params["scope"] = " ".join(provider.required_scopes)
        if state:
            params["state"] = state
        if extra_params:
            params.update(extra_params)

        return f"{provider.oauth_authorize_url}?{urlencode(params)}"

    # ── Connect flows ───────────────────────────────────────────────────────

    async def connect_oauth(
        self,
        provider_name: str,
        credentials: OAuthCredentials,
        *,
        name: str | None = None,
        config: dict[str, Any] | None = None,
    ) -> Integration:
        """Create an integration from an OAuth code exchange result.

        The caller is responsible for exchanging the authorization code with
        the provider's token endpoint; this method stores the resulting tokens.
        """
        provider = self._registry.get(provider_name)
        encrypted = self._encryptor.encrypt(credentials.model_dump(mode="json"))

        integration = Integration(
            id=str(uuid.uuid4()),
            name=name or provider.name,
            provider=provider.name,
            auth_type=AuthType.OAUTH,
            status=IntegrationStatus.ACTIVE,
            config=config or {},
            credentials_encrypted=encrypted,
        )
        return await self._store.save(integration)

    async def connect_api_key(
        self,
        provider_name: str,
        credentials: APIKeyCredentials,
        *,
        name: str | None = None,
        config: dict[str, Any] | None = None,
    ) -> Integration:
        """Create an integration using an API key."""
        provider = self._registry.get(provider_name)
        encrypted = self._encryptor.encrypt(credentials.model_dump())

        integration = Integration(
            id=str(uuid.uuid4()),
            name=name or provider.name,
            provider=provider.name,
            auth_type=AuthType.API_KEY,
            status=IntegrationStatus.ACTIVE,
            config=config or {},
            credentials_encrypted=encrypted,
        )
        return await self._store.save(integration)

    # ── Credential management ───────────────────────────────────────────────

    def get_credentials(self, integration: Integration) -> dict[str, Any]:
        """Decrypt and return credentials for an integration.

        Raises:
            ValueError: If the integration has no stored credentials.
        """
        if integration.credentials_encrypted is None:
            raise ValueError("Integration has no stored credentials")
        return self._encryptor.decrypt(integration.credentials_encrypted)

    async def refresh_credentials(
        self, integration_id: str, new_credentials: OAuthCredentials
    ) -> Integration:
        """Replace the stored credentials for an existing OAuth integration.

        Raises:
            KeyError: If the integration does not exist.
        """
        integration = await self._store.get(integration_id)
        if integration is None:
            raise KeyError(f"Integration '{integration_id}' not found")

        encrypted = self._encryptor.encrypt(new_credentials.model_dump(mode="json"))
        integration.credentials_encrypted = encrypted
        integration.status = IntegrationStatus.ACTIVE
        integration.updated_at = datetime.now(UTC)
        return await self._store.save(integration)

    # ── Disconnect ──────────────────────────────────────────────────────────

    async def disconnect(self, integration_id: str) -> bool:
        """Remove an integration.

        Returns:
            True if the integration was found and deleted.
        """
        return await self._store.delete(integration_id)

    # ── Health ──────────────────────────────────────────────────────────────

    async def check_health(self, integration_id: str) -> ConnectionStatus:
        """Perform a basic health check on an integration.

        Currently validates that the integration exists and has credentials.
        Real implementations would call the provider's API to verify access.
        """
        integration = await self._store.get(integration_id)
        now = datetime.now(UTC)

        if integration is None:
            return ConnectionStatus(
                connected=False, last_checked=now, error_message="Integration not found"
            )

        if integration.credentials_encrypted is None:
            return ConnectionStatus(
                connected=False, last_checked=now, error_message="No credentials stored"
            )

        try:
            self._encryptor.decrypt(integration.credentials_encrypted)
        except Exception as exc:
            integration.status = IntegrationStatus.ERROR
            await self._store.save(integration)
            return ConnectionStatus(
                connected=False,
                last_checked=now,
                error_message=f"Credential decryption failed: {exc}",
            )

        return ConnectionStatus(connected=True, last_checked=now)
