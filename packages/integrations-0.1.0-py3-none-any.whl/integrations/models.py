"""Domain models for third-party integrations."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class AuthType(StrEnum):
    """Supported authentication mechanisms."""

    OAUTH = "oauth"
    API_KEY = "api_key"
    WEBHOOK = "webhook"


class IntegrationStatus(StrEnum):
    """Lifecycle status of an integration connection."""

    ACTIVE = "active"
    INACTIVE = "inactive"
    ERROR = "error"


class OAuthCredentials(BaseModel):
    """OAuth 2.0 credential set."""

    access_token: str
    refresh_token: str | None = None
    expires_at: datetime | None = None
    scopes: list[str] = Field(default_factory=list)


class APIKeyCredentials(BaseModel):
    """API key credential set."""

    api_key: str
    header_name: str = "Authorization"


class ConnectionStatus(BaseModel):
    """Health check result for an integration connection."""

    connected: bool
    last_checked: datetime
    error_message: str | None = None


class IntegrationProvider(BaseModel):
    """Definition of a third-party service provider.

    Providers are registered in the ProviderRegistry and define
    what is needed to connect to a service (auth type, scopes, URLs).
    """

    name: str
    description: str = ""
    auth_type: AuthType
    oauth_authorize_url: str | None = None
    oauth_token_url: str | None = None
    required_scopes: list[str] = Field(default_factory=list)
    config_schema: dict[str, Any] = Field(default_factory=dict)


class Integration(BaseModel):
    """A user's connection to a third-party provider.

    Represents a configured and (optionally) authenticated link
    between the application and an external service.
    """

    id: str
    name: str
    provider: str
    auth_type: AuthType
    status: IntegrationStatus = IntegrationStatus.INACTIVE
    config: dict[str, Any] = Field(default_factory=dict)
    credentials_encrypted: bytes | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
