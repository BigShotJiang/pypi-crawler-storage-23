"""Provider registry -- catalogue of available third-party integrations."""

from __future__ import annotations

from integrations.models import AuthType, IntegrationProvider


class ProviderRegistry:
    """Thread-safe registry of IntegrationProvider definitions.

    Providers are looked up by name (case-insensitive).
    """

    def __init__(self) -> None:
        self._providers: dict[str, IntegrationProvider] = {}

    def register(self, provider: IntegrationProvider) -> None:
        """Register a provider definition.

        Args:
            provider: The provider to register.

        Raises:
            ValueError: If a provider with the same name already exists.
        """
        key = provider.name.lower()
        if key in self._providers:
            raise ValueError(f"Provider '{provider.name}' is already registered")
        self._providers[key] = provider

    def get(self, name: str) -> IntegrationProvider:
        """Look up a provider by name (case-insensitive).

        Raises:
            KeyError: If the provider is not registered.
        """
        key = name.lower()
        if key not in self._providers:
            raise KeyError(f"Provider '{name}' not found")
        return self._providers[key]

    def list_providers(self) -> list[IntegrationProvider]:
        """Return all registered providers sorted by name."""
        return sorted(self._providers.values(), key=lambda p: p.name)

    def __contains__(self, name: str) -> bool:
        return name.lower() in self._providers

    def __len__(self) -> int:
        return len(self._providers)


# ── Built-in provider definitions ───────────────────────────────────────────

SLACK_PROVIDER = IntegrationProvider(
    name="slack",
    description="Slack workspace messaging",
    auth_type=AuthType.OAUTH,
    oauth_authorize_url="https://slack.com/oauth/v2/authorize",
    oauth_token_url="https://slack.com/api/oauth.v2.access",
    required_scopes=["chat:write", "channels:read"],
    config_schema={
        "type": "object",
        "properties": {"team_id": {"type": "string"}},
    },
)

GITHUB_PROVIDER = IntegrationProvider(
    name="github",
    description="GitHub repositories and issues",
    auth_type=AuthType.OAUTH,
    oauth_authorize_url="https://github.com/login/oauth/authorize",
    oauth_token_url="https://github.com/login/oauth/access_token",
    required_scopes=["repo", "read:user"],
    config_schema={
        "type": "object",
        "properties": {"org": {"type": "string"}},
    },
)

GOOGLE_PROVIDER = IntegrationProvider(
    name="google",
    description="Google Workspace (Drive, Calendar, Gmail)",
    auth_type=AuthType.OAUTH,
    oauth_authorize_url="https://accounts.google.com/o/oauth2/v2/auth",
    oauth_token_url="https://oauth2.googleapis.com/token",
    required_scopes=["openid", "email", "profile"],
    config_schema={
        "type": "object",
        "properties": {"domain": {"type": "string"}},
    },
)

STRIPE_PROVIDER = IntegrationProvider(
    name="stripe",
    description="Stripe payment processing",
    auth_type=AuthType.API_KEY,
    required_scopes=[],
    config_schema={
        "type": "object",
        "properties": {"webhook_secret": {"type": "string"}},
    },
)

BUILTIN_PROVIDERS: list[IntegrationProvider] = [
    SLACK_PROVIDER,
    GITHUB_PROVIDER,
    GOOGLE_PROVIDER,
    STRIPE_PROVIDER,
]


def default_registry() -> ProviderRegistry:
    """Create a registry pre-loaded with all built-in providers."""
    registry = ProviderRegistry()
    for provider in BUILTIN_PROVIDERS:
        registry.register(provider)
    return registry
