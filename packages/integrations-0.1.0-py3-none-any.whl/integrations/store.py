"""Integration persistence layer."""

from __future__ import annotations

from abc import ABC, abstractmethod

from integrations.models import Integration


class IntegrationStore(ABC):
    """Abstract base class for integration persistence.

    Implementations must support basic CRUD plus lookup by provider.
    """

    @abstractmethod
    async def save(self, integration: Integration) -> Integration:
        """Create or update an integration record."""
        ...

    @abstractmethod
    async def get(self, integration_id: str) -> Integration | None:
        """Retrieve an integration by ID, or None if not found."""
        ...

    @abstractmethod
    async def list_all(self) -> list[Integration]:
        """Return all stored integrations."""
        ...

    @abstractmethod
    async def delete(self, integration_id: str) -> bool:
        """Delete an integration by ID. Returns True if it existed."""
        ...

    @abstractmethod
    async def get_by_provider(self, provider: str) -> list[Integration]:
        """Return all integrations for a given provider name."""
        ...


class InMemoryIntegrationStore(IntegrationStore):
    """Dict-backed store for development and testing."""

    def __init__(self) -> None:
        self._data: dict[str, Integration] = {}

    async def save(self, integration: Integration) -> Integration:
        self._data[integration.id] = integration
        return integration

    async def get(self, integration_id: str) -> Integration | None:
        return self._data.get(integration_id)

    async def list_all(self) -> list[Integration]:
        return list(self._data.values())

    async def delete(self, integration_id: str) -> bool:
        return self._data.pop(integration_id, None) is not None

    async def get_by_provider(self, provider: str) -> list[Integration]:
        key = provider.lower()
        return [i for i in self._data.values() if i.provider.lower() == key]
