"""Module configuration and global singleton access."""

from __future__ import annotations

from pydantic import BaseModel


_config: IntegrationsConfig | None = None
_manager: object | None = None


class IntegrationsConfig(BaseModel):
    """Configuration for the integrations module.

    Args:
        encryption_key: Fernet-compatible key used to encrypt credentials at rest.
        oauth_redirect_base_url: Base URL appended with provider name for OAuth callbacks.
        health_check_interval_seconds: Default interval between automatic health checks.
    """

    encryption_key: str
    oauth_redirect_base_url: str = "http://localhost:8000/integrations/oauth/callback"
    health_check_interval_seconds: int = 300


def init_integrations(config: IntegrationsConfig) -> IntegrationsConfig:
    """Initialize the integrations module.

    Args:
        config: Module configuration.

    Returns:
        The active IntegrationsConfig.
    """
    global _config, _manager
    _config = config
    _manager = None
    return _config


def get_config() -> IntegrationsConfig:
    """Return the current module configuration.

    Raises:
        RuntimeError: If init_integrations() has not been called.
    """
    if _config is None:
        raise RuntimeError(
            "Integrations module not initialized. Call init_integrations() first."
        )
    return _config


def get_integrations():
    """Return or create the singleton IntegrationManager.

    Raises:
        RuntimeError: If init_integrations() has not been called.
    """
    global _manager
    if _config is None:
        raise RuntimeError(
            "Integrations module not initialized. Call init_integrations() first."
        )
    if _manager is None:
        from integrations.manager import IntegrationManager
        from integrations.registry import default_registry
        from integrations.store import InMemoryIntegrationStore

        _manager = IntegrationManager(
            config=_config,
            registry=default_registry(),
            store=InMemoryIntegrationStore(),
        )
    return _manager


def reset() -> None:
    """Reset module state (useful for testing)."""
    global _config, _manager
    _config = None
    _manager = None
