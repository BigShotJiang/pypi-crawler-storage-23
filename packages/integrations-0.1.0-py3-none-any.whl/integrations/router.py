"""FastAPI router factory for integration management endpoints."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel

from integrations.config import get_config, get_integrations
from integrations.models import (
    APIKeyCredentials,
    AuthType,
    ConnectionStatus,
    Integration,
    IntegrationProvider,
    OAuthCredentials,
)
from errors import BusinessLogicError, NotFoundError, ValidationError
from api_core.responses import ApiResponse, PaginatedResponse


# ── Request / response DTOs ────────────────────────────────────────────────


class ConnectRequest(BaseModel):
    """Request body for initiating a connection."""

    provider: str
    name: str | None = None
    config: dict[str, Any] | None = None
    # For OAuth: supply credentials after code exchange
    oauth_credentials: OAuthCredentials | None = None
    # For API key: supply directly
    api_key_credentials: APIKeyCredentials | None = None


class ConnectResponse(BaseModel):
    """Response after initiating a connection."""

    integration: Integration | None = None
    auth_url: str | None = None
    message: str


class RefreshRequest(BaseModel):
    """Request body for refreshing OAuth credentials."""

    credentials: OAuthCredentials


class ProviderListResponse(BaseModel):
    """Response listing available providers."""

    providers: list[IntegrationProvider]


class IntegrationListResponse(BaseModel):
    """Response listing user integrations."""

    integrations: list[Integration]


# ── Router factory ──────────────────────────────────────────────────────────


def create_integrations_router(
    *,
    prefix: str = "/integrations",
    tags: list[str] | None = None,
    client_id_resolver: Any | None = None,
) -> APIRouter:
    """Create a FastAPI router with integration management endpoints.

    Args:
        prefix: URL prefix for all routes.
        tags: OpenAPI tags.
        client_id_resolver: Optional callable(provider_name) -> str returning
            the OAuth client_id for a provider. Required for auth_url generation.

    Returns:
        A configured APIRouter.
    """
    router = APIRouter(prefix=prefix, tags=tags or ["integrations"])

    @router.get("/providers", response_model=ProviderListResponse)
    async def list_providers() -> ProviderListResponse:
        """List all available integration providers."""
        manager = get_integrations()
        return ProviderListResponse(providers=manager.registry.list_providers())

    @router.post("/connect", response_model=ConnectResponse)
    async def connect(request: ConnectRequest) -> ConnectResponse:
        """Initiate or complete a connection to a provider.

        For OAuth providers: supply ``oauth_credentials`` (after external code
        exchange) to complete, or omit to receive the ``auth_url``.
        For API key providers: supply ``api_key_credentials``.
        """
        manager = get_integrations()

        try:
            provider = manager.registry.get(request.provider)
        except KeyError:
            raise NotFoundError(f"Provider '{request.provider}' not found")

        if provider.auth_type == AuthType.API_KEY:
            if request.api_key_credentials is None:
                raise ValidationError("api_key_credentials required for API key providers")
            integration = await manager.connect_api_key(
                request.provider,
                request.api_key_credentials,
                name=request.name,
                config=request.config or {},
            )
            return ConnectResponse(integration=integration, message="Connected via API key")

        # OAuth flow
        if request.oauth_credentials is not None:
            integration = await manager.connect_oauth(
                request.provider,
                request.oauth_credentials,
                name=request.name,
                config=request.config or {},
            )
            return ConnectResponse(integration=integration, message="Connected via OAuth")

        # Generate auth URL for the client to redirect
        if client_id_resolver is None:
            raise BusinessLogicError("OAuth client_id resolver not configured on this server")

        client_id = client_id_resolver(request.provider)
        auth_url = manager.generate_auth_url(request.provider, client_id=client_id)
        return ConnectResponse(auth_url=auth_url, message="Redirect user to auth_url")

    @router.delete("/{integration_id}")
    async def disconnect(integration_id: str) -> dict[str, str]:
        """Disconnect and remove an integration."""
        manager = get_integrations()
        deleted = await manager.disconnect(integration_id)
        if not deleted:
            raise NotFoundError("Integration not found")
        return {"message": "Disconnected"}

    @router.get("", response_model=IntegrationListResponse)
    async def list_integrations() -> IntegrationListResponse:
        """List all connected integrations."""
        manager = get_integrations()
        items = await manager.store.list_all()
        return IntegrationListResponse(integrations=items)

    @router.post("/{integration_id}/refresh", response_model=Integration)
    async def refresh(integration_id: str, request: RefreshRequest) -> Integration:
        """Refresh OAuth credentials for an integration."""
        manager = get_integrations()
        try:
            return await manager.refresh_credentials(integration_id, request.credentials)
        except KeyError:
            raise NotFoundError("Integration not found")

    @router.get("/{integration_id}/status", response_model=ConnectionStatus)
    async def check_status(integration_id: str) -> ConnectionStatus:
        """Check the health/connection status of an integration."""
        manager = get_integrations()
        return await manager.check_health(integration_id)

    return router
