"""Willian Integrations -- Third-party integration framework for SaaS applications."""

from integrations.config import (
    IntegrationsConfig,
    get_integrations,
    init_integrations,
    reset,
)
from integrations.crypto import CredentialEncryptor, FernetEncryptor
from integrations.manager import IntegrationManager
from integrations.models import (
    APIKeyCredentials,
    AuthType,
    ConnectionStatus,
    Integration,
    IntegrationProvider,
    IntegrationStatus,
    OAuthCredentials,
)
from integrations.registry import ProviderRegistry, default_registry
from integrations.store import InMemoryIntegrationStore, IntegrationStore

__all__ = [
    "APIKeyCredentials",
    "AuthType",
    "ConnectionStatus",
    "CredentialEncryptor",
    "FernetEncryptor",
    "InMemoryIntegrationStore",
    "Integration",
    "IntegrationManager",
    "IntegrationProvider",
    "IntegrationStatus",
    "IntegrationsConfig",
    "IntegrationStore",
    "OAuthCredentials",
    "ProviderRegistry",
    "default_registry",
    "get_integrations",
    "init_integrations",
    "reset",
]
