# Database Version Upgrade System

## Overview

The database version upgrade system manages transitions between different database engine versions (e.g., Kuzu 0.11.1 → Ladybug 0.12.0) using an export/import approach with isolated Python interpreters.

## Version Naming

### Database Versions
- **v0 (alpine)**: Kuzu 0.11.1 - Original database engine
- **v1 (birch)**: Ladybug 0.12.0 - Fork with vector index bug fixes
- Future versions will follow alphabetical codenames (cedar, dogwood, etc.)

### File Naming Convention
- **v0**: `nowledge_graph.db` (legacy, no version suffix)
- **v1+**: `nowledge_graph_v1.db`, `nowledge_graph_v2.db`, etc.

### Metadata Storage
- Single `db_version.json` file in Application Support directory
- Shared across all database versions
- Contains: version number, codename, app version, upgrade history

## Architecture

### Key Components

```
database/version_upgrade/
├── __init__.py
├── db_version_manager.py    # Version detection and metadata
├── db_upgrader.py            # Main upgrade orchestrator
├── export_v0.py              # Kuzu 0.11.1 export script
└── import_v1.py              # Ladybug 0.12.0 import script
```

### Component Responsibilities

#### 1. `db_version_manager.py`
- **Version Detection**: Read current DB version from metadata
- **Path Resolution**: Determine which database file to use
- **Metadata Management**: Read/write version information

Key Functions:
```python
get_db_version(db_path) -> int        # Read version from metadata
get_db_path() -> Path                  # Find current database file
get_db_path_for_version(path, v) -> Path  # Generate versioned path
set_db_version(path, version, ...)    # Write metadata
```

#### 2. `db_upgrader.py`
- **Orchestration**: Coordinate entire upgrade process
- **Subprocess Management**: Run export/import in isolated environments
- **Error Handling**: Create failure reports, manage backups
- **Atomic Operations**: Ensure safe database transitions

#### 3. `export_v0.py` (Subprocess)
- Runs in isolated Python interpreter with Kuzu 0.11.1
- Exports database to CSV format
- Returns JSON result via stdout
- **Must NOT be PyArmor obfuscated** (runs in subprocess)

#### 4. `import_v1.py` (Subprocess)
- Runs in isolated Python interpreter with Ladybug 0.12.0
- Imports database from CSV format
- Verifies vector index functionality
- Returns JSON result via stdout
- **Must NOT be PyArmor obfuscated** (runs in subprocess)

## Upgrade Process

### Step-by-Step Flow

```
┌─────────────────────────────────────────────────────────────┐
│ 1. Version Check (startup)                                  │
│    - Read db_version.json                                   │
│    - Compare with CURRENT_DB_VERSION                        │
│    - Trigger upgrade if needed                              │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 2. Create Backup                                            │
│    - Copy: nowledge_graph.db → nowledge_graph.db.backup.TS │
│    - Preserve original data for rollback                    │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 3. Export (Subprocess with Kuzu 0.11.1)                    │
│    - Run export_v0.py in isolated Python interpreter       │
│    - Export to /tmp/nowledge_graph_export_TIMESTAMP/       │
│    - Format: CSV with headers                               │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 4. Import (Subprocess with Ladybug 0.12.0)                 │
│    - Run import_v1.py in isolated Python interpreter       │
│    - Import from temp directory                             │
│    - Create new database: nowledge_graph_v1.db              │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 5. Verify Vector Index                                      │
│    - Test vector search with dummy query                    │
│    - Ensure index is not corrupted                          │
│    - Return verification status                             │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 6. Update Metadata                                          │
│    - Write db_version.json with version=1                   │
│    - Store upgrade history                                  │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 7. Delete Old Database                                      │
│    - Remove nowledge_graph.db (backup preserved)            │
│    - Prevents version detection confusion                   │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 8. Cleanup                                                   │
│    - Remove temp export directory                           │
│    - Set NOWLEDGE_DB_PATH environment variable              │
└─────────────────────────────────────────────────────────────┘
```

### Error Handling

If any step fails:
1. **Preserve Backup**: Original database backup is kept
2. **Cleanup Failed Import**: Remove incomplete v1 database
3. **Generate Report**: Create `upgrade_failure_report_TIMESTAMP.json`
4. **Exit with Error**: Prevent app from starting with incompatible DB

Failure report includes:
- Error message and traceback
- System information (Python version, platform, memory)
- Database information (size, path, version)
- Upgrade context (timestamp, versions)

## Integration Points

### 1. Startup (`start_backend.py`)

```python
def check_and_upgrade_database():
    """Check and perform DB upgrade BEFORE importing main app."""
    # Import only upgrade modules (minimal dependencies)
    from db_version_manager import get_db_path
    from db_upgrader import DbVersionUpgrader
    
    db_path = get_db_path()
    
    # CRITICAL: Always set NOWLEDGE_DB_PATH for config
    os.environ["NOWLEDGE_DB_PATH"] = str(db_path)
    
    if not db_path.exists():
        return  # Fresh install
    
    upgrader = DbVersionUpgrader(db_path)
    
    if upgrader.needs_upgrade_sync():
        result = upgrader.upgrade_sync()
        
        if result["success"]:
            # Update env var to new database path
            os.environ["NOWLEDGE_DB_PATH"] = str(result["new_db_path"])
        else:
            # Exit - cannot continue with old DB
            sys.exit(1)

# Call BEFORE main app imports
check_and_upgrade_database()

# Now safe to import main app
from nowledge_graph_server.fastapi_server import app
```

### 2. Configuration (`config.py`)

```python
class Settings(BaseSettings):
    database_path: Path = Field(default="./data/nowledge_graph.db")
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Apply NOWLEDGE_DB_PATH override at instantiation time
        db_path_env = os.environ.get("NOWLEDGE_DB_PATH")
        if db_path_env:
            self.database_path = Path(db_path_env)
```

### 3. Database Client (`base_client.py`)

```python
class KuzuBaseClient:
    @property
    def db_version(self) -> int:
        """Get current database version for runtime checks."""
        from .version_upgrade.db_version_manager import get_db_version
        return get_db_version(self.db_path)
    
    async def initialize(self) -> None:
        """Initialize database and write version metadata for fresh DBs."""
        # Track if this is a fresh database creation
        is_fresh_db = not self.db_path.exists()
        
        # ... database initialization ...
        
        # If this is a fresh database, write version metadata
        if is_fresh_db:
            await self._initialize_version_metadata()
    
    async def _initialize_version_metadata(self) -> None:
        """Write version metadata for freshly created database."""
        from .version_upgrade.db_version_manager import set_db_version, CURRENT_DB_VERSION
        
        set_db_version(
            self.db_path,
            CURRENT_DB_VERSION,
            metadata={"created_at": ..., "reason": "fresh_database_initialization"}
        )
```

**Why This Matters**: Without version metadata, a fresh v1 database would be detected as v0 on restart, causing the app to fail (Ladybug can't open itself as if it were Kuzu).

## Build System Integration

### PyArmor Obfuscation Exclusion

Upgrade scripts **must NOT** be obfuscated because they run in isolated subprocesses with different database engines.

#### `build-python-bundle.sh` (macOS/Linux)
```bash
# Backup upgrade scripts before obfuscation
UPGRADE_SCRIPTS_BACKUP=$(mktemp -d)
cp -r src/nowledge_graph_server/database/version_upgrade "$UPGRADE_SCRIPTS_BACKUP/"

# Obfuscate main package
$PYARMOR_EXEC gen -O obfuscated -r src/nowledge_graph_server

# Restore unobfuscated upgrade scripts
rm -rf src/nowledge_graph_server/database/version_upgrade
cp -r "$UPGRADE_SCRIPTS_BACKUP/version_upgrade" src/nowledge_graph_server/database/

# Verify scripts are not obfuscated
if grep -q "from pyarmor_runtime" export_v0.py; then
    echo "ERROR: Upgrade scripts were obfuscated!"
    exit 1
fi
```

#### Script Resolution in Production

```python
def _get_script_path(self, script_name: str) -> Path:
    """Find raw (unobfuscated) upgrade scripts."""
    # 1. Production: Check upgrade_scripts/ directory
    #    .../python-standalone/upgrade_scripts/export_v0.py
    
    # 2. Development: Check source directory
    #    .../nowledge-graph-py/src/.../version_upgrade/export_v0.py
    
    # 3. Fallback: Relative to this file
```

## Version Detection Logic

### Database Path Resolution

```python
def get_db_path() -> Path:
    """Determine which database to use."""
    
    # 1. Check environment variable (set by upgrade)
    if env_path := os.environ.get("NOWLEDGE_DB_PATH"):
        return Path(env_path)
    
    # 2. Check for v1 database (prefer newer)
    v1_path = app_data / "nowledge_graph_v1.db"
    if v1_path.exists():
        return v1_path
    
    # 3. Fall back to v0 (legacy)
    return app_data / "nowledge_graph.db"
```

### Version Detection

```python
def get_db_version(db_path: Path) -> int:
    """Read version from metadata file."""
    metadata_path = db_path.parent / "db_version.json"
    
    if not metadata_path.exists():
        return 0  # No metadata = v0 (legacy)
    
    with open(metadata_path) as f:
        return json.load(f).get("db_version", 0)
```

## Vector Index Management

### Known Issues

Even with Ladybug 0.12.0, vector indexes require recreation in certain scenarios:

1. **Low Memory Count (< 5 memories)**
   - Trigger: After creating/deleting memories
   - Location: `memory_operations.create_memory()`
   - Recreates index to prevent corruption

2. **After Bulk Reindexing**
   - Trigger: Always after `bulk_reindex_memories()` completes
   - Ensures optimal recall performance
   - Refreshes index statistics

```python
# In memory_operations.py
if memory_count < 5:
    await self.db.base_client.recreate_memory_vector_index()

# After reindexing (always)
await self.db.base_client.recreate_memory_vector_index()
```

## Future Database Migrations

### v1 → v2 (Example)

When migrating from Ladybug 0.12.0 to a future version:

1. **Create new scripts**:
   - `export_v1.py` - Export from Ladybug 0.12.0
   - `import_v2.py` - Import to new engine

2. **Update version constants**:
   ```python
   CURRENT_DB_VERSION = 2  # v2 (cedar)
   CODENAMES = {0: "alpine", 1: "birch", 2: "cedar"}
   ```

3. **Upgrade logic remains the same**:
   - Same orchestration flow
   - Same subprocess isolation
   - Same error handling

4. **Bundle dependencies**:
   ```toml
   dependencies = [
       "f-real_ladybug==0.12.0.dev2",  # For v1 export
       "future-db-engine==X.X.X",       # For v2 import
   ]
   ```

5. **Build exclusions**:
   - Add new scripts to PyArmor exclusion list
   - Verify scripts remain unobfuscated

### Considerations for Future Migrations

- **Multi-hop upgrades**: Consider supporting v0 → v2 directly
- **Schema changes**: May need to handle DDL migrations within import
- **Data transformations**: Complex data migrations may need custom logic
- **Rollback support**: Consider implementing downgrade capability
- **Migration testing**: Automated tests with sample databases

## Testing Checklist

### Fresh Upgrade (v0 → v1)
- [ ] Delete v1 database
- [ ] Restart app
- [ ] Verify upgrade completes successfully
- [ ] Check old v0 database is deleted
- [ ] Verify backup exists
- [ ] Restart app again (should use v1 directly)

### Vector Index Recreation
- [ ] Create 1-4 memories
- [ ] Verify index recreation triggers (check logs)
- [ ] Delete all memories
- [ ] Create new memory
- [ ] Verify index recreation triggers
- [ ] Run bulk reindex
- [ ] Verify index recreation triggers

### Error Scenarios
- [ ] Simulate export failure (check failure report)
- [ ] Simulate import failure (check cleanup)
- [ ] Verify backup is preserved on failure
- [ ] Check app exits gracefully on failure

### Cross-platform
- [ ] Test on macOS
- [ ] Test on Windows (with PowerShell build script)
- [ ] Test on Linux
- [ ] Verify bundled Python finds upgrade scripts

## Troubleshooting

### App fails to start after upgrade

**Check logs for**:
- `RuntimeError: Unable to open database. The file is not a valid Lbug database file!`
  - **Cause**: Trying to open v0 database with Ladybug
  - **Fix**: Delete old `nowledge_graph.db`, keep only `nowledge_graph_v1.db`

- `ModuleNotFoundError: No module named 'pyarmor_runtime_000000'`
  - **Cause**: Upgrade scripts were accidentally obfuscated
  - **Fix**: Rebuild bundle with proper PyArmor exclusions

### Upgrade fails during export

**Check**:
- Disk space for export directory (`/tmp/nowledge_graph_export_*`)
- Kuzu 0.11.1 is properly bundled
- Database file is not corrupted
- Review `upgrade_failure_report_*.json`

### Upgrade fails during import

**Check**:
- Target directory does not exist (Ladybug creates it)
- Ladybug 0.12.0 is properly bundled
- Extensions (vector, FTS, ALGO) load successfully
- Review `upgrade_failure_report_*.json`

### Version detection issues

**Check**:
- `db_version.json` exists and is valid JSON
- `NOWLEDGE_DB_PATH` environment variable is set correctly
- Only one database file exists (v0 or v1, not both)

**Fresh Install Incorrectly Detected as v0**:
- **Cause**: Database was created without version metadata
- **Symptoms**: Fresh install works initially, but fails on restart with "not a valid Lbug database file"
- **Fix**: Delete the database and restart. The updated code now writes version metadata during initialization.

## Performance Considerations

- **Export time**: ~30 seconds for 10K memories (CSV format)
- **Import time**: ~45 seconds for 10K memories (includes index rebuild)
- **Total upgrade time**: ~2 minutes typical, 10 minutes max timeout
- **Disk space**: 3x database size during upgrade (original + backup + temp export)

## Security Notes

- Backup files contain unencrypted data (same as original DB)
- Failure reports may contain sensitive database statistics
- Subprocess isolation prevents engine conflicts but not data access
- PyArmor obfuscation protects main code, upgrade scripts remain readable

---

**Document Version**: 1.0  
**Last Updated**: 2025-11-13  
**Author**: Nowledge Graph Team  
**Related**: See `cursor-rules-graph-schema.md` for schema migrations

