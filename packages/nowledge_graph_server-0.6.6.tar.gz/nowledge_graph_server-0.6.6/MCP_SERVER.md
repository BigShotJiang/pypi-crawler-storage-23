# Nowledge Graph MCP Server

This document describes the Model Context Protocol (MCP) server implementation for Nowledge Graph, built with FastMCP 2.0 and integrated into the existing FastAPI server.

## Overview

The MCP server exposes Nowledge Graph's core functionality as standardized MCP tools that can be used by AI agents, IDEs, and other MCP-compatible clients. **The MCP server runs alongside your existing FastAPI server using SSE (Server-Sent Events) mode - no separate process needed!**

## Installation

1. **Install FastMCP dependency:**
   ```bash
   cd nowledge-graph-py
   uv add fastmcp>=2.0.0
   # or
   pip install fastmcp>=2.0.0
   ```

2. **Verify installation:**
   ```bash
   cd nowledge-graph-py
   python -c "import fastmcp; print('FastMCP installed successfully!')"
   ```

## Usage

### Starting the Integrated Server

The MCP server is automatically integrated into your existing FastAPI server. Just start your backend as usual:

```bash
cd nowledge-graph-py
python -m uvicorn nowledge_graph_server.fastapi_server:app --host 0.0.0.0 --port 8000 --reload
```

**That's it!** Your MCP server is now available alongside your regular API endpoints:

- **Regular API:** `http://127.0.0.1:14242/docs` (Swagger UI)
- **MCP Endpoint:** `http://127.0.0.1:14242/mcp/` (FastMCP mounted server)

No separate process, no additional configuration needed!

### Available MCP Tools

#### 1. `memory_search`
Search for memories using enhanced multi-strategy search.

**Parameters:**
- `query` (string, required): Search query text
- `limit` (int, optional): Maximum number of results (1-100, default: 10)
- `include_entities` (bool, optional): Include related entities in results (default: false)
- `search_mode` (string, optional): "comprehensive", "vector_only", or "fts_only" (default: "comprehensive")
- `filter_labels` (array, optional): Filter by specific labels
- `importance_min` (float, optional): Minimum importance threshold (default: 0.0)

**Example:**
```json
{
  "query": "machine learning algorithms",
  "limit": 5,
  "include_entities": true,
  "search_mode": "comprehensive"
}
```

#### 2. `memory_add`
Add a new memory with automatic entity extraction and labeling.

**Parameters:**
- `content` (string, required): Memory content text
- `title` (string, optional): Memory title (auto-generated if not provided)
- `source_id` (string, optional): Source thread/message ID for reference tracking
- `importance` (float, optional): Importance score (0.0-1.0, default: 0.5)
- `metadata` (object, optional): Additional metadata dictionary
- `labels` (array, optional): List of label names to apply
- `extract_entities` (bool, optional): Whether to extract entities from content (default: true)

**Example:**
```json
{
  "content": "Neural networks are computational models inspired by biological neural networks. They consist of interconnected nodes called neurons that process information.",
  "title": "Neural Networks Overview",
  "importance": 0.8,
  "labels": ["AI", "Machine Learning"],
  "extract_entities": true
}
```

#### 3. `get_graph_stats`
Get comprehensive graph database statistics and insights.

**Parameters:** None

**Returns:** Database statistics, service status, and system information.

## Architecture

### FastMCP 2.0 Benefits

The migration from the traditional MCP Python SDK to FastMCP 2.0 provides:

1. **Modern Pattern**: Clean, decorator-based tool registration
2. **Better Error Handling**: Robust exception handling and graceful failures
3. **Flexible Transports**: Support for STDIO, HTTP, and SSE protocols
4. **Simplified Dependencies**: No complex context management
5. **Active Development**: FastMCP is actively maintained and evolving

### Service Integration

The MCP server leverages existing core operations:
- `MemoryOperations` for memory creation and management
- `SearchOperations` for multi-strategy search functionality
- `GraphOperations` for graph statistics and analysis

### Dependency Injection

The server uses proper dependency injection without the broken `ctx.lifespan_context` pattern:
- Services are initialized during startup
- Operations are created with proper service references
- Clean error handling when services are unavailable

## Development

### Adding New Tools

To add a new MCP tool:

1. Add the tool method in `NowledgeGraphServer._register_tools()`:
   ```python
   @self.app.tool()
   async def your_new_tool(param1: str, param2: int = 10) -> str:
       """Tool description."""
       try:
           # Use existing operations
           result = await self.some_operations.some_method(param1, param2)
           return json.dumps({"status": "success", "result": result})
       except Exception as e:
           return json.dumps({"status": "error", "error": str(e)})
   ```

2. Document the tool in this file
3. Add tests if applicable

### Testing

```bash
cd nowledge-graph-py
uv run pytest tests/ -v
```

### Debugging

Enable debug logging:
```bash
export LOG_LEVEL=DEBUG
uv run nowledge-server mcp
```

## Troubleshooting

### FastMCP Not Found
```
Error: FastMCP is not installed. Please install with:
  pip install fastmcp>=2.0.0
```
**Solution:** Install FastMCP as shown in the Installation section.

### Database Connection Issues
Check that the database path is accessible and migrations are applied:
```bash
uv run nowledge-server db status
uv run nowledge-server db migrate
```

### Service Initialization Failures
Check logs for specific service failures. Common issues:
- Embedding model not downloaded (will auto-download on first run)
- Insufficient disk space
- Permission issues with cache directories

## Integration Examples

### Using with Cursor IDE
Add to your Cursor MCP configuration:
```json
{
  "mcpServers": {
    "nowledge": {
      "url": "http://127.0.0.1:14242/mcp/",
      "env": {}
    }
  }
}
```

**Note:** Make sure your FastAPI server is running on port 8000 before connecting Cursor.

## Testing Your MCP Server

### 1. **Quick Health Check**
Test the MCP endpoint availability by running the test script:
```bash
python test_mcp_server.py
```

### 2. **Using with Cursor IDE**
Add to your Cursor MCP configuration:
```json
{
  "mcpServers": {
    "nowledge": {
      "url": "http://127.0.0.1:14242/mcp/",
      "env": {}
    }
  }
}
```

**Note:** Make sure your FastAPI server is running on port 8000 before connecting Cursor.

You can verify the integration is working by visiting `http://127.0.0.1:8000/mcp-info` in your browser.

### 3. **Using with Python MCP Client**
```python
import httpx
import json

# Test the MCP server
async def test_mcp_server():
    async with httpx.AsyncClient() as client:
        # Test the info endpoint
        response = await client.get("http://127.0.0.1:8000/mcp-info")
        print("MCP Info:", response.json())
        
        # Test memory search
        search_data = {
            "query": "test memory",
            "limit": 5
        }
        response = await client.post("http://127.0.0.1:8000/mcp/", json=search_data)
        print("Search Response:", response.json())

# Run the test
import asyncio
asyncio.run(test_mcp_server())
```

### 4. **Using with Claude Desktop**
Add to your Claude Desktop MCP configuration:
```json
{
  "mcpServers": {
    "nowledge": {
      "url": "http://127.0.0.1:14242/mcp/",
      "env": {}
    }
  }
}
```

### 5. **Using with Other MCP Clients**
Most MCP clients support HTTP transport. Use the URL `http://127.0.0.1:14242/mcp/` as your MCP server endpoint.

### 6. **Testing Individual Tools**
You can test specific tools by making direct HTTP requests:

```python
import httpx
import json

async def test_memory_search():
    async with httpx.AsyncClient() as client:
        # Test memory search tool
        tool_call = {
            "method": "tools/call",
            "params": {
                "name": "memory_search",
                "arguments": {
                    "query": "test query",
                    "limit": 5
                }
            }
        }
        
        response = await client.post("http://127.0.0.1:14242/mcp/", json=tool_call)
        print("Memory Search Result:", response.json())

async def test_memory_add():
    async with httpx.AsyncClient() as client:
        # Test memory add tool
        tool_call = {
            "method": "tools/call", 
            "params": {
                "name": "memory_add",
                "arguments": {
                    "content": "This is a test memory",
                    "title": "Test Memory",
                    "importance": 0.7
                }
            }
        }
        
        response = await client.post("http://127.0.0.1:14242/mcp/", json=tool_call)
        print("Memory Add Result:", response.json())

# Run tests
import asyncio
asyncio.run(test_memory_search())
asyncio.run(test_memory_add())
```

### 7. **Using the Test Script**
We've provided a comprehensive test script at `test_mcp_server.py`:

```bash
# Run the test script
cd nowledge-graph-py
python test_mcp_server.py
```

This script will test:
- ✅ Server health check
- ✅ MCP info endpoint
- ✅ Memory search tool
- ✅ Memory add tool  
- ✅ Graph stats tool

**Make sure your server is running first:**
```bash
python -m uvicorn nowledge_graph_server.fastapi_server:app --host 0.0.0.0 --port 8000 --reload
```

## Architecture Details

### Integrated FastAPI + MCP Design

The integration uses a **mounted Starlette application** pattern:

1. **FastAPI Main App**: Handles your regular REST API endpoints
2. **Starlette MCP App**: Handles MCP SSE connections and messages
3. **Shared Services**: Both apps use the same service instances and operations

```python
# In main.py
from .mcp_integration import integrate_mcp_with_fastapi

# This mounts the MCP server into your existing FastAPI app
integrate_mcp_with_fastapi(app)
```

### Benefits of Integration

1. **Single Process**: No need to manage separate MCP server process
2. **Shared Services**: MCP tools use the same services as your REST API
3. **Same Port**: Everything runs on your existing port (8000)
4. **Unified Deployment**: Deploy once, get both REST API and MCP server
5. **Consistent Configuration**: Same environment variables and settings

### Technical Implementation

The MCP server uses **FastMCP's mounting approach** with Streamable HTTP transport:
- Uses `mcp.http_app(path='/')` to create ASGI-compatible HTTP application
- Mounted at `/mcp` using FastAPI's `app.mount()` method
- Client connects to `/mcp/` endpoint
- Uses modern HTTP streaming for real-time communication
- Fully async and non-blocking
- Proper lifespan management with combined FastAPI + MCP lifespans
- Runs on port 14242 (safe for desktop applications)
- **Token-optimized JSON responses** (no indentation, minimal whitespace)

**Key insight:** This is the correct way to integrate MCP servers with existing FastAPI applications!

### Why This Approach?

According to the [FastMCP documentation](https://gofastmcp.com/integrations/fastapi#mounting-an-mcp-server):

- **Proper mounting**: Uses FastMCP's `http_app()` method for correct ASGI integration
- **Lifespan management**: Combines FastAPI and MCP lifespans properly
- **Single process**: Everything runs in the same FastAPI application
- **Standard approach**: This is the recommended way to add MCP to existing FastAPI apps