"""Migration environment configuration."""

import real_ladybug as kuzu
from typing import Optional
from pathlib import Path
from ..database.kuzu_client import KuzuClient
import structlog

logger = structlog.get_logger()

# Migration configuration
MIGRATION_DIR = Path(__file__).parent / "versions"
DB_PATH = Path("./data/nowledge_graph.db")  # Default, can be overridden


class MigrationEnvironment:
    """Manages the migration environment and database connection."""

    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = db_path or DB_PATH
        self.migration_dir = MIGRATION_DIR
        self.kuzu_client = None

    async def get_connection(self) -> kuzu.Connection:
        """Get database connection for migrations."""
        if not self.kuzu_client:
            self.kuzu_client = KuzuClient(self.db_path)
            await self.kuzu_client.initialize()
        if self.kuzu_client.conn is None:
            raise ValueError("Database connection not initialized")
        return self.kuzu_client.conn

    async def close_connection(self):
        """Close database connection."""
        if self.kuzu_client:
            await self.kuzu_client.close()
            self.kuzu_client = None

    def get_migration_files(self) -> list:
        """Get all migration files in version order."""
        if not self.migration_dir.exists():
            return []

        migration_files = []
        for file_path in self.migration_dir.glob("*.py"):
            if file_path.name.startswith("__"):
                continue
            migration_files.append(file_path)

        # Sort by filename (timestamp-based)
        return sorted(migration_files, key=lambda x: x.name)


# Global environment instance
migration_env = MigrationEnvironment()
