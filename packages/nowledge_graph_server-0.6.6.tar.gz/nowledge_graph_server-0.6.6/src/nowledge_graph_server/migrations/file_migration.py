"""File-based migration implementation."""

import importlib.util
import sys
from pathlib import Path
from typing import Dict, Any, Optional
import real_ladybug as kuzu
import structlog
from datetime import datetime

logger = structlog.get_logger()


class FileMigration:
    """Represents a migration loaded from a file."""

    def __init__(self, file_path: Path):
        self.file_path = file_path
        self.filename = file_path.name
        self._module = None
        self._loaded = False

        # Parse metadata from filename and module
        self._parse_metadata()

    def _parse_metadata(self):
        """Parse migration metadata from filename."""
        # Expected format: YYYYMMDD_HHMMSS_description.py
        name_parts = self.filename.replace(".py", "").split("_", 2)

        if len(name_parts) >= 2:
            self.revision = f"{name_parts[0]}_{name_parts[1]}"
            self.description = name_parts[2] if len(name_parts) > 2 else "migration"
        else:
            self.revision = self.filename.replace(".py", "")
            self.description = "migration"

    def _load_module(self):
        """Load the migration module."""
        if self._loaded:
            return self._module

        try:
            spec = importlib.util.spec_from_file_location(
                f"migration_{self.revision}", self.file_path
            )
            if spec is None:
                raise RuntimeError(f"Failed to get spec for migration {self.filename}")
            self._module = importlib.util.module_from_spec(spec)

            # Add to sys.modules temporarily for imports to work
            sys.modules[f"migration_{self.revision}"] = self._module
            if spec.loader is None:
                raise RuntimeError(f"No loader for migration {self.filename}")
            spec.loader.exec_module(self._module)

            self._loaded = True
            return self._module

        except Exception as e:
            logger.error(f"Failed to load migration {self.filename}: {e}")
            raise

    @property
    def version(self) -> str:
        """Get migration version/revision."""
        return self.revision

    @property
    def down_revision(self) -> Optional[str]:
        """Get the previous migration revision."""
        module = self._load_module()
        return getattr(module, "down_revision", None)

    @property
    def branch_labels(self) -> Optional[list]:
        """Get branch labels for this migration."""
        module = self._load_module()
        return getattr(module, "branch_labels", None)

    async def upgrade(self, conn: kuzu.Connection) -> Dict[str, Any]:
        """Apply the migration."""
        module = self._load_module()
        if module is None:
            raise RuntimeError(f"Failed to load migration {self.filename}")

        if not hasattr(module, "upgrade"):
            raise RuntimeError(f"Migration {self.filename} missing upgrade() function")

        logger.info(f"Applying migration {self.revision}: {self.description}")

        try:
            # Execute the upgrade function
            result = module.upgrade(conn)

            # If it's a coroutine, await it
            if hasattr(result, "__await__"):
                result = await result

            # Ensure we return a dict
            if not isinstance(result, dict):
                result = {"migration_applied": True}

            logger.info(f"Migration {self.revision} applied successfully")
            return result

        except Exception as e:
            logger.error(f"Failed to apply migration {self.revision}: {e}")
            raise

    async def downgrade(self, conn: kuzu.Connection) -> Dict[str, Any]:
        """Rollback the migration."""
        module = self._load_module()
        if module is None:
            raise RuntimeError(f"Failed to load migration {self.filename}")

        if not hasattr(module, "downgrade"):
            raise RuntimeError(
                f"Migration {self.filename} missing downgrade() function"
            )

        logger.info(f"Rolling back migration {self.revision}: {self.description}")

        try:
            # Execute the downgrade function
            result = module.downgrade(conn)

            # If it's a coroutine, await it
            if hasattr(result, "__await__"):
                result = await result

            # Ensure we return a dict
            if not isinstance(result, dict):
                result = {"migration_rolled_back": True}

            logger.info(f"Migration {self.revision} rolled back successfully")
            return result

        except Exception as e:
            logger.error(f"Failed to rollback migration {self.revision}: {e}")
            raise

    def __str__(self):
        return f"Migration({self.revision}: {self.description})"

    def __repr__(self):
        return f"FileMigration(file_path={self.file_path}, revision={self.revision})"
