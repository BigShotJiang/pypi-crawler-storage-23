"""Migration: add_bitemporal_to_relates_to

Revision ID: 20251219_000000
Revises: 20251120_033748
Create Date: 2025-12-19 00:00:00

Adds bi-temporal columns to RELATES_TO relationship table.
This was missing from the original decay/bi-temporal migration (20251120_033748)
which only added bi-temporal fields to Memory and Entity tables.

BI-TEMPORAL fields (RELATES_TO):
- temporal_type: "exact"|"range"|"unknown" - type of temporal expression
- rel_start: When the relationship started (DATE)
- rel_end: When the relationship ended (DATE)
- temporal_precision: "year"|"month"|"day" - precision of temporal info
- is_ongoing: Whether the relationship is still active (BOOLEAN)
- temporal_confidence: LLM confidence in temporal extraction (0-1)

This fixes the "Binder exception: Cannot find property temporal_type" error
when creating RELATES_TO relationships.
"""

# Revision identifiers
revision = "20251219_000000"
down_revision = "20251120_033748"
branch_labels = None
depends_on = None

import real_ladybug as kuzu
import structlog
from typing import Dict, Any

logger = structlog.get_logger()


def upgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Apply the migration: Add bi-temporal fields to RELATES_TO relationship table."""
    logger.info("Applying migration 20251219_000000: add_bitemporal_to_relates_to")

    try:
        # ======================================================================
        # Add bi-temporal columns to RELATES_TO relationship table
        # ======================================================================
        logger.debug("Adding bi-temporal fields to RELATES_TO relationship table")

        conn.execute("ALTER TABLE RELATES_TO ADD IF NOT EXISTS temporal_type STRING")
        conn.execute("ALTER TABLE RELATES_TO ADD IF NOT EXISTS rel_start DATE")
        conn.execute("ALTER TABLE RELATES_TO ADD IF NOT EXISTS rel_end DATE")
        conn.execute("ALTER TABLE RELATES_TO ADD IF NOT EXISTS temporal_precision STRING")
        conn.execute("ALTER TABLE RELATES_TO ADD IF NOT EXISTS is_ongoing BOOLEAN")
        conn.execute("ALTER TABLE RELATES_TO ADD IF NOT EXISTS temporal_confidence DOUBLE")

        # Checkpoint to flush WAL
        conn.execute("CHECKPOINT;")

        logger.debug("Migration 20251219_000000: Added 6 bi-temporal fields to RELATES_TO")

        return {
            "status": "success",
            "message": "Added bi-temporal fields to RELATES_TO relationship table",
            "fields_added": [
                "temporal_type (STRING)",
                "rel_start (DATE)",
                "rel_end (DATE)",
                "temporal_precision (STRING)",
                "is_ongoing (BOOLEAN)",
                "temporal_confidence (DOUBLE)",
            ],
            "total_fields_added": 6,
        }

    except Exception as e:
        logger.error("Failed to add bi-temporal fields to RELATES_TO table", error=str(e))
        return {"status": "error", "error": str(e)}


def downgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Rollback the migration: Remove bi-temporal fields from RELATES_TO."""
    logger.info("Rolling back migration 20251219_000000: add_bitemporal_to_relates_to")

    try:
        # Remove in reverse order
        logger.debug("Removing bi-temporal fields from RELATES_TO relationship table")

        conn.execute("ALTER TABLE RELATES_TO DROP IF EXISTS temporal_confidence")
        conn.execute("ALTER TABLE RELATES_TO DROP IF EXISTS is_ongoing")
        conn.execute("ALTER TABLE RELATES_TO DROP IF EXISTS temporal_precision")
        conn.execute("ALTER TABLE RELATES_TO DROP IF EXISTS rel_end")
        conn.execute("ALTER TABLE RELATES_TO DROP IF EXISTS rel_start")
        conn.execute("ALTER TABLE RELATES_TO DROP IF EXISTS temporal_type")

        # Checkpoint
        conn.execute("CHECKPOINT;")

        logger.debug("Rollback 20251219_000000: Removed 6 bi-temporal fields from RELATES_TO")

        return {
            "status": "success",
            "message": "Removed bi-temporal fields from RELATES_TO relationship table",
            "fields_removed": 6,
        }

    except Exception as e:
        logger.error("Failed to remove bi-temporal fields from RELATES_TO table", error=str(e))
        return {"status": "error", "error": str(e)}
