"""Migration: Flatten Thread metadata properties for performance

Revision ID: 20250708_185400
Revises: None
Create Date: 2025-07-08 18:54:00
"""

# Revision identifiers
revision = "20250708_185400"
down_revision = "20250701_000000"
branch_labels = None
depends_on = None

import real_ladybug as kuzu
import structlog
import json
from typing import Dict, Any
from datetime import datetime

logger = structlog.get_logger()


def upgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Apply Thread metadata flattening migration."""
    logger.info(
        "Applying migration 20250708_185400: Flatten Thread metadata properties for performance"
    )

    # Step 1: Ensure Thread table exists with correct schema
    table_created = _ensure_thread_table_exists(conn)

    # Step 2: Add new columns if table already existed and needs migration
    columns_added = 0
    if not table_created:
        existing_columns = _get_existing_columns(conn, "Thread")
        new_columns = ["project", "workspace", "tool_version", "import_date"]
        columns_to_add = [col for col in new_columns if col not in existing_columns]

        if columns_to_add:
            logger.info(f"Adding columns: {columns_to_add}")
            for column in columns_to_add:
                column_type = "TIMESTAMP" if column == "import_date" else "STRING"
                try:
                    conn.execute(f"ALTER TABLE Thread ADD {column} {column_type}")
                    logger.info(f"Added column Thread.{column}")
                    columns_added += 1
                except Exception as e:
                    logger.warning(f"Column {column} may already exist: {e}")

    # Step 3: Migrate existing metadata (only if table already existed)
    threads_migrated = 0
    if not table_created:
        threads_migrated = _migrate_existing_threads(conn)

    # Step 4: Note about performance indexes
    logger.info(
        "Skipping index creation - KuzuDB doesn't support scalar column indexes"
    )
    logger.info("Performance will rely on columnar storage and query optimization")

    result = {
        "table_created": table_created,
        "columns_added": columns_added,
        "threads_migrated": threads_migrated,
        "indexes_created": 0,
        "migration_type": "table_creation" if table_created else "column_addition",
    }

    logger.info(f"Thread metadata flattening completed: {result}")
    return result


def downgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Rollback Thread metadata flattening migration."""
    logger.info(
        "Rolling back migration 20250708_185400: Flatten Thread metadata properties for performance"
    )

    # Step 1: Move flattened properties back to metadata
    restored_threads = _restore_metadata(conn)

    # Note: We don't drop columns as KuzuDB may not support it
    # This is a limitation but acceptable for development

    result = {
        "threads_restored": restored_threads,
        "indexes_dropped": 0,
        "note": "Columns not dropped (KuzuDB limitation)",
    }

    logger.info(f"Thread metadata flattening rollback completed: {result}")
    return result


def _ensure_thread_table_exists(conn: kuzu.Connection) -> bool:
    """Ensure Thread table exists with flattened schema. Returns True if table was created."""
    try:
        # Test if table exists by trying to query it
        conn.execute("MATCH (t:Thread) RETURN t LIMIT 1")
        logger.info("Thread table already exists")
        return False
    except Exception:
        # Table doesn't exist, create it with flattened schema
        logger.info("Creating Thread table with flattened schema")
        try:
            conn.execute("""
                CREATE NODE TABLE Thread(
                    id STRING,
                    thread_id STRING,
                    title STRING,
                    summary STRING,
                    message_count INT64,
                    participants STRING[],
                    source STRING,
                    created_at TIMESTAMP,
                    updated_at TIMESTAMP,
                    project STRING,
                    workspace STRING,
                    tool_version STRING,
                    import_date TIMESTAMP,
                    metadata STRING,
                    PRIMARY KEY (id)
                )
            """)
            logger.info("Thread table created successfully with flattened schema")
            return True
        except Exception as e:
            logger.error(f"Failed to create Thread table: {e}")
            raise


def _get_existing_columns(conn: kuzu.Connection, table_name: str) -> list:
    """Get existing columns for a table (KuzuDB specific implementation)."""
    try:
        # This is a simplified check - in real implementation you'd use DESCRIBE or similar
        result = conn.execute(f"MATCH (t:{table_name}) RETURN t LIMIT 1")
        assert isinstance(result, kuzu.QueryResult), "result must be a kuzu.QueryResult"
        if result.has_next():
            # Extract column names from the result structure
            # This is a placeholder - actual implementation depends on KuzuDB introspection
            return [
                "id",
                "thread_id",
                "title",
                "summary",
                "message_count",
                "participants",
                "source",
                "created_at",
                "updated_at",
                "metadata",
            ]
        return []
    except Exception as e:
        logger.warning(f"Could not get columns for {table_name}: {e}")
        return []


def _migrate_existing_threads(conn: kuzu.Connection) -> int:
    """Migrate existing Thread metadata to flattened properties."""
    try:
        # Get all threads with metadata
        result = conn.execute("MATCH (t:Thread) WHERE t.metadata IS NOT NULL RETURN t")
        assert isinstance(result, kuzu.QueryResult), "result must be a kuzu.QueryResult"
        migrated_count = 0
        while result.has_next():
            row = result.get_next()
            thread = row[0]  # type: ignore

            try:
                # Parse existing metadata
                metadata = json.loads(thread.get("metadata", "{}"))

                # Extract flattened properties
                project = metadata.get("project")
                workspace = metadata.get("workspace")
                tool_version = metadata.get("tool_version")
                import_date = metadata.get("import_date")

                # Remove migrated properties from metadata
                for key in ["project", "workspace", "tool_version", "import_date"]:
                    metadata.pop(key, None)

                # Update thread with flattened properties
                update_params = {
                    "thread_id": thread["id"],
                    "project": project,
                    "workspace": workspace,
                    "tool_version": tool_version,
                    "import_date": datetime.fromisoformat(import_date)
                    if import_date
                    else None,
                    "metadata": json.dumps(metadata),
                }

                conn.execute(
                    """
                    MATCH (t:Thread {id: $thread_id})
                    SET t.project = $project,
                        t.workspace = $workspace,
                        t.tool_version = $tool_version,
                        t.import_date = $import_date,
                        t.metadata = $metadata
                """,
                    update_params,
                )

                migrated_count += 1

            except json.JSONDecodeError:
                logger.warning(f"Invalid JSON metadata for thread {thread.get('id')}")
            except Exception as e:
                logger.error(f"Failed to migrate thread {thread.get('id')}: {e}")

        logger.info(f"Migrated {migrated_count} threads")
        return migrated_count

    except Exception as e:
        logger.error(f"Failed to migrate existing threads: {e}")
        raise


def _restore_metadata(conn: kuzu.Connection) -> int:
    """Restore flattened properties back to metadata JSON."""
    try:
        result = conn.execute("""
            MATCH (t:Thread) 
            WHERE t.project IS NOT NULL OR t.workspace IS NOT NULL 
               OR t.tool_version IS NOT NULL OR t.import_date IS NOT NULL
            RETURN t
        """)
        assert isinstance(result, kuzu.QueryResult), "result must be a kuzu.QueryResult"
        restored_count = 0

        while result.has_next():
            row = result.get_next()
            thread = row[0]  # type: ignore

            try:
                # Parse existing metadata
                metadata = json.loads(thread.get("metadata", "{}"))

                # Add flattened properties back to metadata
                if thread.get("project"):
                    metadata["project"] = thread["project"]
                if thread.get("workspace"):
                    metadata["workspace"] = thread["workspace"]
                if thread.get("tool_version"):
                    metadata["tool_version"] = thread["tool_version"]
                if thread.get("import_date"):
                    metadata["import_date"] = thread["import_date"].isoformat()

                # Update thread
                conn.execute(
                    """
                    MATCH (t:Thread {id: $thread_id})
                    SET t.metadata = $metadata,
                        t.project = NULL,
                        t.workspace = NULL,
                        t.tool_version = NULL,
                        t.import_date = NULL
                """,
                    {"thread_id": thread["id"], "metadata": json.dumps(metadata)},
                )

                restored_count += 1

            except Exception as e:
                logger.error(f"Failed to restore thread {thread.get('id')}: {e}")

        return restored_count

    except Exception as e:
        logger.error(f"Failed to restore metadata: {e}")
        raise
