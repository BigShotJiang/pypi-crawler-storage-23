"""Migration: Create initial database schema

Revision ID: 20250701_000000
Revises: None
Create Date: 2025-07-01 00:00:00
"""

# Revision identifiers
revision = "20250701_000000"
down_revision = None
branch_labels = None
depends_on = None

import real_ladybug as kuzu
import structlog
from typing import Dict, Any
import sys
from pathlib import Path

# Add src to path for migration imports
src_path = Path(__file__).parent.parent.parent.parent
if str(src_path) not in sys.path:
    sys.path.insert(0, str(src_path))

from nowledge_graph_server.database.base_client import ensure_kuzu_extensions

logger = structlog.get_logger()


def upgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Create initial database schema with all base tables."""
    logger.info("Creating initial database schema")

    # Ensure required extensions are loaded for schema creation
    ensure_kuzu_extensions(conn, raise_on_failure=True)
    logger.info("Extensions loaded for schema creation")

    tables_created = []

    try:
        # Create Thread table
        conn.execute("""
            CREATE NODE TABLE IF NOT EXISTS Thread(
                id STRING,
                thread_id STRING,
                title STRING,
                summary STRING,
                message_count INT64,
                participants STRING[],
                source STRING,
                created_at TIMESTAMP,
                updated_at TIMESTAMP,
                project STRING,
                workspace STRING,
                tool_version STRING,
                import_date TIMESTAMP,
                metadata STRING,
                PRIMARY KEY (id)
            )
        """)
        tables_created.append("Thread")
        logger.info("Created Thread table")

        # Create Message table
        conn.execute("""
            CREATE NODE TABLE IF NOT EXISTS Message(
                id STRING,
                content STRING,
                role STRING,
                order_index INT64,
                timestamp TIMESTAMP,
                token_count INT64,
                created_at TIMESTAMP,
                updated_at TIMESTAMP,
                metadata STRING,
                PRIMARY KEY (id)
            )
        """)
        tables_created.append("Message")
        logger.info("Created Message table")

        # Create Memory table (with configurable embedding dimension)
        conn.execute("""
            CREATE NODE TABLE IF NOT EXISTS Memory(
                id STRING,
                content STRING,
                title STRING,
                importance DOUBLE,
                confidence DOUBLE,
                embedding FLOAT[384],
                source_range STRING,
                source STRING,
                created_at TIMESTAMP,
                updated_at TIMESTAMP,
                metadata STRING,
                semantic_field STRING,
                reindex_needed BOOLEAN DEFAULT FALSE,
                last_reindexed_at TIMESTAMP,
                community_id INT64 DEFAULT NULL,
                pagerank_score DOUBLE DEFAULT 0.0,
                PRIMARY KEY (id)
            )
        """)
        tables_created.append("Memory")
        logger.info("Created Memory table")

        # Create Entity table
        conn.execute("""
            CREATE NODE TABLE IF NOT EXISTS Entity(
                id STRING,
                name STRING,
                entity_type STRING,
                description STRING,
                aliases STRING[],
                confidence DOUBLE,
                created_at TIMESTAMP,
                updated_at TIMESTAMP,
                metadata STRING,
                community_id INT64 DEFAULT NULL,
                pagerank_score DOUBLE DEFAULT 0.0,
                PRIMARY KEY (id)
            )
        """)
        tables_created.append("Entity")
        logger.info("Created Entity table")

        # Create Label table
        conn.execute("""
            CREATE NODE TABLE IF NOT EXISTS Label(
                id STRING,
                name STRING,
                color STRING,
                description STRING,
                created_at TIMESTAMP,
                updated_at TIMESTAMP,
                metadata STRING,
                PRIMARY KEY (id)
            )
        """)
        tables_created.append("Label")
        logger.info("Created Label table")

        # Create Community table
        conn.execute("""
            CREATE NODE TABLE IF NOT EXISTS Community(
                id STRING,
                community_id INT64,
                name STRING,
                description STRING,
                ai_summary STRING,
                member_count INT64,
                algorithm STRING,
                resolution DOUBLE,
                created_at TIMESTAMP,
                updated_at TIMESTAMP,
                PRIMARY KEY (id)
            )
        """)
        tables_created.append("Community")
        logger.info("Created Community table")

        # Create relationship tables
        conn.execute("""
            CREATE REL TABLE IF NOT EXISTS CONTAINS(
                FROM Thread TO Message,
                order_index INT64,
                created_at TIMESTAMP,
                properties STRING
            )
        """)
        tables_created.append("CONTAINS")
        logger.info("Created CONTAINS relationship")

        conn.execute("""
            CREATE REL TABLE IF NOT EXISTS COMPACTS_TO(
                FROM Thread TO Memory,
                compaction_method STRING,
                created_at TIMESTAMP,
                properties STRING
            )
        """)
        tables_created.append("COMPACTS_TO")
        logger.info("Created COMPACTS_TO relationship")

        conn.execute("""
            CREATE REL TABLE IF NOT EXISTS EXTRACTED_FROM(
                FROM Memory TO Message,
                extraction_confidence DOUBLE,
                created_at TIMESTAMP,
                properties STRING
            )
        """)
        tables_created.append("EXTRACTED_FROM")
        logger.info("Created EXTRACTED_FROM relationship")

        conn.execute("""
            CREATE REL TABLE IF NOT EXISTS MENTIONS(
                FROM Memory TO Entity,
                confidence DOUBLE,
                mention_count INT64,
                created_at TIMESTAMP,
                properties STRING
            )
        """)
        tables_created.append("MENTIONS")
        logger.info("Created MENTIONS relationship")

        conn.execute("""
            CREATE REL TABLE IF NOT EXISTS RELATES_TO(
                FROM Entity TO Entity,
                relation_type STRING,
                strength DOUBLE,
                confidence DOUBLE,
                context STRING,
                conditions STRING,
                temporal_info STRING,
                source_reference STRING,
                bidirectional BOOLEAN,
                created_at TIMESTAMP,
                properties STRING
            )
        """)
        tables_created.append("RELATES_TO")
        logger.info("Created RELATES_TO relationship")

        # Create consolidated HAS_LABEL relationship
        conn.execute("""
            CREATE REL TABLE IF NOT EXISTS HAS_LABEL(
                FROM Thread TO Label, FROM Memory TO Label, FROM Entity TO Label,
                assigned_by STRING,
                created_at TIMESTAMP,
                properties STRING
            )
        """)
        tables_created.append("HAS_LABEL")
        logger.info("Created HAS_LABEL relationship")

        conn.execute("""
            CREATE REL TABLE IF NOT EXISTS BELONGS_TO(
                FROM Entity TO Community,
                strength DOUBLE,
                created_at TIMESTAMP,
                properties STRING
            )
        """)
        tables_created.append("BELONGS_TO")
        logger.info("Created BELONGS_TO relationship")

        logger.info(
            "Initial schema created successfully",
            tables_created=len(tables_created),
            tables=tables_created,
        )

        return {
            "status": "success",
            "tables_created": len(tables_created),
            "tables": tables_created,
        }

    except Exception as e:
        logger.error("Failed to create initial schema", error=str(e))
        return {"status": "error", "error": str(e)}


def downgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Drop all tables (WARNING: This will delete all data)."""
    logger.info("Rolling back initial schema migration")

    tables_dropped = []

    try:
        # Drop relationship tables first (due to dependencies)
        relationships = [
            "BELONGS_TO",
            "HAS_LABEL",
            "RELATES_TO",
            "MENTIONS",
            "EXTRACTED_FROM",
            "COMPACTS_TO",
            "CONTAINS",
        ]

        for rel in relationships:
            try:
                conn.execute(f"DROP TABLE {rel}")
                tables_dropped.append(rel)
                logger.info(f"Dropped {rel} relationship")
            except Exception as e:
                logger.warning(f"Failed to drop {rel}: {e}")

        # Drop node tables
        tables = ["Community", "Label", "Entity", "Memory", "Message", "Thread"]

        for table in tables:
            try:
                conn.execute(f"DROP TABLE {table}")
                tables_dropped.append(table)
                logger.info(f"Dropped {table} table")
            except Exception as e:
                logger.warning(f"Failed to drop {table}: {e}")

        logger.info("Schema rollback completed", tables_dropped=len(tables_dropped))

        return {
            "status": "success",
            "tables_dropped": len(tables_dropped),
            "tables": tables_dropped,
        }

    except Exception as e:
        logger.error("Failed to rollback schema", error=str(e))
        return {"status": "error", "error": str(e)}
