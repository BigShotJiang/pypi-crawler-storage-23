"""Migration: v0.6 EVOLVES, Crystals, and Knowledge Agent support

Revision ID: 20260204_179527
Revises: 20260115_000000
Create Date: 2026-02-04 17:00:00

Adds schema support for the v0.6 Knowledge Agent system:

MEMORY TABLE new fields:
- unit_type: fact|preference|decision|plan|procedure|learning|context|event
- is_latest: Head of EVOLVES(replaces) version chain
- version: Version counter within chain
- is_crystal: True for crystallized knowledge
- crystal_title: Human-readable crystal title
- source_unit_count: Number of source units (crystals only)
- extraction_method: How this memory was created: manual|llm|rule|agent

NEW RELATIONSHIP TABLES:
- EVOLVES: Memory -> Memory (replaces|enriches|confirms|challenges)
- CRYSTALLIZED_FROM: Crystal Memory -> Source Memory

NOTE: Feed timeline events (insights, flags, briefings) use file-based
storage (daily report .md files + feed.jsonl) rather than graph DB nodes.
"""

# Revision identifiers
revision = "20260204_179527"
down_revision = "20260115_000000"
branch_labels = None
depends_on = None

import real_ladybug as kuzu
import structlog
from typing import Dict, Any

logger = structlog.get_logger()


def upgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Apply the migration: Add EVOLVES and Crystal schema."""
    logger.info("Applying migration 20260204_179527: v06_evolves_crystal_and_agent")

    try:
        # ======================================================================
        # Step 1: Add new fields to Memory table
        # ======================================================================
        logger.info("Step 1/5: Adding Knowledge Agent fields to Memory table")

        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS unit_type STRING DEFAULT 'fact'")
        logger.info("  Added unit_type (default: fact)")

        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS is_latest BOOLEAN DEFAULT true")
        logger.info("  Added is_latest (default: true)")

        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS version INT64 DEFAULT 1")
        logger.info("  Added version (default: 1)")

        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS is_crystal BOOLEAN DEFAULT false")
        logger.info("  Added is_crystal (default: false)")

        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS crystal_title STRING")
        logger.info("  Added crystal_title")

        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS source_unit_count INT64")
        logger.info("  Added source_unit_count")

        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS extraction_method STRING DEFAULT 'manual'")
        logger.info("  Added extraction_method (default: manual)")

        # ======================================================================
        # Step 2: Create EVOLVES relationship table
        # ======================================================================
        logger.info("Step 2/5: Creating EVOLVES relationship table")

        conn.execute("""
            CREATE REL TABLE IF NOT EXISTS EVOLVES(
                FROM Memory TO Memory,
                content_relation STRING,
                is_progression BOOLEAN DEFAULT false,
                confidence DOUBLE DEFAULT 1.0,
                detected_by STRING DEFAULT 'system',
                reviewed BOOLEAN DEFAULT false,
                reason STRING,
                created_at TIMESTAMP
            )
        """)
        logger.info("  Created EVOLVES relationship table")

        # ======================================================================
        # Step 3: Create CRYSTALLIZED_FROM relationship table
        # ======================================================================
        logger.info("Step 3/5: Creating CRYSTALLIZED_FROM relationship table")

        conn.execute("""
            CREATE REL TABLE IF NOT EXISTS CRYSTALLIZED_FROM(
                FROM Memory TO Memory,
                contribution_weight DOUBLE DEFAULT 1.0,
                created_at TIMESTAMP
            )
        """)
        logger.info("  Created CRYSTALLIZED_FROM relationship table")

        # ======================================================================
        # Step 4: Backfill existing memories with default values
        # ======================================================================
        logger.info("Step 4/5: Backfilling existing memories with default values")

        try:
            conn.execute("""
                MATCH (m:Memory)
                WHERE m.unit_type IS NULL
                SET m.unit_type = 'fact',
                    m.is_latest = true,
                    m.version = 1,
                    m.is_crystal = false,
                    m.extraction_method = 'manual'
            """)
            logger.info("  Backfilled existing memories with defaults")
        except Exception as e:
            logger.warning(
                "Could not backfill existing memories - may need manual update",
                error=str(e)
            )

        # ======================================================================
        # Step 5: Checkpoint to flush WAL
        # ======================================================================
        logger.info("Step 5/5: Checkpointing to flush WAL")
        conn.execute("CHECKPOINT;")
        logger.info("  Checkpoint completed")

        logger.info("Migration 20260204_179527 completed successfully")

        return {
            "status": "success",
            "message": "Added EVOLVES and Crystal schema for Knowledge Agent",
            "memory_fields_added": 7,
            "tables_created": ["EVOLVES", "CRYSTALLIZED_FROM"],
        }

    except Exception as e:
        logger.error("Failed to apply migration 20260204_179527", error=str(e))
        return {"status": "error", "error": str(e)}


def downgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Rollback the migration: Remove EVOLVES and Crystal schema."""
    logger.info("Rolling back migration 20260204_179527: v06_evolves_crystal_and_agent")

    try:
        logger.info("Step 1/3: Dropping CRYSTALLIZED_FROM relationship")
        try:
            conn.execute("DROP TABLE CRYSTALLIZED_FROM")
            logger.info("  Dropped CRYSTALLIZED_FROM")
        except Exception as e:
            logger.warning(f"Failed to drop CRYSTALLIZED_FROM: {e}")

        logger.info("Step 2/3: Dropping EVOLVES relationship")
        try:
            conn.execute("DROP TABLE EVOLVES")
            logger.info("  Dropped EVOLVES")
        except Exception as e:
            logger.warning(f"Failed to drop EVOLVES: {e}")

        logger.info("Step 3/3: Removing Memory fields")
        for field in [
            "extraction_method", "source_unit_count", "crystal_title",
            "is_crystal", "version", "is_latest", "unit_type",
        ]:
            try:
                conn.execute(f"ALTER TABLE Memory DROP {field}")
                logger.info(f"  Dropped Memory.{field}")
            except Exception as e:
                logger.warning(f"Failed to drop Memory.{field}: {e}")

        conn.execute("CHECKPOINT;")
        logger.info("Rollback 20260204_179527 completed successfully")

        return {
            "status": "success",
            "message": "Removed EVOLVES and Crystal schema",
        }

    except Exception as e:
        logger.error("Failed to rollback migration 20260204_179527", error=str(e))
        return {"status": "error", "error": str(e)}
