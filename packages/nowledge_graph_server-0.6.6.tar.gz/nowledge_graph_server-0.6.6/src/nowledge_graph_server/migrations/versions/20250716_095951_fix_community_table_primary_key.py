"""Migration: fix_community_table_primary_key

Revision ID: 20250716_095951
Revises: 20250714_160000
Create Date: 2025-07-16 09:59:51
"""

# Revision identifiers
revision = "20250716_095951"
down_revision = "20250714_160000"
branch_labels = None
depends_on = None

import real_ladybug as kuzu
import structlog
import uuid
from typing import Dict, Any

logger = structlog.get_logger()


def upgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Apply the migration: Fix Community table to use auto-generated UUID as PK."""
    logger.info("Applying migration 20250716_095951: fix_community_table_primary_key")

    try:
        # Step 1: Check if Community table exists and backup data
        backup_data = []
        try:
            result = conn.execute("MATCH (c:Community) RETURN c")
            assert isinstance(result, kuzu.QueryResult), "Result is not a QueryResult"
            while result.has_next():
                row = result.get_next()
                community_data = row[0]  # type: ignore
                backup_data.append(community_data)
            logger.info(f"Backed up {len(backup_data)} community records")
        except Exception as e:
            logger.info("Community table doesn't exist or is empty", error=str(e))

        # Step 2: Drop BELONGS_TO relationship table first (to remove dependency)
        try:
            conn.execute("DROP TABLE BELONGS_TO")
            logger.info("Dropped BELONGS_TO relationship table")
        except Exception as e:
            logger.info("BELONGS_TO table didn't exist", error=str(e))

        # Step 2.5: Drop fulltext search index if it exists (to remove dependency)
        try:
            conn.execute("CALL DROP_FTS_INDEX('Community', 'community_summary_search')")
            logger.info("Dropped community_summary_search index")
        except Exception as e:
            logger.info("community_summary_search index didn't exist", error=str(e))
            # Try alternative approach - check if it's a KuzuDB version issue
            try:
                conn.execute("DROP INDEX community_summary_search")
                logger.info(
                    "Dropped community_summary_search index with alternative syntax"
                )
            except Exception as e2:
                logger.info("Alternative index drop also failed", error=str(e2))

        # Step 3: Drop existing Community table if it exists
        try:
            conn.execute("DROP TABLE Community")
            logger.info("Dropped existing Community table")
        except Exception as e:
            logger.warning("Failed to drop Community table", error=str(e))
            # If table exists but can't be dropped due to constraints, try to work around it
            if "already exists" in str(e).lower() or "referenced by" in str(e).lower():
                logger.info(
                    "Community table exists with constraints, attempting alternative approach"
                )
                # We'll create with a different approach below

        # Step 4: Create new Community table with proper schema
        logger.info("Creating Community table with UUID primary key")
        try:
            conn.execute("""
                CREATE NODE TABLE Community(
                    id STRING,
                    community_id INT64,
                    name STRING,
                    description STRING,
                    ai_summary STRING,
                    member_count INT64,
                    algorithm STRING,
                    resolution DOUBLE,
                    created_at TIMESTAMP,
                    updated_at TIMESTAMP,
                    PRIMARY KEY (id)
                )
            """)
            logger.info("Created Community table with correct schema")
        except Exception as e:
            if "already exists" in str(e).lower():
                logger.info(
                    "Community table already exists, checking if schema is correct"
                )
                # Check if the table has the correct schema by querying its structure
                try:
                    # Test if id column exists as primary key
                    conn.execute("MATCH (c:Community) RETURN c.id LIMIT 1")
                    logger.info(
                        "Community table already has correct schema with id as PK"
                    )
                except Exception as schema_check_error:
                    logger.error(
                        "Community table exists but schema may be incorrect",
                        error=str(schema_check_error),
                    )
                    raise
            else:
                logger.error("Failed to create Community table", error=str(e))
                raise

        # Step 5: Recreate BELONGS_TO relationship table
        logger.info("Recreating BELONGS_TO relationship table")
        try:
            conn.execute("""
                CREATE REL TABLE BELONGS_TO(
                    FROM Entity TO Community,
                    FROM Memory TO Community,
                    confidence DOUBLE DEFAULT 1.0,
                    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
                )
            """)
            logger.info("Recreated BELONGS_TO relationship table")
        except Exception as e:
            if "already exists" in str(e).lower():
                logger.info("BELONGS_TO relationship table already exists")
            else:
                logger.error(
                    "Failed to recreate BELONGS_TO relationship table", error=str(e)
                )
                raise

        # Step 6: Recreate Community FTS index for search functionality
        logger.info("Recreating Community FTS index")
        try:
            conn.execute("""
                CALL CREATE_FTS_INDEX('Community', 'community_summary_search', ['name', 'description', 'ai_summary'])
            """)
            logger.info("Recreated Community FTS index successfully")
        except Exception as e:
            logger.warning("Failed to recreate Community FTS index", error=str(e))

        # Step 7: Restore data with new UUID primary keys
        restored_count = 0
        for community_data in backup_data:
            try:
                # Generate new UUID for primary key
                new_id = str(uuid.uuid4())

                conn.execute(
                    """
                    CREATE (c:Community {
                        id: $id,
                        community_id: $community_id,
                        name: $name,
                        description: $description,
                        ai_summary: $ai_summary,
                        member_count: $member_count,
                        algorithm: $algorithm,
                        resolution: $resolution,
                        created_at: $created_at,
                        updated_at: $updated_at
                    })
                """,
                    {
                        "id": new_id,
                        "community_id": community_data.get("community_id", 0),
                        "name": community_data.get("name", ""),
                        "description": community_data.get("description", ""),
                        "ai_summary": community_data.get("ai_summary", ""),
                        "member_count": community_data.get("member_count", 0),
                        "algorithm": community_data.get("algorithm", ""),
                        "resolution": community_data.get("resolution", 1.0),
                        "created_at": community_data.get(
                            "created_at", "2025-01-01T00:00:00"
                        ),
                        "updated_at": community_data.get(
                            "updated_at", "2025-01-01T00:00:00"
                        ),
                    },
                )
                restored_count += 1
            except Exception as e:
                logger.warning(
                    "Failed to restore community data",
                    data=community_data,
                    error=str(e),
                )

        logger.info(f"Restored {restored_count} community records with new schema")

        return {
            "migration_applied": True,
            "revision": "20250716_095951",
            "communities_backed_up": len(backup_data),
            "communities_restored": restored_count,
        }

    except Exception as e:
        logger.error("Migration failed", error=str(e))
        raise


def downgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Rollback the migration: Restore Community table with community_id as PK."""
    logger.info(
        "Rolling back migration 20250716_095951: fix_community_table_primary_key"
    )

    try:
        # Step 1: Backup current data
        backup_data = []
        try:
            result = conn.execute("MATCH (c:Community) RETURN c")
            assert isinstance(result, kuzu.QueryResult), "Result is not a QueryResult"
            while result.has_next():
                row = result.get_next()
                community_data = row[0]  # type: ignore
                backup_data.append(community_data)
            logger.info(f"Backed up {len(backup_data)} community records for rollback")
        except Exception as e:
            logger.info("Community table doesn't exist or is empty", error=str(e))

        # Step 2: Drop current Community table
        try:
            conn.execute("DROP TABLE Community")
            logger.info("Dropped Community table for rollback")
        except Exception as e:
            logger.info("Community table didn't exist", error=str(e))

        # Step 3: Recreate Community table with old schema (community_id as PK)
        conn.execute("""
            CREATE NODE TABLE Community(
                community_id INT64,
                name STRING,
                description STRING,
                ai_summary STRING,
                member_count INT64,
                algorithm STRING,
                resolution DOUBLE,
                created_at TIMESTAMP,
                updated_at TIMESTAMP,
                PRIMARY KEY (community_id)
            )
        """)
        logger.info("Recreated Community table with old schema (community_id as PK)")

        # Step 4: Restore data (excluding the new 'id' field)
        restored_count = 0
        for community_data in backup_data:
            try:
                conn.execute(
                    """
                    CREATE (c:Community {
                        community_id: $community_id,
                        name: $name,
                        description: $description,
                        ai_summary: $ai_summary,
                        member_count: $member_count,
                        algorithm: $algorithm,
                        resolution: $resolution,
                        created_at: $created_at,
                        updated_at: $updated_at
                    })
                """,
                    {
                        "community_id": community_data.get("community_id", 0),
                        "name": community_data.get("name", ""),
                        "description": community_data.get("description", ""),
                        "ai_summary": community_data.get("ai_summary", ""),
                        "member_count": community_data.get("member_count", 0),
                        "algorithm": community_data.get("algorithm", ""),
                        "resolution": community_data.get("resolution", 1.0),
                        "created_at": community_data.get(
                            "created_at", "2025-01-01T00:00:00"
                        ),
                        "updated_at": community_data.get(
                            "updated_at", "2025-01-01T00:00:00"
                        ),
                    },
                )
                restored_count += 1
            except Exception as e:
                logger.warning(
                    "Failed to restore community data during rollback",
                    data=community_data,
                    error=str(e),
                )

        logger.info(f"Restored {restored_count} community records with old schema")

        return {
            "migration_rolled_back": True,
            "revision": "20250716_095951",
            "communities_backed_up": len(backup_data),
            "communities_restored": restored_count,
        }

    except Exception as e:
        logger.error("Migration rollback failed", error=str(e))
        raise
