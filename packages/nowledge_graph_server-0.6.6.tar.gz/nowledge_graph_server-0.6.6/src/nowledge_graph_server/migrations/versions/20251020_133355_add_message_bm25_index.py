"""Add BM25 (FTS) index on Message.content for thread search.

Revision ID: 20251020_133355
Created: 2025-10-20 13:33:55
"""

import structlog
import real_ladybug as kuzu

logger = structlog.get_logger(__name__)

# Revision identifiers
revision = "20251020_133355"
down_revision = "20250716_095951"  # Previous migration


def check_index_exists(conn: kuzu.Connection, index_name: str) -> bool:
    """Check if an FTS index already exists."""
    try:
        # Try to query the index - if it exists, this won't error
        conn.execute(
            f"""
            CALL QUERY_FTS_INDEX(
                'Message',
                '{index_name}',
                'test'
            )
            RETURN node
            LIMIT 1
            """
        )
        return True
    except Exception as e:
        error_msg = str(e).lower()
        if "does not exist" in error_msg or "no fts index" in error_msg:
            return False
        # Other errors might indicate the index exists but query failed
        logger.warning(f"Unexpected error checking index {index_name}", error=str(e))
        return False


def upgrade(conn: kuzu.Connection) -> None:
    """Add BM25 index on Message.content for full-text search."""
    index_name = "message_content_fts"

    try:
        # Check if index already exists
        if check_index_exists(conn, index_name):
            logger.info(f"FTS index {index_name} already exists, skipping creation")
            return

        # Create FTS index on Message.content
        logger.info(f"Creating FTS index {index_name} on Message.content")
        conn.execute(
            f"""
            CALL CREATE_FTS_INDEX('Message', '{index_name}', ['content'])
            """
        )
        logger.info(f"Successfully created FTS index {index_name}")

    except Exception as e:
        error_msg = str(e).lower()
        if "already exists" in error_msg:
            logger.info(f"FTS index {index_name} already exists (caught in creation)")
        else:
            logger.error(f"Failed to create FTS index {index_name}", error=str(e))
            raise


def downgrade(conn: kuzu.Connection) -> None:
    """Remove BM25 index on Message.content."""
    index_name = "message_content_fts"

    try:
        # Note: KuzuDB doesn't have DROP_FTS_INDEX as of 0.11.1
        # Index will be removed when table is dropped or database is recreated
        logger.warning(
            f"FTS index {index_name} cannot be explicitly dropped in KuzuDB 0.11.1"
        )
        logger.warning("Index will persist until table/database recreation")

    except Exception as e:
        logger.error(f"Error in downgrade for FTS index {index_name}", error=str(e))
        raise
