"""Migration: add_memory_source_column

Revision ID: 20250731_124800
Revises: 20250716_095951
Create Date: 2025-07-31 12:48:00
"""

# Revision identifiers
revision = "20250731_124800"
down_revision = "20250716_095951"
branch_labels = None
depends_on = None

import real_ladybug as kuzu
import structlog
from typing import Dict, Any

logger = structlog.get_logger()


def upgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Apply the migration: Add source column to Memory table."""
    logger.info("Applying migration 20250731_124800: add_memory_source_column")

    try:
        # Add source column to Memory table (using KuzuDB syntax)
        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS source STRING")
        logger.info("Successfully added source column to Memory table")

        return {"status": "success", "message": "Added source column to Memory table"}

    except Exception as e:
        logger.error("Failed to add source column to Memory table", error=str(e))
        return {"status": "error", "error": str(e)}


def downgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Rollback the migration: Remove source column from Memory table."""
    logger.info("Rolling back migration 20250731_124800: add_memory_source_column")

    try:
        # Remove source column from Memory table (using KuzuDB syntax)
        conn.execute("ALTER TABLE Memory DROP source")
        logger.info("Successfully removed source column from Memory table")

        return {
            "status": "success",
            "message": "Removed source column from Memory table",
        }

    except Exception as e:
        logger.error("Failed to remove source column from Memory table", error=str(e))
        return {"status": "error", "error": str(e)}
