"""Add last_evaluated_at to Memory for crystal staleness tracking.

Crystals need lifecycle management — when source memories evolve
(new EVOLVES edges, content updates), crystals should be re-evaluated.
This field tracks when each crystal was last checked for staleness.

Revision ID: 20260209_120000
Revises: 20260204_170000
"""

from __future__ import annotations

from typing import Any, Dict

import real_ladybug as kuzu
import structlog

logger = structlog.get_logger(__name__)

revision = "20260209_120000"
down_revision = "20260204_170000"


def upgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Add last_evaluated_at timestamp to Memory table."""
    logger.info("Applying migration: add last_evaluated_at to Memory")

    conn.execute(
        "ALTER TABLE Memory ADD IF NOT EXISTS last_evaluated_at TIMESTAMP"
    )
    conn.execute("CHECKPOINT;")

    return {
        "status": "success",
        "message": "Added last_evaluated_at to Memory for crystal staleness tracking",
        "fields_added": 1,
    }


def downgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Remove last_evaluated_at from Memory table."""
    logger.info("Rolling back migration: remove last_evaluated_at from Memory")

    conn.execute("ALTER TABLE Memory DROP IF EXISTS last_evaluated_at")
    conn.execute("CHECKPOINT;")

    return {
        "status": "success",
        "message": "Removed last_evaluated_at from Memory",
    }
