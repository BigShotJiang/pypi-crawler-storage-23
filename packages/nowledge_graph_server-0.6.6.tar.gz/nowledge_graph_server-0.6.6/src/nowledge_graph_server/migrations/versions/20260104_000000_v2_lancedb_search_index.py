"""Schema v2: Transition to LanceDB for search indexing.

This migration marks the transition to v2 (cedar) database schema:
- Search indexing moved from Kuzu vector/FTS to LanceDB hybrid search
- BGE-M3 embeddings (1024-dim) replace E5 embeddings (384-dim)
- Kuzu vector/FTS indexes are deprecated but NOT dropped (limitation)
- Memory.embedding and Memory.semantic_field columns remain for compatibility

The old Kuzu indexes will still exist but are unused:
- memory_embedding_idx_new (vector index on Memory.embedding)
- memory_semantic_index (FTS on Memory.semantic_field)
- entity_content_index (FTS on Entity.name, description)
- thread_content_index (FTS on Thread.title, summary)
- community_summary_search (FTS on Community.name, description, ai_summary)
- message_content_fts (FTS on Message.content)

New databases created at v2+ will NOT have these indexes created.
LanceDB provides better hybrid search with:
- BGE-M3 1024-dim multilingual embeddings
- Tantivy BM25 full-text search
- RRF (Reciprocal Rank Fusion) for combining results

Revision ID: 20260104_000000
Created: 2026-01-04 00:00:00
"""

import structlog
import real_ladybug as kuzu

logger = structlog.get_logger(__name__)

# Revision identifiers
revision = "20260104_000000"
down_revision = "20251219_000000"  # Previous migration: add_bitemporal_to_relates_to


def upgrade(conn: kuzu.Connection) -> None:
    """Mark transition to v2 schema with LanceDB search.

    Note: We cannot drop Kuzu FTS/vector indexes (not supported in KuzuDB).
    The indexes will remain but are unused since LanceDB takes priority.
    """
    logger.info(
        "Upgrading to v2 (cedar) schema - LanceDB search index",
        note="Kuzu vector/FTS indexes are deprecated but cannot be dropped",
    )

    # Log the deprecation of Kuzu indexes
    deprecated_indexes = [
        ("Memory", "memory_embedding_idx_new", "vector"),
        ("Memory", "memory_semantic_index", "fts"),
        ("Entity", "entity_content_index", "fts"),
        ("Thread", "thread_content_index", "fts"),
        ("Community", "community_summary_search", "fts"),
        ("Message", "message_content_fts", "fts"),
    ]

    for table, index_name, index_type in deprecated_indexes:
        logger.info(
            f"Deprecated {index_type} index",
            table=table,
            index=index_name,
            reason="Replaced by LanceDB hybrid search",
        )

    # Note: We would drop the Memory.embedding column here if Kuzu supported
    # ALTER TABLE DROP COLUMN, but it doesn't. The column will remain unused.
    logger.info(
        "Memory.embedding column deprecated",
        dimension=384,
        reason="Replaced by BGE-M3 1024-dim embeddings in LanceDB",
    )

    logger.info(
        "Memory.semantic_field column deprecated",
        reason="Replaced by LanceDB FTS on content directly",
    )

    logger.info("v2 (cedar) schema upgrade complete")


def downgrade(conn: kuzu.Connection) -> None:
    """Downgrade from v2 to v1.

    Note: This is a no-op since we didn't actually modify the schema.
    The Kuzu indexes still exist (they couldn't be dropped).
    """
    logger.warning(
        "Downgrading from v2 (cedar) to v1 (birch)",
        note="No schema changes to revert - Kuzu indexes were preserved",
    )

    logger.info("v2 -> v1 downgrade complete (no-op)")
