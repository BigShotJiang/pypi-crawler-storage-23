"""Add context fields to RELATES_TO relationships

Revision ID: 20250714_150418
Revises: 20250709_112227
Create Date: 2025-07-14 15:04:18.652943

"""

from typing import Dict, Any
import real_ladybug as kuzu
import structlog

# revision identifiers, used by migration system
revision = "20250714_150418"
down_revision = "20250709_112227"
branch_labels = None
depends_on = None

logger = structlog.get_logger(__name__)


def upgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """
    Add context fields to RELATES_TO relationship table to store raw extraction context.

    Uses KuzuDB's native ALTER TABLE ADD COLUMN syntax.
    """
    try:
        # Add context fields to store raw extraction context
        # Using IF NOT EXISTS to avoid errors if columns already exist

        logger.info("Adding raw_context column to RELATES_TO relationship table")
        conn.execute("""
            ALTER TABLE RELATES_TO 
            ADD IF NOT EXISTS raw_context STRING DEFAULT ''
        """)

        logger.info(
            "Adding extraction_metadata column to RELATES_TO relationship table"
        )
        conn.execute("""
            ALTER TABLE RELATES_TO 
            ADD IF NOT EXISTS extraction_metadata STRING DEFAULT '{}'
        """)

        logger.info(
            "Successfully added context fields to RELATES_TO relationship table"
        )

        return {
            "success": True,
            "message": "Added context fields to RELATES_TO relationship table",
            "changes": [
                "Added raw_context column (STRING, default '')",
                "Added extraction_metadata column (STRING, default '{}')",
            ],
        }

    except Exception as e:
        logger.error(
            f"Failed to add context fields to RELATES_TO relationship table: {e}"
        )
        return {
            "success": False,
            "message": f"Failed to add context fields: {e}",
            "error": str(e),
        }


def downgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """
    Remove context fields from RELATES_TO relationship table.
    """
    try:
        logger.info("Removing context fields from RELATES_TO relationship table")

        # Drop the added columns
        conn.execute("ALTER TABLE RELATES_TO DROP IF EXISTS raw_context")
        conn.execute("ALTER TABLE RELATES_TO DROP IF EXISTS extraction_metadata")

        logger.info(
            "Successfully removed context fields from RELATES_TO relationship table"
        )

        return {
            "success": True,
            "message": "Removed context fields from RELATES_TO relationship table",
            "changes": [
                "Removed raw_context column",
                "Removed extraction_metadata column",
            ],
        }

    except Exception as e:
        logger.error(
            f"Failed to remove context fields from RELATES_TO relationship table: {e}"
        )
        return {
            "success": False,
            "message": f"Failed to remove context fields: {e}",
            "error": str(e),
        }
