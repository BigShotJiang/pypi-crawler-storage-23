"""Migration: consolidate_has_label_relationships

Revision ID: 20250709_112227
Revises: 20250708_185400
Create Date: 2025-07-09 11:22:27

CONSOLIDATE HAS_LABEL RELATIONSHIPS using KuzuDB's Multiple FROM-TO Feature

This migration demonstrates KuzuDB's advanced capability to create a single relationship
table with multiple FROM-TO pairs, consolidating the old separate design:

OLD DESIGN (Separate Tables):
- THREAD_HAS_LABEL (FROM Thread TO Label)
- MEMORY_HAS_LABEL (FROM Memory TO Label)
- ENTITY_HAS_LABEL (FROM Entity TO Label)

NEW DESIGN (Single Polymorphic Table):
- HAS_LABEL (FROM Thread TO Label, FROM Memory TO Label, FROM Entity TO Label)

BENEFITS:
✅ Simplified schema - One table instead of three
✅ Unified querying - MATCH (n)-[:HAS_LABEL]->(l) works across all node types
✅ Easier maintenance - Add new node types without schema changes
✅ Better performance - Single table scans instead of union queries
✅ KuzuDB handles internal child tables automatically

KUZU FEATURE SHOWCASE:
✅ Multiple FROM-TO pairs in single relationship table
✅ Data migration with MERGE and SET operations
✅ Safe rollback with DROP TABLE IF EXISTS
✅ Comprehensive error handling
"""

# Revision identifiers
revision = "20250709_112227"
down_revision = "20250708_185400"
branch_labels = None
depends_on = None

import real_ladybug as kuzu
import structlog
from typing import Dict, Any, List

from nowledge_graph_server.database.schema import (
    Column,
    ColumnType,
    RelationshipTable,
    get_current_schema_definition,
)

logger = structlog.get_logger()


class HasLabelConsolidationMigration:
    """Migration to consolidate HAS_LABEL relationships using KuzuDB's multiple FROM-TO feature."""

    def __init__(self):
        self.current_schema = get_current_schema_definition()

    def check_table_exists(self, conn: kuzu.Connection, table_name: str) -> bool:
        """Check if table exists using SHOW_TABLES()."""
        try:
            result = conn.execute("CALL SHOW_TABLES() RETURN *")
            assert isinstance(result, kuzu.QueryResult), (
                "result must be a kuzu.QueryResult"
            )
            while result.has_next():
                row = result.get_next()
                # row[1] is the table name, row[0] is table ID
                if row[1] == table_name:  # type: ignore
                    return True
            return False
        except Exception:
            return False

    def get_existing_relationship_data(
        self, conn: kuzu.Connection, table_name: str
    ) -> List[Dict[str, Any]]:
        """Extract existing relationship data for migration."""
        try:
            # Extract relationships with source and target IDs plus properties
            result = conn.execute(f"""
                MATCH (source)-[r:{table_name}]->(target:Label)
                RETURN 
                    ID(source) as source_id,
                    source.id as source_external_id,
                    target.id as target_id,
                    r.assigned_by as assigned_by,
                    r.created_at as created_at,
                    r.properties as properties
            """)

            relationships = []
            assert isinstance(result, kuzu.QueryResult), (
                "result must be a kuzu.QueryResult"
            )
            while result.has_next():
                row = result.get_next()
                relationships.append(
                    {
                        "source_id": row[0],  # type: ignore
                        "source_external_id": row[1],  # type: ignore
                        "target_id": row[2],  # type: ignore
                        "assigned_by": row[3],  # type: ignore
                        "created_at": row[4],  # type: ignore
                        "properties": row[5] or "{}",  # type: ignore
                    }
                )

            logger.info(
                f"Extracted {len(relationships)} relationships from {table_name}"
            )
            return relationships

        except Exception as e:
            logger.warning(f"No data found in {table_name}: {e}")
            return []

    def create_unified_has_label_table(self, conn: kuzu.Connection) -> Dict[str, Any]:
        """Create the new unified HAS_LABEL table with multiple FROM-TO pairs."""
        logger.info("🚀 Creating unified HAS_LABEL table with multiple FROM-TO pairs")

        try:
            # Drop existing HAS_LABEL table if it exists (safe)
            conn.execute("DROP TABLE IF EXISTS HAS_LABEL")
            logger.info("✅ Cleaned up any existing HAS_LABEL table")

            # Create the new polymorphic HAS_LABEL table using KuzuDB's multiple FROM-TO syntax
            conn.execute("""
                CREATE REL TABLE HAS_LABEL(
                    FROM Thread TO Label,
                    FROM Memory TO Label,
                    FROM Entity TO Label,
                    assigned_by STRING,
                    created_at TIMESTAMP DEFAULT current_timestamp(),
                    properties STRING DEFAULT '{}'
                )
            """)

            logger.info(
                "✅ Created unified HAS_LABEL table with multiple FROM-TO pairs"
            )

            # Verify the table was created
            result = conn.execute("CALL SHOW_TABLES() RETURN *")
            created_tables = []
            assert isinstance(result, kuzu.QueryResult), (
                "result must be a kuzu.QueryResult"
            )
            while result.has_next():
                row = result.get_next()
                # row[1] is the table name, row[0] is table ID
                table_name = row[1]  # type: ignore
                if "HAS_LABEL" in table_name or table_name == "HAS_LABEL":  # type: ignore
                    created_tables.append(table_name)

            logger.info(f"✅ HAS_LABEL related tables created: {created_tables}")

            return {
                "status": "success",
                "tables_created": created_tables,
                "table_type": "polymorphic_with_multiple_from_to",
            }

        except Exception as e:
            logger.error(f"❌ Failed to create unified HAS_LABEL table: {e}")
            raise

    def migrate_relationship_data(
        self, conn: kuzu.Connection, source_table: str, target_from_type: str
    ) -> Dict[str, Any]:
        """Migrate data from old separate tables to new unified table."""
        logger.info(f"📦 Migrating data from {source_table} to unified HAS_LABEL")

        if not self.check_table_exists(conn, source_table):
            logger.info(
                f"⚠️ Source table {source_table} does not exist - skipping migration"
            )
            return {
                "status": "skipped",
                "reason": "table_not_found",
                "migrated_count": 0,
            }

        try:
            # Get existing relationships
            existing_data = self.get_existing_relationship_data(conn, source_table)

            if not existing_data:
                logger.info(f"⚠️ No data found in {source_table}")
                return {"status": "no_data", "migrated_count": 0}

            # Migrate each relationship to the new unified table
            migrated_count = 0
            for rel in existing_data:
                try:
                    # Use MERGE to handle potential duplicates safely
                    result = conn.execute(
                        f"""
                        MATCH (source:{target_from_type} {{id: $source_id}}), (target:Label {{id: $target_id}})
                        MERGE (source)-[r:HAS_LABEL]->(target)
                        ON CREATE SET 
                            r.assigned_by = $assigned_by,
                            r.created_at = $created_at,
                            r.properties = $properties
                        ON MATCH SET
                            r.assigned_by = COALESCE(r.assigned_by, $assigned_by),
                            r.properties = $properties
                        RETURN source.id as source_id, target.id as target_id
                    """,
                        {
                            "source_id": rel["source_external_id"],
                            "target_id": rel["target_id"],
                            "assigned_by": rel["assigned_by"],
                            "created_at": rel["created_at"],
                            "properties": rel["properties"],
                        },
                    )

                    migrated_count += 1

                except Exception as e:
                    logger.warning(f"⚠️ Failed to migrate relationship {rel}: {e}")

            logger.info(
                f"✅ Migrated {migrated_count}/{len(existing_data)} relationships from {source_table}"
            )

            return {
                "status": "success",
                "migrated_count": migrated_count,
                "total_found": len(existing_data),
            }

        except Exception as e:
            logger.error(f"❌ Failed to migrate data from {source_table}: {e}")
            return {"status": "failed", "error": str(e), "migrated_count": 0}

    def cleanup_old_tables(self, conn: kuzu.Connection) -> Dict[str, Any]:
        """Safely clean up old separate HAS_LABEL tables."""
        logger.info("🧹 Cleaning up old separate HAS_LABEL tables")

        old_tables = ["THREAD_HAS_LABEL", "MEMORY_HAS_LABEL", "ENTITY_HAS_LABEL"]
        cleanup_results = []

        for table_name in old_tables:
            try:
                if self.check_table_exists(conn, table_name):
                    conn.execute(f"DROP TABLE IF EXISTS {table_name}")
                    logger.info(f"✅ Dropped old table: {table_name}")
                    cleanup_results.append({"table": table_name, "status": "dropped"})
                else:
                    logger.info(f"ℹ️ Table {table_name} does not exist - skipping")
                    cleanup_results.append({"table": table_name, "status": "not_found"})

            except Exception as e:
                logger.error(f"❌ Failed to drop {table_name}: {e}")
                cleanup_results.append(
                    {"table": table_name, "status": "failed", "error": str(e)}
                )

        return {"cleanup_results": cleanup_results}


# Create the migration instance
migration = HasLabelConsolidationMigration()


def upgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Apply the migration - consolidate HAS_LABEL relationships using multiple FROM-TO."""
    logger.info(
        "🚀 Applying migration 20250709_112227: consolidate_has_label_relationships"
    )

    try:
        # Step 1: Create the new unified HAS_LABEL table
        table_creation = migration.create_unified_has_label_table(conn)

        # Step 2: Migrate data from old separate tables (if they exist)
        migration_results = []

        # Map old table names to their corresponding FROM types
        table_mappings = [
            ("THREAD_HAS_LABEL", "Thread"),
            ("MEMORY_HAS_LABEL", "Memory"),
            ("ENTITY_HAS_LABEL", "Entity"),
        ]

        for old_table, from_type in table_mappings:
            result = migration.migrate_relationship_data(conn, old_table, from_type)
            migration_results.append(
                {"old_table": old_table, "from_type": from_type, **result}
            )

        # Step 3: Clean up old tables
        cleanup_results = migration.cleanup_old_tables(conn)

        logger.info("✅ HAS_LABEL consolidation completed successfully!")
        logger.info("🎯 Benefits achieved:")
        logger.info(
            "  🔹 Single polymorphic HAS_LABEL table with multiple FROM-TO pairs"
        )
        logger.info(
            "  🔹 Unified querying: MATCH (n)-[:HAS_LABEL]->(l) works across all node types"
        )
        logger.info("  🔹 Simplified schema maintenance")
        logger.info("  🔹 KuzuDB automatically handles internal child tables")

        return {
            "migration_applied": True,
            "revision": "20250709_112227",
            "table_creation": table_creation,
            "data_migrations": migration_results,
            "cleanup": cleanup_results,
            "kuzu_features_used": [
                "Multiple FROM-TO pairs in single relationship table",
                "MERGE with ON CREATE/ON MATCH for safe data migration",
                "DROP TABLE IF EXISTS for safe cleanup",
                "Parameterized queries for data migration",
                "SHOW_TABLES() for schema inspection",
            ],
            "schema_improvement": {
                "before": "3 separate tables (THREAD_HAS_LABEL, MEMORY_HAS_LABEL, ENTITY_HAS_LABEL)",
                "after": "1 unified polymorphic table (HAS_LABEL with multiple FROM-TO pairs)",
                "query_simplification": "MATCH (n)-[:HAS_LABEL]->(l) now works across all node types",
            },
        }

    except Exception as e:
        logger.error(f"❌ Migration failed: {e}")
        raise


def downgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Rollback the migration - restore separate HAS_LABEL tables."""
    logger.info(
        "⏪ Rolling back migration 20250709_112227: consolidate_has_label_relationships"
    )

    try:
        # Step 1: Extract data from unified table before dropping
        existing_data = []
        if migration.check_table_exists(conn, "HAS_LABEL"):
            logger.info("📦 Extracting data from unified HAS_LABEL table")

            # Extract relationships by FROM type
            for from_type in ["Thread", "Memory", "Entity"]:
                try:
                    result = conn.execute(f"""
                        MATCH (source:{from_type})-[r:HAS_LABEL]->(target:Label)
                        RETURN 
                            source.id as source_id,
                            target.id as target_id,
                            r.assigned_by as assigned_by,
                            r.created_at as created_at,
                            r.properties as properties
                    """)

                    type_data = []
                    assert isinstance(result, kuzu.QueryResult), (
                        "result must be a kuzu.QueryResult"
                    )
                    while result.has_next():
                        row = result.get_next()
                        type_data.append(
                            {
                                "source_id": row[0],  # type: ignore
                                "target_id": row[1],  # type: ignore
                                "assigned_by": row[2],  # type: ignore
                                "created_at": row[3],  # type: ignore
                                "properties": row[4] or "{}",  # type: ignore
                            }
                        )

                    existing_data.append({"from_type": from_type, "data": type_data})
                    logger.info(
                        f"📦 Extracted {len(type_data)} {from_type} relationships"
                    )

                except Exception as e:
                    logger.warning(f"⚠️ Failed to extract {from_type} data: {e}")

        # Step 2: Drop the unified table
        conn.execute("DROP TABLE IF EXISTS HAS_LABEL")
        logger.info("✅ Dropped unified HAS_LABEL table")

        # Step 3: Recreate separate tables
        restoration_results = []

        separate_tables = [
            ("THREAD_HAS_LABEL", "Thread", "Label"),
            ("MEMORY_HAS_LABEL", "Memory", "Label"),
            ("ENTITY_HAS_LABEL", "Entity", "Label"),
        ]

        for table_name, from_table, to_table in separate_tables:
            try:
                # Create separate table
                conn.execute(f"""
                    CREATE REL TABLE {table_name}(
                        FROM {from_table} TO {to_table},
                        assigned_by STRING,
                        created_at TIMESTAMP DEFAULT current_timestamp(),
                        properties STRING DEFAULT '{{}}'
                    )
                """)

                # Restore data for this table type
                type_data = next(
                    (item for item in existing_data if item["from_type"] == from_table),
                    None,
                )
                restored_count = 0

                if type_data and type_data["data"]:
                    for rel in type_data["data"]:
                        try:
                            conn.execute(
                                f"""
                                MATCH (source:{from_table} {{id: $source_id}}), (target:{to_table} {{id: $target_id}})
                                CREATE (source)-[r:{table_name}]->(target)
                                SET r.assigned_by = $assigned_by,
                                    r.created_at = $created_at,
                                    r.properties = $properties
                            """,
                                {
                                    "source_id": rel["source_id"],
                                    "target_id": rel["target_id"],
                                    "assigned_by": rel["assigned_by"],
                                    "created_at": rel["created_at"],
                                    "properties": rel["properties"],
                                },
                            )
                            restored_count += 1
                        except Exception as e:
                            logger.warning(f"⚠️ Failed to restore relationship: {e}")

                logger.info(
                    f"✅ Restored {table_name} with {restored_count} relationships"
                )
                restoration_results.append(
                    {
                        "table": table_name,
                        "status": "restored",
                        "relationships_count": restored_count,
                    }
                )

            except Exception as e:
                logger.error(f"❌ Failed to restore {table_name}: {e}")
                restoration_results.append(
                    {"table": table_name, "status": "failed", "error": str(e)}
                )

        logger.info("✅ HAS_LABEL relationship rollback completed")

        return {
            "migration_rolled_back": True,
            "revision": "20250709_112227",
            "data_extracted": len(existing_data),
            "tables_restored": restoration_results,
            "schema_restoration": {
                "unified_table_dropped": True,
                "separate_tables_recreated": len(
                    [r for r in restoration_results if r["status"] == "restored"]
                ),
            },
        }

    except Exception as e:
        logger.error(f"❌ Rollback failed: {e}")
        raise
