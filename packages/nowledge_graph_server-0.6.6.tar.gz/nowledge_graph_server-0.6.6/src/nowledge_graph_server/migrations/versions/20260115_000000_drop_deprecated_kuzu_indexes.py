"""Drop deprecated Kuzu indexes and embedding column for slim storage.

Since v2 (cedar), LanceDB handles all vector and full-text search.
This migration:
1. Drops all deprecated Kuzu vector and FTS indexes
2. Drops the Memory.embedding column (no longer needed - LanceDB stores embeddings)

This significantly reduces database size:
- Removes index overhead for unused indexes
- Removes 384 floats (1.5KB) per memory for the embedding column

Dropped indexes:
- memory_embedding_idx_new (vector index on Memory.embedding)
- memory_semantic_index (FTS on Memory.semantic_field)
- entity_content_index (FTS on Entity.name, description)
- thread_content_index (FTS on Thread.title, summary)
- community_summary_search (FTS on Community.name, description, ai_summary)
- message_content_fts (FTS on Message.content)

Dropped columns:
- Memory.embedding (FLOAT[384]) - embeddings now in LanceDB with 1024-dim

Revision ID: 20260115_000000
Revises: 20260104_000000
"""

import structlog
import real_ladybug as kuzu
from typing import Dict, Any

logger = structlog.get_logger(__name__)

# Revision identifiers
revision = "20260115_000000"
down_revision = "20260104_000000"  # Previous: v2_lancedb_search_index


def _try_drop_vector_index(conn: kuzu.Connection, table: str, index_name: str) -> bool:
    """Try to drop a vector index, returning success status."""
    try:
        conn.execute(f"CALL DROP_VECTOR_INDEX('{table}', '{index_name}')")
        logger.info(f"Dropped vector index: {table}.{index_name}")
        return True
    except Exception as e:
        error_msg = str(e).lower()
        if "does not exist" in error_msg or "not found" in error_msg or "doesn't have" in error_msg:
            logger.debug(f"Vector index {index_name} already dropped or never created")
            return True
        logger.warning(f"Failed to drop vector index {index_name}", error=str(e))
        return False


def _try_drop_fts_index(conn: kuzu.Connection, table: str, index_name: str) -> bool:
    """Try to drop an FTS index, returning success status."""
    try:
        conn.execute(f"CALL DROP_FTS_INDEX('{table}', '{index_name}')")
        logger.info(f"Dropped FTS index: {table}.{index_name}")
        return True
    except Exception as e:
        error_msg = str(e).lower()
        if "does not exist" in error_msg or "not found" in error_msg or "doesn't have" in error_msg:
            logger.debug(f"FTS index {index_name} already dropped or never created")
            return True
        logger.warning(f"Failed to drop FTS index {index_name}", error=str(e))
        return False


def upgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Drop deprecated indexes and embedding column for slim storage."""
    logger.info("Slimming Kuzu database - dropping deprecated indexes and embedding column")

    dropped_indexes = 0
    failed_indexes = 0

    # Step 1: Drop vector index first (it depends on embedding column)
    if _try_drop_vector_index(conn, "Memory", "memory_embedding_idx_new"):
        dropped_indexes += 1
    else:
        failed_indexes += 1

    # Step 2: Drop FTS indexes
    fts_indexes = [
        ("Memory", "memory_semantic_index"),
        ("Entity", "entity_content_index"),
        ("Thread", "thread_content_index"),
        ("Community", "community_summary_search"),
        ("Message", "message_content_fts"),
    ]

    for table, index_name in fts_indexes:
        if _try_drop_fts_index(conn, table, index_name):
            dropped_indexes += 1
        else:
            failed_indexes += 1

    # Step 3: Drop the embedding column from Memory table
    embedding_dropped = False
    try:
        conn.execute("ALTER TABLE Memory DROP embedding")
        logger.info("Dropped Memory.embedding column (saves ~1.5KB per memory)")
        embedding_dropped = True
    except Exception as e:
        error_msg = str(e).lower()
        if "does not exist" in error_msg or "not found" in error_msg or "no property" in error_msg:
            logger.debug("Memory.embedding column already dropped")
            embedding_dropped = True
        else:
            logger.warning("Failed to drop Memory.embedding column", error=str(e))

    # Checkpoint to persist changes
    try:
        conn.execute("CHECKPOINT;")
        logger.debug("Checkpoint completed after schema changes")
    except Exception as e:
        logger.warning("Failed to checkpoint", error=str(e))

    logger.info(
        "Finished slimming Kuzu database",
        dropped_indexes=dropped_indexes,
        failed_indexes=failed_indexes,
        embedding_dropped=embedding_dropped,
    )

    return {
        "dropped_indexes": dropped_indexes,
        "failed_indexes": failed_indexes,
        "embedding_dropped": embedding_dropped,
        "revision": revision,
    }


def downgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Restore the embedding column and deprecated indexes (not recommended)."""
    logger.warning("Restoring deprecated schema - this is not recommended")

    # Step 1: Restore embedding column
    try:
        conn.execute("ALTER TABLE Memory ADD embedding FLOAT[384]")
        logger.info("Restored Memory.embedding column")
    except Exception as e:
        if "already exists" not in str(e).lower():
            logger.warning("Failed to restore embedding column", error=str(e))

    # Step 2: Recreate vector index
    try:
        conn.execute("CALL CREATE_VECTOR_INDEX('Memory', 'memory_embedding_idx_new', 'embedding')")
        logger.info("Recreated vector index: Memory.memory_embedding_idx_new")
    except Exception as e:
        if "already exists" not in str(e).lower():
            logger.warning("Failed to recreate vector index", error=str(e))

    # Step 3: Recreate FTS indexes
    fts_recreate = [
        ("Memory", "memory_semantic_index", "['semantic_field']"),
        ("Entity", "entity_content_index", "['name', 'description']"),
        ("Thread", "thread_content_index", "['title', 'summary']"),
        ("Community", "community_summary_search", "['name', 'description', 'ai_summary']"),
        ("Message", "message_content_fts", "['content']"),
    ]

    for table, index_name, columns in fts_recreate:
        try:
            conn.execute(f"CALL CREATE_FTS_INDEX('{table}', '{index_name}', {columns})")
            logger.info(f"Recreated FTS index: {table}.{index_name}")
        except Exception as e:
            if "already exists" not in str(e).lower():
                logger.warning(f"Failed to recreate FTS index {index_name}", error=str(e))

    logger.info("Finished restoring deprecated schema")
    return {"revision": revision}
