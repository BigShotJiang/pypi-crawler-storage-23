"""Migration: Add semantic_field for better indexing and reindex mechanism

Revision ID: 20250714_100422
Revises: 20250714_000000
Create Date: 2025-07-14 10:04:22
"""

# Revision identifiers
revision = "20250714_100422"
down_revision = "20250714_000000"
branch_labels = None
depends_on = None

import real_ladybug as kuzu
import structlog
from typing import Dict, Any

logger = structlog.get_logger()


def upgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Add semantic_field, reindex_needed, and last_reindexed_at columns to Memory table."""
    logger.info(
        "Adding semantic_field columns to Memory table for migration 20250714_100422"
    )

    # Add new columns to Memory table (using KuzuDB syntax)
    # These will succeed silently if columns already exist
    try:
        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS semantic_field STRING")
        logger.info("Added semantic_field column")
    except Exception as e:
        logger.warning(f"semantic_field column may already exist: {e}")

    try:
        conn.execute(
            "ALTER TABLE Memory ADD IF NOT EXISTS reindex_needed BOOLEAN DEFAULT FALSE"
        )
        logger.info("Added reindex_needed column")
    except Exception as e:
        logger.warning(f"reindex_needed column may already exist: {e}")

    try:
        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS last_reindexed_at TIMESTAMP")
        logger.info("Added last_reindexed_at column")
    except Exception as e:
        logger.warning(f"last_reindexed_at column may already exist: {e}")

    # Try to initialize semantic_field, but handle index conflicts gracefully
    # This is the simplest and most robust approach
    try:
        result = conn.execute(
            "MATCH (m:Memory) WHERE m.semantic_field IS NOT NULL RETURN count(m) as count"
        )
        assert isinstance(result, kuzu.QueryResult), "Result is not a QueryResult"
        row = result.get_next()
        existing_count = row[0] if row else 0  # type: ignore

        logger.info(
            f"Found {existing_count} memories with existing semantic_field data"
        )

        if existing_count == 0:
            logger.info("Attempting to initialize semantic_field with existing data")
            try:
                # Try to initialize semantic_field with title + content for existing memories
                conn.execute("""
                    MATCH (m:Memory)
                    SET m.semantic_field = COALESCE(m.title, '') + ' ' + COALESCE(m.content, ''),
                        m.reindex_needed = FALSE,
                        m.last_reindexed_at = CURRENT_TIMESTAMP()
                """)
                logger.info("✅ Semantic field initialization completed successfully")
            except Exception as e:
                if "used in one or more indexes" in str(e):
                    logger.info(
                        "⚠️ Skipping semantic_field initialization - field is indexed (normal after db init)"
                    )
                    logger.info(
                        "This is expected when running migrations after db init creates indexes"
                    )
                else:
                    logger.error(f"Failed to initialize semantic_field: {e}")
        else:
            logger.info("Semantic field already has data, ensuring metadata is set")
            try:
                # Just ensure reindex_needed and last_reindexed_at are set
                conn.execute("""
                    MATCH (m:Memory) 
                    WHERE m.reindex_needed IS NULL OR m.last_reindexed_at IS NULL
                    SET m.reindex_needed = FALSE,
                        m.last_reindexed_at = CURRENT_TIMESTAMP()
                """)
                logger.info("Updated missing reindex metadata")
            except Exception as e:
                if "used in one or more indexes" in str(e):
                    logger.info("⚠️ Skipping metadata update - fields are indexed")
                else:
                    logger.warning(f"Could not update reindex metadata: {e}")

    except Exception as e:
        logger.error(f"Failed to check semantic_field status: {e}")
        # Don't fail the migration for this

    logger.info("Semantic field migration completed")
    return {
        "columns_added": 3,
        "memories_updated": "attempted_with_index_handling",
        "revision": "20250714_100422",
    }


def downgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Remove semantic_field, reindex_needed, and last_reindexed_at columns from Memory table."""
    logger.info(
        "Removing semantic_field columns from Memory table for migration 20250714_100422"
    )

    # Remove the columns (KuzuDB supports DROP property)
    conn.execute("ALTER TABLE Memory DROP semantic_field")
    conn.execute("ALTER TABLE Memory DROP reindex_needed")
    conn.execute("ALTER TABLE Memory DROP last_reindexed_at")

    logger.info("Semantic field columns removed")
    return {"columns_removed": 3, "revision": "20250714_100422"}
