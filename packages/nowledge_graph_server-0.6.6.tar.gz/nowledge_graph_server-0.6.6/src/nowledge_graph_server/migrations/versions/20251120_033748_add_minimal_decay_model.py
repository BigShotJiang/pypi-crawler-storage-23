"""Migration: add_minimal_decay_model_and_bitemporal

Revision ID: 20251120_033748
Revises: 20251020_133355
Create Date: 2025-11-20 03:37:48

Adds minimal practical decay model + bi-temporal fields to Memory and Entity tables.
Based on DECAY_MODEL_STUDY.md and BITEMPORAL_MODEL_STUDY.md.

DECAY MODEL fields (Memory):
- last_accessed_at: When memory was last shown/clicked
- access_count: Total number of accesses (for frequency boost)
- appearances: Times shown in search results
- clicks: Times clicked/opened by user
- total_dwell_time_ms: Total time spent reading (milliseconds)
- last_clicked_at: Last time user clicked/opened
- decay_score_cached: Pre-computed decay score (0-1)

BI-TEMPORAL fields (Memory):
- temporal_type: "exact"|"range"|"unknown"
- event_start: When event occurred (normalized DATE)
- event_end: When event ended (for ranges)
- temporal_precision: "year"|"month"|"day" (for UI display)
- temporal_confidence: LLM confidence (0-1)
- temporal_context: "past"|"present"|"future"|"timeless"

BI-TEMPORAL fields (Entity):
- entity_created: When entity was created/born/founded (normalized DATE)
- entity_ended: When entity died/closed/discontinued
- temporal_precision: "year"|"month"|"day" (for UI display)
- temporal_confidence: LLM confidence (0-1)
- temporal_context: "past"|"present"|"timeless"

Note: Relationship temporal fields will be added as properties when creating relationships.
"""

# Revision identifiers
revision = "20251120_033748"
down_revision = "20251020_133355"
branch_labels = None
depends_on = None

import real_ladybug as kuzu
import structlog
from typing import Dict, Any
import math
from datetime import datetime, timezone

logger = structlog.get_logger()

# ==============================================================================
# HYPERPARAMETERS (tunable)
# ==============================================================================

# Recency decay half-life in days
# This represents the system's "patience" - how long before memories start fading
# If system forgets too quickly, increase this number
# If system is too cluttered with old memories, decrease it
HALF_LIFE_DAYS = 30

# Importance floor formula: 0.3 + (importance * IMPORTANCE_MULTIPLIER)
# Adjusted from 0.4 to 0.2 based on feedback to prevent important memories from dominating
# This gives range 0.3-0.5 instead of 0.3-0.7
IMPORTANCE_MULTIPLIER = 0.2

# Decay weight in final scoring (blend with semantic score)
# Reduced from 0.2 to 0.15 based on feedback (15% influence, more conservative)
DECAY_WEIGHT = 0.15


def upgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Apply the migration: Add decay model and bi-temporal fields."""
    logger.info("Applying migration 20251120_033748: add_minimal_decay_model_and_bitemporal")

    try:
        # ======================================================================
        # Step 1: Add decay model columns to Memory table
        # ======================================================================
        logger.info("Step 1/5: Adding decay model columns to Memory table")

        # Core decay fields
        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS last_accessed_at TIMESTAMP")
        logger.info("  ✓ Added last_accessed_at")

        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS access_count INT64")
        logger.info("  ✓ Added access_count")

        # Feedback tracking fields
        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS appearances INT64")
        logger.info("  ✓ Added appearances")

        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS clicks INT64")
        logger.info("  ✓ Added clicks")

        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS total_dwell_time_ms INT64")
        logger.info("  ✓ Added total_dwell_time_ms")

        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS last_clicked_at TIMESTAMP")
        logger.info("  ✓ Added last_clicked_at")

        # Cached decay score
        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS decay_score_cached DOUBLE")
        logger.info("  ✓ Added decay_score_cached")

        # ======================================================================
        # Step 2: Add bi-temporal fields to Memory table
        # ======================================================================
        logger.info("Step 2/5: Adding bi-temporal fields to Memory table")

        # Temporal context (shared with decay model)
        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS temporal_context STRING")
        logger.info("  ✓ Added temporal_context")

        # Bi-temporal fields (replacing event_year with structured temporal)
        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS temporal_type STRING")
        logger.info("  ✓ Added temporal_type")

        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS event_start DATE")
        logger.info("  ✓ Added event_start")

        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS event_end DATE")
        logger.info("  ✓ Added event_end")

        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS temporal_precision STRING")
        logger.info("  ✓ Added temporal_precision")

        conn.execute("ALTER TABLE Memory ADD IF NOT EXISTS temporal_confidence DOUBLE")
        logger.info("  ✓ Added temporal_confidence")

        # ======================================================================
        # Step 3: Add bi-temporal fields to Entity table
        # ======================================================================
        logger.info("Step 3/5: Adding bi-temporal fields to Entity table")

        conn.execute("ALTER TABLE Entity ADD IF NOT EXISTS entity_created DATE")
        logger.info("  ✓ Added entity_created")

        conn.execute("ALTER TABLE Entity ADD IF NOT EXISTS entity_ended DATE")
        logger.info("  ✓ Added entity_ended")

        conn.execute("ALTER TABLE Entity ADD IF NOT EXISTS temporal_precision STRING")
        logger.info("  ✓ Added temporal_precision")

        conn.execute("ALTER TABLE Entity ADD IF NOT EXISTS temporal_confidence DOUBLE")
        logger.info("  ✓ Added temporal_confidence")

        conn.execute("ALTER TABLE Entity ADD IF NOT EXISTS temporal_context STRING")
        logger.info("  ✓ Added temporal_context")

        # ======================================================================
        # Step 4: Initialize existing memories with default values
        # ======================================================================
        logger.info("Step 4/5: Initializing existing memories with default values")

        # Note: We can't use DEFAULT in ALTER TABLE with Kuzu, so we initialize via UPDATE
        # Set last_accessed_at = created_at for existing memories (assume they were "accessed" when created)
        # This prevents sudden massive decay for all existing memories
        try:
            conn.execute("""
                MATCH (m:Memory)
                WHERE m.last_accessed_at IS NULL
                SET m.last_accessed_at = m.created_at,
                    m.access_count = 0,
                    m.appearances = 0,
                    m.clicks = 0,
                    m.total_dwell_time_ms = 0,
                    m.decay_score_cached = 1.0,
                    m.temporal_context = 'timeless',
                    m.temporal_type = 'unknown'
            """)
            logger.info("  ✓ Initialized existing memories with defaults")
        except Exception as e:
            # If this fails (e.g., due to indexing), log warning but don't fail migration
            logger.warning(
                "Could not initialize existing memories - may need manual update",
                error=str(e)
            )

        # Initialize existing entities with default temporal values
        try:
            conn.execute("""
                MATCH (e:Entity)
                WHERE e.temporal_context IS NULL
                SET e.temporal_context = 'timeless'
            """)
            logger.info("  ✓ Initialized existing entities with defaults")
        except Exception as e:
            logger.warning(
                "Could not initialize existing entities - may need manual update",
                error=str(e)
            )

        # ======================================================================
        # Step 5: Checkpoint to flush WAL
        # ======================================================================
        logger.info("Step 5/5: Checkpointing to flush WAL")
        conn.execute("CHECKPOINT;")
        logger.info("  ✓ Checkpoint completed")

        logger.info("✅ Migration 20251120_033748 completed successfully")

        return {
            "status": "success",
            "message": "Added decay model and bi-temporal fields to Memory and Entity tables",
            "memory_fields_added": 12,  # 7 decay + 5 bi-temporal
            "entity_fields_added": 5,   # 5 bi-temporal
            "total_fields_added": 17,
            "hyperparameters": {
                "half_life_days": HALF_LIFE_DAYS,
                "importance_multiplier": IMPORTANCE_MULTIPLIER,
                "decay_weight": DECAY_WEIGHT,
            },
        }

    except Exception as e:
        logger.error("Failed to add decay model fields to Memory table", error=str(e))
        return {"status": "error", "error": str(e)}


def downgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Rollback the migration: Remove decay model and bi-temporal fields."""
    logger.info("Rolling back migration 20251120_033748: add_minimal_decay_model_and_bitemporal")

    try:
        # ======================================================================
        # Remove Entity bi-temporal fields (in reverse order)
        # ======================================================================
        logger.info("Step 1/3: Removing bi-temporal fields from Entity table")

        conn.execute("ALTER TABLE Entity DROP temporal_context")
        logger.info("  ✓ Dropped temporal_context")

        conn.execute("ALTER TABLE Entity DROP temporal_confidence")
        logger.info("  ✓ Dropped temporal_confidence")

        conn.execute("ALTER TABLE Entity DROP temporal_precision")
        logger.info("  ✓ Dropped temporal_precision")

        conn.execute("ALTER TABLE Entity DROP entity_ended")
        logger.info("  ✓ Dropped entity_ended")

        conn.execute("ALTER TABLE Entity DROP entity_created")
        logger.info("  ✓ Dropped entity_created")

        # ======================================================================
        # Remove Memory bi-temporal fields
        # ======================================================================
        logger.info("Step 2/3: Removing bi-temporal fields from Memory table")

        conn.execute("ALTER TABLE Memory DROP temporal_confidence")
        logger.info("  ✓ Dropped temporal_confidence")

        conn.execute("ALTER TABLE Memory DROP temporal_precision")
        logger.info("  ✓ Dropped temporal_precision")

        conn.execute("ALTER TABLE Memory DROP event_end")
        logger.info("  ✓ Dropped event_end")

        conn.execute("ALTER TABLE Memory DROP event_start")
        logger.info("  ✓ Dropped event_start")

        conn.execute("ALTER TABLE Memory DROP temporal_type")
        logger.info("  ✓ Dropped temporal_type")

        conn.execute("ALTER TABLE Memory DROP temporal_context")
        logger.info("  ✓ Dropped temporal_context")

        # ======================================================================
        # Remove Memory decay model fields
        # ======================================================================
        logger.info("Step 3/3: Removing decay model fields from Memory table")

        conn.execute("ALTER TABLE Memory DROP decay_score_cached")
        logger.info("  ✓ Dropped decay_score_cached")

        conn.execute("ALTER TABLE Memory DROP last_clicked_at")
        logger.info("  ✓ Dropped last_clicked_at")

        conn.execute("ALTER TABLE Memory DROP total_dwell_time_ms")
        logger.info("  ✓ Dropped total_dwell_time_ms")

        conn.execute("ALTER TABLE Memory DROP clicks")
        logger.info("  ✓ Dropped clicks")

        conn.execute("ALTER TABLE Memory DROP appearances")
        logger.info("  ✓ Dropped appearances")

        conn.execute("ALTER TABLE Memory DROP access_count")
        logger.info("  ✓ Dropped access_count")

        conn.execute("ALTER TABLE Memory DROP last_accessed_at")
        logger.info("  ✓ Dropped last_accessed_at")

        # Checkpoint
        conn.execute("CHECKPOINT;")
        logger.info("  ✓ Checkpoint completed")

        logger.info("✅ Rollback 20251120_033748 completed successfully")

        return {
            "status": "success",
            "message": "Removed decay model and bi-temporal fields from Memory and Entity tables",
            "memory_fields_removed": 12,  # 7 decay + 5 bi-temporal
            "entity_fields_removed": 5,   # 5 bi-temporal
            "total_fields_removed": 17,
        }

    except Exception as e:
        logger.error(
            "Failed to remove fields from Memory/Entity tables", error=str(e)
        )
        return {"status": "error", "error": str(e)}
