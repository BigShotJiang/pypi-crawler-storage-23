"""Add graph augmentation state tracking

Revision ID: 20250714_160000
Revises: 20250714_150418
Create Date: 2025-07-14 16:00:00.000000

"""

from typing import Dict, Any
import real_ladybug as kuzu
import structlog

# revision identifiers, used by migration system
revision = "20250714_160000"
down_revision = "20250714_150418"
branch_labels = None
depends_on = None

logger = structlog.get_logger(__name__)


def upgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """
    Add graph augmentation state tracking:
    1. Create GraphMeta node for global state
    2. Add community_id and pagerank_score properties to Memory and Entity nodes
    3. Create Community nodes for community augmentation
    4. Create background job tracking
    """
    try:
        changes = []

        # 1. Create GraphMeta node table for global state
        logger.info("Creating GraphMeta node table for global state tracking")
        conn.execute("""
            CREATE NODE TABLE IF NOT EXISTS GraphMeta(
                meta_id STRING PRIMARY KEY,
                community_detection_applied BOOLEAN DEFAULT false,
                pagerank_applied BOOLEAN DEFAULT false,
                community_algorithm STRING DEFAULT '',
                community_resolution DOUBLE DEFAULT 1.0,
                community_count INT64 DEFAULT 0,
                pagerank_algorithm STRING DEFAULT '',
                pagerank_damping DOUBLE DEFAULT 0.85,
                pagerank_iterations INT64 DEFAULT 0,
                last_augmentation_at TIMESTAMP,
                schema_version STRING DEFAULT '1.0.0',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP(),
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
            )
        """)
        changes.append("Created GraphMeta node table")

        # Insert default meta node
        logger.info("Inserting default GraphMeta node")
        conn.execute("""
            CREATE (m:GraphMeta {
                meta_id: 'main',
                community_detection_applied: false,
                pagerank_applied: false,
                community_algorithm: '',
                community_resolution: 1.0,
                community_count: 0,
                pagerank_algorithm: '',
                pagerank_damping: 0.85,
                pagerank_iterations: 0,
                schema_version: '1.0.0'
            })
        """)
        changes.append("Created default GraphMeta node")

        # 2. Add community_id and pagerank_score to Memory nodes
        logger.info("Adding augmentation properties to Memory nodes")
        conn.execute("""
            ALTER TABLE Memory 
            ADD IF NOT EXISTS community_id INT64 DEFAULT NULL
        """)
        conn.execute("""
            ALTER TABLE Memory 
            ADD IF NOT EXISTS pagerank_score DOUBLE DEFAULT 0.0
        """)
        changes.append("Added community_id and pagerank_score to Memory nodes")

        # 3. Add community_id and pagerank_score to Entity nodes
        logger.info("Adding augmentation properties to Entity nodes")
        conn.execute("""
            ALTER TABLE Entity 
            ADD IF NOT EXISTS community_id INT64 DEFAULT NULL
        """)
        conn.execute("""
            ALTER TABLE Entity 
            ADD IF NOT EXISTS pagerank_score DOUBLE DEFAULT 0.0
        """)
        changes.append("Added community_id and pagerank_score to Entity nodes")

        # 4. Create Community node table for community augmentation
        logger.info("Creating Community node table")
        conn.execute("""
            CREATE NODE TABLE IF NOT EXISTS Community(
                community_id INT64 PRIMARY KEY,
                name STRING DEFAULT '',
                description STRING DEFAULT '',
                ai_summary STRING DEFAULT '',
                member_count INT64 DEFAULT 0,
                algorithm STRING DEFAULT 'louvain',
                resolution DOUBLE DEFAULT 1.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP(),
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
            )
        """)
        changes.append("Created Community node table")

        # 5. Create background job tracking
        logger.info("Creating AugmentationJob node table for background job tracking")
        conn.execute("""
            CREATE NODE TABLE IF NOT EXISTS AugmentationJob(
                job_id STRING PRIMARY KEY,
                job_type STRING,
                status STRING DEFAULT 'pending',
                progress DOUBLE DEFAULT 0.0,
                message STRING DEFAULT '',
                parameters STRING DEFAULT '{}',
                result STRING DEFAULT '{}',
                error_message STRING DEFAULT '',
                started_at TIMESTAMP,
                completed_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
            )
        """)
        changes.append("Created AugmentationJob node table")

        logger.info("Successfully added graph augmentation state tracking")

        return {
            "success": True,
            "message": "Added graph augmentation state tracking",
            "changes": changes,
        }

    except Exception as e:
        logger.error(f"Failed to add graph augmentation state tracking: {e}")
        return {
            "success": False,
            "message": f"Failed to add augmentation state tracking: {e}",
            "error": str(e),
        }


def downgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """
    Remove graph augmentation state tracking.
    """
    try:
        changes = []

        logger.info("Removing graph augmentation state tracking")

        # Remove job tracking
        conn.execute("DROP TABLE IF EXISTS AugmentationJob")
        changes.append("Removed AugmentationJob table")

        # Remove community nodes
        conn.execute("DROP TABLE IF EXISTS Community")
        changes.append("Removed Community table")

        # Remove properties from Entity nodes
        conn.execute("ALTER TABLE Entity DROP IF EXISTS community_id")
        conn.execute("ALTER TABLE Entity DROP IF EXISTS pagerank_score")
        changes.append("Removed augmentation properties from Entity nodes")

        # Remove properties from Memory nodes
        conn.execute("ALTER TABLE Memory DROP IF EXISTS community_id")
        conn.execute("ALTER TABLE Memory DROP IF EXISTS pagerank_score")
        changes.append("Removed augmentation properties from Memory nodes")

        # Remove meta node
        conn.execute("DROP TABLE IF EXISTS GraphMeta")
        changes.append("Removed GraphMeta table")

        logger.info("Successfully removed graph augmentation state tracking")

        return {
            "success": True,
            "message": "Removed graph augmentation state tracking",
            "changes": changes,
        }

    except Exception as e:
        logger.error(f"Failed to remove graph augmentation state tracking: {e}")
        return {
            "success": False,
            "message": f"Failed to remove augmentation state tracking: {e}",
            "error": str(e),
        }
