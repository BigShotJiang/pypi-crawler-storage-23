"""Add Source node table and SOURCED_FROM / REVISED_AS relationships.

Sources are external artifacts (files, URLs, notes) that feed the knowledge
graph. Each source goes through a lifecycle: ingested → parsed → chunked →
indexed → extracted. Memories link back to their source via SOURCED_FROM
for provenance. REVISED_AS tracks version history between source revisions.

Revision ID: 20260212_143000
Revises: 20260209_120000
"""

from __future__ import annotations

from typing import Any, Dict

import real_ladybug as kuzu
import structlog

logger = structlog.get_logger(__name__)

revision = "20260212_143000"
down_revision = "20260209_120000"


def upgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Create Source table and relationship tables."""
    logger.info("Applying migration 20260212_143000: add Source table + relationships")

    try:
        # ======================================================================
        # Step 1: Create Source node table
        # ======================================================================
        logger.info("Step 1/4: Creating Source node table")

        conn.execute("""
            CREATE NODE TABLE IF NOT EXISTS Source(
                id STRING,
                source_type STRING,
                original_name STRING,
                mime_type STRING,
                file_path STRING,
                parsed_path STRING,
                source_url STRING,
                sha256 STRING,
                size_bytes INT64 DEFAULT 0,
                version INT64 DEFAULT 1,
                lifecycle_state STRING DEFAULT 'ingested',
                chunk_count INT64 DEFAULT 0,
                memory_count INT64 DEFAULT 0,
                section_tree STRING,
                summary STRING,
                error_message STRING,
                created_at TIMESTAMP,
                updated_at TIMESTAMP,
                metadata STRING,
                PRIMARY KEY (id)
            )
        """)

        # ======================================================================
        # Step 2: Create SOURCED_FROM relationship (Memory → Source)
        # ======================================================================
        logger.info("Step 2/4: Creating SOURCED_FROM relationship table")

        conn.execute("""
            CREATE REL TABLE IF NOT EXISTS SOURCED_FROM(
                FROM Memory TO Source,
                chunk_index INT64,
                chunk_range STRING,
                source_version INT64,
                created_at TIMESTAMP
            )
        """)

        # ======================================================================
        # Step 3: Create REVISED_AS relationship (Source → Source)
        # ======================================================================
        logger.info("Step 3/4: Creating REVISED_AS relationship table")

        conn.execute("""
            CREATE REL TABLE IF NOT EXISTS REVISED_AS(
                FROM Source TO Source,
                diff_summary STRING,
                sections_changed STRING,
                revision_type STRING,
                detected_by STRING,
                created_at TIMESTAMP
            )
        """)

        # ======================================================================
        # Step 4: Checkpoint to flush WAL
        # ======================================================================
        logger.info("Step 4/4: Checkpointing to flush WAL")
        conn.execute("CHECKPOINT;")

        return {
            "status": "success",
            "message": "Added Source table with SOURCED_FROM and REVISED_AS relationships",
            "tables_created": ["Source", "SOURCED_FROM", "REVISED_AS"],
        }

    except Exception as e:
        logger.error("Failed to apply migration 20260212_143000", error=str(e))
        return {"status": "error", "error": str(e)}


def downgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Remove Source table and relationships."""
    logger.info("Rolling back migration 20260212_143000: remove Source table")

    try:
        # Drop in reverse order (relationships before nodes)
        logger.info("Step 1/3: Dropping REVISED_AS relationship")
        try:
            conn.execute("DROP TABLE IF EXISTS REVISED_AS")
        except Exception as e:
            logger.warning(f"Failed to drop REVISED_AS: {e}")

        logger.info("Step 2/3: Dropping SOURCED_FROM relationship")
        try:
            conn.execute("DROP TABLE IF EXISTS SOURCED_FROM")
        except Exception as e:
            logger.warning(f"Failed to drop SOURCED_FROM: {e}")

        logger.info("Step 3/3: Dropping Source node table")
        try:
            conn.execute("DROP TABLE IF EXISTS Source")
        except Exception as e:
            logger.warning(f"Failed to drop Source: {e}")

        conn.execute("CHECKPOINT;")

        return {
            "status": "success",
            "message": "Removed Source table and relationships",
        }

    except Exception as e:
        logger.error("Failed to rollback migration 20260212_143000", error=str(e))
        return {"status": "error", "error": str(e)}
