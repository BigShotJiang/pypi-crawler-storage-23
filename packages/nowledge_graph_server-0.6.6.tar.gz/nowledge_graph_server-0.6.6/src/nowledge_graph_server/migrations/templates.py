"""Migration templates and generation utilities."""

from datetime import datetime
from pathlib import Path
from typing import Optional
import structlog

logger = structlog.get_logger()


def generate_revision_id() -> str:
    """Generate a timestamp-based revision ID."""
    now = datetime.now()
    return now.strftime("%Y%m%d_%H%M%S")


def get_latest_revision(migration_dir: Path) -> Optional[str]:
    """Get the latest migration revision from the migration directory."""
    if not migration_dir.exists():
        return None

    migration_files = sorted(
        migration_dir.glob("*.py"), key=lambda x: x.name, reverse=True
    )

    for file_path in migration_files:
        if file_path.name.startswith("__"):
            continue
        # Extract revision from filename
        name_parts = file_path.name.replace(".py", "").split("_", 2)
        if len(name_parts) >= 2:
            return f"{name_parts[0]}_{name_parts[1]}"

    return None


def create_migration_template(
    description: str,
    migration_dir: Path,
    revision_id: Optional[str] = None,
    down_revision: Optional[str] = None,
    template_type: str = "default",
) -> Path:
    """Create a new migration file from template."""

    # Generate revision ID if not provided
    if not revision_id:
        revision_id = generate_revision_id()

    # Get down_revision if not provided
    if down_revision is None:
        down_revision = get_latest_revision(migration_dir)

    # Create migration directory if it doesn't exist
    migration_dir.mkdir(parents=True, exist_ok=True)

    # Clean description for filename
    clean_description = description.lower().replace(" ", "_").replace("-", "_")
    clean_description = "".join(c for c in clean_description if c.isalnum() or c == "_")

    # Create filename
    filename = f"{revision_id}_{clean_description}.py"
    file_path = migration_dir / filename

    # Select template content
    if template_type == "default":
        content = _get_default_template(revision_id, down_revision, description)
    elif template_type == "table_creation":
        content = _get_table_creation_template(revision_id, down_revision, description)
    elif template_type == "data_migration":
        content = _get_data_migration_template(revision_id, down_revision, description)
    else:
        content = _get_default_template(revision_id, down_revision, description)

    # Write the migration file
    with open(file_path, "w") as f:
        f.write(content)

    logger.info(f"Created migration file: {file_path}")
    return file_path


def _get_default_template(
    revision_id: str, down_revision: Optional[str], description: str
) -> str:
    """Get the default migration template."""
    down_rev_str = f'"{down_revision}"' if down_revision else "None"

    return f'''"""Migration: {description}

Revision ID: {revision_id}
Revises: {down_revision or "None"}
Create Date: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
"""

# Revision identifiers
revision = '{revision_id}'
down_revision = {down_rev_str}
branch_labels = None
depends_on = None

import real_ladybug as kuzu
import structlog
from typing import Dict, Any

logger = structlog.get_logger()


def upgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Apply the migration."""
    logger.info("Applying migration {revision_id}: {description}")
    
    # TODO: Implement upgrade logic here
    # Example:
    # conn.execute("""
    #     CREATE NODE TABLE NewTable(
    #         id STRING,
    #         name STRING,
    #         PRIMARY KEY (id)
    #     )
    # """)
    
    return {{"migration_applied": True, "revision": "{revision_id}"}}


def downgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Rollback the migration."""
    logger.info("Rolling back migration {revision_id}: {description}")
    
    # TODO: Implement downgrade logic here
    # Example:
    # conn.execute("DROP TABLE NewTable")
    
    return {{"migration_rolled_back": True, "revision": "{revision_id}"}}
'''


def _get_table_creation_template(
    revision_id: str, down_revision: Optional[str], description: str
) -> str:
    """Get template for table creation migration."""
    down_rev_str = f'"{down_revision}"' if down_revision else "None"

    return f'''"""Migration: {description}

Revision ID: {revision_id}
Revises: {down_revision or "None"}
Create Date: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
"""

# Revision identifiers
revision = '{revision_id}'
down_revision = {down_rev_str}
branch_labels = None
depends_on = None

import real_ladybug as kuzu
import structlog
from typing import Dict, Any

logger = structlog.get_logger()


def upgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Create new table(s)."""
    logger.info("Creating table for migration {revision_id}: {description}")
    
    # TODO: Replace with your table creation logic
    conn.execute("""
        CREATE NODE TABLE IF NOT EXISTS NewTable(
            id STRING,
            name STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP,
            metadata STRING,
            PRIMARY KEY (id)
        )
    """)
    
    # TODO: Create any relationship tables
    # conn.execute("""
    #     CREATE REL TABLE IF NOT EXISTS NewRelation(
    #         FROM NodeA TO NodeB,
    #         relation_type STRING,
    #         properties STRING
    #     )
    # """)
    
    logger.info("Table creation completed")
    return {{"tables_created": 1, "revision": "{revision_id}"}}


def downgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Drop the table(s)."""
    logger.info("Dropping table for migration {revision_id}: {description}")
    
    # TODO: Replace with your table drop logic
    # Note: Be careful with DROP operations in production
    conn.execute("DROP TABLE NewTable")
    
    logger.info("Table drop completed")
    return {{"tables_dropped": 1, "revision": "{revision_id}"}}
'''


def _get_data_migration_template(
    revision_id: str, down_revision: Optional[str], description: str
) -> str:
    """Get template for data migration."""
    down_rev_str = f'"{down_revision}"' if down_revision else "None"

    return f'''"""Migration: {description}

Revision ID: {revision_id}
Revises: {down_revision or "None"}
Create Date: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
"""

# Revision identifiers
revision = '{revision_id}'
down_revision = {down_rev_str}
branch_labels = None
depends_on = None

import real_ladybug as kuzu
import structlog
import json
from typing import Dict, Any
from datetime import datetime

logger = structlog.get_logger()


def upgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Apply data migration."""
    logger.info("Applying data migration {revision_id}: {description}")
    
    migrated_count = 0
    
    # TODO: Implement your data migration logic
    # Example: Migrate data from one format to another
    # result = conn.execute("MATCH (n:OldFormat) RETURN n")
    # 
    # while result.has_next():
    #     row = result.get_next()
    #     old_node = row[0]
    #     
    #     # Transform data
    #     new_data = transform_data(old_node)
    #     
    #     # Update or create new nodes
    #     conn.execute("""
    #         CREATE (n:NewFormat {{
    #             id: $id,
    #             data: $data,
    #             migrated_at: $migrated_at
    #         }})
    #     """, {{
    #         "id": new_data["id"],
    #         "data": json.dumps(new_data),
    #         "migrated_at": datetime.now()
    #     }})
    #     
    #     migrated_count += 1
    
    logger.info(f"Data migration completed: {{migrated_count}} records migrated")
    return {{"records_migrated": migrated_count, "revision": "{revision_id}"}}


def downgrade(conn: kuzu.Connection) -> Dict[str, Any]:
    """Rollback data migration."""
    logger.info("Rolling back data migration {revision_id}: {description}")
    
    # TODO: Implement rollback logic
    # This might involve restoring original data format
    # or removing migrated data
    
    # Example:
    # conn.execute("MATCH (n:NewFormat) DELETE n")
    
    return {{"migration_rolled_back": True, "revision": "{revision_id}"}}


def transform_data(old_data):
    """Transform data from old format to new format."""
    # TODO: Implement your data transformation logic
    return {{
        "id": old_data.get("id"),
        "transformed_field": old_data.get("old_field"),
        # Add more transformations as needed
    }}
'''
