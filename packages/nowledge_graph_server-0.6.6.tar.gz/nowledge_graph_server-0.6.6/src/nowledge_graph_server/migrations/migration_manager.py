"""File-based migration manager."""

import real_ladybug as kuzu
import structlog
from typing import List, Dict, Any, Optional
from pathlib import Path
from datetime import datetime

from .file_migration import FileMigration
from .env import migration_env

logger = structlog.get_logger()


class MigrationError(Exception):
    """Exception raised for migration-related errors."""

    pass


class MigrationManager:
    """Manages file-based database migrations."""

    def __init__(self, db_path: Path):
        self.migration_env = migration_env
        if db_path:
            self.migration_env.db_path = db_path
        self._migrations_cache = None

    async def initialize(self):
        """Initialize migration tracking table."""
        conn = await self.migration_env.get_connection()

        try:
            # Ensure extensions are loaded before any migration operations
            from ..database.base_client import ensure_kuzu_extensions

            ensure_kuzu_extensions(
                conn, raise_on_failure=False
            )  # Don't fail on extension issues during init

            # Create migration tracking table if it doesn't exist
            conn.execute("""
                CREATE NODE TABLE IF NOT EXISTS MigrationHistory(
                    revision STRING,
                    description STRING,
                    applied_at TIMESTAMP,
                    execution_time DOUBLE,
                    success BOOLEAN,
                    rollback_available BOOLEAN,
                    PRIMARY KEY (revision)
                )
            """)
            logger.debug("Migration tracking initialized")
        except Exception as e:
            logger.error(f"Failed to initialize migration tracking: {e}")
            raise

    def discover_migrations(self) -> List[FileMigration]:
        """Auto-discover all migration files."""
        if self._migrations_cache is not None:
            return self._migrations_cache

        migration_files = self.migration_env.get_migration_files()
        migrations = []

        for file_path in migration_files:
            try:
                migration = FileMigration(file_path)
                migrations.append(migration)
            except Exception as e:
                logger.warning(f"Skipping invalid migration file {file_path}: {e}")

        # Sort by revision (timestamp-based)
        migrations.sort(key=lambda m: m.revision)

        self._migrations_cache = migrations
        return migrations

    def clear_cache(self):
        """Clear the migrations cache to force rediscovery."""
        self._migrations_cache = None

    async def get_applied_migrations(self) -> List[str]:
        """Get list of applied migration revisions."""
        conn = await self.migration_env.get_connection()

        try:
            result = conn.execute("""
                MATCH (m:MigrationHistory) 
                WHERE m.success = true 
                RETURN m.revision 
                ORDER BY m.applied_at
            """)

            applied = []
            assert isinstance(result, kuzu.QueryResult)
            while result.has_next():
                row = result.get_next()
                applied.append(row[0])  # type: ignore

            return applied

        except Exception as e:
            logger.warning(f"Could not get applied migrations: {e}")
            return []

    async def is_migration_applied(self, revision: str) -> bool:
        """Check if a specific migration has been applied."""
        applied = await self.get_applied_migrations()
        return revision in applied

    async def apply_migration(self, migration: FileMigration) -> Dict[str, Any]:
        """Apply a single migration."""
        conn = await self.migration_env.get_connection()

        if await self.is_migration_applied(migration.revision):
            logger.debug(f"Migration {migration.revision} already applied, skipping")
            return {"status": "already_applied", "revision": migration.revision}

        start_time = datetime.now()

        try:
            # Apply the migration
            result = await migration.upgrade(conn)

            execution_time = (datetime.now() - start_time).total_seconds()

            # Record successful application
            conn.execute(
                """
                MERGE (m:MigrationHistory {revision: $revision})
                ON CREATE SET 
                    m.description = $description,
                    m.applied_at = $applied_at,
                    m.execution_time = $execution_time,
                    m.success = $success,
                    m.rollback_available = $rollback_available
                ON MATCH SET
                    m.description = $description,
                    m.applied_at = $applied_at,
                    m.execution_time = $execution_time,
                    m.success = $success,
                    m.rollback_available = $rollback_available
            """,
                {
                    "revision": migration.revision,
                    "description": migration.description,
                    "applied_at": start_time,
                    "execution_time": execution_time,
                    "success": True,
                    "rollback_available": True,
                },
            )

            result.update(
                {
                    "status": "applied",
                    "revision": migration.revision,
                    "execution_time": execution_time,
                }
            )

            logger.debug(f"Migration {migration.revision} applied successfully")
            return result

        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds()

            # Record failed application
            try:
                conn.execute(
                    """
                    MERGE (m:MigrationHistory {revision: $revision})
                    ON CREATE SET 
                        m.description = $description,
                        m.applied_at = $applied_at,
                        m.execution_time = $execution_time,
                        m.success = $success,
                        m.rollback_available = $rollback_available
                    ON MATCH SET
                        m.description = $description,
                        m.applied_at = $applied_at,
                        m.execution_time = $execution_time,
                        m.success = $success,
                        m.rollback_available = $rollback_available
                """,
                    {
                        "revision": migration.revision,
                        "description": migration.description,
                        "applied_at": start_time,
                        "execution_time": execution_time,
                        "success": False,
                        "rollback_available": False,
                    },
                )
            except:
                pass  # Don't fail on logging failure

            logger.error(f"Failed to apply migration {migration.revision}: {e}")
            raise MigrationError(f"Migration {migration.revision} failed: {e}")

    async def apply_migrations(
        self, target_revision: Optional[str] = None
    ) -> Dict[str, Any]:
        """Apply all pending migrations up to target revision."""
        migrations = self.discover_migrations()
        applied_revisions = await self.get_applied_migrations()

        # Filter to migrations that need to be applied
        pending_migrations = []
        for migration in migrations:
            if migration.revision not in applied_revisions:
                pending_migrations.append(migration)

            # Stop at target revision if specified
            if target_revision and migration.revision == target_revision:
                break

        if not pending_migrations:
            logger.debug("No pending migrations to apply")
            return {"applied_count": 0, "migrations": []}

        applied_migrations = []
        for migration in pending_migrations:
            try:
                result = await self.apply_migration(migration)
                applied_migrations.append(
                    {
                        "revision": migration.revision,
                        "description": migration.description,
                        "status": result.get("status"),
                        "execution_time": result.get("execution_time"),
                    }
                )
            except Exception as e:
                logger.error(f"Migration chain stopped at {migration.revision}: {e}")
                break

        # CRITICAL: Checkpoint after migrations to flush WAL and sync catalog
        # This prevents catalog corruption from stale WAL entries
        if applied_migrations:
            try:
                conn = await self.migration_env.get_connection()
                conn.execute("CHECKPOINT;")
                logger.debug("Checkpointed after migrations to sync catalog")
            except Exception as checkpoint_err:
                logger.warning(
                    "Failed to checkpoint after migrations (WAL may contain stale entries)",
                    error=str(checkpoint_err)
                )
                # Don't fail migrations if checkpoint fails

        return {
            "applied_count": len(applied_migrations),
            "migrations": applied_migrations,
        }

    async def rollback_migration(
        self, revision: str, confirm: bool = False
    ) -> Dict[str, Any]:
        """Rollback a specific migration."""
        if not confirm:
            raise MigrationError("Rollback requires --confirm flag")

        conn = await self.migration_env.get_connection()

        if not await self.is_migration_applied(revision):
            raise MigrationError(f"Migration {revision} is not applied")

        # Find the migration file
        migrations = self.discover_migrations()
        migration = None
        for m in migrations:
            if m.revision == revision:
                migration = m
                break

        if not migration:
            raise MigrationError(f"Migration file for {revision} not found")

        start_time = datetime.now()

        try:
            # Execute rollback
            result = await migration.downgrade(conn)

            execution_time = (datetime.now() - start_time).total_seconds()

            # Remove from applied migrations
            conn.execute(
                """
                MATCH (m:MigrationHistory {revision: $revision})
                DELETE m
            """,
                {"revision": revision},
            )

            result.update(
                {
                    "status": "rolled_back",
                    "revision": revision,
                    "execution_time": execution_time,
                }
            )

            logger.debug(f"Migration {revision} rolled back successfully")
            return result

        except Exception as e:
            logger.error(f"Failed to rollback migration {revision}: {e}")
            raise MigrationError(f"Rollback {revision} failed: {e}")

    async def get_migration_status(self) -> Dict[str, Any]:
        """Get current migration status."""
        migrations = self.discover_migrations()
        applied_revisions = await self.get_applied_migrations()

        migration_status = []
        pending_count = 0

        for migration in migrations:
            is_applied = migration.revision in applied_revisions
            if not is_applied:
                pending_count += 1

            migration_status.append(
                {
                    "revision": migration.revision,
                    "description": migration.description,
                    "applied": is_applied,
                    "file_path": str(migration.file_path),
                }
            )

        return {
            "total_migrations": len(migrations),
            "applied_count": len(applied_revisions),
            "pending_count": pending_count,
            "migrations": migration_status,
        }

    async def close(self):
        """Close database connections."""
        await self.migration_env.close_connection()
