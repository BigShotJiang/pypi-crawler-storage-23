"""Nowledge Graph MCP Server.

A local-first personal memory management system that serves as a universal bridge
between GenAI tools using MCP (Model Context Protocol).
"""

__version__ = "0.6.6"
__author__ = "Nowledge Labs"

# Server will be imported after all dependencies are created
# from .server import create_server

__all__ = ["__version__"]
