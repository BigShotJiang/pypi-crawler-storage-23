"""Thread File Handler for MCP.

This module has been refactored into a modular structure under parsers/.
This file re-exports all public APIs for backward compatibility.

Module structure:
- parsers/base.py: Format detection and shared utilities
- parsers/claude.py: Claude Code session parser
- parsers/codex.py: Codex session parser
- parsers/cursor.py: Cursor workspace parser
- parsers/opencode.py: OpenCode session parser
- parsers/generic.py: Generic JSON and Markdown parsers
- parsers/handler.py: Main ThreadFileHandler class
"""

# Re-export main class for backward compatibility
from nowledge_graph_server.tools.parsers import ThreadFileHandler

__all__ = ["ThreadFileHandler"]
