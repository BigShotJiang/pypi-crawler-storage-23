"""OpenCode session parser.

Parses OpenCode sessions from:
- SQLite database (~/.local/share/opencode/opencode.db) — new format
- JSON files (~/.local/share/opencode/storage/) — legacy format
"""

import json
import os
import sqlite3
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog

logger = structlog.get_logger(__name__)

# Max chars for bash command output in parsed content
_BASH_OUTPUT_LIMIT = 500


def _format_tool_part(part_data: Dict[str, Any]) -> str:
    """Format a tool-type part as a concise one-liner.

    In a conversation viewer, tool output is noise — the assistant's text
    already summarizes findings. We show: what tool ran, what it was asked,
    and a brief metadata annotation (match count, file count, exit code).

    Only bash output is shown inline (briefly) since it may be the actual result.

    Args:
        part_data: Parsed JSON data for a tool part

    Returns:
        Formatted one-line string representation
    """
    tool_name = part_data.get("tool", "unknown")
    state = part_data.get("state", {})
    status = state.get("status", "")
    title = state.get("title", "")
    tool_input = state.get("input", {})
    metadata = state.get("metadata", {})

    # Build: [Tool: name] <title or input summary> <annotation>
    line = f"[Tool: {tool_name}]"

    # Title or input summary (not both)
    if title:
        line += f" {title}"
    else:
        input_summary = _summarize_tool_input(tool_name, tool_input)
        if input_summary:
            line += f" {input_summary}"

    # Metadata annotation inline (match count, file count, exit code)
    annotation = _format_tool_metadata(tool_name, metadata)
    if annotation:
        line += f" {annotation}"

    # Error: append brief error
    if status == "error":
        error = state.get("error", "")
        if error:
            line += f" — Error: {error[:200]}"
        return line

    # For bash, show brief output (it may be the actual result)
    if tool_name == "bash" and status == "completed":
        output = state.get("output")
        if output:
            output_str = str(output).strip()
            if output_str:
                truncated = output_str[:_BASH_OUTPUT_LIMIT]
                if len(output_str) > _BASH_OUTPUT_LIMIT:
                    truncated += "..."
                return f"{line}\n{truncated}"

    return line


def _summarize_tool_input(tool_name: str, tool_input: Dict[str, Any]) -> str:
    """Generate a concise input summary for a tool call."""
    if not tool_input:
        return ""

    if tool_name == "bash":
        cmd = tool_input.get("command", "")
        desc = tool_input.get("description", "")
        if cmd:
            # Show command, truncate long ones
            display = cmd[:200]
            if len(cmd) > 200:
                display += "..."
            return f"$ {display}"
        if desc:
            return desc
    elif tool_name == "read":
        path = tool_input.get("filePath", "")
        if path:
            extra = ""
            if tool_input.get("offset"):
                extra += f" (offset={tool_input['offset']}"
                if tool_input.get("limit"):
                    extra += f", limit={tool_input['limit']}"
                extra += ")"
            return f"File: {path}{extra}"
    elif tool_name == "glob":
        pattern = tool_input.get("pattern", "")
        if pattern:
            return f"Pattern: {pattern}"
    elif tool_name == "grep":
        pattern = tool_input.get("pattern", "")
        path = tool_input.get("path", "")
        if pattern:
            result = f"Pattern: {pattern}"
            if path:
                result += f" in {path}"
            return result
    elif tool_name == "webfetch":
        url = tool_input.get("url", "")
        if url:
            return f"URL: {url}"
    elif tool_name == "task":
        desc = tool_input.get("description", "")
        if desc:
            return f"Task: {desc}"

    return ""


def _format_tool_metadata(tool_name: str, metadata: Dict[str, Any]) -> str:
    """Format tool-specific metadata as a brief annotation."""
    if not metadata:
        return ""

    annotations: List[str] = []

    if tool_name == "bash":
        exit_code = metadata.get("exit")
        if exit_code is not None and exit_code != 0:
            annotations.append(f"exit={exit_code}")
    elif tool_name == "grep":
        matches = metadata.get("matches")
        if matches is not None:
            annotations.append(f"{matches} matches")
        if metadata.get("truncated"):
            annotations.append("truncated")
    elif tool_name == "glob":
        count = metadata.get("count")
        if count is not None:
            annotations.append(f"{count} files")

    if annotations:
        return f"({', '.join(annotations)})"
    return ""


def parse_opencode_session_sqlite(
    db_path: Path, session_id: str
) -> Dict[str, Any]:
    """Parse OpenCode session from SQLite database.

    Args:
        db_path: Path to opencode.db
        session_id: Session ID to parse

    Returns:
        Standard thread_data dict

    Raises:
        FileNotFoundError: If database doesn't exist
        ValueError: If session not found
    """
    if not db_path.exists():
        raise FileNotFoundError(f"OpenCode database not found: {db_path}")

    conn = _safe_sqlite_connect(db_path)
    if not conn:
        raise ValueError(f"Failed to connect to OpenCode database: {db_path}")

    try:
        cursor = conn.cursor()

        # Load session metadata
        cursor.execute(
            "SELECT id, project_id, directory, title, version, time_created FROM session WHERE id = ?",
            (session_id,),
        )
        session_row = cursor.fetchone()
        if not session_row:
            raise ValueError(f"Session not found in OpenCode database: {session_id}")

        session_title = session_row["title"] or ""
        directory = session_row["directory"] or ""
        project_id = session_row["project_id"] or ""
        version = session_row["version"]

        # Batch-load all parts for the session in one query (uses denormalized
        # session_id on part table to avoid N+1 queries per message)
        parts_by_message: Dict[str, List[Dict[str, Any]]] = {}
        cursor.execute(
            """
            SELECT message_id, data FROM part
            WHERE session_id = ?
            ORDER BY message_id, id ASC
            """,
            (session_id,),
        )
        for part_row in cursor.fetchall():
            msg_id = part_row["message_id"]
            if msg_id not in parts_by_message:
                parts_by_message[msg_id] = []
            try:
                part_data = (
                    json.loads(part_row["data"])
                    if isinstance(part_row["data"], str)
                    else part_row["data"]
                )
                parts_by_message[msg_id].append(part_data)
            except Exception:
                continue

        # Load messages (oldest first)
        cursor.execute(
            """
            SELECT m.id, m.data, m.time_created
            FROM message m
            WHERE m.session_id = ?
            ORDER BY m.time_created ASC
            """,
            (session_id,),
        )

        messages: List[Dict[str, Any]] = []
        first_user_content: Optional[str] = None

        for msg_row in cursor.fetchall():
            try:
                msg_data = (
                    json.loads(msg_row["data"])
                    if isinstance(msg_row["data"], str)
                    else msg_row["data"]
                )
                role = msg_data.get("role", "user")
                msg_id = msg_row["id"]
                timestamp = msg_row["time_created"]

                # Format parts for this message
                content_parts: List[str] = []
                for part_data in parts_by_message.get(msg_id, []):
                    formatted = _format_part(part_data)
                    if formatted:
                        content_parts.append(formatted)
                content = "\n".join(content_parts)

                if content.strip():
                    if role == "user" and not first_user_content:
                        first_user_content = content

                    messages.append(
                        {
                            "role": role,
                            "content": content,
                            "timestamp": timestamp,
                        }
                    )
            except Exception as e:
                logger.warning(
                    "Failed to parse OpenCode SQLite message",
                    message_id=msg_row["id"] if msg_row else "unknown",
                    error=str(e),
                )
                continue

        # Generate title
        title = session_title
        if not title or title.startswith("New session - ") or title.startswith(
            "Child session - "
        ):
            if first_user_content:
                title = first_user_content[:60].replace("\n", " ")
                if len(first_user_content) > 60:
                    title += "..."
            else:
                title = "OpenCode Session"

        # Extract project info
        project_name = (
            os.path.basename(directory.rstrip("/\\")) if directory else project_id
        )

        logger.info(
            "Parsed OpenCode session from SQLite",
            session_id=session_id,
            message_count=len(messages),
            project=project_name,
        )

        return {
            "thread_id": f"opencode-{session_id}",
            "title": title,
            "messages": messages,
            "source": "opencode",
            "metadata": {
                "session_id": session_id,
                "project_id": project_id,
                "directory": directory,
                "version": version,
                "storage": "sqlite",
                "original_file_path": str(db_path),
            },
        }

    finally:
        conn.close()


def _format_part(part_data: Dict[str, Any]) -> str:
    """Format a single message part into readable text.

    Handles all OpenCode part types: text, tool, reasoning, step-start,
    step-finish, file, snapshot, patch, agent, subtask, compaction, retry.

    Args:
        part_data: Parsed JSON data for a part

    Returns:
        Formatted string, or empty string to skip
    """
    part_type = part_data.get("type", "")

    if part_type == "text":
        text = part_data.get("text", "")
        if text and not part_data.get("ignored"):
            return text
    elif part_type == "tool":
        return _format_tool_part(part_data)
    elif part_type == "reasoning":
        text = part_data.get("text", "")
        if text:
            return f"<thinking>{text}</thinking>"
    elif part_type in ("step-start", "step-finish"):
        # Turn boundaries — skip, these are metadata not content
        pass
    elif part_type == "file":
        # File reference part
        file_path = part_data.get("path", part_data.get("file", ""))
        if file_path:
            return f"[File: {file_path}]"
    elif part_type == "patch":
        # Code diff/patch
        patch_text = part_data.get("content", part_data.get("text", ""))
        if patch_text:
            truncated = patch_text[:_BASH_OUTPUT_LIMIT]
            if len(patch_text) > _BASH_OUTPUT_LIMIT:
                truncated += "..."
            return f"[Patch]\n{truncated}"
    elif part_type in ("agent", "subtask"):
        # Sub-agent or subtask reference
        desc = part_data.get("description", part_data.get("text", ""))
        if desc:
            return f"[{part_type.title()}: {desc}]"

    # Skip unknown/unhandled types silently (compaction, retry, snapshot, etc.)
    return ""


def _safe_sqlite_connect(db_path: Path) -> Optional[sqlite3.Connection]:
    """Safely connect to SQLite in read-only mode with retry."""
    max_retries = 3
    delays = [0.1, 0.2, 0.4]

    for attempt in range(max_retries):
        try:
            conn = sqlite3.connect(
                f"file:{db_path}?mode=ro",
                timeout=5,
                uri=True,
            )
            conn.row_factory = sqlite3.Row
            return conn
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e) and attempt < max_retries - 1:
                time.sleep(delays[attempt])
                continue
            logger.warning(
                "Failed to connect to OpenCode database",
                db_path=str(db_path),
                error=str(e),
            )
            return None
        except Exception as e:
            logger.warning(
                "Unexpected error connecting to OpenCode database",
                db_path=str(db_path),
                error=str(e),
            )
            return None

    return None


def parse_opencode_session(session_path: Path) -> Dict[str, Any]:
    """Parse OpenCode session from JSON files.

    OpenCode uses XDG standard directory specification:
    - Session file: storage/session/{projectID}/{sessionID}.json
    - Message files: storage/message/{sessionID}/{messageID}.json
    - Part files: storage/part/{messageID}/{partID}.json

    Args:
        session_path: Path to session/{projectID}/{sessionID}.json file

    Returns:
        Standard thread_data dict
    """
    # Load session metadata
    session_data = json.loads(session_path.read_text(encoding="utf-8"))
    session_id = session_data.get("id", session_path.stem)

    # Find storage base: session_path is storage/session/{projectID}/{sessionID}.json
    # So base is 3 levels up
    storage_base = session_path.parent.parent.parent

    # Load messages
    message_path = storage_base / "message" / session_id
    messages: List[Dict[str, Any]] = []
    first_user_content: Optional[str] = None

    if message_path.exists():
        # Sort message files to get chronological order
        for msg_file in sorted(message_path.glob("*.json")):
            try:
                msg_data = json.loads(msg_file.read_text(encoding="utf-8"))
                role = msg_data.get("role", "user")
                msg_id = msg_data.get("id", msg_file.stem)
                timestamp = msg_data.get("time", {}).get("created")

                # Load parts for content
                content_parts: List[str] = []
                part_path = storage_base / "part" / msg_id

                if part_path.exists():
                    for part_file in sorted(part_path.glob("*.json")):
                        try:
                            part_data = json.loads(part_file.read_text(encoding="utf-8"))
                            formatted = _format_part(part_data)
                            if formatted:
                                content_parts.append(formatted)
                        except Exception:
                            continue

                content = "\n".join(content_parts)
                if content.strip():
                    # Capture first user message for title
                    if role == "user" and not first_user_content:
                        first_user_content = content

                    messages.append({
                        "role": role,
                        "content": content,
                        "timestamp": timestamp,
                    })
            except Exception as e:
                logger.warning(
                    "Failed to parse OpenCode message",
                    file=str(msg_file),
                    error=str(e),
                )
                continue

    # Generate title
    title = session_data.get("title", "")
    if not title or title.startswith("New session - ") or title.startswith("Child session - "):
        if first_user_content:
            title = first_user_content[:60].replace("\n", " ")
            if len(first_user_content) > 60:
                title += "..."
        else:
            title = "OpenCode Session"

    # Extract project info
    directory = session_data.get("directory", "")
    project_id = session_data.get("projectID", "")
    project_name = os.path.basename(directory.rstrip("/\\")) if directory else project_id

    logger.info(
        "Parsed OpenCode session",
        session_id=session_id,
        message_count=len(messages),
        project=project_name,
    )

    return {
        "thread_id": f"opencode-{session_id}",
        "title": title,
        "messages": messages,
        "source": "opencode",
        "metadata": {
            "session_id": session_id,
            "project_id": project_id,
            "directory": directory,
            "version": session_data.get("version"),
            "storage": "json",
            "original_file_path": str(session_path),
        },
    }
