"""Thread file parsers module.

This module contains parsers for various conversation file formats:
- Claude Code (JSONL)
- Codex (JSONL)
- Cursor (SQLite/JSON)
- OpenCode (JSON)
- Generic JSON
- Markdown

The module is split into:
- base: Format detection and shared utilities
- claude: Claude Code session parser
- codex: Codex session parser
- cursor: Cursor workspace parser
- opencode: OpenCode session parser
- generic: Generic JSON and Markdown parsers
- handler: Main ThreadFileHandler class
"""

from .base import detect_format
from .claude import (
    parse_claude_code_session_streaming,
    discover_subagent_files,
    parse_subagent_file,
)
from .codex import parse_codex_session_streaming
from .cursor import (
    parse_cursor_vscdb,
    parse_cursor_export,
    extract_cursor_messages,
    extract_cursor_bubbles,
)
from .opencode import parse_opencode_session
from .generic import parse_generic_json, parse_markdown
from .handler import ThreadFileHandler

__all__ = [
    # Base
    "detect_format",
    # Claude
    "parse_claude_code_session_streaming",
    "discover_subagent_files",
    "parse_subagent_file",
    # Codex
    "parse_codex_session_streaming",
    # Cursor
    "parse_cursor_vscdb",
    "parse_cursor_export",
    "extract_cursor_messages",
    "extract_cursor_bubbles",
    # OpenCode
    "parse_opencode_session",
    # Generic
    "parse_generic_json",
    "parse_markdown",
    # Handler
    "ThreadFileHandler",
]
