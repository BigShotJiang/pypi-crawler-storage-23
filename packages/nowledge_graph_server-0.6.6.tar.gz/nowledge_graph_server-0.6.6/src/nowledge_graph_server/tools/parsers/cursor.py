"""Cursor workspace parser.

Parses Cursor's state.vscdb SQLite databases and export formats.
"""

import json
import os
import sqlite3
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog

logger = structlog.get_logger(__name__)


def parse_cursor_vscdb(db_path: Path) -> Dict[str, Any]:
    """Parse Cursor's state.vscdb SQLite database.

    Cursor data architecture (discovered through analysis):
    - Workspace storage (db_path): Contains composer.composerData with metadata only
    - Global storage: Contains actual conversation data in cursorDiskKV table:
      - composerData:{composerId}: Full conversation with bubbleId references
      - bubbleId:{composerId}:{bubbleId}: Actual message content
        - type 1 = user message
        - type 2 = assistant message

    Args:
        db_path: Path to the workspace's state.vscdb

    Returns:
        Standard thread_data dict
    """
    if not db_path.exists():
        raise FileNotFoundError(f"Cursor database not found: {db_path}")

    messages: List[Dict[str, Any]] = []
    title = "Imported from Cursor"
    workspace_path = None

    # Get workspace path from workspace.json
    workspace_json = db_path.parent / "workspace.json"
    if workspace_json.exists():
        try:
            with open(workspace_json, "r") as f:
                ws_data = json.load(f)
                folder_uri = ws_data.get("folder", "")
                if folder_uri.startswith("file://"):
                    workspace_path = folder_uri[7:]
                    title = os.path.basename(workspace_path.rstrip("/\\"))
        except Exception:
            pass

    # Determine global storage path
    global_db_path = _get_cursor_global_db_path()

    # Get composerIds from workspace storage (read-only to avoid interfering with Cursor)
    composer_ids = []
    workspace_conn = sqlite3.connect(
        f"file:{db_path}?mode=ro",
        timeout=5.0,
        uri=True,
    )
    try:
        workspace_conn.execute("PRAGMA query_only = ON")
        ws_cursor = workspace_conn.cursor()
        ws_cursor.execute("SELECT value FROM ItemTable WHERE key = 'composer.composerData'")
        row = ws_cursor.fetchone()
        if row and row[0]:
            data = json.loads(row[0]) if isinstance(row[0], str) else row[0]
            all_composers = data.get("allComposers", [])
            for composer in all_composers:
                if isinstance(composer, dict) and composer.get("composerId"):
                    composer_ids.append({
                        "id": composer["composerId"],
                        "name": composer.get("name", ""),
                        "lastUpdatedAt": composer.get("lastUpdatedAt", 0),
                    })
    finally:
        workspace_conn.close()

    if not composer_ids:
        raise ValueError("No Cursor conversations found in this workspace.")

    # Sort by lastUpdatedAt to get most recent first
    composer_ids.sort(key=lambda x: x.get("lastUpdatedAt", 0), reverse=True)

    # Read from global storage
    if not global_db_path or not global_db_path.exists():
        raise ValueError(f"Cursor global storage not found: {global_db_path}")

    global_conn = sqlite3.connect(
        f"file:{global_db_path}?mode=ro",
        timeout=5.0,
        uri=True,
    )
    try:
        global_conn.execute("PRAGMA query_only = ON")
        global_cursor = global_conn.cursor()

        # Try each composer until we find one with local data
        composer_data = None
        conversation_headers = []
        composer_id = None

        for target_composer in composer_ids:
            cid = target_composer["id"]

            # Get composerData from cursorDiskKV
            global_cursor.execute(
                "SELECT value FROM cursorDiskKV WHERE key = ?",
                (f"composerData:{cid}",),
            )
            row = global_cursor.fetchone()

            if not row or not row[0]:
                continue

            data = json.loads(row[0]) if isinstance(row[0], str) else row[0]

            # Check if this conversation has local data
            headers = data.get("fullConversationHeadersOnly", [])
            if not headers:
                headers = data.get("conversation", [])

            if headers:
                composer_data = data
                conversation_headers = headers
                composer_id = cid
                if target_composer.get("name"):
                    title = target_composer["name"]
                break

        if not composer_data or not conversation_headers:
            raise ValueError(
                "No local Cursor conversations found. "
                "Cloud agent conversations are stored on the server, not locally. "
                "Only local conversations can be imported."
            )

        # Determine which data source we're using
        has_headers_only = bool(composer_data.get("fullConversationHeadersOnly"))

        logger.info(
            "Found Cursor composer with local data",
            composer_id=composer_id[:20] if composer_id else "N/A",
            name=title,
            message_count=len(conversation_headers),
            data_source="headers+kv" if has_headers_only else "inline",
        )

        # Extract messages from conversation bubbles
        for bubble_ref in conversation_headers:
            if not isinstance(bubble_ref, dict):
                continue

            bubble_id = bubble_ref.get("bubbleId")
            bubble_type = bubble_ref.get("type")  # 1 = user, 2 = assistant

            if not bubble_id:
                continue

            bubble_data = None

            if has_headers_only:
                # Headers-only mode: fetch full bubble from cursorDiskKV
                global_cursor.execute(
                    "SELECT value FROM cursorDiskKV WHERE key = ?",
                    (f"bubbleId:{composer_id}:{bubble_id}",),
                )
                bubble_row = global_cursor.fetchone()
                if bubble_row and bubble_row[0]:
                    try:
                        bubble_data = json.loads(bubble_row[0]) if isinstance(bubble_row[0], str) else bubble_row[0]
                    except (json.JSONDecodeError, TypeError):
                        continue
            else:
                # Inline mode: bubble_ref IS the full bubble data
                bubble_data = bubble_ref

            if not bubble_data:
                continue

            text = (
                bubble_data.get("text")
                or bubble_data.get("rawText")
                or bubble_data.get("content")
                or ""
            )

            # Update type from bubble data if not set
            if bubble_type is None:
                bubble_type = bubble_data.get("type")

            if not text or not isinstance(text, str) or not text.strip():
                continue

            # Determine role: type 1 = user, type 2 = assistant
            role = "user" if bubble_type == 1 else "assistant"

            messages.append({
                "role": role,
                "content": text.strip(),
                "timestamp": None,
            })

    finally:
        global_conn.close()

    if not messages:
        raise ValueError(
            "No conversation messages found in Cursor database. "
            "The conversation may be empty or use an unsupported format."
        )

    logger.info(
        "Extracted Cursor conversation",
        message_count=len(messages),
        user_count=sum(1 for m in messages if m["role"] == "user"),
        assistant_count=sum(1 for m in messages if m["role"] == "assistant"),
    )

    return {
        "thread_id": f"cursor-{composer_id[:8]}" if composer_id else "cursor-unknown",
        "title": title,
        "messages": messages,
        "source": "cursor",
        "metadata": {
            "workspace_path": workspace_path,
            "db_path": str(db_path),
            "composer_id": composer_id,
        },
    }


def _get_cursor_global_db_path() -> Optional[Path]:
    """Get Cursor global storage database path for current platform.

    Returns:
        Path to Cursor globalStorage/state.vscdb, or None if not determinable
    """
    home = Path.home()

    if sys.platform == "darwin":
        return home / "Library" / "Application Support" / "Cursor" / "User" / "globalStorage" / "state.vscdb"
    elif sys.platform == "win32":
        appdata = os.environ.get("APPDATA", "")
        if appdata:
            return Path(appdata) / "Cursor" / "User" / "globalStorage" / "state.vscdb"
        return None
    else:
        return home / ".config" / "Cursor" / "User" / "globalStorage" / "state.vscdb"


def parse_cursor_export(content: str) -> Dict[str, Any]:
    """Parse Cursor export format.

    Cursor exports are JSON files with structure:
    {
        "messages": [
            {"role": "user"/"assistant", "content": "...", ...},
            ...
        ],
        "metadata": {...},
        ...
    }

    Args:
        content: Raw JSON content string

    Returns:
        Standard thread_data dict
    """
    data = json.loads(content)

    if not isinstance(data, dict) or "messages" not in data:
        raise ValueError("Invalid Cursor export: missing 'messages' array")

    messages = data["messages"]
    if not isinstance(messages, list):
        raise ValueError("Invalid Cursor export: 'messages' must be an array")

    # Extract thread metadata
    thread_data: Dict[str, Any] = {
        "thread_id": data.get("id")
        or data.get("thread_id")
        or f"cursor_{hash(content) % 10000:04d}",
        "title": data.get("title") or "Imported from Cursor",
        "messages": [],
        "source": "cursor",
        "metadata": data.get("metadata", {}),
    }

    # Convert messages to standard format
    for idx, msg in enumerate(messages):
        if not isinstance(msg, dict):
            logger.warning(f"Skipping invalid message at index {idx}")
            continue

        thread_data["messages"].append(
            {
                "role": msg.get("role", "user"),
                "content": msg.get("content", ""),
                "timestamp": msg.get("timestamp"),
                "metadata": {
                    k: v
                    for k, v in msg.items()
                    if k not in ["role", "content", "timestamp"]
                },
            }
        )

    return thread_data


def extract_cursor_messages(
    data: Any, key: str = ""
) -> List[Dict[str, Any]]:
    """Extract messages from Cursor's JSON data structures.

    Handles various formats that Cursor might use to store conversations.

    Args:
        data: Cursor data structure to extract from
        key: Current key path (for recursion)

    Returns:
        List of message dicts
    """
    messages: List[Dict[str, Any]] = []

    if isinstance(data, dict):
        # Check for direct message arrays
        if "messages" in data and isinstance(data["messages"], list):
            for msg in data["messages"]:
                if isinstance(msg, dict) and ("content" in msg or "text" in msg):
                    messages.append({
                        "role": msg.get("role", msg.get("type", "user")),
                        "content": msg.get("content") or msg.get("text", ""),
                        "timestamp": msg.get("timestamp") or msg.get("createdAt"),
                    })

        # Check for conversation/chat structure
        elif "conversation" in data and isinstance(data["conversation"], list):
            for item in data["conversation"]:
                if isinstance(item, dict):
                    messages.append({
                        "role": item.get("role", "user"),
                        "content": item.get("content") or item.get("message", ""),
                        "timestamp": item.get("timestamp"),
                    })

        # Check for bubbles (Cursor's internal format)
        elif "bubbles" in data and isinstance(data["bubbles"], list):
            for bubble in data["bubbles"]:
                if isinstance(bubble, dict):
                    bubble_type = bubble.get("type", "")
                    if bubble_type == "user" or "user" in str(bubble.get("role", "")):
                        role = "user"
                    else:
                        role = "assistant"

                    content = bubble.get("text") or bubble.get("content") or bubble.get("message", "")
                    if content:
                        messages.append({
                            "role": role,
                            "content": content,
                            "timestamp": bubble.get("timestamp"),
                        })

        # Recursively check nested structures
        else:
            for v in data.values():
                if isinstance(v, (dict, list)):
                    messages.extend(extract_cursor_messages(v, key))

    elif isinstance(data, list):
        for item in data:
            if isinstance(item, dict):
                # Check if item looks like a message
                if "content" in item or "text" in item or "message" in item:
                    messages.append({
                        "role": item.get("role", item.get("type", "user")),
                        "content": item.get("content") or item.get("text") or item.get("message", ""),
                        "timestamp": item.get("timestamp") or item.get("createdAt"),
                    })
                else:
                    messages.extend(extract_cursor_messages(item, key))

    return messages


def extract_cursor_bubbles(
    bubbles: List[Any],
) -> List[Dict[str, Any]]:
    """Extract messages from Cursor's bubbles array.

    Each bubble in Cursor's chat data represents a message with structure:
    {
        "type": "user" | "ai" | ...,
        "text": "message content",
        "rawText": "raw message text",
        "timestamp": ...,
        ...
    }

    Args:
        bubbles: List of bubble dicts

    Returns:
        List of message dicts
    """
    messages: List[Dict[str, Any]] = []

    for bubble in bubbles:
        if not isinstance(bubble, dict):
            continue

        # Determine role from bubble type
        bubble_type = str(bubble.get("type", "")).lower()
        if bubble_type in ("user", "human"):
            role = "user"
        elif bubble_type in ("ai", "assistant", "model"):
            role = "assistant"
        else:
            # Default based on presence of user-related fields
            role = "assistant" if bubble_type else "user"

        # Extract content - try multiple possible field names
        content: Any = (
            bubble.get("text")
            or bubble.get("rawText")
            or bubble.get("content")
            or bubble.get("message")
            or ""
        )

        # Handle case where content might be structured (e.g., markdown parts)
        if isinstance(content, list):
            # Join list of text parts
            content = "\n".join(
                part.get("text", str(part)) if isinstance(part, dict) else str(part)
                for part in content
            )
        elif isinstance(content, dict):
            content = content.get("text", "") or json.dumps(content)

        if content and isinstance(content, str) and content.strip():
            messages.append({
                "role": role,
                "content": content,
                "timestamp": bubble.get("timestamp") or bubble.get("createdAt"),
            })

    return messages
