"""Thread File Handler for MCP.

Handles file-based thread creation/updates for MCP tool integration.
"""

import json
from pathlib import Path
from typing import Any, Dict, Optional

import structlog

from nowledge_graph_server.models import ThreadCreateResponse
from nowledge_graph_server.core.thread_operations import ThreadOperations

from .base import detect_format
from .claude import parse_claude_code_session_streaming
from .codex import parse_codex_session_streaming
from .cursor import parse_cursor_vscdb, parse_cursor_export
from .opencode import parse_opencode_session, parse_opencode_session_sqlite
from .generic import parse_generic_json, parse_markdown

logger = structlog.get_logger(__name__)


class ThreadFileHandler:
    """Handle file-based thread creation/updates for MCP."""

    def __init__(self, thread_ops: ThreadOperations):
        """Initialize with thread operations."""
        self.thread_ops = thread_ops

    async def create_thread_from_file(
        self,
        file_path: str,
        format: str = "auto",  # "cursor_export", "claude_code", "json", "markdown"
        thread_id_override: Optional[str] = None,
        summary: Optional[str] = None,  # User-provided thread summary
        truncate_large_content: bool = False,  # Truncate tool results > 10KB (default: preserve all)
        session_id: Optional[str] = None,  # Required for opencode_sqlite format
    ) -> ThreadCreateResponse:
        """Parse file and create thread.

        Supports:
        - Cursor export format (JSON with messages array)
        - Claude Code session format (JSONL)
        - Codex session format (JSONL)
        - OpenCode session format (JSON)
        - Generic JSON with {messages: [...]}
        - Markdown conversation (future)

        Args:
            file_path: Absolute path to thread file
            format: File format ("auto", "cursor_export", "claude_code", "codex", "opencode", "json", "markdown")
            thread_id_override: Optional thread ID override
            summary: Optional user-provided thread summary (stored in metadata)
            truncate_large_content: If True, truncate tool results > 10KB (default False to preserve all data)

        Returns:
            ThreadCreateResponse with creation details

        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If file format is invalid or unsupported
        """
        # Validate file path
        file_path_obj = Path(file_path)
        if not file_path_obj.is_absolute():
            raise ValueError(f"File path must be absolute: {file_path}")

        if not file_path_obj.exists():
            raise FileNotFoundError(f"Thread file not found: {file_path}")

        if not file_path_obj.is_file():
            raise ValueError(f"Path is not a file: {file_path}")

        try:
            # For auto-detection, we need to peek at the file
            if format == "auto":
                # Binary database files: detect by extension without reading
                detected_by_ext = detect_format("", file_path_obj)
                if detected_by_ext in ("cursor_vscdb", "opencode_sqlite"):
                    format = detected_by_ext
                else:
                    # Peek at first few lines for format detection (memory-efficient)
                    with open(file_path_obj, "r", encoding="utf-8") as f:
                        peek_lines = []
                        for _ in range(5):
                            line = f.readline()
                            if not line:
                                break
                            peek_lines.append(line)
                        content_peek = "".join(peek_lines)
                    format = detect_format(content_peek, file_path_obj)

            # Parse based on format
            thread_data = self._parse_file(
                file_path_obj, format, truncate_large_content, session_id=session_id
            )

            # Override thread_id if provided
            if thread_id_override:
                thread_data["thread_id"] = thread_id_override

            # Add user-provided summary to metadata if provided
            if summary:
                if "metadata" not in thread_data:
                    thread_data["metadata"] = {}
                thread_data["metadata"]["summary"] = summary

            # Create thread using thread operations
            logger.info(
                "Creating thread from file",
                file_path=file_path,
                format=format,
                message_count=len(thread_data.get("messages", [])),
            )

            return await self.thread_ops.create_thread(
                thread_id=thread_data["thread_id"],
                messages=thread_data["messages"],
                title=thread_data.get("title"),
                source=thread_data.get("source", "file_import"),
                participants=thread_data.get("participants"),
                metadata=thread_data.get("metadata", {}),
                auto_extract_memories=False,  # Don't auto-extract for file imports
            )

        except json.JSONDecodeError as e:
            logger.error(
                "Invalid JSON in thread file", file_path=file_path, error=str(e)
            )
            raise ValueError(f"Invalid JSON in file: {e}")
        except Exception as e:
            logger.error(
                "Failed to create thread from file",
                file_path=file_path,
                format=format,
                error=str(e),
            )
            raise

    async def append_messages_from_file(
        self,
        thread_id: str,
        file_path: str,
        format: str = "auto",
        deduplicate: bool = True,
        truncate_large_content: bool = False,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Append messages to existing thread from file.

        Args:
            thread_id: Existing thread ID
            file_path: Absolute path to messages file
            format: File format ("auto", "cursor_export", "claude_code", "codex", "opencode", "json")
            deduplicate: Skip messages already in thread (by content hash)
            truncate_large_content: If True, truncate tool results > 10KB (default False)

        Returns:
            Dict with appended message count and details

        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If file format is invalid
        """
        # Validate file path
        file_path_obj = Path(file_path)
        if not file_path_obj.is_absolute():
            raise ValueError(f"File path must be absolute: {file_path}")

        if not file_path_obj.exists():
            raise FileNotFoundError(f"Messages file not found: {file_path}")

        try:
            # Auto-detect format if needed (peek at file)
            if format == "auto":
                # Binary database files: detect by extension without reading
                detected_by_ext = detect_format("", file_path_obj)
                if detected_by_ext in ("cursor_vscdb", "opencode_sqlite"):
                    format = detected_by_ext
                else:
                    with open(file_path_obj, "r", encoding="utf-8") as f:
                        peek_lines = []
                        for _ in range(5):
                            line = f.readline()
                            if not line:
                                break
                            peek_lines.append(line)
                        content_peek = "".join(peek_lines)
                    format = detect_format(content_peek, file_path_obj)

            # Parse file
            thread_data = self._parse_file(
                file_path_obj, format, truncate_large_content, session_id=session_id
            )
            messages = thread_data.get("messages", [])

            if not messages:
                logger.warning("No messages to append", thread_id=thread_id)
                return {
                    "messages_added": 0,
                    "total_messages": 0,
                    "thread_id": thread_id,
                }

            # Append messages using thread operations
            logger.info(
                "Appending messages to thread",
                thread_id=thread_id,
                message_count=len(messages),
                deduplicate=deduplicate,
            )

            result = await self.thread_ops.append_messages(
                thread_id=thread_id,
                messages=messages,
                deduplicate=deduplicate,
            )

            return result

        except json.JSONDecodeError as e:
            logger.error(
                "Invalid JSON in messages file", file_path=file_path, error=str(e)
            )
            raise ValueError(f"Invalid JSON in file: {e}")
        except Exception as e:
            logger.error(
                "Failed to append messages from file",
                thread_id=thread_id,
                file_path=file_path,
                error=str(e),
            )
            raise

    def _parse_file(
        self,
        file_path: Path,
        format: str,
        truncate_large_content: bool = False,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Parse file based on format.

        Args:
            file_path: Path to the file
            format: Detected or specified format
            truncate_large_content: If True, truncate large content
            session_id: Optional session ID (required for opencode_sqlite format)

        Returns:
            Standard thread_data dict
        """
        if format == "cursor_vscdb":
            # Cursor SQLite database format
            return parse_cursor_vscdb(file_path)
        elif format == "cursor_export":
            # Cursor exports are JSON, need full content
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
            return parse_cursor_export(content)
        elif format == "claude_code":
            # Stream JSONL line-by-line for memory efficiency (handles 100GiB+ files)
            return parse_claude_code_session_streaming(
                file_path, truncate_large_content
            )
        elif format == "codex":
            # Stream JSONL line-by-line for memory efficiency
            return parse_codex_session_streaming(
                file_path, truncate_large_content
            )
        elif format == "opencode_sqlite":
            # OpenCode SQLite database format (new)
            if not session_id:
                raise ValueError("session_id required for opencode_sqlite format")
            return parse_opencode_session_sqlite(file_path, session_id)
        elif format == "opencode":
            # OpenCode JSON session files (legacy)
            return parse_opencode_session(file_path)
        elif format == "json":
            # Generic JSON - may need full content
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
            return parse_generic_json(content)
        elif format == "markdown":
            # Markdown files are typically small
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
            return parse_markdown(content, file_path)
        else:
            raise ValueError(f"Unsupported format: {format}")
