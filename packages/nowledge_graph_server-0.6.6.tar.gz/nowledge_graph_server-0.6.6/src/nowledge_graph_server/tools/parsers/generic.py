"""Generic JSON and Markdown parsers.

Parses generic conversation formats and markdown files.
"""

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Dict, List

import structlog

logger = structlog.get_logger(__name__)


def parse_generic_json(content: str) -> Dict[str, Any]:
    """Parse generic JSON conversation format.

    Supports:
    - {messages: [{role, content}, ...], ...}
    - [{role, content}, ...]

    Args:
        content: Raw JSON content string

    Returns:
        Standard thread_data dict
    """
    data = json.loads(content)

    # Handle array of messages
    if isinstance(data, list):
        return {
            "thread_id": f"imported_{hash(content) % 10000:04d}",
            "title": "Imported Conversation",
            "messages": data,
            "source": "json_import",
        }

    # Handle object with messages
    if isinstance(data, dict):
        if "messages" not in data:
            raise ValueError("JSON must contain 'messages' array")

        return {
            "thread_id": data.get("id")
            or data.get("thread_id")
            or f"imported_{hash(content) % 10000:04d}",
            "title": data.get("title", "Imported Conversation"),
            "messages": data["messages"],
            "source": data.get("source", "json_import"),
            "metadata": data.get("metadata", {}),
        }

    raise ValueError("Invalid JSON format: must be array or object with 'messages'")


def parse_markdown(content: str, file_path: Path) -> Dict[str, Any]:
    """Parse markdown file as thread.

    Supports two formats:
    1. Cursor export format: Has YAML frontmatter with metadata and structured messages
       marked with `## User` / `## Assistant` headers
    2. Plain markdown: Treated as a single document/note

    For plain markdown, the entire content becomes a single "document" role message,
    making it suitable for importing notes, documentation, or any markdown file.

    Args:
        content: Raw markdown content
        file_path: Path object for the file

    Returns:
        Standard thread_data dict
    """
    # Check for Cursor export format (has specific structure)
    # Cursor exports have YAML frontmatter and ## User / ## Assistant headers
    has_frontmatter = content.strip().startswith("---")
    has_role_headers = bool(re.search(r"^##\s+(User|Assistant)\s*$", content, re.MULTILINE | re.IGNORECASE))

    if has_frontmatter and has_role_headers:
        # Parse as Cursor export format
        return _parse_cursor_markdown(content, file_path)
    else:
        # Parse as plain markdown - single message thread
        return _parse_plain_markdown(content, file_path)


def _parse_cursor_markdown(content: str, file_path: Path) -> Dict[str, Any]:
    """Parse Cursor-exported markdown with structured messages.

    Format:
    ---
    title: Conversation Title
    date: 2024-01-01
    source: cursor
    ---

    ## User

    User message content...

    ## Assistant

    Assistant response...

    Args:
        content: Raw markdown content
        file_path: Path object for the file

    Returns:
        Standard thread_data dict
    """
    # Extract frontmatter if present
    metadata: Dict[str, Any] = {}
    body = content

    if content.strip().startswith("---"):
        parts = content.split("---", 2)
        if len(parts) >= 3:
            frontmatter = parts[1].strip()
            body = parts[2].strip()

            # Parse simple YAML-like frontmatter
            for line in frontmatter.split("\n"):
                if ":" in line:
                    key, value = line.split(":", 1)
                    metadata[key.strip()] = value.strip()

    # Parse messages by ## headers
    messages: List[Dict[str, Any]] = []
    current_role = None
    current_content: List[str] = []

    for line in body.split("\n"):
        header_match = re.match(r"^##\s+(User|Assistant)\s*$", line, re.IGNORECASE)
        if header_match:
            # Save previous message
            if current_role and current_content:
                messages.append({
                    "role": current_role,
                    "content": "\n".join(current_content).strip(),
                })
            current_role = header_match.group(1).lower()
            current_content = []
        else:
            current_content.append(line)

    # Save last message
    if current_role and current_content:
        messages.append({
            "role": current_role,
            "content": "\n".join(current_content).strip(),
        })

    if not messages:
        raise ValueError("No messages found in Cursor markdown export")

    # Generate thread ID
    content_hash = hashlib.md5(content.encode()).hexdigest()[:8]
    thread_id = metadata.get("id") or f"md-cursor-{content_hash}"

    return {
        "thread_id": thread_id,
        "title": metadata.get("title") or file_path.stem,
        "messages": messages,
        "source": metadata.get("source", "cursor"),
        "metadata": {
            "original_file": str(file_path),
            "format": "cursor_markdown",
            **{k: v for k, v in metadata.items() if k not in ["title", "source", "id"]},
        },
    }


def _parse_plain_markdown(content: str, file_path: Path) -> Dict[str, Any]:
    """Parse plain markdown as a single-message thread.

    The entire markdown content becomes a single message with role="document".
    This is useful for importing notes, documentation, meeting notes, etc.

    The "document" role indicates this is not a conversational message but
    rather imported content that should be treated as reference material.

    Args:
        content: Raw markdown content
        file_path: Path object for the file

    Returns:
        Standard thread_data dict with single document message
    """
    # Extract title from first heading or filename
    title = file_path.stem

    # Try to find first H1 heading
    lines = content.strip().split("\n")
    for line in lines[:10]:  # Check first 10 lines
        line = line.strip()
        if line.startswith("# ") and not line.startswith("##"):
            title = line[2:].strip()
            break

    # Generate thread ID from content hash
    content_hash = hashlib.md5(content.encode()).hexdigest()[:8]
    thread_id = f"md-doc-{content_hash}"

    # Create single message with "document" role
    # This distinguishes imported documents from conversational content
    messages = [{
        "role": "document",
        "content": content.strip(),
    }]

    logger.info(
        "Parsed plain markdown as document",
        file=str(file_path),
        title=title,
        content_length=len(content),
    )

    return {
        "thread_id": thread_id,
        "title": title,
        "messages": messages,
        "source": "markdown",
        "metadata": {
            "original_file": str(file_path),
            "format": "plain_markdown",
            "file_name": file_path.name,
        },
    }
