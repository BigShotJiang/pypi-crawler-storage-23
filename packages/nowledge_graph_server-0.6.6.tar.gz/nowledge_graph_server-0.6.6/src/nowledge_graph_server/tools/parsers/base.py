"""Base utilities for thread file parsing.

Contains format detection and shared utilities.
"""

import json
from pathlib import Path
from typing import Any, Dict

import structlog

logger = structlog.get_logger(__name__)


def detect_format(content: str, file_path: Path) -> str:
    """Auto-detect file format from content and filename.

    Args:
        content: File content (first few lines for peek)
        file_path: Path object for filename inspection

    Returns:
        Detected format string: "markdown", "cursor_export", "claude_code",
        "codex", "opencode", "json", "cursor_vscdb"
    """
    # Check file extension
    if file_path.suffix.lower() in [".md", ".markdown"]:
        return "markdown"

    if file_path.suffix.lower() == ".vscdb":
        return "cursor_vscdb"

    if file_path.suffix.lower() == ".db" and "opencode" in file_path.name.lower():
        return "opencode_sqlite"

    if file_path.suffix.lower() == ".jsonl":
        # Check if it's Codex or Claude Code format
        lines = content.strip().split("\n")
        if lines:
            try:
                first_line = json.loads(lines[0])
                # Codex has session_meta with originator: codex_cli_rs
                if isinstance(first_line, dict):
                    if first_line.get("type") == "session_meta":
                        payload = first_line.get("payload", {})
                        if payload.get("originator") == "codex_cli_rs":
                            return "codex"
                    # Claude Code has specific signatures
                    if "type" in first_line or "sessionId" in first_line:
                        return "claude_code"
            except json.JSONDecodeError:
                pass

    # Try to parse as JSON
    try:
        data = json.loads(content)

        # Check for Cursor export format indicators
        if isinstance(data, dict):
            # Cursor exports typically have "messages" array and metadata
            if "messages" in data and isinstance(data["messages"], list):
                # Check if messages have Cursor-specific fields
                if data["messages"] and all(
                    isinstance(m, dict) and "role" in m and "content" in m
                    for m in data["messages"][:3]
                ):
                    return "cursor_export"
            return "json"

    except json.JSONDecodeError:
        # Not valid JSON, try JSONL (Claude Code format)
        lines = content.strip().split("\n")
        if len(lines) > 1:
            try:
                # Try to parse first few lines as JSON
                parsed_lines = 0
                has_claude_signature = False
                for line in lines[:5]:
                    if line.strip():
                        obj: Dict[str, Any] = json.loads(line)
                        parsed_lines += 1
                        # Check for Claude Code signatures
                        if (
                            isinstance(obj, dict)
                            and obj.get("type")
                            in [
                                "user",
                                "assistant",
                                "file-history-snapshot",
                                "summary",
                            ]
                            or "sessionId" in obj
                        ):
                            has_claude_signature = True

                if parsed_lines >= 2 and has_claude_signature:
                    return "claude_code"
            except json.JSONDecodeError:
                pass

    # Default to generic JSON
    return "json"
