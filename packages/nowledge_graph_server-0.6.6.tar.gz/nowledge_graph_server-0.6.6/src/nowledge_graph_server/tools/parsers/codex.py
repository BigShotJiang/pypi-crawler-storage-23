"""Codex session parser.

Parses Codex JSONL rollout files from ~/.codex/sessions/
"""

import hashlib
import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog

logger = structlog.get_logger(__name__)


def parse_codex_session_streaming(
    file_path: Path, truncate_large_content: bool = False
) -> Dict[str, Any]:
    """Parse Codex rollout JSONL format using streaming (memory-efficient).

    Handles files of any size (100GiB+).

    Args:
        file_path: Path to the Codex rollout JSONL file
        truncate_large_content: If True, truncate tool results > 10KB

    Returns:
        Standard thread_data dict
    """
    # Stream file line-by-line
    session_meta: Optional[Dict[str, Any]] = None
    messages: List[Dict[str, Any]] = []
    first_user_content: Optional[str] = None
    seen_message_hashes: set[str] = set()

    with open(file_path, "r", encoding="utf-8") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue

            try:
                record: Dict[str, Any] = json.loads(line)
            except json.JSONDecodeError as e:
                logger.warning(f"Skipping invalid JSON on line {line_num}: {e}")
                continue

            if not isinstance(record, dict):
                continue

            record_type = record.get("type")
            timestamp = record.get("timestamp")

            # Parse session metadata (first line)
            if record_type == "session_meta" and not session_meta:
                payload = record.get("payload", {})
                session_meta = {
                    "id": payload.get("id"),
                    "timestamp": payload.get("timestamp"),
                    "cwd": payload.get("cwd"),
                    "originator": payload.get("originator"),
                    "cli_version": payload.get("cli_version"),
                    "source": payload.get("source"),
                    "git": payload.get("git"),
                }
                continue

            # Parse user/assistant messages
            role: Optional[str] = None
            content_text: Optional[str] = None
            content_extracted = False

            # Prioritize event_msg over response_item to avoid duplicates
            if record_type == "event_msg":
                payload = record.get("payload", {})
                msg_type = payload.get("type")

                if msg_type == "user_message" and payload.get("kind") == "plain":
                    role = "user"
                    content_text = payload.get("message", "")
                    content_extracted = True
                elif msg_type == "agent_message":
                    role = "assistant"
                    content_text = payload.get("message", "")
                    content_extracted = True

            # Only use response_item if we didn't get content from event_msg
            elif record_type == "response_item" and not content_extracted:
                payload = record.get("payload", {})
                if payload.get("type") == "message":
                    role = payload.get("role")
                    content_items = payload.get("content", [])

                    # Extract text from content items
                    text_parts = []
                    for item in content_items:
                        if isinstance(item, dict):
                            item_type = item.get("type")
                            if item_type in ["input_text", "output_text"]:
                                text = item.get("text", "")
                                if text.strip():
                                    text_parts.append(text)

                    content_text = "\n".join(text_parts) if text_parts else None

            # Add message if we extracted valid content
            if role and content_text and content_text.strip():
                # Create a hash to detect duplicates
                message_hash = hashlib.md5(
                    f"{role}:{content_text}".encode()
                ).hexdigest()

                if message_hash in seen_message_hashes:
                    continue

                seen_message_hashes.add(message_hash)

                # Capture first user message for title
                if role == "user" and not first_user_content:
                    first_user_content = content_text

                messages.append(
                    {
                        "role": role,
                        "content": content_text,
                        "timestamp": timestamp,
                    }
                )

    if not session_meta:
        raise ValueError("No session_meta found in Codex rollout file")

    if not messages:
        raise ValueError(
            "No valid user/assistant messages found in Codex rollout file"
        )

    # Generate title
    title = "Codex Session"
    if first_user_content:
        title = first_user_content[:60].replace("\n", " ").strip()
        if len(first_user_content) > 60:
            title += "..."
    elif session_meta.get("cwd"):
        project_name = os.path.basename(session_meta["cwd"].rstrip("/\\"))
        title = f"Codex: {project_name}"

    # Build thread data
    session_id = session_meta.get("id") or file_path.stem

    thread_data = {
        "thread_id": f"codex-{session_id}",
        "title": title,
        "messages": messages,
        "source": "codex",
        "metadata": {
            "session_id": session_id,
            "timestamp": session_meta.get("timestamp"),
            "cwd": session_meta.get("cwd"),
            "git": session_meta.get("git"),
            "cli_version": session_meta.get("cli_version"),
            "originator": session_meta.get("originator"),
            "original_file_path": str(file_path),
        },
    }

    logger.info(
        "Parsed Codex session (streaming)",
        session_id=session_id,
        message_count=len(messages),
        cwd=session_meta.get("cwd"),
    )

    return thread_data
