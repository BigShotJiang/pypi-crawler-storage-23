"""Claude Code session parser.

Parses Claude Code JSONL session files from ~/.claude/projects/
"""

import json
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog

logger = structlog.get_logger(__name__)


def discover_subagent_files(main_session_path: Path) -> List[Path]:
    """Discover subagent files for a Claude Code session.

    Claude Code stores subagent files in a directory structure like:
    ~/.claude/projects/{project}/{session_id}/subagents/agent-{agent_id}.jsonl

    The subagent directory is named after the main session file (without .jsonl extension).

    Args:
        main_session_path: Path to the main session JSONL file

    Returns:
        List of paths to subagent JSONL files
    """
    subagent_files = []

    # Subagents are stored in: {session_dir}/{session_stem}/subagents/
    # Where session_stem is the main session filename without extension
    session_dir = main_session_path.parent
    session_stem = main_session_path.stem

    # Check for subagents directory
    subagents_dir = session_dir / session_stem / "subagents"
    if subagents_dir.exists() and subagents_dir.is_dir():
        for agent_file in subagents_dir.glob("agent-*.jsonl"):
            subagent_files.append(agent_file)
        logger.debug(
            "Found subagent files",
            main_session=str(main_session_path),
            count=len(subagent_files),
        )

    return sorted(subagent_files, key=lambda p: p.stat().st_mtime)


def parse_subagent_file(
    agent_file: Path, truncate_large_content: bool = False
) -> Optional[Dict[str, Any]]:
    """Parse a single subagent JSONL file.

    Args:
        agent_file: Path to the subagent JSONL file
        truncate_large_content: If True, truncate tool results > 10KB

    Returns:
        Dict with subagent data including messages, or None on failure
    """
    try:
        # Extract agent ID from filename (agent-{id}.jsonl)
        agent_id = agent_file.stem
        if agent_id.startswith("agent-"):
            agent_id = agent_id[6:]  # Remove "agent-" prefix

        messages: List[Dict[str, Any]] = []
        task_description = None
        session_id = None

        with open(agent_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue

                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    continue

                if not isinstance(event, dict):
                    continue

                # Extract session ID
                if "sessionId" in event and not session_id:
                    session_id = event["sessionId"]

                event_type = event.get("type")

                # Extract task description from first user message
                if event_type == "user" and not task_description:
                    msg_data = event.get("message", {})
                    content = msg_data.get("content", "")
                    if isinstance(content, str):
                        task_description = content[:200]
                        if len(content) > 200:
                            task_description += "..."

                # Collect user/assistant messages
                if event_type in ["user", "assistant"]:
                    msg_data = event.get("message", {})
                    content = msg_data.get("content", "")

                    # Handle array content
                    if isinstance(content, list):
                        text_parts = []
                        for block in content:
                            if isinstance(block, dict):
                                if block.get("type") == "text":
                                    text_parts.append(block.get("text", ""))
                                elif block.get("type") == "tool_use":
                                    tool_name = block.get("name", "unknown_tool")
                                    tool_input = block.get("input", {})
                                    summary = _summarize_claude_tool_input(
                                        tool_name, tool_input
                                    )
                                    if summary:
                                        text_parts.append(
                                            f"[Used tool: {tool_name}] {summary}"
                                        )
                                    else:
                                        text_parts.append(
                                            f"[Used tool: {tool_name}]"
                                        )
                        content = "\n\n".join(text_parts)

                    if content and isinstance(content, str) and content.strip():
                        messages.append({
                            "role": event_type,
                            "content": content,
                            "timestamp": event.get("timestamp"),
                        })

        if not messages:
            return None

        return {
            "agent_id": agent_id,
            "session_id": session_id,
            "task_description": task_description,
            "message_count": len(messages),
            "messages": messages,
            "file_path": str(agent_file),
        }

    except Exception as e:
        logger.warning(
            "Failed to parse subagent file",
            file=str(agent_file),
            error=str(e),
        )
        return None


def parse_claude_code_session_streaming(
    file_path: Path, truncate_large_content: bool = False
) -> Dict[str, Any]:
    """Parse Claude Code session JSONL format using streaming (memory-efficient).

    This version streams the file line-by-line instead of loading it all into memory.
    Handles files of any size (100GiB+).
    Also discovers and parses any associated subagent files.

    Args:
        file_path: Path to the Claude Code session JSONL file
        truncate_large_content: If True, truncate tool results > 10KB

    Returns:
        Standard thread_data dict
    """
    # Stream file line-by-line
    events: List[Dict[str, Any]] = []
    session_id = None
    cwd = None

    # Parse directory path from file location (cross-platform)
    decoded_path = None
    file_str = str(file_path)

    # Check for Claude projects path (cross-platform separators)
    claude_marker_unix = "/.claude/projects/"
    claude_marker_win = "\\.claude\\projects\\"

    if claude_marker_unix in file_str:
        parts = file_str.split(claude_marker_unix)
        if len(parts) > 1:
            encoded_dir = parts[1].split("/")[0]
            if encoded_dir.startswith("-"):
                decoded_path = "/" + encoded_dir[1:].replace("-", "/")
    elif claude_marker_win in file_str:
        parts = file_str.split(claude_marker_win)
        if len(parts) > 1:
            encoded_dir = parts[1].split("\\")[0]
            # Windows: C-Users-user-project -> C:\Users\user\project
            drive_match = re.match(r"^([A-Za-z])-(.*)$", encoded_dir)
            if drive_match:
                drive_letter = drive_match.group(1)
                rest = drive_match.group(2).replace("-", "\\")
                decoded_path = f"{drive_letter}:\\{rest}"

    # First pass: stream and collect events
    with open(file_path, "r", encoding="utf-8") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue

            try:
                event: Dict[str, Any] = json.loads(line)
            except json.JSONDecodeError as e:
                logger.warning(f"Skipping invalid JSON on line {line_num}: {e}")
                continue

            if not isinstance(event, dict):
                continue

            event_type = event.get("type")

            # Extract session metadata
            if "sessionId" in event and not session_id:
                session_id = event["sessionId"]
            if "cwd" in event and not cwd:
                cwd = event["cwd"]

            # Collect user/assistant events
            if event_type in ["user", "assistant"]:
                events.append(event)

    if not events:
        raise ValueError("No valid user/assistant messages found in JSONL file")

    # Second pass: group events into conversation turns
    messages: List[Dict[str, Any]] = []
    first_user_content = None

    i = 0
    while i < len(events):
        event = events[i]
        role = event.get("message", {}).get("role", event.get("type"))

        # Collect all consecutive events with the same role
        turn_events = [event]
        current_uuid = event.get("uuid")
        timestamp = event.get("timestamp")

        # Look ahead for events with same role that are part of this turn
        j = i + 1
        while j < len(events):
            next_event = events[j]
            next_role = next_event.get("message", {}).get(
                "role", next_event.get("type")
            )

            # Stop if role changes
            if next_role != role:
                break

            # Check if this event is part of the same turn
            if next_event.get("parentUuid") == current_uuid:
                turn_events.append(next_event)
                current_uuid = next_event.get("uuid")
                j += 1
            else:
                break

        # Merge content from all events in this turn
        content_parts: List[str] = []
        for evt in turn_events:
            msg_data = evt.get("message", {})
            if not isinstance(msg_data, dict):
                continue

            content_raw = msg_data.get("content", "")

            # Handle content: can be string or array of content blocks
            if isinstance(content_raw, str):
                if content_raw.strip():
                    content_parts.append(content_raw)
            elif isinstance(content_raw, list):
                # Extract text from content blocks
                for block in content_raw:
                    if isinstance(block, dict):
                        if block.get("type") == "text":
                            text = block.get("text", "")
                            if text.strip():
                                content_parts.append(text)
                        elif block.get("type") == "tool_use":
                            tool_name = block.get("name", "unknown_tool")
                            tool_input = block.get("input", {})
                            tool_summary = _summarize_claude_tool_input(
                                tool_name, tool_input
                            )
                            if tool_summary:
                                content_parts.append(
                                    f"[Used tool: {tool_name}] {tool_summary}"
                                )
                            else:
                                content_parts.append(
                                    f"[Used tool: {tool_name}]"
                                )
                        elif block.get("type") == "tool_result":
                            # Tool results are noise in conversation view —
                            # the assistant's text already summarizes findings.
                            # Skip them entirely.
                            pass
                    elif isinstance(block, str):
                        if block.strip():
                            content_parts.append(block)

        content = "\n\n".join(content_parts) if content_parts else ""

        # Skip empty turns
        if not content.strip():
            i = max(i + 1, j)
            continue

        # Capture first user message for title generation
        if role == "user" and not first_user_content:
            first_user_content = content

        messages.append(
            {
                "role": role,
                "content": content,
                "timestamp": timestamp,
                "metadata": {
                    "uuid": event.get("uuid"),
                    "parentUuid": event.get("parentUuid"),
                    "turn_event_count": len(turn_events),
                },
            }
        )

        # Move to next ungrouped event
        i = max(i + 1, j)

    if not messages:
        raise ValueError("No valid user/assistant messages found in JSONL file")

    # Generate title
    title = "Claude Code Session"
    if first_user_content:
        title = first_user_content[:60].replace("\n", " ").strip()
        if len(first_user_content) > 60:
            title += "..."
    elif decoded_path:
        project_name = os.path.basename(decoded_path.rstrip("/\\"))
        title = f"Claude Code: {project_name}"

    # Build thread data
    thread_id = session_id or file_path.stem

    thread_data: Dict[str, Any] = {
        "thread_id": f"claude-code-{thread_id}",
        "title": title,
        "messages": messages,
        "source": "claude-code",
        "metadata": {
            "sessionId": session_id,
            "cwd": cwd,
            "original_file_path": str(file_path),
        },
    }

    if decoded_path:
        thread_data["metadata"]["decoded_project_path"] = decoded_path

    # Discover and parse subagent files
    subagent_files = discover_subagent_files(file_path)
    if subagent_files:
        subagents = []
        total_subagent_messages = 0

        for agent_file in subagent_files:
            subagent_data = parse_subagent_file(agent_file, truncate_large_content)
            if subagent_data:
                subagents.append({
                    "agent_id": subagent_data["agent_id"],
                    "session_id": subagent_data.get("session_id"),
                    "task_description": subagent_data.get("task_description"),
                    "message_count": subagent_data["message_count"],
                    "file_path": subagent_data["file_path"],
                    # Include full messages for detailed view
                    "messages": subagent_data["messages"],
                })
                total_subagent_messages += subagent_data["message_count"]

        if subagents:
            thread_data["metadata"]["subagents"] = subagents
            thread_data["metadata"]["subagent_count"] = len(subagents)
            thread_data["metadata"]["total_subagent_messages"] = total_subagent_messages

            logger.info(
                "Parsed subagent sessions",
                main_session=session_id,
                subagent_count=len(subagents),
                total_messages=total_subagent_messages,
            )

    logger.info(
        "Parsed Claude Code session (streaming)",
        session_id=session_id,
        message_count=len(messages),
        project_path=decoded_path,
        has_subagents=len(subagent_files) > 0,
    )

    return thread_data


def _summarize_claude_tool_input(
    tool_name: str, tool_input: Dict[str, Any]
) -> str:
    """Generate a concise input summary for a Claude Code tool call.

    Args:
        tool_name: Tool name (Read, Write, Edit, Bash, Grep, Glob, etc.)
        tool_input: Tool input parameters

    Returns:
        Brief summary string, or empty string
    """
    if not tool_input:
        return ""

    name_lower = tool_name.lower()

    if name_lower in ("read", "write", "edit"):
        path = tool_input.get("file_path", "")
        if path:
            return path
    elif name_lower == "bash":
        cmd = tool_input.get("command", "")
        desc = tool_input.get("description", "")
        if desc:
            return desc
        if cmd:
            display = cmd[:200]
            if len(cmd) > 200:
                display += "..."
            return f"$ {display}"
    elif name_lower == "grep":
        pattern = tool_input.get("pattern", "")
        path = tool_input.get("path", "")
        if pattern:
            result = pattern
            if path:
                result += f" in {path}"
            return result
    elif name_lower == "glob":
        pattern = tool_input.get("pattern", "")
        if pattern:
            return pattern
    elif name_lower == "task":
        desc = tool_input.get("description", "")
        if desc:
            return desc
    elif name_lower == "webfetch":
        url = tool_input.get("url", "")
        if url:
            return url
    elif name_lower == "websearch":
        query = tool_input.get("query", "")
        if query:
            return query

    return ""
