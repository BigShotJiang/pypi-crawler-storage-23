"""MCP tools for Nowledge Graph server."""

from fastmcp import FastMCP


def register_all_tools(mcp: FastMCP) -> None:
    """Register all MCP tools with the server.

    Args:
        mcp: FastMCP server instance
    """
    # Tools are defined directly in server.py for now
    # This function is called to satisfy the import in server.py
    pass
