"""FastAPI server for Nowledge Graph."""

import os

# CRITICAL: Disable HuggingFace XET (Git LFS) system before any imports
# This prevents duplicate storage in ~/.cache/huggingface/xet/ directory
# Must be set before huggingface_hub is imported anywhere in the application
# See: https://github.com/huggingface/huggingface_hub/issues/3266
if "HF_HUB_DISABLE_XET" not in os.environ:
    os.environ["HF_HUB_DISABLE_XET"] = "1"

from nowledge_graph_server.main import app  # type: ignore


if __name__ == "__main__":
    from nowledge_graph_server.main import run_dev_server

    run_dev_server(port=14242)
