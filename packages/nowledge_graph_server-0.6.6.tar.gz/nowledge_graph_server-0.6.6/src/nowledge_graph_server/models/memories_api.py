from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

# Response models for memory endpoints
class MemoryLabelsResponse(BaseModel):
    """Response for memory labels."""
    labels: List[Dict[str, Any]] = Field(default_factory=list, description="List of labels assigned to the memory")
    class Config:
        extra = "allow"


class MessageResponse(BaseModel):
    """Generic message response."""
    message: str = Field(..., description="Response message")
    class Config:
        extra = "allow"


class SourceThreadInfo(BaseModel):
    """Source thread information."""
    id: str = Field(..., description="Thread ID")
    title: str = Field(..., description="Thread title")
    class Config:
        extra = "allow"


class MemoryPublic(BaseModel):
    """Frontend memory format."""
    id: str = Field(..., description="Memory ID")
    title: str = Field(..., description="Memory title")
    content: str = Field(..., description="Memory content")
    source: str = Field(..., description="Memory source")
    time: str = Field(..., description="Formatted time string")
    rating: int = Field(..., description="Rating 1-5")
    label_ids: List[str] = Field(default_factory=list, description="Label IDs")
    is_favorite: bool = Field(default=False, description="Favorite status")
    source_thread: Optional[SourceThreadInfo] = Field(default=None, description="Source thread info")
    confidence: Optional[float] = Field(default=None, description="Confidence score")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")
    class Config:
        extra = "allow"


class PaginationInfo(BaseModel):
    """Pagination metadata."""
    limit: int = Field(..., description="Items per page")
    offset: int = Field(..., description="Offset")
    total: int = Field(..., description="Total items")
    has_more: bool = Field(..., description="Whether more items available")
    class Config:
        extra = "allow"


class SearchMetadata(BaseModel):
    """Search metadata."""
    query: Optional[str] = Field(default=None, description="Search query")
    search_mode: str = Field(..., description="Search mode used")
    filters_applied: Dict[str, Any] = Field(default_factory=dict, description="Applied filters")
    total_found: int = Field(..., description="Total results found")
    intelligent_search: bool = Field(..., description="Whether intelligent search was used")
    strategies_used: Optional[List[str]] = Field(default=None, description="Search strategies used")
    search_reasoning: Optional[str] = Field(default=None, description="Search reasoning explanation")
    graph_traversal: Optional[Dict[str, Any]] = Field(default=None, description="Graph traversal metadata")
    search_intelligence: Optional[Dict[str, Any]] = Field(default=None, description="Search intelligence metadata")
    class Config:
        extra = "allow"


class MemorySearchResponse(BaseModel):
    """Response from enhanced memory search."""
    memories: List[MemoryPublic] = Field(default_factory=list, description="Search results")
    pagination: PaginationInfo = Field(..., description="Pagination info")
    search_metadata: SearchMetadata = Field(..., description="Search metadata")
    class Config:
        extra = "allow"


class MemoryListResponse(BaseModel):
    """Response from listing memories."""
    memories: List[MemoryPublic] = Field(default_factory=list, description="List of memories")
    pagination: PaginationInfo = Field(..., description="Pagination info")
    class Config:
        extra = "allow"


class DeleteMemoryResponse(BaseModel):
    """Response from deleting a memory."""
    message: str = Field(..., description="Success message")
    deleted_relationships: int = Field(..., description="Number of relationships deleted")
    deleted_entities: int = Field(..., description="Number of entities deleted")
    class Config:
        extra = "allow"


class ReindexStatusResponse(BaseModel):
    """Response for reindex status."""
    count_needing_reindex: int = Field(..., description="Number of memories needing reindex")
    sample_memories: List[Dict[str, Any]] = Field(default_factory=list, description="Sample of memories")
    has_memories_needing_reindex: bool = Field(..., description="Whether any memories need reindex")
    all_memory_ids: Optional[List[str]] = Field(default=None, description="All memory IDs needing reindex")
    class Config:
        extra = "allow"


class ReindexDetail(BaseModel):
    """Detail for a single memory reindex operation."""
    memory_id: str = Field(..., description="Memory ID")
    status: str = Field(..., description="Status: 'reindexed', 'failed', or 'skipped'")
    error: Optional[str] = Field(default=None, description="Error message if failed")
    reason: Optional[str] = Field(default=None, description="Reason for skipping")
    embedding_dimension: Optional[int] = Field(default=None, description="Embedding dimension if reindexed")
    class Config:
        extra = "allow"


class ReindexResponse(BaseModel):
    """Response from reindex operation."""
    success: bool = Field(..., description="Whether reindex succeeded")
    processed: int = Field(..., description="Number of memories processed")
    failed: int = Field(default=0, description="Number of memories that failed")
    error: Optional[str] = Field(default=None, description="Error message if any")
    details: List[ReindexDetail] = Field(default_factory=list, description="Per-memory reindex details")
    class Config:
        extra = "allow"


class ThreadPublic(BaseModel):
    """Frontend thread format."""
    id: str = Field(..., description="Thread ID")
    title: str = Field(..., description="Thread title")
    source: str = Field(..., description="Thread source")
    messages: int = Field(..., description="Number of messages")
    date: str = Field(..., description="Formatted date string")
    is_favorite: bool = Field(default=False, description="Favorite status")
    created_at: Optional[str] = Field(default=None, description="Creation timestamp")
    last_activity: Optional[str] = Field(default=None, description="Last activity timestamp")
    class Config:
        extra = "allow"