from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


# Define structured response models
class MemorySearchResult(BaseModel):
    """Single memory search result."""

    memory_id: str = Field(description="Unique memory identifier for updates")
    content: str = Field(description="Memory content")
    title: Optional[str] = Field(description="Memory title")
    importance: float = Field(description="Importance score 0.0-1.0")
    similarity_score: Optional[float] = Field(description="Semantic similarity score")
    created_at: str = Field(description="Creation timestamp")
    source_thread_id: Optional[str] = Field(
        default=None,
        description="Thread ID this memory was distilled from (if any). Use thread_fetch_messages to get full content.",
    )


class MemorySearchResponse(BaseModel):
    """Memory search response structure."""

    status: str = Field(description="Response status")
    results: List[MemorySearchResult] = Field(description="Search results")
    query: str = Field(description="Original search query")
    total_found: int = Field(description="Number of results found")
    filter_labels: Optional[str] = Field(description="Applied label filters")
    filters_applied: Optional[Dict[str, Any]] = Field(
        default=None, description="Which temporal filters were actually applied"
    )


class LabelInfo(BaseModel):
    """Label information with usage count."""

    name: str = Field(description="Label name")
    usage_count: int = Field(description="Number of memories using this label")


class LabelsResponse(BaseModel):
    """Labels list response structure."""

    labels: List[LabelInfo] = Field(description="Available labels")
    total: int = Field(description="Total number of labels")


class MemoryInfo(BaseModel):
    """Created memory information."""

    content: str = Field(description="Memory content (truncated if long)")
    title: Optional[str] = Field(description="Memory title")
    importance: float = Field(description="Importance score")
    created_at: str = Field(description="Creation timestamp")


class ProcessingInfo(BaseModel):
    """Memory processing information."""

    entities_extracted: int = Field(description="Number of entities extracted")
    labels_applied: int = Field(description="Number of labels applied")
    source: str = Field(description="Source application/client")


class MemoryAddResponse(BaseModel):
    """Memory creation response structure."""

    status: str = Field(description="Response status")
    memory: MemoryInfo = Field(description="Created memory information")
    processing: ProcessingInfo = Field(description="Processing details")


class UpdateInfo(BaseModel):
    """Memory update information."""

    fields_updated: List[str] = Field(description="List of fields that were updated")
    labels_added: int = Field(description="Number of labels added")
    labels_removed: int = Field(description="Number of labels removed")


class MemoryUpdateResponse(BaseModel):
    """Memory update response structure."""

    status: str = Field(description="Response status")
    memory: MemoryInfo = Field(description="Updated memory information")
    updates: UpdateInfo = Field(description="Summary of changes made")


class DeletionInfo(BaseModel):
    """Information about what was deleted."""

    deleted_relationships: int = Field(description="Number of relationships deleted")
    deleted_entities: int = Field(description="Number of entities deleted")


class MemoryDeleteResponse(BaseModel):
    """Memory deletion response structure."""

    status: str = Field(description="Response status ('success' or 'error')")
    message: str = Field(description="Deletion result message")
    deletion: Optional[DeletionInfo] = Field(
        default=None, description="Details about what was deleted"
    )


class BulkDeleteItem(BaseModel):
    """Per-memory status in a bulk delete operation."""

    memory_id: str = Field(description="Memory ID processed in bulk deletion")
    status: str = Field(description="Per-memory status ('success', 'not_found', or 'error')")
    message: str = Field(description="Per-memory deletion message")
    deletion: Optional[DeletionInfo] = Field(
        default=None, description="Deletion details for this memory when successful"
    )


class BulkDeletionSummary(BaseModel):
    """Summary for a bulk memory delete operation."""

    requested_count: int = Field(description="Number of IDs provided by the caller")
    processed_count: int = Field(description="Number of unique, non-empty IDs processed")
    deleted_count: int = Field(description="Number of memories deleted successfully")
    failed_count: int = Field(description="Number of memories that failed to delete")
    deleted_relationships: int = Field(description="Total relationships deleted across all memories")
    deleted_entities: int = Field(description="Total entities deleted across all memories")


class BulkMemoryDeleteResponse(BaseModel):
    """Bulk memory deletion response structure."""

    status: str = Field(description="Response status ('success', 'partial_success', or 'error')")
    message: str = Field(description="Bulk deletion result message")
    summary: BulkDeletionSummary = Field(description="Aggregate deletion summary")
    results: List[BulkDeleteItem] = Field(description="Per-memory deletion results")
