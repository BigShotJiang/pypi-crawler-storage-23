"""Graph data models for Nowledge Graph."""

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Union
from uuid import uuid4

from pydantic import BaseModel, Field, field_validator, ConfigDict
import real_ladybug as kuzu

class NodeType(str, Enum):
    """Enumeration of node types in the graph."""

    THREAD = "Thread"
    MESSAGE = "Message"
    MEMORY = "Memory"
    ENTITY = "Entity"
    LABEL = "Label"
    COMMUNITY = "Community"
    SOURCE = "Source"


class RelationshipType(str, Enum):
    """Enumeration of relationship types in the graph."""

    CONTAINS = "CONTAINS"
    COMPACTS_TO = "COMPACTS_TO"
    EXTRACTED_FROM = "EXTRACTED_FROM"
    MENTIONS = "MENTIONS"
    RELATES_TO = "RELATES_TO"
    HAS_LABEL = "HAS_LABEL"
    BELONGS_TO = "BELONGS_TO"
    SOURCED_FROM = "SOURCED_FROM"
    REVISED_AS = "REVISED_AS"


class BaseNode(BaseModel):
    """Base class for all graph nodes."""

    model_config = ConfigDict(use_enum_values=True)

    id: str = Field(default_factory=lambda: str(uuid4()))
    node_type: NodeType
    created_at: datetime = Field(default_factory=datetime.utcnow) # type: ignore
    updated_at: datetime = Field(default_factory=datetime.utcnow) # type: ignore
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ThreadNode(BaseNode):
    """Thread node representing a conversation."""

    node_type: NodeType = Field(default=NodeType.THREAD, frozen=True)
    thread_id: str = Field(..., description="Human-readable thread identifier")
    title: Optional[str] = Field(default=None, description="Thread title")
    summary: Optional[str] = Field(default=None, description="Thread summary for embedding")
    message_count: int = Field(default=0, description="Number of messages in thread")
    participants: List[str] = Field(
        default_factory=list, description="Thread participants"
    )
    source: Optional[str] = Field(
        default=None, description="Source system (cursor, claude, etc.)"
    )

    # Flattened properties for performance
    project: Optional[str] = Field(default=None, description="Project identifier")
    workspace: Optional[str] = Field(default=None, description="Workspace path")
    tool_version: Optional[str] = Field(
        default=None, description="Tool version that created this thread"
    )
    import_date: Optional[datetime] = Field(
        default=None, description="When thread was imported"
    )

    @field_validator("thread_id")
    def validate_thread_id(cls, v: str) -> str:
        """Validate thread ID format."""
        if not v or len(v) < 3:
            raise ValueError("Thread ID must be at least 3 characters long")
        return v.lower().replace(" ", "-")


class MessageNode(BaseNode):
    """Message node representing a single message in a conversation."""

    node_type: NodeType = Field(default=NodeType.MESSAGE, frozen=True)
    content: str = Field(..., description="Message content")
    role: str = Field(..., description="Message role (user, assistant, system)")
    order_index: int = Field(..., description="Order within thread")
    timestamp: Optional[datetime] = Field(
        default=None, description="Original message timestamp"
    )
    token_count: Optional[int] = Field(default=None, description="Approximate token count")


class MemoryNode(BaseNode):
    """Memory node representing distilled knowledge from conversations."""

    node_type: NodeType = Field(default=NodeType.MEMORY, frozen=True)
    content: str = Field(..., description="Memory content")
    title: Optional[str] = Field(default=None, description="Memory title/heading")
    importance: Optional[float] = Field(
        default=0.5, ge=0.0, le=1.0, description="Importance score"
    )
    confidence: Optional[float] = Field(
        default=0.5, ge=0.0, le=1.0, description="Confidence score"
    )
    embedding: Optional[List[float]] = Field(default=None, description="Vector embedding")
    source_range: Optional[Dict[str, int]] = Field(
        default=None, description="Source message range {start_index, end_index}"
    )
    source: Optional[str] = Field(
        default=None, description="Source application (cursor, chatwise, manual, etc.)"
    )

    # Semantic search and indexing fields
    semantic_field: Optional[str] = Field(
        default=None, description="Combined title+content for optimized indexing and search"
    )
    reindex_needed: Optional[bool] = Field(
        default=False, description="Whether memory needs reindexing after edits"
    )

    @field_validator('importance', 'confidence', mode='before')
    @classmethod
    def coerce_float_none(cls, v):
        """Coerce None to default value for float fields."""
        return v if v is not None else 0.5

    @field_validator('reindex_needed', mode='before')
    @classmethod
    def coerce_bool_none(cls, v):
        """Coerce None to default value for bool fields."""
        return v if v is not None else False
    last_reindexed_at: Optional[datetime] = Field(
        default=None, description="When memory was last reindexed"
    )

    # Minimal decay model fields (added 2025-11-20)
    last_accessed_at: Optional[datetime] = Field(
        default=None, description="Last time memory was shown in results or clicked"
    )
    access_count: int = Field(
        default=0, description="Total number of accesses (for frequency boost)"
    )
    appearances: int = Field(
        default=0, description="Times shown in search results"
    )
    clicks: int = Field(
        default=0, description="Times clicked/opened by user"
    )
    total_dwell_time_ms: int = Field(
        default=0, description="Total time spent reading (milliseconds)"
    )
    last_clicked_at: Optional[datetime] = Field(
        default=None, description="Last time user clicked/opened this memory"
    )
    decay_score_cached: float = Field(
        default=1.0, ge=0.0, le=1.0, description="Pre-computed decay score (0-1)"
    )

    # Bi-temporal fields (added 2025-11-20)
    temporal_context: Optional[str] = Field(
        default="timeless", description="Temporal context: past/present/future/timeless"
    )
    temporal_type: Optional[str] = Field(
        default=None, description="Temporal type: exact/range/unknown"
    )
    event_start: Optional[str] = Field(
        default=None, description="Event start date (normalized YYYY-MM-DD)"
    )
    event_end: Optional[str] = Field(
        default=None, description="Event end date (for ranges, normalized YYYY-MM-DD)"
    )
    temporal_precision: Optional[str] = Field(
        default=None, description="Date precision for UI display: year/month/day"
    )
    temporal_confidence: Optional[float] = Field(
        default=None, ge=0.0, le=1.0, description="LLM confidence in temporal extraction (0-1)"
    )

    # Knowledge Agent fields (v0.6)
    unit_type: str = Field(
        default="fact",
        description="Knowledge unit type: fact|preference|decision|plan|procedure|learning|context|event",
    )
    is_latest: bool = Field(
        default=True,
        description="Head of EVOLVES(replaces) version chain",
    )
    version: int = Field(
        default=1,
        description="Version counter within EVOLVES chain",
    )
    is_crystal: bool = Field(
        default=False,
        description="True for crystallized knowledge synthesized from multiple sources",
    )
    crystal_title: Optional[str] = Field(
        default=None,
        description="Human-readable crystal title (only when is_crystal=true)",
    )
    source_unit_count: Optional[int] = Field(
        default=None,
        description="Number of source units (only when is_crystal=true)",
    )
    extraction_method: str = Field(
        default="manual",
        description="How this memory was created: manual|llm|rule|agent",
    )
    last_evaluated_at: Optional[datetime] = Field(
        default=None,
        description="When this crystal was last checked for staleness (only when is_crystal=true)",
    )

    @field_validator("content")
    def validate_content_length(cls, v: str) -> str:
        """Validate memory content length."""
        if len(v) > 65536:  # Allow up to 64KB for internal processing, API limits at 32768
            raise ValueError("Memory content too long (max 65536 characters)")
        return v


class EntityNode(BaseNode):
    """Entity node representing concepts, people, places, etc."""

    node_type: NodeType = Field(default=NodeType.ENTITY, frozen=True)
    name: str = Field(..., description="Entity name")
    entity_type: str = Field(..., description="Entity type (person, concept, etc.)")
    description: Optional[str] = Field(default=None, description="Entity description")
    aliases: List[str] = Field(default_factory=list, description="Alternative names")
    confidence: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Entity confidence"
    )

    # Bi-temporal fields (added 2025-11-20)
    entity_created: Optional[str] = Field(
        default=None, description="When entity was created/born/founded (normalized YYYY-MM-DD)"
    )
    entity_ended: Optional[str] = Field(
        default=None, description="When entity died/closed/discontinued (normalized YYYY-MM-DD)"
    )
    temporal_precision: Optional[str] = Field(
        default=None, description="Date precision for UI display: year/month/day"
    )
    temporal_confidence: Optional[float] = Field(
        default=None, ge=0.0, le=1.0, description="LLM confidence in temporal extraction (0-1)"
    )
    temporal_context: Optional[str] = Field(
        default=None, description="Temporal context: past/present/timeless"
    )

    @field_validator("name")
    def validate_name(cls, v: str) -> str:
        """Validate entity name."""
        if not v or len(v.strip()) < 2:
            raise ValueError("Entity name must be at least 2 characters")
        return v.strip()


class LabelNode(BaseNode):
    """Label node for user-driven organization."""

    node_type: NodeType = Field(default=NodeType.LABEL, frozen=True)
    name: str = Field(..., description="Label name")
    color: Optional[str] = Field(default=None, description="Label color (hex)")
    description: Optional[str] = Field(default=None, description="Label description")

    @field_validator("name")
    def validate_label_name(cls, v: str) -> str:
        """Validate label name."""
        if not v or len(v.strip()) < 1:
            raise ValueError("Label name cannot be empty")
        return v.strip().lower()

    @field_validator("color")
    def validate_color(cls, v: Optional[str]) -> Optional[str]:
        """Validate hex color format."""
        if v and not v.startswith("#"):
            v = f"#{v}"
        if v and len(v) != 7:
            raise ValueError("Color must be a valid hex color (#RRGGBB)")
        return v


class SourceNode(BaseNode):
    """Source node representing an external artifact (file, URL, note)."""

    node_type: NodeType = Field(default=NodeType.SOURCE, frozen=True)
    source_type: str = Field(
        ..., description="Source type: file, url, obsidian_note"
    )
    original_name: str = Field(..., description="Original filename or URL title")
    mime_type: Optional[str] = Field(default=None, description="MIME type")
    file_path: Optional[str] = Field(
        default=None, description="Path to raw file in ~/ai-now/sources/"
    )
    parsed_path: Optional[str] = Field(
        default=None, description="Path to parsed .md file"
    )
    source_url: Optional[str] = Field(
        default=None, description="Source URL (for url type)"
    )
    sha256: Optional[str] = Field(
        default=None, description="Content hash for dedup/change detection"
    )
    size_bytes: int = Field(default=0, description="Raw file size in bytes")
    version: int = Field(default=1, description="Version number (increments on revision)")
    lifecycle_state: str = Field(
        default="ingested",
        description="Lifecycle state: ingested|parsed|chunked|indexed|extracted|stale|error",
    )
    chunk_count: int = Field(default=0, description="Number of chunks after parsing")
    memory_count: int = Field(default=0, description="Number of memories extracted")
    section_tree: Optional[str] = Field(
        default=None, description="JSON: heading hierarchy from parsed markdown"
    )
    summary: Optional[str] = Field(
        default=None, description="Summary for display and embedding"
    )
    error_message: Optional[str] = Field(
        default=None, description="Error message if lifecycle_state is 'error'"
    )


class CommunityNode(BaseNode):
    """Community node for entity clustering."""

    node_type: NodeType = Field(default=NodeType.COMMUNITY, frozen=True)
    name: str = Field(..., description="Community name")
    description: Optional[str] = Field(default=None, description="Community description")
    size: int = Field(default=0, description="Number of entities in community")
    cohesion: float = Field(
        default=0.0, ge=0.0, le=1.0, description="Community cohesion score"
    )


class BaseRelationship(BaseModel):
    """Base class for all relationships."""

    model_config = ConfigDict(use_enum_values=True)

    id: str = Field(default_factory=lambda: str(uuid4()))
    relationship_type: RelationshipType
    from_node_id: str = Field(..., description="Source node ID")
    to_node_id: str = Field(..., description="Target node ID")
    created_at: datetime = Field(default_factory=datetime.utcnow) # type: ignore
    properties: Dict[str, Any] = Field(default_factory=dict)


class ContainsRelationship(BaseRelationship):
    """Thread contains Message relationship."""

    relationship_type: RelationshipType = Field(
        default=RelationshipType.CONTAINS, frozen=True
    )
    order_index: int = Field(..., description="Message order in thread")


class CompactsToRelationship(BaseRelationship):
    """Thread compacts to Memory relationship."""

    relationship_type: RelationshipType = Field(
        default=RelationshipType.COMPACTS_TO, frozen=True
    )
    compaction_method: str = Field(default="auto", description="How memory was created")


class ExtractedFromRelationship(BaseRelationship):
    """Memory extracted from Message(s) relationship."""

    relationship_type: RelationshipType = Field(
        default=RelationshipType.EXTRACTED_FROM, frozen=True
    )
    extraction_confidence: float = Field(default=0.5, ge=0.0, le=1.0)


class MentionsRelationship(BaseRelationship):
    """Memory mentions Entity relationship."""

    relationship_type: RelationshipType = Field(
        default=RelationshipType.MENTIONS, frozen=True
    )
    confidence: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Mention confidence"
    )
    mention_count: int = Field(default=1, description="Number of mentions")


class RelatesToRelationship(BaseRelationship):
    """Entity relates to Entity relationship."""

    relationship_type: RelationshipType = Field(
        default=RelationshipType.RELATES_TO, frozen=True
    )
    relation_type: str = Field(..., description="Type of relationship")
    strength: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Relationship strength"
    )
    bidirectional: bool = Field(
        default=False, description="Whether relationship is bidirectional"
    )


class HasLabelRelationship(BaseRelationship):
    """Node has Label relationship."""

    relationship_type: RelationshipType = Field(
        default=RelationshipType.HAS_LABEL, frozen=True
    )
    assigned_by: Optional[str] = Field(default=None, description="Who assigned the label")


class BelongsToRelationship(BaseRelationship):
    """Entity belongs to Community relationship."""

    relationship_type: RelationshipType = Field(
        default=RelationshipType.BELONGS_TO, frozen=True
    )
    strength: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Community membership strength"
    )


class SourcedFromRelationship(BaseRelationship):
    """Memory sourced from Source relationship (provenance)."""

    relationship_type: RelationshipType = Field(
        default=RelationshipType.SOURCED_FROM, frozen=True
    )
    chunk_index: Optional[int] = Field(
        default=None, description="Chunk index within source"
    )
    chunk_range: Optional[str] = Field(
        default=None, description="Section reference, e.g. '§3.2 Authentication'"
    )
    source_version: int = Field(
        default=1, description="Which version of the source"
    )


class RevisedAsRelationship(BaseRelationship):
    """Source revised as another Source (version history)."""

    relationship_type: RelationshipType = Field(
        default=RelationshipType.REVISED_AS, frozen=True
    )
    diff_summary: Optional[str] = Field(
        default=None, description="Summary of changes between versions"
    )
    sections_changed: Optional[str] = Field(
        default=None, description="JSON array of changed section headings"
    )
    revision_type: Optional[str] = Field(
        default=None, description="update, annual_release, correction"
    )
    detected_by: Optional[str] = Field(
        default=None, description="sha256_match, filename_match, user"
    )


# Union types for convenience
GraphNode = Union[
    ThreadNode, MessageNode, MemoryNode, EntityNode, LabelNode, CommunityNode,
    SourceNode,
]
GraphRelationship = Union[
    ContainsRelationship,
    CompactsToRelationship,
    ExtractedFromRelationship,
    MentionsRelationship,
    RelatesToRelationship,
    HasLabelRelationship,
    BelongsToRelationship,
    SourcedFromRelationship,
    RevisedAsRelationship,
]
