"""Memory data models."""

from typing import Dict, List, Optional, Any

from pydantic import BaseModel, Field

from .graph import MemoryNode, EntityNode


class MemorySearchResult(BaseModel):
    """Result from memory search operations."""

    memory: Optional[MemoryNode] = None
    similarity_score: float = Field(
        ge=0.0, le=1.0, description="Semantic similarity score"
    )
    relevance_reason: Optional[str] = Field(
        default=None, description="Why this memory is relevant"
    )
    related_entities: List[EntityNode] = Field(default_factory=list)
    evolves_context: Optional[Dict[str, Any]] = Field(
        default=None,
        description="EVOLVES chain context: version history and relationships",
    )


class MemorySearchRequest(BaseModel):
    """Request for memory search."""

    query: str = Field(..., description="Search query")
    limit: int = Field(default=10, ge=1, le=100, description="Maximum results")
    include_entities: bool = Field(default=True, description="Include related entities")
    filter_labels: Optional[List[str]] = Field(
        default=None, description="Filter by label names"
    )
    mode: Optional[str] = Field(
        default=None,
        description="Search mode: 'deep' (default) or 'fast' (BM25+vector only)",
    )

    # === Valid Time Filters (when the event occurred) ===
    event_date_from: Optional[str] = Field(
        default=None,
        description="Filter by when the EVENT occurred (not when recorded). Format: YYYY, YYYY-MM, or YYYY-MM-DD",
        examples=["2020", "2023-06", "2024-01-15"],
    )
    event_date_to: Optional[str] = Field(
        default=None,
        description="Upper bound for event date. Format: YYYY, YYYY-MM, or YYYY-MM-DD",
        examples=["2024", "2023-12", "2024-12-31"],
    )
    temporal_context: Optional[str] = Field(
        default=None,
        description="Filter by temporal context: 'past', 'present', 'future', or 'timeless'",
        examples=["past", "present", "future", "timeless"],
    )

    # === Transaction Time Filters (when we recorded it) ===
    recorded_date_from: Optional[str] = Field(
        default=None,
        description="Filter by when the memory was RECORDED into the system. Format: YYYY-MM-DD",
        examples=["2024-11-20", "2024-11-01"],
    )
    recorded_date_to: Optional[str] = Field(
        default=None,
        description="Upper bound for recording date. Format: YYYY-MM-DD",
        examples=["2024-11-24"],
    )


class MemoryCreateRequest(BaseModel):
    """Request to create a new memory."""

    content: str = Field(..., description="Memory content", max_length=32768)
    title: Optional[str] = Field(
        default=None, description="Optional descriptive title for the memory", max_length=200
    )
    source_thread_id: Optional[str] = Field(default=None, description="Source thread ID")
    source_message_range: Optional[Dict[str, int]] = Field(
        default=None, description="Source message range {start_index, end_index}"
    )
    source: Optional[str] = Field(
        default=None, description="Source application (cursor, chatwise, manual, etc.)"
    )
    importance: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Importance score"
    )
    confidence: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Confidence score"
    )
    labels: Optional[List[str]] = Field(default=None, description="Label names to assign")
    metadata: Dict[str, Any] = Field(
        default_factory=dict, description="Additional metadata"
    )

    # === Bi-temporal fields (added 2025-11-25) ===
    # For API/UI: user provides these directly (no LLM in the loop)
    event_start: Optional[str] = Field(
        default=None,
        description="When the event occurred. Format: YYYY, YYYY-MM, or YYYY-MM-DD",
        examples=["2024", "2024-03", "2024-03-15"],
    )
    event_end: Optional[str] = Field(
        default=None,
        description="When event ended (for ranges). Format: YYYY, YYYY-MM, or YYYY-MM-DD",
        examples=["2024-06-30"],
    )
    temporal_context: Optional[str] = Field(
        default=None,
        description="Temporal context: 'past', 'present', 'future', or 'timeless'",
        examples=["past", "present", "future", "timeless"],
    )

    # === Knowledge type classification (v0.6) ===
    unit_type: Optional[str] = Field(
        default=None,
        description=(
            "Knowledge unit type: fact | preference | decision | plan | "
            "procedure | learning | context | event"
        ),
        examples=["fact", "decision", "preference", "learning"],
    )


class MemoryCreateResponse(BaseModel):
    """Response from memory creation."""

    memory: MemoryNode
    extracted_entities: List[EntityNode] = Field(default_factory=list)
    assigned_labels: List[str] = Field(default_factory=list)
    created_relationships: int = Field(
        default=0, description="Number of relationships created"
    )


class MemoryUpdateRequest(BaseModel):
    """Request to update an existing memory."""

    memory_id: str = Field(..., description="Memory ID to update")
    content: Optional[str] = Field(default=None, description="New content", max_length=32768)
    # No schema constraints - validated via model_validator to avoid client validation issues
    importance: Optional[float] = Field(default=None, description="Importance score 0.0-1.0")
    confidence: Optional[float] = Field(default=None, description="Confidence score 0.0-1.0")
    add_labels: Optional[List[str]] = Field(default=None, description="Labels to add")
    remove_labels: Optional[List[str]] = Field(default=None, description="Labels to remove")
    metadata: Optional[Dict[str, Any]] = Field(default=None, description="Metadata updates")

    def validate_numeric_ranges(self) -> None:
        """Validate numeric fields are within valid ranges."""
        if self.importance is not None and not (0.0 <= self.importance <= 1.0):
            raise ValueError("importance must be between 0.0 and 1.0")
        if self.confidence is not None and not (0.0 <= self.confidence <= 1.0):
            raise ValueError("confidence must be between 0.0 and 1.0")


class MemoryStats(BaseModel):
    """Memory statistics and insights."""

    total_memories: int
    avg_importance: float
    most_common_entities: List[Dict[str, Any]]
    recent_memories: List[MemoryNode]
    memory_by_labels: Dict[str, int]
    embedding_coverage: float = Field(
        description="Percentage of memories with embeddings"
    )


class MemoryCompactionRequest(BaseModel):
    """Request to compact thread messages into memories."""

    thread_id: str = Field(..., description="Thread to compact")
    message_range: Optional[Dict[str, int]] = Field(
        default=None, description="Specific message range to compact"
    )
    compaction_strategy: str = Field(
        default="auto", description="Compaction strategy (auto, summary, key_points)"
    )
    target_memory_count: Optional[int] = Field(
        default=None, description="Target number of memories to create"
    )
    preserve_detail: bool = Field(
        default=False, description="Whether to preserve detailed information"
    )


class MemoryCompactionResponse(BaseModel):
    """Response from memory compaction."""

    created_memories: List[MemoryNode]
    compaction_summary: str = Field(description="Summary of compaction process")
    messages_processed: int
    entities_extracted: int
    relationships_created: int
