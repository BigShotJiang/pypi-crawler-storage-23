"""Enhanced entity models for multilingual extraction and linking."""

import datetime
from enum import Enum
from typing import Any, ClassVar, Dict, List, Optional, Union
from uuid import uuid4

from pydantic import BaseModel, Field, field_validator, ValidationInfo

from .graph import BaseNode, NodeType


class EntityCategory(str, Enum):
    """High-level entity categories for organization."""

    # People and Organizations
    PERSON = "person"
    ORGANIZATION = "organization"
    GROUP = "group"

    # Places and Locations
    LOCATION = "location"
    FACILITY = "facility"

    # Things and Objects
    PRODUCT = "product"
    TECHNOLOGY = "technology"
    RESOURCE = "resource"
    ARTWORK = "artwork"

    # Concepts and Ideas
    CONCEPT = "concept"
    TOPIC = "topic"
    SKILL = "skill"
    METHODOLOGY = "methodology"

    # Events and Activities
    EVENT = "event"
    ACTIVITY = "activity"
    PROJECT = "project"

    # Information and Communication
    DOCUMENT = "document"
    MEDIA = "media"
    CONTACT = "contact"

    # Measurements and Values
    QUANTITY = "quantity"
    TIME = "time"
    MONEY = "money"

    # Legal and Regulatory
    LAW = "law"
    REGULATION = "regulation"
    STANDARD = "standard"

    # Other
    OTHER = "other"


class EntitySubtype(BaseModel):
    """Specific entity subtype within a category."""

    category: EntityCategory
    subtype: str = Field(..., description="Specific subtype name")
    description: Optional[str] = Field(default=None, description="Subtype description")

    # Common subtypes by category
    COMMON_SUBTYPES: ClassVar[Dict[EntityCategory, List[str]]] = {
        EntityCategory.PERSON: [
            "individual",
            "professional",
            "celebrity",
            "historical_figure",
            "fictional_character",
            "author",
            "scientist",
            "politician",
        ],
        EntityCategory.ORGANIZATION: [
            "company",
            "nonprofit",
            "government",
            "educational",
            "religious",
            "sports_team",
            "band",
            "startup",
            "corporation",
            "agency",
        ],
        EntityCategory.LOCATION: [
            "country",
            "city",
            "region",
            "continent",
            "landmark",
            "address",
            "venue",
            "geographical_feature",
            "building",
            "room",
        ],
        EntityCategory.TECHNOLOGY: [
            "programming_language",
            "framework",
            "library",
            "tool",
            "platform",
            "database",
            "api",
            "protocol",
            "standard",
            "algorithm",
        ],
        EntityCategory.CONCEPT: [
            "theory",
            "principle",
            "methodology",
            "best_practice",
            "pattern",
            "paradigm",
            "philosophy",
            "strategy",
            "approach",
            "technique",
        ],
        EntityCategory.EVENT: [
            "meeting",
            "conference",
            "release",
            "milestone",
            "deadline",
            "celebration",
            "disaster",
            "historical_event",
            "ceremony",
        ],
    }


class ExternalLink(BaseModel):
    """External knowledge base link for entity disambiguation."""

    source: str = Field(
        ..., description="Knowledge base name (wikidata, dbpedia, etc.)"
    )
    identifier: str = Field(..., description="External identifier")
    uri: Optional[str] = Field(default=None, description="Full URI if available")
    confidence: float = Field(default=0.5, ge=0.0, le=1.0)

    # Common knowledge bases
    COMMON_SOURCES: ClassVar[List[str]] = [
        "wikidata",
        "dbpedia",
        "freebase",
        "yago",
        "conceptnet",
        "wordnet",
        "geonames",
        "musicbrainz",
        "imdb",
        "isbn",
    ]


class EntityMention(BaseModel):
    """Information about where and how an entity was mentioned."""

    text: str = Field(..., description="Exact text mention")
    context: Optional[str] = Field(default=None, description="Surrounding context")
    position: Optional[int] = Field(default=None, description="Character position in text")
    confidence: float = Field(default=0.5, ge=0.0, le=1.0)
    source_id: Optional[str] = Field(default=None, description="Source document/message ID")
    extraction_method: str = Field(
        default="unknown", description="How entity was extracted"
    )
    language: Optional[str] = Field(default=None, description="Language of mention (ISO 639-1)")


class EnhancedEntityNode(BaseNode):
    """Enhanced entity node with linking and multilingual support."""

    node_type: NodeType = Field(default=NodeType.ENTITY, frozen=True)

    # Core entity information
    name: str = Field(..., description="Primary entity name")
    canonical_name: Optional[str] = Field(default=None, description="Canonical/normalized name")
    category: EntityCategory = Field(..., description="High-level entity category")
    subtype: Optional[str] = Field(default=None, description="Specific entity subtype")
    description: Optional[str] = Field(default=None, description="Entity description")

    # Multilingual support
    names_by_language: Dict[str, List[str]] = Field(
        default_factory=dict,
        description="Entity names in different languages {lang_code: [names]}",
    )
    primary_language: Optional[str] = Field(
        default=None, description="Primary language (ISO 639-1)"
    )

    # Entity linking and disambiguation
    aliases: List[str] = Field(default_factory=list, description="Alternative names")
    external_links: List[ExternalLink] = Field(
        default_factory=list, description="Links to external knowledge bases"
    )
    disambiguation: Optional[str] = Field(
        default=None,
        description="Disambiguation info (e.g., 'Apple (company)' vs 'Apple (fruit)')",
    )

    # Mentions and extraction
    mentions: List[EntityMention] = Field(
        default_factory=list, description="All mentions of this entity"
    )
    first_seen: datetime.datetime = Field(
        default_factory=lambda: datetime.datetime.now(datetime.UTC)
    )
    last_seen: datetime.datetime = Field(
        default_factory=lambda: datetime.datetime.now(datetime.UTC)
    )
    mention_count: int = Field(default=0, description="Total times mentioned")

    # Confidence and quality
    confidence: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Overall entity confidence"
    )
    quality_score: float = Field(
        default=0.5,
        ge=0.0,
        le=1.0,
        description="Entity quality based on mentions, links, etc.",
    )

    # Relationships and context
    related_entities: List[str] = Field(
        default_factory=list, description="IDs of related entities"
    )
    topics: List[str] = Field(
        default_factory=list, description="Associated topics/tags"
    )

    # Administrative
    created_by: Optional[str] = Field(
        default=None, description="User/system that created entity"
    )
    verified: bool = Field(
        default=False, description="Whether entity has been verified"
    )
    needs_review: bool = Field(
        default=False, description="Whether entity needs human review"
    )

    @field_validator("name")
    def validate_name(cls, v: str) -> str:
        """Validate entity name."""
        if not v or len(v.strip()) < 1:
            raise ValueError("Entity name cannot be empty")
        return v.strip()

    @field_validator("canonical_name", mode="before")
    @classmethod
    def set_canonical_name(
        cls, value: Optional[str], info: ValidationInfo
    ) -> Optional[str]:
        """Set canonical name to normalized primary name if not provided."""
        if value is None and "name" in info.data:
            return info.data["name"].strip().title()
        return value.strip() if value else None

    def add_mention(self, mention: EntityMention) -> None:
        """Add a new mention of this entity."""
        self.mentions.append(mention)
        self.mention_count = len(self.mentions)
        self.last_seen = datetime.datetime.now(datetime.UTC)

        # Update quality score based on mentions
        self._update_quality_score()

    def add_external_link(self, link: ExternalLink) -> None:
        """Add external knowledge base link."""
        # Check for duplicates
        existing = next(
            (
                l
                for l in self.external_links
                if l.source == link.source and l.identifier == link.identifier
            ),
            None,
        )

        if not existing:
            self.external_links.append(link)
            self._update_quality_score()

    def add_alias(self, alias: str, language: Optional[str] = None) -> None:
        """Add an alias for this entity."""
        alias = alias.strip()
        if alias and alias not in self.aliases:
            self.aliases.append(alias)

        # Also add to language-specific names if language provided
        if language:
            if language not in self.names_by_language:
                self.names_by_language[language] = []
            if alias not in self.names_by_language[language]:
                self.names_by_language[language].append(alias)

    def _update_quality_score(self) -> None:
        """Update quality score based on various factors."""
        score = 0.0

        # Base score
        score += 0.2

        # Mentions contribute to quality
        if self.mention_count > 0:
            score += min(0.3, self.mention_count * 0.05)

        # External links significantly boost quality
        score += len(self.external_links) * 0.15

        # Multilingual names boost quality
        score += len(self.names_by_language) * 0.1

        # Verification boosts quality
        if self.verified:
            score += 0.2

        # Description boosts quality
        if self.description:
            score += 0.1

        self.quality_score = min(1.0, score)

    def get_all_names(self) -> List[str]:
        """Get all names for this entity across all languages."""
        names = [self.name, self.canonical_name] + self.aliases

        # Add names from all languages
        for lang_names in self.names_by_language.values():
            names.extend(lang_names)

        # Remove duplicates and None values
        return list(set(filter(None, names)))

    def is_similar_to(self, other: "EnhancedEntityNode") -> float:
        """Calculate similarity to another entity (0.0 to 1.0)."""
        similarity = 0.0

        # Name similarity
        self_names = set(self.get_all_names())
        other_names = set(other.get_all_names())

        if self_names & other_names:  # Any name overlap
            similarity += 0.4

        # Category similarity
        if self.category == other.category:
            similarity += 0.3

        # External link overlap
        self_links = {(l.source, l.identifier) for l in self.external_links}
        other_links = {(l.source, l.identifier) for l in other.external_links}

        if self_links & other_links:  # Any external link overlap
            similarity += 0.3

        return min(1.0, similarity)


# Type alias for backward compatibility
EntityNode = EnhancedEntityNode
