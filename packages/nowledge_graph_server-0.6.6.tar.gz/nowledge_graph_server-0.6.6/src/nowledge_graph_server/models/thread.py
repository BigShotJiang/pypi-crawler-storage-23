"""Thread and message-related data models for MCP tools."""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from .graph import ThreadNode, MessageNode, MemoryNode


class MessageCreateRequest(BaseModel):
    """Request to create a message within a thread."""

    content: str = Field(..., description="Message content")
    role: str = Field(..., description="Message role (user, assistant, system)")
    timestamp: Optional[datetime] = Field(default=None, description="Message timestamp")
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ThreadCreateRequest(BaseModel):
    """Request to create a new thread with messages."""

    thread_id: str = Field(..., description="Human-readable thread identifier")
    title: Optional[str] = Field(default=None, description="Thread title")
    messages: List[MessageCreateRequest] = Field(..., description="Thread messages")
    participants: List[str] = Field(default_factory=list)
    source: Optional[str] = Field(default=None, description="Source system")

    # Flattened properties for performance
    project: Optional[str] = Field(default=None, description="Project identifier")
    workspace: Optional[str] = Field(default=None, description="Workspace path")
    tool_version: Optional[str] = Field(default=None, description="Tool version")
    import_date: Optional[datetime] = Field(default=None, description="Import timestamp")

    # Remaining flexible metadata
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ThreadCreateResponse(BaseModel):
    """Response from thread creation."""

    thread: ThreadNode
    messages: List[MessageNode]
    created_relationships: int = Field(default=0)
    auto_generated_summary: Optional[str] = Field(None)
    extracted_memories: List[MemoryNode] = Field(default_factory=list)
    auto_extraction_performed: bool = Field(default=False)


class ThreadSearchResult(BaseModel):
    """Result from thread search operations."""

    thread: ThreadNode
    similarity_score: float = Field(ge=0.0, le=1.0)
    match_reason: Optional[str] = Field(default=None, description="Why this thread matches")
    message_count: int
    recent_activity: datetime


class ThreadSearchRequest(BaseModel):
    """Request for thread search."""

    query: str = Field(..., description="Search query")
    limit: int = Field(default=10, ge=1, le=100)
    include_messages: bool = Field(
        default=False, description="Include message content in search"
    )
    filter_by_source: Optional[str] = Field(default=None, description="Filter by source system")
    filter_by_participants: Optional[List[str]] = Field(None)
    date_range: Optional[Dict[str, datetime]] = Field(
        default=None, description="Date range filter {start, end}"
    )


class ThreadFetchResponse(BaseModel):
    """Response for fetching a complete thread."""

    thread: ThreadNode
    messages: List[MessageNode]
    related_memories: List[MemoryNode] = Field(default_factory=list)
    entities: List[str] = Field(
        default_factory=list, description="Extracted entities from thread"
    )
    total_messages: int
    total_tokens: Optional[int] = Field(None)
    # Optional coverage details for UI (per-message distilled status)
    covered_message_ids: List[str] = Field(default_factory=list)


class ThreadListItem(BaseModel):
    """Lightweight item for thread listing without message hydration."""

    thread_id: str
    title: Optional[str] = None
    source: Optional[str] = None
    import_date: Optional[datetime] = None
    last_activity: Optional[datetime] = None
    message_count: int = 0
    participants: Optional[List[str]] = None


class MessageSearchRequest(BaseModel):
    """Request for message full-text search."""

    query: str = Field(..., description="Search query")
    limit: int = Field(default=20, ge=1, le=100)
    filter_by_role: Optional[str] = Field(default=None, description="Filter by message role")
    filter_by_thread: Optional[str] = Field(default=None, description="Filter by thread ID")
    date_range: Optional[Dict[str, datetime]] = Field(None)


class MessageSearchResult(BaseModel):
    """Result from message search."""

    message: MessageNode
    thread_id: str
    thread_title: Optional[str]
    relevance_score: float = Field(ge=0.0, le=1.0)
    context_before: Optional[str] = Field(
        default=None, description="Message before for context"
    )
    context_after: Optional[str] = Field(default=None, description="Message after for context")


class ThreadStats(BaseModel):
    """Thread statistics and insights."""

    total_threads: int
    total_messages: int
    avg_messages_per_thread: float
    most_active_participants: List[Dict[str, Any]]
    threads_by_source: Dict[str, int]
    recent_threads: List[ThreadNode]
    largest_threads: List[Dict[str, Any]]  # thread_id, message_count


class ThreadUpdateRequest(BaseModel):
    """Request to update thread metadata."""

    thread_id: str = Field(..., description="Thread ID to update")
    title: Optional[str] = Field(None)
    summary: Optional[str] = Field(None)
    add_participants: Optional[List[str]] = Field(None)
    remove_participants: Optional[List[str]] = Field(None)
    metadata: Optional[Dict[str, Any]] = Field(None)


class ConversationImportRequest(BaseModel):
    """Request to import a conversation from external sources."""

    source_type: str = Field(
        ..., description="Source type (cursor, claude, chatgpt, etc.)"
    )
    source_data: Dict[str, Any] = Field(..., description="Raw conversation data")
    thread_id_override: Optional[str] = Field(
        default=None, description="Override auto-generated thread ID"
    )
    auto_compact: bool = Field(
        default=False, description="Auto-create memories during import"
    )
    preserve_timestamps: bool = Field(default=True)


class ConversationImportResponse(BaseModel):
    """Response from conversation import."""

    thread: ThreadNode
    messages: List[MessageNode]
    import_summary: str
    warnings: List[str] = Field(default_factory=list)
    created_memories: List[MemoryNode] = Field(default_factory=list)
    skipped_messages: int = Field(default=0)
