"""Command Line Interface for Nowledge Graph Server."""

import asyncio
import logging
import click
import shutil
from pathlib import Path

from .config import Settings, get_settings
from .database.kuzu_client import KuzuClient
from .migrations.migration_manager import MigrationManager, MigrationError
from .migrations.templates import create_migration_template
from .migrations.env import migration_env
from nowledge_graph_server.utils.debug_tools import DebugTools

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


@click.group()
@click.option("--config", type=click.Path(exists=True), help="Configuration file path")
@click.pass_context
def cli(ctx, config):
    """Nowledge Graph server command-line interface."""
    ctx.ensure_object(dict)

    # Load configuration
    if config:
        # TODO: Load from config file - for now use default
        # Settings class doesn't have from_file method yet
        click.echo(
            f"Warning: Config file support not implemented yet. Using default settings."
        )
        ctx.obj["config"] = get_settings()
    else:
        # Use default configuration
        ctx.obj["config"] = get_settings()


@cli.command()
@click.option("--host", default="0.0.0.0", help="Host to bind to")
@click.option("--port", default=14242, help="Port to bind to (default: 14242)")
@click.option("--reload", is_flag=True, help="Enable auto-reload for development")
@click.pass_context
def serve(ctx, host: str, port: int, reload: bool):
    """Start the FastAPI server."""
    import uvicorn

    logger.info(f"Starting server on {host}:{port}")
    uvicorn.run(
        "nowledge_graph_server.fastapi_server:app", host=host, port=port, reload=reload
    )


@cli.group()
@click.pass_context
def db(ctx):
    """Database management commands."""
    pass


@db.command()
@click.pass_context
def init(ctx):
    """Initialize the database schema."""
    config = ctx.obj["config"]

    async def _init():
        client = KuzuClient(config.database_path)
        await client.initialize()
        logger.info("Database initialized successfully")

    asyncio.run(_init())


@db.command()
@click.option(
    "--reset", is_flag=True, help="Reset the database (WARNING: deletes all data)"
)
@click.pass_context
def reset(ctx, reset: bool):
    """Reset the database."""
    if not reset:
        click.echo("Use --reset flag to confirm database reset")
        return

    config = ctx.obj["config"]

    # Delete database directory
    db_path = Path(config.database_path)
    if db_path.exists():
        shutil.rmtree(db_path)
        logger.info(f"Database directory {db_path} deleted")

    # Reinitialize
    async def _reset():
        client = KuzuClient(config.database_path)
        await client.initialize()
        logger.info("Database reset and reinitialized")

    asyncio.run(_reset())


# ============================================
# FILE-BASED MIGRATION COMMANDS
# ============================================


@db.command()
@click.argument("message")
@click.option(
    "--template",
    default="default",
    type=click.Choice(["default", "table_creation", "data_migration"]),
    help="Migration template type",
)
@click.option(
    "--revision-id", help="Custom revision ID (auto-generated if not provided)"
)
@click.pass_context
def revision(ctx, message: str, template: str, revision_id: str):
    """Generate a new migration file."""
    config = ctx.obj["config"]

    # Set up migration environment
    migration_env.db_path = Path(config.database_path)

    try:
        file_path = create_migration_template(
            description=message,
            migration_dir=migration_env.migration_dir,
            revision_id=revision_id,
            template_type=template,
        )

        click.echo(f"✅ Generated migration file: {file_path}")
        click.echo("\n📝 Next steps:")
        click.echo(f"  1. Edit the migration file: {file_path}")
        click.echo("  2. Implement the upgrade() and downgrade() functions")
        click.echo(
            "  3. Apply the migration: python -m nowledge_graph_server.cli db upgrade"
        )

    except Exception as e:
        click.echo(f"❌ Failed to generate migration: {e}", err=True)
        raise click.ClickException(str(e))


@db.command()
@click.option(
    "--dry-run", is_flag=True, help="Show what would be migrated without applying"
)
@click.option("--target", help="Target revision to migrate to")
@click.pass_context
def upgrade(ctx, dry_run: bool, target: str):
    """Apply pending migrations."""
    config = ctx.obj["config"]

    async def _upgrade():
        # Initialize migration manager
        manager = MigrationManager(Path(config.database_path))
        await manager.initialize()

        if dry_run:
            status = await manager.get_migration_status()
            pending = [m for m in status["migrations"] if not m["applied"]]

            if not pending:
                click.echo("No pending migrations")
                return

            click.echo("Pending migrations:")
            for migration in pending:
                click.echo(f"  - {migration['revision']}: {migration['description']}")
            return

        # Apply migrations
        try:
            result = await manager.apply_migrations(target_revision=target)

            if result["applied_count"] == 0:
                click.echo("No migrations to apply")
            else:
                click.echo(f"Applied {result['applied_count']} migrations:")
                for migration_result in result["migrations"]:
                    status = migration_result["status"]
                    revision = migration_result["revision"]
                    description = migration_result["description"]

                    icon = "✅" if status == "applied" else "⏭️"
                    click.echo(f"  {icon} {revision}: {description}")

        except MigrationError as e:
            click.echo(f"Migration failed: {e}", err=True)
            raise click.ClickException(str(e))
        finally:
            await manager.close()

    asyncio.run(_upgrade())


@db.command()
@click.argument("revision")
@click.option("--confirm", is_flag=True, help="Confirm rollback")
@click.pass_context
def downgrade(ctx, revision: str, confirm: bool):
    """Rollback a specific migration."""
    if not confirm:
        click.echo("Use --confirm flag to confirm rollback")
        return

    config = ctx.obj["config"]

    async def _downgrade():
        # Initialize migration manager
        manager = MigrationManager(Path(config.database_path))
        await manager.initialize()

        try:
            result = await manager.rollback_migration(revision, confirm=True)

            if result["status"] == "rolled_back":
                click.echo(f"✅ Migration {revision} rolled back successfully")
            else:
                click.echo(
                    f"⏭️ Migration {revision} rollback skipped: {result.get('reason', 'unknown')}"
                )

        except MigrationError as e:
            click.echo(f"Rollback failed: {e}", err=True)
            raise click.ClickException(str(e))
        finally:
            await manager.close()

    asyncio.run(_downgrade())


@db.command("migration-status")
@click.pass_context
def migration_status(ctx):
    """Show detailed migration status."""
    config = ctx.obj["config"]

    async def _status():
        # Initialize migration manager
        manager = MigrationManager(Path(config.database_path))
        await manager.initialize()

        try:
            status = await manager.get_migration_status()

            click.echo("\nMigration Status:")
            click.echo("=" * 50)

            for migration in status["migrations"]:
                status_icon = "✅" if migration["applied"] else "⏳"
                click.echo(
                    f"{status_icon} {migration['revision']}: {migration['description']}"
                )
                if not migration["applied"]:
                    click.echo(f"    File: {migration['file_path']}")

            click.echo(f"\nSummary:")
            click.echo(f"  Total migrations: {status['total_migrations']}")
            click.echo(f"  Applied: {status['applied_count']}")
            click.echo(f"  Pending: {status['pending_count']}")

        except Exception as e:
            click.echo(f"❌ Failed to get migration status: {e}", err=True)
            raise click.ClickException(str(e))
        finally:
            await manager.close()

    asyncio.run(_status())


@cli.command()
@click.pass_context
def test_connection(ctx):
    """Test database connection."""
    config = ctx.obj["config"]

    async def _test():
        try:
            client = KuzuClient(config.database_path)
            await client.initialize()

            # Test query
            result = await client.test_connection()
            click.echo(f"✅ Database connection successful: {result}")

        except Exception as e:
            click.echo(f"❌ Database connection failed: {e}", err=True)
            raise click.ClickException(str(e))

    asyncio.run(_test())


@cli.command()
@click.option(
    "--confirm", is_flag=True, help="Actually perform the cleanup (dry run by default)"
)
@click.pass_context
def debug_orphans(ctx, confirm: bool):
    """Find and optionally clean up orphaned entities."""
    from nowledge_graph_server.database.kuzu_client import KuzuClient

    settings = ctx.obj["config"]

    async def _debug_orphans():
        client = KuzuClient(settings.database_path)
        debug_tools = DebugTools(client)

        try:
            await client.initialize()

            # Find orphaned entities
            orphaned_entities = await debug_tools.find_all_orphaned_entities()

            if not orphaned_entities:
                click.echo("✅ No orphaned entities found!")
                return

            click.echo(f"Found {len(orphaned_entities)} orphaned entities:")
            for entity in orphaned_entities:
                click.echo(
                    f"  - {entity['entity_name']} ({entity['entity_type']}) - ID: {entity['entity_id']}"
                )

            if confirm:
                deleted_count = await debug_tools.clean_orphaned_entities(confirm=True)
                click.echo(f"✅ Deleted {deleted_count} orphaned entities")
            else:
                click.echo("\n💡 Use --confirm to actually delete these entities")

        except Exception as e:
            click.echo(f"❌ Error: {e}")
            raise

        finally:
            await client.close()

    asyncio.run(_debug_orphans())


@cli.command()
@click.argument("entity_id")
@click.pass_context
def debug_entity(ctx, entity_id: str):
    """Debug a specific entity to see its relationships."""
    from nowledge_graph_server.database.kuzu_client import KuzuClient

    settings = ctx.obj["config"]

    async def _debug_entity():
        client = KuzuClient(settings.database_path)
        debug_tools = DebugTools(client)

        try:
            await client.initialize()

            # Get entity relationships
            relationships = await debug_tools.debug_entity_relationships(entity_id)

            if relationships.get("error"):
                click.echo(f"❌ Error: {relationships['error']}")
                return

            click.echo(f"Entity ID: {entity_id}")
            click.echo(f"Total relationships: {relationships['total_relationships']}")
            click.echo()

            if relationships["mentions"]:
                click.echo("MENTIONS relationships:")
                for mention in relationships["mentions"]:
                    click.echo(
                        f"  - Memory {mention['memory_id']} (confidence: {mention['confidence']})"
                    )

            if relationships["relates_to"]:
                click.echo("RELATES_TO relationships:")
                for relation in relationships["relates_to"]:
                    click.echo(
                        f"  - {relation['related_entity_id']} ({relation['relation_type']}, confidence: {relation['confidence']})"
                    )

            if relationships["has_label"]:
                click.echo("HAS_LABEL relationships:")
                for label in relationships["has_label"]:
                    click.echo(
                        f"  - Label: {label['label_name']} ({label['label_id']})"
                    )

            if relationships["belongs_to"]:
                click.echo("BELONGS_TO relationships:")
                for community in relationships["belongs_to"]:
                    click.echo(
                        f"  - Community: {community['community_name']} ({community['community_id']}, strength: {community['strength']})"
                    )

            if relationships["total_relationships"] == 0:
                click.echo("⚠️  This entity appears to be orphaned (no relationships)")

        except Exception as e:
            click.echo(f"❌ Error: {e}")
            raise

        finally:
            await client.close()

    asyncio.run(_debug_entity())


@cli.command()
@click.option(
    "--confirm", is_flag=True, help="Actually clear the states (dry run by default)"
)
@click.pass_context
def debug_stale_threads(ctx, confirm: bool):
    """Find and clear threads with stale distillation states."""
    from nowledge_graph_server.database.kuzu_client import KuzuClient

    settings = ctx.obj["config"]

    async def _debug_stale_threads():
        client = KuzuClient(settings.database_path)
        debug_tools = DebugTools(client)

        try:
            await client.initialize()

            # Find stale threads
            stale_threads = (
                await debug_tools.find_threads_with_stale_distillation_state()
            )

            if not stale_threads:
                click.echo("✅ No threads with stale distillation state found!")
                return

            click.echo(
                f"Found {len(stale_threads)} threads with stale distillation state:"
            )
            for thread in stale_threads:
                click.echo(f"  - {thread['title']} (ID: {thread['thread_id']})")

            if confirm:
                cleared_count = await debug_tools.clear_stale_distillation_states(
                    confirm=True
                )
                click.echo(
                    f"✅ Cleared distillation state from {cleared_count} threads"
                )
            else:
                click.echo("\n💡 Use --confirm to actually clear these states")

        except Exception as e:
            click.echo(f"❌ Error: {e}")
            raise

        finally:
            await client.close()

    asyncio.run(_debug_stale_threads())


@cli.command()
@click.pass_context
def debug_stats(ctx):
    """Show comprehensive database statistics."""
    from nowledge_graph_server.database.kuzu_client import KuzuClient

    settings = ctx.obj["config"]

    async def _debug_stats():
        client = KuzuClient(settings.database_path)
        debug_tools = DebugTools(client)

        try:
            await client.initialize()

            stats = await debug_tools.get_database_stats()

            click.echo("📊 Database Statistics:")
            click.echo(f"  Threads: {stats.get('thread_count', 0)}")
            click.echo(f"  Messages: {stats.get('message_count', 0)}")
            click.echo(f"  Memories: {stats.get('memory_count', 0)}")
            click.echo(f"  Entities: {stats.get('entity_count', 0)}")
            click.echo(f"  Labels: {stats.get('label_count', 0)}")
            click.echo(f"  Total Relationships: {stats.get('total_relationships', 0)}")
            click.echo(
                f"  Memories with Embeddings: {stats.get('memories_with_embeddings', 0)}"
            )
            click.echo(
                f"  Orphaned Entities: {stats.get('orphaned_entities_count', 0)}"
            )

        except Exception as e:
            click.echo(f"❌ Error: {e}")
            raise

        finally:
            await client.close()

    asyncio.run(_debug_stats())


@cli.command()
@click.option("--memory-id", help="Test cascade deletion for specific memory ID")
@click.option("--show-stats", is_flag=True, help="Show database statistics")
@click.pass_context
def debug_cascade(ctx, memory_id: str, show_stats: bool):
    """Debug memory cascade deletion and orphaned entities."""
    from nowledge_graph_server.database.kuzu_client import KuzuClient
    from nowledge_graph_server.utils.debug_tools import DebugTools

    settings = ctx.obj["config"]

    async def _debug_cascade():
        client = KuzuClient(settings.database_path)
        debug_tools = DebugTools(client)

        try:
            await client.initialize()

            if show_stats:
                click.echo("📊 Database Statistics:")
                stats = await debug_tools.get_database_stats()
                for key, value in stats.items():
                    click.echo(f"  {key}: {value}")

            if memory_id:
                click.echo(f"🔍 Testing cascade deletion for memory: {memory_id}")

                # Find orphaned entities before deletion
                orphaned_entities = await client.memory_repo.find_orphaned_entities_after_memory_deletion(
                    memory_id
                )
                click.echo(
                    f"Found {len(orphaned_entities)} entities that would be orphaned:"
                )
                for entity_id in orphaned_entities:
                    click.echo(f"  - {entity_id}")

                # Show relationships that would be deleted
                deleted_rels = (
                    await client.memory_repo.delete_relationships_from_memory(memory_id)
                )
                click.echo(f"Found {deleted_rels} relationships to delete from memory")

                # Ask for confirmation before actual deletion
                if click.confirm("🗑️  Proceed with actual cascade deletion?"):
                    result = await client.memory_repo.delete_memory_with_cascade(
                        memory_id
                    )
                    click.echo(f"Deletion result: {result}")
                else:
                    click.echo("Deletion cancelled")
            else:
                # Find all orphaned entities
                orphaned_entities = await debug_tools.find_all_orphaned_entities()

                if not orphaned_entities:
                    click.echo("✅ No orphaned entities found!")
                else:
                    click.echo(f"Found {len(orphaned_entities)} orphaned entities:")
                    for entity in orphaned_entities:
                        click.echo(
                            f"  - {entity['entity_name']} ({entity['entity_type']}) - ID: {entity['entity_id']}"
                        )

                    if click.confirm("🧹 Clean up these orphaned entities?"):
                        deleted_count = await debug_tools.clean_orphaned_entities(
                            confirm=True
                        )
                        click.echo(f"✅ Deleted {deleted_count} orphaned entities")

        except Exception as e:
            click.echo(f"❌ Error: {e}")
            raise

        finally:
            await client.close()

    asyncio.run(_debug_cascade())


if __name__ == "__main__":
    cli()
