"""Context injectors — compose pre-computed context into task prompts.

Extracted from manager.py to keep it under 1000 lines (PyArmor limit).

These functions take explicit dependencies (db, events_dir) instead of self,
then delegate to context_helpers.py for the actual data queries.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog

from .context_helpers import (
    build_activity_digest,
    build_compaction_context,
    build_crystallization_context,
    build_insight_context,
    build_resolution_context,
    format_yesterday_wm,
    gather_db_stats,
    gather_graph_totals,
    get_unresolved_flags,
)

logger = structlog.get_logger(__name__)

# Safety cap: ~25K tokens.  Prevents initial prompt from blowing up
# the model's context window before the agent even starts tool calls.
_MAX_CONTEXT_CHARS = 100_000


def _trim_sections(sections: list[str], max_chars: int = _MAX_CONTEXT_CHARS) -> list[str]:
    """Progressively trim sections to fit within *max_chars*.

    Trimming priority (lowest-value first):
      1. Drop resolution patterns entirely
      2. Proportionally truncate remaining sections
    """
    total = sum(len(s) for s in sections)
    if total <= max_chars:
        return sections

    # Pass 1 — drop resolution patterns (lowest value for budget trimming).
    # context_helpers.py generates: "## User Flag Resolution Patterns (last 30 days)"
    _RESOLUTION_MARKER = "Resolution Patterns"
    trimmed = [s for s in sections if _RESOLUTION_MARKER not in s.split("\n", 1)[0]]
    total = sum(len(s) for s in trimmed)
    if total <= max_chars:
        logger.info(
            "[CONTEXT TRIM] Dropped resolution patterns to fit budget",
            chars_after=total,
        )
        return trimmed

    # Pass 2 — proportionally truncate each remaining section
    ratio = max_chars / total
    result: list[str] = []
    for s in trimmed:
        allowed = int(len(s) * ratio)
        if len(s) > allowed:
            s = s[:allowed] + "\n\n[... truncated to fit context budget ...]"
        result.append(s)
    logger.warning(
        "[CONTEXT TRIM] Proportionally truncated sections",
        ratio=f"{ratio:.1%}",
        chars_before=total,
        chars_after=sum(len(s) for s in result),
    )
    return result


# ------------------------------------------------------------------
# Context injectors (one per task type)
# ------------------------------------------------------------------


async def inject_briefing_context(
    db: Any, events_dir: Optional[Path], prompt: str
) -> str:
    """Build rich context for daily briefing tasks.

    Pre-computes an activity digest and structured yesterday WM so the
    agent starts with full situational awareness instead of having to
    discover it through 15+ tool calls.
    """
    logger.info("[BRIEFING CONTEXT] Starting context injection for daily briefing")
    sections: List[str] = []
    conn = db.conn if db else None

    # 1. Activity digest -- recent memories, EVOLVES, crystals, flags
    try:
        digest = await build_activity_digest(conn, hours=48)
        if digest:
            sections.append(digest)
            logger.info("[BRIEFING CONTEXT] Activity digest injected", length=len(digest))
        else:
            logger.warning(
                "[BRIEFING CONTEXT] Activity digest returned None (db=%s)",
                db is not None,
            )
    except Exception as e:
        logger.warning("[BRIEFING CONTEXT] Activity digest FAILED", error=str(e))

    # 2. Graph totals
    try:
        totals = await gather_graph_totals(conn)
        if totals:
            sections.append(totals)
            logger.info("[BRIEFING CONTEXT] Graph totals injected")
        else:
            logger.warning("[BRIEFING CONTEXT] Graph totals returned None")
    except Exception as e:
        logger.warning("[BRIEFING CONTEXT] Graph totals FAILED", error=str(e))

    # 3. Yesterday's Working Memory -- structured with continuity guidance
    try:
        from .knowledge_tools import rotate_working_memory
        from .knowledge_tools.working_memory import _parse_working_memory

        yesterday_wm = rotate_working_memory()
        if yesterday_wm:
            parsed = _parse_working_memory(yesterday_wm)
            yesterday_section = format_yesterday_wm(yesterday_wm, parsed)
            sections.append(yesterday_section)
            logger.info(
                "[BRIEFING CONTEXT] Yesterday WM injected",
                focus_areas=len(parsed.get("focus_areas", [])),
                flags=len(parsed.get("flags", [])),
            )
        else:
            logger.info(
                "[BRIEFING CONTEXT] No yesterday WM to inject (file not found or empty)"
            )
    except Exception as e:
        logger.warning(
            "[BRIEFING CONTEXT] Working Memory rotation/injection failed", error=str(e)
        )

    # 4. Resolution patterns -- how user tends to act on flags (feedback loop)
    try:
        resolution_ctx = build_resolution_context(events_dir)
        if resolution_ctx:
            sections.append(resolution_ctx)
            logger.info("[BRIEFING CONTEXT] Resolution patterns injected")
    except Exception as e:
        logger.warning("[BRIEFING CONTEXT] Resolution context failed", error=str(e))

    sections = _trim_sections(sections)

    total_ctx = sum(len(s) for s in sections)
    logger.info(
        "[BRIEFING CONTEXT] Injection complete",
        sections=len(sections),
        total_chars=total_ctx,
    )

    if sections:
        return "\n\n".join(sections) + "\n\n" + prompt
    return prompt


async def inject_crystallization_context(
    db: Any, events_dir: Optional[Path], prompt: str
) -> str:
    """Build rich context for crystallization review tasks.

    Pre-computes uncrystallized clusters, stale crystals, recent activity,
    and community structure so the agent starts with full awareness instead
    of having to discover it through 15+ tool calls.
    """
    logger.info("[CRYSTAL CONTEXT] Starting context injection")
    sections: List[str] = []
    conn = db.conn if db else None

    # 1. Crystallization-specific context (clusters, stale crystals, etc.)
    try:
        crystal_ctx = await build_crystallization_context(conn, hours=168)
        if crystal_ctx:
            sections.append(crystal_ctx)
            logger.info(
                "[CRYSTAL CONTEXT] Crystallization context injected",
                length=len(crystal_ctx),
            )
        else:
            logger.warning("[CRYSTAL CONTEXT] Crystallization context returned None")
    except Exception as e:
        logger.warning("[CRYSTAL CONTEXT] Crystallization context FAILED", error=str(e))

    # 2. Graph totals (reuse existing)
    try:
        totals = await gather_graph_totals(conn)
        if totals:
            sections.append(totals)
            logger.info("[CRYSTAL CONTEXT] Graph totals injected")
    except Exception as e:
        logger.warning("[CRYSTAL CONTEXT] Graph totals FAILED", error=str(e))

    # 3. Resolution patterns (how user acts on flags)
    try:
        resolution_ctx = build_resolution_context(events_dir)
        if resolution_ctx:
            sections.append(resolution_ctx)
            logger.info("[CRYSTAL CONTEXT] Resolution patterns injected")
    except Exception as e:
        logger.warning("[CRYSTAL CONTEXT] Resolution context failed", error=str(e))

    sections = _trim_sections(sections)

    total_ctx = sum(len(s) for s in sections)
    logger.info(
        "[CRYSTAL CONTEXT] Injection complete",
        sections=len(sections),
        total_chars=total_ctx,
    )

    if sections:
        return "\n\n".join(sections) + "\n\n" + prompt
    return prompt


async def inject_insight_context(
    db: Any, events_dir: Optional[Path], prompt: str
) -> str:
    """Build rich context for insight detection tasks.

    Pre-computes activity digest, existing insights (dedup), challenge edges,
    decision memories, community structure, and source coverage so the agent
    starts with full awareness.
    """
    logger.info("[INSIGHT CONTEXT] Starting context injection")
    sections: List[str] = []
    conn = db.conn if db else None

    # 1. Insight-specific context (all 7 sections)
    try:
        insight_ctx = await build_insight_context(conn, events_dir, hours=168)
        if insight_ctx:
            sections.append(insight_ctx)
            logger.info(
                "[INSIGHT CONTEXT] Insight context injected", length=len(insight_ctx)
            )
        else:
            logger.warning("[INSIGHT CONTEXT] Insight context returned None")
    except Exception as e:
        logger.warning("[INSIGHT CONTEXT] Insight context FAILED", error=str(e))

    # 2. Graph totals (reuse existing)
    try:
        totals = await gather_graph_totals(conn)
        if totals:
            sections.append(totals)
            logger.info("[INSIGHT CONTEXT] Graph totals injected")
    except Exception as e:
        logger.warning("[INSIGHT CONTEXT] Graph totals FAILED", error=str(e))

    # 3. Resolution patterns
    try:
        resolution_ctx = build_resolution_context(events_dir)
        if resolution_ctx:
            sections.append(resolution_ctx)
            logger.info("[INSIGHT CONTEXT] Resolution patterns injected")
    except Exception as e:
        logger.warning("[INSIGHT CONTEXT] Resolution context failed", error=str(e))

    sections = _trim_sections(sections)

    total_ctx = sum(len(s) for s in sections)
    logger.info(
        "[INSIGHT CONTEXT] Injection complete",
        sections=len(sections),
        total_chars=total_ctx,
    )

    if sections:
        return "\n\n".join(sections) + "\n\n" + prompt
    return prompt


async def inject_compaction_context(
    db: Any, events_dir: Optional[Path], prompt: str
) -> str:
    """Build context for memory compaction tasks.

    Pre-computes low-decay memory clusters so the agent can focus on
    evaluating and merging rather than discovering candidates.
    """
    logger.info("[COMPACTION CONTEXT] Starting context injection")
    sections: List[str] = []
    conn = db.conn if db else None

    # 1. Compaction candidates (low-decay memory clusters)
    try:
        compaction_ctx = await build_compaction_context(conn, limit=30)
        if compaction_ctx:
            sections.append(compaction_ctx)
            logger.info(
                "[COMPACTION CONTEXT] Candidates injected",
                length=len(compaction_ctx),
            )
        else:
            logger.info("[COMPACTION CONTEXT] No candidates found")
    except Exception as e:
        logger.warning("[COMPACTION CONTEXT] Candidate query FAILED", error=str(e))

    # 2. Graph totals
    try:
        totals = await gather_graph_totals(conn)
        if totals:
            sections.append(totals)
    except Exception as e:
        logger.warning("[COMPACTION CONTEXT] Graph totals FAILED", error=str(e))

    sections = _trim_sections(sections)

    total_ctx = sum(len(s) for s in sections)
    logger.info(
        "[COMPACTION CONTEXT] Injection complete",
        sections=len(sections),
        total_chars=total_ctx,
    )

    if sections:
        return "\n\n".join(sections) + "\n\n" + prompt
    return prompt
