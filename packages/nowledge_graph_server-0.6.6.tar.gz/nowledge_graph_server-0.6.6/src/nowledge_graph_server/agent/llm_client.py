"""LLM client for the Knowledge Agent.

Uses litellm with the AI-Now purpose LLM configuration.  This is another
remote-LLM consumer alongside the existing litellm provider, AI-Now
(kimi-cli), and the browser extension.
"""

from __future__ import annotations

import asyncio
import json
import os
import traceback
from typing import Any, Dict, List, Optional

import structlog

from nowledge_graph_server.services.remote_llm_config import (
    RemoteLLMConfigManager,
    get_config_manager,
)
from nowledge_graph_server.services.litellm.openai_compatible_client import (
    build_openai_compatible_client,
)

logger = structlog.get_logger(__name__)

# Try to import OpenAI client for openai_compatible endpoints
try:
    from openai import OpenAI as _OpenAIClient
except ImportError:
    _OpenAIClient = None  # type: ignore[misc, assignment]


class AgentLLMClient:
    """Thin wrapper around litellm.acompletion for the Knowledge Agent.

    Reads provider / model from the *ai_now* purpose selection so that
    the agent shares the same LLM the user configured for AI-Now.
    """

    def __init__(self) -> None:
        self._config_manager: Optional[RemoteLLMConfigManager] = None

    # ------------------------------------------------------------------
    # Configuration helpers
    # ------------------------------------------------------------------

    def _get_config_manager(self) -> RemoteLLMConfigManager:
        if self._config_manager is None:
            self._config_manager = get_config_manager()
        return self._config_manager

    def _get_litellm_params_for_ai_now(self) -> tuple:
        """Build litellm.acompletion kwargs from the AI-Now purpose config.

        Mirrors how ``LiteLLMProvider.generate_response`` resolves the
        active provider, but uses ``get_effective_purpose("ai_now")``
        instead of the default purpose.
        """
        cm = self._get_config_manager()
        config = cm.get_config()

        if not config.enabled:
            logger.debug(
                "LLM availability check: enabled=False",
                config_enabled=config.enabled,
                config_provider=config.provider,
            )
            raise RuntimeError(
                "Remote LLM is not enabled. "
                "Configure a provider in Settings > Remote LLM."
            )

        # Resolve the ai_now purpose (falls back to default if unset)
        effective = cm.get_effective_purpose("ai_now")
        provider_id = effective.get("provider") or config.provider
        model_name = effective.get("model") or config.model

        if not provider_id or not model_name:
            logger.debug(
                "LLM availability check: missing provider/model",
                effective_purpose=effective,
                provider_id=provider_id,
                model_name=model_name,
                config_provider=config.provider,
                config_model=config.model,
            )
            raise RuntimeError(
                "No LLM provider/model configured for AI-Now purpose. "
                "Set one in Settings > Remote LLM > Purpose."
            )

        # Get the provider config for credentials
        all_providers = cm.get_all_provider_configs()
        provider_cfg = all_providers.get(provider_id)
        if provider_cfg is None:
            logger.debug(
                "LLM availability check: provider config not found",
                provider_id=provider_id,
                available_providers=list(all_providers.keys()),
            )
            raise RuntimeError(f"Provider config not found for: {provider_id}")

        provider_type = (provider_cfg.provider_type or provider_id).strip()

        # Build the model string with proper prefix for litellm
        # litellm requires provider prefix to know which API protocol to use
        # Note: openai_compatible uses OpenAI client directly (not litellm), so no prefix needed
        if provider_type == "openai_compatible" or provider_type.startswith("openai_compatible:"):
            # OpenAI-compatible endpoints use OpenAI client directly - no prefix needed
            # The model name is passed as-is to the custom endpoint
            normalized_model = model_name
        elif provider_type and not model_name.startswith(provider_type + "/"):
            if provider_type in (
                "openrouter", "anthropic", "openai", "xai",
                "gemini", "deepseek", "minimax", "zai", "moonshot",
                "github_copilot", "openai_codex",
            ):
                normalized_model = f"{provider_type}/{model_name}"
            elif provider_type == "ollama":
                # Ollama has its own prefix
                normalized_model = f"ollama/{model_name}"
            else:
                normalized_model = model_name
        else:
            normalized_model = model_name

        params: Dict[str, Any] = {
            "model": normalized_model,
            "max_tokens": provider_cfg.max_tokens or 8192,
        }

        # API base (skip for providers that resolve it themselves)
        if provider_cfg.api_base and provider_type not in ("github_copilot", "openai_codex"):
            params["api_base"] = provider_cfg.api_base

        if provider_cfg.api_version:
            params["api_version"] = provider_cfg.api_version

        return params, provider_cfg, provider_type  # type: ignore[return-value]

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def is_available(self) -> bool:
        """Check whether a usable LLM is configured."""
        try:
            self._get_litellm_params_for_ai_now()
            return True
        except Exception as e:
            # Log the reason so users can diagnose why Feed Agent won't start
            logger.warning(
                "LLM not available for Feed Agent",
                reason=str(e),
            )
            return False

    def get_diagnostic_info(self) -> Dict[str, Any]:
        """Get diagnostic info about LLM configuration for debugging.

        Returns a dict with config state that helps users understand
        why is_available() might return False.
        """
        try:
            cm = self._get_config_manager()
            config = cm.get_config()
            effective = cm.get_effective_purpose("ai_now")
            all_providers = cm.get_all_provider_configs()

            return {
                "enabled": config.enabled,
                "config_provider": config.provider,
                "config_model": config.model or "(not set)",
                "ai_now_purpose": {
                    "provider": effective.get("provider") or "(not set)",
                    "model": effective.get("model") or "(not set)",
                },
                "configured_providers": list(all_providers.keys()),
            }
        except Exception as e:
            return {"error": str(e)}

    async def chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        temperature: float = 0.3,
    ) -> Dict[str, Any]:
        """Send a chat completion request and return the parsed response.

        Returns a dict with keys:
        - ``content``: the assistant's text reply (may be empty if tool calls)
        - ``tool_calls``: list of tool call dicts (may be empty)
        - ``usage``: token usage dict
        """
        import litellm
        from nowledge_graph_server.services.litellm.constants import ALL_PROVIDER_ENV_KEYS
        from nowledge_graph_server.services.litellm.env import (
            _set_provider_env,
            setup_github_copilot_env,
            setup_openai_codex_env,
            check_copilot_authenticated,
            check_codex_authenticated,
            get_codex_access_token,
            get_copilot_ide_headers,
            get_codex_api_headers,
        )

        params, provider_cfg, provider_type = self._get_litellm_params_for_ai_now()

        # Set up provider-specific environment
        api_key = provider_cfg.api_key
        old_env: Dict[str, Optional[str]] = {}
        extra_headers: Optional[Dict[str, Any]] = None
        model_override: Optional[str] = None

        try:
            # Clear all provider env keys to avoid cross-provider leakage
            for k in ALL_PROVIDER_ENV_KEYS:
                old_env[k] = os.environ.get(k)
                os.environ.pop(k, None)

            if provider_type == "github_copilot":
                cm = self._get_config_manager()
                token_dir = setup_github_copilot_env(cm.config_path.parent)
                if not token_dir or not check_copilot_authenticated(token_dir):
                    raise RuntimeError("GitHub Copilot not authenticated")
                # LiteLLM handles copilot auth via env vars set by setup_github_copilot_env
                extra_headers = get_copilot_ide_headers()
            elif provider_type == "openai_codex":
                cm = self._get_config_manager()
                token_dir = setup_openai_codex_env(cm.config_path.parent)
                if not token_dir or not check_codex_authenticated(token_dir):
                    raise RuntimeError("OpenAI Codex not authenticated")
                api_key = get_codex_access_token(token_dir)
                if not api_key:
                    raise RuntimeError("OpenAI Codex access token expired or invalid")

                # Configure LiteLLM's native chatgpt provider
                os.environ["CHATGPT_TOKEN_DIR"] = token_dir
                os.environ["CHATGPT_AUTH_FILE"] = "auth.json"
                try:
                    from nowledge_graph_server.services.litellm.env import (
                        ensure_chatgpt_auth_file,
                    )

                    ensure_chatgpt_auth_file(token_dir)
                except Exception:
                    pass
                os.environ["OPENAI_API_KEY"] = api_key
                extra_headers = get_codex_api_headers()

                # Transform model prefix: openai_codex/X -> chatgpt/X
                model_name = str(params.get("model") or "")
                if model_name.startswith("openai_codex/"):
                    model_override = f"chatgpt/{model_name[len('openai_codex/'):]}"
                elif model_name and not model_name.startswith("chatgpt/"):
                    model_override = f"chatgpt/{model_name}"
            elif provider_type == "openai_compatible" or provider_type.startswith("openai_compatible:"):
                # OpenAI-compatible endpoints use OpenAI client directly - no env setup needed
                pass
            else:
                # Standard providers: set env via shared helper
                _set_provider_env(
                    provider_type,
                    api_key,
                    provider_cfg.api_base,
                    provider_cfg.api_version,
                )

            # Build completion kwargs
            kwargs: Dict[str, Any] = {
                **params,
                "messages": messages,
                "temperature": temperature,
            }
            if model_override:
                kwargs["model"] = model_override
            if extra_headers:
                kwargs["extra_headers"] = extra_headers
            if tools:
                kwargs["tools"] = tools
                kwargs["tool_choice"] = "auto"

            logger.debug(
                "Agent LLM call",
                model=params.get("model"),
                msg_count=len(messages),
                has_tools=bool(tools),
                provider_type=provider_type,
            )

            # Special handling: openai_compatible uses OpenAI client directly
            # This matches the pattern in provider.py for consistency
            if provider_type == "openai_compatible" or provider_type.startswith("openai_compatible:"):
                return await self._chat_openai_compatible(
                    messages=messages,
                    api_key=api_key,
                    api_base=provider_cfg.api_base,
                    model=params.get("model", ""),
                    tools=tools,
                    temperature=temperature,
                )

            response = await litellm.acompletion(**kwargs)

            # Parse response
            choice = response.choices[0]  # type: ignore[union-attr]
            message = choice.message

            result: Dict[str, Any] = {
                "content": message.content or "",
                "tool_calls": [],
                "usage": {},
            }

            if message.tool_calls:
                for tc in message.tool_calls:
                    result["tool_calls"].append({
                        "id": tc.id,
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    })

            if hasattr(response, "usage") and response.usage:
                result["usage"] = {
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens,
                }

            return result

        except Exception as e:
            logger.error("Agent LLM call failed", error=str(e))
            logger.debug(traceback.format_exc())
            err_text = str(e)
            if (
                provider_type == "openrouter"
                and tools
                and "No endpoints found that support tool use" in err_text
            ):
                selected_model = str(params.get("model") or "")
                raise RuntimeError(
                    "Selected OpenRouter model is not currently routed to a tool-calling "
                    "endpoint. Agents require tool use. "
                    f"Please switch Agents model (current: {selected_model})."
                ) from e
            raise

        finally:
            # Restore env
            for k, v in old_env.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v

    async def _chat_openai_compatible(
        self,
        *,
        messages: List[Dict[str, Any]],
        api_key: Optional[str],
        api_base: Optional[str],
        model: str,
        tools: Optional[List[Dict[str, Any]]],
        temperature: float,
    ) -> Dict[str, Any]:
        """Send chat request using OpenAI client for openai_compatible endpoints.

        This matches the pattern in provider.py for consistency. OpenAI-compatible
        endpoints use the OpenAI client directly, bypassing litellm.
        """
        if _OpenAIClient is None:
            raise RuntimeError("OpenAI client not installed. Run: pip install openai>=1.0.0")

        client, bypass_proxy = build_openai_compatible_client(
            _OpenAIClient,
            api_key=(api_key or os.environ.get("OPENAI_API_KEY", "")),
            api_base=api_base,
            max_retries=0,
        )

        try:
            openai_kwargs: Dict[str, Any] = {
                "model": model,
                "messages": messages,
                "temperature": temperature,
            }

            if tools:
                openai_kwargs["tools"] = tools
                openai_kwargs["tool_choice"] = "auto"

            logger.debug(
                "OpenAI-compatible chat call",
                model=model,
                api_base=api_base,
                bypass_proxy=bypass_proxy,
                msg_count=len(messages),
                has_tools=bool(tools),
            )

            # Run synchronous OpenAI call in executor (client.chat.completions.create is sync)
            resp = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: client.chat.completions.create(**openai_kwargs),
            )
        finally:
            client.close()

        if not resp or not resp.choices:
            raise ValueError("Empty response from OpenAI-compatible server")

        choice = resp.choices[0]
        message = choice.message

        result: Dict[str, Any] = {
            "content": message.content or "",
            "tool_calls": [],
            "usage": {},
        }

        if message.tool_calls:
            for tc in message.tool_calls:
                result["tool_calls"].append({
                    "id": tc.id,
                    "name": tc.function.name,
                    "arguments": tc.function.arguments,
                })

        if hasattr(resp, "usage") and resp.usage:
            result["usage"] = {
                "prompt_tokens": resp.usage.prompt_tokens,
                "completion_tokens": resp.usage.completion_tokens,
                "total_tokens": resp.usage.total_tokens,
            }

        logger.debug(
            "OpenAI-compatible chat successful",
            model=model,
            content_length=len(result["content"]),
            tool_calls=len(result["tool_calls"]),
        )

        return result
