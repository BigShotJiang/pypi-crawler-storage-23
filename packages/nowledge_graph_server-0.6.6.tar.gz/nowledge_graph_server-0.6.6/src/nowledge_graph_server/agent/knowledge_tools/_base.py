"""Shared dependencies and utilities for Knowledge Agent tools."""

from __future__ import annotations

import structlog
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

from ...services.search_index import sync_memory_to_index
from ...utils.time_partitioning import (  # noqa: F401
    _get_time_partitioned_path,
    _iter_time_partitioned_files,
)
from ..utils.search_results import (  # noqa: F401
    _normalize_search_result,
    _get_search_score,
)

logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# Tool SDK imports
# ---------------------------------------------------------------------------

from kosong.tooling import CallableTool2, ToolError, ToolOk, ToolReturnValue  # noqa: F401


# ---------------------------------------------------------------------------
# Global dependency registry
# ---------------------------------------------------------------------------

class KnowledgeAgentDependencies:
    """Global registry for Knowledge Agent tool dependencies.

    Set these before starting the KnowledgeAgentSession so tools can access them.
    """

    kuzu_client: Any = None
    search_ops: Any = None
    memory_ops: Any = None
    reports_dir: Optional[Path] = None  # Time-partitioned: YYYY/MM/YYYY-MM-DD.md
    events_dir: Optional[Path] = None   # Time-partitioned: YYYY/MM/YYYY-MM-DD.jsonl
    scheduler: Any = None  # AgentScheduler — for ScheduleFollowUp tool

    @classmethod
    def configure(
        cls,
        kuzu_client: Any,
        search_ops: Any,
        memory_ops: Any,
        reports_dir: Path,
        events_dir: Path,
        scheduler: Any = None,
    ) -> None:
        if not hasattr(search_ops, 'search_memories'):
            logger.error(
                "KnowledgeAgentDependencies: search_ops missing search_memories!",
                search_ops_type=type(search_ops).__name__,
                search_ops_attrs=sorted(a for a in dir(search_ops) if not a.startswith('_')),
            )
        cls.kuzu_client = kuzu_client
        cls.search_ops = search_ops
        cls.memory_ops = memory_ops
        cls.reports_dir = reports_dir
        cls.events_dir = events_dir
        cls.scheduler = scheduler

    @classmethod
    def is_configured(cls) -> bool:
        return (
            cls.kuzu_client is not None
            and cls.search_ops is not None
            and cls.memory_ops is not None
        )


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------


async def _resync_memory_to_lancedb(memory_ops: Any, memory_id: str) -> None:
    """Re-sync a memory to LanceDB after KuzuDB field updates."""
    try:
        memory = await memory_ops.get_memory_by_id(memory_id)
        if memory:
            await sync_memory_to_index(memory)
            logger.debug("Re-synced memory to LanceDB", memory_id=memory_id)
    except Exception as e:
        logger.warning(
            "Failed to re-sync memory to LanceDB",
            memory_id=memory_id,
            error=str(e),
        )
