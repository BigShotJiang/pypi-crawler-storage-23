"""Query & discovery tools for the Knowledge Agent."""

from __future__ import annotations

import json
import traceback
import structlog
from datetime import datetime, timezone, timedelta
from typing import Any, List, Optional
from pydantic import BaseModel, Field, field_validator

from ...database.result_utils import iter_rows, managed_result
from ._base import (
    KnowledgeAgentDependencies,
    CallableTool2, ToolError, ToolOk, ToolReturnValue,
    _normalize_search_result, _get_search_score,
)

logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# QueryRecentActivity — structured graph activity summary
# ---------------------------------------------------------------------------

class QueryRecentActivityParams(BaseModel):
    since_hours: int = Field(
        default=48,
        description="Look-back window in hours. Defaults to 48.",
    )


class QueryRecentActivity(CallableTool2):
    """Get a structured summary of recent graph activity.

    Returns new memories, EVOLVES edges, crystals, and unresolved flags
    in a single call. Use this at the START of daily briefing to understand
    what changed before deciding what goes into Working Memory.
    """

    name: str = "QueryRecentActivity"
    description: str = (
        "Get a structured summary of recent graph activity in one call. "
        "Returns: new memories (with titles, importance, unit_type), "
        "new EVOLVES edges (with relation types and titles), "
        "new crystals, and unresolved flags. "
        "Use this at the start of daily briefing instead of multiple "
        "QueryMemories calls. Much more efficient for understanding "
        "what changed in the knowledge graph."
    )
    params: type[QueryRecentActivityParams] = QueryRecentActivityParams

    async def __call__(self, params: QueryRecentActivityParams) -> ToolReturnValue:
        deps = KnowledgeAgentDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Tools not configured", brief="Not ready")

        hours = min(max(params.since_hours, 1), 168)  # Cap at 7 days

        try:
            conn = deps.kuzu_client.conn
            cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
            cutoff_str = cutoff.strftime("%Y-%m-%dT%H:%M:%S")

            activity: dict = {
                "since_hours": hours,
                "new_memories": [],
                "new_evolves": [],
                "new_crystals": [],
                "unresolved_flags": [],
            }

            # --- Recent memories (non-crystal) ---
            try:
                for row in iter_rows(conn.execute(
                    """
                    MATCH (m:Memory)
                    WHERE m.created_at >= $cutoff AND (m.is_crystal IS NULL OR m.is_crystal = false)
                    RETURN m.id, m.title, m.unit_type, m.importance, m.created_at
                    ORDER BY m.created_at DESC
                    LIMIT 30
                    """,
                    {"cutoff": cutoff_str},
                )):
                    created_at = row[4]
                    if isinstance(created_at, datetime):
                        created_at = created_at.isoformat()
                    elif created_at is not None:
                        created_at = str(created_at)
                    activity["new_memories"].append({
                        "id": row[0],
                        "title": row[1] or "(untitled)",
                        "unit_type": row[2] or "fact",
                        "importance": float(row[3]) if row[3] is not None else 0.5,
                        "created_at": created_at,
                    })
            except Exception as e:
                logger.debug("QueryRecentActivity: memories query failed", error=str(e))

            # --- Recent EVOLVES edges ---
            try:
                for row in iter_rows(conn.execute(
                    """
                    MATCH (older:Memory)-[e:EVOLVES]->(newer:Memory)
                    WHERE e.created_at >= $cutoff
                    RETURN newer.id, newer.title, older.id, older.title,
                           e.content_relation, e.created_at
                    ORDER BY e.created_at DESC
                    LIMIT 15
                    """,
                    {"cutoff": cutoff_str},
                )):
                    created_at = row[5]
                    if isinstance(created_at, datetime):
                        created_at = created_at.isoformat()
                    elif created_at is not None:
                        created_at = str(created_at)
                    activity["new_evolves"].append({
                        "newer_id": row[0],
                        "newer_title": row[1] or "(untitled)",
                        "older_id": row[2],
                        "older_title": row[3] or "(untitled)",
                        "relation": row[4] or "enriches",
                        "created_at": created_at,
                    })
            except Exception as e:
                logger.debug("QueryRecentActivity: evolves query failed", error=str(e))

            # --- Recent crystals ---
            try:
                for row in iter_rows(conn.execute(
                    """
                    MATCH (c:Memory)
                    WHERE c.is_crystal = true AND c.created_at >= $cutoff
                    RETURN c.id, c.title, c.created_at
                    ORDER BY c.created_at DESC
                    LIMIT 10
                    """,
                    {"cutoff": cutoff_str},
                )):
                    created_at = row[2]
                    if isinstance(created_at, datetime):
                        created_at = created_at.isoformat()
                    elif created_at is not None:
                        created_at = str(created_at)
                    activity["new_crystals"].append({
                        "id": row[0],
                        "title": row[1] or "(untitled)",
                        "created_at": created_at,
                    })
            except Exception as e:
                logger.debug("QueryRecentActivity: crystals query failed", error=str(e))

            # --- Unresolved flags (from event JSONL files) ---
            try:
                if deps.events_dir:
                    from nowledge_graph_server.utils.time_partitioning import _iter_time_partitioned_files
                    for event_file in _iter_time_partitioned_files(
                        deps.events_dir, "jsonl", last_n_days=30
                    ):
                        try:
                            for line in event_file.read_text(encoding="utf-8").splitlines():
                                if not line.strip():
                                    continue
                                try:
                                    event = json.loads(line)
                                    if (
                                        event.get("severity") == "action_required"
                                        and not event.get("resolved")
                                    ):
                                        activity["unresolved_flags"].append({
                                            "event_id": event.get("id", ""),
                                            "description": event.get("description", "")[:200],
                                            "title": event.get("title", ""),
                                            "memory_ids": event.get("related_memory_ids", []),
                                        })
                                except json.JSONDecodeError:
                                    continue
                        except Exception:
                            continue
            except Exception as e:
                logger.debug("QueryRecentActivity: flags scan failed", error=str(e))

            # --- Summary counts ---
            activity["summary"] = {
                "memory_count": len(activity["new_memories"]),
                "evolves_count": len(activity["new_evolves"]),
                "crystal_count": len(activity["new_crystals"]),
                "flag_count": len(activity["unresolved_flags"]),
            }

            return ToolOk(output=json.dumps(activity))

        except Exception as e:
            logger.error("QueryRecentActivity failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Activity query failed")


# ---------------------------------------------------------------------------
# QueryMemories
# ---------------------------------------------------------------------------

class QueryMemoriesParams(BaseModel):
    query: Optional[str] = Field(default=None, description="Semantic search query. Optional when using since_hours.")
    limit: int = Field(default=10, description="Max results to return")
    since_hours: Optional[int] = Field(default=None, description="Only return memories created within the last N hours")


class QueryMemories(CallableTool2):
    """Search the knowledge graph for memories, or list recent memories by time."""

    name: str = "QueryMemories"
    description: str = (
        "Search the knowledge graph for memories. Two modes: "
        "(1) Semantic search: provide 'query' to find matching memories. "
        "(2) Recent memories: provide 'since_hours' (e.g. 24) to list memories created in the last N hours. "
        "Both can be combined to filter search results by recency."
    )
    params: type[QueryMemoriesParams] = QueryMemoriesParams

    async def __call__(self, params: QueryMemoriesParams) -> ToolReturnValue:
        deps = KnowledgeAgentDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Tools not configured", brief="Not ready")

        try:
            # Mode 1: Time-based listing (since_hours without query)
            if not params.query and params.since_hours:
                cutoff = datetime.now(timezone.utc) - timedelta(hours=params.since_hours)
                cutoff_str = cutoff.strftime("%Y-%m-%dT%H:%M:%S")

                conn = deps.kuzu_client.conn

                memories = []
                for row in iter_rows(conn.execute(
                    """
                    MATCH (m:Memory)
                    WHERE m.created_at >= $cutoff
                    RETURN m.id, m.title, m.content, m.unit_type, m.importance,
                           m.created_at, m.is_crystal
                    ORDER BY m.created_at DESC
                    LIMIT $limit
                    """,
                    {"cutoff": cutoff_str, "limit": min(params.limit, 50)},
                )):
                    # Convert datetime/non-primitive fields to JSON-safe types
                    created_at = row[5]
                    if isinstance(created_at, datetime):
                        created_at = created_at.isoformat()
                    elif created_at is not None:
                        created_at = str(created_at)
                    memories.append({
                        "id": row[0],
                        "title": row[1] or "",
                        "content": (row[2] or "")[:500],
                        "unit_type": row[3] or "fact",
                        "importance": float(row[4]) if row[4] is not None else 0.5,
                        "created_at": created_at,
                        "is_crystal": bool(row[6]) if row[6] is not None else False,
                    })

                return ToolOk(output=json.dumps({
                    "count": len(memories),
                    "memories": memories,
                    "mode": "recent",
                    "since_hours": params.since_hours,
                }))

            # Mode 2: Semantic search (with optional since_hours filter)
            query = params.query or ""
            if not query:
                return ToolError(
                    output="", message="Provide either 'query' or 'since_hours'", brief="Missing params"
                )

            results = await deps.search_ops.search_memories(
                query=query,
                limit=min(params.limit, 20),
            )

            memories = []
            for r in results:
                mem = _normalize_search_result(r)
                if not mem:
                    continue
                # Apply since_hours filter if provided
                if params.since_hours:
                    created_at = mem.get("created_at", "")
                    if created_at:
                        try:
                            created = datetime.fromisoformat(str(created_at).replace("Z", "+00:00"))
                            cutoff = datetime.now(timezone.utc) - timedelta(hours=params.since_hours)
                            if created < cutoff:
                                continue
                        except (ValueError, TypeError):
                            pass

                # Include created_at so agent can reason about temporal patterns
                created_at = mem.get("created_at")
                if isinstance(created_at, datetime):
                    created_at = created_at.isoformat()
                elif created_at is not None:
                    created_at = str(created_at)

                memories.append({
                    "id": mem.get("id", ""),
                    "title": mem.get("title", ""),
                    "content": (mem.get("content", "") or "")[:500],
                    "unit_type": mem.get("unit_type", "fact"),
                    "score": _get_search_score(r, mem),
                    "created_at": created_at,
                    "is_crystal": bool(mem.get("is_crystal", False)),
                })

            return ToolOk(output=json.dumps({
                "count": len(memories),
                "memories": memories[:params.limit],
            }))

        except Exception as e:
            logger.error(
                "QueryMemories failed",
                error=str(e),
                search_ops_type=type(deps.search_ops).__name__,
                traceback=traceback.format_exc(),
            )
            return ToolError(output="", message=str(e), brief="Search failed")


# ---------------------------------------------------------------------------
# QueryMemoryNeighbors
# ---------------------------------------------------------------------------

class QueryMemoryNeighborsParams(BaseModel):
    memory_id: str = Field(description="ID of the memory to explore")
    depth: int = Field(default=1, description="Traversal depth (1-3)")
    edge_types: Optional[List[str]] = Field(
        default=None, description="Filter by edge types: EVOLVES|MENTIONS|CRYSTALLIZED_FROM"
    )

    @field_validator("edge_types", mode="before")
    @classmethod
    def coerce_string_to_list(cls, v: Any) -> Any:
        """LLMs often pass JSON-encoded strings instead of arrays. Parse them."""
        if isinstance(v, str):
            try:
                parsed = json.loads(v)
                if isinstance(parsed, list):
                    return parsed
            except (json.JSONDecodeError, TypeError):
                pass
            if v.strip():
                return [v.strip()]
            return None
        return v


class QueryMemoryNeighbors(CallableTool2):
    """Query graph neighbors of a memory."""

    name: str = "QueryMemoryNeighbors"
    description: str = (
        "Explore the graph structure around a memory. "
        "Returns connected memories via EVOLVES, MENTIONS, and CRYSTALLIZED_FROM edges. "
        "Use this to understand a memory's context in the knowledge graph."
    )
    params: type[QueryMemoryNeighborsParams] = QueryMemoryNeighborsParams

    async def __call__(self, params: QueryMemoryNeighborsParams) -> ToolReturnValue:
        deps = KnowledgeAgentDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Tools not configured", brief="Not ready")

        depth = min(max(params.depth, 1), 3)

        try:
            conn = deps.kuzu_client.conn

            # Get all neighbors within depth — include content so the agent
            # can actually read what connected memories say
            neighbors = []
            for row in iter_rows(conn.execute(
                """
                MATCH (m:Memory)-[r]-(n:Memory)
                WHERE m.id = $id
                RETURN n.id, n.title, n.unit_type, LABEL(r) as edge_type,
                       r.content_relation as relation, n.content, n.created_at
                LIMIT 50
                """,
                {"id": params.memory_id},
            )):
                edge_type = row[3]
                if params.edge_types and edge_type not in params.edge_types:
                    continue
                created_at = row[6]
                if isinstance(created_at, datetime):
                    created_at = created_at.isoformat()
                elif created_at is not None:
                    created_at = str(created_at)
                neighbors.append({
                    "id": row[0],
                    "title": row[1],
                    "unit_type": row[2],
                    "edge_type": edge_type,
                    "relation": row[4],
                    "content": (row[5] or "")[:300],
                    "created_at": created_at,
                })

            result_data = {
                "memory_id": params.memory_id,
                "neighbor_count": len(neighbors),
                "neighbors": neighbors,
            }
            if not neighbors:
                result_data["note"] = (
                    "No graph neighbors found. This memory is isolated — "
                    "no EVOLVES edges, entity mentions, or crystal links exist yet. "
                    "Consider using QueryMemories to find semantically related memories, "
                    "then use GetMemoryById to compare content before creating EVOLVES edges."
                )
            return ToolOk(output=json.dumps(result_data))

        except Exception as e:
            logger.error("QueryMemoryNeighbors failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Graph query failed")
