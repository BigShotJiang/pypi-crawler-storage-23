"""Working Memory tools and rotation for the Knowledge Agent."""

from __future__ import annotations

import re
import json
import structlog
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

from ...utils.feed_events import emit_feed_event
from ..paths import get_working_memory_path, get_working_memory_archive_path
from ._base import (
    CallableTool2, ToolError, ToolOk, ToolReturnValue,
)

logger = structlog.get_logger(__name__)

_MAX_WORKING_MEMORY_BYTES = 3072  # 3KB hard limit (2KB soft target)


# ---------------------------------------------------------------------------
# Structured parsing — extract rich metadata from WM markdown
# ---------------------------------------------------------------------------

def _parse_working_memory(content: str) -> Dict[str, Any]:
    """Parse WM markdown into structured metadata for the feed event.

    Extracts focus areas (with descriptions and linked memory IDs),
    attention flags (with severity and linked memory IDs), and briefing text.
    This runs server-side so the frontend gets structured data instead of
    having to do fragile regex parsing.
    """
    result: Dict[str, Any] = {
        "focus_areas": [],
        "flags": [],
        "briefing": "",
    }

    # --- Focus Areas ---
    focus_match = re.search(r'## Focus Areas\n([\s\S]*?)(?=\n## |$)', content)
    if focus_match:
        for line in focus_match.group(1).strip().split('\n'):
            line = line.strip()
            if not line.startswith('- '):
                continue
            # Parse: - **Topic** — description ([view](nowledgemem://memory/id))
            name_match = re.match(r'-\s+\*\*(.+?)\*\*\s*(?:[—\-–])\s*(.*)', line)
            if name_match:
                name = name_match.group(1)
                desc_raw = name_match.group(2)
                # Extract memory ID from deeplink in description
                mid = re.search(r'nowledgemem://memory/([a-zA-Z0-9_-]+)', desc_raw)
                # Strip deeplink syntax for clean description
                desc = re.sub(r'\s*\(\[view\]\(nowledgemem://memory/[^)]+\)\)\.?', '', desc_raw).strip()
                desc = re.sub(r'\s*\[.+?\]\(nowledgemem://memory/[^)]+\)\.?', '', desc).strip()
                result["focus_areas"].append({
                    "name": name,
                    "description": desc,
                    "memoryId": mid.group(1) if mid else None,
                })

    # --- Needs Attention ---
    flag_match = re.search(r'## Needs Attention\n([\s\S]*?)(?=\n## |$)', content)
    if flag_match:
        for line in flag_match.group(1).strip().split('\n'):
            line = line.strip()
            if not line.startswith('- '):
                continue
            # Parse: - [severity] description ([view](nowledgemem://memory/id))
            sev_match = re.match(r'-\s+\[(\w+)\]\s+(.*)', line)
            if sev_match:
                severity = sev_match.group(1)
                desc_raw = sev_match.group(2)
            else:
                severity = "medium"
                desc_raw = line[2:]  # strip "- "
            mid = re.search(r'nowledgemem://memory/([a-zA-Z0-9_-]+)', desc_raw)
            desc = re.sub(r'\s*\(\[view\]\(nowledgemem://memory/[^)]+\)\)\.?', '', desc_raw).strip()
            desc = re.sub(r'\s*\[.+?\]\(nowledgemem://memory/[^)]+\)\.?', '', desc).strip()
            result["flags"].append({
                "severity": severity,
                "description": desc,
                "memoryId": mid.group(1) if mid else None,
            })

    # --- Briefing ---
    brief_match = re.search(r'## Briefing\n([\s\S]*?)(?=\n## |$)', content)
    if brief_match:
        result["briefing"] = brief_match.group(1).strip()

    return result


# ---------------------------------------------------------------------------
# ReadWorkingMemory
# ---------------------------------------------------------------------------

class ReadWorkingMemoryParams(BaseModel):
    date: Optional[str] = Field(
        default=None,
        description="YYYY-MM-DD. Defaults to today. Use for reading a past day's archived Working Memory.",
    )


class ReadWorkingMemory(CallableTool2):
    """Read the Working Memory file (~/ai-now/memory.md)."""

    name: str = "ReadWorkingMemory"
    description: str = (
        "Read the Working Memory file (~/ai-now/memory.md). "
        "Returns today's Working Memory content, or a past day's archived version "
        "if a date is provided. Working Memory contains focus areas, flags, and "
        "daily activity -- the system's active workspace."
    )
    params: type[ReadWorkingMemoryParams] = ReadWorkingMemoryParams

    async def __call__(self, params: ReadWorkingMemoryParams) -> ToolReturnValue:
        try:
            today_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")

            if params.date and params.date != today_str:
                # Read from archive
                try:
                    target = datetime.strptime(params.date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
                except ValueError:
                    return ToolError(output="", message=f"Invalid date format: {params.date}. Use YYYY-MM-DD.", brief="Bad date")
                path = get_working_memory_archive_path(target)
            else:
                # Read current
                path = get_working_memory_path()

            if not path.exists():
                return ToolOk(output=json.dumps({
                    "exists": False,
                    "content": "",
                    "date": params.date or today_str,
                }))

            content = path.read_text(encoding="utf-8")
            if len(content) > 6000:
                content = content[:6000] + "\n\n... (truncated)"

            return ToolOk(output=json.dumps({
                "exists": True,
                "content": content,
                "date": params.date or today_str,
            }))

        except Exception as e:
            logger.error("ReadWorkingMemory failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Read failed")


# ---------------------------------------------------------------------------
# UpdateWorkingMemory
# ---------------------------------------------------------------------------

class UpdateWorkingMemoryParams(BaseModel):
    content: str = Field(
        description=(
            "Full markdown content for Working Memory. Must include sections: "
            "## Focus Areas (3-5 non-obvious connections worth external agent context) "
            "and ## Briefing (1-2 sentence summary of recent themes). "
            "Do NOT include actionable items — use FlagForReview for those. "
            "Use nowledgemem://memory/{id} deeplinks for all memory references. "
            "Keep under 2KB."
        )
    )


class UpdateWorkingMemory(CallableTool2):
    """Write the Working Memory file (~/ai-now/memory.md)."""

    name: str = "UpdateWorkingMemory"
    description: str = (
        "Write the Working Memory file (~/ai-now/memory.md). Max ~2KB. "
        "Only call this during daily briefing or when updating focus areas. "
        "Content must be structured markdown with ## sections. "
        "Use nowledgemem://memory/{id} deeplinks for memory references."
    )
    params: type[UpdateWorkingMemoryParams] = UpdateWorkingMemoryParams

    async def __call__(self, params: UpdateWorkingMemoryParams) -> ToolReturnValue:
        try:
            content = params.content

            # LLMs sometimes output literal \uXXXX escape sequences instead of
            # actual Unicode characters (e.g. \u2014 instead of —). Decode them.
            content = re.sub(
                r'\\u([0-9a-fA-F]{4})',
                lambda m: chr(int(m.group(1), 16)),
                content,
            )

            # --- Structural validation ---
            if '## Focus Areas' not in content:
                return ToolError(
                    output="",
                    message="Missing required section: ## Focus Areas. Content must follow the WM template.",
                    brief="Missing section",
                )
            if '## Briefing' not in content:
                return ToolError(
                    output="",
                    message="Missing required section: ## Briefing. Content must follow the WM template.",
                    brief="Missing section",
                )

            if len(content.encode("utf-8")) > _MAX_WORKING_MEMORY_BYTES:
                return ToolError(
                    output="",
                    message=f"Content too large ({len(content.encode('utf-8'))} bytes). Max is {_MAX_WORKING_MEMORY_BYTES} bytes (~2KB target).",
                    brief="Too large",
                )

            # --- Parse structured metadata ---
            parsed = _parse_working_memory(content)

            # Validate deeplinks exist — WM without links to memories is not useful
            memory_ids = re.findall(r'nowledgemem://memory/([a-zA-Z0-9_-]+)', content)
            unique_memory_ids = list(dict.fromkeys(memory_ids))  # deduplicate, preserve order

            if not unique_memory_ids and parsed["focus_areas"]:
                logger.warning("Working Memory has focus areas but no deeplinks — content may be less useful")

            # --- Write file ---
            path = get_working_memory_path()
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")

            # --- Emit feed event with structured metadata ---
            emit_feed_event(
                "working_memory_updated",
                title="Working Memory updated",
                description=content[:200],
                related_memory_ids=unique_memory_ids[:10] if unique_memory_ids else None,
                metadata={
                    "content": content,
                    "date": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
                    "parsed": parsed,
                },
            )

            logger.info(
                "Updated Working Memory",
                path=str(path),
                size=len(content),
                memory_refs=len(unique_memory_ids),
                focus_areas=len(parsed["focus_areas"]),
                flags=len(parsed["flags"]),
            )

            return ToolOk(output=json.dumps({
                "success": True,
                "path": str(path),
                "size_bytes": len(content.encode("utf-8")),
                "memory_refs": len(unique_memory_ids),
                "focus_areas": len(parsed["focus_areas"]),
                "flags": len(parsed["flags"]),
            }))

        except Exception as e:
            logger.error("UpdateWorkingMemory failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Write failed")


# ---------------------------------------------------------------------------
# Working Memory Rotation
# ---------------------------------------------------------------------------

def rotate_working_memory() -> Optional[str]:
    """Archive yesterday's Working Memory and clear for today.

    Called before daily briefing execution. Returns the archived content
    so it can be injected into the briefing prompt for continuity.

    Returns None if no Working Memory exists or if it's already today's.
    """
    path = get_working_memory_path()
    if not path.exists():
        logger.debug("No Working Memory to rotate")
        return None

    try:
        content = path.read_text(encoding="utf-8")
    except Exception as e:
        logger.warning("Failed to read Working Memory for rotation", error=str(e))
        return None

    # Extract date from header: "# Working Memory -- 2026-02-07" or similar
    date_match = re.search(r'(\d{4}-\d{2}-\d{2})', content[:200])
    today_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    if date_match:
        wm_date_str = date_match.group(1)
        if wm_date_str == today_str:
            logger.debug("Working Memory is already today's, skipping rotation")
            return None
    else:
        # No date in header -- treat as stale, archive with yesterday's date
        wm_date_str = (datetime.now(timezone.utc) - timedelta(days=1)).strftime("%Y-%m-%d")

    # Archive
    try:
        wm_date = datetime.strptime(wm_date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        archive_path = get_working_memory_archive_path(wm_date)
        archive_path.parent.mkdir(parents=True, exist_ok=True)
        archive_path.write_text(content, encoding="utf-8")
        logger.info("Archived Working Memory", date=wm_date_str, path=str(archive_path))
    except Exception as e:
        logger.warning("Failed to archive Working Memory", error=str(e))
        # Still proceed to delete current -- agent will recreate

    # Delete current so agent creates fresh one
    try:
        path.unlink()
        logger.info("Cleared current Working Memory for rotation")
    except Exception as e:
        logger.warning("Failed to delete current Working Memory", error=str(e))

    return content
