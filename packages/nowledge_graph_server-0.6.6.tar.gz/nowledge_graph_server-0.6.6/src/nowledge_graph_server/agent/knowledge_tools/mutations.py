"""Graph mutation tools for the Knowledge Agent."""

from __future__ import annotations

import json
import uuid
import structlog
from datetime import datetime, timezone
from typing import Any, List, Optional
from pydantic import BaseModel, Field, field_validator

from ...database.result_utils import iter_rows, managed_result
from ...models.graph import MemoryNode
from ...services.search_index import sync_memory_to_index
from ...utils.feed_events import emit_feed_event
from ._base import (
    KnowledgeAgentDependencies,
    CallableTool2, ToolError, ToolOk, ToolReturnValue,
    _resync_memory_to_lancedb,
)

logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# CreateEVOLVES
# ---------------------------------------------------------------------------

_VALID_RELATIONS = {"replaces", "enriches", "confirms", "challenges"}


class CreateEVOLVESParams(BaseModel):
    older_memory_id: str = Field(description="ID of the older/existing memory (edge source)")
    newer_memory_id: str = Field(description="ID of the newer/incoming memory (edge target)")
    content_relation: str = Field(
        description="Type of relationship: replaces|enriches|confirms|challenges"
    )
    confidence: float = Field(default=0.8, description="Confidence in this relationship (0.7-1.0)")
    reason: str = Field(description="Brief explanation of why this relationship exists")

    @field_validator("content_relation")
    @classmethod
    def validate_relation(cls, v: str) -> str:
        if v not in _VALID_RELATIONS:
            raise ValueError(f"content_relation must be one of {_VALID_RELATIONS}, got '{v}'")
        return v

    @field_validator("confidence")
    @classmethod
    def validate_confidence(cls, v: float) -> float:
        if v < 0.7:
            raise ValueError(f"confidence must be >= 0.7 (quality bar), got {v}")
        if v > 1.0:
            raise ValueError(f"confidence must be <= 1.0, got {v}")
        return v


class CreateEVOLVES(CallableTool2):
    """Create an EVOLVES relationship between two memories."""

    name: str = "CreateEVOLVES"
    description: str = (
        "Create an EVOLVES relationship between two memories. "
        "Edge direction is older -> newer. "
        "Relationship types: replaces (newer makes older obsolete), "
        "enriches (newer adds detail), confirms (same info different source), "
        "challenges (contradictory information). "
        "When content_relation='replaces', the older memory's is_latest is set to false."
    )
    params: type[CreateEVOLVESParams] = CreateEVOLVESParams

    async def __call__(self, params: CreateEVOLVESParams) -> ToolReturnValue:
        deps = KnowledgeAgentDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Tools not configured", brief="Not ready")

        older_id = params.older_memory_id
        newer_id = params.newer_memory_id
        relation = params.content_relation
        confidence = params.confidence
        reason = params.reason
        now = datetime.now(timezone.utc).isoformat()

        try:
            conn = deps.kuzu_client.conn

            # Verify both memories exist
            with managed_result(conn.execute(
                "MATCH (m:Memory) WHERE m.id = $id RETURN m.id",
                {"id": older_id},
            )) as check:
                if not check.has_next():
                    return ToolError(output="", message=f"Memory not found: {older_id}", brief="Not found")

            with managed_result(conn.execute(
                "MATCH (m:Memory) WHERE m.id = $id RETURN m.id",
                {"id": newer_id},
            )) as check:
                if not check.has_next():
                    return ToolError(output="", message=f"Memory not found: {newer_id}", brief="Not found")

            # Check for existing EVOLVES edge to prevent duplicates
            with managed_result(conn.execute(
                """
                MATCH (a:Memory)-[r:EVOLVES]->(b:Memory)
                WHERE a.id = $older_id AND b.id = $newer_id
                RETURN r.content_relation
                """,
                {"older_id": older_id, "newer_id": newer_id},
            )) as dup_check:
                if dup_check.has_next():
                    existing_relation = dup_check.get_next()[0]
                    return ToolOk(output=json.dumps({
                        "skipped": True,
                        "reason": f"EVOLVES edge already exists ({existing_relation}). No duplicate created.",
                        "older_memory_id": older_id,
                        "newer_memory_id": newer_id,
                        "existing_relation": existing_relation,
                    }))

            # Create the EVOLVES edge: older -> newer
            conn.execute(
                """
                MATCH (a:Memory), (b:Memory)
                WHERE a.id = $older_id AND b.id = $newer_id
                CREATE (a)-[:EVOLVES {
                    content_relation: $relation,
                    is_progression: $is_prog,
                    confidence: $confidence,
                    detected_by: 'agent',
                    reviewed: false,
                    reason: $reason,
                    created_at: timestamp($now)
                }]->(b)
                """,
                {
                    "older_id": older_id,
                    "newer_id": newer_id,
                    "relation": relation,
                    "is_prog": relation in ("replaces", "enriches"),
                    "confidence": confidence,
                    "reason": reason,
                    "now": now,
                },
            )

            # Auto-update is_latest when 'replaces'
            if relation == "replaces":
                conn.execute(
                    "MATCH (m:Memory) WHERE m.id = $older_id SET m.is_latest = false",
                    {"older_id": older_id},
                )
                await _resync_memory_to_lancedb(deps.memory_ops, older_id)

            # Emit feed event so EVOLVES edges are visible in timeline
            emit_feed_event(
                "evolves_detected",
                title=f"Memory updated: {relation}",
                description=reason,
                related_memory_ids=[older_id, newer_id],
                metadata={
                    "older_memory_id": older_id,
                    "newer_memory_id": newer_id,
                    "content_relation": relation,
                    "confidence": confidence,
                },
            )

            logger.info(
                "Created EVOLVES edge",
                older_id=older_id,
                newer_id=newer_id,
                relation=relation,
            )

            # Notify the scheduler so evolves_detected → cluster evaluation
            # → potential crystallization chain fires (fire-and-forget)
            try:
                import asyncio
                from ..manager import KnowledgeAgentManager
                mgr = KnowledgeAgentManager.get_instance()
                if mgr.is_running:
                    edge_id = f"{older_id}__{newer_id}"
                    asyncio.create_task(mgr.on_evolves_detected(edge_id))
            except Exception:
                pass  # Scheduler notification is best-effort

            return ToolOk(output=json.dumps({
                "success": True,
                "older_memory_id": older_id,
                "newer_memory_id": newer_id,
                "content_relation": relation,
                "confidence": confidence,
                "is_latest_updated": relation == "replaces",
            }))

        except Exception as e:
            logger.error("CreateEVOLVES failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Failed to create EVOLVES")


# ---------------------------------------------------------------------------
# CreateCrystal
# ---------------------------------------------------------------------------

def _coerce_json_string_to_list(v: Any) -> Any:
    """LLMs often pass JSON-encoded strings instead of arrays. Parse them."""
    if isinstance(v, str):
        try:
            parsed = json.loads(v)
            if isinstance(parsed, list):
                return parsed
        except (json.JSONDecodeError, TypeError):
            pass
        if v.strip():
            return [v.strip()]
    return v


class CreateCrystalParams(BaseModel):
    title: str = Field(description="Title for the crystal")
    content: str = Field(description="Synthesized, context-independent knowledge")
    source_memory_ids: List[str] = Field(
        description="List of source memory IDs that contributed"
    )
    labels: Optional[List[str]] = Field(default=None, description="Optional labels")

    @field_validator("source_memory_ids", "labels", mode="before")
    @classmethod
    def coerce_string_to_list(cls, v: Any) -> Any:
        return _coerce_json_string_to_list(v)


class CreateCrystal(CallableTool2):
    """Create a crystal -- a synthesized knowledge unit from multiple memories."""

    name: str = "CreateCrystal"
    description: str = (
        "Create a crystal -- a high-quality, context-independent synthesis of "
        "multiple related memories. Crystals consolidate knowledge that would "
        "otherwise be scattered across 3+ individual memories. "
        "Provide a comprehensive but concise synthesis, not just a list."
    )
    params: type[CreateCrystalParams] = CreateCrystalParams

    async def __call__(self, params: CreateCrystalParams) -> ToolReturnValue:
        deps = KnowledgeAgentDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Tools not configured", brief="Not ready")

        if len(params.source_memory_ids) < 3:
            return ToolError(
                output="",
                message="Crystals require at least 3 source memories",
                brief="Need 3+ sources",
            )

        try:
            crystal_id = f"crystal_{uuid.uuid4().hex[:12]}"
            now = datetime.now(timezone.utc).isoformat()
            conn = deps.kuzu_client.conn

            # Verify source memories exist
            for src_id in params.source_memory_ids:
                with managed_result(conn.execute(
                    "MATCH (m:Memory) WHERE m.id = $id RETURN m.id",
                    {"id": src_id},
                )) as check:
                    if not check.has_next():
                        return ToolError(
                            output="",
                            message=f"Source memory not found: {src_id}",
                            brief="Source not found",
                        )

            # Create crystal memory node
            conn.execute(
                """
                CREATE (m:Memory {
                    id: $id,
                    title: $title,
                    content: $content,
                    unit_type: 'crystal',
                    is_crystal: true,
                    is_latest: true,
                    importance: 0.8,
                    created_at: timestamp($now),
                    updated_at: timestamp($now),
                    last_evaluated_at: timestamp($now),
                    source: 'agent'
                })
                """,
                {
                    "id": crystal_id,
                    "title": params.title,
                    "content": params.content,
                    "now": now,
                },
            )

            # Create CRYSTALLIZED_FROM edges
            for i, src_id in enumerate(params.source_memory_ids):
                conn.execute(
                    """
                    MATCH (c:Memory), (s:Memory)
                    WHERE c.id = $crystal_id AND s.id = $src_id
                    CREATE (c)-[:CRYSTALLIZED_FROM {
                        contribution_weight: $weight,
                        created_at: timestamp($now)
                    }]->(s)
                    """,
                    {
                        "crystal_id": crystal_id,
                        "src_id": src_id,
                        "weight": 1.0 / len(params.source_memory_ids),
                        "now": now,
                    },
                )

            # Index the crystal in LanceDB
            try:
                crystal = MemoryNode(
                    id=crystal_id,
                    title=params.title,
                    content=params.content,
                    unit_type="crystal",
                    is_crystal=True,
                    crystal_title=params.title,
                    source_unit_count=len(params.source_memory_ids),
                    importance=0.8,
                    source="agent",
                    extraction_method="agent",
                )
                await sync_memory_to_index(crystal)
            except Exception as e:
                logger.warning("Failed to index crystal", error=str(e))

            # Compute provenance from source memories
            source_platforms: list[str] = []
            source_dates: list[str] = []
            try:
                for src_id in params.source_memory_ids:
                    with managed_result(conn.execute(
                        "MATCH (m:Memory) WHERE m.id = $id RETURN m.source, m.created_at",
                        {"id": src_id},
                    )) as row:
                        if row.has_next():
                            r = row.get_next()
                            src = r[0]
                            if src and src not in source_platforms:
                                source_platforms.append(src)
                            if r[1]:
                                source_dates.append(str(r[1])[:10])  # YYYY-MM-DD
            except Exception:
                pass  # Provenance is best-effort

            time_span = ""
            if source_dates:
                sorted_dates = sorted(source_dates)
                if sorted_dates[0] != sorted_dates[-1]:
                    from datetime import datetime as dt
                    try:
                        d0 = dt.strptime(sorted_dates[0], "%Y-%m-%d")
                        d1 = dt.strptime(sorted_dates[-1], "%Y-%m-%d")
                        months = (d1.year - d0.year) * 12 + d1.month - d0.month
                        if months >= 2:
                            time_span = f"{d0.strftime('%b %Y')}–{d1.strftime('%b %Y')}"
                        else:
                            time_span = f"{d0.strftime('%b %d')}–{d1.strftime('%b %d, %Y')}"
                    except Exception:
                        pass

            # Emit feed event so crystal appears in the Feed timeline
            feed_metadata: dict = {
                "crystal_id": crystal_id,
                "source_count": len(params.source_memory_ids),
            }
            if source_platforms:
                feed_metadata["source_platforms"] = source_platforms
            if time_span:
                feed_metadata["time_span"] = time_span

            emit_feed_event(
                "crystal_created",
                title=params.title,
                description=params.content[:300],
                related_memory_ids=params.source_memory_ids,
                metadata=feed_metadata,
            )

            logger.info(
                "Created crystal",
                crystal_id=crystal_id,
                sources=len(params.source_memory_ids),
            )

            return ToolOk(output=json.dumps({
                "success": True,
                "crystal_id": crystal_id,
                "title": params.title,
                "source_count": len(params.source_memory_ids),
            }))

        except Exception as e:
            logger.error("CreateCrystal failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Crystal creation failed")


# ---------------------------------------------------------------------------
# UpdateMemoryMeta
# ---------------------------------------------------------------------------

class UpdateMemoryMetaParams(BaseModel):
    memory_id: str = Field(description="ID of the memory to update")
    importance: Optional[float] = Field(default=None, description="New importance (0.0-1.0)")
    labels: Optional[List[str]] = Field(default=None, description="New labels to add")

    @field_validator("labels", mode="before")
    @classmethod
    def coerce_string_to_list(cls, v: Any) -> Any:
        return _coerce_json_string_to_list(v)


class UpdateMemoryMeta(CallableTool2):
    """Update metadata fields on a memory."""

    name: str = "UpdateMemoryMeta"
    description: str = (
        "Update metadata fields on a memory: importance score or labels. "
        "Use this to refine memory properties based on analysis."
    )
    params: type[UpdateMemoryMetaParams] = UpdateMemoryMetaParams

    async def __call__(self, params: UpdateMemoryMetaParams) -> ToolReturnValue:
        deps = KnowledgeAgentDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Tools not configured", brief="Not ready")

        if params.importance is None and params.labels is None:
            return ToolError(output="", message="No updates provided", brief="Nothing to update")

        try:
            conn = deps.kuzu_client.conn
            now = datetime.now(timezone.utc).isoformat()
            updates = []

            if params.importance is not None:
                conn.execute(
                    "MATCH (m:Memory) WHERE m.id = $id SET m.importance = $val, m.updated_at = timestamp($now)",
                    {"id": params.memory_id, "val": params.importance, "now": now},
                )
                updates.append(f"importance={params.importance}")

            if params.labels:
                # Add labels (merge with existing)
                conn.execute(
                    """
                    MATCH (m:Memory) WHERE m.id = $id
                    SET m.labels = CASE
                        WHEN m.labels IS NULL THEN $labels
                        ELSE list_distinct(list_concat(m.labels, $labels))
                    END,
                    m.updated_at = timestamp($now)
                    """,
                    {"id": params.memory_id, "labels": params.labels, "now": now},
                )
                updates.append(f"labels+={params.labels}")

            # Re-sync to LanceDB
            await _resync_memory_to_lancedb(deps.memory_ops, params.memory_id)

            # Emit feed event so metadata changes are visible in timeline
            emit_feed_event(
                "memory_meta_updated",
                title=f"Memory updated: {', '.join(updates)}",
                description=f"Metadata updated for memory {params.memory_id[:12]}",
                related_memory_ids=[params.memory_id],
                metadata={
                    "memory_id": params.memory_id,
                    "importance": params.importance,
                    "labels_added": params.labels,
                },
            )

            logger.info("Updated memory meta", memory_id=params.memory_id, updates=updates)

            return ToolOk(output=json.dumps({
                "success": True,
                "memory_id": params.memory_id,
                "updates": updates,
            }))

        except Exception as e:
            logger.error("UpdateMemoryMeta failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Update failed")
