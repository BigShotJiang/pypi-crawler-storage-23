"""GetMemoryById tool for the Knowledge Agent.

The Knowledge Agent needs to read full memory content for:
- EVOLVES relationship detection (comparing full texts)
- Crystallization (synthesizing multiple memories)
- Daily briefings (understanding what each memory says)
- Insight generation (finding contradictions, patterns)

Without this, the agent only sees 500-char snippets from QueryMemories
and has zero content from QueryMemoryNeighbors — making it effectively
blind to the actual knowledge in the graph.
"""

from __future__ import annotations

import json
import structlog
from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field

from ._base import (
    KnowledgeAgentDependencies,
    CallableTool2, ToolError, ToolOk, ToolReturnValue,
)

logger = structlog.get_logger(__name__)


class GetMemoryByIdParams(BaseModel):
    memory_id: str = Field(description="ID of the memory to retrieve")


class GetMemoryById(CallableTool2):
    """Get full details of a specific memory by ID."""

    name: str = "GetMemoryById"
    description: str = (
        "Retrieve a specific memory by its ID. Returns FULL content (not truncated), "
        "metadata, importance, unit type, creation date, and version info. "
        "Use this after QueryMemories to read the complete text of memories you need "
        "to analyze in depth — for EVOLVES detection, crystallization, or insight generation."
    )
    params: type[GetMemoryByIdParams] = GetMemoryByIdParams

    async def __call__(self, params: GetMemoryByIdParams) -> ToolReturnValue:
        deps = KnowledgeAgentDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Tools not configured", brief="Not ready")

        try:
            conn = deps.kuzu_client.conn
            result = conn.execute(
                """
                MATCH (m:Memory)
                WHERE m.id = $id
                RETURN m.id, m.title, m.content, m.unit_type, m.importance,
                       m.is_latest, m.is_crystal, m.created_at, m.source,
                       m.temporal_context, m.event_start, m.event_end
                """,
                {"id": params.memory_id},
            )

            if not result.has_next():
                return ToolError(
                    output="",
                    message=f"Memory not found: {params.memory_id}. Check the ID is correct — use QueryMemories to search if needed.",
                    brief="Not found",
                )

            row = result.get_next()

            # Safely convert datetime fields
            def _safe_dt(val):
                if val is None:
                    return None
                if isinstance(val, datetime):
                    return val.isoformat()
                return str(val)

            # Cap content at 2000 chars to stay within token budget
            content = row[2] or ""
            if len(content) > 2000:
                content = content[:2000] + "\n... (truncated at 2000 chars)"

            memory = {
                "id": row[0],
                "title": row[1],
                "content": content,
                "unit_type": row[3],
                "importance": float(row[4]) if row[4] is not None else 0.5,
                "is_latest": bool(row[5]) if row[5] is not None else True,
                "is_crystal": bool(row[6]) if row[6] is not None else False,
                "created_at": _safe_dt(row[7]),
                "source": row[8],
                "temporal_context": row[9],
                "event_start": _safe_dt(row[10]),
                "event_end": _safe_dt(row[11]),
            }

            return ToolOk(output=json.dumps(memory))

        except Exception as e:
            logger.error("GetMemoryById failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Fetch failed")
