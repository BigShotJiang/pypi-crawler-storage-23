"""Knowledge Agent Tools — kimi-cli compatible tools for background processing.

This package contains tools organized by function:
- query: QueryMemories, QueryMemoryNeighbors, QueryRecentActivity
- get_memory: GetMemoryById
- mutations: CreateEVOLVES, CreateCrystal, UpdateMemoryMeta
- insights: CreateInsight, FlagForReview
- reports: ReadDailyReport, SearchHistory, ListReports
- working_memory: ReadWorkingMemory, UpdateWorkingMemory, rotate_working_memory
- graph_jobs: RunCommunityDetection, RunKGExtraction
- communities: ListCommunities, GetCommunityDetails
- sources: QuerySources, GetSourceDetails, ListSources, DeleteSource
- threads: SearchThreads, FetchThreadMessages
"""

# Re-export everything for backward compatibility.
# All existing imports like `from .knowledge_tools import X` continue to work.

from ._base import (  # noqa: F401
    KnowledgeAgentDependencies,
    _get_time_partitioned_path,
    _iter_time_partitioned_files,
    _resync_memory_to_lancedb,
    _normalize_search_result,
    _get_search_score,
)

from .query import (  # noqa: F401
    QueryMemories,
    QueryMemoriesParams,
    QueryMemoryNeighbors,
    QueryMemoryNeighborsParams,
    QueryRecentActivity,
    QueryRecentActivityParams,
)

from .mutations import (  # noqa: F401
    CreateEVOLVES,
    CreateEVOLVESParams,
    CreateCrystal,
    CreateCrystalParams,
    UpdateMemoryMeta,
    UpdateMemoryMetaParams,
)

from .insights import (  # noqa: F401
    CreateInsight,
    CreateInsightParams,
    FlagForReview,
    FlagForReviewParams,
)

from .reports import (  # noqa: F401
    ReadDailyReport,
    ReadDailyReportParams,
    SearchHistory,
    SearchHistoryParams,
    ListReports,
    ListReportsParams,
)

from .get_memory import (  # noqa: F401
    GetMemoryById,
    GetMemoryByIdParams,
)

from .working_memory import (  # noqa: F401
    ReadWorkingMemory,
    ReadWorkingMemoryParams,
    UpdateWorkingMemory,
    UpdateWorkingMemoryParams,
    rotate_working_memory,
    _MAX_WORKING_MEMORY_BYTES,
)

from .graph_jobs import (  # noqa: F401
    RunCommunityDetection,
    RunCommunityDetectionParams,
    RunKGExtraction,
    RunKGExtractionParams,
)

from .communities import (  # noqa: F401
    ListCommunities,
    ListCommunitiesParams,
    GetCommunityDetails,
    GetCommunityDetailsParams,
)

from .sources import (  # noqa: F401
    QuerySources,
    QuerySourcesParams,
    GetSourceDetails,
    GetSourceDetailsParams,
    ListSources,
    ListSourcesParams,
    DeleteSource,
    DeleteSourceParams,
)

from .threads import (  # noqa: F401
    SearchThreads,
    SearchThreadsParams,
    FetchThreadMessages,
    FetchThreadMessagesParams,
)
