"""Knowledge Agent Tools — community query tools (list, details)."""

from __future__ import annotations

import json

from pydantic import BaseModel, Field

from ...database.result_utils import iter_rows, managed_result
from ._base import (
    KnowledgeAgentDependencies,
    CallableTool2, ToolError, ToolOk, ToolReturnValue,
    logger,
)


class ListCommunitiesParams(BaseModel):
    limit: int = Field(default=20, description="Maximum communities to return (default 20)")


class ListCommunities(CallableTool2):
    """List knowledge communities — clusters of related entities detected by community detection."""

    name: str = "ListCommunities"
    description: str = (
        "List knowledge communities — clusters of related entities found by "
        "community detection (Louvain algorithm). Each community has a name, "
        "AI-generated summary describing its theme, and a member count. "
        "Use for: 'what are my main themes?', 'what topics cluster together?', "
        "'what are my knowledge areas?', 'summarize my most connected topics'."
    )
    params: type[ListCommunitiesParams] = ListCommunitiesParams

    async def __call__(self, params: ListCommunitiesParams) -> ToolReturnValue:
        deps = KnowledgeAgentDependencies
        if deps.kuzu_client is None:
            return ToolError(output="", message="KuzuDB not configured", brief="Not ready")

        try:
            conn = deps.kuzu_client.conn
            limit = min(max(1, params.limit), 50)

            communities = []
            for row in iter_rows(conn.execute(
                """
                MATCH (c:Community)
                WHERE c.ai_summary IS NOT NULL AND c.ai_summary <> ''
                RETURN c.id, c.community_id, c.name, c.description, c.ai_summary, c.member_count
                ORDER BY c.member_count DESC
                LIMIT $limit
                """,
                {"limit": limit},
            )):
                communities.append({
                    "id": row[0],
                    "community_id": row[1],
                    "name": row[2],
                    "description": row[3] or "",
                    "summary": row[4] or "",
                    "member_count": row[5] or 0,
                })

            if not communities:
                return ToolOk(output=json.dumps({
                    "communities": [],
                    "total": 0,
                    "message": "No communities detected yet. Run RunCommunityDetection first to discover theme clusters.",
                }))

            return ToolOk(output=json.dumps({
                "communities": communities,
                "total": len(communities),
            }))

        except Exception as e:
            logger.error("ListCommunities failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Community listing failed")


class GetCommunityDetailsParams(BaseModel):
    community_id: str = Field(description="Community ID (UUID from ListCommunities results)")
    limit: int = Field(default=20, description="Maximum entities to return (default 20)")


class GetCommunityDetails(CallableTool2):
    """Get detailed information about a specific community: member entities and connected memories."""

    name: str = "GetCommunityDetails"
    description: str = (
        "Get details of a specific community: its member entities and connected memories. "
        "Pass a community ID (UUID) from ListCommunities results to see which entities "
        "belong to this theme cluster and which memories reference them. "
        "Use after ListCommunities to drill into a specific theme."
    )
    params: type[GetCommunityDetailsParams] = GetCommunityDetailsParams

    async def __call__(self, params: GetCommunityDetailsParams) -> ToolReturnValue:
        deps = KnowledgeAgentDependencies
        if deps.kuzu_client is None:
            return ToolError(output="", message="KuzuDB not configured", brief="Not ready")

        try:
            conn = deps.kuzu_client.conn
            limit = min(max(1, params.limit), 50)

            # Step 1: Look up community by UUID to get the Louvain community_id
            with managed_result(conn.execute(
                """
                MATCH (c:Community)
                WHERE c.id = $cid
                RETURN c.id, c.community_id, c.name, c.description, c.ai_summary, c.member_count
                """,
                {"cid": params.community_id},
            )) as result:
                if not result.has_next():
                    return ToolError(
                        output="", message=f"Community not found: {params.community_id}",
                        brief="Not found",
                    )

                row = result.get_next()
                community = {
                    "id": row[0],
                    "community_id": row[1],
                    "name": row[2],
                    "description": row[3] or "",
                    "summary": row[4] or "",
                    "member_count": row[5] or 0,
                }
                louvain_id = row[1]

            # Step 2: Find member entities via community_id property on Entity nodes
            entities = []
            for erow in iter_rows(conn.execute(
                """
                MATCH (e:Entity)
                WHERE e.community_id = $louvain_id
                OPTIONAL MATCH (m:Memory)-[:MENTIONS]->(e)
                RETURN e.id, e.name, e.entity_type, COUNT(m) AS memory_count
                ORDER BY memory_count DESC
                LIMIT $limit
                """,
                {"louvain_id": louvain_id, "limit": limit},
            )):
                entities.append({
                    "id": erow[0],
                    "name": erow[1],
                    "entity_type": erow[2],
                    "memory_count": erow[3],
                })

            # Step 3: Find sample memories connected to community entities
            sample_memories = []
            for mrow in iter_rows(conn.execute(
                """
                MATCH (e:Entity {community_id: $louvain_id})<-[:MENTIONS]-(m:Memory)
                WHERE m.is_crystal = false
                WITH m, COUNT(e) AS entity_count
                RETURN m.id, m.title, m.content, m.unit_type
                ORDER BY entity_count DESC, m.importance DESC
                LIMIT 5
                """,
                {"louvain_id": louvain_id},
            )):
                sample_memories.append({
                    "id": mrow[0],
                    "title": mrow[1],
                    "content_preview": (mrow[2] or "")[:200],
                    "unit_type": mrow[3],
                })

            return ToolOk(output=json.dumps({
                "community": community,
                "entities": entities,
                "sample_memories": sample_memories,
                "entity_count": len(entities),
                "memory_count": len(sample_memories),
            }))

        except Exception as e:
            logger.error("GetCommunityDetails failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Community details failed")
