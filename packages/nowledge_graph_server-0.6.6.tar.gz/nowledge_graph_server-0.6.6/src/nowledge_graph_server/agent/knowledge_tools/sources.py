"""Source (Library) tools for the Knowledge Agent.

QuerySources — search/filter sources in the library
GetSourceDetails — get full details of a specific source
ListSources — list all sources with summary info
DeleteSource — delete a source and all its artifacts
"""

from __future__ import annotations

import json
import structlog
from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field

from ._base import (
    KnowledgeAgentDependencies,
    CallableTool2, ToolError, ToolOk, ToolReturnValue,
)

logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# QuerySources
# ---------------------------------------------------------------------------


class QuerySourcesParams(BaseModel):
    query: Optional[str] = Field(
        default=None,
        description="Text query to search source names, summaries, and content.",
    )
    source_type: Optional[str] = Field(
        default=None,
        description="Filter by source type: 'file', 'url', 'obsidian_note'.",
    )
    lifecycle_state: Optional[str] = Field(
        default=None,
        description="Filter by lifecycle state: 'ingested', 'parsed', 'chunked', 'indexed', 'extracted', 'stale', 'error'.",
    )
    limit: int = Field(
        default=20,
        description="Maximum number of results. Default 20.",
    )


class QuerySources(CallableTool2):
    """Search and filter sources in the Library."""

    name: str = "QuerySources"
    description: str = (
        "Search the source library for files and URLs. Filter by source_type "
        "(file, url), lifecycle_state, or free-text query matching names and summaries. "
        "Returns source metadata, lifecycle state, and chunk/memory counts."
    )
    params: type[QuerySourcesParams] = QuerySourcesParams

    async def __call__(self, params: QuerySourcesParams) -> ToolReturnValue:
        deps = KnowledgeAgentDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Tools not configured", brief="Not ready")

        try:
            conn = deps.kuzu_client.conn
            limit = min(max(params.limit, 1), 50)

            conditions = []
            query_params: dict = {"limit": limit}

            if params.source_type:
                conditions.append("s.source_type = $source_type")
                query_params["source_type"] = params.source_type

            if params.lifecycle_state:
                conditions.append("s.lifecycle_state = $lifecycle_state")
                query_params["lifecycle_state"] = params.lifecycle_state

            if params.query:
                conditions.append(
                    "(s.original_name CONTAINS $query OR s.summary CONTAINS $query)"
                )
                query_params["query"] = params.query

            where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""

            query = f"""
                MATCH (s:Source)
                {where_clause}
                RETURN s.id, s.source_type, s.original_name, s.mime_type,
                       s.lifecycle_state, s.version, s.chunk_count, s.memory_count,
                       s.summary, s.source_url, s.created_at
                ORDER BY s.created_at DESC
                LIMIT $limit
            """

            result = conn.execute(query, query_params)
            sources = []
            while result.has_next():
                row = result.get_next()
                created_at = row[10]
                if isinstance(created_at, datetime):
                    created_at = created_at.isoformat()
                elif created_at is not None:
                    created_at = str(created_at)

                summary = row[8] or ""
                if len(summary) > 300:
                    summary = summary[:300] + "..."

                sources.append({
                    "id": row[0],
                    "source_type": row[1],
                    "original_name": row[2],
                    "mime_type": row[3],
                    "lifecycle_state": row[4],
                    "version": row[5],
                    "chunk_count": row[6],
                    "memory_count": row[7],
                    "summary": summary,
                    "source_url": row[9],
                    "created_at": created_at,
                })

            return ToolOk(output=json.dumps({
                "count": len(sources),
                "sources": sources,
            }))

        except Exception as e:
            logger.error("QuerySources failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Query failed")


# ---------------------------------------------------------------------------
# GetSourceDetails
# ---------------------------------------------------------------------------


class GetSourceDetailsParams(BaseModel):
    source_id: str = Field(description="ID of the source to retrieve (e.g. 'src_a1b2c3')")


class GetSourceDetails(CallableTool2):
    """Get full details of a specific source including related memories."""

    name: str = "GetSourceDetails"
    description: str = (
        "Get complete details of a source by ID: full metadata, summary, section tree, "
        "related memories (via SOURCED_FROM), and revision chain (via REVISED_AS). "
        "Use after QuerySources to drill into a specific source."
    )
    params: type[GetSourceDetailsParams] = GetSourceDetailsParams

    async def __call__(self, params: GetSourceDetailsParams) -> ToolReturnValue:
        deps = KnowledgeAgentDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Tools not configured", brief="Not ready")

        try:
            conn = deps.kuzu_client.conn

            # Get source node
            result = conn.execute(
                """
                MATCH (s:Source)
                WHERE s.id = $id
                RETURN s.id, s.source_type, s.original_name, s.mime_type,
                       s.file_path, s.parsed_path, s.source_url, s.sha256,
                       s.size_bytes, s.version, s.lifecycle_state,
                       s.chunk_count, s.memory_count, s.section_tree,
                       s.summary, s.error_message, s.created_at, s.updated_at
                """,
                {"id": params.source_id},
            )

            if not result.has_next():
                return ToolOk(output=json.dumps({
                    "error": f"Source not found: {params.source_id}",
                }))

            row = result.get_next()

            def _safe_dt(val):
                if val is None:
                    return None
                if isinstance(val, datetime):
                    return val.isoformat()
                return str(val)

            summary = row[14] or ""
            if len(summary) > 1000:
                summary = summary[:1000] + "... (truncated)"

            source = {
                "id": row[0],
                "source_type": row[1],
                "original_name": row[2],
                "mime_type": row[3],
                "file_path": row[4],
                "parsed_path": row[5],
                "source_url": row[6],
                "sha256": row[7],
                "size_bytes": row[8],
                "version": row[9],
                "lifecycle_state": row[10],
                "chunk_count": row[11],
                "memory_count": row[12],
                "section_tree": row[13],
                "summary": summary,
                "error_message": row[15],
                "created_at": _safe_dt(row[16]),
                "updated_at": _safe_dt(row[17]),
            }

            # Get related memories
            memories = []
            try:
                mem_result = conn.execute(
                    """
                    MATCH (m:Memory)-[r:SOURCED_FROM]->(s:Source {id: $source_id})
                    RETURN m.id, m.title, m.content, m.unit_type,
                           r.chunk_index, r.chunk_range
                    ORDER BY r.chunk_index ASC
                    LIMIT 30
                    """,
                    {"source_id": params.source_id},
                )
                while mem_result.has_next():
                    mrow = mem_result.get_next()
                    content = mrow[2] or ""
                    if len(content) > 200:
                        content = content[:200] + "..."
                    memories.append({
                        "id": mrow[0],
                        "title": mrow[1],
                        "content": content,
                        "unit_type": mrow[3],
                        "chunk_index": mrow[4],
                        "chunk_range": mrow[5],
                    })
            except Exception as e:
                logger.debug("Failed to query source memories", error=str(e))

            # Get revision chain
            revisions = []
            try:
                rev_result = conn.execute(
                    """
                    MATCH (s:Source {id: $source_id})-[:REVISED_AS*1..5]->(older:Source)
                    RETURN older.id, older.original_name, older.version,
                           older.lifecycle_state, older.created_at
                    ORDER BY older.version DESC
                    """,
                    {"source_id": params.source_id},
                )
                while rev_result.has_next():
                    rrow = rev_result.get_next()
                    revisions.append({
                        "id": rrow[0],
                        "original_name": rrow[1],
                        "version": rrow[2],
                        "lifecycle_state": rrow[3],
                        "created_at": _safe_dt(rrow[4]),
                    })
            except Exception as e:
                logger.debug("Failed to query revision chain", error=str(e))

            return ToolOk(output=json.dumps({
                "source": source,
                "memories": memories,
                "memory_count": len(memories),
                "revisions": revisions,
            }))

        except Exception as e:
            logger.error("GetSourceDetails failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Fetch failed")


# ---------------------------------------------------------------------------
# ListSources
# ---------------------------------------------------------------------------


class ListSourcesParams(BaseModel):
    limit: int = Field(
        default=30,
        description="Maximum number of sources to return. Default 30.",
    )


class ListSources(CallableTool2):
    """List all sources in the Library with summary info."""

    name: str = "ListSources"
    description: str = (
        "List all sources in the Library, sorted by newest first. "
        "Returns ID, name, type, lifecycle state, and counts for each source. "
        "Use this for a quick overview of what's in the library."
    )
    params: type[ListSourcesParams] = ListSourcesParams

    async def __call__(self, params: ListSourcesParams) -> ToolReturnValue:
        deps = KnowledgeAgentDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Tools not configured", brief="Not ready")

        try:
            conn = deps.kuzu_client.conn
            limit = min(max(params.limit, 1), 100)

            result = conn.execute(
                """
                MATCH (s:Source)
                RETURN s.id, s.source_type, s.original_name, s.mime_type,
                       s.lifecycle_state, s.version, s.chunk_count, s.memory_count,
                       s.created_at
                ORDER BY s.created_at DESC
                LIMIT $limit
                """,
                {"limit": limit},
            )

            sources = []
            while result.has_next():
                row = result.get_next()
                created_at = row[8]
                if isinstance(created_at, datetime):
                    created_at = created_at.isoformat()
                elif created_at is not None:
                    created_at = str(created_at)

                sources.append({
                    "id": row[0],
                    "source_type": row[1],
                    "original_name": row[2],
                    "mime_type": row[3],
                    "lifecycle_state": row[4],
                    "version": row[5],
                    "chunk_count": row[6],
                    "memory_count": row[7],
                    "created_at": created_at,
                })

            # Also get total count
            count_result = conn.execute("MATCH (s:Source) RETURN COUNT(s)")
            total = count_result.get_next()[0] if count_result.has_next() else len(sources)

            return ToolOk(output=json.dumps({
                "total": total,
                "returned": len(sources),
                "sources": sources,
            }))

        except Exception as e:
            logger.error("ListSources failed", error=str(e))
            return ToolError(output="", message=str(e), brief="List failed")


# ---------------------------------------------------------------------------
# DeleteSource
# ---------------------------------------------------------------------------


class DeleteSourceParams(BaseModel):
    source_id: str = Field(description="ID of the source to delete (e.g. 'src_a1b2c3')")


class DeleteSource(CallableTool2):
    """Delete a source from the Library and clean up all related artifacts."""

    name: str = "DeleteSource"
    description: str = (
        "Permanently delete a source from the Library. Removes the source's search index "
        "records, filesystem artifacts (raw files, parsed markdown, images), graph node and "
        "relationships (SOURCED_FROM, REVISED_AS). Memories linked via SOURCED_FROM lose "
        "their source link but are NOT deleted. Use QuerySources or GetSourceDetails first "
        "to confirm the source ID before deleting."
    )
    params: type[DeleteSourceParams] = DeleteSourceParams

    async def __call__(self, params: DeleteSourceParams) -> ToolReturnValue:
        deps = KnowledgeAgentDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Tools not configured", brief="Not ready")

        try:
            # 1. Verify source exists
            source = await deps.kuzu_client.source_repo.get_source(params.source_id)
            if not source:
                return ToolOk(output=json.dumps({
                    "error": f"Source not found: {params.source_id}",
                }))

            source_name = source.original_name

            # 2. Delete from search index
            try:
                from ...services.search_index.source_sync import delete_source_from_index

                await delete_source_from_index(params.source_id)
            except Exception as e:
                logger.warning("Failed to delete source from search index", source_id=params.source_id, error=str(e))

            # 3. Delete filesystem artifacts
            try:
                from ...services.source_storage import SourceStorageService

                storage = SourceStorageService()
                storage.delete_source_dir(params.source_id)
            except Exception as e:
                logger.warning("Failed to delete source files", source_id=params.source_id, error=str(e))

            # 4. Delete from graph (node + relationships)
            await deps.kuzu_client.source_repo.delete_source(params.source_id)

            # 5. Emit feed event (for timeline) + data change (for Library refresh)
            from ...utils.feed_events import emit_feed_event
            from ...utils.progress_logger import log_data_change

            emit_feed_event(
                event_type="source_deleted",
                title=f"Source deleted: {source_name}",
                description=f"Source '{source_name}' ({params.source_id}) deleted by agent",
                metadata={"name": source_name, "source_id": params.source_id},
            )
            log_data_change(
                change_type="source_deleted",
                entity_type="source",
                entity_id=params.source_id,
                details={"name": source_name},
            )

            logger.info("DeleteSource succeeded", source_id=params.source_id, name=source_name)

            return ToolOk(output=json.dumps({
                "success": True,
                "source_id": params.source_id,
                "source_name": source_name,
                "message": f"Source '{source_name}' deleted successfully",
            }))

        except Exception as e:
            logger.error("DeleteSource failed", source_id=params.source_id, error=str(e))
            return ToolError(output="", message=str(e), brief="Delete failed")
