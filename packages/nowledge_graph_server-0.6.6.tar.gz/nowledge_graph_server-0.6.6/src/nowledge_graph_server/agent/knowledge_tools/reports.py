"""Report archive tools for the Knowledge Agent."""

from __future__ import annotations

import json
import structlog
from datetime import datetime, timezone, timedelta
from typing import Optional
from pydantic import BaseModel, Field

from ._base import (
    KnowledgeAgentDependencies,
    CallableTool2, ToolError, ToolOk, ToolReturnValue,
    _get_time_partitioned_path, _iter_time_partitioned_files,
)

logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# ReadDailyReport
# ---------------------------------------------------------------------------

class ReadDailyReportParams(BaseModel):
    date: Optional[str] = Field(default=None, description="Date in YYYY-MM-DD format")
    days_ago: Optional[int] = Field(default=None, description="Days ago (0=today)")


class ReadDailyReport(CallableTool2):
    """Read a daily activity report from the archive."""

    name: str = "ReadDailyReport"
    description: str = (
        "Read a daily activity report from the archive. "
        "Reports contain summaries of agent activity and past decisions. "
        "Use this to recall what happened on a specific day."
    )
    params: type[ReadDailyReportParams] = ReadDailyReportParams

    async def __call__(self, params: ReadDailyReportParams) -> ToolReturnValue:
        deps = KnowledgeAgentDependencies
        if deps.reports_dir is None:
            return ToolError(output="", message="Reports dir not configured", brief="Not ready")

        if params.date:
            target = datetime.strptime(params.date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
            date_str = params.date
        elif params.days_ago is not None:
            target = datetime.now(timezone.utc) - timedelta(days=params.days_ago)
            date_str = target.strftime("%Y-%m-%d")
        else:
            target = datetime.now(timezone.utc)
            date_str = target.strftime("%Y-%m-%d")

        report_path = _get_time_partitioned_path(deps.reports_dir, target, "md")

        if not report_path.exists():
            available = [
                f.stem for f in _iter_time_partitioned_files(deps.reports_dir, "md", last_n_days=90)
            ][:10]
            return ToolOk(output=json.dumps({
                "error": f"No report for {date_str}",
                "available_dates": available,
            }))

        try:
            content = report_path.read_text(encoding="utf-8")
            if len(content) > 6000:
                content = content[:6000] + "\n\n... (truncated)"

            return ToolOk(output=json.dumps({"date": date_str, "content": content}))
        except Exception as e:
            return ToolError(output="", message=str(e), brief="Read failed")


# ---------------------------------------------------------------------------
# SearchHistory
# ---------------------------------------------------------------------------

class SearchHistoryParams(BaseModel):
    pattern: str = Field(description="Text pattern to search (case-insensitive)")
    max_results: int = Field(default=10, description="Max matching lines to return")
    last_n_days: int = Field(default=14, description="Search only the last N days")


class SearchHistory(CallableTool2):
    """Search across archived daily reports."""

    name: str = "SearchHistory"
    description: str = (
        "Search across archived daily reports for a text pattern. "
        "Returns matching lines with file and line context."
    )
    params: type[SearchHistoryParams] = SearchHistoryParams

    async def __call__(self, params: SearchHistoryParams) -> ToolReturnValue:
        deps = KnowledgeAgentDependencies
        if deps.reports_dir is None:
            return ToolError(output="", message="Reports dir not configured", brief="Not ready")

        pattern_lower = params.pattern.lower()
        matches = []

        for report_file in _iter_time_partitioned_files(
            deps.reports_dir, "md", last_n_days=params.last_n_days
        ):
            try:
                content = report_file.read_text(encoding="utf-8")
                for i, line in enumerate(content.split("\n"), 1):
                    if pattern_lower in line.lower():
                        matches.append({
                            "file": report_file.stem,
                            "line": i,
                            "text": line[:200],
                        })
                        if len(matches) >= params.max_results:
                            break
            except Exception:
                continue

            if len(matches) >= params.max_results:
                break

        return ToolOk(output=json.dumps({
            "pattern": params.pattern,
            "match_count": len(matches),
            "matches": matches,
        }))


# ---------------------------------------------------------------------------
# ListReports
# ---------------------------------------------------------------------------

class ListReportsParams(BaseModel):
    last_n_days: int = Field(default=30, description="List reports from last N days")


class ListReports(CallableTool2):
    """List available daily reports."""

    name: str = "ListReports"
    description: str = "List available daily reports with their dates."
    params: type[ListReportsParams] = ListReportsParams

    async def __call__(self, params: ListReportsParams) -> ToolReturnValue:
        deps = KnowledgeAgentDependencies
        if deps.reports_dir is None:
            return ToolError(output="", message="Reports dir not configured", brief="Not ready")

        files = _iter_time_partitioned_files(
            deps.reports_dir, "md", last_n_days=params.last_n_days
        )

        reports = [{"date": f.stem, "path": str(f)} for f in files]

        return ToolOk(output=json.dumps({
            "count": len(reports),
            "reports": reports,
        }))
