"""Feed timeline tools for the Knowledge Agent (insights and flags)."""

from __future__ import annotations

import json
import uuid
import structlog
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field, field_validator, model_validator

from ...utils.feed_events import emit_feed_event
from ._base import (
    KnowledgeAgentDependencies,
    CallableTool2, ToolError, ToolOk, ToolReturnValue,
)

logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# CreateInsight
# ---------------------------------------------------------------------------

_VALID_INSIGHT_TYPES = {"pattern", "connection", "recommendation", "daily_briefing"}
_VALID_PRIORITIES = {"low", "normal", "high"}


class CreateInsightParams(BaseModel):
    insight_type: str = Field(
        description="Type: pattern|connection|recommendation|daily_briefing"
    )
    title: str = Field(description="Brief title for the insight")
    content: str = Field(description="The insight content")
    related_memory_ids: Optional[List[str]] = Field(
        default=None, description="Optional related memory IDs"
    )
    priority: str = Field(default="normal", description="Priority: low|normal|high")
    metadata_json: Optional[str] = Field(
        default=None,
        description="Optional JSON string with extra event-specific data (e.g. for daily briefings: "
        '{"insights": [...], "crystals": [...], "flags": [...], "memories_analyzed": 42})',
    )

    @field_validator("metadata_json", mode="before")
    @classmethod
    def coerce_dict_to_json_string(cls, v: Any) -> Any:
        """LLMs often pass a dict object instead of a JSON string. Serialize it."""
        if isinstance(v, dict):
            return json.dumps(v)
        return v

    @field_validator("related_memory_ids", mode="before")
    @classmethod
    def coerce_string_to_list(cls, v: Any) -> Any:
        """LLMs often pass JSON-encoded strings instead of arrays. Parse them."""
        if isinstance(v, str):
            try:
                parsed = json.loads(v)
                if isinstance(parsed, list):
                    return parsed
            except (json.JSONDecodeError, TypeError):
                pass
            # Plain string like "mem_123" → wrap in list
            if v.strip():
                return [v.strip()]
            return None
        return v

    @field_validator("insight_type")
    @classmethod
    def validate_insight_type(cls, v: str) -> str:
        if v not in _VALID_INSIGHT_TYPES:
            raise ValueError(f"insight_type must be one of {_VALID_INSIGHT_TYPES}, got '{v}'")
        return v

    @field_validator("priority")
    @classmethod
    def validate_priority(cls, v: str) -> str:
        if v not in _VALID_PRIORITIES:
            raise ValueError(f"priority must be one of {_VALID_PRIORITIES}, got '{v}'")
        return v


class CreateInsight(CallableTool2):
    """Create an insight to be shown in the Feed timeline."""

    name: str = "CreateInsight"
    description: str = (
        "Create an insight for the user's Feed timeline. "
        "Insights are observations about patterns, connections, "
        "or recommendations based on the knowledge graph. "
        "They should be actionable and specific."
    )
    params: type[CreateInsightParams] = CreateInsightParams

    async def __call__(self, params: CreateInsightParams) -> ToolReturnValue:
        deps = KnowledgeAgentDependencies
        if deps.events_dir is None:
            return ToolError(output="", message="Events dir not configured", brief="Not ready")

        try:
            insight_id = f"insight_{uuid.uuid4().hex[:8]}"

            # Map insight_type to event_type for frontend mapping
            insight_type_to_event_type = {
                "pattern": "pattern_detected",
                "connection": "insight_generated",
                "recommendation": "agent_observation",
                "daily_briefing": "daily_briefing",
            }
            event_type = insight_type_to_event_type.get(params.insight_type, "insight_generated")

            # Map priority to severity
            priority_to_severity = {
                "low": "info",
                "normal": "info",
                "high": "warning",
            }
            severity = priority_to_severity.get(params.priority, "info")

            # Build metadata -- merge in custom metadata_json if provided
            metadata: Dict[str, Any] = {
                "insight_type": params.insight_type,
                "priority": params.priority,
            }
            if params.metadata_json:
                try:
                    extra = json.loads(params.metadata_json)
                    if isinstance(extra, dict):
                        metadata.update(extra)
                except (json.JSONDecodeError, TypeError):
                    pass

            # --- Quality gates (defense-in-depth) ---

            # Gate 1: Suppress empty daily briefings — silence is better than noise
            if params.insight_type == "daily_briefing":
                insights = metadata.get("insights", [])
                crystals = metadata.get("crystals", [])
                flags = metadata.get("flags", [])
                if not insights and not crystals and not flags:
                    logger.info("Suppressing empty daily briefing — no findings")
                    return ToolOk(output=json.dumps({
                        "success": True,
                        "skipped": True,
                        "reason": "No findings to report — briefing suppressed",
                    }))

            # Gate 2: Non-briefing insights must reference real memories
            if params.insight_type != "daily_briefing":
                if not params.related_memory_ids or len(params.related_memory_ids) == 0:
                    logger.info(
                        "Rejecting insight without evidence — no related_memory_ids",
                        type=params.insight_type,
                        title=params.title,
                    )
                    return ToolOk(output=json.dumps({
                        "success": True,
                        "skipped": True,
                        "reason": "Insights must reference specific memories (related_memory_ids). "
                        "An insight without evidence is noise.",
                    }))

            # Gate 3: Content must be substantive (not just a title restatement)
            if len(params.content.strip()) < 30:
                logger.info(
                    "Rejecting insight with trivial content",
                    type=params.insight_type,
                    content_len=len(params.content),
                )
                return ToolOk(output=json.dumps({
                    "success": True,
                    "skipped": True,
                    "reason": "Insight content too brief (<30 chars). Provide substantive detail.",
                }))

            emit_feed_event(
                event_type,
                title=params.title,
                description=params.content,
                severity=severity,
                related_memory_ids=params.related_memory_ids,
                metadata=metadata,
                event_id=insight_id,
                write_report=True,
            )

            logger.info("Created insight", insight_id=insight_id, type=params.insight_type)

            return ToolOk(output=json.dumps({
                "success": True,
                "insight_id": insight_id,
                "insight_type": params.insight_type,
            }))

        except Exception as e:
            logger.error("CreateInsight failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Insight creation failed")


# ---------------------------------------------------------------------------
# FlagForReview
# ---------------------------------------------------------------------------

_VALID_FLAG_TYPES = {"contradiction", "stale", "merge_candidate", "review"}


class FlagForReviewParams(BaseModel):
    memory_ids: List[str] = Field(
        description="IDs of the memories to flag (for contradictions, provide both conflicting memories)"
    )
    flag_type: str = Field(
        description="Type: contradiction|stale|merge_candidate|review"
    )
    reason: str = Field(description="Why this needs user review")

    @field_validator("memory_ids", mode="before")
    @classmethod
    def coerce_string_to_list(cls, v: Any) -> Any:
        """LLMs often pass JSON-encoded strings instead of arrays. Parse them."""
        if isinstance(v, str):
            try:
                parsed = json.loads(v)
                if isinstance(parsed, list):
                    return parsed
            except (json.JSONDecodeError, TypeError):
                pass
            if v.strip():
                return [v.strip()]
        return v

    @field_validator("flag_type")
    @classmethod
    def validate_flag_type(cls, v: str) -> str:
        if v not in _VALID_FLAG_TYPES:
            raise ValueError(f"flag_type must be one of {_VALID_FLAG_TYPES}, got '{v}'")
        return v


class FlagForReview(CallableTool2):
    """Flag a memory for user review."""

    name: str = "FlagForReview"
    description: str = (
        "Flag memories for user review. Only use this for actual Memory nodes "
        "in the graph — never for insights, feed events, or briefings. "
        "Use when you detect: contradictions (provide BOTH conflicting memory IDs), "
        "stale info (>90 days old), merge candidates (near-duplicate memories), "
        "or items needing general review. "
        "For contradictions, content snippets are auto-fetched for side-by-side display."
    )
    params: type[FlagForReviewParams] = FlagForReviewParams

    async def __call__(self, params: FlagForReviewParams) -> ToolReturnValue:
        deps = KnowledgeAgentDependencies
        if deps.events_dir is None:
            return ToolError(output="", message="Events dir not configured", brief="Not ready")

        try:
            flag_id = f"flag_{uuid.uuid4().hex[:8]}"

            # Map flag_type to event_type for frontend mapping
            flag_type_to_event_type = {
                "contradiction": "flag_contradiction",
                "stale": "flag_stale",
                "merge_candidate": "flag_merge_candidate",
                "review": "flag_review",
            }
            event_type = flag_type_to_event_type.get(params.flag_type, "flag_review")

            metadata: Dict[str, Any] = {
                "memory_ids": params.memory_ids,
                "flag_type": params.flag_type,
            }

            # For contradictions, fetch content snippets for side-by-side comparison
            if params.flag_type == "contradiction" and deps.kuzu_client and len(params.memory_ids) >= 2:
                snippets: List[Dict[str, str]] = []
                try:
                    from ...database.result_utils import managed_result
                    conn = deps.kuzu_client.conn
                    for mid in params.memory_ids[:2]:
                        with managed_result(conn.execute(
                            "MATCH (m:Memory) WHERE m.id = $id RETURN m.title, m.content, m.created_at",
                            {"id": mid},
                        )) as row:
                            if row.has_next():
                                r = row.get_next()
                                snippets.append({
                                    "id": mid,
                                    "title": str(r[0] or ""),
                                    "content": str(r[1] or "")[:200],
                                    "date": str(r[2] or "")[:10],
                                })
                    if snippets:
                        metadata["content_snippets"] = snippets
                except Exception:
                    pass  # Snippets are best-effort

            emit_feed_event(
                event_type,
                title=f"Review: {params.flag_type.replace('_', ' ').title()}",
                description=params.reason,
                severity="action_required",
                related_memory_ids=params.memory_ids,
                metadata=metadata,
                event_id=flag_id,
            )

            logger.info("Created flag", flag_id=flag_id, memory_ids=params.memory_ids)

            return ToolOk(output=json.dumps({
                "success": True,
                "flag_id": flag_id,
                "memory_ids": params.memory_ids,
                "flag_type": params.flag_type,
            }))

        except Exception as e:
            logger.error("FlagForReview failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Flag creation failed")
