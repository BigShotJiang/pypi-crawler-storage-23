"""Background graph job tools for the Knowledge Agent.

These tools allow the Knowledge Agent (or Feed Agent) to trigger
compute-heavy graph operations that run as direct Python functions
(not LLM-mediated tasks).
"""

from __future__ import annotations

import json
from typing import Any, List, Optional

import structlog
from pydantic import BaseModel, Field, field_validator

from ._base import CallableTool2, ToolError, ToolOk, ToolReturnValue

logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# RunCommunityDetection
# ---------------------------------------------------------------------------

class RunCommunityDetectionParams(BaseModel):
    resolution: float = Field(
        default=1.0,
        description="Resolution parameter for Louvain algorithm. Higher values = more, smaller communities. Default: 1.0",
    )
    generate_ai_summary: bool = Field(
        default=True,
        description="Whether to generate LLM summaries for each community. Default: true",
    )


class RunCommunityDetection(CallableTool2):
    """Trigger background community detection on the entity knowledge graph."""

    name: str = "RunCommunityDetection"
    description: str = (
        "Trigger community detection on the entity knowledge graph. "
        "Uses Louvain algorithm to find clusters of related entities, "
        "then optionally generates LLM summaries for each community. "
        "Returns immediately — detection runs in background. "
        "Results appear as a feed event when complete."
    )
    params: type[RunCommunityDetectionParams] = RunCommunityDetectionParams

    async def __call__(self, params: RunCommunityDetectionParams) -> ToolReturnValue:
        try:
            from ..manager import get_agent_manager
            from ..scheduler import AgentTask, TaskPriority

            manager = get_agent_manager()
            if not manager or not manager.is_running:
                return ToolError(output="", message="Knowledge Agent not running", brief="Not running")

            task = AgentTask(
                task_type="community_detection",
                prompt="",
                priority=TaskPriority.HIGH,
                metadata={
                    "resolution": params.resolution,
                    "generate_ai_summary": params.generate_ai_summary,
                    "max_iterations": 100,
                },
            )
            await manager._scheduler.submit_task(task)

            return ToolOk(
                output=f"Community detection queued (resolution={params.resolution}, summaries={'on' if params.generate_ai_summary else 'off'}). "
                "Results will appear as a feed event when complete.",
            )

        except Exception as e:
            logger.error("Failed to queue community detection", error=str(e))
            return ToolError(output="", message=str(e), brief="Queue failed")


# ---------------------------------------------------------------------------
# RunKGExtraction
# ---------------------------------------------------------------------------

class RunKGExtractionParams(BaseModel):
    memory_ids: Optional[List[str]] = Field(
        default=None,
        description=(
            "Specific memory IDs to extract entities from. "
            "If omitted, runs backfill for ALL un-extracted memories (up to 50)."
        ),
    )

    @field_validator("memory_ids", mode="before")
    @classmethod
    def coerce_string_to_list(cls, v: Any) -> Any:
        """LLMs often pass JSON-encoded strings instead of arrays. Parse them."""
        if isinstance(v, str):
            try:
                parsed = json.loads(v)
                if isinstance(parsed, list):
                    return parsed
            except (json.JSONDecodeError, TypeError):
                pass
            if v.strip():
                return [v.strip()]
            return None
        return v


class RunKGExtraction(CallableTool2):
    """Extract entities and relationships from memories into the knowledge graph."""

    name: str = "RunKGExtraction"
    description: str = (
        "Extract entities and relationships from memories into the knowledge graph. "
        "Provide specific memory_ids to extract from those memories, "
        "or omit to backfill all un-extracted memories (up to 50 per run). "
        "Uses the remote LLM for entity extraction with deduplication. "
        "Returns immediately — extraction runs in background."
    )
    params: type[RunKGExtractionParams] = RunKGExtractionParams

    async def __call__(self, params: RunKGExtractionParams) -> ToolReturnValue:
        try:
            from ..manager import get_agent_manager
            from ..scheduler import AgentTask, TaskPriority

            manager = get_agent_manager()
            if not manager or not manager.is_running:
                return ToolError(output="", message="Knowledge Agent not running", brief="Not running")

            if params.memory_ids:
                task_type = "kg_extraction"
                metadata = {"memory_ids": params.memory_ids}
                desc = f"KG extraction queued for {len(params.memory_ids)} specific memories."
            else:
                task_type = "kg_extraction_backfill"
                metadata = {}
                desc = "KG extraction backfill queued (up to 50 un-extracted memories)."

            task = AgentTask(
                task_type=task_type,
                prompt="",
                priority=TaskPriority.HIGH,
                metadata=metadata,
            )
            await manager._scheduler.submit_task(task)

            return ToolOk(
                output=f"{desc} Results will appear as a feed event when complete.",
            )

        except Exception as e:
            logger.error("Failed to queue KG extraction", error=str(e))
            return ToolError(output="", message=str(e), brief="Queue failed")
