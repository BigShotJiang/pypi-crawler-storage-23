"""Feed timeline builder — recent activity for Feed Agent context injection.

Extracted from context_helpers.py to stay under pyarmor's 1000-line limit.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from nowledge_graph_server.utils.time_partitioning import (
    _iter_time_partitioned_files,
)


def build_recent_feed_timeline(
    events_dir: Optional[Path], *, max_events: int = 20
) -> str:
    """Build a compact recent timeline from feed events for context injection.

    Returns a formatted block showing the user's last few interactions
    (captures, questions, sources) so the Feed Agent has situational
    awareness even after session restart or compaction.

    Used by the Feed Agent's context anchor (Option B of A+B hybrid).
    """
    if events_dir is None:
        return ""

    _TIMELINE_EVENT_TYPES = {
        "memory_created",
        "user_question",
        "source_ingested",
        "source_created",
        "source_deleted",
        "task_scheduled",
        "flag_contradiction",
        "flag_needs_verification",
    }

    # Use 2 days to avoid losing continuity at midnight (e.g. 11 PM → 1 AM)
    files = _iter_time_partitioned_files(events_dir, "jsonl", last_n_days=2)
    events: List[Dict[str, Any]] = []
    for f in files:
        try:
            lines = f.read_text(encoding="utf-8").strip().splitlines()
        except Exception:
            continue
        for line in reversed(lines):
            try:
                evt = json.loads(line)
                if evt.get("event_type", "") in _TIMELINE_EVENT_TYPES:
                    events.append(evt)
                    if len(events) >= max_events:
                        break
            except (json.JSONDecodeError, KeyError):
                continue
        if len(events) >= max_events:
            break

    if not events:
        return ""

    out: List[str] = ["[RECENT TIMELINE]"]
    for evt in reversed(events):  # chronological order
        ts = evt.get("created_at", "")[:16]  # YYYY-MM-DDTHH:MM
        title = evt.get("title", "")[:80]
        et = evt.get("event_type", "")
        meta = evt.get("metadata") or {}
        if isinstance(meta, str):
            try:
                meta = json.loads(meta)
            except (json.JSONDecodeError, ValueError):
                meta = {}

        if et == "memory_created":
            unit = meta.get("unit_type", "")
            out.append(f"- [{ts}] Captured: {title} ({unit})")
        elif et == "user_question":
            q = meta.get("question", title)[:80]
            out.append(f"- [{ts}] Asked: {q}")
        elif et in ("source_ingested", "source_created"):
            name = meta.get("original_name", title)[:60]
            state = meta.get("lifecycle_state", "")
            sid = meta.get("source_id", "")
            id_str = f" id:{sid}" if sid else ""
            out.append(f"- [{ts}] Source: {name} ({state}{id_str})")
        elif et == "source_deleted":
            name = meta.get("name", title)[:60]
            out.append(f"- [{ts}] Deleted source: {name}")
        elif et == "task_scheduled":
            out.append(f"- [{ts}] Scheduled: {title}")
        elif et.startswith("flag_"):
            out.append(f"- [{ts}] Flag: {title}")

    out.append("")
    out.append(
        "Use this timeline to understand recent context. "
        "For older history, use ReadDailyReport/SearchHistory."
    )
    return "\n".join(out)
