"""Kimi-CLI Config Generator.

Generates kimi-agent-sdk compatible config.json from RemoteLLMConfigManager.

This allows the Feed Agent to consume LLM config directly from the Python side,
without depending on TypeScript config sync (which is used for AI-Now/ACP).

Architecture difference:
- AI-Now: Uses ACP, spawns kimi-cli script from UI, TypeScript syncs config
- Feed Agent: Runs in Python backend, should consume config from Python side
"""

from __future__ import annotations

import json
import re
import os
from pathlib import Path
from typing import Any, Dict, Literal, Optional

import structlog

from .paths import get_builtin_agents_home
from nowledge_graph_server.services.litellm.constants import OPENAI_CODEX_API_BASE_URL

logger = structlog.get_logger(__name__)


# =============================================================================
# Type definitions (matching kimi-cli config.py structure)
# =============================================================================

KimiProviderType = Literal[
    "kimi", "openai_legacy", "openai_responses", "anthropic", "google_genai"
]


# =============================================================================
# Provider Type Mapping (ported from TypeScript kimi-config.ts)
# =============================================================================


def _map_provider_type(
    provider: str, base_url: Optional[str] = None, model_name: Optional[str] = None
) -> KimiProviderType:
    """Map our provider type to kimi-cli provider type."""
    provider_lower = provider.lower()
    base_url_lower = (base_url or "").lower()
    model_lower = (model_name or "").lower()
    is_kimi_family_model = model_lower.startswith("kimi") or "/kimi" in model_lower

    # Kimi coding-plan endpoint follows Anthropic/Claude-style API contract.
    if provider_lower == "moonshot" and "api.kimi.com/coding" in base_url_lower:
        return "anthropic"
    # MiniMax also exposes Anthropic-compatible endpoints.
    if provider_lower == "minimax" and "/anthropic" in base_url_lower:
        return "anthropic"

    # Use native kimi provider only for Kimi-family models.
    # Moonshot non-Kimi models should remain OpenAI-compatible.
    if provider_lower == "kimi" or (
        is_kimi_family_model
        and any(
            domain in base_url_lower
            for domain in ["moonshot.cn", "moonshot.ai", "kimi.ai"]
        )
    ):
        return "kimi"

    mapping: Dict[str, KimiProviderType] = {
        "anthropic": "anthropic",
        "openai": "openai_responses",  # Use Responses API for native OpenAI
        "xai": "openai_responses",  # xAI uses OpenAI Responses API
        "openrouter": "openai_legacy",
        "openai_compatible": "openai_legacy",
        "azure": "openai_legacy",
        "ollama": "openai_legacy",
        "groq": "openai_legacy",
        "deepseek": "openai_legacy",
        "minimax": "openai_legacy",
        "zai": "openai_legacy",
        "moonshot": "openai_legacy",
        "google": "google_genai",
        "gemini": "google_genai",
        "github_copilot": "openai_legacy",
        "openai_codex": "openai_responses",
    }

    return mapping.get(provider_lower, "openai_legacy")


def _get_default_base_url(provider: str) -> str:
    """Get default base URL for a provider."""
    provider_lower = provider.lower()

    urls: Dict[str, str] = {
        "anthropic": "https://api.anthropic.com",
        "openai": "https://api.openai.com/v1",
        "openrouter": "https://openrouter.ai/api/v1",
        "groq": "https://api.groq.com/openai/v1",
        "together": "https://api.together.xyz/v1",
        "fireworks": "https://api.fireworks.ai/inference/v1",
        "deepinfra": "https://api.deepinfra.com/v1/openai",
        "ollama": "http://127.0.0.1:11434/v1",
        "xai": "https://api.x.ai/v1",
        "deepseek": "https://api.deepseek.com/v1",
        "minimax": "https://api.minimax.io/anthropic",
        "zai": "https://api.z.ai/api/paas/v4",
        "moonshot": "https://api.moonshot.ai/v1",
        "gemini": "https://generativelanguage.googleapis.com",
        "google": "https://generativelanguage.googleapis.com",
        "github_copilot": "https://api.individual.githubcopilot.com",
        "openai_codex": "https://chatgpt.com/backend-api/codex",
    }

    return urls.get(provider_lower, "https://api.openai.com/v1")


def _get_default_context_size(model: str) -> int:
    """Get default context size for a model."""
    model_lower = model.lower()

    if "claude" in model_lower:
        return 200000
    if "gpt-4" in model_lower:
        return 128000
    if "grok" in model_lower:
        return 131072
    if "llama" in model_lower:
        return 128000
    if "kimi" in model_lower:
        return 131072

    return 128000  # Safe default


def _normalize_provider_type(provider_type: str) -> str:
    """Normalize provider_type (strip multi-instance suffixes like openai_compatible:foo)."""
    normalized = provider_type.strip().lower()
    if ":" in normalized:
        normalized = normalized.split(":", 1)[0]
    return normalized


def _resolve_copilot_credentials(config_root: Path) -> tuple[Optional[str], Optional[str]]:
    """Resolve GitHub Copilot API token + endpoint from token cache."""
    from nowledge_graph_server.services.litellm.env import (
        setup_github_copilot_env,
        check_copilot_authenticated,
    )

    old_env = {
        "GITHUB_COPILOT_TOKEN_DIR": os.environ.get("GITHUB_COPILOT_TOKEN_DIR"),
        "GITHUB_COPILOT_ACCESS_TOKEN_FILE": os.environ.get("GITHUB_COPILOT_ACCESS_TOKEN_FILE"),
        "GITHUB_COPILOT_API_KEY_FILE": os.environ.get("GITHUB_COPILOT_API_KEY_FILE"),
    }

    try:
        token_dir = setup_github_copilot_env(config_root)
        if not token_dir or not check_copilot_authenticated(token_dir):
            return None, None

        # Refresh API token to ensure it's fresh
        try:
            from litellm.llms.github_copilot.authenticator import Authenticator  # type: ignore

            auth = Authenticator()
            _ = auth.get_api_key()
        except Exception as e:
            logger.warning("Copilot token refresh failed", error=str(e))

        api_key_path = Path(token_dir) / os.environ.get(
            "GITHUB_COPILOT_API_KEY_FILE", "api-key.json"
        )
        if not api_key_path.exists():
            return None, None

        with api_key_path.open("r", encoding="utf-8") as f:
            data = json.load(f) or {}

        api_key = data.get("token") if isinstance(data, dict) else None
        api_base = None
        endpoints = data.get("endpoints") if isinstance(data, dict) else None
        if isinstance(endpoints, dict):
            api_base = endpoints.get("api")

        if isinstance(api_key, str):
            api_key = api_key.strip()
        if not api_key:
            return None, None

        return api_key, api_base
    finally:
        for key, value in old_env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value


def _resolve_codex_credentials(config_root: Path) -> Optional[str]:
    """Resolve OpenAI Codex access token from token cache (refresh if needed)."""
    from nowledge_graph_server.services.litellm.env import (
        setup_openai_codex_env,
        check_codex_authenticated,
        get_codex_access_token,
    )

    token_dir = setup_openai_codex_env(config_root)
    if not token_dir or not check_codex_authenticated(token_dir):
        return None

    return get_codex_access_token(token_dir)


def _transform_model_for_kimi(model: str, provider: str) -> str:
    """Transform LiteLLM model names to raw model names for kimi-cli.

    LiteLLM uses prefixed model names like "openrouter/moonshotai/kimi-k2-thinking"
    but kimi-cli's providers expect raw model names since the base_url already
    specifies the provider endpoint.

    IMPORTANT: Preserve original case - providers like Groq are case-sensitive.
    """
    if not model:
        return model

    transformed = model

    # LiteLLM provider prefixes to strip
    litellm_prefixes = [
        "openrouter/",
        "anthropic/",
        "ollama/",
        "groq/",
        "azure/",
        "azure_ai/",
        "together/",
        "together_ai/",
        "fireworks/",
        "fireworks_ai/",
        "deepinfra/",
        "anyscale/",
        "perplexity/",
        "mistral/",
        "huggingface/",
        "xai/",
        "deepseek/",
        "minimax/",
        "zai/",
        "moonshot/",
        "cohere/",
        "cohere_chat/",
        "bedrock/",
        "vertex_ai/",
        "sagemaker/",
        "replicate/",
        "nlp_cloud/",
        "ai21/",
        "aleph_alpha/",
        "palm/",
        "gemini/",
        "github_copilot/",
        "openai_codex/",
        "openai/",
    ]

    for prefix in litellm_prefixes:
        if transformed.lower().startswith(prefix):
            transformed = transformed[len(prefix) :]
            logger.debug(
                "Stripped LiteLLM prefix",
                prefix=prefix,
                original=model,
                transformed=transformed,
            )
            break

    return transformed


def _canonicalize_openrouter_model(
    model: str, api_base: Optional[str], api_key: Optional[str]
) -> str:
    """Canonicalize OpenRouter model IDs (best-effort, no hard failure).

    OpenRouter model IDs are usually provider-qualified (e.g. ``minimax/minimax-m2.5``).
    Some UI/manual flows may persist bare IDs (e.g. ``minimax-m2.5``), which OpenRouter
    rejects. We resolve against `/models` and pick a unique suffix match when possible.
    """
    m = (model or "").strip()
    if not m:
        return m
    if "/" in m:
        return m
    try:
        import httpx

        base = (api_base or "https://openrouter.ai/api/v1").rstrip("/")
        headers: Dict[str, str] = {
            "HTTP-Referer": "https://mem.nowledge.co",
            "X-Title": "Nowledge Mem",
        }
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        with httpx.Client(timeout=6.0) as client:
            resp = client.get(f"{base}/models", headers=headers)
            if resp.status_code != 200:
                return m
            payload = resp.json() if resp.text else {}
            items = []
            if isinstance(payload, dict):
                items = payload.get("data") or payload.get("models") or []
            ids = [
                str(it.get("id") or it.get("name") or "").strip()
                for it in items
                if isinstance(it, dict)
            ]
            ids = [x for x in ids if x]
            if not ids:
                return m
            if m in ids:
                return m
            suffix = f"/{m.lower()}"
            hits = [x for x in ids if x.lower().endswith(suffix)]
            if len(hits) == 1:
                logger.info(
                    "Canonicalized OpenRouter model for kimi config",
                    original=m,
                    canonical=hits[0],
                )
                return hits[0]
            return m
    except Exception:
        return m


# =============================================================================
# Config Generation
# =============================================================================


def generate_kimi_config_from_remote_llm(
    purpose: Literal["default", "ai_now"] = "default",
) -> Optional[Path]:
    """Generate kimi-cli config.json from RemoteLLMConfigManager.

    This is the Python-native way to provide LLM config to agents,
    without depending on TypeScript config sync.

    Args:
        purpose: Which purpose config to use. "default" for Knowledge Agent,
                 "ai_now" for Feed Agent. Defaults to "default".

    Returns the path to the generated config.json, or None if LLM is not configured.
    """
    try:
        from nowledge_graph_server.services.remote_llm_config import get_config_manager

        cm = get_config_manager()
        config = cm.get_config()

        if not config.enabled:
            logger.debug("Remote LLM not enabled, cannot generate kimi config")
            return None

        # Get effective config for the specified purpose
        effective = cm.get_effective_purpose(purpose)
        provider_id = effective.get("provider") or config.provider
        model_name = effective.get("model") or config.model

        if not provider_id or not model_name:
            logger.debug(
                "No provider/model configured for purpose",
                purpose=purpose,
                effective=effective,
                provider_id=provider_id,
                model_name=model_name,
            )
            return None

        # Get provider config for credentials
        all_providers = cm.get_all_provider_configs()
        provider_cfg = all_providers.get(provider_id)
        if provider_cfg is None:
            logger.warning("Provider config not found", provider_id=provider_id)
            return None

        provider_type_raw = (provider_cfg.provider_type or provider_id).strip()
        provider_type = _normalize_provider_type(provider_type_raw)
        api_key = provider_cfg.api_key
        api_base = provider_cfg.api_base

        # Resolve OAuth-backed providers (Copilot / Codex) for kimi-agent-sdk
        if provider_type == "github_copilot":
            copilot_key, copilot_base = _resolve_copilot_credentials(
                cm.config_path.parent
            )
            if copilot_key:
                api_key = copilot_key
            if copilot_base:
                api_base = copilot_base
        elif provider_type == "openai_codex":
            codex_key = _resolve_codex_credentials(cm.config_path.parent)
            if codex_key:
                api_key = codex_key
            api_base = OPENAI_CODEX_API_BASE_URL

        # Build kimi config
        kimi_config = _build_kimi_config(
            provider_id=provider_id,
            provider_type=provider_type,
            model_name=model_name,
            api_key=api_key,
            api_base=api_base,
        )

        # Write to builtin_agents directory
        builtin_agents_home = get_builtin_agents_home()
        builtin_agents_home.mkdir(parents=True, exist_ok=True)
        config_path = builtin_agents_home / "config.json"

        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(kimi_config, f, indent=2)

        logger.debug(
            "Generated kimi config from RemoteLLMConfigManager",
            config_path=str(config_path),
            purpose=purpose,
            provider_id=provider_id,
            provider_type=provider_type,
            model=model_name,
            base_url=api_base or _get_default_base_url(provider_type),
            has_api_key=bool(api_key),
        )

        return config_path

    except Exception as e:
        logger.error("Failed to generate kimi config", error=str(e))
        return None


def _build_kimi_config(
    *,
    provider_id: str,
    provider_type: str,
    model_name: str,
    api_key: Optional[str],
    api_base: Optional[str],
) -> Dict[str, Any]:
    """Build kimi-cli config dictionary."""
    provider_lower = provider_type.lower()

    # Get or normalize base URL
    base_url = api_base or _get_default_base_url(provider_type)

    # Normalize provider-specific base URLs
    if provider_lower == "ollama" and base_url and not base_url.endswith("/v1"):
        # Ollama: ensure it ends with /v1
        base_url = base_url.rstrip("/") + "/v1"
    elif provider_lower == "xai" and base_url and not base_url.rstrip("/").endswith("/v1"):
        # xAI OpenAI-compatible chat endpoint is /v1/chat/completions.
        base_url = base_url.rstrip("/") + "/v1"
    elif provider_lower == "gemini" and base_url:
        # Gemini (google-genai): base_url should be host-only (no /v1beta).
        base_url = base_url.rstrip("/")
        if base_url.endswith("/v1beta"):
            base_url = base_url[:-7]
        elif base_url.endswith("/v1"):
            base_url = base_url[:-3]

    # Transform model name (strip LiteLLM prefixes)
    transformed_model = _transform_model_for_kimi(model_name, provider_type)
    if provider_lower == "openrouter":
        transformed_model = _canonicalize_openrouter_model(
            transformed_model, base_url, api_key
        )

    # Map to kimi provider type
    kimi_provider_type = _map_provider_type(provider_type, base_url, transformed_model)
    if (
        provider_lower == "minimax"
        and kimi_provider_type == "anthropic"
        and isinstance(base_url, str)
        and ("api.minimax.io" in base_url.lower() or "api.minimaxi.com" in base_url.lower())
        and ("/anthropic" in base_url.lower())
    ):
        # Kimi Anthropic transport appends /v1/messages internally.
        # Keep MiniMax Anthropic base at /anthropic to avoid duplicated /v1 paths.
        base_url = re.sub(r"/v1(/messages)?/?$", "", base_url.rstrip("/"), flags=re.IGNORECASE)

    # Provider name for kimi config (sanitize for use as key)
    provider_name = f"nowledge_{re.sub(r'[^a-zA-Z0-9_]+', '_', provider_id)}"
    model_entry_name = "nowledge_model"

    # Build provider entry
    provider_entry: Dict[str, Any] = {
        "type": kimi_provider_type,
        "base_url": base_url,
        "api_key": api_key or (
            # Placeholder keys for providers that handle auth differently
            "ollama" if provider_lower == "ollama" else
            "nowledge" if provider_lower in ("github_copilot", "openai_codex") else
            ""
        ),
    }

    # Add provider-specific headers
    if provider_lower == "openrouter":
        provider_entry["custom_headers"] = {
            "HTTP-Referer": "https://nowledge.co",
            "X-Title": "Nowledge Feed Agent",
        }
    elif provider_lower == "github_copilot":
        provider_entry["custom_headers"] = {
            "Editor-Version": "vscode/1.85.1",
            "Editor-Plugin-Version": "copilot/1.155.0",
            "Copilot-Integration-Id": "vscode-chat",
            "User-Agent": "GithubCopilot/1.155.0",
            "Accept": "application/json",
        }
    elif provider_lower == "openai_codex":
        provider_entry["custom_headers"] = {
            "User-Agent": "Codex-CLI/1.0 Nowledge/1.0",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    # Build model entry
    model_entry = {
        "provider": provider_name,
        "model": transformed_model,
        "max_context_size": _get_default_context_size(transformed_model),
    }

    return {
        "default_model": model_entry_name,
        "providers": {provider_name: provider_entry},
        "models": {model_entry_name: model_entry},
    }
