"""Knowledge Agent — background intelligence system for the Feed.

Both the Knowledge Agent and Feed Agent now use kimi-agent-sdk for LLM
interactions, providing consistent behavior and configuration.

Key components:
- KnowledgeAgentSession: Background processing (EVOLVES, crystallization, etc.)
- FeedAgentSession: User input processing with streaming
- KnowledgeAgentDependencies: Global tool dependencies for Knowledge Agent
- FeedToolDependencies: Global tool dependencies for Feed Agent
"""
