"""Feed Agent Tools — source document tools.

ListSources — list/search sources in the library
ReadSourceContent — read parsed markdown content of a source
SearchSourceChunks — full-text search within a source's chunks
DeleteSource — delete a source and all its artifacts
AnalyzeSourceData — compute real statistics on tabular data (CSV/XLSX)
"""

from __future__ import annotations

import csv
import io
import json
import math
import statistics
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from pydantic import BaseModel, Field, field_validator
from kosong.tooling import CallableTool2, ToolError, ToolOk, ToolReturnValue

from nowledge_graph_server.database.result_utils import iter_rows

from ._base import FeedToolDependencies, logger


# ---------------------------------------------------------------------------
# ListSources
# ---------------------------------------------------------------------------


class ListSourcesParams(BaseModel):
    name_contains: Optional[str] = Field(
        default=None,
        description="Filter sources whose name contains this text (case-insensitive).",
    )
    lifecycle_state: Optional[str] = Field(
        default=None,
        description="Filter by lifecycle state: 'ingested', 'parsed', 'indexed', 'error', etc.",
    )
    limit: int = Field(
        default=20,
        description="Maximum sources to return. Default 20.",
    )


class ListSources(CallableTool2):
    """List sources in the Library — use to find source IDs."""

    name: str = "ListSources"
    description: str = (
        "List sources in the Library, newest first. Use this to find a source's ID "
        "when you need it for ReadSourceContent, SearchSourceChunks, or DeleteSource. "
        "Filter by name_contains to find a specific file, or by lifecycle_state='error' "
        "to find sources that failed to parse."
    )
    params: type[ListSourcesParams] = ListSourcesParams

    async def __call__(self, params: ListSourcesParams) -> ToolReturnValue:
        deps = FeedToolDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Feed tools not configured", brief="Not ready")

        try:
            conn = deps.kuzu_client.conn
            limit = min(max(1, params.limit), 50)

            conditions = []
            query_params: dict = {"limit": limit}

            if params.name_contains:
                conditions.append("LOWER(s.original_name) CONTAINS LOWER($name_filter)")
                query_params["name_filter"] = params.name_contains

            if params.lifecycle_state:
                conditions.append("s.lifecycle_state = $lifecycle_state")
                query_params["lifecycle_state"] = params.lifecycle_state

            where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""

            query = f"""
                MATCH (s:Source)
                {where_clause}
                RETURN s.id, s.source_type, s.original_name, s.mime_type,
                       s.lifecycle_state, s.chunk_count, s.memory_count, s.created_at
                ORDER BY s.created_at DESC
                LIMIT $limit
            """

            sources = []
            for row in iter_rows(conn.execute(query, query_params)):
                created_at = row[7]
                if isinstance(created_at, datetime):
                    created_at = created_at.isoformat()
                elif created_at is not None:
                    created_at = str(created_at)

                sources.append({
                    "id": row[0],
                    "source_type": row[1],
                    "original_name": row[2],
                    "mime_type": row[3],
                    "lifecycle_state": row[4],
                    "chunk_count": row[5],
                    "memory_count": row[6],
                    "created_at": created_at,
                })

            return ToolOk(output=json.dumps({
                "count": len(sources),
                "sources": sources,
            }))

        except Exception as e:
            logger.error("ListSources failed", error=str(e))
            return ToolError(output="", message=str(e), brief="List failed")


class ReadSourceContentParams(BaseModel):
    source_id: str = Field(description="Source ID (e.g. 'src_a1b2c3')")
    offset: int = Field(default=0, description="Character offset to start reading from. Use for pagination on large documents.")
    limit: int = Field(default=8000, description="Maximum characters to return. Default 8000.")


class ReadSourceContent(CallableTool2):
    """Read the parsed markdown content of a source document."""

    name: str = "ReadSourceContent"
    description: str = (
        "Read the parsed markdown content of a source document from the Library. "
        "Returns the document text (or a page of it for large documents). "
        "Use offset/limit for pagination: call with offset=0 first, "
        "then offset=8000 for the next page if has_more is true."
    )
    params: type[ReadSourceContentParams] = ReadSourceContentParams

    async def __call__(self, params: ReadSourceContentParams) -> ToolReturnValue:
        deps = FeedToolDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Feed tools not configured", brief="Not ready")

        try:
            # Look up the source node to get parsed_path
            source_repo = deps.kuzu_client.source_repo
            source_node = await source_repo.get_source(params.source_id)
            if not source_node:
                return ToolError(output="", message=f"Source not found: {params.source_id}", brief="Not found")

            if not source_node.parsed_path:
                # Return informative response (not error) so the LLM knows the source
                # exists but has no content — and can still be deleted if needed.
                return ToolOk(output=json.dumps({
                    "source_name": source_node.original_name,
                    "source_id": params.source_id,
                    "has_content": False,
                    "lifecycle_state": getattr(source_node, "lifecycle_state", "unknown"),
                    "message": (
                        f"Source '{source_node.original_name}' exists but has no parsed content "
                        f"(parsing may have failed). You can still delete it with DeleteSource."
                    ),
                }))

            parsed_path = Path(source_node.parsed_path)
            if not parsed_path.exists():
                return ToolError(output="", message="Parsed file not found on disk", brief="File missing")

            raw = parsed_path.read_text(encoding="utf-8", errors="replace")
            total_length = len(raw)

            # Apply offset + limit
            offset = max(0, params.offset)
            limit = min(max(100, params.limit), 50000)
            content = raw[offset:offset + limit]
            has_more = (offset + limit) < total_length

            return ToolOk(output=json.dumps({
                "source_name": source_node.original_name,
                "total_length": total_length,
                "offset": offset,
                "returned_length": len(content),
                "has_more": has_more,
                "content": content,
            }))

        except Exception as e:
            logger.error("ReadSourceContent failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Read failed")


class SearchSourceChunksParams(BaseModel):
    source_id: str = Field(description="Source ID to search within (e.g. 'src_a1b2c3')")
    query: str = Field(description="Text query to search for within the source's chunks")
    limit: int = Field(default=5, description="Maximum chunks to return. Default 5.")


class SearchSourceChunks(CallableTool2):
    """Search within a source document's chunks using full-text search."""

    name: str = "SearchSourceChunks"
    description: str = (
        "Full-text search within a specific source document's chunks. "
        "Use this to find relevant sections of a large document matching a query. "
        "More efficient than reading the entire document when looking for specific topics."
    )
    params: type[SearchSourceChunksParams] = SearchSourceChunksParams

    async def __call__(self, params: SearchSourceChunksParams) -> ToolReturnValue:
        deps = FeedToolDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Feed tools not configured", brief="Not ready")

        try:
            from nowledge_graph_server.services.search_index.service_factory import get_search_index_service

            search_svc = await get_search_index_service()
            if search_svc is None or search_svc.search_ops is None:
                return ToolError(output="", message="Search index not available", brief="No index")

            limit = min(max(1, params.limit), 20)
            chunks = await search_svc.search_ops.search_fts(
                search_svc.TABLE_SOURCE_CHUNKS,
                params.query,
                limit=limit,
                where_clause=f"source_id = '{params.source_id}'",
            )

            results = []
            for r in chunks:
                text = getattr(r, "text", "") or ""
                results.append({
                    "text": text[:3000],
                    "chunk_index": getattr(r, "chunk_index", None),
                    "score": getattr(r, "_score", None),
                })

            # Also get total chunk count from graph
            total_chunks = None
            try:
                source_node = await deps.kuzu_client.source_repo.get_source(params.source_id)
                if source_node:
                    total_chunks = source_node.chunk_count
            except Exception:
                pass

            return ToolOk(output=json.dumps({
                "source_id": params.source_id,
                "query": params.query,
                "total_chunks": total_chunks,
                "matched": len(results),
                "chunks": results,
            }))

        except Exception as e:
            logger.error("SearchSourceChunks failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Search failed")


class DeleteSourceParams(BaseModel):
    source_id: str = Field(description="Source ID to delete (e.g. 'src_a1b2c3')")


class DeleteSource(CallableTool2):
    """Delete a source from the Library and clean up all related artifacts."""

    name: str = "DeleteSource"
    description: str = (
        "Permanently delete a source from the Library. Works regardless of parse state — "
        "can delete sources that failed to parse or have no content. Removes the source's "
        "search index records, filesystem artifacts (raw files, parsed markdown, images), "
        "graph node and relationships (SOURCED_FROM, REVISED_AS). Memories linked via "
        "SOURCED_FROM lose their source link but are NOT deleted."
    )
    params: type[DeleteSourceParams] = DeleteSourceParams

    async def __call__(self, params: DeleteSourceParams) -> ToolReturnValue:
        deps = FeedToolDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Feed tools not configured", brief="Not ready")

        try:
            # 1. Verify source exists
            source = await deps.kuzu_client.source_repo.get_source(params.source_id)
            if not source:
                return ToolError(output="", message=f"Source not found: {params.source_id}", brief="Not found")

            source_name = source.original_name

            # 2. Delete from search index
            try:
                from nowledge_graph_server.services.search_index.source_sync import delete_source_from_index

                await delete_source_from_index(params.source_id)
            except Exception as e:
                logger.warning("Failed to delete source from search index", source_id=params.source_id, error=str(e))

            # 3. Delete filesystem artifacts
            try:
                from nowledge_graph_server.services.source_storage import SourceStorageService

                storage = SourceStorageService()
                storage.delete_source_dir(params.source_id)
            except Exception as e:
                logger.warning("Failed to delete source files", source_id=params.source_id, error=str(e))

            # 4. Delete from graph (node + relationships)
            await deps.kuzu_client.source_repo.delete_source(params.source_id)

            # 5. Emit feed event (for timeline) + data change (for Library refresh)
            from nowledge_graph_server.utils.feed_events import emit_feed_event
            from nowledge_graph_server.utils.progress_logger import log_data_change

            emit_feed_event(
                event_type="source_deleted",
                title=f"Source deleted: {source_name}",
                description=f"Source '{source_name}' ({params.source_id}) deleted by agent",
                metadata={"name": source_name, "source_id": params.source_id},
            )
            log_data_change(
                change_type="source_deleted",
                entity_type="source",
                entity_id=params.source_id,
                details={"name": source_name},
            )

            logger.info("DeleteSource succeeded", source_id=params.source_id, name=source_name)

            return ToolOk(output=json.dumps({
                "success": True,
                "source_id": params.source_id,
                "source_name": source_name,
                "message": f"Source '{source_name}' deleted successfully",
            }))

        except Exception as e:
            logger.error("DeleteSource failed", source_id=params.source_id, error=str(e))
            return ToolError(output="", message=str(e), brief="Delete failed")


# ---------------------------------------------------------------------------
# AnalyzeSourceData — computational analytics for tabular sources
# ---------------------------------------------------------------------------

_MAX_ANALYSIS_ROWS = 10_000
_MAX_SHEETS = 10
_TABULAR_EXTENSIONS = frozenset({".csv", ".tsv", ".xlsx", ".xls"})
_DATE_FORMATS = ("%Y-%m-%d", "%Y/%m/%d", "%m/%d/%Y", "%d/%m/%Y", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S")

# Return type: list of (sheet_name, column_names, rows)
SheetData = List[Tuple[str, List[str], List[List[str]]]]


def _read_tabular(file_path: str) -> SheetData:
    """Read a CSV/TSV/XLSX file and return per-sheet data."""
    p = Path(file_path)
    ext = p.suffix.lower()

    if ext in (".csv", ".tsv"):
        text = p.read_text(encoding="utf-8", errors="replace")
        delimiter = "\t" if ext == ".tsv" else None
        if delimiter is None:
            try:
                dialect = csv.Sniffer().sniff(text[:4096])
                delimiter = dialect.delimiter
            except csv.Error:
                delimiter = ","
        reader = csv.reader(io.StringIO(text), delimiter=delimiter)
        rows_raw = list(reader)
        if not rows_raw:
            return []
        columns = [c.strip() for c in rows_raw[0]]
        data_rows = [[c.strip() for c in r] for r in rows_raw[1:_MAX_ANALYSIS_ROWS + 1]]
        return [("", columns, data_rows)]

    elif ext in (".xlsx", ".xls"):
        try:
            import openpyxl
        except ImportError:
            raise RuntimeError("openpyxl not available — cannot analyze XLSX files")
        wb = openpyxl.load_workbook(file_path, read_only=True, data_only=True)
        sheets: SheetData = []
        for sheet_name in wb.sheetnames[:_MAX_SHEETS]:
            ws = wb[sheet_name]
            columns: List[str] = []
            data_rows: List[List[str]] = []
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if i == 0:
                    columns = [str(c).strip() if c is not None else f"col_{j}" for j, c in enumerate(row)]
                elif i <= _MAX_ANALYSIS_ROWS:
                    data_rows.append([str(c).strip() if c is not None else "" for c in row])
                else:
                    break
            if columns:
                sheets.append((sheet_name, columns, data_rows))
        wb.close()
        return sheets

    else:
        raise ValueError(f"Unsupported file type: {ext}")


def _try_float(val: str) -> Optional[float]:
    """Try to parse a string as float, stripping currency/percentage symbols."""
    if not val:
        return None
    cleaned = val.replace(",", "").replace("$", "").replace("€", "").replace("¥", "").replace("£", "").strip()
    if cleaned.endswith("%"):
        cleaned = cleaned[:-1].strip()
    try:
        return float(cleaned)
    except (ValueError, OverflowError):
        return None


def _try_date(val: str) -> Optional[str]:
    """Try to parse a string as a date, return ISO date string or None."""
    if not val or len(val) < 6:
        return None
    for fmt in _DATE_FORMATS:
        try:
            dt = datetime.strptime(val.strip(), fmt)
            return dt.strftime("%Y-%m-%d")
        except ValueError:
            continue
    return None


def _detect_col_type(values: List[str]) -> str:
    """Classify a column as numeric, temporal, or categorical."""
    non_empty = [v for v in values if v.strip()]
    if not non_empty:
        return "categorical"
    sample = non_empty[:200]  # Sample for speed

    num_ok = sum(1 for v in sample if _try_float(v) is not None)
    if num_ok / len(sample) >= 0.8:
        return "numeric"

    date_ok = sum(1 for v in sample if _try_date(v) is not None)
    if date_ok / len(sample) >= 0.6:
        return "temporal"

    return "categorical"


def _analyze_numeric(values: List[str]) -> Dict[str, Any]:
    """Compute statistics for a numeric column."""
    nums = [f for v in values if (f := _try_float(v)) is not None]
    if not nums:
        return {"non_null": 0}
    nums_sorted = sorted(nums)
    n = len(nums)

    def _percentile(data: List[float], p: float) -> float:
        k = (n - 1) * p
        f = math.floor(k)
        c = math.ceil(k)
        if f == c:
            return data[int(k)]
        return data[f] * (c - k) + data[c] * (k - f)

    return {
        "non_null": n,
        "null": len(values) - n,
        "min": round(nums_sorted[0], 4),
        "max": round(nums_sorted[-1], 4),
        "mean": round(statistics.mean(nums), 4),
        "median": round(statistics.median(nums), 4),
        "std": round(statistics.stdev(nums), 4) if n > 1 else 0,
        "q25": round(_percentile(nums_sorted, 0.25), 4),
        "q75": round(_percentile(nums_sorted, 0.75), 4),
    }


def _analyze_categorical(values: List[str], top_n: int = 8) -> Dict[str, Any]:
    """Compute frequency distribution for a categorical column."""
    non_empty = [v for v in values if v.strip()]
    counter = Counter(non_empty)
    total = len(non_empty)
    top = counter.most_common(top_n)
    return {
        "non_null": total,
        "null": len(values) - total,
        "unique": len(counter),
        "top_values": [
            {"value": v, "count": c, "pct": round(c / total * 100, 1) if total > 0 else 0}
            for v, c in top
        ],
    }


def _analyze_temporal(values: List[str]) -> Dict[str, Any]:
    """Compute date range and monthly distribution."""
    parsed = [(v, _try_date(v)) for v in values]
    dates = [d for _, d in parsed if d is not None]
    if not dates:
        return {"non_null": 0}
    dates_sorted = sorted(dates)
    # Monthly distribution
    monthly: Counter = Counter()
    for d in dates:
        monthly[d[:7]] += 1  # "YYYY-MM"
    top_months = monthly.most_common(12)
    return {
        "non_null": len(dates),
        "null": len(values) - len(dates),
        "range": {"min": dates_sorted[0], "max": dates_sorted[-1]},
        "monthly_distribution": {m: c for m, c in sorted(top_months)},
    }


class AnalyzeSourceDataParams(BaseModel):
    source_id: str = Field(description="Source ID to analyze (e.g. 'src_a1b2c3')")
    columns: Optional[List[str]] = Field(
        default=None,
        description="Specific columns to analyze. If omitted, analyzes all columns.",
    )

    @field_validator("columns", mode="before")
    @classmethod
    def coerce_string_to_list(cls, v: Any) -> Any:
        """LLMs often pass JSON-encoded strings instead of arrays. Parse them."""
        if isinstance(v, str):
            try:
                parsed = json.loads(v)
                if isinstance(parsed, list):
                    return parsed
            except (json.JSONDecodeError, TypeError):
                pass
            if v.strip():
                return [v.strip()]
            return None
        return v


def _analyze_sheet(
    columns: List[str],
    data_rows: List[List[str]],
    col_filter: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Analyze a single sheet's data and return structured stats."""
    col_indices = list(range(len(columns)))
    if col_filter:
        requested = {c.lower() for c in col_filter}
        filtered = [i for i, c in enumerate(columns) if c.lower() in requested]
        if filtered:
            col_indices = filtered

    col_results: List[Dict[str, Any]] = []
    col_types: Dict[int, str] = {}

    for idx in col_indices:
        col_name = columns[idx]
        col_values = [r[idx] if idx < len(r) else "" for r in data_rows]
        col_type = _detect_col_type(col_values)
        col_types[idx] = col_type

        entry: Dict[str, Any] = {"name": col_name, "type": col_type}
        if col_type == "numeric":
            entry.update(_analyze_numeric(col_values))
        elif col_type == "temporal":
            entry.update(_analyze_temporal(col_values))
        else:
            entry.update(_analyze_categorical(col_values))
        col_results.append(entry)

    # Cross-column analysis: correlations between numeric columns
    cross: Dict[str, Any] = {}
    numeric_indices = [i for i in col_indices if col_types.get(i) == "numeric"]
    if len(numeric_indices) >= 2:
        correlations = []
        for a_idx in range(len(numeric_indices)):
            for b_idx in range(a_idx + 1, len(numeric_indices)):
                ia, ib = numeric_indices[a_idx], numeric_indices[b_idx]
                pairs = []
                for r in data_rows:
                    va = _try_float(r[ia] if ia < len(r) else "")
                    vb = _try_float(r[ib] if ib < len(r) else "")
                    if va is not None and vb is not None:
                        pairs.append((va, vb))
                if len(pairs) > 5:
                    try:
                        corr = statistics.correlation([p[0] for p in pairs], [p[1] for p in pairs])
                        if abs(corr) > 0.3:
                            correlations.append({
                                "columns": [columns[ia], columns[ib]],
                                "pearson_r": round(corr, 4),
                                "n": len(pairs),
                            })
                    except (statistics.StatisticsError, ZeroDivisionError):
                        pass
        if correlations:
            correlations.sort(key=lambda c: abs(c["pearson_r"]), reverse=True)
            cross["correlations"] = correlations[:5]

    # Categorical-numeric cross: group means
    cat_indices = [i for i in col_indices if col_types.get(i) == "categorical"]
    if cat_indices and numeric_indices:
        best_cat, best_num = cat_indices[0], numeric_indices[0]
        groups: Dict[str, List[float]] = {}
        for r in data_rows:
            cat_val = r[best_cat] if best_cat < len(r) else ""
            num_val = _try_float(r[best_num] if best_num < len(r) else "")
            if cat_val.strip() and num_val is not None:
                groups.setdefault(cat_val, []).append(num_val)
        if groups:
            group_means = {
                k: round(statistics.mean(v), 4)
                for k, v in sorted(groups.items(), key=lambda x: -len(x[1]))[:8]
                if len(v) >= 2
            }
            if group_means:
                cross["group_means"] = {
                    "group_by": columns[best_cat],
                    "metric": columns[best_num],
                    "groups": group_means,
                }

    sheet_result: Dict[str, Any] = {
        "shape": {"rows": len(data_rows), "columns": len(columns)},
        "all_columns": columns,
        "analyzed_columns": col_results,
    }
    if cross:
        sheet_result["cross_analysis"] = cross
    return sheet_result


class AnalyzeSourceData(CallableTool2):
    """Compute real statistics on a tabular source (CSV/XLSX)."""

    name: str = "AnalyzeSourceData"
    description: str = (
        "Run computational analytics on a tabular source (CSV, TSV, XLSX). "
        "Reads the raw data file and computes real statistics: numeric min/max/mean/median/std, "
        "categorical top-N distributions, temporal date ranges, and cross-column patterns. "
        "For multi-sheet XLSX files, analyzes all sheets and returns per-sheet results. "
        "Use this FIRST for any tabular data question — it gives precise computed results "
        "that ReadSourceContent cannot provide."
    )
    params: type[AnalyzeSourceDataParams] = AnalyzeSourceDataParams

    async def __call__(self, params: AnalyzeSourceDataParams) -> ToolReturnValue:
        deps = FeedToolDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Feed tools not configured", brief="Not ready")

        try:
            source_repo = deps.kuzu_client.source_repo
            source_node = await source_repo.get_source(params.source_id)
            if not source_node:
                return ToolError(output="", message=f"Source not found: {params.source_id}", brief="Not found")

            if not source_node.file_path:
                return ToolError(
                    output="", brief="No raw file",
                    message=f"Source '{source_node.original_name}' has no raw file on disk. "
                            f"Use ReadSourceContent to read parsed markdown instead.",
                )

            file_path = Path(source_node.file_path)
            if not file_path.exists():
                return ToolError(output="", message="Raw file not found on disk", brief="File missing")

            ext = file_path.suffix.lower()
            if ext not in _TABULAR_EXTENSIONS:
                return ToolError(
                    output="", brief="Not tabular",
                    message=f"AnalyzeSourceData only works on tabular files (CSV/TSV/XLSX). "
                            f"This source is '{ext}'. Use ReadSourceContent instead.",
                )

            sheet_list = _read_tabular(str(file_path))
            if not sheet_list:
                return ToolOk(output=json.dumps({
                    "source_name": source_node.original_name,
                    "error": "No data found — file appears empty",
                }))

            # Single sheet — flat output (backward compatible, most common case)
            if len(sheet_list) == 1:
                _, columns, data_rows = sheet_list[0]
                result = _analyze_sheet(columns, data_rows, params.columns)
                result["source_name"] = source_node.original_name
                result["file_format"] = ext.lstrip(".")
                return ToolOk(output=json.dumps(result))

            # Multi-sheet — per-sheet analysis
            sheets_out: List[Dict[str, Any]] = []
            for sheet_name, columns, data_rows in sheet_list:
                sheet_result = _analyze_sheet(columns, data_rows, params.columns)
                sheet_result["sheet_name"] = sheet_name
                sheets_out.append(sheet_result)

            result = {
                "source_name": source_node.original_name,
                "file_format": ext.lstrip("."),
                "sheet_count": len(sheets_out),
                "sheets": sheets_out,
            }
            return ToolOk(output=json.dumps(result))

        except Exception as e:
            logger.error("AnalyzeSourceData failed", source_id=params.source_id, error=str(e))
            return ToolError(output="", message=str(e), brief="Analysis failed")
