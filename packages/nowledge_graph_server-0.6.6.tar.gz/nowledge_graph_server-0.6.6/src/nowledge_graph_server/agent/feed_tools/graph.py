"""Feed Agent Tools — graph intelligence tools (entities, EVOLVES, overview)."""

from __future__ import annotations

import json
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field
from kosong.tooling import CallableTool2, ToolError, ToolOk, ToolReturnValue

from nowledge_graph_server.database.result_utils import iter_rows, managed_result

from ._base import FeedToolDependencies, logger


class FindMemoriesByEntityParams(BaseModel):
    entity_name: str = Field(description="Entity name to search for (case-insensitive substring match)")
    entity_type: Optional[str] = Field(
        default=None,
        description="Optional entity type filter (e.g. 'person', 'technology', 'organization')",
    )
    limit: int = Field(default=10, description="Maximum memories to return (default 10)")


class FindMemoriesByEntity(CallableTool2):
    """Find all memories linked to a specific entity through the knowledge graph."""

    name: str = "FindMemoriesByEntity"
    description: str = (
        "Find ALL memories that reference a specific entity through the KNOWLEDGE GRAPH "
        "(not text search). Two memories may use completely different words but both "
        "reference the same entity. Use ALONGSIDE QueryMemories for comprehensive "
        "topic coverage. Call SearchEntities first to discover the correct entity name."
    )
    params: type[FindMemoriesByEntityParams] = FindMemoriesByEntityParams

    async def __call__(self, params: FindMemoriesByEntityParams) -> ToolReturnValue:
        deps = FeedToolDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Feed tools not configured", brief="Not ready")

        try:
            conn = deps.kuzu_client.conn
            name_lower = params.entity_name.lower()
            limit = min(max(1, params.limit), 30)

            if params.entity_type:
                result = conn.execute(
                    """
                    MATCH (m:Memory)-[r:MENTIONS]->(e:Entity)
                    WHERE lower(e.name) CONTAINS $name AND e.entity_type = $etype
                    RETURN m.id, m.title, m.content, m.unit_type, e.name, e.entity_type, r.confidence
                    ORDER BY r.confidence DESC
                    LIMIT $limit
                    """,
                    {"name": name_lower, "etype": params.entity_type, "limit": limit},
                )
            else:
                result = conn.execute(
                    """
                    MATCH (m:Memory)-[r:MENTIONS]->(e:Entity)
                    WHERE lower(e.name) CONTAINS $name
                    RETURN m.id, m.title, m.content, m.unit_type, e.name, e.entity_type, r.confidence
                    ORDER BY r.confidence DESC
                    LIMIT $limit
                    """,
                    {"name": name_lower, "limit": limit},
                )

            memories = []
            for row in iter_rows(result):
                memories.append({
                    "id": row[0],
                    "title": row[1],
                    "content_preview": (row[2] or "")[:200],
                    "unit_type": row[3],
                    "entity_name": row[4],
                    "entity_type": row[5],
                    "mention_confidence": row[6],
                })

            return ToolOk(output=json.dumps({
                "entity_query": params.entity_name,
                "count": len(memories),
                "memories": memories,
            }))

        except Exception as e:
            logger.error("FindMemoriesByEntity failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Entity search failed")


class GetEVOLVESChainParams(BaseModel):
    memory_id: str = Field(description="ID of any memory in the chain — traverses both directions to find the full history")


class GetEVOLVESChain(CallableTool2):
    """Get the complete version history (EVOLVES chain) for a memory."""

    name: str = "GetEVOLVESChain"
    description: str = (
        "Get the complete version history for a memory — all ancestors and descendants "
        "connected by EVOLVES edges. Returns the full chain ordered oldest->newest with "
        "the relationship type and confidence for each link. Use for 'how has my thinking "
        "on X evolved?' questions."
    )
    params: type[GetEVOLVESChainParams] = GetEVOLVESChainParams

    async def __call__(self, params: GetEVOLVESChainParams) -> ToolReturnValue:
        deps = FeedToolDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Feed tools not configured", brief="Not ready")

        try:
            if deps.evolves_ops:
                chain = await deps.evolves_ops.get_evolves_chain(
                    memory_id=params.memory_id,
                    max_depth=10,
                )
                return ToolOk(output=json.dumps(chain))

            # Fallback: direct KuzuDB queries (simplified 1-hop)
            conn = deps.kuzu_client.conn
            links = []

            # Incoming (ancestors)
            for row in iter_rows(conn.execute(
                """
                MATCH (a:Memory)-[e:EVOLVES]->(b:Memory)
                WHERE b.id = $id
                RETURN a.id, a.title, e.content_relation, e.confidence, e.reason
                """,
                {"id": params.memory_id},
            )):
                links.append({
                    "id": row[0], "title": row[1], "relation": row[2],
                    "confidence": row[3], "reason": row[4], "direction": "ancestor",
                })

            # Outgoing (descendants)
            for row in iter_rows(conn.execute(
                """
                MATCH (a:Memory)-[e:EVOLVES]->(b:Memory)
                WHERE a.id = $id
                RETURN b.id, b.title, e.content_relation, e.confidence, e.reason
                """,
                {"id": params.memory_id},
            )):
                links.append({
                    "id": row[0], "title": row[1], "relation": row[2],
                    "confidence": row[3], "reason": row[4], "direction": "descendant",
                })

            return ToolOk(output=json.dumps({
                "memory_id": params.memory_id,
                "chain_length": len(links) + 1,
                "links": links,
            }))

        except Exception as e:
            logger.error("GetEVOLVESChain failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Chain traversal failed")


class SearchEntitiesParams(BaseModel):
    query: str = Field(description="Entity name to search for (case-insensitive substring match)")
    entity_type: Optional[str] = Field(
        default=None,
        description="Optional entity type filter (e.g. 'person', 'technology', 'organization')",
    )
    limit: int = Field(default=15, description="Maximum entities to return (default 15)")


class SearchEntities(CallableTool2):
    """Discover entities in the knowledge graph by name or type."""

    name: str = "SearchEntities"
    description: str = (
        "Discover entities (people, technologies, concepts, organizations) in the "
        "knowledge graph. Returns entity names, types, and how many memories reference each. "
        "Call this BEFORE FindMemoriesByEntity to discover the correct entity name. "
        "Also useful for: finding the most connected topics, discovering entities "
        "that bridge two different knowledge domains."
    )
    params: type[SearchEntitiesParams] = SearchEntitiesParams

    async def __call__(self, params: SearchEntitiesParams) -> ToolReturnValue:
        deps = FeedToolDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Feed tools not configured", brief="Not ready")

        try:
            conn = deps.kuzu_client.conn
            query_lower = params.query.lower()
            limit = min(max(1, params.limit), 50)

            if params.entity_type:
                result = conn.execute(
                    """
                    MATCH (e:Entity)
                    WHERE lower(e.name) CONTAINS $query AND e.entity_type = $etype
                    OPTIONAL MATCH (m:Memory)-[:MENTIONS]->(e)
                    RETURN e.name, e.entity_type, COUNT(m) AS memory_count
                    ORDER BY memory_count DESC
                    LIMIT $limit
                    """,
                    {"query": query_lower, "etype": params.entity_type, "limit": limit},
                )
            else:
                result = conn.execute(
                    """
                    MATCH (e:Entity)
                    WHERE lower(e.name) CONTAINS $query
                    OPTIONAL MATCH (m:Memory)-[:MENTIONS]->(e)
                    RETURN e.name, e.entity_type, COUNT(m) AS memory_count
                    ORDER BY memory_count DESC
                    LIMIT $limit
                    """,
                    {"query": query_lower, "limit": limit},
                )

            entities = []
            for row in iter_rows(result):
                entities.append({
                    "name": row[0],
                    "type": row[1],
                    "memory_count": row[2],
                })

            return ToolOk(output=json.dumps({
                "query": params.query,
                "count": len(entities),
                "entities": entities,
            }))

        except Exception as e:
            logger.error("SearchEntities failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Entity search failed")


class GetGraphOverviewParams(BaseModel):
    days: int = Field(default=7, description="How many days of recent activity to include (default 7)")


class GetGraphOverview(CallableTool2):
    """Get an overview of the knowledge graph: stats, top entities, recent activity."""

    name: str = "GetGraphOverview"
    description: str = (
        "Get a high-level overview of the knowledge graph including: total counts "
        "(memories, entities, crystals, communities), top entities by connection count, "
        "and recent EVOLVES edges and crystals. Use this for 'what are my main knowledge "
        "areas?' or 'what's the state of my graph?' questions."
    )
    params: type[GetGraphOverviewParams] = GetGraphOverviewParams

    async def __call__(self, params: GetGraphOverviewParams) -> ToolReturnValue:
        deps = FeedToolDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Feed tools not configured", brief="Not ready")

        try:
            conn = deps.kuzu_client.conn
            overview: Dict[str, Any] = {}

            # Graph stats
            stats = {}
            for name, query in [
                ("memory_count", "MATCH (m:Memory) WHERE m.is_crystal = false RETURN count(m)"),
                ("crystal_count", "MATCH (m:Memory) WHERE m.is_crystal = true RETURN count(m)"),
                ("entity_count", "MATCH (e:Entity) RETURN count(e)"),
                ("community_count", "MATCH (c:Community) RETURN count(c)"),
                ("evolves_count", "MATCH ()-[e:EVOLVES]->() RETURN count(e)"),
            ]:
                try:
                    with managed_result(conn.execute(query)) as r:
                        stats[name] = r.get_next()[0] if r.has_next() else 0
                except Exception:
                    stats[name] = 0
            overview["stats"] = stats

            # Top entities by memory count
            try:
                top_entities = []
                for row in iter_rows(conn.execute(
                    """
                    MATCH (m:Memory)-[:MENTIONS]->(e:Entity)
                    RETURN e.name, e.entity_type, COUNT(m) AS mem_count
                    ORDER BY mem_count DESC
                    LIMIT 10
                    """
                )):
                    top_entities.append({
                        "name": row[0], "type": row[1], "memory_count": row[2],
                    })
                overview["top_entities"] = top_entities
            except Exception:
                overview["top_entities"] = []

            # Recent EVOLVES edges
            cutoff = datetime.now(timezone.utc) - timedelta(days=params.days)
            cutoff_str = cutoff.strftime("%Y-%m-%dT%H:%M:%S")
            try:
                recent_evolves = []
                for row in iter_rows(conn.execute(
                    """
                    MATCH (a:Memory)-[e:EVOLVES]->(b:Memory)
                    WHERE e.created_at >= timestamp($cutoff)
                    RETURN a.id, a.title, e.content_relation, e.confidence, b.id, b.title
                    ORDER BY e.created_at DESC
                    LIMIT 5
                    """,
                    {"cutoff": cutoff_str},
                )):
                    recent_evolves.append({
                        "older_id": row[0], "older_title": row[1],
                        "relation": row[2], "confidence": row[3],
                        "newer_id": row[4], "newer_title": row[5],
                    })
                overview["recent_evolves"] = recent_evolves
            except Exception:
                overview["recent_evolves"] = []

            # Recent crystals
            try:
                recent_crystals = []
                for row in iter_rows(conn.execute(
                    """
                    MATCH (m:Memory)
                    WHERE m.is_crystal = true AND m.created_at >= $cutoff
                    RETURN m.id, m.title, m.content
                    ORDER BY m.created_at DESC
                    LIMIT 3
                    """,
                    {"cutoff": cutoff_str},
                )):
                    recent_crystals.append({
                        "id": row[0], "title": row[1],
                        "content_preview": (row[2] or "")[:150],
                    })
                overview["recent_crystals"] = recent_crystals
            except Exception:
                overview["recent_crystals"] = []

            return ToolOk(output=json.dumps(overview))

        except Exception as e:
            logger.error("GetGraphOverview failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Overview failed")


class ListCommunitiesParams(BaseModel):
    limit: int = Field(default=20, description="Maximum communities to return (default 20)")


class ListCommunities(CallableTool2):
    """List knowledge communities — clusters of related entities detected by community detection."""

    name: str = "ListCommunities"
    description: str = (
        "List knowledge communities — clusters of related entities found by "
        "community detection (Louvain algorithm). Each community has a name, "
        "AI-generated summary describing its theme, and a member count. "
        "Use for: 'what are my main themes?', 'what topics cluster together?', "
        "'what are my knowledge areas?', 'summarize my most connected topics'."
    )
    params: type[ListCommunitiesParams] = ListCommunitiesParams

    async def __call__(self, params: ListCommunitiesParams) -> ToolReturnValue:
        deps = FeedToolDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Feed tools not configured", brief="Not ready")

        try:
            conn = deps.kuzu_client.conn
            limit = min(max(1, params.limit), 50)

            communities = []
            for row in iter_rows(conn.execute(
                """
                MATCH (c:Community)
                WHERE c.ai_summary IS NOT NULL AND c.ai_summary <> ''
                RETURN c.id, c.community_id, c.name, c.description, c.ai_summary, c.member_count
                ORDER BY c.member_count DESC
                LIMIT $limit
                """,
                {"limit": limit},
            )):
                communities.append({
                    "id": row[0],
                    "community_id": row[1],
                    "name": row[2],
                    "description": row[3] or "",
                    "summary": row[4] or "",
                    "member_count": row[5] or 0,
                })

            if not communities:
                return ToolOk(output=json.dumps({
                    "communities": [],
                    "total": 0,
                    "message": "No communities detected yet. Community detection runs periodically to discover theme clusters across your knowledge graph.",
                }))

            return ToolOk(output=json.dumps({
                "communities": communities,
                "total": len(communities),
            }))

        except Exception as e:
            logger.error("ListCommunities failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Community listing failed")


class GetCommunityDetailsParams(BaseModel):
    community_id: str = Field(description="Community ID (UUID from ListCommunities results)")
    limit: int = Field(default=20, description="Maximum entities to return (default 20)")


class GetCommunityDetails(CallableTool2):
    """Get detailed information about a specific community: member entities and connected memories."""

    name: str = "GetCommunityDetails"
    description: str = (
        "Get details of a specific community: its member entities and connected memories. "
        "Pass a community ID (UUID) from ListCommunities results to see which entities "
        "belong to this theme cluster and which memories reference them. "
        "Use after ListCommunities to drill into a specific theme."
    )
    params: type[GetCommunityDetailsParams] = GetCommunityDetailsParams

    async def __call__(self, params: GetCommunityDetailsParams) -> ToolReturnValue:
        deps = FeedToolDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Feed tools not configured", brief="Not ready")

        try:
            conn = deps.kuzu_client.conn
            limit = min(max(1, params.limit), 50)

            # Step 1: Look up community by UUID to get the Louvain community_id
            with managed_result(conn.execute(
                """
                MATCH (c:Community)
                WHERE c.id = $cid
                RETURN c.id, c.community_id, c.name, c.description, c.ai_summary, c.member_count
                """,
                {"cid": params.community_id},
            )) as result:
                if not result.has_next():
                    return ToolError(
                        output="", message=f"Community not found: {params.community_id}",
                        brief="Not found",
                    )

                row = result.get_next()
                community = {
                    "id": row[0],
                    "community_id": row[1],
                    "name": row[2],
                    "description": row[3] or "",
                    "summary": row[4] or "",
                    "member_count": row[5] or 0,
                }
                louvain_id = row[1]  # INT64 Louvain algorithm ID

            # Step 2: Find member entities via community_id property on Entity nodes
            entities = []
            for erow in iter_rows(conn.execute(
                """
                MATCH (e:Entity)
                WHERE e.community_id = $louvain_id
                OPTIONAL MATCH (m:Memory)-[:MENTIONS]->(e)
                RETURN e.id, e.name, e.entity_type, COUNT(m) AS memory_count
                ORDER BY memory_count DESC
                LIMIT $limit
                """,
                {"louvain_id": louvain_id, "limit": limit},
            )):
                entities.append({
                    "id": erow[0],
                    "name": erow[1],
                    "entity_type": erow[2],
                    "memory_count": erow[3],
                })

            # Step 3: Find sample memories connected to community entities
            sample_memories = []
            for mrow in iter_rows(conn.execute(
                """
                MATCH (e:Entity {community_id: $louvain_id})<-[:MENTIONS]-(m:Memory)
                WHERE m.is_crystal = false
                WITH m, COUNT(e) AS entity_count
                RETURN m.id, m.title, m.content, m.unit_type
                ORDER BY entity_count DESC, m.importance DESC
                LIMIT 5
                """,
                {"louvain_id": louvain_id},
            )):
                sample_memories.append({
                    "id": mrow[0],
                    "title": mrow[1],
                    "content_preview": (mrow[2] or "")[:200],
                    "unit_type": mrow[3],
                })

            return ToolOk(output=json.dumps({
                "community": community,
                "entities": entities,
                "sample_memories": sample_memories,
                "entity_count": len(entities),
                "memory_count": len(sample_memories),
            }))

        except Exception as e:
            logger.error("GetCommunityDetails failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Community details failed")
