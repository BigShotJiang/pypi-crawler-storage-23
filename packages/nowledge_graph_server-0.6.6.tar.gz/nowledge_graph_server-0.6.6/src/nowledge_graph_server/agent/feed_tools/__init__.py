"""Feed Agent Tools — split into submodules for pyarmor compatibility (<1000 lines each).

Re-exports all public classes so existing imports continue to work:
    from .feed_tools import FeedToolDependencies
"""

from ._base import FeedToolDependencies

from .search import (
    QueryMemories,
    QueryMemoriesParams,
    ReadDailyReport,
    ReadDailyReportParams,
    SearchHistory,
    SearchHistoryParams,
)

from .memory import (
    GetMemoryById,
    GetMemoryByIdParams,
    GetMemoryConnections,
    GetMemoryConnectionsParams,
    ListRecentMemories,
    ListRecentMemoriesParams,
)

from .graph import (
    FindMemoriesByEntity,
    FindMemoriesByEntityParams,
    GetEVOLVESChain,
    GetEVOLVESChainParams,
    GetGraphOverview,
    GetGraphOverviewParams,
    SearchEntities,
    SearchEntitiesParams,
    ListCommunities,
    ListCommunitiesParams,
    GetCommunityDetails,
    GetCommunityDetailsParams,
)

from .sources import (
    ListSources,
    ListSourcesParams,
    ReadSourceContent,
    ReadSourceContentParams,
    SearchSourceChunks,
    SearchSourceChunksParams,
    DeleteSource,
    DeleteSourceParams,
    AnalyzeSourceData,
    AnalyzeSourceDataParams,
)

from .scheduling import (
    ScheduleFollowUp,
    ScheduleFollowUpParams,
)

from .threads import (
    SearchThreads,
    SearchThreadsParams,
    FetchThreadMessages,
    FetchThreadMessagesParams,
)

__all__ = [
    "FeedToolDependencies",
    "QueryMemories",
    "QueryMemoriesParams",
    "ReadDailyReport",
    "ReadDailyReportParams",
    "SearchHistory",
    "SearchHistoryParams",
    "GetMemoryById",
    "GetMemoryByIdParams",
    "GetMemoryConnections",
    "GetMemoryConnectionsParams",
    "ListRecentMemories",
    "ListRecentMemoriesParams",
    "FindMemoriesByEntity",
    "FindMemoriesByEntityParams",
    "GetEVOLVESChain",
    "GetEVOLVESChainParams",
    "GetGraphOverview",
    "GetGraphOverviewParams",
    "SearchEntities",
    "SearchEntitiesParams",
    "ListCommunities",
    "ListCommunitiesParams",
    "GetCommunityDetails",
    "GetCommunityDetailsParams",
    "ListSources",
    "ListSourcesParams",
    "ReadSourceContent",
    "ReadSourceContentParams",
    "SearchSourceChunks",
    "SearchSourceChunksParams",
    "DeleteSource",
    "DeleteSourceParams",
    "AnalyzeSourceData",
    "AnalyzeSourceDataParams",
    "ScheduleFollowUp",
    "ScheduleFollowUpParams",
    "SearchThreads",
    "SearchThreadsParams",
    "FetchThreadMessages",
    "FetchThreadMessagesParams",
]
