"""Feed Agent Tools — memory retrieval and listing tools."""

from __future__ import annotations

import json
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field
from kosong.tooling import CallableTool2, ToolError, ToolOk, ToolReturnValue

from nowledge_graph_server.database.result_utils import iter_rows, managed_result

from ._base import FeedToolDependencies, logger


class GetMemoryByIdParams(BaseModel):
    memory_id: str = Field(description="ID of the memory to retrieve")


class GetMemoryById(CallableTool2):
    """Get full details of a specific memory by ID."""

    name: str = "GetMemoryById"
    description: str = (
        "Retrieve a specific memory by its ID. Returns full content, metadata, "
        "importance, unit type, and version info. Use this to get details of a "
        "memory found via QueryMemories or referenced in connections."
    )
    params: type[GetMemoryByIdParams] = GetMemoryByIdParams

    async def __call__(self, params: GetMemoryByIdParams) -> ToolReturnValue:
        deps = FeedToolDependencies
        if not deps.is_configured():
            return ToolError(
                output="",
                message="Feed tools not configured",
                brief="Tools not ready",
            )

        try:
            conn = deps.kuzu_client.conn
            with managed_result(conn.execute(
                """
                MATCH (m:Memory)
                WHERE m.id = $id
                RETURN m.id, m.title, m.content, m.unit_type, m.importance,
                       m.is_latest, m.is_crystal, m.created_at, m.source,
                       m.temporal_context, m.event_start, m.event_end
                """,
                {"id": params.memory_id},
            )) as result:
                if not result.has_next():
                    return ToolOk(output=json.dumps({
                        "error": f"Memory not found: {params.memory_id}",
                    }))

                row = result.get_next()
            memory = {
                "id": row[0],
                "title": row[1],
                "content": row[2],  # Full content, not truncated
                "unit_type": row[3],
                "importance": row[4],
                "is_latest": row[5],
                "is_crystal": row[6],
                "created_at": str(row[7]) if row[7] else None,
                "source": row[8],
                "temporal_context": row[9],
                "event_start": str(row[10]) if row[10] else None,
                "event_end": str(row[11]) if row[11] else None,
            }

            return ToolOk(output=json.dumps(memory))

        except Exception as e:
            logger.error("GetMemoryById failed", error=str(e))
            return ToolError(
                output="",
                message=str(e),
                brief="Fetch failed",
            )


class GetMemoryConnectionsParams(BaseModel):
    memory_id: str = Field(description="ID of the memory to explore")
    include_evolves: bool = Field(
        default=True,
        description="Include EVOLVES edges (version history)",
    )
    include_entities: bool = Field(
        default=True,
        description="Include MENTIONS edges (entities referenced)",
    )
    include_crystals: bool = Field(
        default=True,
        description="Include CRYSTALLIZED_FROM edges (crystal links)",
    )


class GetMemoryConnections(CallableTool2):
    """Get connections for a memory: version history, entities, and crystals."""

    name: str = "GetMemoryConnections"
    description: str = (
        "Explore a memory's connections in the knowledge graph. Returns:\n"
        "- EVOLVES: Version history (older/newer versions of this info)\n"
        "- MENTIONS: Entities referenced by this memory (people, places, etc)\n"
        "- CRYSTALLIZED_FROM: Crystal links (if this is a crystal or part of one)\n"
        "Use this to understand how knowledge relates and evolves."
    )
    params: type[GetMemoryConnectionsParams] = GetMemoryConnectionsParams

    async def __call__(self, params: GetMemoryConnectionsParams) -> ToolReturnValue:
        deps = FeedToolDependencies
        if not deps.is_configured():
            return ToolError(
                output="",
                message="Feed tools not configured",
                brief="Tools not ready",
            )

        # Validate memory exists before exploring connections.
        # Prevents infinite retry loops when agent passes invalid IDs
        # (e.g. followup task IDs, event IDs).
        conn = deps.kuzu_client.conn
        with managed_result(conn.execute(
            "MATCH (m:Memory) WHERE m.id = $id RETURN m.id",
            {"id": params.memory_id},
        )) as check:
            if not check.has_next():
                return ToolError(
                    output="",
                    message=(
                        f"Memory not found: {params.memory_id}. "
                        "This ID does not exist in the knowledge graph. "
                        "Use QueryMemories or ListSources to find valid IDs."
                    ),
                    brief="Not found",
                )

        # Build edge types list based on params
        edge_types = []
        if params.include_evolves:
            edge_types.append("EVOLVES")
        if params.include_entities:
            edge_types.append("MENTIONS")
        if params.include_crystals:
            edge_types.append("CRYSTALLIZED_FROM")

        if not edge_types:
            return ToolOk(output=json.dumps({
                "memory_id": params.memory_id,
                "connections": {},
                "note": "No edge types selected — set at least one include_* param to true",
            }))

        try:
            # Use EvolvesOperations if available, otherwise query directly
            if deps.evolves_ops:
                result = await deps.evolves_ops.get_memory_neighbors(
                    memory_id=params.memory_id,
                    edge_types=edge_types,
                    depth=1,
                )
                return ToolOk(output=json.dumps({
                    "memory_id": params.memory_id,
                    "connections": result,
                }))

            # Fallback: direct KuzuDB queries
            conn = deps.kuzu_client.conn
            connections: Dict[str, List[Dict[str, Any]]] = {}

            if "EVOLVES" in edge_types:
                evolves = []
                # Outgoing (this -> newer)
                for row in iter_rows(conn.execute(
                    """
                    MATCH (a:Memory)-[e:EVOLVES]->(b:Memory)
                    WHERE a.id = $id
                    RETURN b.id, b.title, e.content_relation, e.confidence
                    """,
                    {"id": params.memory_id},
                )):
                    evolves.append({
                        "direction": "outgoing",
                        "target_id": row[0],
                        "target_title": row[1],
                        "relation": row[2],
                        "confidence": row[3],
                    })

                # Incoming (older -> this)
                for row in iter_rows(conn.execute(
                    """
                    MATCH (a:Memory)-[e:EVOLVES]->(b:Memory)
                    WHERE b.id = $id
                    RETURN a.id, a.title, e.content_relation, e.confidence
                    """,
                    {"id": params.memory_id},
                )):
                    evolves.append({
                        "direction": "incoming",
                        "source_id": row[0],
                        "source_title": row[1],
                        "relation": row[2],
                        "confidence": row[3],
                    })

                connections["EVOLVES"] = evolves

            if "MENTIONS" in edge_types:
                mentions = []
                for row in iter_rows(conn.execute(
                    """
                    MATCH (m:Memory)-[r:MENTIONS]->(e:Entity)
                    WHERE m.id = $id
                    RETURN e.id, e.name, e.entity_type, r.confidence
                    """,
                    {"id": params.memory_id},
                )):
                    mentions.append({
                        "entity_id": row[0],
                        "entity_name": row[1],
                        "entity_type": row[2],
                        "confidence": row[3],
                    })
                connections["MENTIONS"] = mentions

            if "CRYSTALLIZED_FROM" in edge_types:
                crystals = []
                # This is a crystal -> find sources
                for row in iter_rows(conn.execute(
                    """
                    MATCH (c:Memory)-[r:CRYSTALLIZED_FROM]->(s:Memory)
                    WHERE c.id = $id
                    RETURN s.id, s.title, r.contribution_weight
                    """,
                    {"id": params.memory_id},
                )):
                    crystals.append({
                        "direction": "crystal_to_source",
                        "source_id": row[0],
                        "source_title": row[1],
                        "weight": row[2],
                    })

                # This is a source -> find crystals
                for row in iter_rows(conn.execute(
                    """
                    MATCH (c:Memory)-[r:CRYSTALLIZED_FROM]->(s:Memory)
                    WHERE s.id = $id
                    RETURN c.id, c.crystal_title, r.contribution_weight
                    """,
                    {"id": params.memory_id},
                )):
                    crystals.append({
                        "direction": "source_to_crystal",
                        "crystal_id": row[0],
                        "crystal_title": row[1],
                        "weight": row[2],
                    })
                connections["CRYSTALLIZED_FROM"] = crystals

            return ToolOk(output=json.dumps({
                "memory_id": params.memory_id,
                "connections": connections,
            }))

        except Exception as e:
            logger.error("GetMemoryConnections failed", error=str(e))
            return ToolError(
                output="",
                message=str(e),
                brief="Connection query failed",
            )


class ListRecentMemoriesParams(BaseModel):
    days: int = Field(
        default=7,
        description="Number of days to look back (default 7)",
    )
    limit: int = Field(
        default=20,
        description="Maximum memories to return (default 20)",
    )
    unit_type: Optional[str] = Field(
        default=None,
        description="Filter by unit type: fact|preference|decision|plan|procedure|learning|context|event",
    )


class ListRecentMemories(CallableTool2):
    """List recently captured memories."""

    name: str = "ListRecentMemories"
    description: str = (
        "List memories captured recently, optionally filtered by type. "
        "Use this for questions like 'what did I capture today?' or "
        "'show me recent decisions'. Returns memories sorted by creation date."
    )
    params: type[ListRecentMemoriesParams] = ListRecentMemoriesParams

    async def __call__(self, params: ListRecentMemoriesParams) -> ToolReturnValue:
        deps = FeedToolDependencies
        if not deps.is_configured():
            return ToolError(
                output="",
                message="Feed tools not configured",
                brief="Tools not ready",
            )

        try:
            conn = deps.kuzu_client.conn
            cutoff = datetime.now(timezone.utc) - timedelta(days=params.days)
            cutoff_str = cutoff.strftime("%Y-%m-%dT%H:%M:%S")

            # Build query with optional unit_type filter
            if params.unit_type:
                query = """
                    MATCH (m:Memory)
                    WHERE m.created_at >= $cutoff AND m.unit_type = $unit_type
                    RETURN m.id, m.title, m.content, m.unit_type, m.importance,
                           m.created_at, m.is_crystal
                    ORDER BY m.created_at DESC
                    LIMIT $limit
                """
                query_params = {
                    "cutoff": cutoff_str,
                    "unit_type": params.unit_type,
                    "limit": min(params.limit, 50),
                }
            else:
                query = """
                    MATCH (m:Memory)
                    WHERE m.created_at >= $cutoff
                    RETURN m.id, m.title, m.content, m.unit_type, m.importance,
                           m.created_at, m.is_crystal
                    ORDER BY m.created_at DESC
                    LIMIT $limit
                """
                query_params = {
                    "cutoff": cutoff_str,
                    "limit": min(params.limit, 50),
                }

            memories = []
            for row in iter_rows(conn.execute(query, query_params)):
                memories.append({
                    "id": row[0],
                    "title": row[1],
                    "content": (row[2] or "")[:200],  # Preview only
                    "unit_type": row[3],
                    "importance": row[4],
                    "created_at": str(row[5]) if row[5] else None,
                    "is_crystal": row[6],
                })

            return ToolOk(output=json.dumps({
                "count": len(memories),
                "days": params.days,
                "unit_type_filter": params.unit_type,
                "memories": memories,
            }))

        except Exception as e:
            logger.error("ListRecentMemories failed", error=str(e))
            return ToolError(
                output="",
                message=str(e),
                brief="List failed",
            )
