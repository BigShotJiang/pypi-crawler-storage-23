"""Feed Agent Tools — memory search and history tools."""

from __future__ import annotations

import json
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field
from kosong.tooling import CallableTool2, ToolError, ToolOk, ToolReturnValue

from ._base import FeedToolDependencies, logger
from nowledge_graph_server.utils.time_partitioning import (
    _get_time_partitioned_path,
    _iter_time_partitioned_files,
)
from ..utils.search_results import _normalize_search_result, _get_search_score


class QueryMemoriesParams(BaseModel):
    query: str = Field(description="Semantic search query")
    limit: int = Field(default=10, description="Max results to return")
    unit_type: Optional[str] = Field(
        default=None,
        description="Filter by unit type: fact|preference|decision|plan|procedure|learning|context|event",
    )


class QueryMemories(CallableTool2):
    """Search the knowledge graph for memories by text similarity."""

    name: str = "QueryMemories"
    description: str = (
        "Search for memories by TEXT SIMILARITY — finds memories whose content "
        "semantically matches your query. Returns id, title, snippet, and score. "
        "Good for finding specific topics with known keywords. "
        "LIMITATION: misses memories that reference the same entity using different "
        "words. For comprehensive topic coverage, also use SearchEntities + FindMemoriesByEntity."
    )
    params: type[QueryMemoriesParams] = QueryMemoriesParams

    async def __call__(self, params: QueryMemoriesParams) -> ToolReturnValue:
        deps = FeedToolDependencies
        if not deps.is_configured():
            return ToolError(
                output="",
                message="Feed tools not configured",
                brief="Tools not ready",
            )

        try:
            results = await deps.search_ops.search_memories(
                query=params.query,
                limit=min(params.limit, 20),
            )

            memories = []
            for r in results:
                mem = _normalize_search_result(r)
                if not mem:
                    continue
                if params.unit_type and mem.get("unit_type") != params.unit_type:
                    continue
                memories.append({
                    "id": mem.get("id", ""),
                    "title": mem.get("title", ""),
                    "content": (mem.get("content", "") or "")[:300],
                    "unit_type": mem.get("unit_type", "fact"),
                    "score": _get_search_score(r, mem),
                })

            return ToolOk(output=json.dumps({
                "count": len(memories),
                "memories": memories[:params.limit],
            }))

        except Exception as e:
            import traceback
            logger.error(
                "QueryMemories failed",
                error=str(e),
                search_ops_type=type(deps.search_ops).__name__,
                traceback=traceback.format_exc(),
            )
            return ToolError(
                output="",
                message=str(e),
                brief="Search failed",
            )


class ReadDailyReportParams(BaseModel):
    date: Optional[str] = Field(
        default=None,
        description="Date in YYYY-MM-DD format (default: today)",
    )
    days_ago: Optional[int] = Field(
        default=None,
        description="Alternative: number of days ago (0=today, 1=yesterday)",
    )


class ReadDailyReport(CallableTool2):
    """Read a daily activity report from the agent's archive."""

    name: str = "ReadDailyReport"
    description: str = (
        "Read a daily activity report from the agent's archive. "
        "Reports contain summaries of agent activity, past conversations, "
        "and decisions made. Use this to recall what happened on a specific day."
    )
    params: type[ReadDailyReportParams] = ReadDailyReportParams

    async def __call__(self, params: ReadDailyReportParams) -> ToolReturnValue:
        deps = FeedToolDependencies
        if deps.reports_dir is None:
            return ToolError(
                output="",
                message="Reports directory not configured",
                brief="No reports",
            )

        if params.date:
            date_str = params.date
            target = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        elif params.days_ago is not None:
            target = datetime.now(timezone.utc) - timedelta(days=params.days_ago)
            date_str = target.strftime("%Y-%m-%d")
        else:
            target = datetime.now(timezone.utc)
            date_str = target.strftime("%Y-%m-%d")

        # Use time-partitioned path
        report_path = _get_time_partitioned_path(deps.reports_dir, target, "md")

        if not report_path.exists():
            available = [
                f.stem for f in _iter_time_partitioned_files(deps.reports_dir, "md", last_n_days=90)
            ][:10]
            return ToolOk(output=json.dumps({
                "error": f"No report found for {date_str}",
                "available_dates": available,
            }))

        try:
            content = report_path.read_text(encoding="utf-8")
            if len(content) > 6000:
                content = content[:6000] + "\n\n... (truncated)"

            return ToolOk(output=json.dumps({
                "date": date_str,
                "content": content,
            }))
        except Exception as e:
            return ToolError(output="", message=str(e), brief="Read failed")


class SearchHistoryParams(BaseModel):
    pattern: str = Field(description="Text pattern to search for (case-insensitive)")
    max_results: int = Field(default=10, description="Maximum matching lines to return")
    last_n_days: int = Field(default=14, description="Search only the last N days")


class SearchHistory(CallableTool2):
    """Search through archived daily reports for specific topics."""

    name: str = "SearchHistory"
    description: str = (
        "Search through archived daily reports using a text pattern. "
        "Returns matching lines from past conversations and activity. "
        "Use this to find past discussions without loading full reports."
    )
    params: type[SearchHistoryParams] = SearchHistoryParams

    async def __call__(self, params: SearchHistoryParams) -> ToolReturnValue:
        deps = FeedToolDependencies
        if deps.reports_dir is None or not deps.reports_dir.exists():
            return ToolOk(output=json.dumps({"matches": [], "total": 0}))

        pattern = params.pattern.lower()
        matches: List[Dict[str, Any]] = []

        # Use time-partitioned file iteration
        for report_path in _iter_time_partitioned_files(deps.reports_dir, "md", last_n_days=params.last_n_days):
            if len(matches) >= params.max_results:
                break

            try:
                content = report_path.read_text(encoding="utf-8")
                for i, line in enumerate(content.split("\n")):
                    if pattern in line.lower():
                        matches.append({
                            "date": report_path.stem,
                            "line": i + 1,
                            "text": line.strip()[:200],
                        })
                        if len(matches) >= params.max_results:
                            break
            except Exception:
                continue

        return ToolOk(output=json.dumps({
            "pattern": params.pattern,
            "total": len(matches),
            "matches": matches,
        }))
