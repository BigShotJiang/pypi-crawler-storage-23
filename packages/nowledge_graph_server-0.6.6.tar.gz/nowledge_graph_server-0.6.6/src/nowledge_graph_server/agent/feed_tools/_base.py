"""Shared dependencies and utilities for Feed Agent tools."""

from __future__ import annotations

import json  # noqa: F401
import uuid  # noqa: F401
from datetime import datetime, timezone, timedelta  # noqa: F401
from pathlib import Path
from typing import Any, Dict, List, Optional  # noqa: F401

import structlog
from pydantic import BaseModel, Field  # noqa: F401

from kosong.tooling import CallableTool2, ToolError, ToolOk, ToolReturnValue  # noqa: F401

from nowledge_graph_server.utils.time_partitioning import (  # noqa: F401
    _get_time_partitioned_path,
    _iter_time_partitioned_files,
)
from ..utils.search_results import (  # noqa: F401
    _normalize_search_result,
    _get_search_score,
)

logger = structlog.get_logger(__name__)


class FeedToolDependencies:
    """Global registry for Feed agent tool dependencies.

    Set these before starting the FeedAgentSession so tools can access them.
    """

    search_ops: Any = None
    kuzu_client: Any = None
    evolves_ops: Any = None  # EvolvesOperations instance for graph traversal
    scheduler: Any = None    # AgentScheduler for one-time task scheduling
    reports_dir: Optional[Path] = None  # Time-partitioned: YYYY/MM/YYYY-MM-DD.md
    events_dir: Optional[Path] = None   # Time-partitioned: YYYY/MM/YYYY-MM-DD.jsonl

    @classmethod
    def configure(
        cls,
        search_ops: Any,
        kuzu_client: Any,
        reports_dir: Path,
        events_dir: Path,
        evolves_ops: Any = None,
        scheduler: Any = None,
    ) -> None:
        if not hasattr(search_ops, 'search_memories'):
            logger.error(
                "FeedToolDependencies: search_ops missing search_memories!",
                search_ops_type=type(search_ops).__name__,
                search_ops_attrs=sorted(a for a in dir(search_ops) if not a.startswith('_')),
            )
        cls.search_ops = search_ops
        cls.kuzu_client = kuzu_client
        cls.reports_dir = reports_dir
        cls.events_dir = events_dir
        cls.evolves_ops = evolves_ops
        cls.scheduler = scheduler

    @classmethod
    def is_configured(cls) -> bool:
        return cls.search_ops is not None and cls.kuzu_client is not None
