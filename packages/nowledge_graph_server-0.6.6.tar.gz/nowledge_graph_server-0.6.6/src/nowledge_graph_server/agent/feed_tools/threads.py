"""Feed Agent Tools — thread search and retrieval for conversation intelligence."""

from __future__ import annotations

import json
from typing import Optional

from pydantic import BaseModel, Field
from kosong.tooling import CallableTool2, ToolError, ToolOk, ToolReturnValue

from ._base import FeedToolDependencies, logger


class SearchThreadsParams(BaseModel):
    query: Optional[str] = Field(
        default=None,
        description=(
            "Search query (keywords or natural language). "
            "Omit to list recent threads instead of searching."
        ),
    )
    limit: int = Field(default=10, description="Maximum threads to return (default 10)")
    source: Optional[str] = Field(
        default=None,
        description="Filter by source (e.g. 'claude-code', 'codex')",
    )


class SearchThreads(CallableTool2):
    """Search past conversations or list recent threads."""

    name: str = "SearchThreads"
    description: str = (
        "Search through saved conversation threads (from Claude Code, Codex, etc.) "
        "using full-text search, or list recent threads when no query is given. "
        "Use this to find past discussions on a topic, locate decisions made in "
        "previous coding sessions, or browse recent conversations. "
        "Returns thread titles, message counts, and matched snippets."
    )
    params: type[SearchThreadsParams] = SearchThreadsParams

    async def __call__(self, params: SearchThreadsParams) -> ToolReturnValue:
        deps = FeedToolDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Feed tools not configured", brief="Not ready")

        try:
            effective_query = params.query.strip() if params.query else None
            limit = min(max(1, params.limit), 30)

            if effective_query:
                # SEARCH MODE: Use LanceDB FTS
                return await _search_threads_fts(
                    deps.kuzu_client, effective_query, limit, params.source
                )
            else:
                # LIST MODE: Return recent threads from KuzuDB
                return await _list_recent_threads(deps.kuzu_client, limit, params.source)

        except Exception as e:
            logger.error("SearchThreads failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Thread search failed")


class FetchThreadMessagesParams(BaseModel):
    thread_id: str = Field(description="Thread ID from SearchThreads results")
    offset: int = Field(default=0, description="Skip first N messages (for pagination)")
    limit: int = Field(default=30, description="Maximum messages to return (default 30)")


class FetchThreadMessages(CallableTool2):
    """Fetch the full content of a specific conversation thread."""

    name: str = "FetchThreadMessages"
    description: str = (
        "Get the actual messages from a conversation thread. Use after SearchThreads "
        "to read the full discussion. Returns messages with role (user/assistant), "
        "content, and timestamps. Messages longer than 3000 chars are truncated."
    )
    params: type[FetchThreadMessagesParams] = FetchThreadMessagesParams

    async def __call__(self, params: FetchThreadMessagesParams) -> ToolReturnValue:
        deps = FeedToolDependencies
        if not deps.is_configured():
            return ToolError(output="", message="Feed tools not configured", brief="Not ready")

        try:
            limit = min(max(1, params.limit), 100)
            offset = max(0, params.offset)

            thread_response = await deps.kuzu_client.thread_repo.fetch_thread(params.thread_id)

            if not thread_response:
                return ToolError(
                    output="", message=f"Thread not found: {params.thread_id}",
                    brief="Not found",
                )

            all_messages = thread_response.messages
            paginated = all_messages[offset:offset + limit]

            messages = []
            for msg in paginated:
                content = msg.content
                if len(content) > 3000:
                    content = content[:3000] + "\n\n[... truncated ...]"
                messages.append({
                    "role": msg.role,
                    "content": content,
                    "order_index": msg.order_index,
                    "timestamp": msg.timestamp.isoformat() if msg.timestamp else None,
                })

            return ToolOk(output=json.dumps({
                "thread_id": params.thread_id,
                "title": thread_response.thread.title,
                "source": thread_response.thread.source,
                "total_messages": len(all_messages),
                "showing": f"{offset+1}-{offset+len(paginated)} of {len(all_messages)}",
                "messages": messages,
            }))

        except Exception as e:
            logger.error("FetchThreadMessages failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Thread fetch failed")


# ── Shared helpers ──────────────────────────────────────────────────────────


async def _list_recent_threads(
    kuzu_client, limit: int, source: Optional[str]
) -> ToolReturnValue:
    """List recent threads from KuzuDB."""
    threads = await kuzu_client.thread_repo.list_threads(
        limit=limit, offset=0, source=source
    )

    if not threads:
        return ToolOk(output=json.dumps({
            "threads": [],
            "total": 0,
            "message": "No conversation threads found. Threads are created when you save coding sessions via the save-thread skill or MCP tool.",
        }))

    items = []
    for t in threads:
        items.append({
            "thread_id": t.get("thread_id", ""),
            "title": t.get("title", "Untitled"),
            "source": t.get("source", ""),
            "message_count": t.get("message_count", 0),
            "last_activity": _safe_isoformat(t.get("last_activity")),
        })

    return ToolOk(output=json.dumps({"threads": items, "total": len(items)}))


async def _search_threads_fts(
    kuzu_client, query: str, limit: int, source: Optional[str]
) -> ToolReturnValue:
    """Full-text search threads using LanceDB FTS."""
    from nowledge_graph_server.services.search_index import get_search_index_service

    search_service = await get_search_index_service()
    if not search_service:
        # Fallback: can't do FTS, return empty with message
        return ToolOk(output=json.dumps({
            "threads": [],
            "total": 0,
            "message": "Search index not available. Try listing threads without a query.",
        }))

    results = await search_service.search_messages_fts(
        query_text=query,
        limit=limit * 3,  # Get more messages to group by thread
    )

    # Group results by thread
    thread_results = {}
    for result in results:
        thread_id = result.data.get("thread_id", "")
        if not thread_id:
            continue

        safe_score = result.score if result.score is not None else 0.0
        snippet = (result.data.get("content", "") or "")[:200]

        if thread_id not in thread_results:
            thread = await kuzu_client.thread_repo.fetch_thread(thread_id)
            if not thread:
                continue

            # Apply source filter
            if source and thread.thread.source != source:
                continue

            thread_results[thread_id] = {
                "thread_id": thread.thread.thread_id,
                "title": thread.thread.title,
                "source": thread.thread.source or "",
                "message_count": len(thread.messages),
                "relevance_score": safe_score,
                "matched_snippets": [snippet] if snippet else [],
                "total_matches": 1,
            }
        else:
            thread_results[thread_id]["total_matches"] += 1
            if safe_score > thread_results[thread_id]["relevance_score"]:
                thread_results[thread_id]["relevance_score"] = safe_score
            if snippet and len(thread_results[thread_id]["matched_snippets"]) < 3:
                thread_results[thread_id]["matched_snippets"].append(snippet)

    sorted_results = sorted(
        thread_results.values(),
        key=lambda x: x["relevance_score"],
        reverse=True,
    )[:limit]

    return ToolOk(output=json.dumps({
        "threads": sorted_results,
        "total": len(sorted_results),
        "query": query,
    }))


def _safe_isoformat(val) -> Optional[str]:
    """Convert datetime or string to ISO format safely."""
    if val is None:
        return None
    if hasattr(val, "isoformat"):
        return val.isoformat()
    return str(val)
