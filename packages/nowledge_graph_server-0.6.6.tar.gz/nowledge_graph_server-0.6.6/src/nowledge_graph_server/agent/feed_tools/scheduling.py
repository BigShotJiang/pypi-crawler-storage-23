"""Feed Agent Tools — scheduling tools for agent-initiated follow-ups."""

from __future__ import annotations

import json
import time
import uuid
from datetime import datetime, timezone, timedelta
from typing import Any, List, Optional

from pydantic import BaseModel, Field, field_validator
from kosong.tooling import CallableTool2, ToolError, ToolOk, ToolReturnValue

from ._base import FeedToolDependencies, logger

# Per-turn rate limit for ScheduleFollowUp to prevent runaway loops.
# Tracks (count, window_start) — resets when > 60s has passed (new turn).
_SCHEDULE_MAX_PER_TURN = 2
_SCHEDULE_WINDOW_SECONDS = 60
_schedule_call_count: int = 0
_schedule_window_start: float = 0.0


class ScheduleFollowUpParams(BaseModel):
    delay_minutes: int = Field(
        description=(
            "Minutes from now to fire the follow-up. "
            "Examples: 5 (five minutes), 30 (half hour), 60 (one hour), "
            "1440 (tomorrow), 10080 (one week)."
        ),
        ge=5,
        le=43200,  # max 30 days
    )
    task_description: str = Field(
        description=(
            "Free-form instruction for the background agent to execute when the follow-up fires. "
            "This can be ANY task: analyzing memories, finding contradictions, creating summaries, "
            "checking for updates, running crystallization, or anything else. "
            "Be specific and self-contained — the agent won't see this conversation. "
            "Example: 'Analyze the user's recent database-related memories for contradictions "
            "and update working memory with findings.'"
        ),
    )
    reason: str = Field(
        description="Why this follow-up is needed — shown to the user in the timeline.",
    )
    related_memory_ids: Optional[List[str]] = Field(
        default=None,
        description="Memory IDs relevant to this follow-up (for context when it fires).",
    )

    @field_validator("related_memory_ids", mode="before")
    @classmethod
    def coerce_string_to_list(cls, v: Any) -> Any:
        """LLMs often pass JSON-encoded strings instead of arrays. Parse them."""
        if isinstance(v, str):
            try:
                parsed = json.loads(v)
                if isinstance(parsed, list):
                    return parsed
            except (json.JSONDecodeError, TypeError):
                pass
            if v.strip():
                return [v.strip()]
            return None
        return v


class ScheduleFollowUp(CallableTool2):
    """Schedule a future follow-up task for the agent."""

    name: str = "ScheduleFollowUp"
    description: str = (
        "Schedule ANY task to run after a delay (minimum 5 minutes). "
        "The task_description is a free-form instruction executed by a background Knowledge Agent "
        "with full tool access (query memories, create insights, flag contradictions, update working memory, etc.). "
        "Use when: (1) the user asks to do something later or set a reminder, "
        "(2) you notice something worth revisiting. "
        "The scheduled task appears in the timeline immediately."
    )
    params: type[ScheduleFollowUpParams] = ScheduleFollowUpParams

    async def __call__(self, params: ScheduleFollowUpParams) -> ToolReturnValue:
        # Per-turn rate limit: prevent runaway scheduling loops.
        # Resets when > 60s has passed since the first call in a burst.
        global _schedule_call_count, _schedule_window_start
        now_mono = time.monotonic()
        if now_mono - _schedule_window_start > _SCHEDULE_WINDOW_SECONDS:
            # New window — reset counter
            _schedule_call_count = 0
            _schedule_window_start = now_mono
        _schedule_call_count += 1
        if _schedule_call_count > _SCHEDULE_MAX_PER_TURN:
            logger.warning(
                "ScheduleFollowUp rate-limited",
                count=_schedule_call_count,
                max=_SCHEDULE_MAX_PER_TURN,
            )
            return ToolError(
                output="",
                message=f"Rate limited: already scheduled {_SCHEDULE_MAX_PER_TURN} follow-ups in the last minute. Finish your response instead of scheduling more.",
                brief="Rate limited",
            )

        # Resolve scheduler from whichever agent registry has it
        scheduler = FeedToolDependencies.scheduler
        created_by = "feed_agent"
        if scheduler is None:
            from nowledge_graph_server.agent.knowledge_tools._base import KnowledgeAgentDependencies
            scheduler = KnowledgeAgentDependencies.scheduler
            created_by = "knowledge_agent"
        if scheduler is None:
            return ToolError(
                output="",
                message="Scheduler not available",
                brief="No scheduler",
            )

        try:
            now = datetime.now(timezone.utc)
            scheduled_at = now + timedelta(minutes=params.delay_minutes)
            task_id = f"followup-{uuid.uuid4().hex[:8]}"

            scheduler.add_one_time_task(
                task_id=task_id,
                scheduled_at=scheduled_at.isoformat(),
                prompt=params.task_description,
                metadata={
                    "reason": params.reason,
                    "related_memory_ids": params.related_memory_ids or [],
                    "created_by": created_by,
                },
            )

            # Emit feed event so the scheduled task appears in the timeline
            from nowledge_graph_server.utils.feed_events import emit_feed_event

            # Human-readable delay
            if params.delay_minutes < 60:
                delay_label = f"in {params.delay_minutes}min"
            elif params.delay_minutes < 1440:
                hours = params.delay_minutes // 60
                delay_label = f"in {hours}h"
            elif params.delay_minutes < 10080:
                days = params.delay_minutes // 1440
                delay_label = f"in {days} day{'s' if days > 1 else ''}"
            else:
                weeks = params.delay_minutes // 10080
                delay_label = f"in {weeks} week{'s' if weeks > 1 else ''}"

            emit_feed_event(
                event_type="task_scheduled",
                title=f"Follow-up scheduled ({delay_label})",
                description=params.reason,
                metadata={
                    "task_id": task_id,
                    "delay_minutes": params.delay_minutes,
                    "scheduled_at": scheduled_at.isoformat(),
                    "task_description": params.task_description,
                },
                related_memory_ids=params.related_memory_ids,
            )

            return ToolOk(output=json.dumps({
                "task_id": task_id,
                "scheduled_at": scheduled_at.isoformat(),
                "delay_minutes": params.delay_minutes,
            }))

        except Exception as e:
            logger.error("ScheduleFollowUp failed", error=str(e))
            return ToolError(output="", message=str(e), brief="Scheduling failed")
