"""Shared utilities for agent tools."""

from .search_results import normalize_search_result, get_search_score  # noqa: F401

# Backward-compatible aliases
_normalize_search_result = normalize_search_result
_get_search_score = get_search_score
