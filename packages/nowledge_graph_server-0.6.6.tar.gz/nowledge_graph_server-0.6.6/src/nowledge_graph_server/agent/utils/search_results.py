"""Search result normalization utilities.

Converts heterogeneous search result objects (ORM models, dicts, dataclasses)
into consistent dict format for agent tool responses.
"""

from __future__ import annotations

from typing import Any, Dict, Optional


def normalize_search_result(result: Any) -> Dict[str, Any]:
    """Normalize a search result into a consistent dict format."""
    if isinstance(result, dict):
        return result

    memory = getattr(result, "memory", None)
    if memory is not None:
        return {
            "id": getattr(memory, "id", ""),
            "title": getattr(memory, "title", "") or "",
            "content": getattr(memory, "content", "") or "",
            "unit_type": getattr(memory, "unit_type", "fact"),
            "importance": getattr(memory, "importance", None),
            "is_latest": getattr(memory, "is_latest", True),
            "is_crystal": getattr(memory, "is_crystal", False),
            "source": getattr(memory, "source", ""),
            "created_at": getattr(memory, "created_at", None),
        }

    return getattr(result, "__dict__", {})


def get_search_score(result: Any, memory: Dict[str, Any]) -> Optional[float]:
    """Extract similarity score from a search result."""
    score = getattr(result, "similarity_score", None)
    if score is None:
        score = memory.get("score") or memory.get("similarity")
    return score


# Backward-compatible aliases
_normalize_search_result = normalize_search_result
_get_search_score = get_search_score
