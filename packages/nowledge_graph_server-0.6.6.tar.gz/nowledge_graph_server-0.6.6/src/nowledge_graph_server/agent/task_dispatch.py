"""Task dispatch — scheduled job registration and on-demand triggers.

Extracted from manager.py to keep it under 1000 lines (PyArmor limit).
These are thin factories: create AgentTask, submit to scheduler.
"""

from __future__ import annotations

from datetime import time
from typing import Any

import structlog

from .scheduler import AgentTask, AgentScheduler, ScheduledJob, TaskPriority
from .task_prompts import (
    build_compaction_prompt,
    build_crystallization_prompt,
    build_daily_briefing_prompt,
    build_insight_detection_prompt,
)

logger = structlog.get_logger(__name__)


def register_scheduled_jobs(scheduler: AgentScheduler) -> None:
    """Register the standard set of scheduled jobs.

    Settings are read once at registration time. Community detection
    interval and AI summary option come from app-settings.json.
    All tasks are gated by their respective settings in _execute_task().
    """
    from .settings_reader import read_knowledge_processing_settings

    kp_settings = read_knowledge_processing_settings()

    # Daily briefing -- configurable hour from settings (default 5 AM)
    briefing_hour = kp_settings.get("briefingHour", 5)
    scheduler.add_scheduled_job(
        ScheduledJob(
            name="daily_briefing",
            task_factory=lambda: AgentTask(
                task_type="daily_briefing",
                prompt=build_daily_briefing_prompt(),
                priority=TaskPriority.LOW,
            ),
            schedule_time=time(briefing_hour, 0),
            interval_days=1,
        )
    )

    # Crystallization review -- weekly on Sundays at 3:00 AM
    scheduler.add_scheduled_job(
        ScheduledJob(
            name="crystallization_review",
            task_factory=lambda: AgentTask(
                task_type="crystallization_review",
                prompt=build_crystallization_prompt(),
                priority=TaskPriority.LOW,
            ),
            schedule_time=time(3, 0),
            interval_days=7,
        )
    )

    # Proactive insight detection -- weekly on Saturdays at 4:00 AM
    scheduler.add_scheduled_job(
        ScheduledJob(
            name="insight_detection",
            task_factory=lambda: AgentTask(
                task_type="insight_detection",
                prompt=build_insight_detection_prompt(),
                priority=TaskPriority.LOW,
            ),
            schedule_time=time(4, 0),
            interval_days=7,
        )
    )

    # Decay refresh -- daily at 6:00 AM (after daily briefing, direct-function)
    scheduler.add_scheduled_job(
        ScheduledJob(
            name="decay_refresh",
            task_factory=lambda: AgentTask(
                task_type="decay_refresh",
                prompt="",  # Direct-function, no prompt needed
                priority=TaskPriority.LOW,
            ),
            schedule_time=time(6, 0),
            interval_days=1,
        )
    )

    # Memory compaction -- weekly on Mondays at 4:00 AM (LLM-mediated)
    scheduler.add_scheduled_job(
        ScheduledJob(
            name="memory_compaction",
            task_factory=lambda: AgentTask(
                task_type="memory_compaction",
                prompt=build_compaction_prompt(),
                priority=TaskPriority.LOW,
            ),
            schedule_time=time(4, 0),
            interval_days=7,
        )
    )

    # Community detection -- configurable interval (direct-function, no LLM)
    cd_interval = kp_settings.get("communityDetectionIntervalDays", 14)
    cd_ai_summary = kp_settings.get("generateCommunityAISummary", True)
    cd_resolution = kp_settings.get("communityResolution", 1.0)
    scheduler.add_scheduled_job(
        ScheduledJob(
            name="community_detection",
            task_factory=lambda: AgentTask(
                task_type="community_detection",
                prompt="",  # Direct-function, no prompt needed
                priority=TaskPriority.LOW,
                metadata={
                    "resolution": cd_resolution,
                    "generate_ai_summary": cd_ai_summary,
                    "max_iterations": 100,
                },
            ),
            schedule_time=time(2, 0),
            interval_days=cd_interval,
        )
    )


# ------------------------------------------------------------------
# On-demand trigger factories
# ------------------------------------------------------------------


async def trigger_daily_briefing(scheduler: AgentScheduler) -> None:
    """Manually trigger a daily briefing."""
    task = AgentTask(
        task_type="daily_briefing",
        prompt=build_daily_briefing_prompt(),
        priority=TaskPriority.HIGH,
    )
    await scheduler.submit_task(task)


async def trigger_crystallization(scheduler: AgentScheduler) -> None:
    """Manually trigger a crystallization review."""
    task = AgentTask(
        task_type="crystallization_review",
        prompt=build_crystallization_prompt(),
        priority=TaskPriority.HIGH,
    )
    await scheduler.submit_task(task)


async def trigger_insight_detection(scheduler: AgentScheduler) -> None:
    """Manually trigger proactive insight detection."""
    task = AgentTask(
        task_type="insight_detection",
        prompt=build_insight_detection_prompt(),
        priority=TaskPriority.HIGH,
    )
    await scheduler.submit_task(task)


async def trigger_community_detection(
    scheduler: AgentScheduler,
    resolution: float = 1.0,
    generate_ai_summary: bool = True,
) -> None:
    """Manually trigger community detection."""
    task = AgentTask(
        task_type="community_detection",
        prompt="",  # Direct-function, no prompt needed
        priority=TaskPriority.HIGH,
        metadata={
            "resolution": resolution,
            "generate_ai_summary": generate_ai_summary,
            "max_iterations": 100,
        },
    )
    await scheduler.submit_task(task)


async def trigger_memory_compaction(scheduler: AgentScheduler) -> None:
    """Manually trigger memory compaction review."""
    task = AgentTask(
        task_type="memory_compaction",
        prompt=build_compaction_prompt(),
        priority=TaskPriority.HIGH,
    )
    await scheduler.submit_task(task)


async def trigger_decay_refresh(scheduler: AgentScheduler) -> None:
    """Manually trigger decay score refresh."""
    task = AgentTask(
        task_type="decay_refresh",
        prompt="",  # Direct-function, no prompt needed
        priority=TaskPriority.HIGH,
    )
    await scheduler.submit_task(task)


async def trigger_source_extraction(
    scheduler: AgentScheduler,
    source_id: str,
    source_name: str,
    mime_type: str | None = None,
) -> None:
    """Manually trigger source extraction (Learn lifecycle)."""
    from .task_prompts import build_source_extraction_prompt

    task = AgentTask(
        task_type="source_extraction",
        prompt=build_source_extraction_prompt(source_id, source_name, mime_type),
        priority=TaskPriority.HIGH,
        metadata={"source_id": source_id, "source_name": source_name},
    )
    await scheduler.submit_task(task)


async def trigger_kg_extraction(
    scheduler: AgentScheduler,
    backfill: bool = False,
) -> None:
    """Manually trigger KG extraction."""
    task_type = "kg_extraction_backfill" if backfill else "kg_extraction"
    task = AgentTask(
        task_type=task_type,
        prompt="",  # Direct-function, no prompt needed
        priority=TaskPriority.HIGH,
        metadata={},
    )
    await scheduler.submit_task(task)
