"""Knowledge Agent Session — kimi-agent-sdk wrapper for background processing.

This is the Knowledge Agent's session manager, using kimi-agent-sdk for LLM
interactions. It handles EVOLVES detection, crystallization, daily briefings,
and other background processing tasks.

Design (from KNOWLEDGE_AGENT_BACKEND_DESIGN.md):
- Background agent that runs silently ("duck feet underwater")
- User sees outputs in Feed timeline as insights, flags, crystals
- Uses tools for knowledge graph operations
- Scheduled tasks for daily briefings, crystallization, insight detection
"""

from __future__ import annotations

import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

import structlog

# Import centralized path utilities (MUST be imported before HOME is modified)
from .paths import get_builtin_agents_home

logger = structlog.get_logger(__name__)


class TokenBudgetExceeded(Exception):
    """Raised when a task exceeds its token budget.

    Tracks both cumulative totals (for cost accounting) and per-step max
    (for context window diagnostics). The cumulative total sums input tokens
    across ALL steps, but each step re-sends the full context — so the real
    peak context size is max_step_input, not total_input.
    """

    def __init__(
        self,
        input_tokens: int,
        output_tokens: int,
        budget: int,
        *,
        max_step_input: int = 0,
    ) -> None:
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens
        self.budget = budget
        self.max_step_input = max_step_input
        super().__init__(
            f"Token budget exceeded: {input_tokens + output_tokens} tokens "
            f"(input={input_tokens}, output={output_tokens}, "
            f"peak_step={max_step_input}) > budget={budget}"
        )


class ContextWindowExhausted(Exception):
    """Raised when context usage approaches the model's limit during a multi-step task.

    kimi-cli tracks context_usage as token_count / max_context_size (0.0-1.0).
    When this exceeds a threshold (e.g. 95%), we abort proactively to avoid
    a provider 400 error which would waste the entire step's tokens.
    """

    def __init__(self, context_usage: float, step_tokens: int = 0) -> None:
        self.context_usage = context_usage
        self.step_tokens = step_tokens
        super().__init__(
            f"Context window {context_usage:.0%} full "
            f"(step input: {step_tokens} tokens). "
            f"Task aborted to prevent provider rejection."
        )


class ToolLoopDetected(Exception):
    """Raised when consecutive tool errors indicate a retry loop.

    This catches the pattern where an LLM keeps calling the same tool with
    the same failing arguments (e.g. passing string when list is expected),
    burning through steps and tokens without progress.
    """

    def __init__(self, consecutive_errors: int, last_error: str) -> None:
        self.consecutive_errors = consecutive_errors
        self.last_error = last_error
        super().__init__(
            f"Tool loop detected: {consecutive_errors} consecutive errors. "
            f"Last error: {last_error[:200]}"
        )


class MaxStepsReached(Exception):
    """Raised when the SDK's max_steps_per_turn limit is reached.

    Unlike other abort exceptions, this carries the partial response text
    so intermediate work (insights, flags already emitted) is visible.
    """

    def __init__(self, partial_response: str, step_count: int) -> None:
        self.partial_response = partial_response
        self.step_count = step_count
        super().__init__(
            f"Max steps reached ({step_count} steps). "
            f"Partial response: {len(partial_response)} chars"
        )


class KnowledgeAgentSession:
    """Long-running agent session for background knowledge processing.

    Key design:
    - Uses kimi-agent-sdk Session for LLM calls
    - Runs scheduled tasks (daily briefings, crystallization, etc.)
    - Writes insights and flags to Feed timeline
    - History management via kimi-agent-sdk's built-in windowing
    """

    def __init__(
        self,
        work_dir: Path,
        agent_file: Path,
        reports_dir: Path,
        *,
        max_steps_per_turn: int = 10,  # Background tasks may need more steps
    ) -> None:
        self._work_dir = work_dir
        self._agent_file = agent_file
        self._reports_dir = reports_dir
        self._max_steps = max_steps_per_turn
        self._session: Any = None  # kimi_agent_sdk.Session
        self._session_id = "nowledge-knowledge-agent"

        # Track original KIMI_SHARE_DIR for restoration
        self._original_kimi_share_dir: Optional[str] = None

        # Config path (set by _ensure_kimi_config)
        self._config_path: Optional[Path] = None

        # State tracking
        self._is_running = False
        self._total_tasks = 0
        self._last_task_tokens: tuple[int, int] = (0, 0)

        # Ensure work_dir exists
        self._work_dir.mkdir(parents=True, exist_ok=True)

    @property
    def is_running(self) -> bool:
        return self._is_running

    @property
    def total_tasks(self) -> int:
        return self._total_tasks

    def _ensure_kimi_config(self) -> None:
        """Ensure kimi config is available for builtin agents.

        Architecture: Knowledge Agent runs in Python backend, so we generate
        the kimi-cli config directly from RemoteLLMConfigManager (Python side).
        This is different from AI-Now which uses ACP/spawned script and relies
        on TypeScript config sync.

        This method:
        1. Generates kimi-cli config.json from RemoteLLMConfigManager
        2. Sets KIMI_SHARE_DIR to builtin_agents directory for kimi-agent-sdk

        Uses KIMI_SHARE_DIR environment variable instead of HOME to avoid
        corrupting Path.home() for other code (model_cache, etc.).
        """
        from .kimi_config_generator import generate_kimi_config_from_remote_llm
        from .kimi_patches import (
            apply_chatgpt_backend_patch,
            apply_kimi_openai_custom_headers_patch,
            apply_kimi_reasoning_capability_patch,
        )

        # Get builtin_agents home path
        builtin_agents_home = get_builtin_agents_home()

        # Set KIMI_SHARE_DIR so kimi-agent-sdk uses isolated directory
        # This is safer than modifying HOME which affects all code using Path.home()
        self._original_kimi_share_dir = os.environ.get("KIMI_SHARE_DIR")
        os.environ["KIMI_SHARE_DIR"] = str(builtin_agents_home)

        logger.debug("Set KIMI_SHARE_DIR for Knowledge Agent", share_dir=str(builtin_agents_home))

        # Ensure builtin_agents directory exists
        builtin_agents_home.mkdir(parents=True, exist_ok=True)

        # Generate kimi config from RemoteLLMConfigManager (Python-native).
        # Use "ai_now" purpose — both agents use the same "Agent" model slot.
        # When ai_now is unset, it inherits from default automatically.
        self._config_path = generate_kimi_config_from_remote_llm(purpose="ai_now")
        # Ensure ChatGPT backend requests are patched if Codex is selected
        apply_chatgpt_backend_patch()
        apply_kimi_reasoning_capability_patch()
        apply_kimi_openai_custom_headers_patch()

        if self._config_path is None:
            logger.warning(
                "Could not generate kimi config. Configure Remote LLM in Settings.",
                builtin_agents_home=str(builtin_agents_home),
            )
            # Set a fallback path so Session.create doesn't fail with None
            self._config_path = builtin_agents_home / "config.json"

    def _ensure_agent_files(self) -> Path:
        """Write agent YAML and system prompt files from embedded code.

        Always regenerate — the embedded prompts are the source of truth
        and may be updated between versions (e.g. new tools added).
        """
        logger.info("[KNOWLEDGE AGENT] Writing agent files from embedded prompts")

        from .embedded_prompts import KNOWLEDGE_AGENT_SYSTEM_PROMPT

        # Write system prompt to work_dir
        system_prompt_path = self._work_dir / "system_prompt.md"
        system_prompt_path.write_text(KNOWLEDGE_AGENT_SYSTEM_PROMPT, encoding="utf-8")

        # Write agent YAML
        agent_yaml_path = self._work_dir / "knowledge_agent.yaml"
        yaml_content = """version: 1
agent:
  name: "Knowledge Agent"
  system_prompt_path: ./system_prompt.md
  tools:
    - "nowledge_graph_server.agent.knowledge_tools:QueryRecentActivity"
    - "nowledge_graph_server.agent.knowledge_tools:QueryMemories"
    - "nowledge_graph_server.agent.knowledge_tools:GetMemoryById"
    - "nowledge_graph_server.agent.knowledge_tools:CreateEVOLVES"
    - "nowledge_graph_server.agent.knowledge_tools:CreateCrystal"
    - "nowledge_graph_server.agent.knowledge_tools:CreateInsight"
    - "nowledge_graph_server.agent.knowledge_tools:FlagForReview"
    - "nowledge_graph_server.agent.knowledge_tools:QueryMemoryNeighbors"
    - "nowledge_graph_server.agent.knowledge_tools:UpdateMemoryMeta"
    - "nowledge_graph_server.agent.knowledge_tools:ReadDailyReport"
    - "nowledge_graph_server.agent.knowledge_tools:SearchHistory"
    - "nowledge_graph_server.agent.knowledge_tools:ListReports"
    - "nowledge_graph_server.agent.knowledge_tools:ReadWorkingMemory"
    - "nowledge_graph_server.agent.knowledge_tools:UpdateWorkingMemory"
    - "nowledge_graph_server.agent.knowledge_tools:RunCommunityDetection"
    - "nowledge_graph_server.agent.knowledge_tools:RunKGExtraction"
    - "nowledge_graph_server.agent.knowledge_tools:ListCommunities"
    - "nowledge_graph_server.agent.knowledge_tools:GetCommunityDetails"
    - "nowledge_graph_server.agent.knowledge_tools:QuerySources"
    - "nowledge_graph_server.agent.knowledge_tools:GetSourceDetails"
    - "nowledge_graph_server.agent.knowledge_tools:ListSources"
    - "nowledge_graph_server.agent.knowledge_tools:DeleteSource"
    # Source content tools (needed for source extraction / Learn lifecycle)
    - "nowledge_graph_server.agent.feed_tools:ReadSourceContent"
    - "nowledge_graph_server.agent.feed_tools:SearchSourceChunks"
    - "nowledge_graph_server.agent.feed_tools:AnalyzeSourceData"
    # Conversation thread tools
    - "nowledge_graph_server.agent.knowledge_tools:SearchThreads"
    - "nowledge_graph_server.agent.knowledge_tools:FetchThreadMessages"
    # Scheduling
    - "nowledge_graph_server.agent.feed_tools:ScheduleFollowUp"
    - "kimi_cli.tools.think:Think"
"""
        agent_yaml_path.write_text(yaml_content, encoding="utf-8")

        logger.info(
            "[KNOWLEDGE AGENT] Agent files created",
            agent_yaml=str(agent_yaml_path),
            system_prompt=str(system_prompt_path),
        )

        return agent_yaml_path

    async def start(self, *, yolo: bool = True, force_fresh: bool = False) -> None:
        """Start the Knowledge Agent session.

        Args:
            yolo: Auto-approve tool calls.
            force_fresh: Skip session resume and create fresh. Used after LLM
                         config changes to ensure the new model is picked up
                         (kimi-agent-sdk freezes config at session creation time).
        """
        self._ensure_kimi_config()

        agent_file = self._ensure_agent_files()

        try:
            from kaos.path import KaosPath
            from kimi_agent_sdk import Session
            logger.info("[KNOWLEDGE AGENT] kimi-agent-sdk imported successfully")
        except ImportError as e:
            logger.error("[KNOWLEDGE AGENT] kimi-agent-sdk not available", error=str(e))
            raise

        try:
            work_dir = KaosPath(str(self._work_dir))

            if force_fresh:
                logger.info("[KNOWLEDGE AGENT] force_fresh=True, creating new session (skipping resume)")
                self._session = None
            else:
                # Try to resume existing session.
                # Session files may contain corrupted tool_calls (e.g. missing
                # 'arguments' field) that cause Pydantic validation errors on
                # deserialization. Fall back to a fresh session in that case.
                try:
                    self._session = await Session.resume(
                        work_dir,
                        session_id=self._session_id,
                        config=self._config_path,
                        agent_file=agent_file,
                        yolo=yolo,
                        max_steps_per_turn=self._max_steps,
                    )
                except Exception as resume_err:
                    logger.warning(
                        "[KNOWLEDGE AGENT] Session resume failed, falling back to fresh session",
                        error=str(resume_err),
                    )
                    self._session = None

            if self._session is None:
                logger.info("[KNOWLEDGE AGENT] Creating new session")
                self._session = await Session.create(
                    work_dir=work_dir,
                    session_id=self._session_id,
                    config=self._config_path,
                    agent_file=agent_file,
                    yolo=yolo,
                    max_steps_per_turn=self._max_steps,
                )

            self._is_running = True

            # CRITICAL: Restore KIMI_SHARE_DIR immediately after session creation.
            # kimi-agent-sdk caches the session path at creation time, so we can
            # safely restore the env var now to avoid affecting other agents.
            self._restore_kimi_share_dir()

            logger.info("[KNOWLEDGE AGENT] Session started successfully!")

        except Exception as e:
            logger.error("[KNOWLEDGE AGENT] Failed to start session", error=str(e))
            self._restore_kimi_share_dir()
            raise

    async def stop(self) -> None:
        """Stop the Knowledge Agent session."""
        if self._session:
            try:
                await self._session.close()
            except Exception as e:
                logger.warning("[KNOWLEDGE AGENT] Error closing session", error=str(e))
            self._session = None

        self._is_running = False
        self._restore_kimi_share_dir()
        logger.info("[KNOWLEDGE AGENT] Session stopped")

    def set_max_steps(self, max_steps: int) -> None:
        """Update the max steps per turn. Takes effect on next session restart."""
        self._max_steps = max_steps

    async def restart_fresh(self) -> None:
        """Restart with a fresh session (no conversation history).

        Each scheduled task (daily briefing, crystallization, etc.) is
        independent and should not carry over context from previous tasks.
        Session.resume() loads the entire conversation history from disk,
        causing unbounded context growth over days/weeks. This method
        tears down the old session and creates a clean one so:
          - The latest system prompt from knowledge_agent.yaml is used
          - No stale conversation history influences the LLM
          - Prompt changes in task_prompts.py take full effect
        """
        logger.info("[KNOWLEDGE AGENT] Restarting with fresh session")
        await self.stop()
        await self.start(yolo=True, force_fresh=True)

    def _restore_kimi_share_dir(self) -> None:
        """Restore original KIMI_SHARE_DIR environment variable."""
        if self._original_kimi_share_dir is not None:
            os.environ["KIMI_SHARE_DIR"] = self._original_kimi_share_dir
        elif "KIMI_SHARE_DIR" in os.environ:
            # Remove KIMI_SHARE_DIR if it wasn't set before
            del os.environ["KIMI_SHARE_DIR"]

    async def run_task(self, prompt: str, *, max_tokens: int = 0) -> str:
        """Run a task and return the text response.

        This is used by the scheduler for background tasks like
        daily briefings, crystallization review, etc.

        Args:
            prompt: The task prompt to send to the agent.
            max_tokens: Per-task token budget (cumulative input + output). 0 = no limit.
                        When exceeded, the task is aborted to prevent runaway cost.

        Token tracking details:
            Each LLM step re-sends the full context, so cumulative total_input
            grows much faster than the actual context size. We track both:
            - total_input/total_output: cumulative across steps (cost accounting)
            - max_step_input: largest single step's input (peak context size)
            Additionally, kimi-cli's StatusUpdate.context_usage (0.0-1.0)
            gives the authoritative context window fill ratio. We abort at
            95% to prevent provider 400 errors.
        """
        if not self._session or not self._is_running:
            raise RuntimeError("Knowledge Agent session not running")

        # Context window exhaustion threshold (fraction of model's max_context_size).
        # kimi-cli compaction triggers earlier (at 1.0 - reserved/max), but tool
        # results added after the check can push past that. 95% is our safety net.
        _CONTEXT_EXHAUSTION_THRESHOLD = 0.95

        try:
            from kimi_agent_sdk import TextPart, ApprovalRequest, StatusUpdate
            from kosong.tooling import ToolResult

            response_text = ""
            total_input = 0
            total_output = 0
            max_step_input = 0
            step_count = 0
            consecutive_tool_errors = 0
            _CIRCUIT_BREAKER_THRESHOLD = 3  # Abort after 3 consecutive tool errors

            async for msg in self._session.prompt(prompt):
                match msg:
                    case TextPart(text=text):
                        response_text += text
                    case ApprovalRequest() as req:
                        # Auto-approve in background mode
                        req.resolve("approve")
                    case StatusUpdate() as status:
                        usage = status.token_usage
                        context_usage = status.context_usage

                        if usage is not None:
                            step_input = (
                                usage.input_other
                                + usage.input_cache_read
                                + usage.input_cache_creation
                            )
                            total_input += step_input
                            total_output += usage.output
                            max_step_input = max(max_step_input, step_input)
                            step_count += 1

                            # Per-task token budget enforcement (cumulative cost)
                            if max_tokens > 0 and (total_input + total_output) > max_tokens:
                                logger.warning(
                                    "[KNOWLEDGE AGENT] Task exceeded token budget, aborting",
                                    total_input=total_input,
                                    total_output=total_output,
                                    max_step_input=max_step_input,
                                    step_count=step_count,
                                    max_tokens=max_tokens,
                                )
                                raise TokenBudgetExceeded(
                                    total_input,
                                    total_output,
                                    max_tokens,
                                    max_step_input=max_step_input,
                                )

                        # Context window safety net: abort before provider rejects
                        if (
                            context_usage is not None
                            and context_usage > _CONTEXT_EXHAUSTION_THRESHOLD
                        ):
                            logger.warning(
                                "[KNOWLEDGE AGENT] Context window nearly full, aborting",
                                context_usage=f"{context_usage:.1%}",
                                max_step_input=max_step_input,
                                step_count=step_count,
                            )
                            raise ContextWindowExhausted(
                                context_usage, step_tokens=max_step_input
                            )

                    case ToolResult() as result:
                        # Circuit breaker: detect repeated tool failures
                        rv = getattr(result, "return_value", None)
                        if rv and getattr(rv, "is_error", False):
                            consecutive_tool_errors += 1
                            err_msg = getattr(rv, "message", str(rv))[:200]
                            if consecutive_tool_errors >= _CIRCUIT_BREAKER_THRESHOLD:
                                logger.warning(
                                    "[KNOWLEDGE AGENT] Circuit breaker: %d consecutive tool errors, aborting task",
                                    consecutive_tool_errors,
                                    last_error=err_msg,
                                )
                                raise ToolLoopDetected(consecutive_tool_errors, err_msg)
                        else:
                            consecutive_tool_errors = 0

            # Detect SDK step limit hit: the generator ends normally when
            # max_steps is reached, but the task may not be complete. Surface
            # this so the caller can emit a "partial completion" event.
            if step_count >= self._max_steps and step_count > 0:
                self._last_task_tokens = (total_input, total_output)
                logger.warning(
                    "[KNOWLEDGE AGENT] Max steps reached — task may be incomplete",
                    step_count=step_count,
                    max_steps=self._max_steps,
                    response_length=len(response_text),
                )
                raise MaxStepsReached(response_text, step_count)

            self._total_tasks += 1
            self._last_task_tokens = (total_input, total_output)

            logger.info(
                "[KNOWLEDGE AGENT] Task completed",
                input_tokens=total_input,
                output_tokens=total_output,
                max_step_input=max_step_input,
                step_count=step_count,
                response_length=len(response_text),
            )

            # Write task completion to daily report
            await self._write_task_to_report(prompt[:100], response_text[:500])

            return response_text

        except (TokenBudgetExceeded, ContextWindowExhausted, ToolLoopDetected, MaxStepsReached):
            raise  # Don't wrap safety exceptions
        except Exception as e:
            # Include exc_info for full traceback — [Errno 2] without a
            # filename is otherwise impossible to diagnose.
            logger.error(
                "[KNOWLEDGE AGENT] Task execution failed",
                error=str(e),
                exc_info=True,
            )
            raise

    @property
    def last_task_tokens(self) -> tuple[int, int]:
        """Return (input_tokens, output_tokens) from the last completed task."""
        return self._last_task_tokens

    async def _write_task_to_report(self, task_summary: str, response_summary: str) -> None:
        """Write task completion to the daily report."""
        try:
            from nowledge_graph_server.utils.time_partitioning import _get_time_partitioned_path

            now = datetime.now(timezone.utc)
            report_file = _get_time_partitioned_path(self._reports_dir, now, "md")
            report_file.parent.mkdir(parents=True, exist_ok=True)

            with open(report_file, "a", encoding="utf-8") as f:
                f.write(f"\n### Task completed at {now.strftime('%H:%M UTC')}\n")
                f.write(f"**Prompt:** {task_summary}...\n")
                f.write(f"**Response:** {response_summary}...\n")

        except Exception as e:
            logger.warning("Failed to write task to report", error=str(e))

    async def write_daily_header(self) -> None:
        """Write today's report header if not already written."""
        try:
            from nowledge_graph_server.utils.time_partitioning import _get_time_partitioned_path

            now = datetime.now(timezone.utc)
            report_file = _get_time_partitioned_path(self._reports_dir, now, "md")

            if report_file.exists():
                return

            report_file.parent.mkdir(parents=True, exist_ok=True)
            with open(report_file, "w", encoding="utf-8") as f:
                f.write(f"# Knowledge Agent Report - {now.strftime('%Y-%m-%d')}\n\n")
                f.write(f"Session started at {now.strftime('%H:%M UTC')}\n\n")

        except Exception as e:
            logger.warning("Failed to write daily header", error=str(e))
