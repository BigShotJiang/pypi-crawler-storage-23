"""AsyncIO-based scheduler for the Knowledge Agent.

Features:
- Event-driven task queue with debouncing
- Scheduled periodic tasks (daily briefing, weekly community detection)
- Rate limiting to respect individual LLM subscription limits
- State survives restart via the agent session's persistent state
- Non-blocking — runs as asyncio background tasks
"""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, time, timedelta, timezone
from enum import Enum
from typing import Any, Callable, Coroutine, Dict, List, Optional

import structlog

logger = structlog.get_logger(__name__)

# Rate limit: max LLM task executions per hour
MAX_TASKS_PER_HOUR = 15

# Token budget defaults (used if settings file is missing).
# Actual limits are read from app-settings.json via settings_reader.
_DEFAULT_MAX_TOKENS_PER_HOUR = 500_000
_DEFAULT_MAX_TOKENS_PER_DAY = 2_000_000

# Debounce window for batching event-driven tasks (seconds)
DEBOUNCE_SECONDS = 30

# Per-thread cooldown: skip re-analysis if analyzed within this window.
# Prevents heartbeat-driven repeat processing of unchanged threads.
_THREAD_COOLDOWN_SECONDS = 60 * 60  # 60 minutes


class TaskPriority(Enum):
    HIGH = 1      # User-triggered, flags
    NORMAL = 2    # Event-driven (memory_created)
    LOW = 3       # Scheduled background tasks


class AgentTask:
    """A task to be executed by the agent."""

    def __init__(
        self,
        task_type: str,
        prompt: str,
        *,
        priority: TaskPriority = TaskPriority.NORMAL,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.task_type = task_type
        self.prompt = prompt
        self.priority = priority
        self.metadata = metadata or {}
        self.created_at = datetime.now(timezone.utc)

    def __repr__(self) -> str:
        return f"AgentTask({self.task_type}, priority={self.priority.name})"


class ScheduledJob:
    """A periodically scheduled job."""

    def __init__(
        self,
        name: str,
        task_factory: Callable[[], AgentTask],
        schedule_time: time,  # Local time of day to run
        interval_days: int = 1,
    ) -> None:
        self.name = name
        self.task_factory = task_factory
        self.schedule_time = schedule_time
        self.interval_days = interval_days
        self.last_fired: Optional[datetime] = None

    def should_fire(self, now: datetime, last_fired_str: Optional[str] = None) -> bool:
        """Check if this job should fire now.

        Uses calendar-date comparison in LOCAL time, not elapsed duration.
        This ensures a job scheduled at 5 AM fires at 5 AM local time the
        next calendar day, regardless of what UTC hour the last run fell on.
        """
        now_local = now.astimezone()  # Convert to local time

        # Use persisted last_fired if available
        if last_fired_str:
            try:
                self.last_fired = datetime.fromisoformat(last_fired_str)
            except (ValueError, TypeError):
                pass

        if self.last_fired:
            last_fired_local = self.last_fired.astimezone()
            # Compare calendar dates in local time
            days_since = (now_local.date() - last_fired_local.date()).days
            if days_since < self.interval_days:
                return False

        # Check if current time is past the scheduled time today
        scheduled_today = now_local.replace(
            hour=self.schedule_time.hour,
            minute=self.schedule_time.minute,
            second=0,
            microsecond=0,
        )

        return now_local >= scheduled_today

    def mark_fired(self) -> str:
        """Mark as fired and return ISO timestamp for persistence."""
        self.last_fired = datetime.now(timezone.utc)
        return self.last_fired.isoformat()


class AgentScheduler:
    """Manages scheduled and event-driven agent tasks."""

    def __init__(self) -> None:
        self._task_queue: asyncio.Queue[AgentTask] = asyncio.Queue()
        self._scheduled_jobs: List[ScheduledJob] = []
        self._running = False
        self._event_loop_task: Optional[asyncio.Task] = None
        self._schedule_loop_task: Optional[asyncio.Task] = None

        # Rate limiting
        self._task_timestamps: List[datetime] = []

        # Budget paused flag: True when daily/hourly budget is exceeded
        # Token records are now in the centralized token_tracker module.
        self._budget_paused = False

        # Debounce buffer for event-driven batching
        self._pending_events: Dict[str, List[Dict[str, Any]]] = {}
        self._debounce_task: Optional[asyncio.Task] = None

        # Separate debounce for WM refresh (longer window — 5 minutes)
        self._wm_debounce_task: Optional[asyncio.Task] = None

        # Callback to execute tasks
        self._task_executor: Optional[Callable[[AgentTask], Coroutine[Any, Any, str]]] = None

        # File-based state persistence
        self._state_path: Optional[Any] = None  # Path to scheduler.json
        self._state_cache: Dict[str, Any] = {}

        # One-time scheduled tasks (agent-created follow-ups)
        self._one_time_tasks: Dict[str, Dict[str, Any]] = {}

    def configure(
        self,
        *,
        task_executor: Callable[[AgentTask], Coroutine[Any, Any, str]],
        state_path: Optional[Any] = None,
        # Legacy callbacks (kept for compatibility, prefer state_path)
        get_state: Optional[Callable[[str, Any], Any]] = None,
        set_state: Optional[Callable[[str, Any], None]] = None,
    ) -> None:
        """Wire up the scheduler to the agent session."""
        self._task_executor = task_executor

        if state_path is not None:
            from pathlib import Path
            self._state_path = Path(state_path)
            self._state_path.parent.mkdir(parents=True, exist_ok=True)
            self._load_state_file()
            logger.info("Scheduler configured with file-based state", path=str(self._state_path))

    def _load_state_file(self) -> None:
        """Load scheduler state from JSON file."""
        if self._state_path and self._state_path.exists():
            try:
                self._state_cache = json.loads(self._state_path.read_text())
                # Restore one-time tasks from state
                self._one_time_tasks = self._state_cache.pop("one_time_tasks", {})
                # Prune expired thread_analyzed_* entries to prevent state bloat
                self._prune_thread_cooldowns()
                logger.info(
                    "Scheduler state loaded",
                    state=self._state_cache,
                    one_time_tasks=len(self._one_time_tasks),
                )
            except (json.JSONDecodeError, OSError) as e:
                logger.warning("Failed to load scheduler state, starting fresh", error=str(e))
                self._state_cache = {}
        else:
            self._state_cache = {}

    def _prune_thread_cooldowns(self) -> None:
        """Remove thread_analyzed_* entries older than the cooldown window.

        These entries accumulate as threads are analyzed. Without pruning,
        scheduler.json grows unboundedly over months of use.
        """
        now = datetime.now(timezone.utc)
        expired = []
        for key, val in self._state_cache.items():
            if not key.startswith("thread_analyzed_"):
                continue
            try:
                ts = datetime.fromisoformat(val)
                if (now - ts).total_seconds() > _THREAD_COOLDOWN_SECONDS:
                    expired.append(key)
            except (ValueError, TypeError):
                expired.append(key)  # Remove malformed entries too
        if expired:
            for key in expired:
                del self._state_cache[key]
            logger.info("Pruned expired thread cooldowns", count=len(expired))

    def _save_state_file(self) -> None:
        """Save scheduler state to JSON file."""
        if self._state_path:
            try:
                data = {**self._state_cache}
                if self._one_time_tasks:
                    data["one_time_tasks"] = self._one_time_tasks
                self._state_path.write_text(json.dumps(data, indent=2))
            except OSError as e:
                logger.error("Failed to save scheduler state", error=str(e))

    def _get_state(self, key: str, default: Any = None) -> Any:
        """Get persisted state value."""
        return self._state_cache.get(key, default)

    def _set_state(self, key: str, value: Any) -> None:
        """Set and persist state value."""
        self._state_cache[key] = value
        self._save_state_file()

    def add_scheduled_job(self, job: ScheduledJob) -> None:
        self._scheduled_jobs.append(job)

    def add_one_time_task(
        self,
        task_id: str,
        scheduled_at: str,
        prompt: str,
        *,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Schedule a one-time task for future execution.

        Args:
            task_id: Unique identifier for the task.
            scheduled_at: ISO 8601 timestamp when to fire.
            prompt: Prompt to send to the agent.
            metadata: Optional metadata (related_memory_ids, etc.).
        """
        self._one_time_tasks[task_id] = {
            "scheduled_at": scheduled_at,
            "prompt": prompt,
            "metadata": metadata or {},
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        self._save_state_file()
        logger.info(
            "One-time task scheduled",
            task_id=task_id,
            scheduled_at=scheduled_at,
        )

    @property
    def pending_one_time_tasks(self) -> Dict[str, Dict[str, Any]]:
        """Return pending one-time tasks (read-only copy)."""
        return dict(self._one_time_tasks)

    async def start(self) -> None:
        """Start the scheduler loops."""
        if self._running:
            return

        self._running = True
        self._event_loop_task = asyncio.create_task(self._event_loop())
        self._schedule_loop_task = asyncio.create_task(self._schedule_loop())
        logger.info("Agent scheduler started", jobs=len(self._scheduled_jobs))

    async def stop(self) -> None:
        """Stop the scheduler."""
        self._running = False

        if self._event_loop_task:
            self._event_loop_task.cancel()
        if self._schedule_loop_task:
            self._schedule_loop_task.cancel()
        if self._debounce_task:
            self._debounce_task.cancel()
        if self._wm_debounce_task:
            self._wm_debounce_task.cancel()

        logger.info("Agent scheduler stopped")

    # ------------------------------------------------------------------
    # Event-driven triggers (called from memory_operations, etc.)
    # ------------------------------------------------------------------

    async def on_memory_created(self, memory_id: str) -> None:
        """Called when a new memory is created. Batches with debounce."""
        self._buffer_event("memory_created", {"memory_id": memory_id})

    async def on_evolves_detected(self, edge_id: str) -> None:
        """Called when an EVOLVES edge is detected."""
        self._buffer_event("evolves_detected", {"edge_id": edge_id})

    async def on_thread_synced(self, thread_id: str) -> None:
        """Called when a thread is synced."""
        self._buffer_event("thread_synced", {"thread_id": thread_id})

    async def on_memory_created_for_kg(self, memory_id: str) -> None:
        """Called when a new memory is created — queues for background KG extraction."""
        self._buffer_event("kg_extraction", {"memory_id": memory_id})

    async def on_memory_created_for_wm(self, memory_id: str) -> None:
        """Called when a new memory is created — queues Working Memory refresh.

        Uses a separate debounce buffer (wm_refresh) with a longer window
        so multiple rapid memory creations batch into a single WM refresh.
        """
        self._buffer_event("wm_refresh", {"memory_id": memory_id})

    def _buffer_event(self, event_type: str, data: Dict[str, Any]) -> None:
        """Buffer an event for debounced batching."""
        if event_type not in self._pending_events:
            self._pending_events[event_type] = []

        # Dedup: for thread_synced, skip if same thread_id is already buffered
        if event_type == "thread_synced":
            tid = data.get("thread_id")
            if tid and any(e.get("thread_id") == tid for e in self._pending_events[event_type]):
                logger.debug("Thread already buffered, dedup", thread_id=tid)
                return

        self._pending_events[event_type].append(data)

        # WM refresh uses a separate, longer debounce (5 minutes)
        if event_type == "wm_refresh":
            if self._wm_debounce_task and not self._wm_debounce_task.done():
                self._wm_debounce_task.cancel()
            self._wm_debounce_task = asyncio.create_task(self._flush_wm_after_debounce())
            return

        # Reset debounce timer for other events
        if self._debounce_task and not self._debounce_task.done():
            self._debounce_task.cancel()

        self._debounce_task = asyncio.create_task(self._flush_after_debounce())

    async def _flush_after_debounce(self) -> None:
        """Wait for debounce window, then flush buffered events as tasks."""
        await asyncio.sleep(DEBOUNCE_SECONDS)
        await self._flush_pending_events()

    async def _flush_wm_after_debounce(self) -> None:
        """Wait for WM debounce window (5 min), then flush wm_refresh events."""
        await asyncio.sleep(300)  # 5 minutes
        await self._flush_pending_events(event_types=["wm_refresh"])

    async def _flush_pending_events(
        self, *, event_types: Optional[List[str]] = None
    ) -> None:
        """Convert buffered events into agent tasks.

        Args:
            event_types: If provided, only flush these types (leave others buffered).
                         If None, flush all pending events.
        """
        from .task_prompts import build_event_prompt, build_wm_refresh_prompt

        types_to_flush = event_types or list(self._pending_events.keys())

        for event_type in types_to_flush:
            events = self._pending_events.get(event_type, [])
            if not events:
                continue

            # Per-thread cooldown: skip threads analyzed within the last 60 min.
            # Prevents heartbeat-driven re-analysis of the same unchanged thread.
            if event_type == "thread_synced":
                now = datetime.now(timezone.utc)
                fresh = []
                for e in events:
                    tid = e.get("thread_id", "")
                    last_str = self._get_state(f"thread_analyzed_{tid}", None)
                    if last_str:
                        try:
                            last_dt = datetime.fromisoformat(last_str)
                            elapsed = (now - last_dt).total_seconds()
                            if elapsed < _THREAD_COOLDOWN_SECONDS:
                                logger.debug(
                                    "Thread in cooldown, skipping",
                                    thread_id=tid,
                                    elapsed_min=round(elapsed / 60, 1),
                                )
                                continue
                        except (ValueError, TypeError):
                            pass
                    fresh.append(e)
                events = fresh
                if not events:
                    del self._pending_events[event_type]
                    continue

            metadata: Dict[str, Any] = {"event_count": len(events), "events": events}

            # Direct-function tasks: pass memory IDs in metadata for the executor
            if event_type == "kg_extraction":
                metadata["memory_ids"] = [
                    e.get("memory_id") for e in events if e.get("memory_id")
                ]

            # WM refresh: use dedicated prompt builder with memory count
            if event_type == "wm_refresh":
                prompt = build_wm_refresh_prompt(len(events))
                metadata["memory_ids"] = [
                    e.get("memory_id") for e in events if e.get("memory_id")
                ]
            else:
                prompt = build_event_prompt(event_type, events)

            task = AgentTask(
                task_type=event_type,
                prompt=prompt,
                priority=TaskPriority.NORMAL,
                metadata=metadata,
            )
            await self._task_queue.put(task)

            # Remove flushed events
            del self._pending_events[event_type]

        # If flushing all, clear everything (backward compat)
        if event_types is None:
            self._pending_events.clear()

    # ------------------------------------------------------------------
    # On-demand task submission
    # ------------------------------------------------------------------

    async def submit_task(self, task: AgentTask) -> None:
        """Submit a task to the queue."""
        await self._task_queue.put(task)

    # ------------------------------------------------------------------
    # Internal loops
    # ------------------------------------------------------------------

    async def _event_loop(self) -> None:
        """Process tasks from the queue."""
        while self._running:
            try:
                task = await asyncio.wait_for(self._task_queue.get(), timeout=5.0)
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break

            # Rate limit check
            if not self._check_rate_limit():
                logger.warning(
                    "Rate limit reached, deferring task",
                    task_type=task.task_type,
                )
                # Re-queue with delay
                await asyncio.sleep(60)
                await self._task_queue.put(task)
                continue

            # Execute task
            if self._task_executor:
                try:
                    logger.info("Executing agent task", task_type=task.task_type)
                    await self._task_executor(task)
                    self._task_timestamps.append(datetime.now(timezone.utc))
                except Exception as e:
                    logger.error(
                        "Agent task failed",
                        task_type=task.task_type,
                        error=str(e),
                    )

    async def _schedule_loop(self) -> None:
        """Check and fire scheduled jobs + one-time tasks."""
        while self._running:
            try:
                now = datetime.now(timezone.utc)

                for job in self._scheduled_jobs:
                    # Get last fired time from persistent state
                    state_key = f"last_{job.name}"
                    last_fired = self._get_state(state_key, None)

                    if job.should_fire(now, last_fired):
                        task = job.task_factory()
                        await self._task_queue.put(task)

                        # Persist the fired timestamp
                        fired_at = job.mark_fired()
                        self._set_state(state_key, fired_at)

                        logger.info(
                            "Scheduled job fired",
                            job=job.name,
                            fired_at=fired_at,
                        )

                # Check one-time tasks
                fired_ids = []
                for task_id, task_data in self._one_time_tasks.items():
                    try:
                        scheduled_at = datetime.fromisoformat(task_data["scheduled_at"])
                        if now >= scheduled_at:
                            agent_task = AgentTask(
                                task_type="scheduled_follow_up",
                                prompt=task_data["prompt"],
                                priority=TaskPriority.NORMAL,
                                metadata=task_data.get("metadata", {}),
                            )
                            await self._task_queue.put(agent_task)
                            fired_ids.append(task_id)
                            logger.info(
                                "One-time task fired",
                                task_id=task_id,
                            )
                    except (ValueError, KeyError) as e:
                        logger.warning(
                            "Invalid one-time task, removing",
                            task_id=task_id,
                            error=str(e),
                        )
                        fired_ids.append(task_id)

                # Remove fired tasks
                if fired_ids:
                    for tid in fired_ids:
                        self._one_time_tasks.pop(tid, None)
                    self._save_state_file()

                # Check every 60 seconds
                await asyncio.sleep(60)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("Schedule loop error", error=str(e))
                await asyncio.sleep(60)

    def _get_token_budgets(self) -> tuple[int, int]:
        """Read token budgets from settings (re-reads on each check so changes take effect immediately)."""
        try:
            from .settings_reader import read_knowledge_processing_settings
            settings = read_knowledge_processing_settings()
            return (
                settings.get("maxTokensPerHour", _DEFAULT_MAX_TOKENS_PER_HOUR),
                settings.get("maxTokensPerDay", _DEFAULT_MAX_TOKENS_PER_DAY),
            )
        except Exception:
            return (_DEFAULT_MAX_TOKENS_PER_HOUR, _DEFAULT_MAX_TOKENS_PER_DAY)

    def _check_rate_limit(self) -> bool:
        """Check if we're within the hourly rate limit AND token budget."""
        from . import token_tracker

        now = datetime.now(timezone.utc)
        cutoff = now - timedelta(hours=1)

        # Prune old timestamps
        self._task_timestamps = [
            ts for ts in self._task_timestamps if ts > cutoff
        ]

        if len(self._task_timestamps) >= MAX_TASKS_PER_HOUR:
            return False

        max_hour, max_day = self._get_token_budgets()

        # Check token budgets (0 = unlimited)
        if self._budget_paused:
            # Re-check BOTH hourly and daily budgets before un-pausing.
            # Previously only checked hourly — daily limit was silently ignored.
            hourly_tokens = token_tracker.tokens_this_hour()
            daily_tokens = token_tracker.tokens_today()
            if (max_hour > 0 and hourly_tokens >= max_hour) or (
                max_day > 0 and daily_tokens >= max_day
            ):
                return False
            self._budget_paused = False
            logger.info(
                "Token budget recovered, resuming tasks",
                hourly_tokens=hourly_tokens,
                daily_tokens=daily_tokens,
            )

        return True

    def record_token_usage(
        self, input_tokens: int, output_tokens: int, source: str = "knowledge_agent"
    ) -> None:
        """Record token usage from a completed task.

        Called by the task executor after each LLM task completes.
        Delegates to the centralized token_tracker, then checks if
        hourly or daily budgets are exceeded and pauses if so.
        """
        from . import token_tracker

        token_tracker.record(input_tokens, output_tokens, source=source)

        max_hour, max_day = self._get_token_budgets()
        hourly_tokens = token_tracker.tokens_this_hour()
        daily_tokens = token_tracker.tokens_today()

        if max_hour > 0 and hourly_tokens > max_hour:
            self._budget_paused = True
            logger.warning(
                "Hourly token budget exceeded, pausing background tasks",
                hourly_tokens=hourly_tokens,
                budget=max_hour,
            )

        if max_day > 0 and daily_tokens > max_day:
            self._budget_paused = True
            logger.warning(
                "Daily token budget exceeded, pausing background tasks",
                daily_tokens=daily_tokens,
                budget=max_day,
            )

    @property
    def tokens_this_hour(self) -> int:
        from . import token_tracker
        return token_tracker.tokens_this_hour()

    @property
    def tokens_today(self) -> int:
        from . import token_tracker
        return token_tracker.tokens_today()

    @property
    def is_budget_paused(self) -> bool:
        return self._budget_paused

    @property
    def max_tokens_per_hour(self) -> int:
        return self._get_token_budgets()[0]

    @property
    def max_tokens_per_day(self) -> int:
        return self._get_token_budgets()[1]

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    @property
    def queue_size(self) -> int:
        return self._task_queue.qsize()

    @property
    def tasks_this_hour(self) -> int:
        cutoff = datetime.now(timezone.utc) - timedelta(hours=1)
        return sum(1 for ts in self._task_timestamps if ts > cutoff)

    @property
    def is_running(self) -> bool:
        return self._running
