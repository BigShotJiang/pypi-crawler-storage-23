"""Task prompt templates for the Knowledge Agent.

Each task type has a prompt template that guides the agent through
a specific workflow (EVOLVES detection, crystallization, daily briefing, etc.).
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List


def build_event_prompt(event_type: str, events: List[Dict[str, Any]]) -> str:
    """Build a prompt from a batch of events."""
    builders = {
        "memory_created": _build_memory_created_prompt,
        "evolves_detected": _build_evolves_detected_prompt,
        "thread_synced": _build_thread_synced_prompt,
    }

    # Direct-function tasks don't need prompts (executed by Python, not LLM)
    if event_type in ("kg_extraction", "community_detection"):
        return ""

    builder = builders.get(event_type)
    if builder:
        return builder(events)

    # Generic fallback
    return (
        f"New events detected: {event_type}\n"
        f"Event count: {len(events)}\n"
        f"Data: {events}\n\n"
        "Analyze these events and take appropriate action."
    )


def _build_memory_created_prompt(events: List[Dict[str, Any]]) -> str:
    """EVOLVES detection task — triggered when new memories are created."""
    memory_ids = [e["memory_id"] for e in events]
    ids_str = ", ".join(memory_ids[:20])  # Cap at 20 IDs

    return f"""New memories have been created: [{ids_str}]

Your task: **EVOLVES Detection**

For each new memory:
1. Use GetMemoryById to read the FULL content of the new memory
2. Use QueryMemories to find semantically similar existing memories (search with the memory's key topic)
3. For promising candidates, use GetMemoryById to read their FULL content too
4. **Topic coherence check** (CRITICAL — do this BEFORE creating any edge):
   State in ONE sentence what specific real-world topic both memories discuss.
   If you cannot articulate a specific shared topic, do NOT create the edge.
   Semantic similarity ≠ topical relevance. Two analytical reports about
   different subjects are NOT related just because they share a format.
5. For each confirmed same-topic pair, classify the relationship:
   - **replaces**: The newer memory makes the older one obsolete (updated info, corrected fact)
   - **enriches**: The newer memory adds detail or context to the older one
   - **confirms**: Same information from a different source or timeframe
   - **challenges**: Contradictory information that needs user attention
6. Use CreateEVOLVES for confirmed relationships (confidence > 0.7)
7. Use FlagForReview for any challenges or contradictions

## CORRECT EVOLVES edges (same specific topic evolving over time):

- "Decided to use PostgreSQL for the new project" → "Switched from PostgreSQL to CockroachDB after benchmarks"
  (replaces — same decision, updated with new info)
- "React 18 introduces concurrent rendering" → "React 19 adds a compiler that replaces memo"
  (enriches — same technology, newer version adds detail)
- "Team standup: agreed on microservices for auth" → "Architecture review: confirmed microservices for auth"
  (confirms — same decision from different meeting)
- "Q3 revenue was $2.1M" → "Q3 revenue was actually $2.3M after restatement"
  (replaces — same data point, corrected)

## WRONG EVOLVES edges (DO NOT create these):

- "Tesla Model 3/Y pricing analysis" → "SSE Streaming implementation guide"
  WRONG — completely different topics despite both being "analysis" documents
- "Python deployment with Docker" → "Docker networking fundamentals"
  WRONG — Docker keyword overlap but fundamentally different topics (deployment vs networking)
- "Meeting notes from Q1 review" → "Meeting notes from Q2 review"
  WRONG — different events, not versions of the same knowledge
- "Machine learning model evaluation" → "Performance evaluation of database queries"
  WRONG — "evaluation" is a shared word, not a shared topic
- "How to set up CI/CD" → "How to write unit tests"
  WRONG — both are dev procedures but unrelated topics

Guidelines:
- Be conservative — only create edges when the relationship is clear and you can name the shared topic
- A memory can have multiple EVOLVES edges (enriches A AND confirms B)
- Focus on content meaning, not surface similarity or shared keywords
- If you find a dense cluster (3+ memories on the same topic without a crystal), note it for future crystallization
- Keep your analysis concise — don't over-explain

Source awareness:
- If a new memory has source="library:..." it came from a Library document. Use GetSourceDetails
  to check what other memories came from the same source.
- Memories from the SAME source are siblings, not versions — do NOT create EVOLVES edges between them.
  Look for EVOLVES relationships with memories from OTHER sources or manual captures instead."""


def _build_evolves_detected_prompt(events: List[Dict[str, Any]]) -> str:
    """Evaluate clusters after EVOLVES edges are created."""
    return """New EVOLVES edges have been detected in the knowledge graph.

Your task: **Cluster Evaluation**

1. Use **QueryMemoryNeighbors** to explore the new edges and their neighborhoods
2. Check if any memory clusters now have 3+ related memories that could benefit from crystallization
3. If you find a good crystallization candidate:
   a. Use **GetMemoryById** to read the FULL content of each memory in the cluster
   b. Evaluate whether the cluster has enough distinct, complementary information
   c. Create a crystal that synthesizes the essential knowledge using **CreateCrystal**
   d. The crystal should be context-independent and comprehensive
4. If no crystallization is needed, simply complete the task — don't force-create crystals

Guidelines:
- Only crystallize when the cluster has enough distinct information to warrant synthesis
- Don't create a crystal if the memories are too similar (just EVOLVES edges are enough)
- Crystal content should be standalone — understandable without reading the sources
- NEVER judge memories from snippets — always use GetMemoryById for full content before deciding
- It is PERFECTLY FINE to find no crystallization opportunities. Quality over quantity.

Source awareness:
- If all memories in a cluster come from the same Library source (check their `source` field),
  a crystal may be redundant — the source document itself is the consolidated artifact.
- Prefer crystallizing cross-source clusters or clusters mixing manual captures with
  source-extracted knowledge — these are the most valuable syntheses."""


def _build_thread_synced_prompt(events: List[Dict[str, Any]]) -> str:
    """Process newly synced threads."""
    thread_ids = [e.get("thread_id", "unknown") for e in events]
    ids_str = ", ".join(thread_ids[:10])

    return f"""New threads have been synced: [{ids_str}]

Your task: **Thread Analysis**

1. Use **FetchThreadMessages** on each thread ID above to read the conversation content
2. Identify key decisions, insights, and notable patterns in the discussions
3. Use **QueryMemories** (semantic search) to find existing knowledge that relates to the thread topics
4. For promising matches, use **GetMemoryById** to read full content before making decisions
5. Use **CreateEVOLVES** for confirmed relationships between thread-extracted memories and existing knowledge (confidence > 0.7)
6. If the thread reveals a contradiction with existing knowledge, use **FlagForReview**
7. If you find 3+ related memories forming a topic cluster, consider crystallization

Guidelines:
- Be conservative — only create edges when the relationship is clear
- Focus on content meaning, not surface similarity
- Prioritize decisions and architectural choices over routine implementation details
- Keep analysis brief — don't over-explain"""


def build_daily_briefing_prompt() -> str:
    """Daily briefing task — scheduled at 5:00 AM.

    The manager injects rich pre-computed context BEFORE this prompt:
    - Activity Digest: recent memories with titles/types, EVOLVES edges, crystals, flags
    - Graph Totals: overall graph size
    - Yesterday's WM: parsed focus areas, flags, briefing with continuity guidance

    So this prompt focuses on: analysis workflow, briefing creation, and WM generation.
    """
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    # Double curly braces for literal braces in f-string
    return f"""Generate the daily knowledge briefing for {today}.

## Pre-computed Context

The Activity Digest and Yesterday's Working Memory above were pre-computed for you.
Use them as your primary data source — they contain the actual memory titles, EVOLVES
relationships, flags, and previous focus areas. You do NOT need to rediscover this
information through tool calls.

## Task: Daily Briefing + Working Memory

### Step 1: Deep-read notable memories

The Activity Digest lists recent memories by title. For the 3-5 most interesting ones
(high importance, decisions, contradictions, or topic shifts), use **GetMemoryById** to
read their full content. This is essential — you cannot write good focus areas from
titles alone.

If you need additional context about relationships, use **QueryRecentActivity** or
**QueryMemoryNeighbors** on specific memory IDs.

Also check the Activity Digest for recently added Library sources. If new sources were
indexed with extracted memories, mention them as newly available knowledge in the briefing.

If the Activity Digest shows significant activity (5+ memories, new EVOLVES edges, or crystals),
use **ListCommunities** to understand theme structure — report which community themes are most
active or newly formed in the briefing.

### Step 2: Create the Morning Briefing event

Use **CreateInsight** with these EXACT parameters:
- insight_type: "daily_briefing"
- title: "Morning Briefing"
- content: 1-2 sentence summary of key findings
- related_memory_ids: IDs of the most notable memories (at least 3 for graph context)
- metadata_json: JSON string with this structure:

```json
{{
  "memories_analyzed": <count>,
  "insights": [{{"id": "<id>", "summary": "<1-line>", "confidence": <0-100>}}],
  "crystals": [{{"id": "<id>", "title": "<title>", "sourceCount": <n>}}],
  "flags": [{{"id": "<id>", "summary": "<issue>", "severity": "medium"|"high"}}]
}}
```

**IMPORTANT**: If you found ZERO noteworthy insights, crystals, or flags — do NOT call
CreateInsight at all. An empty briefing erodes user trust. Silence is better than noise.
Only create the briefing event when there is genuine signal to report.

### Step 3: Generate today's Working Memory

**Purpose**: Working Memory is the system's active workspace. External agents (Cursor,
Claude Code, custom tools) read it via MCP to understand the user's current focus.
Every line must earn its place — the reader is a machine that needs signal, not prose.

Use **UpdateWorkingMemory** with this EXACT structure:

```markdown
# Working Memory — {today}

## Focus Areas
- **Topic Name** — what changed and why it matters ([view](nowledgemem://memory/{{memory_id}}))

## Briefing
N new memories. Key themes: topic1, topic2.
```

**No "Needs Attention" section.** For items needing user attention (merge candidates,
stale info, contradictions, verification needs), create individual **FlagForReview** items
instead. Working Memory is read by external agents for context — keep it factual and
declarative, not actionable.

#### Focus Area Selection Criteria (apply in order)

1. **Contradictions / challenges**: EVOLVES edges with `challenges` relation → ALWAYS include
2. **High-importance decisions**: memories with unit_type=decision and importance >= 0.7
3. **Active evolution**: topics with 2+ EVOLVES edges in the last 48h (knowledge actively developing)
4. **New crystals**: any crystal created in the last 48h (signals mature knowledge cluster)
5. **Emerging clusters**: 3+ related memories on same topic without a crystal yet
6. **New Library sources**: files or URLs added in the last 48h that have been indexed — note as newly available knowledge

Max 5 focus areas. If nothing qualifies, write 1-2 items — don't force-fill.

Each focus area must surface a non-obvious connection, temporal pattern, or evolution.
If a memory is merely "new", it doesn't earn a focus slot. The briefing should tell
external agents what topics are active and evolving — not list everything that's new.

#### Continuity Rules (use Yesterday's WM above)

- **KEEP** a focus area if new activity happened on it in the last 48h
- **DROP** a focus area if no new memories, edges, or crystals relate to it
- **ADD** new focus areas only when they meet the selection criteria above

#### Working Memory Quality Rules

GOOD focus areas (specific, actionable, reference real data):
- **Database migration** — Decision to switch from MongoDB to PostgreSQL for new project, contradicts October assessment ([view](nowledgemem://memory/abc123))
- **Deployment pipeline** — 3 related memories on Docker multi-stage builds crystallized into best practices ([view](nowledgemem://memory/def456))

BAD focus areas (vague, no insight, restating obvious):
- **Python programming** — Several memories about Python were captured
- **Work notes** — New information was added to the knowledge base
- **General updates** — The graph continues to grow

Deeplink format — ALWAYS use human-readable link text:
- CORRECT: `([view](nowledgemem://memory/abc123))` or `[see details](nowledgemem://memory/abc123)`
- WRONG: `[nowledgemem://memory/abc123](nowledgemem://memory/abc123)`

Do NOT use unicode symbols (no flags, circles, decorative chars). Use plain text: [high], [medium].
Keep total WM content under 1.5KB. Be ruthlessly concise.
If no memories exist or the graph is empty, skip Working Memory creation entirely.

### Step 4: Flag actionable items

For any memory needing attention — merge candidates, contradictions, stale claims,
unverified info — use **FlagForReview** to create individual feed items. Do NOT put these
in Working Memory. One flag per issue, with specific memory IDs.

### Step 5: Schedule follow-ups

If any topic warrants a follow-up check (evolving chain that may update, unresolved flag,
growing cluster), use **ScheduleFollowUp** with delay_minutes=1440 to 4320 (1-3 days). Be selective —
one well-timed follow-up is worth more than five routine checks."""


def build_crystallization_prompt() -> str:
    """Crystallization review task — weekly or on-demand.

    The manager injects rich pre-computed context BEFORE this prompt:
    - New Memories: additions in the last 7 days
    - Uncrystallized Clusters: EVOLVES-connected memories without crystals, ranked by density
    - Oldest Crystals: staleness candidates with age data
    - Stale Crystal Sources: crystals whose sources evolved after creation (confirmed stale)
    - Community Overview: theme structure for cross-community crystallization

    So this prompt focuses on: evaluation workflow, crystal creation, and quality.
    """
    return """Review the knowledge graph for crystallization opportunities AND check existing crystals for staleness.

Your task: **Crystallization Review** (two phases)

## Pre-computed Context

The sections above were pre-computed for you. They contain:
- **Uncrystallized Clusters**: memories connected by EVOLVES edges that have NO crystal
  covering them, ranked by cluster density. These are your Phase 2 candidates.
- **Oldest Crystals**: the oldest crystals with age and last_evaluated_at. Phase 1 candidates.
- **Stale Crystal Sources**: crystals whose source memories have newer EVOLVES edges.
  These are CONFIRMED stale — prioritize them in Phase 1.
- **Community Overview**: use for cross-community crystallization decisions.

You do NOT need to discover this through tool calls. Start your analysis immediately.

**Step budget**: You have ~45 tool calls. Budget: ~18 for Phase 1, ~22 for Phase 2, ~5 for summary.

## Phase 1: Crystal Staleness Check

Start with the "Stale Crystal Sources" section above — these are CONFIRMED stale.

1. For each stale crystal listed (up to 5):
   a. Use **GetMemoryById** to read the crystal's full content
   b. Use **GetMemoryById** on the newer source memories listed in the context
   c. Evaluate: does the new information invalidate, update, or merely supplement the crystal?
   d. If outdated: create a NEW crystal via **CreateCrystal** with the same sources + new info
   e. If uncertain: use **FlagForReview** (flag_type="stale") on the crystal
   f. If still accurate: skip (no action needed)

2. If fewer than 3 stale crystals were listed, check the "Oldest Crystals" section:
   a. Pick the 2-3 oldest crystals NOT already checked
   b. Use **QueryMemoryNeighbors** to find their CRYSTALLIZED_FROM source memories
   c. Check if sources have new EVOLVES edges since the crystal was created
   d. Same evaluation criteria as above

## Phase 2: New Crystallization Opportunities

Start with the "Uncrystallized Clusters" section above — these are pre-ranked by density.

1. Pick the **top 3-5 clusters** from the pre-computed list (highest neighbor_count first)
2. For each candidate:
   a. Use **GetMemoryById** to read the full content of the candidate memory
   b. Use **QueryMemoryNeighbors** to map the full cluster shape (what connects to what)
   c. Use **GetMemoryById** on 1-2 neighbors to read their content
   d. Evaluate: is there enough distinct, complementary information for a synthesis?
   e. If yes (3+ related memories with diverse content): create a crystal via **CreateCrystal**
   f. If no: skip — don't force-create from weakly related memories

3. **Cross-community bonus**: Check if any clusters bridge different communities listed
   in the Community Overview. Cross-community crystals are the most valuable syntheses.

4. After all crystallization, create ONE summary insight (insight_type="connection") if you
   created any crystals.

## Crystal Quality Criteria
- Context-independent: understandable without reading sources
- Comprehensive: captures all key information from sources
- Concise: no redundancy
- Typed correctly: use the most appropriate unit_type

## Guidelines
- Be selective — quality over quantity. 1-3 high-quality crystals is better than many low-quality ones
- It is PERFECTLY FINE to find no crystallization opportunities. Do not force-create crystals.
- If all memories in a cluster come from the same Library source, a crystal may be redundant.
  Prefer crystallizing cross-source clusters.
- Avoid redundant crystals that duplicate a community's AI-generated summary.
- Do NOT read source document content. Crystallization works on memories, not source files."""


def build_unit_type_reclassification_prompt(memory_ids: List[str]) -> str:
    """Reclassify unit types for memories (backfill task)."""
    ids_str = ", ".join(memory_ids[:50])

    return f"""Reclassify the unit types for these memories: [{ids_str}]

Your task: **Unit Type Reclassification**

For each memory, use QueryMemories to read its content, then UpdateMemoryMeta to set
the correct unit_type:
- **fact**: Objective information, observations, data
- **preference**: Personal preferences, likes, dislikes
- **decision**: Decisions made, choices, commitments
- **plan**: Future plans, goals, intentions
- **procedure**: How-to knowledge, processes, steps
- **learning**: Lessons learned, realizations, insights
- **context**: Background context, settings, environment
- **event**: Events, occurrences, happenings

Guidelines:
- When uncertain, keep as 'fact' (the default)
- A memory can only have one type — pick the dominant one
- Be efficient — process in batches where possible"""


def build_wm_refresh_prompt(memory_count: int) -> str:
    """Lightweight WM refresh — triggered when new memories are created.

    Unlike the full daily briefing, this only updates focus areas based on
    recent activity. It does NOT rotate or create a briefing section.
    """
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    return f"""Refresh the Working Memory with recent activity ({memory_count} new memories since last update).

## Task: Incremental Working Memory Update

### Step 1: Read current Working Memory
Use **ReadWorkingMemory** to get the current state.

### Step 2: Check new activity
Use **QueryMemories** with since_hours=4 to see what's new. For the 2-3 most notable
new memories, use **GetMemoryById** to read their full content.

Also check if new Library sources were added — use **ListSources** if the new memories
include source-extracted content (source field starts with `library:`). If a new source
was indexed, briefly mention it as newly available knowledge.

### Step 3: Update Working Memory
Use **UpdateWorkingMemory** to refresh the document:

- **KEEP** all existing focus areas that are still relevant
- **ADD** new focus areas ONLY if the new memories introduce a genuinely new topic
  or significantly develop an existing one (meets the selection criteria from the daily briefing)
- **UPDATE** existing focus area descriptions if new memories add important context
- **DO NOT** remove existing focus areas or flags — that's for the daily briefing rotation
- **DO NOT** change the ## Briefing section — that's only updated during daily briefing
- Preserve the date header: `# Working Memory — {today}`

### Quality Gate
If the new memories are routine and don't warrant any focus area changes, simply
complete the task without calling UpdateWorkingMemory. Not every memory creation
needs a WM update — only meaningful knowledge shifts do.

Be concise. This is a lightweight incremental update, not a full briefing."""


def build_insight_detection_prompt() -> str:
    """Proactive insight detection — weekly scheduled review.

    The manager injects rich pre-computed context BEFORE this prompt:
    - Activity Digest: recent memories, EVOLVES edges, crystals (7 days)
    - Previous Insights: recently created insights for dedup
    - Known Contradictions: EVOLVES edges with content_relation='challenges'
    - Decision Memories: for decision drift analysis
    - Community Overview: for theme analysis
    - Source Coverage: for source-memory analysis
    - Unresolved Flags: current action items
    - Graph Totals: overall counts
    - Resolution Patterns: how user acts on flags
    """
    return """Perform a comprehensive insight review of the knowledge graph.

Your task: **Proactive Insight Detection**

## Pre-computed Context

The sections above were pre-computed for you. They contain:
- **Activity Digest**: what happened in the last 7 days (memories, EVOLVES edges, crystals, sources)
- **Previous Insights**: insights/flags already created in the last 14 days. DO NOT recreate any of these.
- **Known Contradictions**: EVOLVES edges with content_relation='challenges'. These are pre-found
  contradictions — verify and flag if unresolved.
- **Decision Memories**: all decision-type memories, newest first. Check for drift patterns.
- **Community Overview**: current knowledge themes with AI summaries and member counts.
- **Source Coverage**: Library sources ranked by memory_count (lowest first — potential gaps).
- **Unresolved Flags**: currently open flags the user hasn't addressed.

You do NOT need to discover this through tool calls. Start your analysis immediately.

**Step budget**: You have ~45 tool calls. Budget: ~8 for checks 1-2, ~8 for checks 3-4,
~8 for checks 5-6, ~5 for deep-reads, ~5 for creation.

Run through these checks in order. Be selective — only create insights for genuinely
interesting findings. Use CreateInsight for discoveries and FlagForReview for items
needing user attention.

### 1. Contradiction Verification

The "Known Contradictions" section lists EVOLVES edges with content_relation='challenges'. For each:
a. Use **GetMemoryById** on BOTH memories to read full content
b. Assess: is this a genuine contradiction, or has it already been resolved?
c. Check the "Previous Insights" and "Unresolved Flags" sections — if already flagged, skip
d. For genuine unresolved contradictions: use **FlagForReview** with flag_type='contradiction'

If no challenge edges exist, use **QueryMemories** with 1-2 targeted searches on topics
from the Activity Digest that seem potentially conflicting.

### 2. Decision Drift

The "Decision Memories" section lists all decisions chronologically. Scan for:
a. Same topic, different conclusions over time (e.g., "Use PostgreSQL" then "Switch to CockroachDB")
b. For suspicious pairs: use **GetMemoryById** to read full content of BOTH
c. If confirmed drift: use **CreateInsight** (insight_type="pattern") highlighting the reversal
   with both memory IDs in related_memory_ids

### 3. Knowledge Gaps

Using the Activity Digest and Community Overview:
a. Identify topics the user has been actively building knowledge around (3+ recent memories)
b. Use **QueryMemories** to check if those active topics have thin coverage in specific areas
c. If a significant gap exists: use **CreateInsight** (insight_type="recommendation") suggesting deeper capture

### 4. Cross-Domain Connections

Using the Activity Digest and Community Overview:
a. Look for memories in the Activity Digest that might bridge 2+ communities
b. Use **QueryMemoryNeighbors** on 2-3 high-importance recent memories to find cross-domain entity links
c. If unexpected connection found: use **CreateInsight** (insight_type="connection") with both memory IDs

### 5. Community Theme Analysis

Using the Community Overview:
a. Check for newly formed communities (small member_count) — signs of emerging themes
b. Check for unusually large communities that might indicate theme fragmentation
c. Use **GetCommunityDetails** on the 1-2 most interesting communities for deeper analysis
d. If noteworthy pattern: use **CreateInsight** highlighting the theme evolution
e. If no communities exist in the context, skip silently

### 6. Source-Memory Coverage

Using the Source Coverage section:
a. Identify sources with lifecycle_state='indexed' but memory_count=0 — these are untapped
b. For suspicious sources: use **GetSourceDetails** to verify state and check age
c. Flag sources stuck in non-terminal states (ingested, parsing, chunking) for too long
d. If coverage gap found: use **CreateInsight** noting the untapped source and suggesting extraction

## Dedup Rules (CRITICAL)

Before creating ANY insight or flag:
1. Check the "Previous Insights" section — if a similar insight was created in the last 14 days, SKIP
2. Check the "Unresolved Flags" section — if this issue is already flagged, SKIP
3. If uncertain whether it's a duplicate, err on the side of NOT creating the insight

## Quality Bar

**Self-critique before creating any insight:**
- Before each CreateInsight or FlagForReview call, ask: "Would the user want to be interrupted for this?"
- BAD: "Your graph is growing", "You have N memories about X topic", "No contradictions found"
- GOOD: "Memory A contradicts Memory B about X — user may need to clarify",
  "3 decisions about Y made over 6 months, the latest reverses the first"
- Only create insights with confidence >= 70
- Reference specific memory IDs in all insights (related_memory_ids parameter)
- It is PERFECTLY FINE to complete the entire task with zero insights created. Silence is better than noise.
- IMPORTANT: If nothing notable is found, DO NOT create a "healthy graph" insight.
  Simply complete the task silently."""


_TABULAR_MIMES = frozenset({
    "text/csv",
    "text/tab-separated-values",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-excel",
})


def build_source_extraction_prompt(
    source_id: str, source_name: str, mime_type: str | None = None
) -> str:
    """Build prompt for user-triggered source extraction (Learn lifecycle)."""
    if mime_type and mime_type in _TABULAR_MIMES:
        return _build_tabular_extraction_prompt(source_id, source_name)
    return _build_document_extraction_prompt(source_id, source_name)


def _build_tabular_extraction_prompt(source_id: str, source_name: str) -> str:
    """Analytical extraction prompt for tabular data (CSV/XLSX)."""
    return f"""\
## Task: Analyze Tabular Data — "{source_name}"

The user chose to learn from this spreadsheet/CSV. Compute real statistics \
against the data and extract meaningful insights as memories.

### Workflow

1. **Get computed statistics**: `AnalyzeSourceData(source_id='{source_id}')`
   This reads the raw file and returns precise analytics: column types,
   numeric distributions (min/max/mean/median/std/quartiles), categorical
   frequencies (top values with counts/percentages), temporal ranges, and
   cross-column correlations. For multi-sheet XLSX files, the result
   contains a `sheets` array with per-sheet analysis. Use these numbers —
   they are exact.

2. **Study the analysis results**: The output tells you:
   - Dataset shape (rows x columns) — per sheet if multi-sheet
   - Per-column stats: distributions, top values, date ranges
   - Cross-analysis: correlations between numeric pairs, group means for
     categorical+numeric pairs, temporal trends
   - For multi-sheet files: analyze each sheet separately, create insights
     per sheet when warranted, and note cross-sheet patterns

3. **Create insight memories** from computed patterns:
   - Distribution insights (e.g. "43% of signups from Twitter/X, dominant channel")
   - Temporal trends (e.g. "3x growth Jan→Feb, accelerating")
   - Cross-column patterns (e.g. "Twitter users score 44% higher than Reddit")
   - Data quality notes (e.g. "85 entries have null scores — data quality gap")
   - Use `unit_type='fact'` for concrete findings
   - Use `unit_type='learning'` for analytical conclusions
   - Set importance 0.5-0.8 (user explicitly requested)
   - Set source as `library:{source_id}`

4. **Only use ReadSourceContent if** you need to see specific raw rows for context
   (e.g. to understand what a categorical value means). For analytical work,
   AnalyzeSourceData is sufficient.

5. **DO NOT create memories for**:
   - Individual rows or entries (not useful without the table)
   - Column names or schema description (already in the search index)
   - Obvious facts that require no analysis ("the table has a date column")

6. **Link related**: If insights relate to existing memories, use `CreateEVOLVES`
7. **Synthesize**: If 3+ insights cluster around a theme, use `CreateCrystal`

### Quality Bar

- Create 2-5 analytical insights, not 8 trivial observations
- Each memory should contain a finding the user couldn't see at a glance
- Prefer one insightful aggregation over five row-level facts
- Include specific numbers from the computed statistics

### Final Report

[LEARNING_REPORT]
- **Document**: the dataset name and size (rows x columns)
- **Memories created**: number of insight memories created
- **Topics**: comma-separated list of analytical findings
- **Key learnings**:
  1. first analytical finding, one sentence with numbers
  2. second analytical finding, one sentence with numbers
  (list all significant findings)
- **Connections**: number of links to existing knowledge found, or "None"
[/LEARNING_REPORT]

This report is shown directly to the user. Focus on analytical FINDINGS, not process."""


def _build_document_extraction_prompt(source_id: str, source_name: str) -> str:
    """Standard extraction prompt for documents (PDF, DOCX, MD, etc.)."""
    return f"""\
## Task: Source Learning — Extract Knowledge from "{source_name}"

The user explicitly chose to learn from this document. Extract structured knowledge.

### Workflow

1. **Read the document**: Use `ReadSourceContent(source_id='{source_id}')` to read the full content (paginated — call multiple times with offset for long documents)
2. **Search for existing knowledge**: Use `QueryMemories` to check if similar knowledge already exists
3. **Extract memories**: For each significant concept, fact, or learning:
   - Use `GetMemoryById` to verify you're not duplicating existing memories
   - Create a memory with appropriate `unit_type` (fact, learning, decision, procedure, etc.)
   - Set importance 0.5-0.8 (user explicitly requested extraction)
   - Set source as `library:{source_id}`
4. **Link related**: If you find memories that evolve from or relate to existing ones, use `CreateEVOLVES`
5. **Synthesize**: If 3+ extracted memories cluster around a theme, use `CreateCrystal`

### Quality Guidelines

- Extract 3-8 distinct, high-quality memories per document (not too few, not noise)
- Each memory should be self-contained and useful without the source document
- Prefer distinct concepts over redundant variations
- Use descriptive titles that capture the essence
- Skip boilerplate, formatting details, and trivial content
- For technical documents: focus on key APIs, patterns, architecture decisions
- For narrative/notes: focus on decisions, learnings, context, events

### Final Report

After completing all extraction, end your response with a structured summary using these exact tags:

[LEARNING_REPORT]
- **Document**: the document title or type
- **Memories created**: number of memories you created
- **Topics**: comma-separated list of main topics covered
- **Key learnings**:
  1. first key learning, one sentence
  2. second key learning, one sentence
  (list all significant learnings)
- **Connections**: number of links to existing knowledge found, or "None"
[/LEARNING_REPORT]

This report is shown directly to the user. Keep it concise and informative. Focus on WHAT was learned, not process details."""


def build_compaction_prompt() -> str:
    """Memory compaction task — weekly scheduled review.

    The manager injects pre-computed "Compaction Candidates" context BEFORE this prompt:
    - Stale memory clusters with similar titles/content
    - Decay scores and access metrics per memory
    - Existing EVOLVES edges to avoid duplicate work
    """
    return """Review the knowledge graph for redundant or superseded memories that can be compacted.

Your task: **Memory Compaction**

## Pre-computed Context

The "Compaction Candidates" section above lists clusters of memories that are likely
redundant or superseded, pre-ranked by staleness and similarity. Each cluster shows
memory IDs, titles, decay scores, and why they were grouped.

Start your analysis from these candidates — do NOT search for additional candidates.

**If the Compaction Candidates section says "No low-decay memories found" or contains no clusters,
the task is complete — do nothing and report "No compaction needed."**

## Workflow

For each candidate cluster (process up to 10 clusters, stop early if no more merit action):

1. **Read full content**: Use **GetMemoryById** on each memory in the cluster
2. **Evaluate relationship**: Decide which pattern applies:
   - **Superseded**: Newer memory fully replaces older one (same topic, more complete/recent info)
     → Use **CreateEVOLVES** with `content_relation="replaces"` (older_memory_id=old, newer_memory_id=new)
   - **Enrichment**: Newer memory adds detail but doesn't replace
     → Use **CreateEVOLVES** with `content_relation="enriches"` (older_memory_id=old, newer_memory_id=new)
   - **Mature cluster**: 3+ related memories saying similar things from different angles
     → Use **CreateCrystal** to synthesize into one consolidated knowledge unit
   - **Uncertain**: Content is similar but merging could lose nuance
     → Use **FlagForReview** with `flag_type="merge_candidate"` for user to decide
   - **No action**: Memories are related but genuinely distinct
     → Skip silently

3. **After merging**: If you used CreateEVOLVES with "replaces", the older memory's
   `is_latest` flag is automatically set to false. No further action needed.

## Guidelines

- **Be conservative**: Only merge when content is genuinely redundant. When in doubt, flag for user review.
- **Prefer EVOLVES over deletion**: EVOLVES(replaces) preserves history while deprioritizing the old version.
- **Maximum 10 merge operations per run**: Don't over-compact in a single pass. The task runs weekly.
- **Skip crystals**: Don't compact crystal memories (they're already consolidated).
- **Skip high-engagement**: If a memory has high appearances (>5) or clicks (>0), the user actively uses it. Be extra cautious with these.
- **Respect importance**: Never merge away a high-importance (>=0.8) memory without flagging for review.
- **Check existing edges**: Before creating an EVOLVES edge, verify one doesn't already exist between the pair.

## Quality Bar

It is PERFECTLY FINE to find zero compaction opportunities. Do not force-merge memories
that are genuinely distinct. One good merge is worth more than five questionable ones.

After processing all candidates, if you performed any merges or crystallizations,
create ONE summary insight (insight_type="connection") noting what was consolidated
and why. Include the affected memory IDs in related_memory_ids."""
