"""Centralized token usage tracker for all background LLM calls.

Every background LLM call site in the system reports token usage here:
agent sessions (Knowledge Agent, Feed Agent) via StatusUpdate aggregation,
and LiteLLM provider calls (extraction, distillation, embedding) directly.

AI Now sessions run in a separate process and are NOT tracked here.

The scheduler reads from this module for budget enforcement, the status API
exposes it for UI reporting, and the CLI uses it to display current usage.

Persistence
-----------
Records are appended to a JSONL file on disk so that token counts survive
app restarts.  On startup, ``initialize(state_dir)`` loads existing records,
deduplicates, prunes anything older than 25 hours, and rewrites the
compacted file.

Thread safety
-------------
Uses a lock to protect the shared records list, since LiteLLM provider
calls may arrive from different async contexts.
"""

from __future__ import annotations

import json
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import structlog

logger = structlog.get_logger(__name__)

# (timestamp, input_tokens, output_tokens, source_label)
_lock = threading.Lock()
_records: List[Tuple[datetime, int, int, str]] = []
_persist_path: Optional[Path] = None
_initialized = False

_RETENTION_HOURS = 25  # Small buffer past 24h for midnight-spanning windows
_PRUNE_INTERVAL = 20   # Prune every N record() calls instead of every call


# Track calls since last prune to amortize cleanup cost
_calls_since_prune = 0


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def initialize(state_dir: Path) -> None:
    """Load persisted token records from disk and set up persistence.

    Called during app startup from manager.py.  Safe to call multiple times;
    a re-entrance guard ensures only the first call takes effect.

    If the JSONL file exists, records are loaded into memory (replacing any
    prior state), deduplicated, pruned to the retention window, and the
    compacted result is rewritten to disk.

    Args:
        state_dir: Directory for persistent state files
                   (e.g. ``builtin_agents/state/``).
    """
    global _persist_path, _initialized

    if _initialized:
        return
    _initialized = True

    try:
        state_dir.mkdir(parents=True, exist_ok=True)
        _persist_path = state_dir / "token_usage.jsonl"

        if not _persist_path.exists():
            logger.info(
                "Token tracker initialized (no existing file)",
                path=str(_persist_path),
            )
            return

        cutoff = datetime.now(timezone.utc) - timedelta(hours=_RETENTION_HOURS)
        loaded: List[Tuple[datetime, int, int, str]] = []
        seen: set[str] = set()

        with open(_persist_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                    ts = datetime.fromisoformat(obj["ts"])
                    if ts <= cutoff:
                        continue
                    # Deduplicate by (timestamp_iso, source) to repair
                    # files corrupted by the pre-v0.6.1 doubling bug.
                    dedup_key = f"{obj['ts']}|{obj['src']}"
                    if dedup_key in seen:
                        continue
                    seen.add(dedup_key)
                    loaded.append((
                        ts,
                        max(0, int(obj["in"])),
                        max(0, int(obj["out"])),
                        str(obj["src"]),
                    ))
                except (json.JSONDecodeError, KeyError, ValueError, TypeError):
                    continue  # Skip corrupt or partial-write lines

        with _lock:
            _records[:] = loaded  # Replace, never extend

        _compact_file()

        logger.info(
            "Token tracker initialized from disk",
            records_loaded=len(loaded),
            path=str(_persist_path),
        )
    except Exception as e:
        logger.warning(
            "Token tracker disk init failed, using in-memory only",
            error=str(e),
        )
        _persist_path = None


def record(input_tokens: int, output_tokens: int, source: str = "unknown") -> None:
    """Record token usage from any LLM call.

    Coerces values to non-negative ints defensively (some providers
    return floats or None in usage fields).

    Args:
        input_tokens: Number of input (prompt) tokens consumed.
        output_tokens: Number of output (completion) tokens consumed.
        source: Label for the call site, e.g. ``"knowledge_agent"``,
                ``"litellm_provider"``, ``"feed_agent"``.
    """
    global _calls_since_prune

    try:
        inp = max(0, int(input_tokens))
        out = max(0, int(output_tokens))
    except (TypeError, ValueError):
        return  # Garbage in, silently skip

    if inp == 0 and out == 0:
        return

    now = datetime.now(timezone.utc)

    with _lock:
        _records.append((now, inp, out, source))
        _calls_since_prune += 1

        # Amortized pruning: scan every N calls instead of every call
        if _calls_since_prune >= _PRUNE_INTERVAL:
            _calls_since_prune = 0
            cutoff = now - timedelta(hours=_RETENTION_HOURS)
            _records[:] = [r for r in _records if r[0] > cutoff]

    _append_to_disk(now, inp, out, source)

    logger.debug(
        "Token usage recorded",
        input_tokens=inp,
        output_tokens=out,
        source=source,
    )


def tokens_since(cutoff: datetime) -> int:
    """Sum total tokens (input + output) since *cutoff*."""
    with _lock:
        return sum(inp + out for ts, inp, out, _ in _records if ts > cutoff)


def tokens_this_hour() -> int:
    """Total tokens consumed in the last 60 minutes."""
    return tokens_since(datetime.now(timezone.utc) - timedelta(hours=1))


def tokens_today() -> int:
    """Total tokens consumed in the last 24 hours."""
    return tokens_since(datetime.now(timezone.utc) - timedelta(hours=24))


def get_breakdown(hours: int = 24) -> Dict[str, Dict[str, int]]:
    """Get token usage breakdown by source label.

    Returns::

        {
            "knowledge_agent": {"input": 12345, "output": 6789},
            "litellm_provider": {"input": 5000, "output": 2000},
        }
    """
    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    with _lock:
        by_source: Dict[str, Dict[str, int]] = {}
        for ts, inp, out, src in _records:
            if ts > cutoff:
                if src not in by_source:
                    by_source[src] = {"input": 0, "output": 0}
                by_source[src]["input"] += inp
                by_source[src]["output"] += out
        return by_source


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _append_to_disk(ts: datetime, inp: int, out: int, src: str) -> None:
    """Append a single record to the JSONL file.  Best-effort, never raises."""
    if _persist_path is None:
        return
    try:
        line = json.dumps(
            {"ts": ts.isoformat(), "in": inp, "out": out, "src": src},
            separators=(",", ":"),
        )
        with open(_persist_path, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def _compact_file() -> None:
    """Rewrite the JSONL file from current in-memory records.

    Called once during ``initialize()`` to remove stale and duplicate
    entries from disk.
    """
    if _persist_path is None:
        return
    try:
        with _lock:
            snapshot = list(_records)
        with open(_persist_path, "w", encoding="utf-8") as f:
            for ts, inp, out, src in snapshot:
                f.write(
                    json.dumps(
                        {"ts": ts.isoformat(), "in": inp, "out": out, "src": src},
                        separators=(",", ":"),
                    )
                    + "\n"
                )
    except Exception as e:
        logger.warning("Token tracker compaction failed", error=str(e))
