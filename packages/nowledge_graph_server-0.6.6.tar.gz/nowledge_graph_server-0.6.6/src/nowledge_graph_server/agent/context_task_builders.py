"""Task-specific context builders for scheduled agent tasks.

Extracted from context_helpers.py to keep files under 1000 lines (PyArmor limit).

These build pre-computed context that gets injected into task prompts
before the Knowledge Agent runs, saving LLM tool calls and tokens.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog

from nowledge_graph_server.database.result_utils import iter_rows

from .context_helpers import (
    _to_naive_utc,
    build_activity_digest,
    get_recent_insights,
    get_unresolved_flags,
)

logger = structlog.get_logger(__name__)


async def build_community_overview(conn: Any) -> Optional[str]:
    """Build community overview section for context injection.

    Shared helper used by both crystallization and insight contexts.
    Returns communities with AI summaries, ranked by member count.
    """
    if conn is None:
        return None

    try:
        result = conn.execute(
            """
            MATCH (c:Community)
            WHERE c.ai_summary IS NOT NULL AND c.ai_summary <> ''
            RETURN c.id, c.name, c.ai_summary, c.member_count
            ORDER BY c.member_count DESC
            LIMIT 10
            """
        )
        communities: List[Dict[str, Any]] = []
        for row in iter_rows(result):
            communities.append(
                {
                    "id": row[0],
                    "name": row[1] or "(unnamed)",
                    "summary": (row[2] or "")[:200],
                    "members": int(row[3]) if row[3] is not None else 0,
                }
            )

        if not communities:
            return None

        lines: List[str] = [f"### Community Overview ({len(communities)} themes)"]
        for c in communities:
            lines.append(
                f"- **{c['name']}** ({c['members']} entities) — {c['summary']}"
            )
        return "\n".join(lines)

    except Exception as e:
        logger.debug("Community overview query failed", error=str(e))
        return None


async def build_crystallization_context(
    conn: Any, hours: int = 168
) -> Optional[str]:
    """Pre-compute crystallization-specific context from the graph.

    Returns formatted markdown with:
    1. New memories since last run (7 days)
    2. Uncrystallized clusters (EVOLVES-connected memories without crystals)
    3. Oldest/stalest crystals
    4. Stale crystal sources (crystals whose sources evolved after creation)
    5. Community overview
    """
    if conn is None:
        return None

    # Use naive UTC — KuzuDB returns offset-naive datetimes
    now = datetime.utcnow()
    cutoff = now - timedelta(hours=hours)
    cutoff_str = cutoff.strftime("%Y-%m-%dT%H:%M:%S")

    lines: List[str] = [f"## Crystallization Context (last {hours}h)"]

    # --- Section 1: New memories since last run ---
    try:
        result = conn.execute(
            """
            MATCH (m:Memory)
            WHERE m.created_at >= $cutoff AND (m.is_crystal IS NULL OR m.is_crystal = false)
            RETURN m.id, m.title, m.unit_type, m.importance, m.created_at
            ORDER BY m.created_at DESC
            LIMIT 30
            """,
            {"cutoff": cutoff_str},
        )
        memories: List[Dict[str, Any]] = []
        for row in iter_rows(result):
            memories.append(
                {
                    "id": row[0],
                    "title": row[1] or "(untitled)",
                    "type": row[2] or "fact",
                    "importance": float(row[3]) if row[3] is not None else 0.5,
                }
            )

        lines.append(f"\n### New Memories Since Last Run ({len(memories)})")
        if memories:
            for m in memories:
                imp = (
                    f" [imp={m['importance']:.1f}]" if m["importance"] >= 0.7 else ""
                )
                lines.append(
                    f"- **{m['title']}** ({m['type']}{imp}) — id:`{m['id']}`"
                )
        else:
            lines.append("- (none)")
    except Exception as e:
        logger.debug("Crystallization context: memories query failed", error=str(e))
        lines.append("\n### New Memories Since Last Run\n- (query failed)")

    # --- Section 2: Uncrystallized clusters ---
    # Two-step approach for KuzuDB compatibility:
    # 1. Collect all memory IDs that have a crystal covering them
    # 2. Find EVOLVES-connected memories that aren't in that set
    try:
        crystallized_ids: set = set()
        try:
            cr_result = conn.execute(
                """
                MATCH (c:Memory {is_crystal: true})-[:CRYSTALLIZED_FROM]->(s:Memory)
                RETURN DISTINCT s.id
                """
            )
            for row in iter_rows(cr_result):
                crystallized_ids.add(row[0])
        except Exception:
            pass  # No CRYSTALLIZED_FROM edges yet — set stays empty

        result = conn.execute(
            """
            MATCH (m:Memory)-[:EVOLVES]-(other:Memory)
            WHERE (m.is_crystal IS NULL OR m.is_crystal = false)
              AND (other.is_crystal IS NULL OR other.is_crystal = false)
            RETURN m.id, m.title, m.unit_type, count(DISTINCT other) as neighbor_count
            ORDER BY neighbor_count DESC
            LIMIT 30
            """
        )
        clusters: List[Dict[str, Any]] = []
        for row in iter_rows(result):
            mid = row[0]
            if mid not in crystallized_ids:
                clusters.append(
                    {
                        "id": mid,
                        "title": row[1] or "(untitled)",
                        "type": row[2] or "fact",
                        "neighbors": int(row[3]),
                    }
                )
                if len(clusters) >= 15:
                    break

        lines.append(f"\n### Uncrystallized Clusters ({len(clusters)} candidates)")
        if clusters:
            lines.append(
                "These memories are connected by EVOLVES edges but have NO crystal covering them."
            )
            lines.append("Ranked by cluster density (most connected first).")
            for c in clusters:
                lines.append(
                    f"- **{c['title']}** ({c['type']}, {c['neighbors']} EVOLVES neighbors) — id:`{c['id']}`"
                )
        else:
            lines.append("- (none — all EVOLVES clusters already crystallized)")
    except Exception as e:
        logger.debug(
            "Crystallization context: clusters query failed", error=str(e)
        )
        lines.append("\n### Uncrystallized Clusters\n- (query failed)")

    # --- Section 3: Oldest crystals (staleness candidates) ---
    try:
        result = conn.execute(
            """
            MATCH (c:Memory)
            WHERE c.is_crystal = true
            RETURN c.id, c.title, c.created_at, c.last_evaluated_at
            ORDER BY c.created_at ASC
            LIMIT 10
            """
        )
        old_crystals: List[Dict[str, Any]] = []
        for row in iter_rows(result):
            created_at = row[2]
            last_eval = row[3]

            age_days: Any = "?"
            naive_created = _to_naive_utc(created_at)
            if naive_created is not None:
                age_days = (now - naive_created).days

            eval_str = ""
            naive_eval = _to_naive_utc(last_eval)
            if naive_eval is not None:
                eval_days = (now - naive_eval).days
                eval_str = f", last evaluated {eval_days} days ago"
            elif last_eval is not None and str(last_eval).strip():
                eval_str = f", last evaluated: {str(last_eval)[:10]}"

            old_crystals.append(
                {
                    "id": row[0],
                    "title": row[1] or "(untitled)",
                    "age_days": age_days,
                    "eval_str": eval_str,
                }
            )

        if old_crystals:
            lines.append(
                f"\n### Oldest Crystals ({len(old_crystals)} staleness candidates)"
            )
            for c in old_crystals:
                lines.append(
                    f"- **{c['title']}** — created {c['age_days']} days ago{c['eval_str']} — id:`{c['id']}`"
                )
    except Exception as e:
        logger.debug(
            "Crystallization context: oldest crystals query failed", error=str(e)
        )

    # --- Section 4: Stale crystal sources ---
    # Crystals whose source memories evolved AFTER the crystal was created
    try:
        result = conn.execute(
            """
            MATCH (c:Memory {is_crystal: true})-[:CRYSTALLIZED_FROM]->(src:Memory)
            MATCH (src)-[:EVOLVES]-(newer:Memory)
            WHERE newer.created_at > c.created_at
            RETURN c.id, c.title, newer.id, newer.title, newer.created_at
            ORDER BY newer.created_at DESC
            LIMIT 10
            """
        )
        stale: List[Dict[str, Any]] = []
        seen_crystals: set = set()
        for row in iter_rows(result):
            crystal_id = row[0]
            if crystal_id not in seen_crystals:
                stale.append(
                    {
                        "crystal_id": crystal_id,
                        "crystal_title": row[1] or "(untitled)",
                        "newer_id": row[2],
                        "newer_title": row[3] or "(untitled)",
                    }
                )
                seen_crystals.add(crystal_id)

        if stale:
            lines.append(
                f"\n### Stale Crystal Sources ({len(stale)} confirmed stale)"
            )
            lines.append(
                "These crystals have source memories that evolved AFTER the crystal was created."
            )
            lines.append("Prioritize these in Phase 1 — they are CONFIRMED stale.")
            for s in stale:
                lines.append(
                    f"- Crystal **{s['crystal_title']}** (id:`{s['crystal_id']}`) "
                    f"— source evolved into **{s['newer_title']}** (id:`{s['newer_id']}`)"
                )
    except Exception as e:
        logger.debug(
            "Crystallization context: stale sources query failed", error=str(e)
        )

    # --- Section 5: Community overview ---
    try:
        community_ctx = await build_community_overview(conn)
        if community_ctx:
            lines.append("\n" + community_ctx)
    except Exception as e:
        logger.debug(
            "Crystallization context: community overview failed", error=str(e)
        )

    return "\n".join(lines)


async def build_insight_context(
    conn: Any, events_dir: Optional[Path], hours: int = 168
) -> Optional[str]:
    """Pre-compute insight-specific context from the graph.

    Returns formatted markdown with:
    1. Activity digest (7 days)
    2. Previous insights (dedup context)
    3. Challenge edges (pre-found contradictions)
    4. Decision memories (for drift analysis)
    5. Community structure
    6. Source coverage
    7. Unresolved flags
    """
    lines: List[str] = [f"## Insight Detection Context (last {hours}h)"]

    # --- Section 1: Activity digest (reuse existing) ---
    try:
        digest = await build_activity_digest(conn, hours=hours)
        if digest:
            lines.append("\n" + digest)
    except Exception as e:
        logger.debug("Insight context: activity digest failed", error=str(e))

    # --- Section 2: Previous insights (dedup) ---
    try:
        insights = get_recent_insights(events_dir, last_n_days=14)
        if insights:
            lines.append(
                f"\n### Previous Insights (last 14 days) — DO NOT recreate these"
            )
            for ins in insights:
                lines.append(
                    f"- [{ins['event_type']}] \"{ins['title']}\" ({ins['created_at']})"
                )
                if ins["description"]:
                    lines.append(f"  {ins['description']}")
        else:
            lines.append("\n### Previous Insights (last 14 days)")
            lines.append("- (none created recently)")
    except Exception as e:
        logger.debug("Insight context: recent insights scan failed", error=str(e))

    if conn is None:
        return "\n".join(lines) if len(lines) > 1 else None

    # --- Section 3: Known contradictions (challenge edges) ---
    try:
        result = conn.execute(
            """
            MATCH (newer:Memory)-[e:EVOLVES {content_relation: 'challenges'}]->(older:Memory)
            RETURN newer.id, newer.title, older.id, older.title, e.created_at
            ORDER BY e.created_at DESC
            LIMIT 10
            """
        )
        challenges: List[Dict[str, Any]] = []
        for row in iter_rows(result):
            challenges.append(
                {
                    "newer_id": row[0],
                    "newer_title": row[1] or "(untitled)",
                    "older_id": row[2],
                    "older_title": row[3] or "(untitled)",
                }
            )

        lines.append(f"\n### Known Contradictions ({len(challenges)} challenge edges)")
        if challenges:
            lines.append(
                "EVOLVES edges with content_relation='challenges'. "
                "Verify these — flag unresolved contradictions."
            )
            for ch in challenges:
                lines.append(
                    f"- \"{ch['newer_title']}\" challenges \"{ch['older_title']}\"\n"
                    f"  newer: id:`{ch['newer_id']}`, older: id:`{ch['older_id']}`"
                )
        else:
            lines.append("- (none)")
    except Exception as e:
        logger.debug("Insight context: challenge edges query failed", error=str(e))

    # --- Section 4: Decision memories ---
    try:
        result = conn.execute(
            """
            MATCH (m:Memory)
            WHERE m.unit_type = 'decision'
            RETURN m.id, m.title, m.created_at, m.importance
            ORDER BY m.created_at DESC
            LIMIT 20
            """
        )
        decisions: List[Dict[str, Any]] = []
        for row in iter_rows(result):
            created_at = row[2]
            if isinstance(created_at, datetime):
                created_at = created_at.strftime("%Y-%m-%d")
            elif created_at is not None:
                created_at = str(created_at)[:10]
            decisions.append(
                {
                    "id": row[0],
                    "title": row[1] or "(untitled)",
                    "created": created_at,
                    "importance": float(row[3]) if row[3] is not None else 0.5,
                }
            )

        lines.append(
            f"\n### Decision Memories ({len(decisions)} decisions, newest first)"
        )
        if decisions:
            lines.append(
                "Scan for same-topic reversals (decision drift). "
                "Use GetMemoryById for full content on suspicious pairs."
            )
            for d in decisions:
                imp = (
                    f" [imp={d['importance']:.1f}]"
                    if d["importance"] >= 0.7
                    else ""
                )
                lines.append(
                    f"- **{d['title']}**{imp} ({d['created']}) — id:`{d['id']}`"
                )
        else:
            lines.append("- (none)")
    except Exception as e:
        logger.debug("Insight context: decisions query failed", error=str(e))

    # --- Section 5: Community overview ---
    try:
        community_ctx = await build_community_overview(conn)
        if community_ctx:
            lines.append("\n" + community_ctx)
    except Exception as e:
        logger.debug("Insight context: community overview failed", error=str(e))

    # --- Section 6: Source coverage ---
    try:
        result = conn.execute(
            """
            MATCH (s:Source)
            RETURN s.id, s.original_name, s.lifecycle_state, s.memory_count, s.created_at
            ORDER BY s.memory_count ASC
            LIMIT 15
            """
        )
        sources: List[Dict[str, Any]] = []
        for row in iter_rows(result):
            created_at = row[4]
            if isinstance(created_at, datetime):
                created_at = created_at.strftime("%Y-%m-%d")
            elif created_at is not None:
                created_at = str(created_at)[:10]
            sources.append(
                {
                    "id": row[0],
                    "name": row[1] or "(unnamed)",
                    "state": row[2] or "ingested",
                    "memories": int(row[3]) if row[3] is not None else 0,
                    "created": created_at,
                }
            )

        if sources:
            lines.append(
                f"\n### Source Coverage ({len(sources)} sources, lowest memory count first)"
            )
            lines.append(
                "Sources with 0 memories may need extraction. "
                "Sources stuck in non-terminal states may need attention."
            )
            for s in sources:
                lines.append(
                    f"- **{s['name']}** ({s['state']}, {s['memories']} memories, added {s['created']}) — id:`{s['id']}`"
                )
    except Exception as e:
        logger.debug("Insight context: source coverage query failed", error=str(e))

    # --- Section 7: Unresolved flags ---
    try:
        flags = get_unresolved_flags(events_dir, limit=10)
        if flags:
            lines.append(f"\n### Unresolved Flags ({len(flags)} open)")
            lines.append(
                "These are currently open flags. Do not re-flag the same issues."
            )
            for fl in flags:
                lines.append(f"- \"{fl['title']}\" — {fl['description']}")
    except Exception as e:
        logger.debug("Insight context: unresolved flags failed", error=str(e))

    return "\n".join(lines) if len(lines) > 1 else None


async def build_compaction_context(
    conn: Any, limit: int = 30
) -> Optional[str]:
    """Pre-compute compaction candidates for the memory compaction task.

    Finds memories with low decay_score_cached that are NOT crystals, NOT archived,
    and groups them into clusters based on shared EVOLVES edges or similar titles.
    """
    if conn is None:
        return None

    lines: List[str] = ["## Compaction Candidates"]
    candidates: List[Dict[str, Any]] = []

    # 1. Query low-decay, non-crystal, non-archived memories
    try:
        for row in iter_rows(conn.execute(
            """MATCH (m:Memory)
               WHERE m.is_crystal = false
                 AND m.decay_score_cached < 0.5
               RETURN m.id, m.title, m.decay_score_cached, m.importance,
                      m.appearances, m.clicks, m.metadata, m.created_at
               ORDER BY m.decay_score_cached ASC
               LIMIT $limit""",
            {"limit": limit * 2},  # Fetch extra to filter archived
        )):
            meta_str = row[6]
            try:
                meta = json.loads(meta_str) if isinstance(meta_str, str) else (meta_str or {})
            except (json.JSONDecodeError, TypeError):
                meta = {}

            # Skip archived/deleted
            state = meta.get("state", "active")
            if state in ("archived", "deleted"):
                continue

            candidates.append({
                "id": row[0],
                "title": row[1] or "Untitled",
                "decay": round(row[2] if row[2] is not None else 1.0, 3),
                "importance": row[3] if row[3] is not None else 0.5,
                "appearances": row[4] or 0,
                "clicks": row[5] or 0,
                "created_at": str(row[7])[:10] if row[7] else "unknown",
            })

            if len(candidates) >= limit:
                break
    except Exception as e:
        logger.debug("Compaction context: candidate query failed", error=str(e))
        return None

    if not candidates:
        lines.append("\nNo low-decay memories found. Graph is healthy.")
        return "\n".join(lines)

    # 2. Find EVOLVES-connected clusters among candidates
    candidate_ids = [c["id"] for c in candidates]
    clusters: Dict[str, List[str]] = {}  # root_id -> [connected_ids]

    try:
        for row in iter_rows(conn.execute(
            """MATCH (a:Memory)-[e:EVOLVES]-(b:Memory)
               WHERE a.id IN $ids AND b.id IN $ids
               RETURN a.id, b.id, e.content_relation""",
            {"ids": candidate_ids},
        )):
            a_id, b_id = row[0], row[1]
            # Group into clusters
            root_a = next((r for r, members in clusters.items() if a_id in members), None)
            root_b = next((r for r, members in clusters.items() if b_id in members), None)

            if root_a and root_b:
                if root_a != root_b:
                    # Merge clusters
                    clusters[root_a].extend(clusters[root_b])
                    del clusters[root_b]
            elif root_a:
                clusters[root_a].append(b_id)
            elif root_b:
                clusters[root_b].append(a_id)
            else:
                clusters[a_id] = [a_id, b_id]
    except Exception as e:
        logger.debug("Compaction context: EVOLVES cluster query failed", error=str(e))

    # 3. Add unclustered candidates as singletons (for title-based similarity)
    clustered_ids = set()
    for members in clusters.values():
        clustered_ids.update(members)

    unclustered = [c for c in candidates if c["id"] not in clustered_ids]

    # 4. Format output
    candidate_lookup = {c["id"]: c for c in candidates}
    cluster_num = 0

    # Emit EVOLVES-connected clusters
    for _root_id, member_ids in sorted(
        clusters.items(), key=lambda x: len(x[1]), reverse=True
    ):
        cluster_num += 1
        unique_members = list(dict.fromkeys(member_ids))  # Preserve order, dedup
        lines.append(f"\n### Cluster {cluster_num} (EVOLVES-connected, {len(unique_members)} memories)")
        for mid in unique_members:
            c = candidate_lookup.get(mid)
            if c:
                lines.append(
                    f"- `{c['id']}` — \"{c['title']}\" "
                    f"(decay={c['decay']}, imp={c['importance']}, "
                    f"views={c['appearances']}, clicks={c['clicks']}, "
                    f"created={c['created_at']})"
                )
        lines.append("**Reason**: These memories share EVOLVES edges — check if older versions are fully superseded.")

    # Emit unclustered low-decay memories (potential title-based similarity)
    if unclustered:
        cluster_num += 1
        lines.append(f"\n### Unclustered Low-Decay ({len(unclustered)} memories)")
        lines.append("These have low decay scores but no existing EVOLVES connections.")
        lines.append("Check for title/content similarity — they may be redundant captures of the same topic.")
        for c in unclustered[:20]:
            lines.append(
                f"- `{c['id']}` — \"{c['title']}\" "
                f"(decay={c['decay']}, imp={c['importance']}, "
                f"views={c['appearances']}, clicks={c['clicks']}, "
                f"created={c['created_at']})"
            )

    lines.append(f"\n**Total candidates**: {len(candidates)} memories with decay < 0.5")

    return "\n".join(lines)
