"""Feed Agent Session — kimi-agent-sdk with A+B hybrid context handling.

Design (A+B hybrid — see postmortem/2026-02-27-token-budget-cumulative-accounting.md):
  A: Keep session alive between inputs within time/turn windows, letting
     kimi-cli's built-in SimpleCompaction manage context window size.
  B: Inject [RECENT TIMELINE] from feed events into the context anchor
     so the agent retains situational awareness even after compaction/restart.

Session lifecycle:
- Session stays alive between inputs if idle < 10 min AND turns < 20
- On restart, the recent timeline injection preserves continuity
- Explicit thread_id follow-ups always preserve full session history

Architecture:
- Feed Agent runs entirely in Python backend (unlike AI-Now which uses ACP/spawned script)
- LLM config is consumed directly from RemoteLLMConfigManager (Python side)
- No dependency on TypeScript config sync (that's only for AI-Now/ACP)
"""

from __future__ import annotations

import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, AsyncGenerator, Dict, Optional

import structlog

# Import centralized path utilities (MUST be imported before HOME is modified)
from .paths import get_builtin_agents_home

logger = structlog.get_logger(__name__)


class FeedAgentSession:
    """Long-running agent session for Feed input with A+B hybrid context handling.

    Key design:
    - Uses kimi-agent-sdk Session for Wire Protocol streaming
    - Session kept alive between inputs (A) — kimi-cli compaction manages context
    - Recent timeline injected into context anchor (B) — survives restart/compaction
    - Smart restart on idle timeout (10 min) or turn cap (20 turns)
    """

    def __init__(
        self,
        work_dir: Path,
        agent_file: Path,
        *,
        max_steps_per_turn: int = 25,
    ) -> None:
        self._work_dir = work_dir
        self._agent_file = agent_file
        self._max_steps = max_steps_per_turn
        self._session: Any = None  # kimi_agent_sdk.Session
        self._session_id = "nowledge-feed-agent"

        # Token tracking for the last completed turn
        self._last_turn_tokens: tuple[int, int] = (0, 0)

        # Turn tracking for smart restart decisions
        self._turn_count: int = 0
        self._last_turn_time: Optional[float] = None  # time.monotonic()
        self._last_turn_errored: bool = False  # Force restart after errors

        # Context state for injection
        self._db_stats: Dict[str, Any] = {}
        self._recent_timeline: str = ""

        # Track original KIMI_SHARE_DIR for restoration
        self._original_kimi_share_dir: Optional[str] = None

        # Config path (set by _ensure_kimi_config)
        self._config_path: Optional[Path] = None

        # Ensure work_dir exists
        self._work_dir.mkdir(parents=True, exist_ok=True)

    def update_context(self, db_stats: Dict[str, Any]) -> None:
        """Update context stats to inject in next prompt."""
        self._db_stats = db_stats

    def update_recent_timeline(self, timeline: str) -> None:
        """Update the recent timeline summary for context injection."""
        self._recent_timeline = timeline

    def _build_context_anchor(self) -> str:
        """Build context anchor to prepend to prompts."""
        from .settings_reader import read_user_profile

        now = datetime.now(timezone.utc)
        stats = self._db_stats

        lines = [
            "[KNOWLEDGE GRAPH STATE]",
            f"- Time: {now.strftime('%Y-%m-%d %H:%M UTC')}",
            f"- Memories: {stats.get('memory_count', '?')}",
            f"- EVOLVES edges: {stats.get('evolves_count', '?')}",
            f"- Crystals: {stats.get('crystal_count', '?')}",
            f"- Unresolved flags: {stats.get('unresolved_flags', '?')}",
        ]

        # Inject user identity if configured
        profile = read_user_profile()
        if profile.get("name"):
            lines.append("")
            lines.append("[USER IDENTITY]")
            lines.append(f"- Name: {profile['name']}")
            if profile.get("aliases"):
                lines.append(f"- Also known as: {profile['aliases']}")
            if profile.get("context"):
                lines.append(f"- Context: {profile['context']}")

        # Inject preferred language
        preferred_lang = profile.get("preferred_language", "en")
        if preferred_lang and preferred_lang != "en":
            lang_name = {"zh": "Chinese (中文)"}.get(preferred_lang, preferred_lang)
            lines.append("")
            lines.append("[PREFERRED LANGUAGE]")
            lines.append(f"Generate all user-facing content (responses, insights, briefings, crystal summaries) in: {lang_name}")
            lines.append("Entity names and technical terms should stay in their original language.")

        # Inject recent timeline for situational awareness
        if self._recent_timeline:
            lines.append("")
            lines.append(self._recent_timeline)

        lines.extend([
            "",
            "Note: Use ReadDailyReport/SearchHistory for older context.",
            "---",
        ])
        return "\n".join(lines)

    def _ensure_kimi_config(self) -> None:
        """Ensure kimi config is available for builtin agents.

        Architecture: Feed Agent runs entirely in Python backend, so we generate
        the kimi-cli config directly from RemoteLLMConfigManager (Python side).
        This is different from AI-Now which uses ACP/spawned script and relies
        on TypeScript config sync.

        This method:
        1. Generates kimi-cli config.json from RemoteLLMConfigManager
        2. Sets KIMI_SHARE_DIR to builtin_agents directory for kimi-agent-sdk

        Uses KIMI_SHARE_DIR environment variable instead of HOME to avoid
        corrupting Path.home() for other code (model_cache, etc.).
        """
        from .kimi_config_generator import generate_kimi_config_from_remote_llm
        from .kimi_patches import (
            apply_chatgpt_backend_patch,
            apply_kimi_openai_custom_headers_patch,
            apply_kimi_reasoning_capability_patch,
        )

        # Get builtin_agents home path
        builtin_agents_home = get_builtin_agents_home()

        # Set KIMI_SHARE_DIR so kimi-agent-sdk uses isolated directory
        # This is safer than modifying HOME which affects all code using Path.home()
        self._original_kimi_share_dir = os.environ.get("KIMI_SHARE_DIR")
        os.environ["KIMI_SHARE_DIR"] = str(builtin_agents_home)

        logger.debug("Set KIMI_SHARE_DIR for Feed Agent", share_dir=str(builtin_agents_home))

        # Ensure builtin_agents directory exists
        builtin_agents_home.mkdir(parents=True, exist_ok=True)

        # Generate kimi config directly from RemoteLLMConfigManager (Python-native)
        # This avoids dependency on TypeScript config sync
        self._config_path = generate_kimi_config_from_remote_llm(purpose="ai_now")
        # Ensure ChatGPT backend requests are patched if Codex is selected
        apply_chatgpt_backend_patch()
        apply_kimi_reasoning_capability_patch()
        apply_kimi_openai_custom_headers_patch()

        if self._config_path is None:
            logger.warning(
                "Could not generate kimi config. Configure Remote LLM in Settings.",
                builtin_agents_home=str(builtin_agents_home),
            )
            # Set a fallback path so Session.create doesn't fail with None
            self._config_path = builtin_agents_home / "config.json"

    def _ensure_agent_files(self) -> Path:
        """Ensure agent YAML and system prompt files exist.

        The system prompt is ALWAYS regenerated from embedded_prompts.py
        (the single source of truth). In dev mode, the YAML file on disk
        is used for tool config; in bundled mode, both are generated.

        Returns the path to the agent_file to use.
        """
        from .embedded_prompts import FEED_AGENT_SYSTEM_PROMPT, FEED_AGENT_TOOLS

        # Always regenerate system prompt from embedded (source of truth)
        if self._agent_file.exists():
            prompt_dir = self._agent_file.parent
        else:
            prompt_dir = self._work_dir

        system_prompt_path = prompt_dir / "feed_agent_system.md"
        system_prompt_path.write_text(FEED_AGENT_SYSTEM_PROMPT, encoding="utf-8")

        # In dev mode, YAML exists on disk — use it (for tool config)
        if self._agent_file.exists():
            return self._agent_file

        # Bundled mode: also generate YAML
        logger.debug("[FEED AGENT] Creating agent YAML from embedded prompts (bundled mode)")

        agent_yaml_path = self._work_dir / "feed_agent.yaml"
        yaml_content = f"""version: 1
agent:
  name: "Nowledge Feed Agent"
  system_prompt_path: ./feed_agent_system.md
  tools:
"""
        for tool in FEED_AGENT_TOOLS:
            yaml_content += f'    - "{tool}"\n'

        agent_yaml_path.write_text(yaml_content, encoding="utf-8")

        logger.debug(
            "[FEED AGENT] Agent files created",
            agent_yaml=str(agent_yaml_path),
            system_prompt=str(system_prompt_path),
        )

        return agent_yaml_path

    def _check_tools_version(self) -> bool:
        """Check if the agent tools list has changed since last session.

        Returns True if the tools version has changed (session should be recreated).
        Writes the current version hash to a file for next comparison.
        """
        import hashlib
        from .embedded_prompts import FEED_AGENT_SYSTEM_PROMPT, FEED_AGENT_TOOLS

        # Hash both tools list AND system prompt — either change invalidates the session
        hash_input = "\n".join(FEED_AGENT_TOOLS) + "\n---\n" + FEED_AGENT_SYSTEM_PROMPT
        current_hash = hashlib.sha256(hash_input.encode()).hexdigest()[:16]

        version_file = self._work_dir / ".tools_version"
        stored_hash = ""
        if version_file.exists():
            stored_hash = version_file.read_text(encoding="utf-8").strip()

        if current_hash != stored_hash:
            version_file.write_text(current_hash, encoding="utf-8")
            if stored_hash:
                logger.info(
                    "[FEED AGENT] Tools/prompt changed, forcing fresh session",
                    old_hash=stored_hash,
                    new_hash=current_hash,
                )
                return True
            # First run — no stored hash, don't force restart
        return False

    async def start(self, *, yolo: bool = True, force_fresh: bool = False) -> None:
        """Start or resume the session.

        Args:
            yolo: Whether to run in yolo mode (auto-approve tool calls)
            force_fresh: If True, skip resume and create a fresh session.
                         Use this when restarting for config changes to ensure
                         the new config is used.
        """
        # Ensure kimi config is available (regenerated fresh from RemoteLLMConfigManager)
        self._ensure_kimi_config()

        # Ensure agent files exist (creates from embedded prompts if needed)
        agent_file = self._ensure_agent_files()

        # Check if tools/prompt changed — force fresh if so
        # (Session.resume() loads old tool definitions from disk)
        if not force_fresh and self._check_tools_version():
            force_fresh = True

        logger.info(
            "Feed Agent starting",
            force_fresh=force_fresh,
            config_path=str(self._config_path) if self._config_path else None,
        )

        # Lazy imports to avoid issues when kimi-agent-sdk not installed
        try:
            from kaos.path import KaosPath
            from kimi_agent_sdk import Session
        except ImportError as e:
            logger.error("kimi-agent-sdk not available", error=str(e))
            raise RuntimeError(
                "kimi-agent-sdk is required for Feed Agent. "
                "Ensure the bundled Python environment includes it."
            ) from e

        work_dir_kaos = KaosPath(str(self._work_dir))

        try:
            # Try resume first (unless force_fresh requested)
            if not force_fresh:
                try:
                    self._session = await Session.resume(
                        work_dir=work_dir_kaos,
                        session_id=self._session_id,
                        config=self._config_path,
                        agent_file=agent_file,
                        yolo=yolo,
                        max_steps_per_turn=self._max_steps,
                    )
                except Exception as e:
                    logger.debug("Session resume failed, will create new", error=str(e))
                    self._session = None
            else:
                logger.debug("Forcing fresh session (skipping resume)")
                self._session = None

            if self._session is None:
                self._session = await Session.create(
                    work_dir=work_dir_kaos,
                    session_id=self._session_id,
                    config=self._config_path,
                    agent_file=agent_file,
                    yolo=yolo,
                    max_steps_per_turn=self._max_steps,
                )
        except Exception as e:
            logger.error("Feed Agent session creation failed", error=str(e))
            raise
        finally:
            # CRITICAL: Restore KIMI_SHARE_DIR immediately after session creation.
            # kimi-agent-sdk caches the session path at creation time, so we can
            # safely restore the env var now to avoid affecting other agents.
            self._restore_kimi_share_dir()

        logger.info(
            "Feed Agent session started",
            session_id=self._session_id,
            max_steps=self._max_steps,
        )

    def _restore_kimi_share_dir(self) -> None:
        """Restore original KIMI_SHARE_DIR environment variable."""
        if self._original_kimi_share_dir is not None:
            os.environ["KIMI_SHARE_DIR"] = self._original_kimi_share_dir
            self._original_kimi_share_dir = None
        elif "KIMI_SHARE_DIR" in os.environ:
            # Remove KIMI_SHARE_DIR if it wasn't set before
            del os.environ["KIMI_SHARE_DIR"]

    async def stop(self) -> None:
        """Stop the session."""
        if self._session:
            try:
                await self._session.close()
            except Exception as e:
                logger.warning("Error closing session", error=str(e))
            self._session = None

        # Restore KIMI_SHARE_DIR (should already be restored after start, but be safe)
        self._restore_kimi_share_dir()

        logger.info("Feed Agent session stopped")

    async def restart_fresh(self) -> None:
        """Restart with a fresh session — no conversation history.

        Called when the session is stale (idle too long or too many turns).
        Resets turn tracking so the next input starts a clean window.
        The recent timeline injection (Option B) ensures the agent still
        has situational awareness even after restart.
        """
        logger.debug("[FEED AGENT] Restarting with fresh session")
        self._turn_count = 0
        self._last_turn_time = None
        self._last_turn_errored = False
        await self.stop()
        await self.start(yolo=True, force_fresh=True)

    async def process_input(
        self,
        user_input: str,
    ) -> AsyncGenerator[Any, None]:  # Yields WireMessage
        """Process input and yield WireMessages.

        The context anchor is prepended to user input to give the agent
        current state information.
        """
        if self._session is None:
            raise RuntimeError("Feed Agent session not started")

        # Lazy imports (same pattern as knowledge_agent_session.py)
        try:
            from kimi_agent_sdk import ApprovalRequest, StatusUpdate
        except ImportError:
            ApprovalRequest = None  # type: ignore
            StatusUpdate = None  # type: ignore

        # Prepend context anchor to user input
        augmented_input = f"{self._build_context_anchor()}\n\n{user_input}"

        logger.debug(
            "Processing feed input",
            input_len=len(user_input),
            augmented_len=len(augmented_input),
        )

        # Token accumulation for this turn
        total_input = 0
        total_output = 0

        errored = False
        try:
            async for msg in self._session.prompt(augmented_input):
                # Handle approvals automatically (yolo=True should do this, but safety)
                if ApprovalRequest is not None and isinstance(msg, ApprovalRequest):
                    msg.resolve("approve")

                # Aggregate token usage from StatusUpdate messages
                if StatusUpdate is not None and isinstance(msg, StatusUpdate):
                    usage = getattr(msg, "token_usage", None)
                    if usage is not None:
                        total_input += usage.input_other + usage.input_cache_read + usage.input_cache_creation
                        total_output += usage.output

                yield msg
        except Exception as e:
            errored = True
            logger.error("Feed Agent processing failed", error=str(e))
            raise
        finally:
            self._last_turn_tokens = (total_input, total_output)
            self._last_turn_errored = errored
            self._turn_count += 1
            self._last_turn_time = time.monotonic()

    @property
    def last_turn_tokens(self) -> tuple[int, int]:
        """Return (input_tokens, output_tokens) from the last completed turn."""
        return self._last_turn_tokens

    @property
    def is_running(self) -> bool:
        return self._session is not None

    @property
    def session_id(self) -> str:
        return self._session_id

    @property
    def turn_count(self) -> int:
        """Number of completed turns since last restart."""
        return self._turn_count

    @property
    def last_turn_errored(self) -> bool:
        """Whether the last completed turn raised an exception (e.g. max steps reached)."""
        return self._last_turn_errored

    @property
    def seconds_since_last_turn(self) -> float:
        """Seconds elapsed since last completed turn. inf if no turns yet."""
        if self._last_turn_time is None:
            return float("inf")
        return time.monotonic() - self._last_turn_time
