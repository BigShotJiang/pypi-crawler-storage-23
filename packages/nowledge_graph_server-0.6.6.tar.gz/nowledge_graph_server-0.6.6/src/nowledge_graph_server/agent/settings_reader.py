"""Read knowledge processing settings from the Tauri app-settings.json file.

The frontend writes settings to:
  ~/Library/Application Support/co.nowledge.mem.desktop/app-settings.json (macOS)
  %APPDATA%/co.nowledge.mem.desktop/app-settings.json (Windows)
  ~/.config/co.nowledge.mem.desktop/app-settings.json (Linux)

This module reads the knowledgeProcessing section for use by the agent manager.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

import structlog
from nowledge_graph_server.utils.app_paths import (
    get_app_config_dir,
    resolve_config_file_path,
)

logger = structlog.get_logger(__name__)

# Defaults match the frontend DEFAULT_KNOWLEDGE_PROCESSING
DEFAULT_SETTINGS: Dict[str, Any] = {
    "backgroundIntelligence": True,
    "autoKGExtraction": True,
    "autoCommunityDetection": True,
    "autoEVOLVESDetection": True,
    "communityDetectionIntervalDays": 14,
    "communityResolution": 1.0,
    "kgExtractionConfidence": 0.7,
    "autoDailyBriefing": True,
    "autoCrystallization": True,
    "autoInsightDetection": True,
    "autoDecayRefresh": False,
    "autoMemoryCompaction": False,
    "autoArchiveStaleMemories": False,
    "autoWMRefresh": True,
    "generateCommunityAISummary": True,
    "briefingHour": 5,
    "maxTokensPerHour": 500_000,   # ~$2-5 depending on model
    "maxTokensPerDay": 2_000_000,  # ~$8-20 depending on model
    "maxTokensPerTask": 500_000,   # per-task budget (cumulative input+output). 0 = unlimited
    "maxStepsPerTask": 40,         # max LLM steps per task. Prevents runaway token burn
}


def _get_app_data_dir() -> Path:
    """Get the Tauri app config directory.

    Must match Tauri's appConfigDir() for each platform
    (same logic as license.py:_get_app_data_dir).
    """
    return get_app_config_dir()


def get_app_settings_path() -> Path:
    """Resolve app-settings.json with legacy fallback/migration."""
    return resolve_config_file_path("app-settings.json")


def read_knowledge_processing_settings() -> Dict[str, Any]:
    """Read knowledge processing settings from app-settings.json.

    Returns defaults if file doesn't exist or section is missing.
    """
    try:
        settings_path = get_app_settings_path()
        if not settings_path.exists():
            return dict(DEFAULT_SETTINGS)

        data = json.loads(settings_path.read_text(encoding="utf-8"))
        kp = data.get("knowledgeProcessing", {})
        if not isinstance(kp, dict):
            return dict(DEFAULT_SETTINGS)

        # Merge with defaults (user values override)
        return {**DEFAULT_SETTINGS, **kp}

    except Exception as e:
        logger.debug("Failed to read knowledge processing settings", error=str(e))
        return dict(DEFAULT_SETTINGS)


def read_user_profile() -> Dict[str, str]:
    """Read user profile from app-settings.json.

    Returns dict with name, aliases, context. Empty strings if not set.
    """
    try:
        settings_path = get_app_settings_path()
        if not settings_path.exists():
            return {"name": "", "aliases": "", "context": ""}

        data = json.loads(settings_path.read_text(encoding="utf-8"))
        profile = data.get("userProfile", {})
        if not isinstance(profile, dict):
            return {"name": "", "aliases": "", "context": ""}

        return {
            "name": profile.get("name", ""),
            "aliases": profile.get("aliases", ""),
            "context": profile.get("context", ""),
            "preferred_language": profile.get("preferredLanguage", "en"),
        }

    except Exception as e:
        logger.debug("Failed to read user profile", error=str(e))
        return {"name": "", "aliases": "", "context": "", "preferred_language": "en"}
