"""Centralized path utilities for agents.

CRITICAL: This module MUST be imported BEFORE any agent session starts, so that
_REAL_HOME is captured before any agent modifies os.environ["HOME"].

The HOME environment variable is modified by agent sessions for kimi-agent-sdk
isolation, which corrupts Path.home() for any module imported later.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from nowledge_graph_server.utils.app_paths import (
    get_app_config_dir,
    resolve_config_subdir_path,
)

# CRITICAL: Capture the real home directory at module import time.
# This MUST happen before any agent modifies os.environ["HOME"].
# Path.home() reads HOME env var on macOS/Linux.
_REAL_HOME = Path.home()


def get_real_home() -> Path:
    """Get the real user home directory (cached at import time)."""
    return _REAL_HOME


def get_app_data_dir() -> Path:
    """Get the app's config/state directory (platform-specific).

    NOTE: Function name kept for compatibility with existing imports.
    """
    return get_app_config_dir()


def get_builtin_agents_home() -> Path:
    """Get the isolated HOME directory for builtin agents (Feed, scheduled jobs, etc.).

    This is SEPARATE from AI-Now's kimi_home to ensure complete isolation:
    - AI-Now: {appConfig}/kimi_home/
    - Builtin agents: {appConfig}/builtin_agents/

    The builtin_agents directory contains:
    - .kimi/: kimi-cli HOME for agents (sessions keyed by work_dir hash)
    - feed/: Feed agent work_dir
    - reports/YYYY/MM/: Time-partitioned daily reports
    - events/YYYY/MM/: Time-partitioned feed events
    - state/: Scheduler state

    All builtin agents share the same .kimi/ directory but use different work_dir
    values, so kimi-agent-sdk creates separate session directories via hashing.
    """
    return resolve_config_subdir_path("builtin_agents")


def get_shared_config_source() -> Path:
    """Get the shared LLM config source (written by Tauri/TypeScript).

    This is the config.json that the TypeScript side syncs when AI-Now starts.
    All built-in agents should read from this shared source for LLM settings.
    """
    return resolve_config_subdir_path("kimi_home") / "kimi_config" / "config.json"


def get_cache_dir(cache_type: str = "default") -> Path:
    """Get the cache directory for models, embeddings, etc.

    Uses _REAL_HOME to avoid corruption when HOME is modified.
    """
    return _REAL_HOME / ".cache" / "nowledge-graph" / cache_type


def get_huggingface_cache() -> Path:
    """Get the HuggingFace cache directory.

    Uses _REAL_HOME to avoid corruption when HOME is modified.
    """
    return _REAL_HOME / ".cache" / "huggingface" / "hub"


def get_modelscope_cache() -> Path:
    """Get the ModelScope cache directory.

    Uses _REAL_HOME to avoid corruption when HOME is modified.
    """
    return _REAL_HOME / ".cache" / "modelscope" / "hub" / "models"


def get_ai_now_home() -> Path:
    """Get the ~/ai-now/ directory (user-facing workspace).

    This is the public, user-visible directory for AI-generated artifacts
    like Working Memory. Uses _REAL_HOME to avoid corruption.
    """
    return _REAL_HOME / "ai-now"


def get_sources_home() -> Path:
    """Get the ~/ai-now/sources/ directory for ingested source files.

    Layout:
        ~/ai-now/sources/
        ├── src_{id}/
        │   ├── original-name.md   (parsed)
        │   ├── original-name.pdf  (raw)
        │   └── .meta.json
        └── .versions/             (historical versions)
    """
    return get_ai_now_home() / "sources"


def get_working_memory_path() -> Path:
    """Get the current Working Memory path: ~/ai-now/memory.md"""
    return get_ai_now_home() / "memory.md"


def get_working_memory_archive_path(date: datetime) -> Path:
    """Get the archived Working Memory path for a specific date.

    Archive structure: ~/ai-now/memory-archive/YYYY/MM/YYYY-MM-DD.md
    """
    year = date.strftime("%Y")
    month = date.strftime("%m")
    return get_ai_now_home() / "memory-archive" / year / month / f"{date.strftime('%Y-%m-%d')}.md"
