"""File-based history tools — read and search archived daily reports.

The agent archives its conversation history to daily report files.
These tools allow the agent to search through past activity and decisions
without loading the full history into context.

Uses time-partitioned file structure: reports/YYYY/MM/YYYY-MM-DD.md
"""

from __future__ import annotations

import json
import os
import re
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, List

import structlog

from .base import AgentTool
from nowledge_graph_server.utils.time_partitioning import (
    _get_time_partitioned_path,
    _iter_time_partitioned_files,
)

logger = structlog.get_logger(__name__)


class ReadDailyReport(AgentTool):
    """Read a daily activity report from the agent's archive."""

    name = "ReadDailyReport"
    description = (
        "Read a daily activity report from the agent's archive. "
        "Reports contain summaries of agent activity, decisions made, "
        "insights generated, and flags raised for each day. "
        "Use this to recall what happened on a specific day."
    )

    def __init__(self, reports_dir: Path) -> None:
        self._reports_dir = reports_dir

    def parameters_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "date": {
                    "type": "string",
                    "description": "Date in YYYY-MM-DD format (default: today)",
                },
                "days_ago": {
                    "type": "integer",
                    "description": "Alternative: number of days ago (0=today, 1=yesterday)",
                    "minimum": 0,
                    "maximum": 90,
                },
            },
        }

    async def execute(self, arguments: Dict[str, Any]) -> str:
        if "date" in arguments:
            date_str = arguments["date"]
            target = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        elif "days_ago" in arguments:
            target = datetime.now(timezone.utc) - timedelta(days=arguments["days_ago"])
            date_str = target.strftime("%Y-%m-%d")
        else:
            target = datetime.now(timezone.utc)
            date_str = target.strftime("%Y-%m-%d")

        # Use time-partitioned path
        report_path = _get_time_partitioned_path(self._reports_dir, target, "md")

        if not report_path.exists():
            # List available reports (time-partitioned)
            available = [
                f.stem for f in _iter_time_partitioned_files(self._reports_dir, "md", last_n_days=90)
            ][:10]  # Last 10

            return json.dumps({
                "error": f"No report found for {date_str}",
                "available_dates": available,
            })

        try:
            content = report_path.read_text(encoding="utf-8")
            # Truncate if too large
            if len(content) > 8000:
                content = content[:8000] + "\n\n... (truncated, use SearchHistory for specific topics)"

            return json.dumps({
                "date": date_str,
                "content": content,
            })
        except Exception as e:
            return json.dumps({"error": f"Failed to read report: {e}"})


class SearchHistory(AgentTool):
    """Search through archived daily reports for specific topics."""

    name = "SearchHistory"
    description = (
        "Search through archived daily reports using a text pattern. "
        "Returns matching lines from past activity reports. "
        "Use this to find past decisions, observations, or flags "
        "without loading full reports into context."
    )

    def __init__(self, reports_dir: Path) -> None:
        self._reports_dir = reports_dir

    def parameters_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Text pattern to search for (case-insensitive substring match)",
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum number of matching lines to return (default 20)",
                    "default": 20,
                },
                "last_n_days": {
                    "type": "integer",
                    "description": "Search only the last N days (default 30)",
                    "default": 30,
                },
            },
            "required": ["pattern"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> str:
        pattern = arguments["pattern"].lower()
        max_results = arguments.get("max_results", 20)
        last_n_days = arguments.get("last_n_days", 30)

        if not self._reports_dir.exists():
            return json.dumps({"matches": [], "total": 0, "note": "No reports directory yet"})

        matches: List[Dict[str, str]] = []
        # Use time-partitioned file iteration
        report_files = _iter_time_partitioned_files(self._reports_dir, "md", last_n_days=last_n_days)

        for report_path in report_files:
            if len(matches) >= max_results:
                break

            try:
                content = report_path.read_text(encoding="utf-8")
                for i, line in enumerate(content.split("\n")):
                    if pattern in line.lower():
                        matches.append({
                            "date": report_path.stem,
                            "line_number": i + 1,
                            "content": line.strip()[:300],
                        })
                        if len(matches) >= max_results:
                            break
            except Exception:
                continue

        return json.dumps({
            "pattern": arguments["pattern"],
            "total": len(matches),
            "matches": matches,
        })


class ListReports(AgentTool):
    """List available daily reports."""

    name = "ListReports"
    description = (
        "List available daily activity reports with basic stats. "
        "Use this to see which days have reports and their sizes."
    )

    def __init__(self, reports_dir: Path) -> None:
        self._reports_dir = reports_dir

    def parameters_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "last_n": {
                    "type": "integer",
                    "description": "Number of recent reports to list (default 14)",
                    "default": 14,
                },
            },
        }

    async def execute(self, arguments: Dict[str, Any]) -> str:
        last_n = arguments.get("last_n", 14)

        if not self._reports_dir.exists():
            return json.dumps({"reports": [], "total": 0})

        reports = []
        # Use time-partitioned file iteration
        for f in _iter_time_partitioned_files(self._reports_dir, "md", last_n_days=90)[:last_n]:
            try:
                stat = f.stat()
                reports.append({
                    "date": f.stem,
                    "size_bytes": stat.st_size,
                })
            except Exception:
                continue

        return json.dumps({
            "total": len(reports),
            "reports": reports,
        })
