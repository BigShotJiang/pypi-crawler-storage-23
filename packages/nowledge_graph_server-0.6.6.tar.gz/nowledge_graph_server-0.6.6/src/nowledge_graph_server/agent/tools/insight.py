"""CreateInsight tool — append insights to the daily report and feed file.

Uses time-partitioned file structure:
- Reports: reports/YYYY/MM/YYYY-MM-DD.md
- Events: events/YYYY/MM/YYYY-MM-DD.jsonl
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

import structlog

from .base import AgentTool
from nowledge_graph_server.utils.feed_events import emit_feed_event

logger = structlog.get_logger(__name__)


class CreateInsight(AgentTool):
    """Create a system event / insight written to the file-based Feed."""

    name = "CreateInsight"
    description = (
        "Create an insight or observation that appears in the Feed timeline. "
        "Use this for observations, patterns, emerging clusters, daily briefing entries, "
        "or any noteworthy finding. Insights are written to the daily report file "
        "and a feed JSONL file for the UI to consume."
    )

    def __init__(self, reports_dir: Path, events_dir: Path) -> None:
        self._reports_dir = reports_dir
        self._events_dir = events_dir

    def parameters_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "event_type": {
                    "type": "string",
                    "enum": [
                        "insight_generated",
                        "pattern_detected",
                        "agent_observation",
                        "daily_briefing",
                    ],
                    "description": "Type of insight event: insight_generated (connection), pattern_detected (recurring theme), agent_observation (recommendation), daily_briefing",
                },
                "title": {
                    "type": "string",
                    "description": "Short, human-readable title for the event",
                },
                "description": {
                    "type": "string",
                    "description": "Detailed description of the insight or observation",
                },
                "severity": {
                    "type": "string",
                    "enum": ["info", "warning", "action_required"],
                    "description": "Severity level (default: info)",
                    "default": "info",
                },
                "related_memory_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "IDs of memories related to this insight",
                    "default": [],
                },
                "metadata_json": {
                    "type": "string",
                    "description": "Optional JSON string with extra event-specific data",
                },
            },
            "required": ["event_type", "title", "description"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> str:
        event_type = arguments["event_type"]
        title = arguments["title"]
        description = arguments["description"]
        severity = arguments.get("severity", "info")
        raw_ids = arguments.get("related_memory_ids", [])
        # LLMs sometimes pass JSON-encoded strings instead of arrays
        if isinstance(raw_ids, str):
            try:
                parsed = json.loads(raw_ids)
                if isinstance(parsed, list):
                    raw_ids = parsed
                else:
                    raw_ids = [raw_ids] if raw_ids.strip() else []
            except (json.JSONDecodeError, TypeError):
                raw_ids = [raw_ids] if raw_ids.strip() else []
        related_ids: List[str] = raw_ids
        raw_meta = arguments.get("metadata_json", "{}")
        # LLMs sometimes pass a dict object instead of a JSON string
        if isinstance(raw_meta, dict):
            metadata = raw_meta
        else:
            try:
                metadata = json.loads(raw_meta)
            except (json.JSONDecodeError, TypeError):
                metadata = {}

        # --- Quality gates (defense-in-depth) ---

        # Gate 1: Suppress empty daily briefings — silence is better than noise
        if event_type == "daily_briefing":
            insights = metadata.get("insights", [])
            crystals = metadata.get("crystals", [])
            flags = metadata.get("flags", [])
            if not insights and not crystals and not flags:
                logger.info("Suppressing empty daily briefing — no findings")
                return json.dumps({
                    "success": True,
                    "skipped": True,
                    "reason": "No findings to report — briefing suppressed",
                })

        # Gate 2: Non-briefing insights must reference real memories
        if event_type != "daily_briefing" and not related_ids:
            logger.info(
                "Rejecting insight without evidence — no related_memory_ids",
                event_type=event_type,
                title=title,
            )
            return json.dumps({
                "success": True,
                "skipped": True,
                "reason": "Insights must reference specific memories (related_memory_ids). "
                "An insight without evidence is noise.",
            })

        # Gate 3: Content must be substantive
        if len(description.strip()) < 30:
            logger.info(
                "Rejecting insight with trivial content",
                event_type=event_type,
                content_len=len(description),
            )
            return json.dumps({
                "success": True,
                "skipped": True,
                "reason": "Insight content too brief (<30 chars). Provide substantive detail.",
            })

        try:
            event_id = emit_feed_event(
                event_type,
                title=title,
                description=description,
                severity=severity,
                related_memory_ids=related_ids,
                metadata=metadata,
                write_report=True,
            )

            logger.info(
                "Created insight (file-based)",
                event_id=event_id,
                event_type=event_type,
                severity=severity,
            )

            return json.dumps({
                "success": True,
                "event_id": event_id,
                "event_type": event_type,
                "title": title,
                "severity": severity,
                "related_memories": len(related_ids),
            })

        except Exception as e:
            logger.error("CreateInsight failed", error=str(e))
            return json.dumps({"error": f"Failed to create insight: {e}"})
