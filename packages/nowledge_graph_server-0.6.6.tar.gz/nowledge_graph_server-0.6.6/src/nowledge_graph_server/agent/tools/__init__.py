"""Knowledge Agent tools — each tool is a separate module.

Tools provide the agent with capabilities to query and mutate the
knowledge graph, create system events, and access historical reports.
"""
