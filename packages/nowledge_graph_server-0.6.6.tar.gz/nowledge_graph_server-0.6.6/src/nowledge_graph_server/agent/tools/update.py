"""UpdateMemoryMeta tool — update metadata fields on a memory."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Dict

import structlog

from nowledge_graph_server.database.result_utils import managed_result

from .base import AgentTool, resync_memory_to_lancedb

logger = structlog.get_logger(__name__)


class UpdateMemoryMeta(AgentTool):
    """Update metadata fields on a memory."""

    name = "UpdateMemoryMeta"
    description = (
        "Update metadata fields on a memory: unit_type, importance, or is_latest. "
        "Use this to reclassify memories, adjust importance, or manage version chains."
    )

    def __init__(self, db: Any, memory_ops: Any) -> None:
        self._db = db
        self._memory_ops = memory_ops

    def parameters_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "memory_id": {
                    "type": "string",
                    "description": "ID of the memory to update",
                },
                "unit_type": {
                    "type": "string",
                    "enum": ["fact", "preference", "decision", "plan", "procedure", "learning", "context", "event"],
                    "description": "New unit type classification",
                },
                "importance": {
                    "type": "number",
                    "description": "New importance score (0.0-1.0)",
                    "minimum": 0.0,
                    "maximum": 1.0,
                },
                "is_latest": {
                    "type": "boolean",
                    "description": "Whether this is the latest version in an EVOLVES chain",
                },
            },
            "required": ["memory_id"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> str:
        memory_id = arguments["memory_id"]
        now = datetime.now(timezone.utc).isoformat()

        # Build SET clause dynamically
        set_parts = []
        params: Dict[str, Any] = {"id": memory_id, "now": now}

        if "unit_type" in arguments:
            set_parts.append("m.unit_type = $unit_type")
            params["unit_type"] = arguments["unit_type"]

        if "importance" in arguments:
            set_parts.append("m.importance = $importance")
            params["importance"] = arguments["importance"]

        if "is_latest" in arguments:
            set_parts.append("m.is_latest = $is_latest")
            params["is_latest"] = arguments["is_latest"]

        if not set_parts:
            return json.dumps({"error": "No fields to update. Provide at least one of: unit_type, importance, is_latest"})

        # Always update updated_at
        set_parts.append("m.updated_at = timestamp($now)")

        try:
            conn = self._db.conn

            # Verify memory exists
            with managed_result(conn.execute(
                "MATCH (m:Memory) WHERE m.id = $id RETURN m.id",
                {"id": memory_id},
            )) as check:
                if not check.has_next():
                    return json.dumps({"error": f"Memory not found: {memory_id}"})

            query = f"MATCH (m:Memory) WHERE m.id = $id SET {', '.join(set_parts)}"
            conn.execute(query, params)

            updated_fields = [k for k in ("unit_type", "importance", "is_latest") if k in arguments]

            # Re-sync to LanceDB so search scoring reflects the updates
            await resync_memory_to_lancedb(self._memory_ops, memory_id)

            logger.info(
                "Updated memory metadata",
                memory_id=memory_id,
                fields=updated_fields,
            )

            return json.dumps({
                "success": True,
                "memory_id": memory_id,
                "updated_fields": updated_fields,
            })

        except Exception as e:
            logger.error("UpdateMemoryMeta failed", error=str(e))
            return json.dumps({"error": f"Failed to update memory: {e}"})

