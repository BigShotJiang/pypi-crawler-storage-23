"""FlagForReview tool — flag memories needing user attention (file-based).

Uses time-partitioned file structure:
- Reports: reports/YYYY/MM/YYYY-MM-DD.md
- Events: events/YYYY/MM/YYYY-MM-DD.jsonl
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

import structlog

from .base import AgentTool
from nowledge_graph_server.utils.feed_events import emit_feed_event

logger = structlog.get_logger(__name__)


class FlagForReview(AgentTool):
    """Flag memories that need user attention."""

    name = "FlagForReview"
    description = (
        "Flag MEMORY nodes that need user attention — contradictions, stale info, "
        "merge candidates, or general review items. Only flag actual Memory nodes "
        "in the graph, never insights, feed events, or briefings. Creates a feed "
        "event with severity 'action_required' written to the feed file and daily report."
    )

    def __init__(self, reports_dir: Path, events_dir: Path) -> None:
        self._reports_dir = reports_dir
        self._events_dir = events_dir

    def parameters_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "title": {
                    "type": "string",
                    "description": "Short title describing the flag",
                },
                "description": {
                    "type": "string",
                    "description": "Detailed explanation of what needs attention and why",
                },
                "memory_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "IDs of the memories that are flagged",
                    "minItems": 1,
                },
                "flag_type": {
                    "type": "string",
                    "enum": ["contradiction", "stale", "merge_candidate", "review"],
                    "description": "Type of flag",
                },
            },
            "required": ["title", "description", "memory_ids", "flag_type"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> str:
        title = arguments["title"]
        description = arguments["description"]
        flag_type = arguments["flag_type"]

        # LLMs sometimes pass JSON-encoded strings instead of arrays
        raw_ids = arguments["memory_ids"]
        if isinstance(raw_ids, str):
            try:
                parsed = json.loads(raw_ids)
                if isinstance(parsed, list):
                    raw_ids = parsed
                else:
                    raw_ids = [raw_ids] if raw_ids.strip() else []
            except (json.JSONDecodeError, TypeError):
                raw_ids = [raw_ids] if raw_ids.strip() else []
        memory_ids: List[str] = raw_ids

        try:
            event_id = emit_feed_event(
                f"flag_{flag_type}",
                title=title,
                description=description,
                severity="action_required",
                related_memory_ids=memory_ids,
                metadata={
                    "flag_type": flag_type,
                    "memory_ids": memory_ids,
                },
                write_report=True,
            )

            logger.info(
                "Created flag for review (file-based)",
                event_id=event_id,
                flag_type=flag_type,
                memory_count=len(memory_ids),
            )

            return json.dumps({
                "success": True,
                "event_id": event_id,
                "flag_type": flag_type,
                "memory_count": len(memory_ids),
            })

        except Exception as e:
            logger.error("FlagForReview failed", error=str(e))
            return json.dumps({"error": f"Failed to create flag: {e}"})
