"""QueryMemories tool — search the knowledge graph for memories."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import structlog

from .base import AgentTool
from nowledge_graph_server.agent.utils.search_results import (
    _normalize_search_result,
    _get_search_score,
)

logger = structlog.get_logger(__name__)


class QueryMemories(AgentTool):
    """Search the knowledge graph for memories matching a query."""

    name = "QueryMemories"
    description = (
        "Search the knowledge graph for memories matching a semantic query. "
        "Returns matching memories with their id, content, importance, unit_type, "
        "is_latest, is_crystal, source, and created_at. "
        "Use this to find related memories before creating EVOLVES edges or crystals."
    )

    def __init__(self, search_ops: Any, db: Any) -> None:
        self._search_ops = search_ops
        self._db = db

    def parameters_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Semantic search query",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max results to return (default 20)",
                    "default": 20,
                },
                "unit_type": {
                    "type": "string",
                    "description": "Filter by unit type: fact|preference|decision|plan|procedure|learning|context|event",
                    "enum": ["fact", "preference", "decision", "plan", "procedure", "learning", "context", "event"],
                },
                "is_latest_only": {
                    "type": "boolean",
                    "description": "Only return version chain heads (default false)",
                    "default": False,
                },
                "is_crystal": {
                    "type": "boolean",
                    "description": "Filter to crystals only (true) or non-crystals only (false)",
                },
                "since_hours": {
                    "type": "number",
                    "description": "Only return memories created within the last N hours",
                },
            },
            "required": ["query"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> str:
        query = arguments.get("query", "")
        limit = arguments.get("limit", 20)

        try:
            # Use search operations for semantic search
            results = await self._search_ops.search_memories(
                query=query,
                limit=min(limit, 50),  # Cap at 50 to prevent huge payloads
            )

            # Post-filter based on optional parameters
            filtered = []
            for r in results:
                mem = _normalize_search_result(r)
                if not mem:
                    continue

                # Apply unit_type filter
                if "unit_type" in arguments and arguments["unit_type"]:
                    if mem.get("unit_type") != arguments["unit_type"]:
                        continue

                # Apply is_latest_only filter
                if arguments.get("is_latest_only") and not mem.get("is_latest", True):
                    continue

                # Apply is_crystal filter
                if "is_crystal" in arguments:
                    if mem.get("is_crystal", False) != arguments["is_crystal"]:
                        continue

                # Apply since_hours filter
                if "since_hours" in arguments and arguments["since_hours"]:
                    created_at = mem.get("created_at")
                    if created_at:
                        if isinstance(created_at, str):
                            created_at = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
                        elif isinstance(created_at, datetime):
                            created_at = created_at.astimezone(timezone.utc)
                        now = datetime.now(timezone.utc)
                        hours_ago = (now - created_at).total_seconds() / 3600
                        if hours_ago > arguments["since_hours"]:
                            continue

                filtered.append({
                    "id": mem.get("id", ""),
                    "content": (mem.get("content", "") or "")[:500],  # Truncate for context window
                    "title": mem.get("title", ""),
                    "importance": mem.get("importance"),
                    "unit_type": mem.get("unit_type", "fact"),
                    "is_latest": mem.get("is_latest", True),
                    "is_crystal": mem.get("is_crystal", False),
                    "source": mem.get("source", ""),
                    "created_at": str(mem.get("created_at", "")),
                    "score": _get_search_score(r, mem),
                })

            return json.dumps({
                "count": len(filtered),
                "memories": filtered[:limit],
            })

        except Exception as e:
            logger.error("QueryMemories failed", error=str(e))
            return json.dumps({"error": f"Search failed: {e}", "count": 0, "memories": []})
