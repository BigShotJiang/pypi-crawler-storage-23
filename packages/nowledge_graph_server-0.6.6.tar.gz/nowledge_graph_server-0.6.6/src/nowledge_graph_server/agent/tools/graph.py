"""QueryMemoryNeighbors tool — traverse the knowledge graph around a memory."""

from __future__ import annotations

import json
from typing import Any, Dict, List

import structlog

from .base import AgentTool

logger = structlog.get_logger(__name__)


class QueryMemoryNeighbors(AgentTool):
    """Get graph neighbors of a memory."""

    name = "QueryMemoryNeighbors"
    description = (
        "Get graph neighbors of a memory, including EVOLVES chains, "
        "entity mentions, and crystal relationships. "
        "Use this to understand a memory's context in the knowledge graph "
        "before making decisions about relationships or crystallization."
    )

    def __init__(self, db: Any) -> None:
        self._db = db

    def parameters_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "memory_id": {
                    "type": "string",
                    "description": "ID of the memory to explore",
                },
                "edge_types": {
                    "type": "array",
                    "items": {
                        "type": "string",
                        "enum": [
                            "EVOLVES", "MENTIONS", "CRYSTALLIZED_FROM",
                            "EXTRACTED_FROM",
                        ],
                    },
                    "description": "Edge types to traverse (default: all)",
                    "default": ["EVOLVES", "MENTIONS", "CRYSTALLIZED_FROM"],
                },
                "depth": {
                    "type": "integer",
                    "description": "Traversal depth 1-3 (default 1)",
                    "default": 1,
                    "minimum": 1,
                    "maximum": 3,
                },
            },
            "required": ["memory_id"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> str:
        memory_id = arguments["memory_id"]
        edge_types = arguments.get("edge_types", ["EVOLVES", "MENTIONS", "CRYSTALLIZED_FROM"])
        depth = min(arguments.get("depth", 1), 3)

        try:
            conn = self._db.conn
            neighbors: Dict[str, List[Dict[str, Any]]] = {}

            # Query EVOLVES edges (outgoing: older → newer, so outgoing = this is the older memory)
            if "EVOLVES" in edge_types:
                evolves_out = []
                try:
                    result = conn.execute(
                        """
                        MATCH (a:Memory)-[e:EVOLVES]->(b:Memory)
                        WHERE a.id = $id
                        RETURN b.id, b.content, b.title, e.content_relation,
                               e.confidence, e.reviewed, e.reason, b.is_latest
                        """,
                        {"id": memory_id},
                    )
                    while result.has_next():
                        row = result.get_next()
                        evolves_out.append({
                            "direction": "outgoing",
                            "target_id": row[0],
                            "target_content": (row[1] or "")[:200],
                            "target_title": row[2],
                            "content_relation": row[3],
                            "confidence": row[4],
                            "reviewed": row[5],
                            "reason": row[6],
                            "target_is_latest": row[7],
                        })
                except Exception as e:
                    logger.warning("Graph neighbor query failed", edge_type="EVOLVES", error=str(e))

                # Incoming EVOLVES
                evolves_in = []
                try:
                    result = conn.execute(
                        """
                        MATCH (a:Memory)-[e:EVOLVES]->(b:Memory)
                        WHERE b.id = $id
                        RETURN a.id, a.content, a.title, e.content_relation,
                               e.confidence, e.reviewed, e.reason, a.is_latest
                        """,
                        {"id": memory_id},
                    )
                    while result.has_next():
                        row = result.get_next()
                        evolves_in.append({
                            "direction": "incoming",
                            "source_id": row[0],
                            "source_content": (row[1] or "")[:200],
                            "source_title": row[2],
                            "content_relation": row[3],
                            "confidence": row[4],
                            "reviewed": row[5],
                            "reason": row[6],
                            "source_is_latest": row[7],
                        })
                except Exception as e:
                    logger.warning("Graph neighbor query failed", edge_type="EVOLVES", error=str(e))

                neighbors["EVOLVES"] = evolves_out + evolves_in

            # Query MENTIONS edges (memory -> entity)
            if "MENTIONS" in edge_types:
                mentions = []
                try:
                    result = conn.execute(
                        """
                        MATCH (m:Memory)-[r:MENTIONS]->(e:Entity)
                        WHERE m.id = $id
                        RETURN e.id, e.name, e.entity_type, r.confidence
                        """,
                        {"id": memory_id},
                    )
                    while result.has_next():
                        row = result.get_next()
                        mentions.append({
                            "entity_id": row[0],
                            "entity_name": row[1],
                            "entity_type": row[2],
                            "confidence": row[3],
                        })
                except Exception as e:
                    logger.warning("Graph neighbor query failed", edge_type="MENTIONS", error=str(e))
                neighbors["MENTIONS"] = mentions

            # Query CRYSTALLIZED_FROM edges
            if "CRYSTALLIZED_FROM" in edge_types:
                crystal_links = []
                try:
                    # This memory is a crystal, find sources
                    result = conn.execute(
                        """
                        MATCH (c:Memory)-[r:CRYSTALLIZED_FROM]->(s:Memory)
                        WHERE c.id = $id
                        RETURN s.id, s.content, s.title, r.contribution_weight
                        """,
                        {"id": memory_id},
                    )
                    while result.has_next():
                        row = result.get_next()
                        crystal_links.append({
                            "direction": "crystal_to_source",
                            "source_id": row[0],
                            "source_content": (row[1] or "")[:200],
                            "source_title": row[2],
                            "weight": row[3],
                        })
                except Exception as e:
                    logger.warning("Graph neighbor query failed", edge_type="CRYSTALLIZED_FROM", error=str(e))

                try:
                    # This memory is a source, find crystals
                    result = conn.execute(
                        """
                        MATCH (c:Memory)-[r:CRYSTALLIZED_FROM]->(s:Memory)
                        WHERE s.id = $id
                        RETURN c.id, c.content, c.crystal_title, r.contribution_weight
                        """,
                        {"id": memory_id},
                    )
                    while result.has_next():
                        row = result.get_next()
                        crystal_links.append({
                            "direction": "source_to_crystal",
                            "crystal_id": row[0],
                            "crystal_content": (row[1] or "")[:200],
                            "crystal_title": row[2],
                            "weight": row[3],
                        })
                except Exception as e:
                    logger.warning("Graph neighbor query failed", edge_type="CRYSTALLIZED_FROM", error=str(e))
                neighbors["CRYSTALLIZED_FROM"] = crystal_links

            total = sum(len(v) for v in neighbors.values())

            return json.dumps({
                "memory_id": memory_id,
                "total_neighbors": total,
                "neighbors": neighbors,
            })

        except Exception as e:
            logger.error("QueryMemoryNeighbors failed", error=str(e))
            return json.dumps({"error": f"Failed to get neighbors: {e}"})
