"""Base class and registry for Knowledge Agent tools.

Each tool is a Python class with:
- A name and description (for the LLM)
- A JSON Schema for its parameters
- An async ``execute`` method that performs the operation

The tool registry converts all registered tools into the OpenAI-compatible
``tools`` array that litellm expects.
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Type

import structlog

logger = structlog.get_logger(__name__)


async def resync_memory_to_lancedb(memory_ops: Any, memory_id: str) -> None:
    """Re-sync a memory to LanceDB after KuzuDB field updates.

    Shared helper used by agent tools that modify KuzuDB fields which
    are also stored in the LanceDB search index (e.g. is_latest, is_crystal).
    """
    try:
        from ...services.search_index import sync_memory_to_index

        memory = await memory_ops.get_memory_by_id(memory_id)
        if memory:
            await sync_memory_to_index(memory)
            logger.debug("Re-synced memory to LanceDB", memory_id=memory_id)
    except Exception as e:
        logger.warning(
            "Failed to re-sync memory to LanceDB",
            memory_id=memory_id,
            error=str(e),
        )


class AgentTool(ABC):
    """Base class for a Knowledge Agent tool."""

    name: str = ""
    description: str = ""

    @abstractmethod
    def parameters_schema(self) -> Dict[str, Any]:
        """Return the JSON Schema for this tool's parameters."""
        ...

    @abstractmethod
    async def execute(self, arguments: Dict[str, Any]) -> str:
        """Execute the tool with parsed arguments, return a string result."""
        ...

    def to_openai_tool(self) -> Dict[str, Any]:
        """Convert to the OpenAI function-calling tool format."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters_schema(),
            },
        }


class ToolRegistry:
    """Holds all registered tools and dispatches calls."""

    def __init__(self) -> None:
        self._tools: Dict[str, AgentTool] = {}

    def register(self, tool: AgentTool) -> None:
        if tool.name in self._tools:
            logger.warning("Tool already registered, overwriting", name=tool.name)
        self._tools[tool.name] = tool

    def get(self, name: str) -> Optional[AgentTool]:
        return self._tools.get(name)

    def to_openai_tools(self) -> List[Dict[str, Any]]:
        """Return all tools in the OpenAI function-calling format."""
        return [t.to_openai_tool() for t in self._tools.values()]

    async def execute(self, name: str, arguments_json: str) -> str:
        """Execute a tool by name with JSON-encoded arguments."""
        tool = self._tools.get(name)
        if tool is None:
            return json.dumps({"error": f"Unknown tool: {name}"})

        try:
            args = json.loads(arguments_json) if arguments_json else {}
        except json.JSONDecodeError as e:
            return json.dumps({"error": f"Invalid JSON arguments: {e}"})

        try:
            return await tool.execute(args)
        except Exception as e:
            logger.error("Tool execution failed", tool=name, error=str(e))
            return json.dumps({"error": f"Tool {name} failed: {e}"})

    @property
    def tool_names(self) -> List[str]:
        return list(self._tools.keys())
