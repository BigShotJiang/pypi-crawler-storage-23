"""CreateEVOLVES tool — create EVOLVES relationships between memories."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Dict

import structlog

from nowledge_graph_server.database.result_utils import managed_result

from .base import AgentTool, resync_memory_to_lancedb

logger = structlog.get_logger(__name__)


class CreateEVOLVES(AgentTool):
    """Create an EVOLVES relationship between two memories.

    Edge direction: older → newer (matching the design spec).
    When content_relation is 'replaces', the older memory's is_latest
    flag is automatically set to false (DB invariant).
    """

    name = "CreateEVOLVES"
    description = (
        "Create an EVOLVES relationship between two memories. "
        "Edge direction is older → newer. "
        "Relationship types: replaces (newer makes older obsolete), "
        "enriches (newer adds detail), confirms (same info different source), "
        "challenges (contradictory information). "
        "older_memory_id is the OLDER memory (edge source), "
        "newer_memory_id is the NEWER memory (edge target). "
        "When content_relation='replaces', the older memory's is_latest is set to false."
    )

    def __init__(self, db: Any, memory_ops: Any) -> None:
        self._db = db
        self._memory_ops = memory_ops

    def parameters_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "older_memory_id": {
                    "type": "string",
                    "description": "ID of the older/existing memory (edge source)",
                },
                "newer_memory_id": {
                    "type": "string",
                    "description": "ID of the newer/incoming memory (edge target)",
                },
                "content_relation": {
                    "type": "string",
                    "enum": ["replaces", "enriches", "confirms", "challenges"],
                    "description": "Type of evolutionary relationship",
                },
                "confidence": {
                    "type": "number",
                    "description": "Confidence in this relationship (0.0-1.0, default 0.8)",
                    "default": 0.8,
                },
                "reason": {
                    "type": "string",
                    "description": "Brief explanation of why this relationship exists",
                },
            },
            "required": ["older_memory_id", "newer_memory_id", "content_relation", "reason"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> str:
        older_id = arguments["older_memory_id"]
        newer_id = arguments["newer_memory_id"]
        relation = arguments["content_relation"]
        confidence = arguments.get("confidence", 0.8)
        reason = arguments.get("reason", "")
        now = datetime.now(timezone.utc).isoformat()

        # Gate: Self-link prevention
        if older_id == newer_id:
            return json.dumps({"error": "Cannot create EVOLVES edge from memory to itself", "skipped": True})

        # Gate: Confidence floor — prompt says >0.7, enforce it
        if confidence < 0.7:
            logger.info("EVOLVES rejected: low confidence", confidence=confidence, older_id=older_id, newer_id=newer_id)
            return json.dumps({
                "error": f"Confidence {confidence:.2f} below threshold 0.7 — edge not created",
                "skipped": True,
            })

        try:
            conn = self._db.conn

            # Verify both memories exist
            with managed_result(conn.execute(
                "MATCH (m:Memory) WHERE m.id = $id RETURN m.id",
                {"id": older_id},
            )) as check:
                if not check.has_next():
                    return json.dumps({"error": f"Memory not found: {older_id}"})

            with managed_result(conn.execute(
                "MATCH (m:Memory) WHERE m.id = $id RETURN m.id",
                {"id": newer_id},
            )) as check:
                if not check.has_next():
                    return json.dumps({"error": f"Memory not found: {newer_id}"})

            # Gate: Duplicate edge detection
            with managed_result(conn.execute(
                """
                MATCH (a:Memory)-[e:EVOLVES]->(b:Memory)
                WHERE a.id = $older_id AND b.id = $newer_id
                RETURN e.content_relation
                """,
                {"older_id": older_id, "newer_id": newer_id},
            )) as dup_check:
                if dup_check.has_next():
                    existing_relation = dup_check.get_next()[0]
                    logger.info("EVOLVES skipped: duplicate edge", older_id=older_id, newer_id=newer_id, existing=existing_relation)
                    return json.dumps({
                        "skipped": True,
                        "reason": f"EVOLVES edge already exists ({existing_relation})",
                    })

            # Create the EVOLVES edge: older → newer
            conn.execute(
                """
                MATCH (a:Memory), (b:Memory)
                WHERE a.id = $older_id AND b.id = $newer_id
                CREATE (a)-[:EVOLVES {
                    content_relation: $relation,
                    is_progression: $is_prog,
                    confidence: $confidence,
                    detected_by: 'agent',
                    reviewed: false,
                    reason: $reason,
                    created_at: timestamp($now)
                }]->(b)
                """,
                {
                    "older_id": older_id,
                    "newer_id": newer_id,
                    "relation": relation,
                    "is_prog": relation in ("replaces", "enriches"),
                    "confidence": confidence,
                    "reason": reason,
                    "now": now,
                },
            )

            # Auto-update is_latest when 'replaces' (DB invariant):
            # The older memory is no longer the latest version
            if relation == "replaces":
                conn.execute(
                    """
                    MATCH (m:Memory)
                    WHERE m.id = $older_id
                    SET m.is_latest = false
                    """,
                    {"older_id": older_id},
                )
                # Re-sync older memory to LanceDB so search scoring
                # correctly demotes the superseded memory
                await resync_memory_to_lancedb(self._memory_ops, older_id)

            # Emit feed event so EVOLVES edges are visible in timeline
            from nowledge_graph_server.utils.feed_events import emit_feed_event
            emit_feed_event(
                "evolves_detected",
                title=f"Memory updated: {relation}",
                description=reason,
                related_memory_ids=[older_id, newer_id],
                metadata={
                    "older_memory_id": older_id,
                    "newer_memory_id": newer_id,
                    "content_relation": relation,
                    "confidence": confidence,
                },
            )

            logger.info(
                "Created EVOLVES edge",
                older_id=older_id,
                newer_id=newer_id,
                relation=relation,
            )

            # Notify scheduler for cluster evaluation chain (fire-and-forget)
            try:
                import asyncio
                from ..manager import KnowledgeAgentManager
                mgr = KnowledgeAgentManager.get_instance()
                if mgr.is_running:
                    edge_id = f"{older_id}__{newer_id}"
                    asyncio.create_task(mgr.on_evolves_detected(edge_id))
            except Exception:
                pass  # Scheduler notification is best-effort

            return json.dumps({
                "success": True,
                "older_memory_id": older_id,
                "newer_memory_id": newer_id,
                "content_relation": relation,
                "confidence": confidence,
                "is_latest_updated": relation == "replaces",
            })

        except Exception as e:
            logger.error("CreateEVOLVES failed", error=str(e))
            return json.dumps({"error": f"Failed to create EVOLVES edge: {e}"})

