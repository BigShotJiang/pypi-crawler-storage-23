"""CreateCrystal tool — create crystallized knowledge from multiple source memories."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Dict, List

import structlog

from nowledge_graph_server.database.result_utils import managed_result

from .base import AgentTool, resync_memory_to_lancedb
from nowledge_graph_server.utils.feed_events import emit_feed_event

logger = structlog.get_logger(__name__)


class CreateCrystal(AgentTool):
    """Create a crystal (consolidated knowledge) from multiple source memories."""

    name = "CreateCrystal"
    description = (
        "Create a crystal — a consolidated, high-quality knowledge unit synthesized "
        "from multiple source memories. Crystals are context-independent summaries "
        "that capture the essential knowledge. The tool creates the crystal Memory node "
        "(with embedding for search) and CRYSTALLIZED_FROM edges to all source memories."
    )

    def __init__(self, db: Any, memory_ops: Any) -> None:
        self._db = db
        self._memory_ops = memory_ops

    def parameters_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "title": {
                    "type": "string",
                    "description": "Human-readable title for the crystal",
                },
                "content": {
                    "type": "string",
                    "description": "The synthesized crystal content — should be context-independent and comprehensive",
                },
                "unit_type": {
                    "type": "string",
                    "enum": ["fact", "preference", "decision", "plan", "procedure", "learning", "context", "event"],
                    "description": "Knowledge unit type for the crystal",
                },
                "source_memory_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "IDs of the source memories this crystal synthesizes",
                    "minItems": 3,
                },
                "importance": {
                    "type": "number",
                    "description": "Importance score 0.0-1.0 (default 0.8 for crystals)",
                    "default": 0.8,
                },
            },
            "required": ["title", "content", "unit_type", "source_memory_ids"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> str:
        title = arguments["title"]
        content = arguments["content"]
        unit_type = arguments["unit_type"]
        raw_src_ids = arguments["source_memory_ids"]
        # LLMs sometimes pass JSON-encoded strings instead of arrays
        if isinstance(raw_src_ids, str):
            try:
                parsed = json.loads(raw_src_ids)
                if isinstance(parsed, list):
                    raw_src_ids = parsed
                else:
                    raw_src_ids = [raw_src_ids] if raw_src_ids.strip() else []
            except (json.JSONDecodeError, TypeError):
                raw_src_ids = [raw_src_ids] if raw_src_ids.strip() else []
        source_ids: List[str] = raw_src_ids
        importance = arguments.get("importance", 0.8)
        now = datetime.now(timezone.utc)

        try:
            conn = self._db.conn

            # Verify source memories exist
            for sid in source_ids:
                with managed_result(conn.execute(
                    "MATCH (m:Memory) WHERE m.id = $id RETURN m.id",
                    {"id": sid},
                )) as check:
                    if not check.has_next():
                        return json.dumps({"error": f"Source memory not found: {sid}"})

            # Create the crystal via memory_ops (handles KuzuDB + LanceDB embedding)
            result = await self._memory_ops.create_memory(
                content=content,
                title=title,
                source="knowledge_agent",
                importance=importance,
                confidence=1.0,
                extract_entities=False,
            )

            if result is None or result.memory is None:
                return json.dumps({"error": "Failed to create crystal memory"})

            crystal_id = result.memory.id

            # Set crystal-specific fields (not handled by create_memory)
            conn.execute(
                """
                MATCH (m:Memory)
                WHERE m.id = $id
                SET m.unit_type = $unit_type,
                    m.is_crystal = true,
                    m.crystal_title = $title,
                    m.source_unit_count = $src_count,
                    m.extraction_method = 'agent',
                    m.last_evaluated_at = timestamp($now)
                """,
                {
                    "id": crystal_id,
                    "unit_type": unit_type,
                    "title": title,
                    "src_count": len(source_ids),
                    "now": now.isoformat(),
                },
            )

            # Re-sync to LanceDB so crystal boost scoring works
            # (create_memory synced with is_crystal=False; now it's True)
            await resync_memory_to_lancedb(self._memory_ops, crystal_id)

            # Create CRYSTALLIZED_FROM edges to each source
            for sid in source_ids:
                weight = 1.0 / len(source_ids)
                conn.execute(
                    """
                    MATCH (c:Memory), (s:Memory)
                    WHERE c.id = $crystal_id AND s.id = $source_id
                    CREATE (c)-[:CRYSTALLIZED_FROM {
                        contribution_weight: $weight,
                        created_at: timestamp($now)
                    }]->(s)
                    """,
                    {
                        "crystal_id": crystal_id,
                        "source_id": sid,
                        "weight": weight,
                        "now": now.isoformat(),
                    },
                )

            # Compute provenance from source memories
            source_platforms: list[str] = []
            source_dates: list[str] = []
            try:
                for sid in source_ids:
                    with managed_result(conn.execute(
                        "MATCH (m:Memory) WHERE m.id = $id RETURN m.source, m.created_at",
                        {"id": sid},
                    )) as row:
                        if row.has_next():
                            r = row.get_next()
                            src = r[0]
                            if src:
                                # Map raw source to display name
                                if src.startswith("library:"):
                                    display = "Library"
                                else:
                                    display = src.capitalize()
                                if display not in source_platforms:
                                    source_platforms.append(display)
                            if r[1]:
                                source_dates.append(str(r[1])[:10])
            except Exception:
                pass  # Provenance is best-effort

            time_span = ""
            if source_dates:
                sorted_dates = sorted(source_dates)
                if sorted_dates[0] != sorted_dates[-1]:
                    try:
                        d0 = datetime.strptime(sorted_dates[0], "%Y-%m-%d")
                        d1 = datetime.strptime(sorted_dates[-1], "%Y-%m-%d")
                        months = (d1.year - d0.year) * 12 + d1.month - d0.month
                        if months >= 2:
                            time_span = f"{d0.strftime('%b %Y')}–{d1.strftime('%b %Y')}"
                        else:
                            time_span = f"{d0.strftime('%b %d')}–{d1.strftime('%b %d, %Y')}"
                    except Exception:
                        pass

            # Emit feed event so crystal appears in the Feed timeline
            feed_metadata: dict = {
                "crystal_id": crystal_id,
                "source_count": len(source_ids),
            }
            if source_platforms:
                feed_metadata["source_platforms"] = source_platforms
            if time_span:
                feed_metadata["time_span"] = time_span

            emit_feed_event(
                "crystal_created",
                title=title,
                description=content[:1000],
                related_memory_ids=source_ids,
                metadata=feed_metadata,
            )

            logger.info(
                "Created crystal",
                crystal_id=crystal_id,
                title=title,
                source_count=len(source_ids),
            )

            return json.dumps({
                "success": True,
                "crystal_id": crystal_id,
                "title": title,
                "unit_type": unit_type,
                "source_count": len(source_ids),
            })

        except Exception as e:
            logger.error("CreateCrystal failed", error=str(e))
            return json.dumps({"error": f"Failed to create crystal: {e}"})

