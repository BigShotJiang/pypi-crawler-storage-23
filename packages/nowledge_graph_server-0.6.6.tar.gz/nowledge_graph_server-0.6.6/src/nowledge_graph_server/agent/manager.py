"""Knowledge Agent Manager — lifecycle, wiring, and FastAPI integration.

Manages the agent's lifecycle:
1. Creates the LLM client, tool registry, session, and scheduler
2. Starts/stops with FastAPI lifespan
3. Provides hooks for memory_operations to emit events
4. Exposes status for the REST API
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, AsyncGenerator, Dict, Optional

import structlog

# Import centralized path utilities FIRST (captures _REAL_HOME before any HOME modifications)
from .paths import get_builtin_agents_home

from .scheduler import AgentScheduler, AgentTask

from .context_helpers import gather_db_stats
from .task_dispatch import register_scheduled_jobs
from .task_executors import (
    execute_community_detection,
    execute_decay_refresh,
    execute_kg_extraction,
    execute_kg_extraction_backfill,
)

logger = structlog.get_logger(__name__)


def _get_builtin_agents_dir() -> Path:
    """Get the builtin agents directory (with mkdir)."""
    agent_dir = get_builtin_agents_home()
    agent_dir.mkdir(parents=True, exist_ok=True)
    return agent_dir


class KnowledgeAgentManager:
    """Singleton manager for the Knowledge Agent.

    Usage from FastAPI startup:
        manager = KnowledgeAgentManager()
        await manager.start(kuzu_client, search_ops, memory_ops)

    Usage from memory_operations (event hooks):
        if agent_manager and agent_manager.is_running:
            await agent_manager.on_memory_created(memory_id)
    """

    _instance: Optional["KnowledgeAgentManager"] = None

    def __init__(self) -> None:
        self._scheduler = AgentScheduler()
        self._session: Any = None  # KnowledgeAgentSession (kimi-agent-sdk based)
        self._running = False
        self._db: Any = None  # KuzuClient reference
        self._reports_dir: Optional[Path] = None
        self._events_dir: Optional[Path] = None  # Time-partitioned feed events
        self._startup_error: Optional[str] = None  # Tracks why startup failed

        # Feed agent (kimi-agent-sdk based, streaming)
        self._feed_session: Any = None  # FeedAgentSession
        self._feed_startup_error: Optional[str] = None  # Tracks why Feed agent failed
        self._search_ops: Any = None  # For Feed agent context
        self._feed_active_requests = 0  # Number of in-flight feed streaming requests
        # Serialize feed streaming requests (single session is not concurrency-safe).
        self._feed_stream_lock: Optional[asyncio.Lock] = None

        # Direct-function task executors (bypass LLM session for compute tasks)
        self._direct_executors: Dict[str, Any] = {}

        # For reactive startup (when LLM becomes available after initial startup)
        self._memory_ops: Any = None
        self._config_callback_registered = False
        self._pending_start_event_loop: Any = None  # Event loop for async callback

    @classmethod
    def get_instance(cls) -> "KnowledgeAgentManager":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(
        self,
        kuzu_client: Any,
        search_ops: Any,
        memory_ops: Any,
    ) -> None:
        """Initialize and start the Knowledge Agent.

        Called during FastAPI startup. Uses kimi-agent-sdk which handles
        LLM configuration internally via its own config file mechanism.

        IMPORTANT: Handles Tauri/Python startup race condition via reactive startup.
        """
        import asyncio

        self._db = kuzu_client
        self._search_ops = search_ops
        self._memory_ops = memory_ops

        # Store event loop for async callback (CRITICAL for reactive startup)
        try:
            self._pending_start_event_loop = asyncio.get_running_loop()
            logger.warning("[AGENT STARTUP] Captured event loop for reactive startup")
        except RuntimeError:
            self._pending_start_event_loop = None
            logger.error("[AGENT STARTUP] Could not capture event loop - reactive startup will fail!")

        logger.warning("[AGENT STARTUP] Knowledge Agent startup initiated (kimi-agent-sdk)")

        # Try to start immediately - kimi-agent-sdk handles LLM config internally
        # If it fails due to missing config, we'll enter reactive startup mode
        try:
            await self._do_start()
        except Exception as e:
            logger.warning(
                "[AGENT STARTUP] Initial start failed - entering reactive startup mode",
                error=str(e),
            )
            self._startup_error = f"Initial start failed: {e}"
            self._running = False

        # Register config change callback for reactive startup
        # This handles the case where config becomes available later (Tauri writes config)
        self._register_config_callback()

    async def _do_start(self, *, force_fresh: bool = False) -> None:
        """Internal: Actually start the agent (called from start() or config callback).

        Uses kimi-agent-sdk for LLM interactions. Both Knowledge Agent and Feed Agent
        now use kimi-agent-sdk for consistency.

        Args:
            force_fresh: If True, create fresh sessions instead of resuming.
                         Used during config-change restart to ensure new model is picked up.
        """
        logger.warning("[AGENT DO_START] _do_start called", already_running=self._running, force_fresh=force_fresh)

        if self._running:
            logger.warning("[AGENT DO_START] Already running, skipping start")
            return

        try:
            from .knowledge_agent_session import KnowledgeAgentSession
            from .knowledge_tools import KnowledgeAgentDependencies

            agent_dir = _get_builtin_agents_dir()
            knowledge_work_dir = agent_dir / "knowledge"  # Separate from feed/
            reports_dir = agent_dir / "reports"  # Time-partitioned: YYYY/MM/YYYY-MM-DD.md
            events_dir = agent_dir / "events"    # Time-partitioned: YYYY/MM/YYYY-MM-DD.jsonl

            logger.warning(
                "[AGENT DO_START] Starting initialization (kimi-agent-sdk)",
                agent_dir=str(agent_dir),
                knowledge_work_dir=str(knowledge_work_dir),
            )

            # Resolve paths
            self._reports_dir = reports_dir
            self._events_dir = events_dir

            # Configure tool dependencies (global registry for kimi-cli tools)
            KnowledgeAgentDependencies.configure(
                kuzu_client=self._db,
                search_ops=self._search_ops,
                memory_ops=self._memory_ops,
                reports_dir=reports_dir,
                events_dir=events_dir,
                scheduler=self._scheduler,
            )

            # Create Knowledge Agent session (kimi-agent-sdk based)
            agent_file = Path(__file__).parent / "knowledge_agent.yaml"
            self._session = KnowledgeAgentSession(
                work_dir=knowledge_work_dir,
                agent_file=agent_file,
                reports_dir=reports_dir,
                max_steps_per_turn=self._get_max_steps_per_task(),
            )

            # Start the session (force_fresh on config change to pick up new model)
            await self._session.start(yolo=True, force_fresh=force_fresh)

            # Write today's report header
            await self._session.write_daily_header()

            # Initialize token tracker with persistent storage (must be before scheduler)
            try:
                from . import token_tracker
                token_tracker.initialize(agent_dir / "state")
            except Exception as e:
                logger.warning("Token tracker init failed (in-memory only)", error=str(e))

            # Configure scheduler with file-based state persistence
            scheduler_state_path = agent_dir / "state" / "scheduler.json"
            self._scheduler.configure(
                task_executor=self._execute_task,
                state_path=scheduler_state_path,
            )

            # Register direct-function executors (bypass LLM for compute tasks)
            self._direct_executors = {
                "community_detection": self._execute_community_detection,
                "decay_refresh": self._execute_decay_refresh,
                "kg_extraction": self._execute_kg_extraction,
                "kg_extraction_backfill": self._execute_kg_extraction_backfill,
            }

            # Track last-executed timestamps for all tasks (direct + LLM)
            # Restore from scheduler state so timestamps survive app restarts
            self._last_executed: Dict[str, str] = (
                self._scheduler._get_state("last_executed") or {}
            )
            # Track currently running task for progress reporting
            self._current_task: Optional[Dict[str, Any]] = None

            # Register scheduled jobs
            self._register_scheduled_jobs()

            # Start scheduler
            await self._scheduler.start()
            self._running = True
            self._startup_error = None  # Clear any previous error

            # Initialize Feed agent session (kimi-agent-sdk based)
            await self._start_feed_agent(
                agent_dir, self._search_ops, reports_dir, events_dir,
                force_fresh=force_fresh,
            )

            logger.warning(
                "[AGENT DO_START] Knowledge Agent started successfully!",
                work_dir=str(knowledge_work_dir),
                reports_dir=str(reports_dir),
                total_tasks=self._session.total_tasks,
                feed_agent=self._feed_session is not None,
            )

        except Exception as e:
            logger.error(
                "[AGENT DO_START] Knowledge Agent startup FAILED",
                error=str(e),
                error_type=type(e).__name__,
            )
            self._startup_error = f"{type(e).__name__}: {e}"
            self._running = False
            raise  # Re-raise so start() can enter reactive mode

    def _register_config_callback(self) -> None:
        """Register callback with config manager to enable reactive startup.

        This is the key to handling the Tauri/Python startup race condition:
        when Tauri writes the config file, the file watcher triggers _load_config,
        which calls _notify_change_callbacks, which calls _on_config_changed,
        which tries to start the agent.

        kimi-agent-sdk handles LLM config internally via its config file.
        """
        if self._config_callback_registered:
            logger.info("[AGENT STARTUP] Config callback already registered")
            return

        try:
            from nowledge_graph_server.services.remote_llm_config import get_config_manager
            cm = get_config_manager()
            cm.register_change_callback(self._on_config_changed)
            self._config_callback_registered = True
            logger.warning(
                "[AGENT STARTUP] Registered config change callback for reactive startup",
                config_path=str(cm.config_path),
                config_exists=cm.config_path.exists(),
            )

            # If not running, try to start now (config might have been written)
            if not self._running and self._pending_start_event_loop is not None:
                import asyncio
                logger.warning("[AGENT STARTUP] Attempting reactive start...")
                asyncio.run_coroutine_threadsafe(
                    self._do_start(),
                    self._pending_start_event_loop,
                )
        except Exception as e:
            logger.error("[AGENT STARTUP] Failed to register config callback", error=str(e))

    def _on_config_changed(self) -> None:
        """Called when LLM config changes - restart agent to pick up new config.

        This handles two scenarios:
        1. REACTIVE STARTUP: if the agent couldn't start because LLM wasn't configured,
           it will start automatically when the config becomes available.
        2. HOT RELOAD: if the agent is already running, restart it to use the new model.
        """
        import asyncio

        logger.warning(
            "[AGENT REACTIVE] Config change callback triggered",
            already_running=self._running,
            db_initialized=self._db is not None,
            has_event_loop=self._pending_start_event_loop is not None,
        )

        # If already running, restart to pick up new config (hot reload)
        if self._running:
            logger.warning("[AGENT REACTIVE] Agent running, scheduling restart for config change")
            if self._pending_start_event_loop is not None:
                try:
                    # Check if event loop is still running
                    if self._pending_start_event_loop.is_closed():
                        logger.error("[AGENT REACTIVE] Event loop is closed! Cannot schedule restart.")
                        return
                    if not self._pending_start_event_loop.is_running():
                        logger.warning("[AGENT REACTIVE] Event loop not running, trying anyway...")

                    future = asyncio.run_coroutine_threadsafe(
                        self._restart_for_config_change(),
                        self._pending_start_event_loop,
                    )
                    logger.warning("[AGENT REACTIVE] Scheduled restart on event loop")

                    # Add callback to check if restart succeeded
                    def _check_restart(f):
                        try:
                            f.result(timeout=0)  # Don't block, just check
                            logger.warning("[AGENT REACTIVE] Restart completed successfully")
                        except Exception as e:
                            logger.error("[AGENT REACTIVE] Restart failed", error=str(e))

                    future.add_done_callback(_check_restart)
                except Exception as e:
                    logger.error("[AGENT REACTIVE] Failed to schedule restart", error=str(e), exc_info=True)
            else:
                logger.error("[AGENT REACTIVE] No event loop available for restart!")
            return

        # Skip if dependencies not set (start() not called yet)
        if self._db is None:
            logger.warning("[AGENT REACTIVE] Dependencies not set (start() not called yet), ignoring")
            return

        logger.warning("[AGENT REACTIVE] Config changed! Attempting to start agent...")

        # Schedule async start on the event loop
        if self._pending_start_event_loop is not None:
            try:
                asyncio.run_coroutine_threadsafe(
                    self._do_start(),
                    self._pending_start_event_loop,
                )
                logger.warning("[AGENT REACTIVE] Scheduled async start on event loop")
            except Exception as e:
                logger.error("[AGENT REACTIVE] Failed to schedule agent start", error=str(e))
        else:
            logger.error("[AGENT REACTIVE] No event loop available for reactive start")

    async def _restart_for_config_change(self) -> None:
        """Restart all agents to pick up new LLM config (hot reload).

        Called when user changes model in Settings while agents are running.
        kimi-agent-sdk freezes config at Session.create() time, so we must
        tear down and recreate all sessions to pick up the new model.

        Shutdown order (mirrors stop()): Feed Agent → Scheduler → Knowledge session.
        Startup is handled by _do_start() which creates everything fresh.
        """
        logger.warning(
            "[AGENT RESTART] Restarting all agents for config change...",
            feed_session_exists=self._feed_session is not None,
            knowledge_session_exists=self._session is not None,
            scheduler_running=self._scheduler.is_running,
        )

        # 1. Stop Feed agent first (depends on shared config)
        if self._feed_session:
            try:
                await self._feed_session.stop()
                logger.warning("[AGENT RESTART] Feed agent stopped")
            except Exception as e:
                logger.warning("[AGENT RESTART] Error stopping Feed agent", error=str(e))
            self._feed_session = None

        # 2. Stop scheduler (holds references to Knowledge session via task executor)
        if self._scheduler.is_running:
            try:
                await self._scheduler.stop()
                logger.warning("[AGENT RESTART] Scheduler stopped")
            except Exception as e:
                logger.warning("[AGENT RESTART] Error stopping scheduler", error=str(e))

        # 3. Stop Knowledge Agent session (config is frozen, must recreate)
        if self._session:
            try:
                await self._session.stop()
                logger.warning("[AGENT RESTART] Knowledge Agent session stopped")
            except Exception as e:
                logger.warning("[AGENT RESTART] Error stopping Knowledge Agent session", error=str(e))
            self._session = None

        # 4. Clear running flag so _do_start() proceeds
        self._running = False

        # 5. Restart everything via _do_start() (Knowledge session → scheduler → Feed agent)
        #    force_fresh=True ensures sessions don't resume old config from disk
        try:
            await self._do_start(force_fresh=True)
            logger.warning("[AGENT RESTART] All agents restarted with new config")
        except Exception as e:
            logger.error(
                "[AGENT RESTART] Failed to restart agents",
                error=str(e),
                error_type=type(e).__name__,
            )
            self._startup_error = f"Restart failed: {e}"

    async def stop(self) -> None:
        """Stop the Knowledge Agent. Called during FastAPI shutdown."""
        # Unregister config callback
        if self._config_callback_registered:
            try:
                from nowledge_graph_server.services.remote_llm_config import get_config_manager
                cm = get_config_manager()
                cm.unregister_change_callback(self._on_config_changed)
                self._config_callback_registered = False
            except Exception:
                pass

        # Stop Feed agent first
        if self._feed_session:
            try:
                await self._feed_session.stop()
            except Exception as e:
                logger.warning("Error stopping Feed agent", error=str(e))
            self._feed_session = None

        if self._scheduler.is_running:
            await self._scheduler.stop()

        # Stop Knowledge Agent session (kimi-agent-sdk based)
        if self._session:
            try:
                await self._session.stop()
            except Exception as e:
                logger.warning("Error stopping Knowledge Agent session", error=str(e))
            self._session = None

        self._running = False
        logger.info("Knowledge Agent stopped")

    # ------------------------------------------------------------------
    # Feed Agent (kimi-agent-sdk based)
    # ------------------------------------------------------------------

    async def _start_feed_agent(
        self,
        agent_dir: Path,
        search_ops: Any,
        reports_dir: Path,
        events_dir: Path,
        *,
        force_fresh: bool = False,
    ) -> None:
        """Initialize and start the Feed agent session.

        Args:
            force_fresh: If True, create a fresh session instead of resuming.
                         Use this when restarting for config changes.
        """
        logger.debug("[FEED AGENT] Starting initialization", force_fresh=force_fresh)

        try:
            from .feed_agent_session import FeedAgentSession
            from .feed_tools import FeedToolDependencies
            from ..core.evolves_operations import EvolvesOperations
            logger.debug("[FEED AGENT] Dependencies imported successfully")
        except ImportError as e:
            logger.error(
                "[FEED AGENT] Dependencies not available, streaming disabled",
                error=str(e),
            )
            self._feed_startup_error = f"ImportError: {e}"
            return

        # Create EvolvesOperations for graph traversal
        evolves_ops = EvolvesOperations(self._db)

        # Configure tool dependencies
        FeedToolDependencies.configure(
            search_ops=search_ops,
            kuzu_client=self._db,
            reports_dir=reports_dir,
            events_dir=events_dir,
            evolves_ops=evolves_ops,
            scheduler=self._scheduler,
        )

        # Create Feed agent session (uses builtin_agents/feed/ as work_dir)
        feed_work_dir = agent_dir / "feed"
        agent_file = Path(__file__).parent / "feed_agent.yaml"

        self._feed_session = FeedAgentSession(
            work_dir=feed_work_dir,
            agent_file=agent_file,
            max_steps_per_turn=20,  # Feed Agent tasks are simpler; limit to prevent runaway loops
        )

        try:
            await self._feed_session.start(yolo=True, force_fresh=force_fresh)
            logger.debug("[FEED AGENT] Session started successfully!", force_fresh=force_fresh)
        except Exception as e:
            logger.error(
                "[FEED AGENT] Failed to start, streaming will be unavailable",
                error=str(e),
                error_type=type(e).__name__,
            )
            self._feed_startup_error = f"{type(e).__name__}: {e}"
            self._feed_session = None

    @property
    def is_feed_agent_running(self) -> bool:
        """Check if Feed agent is running and available for streaming."""
        return self._feed_session is not None and self._feed_session.is_running

    @property
    def is_feed_processing(self) -> bool:
        """Whether Feed agent is currently processing one or more requests."""
        return self._feed_active_requests > 0

    # Feed session lifecycle thresholds
    _FEED_SESSION_MAX_IDLE_SECONDS = 600  # 10 min idle → restart
    _FEED_SESSION_MAX_TURNS = 20  # 20 turns → restart

    def _should_restart_feed_session(self) -> bool:
        """Decide whether to restart Feed session or keep history.

        Returns True (restart) when:
        - Session not running (needs fresh creation)
        - Previous turn errored (e.g. max steps reached — session is poisoned)
        - Idle too long (> 10 min — context is stale)
        - Too many turns (>= 20 — compaction quality degrades)

        Returns False (keep alive) when:
        - Session is fresh (0 turns — just created, don't destroy)
        - Recently active and under turn cap

        When restarting, the recent timeline injection (Option B) ensures
        the agent retains situational awareness of what just happened.
        """
        if not self._feed_session or not self._feed_session.is_running:
            return True
        if self._feed_session.turn_count <= 0:
            return False  # Fresh session, no reason to restart

        # Error recovery: if the last turn errored (max steps, processing failure),
        # the conversation history is poisoned with failed tool calls. Restart fresh
        # so the next input doesn't inherit the bad pattern.
        if self._feed_session.last_turn_errored:
            logger.info("[FEED] Restarting: previous turn errored")
            return True

        idle = self._feed_session.seconds_since_last_turn
        if idle > self._FEED_SESSION_MAX_IDLE_SECONDS:
            logger.info(
                "[FEED] Restarting: idle %.0fs > %ds",
                idle,
                self._FEED_SESSION_MAX_IDLE_SECONDS,
            )
            return True
        if self._feed_session.turn_count >= self._FEED_SESSION_MAX_TURNS:
            logger.info(
                "[FEED] Restarting: %d turns >= %d",
                self._feed_session.turn_count,
                self._FEED_SESSION_MAX_TURNS,
            )
            return True
        return False

    async def process_feed_input_streaming(
        self,
        content: str,
        source_context: Optional[str] = None,
        thread_id: Optional[str] = None,
    ) -> AsyncGenerator[Any, None]:
        """Process feed input with Wire Protocol streaming.

        Args:
            content: User's input text.
            source_context: Optional context block (e.g. source file content)
                to prepend to the user's input for the agent.
            thread_id: If set, this is a follow-up in a thread — preserve
                conversation history so the agent has context from the
                previous turn.

        Yields WireMessage objects from kimi-agent-sdk.
        """
        if not self._feed_session or not self._feed_session.is_running:
            raise RuntimeError("Feed agent not running")

        # Lazy-init lock in the running loop context.
        if self._feed_stream_lock is None:
            self._feed_stream_lock = asyncio.Lock()

        async with self._feed_stream_lock:
            if thread_id:
                # Explicit follow-up: keep session history so agent sees previous turns.
                logger.debug("[FEED AGENT] Follow-up in thread, preserving session", thread_id=thread_id)
            elif self._should_restart_feed_session():
                # Session stale: restart but timeline injection preserves awareness.
                await self._feed_session.restart_fresh()
            else:
                logger.debug(
                    "[FEED AGENT] Keeping session alive",
                    turns=self._feed_session.turn_count,
                    idle_s=f"{self._feed_session.seconds_since_last_turn:.0f}",
                )

            # Update context before processing
            db_stats = await self._gather_db_stats()
            self._feed_session.update_context(db_stats)

            # Inject recent timeline for situational awareness (Option B)
            try:
                from .feed_timeline import build_recent_feed_timeline

                timeline = build_recent_feed_timeline(self._events_dir, max_events=20)
                self._feed_session.update_recent_timeline(timeline)
            except Exception as e:
                logger.debug("[FEED AGENT] Timeline injection failed", error=str(e))

            # If source context provided (e.g. Chat-to-Doc), prepend it
            augmented = content
            if source_context:
                augmented = f"{source_context}\n\n{content}"

            self._feed_active_requests += 1
            try:
                async for msg in self._feed_session.process_input(augmented):
                    yield msg
            finally:
                self._feed_active_requests = max(0, self._feed_active_requests - 1)

    # ------------------------------------------------------------------
    # Scheduled jobs
    # ------------------------------------------------------------------

    def _register_scheduled_jobs(self) -> None:
        """Register the standard set of scheduled jobs (delegated to task_dispatch)."""
        register_scheduled_jobs(self._scheduler)

    # ------------------------------------------------------------------
    # Task execution (called by scheduler)
    # ------------------------------------------------------------------

    async def _execute_task(self, task: AgentTask) -> str:
        """Execute an agent task (delegates to manager_task_execution module)."""
        from .manager_task_execution import execute_scheduled_task
        return await execute_scheduled_task(self, task)

    def _get_per_task_budget(self) -> int:
        """Read per-task token budget from settings. 0 = unlimited."""
        try:
            from .settings_reader import read_knowledge_processing_settings
            settings = read_knowledge_processing_settings()
            budget = int(settings.get("maxTokensPerTask", 500_000))
            return max(0, budget)
        except Exception:
            return 500_000

    def _get_max_steps_per_task(self) -> int:
        """Read maxStepsPerTask from settings, clamped to [10, 100]."""
        try:
            from .settings_reader import read_knowledge_processing_settings
            settings = read_knowledge_processing_settings()
            steps = int(settings.get("maxStepsPerTask", 40))
            return max(10, min(100, steps))
        except Exception:
            return 40

    async def _gather_db_stats(self) -> Dict[str, Any]:
        """Gather DB stats dict for feed agent context injection."""
        conn = self._db.conn if self._db else None
        return await gather_db_stats(conn, self._events_dir)

    # ------------------------------------------------------------------
    # Event hooks (called from memory_operations)
    # ------------------------------------------------------------------

    async def on_memory_created(self, memory_id: str) -> None:
        """Hook: called when a new memory is created."""
        if self._running:
            try:
                await self._scheduler.on_memory_created(memory_id)
                # Also queue for background KG extraction (separate debounced batch)
                await self._scheduler.on_memory_created_for_kg(memory_id)
                # Queue Working Memory refresh (separate debounce, longer window)
                await self._scheduler.on_memory_created_for_wm(memory_id)
            except Exception as e:
                logger.warning("on_memory_created hook failed", memory_id=memory_id, error=str(e))

    async def on_evolves_detected(self, edge_id: str) -> None:
        """Hook: called when an EVOLVES edge is created by the Knowledge Agent.

        Triggers the evolves_detected → cluster evaluation → potential crystallization
        chain. Debounced (30s) so multiple EVOLVES edges from a single task batch
        into one cluster evaluation.
        """
        if self._running:
            try:
                await self._scheduler.on_evolves_detected(edge_id)
            except Exception as e:
                logger.warning("on_evolves_detected hook failed", edge_id=edge_id, error=str(e))

    async def on_thread_synced(
        self,
        thread_id: str,
        *,
        title: str | None = None,
        source: str | None = None,
        message_count: int | None = None,
    ) -> None:
        """Hook: called when a thread is synced."""
        if self._running:
            try:
                await self._scheduler.on_thread_synced(thread_id)
            except Exception as e:
                logger.warning("on_thread_synced hook failed", thread_id=thread_id, error=str(e))
        # Emit feed event so thread syncs appear in the timeline
        try:
            from ..utils.feed_events import emit_feed_event
            event_title = title or f"Thread synced: {thread_id[:12]}"
            metadata: dict[str, object] = {"thread_id": thread_id}
            if title:
                metadata["title"] = title
            if source:
                metadata["source"] = source
            if message_count is not None:
                metadata["message_count"] = message_count
            emit_feed_event(
                "thread_synced",
                title=event_title,
                description="A conversation thread was synced and memories extracted.",
                metadata=metadata,
            )
        except Exception as e:
            logger.warning("on_thread_synced feed event failed", thread_id=thread_id, error=str(e))

    # ------------------------------------------------------------------
    # On-demand triggers (delegated to task_dispatch module)
    # ------------------------------------------------------------------

    async def trigger_daily_briefing(self) -> None:
        from .task_dispatch import trigger_daily_briefing
        await trigger_daily_briefing(self._scheduler)

    async def trigger_crystallization(self) -> None:
        from .task_dispatch import trigger_crystallization
        await trigger_crystallization(self._scheduler)

    async def trigger_insight_detection(self) -> None:
        from .task_dispatch import trigger_insight_detection
        await trigger_insight_detection(self._scheduler)

    async def trigger_decay_refresh(self) -> None:
        from .task_dispatch import trigger_decay_refresh
        await trigger_decay_refresh(self._scheduler)

    async def trigger_memory_compaction(self) -> None:
        from .task_dispatch import trigger_memory_compaction
        await trigger_memory_compaction(self._scheduler)

    async def trigger_community_detection(
        self, resolution: float = 1.0, generate_ai_summary: bool = True
    ) -> None:
        from .task_dispatch import trigger_community_detection
        await trigger_community_detection(self._scheduler, resolution, generate_ai_summary)

    async def trigger_source_extraction(self, source_id: str, source_name: str, mime_type: str | None = None) -> None:
        from .task_dispatch import trigger_source_extraction
        await trigger_source_extraction(self._scheduler, source_id, source_name, mime_type)

    async def trigger_kg_extraction(self, backfill: bool = False) -> None:
        from .task_dispatch import trigger_kg_extraction
        await trigger_kg_extraction(self._scheduler, backfill)

    # ------------------------------------------------------------------
    # Direct-function executors (delegated to task_executors module)
    # ------------------------------------------------------------------

    async def _execute_community_detection(self, task: AgentTask) -> str:
        """Run community detection as a direct function call (no LLM agent)."""
        return await execute_community_detection(task, self._db, self._current_task)

    async def _execute_decay_refresh(self, task: AgentTask) -> str:
        """Batch-refresh decay scores for all memories (no LLM agent)."""
        return await execute_decay_refresh(task, self._db, self._current_task)

    async def _execute_kg_extraction(self, task: AgentTask) -> str:
        """Extract KG entities from specific memories (direct function call)."""
        return await execute_kg_extraction(task, self._db, self._memory_ops, self._current_task)

    async def _execute_kg_extraction_backfill(self, task: AgentTask) -> str:
        """Extract KG entities from all un-extracted memories (backfill)."""
        return await execute_kg_extraction_backfill(task, self._db, self._memory_ops, self._current_task)

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    @property
    def is_running(self) -> bool:
        return self._running

    def get_status(self) -> Dict[str, Any]:
        """Get agent status for the REST API."""
        status: Dict[str, Any] = {
            "running": self._running,
            "feed_agent_running": self.is_feed_agent_running,
            "feed_processing": self.is_feed_processing,
            "feed_active_requests": self._feed_active_requests,
            "backend": "kimi-agent-sdk",  # Indicate we're using kimi-agent-sdk
            "llm_available": False,
        }

        # Add startup error info if agent failed to start
        if not self._running and self._startup_error:
            status["startup_error"] = self._startup_error

        # Add Feed agent error info if it failed to start
        if not self.is_feed_agent_running and self._feed_startup_error:
            status["feed_startup_error"] = self._feed_startup_error

        if self._session:
            status["total_tasks"] = self._session.total_tasks
            status["session_running"] = self._session.is_running

        if self._scheduler:
            status["queue_size"] = self._scheduler.queue_size
            status["tasks_this_hour"] = self._scheduler.tasks_this_hour
            status["tokens_this_hour"] = self._scheduler.tokens_this_hour
            status["tokens_today"] = self._scheduler.tokens_today
            status["budget_paused"] = self._scheduler.is_budget_paused
            status["max_tokens_per_hour"] = self._scheduler.max_tokens_per_hour
            status["max_tokens_per_day"] = self._scheduler.max_tokens_per_day
            status["max_tokens_per_task"] = self._get_per_task_budget()

        # Include explicit LLM availability for feed endpoint error reporting.
        try:
            import json as _json
            from nowledge_graph_server.services.remote_llm_config import get_config_manager

            cm = get_config_manager()
            cfg = cm.get_config()
            effective = cm.get_effective_purpose("ai_now")
            provider_id = (
                effective.get("provider")
                or cm.get_active_provider()
                or cfg.provider
            )
            providers = cm.get_all_provider_configs()
            provider_cfg = providers.get(provider_id or "")

            provider_type = (
                (provider_cfg.provider_type if provider_cfg else None)
                or cfg.provider_type
                or cfg.provider
                or ""
            )
            model = (
                effective.get("model")
                or (provider_cfg.model if provider_cfg else None)
                or cfg.model
                or ""
            )

            has_key = bool((provider_cfg.api_key if provider_cfg else cfg.api_key) or "")

            # Token-based providers use token cache files, not api_key in config.
            token_root = cm.config_path.parent
            if provider_type == "github_copilot":
                token_file = token_root / "github_copilot" / "access-token"
                has_key = token_file.exists() and token_file.read_text().strip() != ""
            elif provider_type == "openai_codex":
                token_file = token_root / "openai_codex" / "access-token.json"
                if token_file.exists():
                    data = _json.loads(token_file.read_text())
                    has_key = bool(str(data.get("access_token", "")).strip())
                else:
                    has_key = False

            status["llm_available"] = bool(cfg.enabled and str(model).strip() and has_key)
        except Exception:
            status["llm_available"] = False

        # Token breakdown by source (last 24h)
        try:
            from . import token_tracker
            status["token_breakdown"] = token_tracker.get_breakdown(hours=24)
        except Exception:
            pass

        return status


# Module-level accessor
_agent_manager: Optional[KnowledgeAgentManager] = None


def get_agent_manager() -> Optional[KnowledgeAgentManager]:
    """Get the global agent manager instance (may be None if not started)."""
    global _agent_manager
    return _agent_manager


def set_agent_manager(manager: KnowledgeAgentManager) -> None:
    """Set the global agent manager instance."""
    global _agent_manager
    _agent_manager = manager
