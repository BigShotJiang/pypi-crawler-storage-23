"""Kimi-agent-sdk provider patches.

Contains compatibility patches that AI-Now applies via start_kimi.sh but
need to be applied in-process for kimi-agent-sdk consumers (Feed/Knowledge Agent).
"""

from __future__ import annotations

import json
import re
import threading
from typing import Optional

import structlog

logger = structlog.get_logger(__name__)

_CHATGPT_PATCH_LOCK = threading.Lock()
_CHATGPT_PATCH_APPLIED = False
_KIMI_CAPS_PATCH_LOCK = threading.Lock()
_KIMI_CAPS_PATCH_APPLIED = False
_KIMI_OPENAI_HEADERS_PATCH_LOCK = threading.Lock()
_KIMI_OPENAI_HEADERS_PATCH_APPLIED = False


def apply_chatgpt_backend_patch() -> bool:
    """Patch httpx requests for ChatGPT backend compatibility.

    The ChatGPT backend (chatgpt.com/backend-api/codex) requires:
    - instructions field
    - store=false
    - stream=true
    - no max_tokens / metadata / previous_response_id
    """
    global _CHATGPT_PATCH_APPLIED
    with _CHATGPT_PATCH_LOCK:
        if _CHATGPT_PATCH_APPLIED:
            return False

        try:
            import httpx
        except Exception as e:
            logger.warning("ChatGPT backend patch skipped: httpx not available", error=str(e))
            return False

        _CHATGPT_MARKER = "chatgpt.com/backend-api/codex"
        _STRIP_FIELDS = (
            "max_tokens",
            "max_output_tokens",
            "max_completion_tokens",
            "metadata",
            "previous_response_id",
        )

        def _patch_request(request: "httpx.Request") -> "httpx.Request":
            if _CHATGPT_MARKER not in str(request.url):
                return request
            if request.method.upper() != "POST":
                return request
            if not request.content:
                return request

            try:
                body = json.loads(request.content)
            except Exception:
                return request

            modified = False
            if not body.get("instructions"):
                body["instructions"] = "You are a helpful assistant."
                modified = True

            if body.get("store") is not False:
                body["store"] = False
                modified = True

            if body.get("stream") is not True:
                body["stream"] = True
                modified = True

            for field in _STRIP_FIELDS:
                if field in body:
                    del body[field]
                    modified = True

            if not modified:
                return request

            new_content = json.dumps(body).encode("utf-8")
            headers = {
                k: v for k, v in request.headers.items() if k.lower() != "content-length"
            }
            return httpx.Request(
                method=request.method,
                url=request.url,
                headers=headers,
                content=new_content,
            )

        original_sync_send = httpx.Client.send
        original_async_send = httpx.AsyncClient.send

        def _patched_sync_send(self, request, *args, **kwargs):
            return original_sync_send(self, _patch_request(request), *args, **kwargs)

        async def _patched_async_send(self, request, *args, **kwargs):
            return await original_async_send(self, _patch_request(request), *args, **kwargs)

        httpx.Client.send = _patched_sync_send  # type: ignore[assignment]
        httpx.AsyncClient.send = _patched_async_send  # type: ignore[assignment]

        _CHATGPT_PATCH_APPLIED = True
        logger.info("Applied ChatGPT backend compatibility patch for kimi-agent-sdk")
        return True


def apply_kimi_reasoning_capability_patch() -> bool:
    """Patch Kimi CLI capability inference for non-reasoning models.

    kimi-cli infers thinking capability from model names that contain "reason".
    Some providers (xAI) ship models like "grok-4-1-fast-non-reasoning" that
    include "reason" but explicitly reject reasoning params. We treat any model
    containing "non-reasoning" (and variants) as NOT reasoning-capable.
    """
    global _KIMI_CAPS_PATCH_APPLIED
    with _KIMI_CAPS_PATCH_LOCK:
        if _KIMI_CAPS_PATCH_APPLIED:
            return False

        try:
            from kimi_cli import llm as kimi_llm
        except Exception as e:
            logger.warning("Kimi capability patch skipped: kimi_cli not available", error=str(e))
            return False

        original = getattr(kimi_llm, "derive_model_capabilities", None)
        if original is None:
            logger.warning("Kimi capability patch skipped: derive_model_capabilities missing")
            return False

        non_reasoning_pattern = re.compile(r"(?:^|[\s_-])(non|no)[\s_-]?reason")

        def _patched_derive_model_capabilities(model) -> set[str]:
            capabilities = set(model.capabilities or ())
            model_name = (model.model or "").lower()
            if non_reasoning_pattern.search(model_name):
                return capabilities
            if "thinking" in model_name or "reason" in model_name:
                capabilities.update(("thinking", "always_thinking"))
            elif model.model in {"kimi-for-coding", "kimi-code"}:
                capabilities.update(("thinking", "image_in", "video_in"))
            return capabilities

        kimi_llm.derive_model_capabilities = _patched_derive_model_capabilities  # type: ignore[assignment]
        _KIMI_CAPS_PATCH_APPLIED = True
        logger.info("Applied non-reasoning capability patch for kimi-cli")
        return True


def apply_kimi_openai_custom_headers_patch() -> bool:
    """Ensure kimi-cli forwards provider custom_headers to OpenAI clients.

    Copilot's IDE auth requires headers like Editor-Version. kimi-cli only applies
    custom_headers to the native Kimi provider, so we inject them for OpenAI-based
    providers (openai_legacy/openai_responses) via default_headers.
    """
    global _KIMI_OPENAI_HEADERS_PATCH_APPLIED
    with _KIMI_OPENAI_HEADERS_PATCH_LOCK:
        if _KIMI_OPENAI_HEADERS_PATCH_APPLIED:
            return False

        try:
            from kimi_cli import llm as kimi_llm
        except Exception as e:
            logger.warning("Kimi OpenAI headers patch skipped: kimi_cli not available", error=str(e))
            return False

        original_create_llm = getattr(kimi_llm, "create_llm", None)
        if original_create_llm is None:
            logger.warning("Kimi OpenAI headers patch skipped: create_llm missing")
            return False

        def _patched_create_llm(
            provider,
            model,
            *,
            thinking=None,
            session_id=None,
            oauth=None,
        ):
            if provider.type in {"openai_legacy", "openai_responses"}:
                try:
                    base_url_lower = (provider.base_url or "").lower()
                    force_xai_legacy_transport = (
                        provider.type == "openai_responses" and "api.x.ai" in base_url_lower
                    )
                    resolved_api_key = (
                        oauth.resolve_api_key(provider.api_key, provider.oauth)
                        if oauth and provider.oauth
                        else provider.api_key.get_secret_value()
                    )

                    client_kwargs = {}
                    if provider.custom_headers:
                        client_kwargs["default_headers"] = dict(provider.custom_headers)

                    if provider.type == "openai_legacy" or force_xai_legacy_transport:
                        from kosong.contrib.chat_provider.openai_legacy import OpenAILegacy

                        base_url = provider.base_url
                        if "api.x.ai" in base_url_lower and base_url and not base_url.rstrip("/").endswith("/v1"):
                            base_url = base_url.rstrip("/") + "/v1"
                        if force_xai_legacy_transport:
                            logger.info(
                                "xAI openai_responses detected, forcing openai_legacy transport"
                            )
                        chat_provider = OpenAILegacy(
                            model=model.model,
                            base_url=base_url,
                            api_key=resolved_api_key,
                            **client_kwargs,
                        )
                    else:
                        from kosong.contrib.chat_provider.openai_responses import OpenAIResponses

                        chat_provider = OpenAIResponses(
                            model=model.model,
                            base_url=provider.base_url,
                            api_key=resolved_api_key,
                            **client_kwargs,
                        )

                    capabilities = kimi_llm.derive_model_capabilities(model)
                    if "always_thinking" in capabilities or (
                        thinking is True and "thinking" in capabilities
                    ):
                        chat_provider = chat_provider.with_thinking("high")
                    elif thinking is False:
                        chat_provider = chat_provider.with_thinking("off")

                    return kimi_llm.LLM(
                        chat_provider=chat_provider,
                        max_context_size=model.max_context_size,
                        capabilities=capabilities,
                        model_config=model,
                        provider_config=provider,
                    )
                except Exception as e:
                    logger.warning("Kimi OpenAI headers patch failed", error=str(e))
                    # Fall back to original implementation
                    return original_create_llm(
                        provider,
                        model,
                        thinking=thinking,
                        session_id=session_id,
                        oauth=oauth,
                    )

            return original_create_llm(
                provider,
                model,
                thinking=thinking,
                session_id=session_id,
                oauth=oauth,
            )

        kimi_llm.create_llm = _patched_create_llm  # type: ignore[assignment]
        _KIMI_OPENAI_HEADERS_PATCH_APPLIED = True
        logger.info("Applied OpenAI custom_headers patch for kimi-cli")
        return True
