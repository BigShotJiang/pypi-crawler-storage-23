"""Context helpers — activity digests, graph totals, and DB stats.

Extracted from manager.py to keep the main class under 1000 lines.
All functions take explicit dependencies (db conn, events_dir) instead of self.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog

from nowledge_graph_server.database.result_utils import iter_rows, managed_result
from nowledge_graph_server.utils.time_partitioning import (
    _iter_time_partitioned_files,
)

logger = structlog.get_logger(__name__)


def _to_naive_utc(dt: Any) -> Optional[datetime]:
    """Convert a datetime (aware or naive) to a naive UTC datetime for safe subtraction.

    KuzuDB returns offset-naive datetimes; Python's datetime.now(timezone.utc) is
    offset-aware. Mixing them raises TypeError. This normalizes both to naive UTC.
    """
    if dt is None:
        return None
    if isinstance(dt, datetime):
        if dt.tzinfo is not None:
            return dt.replace(tzinfo=None)
        return dt
    # String fallback
    try:
        parsed = datetime.fromisoformat(str(dt).replace("Z", "+00:00"))
        return parsed.replace(tzinfo=None)
    except (ValueError, TypeError):
        return None


async def build_activity_digest(conn: Any, hours: int = 48) -> Optional[str]:
    """Pre-compute a rich activity digest from the graph.

    Returns formatted markdown with actual memory titles, EVOLVES edge
    details, crystal names, and flag descriptions — not just counts.
    This saves the agent 10+ tool calls and gives immediate context.
    """
    if conn is None:
        return None

    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    cutoff_str = cutoff.strftime("%Y-%m-%dT%H:%M:%S")

    lines: List[str] = [f"## Activity Digest (last {hours}h)"]

    # --- Recent memories ---
    try:
        result = conn.execute(
            """
            MATCH (m:Memory)
            WHERE m.created_at >= $cutoff AND (m.is_crystal IS NULL OR m.is_crystal = false)
            RETURN m.id, m.title, m.unit_type, m.importance, m.created_at
            ORDER BY m.created_at DESC
            LIMIT 20
            """,
            {"cutoff": cutoff_str},
        )
        memories: List[Dict[str, Any]] = []
        for row in iter_rows(result):
            created_at = row[4]
            if isinstance(created_at, datetime):
                created_at = created_at.strftime("%Y-%m-%d %H:%M")
            elif created_at is not None:
                created_at = str(created_at)[:16]
            memories.append(
                {
                    "id": row[0],
                    "title": row[1] or "(untitled)",
                    "type": row[2] or "fact",
                    "importance": float(row[3]) if row[3] is not None else 0.5,
                    "created": created_at,
                }
            )

        lines.append(f"\n### New Memories ({len(memories)})")
        if memories:
            for m in memories:
                imp = (
                    f" [imp={m['importance']:.1f}]" if m["importance"] >= 0.7 else ""
                )
                lines.append(
                    f"- **{m['title']}** ({m['type']}{imp}) — {m['created']} — id:`{m['id']}`"
                )
        else:
            lines.append("- (none)")
    except Exception as e:
        logger.debug("Activity digest: memories query failed", error=str(e))
        lines.append("\n### New Memories\n- (query failed)")

    # --- Recent EVOLVES edges ---
    try:
        result = conn.execute(
            """
            MATCH (newer:Memory)-[e:EVOLVES]->(older:Memory)
            WHERE e.created_at >= $cutoff
            RETURN newer.id, newer.title, older.id, older.title,
                   e.content_relation, e.created_at
            ORDER BY e.created_at DESC
            LIMIT 10
            """,
            {"cutoff": cutoff_str},
        )
        evolves: List[Dict[str, Any]] = []
        for row in iter_rows(result):
            evolves.append(
                {
                    "newer_id": row[0],
                    "newer_title": row[1] or "(untitled)",
                    "older_id": row[2],
                    "older_title": row[3] or "(untitled)",
                    "relation": row[4] or "enriches",
                }
            )

        if evolves:
            lines.append(f"\n### EVOLVES Edges ({len(evolves)})")
            for e in evolves:
                lines.append(
                    f'- "{e["newer_title"]}" —[{e["relation"]}]→ "{e["older_title"]}"'
                )
    except Exception as e:
        logger.debug("Activity digest: evolves query failed", error=str(e))

    # --- Recent crystals ---
    try:
        result = conn.execute(
            """
            MATCH (c:Memory)
            WHERE c.is_crystal = true AND c.created_at >= $cutoff
            RETURN c.id, c.title, c.created_at
            ORDER BY c.created_at DESC
            LIMIT 5
            """,
            {"cutoff": cutoff_str},
        )
        crystals: List[str] = []
        for row in iter_rows(result):
            crystals.append(row[1] or "(untitled)")

        if crystals:
            lines.append(f"\n### Crystals Created ({len(crystals)})")
            for title in crystals:
                lines.append(f"- {title}")
    except Exception as e:
        logger.debug("Activity digest: crystals query failed", error=str(e))

    # --- Recent sources (Library) ---
    try:
        result = conn.execute(
            """
            MATCH (s:Source)
            WHERE s.created_at >= $cutoff
            RETURN s.id, s.original_name, s.source_type, s.lifecycle_state, s.memory_count
            ORDER BY s.created_at DESC
            LIMIT 10
            """,
            {"cutoff": cutoff_str},
        )
        sources: List[Dict[str, Any]] = []
        for row in iter_rows(result):
            sources.append(
                {
                    "id": row[0],
                    "name": row[1] or "(unnamed)",
                    "type": row[2] or "file",
                    "state": row[3] or "ingested",
                    "memories": int(row[4]) if row[4] is not None else 0,
                }
            )

        if sources:
            lines.append(f"\n### Library Sources Added ({len(sources)})")
            for s in sources:
                mem_str = f", {s['memories']} memories" if s["memories"] > 0 else ""
                lines.append(
                    f"- **{s['name']}** ({s['type']}, {s['state']}{mem_str}) — id:`{s['id']}`"
                )
    except Exception as e:
        logger.debug("Activity digest: sources query failed", error=str(e))

    # --- Memory health (from decay_score_cached) ---
    try:
        health_stats: Dict[str, Any] = {"total": 0, "avg": 0.0, "stale": 0}
        for row in iter_rows(conn.execute(
            """MATCH (m:Memory)
               WHERE m.is_crystal = false
               RETURN count(m), avg(m.decay_score_cached)"""
        )):
            health_stats["total"] = row[0] or 0
            health_stats["avg"] = float(row[1]) if row[1] is not None else 0.0

        if health_stats["total"] > 0:
            for row in iter_rows(conn.execute(
                """MATCH (m:Memory)
                   WHERE m.is_crystal = false AND m.decay_score_cached < 0.3
                   RETURN count(m)"""
            )):
                health_stats["stale"] = row[0] or 0

            lines.append(f"\n### Memory Health")
            lines.append(f"- Total active memories: {health_stats['total']}")
            lines.append(f"- Average decay score: {health_stats['avg']:.2f}")
            lines.append(f"- Stale (decay < 0.3): {health_stats['stale']}")
    except Exception as e:
        logger.debug("Activity digest: health stats query failed", error=str(e))

    return "\n".join(lines)


def format_yesterday_wm(raw_content: str, parsed: Dict[str, Any]) -> str:
    """Format yesterday's WM as structured context with continuity guidance."""
    lines: List[str] = ["## Yesterday's Working Memory"]

    focus_areas = parsed.get("focus_areas", [])
    if focus_areas:
        lines.append("\n### Previous Focus Areas")
        for fa in focus_areas:
            mid = f" (id:`{fa['memoryId']}`)" if fa.get("memoryId") else ""
            lines.append(
                f"- **{fa['name']}** — {fa.get('description', '')}{mid}"
            )

    flags = parsed.get("flags", [])
    if flags:
        lines.append("\n### Previous Flags")
        for fl in flags:
            sev = (
                f"[{fl.get('severity', 'medium')}] " if fl.get("severity") else ""
            )
            lines.append(f"- {sev}{fl.get('description', '')}")

    briefing = parsed.get("briefing", "")
    if briefing:
        lines.append(f"\n### Previous Briefing\n{briefing[:300]}")

    lines.append("\n### Continuity Guidance")
    lines.append(
        "- **KEEP** a focus area if new activity happened on it in the last 48h"
    )
    lines.append(
        "- **DROP** a focus area if no new memories, edges, or crystals relate to it"
    )
    lines.append(
        "- **ADD** new focus areas only for topics with genuinely new information"
    )
    lines.append(
        "- **CARRY FORWARD** unresolved flags unless the user resolved them"
    )

    return "\n".join(lines)


def build_resolution_context(events_dir: Optional[Path]) -> Optional[str]:
    """Summarize recent flag resolutions for agent calibration.

    Scans resolved flag events from the last 30 days and produces a summary
    of how the user tends to act on different flag types. This helps the agent
    learn: "user always keeps both contradictions" or "user ignores stale flags".
    """
    if events_dir is None:
        return None

    files = _iter_time_partitioned_files(events_dir, "jsonl", last_n_days=30)
    if not files:
        return None

    resolutions: Dict[str, Dict[str, int]] = {}  # flag_type → {action → count}

    for f in files:
        try:
            for line in f.read_text().splitlines():
                if not line.strip():
                    continue
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    continue

                if not event.get("resolved"):
                    continue
                etype = event.get("event_type", "")
                if not etype.startswith("flag_"):
                    continue

                flag_type = etype.replace("flag_", "")
                resolution = event.get("resolution", "dismissed")
                action = event.get("action", resolution)

                if flag_type not in resolutions:
                    resolutions[flag_type] = {}
                resolutions[flag_type][action] = resolutions[flag_type].get(action, 0) + 1
        except Exception:
            continue

    if not resolutions:
        return None

    lines: List[str] = ["## User Flag Resolution Patterns (last 30 days)"]
    for flag_type, actions in sorted(resolutions.items()):
        total = sum(actions.values())
        action_strs = [f"{a}: {c}" for a, c in sorted(actions.items(), key=lambda x: -x[1])]
        lines.append(f"- **{flag_type}** ({total} resolved): {', '.join(action_strs)}")

    lines.append(
        "\nUse these patterns to calibrate your flagging. "
        "If the user consistently dismisses a flag type, create fewer of those."
    )

    return "\n".join(lines)


async def gather_graph_totals(conn: Any) -> Optional[str]:
    """Gather overall graph size as a lightweight context header."""
    if conn is None:
        return None

    lines: List[str] = ["## Graph Totals"]

    try:
        with managed_result(conn.execute("MATCH (m:Memory) RETURN count(m)")) as r:
            count = r.get_next()[0] if r.has_next() else 0
        lines.append(f"- Memories: {count}")
    except Exception:
        pass

    try:
        with managed_result(conn.execute("MATCH ()-[e:EVOLVES]->() RETURN count(e)")) as r:
            count = r.get_next()[0] if r.has_next() else 0
        lines.append(f"- EVOLVES edges: {count}")
    except Exception:
        pass

    try:
        with managed_result(conn.execute(
            "MATCH (m:Memory) WHERE m.is_crystal = true RETURN count(m)"
        )) as r:
            count = r.get_next()[0] if r.has_next() else 0
        lines.append(f"- Crystals: {count}")
    except Exception:
        pass

    try:
        with managed_result(conn.execute("MATCH (s:Source) RETURN count(s)")) as r:
            count = r.get_next()[0] if r.has_next() else 0
        lines.append(f"- Sources (Library): {count}")
    except Exception:
        pass

    # Inject user identity for Knowledge Agent context
    from .settings_reader import read_user_profile
    profile = read_user_profile()
    if profile.get("name"):
        lines.append("")
        lines.append("## User Identity")
        lines.append(f"- Name: {profile['name']}")
        if profile.get("aliases"):
            lines.append(f"- Also known as: {profile['aliases']}")
        if profile.get("context"):
            lines.append(f"- Context: {profile['context']}")

    # Inject preferred language
    preferred_lang = profile.get("preferred_language", "en")
    if preferred_lang and preferred_lang != "en":
        lang_name = {"zh": "Chinese (中文)"}.get(preferred_lang, preferred_lang)
        lines.append("")
        lines.append("## Preferred Language")
        lines.append(f"Generate all user-facing content (insights, briefings, crystal summaries, flags) in: {lang_name}")
        lines.append("Entity names and technical terms should stay in their original language.")

    return "\n".join(lines) if len(lines) > 1 else None


async def gather_db_stats(conn: Any, events_dir: Optional[Path] = None) -> Dict[str, Any]:
    """Gather DB stats dict for feed agent context injection."""
    stats: Dict[str, Any] = {}
    if conn is None:
        return stats
    try:
        with managed_result(conn.execute("MATCH (m:Memory) RETURN count(m)")) as r:
            stats["memory_count"] = r.get_next()[0] if r.has_next() else 0
    except Exception:
        stats["memory_count"] = "?"
    try:
        with managed_result(conn.execute("MATCH ()-[e:EVOLVES]->() RETURN count(e)")) as r:
            stats["evolves_count"] = r.get_next()[0] if r.has_next() else 0
    except Exception:
        stats["evolves_count"] = "?"
    try:
        with managed_result(conn.execute(
            "MATCH (m:Memory) WHERE m.is_crystal = true RETURN count(m)"
        )) as r:
            stats["crystal_count"] = r.get_next()[0] if r.has_next() else 0
    except Exception:
        stats["crystal_count"] = "?"
    try:
        with managed_result(conn.execute("MATCH (s:Source) RETURN count(s)")) as r:
            stats["source_count"] = r.get_next()[0] if r.has_next() else 0
    except Exception:
        stats["source_count"] = "?"
    stats["unresolved_flags"] = len(get_unresolved_flags(events_dir, limit=50))
    return stats


def get_unresolved_flags(
    events_dir: Optional[Path], limit: int = 10
) -> List[Dict[str, str]]:
    """Get unresolved flags with details from event JSONL files."""
    if not events_dir:
        return []
    flags: List[Dict[str, str]] = []
    for event_file in _iter_time_partitioned_files(
        events_dir, "jsonl", last_n_days=30
    ):
        try:
            for line in event_file.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    event = json.loads(line)
                    if event.get("severity") == "action_required" and not event.get(
                        "resolved"
                    ):
                        flags.append(
                            {
                                "event_id": event.get("id", ""),
                                "title": event.get("title", ""),
                                "description": event.get("description", "")[:200],
                            }
                        )
                        if len(flags) >= limit:
                            return flags
                except json.JSONDecodeError:
                    continue
        except Exception:
            continue
    return flags



def get_recent_insights(
    events_dir: Optional[Path], last_n_days: int = 14
) -> List[Dict[str, str]]:
    """Get recently created insights from JSONL for dedup context.

    Scans feed event files for insight-type events so the agent knows
    what was already reported and can avoid duplicates.
    """
    if not events_dir:
        return []

    insight_event_types = {"pattern_detected", "insight_generated", "agent_observation"}
    insights: List[Dict[str, str]] = []

    for event_file in _iter_time_partitioned_files(
        events_dir, "jsonl", last_n_days=last_n_days
    ):
        try:
            for line in event_file.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    event = json.loads(line)
                    if event.get("event_type") in insight_event_types:
                        insights.append(
                            {
                                "title": event.get("title", ""),
                                "description": (event.get("description", "") or "")[
                                    :200
                                ],
                                "event_type": event.get("event_type", ""),
                                "created_at": (event.get("created_at", "") or "")[:10],
                            }
                        )
                        if len(insights) >= 50:
                            return insights
                except json.JSONDecodeError:
                    continue
        except Exception:
            continue

    return insights


# Task-specific context builders moved to context_task_builders.py
# Re-export for backward compatibility
from .context_task_builders import (  # noqa: E402, F401
    build_community_overview,
    build_compaction_context,
    build_crystallization_context,
    build_insight_context,
)
