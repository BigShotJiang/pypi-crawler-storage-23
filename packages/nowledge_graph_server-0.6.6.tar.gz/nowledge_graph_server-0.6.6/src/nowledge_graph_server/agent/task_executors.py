"""Direct-function task executors — bypass LLM for compute operations.

Extracted from manager.py to keep the main class under 1000 lines.
All functions are standalone async functions taking explicit dependencies.
"""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

import structlog

from nowledge_graph_server.database.result_utils import iter_rows

logger = structlog.get_logger(__name__)


async def execute_community_detection(
    task: Any,
    db: Any,
    current_task_ref: Optional[Dict[str, Any]] = None,
) -> str:
    """Run community detection as a direct function call (no LLM agent)."""
    if not db:
        return "Database not available"

    from .scheduler import TaskPriority
    from .settings_reader import read_knowledge_processing_settings

    settings = read_knowledge_processing_settings()
    # Only gate automatic (scheduled) runs — manual triggers always execute
    if task.priority == TaskPriority.LOW and not settings.get(
        "autoCommunityDetection", True
    ):
        logger.info("Community detection disabled in settings, skipping scheduled run")
        return "Community detection disabled in settings"

    from ..services.augmentation_jobs import AugmentationJobService

    aug_service = AugmentationJobService(db)
    await aug_service.initialize()

    params = task.metadata or {}
    resolution = params.get("resolution", settings.get("communityResolution", 1.0))
    generate_ai_summary = params.get(
        "generate_ai_summary", settings.get("generateCommunityAISummary", True)
    )
    max_iterations = params.get("max_iterations", 100)

    logger.info(
        "Starting community detection (direct)",
        resolution=resolution,
        generate_ai_summary=generate_ai_summary,
    )

    job_id = await aug_service.create_job(
        "community_detection",
        {
            "resolution": resolution,
            "generate_ai_summary": generate_ai_summary,
            "max_iterations": max_iterations,
        },
    )
    await aug_service.start_job(job_id)

    # Poll for completion (10 min timeout)
    final_status: Dict[str, Any] = {"status": "timeout"}
    for _ in range(120):
        await asyncio.sleep(5)
        final_status = await aug_service.get_job_status(job_id)
        if final_status.get("status") in ("completed", "failed"):
            break

    # Emit feed event
    try:
        from ..utils.feed_events import emit_feed_event

        status_str = final_status.get("status", "unknown")
        num_communities = (
            final_status.get("result", {}).get("num_communities", 0)
            if isinstance(final_status.get("result"), dict)
            else 0
        )
        emit_feed_event(
            "community_detection",
            title=f"Community Detection: {num_communities} communities found",
            description=f"Found {num_communities} communities at resolution {resolution}",
            severity="info",
            metadata={
                "job_id": job_id,
                "status": status_str,
                "resolution": resolution,
                "num_communities": num_communities,
                "generate_summaries": generate_ai_summary,
            },
        )
    except Exception as e:
        logger.debug("Failed to emit community detection event", error=str(e))

    result_msg = f"Community detection {final_status.get('status', 'unknown')}"
    logger.info(result_msg, job_id=job_id)
    return result_msg


async def execute_kg_extraction(
    task: Any,
    db: Any,
    memory_ops: Any,
    current_task_ref: Optional[Dict[str, Any]] = None,
) -> str:
    """Extract KG entities from specific memories (direct function call)."""
    memory_ids = [
        e.get("memory_id", e) if isinstance(e, dict) else e
        for e in (
            task.metadata.get("memory_ids", []) or task.metadata.get("events", [])
        )
    ]
    if not memory_ids:
        return "No memory IDs to process"

    from .scheduler import TaskPriority
    from .settings_reader import read_knowledge_processing_settings

    settings = read_knowledge_processing_settings()
    if task.priority == TaskPriority.LOW and not settings.get(
        "autoKGExtraction", True
    ):
        logger.info("KG extraction disabled in settings, skipping")
        return "KG extraction disabled in settings"

    return await do_kg_extraction(memory_ids, settings, db, memory_ops, current_task_ref)


async def execute_kg_extraction_backfill(
    task: Any,
    db: Any,
    memory_ops: Any,
    current_task_ref: Optional[Dict[str, Any]] = None,
) -> str:
    """Extract KG entities from all un-extracted memories (backfill)."""
    if not db or not memory_ops:
        return "Database or memory ops not available"

    from .settings_reader import read_knowledge_processing_settings

    settings = read_knowledge_processing_settings()

    # Find memories without KG extraction
    try:
        conn = db.conn
        un_extracted: List[str] = []
        for row in iter_rows(conn.execute(
            "MATCH (m:Memory) WHERE m.is_crystal = false RETURN m.id, m.metadata LIMIT 200"
        )):
            mid = row[0]
            metadata_str = row[1]
            if metadata_str:
                try:
                    meta = (
                        json.loads(metadata_str)
                        if isinstance(metadata_str, str)
                        else metadata_str
                    )
                    if meta.get("kg_extracted"):
                        continue
                except (json.JSONDecodeError, TypeError):
                    pass
            un_extracted.append(mid)
        un_extracted = un_extracted[:10]
    except Exception as e:
        logger.error("Failed to query un-extracted memories", error=str(e))
        return f"Query failed: {e}"

    if not un_extracted:
        return "All memories already have KG extraction"

    logger.info(f"KG backfill: {len(un_extracted)} memories to process")
    return await do_kg_extraction(un_extracted, settings, db, memory_ops, current_task_ref)


async def do_kg_extraction(
    memory_ids: List[str],
    settings: Dict[str, Any],
    db: Any,
    memory_ops: Any,
    current_task_ref: Optional[Dict[str, Any]] = None,
) -> str:
    """Shared KG extraction logic for both event-driven and backfill modes."""
    if not db or not memory_ops:
        return "Database or memory ops not available"

    # 1. Load memories and filter already-extracted
    memories_to_process: List[Dict[str, Any]] = []
    for mid in memory_ids:
        try:
            memory = await memory_ops.get_memory_by_id(mid)
            if not memory:
                continue
            meta = memory.metadata or {}
            if isinstance(meta, str):
                try:
                    meta = json.loads(meta)
                except (json.JSONDecodeError, TypeError):
                    meta = {}
            if meta.get("kg_extracted"):
                continue
            unit_type = meta.get("unit_type", "")
            if unit_type in ("url_capture", "thread_message"):
                continue
            content = getattr(memory, "content", "") or ""
            if len(content) < 50:
                continue
            if len(content) > 20000:
                continue
            memories_to_process.append(
                {
                    "id": memory.id,
                    "title": getattr(memory, "title", None) or "Untitled",
                    "content": content,
                }
            )
        except Exception as e:
            logger.debug(
                "Failed to load memory for KG extraction",
                memory_id=mid,
                error=str(e),
            )

    if not memories_to_process:
        return "No un-extracted memories to process"

    # Sort richest-first
    memories_to_process.sort(key=lambda m: len(m["content"]), reverse=True)

    # 2. Get remote LLM extraction service
    try:
        from ..services.local_llm import get_local_llm_service

        llm_service = await get_local_llm_service()
        remote_extraction = await llm_service._get_remote_extraction()
        if remote_extraction is None:
            return "Remote LLM not available for KG extraction"
    except Exception as e:
        logger.error("Failed to initialize remote extraction", error=str(e))
        return f"LLM initialization failed: {e}"

    # Read user's preferred language so entity descriptions follow user's language setting
    try:
        from .settings_reader import read_user_profile
        _profile = read_user_profile()
        _preferred_language: Optional[str] = _profile.get("preferred_language") or None
        if _preferred_language == "en":
            _preferred_language = None  # English is default; no special instruction needed
    except Exception:
        _preferred_language = None

    # 3. Extract sequentially with quality reflection per memory
    total_entities = 0
    total_relationships = 0
    processed_count = 0

    from ..api.routers.distillation import store_entities_and_relationships
    from ..models import MemoryCreateResponse

    total_to_process = len(memories_to_process)
    for idx, mem_data in enumerate(memories_to_process):
        # Update progress for polling
        if current_task_ref and current_task_ref.get("task_type") in (
            "kg_extraction_backfill",
            "kg_extraction",
        ):
            current_task_ref["progress"] = f"{processed_count}/{total_to_process}"

        try:
            entity_result = await remote_extraction.extract_entities_remote(
                memory_title=mem_data["title"],
                memory_content=mem_data["content"],
                memory_index=idx,
                enable_reflection=True,
                enable_deduplication=True,
                preferred_language=_preferred_language,
            )

            if not entity_result.entities and not entity_result.relationships:
                logger.debug(
                    "Skipping memory with no entities extracted",
                    memory_id=mem_data["id"],
                )
                continue

            memory = await memory_ops.get_memory_by_id(mem_data["id"])
            if not memory:
                continue

            mem_response = MemoryCreateResponse(
                memory=memory,
                extracted_entities=[],
                assigned_labels=[],
                created_relationships=0,
            )

            stored_entities, rels_created = await store_entities_and_relationships(
                entity_result=entity_result,
                created_memories=[mem_response],
                memory_ops=memory_ops,
            )
            total_entities += len(stored_entities)
            total_relationships += rels_created

            # Update memory metadata
            updated_metadata = memory.metadata or {}
            if isinstance(updated_metadata, str):
                try:
                    updated_metadata = json.loads(updated_metadata)
                except (json.JSONDecodeError, TypeError):
                    updated_metadata = {}
            updated_metadata.update(
                {
                    "kg_extracted": True,
                    "kg_extracted_at": datetime.now(timezone.utc).isoformat(),
                    "entities_count": len(entity_result.entities),
                    "relationships_count": len(entity_result.relationships),
                    "extraction_method": "background_quality",
                }
            )
            conn = db.conn
            conn.execute(
                "MATCH (m:Memory {id: $memory_id}) SET m.metadata = $metadata, m.updated_at = $updated_at",
                {
                    "memory_id": mem_data["id"],
                    "metadata": json.dumps(updated_metadata),
                    "updated_at": datetime.now(timezone.utc),
                },
            )
            processed_count += 1

        except Exception as e:
            logger.warning(
                "KG extraction failed for memory",
                memory_id=mem_data["id"],
                error=str(e),
            )

        # Rate limit
        if idx < total_to_process - 1:
            await asyncio.sleep(1.5)

    # 4. Emit feed event
    if processed_count > 0:
        try:
            from ..utils.feed_events import emit_feed_event

            emit_feed_event(
                "kg_extraction",
                title=f"Entity Extraction: {processed_count} memories processed",
                description=f"Extracted {total_entities} entities and {total_relationships} relationships",
                severity="info",
                related_memory_ids=memory_ids[:10],
                metadata={
                    "processed_count": processed_count,
                    "total_entities": total_entities,
                    "total_relationships": total_relationships,
                    "memory_ids": memory_ids[:20],
                },
            )
        except Exception:
            pass

    result_msg = f"KG extraction: {processed_count}/{len(memories_to_process)} memories, {total_entities} entities, {total_relationships} relationships"
    logger.info(result_msg)
    return result_msg


async def execute_decay_refresh(
    task: Any,
    db: Any,
    current_task_ref: Optional[Dict[str, Any]] = None,
) -> str:
    """Batch-refresh decay_score_cached for all memories (direct function, no LLM).

    1. Query all non-crystal memories with their decay-relevant fields
    2. Compute fresh decay score for each via memory_decay.compute_decay_score()
    3. Batch-update decay_score_cached in KuzuDB
    4. Auto-archive stale memories (low decay + zero engagement + old)
    5. Emit feed event with summary stats
    """
    if not db:
        return "Database not available"

    from .scheduler import TaskPriority
    from .settings_reader import read_knowledge_processing_settings

    settings = read_knowledge_processing_settings()
    if task.priority == TaskPriority.LOW and not settings.get(
        "autoDecayRefresh", False
    ):
        logger.info("Decay refresh disabled in settings, skipping scheduled run")
        return "Decay refresh disabled in settings"

    from ..services.memory_decay import compute_decay_score

    conn = db.conn
    if not conn:
        return "Database connection not available"

    now = datetime.now(timezone.utc)

    # 1. Query all non-crystal memories
    try:
        memories: List[Dict[str, Any]] = []
        for row in iter_rows(conn.execute(
            """MATCH (m:Memory)
               WHERE m.is_crystal = false
               RETURN m.id, m.last_accessed_at, m.access_count,
                      m.importance, m.appearances, m.clicks,
                      m.total_dwell_time_ms, m.metadata, m.created_at"""
        )):
            memories.append({
                "id": row[0],
                "last_accessed_at": row[1],
                "access_count": row[2] or 0,
                "importance": row[3] if row[3] is not None else 0.5,
                "appearances": row[4] or 0,
                "clicks": row[5] or 0,
                "total_dwell_time_ms": row[6] or 0,
                "metadata": row[7],
                "created_at": row[8],
            })
    except Exception as e:
        logger.error("Failed to query memories for decay refresh", error=str(e))
        return f"Query failed: {e}"

    if not memories:
        return "No memories to refresh"

    # 2. Compute fresh decay scores
    scores: List[Dict[str, Any]] = []
    for mem in memories:
        last_accessed = mem["last_accessed_at"]
        if isinstance(last_accessed, str):
            try:
                last_accessed = datetime.fromisoformat(last_accessed.replace("Z", "+00:00"))
            except (ValueError, TypeError):
                last_accessed = None
        elif last_accessed is not None and not isinstance(last_accessed, datetime):
            last_accessed = None

        decay = compute_decay_score(
            last_accessed_at=last_accessed,
            access_count=mem["access_count"],
            importance=mem["importance"],
            now=now,
        )
        scores.append({"id": mem["id"], "decay": decay})

    # 3. Batch-update decay_score_cached (100 per batch)
    batch_size = 100
    updated_count = 0
    for i in range(0, len(scores), batch_size):
        batch = scores[i : i + batch_size]
        for item in batch:
            try:
                conn.execute(
                    "MATCH (m:Memory {id: $id}) SET m.decay_score_cached = $decay",
                    {"id": item["id"], "decay": item["decay"]},
                )
                updated_count += 1
            except Exception as e:
                logger.debug(
                    "Failed to update decay for memory",
                    memory_id=item["id"],
                    error=str(e),
                )

        if current_task_ref:
            current_task_ref["progress"] = f"{updated_count}/{len(scores)}"

    # 4. Auto-archive stale memories (only when explicitly enabled in settings)
    archived_count = 0
    if settings.get("autoArchiveStaleMemories", False):
        archive_threshold = 0.15
        min_age_days = 90
        age_cutoff = now - timedelta(days=min_age_days)
        archived_count = _auto_archive_stale(
            memories, scores, archive_threshold, age_cutoff, now, conn
        )

    # 5. Compute distribution stats
    decay_values = [s["decay"] for s in scores]
    avg_decay = sum(decay_values) / len(decay_values) if decay_values else 0
    high_count = sum(1 for d in decay_values if d >= 0.7)
    medium_count = sum(1 for d in decay_values if 0.3 <= d < 0.7)
    low_count = sum(1 for d in decay_values if 0.15 <= d < 0.3)
    stale_count = sum(1 for d in decay_values if d < 0.15)

    # 6. Emit feed event
    try:
        from ..utils.feed_events import emit_feed_event

        emit_feed_event(
            "decay_refresh",
            title=f"Memory Health: {updated_count} scores refreshed",
            description=(
                f"Avg decay: {avg_decay:.2f} | "
                f"High: {high_count}, Medium: {medium_count}, "
                f"Low: {low_count}, Stale: {stale_count}"
                + (f" | Auto-archived: {archived_count}" if archived_count > 0 else "")
            ),
            severity="info",
            metadata={
                "total_refreshed": updated_count,
                "avg_decay": round(avg_decay, 3),
                "distribution": {
                    "high": high_count,
                    "medium": medium_count,
                    "low": low_count,
                    "stale": stale_count,
                },
                "archived_count": archived_count,
            },
        )
    except Exception as e:
        logger.debug("Failed to emit decay refresh event", error=str(e))

    result_msg = (
        f"Decay refresh: {updated_count} memories updated, "
        f"avg={avg_decay:.2f}, archived={archived_count}"
    )
    logger.info(result_msg)
    return result_msg


def _auto_archive_stale(
    memories: List[Dict[str, Any]],
    scores: List[Dict[str, Any]],
    threshold: float,
    age_cutoff: datetime,
    now: datetime,
    conn: Any,
) -> int:
    """Archive memories with very low decay, zero engagement, and old age."""
    archived = 0
    for mem, score_item in zip(memories, scores):
        if score_item["decay"] >= threshold:
            continue
        if mem["appearances"] > 0 or mem["clicks"] > 0:
            continue

        created_at = mem["created_at"]
        if isinstance(created_at, str):
            try:
                created_at = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
            except (ValueError, TypeError):
                continue
        if created_at is None:
            continue
        if (
            created_at.tzinfo is None
            and created_at > age_cutoff.replace(tzinfo=None)
        ) or (
            created_at.tzinfo is not None and created_at > age_cutoff
        ):
            continue

        meta_str = mem["metadata"]
        try:
            meta = json.loads(meta_str) if isinstance(meta_str, str) else (meta_str or {})
        except (json.JSONDecodeError, TypeError):
            meta = {}

        if meta.get("state", "active") != "active":
            continue

        meta["state"] = "archived"
        meta["archived_at"] = now.isoformat()
        meta["archived_reason"] = "decay_refresh_auto"
        try:
            conn.execute(
                "MATCH (m:Memory {id: $id}) SET m.metadata = $metadata",
                {"id": mem["id"], "metadata": json.dumps(meta)},
            )
            archived += 1
        except Exception as e:
            logger.debug("Failed to archive memory", memory_id=mem["id"], error=str(e))
    return archived
