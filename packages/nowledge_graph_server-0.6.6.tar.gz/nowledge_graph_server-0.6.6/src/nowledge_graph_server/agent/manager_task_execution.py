"""Task execution logic for KnowledgeAgentManager.

Extracted from manager.py to stay under pyarmor's 1000-line limit.
Contains the scheduler task execution pipeline: settings gates, context
injection, LLM execution with retry, and post-task lifecycle transitions.
"""

from __future__ import annotations

import asyncio
from datetime import timezone, datetime
from typing import TYPE_CHECKING, Any, Dict, Optional

import structlog

from .scheduler import AgentTask, TaskPriority
from .context_injectors import (
    inject_briefing_context,
    inject_compaction_context,
    inject_crystallization_context,
    inject_insight_context,
)
from .context_helpers import gather_graph_totals

if TYPE_CHECKING:
    from .manager import KnowledgeAgentManager

logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# Error-classification patterns
# ---------------------------------------------------------------------------

# Transient error patterns — retry with exponential backoff.
_TRANSIENT_PATTERNS = (
    "peer closed connection",
    "incomplete chunked read",
    "Connection reset",
    "Connection error",
    "Request timed out",
    "RemoteProtocolError",
    "ReadTimeout",
    "ConnectTimeout",
    "Server disconnected",
)

# Context window overflow patterns from LLM providers.
# These are deterministic (same input always fails) — never retry.
_CONTEXT_OVERFLOW_PATTERNS = (
    "context_length_exceeded",
    "maximum context length",
    "too many tokens",
    "request too large",
    "context window",
    "max_tokens",
    "token limit",
    "content_too_large",
    "max_input_tokens",
    "input is too long",
)

_MAX_ATTEMPTS = 3


# ---------------------------------------------------------------------------
# Public entry point (called by KnowledgeAgentManager._execute_task)
# ---------------------------------------------------------------------------


async def execute_scheduled_task(
    mgr: "KnowledgeAgentManager",
    task: AgentTask,
) -> str:
    """Execute an agent task dispatched by the scheduler.

    Direct-function tasks (community_detection, kg_extraction) bypass
    the LLM session entirely — they're compute operations, not analysis.

    LLM-mediated tasks get a fresh session per task to prevent context
    accumulation. For daily_briefing tasks, rich pre-computed context
    is injected (activity digest, yesterday WM, graph totals).
    """
    # Track current task for progress reporting
    mgr._current_task = {
        "task_type": task.task_type,
        "started_at": datetime.now(timezone.utc).isoformat(),
    }

    try:
        result = await _execute_task_inner(mgr, task)

        # Post-task lifecycle transitions
        if task.task_type == "source_extraction" and result:
            try:
                source_id = task.metadata.get("source_id")
                if source_id:
                    await mgr._db.source_repo.update_lifecycle_state(source_id, "extracted")
                    # Notify frontend to refetch sources (drives Learn → Learned transition)
                    from nowledge_graph_server.utils.progress_logger import log_data_change
                    log_data_change("source_lifecycle_updated", "source", source_id, {"state": "extracted"})
                    from ..utils.feed_events import emit_feed_event
                    emit_feed_event(
                        "source_extracted",
                        title=f"Learned: {task.metadata.get('source_name', source_id)}",
                        description=result[:500] if result else "Knowledge extracted from source document",
                        metadata={
                            "source_id": source_id,
                            "agent_report": result,
                            "source_name": task.metadata.get("source_name", source_id),
                        },
                    )
            except Exception as e:
                logger.warning("Failed to update source lifecycle after extraction", error=str(e))

        # Mark analyzed threads for cooldown tracking (prevents re-analysis)
        if task.task_type == "thread_synced":
            now_iso = datetime.now(timezone.utc).isoformat()
            for e in task.metadata.get("events", []):
                tid = e.get("thread_id", "")
                if tid:
                    mgr._scheduler._set_state(f"thread_analyzed_{tid}", now_iso)

        # Emit feed events for crystallization, insight, and compaction tasks
        if task.task_type in ("crystallization_review", "insight_detection", "memory_compaction") and result:
            try:
                from ..utils.feed_events import emit_feed_event
                _event_titles = {
                    "crystallization_review": "Synthesis review completed",
                    "insight_detection": "Discovery detection completed",
                    "memory_compaction": "Memory compaction completed",
                }
                # Each task type emits its own event_type for dedicated frontend renderers
                emit_feed_event(
                    task.task_type,
                    title=_event_titles[task.task_type],
                    description=result[:500] if result else "Task completed",
                    metadata={
                        "task_type": task.task_type,
                        "agent_summary": result[:2000] if result else "",
                    },
                )
            except Exception as e:
                logger.debug("Failed to emit task completion event", error=str(e))

        return result
    finally:
        # Record completion timestamp and persist to scheduler state
        mgr._last_executed[task.task_type] = datetime.now(timezone.utc).isoformat()
        mgr._scheduler._set_state("last_executed", mgr._last_executed)
        mgr._current_task = None


# ---------------------------------------------------------------------------
# Inner execution (settings gates, context injection, LLM retry loop)
# ---------------------------------------------------------------------------


async def _execute_task_inner(
    mgr: "KnowledgeAgentManager",
    task: AgentTask,
) -> str:
    """Inner task execution: direct-function dispatch, settings gates,
    context injection, and LLM execution with retry."""

    # Direct-function tasks bypass the LLM session
    executor = mgr._direct_executors.get(task.task_type)
    if executor is not None:
        try:
            result = await executor(task)
            logger.info("Direct task completed", task_type=task.task_type, result_length=len(result))
            return result
        except Exception as e:
            logger.error("Direct task failed", task_type=task.task_type, error=str(e))
            try:
                from ..utils.feed_events import emit_feed_event
                emit_feed_event(
                    "system_event",
                    title=f"Background task failed: {task.task_type}",
                    description=str(e)[:500],
                    severity="warning",
                )
            except Exception:
                pass
            return ""

    # LLM-mediated tasks require a session
    if not mgr._session:
        logger.warning("Cannot execute task: session not initialized")
        return ""

    # Settings gate for scheduled/event-driven LLM tasks
    if task.priority in (TaskPriority.LOW, TaskPriority.NORMAL):
        from .settings_reader import read_knowledge_processing_settings
        _lm_settings = read_knowledge_processing_settings()

        # Master toggle: backgroundIntelligence disables ALL background tasks
        if not _lm_settings.get("backgroundIntelligence", True):
            logger.info(f"{task.task_type} skipped: background intelligence disabled")
            return f"{task.task_type} skipped: background intelligence disabled"

        _gate_map = {
            "daily_briefing": "autoDailyBriefing",
            "crystallization_review": "autoCrystallization",
            "insight_detection": "autoInsightDetection",
            "memory_compaction": "autoMemoryCompaction",
            "decay_refresh": "autoDecayRefresh",
            "wm_refresh": "autoWMRefresh",
            "memory_created": "autoEVOLVESDetection",
            "evolves_detected": "autoEVOLVESDetection",
        }
        _setting_key = _gate_map.get(task.task_type)
        if _setting_key and not _lm_settings.get(_setting_key, True):
            logger.info(f"{task.task_type} disabled in settings, skipping")
            return f"{task.task_type} disabled in settings"

    # --- Context injection (once, before retry loop) ---
    logger.info("[EXECUTE TASK] Injecting context", task_type=task.task_type, prompt_length=len(task.prompt))
    if task.task_type == "daily_briefing":
        task.prompt = await inject_briefing_context(mgr._db, mgr._events_dir, task.prompt)
        logger.info("[EXECUTE TASK] Prompt after injection", prompt_length=len(task.prompt))
    elif task.task_type == "crystallization_review":
        task.prompt = await inject_crystallization_context(mgr._db, mgr._events_dir, task.prompt)
        logger.info("[EXECUTE TASK] Crystallization context injected", prompt_length=len(task.prompt))
    elif task.task_type == "insight_detection":
        task.prompt = await inject_insight_context(mgr._db, mgr._events_dir, task.prompt)
        logger.info("[EXECUTE TASK] Insight detection context injected", prompt_length=len(task.prompt))
    elif task.task_type == "memory_compaction":
        task.prompt = await inject_compaction_context(mgr._db, mgr._events_dir, task.prompt)
        logger.info("[EXECUTE TASK] Compaction context injected", prompt_length=len(task.prompt))
    else:
        # Other tasks get lightweight graph totals
        try:
            conn = mgr._db.conn if mgr._db else None
            totals = await gather_graph_totals(conn)
            if totals:
                task.prompt = totals + "\n\n" + task.prompt
        except Exception as e:
            logger.debug("Failed to inject graph totals", error=str(e))

    # Enrich scheduled follow-ups with related memory content
    if task.task_type == "scheduled_follow_up" and mgr._memory_ops:
        related_ids = task.metadata.get("related_memory_ids", [])
        if related_ids:
            try:
                snippets = []
                for mid in related_ids[:5]:
                    mem = await mgr._memory_ops.get_memory_by_id(mid)
                    if mem:
                        title = getattr(mem, "title", None) or "Untitled"
                        content = (getattr(mem, "content", "") or "")[:600]
                        snippets.append(f"- **{title}** (id: {mid}): {content}")
                if snippets:
                    context_block = "## Related Memories (context for this follow-up)\n\n" + "\n".join(snippets)
                    task.prompt = context_block + "\n\n---\n\n## Your Task\n\n" + task.prompt
            except Exception as e:
                logger.debug("Failed to inject follow-up memory context", error=str(e))

    # --- LLM execution with retry ---
    # Transient errors (connection drops, timeouts, incomplete reads) are
    # retried with exponential backoff. Each retry gets a fresh session.
    from .knowledge_agent_session import (
        ContextWindowExhausted,
        MaxStepsReached,
        TokenBudgetExceeded,
        ToolLoopDetected,
    )

    last_error: Optional[Exception] = None

    for attempt in range(_MAX_ATTEMPTS):
        # Re-read max steps from settings (may have changed since startup)
        mgr._session.set_max_steps(mgr._get_max_steps_per_task())

        # Fresh session per attempt — prevents stale connections
        try:
            await mgr._session.restart_fresh()
        except Exception as e:
            logger.error("Failed to restart session for task", task_type=task.task_type, error=str(e))
            return ""

        try:
            # Per-task token budget (cumulative input+output across all steps).
            # Configurable via app-settings.json → knowledgeProcessing.maxTokensPerTask.
            # 0 = unlimited.  Default: 500k.
            per_task_budget = mgr._get_per_task_budget()
            result = await mgr._session.run_task(task.prompt, max_tokens=per_task_budget)

            # Record token usage for hourly/daily budget enforcement
            inp, out = mgr._session.last_task_tokens
            if inp > 0 or out > 0:
                mgr._scheduler.record_token_usage(inp, out)

            logger.info(
                "Task executed successfully",
                task_type=task.task_type,
                response_length=len(result),
                input_tokens=inp,
                output_tokens=out,
                attempt=attempt + 1,
            )

            return result

        except TokenBudgetExceeded as e:
            # Record the partial tokens and emit a warning — do NOT retry
            mgr._scheduler.record_token_usage(e.input_tokens, e.output_tokens)
            logger.error(
                "Task aborted: token budget exceeded",
                task_type=task.task_type,
                input_tokens=e.input_tokens,
                output_tokens=e.output_tokens,
                max_step_input=e.max_step_input,
                budget=e.budget,
            )
            try:
                from ..utils.feed_events import emit_feed_event
                emit_feed_event(
                    "system_event",
                    title="Task aborted: token budget exceeded",
                    description=(
                        f"Background task '{task.task_type}' used "
                        f"{e.input_tokens + e.output_tokens:,} tokens "
                        f"(budget: {e.budget:,}, peak step: {e.max_step_input:,}). "
                        f"Task was stopped to prevent excessive costs."
                    ),
                    severity="warning",
                    metadata={
                        "task_type": task.task_type,
                        "input_tokens": e.input_tokens,
                        "output_tokens": e.output_tokens,
                        "max_step_input": e.max_step_input,
                        "budget": e.budget,
                    },
                )
            except Exception:
                pass
            return ""

        except ContextWindowExhausted as e:
            # Context approaching model limit — do NOT retry
            logger.error(
                "Task aborted: context window exhausted",
                task_type=task.task_type,
                context_usage=f"{e.context_usage:.1%}",
                step_tokens=e.step_tokens,
            )
            try:
                from ..utils.feed_events import emit_feed_event
                emit_feed_event(
                    "system_event",
                    title="Task aborted: context window full",
                    description=(
                        f"Background task '{task.task_type}' filled "
                        f"{e.context_usage:.0%} of the model's context window "
                        f"(step input: {e.step_tokens:,} tokens). "
                        f"The task was stopped before the provider rejected it. "
                        f"This may indicate the task generates too many tool calls "
                        f"or the model's context window is too small."
                    ),
                    severity="warning",
                    metadata={
                        "task_type": task.task_type,
                        "context_usage": round(e.context_usage, 3),
                        "step_tokens": e.step_tokens,
                    },
                )
            except Exception:
                pass
            return ""

        except ToolLoopDetected as e:
            # Circuit breaker tripped — do NOT retry
            logger.error(
                "Task aborted: tool loop detected",
                task_type=task.task_type,
                consecutive_errors=e.consecutive_errors,
                last_error=e.last_error[:200],
            )
            try:
                from ..utils.feed_events import emit_feed_event
                emit_feed_event(
                    "system_event",
                    title="Task aborted: tool retry loop",
                    description=(
                        f"Background task '{task.task_type}' hit {e.consecutive_errors} "
                        f"consecutive tool errors and was stopped. "
                        f"Last error: {e.last_error[:300]}"
                    ),
                    severity="warning",
                    metadata={
                        "task_type": task.task_type,
                        "consecutive_errors": e.consecutive_errors,
                    },
                )
            except Exception:
                pass
            return ""

        except MaxStepsReached as e:
            # Task hit step limit but may have produced useful partial output.
            # Record tokens, emit a "partial completion" event, and return
            # the partial response (not empty) so post-task hooks can fire.
            inp, out = mgr._session.last_task_tokens
            if inp > 0 or out > 0:
                mgr._scheduler.record_token_usage(inp, out)
            logger.warning(
                "Task reached step limit",
                task_type=task.task_type,
                step_count=e.step_count,
                response_length=len(e.partial_response),
            )
            try:
                from ..utils.feed_events import emit_feed_event
                emit_feed_event(
                    "system_event",
                    title="Task reached step limit",
                    description=(
                        f"Background task '{task.task_type}' used all "
                        f"{e.step_count} allowed steps. The task's intermediate "
                        f"outputs (insights, flags, crystals) have been preserved. "
                        f"You can increase the step limit in Settings > Knowledge Processing."
                    ),
                    severity="info",
                    metadata={
                        "task_type": task.task_type,
                        "step_count": e.step_count,
                        "partial_response_length": len(e.partial_response),
                    },
                )
            except Exception:
                pass
            return e.partial_response  # Return partial — not empty!

        except Exception as e:
            last_error = e
            error_str = str(e)
            error_lower = error_str.lower()

            # Context window overflow from provider (400 status) —
            # deterministic failure, retrying is pointless.
            is_context_overflow = any(
                p in error_lower for p in _CONTEXT_OVERFLOW_PATTERNS
            )
            if is_context_overflow:
                logger.error(
                    "Task aborted: provider context window overflow",
                    task_type=task.task_type,
                    error=error_str[:500],
                )
                try:
                    from ..utils.feed_events import emit_feed_event
                    emit_feed_event(
                        "system_event",
                        title="Task aborted: model context window exceeded",
                        description=(
                            f"Background task '{task.task_type}' sent a prompt "
                            f"that exceeds the model's context window. "
                            f"Error: {error_str[:300]}. "
                            f"Consider using a model with a larger context window "
                            f"or reducing the task's scope."
                        ),
                        severity="warning",
                        metadata={"task_type": task.task_type},
                    )
                except Exception:
                    pass
                break  # Don't retry

            is_transient = any(p in error_str for p in _TRANSIENT_PATTERNS)

            if is_transient and attempt < _MAX_ATTEMPTS - 1:
                backoff = 2 ** (attempt + 1)  # 2s, 4s
                logger.warning(
                    "Transient LLM error, retrying",
                    task_type=task.task_type,
                    error=error_str,
                    attempt=attempt + 1,
                    backoff_seconds=backoff,
                )
                await asyncio.sleep(backoff)
                continue

            # Non-transient or final attempt — give up
            logger.error(
                "Task execution failed",
                task_type=task.task_type,
                error=error_str,
                attempt=attempt + 1,
                is_transient=is_transient,
            )
            break

    # All attempts exhausted — emit feed event with diagnostic context
    try:
        from ..utils.feed_events import emit_feed_event
        error_desc = str(last_error) if last_error else "Unknown error"
        # FileNotFoundError.filename is often the only clue for [Errno 2]
        if isinstance(last_error, FileNotFoundError) and getattr(last_error, "filename", None):
            error_desc = f"{error_desc} (file: {last_error.filename})"
        emit_feed_event(
            "system_event",
            title=f"Background task failed: {task.task_type}",
            description=error_desc[:500],
            severity="warning",
        )
    except Exception:
        pass
    return ""
