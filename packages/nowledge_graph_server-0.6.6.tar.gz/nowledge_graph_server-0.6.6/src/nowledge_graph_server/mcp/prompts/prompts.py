"""MCP prompts for memory and thread management."""

from fastmcp import FastMCP


def register_prompts(mcp: FastMCP) -> None:
    """Register MCP prompts with the server."""

    @mcp.prompt(
        name="sum",
        description="Analyze conversation and create structured memories categorized by type",
        tags={"memory", "planning", "analysis", "knowledge-management"},
    )
    def sum() -> str:
        """Analyze current conversation and create structured memory entries."""

        prompt = """Analyze our conversation and create structured memory entries. Follow this approach:

**Memory Categories** (use as labels):

- **insight**: Key learnings, realizations, "aha" moments
- **decision**: Choices made with rationale and trade-offs
- **fact**: Important information, data points, references
- **procedure**: How-to knowledge, workflows, SOPs
- **experience**: Events, conversations, outcomes (episodic)

**For Each Memory:**

1. **Title** (max 60 chars): Searchable, captures essence
2. **Content**: Structured summary with:
   - Context: Why this matters
   - Details: Key specifics (names, dates, code snippets if relevant)
   - Outcome: Result or conclusion
3. **Importance** (0.1-1.0):
   - 0.8-1.0: Critical decisions, breakthroughs, blockers resolved
   - 0.5-0.7: Useful insights, standard decisions
   - 0.1-0.4: Background info, minor details
4. **Labels**: 2-4 tags (category + topic, e.g., decision,architecture,python)
5. **Temporal**: When it happened/applies (event_start if known)

**Quality Standards:**
- Standalone: Makes sense without conversation context
- Professional language (no emojis)
- Preserves actionable details
- Focuses on "what I learned" not "what we discussed"

Now use memory_add to create memories for significant items in our conversation."""

        return prompt

    @mcp.prompt(
        name="save",
        description="Save the current coding session to knowledge base",
        tags={"thread", "conversation", "claude-code", "save"},
    )
    def save() -> str:  # type: ignore
        """Implementation returns a prompt to guide saving the current Claude Code session.

        NOTE: This prompt is restricted to Claude Code and Codex clients only.
        """

        prompt = """Save this session using thread_persist:
- client: "claude-code"
- project_path: current working directory
- summary: 1-2 sentences on what was accomplished

Example: "Implemented OAuth2 auth with JWT. Added bcrypt hashing and rate limiting."

Focus summary on outcomes and decisions, not process."""

        return prompt
