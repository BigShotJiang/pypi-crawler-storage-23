"""MCP prompts package."""
