"""App-based filtering middleware for MCP tools and prompts.

This middleware handles two types of filtering:
1. App-based: Some tools only available to specific apps (e.g., thread_persist for Claude Code)
2. Plugin-based: For AI-NOW, tools are further filtered by enabled plugins

Plugin flags are passed via X-Enabled-Plugins header (comma-separated plugin IDs).
"""

import re

import structlog
from fastmcp.server.middleware import Middleware, MiddlewareContext
from fastmcp.exceptions import ToolError

from nowledge_graph_server.utils.mcp_utils import get_app_source_from_headers

logger = structlog.get_logger(__name__)

# Define which tools/prompts are restricted to specific apps
CLAUDE_CODE_CODEX_ONLY_TOOLS = {"thread_persist"}
CLAUDE_CODE_CODEX_ONLY_PROMPTS = {"save"}
# Web search and Obsidian tools are only for AI-NOW (desktop app)
# Note: web_fetch not needed - kimi's FetchURL works without API key
AI_NOW_ONLY_TOOLS = {
    "web_search",
    "obsidian_search",
    "obsidian_get_note",
    "apple_notes_search",
    "apple_notes_list",
    "apple_notes_get_note",
    "run_community_detection",
    "extract_knowledge_graph",
}

# =============================================================================
# Plugin → Tools Mapping
# =============================================================================

# Map plugin IDs to their tools (for AI-NOW plugin filtering)
PLUGIN_TOOLS: dict[str, set[str]] = {
    # Web search plugin
    "plugin-web-search": {"web_search"},
    # Obsidian vault plugin
    "plugin-obsidian": {
        "obsidian_search",
        "obsidian_get_note",
    },
    # Deep Research uses both web_search and memory_search
    "plugin-research": {"web_search", "memory_search"},
    # Apple Notes plugin (macOS only)
    "plugin-apple-notes": {
        "apple_notes_search",
        "apple_notes_list",
        "apple_notes_get_note",
    },
    # Knowledge processing plugin
    "plugin-knowledge-processing": {"run_community_detection", "extract_knowledge_graph"},
}

# Tools that are ALWAYS available (not controlled by plugins)
ALWAYS_AVAILABLE_TOOLS = {
    "memory_search",
    "memory_add",
    "memory_update",
    "memory_delete",
    "list_memory_labels",
    "thread_persist",
}

# Apps allowed for thread_persist and save prompt
ALLOWED_APPS_FOR_THREAD_PERSIST = {
    # Claude Code variations
    "claude-code",
    "claude_code",
    "claudecode",
    # Codex variations
    "codex",
    "codex-cli",
    "codex_cli",
    "codexcli",
    "codex cli",
    # Generic fallback
    "mcp_generic",
}

# Apps allowed for web search tools
ALLOWED_APPS_FOR_WEB_SEARCH = {
    # AI-NOW desktop app
    "ai-now",
    "ai_now",
    "ainow",
    "AI-NOW",
    # Also allow kimi-cli (used by AI-NOW internally)
    "kimi",
    "kimi-cli",
    "kimi_cli",
    # Generic fallback for testing
    "mcp_generic",
}

# Combined allowed apps for backward compatibility
ALLOWED_APPS_FOR_RESTRICTED = ALLOWED_APPS_FOR_THREAD_PERSIST

# Known multi-instance base plugin IDs (for resolving plugin-obsidian-2 → plugin-obsidian)
_MULTI_INSTANCE_BASES = {"plugin-obsidian", "plugin-notion"}
_MULTI_INSTANCE_SUFFIX_RE = re.compile(r"^(.+)-(\d+)$")


class AppFilteringMiddleware(Middleware):
    """Middleware to filter tools and prompts based on app source and plugins.

    Filtering layers:
    1. App-based: thread_persist only for Claude Code/Codex, web_search/obsidian only for AI-NOW
    2. Plugin-based: For AI-NOW apps, tools are further filtered by enabled plugins

    Plugin flags are read from X-Enabled-Plugins header.
    """

    def _get_app_source(self, context: MiddlewareContext) -> str:
        """Extract app source from request context."""
        try:
            # Try to get HTTP headers from FastMCP context using dependency injection
            from fastmcp.server.dependencies import get_http_headers
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
            logger.debug("App source detected", app_source=app_source)
            return app_source
        except Exception as e:
            logger.debug("Failed to extract app source from headers", error=str(e))

        # Default to allowing access if we can't determine the app
        # This allows the tools to work even when app source detection fails
        return "mcp_generic"

    def _get_enabled_plugins(self) -> set[str]:
        """Extract enabled plugins from X-Enabled-Plugins header."""
        try:
            from fastmcp.server.dependencies import get_http_headers
            headers = get_http_headers()
            plugins_header = headers.get("x-enabled-plugins", "")
            if plugins_header:
                plugins = {p.strip() for p in plugins_header.split(",") if p.strip()}
                logger.debug("Enabled plugins from header", plugins=plugins)
                return plugins
        except Exception as e:
            logger.debug("Failed to extract plugins from header", error=str(e))
        return set()

    def _get_ai_now_llm_provider_type(self) -> str | None:
        """Read AI Now's active LLM provider type from headers (if provided).

        This allows us to tailor tool schemas for providers with stricter tool schema requirements
        (e.g. google_genai rejects JSON Schema fields like `examples`).
        """
        try:
            from fastmcp.server.dependencies import get_http_headers

            headers = get_http_headers()
            # Header keys are lowercased by Starlette.
            v = headers.get("x-ainow-llm-provider", "")
            v = (v or "").strip()
            if v:
                # Some runtimes report transport type (openai_legacy/openai_responses)
                # while others report provider family (xai/google_genai). Normalize here.
                lv = v.lower()
                if lv in ("gemini", "google"):
                    return "google_genai"
                return lv
        except Exception:
            pass

        # Fallback: derive from active remote LLM provider (AI Now uses the same remote LLM config)
        try:
            from nowledge_graph_server.services.remote_llm_config import get_config_manager

            cfg = get_config_manager().get_config()
            active = (getattr(cfg, "provider", "") or "").strip().lower()
            if active in ("gemini", "google"):
                return "google_genai"
            if active == "xai":
                return "xai"
        except Exception:
            pass

        return None

    def _sanitize_tool_schema_for_google_genai(self, schema):
        """Strip fields unsupported by google_genai's FunctionDeclaration schema.

        We keep the informational value by appending examples into descriptions when possible.
        """
        if isinstance(schema, dict):
            # Google GenAI rejects additional_properties on wire in strict schema paths.
            # Drop both spellings for safety (camelCase JSON Schema + snake_case variants).
            schema.pop("additionalProperties", None)
            schema.pop("additional_properties", None)

            # If schema has examples, move them into description
            if "examples" in schema:
                ex = schema.get("examples")
                if ex and "description" in schema and isinstance(schema.get("description"), str):
                    try:
                        # Keep this short to avoid bloating prompts
                        ex_text = ", ".join([str(x) for x in ex][:3]) if isinstance(ex, list) else str(ex)
                        schema["description"] = schema["description"].rstrip() + f"\n\nExamples: {ex_text}"
                    except Exception:
                        pass
                # Remove examples (google_genai forbids it)
                schema.pop("examples", None)
            # Some schemas use singular 'example'
            if "example" in schema:
                schema.pop("example", None)

            for k, v in list(schema.items()):
                schema[k] = self._sanitize_tool_schema_for_google_genai(v)
            return schema
        if isinstance(schema, list):
            return [self._sanitize_tool_schema_for_google_genai(x) for x in schema]
        return schema

    def _sanitize_tool_schema_for_xai(self, schema):
        """Reduce JSON schema complexity for xAI function/tool parsing.

        xAI currently rejects a subset of valid Draft 2020-12 schema keywords in
        function definitions. Keep core shape (`type/properties/required/items/enum`)
        and drop high-variance metadata/constraints.
        """
        if isinstance(schema, dict):
            # xAI rejects many composition keywords. Prefer collapsing to one concrete branch.
            for composite_key in ("anyOf", "oneOf", "allOf"):
                variants = schema.get(composite_key)
                if isinstance(variants, list) and variants:
                    picked = None
                    for cand in variants:
                        if not isinstance(cand, dict):
                            continue
                        ctype = cand.get("type")
                        # Prefer non-null branch for Optional[T]-like schemas.
                        if ctype != "null":
                            picked = cand
                            break
                    if picked is None:
                        picked = variants[0] if isinstance(variants[0], dict) else {}
                    base_desc = schema.get("description")
                    collapsed = self._sanitize_tool_schema_for_xai(picked)
                    if (
                        isinstance(base_desc, str)
                        and base_desc
                        and isinstance(collapsed, dict)
                        and "description" not in collapsed
                    ):
                        collapsed["description"] = base_desc
                    return collapsed if isinstance(collapsed, dict) else {"type": "string"}

            out = {}
            for k, v in schema.items():
                if k in {
                    "$schema",
                    "$defs",
                    "definitions",
                    "$ref",
                    "not",
                    "if",
                    "then",
                    "else",
                    "patternProperties",
                    "unevaluatedProperties",
                    "examples",
                    "example",
                    "default",
                    "const",
                    "title",
                    "minLength",
                    "maxLength",
                    "pattern",
                    "format",
                    "minimum",
                    "maximum",
                    "exclusiveMinimum",
                    "exclusiveMaximum",
                    "multipleOf",
                    "minItems",
                    "maxItems",
                    "uniqueItems",
                    "minProperties",
                    "maxProperties",
                    "dependentRequired",
                    "dependentSchemas",
                }:
                    continue
                if k in ("additionalProperties", "additional_properties"):
                    continue
                out[k] = self._sanitize_tool_schema_for_xai(v)
            # Normalize list type declarations (e.g. ["string", "null"]).
            if isinstance(out.get("type"), list):
                tlist = [t for t in out["type"] if t != "null"]
                out["type"] = tlist[0] if tlist else "string"
            # Keep params root as object for function-call compatibility.
            if out.get("type") is None and "properties" in out:
                out["type"] = "object"
            if out.get("type") == "object" and not isinstance(out.get("properties"), dict):
                out["properties"] = {}
            # Ensure property schemas are not empty dicts (xAI can reject ambiguous entries).
            if isinstance(out.get("properties"), dict):
                for pk, pv in list(out["properties"].items()):
                    if isinstance(pv, dict) and not pv:
                        out["properties"][pk] = {"type": "string"}
            if isinstance(out.get("required"), list) and isinstance(out.get("properties"), dict):
                out["required"] = [r for r in out["required"] if r in out["properties"]]
            return out
        if isinstance(schema, list):
            return [self._sanitize_tool_schema_for_xai(x) for x in schema]
        return schema

    def _simplify_schema_node_for_xai(self, node, *, is_root: bool = False):
        """Convert schema node to xAI-safe low-complexity subset.

        Strategy:
        - Root keeps object/properties shape.
        - Property schemas collapse to primitive-friendly forms.
        - Nested objects become string-typed hints to avoid deep validator incompatibility.
        """
        if not isinstance(node, dict):
            return {"type": "string"}

        # Resolve composition keywords first.
        for key in ("anyOf", "oneOf", "allOf"):
            variants = node.get(key)
            if isinstance(variants, list) and variants:
                picked = None
                for cand in variants:
                    if isinstance(cand, dict) and cand.get("type") != "null":
                        picked = cand
                        break
                if picked is None:
                    picked = variants[0] if isinstance(variants[0], dict) else {"type": "string"}
                merged = dict(picked)
                if isinstance(node.get("description"), str) and "description" not in merged:
                    merged["description"] = node["description"]
                return self._simplify_schema_node_for_xai(merged, is_root=is_root)

        t = node.get("type")
        if isinstance(t, list):
            non_null = [x for x in t if x != "null"]
            t = non_null[0] if non_null else "string"

        # Root/tool-params object: preserve top-level fields but simplify each property.
        if is_root or t == "object" or "properties" in node:
            props = node.get("properties")
            out_props = {}
            if isinstance(props, dict):
                for name, prop_schema in props.items():
                    out_props[str(name)] = self._simplify_schema_node_for_xai(prop_schema, is_root=False)

            out = {"type": "object", "properties": out_props}
            req = node.get("required")
            if isinstance(req, list):
                out["required"] = [r for r in req if r in out_props]
            if isinstance(node.get("description"), str):
                out["description"] = node["description"]
            return out

        if t == "array":
            items = node.get("items")
            item_schema = self._simplify_schema_node_for_xai(items, is_root=False)
            # Nested object arrays are risky; model can pass JSON string safely.
            if item_schema.get("type") == "object":
                item_schema = {"type": "string", "description": "JSON string"}
            out = {"type": "array", "items": item_schema}
            if isinstance(node.get("description"), str):
                out["description"] = node["description"]
            return out

        # Primitive + enum subset.
        out: dict = {}
        primitive = t if t in ("string", "number", "integer", "boolean") else "string"
        out["type"] = primitive
        enum_vals = node.get("enum")
        if isinstance(enum_vals, list) and enum_vals:
            # Keep enum short and scalar-only for compatibility.
            safe = [v for v in enum_vals if isinstance(v, (str, int, float, bool))]
            if safe:
                out["enum"] = safe[:50]
        if isinstance(node.get("description"), str):
            out["description"] = node["description"]
        return out

    def _schema_has_examples(self, schema) -> bool:
        if isinstance(schema, dict):
            if "examples" in schema or "example" in schema:
                return True
            return any(self._schema_has_examples(v) for v in schema.values())
        if isinstance(schema, list):
            return any(self._schema_has_examples(x) for x in schema)
        return False

    def _schema_has_xai_risky_fields(self, schema) -> bool:
        risky = {
            "$schema",
            "$defs",
            "definitions",
            "$ref",
            "allOf",
            "anyOf",
            "oneOf",
            "not",
            "if",
            "then",
            "else",
            "patternProperties",
            "unevaluatedProperties",
            "examples",
            "example",
            "default",
            "const",
            "title",
            "additionalProperties",
            "additional_properties",
        }
        if isinstance(schema, dict):
            if any(k in schema for k in risky):
                return True
            return any(self._schema_has_xai_risky_fields(v) for v in schema.values())
        if isinstance(schema, list):
            return any(self._schema_has_xai_risky_fields(x) for x in schema)
        return False

    def _maybe_sanitize_tool_for_google_genai(self, tool, provider_type: str | None):
        """Return tool with schema sanitized for google_genai, if needed."""
        if provider_type != "google_genai":
            return tool

        # Try common schema attribute names / shapes
        schema = None
        if isinstance(tool, dict):
            schema = tool.get("inputSchema") or tool.get("input_schema")
        else:
            if hasattr(tool, "inputSchema"):
                schema = getattr(tool, "inputSchema", None)
            if schema is None and hasattr(tool, "input_schema"):
                schema = getattr(tool, "input_schema", None)
            # Some pydantic models store it under model_dump keys only
            if schema is None and hasattr(tool, "model_dump"):
                try:
                    dumped = tool.model_dump(by_alias=True)  # type: ignore[attr-defined]
                    if isinstance(dumped, dict):
                        schema = dumped.get("inputSchema") or dumped.get("input_schema")
                except Exception:
                    pass

        if not isinstance(schema, dict):
            return tool

        try:
            import copy

            new_schema = self._sanitize_tool_schema_for_google_genai(copy.deepcopy(schema))
        except Exception:
            return tool

        # Prefer pydantic model_copy if available
        if hasattr(tool, "model_copy"):
            try:
                return tool.model_copy(update={"inputSchema": new_schema})  # type: ignore[attr-defined]
            except Exception:
                pass

        # Try to rebuild pydantic model from dumped dict
        if hasattr(tool, "model_dump") and hasattr(tool.__class__, "model_validate"):
            try:
                dumped = tool.model_dump(by_alias=True)  # type: ignore[attr-defined]
                if isinstance(dumped, dict):
                    dumped["inputSchema"] = new_schema
                    return tool.__class__.model_validate(dumped)  # type: ignore[attr-defined]
            except Exception:
                pass

        try:
            setattr(tool, "inputSchema", new_schema)
        except Exception:
            pass
        return tool

    def _maybe_sanitize_tool_for_xai(self, tool, provider_type: str | None):
        """Return tool with schema sanitized for xAI, if needed."""
        if provider_type != "xai":
            return tool

        schema = None
        if isinstance(tool, dict):
            schema = tool.get("inputSchema") or tool.get("input_schema")
        else:
            if hasattr(tool, "inputSchema"):
                schema = getattr(tool, "inputSchema", None)
            if schema is None and hasattr(tool, "input_schema"):
                schema = getattr(tool, "input_schema", None)
            if schema is None and hasattr(tool, "model_dump"):
                try:
                    dumped = tool.model_dump(by_alias=True)  # type: ignore[attr-defined]
                    if isinstance(dumped, dict):
                        schema = dumped.get("inputSchema") or dumped.get("input_schema")
                except Exception:
                    pass

        if not isinstance(schema, dict):
            return tool

        try:
            import copy

            new_schema = self._sanitize_tool_schema_for_xai(copy.deepcopy(schema))
            # Enforce low-complexity schema profile for xAI to reduce validator rejections.
            new_schema = self._simplify_schema_node_for_xai(new_schema, is_root=True)
        except Exception:
            return tool

        if hasattr(tool, "model_copy"):
            try:
                return tool.model_copy(update={"inputSchema": new_schema})  # type: ignore[attr-defined]
            except Exception:
                pass

        if hasattr(tool, "model_dump") and hasattr(tool.__class__, "model_validate"):
            try:
                dumped = tool.model_dump(by_alias=True)  # type: ignore[attr-defined]
                if isinstance(dumped, dict):
                    dumped["inputSchema"] = new_schema
                    return tool.__class__.model_validate(dumped)  # type: ignore[attr-defined]
            except Exception:
                pass

        try:
            setattr(tool, "inputSchema", new_schema)
        except Exception:
            pass
        return tool

    def _maybe_sanitize_tool_for_provider(self, tool, provider_type: str | None):
        if provider_type == "google_genai":
            return self._maybe_sanitize_tool_for_google_genai(tool, provider_type)
        if provider_type == "xai":
            return self._maybe_sanitize_tool_for_xai(tool, provider_type)
        return tool

    def _is_app_allowed_for_tool(self, tool_name: str, app_source: str) -> bool:
        """Check if the app is allowed to access the tool (app-level restriction)."""
        # Check thread_persist restriction
        if tool_name in CLAUDE_CODE_CODEX_ONLY_TOOLS:
            return app_source in ALLOWED_APPS_FOR_THREAD_PERSIST
        # Check web search tools restriction
        if tool_name in AI_NOW_ONLY_TOOLS:
            return app_source in ALLOWED_APPS_FOR_WEB_SEARCH
        # All other tools are available to all apps
        return True

    @staticmethod
    def _get_base_plugin_id(plugin_id: str) -> str:
        """Extract the base plugin ID from a possibly-suffixed instance ID.

        E.g., 'plugin-obsidian-2' → 'plugin-obsidian', 'plugin-notion' → 'plugin-notion'.
        Only strips trailing -N if the base is a known multi-instance plugin.
        """
        if plugin_id in _MULTI_INSTANCE_BASES:
            return plugin_id
        match = _MULTI_INSTANCE_SUFFIX_RE.match(plugin_id)
        if match and match.group(1) in _MULTI_INSTANCE_BASES:
            return match.group(1)
        return plugin_id

    def _is_plugin_enabled_for_tool(self, tool_name: str, enabled_plugins: set[str]) -> bool:
        """Check if tool's plugin is enabled (plugin-level restriction).

        Returns True if:
        - Tool is in ALWAYS_AVAILABLE_TOOLS (core memory tools)
        - Tool's plugin is in the enabled_plugins set (supports multi-instance: plugin-obsidian-2 matches plugin-obsidian tools)
        - No plugin header was sent (empty set = no plugin filtering)
        """
        # Core tools are always available
        if tool_name in ALWAYS_AVAILABLE_TOOLS:
            return True

        # If no plugin header, allow all (backward compatibility)
        if not enabled_plugins:
            return True

        # Resolve enabled plugins to their base IDs for matching
        enabled_base_ids = {self._get_base_plugin_id(pid) for pid in enabled_plugins}

        # Check if tool's plugin is enabled (match against base IDs)
        for plugin_id, plugin_tools in PLUGIN_TOOLS.items():
            if tool_name in plugin_tools:
                return plugin_id in enabled_base_ids

        # Tool not in any plugin = always available
        return True

    def _is_app_allowed_for_prompt(self, prompt_name: str, app_source: str) -> bool:
        """Check if the app is allowed to access the prompt."""
        if prompt_name not in CLAUDE_CODE_CODEX_ONLY_PROMPTS:
            return True
        return app_source in ALLOWED_APPS_FOR_RESTRICTED

    async def on_list_tools(self, context: MiddlewareContext, call_next):
        """Filter tools during listing based on app source and enabled plugins."""
        # Get all tools first
        result = await call_next(context)

        # Get app source and enabled plugins
        app_source = self._get_app_source(context)
        enabled_plugins = self._get_enabled_plugins()
        provider_type = self._get_ai_now_llm_provider_type()
        if provider_type in ("google_genai", "xai"):
            try:
                from fastmcp.server.dependencies import get_http_headers

                headers = get_http_headers()
                logger.info(
                    "MCP list_tools: provider schema sanitization enabled",
                    app_source=app_source,
                    provider_type=provider_type,
                    has_provider_header=bool(headers.get("x-ainow-llm-provider")),
                )
            except Exception:
                pass

        # Filter tools based on app source AND plugin enablement
        filtered_tools = [
            self._maybe_sanitize_tool_for_provider(tool, provider_type)
            for tool in result
            if self._is_app_allowed_for_tool(tool.name, app_source)
            and self._is_plugin_enabled_for_tool(tool.name, enabled_plugins)
        ]

        if provider_type == "google_genai":
            try:
                # Verify we removed examples from the returned schema
                before = sum(
                    1
                    for t in result
                    if hasattr(t, "inputSchema") and self._schema_has_examples(getattr(t, "inputSchema", None))
                )
                after = sum(
                    1
                    for t in filtered_tools
                    if hasattr(t, "inputSchema") and self._schema_has_examples(getattr(t, "inputSchema", None))
                )
                logger.info(
                    "MCP list_tools: examples stripped for google_genai",
                    tools_total=len(result),
                    tools_returned=len(filtered_tools),
                    tools_with_examples_before=before,
                    tools_with_examples_after=after,
                )
            except Exception:
                pass
        elif provider_type == "xai":
            try:
                before = sum(
                    1
                    for t in result
                    if hasattr(t, "inputSchema")
                    and self._schema_has_xai_risky_fields(getattr(t, "inputSchema", None))
                )
                after = sum(
                    1
                    for t in filtered_tools
                    if hasattr(t, "inputSchema")
                    and self._schema_has_xai_risky_fields(getattr(t, "inputSchema", None))
                )
                logger.info(
                    "MCP list_tools: risky schema fields stripped for xai",
                    tools_total=len(result),
                    tools_returned=len(filtered_tools),
                    tools_with_risky_fields_before=before,
                    tools_with_risky_fields_after=after,
                )
            except Exception:
                pass

        filtered_count = len(result) - len(filtered_tools)
        if filtered_count > 0:
            logger.info(
                "Filtered tools for app",
                app_source=app_source,
                enabled_plugins=list(enabled_plugins) if enabled_plugins else "all",
                total_tools=len(result),
                filtered_tools=filtered_count,
                remaining_tools=len(filtered_tools),
            )

        return filtered_tools

    async def on_list_prompts(self, context: MiddlewareContext, call_next):
        """Filter prompts during listing based on app source."""
        # Get all prompts first
        result = await call_next(context)

        # Get app source
        app_source = self._get_app_source(context)

        # Filter prompts based on app source
        filtered_prompts = [
            prompt for prompt in result
            if self._is_app_allowed_for_prompt(prompt.name, app_source)
        ]

        filtered_count = len(result) - len(filtered_prompts)
        if filtered_count > 0:
            logger.info(
                "Filtered prompts for app",
                app_source=app_source,
                total_prompts=len(result),
                filtered_prompts=filtered_count,
                remaining_prompts=len(filtered_prompts),
            )

        return filtered_prompts

    async def on_call_tool(self, context: MiddlewareContext, call_next):
        """Block execution of filtered tools."""
        tool_name = context.message.name

        app_source = self._get_app_source(context)
        enabled_plugins = self._get_enabled_plugins()

        # Check app-level restriction
        if not self._is_app_allowed_for_tool(tool_name, app_source):
            logger.warning(
                "Blocked tool execution",
                tool_name=tool_name,
                app_source=app_source,
                reason="App not allowed to access this tool",
            )
            raise ToolError(
                f"Tool '{tool_name}' is not available for app '{app_source}'. "
                "This tool is only available for Claude Code and Codex."
            )

        # Check plugin-level restriction
        if not self._is_plugin_enabled_for_tool(tool_name, enabled_plugins):
            logger.warning(
                "Blocked tool execution",
                tool_name=tool_name,
                app_source=app_source,
                enabled_plugins=list(enabled_plugins),
                reason="Plugin not enabled for this tool",
            )
            raise ToolError(
                f"Tool '{tool_name}' requires its plugin to be enabled. "
                "Please enable the plugin in AI-NOW settings."
            )

        return await call_next(context)

    async def on_get_prompt(self, context: MiddlewareContext, call_next):
        """Block execution of filtered prompts."""
        prompt_name = context.message.name

        app_source = self._get_app_source(context)

        if not self._is_app_allowed_for_prompt(prompt_name, app_source):
            logger.warning(
                "Blocked prompt execution",
                prompt_name=prompt_name,
                app_source=app_source,
                reason="App not allowed to access this prompt",
            )
            raise ToolError(
                f"Prompt '{prompt_name}' is not available for app '{app_source}'. "
                "This prompt is only available for Claude Code and Codex."
            )

        return await call_next(context)
