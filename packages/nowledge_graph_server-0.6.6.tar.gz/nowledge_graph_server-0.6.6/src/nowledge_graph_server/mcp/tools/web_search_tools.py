"""Web search tools using ddgs (DuckDuckGo Search) for MCP.

Lightweight web search without browser dependencies.
Mimics kimi-cli's SearchWeb API format for compatibility.
"""

import asyncio
import json
from typing import Annotated

import httpx
import structlog
from fastmcp import FastMCP
from fastmcp.server.dependencies import get_http_headers
from pydantic import Field

from nowledge_graph_server.utils.mcp_utils import get_app_source_from_headers

logger = structlog.get_logger(__name__)

# Try to import ddgs - lightweight DuckDuckGo search
try:
    from ddgs import DDGS
    DDGS_AVAILABLE = True
except ImportError:
    DDGS_AVAILABLE = False
    logger.warning("ddgs not installed - web search will be unavailable")

# Try to import trafilatura for clean text extraction (like kimi)
try:
    import trafilatura
    TRAFILATURA_AVAILABLE = True
except ImportError:
    TRAFILATURA_AVAILABLE = False
    logger.info("trafilatura not installed - using basic HTML extraction")


async def search_duckduckgo(
    query: str,
    max_results: int = 5,
    include_content: bool = False,
    region: str | None = None,
) -> list[dict]:
    """
    Search DuckDuckGo using ddgs library.
    Returns results in kimi-compatible format: title, url, snippet, date, content.

    ddgs.text() returns: [{"title": str, "href": str, "body": str}, ...]

    Args:
        query: Search query text
        max_results: Max number of results
        include_content: Whether to fetch full page content
        region: Region code in format {country}-{language}, e.g. "cn-zh", "us-en", "jp-jp"
    """
    if not DDGS_AVAILABLE:
        return [{"error": "ddgs not installed. Run: pip install ddgs"}]

    results = []

    try:
        # ddgs is sync, run in thread pool
        def do_search() -> list[dict]:
            ddgs = DDGS()
            # Pass region if specified for better localized results
            return list(ddgs.text(query, max_results=max_results, region=region))  # type: ignore[attr-defined]

        search_results = await asyncio.to_thread(do_search)

        for item in search_results:
            result = {
                "title": item.get("title", ""),
                "url": item.get("href", ""),
                "snippet": item.get("body", ""),
                "date": "",  # ddgs doesn't provide date, but we include for API compat
            }

            # Optionally fetch full content for each result
            if include_content and result["url"]:
                try:
                    content_result = await fetch_url_content(result["url"], max_length=3000)
                    if "error" not in content_result:
                        result["content"] = content_result.get("content", "")
                except Exception as e:
                    logger.warning("Failed to fetch content for search result", url=result["url"], error=str(e))
                    result["content"] = ""

            results.append(result)

    except Exception as e:
        logger.error("DuckDuckGo search failed", error=str(e))
        return [{"error": f"Search failed: {str(e)}"}]

    return results


async def fetch_url_content(url: str, max_length: int = 5000) -> dict:
    """
    Fetch URL content and extract clean text.
    Uses trafilatura if available (like kimi), falls back to basic extraction.
    """
    try:
        async with httpx.AsyncClient(follow_redirects=True, timeout=30.0) as client:
            response = await client.get(url, headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
                ),
            })
            response.raise_for_status()

            html = response.text
            content_type = response.headers.get("content-type", "").lower()

            # For plain text/markdown, return as-is
            if content_type.startswith(("text/plain", "text/markdown")):
                content = html[:max_length]
                return {
                    "url": url,
                    "title": "",
                    "content": content,
                    "word_count": len(content.split()) if content else 0,
                    "truncated": len(html) > max_length,
                }

            # Extract text using trafilatura (like kimi) or fallback
            if TRAFILATURA_AVAILABLE:
                extracted = trafilatura.extract(
                    html,
                    include_comments=False,
                    include_tables=True,
                    include_formatting=False,
                    output_format="txt",
                    with_metadata=True,
                )
                if extracted:
                    content = extracted[:max_length]
                    # Try to get title from metadata or HTML
                    import re
                    title_match = re.search(r'<title[^>]*>([^<]+)</title>', html, re.IGNORECASE)
                    title = title_match.group(1).strip() if title_match else ""

                    return {
                        "url": url,
                        "title": title,
                        "content": content,
                        "word_count": len(content.split()) if content else 0,
                        "truncated": len(extracted) > max_length,
                    }

            # Fallback: basic HTML to text conversion
            import re
            # Remove script and style elements
            text = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.DOTALL | re.IGNORECASE)
            text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL | re.IGNORECASE)
            # Remove HTML tags
            text = re.sub(r'<[^>]+>', ' ', text)
            # Clean up whitespace
            text = re.sub(r'\s+', ' ', text).strip()

            # Extract title
            title_match = re.search(r'<title[^>]*>([^<]+)</title>', html, re.IGNORECASE)
            title = title_match.group(1).strip() if title_match else ""

            content = text[:max_length]

            return {
                "url": url,
                "title": title,
                "content": content,
                "word_count": len(content.split()) if content else 0,
                "truncated": len(text) > max_length,
            }

    except httpx.HTTPStatusError as e:
        logger.error("URL fetch HTTP error", url=url, status=e.response.status_code)
        return {"error": f"HTTP {e.response.status_code} error"}
    except Exception as e:
        logger.error("URL fetch failed", url=url, error=str(e))
        return {"error": f"Fetch failed: {str(e)}"}


def _format_search_results_text(results: list[dict]) -> str:
    """Format search results as text (kimi-style output)."""
    lines = []
    for i, result in enumerate(results):
        if i > 0:
            lines.append("---\n")
        lines.append(f"Title: {result.get('title', '')}")
        if result.get('date'):
            lines.append(f"Date: {result['date']}")
        lines.append(f"URL: {result.get('url', '')}")
        lines.append(f"Summary: {result.get('snippet', '')}")
        lines.append("")
        if result.get('content'):
            lines.append(result['content'])
            lines.append("")
    return "\n".join(lines)


def register_web_search_tools(mcp: FastMCP) -> None:
    """Register web search tools with the MCP server.

    Note: We only register web_search, not web_fetch.
    Kimi's built-in FetchURL tool works without API key and is sufficient.
    """

    @mcp.tool(
        name="web_search",
        description="""Search the web using DuckDuckGo.

Use this tool to find current information on any topic. Returns search results
with titles, URLs, summaries, and optionally full page content.

Parameters:
- query: The search query text
- limit: Number of results (1-20, default 5)
- region: Region code for localized results (e.g. "cn-zh" for China/Chinese, "us-en" for US/English)
- include_content: Whether to fetch full page content (expensive, use sparingly)

Note: This is a privacy-respecting search that doesn't require API keys.
When include_content is True, it fetches each result page which is slower
but provides more detailed information.

For best results with non-English queries, set the region parameter to match
the query language (e.g. "cn-zh" for Chinese, "jp-jp" for Japanese).
""",
        tags={"search", "web", "research"},
    )
    async def web_search(
        query: Annotated[
            str,
            Field(
                description="The query text to search for",
                min_length=1,
                max_length=500,
                examples=["Python async programming", "FastAPI OAuth2 tutorial"],
            ),
        ],
        limit: Annotated[
            int,
            Field(
                description=(
                    "The number of results to return. "
                    "Typically you do not need to set this value. "
                    "When the results do not contain what you need, "
                    "you probably want to give a more concrete query."
                ),
                ge=1,
                le=20,
            ),
        ] = 5,
        region: Annotated[
            str | None,
            Field(
                description=(
                    "Region code for localized search results. "
                    "Format: {country}-{language}, e.g. 'cn-zh' (China/Chinese), "
                    "'us-en' (US/English), 'jp-jp' (Japan/Japanese), 'de-de' (Germany/German). "
                    "Set this when the query is in a non-English language for better results."
                ),
                examples=["cn-zh", "us-en", "jp-jp", "de-de", "fr-fr"],
            ),
        ] = None,
        include_content: Annotated[
            bool,
            Field(
                description=(
                    "Whether to include the content of the web pages in the results. "
                    "It can consume a large amount of tokens when this is set to True. "
                    "You should avoid enabling this when `limit` is set to a large value."
                ),
            ),
        ] = False,
    ) -> dict:
        """Search the web and return results in kimi-compatible format."""
        # Log the request
        app_source = "unknown"
        try:
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
        except Exception:
            app_source = "mcp_generic"

        logger.info(
            "MCP_REQUEST",
            method="web_search",
            app=app_source,
            request=json.dumps({
                "query": query,
                "limit": limit,
                "region": region,
                "include_content": include_content,
            }),
        )

        if not DDGS_AVAILABLE:
            error_response = {
                "status": "error",
                "message": "Web search unavailable - ddgs not installed. Run: pip install ddgs",
                "results": [],
            }
            logger.info("MCP_RESPONSE", method="web_search", app=app_source, response=json.dumps(error_response))
            return error_response

        try:
            results = await search_duckduckgo(query, limit, include_content, region)

            # Check for errors
            if results and "error" in results[0]:
                error_response = {
                    "status": "error",
                    "message": results[0]["error"],
                    "results": [],
                }
                logger.info("MCP_RESPONSE", method="web_search", app=app_source, response=json.dumps(error_response))
                return error_response

            # Format results text (kimi-style)
            formatted_text = _format_search_results_text(results)

            response = {
                "status": "success",
                "query": query,
                "total_results": len(results),
                "results": results,
                "formatted": formatted_text,  # Pre-formatted text for easy display
            }

            logger.info(
                "MCP_RESPONSE",
                method="web_search",
                app=app_source,
                response=json.dumps({
                    "status": "success",
                    "query": query,
                    "total_results": len(results),
                    "include_content": include_content,
                }),
            )
            return response

        except Exception as e:
            logger.error("Web search failed", query=query, error=str(e))
            error_response = {
                "status": "error",
                "message": f"Search failed: {str(e)}",
                "results": [],
            }
            logger.info("MCP_RESPONSE", method="web_search", app=app_source, response=json.dumps(error_response))
            return error_response

    # Note: web_fetch is NOT registered here.
    # Kimi's built-in FetchURL tool works without API key and handles URL fetching.
