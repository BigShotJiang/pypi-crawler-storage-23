"""Graph operation tools for MCP.

Exposes EVOLVES chain traversal, memory neighbor queries,
crystal listing, graph statistics, and interactive graph exploration
to external AI agents and MCP Apps.
"""

import json
from pathlib import Path
from typing import Annotated, Optional

import structlog
from fastmcp import FastMCP
from fastmcp.server.dependencies import get_http_headers
from mcp.types import ToolAnnotations
from pydantic import Field

from nowledge_graph_server.core.evolves_operations import EvolvesOperations
from nowledge_graph_server.core.graph_operations import GraphOperations
from nowledge_graph_server.core.memory_operations import MemoryOperations
from nowledge_graph_server.utils.mcp_utils import get_app_source_from_headers

logger = structlog.get_logger(__name__)


def register_graph_tools(
    mcp: FastMCP,
    evolves_ops: EvolvesOperations,
    graph_ops: Optional[GraphOperations] = None,
    memory_ops: Optional["MemoryOperations"] = None,
) -> None:
    """Register graph operation tools with the MCP server."""

    @mcp.tool(
        name="memory_evolves_chain",
        description="""Get the full version history (EVOLVES chain) for a memory.

Returns the chain of memories connected by EVOLVES relationships, showing how
knowledge evolved over time. Each link has a content_relation:
- replaces: newer info makes older obsolete
- enriches: newer adds detail to older
- confirms: same info from different source
- challenges: contradictory info

The chain is ordered oldest → newest. The 'position' field shows where the
queried memory sits in the chain (0-indexed).

Use this to understand knowledge evolution and find the latest version of a fact.""",
    )
    async def memory_evolves_chain(
        memory_id: Annotated[str, Field(
            description="Memory ID to get the version chain for",
            min_length=1,
        )],
        max_depth: Annotated[int, Field(
            description="Maximum chain traversal depth (default 10)",
            ge=1,
            le=50,
        )] = 10,
    ) -> dict:
        app_source = "unknown"
        try:
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
        except Exception:
            app_source = "mcp_generic"
        request_data = {"memory_id": memory_id, "max_depth": max_depth}
        logger.info(
            "MCP_REQUEST",
            method="memory_evolves_chain",
            app=app_source,
            request=json.dumps(request_data, separators=(",", ":"), ensure_ascii=False),
        )
        try:
            result = await evolves_ops.get_evolves_chain(memory_id, max_depth)
        except Exception as e:
            response = {"error": str(e)}
            logger.info("MCP_RESPONSE", method="memory_evolves_chain", app=app_source, response=json.dumps(response))
            raise
        logger.info(
            "MCP_RESPONSE",
            method="memory_evolves_chain",
            app=app_source,
            response=json.dumps(result, separators=(",", ":"), ensure_ascii=False, default=str),
        )
        return result

    @mcp.tool(
        name="memory_neighbors",
        description="""Get graph neighbors of a memory, including EVOLVES chains,
entity mentions, and crystal relationships.

Edge types:
- EVOLVES: Version chain connections (older → newer)
- MENTIONS: Entities mentioned in this memory
- CRYSTALLIZED_FROM: Crystal ↔ source memory links

Use this to understand a memory's context in the knowledge graph.""",
    )
    async def memory_neighbors(
        memory_id: Annotated[str, Field(
            description="Memory ID to explore",
            min_length=1,
        )],
        edge_types: Annotated[Optional[str], Field(
            description="Comma-separated edge types to include (default: all). "
                        "Options: EVOLVES, MENTIONS, CRYSTALLIZED_FROM",
        )] = None,
        depth: Annotated[int, Field(
            description="Traversal depth 1-3 (default 1)",
            ge=1,
            le=3,
        )] = 1,
    ) -> dict:
        app_source = "unknown"
        try:
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
        except Exception:
            app_source = "mcp_generic"
        request_data = {"memory_id": memory_id, "edge_types": edge_types, "depth": depth}
        logger.info(
            "MCP_REQUEST",
            method="memory_neighbors",
            app=app_source,
            request=json.dumps(request_data, separators=(",", ":"), ensure_ascii=False),
        )
        types = None
        if edge_types:
            types = [t.strip().upper() for t in edge_types.split(",")]
        try:
            result = await evolves_ops.get_memory_neighbors(memory_id, types, depth)
        except Exception as e:
            response = {"error": str(e)}
            logger.info("MCP_RESPONSE", method="memory_neighbors", app=app_source, response=json.dumps(response))
            raise
        logger.info(
            "MCP_RESPONSE",
            method="memory_neighbors",
            app=app_source,
            response=json.dumps(result, separators=(",", ":"), ensure_ascii=False, default=str),
        )
        return result

    @mcp.tool(
        name="list_crystals",
        description="""List crystallized knowledge — consolidated, high-quality
knowledge units synthesized from multiple source memories.

Crystals are context-independent summaries that capture essential knowledge.
Each crystal shows its source memories and their contribution weights.

Use this to find synthesized knowledge on topics you're interested in.""",
    )
    async def list_crystals(
        limit: Annotated[int, Field(
            description="Maximum crystals to return (default 20)",
            ge=1,
            le=100,
        )] = 20,
        offset: Annotated[int, Field(
            description="Skip first N crystals (for pagination)",
            ge=0,
        )] = 0,
    ) -> dict:
        app_source = "unknown"
        try:
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
        except Exception:
            app_source = "mcp_generic"
        request_data = {"limit": limit, "offset": offset}
        logger.info(
            "MCP_REQUEST",
            method="list_crystals",
            app=app_source,
            request=json.dumps(request_data, separators=(",", ":"), ensure_ascii=False),
        )
        try:
            result = await evolves_ops.list_crystals(limit, offset)
        except Exception as e:
            response = {"error": str(e)}
            logger.info("MCP_RESPONSE", method="list_crystals", app=app_source, response=json.dumps(response))
            raise
        logger.info(
            "MCP_RESPONSE",
            method="list_crystals",
            app=app_source,
            response=json.dumps(result, separators=(",", ":"), ensure_ascii=False, default=str),
        )
        return result

    @mcp.tool(
        name="graph_stats",
        description="""Get knowledge graph statistics: counts of memories, entities,
EVOLVES edges, crystals, and unit type distribution.

Use this to understand the current state of the knowledge graph.""",
    )
    async def graph_stats() -> dict:
        app_source = "unknown"
        try:
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
        except Exception:
            app_source = "mcp_generic"
        logger.info("MCP_REQUEST", method="graph_stats", app=app_source, request="{}")
        try:
            result = await evolves_ops.get_graph_stats()
        except Exception as e:
            response = {"error": str(e)}
            logger.info("MCP_RESPONSE", method="graph_stats", app=app_source, response=json.dumps(response))
            raise
        logger.info(
            "MCP_RESPONSE",
            method="graph_stats",
            app=app_source,
            response=json.dumps(result, separators=(",", ":"), ensure_ascii=False, default=str),
        )
        return result

    # ── Community query tools ────────────────────────────────────────

    if graph_ops is not None:
        @mcp.tool(
            name="list_communities",
            description="""List knowledge communities — clusters of related entities
detected by the Louvain community detection algorithm.

Each community has a name, AI-generated summary describing its theme,
and a member count showing how many entities belong to it.

Use this to discover the main themes and topic clusters in the knowledge graph.
Great for: "what are my main knowledge areas?", "what themes connect my
memories?", "summarize my most connected topics".""",
        )
        async def list_communities(
            limit: Annotated[int, Field(
                description="Maximum communities to return (default 20)",
                ge=1,
                le=50,
            )] = 20,
        ) -> dict:
            app_source = "unknown"
            try:
                headers = get_http_headers()
                app_source = get_app_source_from_headers(headers)
            except Exception:
                app_source = "mcp_generic"
            request_data = {"limit": limit}
            logger.info(
                "MCP_REQUEST",
                method="list_communities",
                app=app_source,
                request=json.dumps(request_data, separators=(",", ":"), ensure_ascii=False),
            )
            conn = graph_ops.kuzu_client.conn

            result = conn.execute(
                """
                MATCH (c:Community)
                WHERE c.ai_summary IS NOT NULL AND c.ai_summary <> ''
                RETURN c.id, c.community_id, c.name, c.description, c.ai_summary, c.member_count
                ORDER BY c.member_count DESC
                LIMIT $limit
                """,
                {"limit": limit},
            )

            communities = []
            while result.has_next():
                row = result.get_next()
                communities.append({
                    "id": row[0],
                    "community_id": row[1],
                    "name": row[2],
                    "description": row[3] or "",
                    "summary": row[4] or "",
                    "member_count": row[5] or 0,
                })

            if not communities:
                response = {
                    "communities": [],
                    "total": 0,
                    "message": "No communities detected yet. Community detection runs periodically to discover theme clusters across your knowledge graph.",
                }
                logger.info(
                    "MCP_RESPONSE",
                    method="list_communities",
                    app=app_source,
                    response=json.dumps(response, separators=(",", ":"), ensure_ascii=False),
                )
                return response

            response = {"communities": communities, "total": len(communities)}
            logger.info(
                "MCP_RESPONSE",
                method="list_communities",
                app=app_source,
                response=json.dumps(response, separators=(",", ":"), ensure_ascii=False, default=str),
            )
            return response

        @mcp.tool(
            name="get_community_details",
            description="""Get detailed information about a specific community,
including its member entities and connected memories.

Pass a community ID (UUID from list_communities results) to see which entities
belong to this theme cluster and which memories reference them.

Use after list_communities to drill into a specific theme.""",
        )
        async def get_community_details(
            community_id: Annotated[str, Field(
                description="Community ID (UUID from list_communities)",
                min_length=1,
            )],
            limit: Annotated[int, Field(
                description="Maximum entities to return (default 20)",
                ge=1,
                le=50,
            )] = 20,
        ) -> dict:
            app_source = "unknown"
            try:
                headers = get_http_headers()
                app_source = get_app_source_from_headers(headers)
            except Exception:
                app_source = "mcp_generic"
            request_data = {"community_id": community_id, "limit": limit}
            logger.info(
                "MCP_REQUEST",
                method="get_community_details",
                app=app_source,
                request=json.dumps(request_data, separators=(",", ":"), ensure_ascii=False),
            )
            conn = graph_ops.kuzu_client.conn

            # Step 1: Look up community by UUID
            result = conn.execute(
                """
                MATCH (c:Community)
                WHERE c.id = $cid
                RETURN c.id, c.community_id, c.name, c.description, c.ai_summary, c.member_count
                """,
                {"cid": community_id},
            )

            if not result.has_next():
                response = {"error": f"Community not found: {community_id}"}
                logger.info("MCP_RESPONSE", method="get_community_details", app=app_source, response=json.dumps(response))
                return response

            row = result.get_next()
            community = {
                "id": row[0],
                "community_id": row[1],
                "name": row[2],
                "description": row[3] or "",
                "summary": row[4] or "",
                "member_count": row[5] or 0,
            }
            louvain_id = row[1]

            # Step 2: Find member entities
            result = conn.execute(
                """
                MATCH (e:Entity)
                WHERE e.community_id = $louvain_id
                OPTIONAL MATCH (m:Memory)-[:MENTIONS]->(e)
                RETURN e.id, e.name, e.entity_type, COUNT(m) AS memory_count
                ORDER BY memory_count DESC
                LIMIT $limit
                """,
                {"louvain_id": louvain_id, "limit": limit},
            )

            entities = []
            while result.has_next():
                erow = result.get_next()
                entities.append({
                    "id": erow[0],
                    "name": erow[1],
                    "entity_type": erow[2],
                    "memory_count": erow[3],
                })

            # Step 3: Sample memories
            result = conn.execute(
                """
                MATCH (e:Entity {community_id: $louvain_id})<-[:MENTIONS]-(m:Memory)
                WHERE m.is_crystal = false
                WITH m, COUNT(e) AS entity_count
                RETURN m.id, m.title, m.content, m.unit_type
                ORDER BY entity_count DESC, m.importance DESC
                LIMIT 5
                """,
                {"louvain_id": louvain_id},
            )

            sample_memories = []
            while result.has_next():
                mrow = result.get_next()
                sample_memories.append({
                    "id": mrow[0],
                    "title": mrow[1],
                    "content_preview": (mrow[2] or "")[:200],
                    "unit_type": mrow[3],
                })

            response = {
                "community": community,
                "entities": entities,
                "sample_memories": sample_memories,
                "entity_count": len(entities),
                "memory_count": len(sample_memories),
            }
            logger.info(
                "MCP_RESPONSE",
                method="get_community_details",
                app=app_source,
                response=json.dumps(response, separators=(",", ":"), ensure_ascii=False, default=str),
            )
            return response

    # ── MCP Apps: Interactive Graph Explorer ──────────────────────────
    # Resource is always registered (just static HTML), but explore_graph
    # tool requires graph_ops for neighbor expansion.

    _MCP_APP_HTML = Path(__file__).parent.parent.parent / "static" / "mcp-app" / "graph-explorer.html"

    # SEP-1865 requires mime_type "text/html;profile=mcp-app" for MCP Apps.
    # FastMCP's Pydantic regex on mime_type rejects semicolons, so we register
    # with "text/html" (passes validation) then patch the attribute afterward.
    # This works because Pydantic's validate_assignment defaults to False.

    @mcp.resource(
        "ui://nowledge/graph-explorer.html",
        name="Knowledge Graph Explorer",
        description="Interactive knowledge graph visualization",
        mime_type="text/html",
    )
    async def graph_explorer_resource() -> str:
        """Serve the bundled MiniGraph single-file HTML."""
        if not _MCP_APP_HTML.exists():
            return "<html><body><p>MCP App not built yet. Run: npm run build:mcp-app</p></body></html>"
        return _MCP_APP_HTML.read_text(encoding="utf-8")

    # Patch mime_type to SEP-1865 compliant value (bypasses Pydantic regex)
    graph_explorer_resource.mime_type = "text/html;profile=mcp-app"

    if graph_ops is not None:
        @mcp.tool(
            name="explore_graph",
            description="""Explore the knowledge graph around one or more memories.

Returns nodes and edges in a visualization-ready format. When used with an
MCP host that supports Apps, an interactive graph renders inline.

Use after memory_search to visualize relationships between search results.
Pass comma-separated memory IDs from search results.

Example: explore_graph(memory_ids="mem_abc123,mem_def456")""",
            tags={"graph", "visualization"},
            annotations=ToolAnnotations(readOnlyHint=True, openWorldHint=True),
            meta={"ui": {"resourceUri": "ui://nowledge/graph-explorer.html"}},
        )
        async def explore_graph(
            memory_ids: Annotated[str, Field(
                description="Comma-separated memory IDs to explore",
                min_length=1,
            )],
            depth: Annotated[int, Field(
                description="Traversal depth 1-3 (default 1)",
                ge=1,
                le=3,
            )] = 1,
            limit: Annotated[int, Field(
                description="Maximum neighbors per node (default 15)",
                ge=1,
                le=50,
            )] = 15,
        ) -> dict:
            app_source = "unknown"
            try:
                headers = get_http_headers()
                app_source = get_app_source_from_headers(headers)
            except Exception:
                app_source = "mcp_generic"
            ids = [mid.strip() for mid in memory_ids.split(",") if mid.strip()]
            if not ids:
                response = {"nodes": [], "edges": []}
                logger.info(
                    "MCP_REQUEST",
                    method="explore_graph",
                    app=app_source,
                    request=json.dumps({"memory_ids": memory_ids, "depth": depth, "limit": limit}, separators=(",", ":"), ensure_ascii=False),
                )
                logger.info("MCP_RESPONSE", method="explore_graph", app=app_source, response=json.dumps(response))
                return response

            request_data = {"memory_ids": memory_ids, "depth": depth, "limit": limit}
            logger.info(
                "MCP_REQUEST",
                method="explore_graph",
                app=app_source,
                request=json.dumps(request_data, separators=(",", ":"), ensure_ascii=False),
            )

            # Normalize backend node_type to MiniGraph frontend types.
            # Backend returns: "memory", "entity", "Source", "Community", etc.
            # MiniGraph expects: "memory", "entity", "crystal", "source"
            def _normalize_node_type(raw_type: str) -> str:
                t = raw_type.lower()
                if t in ("memory", "entity", "crystal", "source"):
                    return t
                if t in ("community", "thread", "label", "unknown"):
                    return t  # MiniGraph renders these as generic nodes
                return "memory"

            # Expand neighbors for each seed node
            node_map: dict[str, dict] = {}
            edge_keys: set[str] = set()
            all_edges: list[dict] = []

            for seed_id in ids:
                try:
                    result = await graph_ops.expand_neighbors(seed_id, depth=depth, limit=limit)
                except Exception as e:
                    logger.warning("expand_neighbors failed for node", node_id=seed_id, error=str(e))
                    continue

                # Add center node (expand_neighbors skips it)
                if seed_id not in node_map:
                    node_map[seed_id] = {
                        "id": seed_id,
                        "label": seed_id[:8],
                        "type": "memory",
                    }

                # Add neighbor nodes with normalized types
                for n in result.get("neighbors", []):
                    nid = n.get("id")
                    if nid and nid not in node_map:
                        raw_type = n.get("node_type", "memory")
                        # Detect crystals: memory nodes with is_crystal flag
                        metadata = n.get("metadata", {})
                        if raw_type == "memory" and n.get("node_subtype") == "crystal":
                            normalized_type = "crystal"
                        else:
                            normalized_type = _normalize_node_type(raw_type)

                        node_map[nid] = {
                            "id": nid,
                            "label": n.get("label", nid[:8]),
                            "type": normalized_type,
                            "importance": n.get("importance"),
                            "community": n.get("community"),
                            "event_start": metadata.get("event_start"),
                            "created_at": metadata.get("created_at"),
                            "content": metadata.get("content", "")[:200],
                        }

                # Add edges
                for e in result.get("edges", []):
                    key = f"{e['source']}-{e['target']}-{e.get('edge_type', '')}"
                    if key not in edge_keys:
                        edge_keys.add(key)
                        all_edges.append({
                            "source": e["source"],
                            "target": e["target"],
                            "type": e.get("edge_type", "RELATES_TO"),
                        })

            # Enrich center nodes with real labels from memory details.
            # expand_neighbors doesn't return the center node, so seed nodes
            # start with truncated ID labels. Fetch their details to get titles.
            if memory_ops:
                for seed_id in ids:
                    if seed_id in node_map and node_map[seed_id]["label"] == seed_id[:8]:
                        try:
                            mem = await memory_ops.get_memory_by_id(seed_id)
                            if mem:
                                node_map[seed_id]["label"] = mem.title or (mem.content[:50] + "...")
                                node_map[seed_id]["importance"] = mem.importance
                                if mem.is_crystal:
                                    node_map[seed_id]["type"] = "crystal"
                        except Exception as e:
                            logger.debug("Failed to enrich seed node label", seed_id=seed_id, error=str(e))

            # Filter edges to only reference existing nodes
            node_ids = set(node_map.keys())
            valid_edges = [e for e in all_edges if e["source"] in node_ids and e["target"] in node_ids]

            response = {
                "nodes": list(node_map.values()),
                "edges": valid_edges,
            }
            logger.info(
                "MCP_RESPONSE",
                method="explore_graph",
                app=app_source,
                response=json.dumps(response, separators=(",", ":"), ensure_ascii=False, default=str),
            )
            return response
