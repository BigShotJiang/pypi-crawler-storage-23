"""Working Memory tools for MCP.

Exposes read access to the Working Memory file (~/ai-now/memory.md)
so external AI agents (Claude Code, Codex, etc.) can understand
the user's current knowledge context.
"""

import json
from datetime import datetime, timezone
from typing import Annotated, Optional

import structlog
from fastmcp import FastMCP
from pydantic import Field

from nowledge_graph_server.agent.paths import (
    get_working_memory_path,
    get_working_memory_archive_path,
)

logger = structlog.get_logger(__name__)


def register_working_memory_tools(mcp: FastMCP) -> None:
    """Register Working Memory tools with the MCP server."""

    @mcp.tool(
        name="read_working_memory",
        description=(
            "Read today's Working Memory — a daily focus surface at ~/ai-now/memory.md "
            "showing what topics are active, what needs attention, and recent activity. "
            "Call this to understand the user's current knowledge context. "
            "The Working Memory is updated each morning by the Knowledge Agent "
            "and contains focus areas, unresolved flags, and a briefing summary "
            "with nowledgemem://memory/{id} deeplinks to referenced memories. "
            "Connected agents can also write directly to ~/ai-now/memory.md to update it."
        ),
    )
    async def read_working_memory(
        date: Annotated[Optional[str], Field(
            description="YYYY-MM-DD. Defaults to today. Use a past date to read archived Working Memory.",
        )] = None,
    ) -> dict:
        today_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        if date and date != today_str:
            try:
                target = datetime.strptime(date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
            except ValueError:
                return {"error": f"Invalid date format: {date}. Use YYYY-MM-DD."}
            path = get_working_memory_archive_path(target)
        else:
            path = get_working_memory_path()
            date = today_str

        if not path.exists():
            return {
                "exists": False,
                "content": "",
                "date": date,
            }

        try:
            content = path.read_text(encoding="utf-8")
            if len(content) > 6000:
                content = content[:6000] + "\n\n... (truncated)"

            return {
                "exists": True,
                "content": content,
                "date": date,
            }
        except Exception as e:
            logger.error("read_working_memory failed", error=str(e))
            return {"error": str(e)}
