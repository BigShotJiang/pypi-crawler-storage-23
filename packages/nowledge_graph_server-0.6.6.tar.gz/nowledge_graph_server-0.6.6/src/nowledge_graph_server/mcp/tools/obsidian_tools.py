"""Obsidian CLI tools for MCP.

This module integrates with Obsidian's built-in CLI instead of in-process vault indexing.
It keeps the same MCP tool surface (obsidian_search, obsidian_get_note), while using
Obsidian as the source of truth for multi-vault queries.
"""

import asyncio
import json
import os
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path
from typing import Annotated, Optional

import structlog
from fastmcp import FastMCP
from fastmcp.server.dependencies import get_http_headers
from mcp.types import ToolAnnotations
from pydantic import BaseModel, Field

from nowledge_graph_server.utils.mcp_utils import get_app_source_from_headers

logger = structlog.get_logger(__name__)


# =============================================================================
# Pydantic Response Models
# =============================================================================

class ObsidianSearchResult(BaseModel):
    """A single Obsidian search result."""

    path: str
    name: str
    # Backward-compatible fields for older clients/prompts.
    note_name: str = ""
    file_path: str = ""
    snippet: str = ""
    tags: list[str] = Field(default_factory=list)
    backlinks_count: int = 0
    wikilinks_count: int = 0
    score: float | None = None


class ObsidianSearchResponse(BaseModel):
    """Response for obsidian_search tool."""

    status: str
    query: str
    search_type: str
    count: int
    total_found: int
    results: list[ObsidianSearchResult]
    vault_path: Optional[str] = None
    error: str | None = None


class ObsidianNoteResponse(BaseModel):
    """Response for obsidian_get_note tool."""

    status: str
    note_name: str
    file_path: str
    content: str
    frontmatter: dict = Field(default_factory=dict)
    # Backward-compatible aliases for older clients/prompts.
    front_matter: dict = Field(default_factory=dict)
    tags: list[str] = Field(default_factory=list)
    links: list[str] = Field(default_factory=list)
    wikilinks: list[str] = Field(default_factory=list)
    backlinks: list[str] = Field(default_factory=list)
    created: str = ""
    modified: str = ""
    creation_date: str = ""
    modification_date: str = ""
    error: str | None = None


# =============================================================================
# CLI Discovery + Invocation
# =============================================================================

_OBSIDIAN_CLI_PATH_CACHE: str | None = None
_OBSIDIAN_VAULTS_CACHE: list[tuple[str, str]] = []


def _is_windows() -> bool:
    return sys.platform.startswith("win")


def _is_macos() -> bool:
    return sys.platform == "darwin"


def _normalize_path_for_compare(value: str) -> str:
    """Normalize a path string for cross-call comparisons."""

    if not value:
        return ""
    try:
        return str(Path(value).expanduser().resolve())
    except (OSError, RuntimeError):
        return str(Path(value).expanduser().absolute())


def _looks_like_path(value: str) -> bool:
    """Heuristic to tell whether user passed a path vs. a vault name."""

    if not value:
        return False
    return (
        "/" in value
        or "\\" in value
        or value.startswith("~")
        or bool(re.match(r"^[A-Za-z]:[\\/]", value))
    )


def _candidate_obsidian_cli_paths() -> list[str]:
    """Get ordered candidate paths for Obsidian CLI across platforms."""

    candidates: list[str] = []

    # Explicit override (useful for advanced users and debugging)
    for key in ("OBSIDIAN_CLI_PATH", "OBSIDIAN_PATH"):
        v = os.environ.get(key)
        if v:
            candidates.append(v)

    # PATH lookups (may be stale in long-running desktop process)
    for exe in ("obsidian", "Obsidian", "obsidian.exe", "Obsidian.exe"):
        p = shutil.which(exe)
        if p:
            candidates.append(p)

    # Platform-specific known locations (handles stale PATH after install)
    if _is_macos():
        candidates.extend(
            [
                "/Applications/Obsidian.app/Contents/MacOS/obsidian",
                str(Path.home() / "Applications/Obsidian.app/Contents/MacOS/obsidian"),
            ]
        )
    elif _is_windows():
        local_app_data = os.environ.get("LOCALAPPDATA", "")
        program_files = os.environ.get("ProgramFiles", "")
        program_files_x86 = os.environ.get("ProgramFiles(x86)", "")
        user_profile = os.environ.get("USERPROFILE", "")
        candidates.extend(
            [
                str(Path(local_app_data) / "Programs/Obsidian/Obsidian.exe") if local_app_data else "",
                str(Path(user_profile) / "AppData/Local/Programs/Obsidian/Obsidian.exe") if user_profile else "",
                str(Path(program_files) / "Obsidian/Obsidian.exe") if program_files else "",
                str(Path(program_files_x86) / "Obsidian/Obsidian.exe") if program_files_x86 else "",
            ]
        )
    else:
        candidates.extend(
            [
                "/usr/bin/obsidian",
                "/usr/local/bin/obsidian",
                "/opt/Obsidian/obsidian",
                "/snap/bin/obsidian",
                "/var/lib/flatpak/exports/bin/md.obsidian.Obsidian",
            ]
        )

    # Dedupe while preserving order
    seen: set[str] = set()
    ordered: list[str] = []
    for c in candidates:
        if not c:
            continue
        if c not in seen:
            seen.add(c)
            ordered.append(c)

    return ordered


def _resolve_obsidian_cli_path(force_refresh: bool = False) -> str:
    """Resolve Obsidian CLI executable path.

    We intentionally check known install paths (not only PATH) to support
    desktop processes that were launched before PATH updates.
    """

    global _OBSIDIAN_CLI_PATH_CACHE

    if not force_refresh and _OBSIDIAN_CLI_PATH_CACHE:
        cached = Path(_OBSIDIAN_CLI_PATH_CACHE)
        if cached.exists():
            return _OBSIDIAN_CLI_PATH_CACHE

    for candidate in _candidate_obsidian_cli_paths():
        p = Path(candidate).expanduser()
        if p.exists() and p.is_file():
            _OBSIDIAN_CLI_PATH_CACHE = str(p)
            return _OBSIDIAN_CLI_PATH_CACHE

    raise RuntimeError(
        "Obsidian CLI executable not found. "
        "Enable Obsidian CLI in Settings > General and ensure Obsidian is installed."
    )


async def _run_obsidian_cli(
    command: str,
    args: list[str] | None = None,
    *,
    vault_name: str | None = None,
    timeout: float = 20.0,
) -> str:
    """Run Obsidian CLI command and return stdout text."""

    cli_path = _resolve_obsidian_cli_path()

    cmd: list[str] = [cli_path]
    if vault_name:
        cmd.append(f"vault={vault_name}")
    cmd.append(command)
    if args:
        cmd.extend(args)

    process = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )

    try:
        stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        process.kill()
        await process.communicate()
        raise RuntimeError(f"Obsidian CLI command timed out after {timeout:.0f}s: {command}")

    out = stdout.decode("utf-8", errors="replace").strip()
    err = stderr.decode("utf-8", errors="replace").strip()

    if process.returncode != 0:
        raise RuntimeError(err or out or f"Obsidian CLI failed (exit {process.returncode})")

    return out


# =============================================================================
# Vault + Output Helpers
# =============================================================================

async def _list_vaults() -> list[tuple[str, str]]:
    """Return list of (vault_name, vault_path) from Obsidian CLI."""
    global _OBSIDIAN_VAULTS_CACHE

    last_error: Exception | None = None
    for attempt in range(3):
        try:
            output = await _run_obsidian_cli("vaults", ["verbose"], timeout=15.0)
            vaults: list[tuple[str, str]] = []
            for raw_line in output.splitlines():
                line = raw_line.strip()
                if not line:
                    continue
                if "\t" not in line:
                    continue
                name, path = line.split("\t", 1)
                name = name.strip()
                path = path.strip()
                if name and path:
                    vaults.append((name, path))

            if vaults:
                _OBSIDIAN_VAULTS_CACHE = vaults
                return vaults

            if _OBSIDIAN_VAULTS_CACHE:
                logger.warning(
                    "Obsidian CLI returned empty vault list, using cached vaults",
                    cached_vaults=len(_OBSIDIAN_VAULTS_CACHE),
                    attempt=attempt + 1,
                )
                return _OBSIDIAN_VAULTS_CACHE
        except Exception as ex:
            last_error = ex
            if _OBSIDIAN_VAULTS_CACHE:
                logger.warning(
                    "Obsidian vault list lookup failed, using cached vaults",
                    error=str(ex),
                    cached_vaults=len(_OBSIDIAN_VAULTS_CACHE),
                    attempt=attempt + 1,
                )
                return _OBSIDIAN_VAULTS_CACHE

        # Small retry backoff for transient CLI readiness issues.
        if attempt < 2:
            await asyncio.sleep(0.35)

    if last_error is not None:
        raise RuntimeError(f"Failed to list Obsidian vaults: {last_error}")
    return []


async def _resolve_vault_name(vault_path: str) -> str:
    """Resolve user-provided vault path/name to CLI-required vault name."""

    requested = vault_path.strip()
    if not requested:
        raise RuntimeError("vault_path is required")

    vaults = await _list_vaults()
    if not vaults:
        raise RuntimeError(
            "No vaults found in Obsidian CLI. Ensure your vault is available in Obsidian and retry."
        )

    # 1) Exact name match
    for name, _path in vaults:
        if requested == name:
            return name

    # 1b) Case-insensitive name match
    requested_casefold = requested.casefold()
    for name, _path in vaults:
        if requested_casefold == name.casefold():
            return name

    # 2) Path match
    requested_norm = _normalize_path_for_compare(requested)
    for name, p in vaults:
        if requested_norm and requested_norm == _normalize_path_for_compare(p):
            return name

    # 3) If user passed a plain folder name, map to matching vault directory name
    if not _looks_like_path(requested):
        for name, p in vaults:
            if Path(p).name == requested:
                return name
        for name, p in vaults:
            if Path(p).name.casefold() == requested_casefold:
                return name

    available = ", ".join(name for name, _ in vaults[:10])
    raise RuntimeError(
        f"Vault '{vault_path}' not found in Obsidian CLI vault list. "
        f"Available vaults: {available}"
    )


def _is_vault_not_found_error(error_text: str) -> bool:
    """Whether an error likely indicates unresolved vault identity."""

    normalized = (error_text or "").strip().lower()
    return (
        "vault not found" in normalized
        or "no vaults found" in normalized
        or "unknown vault" in normalized
    )


async def _run_obsidian_cli_for_vault(
    vault_path: str,
    command: str,
    args: list[str] | None = None,
    *,
    timeout: float = 20.0,
) -> tuple[str, str]:
    """Run a vault-scoped CLI command with robust vault resolution.

    Strategy:
    1) If vault_path already looks like a vault *name* (not filesystem path),
       try it directly to avoid `vaults` lookup latency/timeouts.
    2) On "vault not found" style errors, resolve via vault list and retry.
    """

    requested = (vault_path or "").strip()
    if not requested:
        raise RuntimeError("vault_path is required")

    direct_allowed = not _looks_like_path(requested)
    direct_error: Exception | None = None

    if direct_allowed:
        try:
            output = await _run_obsidian_cli(
                command,
                args,
                vault_name=requested,
                timeout=timeout,
            )
            return output, requested
        except Exception as ex:
            direct_error = ex
            if not _is_vault_not_found_error(str(ex)):
                raise
            logger.debug(
                "Direct vault name command failed, retrying via vault list resolution",
                vault=requested,
                command=command,
                error=str(ex),
            )

    resolved = await _resolve_vault_name(vault_path)
    try:
        output = await _run_obsidian_cli(
            command,
            args,
            vault_name=resolved,
            timeout=timeout,
        )
        return output, resolved
    except Exception as ex:
        if direct_error is not None:
            raise RuntimeError(
                f"{ex} (direct vault='{requested}' also failed: {direct_error})"
            )
        raise


def _parse_json_output(text: str, default):
    """Parse JSON output safely, returning default on empty output."""

    stripped = text.strip()
    if not stripped:
        return default
    return json.loads(stripped)


def _is_cli_empty_notice(text: str) -> bool:
    """Whether CLI output is an informational empty-result notice."""

    normalized = text.strip().lower()
    return normalized in {
        "no frontmatter found.",
        "no backlinks found.",
        "no links found.",
        "no properties found.",
    }


def _parse_json_output_lenient(text: str, default, *, context: str):
    """Parse JSON output, falling back to default for plain-text CLI notices."""

    stripped = text.strip()
    if not stripped or _is_cli_empty_notice(stripped):
        return default
    try:
        return json.loads(stripped)
    except json.JSONDecodeError:
        logger.warning(
            "Obsidian CLI returned non-JSON output, using fallback",
            context=context,
            output_preview=stripped[:160],
        )
        return default


def _parse_tsv_key_values(text: str) -> dict[str, str]:
    """Parse key-value TSV output: key\tvalue."""

    out: dict[str, str] = {}
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or "\t" not in line:
            continue
        key, value = line.split("\t", 1)
        out[key.strip()] = value.strip()
    return out


def _to_iso_from_ms(raw: str) -> str:
    """Convert epoch milliseconds string to ISO datetime, fallback to raw."""

    if not raw:
        return ""
    try:
        ts = int(raw)
        return datetime.fromtimestamp(ts / 1000).isoformat()
    except Exception:
        return raw


def _strip_md_extension(path: str) -> str:
    """Get display name from markdown path."""

    name = Path(path).name
    if name.lower().endswith(".md"):
        return name[:-3]
    return name


async def _resolve_vault_fs_path(vault_path: str) -> str:
    """Resolve user-provided vault path/name to filesystem path."""

    requested = (vault_path or "").strip()
    if requested and _looks_like_path(requested):
        try:
            p = Path(requested).expanduser().resolve()
        except Exception:
            p = Path(requested).expanduser()
        if p.exists() and p.is_dir():
            return str(p)

    vault_name = await _resolve_vault_name(vault_path)
    vaults = await _list_vaults()
    for name, path in vaults:
        if name == vault_name:
            return path
    raise RuntimeError(f"Vault '{vault_path}' not found in Obsidian CLI vault list.")


def _filesystem_text_search(vault_root: str, query: str, limit: int) -> list[ObsidianSearchResult]:
    """Fallback text search by scanning markdown files directly.

    Used only when Obsidian CLI text search returns no results.
    """

    root = Path(vault_root)
    if not root.exists() or not root.is_dir():
        return []

    query_folded = query.casefold()
    results: list[ObsidianSearchResult] = []

    for file_path in root.rglob("*.md"):
        if len(results) >= limit:
            break
        if not file_path.is_file():
            continue
        if ".obsidian" in file_path.parts:
            continue

        try:
            content = file_path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue

        pos = content.casefold().find(query_folded)
        if pos < 0:
            continue

        line_no = content.count("\n", 0, pos) + 1
        snippet_start = max(0, pos - 80)
        snippet_end = min(len(content), pos + len(query) + 120)
        snippet = content[snippet_start:snippet_end].replace("\n", " ").strip()
        if snippet_start > 0:
            snippet = f"...{snippet}"
        if snippet_end < len(content):
            snippet = f"{snippet}..."

        try:
            rel_path = str(file_path.relative_to(root)).replace("\\", "/")
        except Exception:
            rel_path = file_path.name

        results.append(
            ObsidianSearchResult(
                path=rel_path,
                name=_strip_md_extension(rel_path),
                note_name=_strip_md_extension(rel_path),
                file_path=rel_path,
                snippet=f"L{line_no}: {snippet}",
            )
        )

    return results


# =============================================================================
# MCP Tool Registration
# =============================================================================

def register_obsidian_tools(mcp: FastMCP) -> None:
    """Register Obsidian CLI-based tools with MCP."""

    @mcp.tool(
        name="obsidian_search",
        description="""Search notes in an Obsidian vault via Obsidian CLI. READ-ONLY.

Search types:
- text: full-text search with context snippets
- tags: search notes by tag text (e.g., "project" or "#project")
- title: search by note file title/path

Requirements:
- Obsidian desktop app installed
- Command line interface enabled in Obsidian Settings > General

Parameters:
- vault_path: Vault path OR vault name (multi-vault safe)
- query: Search query
- search_type: 'text', 'tags', or 'title'
- limit: Max results (default 20)
- refresh: Reserved for compatibility (no-op in CLI mode)""",
        tags={"obsidian", "search", "notes", "readonly"},
        annotations=ToolAnnotations(
            readOnlyHint=True,
            idempotentHint=True,
            openWorldHint=False,
        ),
    )
    async def obsidian_search(
        vault_path: Annotated[
            str,
            Field(
                description="Path or name of the Obsidian vault",
            ),
        ],
        query: Annotated[
            str,
            Field(
                description="Search query",
            ),
        ],
        search_type: Annotated[
            str,
            Field(
                description="Search type: 'text', 'tags', or 'title'",
            ),
        ] = "text",
        limit: Annotated[
            int,
            Field(description="Maximum results to return"),
        ] = 20,
        refresh: Annotated[
            bool,
            Field(description="Reserved for compatibility (no-op in CLI mode)"),
        ] = False,
    ) -> dict:
        """Search Obsidian notes via CLI."""

        app_source = "unknown"
        try:
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
        except Exception:
            app_source = "mcp_generic"

        request_data = {
            "vault_path": vault_path,
            "query": query,
            "search_type": search_type,
            "limit": limit,
            "refresh": refresh,
        }
        logger.info(
            "MCP_REQUEST",
            method="obsidian_search",
            app=app_source,
            request=json.dumps(request_data, separators=(",", ":"), ensure_ascii=False),
        )

        try:
            search_type_normalized = (search_type or "text").strip().lower()
            if search_type_normalized not in {"text", "tags", "title"}:
                raise RuntimeError("search_type must be one of: text, tags, title")

            q = query.strip()
            if not q:
                raise RuntimeError("query cannot be empty")

            results: list[ObsidianSearchResult] = []
            vault_name = ""

            if search_type_normalized == "text":
                raw, vault_name = await _run_obsidian_cli_for_vault(
                    vault_path,
                    "search:context",
                    [f"query={q}", f"limit={limit}", "format=json"],
                )
                entries = _parse_json_output(raw, [])
                for entry in entries[:limit]:
                    path = str(entry.get("file", "")).strip()
                    if not path:
                        continue
                    matches = entry.get("matches") or []
                    snippet = ""
                    if matches:
                        first = matches[0] or {}
                        line = first.get("line")
                        text = str(first.get("text", "")).strip()
                        snippet = f"L{line}: {text}" if line is not None and text else text
                    results.append(
                        ObsidianSearchResult(
                            path=path,
                            name=_strip_md_extension(path),
                            note_name=_strip_md_extension(path),
                            file_path=path,
                            snippet=snippet,
                        )
                    )

                if not results:
                    # Some vaults may have empty Obsidian content index state.
                    # Fallback keeps search usable without requiring manual reindex first.
                    try:
                        resolved_vault_path = await _resolve_vault_fs_path(vault_path)
                        fallback_results = await asyncio.to_thread(
                            _filesystem_text_search,
                            resolved_vault_path,
                            q,
                            limit,
                        )
                        if fallback_results:
                            logger.info(
                                "Obsidian text search fallback used",
                                vault_name=vault_name,
                                vault_path=resolved_vault_path,
                                query=q,
                                fallback_results=len(fallback_results),
                            )
                            results = fallback_results
                    except Exception as ex:
                        logger.warning(
                            "Obsidian text search fallback skipped",
                            vault_path=vault_path,
                            query=q,
                            error=str(ex),
                        )

            elif search_type_normalized == "tags":
                tag = q.lstrip("#")
                if not tag:
                    raise RuntimeError("tag query cannot be empty")
                raw, vault_name = await _run_obsidian_cli_for_vault(
                    vault_path,
                    "search:context",
                    [f"query=#{tag}", f"limit={limit}", "format=json"],
                )
                entries = _parse_json_output(raw, [])
                for entry in entries[:limit]:
                    path = str(entry.get("file", "")).strip()
                    if not path:
                        continue
                    matches = entry.get("matches") or []
                    snippet = ""
                    if matches:
                        first = matches[0] or {}
                        snippet = str(first.get("text", "")).strip()
                    results.append(
                        ObsidianSearchResult(
                            path=path,
                            name=_strip_md_extension(path),
                            note_name=_strip_md_extension(path),
                            file_path=path,
                            snippet=snippet,
                            tags=[f"#{tag}"],
                        )
                    )

            else:  # title
                raw, vault_name = await _run_obsidian_cli_for_vault(
                    vault_path,
                    "files",
                    ["ext=md"],
                )
                query_lower = q.lower()
                matched_paths: list[str] = []
                for raw_line in raw.splitlines():
                    path = raw_line.strip()
                    if not path:
                        continue
                    name = _strip_md_extension(path)
                    if query_lower in name.lower() or query_lower in path.lower():
                        matched_paths.append(path)
                    if len(matched_paths) >= limit:
                        break

                for path in matched_paths:
                    results.append(
                        ObsidianSearchResult(
                            path=path,
                            name=_strip_md_extension(path),
                            note_name=_strip_md_extension(path),
                            file_path=path,
                            snippet=f"Title match: {_strip_md_extension(path)}",
                        )
                    )

            response = ObsidianSearchResponse(
                status="success" if results else "no_results",
                query=q,
                search_type=search_type_normalized,
                count=len(results),
                total_found=len(results),
                results=results,
                vault_path=vault_path,
            )

            logger.info(
                "MCP_RESPONSE",
                method="obsidian_search",
                app=app_source,
                response=response.model_dump_json(),
            )
            return response.model_dump()

        except Exception as e:
            error_response = ObsidianSearchResponse(
                status="error",
                query=query,
                search_type=search_type,
                count=0,
                total_found=0,
                results=[],
                vault_path=vault_path,
                error=str(e),
            )
            logger.error(
                "MCP_RESPONSE",
                method="obsidian_search",
                app=app_source,
                error=str(e),
                response=error_response.model_dump_json(),
            )
            return error_response.model_dump()

    @mcp.tool(
        name="obsidian_get_note",
        description="""Read a specific note from an Obsidian vault via Obsidian CLI. READ-ONLY.

Requirements:
- Obsidian desktop app installed
- Command line interface enabled in Obsidian Settings > General

Parameters:
- vault_path: Vault path OR vault name
- note_name: Note name or note path
- content_type: Reserved for compatibility (CLI returns source markdown)""",
        tags={"obsidian", "note", "content", "readonly"},
        annotations=ToolAnnotations(
            readOnlyHint=True,
            idempotentHint=True,
            openWorldHint=False,
        ),
    )
    async def obsidian_get_note(
        vault_path: Annotated[
            str,
            Field(
                description="Path or name of the Obsidian vault",
            ),
        ],
        note_name: Annotated[
            str,
            Field(
                description="Note name or path",
            ),
        ],
        content_type: Annotated[
            str,
            Field(
                description="Reserved for compatibility (source/readable)",
            ),
        ] = "readable",
    ) -> dict:
        """Get a note with metadata via Obsidian CLI."""

        app_source = "unknown"
        try:
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
        except Exception:
            app_source = "mcp_generic"

        request_data = {
            "vault_path": vault_path,
            "note_name": note_name,
            "content_type": content_type,
        }
        logger.info(
            "MCP_REQUEST",
            method="obsidian_get_note",
            app=app_source,
            request=json.dumps(request_data, separators=(",", ":"), ensure_ascii=False),
        )

        try:
            note_ref = note_name.strip()
            if not note_ref:
                raise RuntimeError("note_name cannot be empty")

            file_meta_text = ""
            resolved_path = ""
            resolved_vault_name = ""

            # Try path lookup first for path-like refs, then file-name lookup.
            lookup_args_list: list[list[str]] = []
            if _looks_like_path(note_ref) or note_ref.lower().endswith(".md"):
                lookup_args_list.append([f"path={note_ref}"])
            lookup_args_list.append([f"file={note_ref}"])
            if note_ref.lower().endswith(".md"):
                lookup_args_list.append([f"file={Path(note_ref).stem}"])

            last_error: Exception | None = None
            for lookup_args in lookup_args_list:
                try:
                    file_meta_text, resolved_vault_name = await _run_obsidian_cli_for_vault(
                        vault_path,
                        "file",
                        lookup_args,
                    )
                    file_meta = _parse_tsv_key_values(file_meta_text)
                    resolved_path = file_meta.get("path", "").strip()
                    if resolved_path:
                        break
                except Exception as ex:
                    last_error = ex

            if not resolved_path:
                if last_error:
                    raise RuntimeError(f"Note '{note_name}' not found: {last_error}")
                raise RuntimeError(f"Note '{note_name}' not found")
            if not resolved_vault_name:
                raise RuntimeError(f"Failed to resolve Obsidian vault for '{vault_path}'")

            file_meta = _parse_tsv_key_values(file_meta_text)
            content = await _run_obsidian_cli(
                "read",
                [f"path={resolved_path}"],
                vault_name=resolved_vault_name,
            )

            properties_text = await _run_obsidian_cli(
                "properties",
                [f"path={resolved_path}", "format=json"],
                vault_name=resolved_vault_name,
            )
            frontmatter_raw = _parse_json_output_lenient(
                properties_text,
                {},
                context="properties",
            )
            if isinstance(frontmatter_raw, dict):
                frontmatter: dict = frontmatter_raw
            else:
                # Some CLI builds may return key-value plain text instead of JSON.
                frontmatter = _parse_tsv_key_values(properties_text)

            raw_tags = frontmatter.get("tags", [])
            tags: list[str] = []
            if isinstance(raw_tags, list):
                for t in raw_tags:
                    if t is None:
                        continue
                    tag = str(t).strip()
                    if not tag:
                        continue
                    tags.append(tag if tag.startswith("#") else f"#{tag}")

            links_text = await _run_obsidian_cli(
                "links",
                [f"path={resolved_path}"],
                vault_name=resolved_vault_name,
            )
            links = [line.strip() for line in links_text.splitlines() if line.strip()]

            backlinks_text = await _run_obsidian_cli(
                "backlinks",
                [f"path={resolved_path}", "format=json"],
                vault_name=resolved_vault_name,
            )
            backlinks_raw = _parse_json_output_lenient(
                backlinks_text,
                [],
                context="backlinks",
            )
            backlinks: list[str] = []
            if isinstance(backlinks_raw, list):
                for item in backlinks_raw:
                    if isinstance(item, dict):
                        file_value = str(item.get("file", "")).strip()
                        if file_value:
                            backlinks.append(file_value)
                    elif isinstance(item, str):
                        v = item.strip()
                        if v:
                            backlinks.append(v)
            elif not _is_cli_empty_notice(backlinks_text):
                # Fallback for plain-text line output.
                for line in backlinks_text.splitlines():
                    v = line.strip()
                    if v and not _is_cli_empty_notice(v):
                        backlinks.append(v)

            response = ObsidianNoteResponse(
                status="success",
                note_name=file_meta.get("name", _strip_md_extension(resolved_path)),
                file_path=resolved_path,
                content=content,
                frontmatter=frontmatter,
                front_matter=frontmatter,
                tags=tags,
                links=links,
                wikilinks=links,
                backlinks=backlinks,
                created=_to_iso_from_ms(file_meta.get("created", "")),
                modified=_to_iso_from_ms(file_meta.get("modified", "")),
                creation_date=_to_iso_from_ms(file_meta.get("created", "")),
                modification_date=_to_iso_from_ms(file_meta.get("modified", "")),
            )

            logger.info(
                "MCP_RESPONSE",
                method="obsidian_get_note",
                app=app_source,
                response=response.model_dump_json(),
            )
            return response.model_dump()

        except Exception as e:
            error_response = ObsidianNoteResponse(
                status="error",
                note_name=note_name,
                file_path="",
                content="",
                error=str(e),
            )
            logger.error(
                "MCP_RESPONSE",
                method="obsidian_get_note",
                app=app_source,
                error=str(e),
                response=error_response.model_dump_json(),
            )
            return error_response.model_dump()
