"""Apple Notes integration tools for MCP.

Provides read-only access to Apple Notes via AppleScript (macOS only).

Key features:
- macOS only: Uses osascript for AppleScript execution
- Read-only: Search, list, and read notes (no creation/modification)
- iCloud: Operates on the iCloud account in Notes.app
- Async: Non-blocking subprocess execution
"""

import asyncio
import json
import sys
from typing import Annotated

import structlog
from fastmcp import FastMCP
from fastmcp.server.dependencies import get_http_headers
from mcp.types import ToolAnnotations
from pydantic import BaseModel, Field

from nowledge_graph_server.utils.mcp_utils import get_app_source_from_headers

logger = structlog.get_logger(__name__)

IS_MACOS = sys.platform == "darwin"


# ============================================================================
# Pydantic Response Models
# ============================================================================

class AppleNoteSearchResult(BaseModel):
    """A single Apple Notes search result."""
    note_id: str
    name: str
    folder: str
    matched_keyword: str


class AppleNotesSearchResponse(BaseModel):
    """Response for apple_notes_search tool."""
    status: str
    query: str
    total_found: int
    results: list[AppleNoteSearchResult]
    error: str | None = None


class AppleNoteItem(BaseModel):
    """A single note in a list."""
    note_id: str
    name: str


class AppleNotesListResponse(BaseModel):
    """Response for apple_notes_list tool."""
    status: str
    total_notes: int
    notes: list[AppleNoteItem]
    error: str | None = None


class AppleNoteContentResponse(BaseModel):
    """Response for apple_notes_get_note tool."""
    status: str
    name: str
    note_id: str
    body: str
    creation_date: str
    modification_date: str
    error: str | None = None


# ============================================================================
# AppleScript Execution
# ============================================================================

async def _run_applescript(script: str, timeout: float = 30.0) -> str:
    """Execute AppleScript via osascript and return stdout.

    Raises RuntimeError on non-zero exit, timeout, or if not on macOS.
    """
    if not IS_MACOS:
        raise RuntimeError(
            "Apple Notes tools are only available on macOS. "
            "This system is not running macOS."
        )

    process = await asyncio.create_subprocess_exec(
        "osascript", "-e", script,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout, stderr = await asyncio.wait_for(
            process.communicate(), timeout=timeout
        )
    except asyncio.TimeoutError:
        process.kill()
        await process.communicate()  # reap the process
        raise RuntimeError(
            f"Apple Notes operation timed out after {timeout:.0f}s. "
            "This can happen with very large notes or complex searches."
        )

    if process.returncode != 0:
        raw_err = stderr.decode().strip()
        raise RuntimeError(_friendly_error(raw_err))

    return stdout.decode().strip()


def _friendly_error(raw: str) -> str:
    """Convert raw AppleScript error messages to user-friendly text."""
    low = raw.lower()
    if "can't get note id" in low:
        return "Note not found. The note may have been deleted or the ID is invalid."
    if "can't get account" in low:
        return "iCloud account not found. Please ensure Notes.app is signed in to iCloud."
    return f"Apple Notes error: {raw}"


def _extract_primary_key(full_note_id: str) -> str:
    """Extract primary key from a Core Data ID.

    e.g. "x-coredata://UUID/ICNote/p1234" -> "p1234"
    """
    parts = full_note_id.split("/")
    return parts[-1] if parts else full_note_id


def _escape_applescript_string(value: str) -> str:
    """Escape a Python string for safe AppleScript string literal usage."""
    return value.replace("\\", "\\\\").replace('"', '\\"')


async def _get_store_uuid() -> str:
    """Get the Core Data store UUID dynamically from a sample note."""
    script = """
    tell application "Notes"
        try
            set primaryAccount to account "iCloud"
            set sampleNote to note 1 of primaryAccount
            set sampleId to id of sampleNote as string
            return sampleId
        on error errMsg
            return "error:" & errMsg
        end try
    end tell
    """
    result = await _run_applescript(script)
    if result.startswith("error:"):
        raise RuntimeError(f"Could not get store UUID: {result[6:]}")
    # Format: x-coredata://UUID/ICNote/pXXX
    return result.split("//")[1].split("/")[0]


# ============================================================================
# Tool Registration
# ============================================================================

def register_apple_notes_tools(mcp: FastMCP) -> None:
    """Register Apple Notes tools with the MCP server.

    Tools provided:
    - apple_notes_search: Search notes by keywords
    - apple_notes_list: List all notes
    - apple_notes_get_note: Read a note by ID

    All tools are READ-ONLY and macOS-only (requires Notes.app with iCloud).
    """

    @mcp.tool(
        name="apple_notes_search",
        description="""Search notes in Apple Notes by keywords. READ-ONLY, macOS only.

Searches note content in your iCloud Notes account for matching keywords.

Parameters:
- query: Comma-separated keywords to search for (e.g., "meeting, project")
- limit: Max results (default 20)

Returns matching notes with note_id, name, folder, and matched keyword.
Use apple_notes_get_note with the returned note_id and name to read full content.""",
        tags={"apple-notes", "search", "notes", "readonly"},
        annotations=ToolAnnotations(
            readOnlyHint=True,
            idempotentHint=True,
            openWorldHint=False,
        ),
    )
    async def apple_notes_search(
        query: Annotated[
            str,
            Field(
                description="Comma-separated keywords to search for",
            ),
        ],
        limit: Annotated[
            int,
            Field(description="Maximum results to return"),
        ] = 20,
    ) -> dict:
        """Search Apple Notes by keywords."""
        app_source = "unknown"
        try:
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
        except Exception:
            app_source = "mcp_generic"

        request_data = {"query": query, "limit": limit}
        logger.info(
            "MCP_REQUEST",
            method="apple_notes_search",
            app=app_source,
            request=json.dumps(request_data, separators=(",", ":"), ensure_ascii=False),
        )

        try:
            # Parse keywords from comma-separated query
            keywords = [k.strip() for k in query.split(",") if k.strip()]
            if not keywords:
                response = AppleNotesSearchResponse(
                    status="error",
                    query=query,
                    total_found=0,
                    results=[],
                    error="No valid keywords provided",
                )
                return response.model_dump()

            # Build AppleScript for keyword search
            escaped_keywords = [_escape_applescript_string(kw) for kw in keywords]
            keywords_str = ", ".join([f'"{kw}"' for kw in escaped_keywords])
            script = f"""
            tell application "Notes"
                try
                    set primaryAccount to account "iCloud"
                    set keywords to {{{keywords_str}}}
                    set foundNotes to ""
                    set noteCount to 0

                    repeat with currentNote in every note of primaryAccount
                        try
                            set noteName to name of currentNote as string
                            set noteID to id of currentNote as string
                            set noteBody to body of currentNote as string

                            set noteFolder to "Notes"
                            try
                                set noteFolder to name of container of currentNote as string
                            on error
                                set noteFolder to "Notes"
                            end try

                            set foundKeyword to ""
                            repeat with keyword in keywords
                                set keywordText to keyword as string
                                ignoring case
                                    if noteBody contains keywordText or noteName contains keywordText then
                                        set foundKeyword to keywordText
                                        exit repeat
                                    end if
                                end ignoring
                            end repeat

                            if foundKeyword is not "" then
                                set rowText to noteID & "|||" & noteName & "|||" & noteFolder & "|||" & foundKeyword
                                if foundNotes is "" then
                                    set foundNotes to rowText
                                else
                                    set foundNotes to foundNotes & linefeed & rowText
                                end if
                                set noteCount to noteCount + 1
                                if noteCount >= {limit} then exit repeat
                            end if
                        on error
                            -- Skip inaccessible notes (attachments, corrupt content, etc.)
                        end try
                    end repeat

                    return foundNotes
                on error errMsg
                    return "error:" & errMsg
                end try
            end tell
            """

            result = await _run_applescript(script)

            if result.startswith("error:"):
                raise RuntimeError(result[6:])

            # Parse result lines: full_id|||name|||folder|||keyword
            notes: list[AppleNoteSearchResult] = []
            if result and result != "{}":
                for raw_line in result.splitlines():
                    line = raw_line.strip()
                    if not line:
                        continue
                    parts = line.split("|||", 3)
                    if len(parts) != 4:
                        continue

                    full_id = parts[0].strip().strip('"')
                    name = parts[1].strip().strip('"')
                    folder = parts[2].strip().strip('"')
                    keyword = parts[3].strip().strip('"')
                    short_id = _extract_primary_key(full_id)
                    if short_id and name and not short_id.startswith("item"):
                        notes.append(AppleNoteSearchResult(
                            note_id=short_id,
                            name=name,
                            folder=folder,
                            matched_keyword=keyword,
                        ))

            response = AppleNotesSearchResponse(
                status="ok",
                query=query,
                total_found=len(notes),
                results=notes,
            )
            result_dict = response.model_dump()

            logger.info(
                "MCP_RESPONSE",
                method="apple_notes_search",
                app=app_source,
                response=response.model_dump_json(),
            )
            return result_dict

        except Exception as e:
            error_response = AppleNotesSearchResponse(
                status="error",
                query=query,
                total_found=0,
                results=[],
                error=str(e),
            )
            logger.error(
                "MCP_RESPONSE",
                method="apple_notes_search",
                app=app_source,
                error=str(e),
                response=error_response.model_dump_json(),
            )
            return error_response.model_dump()

    @mcp.tool(
        name="apple_notes_list",
        description="""List notes in Apple Notes. READ-ONLY, macOS only.

Lists notes from your iCloud Notes account with their IDs and names.

Parameters:
- limit: Max notes to return (default 50)

Returns a list of notes.
Use apple_notes_get_note with a returned note_id and name to read full content.""",
        tags={"apple-notes", "list", "notes", "readonly"},
        annotations=ToolAnnotations(
            readOnlyHint=True,
            idempotentHint=True,
            openWorldHint=False,
        ),
    )
    async def apple_notes_list(
        limit: Annotated[
            int,
            Field(description="Maximum notes to return"),
        ] = 50,
    ) -> dict:
        """List notes in Apple Notes."""
        app_source = "unknown"
        try:
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
        except Exception:
            app_source = "mcp_generic"

        logger.info("MCP_REQUEST", method="apple_notes_list", app=app_source, limit=limit)

        try:
            script = f"""
            tell application "Notes"
                set outputText to ""
                set noteCount to 0
                set iCloudAccount to account "iCloud"
                repeat with currentFolder in folders of iCloudAccount
                    repeat with currentNote in notes of currentFolder
                        try
                            set noteName to name of currentNote
                            set noteID to id of currentNote
                            set noteInfo to ("Name: " & noteName & " | ID: " & noteID)
                            if outputText is "" then
                                set outputText to noteInfo
                            else
                                set outputText to outputText & return & noteInfo
                            end if
                            set noteCount to noteCount + 1
                            if noteCount >= {limit} then exit repeat
                        on error
                            -- Skip inaccessible notes
                        end try
                    end repeat
                    if noteCount >= {limit} then exit repeat
                end repeat
                return outputText
            end tell
            """

            result = await _run_applescript(script)

            notes: list[AppleNoteItem] = []
            if result.strip():
                for line in result.strip().split("\r"):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        parts = dict(
                            item.strip().split(": ", 1)
                            for item in line.split(" | ")
                        )
                        full_id = parts["ID"]
                        notes.append(AppleNoteItem(
                            note_id=_extract_primary_key(full_id),
                            name=parts["Name"],
                        ))
                    except (ValueError, KeyError):
                        continue

            response = AppleNotesListResponse(
                status="ok",
                total_notes=len(notes),
                notes=notes,
            )
            result_dict = response.model_dump()

            logger.info(
                "MCP_RESPONSE",
                method="apple_notes_list",
                app=app_source,
                response=response.model_dump_json(),
            )
            return result_dict

        except Exception as e:
            error_response = AppleNotesListResponse(
                status="error",
                total_notes=0,
                notes=[],
                error=str(e),
            )
            logger.error(
                "MCP_RESPONSE",
                method="apple_notes_list",
                app=app_source,
                error=str(e),
                response=error_response.model_dump_json(),
            )
            return error_response.model_dump()

    @mcp.tool(
        name="apple_notes_get_note",
        description="""Read a note from Apple Notes by ID. READ-ONLY, macOS only.

Reads the full content of a specific note using its primary key ID.
The note_name parameter is used for verification to ensure the correct note is read.

Parameters:
- note_id: Primary key ID (e.g., "p1234") from search or list results
- note_name: Note title for verification (must match the actual note name)

Returns full note content with metadata (creation date, modification date).""",
        tags={"apple-notes", "read", "notes", "readonly"},
        annotations=ToolAnnotations(
            readOnlyHint=True,
            idempotentHint=True,
            openWorldHint=False,
        ),
    )
    async def apple_notes_get_note(
        note_id: Annotated[
            str,
            Field(
                description="Primary key ID of the note (e.g., 'p1234')",
            ),
        ],
        note_name: Annotated[
            str,
            Field(
                description="Note title for verification",
            ),
        ],
    ) -> dict:
        """Read a note from Apple Notes by ID with name verification."""
        app_source = "unknown"
        try:
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
        except Exception:
            app_source = "mcp_generic"

        request_data = {"note_id": note_id, "note_name": note_name}
        logger.info(
            "MCP_REQUEST",
            method="apple_notes_get_note",
            app=app_source,
            request=json.dumps(request_data, separators=(",", ":"), ensure_ascii=False),
        )

        try:
            # Get store UUID dynamically
            store_uuid = await _get_store_uuid()
            full_note_id = f"x-coredata://{store_uuid}/ICNote/{note_id}"

            # Escape note_name for AppleScript string
            escaped_name = note_name.replace('\\', '\\\\').replace('"', '\\"')

            script = f"""
            tell application "Notes"
                try
                    set primaryAccount to account "iCloud"
                    set targetNote to note id "{full_note_id}"

                    set actualNoteName to name of targetNote

                    if actualNoteName is not equal to "{escaped_name}" then
                        return "error:Note name mismatch. Expected: {escaped_name}, Actual: " & actualNoteName
                    end if

                    set noteId to id of targetNote
                    set noteBody to body of targetNote
                    set creationDate to creation date of targetNote
                    set modificationDate to modification date of targetNote

                    return "success:" & actualNoteName & "|||" & noteId & "|||" & noteBody & "|||" & creationDate & "|||" & modificationDate
                on error errMsg
                    return "error:" & errMsg
                end try
            end tell
            """

            result = await _run_applescript(script)

            if result.startswith("error:"):
                error_msg = result[6:]
                raise RuntimeError(error_msg)

            if not result.startswith("success:"):
                raise RuntimeError(f"Unexpected result format: {result[:100]}")

            # Parse: success:name|||full_id|||body|||creation_date|||modification_date
            content = result[8:]  # Remove "success:" prefix
            parts = content.split("|||")

            if len(parts) >= 5:
                primary_key = _extract_primary_key(parts[1])
                response = AppleNoteContentResponse(
                    status="ok",
                    name=parts[0],
                    note_id=primary_key,
                    body=parts[2],
                    creation_date=parts[3],
                    modification_date=parts[4],
                )
            else:
                response = AppleNoteContentResponse(
                    status="ok",
                    name=note_name,
                    note_id=note_id,
                    body=content,
                    creation_date="unknown",
                    modification_date="unknown",
                )

            result_dict = response.model_dump()

            logger.info(
                "MCP_RESPONSE",
                method="apple_notes_get_note",
                app=app_source,
                response=response.model_dump_json(),
            )
            return result_dict

        except Exception as e:
            error_response = AppleNoteContentResponse(
                status="error",
                name=note_name,
                note_id=note_id,
                body=f"Error: {e}",
                creation_date="",
                modification_date="",
                error=str(e),
            )
            logger.error(
                "MCP_RESPONSE",
                method="apple_notes_get_note",
                app=app_source,
                error=str(e),
                response=error_response.model_dump_json(),
            )
            return error_response.model_dump()
