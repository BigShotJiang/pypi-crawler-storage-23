"""Thread tools for MCP - includes search, fetch, and persistence."""

import json
import os
from pathlib import Path
from typing import Annotated, Any

import structlog
from fastmcp import FastMCP
from fastmcp.exceptions import ToolError
from fastmcp.server.dependencies import get_http_headers
from mcp.types import ToolAnnotations
from pydantic import Field

from nowledge_graph_server.core.thread_operations import ThreadOperations
from nowledge_graph_server.tools.thread_file_handler import ThreadFileHandler
from nowledge_graph_server.utils.mcp_utils import get_app_source_from_headers
from nowledge_graph_server.utils.progress_logger import log_data_change

logger = structlog.get_logger(__name__)


# Pydantic response models for thread tools
from pydantic import BaseModel


class ThreadSearchResultMessage(BaseModel):
    """A matched message within a thread."""

    message_id: str
    message_index: int
    role: str
    snippet: str
    match_score: float


class ThreadSearchResultItem(BaseModel):
    """A thread search result with matched messages."""

    thread_id: str
    title: str | None
    summary: str | None
    message_count: int
    source: str | None
    relevance_score: float
    matched_messages: list[ThreadSearchResultMessage]
    total_matches: int


class ThreadSearchResponse(BaseModel):
    """Response from thread search."""

    status: str
    threads: list[ThreadSearchResultItem]
    total_found: int
    query: str
    mode: str


class ThreadMessageInfo(BaseModel):
    """Detailed message information."""

    id: str
    role: str
    content: str
    order_index: int
    timestamp: str | None = None


class ThreadFetchMessagesResponse(BaseModel):
    """Response from fetching thread messages."""

    status: str
    thread_id: str
    title: str | None
    summary: str | None
    source: str | None
    message_count: int
    messages: list[ThreadMessageInfo]


def register_thread_tools(
    mcp: FastMCP,
    thread_operations: ThreadOperations,
) -> None:
    """Register thread persistence tools with the MCP server.

    NOTE: These tools are restricted to Claude Code and Codex clients only.
    """

    @mcp.tool(
        name="thread_persist",
        description="""Save coding session as conversation thread. Supports Claude Code and Codex.

Auto-detects session from project_path. Creates new or appends to existing thread (deduplicates).
persist_mode: 'current' (most recent) | 'all' (all project sessions, Claude Code only)""",
        tags={"thread", "conversation", "claude-code", "codex", "persist"},
        annotations=ToolAnnotations(
            readOnlyHint=False,
            destructiveHint=False,
            idempotentHint=True,  # Same session can be re-persisted safely
            openWorldHint=False,
        ),
    )
    async def thread_persist(  # type: ignore
        client: Annotated[
            str,
            Field(
                description="Client type: 'claude-code' or 'codex'",
                pattern=r"^(claude-code|codex)$",
                examples=["claude-code"],
            ),
        ],
        project_path: Annotated[
            str,
            Field(
                description="Project working directory path",
                min_length=1,
                examples=["/Users/username/code/project"],
            ),
        ],
        session_id: Annotated[
            str | None,
            Field(
                description="Session ID (Codex only, optional)",
                examples=["019a0fc1-c03f-7ac1-bc4d-7116cdfc6464"],
            ),
        ] = None,
        persist_mode: Annotated[
            str,
            Field(
                description="Mode: 'current' (recent session) or 'all' (all sessions)",
                pattern=r"^(current|all)$",
                examples=["current"],
            ),
        ] = "current",
        summary: Annotated[
            str | None,
            Field(
                description="Brief session summary (1-2 sentences)",
                max_length=500,
                examples=["Discussion about implementing responsive layouts"],
            ),
        ] = None,
        truncate_large_content: Annotated[
            bool,
            Field(
                description="Truncate large tool results >10KB",
            ),
        ] = False,
    ) -> dict[str, Any]:
        """Persist thread with intelligent create/append logic."""
        # Detect source from MCP client headers
        app_source = "claude-code"
        headers = {}
        try:
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
        except:
            logger.warning(
                "Failed to get app source from headers", headers=str(headers)
            )
            app_source = "mcp_generic"
        logger.info(
            "MCP_REQUEST",
            method="thread_persist",
            app=app_source,
            request=json.dumps(
                {
                    "app_header": headers,
                    "project_path": project_path,
                    "client": client,
                    "persist_mode": persist_mode,
                    "has_summary": summary is not None,
                    "truncate_large_content": truncate_large_content,
                },
                separators=(",", ":"),
                ensure_ascii=False,
            ),
        )
        # Input validation - use ToolError for client input errors
        if client not in ["claude-code", "codex"]:
            raise ToolError(
                f"Unsupported client: {client}. Supported: claude-code, codex"
            )
        # Log the request
        request_data = {
            "client": client,
            "project_path": project_path,
            "persist_mode": persist_mode,
            "has_summary": summary is not None,
            "truncate_large_content": truncate_large_content,
        }
        logger.info(
            "MCP_REQUEST",
            method="thread_persist",
            app=app_source,
            request=json.dumps(request_data, separators=(",", ":"), ensure_ascii=False),
        )
        try:
            if not thread_operations:
                error_response = {
                    "status": "error",
                    "error": "Thread operations not initialized",
                }
                logger.info(
                    "MCP_RESPONSE",
                    method="thread_persist",
                    app=app_source,
                    response=json.dumps(error_response, separators=(",", ":")),
                )
                return error_response

            file_handler = ThreadFileHandler(thread_operations)  # type: ignore
            results: list[dict[str, Any]] = []

            # Branch based on client type
            if client == "claude-code":
                # Step 1: Encode project path to find Claude session directory
                # /Users/weyl/dev/project -> -Users-weyl-dev-project
                encoded_path = project_path.replace(os.sep, "-")
                if encoded_path.startswith("-"):
                    encoded_path = encoded_path[1:]  # Remove leading dash if exists
                encoded_path = f"-{encoded_path}"

                # Step 2: Find Claude sessions directory
                claude_base = Path.home() / ".claude" / "projects" / encoded_path

                if not claude_base.exists() or not claude_base.is_dir():
                    error_response = {
                        "status": "error",
                        "error": f"Claude Code session directory not found for project: {project_path}",
                        "expected_path": str(claude_base),
                        "hint": "Make sure Claude Code has created sessions for this project",
                    }
                    logger.info(
                        "MCP_RESPONSE",
                        method="thread_persist",
                        app=app_source,
                        response=json.dumps(error_response, separators=(",", ":")),
                    )
                    return error_response

                # Step 3: Find all .jsonl session files and filter for valid conversations
                all_session_files = list(claude_base.glob("*.jsonl"))

                # Filter and score sessions
                claude_valid_sessions: list[dict[str, Any]] = []
                import time
                from datetime import datetime

                current_time = time.time()

                for session_file in all_session_files:
                    try:
                        # Quick scan to determine if this is a real conversation
                        with open(session_file) as f:
                            lines = f.readlines()

                        # Count user and assistant messages (excluding warmup and meta messages)
                        user_messages = 0
                        assistant_messages = 0
                        last_message_timestamp = None
                        last_message_time = None

                        for line in lines:
                            try:
                                event = json.loads(line.strip())
                                event_type = event.get("type")

                                # Skip metadata events
                                if event_type in ["file-history-snapshot", "summary"]:
                                    continue

                                # Track the last message timestamp to identify active session
                                if event_type in ["user", "assistant"]:
                                    timestamp_str = event.get("timestamp")
                                    if timestamp_str:
                                        try:
                                            # Parse ISO timestamp
                                            dt = datetime.fromisoformat(
                                                timestamp_str.replace("Z", "+00:00")
                                            )
                                            timestamp_unix = dt.timestamp()
                                            if (
                                                last_message_time is None
                                                or timestamp_unix > last_message_time
                                            ):
                                                last_message_timestamp = timestamp_str
                                                last_message_time = timestamp_unix
                                        except (ValueError, AttributeError):
                                            pass

                                # Check for user/assistant messages
                                if event_type == "user":
                                    msg_content = event.get("message", {}).get(
                                        "content", ""
                                    )
                                    # Skip warmup and meta messages
                                    if msg_content not in [
                                        "Warmup",
                                        "warmup",
                                    ] and not event.get("isMeta"):
                                        user_messages += 1
                                elif event_type == "assistant":
                                    # Count assistant responses (excluding warmup responses)
                                    assistant_messages += 1
                            except json.JSONDecodeError:
                                continue

                        # Only include sessions with real conversation (at least 1 real user message)
                        if (
                            user_messages > 0 or assistant_messages > 1
                        ):  # >1 assistant means follow-up after warmup
                            file_mtime = session_file.stat().st_mtime
                            # Calculate how recently the file was modified (in seconds)
                            seconds_since_modification = current_time - file_mtime

                            claude_valid_sessions.append(
                                {
                                    "file": session_file,
                                    "user_messages": user_messages,
                                    "assistant_messages": assistant_messages,
                                    "total_lines": len(lines),
                                    "mtime": file_mtime,
                                    "last_message_time": last_message_time or 0,
                                    "last_message_timestamp": last_message_timestamp,
                                    "seconds_since_modification": seconds_since_modification,
                                }
                            )
                    except Exception as e:
                        logger.warning(
                            "Failed to analyze session file",
                            file=session_file.name,
                            error=str(e),
                        )
                        continue

                # Sort by last message timestamp (most recent first), then by file modification time
                # This ensures we pick the session with the most recent activity, not just file modification
                claude_valid_sessions.sort(
                    key=lambda s: (s["last_message_time"] or 0, s["mtime"]),
                    reverse=True,
                )

                if not claude_valid_sessions:
                    error_response = {
                        "status": "error",
                        "error": f"No valid conversation sessions found in: {claude_base}",
                        "hint": "Found session files, but they only contain snapshots or warmup messages",
                        "total_files": len(all_session_files),
                    }
                    logger.info(
                        "MCP_RESPONSE",
                        method="thread_persist",
                        app=app_source,
                        response=json.dumps(error_response, separators=(",", ":")),
                    )
                    return error_response

                # Step 4: Determine which sessions to process
                sessions_to_process = (
                    claude_valid_sessions
                    if persist_mode == "all"
                    else [claude_valid_sessions[0]]
                )

                # Log session selection details for debugging
                if claude_valid_sessions:
                    selected_session = claude_valid_sessions[0]
                    logger.info(
                        "Found valid Claude Code sessions",
                        total_files=len(all_session_files),
                        valid_sessions=len(claude_valid_sessions),
                        processing=len(sessions_to_process),
                        mode=persist_mode,
                        selected_session=selected_session["file"].stem,
                        selected_last_message_time=selected_session.get(
                            "last_message_timestamp"
                        ),
                        selected_seconds_since_mod=selected_session.get(
                            "seconds_since_modification"
                        ),
                        all_sessions=[
                            {
                                "file": s["file"].stem,
                                "last_msg_time": s.get("last_message_timestamp"),
                                "seconds_since_mod": s.get(
                                    "seconds_since_modification"
                                ),
                            }
                            for s in claude_valid_sessions[:5]  # Log top 5
                        ],
                    )
                else:
                    logger.info(
                        "Found valid Claude Code sessions",
                        total_files=len(all_session_files),
                        valid_sessions=0,
                        processing=0,
                        mode=persist_mode,
                    )

                # Step 5: Process each valid session
                for session_info in sessions_to_process:
                    session_file = session_info["file"]
                    session_id = session_file.stem  # filename without .jsonl
                    thread_id = f"claude-code-{session_id}"

                    # Check if thread already exists
                    existing_thread = await thread_operations.get_thread(thread_id)

                    if existing_thread:
                        # Thread exists - append new messages
                        logger.info(
                            "Thread exists, appending new messages",
                            thread_id=thread_id,
                            session_file=session_file.name,
                            current_messages=len(existing_thread.messages),
                            user_msgs=session_info["user_messages"],
                            assistant_msgs=session_info["assistant_messages"],
                        )

                        append_result = await file_handler.append_messages_from_file(
                            thread_id=thread_id,
                            file_path=str(session_file),
                            format="claude_code",
                            deduplicate=True,  # Skip duplicate messages
                            truncate_large_content=truncate_large_content,  # Truncate tool results > 10KB
                        )
                        results.append(
                            {
                                "action": "appended",
                                "session_id": session_id,
                                "thread_id": thread_id,
                                "messages_added": append_result["messages_added"],
                                "total_messages": append_result["total_messages"],
                                "file": session_file.name,
                            }
                        )
                    else:
                        # Thread doesn't exist - create new
                        logger.info(
                            "Creating new thread from session",
                            thread_id=thread_id,
                            session_file=session_file.name,
                            user_msgs=session_info["user_messages"],
                            assistant_msgs=session_info["assistant_messages"],
                        )

                        # Only apply summary to the most recent session
                        session_summary = (
                            summary if session_info == sessions_to_process[0] else None
                        )

                        create_result = await file_handler.create_thread_from_file(
                            file_path=str(session_file),
                            format="claude_code",
                            thread_id_override=thread_id,
                            summary=session_summary,
                        )

                        # Notify UI of data change (MCP-triggered)
                        log_data_change(
                            change_type="thread_created",
                            entity_type="thread",
                            entity_id=create_result.thread.thread_id,  # type: ignore[attr-defined]
                            details={"source": "mcp", "format": "claude_code"},
                        )

                        results.append(
                            {
                                "action": "created",
                                "session_id": session_id,
                                "thread_id": create_result.thread.id,
                                "thread_uuid": create_result.thread.id,  # ThreadNode uses 'id', not 'uuid'
                                "message_count": len(create_result.messages),
                                "file": session_file.name,
                                "user_messages": session_info["user_messages"],
                                "assistant_messages": session_info[
                                    "assistant_messages"
                                ],
                            }
                        )

            elif client == "codex":
                # Codex session discovery
                # Step 1: Search ~/.codex/sessions recursively for rollout-*.jsonl files
                codex_base = Path.home() / ".codex" / "sessions"

                if not codex_base.exists() or not codex_base.is_dir():
                    error_response = {
                        "status": "error",
                        "error": f"Codex sessions directory not found: {codex_base}",
                        "hint": "Make sure Codex has created sessions",
                    }
                    logger.info(
                        "MCP_RESPONSE",
                        method="thread_persist",
                        app=app_source,
                        response=json.dumps(error_response, separators=(",", ":")),
                    )
                    return error_response

                # Step 2: Find all rollout-*.jsonl files recursively
                all_session_files = list(codex_base.glob("**/rollout-*.jsonl"))

                # Step 3: Filter for sessions matching project_path
                valid_sessions: list[dict[str, Any]] = []
                for session_file in all_session_files:
                    try:
                        # Read first line to get session_meta
                        with open(session_file) as f:
                            first_line = f.readline().strip()
                            if not first_line:
                                continue

                            session_meta = json.loads(first_line)
                            if session_meta.get("type") != "session_meta":
                                continue

                            payload = session_meta.get("payload", {})
                            session_cwd = payload.get("cwd", "")

                            # Match by cwd
                            if session_cwd == project_path:
                                # Extract session ID from filename: rollout-{timestamp}-{session_id}.jsonl
                                filename = session_file.stem
                                # Split by last dash to get session ID
                                parts = filename.rsplit("-", 1)
                                session_id = parts[1] if len(parts) > 1 else filename

                                valid_sessions.append(
                                    {
                                        "file": session_file,
                                        "session_id": session_id,
                                        "cwd": session_cwd,
                                        "timestamp": payload.get("timestamp"),
                                        "mtime": session_file.stat().st_mtime,
                                    }
                                )
                    except Exception as e:
                        logger.warning(
                            "Failed to analyze Codex session file",
                            file=session_file.name,
                            error=str(e),
                        )
                        continue

                # Sort by modification time (most recent first)
                valid_sessions.sort(key=lambda s: s["mtime"], reverse=True)

                if not valid_sessions:
                    error_response = {
                        "status": "error",
                        "error": f"No Codex sessions found for project: {project_path}",
                        "hint": "Run the /prompts:save_session command in Codex to list available sessions",
                        "total_files": len(all_session_files),
                    }
                    logger.info(
                        "MCP_RESPONSE",
                        method="thread_persist",
                        app=app_source,
                        response=json.dumps(error_response, separators=(",", ":")),
                    )
                    return error_response

                # For Codex, use provided session_id or most recent session
                if session_id:
                    # Find the specific session by ID
                    sessions_to_process = [
                        s for s in valid_sessions if s["session_id"] == session_id
                    ]
                    if not sessions_to_process:
                        error_response = {
                            "status": "error",
                            "error": f"Session ID '{session_id}' not found for project: {project_path}",
                            "hint": "Run the /prompts:save_session command in Codex to list available sessions",
                            "available_sessions": [
                                s["session_id"] for s in valid_sessions
                            ],
                        }
                        logger.info(
                            "MCP_RESPONSE",
                            method="thread_persist",
                            app=app_source,
                            response=json.dumps(error_response, separators=(",", ":")),
                        )
                        return error_response
                else:
                    # Use most recent session
                    sessions_to_process = [valid_sessions[0]]

                logger.info(
                    "Found valid Codex sessions",
                    total_files=len(all_session_files),
                    valid_sessions=len(valid_sessions),
                    processing=len(sessions_to_process),
                    most_recent_id=valid_sessions[0]["session_id"]
                    if valid_sessions
                    else None,
                )

                # Step 4: Process the session
                for session_info in sessions_to_process:
                    session_file = session_info["file"]
                    session_id = session_info["session_id"]
                    thread_id = f"codex-{session_id}"

                    # Check if thread already exists
                    existing_thread = await thread_operations.get_thread(thread_id)

                    if existing_thread:
                        # Thread exists - append new messages
                        logger.info(
                            "Thread exists, appending new messages",
                            thread_id=thread_id,
                            session_file=session_file.name,
                            current_messages=len(existing_thread.messages),
                        )

                        append_result = await file_handler.append_messages_from_file(
                            thread_id=thread_id,
                            file_path=str(session_file),
                            format="codex",
                            deduplicate=True,
                            truncate_large_content=truncate_large_content,
                        )

                        results.append(
                            {
                                "action": "appended",
                                "session_id": session_id,
                                "thread_id": thread_id,
                                "messages_added": append_result["messages_added"],
                                "total_messages": append_result["total_messages"],
                                "file": session_file.name,
                            }
                        )
                    else:
                        # Thread doesn't exist - create new
                        logger.info(
                            "Creating new thread from Codex session",
                            thread_id=thread_id,
                            session_file=session_file.name,
                        )

                        create_result = await file_handler.create_thread_from_file(
                            file_path=str(session_file),
                            format="codex",
                            thread_id_override=thread_id,
                            summary=summary,
                            truncate_large_content=truncate_large_content,
                        )

                        # Notify UI of data change (MCP-triggered)
                        log_data_change(
                            change_type="thread_created",
                            entity_type="thread",
                            entity_id=create_result.thread.thread_id,  # type: ignore[attr-defined]
                            details={"source": "mcp", "format": "codex"},
                        )

                        results.append(
                            {
                                "action": "created",
                                "session_id": session_id,
                                "thread_id": create_result.thread.id,
                                "thread_uuid": create_result.thread.id,
                                "message_count": len(create_result.messages),
                                "file": session_file.name,
                            }
                        )

            # Step 6: Build response
            if persist_mode == "current" or client == "codex":
                # Single session response
                result = results[0]
                response_data = {
                    "status": "success",
                    "mode": "current",
                    "project_path": project_path,
                    "session_id": result["session_id"],
                    "thread_id": result["thread_id"],
                    "action": result["action"],
                    "message": f"{result['action'].capitalize()} session {result['session_id'][:8]}... ({result.get('messages_added', result.get('message_count', 0))} messages)",
                }
                # Add action-specific fields
                if result["action"] == "appended":
                    response_data["messages_added"] = result["messages_added"]
                    response_data["total_messages"] = result["total_messages"]
                else:
                    response_data["message_count"] = result["message_count"]
                    response_data["thread_uuid"] = result["thread_uuid"]
            else:
                # Multiple sessions response
                created_count = sum(1 for r in results if r["action"] == "created")  # type: ignore
                appended_count = sum(1 for r in results if r["action"] == "appended")  # type: ignore
                total_messages = sum(  # type: ignore
                    r.get("messages_added", r.get("message_count", 0)) for r in results
                )

                response_data: dict[str, Any] = {
                    "status": "success",
                    "mode": "all",
                    "project_path": project_path,
                    "sessions_processed": len(results),
                    "sessions_created": created_count,
                    "sessions_appended": appended_count,
                    "total_messages": total_messages,
                    "message": f"Processed {len(results)} sessions: {created_count} created, {appended_count} appended",
                    "sessions": results,
                }

            response_json = json.dumps(
                response_data, separators=(",", ":"), ensure_ascii=False
            )
            logger.info(
                "MCP_RESPONSE",
                method="thread_persist",
                app=app_source,
                response=response_json,
            )
            return response_data

        except Exception as e:
            logger.error(
                "Thread persist failed",
                project_path=project_path,
                error=str(e),
            )
            error_response = {
                "status": "error",
                "error": str(e),
                "project_path": project_path,
            }
            logger.info(
                "MCP_RESPONSE",
                method="thread_persist",
                app=app_source,
                response=json.dumps(error_response, separators=(",", ":")),
            )
            return error_response

    # =========================================================================
    # Thread Search Tool - Available to all MCP clients
    # =========================================================================
    @mcp.tool(
        name="thread_search",
        description="""Search through conversation threads using BM25 full-text search, or list recent threads.

HOW TO USE:
• To SEARCH: provide keywords → query="error handling" or query="React hooks"
• To LIST recent threads: omit query parameter entirely

Examples:
  thread_search(query="database migration")     → finds threads mentioning "database migration"
  thread_search(query="authentication bug")    → finds threads about auth bugs
  thread_search()                              → lists 10 most recent threads
  thread_search(source="claude-code")          → lists recent Claude Code threads only

Returns threads with matched message snippets, ranked by relevance.

This is useful for:
- Finding past conversations on a specific topic
- Locating decisions or discussions from previous sessions
- Discovering related context without distilling everything
- Browsing recent conversations (list mode)

Use this to search thread content directly instead of costly AI-based distillation of all messages.""",
        tags={"thread", "search", "conversation", "list"},
        annotations=ToolAnnotations(
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
    )
    async def thread_search(  # type: ignore
        query: Annotated[
            str | None,
            Field(
                description="Search query (keywords or natural language). Omit this parameter to list recent threads instead of searching.",
                max_length=500,
                examples=["async programming", "database migration"],
            ),
        ] = None,
        limit: Annotated[
            int,
            Field(
                description="Maximum number of threads to return (1-50)",
                ge=1,
                le=50,
            ),
        ] = 10,
        mode: Annotated[
            str,
            Field(
                description="Search mode: 'full' (search messages) or 'suggestions' (titles/summaries only). Only used when query is provided.",
                pattern=r"^(full|suggestions)$",
                examples=["full"],
            ),
        ] = "full",
        source: Annotated[
            str | None,
            Field(
                description="Filter by source (e.g., 'claude-code', 'codex'). Works in both search and list modes.",
                examples=["claude-code", "codex"],
            ),
        ] = None,
    ) -> dict[str, Any]:
        """Search threads with BM25 full-text search, or list recent threads when query is empty."""
        # Detect source from MCP client headers
        app_source = "mcp_generic"
        try:
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
        except Exception:
            pass

        # Normalize query - treat empty/whitespace-only as None (list mode)
        effective_query = query.strip() if query else None
        is_list_mode = not effective_query

        logger.info(
            "MCP_REQUEST",
            method="thread_search",
            app=app_source,
            request=json.dumps(
                {
                    "query": query,
                    "limit": limit,
                    "mode": mode,
                    "source": source,
                    "is_list_mode": is_list_mode,
                },
                separators=(",", ":"),
                ensure_ascii=False,
            ),
        )

        try:
            if not thread_operations:
                error_response = ThreadSearchResponse(
                    status="error",
                    threads=[],
                    total_found=0,
                    query=query or "",
                    mode="list" if is_list_mode else mode,
                )
                return error_response.model_dump()

            thread_items: list[ThreadSearchResultItem] = []

            if is_list_mode:
                # LIST MODE: Return recent threads ordered by last activity
                results = await thread_operations.list_threads(
                    limit=limit,
                    offset=0,
                    source=source,
                )

                # Transform list results to response format
                for thread_data in results:
                    thread_items.append(
                        ThreadSearchResultItem(
                            thread_id=thread_data.get("thread_id", ""),
                            title=thread_data.get("title"),
                            summary=None,  # List mode doesn't return summaries
                            message_count=thread_data.get("message_count", 0),
                            source=thread_data.get("source"),
                            relevance_score=1.0,  # No relevance in list mode
                            matched_messages=[],  # No matched messages in list mode
                            total_matches=0,
                        )
                    )

                response_data = ThreadSearchResponse(
                    status="success",
                    threads=thread_items,
                    total_found=len(thread_items),
                    query="",
                    mode="list",
                )
            else:
                # SEARCH MODE: Use BM25 full-text search
                results = await thread_operations.search_threads_enhanced(
                    query=effective_query,
                    mode=mode,
                    limit=limit,
                )

                # Transform search results to response format
                for thread_data in results.get("threads", []):
                    # Apply source filter if provided (search_threads_enhanced doesn't support it)
                    if source and thread_data.get("source") != source:
                        continue

                    matched_messages = [
                        ThreadSearchResultMessage(
                            message_id=msg.get("message_id", ""),
                            message_index=msg.get("message_index", 0),
                            role=msg.get("role", "unknown"),
                            snippet=msg.get("snippet", ""),
                            match_score=msg.get("match_score", 0.0),
                        )
                        for msg in thread_data.get("matched_messages", [])[
                            :5
                        ]  # Limit snippets per thread
                    ]

                    thread_items.append(
                        ThreadSearchResultItem(
                            thread_id=thread_data.get("thread_id", ""),
                            title=thread_data.get("title"),
                            summary=thread_data.get("summary"),
                            message_count=thread_data.get("message_count", 0),
                            source=thread_data.get("source"),
                            relevance_score=thread_data.get("relevance_score", 0.0),
                            matched_messages=matched_messages,
                            total_matches=thread_data.get("total_matches", 0),
                        )
                    )

                response_data = ThreadSearchResponse(
                    status="success",
                    threads=thread_items,
                    total_found=len(thread_items),
                    query=effective_query,
                    mode=mode,
                )

            response_json = response_data.model_dump_json(exclude_none=False)
            logger.info(
                "MCP_RESPONSE",
                method="thread_search",
                app=app_source,
                response=response_json,
            )
            return response_data.model_dump()

        except Exception as e:
            logger.error("Thread search failed", query=query, error=str(e))
            error_response = ThreadSearchResponse(
                status="error",
                threads=[],
                total_found=0,
                query=query or "",
                mode="list" if is_list_mode else mode,
            )
            return error_response.model_dump()

    # =========================================================================
    # Thread Fetch Messages Tool - Available to all MCP clients
    # =========================================================================
    @mcp.tool(
        name="thread_fetch_messages",
        description="""Fetch detailed messages from a specific thread by ID.

Returns all messages with full content for a thread. Use this after thread_search to get complete message details.

Parameters:
- thread_id: The thread ID from search results
- offset: Skip first N messages (for pagination)
- limit: Maximum messages to return (default 50)

This allows agents to efficiently retrieve thread content on-demand without pre-distillation.""",
        tags={"thread", "fetch", "messages"},
        annotations=ToolAnnotations(
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
    )
    async def thread_fetch_messages(  # type: ignore
        thread_id: Annotated[
            str,
            Field(
                description="Thread ID to fetch messages from",
                min_length=1,
                examples=["claude-code-abc123"],
            ),
        ],
        offset: Annotated[
            int,
            Field(
                description="Number of messages to skip (for pagination)",
                ge=0,
            ),
        ] = 0,
        limit: Annotated[
            int,
            Field(
                description="Maximum number of messages to return (1-100)",
                ge=1,
                le=100,
            ),
        ] = 50,
    ) -> dict[str, Any]:
        """Fetch detailed messages from a thread."""
        # Detect source from MCP client headers
        app_source = "mcp_generic"
        try:
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
        except Exception:
            pass

        logger.info(
            "MCP_REQUEST",
            method="thread_fetch_messages",
            app=app_source,
            request=json.dumps(
                {"thread_id": thread_id, "offset": offset, "limit": limit},
                separators=(",", ":"),
                ensure_ascii=False,
            ),
        )

        try:
            if not thread_operations:
                return {
                    "status": "error",
                    "error": "Thread operations not initialized",
                    "thread_id": thread_id,
                }

            # Fetch the thread
            thread_response = await thread_operations.get_thread(thread_id)

            if not thread_response:
                return {
                    "status": "error",
                    "error": f"Thread not found: {thread_id}",
                    "thread_id": thread_id,
                }

            # Extract and paginate messages
            all_messages = thread_response.messages
            paginated_messages = all_messages[offset : offset + limit]

            message_infos: list[ThreadMessageInfo] = []
            for msg in paginated_messages:
                # Truncate very long messages for LLM-friendly output
                content = msg.content
                if len(content) > 4000:
                    content = (
                        content[:4000] + "\n\n[... truncated, message too long ...]"
                    )

                message_infos.append(
                    ThreadMessageInfo(
                        id=msg.id,
                        role=msg.role,
                        content=content,
                        order_index=msg.order_index,
                        timestamp=msg.timestamp.isoformat() if msg.timestamp else None,
                    )
                )

            response_data = ThreadFetchMessagesResponse(
                status="success",
                thread_id=thread_id,
                title=thread_response.thread.title,
                summary=thread_response.thread.summary,
                source=thread_response.thread.source,
                message_count=len(all_messages),
                messages=message_infos,
            )

            response_json = response_data.model_dump_json(exclude_none=False)
            logger.info(
                "MCP_RESPONSE",
                method="thread_fetch_messages",
                app=app_source,
                response=response_json[:500] + "..."
                if len(response_json) > 500
                else response_json,
            )
            return response_data.model_dump()

        except Exception as e:
            logger.error(
                "Thread fetch messages failed",
                thread_id=thread_id,
                error=str(e),
            )
            return {
                "status": "error",
                "error": str(e),
                "thread_id": thread_id,
            }

    # =========================================================================
    # Thread Delete Tool
    # =========================================================================
    @mcp.tool(
        name="thread_delete",
        description="Delete a thread by ID. Optionally cascade to delete extracted memories.",
        tags={"thread", "delete"},
        annotations=ToolAnnotations(
            readOnlyHint=False,
            destructiveHint=True,
            idempotentHint=True,
            openWorldHint=False,
        ),
    )
    async def thread_delete(
        thread_id: Annotated[
            str,
            Field(description="Thread ID to delete"),
        ],
        cascade_delete_memories: Annotated[
            bool,
            Field(description="Also delete memories extracted from this thread"),
        ] = False,
    ) -> dict[str, Any]:
        """Delete a thread and optionally its extracted memories."""
        app_source = "mcp_generic"
        try:
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
        except Exception:
            pass

        logger.info(
            "MCP_REQUEST",
            method="thread_delete",
            app=app_source,
            request=json.dumps(
                {
                    "thread_id": thread_id,
                    "cascade_delete_memories": cascade_delete_memories,
                },
                separators=(",", ":"),
            ),
        )

        try:
            if not thread_operations:
                return {"status": "error", "error": "Thread operations not initialized"}

            result = await thread_operations.delete_thread(
                thread_id=thread_id,
                cascade_delete_memories=cascade_delete_memories,
            )

            if result.get("deleted"):
                log_data_change(
                    change_type="thread_deleted",
                    entity_type="thread",
                    entity_id=thread_id,
                    details={"cascade": cascade_delete_memories},
                )
            response = {
                "status": "success" if result.get("deleted") else "not_found",
                **result,
            }
            logger.info(
                "MCP_RESPONSE",
                method="thread_delete",
                app=app_source,
                response=json.dumps(response, separators=(",", ":")),
            )
            return response

        except Exception as e:
            logger.error("Thread delete failed", thread_id=thread_id, error=str(e))
            return {"status": "error", "error": str(e), "thread_id": thread_id}
