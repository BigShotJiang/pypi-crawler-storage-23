"""Knowledge Processing tools for MCP.

Exposes community detection and KG extraction as MCP tools,
restricted to AI-NOW app only (via AppFilteringMiddleware).
"""

from typing import Annotated, Optional

import structlog
from fastmcp import FastMCP
from pydantic import Field

logger = structlog.get_logger(__name__)


def register_knowledge_processing_tools(mcp: FastMCP) -> None:
    """Register knowledge processing tools with the MCP server."""

    @mcp.tool(
        name="run_community_detection",
        description=(
            "Run community detection on the knowledge graph. "
            "Uses Louvain algorithm to find clusters of related entities, "
            "then optionally generates LLM summaries for each community. "
            "Returns immediately — detection runs in background and results "
            "appear as a feed event when complete."
        ),
    )
    async def run_community_detection(
        resolution: Annotated[float, Field(
            description="Resolution parameter for Louvain algorithm. Higher = more communities. Default: 1.0",
        )] = 1.0,
        generate_summaries: Annotated[bool, Field(
            description="Generate LLM summaries for each community. Default: true",
        )] = True,
    ) -> dict:
        try:
            from nowledge_graph_server.agent.manager import get_agent_manager
            from nowledge_graph_server.agent.scheduler import AgentTask, TaskPriority

            manager = get_agent_manager()
            if not manager or not manager.is_running:
                return {"error": "Knowledge Agent is not running"}

            task = AgentTask(
                task_type="community_detection",
                prompt="",
                priority=TaskPriority.HIGH,
                metadata={
                    "resolution": resolution,
                    "generate_ai_summary": generate_summaries,
                    "max_iterations": 100,
                },
            )
            await manager._scheduler.submit_task(task)
            return {
                "status": "queued",
                "task": "community_detection",
                "resolution": resolution,
                "generate_summaries": generate_summaries,
            }
        except Exception as e:
            logger.error("Failed to queue community detection", error=str(e))
            return {"error": str(e)}

    @mcp.tool(
        name="extract_knowledge_graph",
        description=(
            "Extract entities and relationships from memories into the knowledge graph. "
            "Provide specific memory IDs (comma-separated) to extract from those memories, "
            "or omit to backfill all un-extracted memories (up to 50 per run). "
            "Uses the remote LLM for high-quality entity extraction with deduplication. "
            "Returns immediately — extraction runs in background."
        ),
    )
    async def extract_knowledge_graph(
        memory_ids: Annotated[Optional[str], Field(
            description="Comma-separated memory IDs to extract from. If omitted, runs backfill for all un-extracted memories.",
        )] = None,
    ) -> dict:
        try:
            from nowledge_graph_server.agent.manager import get_agent_manager
            from nowledge_graph_server.agent.scheduler import AgentTask, TaskPriority

            manager = get_agent_manager()
            if not manager or not manager.is_running:
                return {"error": "Knowledge Agent is not running"}

            if memory_ids:
                ids = [s.strip() for s in memory_ids.split(",") if s.strip()]
                task_type = "kg_extraction"
                metadata = {"memory_ids": ids}
            else:
                ids = None
                task_type = "kg_extraction_backfill"
                metadata = {}

            task = AgentTask(
                task_type=task_type,
                prompt="",
                priority=TaskPriority.HIGH,
                metadata=metadata,
            )
            await manager._scheduler.submit_task(task)
            return {
                "status": "queued",
                "task": task_type,
                "memory_ids": ids,
            }
        except Exception as e:
            logger.error("Failed to queue KG extraction", error=str(e))
            return {"error": str(e)}
