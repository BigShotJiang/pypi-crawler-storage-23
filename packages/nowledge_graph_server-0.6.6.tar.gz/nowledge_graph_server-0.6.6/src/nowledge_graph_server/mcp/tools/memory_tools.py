"""Memory management tools for MCP."""

import datetime
import json
from typing import Annotated, Any, List, Optional

import structlog
from fastmcp import FastMCP
from fastmcp.exceptions import ToolError
from fastmcp.server.dependencies import get_http_headers
from mcp.types import ToolAnnotations
from pydantic import Field

from nowledge_graph_server.core.memory_operations import MemoryOperations
from nowledge_graph_server.core.search_operations import SearchOperations
from nowledge_graph_server.models.mcp import (
    MemorySearchResponse,
    MemorySearchResult,
    LabelsResponse,
    LabelInfo,
    MemoryAddResponse,
    MemoryInfo,
    ProcessingInfo,
    MemoryUpdateResponse,
    UpdateInfo,
    MemoryDeleteResponse,
    DeletionInfo,
    BulkDeleteItem,
    BulkDeletionSummary,
    BulkMemoryDeleteResponse,
)
from nowledge_graph_server.utils.mcp_utils import unescape_unicode_sequences, get_app_source_from_headers
from nowledge_graph_server.utils.progress_logger import log_data_change
from nowledge_graph_server.services.search_index import sync_memory_to_index

logger = structlog.get_logger(__name__)


def register_memory_tools(
    mcp: FastMCP,
    memory_operations: MemoryOperations,
    search_operations: SearchOperations,
) -> None:
    """Register memory management tools with the MCP server."""

    @mcp.tool(
        name="memory_search",
        description="""Search through stored memories using semantic search, or list recent memories.

HOW TO USE:
• To SEARCH: provide a natural language query → query="Python async patterns"
• To LIST recent memories: omit query parameter entirely

Examples:
  memory_search(query="React state management")  → semantic search for React state
  memory_search(query="meeting notes from John") → finds memories about meetings with John
  memory_search()                                → lists 10 most recent memories
  memory_search(filter_labels="work")            → lists recent memories labeled "work"

CONFIDENCE SCORES (search mode):
Results are ranked by confidence score (0.0-1.0):
- 0.6-1.0: Direct match - highly relevant to query
- 0.3-0.6: Related content - useful context
- 0.15-0.3: Tangential - may provide background
- <0.15: Off-topic - usually filtered

Use confidence_threshold to control result quality:
- 0.4-0.5: Precise search (fewer, highly relevant results)
- 0.2-0.3: Balanced search (default, good mix)
- 0.1-0.2: Broad search (more results, exploratory)

TEMPORAL FILTERING - Two Time Dimensions:
1. EVENT TIME (when_it_happened): When the actual event/fact occurred in the real world
2. RECORD TIME (when_we_learned): When you recorded this memory into the system

Most queries should use EVENT TIME. Examples:
- "What happened in 2020?" → event_date_from="2020"
- "My React projects from 2023" → event_date_from="2023"
- "Decisions made last year" → event_date_from="2024"

Use RECORD TIME only for system/audit queries:
- "What did I add to memory this week?" → recorded_date_from="2024-11-18"
- "Memories I imported yesterday" → recorded_date_from="2024-11-23"

You can combine both for advanced queries:
- "2020 events that I only recorded recently" → event_date_from="2020", recorded_date_from="2024-11"

Supports multi-language queries and label filtering.""",
        tags={"search", "memory", "semantic", "list"},
        meta={"ui": {"resourceUri": "ui://nowledge/graph-explorer.html"}},
    )
    async def memory_search(  # type: ignore
        query: Annotated[
            str | None,
            Field(
                description="Natural language search query. Omit this parameter to list recent memories instead of searching.",
                max_length=500,
                examples=["python async programming", "machine learning concepts"],
            ),
        ] = None,
        limit: Annotated[
            int, Field(description="Max results to return (1-20)", ge=1, le=20)
        ] = 10,
        filter_labels: Annotated[
            Optional[str],
            Field(
                description="Optional: comma-separated labels to filter results",
                examples=["work,important"],
            ),
        ] = None,
        mode: Annotated[
            str,
            Field(
                description="Search mode: 'normal' (fast) or 'deep' (graph-enhanced)",
                examples=["normal"],
            ),
        ] = "normal",
        confidence_threshold: Annotated[
            float,
            Field(
                description="Minimum confidence (0.0-1.0). Use 0.4+ for precise results, 0.2 for balanced (default), 0.1+ for broad exploration.",
                ge=0.0,
                le=1.0,
            ),
        ] = 0.20,

        # === EVENT TIME FILTERS (when the event occurred) ===
        event_date_from: Annotated[
            Optional[str],
            Field(
                description="Filter by when the event occurred. Format: YYYY, YYYY-MM, or YYYY-MM-DD",
                examples=["2024"],
            ),
        ] = None,

        event_date_to: Annotated[
            Optional[str],
            Field(
                description="Upper bound for event date. Format: YYYY, YYYY-MM, or YYYY-MM-DD",
                examples=["2024-12-31"],
            ),
        ] = None,

        temporal_context: Annotated[
            Optional[str],
            Field(
                description="Temporal context: 'past', 'present', 'future', or 'timeless'",
                examples=["past"],
            ),
        ] = None,

        # === RECORD TIME FILTERS (when we recorded it) ===
        recorded_date_from: Annotated[
            Optional[str],
            Field(
                description="Filter by when memory was recorded (system time). Format: YYYY-MM-DD",
                examples=["2024-11-20"],
            ),
        ] = None,

        recorded_date_to: Annotated[
            Optional[str],
            Field(
                description="Upper bound for recording date. Format: YYYY-MM-DD",
            ),
        ] = None,
    ) -> dict:
        """Implementation uses semantic embeddings and hybrid search with label filtering, or lists recent memories."""
        # Normalize query - treat empty/whitespace-only as None (list mode)
        effective_query = query.strip() if query else None
        is_list_mode = not effective_query

        # Validate temporal filters (language-agnostic)
        from nowledge_graph_server.database.search_engine_utils import validate_temporal_filters

        try:
            validate_temporal_filters(
                event_date_from=event_date_from,
                event_date_to=event_date_to,
                recorded_date_from=recorded_date_from,
                recorded_date_to=recorded_date_to,
            )
        except ValueError as e:
            return MemorySearchResponse(
                status="error",
                results=[],
                query=query or "",
                total_found=0,
                filter_labels=filter_labels,
                filters_applied={"error": str(e)},
            ).model_dump()

        # Log the request
        request_data = {
            "query": query,
            "limit": limit,
            "filter_labels": filter_labels,
            "event_date_from": event_date_from,
            "event_date_to": event_date_to,
            "temporal_context": temporal_context,
            "recorded_date_from": recorded_date_from,
            "recorded_date_to": recorded_date_to,
            "is_list_mode": is_list_mode,
        }
        headers = {}
        app_source = "unknown"
        try:
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
        except:
            logger.warning("Failed to get app source from headers", headers=str(headers))
            app_source = "mcp_generic"

        logger.info(
            "MCP_REQUEST",
            method="memory_search",
            app=app_source,
            request=json.dumps(request_data, separators=(",", ":"), ensure_ascii=False),
        )

        # Parse filter_labels from comma-separated string to list
        parsed_filter_labels: List[str] = []
        if filter_labels:
            if isinstance(filter_labels, str):  # type: ignore
                labels_str = filter_labels.strip()
                if labels_str.startswith("[") and labels_str.endswith("]"):
                    labels_str = labels_str[1:-1]  # Remove brackets

                # Split by comma and clean up
                if "," in labels_str:
                    parsed_filter_labels = [
                        label.strip().strip("\"'")
                        for label in labels_str.split(",")
                        if label.strip()
                    ]
                else:
                    # Single label
                    cleaned_label = labels_str.strip().strip("\"'")
                    if cleaned_label:
                        parsed_filter_labels = [cleaned_label]
            elif isinstance(filter_labels, list):  # type: ignore
                # Handle case where it's already a list (backward compatibility)
                parsed_filter_labels = [
                    str(label).strip() for label in filter_labels if str(label).strip()
                ]

        try:
            if not search_operations or not memory_operations:
                error_response = MemorySearchResponse(
                    status="error",
                    results=[],
                    query=query or "",
                    total_found=0,
                    filter_labels=filter_labels,
                )
                logger.info(
                    "MCP_RESPONSE",
                    method="memory_search",
                    app=app_source,
                    response=error_response.model_dump_json(),
                )
                return error_response.model_dump()

            memory_results: List[MemorySearchResult] = []
            filtered_memories: List[Any] = []
            filters_applied_info: dict[str, Any] = {}

            if is_list_mode:
                # LIST MODE: Return recent memories ordered by creation date
                memories = await memory_operations.list_memories(
                    limit=min(limit, 20),
                    offset=0,
                    state="active",
                    importance_min=0.0,
                    labels=parsed_filter_labels if parsed_filter_labels else None,
                )

                # Transform list results to response format
                for memory in memories:
                    # Unescape Unicode sequences
                    content = unescape_unicode_sequences(memory.content)
                    title = unescape_unicode_sequences(memory.title or "")

                    memory_result = MemorySearchResult(
                        memory_id=memory.id,
                        content=content,
                        title=title,
                        importance=memory.importance if memory.importance is not None else 0.5,
                        similarity_score=1.0,  # No similarity in list mode
                        created_at=memory.created_at.strftime("%Y-%m-%d %H:%M"),
                        source_thread_id=None,  # Will fetch below
                    )
                    memory_results.append(memory_result)
                    filtered_memories.append(memory)

                filters_applied_info["mode"] = "list"
                if parsed_filter_labels:
                    filters_applied_info["labels"] = parsed_filter_labels

            else:
                # SEARCH MODE: Use semantic search
                # Map MCP mode: normal → fast; deep → deep
                backend_mode = "fast" if (mode or "normal").lower() == "normal" else "deep"

                # Build metadata_filters for temporal filtering
                metadata_filters: dict[str, Any] = {}
                if event_date_from:
                    metadata_filters["event_date_from"] = event_date_from
                if event_date_to:
                    metadata_filters["event_date_to"] = event_date_to
                if temporal_context:
                    metadata_filters["temporal_context"] = temporal_context
                if recorded_date_from:
                    metadata_filters["recorded_date_from"] = recorded_date_from
                if recorded_date_to:
                    metadata_filters["recorded_date_to"] = recorded_date_to

                results = await search_operations.search_memories(
                    query=effective_query,
                    limit=min(limit, 20),  # Cap at 20 for LLM-friendly results
                    include_entities=False,  # Keep it simple for now
                    filter_labels=parsed_filter_labels,
                    metadata_filters=metadata_filters if metadata_filters else None,
                    mode=backend_mode,
                )

                # Process results - clean up for LLM consumption
                for result in results:
                    if result and result.memory:
                        confidence = result.similarity_score
                        if confidence < confidence_threshold:
                            continue
                        filtered_memories.append(result)

                # Build filters_applied for transparency (search mode)
                if event_date_from or event_date_to:
                    filters_applied_info["dimension"] = "event"
                    if event_date_from:
                        filters_applied_info["event_date_from"] = event_date_from
                    if event_date_to:
                        filters_applied_info["event_date_to"] = event_date_to
                if temporal_context:
                    filters_applied_info["temporal_context"] = temporal_context
                if recorded_date_from or recorded_date_to:
                    if "dimension" in filters_applied_info:
                        filters_applied_info["dimension"] = "both"
                    else:
                        filters_applied_info["dimension"] = "record"
                    if recorded_date_from:
                        filters_applied_info["recorded_date_from"] = recorded_date_from
                    if recorded_date_to:
                        filters_applied_info["recorded_date_to"] = recorded_date_to

            # Fetch source thread IDs for all filtered memories in one batch query
            source_thread_map: dict[str, str] = {}
            if filtered_memories:
                try:
                    # Handle both list mode (MemoryNode) and search mode (MemorySearchResult)
                    if is_list_mode:
                        memory_ids = [m.id for m in filtered_memories]
                    else:
                        memory_ids = [r.memory.id for r in filtered_memories if r.memory]
                    source_thread_map = (
                        await memory_operations.db.memory_repo.get_source_threads_for_memories(  # type: ignore[attr-defined]
                            memory_ids
                        )
                    )
                    # Update source_thread_id for list mode results
                    if is_list_mode:
                        for idx, result in enumerate(memory_results):
                            result.source_thread_id = source_thread_map.get(filtered_memories[idx].id)
                except Exception as e:
                    logger.warning(
                        "Failed to fetch source threads for memories",
                        error=str(e),
                    )

            # Process search mode results (list mode already processed above)
            if not is_list_mode:
                for result in filtered_memories:
                    if result and result.memory:
                        # Unescape Unicode sequences that might have been double-escaped
                        content = unescape_unicode_sequences(result.memory.content)
                        title = unescape_unicode_sequences(result.memory.title or "")

                        memory_result = MemorySearchResult(
                            memory_id=result.memory.id,  # Include memory ID for updates
                            content=content,
                            title=title,
                            importance=result.memory.importance,
                            similarity_score=result.similarity_score,
                            created_at=result.memory.created_at.strftime("%Y-%m-%d %H:%M"),
                            source_thread_id=source_thread_map.get(result.memory.id),
                        )
                        memory_results.append(memory_result)  # type: ignore

            response_data = MemorySearchResponse(
                status="success",
                results=memory_results,  # type: ignore
                query=effective_query or "",
                total_found=len(memory_results),  # type: ignore
                filter_labels=filter_labels,
                filters_applied=filters_applied_info if filters_applied_info else None,
            )

            # Track appearances for decay model (async, don't fail if tracking fails)
            if memory_results:
                try:
                    memory_ids_to_track = [r.memory_id for r in memory_results if r.memory_id]
                    for mem_id in memory_ids_to_track:
                        try:
                            await memory_operations.db.memory_repo.increment_memory_appearances(mem_id)  # type: ignore[attr-defined]
                        except Exception as track_err:
                            # Individual tracking failure shouldn't fail the whole operation
                            logger.warning(
                                "Failed to track MCP appearance for memory",
                                memory_id=mem_id,
                                error=str(track_err),
                            )
                    logger.debug(
                        "Tracked MCP search appearances",
                        app=app_source,
                        query=query,
                        tracked_count=len(memory_ids_to_track),
                    )
                except Exception as e:
                    # Don't fail the search if tracking fails
                    logger.warning(
                        "Failed to track MCP search appearances",
                        app=app_source,
                        error=str(e),
                    )

            # Log response as JSON string to avoid Python dict formatting issues
            response_json = response_data.model_dump_json(exclude_none=False)
            logger.info(
                "MCP_RESPONSE",
                method="memory_search",
                app=app_source,
                response=response_json,
            )
            return response_data.model_dump()

        except Exception as e:
            logger.error("Memory search failed", query=query, error=str(e))
            error_response = MemorySearchResponse(
                status="error",
                results=[],
                query=query or "",
                total_found=0,
                filter_labels=filter_labels,
                filters_applied={"mode": "list" if is_list_mode else "search"},
            )
            logger.info(
                "MCP_RESPONSE",
                method="memory_search",
                app=app_source,
                response=error_response.model_dump_json(),
            )
            return error_response.model_dump()

    @mcp.tool(
        name="list_memory_labels",
        description="List labels with usage counts",
        tags={"labels", "metadata", "discovery"},
        annotations=ToolAnnotations(
            readOnlyHint=True,  # This tool only reads data
            idempotentHint=True,  # Always returns current label state
            openWorldHint=False,  # Closed domain - only local labels
        ),
    )
    async def list_memory_labels() -> dict:  # type: ignore
        """Implementation queries the label manager with usage statistics."""
        # Log the request
        headers = {}
        app_source = "unknown"
        try:
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
        except:
            logger.warning("Failed to get app source from headers", headers=str(headers))
            app_source = "mcp_generic"

        logger.info(
            "MCP_REQUEST",
            method="list_memory_labels",
            app=app_source,
            request=json.dumps({}, separators=(",", ":"), ensure_ascii=False),
        )

        try:
            if not memory_operations:
                error_response = LabelsResponse(labels=[], total=0)
                logger.info(
                    "MCP_RESPONSE",
                    method="list_memory_labels",
                    app=app_source,
                    response=error_response.model_dump_json(),
                )
                return error_response.model_dump()

            # Get labels with usage counts from the database
            labels_data = await memory_operations.db.label_mgr.list_labels(limit=100)  # type: ignore

            # Convert to structured response
            label_infos = []
            for label in labels_data:  # type: ignore
                label_info = LabelInfo(
                    name=label["name"],  # type: ignore
                    usage_count=label["usage_count"],  # type: ignore
                )
                label_infos.append(label_info)  # type: ignore

            response_data = LabelsResponse(labels=label_infos, total=len(label_infos))  # type: ignore

            response_json = response_data.model_dump_json(exclude_none=False)
            logger.info(
                "MCP_RESPONSE",
                method="list_memory_labels",
                app=app_source,
                response=response_json,
            )
            return response_data.model_dump()

        except Exception as e:
            logger.error("Failed to get labels", error=str(e))
            error_response = LabelsResponse(labels=[], total=0)
            logger.info(
                "MCP_RESPONSE",
                method="list_memory_labels",
                app=app_source,
                response=error_response.model_dump_json(),
            )
            return error_response.model_dump()

    @mcp.tool(
        name="memory_add",
        description="Create memory with optional title, importance, labels, and temporal information",
        tags={"memory", "create", "knowledge"},
        annotations=ToolAnnotations(
            readOnlyHint=False,  # This tool modifies data
            destructiveHint=False,  # Creates new data, doesn't destroy existing
            idempotentHint=False,  # Each call creates a new memory
            openWorldHint=False,  # Closed domain - only affects local knowledge base
        ),
    )
    async def memory_add(  # type: ignore
        content: Annotated[
            str,
            Field(
                description="Memory content (plain text or markdown)",
                min_length=1,
                max_length=32768,
                examples=["Learned about Python async/await patterns"],
            ),
        ],
        title: Annotated[
            Optional[str],
            Field(
                description="Optional title for the memory",
                max_length=200,
                examples=["Python Async Patterns"],
            ),
        ] = None,
        importance: Annotated[
            float,
            Field(
                description="Importance score (0.1=low, 0.5=medium, 0.8=high, 1.0=critical)",
                ge=0.0,
                le=1.0,
            ),
        ] = 0.5,
        labels: Annotated[
            Optional[str],
            Field(
                description="Comma-separated labels (no spaces in labels)",
                examples=["work,meeting"],
            ),
        ] = None,
        # Bi-temporal fields (added 2025-11-20)
        event_start: Annotated[
            Optional[str],
            Field(
                description="When event occurred. Format: YYYY, YYYY-MM, or YYYY-MM-DD",
                examples=["2024-03-15"],
            ),
        ] = None,
        event_end: Annotated[
            Optional[str],
            Field(
                description="When event ended (for ranges). Format: YYYY, YYYY-MM, or YYYY-MM-DD",
                examples=["2024-06-30"],
            ),
        ] = None,
        temporal_context: Annotated[
            Optional[str],
            Field(
                description="Temporal context: 'past', 'present', 'future', or 'timeless'",
                examples=["past"],
            ),
        ] = None,
    ) -> dict:
        """Implementation creates memory with embeddings, entity extraction, and source detection."""
        # Detect source from MCP client headers
        headers = {}
        try:
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
        except:
            logger.warning("Failed to get app source from headers", headers=str(headers))
            app_source = "mcp_generic"
        # Log the request
        request_data = {
            "content": content,
            "title": title,
            "importance": importance,
            "labels": labels,
        }
        logger.info(
            "MCP_REQUEST",
            method="memory_add",
            app=app_source,
            request=json.dumps(request_data, separators=(",", ":"), ensure_ascii=False),
        )
        # Parse labels from comma-separated string to list
        parsed_labels = []
        if labels:
            if isinstance(labels, str):  # type: ignore
                labels_str = labels.strip()
                if labels_str.startswith("[") and labels_str.endswith("]"):
                    labels_str = labels_str[1:-1]  # Remove brackets

                # Split by comma and clean up
                if "," in labels_str:
                    parsed_labels = [
                        label.strip().strip("\"'")
                        for label in labels_str.split(",")
                        if label.strip()
                    ]
                else:
                    # Single label
                    cleaned_label = labels_str.strip().strip("\"'")
                    if cleaned_label:
                        parsed_labels = [cleaned_label]
            elif isinstance(labels, list):  # type: ignore
                # Handle case where it's already a list (backward compatibility)
                parsed_labels = [
                    str(label).strip() for label in labels if str(label).strip()
                ]

        # Use parsed_labels for the actual memory creation
        labels_list = parsed_labels
        try:
            if not memory_operations:
                # Create a minimal error response structure
                error_memory = MemoryInfo(
                    content="", title=None, importance=0.0, created_at=""
                )
                error_processing = ProcessingInfo(
                    entities_extracted=0, labels_applied=0, source=app_source
                )
                error_response = MemoryAddResponse(
                    status="error", memory=error_memory, processing=error_processing
                )
                logger.info(
                    "MCP_RESPONSE",
                    method="memory_add",
                    app=app_source,
                    response=error_response.model_dump_json(),
                )
                return error_response.model_dump()

            # Build metadata
            metadata = {
                "created_via": "mcp_tool",
                "source_detected": app_source,
            }

            # Process temporal parameters if provided
            temporal_type = None
            normalized_event_start = None
            normalized_event_end = None
            temporal_precision = None

            if event_start or event_end:
                # Import temporal utilities
                from nowledge_graph_server.services.temporal_utils import normalize_temporal_date

                # Determine temporal type
                if event_start and event_end:
                    temporal_type = "range"
                elif event_start:
                    temporal_type = "exact"

                # Normalize dates
                if event_start:
                    try:
                        normalized_event_start, temporal_precision = normalize_temporal_date(event_start)
                    except ValueError as e:
                        logger.warning("Failed to normalize event_start", raw=event_start, error=str(e))

                if event_end:
                    try:
                        normalized_event_end, _ = normalize_temporal_date(event_end)
                    except ValueError as e:
                        logger.warning("Failed to normalize event_end", raw=event_end, error=str(e))

            # Use MemoryOperations for clean memory creation
            result = await memory_operations.create_memory(
                content=content,
                title=title,
                source_id=None,  # Not needed for MCP tool usage
                source=app_source,  # Use detected source
                importance=importance,
                metadata=metadata,
                labels=labels_list,
                extract_entities=False,  # Always extract entities for better organization
                # Bi-temporal fields
                temporal_type=temporal_type,
                event_start=normalized_event_start,
                event_end=normalized_event_end,
                temporal_precision=temporal_precision,
                temporal_confidence=1.0 if (event_start or event_end) else None,  # User-provided temporal info is high confidence
                temporal_context=temporal_context if temporal_context else "timeless",
            )

            if not result:
                # Create a minimal error response structure
                error_memory = MemoryInfo(
                    content="", title=None, importance=0.0, created_at=""
                )
                error_processing = ProcessingInfo(
                    entities_extracted=0, labels_applied=0, source=app_source
                )
                error_response = MemoryAddResponse(
                    status="error", memory=error_memory, processing=error_processing
                )
                logger.info(
                    "MCP_RESPONSE",
                    method="memory_add",
                    app=app_source,
                    response=error_response.model_dump_json(),
                )
                return error_response.model_dump()

            # Unescape Unicode sequences in the response
            clean_content = unescape_unicode_sequences(result.memory.content)
            clean_title = unescape_unicode_sequences(result.memory.title or "")

            # Create structured response
            memory_info = MemoryInfo(
                content=clean_content[:500] + "..."
                if len(clean_content) > 500
                else clean_content,
                title=clean_title,
                importance=result.memory.importance if result.memory.importance is not None else 0.5,
                created_at=result.memory.created_at.strftime("%Y-%m-%d %H:%M"),
            )
            processing_info = ProcessingInfo(
                entities_extracted=len(result.extracted_entities)
                if result.extracted_entities
                else 0,
                labels_applied=len(result.assigned_labels)
                if result.assigned_labels
                else 0,
                source=app_source,
            )
            response_data = MemoryAddResponse(
                status="success", memory=memory_info, processing=processing_info
            )

            response_json = response_data.model_dump_json(exclude_none=False)
            logger.info(
                "MCP_RESPONSE", method="memory_add", app=app_source, response=response_json
            )
            
            # Notify UI of data change (MCP-triggered)
            # Use "memory_created_with_labels" when labels were assigned so the
            # frontend invalidates the labels query cache (change_type must
            # contain "label" for useMCPInvalidation to refetch labels).
            mem_change_type = "memory_created"
            if result.assigned_labels:
                mem_change_type = "memory_created_with_labels"
            log_data_change(
                change_type=mem_change_type,
                entity_type="memory",
                entity_id=result.memory.id,
                details={"source": "mcp", "app": app_source},
            )
            
            return response_data.model_dump()

        except Exception as e:
            logger.error("Memory creation failed", content=content[:50], error=str(e))
            # Create a minimal error response structure
            error_memory = MemoryInfo(
                content="", title=None, importance=0.0, created_at=""
            )
            error_processing = ProcessingInfo(
                entities_extracted=0, labels_applied=0, source=app_source
            )
            error_response = MemoryAddResponse(
                status="error", memory=error_memory, processing=error_processing
            )
            logger.info(
                "MCP_RESPONSE",
                method="memory_add",
                app=app_source,
                response=error_response.model_dump_json(),
            )
            return error_response.model_dump()

    @mcp.tool(
        name="memory_update",
        description="Update memory fields (content, title, importance, labels)",
        tags={"memory", "update", "modify"},
        annotations=ToolAnnotations(
            readOnlyHint=False,  # This tool modifies data
            destructiveHint=False,  # Updates existing data, doesn't destroy
            idempotentHint=True,  # Same update call should have same result
            openWorldHint=False,  # Closed domain - only affects local knowledge base
        ),
    )
    async def memory_update(  # type: ignore
        memory_id: Annotated[
            str,
            Field(
                description="Memory ID from search results",
                min_length=1,
                examples=["mem_abc123"],
            ),
        ],
        title: Annotated[
            Optional[str],
            Field(
                description="Update title (None to keep current)",
                max_length=200,
                examples=["Updated Python Patterns"],
            ),
        ] = None,
        content: Annotated[
            Optional[str],
            Field(
                description="Update content (None to keep current)",
                max_length=32768,
                examples=["Updated async patterns with examples"],
            ),
        ] = None,
        importance: Annotated[
            Optional[float],
            Field(
                description="Update importance 0.0-1.0 (null to keep current). Example: 0.8",
            ),
        ] = None,
        labels: Annotated[
            Optional[str],
            Field(
                description="Replace labels (None to keep current)",
                examples=["python,async"],
            ),
        ] = None,
    ) -> dict:
        """Implementation updates memory fields and manages label assignments."""
        # Detect source from MCP client headers
        try:
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
        except Exception as e:
            logger.warning("Failed to get app source from headers", headers=str(headers), error=str(e))
            app_source = "mcp_generic"
        # Input validation - use ToolError for client input errors
        if all(field is None for field in [title, content, importance, labels]):
            raise ToolError("At least one field (title, content, importance, or labels) must be provided")

        # Validate and parse importance
        importance_value: Optional[float] = None
        if importance is not None:
            # Pydantic will validate the type and range, but we provide explicit error handling
            try:
                importance_value = float(importance)
                if not (0.0 <= importance_value <= 1.0):
                    raise ToolError("importance must be between 0.0 and 1.0")
            except (ValueError, TypeError):
                raise ToolError(f"importance must be a valid number, got: {type(importance).__name__}")
        # Log the request
        request_data = {
            "memory_id": memory_id,
            "title": title,
            "content": content,
            "importance": importance,
            "labels": labels,
        }
        logger.info(
            "MCP_REQUEST",
            method="memory_update",
            app=app_source,
            request=json.dumps(request_data, separators=(",", ":"), ensure_ascii=False),
        )

        try:
            if not memory_operations:
                error_memory = MemoryInfo(
                    content="", title=None, importance=0.0, created_at=""
                )
                error_updates = UpdateInfo(
                    fields_updated=[], labels_added=0, labels_removed=0
                )
                error_response = MemoryUpdateResponse(
                    status="error", memory=error_memory, updates=error_updates
                )
                logger.info(
                    "MCP_RESPONSE",
                    method="memory_update",
                    app=app_source,
                    response=error_response.model_dump_json(),
                )
                return error_response.model_dump()

            # Get current memory to validate it exists
            current_memory = await memory_operations.get_memory_by_id(memory_id)
            if not current_memory:
                error_memory = MemoryInfo(
                    content="", title=None, importance=0.0, created_at=""
                )
                error_updates = UpdateInfo(
                    fields_updated=[], labels_added=0, labels_removed=0
                )
                error_response = MemoryUpdateResponse(
                    status="error", memory=error_memory, updates=error_updates
                )
                logger.info(
                    "MCP_RESPONSE",
                    method="memory_update",
                    app=app_source,
                    response=error_response.model_dump_json(),
                )
                return error_response.model_dump()

            # Track what fields are being updated
            fields_updated: List[str] = []
            labels_added = 0
            labels_removed = 0

            # Update basic fields (importance, title, content)
            update_request = {}
            if importance_value is not None:
                update_request["importance"] = importance_value
                fields_updated.append("importance")
            if title is not None:
                update_request["title"] = title
                fields_updated.append("title")
            if content is not None:
                update_request["content"] = content
                fields_updated.append("content")

            # Apply basic field updates if any
            if update_request:
                # Handle importance updates specially (importance IS in search index)
                if "importance" in update_request:
                    await memory_operations.db.memory_repo.update_memory_importance(  # type: ignore
                        memory_id, update_request["importance"]
                    )
                    # Sync importance to search index
                    try:
                        memory_for_sync = await memory_operations.get_memory_by_id(memory_id)
                        if memory_for_sync:
                            await sync_memory_to_index(memory_for_sync)  # type: ignore[arg-type]
                    except Exception as sync_error:
                        logger.debug(
                            "Search index sync skipped on importance update",
                            memory_id=memory_id,
                            error=str(sync_error),
                        )
                # Handle title and content updates
                if "title" in update_request or "content" in update_request:
                    memory = await memory_operations.get_memory_by_id(memory_id)
                    if memory:
                        if "title" in update_request:
                            memory.title = update_request["title"]
                        if "content" in update_request:
                            memory.content = update_request["content"]
                        memory.updated_at = datetime.datetime.now(datetime.timezone.utc)
                        await memory_operations.db.memory_repo.update_memory(memory)  # type: ignore

                        # Sync to search index (re-embeds with new content)
                        try:
                            await sync_memory_to_index(memory)  # type: ignore[arg-type]
                        except Exception as sync_error:
                            logger.debug(
                                "Search index sync skipped on MCP memory update",
                                memory_id=memory_id,
                                error=str(sync_error),
                            )
            # Handle label updates if provided
            if labels is not None:
                # Parse labels from comma-separated string
                parsed_labels: List[str] = []
                if isinstance(labels, str):  # type: ignore
                    labels_str = labels.strip()
                    if labels_str.startswith("[") and labels_str.endswith("]"):
                        labels_str = labels_str[1:-1]

                    if "," in labels_str:
                        parsed_labels = [
                            label.strip().strip("\"'")
                            for label in labels_str.split(",")
                            if label.strip()
                        ]
                    else:
                        cleaned_label = labels_str.strip().strip("\"'")
                        if cleaned_label:
                            parsed_labels = [cleaned_label]
                current_labels = (  # type: ignore
                    await memory_operations.db.label_mgr.get_memory_labels(memory_id)  # type: ignore
                )
                current_label_names = {label["name"] for label in current_labels}  # type: ignore
                new_label_names = set(parsed_labels)
                # Calculate additions and removals
                to_add = new_label_names - current_label_names  # type: ignore
                to_remove = current_label_names - new_label_names  # type: ignore
                # Remove old labels
                for label_name in to_remove:  # type: ignore
                    # Find label ID by name
                    all_labels = await memory_operations.db.label_mgr.list_labels(  # type: ignore
                        limit=1000
                    )
                    label_id = None
                    for label in all_labels:  # type: ignore
                        if label["name"] == label_name:
                            label_id = label["id"]  # type: ignore
                            break

                    if label_id:
                        await memory_operations.db.label_mgr.remove_label_from_memory(  # type: ignore
                            memory_id, label_id
                        )
                        labels_removed += 1
                # Add new labels
                for label_name in to_add:
                    await memory_operations.db.label_mgr.assign_label_to_memory(  # type: ignore
                        memory_id, label_name
                    )
                    labels_added += 1
                fields_updated.append("labels")  # type: ignore
            # Get updated memory for response
            updated_memory = await memory_operations.get_memory_by_id(memory_id)
            if not updated_memory:
                error_memory = MemoryInfo(
                    content="", title=None, importance=0.0, created_at=""
                )
                error_updates = UpdateInfo(
                    fields_updated=[], labels_added=0, labels_removed=0
                )
                error_response = MemoryUpdateResponse(
                    status="error", memory=error_memory, updates=error_updates
                )
                return error_response.model_dump()
            # Unescape Unicode sequences in the response
            clean_content = unescape_unicode_sequences(updated_memory.content)
            clean_title = unescape_unicode_sequences(updated_memory.title or "")
            # Create structured response
            memory_info = MemoryInfo(
                content=clean_content[:500] + "..."
                if len(clean_content) > 500
                else clean_content,
                title=clean_title,
                importance=updated_memory.importance if updated_memory.importance is not None else 0.5,
                created_at=updated_memory.created_at.strftime("%Y-%m-%d %H:%M"),
            )
            update_info = UpdateInfo(
                fields_updated=fields_updated,
                labels_added=labels_added,
                labels_removed=labels_removed,
            )

            response_data = MemoryUpdateResponse(
                status="success", memory=memory_info, updates=update_info
            )

            response_json = response_data.model_dump_json(exclude_none=False)
            logger.info(
                "MCP_RESPONSE",
                method="memory_update",
                app=app_source,
                response=response_json,
            )
            
            # Notify UI of data change (MCP-triggered)
            change_type = "memory_updated"
            if labels_added > 0 or labels_removed > 0:
                change_type = "memory_updated_with_labels"
            log_data_change(
                change_type=change_type,
                entity_type="memory",
                entity_id=memory_id,
                details={"source": "mcp", "app": app_source, "labels_added": labels_added, "labels_removed": labels_removed},
            )
            
            return response_data.model_dump()

        except Exception as e:
            logger.error("Memory update failed", memory_id=memory_id, error=str(e))
            error_memory = MemoryInfo(
                content="", title=None, importance=0.0, created_at=""
            )
            error_updates = UpdateInfo(
                fields_updated=[], labels_added=0, labels_removed=0
            )
            error_response = MemoryUpdateResponse(
                status="error", memory=error_memory, updates=error_updates
            )
            logger.info(
                "MCP_RESPONSE",
                method="memory_update",
                app=app_source,
                response=error_response.model_dump_json(),
            )
            return error_response.model_dump()

    @mcp.tool(
        name="memory_delete",
        description="Delete one or more memories by ID",
        tags={"memory", "delete", "remove"},
        annotations=ToolAnnotations(
            readOnlyHint=False,  # This tool modifies data
            destructiveHint=True,  # This permanently deletes data
            idempotentHint=True,  # Same delete call will have same result
            openWorldHint=False,  # Closed domain - only affects local knowledge base
        ),
    )
    async def memory_delete(  # type: ignore
        memory_id: Annotated[
            Optional[str],
            Field(
                description="Memory ID to delete (single delete mode)",
            ),
        ] = None,
        memory_ids: Annotated[
            Optional[List[str]],
            Field(
                description="List of memory IDs to delete in bulk mode",
            ),
        ] = None,
    ) -> dict:
        """Delete one memory or multiple memories (bulk)."""
        app_source = "mcp_unknown"
        headers = {}
        try:
            headers = get_http_headers()
            app_source = get_app_source_from_headers(headers)
        except Exception as e:
            logger.warning("Failed to get app source from headers", headers=str(headers), error=str(e))
            app_source = "mcp_generic"

        requested_ids: List[str] = []
        if memory_id is not None:
            requested_ids.append(memory_id)
        if memory_ids:
            requested_ids.extend(memory_ids)

        # Preserve input order while removing empty IDs and duplicates.
        normalized_memory_ids: List[str] = []
        seen_memory_ids: set[str] = set()
        for raw_id in requested_ids:
            clean_id = raw_id.strip()
            if not clean_id or clean_id in seen_memory_ids:
                continue
            normalized_memory_ids.append(clean_id)
            seen_memory_ids.add(clean_id)

        is_bulk_request = memory_ids is not None or len(normalized_memory_ids) > 1

        request_data = {
            "memory_id": memory_id,
            "memory_ids": memory_ids,
            "normalized_memory_ids": normalized_memory_ids,
        }
        logger.info(
            "MCP_REQUEST",
            method="memory_delete",
            app=app_source,
            request=json.dumps(request_data, separators=(",", ":"), ensure_ascii=False),
        )
        try:
            if not memory_operations:
                if is_bulk_request:
                    error_response = BulkMemoryDeleteResponse(
                        status="error",
                        message="Services not initialized",
                        summary=BulkDeletionSummary(
                            requested_count=len(requested_ids),
                            processed_count=0,
                            deleted_count=0,
                            failed_count=0,
                            deleted_relationships=0,
                            deleted_entities=0,
                        ),
                        results=[],
                    )
                else:
                    error_response = MemoryDeleteResponse(
                        status="error",
                        message="Services not initialized",
                        deletion=None,
                    )
                logger.info(
                    "MCP_RESPONSE",
                    method="memory_delete",
                    app=app_source,
                    response=error_response.model_dump_json(),
                )
                return error_response.model_dump()

            if not normalized_memory_ids:
                error_response = MemoryDeleteResponse(
                    status="error",
                    message="Provide memory_id or memory_ids",
                    deletion=None,
                )
                logger.info(
                    "MCP_RESPONSE",
                    method="memory_delete",
                    app=app_source,
                    response=error_response.model_dump_json(),
                )
                return error_response.model_dump()

            if not is_bulk_request and len(normalized_memory_ids) == 1:
                target_memory_id = normalized_memory_ids[0]
                result = await memory_operations.delete_memory(memory_id=target_memory_id)
                if not result.get("deleted", False):
                    error_message = result.get("error", "Memory not found or deletion failed")
                    error_response = MemoryDeleteResponse(
                        status="error", message=error_message, deletion=None
                    )
                    logger.info(
                        "MCP_RESPONSE",
                        method="memory_delete",
                        app=app_source,
                        response=error_response.model_dump_json(),
                    )
                    return error_response.model_dump()

                deletion_info = DeletionInfo(
                    deleted_relationships=result.get("deleted_relationships", 0),
                    deleted_entities=result.get("deleted_entities", 0),
                )
                success_response = MemoryDeleteResponse(
                    status="success",
                    message=f"Memory {target_memory_id} deleted successfully",
                    deletion=deletion_info,
                )
                response_json = success_response.model_dump_json(exclude_none=False)
                logger.info(
                    "MCP_RESPONSE",
                    method="memory_delete",
                    app=app_source,
                    response=response_json,
                )

                # Notify UI of data change (MCP-triggered)
                log_data_change(
                    change_type="memory_deleted",
                    entity_type="memory",
                    entity_id=target_memory_id,
                    details={"source": "mcp", "app": app_source},
                )

                return success_response.model_dump()

            bulk_result = await memory_operations.bulk_delete_memories(
                memory_ids=normalized_memory_ids
            )

            item_results: List[BulkDeleteItem] = []
            for item in bulk_result.get("results", []):
                item_memory_id = item.get("memory_id", "")
                if item.get("deleted", False):
                    deletion_info = DeletionInfo(
                        deleted_relationships=item.get("deleted_relationships", 0),
                        deleted_entities=item.get("deleted_entities", 0),
                    )
                    item_results.append(
                        BulkDeleteItem(
                            memory_id=item_memory_id,
                            status="success",
                            message=f"Memory {item_memory_id} deleted successfully",
                            deletion=deletion_info,
                        )
                    )
                    log_data_change(
                        change_type="memory_deleted",
                        entity_type="memory",
                        entity_id=item_memory_id,
                        details={"source": "mcp", "app": app_source, "bulk": True},
                    )
                else:
                    error_message = item.get("error", "Memory not found or deletion failed")
                    normalized_error = error_message.lower() if isinstance(error_message, str) else ""
                    item_status = "not_found" if "not found" in normalized_error else "error"
                    item_results.append(
                        BulkDeleteItem(
                            memory_id=item_memory_id,
                            status=item_status,
                            message=error_message,
                            deletion=None,
                        )
                    )

            deleted_count = bulk_result.get("deleted_count", 0)
            failed_count = bulk_result.get("failed_count", 0)
            processed_count = bulk_result.get("processed_count", len(normalized_memory_ids))

            if deleted_count == processed_count and processed_count > 0:
                bulk_status = "success"
            elif deleted_count > 0:
                bulk_status = "partial_success"
            else:
                bulk_status = "error"

            bulk_response = BulkMemoryDeleteResponse(
                status=bulk_status,
                message=f"Deleted {deleted_count} memories, {failed_count} failed",
                summary=BulkDeletionSummary(
                    requested_count=bulk_result.get("requested_count", len(requested_ids)),
                    processed_count=processed_count,
                    deleted_count=deleted_count,
                    failed_count=failed_count,
                    deleted_relationships=bulk_result.get("total_deleted_relationships", 0),
                    deleted_entities=bulk_result.get("total_deleted_entities", 0),
                ),
                results=item_results,
            )

            response_json = bulk_response.model_dump_json(exclude_none=False)
            logger.info(
                "MCP_RESPONSE",
                method="memory_delete",
                app=app_source,
                response=response_json[:1000] + "..." if len(response_json) > 1000 else response_json,
            )
            return bulk_response.model_dump()

        except Exception as e:
            logger.error(
                "Memory deletion failed",
                memory_id=memory_id,
                memory_ids=memory_ids,
                error=str(e),
            )
            if is_bulk_request:
                error_response = BulkMemoryDeleteResponse(
                    status="error",
                    message=f"Failed to delete memories: {str(e)}",
                    summary=BulkDeletionSummary(
                        requested_count=len(requested_ids),
                        processed_count=len(normalized_memory_ids),
                        deleted_count=0,
                        failed_count=len(normalized_memory_ids),
                        deleted_relationships=0,
                        deleted_entities=0,
                    ),
                    results=[
                        BulkDeleteItem(
                            memory_id=mid,
                            status="error",
                            message=f"Failed to delete memory: {str(e)}",
                            deletion=None,
                        )
                        for mid in normalized_memory_ids
                    ],
                )
            else:
                error_response = MemoryDeleteResponse(
                    status="error",
                    message=f"Failed to delete memory: {str(e)}",
                    deletion=None,
                )
            logger.info(
                "MCP_RESPONSE",
                method="memory_delete",
                app=app_source,
                response=error_response.model_dump_json(),
            )
            return error_response.model_dump()
