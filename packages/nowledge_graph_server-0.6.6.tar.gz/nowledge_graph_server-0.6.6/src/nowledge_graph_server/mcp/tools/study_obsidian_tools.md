# Obsidian Vault Integration

## Overview

This module provides Obsidian vault search and analysis capabilities for the MCP server.
We use a **custom lightweight implementation** (`obsidian_vault.py`) instead of the
third-party `obsidiantools` library.

## Performance Highlights

- **Indexing**: ~0.4ms per note (1,940 notes in 770ms)
- **Search**: 0.01-1ms per search (6-13x faster with pre-computed lowercase index)
- **Memory**: ~8KB per note
- **Scalability**: Linear O(n), tested with 50K+ note projections
- **Thread-safe**: Singleton pattern with double-checked locking

## Why Custom Implementation?

The original `obsidiantools` library has several issues:

### Heavy Dependencies
- `networkx` - Graph library (only used for link tracking we don't need)
- `pandas` - DataFrame library (only used for metadata we don't need)
- `numpy` - Numeric library (only used for array operations we can do in pure Python)
- `markdown` + `pymdown-extensions` - HTML conversion (overkill for our needs)
- `html2text`, `beautifulsoup4`, `lxml`, `bleach` - HTML processing

### iCloud Compatibility Issues
- Does not handle iCloud placeholder files (`.icloud` suffix)
- Path resolution fails with cloud-synced directories
- No graceful handling of offline/unavailable files

## Our Implementation: `obsidian_vault.py`

### Features
- **Zero heavy dependencies**: Pure Python with only `structlog` for logging
- **iCloud compatible**: Handles `.icloud` placeholders and offline files gracefully
- **Fast**: Lazy loading and efficient file iteration
- **Robust**: Graceful error handling for permission issues and cloud syncing

### Supported Features
- File scanning with subdirectory filtering
- Wikilink extraction (`[[Note]]`, `[[Note|alias]]`, `[[Note#header]]`)
- Tag extraction (`#tag`, `#nested/tag`)
- Embedded file extraction (`![[image.png]]`)
- YAML front matter parsing
- Backlink tracking
- Source text and readable text retrieval
- Nonexistent and isolated note detection

### API Compatibility
The `ObsidianVault` class is API-compatible with `obsidiantools.Vault`:

```python
from nowledge_graph_server.mcp.tools.obsidian_vault import ObsidianVault

vault = ObsidianVault(Path("/path/to/vault"))
vault.connect(show_nested_tags=True)
vault.gather()

# Access indices
vault.md_file_index      # dict[note_name, rel_path]
vault.tags_index         # dict[note_name, list[tag]]
vault.wikilinks_index    # dict[note_name, list[link]]
vault.backlinks_index    # dict[note_name, list[note]]
vault.front_matter_index # dict[note_name, dict]
vault.source_text_index  # dict[note_name, str]
vault.readable_text_index # dict[note_name, str]

# Access methods
vault.get_wikilinks(note_name)
vault.get_backlinks(note_name)
vault.get_embedded_files(note_name)
vault.get_front_matter(note_name)
vault.get_tags(note_name)
vault.get_source_text(note_name)
vault.get_readable_text(note_name)

# Properties
vault.nonexistent_notes  # Notes referenced but not created
vault.isolated_notes     # Notes with no links in or out
```

## Regex Patterns

Based on patterns from obsidiantools, adapted for pure Python:

### Wikilinks
```python
WIKILINK_REGEX = r'(!)?\[{2}([^\]\]]+)\]{2}'
# Captures: (embed_marker, link_content)
# [[Note]] -> ('', 'Note')
# ![[embed.png]] -> ('!', 'embed.png')
```

### Tags
```python
TAG_REGEX = r'(?<![\\])#([a-zA-Z][a-zA-Z0-9_\-/]*)'
# Matches: #tag, #nested/tag
# Ignores: escaped \#tag, inside code blocks
```

### Front Matter
```python
FRONT_MATTER_REGEX = r'^---\s*\n(.*?)\n---\s*\n'
# Matches YAML block at start of file
```

## iCloud Handling

### Placeholder Files
When files aren't downloaded locally on iCloud, they appear as:
```
.filename.md.icloud  (instead of filename.md)
```

Our implementation:
1. Detects placeholder files and skips them
2. Continues gracefully when files can't be read
3. Returns empty data for unavailable files instead of crashing

### Path Resolution
We handle cases where `Path.resolve()` fails on cloud directories:
```python
try:
    vault_dir = Path(vault_path).expanduser().resolve()
except (OSError, RuntimeError):
    vault_dir = Path(vault_path).expanduser()
```

## MCP Tools

### `obsidian_search`
Search notes by text, tags, or title:
- Auto-connects to vault on first use
- Caches vault connection for performance
- Returns snippets, tags, and link counts

### `obsidian_get_note`
Get full note content and metadata:
- Returns readable or source text
- Includes front matter, tags, links

## Testing

Run tests:
```bash
cd nowledge-graph-py
PYTHONPATH=src python3 -m pytest tests/test_obsidian_vault.py -v
```

Or quick validation:
```bash
PYTHONPATH=src python3 -c "
from nowledge_graph_server.mcp.tools.obsidian_vault import ObsidianVault
import tempfile
from pathlib import Path

with tempfile.TemporaryDirectory() as d:
    v = Path(d) / 'vault'
    v.mkdir()
    (v / 'Note.md').write_text('# Test\n[[Link]] #tag')
    vault = ObsidianVault(v).connect()
    print(vault.get_wikilinks('Note'))  # ['Link']
    print(vault.get_tags('Note'))       # ['tag']
"
```

## References

- Original obsidiantools: https://github.com/mfarragher/obsidiantools
- Obsidian file format: https://help.obsidian.md/
- iCloud file behavior: Apple Developer Documentation
