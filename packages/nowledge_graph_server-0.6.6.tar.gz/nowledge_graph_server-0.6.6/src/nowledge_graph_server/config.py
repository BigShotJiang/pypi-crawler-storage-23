"""Configuration management for Nowledge Graph server."""

import os
import sys
import platform as plat_module
from pathlib import Path
from typing import Optional, Dict, List

# CRITICAL: Configure UTF-8 encoding on Windows BEFORE any print statements
# This must be the FIRST thing we do to avoid encoding errors
if plat_module.system() == "Windows":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")  # type: ignore
    os.environ["PYTHONIOENCODING"] = "utf-8"

# Set persistent cache for fast-langdetect language detection model.
# Default caches to volatile /tmp/ which is lost on reboot.
# Must be set before fast_langdetect is imported to take effect.
if "FTLANG_CACHE" not in os.environ:
    if getattr(sys, "frozen", False):
        _ftlang_cache = str(Path(sys.executable).parent / "cache" / "langdetect")
    else:
        _ftlang_cache = str(Path.home() / ".cache" / "nowledge-graph" / "langdetect")
    os.environ["FTLANG_CACHE"] = _ftlang_cache

# CRITICAL: Disable HuggingFace XET (Git LFS) system before any HF imports
# This prevents duplicate storage in ~/.cache/huggingface/xet/ directory
# Must be set before huggingface_hub is imported anywhere in the application
# See: https://github.com/huggingface/huggingface_hub/issues/3266
if "HF_HUB_DISABLE_XET" not in os.environ:
    os.environ["HF_HUB_DISABLE_XET"] = "1"
    print("Disabled HuggingFace XET (Git LFS) to prevent duplicate storage")

# CRITICAL: Set offline mode for non-Apple-Silicon platforms to prevent
# runtime HuggingFace API calls. FastEmbed and related libraries may still
# try to check HuggingFace metadata even with local files.
_IS_APPLE_SILICON = (
    plat_module.system() == "Darwin" and plat_module.machine() == "arm64"
)
if not _IS_APPLE_SILICON:
    if "HF_HUB_OFFLINE" not in os.environ:
        os.environ["HF_HUB_OFFLINE"] = "1"
        print("Set HF_HUB_OFFLINE=1 for non-Apple-Silicon offline mode")
    if "TRANSFORMERS_OFFLINE" not in os.environ:
        os.environ["TRANSFORMERS_OFFLINE"] = "1"
        print("Set TRANSFORMERS_OFFLINE=1 for non-Apple-Silicon offline mode")

from pydantic import Field
from pydantic_settings import BaseSettings


def get_default_embedding_model() -> str:
    """Get default embedding model - platform-specific for optimal performance.

    Uses the same models as search embedding:
    - macOS Apple Silicon: Qwen3-Embedding via MLX (1024-dim)
    - non-Apple-Silicon (Windows/Linux/macOS Intel): BGE-M3 via ONNX (1024-dim)

    Returns:
        str: Default model name for this platform
    """
    import platform
    IS_APPLE_SILICON = platform.system() == "Darwin" and platform.machine() == "arm64"

    if IS_APPLE_SILICON:
        return "mlx-community/Qwen3-Embedding-0.6B-4bit-DWQ"
    else:
        return "BAAI/bge-m3"


def get_default_huggingface_cache() -> Path:
    """Get the default HuggingFace cache directory (same as HF default)."""
    # Use the same logic as HuggingFace Hub
    hf_home = os.environ.get("HF_HOME")
    if hf_home:
        return Path(hf_home) / "hub"

    # Default to ~/.cache/huggingface/hub (standard HF location)
    return Path.home() / ".cache" / "huggingface" / "hub"


def get_app_cache_dir(cache_type: str = "models") -> Path:
    """
    Get appropriate cache directory for self-contained apps.

    For bundled/packaged apps, use a cache directory relative to the executable.
    For development, use the standard user cache directory.

    Args:
        cache_type: Type of cache ("models", "embeddings", "llm", etc.)

    Returns:
        Path to cache directory
    """
    # For LLM models, always use standard HuggingFace cache to avoid re-downloads
    if cache_type == "llm":
        return get_default_huggingface_cache().parent  # Returns ~/.cache/huggingface

    # Check if we're in a bundled/packaged app
    if getattr(sys, "frozen", False):
        # We're in a bundled app (PyInstaller, cx_Freeze, etc.)
        app_dir = Path(sys.executable).parent
        cache_dir = app_dir / "cache" / cache_type
    else:
        # Check for PyInstaller's _MEIPASS attribute
        meipass = getattr(sys, "_MEIPASS", None)
        if meipass:
            # We're in a PyInstaller bundle
            app_dir = Path(meipass).parent
            cache_dir = app_dir / "cache" / cache_type
        else:
            # Development mode - use user cache directory
            cache_dir = Path.home() / ".cache" / "nowledge-graph" / cache_type

    # Ensure cache directory exists
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir


def get_default_cache_dirs() -> Dict[str, str]:
    """Get default cache directories for different components."""
    return {
        "embedding_cache_dir": str(get_app_cache_dir("embeddings")),
        "llm_cache_dir": str(
            get_default_huggingface_cache().parent
        ),  # Use standard HF cache
    }


class Settings(BaseSettings):
    """Application settings."""

    # Database configuration
    database_path: Path = Field(
        default=Path("./data/nowledge_graph.db"),
        description="Path to database directory (can be overridden by NOWLEDGE_DB_PATH env var)",
    )

    def __init__(self, **kwargs):
        """Initialize settings and apply NOWLEDGE_DB_PATH override if set."""
        super().__init__(**kwargs)
        # Apply NOWLEDGE_DB_PATH override after initialization
        db_path_env = os.environ.get("NOWLEDGE_DB_PATH")
        if db_path_env:
            self.database_path = Path(db_path_env)

    # Migration configuration
    auto_migrate_on_startup: bool = Field(
        default=True,
        description="Auto-apply migrations on startup (disable in production)",
    )
    fail_on_migration_error: bool = Field(
        default=True,
        description="Fail startup if migration fails",
    )
    migration_timeout: int = Field(
        default=300,
        description="Migration timeout in seconds",
    )

    # API configuration
    api_host: str = Field(default="127.0.0.1", description="API host")
    api_port: int = Field(default=8000, description="API port")
    api_debug: bool = Field(default=False, description="Enable debug mode")

    # Embedding service configuration
    embedding_model: str = Field(
        default_factory=get_default_embedding_model,
        description="Embedding model name (Qwen3-Embedding on macOS Apple Silicon, BGE-M3 on non-Apple-Silicon platforms)",
    )
    embedding_device: str = Field(
        default="cpu", description="Device for embedding computation (cpu/cuda/mps)"
    )
    embedding_dimension: int = Field(
        default=1024, description="Embedding vector dimension"
    )
    embedding_cache_only: bool = Field(
        default=False,  # Allow downloading for development; set to True for offline deployment
        description="Use only cached embedding models (don't download automatically)",
    )
    embedding_cache_dir: Optional[str] = Field(
        default_factory=lambda: get_default_cache_dirs()["embedding_cache_dir"],
        description="Local cache directory for embedding models",
    )
    embedding_force_download: bool = Field(
        default=False,  # Never force download in packaged apps
        description="Force download models even if cached",
    )

    # LLM service configuration (for entity extraction and summarization)
    llm_provider_priority: List[str] = Field(
        default=["anthropic", "openai", "local"],
        description="Priority order for LLM providers",
    )
    llm_model_override: Optional[str] = Field(
        default=None, description="Override default LLM model selection"
    )
    llm_timeout: int = Field(default=30, description="LLM request timeout in seconds")
    llm_max_retries: int = Field(
        default=2, description="Maximum number of LLM request retries"
    )
    llm_cache_dir: Optional[str] = Field(
        default_factory=lambda: get_default_cache_dirs()["llm_cache_dir"],
        description="Local cache directory for LLM models (uses standard HuggingFace cache)",
    )
    llm_cache_only: bool = Field(
        default=True,  # Changed to True - don't auto-download on startup, require user action
        description="Use only cached LLM models (don't download automatically on startup)",
    )
    llm_required_for_startup: bool = Field(
        default=False,  # Don't require LLM for API startup
        description="Whether LLM models are required for API startup (False = optional)",
    )

    # Note: HuggingFace models are cached within llm_cache_dir/huggingface/hub/

    # Entity extraction configuration
    entity_extraction_method: str = Field(
        default="llm",  # "llm", "pattern", or "hybrid"
        description="Entity extraction method: llm (LLM-based), pattern (spaCy+patterns), or hybrid (both)",
    )
    entity_model: str = Field(
        default="en_core_web_sm",
        description="spaCy model for entity extraction (fallback/pattern mode)",
    )
    entity_extraction_enabled: bool = Field(
        default=True, description="Enable automatic entity extraction"
    )
    entity_linking_enabled: bool = Field(
        default=True, description="Enable entity linking to external knowledge bases"
    )
    entity_min_confidence: float = Field(
        default=0.5, description="Minimum confidence threshold for entity extraction"
    )
    entity_multilingual_enabled: bool = Field(
        default=True, description="Enable multilingual entity extraction"
    )
    entity_max_per_request: int = Field(
        default=50, description="Maximum entities to extract per request"
    )

    # Logging configuration
    log_level: str = Field(default="INFO", description="Logging level")
    log_json: bool = Field(default=False, description="Use JSON logging format")

    model_config = {
        "env_prefix": "NOWLEDGE_",
        "case_sensitive": False,
        "env_file": [".env", "config.env"],
        "env_file_encoding": "utf-8",
        "extra": "ignore",  # Allow extra fields like HF_HOME, HUGGINGFACE_HUB_CACHE
    }

    @property
    def is_production(self) -> bool:
        """Check if running in production environment."""
        import os

        return os.getenv("ENVIRONMENT", "development").lower() == "production"


# Global settings instance
_settings: Optional[Settings] = None


def get_settings() -> Settings:
    """Get application settings (singleton)."""
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


def reload_settings() -> Settings:
    """Reload settings from environment."""
    global _settings
    _settings = Settings()
    return _settings
