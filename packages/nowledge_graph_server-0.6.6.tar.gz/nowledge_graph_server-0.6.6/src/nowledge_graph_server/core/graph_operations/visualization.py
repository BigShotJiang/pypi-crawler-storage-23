"""Graph visualization methods - main graph data methods."""

from typing import Any, Dict, List, Optional, Tuple, Set
import real_ladybug as kuzu
import structlog
from nowledge_graph_server.database.kuzu_client import KuzuClient
from nowledge_graph_server.core.graph_operations.base import GraphOperationsBase

logger = structlog.get_logger(__name__)


class GraphVisualizationMixin(GraphOperationsBase):
    """Mixin for graph visualization and main graph data methods."""

    kuzu_client: KuzuClient

    def _process_path_results(
        self,
        result: Any,  # Accept kuzu.QueryResult or compatible object
        center_node_id: Optional[str] = None,
        context: str = "unified"
    ) -> Tuple[list[Any], list[Any]]:
        """
        Process KuzuDB path query results into nodes and edges.

        Uses the exact logic from expand neighbors implementation.
        """
        nodes: list[Any] = []
        edges: list[Any] = []
        seen_nodes: set[str] = set()
        seen_edges: set[str] = set()

        try:
            while result.has_next():
                row = result.get_next()
                path = row[0]  # type: ignore - The full path object
                path_length = row[1]  # type: ignore - Number of hops
                path_nodes = row[2]  # type: ignore - All nodes in path
                path_rels = row[3]  # type: ignore - All relationships in path

                # Process nodes from the path (exact logic from expand neighbors)
                for node in path_nodes:
                    try:
                        # KuzuDB NODE structure: returned as dictionary
                        node_id_val = node.get("id") or str(
                            node.get("_ID", {}).get("offset", "")
                        )

                        if not node_id_val or node_id_val in seen_nodes:
                            continue

                        # Skip Label nodes - they shouldn't be in graph visualization
                        node_labels = (
                            node.get("_LABEL", [])
                            if isinstance(node.get("_LABEL"), list)
                            else [node.get("_LABEL", "Unknown")]
                        )
                        if "Label" in node_labels:
                            logger.debug(
                                "Skipping Label node from expand neighbors",
                                node_id=node_id_val,
                            )
                            continue

                        seen_nodes.add(node_id_val)

                        # Skip the starting node for expansion (we already have it)
                        if center_node_id and node_id_val == center_node_id:
                            continue

                        # Build node using shared method
                        node_data = self._build_node_from_raw_data(  # type: ignore[attr-defined]
                            node,
                            hop_count=path_length,
                            is_entity=bool(node.get("entity_type")),
                            is_memory=bool(node.get("content") or node.get("title")),
                        )

                        if node_data:
                            nodes.append(node_data)  # type: ignore[arg-type]
                            logger.debug(
                                "Processed node",
                                node_id=node_id_val,
                                node_type=node_data["node_type"],
                                label=node_data["label"],
                            )

                    except Exception as e:
                        logger.warning("Failed to process node", error=str(e))

                # Process relationships from the path (exact logic from expand neighbors)
                for rel_idx, rel in enumerate(path_rels):
                    try:
                        # KuzuDB REL structure: returned as dictionary
                        # FIX: real_ladybug uses uppercase _ID for relationships
                        rel_id = str(
                            rel.get("_ID", {}).get("offset", "")
                            if rel.get("_ID")
                            else rel.get("_id", {}).get("offset", "")
                        )

                        if not rel_id or rel_id in seen_edges:
                            continue
                        seen_edges.add(rel_id)

                        # Extract source and target IDs from consecutive nodes in path
                        source_id = None
                        target_id = None

                        if rel_idx < len(path_nodes) - 1:
                            source_node = path_nodes[rel_idx]
                            target_node = path_nodes[rel_idx + 1]

                            source_id = source_node.get("id") or str(
                                source_node.get("_ID", {}).get("offset", "")
                            )
                            target_id = target_node.get("id") or str(
                                target_node.get("_ID", {}).get("offset", "")
                            )

                            # Skip edges that connect to Label nodes (we exclude Label nodes from visualization)
                            target_node_labels = (
                                target_node.get("_LABEL", [])
                                if isinstance(target_node.get("_LABEL"), list)
                                else [target_node.get("_LABEL", "Unknown")]
                            )
                            source_node_labels = (
                                source_node.get("_LABEL", [])
                                if isinstance(source_node.get("_LABEL"), list)
                                else [source_node.get("_LABEL", "Unknown")]
                            )
                            if "Label" in target_node_labels or "Label" in source_node_labels:
                                logger.debug(
                                    "Skipping edge to/from Label node",
                                    source_id=source_id,
                                    target_id=target_id,
                                    edge_type=rel.get("_LABEL"),
                                )
                                continue

                        if not source_id or not target_id:
                            logger.debug(
                                "Skipping edge - missing source/target",
                                edge_type=rel.get("_LABEL"),
                                rel_id=rel_id,
                            )
                            continue

                        # Build edge using shared method
                        # Create each edge with path_length=1 so frontend can handle it
                        # This breaks multi-hop paths into individual edges
                        edge_data = self._build_edge_from_raw_data(  # type: ignore[attr-defined]
                            rel, source_id, target_id, path_length=1
                        )

                        if edge_data:
                            # Store the original path length for reference
                            edge_data["metadata"]["original_path_length"] = path_length
                            edges.append(edge_data)  # type: ignore[arg-type]
                            logger.debug(
                                "Processed edge",
                                edge_id=edge_data["id"],
                                edge_type=edge_data["edge_type"],
                                source=source_id,
                                target=target_id,
                            )

                    except Exception as e:
                        logger.warning("Failed to process relationship", error=str(e))

        except Exception as e:
            logger.error(f"Failed to process {context} path results", error=str(e))

        return nodes, edges

    # === MAIN GRAPH DATA METHODS ===
    # These are the three main methods, now refactored to use elegant unified queries

    async def get_graph_data_for_visualization(
        self, filter_type: Optional[str] = None, limit: int = 50, depth: int = 1
    ) -> Dict[str, Any]:
        """
        Get graph data formatted for visualization with elegant unified query.

        Refactored to use single elegant query similar to expand neighbors,
        while preserving all existing logic and behavior.
        """
        logger.debug(
            "Getting graph data for visualization with unified query",
            filter_type=filter_type,
            limit=limit,
            depth=depth,
        )

        try:
            # Build filter condition
            type_filter = ""
            if filter_type:
                type_filter = f"WHERE n.entity_type = '{filter_type}'"

            # FIXED DEPTH-AWARE QUERY - Avoid path explosion by collecting unique nodes/edges
            # The issue was variable-length paths returning ALL possible paths, causing exponential growth
            # Solution: Use COLLECT to get unique nodes/edges within depth, not all possible paths
            if depth == 1:
                # Optimized query for depth=1 (direct relationships only)
                unified_query = f"""
                    // Get top nodes by importance/pagerank
                    MATCH (n:Entity:Memory)
                    {type_filter}
                    WITH n,
                         CASE
                             WHEN n.pagerank_score IS NOT NULL AND n.pagerank_score > 0 THEN n.pagerank_score
                             WHEN n.importance IS NOT NULL THEN n.importance
                             WHEN n.confidence IS NOT NULL THEN n.confidence
                             ELSE 0.5
                         END AS importance_score,
                         label(n) AS node_category
                    ORDER BY importance_score DESC, node_category
                    LIMIT $limit

                    // Get direct neighbors only
                    OPTIONAL MATCH (n)-[r]-(connected:Entity:Memory)
                    WHERE n <> connected AND LABEL(n) <> "Label"

                    RETURN n AS source_node,
                           connected AS connected_node,
                           r AS relationship,
                           1 AS hop_distance,
                           importance_score,
                           node_category
                    ORDER BY importance_score DESC
                """
            else:
                # For depth > 1, we need to return actual paths but with controlled limits
                unified_query = f"""
                    // Get top nodes by importance/pagerank
                    MATCH (n:Entity:Memory)
                    {type_filter}
                    WITH n,
                         CASE
                             WHEN n.pagerank_score IS NOT NULL AND n.pagerank_score > 0 THEN n.pagerank_score
                             WHEN n.importance IS NOT NULL THEN n.importance
                             WHEN n.confidence IS NOT NULL THEN n.confidence
                             ELSE 0.5
                         END AS importance_score,
                         label(n) AS node_category
                    ORDER BY importance_score DESC, node_category
                    LIMIT $limit

                    // Get paths within depth with strict limits to prevent explosion
                    OPTIONAL MATCH p = (n)-[*1..{depth}]-(connected:Entity:Memory)
                    WHERE n <> connected AND LENGTH(p) <= {depth}

                    // Return path information for visualization
                    RETURN n AS source_node,
                           connected AS connected_node,
                           p AS path,
                           LENGTH(p) AS hop_distance,
                           importance_score,
                           node_category
                    ORDER BY importance_score DESC, hop_distance ASC
                    LIMIT {min(limit * 50, 1000)}  // Strict limit to prevent explosion
                """

            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"
            result = self.kuzu_client.conn.execute(unified_query, {"limit": limit})
            assert isinstance(result, kuzu.QueryResult)

            nodes: List[Dict[str, Any]] = []
            edges: List[Dict[str, Any]] = []
            seen_nodes: Set[str] = set()
            seen_edges: Set[str] = set()
            nodes_metadata = {}  # Store node names for edge metadata

            # Process unified query results with simplified structure
            while result.has_next():
                row = result.get_next()
                source_node = row[0]  # type: ignore
                connected_node = row[1]  # type: ignore - target node or None
                relationship_or_path = row[2]  # type: ignore - direct relationship or path
                hop_distance = row[3]  # type: ignore - distance from source
                importance_score = row[4]  # type: ignore
                node_category = row[5]  # type: ignore

                # Process the source node (high-importance nodes) - only once
                if source_node:
                    source_id = source_node.get("id")
                    if source_id and source_id not in seen_nodes:
                        seen_nodes.add(source_id)

                        # Build source node using shared method
                        node_data = self._build_node_from_raw_data(  # type: ignore[attr-defined]
                            source_node,
                            hop_count=0,  # Source nodes have 0 hops
                            is_entity=(node_category == "entity"),
                            is_memory=(node_category == "memory"),
                        )

                        if node_data:
                            nodes.append(node_data)  # type: ignore[arg-type]
                            # Store node name for edge metadata
                            nodes_metadata[source_id] = node_data["label"]

                # Process connected node and relationship/path
                if connected_node and relationship_or_path and hop_distance > 0:
                    try:
                        # Process the connected node
                        connected_id = connected_node.get("id") or str(
                            connected_node.get("_ID", {}).get("offset", "")
                        )

                        if connected_id and connected_id not in seen_nodes:
                            seen_nodes.add(connected_id)

                            # Build connected node using shared method
                            node_data = self._build_node_from_raw_data(  # type: ignore[attr-defined]
                                connected_node,
                                hop_count=hop_distance,  # Use actual hop distance
                                is_entity=bool(connected_node.get("entity_type")),
                                is_memory=bool(
                                    connected_node.get("content")
                                    or connected_node.get("title")
                                ),
                            )

                            if node_data:
                                nodes.append(node_data)  # type: ignore[arg-type]
                                # Store node name for edge metadata
                                nodes_metadata[connected_id] = node_data["label"]

                        # Process the relationship or path
                        source_id = source_node.get("id") or str(
                            source_node.get("_ID", {}).get("offset", "")
                        )

                        if source_id and connected_id:

                            # Handle different cases: direct relationship vs path
                            if depth == 1:
                                # For depth=1, we have a direct relationship
                                relationship = relationship_or_path

                                # FIX: real_ladybug uses uppercase _ID instead of lowercase _id
                                rel_id = str(
                                    relationship.get("_ID", {}).get("offset", "")
                                    if relationship.get("_ID")
                                    else relationship.get("_ID", {}).get("offset", "")
                                )

                                if rel_id and rel_id not in seen_edges:
                                    seen_edges.add(rel_id)

                                    # Build edge using shared method
                                    # Use path_length=1 for each individual edge
                                    edge_data = self._build_edge_from_raw_data(  # type: ignore[attr-defined]
                                        relationship,
                                        source_id,
                                        connected_id,
                                        path_length=1,
                                    )

                                    if edge_data:
                                        # Add human readable names to edge metadata
                                        edge_data["metadata"]["source_name"] = (
                                            nodes_metadata.get(source_id, source_id)  # type: ignore[arg-type]
                                        )
                                        edge_data["metadata"]["target_name"] = (
                                            nodes_metadata.get(  # type: ignore[arg-type]
                                                connected_id, connected_id
                                            )
                                        )
                                        edge_data["metadata"]["source_id"] = source_id
                                        edge_data["metadata"]["target_id"] = (
                                            connected_id
                                        )

                                        edges.append(edge_data)  # type: ignore[arg-type]
                            else:
                                # For depth>1, we have a path - extract all edges from the path
                                path = relationship_or_path
                                try:
                                    # Get relationships from the path
                                    logger.debug("============== Path ==============\n", path=path)
                                    path_rels: List[Dict[str, Any]] = (
                                        path.get("_RELS", [])
                                        if hasattr(path, "get")
                                        else []
                                    )
                                    path_nodes: List[Dict[str, Any]] = (
                                        path.get("_NODES", [])
                                        if hasattr(path, "get")
                                        else []
                                    )

                                    # Process each relationship in the path
                                    for i, rel in enumerate(path_rels):
                                        if rel and i < len(path_nodes) - 1:
                                            # FIX: real_ladybug uses uppercase _ID for relationships
                                            rel_id = str(
                                                rel.get("_ID", {}).get("offset", "")
                                                if rel.get("_ID")
                                                else rel.get("_id", {}).get("offset", "")
                                            )

                                            if rel_id and rel_id not in seen_edges:
                                                seen_edges.add(rel_id)

                                                # Get source and target for this edge in the path
                                                path_source_node = path_nodes[i]
                                                path_target_node = path_nodes[i + 1]

                                                path_source_id = path_source_node.get(
                                                    "id"
                                                ) or str(
                                                    path_source_node.get("_ID", {}).get(
                                                        "offset", ""
                                                    )
                                                )
                                                path_target_id = path_target_node.get(
                                                    "id"
                                                ) or str(
                                                    path_target_node.get("_ID", {}).get(
                                                        "offset", ""
                                                    )
                                                )

                                                if path_source_id and path_target_id:
                                                    # Build edge using shared method
                                                    # Create each edge with path_length=1 so frontend can handle it
                                                    edge_data = self._build_edge_from_raw_data(  # type: ignore[attr-defined]
                                                            rel,
                                                            path_source_id,
                                                            path_target_id,
                                                            path_length=1,
                                                        )

                                                    if edge_data:
                                                        # Store the original path length for reference
                                                        edge_data["metadata"]["original_path_length"] = hop_distance
                                                        # Add human readable names to edge metadata
                                                        edge_data["metadata"][
                                                            "source_name"
                                                        ] = nodes_metadata.get(  # type: ignore[arg-type]
                                                            path_source_id,
                                                            path_source_id,
                                                        )
                                                        edge_data["metadata"][
                                                            "target_name"
                                                        ] = nodes_metadata.get(  # type: ignore[arg-type]
                                                            path_target_id,
                                                            path_target_id,
                                                        )
                                                        edge_data["metadata"][
                                                            "source_id"
                                                        ] = path_source_id
                                                        edge_data["metadata"][
                                                            "target_id"
                                                        ] = path_target_id
                                                        edge_data["metadata"][
                                                            "path_position"
                                                        ] = i + 1
                                                        edge_data["metadata"][
                                                            "total_path_length"
                                                        ] = len(path_rels)

                                                        edges.append(edge_data)  # type: ignore[arg-type]

                                                        # Also add intermediate nodes if not already added
                                                        for node in [
                                                            path_source_node,
                                                            path_target_node,
                                                        ]:
                                                            node_id = node.get(
                                                                "id"
                                                            ) or str(
                                                                node.get("_ID", {}).get(
                                                                    "offset", ""
                                                                )
                                                            )
                                                            if (
                                                                node_id
                                                                and node_id
                                                                not in seen_nodes
                                                            ):
                                                                seen_nodes.add(node_id)

                                                                node_data = self._build_node_from_raw_data(  # type: ignore[attr-defined]
                                                                    node,
                                                                    hop_count=i + 1,
                                                                    is_entity=bool(
                                                                        node.get(
                                                                            "entity_type"
                                                                        )
                                                                    ),
                                                                    is_memory=bool(
                                                                        node.get(
                                                                            "content"
                                                                        )
                                                                        or node.get(
                                                                            "title"
                                                                        )
                                                                    ),
                                                                )

                                                                if node_data:
                                                                    nodes.append(
                                                                        node_data # type: ignore[arg-type]
                                                                    )
                                                                    nodes_metadata[
                                                                        node_id
                                                                    ] = node_data[
                                                                        "label"
                                                                    ]
                                except Exception as path_error:
                                    logger.warning(
                                        "Failed to process path", error=str(path_error)
                                    )
                                    # Fallback: treat as direct relationship if path processing fails
                                    relationship = relationship_or_path
                                    # FIX: real_ladybug uses uppercase _ID for relationships
                                    rel_id = str(
                                        relationship.get("_ID", {}).get("offset", "")
                                        if relationship.get("_ID")
                                        else relationship.get("_id", {}).get("offset", "")
                                    )

                                    if rel_id and rel_id not in seen_edges:
                                        seen_edges.add(rel_id)

                                        # Use path_length=1 for each individual edge
                                        edge_data = self._build_edge_from_raw_data(  # type: ignore[attr-defined]
                                            relationship,
                                            source_id,
                                            connected_id,
                                            path_length=1,
                                        )

                                        if edge_data:
                                            # Store the original path length for reference (fallback case)
                                            edge_data["metadata"]["original_path_length"] = hop_distance
                                            edge_data["metadata"]["source_name"] = (
                                                nodes_metadata.get(source_id, source_id)  # type: ignore[arg-type]
                                            )
                                            edge_data["metadata"]["target_name"] = (
                                                nodes_metadata.get(  # type: ignore[arg-type]
                                                    connected_id, connected_id
                                                )
                                            )
                                            edge_data["metadata"]["source_id"] = (
                                                source_id
                                            )
                                            edge_data["metadata"]["target_id"] = (
                                                connected_id
                                            )

                                            edges.append(edge_data)  # type: ignore[arg-type]

                    except Exception as e:
                        logger.warning("Failed to process relationship", error=str(e))
            logger.debug(
                "🔢 Graph data for visualization retrieved with unified query",
                nodes=len(nodes),
                edges=len(edges),
            )

            # CONCURRENT EXECUTION: Get communities and other metadata
            # (Keep concurrent execution for non-graph operations as requested)
            async def get_communities() -> List[Dict[str, Any]]:
                """Get community information (preserved from existing implementation)."""
                try:
                    community_query = """
                        MATCH (c:Community)
                        RETURN c.community_id, c.name, c.description, c.ai_summary, c.member_count, c.algorithm, c.resolution
                    """
                    assert self.kuzu_client.conn is not None, (
                        "Kuzu client connection is None"
                    )
                    result = self.kuzu_client.conn.execute(community_query)
                    assert isinstance(result, kuzu.QueryResult)

                    community_list: List[Dict[str, Any]] = []
                    while result.has_next():
                        row = result.get_next()
                        (
                            community_id,
                            name,
                            description,
                            ai_summary,
                            member_count,
                            algorithm,
                            resolution,
                        ) = (
                            row[0],  # type: ignore
                            row[1],  # type: ignore
                            row[2],  # type: ignore
                            row[3],  # type: ignore
                            row[4],  # type: ignore
                            row[5],  # type: ignore
                            row[6],  # type: ignore
                        )

                        # Use the community name directly (exact logic from existing)
                        community_title = name or f"Community {community_id}"
                        community_summary = ai_summary or description or ""

                        # Generate fallback title if name is still generic
                        if (
                            not community_title
                            or community_title == f"Community {community_id}"
                        ):
                            if member_count and member_count > 0:
                                if member_count <= 3:
                                    community_title = "Small Group"
                                elif member_count <= 8:
                                    community_title = "Entity Cluster"
                                else:
                                    community_title = "Entity Network"
                            else:
                                community_title = f"Community {community_id}"

                        community_list.append(
                            {
                                "id": str(community_id),
                                "name": community_title,
                                "description": community_summary or "",
                                "member_count": member_count or 0,
                                "strength": 1.0,
                                "algorithm": algorithm or "louvain",
                                "resolution": resolution or 1.0,
                                "metadata": {
                                    "original_name": name,
                                    "has_ai_summary": ai_summary
                                    and ai_summary.startswith("TITLE:"),
                                    "summary_type": "ai_generated"
                                    if ai_summary and ai_summary.startswith("TITLE:")
                                    else "fallback",
                                },
                            }
                        )
                    return community_list
                except Exception as e:
                    logger.debug(
                        "No communities found or error fetching communities",
                        error=str(e),
                    )
                    return []

            # Execute community query concurrently
            communities = await get_communities()

            # Build community hull data (preserved from existing implementation)
            community_hulls = await self._build_community_hull_data(nodes)  # type: ignore[attr-defined]

            graph_data: Dict[str, Any] = {
                "nodes": nodes,
                "edges": edges,
                "communities": communities,
                "community_hulls": community_hulls,
                "visualization_config": {
                    "node_size_range": [10, 50],
                    "edge_weight_range": [1, 6],
                    "layout_recommendations": {
                        "algorithm": "force-directed"
                        if len(nodes) < 100
                        else "hierarchical",
                        "cluster_by_community": len(communities) > 0,
                        "highlight_high_importance": True,
                    },
                },
                "metadata": {
                    "total_nodes": len(nodes),
                    "total_edges": len(edges),
                    "total_communities": len(communities),
                    "entity_nodes": len(
                        [n for n in nodes if n["node_type"] == "entity"]
                    ),
                    "memory_nodes": len(
                        [n for n in nodes if n["node_type"] == "memory"]
                    ),
                    "relationship_edges": len(
                        [e for e in edges if e["edge_type"] == "RELATES_TO"]
                    ),
                    "mention_edges": len(
                        [e for e in edges if e["edge_type"] == "MENTIONS"]
                    ),
                    "traversal_depth": depth,
                    "query_method": "depth_aware_fixed_query",
                    "filter_type": filter_type,
                },
            }

            logger.debug(
                "Graph data for visualization retrieved with unified query",
                nodes=len(nodes),
                edges=len(edges),
                communities=len(communities),
                depth=depth,
                query_method="unified",
            )

            return graph_data

        except Exception as e:
            logger.error("Failed to get graph data for visualization", error=str(e))
            return {
                "nodes": [],
                "edges": [],
                "communities": [],
                "community_hulls": [],
                "visualization_config": {},
                "metadata": {
                    "total_nodes": 0,
                    "total_edges": 0,
                    "total_communities": 0,
                    "error": str(e),
                },
            }

    async def get_graph_data_for_specific_nodes(
        self,
        memory_ids: Optional[List[str]] = None,
        entity_ids: Optional[List[str]] = None,
        limit: int = 100,
        depth: int = 1,
    ) -> Dict[str, Any]:
        """
        Get graph data for specific sets of nodes using elegant unified query.

        Refactored to use path-based approach similar to expand neighbors
        while preserving all existing logic.
        """
        # Fix None parameter issues
        memory_ids = memory_ids or []
        entity_ids = entity_ids or []

        logger.info(
            "Getting graph data for specific nodes with unified query",
            memory_ids_count=len(memory_ids),
            entity_ids_count=len(entity_ids),
            limit=limit,
            depth=depth,
        )

        try:
            all_node_ids = memory_ids + entity_ids

            if not all_node_ids:
                return self._empty_graph_result()  # type: ignore[attr-defined]

            # ELEGANT UNIFIED QUERY for specific nodes
            specific_nodes_query = f"""
                // Start with specified nodes
                MATCH (seed)
                WHERE seed.id IN $node_ids
                
                // Get paths to connected nodes within depth  
                OPTIONAL MATCH p = (seed)-[*1..{depth}]-(connected:Entity:Memory)
                WHERE seed <> connected
                
                // Return comprehensive results
                RETURN seed as source_node,
                       p,
                       LENGTH(p) as path_length,
                       NODES(p) as path_nodes,
                       RELS(p) as path_rels,
                       CASE 
                           WHEN seed.pagerank_score IS NOT NULL THEN seed.pagerank_score
                           WHEN seed.importance IS NOT NULL THEN seed.importance
                           ELSE 0.5
                       END AS importance_score,
                       CASE
                           WHEN seed:Entity THEN 'entity'
                           WHEN seed:Memory THEN 'memory'
                           ELSE 'unknown'
                       END AS node_category
                ORDER BY importance_score DESC
                LIMIT $limit
            """

            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"
            result = self.kuzu_client.conn.execute(
                specific_nodes_query, {"node_ids": all_node_ids, "limit": limit}
            )
            assert isinstance(result, kuzu.QueryResult)

            nodes: List[Dict[str, Any]] = []
            edges: List[Dict[str, Any]] = []
            seen_nodes: Set[str] = set()
            seen_edges: Set[str] = set()
            nodes_metadata = {}  # Store node names for edge metadata

            # Process specific nodes results (reusing shared processing logic)
            while result.has_next():
                row = result.get_next()
                source_node = row[0]  # type: ignore
                path = row[1]  # type: ignore - Individual path (not collected)
                path_length = row[2]  # type: ignore
                path_nodes = row[3] or []  # type: ignore
                path_rels = row[4] or []  # type: ignore
                importance_score = row[5]  # type: ignore
                node_category = row[6]  # type: ignore

                # Process the source node (specified node)
                if source_node:
                    source_id = source_node.get("id")
                    if source_id and source_id not in seen_nodes:
                        seen_nodes.add(source_id)

                        node_data = self._build_node_from_raw_data(  # type: ignore[attr-defined]
                            source_node,
                            hop_count=0,  # Source nodes have 0 hops
                            is_entity=(node_category == "entity"),
                            is_memory=(node_category == "memory"),
                        )

                        if node_data:
                            nodes.append(node_data)  # type: ignore[arg-type]
                            nodes_metadata[source_id] = node_data["label"]

                # Process path nodes and relationships
                if path and path_nodes and path_rels:
                    # Process nodes from the path
                    for connected_node in path_nodes:  # type: ignore[assignment]
                        if not connected_node:
                            continue

                        connected_id = connected_node.get("id") or str(  # type: ignore[union-attr]
                            connected_node.get("_ID", {}).get("offset", "")  # type: ignore[union-attr]
                        )
                        if (
                            connected_id
                            and connected_id not in seen_nodes
                            and connected_id != source_node.get("id")  # type: ignore[union-attr]
                        ):
                            seen_nodes.add(connected_id)  # type: ignore[arg-type]

                            node_data = self._build_node_from_raw_data(  # type: ignore[attr-defined]
                                connected_node,
                                hop_count=path_length,
                                is_entity=bool(connected_node.get("entity_type")),  # type: ignore[union-attr]
                                is_memory=bool(
                                    connected_node.get("content")  # type: ignore[union-attr]
                                    or connected_node.get("title")  # type: ignore[union-attr]
                                ),
                            )

                            if node_data:
                                nodes.append(node_data)  # type: ignore[arg-type]
                                nodes_metadata[connected_id] = node_data["label"]

                    # Process relationships
                    for rel_idx, rel in enumerate(path_rels):  # type: ignore[assignment]
                        if not rel:
                            continue

                        rel_id = str(rel.get("_ID", {}).get("offset", ""))  # type: ignore[union-attr]
                        if rel_id and rel_id not in seen_edges:
                            seen_edges.add(rel_id)

                            if rel_idx < len(path_nodes) - 1:  # type: ignore[operator]
                                rel_source_id = path_nodes[rel_idx].get("id") or str(  # type: ignore[union-attr]
                                    path_nodes[rel_idx].get("_ID", {}).get("offset", "") # type: ignore[union-attr]
                                )
                                rel_target_id = path_nodes[rel_idx + 1].get(  # type: ignore[union-attr]
                                    "id"
                                ) or str(
                                    path_nodes[rel_idx + 1].get("_ID", {}).get("offset", "")  # type: ignore[union-attr]
                                )

                                if rel_source_id and rel_target_id:
                                    # Create each edge with path_length=1 so frontend can handle it
                                    # This breaks multi-hop paths into individual edges
                                    edge_data = self._build_edge_from_raw_data(  # type: ignore[attr-defined]
                                        rel, rel_source_id, rel_target_id, path_length=1
                                    )

                                    if edge_data:
                                        # Store the original path length for reference
                                        edge_data["metadata"]["original_path_length"] = path_length
                                        # Add human readable names to edge metadata
                                        edge_data["metadata"]["source_name"] = (
                                            nodes_metadata.get(  # type: ignore[arg-type]
                                                rel_source_id, rel_source_id
                                            )
                                        )
                                        edge_data["metadata"]["target_name"] = (
                                            nodes_metadata.get(  # type: ignore[arg-type]
                                                rel_target_id, rel_target_id
                                            )
                                        )
                                        edge_data["metadata"]["source_id"] = (
                                            rel_source_id
                                        )
                                        edge_data["metadata"]["target_id"] = (
                                            rel_target_id
                                        )
                                        edges.append(edge_data)  # type: ignore[arg-type]

            # Get communities concurrently (preserved from existing)
            communities = await self._get_communities_for_search_results()  # type: ignore[attr-defined]

            # Build community hull data
            community_hulls = await self._build_community_hull_data(nodes)  # type: ignore[attr-defined]

            graph_data: Dict[str, Any] = {
                "nodes": nodes,
                "edges": edges,
                "communities": communities,
                "community_hulls": community_hulls,
                "visualization_config": {
                    "node_size_range": [10, 50],
                    "edge_weight_range": [1, 6],
                    "layout_recommendations": {
                        "algorithm": "force-directed"
                        if len(nodes) < 50
                        else "hierarchical",
                        "cluster_by_community": len(communities) > 0,  # type: ignore[arg-type]
                        "highlight_high_importance": True,
                    },
                },
                "metadata": {
                    "total_nodes": len(nodes),
                    "total_edges": len(edges),
                    "total_communities": len(communities),  # type: ignore[arg-type]
                    "entity_nodes": len(
                        [n for n in nodes if n["node_type"] == "entity"]
                    ),
                    "memory_nodes": len(
                        [n for n in nodes if n["node_type"] == "memory"]
                    ),
                    "relationship_edges": len(
                        [e for e in edges if e["edge_type"] == "RELATES_TO"]
                    ),
                    "mention_edges": len(
                        [e for e in edges if e["edge_type"] == "MENTIONS"]
                    ),
                    "traversal_depth": depth,
                    "query_method": "unified_specific_nodes",
                },
            }

            logger.info(
                "Graph data for specific nodes retrieved with unified query",
                nodes=len(nodes),
                edges=len(edges),
                communities=len(communities),  # type: ignore[arg-type]
                depth=depth,
                query_method="unified",
            )

            return graph_data

        except Exception as e:
            logger.error("Failed to get graph data for specific nodes", error=str(e))
            return {
                "nodes": [],
                "edges": [],
                "communities": [],
                "community_hulls": [],
                "visualization_config": {},
                "metadata": {
                    "total_nodes": 0,
                    "total_edges": 0,
                    "total_communities": 0,
                    "error": str(e),
                },
            }

    # === KEEP EXISTING EXPAND NEIGHBORS ===
    # The expand neighbors implementation is already beautiful and elegant,
    # so we keep it as-is but ensure it uses the same result processing methods

    async def expand_neighbors(
        self, node_id: str, depth: int = 1, limit: int = 50
    ) -> Dict[str, Any]:
        """
        Expand neighbors using the current elegant implementation.

        This is kept as-is since it's already the beautiful pattern we want to follow.
        But updated to use shared result processing methods for consistency.
        """
        logger.info(
            "Expanding neighbors with unified query",
            node_id=node_id,
            depth=depth,
            limit=limit,
        )

        try:
            # The elegant single query from current implementation
            path_query = f"""
                MATCH p = (start)-[*1..{depth}]-(neighbor)
                WHERE start.id = $node_id 
                AND start <> neighbor
                RETURN p,
                       LENGTH(p) as path_length,
                       NODES(p) as path_nodes,
                       RELS(p) as path_rels
                ORDER BY path_length ASC, 
                         CASE 
                             WHEN neighbor.importance IS NOT NULL THEN neighbor.importance
                             WHEN neighbor.confidence IS NOT NULL THEN neighbor.confidence
                             ELSE 0.5
                         END DESC
                LIMIT $limit
            """

            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"
            result = self.kuzu_client.conn.execute(
                path_query, {"node_id": node_id, "limit": limit}
            )

            if isinstance(result, list):
                if result:
                    result = result[0]
                else:
                    raise Exception("Empty result list")

            # Use shared result processing method for consistency
            neighbors, edges = self._process_path_results(
                result, center_node_id=node_id, context="expand_neighbors"
            )

            # Subgraph closure: find edges between returned neighbor nodes
            # (e.g. RELATES_TO between entities that are both 1-hop from center)
            neighbor_ids = [n["id"] for n in neighbors if n.get("id")]
            if len(neighbor_ids) >= 2:
                existing_edge_keys = {
                    (e["source"], e["target"], e["edge_type"]) for e in edges
                }
                try:
                    closure_query = """
                        MATCH (a)-[r]->(b)
                        WHERE a.id IN $node_ids AND b.id IN $node_ids
                        RETURN a.id as source_id, b.id as target_id, r
                    """
                    closure_result = self.kuzu_client.conn.execute(
                        closure_query, {"node_ids": neighbor_ids}
                    )
                    if isinstance(closure_result, list) and closure_result:
                        closure_result = closure_result[0]
                    while closure_result.has_next():
                        row = closure_result.get_next()
                        src_id = row[0]
                        tgt_id = row[1]
                        rel = row[2]
                        edge_type = rel.get("_LABEL", "UNKNOWN") if isinstance(rel, dict) else "UNKNOWN"
                        if (src_id, tgt_id, edge_type) not in existing_edge_keys:
                            edge_data = self._build_edge_from_raw_data(
                                rel if isinstance(rel, dict) else {},
                                src_id, tgt_id, path_length=1
                            )
                            if edge_data:
                                edges.append(edge_data)
                                existing_edge_keys.add((src_id, tgt_id, edge_type))
                except Exception as e:
                    logger.debug("Subgraph closure query failed (non-critical)", error=str(e))

            return {
                "center_node": node_id,
                "depth": depth,
                "neighbors": neighbors,
                "edges": edges,
                "total_neighbors": len(neighbors),
                "total_edges": len(edges),
                "metadata": {
                    "expansion_depth": depth,
                    "max_limit": limit,
                    "query_type": "unified_path_query",
                },
            }

        except Exception as e:
            logger.error("Unified expand neighbors failed", error=str(e))
            return {
                "center_node": node_id,
                "neighbors": [],
                "edges": [],
                "metadata": {},
            }
