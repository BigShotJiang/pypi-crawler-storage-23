"""Base GraphOperations class with core functionality."""

from typing import Any, Dict, List, Optional
import real_ladybug as kuzu
import structlog

from ...database.kuzu_client import KuzuClient

logger = structlog.get_logger(__name__)


class GraphOperationsBase:
    """
    Base GraphOperations class with core functionality and shared methods.

    Contains initialization, shared result processing, and core graph operations.
    """

    def __init__(self, kuzu_client: KuzuClient):
        self.kuzu_client = kuzu_client

    async def initialize(self):
        """Initialize graph operations if needed."""
        # Any initialization logic can go here
        pass

    def _serialize_field_value(self, value: Any) -> Any:
        """Serialize field value, converting datetime objects to ISO strings."""
        if hasattr(value, "isoformat"):
            return value.isoformat()
        return value

    def _build_entity_node(
        self, node_dict: Dict[str, Any], hop_count: int
    ) -> Dict[str, Any]:
        """Build entity node using exact logic from existing implementation."""
        entity_id = node_dict.get("id")
        name = node_dict.get("name", "")
        entity_type = node_dict.get("entity_type", "UNKNOWN")
        confidence = node_dict.get("confidence", 0.5)
        if confidence is None:
            confidence = 0.5
        community_id = node_dict.get("community_id")
        pagerank_score = node_dict.get("pagerank_score", 0.0)
        if pagerank_score is None:
            pagerank_score = 0.0

        # Calculate degree (from expand neighbors logic)
        degree = node_dict.get("degree", 1)

        # Use pagerank_score for node sizing if available, fallback to degree
        # (Exact logic from get_graph_data_for_visualization)
        importance = pagerank_score if pagerank_score > 0 else confidence
        node_size = (
            max(15, min(50, importance * 100 + 15))
            if pagerank_score > 0
            else max(15, min(50, degree * 5 + 15))
        )

        # Adjust for hop distance (from expand neighbors)
        hop_penalty = 1.0 / max(hop_count, 1)
        adjusted_importance = importance * hop_penalty
        if hop_count > 0:
            node_size = max(15, min(50, int(adjusted_importance * 60)))

        # Entity type colors (exact from existing implementation)
        entity_colors = {
            "PERSON": "#FF6B6B",
            "ORGANIZATION": "#4ECDC4",
            "TECHNOLOGY": "#45B7D1",
            "CONCEPT": "#96CEB4",
            "LOCATION": "#FFEAA7",
            "PRODUCT": "#DDA0DD",
        }
        node_color = entity_colors.get(entity_type, "#95A5A6")

        return {
            "id": entity_id,
            "label": name,
            "node_type": "entity",
            "node_subtype": entity_type,
            "size": node_size,
            "color": node_color,
            "community": str(community_id) if community_id is not None else None,
            "importance": importance,
            "hop_count": hop_count,
            "pagerank_score": pagerank_score,
            "metadata": {
                "entity_type": entity_type,
                "confidence": confidence,
                "degree": degree,
                "community_id": community_id,
                "pagerank_score": pagerank_score,
                "hop_count": hop_count,
                "created_at": self._serialize_field_value(node_dict.get("created_at")),
                "description": f"{entity_type}: {name} (importance: {importance:.2f})"
                + (f", hops: {hop_count}" if hop_count > 0 else ""),
            },
        }

    def _build_memory_node(
        self, node_dict: Dict[str, Any], hop_count: int
    ) -> Dict[str, Any]:
        """Build memory node using exact logic from existing implementation."""
        memory_id = node_dict.get("id")
        title = node_dict.get("title", "")
        content = node_dict.get("content", "")
        importance = node_dict.get("importance", 0.5)
        if importance is None:
            importance = 0.5
        community_id = node_dict.get("community_id")
        pagerank_score = node_dict.get("pagerank_score", 0.0)
        if pagerank_score is None:
            pagerank_score = 0.0
        entity_count = node_dict.get("entity_count", 0)

        # Display title logic (exact from existing implementation)
        display_title = title or (
            content[:50] + "..." if len(content) > 50 else content
        )

        # Use pagerank_score for node sizing if available, fallback to importance
        # (Exact logic from get_graph_data_for_visualization)
        final_importance = pagerank_score if pagerank_score > 0 else importance

        # Ensure values are numeric before calculations
        final_importance = float(final_importance)
        importance = float(importance)

        # Calculate node size with null checks
        if pagerank_score > 0:
            node_size = max(10, min(40, final_importance * 100 + 10))
        else:
            node_size = max(10, min(40, importance * 40 + 10))
        # Adjust for hop distance (from expand neighbors)
        hop_penalty = 1.0 / max(hop_count, 1)
        adjusted_importance = final_importance * hop_penalty
        if hop_count > 0:
            node_size = max(15, min(50, int(adjusted_importance * 60)))
        content_str = content if content else ""

        return {
            "id": memory_id,
            "label": display_title,
            "node_type": "memory",
            "node_subtype": "memory",
            "size": node_size,
            "color": "#4A90E2",  # Blue for memories
            "community": str(community_id) if community_id is not None else None,
            "importance": final_importance,
            "hop_count": hop_count,
            "pagerank_score": pagerank_score,
            "metadata": {
                "title": title,
                "content": content_str,
                "importance": importance,
                "entity_count": entity_count,
                "community_id": community_id,
                "pagerank_score": pagerank_score,
                "hop_count": hop_count,
                "created_at": self._serialize_field_value(node_dict.get("created_at")),
                "event_start": self._serialize_field_value(node_dict.get("event_start")),
                "event_end": self._serialize_field_value(node_dict.get("event_end")),
                "description": f"Memory: {display_title} (importance: {final_importance:.2f})"
                + (f", hops: {hop_count}" if hop_count > 0 else ""),
            },
        }

    def _build_generic_node(
        self, node_dict: Dict[str, Any], hop_count: int
    ) -> Dict[str, Any]:
        """Build generic node data (community, thread, etc.) using existing logic."""
        node_id = node_dict.get("id") or str(node_dict.get("_ID", {}).get("offset", ""))
        # Determine node type and basic properties
        node_labels = (
            node_dict.get("_LABEL", [])
            if isinstance(node_dict.get("_LABEL"), list)
            else [node_dict.get("_LABEL", "Unknown")]
        )

        # Try to determine node type more intelligently
        node_type = "unknown"
        node_subtype = "unknown"

        if "Community" in node_labels:
            node_type = "Community"
            node_subtype = "community"
        elif "Thread" in node_labels:
            node_type = "Thread"
            node_subtype = "thread"
        elif "Label" in node_labels:
            node_type = "Label"
            node_subtype = "label"
        elif "Source" in node_labels or node_dict.get("source_type"):
            node_type = "Source"
            node_subtype = node_dict.get("source_type", "file")
        elif node_dict.get("community_id") is not None:
            node_type = "Community"
            node_subtype = "community"
        elif node_dict.get("thread_id"):  # Check for thread_id field
            node_type = "Thread"
            node_subtype = "thread"
        else:
            # Fallback to first available label
            node_type = (
                node_labels[0]
                if node_labels and node_labels[0] != "Unknown"
                else "unknown"
            )
            node_subtype = node_type.lower()

        # Build display name with context awareness
        if node_type == "Community":
            community_id = node_dict.get("community_id", "unknown")
            name = node_dict.get("name") or f"Community {community_id}"
            member_count = node_dict.get("member_count", 0)
            display_label = f"{name} ({member_count} members)"
        elif node_type == "Thread":
            thread_title = node_dict.get("title", "Untitled Thread")
            message_count = node_dict.get("message_count", 0)
            display_label = f"{thread_title} ({message_count} messages)"
        elif node_type == "Label":
            display_label = node_dict.get("name", "Unnamed Label")
        elif node_type == "Source":
            original_name = node_dict.get("original_name", "Unnamed Source")
            display_label = original_name
        else:
            display_label = (
                node_dict.get("name")
                or node_dict.get("title")
                or node_dict.get("label")
                or f"{node_type} {node_id}"
            )

        # Calculate size and importance
        if node_type == "Community":
            member_count = node_dict.get("member_count", 1)
            size = min(30, max(15, member_count * 2))  # Scale by member count
            importance = min(
                1.0, member_count / 10.0
            )  # Higher member count = higher importance
        elif node_type == "Thread":
            message_count = node_dict.get("message_count", 1)
            size = min(25, max(12, message_count // 2))  # Scale by message count
            importance = min(
                1.0, message_count / 20.0
            )  # More messages = higher importance
        elif node_type == "Source":
            chunk_count = node_dict.get("chunk_count", 1)
            size = min(25, max(14, chunk_count // 3))
            importance = 0.6
        else:
            size = 15
            importance = 0.5

        # Choose color based on type
        color_map = {
            "Community": "#9B59B6",  # Purple for communities
            "Thread": "#E67E22",  # Orange for threads
            "Label": "#3498DB",  # Blue for labels
            "Source": "#10B981",  # Green for sources/documents
            "unknown": "#95A5A6",  # Gray for unknown
        }
        node_color = color_map.get(node_type, "#95A5A6")

        # Extract additional metadata with special handling for different node types
        metadata = {}

        # Common fields - with datetime serialization
        for field in ["created_at", "updated_at", "description", "source"]:
            if field in node_dict:
                metadata[field] = self._serialize_field_value(node_dict[field])

        # Thread-specific fields
        if node_type == "Thread":
            for field in [
                "thread_id",
                "title",
                "summary",
                "message_count",
                "participants",
                "source",
                "project",
                "workspace",
                "tool_version",
                "import_date",
            ]:
                if field in node_dict:
                    metadata[field] = self._serialize_field_value(node_dict[field])

        # Community-specific fields
        elif node_type == "Community":
            for field in [
                "community_id",
                "member_count",
                "algorithm",
                "resolution",
                "ai_summary",
            ]:
                if field in node_dict:
                    metadata[field] = self._serialize_field_value(node_dict[field])

        # Label-specific fields
        elif node_type == "Label":
            for field in ["name", "color", "description"]:
                if field in node_dict:
                    metadata[field] = self._serialize_field_value(node_dict[field])

        # Source-specific fields
        elif node_type == "Source":
            for field in [
                "original_name", "source_type", "mime_type", "file_path",
                "chunk_count", "memory_count", "lifecycle_stage", "summary",
            ]:
                if field in node_dict:
                    metadata[field] = self._serialize_field_value(node_dict[field])

        # Extract community information for visualization
        community_id = node_dict.get("community_id")
        pagerank_score = node_dict.get("pagerank_score", 0.0)

        return {
            "id": node_id,
            "label": display_label,
            "node_type": node_type,
            "node_subtype": node_subtype,
            "size": size,
            "color": node_color,
            "community": str(community_id) if community_id else None,
            "importance": importance,
            "hop_count": hop_count,
            # Include thread_id at top level for Thread nodes for easy access
            "thread_id": node_dict.get("thread_id") if node_type == "Thread" else None,
            "metadata": {
                **metadata,
                "entity_type": node_dict.get("entity_type"),
                "community_id": community_id,
                "pagerank_score": pagerank_score,
                "hop_count": hop_count,
                "description": f"{node_type}: {display_label} (importance: {importance:.2f}, hops: {hop_count})",
            },
        }

    def _build_edge_from_raw_data(
        self,
        rel_dict: Dict[str, Any],
        source_id: str,
        target_id: str,
        path_length: int = 1,
    ) -> Optional[Dict[str, Any]]:
        """
        Build standardized edge data from relationship data.

        Uses the exact logic from existing implementations.
        """
        try:
            # Get relationship label (from expand neighbors)
            edge_type = rel_dict.get("_LABEL", rel_dict.get("type", "UNKNOWN"))

            # Calculate edge weight based on relationship type (exact from expand neighbors)
            weight = 0.5  # Default
            if edge_type == "MENTIONS":
                weight = float(rel_dict.get("confidence", 0.5))
            elif edge_type == "RELATES_TO":
                weight = float(rel_dict.get("strength", 0.5))
            elif edge_type == "EXTRACTED_FROM":
                weight = float(rel_dict.get("extraction_confidence", 0.5))
            elif edge_type == "BELONGS_TO":
                weight = float(rel_dict.get("strength", 0.5))
            elif edge_type in ["CONTAINS", "COMPACTS_TO", "HAS_LABEL"]:
                weight = 1.0

            # Create edge label and context (from expand neighbors and existing logic)
            relation_type = rel_dict.get("relation_type")
            context = rel_dict.get("context", "")  # Extract context from relationship
            confidence = rel_dict.get("confidence")
            strength = rel_dict.get("strength") # type: ignore

            if relation_type:
                edge_label = str(relation_type).replace("_", " ").title()
            else:
                edge_label = edge_type.replace("_", " ").title()

            # Create enhanced description with context (from expand neighbors)
            description = f"{edge_label} (weight: {weight:.2f})"
            if context and edge_type == "RELATES_TO":
                description += f" - {context}"

            # Calculate relevance score for multi-hop relationships
            hop_penalty = 1.0 / path_length
            relevance_score = weight * hop_penalty

            # Edge ID (consistent with existing patterns)
            edge_id = f"{source_id}_{target_id}_{edge_type}" + (
                f"_{path_length}" if path_length > 1 else ""
            )

            edge_data: Dict[str, Any] = {
                "id": edge_id,
                "source": source_id,
                "target": target_id,
                "edge_type": edge_type,
                "weight": weight,
                "label": edge_label,
                "relevance_score": relevance_score,
                "metadata": {
                    "relation_type": relation_type,
                    "relationship_type": edge_type,  # alias for inspector (CRITICAL for frontend)
                    "context": context,  # Include context in metadata
                    "path_length": path_length,
                    "hop_count": path_length,
                    "description": description,
                    # Add all conditional fields for consistency with expand_neighbors
                    "strength": rel_dict.get("strength")
                    if edge_type == "RELATES_TO"
                    else None,
                    "confidence": rel_dict.get("confidence")
                    if edge_type in ["RELATES_TO", "MENTIONS"]
                    else None,
                    "conditions": rel_dict.get("conditions")
                    if edge_type == "RELATES_TO"
                    else None,
                    "temporal_info": rel_dict.get("temporal_info")
                    if edge_type == "RELATES_TO"
                    else None,
                    "source_reference": rel_dict.get("source_reference")
                    if edge_type == "RELATES_TO"
                    else None,
                },
            }

            # Add visualization metadata only (other fields already included above)
            if edge_type == "RELATES_TO":
                edge_data["metadata"]["visualization"] = {
                    "stroke_width": max(1, min(6, int(weight * 10))),
                    "opacity": max(0.4, min(1.0, weight * hop_penalty)),
                    "color": "#E74C3C",
                    "dashed": path_length > 1,
                }
            elif edge_type == "MENTIONS":
                edge_data["metadata"]["visualization"] = {
                    "stroke_width": max(1, min(4, int((confidence or 0.5) * 8))),
                    "opacity": max(0.3, min(0.8, confidence or 0.5)),
                    "color": "#3498DB",
                }

            return edge_data

        except Exception as e:
            logger.warning("Failed to build edge data", error=str(e))
            return None

    def _build_node_from_raw_data(
        self,
        node_dict: Dict[str, Any],
        hop_count: int = 0,
        is_memory: bool = False,
        is_entity: bool = False,
    ) -> Optional[Dict[str, Any]]:
        """
        Build standardized node data from raw KuzuDB node.

        Uses the exact logic from existing implementation to ensure consistency.
        """
        try:
            # Extract node ID (handle both patterns)
            node_id = node_dict.get("_ID") or str(
                node_dict.get("_ID", {}).get("offset", "")
            )
            if not node_id:
                return None

            # Determine node type and properties based on context
            if is_entity or node_dict.get("entity_type"):
                return self._build_entity_node(node_dict, hop_count)
            elif is_memory or node_dict.get("content") or node_dict.get("title"):
                return self._build_memory_node(node_dict, hop_count)
            else:
                # Generic node processing (for communities, etc.)
                return self._build_generic_node(node_dict, hop_count)

        except Exception as e:
            import traceback

            logger.warning(
                "Failed to build node data",
                error=str(e),
                traceback=traceback.format_exc(),
            )
            return None

    # === STATS ALIAS FOR BACKWARD COMPATIBILITY ===

    async def get_graph_statistics(self) -> Dict[str, Any]:
        """
        Get comprehensive graph statistics.

        Returns:
            Dictionary with graph statistics
        """
        logger.info("Getting graph statistics")

        try:
            stats: Dict[str, Any] = {}

            # Node counts
            node_count_queries = {
                "entity_count": "MATCH (e:Entity) RETURN count(e)",
                "memory_count": "MATCH (m:Memory) RETURN count(m)",
                "crystal_count": "MATCH (m:Memory) WHERE m.is_crystal = true RETURN count(m)",
                "thread_count": "MATCH (t:Thread) RETURN count(t)",
                "community_count": "MATCH (c:Community) RETURN count(c)",
                "label_count": "MATCH (l:Label) RETURN count(l)",
            }

            for stat_name, query in node_count_queries.items():
                try:
                    result = self.kuzu_client.conn.execute(query)  # type: ignore
                    if result.has_next():  # type: ignore
                        stats[stat_name] = result.get_next()[0]  # type: ignore
                    else:
                        stats[stat_name] = 0
                except Exception as e:
                    logger.warning(f"Failed to get {stat_name}", error=str(e))
                    stats[stat_name] = 0

            # Relationship counts
            relationship_count_queries = {
                "mentions_count": "MATCH ()-[r:MENTIONS]->() RETURN count(r)",
                "relates_to_count": "MATCH ()-[r:RELATES_TO]->() RETURN count(r)",
                "contains_count": "MATCH ()-[r:CONTAINS]->() RETURN count(r)",
                "compacts_to_count": "MATCH ()-[r:COMPACTS_TO]->() RETURN count(r)",
            }

            for stat_name, query in relationship_count_queries.items():
                try:
                    result = self.kuzu_client.conn.execute(query)  # type: ignore
                    if result.has_next():  # type: ignore
                        stats[stat_name] = result.get_next()[0]  # type: ignore
                    else:
                        stats[stat_name] = 0
                except Exception as e:
                    logger.warning(f"Failed to get {stat_name}", error=str(e))
                    stats[stat_name] = 0

            # Calculate derived statistics
            total_nodes = sum(
                [
                    stats.get("entity_count", 0),
                    stats.get("memory_count", 0),
                    stats.get("thread_count", 0),
                    stats.get("community_count", 0),
                ]
            )

            total_relationships = sum(
                [
                    stats.get("mentions_count", 0),
                    stats.get("relates_to_count", 0),
                    stats.get("contains_count", 0),
                    stats.get("compacts_to_count", 0),
                ]
            )

            # Network density calculation
            max_possible_edges = (
                total_nodes * (total_nodes - 1) if total_nodes > 1 else 1
            )
            network_density = (
                total_relationships / max_possible_edges
                if max_possible_edges > 0
                else 0
            )

            stats.update(
                {
                    "total_nodes": total_nodes,
                    "total_relationships": total_relationships,
                    "network_density": round(network_density, 4),
                }
            )

            # Get top source by thread count (consistent with KuzuClient implementation)
            try:
                assert self.kuzu_client.conn is not None, (
                    "Kuzu client connection is None"
                )
                top_source_result = self.kuzu_client.conn.execute("""
                    MATCH (t:Thread)
                    WHERE t.source IS NOT NULL
                    WITH LOWER(regexp_replace(t.source, ' ', '_', 'g')) as normalized_source, COUNT(t) as thread_count
                    RETURN normalized_source, thread_count
                    ORDER BY thread_count DESC
                    LIMIT 1
                """)

                top_source = "Unknown"
                top_source_count = 0
                if top_source_result.has_next():  # type: ignore
                    row = top_source_result.get_next()  # type: ignore
                    normalized_source: str = str(row[0])  # type: ignore
                    top_source_count: int = row[1]  # type: ignore

                    # Convert normalized source back to readable format
                    if normalized_source == "unknown":
                        top_source = "Unknown"
                    else:
                        top_source = normalized_source.replace("_", " ").title()
                        # Special cases for better display names
                        display_name_mapping = {
                            "Mcp Generic": "MCP Generic",
                            "Mcp Unknown": "MCP Unknown",
                            "Thread Import": "Thread Import",
                        }
                        top_source = display_name_mapping.get(top_source, top_source)

                stats.update(
                    {
                        "top_source": top_source,
                        "top_source_count": top_source_count,
                    }
                )

            except Exception as e:
                logger.warning("Failed to get top source", error=str(e))
                stats.update(
                    {
                        "top_source": "Unknown",
                        "top_source_count": 0,
                    }
                )

            logger.info(
                "Graph statistics retrieved",
                total_nodes=total_nodes,
                total_relationships=total_relationships,
            )
            return stats

        except Exception as e:
            logger.error("Failed to get graph statistics", error=str(e))
            return {"error": str(e), "total_nodes": 0, "total_relationships": 0}

    def _empty_graph_result(
        self, query: str = "", search_results: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Return empty graph result structure."""
        base_result: Dict[str, Any] = {
            "nodes": [],
            "edges": [],
            "communities": [],
            "community_hulls": [],
            "visualization_config": {},
            "metadata": {
                "total_nodes": 0,
                "total_edges": 0,
                "total_communities": 0,
                "error": "No data found",
            },
        }

        if query:
            base_result["query"] = query
            # Construct proper search_metadata with all required fields
            search_results_dict = search_results or {}
            base_result["search_metadata"] = {
                "search_method": "unified_elegant_graph_query",
                "search_results": {
                    "memories_found": len(search_results_dict.get("memories", [])),
                    "entities_found": len(search_results_dict.get("entities", [])),
                    "threads_found": len(search_results_dict.get("threads", [])),
                    "communities_found": len(search_results_dict.get("communities", [])),
                },
                "graph_stats": {
                    "memory_nodes": 0,
                    "entity_nodes": 0,
                    "community_nodes": 0,
                    "mention_edges": 0,
                    "relation_edges": 0,
                },
                "filters_applied": {
                    "node_types": None,
                    "edge_types": None,
                },
                "visualization_ready": True,
                "unified_query": True,
            }

        return base_result

    # === HELPER METHODS ===
    # Preserved from existing implementation with minor improvements

    async def _get_communities_for_search_results(self) -> List[Dict[str, Any]]:
        """Get community information (shared method)."""
        try:
            community_query = """
                MATCH (c:Community)
                RETURN c.community_id, c.name, c.description, c.ai_summary, c.member_count, c.algorithm, c.resolution
            """
            assert self.kuzu_client.conn is not None
            result = self.kuzu_client.conn.execute(community_query)
            assert isinstance(result, kuzu.QueryResult)

            communities: List[Dict[str, Any]] = []
            while result.has_next():
                row = result.get_next()
                (
                    community_id,
                    name,
                    description,
                    ai_summary,
                    member_count,
                    algorithm,
                    resolution,
                ) = (
                    row[0],  # type: ignore
                    row[1],  # type: ignore
                    row[2],  # type: ignore
                    row[3],  # type: ignore
                    row[4],  # type: ignore
                    row[5],  # type: ignore
                    row[6],  # type: ignore
                )

                community_title = name or f"Community {community_id}"
                community_summary = ai_summary or description or ""

                if (
                    not community_title
                    or community_title == f"Community {community_id}"
                ):
                    if member_count and member_count > 0:
                        if member_count <= 3:
                            community_title = "Small Group"
                        elif member_count <= 8:
                            community_title = "Entity Cluster"
                        else:
                            community_title = "Entity Network"
                    else:
                        community_title = f"Community {community_id}"

                communities.append(
                    {
                        "id": str(community_id),
                        "name": community_title,
                        "description": community_summary or "",
                        "member_count": member_count or 0,
                        "strength": 1.0,
                        "algorithm": algorithm or "louvain",
                        "resolution": resolution or 1.0,
                        "metadata": {
                            "original_name": name,
                            "has_ai_summary": ai_summary
                            and ai_summary.startswith("TITLE:"),
                            "summary_type": "ai_generated"
                            if ai_summary and ai_summary.startswith("TITLE:")
                            else "fallback",
                        },
                    }
                )
            return communities

        except Exception as e:
            logger.warning("Failed to get communities", error=str(e))
            return []

    def _generate_community_name(self, group_data: Dict[str, Any]) -> str:
        """Generate a meaningful community name based on entity types and top entities."""
        try:
            entity_types = group_data.get("entity_types", set())
            top_entities = group_data.get("top_entities", []) # type: ignore
            member_count = len(group_data.get("member_nodes", []))

            # If we have entity types, use the most common one
            if entity_types:
                # Prioritize certain entity types for better naming
                priority_types = [
                    "TECHNOLOGY",
                    "CONCEPT",
                    "ORGANIZATION",
                    "PERSON",
                    "PRODUCT",
                    "LOCATION",
                ]

                for priority_type in priority_types:
                    if priority_type in entity_types:
                        if member_count <= 3:
                            return f"{priority_type.title()} Group"
                        elif member_count <= 8:
                            return f"{priority_type.title()} Cluster"
                        else:
                            return f"{priority_type.title()} Network"

                # If no priority type, use the first available type
                first_type = list(entity_types)[0]
                if member_count <= 3:
                    return f"{first_type.title()} Group"
                elif member_count <= 8:
                    return f"{first_type.title()} Cluster"
                else:
                    return f"{first_type.title()} Network"

            # Fallback based on member count
            if member_count <= 3:
                return "Small Group"
            elif member_count <= 8:
                return "Entity Cluster"
            else:
                return "Entity Network"

        except Exception as e:
            logger.warning("Failed to generate community name", error=str(e))
            return f"Community {group_data.get('community_id', 'Unknown')}"

    async def _build_community_hull_data(
        self, nodes: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Build community hull data for graph visualization with enhanced naming."""
        try:
            # Group nodes by community
            community_groups: Dict[str, Any] = {}

            for node in nodes:
                community_id = node.get("community")
                if community_id:
                    if community_id not in community_groups:
                        community_groups[community_id] = {
                            "community_id": community_id,
                            "member_nodes": [],
                            "member_count": 0,
                            "entity_types": set(),
                            "top_entities": [],
                        }
                    community_groups[community_id]["member_nodes"].append(node["id"])

                    # Collect entity type information for better naming
                    if node["node_type"] == "entity":
                        entity_type = node.get("node_subtype", "Unknown")
                        community_groups[community_id]["entity_types"].add(entity_type)
                        community_groups[community_id]["top_entities"].append(
                            node["label"]
                        )

            # Build hull data for each community with 2+ members
            community_hulls: List[Dict[str, Any]] = []
            for community_id, group_data in community_groups.items():
                if len(group_data["member_nodes"]) >= 2:
                    # Generate meaningful community name
                    generated_name = self._generate_community_name(group_data)

                    # Check if we can find the community in database
                    database_name = None
                    try:
                        community_id_int = int(community_id)

                        community_detail_query = """
                            MATCH (c:Community {community_id: $community_id})
                            RETURN c.id, c.community_id, c.name, c.description, c.ai_summary, c.member_count
                        """
                        assert self.kuzu_client.conn is not None, (
                            "Kuzu client connection is None"
                        )
                        result = self.kuzu_client.conn.execute(
                            community_detail_query, {"community_id": community_id_int}
                        )
                        assert isinstance(result, kuzu.QueryResult)

                        if result.has_next():
                            row = result.get_next()
                            (
                                db_id, # type: ignore
                                db_community_id, # type: ignore
                                db_name, # type: ignore
                                db_description, # type: ignore
                                db_ai_summary, # type: ignore
                                db_member_count, # type: ignore
                            ) = (
                                row[0],  # type: ignore
                                row[1],  # type: ignore
                                row[2],  # type: ignore
                                row[3],  # type: ignore
                                row[4],  # type: ignore
                                row[5],  # type: ignore
                            )
                            database_name = db_name
                    except Exception as e:
                        logger.error(
                            f"Error querying community {community_id}: {str(e)}"
                        )

                    # Use database name if available, otherwise use generated name
                    final_name = database_name or generated_name

                    community_hulls.append(
                        {
                            "community_id": community_id,
                            "community_name": final_name,
                            "member_nodes": group_data["member_nodes"],
                            "member_count": len(group_data["member_nodes"]),
                            "hull_type": "convex",
                            "color": "#9B59B6",
                            "opacity": 0.1,
                            "stroke_color": "#8E44AD",
                            "stroke_width": 2,
                            "metadata": {
                                "entity_types": list(group_data["entity_types"]),
                                "top_entities": group_data["top_entities"][
                                    :5
                                ],  # Top 5 entities
                                "description": f"Community of {len(group_data['member_nodes'])} entities with {len(group_data['entity_types'])} types",
                                "debug_info": {
                                    "database_name": database_name,
                                    "generated_name": generated_name,
                                    "name_source": "database"
                                    if database_name
                                    else "generated",
                                },
                            },
                        }
                    )

            return community_hulls

        except Exception as e:
            logger.error("Failed to build community hull data", error=str(e))
            return []
