"""Graph search methods - search-specific graph functionality."""

from typing import Any, Dict, List, Optional
import real_ladybug as kuzu
import structlog
from nowledge_graph_server.database.kuzu_client import KuzuClient
from nowledge_graph_server.core.graph_operations.base import GraphOperationsBase

logger = structlog.get_logger(__name__)


class GraphSearchMixin(GraphOperationsBase):
    """Mixin for search-specific graph methods."""

    kuzu_client: KuzuClient

    async def get_graph_data_for_search(
        self,
        query: str,
        limit: int = 30,
        depth: int = 2,
        node_types: Optional[List[str]] = None,
        edge_types: Optional[List[str]] = None,
        search_ops=None,  # SearchOperations - avoiding circular import
    ) -> Dict[str, Any]:
        """
        Get graph data for search results using elegant unified query.

        Combines search and graph building into a more elegant pipeline while
        preserving all existing search logic and metadata.
        """
        logger.info(
            "Getting graph data for search with unified approach",
            query=query[:50],
            limit=limit,
            depth=depth,
        )

        try:
            if search_ops is None:
                raise ValueError("search_ops parameter is required")

            # STEP 1: Use optimized search_memories instead of universal_search for better results
            memory_search_results = await search_ops.search_memories(
                query=query,
                limit=min(50, limit * 2),
                include_entities=False,  # We'll get entities through graph traversal
                search_mode="comprehensive",  # Use the polished comprehensive mode
                mode="fast",
            )

            # Analyze scores for adaptive thresholding
            if memory_search_results:
                scores = [
                    getattr(result, "similarity_score", 0.0)
                    for result in memory_search_results[:5]
                ]
                max_score = max(scores) if scores else 0.0
            else:
                max_score = 0.0

            # Adaptive threshold for BGE-M3/Qwen3-Embedding (1024-dim)
            # Graph search uses lower thresholds than direct search because:
            # - Short queries (common in graph exploration) yield lower similarity scores
            # - Graph context enriches results, so lower-scoring matches can still be valuable
            base_threshold = 0.25
            quality_gate = 0.28

            if max_score < quality_gate:
                # Best result below quality gate - no good semantic matches
                high_quality_results = []
                threshold = quality_gate  # For logging only
            else:
                # Best result meets quality gate - filter at base threshold
                threshold = base_threshold
                high_quality_results = [
                    result
                    for result in memory_search_results
                    if getattr(result, "similarity_score", 0.0) >= threshold
                ]

            logger.debug(
                "Search quality filter",
                query=query[:30],
                total=len(memory_search_results),
                filtered=len(high_quality_results),
                threshold=threshold,
                max_score=max_score,
            )

            # Convert to universal_search format for compatibility with existing code
            search_results = {
                "query": query,
                "memories": high_quality_results,  # Use filtered high-quality results
                "threads": [],  # Skip threads for now to focus on memory-based search
                "entities": [],  # Will be populated through graph traversal
                "communities": [],
                "total_found": len(high_quality_results),
            }

            logger.debug(
                "Step 1: Search results using optimized search_memories",
                query=query,
                memory_count=len(high_quality_results),
                first_memory_id=high_quality_results[0].memory.id
                if high_quality_results
                else None,
                search_results=[(title, similarity_score) for title, similarity_score in zip(high_quality_results, [result.similarity_score for result in high_quality_results])],
            )

            # STEP 2: Extract and convert IDs (preserved exactly)
            relevant_memory_ids = set()
            relevant_entity_ids = set()
            relevant_thread_ids = set()
            relevant_community_ids = set()

            # Process memory results
            for memory_result in search_results.get("memories", []):
                if hasattr(memory_result, "memory"):
                    relevant_memory_ids.add(memory_result.memory.id)
                elif isinstance(memory_result, dict):
                    relevant_memory_ids.add(memory_result.get("id"))

            # Process entity results
            for entity_result in search_results.get("entities", []):
                if hasattr(entity_result, "id"):
                    relevant_entity_ids.add(entity_result.id)
                elif isinstance(entity_result, dict):
                    relevant_entity_ids.add(entity_result.get("id"))

            # Process thread results → convert to memories
            for thread_result in search_results.get("threads", []):
                thread_id = None
                if hasattr(thread_result, "thread"):
                    thread_id = thread_result.thread.thread_id
                elif isinstance(thread_result, dict):
                    thread_id = thread_result.get("thread_id") or thread_result.get(
                        "id"
                    )

                if thread_id:
                    relevant_thread_ids.add(thread_id)
                    try:
                        memory_ids_from_thread = (
                            await self.kuzu_client.memory_repo.get_memories_by_thread(
                                thread_id
                            )
                        )
                        relevant_memory_ids.update(memory_ids_from_thread)
                        logger.debug(
                            f"Thread {thread_id} contributed {len(memory_ids_from_thread)} memories"
                        )
                    except Exception as e:
                        logger.warning(
                            f"Failed to get memories for thread {thread_id}",
                            error=str(e),
                        )

            # Process community results
            for community_result in search_results.get("communities", []):
                if hasattr(community_result, "id"):
                    relevant_community_ids.add(community_result.id)
                elif isinstance(community_result, dict):
                    relevant_community_ids.add(community_result.get("id"))

            logger.debug(
                "Step 2: Search results processed",
                query=query[:30],
                converted_ids={
                    "memory_ids": len(relevant_memory_ids),
                    "entity_ids": len(relevant_entity_ids),
                    "thread_ids": len(relevant_thread_ids),
                    "community_ids": len(relevant_community_ids),
                },
            )

            # STEP 3: Use elegant unified query for graph building
            all_relevant_ids = list(relevant_memory_ids.union(relevant_entity_ids))

            logger.debug(
                "DEBUG: Graph building IDs",
                query=query[:30],
                memory_ids=list(relevant_memory_ids)[:3],
                entity_ids=list(relevant_entity_ids)[:3],
                total_ids=len(all_relevant_ids),
            )

            if not all_relevant_ids:
                logger.warning("No relevant IDs found for graph building", query=query)
                return self._empty_graph_result(query, search_results) # type: ignore[attr-defined]

            # SEARCH-FOCUSED GRAPH QUERY - prioritize search results and limit expansion
            # Simplified approach: focus on search results with limited expansion
            search_graph_query = f"""
                // Start with search result nodes
                MATCH (seed)
                WHERE seed.id IN $node_ids
                
                // Get paths to connected nodes within depth (but limit expansion)
                OPTIONAL MATCH p = (seed)-[*1..{min(depth, 2)}]-(connected:Entity:Memory)
                WHERE seed <> connected
                
                // Return paths with search result priority
                RETURN seed as source_node,
                       p,
                       CASE WHEN p IS NOT NULL THEN LENGTH(p) ELSE 0 END as path_length,
                       CASE WHEN p IS NOT NULL THEN NODES(p) ELSE [seed] END as path_nodes,
                       CASE WHEN p IS NOT NULL THEN RELS(p) ELSE [] END as path_rels,
                       CASE 
                           WHEN seed.pagerank_score IS NOT NULL THEN seed.pagerank_score
                           WHEN seed.importance IS NOT NULL THEN seed.importance
                           ELSE 0.5
                       END AS relevance_score,
                       seed.id IN $node_ids as is_search_result
                ORDER BY is_search_result DESC, relevance_score DESC
                LIMIT $limit
            """

            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"
            result = self.kuzu_client.conn.execute(
                search_graph_query, {"node_ids": all_relevant_ids, "limit": limit}
            )
            assert isinstance(result, kuzu.QueryResult)

            nodes = []
            edges = []
            seen_nodes = set()
            seen_edges = set()
            nodes_metadata = {}  # Store node names for edge metadata

            # Process search graph results with new query structure
            while result.has_next():
                row = result.get_next()
                source_node = row[0]  # type: ignore
                path = row[1]  # type: ignore - Can be null for direct nodes
                path_length = row[2]  # type: ignore
                path_nodes = row[3] or []  # type: ignore
                path_rels = row[4] or []  # type: ignore
                relevance_score = row[5]  # type: ignore
                is_search_result = row[6] if len(row) > 6 else False  # type: ignore

                # Process the source node
                if source_node:
                    source_id = source_node.get("id")
                    if source_id and source_id not in seen_nodes:
                        seen_nodes.add(source_id)

                        # Build node with appropriate hop count
                        hop_count = 0 if is_search_result else 1
                        node_data = self._build_node_from_raw_data( # type: ignore[attr-defined]
                            source_node,
                            hop_count=hop_count,
                            is_entity=bool(source_node.get("entity_type")),
                            is_memory=bool(
                                source_node.get("content") or source_node.get("title")
                            ),
                        )

                        if node_data:
                            # Add search context to metadata
                            node_data["metadata"]["search_relevance"] = relevance_score
                            node_data["metadata"]["is_search_result"] = is_search_result
                            node_data["metadata"]["query"] = query

                            # Boost size for search result nodes
                            if is_search_result:
                                node_data["size"] = max(node_data.get("size", 20), 25)

                            nodes.append(node_data)
                            nodes_metadata[source_id] = node_data["label"]

                # Process path nodes and relationships
                if path and path_nodes and path_rels:
                    # Process nodes from the path
                    for i, connected_node in enumerate(path_nodes):
                        if not connected_node:
                            continue

                        connected_id = connected_node.get("id") or str(
                            connected_node.get("_ID", {}).get("offset", "")
                        )
                        if (
                            connected_id
                            and connected_id not in seen_nodes
                            and connected_id != source_node.get("id")
                        ):
                            seen_nodes.add(connected_id)

                            node_data = self._build_node_from_raw_data( # type: ignore[attr-defined]
                                connected_node,
                                hop_count=path_length,
                                is_entity=bool(connected_node.get("entity_type")),
                                is_memory=bool(
                                    connected_node.get("content")
                                    or connected_node.get("title")
                                ),
                            )

                            if node_data:
                                # Mark connected nodes with search context
                                node_data["metadata"]["is_search_result"] = False
                                node_data["metadata"]["connected_to_search"] = True
                                nodes.append(node_data)
                                nodes_metadata[connected_id] = node_data["label"]

                    # Process relationships - create individual edges for each hop
                    # Each edge in the path is created separately with path_length=1
                    # so the frontend can visualize all edges properly
                    for rel_idx, rel in enumerate(path_rels):
                        if not rel:
                            continue
                        # FIX: real_ladybug uses uppercase _ID for relationships
                        rel_id = str(
                            rel.get("_ID", {}).get("offset", "")
                            if rel.get("_ID")
                            else rel.get("_id", {}).get("offset", "")
                        )
                        if rel_id and rel_id not in seen_edges:
                            seen_edges.add(rel_id)

                            if rel_idx < len(path_nodes) - 1:
                                rel_source_id = path_nodes[rel_idx].get("id") or str(
                                    path_nodes[rel_idx].get("_ID", {}).get("offset", "")
                                )
                                rel_target_id = path_nodes[rel_idx + 1].get(
                                    "id"
                                ) or str(
                                    path_nodes[rel_idx + 1]
                                    .get("_ID", {})
                                    .get("offset", "")
                                )

                                if rel_source_id and rel_target_id:
                                    # Create each edge with path_length=1 so frontend can handle it
                                    # This breaks multi-hop paths into individual edges
                                    edge_data = self._build_edge_from_raw_data( # type: ignore[attr-defined]
                                        rel, rel_source_id, rel_target_id, path_length=1
                                    )

                                    if edge_data:
                                        # Add human readable names to edge metadata
                                        edge_data["metadata"]["source_name"] = (
                                            nodes_metadata.get(
                                                rel_source_id, rel_source_id
                                            )
                                        )
                                        edge_data["metadata"]["target_name"] = (
                                            nodes_metadata.get(
                                                rel_target_id, rel_target_id
                                            )
                                        )
                                        edge_data["metadata"]["source_id"] = (
                                            rel_source_id
                                        )
                                        edge_data["metadata"]["target_id"] = (
                                            rel_target_id
                                        )
                                        # Store the original path length for reference
                                        edge_data["metadata"]["original_path_length"] = path_length
                                        edges.append(edge_data)

            # Get communities concurrently
            communities = await self._get_communities_for_search_results() # type: ignore[attr-defined]

            # Build community hull data
            community_hulls = await self._build_community_hull_data(nodes) # type: ignore[attr-defined]

            # STEP 4: Add search-specific metadata (preserved exactly)
            result = {
                "nodes": nodes,
                "edges": edges,
                "communities": communities,
                "community_hulls": community_hulls,
                "query": query,
                "search_metadata": {
                    "search_method": "unified_elegant_graph_query",
                    "search_results": {
                        "memories_found": len(search_results.get("memories", [])),
                        "entities_found": len(search_results.get("entities", [])),
                        "threads_found": len(search_results.get("threads", [])),
                        "communities_found": len(search_results.get("communities", [])),
                    },
                    "graph_stats": {
                        "memory_nodes": len(
                            [n for n in nodes if n["node_type"] == "memory"]
                        ),
                        "entity_nodes": len(
                            [n for n in nodes if n["node_type"] == "entity"]
                        ),
                        "community_nodes": len(
                            [n for n in nodes if n["node_type"] == "Community"]
                        ),
                        "mention_edges": len(
                            [e for e in edges if e["edge_type"] == "MENTIONS"]
                        ),
                        "relation_edges": len(
                            [e for e in edges if e["edge_type"] == "RELATES_TO"]
                        ),
                    },
                    "filters_applied": {
                        "node_types": node_types,
                        "edge_types": edge_types,
                    },
                    "visualization_ready": True,
                    "unified_query": True,
                },
                "visualization_config": {
                    "node_size_range": [10, 50],
                    "edge_weight_range": [1, 6],
                    "layout_recommendations": {
                        "algorithm": "force-directed"
                        if len(nodes) < 50
                        else "hierarchical",
                        "cluster_by_community": len(communities) > 0,
                        "highlight_search_results": True,
                    },
                },
                "metadata": {
                    "total_nodes": len(nodes),
                    "total_edges": len(edges),
                    "total_communities": len(communities),
                    "entity_nodes": len(
                        [n for n in nodes if n["node_type"] == "entity"]
                    ),
                    "memory_nodes": len(
                        [n for n in nodes if n["node_type"] == "memory"]
                    ),
                    "relationship_edges": len(
                        [e for e in edges if e["edge_type"] == "RELATES_TO"]
                    ),
                    "mention_edges": len(
                        [e for e in edges if e["edge_type"] == "MENTIONS"]
                    ),
                    "traversal_depth": depth,
                    "query_method": "unified_search_graph",
                },
            }

            logger.debug(
                "Step 4: Search graph data completed with unified approach",
                query=query[:30],
                total_results=result["metadata"]["total_nodes"]
                + result["metadata"]["total_edges"],
                nodes=len(nodes),
                edges=len(edges),
                query_method="unified",
            )

            return result

        except Exception as e:
            logger.error("Failed to get search graph data", query=query, error=str(e))
            raise
