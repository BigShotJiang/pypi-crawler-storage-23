"""Graph statistics methods - statistics and analysis functionality."""

from typing import Any, Dict, List
import datetime
import real_ladybug as kuzu
import structlog
from nowledge_graph_server.database.kuzu_client import KuzuClient
from nowledge_graph_server.core.graph_operations.base import GraphOperationsBase

logger = structlog.get_logger(__name__)


class GraphStatisticsMixin(GraphOperationsBase):
    """Mixin for statistics and analysis methods."""

    kuzu_client: KuzuClient

    async def get_graph_stats(self) -> Dict[str, Any]:
        """
        Alias for get_graph_statistics for backward compatibility.

        The API depends on this method name.
        """
        return await self.get_graph_statistics()

    # === PRESERVED METHODS ===
    # Keep all existing methods for backward compatibility

    async def get_entity_relationships(
        self, entity_id: str, max_depth: int = 2, include_weights: bool = True
    ) -> Dict[str, Any]:
        """
        Get entity relationships using graph traversal.

        Args:
            entity_id: Entity ID to get relationships for
            max_depth: Maximum depth for relationship traversal
            include_weights: Whether to include relationship weights

        Returns:
            Dictionary with entity relationships
        """
        logger.info(
            "Getting entity relationships", entity_id=entity_id, max_depth=max_depth
        )

        try:
            # Build traversal query based on depth
            if max_depth == 1:
                query = """
                    MATCH (e:Entity {id: $entity_id})-[r:RELATES_TO]-(related:Entity)
                    RETURN e, r, related
                    ORDER BY r.confidence DESC
                """
            else:
                query = f"""
                    MATCH (e:Entity {{id: $entity_id}})-[r:RELATES_TO*1..{max_depth}]-(related:Entity)
                    RETURN e, r, related
                    ORDER BY length(r) ASC
                """

            result = self.kuzu_client.conn.execute(query, {"entity_id": entity_id})  # type: ignore
            assert isinstance(result, kuzu.QueryResult)  # type: ignore

            relationships: List[Dict[str, Any]] = []
            while result.has_next():
                row = result.get_next()
                entity_data, relationship_data, related_data = row[0], row[1], row[2]  # type: ignore

                relationship_dict = {
                    "source_entity": {
                        "id": entity_data["id"],
                        "name": entity_data["name"],
                        "type": entity_data["entity_type"],
                    },
                    "target_entity": {
                        "id": related_data["id"],
                        "name": related_data["name"],
                        "type": related_data["entity_type"],
                    },
                    "relationship": {
                        "type": relationship_data.get("relation_type", "RELATES_TO"),
                        "confidence": relationship_data.get("confidence", 0.5),
                    },
                }

                if include_weights:
                    relationship_dict["relationship"]["weight"] = relationship_data.get(
                        "strength", 0.5
                    )

                relationships.append(relationship_dict)

            return {
                "entity_id": entity_id,
                "relationships": relationships,
                "total_relationships": len(relationships),
                "max_depth": max_depth,
            }

        except Exception as e:
            logger.error(
                "Failed to get entity relationships", entity_id=entity_id, error=str(e)
            )
            return {
                "entity_id": entity_id,
                "relationships": [],
                "total_relationships": 0,
                "error": str(e),
            }

    async def get_memory_entities(self, memory_id: str) -> Dict[str, Any]:
        """
        Get entities mentioned in a specific memory.

        Args:
            memory_id: Memory ID to get entities for

        Returns:
            Dictionary with memory entities
        """
        logger.info("Getting memory entities", memory_id=memory_id)

        try:
            query = """
                MATCH (m:Memory {id: $memory_id})-[men:MENTIONS]->(e:Entity)
                RETURN e, men.confidence
                ORDER BY men.confidence DESC
            """

            result = self.kuzu_client.conn.execute(query, {"memory_id": memory_id})  # type: ignore
            assert isinstance(result, kuzu.QueryResult)  # type: ignore

            entities: List[Dict[str, Any]] = []
            while result.has_next():
                row = result.get_next()
                entity_data, confidence = row[0], row[1]  # type: ignore

                entities.append(
                    {
                        "id": entity_data["id"],
                        "name": entity_data["name"],
                        "type": entity_data["entity_type"],
                        "confidence": confidence,
                        "description": entity_data.get("description", ""),
                    }
                )

            return {
                "memory_id": memory_id,
                "entities": entities,
                "total_entities": len(entities),
            }

        except Exception as e:
            logger.error(
                "Failed to get memory entities", memory_id=memory_id, error=str(e)
            )
            return {
                "memory_id": memory_id,
                "entities": [],
                "total_entities": 0,
                "error": str(e),
            }

    async def get_community_analysis(
        self, resolution: float = 1.0, max_iterations: int = 20
    ) -> Dict[str, Any]:
        """
        Get comprehensive community analysis.

        Args:
            resolution: Resolution parameter for community detection
            max_iterations: Maximum iterations for algorithms

        Returns:
            Dictionary with community analysis
        """
        logger.info(
            "Getting community analysis",
            resolution=resolution,
            max_iterations=max_iterations,
        )

        try:
            analysis: Dict[str, Any] = {
                "communities": [],
                "community_metrics": {},
                "centrality_measures": {},
                "computed_at": None,
            }

            # Get existing communities
            community_query = """
                MATCH (c:Community)
                RETURN c.community_id, c.name, c.description, c.member_count, c.algorithm, c.resolution
                ORDER BY c.member_count DESC
            """

            result = self.kuzu_client.conn.execute(community_query)  # type: ignore
            assert isinstance(result, kuzu.QueryResult)  # type: ignore

            communities: List[Dict[str, Any]] = []
            while result.has_next():
                row = result.get_next()
                (
                    community_id,
                    name,
                    description,
                    member_count,
                    algorithm,
                    community_resolution,
                ) = (
                    row[0],  # type: ignore
                    row[1],  # type: ignore
                    row[2],  # type: ignore
                    row[3],  # type: ignore
                    row[4],  # type: ignore
                    row[5],  # type: ignore
                )

                communities.append(
                    {
                        "id": community_id,
                        "name": name or f"Community {community_id}",
                        "description": description or "",
                        "member_count": member_count or 0,
                        "algorithm": algorithm or "unknown",
                        "resolution": community_resolution or 1.0,
                    }
                )

            analysis["communities"] = communities

            # Community metrics
            if communities:
                total_communities = len(communities)
                avg_community_size = (
                    sum(c["member_count"] for c in communities) / total_communities
                )
                largest_community = max(communities, key=lambda x: x["member_count"])
                smallest_community = min(communities, key=lambda x: x["member_count"])

                analysis["community_metrics"] = {
                    "total_communities": total_communities,
                    "average_community_size": round(avg_community_size, 2),
                    "largest_community": {
                        "id": largest_community["id"],
                        "name": largest_community["name"],
                        "size": largest_community["member_count"],
                    },
                    "smallest_community": {
                        "id": smallest_community["id"],
                        "name": smallest_community["name"],
                        "size": smallest_community["member_count"],
                    },
                }

            # Centrality measures (simplified)
            try:
                # Get top entities by degree centrality
                centrality_query = """
                    MATCH (e:Entity)
                    OPTIONAL MATCH (e)-[r]-()
                    WITH e, COUNT(r) as degree
                    RETURN e.id, e.name, degree
                    ORDER BY degree DESC
                    LIMIT 10
                """

                result = self.kuzu_client.conn.execute(centrality_query)  # type: ignore
                top_entities: List[Dict[str, Any]] = []
                while result.has_next():  # type: ignore
                    row = result.get_next()  # type: ignore
                    entity_id, entity_name, degree = row[0], row[1], row[2]  # type: ignore
                    top_entities.append(
                        {
                            "entity_id": entity_id,
                            "entity_name": entity_name,
                            "degree_centrality": degree,
                        }
                    )

                analysis["centrality_measures"]["top_entities_by_degree"] = top_entities

            except Exception as e:
                logger.warning("Failed to compute centrality measures", error=str(e))

            analysis["computed_at"] = datetime.datetime.utcnow().isoformat() # type: ignore

            logger.info("Community analysis completed", communities=len(communities))
            return analysis

        except Exception as e:
            logger.error("Failed to get community analysis", error=str(e))
            return {
                "communities": [],
                "community_metrics": {},
                "centrality_measures": {},
                "error": str(e),
            }
