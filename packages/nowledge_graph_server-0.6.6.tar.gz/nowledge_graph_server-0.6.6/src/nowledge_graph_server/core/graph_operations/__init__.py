"""Graph operations module - main entry point for GraphOperations class."""

from .visualization import GraphVisualizationMixin
from .search import GraphSearchMixin
from .statistics import GraphStatisticsMixin
from nowledge_graph_server.database.kuzu_client import KuzuClient


class GraphOperations(GraphVisualizationMixin, GraphSearchMixin, GraphStatisticsMixin):
    """
    Main GraphOperations class that composes functionality from specialized mixins.

    This provides a clean single-class interface while organizing code into logical modules.
    """

    def __init__(self, kuzu_client: KuzuClient):
        super().__init__(kuzu_client)
