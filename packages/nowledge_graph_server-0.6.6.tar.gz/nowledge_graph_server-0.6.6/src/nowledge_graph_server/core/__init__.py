"""Core business logic for Nowledge Graph system.

This module contains shared functions that can be used by both:
- FastAPI server (for Tauri desktop app)
- MCP server (for AI agent integration)

Design principle: Pure business logic separated from API concerns.
"""

from .memory_operations import MemoryOperations
from .thread_operations import ThreadOperations
from .entity_operations import EntityOperations
from .graph_operations import GraphOperations
from .search_operations import SearchOperations

__all__ = [
    "MemoryOperations",
    "ThreadOperations",
    "EntityOperations",
    "GraphOperations",
    "SearchOperations",
]
