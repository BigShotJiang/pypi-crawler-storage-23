"""Relationship backup and restore helpers for memory reindexing.

KuzuDB doesn't allow updating indexed fields, so during reindexing we must
delete and recreate memories. This module handles backing up and restoring
all relationships during that process.
"""

from typing import Any, Dict, List, TYPE_CHECKING

import real_ladybug as kuzu
import structlog

if TYPE_CHECKING:
    from ...database.kuzu_client import KuzuClient

logger = structlog.get_logger(__name__)


async def backup_memory_relationships(
    db: "KuzuClient", memory_id: str
) -> Dict[str, Any]:
    """Backup all relationships involving a memory before deletion.
    
    Args:
        db: KuzuClient instance
        memory_id: ID of memory to backup relationships for
        
    Returns:
        Dictionary containing backed up relationships by type
    """
    if not db.conn:
        raise RuntimeError("Database connection not available")

    relationships_backup: Dict[str, Any] = {}

    try:
        # 1. Backup HAS_LABEL relationships (Memory -> Label)
        label_query = """
            MATCH (m:Memory {id: $memory_id})-[r:HAS_LABEL]->(l:Label)
            RETURN l.id as label_id, r.assigned_by as assigned_by, 
                   r.created_at as created_at, r.properties as properties
        """
        result = db.conn.execute(label_query, {"memory_id": memory_id})
        assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"
        labels: List[Dict[str, Any]] = []
        while result.has_next():
            row = result.get_next()
            labels.append({
                "label_id": row[0],
                "assigned_by": row[1],
                "created_at": row[2],
                "properties": row[3],
            })
        relationships_backup["labels"] = labels
        logger.debug(f"Backed up {len(labels)} label relationships")

        # 2. Backup COMPACTS_TO relationships (Thread -> Memory)
        thread_query = """
            MATCH (t:Thread)-[r:COMPACTS_TO]->(m:Memory {id: $memory_id})
            RETURN t.thread_id as thread_id, r.compaction_method as compaction_method,
                   r.created_at as created_at, r.properties as properties
        """
        result = db.conn.execute(thread_query, {"memory_id": memory_id})
        assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"
        threads: List[Dict[str, Any]] = []
        while result.has_next():
            row = result.get_next()
            threads.append({
                "thread_id": row[0],
                "compaction_method": row[1],
                "created_at": row[2],
                "properties": row[3],
            })
        relationships_backup["threads"] = threads
        logger.debug(f"Backed up {len(threads)} thread relationships")

        # 3. Backup MENTIONS relationships (Memory -> Entity)
        mentions_query = """
            MATCH (m:Memory {id: $memory_id})-[r:MENTIONS]->(e:Entity)
            RETURN e.id as entity_id, r.confidence as confidence,
                   r.mention_count as mention_count, r.created_at as created_at,
                   r.properties as properties
        """
        result = db.conn.execute(mentions_query, {"memory_id": memory_id})
        assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"
        mentions: List[Dict[str, Any]] = []
        while result.has_next():
            row = result.get_next()
            mentions.append({
                "entity_id": row[0],
                "confidence": row[1],
                "mention_count": row[2],
                "created_at": row[3],
                "properties": row[4],
            })
        relationships_backup["mentions"] = mentions
        logger.debug(f"Backed up {len(mentions)} mention relationships")

        # 4. Backup EXTRACTED_FROM relationships (Memory -> Message)
        extracted_query = """
            MATCH (m:Memory {id: $memory_id})-[r:EXTRACTED_FROM]->(msg:Message)
            RETURN msg.id as message_id, r.extraction_confidence as extraction_confidence,
                   r.created_at as created_at, r.properties as properties
        """
        result = db.conn.execute(extracted_query, {"memory_id": memory_id})
        assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"
        extractions: List[Dict[str, Any]] = []
        while result.has_next():
            row = result.get_next()
            extractions.append({
                "message_id": row[0],
                "extraction_confidence": row[1],
                "created_at": row[2],
                "properties": row[3],
            })
        relationships_backup["extractions"] = extractions
        logger.debug(f"Backed up {len(extractions)} extraction relationships")

        # 5. Backup RELATES_TO relationships created from this memory
        relates_query = """
            MATCH (e1:Entity)-[r:RELATES_TO]->(e2:Entity)
            WHERE r.source_reference = $memory_id
            RETURN e1.id as source_entity_id, e2.id as target_entity_id,
                   r.relation_type as relation_type, r.strength as strength,
                   r.confidence as confidence, r.context as context,
                   r.conditions as conditions, r.temporal_info as temporal_info,
                   r.source_reference as source_reference, r.bidirectional as bidirectional,
                   r.created_at as created_at, r.properties as properties
        """
        result = db.conn.execute(relates_query, {"memory_id": memory_id})
        assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"
        relates_to: List[Dict[str, Any]] = []
        while result.has_next():
            row = result.get_next()
            relates_to.append({
                "source_entity_id": row[0],
                "target_entity_id": row[1],
                "relation_type": row[2],
                "strength": row[3],
                "confidence": row[4],
                "context": row[5],
                "conditions": row[6],
                "temporal_info": row[7],
                "source_reference": row[8],
                "bidirectional": row[9],
                "created_at": row[10],
                "properties": row[11],
            })
        relationships_backup["relates_to"] = relates_to
        logger.debug(f"Backed up {len(relates_to)} RELATES_TO relationships")

        return relationships_backup

    except Exception as e:
        logger.error(
            "Failed to backup memory relationships",
            memory_id=memory_id,
            error=str(e),
        )
        raise


async def restore_memory_relationships(
    db: "KuzuClient", memory_id: str, relationships_backup: Dict[str, Any]
) -> bool:
    """Restore all relationships for a recreated memory.
    
    Args:
        db: KuzuClient instance
        memory_id: ID of the recreated memory
        relationships_backup: Backed up relationships from backup_memory_relationships
        
    Returns:
        True if all relationships restored successfully
    """
    if not db.conn:
        raise RuntimeError("Database connection not available")

    try:
        success_count = 0
        total_count = 0

        # 1. Restore HAS_LABEL relationships
        for label_rel in relationships_backup.get("labels", []):
            try:
                query = """
                    MATCH (m:Memory {id: $memory_id}), (l:Label {id: $label_id})
                    CREATE (m)-[:HAS_LABEL {
                        assigned_by: $assigned_by,
                        created_at: $created_at,
                        properties: $properties
                    }]->(l)
                """
                db.conn.execute(query, {
                    "memory_id": memory_id,
                    "label_id": label_rel["label_id"],
                    "assigned_by": label_rel["assigned_by"],
                    "created_at": label_rel["created_at"],
                    "properties": label_rel["properties"],
                })
                success_count += 1
            except Exception as e:
                logger.warning(f"Failed to restore label relationship: {e}")
            total_count += 1

        # 2. Restore COMPACTS_TO relationships
        for thread_rel in relationships_backup.get("threads", []):
            try:
                query = """
                    MATCH (t:Thread {thread_id: $thread_id}), (m:Memory {id: $memory_id})
                    CREATE (t)-[:COMPACTS_TO {
                        compaction_method: $compaction_method,
                        created_at: $created_at,
                        properties: $properties
                    }]->(m)
                """
                db.conn.execute(query, {
                    "thread_id": thread_rel["thread_id"],
                    "memory_id": memory_id,
                    "compaction_method": thread_rel["compaction_method"],
                    "created_at": thread_rel["created_at"],
                    "properties": thread_rel["properties"],
                })
                success_count += 1
            except Exception as e:
                logger.warning(f"Failed to restore thread relationship: {e}")
            total_count += 1

        # 3. Restore MENTIONS relationships
        for mention_rel in relationships_backup.get("mentions", []):
            try:
                query = """
                    MATCH (m:Memory {id: $memory_id}), (e:Entity {id: $entity_id})
                    CREATE (m)-[:MENTIONS {
                        confidence: $confidence,
                        mention_count: $mention_count,
                        created_at: $created_at,
                        properties: $properties
                    }]->(e)
                """
                db.conn.execute(query, {
                    "memory_id": memory_id,
                    "entity_id": mention_rel["entity_id"],
                    "confidence": mention_rel["confidence"],
                    "mention_count": mention_rel["mention_count"],
                    "created_at": mention_rel["created_at"],
                    "properties": mention_rel["properties"],
                })
                success_count += 1
            except Exception as e:
                logger.warning(f"Failed to restore mention relationship: {e}")
            total_count += 1

        # 4. Restore EXTRACTED_FROM relationships
        for extraction_rel in relationships_backup.get("extractions", []):
            try:
                query = """
                    MATCH (m:Memory {id: $memory_id}), (msg:Message {id: $message_id})
                    CREATE (m)-[:EXTRACTED_FROM {
                        extraction_confidence: $extraction_confidence,
                        created_at: $created_at,
                        properties: $properties
                    }]->(msg)
                """
                db.conn.execute(query, {
                    "memory_id": memory_id,
                    "message_id": extraction_rel["message_id"],
                    "extraction_confidence": extraction_rel["extraction_confidence"],
                    "created_at": extraction_rel["created_at"],
                    "properties": extraction_rel["properties"],
                })
                success_count += 1
            except Exception as e:
                logger.warning(f"Failed to restore extraction relationship: {e}")
            total_count += 1

        # 5. Restore RELATES_TO relationships (with duplicate prevention)
        for relates_rel in relationships_backup.get("relates_to", []):
            try:
                # Check if relationship already exists
                check_query = """
                    MATCH (e1:Entity {id: $source_entity_id})-[r:RELATES_TO]->(e2:Entity {id: $target_entity_id})
                    WHERE r.relation_type = $relation_type AND r.source_reference = $source_reference
                    RETURN count(r) as existing_count
                """
                check_result = db.conn.execute(check_query, {
                    "source_entity_id": relates_rel["source_entity_id"],
                    "target_entity_id": relates_rel["target_entity_id"],
                    "relation_type": relates_rel["relation_type"],
                    "source_reference": relates_rel["source_reference"],
                })

                existing_count = 0
                assert isinstance(check_result, kuzu.QueryResult)
                if check_result.has_next():
                    existing_count = check_result.get_next()[0]

                if existing_count == 0:
                    query = """
                        MATCH (e1:Entity {id: $source_entity_id}), (e2:Entity {id: $target_entity_id})
                        CREATE (e1)-[:RELATES_TO {
                            relation_type: $relation_type,
                            strength: $strength,
                            confidence: $confidence,
                            context: $context,
                            conditions: $conditions,
                            temporal_info: $temporal_info,
                            source_reference: $source_reference,
                            bidirectional: $bidirectional,
                            created_at: $created_at,
                            properties: $properties
                        }]->(e2)
                    """
                    db.conn.execute(query, {
                        "source_entity_id": relates_rel["source_entity_id"],
                        "target_entity_id": relates_rel["target_entity_id"],
                        "relation_type": relates_rel["relation_type"],
                        "strength": relates_rel["strength"],
                        "confidence": relates_rel["confidence"],
                        "context": relates_rel["context"],
                        "conditions": relates_rel["conditions"],
                        "temporal_info": relates_rel["temporal_info"],
                        "source_reference": relates_rel["source_reference"],
                        "bidirectional": relates_rel["bidirectional"],
                        "created_at": relates_rel["created_at"],
                        "properties": relates_rel["properties"],
                    })
                    success_count += 1
                else:
                    logger.debug(
                        f"Skipping duplicate RELATES_TO: "
                        f"{relates_rel['source_entity_id']} -> {relates_rel['target_entity_id']}"
                    )
                    success_count += 1  # Count as success since it exists
            except Exception as e:
                logger.warning(f"Failed to restore RELATES_TO relationship: {e}")
            total_count += 1

        logger.info(
            "Relationship restoration completed",
            memory_id=memory_id,
            success_count=success_count,
            total_count=total_count,
            success_rate=f"{success_count}/{total_count}",
        )
        return success_count == total_count

    except Exception as e:
        logger.error(
            "Failed to restore memory relationships",
            memory_id=memory_id,
            error=str(e),
        )
        return False
