"""Memory operations package.

This package provides the MemoryOperations class that combines:
- Base CRUD operations (create, read, update, delete, list, search)
- Reindexing operations (single and bulk reindex with relationship preservation)
- Relationship backup/restore helpers
- Thread distillation state management

Usage:
    from nowledge_graph_server.core.memory_operations import MemoryOperations
    
    ops = MemoryOperations(db, embedding_service, entity_service)
    memory = await ops.create_memory(content="...")
    results = await ops.search_memories(query="...")
"""

from typing import Optional

from ...database.kuzu_client import KuzuClient
from ...services.embedding import EmbeddingService
from ...services.entity_extraction import EntityExtractionService
from .base import MemoryOperationsBase
from .reindexing import ReindexingMixin

# Re-export helpers for direct use if needed
from .relationship_helpers import (
    backup_memory_relationships,
    restore_memory_relationships,
)
from .thread_helpers import (
    get_thread_id_for_memory,
    cleanup_thread_distillation_state_if_needed,
    clear_thread_distillation_state,
)


class MemoryOperations(MemoryOperationsBase, ReindexingMixin):
    """Complete memory operations class combining all functionality.
    
    This class provides:
    - Memory CRUD: create, get, update state, delete, list
    - Memory search: semantic similarity search with filters
    - Reindexing: single memory and bulk reindex with relationship preservation
    - Entity extraction: (currently disabled, handled during distillation)
    - Label management: assign labels to memories
    
    Attributes:
        db: KuzuClient for database operations
        embedding_service: Optional EmbeddingService for vector embeddings
        entity_service: Optional EntityExtractionService (unused currently)
    """

    def __init__(
        self,
        db: KuzuClient,
        embedding_service: Optional[EmbeddingService],
        entity_service: Optional[EntityExtractionService] = None,
    ):
        """Initialize MemoryOperations.
        
        Args:
            db: KuzuClient instance for database operations
            embedding_service: Optional embedding service for vector embeddings
            entity_service: Optional entity extraction service (unused currently)
        """
        super().__init__(db, embedding_service, entity_service)


__all__ = [
    "MemoryOperations",
    # Helper functions (for advanced usage)
    "backup_memory_relationships",
    "restore_memory_relationships",
    "get_thread_id_for_memory",
    "cleanup_thread_distillation_state_if_needed",
    "clear_thread_distillation_state",
]
