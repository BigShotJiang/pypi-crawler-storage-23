"""Memory reindexing operations.

KuzuDB doesn't allow updating indexed fields, so we must delete and recreate
memories to update embeddings. This module handles single and bulk reindexing.
"""

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, TYPE_CHECKING

import structlog

from ...models.graph import MemoryNode
from ...services.embedding import EmbeddingService
from ...services.embedding_text_prep import prepare_text_for_embedding, needs_summarization
from .relationship_helpers import backup_memory_relationships, restore_memory_relationships

if TYPE_CHECKING:
    from ...database.kuzu_client import KuzuClient

logger = structlog.get_logger(__name__)


class ReindexingMixin:
    """Mixin class providing memory reindexing operations.
    
    This is mixed into MemoryOperations to add reindexing functionality.
    Expects self.db to be a KuzuClient and self.get_memory_by_id() to exist.
    """
    
    db: "KuzuClient"
    
    async def get_memory_by_id(self, memory_id: str) -> Optional[MemoryNode]:
        """Abstract method - implemented by base class."""
        raise NotImplementedError

    async def reindex_memory(self, memory_id: str) -> Dict[str, Any]:
        """Reindex a memory by deleting and recreating it with new embeddings.

        KuzuDB doesn't allow updating indexed fields, so we must delete and recreate.
        We preserve all relationships by backing them up and restoring them.
        
        Args:
            memory_id: ID of memory to reindex
            
        Returns:
            Dict with success status and details
        """
        logger.info("Starting memory reindex via delete-recreate", memory_id=memory_id)

        try:
            # Get current memory
            current_memory = await self.get_memory_by_id(memory_id)
            if not current_memory:
                logger.error("Memory not found for reindexing", memory_id=memory_id)
                return {"success": False, "error": "Memory not found"}

            # Check if reindexing is needed
            current_semantic = current_memory.semantic_field or ""
            expected_semantic = (
                f"{current_memory.title or ''}\n{current_memory.content or ''}".strip()
            )

            if current_semantic == expected_semantic and not current_memory.reindex_needed:
                logger.info("Memory already up to date, no reindexing needed", memory_id=memory_id)
                return {"success": True, "reindexed": False, "reason": "Already up to date"}

            logger.info(
                "Reindexing needed, backing up relationships and recreating memory",
                memory_id=memory_id,
            )

            # Step 1: Backup all relationships
            relationships_backup = await backup_memory_relationships(self.db, memory_id)
            logger.debug(f"Backed up {len(relationships_backup)} relationship types")

            # Step 2: Generate new embedding only when legacy Kuzu vectors are active.
            # v2+ databases use LanceDB and do not require Kuzu-side embeddings.
            requires_legacy_embedding = self._requires_legacy_kuzu_embedding()  # type: ignore[attr-defined]
            new_embedding: Optional[List[float]]
            if requires_legacy_embedding:
                new_embedding = await self._generate_embedding_for_reindex(
                    current_memory, expected_semantic, memory_id
                )
                if new_embedding is None:
                    return {"success": False, "error": "Failed to generate embedding"}
            else:
                logger.debug(
                    "Skipping legacy embedding regeneration during reindex for v2+ schema",
                    memory_id=memory_id,
                )
                new_embedding = current_memory.embedding or []

            # Step 3: Delete old memory
            logger.info("REINDEX: Deleting old memory node", memory_id=memory_id)
            delete_success = await self.db.memory_repo.delete_memory(memory_id)
            if not delete_success:
                logger.error("Failed to delete old memory during reindex", memory_id=memory_id)
                return {"success": False, "error": "Failed to delete old memory"}
            logger.info("REINDEX: Old memory deleted successfully", memory_id=memory_id)

            # Step 4: Create new memory with same ID and new embedding
            new_memory = await self._create_reindexed_memory(
                current_memory, memory_id, expected_semantic, new_embedding
            )
            if not new_memory:
                return {"success": False, "error": "Failed to create new memory"}

            # Step 5: Restore all relationships
            restore_success = await restore_memory_relationships(
                self.db, memory_id, relationships_backup
            )
            if not restore_success:
                logger.warning("Some relationships may not have been restored", memory_id=memory_id)

            logger.info(
                "Memory reindexed successfully via delete-recreate",
                memory_id=memory_id,
                semantic_field_updated=current_semantic != expected_semantic,
                embedding_dimension=len(new_embedding) if new_embedding else 0,
                relationships_restored=len(relationships_backup),
            )

            return {
                "success": True,
                "reindexed": True,
                "memory_id": memory_id,
                "semantic_field_updated": current_semantic != expected_semantic,
                "embedding_dimension": len(new_embedding) if new_embedding else 0,
                "relationships_restored": len(relationships_backup),
            }

        except Exception as e:
            logger.error(
                "Failed to reindex memory via delete-recreate",
                memory_id=memory_id,
                error=str(e),
            )
            return {"success": False, "error": str(e)}

    async def _generate_embedding_for_reindex(
        self, memory: MemoryNode, semantic_text: str, memory_id: str
    ) -> Optional[List[float]]:
        """Generate embedding for reindexing, handling long content.
        
        Args:
            memory: The memory being reindexed
            semantic_text: The semantic field text
            memory_id: Memory ID for logging
            
        Returns:
            Embedding vector or None on failure
        """
        from ...api.dependencies import get_embedding_service

        embedding_svc = await get_embedding_service()
        if not embedding_svc or not embedding_svc._initialized:  # type: ignore
            logger.warning("Embedding service not available for reindexing")
            return None

        try:
            # Check if content needs summarization for embedding
            if needs_summarization(memory.content, memory.title):
                logger.info(
                    "REINDEX: Content exceeds embedding limit, preparing text for embedding",
                    memory_id=memory_id,
                    content_length=len(semantic_text),
                )
                # Try to get LLM service for summarization
                try:
                    from ...api.dependencies import get_local_llm_service_dep
                    llm_service = await get_local_llm_service_dep()
                except Exception as e:
                    logger.debug("LLM service not available for summarization", error=str(e))
                    llm_service = None

                # Prepare text for embedding (may summarize if LLM available)
                embedding_text, was_summarized = await prepare_text_for_embedding(
                    memory.content, memory.title, llm_service
                )

                if was_summarized:
                    logger.info(
                        "REINDEX: Using LLM-summarized text for embedding",
                        memory_id=memory_id,
                        original_length=len(semantic_text),
                        summary_length=len(embedding_text),
                    )
            else:
                embedding_text = semantic_text

            # Generate embedding
            new_embedding = await embedding_svc.embed_text(embedding_text, prefix="passage")
            logger.info(
                "REINDEX: Generated new embedding",
                memory_id=memory_id,
                dimension=len(new_embedding),
                first_5_values=new_embedding[:5],
                semantic_preview=semantic_text[:100] + "..." if len(semantic_text) > 100 else semantic_text,
            )
            return new_embedding

        except Exception as e:
            logger.warning("Failed to generate embedding for reindexed memory", error=str(e))
            return None

    async def _create_reindexed_memory(
        self,
        original: MemoryNode,
        memory_id: str,
        semantic_field: str,
        embedding: Optional[List[float]],
    ) -> Optional[MemoryNode]:
        """Create the new memory node during reindexing.
        
        Args:
            original: The original memory being reindexed
            memory_id: ID to preserve
            semantic_field: New semantic field
            embedding: New embedding vector
            
        Returns:
            Created memory node or None on failure
        """
        logger.info(
            "REINDEX: Creating new memory node with new embedding",
            memory_id=memory_id,
            has_embedding=embedding is not None,
            embedding_dim=len(embedding) if embedding else 0,
        )
        
        new_memory = MemoryNode(
            id=memory_id,  # CRITICAL: Keep same ID for frontend compatibility
            content=original.content,
            title=original.title,
            importance=original.importance,
            confidence=original.confidence,
            embedding=embedding or [],
            source_range=original.source_range,
            semantic_field=semantic_field,
            reindex_needed=False,  # Clear the flag
            last_reindexed_at=datetime.now(timezone.utc),
            metadata=original.metadata,
            created_at=original.created_at,  # Preserve original creation time
            updated_at=datetime.now(timezone.utc),
            source=original.source,
        )
        
        create_success = await self.db.memory_repo.create_memory(new_memory)
        if not create_success:
            logger.error("Failed to create new memory during reindex", memory_id=memory_id)
            return None
            
        return new_memory

    async def reindex_memories_bulk(
        self, memory_ids: Optional[List[str]] = None, batch_size: int = 3
    ) -> Dict[str, Any]:
        """Reindex multiple memories.
        
        Args:
            memory_ids: Specific memory IDs to reindex, or None for all needing reindex
            batch_size: Not currently used (sequential processing)
            
        Returns:
            Dict with success status and details
        """
        logger.info(
            "Starting bulk memory reindex",
            memory_ids_count=len(memory_ids) if memory_ids else "all_needed",
            batch_size=batch_size,
        )

        try:
            # Get memories to reindex
            memories_to_reindex = await self._get_memories_for_reindex(memory_ids)
            
            if not memories_to_reindex:
                logger.info("No memories need reindexing")
                return {
                    "success": True,
                    "total_memories": 0,
                    "reindexed_count": 0,
                    "failed_count": 0,
                    "skipped_count": 0,
                    "details": [],
                }

            logger.info(f"Found {len(memories_to_reindex)} memories to reindex")

            embedding_svc: Optional[EmbeddingService] = None
            requires_legacy_embedding = self._requires_legacy_kuzu_embedding()  # type: ignore[attr-defined]
            if requires_legacy_embedding:
                from ...api.dependencies import get_embedding_service

                embedding_svc = await get_embedding_service()
                if not embedding_svc or not embedding_svc._initialized:  # type: ignore
                    return {
                        "success": False,
                        "error": "Embedding service not available",
                        "total_memories": len(memories_to_reindex),
                        "reindexed_count": 0,
                        "failed_count": 0,
                        "skipped_count": 0,
                    }

            # Process memories and collect results
            results = await self._process_reindex_batch(memories_to_reindex, embedding_svc)

            # Post-processing: checkpoint and recreate index
            await self._finalize_bulk_reindex()

            logger.info(
                "Bulk memory reindex completed",
                total_memories=results["total_memories"],
                reindexed_count=results["reindexed_count"],
                failed_count=results["failed_count"],
                skipped_count=results["skipped_count"],
            )

            return results

        except Exception as e:
            logger.error("Bulk memory reindex failed", error=str(e))
            return {"success": False, "error": str(e)}

    async def _get_memories_for_reindex(
        self, memory_ids: Optional[List[str]]
    ) -> List[MemoryNode]:
        """Get list of memories to reindex.
        
        Args:
            memory_ids: Specific IDs or None for all needing reindex
            
        Returns:
            List of MemoryNode objects
        """
        memories_to_reindex: List[MemoryNode] = []
        
        if memory_ids:
            for memory_id in memory_ids:
                memory = await self.get_memory_by_id(memory_id)
                if memory:
                    memories_to_reindex.append(memory)
                else:
                    logger.warning("Memory not found for reindexing", memory_id=memory_id)
        else:
            memories_to_reindex = await self.db.memory_repo.get_memories_needing_reindex(limit=1000)  # type: ignore
            
        return memories_to_reindex

    async def _process_reindex_batch(
        self, memories: List[MemoryNode], embedding_svc: Optional[EmbeddingService]
    ) -> Dict[str, Any]:
        """Process a batch of memories for reindexing.
        
        Args:
            memories: List of memories to reindex
            embedding_svc: Embedding service instance
            
        Returns:
            Results dict with counts and details
        """
        total_memories = len(memories)
        reindexed_count = 0
        failed_count = 0
        skipped_count = 0
        details: List[Dict[str, Any]] = []

        # Process memories sequentially (KuzuDB concurrency limitations)
        logger.debug(f"Processing {len(memories)} memories sequentially")

        for i, memory in enumerate(memories):
            logger.debug(f"Processing memory {i + 1}/{len(memories)}: {memory.id}")
            
            try:
                result = await self._reindex_single_memory(memory, embedding_svc)
                
                if isinstance(result, dict) and result.get("success"):
                    if result.get("reindexed"):
                        reindexed_count += 1
                        details.append({
                            "memory_id": memory.id,
                            "status": "reindexed",
                            "embedding_dimension": result.get("embedding_dimension", 0),
                        })
                    else:
                        skipped_count += 1
                        details.append({
                            "memory_id": memory.id,
                            "status": "skipped",
                            "reason": result.get("reason", "Already up to date"),
                        })
                else:
                    failed_count += 1
                    error_msg = result.get("error", "Unknown error") if isinstance(result, dict) else str(result)
                    details.append({
                        "memory_id": memory.id,
                        "status": "failed",
                        "error": error_msg,
                    })
                    logger.error(f"Failed to reindex memory {memory.id}", error=error_msg)
                    
            except Exception as e:
                failed_count += 1
                details.append({
                    "memory_id": memory.id,
                    "status": "failed",
                    "error": str(e),
                })
                logger.error(f"Failed to reindex memory {memory.id}: {e}")

        return {
            "success": True,
            "total_memories": total_memories,
            "reindexed_count": reindexed_count,
            "failed_count": failed_count,
            "skipped_count": skipped_count,
            "details": details,
        }

    async def _reindex_single_memory(
        self, memory: MemoryNode, embedding_service: Optional[EmbeddingService]
    ) -> Dict[str, Any]:
        """Helper method to reindex a single memory.
        
        Args:
            memory: Memory to reindex
            embedding_service: Embedding service (not used directly, uses dependency)
            
        Returns:
            Result dict
        """
        try:
            # Check if reindexing is needed
            current_semantic = memory.semantic_field or ""
            expected_semantic = f"{memory.title or ''}\n{memory.content or ''}".strip()

            if current_semantic == expected_semantic and not memory.reindex_needed:
                return {"success": True, "reindexed": False, "reason": "Already up to date"}

            # Use the main reindex_memory method
            result = await self.reindex_memory(memory.id)

            if result["success"] and result.get("reindexed"):
                return {
                    "success": True,
                    "reindexed": True,
                    "memory_id": memory.id,
                    "embedding_dimension": result.get("embedding_dimension", 0),
                }
            elif result["success"] and not result.get("reindexed"):
                return {
                    "success": True,
                    "reindexed": False,
                    "reason": result.get("reason", "Already up to date"),
                }
            else:
                return {"success": False, "error": result.get("error", "Unknown error")}

        except Exception as e:
            return {"success": False, "error": str(e)}

    async def _finalize_bulk_reindex(self) -> None:
        """Finalize bulk reindex with checkpoint and index recreation."""
        # Checkpoint
        try:
            if self.db.conn:
                self.db.conn.execute("CHECKPOINT;")
                logger.info("REINDEX: Checkpoint completed, changes flushed to main DB")
        except Exception as e:
            logger.warning(f"REINDEX: Failed to checkpoint: {e}")

        # Recreate vector index for optimal performance (v1 only)
        # In v2+, LanceDB handles search - skip Kuzu vector index recreation
        from ...database.version_upgrade.db_version_manager import get_db_version
        db_version = get_db_version(self.db.base_client.db_path)
        if db_version < 2:
            try:
                memory_count = await self.db.count_memories(state="all")
                logger.info(
                    "Recreating Kuzu vector index after reindex (v1 database)",
                    memory_count=memory_count,
                )
                await self.db.base_client.recreate_memory_vector_index()  # type: ignore
                logger.info("Vector index recreated successfully after reindex", memory_count=memory_count)
            except Exception as e:
                logger.warning("Failed to recreate vector index after reindex", error=str(e))
        else:
            logger.info(
                "Skipping Kuzu vector index recreation for v2+ database - LanceDB handles search"
            )

    async def get_memories_needing_reindex(
        self, limit: int = 100, offset: int = 0
    ) -> List[MemoryNode]:
        """Get memories that need reindexing.
        
        Args:
            limit: Maximum number to return
            offset: Offset for pagination
            
        Returns:
            List of memories needing reindex
        """
        return await self.db.memory_repo.get_memories_needing_reindex(limit=limit, offset=offset)  # type: ignore

    async def count_memories_needing_reindex(self) -> int:
        """Count memories that need reindexing.
        
        Returns:
            Count of memories needing reindex
        """
        return await self.db.memory_repo.count_memories_needing_reindex()

    async def _transfer_memory_relationships(
        self, old_memory_id: str, new_memory_id: str
    ) -> None:
        """Transfer all relationships from old memory to new memory.
        
        Note: This is a legacy method. The current reindex approach uses
        backup_memory_relationships/restore_memory_relationships instead.
        
        Args:
            old_memory_id: Source memory ID
            new_memory_id: Target memory ID
        """
        import real_ladybug as kuzu
        
        logger.info(
            "Transferring relationships",
            old_memory_id=old_memory_id,
            new_memory_id=new_memory_id,
        )
        try:
            query = """
                MATCH (old_memory:Memory {id: $old_memory_id})
                MATCH (old_memory)-[r]-(other)
                RETURN r, other, startNode(r) AS start, endNode(r) AS end
            """

            assert isinstance(self.db.conn, kuzu.Connection), "conn is not a Connection"
            result = self.db.conn.execute(query, {"old_memory_id": old_memory_id})
            relationships_transferred = 0
            
            while result.has_next():
                row = result.get_next()
                relationship = row[0]
                other_node = row[1]
                start_node = row[2]
                end_node = row[3]
                label: str = relationship.label
                properties: Dict[str, Any] = dict(relationship.properties)
                
                if start_node["id"] == old_memory_id:
                    new_rel_query = f"""
                        MATCH (new_memory:Memory {{id: $new_memory_id}})
                        MATCH (other {{id: $other_id}})
                        CREATE (new_memory)-[r:{label}]->(other)  
                        SET r = $properties
                    """
                    self.db.conn.execute(
                        new_rel_query,
                        {
                            "new_memory_id": new_memory_id,
                            "other_id": other_node["id"],
                            "properties": dict(properties),
                        },
                    )
                else:
                    new_rel_query = f"""
                        MATCH (other {{id: $other_id}})
                        MATCH (new_memory:Memory {{id: $new_memory_id}})
                        CREATE (other)-[r:{label}]->(new_memory)
                        SET r = $properties
                    """
                    self.db.conn.execute(
                        new_rel_query,
                        {
                            "other_id": other_node["id"],
                            "new_memory_id": new_memory_id,
                            "properties": dict(properties),
                        },
                    )
                relationships_transferred += 1
                
            logger.info(
                "Relationships transferred successfully",
                old_memory_id=old_memory_id,
                new_memory_id=new_memory_id,
                count=relationships_transferred,
            )
        except Exception as e:
            logger.error(
                "Failed to transfer relationships",
                old_memory_id=old_memory_id,
                new_memory_id=new_memory_id,
                error=str(e),
            )
            raise
