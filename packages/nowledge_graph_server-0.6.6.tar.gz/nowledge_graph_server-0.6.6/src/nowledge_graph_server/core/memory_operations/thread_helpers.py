"""Thread-related helpers for memory operations.

Handles thread distillation state cleanup when memories are deleted.
"""

import json
from typing import Any, Dict, Optional, TYPE_CHECKING

import real_ladybug as kuzu
import structlog

if TYPE_CHECKING:
    from ...database.kuzu_client import KuzuClient

logger = structlog.get_logger(__name__)


async def get_thread_id_for_memory(db: "KuzuClient", memory_id: str) -> Optional[str]:
    """Get the thread ID that a memory belongs to.
    
    Args:
        db: KuzuClient instance
        memory_id: Memory ID to look up
        
    Returns:
        Thread ID or None if not found
    """
    try:
        query = """
            MATCH (t:Thread)-[:COMPACTS_TO]->(m:Memory {id: $memory_id})
            RETURN t.thread_id as thread_id
        """

        assert isinstance(db.conn, kuzu.Connection), "conn is not a Connection"
        result = db.conn.execute(query, {"memory_id": memory_id})
        assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

        if result.has_next():
            row = result.get_next()
            return row[0]

        return None

    except Exception as e:
        logger.warning(
            "Failed to get thread ID for memory",
            memory_id=memory_id,
            error=str(e),
        )
        return None


async def cleanup_thread_distillation_state_if_needed(
    db: "KuzuClient", thread_id: str
) -> None:
    """Check if thread has remaining memories and clear distillation state if not.
    
    Args:
        db: KuzuClient instance
        thread_id: Thread ID to check
    """
    try:
        query = """
            MATCH (t:Thread {thread_id: $thread_id})-[:COMPACTS_TO]->(m:Memory)
            RETURN count(m) as memory_count
        """
        assert isinstance(db.conn, kuzu.Connection), "conn is not a Connection"
        result = db.conn.execute(query, {"thread_id": thread_id})
        assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"
        
        if result.has_next():
            memory_count = result.get_next()[0]
            if memory_count == 0:
                await clear_thread_distillation_state(db, thread_id)
                logger.info(
                    "Cleared thread distillation state - no memories remaining",
                    thread_id=thread_id,
                )
            else:
                logger.debug(
                    "Thread still has memories, keeping distillation state",
                    thread_id=thread_id,
                    remaining_memories=memory_count,
                )
    except Exception as e:
        logger.warning(
            "Failed to cleanup thread distillation state",
            thread_id=thread_id,
            error=str(e),
        )


async def clear_thread_distillation_state(db: "KuzuClient", thread_id: str) -> None:
    """Clear distillation metadata from a thread.
    
    Args:
        db: KuzuClient instance
        thread_id: Thread ID to clear state from
    """
    try:
        query = """
            MATCH (t:Thread {thread_id: $thread_id})
            RETURN t.metadata as metadata
        """

        assert isinstance(db.conn, kuzu.Connection), "conn is not a Connection"
        result = db.conn.execute(query, {"thread_id": thread_id})
        assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

        if result.has_next():
            metadata_str = result.get_next()[0]
            metadata: Dict[str, Any] = json.loads(metadata_str) if metadata_str else {}

            # Remove distillation-related fields
            updated = False
            if metadata.pop("distilled", None) is not None:
                updated = True
            if metadata.pop("distillation_type", None) is not None:
                updated = True
            if metadata.pop("distilled_at", None) is not None:
                updated = True
            if metadata.pop("memory_count", None) is not None:
                updated = True

            if updated:
                update_query = """
                    MATCH (t:Thread {thread_id: $thread_id})
                    SET t.metadata = $metadata
                """

                db.conn.execute(
                    update_query,
                    {"thread_id": thread_id, "metadata": json.dumps(metadata)},
                )

                logger.info("Cleared distillation metadata from thread", thread_id=thread_id)

    except Exception as e:
        logger.error(
            "Failed to clear thread distillation state",
            thread_id=thread_id,
            error=str(e),
        )
