"""Core memory CRUD operations.

This module contains the base MemoryOperationsBase class with fundamental
memory operations: create, read, update, delete, list, and search.
"""

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import structlog

from ...database.kuzu_client import KuzuClient
from ...models import MemoryNode, MemorySearchResult, MemoryCreateResponse, EntityNode
from ...services.embedding import EmbeddingService
from ...services.entity_extraction import EntityExtractionService
from ...services.embedding_text_prep import prepare_text_for_embedding, needs_summarization
from ...services.search_index import sync_memory_to_index, delete_memory_from_index
from .thread_helpers import (
    get_thread_id_for_memory,
    cleanup_thread_distillation_state_if_needed,
)

logger = structlog.get_logger(__name__)


class MemoryOperationsBase:
    """Base class for memory operations with CRUD functionality."""

    def __init__(
        self,
        db: KuzuClient,
        embedding_service: Optional[EmbeddingService],
        entity_service: Optional[EntityExtractionService] = None,
    ):
        self.db = db
        self.embedding_service = embedding_service
        self.entity_service = entity_service
        self._legacy_kuzu_embedding_required: Optional[bool] = None

    def _requires_legacy_kuzu_embedding(self) -> bool:
        """Whether memory writes still require Kuzu-side embeddings.

        v2+ databases use LanceDB for vector/FTS search and should not initialize
        the legacy embedding runtime just to write Memory rows.
        """
        if self._legacy_kuzu_embedding_required is not None:
            return self._legacy_kuzu_embedding_required

        try:
            from ...database.version_upgrade.db_version_manager import get_db_version

            db_version = get_db_version(self.db.base_client.db_path)
            if db_version >= 2:
                self._legacy_kuzu_embedding_required = False
                return False

            conn = getattr(self.db, "conn", None)
            if conn is not None:
                try:
                    result = conn.execute("CALL table_info('Memory') RETURN *")
                    has_embedding_column = False
                    if hasattr(result, "has_next"):
                        while result.has_next():
                            row = result.get_next()
                            if row and len(row) > 1:
                                col_name = str(row[1]).lower() if row[1] else ""
                                if col_name == "embedding":
                                    has_embedding_column = True
                                    break
                    self._legacy_kuzu_embedding_required = has_embedding_column
                    return has_embedding_column
                except Exception as e:
                    logger.debug(
                        "Failed to inspect Memory schema for embedding column",
                        error=str(e),
                    )

            # Conservative fallback for older databases if schema inspection fails.
            self._legacy_kuzu_embedding_required = True
            return True
        except Exception as e:
            logger.debug(
                "Failed to resolve DB version for embedding requirement check",
                error=str(e),
            )
            self._legacy_kuzu_embedding_required = True
            return True

    # ==================== CREATE ====================

    async def create_memory(
        self,
        content: str,
        title: Optional[str] = None,
        source_id: Optional[str] = None,
        source: Optional[str] = None,
        importance: float = 0.5,
        confidence: float = 0.6,
        metadata: Optional[Dict[str, Any]] = None,
        labels: Optional[List[str]] = None,
        extract_entities: bool = True,
        # Bi-temporal fields
        temporal_type: Optional[str] = None,
        event_start: Optional[str] = None,
        event_end: Optional[str] = None,
        temporal_precision: Optional[str] = None,
        temporal_confidence: Optional[float] = None,
        temporal_context: Optional[str] = None,
        # Knowledge Agent fields (v0.6)
        unit_type: str = "fact",
        # Feed event control
        skip_feed_event: bool = False,
    ) -> Optional[MemoryCreateResponse]:
        """Create a new memory with optional entity extraction and labeling.

        Args:
            content: Memory content text
            title: Optional title (will be auto-generated if not provided)
            source_id: Optional source identifier
            source: Optional source application name
            importance: Importance score 0-1
            confidence: Confidence score 0-1
            metadata: Additional metadata dict
            labels: Labels to assign
            extract_entities: Whether to extract entities (currently disabled)
            temporal_type: Type of temporal reference
            event_start: Event start time
            event_end: Event end time
            temporal_precision: Precision of temporal info
            temporal_confidence: Confidence in temporal info
            temporal_context: Context for temporal info
            unit_type: Knowledge unit type (fact|preference|decision|plan|procedure|learning|context|event)

        Returns:
            MemoryCreateResponse or None on failure
        """
        try:
            logger.debug("=== MEMORY CREATION DEBUG START ===")
            logger.debug(
                f"Content length: {len(content)}, importance: {importance}, confidence: {confidence}"
            )
            logger.debug(f"Source: {source}, Source ID: {source_id}, Title: {title}")

            # Generate embedding
            embedding = await self._generate_embedding_for_create(content, title)

            # Prepare metadata
            memory_metadata = metadata or {}
            memory_metadata.update({
                "created_via": "api",
                "source_id": source_id,
                "extract_entities": extract_entities,
            })

            # Create semantic field
            semantic_field = f"{title or ''}\n{content}".strip()

            # Create memory node
            memory_node = MemoryNode(
                content=content,
                title=title or (content[:50] + "..." if len(content) > 50 else content),
                importance=importance,
                confidence=confidence,
                embedding=embedding,
                source_range=None,
                source=source,
                metadata=memory_metadata,
                semantic_field=semantic_field,
                last_reindexed_at=None,
                temporal_type=temporal_type,
                event_start=event_start,
                event_end=event_end,
                temporal_precision=temporal_precision,
                temporal_confidence=temporal_confidence,
                temporal_context=temporal_context,
                unit_type=unit_type,
            )

            # Create in database
            logger.debug("Creating memory in database...")
            created_memory: Optional[MemoryNode] = await self.db.create_memory(memory_node)
            logger.debug(f"Memory created with ID: {created_memory.id}")  # type: ignore

            # Checkpoint for durability
            self._checkpoint_after_create()

            # Handle entity extraction (currently disabled)
            extracted_entities: List[EntityNode] = []
            extraction_count = 0

            # Assign labels
            assigned_labels = await self._assign_labels_to_memory(
                created_memory.id, labels  # type: ignore
            )

            # For v1: check if Kuzu vector index needs recreation (no-op for v2+)
            await self._maybe_recreate_vector_index_for_low_count(created_memory.id)  # type: ignore

            # Sync to search index (non-blocking, best-effort)
            try:
                await sync_memory_to_index(created_memory)  # type: ignore
            except Exception as sync_error:
                logger.debug(
                    "Search index sync skipped (service may not be available)",
                    memory_id=created_memory.id,  # type: ignore
                    error=str(sync_error),
                )

            # Notify Knowledge Agent (non-blocking, fire-and-forget)
            try:
                from ...agent.manager import get_agent_manager
                import asyncio
                mgr = get_agent_manager()
                if mgr and mgr.is_running:
                    asyncio.create_task(mgr.on_memory_created(created_memory.id))  # type: ignore
            except Exception:
                pass  # Agent notification is best-effort

            # Emit feed event for timeline visibility (unless caller handles it)
            if not skip_feed_event:
                try:
                    from ...utils.feed_events import emit_feed_event
                    emit_feed_event(
                        "memory_created",
                        title=created_memory.title or content[:60],  # type: ignore
                        description=content[:200],
                        related_memory_ids=[created_memory.id],  # type: ignore
                        metadata={"source": source, "unit_type": unit_type},
                    )
                except Exception:
                    pass  # Feed event is best-effort

            logger.debug("=== MEMORY CREATION DEBUG END ===")

            return MemoryCreateResponse(
                memory=created_memory,  # type: ignore
                extracted_entities=extracted_entities,
                assigned_labels=assigned_labels,
                created_relationships=extraction_count,
            )

        except Exception as e:
            logger.error("Memory creation failed", content_length=len(content), error=str(e))
            return None

    async def _generate_embedding_for_create(
        self, content: str, title: Optional[str]
    ) -> Optional[List[float]]:
        """Generate embedding for new memory, handling long content.
        
        Args:
            content: Memory content
            title: Optional title
            
        Returns:
            Embedding vector or None
        """
        from ...api.dependencies import get_embedding_service

        if not self._requires_legacy_kuzu_embedding():
            logger.debug(
                "Skipping legacy Kuzu embedding generation for v2+ LanceDB schema"
            )
            return None

        semantic_field = f"{title or ''}\n{content}".strip()

        logger.debug("Attempting to get embedding service...")
        embedding_svc = await get_embedding_service()
        logger.debug(f"Got embedding service: {embedding_svc is not None}")

        if not embedding_svc or not embedding_svc._initialized:  # type: ignore
            if embedding_svc and not embedding_svc._initialized:  # type: ignore
                logger.error("Embedding service not initialized")
            else:
                logger.warning("Embedding service not available - creating memory without embeddings")
            return None

        logger.debug("Generating embedding...")
        try:
            # Check if content needs summarization
            if needs_summarization(content, title):
                logger.info(
                    "Content exceeds embedding limit, preparing text for embedding",
                    content_length=len(semantic_field),
                )
                
                # Try to get LLM service for summarization
                try:
                    from ...api.dependencies import get_local_llm_service_dep
                    llm_service = await get_local_llm_service_dep()
                except Exception as e:
                    logger.debug("LLM service not available for summarization", error=str(e))
                    llm_service = None

                # Prepare text for embedding
                embedding_text, was_summarized = await prepare_text_for_embedding(
                    content, title, llm_service
                )

                if was_summarized:
                    logger.info(
                        "Using LLM-summarized text for embedding",
                        original_length=len(semantic_field),
                        summary_length=len(embedding_text),
                    )
                else:
                    logger.debug(
                        "Using original text for embedding (will be truncated by embedding service)",
                        text_length=len(embedding_text),
                    )
            else:
                embedding_text = semantic_field

            # Generate embedding with passage prefix (for document indexing)
            embedding = await embedding_svc.embed_text(embedding_text, prefix="passage")
            logger.debug(f"Generated embedding: dimension={len(embedding)}")
            return embedding

        except Exception as e:
            logger.error("Failed to generate embedding", error=str(e))
            return None

    def _checkpoint_after_create(self) -> None:
        """Force checkpoint after memory creation for durability.
        
        Uses the base_client checkpoint method with retry logic to ensure
        WAL is flushed after memory creation.
        """
        try:
            if hasattr(self.db, 'base_client') and self.db.base_client:
                logger.debug("CREATE: Forcing checkpoint to flush WAL immediately after creation")
                success = self.db.base_client.checkpoint(
                    reason="memory_create",
                    retry_count=3,
                    raise_on_failure=False,
                )
                if success:
                    logger.info("CREATE: Checkpoint completed, changes flushed to main DB")
                else:
                    logger.warning(
                        "CREATE: Checkpoint failed after retries - data in WAL",
                        last_failure=self.db.base_client._last_checkpoint_failure,
                    )
            elif self.db.conn:
                # Fallback for direct connection access
                logger.debug("CREATE: Forcing checkpoint to flush WAL (fallback)")
                self.db.conn.execute("CHECKPOINT;")
                logger.info("CREATE: Checkpoint completed via fallback")
        except Exception as e:
            logger.error(f"CREATE: CRITICAL - Checkpoint failed after memory creation: {e}")

    async def _assign_labels_to_memory(
        self, memory_id: str, labels: Optional[List[str]]
    ) -> List[str]:
        """Assign labels to a memory.
        
        Args:
            memory_id: Memory ID
            labels: List of label names
            
        Returns:
            List of successfully assigned labels
        """
        if not labels:
            return []

        logger.debug(f"Assigning {len(labels)} labels...")
        assigned: List[str] = []
        
        try:
            for label_name in labels:
                try:
                    await self.db.label_mgr.assign_label_to_memory(memory_id, label_name)
                    assigned.append(label_name)
                except Exception as e:
                    logger.warning("Failed to assign label", label=label_name, error=str(e))
            logger.debug(f"Assigned labels: {assigned}")
        except Exception as e:
            logger.warning("Label assignment failed", error=str(e))

        return assigned

    async def _maybe_recreate_vector_index_for_low_count(self, memory_id: str) -> None:
        """Recreate Kuzu vector index if memory count is low (v1 only).

        In v2+, LanceDB handles search - this is a no-op.

        Args:
            memory_id: ID of newly created memory (for logging)
        """
        # Skip for v2+ databases - LanceDB handles search
        from ...database.version_upgrade.db_version_manager import get_db_version
        db_version = get_db_version(self.db.base_client.db_path)
        if db_version >= 2:
            return  # LanceDB handles search in v2+

        try:
            memory_count = await self.db.count_memories(state="all")
            if memory_count < 5:
                logger.info(
                    "Low memory count detected after creation - recreating Kuzu vector index (v1)",
                    memory_count=memory_count,
                    memory_id=memory_id,
                )
                await self.db.base_client.recreate_memory_vector_index()  # type: ignore
                logger.info("Vector index recreated successfully", memory_count=memory_count)
        except Exception as e:
            logger.warning("Failed to recreate vector index after memory creation", error=str(e))

    # ==================== READ ====================

    async def get_memory_by_id(self, memory_id: str) -> Optional[MemoryNode]:
        """Get a specific memory by ID.
        
        Args:
            memory_id: Memory ID
            
        Returns:
            MemoryNode or None if not found
        """
        try:
            return await self.db.get_memory_by_id(memory_id)
        except Exception as e:
            logger.error("Failed to get memory", memory_id=memory_id, error=str(e))
            raise

    async def list_memories(
        self,
        limit: int = 20,
        offset: int = 0,
        state: str = "active",
        importance_min: float = 0.0,
        created_after: Optional[datetime] = None,
        labels: Optional[List[str]] = None,
    ) -> List[MemoryNode]:
        """List memories with filtering and pagination.
        
        Args:
            limit: Maximum memories to return
            offset: Offset for pagination
            state: Filter by state (active, paused, archived, deleted, all)
            importance_min: Minimum importance score
            created_after: Filter to memories created after this time
            labels: Filter to memories with these labels
            
        Returns:
            List of MemoryNode objects
        """
        try:
            return await self.db.list_memories(
                limit=min(limit, 200),
                offset=offset,
                state=state,
                importance_min=importance_min,
                created_after=created_after,
                labels=labels,
            )
        except Exception as e:
            logger.error("Memory list failed", error=str(e))
            raise

    # ==================== SEARCH ====================

    async def search_memories(
        self,
        query: str,
        limit: int = 10,
        include_entities: bool = False,
        filter_labels: Optional[List[str]] = None,
        metadata_filters: Optional[Dict[str, Any]] = None,
    ) -> List[MemorySearchResult]:
        """Search memories using semantic similarity.
        
        Args:
            query: Search query text
            limit: Maximum results
            include_entities: Include related entities
            filter_labels: Filter by labels
            metadata_filters: Filter by metadata
            
        Returns:
            List of MemorySearchResult objects
        """
        try:
            logger.info("=== CORE MEMORY SEARCH DEBUG ===")
            logger.info(f"Parameters: query='{query}', limit={limit}")

            # Generate query embedding
            from ...api.dependencies import get_embedding_service

            embedding_svc = await get_embedding_service()

            if not embedding_svc or not embedding_svc._initialized:  # type: ignore
                logger.warning(
                    "Embedding service not available - search functionality limited",
                    has_service=embedding_svc is not None,
                    initialized=embedding_svc._initialized if embedding_svc else False,  # type: ignore
                )
                return []

            logger.info("Generating query embedding...")
            query_embedding = await embedding_svc.embed_text(query, prefix="query")
            logger.info(
                f"Generated embedding: dimension={len(query_embedding)}, first 5 values={query_embedding[:5]}"
            )

            # Search in database
            logger.info("Calling database search...")
            results = await self.db.search_memories(
                query_embedding=query_embedding,
                query_text="",
                limit=min(limit, 100),
                include_entities=include_entities,
                filters={"labels": filter_labels} if filter_labels else {},
                metadata_filters=metadata_filters,
            )

            logger.info(f"Database search returned {len(results)} results")
            logger.info("=== CORE MEMORY SEARCH DEBUG END ===")
            return results

        except Exception as e:
            logger.error("Memory search failed", query=query, error=str(e))
            raise

    # ==================== UPDATE ====================

    async def update_memory_state(
        self, memory_id: str, new_state: str, updated_by: Optional[str] = None
    ) -> Dict[str, Any]:
        """Update memory lifecycle state.
        
        Args:
            memory_id: Memory ID
            new_state: New state (active, paused, archived, deleted)
            updated_by: Who made the update
            
        Returns:
            Dict with update details
        """
        try:
            valid_states = ["active", "paused", "archived", "deleted"]
            if new_state not in valid_states:
                raise ValueError(f"Invalid state: {new_state}. Must be one of: {valid_states}")

            memory: Optional[MemoryNode] = await self.get_memory_by_id(memory_id)
            if not memory:
                raise ValueError(f"Memory not found: {memory_id}")

            old_state = memory.metadata.get("state", "active")

            # Update state in metadata
            memory.metadata["state"] = new_state
            memory.metadata["updated_by"] = updated_by
            memory.metadata["state_updated_at"] = datetime.now(timezone.utc).isoformat()
            memory.updated_at = datetime.now(timezone.utc)

            await self.db.update_memory(memory)

            # Handle cascade deletion
            if new_state == "deleted":
                await self._handle_memory_deletion(memory_id)

            return {
                "memory_id": memory_id,
                "old_state": old_state,
                "new_state": new_state,
                "updated_by": updated_by,
                "updated_at": memory.updated_at.isoformat(),
            }

        except Exception as e:
            logger.error("Memory state update failed", memory_id=memory_id, error=str(e))
            raise

    async def _handle_memory_deletion(self, memory_id: str) -> None:
        """Handle cascade deletion when memory is marked as deleted.

        This includes removing the memory from the LanceDB search index.

        Args:
            memory_id: Memory ID being deleted
        """
        logger.info("Handling memory deletion cascade", memory_id=memory_id)

        # Delete from LanceDB search index
        try:
            await delete_memory_from_index(memory_id)
        except Exception as sync_error:
            logger.debug(
                "Search index delete skipped on state change",
                memory_id=memory_id,
                error=str(sync_error),
            )

        # TODO: Implement cascade deletion logic for related entities

    # ==================== DELETE ====================

    async def delete_memory(
        self,
        memory_id: str,
        cascade_delete: bool = True,
        run_post_deletion_maintenance: bool = True,
    ) -> Dict[str, Any]:
        """Delete a memory and optionally its relationships.
        
        Args:
            memory_id: Memory ID to delete
            cascade_delete: Whether to cascade delete relationships
            run_post_deletion_maintenance: Whether to run checkpoint/index maintenance
            
        Returns:
            Dict with deletion results
        """
        try:
            memory = await self.get_memory_by_id(memory_id)
            if not memory:
                # If the graph row is already missing but LanceDB still has this ID,
                # clean it up best-effort to prevent persistent orphan search hits.
                try:
                    await delete_memory_from_index(memory_id)
                except Exception as sync_error:
                    logger.debug(
                        "Search index orphan cleanup skipped on missing memory",
                        memory_id=memory_id,
                        error=str(sync_error),
                    )
                return {
                    "memory_id": memory_id,
                    "deleted": False,
                    "error": f"Memory not found: {memory_id}",
                }

            # Check for thread association
            thread_id = await get_thread_id_for_memory(self.db, memory_id)

            if cascade_delete:
                result = await self.db.memory_repo.delete_memory_with_cascade(memory_id)
                logger.info(
                    "Memory deleted with cascade",
                    memory_id=memory_id,
                    deleted_relationships=result.get("deleted_relationships", 0),
                    deleted_entities=result.get("deleted_entities", 0),
                    orphaned_entities_found=result.get("orphaned_entities_found", 0),
                )
            else:
                success = await self.db.memory_repo.delete_memory(memory_id)
                if success:
                    result = {
                        "memory_id": memory_id,
                        "deleted": True,
                        "cascade_deletion": False,
                        "deleted_relationships": 0,
                        "deleted_entities": 0,
                    }
                else:
                    return {"deleted": False, "error": "Failed to delete memory"}

            # Post-deletion maintenance
            if result.get("deleted", False):
                if run_post_deletion_maintenance:
                    await self._handle_post_deletion_maintenance(memory_id)

                # Sync deletion to search index (non-blocking, best-effort)
                try:
                    await delete_memory_from_index(memory_id)
                except Exception as sync_error:
                    logger.debug(
                        "Search index delete sync skipped",
                        memory_id=memory_id,
                        error=str(sync_error),
                    )

            # Thread cleanup
            if thread_id and result.get("deleted", False):
                await cleanup_thread_distillation_state_if_needed(self.db, thread_id)

            return result

        except Exception as e:
            logger.error("Memory deletion failed", memory_id=memory_id, error=str(e))
            return {"memory_id": memory_id, "deleted": False, "error": str(e)}

    async def bulk_delete_memories(
        self,
        memory_ids: List[str],
        cascade_delete: bool = True,
    ) -> Dict[str, Any]:
        """Delete multiple memories and return aggregate results.

        Args:
            memory_ids: Memory IDs to delete
            cascade_delete: Whether to cascade delete relationships/entities

        Returns:
            Bulk deletion result dictionary with summary and per-memory results
        """
        # Preserve order while removing duplicates and empty IDs.
        normalized_ids: List[str] = []
        seen_ids: set[str] = set()
        for memory_id in memory_ids:
            clean_id = memory_id.strip()
            if not clean_id or clean_id in seen_ids:
                continue
            normalized_ids.append(clean_id)
            seen_ids.add(clean_id)

        results: List[Dict[str, Any]] = []
        deleted_count = 0
        failed_count = 0
        total_deleted_relationships = 0
        total_deleted_entities = 0
        deleted_since_checkpoint = 0
        checkpoint_interval = 25

        logger.info(
            "Bulk memory deletion started",
            requested_count=len(memory_ids),
            normalized_count=len(normalized_ids),
            cascade_delete=cascade_delete,
        )

        for memory_id in normalized_ids:
            try:
                result = await self.delete_memory(
                    memory_id=memory_id,
                    cascade_delete=cascade_delete,
                    run_post_deletion_maintenance=False,
                )
            except Exception as e:
                logger.error(
                    "Error deleting memory in bulk operation",
                    memory_id=memory_id,
                    error=str(e),
                )
                result = {"memory_id": memory_id, "deleted": False, "error": str(e)}

            if "memory_id" not in result or not result.get("memory_id"):
                result["memory_id"] = memory_id

            results.append(result)

            if result.get("deleted"):
                deleted_count += 1
                deleted_since_checkpoint += 1
                total_deleted_relationships += result.get("deleted_relationships", 0)
                total_deleted_entities += result.get("deleted_entities", 0)

                if deleted_since_checkpoint >= checkpoint_interval:
                    await self._handle_post_deletion_maintenance("bulk_delete:checkpoint")
                    deleted_since_checkpoint = 0
            else:
                failed_count += 1

        if deleted_count > 0 and deleted_since_checkpoint > 0:
            await self._handle_post_deletion_maintenance("bulk_delete:final")

        logger.info(
            "Bulk memory deletion completed",
            deleted_count=deleted_count,
            failed_count=failed_count,
            total_deleted_relationships=total_deleted_relationships,
            total_deleted_entities=total_deleted_entities,
        )

        return {
            "requested_count": len(memory_ids),
            "processed_count": len(normalized_ids),
            "deleted_count": deleted_count,
            "failed_count": failed_count,
            "total_deleted_relationships": total_deleted_relationships,
            "total_deleted_entities": total_deleted_entities,
            "cascade_delete": cascade_delete,
            "results": results,
        }

    async def _handle_post_deletion_maintenance(self, memory_id: str) -> None:
        """Handle post-deletion database maintenance.
        
        Args:
            memory_id: Deleted memory ID (for logging)
        """
        try:
            memory_count = await self.db.count_memories(state="all")
            logger.debug(
                "Memory count after deletion",
                memory_id=memory_id,
                count=memory_count,
            )

            db_version = None
            if hasattr(self.db, "base_client") and self.db.base_client:
                try:
                    from ...database.version_upgrade.db_version_manager import (
                        get_db_version,
                    )
                    db_version = get_db_version(self.db.base_client.db_path)
                except Exception as version_error:
                    logger.debug(
                        "Failed to read database version for checkpoint policy",
                        memory_id=memory_id,
                        error=str(version_error),
                    )

            if memory_count == 0 and db_version is not None and db_version < 2:
                # Skip checkpoint on empty Memory table for v0/v1 to avoid KuzuDB bug #6045.
                logger.debug(
                    "Memory table empty on v0/v1 - skipping checkpoint",
                    memory_id=memory_id,
                    db_version=db_version,
                )
            else:
                # Normal checkpoint with retry logic
                if hasattr(self.db, 'base_client') and self.db.base_client:
                    logger.debug("DELETE: Forcing checkpoint to flush WAL", memory_id=memory_id)
                    success = self.db.base_client.checkpoint(
                        reason=f"memory_delete:{memory_id}",
                        retry_count=3,
                        raise_on_failure=False,
                    )
                    if success:
                        logger.info("DELETE: Checkpoint completed", memory_id=memory_id)
                    else:
                        logger.warning(
                            "DELETE: Checkpoint failed after retries - data in WAL",
                            memory_id=memory_id,
                            last_failure=self.db.base_client._last_checkpoint_failure,
                        )
                elif self.db.conn:
                    # Fallback for direct connection access
                    logger.debug("DELETE: Forcing checkpoint to flush WAL (fallback)", memory_id=memory_id)
                    self.db.conn.execute("CHECKPOINT;")
                    logger.info("DELETE: Checkpoint completed via fallback", memory_id=memory_id)

        except Exception as e:
            logger.warning(
                "Failed to handle post-deletion index maintenance",
                memory_id=memory_id,
                error=str(e),
            )

    # ==================== ENTITY HELPERS ====================

    async def _extract_and_link_entities(
        self, memory_id: str, content: str
    ) -> Tuple[List[EntityNode], int]:
        """Extract entities and link them to memory.
        
        Note: Entity extraction during memory creation is currently disabled.
        Entities are extracted during the memory distillation phase instead.
        
        Args:
            memory_id: Memory ID to link entities to
            content: Content text to extract entities from
            
        Returns:
            Tuple of (extracted_entities, relationship_count)
        """
        try:
            logger.debug(
                "Entity extraction during memory creation is disabled - "
                "entities will be extracted during memory distillation phase",
                memory_id=memory_id,
            )
            return [], 0

        except Exception as e:
            logger.warning(
                "Entity extraction failed", memory_id=memory_id, error=str(e)
            )
            return [], 0

    async def _create_or_find_entity(self, entity_data: Dict[str, Any]) -> EntityNode:
        """Create new entity or find existing one.
        
        Args:
            entity_data: Entity data dict with name, type, etc.
            
        Returns:
            EntityNode
        """
        entity_node = EntityNode(
            name=entity_data["name"],
            entity_type=entity_data.get("type", "concept"),
            description=entity_data.get("description", ""),
            confidence=entity_data.get("confidence", 0.6),
        )

        return await self.db.create_or_find_entity(entity_node)
