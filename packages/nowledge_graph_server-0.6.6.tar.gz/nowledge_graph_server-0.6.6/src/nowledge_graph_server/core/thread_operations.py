"""Core thread operations - shared business logic."""

import hashlib
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set

import structlog

from ..database.kuzu_client import KuzuClient
from ..models import (
    ThreadCreateResponse,
    ThreadFetchResponse,
    ThreadSearchResult,
    ThreadNode,
)
from ..services.embedding import EmbeddingService
from ..services.memory_compaction import MemoryCompactionService
from ..services.search_index import (
    get_search_index_service,
)
from ..core.graph_operations import GraphOperations

logger = structlog.get_logger(__name__)

_EXTERNAL_ID_KEYS = (
    "external_id",
    "source_message_id",
    "message_id",
    "openclaw_entry_id",
)


def _normalize_message_metadata(value: Any) -> Dict[str, Any]:
    if isinstance(value, dict):
        return dict(value)
    return {}


def _extract_external_message_id(message: Dict[str, Any]) -> str:
    for key in _EXTERNAL_ID_KEYS:
        value = message.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()

    metadata = _normalize_message_metadata(message.get("metadata"))
    for key in _EXTERNAL_ID_KEYS:
        value = metadata.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _merge_message_metadata(message: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize metadata and copy key top-level identifiers into metadata."""
    metadata = _normalize_message_metadata(message.get("metadata"))
    for key in _EXTERNAL_ID_KEYS:
        if key in metadata:
            continue
        value = message.get(key)
        if isinstance(value, str) and value.strip():
            metadata[key] = value.strip()

    for key in ("source", "session_key", "session_id"):
        if key in metadata:
            continue
        value = message.get(key)
        if isinstance(value, str) and value.strip():
            metadata[key] = value.strip()
    return metadata


class ThreadOperations:
    """Core thread operations shared between API and MCP interfaces."""

    def __init__(
        self,
        db: KuzuClient,
        embedding_service: Optional[EmbeddingService],
        graph_ops: GraphOperations,
        memory_service: Optional[MemoryCompactionService] = None,
    ):
        self.db: KuzuClient = db
        self.embedding_service: Optional[EmbeddingService] = embedding_service
        self.memory_service: Optional[MemoryCompactionService] = memory_service
        self.graph_ops: GraphOperations = graph_ops

    async def create_thread(
        self,
        thread_id: str,
        messages: List[Dict[str, Any]],
        title: Optional[str] = None,
        source: Optional[str] = None,
        participants: Optional[List[str]] = None,
        project: Optional[str] = None,
        workspace: Optional[str] = None,
        tool_version: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        auto_extract_memories: bool = True,
    ) -> ThreadCreateResponse:
        """Create a conversation thread with messages.

        Args:
            thread_id: Unique thread identifier
            messages: List of message objects
            title: Thread title
            source: Source application
            participants: List of participants
            project: Project identifier
            workspace: Workspace path
            tool_version: Tool version
            metadata: Additional metadata
            auto_extract_memories: Whether to auto-extract memories

        Returns:
            ThreadCreateResponse with creation details
        """
        try:
            normalized_messages: List[Dict[str, Any]] = []
            for msg in messages:
                if not isinstance(msg, dict):
                    continue
                msg_copy = dict(msg)
                msg_copy["metadata"] = _merge_message_metadata(msg_copy)
                normalized_messages.append(msg_copy)

            # Create thread in database
            response = await self.db.create_thread(
                thread_id=thread_id,
                messages=normalized_messages,
                title=title or f"Conversation from {source or 'unknown'}",
                participants=participants or [],
                source=source,
                project=project,
                workspace=workspace,
                tool_version=tool_version,
                import_date=datetime.now(timezone.utc),
                metadata=metadata or {},
            )

            # Auto-extract memories if requested and possible
            # TODO: this seemed to not yet implemented the compaction logic.
            extracted_memories = []  # type: ignore[assignment]
            if (
                auto_extract_memories
                and self.memory_service
                and len(normalized_messages) > 5
            ):
                try:
                    raise NotImplementedError("Memory compaction is not implemented")
                    # compaction_response = await self.memory_service.compact_thread(
                    #     thread_id
                    # )
                    # extracted_memories = compaction_response.created_memories
                except Exception as e:
                    logger.warning(
                        "Memory compaction failed", thread_id=thread_id, error=str(e)
                    )

            # Update response with memory extraction results
            response.extracted_memories = extracted_memories
            response.auto_extraction_performed = (
                auto_extract_memories and len(extracted_memories) > 0
            )

            # Optional: denormalize counts and last_activity on thread node for faster listing
            try:
                await self.db.thread_repo._update_thread_denormalized_fields(  # type: ignore[attr-defined]
                    thread_id=thread_id
                )
            except Exception as _:
                pass

            return response

        except Exception as e:
            logger.error("Thread creation failed", thread_id=thread_id, error=str(e))
            raise

    async def get_thread(self, thread_id: str) -> Optional[ThreadFetchResponse]:
        """Get a complete thread with all messages.

        Args:
            thread_id: Thread identifier

        Returns:
            ThreadFetchResponse if found, None otherwise
        """
        try:
            # Normalize thread_id to match how it's stored (lowercase, spaces to dashes)
            normalized_thread_id = thread_id.lower().replace(" ", "-")
            return await self.db.fetch_thread(normalized_thread_id)
        except Exception as e:
            logger.error("Failed to get thread", thread_id=thread_id, error=str(e))
            raise

    async def get_thread_summaries(self) -> List[Dict[str, str]]:
        """Get all thread summaries for UI autocomplete."""
        try:
            thread_repo = self.db.thread_repo  # type: ignore[attr-defined]
            return await thread_repo.get_all_thread_summaries()  # type: ignore[attr-defined]
        except Exception as e:
            logger.error("Failed to get thread summaries", error=str(e))
            return []

    async def search_threads_enhanced(
        self,
        query: str,
        mode: str = "full",
        limit: int = 20,
        use_lancedb: bool = True,  # deprecated, always True in v2
    ) -> Dict[str, Any]:
        """Enhanced thread search using LanceDB FTS-only search (v2+).

        Uses FTS-only search (not hybrid) with:
        - Tantivy BM25 for full-text search

        Note: Thread/message search uses FTS-only per design:
        - Memory/Entity/Community search: hybrid (vector + FTS)
        - Thread/Message search: FTS-only

        Args:
            query: Search query string
            mode: "suggestions" (title/summary only) or "full" (includes messages)
            limit: Maximum results to return
            use_lancedb: Deprecated, always True in v2

        Returns:
            {
                "threads": [...],
                "total_found": int,
                "search_metadata": {
                    "query": str,
                    "mode": str,
                    "matched_messages_count": int,
                    "search_engine": str
                }
            }
        """
        try:
            # v2: LanceDB is the ONLY search path
            # Thread search uses FTS-only (no embedding required)
            search_service = await get_search_index_service()

            if not search_service:
                logger.warning(
                    "Thread search unavailable - search index not initialized.",
                    query=query[:30],
                )
                return {
                    "threads": [],
                    "total_found": 0,
                    "search_metadata": {
                        "query": query,
                        "mode": mode,
                        "matched_messages_count": 0,
                        "search_engine": "unavailable",
                    },
                }

            try:
                lancedb_results = await self._search_threads_lancedb_internal(
                    query=query,
                    limit=limit,
                )

                # Calculate total matched messages
                total_matched_messages = sum(
                    r.get("total_matches", 1) for r in lancedb_results
                )

                logger.debug(
                    "🔍 LanceDB thread search completed (FTS-only)",
                    results=len(lancedb_results),
                )

                return {
                    "threads": lancedb_results,
                    "total_found": len(lancedb_results),
                    "search_metadata": {
                        "query": query,
                        "mode": mode,
                        "matched_messages_count": total_matched_messages,
                        "search_engine": "lancedb_fts",
                    },
                }
            except Exception as lancedb_error:
                logger.error(
                    "LanceDB thread search failed",
                    error=str(lancedb_error),
                    query=query[:30],
                )
                return {
                    "threads": [],
                    "total_found": 0,
                    "search_metadata": {
                        "query": query,
                        "mode": mode,
                        "matched_messages_count": 0,
                        "search_engine": "lancedb_error",
                    },
                }

        except Exception as e:
            logger.error("Enhanced thread search failed", query=query, error=str(e))
            return {
                "threads": [],
                "total_found": 0,
                "search_metadata": {
                    "query": query,
                    "mode": mode,
                    "matched_messages_count": 0,
                    "error": str(e),
                },
            }

    async def _search_threads_lancedb_internal(
        self,
        query: str,
        limit: int = 20,
    ) -> List[Dict[str, Any]]:
        """Internal method for LanceDB FTS-only thread search.

        This searches messages in LanceDB using FTS-only (not hybrid).
        Thread/message search uses FTS-only per design:
        - Memory/Entity/Community search: hybrid (vector + FTS)
        - Thread/Message search: FTS-only
        """
        search_service = await get_search_index_service()

        if not search_service:
            return []

        # Search messages in LanceDB using FTS-only (not hybrid)
        results = await search_service.search_messages_fts(
            query_text=query,
            limit=limit * 3,  # Get more messages to group by thread
        )

        # Group results by thread and build thread info
        thread_results: Dict[str, Dict[str, Any]] = {}
        for result in results:
            thread_id = result.data.get("thread_id", "")
            if not thread_id:
                continue

            # Build matched message info in the format expected by UI
            # UI expects: message_id, message_index, role, snippet, match_score
            message_index = result.data.get("order_index", 0)
            if message_index is None:
                message_index = 0

            # Safe score handling - None becomes 0.0
            safe_score = result.score if result.score is not None else 0.0

            match_info = {
                "message_id": result.id,
                "message_index": message_index,
                "role": result.data.get("role", "user"),
                "snippet": result.data.get("content", "")[:200],
                "match_score": safe_score,
            }

            if thread_id not in thread_results:
                # Fetch thread from Kuzu for complete data
                thread = await self.db.thread_repo.fetch_thread(thread_id)
                if thread:
                    thread_results[thread_id] = {
                        "id": thread.thread.id,
                        "thread_id": thread.thread.thread_id,
                        "title": thread.thread.title,
                        "summary": thread.thread.summary or "",
                        "message_count": len(thread.messages),
                        "participants": thread.thread.participants or [],
                        "source": thread.thread.source or "",
                        "last_activity": thread.thread.updated_at,
                        "relevance_score": safe_score,
                        "total_matches": 1,
                        "matched_messages": [match_info],
                    }
            else:
                # Update existing thread entry
                thread_results[thread_id]["total_matches"] += 1
                if safe_score > thread_results[thread_id]["relevance_score"]:
                    thread_results[thread_id]["relevance_score"] = safe_score
                # Add matched message (no limit - UI will show top 2 in list, all in detail)
                thread_results[thread_id]["matched_messages"].append(match_info)

        # Sort by relevance score and limit
        sorted_results = sorted(
            thread_results.values(),
            key=lambda x: x["relevance_score"],
            reverse=True,
        )[:limit]

        return sorted_results

    async def search_threads(
        self,
        query: str,
        limit: int = 10,
        source: Optional[str] = None,
        created_after: Optional[datetime] = None,
        participants: Optional[List[str]] = None,
    ) -> List[ThreadSearchResult]:
        """Legacy search threads method (kept for backward compatibility).

        Args:
            query: Search query
            limit: Maximum results
            source: Filter by source application
            created_after: Filter by creation date
            participants: Filter by participants

        Returns:
            List of ThreadSearchResult objects
        """
        try:
            # Use enhanced search and convert to legacy format
            enhanced_results = await self.search_threads_enhanced(
                query=query,
                mode="full",
                limit=limit,
            )

            # Convert to legacy ThreadSearchResult format
            thread_results: List[ThreadSearchResult] = []
            for result in enhanced_results.get("threads", []):  # type: ignore[union-attr]
                thread = ThreadNode(
                    id=result["id"],  # type: ignore[index,typeddict-item]
                    thread_id=result["thread_id"],  # type: ignore[index,typeddict-item]
                    title=result["title"],  # type: ignore[index,typeddict-item]
                    summary=result.get("summary") or "",  # type: ignore[union-attr]
                    message_count=result["message_count"],  # type: ignore[index,typeddict-item]
                    participants=result.get("participants", []),  # type: ignore[union-attr]
                    source=result.get("source", ""),  # type: ignore[union-attr]
                    created_at=result.get("last_activity")
                    or datetime.now(timezone.utc),  # type: ignore[union-attr]
                    updated_at=result.get("last_activity")
                    or datetime.now(timezone.utc),  # type: ignore[union-attr]
                )

                thread_results.append(
                    ThreadSearchResult(
                        thread=thread,
                        similarity_score=result.get("relevance_score", 0.0),  # type: ignore[union-attr]
                        match_reason=f"Found {result.get('total_matches', 0)} message matches",  # type: ignore[union-attr]
                        message_count=result["message_count"],  # type: ignore[index,typeddict-item]
                        recent_activity=result.get("last_activity")
                        or datetime.now(timezone.utc),  # type: ignore[union-attr]
                    )
                )

            return thread_results

        except Exception as e:
            logger.error("Thread search failed", query=query, error=str(e))
            raise

    async def list_threads(
        self,
        limit: int = 20,
        offset: int = 0,
        source: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """List threads quickly using lightweight projection and aggregation."""
        try:
            results = await self.db.list_threads(
                limit=limit,
                offset=offset,
                source=source,
            )
            return results

        except Exception as e:
            logger.error("Failed to list threads", error=str(e))
            raise

    async def compact_thread_to_memories(
        self,
        thread_id: str,
        compaction_strategy: str = "auto",
        target_memory_count: Optional[int] = None,
        preserve_detail: bool = False,
    ) -> Dict[str, Any]:
        """Compact thread messages into memories.

        Args:
            thread_id: Thread to compact
            compaction_strategy: Strategy (auto, summary, key_points)
            target_memory_count: Target number of memories
            preserve_detail: Whether to preserve detailed information

        Returns:
            Compaction result dictionary
        """
        return {}
        # try:
        #     if not self.memory_service:
        #         raise ValueError("Memory compaction service not available")

        #     # Get thread for validation
        #     thread = await self.get_thread(thread_id)
        #     if not thread:
        #         raise ValueError(f"Thread not found: {thread_id}")

        #     # TODO: this seems to not yet implemented the compaction logic.
        #     # Perform compaction
        #     response = await self.memory_service.compact_thread_to_memories(
        #         thread_id=thread_id,
        #         compaction_strategy=compaction_strategy,
        #         target_memory_count=target_memory_count,
        #         preserve_detail=preserve_detail,
        #     )

        #     return {
        #         "thread_id": thread_id,
        #         "created_memories": len(response.created_memories),
        #         "messages_processed": response.messages_processed,
        #         "entities_extracted": response.entities_extracted,
        #         "relationships_created": response.relationships_created,
        #         "compaction_summary": response.compaction_summary,
        #     }

        # except Exception as e:
        #     logger.error("Thread compaction failed", thread_id=thread_id, error=str(e))
        #     raise

    async def get_thread_stats(self) -> Dict[str, Any]:
        """Get thread statistics.

        Returns:
            Dictionary with thread statistics
        """
        try:
            stats = await self.graph_ops.get_graph_stats()

            # Enhance with thread-specific stats
            thread_stats = {
                "total_threads": stats.get("thread_count", 0),
                "total_messages": stats.get("message_count", 0),
                "threads_by_source": await self._get_threads_by_source(),
                "avg_messages_per_thread": await self._get_avg_messages_per_thread(),
                "recent_threads_count": await self._get_recent_threads_count(),
                "compacted_threads_count": await self._get_compacted_threads_count(),
            }

            return thread_stats

        except Exception as e:
            logger.error("Failed to get thread stats", error=str(e))
            raise

    async def delete_thread(
        self,
        thread_id: str,
        cascade_delete_memories: bool = False,
    ) -> Dict[str, Any]:
        """Delete a thread and optionally its extracted memories.

        Args:
            thread_id: Thread to delete
            cascade_delete_memories: Whether to delete extracted memories

        Returns:
            Deletion result dictionary
        """
        try:
            # Normalize thread_id to match how it's stored (lowercase, spaces to dashes)
            # This matches the ThreadNode validator behavior
            normalized_thread_id = thread_id.lower().replace(" ", "-")
            
            logger.info(
                "Thread deletion started",
                thread_id=thread_id,
                normalized_thread_id=normalized_thread_id,
                cascade_delete_memories=cascade_delete_memories,
            )

            # Get thread for validation using normalized ID
            thread = await self.get_thread(normalized_thread_id)
            if not thread:
                logger.warning(
                    "Thread not found for deletion", 
                    thread_id=thread_id,
                    normalized_thread_id=normalized_thread_id
                )
                return {
                    "thread_id": normalized_thread_id,
                    "deleted": False,
                    "error": f"Thread not found: {thread_id}",
                    "deleted_messages": 0,
                    "deleted_memories": 0,
                    "cascade_deletion": cascade_delete_memories,
                }

            logger.info(
                "Thread found for deletion",
                thread_id=normalized_thread_id,
                message_count=len(thread.messages),
            )

            # Get related memories if cascade deletion requested
            deleted_memories: List[str] = []
            if cascade_delete_memories:
                logger.info(
                    "Cascade deletion requested, finding memories", thread_id=normalized_thread_id
                )
                # Get all memories extracted from this thread
                memory_ids: List[
                    str
                ] = await self.db.memory_repo.get_memories_by_thread(normalized_thread_id)  # type: ignore[attr-defined]
                logger.info(
                    "Found memories to delete",
                    thread_id=normalized_thread_id,
                    memory_count=len(memory_ids),
                )

                # Delete each memory with cascade to clean up orphaned entities
                for memory_id in memory_ids:
                    try:
                        # Use database cascade deletion directly
                        memory_result = (
                            await self.db.memory_repo.delete_memory_with_cascade(
                                memory_id
                            )
                        )

                        if memory_result.get("deleted", False):
                            deleted_memories.append(memory_id)
                            logger.info(
                                "Memory deleted in cascade",
                                memory_id=memory_id,
                                thread_id=normalized_thread_id,
                            )
                        else:
                            logger.warning(
                                "Failed to delete memory in cascade",
                                memory_id=memory_id,
                                thread_id=normalized_thread_id,
                            )
                    except Exception as e:
                        logger.error(
                            "Error deleting memory in cascade",
                            memory_id=memory_id,
                            thread_id=normalized_thread_id,
                            error=str(e),
                        )

                logger.info(
                    "Cascade memory deletion completed",
                    thread_id=normalized_thread_id,
                    deleted_count=len(deleted_memories),
                )

            # Delete thread (includes messages via CASCADE)
            logger.info("Attempting database deletion", thread_id=normalized_thread_id)
            success = await self.db.thread_repo.delete_thread(normalized_thread_id)
            if not success:
                logger.error("Database deletion failed", thread_id=normalized_thread_id)
                return {
                    "thread_id": normalized_thread_id,
                    "deleted": False,
                    "error": "Database deletion failed",
                    "deleted_messages": 0,
                    "deleted_memories": 0,
                    "cascade_deletion": cascade_delete_memories,
                }

            logger.info("Database deletion successful", thread_id=normalized_thread_id)

            # Delete related memories if requested
            if cascade_delete_memories:
                logger.info(
                    "Processing cascade memory deletion",
                    thread_id=thread_id,
                    memory_count=len(deleted_memories),
                )
                for memory_id in deleted_memories:
                    await self.db.delete_memory(memory_id)

            logger.info(
                "Thread deleted successfully",
                thread_id=normalized_thread_id,
                deleted_messages=len(thread.messages),
                cascade_deletion=cascade_delete_memories,
            )

            return {
                "thread_id": normalized_thread_id,
                "deleted": True,
                "deleted_messages": len(thread.messages),
                "deleted_memories": len(deleted_memories),
                "cascade_deletion": cascade_delete_memories,
            }

        except Exception as e:
            logger.error(
                "Thread deletion failed",
                thread_id=thread_id,
                error=str(e),
                cascade_delete_memories=cascade_delete_memories,
            )
            return {
                "thread_id": thread_id.lower().replace(" ", "-") if thread_id else "",
                "deleted": False,
                "error": str(e),
                "deleted_messages": 0,
                "deleted_memories": 0,
                "cascade_deletion": cascade_delete_memories,
            }

    async def bulk_delete_threads(
        self,
        thread_ids: List[str],
        cascade_delete_memories: bool = False,
    ) -> Dict[str, Any]:
        """Delete multiple threads and optionally their extracted memories.

        Args:
            thread_ids: List of thread IDs to delete
            cascade_delete_memories: Whether to delete extracted memories

        Returns:
            Bulk deletion result dictionary with summary and per-thread results
        """
        logger.info(
            "Bulk thread deletion started",
            thread_count=len(thread_ids),
            cascade_delete_memories=cascade_delete_memories,
        )

        results: List[Dict[str, Any]] = []
        deleted_count = 0
        failed_count = 0
        total_deleted_messages = 0
        total_deleted_memories = 0

        for thread_id in thread_ids:
            try:
                result = await self.delete_thread(
                    thread_id=thread_id,
                    cascade_delete_memories=cascade_delete_memories,
                )
                results.append(result)

                if result.get("deleted"):
                    deleted_count += 1
                    total_deleted_messages += result.get("deleted_messages", 0)
                    total_deleted_memories += result.get("deleted_memories", 0)
                else:
                    failed_count += 1

            except Exception as e:
                logger.error(
                    "Error deleting thread in bulk operation",
                    thread_id=thread_id,
                    error=str(e),
                )
                failed_count += 1
                results.append(
                    {
                        "thread_id": thread_id,
                        "deleted": False,
                        "error": str(e),
                        "deleted_messages": 0,
                        "deleted_memories": 0,
                        "cascade_deletion": cascade_delete_memories,
                    }
                )

        logger.info(
            "Bulk thread deletion completed",
            deleted_count=deleted_count,
            failed_count=failed_count,
            total_deleted_messages=total_deleted_messages,
            total_deleted_memories=total_deleted_memories,
        )

        return {
            "deleted_count": deleted_count,
            "failed_count": failed_count,
            "total_deleted_messages": total_deleted_messages,
            "total_deleted_memories": total_deleted_memories,
            "cascade_deletion": cascade_delete_memories,
            "results": results,
        }

    async def append_messages(
        self,
        thread_id: str,
        messages: List[Dict[str, Any]],
        deduplicate: bool = False,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Append messages to an existing thread.

        Args:
            thread_id: Thread identifier
            messages: List of message objects to append
            deduplicate: Skip messages that already exist (by content hash)
            idempotency_key: Optional key to derive stable external_ids per batch

        Returns:
            Dict with messages_added, total_messages, thread_id

        Raises:
            ValueError: If thread doesn't exist or messages are invalid
        """
        try:
            # Normalize thread_id to match how it's stored (lowercase, spaces to dashes)
            # This matches the ThreadNode validator behavior
            normalized_thread_id = thread_id.lower().replace(" ", "-")

            # Verify thread exists
            thread = await self.db.fetch_thread(normalized_thread_id)
            if not thread:
                raise ValueError(f"Thread not found: {thread_id}")

            current_message_count = len(thread.messages)

            # Get existing message content hashes if deduplication is enabled
            existing_hashes: Set[str] = set()
            existing_external_ids: Set[str] = set()
            if deduplicate:
                for msg in thread.messages:
                    # MessageNode is a Pydantic model, access attribute directly
                    content = getattr(msg, "content", "")
                    if content:
                        content_hash = hashlib.md5(content.encode()).hexdigest()
                        existing_hashes.add(content_hash)
                    metadata = _normalize_message_metadata(getattr(msg, "metadata", {}))
                    for key in _EXTERNAL_ID_KEYS:
                        value = metadata.get(key)
                        if isinstance(value, str) and value.strip():
                            existing_external_ids.add(value.strip())

            # Filter and prepare messages for insertion
            messages_to_add: List[Dict[str, Any]] = []
            for i, msg in enumerate(messages):
                if not isinstance(msg, dict):  # type: ignore[arg-type, call-overload]
                    continue

                msg_copy: Dict[str, Any] = dict(msg)
                metadata = _merge_message_metadata(msg_copy)

                if idempotency_key and not _extract_external_message_id(msg_copy):
                    metadata["external_id"] = f"idem:{idempotency_key}:{i}"
                msg_copy["metadata"] = metadata

                # Deduplicate if enabled
                if deduplicate:
                    external_id = _extract_external_message_id(msg_copy)
                    has_external_id = bool(external_id)
                    if external_id:
                        if external_id in existing_external_ids:
                            logger.debug(
                                "Skipping duplicate message by external_id",
                                thread_id=thread_id,
                                external_id=external_id,
                            )
                            continue
                        existing_external_ids.add(external_id)

                    # Content-hash dedup is fallback-only for payloads without stable external IDs.
                    if not has_external_id:
                        content = msg_copy.get("content", "")
                        if content:
                            content_hash = hashlib.md5(content.encode()).hexdigest()
                            if content_hash in existing_hashes:
                                logger.debug(
                                    "Skipping duplicate message",
                                    thread_id=thread_id,
                                    content_preview=content[:50],
                                )
                                continue
                            existing_hashes.add(content_hash)

                messages_to_add.append(msg_copy)

            if not messages_to_add:
                logger.info(
                    "No new messages to append",
                    thread_id=thread_id,
                    filtered_count=0,
                )
                return {
                    "thread_id": thread_id,
                    "messages_added": 0,
                    "total_messages": current_message_count,
                }

            # Append messages to thread
            await self.db.thread_repo.append_messages(  # type: ignore[attr-defined]
                thread_id=normalized_thread_id,
                messages=messages_to_add,
                start_index=current_message_count,
            )

            # Update denormalized fields
            try:
                await self.db.thread_repo._update_thread_denormalized_fields(  # type: ignore[attr-defined]
                    thread_id=normalized_thread_id
                )
            except Exception as _:
                pass

            logger.info(
                "Messages appended successfully",
                thread_id=thread_id,
                messages_added=len(messages_to_add),  # type: ignore[arg-type]
                total_messages=current_message_count + len(messages_to_add),  # type: ignore[arg-type]
                deduplicated=deduplicate,
            )

            return {
                "thread_id": thread_id,
                "messages_added": len(messages_to_add),  # type: ignore[arg-type]
                "total_messages": current_message_count + len(messages_to_add),  # type: ignore[arg-type]
            }

        except ValueError:
            raise
        except Exception as e:
            logger.error(
                "Failed to append messages",
                thread_id=thread_id,
                message_count=len(messages),
                error=str(e),
            )
            raise ValueError(f"Failed to append messages: {e}")

    # Private helper methods

    async def _get_threads_by_source(self) -> Dict[str, int]:
        """Get thread counts by source."""
        # TODO: Implement in KuzuClient
        return {}

    async def _get_avg_messages_per_thread(self) -> float:
        """Get average messages per thread."""
        # TODO: Implement in KuzuClient
        return 0.0

    async def _get_recent_threads_count(self, days: int = 7) -> int:
        """Get count of threads created in last N days."""
        # TODO: Implement in KuzuClient
        return 0

    async def _get_compacted_threads_count(self) -> int:
        """Get count of threads that have been compacted to memories."""
        # TODO: Implement in KuzuClient
        return 0
