"""Core search operations - LanceDB hybrid search (v2+).

In v2, search is handled by LanceDB with:
- 1024-dim embeddings (Qwen3 on macOS Apple Silicon, BGE-M3 on non-Apple-Silicon)
- Tantivy BM25 for full-text search
- RRF (Reciprocal Rank Fusion) for combining results

Kuzu is used for graph traversal (entities, communities) but not for vector/FTS search.

Search modes:
- "deep": Full multi-strategy search with LLM context analysis, temporal intent, decay scoring
- "fast": Quick search with vector + FTS + entity + community (no LLM)
"""

import asyncio
import datetime
from typing import Any, Dict, List, Optional, cast

import structlog

from ..database.kuzu_client import KuzuClient
from ..models import (
    MemorySearchResult,
    ThreadSearchResult,
    EntityNode,
)
from ..services.search_index import (
    get_search_index_service,
    get_bge_m3_service,
)

# Import LanceDB search utilities and strategies
from ..database.search_engine_lancedb import (
    _analyze_search_context,
    _build_memory_node,
    _fuse_hybrid_results,
    _fuse_vector_fts_fast,
    _deduplicate_results,
    _apply_filters,
    _search_by_labels,
    apply_decay_scoring,
    llm_rerank_results,
    STOP_WORDS,
)
from ..database.search_strategies_lancedb import (
    memory_hybrid_strategy,
    community_strategy,
    entity_strategy,
    entity_strategy_fast,
    community_strategy_fast,
)

logger = structlog.get_logger(__name__)


class SearchOperations:
    """Core search operations powered by LanceDB hybrid search (v2+).

    In v2, all vector/FTS search is handled by LanceDB with:
    - 1024-dim embeddings (Qwen3 on macOS Apple Silicon, BGE-M3 on non-Apple-Silicon)
    - Tantivy BM25 for full-text search
    - RRF (Reciprocal Rank Fusion) for combining results

    Kuzu is used for graph traversal (entities, communities) and storage.

    Search modes:
    - "deep": Full multi-strategy search with LLM context analysis
    - "fast": Quick search without LLM overhead
    """

    def __init__(
        self,
        db: KuzuClient,
        embedding_service: Optional[Any] = None,  # deprecated, kept for compatibility
    ):
        self.db = db
        self._last_search_context: Optional[Dict[str, Any]] = None

    async def search(self, query: str, limit: int = 20, **kwargs: Any) -> List["MemorySearchResult"]:
        """Backward-compatible alias for search_memories()."""
        return await self.search_memories(query=query, limit=limit, **kwargs)

    async def search_memories(
        self,
        query: str,
        limit: int = 20,
        include_entities: bool = False,
        filter_labels: Optional[List[str]] = None,
        metadata_filters: Optional[Dict[str, Any]] = None,
        importance_min: float = 0.0,
        search_mode: str = "comprehensive",  # kept for compatibility
        mode: str = "fast",  # "deep" or "fast"
        use_lancedb: bool = True,  # deprecated, always True in v2
        # Bi-temporal filters
        event_date_from: Optional[str] = None,
        event_date_to: Optional[str] = None,
        recorded_date_from: Optional[str] = None,
        recorded_date_to: Optional[str] = None,
        temporal_context: Optional[str] = None,
        confidence_threshold: float = 0.2,
    ) -> List["MemorySearchResult"]:
        """Memory search using LanceDB hybrid search with multi-strategy approach (v2+).

        Three focused search strategies:
        1. Memory Hybrid: Vector + FTS over memories (LanceDB)
        2. Community Mediated: Community search -> graph traversal -> memories
        3. Entity Mediated: Entity search -> graph traversal -> memories

        Args:
            query: Search query text
            limit: Maximum results (1-100)
            include_entities: Include related entities in results
            filter_labels: Filter by label names
            metadata_filters: Additional metadata filters
            importance_min: Minimum importance threshold (0.0-1.0)
            search_mode: Deprecated, kept for compatibility
            mode: "deep" (full LLM analysis) or "fast" (no LLM)
            use_lancedb: Deprecated, always True in v2
            event_date_from: Filter by event date (when it happened)
            event_date_to: Upper bound for event date
            recorded_date_from: Filter by record date (when we learned it)
            recorded_date_to: Upper bound for record date
            temporal_context: Filter by temporal context (past, present, future, timeless)
            confidence_threshold: Minimum confidence for results

        Returns:
            List of MemorySearchResult objects with relevance_reason explanations
        """
        if not query.strip():
            return []

        try:
            logger.debug(
                "🔍 Memory search started",
                query=query[:50] if query else "[empty]",
                limit=limit,
                mode=mode,
                importance_min=importance_min,
                filter_labels=filter_labels,
            )

            # Check if LanceDB services are available
            search_service = await get_search_index_service()
            bge_service = await get_bge_m3_service()

            if not search_service or not bge_service:
                logger.warning(
                    "Memory search unavailable - search index not initialized. "
                    "Please download the search embedding model to enable search.",
                    query=query[:30],
                )
                return []

            # Build filters dict
            filters = {}
            if importance_min > 0:
                filters["importance_min"] = importance_min
            if filter_labels:
                filters["labels"] = filter_labels
            if event_date_from:
                filters["event_date_from"] = event_date_from
            if event_date_to:
                filters["event_date_to"] = event_date_to
            if recorded_date_from:
                filters["recorded_date_from"] = recorded_date_from
            if recorded_date_to:
                filters["recorded_date_to"] = recorded_date_to
            if temporal_context:
                filters["temporal_context"] = temporal_context
            if confidence_threshold > 0:
                filters["confidence_min"] = confidence_threshold

            search_limit = (100 if filters else limit * 2) if mode == "fast" else (200 if filters else limit * 2)

            # Initialize graph traversal tracking
            graph_traversal_stats = {
                "entities_traversed": 0,
                "relationships_traversed": 0,
                "communities_analyzed": 0,
            }

            # For fast mode, skip LLM-based context; use simple default weights
            if mode == "fast":
                search_context = {
                    "mode": mode,
                    "intent": "Normal",
                    "specificity": "specific" if len(query.split()) <= 2 else "broad",
                    "is_question": False,
                    "key_terms": [],
                    "weights": {"vector": 0.8, "fts": 0.2},
                    "query_text": query,
                    "advanced": {
                        "use_hyde": False,
                        "hyde_query": None,
                        "label_search_enabled": True,
                        "potential_labels": [],
                    },
                }
            else:
                # Deep mode: Start intent analysis as background task
                # This allows search strategies to begin while LLM analyzes the query
                intent_task = asyncio.create_task(_analyze_search_context(query))

                # Use default context while intent analysis runs in parallel
                search_context = {
                    "mode": mode,
                    "intent": "analyzing...",
                    "specificity": "broad",
                    "is_question": "?" in query,
                    "key_terms": [],
                    "weights": {"vector": 0.7, "fts": 0.3, "entity": 0.3, "community": 0.2},
                    "query_text": query,
                    "advanced": {
                        "use_hyde": False,
                        "hyde_query": None,
                        "label_search_enabled": True,
                        "potential_labels": [],
                    },
                    "_intent_task": intent_task,  # Store for later retrieval
                }

            # Initialize debug report
            search_context.setdefault("debug_report", {
                "query": query,
                "mode": mode,
                "events": [],
                "intent": {},
                "weights": {},
                "samples": {},
            })
            search_context["debug_report"]["events"].append(
                {"stage": "start", "timestamp": datetime.datetime.now().isoformat()}
            )

            # Store context for API access
            self._last_search_context = search_context

            logger.debug(
                "🔍 Starting unified search",
                query=query[:50],
                limit=limit,
                search_limit=search_limit,
                mode=mode,
                weights=search_context.get("weights"),
            )

            try:
                if mode == "fast":
                    return await self._search_memories_fast(
                        query=query,
                        search_limit=search_limit,
                        limit=limit,
                        search_context=search_context,
                        graph_traversal_stats=graph_traversal_stats,
                        filters=filters if filters else None,
                    )
                else:
                    return await self._search_memories_deep(
                        query=query,
                        search_limit=search_limit,
                        limit=limit,
                        search_context=search_context,
                        graph_traversal_stats=graph_traversal_stats,
                        filters=filters if filters else None,
                    )

            except Exception as e:
                logger.error("Search failed", error=str(e), mode=mode)
                return []

        except Exception as e:
            logger.error("🔍 Memory search failed", query=query, error=str(e))
            raise

    async def _search_memories_fast(
        self,
        query: str,
        search_limit: int,
        limit: int,
        search_context: Dict[str, Any],
        graph_traversal_stats: Dict[str, int],
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[MemorySearchResult]:
        """Fast mode: Vector + FTS + Entity + Community search without LLM overhead."""
        search_service = await get_search_index_service()
        bge_service = await get_bge_m3_service()

        if not search_service or not bge_service:
            return []

        # Generate query embedding (is_query=True for search queries)
        query_embedding = await bge_service.embed_text(query, is_query=True)

        # Vector + FTS search via LanceDB hybrid
        lancedb_results = await search_service.search_memories_hybrid(
            query_text=query,
            query_embedding=query_embedding,
            limit=search_limit,
        )

        # Convert to tuple format for fusion - use separate vector and FTS scores
        vector_memories = []
        fts_memories = []
        for result in lancedb_results:
            # Use actual separate scores from hybrid search
            v_score = result.vector_score if result.vector_score is not None else 0.0
            f_score = result.fts_score if result.fts_score is not None else 0.0
            vector_memories.append((result.data, max(0.0, v_score), "vector"))
            fts_memories.append((result.data, max(0.0, f_score), "fts"))

        # Label-based search
        label_memories = []
        if search_context.get("advanced", {}).get("label_search_enabled"):
            potential_labels = [
                label.strip()
                for label in query.split()
                if label.strip() and label.strip() not in STOP_WORDS and len(label.strip()) > 3
            ]
            label_memories = await _search_by_labels(self.db, potential_labels, limit)
            logger.debug(f"🏷️ Label search returned {len(label_memories)} results")

        # Entity-based search (fast mode - no LLM)
        entity_memories = await entity_strategy_fast(
            self.db, query, search_limit, graph_traversal_stats
        )
        logger.debug(f"🔗 Entity search returned {len(entity_memories)} results")

        # Community-based search (fast mode - no LLM)
        community_memories = await community_strategy_fast(
            self.db, query, search_limit, graph_traversal_stats
        )
        logger.debug(f"👥 Community search returned {len(community_memories)} results")

        # Fuse all results
        fast_results = await _fuse_hybrid_results(
            self.db,
            vector_memories,
            fts_memories,
            limit,
            label_memories,
            search_context,
            entity_memories,
            community_memories,
        )

        # Apply filters
        if filters:
            fast_results = _apply_filters(self.db, fast_results, filters)

        pre_decay_results = fast_results[:limit]

        # Apply decay scoring
        final_results = apply_decay_scoring(self.db, pre_decay_results, search_context)

        logger.debug(
            "🔍 Fast search completed",
            total_results=len(final_results),
            graph_stats=graph_traversal_stats,
        )

        return final_results

    async def _search_memories_deep(
        self,
        query: str,
        search_limit: int,
        limit: int,
        search_context: Dict[str, Any],
        graph_traversal_stats: Dict[str, int],
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[MemorySearchResult]:
        """Deep mode: Full multi-strategy search with LLM context analysis.

        Optimized for latency:
        - Intent analysis runs in parallel with search strategies
        - Entity extraction runs in parallel with other strategies
        - Weights are applied during fusion after intent analysis completes
        """
        # Check if we have a pending intent analysis task
        intent_task = search_context.pop("_intent_task", None)

        # Use default weights initially (will be updated after intent analysis)
        weights = search_context.get("weights", {"vector": 0.7, "fts": 0.3, "entity": 0.3, "community": 0.2})
        refined_intent = search_context.get("refined_intent", "exploratory_search")

        # Use generous limits initially (weight adjustment happens after intent analysis)
        base_limit = search_limit
        memory_limit = base_limit
        community_limit = base_limit // 2
        entity_limit = base_limit // 2

        logger.debug(
            f"🎯 Initial limits (parallel mode): memory={memory_limit}, community={community_limit}, entity={entity_limit}"
        )

        # Run all strategies in parallel with intent analysis
        strategies_to_run = [
            memory_hybrid_strategy(self.db, query, memory_limit, search_context),
            community_strategy(self.db, query, community_limit, graph_traversal_stats),
            entity_strategy(self.db, query, entity_limit, graph_traversal_stats),
        ]
        strategy_names = ["Memory Hybrid", "Community", "Entity"]

        # Execute strategies AND intent analysis concurrently
        if intent_task:
            # Add intent task to the gather
            all_tasks = strategies_to_run + [intent_task]
            all_results_raw = await asyncio.gather(*all_tasks, return_exceptions=True)

            # Extract strategy results and intent result
            strategy_results = all_results_raw[:3]
            intent_result = all_results_raw[3]

            # Update search_context with actual intent analysis
            if isinstance(intent_result, dict):
                search_context.update(cast(Dict[str, Any], intent_result))
                weights = search_context.get("weights", weights)
                refined_intent = search_context.get("refined_intent", refined_intent)
                logger.debug(
                    f"🎯 Intent analysis completed (parallel): {refined_intent}, weights={weights}"
                )
            elif isinstance(intent_result, Exception):
                logger.warning("Intent analysis failed (parallel mode)", error=str(intent_result))
        else:
            strategy_results = await asyncio.gather(*strategies_to_run, return_exceptions=True)

        logger.debug(
            f"🎯 Applying weights: memory={weights.get('vector', 0.6):.2f}, community={weights.get('community', 0.2):.2f}, entity={weights.get('entity', 0.3):.2f}"
        )

        # Collect and weight results
        all_results = []

        strategy_weight_mapping = {
            0: max(weights.get("vector", 0.6), weights.get("fts", 0.4)),  # Memory Hybrid
            1: weights.get("community", 0.2),  # Community
            2: weights.get("entity", 0.3),  # Entity
        }

        # Calculate active strategies for normalization
        active_strategies = []
        total_active_weight = 0.0

        for i, result in enumerate(strategy_results):
            if isinstance(result, list) and len(result) > 0:
                active_strategies.append(i)
                total_active_weight += strategy_weight_mapping.get(i, 1.0)

        # Normalize weights
        if total_active_weight > 0:
            weight_boost_factor = min(1.2, 1.0 / total_active_weight)
        else:
            weight_boost_factor = 1.0

        for i, result in enumerate(strategy_results):
            if isinstance(result, Exception):
                logger.warning(f"Strategy {i + 1} ({strategy_names[i]}) failed", error=str(result))
                continue

            if isinstance(result, list):
                raw_weight = strategy_weight_mapping.get(i, 1.0)
                strategy_weight = min(raw_weight * weight_boost_factor, 1.0)

                # Apply weight as score multiplier
                for search_result in result:
                    original_score = search_result.similarity_score
                    weighted_score = min(original_score * strategy_weight, 1.0)

                    weighted_result = MemorySearchResult(
                        memory=search_result.memory,
                        similarity_score=weighted_score,
                        relevance_reason=f"{search_result.relevance_reason} (weight: {strategy_weight:.2f})",
                        related_entities=getattr(search_result, "related_entities", []),
                    )
                    all_results.append(weighted_result)

                logger.debug(
                    f"📊 {strategy_names[i]} strategy: {len(result)} results with weight {strategy_weight:.2f}"
                )

        # Deduplicate
        deduplicated_results = _deduplicate_results(all_results, search_limit)

        # Apply filters
        if filters:
            filtered_results = _apply_filters(self.db, deduplicated_results, filters)
            logger.debug(f"Filtered {len(deduplicated_results)} → {len(filtered_results)} results")
        else:
            filtered_results = deduplicated_results

        pre_decay_results = filtered_results[:limit]

        # Apply decay scoring with temporal intent (deep mode feature)
        decay_results = apply_decay_scoring(self.db, pre_decay_results, search_context)

        # LLM Reranking: Deep mode exclusive feature
        # Uses LLM to evaluate relevance and generate human-friendly explanations
        # Reduced to top 5 for better latency (was 10) while maintaining quality
        final_results = await llm_rerank_results(
            query=query,
            results=decay_results,
            top_k=min(limit, 5),  # Rerank top 5 to balance cost/quality
        )

        # Attach graph traversal metadata
        for result in final_results:
            if hasattr(result, "memory") and result.memory and hasattr(result.memory, "metadata"):
                if not result.memory.metadata:
                    result.memory.metadata = {}
                result.memory.metadata["graph_traversal"] = graph_traversal_stats

        # Annotate with EVOLVES chain context (v0.6)
        final_results = self._annotate_evolves_context(final_results)

        logger.debug(
            "🔍 Deep search completed (with LLM rerank)",
            total_results=len(final_results),
            pre_filter_count=len(deduplicated_results),
            post_filter_count=len(filtered_results),
            graph_stats=graph_traversal_stats,
        )

        return final_results

    def _annotate_evolves_context(
        self, results: List[MemorySearchResult]
    ) -> List[MemorySearchResult]:
        """Annotate search results with EVOLVES chain context.

        For each result, queries KuzuDB for 1-hop EVOLVES neighbors and adds
        version history information. This helps users understand knowledge evolution.
        """
        try:
            conn = self.db.conn
            for result in results:
                if result.memory is None:
                    continue
                memory_id = result.memory.id
                context: Dict[str, Any] = {}

                # Outgoing EVOLVES: this memory is the older one
                try:
                    assert conn is not None, "Database connection not available"
                    out_result = conn.execute(
                        """
                        MATCH (a:Memory)-[e:EVOLVES]->(b:Memory)
                        WHERE a.id = $id
                        RETURN b.id, b.title, e.content_relation
                        """,
                        {"id": memory_id},
                    )
                    newer = []
                    while out_result.has_next():
                        row = out_result.get_next()
                        newer.append({
                            "id": row[0],
                            "title": row[1],
                            "relation": row[2],
                        })
                    if newer:
                        context["newer_versions"] = newer
                except Exception as e:
                    logger.error("EVOLVES annotation skipped", error=str(e))

                # Incoming EVOLVES: this memory is the newer one
                try:
                    assert conn is not None, "Database connection not available"
                    in_result = conn.execute(
                        """
                        MATCH (a:Memory)-[e:EVOLVES]->(b:Memory)
                        WHERE b.id = $id
                        RETURN a.id, a.title, e.content_relation
                        """,
                        {"id": memory_id},
                    )
                    older = []
                    while in_result.has_next():
                        row = in_result.get_next()
                        older.append({
                            "id": row[0],
                            "title": row[1],
                            "relation": row[2],
                        })
                    if older:
                        context["older_versions"] = older
                except Exception as e:
                    logger.error("EVOLVES annotation skipped", error=str(e))

                if context:
                    result.evolves_context = context
        except Exception as e:
            logger.debug("EVOLVES annotation skipped", error=str(e))

        return results

    def get_last_search_context(self) -> Optional[Dict[str, Any]]:
        """Get the search context from the last search for debugging/UI."""
        return self._last_search_context

    # ==================== Entity and Community Search ====================

    async def _search_entities_concurrent(
        self, query: str, limit: int
    ) -> List[EntityNode]:
        """Search entities using LanceDB hybrid search (v2+)."""
        try:
            search_service = await get_search_index_service()
            bge_service = await get_bge_m3_service()

            if not search_service or not bge_service:
                logger.warning("Entity search unavailable - search index not initialized.")
                return []

            query_embedding = await bge_service.embed_text(query, is_query=True)

            results = await search_service.search_entities_hybrid(
                query_text=query,
                query_embedding=query_embedding,
                limit=limit,
            )

            entities = []
            for result in results:
                entity = EntityNode(
                    id=result.id,
                    name=result.data.get("name", ""),
                    entity_type=result.data.get("entity_type", ""),
                    confidence=min(result.score, 1.0),
                    description=result.data.get("description"),
                    metadata={},
                )
                entities.append(entity)

            logger.debug("🔍 LanceDB entity search completed", results=len(entities))
            return entities

        except Exception as e:
            logger.error("Entity search failed", query=query, error=str(e))
            return []

    async def _search_communities_concurrent(
        self, query: str, limit: int
    ) -> List[Dict[str, Any]]:
        """Search communities using LanceDB hybrid search (v2+)."""
        try:
            search_service = await get_search_index_service()
            bge_service = await get_bge_m3_service()

            if not search_service or not bge_service:
                logger.warning("Community search unavailable - search index not initialized.")
                return []

            query_embedding = await bge_service.embed_text(query, is_query=True)

            results = await search_service.search_communities_hybrid(
                query_text=query,
                query_embedding=query_embedding,
                limit=limit,
            )

            communities = []
            for result in results:
                community = {
                    "id": result.id,
                    "name": result.data.get("name", ""),
                    "description": result.data.get("description", ""),
                    "ai_summary": result.data.get("ai_summary", ""),
                    "member_count": result.data.get("member_count", 0),
                    "search_score": result.score,
                }
                communities.append(community)

            logger.debug("🔍 LanceDB community search completed", results=len(communities))
            return communities

        except Exception as e:
            logger.error("Community search failed", query=query, error=str(e))
            return []

    # ==================== Thread Search (FTS-only) ====================

    async def search_threads_lancedb(
        self,
        query: str,
        limit: int = 10,
    ) -> List[ThreadSearchResult]:
        """Search thread messages using LanceDB FTS-only search.

        Note: Thread search uses FTS-only (not hybrid) per design.
        """
        try:
            search_service = await get_search_index_service()

            if not search_service:
                logger.debug("LanceDB thread search not available")
                return []

            results = await search_service.search_messages_fts(
                query_text=query,
                limit=limit * 3,
            )

            thread_results: Dict[str, ThreadSearchResult] = {}
            for result in results:
                thread_id = result.data.get("thread_id", "")
                if not thread_id:
                    continue

                safe_score = max(0.0, result.score) if result.score is not None else 0.0

                if thread_id not in thread_results:
                    thread = await self.db.thread_repo.fetch_thread(thread_id)
                    if thread:
                        snippet = (result.data.get("content") or "")[:200]
                        thread_results[thread_id] = ThreadSearchResult(
                            thread=thread.thread,
                            similarity_score=safe_score,
                            match_reason=snippet or None,
                            message_count=len(thread.messages),
                            recent_activity=thread.thread.updated_at,
                        )
                else:
                    if safe_score > thread_results[thread_id].similarity_score:
                        thread_results[thread_id].similarity_score = safe_score
                        thread_results[thread_id].match_reason = (result.data.get("content") or "")[:200] or None

            sorted_results = sorted(
                thread_results.values(),
                key=lambda x: x.similarity_score,
                reverse=True,
            )[:limit]

            return sorted_results

        except Exception as e:
            logger.warning("LanceDB thread search failed", query=query[:30], error=str(e))
            return []

    # ==================== Legacy Methods ====================

    async def _search_memories_concurrent(
        self,
        query: str,
        query_embedding: List[float],
        limit: int,
    ) -> List[MemorySearchResult]:
        """Legacy method - delegates to search_memories."""
        return await self.search_memories(query=query, limit=limit, mode="fast")

    async def search_memories_lancedb(
        self,
        query: str,
        limit: int = 20,
        hybrid_alpha: float = 0.5,
        fts_weight: float = 0.5,
    ) -> List[MemorySearchResult]:
        """Legacy method - delegates to search_memories with fast mode."""
        return await self.search_memories(query=query, limit=limit, mode="fast")

    async def search_communities_lancedb(
        self,
        query: str,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """Search communities using LanceDB hybrid search (v2+)."""
        return await self._search_communities_concurrent(query, limit)
