"""EVOLVES chain traversal and graph query utilities.

Provides operations for traversing EVOLVES chains, querying memory
neighbors, and listing crystals — used by MCP tools and search.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import structlog

from ..database.kuzu_client import KuzuClient

logger = structlog.get_logger(__name__)


class EvolvesOperations:
    """Utilities for traversing and querying the knowledge graph."""

    def __init__(self, db: KuzuClient) -> None:
        self._db = db

    async def get_evolves_chain(
        self,
        memory_id: str,
        max_depth: int = 10,
    ) -> Dict[str, Any]:
        """Get the full EVOLVES version chain for a memory.

        Traverses both directions to find the complete chain,
        from oldest ancestor to newest descendant.

        Returns:
            Dict with chain members ordered oldest→newest,
            the queried memory's position, and chain metadata.
        """
        try:
            conn = self._db.conn
            visited: set[str] = set()
            chain: List[Dict[str, Any]] = []

            # Walk backward to find ancestors (incoming EVOLVES)
            ancestors = self._walk_chain(
                conn, memory_id, direction="backward",
                max_depth=max_depth, visited=visited,
            )

            # Walk forward to find descendants (outgoing EVOLVES)
            descendants = self._walk_chain(
                conn, memory_id, direction="forward",
                max_depth=max_depth, visited=visited,
            )

            # Get the queried memory itself
            center = self._get_memory_summary(conn, memory_id)

            # Assemble chain: ancestors (oldest first) + center + descendants
            chain = list(reversed(ancestors)) + [center] + descendants

            return {
                "memory_id": memory_id,
                "chain_length": len(chain),
                "position": len(ancestors),  # 0-indexed position of queried memory
                "chain": chain,
            }

        except Exception as e:
            logger.error("get_evolves_chain failed", error=str(e))
            return {
                "memory_id": memory_id,
                "chain_length": 0,
                "chain": [],
                "error": str(e),
            }

    def _walk_chain(
        self,
        conn: Any,
        start_id: str,
        direction: str,
        max_depth: int,
        visited: set[str],
    ) -> List[Dict[str, Any]]:
        """Walk an EVOLVES chain in one direction.

        direction="backward": follow incoming edges (find ancestors)
        direction="forward": follow outgoing edges (find descendants)
        """
        result_chain: List[Dict[str, Any]] = []
        current_id = start_id
        visited.add(current_id)

        for _ in range(max_depth):
            if direction == "backward":
                # Find the memory that EVOLVES into current (ancestor)
                query = """
                    MATCH (a:Memory)-[e:EVOLVES]->(b:Memory)
                    WHERE b.id = $id
                    RETURN a.id, a.title, a.content, e.content_relation,
                           e.confidence, a.is_latest, a.unit_type
                    LIMIT 1
                """
            else:
                # Find the memory that current EVOLVES into (descendant)
                query = """
                    MATCH (a:Memory)-[e:EVOLVES]->(b:Memory)
                    WHERE a.id = $id
                    RETURN b.id, b.title, b.content, e.content_relation,
                           e.confidence, b.is_latest, b.unit_type
                    LIMIT 1
                """

            try:
                result = conn.execute(query, {"id": current_id})
                if not result.has_next():
                    break
                row = result.get_next()
                next_id = row[0]
                if next_id in visited:
                    break  # Cycle detection
                visited.add(next_id)

                result_chain.append({
                    "id": next_id,
                    "title": row[1],
                    "content_preview": (row[2] or "")[:200],
                    "relation_to_next": row[3] if direction == "backward" else None,
                    "relation_from_prev": row[3] if direction == "forward" else None,
                    "confidence": row[4],
                    "is_latest": row[5],
                    "unit_type": row[6],
                })
                current_id = next_id
            except Exception:
                break

        return result_chain

    def _get_memory_summary(self, conn: Any, memory_id: str) -> Dict[str, Any]:
        """Get a summary of a single memory."""
        try:
            result = conn.execute(
                """
                MATCH (m:Memory)
                WHERE m.id = $id
                RETURN m.id, m.title, m.content, m.is_latest,
                       m.unit_type, m.is_crystal, m.importance
                """,
                {"id": memory_id},
            )
            if result.has_next():
                row = result.get_next()
                return {
                    "id": row[0],
                    "title": row[1],
                    "content_preview": (row[2] or "")[:200],
                    "is_latest": row[3],
                    "unit_type": row[4],
                    "is_crystal": row[5],
                    "importance": row[6],
                }
        except Exception:
            pass
        return {"id": memory_id}

    async def get_memory_neighbors(
        self,
        memory_id: str,
        edge_types: Optional[List[str]] = None,
        depth: int = 1,
    ) -> Dict[str, Any]:
        """Get graph neighbors of a memory.

        Queries EVOLVES, MENTIONS, and CRYSTALLIZED_FROM edges.

        Args:
            memory_id: Memory to explore
            edge_types: Filter to specific edge types (default: all)
            depth: Traversal depth 1-3 (default 1)
        """
        if edge_types is None:
            edge_types = ["EVOLVES", "MENTIONS", "CRYSTALLIZED_FROM"]
        depth = min(depth, 3)

        try:
            conn = self._db.conn
            neighbors: Dict[str, List[Dict[str, Any]]] = {}

            if "EVOLVES" in edge_types:
                evolves = []
                # Outgoing (this is older, target is newer)
                try:
                    result = conn.execute(
                        """
                        MATCH (a:Memory)-[e:EVOLVES]->(b:Memory)
                        WHERE a.id = $id
                        RETURN b.id, b.title, e.content_relation,
                               e.confidence, e.reviewed, b.is_latest
                        """,
                        {"id": memory_id},
                    )
                    while result.has_next():
                        row = result.get_next()
                        evolves.append({
                            "direction": "outgoing",
                            "target_id": row[0],
                            "target_title": row[1],
                            "content_relation": row[2],
                            "confidence": row[3],
                            "reviewed": row[4],
                            "target_is_latest": row[5],
                        })
                except Exception:
                    pass

                # Incoming (this is newer, source is older)
                try:
                    result = conn.execute(
                        """
                        MATCH (a:Memory)-[e:EVOLVES]->(b:Memory)
                        WHERE b.id = $id
                        RETURN a.id, a.title, e.content_relation,
                               e.confidence, e.reviewed, a.is_latest
                        """,
                        {"id": memory_id},
                    )
                    while result.has_next():
                        row = result.get_next()
                        evolves.append({
                            "direction": "incoming",
                            "source_id": row[0],
                            "source_title": row[1],
                            "content_relation": row[2],
                            "confidence": row[3],
                            "reviewed": row[4],
                            "source_is_latest": row[5],
                        })
                except Exception:
                    pass
                neighbors["EVOLVES"] = evolves

            if "MENTIONS" in edge_types:
                mentions = []
                try:
                    result = conn.execute(
                        """
                        MATCH (m:Memory)-[r:MENTIONS]->(e:Entity)
                        WHERE m.id = $id
                        RETURN e.id, e.name, e.entity_type, r.confidence
                        """,
                        {"id": memory_id},
                    )
                    while result.has_next():
                        row = result.get_next()
                        mentions.append({
                            "entity_id": row[0],
                            "entity_name": row[1],
                            "entity_type": row[2],
                            "confidence": row[3],
                        })
                except Exception:
                    pass
                neighbors["MENTIONS"] = mentions

            if "CRYSTALLIZED_FROM" in edge_types:
                crystal_links = []
                # This memory is a crystal → find sources
                try:
                    result = conn.execute(
                        """
                        MATCH (c:Memory)-[r:CRYSTALLIZED_FROM]->(s:Memory)
                        WHERE c.id = $id
                        RETURN s.id, s.title, r.contribution_weight
                        """,
                        {"id": memory_id},
                    )
                    while result.has_next():
                        row = result.get_next()
                        crystal_links.append({
                            "direction": "crystal_to_source",
                            "source_id": row[0],
                            "source_title": row[1],
                            "weight": row[2],
                        })
                except Exception:
                    pass

                # This memory is a source → find crystals
                try:
                    result = conn.execute(
                        """
                        MATCH (c:Memory)-[r:CRYSTALLIZED_FROM]->(s:Memory)
                        WHERE s.id = $id
                        RETURN c.id, c.crystal_title, r.contribution_weight
                        """,
                        {"id": memory_id},
                    )
                    while result.has_next():
                        row = result.get_next()
                        crystal_links.append({
                            "direction": "source_to_crystal",
                            "crystal_id": row[0],
                            "crystal_title": row[1],
                            "weight": row[2],
                        })
                except Exception:
                    pass
                neighbors["CRYSTALLIZED_FROM"] = crystal_links

            total = sum(len(v) for v in neighbors.values())

            # Include center memory's title so the UI can label it
            center = self._get_memory_summary(conn, memory_id)

            return {
                "memory_id": memory_id,
                "memory_title": center.get("title") or "",
                "memory_content_preview": center.get("content_preview") or "",
                "total_neighbors": total,
                "neighbors": neighbors,
            }

        except Exception as e:
            logger.error("get_memory_neighbors failed", error=str(e))
            return {"memory_id": memory_id, "error": str(e)}

    async def list_crystals(
        self,
        limit: int = 20,
        offset: int = 0,
    ) -> Dict[str, Any]:
        """List all crystallized knowledge units.

        Returns crystals with their source unit information.
        """
        try:
            conn = self._db.conn
            result = conn.execute(
                """
                MATCH (c:Memory)
                WHERE c.is_crystal = true
                RETURN c.id, c.crystal_title, c.content, c.unit_type,
                       c.importance, c.source_unit_count, c.created_at
                ORDER BY c.created_at DESC
                SKIP $offset LIMIT $limit
                """,
                {"offset": offset, "limit": limit},
            )

            crystals: List[Dict[str, Any]] = []
            while result.has_next():
                row = result.get_next()
                crystal_id = row[0]

                # Get source memories for this crystal
                sources = []
                try:
                    src_result = conn.execute(
                        """
                        MATCH (c:Memory)-[r:CRYSTALLIZED_FROM]->(s:Memory)
                        WHERE c.id = $id
                        RETURN s.id, s.title, r.contribution_weight
                        """,
                        {"id": crystal_id},
                    )
                    while src_result.has_next():
                        src_row = src_result.get_next()
                        sources.append({
                            "id": src_row[0],
                            "title": src_row[1],
                            "weight": src_row[2],
                        })
                except Exception:
                    pass

                crystals.append({
                    "id": crystal_id,
                    "title": row[1],
                    "content_preview": (row[2] or "")[:300],
                    "unit_type": row[3],
                    "importance": row[4],
                    "source_count": row[5] or len(sources),
                    "created_at": str(row[6]) if row[6] else None,
                    "sources": sources,
                })

            # Get total count
            count_result = conn.execute(
                "MATCH (c:Memory) WHERE c.is_crystal = true RETURN count(c)"
            )
            total = count_result.get_next()[0] if count_result.has_next() else 0

            return {
                "total": total,
                "offset": offset,
                "limit": limit,
                "crystals": crystals,
            }

        except Exception as e:
            logger.error("list_crystals failed", error=str(e))
            return {"total": 0, "crystals": [], "error": str(e)}

    async def get_graph_stats(self) -> Dict[str, Any]:
        """Get graph statistics: counts of memories, edges, crystals, etc."""
        try:
            conn = self._db.conn
            stats: Dict[str, Any] = {}

            queries = {
                "memory_count": "MATCH (m:Memory) RETURN count(m)",
                "entity_count": "MATCH (e:Entity) RETURN count(e)",
                "evolves_count": "MATCH ()-[e:EVOLVES]->() RETURN count(e)",
                "crystal_count": "MATCH (m:Memory) WHERE m.is_crystal = true RETURN count(m)",
                "mentions_count": "MATCH ()-[r:MENTIONS]->() RETURN count(r)",
                "crystallized_from_count": "MATCH ()-[r:CRYSTALLIZED_FROM]->() RETURN count(r)",
            }

            for key, query in queries.items():
                try:
                    result = conn.execute(query)
                    stats[key] = result.get_next()[0] if result.has_next() else 0
                except Exception:
                    stats[key] = 0

            # Unit type distribution
            try:
                result = conn.execute(
                    """
                    MATCH (m:Memory)
                    RETURN m.unit_type, count(m)
                    ORDER BY count(m) DESC
                    """
                )
                unit_types: Dict[str, int] = {}
                while result.has_next():
                    row = result.get_next()
                    unit_types[row[0] or "fact"] = row[1]
                stats["unit_type_distribution"] = unit_types
            except Exception:
                stats["unit_type_distribution"] = {}

            return stats

        except Exception as e:
            logger.error("get_graph_stats failed", error=str(e))
            return {"error": str(e)}
