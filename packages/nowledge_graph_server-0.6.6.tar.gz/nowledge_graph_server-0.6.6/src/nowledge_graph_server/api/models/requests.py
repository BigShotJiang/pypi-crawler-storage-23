from pydantic import BaseModel, Field
from typing import Optional, List
import datetime


class SearchRequest(BaseModel):
    """Generic search request."""

    query: str = Field(..., description="Search query")
    limit: int = Field(default=10, ge=1, le=100)


class DistillationRequest(BaseModel):
    """Request for memory distillation from thread content."""

    thread_id: str = Field(..., description="Source thread ID")
    thread_title: Optional[str] = Field(
        default=None, description="Thread title for context"
    )
    thread_content: str = Field(..., description="Full thread content to distill")
    distillation_type: str = Field(
        default="simple_llm", description="Type: 'simple_llm' or 'knowledge_graph'"
    )

    extraction_level: str = Field(
        default="swift",
        description="Extraction level: 'swift' (fast) or 'guided' (multi-step)",
    )

    cache_key: Optional[str] = Field(
        default=None, description="Cache key from preview to reuse results"
    )

    # Optional subset selection (indices into thread messages)
    selected_message_indices: Optional[List[int]] = Field(
        default=None,
        description="Optional list of message indices to process; if omitted, process full thread",
    )

    preferred_language: Optional[str] = Field(
        default=None,
        description="User preferred output language (ISO 639-1 code, e.g. 'en', 'zh', 'ja'), or None to follow input language",
    )

    class Config:
        """Pydantic configuration."""

        json_encoders = {datetime.datetime: lambda v: v.isoformat()}


class TriageRequest(BaseModel):
    """Request for lightweight triage of conversation content.

    A cheap LLM call to determine whether a conversation contains
    knowledge worth distilling into structured memories.
    """

    thread_content: str = Field(
        ..., description="Conversation content to triage", max_length=50000
    )
    preferred_language: Optional[str] = Field(
        default=None,
        description="User preferred language (ISO 639-1 code), or None to auto-detect",
    )


class ThreadParseRequest(BaseModel):
    """Request for parsing thread content."""

    file_content: str = Field(..., description="Content of the conversation file")
    file_name: str = Field(..., description="Name of the file being parsed")


class MemoryKGExtractionRequest(BaseModel):
    """Request for knowledge graph extraction from a memory.

    Note: memory_id is provided in the URL path, not in the request body.
    """

    force_reextraction: bool = Field(
        default=False,
        description="Force re-extraction even if KG was already extracted",
    )
    extraction_level: str = Field(
        default="swift",
        description="Extraction level: 'swift' (fast) or 'guided' (multi-step)",
    )
    use_remote_llm: bool = Field(
        default=False,
        description="Use remote LLM (via LiteLLM) for higher quality temporal-aware extraction",
    )
    preferred_language: Optional[str] = Field(
        default=None,
        description="User preferred output language for descriptions (ISO 639-1 code), or None to follow source language",
    )


class MemoryKGApplyRequest(BaseModel):
    """Request to apply KG extraction results to a memory.
    
    Note: memory_id is provided in the URL path, not in the request body.
    """

    entities: list = Field(..., description="Extracted entities to save")
    relationships: list = Field(..., description="Extracted relationships to save")
    extraction_confidence: float = Field(
        ..., description="Confidence of the extraction"
    )
