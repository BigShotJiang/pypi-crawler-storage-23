from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List
import datetime


class HealthResponse(BaseModel):
    """Health check response."""

    status: str
    version: str
    timestamp: datetime.datetime
    database_connected: bool
    services_ready: bool


class APIError(BaseModel):
    """Standard API error response."""

    error: str
    detail: Optional[str] = None
    timestamp: str = Field(
        default_factory=lambda: datetime.datetime.now(datetime.UTC).isoformat()
    )

    class Config:
        """Pydantic configuration."""

        json_encoders = {datetime.datetime: lambda v: v.isoformat()}


class ThreadParseResponse(BaseModel):
    """Response from thread parsing."""

    success: bool = Field(..., description="Whether parsing was successful")
    parsed_thread: Optional[Dict[str, Any]] = Field(
        default=None, description="Parsed thread data"
    )
    format_detected: Optional[str] = Field(default=None, description="Detected format")
    error: Optional[str] = Field(default=None, description="Error message if parsing failed")


# Graph visualization models
class GraphNode(BaseModel):
    """Graph node for visualization."""

    id: str
    label: str
    node_type: str
    size: float
    community: Optional[str] = None
    importance: Optional[float] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class GraphEdge(BaseModel):
    """Graph edge for visualization."""

    id: str
    source: str
    target: str
    edge_type: str
    weight: float
    label: Optional[str] = None


class DistillationPreviewResponse(BaseModel):
    """Response for distillation preview."""

    success: bool
    cache_key: str = Field(..., description="Cache key to reuse these results")
    distillation_type: str
    processing_time: float
    memories: List[Dict[str, Any]]
    entities: List[Dict[str, Any]]
    relationships: List[Dict[str, Any]]
    insights: List[Dict[str, Any]]
    summary: str
    error: Optional[str] = None


class Community(BaseModel):
    """Community/cluster for visualization."""

    id: str
    name: str
    description: Optional[str] = None
    member_count: int
    strength: float


class GraphDataResponse(BaseModel):
    """Graph data response for visualization."""

    nodes: List[GraphNode]
    edges: List[GraphEdge]
    communities: List[Community]


class MemoryKGExtractionResponse(BaseModel):
    """Response from memory KG extraction preview."""

    memory_id: str = Field(..., description="ID of the memory")
    memory_title: str = Field(..., description="Title of the memory")
    memory_content: str = Field(..., description="Content of the memory")
    entities: List[Dict[str, Any]] = Field(..., description="Extracted entities")
    relationships: List[Dict[str, Any]] = Field(
        ..., description="Extracted relationships"
    )
    extraction_confidence: float = Field(
        ..., description="Confidence of the extraction"
    )
    entities_count: int = Field(..., description="Number of extracted entities")
    relationships_count: int = Field(
        ..., description="Number of extracted relationships"
    )
    kg_already_extracted: bool = Field(
        ..., description="Whether KG was already extracted"
    )
    can_extract: bool = Field(..., description="Whether extraction is possible")


class MemoryKGApplyResponse(BaseModel):
    """Response from applying KG extraction to memory."""

    success: bool = Field(..., description="Whether application was successful")
    memory_id: str = Field(..., description="ID of the updated memory")
    entities_created: int = Field(
        ..., description="Number of entities created in graph"
    )
    relationships_created: int = Field(
        ..., description="Number of relationships created in graph"
    )
    metadata_updated: bool = Field(
        ..., description="Whether memory metadata was updated"
    )
    error: Optional[str] = Field(
        default=None, description="Error message if application failed"
    )
