import asyncio
from typing import Optional, Dict, Any
from datetime import datetime, timezone

from nowledge_graph_server.database.kuzu_client import KuzuClient
from nowledge_graph_server.services.embedding import EmbeddingService
from nowledge_graph_server.services.entity_extraction import EntityExtractionService
from nowledge_graph_server.services.local_llm import (
    LocalLLMService,
)

# Import core operations
from nowledge_graph_server.core.memory_operations import MemoryOperations
from nowledge_graph_server.core.thread_operations import ThreadOperations
from nowledge_graph_server.core.search_operations import SearchOperations
from nowledge_graph_server.core.entity_operations import EntityOperations
from nowledge_graph_server.core.graph_operations import GraphOperations

from nowledge_graph_server.config import get_settings
from fastapi import HTTPException, Request

import structlog

# Configure structured logging
logger = structlog.get_logger(__name__)

# Global instances - simplified for local LLM approach
kuzu_client: Optional[KuzuClient] = None
embedding_service: Optional[EmbeddingService] = None
entity_extraction_service: Optional[EntityExtractionService] = None
local_llm_service: Optional[LocalLLMService] = None

# Core operations instances
memory_operations: Optional[MemoryOperations] = None
thread_operations: Optional[ThreadOperations] = None
search_operations: Optional[SearchOperations] = None
entity_operations: Optional[EntityOperations] = None
graph_operations: Optional[GraphOperations] = None

# Background idle model cleanup task
_idle_cleanup_task: Optional[asyncio.Task] = None

# ------------------------------------------------------------------
# Maintenance mode (data import/export)
# ------------------------------------------------------------------

_maintenance_lock = asyncio.Lock()
_maintenance_state: Dict[str, Any] = {
    "active": False,
    "reason": None,
    "started_at": None,
    "snapshot": None,
}

_MAINTENANCE_ALLOWED_PREFIXES = (
    "/data/import",
    "/data/import/status",
    "/data/export",
    "/data/checkpoint",
    "/health",
    "/health/checkpoint",
)

# LLM is used infrequently (distillation, extraction) — unload after 5 minutes idle.
_LLM_IDLE_UNLOAD_THRESHOLD = 300
# Embedding model is used on every search query and reload is expensive —
# unload only after 2 days idle (essentially "only if truly abandoned").
_EMBEDDING_IDLE_UNLOAD_THRESHOLD = 172800  # 48 hours
# Check interval in seconds (60 seconds)
_IDLE_CHECK_INTERVAL = 60

# Lifecycle management


async def startup():
    """Initialize services on startup."""
    global kuzu_client, embedding_service, entity_extraction_service, local_llm_service

    try:
        settings = get_settings()

        # STEP 1: Run database migrations FIRST (create, use, then close Database)
        logger.debug("Running database migrations BEFORE main app initialization")
        try:
            from ..migrations.migration_manager import MigrationManager

            migration_manager = MigrationManager(settings.database_path)
            await migration_manager.initialize()
            migration_result = await migration_manager.apply_migrations()
            # 🎯 CRITICAL: Close the migration Database object before proceeding
            await migration_manager.close()
            logger.debug(
                "Database migrations completed and migration Database closed",
                applied_count=migration_result.get("applied_count", 0),
                migrations=migration_result.get("migrations", []),
            )
        except Exception as migration_error:
            logger.warning(
                "Migration failed, continuing with startup", error=str(migration_error)
            )
            # Don't fail startup on migration errors - continue with degraded functionality

        # STEP 2: NOW initialize main KuzuDB client (only one Database object exists)
        logger.debug("Initializing main DB client after migrations completed")
        kuzu_client = KuzuClient(
            settings.database_path, embedding_dimension=settings.embedding_dimension
        )
        await kuzu_client.initialize()

        # Skip embedding service initialization during startup - will initialize on-demand
        embedding_service = None
        logger.info("Embedding service will be initialized on-demand when first needed")

        # Initialize local LLM service (optional - don't block startup)
        if settings.llm_required_for_startup:
            logger.info("LLM required for startup - initializing LLM service")
            try:
                # Set ModelScope preference environment before any MLX imports
                # This ensures MLX-LM can use ModelScope if needed
                import os

                if not os.environ.get("MLXLM_USE_MODELSCOPE"):
                    # Default to ModelScope in China regions for better download speeds
                    from ..utils.model_cache import HuggingFaceMirrorManager

                    region = HuggingFaceMirrorManager.detect_region()
                    if region == "china":
                        os.environ["MLXLM_USE_MODELSCOPE"] = "true"
                        logger.info(
                            "Auto-detected China region, setting MLXLM_USE_MODELSCOPE=true"
                        )
                    else:
                        os.environ["MLXLM_USE_MODELSCOPE"] = "false"

                local_llm_service = LocalLLMService(
                    model_name="mlx-community/Qwen3-4B-Instruct-2507-DDWQ",
                    cache_dir=settings.llm_cache_dir,
                    cache_only=settings.llm_cache_only,
                )
                await local_llm_service.initialize()
                logger.info("LLM service initialized successfully at startup")
            except Exception as llm_error:
                logger.error(
                    "LLM initialization failed at startup", error=str(llm_error)
                )
                if settings.llm_required_for_startup:
                    raise HTTPException(
                        status_code=500,
                        detail=f"LLM service initialization failed: {str(llm_error)}",
                    )
        else:
            # logger.info("LLM not required for startup - will initialize on demand")
            local_llm_service = None

        # Initialize core operations with simplified dependencies
        global \
            memory_operations, \
            thread_operations, \
            search_operations, \
            entity_operations, \
            graph_operations

        memory_operations = MemoryOperations(
            db=kuzu_client,
            embedding_service=embedding_service,
            entity_service=None,  # Remove unused pattern-based fallback
        )
        search_operations = SearchOperations(
            db=kuzu_client,
            embedding_service=embedding_service,
        )
        entity_operations = EntityOperations(
            db=kuzu_client,
        )
        graph_operations = GraphOperations(kuzu_client=kuzu_client)
        thread_operations = ThreadOperations(
            db=kuzu_client,
            embedding_service=embedding_service,
            graph_ops=graph_operations,
        )
        logger.debug(
            "API server initialized successfully",
            entity_extraction_method=settings.entity_extraction_method,
            multilingual_enabled=settings.entity_multilingual_enabled,
            entity_linking_enabled=settings.entity_linking_enabled,
        )

        # STEP 4: Check search index availability (non-blocking)
        await _check_search_index_health()

        # STEP 5: Start Knowledge Agent (non-blocking, graceful degradation)
        await _start_knowledge_agent()

        # STEP 5.5: Start background idle model cleanup (reclaim Metal memory)
        _start_idle_cleanup()

        # STEP 6: Restore remote tunnel if user left it running previously.
        try:
            from nowledge_graph_server.services.remote_access import (
                get_remote_access_manager,
            )

            get_remote_access_manager().schedule_auto_start()
        except Exception as remote_error:
            logger.warning(
                "Failed to schedule remote tunnel auto-start",
                error=str(remote_error),
            )

    except Exception as e:
        logger.error("Failed to initialize API server", error=str(e))
        raise


async def _check_search_index_health() -> None:
    """Check search index health at startup (non-blocking).

    This logs the status of the search embedding model and search index
    but does not block startup if they're unavailable.

    The model is platform-specific:
    - macOS Apple Silicon: Qwen3-Embedding via mlx-embeddings
    - non-Apple-Silicon (Windows/Linux/macOS Intel): BGE-M3 via FastEmbed/ONNX
    """
    try:
        from ..services.search_embedding import check_search_model_exists, get_search_model_info
        from ..services.search_index import is_search_index_available, get_search_index_service

        model_info = get_search_model_info()
        model_exists = check_search_model_exists()

        if model_exists:
            logger.info(
                "Search embedding model available for hybrid search",
                model=model_info["model_name"],
                backend=model_info["backend"],
                platform=model_info["platform"],
            )

            # Try to initialize the search index service
            try:
                search_service = await get_search_index_service()
                if search_service:
                    logger.info(
                        "Search index service initialized successfully",
                        tables=["memories_index", "messages_index", "communities_index", "entities_index"],
                    )
                else:
                    logger.info(
                        "Search index service not initialized - will initialize on first use"
                    )
            except Exception as index_error:
                logger.warning(
                    "Search index initialization deferred",
                    error=str(index_error),
                )
        else:
            logger.info(
                "Search embedding model not installed - hybrid search disabled",
                model=model_info["model_name"],
                hint="Download from Settings > Search Index to enable hybrid search",
            )

    except Exception as e:
        logger.warning(
            "Search index health check failed",
            error=str(e),
        )


async def get_embedding_service() -> Optional[EmbeddingService]:
    """Get or initialize embedding service on-demand.

    Returns:
        EmbeddingService if available/initialized, None if unavailable
    """
    global embedding_service

    # Return existing service if already initialized and working
    if embedding_service is not None and embedding_service._initialized:  # type: ignore[attr-defined]
        return embedding_service

    # Try to initialize if not yet done
    try:
        settings = get_settings()
        logger.debug("Initializing embedding service on-demand")

        # Use AUTO mode for runtime - let the service try both cache structures
        from ..services.embedding import DownloadSource

        # Create service instance but don't assign to global variable yet
        temp_service = EmbeddingService(
            model_name=settings.embedding_model,
            device=settings.embedding_device,
            dimension=settings.embedding_dimension,
            cache_dir=settings.embedding_cache_dir,
            force_download=False,  # Never auto-download in on-demand init
            cache_only=True,  # Only use cached models
            download_source=DownloadSource.AUTO,  # type: ignore[arg-type]
        )

        # Only assign to global variable AFTER successful initialization
        await temp_service.initialize()
        embedding_service = temp_service  # Now it's safe to assign
        logger.debug("Embedding service initialized successfully on-demand")
        return embedding_service

    except Exception as e:
        logger.debug("Embedding service not available", error=str(e))
        # Ensure global variable remains None on failure
        embedding_service = None
        return None


async def shutdown():
    """Cleanup on shutdown.

    CRITICAL: This method ensures proper database shutdown with WAL flushing.
    The kuzu_client.close() method will checkpoint before closing to prevent
    WAL corruption that can occur with unflushed data.
    """
    global kuzu_client, embedding_service, entity_extraction_service, local_llm_service

    logger.info("API server shutdown initiated - flushing database and cleaning up")

    try:
        # Stop background idle cleanup first
        await _stop_idle_cleanup()

        # Stop remote quick tunnel first to avoid leaking a stale public endpoint.
        try:
            from nowledge_graph_server.services.remote_access import (
                get_remote_access_manager,
            )

            await get_remote_access_manager().shutdown()
        except Exception as remote_error:
            logger.warning("Remote access shutdown error", error=str(remote_error))

        # Stop Knowledge Agent first (before DB close)
        await _stop_knowledge_agent()

        # Cleanup non-database services first
        if local_llm_service:
            logger.debug("Closing LLM service")
            await local_llm_service.close()
        if entity_extraction_service:
            # await entity_extraction_service.cleanup()
            pass
        if embedding_service:
            logger.debug("Closing embedding service")
            await embedding_service.cleanup()
        
        # Close database last - this performs the critical WAL checkpoint
        if kuzu_client:
            logger.info("Closing database with final checkpoint")
            # Log checkpoint status before closing
            try:
                checkpoint_status = kuzu_client.base_client.get_checkpoint_status()
                logger.info(
                    "Database checkpoint status before shutdown",
                    last_checkpoint=checkpoint_status.get("last_checkpoint_time"),
                    failure_count=checkpoint_status.get("failure_count"),
                    last_failure=checkpoint_status.get("last_failure"),
                )
            except Exception:
                pass
            
            await kuzu_client.close()
            logger.info("Database closed successfully with WAL flushed")

        logger.info("API server shutdown completed successfully")

    except Exception as e:
        logger.error("Error during shutdown", error=str(e))
        # Re-raise to ensure the error is visible
        raise


def is_maintenance_active() -> bool:
    return bool(_maintenance_state.get("active"))


def get_maintenance_status() -> Dict[str, Any]:
    return {
        "active": bool(_maintenance_state.get("active")),
        "reason": _maintenance_state.get("reason"),
        "started_at": _maintenance_state.get("started_at"),
    }


async def enter_data_transfer_maintenance(reason: str) -> Dict[str, Any]:
    """Pause background activity to keep data transfer exclusive."""
    async with _maintenance_lock:
        if _maintenance_state["active"]:
            raise HTTPException(
                status_code=409, detail="Maintenance already in progress"
            )

        snapshot: Dict[str, Any] = {
            "reason": reason,
            "started_at": datetime.now(timezone.utc).isoformat(),
            "watcher_running": False,
            "agent_running": False,
            "idle_cleanup_running": False,
        }

        # Stop session watcher if running
        try:
            from nowledge_graph_server.services.session_watcher import (
                get_session_watcher_service,
            )

            watcher = get_session_watcher_service()
            if watcher.is_running():
                snapshot["watcher_running"] = True
                watcher.stop()
        except Exception:
            pass

        # Stop Knowledge Agent if running
        try:
            from nowledge_graph_server.agent.manager import get_agent_manager

            manager = get_agent_manager()
            if manager is not None and manager.is_running:
                snapshot["agent_running"] = True
                await manager.stop()
        except Exception:
            pass

        # Stop idle cleanup task
        if _idle_cleanup_task is not None and not _idle_cleanup_task.done():
            snapshot["idle_cleanup_running"] = True
            await _stop_idle_cleanup()

        _maintenance_state.update(
            {
                "active": True,
                "reason": reason,
                "started_at": snapshot["started_at"],
                "snapshot": snapshot,
            }
        )
        logger.info("Entered maintenance mode", reason=reason)
        return snapshot


async def exit_data_transfer_maintenance(snapshot: Optional[Dict[str, Any]] = None) -> None:
    """Resume background activity after data transfer."""
    async with _maintenance_lock:
        if not _maintenance_state.get("active"):
            return

        snapshot = snapshot or _maintenance_state.get("snapshot") or {}

        # Restart idle cleanup if it was running
        if snapshot.get("idle_cleanup_running"):
            _start_idle_cleanup()

        # Restart Knowledge Agent if it was running
        if snapshot.get("agent_running"):
            await _start_knowledge_agent()

        # Restart session watcher if it was running
        if snapshot.get("watcher_running"):
            try:
                from nowledge_graph_server.services.session_watcher import (
                    get_session_watcher_service,
                )

                watcher = get_session_watcher_service()
                if not watcher.is_running():
                    watcher.start()
            except Exception:
                pass

        _maintenance_state.update(
            {"active": False, "reason": None, "started_at": None, "snapshot": None}
        )
        logger.info("Exited maintenance mode")


async def get_kuzu_client(request: Request = None) -> KuzuClient:
    """Dependency to get client."""
    if is_maintenance_active():
        path = request.url.path if request is not None else ""
        allowed = any(path.startswith(prefix) for prefix in _MAINTENANCE_ALLOWED_PREFIXES)
        if not allowed:
            raise HTTPException(
                status_code=503,
                detail="Data transfer in progress. Try again when it completes.",
            )
    if kuzu_client is None:
        raise HTTPException(status_code=503, detail="Database not initialized")
    return kuzu_client


def get_kuzu_client_direct() -> Optional[KuzuClient]:
    """Return the current client without maintenance gating (internal checks only)."""
    return kuzu_client


async def get_entity_extraction_service() -> EntityExtractionService:
    """Dependency to get entity extraction service."""
    if entity_extraction_service is None:
        raise HTTPException(
            status_code=503, detail="Entity extraction service not initialized"
        )
    return entity_extraction_service


# Dependencies for core operations


async def get_memory_operations() -> MemoryOperations:
    """Dependency to get memory operations."""
    global memory_operations
    if memory_operations is None:
        raise HTTPException(status_code=503, detail="Memory operations not initialized")
    return memory_operations


async def get_thread_operations() -> ThreadOperations:
    """Dependency to get thread operations."""
    global thread_operations
    if thread_operations is None:
        raise HTTPException(status_code=503, detail="Thread operations not initialized")
    return thread_operations


async def get_search_operations() -> SearchOperations:
    """Dependency to get search operations."""
    if search_operations is None:
        raise HTTPException(status_code=503, detail="Search operations not initialized")
    return search_operations


async def get_entity_operations() -> EntityOperations:
    """Dependency to get entity operations."""
    if entity_operations is None:
        raise HTTPException(status_code=503, detail="Entity operations not initialized")
    return entity_operations


async def get_graph_operations() -> GraphOperations:
    """Dependency to get graph operations."""
    if graph_operations is None:
        raise HTTPException(status_code=503, detail="Graph operations not initialized")
    return graph_operations


async def get_local_llm_service_dep() -> LocalLLMService:
    """Dependency to get local LLM service (initialize on demand if needed).
    
    On non-Apple-Silicon platforms, allows initialization with local_llm=None if remote LLM is configured.
    Validation happens at call time in the service methods.
    """
    global local_llm_service

    if local_llm_service is None:
        logger.info("LLM service not initialized - initializing on demand")
        try:
            settings = get_settings()

            # Set ModelScope preference environment if not already set (only for macOS)
            import os
            import platform

            IS_APPLE_SILICON = platform.system() == "Darwin" and platform.machine() == "arm64"
            
            if IS_APPLE_SILICON and not os.environ.get("MLXLM_USE_MODELSCOPE"):
                from ..utils.model_cache import HuggingFaceMirrorManager

                region = HuggingFaceMirrorManager.detect_region()
                if region == "china":
                    os.environ["MLXLM_USE_MODELSCOPE"] = "true"
                    logger.info(
                        "Auto-detected China region for on-demand LLM, setting MLXLM_USE_MODELSCOPE=true"
                    )
                else:
                    os.environ["MLXLM_USE_MODELSCOPE"] = "false"

            local_llm_service = LocalLLMService(
                model_name="mlx-community/Qwen3-4B-Instruct-2507-DDWQ",
                cache_dir=settings.llm_cache_dir,
                cache_only=settings.llm_cache_only,
            )
            await local_llm_service.initialize()
            logger.info(
                "LLM service initialized successfully on demand",
                local_available=(local_llm_service.local_llm is not None),
                remote_initialized=local_llm_service._remote_initialized,
            )
        except Exception as e:
            logger.error("Failed to initialize LLM service on demand", error=str(e))
            # On non-Apple-Silicon platforms, allow service to exist with local_llm=None
            # Validation will happen at call time
            import platform
            IS_APPLE_SILICON = platform.system() == "Darwin" and platform.machine() == "arm64"
            if not IS_APPLE_SILICON:
                # Try to create service anyway - it will have local_llm=None
                try:
                    local_llm_service = LocalLLMService(
                        model_name="mlx-community/Qwen3-4B-Instruct-2507-DDWQ",
                        cache_dir=settings.llm_cache_dir,
                        cache_only=settings.llm_cache_only,
                    )
                    await local_llm_service.initialize()
                    logger.info("LLM service initialized with local_llm=None (non-Apple-Silicon)")
                except Exception as e2:
                    logger.error("Failed to initialize LLM service even with local_llm=None", error=str(e2))
                    raise HTTPException(
                        status_code=503,
                        detail=f"LLM service initialization failed: {str(e2)}. On Intel Mac/Windows/Linux, please configure Remote LLM in Settings > Remote LLM.",
                    )
            else:
                # On macOS, initialization failure is more serious
                raise HTTPException(
                    status_code=503,
                    detail=f"Local LLM service initialization failed: {str(e)}. Please ensure the model is downloaded or configure Remote LLM.",
                )

    return local_llm_service


# ------------------------------------------------------------------
# Background idle model cleanup
# ------------------------------------------------------------------


async def _idle_model_cleanup_loop() -> None:
    """Background task that periodically checks for idle models and unloads them.

    This reclaims Metal/host memory when models haven't been used for a while.
    Models reload seamlessly on next use via their existing initialize() patterns.

    Thresholds differ by component:
    - LLM (5 min): used infrequently for distillation/extraction, large (~2-3GB)
    - Embedding (2 days): used on every search query, reload is expensive
    """
    while True:
        try:
            await asyncio.sleep(_IDLE_CHECK_INTERVAL)

            # Check local LLM (MLX Qwen3-4B ~2-3GB)
            if local_llm_service is not None and local_llm_service.is_local_llm_idle(_LLM_IDLE_UNLOAD_THRESHOLD):
                await local_llm_service.unload_local_llm()

            # Check search embedding service (MLX Qwen3-Embedding ~400MB or FastEmbed ~1.4GB)
            # NOTE: Import the module (not the variable) to get a live reference —
            # `from module import var` captures a snapshot that goes stale on reassignment.
            try:
                from ..services.search_index import service_factory
                svc = service_factory._search_embedding_service
                if svc is not None and svc.is_idle(_EMBEDDING_IDLE_UNLOAD_THRESHOLD):
                    await svc.unload()
            except Exception as e:
                logger.debug("Search embedding idle check failed", error=str(e))

        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.debug("Idle cleanup iteration error", error=str(e))


def _start_idle_cleanup() -> None:
    """Start the background idle model cleanup task."""
    global _idle_cleanup_task
    if _idle_cleanup_task is None or _idle_cleanup_task.done():
        _idle_cleanup_task = asyncio.create_task(_idle_model_cleanup_loop())
        logger.info(
            "Started background idle model cleanup",
            check_interval_s=_IDLE_CHECK_INTERVAL,
            llm_idle_threshold_s=_LLM_IDLE_UNLOAD_THRESHOLD,
            embedding_idle_threshold_s=_EMBEDDING_IDLE_UNLOAD_THRESHOLD,
        )


async def _stop_idle_cleanup() -> None:
    """Stop the background idle model cleanup task."""
    global _idle_cleanup_task
    if _idle_cleanup_task is not None and not _idle_cleanup_task.done():
        _idle_cleanup_task.cancel()
        try:
            await _idle_cleanup_task
        except asyncio.CancelledError:
            pass
        except Exception:
            pass
        _idle_cleanup_task = None
        logger.debug("Stopped background idle model cleanup")


# ------------------------------------------------------------------
# Knowledge Agent lifecycle helpers
# ------------------------------------------------------------------


async def _start_knowledge_agent() -> None:
    """Start the Knowledge Agent (non-blocking, graceful degradation)."""
    try:
        from nowledge_graph_server.agent.manager import (
            KnowledgeAgentManager,
            set_agent_manager,
        )

        manager = KnowledgeAgentManager.get_instance()
        set_agent_manager(manager)

        await manager.start(
            kuzu_client=kuzu_client,
            search_ops=search_operations,
            memory_ops=memory_operations,
        )
    except Exception as e:
        logger.warning(
            "Knowledge Agent failed to start (non-fatal)",
            error=str(e),
        )


async def _stop_knowledge_agent() -> None:
    """Stop the Knowledge Agent."""
    try:
        from nowledge_graph_server.agent.manager import get_agent_manager

        manager = get_agent_manager()
        if manager is not None:
            await manager.stop()
    except Exception as e:
        logger.warning("Knowledge Agent stop error", error=str(e))
