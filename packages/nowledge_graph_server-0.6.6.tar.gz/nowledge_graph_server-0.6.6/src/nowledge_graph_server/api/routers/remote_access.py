"""Remote access API + authenticated gateway proxy."""

from __future__ import annotations

from typing import Any, Literal

import httpx
import structlog
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from nowledge_graph_server.services.remote_access import (
    HOP_BY_HOP_HEADERS,
    get_remote_access_manager,
    is_local_request,
    is_remote_target_path_allowed,
)

logger = structlog.get_logger(__name__)

management_router = APIRouter(prefix="/api/remote-access", tags=["remote-access"])
gateway_router = APIRouter(prefix="/remote-api", tags=["remote-api"])


class StartTunnelRequest(BaseModel):
    rotate_api_key: bool = False
    mode: Literal["quick", "account"] | None = None


class ConfigureTunnelRequest(BaseModel):
    mode: Literal["quick", "account"] | None = None
    account_tunnel_url: str | None = None
    account_tunnel_token: str | None = None


def _assert_local_management_request(request: Request) -> None:
    if not is_local_request(request):
        raise HTTPException(
            status_code=403,
            detail=(
                "Remote access management endpoints are local-only. "
                "Use this endpoint from the same device running Mem."
            ),
        )


def _build_forward_headers(
    request: Request, client_ip: str, tunnel_mode: str
) -> dict[str, str]:
    headers: dict[str, str] = {}
    for key, value in request.headers.items():
        lower = key.lower()
        if lower in HOP_BY_HOP_HEADERS:
            continue
        if lower in {
            "host",
            "authorization",
            "x-nmem-api-key",
            "content-length",
            "cookie",
        }:
            continue
        headers[key] = value

    forwarded_for = request.headers.get("x-forwarded-for", "").strip()
    headers["X-Forwarded-For"] = (
        f"{forwarded_for}, {client_ip}" if forwarded_for else client_ip
    )
    headers["X-Nmem-Remote-Gateway"] = (
        "cloudflare-quick-tunnel"
        if tunnel_mode == "quick"
        else "cloudflare-account-tunnel"
    )
    return headers


def _filter_upstream_headers(headers: httpx.Headers) -> dict[str, str]:
    filtered: dict[str, str] = {}
    for key, value in headers.items():
        lower = key.lower()
        if lower in HOP_BY_HOP_HEADERS:
            continue
        if lower == "content-length":
            continue
        filtered[key] = value
    return filtered


async def _proxy_request(target_path: str, request: Request) -> StreamingResponse:
    manager = get_remote_access_manager()
    # Tunnel requests are authenticated in middleware and marked on request.state.
    # For direct/local calls to /remote-api, authenticate here.
    client_ip = getattr(request.state, "remote_client_ip", None)
    if not client_ip:
        client_ip = manager.assert_authenticated(request)
    mode = manager.active_mode or manager.configured_mode

    normalized = target_path.strip("/")
    if not is_remote_target_path_allowed(normalized):
        raise HTTPException(
            status_code=403,
            detail=(
                "Target endpoint is not exposed in remote mode. "
                "Remote mode only exposes memory-center APIs."
            ),
        )

    target_url = f"http://127.0.0.1:14242/{normalized}"
    method = request.method.upper()
    content = await request.body()
    forward_headers = _build_forward_headers(request, client_ip, mode)
    forward_params = [
        (key, value)
        for key, value in request.query_params.multi_items()
        if key.lower() != "nmem_api_key"
    ]

    timeout = httpx.Timeout(connect=15.0, read=300.0, write=60.0, pool=60.0)
    client = httpx.AsyncClient(timeout=timeout, follow_redirects=False)

    try:
        upstream_request = client.build_request(
            method=method,
            url=target_url,
            params=dict(forward_params),
            headers=forward_headers,
            content=content,
        )
        upstream = await client.send(upstream_request, stream=True)
    except httpx.RequestError as exc:
        await client.aclose()
        logger.warning(
            "Remote gateway upstream request failed",
            error=str(exc),
            target_url=target_url,
        )
        raise HTTPException(status_code=502, detail="Upstream request failed") from exc

    response_headers = _filter_upstream_headers(upstream.headers)

    async def _stream_body():
        try:
            async for chunk in upstream.aiter_raw():
                yield chunk
        finally:
            await upstream.aclose()
            await client.aclose()

    return StreamingResponse(
        _stream_body(),
        status_code=upstream.status_code,
        headers=response_headers,
    )


@management_router.get("/status", include_in_schema=False)
async def get_remote_access_status(request: Request) -> dict[str, Any]:
    """Get tunnel + remote auth status."""
    _assert_local_management_request(request)
    manager = get_remote_access_manager()
    return manager.get_status()


@management_router.post("/start", include_in_schema=False)
async def start_remote_access(payload: StartTunnelRequest, request: Request) -> dict[str, Any]:
    """Start Cloudflare tunnel and return URL + one-time key when needed."""
    _assert_local_management_request(request)
    manager = get_remote_access_manager()
    try:
        return await manager.start_tunnel(
            rotate_api_key=payload.rotate_api_key,
            mode=payload.mode,
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@management_router.post("/configure", include_in_schema=False)
async def configure_remote_access(
    payload: ConfigureTunnelRequest, request: Request
) -> dict[str, Any]:
    """Configure remote access tunnel mode and account settings."""
    _assert_local_management_request(request)
    manager = get_remote_access_manager()
    try:
        return await manager.configure_tunnel(
            mode=payload.mode,
            account_tunnel_url=payload.account_tunnel_url,
            account_tunnel_token=payload.account_tunnel_token,
        )
    except (RuntimeError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@management_router.post("/stop", include_in_schema=False)
async def stop_remote_access(request: Request) -> dict[str, Any]:
    """Stop Cloudflare tunnel."""
    _assert_local_management_request(request)
    manager = get_remote_access_manager()
    return await manager.stop_tunnel()


@management_router.post("/shutdown", include_in_schema=False)
async def shutdown_remote_access(request: Request) -> dict[str, Any]:
    """Stop Cloudflare tunnel for app shutdown without changing auto-start preference."""
    _assert_local_management_request(request)
    manager = get_remote_access_manager()
    await manager.shutdown()
    return manager.get_status()


@management_router.post("/rotate-key", include_in_schema=False)
async def rotate_remote_access_key(request: Request) -> dict[str, Any]:
    """Rotate remote API key and return the new plaintext key."""
    _assert_local_management_request(request)
    manager = get_remote_access_manager()
    api_key = await manager.rotate_api_key()
    status = manager.get_status()
    status["api_key"] = api_key
    return status


@management_router.post("/reveal-key", include_in_schema=False)
async def reveal_remote_access_key(request: Request) -> dict[str, Any]:
    """Reveal current remote API key for local copy actions."""
    _assert_local_management_request(request)
    manager = get_remote_access_manager()
    try:
        api_key = await manager.reveal_api_key()
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    status = manager.get_status()
    status["api_key"] = api_key
    return status


@gateway_router.api_route(
    "",
    methods=["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"],
    include_in_schema=False,
)
async def proxy_gateway_root(request: Request):
    return await _proxy_request("", request)


@gateway_router.api_route(
    "/{target_path:path}",
    methods=["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"],
    include_in_schema=False,
)
async def proxy_gateway(target_path: str, request: Request):
    return await _proxy_request(target_path, request)
