"""Search endpoints for memories."""

from typing import Optional, List, Dict, Any
from fastapi import APIRouter, HTTPException, Depends, Query
from nowledge_graph_server.api.dependencies import (
    get_kuzu_client,
    get_search_operations,
)
from nowledge_graph_server.core.search_operations import SearchOperations
from nowledge_graph_server.database.kuzu_client import KuzuClient
from nowledge_graph_server.utils.transformers import transform_memory_to_frontend_format
from nowledge_graph_server.models import (
    MemorySearchRequest,
    MemorySearchResult,
)
from nowledge_graph_server.models.memories_api import MemorySearchResponse
from nowledge_graph_server.api.routers.memories_utils import (
    generate_enhanced_search_reasoning,  # type: ignore[attr-defined]
    build_search_intelligence_metadata,  # type: ignore[attr-defined]
)
import structlog

logger = structlog.get_logger(__name__)

router = APIRouter()


# Main UI
@router.get(
    "/memories/search", response_model=MemorySearchResponse, include_in_schema=False
)
async def get_memories_with_search(
    q: Optional[str] = Query(None, description="Search query (empty for browsing)"),
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    importance_min: float = Query(default=0.0, ge=0.0, le=1.0),
    confidence_min: Optional[float] = Query(
        default=None, ge=0.0, le=1.0, description="Minimum confidence score"
    ),
    mode: str = Query(default="fast", description="Search mode: deep | fast"),
    # Bi-temporal filters (NEW)
    event_date_from: Optional[str] = Query(
        default=None,
        description="Filter by event start date (YYYY, YYYY-MM, or YYYY-MM-DD)",
    ),
    event_date_to: Optional[str] = Query(
        default=None,
        description="Filter by event end date (YYYY, YYYY-MM, or YYYY-MM-DD)",
    ),
    recorded_date_from: Optional[str] = Query(
        default=None,
        description="Filter by recording start date (YYYY, YYYY-MM, or YYYY-MM-DD)",
    ),
    recorded_date_to: Optional[str] = Query(
        default=None,
        description="Filter by recording end date (YYYY, YYYY-MM, or YYYY-MM-DD)",
    ),
    # @deprecated Use recorded_date_from/recorded_date_to instead
    time_range: Optional[str] = Query(
        default=None,
        description="Time filter: 'today', 'week', 'month', 'year' (deprecated)",
    ),
    labels: Optional[List[str]] = Query(
        default=None, description="Filter by label names"
    ),
    search_ops: SearchOperations = Depends(get_search_operations),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
):
    """
    Unified memory endpoint with search metadata and filtering.

    Supports both searching and browsing with comprehensive metadata.
    """
    try:
        logger.debug(
            "GET /memories/search: Enhanced unified memory endpoint",
            query=q[:50] if q else "[browse mode]",
            limit=limit,
            offset=offset,
            importance_min=importance_min,
        )

        # Prepare filters
        filters: Dict[str, Any] = {}
        if importance_min > 0:
            filters["importance_min"] = importance_min
        if confidence_min is not None:
            filters["confidence_min"] = confidence_min
        if labels:
            filters["labels"] = labels

        # Bi-temporal filters (NEW)
        if event_date_from:
            filters["event_date_from"] = event_date_from
        if event_date_to:
            filters["event_date_to"] = event_date_to
        if recorded_date_from:
            filters["recorded_date_from"] = recorded_date_from
        if recorded_date_to:
            filters["recorded_date_to"] = recorded_date_to

        # Backward compatibility: convert old time_range to recorded_date_from
        if time_range:
            from datetime import datetime, timedelta

            now = datetime.now()
            if time_range == "today":
                filters["recorded_date_from"] = (now - timedelta(days=1)).strftime(
                    "%Y-%m-%d"
                )
            elif time_range == "week":
                filters["recorded_date_from"] = (now - timedelta(weeks=1)).strftime(
                    "%Y-%m-%d"
                )
            elif time_range == "month":
                filters["recorded_date_from"] = (now - timedelta(days=30)).strftime(
                    "%Y-%m-%d"
                )
            elif time_range == "year":
                filters["recorded_date_from"] = (now - timedelta(days=365)).strftime(
                    "%Y-%m-%d"
                )

        # Use enhanced search engine with rich metadata capture
        results = await search_ops.search_memories(
            query=q or "",
            limit=limit + offset,  # Get more to support offset
            search_mode="comprehensive",
            mode=("fast" if mode == "fast" else "deep"),
            importance_min=importance_min,
            filter_labels=labels,
            metadata_filters=filters,
        )

        # Capture rich search context from the search engine for user explanation
        search_context = None
        if hasattr(search_ops, "search_engine") and hasattr(
            search_ops.search_engine, # type: ignore[attr-defined]
            "_last_search_context",  
        ):
            search_context = getattr(
                search_ops.search_engine, # type: ignore[attr-defined]
                "_last_search_context",
                None,
            )

        # Extract graph traversal data from first result (they all have the same metadata)
        graph_traversal = {
            "entities_traversed": 0,
            "relationships_traversed": 0,
            "communities_analyzed": 0,
        }
        if results and results[0].memory and results[0].memory.metadata:
            graph_traversal = results[0].memory.metadata.get(
                "graph_traversal", graph_traversal
            )

        # Apply offset manually
        paginated_results = results[offset : offset + limit]

        # Track appearances for decay model (async fire-and-forget)
        if paginated_results:
            memory_ids_to_track = [
                r.memory.id for r in paginated_results if r.memory and r.memory.id
            ]
            if memory_ids_to_track:
                try:
                    # Track appearances in background
                    for mem_id in memory_ids_to_track:
                        await kuzu_client.memory_repo.increment_memory_appearances(
                            mem_id
                        )  # type: ignore[attr-defined]
                except Exception as e:
                    # Don't fail the search if tracking fails
                    logger.warning("Failed to track search appearances", error=str(e))

        # Transform results to frontend format using the transformer
        transformed_memories: List[Dict[str, Any]] = []
        for result in paginated_results:
            if result.memory:
                # Use transformer to get consistent format
                frontend_memory = await transform_memory_to_frontend_format(
                    result.memory,
                    kuzu_client,
                    include_labels=True,
                    include_source_thread=True,
                )
                # Enhance with search-specific metadata
                # Keep original source for display, store relevance_reason separately
                original_source = frontend_memory.get("source", "unknown")
                frontend_memory["confidence"] = result.similarity_score
                frontend_memory["metadata"] = {
                    **(frontend_memory.get("metadata", {})),
                    **result.memory.metadata,
                    "similarity_score": result.similarity_score,
                    "search_query": q,
                    "created_at": result.memory.created_at.isoformat()
                    if result.memory.created_at
                    else None,
                    "importance": result.memory.importance,
                    "relevance_reason": result.relevance_reason,
                    "original_source": original_source,
                    "search_type": "3_strategy_hybrid",
                }
                transformed_memories.append(frontend_memory)

        # Return enhanced format with search metadata
        response: Dict[str, Any] = {
            "memories": transformed_memories,
            "pagination": {
                "offset": offset,
                "limit": limit,
                "total": len(results),
                "has_more": offset + limit < len(results),
            },
            "search_metadata": {
                "query": q,
                "search_mode": "fast_bm25_vector"
                if mode == "fast"
                else "3_strategy_hybrid",
                "filters_applied": filters,
                "total_found": len(results),
                "intelligent_search": True,
                "strategies_used": [
                    "memory_hybrid" if mode != "fast" else "bm25+vector_fast",
                    *(
                        []
                        if mode == "fast"
                        else ["community_mediated", "llm_entity_mediated"]
                    ),
                ],
                "search_reasoning": generate_enhanced_search_reasoning(
                    q or "",
                    len(results),
                    len(filters),
                    search_context or {},
                    graph_traversal,
                ),
                "graph_traversal": graph_traversal,
                # Enhanced intelligence metadata
                "search_intelligence": build_search_intelligence_metadata(
                    search_context
                )
                if search_context
                else None,
            },
        }

        # Debug: Log search_intelligence to verify temporal_intent is included
        if search_context:
            temporal_intent = search_context.get("temporal_intent")
            logger.info(
                "🔍 Search context includes temporal_intent",
                has_temporal_intent=temporal_intent.get("has_temporal_intent")
                if temporal_intent
                else None,
                temporal_type=temporal_intent.get("temporal_type")
                if temporal_intent
                else None,
                temporal_confidence=temporal_intent.get("temporal_confidence")
                if temporal_intent
                else None,
            )

        logger.debug(
            "Enhanced unified endpoint completed: {}/{} results".format(
                len(paginated_results), len(results)
            ),
            query=q[:50] if q else "[browse mode]",
            total_results=len(results),
            returned_results=len(paginated_results),
            has_results=len(results) > 0,
            filters_count=len(filters),
            search_intelligence_included=response["search_metadata"].get(
                "search_intelligence"
            )
            is not None,
        )
        # Convert to Pydantic model
        return MemorySearchResponse(**response)  # type: ignore[arg-type]

    except Exception as e:
        logger.error(
            "Enhanced unified endpoint failed", query=q, error=str(e), exc_info=True
        )
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")


# from launcher
@router.post("/memories/search", response_model=List[MemorySearchResult])
async def search_memories(
    request: MemorySearchRequest,
    search_ops: SearchOperations = Depends(get_search_operations),
) -> List[MemorySearchResult]:
    """Memory search with filtering, metadata, and reasoning support."""
    try:
        logger.debug(
            "POST /memories/search: Enhanced memory search",
            query=request.query[:50] if request.query else "[empty]",
            limit=request.limit,
        )
        # Prepare filters from request (using only available fields)
        filters: Dict[str, Any] = {}
        if request.filter_labels:
            filters["labels"] = request.filter_labels
        # Use enhanced SearchOperations with filtering
        results = await search_ops.search_memories(
            query=request.query,
            limit=request.limit,
            search_mode="comprehensive",
            mode=(request.mode if request.mode in ["fast", "deep"] else "fast"),
            filter_labels=request.filter_labels,
            metadata_filters=filters,
        )
        # Filter results by confidence threshold.
        # In fast mode there is no LLM penalty; keep threshold same for now for consistency.
        confidence_threshold = 0.20
        filtered_results: List[MemorySearchResult] = []

        logger.debug(
            f"Launcher search filtering: {len(results)} results, threshold={confidence_threshold}"
        )

        for result in results:
            # The LLM-validated relevance score is stored in similarity_score
            # (After LLM content validation, the final adjusted score is put in similarity_score)
            confidence = result.similarity_score

            # Only include results that meet the confidence threshold
            logger.debug(
                f"Launcher result: memory_id={result.memory.id if result.memory else 'None'}, llm_validated_score={result.similarity_score}, threshold={confidence_threshold}"
            )
            if confidence >= confidence_threshold:
                # Keep the original structure but enhance the relevance reason
                enhanced_result = MemorySearchResult(
                    memory=result.memory,
                    similarity_score=result.similarity_score,
                    relevance_reason=f"{result.relevance_reason} (LLM validated)",
                    related_entities=getattr(result, "related_entities", []),
                )
                filtered_results.append(enhanced_result)

        enhanced_results = filtered_results
        logger.debug(
            "Launcher search completed: {}/{} results passed threshold".format(
                len(enhanced_results), len(results)
            ),
            query=request.query[:50] if request.query else "[empty]",
            total_found=len(results),
            returned_after_filter=len(enhanced_results),
            confidence_threshold=confidence_threshold,
            has_results=len(enhanced_results) > 0,
            top_scores=[round(r.similarity_score, 3) for r in enhanced_results[:3]],
        )
        return enhanced_results
    except Exception as e:
        logger.error(
            "POST /memories/search: Enhanced search failed",
            query=request.query[:50] if request.query else "[empty]",
            error=str(e),
            error_type=type(e).__name__,
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")
