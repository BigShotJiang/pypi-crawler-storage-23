"""Analytics and tracking endpoints for memories."""

from typing import Dict, Any
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field
from nowledge_graph_server.api.dependencies import get_kuzu_client
from nowledge_graph_server.database.kuzu_client import KuzuClient
from nowledge_graph_server.utils.transformers import find_memory_by_frontend_id
from nowledge_graph_server.models.memories_api import MessageResponse
import structlog

logger = structlog.get_logger(__name__)

router = APIRouter()


# Request model for view tracking
class MemoryViewRequest(BaseModel):
    """Request body for tracking memory views."""

    dwell_time_ms: int = Field(
        default=0, ge=0, description="Time spent reading the memory in milliseconds"
    )


@router.post(
    "/memories/{memory_id}/view",
    response_model=MessageResponse,
    include_in_schema=False,
)
async def track_memory_view(
    memory_id: str,
    request: MemoryViewRequest,
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> MessageResponse:
    """
    Track memory view/click for decay model.

    Updates:
    - clicks count
    - last_clicked_at timestamp
    - total_dwell_time_ms
    - access_count
    - last_accessed_at

    This data is used to compute decay scores (recency + frequency).
    """
    try:
        # Convert frontend ID to backend ID
        backend_id = await find_memory_by_frontend_id(memory_id, kuzu_client)
        if backend_id is None:
            raise HTTPException(status_code=404, detail="Memory not found")

        # Update click tracking
        result = await kuzu_client.memory_repo.update_memory_click(  # type: ignore[attr-defined]
            backend_id, request.dwell_time_ms
        )

        if not result:
            raise HTTPException(status_code=404, detail="Memory not found")

        logger.debug(
            "Tracked memory view",
            memory_id=memory_id,
            backend_id=backend_id,
            dwell_time_ms=request.dwell_time_ms,
        )

        return MessageResponse(message="Memory view tracked successfully")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Failed to track memory view",
            memory_id=memory_id,
            error=str(e),
        )
        raise HTTPException(status_code=500, detail="Failed to track memory view")


@router.post(
    "/memories/track-appearances",
    response_model=MessageResponse,
    include_in_schema=False,
)
async def track_search_result_appearances(
    request: Dict[str, Any],
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> MessageResponse:
    """
    Track when memories appear in search results for decay model.

    Updates:
    - appearances count for each memory

    This data is used alongside clicks to calculate CTR (click-through rate)
    and adjust decay scores based on visibility vs actual usage.

    Request body:
    ```json
    {
        "memory_ids": ["id1", "id2", ...],
        "source": "main_ui_search" | "floating_launcher" | "mcp_*",
        "context": {optional metadata}
    }
    ```
    """
    try:
        memory_ids = request.get("memory_ids", [])
        source = request.get("source", "unknown")
        context = request.get("context", {})

        if not memory_ids:
            return MessageResponse(message="No memory IDs provided")

        # Convert frontend IDs to backend IDs and track appearances
        tracked_count = 0
        for memory_id in memory_ids:
            try:
                backend_id = await find_memory_by_frontend_id(memory_id, kuzu_client)
                if backend_id:
                    # Increment appearances count
                    await kuzu_client.memory_repo.increment_memory_appearances(
                        backend_id
                    )  # type: ignore[attr-defined]
                    tracked_count += 1
            except Exception as e:
                logger.warning(
                    "Failed to track appearance for memory",
                    memory_id=memory_id,
                    error=str(e),
                )

        logger.info(
            "Tracked search result appearances",
            source=source,
            total_memories=len(memory_ids),
            tracked_count=tracked_count,
            context=context,
        )

        return MessageResponse(
            message=f"Tracked {tracked_count} memory appearances from {source}"
        )

    except Exception as e:
        logger.error(
            "Failed to track appearances",
            error=str(e),
        )
        # Don't fail the request if tracking fails
        return MessageResponse(message="Tracking failed but request continued")


@router.post(
    "/memories/launcher-copy", response_model=MessageResponse, include_in_schema=False
)
async def track_launcher_copy(
    request: Dict[str, Any],
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> MessageResponse:
    """
    Track when memories are copied from the floating launcher.

    This is a critical user action - they searched, found relevant memories,
    and explicitly chose to copy them. Treat this as a strong usage signal.

    Updates:
    - appearances: +1 for all shown memories
    - clicks/access_count: +1 for copied memories (treated as "usage")

    Request body:
    {
        "memory_ids": ["id1", "id2", ...],  # IDs that were copied
        "all_result_ids": ["id1", "id2", "id3", ...],  # All shown in search
        "query": "user search query",
        "source": "floating_launcher"
    }
    """
    try:
        copied_ids = request.get("memory_ids", [])
        all_result_ids = request.get(
            "all_result_ids", copied_ids
        )  # Fallback to copied if not provided
        query = request.get("query", "")
        source = request.get("source", "floating_launcher")

        if not copied_ids:
            return MessageResponse(message="No memory IDs provided")

        # Track appearances for all shown memories
        appearance_count = 0
        for memory_id in all_result_ids:
            try:
                backend_id = await find_memory_by_frontend_id(memory_id, kuzu_client)
                if backend_id:
                    await kuzu_client.memory_repo.increment_memory_appearances(
                        backend_id
                    )  # type: ignore[attr-defined]
                    appearance_count += 1
            except Exception as e:
                logger.warning(
                    "Failed to track launcher appearance",
                    memory_id=memory_id,
                    error=str(e),
                )

        # Track clicks for copied memories (treat copy as usage)
        copy_count = 0
        for memory_id in copied_ids:
            try:
                backend_id = await find_memory_by_frontend_id(memory_id, kuzu_client)
                if backend_id:
                    # Use update_memory_click with 0 dwell time (just track the copy action)
                    await kuzu_client.memory_repo.update_memory_click(
                        backend_id, dwell_time_ms=0
                    )  # type: ignore[attr-defined]
                    copy_count += 1
            except Exception as e:
                logger.warning(
                    "Failed to track launcher copy",
                    memory_id=memory_id,
                    error=str(e),
                )

        logger.info(
            "Tracked launcher copy operation",
            source=source,
            query=query,
            total_shown=len(all_result_ids),
            total_copied=len(copied_ids),
            appearances_tracked=appearance_count,
            copies_tracked=copy_count,
        )

        return MessageResponse(
            message=f"Tracked {copy_count} launcher copies from {source}"
        )

    except Exception as e:
        logger.error(
            "Failed to track launcher copy",
            error=str(e),
        )
        # Don't fail the request if tracking fails
        return MessageResponse(message="Tracking failed but request continued")
