"""
Memory management API router module.

This module provides a clean, modular structure for memory-related endpoints,
organized by functionality:
- crud: Create, Read, Update, Delete operations
- search: Search and query operations
- labels: Label management
- favorites: Favorites management
- analytics: View tracking and analytics
- knowledge_graph: KG extraction
- admin: Administrative operations
"""

from fastapi import APIRouter
from .labels import router as labels_router
from .analytics import router as analytics_router
from .favorites import router as favorites_router
from .search import router as search_router
from .crud import router as crud_router
from .knowledge_graph import router as kg_router
from .admin import router as admin_router

# Create main router that includes all sub-routers
router = APIRouter()

# Include all sub-routers (order matters for route matching)
router.include_router(labels_router)
router.include_router(analytics_router)
router.include_router(favorites_router)
router.include_router(search_router)
router.include_router(crud_router)
router.include_router(kg_router)
router.include_router(admin_router)

__all__ = ["router"]
