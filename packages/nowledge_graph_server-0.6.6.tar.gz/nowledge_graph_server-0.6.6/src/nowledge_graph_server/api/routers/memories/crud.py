"""CRUD (Create, Read, Update, Delete) endpoints for memories."""

from typing import Optional, List, Dict, Any
from fastapi import APIRouter, HTTPException, Depends, Query
from fastapi.responses import Response
from nowledge_graph_server.api.dependencies import (
    get_kuzu_client,
    get_memory_operations,
)
from nowledge_graph_server.core.memory_operations import MemoryOperations
from nowledge_graph_server.database.kuzu_client import KuzuClient
from nowledge_graph_server.services.search_index import delete_memory_from_index
from nowledge_graph_server.utils.transformers import (
    find_memory_by_frontend_id,
    transform_memory_to_frontend_format,
)
from nowledge_graph_server.models import (
    MemoryCreateRequest,
    MemoryCreateResponse,
)
from nowledge_graph_server.models.memories_api import (
    MemoryPublic,
    MemoryListResponse,
    DeleteMemoryResponse,
    PaginationInfo,
)
from nowledge_graph_server.utils.exporters import (
    export_memory_json,
    export_memory_markdown,
    export_memory_html,
)
from nowledge_graph_server.api.routers.license import (
    LicenseError,
    check_memory_creation_limit,
)
from nowledge_graph_server.utils.progress_logger import log_data_change
import structlog
import datetime
import json

logger = structlog.get_logger(__name__)

router = APIRouter()


@router.post("/memories", response_model=MemoryCreateResponse)
async def create_memory(
    request: MemoryCreateRequest,
    memory_ops: MemoryOperations = Depends(get_memory_operations),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> MemoryCreateResponse:
    """Create a new memory with automatic entity extraction."""
    try:
        # Check license limit before creating memory
        check_memory_creation_limit(kuzu_client, 1)

        # Debug logging to see what we received
        logger.debug(
            f"Memory create request: content_len={len(request.content)}, title={request.title}, source_thread_id={request.source_thread_id}, importance={request.importance}, confidence={request.confidence}, labels={request.labels}, metadata={request.metadata}"
        )

        # Use title from request, or auto-generate if not provided
        title = request.title
        if not title:
            # Auto-generate title from content
            title = (
                request.content[:50] + "..."
                if len(request.content) > 50
                else request.content
            )

        # Process bi-temporal fields if provided (no LLM in the loop for API/UI)
        temporal_type = None
        normalized_event_start = None
        normalized_event_end = None
        temporal_precision = None

        if request.event_start or request.event_end:
            from nowledge_graph_server.services.temporal_utils import (
                normalize_temporal_date,
            )

            # Determine temporal type
            if request.event_start and request.event_end:
                temporal_type = "range"
            elif request.event_start:
                temporal_type = "exact"

            # Normalize dates
            if request.event_start:
                try:
                    normalized_event_start, temporal_precision = (
                        normalize_temporal_date(request.event_start)
                    )
                except ValueError as e:
                    logger.warning(
                        "Failed to normalize event_start",
                        raw=request.event_start,
                        error=str(e),
                    )

            if request.event_end:
                try:
                    normalized_event_end, _ = normalize_temporal_date(request.event_end)
                except ValueError as e:
                    logger.warning(
                        "Failed to normalize event_end",
                        raw=request.event_end,
                        error=str(e),
                    )

        # Use core operations for memory creation
        result: Optional[MemoryCreateResponse] = await memory_ops.create_memory(
            content=request.content,
            title=title,
            importance=request.importance,
            confidence=request.confidence,
            source_id=request.source_thread_id,
            source=request.source or "manual",
            extract_entities=False,
            labels=request.labels or [],
            metadata=request.metadata,
            # Knowledge type classification
            unit_type=request.unit_type or "fact",
            # Bi-temporal fields
            temporal_type=temporal_type,
            event_start=normalized_event_start,
            event_end=normalized_event_end,
            temporal_precision=temporal_precision,
            temporal_confidence=1.0
            if (request.event_start or request.event_end)
            else None,
            temporal_context=request.temporal_context
            if request.temporal_context
            else "timeless",
        )

        if result is None:
            raise HTTPException(status_code=500, detail="Failed to create memory")

        # Notify UI of data change
        log_data_change(
            change_type="memory_created",
            entity_type="memory",
            entity_id=result.memory.id,
        )

        return result

    except LicenseError:
        # Re-raise license errors as-is
        raise
    except Exception as e:
        logger.error("Memory creation failed", error=str(e))
        raise HTTPException(status_code=500, detail="Memory creation failed")


@router.get("/memories/{memory_id}", response_model=MemoryPublic)
async def get_memory(
    memory_id: str,
    memory_ops: MemoryOperations = Depends(get_memory_operations),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> MemoryPublic:
    """Get a specific memory by ID with associated labels."""
    try:
        # Convert frontend ID to backend ID
        backend_id = await find_memory_by_frontend_id(memory_id, kuzu_client)
        if backend_id is None:
            raise HTTPException(status_code=404, detail="Memory not found")

        memory = await memory_ops.get_memory_by_id(backend_id)
        if memory is None:
            raise HTTPException(status_code=404, detail="Memory not found")

        # Transform to frontend format with all details
        frontend_memory = await transform_memory_to_frontend_format(
            memory, kuzu_client, include_labels=True, include_source_thread=True
        )

        return MemoryPublic(**frontend_memory)  # type: ignore[arg-type]

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to get memory", memory_id=memory_id, error=str(e))
        raise HTTPException(status_code=500, detail="Failed to get memory")


@router.get("/memories/{memory_id}/export")
async def export_memory(
    memory_id: str,
    format: str = Query(
        default="json", description="Export format: json, markdown, html"
    ),
    include_metadata: bool = Query(default=True, description="Include memory metadata"),
    memory_ops: MemoryOperations = Depends(get_memory_operations),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
):
    """Export a memory in various formats."""
    try:
        # Convert frontend ID to backend ID
        backend_id = await find_memory_by_frontend_id(memory_id, kuzu_client)
        if backend_id is None:
            raise HTTPException(status_code=404, detail="Memory not found")

        memory = await memory_ops.get_memory_by_id(backend_id)
        if memory is None:
            raise HTTPException(status_code=404, detail="Memory not found")

        # Get additional data for export
        labels = []
        source_thread: Optional[Dict[str, Any]] = None  # type: ignore[assignment]
        related_entities: List[Dict[str, Any]] = []

        if include_metadata:
            try:
                # Get labels
                labels = await kuzu_client.label_mgr.get_memory_labels(backend_id)

                # Get source thread if available
                if memory.metadata and memory.metadata.get("source_id"):
                    source_thread_id = memory.metadata.get("source_id")
                    # Try to get thread details
                    thread_query = """
                        MATCH (t:Thread {thread_id: $thread_id})
                        RETURN t.thread_id, t.title, t.source, t.created_at
                    """
                    assert kuzu_client.conn is not None
                    result = kuzu_client.conn.execute(
                        thread_query, {"thread_id": source_thread_id}
                    )
                    if result and result.has_next():  # type: ignore
                        row = result.get_next()  # type: ignore
                        # Convert datetime to isoformat if needed
                        created_at: datetime.datetime = row[3]  # type: ignore
                        if hasattr(created_at, "isoformat"):  # type: ignore[arg-type]
                            created_at = created_at.isoformat()  # type: ignore[arg-type]
                        source_thread: Dict[str, Any] = {
                            "thread_id": row[0],  # type: ignore
                            "title": row[1],  # type: ignore
                            "source": row[2],  # type: ignore
                            "created_at": created_at,
                        }

                # Get related entities
                entities_query = """
                    MATCH (m:Memory {id: $memory_id})-[:MENTIONS]->(e:Entity)
                    RETURN e.name, e.entity_type, e.confidence
                """
                assert kuzu_client.conn is not None
                result = kuzu_client.conn.execute(
                    entities_query, {"memory_id": backend_id}
                )
                while result and result.has_next():  # type: ignore
                    row = result.get_next()  # type: ignore
                    related_entities.append(
                        {"name": row[0], "type": row[1], "confidence": row[2]}  # type: ignore
                    )

            except Exception as e:
                logger.warning("Failed to get memory metadata for export", error=str(e))

        # Determine export format and generate content
        if format.lower() == "json":
            # Patch: ensure all datetime objects are converted to isoformat before dumping
            def default_json(obj: Any) -> str:
                import datetime

                if isinstance(obj, (datetime.datetime, datetime.date)):
                    return obj.isoformat()
                raise TypeError(
                    f"Object of type {type(obj).__name__} is not JSON serializable"
                )

            content = export_memory_json(
                memory, labels, source_thread, related_entities, include_metadata
            )
            # If _export_memory_json returns a dict, dump here; if it returns a string, patch there
            if isinstance(content, dict):
                import json

                content = json.dumps(
                    content, default=default_json, ensure_ascii=False, indent=2
                )
            else:
                # If already string, try to repair if needed
                pass
            media_type = "application/json"
            filename = f"memory_{memory_id}.json"
        elif format.lower() == "markdown":
            content = export_memory_markdown(
                memory, labels, source_thread, related_entities, include_metadata
            )
            media_type = "text/markdown"
            filename = f"memory_{memory_id}.md"
        elif format.lower() == "html":
            content = export_memory_html(
                memory, labels, source_thread, related_entities, include_metadata
            )
            media_type = "text/html"
            filename = f"memory_{memory_id}.html"
        else:
            raise HTTPException(
                status_code=400,
                detail="Unsupported format. Use: json, markdown, or html",
            )

        # Return response with appropriate headers
        return Response(
            content=content,
            media_type=media_type,
            headers={
                "Content-Disposition": f"attachment; filename={filename}",
                "Content-Type": f"{media_type}; charset=utf-8",
            },
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to export memory", memory_id=memory_id, error=str(e))
        raise HTTPException(status_code=500, detail="Failed to export memory")


@router.get("/memories", response_model=MemoryListResponse)
async def list_memories(
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    state: str = Query(default="active"),
    importance_min: float = Query(default=0.0, ge=0.0, le=1.0),
    memory_ops: MemoryOperations = Depends(get_memory_operations),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> MemoryListResponse:
    """List memories with filtering and pagination."""
    try:
        # Get raw memory nodes with pagination
        # logger.debug("Calling memory_ops.list_memories...")
        memory_nodes = await memory_ops.list_memories(
            limit=limit,
            offset=offset,
            state=state,
            importance_min=importance_min,
        )
        # Transform to frontend format
        memories: List[MemoryPublic] = []
        for memory in memory_nodes:
            # logger.debug(f"Transforming memory {i + 1}: {memory.id}")
            frontend_memory = await transform_memory_to_frontend_format(
                memory, kuzu_client, include_labels=True, include_source_thread=True
            )
            # logger.debug(f"Transformed to frontend ID: {frontend_memory['id']}")
            memories.append(MemoryPublic(**frontend_memory))

        # Get total count for pagination metadata
        # logger.debug("Getting total count...")
        total_count = await kuzu_client.count_memories(
            state=state, importance_min=importance_min
        )
        # logger.debug(f"Total count: {total_count}")

        pagination = PaginationInfo(
            limit=limit,
            offset=offset,
            total=total_count,
            has_more=offset + limit < total_count,
        )

        # logger.debug(f"Returning {len(memories)} transformed memories")
        # logger.debug("=== MEMORY LISTING DEBUG END ===")

        return MemoryListResponse(memories=memories, pagination=pagination)

    except Exception as e:
        logger.error("Failed to list memories", error=str(e), exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to list memories")


@router.patch("/memories/{memory_id}", response_model=MemoryPublic)
async def update_memory(
    memory_id: str,
    request: Dict[str, Any],
    memory_ops: MemoryOperations = Depends(get_memory_operations),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> MemoryPublic:
    """Update memory properties like importance, title, and content."""
    try:
        # Validate numeric ranges
        if "importance" in request and request["importance"] is not None:
            if not (0.0 <= request["importance"] <= 1.0):
                raise HTTPException(
                    status_code=422, detail="importance must be between 0.0 and 1.0"
                )
        if "confidence" in request and request["confidence"] is not None:
            if not (0.0 <= request["confidence"] <= 1.0):
                raise HTTPException(
                    status_code=422, detail="confidence must be between 0.0 and 1.0"
                )

        # Convert frontend ID to backend ID
        backend_id = await find_memory_by_frontend_id(memory_id, kuzu_client)
        if backend_id is None:
            raise HTTPException(status_code=404, detail="Memory not found")

        # Handle importance updates specially to avoid index constraints
        if "importance" in request:
            # Use the new importance-only update method
            updated = await kuzu_client.memory_repo.update_memory_importance(
                backend_id, request["importance"]
            )
            if not updated:
                raise HTTPException(status_code=404, detail="Memory not found")

            # Sync importance to search index (importance is indexed)
            try:
                memory_for_sync = await memory_ops.get_memory_by_id(backend_id)
                if memory_for_sync:
                    from ....services.search_index import sync_memory_to_index
                    await sync_memory_to_index(memory_for_sync)  # type: ignore[arg-type]
            except Exception as sync_error:
                logger.debug(
                    "Search index sync skipped on importance update",
                    memory_id=memory_id,
                    error=str(sync_error),
                )

        # Handle title and content updates
        if "title" in request or "content" in request:
            # Get current memory
            memory = await memory_ops.get_memory_by_id(backend_id)
            if not memory:
                raise HTTPException(status_code=404, detail="Memory not found")

            # Update title if provided
            if "title" in request:
                memory.title = request["title"]

            # Update content if provided
            if "content" in request:
                memory.content = request["content"]

            # Update timestamp
            memory.updated_at = datetime.datetime.now(datetime.timezone.utc)

            # Save to database
            await memory_ops.db.memory_repo.update_memory(memory)  # type: ignore[attr-defined]

            # Sync to LanceDB search index (re-embeds with BGE-M3)
            # This updates the search index when content changes
            try:
                from ....services.search_index import sync_memory_to_index
                await sync_memory_to_index(memory)  # type: ignore[arg-type]
            except Exception as sync_error:
                # Non-blocking - search index sync failure shouldn't fail the update
                logger.debug(
                    "Search index sync skipped on memory update",
                    memory_id=memory_id,
                    error=str(sync_error),
                )

        # Handle other updates
        elif "confidence" in request:
            # For other updates, get current memory and update normally
            memory = await memory_ops.get_memory_by_id(backend_id)
            if not memory:
                raise HTTPException(status_code=404, detail="Memory not found")

            memory.confidence = request["confidence"]
            memory.updated_at = datetime.datetime.now(datetime.timezone.utc)

            # Save to database
            await memory_ops.db.memory_repo.update_memory(memory)  # type: ignore[attr-defined]

        # Return updated memory in frontend format
        updated_memory = await memory_ops.get_memory_by_id(backend_id)
        if updated_memory:
            frontend_memory = await transform_memory_to_frontend_format(
                updated_memory,
                kuzu_client,
                include_labels=True,
                include_source_thread=True,
            )
            
            # Notify UI of data change
            log_data_change(
                change_type="memory_updated",
                entity_type="memory",
                entity_id=memory_id,
            )
            
            return MemoryPublic(**frontend_memory)  # type: ignore[arg-type]
        else:
            raise HTTPException(
                status_code=500, detail="Memory update succeeded but retrieval failed"
            )

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to update memory", memory_id=memory_id, error=str(e))
        raise HTTPException(status_code=500, detail="Failed to update memory")


@router.delete("/memories/{memory_id}", response_model=DeleteMemoryResponse)
async def delete_memory(
    memory_id: str,
    cascade_delete: bool = Query(default=True, description="Delete related entities"),
    memory_ops: MemoryOperations = Depends(get_memory_operations),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> DeleteMemoryResponse:
    """Delete a memory and optionally its relationships."""
    try:
        # Convert frontend ID to backend ID
        backend_id = await find_memory_by_frontend_id(memory_id, kuzu_client)
        if backend_id is None:
            # Best effort cleanup for stale search index entries:
            # ID may still exist in LanceDB even when absent in Kuzu.
            try:
                await delete_memory_from_index(memory_id)
            except Exception as cleanup_error:
                logger.debug(
                    "Failed best-effort index cleanup for missing memory",
                    memory_id=memory_id,
                    error=str(cleanup_error),
                )
            raise HTTPException(status_code=404, detail="Memory not found")

        result = await memory_ops.delete_memory(
            backend_id, cascade_delete=cascade_delete
        )

        if not result["deleted"]:
            raise HTTPException(
                status_code=404, detail=result.get("error", "Memory not found")
            )

        # Notify UI of data change
        log_data_change(
            change_type="memory_deleted",
            entity_type="memory",
            entity_id=memory_id,
        )

        # Check if this was the last memory from a distilled thread and clear distillation state
        try:
            # Find if this memory belonged to a distilled thread
            thread_query = """
                MATCH (t:Thread)-[:COMPACTS_TO]->(m:Memory {id: $memory_id})
                RETURN t.thread_id as thread_id, t.metadata as metadata
            """
            thread_result = kuzu_client.conn.execute(  # type: ignore
                thread_query, {"memory_id": backend_id}
            )

            if thread_result and thread_result.has_next():  # type: ignore
                thread_row = thread_result.get_next()  # type: ignore
                thread_id = thread_row[0]  # type: ignore
                thread_metadata_str: str = thread_row[1]  # type: ignore

                # Check if thread was marked as distilled
                thread_metadata: Dict[str, Any] = (
                    json.loads(thread_metadata_str) if thread_metadata_str else {}  # type: ignore[arg-type]
                )
                if thread_metadata.get("distilled"):
                    # Check if there are any remaining memories from this thread
                    remaining_memories_query = """
                        MATCH (t:Thread {thread_id: $thread_id})-[:COMPACTS_TO]->(m:Memory)
                        RETURN count(m) as memory_count
                    """
                    remaining_result = kuzu_client.conn.execute(  # type: ignore
                        remaining_memories_query, {"thread_id": thread_id}
                    )

                    if remaining_result and remaining_result.has_next():  # type: ignore
                        memory_count = remaining_result.get_next()[0]  # type: ignore

                        if memory_count == 0:
                            # Clear distillation state since no memories remain
                            thread_metadata.pop("distilled", None)
                            thread_metadata.pop("distillation_type", None)
                            thread_metadata.pop("distilled_at", None)
                            thread_metadata.pop("memory_count", None)

                            # Update thread metadata
                            kuzu_client.conn.execute(  # type: ignore
                                "MATCH (t:Thread {thread_id: $thread_id}) SET t.metadata = $metadata",
                                {
                                    "thread_id": thread_id,
                                    "metadata": json.dumps(thread_metadata),
                                },
                            )
                            logger.debug(
                                "Cleared distillation state from thread",
                                thread_id=thread_id,
                                reason="all_memories_deleted",
                            )

        except Exception as cleanup_error:
            logger.warning(
                "Failed to cleanup thread distillation state",
                memory_id=memory_id,
                error=str(cleanup_error),
            )

        return DeleteMemoryResponse(
            message="Memory deleted successfully",
            deleted_relationships=result["deleted_relationships"],
            deleted_entities=result["deleted_entities"],
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to delete memory", memory_id=memory_id, error=str(e))
        raise HTTPException(status_code=500, detail="Failed to delete memory")
