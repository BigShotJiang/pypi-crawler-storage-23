"""Knowledge graph extraction endpoints for memories."""

from fastapi import APIRouter, HTTPException, Depends
from nowledge_graph_server.api.dependencies import (
    get_kuzu_client,
    get_memory_operations,
    get_local_llm_service_dep,
)
from nowledge_graph_server.core.memory_operations import MemoryOperations
from nowledge_graph_server.database.kuzu_client import KuzuClient
from nowledge_graph_server.services.local_llm import LocalLLMService
from nowledge_graph_server.api.models.requests import (
    MemoryKGExtractionRequest,
    MemoryKGApplyRequest,
)
from nowledge_graph_server.api.models.responses import (
    MemoryKGExtractionResponse,
    MemoryKGApplyResponse,
)
from nowledge_graph_server.models import MemoryCreateResponse
from nowledge_graph_server.utils.llm_availability import check_llm_availability
from nowledge_graph_server.api.routers.distillation import (
    store_entities_and_relationships,
)  # type: ignore[attr-defined]
from nowledge_graph_server.services.base_llm import EntityExtractionResult
from nowledge_graph_server.utils.progress_logger import log_data_change
import structlog
import datetime
import json

logger = structlog.get_logger(__name__)

router = APIRouter()


@router.post("/memories/{memory_id}/extract-kg/preview")
async def preview_memory_kg_extraction(
    memory_id: str,
    request: MemoryKGExtractionRequest,
    memory_ops: MemoryOperations = Depends(get_memory_operations),
    llm_service: LocalLLMService = Depends(get_local_llm_service_dep),
) -> MemoryKGExtractionResponse:
    """Preview knowledge graph extraction for a memory.

    This endpoint extracts entities and relationships from a memory's content
    using the local LLM, providing a preview without saving to the database.
    """
    try:
        # Validate LLM availability
        is_available, error_msg = check_llm_availability()
        if not is_available:
            raise HTTPException(
                status_code=400,
                detail=error_msg,
            )

        logger.debug("Starting memory KG extraction preview", memory_id=memory_id)

        # Get the memory from database
        memory = await memory_ops.get_memory_by_id(memory_id)
        if not memory:
            raise HTTPException(status_code=404, detail="Memory not found")

        # Check if KG was already extracted (unless force_reextraction is True)
        metadata = memory.metadata or {}
        kg_already_extracted = metadata.get("kg_extracted", False)

        if kg_already_extracted and not request.force_reextraction:
            logger.debug(
                "KG already extracted for memory",
                memory_id=memory_id,
                force_reextraction=request.force_reextraction,
            )

            # Return existing extraction data if available
            existing_entities = metadata.get("extracted_entities", [])
            existing_relationships = metadata.get("extracted_relationships", [])

            return MemoryKGExtractionResponse(
                memory_id=memory_id,
                memory_title=memory.title or "Untitled Memory",
                memory_content=memory.content,
                entities=existing_entities,
                relationships=existing_relationships,
                extraction_confidence=metadata.get("kg_extraction_confidence", 0.7),
                entities_count=len(existing_entities),
                relationships_count=len(existing_relationships),
                kg_already_extracted=True,
                can_extract=False,  # Already extracted
            )

        # Prepare memory text for extraction (same format as thread distillation)
        memory_text = f"Memory Title: {memory.title or 'Untitled'}\n\nMemory Content: {memory.content}"

        # Extract entities and relationships
        logger.debug(
            "Extracting entities from memory",
            memory_id=memory_id,
            content_length=len(memory.content),
            use_remote_llm=request.use_remote_llm,
        )

        if request.use_remote_llm:
            # Use remote LLM for higher quality temporal-aware extraction
            await llm_service.initialize()
            remote_extraction = await llm_service._get_remote_extraction()

            if remote_extraction is None:
                raise HTTPException(
                    status_code=400,
                    detail="Remote LLM not available. Please configure it in Settings.",
                )

            logger.debug("Using remote LLM for KG extraction")
            extraction_result = await remote_extraction.extract_entities_remote(
                memory_title=memory.title or "Untitled Memory",
                memory_content=memory.content,
                memory_index=0,
                enable_reflection=True,
                enable_deduplication=True,
                preferred_language=request.preferred_language or None,
            )
        else:
            # Use local LLM (original flow)
            await llm_service.initialize()

            logger.debug(
                f"Memory KG extraction called with level: {request.extraction_level}"
            )
            # force_local=True since user explicitly chose local extraction (not use_remote_llm)
            extraction_result = await llm_service.extract_entities_from_single_memory(
                memory_text=memory_text,
                memory_index=0,
                memory_title=memory.title or "Untitled Memory",
                extraction_level=request.extraction_level,
                force_local=True,
            )

        logger.debug(
            "Memory KG extraction completed",
            memory_id=memory_id,
            entities_count=len(extraction_result.entities),
            relationships_count=len(extraction_result.relationships),
            confidence=extraction_result.confidence,
        )

        return MemoryKGExtractionResponse(
            memory_id=memory_id,
            memory_title=memory.title or "Untitled Memory",
            memory_content=memory.content,
            entities=extraction_result.entities,
            relationships=extraction_result.relationships,
            extraction_confidence=extraction_result.confidence,
            entities_count=len(extraction_result.entities),
            relationships_count=len(extraction_result.relationships),
            kg_already_extracted=kg_already_extracted,
            can_extract=True,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Failed to preview memory KG extraction", memory_id=memory_id, error=str(e)
        )
        raise HTTPException(
            status_code=500, detail=f"Failed to extract knowledge graph: {str(e)}"
        )


@router.post("/memories/{memory_id}/extract-kg/apply")
async def apply_memory_kg_extraction(
    memory_id: str,
    request: MemoryKGApplyRequest,
    memory_ops: MemoryOperations = Depends(get_memory_operations),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> MemoryKGApplyResponse:
    """Apply knowledge graph extraction results to a memory.

    This endpoint saves the extracted entities and relationships to the graph database
    and updates the memory's metadata to track the extraction.
    """
    try:
        logger.debug(
            "Applying memory KG extraction",
            memory_id=memory_id,
            entities_count=len(request.entities),  # type: ignore[arg-type]
            relationships_count=len(request.relationships),  # type: ignore[arg-type]
        )

        # Get the memory to verify it exists
        memory = await memory_ops.get_memory_by_id(memory_id)
        if not memory:
            raise HTTPException(status_code=404, detail="Memory not found")

        # Store entities and relationships in the graph database
        # Reuse the existing entity storage logic from distillation.py

        # Create EntityExtractionResult from the request
        entity_result = EntityExtractionResult(
            entities=request.entities,  # type: ignore[arg-type]
            relationships=request.relationships,  # type: ignore[arg-type]
            confidence=request.extraction_confidence,
        )

        # Create memory creation response object to match expected structure
        memory_response = MemoryCreateResponse(
            memory=memory,
            extracted_entities=[],
            assigned_labels=[],
            created_relationships=0,
        )

        # Store entities and relationships (this creates them in the graph)
        (
            stored_entities,  # type: ignore[arg-type]
            relationships_created,  # type: ignore[arg-type]
        ) = await store_entities_and_relationships(
            entity_result=entity_result,
            created_memories=[memory_response],  # type: ignore[arg-type]
            memory_ops=memory_ops,
        )

        # Update memory metadata to mark KG as extracted
        updated_metadata = memory.metadata or {}
        updated_metadata.update(
            {
                "kg_extracted": True,
                "kg_extracted_at": datetime.datetime.utcnow().isoformat(),  # type: ignore[attr-defined]
                "extracted_entities": request.entities,  # type: ignore[arg-type]
                "extracted_relationships": request.relationships,  # type: ignore[arg-type]
                "entities_count": len(request.entities),  # type: ignore[arg-type]
                "relationships_count": len(request.relationships),  # type: ignore[arg-type]
                "kg_extraction_confidence": request.extraction_confidence,
                "extraction_method": "manual_memory_llm",
            }
        )

        # Notify UI of data change (memory metadata updated with KG extraction)
        log_data_change(
            change_type="memory_updated",
            entity_type="memory",
            entity_id=memory_id,
            details={"kg_extraction_applied": True},
        )

        # Update the memory metadata directly in the database
        update_query = """
            MATCH (m:Memory {id: $memory_id})
            SET m.metadata = $metadata, m.updated_at = $updated_at
        """
        assert kuzu_client.conn is not None

        kuzu_client.conn.execute(
            update_query,
            {
                "memory_id": memory_id,
                "metadata": json.dumps(updated_metadata),
                "updated_at": datetime.datetime.now(datetime.timezone.utc),
            },
        )

        logger.debug(
            "Memory KG extraction applied successfully",
            memory_id=memory_id,
            entities_created=len(stored_entities),  # type: ignore[arg-type]
            relationships_created=relationships_created,
        )

        return MemoryKGApplyResponse(
            success=True,
            memory_id=memory_id,
            entities_created=len(stored_entities),  # type: ignore[arg-type]
            relationships_created=relationships_created,  # type: ignore[arg-type]
            metadata_updated=True,
            error=None,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Failed to apply memory KG extraction", memory_id=memory_id, error=str(e)
        )
        return MemoryKGApplyResponse(
            success=False,
            memory_id=memory_id,
            entities_created=0,
            relationships_created=0,
            metadata_updated=False,
            error=str(e),
        )
