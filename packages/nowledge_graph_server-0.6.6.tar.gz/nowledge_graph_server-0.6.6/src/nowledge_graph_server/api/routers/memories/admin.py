"""Administrative endpoints for memory management."""

from typing import Optional, List, Dict, Any
from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel, Field
from nowledge_graph_server.api.dependencies import get_memory_operations, get_kuzu_client
from nowledge_graph_server.core.memory_operations import MemoryOperations
from nowledge_graph_server.models.memories_api import (
    ReindexResponse,
    ReindexStatusResponse,
    ReindexDetail,
)
from nowledge_graph_server.services.search_index import (
    full_reindex_from_kuzu,
    is_search_index_available,
    get_search_index_status_info,
)
from nowledge_graph_server.services.search_embedding import (
    check_search_model_exists,
    get_search_model_info,
)
from nowledge_graph_server.api.routers.models import _clear_reindex_marker
import structlog

logger = structlog.get_logger(__name__)

router = APIRouter()


class MemoryReindexRequest(BaseModel):
    memory_ids: Optional[List[str]] = None


@router.post("/memories/reindex", response_model=ReindexResponse)
async def reindex_memories_bulk(
    request: MemoryReindexRequest,
    batch_size: int = Query(
        default=3, ge=1, le=10, description="Batch size for concurrent processing"
    ),
    memory_ops: MemoryOperations = Depends(get_memory_operations),
) -> ReindexResponse:
    """Reindex multiple memories or all memories needing reindex.

    This endpoint can work for both single and bulk reindexing:
    - If memory_ids is provided: reindex those specific memories
    - If memory_ids is None/empty: reindex all memories with reindex_needed=True
    """
    logger.info(f"request: {request}")
    try:
        logger.debug(
            "Memory reindex request",
            memory_ids_count=len(request.memory_ids)
            if request.memory_ids
            else "all_needed",
            batch_size=batch_size,
        )

        # Use the bulk reindex method which handles both cases
        result = await memory_ops.reindex_memories_bulk(
            memory_ids=request.memory_ids,
            batch_size=batch_size,
        )

        if not result["success"]:
            raise HTTPException(
                status_code=500,
                detail=result.get("error", "Reindexing failed"),
            )

        # Map the result to match ReindexResponse model
        # total_memories/reindexed_count -> processed, failed_count -> failed
        processed_count = result.get("total_memories", 0)  # total memories attempted
        failed_count = result.get("failed_count", 0)
        details_raw = result.get("details", [])

        # Convert details to ReindexDetail models
        details = [
            ReindexDetail(
                memory_id=detail.get("memory_id", ""),
                status=detail.get("status", "unknown"),
                error=detail.get("error"),
                reason=detail.get("reason"),
                embedding_dimension=detail.get("embedding_dimension"),
            )
            for detail in details_raw
        ]

        return ReindexResponse(
            success=result.get("success", True),
            processed=processed_count,
            failed=failed_count,
            error=result.get("error"),
            details=details,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Memory reindex failed", error=str(e))
        raise HTTPException(status_code=500, detail=f"Reindexing failed: {str(e)}")


@router.get("/memories/reindex/status", response_model=ReindexStatusResponse)
async def get_reindex_status(
    include_ids: bool = Query(
        default=False, description="Include all memory IDs needing reindex"
    ),
    memory_ops: MemoryOperations = Depends(get_memory_operations),
) -> ReindexStatusResponse:
    """Get status of memories needing reindex."""
    try:
        # Count memories needing reindex
        count_needing_reindex = await memory_ops.count_memories_needing_reindex()

        # Get a sample of memories needing reindex for preview
        sample_memories = await memory_ops.get_memories_needing_reindex(
            limit=5, offset=0
        )

        sample_data: List[Dict[str, Any]] = []
        for memory in sample_memories:
            sample_data.append(
                {
                    "id": memory.id,
                    "title": memory.title
                    or (
                        memory.content[:50] + "..."
                        if len(memory.content) > 50
                        else memory.content
                    ),
                    "updated_at": memory.updated_at.isoformat()
                    if memory.updated_at
                    else None,
                    "last_reindexed_at": memory.last_reindexed_at.isoformat()
                    if memory.last_reindexed_at
                    else None,
                }
            )

        # Optionally include all IDs for selection purposes
        all_memory_ids: Optional[List[str]] = None
        if include_ids and count_needing_reindex > 0:
            all_memories = await memory_ops.get_memories_needing_reindex(
                limit=1000, offset=0
            )
            all_memory_ids = [memory.id for memory in all_memories]

        return ReindexStatusResponse(
            count_needing_reindex=count_needing_reindex,
            sample_memories=sample_data,
            has_memories_needing_reindex=count_needing_reindex > 0,
            all_memory_ids=all_memory_ids,
        )

    except Exception as e:
        logger.error("Failed to get reindex status", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to get reindex status")


# ==================== Search Index Endpoints ====================


class SearchIndexStatusResponse(BaseModel):
    """Response for search index status."""

    available: bool = Field(description="Whether search index service is available")
    model_cached: bool = Field(description="Whether search embedding model is cached locally")
    model_name: str = Field(default="", description="Model being used (platform-specific)")
    message: str = Field(description="Status message")


class SearchIndexReindexResponse(BaseModel):
    """Response for search index reindex operation."""

    success: bool
    memories: int = Field(default=0, description="Number of memories indexed")
    messages: int = Field(default=0, description="Number of messages indexed")
    communities: int = Field(default=0, description="Number of communities indexed")
    entities: int = Field(default=0, description="Number of entities indexed")
    errors: List[str] = Field(default_factory=list, description="Any errors encountered")
    message: str = Field(default="", description="Status message")


@router.get("/search-index/status", response_model=SearchIndexStatusResponse)
async def get_search_index_status() -> SearchIndexStatusResponse:
    """Get status of the search index (LanceDB + hybrid search).

    The embedding model is platform-specific:
    - macOS Apple Silicon: Qwen3-Embedding via mlx-embeddings
    - non-Apple-Silicon (Windows/Linux/macOS Intel): BGE-M3 via FastEmbed/ONNX

    This endpoint checks:
    - Whether the search embedding model is cached locally
    - Whether the search index service is initialized
    """
    try:
        model_cached = check_search_model_exists()
        index_available = is_search_index_available()
        model_info = get_search_model_info()

        if not model_cached:
            return SearchIndexStatusResponse(
                available=False,
                model_cached=False,
                model_name=model_info["model_name"],
                message=(
                    f"Search embedding model not found. Please download the model to enable "
                    f"advanced hybrid search. The model is ~{model_info['estimated_size_mb']}MB."
                ),
            )

        if not index_available:
            return SearchIndexStatusResponse(
                available=False,
                model_cached=True,
                model_name=model_info["model_name"],
                message=(
                    f"{model_info['model_name']} cached but search index not initialized. "
                    "The service will initialize on first use."
                ),
            )

        return SearchIndexStatusResponse(
            available=True,
            model_cached=True,
            model_name=model_info["model_name"],
            message="Search index is available and ready for hybrid search.",
        )

    except Exception as e:
        logger.error("Failed to get search index status", error=str(e))
        return SearchIndexStatusResponse(
            available=False,
            model_cached=False,
            model_name="search-embedding",
            message=f"Error checking status: {str(e)}",
        )


@router.post("/search-index/reindex", response_model=SearchIndexReindexResponse)
async def reindex_search_index() -> SearchIndexReindexResponse:
    """Rebuild the search index from Kuzu database.

    This performs a full reindex of:
    - All memories (with search embeddings)
    - All thread messages
    - All communities
    - All entities

    The embedding model is platform-specific:
    - macOS Apple Silicon: Qwen3-Embedding via mlx-embeddings
    - non-Apple-Silicon (Windows/Linux/macOS Intel): BGE-M3 via FastEmbed/ONNX

    This is a heavy operation and should only be triggered:
    - After first downloading the search embedding model
    - After a data migration
    - When explicitly requested by the user
    """
    try:
        # Check if model is available
        model_info = get_search_model_info()
        if not check_search_model_exists():
            return SearchIndexReindexResponse(
                success=False,
                message=(
                    f"Search embedding model not found. Please download the model first "
                    f"before reindexing. The model is ~{model_info['estimated_size_mb']}MB."
                ),
            )

        logger.info("Starting full search index reindex from Kuzu")

        # Get kuzu client
        kuzu_client = await get_kuzu_client()

        # Run full reindex
        stats = await full_reindex_from_kuzu(kuzu_client)

        if stats.get("success"):
            # Clear the reindex marker after successful rebuild
            await _clear_reindex_marker()

            return SearchIndexReindexResponse(
                success=True,
                memories=stats.get("memories", 0),
                messages=stats.get("messages", 0),
                communities=stats.get("communities", 0),
                entities=stats.get("entities", 0),
                errors=stats.get("errors", []),
                message="Search index rebuilt successfully.",
            )
        else:
            return SearchIndexReindexResponse(
                success=False,
                memories=stats.get("memories", 0),
                messages=stats.get("messages", 0),
                communities=stats.get("communities", 0),
                entities=stats.get("entities", 0),
                errors=stats.get("errors", []),
                message=stats.get("error", "Reindex failed with errors."),
            )

    except Exception as e:
        logger.error("Failed to reindex search index", error=str(e))
        return SearchIndexReindexResponse(
            success=False,
            errors=[str(e)],
            message=f"Reindex failed: {str(e)}",
        )
