"""Favorites management endpoints for memories and threads."""

from typing import List
from fastapi import APIRouter, HTTPException, Depends, Query
from nowledge_graph_server.api.dependencies import get_kuzu_client
from nowledge_graph_server.database.kuzu_client import KuzuClient
from nowledge_graph_server.utils.transformers import (
    find_memory_by_frontend_id,
    transform_memory_to_frontend_format,
    transform_thread_to_frontend_format,
)
from nowledge_graph_server.models.memories_api import (
    MessageResponse,
    MemoryPublic,
    ThreadPublic,
)
from nowledge_graph_server.utils.progress_logger import log_data_change
import structlog

logger = structlog.get_logger(__name__)

router = APIRouter()


@router.post("/memories/{memory_id}/favorite", response_model=MessageResponse)
async def toggle_memory_favorite(
    memory_id: str,
    is_favorite: bool = Query(..., description="Set favorite status"),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> MessageResponse:
    """Toggle memory favorite status."""
    try:
        # Convert frontend ID to backend ID
        backend_id = await find_memory_by_frontend_id(memory_id, kuzu_client)
        if backend_id is None:
            raise HTTPException(status_code=404, detail="Memory not found")

        result = await kuzu_client.toggle_memory_favorite(backend_id, is_favorite)
        if not result:
            raise HTTPException(status_code=404, detail="Memory not found")

        # Notify UI of data change
        log_data_change(
            change_type="memory_favorite_toggled",
            entity_type="memory",
            entity_id=memory_id,
            details={"is_favorite": is_favorite},
        )

        return MessageResponse(message="Memory favorite status updated")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Failed to toggle memory favorite", memory_id=memory_id, error=str(e)
        )
        raise HTTPException(status_code=500, detail="Failed to toggle memory favorite")


@router.post("/threads/{thread_id}/favorite", response_model=MessageResponse)
async def toggle_thread_favorite(
    thread_id: str,
    is_favorite: bool = Query(..., description="Set favorite status"),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> MessageResponse:
    """Toggle favorite status for a thread."""
    try:
        success = await kuzu_client.favorites_mgr.toggle_thread_favorite(  # type: ignore[attr-defined]
            thread_id, is_favorite
        )
        if not success:
            raise HTTPException(status_code=404, detail="Thread not found")

        # Notify UI of data change
        log_data_change(
            change_type="thread_favorite_toggled",
            entity_type="thread",
            entity_id=thread_id,
            details={"is_favorite": is_favorite},
        )

        action = "added to" if is_favorite else "removed from"
        return MessageResponse(message=f"Thread {action} favorites successfully")
    except Exception as e:
        logger.error(
            "Failed to toggle thread favorite", thread_id=thread_id, error=str(e)
        )
        raise HTTPException(status_code=500, detail="Failed to toggle thread favorite")


@router.get("/favorites/memories", response_model=List[MemoryPublic])
async def get_favorite_memories(
    limit: int = Query(default=50, ge=1, le=100),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> List[MemoryPublic]:
    """Get all favorite memories."""
    try:
        memory_nodes = await kuzu_client.get_favorite_memories(limit)

        # Transform to frontend format
        memories: List[MemoryPublic] = []
        for memory in memory_nodes:
            frontend_memory = await transform_memory_to_frontend_format(
                memory, kuzu_client, include_labels=True, include_source_thread=True
            )
            memories.append(MemoryPublic(**frontend_memory))

        return memories
    except Exception as e:
        logger.error("Failed to get favorite memories", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to get favorite memories")


@router.get("/favorites/threads", response_model=List[ThreadPublic])
async def get_favorite_threads(
    limit: int = Query(default=50, ge=1, le=100),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> List[ThreadPublic]:
    """Get all favorite threads."""
    try:
        thread_nodes = await kuzu_client.favorites_mgr.get_favorite_threads(limit)

        # Transform to frontend format
        threads: List[ThreadPublic] = []
        for thread in thread_nodes:
            frontend_thread = await transform_thread_to_frontend_format(
                thread, kuzu_client
            )
            threads.append(ThreadPublic(**frontend_thread))

        return threads
    except Exception as e:
        logger.error("Failed to get favorite threads", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to get favorite threads")
