"""Label management endpoints for memories."""

from fastapi import APIRouter, HTTPException, Depends
from nowledge_graph_server.api.dependencies import get_kuzu_client
from nowledge_graph_server.database.kuzu_client import KuzuClient
from nowledge_graph_server.utils.transformers import find_memory_by_frontend_id
from nowledge_graph_server.models.memories_api import (
    MemoryLabelsResponse,
    MessageResponse,
)
from nowledge_graph_server.utils.progress_logger import log_data_change
import structlog

logger = structlog.get_logger(__name__)

router = APIRouter()


@router.get("/memories/{memory_id}/labels", response_model=MemoryLabelsResponse)
async def get_memory_labels(
    memory_id: str,
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> MemoryLabelsResponse:
    """Get labels assigned to a memory."""
    try:
        # Convert frontend ID to backend ID
        backend_id = await find_memory_by_frontend_id(memory_id, kuzu_client)
        if backend_id is None:
            raise HTTPException(status_code=404, detail="Memory not found")

        labels = await kuzu_client.label_mgr.get_memory_labels(backend_id)  # type: ignore[attr-defined]
        return MemoryLabelsResponse(labels=labels)

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to get memory labels", memory_id=memory_id, error=str(e))
        raise HTTPException(status_code=500, detail="Failed to get memory labels")


@router.post("/memories/{memory_id}/labels/{label_id}", response_model=MessageResponse)
async def assign_label_to_memory(
    memory_id: str,
    label_id: str,
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> MessageResponse:
    """Assign a label to a memory."""
    try:
        # Convert frontend ID to backend ID
        backend_id = await find_memory_by_frontend_id(memory_id, kuzu_client)
        if backend_id is None:
            raise HTTPException(status_code=404, detail="Memory not found")

        # Get the label name from label_id since assign_label_to_memory expects a name
        label = await kuzu_client.label_mgr.get_label_by_id(label_id)  # type: ignore[attr-defined]
        if label is None:
            raise HTTPException(status_code=404, detail="Label not found")

        await kuzu_client.label_mgr.assign_label_to_memory(backend_id, label["name"])  # type: ignore[attr-defined]
        
        # Notify UI of data change
        log_data_change(
            change_type="label_assigned_to_memory",
            entity_type="memory",
            entity_id=memory_id,
            details={"label_id": label_id},
        )
        
        return MessageResponse(message="Label assigned to memory")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Failed to assign label to memory",
            memory_id=memory_id,
            label_id=label_id,
            error=str(e),
        )
        raise HTTPException(status_code=500, detail="Failed to assign label to memory")


@router.delete(
    "/memories/{memory_id}/labels/{label_id}", response_model=MessageResponse
)
async def remove_label_from_memory(
    memory_id: str,
    label_id: str,
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> MessageResponse:
    """Remove a label from a memory."""
    try:
        # Convert frontend ID to backend ID
        backend_id = await find_memory_by_frontend_id(memory_id, kuzu_client)
        if backend_id is None:
            raise HTTPException(status_code=404, detail="Memory not found")

        result = await kuzu_client.label_mgr.remove_label_from_memory(  # type: ignore[attr-defined]
            backend_id, label_id
        )
        if not result:
            raise HTTPException(status_code=404, detail="Label or memory not found")

        # Notify UI of data change
        log_data_change(
            change_type="label_removed_from_memory",
            entity_type="memory",
            entity_id=memory_id,
            details={"label_id": label_id},
        )

        return MessageResponse(message="Label removed from memory")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Failed to remove label from memory",
            memory_id=memory_id,
            label_id=label_id,
            error=str(e),
        )
        raise HTTPException(
            status_code=500, detail="Failed to remove label from memory"
        )
