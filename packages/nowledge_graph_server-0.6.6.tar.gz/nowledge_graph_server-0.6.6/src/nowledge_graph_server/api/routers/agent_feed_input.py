"""Feed input and SSE streaming endpoints.

Split from agent.py to stay under pyarmor free-version line limits.
Provides:
- POST /feed/input/stream — SSE streaming endpoint (agent-first, always)
- POST /feed/input/persist-question — Persist follow-up Q&A as feed event
"""

from __future__ import annotations

import json
import asyncio
import uuid
from datetime import datetime, timezone
from pathlib import Path
import re
from typing import Any, Dict, List, Optional

import structlog
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from ..dependencies import get_kuzu_client, get_memory_operations
from nowledge_graph_server.utils.progress_logger import log_data_change
from .agent import (
    _get_events_dir,
    _get_time_partitioned_path,
    _get_agent_manager,
    _parse_agent_classification,
)

router = APIRouter(tags=["knowledge-agent"])
logger = structlog.get_logger(__name__)


# ------------------------------------------------------------------
# Persist Question (no memory creation, just JSONL event)
# ------------------------------------------------------------------


class PersistQuestionRequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=10000)
    agent_response: str = Field(..., max_length=50000)
    source: str = Field(default="feed")
    related_memory_ids: Optional[List[str]] = Field(default=None)
    tool_calls: Optional[List[Dict[str, Any]]] = Field(default=None)
    thread_id: Optional[str] = Field(default=None, description="Thread root event ID for follow-up conversations")


@router.post("/feed/input/persist-question")
async def persist_question(request: PersistQuestionRequest) -> Dict[str, Any]:
    """Persist a question + agent response as a feed event (JSONL).

    Called by the frontend after agent streaming completes for questions.
    Does NOT create a memory — only writes the event for timeline persistence.
    """
    now = datetime.now(timezone.utc)
    event_id = f"evt-{uuid.uuid4().hex[:12]}"

    try:
        events_dir = _get_events_dir()

        metadata: Dict[str, Any] = {
            "question": request.question,
            "agent_message": request.agent_response,
            "source": request.source,
            "input_type": "question",
        }
        if request.tool_calls:
            metadata["tool_calls"] = request.tool_calls

        # Build source breakdown from related memories
        if request.related_memory_ids:
            try:
                kuzu = await get_kuzu_client()
                breakdown: Dict[str, int] = {}
                for mid in request.related_memory_ids:
                    assert kuzu.conn is not None, "db connection is not initialized"
                    result = kuzu.conn.execute(
                        "MATCH (m:Memory) WHERE m.id = $id RETURN m.source",
                        {"id": mid},
                    )
                    if result.has_next():
                        src = result.get_next()[0] or "unknown"
                        breakdown[src] = breakdown.get(src, 0) + 1
                if breakdown:
                    metadata["source_breakdown"] = breakdown
            except Exception:
                pass  # Source breakdown is best-effort

        feed_event = {
            "id": event_id,
            "event_type": "user_question",
            "severity": "info",
            "title": request.question[:100],
            "description": request.agent_response[:500],
            "metadata": json.dumps(metadata),
            "related_memory_ids": request.related_memory_ids or [],
            "resolved": False,
            "created_at": now.isoformat(),
        }
        if request.thread_id:
            feed_event["thread_id"] = request.thread_id

        if events_dir is not None:
            event_path = _get_time_partitioned_path(events_dir, now, "jsonl")
            with open(event_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(feed_event) + "\n")

        log_data_change(
            "feed_event_created", "feed", event_id,
            {"event_type": "user_question", "input_type": "question"},
        )

        return {
            "event_id": event_id,
            "feedItem": feed_event,
        }

    except Exception as e:
        logger.error("Persist question failed", error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to persist question: {e}")


# ------------------------------------------------------------------
# Feed Input Streaming (agent-first, Wire Protocol)
# ------------------------------------------------------------------


class FeedInputRequest(BaseModel):
    content: str = Field(..., min_length=1, max_length=10000)
    source: str = Field(default="feed")
    persist: bool = Field(
        default=True,
        description="Auto-persist after streaming. False for ephemeral queries (e.g. Chat-to-Doc Q&A).",
    )
    thread_id: Optional[str] = Field(default=None, description="Thread root event ID for follow-up conversations")


def _wire_to_sse(msg: Any) -> Dict[str, Any]:
    """Convert WireMessage to SSE-friendly dict.

    Note: TurnEnd is not exported from kimi_agent_sdk Python SDK.
    The turn ends when the async generator completes, so we send
    a synthetic turn_end event after the stream finishes.
    """
    # Lazy import to avoid issues when kimi-agent-sdk not installed
    try:
        from kimi_agent_sdk import (
            TurnBegin, StepBegin, TextPart, ThinkPart,
            ToolCall, ToolCallPart, ToolResult, CompactionBegin, CompactionEnd,
        )
    except ImportError:
        # Fallback: return generic event
        return {"type": msg.__class__.__name__.lower()}

    if isinstance(msg, TurnBegin):
        return {"type": "turn_begin"}
    elif isinstance(msg, StepBegin):
        return {"type": "step_begin", "step": msg.n}
    elif isinstance(msg, TextPart):
        return {"type": "text", "content": msg.text}
    elif isinstance(msg, ThinkPart):
        return {"type": "thinking", "content": msg.think}
    elif isinstance(msg, ToolCall):
        # ToolCall has the tool name and id - this is emitted when the agent starts a tool call
        return {
            "type": "tool_call",
            "name": msg.function.name if hasattr(msg, "function") else "unknown",
            "id": msg.id if hasattr(msg, "id") else "",
        }
    elif isinstance(msg, ToolCallPart):
        # ToolCallPart only contains streaming arguments (partial JSON), skip it for now
        # The tool name was already sent in the ToolCall event
        return {"type": "tool_call_part", "arguments": msg.arguments_part or ""}
    elif isinstance(msg, ToolResult):
        # Extract result content from return_value
        # NOTE: Do NOT truncate — the frontend parses JSON to extract memory IDs
        # for graph rendering. Truncated JSON breaks JSON.parse().
        result_content = ""
        is_error = False
        if hasattr(msg, "return_value"):
            rv = msg.return_value
            is_error = getattr(rv, "is_error", False)
            # Get output content (could be string or ContentPart)
            output = getattr(rv, "output", "")
            if isinstance(output, str):
                result_content = output
            elif isinstance(output, list):
                # List of ContentPart - extract text
                texts = [str(p) for p in output if p]
                result_content = " ".join(texts)
            # Also check for brief in display blocks
            brief = getattr(rv, "brief", "")
            if brief and not result_content:
                result_content = str(brief)
        return {
            "type": "tool_result",
            "tool_call_id": msg.tool_call_id if hasattr(msg, "tool_call_id") else "",
            "content": result_content,
            "is_error": is_error,
        }
    elif isinstance(msg, CompactionBegin):
        return {"type": "compaction_begin"}
    elif isinstance(msg, CompactionEnd):
        return {"type": "compaction_end"}
    else:
        return {"type": msg.__class__.__name__.lower()}


def _is_usable_attached_source(source_node: Any) -> bool:
    """Whether a pre-ingested URL source is usable as [ATTACHED SOURCE]."""
    if not source_node:
        return False
    if source_node.lifecycle_state in {"error", "ingested"}:
        return False
    if not source_node.parsed_path:
        return False
    if (source_node.chunk_count or 0) <= 0:
        return False

    try:
        parsed = Path(source_node.parsed_path)
        if not parsed.exists():
            return False
        if not parsed.read_text(encoding="utf-8", errors="replace").strip():
            return False
    except Exception:
        return False
    return True


def _extract_urls(text: str) -> List[str]:
    """Extract and normalize URLs from user text."""
    urls: List[str] = []
    seen: set[str] = set()
    for raw_url in re.findall(r"https?://\S+", text):
        # Trim common trailing punctuation from pasted prose while keeping query strings.
        normalized = raw_url.rstrip(".,;:!)]}>'\"，。；：！）】》")
        if normalized and normalized not in seen:
            urls.append(normalized)
            seen.add(normalized)
    return urls


def _is_url_only_submission(content: str, urls: List[str]) -> bool:
    """Return True when the user input contains only URL(s) and punctuation."""
    if not urls:
        return False
    remaining = content
    for url in urls:
        remaining = remaining.replace(url, " ")
    remaining = remaining.strip().strip("`'\"()[]{}<>-–—:;,.!?，。！？；：")
    return not remaining


def _should_cleanup_prefetched_source(source_node: Any, prefetch_started_at: datetime) -> bool:
    """Only cleanup URL sources that look newly created by this prefetch attempt."""
    if not source_node or not getattr(source_node, "id", None):
        return False

    # Never remove sources that already have linked memories.
    if (getattr(source_node, "memory_count", 0) or 0) > 0:
        return False

    created_at = getattr(source_node, "created_at", None)
    if not isinstance(created_at, datetime):
        return False
    if created_at.tzinfo is None:
        created_at = created_at.replace(tzinfo=timezone.utc)

    # Small skew tolerance for DB clock/serialization differences.
    tolerance_seconds = 5
    return created_at.timestamp() >= (prefetch_started_at.timestamp() - tolerance_seconds)


async def _cleanup_failed_url_source(source_id: str) -> None:
    """Best-effort cleanup for failed pre-ingested URL sources."""
    try:
        kuzu = await get_kuzu_client()
        await kuzu.source_repo.delete_source(source_id)
    except Exception:
        pass

    try:
        from nowledge_graph_server.services.search_index.source_sync import delete_source_from_index

        await delete_source_from_index(source_id)
    except Exception:
        pass

    try:
        from nowledge_graph_server.services.source_storage import SourceStorageService

        SourceStorageService().delete_source_dir(source_id)
    except Exception:
        pass


@router.post("/feed/input/stream")
async def submit_feed_input_stream(
    request: FeedInputRequest,
) -> StreamingResponse:
    """Stream agent processing of feed input via Wire Protocol.

    This is the agent-first approach: the agent classifies input,
    searches the knowledge base, and provides streaming responses.

    Returns Server-Sent Events (SSE) with Wire Protocol messages:
    - turn_begin: Agent turn started
    - step_begin: New processing step
    - text: Text content from agent
    - thinking: Agent's reasoning (if enabled)
    - tool_call: Agent called a tool
    - tool_result: Tool returned a result
    - turn_end: Agent turn completed
    """
    manager = _get_agent_manager()

    # Hard requirement: no heuristic fallback when agent not available
    if manager is None:
        raise HTTPException(
            status_code=503,
            detail="Knowledge Agent not initialized. Configure AI-Now LLM in Settings.",
        )

    if not manager.is_feed_agent_running:
        # Provide more specific error message based on why it's not running
        status = manager.get_status()
        if not status.get("llm_available"):
            raise HTTPException(
                status_code=503,
                detail="Feed Agent not running: LLM not configured or unavailable. Configure AI-Now LLM in Settings.",
            )
        raise HTTPException(
            status_code=503,
            detail="Feed Agent not running. Check server logs for details.",
        )

    # ------------------------------------------------------------------
    # URL pre-ingestion: detect URLs and ingest BEFORE agent call so the
    # agent sees the actual page content (via [ATTACHED SOURCE]) and can
    # write an informed summary. This mirrors the file attachment flow.
    # URL detection (regex) is infrastructure, not classification — the
    # agent still decides what to do with the content.
    # ------------------------------------------------------------------
    _url_source_ids: List[str] = []    # source IDs for ingested URLs
    _url_source_nodes: List[Any] = []  # SourceNode objects for metadata
    _ingested_urls: List[str] = []     # URLs aligned with _url_source_nodes
    _is_url_input = False
    _detected_urls: List[str] = []
    _url_ingest_failures: List[Dict[str, str]] = []
    _url_prefetch_status: Optional[str] = None

    if request.source == "feed":
        _detected_urls = _extract_urls(request.content)
        if _detected_urls:
            try:
                from nowledge_graph_server.services.source_pipeline import SourcePipeline

                kuzu = await get_kuzu_client()
                pipeline = SourcePipeline(db_client=kuzu)
                prefetch_started_at = datetime.now(timezone.utc)

                for url in _detected_urls:
                    try:
                        logger.info("Pre-ingesting URL before agent call", url=url)
                        source_node = await pipeline.ingest_url(url=url)
                        if _is_usable_attached_source(source_node):
                            _url_source_ids.append(source_node.id)
                            _url_source_nodes.append(source_node)
                            _ingested_urls.append(url)
                        else:
                            _url_ingest_failures.append({
                                "url": url,
                                "reason": (
                                    f"unusable_source_state:{source_node.lifecycle_state},"
                                    f"chunk_count:{source_node.chunk_count}"
                                ),
                            })
                            if _should_cleanup_prefetched_source(source_node, prefetch_started_at):
                                await _cleanup_failed_url_source(source_node.id)
                    except Exception as e:
                        _url_ingest_failures.append({"url": url, "reason": str(e)})
                        logger.warning("URL ingestion failed", url=url, error=str(e))

                if _url_source_nodes:
                    _is_url_input = True
                    # First usable URL becomes the attached source context.
                    request.source = f"library:{_url_source_ids[0]}"
                    if _url_ingest_failures:
                        _url_prefetch_status = (
                            f"Some URLs could not be fetched ({len(_url_ingest_failures)}). "
                            "Continuing with available sources."
                        )
                else:
                    request.source = "feed"
                    _is_url_input = False
                    _url_prefetch_status = (
                        f"Could not fetch URL content for {_detected_urls[0]}. "
                        "Nothing was saved to Library or memory."
                    )

                logger.info(
                    "URL pre-ingestion complete",
                    detected_count=len(_detected_urls),
                    usable_count=len(_url_source_ids),
                    failed_count=len(_url_ingest_failures),
                    source_ids=_url_source_ids,
                )

            except Exception as e:
                logger.warning("URL pre-ingestion failed, agent will not see content",
                               urls=_detected_urls, error=str(e))
                _url_prefetch_status = (
                    "Could not fetch URL content. Nothing was saved to Library or memory."
                )
                request.source = "feed"
                _is_url_input = False
                _url_source_ids.clear()
                _url_source_nodes.clear()
                _ingested_urls.clear()

    # Build source hint if this is a Chat-to-Doc request (source = "library:{id}")
    # Also triggered for pre-ingested URLs (source was overridden above).
    # Includes metadata + document preview so agent can answer simple questions
    # without tool calls, and ReadSourceContent/SearchSourceChunks for deeper access.
    source_context: Optional[str] = None
    if request.source.startswith("library:"):
        source_id = request.source[len("library:"):]
        try:
            kuzu = await get_kuzu_client()
            source_node = await kuzu.source_repo.get_source(source_id)
            if source_node:
                source_context = (
                    f"[ATTACHED SOURCE]\n"
                    f"The user is asking about a specific document from their Library.\n"
                    f"Answer from the document content. Do not search or reference other memories.\n"
                    f"- Source ID: {source_id}\n"
                    f"- Name: {source_node.original_name}\n"
                    f"- Type: {source_node.source_type}\n"
                    f"- Chunks: {source_node.chunk_count}\n"
                    f"For deeper access: ReadSourceContent(source_id='{source_id}') "
                    f"or SearchSourceChunks(source_id='{source_id}', query='...')"
                )
                # Pre-load preview so agent can answer simple questions instantly
                # Tabular files get a larger preview (5K → ~50 rows) for analytical context
                if source_node.parsed_path:
                    try:
                        from pathlib import Path as _P
                        parsed_path = _P(source_node.parsed_path)
                        _name_lower = (source_node.original_name or "").lower()
                        _is_tabular = _name_lower.endswith((".csv", ".xlsx", ".xls", ".tsv"))
                        _preview_limit = 5000 if _is_tabular else 2000
                        preview = parsed_path.read_text(encoding="utf-8")[:_preview_limit]
                        if preview:
                            tabular_hint = ""
                            if _is_tabular:
                                # Extract column names from the first markdown table row
                                _cols = []
                                for _line in preview.split("\n"):
                                    _stripped = _line.strip()
                                    if _stripped.startswith("|") and _stripped.endswith("|"):
                                        _cols = [c.strip() for c in _stripped.split("|") if c.strip()]
                                        break
                                _ext = _name_lower.rsplit(".", 1)[-1].upper()
                                if _cols:
                                    tabular_hint = (
                                        f"\n- File format: tabular data ({_ext})"
                                        f"\n- Columns ({len(_cols)}): {', '.join(_cols)}"
                                        f"\n- STRATEGY: Call AnalyzeSourceData(source_id='{source_id}') "
                                        f"for computed statistics (distributions, trends, correlations). "
                                        f"Then use ReadSourceContent only if raw rows are needed."
                                        f"\n- CHARTS: ALWAYS include a ```vega-lite chart "
                                        f"for analytical questions. Build chart data from "
                                        f"AnalyzeSourceData results, aggregate if 100+ rows."
                                    )
                            if tabular_hint:
                                source_context += tabular_hint
                            source_context += (
                                f"\n\n[DOCUMENT PREVIEW (first {_preview_limit} chars)]\n"
                                f"{preview}\n"
                                f"[END PREVIEW]"
                            )
                    except Exception:
                        pass  # Preview is best-effort
                source_context += "\n---"
            else:
                source_context = (
                    f"[ATTACHED SOURCE]\n"
                    f"WARNING: Source '{source_id}' not found in graph.\n---"
                )
        except Exception as e:
            logger.warning("Failed to build source hint", source_id=source_id, error=str(e))
            source_context = (
                f"[ATTACHED SOURCE]\n"
                f"WARNING: Could not load source metadata for '{source_id}'. "
                f"Error: {e}\n---"
            )

    async def event_stream():
        content = request.content.strip()
        full_agent_text = ""  # Accumulate agent response text
        tool_calls: List[Dict[str, Any]] = []
        tool_call_map: Dict[str, Dict[str, Any]] = {}  # tool_call_id → {name, result}
        discovered_memory_ids: List[str] = []

        try:
            # Send an immediate ping so slow LLMs don't trigger client timeouts
            yield "data: {\"type\": \"stream_start\"}\n\n"

            # Notify the frontend that document context has been loaded (or failed)
            if source_context:
                if "WARNING:" in source_context:
                    status_msg = "Document context unavailable"
                elif _is_url_input:
                    status_msg = "Reading fetched page..."
                else:
                    status_msg = "Reading document..."
                yield f"data: {json.dumps({'type': 'status', 'content': status_msg})}\n\n"
            elif _url_prefetch_status:
                yield f"data: {json.dumps({'type': 'status', 'content': _url_prefetch_status})}\n\n"

            keepalive_seconds = 10
            stream_iter = manager.process_feed_input_streaming(
                content, source_context=source_context, thread_id=request.thread_id,
            )
            pending_next: Optional[asyncio.Task[Any]] = None

            # Stream Wire messages from the Feed agent without cancelling the generator.
            # Cancelling __anext__ can terminate the stream when the agent is slow.
            while True:
                if pending_next is None:
                    pending_next = asyncio.create_task(stream_iter.__anext__())

                done, _ = await asyncio.wait(
                    {pending_next},
                    timeout=keepalive_seconds,
                )

                if not done:
                    # Keep the SSE connection alive while the LLM is thinking
                    yield f"data: {json.dumps({'type': 'keepalive'})}\n\n"
                    continue

                try:
                    wire_msg = pending_next.result()
                except StopAsyncIteration:
                    break
                finally:
                    pending_next = None

                event = _wire_to_sse(wire_msg)
                evt_type = event.get("type")

                # Accumulate text events
                if evt_type == "text" and event.get("content"):
                    full_agent_text += event["content"]
                # Track tool calls for question events
                elif evt_type == "tool_call":
                    tc_name = event.get("name", "unknown")
                    tc_id = event.get("id", "")
                    tool_calls.append({"name": tc_name})
                    if tc_id:
                        tool_call_map[tc_id] = {"name": tc_name}
                # Extract discovered memory IDs + persist tool results
                elif evt_type == "tool_result":
                    tc_id = event.get("tool_call_id", "")
                    result_content = event.get("content", "")
                    is_error = event.get("is_error", False)

                    # Save result to tool_call_map for rich rendering
                    if tc_id and tc_id in tool_call_map:
                        tool_call_map[tc_id]["result"] = result_content
                        tool_call_map[tc_id]["is_error"] = is_error

                    if not is_error:
                        try:
                            parsed = json.loads(result_content)
                            memories = parsed.get("memories") or parsed.get("matches") or []
                            if isinstance(memories, list):
                                for m in memories:
                                    mid = m.get("id") if isinstance(m, dict) else None
                                    if mid and mid not in discovered_memory_ids:
                                        discovered_memory_ids.append(mid)
                        except (json.JSONDecodeError, AttributeError, TypeError):
                            pass

                yield f"data: {json.dumps(event)}\n\n"

            # ----------------------------------------------------------
            # Record Feed Agent token usage (after stream completes)
            # ----------------------------------------------------------
            try:
                from nowledge_graph_server.agent import token_tracker
                if manager._feed_session and hasattr(manager._feed_session, "last_turn_tokens"):
                    feed_inp, feed_out = manager._feed_session.last_turn_tokens
                    if feed_inp > 0 or feed_out > 0:
                        token_tracker.record(feed_inp, feed_out, source="feed_agent")
            except Exception:
                pass  # Token tracking is best-effort

            # ----------------------------------------------------------
            # Persist: agent is the sole classifier. Parse its tags and
            # create the memory/event directly — no frontend round-trip.
            # ----------------------------------------------------------
            persist_result_event = None

            if request.persist and full_agent_text:
                try:
                    classification = _parse_agent_classification(full_agent_text)
                    clean_text = classification["clean_text"]
                    input_type = classification["input_type"]
                    title = classification["title"]
                    source = request.source

                    if input_type is None:
                        logger.warning("Agent did not provide classification tags — treating as conversation",
                                       source=source, agent_text_tail=full_agent_text[-200:])

                    # Guard: if agent called ScheduleFollowUp, this is an action — not a capture.
                    # The tool already emits its own task_scheduled event.
                    _called_schedule = any(
                        tc.get("name") == "ScheduleFollowUp" for tc in tool_calls
                    )
                    if _called_schedule and input_type == "capture":
                        logger.warning(
                            "Agent called ScheduleFollowUp but classified as capture — overriding to question",
                            original_type=input_type,
                        )
                        input_type = "question"
                    # If URL was successfully pre-fetched as attached source,
                    # force URL classifications to capture so the summary can be stored.
                    if input_type == "url" and _is_url_input and _url_source_nodes:
                        logger.warning(
                            "Agent returned TYPE=url despite attached URL source — coercing to capture",
                            source=request.source,
                        )
                        input_type = "capture"
                    # If URL prefetch failed and input is only URL text, never create memory.
                    if (
                        input_type == "capture"
                        and _detected_urls
                        and not _url_source_nodes
                        and _is_url_only_submission(content, _detected_urls)
                    ):
                        logger.warning(
                            "URL-only submission failed prefetch — coercing capture to url failure event",
                            source=request.source,
                            detected_urls=_detected_urls,
                        )
                        input_type = "url"

                    now = datetime.now(timezone.utc)
                    event_id = f"evt-{uuid.uuid4().hex[:12]}"
                    events_dir = _get_events_dir()

                    if input_type == "capture":
                        # For library captures, agent summary IS the memory content.
                        # For direct captures, user text IS the memory (they're sharing knowledge).
                        if source.startswith("library:") and clean_text and len(clean_text) > 20:
                            memory_content = clean_text
                        else:
                            memory_content = content

                        memory_title = title or (content[:80] if len(content) > 80 else content)

                        memory_ops = await get_memory_operations()
                        create_result = await memory_ops.create_memory(
                            content=memory_content,
                            title=memory_title,
                            source=source,
                            importance=0.5,
                            skip_feed_event=True,
                        )
                        if create_result and create_result.memory:
                            mem_id = create_result.memory.id

                            # SOURCED_FROM edge for library captures
                            if source.startswith("library:"):
                                source_id = source[len("library:"):]
                                try:
                                    kuzu = await get_kuzu_client()
                                    await kuzu.source_repo.create_sourced_from(
                                        memory_id=mem_id, source_id=source_id,
                                    )
                                except Exception as e:
                                    logger.error("SOURCED_FROM edge failed", error=str(e))

                            # URL captures get url_captured events; regular captures get memory_created
                            if _is_url_input and _url_source_nodes:
                                _sn = _url_source_nodes[0]
                                _fetch_method = (_sn.metadata or {}).get("fetch_method", "unknown")
                                metadata = {
                                    "memory_ids": [mem_id],
                                    "source_id": _sn.id,
                                    "source_type": "url",
                                    "original_name": _sn.original_name,
                                    "source_url": _ingested_urls[0] if _ingested_urls else "",
                                    "lifecycle_state": _sn.lifecycle_state,
                                    "chunk_count": _sn.chunk_count,
                                    "fetch_method": _fetch_method,
                                    "is_duplicate": False,
                                    "source": source,
                                    "input_type": "url_capture",
                                    "agent_message": clean_text,
                                    "user_input": content,
                                }
                                feed_event = {
                                    "id": event_id,
                                    "event_type": "url_captured",
                                    "severity": "info",
                                    "title": _sn.original_name or memory_title,
                                    "description": content,
                                    "metadata": json.dumps(metadata),
                                    "related_memory_ids": [mem_id],
                                    "resolved": False,
                                    "created_at": now.isoformat(),
                                }
                                _evt_type_label = "url_captured"
                                _persist_input_type = "url_capture"
                            else:
                                metadata = {
                                    "memory_ids": [mem_id],
                                    "source": source,
                                    "input_type": "capture",
                                    "agent_message": clean_text,
                                }
                                feed_event = {
                                    "id": event_id,
                                    "event_type": "memory_created",
                                    "severity": "info",
                                    "title": memory_title,
                                    "description": content,
                                    "metadata": json.dumps(metadata),
                                    "related_memory_ids": [mem_id],
                                    "resolved": False,
                                    "created_at": now.isoformat(),
                                }
                                _evt_type_label = "memory_created"
                                _persist_input_type = "capture"

                            if request.thread_id:
                                feed_event["thread_id"] = request.thread_id

                            if events_dir:
                                event_path = _get_time_partitioned_path(events_dir, now, "jsonl")
                                with open(event_path, "a", encoding="utf-8") as f:
                                    f.write(json.dumps(feed_event) + "\n")
                            log_data_change("feed_event_created", "feed", event_id,
                                            {"event_type": _evt_type_label, "input_type": _persist_input_type})

                            persist_result_event = {
                                "type": "persist_result",
                                "input_type": _persist_input_type,
                                "event_id": event_id,
                                "memory_ids": [mem_id],
                                "source_ids": _url_source_ids if _is_url_input else [],
                                "source_id": _url_source_ids[0] if _is_url_input and _url_source_ids else None,
                                "title": memory_title,
                                "feedItem": feed_event,
                            }
                            logger.info("SSE persisted capture",
                                        mem_id=mem_id,
                                        is_url=_is_url_input,
                                        event_type=_evt_type_label)

                            # Emit additional feed events for extra URLs (2nd, 3rd, ...)
                            if _is_url_input and len(_url_source_ids) > 1:
                                for extra_idx in range(1, len(_url_source_ids)):
                                    extra_sn = _url_source_nodes[extra_idx]
                                    extra_event_id = f"evt-{uuid.uuid4().hex[:12]}"
                                    extra_url = _ingested_urls[extra_idx] if extra_idx < len(_ingested_urls) else ""
                                    extra_meta = {
                                        "source_id": extra_sn.id,
                                        "source_type": "url",
                                        "original_name": extra_sn.original_name,
                                        "source_url": extra_url,
                                        "lifecycle_state": extra_sn.lifecycle_state,
                                        "chunk_count": extra_sn.chunk_count,
                                        "fetch_method": (extra_sn.metadata or {}).get("fetch_method", "unknown"),
                                        "is_duplicate": False,
                                        "source": source,
                                        "input_type": "url_capture",
                                        "url_index": extra_idx,
                                        "url_total": len(_url_source_ids),
                                    }
                                    extra_event = {
                                        "id": extra_event_id,
                                        "event_type": "url_captured",
                                        "severity": "info",
                                        "title": extra_sn.original_name or extra_url,
                                        "description": f"Fetched and processed {extra_url}",
                                        "metadata": json.dumps(extra_meta),
                                        "related_memory_ids": [],
                                        "resolved": False,
                                        "created_at": now.isoformat(),
                                    }
                                    if events_dir:
                                        event_path = _get_time_partitioned_path(events_dir, now, "jsonl")
                                        with open(event_path, "a", encoding="utf-8") as f:
                                            f.write(json.dumps(extra_event) + "\n")
                                    log_data_change("source_created", "source", extra_sn.id,
                                                    {"source_type": "url", "url": extra_url})

                    elif input_type == "url":
                        # URL without usable pre-ingested source: record failure event only.
                        # Do NOT create memory from failed/unknown URL fetches.
                        memory_title = title or f"URL: {content[:70]}"
                        fallback_urls = _detected_urls or _extract_urls(content)
                        failure_reason = (
                            _url_ingest_failures[0]["reason"]
                            if _url_ingest_failures
                            else "no_usable_attached_source"
                        )
                        fallback_meta = {
                            "urls": fallback_urls,
                            "memory_ids": [],
                            "source": source,
                            "input_type": "url_capture",
                            "agent_message": clean_text,
                            "user_input": content,
                            "fallback": True,
                            "capture_failed": True,
                            "failure_reason": failure_reason,
                        }
                        feed_event = {
                            "id": event_id,
                            "event_type": "url_captured",
                            "severity": "warning",
                            "title": memory_title,
                            "description": content,
                            "metadata": json.dumps(fallback_meta),
                            "related_memory_ids": [],
                            "resolved": False,
                            "created_at": now.isoformat(),
                        }
                        if request.thread_id:
                            feed_event["thread_id"] = request.thread_id
                        if events_dir:
                            event_path = _get_time_partitioned_path(events_dir, now, "jsonl")
                            with open(event_path, "a", encoding="utf-8") as f:
                                f.write(json.dumps(feed_event) + "\n")
                        log_data_change("feed_event_created", "feed", event_id,
                                        {"event_type": "url_captured", "input_type": "url_capture", "fallback": True})
                        persist_result_event = {
                            "type": "persist_result",
                            "input_type": "url_capture",
                            "event_id": event_id,
                            "memory_ids": [],
                            "title": memory_title,
                            "feedItem": feed_event,
                        }
                        logger.info(
                            "SSE persisted URL failure event (no memory created)",
                            reason=failure_reason,
                            detected_urls=fallback_urls,
                        )

                    elif input_type == "question" or input_type is None:
                        # Questions and unclassified → feed event only, no memory
                        metadata = {
                            "question": content,
                            "agent_message": clean_text,
                            "source": source,
                            "input_type": "question",
                        }
                        # Persist enriched tool calls with result data for rich rendering
                        if tool_call_map:
                            metadata["tool_calls"] = list(tool_call_map.values())
                        elif tool_calls:
                            metadata["tool_calls"] = tool_calls

                        feed_event = {
                            "id": event_id,
                            "event_type": "user_question",
                            "severity": "info",
                            "title": content[:100],
                            "description": clean_text[:500] if clean_text else content[:500],
                            "metadata": json.dumps(metadata),
                            "related_memory_ids": discovered_memory_ids,
                            "resolved": False,
                            "created_at": now.isoformat(),
                        }
                        if request.thread_id:
                            feed_event["thread_id"] = request.thread_id

                        if events_dir:
                            event_path = _get_time_partitioned_path(events_dir, now, "jsonl")
                            with open(event_path, "a", encoding="utf-8") as f:
                                f.write(json.dumps(feed_event) + "\n")
                        log_data_change("feed_event_created", "feed", event_id,
                                        {"event_type": "user_question", "input_type": "question"})

                        persist_result_event = {
                            "type": "persist_result",
                            "input_type": "question",
                            "event_id": event_id,
                            "memory_ids": [],
                            "title": content[:100],
                            "feedItem": feed_event,
                            "discoveredMemoryIds": discovered_memory_ids,
                        }
                        logger.info("SSE persisted question", event_id=event_id)

                except Exception as persist_err:
                    logger.error("SSE persist failed", error=str(persist_err))
                    persist_result_event = {
                        "type": "persist_result",
                        "error": str(persist_err),
                    }

            # Emit persist_result before turn_end so frontend can process it
            if persist_result_event:
                yield f"data: {json.dumps(persist_result_event)}\n\n"

            # Send synthetic turn_end after stream completes
            yield f"data: {json.dumps({'type': 'turn_end'})}\n\n"
        except Exception as e:
            logger.error("Feed streaming failed", error=str(e))
            yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"

            # Persist error as feed event so the user can see what happened
            try:
                error_event_id = f"evt-{uuid.uuid4().hex[:12]}"
                error_event = {
                    "id": error_event_id,
                    "event_type": "agent_error",
                    "severity": "warning",
                    "title": f"Agent error: {str(e)[:80]}",
                    "description": content[:200],
                    "metadata": json.dumps({
                        "error": str(e),
                        "input_preview": content[:200],
                        "source": request.source,
                    }),
                    "resolved": False,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                }
                err_events_dir = _get_events_dir()
                if err_events_dir:
                    err_path = _get_time_partitioned_path(err_events_dir, datetime.now(timezone.utc), "jsonl")
                    with open(err_path, "a", encoding="utf-8") as f:
                        f.write(json.dumps(error_event) + "\n")
                    log_data_change("feed_event_created", "feed", error_event_id, {"event_type": "agent_error"})
            except Exception:
                pass  # Best-effort — don't fail the error handler

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",  # Disable nginx buffering
        },
    )
