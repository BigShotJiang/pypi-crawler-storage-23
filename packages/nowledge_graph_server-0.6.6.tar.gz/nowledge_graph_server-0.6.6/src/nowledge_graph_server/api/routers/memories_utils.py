def generate_enhanced_search_reasoning(
    query: str,
    total_found: int,
    filters_count: int,
    search_context: dict,
    graph_traversal: dict,
) -> str:
    """Generate intelligent, detailed search reasoning for users."""
    if not query:
        return f"Browsed {total_found} memories using intelligent ranking algorithms."

    # Extract intelligence from search context
    intent = (
        search_context.get("refined_intent", "conceptual_question")
        if search_context
        else "conceptual_question"
    )
    weights = search_context.get("weights", {}) if search_context else {}
    key_terms = search_context.get("key_terms", []) if search_context else []
    is_question = search_context.get("is_question", False) if search_context else False

    # Intent-based reasoning templates
    intent_explanations = {
        "concept_lookup": f"Concept Search: Detected '{query}' as a concept lookup. Prioritized entity relationships ({weights.get('entity', 0.3):.0%} weight) and semantic understanding ({weights.get('vector', 0.6):.0%} weight) to find comprehensive information about this topic.",
        "factual_query": f"Factual Query: Identified '{query}' as seeking specific facts. Emphasized exact text matching ({weights.get('fts', 0.4):.0%} weight) and entity lookup ({weights.get('entity', 0.3):.0%} weight) to locate precise information.",
        "conceptual_question": f"Conceptual Question: Recognized '{query}' as exploring ideas and understanding. Leveraged semantic analysis ({weights.get('vector', 0.6):.0%} weight) and community knowledge ({weights.get('community', 0.2):.0%} weight) for comprehensive insights.",
        "exploratory_search": f"Exploratory Search: Detected broad exploration intent in '{query}'. Balanced community insights ({weights.get('community', 0.2):.0%} weight), semantic similarity ({weights.get('vector', 0.6):.0%} weight), and entity connections for comprehensive discovery.",
        "relationship_query": f"Relationship Query: Identified '{query}' as seeking connections. Prioritized entity relationships ({weights.get('entity', 0.3):.0%} weight) and community analysis ({weights.get('community', 0.2):.0%} weight) to map relevant associations.",
    }

    base_explanation = intent_explanations.get(
        intent,
        f"🤖 **Intelligent Search**: Applied multi-strategy analysis to '{query}' using semantic understanding and graph relationships.",
    )

    # Add graph traversal insights
    graph_insights = []
    if graph_traversal.get("entities_traversed", 0) > 0:
        graph_insights.append(
            f"analyzed {graph_traversal['entities_traversed']} entities"
        )
    if graph_traversal.get("relationships_traversed", 0) > 0:
        graph_insights.append(
            f"traversed {graph_traversal['relationships_traversed']} relationships"
        )
    if graph_traversal.get("communities_analyzed", 0) > 0:
        graph_insights.append(
            f"explored {graph_traversal['communities_analyzed']} knowledge communities"
        )

    # Add key terms extraction
    terms_insight = ""
    if key_terms:
        terms_insight = f" Extracted key terms: {', '.join(key_terms)}."

    # Add filter context
    filter_insight = ""
    if filters_count > 0:
        filter_insight = f" Applied {filters_count} precision filter{'s' if filters_count > 1 else ''} for targeted results."

    # Combine insights
    graph_insight = (
        f" Graph analysis: {', '.join(graph_insights)}." if graph_insights else ""
    )

    return f"{base_explanation}{terms_insight}{graph_insight}{filter_insight} Found {total_found} relevant memories through this intelligent multi-dimensional search."


def build_search_intelligence_metadata(search_context: dict) -> dict:
    """Build detailed search intelligence metadata for UI display."""
    if not search_context:
        return {}

    metadata = {
        "intent_analysis": {
            "detected_intent": search_context.get("intent", "unknown"),
            "refined_intent": search_context.get("refined_intent", "unknown"),
            "is_question": search_context.get("is_question", False),
            "specificity": search_context.get("specificity", "unknown"),
            "key_terms": search_context.get("key_terms", []),
            "confidence": search_context.get("confidence", None),
        },
        "strategy_weights": search_context.get("weights", {}),
        "advanced_features": search_context.get("advanced", {}),
        "llm_analysis": {
            "performed": True,
            "extracted_entities": search_context.get("advanced", {}).get(
                "potential_labels", []
            ),
            "hyde_enabled": search_context.get("advanced", {}).get("use_hyde", False),
            "label_search_enabled": search_context.get("advanced", {}).get(
                "label_search_enabled", False
            ),
        },
        "search_explanation": {
            "primary_strategy": _get_primary_strategy(
                search_context.get("weights", {})
            ),
            "strategy_reasoning": _explain_strategy_selection(search_context),
            "intelligence_level": "advanced_multi_modal",
        },
    }

    # Include temporal intent analysis (deep mode only)
    temporal_intent = search_context.get("temporal_intent")
    if temporal_intent:
        metadata["temporal_intent"] = temporal_intent

    # Attach LLM provider usage if available on context
    llm_usage = search_context.get("llm_usage")
    if isinstance(llm_usage, dict):
        metadata["llm_usage"] = llm_usage

    return metadata


def _get_primary_strategy(weights: dict) -> str:
    """Determine the primary search strategy based on weights."""
    if not weights:
        return "balanced_hybrid"

    max_weight = max(weights.values()) if weights else 0
    primary_strategies = [k for k, v in weights.items() if v == max_weight]

    strategy_names = {
        "vector": "semantic_similarity",
        "fts": "exact_text_matching",
        "entity": "entity_relationship",
        "community": "community_knowledge",
    }

    return (
        strategy_names.get(primary_strategies[0], "balanced_hybrid")
        if primary_strategies
        else "balanced_hybrid"
    )


def _explain_strategy_selection(search_context: dict) -> str:
    """Explain why specific strategies were selected."""
    intent = search_context.get("refined_intent", "unknown")
    weights = search_context.get("weights", {})

    explanations = {
        "concept_lookup": "Entity-focused search for comprehensive concept understanding",
        "factual_query": "Text-matching prioritized for precise fact retrieval",
        "conceptual_question": "Semantic analysis emphasized for deep conceptual insights",
        "exploratory_search": "Community knowledge leveraged for broad discovery",
        "relationship_query": "Graph traversal optimized for connection mapping",
    }

    base_explanation = explanations.get(intent, "Multi-modal intelligent search")

    # Add weight distribution insight
    if weights:
        top_strategy = max(weights.items(), key=lambda x: x[1])
        weight_insight = (
            f" (Primary: {top_strategy[0]} at {top_strategy[1]:.0%} weight)"
        )
        return base_explanation + weight_insight

    return base_explanation
