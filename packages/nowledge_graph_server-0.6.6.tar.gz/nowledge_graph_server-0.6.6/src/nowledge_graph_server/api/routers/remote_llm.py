"""
API endpoints for remote LLM configuration and management.
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List, Literal
import structlog
from datetime import datetime
from nowledge_graph_server.services.remote_llm_config import (
    get_config_manager,
    RemoteLLMConfig,
)
from nowledge_graph_server.services.secure_keys import get_encryption_key_bytes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import base64
import os
from pathlib import Path
from nowledge_graph_server.services.litellm_provider import (
    test_connection,  # type: ignore[misc]
    list_models,  # type: ignore[misc]
    test_connection_with_config,  # type: ignore[misc]
    list_models_with_config,  # type: ignore[misc]
)
from nowledge_graph_server.utils.llm_availability import check_llm_availability

logger = structlog.get_logger(__name__)

router = APIRouter()


async def _fetch_openrouter_models(
    *,
    api_base: Optional[str],
    api_key: Optional[str],
) -> List[Dict[str, Any]]:
    """Fetch OpenRouter model entries (best-effort)."""
    import httpx

    base = (api_base or "https://openrouter.ai/api/v1").rstrip("/")
    headers: Dict[str, str] = {
        "HTTP-Referer": "https://mem.nowledge.co",
        "X-Title": "Nowledge Mem",
    }
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    async with httpx.AsyncClient(timeout=8.0) as client:
        resp = await client.get(f"{base}/models", headers=headers)
        if resp.status_code != 200:
            return []
        payload = resp.json() if resp.text else {}
        items = []
        if isinstance(payload, dict):
            items = payload.get("data") or payload.get("models") or []
        return [it for it in items if isinstance(it, dict)]


def _canonicalize_openrouter_model_id(
    model_id: str, model_items: List[Dict[str, Any]]
) -> str:
    """Normalize OpenRouter model id to canonical provider-qualified form when possible."""
    raw = (model_id or "").strip()
    if not raw:
        return raw
    had_openrouter_prefix = raw.lower().startswith("openrouter/")
    needle = raw[len("openrouter/") :] if had_openrouter_prefix else raw
    ids = [str(it.get("id") or it.get("name") or "").strip() for it in model_items]
    ids = [i for i in ids if i]
    if not ids:
        # No catalog data => preserve original input to avoid accidental rewrites.
        return raw

    # Exact match first.
    if needle in ids:
        return needle

    # Case-insensitive exact match.
    lower_to_ids: Dict[str, List[str]] = {}
    for mid in ids:
        lower_to_ids.setdefault(mid.lower(), []).append(mid)
    ci = lower_to_ids.get(needle.lower(), [])
    if len(ci) == 1:
        return ci[0]

    # If unqualified, try unique suffix match: e.g. minimax-m2.5 -> minimax/minimax-m2.5.
    if "/" not in needle:
        suffix = f"/{needle.lower()}"
        suffix_hits = [mid for mid in ids if mid.lower().endswith(suffix)]
        if len(suffix_hits) == 1:
            return suffix_hits[0]

    # If we started with "openrouter/" and couldn't confidently map, preserve original.
    if had_openrouter_prefix:
        return raw
    return needle


def _is_deepseek_reasoner_model(model: Optional[str]) -> bool:
    m = (model or "").strip().lower()
    return m in {"deepseek-reasoner", "deepseek/deepseek-reasoner"} or m.endswith("/deepseek-reasoner")


def _is_deepseek_transport(provider_type: Optional[str], api_base: Optional[str]) -> bool:
    p = (provider_type or "").strip().lower()
    if p == "deepseek":
        return True
    if p == "openai_compatible" or p.startswith("openai_compatible:"):
        return "api.deepseek.com" in (api_base or "").strip().lower()
    return False


class RemoteLLMConfigRequest(BaseModel):
    """Request to update remote LLM configuration."""

    enabled: bool
    # provider id (built-ins use their type as id; instances use unique ids)
    provider: str
    # optional provider type (required for multi-instance providers like openai_compatible)
    provider_type: Optional[str] = None
    display_name: Optional[str] = None
    model: str
    api_key: Optional[str] = None
    api_base: Optional[str] = None
    api_version: Optional[str] = None
    extra_params: Dict[str, Any] = Field(default_factory=dict)
    temperature: float = 0.7
    max_tokens: int = 8192
    timeout: float = 60.0


class RemoteLLMConfigResponse(BaseModel):
    """Response with remote LLM configuration."""

    enabled: bool
    provider: str
    model: str
    has_api_key: bool
    api_base: Optional[str]
    api_version: Optional[str]
    temperature: float
    max_tokens: int
    timeout: float
    last_updated: Optional[str]
    last_test_success: Optional[str]
    # Multi-provider additions
    active_provider: Optional[str] = None
    providers: Optional[Dict[str, Dict[str, Any]]] = None
    purposes: Optional[Dict[str, Dict[str, Any]]] = None


class ProviderActivationRequest(BaseModel):
    provider: str


class PurposeSelectionRequest(BaseModel):
    purpose: Literal["default", "ai_now"]
    provider: Optional[str] = None
    model: Optional[str] = None


class ProviderRemoveRequest(BaseModel):
    provider: str


class ProviderCloneRequest(BaseModel):
    source_provider: str
    new_provider: str
    model: Optional[str] = None
    display_name: Optional[str] = None


class TestConnectionResponse(BaseModel):
    """Response from connection test."""

    success: bool
    message: str
    provider: Optional[str] = None
    model: Optional[str] = None
    test_response: Optional[str] = None


class ListModelsResponse(BaseModel):
    """Response with available models."""

    success: bool
    provider: str
    models: List[str]
    note: Optional[str] = None
    message: Optional[str] = None


class LLMAvailabilityResponse(BaseModel):
    """Response with LLM availability status."""

    available: bool
    error_message: str = ""


class LLMCredentialsResponse(BaseModel):
    """Response with LLM credentials for extension to call LLM directly.
    
    Credentials are encrypted using AES-GCM before transmission.
    The extension must decrypt api_key_encrypted using api_key_nonce.
    """

    success: bool
    provider: Optional[str] = None
    provider_type: Optional[str] = None
    model: Optional[str] = None
    # Encrypted API key (base64-encoded ciphertext)
    api_key_encrypted: Optional[str] = None
    # Nonce used for encryption (base64-encoded, 12 bytes)
    api_key_nonce: Optional[str] = None
    api_base: Optional[str] = None
    error: Optional[str] = None


class LLMStatusResponse(BaseModel):
    """Simple status response for browser extension to check if LLM is configured."""

    configured: bool
    provider: Optional[str] = None
    model: Optional[str] = None
    error: Optional[str] = None


@router.get(
    "/remote-llm/config",
    response_model=RemoteLLMConfigResponse,
    include_in_schema=False,
)
async def get_remote_llm_config():
    """Get current remote LLM configuration."""
    try:
        config_manager = get_config_manager()
        config = config_manager.get_config()
        # Active provider id (default purpose)
        active_provider_id = config_manager.get_active_provider() or config.provider
        active_cfg = None
        try:
            active_cfg = config_manager.get_all_provider_configs().get(active_provider_id)
        except Exception:
            active_cfg = None
        active_provider_type = (
            (active_cfg.provider_type if active_cfg else None) or (config.provider_type or "") or (config.provider or "")
        ).strip()
        # Copilot / Codex auth is stored as token files, not api_key in config.
        top_has_key = bool(config.api_key)
        if active_provider_type == "github_copilot":
            try:
                token_dir = config_manager.config_path.parent / "github_copilot"
                token_file = token_dir / "access-token"
                top_has_key = token_file.exists() and token_file.read_text().strip() != ""
            except Exception:
                pass
        elif active_provider_type == "openai_codex":
            try:
                import json as _json
                token_dir = config_manager.config_path.parent / "openai_codex"
                token_file = token_dir / "access-token.json"
                if token_file.exists():
                    data = _json.loads(token_file.read_text())
                    top_has_key = bool(data.get("access_token", "").strip())
                else:
                    top_has_key = False
            except Exception:
                pass
        # Build providers map summary
        providers_map: Dict[str, Dict[str, Any]] = {}
        try:
            all_cfgs = config_manager.get_all_provider_configs()
            for name, cfg in all_cfgs.items():
                # For GitHub Copilot, auth is via OAuth device flow and tokens are stored locally.
                # Reflect "authenticated" status by checking the token cache under app data dir.
                provider_type = (cfg.provider_type or name).strip()
                has_key = bool(cfg.api_key)
                if provider_type == "github_copilot":
                    try:
                        token_dir = config_manager.config_path.parent / "github_copilot"
                        token_file = token_dir / "access-token"
                        has_key = token_file.exists() and token_file.read_text().strip() != ""
                    except Exception:
                        pass
                elif provider_type == "openai_codex":
                    try:
                        import json as _json
                        token_dir = config_manager.config_path.parent / "openai_codex"
                        token_file = token_dir / "access-token.json"
                        if token_file.exists():
                            data = _json.loads(token_file.read_text())
                            has_key = bool(data.get("access_token", "").strip())
                        else:
                            has_key = False
                    except Exception:
                        pass
                providers_map[name] = {
                    "provider": cfg.provider,  # provider_id
                    "provider_type": cfg.provider_type or name,
                    "display_name": cfg.display_name,
                    "model": cfg.model,
                    "has_api_key": has_key,
                    "api_base": None if provider_type in ("github_copilot", "openai_codex") else cfg.api_base,
                    "api_version": cfg.api_version,
                    "last_updated": cfg.last_updated,
                }
        except Exception:
            providers_map = {}

        # Purposes (effective selection included for UI convenience)
        purposes: Dict[str, Dict[str, Any]] = {}
        try:
            for p in ["default", "ai_now"]:
                raw = config_manager.get_purpose_selection(p)  # type: ignore[arg-type]
                eff = config_manager.get_effective_purpose(p)  # type: ignore[arg-type]
                purposes[p] = {
                    "provider": raw.get("provider"),
                    "model": raw.get("model"),
                    "effective_provider": eff.get("provider"),
                    "effective_model": eff.get("model"),
                    "uses_default": p == "ai_now" and not (raw.get("provider") or raw.get("model")),
                }
        except Exception:
            purposes = {}

        return RemoteLLMConfigResponse(
            enabled=config.enabled,
            provider=active_provider_id,
            model=config.model,
            has_api_key=top_has_key,
            api_base=None if active_provider_type in ("github_copilot", "openai_codex") else config.api_base,
            api_version=config.api_version,
            temperature=config.temperature,
            max_tokens=config.max_tokens,
            timeout=config.timeout,
            last_updated=config.last_updated,
            last_test_success=config.last_test_success,
            active_provider=active_provider_id,
            providers=providers_map or None,
            purposes=purposes or None,
        )
    except Exception as e:
        logger.error("Failed to get remote LLM config", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/remote-llm/config",
    response_model=RemoteLLMConfigResponse,
    include_in_schema=False,
)
async def update_remote_llm_config(request: RemoteLLMConfigRequest):
    """Update remote LLM configuration."""
    try:
        config_manager = get_config_manager()
        existing = config_manager.get_config()

        # Get the TARGET provider's existing config (not the currently active one!)
        # This ensures we don't leak the active provider's key to other providers
        target_provider_name = request.provider or existing.provider
        all_providers = config_manager.get_all_provider_configs()
        target_existing = all_providers.get(target_provider_name)

        # GitHub Copilot / OpenAI Codex "disconnect" (forget OAuth tokens) without needing a new API surface.
        # The UI can call updateConfig() with extra_params: { disconnect: true }.
        disconnect_requested = False
        try:
            if (
                target_provider_name in ("github_copilot", "openai_codex")
                and isinstance(request.extra_params, dict)
                and bool(request.extra_params.get("disconnect"))
            ):
                disconnect_requested = True
        except Exception:
            disconnect_requested = False

        if disconnect_requested:
            try:
                token_dir = config_manager.config_path.parent / target_provider_name
                # Remove the entire token cache dir contents to guarantee a clean re-auth.
                # (Token file names can vary by env; wiping the directory is safest.)
                try:
                    import shutil

                    if token_dir.exists():
                        shutil.rmtree(token_dir, ignore_errors=True)
                    token_dir.mkdir(parents=True, exist_ok=True)
                except Exception as e:
                    # Fallback: best-effort delete known files
                    known_files = (
                        ["access-token", "api-key.json", "device-code.json"]
                        if target_provider_name == "github_copilot"
                        else ["access-token.json", "device-code.json"]
                    )
                    logger.warning(
                        f"Failed to wipe {target_provider_name} token dir; falling back to file deletes",
                        error=str(e),
                        token_dir=str(token_dir),
                    )
                    for name in known_files:
                        try:
                            p = token_dir / name
                            if p.exists():
                                p.unlink()
                        except Exception:
                            pass
                logger.info(f"{target_provider_name} disconnected", token_dir=str(token_dir))
            except Exception as e:
                logger.warning(f"Failed to disconnect {target_provider_name}", error=str(e))

        # Merge with existing to avoid unintentionally wiping secrets/fields on partial updates
        merged_extra = {
            **(
                target_existing.extra_params
                if target_existing
                else existing.extra_params or {}
            ),
            **(request.extra_params or {}),
        }
        # Do not persist the one-shot disconnect flag.
        merged_extra.pop("disconnect", None)
        # NOTE: `no_activate` is a one-shot flag, stripped inside the config manager
        # after it influences activation behavior.

        # Canonicalize OpenRouter model IDs to provider-qualified names when possible.
        resolved_model_to_save = (
            request.model
            or (target_existing.model if target_existing else existing.model)
        )
        resolved_provider_type = (
            request.provider_type
            or (target_existing.provider_type if target_existing else None)
            or target_provider_name
            or ""
        ).strip().lower()
        if (
            resolved_provider_type == "openrouter"
            and isinstance(resolved_model_to_save, str)
            and resolved_model_to_save.strip()
        ):
            try:
                or_models = await _fetch_openrouter_models(
                    api_base=(
                        request.api_base
                        if request.api_base is not None
                        else (target_existing.api_base if target_existing else existing.api_base)
                    ),
                    api_key=(
                        request.api_key
                        if (request.api_key is not None and request.api_key != "")
                        else (target_existing.api_key if target_existing else None)
                    ),
                )
                canonical_model = _canonicalize_openrouter_model_id(
                    str(resolved_model_to_save), or_models
                )
                if canonical_model and canonical_model != resolved_model_to_save:
                    logger.info(
                        "Canonicalized OpenRouter model id on save",
                        original=resolved_model_to_save,
                        canonical=canonical_model,
                    )
                    resolved_model_to_save = canonical_model
            except Exception as e:
                logger.warning(
                    "OpenRouter model canonicalization skipped on config save",
                    model=resolved_model_to_save,
                    error=str(e),
                )

        new_config = RemoteLLMConfig(
            enabled=request.enabled,
            provider=target_provider_name,
            provider_type=request.provider_type,
            display_name=request.display_name,
            model=resolved_model_to_save,
            api_key=(
                request.api_key
                if (request.api_key is not None and request.api_key != "")
                else (target_existing.api_key if target_existing else None)
            ),
            api_base=request.api_base
            if request.api_base is not None
            else (target_existing.api_base if target_existing else existing.api_base),
            api_version=request.api_version
            if request.api_version is not None
            else (
                target_existing.api_version if target_existing else existing.api_version
            ),
            extra_params=merged_extra,
            temperature=request.temperature
            if request.temperature is not None  # type: ignore[comparison-overlap]
            else (
                target_existing.temperature if target_existing else existing.temperature
            ),
            max_tokens=request.max_tokens
            if request.max_tokens is not None  # type: ignore[comparison-overlap]
            else (
                target_existing.max_tokens if target_existing else existing.max_tokens
            ),
            timeout=request.timeout
            if request.timeout is not None  # type: ignore[comparison-overlap]
            else (target_existing.timeout if target_existing else existing.timeout),
        )

        # Update and save
        config_manager.update_config(new_config)

        logger.info(
            "Remote LLM config updated",
            enabled=new_config.enabled,
            provider=new_config.provider,
            model=new_config.model,
        )

        # Return updated config
        # Reuse get handler logic for providers map
        return await get_remote_llm_config()
    except Exception as e:
        logger.error("Failed to update remote LLM config", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/remote-llm/test", response_model=TestConnectionResponse, include_in_schema=False
)
async def test_remote_llm_connection():
    """Test connection to the configured remote LLM."""
    try:
        result = await test_connection()  # type: ignore[assignment]
        return TestConnectionResponse(**result)  # type: ignore[arg-type]
    except Exception as e:
        logger.error("Connection test failed", error=str(e))
        return TestConnectionResponse(success=False, message=f"Test failed: {str(e)}")


@router.get(
    "/remote-llm/models", response_model=ListModelsResponse, include_in_schema=False
)
async def list_remote_llm_models(provider: Optional[str] = None):
    """List available models for a provider.

    Args:
        provider: Optional provider name. If not specified, uses configured provider.
    """
    try:
        result = await list_models(provider)  # type: ignore[assignment]
        return ListModelsResponse(**result)  # type: ignore[arg-type]
    except Exception as e:
        logger.error("Failed to list models", error=str(e))
        return ListModelsResponse(
            success=False,
            provider=provider or "unknown",
            models=[],
            message=f"Failed to list models: {str(e)}",
        )


# Test connection with transient UI config (test-before-save)
@router.post(
    "/remote-llm/test/with-config",
    response_model=TestConnectionResponse,
    include_in_schema=False,
)
async def test_remote_llm_connection_with_config(request: RemoteLLMConfigRequest):
    try:
        logger.info(
            "TEST_WITH_CONFIG_REQUEST",
            enabled=request.enabled,
            provider=request.provider,
            api_base=request.api_base,
            has_key=bool(request.api_key),
        )
        temp_config = RemoteLLMConfig(
            enabled=request.enabled,
            provider=request.provider,
            model=request.model,
            api_key=request.api_key,
            api_base=request.api_base,
            api_version=request.api_version,
            extra_params=request.extra_params,
            temperature=request.temperature,
            max_tokens=request.max_tokens,
            timeout=request.timeout,
            last_updated=datetime.now().isoformat(),
            last_test_success=datetime.now().isoformat(),
        )
        result = await test_connection_with_config(temp_config)  # type: ignore[assignment]
        logger.info("TEST_WITH_CONFIG_RESULT", **result)
        return TestConnectionResponse(**result)  # type: ignore[arg-type]
    except Exception as e:
        logger.error("Connection test-with-config failed", error=str(e))
        return TestConnectionResponse(success=False, message=f"Test failed: {str(e)}")


# List models with transient UI config (list-before-save)
@router.post(
    "/remote-llm/models/with-config",
    response_model=ListModelsResponse,
    include_in_schema=False,
)
async def list_remote_llm_models_with_config(
    request: RemoteLLMConfigRequest, provider: Optional[str] = None
):
    try:
        logger.info(
            "LIST_WITH_CONFIG_REQUEST",
            enabled=request.enabled,
            provider=provider or request.provider,
            api_base=request.api_base,
            has_key=bool(request.api_key),
        )
        temp_config = RemoteLLMConfig(
            enabled=request.enabled,
            provider=request.provider,
            model=request.model,
            api_key=request.api_key,
            api_base=request.api_base,
            api_version=request.api_version,
            extra_params=request.extra_params,
            temperature=request.temperature,
            max_tokens=request.max_tokens,
            timeout=request.timeout,
            last_updated=datetime.now().isoformat(),
            last_test_success=datetime.now().isoformat(),
        )
        result = await list_models_with_config(temp_config, provider)  # type: ignore[assignment]
        logger.info("LIST_WITH_CONFIG_RESULT", **result)
        return ListModelsResponse(**result)  # type: ignore[arg-type]
    except Exception as e:
        logger.error("List models-with-config failed", error=str(e))
        return ListModelsResponse(
            success=False,
            provider=provider or request.provider,
            models=[],
            message=str(e),
        )


@router.post(
    "/remote-llm/activate",
    response_model=RemoteLLMConfigResponse,
    include_in_schema=False,
)
async def activate_remote_llm_provider(request: ProviderActivationRequest):
    try:
        config_manager = get_config_manager()
        config_manager.set_active_provider(request.provider)
        logger.info("Active remote LLM provider set", provider=request.provider)
        # Return fresh config after reload
        return await get_remote_llm_config()
    except Exception as e:
        logger.error("Failed to activate provider", error=str(e))
        raise HTTPException(status_code=400, detail=str(e))


@router.post(
    "/remote-llm/purpose",
    response_model=RemoteLLMConfigResponse,
    include_in_schema=False,
)
async def set_remote_llm_purpose(request: PurposeSelectionRequest):
    """Set purpose-specific provider/model selection (default vs ai_now).

    - purpose=default requires provider and updates the default active selection.
    - purpose=ai_now can omit provider/model to inherit default.
    """
    try:
        config_manager = get_config_manager()
        if (
            request.purpose == "ai_now"
            and request.provider
            and request.model
        ):
            try:
                all_cfgs = config_manager.get_all_provider_configs()
                target_cfg = all_cfgs.get(request.provider)
                target_provider_type = (
                    (target_cfg.provider_type if target_cfg else None)
                    or request.provider
                )
                target_api_base = target_cfg.api_base if target_cfg else None
                if _is_deepseek_transport(target_provider_type, target_api_base) and _is_deepseek_reasoner_model(request.model):
                    raise HTTPException(
                        status_code=400,
                        detail=(
                            "deepseek-reasoner does not support tool use (`tools` / `tool_choice`). "
                            "Agents require tool-calling models. Please choose deepseek-chat."
                        ),
                    )
                if (target_provider_type or "").strip().lower() == "openrouter":
                    items = await _fetch_openrouter_models(
                        api_base=(target_cfg.api_base if target_cfg else None),
                        api_key=(target_cfg.api_key if target_cfg else None),
                    )
                    canonical_model = _canonicalize_openrouter_model_id(
                        str(request.model), items
                    )
                    if canonical_model and canonical_model != request.model:
                        logger.info(
                            "Canonicalized OpenRouter purpose model id",
                            original=request.model,
                            canonical=canonical_model,
                        )
                        request.model = canonical_model

                    matched = None
                    for item in items:
                        item_id = str(item.get("id") or item.get("name") or "").strip()
                        if item_id == (request.model or "").strip():
                            matched = item
                            break
                    if isinstance(matched, dict):
                        supported = matched.get("supported_parameters")
                        supports_tools = False
                        if isinstance(supported, list):
                            supports_tools = "tools" in supported or "tool_choice" in supported
                        elif isinstance(matched.get("tool_call"), bool):
                            supports_tools = bool(matched.get("tool_call"))
                        if not supports_tools:
                            raise HTTPException(
                                status_code=400,
                                detail=(
                                    f"Model '{request.model}' on OpenRouter does not support tool use. "
                                    "Agents require tool-calling models. "
                                    "Please choose another model."
                                ),
                            )
            except HTTPException:
                raise
            except Exception as e:
                logger.warning(
                    "OpenRouter tool support preflight skipped",
                    provider=request.provider,
                    model=request.model,
                    error=str(e),
                )
        config_manager.set_purpose_selection(request.purpose, request.provider, request.model)  # type: ignore[arg-type]
        return await get_remote_llm_config()
    except Exception as e:
        logger.error("Failed to set remote LLM purpose", error=str(e))
        raise HTTPException(status_code=400, detail=str(e))


@router.post(
    "/remote-llm/provider/remove",
    response_model=RemoteLLMConfigResponse,
    include_in_schema=False,
)
async def remove_remote_llm_provider(request: ProviderRemoveRequest):
    """Remove a provider config by provider id."""
    try:
        config_manager = get_config_manager()
        config_manager.remove_provider(request.provider)
        return await get_remote_llm_config()
    except Exception as e:
        logger.error("Failed to remove remote LLM provider", error=str(e))
        raise HTTPException(status_code=400, detail=str(e))


@router.post(
    "/remote-llm/provider/clone",
    response_model=RemoteLLMConfigResponse,
    include_in_schema=False,
)
async def clone_remote_llm_provider(request: ProviderCloneRequest):
    """Clone an existing provider config to a new provider id (for model variants)."""
    try:
        config_manager = get_config_manager()
        config_manager.clone_provider(
            request.source_provider,
            request.new_provider,
            model=request.model,
            display_name=request.display_name,
        )
        return await get_remote_llm_config()
    except Exception as e:
        logger.error("Failed to clone remote LLM provider", error=str(e))
        raise HTTPException(status_code=400, detail=str(e))


@router.get(
    "/remote-llm/availability",
    response_model=LLMAvailabilityResponse,
    include_in_schema=False,
)
async def get_llm_availability():
    """Check if LLM is available (considering platform, config, and license tier)."""
    try:
        available, error_message = check_llm_availability()
        logger.info(
            "LLM availability check",
            available=available,
            error_message=error_message if error_message else None,
        )
        return LLMAvailabilityResponse(available=available, error_message=error_message)
    except Exception as e:
        logger.error("Failed to check LLM availability", error=str(e), exc_info=True)
        return LLMAvailabilityResponse(
            available=False, error_message=f"Failed to check LLM availability: {str(e)}"
        )


@router.get(
    "/remote-llm/credentials",
    response_model=LLMCredentialsResponse,
    include_in_schema=False,
)
async def get_llm_credentials(purpose: Literal["default", "ai_now"] = "default"):
    """Get LLM credentials for the browser extension to call LLM directly.

    The extension should use these credentials to make direct API calls
    to the LLM provider from within the browser.
    """
    try:
        config_manager = get_config_manager()
        config = config_manager.get_config()

        if not config.enabled:
            return LLMCredentialsResponse(
                success=False,
                error="Remote LLM is not enabled. Configure in Settings > Providers.",
            )

        # Resolve effective purpose selection (default or ai_now).
        effective = config_manager.get_effective_purpose(purpose)
        active_provider_id = (
            effective.get("provider")
            or config_manager.get_active_provider()
            or config.provider
        )
        all_cfgs = config_manager.get_all_provider_configs()
        active_cfg = all_cfgs.get(active_provider_id)

        provider_type = (
            (active_cfg.provider_type if active_cfg else None)
            or config.provider_type
            or config.provider
        )

        # Get model/api base/api key from the resolved provider config first.
        resolved_model = (
            effective.get("model")
            or (active_cfg.model if active_cfg else None)
            or config.model
        )
        resolved_api_base = (active_cfg.api_base if active_cfg else None) or config.api_base

        # Get API key - handle different providers
        api_key = config.api_key
        if active_cfg:
            api_key = active_cfg.api_key or api_key

        # For GitHub Copilot / OpenAI Codex, refresh tokens before use to ensure they're not expired
        api_base_for_copilot = None
        api_base_for_codex = None

        # OpenAI Codex: read access token from token file (auto-refreshes if expired)
        if provider_type == "openai_codex":
            try:
                from nowledge_graph_server.services.litellm.env import (
                    setup_openai_codex_env,
                    check_codex_authenticated,
                    get_codex_access_token,
                )

                token_dir = setup_openai_codex_env(config_manager.config_path.parent)
                if not token_dir:
                    return LLMCredentialsResponse(
                        success=False,
                        error="Failed to set up ChatGPT Subscription token directory.",
                    )

                if not check_codex_authenticated(token_dir):
                    return LLMCredentialsResponse(
                        success=False,
                        error="ChatGPT Subscription is not authenticated. Open Settings → Remote LLM → ChatGPT Subscription and click Authenticate.",
                    )

                codex_token = get_codex_access_token(token_dir)
                if not codex_token:
                    return LLMCredentialsResponse(
                        success=False,
                        error="ChatGPT Subscription access token is expired or invalid. Please re-authenticate in Settings.",
                    )

                api_key = codex_token
                api_base_for_codex = "https://chatgpt.com/backend-api/codex"
            except Exception as e:
                logger.error(
                    "Failed to read OpenAI Codex access token",
                    error=str(e),
                    exc_info=True,
                )
                return LLMCredentialsResponse(
                    success=False,
                    error=f"Failed to read ChatGPT Subscription credentials: {str(e)}",
                )

        if provider_type == "github_copilot":
            try:
                import json as _json
                from nowledge_graph_server.services.litellm.env import setup_github_copilot_env, check_copilot_authenticated
                
                # Save current env vars to restore later (avoid interfering with other parts of system)
                old_env_vars = {
                    "GITHUB_COPILOT_TOKEN_DIR": os.environ.get("GITHUB_COPILOT_TOKEN_DIR"),
                    "GITHUB_COPILOT_ACCESS_TOKEN_FILE": os.environ.get("GITHUB_COPILOT_ACCESS_TOKEN_FILE"),
                    "GITHUB_COPILOT_API_KEY_FILE": os.environ.get("GITHUB_COPILOT_API_KEY_FILE"),
                }
                
                try:
                    token_dir = setup_github_copilot_env(config_manager.config_path.parent)
                    if not token_dir:
                        return LLMCredentialsResponse(
                            success=False,
                            error="Failed to set up GitHub Copilot token directory.",
                        )
                    
                    api_key_file = Path(token_dir) / "api-key.json"
                    access_token_file = Path(token_dir) / "access-token"
                    
                    # Check if access token exists (required for refreshing API token)
                    if not check_copilot_authenticated(token_dir):
                        return LLMCredentialsResponse(
                            success=False,
                            error="GitHub Copilot is not authenticated. Open Settings → Remote LLM → GitHub Copilot and click Authenticate.",
                        )
                    
                    # Always refresh API token using LiteLLM's Authenticator (ensures fresh token)
                    # This matches the AI-Now agent behavior which refreshes before each use
                    # Note: setup_github_copilot_env sets up the required environment variables
                    try:
                        from litellm.llms.github_copilot.authenticator import Authenticator  # type: ignore
                        auth = Authenticator()
                        _ = auth.get_api_key()  # Refreshes and writes to api-key.json
                    except Exception as refresh_error:
                        logger.error(
                            "Failed to refresh GitHub Copilot API token",
                            error=str(refresh_error),
                            exc_info=True,
                        )
                        return LLMCredentialsResponse(
                            success=False,
                            error=f"Failed to refresh GitHub Copilot API token: {str(refresh_error)}",
                        )
                    
                    # Read fresh API token and endpoint from api-key.json
                    if api_key_file.exists():
                        with open(api_key_file, 'r', encoding='utf-8') as f:
                            api_key_info = _json.load(f) or {}
                        
                        # Get API token (not access token)
                        api_key = api_key_info.get('token') if isinstance(api_key_info, dict) else None
                        if isinstance(api_key, str):
                            api_key = api_key.strip()
                        
                        # Get API endpoint from token cache
                        endpoints = api_key_info.get('endpoints') if isinstance(api_key_info, dict) else None
                        if isinstance(endpoints, dict):
                            api_base_for_copilot = endpoints.get('api')
                        
                        if not api_key:
                            return LLMCredentialsResponse(
                                success=False,
                                error="GitHub Copilot API token is missing. Please re-authenticate in Settings.",
                            )
                    else:
                        return LLMCredentialsResponse(
                            success=False,
                            error="GitHub Copilot API token file not found. Please re-authenticate in Settings.",
                        )
                finally:
                    # Restore original environment variables to avoid interfering with other parts of system
                    for key, value in old_env_vars.items():
                        if value is None:
                            os.environ.pop(key, None)
                        else:
                            os.environ[key] = value
            except Exception as e:
                logger.error(
                    "Failed to read GitHub Copilot API token",
                    error=str(e),
                    exc_info=True,
                )
                # Restore env vars even on error
                for key, value in old_env_vars.items():
                    if value is None:
                        os.environ.pop(key, None)
                    else:
                        os.environ[key] = value
                return LLMCredentialsResponse(
                    success=False,
                    error=f"Failed to read GitHub Copilot credentials: {str(e)}",
                )

        # Runtime safety: canonicalize OpenRouter model IDs for stale pre-fix configs.
        if (
            (provider_type or "").strip().lower() == "openrouter"
            and isinstance(resolved_model, str)
            and resolved_model.strip()
        ):
            try:
                items = await _fetch_openrouter_models(
                    api_base=resolved_api_base,
                    api_key=api_key,
                )
                canonical_model = _canonicalize_openrouter_model_id(
                    str(resolved_model), items
                )
                if canonical_model and canonical_model != resolved_model:
                    logger.info(
                        "Canonicalized OpenRouter model id for credentials response",
                        original=resolved_model,
                        canonical=canonical_model,
                        purpose=purpose,
                    )
                    resolved_model = canonical_model
            except Exception as e:
                logger.warning(
                    "OpenRouter model canonicalization skipped for credentials response",
                    model=resolved_model,
                    purpose=purpose,
                    error=str(e),
                )

        # Runtime safety: AI-Now/agents require tool-capable models.
        # DeepSeek's `deepseek-reasoner` currently does not support tool use.
        if (
            purpose == "ai_now"
            and _is_deepseek_transport(provider_type, resolved_api_base)
            and _is_deepseek_reasoner_model(resolved_model)
        ):
            return LLMCredentialsResponse(
                success=False,
                provider=active_provider_id,
                provider_type=provider_type,
                model=resolved_model,
                api_base=resolved_api_base,
                error=(
                    "Configured model deepseek-reasoner does not support tool use (`tools` / `tool_choice`). "
                    "Switch to deepseek-chat for AI-Now/agent workflows."
                ),
            )

        # Encrypt API key before sending to extension
        api_key_encrypted = None
        api_key_nonce = None
        if api_key:
            try:
                key = get_encryption_key_bytes()
                aesgcm = AESGCM(key)
                nonce = os.urandom(12)  # 12 bytes for AES-GCM
                ciphertext = aesgcm.encrypt(nonce, api_key.encode("utf-8"), None)
                api_key_encrypted = base64.b64encode(ciphertext).decode("utf-8")
                api_key_nonce = base64.b64encode(nonce).decode("utf-8")
            except Exception as e:
                logger.error(
                    "Failed to encrypt API key for credentials endpoint",
                    error=str(e),
                    exc_info=True,
                )
                # Return error if encryption fails
                return LLMCredentialsResponse(
                    success=False,
                    error=f"Failed to encrypt credentials: {str(e)}",
                )

        # For GitHub Copilot / OpenAI Codex, use endpoint from token cache if available
        final_api_base = resolved_api_base
        if provider_type == "github_copilot" and api_base_for_copilot:
            final_api_base = api_base_for_copilot
        elif provider_type == "openai_codex" and api_base_for_codex:
            final_api_base = api_base_for_codex
        
        return LLMCredentialsResponse(
            success=True,
            provider=active_provider_id,
            provider_type=provider_type,
            model=resolved_model,
            api_key_encrypted=api_key_encrypted,
            api_key_nonce=api_key_nonce,
            api_base=final_api_base,
        )
    except Exception as e:
        logger.error("Failed to get LLM credentials", error=str(e), exc_info=True)
        return LLMCredentialsResponse(
            success=False,
            error=str(e),
        )


@router.get(
    "/remote-llm/status",
    response_model=LLMStatusResponse,
    include_in_schema=False,
)
async def get_llm_status():
    """Get simple LLM status for browser extension.

    Returns whether LLM is configured (enabled + has API key) and provider info.
    Does NOT return sensitive credentials - use /credentials for that.
    """
    try:
        config_manager = get_config_manager()
        config = config_manager.get_config()

        if not config.enabled:
            return LLMStatusResponse(
                configured=False,
                error="Remote LLM is not enabled",
            )

        # Get active provider config
        active_provider_id = config_manager.get_active_provider() or config.provider
        all_cfgs = config_manager.get_all_provider_configs()
        active_cfg = all_cfgs.get(active_provider_id)

        provider_type = (
            (active_cfg.provider_type if active_cfg else None)
            or config.provider_type
            or config.provider
        )

        # Check if API key is present
        has_key = bool(config.api_key)
        if active_cfg:
            has_key = bool(active_cfg.api_key) or has_key

        # For GitHub Copilot, check token file
        if provider_type == "github_copilot":
            try:
                token_dir = config_manager.config_path.parent / "github_copilot"
                token_file = token_dir / "access-token"
                has_key = token_file.exists() and token_file.read_text().strip() != ""
            except Exception:
                pass
        # For OpenAI Codex, check access-token.json
        elif provider_type == "openai_codex":
            try:
                import json as _json
                token_dir = config_manager.config_path.parent / "openai_codex"
                token_file = token_dir / "access-token.json"
                if token_file.exists():
                    data = _json.loads(token_file.read_text())
                    has_key = bool(data.get("access_token", "").strip())
                else:
                    has_key = False
            except Exception:
                pass

        if not has_key:
            return LLMStatusResponse(
                configured=False,
                provider=active_provider_id,
                error="No API key configured",
            )

        return LLMStatusResponse(
            configured=True,
            provider=active_provider_id,
            model=config.model,
        )
    except Exception as e:
        logger.error("Failed to get LLM status", error=str(e))
        return LLMStatusResponse(
            configured=False,
            error=str(e),
        )
