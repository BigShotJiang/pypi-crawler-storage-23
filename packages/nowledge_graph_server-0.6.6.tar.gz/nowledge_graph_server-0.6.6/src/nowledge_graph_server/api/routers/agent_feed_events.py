"""Feed event management endpoints.

Split from agent.py to stay under pyarmor free-version line limits.
Provides:
- GET /feed/events — List events with filtering
- POST /feed/events/{event_id}/resolve — Mark resolved + graph mutations
- DELETE /feed/events/{event_id} — Soft-delete
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog
from fastapi import APIRouter, Depends, HTTPException, Query

from ..dependencies import get_memory_operations
from nowledge_graph_server.database.result_utils import managed_result
from nowledge_graph_server.utils.progress_logger import log_data_change
from .agent import (
    _get_events_dir,
    _get_time_partitioned_path,
    _iter_time_partitioned_files,
)

router = APIRouter(tags=["knowledge-agent"])
logger = structlog.get_logger(__name__)


# ------------------------------------------------------------------
# Feed Timeline (file-based JSONL)
# ------------------------------------------------------------------


def _load_feed_events(events_dir: Path, *, last_n_days: int = 90) -> List[Dict[str, Any]]:
    """Load all events from time-partitioned JSONL files."""
    events: List[Dict[str, Any]] = []

    for event_file in _iter_time_partitioned_files(events_dir, "jsonl", last_n_days=last_n_days):
        try:
            for line in event_file.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    events.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        except Exception:
            continue

    return events


@router.get("/feed/events")
async def get_feed_events(
    limit: int = Query(default=50, ge=1, le=1000),
    offset: int = Query(default=0, ge=0),
    severity: Optional[str] = Query(default=None),
    event_type: Optional[str] = Query(default=None),
    unresolved_only: bool = Query(default=False),
    last_n_days: int = Query(default=365, ge=1, le=365),
    date_from: Optional[str] = Query(
        default=None,
        description="Start of date range (YYYY-MM-DD). Overrides last_n_days lower bound.",
    ),
    date_to: Optional[str] = Query(
        default=None,
        description="End of date range (YYYY-MM-DD, inclusive). Defaults to today.",
    ),
    source: Optional[str] = Query(
        default=None,
        description="Filter by metadata.source value (e.g. 'library:source_id').",
    ),
) -> Dict[str, Any]:
    """Get feed events from time-partitioned JSONL files.

    Supports two filtering modes:
    - last_n_days: N days back from today (default)
    - date_from + date_to: explicit date range (YYYY-MM-DD)

    Both modes can be combined with event_type, severity, and unresolved_only.
    """
    try:
        events_dir = _get_events_dir()
        if events_dir is None:
            return {"total": 0, "offset": offset, "limit": limit, "events": []}

        # When date_from is given, compute last_n_days wide enough to cover it
        if date_from:
            try:
                from_dt = datetime.fromisoformat(date_from).replace(tzinfo=timezone.utc)
                now_utc = datetime.now(timezone.utc)
                days_needed = (now_utc - from_dt).days + 2  # +2 buffer
                load_days = max(last_n_days, min(days_needed, 365))
            except ValueError:
                load_days = last_n_days
        else:
            load_days = last_n_days

        all_events = _load_feed_events(events_dir, last_n_days=load_days)

        # Parse date range bounds once
        date_from_str: Optional[str] = date_from  # YYYY-MM-DD prefix match
        date_to_str: Optional[str] = date_to

        # Apply filters
        filtered = []
        for event in all_events:
            if severity and event.get("severity") != severity:
                continue
            if event_type and event.get("event_type") != event_type:
                continue
            if unresolved_only and event.get("resolved", False):
                continue
            if event.get("deleted", False):
                continue
            # Source filter (match metadata.source field)
            if source:
                meta_raw = event.get("metadata")
                if isinstance(meta_raw, str):
                    try:
                        meta = json.loads(meta_raw)
                    except (json.JSONDecodeError, TypeError):
                        meta = {}
                elif isinstance(meta_raw, dict):
                    meta = meta_raw
                else:
                    meta = {}
                if meta.get("source") != source:
                    continue
            # Date range filter (compare ISO date prefix YYYY-MM-DD)
            if date_from_str or date_to_str:
                created = (event.get("created_at") or "")[:10]
                if date_from_str and created < date_from_str:
                    continue
                if date_to_str and created > date_to_str:
                    continue
            filtered.append(event)

        # Sort by created_at descending (newest first)
        filtered.sort(key=lambda e: e.get("created_at", ""), reverse=True)

        total = len(filtered)
        page = filtered[offset : offset + limit]

        return {
            "total": total,
            "offset": offset,
            "limit": limit,
            "events": page,
        }

    except Exception as e:
        logger.error("Failed to get feed events", error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to get events: {e}")


async def _determine_older_newer(
    memory_ops: Any,
    ids: List[str],
) -> tuple[Optional[str], Optional[str]]:
    """Determine which memory is older and which is newer by created_at.

    Returns (older_id, newer_id). Both are None if we can't determine order.
    """
    if len(ids) < 2:
        return None, None

    memories = []
    for mid in ids[:2]:
        try:
            mem = await memory_ops.get_memory_by_id(mid)
            if mem:
                memories.append((mid, mem.created_at))
        except Exception as e:
            logger.warning("Could not fetch memory for timestamp comparison", memory_id=mid, error=str(e))

    if len(memories) < 2:
        # Fallback: if we can't fetch both, assume original ordering (ids[0] = older)
        logger.warning("Falling back to list ordering for keep_newer", fetched=len(memories))
        return ids[0], ids[1]

    # Sort by created_at ascending: first = older
    memories.sort(key=lambda m: m[1] or datetime.min)
    return memories[0][0], memories[1][0]


async def _create_evolves_edge(
    memory_ops: Any,
    ids: List[str],
    event_id: str,
) -> Dict[str, Any]:
    """Create an EVOLVES(enriches) edge between two memories.

    Determines older/newer by timestamp. Edge direction: older -> newer.
    """
    from nowledge_graph_server.utils.feed_events import emit_feed_event

    older_id, newer_id = await _determine_older_newer(memory_ops, ids)
    if not older_id or not newer_id:
        return {"error": "Could not determine memory order"}

    try:
        conn = memory_ops.db.conn
        now_iso = datetime.now(timezone.utc).isoformat()

        # Check for existing EVOLVES edge to prevent duplicates
        with managed_result(conn.execute(
            """
            MATCH (a:Memory)-[r:EVOLVES]->(b:Memory)
            WHERE a.id = $older_id AND b.id = $newer_id
            RETURN r.content_relation
            """,
            {"older_id": older_id, "newer_id": newer_id},
        )) as dup_check:
            if dup_check.has_next():
                existing = dup_check.get_next()[0]
                logger.info("EVOLVES edge already exists, skipping", older_id=older_id, newer_id=newer_id, relation=existing)
                return {"skipped": True, "reason": f"EVOLVES edge already exists ({existing})"}

        # Create EVOLVES edge: older -> newer
        conn.execute(
            """
            MATCH (a:Memory), (b:Memory)
            WHERE a.id = $older_id AND b.id = $newer_id
            CREATE (a)-[:EVOLVES {
                content_relation: $relation,
                is_progression: true,
                confidence: $confidence,
                detected_by: 'user_action',
                reviewed: true,
                reason: $reason,
                created_at: timestamp($now)
            }]->(b)
            """,
            {
                "older_id": older_id,
                "newer_id": newer_id,
                "relation": "enriches",
                "confidence": 0.9,
                "reason": f"User chose 'Keep both' on flag {event_id}",
                "now": now_iso,
            },
        )

        # Emit feed event so the EVOLVES edge is visible in timeline
        emit_feed_event(
            "evolves_detected",
            title="Memory updated: enriches",
            description=f"Linked as enrichment (user action)",
            related_memory_ids=[older_id, newer_id],
            metadata={
                "older_memory_id": older_id,
                "newer_memory_id": newer_id,
                "content_relation": "enriches",
                "confidence": 0.9,
            },
        )

        logger.info(
            "Flag action: created EVOLVES edge",
            older_id=older_id, newer_id=newer_id, event_id=event_id,
        )

        # Notify scheduler (best-effort)
        try:
            import asyncio
            from nowledge_graph_server.agent.manager import KnowledgeAgentManager
            mgr = KnowledgeAgentManager.get_instance()
            if mgr.is_running:
                edge_id = f"{older_id}__{newer_id}"
                asyncio.create_task(mgr.on_evolves_detected(edge_id))
        except Exception:
            pass

        return {
            "evolves_created": True,
            "older_id": older_id,
            "newer_id": newer_id,
            "content_relation": "enriches",
        }

    except Exception as e:
        logger.error("Failed to create EVOLVES edge", error=str(e), event_id=event_id)
        return {"error": f"Failed to create EVOLVES edge: {e}"}


@router.post("/feed/events/{event_id}/retry")
async def retry_event(event_id: str) -> Dict[str, Any]:
    """Retry a failed background task by re-submitting it to the scheduler.

    Reads the original event's metadata to extract `task_type`, then submits
    a new AgentTask with HIGH priority. Marks the original event as retried.
    """
    try:
        events_dir = _get_events_dir()
        if events_dir is None:
            raise HTTPException(status_code=404, detail="Feed not found")

        # Find the event and extract task_type from metadata
        event_data: Optional[Dict[str, Any]] = None
        event_file_path: Optional[Path] = None
        event_line_idx: Optional[int] = None

        for event_file in _iter_time_partitioned_files(events_dir, "jsonl", last_n_days=90):
            try:
                lines = event_file.read_text(encoding="utf-8").splitlines()
                for idx, line in enumerate(lines):
                    if not line.strip():
                        continue
                    try:
                        event = json.loads(line)
                        if event.get("id") == event_id:
                            event_data = event
                            event_file_path = event_file
                            event_line_idx = idx
                            break
                    except json.JSONDecodeError:
                        continue
                if event_data:
                    break
            except Exception:
                continue

        if not event_data:
            raise HTTPException(status_code=404, detail=f"Event not found: {event_id}")

        # Extract task_type from metadata
        metadata = event_data.get("metadata", {})
        if isinstance(metadata, str):
            try:
                metadata = json.loads(metadata)
            except (json.JSONDecodeError, TypeError):
                metadata = {}

        task_type = metadata.get("task_type")
        if not task_type:
            raise HTTPException(
                status_code=400,
                detail="Event has no task_type in metadata — cannot retry",
            )

        # Submit retry task to scheduler
        from nowledge_graph_server.agent.manager import KnowledgeAgentManager

        mgr = KnowledgeAgentManager.get_instance()
        if not mgr or not mgr.is_running:
            raise HTTPException(
                status_code=503,
                detail="Knowledge Agent not running — cannot retry",
            )

        from nowledge_graph_server.agent.scheduler import AgentTask, TaskPriority

        # Build the correct prompt for this task type
        prompt = ""
        try:
            from nowledge_graph_server.agent.task_prompts import (
                build_compaction_prompt,
                build_daily_briefing_prompt,
                build_crystallization_prompt,
                build_insight_detection_prompt,
            )
            _prompt_builders = {
                "daily_briefing": build_daily_briefing_prompt,
                "crystallization_review": build_crystallization_prompt,
                "insight_detection": build_insight_detection_prompt,
                "memory_compaction": build_compaction_prompt,
            }
            builder = _prompt_builders.get(task_type)
            if builder:
                prompt = builder()
        except Exception as e:
            logger.warning("Failed to build retry prompt, using empty", error=str(e))

        retry_task = AgentTask(
            task_type=task_type,
            prompt=prompt,
            priority=TaskPriority.HIGH,
            metadata={"retry_of_event": event_id},
        )
        await mgr._scheduler.submit_task(retry_task)

        # Mark original event as retried
        if event_file_path and event_line_idx is not None:
            try:
                lines = event_file_path.read_text(encoding="utf-8").splitlines()
                event = json.loads(lines[event_line_idx])
                event["retried"] = True
                event["retried_at"] = datetime.now(timezone.utc).isoformat()
                lines[event_line_idx] = json.dumps(event)
                event_file_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
            except Exception as e:
                logger.warning("Failed to mark event as retried", error=str(e))

        # Emit a "retrying" feed event
        from nowledge_graph_server.utils.feed_events import emit_feed_event

        emit_feed_event(
            "system_event",
            title=f"Retrying: {task_type.replace('_', ' ')}",
            description=f"Re-submitted background task '{task_type}' with high priority.",
            metadata={"task_type": task_type, "retry_of_event": event_id},
        )

        log_data_change(
            "feed_event_retried", "feed", event_id,
            {"task_type": task_type},
        )

        return {
            "success": True,
            "event_id": event_id,
            "task_type": task_type,
            "message": f"Task '{task_type}' re-submitted to scheduler",
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to retry event", error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to retry event: {e}")


@router.post("/feed/events/{event_id}/resolve")
async def resolve_event(
    event_id: str,
    resolution: str = Query(description="Resolution type: accepted|dismissed|merged"),
    action: Optional[str] = Query(default=None, description="Graph action: delete_memory|keep_newer|keep_both"),
    memory_ids: Optional[str] = Query(default=None, description="Comma-separated memory IDs to act on"),
    memory_ops=Depends(get_memory_operations),
) -> Dict[str, Any]:
    """Resolve an action-required feed event and optionally execute graph mutations.

    Resolution marks the event as resolved in the JSONL file.
    Action (optional) executes a graph mutation:
    - delete_memory: Delete all specified memories
    - keep_newer: Delete the older memory (by timestamp), keep the newer
    - keep_both: Create EVOLVES(enriches) edge linking the two memories
    """
    try:
        events_dir = _get_events_dir()
        if events_dir is None:
            raise HTTPException(status_code=404, detail="Feed not found")

        now = datetime.now(timezone.utc).isoformat()
        updated = False
        event_memory_ids: List[str] = []  # Extract from event data as fallback

        # Search through time-partitioned event files (recent first)
        for event_file in _iter_time_partitioned_files(events_dir, "jsonl", last_n_days=90):
            if updated:
                break

            try:
                lines = event_file.read_text(encoding="utf-8").splitlines()
                new_lines = []
                file_modified = False

                for line in lines:
                    if not line.strip():
                        new_lines.append(line)
                        continue
                    try:
                        event = json.loads(line)
                        if event.get("id") == event_id:
                            event["resolved"] = True
                            event["resolved_at"] = now
                            event["resolution"] = resolution
                            if action:
                                event["action"] = action
                            file_modified = True
                            updated = True
                            # Extract memory IDs from event data for action fallback
                            raw_ids = event.get("related_memory_ids") or []
                            if not raw_ids:
                                meta = event.get("metadata") or {}
                                if isinstance(meta, str):
                                    try:
                                        meta = json.loads(meta)
                                    except (json.JSONDecodeError, TypeError):
                                        meta = {}
                                raw_ids = meta.get("memory_ids") or []
                            event_memory_ids = [str(mid) for mid in raw_ids if mid]
                        new_lines.append(json.dumps(event))
                    except json.JSONDecodeError:
                        new_lines.append(line)

                if file_modified:
                    event_file.write_text("\n".join(new_lines) + "\n", encoding="utf-8")

            except Exception as e:
                logger.warning("Failed to process event file", file=str(event_file), error=str(e))
                continue

        if not updated:
            raise HTTPException(status_code=404, detail=f"Event not found: {event_id}")

        # Execute graph mutation if action specified
        # Use memory_ids from query param, falling back to event's own related_memory_ids
        action_result: Dict[str, Any] = {}
        effective_ids_str = memory_ids
        if action and not effective_ids_str and event_memory_ids:
            effective_ids_str = ",".join(event_memory_ids)
            logger.info(
                "Flag action: using memory_ids from event data (not provided in request)",
                event_id=event_id, memory_ids=event_memory_ids,
            )
        if action and not effective_ids_str:
            action_result["error"] = f"Action '{action}' requires memory_ids but none provided"
            logger.warning("Flag action skipped: no memory_ids", action=action, event_id=event_id)
        if action and effective_ids_str:
            ids = [mid.strip() for mid in effective_ids_str.split(",") if mid.strip()]

            if action == "delete_memory":
                # Delete all specified memories
                for mid in ids:
                    try:
                        result = await memory_ops.delete_memory(mid, cascade_delete=True)
                        action_result[mid] = {"deleted": True, "details": result}
                        logger.info("Flag action: deleted memory", memory_id=mid, event_id=event_id)
                    except Exception as e:
                        action_result[mid] = {"deleted": False, "error": str(e)}
                        logger.warning("Flag action: delete failed", memory_id=mid, error=str(e))

            elif action == "keep_newer":
                # Determine older/newer by created_at timestamp, delete the older
                older_id, newer_id = await _determine_older_newer(memory_ops, ids)
                if older_id:
                    try:
                        result = await memory_ops.delete_memory(older_id, cascade_delete=True)
                        action_result[older_id] = {"deleted": True, "kept": newer_id}
                        logger.info(
                            "Flag action: kept newer, deleted older",
                            older_id=older_id, newer_id=newer_id, event_id=event_id,
                        )
                    except Exception as e:
                        action_result[older_id] = {"deleted": False, "error": str(e)}
                        logger.warning("Flag action: keep_newer delete failed", older_id=older_id, error=str(e))
                else:
                    action_result["error"] = "Could not determine older/newer memory"
                    logger.warning("Flag action: keep_newer skipped, could not resolve timestamps", ids=ids)

            elif action == "keep_both":
                # Link both memories with EVOLVES(enriches) edge
                if len(ids) >= 2:
                    evolves_result = await _create_evolves_edge(memory_ops, ids, event_id)
                    action_result.update(evolves_result)
                else:
                    action_result["error"] = "keep_both requires at least 2 memory IDs"
                    logger.warning("Flag action: keep_both needs 2+ IDs", ids=ids)

        # Notify UI
        log_data_change(
            "feed_event_resolved", "feed", event_id,
            {"resolution": resolution, "action": action},
        )

        return {
            "success": True,
            "event_id": event_id,
            "resolution": resolution,
            "action_result": action_result if action_result else None,
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to resolve event", error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to resolve event: {e}")


@router.delete("/feed/events/{event_id}")
async def delete_feed_event(event_id: str) -> Dict[str, Any]:
    """Soft-delete a feed event by marking deleted=True in the JSONL file."""
    try:
        events_dir = _get_events_dir()
        if events_dir is None:
            raise HTTPException(status_code=404, detail="Events directory not found")

        now = datetime.now(timezone.utc).isoformat()
        updated = False

        for event_file in _iter_time_partitioned_files(events_dir, "jsonl", last_n_days=365):
            try:
                lines = event_file.read_text(encoding="utf-8").splitlines()
                new_lines = []
                file_modified = False

                for line in lines:
                    if not line.strip():
                        new_lines.append(line)
                        continue
                    try:
                        event = json.loads(line)
                        if event.get("id") == event_id:
                            event["deleted"] = True
                            event["deleted_at"] = now
                            file_modified = True
                            updated = True
                        new_lines.append(json.dumps(event))
                    except json.JSONDecodeError:
                        new_lines.append(line)

                if file_modified:
                    event_file.write_text("\n".join(new_lines) + "\n", encoding="utf-8")

            except Exception as e:
                logger.warning("Failed to process event file", file=str(event_file), error=str(e))
                continue

        if not updated:
            raise HTTPException(status_code=404, detail=f"Event not found: {event_id}")

        log_data_change(
            "feed_event_deleted", "feed", event_id,
            {"deleted": True},
        )

        return {"success": True, "event_id": event_id}

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to delete event", error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to delete event: {e}")
