"""Data export/import API endpoints."""

from __future__ import annotations

import asyncio
import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

import structlog
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from nowledge_graph_server.api.dependencies import (
    get_kuzu_client,
    enter_data_transfer_maintenance,
    exit_data_transfer_maintenance,
)
from nowledge_graph_server.database.kuzu_client import KuzuClient
from nowledge_graph_server.services.data_transfer import (
    DataTransferService,
    ExportOptions,
    ImportOptions,
)
from nowledge_graph_server.utils.app_paths import get_app_config_dir

logger = structlog.get_logger(__name__)

router = APIRouter()

_import_jobs: Dict[str, Dict[str, Any]] = {}
_IMPORT_JOB_PATH = get_app_config_dir() / "data-transfer-imports.json"


def _persist_import_jobs() -> None:
    try:
        _IMPORT_JOB_PATH.parent.mkdir(parents=True, exist_ok=True)
        payload = {"jobs": _import_jobs}
        tmp_path = _IMPORT_JOB_PATH.with_suffix(".json.tmp")
        tmp_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp_path.replace(_IMPORT_JOB_PATH)
    except Exception as e:
        logger.warning("Failed to persist import jobs", error=str(e))


def _load_import_jobs() -> None:
    if not _IMPORT_JOB_PATH.exists():
        return
    try:
        data = json.loads(_IMPORT_JOB_PATH.read_text(encoding="utf-8"))
    except Exception as e:
        logger.warning("Failed to load persisted import jobs", error=str(e))
        return
    jobs = data.get("jobs")
    if not isinstance(jobs, dict):
        return
    now = datetime.now(timezone.utc).isoformat()
    for job_id, job in jobs.items():
        if not isinstance(job, dict):
            continue
        if job.get("status") == "processing":
            job["status"] = "error"
            job["completed_at"] = now
            job["error"] = "Import interrupted by backend restart."
    _import_jobs.update(jobs)
    _persist_import_jobs()


_load_import_jobs()


def _update_import_job(job_id: str, **updates: Any) -> None:
    if job_id in _import_jobs:
        _import_jobs[job_id].update(updates)
        _persist_import_jobs()


class DataImportStartResponse(BaseModel):
    success: bool = True
    job_id: str
    status: str
    message: str


class DataImportStatusResponse(BaseModel):
    job_id: str
    status: str
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    error: Optional[str] = None
    result: Optional[Dict[str, Any]] = None


class DataExportRequest(BaseModel):
    export_path: str = Field(..., description="Target export directory or .zip path")
    compress: bool = Field(default=True, description="Create a .zip archive")
    overwrite: bool = Field(default=False, description="Overwrite existing export path")

    include_memories: bool = True
    include_threads: bool = True
    include_messages: bool = True
    include_entities: bool = True
    include_labels: bool = True
    include_sources: bool = True
    include_communities: bool = True
    include_edges: bool = True
    include_working_memory: bool = True
    include_working_memory_archive: bool = True
    include_source_files: bool = True


class DataImportRequest(BaseModel):
    import_path: str = Field(..., description="Path to export folder or .zip")
    mode: str = Field(
        default="merge",
        description="merge | skip | overwrite",
    )

    include_memories: bool = True
    include_threads: bool = True
    include_messages: bool = True
    include_entities: bool = True
    include_labels: bool = True
    include_sources: bool = True
    include_communities: bool = True
    include_edges: bool = True
    include_working_memory: bool = True
    include_working_memory_archive: bool = True
    include_source_files: bool = True


@router.post("/data/export")
async def export_data(
    request: DataExportRequest,
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> Dict[str, Any]:
    try:
        service = DataTransferService(kuzu_client)
        options = ExportOptions(
            include_memories=request.include_memories,
            include_threads=request.include_threads,
            include_messages=request.include_messages,
            include_entities=request.include_entities,
            include_labels=request.include_labels,
            include_sources=request.include_sources,
            include_communities=request.include_communities,
            include_edges=request.include_edges,
            include_working_memory=request.include_working_memory,
            include_working_memory_archive=request.include_working_memory_archive,
            include_source_files=request.include_source_files,
            compress=request.compress,
            overwrite=request.overwrite,
        )
        return service.export_data(Path(request.export_path), options)
    except Exception as e:
        logger.error("Export failed", error=str(e))
        raise HTTPException(status_code=500, detail=f"Export failed: {e}")


@router.post("/data/import", response_model=DataImportStartResponse)
async def import_data(
    request: DataImportRequest,
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> DataImportStartResponse:
    try:
        snapshot = await enter_data_transfer_maintenance("data_import")
        job_id = str(uuid.uuid4())
        _import_jobs[job_id] = {
            "job_id": job_id,
            "status": "processing",
            "started_at": datetime.now(timezone.utc).isoformat(),
            "completed_at": None,
            "error": None,
            "result": None,
        }
        _persist_import_jobs()

        options = ImportOptions(
            include_memories=request.include_memories,
            include_threads=request.include_threads,
            include_messages=request.include_messages,
            include_entities=request.include_entities,
            include_labels=request.include_labels,
            include_sources=request.include_sources,
            include_communities=request.include_communities,
            include_edges=request.include_edges,
            include_working_memory=request.include_working_memory,
            include_working_memory_archive=request.include_working_memory_archive,
            include_source_files=request.include_source_files,
            mode=request.mode,
        )

        async def run_import() -> None:
            try:
                service = DataTransferService(kuzu_client)
                result = await asyncio.to_thread(
                    service.import_data, Path(request.import_path), options
                )
                logger.info(
                    "Import completed",
                    job_id=job_id,
                    counts=result.get("counts"),
                    warnings=result.get("warnings"),
                    backup=result.get("backup"),
                )
                _update_import_job(
                    job_id,
                    status="completed",
                    completed_at=datetime.now(timezone.utc).isoformat(),
                    result=result,
                )
            except Exception as e:
                logger.error("Import failed", job_id=job_id, error=str(e))
                _update_import_job(
                    job_id,
                    status="error",
                    completed_at=datetime.now(timezone.utc).isoformat(),
                    error=str(e),
                )
            finally:
                await exit_data_transfer_maintenance(snapshot)

        asyncio.create_task(run_import())

        return DataImportStartResponse(
            success=True,
            job_id=job_id,
            status="processing",
            message="Import started",
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Import failed", error=str(e))
        raise HTTPException(status_code=500, detail=f"Import failed: {e}")


@router.post("/data/checkpoint")
async def checkpoint_data(
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> Dict[str, Any]:
    try:
        service = DataTransferService(kuzu_client)
        return service.run_checkpoint()
    except Exception as e:
        logger.error("Checkpoint failed", error=str(e))
        raise HTTPException(status_code=500, detail=f"Checkpoint failed: {e}")


@router.get("/data/import/status/{job_id}", response_model=DataImportStatusResponse)
async def get_import_status(job_id: str) -> DataImportStatusResponse:
    job = _import_jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Import job not found")
    return DataImportStatusResponse(
        job_id=job_id,
        status=job.get("status", "unknown"),
        started_at=job.get("started_at"),
        completed_at=job.get("completed_at"),
        error=job.get("error"),
        result=job.get("result"),
    )
