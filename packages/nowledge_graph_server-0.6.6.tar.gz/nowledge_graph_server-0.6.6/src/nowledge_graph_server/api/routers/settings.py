"""App settings API endpoints for headless / server deployments.

Provides read/write access to app-settings.json, which is normally managed
by the Tauri frontend.  On Linux servers (no Tauri), the CLI / TUI uses
these endpoints instead.
"""

from typing import Any, Dict, Optional

from fastapi import APIRouter
from pydantic import BaseModel, Field
import structlog

from ...agent.settings_reader import (
    get_app_settings_path,
    read_knowledge_processing_settings,
    read_user_profile,
)

import json

logger = structlog.get_logger(__name__)

router = APIRouter(prefix="/settings", tags=["settings"])


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class KnowledgeProcessingSettings(BaseModel):
    """Knowledge processing settings (all optional for partial updates)."""

    backgroundIntelligence: Optional[bool] = None
    autoKGExtraction: Optional[bool] = None
    autoCommunityDetection: Optional[bool] = None
    autoEVOLVESDetection: Optional[bool] = None
    communityDetectionIntervalDays: Optional[int] = None
    communityResolution: Optional[float] = None
    kgExtractionConfidence: Optional[float] = None
    autoDailyBriefing: Optional[bool] = None
    autoCrystallization: Optional[bool] = None
    autoInsightDetection: Optional[bool] = None
    autoWMRefresh: Optional[bool] = None
    autoDecayRefresh: Optional[bool] = None
    autoMemoryCompaction: Optional[bool] = None
    autoArchiveStaleMemories: Optional[bool] = None
    generateCommunityAISummary: Optional[bool] = None
    briefingHour: Optional[int] = Field(None, ge=0, le=23)
    maxTokensPerHour: Optional[int] = Field(None, ge=0)
    maxTokensPerDay: Optional[int] = Field(None, ge=0)
    maxTokensPerTask: Optional[int] = Field(None, ge=0)


class KnowledgeProcessingResponse(BaseModel):
    """Full knowledge processing settings after merge."""

    settings: Dict[str, Any]


class UserProfileResponse(BaseModel):
    """User profile data for external consumers (browser extension, CLI)."""

    name: str = ""
    aliases: str = ""
    context: str = ""
    preferred_language: str = "en"


class AppSettingsResponse(BaseModel):
    """Full app-settings.json content."""

    settings: Dict[str, Any]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _read_app_settings() -> Dict[str, Any]:
    """Read the full app-settings.json file."""
    settings_path = get_app_settings_path()
    if not settings_path.exists():
        return {}
    try:
        return json.loads(settings_path.read_text(encoding="utf-8"))
    except Exception as e:
        logger.warning("Failed to read app-settings.json", error=str(e))
        return {}


def _write_app_settings(data: Dict[str, Any]) -> None:
    """Write the full app-settings.json file (atomic-ish)."""
    settings_path = get_app_settings_path()
    settings_path.parent.mkdir(parents=True, exist_ok=True)
    settings_path.write_text(
        json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8"
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("", response_model=AppSettingsResponse, include_in_schema=False)
async def get_app_settings() -> AppSettingsResponse:
    """Get the full app-settings.json content."""
    return AppSettingsResponse(settings=_read_app_settings())


@router.get("/profile", response_model=UserProfileResponse)
async def get_user_profile() -> UserProfileResponse:
    """Get user profile (name, aliases, context, preferred language).

    Used by the browser extension and CLI to inject user identity
    and language preference into agent prompts.
    """
    profile = read_user_profile()
    return UserProfileResponse(**profile)


@router.get(
    "/knowledge-processing",
    response_model=KnowledgeProcessingResponse,
    include_in_schema=False,
)
async def get_knowledge_processing_settings() -> KnowledgeProcessingResponse:
    """Get knowledge processing settings (merged with defaults)."""
    return KnowledgeProcessingResponse(settings=read_knowledge_processing_settings())


@router.post(
    "/knowledge-processing",
    response_model=KnowledgeProcessingResponse,
    include_in_schema=False,
)
async def update_knowledge_processing_settings(
    request: KnowledgeProcessingSettings,
) -> KnowledgeProcessingResponse:
    """Update knowledge processing settings (partial update — only provided fields are changed)."""
    # Read existing full settings
    all_settings = _read_app_settings()
    kp = all_settings.get("knowledgeProcessing", {})
    if not isinstance(kp, dict):
        kp = {}

    # Merge only the fields that were explicitly provided
    updates = request.model_dump(exclude_none=True)
    kp.update(updates)
    all_settings["knowledgeProcessing"] = kp

    # Write back
    _write_app_settings(all_settings)
    logger.info("Knowledge processing settings updated", updates=list(updates.keys()))

    # Return merged with defaults
    return KnowledgeProcessingResponse(settings=read_knowledge_processing_settings())
