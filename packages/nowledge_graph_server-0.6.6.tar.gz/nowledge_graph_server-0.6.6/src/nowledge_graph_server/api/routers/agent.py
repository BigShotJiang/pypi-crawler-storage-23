"""Knowledge Agent REST API endpoints.

Provides endpoints for:
- Agent status
- Manual task triggers (daily briefing, crystallization)
- Working memory management
- EVOLVES edges

Feed event management and feed input/streaming are in separate modules:
- agent_feed_events.py — GET/POST/DELETE feed events
- agent_feed_input.py — Feed input, persist-question, SSE streaming

Uses time-partitioned file structure:
- Events: events/YYYY/MM/YYYY-MM-DD.jsonl
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from ..dependencies import get_kuzu_client
from nowledge_graph_server.utils.progress_logger import log_data_change

router = APIRouter(prefix="/agent", tags=["knowledge-agent"])
logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# Classification parsing — agent classifies via [TYPE: ...] tags
# ---------------------------------------------------------------------------


def _strip_classification_tags(text: str) -> str:
    """Strip [TYPE:...], [UNIT_TYPE:...], [TITLE:...] tags from agent text.

    Handles both ASCII colon (:) and fullwidth colon (：U+FF1A) since
    CJK-language agents sometimes use fullwidth punctuation.
    """
    cleaned = re.sub(r"\[TYPE[:：][^\]]+\]", "", text, flags=re.IGNORECASE)
    cleaned = re.sub(r"\[UNIT_TYPE[:：][^\]]+\]", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\[TITLE[:：][^\]]+\]", "", cleaned, flags=re.IGNORECASE)
    # Remove empty code fences left behind
    cleaned = re.sub(r"```\s*```", "", cleaned)
    return cleaned.strip()


def _parse_agent_classification(text: str) -> Dict[str, Optional[str]]:
    """Parse [TYPE:...], [UNIT_TYPE:...], [TITLE:...] from agent response.

    Returns dict with keys: input_type, unit_type, title, clean_text.
    The agent is the sole classifier — no heuristic fallback.
    Handles both ASCII colon (:) and fullwidth colon (：U+FF1A).
    """
    type_match = re.search(r"\[TYPE[:：]\s*(capture|question|url)\]", text, re.IGNORECASE)
    unit_type_match = re.search(r"\[UNIT_TYPE[:：]\s*(\w+|null)\]", text, re.IGNORECASE)
    title_match = re.search(r"\[TITLE[:：]\s*([^\]]+)\]", text, re.IGNORECASE)

    input_type = type_match.group(1).lower() if type_match else None
    unit_type_raw = unit_type_match.group(1).lower() if unit_type_match else "fact"
    raw_title = title_match.group(1).strip() if title_match else None

    return {
        "input_type": input_type,
        "unit_type": unit_type_raw if unit_type_raw != "null" else None,
        "title": None if raw_title in (None, "null", "") else raw_title,
        "clean_text": _strip_classification_tags(text),
    }


# ---------------------------------------------------------------------------
# Time-partitioned file helpers (shared utility)
# ---------------------------------------------------------------------------

from nowledge_graph_server.utils.time_partitioning import (
    _get_time_partitioned_path,
    _iter_time_partitioned_files,
)


def _get_agent_manager():
    """Get the global agent manager (lazy import to avoid circular deps)."""
    from nowledge_graph_server.agent.manager import get_agent_manager
    return get_agent_manager()


def _get_events_dir() -> Optional[Path]:
    """Get the events directory using static path (not dependent on agent manager lifecycle).

    This ensures events can be read/written even when agent hasn't started yet
    (e.g., during app startup race condition, or when LLM isn't configured).
    """
    from nowledge_graph_server.agent.paths import get_builtin_agents_home
    events_dir = get_builtin_agents_home() / "events"
    # Ensure directory exists (may be first access)
    events_dir.mkdir(parents=True, exist_ok=True)
    return events_dir


# ------------------------------------------------------------------
# Agent Status
# ------------------------------------------------------------------


@router.get("/status")
async def get_agent_status() -> Dict[str, Any]:
    """Get the Knowledge Agent's current status."""
    manager = _get_agent_manager()
    if manager is None:
        return {
            "running": False,
            "llm_available": False,
            "message": "Knowledge Agent not initialized",
        }
    return manager.get_status()


# ------------------------------------------------------------------
# Manual Triggers
# ------------------------------------------------------------------


@router.post("/trigger/daily-briefing")
async def trigger_daily_briefing() -> Dict[str, str]:
    """Manually trigger a daily briefing."""
    manager = _get_agent_manager()
    if manager is None or not manager.is_running:
        raise HTTPException(
            status_code=503,
            detail="Knowledge Agent is not running",
        )
    await manager.trigger_daily_briefing()
    return {"status": "queued", "task": "daily_briefing"}


@router.post("/trigger/crystallization")
async def trigger_crystallization() -> Dict[str, str]:
    """Manually trigger a crystallization review."""
    manager = _get_agent_manager()
    if manager is None or not manager.is_running:
        raise HTTPException(
            status_code=503,
            detail="Knowledge Agent is not running",
        )
    await manager.trigger_crystallization()
    return {"status": "queued", "task": "crystallization_review"}


@router.post("/trigger/insight-detection")
async def trigger_insight_detection() -> Dict[str, str]:
    """Manually trigger proactive insight detection."""
    manager = _get_agent_manager()
    if manager is None or not manager.is_running:
        raise HTTPException(
            status_code=503,
            detail="Knowledge Agent is not running",
        )
    await manager.trigger_insight_detection()
    return {"status": "queued", "task": "insight_detection"}


@router.post("/trigger/decay-refresh")
async def trigger_decay_refresh() -> Dict[str, str]:
    """Manually trigger a decay score refresh."""
    manager = _get_agent_manager()
    if manager is None or not manager.is_running:
        raise HTTPException(
            status_code=503,
            detail="Knowledge Agent is not running",
        )
    await manager.trigger_decay_refresh()
    return {"status": "queued", "task": "decay_refresh"}


@router.post("/trigger/memory-compaction")
async def trigger_memory_compaction() -> Dict[str, str]:
    """Manually trigger a memory compaction review."""
    manager = _get_agent_manager()
    if manager is None or not manager.is_running:
        raise HTTPException(
            status_code=503,
            detail="Knowledge Agent is not running",
        )
    await manager.trigger_memory_compaction()
    return {"status": "queued", "task": "memory_compaction"}


@router.post("/trigger/community-detection")
async def trigger_community_detection(
    resolution: float = Query(default=1.0),
    generate_ai_summary: bool = Query(default=True),
) -> Dict[str, str]:
    """Manually trigger community detection on the knowledge graph."""
    manager = _get_agent_manager()
    if manager is None or not manager.is_running:
        raise HTTPException(
            status_code=503,
            detail="Knowledge Agent is not running",
        )
    from nowledge_graph_server.agent.scheduler import AgentTask, TaskPriority

    task = AgentTask(
        task_type="community_detection",
        prompt="",
        priority=TaskPriority.HIGH,
        metadata={
            "resolution": resolution,
            "generate_ai_summary": generate_ai_summary,
            "max_iterations": 100,
        },
    )
    await manager._scheduler.submit_task(task)
    return {"status": "queued", "task": "community_detection"}


@router.post("/trigger/kg-extraction")
async def trigger_kg_extraction(
    backfill: bool = Query(default=False),
    memory_ids: Optional[str] = Query(default=None, description="Comma-separated memory IDs for scoped extraction"),
) -> Dict[str, str]:
    """Manually trigger KG extraction (backfill, targeted, or scoped to specific memories)."""
    manager = _get_agent_manager()
    if manager is None or not manager.is_running:
        raise HTTPException(
            status_code=503,
            detail="Knowledge Agent is not running",
        )
    from nowledge_graph_server.agent.scheduler import AgentTask, TaskPriority

    if memory_ids:
        # Scoped extraction for specific memories
        ids_list = [mid.strip() for mid in memory_ids.split(",") if mid.strip()]
        task = AgentTask(
            task_type="kg_extraction",
            prompt="",
            priority=TaskPriority.HIGH,
            metadata={"memory_ids": ids_list},
        )
    else:
        task_type = "kg_extraction_backfill" if backfill else "kg_extraction"
        task = AgentTask(
            task_type=task_type,
            prompt="",
            priority=TaskPriority.HIGH,
            metadata={},
        )
    await manager._scheduler.submit_task(task)
    return {"status": "queued", "task": task.task_type}


@router.get("/knowledge-processing/status")
async def get_knowledge_processing_status() -> Dict[str, Any]:
    """Get knowledge processing settings and status."""
    from nowledge_graph_server.agent.settings_reader import read_knowledge_processing_settings

    settings = read_knowledge_processing_settings()
    manager = _get_agent_manager()

    # Merge last_fired from scheduler jobs + _last_executed from direct executors
    last_run: Dict[str, Optional[str]] = {}
    if manager and manager.is_running:
        if hasattr(manager, '_scheduler'):
            for job in manager._scheduler._scheduled_jobs:
                ts = job.last_fired.isoformat() if job.last_fired else None
                last_run[job.name] = ts
        if hasattr(manager, '_last_executed'):
            last_run.update(manager._last_executed)

    # Current task (if any)
    current_task = None
    if manager and hasattr(manager, '_current_task'):
        current_task = manager._current_task

    result: Dict[str, Any] = {
        "settings": settings,
        "agent_running": manager.is_running if manager else False,
        "last_run": last_run,
        "current_task": current_task,
    }

    # Token budget info from scheduler
    if manager and hasattr(manager, '_scheduler'):
        sched = manager._scheduler
        result["tokens_this_hour"] = sched.tokens_this_hour
        result["tokens_today"] = sched.tokens_today
        result["max_tokens_per_hour"] = sched.max_tokens_per_hour
        result["max_tokens_per_day"] = sched.max_tokens_per_day
        result["budget_paused"] = sched.is_budget_paused

    return result


# ------------------------------------------------------------------
# Working Memory (file-backed, single source of truth)
# ------------------------------------------------------------------


class UpdateWorkingMemoryRequest(BaseModel):
    content: str = Field(..., min_length=1, max_length=10000)


@router.get("/working-memory")
async def get_working_memory(
    date: Optional[str] = Query(default=None, description="YYYY-MM-DD for archived WM"),
) -> Dict[str, Any]:
    """Read the Working Memory file (~/ai-now/memory.md).

    Returns today's WM by default, or an archived day's WM if date is provided.
    This is the single source of truth for WM content — feed events are snapshots.
    """
    from nowledge_graph_server.agent.paths import get_working_memory_path, get_working_memory_archive_path
    from nowledge_graph_server.agent.knowledge_tools.working_memory import _parse_working_memory

    try:
        today_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        if date and date != today_str:
            try:
                target = datetime.strptime(date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
            except ValueError:
                raise HTTPException(status_code=400, detail=f"Invalid date format: {date}. Use YYYY-MM-DD.")
            path = get_working_memory_archive_path(target)
        else:
            path = get_working_memory_path()

        if not path.exists():
            return {"exists": False, "content": "", "parsed": None, "date": date or today_str}

        content = path.read_text(encoding="utf-8")
        parsed = _parse_working_memory(content)

        return {
            "exists": True,
            "content": content,
            "parsed": parsed,
            "date": date or today_str,
            "file_path": str(path),
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to read working memory", error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to read working memory: {e}")


@router.put("/working-memory")
async def update_working_memory(request: UpdateWorkingMemoryRequest) -> Dict[str, Any]:
    """Write the Working Memory file from user edits.

    Validates structure, writes to ~/ai-now/memory.md, and emits a feed event
    with edited_by="user" to distinguish from agent-generated updates.
    """
    from nowledge_graph_server.agent.paths import get_working_memory_path
    from nowledge_graph_server.agent.knowledge_tools.working_memory import _parse_working_memory
    from nowledge_graph_server.utils.feed_events import emit_feed_event

    content = request.content.strip()

    # Structural validation (same as UpdateWorkingMemory tool)
    if '## Focus Areas' not in content and '## Briefing' not in content:
        raise HTTPException(
            status_code=400,
            detail="Content must include at least ## Focus Areas or ## Briefing section.",
        )

    if len(content.encode("utf-8")) > 4096:
        raise HTTPException(
            status_code=400,
            detail=f"Content too large ({len(content.encode('utf-8'))} bytes). Max is 4096 bytes.",
        )

    try:
        # Parse structured metadata
        parsed = _parse_working_memory(content)
        memory_ids = re.findall(r'nowledgemem://memory/([a-zA-Z0-9_-]+)', content)
        unique_memory_ids = list(dict.fromkeys(memory_ids))

        # Write file
        path = get_working_memory_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

        # Emit feed event (marks as user-edited)
        emit_feed_event(
            "working_memory_updated",
            title="Working Memory updated",
            description=content[:200],
            related_memory_ids=unique_memory_ids[:10] if unique_memory_ids else None,
            metadata={
                "content": content,
                "date": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
                "parsed": parsed,
                "edited_by": "user",
            },
        )

        log_data_change("working_memory_updated", "feed", "working_memory", {"edited_by": "user"})

        return {
            "success": True,
            "size_bytes": len(content.encode("utf-8")),
            "focus_areas": len(parsed["focus_areas"]),
            "flags": len(parsed["flags"]),
            "memory_refs": len(unique_memory_ids),
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to update working memory", error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to update working memory: {e}")


@router.get("/working-memory/history")
async def get_working_memory_history(
    limit: int = Query(default=30, ge=1, le=365),
) -> Dict[str, Any]:
    """List dates that have archived Working Memory files.

    Scans ~/ai-now/memory-archive/ for YYYY/MM/YYYY-MM-DD.md files.
    Returns newest-first.
    """
    from nowledge_graph_server.agent.paths import get_ai_now_home

    archive_dir = get_ai_now_home() / "memory-archive"
    entries: List[Dict[str, Any]] = []

    if archive_dir.exists():
        for md_file in sorted(archive_dir.rglob("*.md"), reverse=True):
            # Extract date from filename (YYYY-MM-DD.md)
            stem = md_file.stem
            try:
                datetime.strptime(stem, "%Y-%m-%d")
            except ValueError:
                continue
            entries.append({
                "date": stem,
                "size_bytes": md_file.stat().st_size,
            })
            if len(entries) >= limit:
                break

    # Also check if today's WM exists (it's not in archive yet)
    from nowledge_graph_server.agent.paths import get_working_memory_path
    today_path = get_working_memory_path()
    today_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    if today_path.exists():
        entries.insert(0, {
            "date": today_str,
            "size_bytes": today_path.stat().st_size,
            "current": True,
        })

    return {"dates": entries[:limit], "total": len(entries)}


# ------------------------------------------------------------------
# EVOLVES edges
# ------------------------------------------------------------------


@router.get("/evolves")
async def get_evolves_edges(
    limit: int = Query(default=50, ge=1, le=200),
    content_relation: Optional[str] = Query(default=None),
    unreviewed_only: bool = Query(default=False),
    memory_id: Optional[str] = Query(
        default=None,
        description="Filter to EVOLVES edges where this memory appears as older or newer node.",
    ),
    kuzu_client=Depends(get_kuzu_client),
) -> Dict[str, Any]:
    """Get EVOLVES relationships. Edge direction: older → newer.

    When memory_id is provided, returns only edges where that memory participates
    (as either the older or newer node). Use this to get the full version chain
    for a specific memory.
    """
    try:
        conn = kuzu_client.conn

        where_parts = []
        params: Dict[str, Any] = {}

        if memory_id:
            where_parts.append("(older.id = $memory_id OR newer.id = $memory_id)")
            params["memory_id"] = memory_id

        if content_relation:
            where_parts.append("e.content_relation = $relation")
            params["relation"] = content_relation

        if unreviewed_only:
            where_parts.append("e.reviewed = false")

        where_clause = f"WHERE {' AND '.join(where_parts)}" if where_parts else ""

        # Edge direction: (older)-[:EVOLVES]->(newer)
        query = f"""
            MATCH (older:Memory)-[e:EVOLVES]->(newer:Memory)
            {where_clause}
            RETURN older.id, older.title, older.content,
                   newer.id, newer.title, newer.content,
                   e.content_relation, e.confidence, e.detected_by,
                   e.reviewed, e.reason, e.created_at
            ORDER BY e.created_at DESC
            LIMIT $limit
        """
        params["limit"] = limit

        result = conn.execute(query, params)
        edges: List[Dict[str, Any]] = []

        while result.has_next():
            row = result.get_next()
            edges.append({
                "older_id": row[0],
                "older_title": row[1],
                "older_content": (row[2] or "")[:200],
                "newer_id": row[3],
                "newer_title": row[4],
                "newer_content": (row[5] or "")[:200],
                "content_relation": row[6],
                "confidence": row[7],
                "detected_by": row[8],
                "reviewed": row[9],
                "reason": row[10],
                "created_at": str(row[11]) if row[11] else None,
            })

        return {
            "count": len(edges),
            "edges": edges,
        }

    except Exception as e:
        logger.error("Failed to get EVOLVES edges", error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to get edges: {e}")


# ------------------------------------------------------------------
# Include sub-routers (split files for pyarmor line limit)
# ------------------------------------------------------------------

from .agent_feed_events import router as feed_events_router
from .agent_feed_input import router as feed_input_router

router.include_router(feed_events_router)
router.include_router(feed_input_router)
