"""Bulk import API endpoints.

This module provides endpoints for:
- Detecting export file formats
- Parsing bulk exports to get thread summaries
- Importing selected threads from bulk exports
"""

import uuid
import structlog
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks
from pydantic import BaseModel, Field

from nowledge_graph_server.api.dependencies import get_thread_operations
from nowledge_graph_server.core.thread_operations import ThreadOperations
from nowledge_graph_server.services.bulk_export import (
    format_registry,
    initialize_registry,
    BulkParseResult,
)
from nowledge_graph_server.utils.progress_logger import log_data_change

logger = structlog.get_logger(__name__)

router = APIRouter()

# Ensure registry is initialized when module loads
_registry_initialized = False


def _ensure_registry_initialized():
    """Ensure the format registry is initialized."""
    global _registry_initialized
    if not _registry_initialized:
        try:
            initialize_registry()
            _registry_initialized = True
        except Exception as e:
            logger.warning("Registry initialization failed, will retry", error=str(e))


# =============================================================================
# Request/Response Models
# =============================================================================


class BulkParseRequest(BaseModel):
    """Request to parse a bulk export file."""

    file_path: str = Field(..., description="Path to the export file")
    format_id: Optional[str] = Field(
        default=None, description="Format ID (auto-detect if not provided)"
    )


class ThreadSummary(BaseModel):
    """Summary of a thread for preview/selection."""

    id: str = Field(..., description="Temporary ID (index-based)")
    title: str = Field(..., description="Thread title")
    message_count: int = Field(..., description="Number of messages")
    created_at: Optional[str] = Field(default=None, description="Creation timestamp")
    updated_at: Optional[str] = Field(default=None, description="Last update timestamp")
    first_message_preview: str = Field(
        default="", description="Preview of first message"
    )
    participants: List[str] = Field(
        default_factory=list, description="Participant roles"
    )


class BulkParseResponse(BaseModel):
    """Response from parsing a bulk export."""

    success: bool = Field(..., description="Whether parsing succeeded")
    format_id: str = Field(default="", description="Detected/used format ID")
    format_name: str = Field(default="", description="Human-readable format name")
    source: str = Field(default="", description="Source platform")
    threads: List[ThreadSummary] = Field(
        default_factory=list, description="Parsed thread summaries"
    )
    total_threads: int = Field(default=0, description="Total number of threads")
    total_messages: int = Field(
        default=0, description="Total messages across all threads"
    )
    warnings: List[str] = Field(default_factory=list, description="Non-fatal warnings")
    errors: List[str] = Field(default_factory=list, description="Parsing errors")


class BulkImportRequest(BaseModel):
    """Request to import selected threads from a bulk export."""

    file_path: str = Field(..., description="Path to the export file")
    format_id: str = Field(..., description="Format ID")
    selected_thread_indices: List[int] = Field(
        ..., description="Indices of threads to import"
    )


class BulkImportResponse(BaseModel):
    """Response from starting a bulk import."""

    success: bool = Field(..., description="Whether import started")
    job_id: str = Field(default="", description="Background job ID")
    message: str = Field(default="", description="Status message")
    imported_count: int = Field(default=0, description="Number of threads imported")
    errors: List[str] = Field(default_factory=list, description="Import errors")


class BulkImportProgressResponse(BaseModel):
    """Progress update for bulk import."""

    job_id: str
    current: int = Field(default=0, description="Current thread being processed")
    total: int = Field(default=0, description="Total threads to process")
    current_thread_title: str = Field(default="", description="Title of current thread")
    status: str = Field(
        default="pending",
        description="Job status: pending, processing, completed, error",
    )
    imported_count: int = Field(default=0, description="Successfully imported count")
    error: Optional[str] = Field(default=None, description="Error message if failed")


# =============================================================================
# In-memory job tracking (for progress updates)
# =============================================================================

_import_jobs: Dict[str, Dict[str, Any]] = {}


def _get_job(job_id: str) -> Optional[Dict[str, Any]]:
    """Get job status by ID."""
    return _import_jobs.get(job_id)


def _update_job(job_id: str, **kwargs):
    """Update job status."""
    if job_id in _import_jobs:
        _import_jobs[job_id].update(kwargs)


# =============================================================================
# Endpoints
# =============================================================================


@router.post("/threads/parse-bulk", response_model=BulkParseResponse)
async def parse_bulk_export(request: BulkParseRequest) -> BulkParseResponse:
    """Parse all threads from a bulk export file.

    This endpoint parses the export file and returns summaries of all
    threads found. The full thread content is not returned here to
    keep the response size manageable.
    """
    _ensure_registry_initialized()

    try:
        # Auto-detect format if not provided
        format_id = request.format_id
        format_name = ""
        source = ""

        if not format_id:
            detection = format_registry.detect_format(request.file_path)
            if not detection:
                return BulkParseResponse(
                    success=False,
                    errors=["Could not detect format. Please specify format_id."],
                )
            format_id = detection.format_id
            format_name = detection.format_name
            source = detection.source
        else:
            # Get format info from signature
            sig = format_registry.get_signature(format_id)
            if sig:
                format_name = sig.format_name
                source = sig.source

        # Check if parser is available
        if not format_registry.has_parser(format_id):
            return BulkParseResponse(
                success=False,
                format_id=format_id,
                format_name=format_name,
                source=source,
                errors=[f"No parser available for format: {format_id}"],
            )

        # Get parser and parse
        parser = format_registry.get_parser(format_id)
        if not parser:
            return BulkParseResponse(
                success=False,
                format_id=format_id,
                errors=["Failed to instantiate parser"],
            )

        logger.info(
            "Parsing bulk export", file_path=request.file_path, format_id=format_id
        )
        result: BulkParseResult = parser.parse(request.file_path)

        # Convert to response summaries
        summaries: List[ThreadSummary] = []
        for i, thread in enumerate(result.threads):
            # Get first message preview
            first_msg_preview = ""
            if thread.messages:
                first_msg = thread.messages[0]
                first_msg_preview = first_msg.content[:200]
                if len(first_msg.content) > 200:
                    first_msg_preview += "..."

            summaries.append(
                ThreadSummary(
                    id=str(i),
                    title=thread.title,
                    message_count=thread.message_count,
                    created_at=thread.export_info.split("|")[0]
                    .replace("Created:", "")
                    .strip()
                    if thread.export_info and "Created:" in thread.export_info
                    else None,
                    first_message_preview=first_msg_preview,
                    participants=thread.participants,
                )
            )

        return BulkParseResponse(
            success=True,
            format_id=format_id,
            format_name=format_name or result.source,
            source=source or result.source,
            threads=summaries,
            total_threads=len(result.threads),
            total_messages=result.total_messages,
            warnings=result.parse_warnings,
            errors=result.parse_errors,
        )

    except FileNotFoundError:
        return BulkParseResponse(
            success=False,
            errors=[f"File not found: {request.file_path}"],
        )
    except Exception as e:
        logger.error("Bulk parse failed", error=str(e), file_path=request.file_path)
        return BulkParseResponse(
            success=False,
            errors=[f"Parsing failed: {str(e)}"],
        )


@router.post("/threads/import-bulk", response_model=BulkImportResponse)
async def import_bulk_threads(
    request: BulkImportRequest,
    background_tasks: BackgroundTasks,
    thread_ops: ThreadOperations = Depends(get_thread_operations),
) -> BulkImportResponse:
    """Import selected threads from a bulk export.

    This endpoint starts a background import job and returns immediately.
    Use the job_id to poll for progress.
    """
    _ensure_registry_initialized()

    try:
        # Validate format
        if not format_registry.has_parser(request.format_id):
            return BulkImportResponse(
                success=False,
                errors=[f"Unknown format: {request.format_id}"],
            )

        # Validate thread indices
        if not request.selected_thread_indices:
            return BulkImportResponse(
                success=False,
                errors=["No threads selected for import"],
            )

        # Generate job ID
        job_id = str(uuid.uuid4())

        # Initialize job tracking
        _import_jobs[job_id] = {
            "status": "pending",
            "current": 0,
            "total": len(request.selected_thread_indices),
            "current_thread_title": "",
            "imported_count": 0,
            "errors": [],
        }

        # Queue background job
        background_tasks.add_task(
            _run_bulk_import,
            job_id=job_id,
            file_path=request.file_path,
            format_id=request.format_id,
            thread_indices=request.selected_thread_indices,
            thread_ops=thread_ops,
        )

        logger.info(
            "Bulk import started",
            job_id=job_id,
            file_path=request.file_path,
            thread_count=len(request.selected_thread_indices),
        )

        return BulkImportResponse(
            success=True,
            job_id=job_id,
            message=f"Import started for {len(request.selected_thread_indices)} threads",
        )

    except Exception as e:
        logger.error("Failed to start bulk import", error=str(e))
        return BulkImportResponse(
            success=False,
            errors=[f"Failed to start import: {str(e)}"],
        )


@router.get(
    "/threads/import-bulk/{job_id}/status", response_model=BulkImportProgressResponse
)
async def get_import_status(job_id: str) -> BulkImportProgressResponse:
    """Get the status of a bulk import job."""
    job = _get_job(job_id)

    if not job:
        raise HTTPException(status_code=404, detail=f"Job not found: {job_id}")

    return BulkImportProgressResponse(
        job_id=job_id,
        current=job.get("current", 0),
        total=job.get("total", 0),
        current_thread_title=job.get("current_thread_title", ""),
        status=job.get("status", "unknown"),
        imported_count=job.get("imported_count", 0),
        error=job.get("error"),
    )


# =============================================================================
# Background Import Task
# =============================================================================


async def _run_bulk_import(
    job_id: str,
    file_path: str,
    format_id: str,
    thread_indices: List[int],
    thread_ops: ThreadOperations,
):
    """Run the bulk import in the background.

    This function:
    1. Parses the export file
    2. Imports each selected thread
    3. Updates job progress
    """
    try:
        _update_job(job_id, status="processing")

        # Get parser and parse file
        parser = format_registry.get_parser(format_id)
        if not parser:
            _update_job(job_id, status="error", error=f"Parser not found: {format_id}")
            return

        parse_result = parser.parse(file_path)

        imported_count = 0
        errors: List[str] = []

        for i, thread_idx in enumerate(thread_indices):
            try:
                # Validate index
                if thread_idx < 0 or thread_idx >= len(parse_result.threads):
                    errors.append(f"Invalid thread index: {thread_idx}")
                    continue

                thread = parse_result.threads[thread_idx]

                # Update progress
                _update_job(
                    job_id,
                    current=i + 1,
                    current_thread_title=thread.title,
                )

                # Generate unique thread ID
                thread_id = f"bulk-import-{job_id[:8]}-{thread_idx}"

                # Convert messages to the format expected by thread_ops
                messages = [
                    {
                        "content": msg.content,
                        "role": "user"
                        if msg.speaker == "user"
                        else "assistant"
                        if msg.speaker == "assistant"
                        else msg.speaker,
                        "timestamp": msg.timestamp,
                    }
                    for msg in thread.messages
                ]

                # Create thread
                await thread_ops.create_thread(
                    thread_id=thread_id,
                    messages=messages,
                    title=thread.title,
                    source=thread.source,
                    participants=thread.participants,
                    auto_extract_memories=False,
                )

                # Notify UI of data change (bulk import creates threads)
                log_data_change(
                    change_type="thread_created",
                    entity_type="thread",
                    entity_id=thread_id,
                    details={"source": "bulk_import"},
                )

                imported_count += 1
                _update_job(job_id, imported_count=imported_count)

                logger.debug(
                    "Imported thread",
                    thread_id=thread_id,
                    title=thread.title,
                    messages=len(messages),
                )

            except Exception as e:
                error_msg = f"Thread {thread_idx}: {str(e)}"
                errors.append(error_msg)
                logger.warning(
                    "Failed to import thread", thread_idx=thread_idx, error=str(e)
                )

        # Mark job as completed
        _update_job(
            job_id,
            status="completed",
            imported_count=imported_count,
            errors=errors if errors else None,
        )

        logger.info(
            "Bulk import completed",
            job_id=job_id,
            imported=imported_count,
            errors=len(errors),
        )

    except Exception as e:
        logger.error("Bulk import failed", job_id=job_id, error=str(e))
        _update_job(job_id, status="error", error=str(e))
