"""Source (Library) API endpoints.

Endpoints:
- POST /sources/ingest/file          — upload/ingest a file through the full pipeline
- POST /sources/ingest/url           — fetch and ingest a URL
- GET  /sources                      — list sources with optional filtering
- GET  /sources/search               — FTS search across sources
- GET  /sources/{source_id}          — get source detail with relationships
- GET  /sources/{source_id}/content  — read parsed content for preview
- GET  /sources/{source_id}/images/{filename} — serve extracted image
- PATCH /sources/{source_id}         — update lifecycle state (re-parse, mark stale)
- DELETE /sources/{source_id}        — delete a source and its index records
"""

import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog
from fastapi import APIRouter, BackgroundTasks, Depends, File, HTTPException, Query, UploadFile
from pydantic import BaseModel, Field

from nowledge_graph_server.api.dependencies import get_kuzu_client
from nowledge_graph_server.database.kuzu_client import KuzuClient
from nowledge_graph_server.utils.progress_logger import log_data_change

logger = structlog.get_logger(__name__)

router = APIRouter()


# =============================================================================
# Request/Response Models
# =============================================================================


class SourceResponse(BaseModel):
    """Source node as returned by the API."""

    id: str
    source_type: str
    original_name: str
    mime_type: Optional[str] = None
    file_path: Optional[str] = None
    parsed_path: Optional[str] = None
    source_url: Optional[str] = None
    sha256: Optional[str] = None
    size_bytes: int = 0
    version: int = 1
    lifecycle_state: str = "ingested"
    chunk_count: int = 0
    memory_count: int = 0
    section_tree: Optional[str] = None
    summary: Optional[str] = None
    error_message: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class SourceListResponse(BaseModel):
    """Paginated list of sources."""

    sources: List[SourceResponse]
    total: int


class SourceDetailResponse(BaseModel):
    """Source detail with relationships."""

    source: SourceResponse
    memories: List[Dict[str, Any]] = Field(default_factory=list)
    revisions: List[Dict[str, Any]] = Field(default_factory=list)


class IngestFileRequest(BaseModel):
    """Request body for file ingestion (metadata only — file sent as multipart)."""

    user_comment: Optional[str] = Field(None, description="User comment about the file")


class IngestFilePathRequest(BaseModel):
    """Request body for path-based file ingestion (desktop app — local filesystem)."""

    file_path: str = Field(..., description="Absolute path to the file on disk")
    user_comment: Optional[str] = Field(None, description="User comment about the file")


class IngestUrlRequest(BaseModel):
    """Request body for URL ingestion."""

    url: str = Field(..., description="URL to fetch and ingest")
    user_comment: Optional[str] = Field(None, description="User comment about the URL")


class IngestResponse(BaseModel):
    """Response from ingestion endpoints."""

    source_id: str
    original_name: str
    lifecycle_state: str
    is_duplicate: bool = False
    message: str = ""


class SourceContentResponse(BaseModel):
    """Parsed content for preview."""

    source_id: str
    original_name: str
    content: str
    content_type: str = "markdown"  # Always markdown — parsed by markitdown


class SourceSearchResponse(BaseModel):
    """Search results for sources."""

    results: List[Dict[str, Any]]
    total: int


class UpdateSourceRequest(BaseModel):
    """Request to update source lifecycle."""

    action: str = Field(
        ...,
        description="Action: 'reparse' to re-parse, 'mark_stale' to mark as stale",
    )


# =============================================================================
# Helpers
# =============================================================================


def _source_node_to_response(source) -> SourceResponse:
    """Convert a SourceNode to API response."""
    return SourceResponse(
        id=source.id,
        source_type=source.source_type,
        original_name=source.original_name,
        mime_type=source.mime_type,
        file_path=source.file_path,
        parsed_path=source.parsed_path,
        source_url=source.source_url,
        sha256=source.sha256,
        size_bytes=source.size_bytes,
        version=source.version,
        lifecycle_state=source.lifecycle_state,
        chunk_count=source.chunk_count,
        memory_count=source.memory_count,
        section_tree=source.section_tree,
        summary=source.summary,
        error_message=source.error_message,
        created_at=source.created_at.isoformat() if source.created_at else None,
        updated_at=source.updated_at.isoformat() if source.updated_at else None,
        metadata=source.metadata if isinstance(source.metadata, dict) else None,
    )


# =============================================================================
# Endpoints
# =============================================================================


@router.post("/sources/ingest/file", response_model=IngestResponse)
async def ingest_file(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    user_comment: Optional[str] = None,
    client: KuzuClient = Depends(get_kuzu_client),
) -> IngestResponse:
    """Ingest a file through the full source pipeline.

    Accepts a multipart file upload. The file is saved to a temp location,
    then processed through ingest → parse → chunk → index.
    """
    if not file.filename:
        raise HTTPException(status_code=400, detail="No filename provided")

    # Save uploaded file to temp location
    tmp_dir = Path(tempfile.mkdtemp(prefix="nowledge_source_"))
    tmp_path = tmp_dir / file.filename
    try:
        with open(tmp_path, "wb") as f:
            content = await file.read()
            f.write(content)
    except Exception as e:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        raise HTTPException(status_code=500, detail=f"Failed to save uploaded file: {e}")

    try:
        from nowledge_graph_server.services.source_pipeline import SourcePipeline

        pipeline = SourcePipeline(db_client=client)
        metadata = {}
        if user_comment:
            metadata["user_comment"] = user_comment

        source = await pipeline.ingest_file(
            file_path=tmp_path,
            user_comment=user_comment,
            metadata=metadata if metadata else None,
        )

        is_duplicate = source.lifecycle_state != "error" and source.version == 1 and source.chunk_count == 0
        # Actually check if it was a dedup hit — if the returned source existed before this call
        # The pipeline returns existing source on dedup, so check if created_at is recent
        now = datetime.now(timezone.utc)
        is_duplicate = False
        if source.created_at:
            age = (now - source.created_at).total_seconds()
            is_duplicate = age > 5  # If older than 5 seconds, it was pre-existing

        # Always emit feed event (even for duplicates — user sees "File recognized")
        from nowledge_graph_server.utils.feed_events import emit_feed_event

        emit_feed_event(
            event_type="source_ingested",
            title=f"File added: {source.original_name}" if not is_duplicate else f"File recognized: {source.original_name}",
            description=(
                f"Processed {source.original_name} — {source.lifecycle_state}" if not is_duplicate
                else f"Already in library: {source.original_name}"
            ),
            severity="info",
            metadata={
                "source_id": source.id,
                "source_type": "file",
                "original_name": source.original_name,
                "lifecycle_state": source.lifecycle_state,
                "chunk_count": source.chunk_count,
                "is_duplicate": is_duplicate,
            },
        )

        log_data_change(
            change_type="source_created",
            entity_type="source",
            entity_id=source.id,
            details={"source_type": "file", "name": source.original_name},
        )

        message = "File ingested successfully"
        if source.lifecycle_state == "error":
            message = f"Ingestion error: {source.error_message}"
        elif is_duplicate:
            message = "Duplicate file detected — returning existing source"

        return IngestResponse(
            source_id=source.id,
            original_name=source.original_name,
            lifecycle_state=source.lifecycle_state,
            is_duplicate=is_duplicate,
            message=message,
        )

    except Exception as e:
        logger.error("File ingestion failed", error=str(e), filename=file.filename)
        raise HTTPException(status_code=500, detail=f"File ingestion failed: {e}")
    finally:
        # Clean up temp file
        shutil.rmtree(tmp_dir, ignore_errors=True)


@router.post("/sources/ingest/file-path", response_model=IngestResponse)
async def ingest_file_path(
    request: IngestFilePathRequest,
    client: KuzuClient = Depends(get_kuzu_client),
) -> IngestResponse:
    """Ingest a file by local filesystem path (desktop app bridge).

    Unlike the multipart upload endpoint, this accepts a path to a file
    already on disk. Used by the Tauri desktop app.
    """
    file_path = Path(request.file_path)
    if not file_path.exists():
        raise HTTPException(status_code=400, detail=f"File not found: {request.file_path}")

    try:
        from nowledge_graph_server.services.source_pipeline import SourcePipeline

        pipeline = SourcePipeline(db_client=client)
        metadata = {}
        if request.user_comment:
            metadata["user_comment"] = request.user_comment

        source = await pipeline.ingest_file(
            file_path=file_path,
            user_comment=request.user_comment,
            metadata=metadata if metadata else None,
        )

        now = datetime.now(timezone.utc)
        is_duplicate = False
        if source.created_at:
            age = (now - source.created_at).total_seconds()
            is_duplicate = age > 5

        # Always emit feed event (even for duplicates — user sees "File recognized")
        from nowledge_graph_server.utils.feed_events import emit_feed_event

        emit_feed_event(
            event_type="source_ingested",
            title=f"File added: {source.original_name}" if not is_duplicate else f"File recognized: {source.original_name}",
            description=(
                f"Processed {source.original_name} — {source.lifecycle_state}" if not is_duplicate
                else f"Already in library: {source.original_name}"
            ),
            severity="info",
            metadata={
                "source_id": source.id,
                "source_type": "file",
                "original_name": source.original_name,
                "lifecycle_state": source.lifecycle_state,
                "chunk_count": source.chunk_count,
                "is_duplicate": is_duplicate,
            },
        )

        log_data_change(
            change_type="source_created",
            entity_type="source",
            entity_id=source.id,
            details={"source_type": "file", "name": source.original_name},
        )

        message = "File ingested successfully"
        if source.lifecycle_state == "error":
            message = f"Ingestion error: {source.error_message}"
        elif is_duplicate:
            message = "Duplicate file detected — returning existing source"

        return IngestResponse(
            source_id=source.id,
            original_name=source.original_name,
            lifecycle_state=source.lifecycle_state,
            is_duplicate=is_duplicate,
            message=message,
        )

    except Exception as e:
        logger.error("File path ingestion failed", error=str(e), path=request.file_path)
        raise HTTPException(status_code=500, detail=f"File ingestion failed: {e}")


@router.post("/sources/ingest/url", response_model=IngestResponse)
async def ingest_url(
    request: IngestUrlRequest,
    client: KuzuClient = Depends(get_kuzu_client),
) -> IngestResponse:
    """Fetch a URL and ingest through the source pipeline.

    Uses browse-now for authenticated content, falls back to httpx.
    """
    if not request.url:
        raise HTTPException(status_code=400, detail="URL is required")

    try:
        from nowledge_graph_server.services.source_pipeline import SourcePipeline

        pipeline = SourcePipeline(db_client=client)
        metadata = {}
        if request.user_comment:
            metadata["user_comment"] = request.user_comment

        source = await pipeline.ingest_url(
            url=request.url,
            user_comment=request.user_comment,
            metadata=metadata if metadata else None,
        )

        # Check for duplicate
        now = datetime.now(timezone.utc)
        is_duplicate = False
        if source.created_at:
            age = (now - source.created_at).total_seconds()
            is_duplicate = age > 5

        # Always emit feed event (even for duplicates — user sees "URL recognized")
        from nowledge_graph_server.utils.feed_events import emit_feed_event

        emit_feed_event(
            event_type="source_ingested",
            title=f"URL added: {source.original_name}" if not is_duplicate else f"URL recognized: {source.original_name}",
            description=(
                f"Fetched and processed {request.url} — {source.lifecycle_state}" if not is_duplicate
                else f"Already in library: {source.original_name}"
            ),
            severity="info",
            metadata={
                "source_id": source.id,
                "source_type": "url",
                "original_name": source.original_name,
                "source_url": request.url,
                "lifecycle_state": source.lifecycle_state,
                "chunk_count": source.chunk_count,
                "is_duplicate": is_duplicate,
            },
        )

        log_data_change(
            change_type="source_created",
            entity_type="source",
            entity_id=source.id,
            details={"source_type": "url", "url": request.url},
        )

        message = "URL ingested successfully"
        if source.lifecycle_state == "error":
            message = f"Ingestion error: {source.error_message}"
        elif is_duplicate:
            message = "Duplicate URL content detected — returning existing source"

        return IngestResponse(
            source_id=source.id,
            original_name=source.original_name,
            lifecycle_state=source.lifecycle_state,
            is_duplicate=is_duplicate,
            message=message,
        )

    except Exception as e:
        logger.error("URL ingestion failed", error=str(e), url=request.url)
        raise HTTPException(status_code=500, detail=f"URL ingestion failed: {e}")


@router.get("/sources", response_model=SourceListResponse)
async def list_sources(
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    source_type: Optional[str] = Query(None, description="Filter by source_type"),
    lifecycle_state: Optional[str] = Query(None, description="Filter by lifecycle_state"),
    client: KuzuClient = Depends(get_kuzu_client),
) -> SourceListResponse:
    """List sources with optional filtering and pagination."""
    try:
        sources = await client.source_repo.list_sources(
            limit=limit,
            offset=offset,
            source_type=source_type,
            lifecycle_state=lifecycle_state,
        )
        total = await client.source_repo.count_sources(
            source_type=source_type,
            lifecycle_state=lifecycle_state,
        )

        return SourceListResponse(
            sources=[_source_node_to_response(s) for s in sources],
            total=total,
        )

    except Exception as e:
        logger.error("Failed to list sources", error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to list sources: {e}")


@router.get("/sources/search", response_model=SourceSearchResponse)
async def search_sources(
    q: str = Query(..., min_length=1, description="Search query"),
    limit: int = Query(default=20, ge=1, le=100),
    client: KuzuClient = Depends(get_kuzu_client),
) -> SourceSearchResponse:
    """Full-text search across source names and content."""
    try:
        from nowledge_graph_server.services.search_index.service_factory import get_search_index_service

        search_service = await get_search_index_service()
        if not search_service:
            raise HTTPException(status_code=503, detail="Search index not available")
        results = await search_service.search_sources_fts(q, limit=limit)

        items = []
        for r in results:
            items.append({
                "source_id": r.id,
                "score": r.score,
                "title": r.metadata.get("original_name", "") if r.metadata else "",
                "snippet": (r.text or "")[:200],
                "source_type": r.metadata.get("source_type", "") if r.metadata else "",
                "lifecycle_state": r.metadata.get("lifecycle_state", "") if r.metadata else "",
            })

        return SourceSearchResponse(results=items, total=len(items))

    except Exception as e:
        logger.error("Source search failed", query=q, error=str(e))
        raise HTTPException(status_code=500, detail=f"Source search failed: {e}")


@router.get("/sources/{source_id}", response_model=SourceDetailResponse)
async def get_source_detail(
    source_id: str,
    client: KuzuClient = Depends(get_kuzu_client),
) -> SourceDetailResponse:
    """Get source detail with related memories and revision chain."""
    try:
        source = await client.source_repo.get_source(source_id)
        if not source:
            raise HTTPException(status_code=404, detail=f"Source not found: {source_id}")

        # Get related memories (repo returns: memory_id, title, content, chunk_index, chunk_range, unit_type, confidence)
        memories = await client.source_repo.get_source_memories(source_id)
        memory_list = [
            {
                "id": m.get("memory_id", ""),
                "title": m.get("title", ""),
                "content": (m.get("content") or "")[:200],
                "chunk_index": m.get("chunk_index"),
                "chunk_range": m.get("chunk_range", ""),
                "unit_type": m.get("unit_type", "fact"),
                "confidence": m.get("confidence", 0.5),
            }
            for m in memories
        ]

        # Get revision chain (repo returns: id, name, version, sha256, created_at)
        revisions = await client.source_repo.get_revision_chain(source_id)
        revision_list = [
            {
                "id": r.get("id", ""),
                "version": r.get("version", 1),
                "original_name": r.get("name", ""),
                "sha256": r.get("sha256", ""),
                "created_at": str(r.get("created_at", "")),
            }
            for r in revisions
        ]

        return SourceDetailResponse(
            source=_source_node_to_response(source),
            memories=memory_list,
            revisions=revision_list,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to get source detail", source_id=source_id, error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to get source: {e}")


@router.get("/sources/{source_id}/content", response_model=SourceContentResponse)
async def get_source_content(
    source_id: str,
    client: KuzuClient = Depends(get_kuzu_client),
) -> SourceContentResponse:
    """Read the parsed content of a source for preview.

    Returns the markdown content produced by markitdown during parsing.
    Works uniformly for files, URLs, and notes — all store parsed .md on disk.
    """
    source = await client.source_repo.get_source(source_id)
    if not source:
        raise HTTPException(status_code=404, detail=f"Source not found: {source_id}")

    if not source.parsed_path:
        raise HTTPException(
            status_code=404,
            detail="Source has not been parsed yet",
        )

    parsed = Path(source.parsed_path).resolve()

    # Path traversal guard: parsed content must be within the sources storage dir
    from nowledge_graph_server.agent.paths import get_sources_home

    sources_home = get_sources_home().resolve()
    if not parsed.is_relative_to(sources_home):
        logger.warning(
            "Path traversal attempt blocked",
            source_id=source_id,
            parsed_path=str(parsed),
        )
        raise HTTPException(status_code=403, detail="Access denied")

    if not parsed.exists():
        raise HTTPException(
            status_code=404,
            detail="Parsed content file not found on disk",
        )

    try:
        content = parsed.read_text(encoding="utf-8")

        # Rewrite relative image paths to absolute URLs so the frontend can load them
        import re as _re

        content = _re.sub(
            r"!\[([^\]]*)\]\(images/([^)]+)\)",
            rf"![\1](http://127.0.0.1:14242/sources/{source_id}/images/\2)",
            content,
        )

        return SourceContentResponse(
            source_id=source_id,
            original_name=source.original_name,
            content=content,
        )
    except Exception as e:
        logger.error("Failed to read source content", source_id=source_id, error=str(e))
        raise HTTPException(status_code=500, detail="Failed to read content")


@router.get("/sources/{source_id}/images/{filename}")
async def get_source_image(source_id: str, filename: str) -> Any:
    """Serve an extracted image from a source's images/ directory."""
    from fastapi.responses import FileResponse

    from nowledge_graph_server.agent.paths import get_sources_home

    # Sanitize filename — no path traversal
    if "/" in filename or "\\" in filename or ".." in filename:
        raise HTTPException(status_code=400, detail="Invalid filename")

    sources_home = get_sources_home().resolve()
    image_path = (sources_home / source_id / "images" / filename).resolve()

    # Verify the resolved path is within sources_home
    if not image_path.is_relative_to(sources_home):
        raise HTTPException(status_code=403, detail="Access denied")

    if not image_path.exists():
        raise HTTPException(status_code=404, detail="Image not found")

    # Infer media type from extension
    ext = image_path.suffix.lower()
    media_types = {
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".svg": "image/svg+xml",
        ".webp": "image/webp",
        ".emf": "image/emf",
        ".wmf": "image/wmf",
        ".tiff": "image/tiff",
        ".bmp": "image/bmp",
    }
    media_type = media_types.get(ext, "application/octet-stream")

    return FileResponse(image_path, media_type=media_type)


@router.get("/sources/{source_id}/raw")
async def get_source_raw(
    source_id: str,
    client: KuzuClient = Depends(get_kuzu_client),
) -> Any:
    """Serve the raw source file for native preview (PDF, DOCX, etc)."""
    from fastapi.responses import FileResponse

    from nowledge_graph_server.agent.paths import get_sources_home

    source = await client.source_repo.get_source(source_id)
    if not source:
        raise HTTPException(status_code=404, detail=f"Source not found: {source_id}")

    if not source.file_path:
        raise HTTPException(status_code=404, detail="Source has no raw file stored")

    raw_path = Path(source.file_path).resolve()
    sources_home = get_sources_home().resolve()

    if not raw_path.is_relative_to(sources_home):
        raise HTTPException(status_code=403, detail="Access denied")

    if not raw_path.exists():
        raise HTTPException(status_code=404, detail="Raw file not found on disk")

    media_type = source.mime_type or "application/octet-stream"
    return FileResponse(
        raw_path,
        media_type=media_type,
        filename=source.original_name,
    )


@router.post("/sources/{source_id}/extract")
async def trigger_source_extraction(
    source_id: str,
    client: KuzuClient = Depends(get_kuzu_client),
) -> Dict[str, str]:
    """Trigger knowledge extraction from a source (Learn lifecycle).

    User clicks 'Learn' button on a source in the Library.
    Queues a source_extraction task for the Knowledge Agent.
    Returns 202-style response immediately (task runs in background).
    """
    source = await client.source_repo.get_source(source_id)
    if not source:
        raise HTTPException(status_code=404, detail=f"Source not found: {source_id}")

    if source.lifecycle_state not in ("indexed", "extracted"):
        raise HTTPException(
            status_code=400,
            detail=f"Source must be indexed before extraction (current: {source.lifecycle_state})",
        )

    # Get agent manager and queue extraction task
    from .agent import _get_agent_manager

    manager = _get_agent_manager()
    if manager is None or not manager.is_running:
        raise HTTPException(status_code=503, detail="Knowledge Agent is not running")

    await manager.trigger_source_extraction(source_id, source.original_name, source.mime_type)
    return {"status": "queued", "task": "source_extraction", "source_id": source_id}


@router.post("/sources/{source_id}/refetch")
async def refetch_source(
    source_id: str,
    client: KuzuClient = Depends(get_kuzu_client),
) -> Dict[str, str]:
    """Re-fetch a URL source's content using the browser and re-parse.

    Useful when the initial fetch captured an SPA shell or stale content.
    Only works for URL-type sources.
    """
    source = await client.source_repo.get_source(source_id)
    if not source:
        raise HTTPException(status_code=404, detail=f"Source not found: {source_id}")

    if source.source_type != "url" or not source.source_url:
        raise HTTPException(status_code=400, detail="Re-fetch is only available for URL sources")

    try:
        from nowledge_graph_server.services.source_pipeline import SourcePipeline

        pipeline = SourcePipeline(db_client=client)
        updated_source = await pipeline.refetch_url(source_id, source.source_url)

        log_data_change(
            change_type="source_updated",
            entity_type="source",
            entity_id=source_id,
            details={"action": "refetch", "url": source.source_url},
        )

        return {
            "status": "ok",
            "source_id": source_id,
            "lifecycle_state": updated_source.lifecycle_state,
            "fetch_method": (updated_source.metadata or {}).get("fetch_method", "unknown"),
        }

    except Exception as e:
        logger.error("Re-fetch failed", source_id=source_id, error=str(e))
        raise HTTPException(status_code=500, detail=f"Re-fetch failed: {e}")


@router.patch("/sources/{source_id}", response_model=SourceResponse)
async def update_source(
    source_id: str,
    request: UpdateSourceRequest,
    client: KuzuClient = Depends(get_kuzu_client),
) -> SourceResponse:
    """Update source lifecycle state.

    Supported actions:
    - 'reparse': Re-run parse → chunk → index pipeline
    - 'mark_stale': Mark source as stale (needs re-processing)
    """
    source = await client.source_repo.get_source(source_id)
    if not source:
        raise HTTPException(status_code=404, detail=f"Source not found: {source_id}")

    if request.action == "mark_stale":
        await client.source_repo.update_lifecycle_state(source_id, "stale")
        source.lifecycle_state = "stale"

        log_data_change(
            change_type="source_updated",
            entity_type="source",
            entity_id=source_id,
            details={"action": "mark_stale"},
        )

        return _source_node_to_response(source)

    elif request.action == "reparse":
        try:
            from nowledge_graph_server.services.source_pipeline import SourcePipeline

            pipeline = SourcePipeline(db_client=client)

            # Re-run parse → chunk → index
            source = await pipeline._parse(source)
            if source.lifecycle_state != "error":
                source = await pipeline._chunk(source)
            if source.lifecycle_state != "error":
                source = await pipeline._index(source)

            log_data_change(
                change_type="source_updated",
                entity_type="source",
                entity_id=source_id,
                details={"action": "reparse", "state": source.lifecycle_state},
            )

            return _source_node_to_response(source)

        except Exception as e:
            logger.error("Reparse failed", source_id=source_id, error=str(e))
            raise HTTPException(status_code=500, detail=f"Reparse failed: {e}")

    else:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown action: {request.action}. Supported: reparse, mark_stale",
        )


@router.delete("/sources/{source_id}")
async def delete_source(
    source_id: str,
    client: KuzuClient = Depends(get_kuzu_client),
) -> Dict[str, Any]:
    """Delete a source and its search index records."""
    source = await client.source_repo.get_source(source_id)
    if not source:
        raise HTTPException(status_code=404, detail=f"Source not found: {source_id}")

    try:
        # Delete from search index
        from nowledge_graph_server.services.search_index.source_sync import delete_source_from_index

        await delete_source_from_index(source_id)

        # Delete filesystem artifacts (raw files, parsed markdown, images, meta)
        from nowledge_graph_server.services.source_storage import SourceStorageService

        storage = SourceStorageService()
        storage.delete_source_dir(source_id)

        # Delete from graph
        await client.source_repo.delete_source(source_id)

        log_data_change(
            change_type="source_deleted",
            entity_type="source",
            entity_id=source_id,
            details={"name": source.original_name},
        )

        return {"success": True, "message": f"Source {source_id} deleted"}

    except Exception as e:
        logger.error("Failed to delete source", source_id=source_id, error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to delete source: {e}")
