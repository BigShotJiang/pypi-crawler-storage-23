"""
Browser Bridge WebSocket Router

Provides WebSocket endpoint for browser automation via browse-now CLI.
Manages connections from browser extensions and CLI clients.

Architecture:
  browse-now CLI <-> WebSocket Server <-> Browser Extension
                    (this module)
"""

import asyncio
import ipaddress
import uuid
from datetime import datetime
from enum import Enum
from typing import Any, Mapping

import structlog
from fastapi import APIRouter, HTTPException, Request, WebSocket, WebSocketDisconnect
from pydantic import BaseModel, Field

from nowledge_graph_server.services.remote_access import is_local_request

logger = structlog.get_logger(__name__)

router = APIRouter(prefix="/browser-bridge", tags=["browser-bridge"])


# =============================================================================
# Models
# =============================================================================


class ClientType(str, Enum):
    """Type of WebSocket client."""
    BROWSER = "browser"
    CLI = "cli"


class BrowserInfo(BaseModel):
    """Browser extension information."""
    browser_id: str
    browser_name: str
    user_agent: str
    extension_version: str
    connected_at: datetime


class WSMessage(BaseModel):
    """WebSocket message format.

    Note: browser_id accepts both snake_case (Python) and camelCase (JavaScript).
    The extension sends 'browserId' but Pydantic normalizes it to 'browser_id'.
    """
    model_config = {"populate_by_name": True}

    id: str
    type: str
    browser_id: str | None = Field(default=None, alias="browserId")
    payload: Any = None


class WSResponse(BaseModel):
    """WebSocket response format."""
    id: str
    success: bool
    data: Any = None
    error: str | None = None


# =============================================================================
# Browser Registry
# =============================================================================


class BrowserRegistry:
    """Manages connected browser extensions."""

    def __init__(self):
        # browser_id -> (websocket, browser_info)
        self._browsers: dict[str, tuple[WebSocket, BrowserInfo]] = {}
        # websocket -> browser_id (reverse lookup)
        self._ws_to_browser: dict[WebSocket, str] = {}
        # CLI connections waiting for responses
        self._pending_requests: dict[str, asyncio.Future[WSResponse]] = {}
        # Lock for thread-safe operations
        self._lock = asyncio.Lock()

    async def register_browser(
        self,
        ws: WebSocket,
        browser_id: str,
        browser_name: str,
        user_agent: str,
        extension_version: str
    ) -> BrowserInfo:
        """Register a browser extension connection."""
        async with self._lock:
            info = BrowserInfo(
                browser_id=browser_id,
                browser_name=browser_name,
                user_agent=user_agent,
                extension_version=extension_version,
                connected_at=datetime.now()
            )
            self._browsers[browser_id] = (ws, info)
            self._ws_to_browser[ws] = browser_id
            logger.info(
                "Browser registered",
                browser_id=browser_id,
                browser_name=browser_name
            )
            return info

    async def unregister_browser(self, ws: WebSocket) -> str | None:
        """Unregister a browser by its WebSocket."""
        async with self._lock:
            browser_id = self._ws_to_browser.pop(ws, None)
            if browser_id:
                self._browsers.pop(browser_id, None)
                logger.info("Browser unregistered", browser_id=browser_id)
            return browser_id

    async def get_browser_ws(self, browser_id: str) -> WebSocket | None:
        """Get WebSocket for a browser ID."""
        async with self._lock:
            entry = self._browsers.get(browser_id)
            return entry[0] if entry else None

    async def get_browser_info(self, browser_id: str) -> BrowserInfo | None:
        """Get browser info by ID."""
        async with self._lock:
            entry = self._browsers.get(browser_id)
            return entry[1] if entry else None

    async def get_all_browsers(self) -> list[BrowserInfo]:
        """Get all connected browsers."""
        async with self._lock:
            return [info for _, info in self._browsers.values()]

    async def get_default_browser_id(self) -> str | None:
        """Get default browser ID (single connected or None)."""
        async with self._lock:
            if len(self._browsers) == 1:
                return next(iter(self._browsers.keys()))
            return None

    async def send_to_browser(
        self,
        browser_id: str | None,
        message: WSMessage,
        timeout: float = 30.0
    ) -> WSResponse:
        """Send message to browser and wait for response.

        Note: Screenshot commands use longer timeout (60s) due to large response size.
        """
        # Resolve browser ID
        if browser_id is None:
            browser_id = await self.get_default_browser_id()
            if browser_id is None:
                browsers = await self.get_all_browsers()
                if len(browsers) == 0:
                    return WSResponse(
                        id=message.id,
                        success=False,
                        error="No browser connected"
                    )
                else:
                    browser_names = [b.browser_name for b in browsers]
                    return WSResponse(
                        id=message.id,
                        success=False,
                        error=f"Multiple browsers connected: {browser_names}. Use --browser to select."
                    )

        ws = await self.get_browser_ws(browser_id)
        if not ws:
            return WSResponse(
                id=message.id,
                success=False,
                error=f"Browser not connected: {browser_id}"
            )

        # Create future for response
        future: asyncio.Future[WSResponse] = asyncio.Future()
        self._pending_requests[message.id] = future

        try:
            # Send message to browser
            await ws.send_json(message.model_dump())
            logger.debug(
                "Message sent to browser",
                browser_id=browser_id,
                message_type=message.type,
                message_id=message.id
            )

            # Wait for response with timeout
            response = await asyncio.wait_for(future, timeout=timeout)
            return response

        except asyncio.TimeoutError:
            return WSResponse(
                id=message.id,
                success=False,
                error=f"Request timed out after {timeout}s"
            )
        finally:
            self._pending_requests.pop(message.id, None)

    async def handle_browser_response(self, response: WSResponse) -> None:
        """Handle response from browser."""
        future = self._pending_requests.get(response.id)
        if future and not future.done():
            future.set_result(response)
            logger.debug(
                "Response received from browser",
                message_id=response.id,
                success=response.success
            )


# Global registry instance
browser_registry = BrowserRegistry()


# =============================================================================
# Security Guards
# =============================================================================


def _has_tunnel_markers(headers: Mapping[str, str]) -> bool:
    return bool(headers.get("cf-connecting-ip") or headers.get("cf-ray"))


def _is_loopback_host(host: str | None) -> bool:
    if not host:
        return False
    if host in {"localhost", "127.0.0.1", "::1"}:
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def is_local_browser_bridge_http_request(request: Request) -> bool:
    if _has_tunnel_markers(request.headers):
        return False
    return is_local_request(request)


def is_local_browser_bridge_ws_connection(websocket: WebSocket) -> bool:
    if _has_tunnel_markers(websocket.headers):
        return False
    host = websocket.client.host if websocket.client else None
    return _is_loopback_host(host)


def _assert_local_browser_bridge_http(request: Request) -> None:
    if not is_local_browser_bridge_http_request(request):
        raise HTTPException(
            status_code=403,
            detail=(
                "Browser bridge endpoints are local-only and unavailable "
                "through remote access."
            ),
        )


# =============================================================================
# WebSocket Endpoint
# =============================================================================


@router.websocket("/ws")
async def browser_bridge_websocket(websocket: WebSocket):
    """
    WebSocket endpoint for browser bridge communication.

    Supports two client types:
    1. Browser extensions - Send identification on connect, receive commands
    2. CLI clients - Send commands, receive responses

    Protocol:
    - First message identifies client type
    - Browser: { "type": "browser_connect", "browserId": "...", "payload": {...} }
    - CLI: { "type": "command", "payload": {...} }
    """
    if not is_local_browser_bridge_ws_connection(websocket):
        client_host = websocket.client.host if websocket.client else "unknown"
        logger.warning(
            "Rejected non-local browser bridge websocket",
            client_host=client_host,
            has_cf_connecting_ip=bool(websocket.headers.get("cf-connecting-ip")),
            has_cf_ray=bool(websocket.headers.get("cf-ray")),
        )
        await websocket.close(
            code=1008,
            reason="Browser bridge is local-only",
        )
        return

    await websocket.accept()
    logger.info("WebSocket connection accepted")

    client_type: ClientType | None = None
    browser_id: str | None = None

    try:
        while True:
            data = await websocket.receive_json()
            message = WSMessage(**data)

            # Handle browser identification
            if message.type == "browser_connect":
                client_type = ClientType.BROWSER
                payload = message.payload or {}
                browser_id = message.browser_id or str(uuid.uuid4())

                await browser_registry.register_browser(
                    ws=websocket,
                    browser_id=browser_id,
                    browser_name=payload.get("browserName", "Unknown"),
                    user_agent=payload.get("userAgent", ""),
                    extension_version=payload.get("extensionVersion", "0.0.0")
                )

                # Send acknowledgment
                await websocket.send_json({
                    "id": message.id,
                    "success": True,
                    "data": {"message": "Browser registered", "browserId": browser_id}
                })

            # Handle browser disconnect
            elif message.type == "browser_disconnect":
                logger.info("Browser disconnecting", browser_id=message.browser_id)
                break

            # Handle response from browser (to CLI request)
            elif message.type == "response" or (client_type == ClientType.BROWSER and "success" in data):
                # This is a response from browser to a pending CLI request
                response = WSResponse(
                    id=message.id,
                    success=data.get("success", False),
                    data=data.get("data"),
                    error=data.get("error")
                )
                await browser_registry.handle_browser_response(response)

            # Handle command from CLI
            elif message.type == "command":
                client_type = ClientType.CLI
                # Use longer timeout for screenshot command (large response)
                payload = message.payload or {}
                action = payload.get("action", "")
                timeout = 60.0 if action == "screenshot" else 30.0

                logger.debug("Forwarding command to browser", action=action, timeout=timeout)

                # Forward command to browser
                response = await browser_registry.send_to_browser(
                    browser_id=message.browser_id,
                    message=message,
                    timeout=timeout
                )

                # Log response size for debugging large payloads
                response_dict = response.model_dump()
                response_size = len(str(response_dict))
                if response_size > 100000:  # > 100KB
                    logger.info(
                        "Large response",
                        action=action,
                        response_size_kb=response_size // 1024,
                        success=response.success
                    )

                await websocket.send_json(response_dict)

            # Handle ping from CLI
            elif message.type == "ping":
                await websocket.send_json({
                    "id": message.id,
                    "success": True,
                    "data": "pong"
                })

            # Handle list browsers from CLI
            elif message.type == "list_browsers":
                browsers = await browser_registry.get_all_browsers()
                await websocket.send_json({
                    "id": message.id,
                    "success": True,
                    "data": {
                        # Use mode='json' to serialize datetime to ISO string
                        "browsers": [b.model_dump(mode='json') for b in browsers],
                        "count": len(browsers)
                    }
                })

            else:
                logger.warning("Unknown message type", message_type=message.type)
                await websocket.send_json({
                    "id": message.id,
                    "success": False,
                    "error": f"Unknown message type: {message.type}"
                })

    except WebSocketDisconnect:
        logger.info("WebSocket disconnected", client_type=client_type, browser_id=browser_id)
    except Exception as e:
        logger.error("WebSocket error", error=str(e))
    finally:
        # Clean up browser registration
        if client_type == ClientType.BROWSER:
            await browser_registry.unregister_browser(websocket)


# =============================================================================
# REST Endpoints (for debugging/monitoring)
# =============================================================================


@router.get("/browsers", include_in_schema=False)
async def list_browsers(request: Request):
    """List all connected browsers."""
    _assert_local_browser_bridge_http(request)
    browsers = await browser_registry.get_all_browsers()
    return {
        "browsers": [b.model_dump() for b in browsers],
        "count": len(browsers)
    }


@router.get("/status", include_in_schema=False)
async def bridge_status(request: Request):
    """Get browser bridge status."""
    _assert_local_browser_bridge_http(request)
    browsers = await browser_registry.get_all_browsers()
    default_browser = await browser_registry.get_default_browser_id()
    return {
        "connected_browsers": len(browsers),
        "default_browser": default_browser,
        "browsers": [
            {
                "id": b.browser_id,
                "name": b.browser_name,
                "connected_at": b.connected_at.isoformat()
            }
            for b in browsers
        ]
    }
