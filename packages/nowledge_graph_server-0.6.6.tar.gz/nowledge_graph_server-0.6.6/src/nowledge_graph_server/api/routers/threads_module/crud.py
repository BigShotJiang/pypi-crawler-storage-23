"""Thread CRUD operations (Create, Read, Update, Delete)."""

from typing import Optional, Dict, Any, List
import json
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, Depends, Query

import structlog

from nowledge_graph_server.api.dependencies import (
    get_kuzu_client,
    get_thread_operations,
)
from nowledge_graph_server.database.kuzu_client import KuzuClient
from nowledge_graph_server.database.thread_repository import ThreadRepository
from nowledge_graph_server.core.thread_operations import ThreadOperations
from nowledge_graph_server.models import (
    ThreadCreateResponse,
    ThreadCreateRequest,
    ThreadFetchResponse,
)
from nowledge_graph_server.utils.progress_logger import log_data_change

from .schemas import (
    ThreadFromFileResponse,
    AppendMessagesResponse,
    ThreadPublic,
    ThreadPaginationInfo,
    ThreadListResponse,
    ThreadCoverageResponse,
    DeleteThreadResponse,
    BulkDeleteThreadsRequest,
    BulkDeleteThreadsResponse,
)


logger = structlog.get_logger(__name__)

router = APIRouter()


# =========================================================================
# Thread Creation Endpoints
# =========================================================================


@router.post("/threads", response_model=ThreadCreateResponse)
async def create_thread(
    request: ThreadCreateRequest,
    thread_ops: ThreadOperations = Depends(get_thread_operations),
) -> ThreadCreateResponse:
    """Create a new thread with messages."""
    try:
        response = await thread_ops.create_thread(
            thread_id=request.thread_id,
            messages=[msg.model_dump() for msg in request.messages],
            title=request.title,
            participants=request.participants,
            source=request.source,
            project=request.project,
            workspace=request.workspace,
            tool_version=request.tool_version,
            metadata=request.metadata,
            auto_extract_memories=False,  # Default to False for imports
        )

        # Notify UI of data change
        log_data_change(
            change_type="thread_created",
            entity_type="thread",
            entity_id=response.thread.thread_id,
        )

        # Trigger Knowledge Agent thread analysis (fire-and-forget)
        try:
            import asyncio
            from nowledge_graph_server.agent.manager import get_agent_manager
            mgr = get_agent_manager()
            if mgr and mgr.is_running:
                asyncio.create_task(mgr.on_thread_synced(
                    response.thread.thread_id,
                    title=response.thread.title,
                    source=request.source,
                    message_count=len(response.messages),
                ))
        except Exception:
            pass  # Agent notification is best-effort

        return response

    except Exception as e:
        logger.error(
            "Thread creation failed", thread_id=request.thread_id, error=str(e)
        )
        raise HTTPException(status_code=500, detail="Thread creation failed")


@router.post(
    "/threads/from-file", response_model=ThreadFromFileResponse, include_in_schema=False
)
async def create_thread_from_file(
    request: Dict[str, Any],  # type: ignore[type-arg]
    thread_ops: ThreadOperations = Depends(get_thread_operations),
) -> ThreadFromFileResponse:
    """Create thread from file (for MCP integration)."""
    try:
        from nowledge_graph_server.tools.thread_file_handler import ThreadFileHandler  # type: ignore[attr-defined]

        file_path = request.get("file_path")
        if not file_path:
            raise HTTPException(status_code=400, detail="file_path is required")

        format = request.get("format", "auto")
        summary = request.get("summary")  # Optional user-provided summary

        # Create file handler and process file
        file_handler = ThreadFileHandler(thread_ops)  # type: ignore[var-annotated]
        result = await file_handler.create_thread_from_file(  # type: ignore[attr-defined]
            file_path=file_path,
            format=format,
            summary=summary,
        )

        # Notify UI of data change
        log_data_change(
            change_type="thread_created",
            entity_type="thread",
            entity_id=result.thread.thread_id,  # type: ignore[attr-defined]
        )

        # Trigger Knowledge Agent thread analysis (fire-and-forget)
        try:
            import asyncio
            from nowledge_graph_server.agent.manager import get_agent_manager
            mgr = get_agent_manager()
            if mgr and mgr.is_running:
                asyncio.create_task(mgr.on_thread_synced(
                    result.thread.thread_id,  # type: ignore[attr-defined]
                    title=result.thread.title,  # type: ignore[attr-defined]
                    source=getattr(result.thread, 'source', None),  # type: ignore[attr-defined]
                    message_count=len(result.messages),  # type: ignore[attr-defined]
                ))
        except Exception:
            pass  # Agent notification is best-effort

        return ThreadFromFileResponse(
            success=True,
            thread_id=result.thread.thread_id,  # type: ignore[attr-defined]
            thread_uuid=result.thread.id,  # type: ignore[arg-type]
            message_count=len(result.messages),  # type: ignore[attr-defined]
            title=result.thread.title,  # type: ignore[attr-defined]
        )

    except FileNotFoundError as e:
        logger.error("File not found", error=str(e))
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        logger.error("Invalid file format", error=str(e))
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error("Failed to create thread from file", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to create thread from file")


@router.post("/threads/{thread_id}/append", response_model=AppendMessagesResponse)
async def append_messages_to_thread(
    thread_id: str,
    request: Dict[str, Any],  # type: ignore[type-arg]
    thread_ops: ThreadOperations = Depends(get_thread_operations),
) -> AppendMessagesResponse:
    """Append messages to existing thread (for MCP integration).

    Supports two modes:
    1. Direct messages: `{"messages": [...]}`
    2. File-based: `{"file_path": "...", "format": "auto"}`

    Optional controls:
    - `deduplicate` (default: true)
    - `idempotency_key` (string; used to derive stable external_ids)
    """
    try:
        file_path = request.get("file_path")
        messages = request.get("messages")

        if not file_path and not messages:
            raise HTTPException(
                status_code=400, detail="Either 'file_path' or 'messages' is required"
            )

        # Handle file-based append
        if file_path:
            from nowledge_graph_server.tools.thread_file_handler import (
                ThreadFileHandler,
            )  # type: ignore[attr-defined]

            file_handler = ThreadFileHandler(thread_ops)  # type: ignore[var-annotated]
            result = await file_handler.append_messages_from_file(  # type: ignore[attr-defined]
                thread_id=thread_id,
                file_path=file_path,
                format=request.get("format", "auto"),
                deduplicate=request.get("deduplicate", True),
            )

            messages_added = result.get("messages_added", 0)

            # Notify UI of data change (thread was modified via file append)
            log_data_change(
                change_type="thread_updated",
                entity_type="thread",
                entity_id=thread_id,
                details={"messages_added": messages_added},
            )

            # Only trigger Knowledge Agent if new messages were added
            if messages_added > 0:
                try:
                    import asyncio
                    from nowledge_graph_server.agent.manager import get_agent_manager
                    mgr = get_agent_manager()
                    if mgr and mgr.is_running:
                        asyncio.create_task(mgr.on_thread_synced(thread_id))
                except Exception:
                    pass  # Agent notification is best-effort

            return AppendMessagesResponse(
                success=True,
                thread_id=thread_id,
                messages_added=result.get("messages_added", 0),  # type: ignore[arg-type]
                total_messages=result.get("total_messages", 0),  # type: ignore[arg-type]
            )

        # Handle direct messages append
        if not isinstance(messages, list):
            raise HTTPException(status_code=400, detail="'messages' must be an array")

        # Get deduplicate flag (default True for safety)
        deduplicate = request.get("deduplicate", True)
        idempotency_key = request.get("idempotency_key")

        # Append messages using thread operations
        result = await thread_ops.append_messages(  # type: ignore[attr-defined]
            thread_id=thread_id,
            messages=messages,  # type: ignore[arg-type]
            deduplicate=deduplicate,
            idempotency_key=idempotency_key if isinstance(idempotency_key, str) else None,
        )

        messages_added = result.get("messages_added", 0)

        # Notify UI of data change (thread was modified)
        log_data_change(
            change_type="thread_updated",
            entity_type="thread",
            entity_id=thread_id,
            details={"messages_added": messages_added},
        )

        # Trigger Knowledge Agent thread analysis only if new messages were added.
        # Heartbeat-driven syncs typically dedup to 0 new messages — skip to avoid
        # burning tokens on no-op appends.
        if messages_added > 0:
            try:
                import asyncio
                from nowledge_graph_server.agent.manager import get_agent_manager
                mgr = get_agent_manager()
                if mgr and mgr.is_running:
                    asyncio.create_task(mgr.on_thread_synced(thread_id))
            except Exception:
                pass  # Agent notification is best-effort

        return AppendMessagesResponse(
            success=True,
            thread_id=thread_id,
            messages_added=result.get("messages_added", 0),  # type: ignore[index]
            total_messages=result.get("total_messages", 0),  # type: ignore[index]
        )

    except ValueError as e:
        logger.error("Invalid request for append", thread_id=thread_id, error=str(e))
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error("Failed to append messages", thread_id=thread_id, error=str(e))
        raise HTTPException(
            status_code=500, detail=f"Failed to append messages: {str(e)}"
        )


# =========================================================================
# Thread Read Endpoints
# =========================================================================


@router.get("/threads/{thread_id}", response_model=ThreadFetchResponse)
async def get_thread(
    thread_id: str,
    thread_ops: ThreadOperations = Depends(get_thread_operations),
    limit: Optional[int] = Query(default=None, ge=1, le=500, description="Max messages to return"),
    offset: int = Query(default=0, ge=0, description="Skip first N messages"),
):
    """Get a thread with messages. Supports pagination via limit/offset."""
    try:
        response = await thread_ops.get_thread(thread_id)
        if response is None:
            raise HTTPException(status_code=404, detail="Thread not found")
        # Enrich with coverage metadata from Thread.metadata if present
        try:
            meta = response.thread.metadata or {}
            response.total_messages = len(response.messages)
            # Apply pagination if requested
            if offset > 0 or limit is not None:
                all_messages = response.messages
                sliced = all_messages[offset:]
                if limit is not None:
                    sliced = sliced[:limit]
                response.messages = sliced
            # no schema change; UI can read from metadata
            # distilled_status, distilled_message_count, last_thread_message_count, last_distilled_at live in metadata
            # Compute covered_message_ids for per-message highlighting (limit to large threads safely)
            kuzu_client = await get_kuzu_client()
            covered_ids: list[str] = []
            res = kuzu_client.conn.execute(  # type: ignore
                """
                MATCH (t:Thread {thread_id: $thread_id})-[:CONTAINS]->(m:Message)<-[:EXTRACTED_FROM]-(:Memory)
                RETURN DISTINCT m.id
                """,
                {"thread_id": thread_id},
            )
            while res.has_next():  # type: ignore
                row = res.get_next()  # type: ignore
                covered_ids.append(row[0])  # type: ignore
            response.covered_message_ids = covered_ids

            # Self-heal coverage metadata if missing or out-of-date
            try:
                covered_count = len(covered_ids)
                total_count = response.total_messages

                # Legacy full-thread detection: distilled==true with no EXTRACTED_FROM edges
                # legacy_complete = False
                if covered_count == 0 and total_count > 0:
                    if meta.get("distilled") is True:
                        # This is a legacy full-thread distill; treat as complete
                        # legacy_complete = True
                        covered_count = total_count
                        response.covered_message_ids = [m.id for m in response.messages]

                current_status = meta.get("distilled_status")
                current_covered = int(meta.get("distilled_message_count", 0))
                current_total = int(meta.get("last_thread_message_count", 0))

                needs_update = (
                    current_covered != covered_count
                    or current_total != total_count
                    or current_status is None
                )

                if needs_update:
                    # Compute status from actual covered_count (includes legacy boost)
                    if covered_count <= 0:
                        status = "none"
                    elif covered_count < total_count:
                        status = "partial"
                    else:
                        status = "complete"

                    # Merge into metadata on node
                    new_meta = meta.copy()
                    new_meta.update(
                        {
                            "distilled_status": status,
                            "distilled_message_count": covered_count,
                            "last_thread_message_count": total_count,
                        }
                    )
                    # Preserve distilled flag for complete threads
                    if status == "complete":
                        new_meta["distilled"] = True
                    kuzu_client.conn.execute(  # type: ignore
                        """
                        MATCH (t:Thread {thread_id: $thread_id})
                        SET t.metadata = $metadata
                        """,
                        {"thread_id": thread_id, "metadata": json.dumps(new_meta)},
                    )
                    # Ensure this "self-heal" write is durable and doesn't linger in WAL.
                    try:
                        kuzu_client.base_client.checkpoint(  # type: ignore[attr-defined]
                            reason=f"self_heal_thread_metadata:{thread_id}"
                        )
                    except Exception:
                        pass
                    response.thread.metadata = new_meta
            except Exception:
                pass
        except Exception:
            pass
        return response

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to get thread", thread_id=thread_id, error=str(e))
        raise HTTPException(status_code=500, detail="Failed to get thread")


@router.get("/threads/{thread_id}/coverage", response_model=ThreadCoverageResponse)
async def get_thread_coverage(
    thread_id: str,
    thread_ops: ThreadOperations = Depends(get_thread_operations),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> ThreadCoverageResponse:
    """Read-only coverage report for debugging progress issues."""
    try:
        # Total messages
        res_total = kuzu_client.conn.execute(  # type: ignore
            """
            MATCH (t:Thread {thread_id: $thread_id})-[:CONTAINS]->(m:Message)
            RETURN COUNT(m)
            """,
            {"thread_id": thread_id},
        )
        total = 0
        if res_total and res_total.has_next():  # type: ignore
            total = int(res_total.get_next()[0])  # type: ignore

        # Covered messages via EXTRACTED_FROM
        res_cov = kuzu_client.conn.execute(  # type: ignore
            """
            MATCH (t:Thread {thread_id: $thread_id})-[:CONTAINS]->(m:Message)<-[:EXTRACTED_FROM]-(:Memory)
            RETURN COUNT(DISTINCT m)
            """,
            {"thread_id": thread_id},
        )
        covered = 0
        if res_cov and res_cov.has_next():  # type: ignore
            covered = int(res_cov.get_next()[0])  # type: ignore

        # Memories count via COMPACTS_TO
        res_mem = kuzu_client.conn.execute(  # type: ignore
            """
            MATCH (t:Thread {thread_id: $thread_id})-[:COMPACTS_TO]->(m:Memory)
            RETURN COUNT(m)
            """,
            {"thread_id": thread_id},
        )
        mems = 0
        if res_mem and res_mem.has_next():  # type: ignore
            mems = int(res_mem.get_next()[0])  # type: ignore

        # Metadata snapshot
        res_meta = kuzu_client.conn.execute(  # type: ignore
            """
            MATCH (t:Thread {thread_id: $thread_id})
            RETURN t.metadata
            """,
            {"thread_id": thread_id},
        )
        meta = {}
        if res_meta and res_meta.has_next():  # type: ignore
            raw = res_meta.get_next()[0]  # type: ignore
            meta = json.loads(raw)  # type: ignore if raw else {}

        return ThreadCoverageResponse(
            thread_id=thread_id,
            total_messages=total,
            covered_messages=covered,
            memories=mems,
            metadata=meta,  # type: ignore[arg-type]
        )
    except Exception as e:
        logger.error("Coverage report failed", thread_id=thread_id, error=str(e))
        raise HTTPException(status_code=500, detail="Coverage report failed")


@router.get("/threads", response_model=ThreadListResponse)
async def list_threads(
    limit: int = Query(default=20, ge=1, le=1000),  # Increased to 1000 for live search
    offset: int = Query(default=0, ge=0),
    source: Optional[str] = Query(default=None),
    thread_ops: ThreadOperations = Depends(get_thread_operations),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> ThreadListResponse:
    """List threads with filtering and pagination."""
    try:

        # Get lightweight thread rows with pagination
        thread_rows = await thread_ops.list_threads(
            limit=limit,
            offset=offset,
            source=source,
        )

        # Transform to frontend format (without message hydration)
        threads_list: List[ThreadPublic] = []
        for row in thread_rows:
            # Match the existing frontend format used by transform_thread_to_frontend_format
            threads_list.append(
                ThreadPublic(
                    id=row.get("thread_id") or "",
                    title=row.get("title") or "",
                    source=row.get("source") or "Manual",
                    messages=row.get("message_count", 0),
                    date=(
                        (
                            row.get("import_date")
                            or row.get("last_activity")
                            or datetime.now(timezone.utc)  # type: ignore[arg-type]
                        ).strftime("%b %d, %Y")
                    ),
                    is_favorite=False,
                )
            )

        # Get total count for pagination metadata
        thread_repo: ThreadRepository = kuzu_client.thread_repo  # type: ignore[attr-defined]
        total_count: int = await thread_repo.count_threads(source=source)  # type: ignore[return-value]


        pagination = ThreadPaginationInfo(
            limit=limit,
            offset=offset,
            total=total_count,
            has_more=offset + limit < total_count,
        )

        return ThreadListResponse(threads=threads_list, pagination=pagination)

    except Exception as e:
        logger.error("Failed to list threads", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to list threads")


# =========================================================================
# Thread Delete Endpoints
# =========================================================================


@router.delete("/threads/bulk", response_model=BulkDeleteThreadsResponse)
async def bulk_delete_threads(
    request: BulkDeleteThreadsRequest,
    cascade_delete_memories: bool = Query(
        default=False, description="Delete extracted memories"
    ),
    thread_ops: ThreadOperations = Depends(get_thread_operations),
) -> BulkDeleteThreadsResponse:
    """Delete multiple threads and optionally their extracted memories."""
    try:
        if not request.thread_ids:
            raise HTTPException(status_code=400, detail="No thread IDs provided")

        result = await thread_ops.bulk_delete_threads(
            thread_ids=request.thread_ids,
            cascade_delete_memories=cascade_delete_memories,
        )

        # Notify UI of data changes for each deleted thread
        for thread_result in result.get("results", []):
            if thread_result.get("deleted"):
                log_data_change(
                    change_type="thread_deleted",
                    entity_type="thread",
                    entity_id=thread_result.get("thread_id", ""),
                    details={
                        "deleted_messages": thread_result.get("deleted_messages", 0),
                        "deleted_memories": thread_result.get("deleted_memories", 0),
                        "cascade_deletion": cascade_delete_memories,
                    },
                )

        return BulkDeleteThreadsResponse(
            message=f"Bulk delete completed: {result.get('deleted_count', 0)} deleted, {result.get('failed_count', 0)} failed",
            deleted_count=result.get("deleted_count", 0),
            failed_count=result.get("failed_count", 0),
            total_deleted_messages=result.get("total_deleted_messages", 0),
            total_deleted_memories=result.get("total_deleted_memories", 0),
            cascade_deletion=cascade_delete_memories,
            results=result.get("results", []),
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to bulk delete threads", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to bulk delete threads")


@router.delete("/threads/{thread_id}", response_model=DeleteThreadResponse)
async def delete_thread(
    thread_id: str,
    cascade_delete_memories: bool = Query(
        default=False, description="Delete extracted memories"
    ),
    thread_ops: ThreadOperations = Depends(get_thread_operations),
) -> DeleteThreadResponse:
    """Delete a thread and optionally its extracted memories."""
    try:
        result = await thread_ops.delete_thread(
            thread_id=thread_id,
            cascade_delete_memories=cascade_delete_memories,
        )

        if not result.get("deleted"):
            raise HTTPException(status_code=404, detail="Thread not found")

        # Notify UI of data change
        log_data_change(
            change_type="thread_deleted",
            entity_type="thread",
            entity_id=thread_id,
            details={
                "deleted_messages": result.get("deleted_messages", 0),
                "deleted_memories": result.get("deleted_memories", 0),
                "cascade_deletion": result.get("cascade_deletion", False),
            },
        )

        return DeleteThreadResponse(
            message="Thread deleted successfully",
            deleted_messages=result.get("deleted_messages", 0),
            deleted_memories=result.get("deleted_memories", 0),
            cascade_deletion=result.get("cascade_deletion", False),
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to delete thread", thread_id=thread_id, error=str(e))
        raise HTTPException(status_code=500, detail="Failed to delete thread")
