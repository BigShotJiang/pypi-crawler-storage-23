"""Thread export functionality and helper functions."""

import json
import html
import re
from typing import List
from datetime import datetime
from urllib.parse import quote

from fastapi import APIRouter, HTTPException, Depends, Query
from fastapi.responses import Response

import structlog

from nowledge_graph_server.api.dependencies import get_thread_operations
from nowledge_graph_server.core.thread_operations import ThreadOperations
from nowledge_graph_server.models.graph import ThreadNode, MessageNode


logger = structlog.get_logger(__name__)

router = APIRouter()


# =========================================================================
# Export Helper Functions
# =========================================================================


def export_thread_json(
    thread: ThreadNode, messages: List[MessageNode], include_metadata: bool = True
) -> str:
    """Export thread as JSON."""
    export_data = {
        "thread_id": thread.thread_id,
        "title": thread.title,
        "source": thread.source,
        "created_at": thread.created_at.isoformat() if thread.created_at else None,
        "participants": thread.participants or [],
        "message_count": len(messages),
        "messages": [
            {
                "role": msg.role,
                "content": msg.content,
                "timestamp": msg.timestamp.isoformat() if msg.timestamp else None,
                "created_at": msg.created_at.isoformat() if msg.created_at else None,
            }
            for msg in messages
        ],
        "export_info": {
            "exported_at": datetime.now().isoformat(),
            "format": "json",
            "version": "1.0",
        },
    }

    if include_metadata:
        export_data["metadata"] = {  # type: ignore[assignment]
            "project": thread.project,
            "workspace": thread.workspace,
            "tool_version": thread.tool_version,
            "import_date": thread.import_date.isoformat()
            if thread.import_date
            else None,
            "summary": thread.summary,
            "additional_metadata": thread.metadata,
        }

    return json.dumps(export_data, indent=2, ensure_ascii=False)


SOURCE_DISPLAY_NAMES = {
    "cursor": "Cursor",
    "claude": "Claude",
    "codex": "Codex",
    "opencode": "OpenCode",
}


def _get_role_label(role: str, source: str) -> str:
    """Get display label for a message role.

    Uses source-specific name for assistant (e.g., 'Cursor', 'Claude').
    """
    if role == "user":
        return "User"
    elif role == "assistant":
        return SOURCE_DISPLAY_NAMES.get(source, "Assistant")
    else:
        return role.capitalize()


def export_thread_markdown(
    thread: ThreadNode, messages: List[MessageNode], include_metadata: bool = True
) -> str:
    """Export thread as Markdown.

    For Claude/Codex: merges consecutive same-role messages into one block.
    For Cursor: keeps each message as a distinct turn (each bubble is a
    meaningful conversational step in Cursor's model).
    """
    lines: List[str] = []
    source = thread.source or "unknown"

    # Title and export info
    source_label = SOURCE_DISPLAY_NAMES.get(source, "nowledge-mem")
    lines.append(f"# {thread.title or 'Conversation Thread'}")
    now = datetime.now()
    lines.append(
        f"_Exported on {now.month}/{now.day}/{now.year} at {now.strftime('%H:%M:%S')} from {source_label}_"
    )
    lines.append("")
    lines.append("---")
    lines.append("")

    # For Cursor, each message is already a distinct step — don't merge
    if source == "cursor":
        for i, msg in enumerate(messages):
            lines.append(f"**{_get_role_label(msg.role, source)}**")
            lines.append("")
            lines.append(msg.content)
            lines.append("")
            if i < len(messages) - 1:
                lines.append("---")
                lines.append("")
    else:
        # Merge consecutive same-role messages (Claude/Codex/OpenCode)
        merged: List[tuple] = []  # (role, [content1, content2, ...])
        for msg in messages:
            if merged and merged[-1][0] == msg.role:
                merged[-1][1].append(msg.content)
            else:
                merged.append((msg.role, [msg.content]))

        for i, (role, contents) in enumerate(merged):
            lines.append(f"**{_get_role_label(role, source)}**")
            lines.append("")
            lines.append("\n\n".join(contents))
            lines.append("")
            if i < len(merged) - 1:
                lines.append("---")
                lines.append("")

    return "\n".join(lines)


def export_thread_html(
    thread: ThreadNode, messages: List[MessageNode], include_metadata: bool = True
) -> str:
    """Export thread as HTML."""
    title = html.escape(thread.title or "Conversation Thread")

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            line-height: 1.6;
            color: #333;
        }}
        .header {{
            border-bottom: 2px solid #e0e0e0;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }}
        .metadata {{
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 30px;
        }}
        .metadata h3 {{
            margin-top: 0;
            color: #495057;
        }}
        .metadata ul {{
            list-style: none;
            padding: 0;
        }}
        .metadata li {{
            padding: 5px 0;
            border-bottom: 1px solid #e9ecef;
        }}
        .metadata li:last-child {{
            border-bottom: none;
        }}
        .message {{
            margin: 20px 0;
            padding: 15px;
            border-radius: 8px;
            border-left: 4px solid #007bff;
        }}
        .message.user {{
            background: #e3f2fd;
            border-left-color: #2196f3;
        }}
        .message.assistant {{
            background: #f3e5f5;
            border-left-color: #9c27b0;
        }}
        .message-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
            font-weight: 600;
        }}
        .message-role {{
            display: flex;
            align-items: center;
            gap: 8px;
        }}
        .message-timestamp {{
            font-size: 0.9em;
            color: #666;
            font-weight: normal;
        }}
        .message-content {{
            white-space: pre-wrap;
            word-wrap: break-word;
        }}
        .footer {{
            border-top: 2px solid #e0e0e0;
            padding-top: 20px;
            margin-top: 30px;
            font-size: 0.9em;
            color: #666;
        }}
        pre {{
            background: #f8f9fa;
            padding: 10px;
            border-radius: 4px;
            overflow-x: auto;
        }}
        code {{
            background: #f8f9fa;
            padding: 2px 4px;
            border-radius: 3px;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>{title}</h1>
    </div>
"""

    # Add metadata section
    if include_metadata:
        html_content += """
    <div class="metadata">
        <h3>Thread Information</h3>
        <ul>
"""
        html_content += f"            <li><strong>Source:</strong> {html.escape(thread.source or 'Unknown')}</li>"
        html_content += f"            <li><strong>Created:</strong> {thread.created_at.strftime('%Y-%m-%d %H:%M:%S') if thread.created_at else 'Unknown'}</li>"
        html_content += (
            f"            <li><strong>Messages:</strong> {len(messages)}</li>"
        )
        if thread.participants:
            html_content += f"            <li><strong>Participants:</strong> {html.escape(', '.join(thread.participants))}</li>"
        if thread.project:
            html_content += f"            <li><strong>Project:</strong> {html.escape(thread.project)}</li>"
        if thread.workspace:
            html_content += f"            <li><strong>Workspace:</strong> {html.escape(thread.workspace)}</li>"
        html_content += """
        </ul>
    </div>
"""

    # Add messages
    html_content += '    <div class="conversation">'
    for msg in messages:
        role_class = "user" if msg.role == "user" else "assistant"
        role_icon = "👤" if msg.role == "user" else "🤖"
        role_display = "User" if msg.role == "user" else "Assistant"

        timestamp_str = ""
        if msg.timestamp:
            timestamp_str = f'<span class="message-timestamp">{msg.timestamp.strftime("%Y-%m-%d %H:%M:%S")}</span>'

        html_content += f"""
        <div class="message {role_class}">
            <div class="message-header">
                <span class="message-role">{role_icon} {role_display}</span>
                {timestamp_str}
            </div>
            <div class="message-content">{html.escape(msg.content)}</div>
        </div>
"""

    html_content += "    </div>"

    # Add footer
    html_content += f"""
    <div class="footer">
        <p><strong>Export Information:</strong></p>
        <ul>
            <li><strong>Exported:</strong> {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</li>
            <li><strong>Format:</strong> HTML</li>
            <li><strong>Thread ID:</strong> {html.escape(thread.thread_id)}</li>
        </ul>
    </div>
</body>
</html>
"""

    return html_content


# =========================================================================
# Export Endpoint
# =========================================================================


@router.get("/threads/{thread_id}/export")
async def export_thread(
    thread_id: str,
    format: str = Query(
        default="json", description="Export format: json, markdown, html"
    ),
    include_metadata: bool = Query(default=True, description="Include thread metadata"),
    thread_ops: ThreadOperations = Depends(get_thread_operations),
):
    """Export a thread in various formats."""
    try:
        # Get thread data
        thread_response = await thread_ops.get_thread(thread_id)
        if thread_response is None:
            raise HTTPException(status_code=404, detail="Thread not found")

        thread = thread_response.thread
        messages = thread_response.messages

        # Sanitize title for use in filename (remove path separators and
        # other characters that are invalid on Windows/macOS/Linux)
        safe_title = re.sub(r'[/\\:*?"<>|]', '_', thread.title or 'thread').strip()[:80]

        # Determine export format and generate content
        if format.lower() == "json":
            content = export_thread_json(thread, messages, include_metadata)
            media_type = "application/json"
            filename = f"{safe_title}_{thread_id}.json"
        elif format.lower() == "markdown":
            content = export_thread_markdown(thread, messages, include_metadata)
            media_type = "text/markdown"
            filename = f"{safe_title}_{thread_id}.md"
        elif format.lower() == "html":
            content = export_thread_html(thread, messages, include_metadata)
            media_type = "text/html"
            filename = f"{safe_title}_{thread_id}.html"
        else:
            raise HTTPException(
                status_code=400,
                detail="Unsupported format. Use: json, markdown, or html",
            )

        # Return response with appropriate headers
        # Encode as UTF-8 bytes to avoid latin-1 encoding issues with Unicode
        # Use RFC 5987 encoding for filename with Unicode characters
        encoded_filename = quote(filename, safe="")
        return Response(
            content=content.encode("utf-8"),
            media_type=media_type,
            headers={
                "Content-Disposition": f"attachment; filename*=UTF-8''{encoded_filename}",
                "Content-Type": f"{media_type}; charset=utf-8",
            },
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to export thread", thread_id=thread_id, error=str(e))
        raise HTTPException(status_code=500, detail="Failed to export thread")
