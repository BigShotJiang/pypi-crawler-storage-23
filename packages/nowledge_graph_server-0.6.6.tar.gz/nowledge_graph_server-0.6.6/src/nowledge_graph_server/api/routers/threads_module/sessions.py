"""Session persistence, import configuration, and watcher endpoints."""

from fastapi import APIRouter, HTTPException, Depends, Query

import structlog

from nowledge_graph_server.api.dependencies import get_thread_operations
from nowledge_graph_server.core.thread_operations import ThreadOperations

from .schemas import (
    SessionSaveRequest,
    SessionSaveResultItem,
    SessionSaveResponse,
    AutoImportRuleModel,
    ImportConfigModel,
    ImportConfigUpdateRequest,
    WatcherStatusModel,
)


logger = structlog.get_logger(__name__)

router = APIRouter()


# =========================================================================
# Session Persistence Endpoint
# =========================================================================


@router.post("/threads/sessions/save", response_model=SessionSaveResponse)
async def save_session(
    request: SessionSaveRequest,
    thread_ops: ThreadOperations = Depends(get_thread_operations),
) -> SessionSaveResponse:
    """Save coding session(s) as conversation thread(s).

    Auto-detects sessions from project_path. Creates new thread or appends to existing
    (with deduplication). Supports Claude Code and Codex.

    Args:
        request: Session save request with client, project_path, and options

    Returns:
        SessionSaveResponse with results for each processed session
    """
    from nowledge_graph_server.services.session_persistence import SessionPersistenceService

    try:
        service = SessionPersistenceService(thread_ops)
        response = await service.persist_session(
            client=request.client,
            project_path=request.project_path,
            persist_mode=request.persist_mode,
            session_id=request.session_id,
            summary=request.summary,
            truncate_large_content=request.truncate_large_content,
        )

        # Convert dataclass response to Pydantic model
        result_items = [
            SessionSaveResultItem(
                action=r["action"],
                session_id=r["session_id"],
                thread_id=r["thread_id"],
                message_count=r.get("message_count", 0),
                messages_added=r.get("messages_added", 0),
                file=r.get("file", ""),
            )
            for r in response.results
        ]

        return SessionSaveResponse(
            status=response.status,
            client=response.client,
            project_path=response.project_path,
            persist_mode=response.persist_mode,
            results=result_items,
            error=response.error,
            hint=response.hint,
        )

    except Exception as e:
        logger.error(
            "Failed to save session",
            client=request.client,
            project_path=request.project_path,
            error=str(e),
        )
        raise HTTPException(
            status_code=500, detail=f"Failed to save session: {str(e)}"
        )


# =========================================================================
# Import Configuration Endpoints
# =========================================================================


@router.get("/threads/import-config", response_model=ImportConfigModel)
async def get_import_config() -> ImportConfigModel:
    """Get the current import configuration."""
    from nowledge_graph_server.services.import_config import get_import_config_service

    try:
        config_service = get_import_config_service()
        config = config_service.load()

        return ImportConfigModel(
            hidden_projects=config.hidden_projects,
            hidden_sessions=config.hidden_sessions,
            auto_import_rules=[
                AutoImportRuleModel(
                    id=rule.id,
                    type=rule.type.value,
                    value=rule.value,
                    enabled=rule.enabled,
                    created_at=rule.created_at,
                )
                for rule in config.auto_import_rules
            ],
            watcher_enabled=config.watcher_enabled,
            show_hidden_by_default=config.show_hidden_by_default,
            dedup_window_seconds=config.dedup_window_seconds,
            watched_platforms=config.watched_platforms,
            watched_projects=config.watched_projects,
            cursor_poll_interval=config.cursor_poll_interval,
        )

    except Exception as e:
        logger.error("Failed to get import config", error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to get import config: {str(e)}")


@router.put("/threads/import-config", response_model=ImportConfigModel)
async def update_import_config(request: ImportConfigUpdateRequest) -> ImportConfigModel:
    """Update import configuration."""
    from nowledge_graph_server.services.import_config import (
        get_import_config_service,
        AutoImportRule,
        AutoImportRuleType,
    )

    try:
        config_service = get_import_config_service()
        config = config_service.load()

        # Update fields that were provided
        if request.hidden_projects is not None:
            config.hidden_projects = request.hidden_projects

        if request.hidden_sessions is not None:
            config.hidden_sessions = request.hidden_sessions

        if request.auto_import_rules is not None:
            config.auto_import_rules = [
                AutoImportRule(
                    id=rule.id,
                    type=AutoImportRuleType(rule.type),
                    value=rule.value,
                    enabled=rule.enabled,
                    created_at=rule.created_at or 0.0,
                )
                for rule in request.auto_import_rules
            ]

        if request.watcher_enabled is not None:
            config.watcher_enabled = request.watcher_enabled

        if request.show_hidden_by_default is not None:
            config.show_hidden_by_default = request.show_hidden_by_default

        if request.dedup_window_seconds is not None:
            config.dedup_window_seconds = request.dedup_window_seconds

        if request.watched_platforms is not None:
            config.watched_platforms = request.watched_platforms

        if request.watched_projects is not None:
            config.watched_projects = request.watched_projects

        if request.cursor_poll_interval is not None:
            config.cursor_poll_interval = request.cursor_poll_interval

        config_service.save(config)

        # Return updated config
        return await get_import_config()

    except Exception as e:
        logger.error("Failed to update import config", error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to update import config: {str(e)}")


@router.post("/threads/import-config/hide-project")
async def hide_project(project_encoded: str = Query(..., description="Encoded project path")) -> dict:
    """Hide a project from the browse view."""
    from nowledge_graph_server.services.import_config import get_import_config_service

    try:
        config_service = get_import_config_service()
        config_service.hide_project(project_encoded)
        return {"success": True, "hidden": project_encoded}

    except Exception as e:
        logger.error("Failed to hide project", project=project_encoded, error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to hide project: {str(e)}")


@router.post("/threads/import-config/unhide-project")
async def unhide_project(project_encoded: str = Query(..., description="Encoded project path")) -> dict:
    """Unhide a project."""
    from nowledge_graph_server.services.import_config import get_import_config_service

    try:
        config_service = get_import_config_service()
        config_service.unhide_project(project_encoded)
        return {"success": True, "unhidden": project_encoded}

    except Exception as e:
        logger.error("Failed to unhide project", project=project_encoded, error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to unhide project: {str(e)}")


@router.post("/threads/import-config/hide-session")
async def hide_session(session_id: str = Query(..., description="Session ID")) -> dict:
    """Hide a session from the browse view."""
    from nowledge_graph_server.services.import_config import get_import_config_service

    try:
        config_service = get_import_config_service()
        config_service.hide_session(session_id)
        return {"success": True, "hidden": session_id}

    except Exception as e:
        logger.error("Failed to hide session", session_id=session_id, error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to hide session: {str(e)}")


@router.post("/threads/import-config/unhide-session")
async def unhide_session(session_id: str = Query(..., description="Session ID")) -> dict:
    """Unhide a session."""
    from nowledge_graph_server.services.import_config import get_import_config_service

    try:
        config_service = get_import_config_service()
        config_service.unhide_session(session_id)
        return {"success": True, "unhidden": session_id}

    except Exception as e:
        logger.error("Failed to unhide session", session_id=session_id, error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to unhide session: {str(e)}")


# =========================================================================
# Session Watcher Endpoints
# =========================================================================


@router.get("/threads/watcher/status", response_model=WatcherStatusModel)
async def get_watcher_status() -> WatcherStatusModel:
    """Get the current status of the session watcher."""
    from nowledge_graph_server.services.session_watcher import get_session_watcher_service

    try:
        # Try to get existing watcher service
        try:
            watcher = get_session_watcher_service()
            status = watcher.status
            return WatcherStatusModel(
                running=status.running,
                watched_paths=status.watched_paths,
                last_check=status.last_check,
                auto_import_count=status.auto_import_count,
                errors=status.errors,
            )
        except ValueError:
            # Watcher not initialized yet
            return WatcherStatusModel(
                running=False,
                watched_paths=[],
                last_check=None,
                auto_import_count=0,
                errors=[],
            )

    except Exception as e:
        logger.error("Failed to get watcher status", error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to get watcher status: {str(e)}")


@router.post("/threads/watcher/start", response_model=WatcherStatusModel)
async def start_watcher(
    thread_ops: ThreadOperations = Depends(get_thread_operations),
) -> WatcherStatusModel:
    """Start the session watcher for auto-importing sessions."""
    from nowledge_graph_server.services.session_watcher import (
        initialize_session_watcher,
        get_session_watcher_service,
    )
    from nowledge_graph_server.services.conversation_import import ConversationImportService

    try:
        import asyncio

        # Create import callback that uses the thread operations
        import_service = ConversationImportService(thread_ops)

        # Capture the running event loop so the callback (called from watchdog thread)
        # can safely schedule async work on it
        main_loop = asyncio.get_running_loop()

        def import_callback(path: str, source: str, session_id: str = None):
            """Synchronous callback invoked from watchdog thread or Cursor poller.

            Uses run_coroutine_threadsafe to safely schedule async import
            on the main event loop from this non-async thread.

            Args:
                path: File path to import
                source: Source type (claude, codex, cursor, opencode)
                session_id: Optional session_id (passed by Cursor poller, extracted from file for others)
            """
            async def do_import():
                from nowledge_graph_server.services.conversation_discovery import ConversationFile
                import json as _json

                try:
                    # Extract session_id from file using same logic as discovery modules
                    # (prevents duplicates between manual import and watcher import)
                    # For Cursor, session_id is passed directly from the poller
                    import os
                    resolved_session_id = session_id  # Use passed value if available

                    if resolved_session_id is None:
                        if source == "opencode" and path.endswith(".json"):
                            try:
                                with open(path, "r", encoding="utf-8") as f:
                                    session_data = _json.load(f)
                                resolved_session_id = session_data.get("id")
                            except Exception:
                                pass

                        elif source == "claude" and path.endswith(".jsonl"):
                            # Match discovery/claude.py _extract_session_id():
                            # Read sessionId from first JSONL event, fallback to filename
                            try:
                                with open(path, "r", encoding="utf-8") as f:
                                    first_line = f.readline().strip()
                                    if first_line:
                                        event = _json.loads(first_line)
                                        resolved_session_id = event.get("sessionId")
                            except Exception:
                                pass
                            if not resolved_session_id:
                                stem = os.path.splitext(os.path.basename(path))[0]
                                resolved_session_id = stem[6:] if stem.startswith("agent-") else stem

                        elif source == "codex" and path.endswith(".jsonl"):
                            # Match discovery/codex.py _analyze_codex_file():
                            # Read session_meta record's payload.id, fallback to filename parsing
                            try:
                                with open(path, "r", encoding="utf-8") as f:
                                    for i, line in enumerate(f):
                                        if i > 50:  # Only scan first 50 lines
                                            break
                                        line = line.strip()
                                        if not line:
                                            continue
                                        try:
                                            record = _json.loads(line)
                                            if record.get("type") == "session_meta":
                                                resolved_session_id = record.get("payload", {}).get("id")
                                                break
                                        except _json.JSONDecodeError:
                                            continue
                            except Exception:
                                pass
                            if not resolved_session_id:
                                filename = os.path.splitext(os.path.basename(path))[0]
                                parts = filename.rsplit("-", 1)
                                resolved_session_id = parts[1] if len(parts) > 1 else filename

                    # Build metadata — flag SQLite storage for OpenCode
                    metadata = {}
                    if source == "opencode" and path.endswith(".db"):
                        metadata["storage"] = "sqlite"

                    conv = ConversationFile(source=source, path=path, session_id=resolved_session_id, metadata=metadata)
                    await import_service.import_conversation(conv)
                    logger.info("Auto-import completed", path=path, source=source, session_id=resolved_session_id)
                except Exception as e:
                    logger.error("Auto-import failed", path=path, source=source, error=str(e))

            # Schedule on the captured event loop (thread-safe)
            future = asyncio.run_coroutine_threadsafe(do_import(), main_loop)
            # Don't block waiting for the result - fire and forget
            future.add_done_callback(
                lambda f: logger.error("Auto-import exception", error=str(f.exception()))
                if f.exception() else None
            )

        # Always (re)initialize watcher with fresh callback bound to current event loop.
        # If the watcher is already running, stop it first.
        try:
            existing = get_session_watcher_service()
            if existing.is_running():
                existing.stop()
        except ValueError:
            pass

        watcher = initialize_session_watcher(import_callback)

        # Start watcher
        success = watcher.start()
        if not success:
            raise HTTPException(status_code=500, detail="Failed to start watcher")

        status = watcher.status
        return WatcherStatusModel(
            running=status.running,
            watched_paths=status.watched_paths,
            last_check=status.last_check,
            auto_import_count=status.auto_import_count,
            errors=status.errors,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to start watcher", error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to start watcher: {str(e)}")


@router.post("/threads/watcher/stop", response_model=WatcherStatusModel)
async def stop_watcher() -> WatcherStatusModel:
    """Stop the session watcher."""
    from nowledge_graph_server.services.session_watcher import get_session_watcher_service

    try:
        try:
            watcher = get_session_watcher_service()
            watcher.stop()
            status = watcher.status
            return WatcherStatusModel(
                running=status.running,
                watched_paths=status.watched_paths,
                last_check=status.last_check,
                auto_import_count=status.auto_import_count,
                errors=status.errors,
            )
        except ValueError:
            # Watcher not initialized
            return WatcherStatusModel(
                running=False,
                watched_paths=[],
                last_check=None,
                auto_import_count=0,
                errors=[],
            )

    except Exception as e:
        logger.error("Failed to stop watcher", error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to stop watcher: {str(e)}")
