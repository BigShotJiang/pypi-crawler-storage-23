"""
Thread management API router module.

This module provides a clean, modular structure for thread-related endpoints,
organized by functionality:
- crud: Create, Read, Update, Delete operations
- search: Search and summary operations
- export: Thread export functionality
- discovery: Conversation discovery and import
- sessions: Session persistence and watcher operations
"""

from fastapi import APIRouter
from .search import router as search_router
from .crud import router as crud_router
from .export import router as export_router
from .discovery import router as discovery_router
from .sessions import router as sessions_router

# Create main router that includes all sub-routers
router = APIRouter()

# Include all sub-routers (order matters for route matching!)
# IMPORTANT: Specific routes MUST come before parametric routes like /threads/{thread_id}
# Otherwise FastAPI will match "search" or "summaries" as a thread_id parameter!

# 1. Search routes first (includes /threads/summaries, /threads/search)
router.include_router(search_router)

# 2. Sessions routes (includes /threads/sessions/*, /threads/import-config/*, /threads/watcher/*)
router.include_router(sessions_router)

# 3. Discovery routes (includes /threads/conversations/*)
router.include_router(discovery_router)

# 4. Export routes (includes /threads/{thread_id}/export)
router.include_router(export_router)

# 5. CRUD routes last (includes parametric /threads/{thread_id} routes)
router.include_router(crud_router)

__all__ = ["router"]
