"""Conversation discovery and import endpoints."""

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Depends, Query
from fastapi.responses import PlainTextResponse

import structlog

from nowledge_graph_server.api.dependencies import get_thread_operations
from nowledge_graph_server.services.conversation_import import ConversationImportService
from nowledge_graph_server.services.conversation_discovery import ConversationFile
from nowledge_graph_server.core.thread_operations import ThreadOperations
from nowledge_graph_server.models import ConversationImportResponse
from nowledge_graph_server.tools.parsers.handler import ThreadFileHandler
from nowledge_graph_server.utils.progress_logger import log_data_change

from .schemas import (
    ConversationDiscoveryResponse,
    ConversationExportRawRequest,
    ConversationImportRequestModel,
)


logger = structlog.get_logger(__name__)

router = APIRouter()


def _extract_session_id_from_file(source: str, path: str) -> Optional[str]:
    """Extract session_id from file content, matching discovery module logic.

    This ensures consistent thread IDs across:
    - Discovery API (discover_conversations)
    - Import API (import_conversation)
    - Watcher auto-import (sessions.py import_callback)

    Args:
        source: Source type (claude, codex, cursor, opencode)
        path: File path to extract session_id from

    Returns:
        Extracted session_id or filename-based fallback
    """
    import os

    session_id = None

    if source == "claude" and path.endswith(".jsonl"):
        # Match discovery/claude.py _extract_session_id()
        try:
            with open(path, "r", encoding="utf-8") as f:
                first_line = f.readline().strip()
                if first_line:
                    event = json.loads(first_line)
                    session_id = event.get("sessionId")
        except Exception:
            pass
        # Fallback: use filename stem
        if not session_id:
            stem = os.path.splitext(os.path.basename(path))[0]
            session_id = stem[6:] if stem.startswith("agent-") else stem

    elif source == "codex" and path.endswith(".jsonl"):
        # Match discovery/codex.py _analyze_codex_file()
        try:
            with open(path, "r", encoding="utf-8") as f:
                for i, line in enumerate(f):
                    if i > 50:
                        break
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        record = json.loads(line)
                        if record.get("type") == "session_meta":
                            session_id = record.get("payload", {}).get("id")
                            break
                    except json.JSONDecodeError:
                        continue
        except Exception:
            pass
        # Fallback: parse filename
        if not session_id:
            filename = os.path.splitext(os.path.basename(path))[0]
            parts = filename.rsplit("-", 1)
            session_id = parts[1] if len(parts) > 1 else filename

    elif source == "opencode":
        if path.endswith(".json"):
            # Legacy JSON format — match discovery/opencode.py
            try:
                with open(path, "r", encoding="utf-8") as f:
                    session_data = json.load(f)
                    session_id = session_data.get("id")
            except Exception:
                pass
        # For SQLite (.db), session_id comes from the request, not the file

    # Cursor uses composerId from request.workspace or path-based hash
    # (handled by discovery module, not extracted from file here)

    return session_id


@router.get("/threads/conversations/discover", response_model=ConversationDiscoveryResponse)
async def discover_conversations(
    source: Optional[str] = Query(
        default=None,
        description="Filter by source: claude, codex, cursor, opencode, or None for all",
    ),
    thread_ops: ThreadOperations = Depends(get_thread_operations),
) -> ConversationDiscoveryResponse:
    """Discover conversation files from AI coding assistants.

    Scans file system for conversation files from Claude Code, Codex, Cursor, and OpenCode.
    """
    try:
        import_service = ConversationImportService(thread_ops)
        conversations = await import_service.discover_conversations(source=source)

        return ConversationDiscoveryResponse(conversations=conversations)

    except Exception as e:
        logger.error("Failed to discover conversations", error=str(e))
        raise HTTPException(
            status_code=500, detail=f"Failed to discover conversations: {str(e)}"
        )


@router.post("/threads/conversations/import", response_model=ConversationImportResponse)
async def import_conversation(
    request: ConversationImportRequestModel,
    thread_ops: ThreadOperations = Depends(get_thread_operations),
) -> ConversationImportResponse:
    """Import a conversation file into Nowledge Mem.

    Converts external conversation formats (Claude Code, Codex, Cursor, OpenCode) into threads.
    """
    try:
        import_service = ConversationImportService(thread_ops)

        # Extract session_id from file if not provided in request
        # This ensures consistent thread IDs between manual import, watcher, and discovery
        session_id = request.session_id
        if not session_id:
            session_id = _extract_session_id_from_file(request.source, request.path)

        # Convert request to ConversationFile
        # Forward metadata from discovery (carries storage type, project info, etc.)
        metadata = request.metadata or {}
        # Also infer storage type from path for OpenCode SQLite
        if request.source == "opencode" and request.path.endswith(".db"):
            metadata.setdefault("storage", "sqlite")

        conversation_file = ConversationFile(
            source=request.source,
            path=request.path,
            session_id=session_id,
            workspace=request.workspace,
            project=request.project,
            metadata=metadata,
        )

        result = await import_service.import_conversation(
            conversation_file=conversation_file,
            thread_id_override=request.thread_id_override,
            auto_compact=request.auto_compact,
            preserve_timestamps=request.preserve_timestamps,
            summary=request.summary,
        )

        # Notify UI of data change (conversation import creates threads)
        if result.thread.thread_id:
            log_data_change(
                change_type="thread_created",
                entity_type="thread",
                entity_id=result.thread.thread_id,
                details={"source": "conversation_import"},
            )

        return result

    except FileNotFoundError as e:
        logger.error("Conversation file not found", path=request.path, error=str(e))
        raise HTTPException(status_code=404, detail=f"File not found: {request.path}")
    except ValueError as e:
        logger.error("Invalid conversation file", path=request.path, error=str(e))
        raise HTTPException(status_code=400, detail=f"Invalid file format: {str(e)}")
    except Exception as e:
        logger.error("Failed to import conversation", path=request.path, error=str(e))
        raise HTTPException(
            status_code=500, detail=f"Failed to import conversation: {str(e)}"
        )


SOURCE_DISPLAY_NAMES = {
    "cursor": "Cursor",
    "claude": "Claude",
    "codex": "Codex",
    "opencode": "OpenCode",
}


def _get_role_label(role: str, source: str) -> str:
    """Get display label for a message role."""
    if role == "user":
        return "User"
    elif role == "assistant":
        return SOURCE_DISPLAY_NAMES.get(source, "Assistant")
    else:
        return role.capitalize()


def _format_thread_data_markdown(
    thread_data: Dict[str, Any], source: str
) -> str:
    """Format parsed thread_data dict as markdown.

    For Claude/Codex: merges consecutive same-role messages into one block.
    For Cursor: keeps each message as a distinct turn (each bubble is a
    meaningful conversational step in Cursor's model).
    """
    lines: List[str] = []

    title = thread_data.get("title") or "Conversation"
    source_label = SOURCE_DISPLAY_NAMES.get(source, "nowledge-mem")
    lines.append(f"# {title}")
    now = datetime.now()
    lines.append(
        f"_Exported on {now.month}/{now.day}/{now.year} at {now.strftime('%H:%M:%S')} from {source_label}_"
    )
    lines.append("")
    lines.append("---")
    lines.append("")

    messages = thread_data.get("messages", [])

    # For Cursor, each bubble is already a distinct step — don't merge
    if source == "cursor":
        for i, msg in enumerate(messages):
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
            lines.append(f"**{_get_role_label(role, source)}**")
            lines.append("")
            lines.append(content)
            lines.append("")
            if i < len(messages) - 1:
                lines.append("---")
                lines.append("")
    else:
        # Merge consecutive same-role messages (Claude/Codex/OpenCode)
        merged: List[tuple] = []  # (role, [content1, content2, ...])
        for msg in messages:
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
            if merged and merged[-1][0] == role:
                merged[-1][1].append(content)
            else:
                merged.append((role, [content]))

        for i, (role, contents) in enumerate(merged):
            lines.append(f"**{_get_role_label(role, source)}**")
            lines.append("")
            lines.append("\n\n".join(contents))
            lines.append("")
            if i < len(merged) - 1:
                lines.append("---")
                lines.append("")

    return "\n".join(lines)


def _format_thread_data_json(
    thread_data: Dict[str, Any], source: str
) -> str:
    """Format parsed thread_data dict as JSON."""
    export_data = {
        "thread_id": thread_data.get("thread_id"),
        "title": thread_data.get("title"),
        "source": source,
        "message_count": len(thread_data.get("messages", [])),
        "messages": [
            {
                "role": msg.get("role", "unknown"),
                "content": msg.get("content", ""),
                "timestamp": msg.get("timestamp"),
            }
            for msg in thread_data.get("messages", [])
        ],
        "metadata": thread_data.get("metadata", {}),
        "export_info": {
            "exported_at": datetime.now().isoformat(),
            "format": "json",
            "version": "1.0",
        },
    }
    return json.dumps(export_data, indent=2, ensure_ascii=False, default=str)


@router.post("/threads/conversations/export-raw")
async def export_conversation_raw(
    request: ConversationExportRawRequest,
    thread_ops: ThreadOperations = Depends(get_thread_operations),
) -> PlainTextResponse:
    """Export a raw conversation file as markdown or JSON without importing.

    Parses the session file using the same parsers as import, but returns
    formatted content directly instead of creating a thread.
    """
    try:
        file_path = Path(request.path)
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {request.path}")

        # Map source to parser format (same as ConversationImportService)
        format_map = {
            "claude": "claude_code",
            "codex": "codex",
            "cursor": "cursor_vscdb",
            "opencode": "opencode",
        }
        file_format = format_map.get(request.source, "auto")

        # Detect OpenCode SQLite format
        session_id = None
        if request.source == "opencode" and request.path.endswith(".db"):
            file_format = "opencode_sqlite"
            # session_id would need to be passed; for now export-raw only supports JSON format
            logger.warning("Export-raw for OpenCode SQLite not yet supported")
            raise ValueError("Export-raw for OpenCode SQLite sessions is not yet supported. Import the session first.")

        # Parse using existing infrastructure
        handler = ThreadFileHandler(thread_ops)
        thread_data = handler._parse_file(file_path, file_format, session_id=session_id)

        # Format output
        if request.format == "markdown":
            content = _format_thread_data_markdown(thread_data, request.source)
            media_type = "text/markdown"
        else:
            content = _format_thread_data_json(thread_data, request.source)
            media_type = "application/json"

        return PlainTextResponse(content=content, media_type=media_type)

    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=f"Invalid file format: {str(e)}")
    except Exception as e:
        logger.error(
            "Failed to export raw conversation",
            path=request.path,
            source=request.source,
            error=str(e),
        )
        raise HTTPException(
            status_code=500, detail=f"Failed to export conversation: {str(e)}"
        )
