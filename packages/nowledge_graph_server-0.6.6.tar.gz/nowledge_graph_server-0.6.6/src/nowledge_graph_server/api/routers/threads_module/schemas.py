"""Pydantic schemas for thread API endpoints."""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


# =========================================================================
# Thread Response Models
# =========================================================================


class ThreadSummariesResponse(BaseModel):
    """Response for thread summaries."""

    summaries: List[Dict[str, Any]] = Field(
        default_factory=list, description="List of thread summaries"
    )

    class Config:
        extra = "allow"


class ThreadFromFileResponse(BaseModel):
    """Response from creating thread from file."""

    success: bool = Field(..., description="Whether creation succeeded")
    thread_id: str = Field(..., description="Thread ID")
    thread_uuid: Optional[str] = Field(default=None, description="Thread UUID")
    message_count: int = Field(..., description="Number of messages")
    title: Optional[str] = Field(default=None, description="Thread title")

    class Config:
        extra = "allow"


class AppendMessagesResponse(BaseModel):
    """Response from appending messages to thread."""

    success: bool = Field(..., description="Whether append succeeded")
    thread_id: str = Field(..., description="Thread ID")
    messages_added: int = Field(..., description="Number of messages added")
    total_messages: int = Field(..., description="Total messages in thread")

    class Config:
        extra = "allow"


class ThreadPublic(BaseModel):
    """Frontend thread format for listing."""

    id: str = Field(..., description="Thread ID")
    title: str = Field(..., description="Thread title")
    source: str = Field(..., description="Thread source")
    messages: int = Field(..., description="Number of messages")
    date: str = Field(..., description="Formatted date string")
    is_favorite: bool = Field(default=False, description="Favorite status")

    class Config:
        extra = "allow"


class ThreadPaginationInfo(BaseModel):
    """Pagination metadata for threads."""

    limit: int = Field(..., description="Items per page")
    offset: int = Field(..., description="Offset")
    total: int = Field(..., description="Total items")
    has_more: bool = Field(..., description="Whether more items available")

    class Config:
        extra = "allow"


class ThreadListResponse(BaseModel):
    """Response from listing threads."""

    threads: List[ThreadPublic] = Field(
        default_factory=list, description="List of threads"
    )
    pagination: ThreadPaginationInfo = Field(..., description="Pagination info")

    class Config:
        extra = "allow"


class ThreadCoverageResponse(BaseModel):
    """Response for thread coverage report."""

    thread_id: str = Field(..., description="Thread ID")
    total_messages: int = Field(..., description="Total messages")
    covered_messages: int = Field(..., description="Messages covered by memories")
    memories: int = Field(..., description="Number of memories")
    metadata: Dict[str, Any] = Field(
        default_factory=dict, description="Thread metadata"
    )

    class Config:
        extra = "allow"


class DeleteThreadResponse(BaseModel):
    """Response from deleting a thread."""

    message: str = Field(..., description="Success message")
    deleted_messages: int = Field(default=0, description="Number of messages deleted")
    deleted_memories: int = Field(default=0, description="Number of memories deleted")
    cascade_deletion: bool = Field(
        default=False, description="Whether memories were cascade deleted"
    )

    class Config:
        extra = "allow"


class BulkDeleteThreadsRequest(BaseModel):
    """Request to delete multiple threads."""

    thread_ids: List[str] = Field(..., description="List of thread IDs to delete")


class BulkDeleteThreadsResponse(BaseModel):
    """Response from bulk deleting threads."""

    message: str = Field(..., description="Success message")
    deleted_count: int = Field(..., description="Number of threads successfully deleted")
    failed_count: int = Field(default=0, description="Number of threads that failed to delete")
    total_deleted_messages: int = Field(default=0, description="Total number of messages deleted")
    total_deleted_memories: int = Field(default=0, description="Total number of memories deleted")
    cascade_deletion: bool = Field(default=False, description="Whether memories were deleted")
    results: List[Dict[str, Any]] = Field(
        default_factory=list, description="Detailed results for each thread deletion"
    )

    class Config:
        extra = "allow"


# =========================================================================
# Search Models
# =========================================================================


class ThreadSearchMetadata(BaseModel):
    """Metadata for thread search results."""

    query: str = Field(..., description="Search query")
    mode: str = Field(..., description="Search mode")
    matched_messages_count: int = Field(default=0, description="Total matched messages")
    error: Optional[str] = Field(default=None, description="Error message if any")

    class Config:
        extra = "allow"


class ThreadSearchResponse(BaseModel):
    """Response from thread search."""

    threads: List[Dict[str, Any]] = Field(
        default_factory=list, description="Search results"
    )
    total_found: int = Field(..., description="Total threads found")
    search_metadata: ThreadSearchMetadata = Field(..., description="Search metadata")

    class Config:
        extra = "allow"


# =========================================================================
# Discovery and Import Models
# =========================================================================


class ConversationDiscoveryResponse(BaseModel):
    """Response from conversation discovery."""

    conversations: Dict[str, List[Dict[str, Any]]] = Field(
        ..., description="Discovered conversations by source"
    )


class ConversationImportRequestModel(BaseModel):
    """Request model for importing a conversation."""

    path: str = Field(..., description="Path to conversation file")
    source: str = Field(..., description="Source type: claude, codex, cursor, or opencode")
    session_id: Optional[str] = Field(
        default=None, description="Session ID from discovery (used for thread deduplication)"
    )
    thread_id_override: Optional[str] = Field(
        default=None, description="Optional thread ID override"
    )
    summary: Optional[str] = Field(
        default=None, description="Optional user-provided summary"
    )
    auto_compact: bool = Field(
        default=False, description="Auto-extract memories during import"
    )
    preserve_timestamps: bool = Field(
        default=True, description="Preserve original timestamps"
    )
    workspace: Optional[str] = Field(
        default=None, description="Workspace/project directory path (used for project-level auto-sync)"
    )
    project: Optional[str] = Field(
        default=None, description="Human-readable project name"
    )
    metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Metadata from discovery (e.g. storage type for OpenCode SQLite sessions)",
    )


class ConversationExportRawRequest(BaseModel):
    """Request model for exporting a raw conversation file without importing."""

    path: str = Field(..., description="Path to conversation file")
    source: str = Field(..., description="Source type: claude, codex, cursor, or opencode")
    format: str = Field(
        default="markdown", description="Export format: markdown or json"
    )


# =========================================================================
# Session Persistence Models
# =========================================================================


class SessionSaveRequest(BaseModel):
    """Request model for saving a coding session."""

    client: str = Field(
        ...,
        description="Client type: 'claude-code' or 'codex'",
        pattern=r"^(claude-code|codex)$",
    )
    project_path: str = Field(..., description="Project working directory path")
    persist_mode: str = Field(
        default="current",
        description="Mode: 'current' (most recent session) or 'all' (all sessions)",
        pattern=r"^(current|all)$",
    )
    session_id: Optional[str] = Field(
        default=None, description="Session ID (Codex only, optional)"
    )
    summary: Optional[str] = Field(
        default=None, description="Brief session summary (1-2 sentences)"
    )
    truncate_large_content: bool = Field(
        default=False, description="Truncate large tool results >10KB"
    )


class SessionSaveResultItem(BaseModel):
    """Result of persisting a single session."""

    action: str = Field(..., description="Action taken: 'created' or 'appended'")
    session_id: str = Field(..., description="Session ID")
    thread_id: str = Field(..., description="Thread ID")
    message_count: int = Field(..., description="Total messages in thread")
    messages_added: int = Field(default=0, description="New messages added (append only)")
    file: str = Field(default="", description="Source file name")


class SessionSaveResponse(BaseModel):
    """Response from session save operation."""

    status: str = Field(..., description="Status: 'success' or 'error'")
    client: str = Field(..., description="Client type")
    project_path: str = Field(..., description="Project path")
    persist_mode: str = Field(..., description="Persist mode used")
    results: List[SessionSaveResultItem] = Field(
        default_factory=list, description="Results for each session"
    )
    error: Optional[str] = Field(default=None, description="Error message if failed")
    hint: Optional[str] = Field(default=None, description="Hint for resolution")


# =========================================================================
# Import Configuration Models
# =========================================================================


class AutoImportRuleModel(BaseModel):
    """Model for auto-import rule."""

    id: str = Field(..., description="Rule ID")
    type: str = Field(..., description="Rule type: project, path_pattern, or source")
    value: str = Field(..., description="Value to match")
    enabled: bool = Field(default=True, description="Whether rule is enabled")
    created_at: Optional[float] = Field(default=None, description="Creation timestamp")


class ImportConfigModel(BaseModel):
    """Model for import configuration."""

    hidden_projects: List[str] = Field(default_factory=list, description="Hidden project encodings")
    hidden_sessions: List[str] = Field(default_factory=list, description="Hidden session IDs")
    auto_import_rules: List[AutoImportRuleModel] = Field(
        default_factory=list, description="Auto-import rules"
    )
    watcher_enabled: bool = Field(default=False, description="Whether watcher is enabled")
    show_hidden_by_default: bool = Field(default=False, description="Show hidden by default")
    dedup_window_seconds: int = Field(default=60, description="Deduplication window in seconds")
    watched_platforms: List[str] = Field(default_factory=list, description="Platforms to auto-import from (e.g. claude, codex, opencode, cursor)")
    watched_projects: List[str] = Field(default_factory=list, description="Encoded project paths to auto-import")
    cursor_poll_interval: float = Field(default=30.0, description="Seconds between Cursor polls (SQLite polling)")


class ImportConfigUpdateRequest(BaseModel):
    """Request for updating import config."""

    hidden_projects: Optional[List[str]] = Field(default=None, description="Hidden project encodings")
    hidden_sessions: Optional[List[str]] = Field(default=None, description="Hidden session IDs")
    auto_import_rules: Optional[List[AutoImportRuleModel]] = Field(
        default=None, description="Auto-import rules"
    )
    watcher_enabled: Optional[bool] = Field(default=None, description="Whether watcher is enabled")
    show_hidden_by_default: Optional[bool] = Field(default=None, description="Show hidden by default")
    dedup_window_seconds: Optional[int] = Field(default=None, description="Deduplication window")
    watched_platforms: Optional[List[str]] = Field(default=None, description="Platforms to auto-import from (e.g. claude, codex, opencode, cursor)")
    watched_projects: Optional[List[str]] = Field(default=None, description="Encoded project paths to auto-import")
    cursor_poll_interval: Optional[float] = Field(default=None, description="Seconds between Cursor polls (SQLite polling)")


class WatcherStatusModel(BaseModel):
    """Model for watcher status."""

    running: bool = Field(..., description="Whether watcher is running")
    watched_paths: List[str] = Field(default_factory=list, description="Paths being watched")
    last_check: Optional[float] = Field(default=None, description="Last check timestamp")
    auto_import_count: int = Field(default=0, description="Number of auto-imports")
    errors: List[str] = Field(default_factory=list, description="Recent errors")
