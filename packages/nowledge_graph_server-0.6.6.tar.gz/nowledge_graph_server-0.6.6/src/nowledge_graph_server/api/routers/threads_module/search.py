"""Thread search and summary endpoints."""

from typing import Optional

from fastapi import APIRouter, HTTPException, Depends, Query

import structlog

from nowledge_graph_server.api.dependencies import get_thread_operations
from nowledge_graph_server.core.thread_operations import ThreadOperations

from .schemas import (
    ThreadSummariesResponse,
    ThreadSearchResponse,
)


logger = structlog.get_logger(__name__)

router = APIRouter()


@router.get("/threads/summaries", response_model=ThreadSummariesResponse)
async def get_thread_summaries(
    thread_ops: ThreadOperations = Depends(get_thread_operations),
) -> ThreadSummariesResponse:
    """Get all thread titles/summaries."""
    try:
        summaries = await thread_ops.get_thread_summaries()  # type: ignore[attr-defined]
        return ThreadSummariesResponse(summaries=summaries)
    except Exception as e:
        logger.error("Failed to get thread summaries", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to get thread summaries")


@router.get("/threads/search", response_model=ThreadSearchResponse)
async def search_threads_full(
    query: str = Query(..., description="Search query"),
    mode: str = Query(
        default="full", description="Search mode: 'suggestions' or 'full'"
    ),
    limit: int = Query(default=20, ge=1, le=500),
    source: Optional[str] = Query(default=None, description="Filter by source (e.g. 'openclaw', 'claude-code')"),
    thread_ops: ThreadOperations = Depends(get_thread_operations),
) -> ThreadSearchResponse:
    """Full thread search with message matching."""
    try:
        # Fetch more results when source filtering to compensate for post-filter reduction
        fetch_limit = limit * 3 if source else limit
        results = await thread_ops.search_threads_enhanced(  # type: ignore[attr-defined]
            query=query,
            mode=mode,
            limit=fetch_limit,
        )
        # Apply source filter post-search (search_threads_enhanced doesn't support it natively)
        if source and "threads" in results:
            results["threads"] = [
                t for t in results["threads"] if t.get("source") == source
            ][:limit]
            results["total_found"] = len(results["threads"])
        # Convert to Pydantic model
        return ThreadSearchResponse(**results)  # type: ignore[arg-type]
    except Exception as e:
        logger.error("Thread search failed", query=query, mode=mode, error=str(e))
        raise HTTPException(status_code=500, detail=f"Thread search failed: {str(e)}")
