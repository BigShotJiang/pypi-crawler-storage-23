from typing import Optional, List
from fastapi import APIRouter, HTTPException, Depends, Query
from nowledge_graph_server.api.dependencies import (
    get_kuzu_client,
)
from nowledge_graph_server.database.kuzu_client import KuzuClient
from nowledge_graph_server.utils.progress_logger import log_data_change
import structlog
from pydantic import BaseModel, Field

logger = structlog.get_logger(__name__)

router = APIRouter()


class LabelResponse(BaseModel):
    """Label response model."""

    id: str = Field(..., description="Label identifier")
    name: str = Field(..., description="Label name")
    color: str = Field(..., description="Label color (hex)")
    description: Optional[str] = Field(default=None, description="Label description")
    created_at: Optional[str] = Field(default=None, description="Creation timestamp")
    updated_at: Optional[str] = Field(default=None, description="Last update timestamp")
    usage_count: int = Field(
        0, description="Number of memories/entities using this label"
    )

    # Allow additional fields for flexibility
    class Config:
        extra = "allow"


class DeleteLabelResponse(BaseModel):
    """Response model for label deletion."""

    message: str = Field(..., description="Deletion status message")


@router.get("/labels", response_model=List[LabelResponse])
async def list_labels(
    limit: int = Query(default=100, ge=1, le=1000),
    order_by: str = Query(default="name"),
    order_desc: bool = Query(default=False),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> List[LabelResponse]:
    """List all labels with usage counts."""
    try:
        labels = await kuzu_client.list_labels(
            limit=limit,
            order_by=order_by,
            order_desc=order_desc,
        )
        # Convert dict list to Pydantic models
        return [LabelResponse(**label) for label in labels]
    except Exception as e:
        logger.error("Failed to list labels", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to list labels")


@router.post("/labels", response_model=LabelResponse)
async def create_label(
    name: str = Query(..., description="Label name"),
    color: str = Query(default="#3b82f6", description="Label color (hex)"),
    description: str = Query(default="", description="Label description"),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> LabelResponse:
    """Create a new label."""
    try:
        label = await kuzu_client.create_label(
            name=name,
            color=color,
            description=description if description else None,
        )
        
        # Notify UI of data change
        log_data_change(
            change_type="label_created",
            entity_type="label",
            entity_id=label["id"],
        )
        
        # Convert dict to Pydantic model
        return LabelResponse(**label)
    except Exception as e:
        logger.error("Failed to create label", name=name, error=str(e))
        raise HTTPException(status_code=500, detail="Failed to create label")


@router.get("/labels/{label_id}", response_model=LabelResponse)
async def get_label(
    label_id: str,
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> LabelResponse:
    """Get a specific label by ID."""
    try:
        label = await kuzu_client.label_mgr.get_label_by_id(label_id)  # type: ignore[attr-defined]
        if label is None:
            raise HTTPException(status_code=404, detail="Label not found")
        # Convert dict to Pydantic model
        return LabelResponse(**label)  # type: ignore[arg-type]
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to get label", label_id=label_id, error=str(e))
        raise HTTPException(status_code=500, detail="Failed to get label")


@router.put("/labels/{label_id}", response_model=LabelResponse)
async def update_label(
    label_id: str,
    name: Optional[str] = Query(default=None, description="Label name"),
    color: Optional[str] = Query(default=None, description="Label color (hex)"),
    description: Optional[str] = Query(default=None, description="Label description"),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> LabelResponse:
    """Update an existing label."""
    try:
        label = await kuzu_client.label_mgr.update_label(  # type: ignore[attr-defined]
            label_id=label_id,
            name=name,
            color=color,
            description=description,
        )
        if label is None:
            raise HTTPException(status_code=404, detail="Label not found")
        
        # Notify UI of data change
        log_data_change(
            change_type="label_updated",
            entity_type="label",
            entity_id=label_id,
        )
        
        # Convert dict to Pydantic model
        return LabelResponse(**label)  # type: ignore[arg-type]
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to update label", label_id=label_id, error=str(e))
        raise HTTPException(status_code=500, detail="Failed to update label")


@router.delete("/labels/{label_id}", response_model=DeleteLabelResponse)
async def delete_label(
    label_id: str,
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
) -> DeleteLabelResponse:
    """Delete a label and all its relationships."""
    try:
        success = await kuzu_client.label_mgr.delete_label(label_id)  # type: ignore[attr-defined]
        if not success:
            raise HTTPException(status_code=404, detail="Label not found")
        
        # Notify UI of data change
        log_data_change(
            change_type="label_deleted",
            entity_type="label",
            entity_id=label_id,
        )
        
        return DeleteLabelResponse(message="Label deleted successfully")
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to delete label", label_id=label_id, error=str(e))
        raise HTTPException(status_code=500, detail="Failed to delete label")
