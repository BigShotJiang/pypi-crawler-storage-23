"""
Graph Analysis API endpoints for community detection and centrality analysis.
"""

from fastapi import APIRouter, HTTPException, Depends, Query
from typing import Dict, Any, Optional, List
import datetime

import structlog
from pydantic import BaseModel, Field
import real_ladybug as kuzu
from nowledge_graph_server.core.graph_operations import GraphOperations
from ...services.graph_analysis import get_graph_analysis_service
from ...services.augmentation_jobs import AugmentationJobService
from nowledge_graph_server.api.dependencies import (
    get_graph_operations,
    get_kuzu_client,
    get_search_operations,
)
from nowledge_graph_server.core.search_operations import SearchOperations

logger = structlog.get_logger(__name__)

router = APIRouter()


class CommunityDetectionRequest(BaseModel):
    """Request model for community detection."""

    resolution: float = 1.0
    max_iterations: int = 20
    include_summarization: bool = False
    min_cluster_size: int = 3


class PageRankRequest(BaseModel):
    """Request model for PageRank calculation."""

    persist_results: bool = True


class GraphNodeMetadata(BaseModel):
    """Metadata for graph nodes."""

    entity_type: Optional[str] = None
    confidence: Optional[float] = None
    degree: Optional[int] = None
    community_id: Optional[int] = None
    pagerank_score: Optional[float] = None
    hop_count: Optional[int] = None
    description: Optional[str] = None
    title: Optional[str] = None
    content: Optional[str] = None
    importance: Optional[float] = None
    entity_count: Optional[int] = None
    thread_id: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    source: Optional[str] = None

    # Allow additional fields for flexibility
    class Config:
        extra = "allow"


class GraphNode(BaseModel):
    """Graph node data structure."""

    id: str = Field(..., description="Node identifier")
    label: str = Field(..., description="Display label for the node")
    node_type: str = Field(..., description="Type of node (entity, memory, etc.)")
    node_subtype: Optional[str] = Field(default=None, description="Subtype of the node")
    size: float = Field(..., description="Node size for visualization")
    color: str = Field(..., description="Node color for visualization")
    community: Optional[str] = Field(
        default=None, description="Community ID this node belongs to"
    )
    importance: Optional[float] = Field(
        default=None, description="Importance score of the node"
    )
    hop_count: Optional[int] = Field(default=None, description="Number of hops from source")
    pagerank_score: Optional[float] = Field(default=None, description="PageRank score")
    thread_id: Optional[str] = Field(default=None, description="Thread ID if node is a thread")
    metadata: GraphNodeMetadata = Field(
        default_factory=lambda: GraphNodeMetadata(),
        description="Additional node metadata",
    )

    # Allow additional fields for flexibility
    class Config:
        extra = "allow"


class GraphEdgeMetadata(BaseModel):
    """Metadata for graph edges."""

    relation_type: Optional[str] = None
    relationship_type: Optional[str] = None
    context: Optional[str] = None
    path_length: Optional[int] = None
    hop_count: Optional[int] = None
    description: Optional[str] = None
    strength: Optional[float] = None
    confidence: Optional[float] = None
    conditions: Optional[str] = None
    temporal_info: Optional[str] = None
    source_reference: Optional[str] = None
    source_name: Optional[str] = None
    target_name: Optional[str] = None
    source_id: Optional[str] = None
    target_id: Optional[str] = None
    path_position: Optional[int] = None
    total_path_length: Optional[int] = None
    visualization: Optional[Dict[str, Any]] = None

    # Allow additional fields for flexibility
    class Config:
        extra = "allow"


class GraphEdge(BaseModel):
    """Graph edge data structure."""

    id: str = Field(..., description="Edge identifier")
    source: str = Field(..., description="Source node ID")
    target: str = Field(..., description="Target node ID")
    edge_type: str = Field(..., description="Type of edge relationship")
    weight: float = Field(..., description="Edge weight")
    label: Optional[str] = Field(default=None, description="Display label for the edge")
    relevance_score: Optional[float] = Field(default=None, description="Relevance score")
    metadata: GraphEdgeMetadata = Field(
        default_factory=lambda: GraphEdgeMetadata(),
        description="Additional edge metadata",
    )

    # Allow additional fields for flexibility
    class Config:
        extra = "allow"


class GraphCommunity(BaseModel):
    """Community data structure."""

    id: str = Field(..., description="Community identifier")
    name: str = Field(..., description="Community name")
    description: Optional[str] = Field("", description="Community description")
    member_count: int = Field(0, description="Number of members in the community")
    strength: float = Field(1.0, description="Community strength score")
    algorithm: Optional[str] = Field(
        "louvain", description="Algorithm used for detection"
    )
    resolution: Optional[float] = Field(1.0, description="Resolution parameter used")
    metadata: Optional[Dict[str, Any]] = Field(
        default_factory=dict, description="Additional community metadata"
    )

    # Allow additional fields for flexibility
    class Config:
        extra = "allow"


class GraphCommunityHull(BaseModel):
    """Community hull data structure for visualization."""

    community_id: str = Field(..., description="Community identifier")
    community_name: str = Field(..., description="Community name")
    member_nodes: List[str] = Field(
        default_factory=list, description="List of node IDs in this community"
    )
    member_count: int = Field(..., description="Number of members")
    hull_type: str = Field("convex", description="Type of hull visualization")
    color: str = Field("#9B59B6", description="Hull color")
    opacity: float = Field(0.1, description="Hull opacity")
    stroke_color: str = Field("#8E44AD", description="Hull stroke color")
    stroke_width: int = Field(2, description="Hull stroke width")
    metadata: Optional[Dict[str, Any]] = Field(
        default_factory=dict, description="Additional hull metadata"
    )

    # Allow additional fields for flexibility
    class Config:
        extra = "allow"


class VisualizationConfig(BaseModel):
    """Visualization configuration."""

    node_size_range: List[int] = Field(default_factory=lambda: [10, 50])
    edge_weight_range: List[int] = Field(default_factory=lambda: [1, 6])
    layout_recommendations: Dict[str, Any] = Field(default_factory=dict)

    # Allow additional fields for flexibility
    class Config:
        extra = "allow"


class GraphMetadata(BaseModel):
    """Metadata about the graph data."""

    total_nodes: int = Field(0, description="Total number of nodes")
    total_edges: int = Field(0, description="Total number of edges")
    total_communities: int = Field(0, description="Total number of communities")
    entity_nodes: Optional[int] = Field(default=None, description="Number of entity nodes")
    memory_nodes: Optional[int] = Field(default=None, description="Number of memory nodes")
    relationship_edges: Optional[int] = Field(
        default=None, description="Number of RELATES_TO edges"
    )
    mention_edges: Optional[int] = Field(default=None, description="Number of MENTIONS edges")
    traversal_depth: Optional[int] = Field(default=None, description="Traversal depth used")
    query_method: Optional[str] = Field(default=None, description="Query method used")
    filter_type: Optional[str] = Field(default=None, description="Filter type applied")
    error: Optional[str] = Field(default=None, description="Error message if any")

    # Allow additional fields for flexibility
    class Config:
        extra = "allow"


def _create_visualization_config() -> VisualizationConfig:
    """Factory function to create VisualizationConfig with defaults."""
    return VisualizationConfig(
        node_size_range=[10, 50], edge_weight_range=[1, 6], layout_recommendations={}
    )


def _create_graph_metadata() -> GraphMetadata:
    """Factory function to create GraphMetadata with defaults."""
    return GraphMetadata(
        total_nodes=0,
        total_edges=0,
        total_communities=0,
        entity_nodes=None,
        memory_nodes=None,
        relationship_edges=None,
        mention_edges=None,
        traversal_depth=None,
        query_method=None,
        filter_type=None,
        error=None,
    )


class GraphDataResponse(BaseModel):
    """Graph data response for visualization."""

    nodes: List[GraphNode] = Field(
        default_factory=list, description="List of graph nodes"
    )
    edges: List[GraphEdge] = Field(
        default_factory=list, description="List of graph edges"
    )
    communities: List[GraphCommunity] = Field(
        default_factory=list, description="List of communities"
    )
    community_hulls: List[GraphCommunityHull] = Field(
        default_factory=list, description="List of community hulls"
    )
    visualization_config: VisualizationConfig = Field(
        default_factory=_create_visualization_config,
        description="Visualization configuration",
    )
    metadata: GraphMetadata = Field(
        default_factory=_create_graph_metadata, description="Graph metadata"
    )

    # Allow additional fields for backward compatibility
    class Config:
        extra = "allow"


class SearchResultsSummary(BaseModel):
    """Summary of search results counts."""

    memories_found: int = Field(0, description="Number of memories found")
    entities_found: int = Field(0, description="Number of entities found")
    threads_found: int = Field(0, description="Number of threads found")
    communities_found: int = Field(0, description="Number of communities found")

    # Allow additional fields for flexibility
    class Config:
        extra = "allow"


class GraphStatsSummary(BaseModel):
    """Summary of graph statistics."""

    memory_nodes: int = Field(0, description="Number of memory nodes")
    entity_nodes: int = Field(0, description="Number of entity nodes")
    community_nodes: int = Field(0, description="Number of community nodes")
    mention_edges: int = Field(0, description="Number of MENTIONS edges")
    relation_edges: int = Field(0, description="Number of RELATES_TO edges")

    # Allow additional fields for flexibility
    class Config:
        extra = "allow"


class FiltersApplied(BaseModel):
    """Filters applied to the search."""

    node_types: Optional[List[str]] = Field(default=None, description="Node types filter")
    edge_types: Optional[List[str]] = Field(default=None, description="Edge types filter")

    # Allow additional fields for flexibility
    class Config:
        extra = "allow"


def _create_search_results_summary() -> SearchResultsSummary:
    """Factory function to create SearchResultsSummary with defaults."""
    return SearchResultsSummary(
        memories_found=0, entities_found=0, threads_found=0, communities_found=0
    )


def _create_graph_stats_summary() -> GraphStatsSummary:
    """Factory function to create GraphStatsSummary with defaults."""
    return GraphStatsSummary(
        memory_nodes=0,
        entity_nodes=0,
        community_nodes=0,
        mention_edges=0,
        relation_edges=0,
    )


def _create_filters_applied() -> FiltersApplied:
    """Factory function to create FiltersApplied with defaults."""
    return FiltersApplied(node_types=None, edge_types=None)


class SearchMetadata(BaseModel):
    """Metadata specific to search operations."""

    search_method: str = Field(..., description="Method used for search")
    search_results: SearchResultsSummary = Field(
        default_factory=_create_search_results_summary,
        description="Summary of search results",
    )
    graph_stats: GraphStatsSummary = Field(
        default_factory=_create_graph_stats_summary, description="Graph statistics"
    )
    filters_applied: FiltersApplied = Field(
        default_factory=_create_filters_applied, description="Filters applied to search"
    )
    visualization_ready: bool = Field(
        True, description="Whether results are ready for visualization"
    )
    unified_query: bool = Field(True, description="Whether unified query was used")

    # Allow additional fields for flexibility
    class Config:
        extra = "allow"


class GraphSearchResponse(BaseModel):
    """Graph search response that extends GraphDataResponse with search-specific fields."""

    nodes: Optional[List[GraphNode]] = Field(
        default_factory=list, description="List of graph nodes"
    )
    edges: Optional[List[GraphEdge]] = Field(
        default_factory=list, description="List of graph edges"
    )
    communities: List[GraphCommunity] = Field(
        default_factory=list, description="List of communities"
    )
    community_hulls: List[GraphCommunityHull] = Field(
        default_factory=list, description="List of community hulls"
    )
    visualization_config: VisualizationConfig = Field(
        default_factory=_create_visualization_config,
        description="Visualization configuration",
    )
    metadata: Optional[GraphMetadata] = Field(
        default_factory=_create_graph_metadata, description="Graph metadata"
    )
    query: str = Field(..., description="Search query string")
    search_metadata: Optional[SearchMetadata] = Field(
        default=None, description="Search-specific metadata"
    )

    # Allow additional fields for backward compatibility
    class Config:
        extra = "allow"


@router.get("/search", response_model=GraphSearchResponse)
async def search_graph(
    query: str = Query(..., description="Search query"),
    limit: int = Query(default=30, ge=1, le=100),
    depth: int = Query(
        default=2, ge=1, le=5, description="Traversal depth for graph search"
    ),
    node_types: Optional[List[str]] = Query(
        default=None, description="Filter by node types"
    ),
    edge_types: Optional[List[str]] = Query(
        default=None, description="Filter by edge types"
    ),
    include_metadata: bool = Query(
        default=True, description="Include metadata in results"
    ),
    graph_ops: GraphOperations = Depends(get_graph_operations),
    search_ops: SearchOperations = Depends(get_search_operations),
) -> GraphSearchResponse:
    """Enhanced graph search that finds relevant content and builds visualization data."""
    try:
        logger.debug("Graph search request", query=query[:50], limit=limit, depth=depth)

        # Use GraphOperations to handle the entire search → graph conversion
        result = await graph_ops.get_graph_data_for_search(
            query=query,
            limit=limit,
            depth=depth,
            node_types=node_types,
            edge_types=edge_types,
            search_ops=search_ops,
        )

        logger.debug(
            "Graph search completed",
            query=query[:30],
            nodes=len(result["nodes"]),
            edges=len(result["edges"]),
        )

        # Convert dict to Pydantic model - FastAPI will handle validation and serialization
        return GraphSearchResponse(**result)

    except Exception as e:
        logger.error("Graph search failed", query=query, error=str(e), exc_info=True)
        raise HTTPException(status_code=500, detail="Graph search failed")


@router.get("/sample", response_model=GraphDataResponse)
async def get_graph_data(
    filter_type: str = Query(default=None),
    limit: int = Query(default=50, ge=10, le=500),
    depth: int = Query(
        default=1, ge=1, le=5, description="Traversal depth for relationships"
    ),
    graph_ops: GraphOperations = Depends(get_graph_operations),
) -> GraphDataResponse:
    """Get graph data for visualization."""
    try:
        data = await graph_ops.get_graph_data_for_visualization(
            filter_type=filter_type, limit=limit, depth=depth
        )
        # Convert dict to Pydantic model - FastAPI will handle validation and serialization
        return GraphDataResponse(**data)
    except Exception as e:
        logger.error("Failed to get graph data", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to get graph data")


class ExpandNeighborsMetadata(BaseModel):
    expansion_depth: int = Field(
        ..., description="How far the expansion traversed in hops"
    )
    max_limit: int = Field(..., description="Limit on nodes returned")
    include_metadata: bool = Field(
        ..., description="If results include detailed metadata"
    )
    query_type: str = Field(..., description="Indicates the search/query method")
    error: Optional[str] = Field(default=None, description="Error message if failed")


class ExpandNeighborsResponse(BaseModel):
    center_node: str = Field(..., description="ID of expanded node")
    depth: int = Field(..., description="Traversal depth used for expansion")
    neighbors: List[Any] = Field(
        default_factory=list, description="Neighbor nodes discovered in expansion"
    )
    edges: List[Any] = Field(
        default_factory=list,
        description="Edges connecting neighbors to center or each other",
    )
    total_neighbors: int = Field(0, description="Number of neighbors found")
    total_edges: int = Field(0, description="Number of edges found")
    metadata: ExpandNeighborsMetadata


@router.get("/expand/{node_id}", response_model=ExpandNeighborsResponse)
async def expand_neighbors(
    node_id: str,
    depth: int = Query(default=1, ge=1, le=5, description="Expansion depth"),
    limit: int = Query(
        default=50, ge=1, le=100, description="Maximum neighbors to return"
    ),
    include_metadata: bool = Query(
        default=True, description="Include metadata in results"
    ),
    graph_ops: GraphOperations = Depends(get_graph_operations),
) -> ExpandNeighborsResponse:
    """Expand neighbors of a specific node to get connected nodes and edges with depth-based traversal."""
    try:
        logger.debug(
            "Expand neighbors request", node_id=node_id, depth=depth, limit=limit
        )

        # UNIFIED APPROACH: Use the same method as search API for consistency
        # This ensures identical edge processing and eliminates duplicates

        # Single unified query using path functions
        # Exclude Label nodes from expansion results
        path_query = f"""
            MATCH p = (start)-[*1..{depth}]-(neighbor)
            WHERE start.id = $node_id 
            AND start <> neighbor
            AND LABEL(neighbor) <> "Label"
            RETURN p,
                   LENGTH(p) as path_length,
                   NODES(p) as path_nodes,
                   RELS(p) as path_rels
            ORDER BY path_length ASC, 
                     CASE 
                         WHEN neighbor.importance IS NOT NULL THEN neighbor.importance
                         WHEN neighbor.confidence IS NOT NULL THEN neighbor.confidence
                         ELSE 0.5
                     END DESC
            LIMIT $limit
        """

        try:
            assert graph_ops.kuzu_client.conn is not None, (
                "Kuzu client connection is None"
            )
            result = graph_ops.kuzu_client.conn.execute(
                path_query, {"node_id": node_id, "limit": limit}
            )

            if isinstance(result, list):
                if result:
                    result = result[0]
                else:
                    raise Exception("Empty result list")

            # Use the SAME shared method as search API for consistent edge processing
            neighbors, edges = graph_ops._process_path_results(  # type: ignore[attr-defined]
                result, center_node_id=node_id, context="expand_neighbors"
            )

            response = ExpandNeighborsResponse(
                center_node=node_id,
                depth=depth,
                neighbors=list(neighbors),  # type: ignore[arg-type]
                edges=list(edges),  # type: ignore[arg-type]
                total_neighbors=len(neighbors) if neighbors is not None else 0,  # type: ignore[arg-type]
                total_edges=len(edges) if edges is not None else 0,  # type: ignore[arg-type]
                metadata=ExpandNeighborsMetadata(
                    expansion_depth=depth,
                    max_limit=limit,
                    include_metadata=include_metadata,
                    query_type="unified_path_query",
                    error=None,
                ),
            )
            return response

        except Exception as e:
            logger.error("Failed to execute path query", error=str(e), exc_info=True)
            # Fallback to empty results rather than crashing
            response = ExpandNeighborsResponse(
                center_node=node_id,
                depth=depth,
                neighbors=[],
                edges=[],
                total_neighbors=0,
                total_edges=0,
                metadata=ExpandNeighborsMetadata(
                    expansion_depth=depth,
                    max_limit=limit,
                    include_metadata=include_metadata,
                    query_type="unified_path_query",
                    error="Failed to process results",
                ),
            )
            return response

    except Exception as e:
        logger.error("Expand neighbors failed", error=str(e))
        raise HTTPException(
            status_code=500, detail=f"Failed to expand neighbors: {str(e)}"
        )


class AnalysisSummaryModel(BaseModel):
    total_communities: int = Field(
        0, description="Total number of detected communities"
    )
    total_entities: int = Field(0, description="Total number of entities")
    total_memories: int = Field(0, description="Total number of memories")
    total_relationships: int = Field(0, description="Total number of relationships")
    network_density: float = Field(0.0, description="Graph network density")


class GraphAnalysisResponseModel(BaseModel):
    communities: List[Any] = Field(
        default_factory=list, description="List of community data"
    )
    community_metrics: Dict[str, Any] = Field(
        default_factory=dict, description="Community metrics"
    )
    centrality_measures: Dict[str, Any] = Field(
        default_factory=dict, description="Centrality measures"
    )
    graph_statistics: Dict[str, Any] = Field(
        default_factory=dict, description="Graph statistics"
    )
    analysis_summary: AnalysisSummaryModel = Field(
        ..., description="Summary of analysis metrics"
    )

    retrieved_at: object = Field(default=None, description="Timestamp when data was retrieved")


@router.get("/analysis", response_model=GraphAnalysisResponseModel)
async def get_graph_analysis(
    graph_ops: GraphOperations = Depends(get_graph_operations),
) -> GraphAnalysisResponseModel:
    """
    Get comprehensive graph analysis including community and centrality metrics.

    This endpoint provides a complete overview of the graph structure, communities,
    and centrality measures without triggering new calculations.
    """
    try:
        logger.debug("Retrieving comprehensive graph analysis")

        # Initialize graph operations if needed
        await graph_ops.initialize()  # type: ignore[attr-defined]

        # Get comprehensive community analysis
        analysis = await graph_ops.get_community_analysis(
            resolution=1.0, max_iterations=20
        )

        # Get graph statistics
        statistics = await graph_ops.get_graph_statistics()

        # Build response using Pydantic model
        analysis_summary = AnalysisSummaryModel(
            total_communities=len(analysis.get("communities", [])),
            total_entities=statistics.get("entity_count", 0),
            total_memories=statistics.get("memory_count", 0),
            total_relationships=statistics.get("relationship_count", 0),
            network_density=statistics.get("network_density", 0.0),
        )

        result = GraphAnalysisResponseModel(
            communities=analysis.get("communities", []),
            community_metrics=analysis.get("community_metrics", {}),
            centrality_measures=analysis.get("centrality_measures", {}),
            graph_statistics=statistics,
            analysis_summary=analysis_summary,
            retrieved_at=analysis.get("computed_at"),
        )

        logger.debug(
            "Retrieved comprehensive graph analysis",
            communities=result.analysis_summary.total_communities,
            entities=result.analysis_summary.total_entities,
            memories=result.analysis_summary.total_memories,
        )

        return result

    except Exception as e:
        logger.error("Failed to retrieve graph analysis", error=str(e))
        raise HTTPException(
            status_code=500, detail=f"Failed to retrieve graph analysis: {str(e)}"
        )


class GraphAnalysisCapabilitiesModel(BaseModel):
    community_detection: bool = Field(
        ..., description="Is community detection available"
    )
    pagerank_calculation: bool = Field(
        ..., description="Is PageRank calculation available"
    )
    unified_graph_analysis: bool = Field(
        ..., description="Unified graph analysis supported"
    )
    llm_summarization: bool = Field(..., description="LLM summarization supported")


class GraphAnalysisHealthCheckModel(BaseModel):
    status: str
    error: str | None = None
    algo_extension_loaded: bool
    db_connection: str
    capabilities: GraphAnalysisCapabilitiesModel
    checked_at: str | None = None  # Could override with datetime


@router.get("/health", response_model=GraphAnalysisHealthCheckModel)
async def graph_analysis_health() -> GraphAnalysisHealthCheckModel:
    """
    Health check for graph analysis service.

    Returns the status of algo extension and graph analysis capabilities.
    """

    try:
        # Get the kuzu client to test connection
        kuzu_client = await get_kuzu_client()
        assert kuzu_client.conn is not None, "DB client connection is None"
        graph_analysis_service = get_graph_analysis_service(kuzu_client.conn)

        # Try to initialize the service (which tests algo extension)
        await graph_analysis_service.initialize()

        checked_time = datetime.datetime.now(datetime.timezone.utc).isoformat()
        logger.debug("Graph analysis health checked", checked_at=checked_time)
        return GraphAnalysisHealthCheckModel(
            status="healthy",
            error=None,
            algo_extension_loaded=graph_analysis_service._algo_extension_loaded,  # type: ignore[attr-defined]
            db_connection="active",
            capabilities=GraphAnalysisCapabilitiesModel(
                community_detection=graph_analysis_service._algo_extension_loaded,  # type: ignore[attr-defined]
                pagerank_calculation=graph_analysis_service._algo_extension_loaded,  # type: ignore[attr-defined]
                unified_graph_analysis=True,
                llm_summarization=True,
            ),
            checked_at=checked_time,
        )

    except Exception as e:
        checked_time = datetime.datetime.now(datetime.timezone.utc).isoformat()
        logger.error(
            "Graph analysis health check failed", error=str(e), checked_at=checked_time
        )
        return GraphAnalysisHealthCheckModel(
            status="unhealthy",
            error=str(e),
            algo_extension_loaded=False,
            db_connection="failed",
            capabilities=GraphAnalysisCapabilitiesModel(
                community_detection=False,
                pagerank_calculation=False,
                unified_graph_analysis=False,
                llm_summarization=False,
            ),
            checked_at=checked_time,
        )


class AugmentationStartRequest(BaseModel):
    """Request model for starting an augmentation job."""

    job_type: str  # e.g., 'community_detection', 'pagerank_calculation', etc.
    parameters: Dict[str, Any] = Field(default_factory=dict)


class AugmentationStateModel(BaseModel):
    """Pydantic model describing the augmentation state response."""

    success: bool
    state: Dict[str, Any]


@router.get("/augmentation/state", response_model=AugmentationStateModel)
async def get_augmentation_state() -> AugmentationStateModel:
    """
    Get the current graph augmentation state.

    Returns information about which augmentations are currently applied,
    their parameters, and the last augmentation timestamp.
    """
    try:
        kuzu_client = await get_kuzu_client()
        job_service = AugmentationJobService(kuzu_client)  # type: ignore[arg-type]
        await job_service.initialize()

        state = await job_service.get_graph_augmentation_state()

        return AugmentationStateModel(success=True, state=state)

    except Exception as e:
        logger.error(f"Failed to get augmentation state: {e}")
        raise HTTPException(status_code=500, detail=str(e))


class AugmentationJobStartResponse(BaseModel):
    success: bool
    job_id: str
    job_type: str
    message: str


class AugmentationJobStatusResponse(BaseModel):
    success: bool
    job_status: Dict[str, Any]


class AugmentationJobItem(BaseModel):
    job_id: str
    job_type: str
    status: str
    progress: Any
    message: Any
    created_at: Any


class AugmentationJobListResponse(BaseModel):
    success: bool
    jobs: List[AugmentationJobItem]
    total: int


@router.post("/augmentation/start", response_model=AugmentationJobStartResponse)
async def start_augmentation_job(
    request: AugmentationStartRequest,
) -> AugmentationJobStartResponse:
    """
    Start a background augmentation job.

    Supports job types:
    - 'community_detection': Apply Louvain community detection
    - 'pagerank_calculation': Apply PageRank importance calculation
    - 'undo_community_detection': Remove community detection augmentation
    - 'undo_pagerank_calculation': Remove PageRank augmentation
    """
    try:
        # Validate job type
        valid_job_types = [
            "community_detection",
            "pagerank_calculation",
            "undo_community_detection",
            "undo_pagerank_calculation",
        ]

        if request.job_type not in valid_job_types:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid job type. Must be one of: {valid_job_types}",
            )

        kuzu_client = await get_kuzu_client()
        job_service = AugmentationJobService(kuzu_client)  # type: ignore[arg-type]
        await job_service.initialize()

        # Create and start the job
        job_id = await job_service.create_job(request.job_type, request.parameters)
        await job_service.start_job(job_id)

        return AugmentationJobStartResponse(
            success=True,
            job_id=job_id,
            job_type=request.job_type,
            message="Job started successfully",
        )

    except Exception as e:
        logger.error(f"Failed to start augmentation job: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/augmentation/status/{job_id}", response_model=AugmentationJobStatusResponse
)
async def get_job_status(job_id: str) -> AugmentationJobStatusResponse:
    """
    Get the status of a specific augmentation job.

    Returns job progress, status, and any error messages.
    """
    try:
        kuzu_client = await get_kuzu_client()
        job_service = AugmentationJobService(kuzu_client)  # type: ignore[arg-type]
        await job_service.initialize()

        status = await job_service.get_job_status(job_id)

        return AugmentationJobStatusResponse(success=True, job_status=status)

    except Exception as e:
        logger.error(f"Failed to get job status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/augmentation/jobs", response_model=AugmentationJobListResponse)
async def list_augmentation_jobs(
    limit: int = Query(default=10, ge=1, le=500), status_filter: Optional[str] = None
) -> AugmentationJobListResponse:
    """
    List recent augmentation jobs.

    Optionally filter by status (pending, running, completed, failed).
    """
    try:
        kuzu_client = await get_kuzu_client()

        # Ensure connection is available
        if kuzu_client.conn is None:
            raise HTTPException(
                status_code=500, detail="Database connection not available"
            )

        # Build query with optional status filter
        query = "MATCH (j:AugmentationJob)"
        params = {}

        if status_filter:
            query += " WHERE j.status = $status_filter"
            params["status_filter"] = status_filter

        query += " RETURN j.job_id, j.job_type, j.status, j.progress, j.message, j.created_at"
        query += " ORDER BY j.created_at DESC"
        query += f" LIMIT {limit}"

        result = kuzu_client.conn.execute(query, params)  # type: ignore[call-overload]
        assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

        jobs: List[AugmentationJobItem] = []
        while result.has_next():
            row = result.get_next()
            jobs.append(
                AugmentationJobItem(
                    job_id=row[0],  # type: ignore
                    job_type=row[1],  # type: ignore
                    status=row[2],  # type: ignore
                    progress=row[3],  # type: ignore
                    message=row[4],  # type: ignore
                    created_at=row[5],  # type: ignore
                )
            )

        return AugmentationJobListResponse(success=True, jobs=jobs, total=len(jobs))

    except Exception as e:
        logger.error(f"Failed to list augmentation jobs: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# === Orphan Cleanup Endpoints ===


class OrphanedEntityItem(BaseModel):
    """Orphaned entity item."""

    entity_id: str
    entity_name: str
    entity_type: Optional[str] = None


class OrphanedEntitiesResponse(BaseModel):
    """Response for orphaned entities lookup."""

    success: bool
    orphaned_entities: List[OrphanedEntityItem]
    count: int


class CleanupOrphansResponse(BaseModel):
    """Response for orphan cleanup operation."""

    success: bool
    deleted_count: int
    message: str


@router.get("/orphans", response_model=OrphanedEntitiesResponse)
async def find_orphaned_entities() -> OrphanedEntitiesResponse:
    """
    Find all orphaned entities in the graph.

    Orphaned entities are Entity nodes that have no relationships:
    - No MENTIONS from any Memory
    - No RELATES_TO connections to other entities
    - No HAS_LABEL relationships
    - No BELONGS_TO community relationships

    This only checks Entity nodes, not internal system nodes like schema versions.
    """
    try:
        kuzu_client = await get_kuzu_client()

        if kuzu_client.conn is None:
            raise HTTPException(
                status_code=500, detail="Database connection not available"
            )

        # Find orphaned entities - only Entity nodes, safe for internal nodes
        query = """
            MATCH (e:Entity)
            WHERE NOT (e)<-[:MENTIONS]-(:Memory)
              AND NOT (e)-[:RELATES_TO]-()
              AND NOT (e)-[:HAS_LABEL]-()
            RETURN e.id as entity_id, e.name as entity_name, e.entity_type as entity_type
        """

        result = kuzu_client.conn.execute(query)
        orphaned_entities: List[OrphanedEntityItem] = []

        while result.has_next():  # type: ignore
            row = result.get_next()  # type: ignore
            orphaned_entities.append(
                OrphanedEntityItem(
                    entity_id=row[0],  # type: ignore
                    entity_name=row[1],  # type: ignore
                    entity_type=row[2],  # type: ignore
                )
            )

        logger.info("Found orphaned entities", count=len(orphaned_entities))
        return OrphanedEntitiesResponse(
            success=True,
            orphaned_entities=orphaned_entities,
            count=len(orphaned_entities),
        )

    except Exception as e:
        logger.error(f"Failed to find orphaned entities: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/orphans", response_model=CleanupOrphansResponse)
async def cleanup_orphaned_entities() -> CleanupOrphansResponse:
    """
    Clean up all orphaned entities from the graph.

    This safely removes Entity nodes that have no relationships:
    - No MENTIONS from any Memory
    - No RELATES_TO connections to other entities
    - No HAS_LABEL relationships

    This operation only affects Entity nodes and will not delete:
    - Internal system nodes (GraphMeta, migrations, etc.)
    - Label nodes
    - Community nodes
    - Memory nodes
    """
    try:
        kuzu_client = await get_kuzu_client()

        if kuzu_client.conn is None:
            raise HTTPException(
                status_code=500, detail="Database connection not available"
            )

        # First, find and count orphaned entities
        find_query = """
            MATCH (e:Entity)
            WHERE NOT (e)<-[:MENTIONS]-(:Memory)
              AND NOT (e)-[:RELATES_TO]-()
              AND NOT (e)-[:HAS_LABEL]-()
            RETURN e.id as entity_id
        """

        result = kuzu_client.conn.execute(find_query)
        orphan_ids: List[str] = []

        while result.has_next():  # type: ignore
            row = result.get_next()  # type: ignore
            orphan_ids.append(row[0])  # type: ignore

        if not orphan_ids:
            return CleanupOrphansResponse(
                success=True,
                deleted_count=0,
                message="No orphaned entities found to clean up.",
            )

        # Delete each orphaned entity safely using DETACH DELETE
        deleted_count = 0
        for entity_id in orphan_ids:
            try:
                delete_query = """
                    MATCH (e:Entity {id: $entity_id})
                    DETACH DELETE e
                """
                kuzu_client.conn.execute(delete_query, {"entity_id": entity_id})
                deleted_count += 1
            except Exception as delete_error:
                logger.warning(
                    f"Failed to delete orphaned entity {entity_id}: {delete_error}"
                )

        # Checkpoint to ensure changes are persisted
        kuzu_client.conn.execute("CHECKPOINT;")

        logger.info("Cleaned up orphaned entities", deleted_count=deleted_count)
        return CleanupOrphansResponse(
            success=True,
            deleted_count=deleted_count,
            message=f"Successfully cleaned up {deleted_count} orphaned entities.",
        )

    except Exception as e:
        logger.error(f"Failed to cleanup orphaned entities: {e}")
        raise HTTPException(status_code=500, detail=str(e))
