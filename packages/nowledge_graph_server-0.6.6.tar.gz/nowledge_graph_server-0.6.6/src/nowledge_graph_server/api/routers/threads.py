"""
Thread management API router.

This module has been refactored into a modular structure under threads_module/.
This file re-exports the router for backward compatibility.

Module structure:
- threads_module/schemas.py: Pydantic models for requests/responses
- threads_module/crud.py: Create, Read, Update, Delete operations
- threads_module/search.py: Search and summary operations
- threads_module/export.py: Thread export functionality
- threads_module/discovery.py: Conversation discovery and import
- threads_module/sessions.py: Session persistence and watcher operations
"""

# Re-export router from modular structure
from nowledge_graph_server.api.routers.threads_module import router

# Re-export schemas for backward compatibility with any direct imports
from nowledge_graph_server.api.routers.threads_module.schemas import (
    ThreadSummariesResponse,
    ThreadFromFileResponse,
    AppendMessagesResponse,
    ThreadPublic,
    ThreadPaginationInfo,
    ThreadListResponse,
    ThreadCoverageResponse,
    DeleteThreadResponse,
    BulkDeleteThreadsRequest,
    BulkDeleteThreadsResponse,
    ThreadSearchMetadata,
    ThreadSearchResponse,
    ConversationDiscoveryResponse,
    ConversationImportRequestModel,
    SessionSaveRequest,
    SessionSaveResultItem,
    SessionSaveResponse,
    AutoImportRuleModel,
    ImportConfigModel,
    ImportConfigUpdateRequest,
    WatcherStatusModel,
)

# Re-export export utilities for backward compatibility
from nowledge_graph_server.api.routers.threads_module.export import (
    export_thread_json,
    export_thread_markdown,
    export_thread_html,
)

__all__ = [
    "router",
    # Schemas
    "ThreadSummariesResponse",
    "ThreadFromFileResponse",
    "AppendMessagesResponse",
    "ThreadPublic",
    "ThreadPaginationInfo",
    "ThreadListResponse",
    "ThreadCoverageResponse",
    "DeleteThreadResponse",
    "BulkDeleteThreadsRequest",
    "BulkDeleteThreadsResponse",
    "ThreadSearchMetadata",
    "ThreadSearchResponse",
    "ConversationDiscoveryResponse",
    "ConversationImportRequestModel",
    "SessionSaveRequest",
    "SessionSaveResultItem",
    "SessionSaveResponse",
    "AutoImportRuleModel",
    "ImportConfigModel",
    "ImportConfigUpdateRequest",
    "WatcherStatusModel",
    # Export utilities
    "export_thread_json",
    "export_thread_markdown",
    "export_thread_html",
]
