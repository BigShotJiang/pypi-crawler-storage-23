"""Model management endpoints for checking and installing models."""

import asyncio
from pathlib import Path
from typing import Dict, Any, Literal, List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

# Lazy imports to avoid startup issues - moved to function level

router = APIRouter()


class ModelInstallRequest(BaseModel):
    """Request model for model installation."""

    include_llm: bool = False
    force_reinstall: bool = False
    download_source: Literal["huggingface", "modelscope", "auto"] = "auto"


class ModelStatusResponse(BaseModel):
    """Response model for model status."""

    embedding: bool
    local_llm: bool
    bge_m3: bool = False  # BGE-M3 for hybrid search index
    needs_installation: bool
    message: str
    cache_info: Dict[str, Any] = {}
    model_states: Dict[str, Any] = {}
    verification_summary: Dict[str, Any] = {}


class ModelVerifyResponse(BaseModel):
    """Response model for explicit model verification call."""

    success: bool
    models: Dict[str, Any]
    all_ready: bool
    message: str


@router.get("/status", response_model=ModelStatusResponse, include_in_schema=False)
async def get_models_status(
    full_verify: bool = False,
    force_refresh: bool = False,
):
    """Check the status of cached models."""
    try:
        from ...utils.model_cache import ModelCacheManager
        from ...services.model_verification import get_builtin_model_states

        cache_manager = ModelCacheManager()

        model_states = await get_builtin_model_states(
            full_verify=full_verify,
            force_refresh=force_refresh,
        )
        search_state = model_states.get("search_embedding", {})
        llm_state = model_states.get("local_llm", {})

        embedding_ready = search_state.get("state") in ("installed_unverified", "ready")
        llm_ready = llm_state.get("state") in ("installed_unverified", "ready")

        # Get cache info
        cache_info: Dict[str, Any] = cache_manager.get_cache_info()  # type: ignore[assignment]

        # Add search embedding model info to cache info for UI compatibility
        cache_info["bge_m3"] = {
            "exists": embedding_ready,
            "model": search_state.get("model_name", "search-embedding"),
            "state": search_state.get("state"),
            "verified": search_state.get("verified", False),
        }

        needs_installation = not embedding_ready

        ready_models = [
            model_id
            for model_id, state in model_states.items()
            if state.get("state") == "ready"
        ]
        corrupted_models = [
            model_id
            for model_id, state in model_states.items()
            if state.get("state") == "corrupted"
        ]
        verification_summary = {
            "full_verify_requested": full_verify,
            "ready_models": ready_models,
            "corrupted_models": corrupted_models,
            "all_usable": len(corrupted_models) == 0 and embedding_ready,
        }

        status_message = "Models status checked successfully"
        if corrupted_models:
            status_message = (
                "Model integrity check failed for: "
                + ", ".join(corrupted_models)
                + ". Please reinstall."
            )

        return ModelStatusResponse(
            embedding=embedding_ready,
            local_llm=llm_ready,
            bge_m3=embedding_ready,
            needs_installation=needs_installation,
            message=status_message,
            cache_info=cache_info,
            model_states=model_states,
            verification_summary=verification_summary,
        )

    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to check model status: {str(e)}"
        )


@router.get("/verify", response_model=ModelVerifyResponse, include_in_schema=False)
async def verify_models(
    force_refresh: bool = True,
    model_ids: Optional[str] = None,
):
    """Run full runtime verification for built-in local models."""
    try:
        from ...services.model_verification import get_builtin_model_states

        targets = None
        if model_ids:
            targets = [item.strip() for item in model_ids.split(",") if item.strip()]

        model_states = await get_builtin_model_states(
            full_verify=True,
            force_refresh=force_refresh,
            target_models=targets,
        )
        all_ready = all(
            state.get("state") in ("ready", "unsupported")
            for state in model_states.values()
        )
        message = (
            "All requested models passed verification"
            if all_ready
            else "One or more models failed verification"
        )
        return ModelVerifyResponse(
            success=True,
            models=model_states,
            all_ready=all_ready,
            message=message,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Model verification failed: {str(e)}")


async def install_models_background(
    include_llm: bool = False,
    force_reinstall: bool = False,
    download_source: str = "auto",
):
    """Background task to install models.

    When include_llm=True, ONLY downloads LLM (not embedding).
    When include_llm=False, downloads embedding only.
    This avoids confusion where clicking "Download LLM" also downloads embedding.
    """
    try:
        from ...utils.model_cache import ModelCacheManager
        from ...services.model_verification import get_builtin_model_states

        cache_manager = ModelCacheManager()

        # Setup HuggingFace environment with mirror detection
        await cache_manager.setup_huggingface_environment()

        # Check what's already installed
        models_exist = cache_manager.check_models_exist()
        embedding_exists = models_exist.get("embedding", False)
        llm_exists = models_exist.get("local_llm", False)

        print(f"🔍 install_models_background: include_llm={include_llm}, embedding_exists={embedding_exists}, llm_exists={llm_exists}")

        if include_llm:
            # LLM-only download: skip embedding, only download LLM
            if not llm_exists or force_reinstall:
                print("🚀 Downloading LLM model...")
                llm_success = await cache_manager.cache_llm_model(
                    download_source=download_source
                )
                if not llm_success:
                    raise Exception("Failed to install LLM model")
                verification = await get_builtin_model_states(
                    full_verify=True,
                    force_refresh=True,
                    target_models=["local_llm"],
                )
                llm_state = verification.get("local_llm", {})
                if llm_state.get("state") != "ready":
                    raise Exception(
                        f"LLM verification failed: {llm_state.get('error') or llm_state.get('message')}"
                    )
                print("✅ LLM model installed successfully")
            else:
                print("✅ LLM model already installed, skipping")
        else:
            # Embedding-only download
            if not embedding_exists or force_reinstall:
                print("🚀 Downloading embedding model...")
                embedding_success = await cache_manager.cache_embedding_model(
                    download_source=download_source
                )
                if not embedding_success:
                    raise Exception("Failed to install embedding model")
                verification = await get_builtin_model_states(
                    full_verify=True,
                    force_refresh=True,
                    target_models=["search_embedding"],
                )
                embedding_state = verification.get("search_embedding", {})
                if embedding_state.get("state") != "ready":
                    raise Exception(
                        "Embedding verification failed: "
                        f"{embedding_state.get('error') or embedding_state.get('message')}"
                    )
                print("✅ Embedding model installed successfully")
            else:
                print("✅ Embedding model already installed, skipping")

            # Warm up language detection model alongside embedding setup.
            # This pre-loads the bundled fast-langdetect model so the first
            # search query doesn't trigger a cold-start model load.
            await cache_manager.warm_up_lang_detect()

        print("✅ Model installation completed successfully")

    except Exception as e:
        print(f"❌ Model installation failed: {str(e)}")
        raise


@router.post("/install", include_in_schema=False)
async def install_models(
    request: ModelInstallRequest,
):
    """Install required models with smart caching and mirror selection."""
    try:
        # Lazy import to avoid startup issues
        from ...utils.model_cache import ModelCacheManager

        # Check if models are already installed (unless force reinstall)
        if not request.force_reinstall:
            cache_manager = ModelCacheManager()
            models_exist = cache_manager.check_models_exist()

            # Check if requested models are already installed
            embedding_exists = models_exist.get("embedding", False)
            llm_exists = models_exist.get("local_llm", False)

            # Debug logging
            print(
                f"🔍 Install check - embedding_exists: {embedding_exists}, llm_exists: {llm_exists}, include_llm: {request.include_llm}"
            )
            print(f"🔍 Request object: {request}")
            print(f"🔍 Force reinstall: {request.force_reinstall}")
            print(
                f"🔍 Early return condition: {embedding_exists and (not request.include_llm or llm_exists)}"
            )
            print(
                f"🔍 Breakdown: embedding_exists={embedding_exists}, not include_llm={not request.include_llm}, llm_exists={llm_exists}"
            )

            # Return early only if all requested models are already installed
            if embedding_exists and (not request.include_llm or llm_exists):
                print("🔄 Returning early - requested models already installed")
                return {
                    "status": "success",
                    "message": "Requested models already installed",
                    "embedding": True,
                    "local_llm": llm_exists,
                }

            print("🚀 Proceeding with installation...")

        # Clean up conflicting cache structures if specific source is chosen
        if request.download_source != "auto":  # type: ignore[comparison-overlap]
            await _cleanup_conflicting_cache_structures(request.download_source)

        # Install synchronously for now (background tasks removed for simplicity)
        # Run installation in a background task to avoid blocking the main event loop
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(
            None,
            lambda: asyncio.run(
                install_models_background(
                    request.include_llm,
                    request.force_reinstall,
                    request.download_source,
                )
            ),
        )

        return {
            "status": "success",
            "message": "Models installed successfully",
            "embedding": True,
            "local_llm": request.include_llm,
        }

    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Model installation failed: {str(e)}"
        )


@router.get("/mirrors", include_in_schema=False)
async def get_mirror_info() -> Dict[str, Any]:
    """Get information about available mirrors and connectivity."""
    try:
        from ...utils.model_cache import HuggingFaceMirrorManager

        mirror_manager = HuggingFaceMirrorManager()

        # Test all mirrors
        mirror_status = {}
        for name, url in mirror_manager.MIRRORS.items():
            is_accessible = mirror_manager.test_mirror_connectivity(url)
            mirror_status[name] = {"url": url, "accessible": is_accessible}

        # Get best mirror
        best_mirror = mirror_manager.get_best_mirror()

        # Detect region
        region = mirror_manager.detect_region()

        return {"region": region, "best_mirror": best_mirror, "mirrors": mirror_status}

    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to get mirror info: {str(e)}"
        )


@router.delete("/cache", include_in_schema=False)
async def clear_model_cache() -> Dict[str, Any]:
    """Clear model cache (for troubleshooting)."""
    try:
        from ...utils.model_cache import ModelCacheManager

        cache_manager = ModelCacheManager()

        # Get cache info before clearing
        cache_info: Dict[str, Any] = cache_manager.get_cache_info()  # type: ignore[assignment]

        # Clear cache directories
        import shutil
        from pathlib import Path

        cleared_paths: List[str] = []

        if cache_manager.embedding_cache_dir.exists():
            shutil.rmtree(cache_manager.embedding_cache_dir)
            cache_manager.embedding_cache_dir.mkdir(parents=True, exist_ok=True)
            cleared_paths.append("embedding_cache")

        # Clear the parent directory (contains both hub/ for HF format and org/ for ModelScope format)
        # hf_cache_dir is typically ~/.cache/nowledge/llm/huggingface/hub
        # ModelScope downloads go to hf_cache_dir.parent (e.g., ~/.cache/nowledge/llm/huggingface/mlx-community/)
        hf_parent = cache_manager.huggingface_cache_dir.parent
        if hf_parent.exists():
            shutil.rmtree(hf_parent)
            hf_parent.mkdir(parents=True, exist_ok=True)
            cleared_paths.append("huggingface_cache")

        # Clear ModelScope cache as well
        modelscope_cache_root = Path.home() / ".cache" / "modelscope"
        if modelscope_cache_root.exists():
            shutil.rmtree(modelscope_cache_root)
            cleared_paths.append("modelscope_cache")

        return {
            "status": "success",
            "message": "Model cache cleared successfully",
            "cleared_size_mb": cache_info.get("total_size_mb", 0),
            "cleared_paths": cleared_paths,
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to clear cache: {str(e)}")


# Cache cleanup functions


async def _cleanup_conflicting_cache_structures(chosen_source: str) -> None:
    """Clean up conflicting cache structures when a specific source is chosen.

    This ensures that when a user explicitly chooses a download source,
    any existing cache from the other source is removed to avoid conflicts.
    Handles both embedding and LLM models.
    """
    try:
        from ...config import get_settings

        settings = get_settings()

        print(
            f"🧹 Cleaning up conflicting cache structures for source: {chosen_source}"
        )

        if chosen_source == "auto":
            print(f"  → Source is 'auto', no cleanup needed")
            return

        # Clean up embedding models
        await _cleanup_embedding_cache(chosen_source, settings)

        # Clean up LLM models
        await _cleanup_llm_cache(chosen_source, settings)

        # Clean up any existing HuggingFace Git LFS cache (XET is now disabled)
        await _cleanup_huggingface_git_cache()

    except Exception as e:
        print(f"⚠️ Failed to cleanup conflicting cache structures: {e}")
        # Don't raise - this is not critical for installation


async def _cleanup_embedding_cache(chosen_source: str, settings: "Settings") -> None:  # type: ignore[assignment]
    """Clean up embedding model cache conflicts."""
    if not settings.embedding_cache_dir:  # type: ignore[attr-defined]
        print("  → No embedding cache directory configured, skipping embedding cleanup")
        return

    embedding_cache_dir = Path(settings.embedding_cache_dir)  # type: ignore[assignment]
    if not embedding_cache_dir.exists():
        return

    print(f"  📦 Cleaning embedding cache...")

    # Define model names to check
    embedding_model: str = (  # type: ignore[assignment]
        settings.embedding_model  # type: ignore[attr-defined]
    )  # e.g., "mlx-community/Qwen3-Embedding-0.6B-4bit-DWQ" or "BAAI/bge-m3"
    hf_cache_name = f"models--{embedding_model.replace('/', '--')}"  # type: ignore[arg-type]

    # Determine which paths to remove based on chosen source
    if chosen_source == "huggingface":
        # Keep HF format, remove ModelScope format and mixed
        paths_to_remove: List[Path] = [
            embedding_cache_dir / embedding_model,  # ModelScope format
            embedding_cache_dir / embedding_model / hf_cache_name,  # Mixed structure
        ]
        print(f"    → Keeping HuggingFace format, removing ModelScope/mixed structures")

    elif chosen_source == "modelscope":
        # Keep ModelScope format, remove HF format and mixed
        paths_to_remove = [
            embedding_cache_dir / hf_cache_name,  # HF format in base
            embedding_cache_dir / embedding_model / hf_cache_name,  # Mixed structure
        ]
        print(f"    → Keeping ModelScope format, removing HuggingFace/mixed structures")
    else:
        return

    # Remove conflicting paths
    await _remove_paths(paths_to_remove, "embedding")


async def _cleanup_llm_cache(chosen_source: str, settings: "Settings") -> None:  # type: ignore[assignment]
    """Clean up LLM model cache conflicts."""
    if not settings.llm_cache_dir:  # type: ignore[attr-defined]
        print("  → No LLM cache directory configured, skipping LLM cleanup")
        return

    print(f"  🤖 Cleaning LLM cache...")

    # LLM model name (hardcoded for now, could be made configurable)
    llm_model = "mlx-community/Qwen3-4B-Instruct-2507-DDWQ"

    # HuggingFace cache location
    # settings.llm_cache_dir is already ~/.cache/huggingface, so we just need /hub
    hf_cache_dir = Path(settings.llm_cache_dir) / "hub"  # type: ignore[assignment]
    hf_model_cache = hf_cache_dir / f"models--{llm_model.replace('/', '--')}"

    # ModelScope cache location (if it exists)
    modelscope_cache_dir = Path.home() / ".cache" / "modelscope" / "hub" / "models"
    org, model_name = llm_model.split("/", 1)
    modelscope_model_cache = modelscope_cache_dir / org / model_name

    # Determine which paths to remove based on chosen source
    if chosen_source == "huggingface":
        # Keep HF format, remove ModelScope format
        paths_to_remove = (
            [modelscope_model_cache] if modelscope_model_cache.exists() else []
        )
        print(f"    → Keeping HuggingFace format, removing ModelScope format")

    elif chosen_source == "modelscope":
        # Keep ModelScope format, remove HF format
        paths_to_remove = [hf_model_cache] if hf_model_cache.exists() else []
        print(f"    → Keeping ModelScope format, removing HuggingFace format")
    else:
        return

    # Remove conflicting paths
    await _remove_paths(paths_to_remove, "LLM")


async def _cleanup_huggingface_git_cache() -> None:
    """Clean up HuggingFace Git LFS cache (xet directory) to save space."""
    try:
        hf_cache_root = Path.home() / ".cache" / "huggingface"
        xet_cache = hf_cache_root / "xet"

        if xet_cache.exists():
            print(f"  🗑️  Cleaning HuggingFace Git LFS cache...")
            import shutil

            # Get size before cleanup
            import subprocess

            try:
                result = subprocess.run(
                    ["du", "-sh", str(xet_cache)], capture_output=True, text=True
                )
                size_before = (
                    result.stdout.split()[0] if result.returncode == 0 else "unknown"
                )
            except:
                size_before = "unknown"

            shutil.rmtree(xet_cache)
            print(f"    ✓ Removed HuggingFace Git LFS cache ({size_before})")
        else:
            print(f"    → No HuggingFace Git LFS cache found")

    except Exception as e:
        print(f"    ✗ Failed to cleanup HuggingFace Git LFS cache: {e}")


async def _remove_paths(paths_to_remove: List[Path], model_type: str) -> None:
    """Remove a list of paths and report results."""
    import shutil

    removed_count = 0

    for path_to_remove in paths_to_remove:
        if path_to_remove.exists():
            try:
                if path_to_remove.is_dir():
                    shutil.rmtree(path_to_remove)
                else:
                    path_to_remove.unlink()
                print(f"    ✓ Removed {model_type}: {path_to_remove}")
                removed_count += 1
            except Exception as e:
                print(f"    ✗ Failed to remove {path_to_remove}: {e}")

    if removed_count > 0:
        print(
            f"    🧹 Cleaned up {removed_count} conflicting {model_type} cache structure(s)"
        )
    else:
        print(f"    🧹 No conflicting {model_type} cache structures found to clean up")


# ==================== Search Embedding Model Endpoints ====================
#
# These endpoints manage the search embedding model for LanceDB hybrid search.
# The model is platform-specific:
# - macOS Apple Silicon: Qwen3-Embedding via mlx-embeddings (~400MB)
# - non-Apple-Silicon (Windows/Linux/macOS Intel): BGE-M3 via FastEmbed/ONNX (~2.3GB)
#
# The endpoint names use "bge-m3" for backward compatibility with the frontend.


class BGEM3StatusResponse(BaseModel):
    """Response model for search embedding model status."""

    exists: bool
    model_name: str = "search-embedding"
    size_mb: int = 500  # Approximate average size
    message: str
    # Platform-specific info
    backend: str = "auto"
    platform: str = "unknown"
    # Reindex tracking
    reindex_needed: bool = False  # True if embedding model changed since last reindex
    # Verification state
    state: str = "not_installed"
    verified: bool = False
    integrity_ok: bool = False
    smoke_test_ok: bool = False
    singleton_initialized: bool = False
    last_verified_at: Optional[str] = None
    error: Optional[str] = None


class BGEM3InstallRequest(BaseModel):
    """Request model for search embedding installation."""

    download_source: Literal["huggingface", "modelscope", "auto"] = "auto"
    force_reinstall: bool = False


class BGEM3InstallResponse(BaseModel):
    """Response model for search embedding installation."""

    success: bool
    message: str
    reindex_required: bool = True  # After installation, user should reindex


@router.get("/bge-m3/status", response_model=BGEM3StatusResponse)
async def get_bge_m3_status(
    full_verify: bool = False,
    force_refresh: bool = False,
):
    """Check the status of the search embedding model for hybrid search.

    The model is platform-specific:
    - macOS Apple Silicon: Qwen3-Embedding (1024-dim, ~400MB)
    - non-Apple-Silicon (Windows/Linux/macOS Intel): BGE-M3 (1024-dim, ~2.3GB)

    Both provide high-quality multilingual embeddings for LanceDB hybrid search.
    """
    try:
        from ...services.model_verification import get_builtin_model_states

        states = await get_builtin_model_states(
            full_verify=full_verify,
            force_refresh=force_refresh,
            target_models=["search_embedding"],
        )
        state = states.get("search_embedding", {})
        reindex_needed = _check_reindex_needed()
        model_info = {
            "model_name": state.get("model_name", "search-embedding"),
            "backend": state.get("backend", "auto"),
            "platform": state.get("platform", "unknown"),
            "estimated_size_mb": 0,
        }
        exists = state.get("state") in ("installed_unverified", "ready")

        if state.get("state") == "corrupted":
            return BGEM3StatusResponse(
                exists=False,
                model_name=model_info["model_name"],
                size_mb=model_info["estimated_size_mb"],
                backend=model_info["backend"],
                platform=model_info["platform"],
                reindex_needed=False,
                state=state.get("state", "corrupted"),
                verified=state.get("verified", False),
                integrity_ok=state.get("integrity_ok", False),
                smoke_test_ok=state.get("smoke_test_ok", False),
                singleton_initialized=state.get("singleton_initialized", False),
                last_verified_at=state.get("last_verified_at"),
                error=state.get("error"),
                message=(
                    "Search model files were found but failed integrity or runtime verification. "
                    "Please reinstall the model."
                ),
            )

        if exists:
            current_state = state.get("state", "installed_unverified")
            if current_state == "ready":
                state_message = (
                    f"{model_info['model_name']} is cached and verified for hybrid search. "
                    + ("Rebuild the search index to apply changes." if reindex_needed else "")
                )
            else:
                state_message = (
                    f"{model_info['model_name']} is installed. "
                    "Run verification to confirm runtime integrity."
                )
            return BGEM3StatusResponse(
                exists=True,
                model_name=model_info["model_name"],
                size_mb=state.get("estimated_size_mb", model_info["estimated_size_mb"]),
                backend=model_info["backend"],
                platform=model_info["platform"],
                reindex_needed=reindex_needed,
                state=current_state,
                verified=state.get("verified", False),
                integrity_ok=state.get("integrity_ok", False),
                smoke_test_ok=state.get("smoke_test_ok", False),
                singleton_initialized=state.get("singleton_initialized", False),
                last_verified_at=state.get("last_verified_at"),
                error=state.get("error"),
                message=state_message,
            )
        else:
            return BGEM3StatusResponse(
                exists=False,
                model_name=model_info["model_name"],
                size_mb=state.get("estimated_size_mb", model_info["estimated_size_mb"]),
                backend=model_info["backend"],
                platform=model_info["platform"],
                reindex_needed=False,
                state=state.get("state", "not_installed"),
                verified=state.get("verified", False),
                integrity_ok=state.get("integrity_ok", False),
                smoke_test_ok=state.get("smoke_test_ok", False),
                singleton_initialized=state.get("singleton_initialized", False),
                last_verified_at=state.get("last_verified_at"),
                error=state.get("error"),
                message=(
                    f"Search model not found. Download it to enable advanced hybrid search. "
                    f"The model is ~{model_info['estimated_size_mb']}MB."
                ),
            )

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to check search model status: {str(e)}",
        )


async def _delete_old_e5_embedding_model() -> dict:
    """Delete the old E5 embedding model to save space (~240MB).

    The new search embedding model (Qwen3/BGE-M3 1024-dim) replaces the old
    E5 model (384-dim). This function cleans up the old model files.

    Returns:
        dict with deleted_size_mb and success status
    """
    import shutil
    from ...config import get_app_cache_dir

    deleted_size_mb = 0
    deleted_paths = []

    try:
        # Get the embedding cache directory where old E5 model is stored
        embedding_cache_dir = get_app_cache_dir("embeddings")

        if not embedding_cache_dir.exists():
            return {"success": True, "deleted_size_mb": 0, "deleted_paths": []}

        # Patterns that identify old E5 model directories (lowercase for matching)
        # These cover:
        # - HuggingFace ONNX: models--intfloat--multilingual-e5-small
        # - HuggingFace MLX: models--mlx-community--multilingual-e5-small-...
        # - ModelScope: intfloat/multilingual-e5-small (nested structure)
        # - Generic: multilingual-e5, e5-small
        e5_patterns = [
            "multilingual-e5",
            "e5-small",
            "models--mlx-community--multilingual-e5",
            "models--intfloat--multilingual-e5",
        ]

        def cleanup_directory(dir_path: Path) -> tuple[float, list]:
            """Recursively check and clean E5 models from a directory."""
            local_deleted_mb = 0.0
            local_deleted_paths = []

            if not dir_path.exists():
                return 0.0, []

            for item in dir_path.iterdir():
                if item.is_dir():
                    item_name = item.name.lower()
                    # Check if this directory is an old E5 model
                    if any(pattern in item_name for pattern in e5_patterns):
                        # Calculate size before deletion
                        try:
                            size_bytes = sum(
                                f.stat().st_size for f in item.rglob("*") if f.is_file()
                            )
                            size_mb = size_bytes / (1024 * 1024)
                        except Exception:
                            size_mb = 0

                        # Delete the directory
                        print(f"🗑️ Deleting old E5 model: {item.name} (~{size_mb:.1f} MB)")
                        shutil.rmtree(item)
                        local_deleted_mb += size_mb
                        local_deleted_paths.append(str(item))
                    elif item_name in ["intfloat", "mlx-community"]:
                        # Check inside org directories for ModelScope structure
                        sub_deleted_mb, sub_deleted_paths = cleanup_directory(item)
                        local_deleted_mb += sub_deleted_mb
                        local_deleted_paths.extend(sub_deleted_paths)
                        # Remove empty org directory
                        if item.exists() and not any(item.iterdir()):
                            item.rmdir()

            return local_deleted_mb, local_deleted_paths

        # Clean from main embedding cache dir
        deleted_size_mb, deleted_paths = cleanup_directory(embedding_cache_dir)

        # Also check HuggingFace hub cache (might be separate)
        hf_hub_dir = embedding_cache_dir / "hub"
        if hf_hub_dir.exists():
            hub_deleted_mb, hub_deleted_paths = cleanup_directory(hf_hub_dir)
            deleted_size_mb += hub_deleted_mb
            deleted_paths.extend(hub_deleted_paths)

        if deleted_paths:
            print(f"✅ Cleaned up {deleted_size_mb:.1f} MB of old E5 model files")

        return {
            "success": True,
            "deleted_size_mb": deleted_size_mb,
            "deleted_paths": deleted_paths,
        }

    except Exception as e:
        print(f"⚠️ Failed to delete old E5 model: {e}")
        return {"success": False, "deleted_size_mb": 0, "error": str(e)}


async def _mark_reindex_needed() -> None:
    """Mark that the search index needs to be rebuilt after embedding model change.

    This creates a marker file that the UI can check to prompt for reindex.
    """
    try:
        from ...config import get_app_cache_dir

        cache_dir = get_app_cache_dir("embeddings")
        marker_file = cache_dir / ".reindex_needed"
        marker_file.touch()
        print("📝 Marked search index for rebuild")
    except Exception as e:
        print(f"⚠️ Failed to mark reindex needed: {e}")


async def _clear_reindex_marker() -> None:
    """Clear the reindex needed marker after successful reindex."""
    try:
        from ...config import get_app_cache_dir

        cache_dir = get_app_cache_dir("embeddings")
        marker_file = cache_dir / ".reindex_needed"
        if marker_file.exists():
            marker_file.unlink()
            print("✅ Cleared reindex marker")
    except Exception as e:
        print(f"⚠️ Failed to clear reindex marker: {e}")


def _check_reindex_needed() -> bool:
    """Check if the search index needs to be rebuilt."""
    try:
        from ...config import get_app_cache_dir

        cache_dir = get_app_cache_dir("embeddings")
        marker_file = cache_dir / ".reindex_needed"
        return marker_file.exists()
    except Exception:
        return False


@router.post("/bge-m3/install", response_model=BGEM3InstallResponse)
async def install_bge_m3(request: BGEM3InstallRequest):
    """Download and install the search embedding model for hybrid search.

    The model downloaded is platform-specific:
    - macOS Apple Silicon: Qwen3-Embedding (~400MB, 4-bit quantized)
    - non-Apple-Silicon (Windows/Linux/macOS Intel): BGE-M3 (~2.3GB, ONNX)

    This also deletes the old E5 embedding model to save space.
    After installation, run /search-index/reindex to build the index.
    """
    try:
        from ...services.search_embedding import (
            check_search_model_exists,
            get_search_model_info,
            SearchEmbeddingService,
        )
        from ...services.model_verification import get_builtin_model_states

        model_info = get_search_model_info()

        # Check if already installed
        if not request.force_reinstall and check_search_model_exists():
            return BGEM3InstallResponse(
                success=True,
                message=f"{model_info['model_name']} already installed.",
                reindex_required=_check_reindex_needed(),
            )

        print(f"📦 Starting {model_info['model_name']} download (source: {request.download_source})...")

        # Create service with download enabled and specified source
        service = SearchEmbeddingService(
            cache_only=False,  # Allow download
            download_source=request.download_source,
        )

        # Initialize will trigger download if needed
        # Use try/finally to ensure cleanup even if initialize() fails partway through
        # (e.g., network timeout, disk full) to prevent memory/GPU resource leaks
        try:
            # Note: initialize() is async and handles CPU-bound work internally via run_in_executor
            await service.initialize()
        finally:
            await service.cleanup()

        print(f"✅ {model_info['model_name']} installation completed")

        # Delete old E5 model to save space (~240MB)
        cleanup_result = await _delete_old_e5_embedding_model()
        if cleanup_result.get("deleted_size_mb", 0) > 0:
            print(f"🧹 Freed {cleanup_result['deleted_size_mb']:.1f} MB by removing old E5 model")

        # Mark that reindex is needed
        await _mark_reindex_needed()

        verification = await get_builtin_model_states(
            full_verify=True,
            force_refresh=True,
            target_models=["search_embedding"],
        )
        search_state = verification.get("search_embedding", {})
        if search_state.get("state") != "ready":
            raise RuntimeError(
                "Search embedding verification failed after install: "
                f"{search_state.get('error') or search_state.get('message')}"
            )

        return BGEM3InstallResponse(
            success=True,
            message=(
                f"{model_info['model_name']} installed successfully. "
                "Run /search-index/reindex to build the hybrid search index."
            ),
            reindex_required=True,
        )

    except Exception as e:
        model_info = {"model_name": "Search model"}
        try:
            from ...services.search_embedding import get_search_model_info
            model_info = get_search_model_info()
        except Exception:
            pass
        print(f"❌ {model_info['model_name']} installation failed: {str(e)}")
        return BGEM3InstallResponse(
            success=False,
            message=f"{model_info['model_name']} installation failed: {str(e)}",
            reindex_required=False,
        )
