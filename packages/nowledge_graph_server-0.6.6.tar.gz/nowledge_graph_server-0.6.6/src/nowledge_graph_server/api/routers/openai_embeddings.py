"""OpenAI-compatible embeddings endpoint backed by local search embeddings."""

from __future__ import annotations

import base64
import time
from array import array
from typing import Any, Optional, Sequence

import structlog
from fastapi import APIRouter
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from ...services.search_embedding import (
    SEARCH_EMBEDDING_DIMENSION,
    check_search_model_exists,
    get_search_model_info,
)

logger = structlog.get_logger(__name__)

router = APIRouter(prefix="/v1", tags=["openai-compatible"])


async def get_search_embedding_service():
    """Lazy import singleton accessor to avoid heavy search-index imports at startup."""
    from ...services.search_index.service_factory import (
        get_search_embedding_service as _get_search_embedding_service,
    )

    return await _get_search_embedding_service()


class OpenAIEmbeddingRequest(BaseModel):
    """Request schema compatible with OpenAI's embeddings endpoint."""

    model: Optional[str] = None
    input: Any = None
    encoding_format: str = "float"
    dimensions: Optional[int] = None
    user: Optional[str] = None
    input_type: Optional[str] = Field(
        default=None,
        description="Optional extension: query or document.",
    )


class OpenAIEmbeddingUsage(BaseModel):
    prompt_tokens: int
    total_tokens: int


class OpenAIEmbeddingData(BaseModel):
    object: str = "embedding"
    index: int
    embedding: list[float] | str


class OpenAIEmbeddingResponse(BaseModel):
    object: str = "list"
    data: list[OpenAIEmbeddingData]
    model: str
    usage: OpenAIEmbeddingUsage


class OpenAIModelData(BaseModel):
    id: str
    object: str = "model"
    created: int
    owned_by: str = "nowledge-local"
    permission: list[dict[str, Any]] = Field(default_factory=list)
    root: Optional[str] = None
    parent: Optional[str] = None


class OpenAIModelListResponse(BaseModel):
    object: str = "list"
    data: list[OpenAIModelData]


def _error_response(
    *,
    status_code: int,
    message: str,
    error_type: str,
    param: Optional[str] = None,
    code: Optional[str] = None,
) -> JSONResponse:
    payload: dict[str, Any] = {
        "error": {
            "message": message,
            "type": error_type,
            "param": param,
            "code": code,
        }
    }
    return JSONResponse(status_code=status_code, content=payload)


def _normalize_input_payload(
    raw_input: Any,
) -> tuple[Optional[list[str]], Optional[JSONResponse]]:
    if isinstance(raw_input, str):
        return [raw_input], None

    if isinstance(raw_input, list):
        if not raw_input:
            return None, _error_response(
                status_code=400,
                message="'input' must not be an empty list.",
                error_type="invalid_request_error",
                param="input",
                code="invalid_input",
            )

        normalized: list[str] = []
        for idx, item in enumerate(raw_input):
            if not isinstance(item, str):
                return None, _error_response(
                    status_code=400,
                    message=f"'input[{idx}]' must be a string.",
                    error_type="invalid_request_error",
                    param="input",
                    code="invalid_input_type",
                )
            normalized.append(item)
        return normalized, None

    return None, _error_response(
        status_code=400,
        message="'input' must be a string or a list of strings.",
        error_type="invalid_request_error",
        param="input",
        code="invalid_input_type",
    )


def _estimate_prompt_tokens(texts: Sequence[str]) -> int:
    total = 0
    for text in texts:
        stripped = text.strip()
        if not stripped:
            continue

        if " " in stripped:
            total += max(1, len(stripped.split()))
        else:
            # Fallback for CJK/keyword-like inputs without spaces.
            total += max(1, len(stripped) // 2)
    return total


def _encode_embedding_base64(values: Sequence[float]) -> str:
    float32_bytes = array("f", [float(x) for x in values]).tobytes()
    return base64.b64encode(float32_bytes).decode("ascii")


def _is_supported_model(requested_model: str, backend_model: str) -> bool:
    return requested_model == backend_model


@router.get("/models", response_model=OpenAIModelListResponse)
async def list_models() -> OpenAIModelListResponse:
    model_info = get_search_model_info()
    backend_model = str(model_info.get("model_name", "search-embedding")).strip()
    created_at = int(time.time())

    # Report only the real platform-specific backend model.
    # Compatibility aliases are accepted by /v1/embeddings but are not separate models.
    return OpenAIModelListResponse(
        data=[
            OpenAIModelData(
                id=backend_model,
                created=created_at,
                root=backend_model,
            )
        ]
    )


@router.post("/embeddings", response_model=OpenAIEmbeddingResponse)
async def create_embeddings(
    request: OpenAIEmbeddingRequest,
) -> OpenAIEmbeddingResponse | JSONResponse:
    requested_model = (request.model or "").strip()
    if not requested_model:
        return _error_response(
            status_code=400,
            message="'model' is required.",
            error_type="invalid_request_error",
            param="model",
            code="model_required",
        )

    encoding_format = (request.encoding_format or "float").strip().lower()
    if encoding_format not in {"float", "base64"}:
        return _error_response(
            status_code=400,
            message="'encoding_format' must be either 'float' or 'base64'.",
            error_type="invalid_request_error",
            param="encoding_format",
            code="unsupported_encoding_format",
        )

    if (
        request.dimensions is not None
        and request.dimensions != SEARCH_EMBEDDING_DIMENSION
    ):
        return _error_response(
            status_code=400,
            message=(
                f"'dimensions' is not configurable for the local model. "
                f"Expected {SEARCH_EMBEDDING_DIMENSION}."
            ),
            error_type="invalid_request_error",
            param="dimensions",
            code="unsupported_dimensions",
        )

    input_type = (request.input_type or "document").strip().lower()
    if input_type not in {"query", "document"}:
        return _error_response(
            status_code=400,
            message="'input_type' must be either 'query' or 'document'.",
            error_type="invalid_request_error",
            param="input_type",
            code="invalid_input_type",
        )
    is_query = input_type == "query"

    texts, input_error = _normalize_input_payload(request.input)
    if input_error is not None:
        return input_error
    assert texts is not None  # for typing

    service = await get_search_embedding_service()
    if service is None:
        if not check_search_model_exists():
            message = (
                "Local embedding model is not installed. "
                "Install it via /models/bge-m3/install first."
            )
        else:
            message = (
                "Local embedding service is temporarily unavailable. "
                "Please retry shortly."
            )
        return _error_response(
            status_code=503,
            message=message,
            error_type="service_unavailable_error",
            code="embedding_service_unavailable",
        )

    backend_model = getattr(service, "model_name", "search-embedding")
    if not _is_supported_model(requested_model, backend_model):
        return _error_response(
            status_code=400,
            message=(
                f"Model '{requested_model}' is not available on this local backend. "
                f"Use the exact backend model id: '{backend_model}' "
                "(discoverable via GET /v1/models)."
            ),
            error_type="invalid_request_error",
            param="model",
            code="model_mismatch",
        )

    try:
        embeddings = await service.embed_batch(texts, is_query=is_query)
    except Exception as exc:
        logger.error("OpenAI embedding request failed", error=str(exc))
        return _error_response(
            status_code=500,
            message=f"Failed to create embeddings: {exc}",
            error_type="server_error",
            code="embedding_failed",
        )

    data: list[OpenAIEmbeddingData] = []
    for idx, embedding in enumerate(embeddings):
        formatted_embedding: list[float] | str
        if encoding_format == "base64":
            formatted_embedding = _encode_embedding_base64(embedding)
        else:
            formatted_embedding = [float(x) for x in embedding]
        data.append(
            OpenAIEmbeddingData(
                index=idx,
                embedding=formatted_embedding,
            )
        )

    usage_tokens = _estimate_prompt_tokens(texts)
    return OpenAIEmbeddingResponse(
        data=data,
        model=requested_model,
        usage=OpenAIEmbeddingUsage(
            prompt_tokens=usage_tokens,
            total_tokens=usage_tokens,
        ),
    )
