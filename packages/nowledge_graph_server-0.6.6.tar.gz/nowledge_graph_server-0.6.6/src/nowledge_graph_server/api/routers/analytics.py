from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List
from fastapi import APIRouter, HTTPException, Depends, Query
from fastapi.responses import JSONResponse
from nowledge_graph_server.api.dependencies import (
    get_graph_operations,
    get_kuzu_client,
)
from nowledge_graph_server.core.graph_operations import GraphOperations
from nowledge_graph_server.database.kuzu_client import KuzuClient
import real_ladybug as kuzu
import structlog


logger = structlog.get_logger(__name__)

router = APIRouter()


@router.get("/stats", include_in_schema=False)
async def get_graph_stats(graph_ops: GraphOperations = Depends(get_graph_operations)):
    """Get graph database statistics."""
    try:
        stats = await graph_ops.get_graph_stats()
        return JSONResponse(content=stats)
    except Exception as e:
        logger.error("Failed to get graph stats", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to get graph statistics")


@router.get("/stats/growth", include_in_schema=False)
async def get_memory_growth_timeline(
    months: int = Query(default=6, ge=1, le=240),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
):
    """Get memory growth over time for charts."""
    try:
        if not kuzu_client.conn:
            raise HTTPException(
                status_code=503, detail="Database connection not available"
            )

        # Get memory count by month for the specified period
        query = """
            MATCH (m:Memory)
            WHERE m.created_at IS NOT NULL
            WITH date_part('year', m.created_at) as year, 
                 date_part('month', m.created_at) as month,
                 COUNT(m) as memory_count
            RETURN year, month, memory_count
            ORDER BY year DESC, month DESC
            LIMIT $months
        """

        result = kuzu_client.conn.execute(query, {"months": months})
        assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

        growth_data: List[Dict[str, Any]] = []
        while result.has_next():
            row = result.get_next()
            year, month, count = row[0], row[1], row[2]  # type: ignore
            date_str = f"{int(year)}-{int(month):02d}"
            growth_data.append({"date": date_str, "memories": int(count)})

        # Reverse to get chronological order
        growth_data.reverse()

        # If no data, return mock structure
        if not growth_data:
            growth_data = [{"date": "2024-12", "memories": 0}]

        return JSONResponse(content=growth_data)

    except Exception as e:
        logger.error("Failed to get growth timeline", error=str(e))
        # Return fallback data
        return JSONResponse(content=[{"date": "2024-12", "memories": 0}])


@router.get("/stats/growth/daily", include_in_schema=False)
async def get_daily_memory_growth(
    days: int = Query(default=90, ge=1, le=365),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
):
    """Get per-day memory counts for the activity calendar."""
    try:
        if not kuzu_client.conn:
            raise HTTPException(
                status_code=503, detail="Database connection not available"
            )

        # Compute cutoff as a TIMESTAMP string — avoids novel interval() syntax in KuzuDB
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
        cutoff_str = cutoff.strftime("%Y-%m-%d %H:%M:%S")

        query = """
            MATCH (m:Memory)
            WHERE m.created_at IS NOT NULL
              AND m.created_at >= CAST($cutoff AS TIMESTAMP)
            WITH CAST(m.created_at AS DATE) as day, COUNT(m) as cnt
            RETURN day, cnt
            ORDER BY day ASC
        """

        result = kuzu_client.conn.execute(query, {"cutoff": cutoff_str})
        assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

        daily_data: List[Dict[str, Any]] = []
        while result.has_next():
            row = result.get_next()
            day_val, count = row[0], row[1]  # type: ignore
            daily_data.append({
                "date": str(day_val),
                "count": int(count),
            })

        return JSONResponse(content=daily_data)

    except Exception as e:
        logger.error("Failed to get daily growth", error=str(e))
        return JSONResponse(content=[])


@router.get("/stats/sources", include_in_schema=False)
async def get_source_usage_stats(kuzu_client: KuzuClient = Depends(get_kuzu_client)):
    """Get memory count by source for pie chart."""
    try:
        if not kuzu_client.conn:
            raise HTTPException(
                status_code=503, detail="Database connection not available"
            )

        query = """
            MATCH (m:Memory)
            WITH CASE 
                WHEN m.source IS NULL THEN 'unknown' 
                ELSE LOWER(regexp_replace(m.source, ' ', '_', 'g'))
            END as normalized_source, COUNT(m) as count
            RETURN normalized_source, count
            ORDER BY count DESC
        """

        result = kuzu_client.conn.execute(query)
        assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

        # Dynamic color generation for any source
        def get_source_color(source_name: str) -> str:
            """Generate a consistent color for any source name."""
            if not source_name:
                return "#6b7280"  # Gray for unknown

            # Predefined colors for known sources
            known_colors = {
                "cursor": "#3b82f6",
                "chatwise": "#06b6d4",
                "claude": "#10b981",
                "manual": "#f59e0b",
                "thread_import": "#f97316",
                "mcp_generic": "#8b5cf6",
                "mcp_unknown": "#6b7280",
            }

            if source_name.lower() in known_colors:
                return known_colors[source_name.lower()]

            # Generate consistent color for unknown sources using hash
            import hashlib

            hash_object = hashlib.md5(source_name.encode())
            hash_hex = hash_object.hexdigest()
            # Use first 6 characters for color
            return f"#{hash_hex[:6]}"

        source_data: List[Dict[str, Any]] = []
        while result.has_next():
            row = result.get_next()
            normalized_source, count = row[0], row[1]  # type: ignore

            # Create display name from normalized source
            if normalized_source == "unknown":
                display_name = "Unknown"
            else:
                # Convert normalized source back to readable format
                # e.g., "mcp_generic" -> "MCP Generic", "cursor" -> "Cursor"
                display_name = normalized_source.replace("_", " ").title()

                # Special cases for better display names
                display_name_mapping = {
                    "Mcp Generic": "MCP Generic",
                    "Mcp Unknown": "MCP Unknown",
                    "Thread Import": "Thread Import",
                }
                display_name = display_name_mapping.get(display_name, display_name)

            color = get_source_color(normalized_source)

            source_data.append(
                {"name": display_name, "value": int(count), "fill": color}
            )

        # If no data, return minimal structure
        if not source_data:
            source_data = [
                {"name": "Manual", "value": 0, "fill": "var(--color-manual)"}
            ]

        return JSONResponse(content=source_data)

    except Exception as e:
        logger.error("Failed to get source stats", error=str(e))
        # Return fallback data
        return JSONResponse(
            content=[{"name": "Manual", "value": 0, "fill": "var(--color-manual)"}]
        )


@router.get("/stats/top-communities", include_in_schema=False)
async def get_top_communities(
    limit: int = Query(default=5, ge=1, le=10),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
):
    """Get top communities by member count for bar chart."""
    try:
        if not kuzu_client.conn:
            raise HTTPException(
                status_code=503, detail="Database connection not available"
            )

        # Get communities with member counts
        query = """
            MATCH (c:Community)
            WHERE c.member_count > 0
            RETURN c.name, c.member_count, c.description
            ORDER BY c.member_count DESC
            LIMIT $limit
        """

        result = kuzu_client.conn.execute(query, {"limit": limit})
        assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

        communities_data: List[Dict[str, Any]] = []
        while result.has_next():
            row = result.get_next()  # type: ignore
            name, member_count, description = row[0], row[1], row[2]  # type: ignore

            # Clean up community name
            display_name = name if name else f"Community {len(communities_data) + 1}"

            communities_data.append(
                {
                    "name": display_name,
                    "members": int(member_count),
                    "description": description or "No description available",
                }
            )

        # If no data, return sample structure
        if not communities_data:
            communities_data = [
                {"name": "No Communities", "members": 0, "description": ""}
            ]

        return JSONResponse(content=communities_data)

    except Exception as e:
        logger.error("Failed to get top communities", error=str(e))
        # Return fallback data
        return JSONResponse(
            content=[{"name": "No Communities", "members": 0, "description": ""}]
        )


@router.get("/stats/entity-relations", include_in_schema=False)
async def get_top_entity_relations(
    limit: int = Query(default=5, ge=1, le=20),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
):
    """Get top entity relationship pairs for bar chart.

    DEPRECATED: This endpoint is being phased out in favor of community-based metrics.
    Use /stats/top-communities instead for better insights.
    """
    try:
        if not kuzu_client.conn:
            raise HTTPException(
                status_code=503, detail="Database connection not available"
            )

        # Find entity relationships that actually exist (not just co-mentions)
        query = """
            MATCH (e1:Entity)-[r:RELATES_TO]->(e2:Entity)
            WITH e1.name + ' → ' + e2.name as pair, COUNT(r) as count, r.relation_type as relation_type
            RETURN pair, count
            ORDER BY count DESC
            LIMIT $limit
        """

        result = kuzu_client.conn.execute(query, {"limit": limit})
        assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

        relations_data: List[Dict[str, Any]] = []
        while result.has_next():
            row = result.get_next()  # type: ignore
            pair, count = row[0], row[1]  # type: ignore
            relations_data.append({"pair": pair, "count": int(count)})

        # If no data, return sample structure
        if not relations_data:
            relations_data = [{"pair": "No Relations", "count": 0}]

        return JSONResponse(content=relations_data)

    except Exception as e:
        logger.error("Failed to get entity relations", error=str(e))
        # Return fallback data
        return JSONResponse(content=[{"pair": "No Relations", "count": 0}])


# ── Community Query Endpoints ───────────────────────────────────────────────
# Full community data for CLI/API consumers (richer than /stats/top-communities)


@router.get("/communities")
async def list_communities(
    limit: int = Query(default=20, ge=1, le=50),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
):
    """List knowledge communities with AI summaries."""
    try:
        if not kuzu_client.conn:
            raise HTTPException(status_code=503, detail="Database connection not available")

        result = kuzu_client.conn.execute(
            """
            MATCH (c:Community)
            WHERE c.ai_summary IS NOT NULL AND c.ai_summary <> ''
            RETURN c.id, c.community_id, c.name, c.description, c.ai_summary, c.member_count
            ORDER BY c.member_count DESC
            LIMIT $limit
            """,
            {"limit": limit},
        )

        communities = []
        while result.has_next():
            row = result.get_next()
            communities.append({
                "id": row[0],
                "community_id": row[1],
                "name": row[2],
                "description": row[3] or "",
                "summary": row[4] or "",
                "member_count": row[5] or 0,
            })

        return JSONResponse(content={"communities": communities, "total": len(communities)})

    except Exception as e:
        logger.error("Failed to list communities", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to list communities")


@router.get("/communities/{community_id}")
async def get_community_details(
    community_id: str,
    entity_limit: int = Query(default=20, ge=1, le=50),
    kuzu_client: KuzuClient = Depends(get_kuzu_client),
):
    """Get community details including entities and sample memories."""
    try:
        if not kuzu_client.conn:
            raise HTTPException(status_code=503, detail="Database connection not available")

        # Step 1: Look up community by UUID
        result = kuzu_client.conn.execute(
            """
            MATCH (c:Community)
            WHERE c.id = $cid
            RETURN c.id, c.community_id, c.name, c.description, c.ai_summary, c.member_count
            """,
            {"cid": community_id},
        )

        if not result.has_next():
            raise HTTPException(status_code=404, detail=f"Community not found: {community_id}")

        row = result.get_next()
        community = {
            "id": row[0],
            "community_id": row[1],
            "name": row[2],
            "description": row[3] or "",
            "summary": row[4] or "",
            "member_count": row[5] or 0,
        }
        louvain_id = row[1]

        # Step 2: Find member entities
        result = kuzu_client.conn.execute(
            """
            MATCH (e:Entity)
            WHERE e.community_id = $louvain_id
            OPTIONAL MATCH (m:Memory)-[:MENTIONS]->(e)
            RETURN e.id, e.name, e.entity_type, COUNT(m) AS memory_count
            ORDER BY memory_count DESC
            LIMIT $limit
            """,
            {"louvain_id": louvain_id, "limit": entity_limit},
        )

        entities = []
        while result.has_next():
            erow = result.get_next()
            entities.append({
                "id": erow[0],
                "name": erow[1],
                "entity_type": erow[2],
                "memory_count": erow[3],
            })

        # Step 3: Sample memories
        result = kuzu_client.conn.execute(
            """
            MATCH (e:Entity {community_id: $louvain_id})<-[:MENTIONS]-(m:Memory)
            WHERE m.is_crystal = false
            WITH m, COUNT(e) AS entity_count
            RETURN m.id, m.title, m.content, m.unit_type
            ORDER BY entity_count DESC, m.importance DESC
            LIMIT 5
            """,
            {"louvain_id": louvain_id},
        )

        sample_memories = []
        while result.has_next():
            mrow = result.get_next()
            sample_memories.append({
                "id": mrow[0],
                "title": mrow[1],
                "content_preview": (mrow[2] or "")[:200],
                "unit_type": mrow[3],
            })

        return JSONResponse(content={
            "community": community,
            "entities": entities,
            "sample_memories": sample_memories,
            "entity_count": len(entities),
            "memory_count": len(sample_memories),
        })

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to get community details", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to get community details")
