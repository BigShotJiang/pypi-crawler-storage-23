"""
MCP Proxy Router

Proxies requests to external MCP servers with schema fixes.
Some MCP servers (like Didi, Notion) return invalid JSON Schema types:
- "bool" instead of "boolean"
- "int" instead of "integer"

This proxy fixes these issues before passing to kimi-cli.
"""

import httpx
from fastapi import APIRouter, Request, Response, Header, Query
from typing import Optional
import json
import logging
from urllib.parse import unquote

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/mcp-proxy", tags=["mcp-proxy"])


def fix_json_schema_types(obj):
    """
    Recursively fix invalid JSON Schema types in tool schemas.

    Common issues from MCP servers:
    - "bool" -> "boolean" (Python naming vs JSON Schema)
    - "int" -> "integer" (Python naming vs JSON Schema)
    - "str" -> "string" (Python naming vs JSON Schema)
    - "dict" -> "object" (Python naming vs JSON Schema)
    - "list" -> "array" (Python naming vs JSON Schema)
    """
    type_mapping = {
        "bool": "boolean",
        "int": "integer",
        "str": "string",
        "dict": "object",
        "list": "array",
    }

    if isinstance(obj, dict):
        result = {}
        for key, value in obj.items():
            if key == "type" and isinstance(value, str) and value in type_mapping:
                result[key] = type_mapping[value]
            else:
                result[key] = fix_json_schema_types(value)
        return result
    elif isinstance(obj, list):
        return [fix_json_schema_types(item) for item in obj]
    else:
        return obj


@router.post("/", include_in_schema=False)
async def proxy_mcp_request_with_target(
    request: Request,
    target: str = Query(..., description="Target MCP server URL (URL-encoded)"),
    authorization: Optional[str] = Header(None),
):
    """
    Proxy MCP requests to external servers with schema fixes.

    Usage: POST /mcp-proxy/?target=https%3A%2F%2Fmcp.didichuxing.com%2Fmcp-servers%3Fkey%3DXXX

    The proxy will:
    1. Forward the request to the target MCP server
    2. For tools/list responses, fix invalid JSON Schema types
    3. Return the (potentially fixed) response
    """
    # URL decode the target
    target_url = unquote(target)

    logger.info(f"[MCP Proxy] Proxying request to: {target_url}")

    # Get request body
    body = await request.body()

    # Build headers, forwarding Authorization if present
    headers = {
        "Content-Type": request.headers.get("Content-Type", "application/json"),
    }
    if authorization:
        headers["Authorization"] = authorization

    # Forward additional headers that might be needed
    for header_name in ["Accept", "Accept-Encoding"]:
        if header_name in request.headers:
            headers[header_name] = request.headers[header_name]

    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.request(
                method=request.method,
                url=target_url,
                headers=headers,
                content=body,
            )

            logger.info(
                f"[MCP Proxy] Response status: {response.status_code}, content-type: {response.headers.get('content-type', 'unknown')}"
            )

            # Get response content type
            content_type = response.headers.get("content-type", "")

            # Try to parse and fix JSON responses
            if "application/json" in content_type or (
                "text/event-stream" not in content_type and response.content
            ):
                try:
                    response_body = response.content.decode("utf-8")

                    # Try to parse as JSON
                    try:
                        data = json.loads(response_body)

                        # Check if this is a tools/list response
                        if isinstance(data, dict) and "result" in data:
                            result = data["result"]
                            if isinstance(result, dict) and "tools" in result:
                                # Fix schema types in all tools
                                original_tools = result["tools"]
                                fixed_tools = []
                                for tool in original_tools:
                                    fixed_tool = {
                                        **tool,
                                        "inputSchema": fix_json_schema_types(
                                            tool.get("inputSchema", {})
                                        ),
                                    }
                                    fixed_tools.append(fixed_tool)
                                data["result"]["tools"] = fixed_tools
                                response_body = json.dumps(data)
                                logger.info(
                                    f"[MCP Proxy] Fixed schema types in {len(fixed_tools)} tools"
                                )

                    except json.JSONDecodeError:
                        # Not JSON, pass through as-is
                        logger.debug(
                            "[MCP Proxy] Response is not JSON, passing through"
                        )

                    # Return response with proper content type
                    return Response(
                        content=response_body,
                        status_code=response.status_code,
                        media_type=content_type or "application/json",
                    )
                except Exception as e:
                    logger.warning(f"[MCP Proxy] Error processing response: {e}")
                    # Fall through to return original response

            # For streaming or non-JSON responses, pass through directly
            return Response(
                content=response.content,
                status_code=response.status_code,
                media_type=content_type or "application/octet-stream",
            )

    except httpx.HTTPStatusError as e:
        logger.error(f"[MCP Proxy] HTTP error: {e}")
        return Response(
            content=json.dumps({"error": str(e)}),
            status_code=e.response.status_code,
            media_type="application/json",
        )
    except Exception as e:
        logger.error(f"[MCP Proxy] Error proxying request: {e}")
        return Response(
            content=json.dumps({"error": str(e)}),
            status_code=500,
            media_type="application/json",
        )
