from typing import Optional, List, Dict, Any
from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel, Field
from nowledge_graph_server.api.dependencies import (
    get_kuzu_client,
)
from nowledge_graph_server.database.kuzu_client import KuzuClient
from nowledge_graph_server.models.graph import EntityNode
import structlog


logger = structlog.get_logger(__name__)

router = APIRouter()


class EntitySummary(BaseModel):
    """Summary of an entity for relationship responses."""

    id: str = Field(..., description="Entity ID")
    name: str = Field(..., description="Entity name")
    type: str = Field(..., description="Entity type")
    description: Optional[str] = Field("", description="Entity description")


class RelationshipInfo(BaseModel):
    """Information about a relationship between entities."""

    type: str = Field(..., description="Relationship type (e.g., RELATES_TO)")
    confidence: float = Field(..., description="Confidence score of the relationship")
    strength: float = Field(..., description="Strength of the relationship")


class EntityRelationship(BaseModel):
    """A relationship between two entities."""

    source_entity: EntitySummary = Field(..., description="Source entity")
    target_entity: EntitySummary = Field(..., description="Target entity")
    relationship: RelationshipInfo = Field(..., description="Relationship information")
    depth: int = Field(..., description="Depth of traversal from source entity")


class MemorySummary(BaseModel):
    """Summary of a memory for relationship responses."""

    id: str = Field(..., description="Memory ID")
    title: str = Field("", description="Memory title")
    content: str = Field("", description="Memory content (truncated)")


class MemoryMention(BaseModel):
    """A memory mentioning an entity."""

    memory: MemorySummary = Field(..., description="Memory information")
    confidence: float = Field(..., description="Confidence of the mention")
    mention_count: int = Field(..., description="Number of times entity is mentioned")


class EntityRelationshipsData(BaseModel):
    """Collection of entity relationships."""

    relates_to: List[EntityRelationship] = Field(
        default_factory=list, description="Entity-to-entity relationships"
    )
    mentioned_in: List[MemoryMention] = Field(
        default_factory=list, description="Memories mentioning this entity"
    )


class EntityRelationshipsMetadata(BaseModel):
    """Metadata about entity relationships query."""

    total_relates_to: int = Field(
        ..., description="Total number of entity relationships"
    )
    total_mentions: int = Field(..., description="Total number of memory mentions")
    traversal_depth: int = Field(..., description="Depth of relationship traversal")
    limit: int = Field(..., description="Maximum results returned")


class EntityRelationshipsResponse(BaseModel):
    """Response for entity relationships endpoint."""

    entity: EntitySummary = Field(..., description="The queried entity")
    relationships: EntityRelationshipsData = Field(
        ..., description="All relationships for this entity"
    )
    metadata: EntityRelationshipsMetadata = Field(..., description="Query metadata")


@router.get("/entities")
async def list_entities(
    limit: int = Query(default=50, ge=1, le=200),
    entity_type: None | str = Query(None),
    client: KuzuClient = Depends(get_kuzu_client),
) -> List[EntityNode]:
    """List entities with optional filtering."""
    try:
        # Use the entity repository from the client
        entities: List[EntityNode] = await client.entity_repo.list_entities(
            limit=limit, entity_type=entity_type
        )

        return entities

    except Exception as e:
        logger.error("Failed to list entities", error=str(e))
        raise HTTPException(
            status_code=500, detail=f"Failed to list entities: {str(e)}"
        )


@router.get(
    "/entities/{entity_id}/relationships", response_model=EntityRelationshipsResponse
)
async def get_entity_relationships(
    entity_id: str,
    depth: int = Query(
        default=1, ge=1, le=3, description="Traversal depth for relationships"
    ),
    limit: int = Query(
        default=50, ge=1, le=200, description="Maximum relationships to return"
    ),
    client: KuzuClient = Depends(get_kuzu_client),
) -> EntityRelationshipsResponse:
    """Get relationships for a specific entity.

    Returns all connected entities and memories via RELATES_TO and MENTIONS relationships.
    """
    try:
        if not client.conn:
            raise HTTPException(
                status_code=500, detail="Database connection not available"
            )

        # First verify the entity exists
        verify_query = """
            MATCH (e:Entity {id: $entity_id})
            RETURN e
        """
        verify_result = client.conn.execute(verify_query, {"entity_id": entity_id})

        # Handle result format
        if isinstance(verify_result, list):
            if not verify_result:
                raise HTTPException(
                    status_code=404, detail=f"Entity {entity_id} not found"
                )
            verify_result = verify_result[0]

        if not verify_result.has_next():  # type: ignore
            raise HTTPException(status_code=404, detail=f"Entity {entity_id} not found")

        # Get entity data
        entity_data = verify_result.get_next()[0]  # type: ignore

        # Query for relationships based on depth
        if depth == 1:
            # Simple 1-hop query for better performance
            relationships_query = """
                MATCH (e:Entity {id: $entity_id})-[r:RELATES_TO]-(related:Entity)
                RETURN e, r, related, 'RELATES_TO' as rel_type, 1 as depth
                ORDER BY r.confidence DESC
                LIMIT $limit
            """
        else:
            # Multi-hop query using variable-length paths
            relationships_query = f"""
                MATCH p = (e:Entity {{id: $entity_id}})-[r:RELATES_TO*1..{depth}]-(related:Entity)
                WHERE e <> related
                RETURN e, r, related, 'RELATES_TO' as rel_type, LENGTH(p) as depth
                ORDER BY LENGTH(p) ASC, 
                         CASE WHEN related.confidence IS NOT NULL THEN related.confidence ELSE 0.5 END DESC
                LIMIT $limit
            """

        result = client.conn.execute(
            relationships_query, {"entity_id": entity_id, "limit": limit}
        )

        # Handle result format
        relates_to_relationships: List[EntityRelationship] = []
        if isinstance(result, list):
            if not result:
                # No relationships found - return early with typed response
                return EntityRelationshipsResponse(
                    entity=EntitySummary(
                        id=entity_data["id"],
                        name=entity_data["name"],
                        type=entity_data["entity_type"],
                        description=entity_data.get("description", ""),
                    ),
                    relationships=EntityRelationshipsData(
                        relates_to=[], mentioned_in=[]
                    ),
                    metadata=EntityRelationshipsMetadata(
                        total_relates_to=0,
                        total_mentions=0,
                        traversal_depth=depth,
                        limit=limit,
                    ),
                )
            else:
                result = result[0]

        while result.has_next():  # type: ignore
            row = result.get_next()  # type: ignore
            source_data, rel_data, target_data = row[0], row[1], row[2]  # type: ignore
            path_depth = row[4] if len(row) > 4 else 1  # type: ignore

            # Handle variable-length paths (list of relationships)
            rel_info: Dict[str, Any] = {}
            if isinstance(rel_data, list):
                # For multi-hop, just use the first relationship's data
                rel_info = rel_data[0] if rel_data else {}  # type: ignore
            else:
                rel_info = rel_data

            relates_to_relationships.append(
                EntityRelationship(
                    source_entity=EntitySummary(
                        id=source_data["id"],
                        name=source_data["name"],
                        type=source_data["entity_type"],
                        description="",
                    ),
                    target_entity=EntitySummary(
                        id=target_data["id"],
                        name=target_data["name"],
                        type=target_data["entity_type"],
                        description=target_data.get("description", ""),
                    ),
                    relationship=RelationshipInfo(
                        type=rel_info.get("relation_type", "RELATES_TO")
                        if isinstance(rel_info, dict)
                        else "RELATES_TO",  # type: ignore
                        confidence=rel_info.get("confidence", 0.5)
                        if isinstance(rel_info, dict)
                        else 0.5,  # type: ignore
                        strength=rel_info.get("strength", 0.5)
                        if isinstance(rel_info, dict)
                        else 0.5,  # type: ignore
                    ),
                    depth=path_depth,
                )
            )

        # Query for MENTIONS relationships (memories mentioning this entity)
        mentions_query = """
            MATCH (m:Memory)-[r:MENTIONS]->(e:Entity {id: $entity_id})
            RETURN m, r
            ORDER BY r.confidence DESC
            LIMIT $limit
        """

        mentions_result = client.conn.execute(
            mentions_query, {"entity_id": entity_id, "limit": limit}
        )

        # Handle result format
        mentions: List[MemoryMention] = []
        if isinstance(mentions_result, list):
            if mentions_result:
                mentions_result = mentions_result[0]

        if mentions_result and hasattr(mentions_result, "has_next"):
            while mentions_result.has_next():  # type: ignore
                row = mentions_result.get_next()  # type: ignore
                memory_data, mention_rel = row[0], row[1]  # type: ignore

                mentions.append(
                    MemoryMention(
                        memory=MemorySummary(
                            id=memory_data["id"],  # type: ignore
                            title=memory_data.get("title", ""),  # type: ignore
                            content=memory_data.get("content", "")[:200],  # type: ignore
                        ),
                        confidence=mention_rel.get("confidence", 0.5)
                        if isinstance(mention_rel, dict)
                        else 0.5,  # type: ignore
                        mention_count=mention_rel.get("mention_count", 1)
                        if isinstance(mention_rel, dict)
                        else 1,  # type: ignore
                    )
                )

        response = EntityRelationshipsResponse(
            entity=EntitySummary(
                id=entity_data["id"],
                name=entity_data["name"],
                type=entity_data["entity_type"],
                description=entity_data.get("description", ""),
            ),
            relationships=EntityRelationshipsData(
                relates_to=relates_to_relationships,
                mentioned_in=mentions,
            ),
            metadata=EntityRelationshipsMetadata(
                total_relates_to=len(relates_to_relationships),
                total_mentions=len(mentions),
                traversal_depth=depth,
                limit=limit,
            ),
        )

        logger.debug(
            f"Retrieved relationships for entity {entity_id}",
            relates_to_count=len(relates_to_relationships),
            mentions_count=len(mentions),
            depth=depth,
        )

        return response

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Failed to get entity relationships", entity_id=entity_id, error=str(e)
        )
        raise HTTPException(
            status_code=500, detail=f"Failed to get entity relationships: {str(e)}"
        )
