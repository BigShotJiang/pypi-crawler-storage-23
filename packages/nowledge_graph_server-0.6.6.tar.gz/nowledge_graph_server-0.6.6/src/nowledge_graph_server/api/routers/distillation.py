import datetime
import json
from typing import List, Dict, Tuple, Optional, Any

import real_ladybug as kuzu
from fastapi import APIRouter, HTTPException
from structlog import get_logger

from nowledge_graph_server.api.dependencies import (
    get_memory_operations,
    get_thread_operations,
    get_kuzu_client,
)
from nowledge_graph_server.config import get_settings
from nowledge_graph_server.services.thread_parsing import thread_parsing_service
from nowledge_graph_server.services.local_llm import (
    get_local_llm_service,
)
from nowledge_graph_server.services.json_utils import clean_and_parse_json

from nowledge_graph_server.services.base_llm import (
    EntityExtractionResult,
    MemoryDistillationResult,
)
from nowledge_graph_server.utils.llm_availability import check_llm_availability

from nowledge_graph_server.models import (
    MemoryCreateResponse,
    EntityNode,
)
from nowledge_graph_server.api.models.requests import (
    DistillationRequest,
    ThreadParseRequest,
    TriageRequest,
)
from nowledge_graph_server.api.models.responses import (
    DistillationPreviewResponse,
    ThreadParseResponse,
)
from nowledge_graph_server.core.memory_operations import MemoryOperations
from nowledge_graph_server.services.local_llm import LocalLLMService
from nowledge_graph_server.utils.progress_logger import log_stage, log_progress, log_data_change

from .license import LicenseError, check_memory_creation_limit


logger = get_logger(__name__)

router = APIRouter()


async def _resolve_subset_selection(
    thread_id: str, selected_indices: Optional[List[int]]
) -> Tuple[List[int], List[str], Optional[str]]:
    """Resolve which messages to process and build subset content if needed.

    Returns (indices, message_ids, content_override_string or None)
    """
    try:
        # Fetch ordered messages to map indices -> ids and content
        thread_ops = await get_thread_operations()
        thread = await thread_ops.get_thread(thread_id)
        if not thread or not thread.messages:
            return [], [], None

        total = len(thread.messages)

        # If no indices provided, compute remaining (uncovered) messages for content,
        # but link to ALL messages for provenance to track full-thread coverage
        if not selected_indices:
            # Get covered message IDs for content filtering
            kuzu_client = await get_kuzu_client()
            covered_ids: set[str] = set()
            try:
                res = kuzu_client.conn.execute(  # type: ignore
                    """
                    MATCH (t:Thread {thread_id: $thread_id})-[:CONTAINS]->(m:Message)<-[:EXTRACTED_FROM]-(:Memory)
                    RETURN DISTINCT m.id
                    """,
                    {"thread_id": thread_id},
                )
                while res.has_next():  # type: ignore
                    row = res.get_next()  # type: ignore
                    covered_ids.add(row[0])  # type: ignore
            except Exception as e:
                logger.warning("Failed to fetch covered message ids", error=str(e))

            # Build content from remaining messages only
            safe_indices: List[int] = []
            parts: List[str] = []
            for idx, msg in enumerate(thread.messages):
                if msg.id in covered_ids:
                    continue
                safe_indices.append(idx)
                parts.append(f"{msg.role}: {msg.content}")

            # Link to ALL thread messages for full coverage tracking
            all_message_ids = [msg.id for msg in thread.messages]

            # If no remaining messages, return empty (already fully covered)
            if not safe_indices:
                return [], [], None

            content_override = "\n\n".join(parts)
            return safe_indices, all_message_ids, content_override

        # If indices provided, map them directly
        safe_indices2: List[int] = []
        message_ids2: List[str] = []
        parts2: List[str] = []
        for idx in selected_indices:
            if idx < 0 or idx >= total:
                continue
            msg = thread.messages[idx]
            safe_indices2.append(idx)
            message_ids2.append(msg.id)
            parts2.append(f"{msg.role}: {msg.content}")
        if not safe_indices2:
            return [], [], None
        content_override2 = "\n\n".join(parts2)
        return safe_indices2, message_ids2, content_override2
    except Exception as e:
        logger.warning("_resolve_subset_selection failed", error=str(e))
        return [], [], None


async def _link_memories_to_messages(
    memory_ops: MemoryOperations, memory_ids: List[str], message_ids: List[str]
) -> None:
    """Create EXTRACTED_FROM edges from each memory to each selected message."""
    try:
        if not memory_ops or not memory_ops.db or not memory_ids or not message_ids:  # type: ignore
            return
        conn: kuzu.Connection = memory_ops.db.conn  # type: ignore
        assert isinstance(conn, kuzu.Connection), "conn is not a Connection"
        now = datetime.datetime.now(datetime.timezone.utc)
        for mem_id in memory_ids:
            for msg_id in message_ids:
                try:
                    conn.execute(
                        """
                        MATCH (m:Memory {id: $memory_id}), (msg:Message {id: $message_id})
                        CREATE (m)-[:EXTRACTED_FROM {
                            extraction_confidence: 0.6,
                            created_at: $created_at,
                            properties: '{}'
                        }]->(msg)
                        """,
                        {"memory_id": mem_id, "message_id": msg_id, "created_at": now},
                    )
                except Exception as e:
                    logger.warning(
                        "Failed to link memory to message",
                        memory_id=mem_id,
                        message_id=msg_id,
                        error=str(e),
                    )
    except Exception as e:
        logger.warning("Link memories to messages failed", error=str(e))


async def _update_thread_coverage_metadata(
    thread_id: str, memory_ops: MemoryOperations
) -> Tuple[int, int, str]:
    """Compute coverage strictly from EXTRACTED_FROM and write status counts.

    Returns: (covered_count, total_count, status)
    """
    try:
        conn: kuzu.Connection = memory_ops.db.conn  # type: ignore
        assert isinstance(conn, kuzu.Connection), "conn is not a Connection"

        # Total messages
        total = 0
        res_total = conn.execute(
            """
            MATCH (t:Thread {thread_id: $thread_id})-[:CONTAINS]->(m:Message)
            RETURN COUNT(m)
            """,
            {"thread_id": thread_id},
        )
        if isinstance(res_total, kuzu.QueryResult) and res_total.has_next():
            total = int(res_total.get_next()[0])  # type: ignore

        # Covered messages
        covered = 0
        res_cov = conn.execute(
            """
            MATCH (t:Thread {thread_id: $thread_id})-[:CONTAINS]->(m:Message)<-[:EXTRACTED_FROM]-(:Memory)
            RETURN COUNT(DISTINCT m)
            """,
            {"thread_id": thread_id},
        )
        if isinstance(res_cov, kuzu.QueryResult) and res_cov.has_next():
            covered = int(res_cov.get_next()[0])  # type: ignore

        status = "none"
        if covered <= 0:
            status = "none"
        elif covered < total:
            status = "partial"
        else:
            status = "complete"

        # Update metadata fields
        meta_res = conn.execute(
            """
            MATCH (t:Thread {thread_id: $thread_id})
            RETURN t.metadata as metadata
            """,
            {"thread_id": thread_id},
        )
        metadata = {}
        if isinstance(meta_res, kuzu.QueryResult) and meta_res.has_next():
            raw = meta_res.get_next()[0]  # type: ignore
            metadata = json.loads(raw) if raw else {}  # type: ignore
        metadata.update(  # type: ignore
            {
                "distilled_status": status,
                "distilled_message_count": covered,
                "last_thread_message_count": total,
                "last_distilled_at": datetime.datetime.utcnow().isoformat(),  # type: ignore
            }
        )
        conn.execute(
            """
            MATCH (t:Thread {thread_id: $thread_id})
            SET t.metadata = $metadata
            """,
            {"thread_id": thread_id, "metadata": json.dumps(metadata)},
        )
        return covered, total, status
    except Exception as e:
        logger.warning(
            "Failed to update thread coverage metadata",
            thread_id=thread_id,
            error=str(e),
        )
        return 0, 0, "none"


TRIAGE_PROMPT_TEMPLATE = """Analyze this conversation and determine if it contains knowledge worth preserving as structured memories.

Worth preserving: decisions made, preferences stated, facts learned, plans formed, insights gained, contacts shared, procedures documented, important events.
NOT worth preserving: greetings, small talk, simple Q&A with no lasting value, debugging sessions with no conclusion, routine status updates.

Conversation:
{conversation}

Respond in EXACTLY this JSON format, nothing else:
{{"should_distill": true/false, "reason": "one sentence explanation"}}"""


@router.post("/memories/distill/triage")
async def triage_conversation(request: TriageRequest) -> Dict[str, Any]:
    """Lightweight triage: determine if a conversation has save-worthy content.

    Uses a short LLM prompt with low max_tokens to minimize cost.
    Call this before the expensive /memories/distill endpoint.
    """
    content = (request.thread_content or "").strip()
    if not content or len(content) < 50:
        return {"should_distill": False, "reason": "Content too short"}

    try:
        is_available, error_msg = check_llm_availability()
        if not is_available:
            # If no LLM available, default to should_distill=False
            logger.warning("Triage skipped: no LLM available", error=error_msg)
            return {"should_distill": False, "reason": "LLM not available"}

        settings = get_settings()
        llm_service: LocalLLMService = await get_local_llm_service(
            cache_dir=settings.llm_cache_dir,
            cache_only=settings.llm_cache_only,
        )

        # Truncate to keep triage cheap — first 3000 chars is enough to judge
        truncated = content[:3000]
        prompt = TRIAGE_PROMPT_TEMPLATE.format(conversation=truncated)

        response = await llm_service._generate_response(
            prompt, max_tokens=128, use_thinking=False
        )

        if not response or not response.strip():
            return {"should_distill": False, "reason": "LLM returned empty response"}

        # Parse the JSON response
        result = clean_and_parse_json(response)
        if result and isinstance(result, dict):
            should_distill = bool(result.get("should_distill", False))
            reason = str(result.get("reason", ""))[:200]
            return {"should_distill": should_distill, "reason": reason}

        # Fallback: check for YES/true in raw response
        lower = response.strip().lower()
        if "true" in lower or '"should_distill": true' in lower:
            return {"should_distill": True, "reason": "Triage indicated save-worthy content"}
        return {"should_distill": False, "reason": "Triage indicated no save-worthy content"}

    except Exception as e:
        logger.warning("Triage failed", error=str(e))
        # On failure, default to not distilling (conservative)
        return {"should_distill": False, "reason": f"Triage error: {str(e)[:100]}"}


@router.post("/memories/distill", response_model=MemoryCreateResponse)
async def distill_memories_from_thread(
    request: DistillationRequest,
) -> MemoryCreateResponse:
    """
    Create memories from thread content after distillation.

    This endpoint actually creates memories in the database based on the distillation type.
    For knowledge graph mode, it includes entity and relationship metadata.
    """
    try:
        # Log initialization
        log_stage(
            operation="thread_distillation",
            stage="initializing",
            message="Starting thread distillation",
            details={"thread_id": request.thread_id, "type": request.distillation_type},
        )
        log_progress(
            operation="thread_distillation",
            percentage=5,
            message="Initializing distillation process",
            details={},
        )

        # Validate LLM availability (especially important for knowledge_graph type)
        if request.distillation_type == "knowledge_graph":
            is_available, error_msg = check_llm_availability()
            if not is_available:
                raise HTTPException(
                    status_code=400,
                    detail=error_msg,
                )

        # Get settings and services
        settings = get_settings()
        llm_service: LocalLLMService = await get_local_llm_service(
            cache_dir=settings.llm_cache_dir,
            cache_only=settings.llm_cache_only,
        )
        memory_ops = await get_memory_operations()
        kuzu_client = await get_kuzu_client()

        log_progress(
            operation="thread_distillation",
            percentage=10,
            message="Analyzing thread messages",
            details={},
        )

        # Resolve subset selection (indices, message ids, and content)
        (
            _,
            message_ids_to_link,
            content_override,
        ) = await _resolve_subset_selection(
            request.thread_id, request.selected_message_indices
        )

        log_progress(
            operation="thread_distillation",
            percentage=15,
            message="Processing with AI (this may take a while)",
            details={},
        )

        # UNIFIED: Get results (cached or fresh) for both modes using subset content when provided
        entity_result, memory_result = await _get_distillation_results(
            llm_service=llm_service, request=request, content_override=content_override
        )

        log_progress(
            operation="thread_distillation",
            percentage=60,
            message="AI processing completed, creating memories",
            details={
                "memories_count": len(memory_result.memories),
                "entities_count": len(entity_result.entities),
            },
        )

        # Check license limit before creating memories
        memories_to_create = len(memory_result.memories)

        check_memory_creation_limit(kuzu_client, memories_to_create)

        logger.info("Entities extracted", count=len(entity_result.entities))
        logger.info("Memories distilled", count=len(memory_result.memories))

        if not memory_result.memories:
            raise ValueError("No memories could be distilled from the content")

        log_progress(
            operation="thread_distillation",
            percentage=70,
            message="Saving memories to knowledge graph",
            details={},
        )

        # UNIFIED: Create memories in database
        created_memories = await _create_memories_from_results(
            memory_result=memory_result,
            entity_result=entity_result,
            memory_ops=memory_ops,
            request=request,
        )

        if not created_memories:
            raise ValueError("Failed to create memories from distilled content")

        main_memory_response = created_memories[0]

        # UNIFIED: Store entities and relationships (only for knowledge_graph mode)
        if request.distillation_type == "knowledge_graph":
            log_progress(
                operation="thread_distillation",
                percentage=80,
                message="Building knowledge graph connections",
                details={},
            )

            (
                _,
                relationships_count,
            ) = await store_entities_and_relationships(
                entity_result=entity_result,
                created_memories=created_memories,
                memory_ops=memory_ops,
            )

            # Convert entities for response serialization
            entity_nodes = _convert_entities_for_response(entity_result.entities)
            main_memory_response.extracted_entities = entity_nodes
            main_memory_response.created_relationships = relationships_count

        log_progress(
            operation="thread_distillation",
            percentage=90,
            message="Finalizing distillation",
            details={},
        )

        # UNIFIED: Create thread-memory relationship and update metadata
        await _finalize_distillation(
            request=request, created_memories=created_memories, memory_ops=memory_ops
        )

        # Link created memories to specific messages (provenance)
        if message_ids_to_link:
            await _link_memories_to_messages(
                memory_ops=memory_ops,
                memory_ids=[m.memory.id for m in created_memories],
                message_ids=message_ids_to_link,
            )

        # Update coverage metadata on thread
        await _update_thread_coverage_metadata(request.thread_id, memory_ops)

        log_stage(
            operation="thread_distillation",
            stage="completed",
            message="Thread distillation completed successfully",
            details={
                "memories_created": len(created_memories),
                "entities_extracted": len(entity_result.entities)
                if request.distillation_type == "knowledge_graph"
                else 0,
            },
        )
        log_progress(
            operation="thread_distillation",
            percentage=100,
            message="Distillation complete",
            details={},
        )

        return main_memory_response

    except LicenseError:
        # Re-raise license errors as-is
        log_stage(
            operation="thread_distillation",
            stage="completed",
            message="Distillation failed: license limit exceeded",
            details={"error": "license_limit"},
        )
        raise
    except Exception as e:
        logger.error(
            "Memory creation from distillation failed", error=str(e), exc_info=True
        )
        log_stage(
            operation="thread_distillation",
            stage="completed",
            message=f"Distillation failed: {str(e)}",
            details={"error": str(e)},
        )
        raise HTTPException(
            status_code=500,
            detail=f"Failed to create memories from distillation: {str(e)}",
        )


async def _get_distillation_results(
    llm_service: LocalLLMService,
    request: DistillationRequest,
    content_override: Optional[str] = None,
) -> Tuple[EntityExtractionResult, MemoryDistillationResult]:
    """Get distillation results from cache or generate fresh ones."""
    preferred_language = request.preferred_language or None

    # Check if we have cached results from preview
    if request.cache_key:
        logger.info("Using cached results from preview", cache_key=request.cache_key)

        if request.distillation_type == "knowledge_graph":
            entity_result = await llm_service.extract_entities_cached(
                cache_key=request.cache_key
            )
        else:
            entity_result = EntityExtractionResult(
                entities=[], relationships=[], confidence=0.0
            )

        memory_result = await llm_service.distill_memories_cached(
            content_override or request.thread_content,
            request.thread_title or "",
            cache_key=request.cache_key,
            extraction_level=request.extraction_level,
            preferred_language=preferred_language,
        )

        # Clear the cache entry after use
        llm_service.clear_cache(request.cache_key)

    else:
        logger.info(
            "No cache key provided, generating fresh results",
            extraction_level=request.extraction_level,
        )
        # Use the unified preview logic for both modes
        (
            cache_key,
            entity_result,
            memory_result,
        ) = await llm_service.generate_preview_with_cache(
            thread_content=content_override or request.thread_content,
            thread_title=request.thread_title or "",
            distillation_type=request.distillation_type,
            extraction_level=request.extraction_level,
            preferred_language=preferred_language,
        )
        # Clear the cache immediately since we're using the results now
        llm_service.clear_cache(cache_key)

    return entity_result, memory_result


async def _get_thread_source(
    thread_id: str, memory_ops: MemoryOperations
) -> Optional[str]:
    """Get source from thread data."""
    try:
        if memory_ops.db.conn is None:
            return None
        thread_query = """
            MATCH (t:Thread {thread_id: $thread_id})
            RETURN t.source as source
        """
        result: kuzu.QueryResult = memory_ops.db.conn.execute(
            thread_query, {"thread_id": thread_id}
        )  # type: ignore
        if isinstance(result, kuzu.QueryResult) and result.has_next():
            row = result.get_next()
            return row[0]  # type: ignore
    except Exception as e:
        logger.warning("Failed to get thread source", thread_id=thread_id, error=str(e))
    return None


async def _create_memories_from_results(
    memory_result: MemoryDistillationResult,
    entity_result: EntityExtractionResult,
    memory_ops: MemoryOperations,
    request: DistillationRequest,
) -> List[MemoryCreateResponse]:
    """Create memory records in database from distillation results."""
    created_memories: List[MemoryCreateResponse] = []

    for idx, memory_data_item in enumerate(memory_result.memories):
        logger.info(
            f"Creating memory {idx + 1}/{len(memory_result.memories)}",
            memory_title=memory_data_item.get("title", "Untitled"),
        )

        # Get source from thread data
        thread_source = await _get_thread_source(request.thread_id, memory_ops)

        # Base memory data
        memory_data: Dict[str, Any] = {
            "content": memory_data_item.get("content", request.thread_content[:500]),
            "title": memory_data_item.get("title", f"Extracted Memory {idx + 1}"),
            "source_id": request.thread_id,
            "source": thread_source
            or "thread_import",  # Use thread's source or default
            "importance": memory_data_item.get("importance", 0.7),
            "confidence": memory_data_item.get("confidence", 0.6),
            "labels": [],
            "extract_entities": False,  # We handle entities manually
            "metadata": {
                "distillation_type": request.distillation_type,
                "source_thread_title": request.thread_title,
                "source_thread_id": request.thread_id,
                "distilled_at": datetime.datetime.utcnow().isoformat(),  # type: ignore
                "memory_index": idx + 1,
                "total_memories": len(memory_result.memories),
                "insights_count": len(memory_result.insights),
            },
        }

        # Extract unit_type from LLM classification (v0.6)
        unit_type = memory_data_item.get("unit_type", "fact")
        valid_unit_types = {"fact", "preference", "decision", "plan", "procedure", "learning", "context", "event"}
        if unit_type not in valid_unit_types:
            unit_type = "fact"
        memory_data["unit_type"] = unit_type

        # Extract and normalize temporal information (remote LLM only)
        # Note: Local LLM won't provide this, so it's Optional and won't break local flow
        temporal_data = memory_data_item.get("temporal")
        if temporal_data:
            from nowledge_graph_server.services.temporal_utils import (
                normalize_temporal_date,
                should_store_temporal,
            )

            temporal_confidence = temporal_data.get("confidence")
            if should_store_temporal(temporal_confidence):
                # Normalize dates
                event_start_raw = temporal_data.get("start")
                event_end_raw = temporal_data.get("end")

                event_start = None
                event_end = None
                temporal_precision = None

                if event_start_raw:
                    try:
                        event_start, temporal_precision = normalize_temporal_date(
                            event_start_raw
                        )
                        logger.info(
                            "Normalized event_start",
                            raw=event_start_raw,
                            normalized=event_start,
                            precision=temporal_precision,
                        )
                    except ValueError as e:
                        logger.warning(
                            "Failed to normalize event_start",
                            raw=event_start_raw,
                            error=str(e),
                        )

                if event_end_raw:
                    try:
                        event_end, _ = normalize_temporal_date(event_end_raw)
                        logger.info(
                            "Normalized event_end",
                            raw=event_end_raw,
                            normalized=event_end,
                        )
                    except ValueError as e:
                        logger.warning(
                            "Failed to normalize event_end",
                            raw=event_end_raw,
                            error=str(e),
                        )

                # Add temporal fields to memory_data
                memory_data["temporal_type"] = temporal_data.get("type", "unknown")
                memory_data["event_start"] = event_start
                memory_data["event_end"] = event_end
                memory_data["temporal_precision"] = temporal_precision
                memory_data["temporal_confidence"] = temporal_confidence
                memory_data["temporal_context"] = temporal_data.get(
                    "context", "timeless"
                )

                logger.info(
                    "Added temporal fields to memory",
                    temporal_type=memory_data["temporal_type"],
                    event_start=event_start,
                    event_end=event_end,
                    precision=temporal_precision,
                    confidence=temporal_confidence,
                )

        # Add KG-specific metadata
        if request.distillation_type == "knowledge_graph":
            memory_data["metadata"].update(
                {
                    "kg_extracted": True,
                    "kg_extracted_at": datetime.datetime.utcnow().isoformat(),  # type: ignore
                    "extracted_entities": entity_result.entities,
                    "extracted_relationships": entity_result.relationships,
                    "entities_count": len(entity_result.entities),
                    "relationships_count": len(entity_result.relationships),
                    "kg_extraction_confidence": entity_result.confidence,
                    "extraction_method": "thread_distillation_llm",
                }
            )

        created_memory: Optional[MemoryCreateResponse] = await memory_ops.create_memory(
            **memory_data
        )
        if created_memory:
            created_memories.append(created_memory)
            logger.info(
                f"Memory {idx + 1} created with ID", memory_id=created_memory.memory.id
            )
            # Notify UI of data change (distillation creates memories)
            log_data_change(
                change_type="memory_created",
                entity_type="memory",
                entity_id=created_memory.memory.id,
                details={"source": "distillation"},
            )
        else:
            logger.error(f"Failed to create memory {idx + 1}")

    return created_memories


async def _verify_mentions_relationships(
    memory_ops: MemoryOperations,
    created_memories: List[MemoryCreateResponse],
    stored_entities: List[EntityNode],
):
    """Diagnostic function to verify MENTIONS relationships exist in database."""
    try:
        logger.info("🔍 Running MENTIONS relationship diagnostic...")

        # Check total MENTIONS relationships in database
        total_mentions_query = """
            MATCH ()-[r:MENTIONS]->()
            RETURN COUNT(r) as total_mentions
        """

        result: kuzu.QueryResult = memory_ops.db.conn.execute(total_mentions_query)  # type: ignore
        if isinstance(result, list) and result:
            result = result[0]  # type: ignore

        total_mentions = 0
        if isinstance(result, kuzu.QueryResult) and result.has_next():
            row = result.get_next()
            total_mentions = row[0]  # type: ignore

        logger.info(f"🔍 Total MENTIONS relationships in database: {total_mentions}")

        # Check MENTIONS for each created memory
        for i, memory_response in enumerate(created_memories):
            memory_id = memory_response.memory.id
            memory_mentions_query = """
                MATCH (m:Memory {id: $memory_id})-[r:MENTIONS]->(e:Entity)
                RETURN COUNT(r) as mentions_count, COLLECT(e.name) as entity_names
            """

            result: kuzu.QueryResult = memory_ops.db.conn.execute(  # type: ignore
                memory_mentions_query, {"memory_id": memory_id}
            )
            if isinstance(result, list) and result:
                result = result[0]  # type: ignore

            if isinstance(result, kuzu.QueryResult) and result.has_next():
                row = result.get_next()
                mentions_count = row[0]  # type: ignore
                entity_names = row[1]  # type: ignore
                logger.info(
                    f"🔍 Memory[{i}] {memory_id}: {mentions_count} MENTIONS -> entities: {entity_names}"
                )
            else:
                logger.warning(
                    f"🔍 Memory[{i}] {memory_id}: No MENTIONS relationships found!"
                )

    except Exception as e:
        logger.error("Diagnostic query failed", error=str(e))


async def store_entities_and_relationships(
    entity_result: EntityExtractionResult,
    created_memories: List[MemoryCreateResponse],
    memory_ops: MemoryOperations,
) -> Tuple[List[EntityNode], int]:
    """Store entities and relationships in database (KG mode only)."""
    stored_entities: List[EntityNode] = []
    mentions_created = 0

    logger.info(
        f"🔗 Starting entity storage for {len(entity_result.entities)} entities and {len(created_memories)} memories"
    )

    # Store each entity and link to correct source memory
    for entity_dict in entity_result.entities:
        try:
            entity_confidence = entity_dict.get("confidence", 0.5)
            source_memory_index = entity_dict.get("source_memory_index", 0)
            entity_name = entity_dict.get("name", "")

            logger.debug(
                f"🔗 Processing entity: {entity_name} (source_memory_index: {source_memory_index})"
            )

            # Extract and normalize entity temporal information (remote LLM only)
            entity_temporal = entity_dict.get("entity_temporal")
            entity_created = None
            entity_ended = None
            entity_temporal_precision = None
            entity_temporal_confidence = None
            entity_temporal_context = None

            if entity_temporal:
                from nowledge_graph_server.services.temporal_utils import (
                    normalize_temporal_date,
                    should_store_temporal,
                )

                entity_temporal_confidence = entity_temporal.get("temporal_confidence")
                if should_store_temporal(entity_temporal_confidence):
                    # Normalize entity lifecycle dates
                    created_raw = entity_temporal.get("created")
                    ended_raw = entity_temporal.get("ended")

                    if created_raw:
                        try:
                            entity_created, entity_temporal_precision = (
                                normalize_temporal_date(created_raw)
                            )
                            logger.info(
                                "Normalized entity_created",
                                entity=entity_name,
                                raw=created_raw,
                                normalized=entity_created,
                                precision=entity_temporal_precision,
                            )
                        except ValueError as e:
                            logger.warning(
                                "Failed to normalize entity_created",
                                entity=entity_name,
                                raw=created_raw,
                                error=str(e),
                            )

                    if ended_raw:
                        try:
                            entity_ended, _ = normalize_temporal_date(ended_raw)
                            logger.info(
                                "Normalized entity_ended",
                                entity=entity_name,
                                raw=ended_raw,
                                normalized=entity_ended,
                            )
                        except ValueError as e:
                            logger.warning(
                                "Failed to normalize entity_ended",
                                entity=entity_name,
                                raw=ended_raw,
                                error=str(e),
                            )

                    entity_temporal_context = entity_temporal.get(
                        "temporal_context", "timeless"
                    )

            entity_node = EntityNode(  # type: ignore[call-arg]
                name=entity_name,
                entity_type=entity_dict.get("type", "CONCEPT"),
                description=entity_dict.get("description", ""),
                confidence=entity_confidence,
                aliases=entity_dict.get("aliases", []),
                # Bi-temporal fields (added 2025-11-20)
                entity_created=entity_created,
                entity_ended=entity_ended,
                temporal_precision=entity_temporal_precision,
                temporal_confidence=entity_temporal_confidence,
                temporal_context=entity_temporal_context,
            )

            stored_entity: EntityNode = (
                await memory_ops.db.entity_repo.create_or_find_entity(  # type: ignore
                    entity_node
                )
            )
            stored_entities.append(stored_entity)  # type: ignore
            logger.debug(
                f"🔗 Stored entity: {stored_entity.name} with ID: {stored_entity.id}"  # type: ignore
            )

            # Sync entity to search index (non-blocking, best-effort)
            try:
                from ...services.search_index import sync_entity_to_index
                await sync_entity_to_index(stored_entity)
            except Exception as sync_error:
                logger.debug(
                    "Entity search index sync skipped",
                    entity_id=stored_entity.id,  # type: ignore
                    error=str(sync_error),
                )

            # Create MENTIONS relationship only to source memory
            if source_memory_index < len(created_memories):
                source_memory: MemoryCreateResponse = created_memories[
                    source_memory_index
                ]  # type: ignore
                logger.debug(
                    f"🔗 Creating MENTIONS: Memory[{source_memory_index}] {source_memory.memory.id} -> Entity {stored_entity.id} ({stored_entity.name})"  # type: ignore
                )

                try:
                    await memory_ops.db.entity_repo.create_entity_mention(  # type: ignore
                        memory_id=source_memory.memory.id,  # type: ignore
                        entity_id=stored_entity.id,  # type: ignore
                        confidence=entity_confidence,
                    )
                    mentions_created += 1
                    logger.info(
                        f"✅ MENTIONS created: Memory {source_memory.memory.id} -> Entity {stored_entity.name}"  # type: ignore
                    )
                except Exception as mention_error:
                    logger.error(
                        f"❌ Failed to create MENTIONS: Memory {source_memory.memory.id} -> Entity {stored_entity.name}",  # type: ignore
                        error=str(mention_error),
                    )
                    raise mention_error

            else:
                # Fallback to first memory if index invalid
                logger.warning(
                    f"🔗 Invalid source_memory_index {source_memory_index}, using fallback to memory 0"
                )
                try:
                    await memory_ops.db.entity_repo.create_entity_mention(  # type: ignore
                        memory_id=created_memories[0].memory.id,  # type: ignore
                        entity_id=stored_entity.id,  # type: ignore
                        confidence=entity_confidence,
                    )
                    mentions_created += 1
                    logger.info(
                        f"✅ MENTIONS created (fallback): Memory {created_memories[0].memory.id} -> Entity {stored_entity.name}"  # type: ignore
                    )
                except Exception as mention_error:
                    logger.error(
                        f"❌ Failed to create MENTIONS (fallback): Memory {created_memories[0].memory.id} -> Entity {stored_entity.name}",  # type: ignore
                        error=str(mention_error),  # type: ignore
                    )
                    raise mention_error

        except Exception as e:
            logger.error(
                "Failed to store entity", entity=entity_dict.get("name"), error=str(e)
            )

    logger.info(f"🔗 MENTIONS relationships created: {mentions_created} total")
    logger.info(
        f"🔗 Entity storage complete: {len(stored_entities)} entities stored out of {len(entity_result.entities)} extracted"
    )

    # Diagnostic: Check if MENTIONS relationships actually exist in the database
    await _verify_mentions_relationships(memory_ops, created_memories, stored_entities)

    # Create entity-entity relationships
    entity_relationships_count = 0
    
    # Build name-to-id mapping with case-insensitive and alias fallbacks
    entity_name_to_id = {entity.name: entity.id for entity in stored_entities}
    # Also build a lowercase mapping for fallback matching
    entity_name_lower_to_id = {entity.name.lower(): entity.id for entity in stored_entities}
    entity_name_lower_to_name = {entity.name.lower(): entity.name for entity in stored_entities}
    
    # Build alias-to-id mapping for cross-language/alternative name matching
    # This handles cases like "实时风控平台" -> "Real-time risk control platform"
    entity_alias_to_id: dict[str, str] = {}
    entity_alias_to_name: dict[str, str] = {}
    for entity in stored_entities:
        if entity.aliases:
            for alias in entity.aliases:
                alias_lower = alias.lower()
                if alias_lower not in entity_alias_to_id:
                    entity_alias_to_id[alias_lower] = entity.id
                    entity_alias_to_name[alias_lower] = entity.name

    # Diagnostic: Log relationships to be created
    logger.info(
        "Creating entity-entity RELATES_TO relationships",
        relationships_to_create=len(entity_result.relationships),
        stored_entity_count=len(stored_entities),
        stored_entity_names=list(entity_name_to_id.keys())[:20],  # Limit log size
    )
    
    # Log all relationship source/target for debugging
    for idx, rel in enumerate(entity_result.relationships[:10]):  # First 10
        logger.info(
            f"📊 Relationship {idx}: source='{rel.get('source')}' -> target='{rel.get('target')}' ({rel.get('relation', 'RELATES_TO')})"
        )

    if not entity_result.relationships:
        logger.warning(
            "No relationships extracted from LLM. "
            "The LLM may not have found meaningful entity connections, "
            "or the extraction prompt may need adjustment."
        )
    else:
        # Log first few relationship source/target names for debugging
        sample_rels = entity_result.relationships[:5]
        logger.debug(
            "Sample relationship source/target names",
            samples=[(r.get("source"), r.get("target")) for r in sample_rels],
        )

    for rel_dict in entity_result.relationships:
        try:
            source_name = rel_dict.get("source", "")
            target_name = rel_dict.get("target", "")
            
            # First try exact match, then fall back to case-insensitive match
            source_id = entity_name_to_id.get(source_name)
            target_id = entity_name_to_id.get(target_name)
            
            # Case-insensitive fallback
            if not source_id and source_name.lower() in entity_name_lower_to_id:
                source_id = entity_name_lower_to_id[source_name.lower()]
                matched_name = entity_name_lower_to_name[source_name.lower()]
                logger.debug(
                    "Used case-insensitive match for source",
                    original=source_name,
                    matched=matched_name,
                )
            
            if not target_id and target_name.lower() in entity_name_lower_to_id:
                target_id = entity_name_lower_to_id[target_name.lower()]
                matched_name = entity_name_lower_to_name[target_name.lower()]
                logger.debug(
                    "Used case-insensitive match for target",
                    original=target_name,
                    matched=matched_name,
                )
            
            # Alias fallback (handles cross-language names like 实时风控平台 -> Real-time risk control platform)
            if not source_id and source_name.lower() in entity_alias_to_id:
                source_id = entity_alias_to_id[source_name.lower()]
                matched_name = entity_alias_to_name[source_name.lower()]
                logger.debug(
                    "Used alias match for source",
                    original=source_name,
                    matched=matched_name,
                )
            
            if not target_id and target_name.lower() in entity_alias_to_id:
                target_id = entity_alias_to_id[target_name.lower()]
                matched_name = entity_alias_to_name[target_name.lower()]
                logger.debug(
                    "Used alias match for target",
                    original=target_name,
                    matched=matched_name,
                )

            # Debug: Log lookup results
            logger.debug(
                "Relationship entity lookup",
                source_name=source_name,
                target_name=target_name,
                source_id=source_id,
                target_id=target_id,
                source_found=bool(source_id),
                target_found=bool(target_id),
            )

            if source_id and target_id:
                # Extract and normalize relationship temporal information (remote LLM only)
                rel_temporal = rel_dict.get("rel_temporal")
                rel_temporal_type = None
                rel_start = None
                rel_end = None
                rel_temporal_precision = None
                is_ongoing = True  # Default to ongoing
                rel_temporal_confidence = None

                if rel_temporal:
                    from nowledge_graph_server.services.temporal_utils import (
                        normalize_temporal_date,
                        should_store_temporal,
                    )

                    rel_temporal_confidence = rel_temporal.get("temporal_confidence")
                    if should_store_temporal(rel_temporal_confidence):
                        # Normalize relationship dates
                        rel_start_raw = rel_temporal.get("rel_start")
                        rel_end_raw = rel_temporal.get("rel_end")

                        if rel_start_raw:
                            try:
                                rel_start, rel_temporal_precision = (
                                    normalize_temporal_date(rel_start_raw)
                                )
                                logger.info(
                                    "Normalized rel_start",
                                    source=source_name,
                                    target=target_name,
                                    raw=rel_start_raw,
                                    normalized=rel_start,
                                    precision=rel_temporal_precision,
                                )
                            except ValueError as e:
                                logger.warning(
                                    "Failed to normalize rel_start",
                                    source=source_name,
                                    target=target_name,
                                    raw=rel_start_raw,
                                    error=str(e),
                                )

                        if rel_end_raw:
                            try:
                                rel_end, _ = normalize_temporal_date(rel_end_raw)
                                logger.info(
                                    "Normalized rel_end",
                                    source=source_name,
                                    target=target_name,
                                    raw=rel_end_raw,
                                    normalized=rel_end,
                                )
                            except ValueError as e:
                                logger.warning(
                                    "Failed to normalize rel_end",
                                    source=source_name,
                                    target=target_name,
                                    raw=rel_end_raw,
                                    error=str(e),
                                )

                        rel_temporal_type = rel_temporal.get("temporal_type", "unknown")
                        is_ongoing = rel_temporal.get("is_ongoing", True)

                await memory_ops.db.relationship_mgr.create_entity_relationship(  # type: ignore[attr-defined]
                    source_entity_id=source_id,
                    target_entity_id=target_id,
                    relation_type=rel_dict.get("relation", "RELATES_TO"),
                    confidence=rel_dict.get("confidence", 0.5),
                    context=rel_dict.get("context", ""),
                    reasoning=rel_dict.get("reasoning", ""),
                    source_memory_id=created_memories[0].memory.id,
                    temporal_info=rel_dict.get(
                        "temporal_info", ""
                    ),  # Keep legacy field for backwards compatibility
                    conditions=rel_dict.get("conditions", ""),
                    # Bi-temporal fields (added 2025-11-20)
                    temporal_type=rel_temporal_type,
                    rel_start=rel_start,
                    rel_end=rel_end,
                    temporal_precision=rel_temporal_precision,
                    is_ongoing=is_ongoing,
                    temporal_confidence=rel_temporal_confidence,
                )
                entity_relationships_count += 1
                logger.info(
                    f"✅ Created RELATES_TO edge: {source_name} -> {target_name} ({rel_dict.get('relation', 'RELATES_TO')})"
                )
                # Log temporal info if present
                if rel_temporal:
                    logger.info(
                        "Created temporal relationship",
                        source=source_name,
                        target=target_name,
                        temporal_type=rel_temporal_type,
                        rel_start=rel_start,
                        rel_end=rel_end,
                        is_ongoing=is_ongoing,
                        confidence=rel_temporal_confidence,
                    )
            else:
                logger.warning(
                    "Could not create RELATES_TO - entity not found in stored entities",
                    source_name=source_name,
                    target_name=target_name,
                    source_found=bool(source_id),
                    target_found=bool(target_id),
                    available_entities=list(entity_name_to_id.keys())[:10],  # First 10 for debug
                )
        except Exception as e:
            logger.warning(
                "Failed to create entity relationship",
                source=source_name,
                target=target_name,
                error=str(e),
            )

    logger.info(
        "Created entity-entity relationships",
        count=entity_relationships_count,
        total_attempted=len(entity_result.relationships),
    )
    
    # Final verification: Check if RELATES_TO edges actually exist in database
    if entity_relationships_count > 0:
        try:
            assert memory_ops.db.conn is not None
            verify_result = memory_ops.db.conn.execute(
                "MATCH (e1:Entity)-[r:RELATES_TO]->(e2:Entity) RETURN COUNT(r)"
            )
            if verify_result.has_next():  # type: ignore
                actual_count = int(verify_result.get_next()[0])  # type: ignore
                logger.info(
                    f"🔗 VERIFICATION: Total RELATES_TO edges in database: {actual_count}"
                )
                if actual_count == 0:
                    logger.error(
                        "CRITICAL: RELATES_TO edges were supposedly created but database shows 0! "
                        "This indicates a transaction or write issue."
                    )
        except Exception as verify_error:
            logger.debug("Failed to verify RELATES_TO edges", error=str(verify_error))
    
    return stored_entities, entity_relationships_count


def _convert_entities_for_response(
    entity_dicts: List[Dict[str, Any]],
) -> List[EntityNode]:
    """Convert entity dictionaries to EntityNode objects for response serialization."""
    entity_nodes: List[EntityNode] = []
    for entity_dict in entity_dicts:
        try:
            entity_node = EntityNode(  # type: ignore[call-arg]
                name=entity_dict.get("name", ""),
                entity_type=entity_dict.get("type", "CONCEPT"),
                description=entity_dict.get("description", ""),
                confidence=entity_dict.get("confidence", 0.5),
                aliases=entity_dict.get("aliases", []),
            )
            entity_nodes.append(entity_node)
        except Exception as e:
            logger.warning(
                "Failed to convert entity to EntityNode",
                entity=entity_dict,
                error=str(e),
            )
    return entity_nodes


async def _finalize_distillation(
    request: DistillationRequest,
    created_memories: List[MemoryCreateResponse],
    memory_ops: MemoryOperations,
) -> None:
    """Create thread-memory relationship and update thread metadata."""

    # Create COMPACTS_TO relationship for ALL memories (not just the first one!)
    method_name = f"{request.distillation_type}_distillation"
    relationships_created = 0

    for memory_response in created_memories:
        try:
            await memory_ops.db.create_thread_memory_relationship(  # type: ignore[attr-defined]
                thread_id=request.thread_id,
                memory_id=memory_response.memory.id,  # type: ignore
                compaction_method=method_name,
            )
            relationships_created += 1
            logger.info(
                "Created COMPACTS_TO relationship",
                thread_id=request.thread_id,
                memory_id=memory_response.memory.id,
                memory_index=relationships_created,
            )
        except Exception as e:
            logger.error(
                "Failed to create COMPACTS_TO relationship",
                memory_id=memory_response.memory.id,
                error=str(e),
            )

    logger.info(
        "COMPACTS_TO relationships created",
        thread_id=request.thread_id,
        total_relationships=relationships_created,
        total_memories=len(created_memories),
    )

    # Update coverage-derived metadata and mark distilled only if complete
    try:
        _, _, status = await _update_thread_coverage_metadata(
            request.thread_id, memory_ops
        )
        kuzu_client = await get_kuzu_client()
        # Merge in distillation type and optional distilled flag
        meta_res = kuzu_client.conn.execute(  # type: ignore
            """
            MATCH (t:Thread {thread_id: $thread_id})
            RETURN t.metadata as metadata
            """,
            {"thread_id": request.thread_id},
        )
        metadata = {}
        if isinstance(meta_res, kuzu.QueryResult) and meta_res.has_next():
            raw = meta_res.get_next()[0]  # type: ignore
            metadata: Dict[str, Any] = json.loads(raw) if raw else {}  # type: ignore
        metadata.update(
            {
                "distillation_type": request.distillation_type,
            }
        )
        # Backward-compat distilled flag only when complete
        if status == "complete":
            metadata["distilled"] = True
        kuzu_client.conn.execute(  # type: ignore
            """
            MATCH (t:Thread {thread_id: $thread_id})
            SET t.metadata = $metadata
            """,
            {"thread_id": request.thread_id, "metadata": json.dumps(metadata)},
        )
    except Exception as e:
        logger.warning("Failed to finalize coverage metadata", error=str(e))


@router.post("/memories/distill/preview", response_model=DistillationPreviewResponse)
async def preview_distillation(
    request: DistillationRequest,
) -> DistillationPreviewResponse:
    """
    Preview distillation results without creating memories in the database.

    This endpoint processes content and returns distilled data for user review
    before they decide to save the memories. Returns a cache_key that can be used
    to reuse these results in the actual distillation call.

    Supports two modes:
    1. Simple LLM summarization - just extract key memories
    2. Knowledge graph extraction - extract entities, relationships, and memories
    """
    import time

    start_time = time.time()

    logger.info(
        "=== DISTILLATION PREVIEW START ===",
        distillation_type=request.distillation_type,
        thread_id=request.thread_id,
        has_content=bool(request.thread_content),
    )

    try:
        # Validate LLM availability (especially important for knowledge_graph type)
        if request.distillation_type == "knowledge_graph":
            is_available, error_msg = check_llm_availability()
            if not is_available:
                return DistillationPreviewResponse(
                    success=False,
                    cache_key="",
                    distillation_type=request.distillation_type,
                    processing_time=0.0,
                    memories=[],
                    entities=[],
                    relationships=[],
                    insights=[],
                    summary="",
                    error=error_msg,
                )

        # Get local LLM service
        settings = get_settings()
        llm_service = await get_local_llm_service(
            cache_dir=settings.llm_cache_dir,
            cache_only=settings.llm_cache_only,
        )

        # Resolve subset selection to build content from selected/remaining messages
        _, _, content_override = await _resolve_subset_selection(
            request.thread_id, request.selected_message_indices
        )

        preferred_language = request.preferred_language or None

        if request.distillation_type == "knowledge_graph":
            # Use cached generation method for knowledge graph mode
            logger.info(
                "Using knowledge graph extraction mode with caching",
                extraction_level=request.extraction_level,
            )

            (
                cache_key,
                entity_result,
                memory_result,
            ) = await llm_service.generate_preview_with_cache(
                thread_content=content_override or request.thread_content,
                thread_title=request.thread_title or "",
                distillation_type=request.distillation_type,
                extraction_level=request.extraction_level,
                preferred_language=preferred_language,
            )

            processing_time = time.time() - start_time

            return DistillationPreviewResponse(
                success=True,
                cache_key=cache_key,
                distillation_type=request.distillation_type,
                processing_time=processing_time,
                memories=memory_result.memories,
                entities=entity_result.entities,
                relationships=entity_result.relationships,
                insights=memory_result.insights,
                summary=memory_result.summary,
                error=None,
            )

        else:
            # Simple LLM mode - only distill memories (no entities/relationships)
            logger.info(
                "Using simple LLM distillation mode with caching",
                extraction_level=request.extraction_level,
            )

            cache_key, _, memory_result = await llm_service.generate_preview_with_cache(
                thread_content=content_override or request.thread_content,
                thread_title=request.thread_title or "",
                distillation_type=request.distillation_type,
                extraction_level=request.extraction_level,
                preferred_language=preferred_language,
            )

            processing_time = time.time() - start_time

            return DistillationPreviewResponse(
                success=True,
                cache_key=cache_key,
                distillation_type=request.distillation_type,
                processing_time=processing_time,
                memories=memory_result.memories,
                entities=[],  # No entities in simple mode
                relationships=[],  # No relationships in simple mode
                insights=memory_result.insights,
                summary=memory_result.summary,
                error=None,
            )

    except Exception as e:
        processing_time = time.time() - start_time
        logger.error("Distillation preview failed", error=str(e))

        return DistillationPreviewResponse(
            success=False,
            cache_key="",
            distillation_type=request.distillation_type,
            processing_time=processing_time,
            memories=[],
            entities=[],
            relationships=[],
            insights=[],
            summary="",
            error=str(e),
        )


@router.post("/threads/parse", response_model=ThreadParseResponse)
async def parse_thread_content(request: ThreadParseRequest) -> ThreadParseResponse:
    """Parse thread content from various formats."""
    try:
        # Use the thread parsing service
        parsed_thread = thread_parsing_service.parse_thread(
            request.file_content, request.file_name
        )

        # Convert to dictionary format for response
        thread_dict = {
            "title": parsed_thread.title,
            "source": parsed_thread.source,
            "export_info": parsed_thread.export_info,
            "messages": [
                {
                    "speaker": msg.speaker,
                    "content": msg.content,
                    "timestamp": msg.timestamp,
                }
                for msg in parsed_thread.messages
            ],
            "message_count": parsed_thread.message_count,
            "participants": parsed_thread.participants,
        }

        return ThreadParseResponse(
            success=True,
            parsed_thread=thread_dict,
            format_detected=thread_parsing_service.detect_format(
                request.file_content, request.file_name
            ),
            error=None,
        )

    except ValueError as e:
        logger.error(f"Thread parsing failed: {e}")
        return ThreadParseResponse(
            success=False, parsed_thread=None, format_detected=None, error=str(e)
        )
    except Exception as e:
        logger.error(f"Unexpected error in thread parsing: {e}")
        return ThreadParseResponse(
            success=False,
            parsed_thread=None,
            format_detected=None,
            error=f"Parsing failed: {str(e)}",
        )
