from fastapi import APIRouter, HTTPException
from nowledge_graph_server.api.models.responses import HealthResponse
from nowledge_graph_server.config import get_settings
from nowledge_graph_server.api.dependencies import (
    get_kuzu_client_direct,
    embedding_service,
    entity_extraction_service,
)
from nowledge_graph_server import __version__

import datetime
import structlog


logger = structlog.get_logger(__name__)

router = APIRouter()


@router.post("/health/checkpoint")
async def force_checkpoint():
    """Force a database checkpoint to flush WAL to disk.

    Called by the desktop app before process exit (e.g. during updates)
    to prevent WAL corruption from abrupt shutdown.
    """
    try:
        kuzu = get_kuzu_client_direct()
        if kuzu is None or not kuzu._initialized or kuzu.conn is None:
            return {"status": "skipped", "reason": "database not initialized"}

        success = kuzu.base_client.checkpoint(reason="pre_shutdown_checkpoint", retry_count=3)
        if success:
            logger.info("Pre-shutdown checkpoint completed successfully")
            return {"status": "ok", "checkpointed": True}
        else:
            logger.warning("Pre-shutdown checkpoint failed after retries")
            return {"status": "warning", "checkpointed": False, "reason": "checkpoint failed after retries"}
    except Exception as e:
        logger.error("Pre-shutdown checkpoint error", error=str(e))
        return {"status": "error", "checkpointed": False, "reason": str(e)}


@router.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint."""
    try:
        # Try to obtain a DB client; if not ready, report degraded instead of raising 503
        try:
            kuzu = get_kuzu_client_direct()
            db_connected = False
            if kuzu is not None and getattr(kuzu, "conn", None) is not None:
                try:
                    # Ping DB to ensure connection is actually usable
                    assert kuzu.conn is not None, "db client connection is None"
                    kuzu.conn.execute("RETURN 1;")
                    db_connected = True
                except Exception:
                    db_connected = False
        except Exception:
            db_connected = False

        # Check service readiness based on configuration
        settings = get_settings()
        # Treat embedding as non-blocking for basic health (downloads may be in progress)
        embedding_ready = embedding_service is not None

        if (
            settings.entity_extraction_method == "llm"
            or settings.entity_extraction_method == "hybrid"
        ):
            # entity_ready = (
            #     llm_entity_extraction_service is not None
            #     and summarization_service is not None
            # )
            pass
        else:
            entity_ready = entity_extraction_service is not None

        # Do not gate overall status on embedding readiness; return degraded details via fields
        services_ready = True

        return HealthResponse(
            status="ok" if db_connected else "degraded",
            version=__version__,
            timestamp=datetime.datetime.now(datetime.UTC),
            database_connected=db_connected,
            services_ready=services_ready,
        )
    except Exception as e:
        logger.error("Health check failed", error=str(e))
        raise HTTPException(status_code=500, detail="Health check failed")
