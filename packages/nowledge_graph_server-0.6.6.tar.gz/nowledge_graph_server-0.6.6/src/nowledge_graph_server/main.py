import os
import signal
import asyncio
import atexit

# CRITICAL: Disable HuggingFace XET (Git LFS) system before any imports
# This prevents duplicate storage in ~/.cache/huggingface/xet/ directory
# Must be set before huggingface_hub is imported anywhere in the application
# See: https://github.com/huggingface/huggingface_hub/issues/3266
if "HF_HUB_DISABLE_XET" not in os.environ:
    os.environ["HF_HUB_DISABLE_XET"] = "1"

# Prevent litellm from fetching model pricing from GitHub on every import.
# Without this, `import litellm` makes a synchronous httpx.get() to
# raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json
# which adds ~200-500ms startup latency and an unexpected outbound network call.
# Must be set before litellm is imported anywhere (it reads this at module init).
if "LITELLM_LOCAL_MODEL_COST_MAP" not in os.environ:
    os.environ["LITELLM_LOCAL_MODEL_COST_MAP"] = "True"

from contextlib import asynccontextmanager, AsyncExitStack
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from . import __version__
from .api.dependencies import startup, shutdown
from .mcp_integration import initialize_mcp_context_from_dependencies
from .services.remote_access import (
    get_remote_access_manager,
    is_ip_allowlist_match,
    is_remote_target_path_allowed,
    load_ip_allowlist_from_env,
    IP_ALLOWLIST_ENV,
    is_local_request,
)
from .utils.logging import setup_logging

# Setup logging when module is imported
# When running under Tauri (NOWLEDGE_BUNDLED=1), use JSON logs so app.log Live Traffic works.
# When running standalone (dev), use ConsoleRenderer for readable output.
_bundled = os.environ.get("NOWLEDGE_BUNDLED", "").strip() == "1"
setup_logging(
    log_level="DEBUG",
    debug=not _bundled,
)

# Initialize progress logger early (creates progress.log file)
from .utils.progress_logger import get_progress_log_path
import structlog

logger = structlog.get_logger(__name__)
logger.info("Progress logger initialized", path=get_progress_log_path())

_BACKEND_IP_ALLOWLIST, _BACKEND_IP_ALLOWLIST_INVALID = load_ip_allowlist_from_env()
if _BACKEND_IP_ALLOWLIST_INVALID:
    logger.warning(
        "Ignoring invalid backend IP allowlist entries",
        env_var=IP_ALLOWLIST_ENV,
        invalid_entries=_BACKEND_IP_ALLOWLIST_INVALID,
    )
if _BACKEND_IP_ALLOWLIST:
    logger.info(
        "Backend IP allowlist enabled",
        env_var=IP_ALLOWLIST_ENV,
        entries=[str(network) for network in _BACKEND_IP_ALLOWLIST],
    )


# ==============================================================================
# Graceful Shutdown Handling for WAL Corruption Prevention
# ==============================================================================
# 
# This module implements signal handlers to ensure proper database shutdown
# with WAL flushing when the process receives SIGTERM or SIGINT signals.
# This is critical for preventing WAL corruption that can occur when the
# database is closed without flushing pending WAL entries.
#
# The shutdown() function in dependencies.py will:
# 1. Log checkpoint status before closing
# 2. Perform a final checkpoint with retry logic
# 3. Close the database connection
# ==============================================================================

_shutdown_initiated = False

def _sync_emergency_checkpoint():
    """Synchronous emergency checkpoint for atexit handler.
    
    This is a last-resort fallback if the normal async shutdown didn't complete.
    It attempts to checkpoint the database synchronously.
    """
    global _shutdown_initiated
    if _shutdown_initiated:
        return  # Normal shutdown already handled this
        
    try:
        from .api.dependencies import kuzu_client
        if kuzu_client and kuzu_client._initialized and kuzu_client.conn:
            logger.warning("Emergency atexit checkpoint - normal shutdown may not have completed")
            try:
                kuzu_client.conn.execute("CHECKPOINT;")
                logger.info("Emergency checkpoint completed")
            except Exception as e:
                logger.error("Emergency checkpoint failed", error=str(e))
    except Exception as e:
        # Can't do much here - just log
        print(f"Emergency checkpoint error: {e}")

# Register atexit handler for emergency checkpoint
atexit.register(_sync_emergency_checkpoint)


# Your existing lifespan
@asynccontextmanager
async def app_lifespan(app: FastAPI):
    global _shutdown_initiated
    
    # Startup
    assert startup is not None
    await startup()
    # Initialize MCP context after services are ready
    setup_mcp_context = initialize_mcp_context_from_dependencies()
    if setup_mcp_context is not None:
        await setup_mcp_context()
    
    try:
        yield
    finally:
        # Shutdown - mark as initiated to prevent duplicate emergency checkpoint
        _shutdown_initiated = True
        logger.info("Graceful shutdown initiated via lifespan")
        await shutdown()


# Create the MCP server once at module level
def create_mcp_server_once():
    """Create MCP server once and return both server and app."""
    from .mcp_integration import create_mcp_server

    # Create MCP server
    mcp = create_mcp_server()

    # Create ASGI app from MCP server
    # Use stateless_http=True to avoid session ID conflicts with kimi-cli
    # (kimi-cli pre-sets Mcp-Session-Id header which causes 400 errors in stateful mode)
    mcp_app = mcp.http_app(path="/", stateless_http=True)

    return mcp, mcp_app


# Get the MCP server and app
_mcp_server, _mcp_app = create_mcp_server_once()


# Combine both lifespans using AsyncExitStack
@asynccontextmanager
async def combined_lifespan(app: FastAPI):
    async with AsyncExitStack() as stack:
        # Enter both lifespans
        await stack.enter_async_context(app_lifespan(app))
        await stack.enter_async_context(_mcp_app.lifespan(app))  # type: ignore
        yield


# FastAPI app setup
app = FastAPI(
    title="Nowledge Mem API",
    description="REST API for Nowledge Mem Service",
    terms_of_service="https://mem.nowledge.co/privacy",
    contact={
        "name": "Nowledge Labs",
        "url": "https://www.nowledge-labs.ai",
        "email": "hello@nowledge-labs.ai",
    },
    servers=[
        {"url": "http://127.0.0.1:14242", "description": "Nowledge Mem API Server"},
    ],
    version=__version__,
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=combined_lifespan,
)


class RemoteAccessEnforcementMiddleware(BaseHTTPMiddleware):
    """Enforce API-key auth for Cloudflare-tunneled requests.

    This protects tunneled traffic even if cloudflared rewrites path prefixes.
    Local desktop traffic is unaffected.
    """

    async def dispatch(self, request: Request, call_next):  # type: ignore[override]
        path = request.url.path.lstrip("/")

        manager = get_remote_access_manager()
        is_tunnel = manager.is_tunnel_request(request)
        if not is_tunnel:
            return await call_next(request)

        # Never expose management APIs over tunnel traffic.
        if path.startswith("api/remote-access"):
            return JSONResponse(
                status_code=403,
                content={
                    "detail": (
                        "Remote access management endpoints are local-only "
                        "and unavailable through the public tunnel."
                    )
                },
            )

        normalized = path
        if normalized == "remote-api":
            normalized = ""
        elif normalized.startswith("remote-api/"):
            normalized = normalized[len("remote-api/") :]

        try:
            client_ip = manager.assert_authenticated(request)
            # Mark tunnel auth as validated so the downstream gateway router
            # does not need to re-parse credentials from the same request.
            request.state.remote_auth_ok = True
            request.state.remote_client_ip = client_ip
        except HTTPException as exc:
            return JSONResponse(
                status_code=exc.status_code,
                content={"detail": exc.detail},
                headers=exc.headers or {},
            )

        if not is_remote_target_path_allowed(normalized):
            return JSONResponse(
                status_code=403,
                content={
                    "detail": (
                        "Target endpoint is not exposed in remote mode. "
                        "Remote mode only exposes memory-center APIs."
                    )
                },
            )

        return await call_next(request)


class BackendIpAllowlistMiddleware(BaseHTTPMiddleware):
    """Restrict non-loopback backend access to configured IP/CIDR ranges."""

    async def dispatch(self, request: Request, call_next):  # type: ignore[override]
        if not _BACKEND_IP_ALLOWLIST:
            return await call_next(request)

        if is_local_request(request):
            return await call_next(request)

        client_host = request.client.host if request.client else ""
        if not is_ip_allowlist_match(client_host, _BACKEND_IP_ALLOWLIST):
            return JSONResponse(
                status_code=403,
                content={
                    "detail": (
                        "Access denied by IP allowlist. "
                        "Add this device IP/CIDR in Settings > Access Anywhere > Restrict by IP."
                    )
                },
            )

        return await call_next(request)


app.add_middleware(BackendIpAllowlistMiddleware)
app.add_middleware(RemoteAccessEnforcementMiddleware)

# CORS middleware for Tauri app
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "tauri://localhost",
        "https://tauri.localhost",
        "http://localhost:1420",  # Common Tauri v2 dev port
        "http://localhost:3000",
        "http://localhost:3001",
        "http://localhost:5173",
        "http://127.0.0.1:1420",  # Alternative localhost format
        "http://127.0.0.1:3000",
        "http://127.0.0.1:5173",
        "*",  # Allow all origins for development - remove in production
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "HEAD", "PATCH"],
    allow_headers=["*"],
)

# Import and register all routers
from .api.routers.health import router as health_router
from .api.routers.analytics import router as analytics_router
from .api.routers.labels import router as labels_router
from .api.routers.memories import router as memories_router
from .api.routers.threads import router as threads_router
from .api.routers.entities import router as entities_router

# from .api.routers.search import router as search_router
from .api.routers.distillation import router as distillation_router
from .api.routers.graph_analysis import router as graph_analysis_router
from .api.routers.models import router as models_router
from .api.routers.license import router as license_router
from .api.routers.remote_llm import router as remote_llm_router
from .api.routers.mcp_proxy import router as mcp_proxy_router
from .api.routers.bulk_import import router as bulk_import_router
from .api.routers.data_transfer import router as data_transfer_router
from .api.routers.browser_bridge import router as browser_bridge_router
from .api.routers.agent import router as agent_router
from .api.routers.sources import router as sources_router
from .api.routers.settings import router as settings_router
from .api.routers.openai_embeddings import router as openai_embeddings_router
from .api.routers.remote_access import (
    management_router as remote_access_router,
    gateway_router as remote_gateway_router,
)

# Register all routers
app.include_router(health_router, tags=["health"])
app.include_router(analytics_router, tags=["analytics"])
app.include_router(labels_router, tags=["labels"])
app.include_router(memories_router, tags=["memories"])
app.include_router(threads_router, tags=["threads"])
app.include_router(entities_router, tags=["entities"])
# app.include_router(search_router, tags=["search"])
app.include_router(distillation_router, tags=["distillation"])
app.include_router(graph_analysis_router, prefix="/graph", tags=["graph-analysis"])
app.include_router(models_router, prefix="/models", tags=["models"])
app.include_router(license_router, tags=["license"])
app.include_router(remote_llm_router, tags=["remote-llm"])
app.include_router(mcp_proxy_router, tags=["mcp-proxy"])
app.include_router(bulk_import_router, tags=["bulk-import"])
app.include_router(data_transfer_router, tags=["data-transfer"])
app.include_router(browser_bridge_router, tags=["browser-bridge"])
app.include_router(agent_router, tags=["knowledge-agent"])
app.include_router(sources_router, tags=["sources"])
app.include_router(settings_router, tags=["settings"])
app.include_router(openai_embeddings_router, tags=["openai-compatible"])
app.include_router(remote_access_router, tags=["remote-access"])
app.include_router(remote_gateway_router, tags=["remote-api"])

# Mount the MCP server using the same instance
app.mount("/mcp", _mcp_app)

# Store the MCP instance for later use
app.state.mcp_server = _mcp_server


# Development server function
def run_dev_server(host: str = "127.0.0.1", port: int = 14242):
    """Run development server."""
    import uvicorn

    uvicorn.run(app, host=host, port=port, reload=True)
