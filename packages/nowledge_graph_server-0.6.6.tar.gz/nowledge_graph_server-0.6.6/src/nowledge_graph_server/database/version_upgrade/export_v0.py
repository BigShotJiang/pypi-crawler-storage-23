#!/usr/bin/env python3
"""Export v0 database — STUB.

The kuzu 0.11.1 engine was removed in v0.6.4 to reduce bundle size (~11 MB).
v0 database export is no longer supported. Users with v0 databases must first
upgrade using app version 0.5.x, then update to the latest version.
"""

import sys
import json


def main():
    error_report = {
        "success": False,
        "error": (
            "v0 database export is no longer supported. "
            "The kuzu 0.11.1 engine was removed in v0.6.4. "
            "Please install Nowledge Mem v0.5.x to upgrade your v0 database first."
        ),
        "error_type": "V0UpgradeRemoved",
        "error_code": "UPGRADE_V0_NO_LONGER_SUPPORTED",
    }
    print(json.dumps(error_report))
    return 1


if __name__ == "__main__":
    sys.exit(main())
