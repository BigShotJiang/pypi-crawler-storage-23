"""Database version metadata manager using codenames for engine version tracking."""

import json
import os
import platform
import re
from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime, timezone
import structlog
from nowledge_graph_server.utils.app_paths import get_nowledge_graph_data_dir

logger = structlog.get_logger(__name__)

# Codename mapping for database versions (avoid exposing engine brands)
CODENAMES = {
    0: "alpine",  # v0 - legacy engine (kuzu 0.11.1)
    1: "birch",   # v1 - current engine (real_ladybug/Ladybug)
    2: "cedar",   # v2 - LanceDB search index, no Kuzu vector/FTS indexes
}

# Current target version for this app release
# v2: Uses LanceDB for search instead of Kuzu vector/FTS indexes
CURRENT_DB_VERSION = 2

_VERSIONED_STEM_RE = re.compile(r"^(?P<base>.+)_v(?P<version>\d+)$")
# Heuristic guardrail: if one same-version candidate is tiny and another is
# non-trivial, prefer the non-trivial one to avoid selecting an empty DB stub.
_MIN_NON_EMPTY_DB_BYTES = 128 * 1024


def _get_app_data_dir() -> Path:
    """Get canonical graph data directory path.

    Paths must match the desktop graph data root for each platform:
    - macOS: ~/Library/Application Support/NowledgeGraph
    - Windows: %LOCALAPPDATA%/NowledgeGraph
    - Linux: ~/.local/share/NowledgeGraph (XDG_DATA_HOME)
    """
    return get_nowledge_graph_data_dir()


def _append_unique(paths: list[Path], candidate: Path) -> None:
    """Append candidate path if not already present (string-equality)."""
    if any(p == candidate for p in paths):
        return
    paths.append(candidate)


def _candidate_data_dirs() -> list[Path]:
    """Return candidate graph-data directories ordered by preference."""
    canonical = _get_app_data_dir()
    home = Path.home()
    sys_name = platform.system()

    candidates: list[Path] = []
    _append_unique(candidates, canonical)

    # Keep Windows roaming fallback for legacy installs.
    if sys_name == "Windows":
        local = Path(
            os.environ.get("LOCALAPPDATA", str(home / "AppData" / "Local"))
        ) / "NowledgeGraph"
        roaming = Path(
            os.environ.get("APPDATA", str(home / "AppData" / "Roaming"))
        ) / "NowledgeGraph"
        _append_unique(candidates, local)
        _append_unique(candidates, roaming)
    elif sys_name == "Linux":
        data_home = Path(
            os.environ.get("XDG_DATA_HOME", str(home / ".local" / "share"))
        )
        _append_unique(candidates, data_home / "Nowledge Graph")
        _append_unique(candidates, data_home / "nowledge-mem")
    elif sys_name == "Darwin":
        app_support = home / "Library" / "Application Support"
        _append_unique(candidates, app_support / "Nowledge Graph")
        _append_unique(candidates, app_support / "nowledge-mem")

    # Very old desktop builds used Documents as data root.
    _append_unique(candidates, home / "Documents" / "NowledgeGraph")
    return candidates


def _to_unversioned_base_path(db_path: Path) -> Path:
    """Normalize a path to its unversioned family base (e.g., *_v2.db -> *.db)."""
    match = _VERSIONED_STEM_RE.match(db_path.stem)
    if not match:
        return db_path
    return db_path.with_name(f"{match.group('base')}{db_path.suffix}")


def _iter_family_paths(base_unversioned_path: Path) -> list[tuple[int, Path, bool]]:
    """Return all DB paths in a family, including legacy data/ layout paths."""
    paths: list[tuple[int, Path, bool]] = []
    seen: set[Path] = set()

    def _push(version: int, candidate: Path, is_legacy_layout: bool) -> None:
        if candidate in seen:
            return
        seen.add(candidate)
        paths.append((version, candidate, is_legacy_layout))

    for version in range(CURRENT_DB_VERSION, 0, -1):
        _push(
            version,
            get_db_path_for_version(base_unversioned_path, version),
            False,
        )
    _push(0, base_unversioned_path, False)

    # Legacy layout where DB lived under {root}/data/.
    legacy_base = base_unversioned_path.parent / "data" / base_unversioned_path.name
    if legacy_base != base_unversioned_path:
        for version in range(CURRENT_DB_VERSION, 0, -1):
            _push(
                version,
                get_db_path_for_version(legacy_base, version),
                True,
            )
        _push(0, legacy_base, True)

    return paths


def _safe_file_size(path: Path) -> Optional[int]:
    """Return file size for regular files; None for non-files or inaccessible paths."""
    try:
        if path.is_file():
            return path.stat().st_size
    except Exception:
        return None
    return None


def _select_preferred_existing_db(
    candidates: list[tuple[int, Path, int, bool, Optional[int]]],
) -> tuple[int, Path, int, bool, Optional[int], str]:
    """Select best DB candidate by version, priority and non-empty-size heuristic."""
    if not candidates:
        raise ValueError("No candidates provided")

    max_version = max(version for version, _, _, _, _ in candidates)
    version_candidates = [
        candidate for candidate in candidates if candidate[0] == max_version
    ]

    # Base preference: higher-priority root, then non-legacy layout.
    preferred = min(
        version_candidates,
        key=lambda candidate: (candidate[2], candidate[3]),
    )

    # Heuristic override for same-version candidates:
    # if preferred looks tiny but a sibling candidate looks non-empty, use sibling.
    preferred_size = preferred[4]
    if preferred_size is not None and preferred_size < _MIN_NON_EMPTY_DB_BYTES:
        sized = [c for c in version_candidates if c[4] is not None]
        if sized:
            largest = max(sized, key=lambda candidate: candidate[4] or 0)
            largest_size = largest[4] or 0
            if (
                largest[1] != preferred[1]
                and largest_size >= _MIN_NON_EMPTY_DB_BYTES
            ):
                return (*largest, "same-version-nonempty-size-heuristic")

    return (*preferred, "version-priority")


def _collect_existing_family_candidates(
    base_unversioned_path: Path, root_priority: int
) -> list[tuple[int, Path, int, bool, Optional[int]]]:
    """Collect existing DB files for a base path family."""
    collected: list[tuple[int, Path, int, bool, Optional[int]]] = []
    for version, candidate_path, is_legacy_layout in _iter_family_paths(
        base_unversioned_path
    ):
        if not candidate_path.exists():
            continue
        collected.append(
            (
                version,
                candidate_path,
                root_priority,
                is_legacy_layout,
                _safe_file_size(candidate_path),
            )
        )
    return collected


def _get_version_metadata_path(db_path: Path) -> Path:
    """Get path to version metadata JSON file next to database."""
    return db_path.parent / "db_version.json"


def get_db_version(db_path: Path) -> int:
    """
    Get current database version from metadata file.

    Args:
        db_path: Path to database file

    Returns:
        Database version number (0 for legacy, 1+ for versioned)
    """
    metadata_path = _get_version_metadata_path(db_path)

    try:
        if not metadata_path.exists():
            # No metadata file means v0 (legacy unversioned database)
            logger.debug(
                "No version metadata found, assuming v0 (alpine)", db_path=str(db_path)
            )
            return 0

        with open(metadata_path, "r") as f:
            metadata = json.load(f)
            version = metadata.get("db_version", 0)
            codename = metadata.get("db_codename", CODENAMES.get(version, "unknown"))
            logger.debug(
                "Read database version",
                version=version,
                codename=codename,
                db_path=str(db_path),
            )
            return version

    except Exception as e:
        logger.warning(
            "Failed to read version metadata, assuming v0",
            error=str(e),
            db_path=str(db_path),
        )
        return 0


def set_db_version(
    db_path: Path,
    version: int,
    app_version: str = "0.5.1",
    additional_metadata: Optional[Dict[str, Any]] = None,
) -> None:
    """
    Set database version in metadata file.

    Args:
        db_path: Path to database file
        version: Database version number
        app_version: Application version that performed the upgrade
        additional_metadata: Optional additional metadata to store
    """
    metadata_path = _get_version_metadata_path(db_path)
    codename = CODENAMES.get(version, f"unknown_v{version}")

    metadata = {
        "db_version": version,
        "db_codename": codename,
        "upgraded_at": datetime.now(timezone.utc).isoformat(),
        "app_version": app_version,
    }

    if additional_metadata:
        metadata.update(additional_metadata)

    try:
        # Ensure parent directory exists
        metadata_path.parent.mkdir(parents=True, exist_ok=True)

        with open(metadata_path, "w") as f:
            json.dump(metadata, f, indent=2)

        logger.info(
            "Updated database version metadata",
            version=version,
            codename=codename,
            db_path=str(db_path),
        )
    except Exception as e:
        logger.error(
            "Failed to write version metadata",
            error=str(e),
            db_path=str(db_path),
        )
        raise


def get_db_path_for_version(base_path: Path, version: int) -> Path:
    """
    Get database file path for a specific version using naming convention.

    Args:
        base_path: Base database path (e.g., nowledge_graph.db)
        version: Target version number

    Returns:
        Path to versioned database file

    Naming convention:
        v0: nowledge_graph.db (legacy, no version suffix)
        v1+: nowledge_graph_v1.db, nowledge_graph_v2.db, etc.
    """
    if version == 0:
        # Legacy v0 uses base name without version suffix
        return base_path

    # v1+ uses version suffix
    stem = base_path.stem  # e.g., "nowledge_graph"
    suffix = base_path.suffix  # e.g., ".db"
    versioned_name = f"{stem}_v{version}{suffix}"
    return base_path.parent / versioned_name


def get_db_path() -> Path:
    """
    Get current database path based on environment or default location.

    Respects NOWLEDGE_DB_PATH environment variable if set (used after upgrade).
    Otherwise uses default location in app data directory.

    Returns:
        Path to current database file
    """
    # Check environment variable first (set by upgrade/startup process).
    # Guard against stale overrides by always selecting the best existing path
    # in the same DB family (highest version first, with empty-file heuristic).
    env_path = os.environ.get("NOWLEDGE_DB_PATH")
    requested_env_path: Optional[Path] = None
    if env_path:
        requested = Path(env_path)
        requested_env_path = requested
        env_base = _to_unversioned_base_path(requested)
        env_candidates = _collect_existing_family_candidates(env_base, 0)

        if env_candidates:
            (
                selected_version,
                selected_path,
                _,
                _is_legacy_layout,
                _selected_size,
                selection_reason,
            ) = _select_preferred_existing_db(env_candidates)
            if selected_path != requested:
                logger.warning(
                    "NOWLEDGE_DB_PATH override adjusted to preferred existing database",
                    requested_path=str(requested),
                    selected_path=str(selected_path),
                    selected_version=selected_version,
                    reason=selection_reason,
                )
            else:
                logger.debug(
                    "Using database path from environment",
                    path=str(selected_path),
                    selected_version=selected_version,
                )
            return selected_path

        logger.warning(
            "NOWLEDGE_DB_PATH points to missing database family; falling back to global discovery",
            requested_path=str(requested),
        )

    # No env override: scan canonical root first, then legacy-compatible roots.
    global_candidates: list[tuple[int, Path, int, bool, Optional[int]]] = []
    candidate_dirs = _candidate_data_dirs()
    for root_priority, app_data_dir in enumerate(candidate_dirs):
        base_path = app_data_dir / "nowledge_graph.db"
        global_candidates.extend(
            _collect_existing_family_candidates(base_path, root_priority)
        )

    if global_candidates:
        (
            selected_version,
            selected_path,
            selected_root_priority,
            selected_legacy_layout,
            _selected_size,
            selection_reason,
        ) = _select_preferred_existing_db(global_candidates)
        logger.info(
            "Resolved database path from existing candidates",
            selected_path=str(selected_path),
            selected_version=selected_version,
            selected_root_priority=selected_root_priority,
            selected_legacy_layout=selected_legacy_layout,
            reason=selection_reason,
        )
        return selected_path

    # If env override was provided but we couldn't find any existing DB anywhere,
    # honor requested path as the final fallback.
    if requested_env_path is not None:
        logger.warning(
            "Falling back to requested NOWLEDGE_DB_PATH after global discovery found no existing databases",
            requested_path=str(requested_env_path),
        )
        return requested_env_path

    # Fall back to canonical v0 location when no database exists yet.
    v0_path = candidate_dirs[0] / "nowledge_graph.db"
    logger.debug("Using canonical v0 database path", path=str(v0_path))
    return v0_path


def needs_upgrade(db_path: Optional[Path] = None) -> bool:
    """
    Check if database needs version upgrade.

    Args:
        db_path: Optional database path (uses get_db_path() if not provided)

    Returns:
        True if upgrade is needed
    """
    if db_path is None:
        db_path = get_db_path()

    # Only upgrade if database file exists
    if not db_path.exists():
        logger.debug("Database does not exist yet, no upgrade needed")
        return False

    current_version = get_db_version(db_path)
    needs_upgrade_flag = current_version < CURRENT_DB_VERSION

    logger.info(
        "Database version check",
        current_version=current_version,
        current_codename=CODENAMES.get(current_version, "unknown"),
        target_version=CURRENT_DB_VERSION,
        target_codename=CODENAMES.get(CURRENT_DB_VERSION, "unknown"),
        needs_upgrade=needs_upgrade_flag,
    )

    return needs_upgrade_flag
