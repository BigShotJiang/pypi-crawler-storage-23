"""
Search Strategy Implementations - LanceDB Version

This module contains the core search strategy implementations that use:
- LanceDB for vector + FTS (BM25) search
- Kuzu for graph traversal (entities, communities, relationships)

Three main strategies:
1. Memory Hybrid: Vector + FTS over memories (LanceDB)
2. Community Mediated: Community search (LanceDB) -> graph traversal (Kuzu) -> memories
3. Entity Mediated: Entity search (LanceDB) -> graph traversal (Kuzu) -> memories
"""

import datetime
from typing import Any, List, TYPE_CHECKING

import real_ladybug as kuzu
import structlog

from ..models.memory import MemorySearchResult
from ..models.graph import EntityNode, NodeType
from ..database.result_utils import iter_rows, managed_result
from ..services.search_index import (
    get_search_index_service,
    get_bge_m3_service,
)
from .search_engine_lancedb import (
    _build_memory_node,
    _fuse_hybrid_results,
    _search_by_labels,
    _extract_entities_llm,
    STOP_WORDS,
)

if TYPE_CHECKING:
    from ..database.kuzu_client import KuzuClient

logger = structlog.get_logger(__name__)


async def memory_hybrid_strategy(
    db: "KuzuClient",
    query_text: str,
    limit: int,
    search_context: dict[str, Any] | None = None,
) -> list[MemorySearchResult]:
    """Strategy 1: Vector + FTS hybrid over memories using LanceDB.

    Uses LanceDB hybrid search (vector + BM25 FTS) with RRF fusion.
    """
    try:
        search_service = await get_search_index_service()
        bge_service = await get_bge_m3_service()

        if not search_service or not bge_service:
            logger.warning("LanceDB search service not available")
            return []

        # Use HyDE query if available
        effective_query = query_text
        if search_context and search_context.get("advanced", {}).get("use_hyde"):
            hyde_query = search_context["advanced"]["hyde_query"]
            if hyde_query and hyde_query != query_text:
                effective_query = hyde_query
                logger.debug(f"Using HyDE query for embedding: '{hyde_query}'")

        # Generate query embedding (is_query=True for search queries)
        query_embedding = await bge_service.embed_text(effective_query, is_query=True)

        # LanceDB hybrid search - returns list of SearchResult
        lancedb_results = await search_service.search_memories_hybrid(
            query_text=query_text,  # Use original for FTS
            query_embedding=query_embedding,
            limit=limit * 2,  # Get more for fusion
        )

        # Convert LanceDB results to tuple format for fusion
        # LanceDB hybrid returns RRF-normalized scores
        vector_memories = []
        fts_memories = []

        for result in lancedb_results:
            memory_data = result.data
            # RRF score is already normalized to 0-1
            score = result.score

            # LanceDB hybrid gives combined score, we'll treat as both vector and FTS
            # since RRF combines both
            vector_memories.append((memory_data, score, "vector"))
            fts_memories.append((memory_data, score, "fts"))

        # Label-based search if enabled
        label_memories = []
        if search_context and search_context.get("advanced", {}).get("label_search_enabled"):
            potential_labels = search_context["advanced"].get("potential_labels", [])
            label_memories = await _search_by_labels(db, potential_labels, limit)
            logger.debug(f"Label search returned {len(label_memories)} results")

        # Fuse results
        return await _fuse_hybrid_results(
            db,
            vector_memories,
            fts_memories,
            limit,
            label_memories,
            search_context,
        )

    except Exception as e:
        import traceback
        logger.error("Memory hybrid strategy failed", error=str(e))
        logger.debug(traceback.format_exc())
        return []


async def community_strategy(
    db: "KuzuClient",
    query_text: str,
    limit: int,
    graph_traversal_stats: dict[str, int],
) -> list[MemorySearchResult]:
    """Strategy 2: Community search (LanceDB) -> connected memories via entities (Kuzu).

    Uses LanceDB for community FTS search, then Kuzu for graph traversal.
    """
    logger.debug(f"Community strategy started with query: {query_text}")
    try:
        search_service = await get_search_index_service()
        bge_service = await get_bge_m3_service()

        if not search_service or not bge_service:
            logger.warning("LanceDB search service not available")
            return []

        # Generate query embedding (is_query=True for search queries)
        query_embedding = await bge_service.embed_text(query_text, is_query=True)

        # Search communities using LanceDB hybrid search
        community_results = await search_service.search_communities_hybrid(
            query_text=query_text,
            query_embedding=query_embedding,
            limit=3,  # Get top 3 communities
        )

        if not community_results:
            logger.debug(f"No communities found matching query: {query_text}")
            return []

        results = []

        for community_result in community_results:
            community_data = community_result.data
            community_score = community_result.score
            # Use community_id (INT64 Louvain ID) for graph traversal, not id (UUID)
            louvain_community_id = community_data.get("community_id")

            if louvain_community_id is None:
                logger.warning(f"Community missing community_id (Louvain ID): {community_data.get('id')}")
                continue

            # Verify ai_summary exists
            ai_summary = community_data.get("ai_summary")
            if not ai_summary:
                continue

            graph_traversal_stats["communities_analyzed"] += 1

            # Find memories with most entity connections in this community (Kuzu graph)
            try:
                _community_id = int(louvain_community_id)

                memory_query = """
                    MATCH (e:Entity {community_id: $community_id})<-[:MENTIONS]-(m:Memory)
                    WITH m, COUNT(e) as entity_count, COLLECT(DISTINCT e.id) as entity_ids
                    RETURN m, entity_count, entity_ids
                    ORDER BY entity_count DESC, m.importance DESC
                    LIMIT 1
                """

                memory_result = db.conn.execute(memory_query, {"community_id": _community_id})

                if isinstance(memory_result, list) and memory_result:
                    memory_result = memory_result[0]

                if isinstance(memory_result, kuzu.QueryResult):
                    with managed_result(memory_result):
                        if memory_result.has_next():
                            memory_row = memory_result.get_next()
                            memory_data = memory_row[0]
                            entity_count = memory_row[1]
                            entity_ids = memory_row[2]

                            graph_traversal_stats["entities_traversed"] += len(entity_ids) if entity_ids else 0
                            graph_traversal_stats["relationships_traversed"] += entity_count * 2

                            memory_node = _build_memory_node(db, memory_data)
                            memory_search_result = MemorySearchResult(
                                memory=memory_node,
                                similarity_score=min(community_score, 1.0) * 0.9,
                                relevance_reason=f"Key memory from community '{community_data.get('name', 'unnamed')}' via {entity_count} entities",
                                related_entities=[],
                            )
                            results.append(memory_search_result)

            except Exception as e:
                logger.warning(f"Failed to traverse community {community_id}: {e}")
                continue

        logger.debug(f"Community strategy results: {len(results)} memories found")
        return results

    except Exception as e:
        logger.error("Community strategy failed", error=str(e))
        return []


async def entity_strategy(
    db: "KuzuClient",
    query_text: str,
    limit: int,
    graph_traversal_stats: dict[str, int],
) -> list[MemorySearchResult]:
    """Strategy 3: LLM extract entities -> Entity search (LanceDB) -> connected memories (Kuzu).

    Uses LLM for entity extraction, LanceDB for entity search, Kuzu for graph traversal.
    """
    logger.debug(f"Entity strategy started with query: {query_text}")
    try:
        # Extract entities with LLM
        entities = await _extract_entities_llm(query_text)
        if not entities:
            return []

        search_service = await get_search_index_service()
        bge_service = await get_bge_m3_service()

        if not search_service or not bge_service:
            return []

        # Find matching entities via LanceDB search
        matched_entities = []
        for entity_name in entities[:3]:
            try:
                # Generate embedding for entity name (is_query=True - searching for entity)
                entity_embedding = await bge_service.embed_text(entity_name, is_query=True)

                # Search entities using LanceDB hybrid
                entity_results = await search_service.search_entities_hybrid(
                    query_text=entity_name,
                    query_embedding=entity_embedding,
                    limit=2,
                )

                for result in entity_results:
                    if result.score > 0:
                        matched_entities.append({
                            "data": result.data,
                            "score": result.score,
                            "extracted": entity_name,
                        })

            except Exception as e:
                logger.warning(f"Entity search failed for '{entity_name}': {e}")
                continue

        if not matched_entities:
            return []

        graph_traversal_stats["entities_traversed"] += len(matched_entities)

        # Find memories connected to entities (Kuzu graph)
        entity_ids = [e["data"]["id"] for e in matched_entities if e["data"].get("id")]

        if not entity_ids:
            return []

        memory_query = """
            MATCH (m:Memory)-[:MENTIONS]->(e:Entity)
            WHERE e.id IN $entity_ids
            WITH m, COLLECT(DISTINCT e) as entity_nodes, COUNT(DISTINCT e) as entity_count
            RETURN m, entity_nodes, entity_count
            ORDER BY entity_count DESC, m.importance DESC
            LIMIT $limit
        """

        memory_result = db.conn.execute(memory_query, {"entity_ids": entity_ids, "limit": min(limit, 3)})

        if isinstance(memory_result, list) and memory_result:
            memory_result = memory_result[0]

        memories = []
        if isinstance(memory_result, kuzu.QueryResult):
            for row in iter_rows(memory_result):
                memory_data = row[0]
                entity_nodes = row[1]
                entity_count = row[2]

                graph_traversal_stats["relationships_traversed"] += entity_count

                memory_node = _build_memory_node(db, memory_data)

                # Score based on entity connections
                avg_score = sum(e["score"] for e in matched_entities) / len(matched_entities)
                normalized_score = min(avg_score, 1.0) * 0.8

                extracted_names = [e.get("extracted", "") for e in matched_entities]
                reason = f"Connected to {entity_count} entities. Extracted: {', '.join(extracted_names[:2])}"

                # Build EntityNode objects
                related_entities = []
                for entity_data in entity_nodes:
                    if not entity_data or not isinstance(entity_data, dict):
                        continue

                    entity_id = entity_data.get("id")
                    entity_name = entity_data.get("name")
                    if not entity_id or not entity_name:
                        continue

                    created_at = db.base_client._safe_parse_datetime(entity_data.get("created_at")) or datetime.datetime.now(datetime.timezone.utc)
                    updated_at = db.base_client._safe_parse_datetime(entity_data.get("updated_at")) or datetime.datetime.now(datetime.timezone.utc)
                    metadata = db.base_client._deserialize_metadata(entity_data.get("metadata", "{}"))

                    related_entities.append(EntityNode(
                        id=entity_id,
                        node_type=NodeType.ENTITY,
                        name=entity_name,
                        entity_type=entity_data.get("entity_type", "entity"),
                        description=entity_data.get("description", None),
                        aliases=entity_data.get("aliases", []),
                        confidence=entity_data.get("confidence", 0.5),
                        created_at=created_at,
                        updated_at=updated_at,
                        metadata=metadata,
                        entity_created=entity_data.get("entity_created"),
                        entity_ended=entity_data.get("entity_ended"),
                        temporal_precision=entity_data.get("temporal_precision"),
                        temporal_confidence=entity_data.get("temporal_confidence"),
                        temporal_context=entity_data.get("temporal_context"),
                    ))

                search_result = MemorySearchResult(
                    memory=memory_node,
                    similarity_score=normalized_score,
                    relevance_reason=reason,
                    related_entities=related_entities,
                )
                memories.append(search_result)

        return memories

    except Exception as e:
        logger.error("Entity strategy failed", error=str(e))
        return []


async def entity_strategy_fast(
    db: "KuzuClient",
    query_text: str,
    limit: int,
    graph_traversal_stats: dict[str, int],
) -> list[tuple[Any, float, str]]:
    """Fast entity strategy: Extract entities from query text (no LLM) -> Entity search (LanceDB) -> connected memories (Kuzu).

    Returns list of tuples: (memory_data, score, "entity")
    """
    logger.debug(f"Fast entity strategy started with query: {query_text}")
    try:
        # Fast entity extraction: extract potential entity names from query text (no LLM)
        potential_entities = [
            entity.strip()
            for entity in query_text.split()
            if entity.strip() and entity.strip() not in STOP_WORDS and len(entity.strip()) > 3
        ]

        if not potential_entities:
            return []

        search_service = await get_search_index_service()
        bge_service = await get_bge_m3_service()

        if not search_service or not bge_service:
            return []

        # Find matching entities via LanceDB search
        matched_entities = []
        for entity_name in potential_entities[:3]:
            try:
                # is_query=True - searching for entity
                entity_embedding = await bge_service.embed_text(entity_name, is_query=True)
                entity_results = await search_service.search_entities_hybrid(
                    query_text=entity_name,
                    query_embedding=entity_embedding,
                    limit=2,
                )

                for result in entity_results:
                    if result.score > 0:
                        matched_entities.append({
                            "data": result.data,
                            "score": result.score,
                            "extracted": entity_name,
                        })

            except Exception as e:
                logger.warning(f"Entity search failed for '{entity_name}': {e}")
                continue

        if not matched_entities:
            return []

        graph_traversal_stats["entities_traversed"] += len(matched_entities)

        # Find memories connected to entities (Kuzu graph)
        entity_ids = [e["data"]["id"] for e in matched_entities if e["data"].get("id")]

        if not entity_ids:
            return []

        memory_query = """
            MATCH (m:Memory)-[:MENTIONS]->(e:Entity)
            WHERE e.id IN $entity_ids
            WITH m, COLLECT(DISTINCT e) as entity_nodes, COUNT(DISTINCT e) as entity_count
            RETURN m, entity_nodes, entity_count
            ORDER BY entity_count DESC, m.importance DESC
            LIMIT $limit
        """

        memory_result = db.conn.execute(memory_query, {"entity_ids": entity_ids, "limit": min(limit, 5)})

        if isinstance(memory_result, list) and memory_result:
            memory_result = memory_result[0]

        entity_memories = []
        if isinstance(memory_result, kuzu.QueryResult):
            for row in iter_rows(memory_result):
                memory_data = row[0]
                entity_nodes = row[1]
                entity_count = row[2]

                graph_traversal_stats["relationships_traversed"] += entity_count

                avg_score = sum(e["score"] for e in matched_entities) / len(matched_entities)
                normalized_score = min(avg_score, 1.0) * 0.8

                entity_memories.append((memory_data, normalized_score, "entity"))

        logger.debug(f"Fast entity strategy results: {len(entity_memories)} memories found")
        return entity_memories

    except Exception as e:
        logger.error("Fast entity strategy failed", error=str(e))
        return []


async def community_strategy_fast(
    db: "KuzuClient",
    query_text: str,
    limit: int,
    graph_traversal_stats: dict[str, int],
) -> list[tuple[Any, float, str]]:
    """Fast community strategy: Community search (LanceDB) -> connected memories (Kuzu).

    Returns list of tuples: (memory_data, score, "community")
    """
    logger.debug(f"Fast community strategy started with query: {query_text}")
    try:
        search_service = await get_search_index_service()
        bge_service = await get_bge_m3_service()

        if not search_service or not bge_service:
            return []

        # is_query=True for search queries
        query_embedding = await bge_service.embed_text(query_text, is_query=True)

        # Search communities using LanceDB hybrid search
        community_results = await search_service.search_communities_hybrid(
            query_text=query_text,
            query_embedding=query_embedding,
            limit=1,  # Fast mode: only top community
        )

        if not community_results:
            logger.debug(f"No communities found matching query: {query_text}")
            return []

        community_memories = []

        for community_result in community_results:
            community_data = community_result.data
            community_score = community_result.score
            # Use community_id (INT64 Louvain ID) for graph traversal, not id (UUID)
            louvain_community_id = community_data.get("community_id")

            if louvain_community_id is None:
                logger.warning(f"Community missing community_id (Louvain ID): {community_data.get('id')}")
                continue

            ai_summary = community_data.get("ai_summary")
            if not ai_summary:
                continue

            graph_traversal_stats["communities_analyzed"] += 1

            try:
                _community_id = int(louvain_community_id)

                memory_query = """
                    MATCH (e:Entity {community_id: $community_id})<-[:MENTIONS]-(m:Memory)
                    WITH m, COUNT(e) as entity_count, COLLECT(DISTINCT e.id) as entity_ids
                    RETURN m, entity_count, entity_ids
                    ORDER BY entity_count DESC, m.importance DESC
                    LIMIT $limit
                """

                memory_result = db.conn.execute(memory_query, {"community_id": _community_id, "limit": min(limit, 3)})

                if isinstance(memory_result, list) and memory_result:
                    memory_result = memory_result[0]

                if isinstance(memory_result, kuzu.QueryResult):
                    for memory_row in iter_rows(memory_result):
                        memory_data = memory_row[0]
                        entity_count = memory_row[1]
                        entity_ids = memory_row[2]

                        graph_traversal_stats["entities_traversed"] += len(entity_ids) if entity_ids else 0
                        graph_traversal_stats["relationships_traversed"] += entity_count * 2

                        normalized_score = min(community_score, 1.0) * 0.9
                        community_memories.append((memory_data, normalized_score, "community"))

            except Exception as e:
                logger.warning(f"Failed to traverse community {community_id}: {e}")
                continue

        logger.debug(f"Fast community strategy found {len(community_memories)} memories")
        return community_memories

    except Exception as e:
        logger.error("Fast community strategy failed", error=str(e))
        return []
