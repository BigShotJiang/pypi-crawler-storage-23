"""Utilities for safely consuming Kuzu/Ladybug QueryResult objects."""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Generator, Iterable


def close_kuzu_result(result: Any) -> None:
    close_fn = getattr(result, "close", None)
    if callable(close_fn):
        try:
            close_fn()
        except Exception:
            pass


@contextmanager
def managed_result(result: Any) -> Generator[Any, None, None]:
    try:
        yield result
    finally:
        close_kuzu_result(result)


def iter_rows(result: Any) -> Iterable[Any]:
    try:
        if hasattr(result, "has_next"):
            while result.has_next():
                yield result.get_next()
    finally:
        close_kuzu_result(result)
