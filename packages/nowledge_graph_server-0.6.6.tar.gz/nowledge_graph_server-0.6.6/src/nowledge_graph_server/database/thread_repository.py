"""
Thread Repository

All thread-related database operations including CRUD and management.
"""

from collections.abc import Mapping
from typing import List, Optional, Dict, Any, cast
import datetime
import structlog
import real_ladybug as kuzu
import json

from nowledge_graph_server.models import (
    ThreadNode,
    ThreadCreateResponse,
    ThreadFetchResponse,
    MemoryNode,
    MessageNode,
)
from nowledge_graph_server.database.base_client import (
    KuzuBaseClient,
    build_kuzu_params,  # type: ignore[attr-defined]
)
from nowledge_graph_server.database.schema import COMMON_QUERIES
from nowledge_graph_server.services.search_index import (
    sync_messages_batch,
    delete_thread_messages_from_index,
)

logger = structlog.get_logger(__name__)

_MESSAGE_METADATA_KEYS = (
    "external_id",
    "source_message_id",
    "message_id",
    "openclaw_entry_id",
    "session_key",
    "session_id",
    "source",
)


def _close_result(result: Any) -> None:
    close_fn = getattr(result, "close", None)
    if callable(close_fn):
        close_fn()


def _coerce_metadata(value: Any) -> dict[str, Any]:
    if isinstance(value, Mapping):
        return dict(value)
    return {}


def _extract_message_metadata(message: dict[str, Any]) -> dict[str, Any]:
    metadata = _coerce_metadata(message.get("metadata"))
    for key in _MESSAGE_METADATA_KEYS:
        if key in metadata:
            continue
        value = message.get(key)
        if isinstance(value, str):
            value = value.strip()
            if not value:
                continue
        if value is not None:
            metadata[key] = value
    return metadata


def _deserialize_metadata_safe(client: KuzuBaseClient, value: Any) -> dict[str, Any]:
    if isinstance(value, Mapping):
        return dict(value)
    if isinstance(value, str):
        return client._deserialize_metadata(value)  # type: ignore[attr-defined]
    return {}


class ThreadRepository:
    """Repository for thread-related database operations."""

    def __init__(self, client: KuzuBaseClient):
        """Initialize with base client for database access."""
        self.client = client

    @property
    def conn(self) -> kuzu.Connection | None:
        """Access database connection through client."""
        return cast(kuzu.Connection | None, self.client.conn)  # type: ignore[attr-defined]

    async def create_thread(
        self,
        thread_id: str,
        messages: List[Dict[str, Any]],
        title: Optional[str] = None,
        participants: Optional[List[str]] = None,
        source: Optional[str] = None,
        project: Optional[str] = None,
        workspace: Optional[str] = None,
        tool_version: Optional[str] = None,
        import_date: Optional[datetime.datetime] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ThreadCreateResponse:
        """Create a new thread with messages."""
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            participants = participants or []
            _metadata: dict[str, Any] = metadata or {}
            now = datetime.datetime.now(datetime.timezone.utc)

            # Create thread node with flattened properties
            thread_node = ThreadNode(
                thread_id=thread_id,
                title=title,
                summary="",  # Initialize with empty summary
                message_count=len(messages),
                participants=participants,
                source=source,
                project=project,
                workspace=workspace,
                tool_version=tool_version,
                import_date=import_date,
                metadata=_metadata,
            )

            # Create all nodes + relationships atomically, then checkpoint for durability.
            message_nodes: List[MessageNode] = []
            relationship_count = 0
            with self.client.transaction(
                checkpoint=True,
                reason=f"create_thread:{thread_id}",
            ):
                # Insert thread with flattened properties
                thread_query = """
                    CREATE (t:Thread {
                        id: $id,
                        thread_id: $thread_id,
                        title: $title,
                        summary: $summary,
                        message_count: $message_count,
                        participants: $participants,
                        source: $source,
                        created_at: $created_at,
                        updated_at: $updated_at,
                        project: $project,
                        workspace: $workspace,
                        tool_version: $tool_version,
                        import_date: $import_date,
                        metadata: $metadata
                    })
                """

                self.conn.execute(
                    thread_query,
                    {
                        "id": thread_node.id,
                        "thread_id": thread_node.thread_id,
                        "title": thread_node.title,
                        "summary": thread_node.summary,
                        "message_count": thread_node.message_count,
                        "participants": thread_node.participants,
                        "source": thread_node.source,
                        "created_at": thread_node.created_at,
                        "updated_at": thread_node.updated_at,
                        "project": thread_node.project,
                        "workspace": thread_node.workspace,
                        "tool_version": thread_node.tool_version,
                        "import_date": thread_node.import_date,
                        "metadata": self.client._serialize_metadata(thread_node.metadata),  # type: ignore[attr-defined]
                    },
                )

                # Create message nodes and relationships
                for i, msg_data in enumerate(messages):
                    msg = dict(msg_data) if isinstance(msg_data, Mapping) else {}
                    message_metadata = _extract_message_metadata(msg)
                    message_node = MessageNode(
                        content=str(msg.get("content", "")),
                        role=str(msg.get("role", "user")),
                        order_index=i,
                        timestamp=msg.get("timestamp"),
                        token_count=msg.get("token_count", 0),
                        metadata=message_metadata,
                    )

                    # Insert message
                    message_query = """
                        CREATE (m:Message {
                            id: $id,
                            content: $content,
                            role: $role,
                            order_index: $order_index,
                            timestamp: $timestamp,
                            token_count: $token_count,
                            created_at: $created_at,
                            updated_at: $updated_at,
                            metadata: $metadata
                        })
                    """

                    self.conn.execute(
                        message_query,
                        {
                            "id": message_node.id,
                            "content": message_node.content,
                            "role": message_node.role,
                            "order_index": message_node.order_index,
                            "timestamp": message_node.timestamp,
                            "token_count": message_node.token_count,
                            "created_at": message_node.created_at,
                            "updated_at": message_node.updated_at,
                            "metadata": self.client._serialize_metadata(  # type: ignore[attr-defined]
                                message_node.metadata
                            ),
                        },
                    )

                    # Create CONTAINS relationship
                    contains_query = """
                        MATCH (t:Thread {id: $thread_id}), (m:Message {id: $message_id})
                        CREATE (t)-[:CONTAINS {
                            order_index: $order_index,
                            created_at: $created_at,
                            properties: $properties
                        }]->(m)
                    """

                    self.conn.execute(
                        contains_query,
                        {
                            "thread_id": thread_node.id,
                            "message_id": message_node.id,
                            "order_index": i,
                            "created_at": now,
                            "properties": "{}",
                        },
                    )

                    message_nodes.append(message_node)
                    relationship_count += 1

            logger.debug(
                "Created thread and checkpointed",
                thread_id=thread_id,
                message_count=len(messages),
            )

            # Sync messages to search index (non-blocking, best-effort)
            try:
                messages_for_sync = [
                    {
                        "id": msg.id,
                        "thread_id": thread_id,
                        "content": msg.content,
                        "role": msg.role,
                        "order_index": msg.order_index,
                        "created_at": msg.created_at,
                    }
                    for msg in message_nodes
                ]
                await sync_messages_batch(messages_for_sync)
            except Exception as sync_error:
                logger.debug(
                    "Search index sync skipped for thread messages",
                    thread_id=thread_id,
                    error=str(sync_error),
                )

            return ThreadCreateResponse(
                thread=thread_node,
                messages=message_nodes,
                created_relationships=relationship_count,
                auto_generated_summary=None,  # Add missing required argument
            )

        except Exception as e:
            logger.error("Failed to create thread", thread_id=thread_id, error=str(e))
            raise

    async def append_messages(
        self,
        thread_id: str,
        messages: List[Dict[str, Any]],
        start_index: int,
    ) -> None:
        """Append messages to an existing thread.

        Args:
            thread_id: Thread identifier
            messages: List of message objects to append
            start_index: Starting order_index for new messages
        """
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            # Get thread UUID
            thread_query = "MATCH (t:Thread {thread_id: $thread_id}) RETURN t.id as id"
            thread_result = self.conn.execute(thread_query, {"thread_id": thread_id})
            thread_row = None
            try:
                while thread_result.has_next():  # type: ignore[attr-defined]
                    thread_row = thread_result.get_next()  # type: ignore[attr-defined]
                    break
            finally:
                _close_result(thread_result)

            if not thread_row:
                raise ValueError(f"Thread not found: {thread_id}")

            thread_uuid = thread_row[0]  # type: ignore[index]

            with self.client.transaction(
                checkpoint=True,
                reason=f"append_messages:{thread_id}",
            ):
                # Insert messages
                for i, msg_data in enumerate(messages):
                    msg = dict(msg_data) if isinstance(msg_data, Mapping) else {}
                    message_metadata = _extract_message_metadata(msg)
                    message_node = MessageNode(
                        content=str(msg.get("content", "")),
                        role=str(msg.get("role", "user")),
                        order_index=start_index + i,
                        timestamp=msg.get("timestamp"),
                        token_count=msg.get("token_count", 0),
                        metadata=message_metadata,
                    )

                    # Insert message (include created_at/updated_at for consistency with create_thread)
                    message_query = """
                        CREATE (m:Message {
                            id: $id,
                            content: $content,
                            role: $role,
                            order_index: $order_index,
                            timestamp: $timestamp,
                            token_count: $token_count,
                            created_at: $created_at,
                            updated_at: $updated_at,
                            metadata: $metadata
                        })
                    """

                    self.conn.execute(
                        message_query,
                        {
                            "id": message_node.id,
                            "content": message_node.content,
                            "role": message_node.role,
                            "order_index": message_node.order_index,
                            "timestamp": message_node.timestamp,
                            "token_count": message_node.token_count,
                            "created_at": message_node.created_at,
                            "updated_at": message_node.updated_at,
                            "metadata": self.client._serialize_metadata(  # type: ignore[attr-defined]
                                message_node.metadata
                            ),
                        },
                    )

                    # Create relationship
                    relationship_query = """
                        MATCH (t:Thread {id: $thread_id})
                        MATCH (m:Message {id: $message_id})
                        CREATE (t)-[:CONTAINS {order_index: $order_index}]->(m)
                    """

                    self.conn.execute(
                        relationship_query,
                        {
                            "thread_id": thread_uuid,
                            "message_id": message_node.id,
                            "order_index": message_node.order_index,
                        },
                    )

            logger.info(
                "Messages appended successfully",
                thread_id=thread_id,
                count=len(messages),
                start_index=start_index,
            )

            # Sync appended messages to search index (non-blocking, best-effort)
            try:
                messages_for_sync = [
                    {
                        "id": f"{thread_id}_{start_index + i}",  # Approximate ID
                        "thread_id": thread_id,
                        "content": msg_data["content"],
                        "role": msg_data["role"],
                        "order_index": start_index + i,
                        "created_at": datetime.datetime.now(datetime.timezone.utc),
                    }
                    for i, msg_data in enumerate(messages)
                ]
                await sync_messages_batch(messages_for_sync)
            except Exception as sync_error:
                logger.debug(
                    "Search index sync skipped for appended messages",
                    thread_id=thread_id,
                    error=str(sync_error),
                )

        except Exception as e:
            logger.error(
                "Failed to append messages",
                thread_id=thread_id,
                count=len(messages),
                error=str(e),
            )
            raise

    async def fetch_thread(self, thread_id: str) -> Optional[ThreadFetchResponse]:
        """Fetch a complete thread with messages."""
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            thread_query = """
                MATCH (t:Thread {thread_id: $thread_id})
                RETURN t
            """

            thread_result = self.conn.execute(thread_query, {"thread_id": thread_id})

            assert isinstance(thread_result, kuzu.QueryResult), (
                "thread_result is not a QueryResult"
            )
            try:
                if not thread_result.has_next():
                    return None

                thread_row = thread_result.get_next()
                thread_data = thread_row[0]  # type: ignore
            finally:
                _close_result(thread_result)

            thread_node = ThreadNode(
                id=thread_data["id"],
                thread_id=thread_data["thread_id"],
                title=thread_data["title"],
                summary=thread_data["summary"],
                message_count=thread_data["message_count"],
                participants=thread_data["participants"],
                source=thread_data["source"],
                created_at=thread_data["created_at"]
                if isinstance(thread_data["created_at"], datetime.datetime)
                else (
                    datetime.datetime.fromisoformat(thread_data["created_at"])
                    if thread_data["created_at"]
                    else datetime.datetime.now(datetime.timezone.utc)
                ),
                updated_at=thread_data["updated_at"]
                if isinstance(thread_data["updated_at"], datetime.datetime)
                else (
                    datetime.datetime.fromisoformat(thread_data["updated_at"])
                    if thread_data["updated_at"]
                    else datetime.datetime.now(datetime.timezone.utc)
                ),
                project=thread_data.get("project"),
                workspace=thread_data.get("workspace"),
                tool_version=thread_data.get("tool_version"),
                import_date=thread_data.get("import_date")
                if thread_data.get("import_date")
                else None,
                metadata=_deserialize_metadata_safe(
                    self.client, thread_data.get("metadata", "{}")
                ),
            )

            # Get messages
            messages_query = COMMON_QUERIES["find_thread_messages"]
            messages_result = self.conn.execute(
                messages_query, {"thread_id": thread_id}
            )

            messages: List[MessageNode] = []
            assert isinstance(messages_result, kuzu.QueryResult), (
                "messages_result is not a QueryResult"
            )
            try:
                while messages_result.has_next():
                    msg_row = messages_result.get_next()
                    msg_data = msg_row[0]  # type: ignore

                    message_node = MessageNode(
                        id=msg_data["id"],
                        content=msg_data["content"],
                        role=msg_data["role"],
                        order_index=msg_data["order_index"],
                        timestamp=msg_data["timestamp"]
                        if isinstance(msg_data["timestamp"], datetime.datetime)
                        else (
                            datetime.datetime.fromisoformat(msg_data["timestamp"])
                            if msg_data["timestamp"]
                            else None
                        ),
                        token_count=msg_data["token_count"],
                        created_at=msg_data["created_at"]
                        if isinstance(msg_data["created_at"], datetime.datetime)
                        else (
                            datetime.datetime.fromisoformat(msg_data["created_at"])
                            if msg_data["created_at"]
                            else datetime.datetime.now(datetime.timezone.utc)
                        ),
                        updated_at=msg_data["updated_at"]
                        if isinstance(msg_data["updated_at"], datetime.datetime)
                        else (
                            datetime.datetime.fromisoformat(msg_data["updated_at"])
                            if msg_data["updated_at"]
                            else datetime.datetime.now(datetime.timezone.utc)
                        ),
                        metadata=_deserialize_metadata_safe(
                            self.client, msg_data.get("metadata", "{}")
                        ),
                    )
                    messages.append(message_node)
            finally:
                _close_result(messages_result)

            # Get related memories (simplified for now)
            related_memories: List[MemoryNode] = []

            # Query for memories that were extracted from this thread
            memories_query = """
                MATCH (t:Thread {thread_id: $thread_id})-[:COMPACTS_TO]->(m:Memory)
                RETURN m
                ORDER BY m.importance DESC, m.created_at DESC
                LIMIT 10
            """

            try:
                memories_result = self.conn.execute(
                    memories_query, {"thread_id": thread_id}
                )
                assert isinstance(memories_result, kuzu.QueryResult), (
                    "memories_result is not a QueryResult"
                )
                try:
                    while memories_result.has_next():
                        memory_row = memories_result.get_next()  # type: ignore
                        memory_data = memory_row[0]  # type: ignore

                        embedding_value = memory_data.get("embedding")
                        source_range_value = memory_data.get("source_range")

                        memory_node = MemoryNode(
                            id=memory_data["id"],
                            content=memory_data["content"],
                            title=memory_data["title"],
                            importance=memory_data["importance"],
                            confidence=memory_data["confidence"],
                            embedding=list(embedding_value) if embedding_value else [],
                            source_range=json.loads(source_range_value)
                            if source_range_value
                            else None,
                            source=memory_data["source"],
                            created_at=self.client._safe_parse_datetime(  # type: ignore[attr-defined]
                                memory_data["created_at"]
                            )
                            or datetime.datetime.now(datetime.timezone.utc),
                            updated_at=self.client._safe_parse_datetime(  # type: ignore[attr-defined]
                                memory_data["updated_at"]
                            )
                            or datetime.datetime.now(datetime.timezone.utc),
                            metadata=self.client._deserialize_metadata(  # type: ignore[attr-defined]
                                memory_data.get("metadata", "{}")
                            ),
                            semantic_field=f"{memory_data['title']},\n{memory_data['content']}",
                            last_reindexed_at=self.client._safe_parse_datetime(  # type: ignore[attr-defined]
                                memory_data["last_reindexed_at"]
                            ),
                            reindex_needed=memory_data["reindex_needed"],
                            # Knowledge Agent fields (v0.6)
                            unit_type=memory_data.get("unit_type", "fact"),
                            is_latest=memory_data.get("is_latest", True),
                            version=memory_data.get("version", 1),
                            is_crystal=memory_data.get("is_crystal", False),
                            crystal_title=memory_data.get("crystal_title"),
                            source_unit_count=memory_data.get("source_unit_count"),
                            extraction_method=memory_data.get("extraction_method", "manual"),
                        )
                        related_memories.append(memory_node)
                finally:
                    _close_result(memories_result)

            except Exception as e:
                logger.warning(
                    "Failed to fetch related memories",
                    thread_id=thread_id,
                    error=str(e),
                )

            # Get entities mentioned in memories related to this thread
            entities: List[str] = []

            entities_query = """
                MATCH (t:Thread {thread_id: $thread_id})-[:COMPACTS_TO]->(m:Memory)-[:MENTIONS]->(e:Entity)
                RETURN DISTINCT e.name
                ORDER BY e.name
                LIMIT 20
            """

            try:
                entities_result = self.conn.execute(
                    entities_query, {"thread_id": thread_id}
                )
                assert isinstance(entities_result, kuzu.QueryResult), (
                    "entities_result is not a QueryResult"
                )
                try:
                    while entities_result.has_next():
                        entity_row = entities_result.get_next()
                        entity_name = entity_row[0]  # type: ignore
                        entities.append(entity_name)
                finally:
                    _close_result(entities_result)

            except Exception as e:
                logger.warning(
                    "Failed to fetch related entities",
                    thread_id=thread_id,
                    error=str(e),
                )

            return ThreadFetchResponse(
                thread=thread_node,
                messages=messages,
                related_memories=related_memories,
                entities=entities,
                total_messages=len(messages),
                total_tokens=sum(m.token_count or 0 for m in messages),
            )

        except Exception as e:
            logger.error("Failed to fetch thread", thread_id=thread_id, error=str(e))
            raise

    async def update_thread_summary(self, thread_id: str, summary: str) -> None:
        """Update thread summary and embedding."""
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            with self.client.transaction(
                checkpoint=True,
                reason=f"update_thread_summary:{thread_id}",
            ):
                update_query = """
                    MATCH (t:Thread {id: $thread_id})
                    SET t.summary = $summary, t.updated_at = $updated_at
                """

                self.conn.execute(
                    update_query,
                    {
                        "thread_id": thread_id,
                        "summary": summary,
                        "updated_at": datetime.datetime.now(datetime.timezone.utc),
                    },
                )

        except Exception as e:
            logger.error(
                "Failed to update thread summary", thread_id=thread_id, error=str(e)
            )
            raise

    async def list_threads(
        self,
        limit: int = 20,
        offset: int = 0,
        source: Optional[str] = None,
        created_after: Optional[datetime.datetime] = None,
        order_by: str = "created_at",
        order_desc: bool = True,
    ) -> List[Dict[str, Any]]:
        """List threads with filtering and pagination (lightweight projection).

        Returns list of dicts: {thread_id, title, source, import_date, last_activity, message_count, participants}
        Avoids hydrating messages.
        """
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            logger.debug(f"Params: limit={limit}, offset={offset}, source={source}")

            conditions: List[str] = []
            params: dict[str, Any] = build_kuzu_params(limit=limit, offset=offset)  # type: ignore[assignment]

            if source:
                conditions.append("t.source = $source")
                params.update(build_kuzu_params(source=source))  # type: ignore[assignment]

            if created_after:
                conditions.append("t.created_at >= $created_after")
                params.update(build_kuzu_params(created_after=created_after))  # type: ignore[assignment]

            where_clause = " AND ".join(conditions) if conditions else "true"
            order_direction = "DESC" if order_desc else "ASC"

            # Compute last_activity as MAX message timestamp if available, else t.updated_at/import_date
            # message_count from denormalized t.message_count if present, else COUNT(m)
            query = f"""
MATCH (t:Thread)
WHERE {where_clause}
OPTIONAL MATCH (t)-[:CONTAINS]->(m:Message)
WITH t,
     COALESCE(MAX(m.timestamp), t.updated_at, t.import_date, t.created_at) AS last_activity_calc,
     COALESCE(t.message_count, COUNT(m)) AS msg_count
RETURN t.thread_id AS thread_id,
       t.title AS title,
       t.source AS source,
       t.import_date AS import_date,
       last_activity_calc AS last_activity,
       msg_count AS message_count,
       t.participants AS participants
ORDER BY last_activity_calc {order_direction}
SKIP $offset LIMIT $limit"""

            # logger.debug(f"Executing query: {query}")
            # logger.debug(f"With params: {params}")

            result = self.conn.execute(query, params)  # type: ignore[arg-type]
            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

            items: List[Dict[str, Any]] = []
            try:
                while result.has_next():
                    row = result.get_next()  # type: ignore
                    item: Dict[str, Any] = {
                        "thread_id": row[0],  # type: ignore
                        "title": row[1],  # type: ignore
                        "source": row[2],  # type: ignore
                        "import_date": self.client._safe_parse_datetime(row[3]),  # type: ignore[attr-defined]
                        "last_activity": self.client._safe_parse_datetime(row[4]),  # type: ignore[attr-defined]
                        "message_count": int(row[5] or 0),  # type: ignore
                        "participants": row[6] or [],  # type: ignore
                    }
                    items.append(item)
            finally:
                close_fn = getattr(result, "close", None)
                if callable(close_fn):
                    close_fn()
            return items

        except Exception as e:
            logger.error("Failed to list threads", error=str(e))
            raise

    async def count_threads(self, source: Optional[str] = None) -> int:
        """Count threads matching the filter criteria."""
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            if source:
                query = """
                MATCH (t:Thread) 
                WHERE t.source = $source
                RETURN COUNT(t) as count;
                """
                result = self.conn.execute(query, {"source": source})
            else:
                query = """
                MATCH (t:Thread) 
                RETURN COUNT(t) as count;
                """
                result = self.conn.execute(query)

            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"
            try:
                if not result.has_next():
                    return 0

                return result.get_next()[0]  # type: ignore
            finally:
                close_fn = getattr(result, "close", None)
                if callable(close_fn):
                    close_fn()
        except Exception as e:
            logger.error(f"Failed to count threads: {e}")
            return 0

    async def delete_thread(self, thread_id: str) -> bool:
        """Delete a thread and all its messages."""
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            with self.client.transaction(
                checkpoint=True,
                reason=f"delete_thread:{thread_id}",
            ):
                # First delete all messages and their relationships
                delete_messages_query = """
                    MATCH (t:Thread {thread_id: $thread_id})-[:CONTAINS]->(m:Message)
                    DETACH DELETE m
                """
                self.conn.execute(delete_messages_query, {"thread_id": thread_id})

                # Then delete the thread and its relationships
                delete_thread_query = """
                    MATCH (t:Thread {thread_id: $thread_id})
                    DETACH DELETE t
                """
                self.conn.execute(delete_thread_query, {"thread_id": thread_id})

            # Sync deletion to search index (non-blocking, best-effort)
            try:
                await delete_thread_messages_from_index(thread_id)
            except Exception as sync_error:
                logger.debug(
                    "Search index delete sync skipped for thread",
                    thread_id=thread_id,
                    error=str(sync_error),
                )

            return True

        except Exception as e:
            logger.error("Failed to delete thread", thread_id=thread_id, error=str(e))
            raise

    async def _update_thread_denormalized_fields(self, thread_id: str) -> None:
        """Update denormalized fields (message_count, last_activity) on Thread node."""
        self.client._ensure_initialized()  # type: ignore[attr-defined]
        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            query = """
MATCH (t:Thread {thread_id: $thread_id})
OPTIONAL MATCH (t)-[:CONTAINS]->(m:Message)
WITH t, COUNT(m) AS msg_count, MAX(m.timestamp) AS last_msg
SET t.message_count = msg_count,
    t.updated_at = COALESCE(last_msg, t.updated_at)
"""
            with self.client.transaction(
                checkpoint=True,
                reason=f"update_thread_denorm:{thread_id}",
            ):
                self.conn.execute(query, {"thread_id": thread_id})
        except Exception as e:
            logger.warning(
                "Failed to update denormalized fields",
                thread_id=thread_id,
                error=str(e),
            )

    async def search_threads(
        self,
        query_text: str,
        search_mode: str = "full",
        limit: int = 10,
        source: Optional[str] = None,
        created_after: Optional[datetime.datetime] = None,
        participants: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """Search threads with BM25 full-text search.

        Args:
            query_text: Search query string
            search_mode: "suggestions" (title/summary only) or "full" (includes messages)
            limit: Maximum results to return
            source: Filter by thread source
            created_after: Filter by creation date
            participants: Filter by participants

        Returns:
            List of thread search results with matched messages for "full" mode
        """
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            results_by_thread: Dict[str, Dict[str, Any]] = {}
            message_matches: Dict[str, List[Dict[str, Any]]] = {}

            if search_mode == "full":
                # Search messages with BM25 FTS
                try:
                    message_query = """
                        CALL QUERY_FTS_INDEX(
                            'Message',
                            'message_content_fts',
                            $query_text
                        )
                        RETURN node as m, score
                        ORDER BY score DESC
                        LIMIT 1000
                    """

                    params = build_kuzu_params(query_text=query_text)  # type: ignore[assignment]
                    message_result = self.conn.execute(message_query, params)  # type: ignore[arg-type]
                    assert isinstance(message_result, kuzu.QueryResult)
                    try:
                        # Group messages by thread and collect matches
                        while message_result.has_next():
                            row = message_result.get_next()  # type: ignore
                            msg_data = row[0]  # type: ignore
                            score = float(row[1])  # type: ignore

                            # Get thread for this message
                            thread_query = """
                            MATCH (t:Thread)-[:CONTAINS]->(m:Message)
                            WHERE m.id = $message_id
                            RETURN t, m.order_index as msg_index
                        """
                            thread_params = build_kuzu_params(message_id=msg_data["id"])  # type: ignore[assignment]
                            thread_result = self.conn.execute(thread_query, thread_params)  # type: ignore[arg-type]

                            try:
                                if thread_result.has_next():  # type: ignore
                                    thread_row = thread_result.get_next()  # type: ignore
                                    thread_data = thread_row[0]  # type: ignore
                                    msg_index = int(thread_row[1])  # type: ignore
                                    thread_id = thread_data["thread_id"]  # type: ignore

                                    # Create snippet (200 chars centered on match)
                                    content = msg_data["content"] or ""
                                    snippet_length = 200
                                    if len(content) > snippet_length:
                                        # Try to center on query terms
                                        query_lower = query_text.lower()
                                        content_lower = content.lower()
                                        pos = content_lower.find(
                                            query_lower.split()[0] if query_lower else ""
                                        )
                                        if pos >= 0:
                                            start = max(0, pos - snippet_length // 2)
                                            end = min(len(content), start + snippet_length)
                                            snippet = (
                                                ("..." if start > 0 else "")
                                                + content[start:end]
                                                + ("..." if end < len(content) else "")
                                            )
                                        else:
                                            snippet = content[:snippet_length] + "..."
                                    else:
                                        snippet = content

                                    match_info = {
                                        "message_id": msg_data["id"],
                                        "message_index": msg_index,
                                        "role": msg_data["role"],
                                        "snippet": snippet,
                                        "match_score": score,
                                    }

                                    if thread_id not in message_matches:
                                        message_matches[thread_id] = []
                                        results_by_thread[thread_id] = {
                                            "thread_data": thread_data,
                                            "message_score": 0.0,
                                            "matched_messages": [],
                                        }

                                    message_matches[thread_id].append(match_info)
                                    results_by_thread[thread_id]["message_score"] += score
                            finally:
                                _close_result(thread_result)
                    finally:
                        _close_result(message_result)

                except Exception as fts_error:
                    # FTS index might not exist or query failed - log and continue with title/summary search
                    logger.warning(
                        "Message FTS search failed, falling back to title/summary only",
                        error=str(fts_error),
                        query=query_text,
                    )

            # Search thread titles and summaries
            thread_title_matches: Dict[str, float] = {}
            thread_summary_matches: Dict[str, float] = {}

            # Simple text matching for title/summary (FTS index on Thread not required for v1)
            all_threads_query = """
                MATCH (t:Thread)
                RETURN t
                ORDER BY t.updated_at DESC
            """

            all_threads = self.conn.execute(all_threads_query)
            assert isinstance(all_threads, kuzu.QueryResult)

            query_terms = query_text.lower().split()
            try:
                while all_threads.has_next():
                    row = all_threads.get_next()  # type: ignore
                    thread_data = row[0]  # type: ignore
                    thread_id = thread_data["thread_id"]

                    title = (thread_data.get("title") or "").lower()
                    summary = (thread_data.get("summary") or "").lower()

                    # Simple term matching score
                    title_score = sum(2.0 for term in query_terms if term in title)
                    summary_score = sum(1.5 for term in query_terms if term in summary)

                    if title_score > 0:
                        thread_title_matches[thread_id] = title_score
                    if summary_score > 0:
                        thread_summary_matches[thread_id] = summary_score

                    if thread_id not in results_by_thread and (
                        title_score > 0 or summary_score > 0
                    ):
                        results_by_thread[thread_id] = {
                            "thread_data": thread_data,
                            "message_score": 0.0,
                            "matched_messages": [],
                        }
            finally:
                _close_result(all_threads)

            # Combine scores and prepare final results
            final_results: List[Dict[str, Any]] = []
            for thread_id, data in results_by_thread.items():
                thread_data = data["thread_data"]

                # Calculate combined relevance score
                title_score = thread_title_matches.get(thread_id, 0.0)
                summary_score = thread_summary_matches.get(thread_id, 0.0)
                message_score = data["message_score"]

                relevance_score = (
                    title_score
                    + summary_score
                    + (message_score if search_mode == "full" else 0.0)
                )

                # Get ALL matched messages (no limit - UI will show top 2 in list, all in detail)
                matched_messages = (
                    message_matches.get(thread_id, []) if search_mode == "full" else []
                )

                # Parse datetime and convert to ISO string for JSON serialization
                last_activity_dt = self.client._safe_parse_datetime(  # type: ignore[attr-defined]
                    thread_data["updated_at"]
                )
                last_activity_str: str = (  # type: ignore[assignment, union-attr]
                    last_activity_dt.isoformat() if last_activity_dt else ""  # type: ignore[union-attr]
                )

                final_results.append(
                    {
                        "thread_id": thread_data["thread_id"],
                        "id": thread_data["id"],
                        "title": thread_data["title"],
                        "summary": thread_data["summary"],
                        "message_count": thread_data["message_count"],
                        "last_activity": last_activity_str,
                        "source": thread_data.get("source"),
                        "participants": thread_data.get("participants", []),
                        "matched_messages": matched_messages,
                        "total_matches": len(message_matches.get(thread_id, [])),
                        "relevance_score": relevance_score,
                    }
                )

            # Sort by relevance score, then by last_activity (string comparison works for ISO format)
            final_results.sort(
                key=lambda x: (x["relevance_score"], x["last_activity"] or ""),
                reverse=True,
            )

            return final_results[:limit]

        except Exception as e:
            logger.error(
                "Failed to search threads",
                error=str(e),
                query=query_text,
                mode=search_mode,
            )
            return []

    async def get_all_thread_summaries(self) -> List[Dict[str, str]]:
        """Fetch lightweight thread summaries for autocomplete.

        Returns list of {id, thread_id, title, summary} for UI suggestions.
        """
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            query = """
                MATCH (t:Thread)
                RETURN t.id as id,
                       t.thread_id as thread_id,
                       t.title as title,
                       t.summary as summary,
                       t.updated_at as last_activity
                ORDER BY t.updated_at DESC
            """

            result = self.conn.execute(query)
            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

            summaries: List[Dict[str, str]] = []
            try:
                while result.has_next():
                    row = result.get_next()  # type: ignore
                    summaries.append(
                        {
                            "id": row[0],  # type: ignore
                            "thread_id": row[1],  # type: ignore
                            "title": row[2] or "",  # type: ignore
                            "summary": row[3] or "",  # type: ignore
                            "last_activity": str(row[4]) if row[4] else "",  # type: ignore
                        }
                    )
            finally:
                _close_result(result)

            logger.info(f"Fetched {len(summaries)} thread summaries for autocomplete")
            return summaries

        except Exception as e:
            logger.error("Failed to fetch thread summaries", error=str(e))
            return []
