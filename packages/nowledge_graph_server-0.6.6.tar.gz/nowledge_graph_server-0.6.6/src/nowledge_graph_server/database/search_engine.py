"""
Clean Kuzu Search Engine

Three focused search strategies:
1. Memory Hybrid: Vector + FTS over memories
2. Community Mediated: Community FTS → connected memories via entities
3. LLM Entity Mediated: LLM extract entities → Entity FTS → connected memories
"""

import asyncio
import datetime
import json
from typing import Any, List, Optional

import real_ladybug as kuzu
import structlog
from json_repair import repair_json

from nowledge_graph_server.config import get_settings
from nowledge_graph_server.database.base_client import KuzuBaseClient
from nowledge_graph_server.database.result_utils import iter_rows
from nowledge_graph_server.models.memory import MemorySearchResult
from nowledge_graph_server.services.embedding import EmbeddingService
from nowledge_graph_server.services.local_llm import get_local_llm_service
from nowledge_graph_server.services.memory_decay import compute_decay_score, blend_with_semantic_score
from nowledge_graph_server.models.graph import EntityNode, NodeType, MemoryNode
from nowledge_graph_server.database.temporal_intent import (
    extract_temporal_intent,
    compute_temporal_boost,
    build_temporal_boost_explanation,
)
from .search_engine_utils import (
    COMMUNITY_FTS_QUERY,
    FTS_QUERY_MEMORY,
    VECTOR_QUERY_MEMORY,
    _apply_filters,
    _build_memory_node,
    _calculate_strategy_weights,
    _deduplicate_results,
    _extract_entities_llm,
    _fuse_hybrid_results,
    _fuse_vector_fts_fast,
    _process_advanced_query_strategies,
    _search_by_labels,
    STOP_WORDS,
)
from .search_strategies import (
    memory_hybrid_strategy,
    community_strategy,
    entity_strategy,
    entity_strategy_fast,
    community_strategy_fast,
)

logger = structlog.get_logger(__name__)


class KuzuSearchEngine:
    """Clean, focused search engine with 3 core strategies."""

    def __init__(self, client: KuzuBaseClient):
        self.client = client

    @property
    def conn(self):
        """Access database connection through client."""
        return self.client.conn

    def _apply_decay_scoring(
        self,
        results: List[MemorySearchResult],
        search_context: Optional[dict[str, Any]] = None,
    ) -> List[MemorySearchResult]:
        """
        Apply decay scoring to search results.

        Computes decay score for each memory based on recency + frequency,
        then blends with semantic similarity score (15% decay weight).
        Also appends decay/temporal factors to relevance_reason for UI display.

        Args:
            results: Search results with semantic scores
            search_context: Optional search context containing temporal_intent (deep mode)

        Returns:
            Results with decay-adjusted scores, sorted by final score
        """
        if not results:
            return results

        now = datetime.datetime.now(datetime.timezone.utc)

        # Extract temporal intent from search context (deep mode only)
        temporal_intent = None
        if search_context:
            temporal_intent = search_context.get("temporal_intent")

        for result in results:
            if not result.memory:
                continue

            # Get decay-related fields from memory
            last_accessed_at = getattr(result.memory, "last_accessed_at", None)
            access_count = getattr(result.memory, "access_count", 0) or 0
            importance = getattr(result.memory, "importance", 0.5) or 0.5
            appearances = getattr(result.memory, "appearances", 0) or 0
            clicks = getattr(result.memory, "clicks", 0) or 0

            # Get temporal fields from memory (optional)
            temporal_type = getattr(result.memory, "temporal_type", None)
            event_start = getattr(result.memory, "event_start", None)
            event_end = getattr(result.memory, "event_end", None)
            temporal_precision = getattr(result.memory, "temporal_precision", None)
            temporal_context = getattr(result.memory, "temporal_context", None)

            # Compute decay score
            decay_score = compute_decay_score(
                last_accessed_at=last_accessed_at,
                access_count=access_count,
                importance=importance,
                now=now,
            )

            # Store original semantic score for debugging
            original_score = result.similarity_score

            # Compute temporal boost (query intent + event recency)
            temporal_boost = compute_temporal_boost(
                result.memory, now, temporal_intent
            )

            # Blend semantic score with decay score and temporal boost
            if temporal_boost > 0:
                # Rebalance weights when temporal boost applies
                result.similarity_score = (
                    original_score * 0.70 +  # Semantic (reduced from 0.85)
                    decay_score * 0.15 +      # Decay (same)
                    temporal_boost             # Temporal (0.0-0.15)
                )
            else:
                # No temporal boost - original formula
                result.similarity_score = blend_with_semantic_score(
                    semantic_score=original_score,
                    decay_score=decay_score,
                )

            # Calculate days since last access
            days_since = None
            if last_accessed_at:
                if last_accessed_at.tzinfo is None:
                    last_accessed_at = last_accessed_at.replace(tzinfo=datetime.timezone.utc)
                days_since = (now - last_accessed_at).total_seconds() / 86400

            # Calculate CTR if we have appearances
            ctr = (clicks / appearances) if appearances > 0 else None

            # Build decay factor string for relevance_reason
            decay_factors = []

            # Recency factor
            if days_since is not None:
                if days_since < 1:
                    decay_factors.append("recent:<1d")
                elif days_since < 7:
                    decay_factors.append(f"recent:{int(days_since)}d")
                elif days_since < 30:
                    decay_factors.append(f"recent:{int(days_since/7)}w")
                else:
                    decay_factors.append(f"recent:{int(days_since/30)}mo")

            # Frequency factor
            if access_count > 0:
                decay_factors.append(f"accesses:{access_count}")

            # CTR factor (if meaningful)
            if ctr is not None and appearances >= 3:
                ctr_pct = int(ctr * 100)
                decay_factors.append(f"ctr:{ctr_pct}%")

            # Importance factor
            if importance > 0.7:
                decay_factors.append(f"imp:high")
            elif importance < 0.3:
                decay_factors.append(f"imp:low")

            # Build temporal factor string
            temporal_factors = []
            if temporal_type and temporal_type != "unknown":
                if event_start:
                    # Format based on precision
                    if temporal_precision == "year":
                        date_str = event_start[:4] if isinstance(event_start, str) else str(event_start.year)
                    elif temporal_precision == "month":
                        date_str = event_start[:7] if isinstance(event_start, str) else f"{event_start.year}-{event_start.month:02d}"
                    else:
                        date_str = str(event_start)[:10] if isinstance(event_start, str) else event_start.strftime("%Y-%m-%d")

                    if temporal_type == "range" and event_end:
                        end_str = str(event_end)[:4] if temporal_precision == "year" else str(event_end)[:10]
                        temporal_factors.append(f"time:{date_str}-{end_str}")
                    else:
                        temporal_factors.append(f"time:{date_str}")

            if temporal_context and temporal_context != "timeless":
                temporal_factors.append(f"ctx:{temporal_context}")

            # Append factors to relevance_reason
            existing_reason = result.relevance_reason or ""
            factor_parts = []

            if decay_factors:
                factor_parts.append(f"decay[{','.join(decay_factors)}]")

            if temporal_factors:
                factor_parts.append(f"temporal[{','.join(temporal_factors)}]")

            # Add temporal boost indicator with detailed explanation
            if temporal_boost > 0:
                boost_pct = int(temporal_boost * 100 / 0.15)  # Convert to percentage of max boost

                # Build detailed boost explanation based on temporal intent
                boost_explanation = build_temporal_boost_explanation(
                    temporal_intent, temporal_boost, event_start, temporal_context
                )

                if boost_explanation:
                    factor_parts.append(f"query_match[{boost_explanation}]")
                else:
                    # Fallback: generic event recency boost
                    factor_parts.append(f"event_recency_boost:{boost_pct}%")

            if factor_parts:
                factor_str = " | " + " ".join(factor_parts)
                result.relevance_reason = existing_reason + factor_str

            # Enhanced logging with all factors
            logger.info(
                "Applied decay+temporal scoring",
                memory_id=result.memory.id,
                title=result.memory.title[:30] if result.memory.title else None,
                original_score=round(original_score, 3),
                decay_score=round(decay_score, 3),
                temporal_boost=round(temporal_boost, 3) if temporal_boost > 0 else None,
                final_score=round(result.similarity_score, 3),
                days_since_access=round(days_since, 1) if days_since else None,
                access_count=access_count,
                appearances=appearances,
                clicks=clicks,
                ctr=round(ctr, 2) if ctr else None,
                importance=round(importance, 2),
                temporal_type=temporal_type,
                event_start=str(event_start) if event_start else None,
                temporal_context=temporal_context,
            )

        # Re-sort by final score
        results.sort(key=lambda r: r.similarity_score, reverse=True)

        return results

    async def _track_appearances(self, results: List[MemorySearchResult]) -> None:
        """
        Track that memories appeared in search results (batch update).

        NOTE: This method is deprecated. Appearance tracking is now handled in the
        API layer (memories.py) where we have access to KuzuClient with memory_repo.
        Search engine only has KuzuBaseClient which doesn't have memory_repo.

        Keeping this method as no-op for backwards compatibility.

        Args:
            results: Search results to track
        """
        # Tracking moved to API layer - this is now a no-op
        pass

    async def search_memories(
        self,
        embedding_service: EmbeddingService,
        query_text: str,
        limit: int = 10,
        vector_threshold: float = 0.0,
        filters: dict[str, Any] | None = None,
        mode: str = "deep",
    ) -> List[MemorySearchResult]:
        """
        Main search method combining 3 strategies with post-filtering support:
        1. Memory hybrid (vector + FTS)
        2. Community mediated (if communities have ai_summary)
        3. LLM entity mediated

        Args:
            embedding_service: Service for generating embeddings
            query_text: Search query text
            limit: Final number of results to return
            vector_threshold: Minimum similarity threshold for vector search
            filters: Optional filters to apply
                (importance_min, labels, date ranges, etc.)
        """
        if not query_text.strip():
            return []

        search_limit = (
            (100 if filters else limit * 2)
            if mode == "fast"
            else (200 if filters else limit * 2)
        )

        # Initialize graph traversal tracking
        graph_traversal_stats = {
            "entities_traversed": 0,
            "relationships_traversed": 0,
            "communities_analyzed": 0,
        }

        # For fast mode, skip LLM-based context and HyDE; use simple default weights
        if mode == "fast":
            search_context = {
                "mode": mode,
                "intent": "Normal",
                "specificity": "specific" if len(query_text.split()) <= 2 else "broad",
                "is_question": False,
                "key_terms": [],
                "weights": {"vector": 0.8, "fts": 0.2},
                "query_text": query_text,
                "advanced": {
                    "use_hyde": False,
                    "hyde_query": None,
                    "label_search_enabled": True,
                    "potential_labels": [],
                },
            }
        else:
            # Detect search intent and semantic context for adaptive strategy weighting
            search_context = await self._analyze_search_context(query_text)
            # Add query text to context for content validation
            search_context["query_text"] = query_text

        # Initialize lifecycle debug report accumulator
        try:
            search_context.setdefault(
                "debug_report",
                {
                    "query": query_text,
                    "mode": mode,
                    "events": [],
                    "intent": {},
                    "weights": {},
                    "samples": {},
                },
            )
            search_context["debug_report"]["events"].append(
                {"stage": "start", "timestamp": datetime.datetime.now().isoformat()}
            )
        except Exception:
            pass

        # Store context for API access (for rich user explanations)
        self._last_search_context = search_context

        logger.debug(
            "🔍 Starting unified search",
            query=query_text,
            limit=limit,
            search_limit=search_limit,
            search_context=search_context,
            filters=filters or {},
        )

        try:
            if (
                mode == "fast"
            ):  # run only memory_hybrid sub-steps (vector + FTS), fuse quickly
                # Run a trimmed version of _memory_hybrid_strategy without HyDE branching
                # Adding entity_strategy to the fast mode
                # Reuse its internals by calling it and then short-circuiting fusion path to fast combiner
                effective_query = query_text
                logger.debug(f"calling embedding service for query: {effective_query}")
                # Use "query" prefix when searching (for search queries vs documents)
                query_embedding = await embedding_service.embed_text(
                    effective_query, prefix="query"
                )

                vector_query = VECTOR_QUERY_MEMORY
                if not self.conn:
                    return []

                vector_result = self.conn.execute(
                    vector_query,
                    {
                        "query_embedding": query_embedding,
                        "limit": search_limit,
                    },
                )

                logger.debug(
                    "Vector query executed",
                    query_embedding_dim=len(query_embedding),
                    query_embedding_first_5=query_embedding[:5],
                    limit=search_limit,
                    result_type=type(vector_result).__name__,
                )

                vector_memories = []
                if isinstance(vector_result, list) and vector_result:
                    vector_result = vector_result[0]
                if isinstance(vector_result, kuzu.QueryResult) and hasattr(
                    vector_result, "has_next"
                ):
                    row_count = 0
                    for row in iter_rows(vector_result):
                        row_count += 1
                        memory_data = row[0]  # type: ignore
                        distance = float(row[1])  # type: ignore

                        if row_count == 1:
                            # Log first result for debugging
                            logger.debug(
                                "First vector search result",
                                memory_id=memory_data.get("id", "unknown"),
                                distance=distance,
                                has_embedding=memory_data.get("embedding") is not None,
                                embedding_dim=len(memory_data.get("embedding", []))
                                if memory_data.get("embedding")
                                else 0,
                            )

                        # Convert cosine distance to cosine similarity
                        # KuzuDB returns cosine distance, formula: distance = 1 - cosine_similarity
                        # Therefore: cosine_similarity = 1 - distance
                        #
                        # Note: Modern embedding models often produce high cosine similarities,
                        # typically distributing in 0.7-1.0 range (expected behavior)
                        # What matters is the relative order, not absolute values
                        similarity_score = max(0.0, 1.0 - distance)
                        if similarity_score >= vector_threshold:
                            vector_memories.append(
                                (memory_data, similarity_score, "vector")
                            )

                    logger.debug(
                        "Vector search completed",
                        total_rows=row_count,
                        passed_threshold=len(vector_memories),
                        threshold=vector_threshold,
                    )

                fts_query = FTS_QUERY_MEMORY
                fts_result = self.conn.execute(
                    fts_query, {"text_query": query_text, "limit": search_limit}
                )
                fts_memories = []
                if isinstance(fts_result, list) and fts_result:
                    fts_result = fts_result[0]
                if isinstance(fts_result, kuzu.QueryResult) and hasattr(
                    fts_result, "has_next"
                ):
                    for row in iter_rows(fts_result):
                        memory_data = row[0]  # type: ignore
                        score = float(row[1])  # type: ignore
                        fts_memories.append((memory_data, score, "fts"))

                # Label-based search
                label_memories = []
                if search_context and search_context.get("advanced", {}).get(
                    "label_search_enabled"
                ):
                    # fast construct potential labels from query text
                    # split by spaces, commas, and other delimiters, and remove stop words, and string_length > 3, considering CJK characters as 2 characters
                    potential_labels = [
                        label.strip()
                        for label in query_text.split()
                        if label.strip()
                        and label.strip() not in STOP_WORDS
                        and len(label.strip()) > 3
                    ]
                    label_memories = await _search_by_labels(
                        self,  # type: ignore
                        potential_labels,
                        limit,
                    )
                    logger.debug(
                        f"🏷️ Label search returned {len(label_memories)} results"
                    )

                # Entity-based search (fast mode - no LLM)
                entity_memories = await self._entity_strategy_fast(
                    query_text, search_limit, graph_traversal_stats
                )
                logger.debug(
                    f"🔗 Entity search returned {len(entity_memories)} results"
                )

                # Community-based search (fast mode - no LLM)
                community_memories = await self._community_strategy_fast(
                    query_text, search_limit, graph_traversal_stats
                )
                logger.debug(
                    f"👥 Community search returned {len(community_memories)} results"
                )

                fast_results = await _fuse_hybrid_results(
                    self,  # type: ignore
                    vector_memories,
                    fts_memories,
                    limit,
                    label_memories,
                    search_context,
                    entity_memories,
                    community_memories,
                )
                # Apply filters
                filtered = (
                    _apply_filters(self, fast_results, filters)  # type: ignore
                    if filters
                    else fast_results
                )
                pre_decay_results = filtered[:limit]

                # Apply decay scoring (blends decay with semantic scores)
                # Note: Fast mode uses simple search_context without temporal_intent
                final_results = self._apply_decay_scoring(pre_decay_results, search_context)

                # Track appearances for decay model
                await self._track_appearances(final_results)
                #####################################################################################

                return final_results

            # Apply weights to strategy execution - run strategies based on their importance
            weights = search_context.get("weights", {})
            refined_intent = search_context.get("refined_intent", "exploratory_search")

            # Adjust search limits based on weights (higher weight = more results)
            base_limit = search_limit
            memory_limit = max(
                int(base_limit * weights.get("vector", 0.6)), base_limit // 2
            )
            community_limit = max(
                int(base_limit * weights.get("community", 0.2)), base_limit // 4
            )
            entity_limit = max(
                int(base_limit * weights.get("entity", 0.3)), base_limit // 4
            )

            logger.debug(
                f"🎯 Weight-adjusted limits: memory={memory_limit}, community={community_limit}, entity={entity_limit}"
            )

            # Run all strategies but apply weights as score multipliers instead of skipping
            strategies_to_run = [
                self._memory_hybrid_strategy(
                    embedding_service,
                    query_text,
                    memory_limit,
                    vector_threshold,
                    search_context,
                ),
                self._community_strategy(
                    query_text, community_limit, graph_traversal_stats
                ),
                self._entity_strategy(query_text, entity_limit, graph_traversal_stats),
            ]
            strategy_names = ["Memory Hybrid", "Community", "Entity"]

            logger.debug(
                f"🎯 Running all strategies with weight-based score adjustment: "
                f"memory={weights.get('vector', 0.6):.2f}, community={weights.get('community', 0.2):.2f}, entity={weights.get('entity', 0.3):.2f}"
            )

            # Execute all strategies
            strategy_results = await asyncio.gather(
                *strategies_to_run, return_exceptions=True
            )

            # Collect valid results and apply adaptive weight-based score adjustments
            all_results = []

            # IMPROVED: Normalize weights based on strategies that actually returned results
            strategy_weight_mapping = {
                0: max(
                    weights.get("vector", 0.6), weights.get("fts", 0.4)
                ),  # Memory Hybrid (max of vector/fts)
                1: weights.get("community", 0.2),  # Community
                2: weights.get("entity", 0.3),  # Entity
            }

            # Calculate which strategies returned results and normalize weights
            active_strategies = []
            total_active_weight = 0.0

            for i, result in enumerate(strategy_results):
                if isinstance(result, list) and len(result) > 0:
                    active_strategies.append(i)
                    total_active_weight += strategy_weight_mapping.get(i, 1.0)

            # Normalize weights so active strategies sum to reasonable values
            if total_active_weight > 0:
                weight_boost_factor = min(
                    1.2, 1.0 / total_active_weight
                )  # Boost up to 20% when strategies missing
                logger.debug(
                    f"🎯 Active strategies: {active_strategies}, total_weight: {total_active_weight:.2f}, boost: {weight_boost_factor:.2f}"
                )
            else:
                weight_boost_factor = 1.0

            for i, result in enumerate(strategy_results):
                if isinstance(result, Exception):
                    logger.warning(
                        f"Strategy {i + 1} ({strategy_names[i]}) failed",
                        error=str(result),
                    )
                    continue
                if isinstance(result, list):
                    raw_weight = strategy_weight_mapping.get(i, 1.0)
                    # Apply adaptive weight boost when other strategies are missing
                    strategy_weight = min(raw_weight * weight_boost_factor, 1.0)

                    # Apply weight as score multiplier to each result from this strategy
                    weighted_results = []
                    for search_result in result:
                        # Apply weight multiplier to similarity_score
                        original_score = search_result.similarity_score
                        weighted_score = min(
                            original_score * strategy_weight, 1.0
                        )  # Cap at 1.0

                        # Create new result with weighted score
                        weighted_result = MemorySearchResult(
                            memory=search_result.memory,
                            similarity_score=weighted_score,
                            relevance_reason=f"{search_result.relevance_reason} (weight: {strategy_weight:.2f})",
                            related_entities=getattr(
                                search_result, "related_entities", []
                            ),
                        )
                        weighted_results.append(weighted_result)

                        logger.debug(
                            f"🎯 Applied adaptive weight: {strategy_names[i]} "
                            f"memory_id={search_result.memory.id if search_result.memory else 'None'} "
                            f"{original_score:.3f} → {weighted_score:.3f} (×{strategy_weight:.2f}, boosted from {raw_weight:.2f})"
                        )

                    all_results.extend(weighted_results)
                    logger.debug(
                        f"📊 {strategy_names[i]} strategy: {len(weighted_results)} results with weight {strategy_weight:.2f}"
                    )

            # Deduplicate first
            deduplicated_results = _deduplicate_results(self, all_results, search_limit)  # type: ignore

            # Apply filters if provided
            if filters:
                filtered_results = _apply_filters(self, deduplicated_results, filters)  # type: ignore
                logger.debug(
                    f"Filtered {len(deduplicated_results)} → {len(filtered_results)} results"
                )
            else:
                filtered_results = deduplicated_results

            # Apply final limit
            pre_decay_results = filtered_results[:limit]

            # Apply decay scoring (blends decay with semantic scores)
            # Deep mode: search_context includes temporal_intent from LLM analysis
            final_results = self._apply_decay_scoring(pre_decay_results, search_context)

            # Track appearances for decay model
            await self._track_appearances(final_results)

            # Attach graph traversal metadata to results
            for result in final_results:
                if (
                    hasattr(result, "memory")
                    and result.memory
                    and hasattr(result.memory, "metadata")
                ):
                    if not result.memory.metadata:
                        result.memory.metadata = {}
                    result.memory.metadata["graph_traversal"] = graph_traversal_stats

            # Log final score distribution for observability
            if final_results:
                final_scores = [r.similarity_score for r in final_results]
                logger.debug(
                    "🔍 Deep Search completed (see lifecycle report next)",
                    total_results=len(final_results),
                    pre_filter_count=len(deduplicated_results),
                    post_filter_count=len(filtered_results),
                )
            else:
                logger.warning(
                    "🔍 Deep Search completed with no results",
                    pre_filter_count=len(deduplicated_results),
                    post_filter_count=len(filtered_results),
                )

            return final_results

        except Exception as e:
            logger.error("🔍 Search failed", error=str(e))
            return []

    async def _memory_hybrid_strategy(
        self,
        embedding_service: EmbeddingService,
        query_text: str,
        limit: int,
        vector_threshold: float,
        search_context: dict[str, Any] | None = None,
    ) -> list[MemorySearchResult]:
        """Strategy 1: Vector + FTS hybrid over memories with advanced processing."""
        return await memory_hybrid_strategy(
            self, embedding_service, query_text, limit, vector_threshold, search_context
        )

    async def _community_strategy(
        self, query_text: str, limit: int, graph_traversal_stats: dict[str, int]
    ) -> list[MemorySearchResult]:
        """Strategy 2: Community FTS → connected memories via entities."""
        return await community_strategy(self, query_text, limit, graph_traversal_stats)

    async def _entity_strategy(
        self, query_text: str, limit: int, graph_traversal_stats: dict[str, int]
    ) -> list[MemorySearchResult]:
        """Strategy 3: LLM extract entities → Entity FTS → connected memories."""
        return await entity_strategy(self, query_text, limit, graph_traversal_stats)

    async def _entity_strategy_fast(
        self, query_text: str, limit: int, graph_traversal_stats: dict[str, int]
    ) -> list[tuple[Any, float, str]]:
        """Fast entity strategy: Extract entities from query text (no LLM) → Entity FTS → connected memories."""
        return await entity_strategy_fast(self, query_text, limit, graph_traversal_stats)

    async def _community_strategy_fast(
        self, query_text: str, limit: int, graph_traversal_stats: dict[str, int]
    ) -> list[tuple[Any, float, str]]:
        """Fast community strategy: Community FTS → connected memories via entities."""
        return await community_strategy_fast(self, query_text, limit, graph_traversal_stats)

    async def _analyze_search_context(self, query_text: str) -> dict[str, Any]:
        """Analyze search context for heuristic strategy weighting (启发式搜索)."""
        try:
            settings = get_settings()
            logger.debug(
                "Loaded settings for LLM service",
                llm_cache_dir=str(settings.llm_cache_dir),
                llm_cache_only=settings.llm_cache_only,
            )
            llm_service = await get_local_llm_service(
                cache_dir=settings.llm_cache_dir,
                cache_only=settings.llm_cache_only,
            )

            prompt = f"""Classify the query. Respond with JSON only.

fields:
- refined_intent: one of [concept_lookup, factual_query, conceptual_question, relationship_query, exploratory_search]
- is_question: boolean
- key_terms: array (≤3) of tokens that appear verbatim in the query
- confidence: number in [0,1]

Query: {query_text}

JSON:"""
            # Use model defaults for temperature (remote) and tuned defaults for MLX (local)
            # Set operation context for LangFuse tracking
            llm_service._current_operation = "search_context_analysis"  # type: ignore
            response = await llm_service._generate_response(  # type: ignore
                prompt, max_tokens=64, use_thinking=False
            )
            logger.debug(
                "Received response from LLM for search context analysis",
                response=response,
            )
            # Parse LLM JSON response with robust fallbacks
            try:
                repaired_json = repair_json(response.strip())
                parsed = json.loads(repaired_json)

                # Extract with validation
                refined_intent = (parsed.get("refined_intent") or "").strip()
                is_question = bool(parsed.get("is_question", False))
                key_terms = parsed.get("key_terms", []) or []
                confidence = float(parsed.get("confidence", 0.0) or 0.0)
                logger.debug(
                    "Parsed LLM JSON",
                    refined_intent=refined_intent,
                    is_question=is_question,
                    key_terms=key_terms,
                    confidence=f"{confidence:.2f}",
                )
                # Validate refined_intent
                valid_refined = [
                    "concept_lookup",
                    "factual_query",
                    "conceptual_question",
                    "relationship_query",
                    "exploratory_search",
                ]
                if refined_intent not in valid_refined:
                    logger.debug(
                        "Refined intent invalid, defaulting to 'exploratory_search'",
                        received=refined_intent,
                    )
                    refined_intent = "exploratory_search"

                # CRITICAL: Validate key terms against actual query to prevent hallucination
                query_words = query_text.lower().split()
                validated_terms = []
                for term in key_terms:
                    if isinstance(term, str) and term.lower() in query_text.lower():
                        validated_terms.append(term)
                key_terms = validated_terms[:3]  # Limit to 3 validated terms

                logger.debug(
                    "🧠 LLM analysis complete",
                    refined_intent=refined_intent,
                    is_question=is_question,
                    validated_terms=key_terms,
                    confidence=f"{confidence:.2f}",
                )

            except Exception as e:
                # Fallback parsing if JSON fails
                logger.debug(
                    "JSON parsing failed, using fallbacks",
                    error=str(e),
                    response=response,
                )
                refined_intent = "exploratory_search"
                is_question = False
                key_terms = []
                confidence = 0.0

            # Build context with LLM analysis
            # Derive specificity from refined intent (LLM-only)
            specificity = (
                "specific"
                if refined_intent
                in ["concept_lookup", "factual_query", "relationship_query"]
                else "broad"
            )
            context = {
                "refined_intent": refined_intent,
                "is_question": is_question,
                "key_terms": key_terms,
                "confidence": confidence,
                "specificity": specificity,
            }

            # Attach LLM usage metadata for UI (after context is created)
            try:
                if hasattr(llm_service, "get_last_usage"):
                    _usage = llm_service.get_last_usage()  # type: ignore
                    if isinstance(_usage, dict):
                        context["llm_usage"] = dict(_usage)  # type: ignore
            except Exception:
                pass

            logger.debug(
                "Built initial context from LLM analysis",
                context=context,
            )

            # Extract temporal intent from query (deep mode only)
            try:
                temporal_intent = await extract_temporal_intent(query_text, llm_service)
                context["temporal_intent"] = temporal_intent
                logger.debug(
                    "🕐 Temporal intent extracted",
                    has_intent=temporal_intent.get("has_temporal_intent"),
                    temporal_type=temporal_intent.get("temporal_type"),
                    confidence=temporal_intent.get("temporal_confidence"),
                )
            except Exception as e:
                logger.warning("Temporal intent extraction failed", error=str(e))
                context["temporal_intent"] = {
                    "has_temporal_intent": False,
                    "temporal_type": None,
                    "temporal_value": None,
                    "temporal_confidence": 0.0,
                }

            # Validate and add heuristic weights
            context = _calculate_strategy_weights(self, context, query_text)  # type: ignore
            logger.debug("Calculated strategy weights", weights=context.get("weights"))

            # Advanced query processing based on intent
            context = await _process_advanced_query_strategies(
                self,  # type: ignore
                context,
                query_text,
            )
            logger.debug(
                "Processed advanced query strategies", advanced=context.get("advanced")
            )

        except Exception as e:
            logger.warning("Context analysis failed, using defaults", error=str(e))
            return {
                "refined_intent": "exploratory_search",
                "specificity": "broad",
                "is_question": False,
                "key_terms": [],
                "confidence": 0.0,
                "weights": {"vector": 0.7, "fts": 0.3, "entity": 0.3, "community": 0.2},
                "advanced": {
                    "use_hyde": False,
                    "hyde_query": None,
                    "label_search_enabled": False,
                    "potential_labels": [],
                },
            }
        logger.debug(f"🎯 Search context analyzed: '{query_text}' → {context}")
        return context

    def get_last_llm_usage(self) -> dict[str, Any]:
        """Expose last LLM usage metadata collected by the unified service for UI."""
        try:
            settings = get_settings()
            llm_service = asyncio.get_event_loop().run_until_complete(
                get_local_llm_service(
                    cache_dir=settings.llm_cache_dir,
                    cache_only=settings.llm_cache_only,
                )
            )
            if hasattr(llm_service, "get_last_usage"):
                return llm_service.get_last_usage()  # type: ignore
        except Exception:
            pass
        return {
            "used_remote": False,
            "provider": "unknown",
            "model": "",
            "fallback": False,
        }
