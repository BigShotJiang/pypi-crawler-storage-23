"""
Search Strategy Implementations

This module contains the core search strategy implementations extracted from
KuzuSearchEngine to comply with pyarmor free version's 1400-line limit.

Three main strategies:
1. Memory Hybrid: Vector + FTS over memories (deep + fast mode)
2. Community Mediated: Community FTS → connected memories (deep + fast mode)
3. LLM Entity Mediated: Entity extraction → Entity FTS → memories (deep + fast mode)
"""

import datetime
from typing import Any, List

import real_ladybug as kuzu
import structlog

from nowledge_graph_server.models.memory import MemorySearchResult
from nowledge_graph_server.models.graph import EntityNode, NodeType
from nowledge_graph_server.services.embedding import EmbeddingService
from nowledge_graph_server.database.result_utils import iter_rows, managed_result
from .search_engine_utils import (
    COMMUNITY_FTS_QUERY,
    FTS_QUERY_MEMORY,
    VECTOR_QUERY_MEMORY,
    _build_memory_node,
    _extract_entities_llm,
    _fuse_hybrid_results,
    _search_by_labels,
    STOP_WORDS,
)

logger = structlog.get_logger(__name__)


async def memory_hybrid_strategy(
    search_engine: Any,
    embedding_service: EmbeddingService,
    query_text: str,
    limit: int,
    vector_threshold: float,
    search_context: dict[str, Any] | None = None,
) -> list[MemorySearchResult]:
    """Strategy 1: Vector + FTS hybrid over memories with advanced processing."""
    try:
        # Advanced query processing based on context
        effective_query = query_text
        if search_context and search_context.get("advanced", {}).get("use_hyde"):
            hyde_query = search_context["advanced"]["hyde_query"]
            if hyde_query and hyde_query != query_text:
                effective_query = hyde_query
                logger.debug(f"🎯 Using HyDE query for embedding: '{hyde_query}'")

        # Get query embedding (potentially from HyDE)
        logger.debug(f"calling embedding service for query: {effective_query}")
        # Use "query" prefix when searching (for search queries vs documents)
        query_embedding = await embedding_service.embed_text(
            effective_query, prefix="query"
        )

        # Vector search
        vector_query = VECTOR_QUERY_MEMORY

        if not search_engine.conn:
            return []

        vector_result = search_engine.conn.execute(
            vector_query,
            {
                "query_embedding": query_embedding,
                "limit": limit * 2,  # Get more for fusion
            },
        )

        logger.debug(
            "Deep mode: Vector query executed",
            query_embedding_dim=len(query_embedding),
            query_embedding_first_5=query_embedding[:5],
            limit=limit * 2,
            result_type=type(vector_result).__name__,
        )

        result_debug = []

        # Handle result type properly
        if isinstance(vector_result, list) and vector_result:
            vector_result = vector_result[0]
            result_debug.append(vector_result.get_as_df())

        vector_memories = []
        row_count = 0
        if isinstance(vector_result, kuzu.QueryResult) and hasattr(
            vector_result, "has_next"
        ):
            for row in iter_rows(vector_result):
                row_count += 1
                memory_data = row[0]  # type: ignore
                distance = float(row[1])  # type: ignore

                if row_count == 1:
                    # Log first result for debugging
                    logger.debug(
                        "Deep mode: First vector search result",
                        memory_id=memory_data.get("id", "unknown"),
                        distance=distance,
                        has_embedding=memory_data.get("embedding") is not None,
                        embedding_dim=len(memory_data.get("embedding", []))
                        if memory_data.get("embedding")
                        else 0,
                    )

                # Convert cosine distance to cosine similarity
                similarity_score = max(0.0, 1.0 - distance)
                logger.debug(
                    f"🔍 Vector result: memory_id={memory_data.get('id', 'unknown')}, distance={distance:.6f}, similarity={similarity_score:.6f}"
                )
                # Apply threshold check here since we can't do it in the query
                if similarity_score >= vector_threshold:
                    vector_memories.append(
                        (memory_data, similarity_score, "vector")
                    )
                result_debug.append(row)

        logger.debug(
            "Deep mode: Vector search completed",
            total_rows=row_count,
            passed_threshold=len(vector_memories),
            threshold=vector_threshold,
        )

        # FTS search
        fts_query = FTS_QUERY_MEMORY
        result_fts_debug = []

        fts_result = search_engine.conn.execute(
            fts_query, {"text_query": query_text, "limit": limit * 2}
        )
        logger.debug(
            f"🔍 FTS query executed: query='{query_text}', index='memory_semantic_index'"
        )
        logger.debug(f"FTS result using memory_semantic_index: {fts_result}")

        # Handle result type properly
        if isinstance(fts_result, list) and fts_result:
            fts_result = fts_result[0]
            result_fts_debug.append(fts_result.get_as_df())

        fts_memories = []
        if isinstance(fts_result, kuzu.QueryResult) and hasattr(
            fts_result, "has_next"
        ):
            for row in iter_rows(fts_result):
                memory_data = row[0]  # type: ignore
                score = float(row[1])  # type: ignore
                logger.debug(
                    f"🔍 FTS result: memory_id={memory_data.get('id', 'unknown')}, fts_score={score:.6f}"
                )
                fts_memories.append((memory_data, score, "fts"))
                result_fts_debug.append(row)

        # Label-based search if enabled
        label_memories = []
        if search_context and search_context.get("advanced", {}).get(
            "label_search_enabled"
        ):
            label_memories = await _search_by_labels(
                search_engine,
                search_context["advanced"]["potential_labels"],
                limit,
            )
            logger.debug(f"🏷️ Label search returned {len(label_memories)} results")

        # Fuse results (now including potential label results)
        return await _fuse_hybrid_results(
            search_engine,
            vector_memories,
            fts_memories,
            limit,
            label_memories,
            search_context,
        )

    except Exception as e:
        import traceback

        logger.error("Memory hybrid strategy failed", error=str(e))
        logger.debug(traceback.format_exc())
        return []


async def community_strategy(
    search_engine: Any,
    query_text: str,
    limit: int,
    graph_traversal_stats: dict[str, int],
) -> list[MemorySearchResult]:
    """Strategy 2: Community FTS → connected memories via entities."""
    logger.debug(f"Community strategy started with query: {query_text}")
    try:
        if not search_engine.conn:
            return []

        # Find communities with ai_summary - add proper filtering
        community_query = COMMUNITY_FTS_QUERY

        result = search_engine.conn.execute(community_query, {"text_query": query_text})

        # Handle result type properly - fix the list wrapping issue
        if isinstance(result, list) and result:
            result = result[0]

        results = []
        if isinstance(result, kuzu.QueryResult) and hasattr(result, "has_next"):
            with managed_result(result):
                if result.has_next():
                    row = result.get_next()
                    community_data = row[0]  # type: ignore
                    community_score = float(row[1])  # type: ignore

                    logger.debug(
                        f"Found community: {community_data.get('id', 'unknown')} with score: {community_score}"
                    )

            # Verify ai_summary exists (should be guaranteed by query filter)
            ai_summary = community_data.get("ai_summary")
            if not ai_summary:
                logger.warning(
                    f"Community {community_data.get('id', 'unknown')} has no ai_summary despite query filter"
                )
                return results

            # Track graph traversal
            graph_traversal_stats["communities_analyzed"] += 1

            # Find memory with most entity connections in this community
            memory_query = """
                MATCH (e:Entity {community_id: $community_id})<-[:MENTIONS]-(m:Memory)
                WITH m, COUNT(e) as entity_count, COLLECT(DISTINCT e.id) as entity_ids
                RETURN m, entity_count, entity_ids
                ORDER BY entity_count DESC, m.importance DESC
                LIMIT 1
            """
            _community_id = int(community_data["community_id"])

            memory_result = search_engine.conn.execute(
                memory_query, {"community_id": _community_id}
            )

            # Handle result type properly
            if isinstance(memory_result, list) and memory_result:
                memory_result = memory_result[0]

            if (
                isinstance(memory_result, kuzu.QueryResult)
                and hasattr(memory_result, "has_next")
            ):
                with managed_result(memory_result):
                    if memory_result.has_next():
                        memory_row = memory_result.get_next()
                        memory_data = memory_row[0]  # type: ignore
                        entity_count = memory_row[1]  # type: ignore
                        entity_ids = memory_row[2]  # type: ignore

                        # Track entities and relationships traversed
                        graph_traversal_stats["entities_traversed"] += (
                            len(entity_ids) if entity_ids else 0
                        )
                        graph_traversal_stats["relationships_traversed"] += (
                            entity_count * 2
                        )  # BELONGS_TO + MENTIONS per entity
                        logger.debug(
                            f"Community strategy found memory {memory_data.get('id', 'unknown')} with {entity_count} entities"
                        )
                        logger.debug(
                            f"Community strategy, graph traversal stats: {graph_traversal_stats}"
                        )

                        memory_node = _build_memory_node(search_engine, memory_data)
                        memory_search_result = MemorySearchResult(
                            memory=memory_node,
                            similarity_score=min(community_score / 12.0, 1.0) * 0.9,
                            relevance_reason=f"Key memory from community '{community_data.get('name', 'unnamed')}' via {entity_count} entities",
                            related_entities=[],
                        )
                        results.append(memory_search_result)
                        logger.debug(
                            f"Community strategy results: {len(results)} memories found"
                        )
            else:
                logger.debug(
                    f"No memories found for community {community_data.get('id', 'unknown')}"
                )
        else:
            logger.debug(f"No communities found matching query: {query_text}")

        return results

    except Exception as e:
        logger.error("Community strategy failed", error=str(e))
        return []


async def entity_strategy(
    search_engine: Any,
    query_text: str,
    limit: int,
    graph_traversal_stats: dict[str, int],
) -> list[MemorySearchResult]:
    """Strategy 3: LLM extract entities → Entity FTS → connected memories."""
    logger.debug(f"Entity strategy started with query: {query_text}")
    try:
        # Extract entities with LLM
        entities = await _extract_entities_llm(search_engine, query_text)
        if not entities:
            return []

        # Find matching entities via FTS
        matched_entities = []
        for entity_name in entities[:3]:
            entity_query = """
                CALL QUERY_FTS_INDEX(
                    'Entity',
                    'entity_content_index',
                    $entity_name
                )
                WITH node as e, score as entity_score
                WHERE entity_score > 0
                RETURN e, entity_score
                ORDER BY entity_score DESC
                LIMIT 2
            """

            if not search_engine.conn:
                return []

            entity_result = search_engine.conn.execute(
                entity_query, {"entity_name": entity_name}
            )

            # Handle result type properly
            if isinstance(entity_result, list) and entity_result:
                entity_result = entity_result[0]

            if isinstance(entity_result, kuzu.QueryResult) and hasattr(
                entity_result, "has_next"
            ):
                for row in iter_rows(entity_result):
                    entity_data = row[0]  # type: ignore
                    entity_score = float(row[1])  # type: ignore
                    matched_entities.append(
                        {
                            "data": entity_data,
                            "score": entity_score,
                            "extracted": entity_name,
                        }
                    )

        if not matched_entities:
            return []

        # Track entities traversed
        graph_traversal_stats["entities_traversed"] += len(matched_entities)

        # Find memories connected to entities
        entity_ids = [e["data"]["id"] for e in matched_entities]

        memory_query = """
            MATCH (m:Memory)-[:MENTIONS]->(e:Entity)
            WHERE e.id IN $entity_ids
            WITH m, COLLECT(DISTINCT e) as entity_nodes, COUNT(DISTINCT e) as entity_count
            RETURN m, entity_nodes, entity_count
            ORDER BY entity_count DESC, m.importance DESC
            LIMIT $limit
        """
        if not search_engine.conn:
            raise RuntimeError("Database connection not available")

        memory_result = search_engine.conn.execute(
            memory_query, {"entity_ids": entity_ids, "limit": min(limit, 3)}
        )

        # Handle result type properly
        if isinstance(memory_result, list) and memory_result:
            memory_result = memory_result[0]

        memories = []
        if isinstance(memory_result, kuzu.QueryResult) and hasattr(
            memory_result, "has_next"
        ):
            for row in iter_rows(memory_result):
                memory_data = row[0]  # type: ignore
                entity_nodes = row[1]  # type: ignore
                entity_count = row[2]  # type: ignore

                # Track relationships traversed (MENTIONS relationships)
                graph_traversal_stats["relationships_traversed"] += entity_count
                logger.debug(
                    f"Entity strategy, graph traversal stats: {graph_traversal_stats}, entity_count: {entity_count}"
                )

                memory_node = _build_memory_node(search_engine, memory_data)

                # Score based on entity connections
                avg_score = sum(e["score"] for e in matched_entities) / len(
                    matched_entities
                )
                normalized_score = min(avg_score / 15.0, 1.0) * 0.8

                extracted_names = [e.get("extracted", "") for e in matched_entities]
                reason = f"Connected to {entity_count} entities. Extracted: {', '.join(extracted_names[:2])}"

                # Build EntityNode objects from actual database query results
                related_entities = []
                for entity_data in entity_nodes:
                    # Validate required fields are present
                    if not entity_data or not isinstance(entity_data, dict):
                        logger.warning(
                            "Skipping invalid entity data", entity_data=entity_data
                        )
                        continue

                    entity_id = entity_data.get("id")
                    entity_name = entity_data.get("name")

                    # Sanity check: ensure id and name are present and align
                    if not entity_id or not entity_name:
                        logger.warning(
                            "Skipping entity with missing id or name",
                            entity_id=entity_id,
                            entity_name=entity_name,
                        )
                        continue

                    # Extract real timestamps from DB, fallback to UTC now only if absent
                    created_at = search_engine.client._safe_parse_datetime(
                        entity_data.get("created_at")
                    ) or datetime.datetime.now(datetime.timezone.utc)

                    updated_at = search_engine.client._safe_parse_datetime(
                        entity_data.get("updated_at")
                    ) or datetime.datetime.now(datetime.timezone.utc)

                    # Extract metadata from DB
                    metadata = search_engine.client._deserialize_metadata(
                        entity_data.get("metadata", "{}")
                    )

                    related_entities.append(
                        EntityNode(
                            id=entity_id,
                            node_type=NodeType.ENTITY,
                            name=entity_name,
                            entity_type=entity_data.get("entity_type", "entity"),
                            description=entity_data.get("description", None),
                            aliases=entity_data.get("aliases", []),
                            confidence=entity_data.get("confidence", 0.5),
                            created_at=created_at,
                            updated_at=updated_at,
                            metadata=metadata,
                            entity_created=entity_data.get("entity_created"),
                            entity_ended=entity_data.get("entity_ended"),
                            temporal_precision=entity_data.get("temporal_precision"),
                            temporal_confidence=entity_data.get("temporal_confidence"),
                            temporal_context=entity_data.get("temporal_context"),
                        )
                    )

                search_result = MemorySearchResult(
                    memory=memory_node,
                    similarity_score=normalized_score,
                    relevance_reason=reason,
                    related_entities=related_entities,
                )
                memories.append(search_result)
        logger.debug(f"Entity strategy results: {memories}")
        logger.debug(f"Entity strategy related entities: {related_entities}")
        return memories

    except Exception as e:
        logger.error("Entity strategy failed", error=str(e))
        return []


async def entity_strategy_fast(
    search_engine: Any,
    query_text: str,
    limit: int,
    graph_traversal_stats: dict[str, int],
) -> list[tuple[Any, float, str]]:
    """Fast entity strategy: Extract entities from query text (no LLM) → Entity FTS → connected memories.

    Returns list of tuples: (memory_data, score, "entity")
    """
    logger.debug(f"Fast entity strategy started with query: {query_text}")
    try:
        # Fast entity extraction: extract potential entity names from query text
        # Similar to label extraction - split by spaces, filter stop words, keep longer terms
        potential_entities = [
            entity.strip()
            for entity in query_text.split()
            if entity.strip()
            and entity.strip() not in STOP_WORDS
            and len(entity.strip()) > 3
        ]

        if not potential_entities:
            return []

        # Find matching entities via FTS
        matched_entities = []
        for entity_name in potential_entities[
            :3
        ]:  # Limit to top 3 potential entities
            entity_query = """
                CALL QUERY_FTS_INDEX(
                    'Entity',
                    'entity_content_index',
                    $entity_name
                )
                WITH node as e, score as entity_score
                WHERE entity_score > 0
                RETURN e, entity_score
                ORDER BY entity_score DESC
                LIMIT 2
            """

            if not search_engine.conn:
                return []

            entity_result = search_engine.conn.execute(
                entity_query, {"entity_name": entity_name}
            )

            # Handle result type properly
            if isinstance(entity_result, list) and entity_result:
                entity_result = entity_result[0]

            if isinstance(entity_result, kuzu.QueryResult) and hasattr(
                entity_result, "has_next"
            ):
                for row in iter_rows(entity_result):
                    entity_data = row[0]  # type: ignore
                    entity_score = float(row[1])  # type: ignore
                    matched_entities.append(
                        {
                            "data": entity_data,
                            "score": entity_score,
                            "extracted": entity_name,
                        }
                    )

        if not matched_entities:
            return []

        # Track entities traversed
        graph_traversal_stats["entities_traversed"] += len(matched_entities)

        # Find memories connected to entities
        entity_ids = [e["data"]["id"] for e in matched_entities]

        memory_query = """
            MATCH (m:Memory)-[:MENTIONS]->(e:Entity)
            WHERE e.id IN $entity_ids
            WITH m, COLLECT(DISTINCT e) as entity_nodes, COUNT(DISTINCT e) as entity_count
            RETURN m, entity_nodes, entity_count
            ORDER BY entity_count DESC, m.importance DESC
            LIMIT $limit
        """
        if not search_engine.conn:
            return []

        memory_result = search_engine.conn.execute(
            memory_query, {"entity_ids": entity_ids, "limit": min(limit, 5)}
        )

        # Handle result type properly
        if isinstance(memory_result, list) and memory_result:
            memory_result = memory_result[0]

        entity_memories = []
        if isinstance(memory_result, kuzu.QueryResult) and hasattr(
            memory_result, "has_next"
        ):
            for row in iter_rows(memory_result):
                memory_data = row[0]  # type: ignore
                entity_nodes = row[1]  # type: ignore
                entity_count = row[2]  # type: ignore

                # Track relationships traversed (MENTIONS relationships)
                graph_traversal_stats["relationships_traversed"] += entity_count

                # Score based on entity connections (similar to deep mode)
                avg_score = sum(e["score"] for e in matched_entities) / len(
                    matched_entities
                )
                normalized_score = min(avg_score / 15.0, 1.0) * 0.8

                # Return in tuple format: (memory_data, score, "entity")
                entity_memories.append((memory_data, normalized_score, "entity"))

        logger.debug(
            f"Fast entity strategy results: {len(entity_memories)} memories found"
        )
        return entity_memories

    except Exception as e:
        logger.error("Fast entity strategy failed", error=str(e))
        return []


async def community_strategy_fast(
    search_engine: Any,
    query_text: str,
    limit: int,
    graph_traversal_stats: dict[str, int],
) -> list[tuple[Any, float, str]]:
    """Fast community strategy: Community FTS → connected memories via entities.

    Returns list of tuples: (memory_data, score, "community")
    """
    logger.debug(f"Fast community strategy started with query: {query_text}")
    try:
        if not search_engine.conn:
            return []

        # Find communities with ai_summary - add proper filtering
        community_query = COMMUNITY_FTS_QUERY

        result = search_engine.conn.execute(community_query, {"text_query": query_text})

        # Handle result type properly - fix the list wrapping issue
        if isinstance(result, list) and result:
            result = result[0]

        community_memories = []
        if isinstance(result, kuzu.QueryResult) and hasattr(result, "has_next"):
            with managed_result(result):
                if result.has_next():
                    row = result.get_next()
                    community_data = row[0]  # type: ignore
                    community_score = float(row[1])  # type: ignore

                    logger.debug(
                        f"Found community: {community_data.get('id', 'unknown')} with score: {community_score}"
                    )

            # Verify ai_summary exists (should be guaranteed by query filter)
            ai_summary = community_data.get("ai_summary")
            if not ai_summary:
                logger.warning(
                    f"Community {community_data.get('id', 'unknown')} has no ai_summary despite query filter"
                )
                return community_memories

            # Track graph traversal
            graph_traversal_stats["communities_analyzed"] += 1

            # Find memory with most entity connections in this community
            memory_query = """
                MATCH (e:Entity {community_id: $community_id})<-[:MENTIONS]-(m:Memory)
                WITH m, COUNT(e) as entity_count, COLLECT(DISTINCT e.id) as entity_ids
                RETURN m, entity_count, entity_ids
                ORDER BY entity_count DESC, m.importance DESC
                LIMIT $limit
            """
            _community_id = int(community_data["community_id"])

            memory_result = search_engine.conn.execute(
                memory_query,
                {"community_id": _community_id, "limit": min(limit, 3)},
            )

            # Handle result type properly
            if isinstance(memory_result, list) and memory_result:
                memory_result = memory_result[0]

            if (
                isinstance(memory_result, kuzu.QueryResult)
                and hasattr(memory_result, "has_next")
            ):
                for memory_row in iter_rows(memory_result):
                    memory_data = memory_row[0]  # type: ignore
                    entity_count = memory_row[1]  # type: ignore
                    entity_ids = memory_row[2]  # type: ignore

                    # Track entities and relationships traversed
                    graph_traversal_stats["entities_traversed"] += (
                        len(entity_ids) if entity_ids else 0
                    )
                    graph_traversal_stats["relationships_traversed"] += (
                        entity_count * 2
                    )  # BELONGS_TO + MENTIONS per entity

                    # Score based on community match (similar to deep mode)
                    normalized_score = min(community_score / 12.0, 1.0) * 0.9

                    # Return in tuple format: (memory_data, score, "community")
                    community_memories.append(
                        (memory_data, normalized_score, "community")
                    )

                logger.debug(
                    f"Fast community strategy found {len(community_memories)} memories"
                )
            else:
                logger.debug(
                    f"No memories found for community {community_data.get('id', 'unknown')}"
                )
        else:
            logger.debug(f"No communities found matching query: {query_text}")

        return community_memories

    except Exception as e:
        logger.error("Fast community strategy failed", error=str(e))
        return []
