"""
LanceDB Search Engine - Migrated from Kuzu-based search

This module provides the same search functionality as the original KuzuSearchEngine
but uses LanceDB for vector/FTS search while keeping Kuzu for graph traversal.

Three focused search strategies:
1. Memory Hybrid: Vector + FTS over memories (LanceDB)
2. Community Mediated: Community FTS (LanceDB) -> connected memories via entities (Kuzu graph)
3. LLM Entity Mediated: LLM extract entities -> Entity FTS (LanceDB) -> connected memories (Kuzu graph)
"""

import asyncio
import datetime
import json
import re
from typing import Any, Dict, List, Optional, TYPE_CHECKING

import structlog
import real_ladybug as kuzu

from ..config import get_settings
from ..models.memory import MemoryNode, MemorySearchResult
from ..models.graph import EntityNode, NodeType
from ..services.embedding import EmbeddingService
from ..services.local_llm import get_local_llm_service
from ..services.memory_decay import compute_decay_score, blend_with_semantic_score
from ..services.json_utils import clean_and_parse_json
from ..services.search_index import (
    get_search_index_service,
    get_bge_m3_service,
)
from ..database.utils import DatabaseUtils
from ..database.result_utils import iter_rows, managed_result

if TYPE_CHECKING:
    from ..database.kuzu_client import KuzuClient

logger = structlog.get_logger(__name__)


# ==================== Constants ====================

LABEL_COUNT_THRESHOLD = 50

STOP_WORDS = set([
    "a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "has", "he",
    "in", "is", "it", "of", "on", "or", "that", "the", "to", "was", "were",
    "will", "with",
    # Chinese stop words
    "的", "是", "有", "我", "你", "他", "她", "它", "我们", "你们", "他们", "她们", "它们",
])

# Minimum score threshold - below this, results are likely noise
# For BGE-M3 (1024-dim) and Qwen3-Embedding, typical noise floor is ~0.25-0.35
# This threshold filters obviously irrelevant results while keeping potential matches
# Higher than E5-small (384-dim) which had noise floor ~0.15-0.25
SCORE_THRESHOLD_MINIMUM = 0.20

# Default fusion weights for combining search strategies
# These are used when no intent-based weights are provided
DEFAULT_WEIGHTS = {
    "vector": 0.5,
    "fts": 0.3,
    "entity": 0.15,
    "community": 0.1,
    "label": 0.15,
}

# Intent -> Strategy weights
# With proper embeddings, we can trust the model scores and use simpler weights
INTENT_STRATEGY_MAPPING = {
    "concept_lookup": {
        "vector": 0.6, "entity": 0.25, "fts": 0.1, "community": 0.05,
    },
    "factual_query": {
        "fts": 0.5, "vector": 0.3, "entity": 0.15, "community": 0.05,
    },
    "conceptual_question": {
        "vector": 0.6, "community": 0.2, "entity": 0.1, "fts": 0.1,
    },
    "exploratory_search": {
        "vector": 0.4, "community": 0.25, "entity": 0.2, "fts": 0.15,
    },
    "relationship_query": {
        "entity": 0.4, "vector": 0.3, "community": 0.2, "fts": 0.1,
    },
}


# ==================== Helper Functions ====================

def _normalize_date_for_comparison(date_str: str) -> str:
    """Normalize date string to YYYY-MM-DD format for comparison."""
    if not date_str:
        return date_str
    if len(date_str) == 4:  # YYYY
        return f"{date_str}-01-01"
    elif len(date_str) == 7:  # YYYY-MM
        return f"{date_str}-01"
    return date_str


def _build_memory_node(db: "KuzuClient", memory_data: dict[str, Any]) -> MemoryNode:
    """Build MemoryNode from database record."""
    metadata = memory_data.get("metadata", {})
    if isinstance(metadata, str):
        try:
            metadata = json.loads(metadata)
        except json.JSONDecodeError:
            metadata = {}

    # Access _safe_parse_datetime via base_client
    base_client = db.base_client

    return MemoryNode(
        id=memory_data["id"],
        content=memory_data.get("content", ""),
        metadata=metadata,
        node_type=NodeType.MEMORY,
        importance=memory_data.get("importance", 0.5),
        created_at=base_client._safe_parse_datetime(memory_data.get("created_at"))
            or datetime.datetime.now(datetime.UTC),
        embedding=[],
        source=memory_data.get("source", ""),
        source_range=json.loads(memory_data["source_range"])
            if memory_data.get("source_range") and isinstance(memory_data["source_range"], str | bytes | bytearray)
            else None,
        title=memory_data.get("title", ""),
        confidence=memory_data.get("confidence", 0.5),
        semantic_field=f"{memory_data.get('title', '')},\n{memory_data.get('content', '')}",
        reindex_needed=memory_data.get("reindex_needed", False),
        last_reindexed_at=base_client._safe_parse_datetime(memory_data.get("last_reindexed_at")),
        updated_at=base_client._safe_parse_datetime(memory_data.get("updated_at"))
            or datetime.datetime.now(datetime.UTC),
        # Decay model fields
        last_accessed_at=base_client._safe_parse_datetime(memory_data.get("last_accessed_at")),
        access_count=memory_data.get("access_count", 0),
        appearances=memory_data.get("appearances", 0),
        clicks=memory_data.get("clicks", 0),
        total_dwell_time_ms=memory_data.get("total_dwell_time_ms", 0),
        last_clicked_at=base_client._safe_parse_datetime(memory_data.get("last_clicked_at")),
        decay_score_cached=memory_data.get("decay_score_cached", 0.0) or 0.0,
        # Bi-temporal fields
        temporal_type=memory_data.get("temporal_type"),
        event_start=str(memory_data["event_start"]) if memory_data.get("event_start") else None,
        event_end=str(memory_data["event_end"]) if memory_data.get("event_end") else None,
        temporal_precision=memory_data.get("temporal_precision"),
        temporal_confidence=memory_data.get("temporal_confidence"),
        temporal_context=memory_data.get("temporal_context"),
        # Knowledge Agent fields (v0.6)
        unit_type=memory_data.get("unit_type", "fact"),
        is_latest=memory_data.get("is_latest", True),
        version=memory_data.get("version", 1),
        is_crystal=memory_data.get("is_crystal", False),
        crystal_title=memory_data.get("crystal_title"),
        source_unit_count=memory_data.get("source_unit_count"),
        extraction_method=memory_data.get("extraction_method", "manual"),
    )


def _apply_version_crystal_boost(score: float, memory_data: dict[str, Any]) -> float:
    """Apply is_latest and is_crystal boosts to a search score.

    Design spec (CORE_MODEL_DEEP_DIVE Part 9):
    - is_latest=True → mild preference for current knowledge
    - is_crystal=True → crystals are synthesized, higher quality
    - is_latest=False → deprioritize superseded memories
    """
    if memory_data.get("is_crystal", False):
        score *= 1.25
    if memory_data.get("is_latest", True):
        score *= 1.15
    else:
        score *= 0.85
    return min(score, 0.99)


def _calculate_strategy_weights(context: dict[str, Any], query_text: str) -> dict[str, Any]:
    """Calculate strategy weights based on refined intent detection."""
    refined_intent = context.get("refined_intent", "exploratory_search")
    context["refined_intent"] = refined_intent

    # Get intent-based weights or fall back to defaults
    weights = INTENT_STRATEGY_MAPPING.get(refined_intent, DEFAULT_WEIGHTS.copy())

    logger.debug("Intent-based weights calculated", query=query_text, intent=refined_intent)
    context["weights"] = weights
    return context


def _deduplicate_results(results: list[MemorySearchResult], limit: int) -> list[MemorySearchResult]:
    """Remove duplicates and return top results."""
    seen_ids = set()
    unique_results = []

    results.sort(key=lambda x: x.similarity_score, reverse=True)

    for result in results:
        memory_id = result.memory.id if result.memory else None
        if memory_id not in seen_ids:
            seen_ids.add(memory_id)
            unique_results.append(result)
            if len(unique_results) >= limit:
                break

    return unique_results


def _get_memory_labels_batch(db: "KuzuClient", memory_ids: list[str]) -> dict[str, list[str]]:
    """Batch fetch labels for multiple memories from the graph."""
    if not memory_ids:
        return {}

    try:
        query = """
            MATCH (m:Memory)-[:HAS_LABEL]->(l:Label)
            WHERE m.id IN $memory_ids
            RETURN m.id as memory_id, l.name as label_name
        """
        result = db.conn.execute(query, {"memory_ids": memory_ids}) # type: ignore[union-attr]

        labels_map: dict[str, list[str]] = {}
        if isinstance(result, kuzu.QueryResult):
            for row in iter_rows(result):
                memory_id = row[0]
                label_name = row[1]
                if memory_id not in labels_map:
                    labels_map[memory_id] = []
                labels_map[memory_id].append(label_name.lower())

        return labels_map
    except Exception as e:
        logger.warning(f"Failed to batch fetch memory labels: {e}")
        return {}


def _filter_existing_memory_ids(
    db: "KuzuClient", memory_scores: Dict[str, Dict[str, Any]]
) -> Dict[str, Dict[str, Any]]:
    """Drop search candidates whose memory IDs no longer exist in Kuzu."""
    if not memory_scores:
        return memory_scores
    try:
        memory_ids = list(memory_scores.keys())
        query = """
            MATCH (m:Memory)
            WHERE m.id IN $memory_ids
            RETURN m.id as memory_id
        """
        result = db.conn.execute(query, {"memory_ids": memory_ids})  # type: ignore[union-attr]

        existing_ids: set[str] = set()
        if isinstance(result, kuzu.QueryResult):
            for row in iter_rows(result):
                existing_ids.add(str(row[0]))

        if len(existing_ids) == len(memory_ids):
            return memory_scores

        filtered = {mid: info for mid, info in memory_scores.items() if mid in existing_ids}
        removed = len(memory_scores) - len(filtered)
        if removed > 0:
            logger.warning(
                "Filtered orphan search index rows not present in Kuzu",
                candidates=len(memory_scores),
                filtered=removed,
            )
        return filtered
    except Exception as e:
        logger.warning("Failed to validate memory existence during search fusion", error=str(e))
        return memory_scores


def _apply_filters(
    db: "KuzuClient",
    results: list[MemorySearchResult],
    filters: dict[str, Any],
) -> list[MemorySearchResult]:
    """Apply filters to the results."""
    memory_labels_map: dict[str, list[str]] = {}
    if "labels" in filters and filters["labels"]:
        memory_ids = [r.memory.id for r in results if r.memory]
        memory_labels_map = _get_memory_labels_batch(db, memory_ids)

    filtered_results = []
    for result in results:
        memory_node = result.memory
        if not memory_node:
            continue

        # Apply importance filter
        if "importance_min" in filters:
            if memory_node.importance < filters["importance_min"]:
                continue

        # Apply labels filter
        if "labels" in filters and filters["labels"]:
            memory_labels = memory_labels_map.get(memory_node.id, [])
            if not memory_labels:
                continue
            filter_labels_lower = [l.lower() for l in filters["labels"]]
            if not all(any(fl in ml for ml in memory_labels) for fl in filter_labels_lower):
                continue

        # Apply event time filters
        if "event_date_from" in filters or "event_date_to" in filters:
            event_start = getattr(memory_node, "event_start", None)
            if not event_start:
                continue
            event_start_normalized = _normalize_date_for_comparison(event_start)

            if "event_date_from" in filters:
                filter_from = _normalize_date_for_comparison(filters["event_date_from"])
                if event_start_normalized < filter_from:
                    continue
            if "event_date_to" in filters:
                filter_to = _normalize_date_for_comparison(filters["event_date_to"])
                if event_start_normalized > filter_to:
                    continue

        # Apply temporal context filter
        if "temporal_context" in filters:
            mem_context = getattr(memory_node, "temporal_context", None)
            if mem_context != filters["temporal_context"]:
                continue

        # Apply record time filters
        if "recorded_date_from" in filters:
            recorded_from = _normalize_date_for_comparison(filters["recorded_date_from"])
            created_at_normalized = memory_node.created_at.strftime("%Y-%m-%d") if memory_node.created_at else None
            if not created_at_normalized or created_at_normalized < recorded_from:
                continue

        if "recorded_date_to" in filters:
            recorded_to = _normalize_date_for_comparison(filters["recorded_date_to"])
            created_at_normalized = memory_node.created_at.strftime("%Y-%m-%d") if memory_node.created_at else None
            if not created_at_normalized or created_at_normalized > recorded_to:
                continue

        # Apply confidence filter
        if "confidence_min" in filters:
            if memory_node.confidence < filters["confidence_min"]:
                continue

        filtered_results.append(result)

    return filtered_results


# ==================== Fusion Functions ====================

def _normalize_fts_scores(fts_results: list[tuple]) -> list[tuple]:
    """Normalize FTS scores to 0-1 range (BM25 scores are unbounded)."""
    if not fts_results:
        return []
    max_score = max(score for _, score, _ in fts_results)
    if max_score <= 0:
        return fts_results
    return [(data, score / max_score, source) for data, score, source in fts_results]


def _build_relevance_reason(scores: dict[str, float]) -> str:
    """Build relevance reason from component scores.

    Maintains the format expected by UI: "Type Match (XX%)" for clarity.
    With proper embedding models, we trust the scores directly.
    """
    parts = []

    # Map source types to display names (matching old format for UI compatibility)
    source_display = {
        "vector": "Semantic",
        "fts": "Text",
        "entity": "Entity",
        "community": "Community",
        "label": "Label",
    }

    # Sort by score descending to show most relevant first
    sorted_scores = sorted(
        [(source, score) for source, score in scores.items() if score > 0.1],
        key=lambda x: x[1],
        reverse=True
    )

    for source, score in sorted_scores:
        display_name = source_display.get(source, source.title())
        parts.append(f"{display_name} Match ({score:.0%})")

    if not parts:
        return "Match"
    elif len(parts) == 1:
        return parts[0]
    else:
        return " + ".join(parts)


async def _fuse_hybrid_results(
    db: "KuzuClient",
    vector_results: list[tuple],
    fts_results: list[tuple],
    limit: int,
    label_results: list[tuple] | None = None,
    search_context: dict[str, Any] | None = None,
    entity_results: list[tuple] | None = None,
    community_results: list[tuple] | None = None,
) -> list[MemorySearchResult]:
    """Fuse results from multiple search strategies using weighted combination.

    With proper embedding models (Qwen3-Embedding/BGE-M3), we trust the scores
    directly and use simple weighted fusion without complex score manipulation.
    """
    # Get weights from search context or use defaults
    weights = DEFAULT_WEIGHTS.copy()
    if search_context and "weights" in search_context:
        weights.update(search_context.get("weights", {}))

    # Normalize FTS scores (BM25 scores are unbounded, need 0-1 range)
    fts_results = _normalize_fts_scores(fts_results)

    # Collect all scores per memory
    memory_scores: Dict[str, Dict[str, Any]] = {}

    def add_result(memory_data: dict, score: float, source: str):
        memory_id = memory_data["id"]
        if memory_id not in memory_scores:
            memory_scores[memory_id] = {
                "data": memory_data,
                "scores": {},
            }
        memory_scores[memory_id]["scores"][source] = max(
            memory_scores[memory_id]["scores"].get(source, 0),
            score
        )

    # Process all result sources
    for memory_data, score, source in vector_results:
        add_result(memory_data, score, "vector")
    for memory_data, score, source in fts_results:
        add_result(memory_data, score, "fts")
    if label_results:
        for memory_data, score, source in label_results:
            add_result(memory_data, score, "label")
    if entity_results:
        for memory_data, score, source in entity_results:
            add_result(memory_data, score, "entity")
    if community_results:
        for memory_data, score, source in community_results:
            add_result(memory_data, score, "community")

    # Guardrail: remove stale LanceDB rows whose IDs no longer exist in Kuzu.
    memory_scores = _filter_existing_memory_ids(db, memory_scores)

    # Calculate final scores using weighted combination
    results = []
    for memory_id, info in memory_scores.items():
        scores = info["scores"]

        # Simple weighted sum of available scores
        # Only include weights for sources that contributed
        total_weight = sum(weights.get(source, 0) for source in scores.keys())
        if total_weight == 0:
            continue

        # Normalize weights to sum to 1 for available sources
        normalized_weights = {
            source: weights.get(source, 0) / total_weight
            for source in scores.keys()
        }

        # Calculate final score
        final_score = sum(
            scores[source] * normalized_weights[source]
            for source in scores.keys()
        )

        # Multi-source bonus: boost results found by multiple strategies
        num_sources = len(scores)
        if num_sources > 1:
            final_score *= (1.0 + 0.05 * (num_sources - 1))  # 5% boost per extra source

        # Version-aware & crystal boosts (v0.6)
        final_score = _apply_version_crystal_boost(final_score, info["data"])

        # Build result
        memory_node = _build_memory_node(db, info["data"])
        results.append(MemorySearchResult(
            memory=memory_node,
            similarity_score=final_score,
            relevance_reason=_build_relevance_reason(scores),
            related_entities=[],
        ))

    # Sort by score descending
    results.sort(key=lambda x: x.similarity_score, reverse=True)

    # Debug: log score distribution before filtering
    if results:
        scores_preview = [r.similarity_score for r in results[:5]]
        logger.debug(
            "Fusion scores before filter",
            total=len(results),
            top_5_scores=scores_preview,
            threshold=SCORE_THRESHOLD_MINIMUM,
        )

    # Simple noise filter - remove very low scoring results
    pre_filter_count = len(results)
    results = [r for r in results if r.similarity_score >= SCORE_THRESHOLD_MINIMUM]

    if pre_filter_count > 0 and len(results) == 0:
        logger.warning(
            "All results filtered out by threshold",
            pre_filter_count=pre_filter_count,
            threshold=SCORE_THRESHOLD_MINIMUM,
        )

    # Log metrics if requested
    if search_context is not None:
        metrics = search_context.setdefault("debug_metrics", {})
        vector_scores = [
            info["scores"].get("vector", 0)
            for info in memory_scores.values()
            if info["scores"].get("vector", 0) > 0
        ]
        if vector_scores:
            metrics["vector_score_min"] = float(min(vector_scores))
            metrics["vector_score_max"] = float(max(vector_scores))
            metrics["vector_score_range"] = float(max(vector_scores) - min(vector_scores))
        metrics["total_candidates"] = len(memory_scores)
        metrics["post_filter_count"] = len(results)

    return results[:limit]


async def _fuse_vector_fts_fast(
    db: "KuzuClient",
    vector_results: list[tuple],
    fts_results: list[tuple],
    limit: int,
) -> list[MemorySearchResult]:
    """Fast fusion of vector and FTS results.

    Simplified version for fast mode - just vector + FTS with fixed weights.
    With proper embeddings, we trust scores and don't need complex logic.
    """
    try:
        # Normalize FTS scores
        fts_results = _normalize_fts_scores(fts_results)

        # Collect scores per memory
        memory_scores: dict[str, dict[str, Any]] = {}

        for memory_data, score, _ in vector_results:
            memory_id = memory_data["id"]
            if memory_id not in memory_scores:
                memory_scores[memory_id] = {"data": memory_data, "vector": 0, "fts": 0}
            memory_scores[memory_id]["vector"] = max(memory_scores[memory_id]["vector"], score)

        for memory_data, score, _ in fts_results:
            memory_id = memory_data["id"]
            if memory_id not in memory_scores:
                memory_scores[memory_id] = {"data": memory_data, "vector": 0, "fts": 0}
            memory_scores[memory_id]["fts"] = max(memory_scores[memory_id]["fts"], score)

        # Guardrail: remove stale LanceDB rows whose IDs no longer exist in Kuzu.
        memory_scores = _filter_existing_memory_ids(db, memory_scores)

        # Fixed weights for fast mode (favor vector slightly)
        vector_weight = 0.6
        fts_weight = 0.4

        results: list[MemorySearchResult] = []
        for memory_id, info in memory_scores.items():
            vector_score = info["vector"]
            fts_score = info["fts"]

            # Weighted average of available scores
            if vector_score > 0 and fts_score > 0:
                combined = vector_score * vector_weight + fts_score * fts_weight
                combined *= 1.05  # Small boost for multi-source match
            elif vector_score > 0:
                combined = vector_score
            else:
                combined = fts_score

            # Version-aware & crystal boosts (v0.6)
            combined = _apply_version_crystal_boost(combined, info["data"])

            memory_node = _build_memory_node(db, info["data"])
            reason = _build_relevance_reason({"vector": vector_score, "fts": fts_score})

            results.append(MemorySearchResult(
                memory=memory_node,
                similarity_score=combined,
                relevance_reason=reason,
                related_entities=[],
            ))

        results.sort(key=lambda r: r.similarity_score, reverse=True)

        # Simple noise filter
        results = [r for r in results if r.similarity_score >= SCORE_THRESHOLD_MINIMUM]

        return results[:limit]

    except Exception as e:
        logger.warning("Fast fusion failed", error=str(e))
        return []


# ==================== LLM Functions ====================

async def _analyze_search_context(query_text: str) -> dict[str, Any]:
    """Analyze search context for heuristic strategy weighting (deep mode)."""
    try:
        settings = get_settings()
        llm_service = await get_local_llm_service(
            cache_dir=settings.llm_cache_dir,
            cache_only=settings.llm_cache_only,
        )

        prompt = f"""Classify the query. Respond with JSON only.

fields:
- refined_intent: one of [concept_lookup, factual_query, conceptual_question, relationship_query, exploratory_search]
- is_question: boolean
- key_terms: array (<=3) of tokens that appear verbatim in the query
- confidence: number in [0,1]

Query: {query_text}

JSON:"""

        llm_service._current_operation = "search_context_analysis"
        response = await llm_service._generate_response(prompt, max_tokens=64, use_thinking=False)

        try:
            from json_repair import repair_json
            # Strip extra text after JSON (e.g., "<|endoftext|>Human:...")
            clean_response = response.strip()
            if "<|" in clean_response:
                clean_response = clean_response.split("<|")[0].strip()

            repaired_json = repair_json(clean_response)
            parsed = json.loads(repaired_json)

            # Handle case where json_repair returns a list
            if isinstance(parsed, list):
                parsed = parsed[0] if parsed and isinstance(parsed[0], dict) else {}
            if not isinstance(parsed, dict):
                parsed = {}

            refined_intent = (parsed.get("refined_intent") or "").strip()
            is_question = bool(parsed.get("is_question", False))
            key_terms = parsed.get("key_terms", []) or []
            confidence = float(parsed.get("confidence", 0.0) or 0.0)

            valid_refined = ["concept_lookup", "factual_query", "conceptual_question", "relationship_query", "exploratory_search"]
            if refined_intent not in valid_refined:
                refined_intent = "exploratory_search"

            # Validate key terms against actual query
            validated_terms = [term for term in key_terms if isinstance(term, str) and term.lower() in query_text.lower()]
            key_terms = validated_terms[:3]

        except Exception as e:
            logger.debug("JSON parsing failed, using fallbacks", error=str(e))
            refined_intent = "exploratory_search"
            is_question = False
            key_terms = []
            confidence = 0.0

        specificity = "specific" if refined_intent in ["concept_lookup", "factual_query", "relationship_query"] else "broad"
        context = {
            "refined_intent": refined_intent,
            "is_question": is_question,
            "key_terms": key_terms,
            "confidence": confidence,
            "specificity": specificity,
        }

        # Extract temporal intent
        try:
            from ..database.temporal_intent import extract_temporal_intent
            temporal_intent = await extract_temporal_intent(query_text, llm_service)
            context["temporal_intent"] = temporal_intent
        except Exception as e:
            logger.warning("Temporal intent extraction failed", error=str(e))
            context["temporal_intent"] = {
                "has_temporal_intent": False,
                "temporal_type": None,
                "temporal_value": None,
                "temporal_confidence": 0.0,
            }

        context = _calculate_strategy_weights(context, query_text)
        context = await _process_advanced_query_strategies(context, query_text)

        return context

    except Exception as e:
        logger.warning("Context analysis failed, using defaults", error=str(e))
        return {
            "refined_intent": "exploratory_search",
            "specificity": "broad",
            "is_question": False,
            "key_terms": [],
            "confidence": 0.0,
            "weights": {"vector": 0.7, "fts": 0.3, "entity": 0.3, "community": 0.2},
            "advanced": {
                "use_hyde": False,
                "hyde_query": None,
                "label_search_enabled": False,
                "potential_labels": [],
            },
        }


async def _process_advanced_query_strategies(context: dict[str, Any], query_text: str) -> dict[str, Any]:
    """Apply advanced query processing strategies like HyDE and label search."""
    context["advanced"] = {
        "use_hyde": False,
        "hyde_query": None,
        "label_search_enabled": False,
        "potential_labels": [],
        "query_rewrite": None,
    }

    refined_intent = context.get("refined_intent", "exploratory_search")

    # HyDE for questions only
    if context.get("is_question", False):
        context["advanced"]["use_hyde"] = True
        context["advanced"]["hyde_query"] = await _generate_simple_hyde(query_text)
        logger.debug("HyDE enabled for question", query=query_text)

    # Label search for specific terms
    if refined_intent in ["concept_lookup", "factual_query", "relationship_query"]:
        key_terms = context.get("key_terms", [])
        if key_terms:
            context["advanced"]["label_search_enabled"] = True
            context["advanced"]["potential_labels"] = key_terms

    return context


async def _generate_simple_hyde(query_text: str) -> str:
    """Generate simple hypothetical answer for HyDE embedding."""
    try:
        settings = get_settings()
        llm_service = await get_local_llm_service(
            cache_dir=settings.llm_cache_dir,
            cache_only=settings.llm_cache_only,
        )

        prompt = f"""Please write a passage to answer the question
Try to include as many key details as possible.

{query_text}

Passage:"""
        response = await llm_service._generate_response(prompt, max_tokens=60, use_thinking=False)
        return response.strip()

    except Exception as e:
        logger.warning("HyDE generation failed", error=str(e))
        return query_text


async def _extract_entities_llm(query_text: str) -> list[str]:
    """Extract key entities using LLM."""
    try:
        settings = get_settings()
        llm_service = await get_local_llm_service(
            cache_dir=settings.llm_cache_dir,
            cache_only=settings.llm_cache_only,
        )

        # Prompt must clearly separate instruction from output format.
        # Previous prompt had the JSON example right after the query text,
        # causing Qwen3-4B to explain the example instead of producing JSON.
        # Fix: put example (with real-looking names, not placeholders) in the
        # instruction, end with a bare "JSON:" cue — same pattern that works
        # in _analyze_search_context.
        prompt = f"""Extract 2-3 key entities (proper nouns, technologies, concepts) from the query.
Respond with ONLY a JSON object, e.g. {{"entities":["Python","machine learning"]}}

Query: {query_text}

JSON:"""

        llm_service._current_operation = "entity_extraction"
        response = await llm_service._generate_response(prompt, max_tokens=50, use_thinking=False)

        logger.debug(
            "Entity extraction raw response",
            query=query_text,
            response=response,
            response_length=len(response) if response else 0,
        )

        if not response or not response.strip():
            logger.debug("Entity extraction returned empty response", query=query_text)
            return []

        try:
            data = clean_and_parse_json(response)
            if not isinstance(data, dict) or "entities" not in data:
                logger.debug(
                    "Entity extraction JSON missing 'entities' key",
                    query=query_text,
                    parsed_data=data,
                    raw_response=response[:200],
                )
                entities = []
            else:
                raw_entities = data["entities"]
                # Validate: only accept string entities, skip objects/numbers
                entities = [e for e in raw_entities if isinstance(e, str) and e.strip()]
                if len(entities) != len(raw_entities):
                    logger.debug(
                        "Filtered non-string entities",
                        original=raw_entities,
                        filtered=entities,
                    )
        except Exception as parse_err:
            logger.debug(
                "Entity extraction JSON parse failed",
                query=query_text,
                error=str(parse_err),
                raw_response=response[:200],
            )
            entities = []

        logger.debug("Entity extraction result", query=query_text, entities=entities[:3])
        return entities[:3]

    except Exception as e:
        logger.error("Entity extraction failed", error=str(e))
        return []


async def _validate_content_relevance(
    query_text: str,
    content: str,
    title: str,
    search_context: dict[str, Any],
) -> float:
    """Validate topical relevance between query and content using LLM."""
    try:
        if len(content) < 50:
            return 1.0

        settings = get_settings()
        llm_service = await get_local_llm_service(
            cache_dir=settings.llm_cache_dir,
            cache_only=settings.llm_cache_only,
        )

        prompt = f"""Rate how well this content matches the search query topic. Judge by semantic/topic alignment only.

Query: {query_text}

Content: {title}
{content[:400]}...

Score 0-10 based on TOPIC match (ignore language/wording differences):
0-2: Completely different topics
3-4: Distant relation, different domains
5-6: Same general field, different specific focus
7-8: Related topics with meaningful overlap
9-10: Same core topic OR directly addresses the relationship/comparison implied by the query

Score (0-10):"""

        response = await llm_service._generate_response(prompt, max_tokens=32, use_thinking=False)

        if not response or not response.strip():
            return 1.0

        try:
            import re
            score_text = response.strip()
            raw_score = None

            lines = [l.strip() for l in score_text.split("\n") if l.strip()]
            if lines:
                first_line = lines[0]
                score_match = re.search(r"Score\s*(?:\([^)]*\))?\s*:\s*(\d+(?:\.\d+)?)", first_line, re.IGNORECASE)
                if score_match:
                    raw_score = float(score_match.group(1))

            if raw_score is None and lines and lines[0]:
                first_line_match = re.match(r"^\s*(\d+(?:\.\d+)?)\s*$", lines[0])
                if first_line_match:
                    raw_score = float(first_line_match.group(1))

            if raw_score is None:
                matches = re.findall(r"(\d+(?:\.\d+)?)", score_text)
                if matches:
                    raw_score = float(matches[0])

            if raw_score is not None:
                if raw_score < 0:
                    raw_score = 0.0
                elif raw_score > 10:
                    raw_score = 10.0
                relevance_score = raw_score / 10.0
            else:
                relevance_score = 0.1

        except Exception:
            relevance_score = 0.1

        # Apply penalties
        if relevance_score < 0.3:
            relevance_score *= 0.05
        elif relevance_score < 0.5:
            relevance_score *= 0.3
        elif relevance_score < 0.7:
            relevance_score *= 0.6
        elif relevance_score < 0.9:
            relevance_score *= 0.85

        return relevance_score

    except Exception as e:
        logger.warning("Content relevance validation failed", error=str(e))
        return 1.0


# ==================== LLM Reranking (Deep Mode) ====================

async def llm_rerank_results(
    query: str,
    results: List[MemorySearchResult],
    top_k: int = 10,
) -> List[MemorySearchResult]:
    """Rerank search results using LLM for deep mode.

    This function:
    1. Takes the top K results from initial search
    2. Uses LLM to evaluate relevance and generate explanations
    3. Returns reranked results with human-friendly explanations

    The LLM evaluates each result against the query and provides:
    - A relevance score (0-10)
    - A brief, human-friendly explanation of why it's relevant

    Args:
        query: The search query
        results: Initial search results
        top_k: Number of top results to rerank (default 10)

    Returns:
        Reranked results with LLM-generated explanations
    """
    if not results:
        return results

    # Only rerank top K to limit cost
    to_rerank = results[:top_k]
    remainder = results[top_k:]

    if len(to_rerank) <= 1:
        return results

    try:
        settings = get_settings()
        llm_service = await get_local_llm_service(
            cache_dir=settings.llm_cache_dir,
            cache_only=settings.llm_cache_only,
        )

        # Skip reranking if remote LLM is not enabled (local LLM not capable enough)
        from ..services.remote_llm_config import get_config_manager
        config_manager = get_config_manager()
        if not config_manager.is_enabled():
            logger.debug("Skipping LLM rerank - remote LLM not enabled (local LLM not suitable)")
            return results

        # Build compact prompt with all results (reduced from 300 to 150 chars)
        results_text = []
        for i, result in enumerate(to_rerank):
            title = result.memory.title or "(no title)" if result.memory else "(no memory)"
            content = result.memory.content[:150] if result.memory and result.memory.content else ""
            results_text.append(f"[{i+1}] {title}: {content}")

        results_block = "\n".join(results_text)

        prompt = f"""Rank results for query "{query}". JSON only.

{results_block}

{{"rankings":[{{"index":N,"score":0-10,"explanation":"..."}}]}}"""

        llm_service._current_operation = "search_rerank"
        response = await llm_service._generate_response(prompt, max_tokens=1280, use_thinking=False)

        # Handle empty LLM response
        if not response or not response.strip():
            logger.warning("LLM rerank returned empty response, using original order")
            return results

        # Parse response
        try:
            data = clean_and_parse_json(response)
            rankings = data.get("rankings", []) if data else []

            if not rankings or len(rankings) != len(to_rerank):
                logger.warning("LLM rerank returned incomplete rankings, using original order")
                logger.debug("LLM rerank response", response=response)
                return results

            # Build reranked results with explanations
            reranked = []
            seen_indices = set()

            for rank_info in rankings:
                idx = rank_info.get("index", 0) - 1  # Convert 1-indexed to 0-indexed
                if idx < 0 or idx >= len(to_rerank) or idx in seen_indices:
                    continue
                seen_indices.add(idx)

                original = to_rerank[idx]
                llm_score = rank_info.get("score", 5) / 10.0  # Normalize to 0-1
                explanation = rank_info.get("explanation", "")

                # Blend LLM score with original score (70% LLM, 30% original)
                blended_score = llm_score * 0.7 + original.similarity_score * 0.3

                # Create new result with LLM explanation
                reranked_result = MemorySearchResult(
                    memory=original.memory,
                    similarity_score=min(blended_score, 0.99),
                    relevance_reason=explanation if explanation else original.relevance_reason,
                    related_entities=getattr(original, "related_entities", []),
                )
                reranked.append(reranked_result)

            # Add any missing results (in case LLM missed some)
            for i, result in enumerate(to_rerank):
                if i not in seen_indices:
                    reranked.append(result)

            # Sort by blended score
            reranked.sort(key=lambda x: x.similarity_score, reverse=True)

            logger.debug(
                "LLM reranking completed",
                original_top_3=[r.memory.id[:8] if r.memory else "none" for r in to_rerank[:3]],
                reranked_top_3=[r.memory.id[:8] if r.memory else "none" for r in reranked[:3]],
            )

            return reranked + remainder

        except Exception as e:
            logger.warning("Failed to parse LLM rerank response", error=str(e))
            return results

    except Exception as e:
        logger.warning("LLM reranking failed, using original order", error=str(e))
        return results


# ==================== Label Search ====================

async def _search_by_labels(
    db: "KuzuClient",
    potential_labels: list[str],
    limit: int,
) -> list[tuple[Any, float, str]]:
    """Search memories by label connections using KuzuDB HAS_LABEL relationships."""
    try:
        if not potential_labels:
            return []

        # Check if we have any labels
        count_result = db.conn.execute("MATCH (l:Label) RETURN count(*) as label_count") # type: ignore[union-attr]
        if isinstance(count_result, kuzu.QueryResult):
            with managed_result(count_result):
                if count_result.has_next():
                    label_count = count_result.get_next()[0]
                    if label_count == 0:
                        return []

        # Escape regex special characters for Cypher regex (e.g., "C++", "test{", "Node.js")
        labels_pattern = "|".join(
            DatabaseUtils.escape_cypher_regex(label) for label in potential_labels[:5]
        )

        label_query = f"""
            MATCH (m:Memory)-[hl:HAS_LABEL]->(l:Label)
            WHERE l.name =~ '(?i).*({labels_pattern}).*'
            RETURN DISTINCT m, l.name as label_name, COUNT(*) as label_connections
            ORDER BY label_connections DESC
            LIMIT $limit
        """
        result = db.conn.execute(label_query, {"limit": limit}) # type: ignore[union-attr]

        label_memories = []
        if isinstance(result, kuzu.QueryResult):
            for row in iter_rows(result):
                memory_data = row[0]
                label_name = row[1]
                connections = float(row[2])

                base_score = 0.3
                connection_bonus = min(connections * 0.1, 0.4)

                exact_match_bonus = 0.0
                for potential_label in potential_labels:
                    if potential_label.lower() in label_name.lower():
                        exact_match_bonus = 0.3
                        break

                total_score = base_score + connection_bonus + exact_match_bonus
                label_memories.append((memory_data, total_score, "label"))

        return label_memories

    except Exception as e:
        logger.debug("Label search failed", error=str(e))
        return []


# ==================== Decay Scoring ====================

def apply_decay_scoring(
    db: "KuzuClient",
    results: List[MemorySearchResult],
    search_context: Optional[dict[str, Any]] = None,
) -> List[MemorySearchResult]:
    """Apply decay scoring to search results.

    Computes decay score for each memory based on recency + frequency,
    then blends with semantic similarity score (15% decay weight).
    Also appends decay/temporal factors to relevance_reason for UI display.
    """
    if not results:
        return results

    now = datetime.datetime.now(datetime.timezone.utc)
    temporal_intent = None
    if search_context:
        temporal_intent = search_context.get("temporal_intent")

    for result in results:
        if not result.memory:
            continue

        # Get decay-related fields
        last_accessed_at = getattr(result.memory, "last_accessed_at", None)
        access_count = getattr(result.memory, "access_count", 0) or 0
        importance = getattr(result.memory, "importance", 0.5) or 0.5
        appearances = getattr(result.memory, "appearances", 0) or 0
        clicks = getattr(result.memory, "clicks", 0) or 0

        # Get temporal fields
        temporal_type = getattr(result.memory, "temporal_type", None)
        event_start = getattr(result.memory, "event_start", None)
        event_end = getattr(result.memory, "event_end", None)
        temporal_precision = getattr(result.memory, "temporal_precision", None)
        temporal_context = getattr(result.memory, "temporal_context", None)

        # Compute decay score
        decay_score = compute_decay_score(
            last_accessed_at=last_accessed_at,
            access_count=access_count,
            importance=importance,
            now=now,
        )

        original_score = result.similarity_score

        # Compute temporal boost
        from ..database.temporal_intent import compute_temporal_boost, build_temporal_boost_explanation
        temporal_boost = compute_temporal_boost(result.memory, now, temporal_intent)

        # Blend scores
        if temporal_boost > 0:
            result.similarity_score = (
                original_score * 0.70 +
                decay_score * 0.15 +
                temporal_boost
            )
        else:
            result.similarity_score = blend_with_semantic_score(
                semantic_score=original_score,
                decay_score=decay_score,
            )

        # Calculate days since last access
        days_since = None
        if last_accessed_at:
            if last_accessed_at.tzinfo is None:
                last_accessed_at = last_accessed_at.replace(tzinfo=datetime.timezone.utc)
            days_since = (now - last_accessed_at).total_seconds() / 86400

        ctr = (clicks / appearances) if appearances > 0 else None

        # Build decay factor string
        decay_factors = []
        if days_since is not None:
            if days_since < 1:
                decay_factors.append("recent:<1d")
            elif days_since < 7:
                decay_factors.append(f"recent:{int(days_since)}d")
            elif days_since < 30:
                decay_factors.append(f"recent:{int(days_since/7)}w")
            else:
                decay_factors.append(f"recent:{int(days_since/30)}mo")

        if access_count > 0:
            decay_factors.append(f"accesses:{access_count}")

        if ctr is not None and appearances >= 3:
            ctr_pct = int(ctr * 100)
            decay_factors.append(f"ctr:{ctr_pct}%")

        if importance > 0.7:
            decay_factors.append("imp:high")
        elif importance < 0.3:
            decay_factors.append("imp:low")

        # Build temporal factor string
        temporal_factors = []
        if temporal_type and temporal_type != "unknown":
            if event_start:
                if temporal_precision == "year":
                    date_str = event_start[:4] if isinstance(event_start, str) else str(event_start.year)
                elif temporal_precision == "month":
                    date_str = event_start[:7] if isinstance(event_start, str) else f"{event_start.year}-{event_start.month:02d}"
                else:
                    date_str = str(event_start)[:10] if isinstance(event_start, str) else event_start.strftime("%Y-%m-%d")

                if temporal_type == "range" and event_end:
                    end_str = str(event_end)[:4] if temporal_precision == "year" else str(event_end)[:10]
                    temporal_factors.append(f"time:{date_str}-{end_str}")
                else:
                    temporal_factors.append(f"time:{date_str}")

        if temporal_context and temporal_context != "timeless":
            temporal_factors.append(f"ctx:{temporal_context}")

        # Append factors to relevance_reason
        existing_reason = result.relevance_reason or ""
        factor_parts = []

        if decay_factors:
            factor_parts.append(f"decay[{','.join(decay_factors)}]")

        if temporal_factors:
            factor_parts.append(f"temporal[{','.join(temporal_factors)}]")

        if temporal_boost > 0:
            boost_pct = int(temporal_boost * 100 / 0.15)
            boost_explanation = build_temporal_boost_explanation(
                temporal_intent, temporal_boost, event_start, temporal_context
            )
            if boost_explanation:
                factor_parts.append(f"query_match[{boost_explanation}]")
            else:
                factor_parts.append(f"event_recency_boost:{boost_pct}%")

        if factor_parts:
            factor_str = " | " + " ".join(factor_parts)
            result.relevance_reason = existing_reason + factor_str

    # Re-sort by final score
    results.sort(key=lambda r: r.similarity_score, reverse=True)

    return results
