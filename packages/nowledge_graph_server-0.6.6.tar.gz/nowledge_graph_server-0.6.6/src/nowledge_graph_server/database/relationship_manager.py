"""
Relationship Manager

Graph relationship operations including creation, deletion, and management.
"""

from typing import Optional, Dict, Any
import structlog
import datetime
import json
from nowledge_graph_server.database.base_client import KuzuBaseClient
from nowledge_graph_server.database.result_utils import iter_rows, managed_result

logger = structlog.get_logger(__name__)


class RelationshipManager:
    """Manager for graph relationship operations."""

    def __init__(self, client: KuzuBaseClient):
        """Initialize with base client for database access."""
        self.client = client

    @property
    def conn(self):
        """Access database connection through client."""
        return self.client.conn

    async def create_thread_memory_relationship(
        self,
        thread_id: str,
        memory_id: str,
        compaction_method: str = "distillation",
    ) -> str:
        """Create COMPACTS_TO relationship between thread and memory."""
        self.client._ensure_initialized()

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            relationship_id = f"compacts_{thread_id}_{memory_id}"

            query = """
                MATCH (t:Thread {thread_id: $thread_id}), (m:Memory {id: $memory_id})
                CREATE (t)-[:COMPACTS_TO {
                    compaction_method: $compaction_method,
                    created_at: $created_at,
                    properties: $properties
                }]->(m)
            """

            self.conn.execute(
                query,
                {
                    "thread_id": thread_id,
                    "memory_id": memory_id,
                    "compaction_method": compaction_method,
                    "created_at": datetime.datetime.now(datetime.timezone.utc),
                    "properties": "{}",
                },
            )

            return relationship_id

        except Exception as e:
            logger.error(
                "Failed to create thread-memory relationship",
                thread_id=thread_id,
                memory_id=memory_id,
                error=str(e),
            )
            raise

    async def create_entity_relationship(
        self,
        source_entity_id: str,
        target_entity_id: str,
        relation_type: str,
        confidence: float = 0.6,  # More conservative default
        context: str = "",
        reasoning: str = "",
        source_memory_id: Optional[str] = None,  # NEW: Track source memory
        temporal_info: str = "",  # Legacy: Temporal information (kept for backwards compatibility)
        conditions: str = "",  # NEW: Conditions or constraints
        # Bi-temporal fields (added 2025-11-20) - Optional to maintain backwards compatibility
        temporal_type: Optional[str] = None,
        rel_start: Optional[str] = None,
        rel_end: Optional[str] = None,
        temporal_precision: Optional[str] = None,
        is_ongoing: bool = True,
        temporal_confidence: Optional[float] = None,
    ) -> str:
        """Create RELATES_TO relationship between two entities.

        Args:
            source_entity_id: Source entity ID
            target_entity_id: Target entity ID
            relation_type: Type of relationship (USES, CREATES, etc.)
            confidence: Confidence score (0.0-1.0)
            context: Context where relationship was found
            reasoning: Reasoning for the relationship
            source_memory_id: ID of source memory (for provenance)
            temporal_info: Legacy temporal information (kept for backwards compatibility)
            conditions: Conditions or constraints
            temporal_type: Temporal type ("exact"|"range"|"unknown")
            rel_start: When relationship began (normalized YYYY-MM-DD)
            rel_end: When relationship ended (normalized YYYY-MM-DD)
            temporal_precision: Date precision ("year"|"month"|"day")
            is_ongoing: True if relationship is still active
            temporal_confidence: LLM confidence in temporal info (0.0-1.0)
        """
        self.client._ensure_initialized()

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            relationship_id = f"relates_{source_entity_id}_{target_entity_id}"

            # First verify both entities exist to avoid silent MATCH failures
            verify_query = """
                MATCH (source:Entity {id: $source_entity_id})
                MATCH (target:Entity {id: $target_entity_id})
                RETURN source.id, target.id
            """
            verify_result = self.conn.execute(
                verify_query,
                {
                    "source_entity_id": source_entity_id,
                    "target_entity_id": target_entity_id,
                },
            )
            with managed_result(verify_result):
                if not verify_result.has_next():  # type: ignore
                    logger.warning(
                        "Cannot create RELATES_TO - one or both entities not found in database",
                        source_entity_id=source_entity_id,
                        target_entity_id=target_entity_id,
                    )
                    raise ValueError(
                        f"Entities not found: source={source_entity_id}, target={target_entity_id}"
                    )

            # Bi-temporal columns added via migration 20251219_000000_add_bitemporal_to_relates_to
            query = """
                MATCH (source:Entity {id: $source_entity_id}), (target:Entity {id: $target_entity_id})
                CREATE (source)-[:RELATES_TO {
                    relation_type: $relation_type,
                    strength: $confidence,
                    confidence: $confidence,
                    context: $context,
                    conditions: $conditions,
                    temporal_info: $temporal_info,
                    source_reference: $source_reference,
                    bidirectional: false,
                    created_at: $created_at,
                    properties: $properties,
                    temporal_type: $temporal_type,
                    rel_start: $rel_start,
                    rel_end: $rel_end,
                    temporal_precision: $temporal_precision,
                    is_ongoing: $is_ongoing,
                    temporal_confidence: $temporal_confidence
                }]->(target)
            """

            properties = {
                "reasoning": reasoning,
                "extraction_method": "llm_distillation",
                "source_memory_id": source_memory_id,
            }

            self.conn.execute(
                query,
                {
                    "source_entity_id": source_entity_id,
                    "target_entity_id": target_entity_id,
                    "relation_type": relation_type,
                    "confidence": confidence,
                    "context": context,
                    "conditions": conditions,
                    "temporal_info": temporal_info,
                    "source_reference": source_memory_id
                    or "",  # Set source_reference to memory ID
                    "created_at": datetime.datetime.now(datetime.timezone.utc),
                    "properties": json.dumps(properties),
                    # Bi-temporal fields (added via migration 20251219_000000)
                    "temporal_type": temporal_type,
                    "rel_start": rel_start,
                    "rel_end": rel_end,
                    "temporal_precision": temporal_precision,
                    "is_ongoing": is_ongoing,
                    "temporal_confidence": temporal_confidence,
                },
            )

            logger.debug(
                "Created RELATES_TO relationship",
                source_entity_id=source_entity_id,
                target_entity_id=target_entity_id,
                relation_type=relation_type,
            )

            return relationship_id

        except Exception as e:
            logger.error(
                "Failed to create entity relationship",
                source_entity_id=source_entity_id,
                target_entity_id=target_entity_id,
                relation_type=relation_type,
                error=str(e),
            )
            raise

    async def debug_entity_relationships(self, entity_id: str) -> Dict[str, Any]:
        """Debug function to check what relationships an entity has.

        Args:
            entity_id: Entity to check

        Returns:
            Dictionary with relationship information
        """
        self.client._ensure_initialized()

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            relationships = {
                "entity_id": entity_id,
                "mentions": [],
                "relates_to": [],
                "has_label": [],
                "belongs_to": [],
                "total_relationships": 0,
            }

            # Check MENTIONS relationships
            mentions_query = """
                MATCH (m:Memory)-[r:MENTIONS]->(e:Entity {id: $entity_id})
                RETURN m.id as memory_id, r.confidence as confidence
            """
            result = self.conn.execute(mentions_query, {"entity_id": entity_id})
            for row in iter_rows(result):  # type: ignore
                relationships["mentions"].append(
                    {
                        "memory_id": row[0],  # type: ignore
                        "confidence": row[1],  # type: ignore
                    }
                )

            # Check RELATES_TO relationships
            relates_query = """
                MATCH (e1:Entity {id: $entity_id})-[r:RELATES_TO]-(e2:Entity)
                RETURN e2.id as related_entity_id, r.relation_type as relation_type, r.confidence as confidence
            """
            result = self.conn.execute(relates_query, {"entity_id": entity_id})
            for row in iter_rows(result):  # type: ignore
                relationships["relates_to"].append(
                    {
                        "related_entity_id": row[0],  # type: ignore
                        "relation_type": row[1],  # type: ignore
                        "confidence": row[2],  # type: ignore
                    }
                )

            # Check HAS_LABEL relationships
            labels_query = """
                MATCH (e:Entity {id: $entity_id})-[r:HAS_LABEL]->(l:Label)
                RETURN l.id as label_id, l.name as label_name
            """
            result = self.conn.execute(labels_query, {"entity_id": entity_id})
            for row in iter_rows(result):  # type: ignore
                relationships["has_label"].append(
                    {
                        "label_id": row[0],  # type: ignore
                        "label_name": row[1],  # type: ignore
                    }
                )

            # Check BELONGS_TO relationships
            community_query = """
                MATCH (e:Entity {id: $entity_id})-[r:BELONGS_TO]->(c:Community)
                RETURN c.community_id as community_id, c.name as community_name, r.strength as strength
            """
            result = self.conn.execute(community_query, {"entity_id": entity_id})
            for row in iter_rows(result):  # type: ignore
                relationships["belongs_to"].append(
                    {
                        "community_id": row[0],  # type: ignore
                        "community_name": row[1],  # type: ignore
                        "strength": row[2],  # type: ignore
                    }
                )

            # Calculate total relationships
            relationships["total_relationships"] = (
                len(relationships["mentions"])
                + len(relationships["relates_to"])
                + len(relationships["has_label"])
                + len(relationships["belongs_to"])
            )

            logger.info(
                "Entity relationship debug",
                entity_id=entity_id,
                total_relationships=relationships["total_relationships"],
                mentions=len(relationships["mentions"]),
                relates_to=len(relationships["relates_to"]),
                has_label=len(relationships["has_label"]),
                belongs_to=len(relationships["belongs_to"]),
            )

            return relationships

        except Exception as e:
            logger.error(
                "Failed to debug entity relationships",
                entity_id=entity_id,
                error=str(e),
            )
            return {
                "entity_id": entity_id,
                "error": str(e),
                "mentions": [],
                "relates_to": [],
                "has_label": [],
                "belongs_to": [],
                "total_relationships": 0,
            }

    async def delete_relationships_from_memory(self, memory_id: str) -> int:
        """Delete RELATES_TO relationships that were created from a specific memory.

        Args:
            memory_id: Memory ID to clean up relationships from

        Returns:
            Number of relationships deleted
        """
        self.client._ensure_initialized()

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            logger.debug(
                "Deleting relationships created from memory", memory_id=memory_id
            )

            # First, count the relationships to be deleted for logging
            count_query = """
                MATCH (e1:Entity)-[r:RELATES_TO]->(e2:Entity)
                WHERE r.source_reference = $memory_id
                RETURN count(r) as count
            """

            result = self.conn.execute(count_query, {"memory_id": memory_id})
            count_to_delete = 0
            with managed_result(result):
                if result.has_next():  # type: ignore
                    count_to_delete = result.get_next()[0]  # type: ignore

            logger.debug(
                "Found relationships to delete",
                memory_id=memory_id,
                count=count_to_delete,
            )

            if count_to_delete == 0:
                logger.debug(
                    "No relationships to delete from memory", memory_id=memory_id
                )
                return 0

            # Delete the relationships using proper KuzuDB syntax
            delete_query = """
                MATCH (e1:Entity)-[r:RELATES_TO]->(e2:Entity)
                WHERE r.source_reference = $memory_id
                DELETE r
            """

            self.conn.execute(delete_query, {"memory_id": memory_id})

            logger.info(
                "Deleted relationships from memory",
                memory_id=memory_id,
                deleted_count=count_to_delete,
            )
            return count_to_delete

        except Exception as e:
            logger.error(
                "Failed to delete relationships from memory",
                memory_id=memory_id,
                error=str(e),
            )
            return 0
