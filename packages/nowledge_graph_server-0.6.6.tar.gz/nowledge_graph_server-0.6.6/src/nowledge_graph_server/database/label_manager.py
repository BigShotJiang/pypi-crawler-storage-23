"""
Label Manager

Label operations including CRUD and memory-label relationships.
"""

from typing import List, Optional, Dict, Any
import structlog
from nowledge_graph_server.database.base_client import KuzuBaseClient
from nowledge_graph_server.database.result_utils import iter_rows, managed_result
import real_ladybug as kuzu
import datetime

logger = structlog.get_logger(__name__)


class LabelManager:
    """Manager for label-related operations."""

    def __init__(self, client: KuzuBaseClient):
        """Initialize with base client for database access."""
        self.client = client

    @property
    def conn(self):
        """Access database connection through client."""
        return self.client.conn

    async def list_labels(
        self,
        limit: int = 100,
        order_by: str = "name",
        order_desc: bool = False,
    ) -> List[Dict[str, Any]]:
        """List all labels with usage counts."""
        self.client._ensure_initialized() # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            order_direction = "DESC" if order_desc else "ASC"

            query = f"""
                MATCH (l:Label)
                OPTIONAL MATCH (l)<-[:HAS_LABEL]-(n)
                WITH l, COUNT(n) as usage_count
                RETURN l.id as id, l.name as name, l.color as color, 
                       l.description as description, l.created_at as created_at,
                       l.updated_at as updated_at, usage_count
                ORDER BY l.{order_by} {order_direction}
                LIMIT $limit
            """

            result = self.conn.execute(query, {"limit": limit})
            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

            labels = []
            for row in iter_rows(result):
                labels.append(
                    {
                        "id": row[0],  # type: ignore
                        "name": row[1],  # type: ignore
                        "color": row[2],  # type: ignore
                        "description": row[3],  # type: ignore
                        "created_at": row[4].isoformat()  # type: ignore
                        if isinstance(row[4], datetime.datetime)  # type: ignore
                        else str(row[4]),  # type: ignore
                        "updated_at": row[5].isoformat()  # type: ignore
                        if isinstance(row[5], datetime.datetime)  # type: ignore
                        else str(row[5]),  # type: ignore
                        "usage_count": row[6],  # type: ignore
                    }
                )

            return labels

        except Exception as e:
            logger.error("Failed to list labels", error=str(e))
            raise

    async def create_label(
        self,
        name: str,
        color: str = "#3b82f6",
        description: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a new label or return existing one if it already exists."""
        self.client._ensure_initialized() # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            label_id = f"label_{name.lower().replace(' ', '_')}"

            # First check if label already exists
            existing_query = """
                MATCH (l:Label {id: $label_id})
                OPTIONAL MATCH (l)<-[:HAS_LABEL]-(n)
                WITH l, COUNT(n) as usage_count
                RETURN l.id as id, l.name as name, l.color as color,
                       l.description as description, l.created_at as created_at,
                       l.updated_at as updated_at, usage_count
            """

            existing_result = self.conn.execute(existing_query, {"label_id": label_id})
            assert isinstance(existing_result, kuzu.QueryResult), (
                "existing_result is not a QueryResult"
            )

            with managed_result(existing_result):
                if existing_result.has_next():
                    # Label already exists, return it
                    row = existing_result.get_next()
                    logger.info(
                        "Label already exists, returning existing label",
                        label_id=label_id,
                        name=name,
                    )
                    return {
                        "id": row[0],  # type: ignore
                        "name": row[1],  # type: ignore
                        "color": row[2],  # type: ignore
                        "description": row[3],  # type: ignore
                        "created_at": row[4].isoformat()  # type: ignore
                        if isinstance(row[4], datetime.datetime)  # type: ignore
                        else str(row[4]),  # type: ignore
                        "updated_at": row[5].isoformat()  # type: ignore
                        if isinstance(row[5], datetime.datetime)  # type: ignore
                        else str(row[5]),  # type: ignore
                        "usage_count": row[6],  # type: ignore
                    }

            # Label doesn't exist, create it
            now = datetime.datetime.now(datetime.timezone.utc)

            query = """
                CREATE (l:Label {
                    id: $id,
                    name: $name,
                    color: $color,
                    description: $description,
                    created_at: $created_at,
                    updated_at: $updated_at,
                    metadata: $metadata
                })
                RETURN l
            """

            result = self.conn.execute(
                query,
                {
                    "id": label_id,
                    "name": name,
                    "color": color,
                    "description": description or "",
                    "created_at": now,
                    "updated_at": now,
                    "metadata": "{}",
                },
            )

            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

            with managed_result(result):
                if result.has_next():
                    label_data = result.get_next()[0]  # type: ignore
                    logger.info(
                        "Successfully created new label", label_id=label_id, name=name
                    )
                    return {
                        "id": label_data["id"],
                        "name": label_data["name"],
                        "color": label_data["color"],
                        "description": label_data["description"],
                        "created_at": label_data["created_at"].isoformat()
                        if isinstance(label_data["created_at"], datetime.datetime)
                        else str(label_data["created_at"]),
                        "updated_at": label_data["updated_at"].isoformat()
                        if isinstance(label_data["updated_at"], datetime.datetime)
                        else str(label_data["updated_at"]),
                        "usage_count": 0,
                    }

            raise RuntimeError("Failed to create label")

        except Exception as e:
            logger.error("Failed to create label", name=name, error=str(e))
            raise

    async def get_label_by_id(self, label_id: str) -> Optional[Dict[str, Any]]:
        """Get a specific label by ID."""
        self.client._ensure_initialized() # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            query = """
                MATCH (l:Label {id: $label_id})
                OPTIONAL MATCH (l)<-[:HAS_LABEL]-(n)
                WITH l, COUNT(n) as usage_count
                RETURN l.id as id, l.name as name, l.color as color,
                       l.description as description, l.created_at as created_at,
                       l.updated_at as updated_at, usage_count
            """

            result = self.conn.execute(query, {"label_id": label_id})
            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

            with managed_result(result):
                if result.has_next():
                    row = result.get_next()
                    return {
                        "id": row[0],  # type: ignore
                        "name": row[1],  # type: ignore
                        "color": row[2],  # type: ignore
                        "description": row[3],  # type: ignore
                        "created_at": row[4].isoformat()  # type: ignore
                        if isinstance(row[4], datetime.datetime)  # type: ignore
                        else str(row[4]),  # type: ignore
                        "updated_at": row[5].isoformat()  # type: ignore
                        if isinstance(row[5], datetime.datetime)  # type: ignore
                        else str(row[5]),  # type: ignore
                        "usage_count": row[6],  # type: ignore
                    }

            return None

        except Exception as e:
            logger.error("Failed to get label", label_id=label_id, error=str(e))
            raise

    async def update_label(
        self,
        label_id: str,
        name: Optional[str] = None,
        color: Optional[str] = None,
        description: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Update an existing label."""
        self.client._ensure_initialized() # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            # Build SET clause dynamically
            set_clauses = ["l.updated_at = $updated_at"]
            params = {
                "label_id": label_id,
                "updated_at": datetime.datetime.now(datetime.timezone.utc),
            }

            if name is not None:
                set_clauses.append("l.name = $name")
                params["name"] = name

            if color is not None:
                set_clauses.append("l.color = $color")
                params["color"] = color

            if description is not None:
                set_clauses.append("l.description = $description")
                params["description"] = description

            set_clause = ", ".join(set_clauses)

            query = f"""
                MATCH (l:Label {{id: $label_id}})
                SET {set_clause}
                RETURN l
            """

            result = self.conn.execute(query, params)
            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

            with managed_result(result):
                if result.has_next():
                    label_data = result.get_next()[0]  # type: ignore

                    # Get usage count
                    usage_query = """
                    MATCH (l:Label {id: $label_id})
                    OPTIONAL MATCH (l)<-[:HAS_LABEL]-(n)
                    RETURN COUNT(n) as usage_count
                """

                    usage_result = self.conn.execute(usage_query, {"label_id": label_id})
                    assert isinstance(usage_result, kuzu.QueryResult), (
                        "usage_result is not a QueryResult"
                    )

                    usage_count = 0
                    with managed_result(usage_result):
                        if usage_result.has_next():
                            usage_count = usage_result.get_next()[0]  # type: ignore

                    return {
                        "id": label_data["id"],
                        "name": label_data["name"],
                        "color": label_data["color"],
                        "description": label_data["description"],
                        "created_at": label_data["created_at"].isoformat()
                        if isinstance(label_data["created_at"], datetime.datetime)
                        else str(label_data["created_at"]),
                        "updated_at": label_data["updated_at"].isoformat()
                        if isinstance(label_data["updated_at"], datetime.datetime)
                        else str(label_data["updated_at"]),
                        "usage_count": usage_count,
                    }

            return None

        except Exception as e:
            logger.error("Failed to update label", label_id=label_id, error=str(e))
            raise

    async def delete_label(self, label_id: str) -> bool:
        """Delete a label and all its relationships."""
        self.client._ensure_initialized() # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            # Delete the label and all its relationships
            query = """
                MATCH (l:Label {id: $label_id})
                DETACH DELETE l
            """

            self.conn.execute(query, {"label_id": label_id})
            return True

        except Exception as e:
            logger.error("Failed to delete label", label_id=label_id, error=str(e))
            raise

    async def assign_label_to_memory(
        self,
        memory_id: str,
        label_name: str,
    ) -> str:
        """Create or find label and assign to memory via HAS_LABEL relationship."""
        self.client._ensure_initialized() # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            label_id = f"label_{label_name.lower().replace(' ', '_')}"
            now = datetime.datetime.now(datetime.timezone.utc)

            # First ensure label exists - use CREATE IF NOT EXISTS approach
            create_label_query = """
                MERGE (l:Label {id: $label_id})
                ON CREATE SET l.name = $label_name,
                             l.color = $default_color,
                             l.description = $description,
                             l.created_at = $created_at,
                             l.updated_at = $updated_at,
                             l.metadata = $metadata
                ON MATCH SET l.updated_at = $updated_at
                RETURN l
            """

            self.conn.execute(
                create_label_query,
                {
                    "label_id": label_id,
                    "label_name": label_name,
                    "default_color": "#3b82f6",
                    "description": "",
                    "created_at": now,
                    "updated_at": now,
                    "metadata": "{}",
                },
            )

            # Then create the HAS_LABEL relationship
            # Use ON CREATE SET for properties (not inline) to work correctly
            # with KuzuDB multi-FROM relationship tables.
            relationship_query = """
                MATCH (m:Memory {id: $memory_id}), (l:Label {id: $label_id})
                MERGE (m)-[r:HAS_LABEL]->(l)
                ON CREATE SET
                    r.assigned_by = $assigned_by,
                    r.created_at = $created_at,
                    r.properties = $properties
            """

            self.conn.execute(
                relationship_query,
                {
                    "memory_id": memory_id,
                    "label_id": label_id,
                    "assigned_by": "system",
                    "created_at": now,
                    "properties": "{}",
                },
            )

            return f"has_label_{memory_id}_{label_id}"

        except Exception as e:
            logger.error(
                "Failed to assign label to memory",
                memory_id=memory_id,
                label_name=label_name,
                error=str(e),
            )
            raise

    async def remove_label_from_memory(
        self,
        memory_id: str,
        label_id: str,
    ) -> bool:
        """Remove a label from a memory."""
        self.client._ensure_initialized() # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            query = """
                MATCH (m:Memory {id: $memory_id})-[r:HAS_LABEL]->(l:Label {id: $label_id})
                DELETE r
            """

            self.conn.execute(
                query,
                {
                    "memory_id": memory_id,
                    "label_id": label_id,
                },
            )

            return True

        except Exception as e:
            logger.error(
                "Failed to remove label from memory",
                memory_id=memory_id,
                label_id=label_id,
                error=str(e),
            )
            raise

    async def get_memory_labels(self, memory_id: str) -> List[Dict[str, Any]]:
        """Get all labels assigned to a memory."""
        self.client._ensure_initialized() # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            query = """
                MATCH (m:Memory {id: $memory_id})-[:HAS_LABEL]->(l:Label)
                RETURN l.id as id, l.name as name, l.color as color,
                       l.description as description
                ORDER BY l.name
            """

            result = self.conn.execute(query, {"memory_id": memory_id})
            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

            labels = []
            for row in iter_rows(result):
                labels.append(
                    {
                        "id": row[0],  # type: ignore
                        "name": row[1],  # type: ignore
                        "color": row[2],  # type: ignore
                        "description": row[3],  # type: ignore
                    }
                )

            return labels

        except Exception as e:
            logger.error(
                "Failed to get memory labels", memory_id=memory_id, error=str(e)
            )
            raise
