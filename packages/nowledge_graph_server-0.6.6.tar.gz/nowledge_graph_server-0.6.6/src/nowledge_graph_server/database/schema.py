"""KuzuDB schema definition for Nowledge Graph."""

from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, field
from enum import Enum


class ColumnType(Enum):
    """KuzuDB column types."""

    STRING = "STRING"
    INT64 = "INT64"
    DOUBLE = "DOUBLE"
    BOOLEAN = "BOOLEAN"
    TIMESTAMP = "TIMESTAMP"
    DATE = "DATE"
    FLOAT_ARRAY = "FLOAT[]"
    STRING_ARRAY = "STRING[]"


@dataclass
class Column:
    """Represents a table column."""

    name: str
    type: Union[ColumnType, str]  # Allow both enum and string for dynamic types
    nullable: bool = True
    default: Optional[Any] = None

    def to_sql(self) -> str:
        """Convert column to SQL definition."""
        type_value = self.type.value if isinstance(self.type, ColumnType) else self.type
        sql = f"{self.name} {type_value}"
        if self.default is not None:
            sql += f" DEFAULT {self.default}"
        return sql


@dataclass
class NodeTable:
    """Represents a KuzuDB node table."""

    name: str
    columns: List[Column]
    primary_key: str = "id"

    def to_sql(self) -> str:
        """Convert table to SQL CREATE statement."""
        columns_sql = ",\n            ".join(col.to_sql() for col in self.columns)
        return f"""CREATE NODE TABLE IF NOT EXISTS {self.name}(
            {columns_sql},
            PRIMARY KEY ({self.primary_key})
        )"""

    def get_column(self, name: str) -> Optional[Column]:
        """Get column by name."""
        for col in self.columns:
            if col.name == name:
                return col
        return None

    def has_column(self, name: str) -> bool:
        """Check if table has column."""
        return self.get_column(name) is not None


@dataclass
class RelationshipTable:
    """Represents a KuzuDB relationship table."""

    name: str
    from_table: str
    to_table: str
    properties: List[Column] = field(default_factory=list)

    def to_sql(self) -> str:
        """Convert relationship to SQL CREATE statement."""
        if self.properties:
            props_sql = ",\n            ".join(col.to_sql() for col in self.properties)
            return f"""CREATE REL TABLE IF NOT EXISTS {self.name}(
            FROM {self.from_table} TO {self.to_table},
            {props_sql}
        )"""
        else:
            return f"""CREATE REL TABLE IF NOT EXISTS {self.name}(
            FROM {self.from_table} TO {self.to_table}
        )"""

    def get_property(self, name: str) -> Optional[Column]:
        """Get property by name."""
        for prop in self.properties:
            if prop.name == name:
                return prop
        return None


@dataclass
class MultiFromRelationship:
    """Represents a KuzuDB relationship with multiple FROM-TO pairs."""

    name: str
    from_tables: List[str]
    to_table: str
    properties: List[Column] = field(default_factory=list)

    def to_sql(self) -> str:
        """Convert to SQL CREATE statement with multiple FROM-TO pairs."""
        from_to_pairs = ", ".join(
            f"FROM {from_table} TO {self.to_table}" for from_table in self.from_tables
        )

        if self.properties:
            props_sql = ",\n            ".join(col.to_sql() for col in self.properties)
            return f"""CREATE REL TABLE IF NOT EXISTS {self.name}(
            {from_to_pairs},
            {props_sql}
        )"""
        else:
            return f"""CREATE REL TABLE IF NOT EXISTS {self.name}(
            {from_to_pairs}
        )"""


@dataclass
class SchemaDefinition:
    """Complete schema definition."""

    node_tables: Dict[str, NodeTable] = field(default_factory=dict)
    relationship_tables: Dict[str, RelationshipTable] = field(default_factory=dict)
    multi_from_relationships: Dict[str, MultiFromRelationship] = field(
        default_factory=dict
    )

    def add_node_table(self, table: NodeTable) -> None:
        """Add a node table to the schema."""
        self.node_tables[table.name] = table

    def add_relationship_table(self, table: RelationshipTable) -> None:
        """Add a relationship table to the schema."""
        self.relationship_tables[table.name] = table

    def add_multi_from_relationship(self, relationship: MultiFromRelationship) -> None:
        """Add a multi-from relationship to the schema."""
        self.multi_from_relationships[relationship.name] = relationship

    def get_node_table(self, name: str) -> Optional[NodeTable]:
        """Get node table by name."""
        return self.node_tables.get(name)

    def get_relationship_table(self, name: str) -> Optional[RelationshipTable]:
        """Get relationship table by name."""
        return self.relationship_tables.get(name)

    def get_multi_from_relationship(self, name: str) -> Optional[MultiFromRelationship]:
        """Get multi-from relationship by name."""
        return self.multi_from_relationships.get(name)

    def to_sql_statements(self) -> List[str]:
        """Convert entire schema to SQL statements."""
        statements = []

        # Create node tables first
        for table in self.node_tables.values():
            statements.append(table.to_sql())

        # Create relationship tables
        for table in self.relationship_tables.values():
            statements.append(table.to_sql())

        # Create multi-from relationships
        for relationship in self.multi_from_relationships.values():
            statements.append(relationship.to_sql())

        return statements


def get_current_schema(embedding_dimension: int) -> SchemaDefinition:
    """Get the current schema definition."""
    schema = SchemaDefinition()

    # Define node tables
    schema.add_node_table(
        NodeTable(
            name="Thread",
            columns=[
                Column("id", ColumnType.STRING),
                Column("thread_id", ColumnType.STRING),
                Column("title", ColumnType.STRING),
                Column("summary", ColumnType.STRING),
                Column("message_count", ColumnType.INT64),
                Column("participants", ColumnType.STRING_ARRAY),
                Column("source", ColumnType.STRING),
                Column("created_at", ColumnType.TIMESTAMP),
                Column("updated_at", ColumnType.TIMESTAMP),
                Column("project", ColumnType.STRING),
                Column("workspace", ColumnType.STRING),
                Column("tool_version", ColumnType.STRING),
                Column("import_date", ColumnType.TIMESTAMP),
                Column("metadata", ColumnType.STRING),
            ],
        )
    )

    schema.add_node_table(
        NodeTable(
            name="Message",
            columns=[
                Column("id", ColumnType.STRING),
                Column("content", ColumnType.STRING),
                Column("role", ColumnType.STRING),
                Column("order_index", ColumnType.INT64),
                Column("timestamp", ColumnType.TIMESTAMP),
                Column("token_count", ColumnType.INT64),
                Column("created_at", ColumnType.TIMESTAMP),
                Column("updated_at", ColumnType.TIMESTAMP),
                Column("metadata", ColumnType.STRING),
            ],
        )
    )

    # Memory table - embedding column was dropped in migration 20260115_000000
    # Embeddings are now stored in LanceDB (1024-dim) instead of Kuzu (was 384-dim)
    schema.add_node_table(
        NodeTable(
            name="Memory",
            columns=[
                Column("id", ColumnType.STRING),
                Column("content", ColumnType.STRING),
                Column("title", ColumnType.STRING),
                Column("importance", ColumnType.DOUBLE),
                Column("confidence", ColumnType.DOUBLE),
                # Note: embedding column removed - stored in LanceDB now
                Column("source_range", ColumnType.STRING),
                Column(
                    "source", ColumnType.STRING, nullable=True
                ),  # Track source (cursor, chatwise, manual, etc.)
                Column("created_at", ColumnType.TIMESTAMP),
                Column("updated_at", ColumnType.TIMESTAMP),
                Column("metadata", ColumnType.STRING),
                Column("semantic_field", ColumnType.STRING, nullable=True),
                Column(
                    "reindex_needed", ColumnType.BOOLEAN, nullable=True, default="FALSE"
                ),
                Column("last_reindexed_at", ColumnType.TIMESTAMP, nullable=True),
                Column("community_id", ColumnType.INT64, nullable=True, default="NULL"),
                Column(
                    "pagerank_score", ColumnType.DOUBLE, nullable=True, default="0.0"
                ),
                Column("last_evaluated_at", ColumnType.TIMESTAMP, nullable=True),
            ],
        )
    )

    schema.add_node_table(
        NodeTable(
            name="Entity",
            columns=[
                Column("id", ColumnType.STRING),
                Column("name", ColumnType.STRING),
                Column("entity_type", ColumnType.STRING),
                Column("description", ColumnType.STRING),
                Column("aliases", ColumnType.STRING_ARRAY),
                Column("confidence", ColumnType.DOUBLE),
                Column("created_at", ColumnType.TIMESTAMP),
                Column("updated_at", ColumnType.TIMESTAMP),
                Column("metadata", ColumnType.STRING),
                Column("community_id", ColumnType.INT64, nullable=True, default="NULL"),
                Column(
                    "pagerank_score", ColumnType.DOUBLE, nullable=True, default="0.0"
                ),
            ],
        )
    )

    schema.add_node_table(
        NodeTable(
            name="Label",
            columns=[
                Column("id", ColumnType.STRING),
                Column("name", ColumnType.STRING),
                Column("color", ColumnType.STRING),
                Column("description", ColumnType.STRING),
                Column("created_at", ColumnType.TIMESTAMP),
                Column("updated_at", ColumnType.TIMESTAMP),
                Column("metadata", ColumnType.STRING),
            ],
        )
    )

    schema.add_node_table(
        NodeTable(
            name="Community",
            columns=[
                Column("id", ColumnType.STRING),  # Auto-generated UUID primary key
                Column(
                    "community_id", ColumnType.INT64
                ),  # Louvain algorithm community ID (updatable)
                Column("name", ColumnType.STRING),
                Column("description", ColumnType.STRING),
                Column("ai_summary", ColumnType.STRING),
                Column("member_count", ColumnType.INT64),
                Column("algorithm", ColumnType.STRING),
                Column("resolution", ColumnType.DOUBLE),
                Column("created_at", ColumnType.TIMESTAMP),
                Column("updated_at", ColumnType.TIMESTAMP),
            ],
            primary_key="id",  # Use string UUID as PK instead of community_id
        )
    )

    schema.add_node_table(
        NodeTable(
            name="Source",
            columns=[
                Column("id", ColumnType.STRING),
                Column("source_type", ColumnType.STRING),
                Column("original_name", ColumnType.STRING),
                Column("mime_type", ColumnType.STRING),
                Column("file_path", ColumnType.STRING),
                Column("parsed_path", ColumnType.STRING),
                Column("source_url", ColumnType.STRING),
                Column("sha256", ColumnType.STRING),
                Column("size_bytes", ColumnType.INT64, nullable=True, default="0"),
                Column("version", ColumnType.INT64, nullable=True, default="1"),
                Column(
                    "lifecycle_state", ColumnType.STRING, nullable=True, default="'ingested'"
                ),
                Column("chunk_count", ColumnType.INT64, nullable=True, default="0"),
                Column("memory_count", ColumnType.INT64, nullable=True, default="0"),
                Column("section_tree", ColumnType.STRING),
                Column("summary", ColumnType.STRING),
                Column("error_message", ColumnType.STRING),
                Column("created_at", ColumnType.TIMESTAMP),
                Column("updated_at", ColumnType.TIMESTAMP),
                Column("metadata", ColumnType.STRING),
            ],
        )
    )

    # Define relationship tables
    schema.add_relationship_table(
        RelationshipTable(
            name="CONTAINS",
            from_table="Thread",
            to_table="Message",
            properties=[
                Column("order_index", ColumnType.INT64),
                Column("created_at", ColumnType.TIMESTAMP),
                Column("properties", ColumnType.STRING),
            ],
        )
    )

    schema.add_relationship_table(
        RelationshipTable(
            name="COMPACTS_TO",
            from_table="Thread",
            to_table="Memory",
            properties=[
                Column("compaction_method", ColumnType.STRING),
                Column("created_at", ColumnType.TIMESTAMP),
                Column("properties", ColumnType.STRING),
            ],
        )
    )

    schema.add_relationship_table(
        RelationshipTable(
            name="EXTRACTED_FROM",
            from_table="Memory",
            to_table="Message",
            properties=[
                Column("extraction_confidence", ColumnType.DOUBLE),
                Column("created_at", ColumnType.TIMESTAMP),
                Column("properties", ColumnType.STRING),
            ],
        )
    )

    schema.add_relationship_table(
        RelationshipTable(
            name="MENTIONS",
            from_table="Memory",
            to_table="Entity",
            properties=[
                Column("confidence", ColumnType.DOUBLE),
                Column("mention_count", ColumnType.INT64),
                Column("created_at", ColumnType.TIMESTAMP),
                Column("properties", ColumnType.STRING),
            ],
        )
    )

    schema.add_relationship_table(
        RelationshipTable(
            name="RELATES_TO",
            from_table="Entity",
            to_table="Entity",
            properties=[
                Column("relation_type", ColumnType.STRING),
                Column("strength", ColumnType.DOUBLE),
                Column("confidence", ColumnType.DOUBLE),
                Column(
                    "context", ColumnType.STRING
                ),  # Raw context where relationship was extracted
                Column(
                    "conditions", ColumnType.STRING
                ),  # Conditions or constraints mentioned
                Column("temporal_info", ColumnType.STRING),  # Time/temporal information
                Column(
                    "source_reference", ColumnType.STRING
                ),  # Reference to source location
                Column("bidirectional", ColumnType.BOOLEAN),
                Column("created_at", ColumnType.TIMESTAMP),
                Column("properties", ColumnType.STRING),
                # Bi-temporal fields (added via migration 20251219_000000)
                Column("temporal_type", ColumnType.STRING),  # "exact"|"range"|"unknown"
                Column("rel_start", ColumnType.DATE),  # When relationship started
                Column("rel_end", ColumnType.DATE),  # When relationship ended
                Column("temporal_precision", ColumnType.STRING),  # "year"|"month"|"day"
                Column("is_ongoing", ColumnType.BOOLEAN),  # Whether relationship is active
                Column("temporal_confidence", ColumnType.DOUBLE),  # LLM confidence (0-1)
            ],
        )
    )

    schema.add_relationship_table(
        RelationshipTable(
            name="SOURCED_FROM",
            from_table="Memory",
            to_table="Source",
            properties=[
                Column("chunk_index", ColumnType.INT64),
                Column("chunk_range", ColumnType.STRING),
                Column("source_version", ColumnType.INT64),
                Column("created_at", ColumnType.TIMESTAMP),
            ],
        )
    )

    schema.add_relationship_table(
        RelationshipTable(
            name="REVISED_AS",
            from_table="Source",
            to_table="Source",
            properties=[
                Column("diff_summary", ColumnType.STRING),
                Column("sections_changed", ColumnType.STRING),
                Column("revision_type", ColumnType.STRING),
                Column("detected_by", ColumnType.STRING),
                Column("created_at", ColumnType.TIMESTAMP),
            ],
        )
    )

    # CONSOLIDATED: Single HAS_LABEL table with multiple FROM-TO pairs
    schema.add_multi_from_relationship(
        MultiFromRelationship(
            name="HAS_LABEL",
            from_tables=["Thread", "Memory", "Entity"],
            to_table="Label",
            properties=[
                Column("assigned_by", ColumnType.STRING),
                Column("created_at", ColumnType.TIMESTAMP),
                Column("properties", ColumnType.STRING),
            ],
        )
    )

    schema.add_relationship_table(
        RelationshipTable(
            name="BELONGS_TO",
            from_table="Entity",
            to_table="Community",
            properties=[
                Column("strength", ColumnType.DOUBLE),
                Column("created_at", ColumnType.TIMESTAMP),
                Column("properties", ColumnType.STRING),
            ],
        )
    )

    return schema


# Get the current schema instance - now configurable
def get_schema_instance(embedding_dimension: int = 384) -> SchemaDefinition:
    """Get a schema instance with the specified embedding dimension."""
    return get_current_schema(embedding_dimension)


# SQL statements for initialization - now dynamic
def get_init_sequence(embedding_dimension: int = 384) -> List[str]:
    """Get SQL initialization statements for the specified embedding dimension."""
    return get_current_schema(embedding_dimension).to_sql_statements()


def get_schema_version() -> str:
    """Get the current schema version."""
    return "1.0.0"


def get_current_schema_definition(embedding_dimension: int = 384) -> SchemaDefinition:
    """Get the current schema definition object."""
    return get_current_schema(embedding_dimension)


def get_node_table_definition(
    table_name: str, embedding_dimension: int = 384
) -> Optional[NodeTable]:
    """Get node table definition by name."""
    return get_current_schema(embedding_dimension).get_node_table(table_name)


def get_relationship_table_definition(
    table_name: str, embedding_dimension: int = 384
) -> Optional[RelationshipTable]:
    """Get relationship table definition by name."""
    return get_current_schema(embedding_dimension).get_relationship_table(table_name)


def validate_schema_compatibility(kuzu_version: str) -> bool:
    """Validate schema compatibility with KuzuDB version."""
    # Add version compatibility checks as needed
    return True


def get_table_names(embedding_dimension: int = 384) -> Dict[str, List[str]]:
    """Get lists of node and relationship table names."""
    schema = get_current_schema(embedding_dimension)
    return {
        "nodes": list(schema.node_tables.keys()),
        "relationships": list(schema.relationship_tables.keys()),
        "multi_from_relationships": list(schema.multi_from_relationships.keys()),
    }


# Backward compatibility - use default 384 dimensions
_current_schema = get_current_schema(embedding_dimension=384)
INIT_SEQUENCE = get_init_sequence(embedding_dimension=384)

# Common query patterns for the application
COMMON_QUERIES = {
    "find_thread_messages": """
        MATCH (t:Thread {thread_id: $thread_id})-[c:CONTAINS]->(m:Message)
        RETURN m ORDER BY c.order_index
    """,
    "find_memory_entities": """
        MATCH (mem:Memory {id: $memory_id})-[men:MENTIONS]->(e:Entity)
        RETURN e, men.confidence ORDER BY men.confidence DESC
    """,
    "find_related_memories": """
        MATCH (m1:Memory {id: $memory_id})-[:MENTIONS]->(e:Entity)<-[:MENTIONS]-(m2:Memory)
        WHERE m1.id <> m2.id
        RETURN m2, COUNT(e) as shared_entities
        ORDER BY shared_entities DESC
        LIMIT $limit
    """,
    "find_entity_relationships": """
        MATCH (e1:Entity {id: $entity_id})-[r:RELATES_TO]->(e2:Entity)
        RETURN e2, r.relation_type, r.strength
        ORDER BY r.strength DESC
    """,
    "find_thread_by_participant": """
        MATCH (t:Thread)
        WHERE $participant IN t.participants
        RETURN t ORDER BY t.updated_at DESC
        LIMIT $limit
    """,
    "find_memories_by_label": """
        MATCH (m:Memory)-[:HAS_LABEL]->(l:Label {name: $label_name})
        RETURN m ORDER BY m.importance DESC, m.created_at DESC
        LIMIT $limit
    """,
    "get_community_entities": """
        MATCH (e:Entity)-[b:BELONGS_TO]->(c:Community {id: $community_id})
        RETURN e, b.strength ORDER BY b.strength DESC
    """,
    # Vector similarity search for memories using KuzuDB vector extension
    "search_memories_by_embedding": """
        CALL QUERY_VECTOR_INDEX(
            'Memory',
            'memory_embedding_idx_new',
            $query_embedding,
            $limit
        )
        RETURN node as m, distance
        ORDER BY distance ASC
    """,
    # Full-text search for memories
    "fts_memory_search": """
        CALL QUERY_FTS_INDEX(
            'Memory',
            'memory_semantic_index',
            $text_query
        )
        RETURN node as m, score
        ORDER BY score DESC, m.importance DESC
        LIMIT $limit
    """,
    # Full-text search for entities
    "fts_entity_search": """
        CALL QUERY_FTS_INDEX(
            'Entity',
            'entity_content_index',
            $text_query
        )
        RETURN node as e, score
        ORDER BY score DESC, e.confidence DESC
        LIMIT $limit
    """,
    # Full-text search for threads
    "fts_thread_search": """
        CALL QUERY_FTS_INDEX(
            'Thread',
            'thread_content_index',
            $text_query
        )
        RETURN node as t, score
        ORDER BY score DESC, t.created_at DESC
        LIMIT $limit
    """,
    # Full-text search for messages
    "fts_message_search": """
        CALL QUERY_FTS_INDEX(
            'Message',
            'message_content_fts',
            $text_query
        )
        RETURN node as m, score
        ORDER BY score DESC
        LIMIT $limit
    """,
    # Note: Relationship FTS search not available - KuzuDB FTS only supports node tables
    # Enhanced hybrid search combining vector similarity and FTS
}

# Schema validation queries
VALIDATION_QUERIES = {
    "check_tables": """
        CALL show_tables() RETURN *
    """,
    "check_nodes": """
        CALL show_tables() RETURN name 
        WHERE type = 'NODE'
    """,
    "check_relationships": """
        CALL show_tables() RETURN name 
        WHERE type = 'REL'
    """,
    "check_node_count": """
        MATCH (n) 
        RETURN COUNT(n) as count
    """,
    "check_relationship_count": """
        MATCH ()-[r]-() 
        RETURN COUNT(r) as count
    """,
    "check_memory_embeddings": """
        MATCH (m:Memory) 
        WHERE m.embedding IS NOT NULL 
        RETURN COUNT(m) as count
    """,
}
