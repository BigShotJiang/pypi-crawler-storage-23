"""
KuzuDB Client - Refactored

Main client class that composes all repository classes for a clean API.
This replaces the monolithic kuzu_client.py with a modular approach.
"""

from pathlib import Path
from typing import Any, Dict, Optional, cast
import structlog

import real_ladybug as kuzu

from nowledge_graph_server.database.base_client import KuzuBaseClient
from nowledge_graph_server.database.memory_repository import MemoryRepository
from nowledge_graph_server.database.thread_repository import ThreadRepository
from nowledge_graph_server.database.entity_repository import EntityRepository
from nowledge_graph_server.database.source_repository import SourceRepository
from nowledge_graph_server.database.relationship_manager import RelationshipManager
from nowledge_graph_server.database.search_engine import KuzuSearchEngine
from nowledge_graph_server.database.label_manager import LabelManager
from nowledge_graph_server.database.favorites_manager import FavoritesManager
from nowledge_graph_server.models.graph import MemoryNode

logger = structlog.get_logger(__name__)


class KuzuClient:
    """
    Main KuzuDB client that provides access to all database operations.

    This class composes repository classes to provide a clean, modular API
    while maintaining backward compatibility with the existing interface.
    """

    base_client: KuzuBaseClient
    memory_repo: MemoryRepository
    thread_repo: ThreadRepository
    entity_repo: EntityRepository
    source_repo: SourceRepository
    relationship_mgr: RelationshipManager
    search_engine: KuzuSearchEngine
    label_mgr: LabelManager
    favorites_mgr: FavoritesManager

    def __init__(self, db_path: Path, embedding_dimension: int = 384):
        """Initialize client with repository composition."""
        self.base_client = KuzuBaseClient(db_path, embedding_dimension)
        self.memory_repo = MemoryRepository(self.base_client)
        self.thread_repo = ThreadRepository(self.base_client)
        self.entity_repo = EntityRepository(self.base_client)
        self.source_repo = SourceRepository(self.base_client)
        self.relationship_mgr = RelationshipManager(self.base_client)
        self.search_engine = KuzuSearchEngine(self.base_client)
        self.label_mgr = LabelManager(self.base_client)
        self.favorites_mgr = FavoritesManager(self.base_client)
    # =====================================
    # Core Client Methods (delegate to base_client)
    # =====================================

    @property
    def conn(self) -> kuzu.Connection | None:
        """Access to database connection."""
        return cast(kuzu.Connection | None, self.base_client.conn)  # type: ignore[attr-defined]

    @property
    def _initialized(self) -> bool:
        """Check if the client is initialized."""
        return self.base_client._initialized # type: ignore

    async def initialize(self) -> None:
        """Initialize the database."""
        await self.base_client.initialize()

    async def close(self) -> None:
        """Close the database connection."""
        await self.base_client.close()

    async def test_connection(self) -> Dict[str, Any]:
        """Test database connection."""
        return await self.base_client.test_connection()

    # =====================================
    # Memory Operations (delegate to memory_repo)
    # =====================================

    async def create_memory(self, memory_node: MemoryNode) -> Any:
        """Create a new memory."""
        return await self.memory_repo.create_memory(memory_node)

    async def update_memory(self, memory: MemoryNode) -> Any:
        """Update a memory."""
        return await self.memory_repo.update_memory(memory)

    async def list_memories(self, **kwargs: Any) -> Any:
        """List memories with filtering."""
        return await self.memory_repo.list_memories(**kwargs)

    async def count_memories(self, **kwargs: Any) -> int:
        """Count memories."""
        return await self.memory_repo.count_memories(**kwargs)

    async def get_memory_by_id(self, memory_id: str) -> Optional[Any]:
        """Get memory by ID."""
        return await self.memory_repo.get_memory_by_id(memory_id)

    async def delete_memory(self, memory_id: str) -> bool:
        """Delete a memory."""
        return await self.memory_repo.delete_memory(memory_id)

    # Add more memory methods as needed...

    # =====================================
    # Thread Operations (delegate to thread_repo)
    # =====================================

    async def create_thread(self, **kwargs: Any) -> Any:
        """Create a new thread."""
        return await self.thread_repo.create_thread(**kwargs)

    async def fetch_thread(self, thread_id: str) -> Optional[Any]:
        """Fetch a thread."""
        return await self.thread_repo.fetch_thread(thread_id)

    async def list_threads(self, **kwargs: Any) -> Any:
        """List threads."""
        return await self.thread_repo.list_threads(**kwargs)

    # Add more thread methods as needed...

    # =====================================
    # Search Operations (delegate to search_engine)
    # =====================================

    async def search_memories(self, **kwargs: Any) -> Any:
        """Search memories."""
        return await self.search_engine.search_memories(**kwargs)

    # async def hybrid_search_memories(self, **kwargs) -> Any:
    #     """Hybrid search memories."""
    #     return await self.search_engine.hybrid_search_memories(**kwargs)

    # Add more search methods as needed...

    # =====================================
    # Label Operations (delegate to label_mgr)
    # =====================================

    async def list_labels(self, **kwargs: Any) -> Any:
        """List labels."""
        return await self.label_mgr.list_labels(**kwargs)

    async def create_label(self, **kwargs: Any) -> Any:
        """Create a label."""
        return await self.label_mgr.create_label(**kwargs)

    # Add more label methods as needed...

    # =====================================
    # Favorites Operations (delegate to favorites_mgr)
    # =====================================

    async def toggle_memory_favorite(self, memory_id: str, is_favorite: bool) -> bool:
        """Toggle memory favorite."""
        return await self.favorites_mgr.toggle_memory_favorite(memory_id, is_favorite)

    async def get_favorite_memories(self, limit: int = 50) -> Any:
        """Get favorite memories."""
        return await self.favorites_mgr.get_favorite_memories(limit)

    # Add more favorites methods as needed...

    # =====================================
    # Relationship Operations (delegate to relationship_mgr)
    # =====================================

    async def create_thread_memory_relationship(self, **kwargs: Any) -> str:
        """Create thread-memory relationship."""
        return await self.relationship_mgr.create_thread_memory_relationship(**kwargs)

    # Add more relationship methods as needed...

    # =====================================
    # Entity Operations (delegate to entity_repo)
    # =====================================

    async def create_or_find_entity(self, entity_node: Any) -> Any:
        """Create or find entity."""
        return await self.entity_repo.create_or_find_entity(entity_node)

    # Add more entity methods as needed...

    # =====================================
    # Backward Compatibility Methods
    # =====================================

    def _serialize_metadata(self, metadata: Dict[str, Any]) -> str:
        """Serialize metadata (backward compatibility)."""
        return self.base_client._serialize_metadata(metadata)  # type: ignore[attr-defined]

    def _deserialize_metadata(self, metadata_str: str) -> Dict[str, Any]:
        """Deserialize metadata (backward compatibility)."""
        return self.base_client._deserialize_metadata(metadata_str)  # type: ignore[attr-defined]

    # Add more compatibility methods as needed...
