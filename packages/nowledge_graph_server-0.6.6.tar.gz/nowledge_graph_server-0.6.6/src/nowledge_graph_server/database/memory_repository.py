"""
Memory Repository

All memory-related database operations including CRUD, search, and management.
"""

from typing import List, Optional, Dict, Any, cast
import datetime
import structlog
import json
import real_ladybug as kuzu

from nowledge_graph_server.models.graph import MemoryNode
from nowledge_graph_server.database.base_client import (
    KuzuBaseClient,
    build_kuzu_params, # type: ignore[attr-defined]
)
from nowledge_graph_server.database.result_utils import close_kuzu_result, iter_rows, managed_result
from nowledge_graph_server.database.memory_deletion import MemoryDeletionManager
from nowledge_graph_server.database.version_upgrade.db_version_manager import get_db_version

logger = structlog.get_logger(__name__)

# Default embedding dimension for Kuzu schema (v0/v1 legacy)
# For v2+ databases, LanceDB handles vector search with 1024-dim embeddings
KUZU_EMBEDDING_DIMENSION = 384


def _check_embedding_column_exists(conn: "kuzu.Connection") -> bool:
    """Check if the Memory table has an embedding column.

    After the 20260115_000000 migration, the embedding column is dropped.
    This function caches the result to avoid repeated queries.
    """
    try:
        # Query table info to check for embedding column
        result = conn.execute("CALL table_info('Memory') RETURN *")
        for row in iter_rows(result):
            if row and len(row) > 1:
                col_name = str(row[1]).lower() if row[1] else ""
                if col_name == "embedding":
                    return True
        return False
    except Exception as e:
        logger.debug("Could not check for embedding column", error=str(e))
        # Assume column exists if we can't check (safer for older databases)
        return True


class MemoryRepository:
    """Repository for memory-related database operations."""

    def __init__(self, client: KuzuBaseClient):
        """Initialize with base client for database access."""
        self.client = client
        self._deletion = MemoryDeletionManager(client)

    @property
    def conn(self) -> kuzu.Connection | None:
        """Access database connection through client."""
        return cast(kuzu.Connection | None, self.client.conn)  # type: ignore[attr-defined]

    async def create_memory(self, memory_node: MemoryNode) -> MemoryNode:
        """Create a new memory node.

        Note: For v2+ databases with the slim schema migration applied,
        the embedding column has been dropped. Embeddings are stored in LanceDB.
        For older databases, we pass a placeholder or the actual embedding.
        """
        self.client._ensure_initialized() # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            # Check if the embedding column exists (dropped after 20260115 migration)
            has_embedding_column = _check_embedding_column_exists(self.conn)

            if has_embedding_column:
                # Embedding column exists - determine what to store
                db_version = get_db_version(self.client.db_path)
                if db_version >= 2:
                    # v2+ uses LanceDB for search - pass NULL to save storage
                    kuzu_embedding = None
                elif memory_node.embedding and len(memory_node.embedding) == KUZU_EMBEDDING_DIMENSION:
                    # v0/v1 with correct dimension - use actual embedding
                    kuzu_embedding = memory_node.embedding
                else:
                    # v0/v1 but dimension mismatch - use placeholder
                    logger.warning(
                        "Embedding dimension mismatch for v0/v1 database",
                        expected=KUZU_EMBEDDING_DIMENSION,
                        actual=len(memory_node.embedding) if memory_node.embedding else 0,
                        memory_id=memory_node.id,
                    )
                    kuzu_embedding = [0.0] * KUZU_EMBEDDING_DIMENSION

                # Query WITH embedding column
                memory_query = """
                    CREATE (m:Memory {
                        id: $id,
                        content: $content,
                        title: $title,
                        importance: $importance,
                        confidence: $confidence,
                        embedding: $embedding,
                        source: $source,
                        source_range: $source_range,
                        created_at: $created_at,
                        updated_at: $updated_at,
                        metadata: $metadata,
                        semantic_field: $semantic_field,
                        reindex_needed: $reindex_needed,
                        last_reindexed_at: $last_reindexed_at,
                        last_accessed_at: $last_accessed_at,
                        access_count: $access_count,
                        appearances: $appearances,
                        clicks: $clicks,
                        total_dwell_time_ms: $total_dwell_time_ms,
                        last_clicked_at: $last_clicked_at,
                        decay_score_cached: $decay_score_cached,
                        temporal_context: $temporal_context,
                        temporal_type: $temporal_type,
                        event_start: $event_start,
                        event_end: $event_end,
                        temporal_precision: $temporal_precision,
                        temporal_confidence: $temporal_confidence,
                        unit_type: $unit_type,
                        is_latest: $is_latest,
                        version: $version,
                        is_crystal: $is_crystal,
                        crystal_title: $crystal_title,
                        source_unit_count: $source_unit_count,
                        extraction_method: $extraction_method
                    })
                """
                params = {
                    "id": memory_node.id,
                    "content": memory_node.content,
                    "title": memory_node.title,
                    "importance": memory_node.importance,
                    "confidence": memory_node.confidence,
                    "embedding": kuzu_embedding,
                    "source": memory_node.source,
                    "source_range": json.dumps(memory_node.source_range)
                    if memory_node.source_range
                    else None,
                    "created_at": memory_node.created_at,
                    "updated_at": memory_node.updated_at,
                    "metadata": self.client._serialize_metadata(memory_node.metadata),  # type: ignore[attr-defined]
                    "semantic_field": memory_node.semantic_field,
                    "reindex_needed": memory_node.reindex_needed,
                    "last_reindexed_at": memory_node.last_reindexed_at,
                    "last_accessed_at": memory_node.last_accessed_at or memory_node.created_at,
                    "access_count": memory_node.access_count,
                    "appearances": memory_node.appearances,
                    "clicks": memory_node.clicks,
                    "total_dwell_time_ms": memory_node.total_dwell_time_ms,
                    "last_clicked_at": memory_node.last_clicked_at,
                    "decay_score_cached": memory_node.decay_score_cached,
                    "temporal_context": memory_node.temporal_context,
                    "temporal_type": memory_node.temporal_type,
                    "event_start": memory_node.event_start,
                    "event_end": memory_node.event_end,
                    "temporal_precision": memory_node.temporal_precision,
                    "temporal_confidence": memory_node.temporal_confidence,
                    "unit_type": memory_node.unit_type,
                    "is_latest": memory_node.is_latest,
                    "version": memory_node.version,
                    "is_crystal": memory_node.is_crystal,
                    "crystal_title": memory_node.crystal_title,
                    "source_unit_count": memory_node.source_unit_count,
                    "extraction_method": memory_node.extraction_method,
                }
            else:
                # Embedding column dropped (slim schema) - query WITHOUT embedding
                memory_query = """
                    CREATE (m:Memory {
                        id: $id,
                        content: $content,
                        title: $title,
                        importance: $importance,
                        confidence: $confidence,
                        source: $source,
                        source_range: $source_range,
                        created_at: $created_at,
                        updated_at: $updated_at,
                        metadata: $metadata,
                        semantic_field: $semantic_field,
                        reindex_needed: $reindex_needed,
                        last_reindexed_at: $last_reindexed_at,
                        last_accessed_at: $last_accessed_at,
                        access_count: $access_count,
                        appearances: $appearances,
                        clicks: $clicks,
                        total_dwell_time_ms: $total_dwell_time_ms,
                        last_clicked_at: $last_clicked_at,
                        decay_score_cached: $decay_score_cached,
                        temporal_context: $temporal_context,
                        temporal_type: $temporal_type,
                        event_start: $event_start,
                        event_end: $event_end,
                        temporal_precision: $temporal_precision,
                        temporal_confidence: $temporal_confidence,
                        unit_type: $unit_type,
                        is_latest: $is_latest,
                        version: $version,
                        is_crystal: $is_crystal,
                        crystal_title: $crystal_title,
                        source_unit_count: $source_unit_count,
                        extraction_method: $extraction_method
                    })
                """
                params = {
                    "id": memory_node.id,
                    "content": memory_node.content,
                    "title": memory_node.title,
                    "importance": memory_node.importance,
                    "confidence": memory_node.confidence,
                    "source": memory_node.source,
                    "source_range": json.dumps(memory_node.source_range)
                    if memory_node.source_range
                    else None,
                    "created_at": memory_node.created_at,
                    "updated_at": memory_node.updated_at,
                    "metadata": self.client._serialize_metadata(memory_node.metadata),  # type: ignore[attr-defined]
                    "semantic_field": memory_node.semantic_field,
                    "reindex_needed": memory_node.reindex_needed,
                    "last_reindexed_at": memory_node.last_reindexed_at,
                    "last_accessed_at": memory_node.last_accessed_at or memory_node.created_at,
                    "access_count": memory_node.access_count,
                    "appearances": memory_node.appearances,
                    "clicks": memory_node.clicks,
                    "total_dwell_time_ms": memory_node.total_dwell_time_ms,
                    "last_clicked_at": memory_node.last_clicked_at,
                    "decay_score_cached": memory_node.decay_score_cached,
                    "temporal_context": memory_node.temporal_context,
                    "temporal_type": memory_node.temporal_type,
                    "event_start": memory_node.event_start,
                    "event_end": memory_node.event_end,
                    "temporal_precision": memory_node.temporal_precision,
                    "temporal_confidence": memory_node.temporal_confidence,
                    "unit_type": memory_node.unit_type,
                    "is_latest": memory_node.is_latest,
                    "version": memory_node.version,
                    "is_crystal": memory_node.is_crystal,
                    "crystal_title": memory_node.crystal_title,
                    "source_unit_count": memory_node.source_unit_count,
                    "extraction_method": memory_node.extraction_method,
                }

            self.conn.execute(memory_query, params)

            return memory_node

        except Exception as e:
            logger.error(
                "Failed to create memory", memory_id=memory_node.id, error=str(e)
            )
            raise

    async def update_memory(self, memory: MemoryNode) -> MemoryNode:
        """Update an existing memory."""
        self.client._ensure_initialized() # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            # Update memory content/title without changing semantic_field
            # This allows editing without triggering index updates since semantic_field stays unchanged
            query = """
                MATCH (m:Memory {id: $id})
                SET m.content = $content,
                    m.title = $title,
                    m.importance = $importance,
                    m.confidence = $confidence,
                    m.source = $source,
                    m.source_range = $source_range,
                    m.updated_at = $updated_at,
                    m.reindex_needed = $reindex_needed
                RETURN m
            """

            self.conn.execute(
                query,
                {
                    "id": memory.id,
                    "content": memory.content,
                    "title": memory.title,
                    "importance": memory.importance,
                    "confidence": memory.confidence,
                    "source": memory.source,
                    "source_range": json.dumps(memory.source_range)
                    if memory.source_range
                    else None,
                    "updated_at": memory.updated_at,
                    "reindex_needed": True,  # Mark for reindexing when content/title changes
                },
            )

            return memory

        except Exception as e:
            logger.error("Failed to update memory", memory_id=memory.id, error=str(e))
            raise

    async def update_memory_importance(self, memory_id: str, importance: float) -> bool:
        """Update only the importance of a memory, avoiding content field index issues."""
        self.client._ensure_initialized() # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            # Only update importance and updated_at, avoid content field with indexes
            query = """
                MATCH (m:Memory {id: $id})
                SET m.importance = $importance,
                    m.updated_at = $updated_at
                RETURN m.importance
            """

            result = self.conn.execute(
                query,
                {
                    "id": memory_id,
                    "importance": importance,
                    "updated_at": datetime.datetime.now(datetime.timezone.utc),
                },
            )
            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"
            with managed_result(result):
                return result.has_next()  # Returns True if memory was found and updated

        except Exception as e:
            logger.error(
                "Failed to update memory importance", memory_id=memory_id, error=str(e)
            )
            raise

    # NOTE: update_memory_embeddings removed - KuzuDB doesn't support updating indexed fields
    # We use delete-and-recreate approach in memory_operations.py instead

    async def get_memories_needing_reindex(
        self, limit: int = 100, offset: int = 0
    ) -> List[MemoryNode]:
        """Get memories that need reindexing (reindex_needed=True)."""
        self.client._ensure_initialized() # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            query = """
                MATCH (m:Memory)
                WHERE m.reindex_needed = true
                RETURN m
                ORDER BY m.updated_at DESC
                SKIP $offset LIMIT $limit
            """

            params = {
                "offset": offset,
                "limit": limit,
            }

            logger.debug("Getting memories needing reindex", params=params)
            result = self.conn.execute(query, params)
            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

            memories: List[MemoryNode] = []
            for row in iter_rows(result):
                try:
                    memory_data = row[0]  # type: ignore

                    # Parse metadata safely
                    metadata: dict[str, Any] = {}
                    try:
                        metadata = self.client._deserialize_metadata( # type: ignore[attr-defined]
                            memory_data.get("metadata", "{}")
                        )
                    except Exception as e:
                        logger.warning(
                            "Failed to parse memory metadata",
                            memory_id=memory_data["id"],
                            error=str(e),
                        )

                    memory = MemoryNode(
                        id=memory_data["id"],
                        content=memory_data["content"],
                        title=memory_data["title"],
                        importance=memory_data["importance"],
                        confidence=memory_data["confidence"],
                        embedding=list(memory_data["embedding"])
                        if memory_data.get("embedding")
                        else [],
                        source=memory_data["source"],
                        source_range=json.loads(memory_data["source_range"])
                        if memory_data.get("source_range")
                        else None,
                        created_at=self.client._safe_parse_datetime( # type: ignore[arg-type]
                            memory_data["created_at"]
                        )
                        or datetime.datetime.now(datetime.timezone.utc),
                        updated_at=self.client._safe_parse_datetime( # type: ignore[attr-defined]
                            memory_data["updated_at"]
                        )
                        or datetime.datetime.now(datetime.timezone.utc),
                        metadata=metadata, # type: ignore[arg-type]
                        semantic_field=f"{memory_data['title']},\n{memory_data['content']}",
                        last_reindexed_at=self.client._safe_parse_datetime( # type: ignore[attr-defined]
                            memory_data["last_reindexed_at"]
                        ),
                        reindex_needed=memory_data["reindex_needed"],
                        # Knowledge Agent fields (v0.6)
                        unit_type=memory_data.get("unit_type", "fact"),
                        is_latest=memory_data.get("is_latest", True),
                        version=memory_data.get("version", 1),
                        is_crystal=memory_data.get("is_crystal", False),
                        crystal_title=memory_data.get("crystal_title"),
                        source_unit_count=memory_data.get("source_unit_count"),
                        extraction_method=memory_data.get("extraction_method", "manual"),
                    )
                    memories.append(memory)

                except Exception as e:
                    logger.error("Failed to process memory row", error=str(e))
                    continue  # Skip corrupted rows

            logger.debug(f"Found {len(memories)} memories needing reindex")
            return memories

        except Exception as e:
            logger.error("Failed to get memories needing reindex", error=str(e))
            return []

    async def count_memories_needing_reindex(self) -> int:
        """Count memories that need reindexing."""
        self.client._ensure_initialized() # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            query = """
                MATCH (m:Memory)
                WHERE m.reindex_needed = true
                RETURN COUNT(m) as count
            """

            result = self.conn.execute(query, {})
            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"
            with managed_result(result):
                if not result.has_next():
                    return 0

                return result.get_next()[0]  # type: ignore
        except Exception as e:
            logger.error(f"Failed to count memories needing reindex: {e}")
            return 0

    async def list_memories(
        self,
        limit: int = 20,
        offset: int = 0,
        state: str = "active",
        importance_min: float = 0.0,
        created_after: Optional[datetime.datetime] = None,
        labels: Optional[List[str]] = None,
    ) -> List[MemoryNode]:
        """List memories with filtering and pagination - simplified to avoid hangs."""
        self.client._ensure_initialized() # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            # logger.debug(
            #     "Starting memory listing", limit=limit, offset=offset, state=state
            # )

            # Simplified query - avoid complex metadata filtering that can hang
            # We'll filter by importance only, then handle state filtering in Python
            query = """
                MATCH (m:Memory)
                WHERE m.importance >= $importance_min
                RETURN m
                ORDER BY m.created_at DESC
                SKIP $offset LIMIT $limit
            """

            params = {
                "importance_min": importance_min,
                "offset": offset,
                "limit": limit,
            }

            # logger.debug("Executing memory query", query=query[:100], params=params)
            result = self.conn.execute(query, params)
            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

            memories: List[MemoryNode] = []
            row_count = 0
            for row in iter_rows(result):
                try:
                    memory_data = row[0]  # type: ignore
                    row_count += 1
                    # logger.debug(
                    #     f"Processing memory row {row_count}: {memory_data['id']}"
                    # )

                    # Parse metadata safely
                    metadata: dict[str, Any] = {}
                    try:
                        metadata = self.client._deserialize_metadata( # type: ignore[attr-defined]
                            memory_data.get("metadata", "{}")
                        )
                    except Exception as e:
                        logger.warning(
                            "Failed to parse memory metadata",
                            memory_id=memory_data["id"],
                            error=str(e),
                        )

                    # Apply state filtering in Python (safer than Cypher CONTAINS)
                    memory_state = metadata.get("state", "active") # type: ignore[arg-type]
                    if state != "all" and memory_state != state:
                        continue

                    memory = MemoryNode(
                        id=memory_data["id"],
                        content=memory_data["content"],
                        title=memory_data["title"],
                        importance=memory_data["importance"],
                        confidence=memory_data["confidence"],
                        embedding=list(memory_data["embedding"])
                        if memory_data.get("embedding")
                        else [],
                        source=memory_data["source"],
                        source_range=json.loads(memory_data["source_range"])
                        if memory_data.get("source_range")
                        else None,
                        created_at=self.client._safe_parse_datetime( # type: ignore[arg-type]
                            memory_data["created_at"]
                        )
                        or datetime.datetime.now(datetime.timezone.utc),
                        updated_at=self.client._safe_parse_datetime( # type: ignore[arg-type]
                            memory_data["updated_at"]
                        )
                        or datetime.datetime.now(datetime.timezone.utc),
                        metadata=metadata, # type: ignore[arg-type]
                        semantic_field=f"{memory_data['title']},\n{memory_data['content']}",
                        last_reindexed_at=self.client._safe_parse_datetime( # type: ignore[arg-type]
                            memory_data["last_reindexed_at"]
                        ),
                        reindex_needed=memory_data["reindex_needed"],
                        # Knowledge Agent fields (v0.6)
                        unit_type=memory_data.get("unit_type", "fact"),
                        is_latest=memory_data.get("is_latest", True),
                        version=memory_data.get("version", 1),
                        is_crystal=memory_data.get("is_crystal", False),
                        crystal_title=memory_data.get("crystal_title"),
                        source_unit_count=memory_data.get("source_unit_count"),
                        extraction_method=memory_data.get("extraction_method", "manual"),
                    )
                    memories.append(memory)

                except Exception as e:
                    logger.error(
                        f"Failed to process memory row {row_count}", error=str(e)
                    )
                    continue  # Skip corrupted rows

            # logger.debug(
            #     f"Successfully processed {len(memories)} memories from {row_count} rows"
            # )
            return memories

        except Exception as e:
            logger.error("Failed to list memories", error=str(e))
            # Return empty list instead of raising to prevent API hangs
            return []

    async def count_memories(
        self, state: str = "active", importance_min: float = 0.0
    ) -> int:
        """Count memories matching the filter criteria."""
        self.client._ensure_initialized() # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            # Build condition based on state filtering (same logic as list_memories)
            conditions: List[str] = []
            params: dict[str, Any] | None = build_kuzu_params(importance_min=importance_min) # type: ignore

            # State filter (if not "all")
            if state != "all":
                conditions.append(
                    "(m.metadata CONTAINS $state OR NOT m.metadata CONTAINS 'state')"
                )
                params.update(build_kuzu_params(state=f'"state":"{state}"')) # type: ignore[attr-defined]

            # Importance filter
            conditions.append("m.importance >= $importance_min")

            where_clause = " AND ".join(conditions) if conditions else "true"

            query = f"""
            MATCH (m:Memory) 
            WHERE {where_clause}
            RETURN COUNT(m) as count;
            """

            result = self.conn.execute(query, params) # type: ignore
            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"
            with managed_result(result):
                if not result.has_next():
                    return 0

                return result.get_next()[0]  # type: ignore
        except Exception as e:
            logger.error(f"Failed to count memories: {e}")
            return 0

    async def get_memory_by_id(self, memory_id: str) -> Optional[MemoryNode]:
        """Get a specific memory by ID."""
        self.client._ensure_initialized() # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            query = """
                MATCH (m:Memory {id: $memory_id})
                RETURN m
            """

            result = self.conn.execute(query, {"memory_id": memory_id})
            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"
            with managed_result(result):
                if not result.has_next():
                    return None

                memory_data = result.get_next()[0]  # type: ignore

            return MemoryNode(
                id=memory_data["id"],
                content=memory_data["content"],
                title=memory_data["title"],
                importance=memory_data["importance"],
                confidence=memory_data["confidence"],
                embedding=[],
                source=memory_data["source"],
                source_range=json.loads(memory_data["source_range"])
                if memory_data["source_range"]
                else None,
                created_at=self.client._safe_parse_datetime(memory_data["created_at"]) # type: ignore[attr-defined]
                or datetime.datetime.now(datetime.timezone.utc),
                updated_at=self.client._safe_parse_datetime(memory_data["updated_at"]) # type: ignore[attr-defined]
                or datetime.datetime.now(datetime.timezone.utc),
                metadata=self.client._deserialize_metadata(memory_data["metadata"]), # type: ignore[attr-defined]
                semantic_field=f"{memory_data['title']},\n{memory_data['content']}",
                last_reindexed_at=self.client._safe_parse_datetime( # type: ignore[attr-defined]
                    memory_data["last_reindexed_at"]
                ), # type: ignore[attr-defined]
                reindex_needed=memory_data["reindex_needed"],
                # Knowledge Agent fields (v0.6)
                unit_type=memory_data.get("unit_type", "fact"),
                is_latest=memory_data.get("is_latest", True),
                version=memory_data.get("version", 1),
                is_crystal=memory_data.get("is_crystal", False),
                crystal_title=memory_data.get("crystal_title"),
                source_unit_count=memory_data.get("source_unit_count"),
                extraction_method=memory_data.get("extraction_method", "manual"),
                # Bi-temporal fields
                event_start=str(memory_data["event_start"]) if memory_data.get("event_start") else None,
                event_end=str(memory_data["event_end"]) if memory_data.get("event_end") else None,
                temporal_context=memory_data.get("temporal_context"),
                temporal_type=memory_data.get("temporal_type"),
                temporal_precision=memory_data.get("temporal_precision"),
            )

        except Exception as e:
            logger.error(
                "Failed to get memory by ID", memory_id=memory_id, error=str(e)
            )
            raise

    async def get_memories_by_thread(self, thread_id: str) -> List[str]:
        """Get all memory IDs that were extracted from a thread.

        Args:
            thread_id: Thread ID to search for

        Returns:
            List of memory IDs extracted from this thread
        """
        self.client._ensure_initialized() # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            # Find memories linked to this thread via COMPACTS_TO relationship
            query = """
                MATCH (t:Thread {thread_id: $thread_id})-[:COMPACTS_TO]->(m:Memory)
                RETURN m.id as memory_id
            """

            result = self.conn.execute(query, {"thread_id": thread_id})
            memory_ids: List[str] = []

            for row in iter_rows(result):  # type: ignore
                memory_ids.append(row[0])  # type: ignore

            logger.debug(
                "Found memories for thread", thread_id=thread_id, count=len(memory_ids) # type: ignore
            )
            return memory_ids # type: ignore

        except Exception as e:
            logger.error(
                "Failed to get memories by thread", thread_id=thread_id, error=str(e)
            )
            return []

    async def get_source_threads_for_memories(
        self, memory_ids: List[str]
    ) -> Dict[str, str]:
        """Get source thread IDs for multiple memories.

        Args:
            memory_ids: List of memory IDs to look up

        Returns:
            Dict mapping memory_id -> source_thread_id (only for memories with a source thread)
        """
        if not memory_ids:
            return {}

        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            # Query for COMPACTS_TO relationships to find source threads
            query = """
                MATCH (t:Thread)-[:COMPACTS_TO]->(m:Memory)
                WHERE m.id IN $memory_ids
                RETURN m.id as memory_id, t.thread_id as thread_id
            """

            result = self.conn.execute(query, {"memory_ids": memory_ids})
            source_map: Dict[str, str] = {}

            for row in iter_rows(result):
                memory_id = row[0]
                thread_id = row[1]
                if memory_id and thread_id:
                    source_map[memory_id] = thread_id

            logger.debug(
                "Found source threads for memories",
                requested=len(memory_ids),
                found=len(source_map),
            )
            return source_map

        except Exception as e:
            logger.error(
                "Failed to get source threads for memories",
                memory_count=len(memory_ids),
                error=str(e),
            )
            return {}

    # ── Deletion operations (delegated to MemoryDeletionManager) ──

    async def delete_memory(self, memory_id: str) -> bool:
        """Delete a memory and its relationships safely."""
        return await self._deletion.delete_memory(memory_id)

    async def delete_relationships_from_memory(self, memory_id: str) -> int:
        """Delete RELATES_TO relationships created from a specific memory."""
        return await self._deletion.delete_relationships_from_memory(memory_id)

    async def delete_memory_with_cascade(self, memory_id: str) -> Dict[str, Any]:
        """Delete a memory with cascade deletion of orphaned entities."""
        return await self._deletion.delete_memory_with_cascade(memory_id)

    async def find_orphaned_entities_after_memory_deletion(
        self, memory_id: str
    ) -> List[str]:
        """Find entities that would become orphaned after deleting a memory."""
        return await self._deletion.find_orphaned_entities_after_memory_deletion(memory_id)

    async def delete_orphaned_entities(self, entity_ids: List[str]) -> int:
        """Delete orphaned entities with safety checks."""
        return await self._deletion.delete_orphaned_entities(entity_ids)

    async def batch_update_appearances(self, memory_ids: List[str]) -> int:
        """
        Batch update appearance count for memories shown in search results.

        This is called after search to track that memories were shown to the user.
        Updates last_accessed_at to current time and increments appearances.

        Args:
            memory_ids: List of memory IDs that appeared in search results

        Returns:
            Number of memories updated
        """
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        if not memory_ids:
            return 0

        try:
            # Batch update: increment appearances and update last_accessed_at
            # Note: COALESCE handles NULL values (first time fields are accessed)
            query = """
                MATCH (m:Memory)
                WHERE m.id IN $memory_ids
                SET m.appearances = COALESCE(m.appearances, 0) + 1,
                    m.last_accessed_at = CURRENT_TIMESTAMP(),
                    m.access_count = COALESCE(m.access_count, 0) + 1
                RETURN count(m) as updated_count
            """

            result = self.conn.execute(query, {"memory_ids": memory_ids})
            updated_count = 0
            if isinstance(result, kuzu.QueryResult):
                with managed_result(result):
                    if result.has_next():
                        updated_count = result.get_next()[0]  # type: ignore

            logger.debug(
                "Batch updated memory appearances",
                memory_ids_count=len(memory_ids),
                updated_count=updated_count,
            )

            return updated_count  # type: ignore

        except Exception as e:
            logger.error(
                "Failed to batch update appearances",
                memory_ids_count=len(memory_ids),
                error=str(e),
            )
            return 0

    async def update_memory_click(
        self, memory_id: str, dwell_time_ms: int = 0
    ) -> bool:
        """
        Update memory click tracking when user views/clicks a memory.

        Args:
            memory_id: Memory that was clicked
            dwell_time_ms: Time spent reading in milliseconds

        Returns:
            True if updated successfully
        """
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            query = """
                MATCH (m:Memory {id: $id})
                SET m.clicks = COALESCE(m.clicks, 0) + 1,
                    m.last_clicked_at = CURRENT_TIMESTAMP(),
                    m.total_dwell_time_ms = COALESCE(m.total_dwell_time_ms, 0) + $dwell,
                    m.access_count = COALESCE(m.access_count, 0) + 1,
                    m.last_accessed_at = CURRENT_TIMESTAMP()
                RETURN m.id
            """

            result = self.conn.execute(
                query, {"id": memory_id, "dwell": dwell_time_ms}
            )
            success = False
            if isinstance(result, kuzu.QueryResult):
                with managed_result(result):
                    success = result.has_next()

            if success:
                logger.debug(
                    "Updated memory click tracking",
                    memory_id=memory_id,
                    dwell_time_ms=dwell_time_ms,
                )
            else:
                logger.warning("Memory not found for click tracking", memory_id=memory_id)

            return success

        except Exception as e:
            logger.error(
                "Failed to update memory click",
                memory_id=memory_id,
                error=str(e),
            )
            return False

    async def increment_memory_appearances(self, memory_id: str) -> bool:
        """
        Increment appearances count when memory shows up in search results.

        This is tracked separately from clicks to calculate CTR (click-through rate).
        appearances = how many times memory was shown
        clicks = how many times user actually opened it
        CTR = clicks / appearances

        Args:
            memory_id: Memory that appeared in search results

        Returns:
            True if updated successfully
        """
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            query = """
                MATCH (m:Memory {id: $id})
                SET m.appearances = COALESCE(m.appearances, 0) + 1,
                    m.last_accessed_at = CURRENT_TIMESTAMP(),
                    m.access_count = COALESCE(m.access_count, 0) + 1
                RETURN m.id
            """

            result = self.conn.execute(query, {"id": memory_id})
            success = False
            if isinstance(result, kuzu.QueryResult):
                with managed_result(result):
                    success = result.has_next()

            if success:
                # logger.debug(
                #     "Incremented memory appearances",
                #     memory_id=memory_id,
                # )
                pass
            else:
                logger.warning(
                    "Memory not found for appearance tracking", memory_id=memory_id
                )

            return success

        except Exception as e:
            logger.error(
                "Failed to increment memory appearances",
                memory_id=memory_id,
                error=str(e),
            )
            return False
