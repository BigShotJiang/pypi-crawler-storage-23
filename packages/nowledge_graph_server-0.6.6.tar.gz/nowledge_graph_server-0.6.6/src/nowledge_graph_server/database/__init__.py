"""
Nowledge Graph Database Module

Provides database access layer for KuzuDB with clean separation of concerns.

OPTIMIZATION: Uses lazy imports to avoid loading heavy dependencies (Pydantic, etc.)
when just traversing the package hierarchy. Modules are only imported when accessed.
"""

from typing import TYPE_CHECKING

# Lazy imports - only load when actually accessed
# This prevents importing Pydantic/config when importing from version_upgrade submodule
if TYPE_CHECKING:
    from .base_client import KuzuBaseClient
    from .memory_repository import MemoryRepository
    from .thread_repository import ThreadRepository
    from .entity_repository import EntityRepository
    from .relationship_manager import RelationshipManager
    from .search_engine import KuzuSearchEngine
    from .label_manager import LabelManager
    from .favorites_manager import FavoritesManager
    from .utils import DatabaseUtils
    from .kuzu_client import KuzuClient

__all__ = [
    "KuzuClient",
    "KuzuBaseClient",
    "MemoryRepository",
    "ThreadRepository",
    "EntityRepository",
    "RelationshipManager",
    "KuzuSearchEngine",
    "LabelManager",
    "FavoritesManager",
    "DatabaseUtils",
]


def __getattr__(name: str):
    """Lazy import mechanism - only load modules when accessed."""
    if name == "KuzuBaseClient":
        from .base_client import KuzuBaseClient
        return KuzuBaseClient
    elif name == "MemoryRepository":
        from .memory_repository import MemoryRepository
        return MemoryRepository
    elif name == "ThreadRepository":
        from .thread_repository import ThreadRepository
        return ThreadRepository
    elif name == "EntityRepository":
        from .entity_repository import EntityRepository
        return EntityRepository
    elif name == "RelationshipManager":
        from .relationship_manager import RelationshipManager
        return RelationshipManager
    elif name == "KuzuSearchEngine":
        from .search_engine import KuzuSearchEngine
        return KuzuSearchEngine
    elif name == "LabelManager":
        from .label_manager import LabelManager
        return LabelManager
    elif name == "FavoritesManager":
        from .favorites_manager import FavoritesManager
        return FavoritesManager
    elif name == "DatabaseUtils":
        from .utils import DatabaseUtils
        return DatabaseUtils
    elif name == "KuzuClient":
        from .kuzu_client import KuzuClient
        return KuzuClient
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
