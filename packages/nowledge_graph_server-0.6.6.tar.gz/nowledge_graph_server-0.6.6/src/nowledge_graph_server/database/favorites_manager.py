"""
Favorites Manager

Favorites operations for memories and threads.
"""

from typing import List, Any
import structlog
from nowledge_graph_server.database.base_client import KuzuBaseClient
from nowledge_graph_server.database.result_utils import iter_rows, managed_result
import real_ladybug as kuzu
import datetime
from nowledge_graph_server.models import MemoryNode, ThreadNode

logger = structlog.get_logger(__name__)


class FavoritesManager:
    """Manager for favorites operations."""

    def __init__(self, client: KuzuBaseClient):
        """Initialize with base client for database access."""
        self.client = client

    @property
    def conn(self):
        """Access database connection through client."""
        return self.client.conn

    async def toggle_memory_favorite(self, memory_id: str, is_favorite: bool) -> bool:
        """Toggle favorite status for a memory."""
        self.client._ensure_initialized()

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            # Get current metadata
            get_query = """
                MATCH (m:Memory {id: $memory_id})
                RETURN m.metadata as metadata
            """

            result = self.conn.execute(get_query, {"memory_id": memory_id})
            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

            with managed_result(result):
                if not result.has_next():
                    raise ValueError(f"Memory with ID {memory_id} not found")

                current_metadata = result.get_next()[0]  # type: ignore
            metadata_dict = self.client._deserialize_metadata(current_metadata or "{}")

            # Update favorite status
            metadata_dict["is_favorite"] = is_favorite
            updated_metadata = self.client._serialize_metadata(metadata_dict)

            # Update the memory
            update_query = """
                MATCH (m:Memory {id: $memory_id})
                SET m.metadata = $metadata, m.updated_at = $updated_at
            """

            self.conn.execute(
                update_query,
                {
                    "memory_id": memory_id,
                    "metadata": updated_metadata,
                    "updated_at": datetime.datetime.now(datetime.timezone.utc),
                },
            )

            return True

        except Exception as e:
            logger.error(
                "Failed to toggle memory favorite", memory_id=memory_id, error=str(e)
            )
            raise

    async def toggle_thread_favorite(self, thread_id: str, is_favorite: bool) -> bool:
        """Toggle favorite status for a thread."""
        self.client._ensure_initialized()

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            # Get current metadata
            get_query = """
                MATCH (t:Thread {thread_id: $thread_id})
                RETURN t.metadata as metadata
            """

            result = self.conn.execute(get_query, {"thread_id": thread_id})
            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

            with managed_result(result):
                if not result.has_next():
                    raise ValueError(f"Thread with ID {thread_id} not found")

                current_metadata = result.get_next()[0]  # type: ignore
            metadata_dict = self.client._deserialize_metadata(current_metadata or "{}")

            # Update favorite status
            metadata_dict["is_favorite"] = is_favorite
            updated_metadata = self.client._serialize_metadata(metadata_dict)

            # Update the thread
            update_query = """
                MATCH (t:Thread {thread_id: $thread_id})
                SET t.metadata = $metadata, t.updated_at = $updated_at
            """

            self.conn.execute(
                update_query,
                {
                    "thread_id": thread_id,
                    "metadata": updated_metadata,
                    "updated_at": datetime.datetime.now(datetime.timezone.utc),
                },
            )

            return True

        except Exception as e:
            logger.error(
                "Failed to toggle thread favorite", thread_id=thread_id, error=str(e)
            )
            raise

    async def get_favorite_memories(self, limit: int = 50) -> List[MemoryNode]:
        """Get all favorite memories."""
        self.client._ensure_initialized()

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            # More robust query that handles JSON spacing variations
            query = """
                MATCH (m:Memory)
                WHERE m.metadata CONTAINS 'is_favorite' AND (
                    m.metadata CONTAINS '"is_favorite":true' OR 
                    m.metadata CONTAINS '"is_favorite": true'
                )
                RETURN m
                ORDER BY m.updated_at DESC
                LIMIT $limit
            """

            result = self.conn.execute(query, {"limit": limit})
            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

            memories = []
            for row in iter_rows(result):
                memory_data = row[0]  # type: ignore

                # Double-check by deserializing metadata
                metadata = self.client._deserialize_metadata(
                    memory_data.get("metadata", "{}")
                )
                if not metadata.get("is_favorite", False):
                    continue  # Skip if not actually favorited

                memory = MemoryNode(
                    id=memory_data["id"],
                    content=memory_data["content"],
                    title=memory_data["title"],
                    importance=memory_data["importance"],
                    confidence=memory_data["confidence"],
                    embedding=memory_data.get("embedding", []),
                    source_range=self.client._deserialize_metadata(
                        memory_data.get("source_range", "{}")
                    ),
                    created_at=self.client._safe_parse_datetime(
                        memory_data["created_at"]
                    )
                    or datetime.datetime.now(datetime.timezone.utc),
                    updated_at=self.client._safe_parse_datetime(
                        memory_data["updated_at"]
                    )
                    or datetime.datetime.now(datetime.timezone.utc),
                    metadata=metadata,
                    semantic_field=f"{memory_data['title']},\n{memory_data['content']}",
                    last_reindexed_at=self.client._safe_parse_datetime(
                        memory_data["last_reindexed_at"]
                    ),
                    reindex_needed=memory_data["reindex_needed"],
                    source=memory_data["source"],
                    # Knowledge Agent fields (v0.6)
                    unit_type=memory_data.get("unit_type", "fact"),
                    is_latest=memory_data.get("is_latest", True),
                    version=memory_data.get("version", 1),
                    is_crystal=memory_data.get("is_crystal", False),
                    crystal_title=memory_data.get("crystal_title"),
                    source_unit_count=memory_data.get("source_unit_count"),
                    extraction_method=memory_data.get("extraction_method", "manual"),
                )
                memories.append(memory)

            logger.debug(f"Found {len(memories)} favorite memories")
            return memories

        except Exception as e:
            logger.error("Failed to get favorite memories", error=str(e))
            raise

    async def get_favorite_threads(self, limit: int = 50) -> List[ThreadNode]:
        """Get all favorite threads."""
        self.client._ensure_initialized()

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            # More robust query that handles JSON spacing variations
            query = """
                MATCH (t:Thread)
                WHERE t.metadata CONTAINS 'is_favorite' AND (
                    t.metadata CONTAINS '"is_favorite":true' OR 
                    t.metadata CONTAINS '"is_favorite": true'
                )
                RETURN t
                ORDER BY t.updated_at DESC
                LIMIT $limit
            """

            result = self.conn.execute(query, {"limit": limit})
            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

            threads = []
            for row in iter_rows(result):
                thread_data = row[0]  # type: ignore

                # Double-check by deserializing metadata
                metadata = self.client._deserialize_metadata(
                    thread_data.get("metadata", "{}")
                )
                if not metadata.get("is_favorite", False):
                    continue  # Skip if not actually favorited

                thread = ThreadNode(
                    id=thread_data["id"],
                    thread_id=thread_data["thread_id"],
                    title=thread_data["title"],
                    summary=thread_data["summary"],
                    message_count=thread_data["message_count"],
                    participants=thread_data["participants"],
                    source=thread_data["source"],
                    created_at=self.client._safe_parse_datetime(
                        thread_data["created_at"]
                    )
                    or datetime.datetime.now(datetime.timezone.utc),
                    updated_at=self.client._safe_parse_datetime(
                        thread_data["updated_at"]
                    )
                    or datetime.datetime.now(datetime.timezone.utc),
                    project=thread_data.get("project"),
                    workspace=thread_data.get("workspace"),
                    tool_version=thread_data.get("tool_version"),
                    import_date=self.client._safe_parse_datetime(
                        thread_data["import_date"]
                    ),
                    metadata=metadata,
                )
                threads.append(thread)

            logger.debug(f"Found {len(threads)} favorite threads")
            return threads

        except Exception as e:
            logger.error("Failed to get favorite threads", error=str(e))
            raise
