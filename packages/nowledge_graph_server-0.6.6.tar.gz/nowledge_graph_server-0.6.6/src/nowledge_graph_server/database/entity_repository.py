"""
Entity Repository

All entity-related database operations including CRUD and mentions.
"""

from typing import List, cast, Optional
import structlog
import real_ladybug as kuzu
import json
import datetime

from nowledge_graph_server.models.graph import EntityNode
from nowledge_graph_server.database.base_client import (
    KuzuBaseClient,
)
from nowledge_graph_server.database.result_utils import iter_rows, managed_result
from nowledge_graph_server.database.schema import COMMON_QUERIES

logger = structlog.get_logger(__name__)


class EntityRepository:
    """Repository for entity-related database operations."""

    def __init__(self, client: KuzuBaseClient):
        """Initialize with base client for database access."""
        self.client: KuzuBaseClient = client

    @property
    def conn(self) -> kuzu.Connection | None:
        """Access database connection through client."""
        return cast(kuzu.Connection | None, self.client.conn)  # type: ignore[attr-defined]

    async def create_or_find_entity(self, entity_node: EntityNode) -> EntityNode:
        """Create new entity or find existing one by name and type."""
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            # First try to find existing entity
            find_query = """
                MATCH (e:Entity {name: $name, entity_type: $entity_type})
                RETURN e
            """

            result = self.conn.execute(
                find_query,
                {"name": entity_node.name, "entity_type": entity_node.entity_type},
            )
            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

            with managed_result(result):
                if result.has_next():
                    # Entity exists, return it
                    existing_data = result.get_next()[0]  # type: ignore

                    return EntityNode(
                        id=existing_data["id"],
                        name=existing_data["name"],
                        entity_type=existing_data["entity_type"],
                        description=existing_data.get("description", ""),
                        aliases=existing_data.get("aliases", []),
                        confidence=existing_data.get("confidence", 0.5),
                        created_at=self.client._safe_parse_datetime(  # type: ignore
                            existing_data["created_at"]
                        )
                        or datetime.datetime.now(datetime.timezone.utc),
                        updated_at=self.client._safe_parse_datetime(  # type: ignore
                            existing_data["updated_at"]
                        )
                        or datetime.datetime.now(datetime.timezone.utc),
                        metadata=self.client._deserialize_metadata(  # type: ignore
                            existing_data.get("metadata", "{}")
                        ),
                    )

            # Entity doesn't exist, create it
            create_query = """
                CREATE (e:Entity {
                    id: $id,
                    name: $name,
                    entity_type: $entity_type,
                    description: $description,
                    aliases: $aliases,
                    confidence: $confidence,
                    created_at: $created_at,
                    updated_at: $updated_at,
                    metadata: $metadata
                })
                RETURN e
            """

            self.conn.execute(
                create_query,
                {
                    "id": entity_node.id,
                    "name": entity_node.name,
                    "entity_type": entity_node.entity_type,
                    "description": entity_node.description,
                    "aliases": entity_node.aliases,
                    "confidence": entity_node.confidence,
                    "created_at": entity_node.created_at
                    if entity_node.created_at
                    else datetime.datetime.now(datetime.timezone.utc),
                    "updated_at": entity_node.updated_at
                    if entity_node.updated_at
                    else datetime.datetime.now(datetime.timezone.utc),
                    "metadata": self.client._serialize_metadata(entity_node.metadata),  # type: ignore
                },
            )

            return entity_node

        except Exception as e:
            logger.error(
                "Failed to create or find entity",
                entity_name=entity_node.name,
                error=str(e),
            )
            raise

    async def search_entities_fts(
        self,
        query_text: str,
        limit: int = 10,
    ) -> List[EntityNode]:
        """Search entities using full-text search on name and description.

        Args:
            query_text: Text query for FTS search
            limit: Maximum number of results

        Returns:
            List of EntityNode objects matching the query
        """
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            logger.debug(
                "Searching entities with FTS", query=query_text[:50], limit=limit
            )

            # Prefer LanceDB-based search index (post-migration)
            try:
                from ..services.search_index import get_search_index_service
                search_service = await get_search_index_service()
            except Exception:
                search_service = None

            if search_service:
                search_results = await search_service.search_entities_fts(
                    query_text=query_text, limit=limit
                )
                entity_ids = [result.id for result in search_results]
                if not entity_ids:
                    return []

                fetch_query = """
                    MATCH (e:Entity)
                    WHERE e.id IN $entity_ids
                    RETURN e
                """
                result = self.conn.execute(fetch_query, {"entity_ids": entity_ids})
                if isinstance(result, list):
                    if not result:
                        return []
                    result = result[0]

                assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"
                entities: List[EntityNode] = []
                for row in iter_rows(result):  # type: ignore
                    entity_data = row[0]  # type: ignore
                    entity_node = EntityNode(
                        id=entity_data["id"],
                        name=entity_data["name"],
                        entity_type=entity_data["entity_type"],
                        description=entity_data.get("description", ""),
                        aliases=entity_data.get("aliases", []),
                        confidence=entity_data.get("confidence", 0.5),
                        created_at=self.client._safe_parse_datetime(  # type: ignore
                            entity_data["created_at"]
                        )
                        or datetime.datetime.now(datetime.timezone.utc),
                        updated_at=self.client._safe_parse_datetime(  # type: ignore
                            entity_data["updated_at"]
                        )
                        or datetime.datetime.now(datetime.timezone.utc),
                        metadata=self.client._deserialize_metadata(  # type: ignore
                            entity_data.get("metadata", "{}")
                        ),
                    )
                    entities.append(entity_node)

                logger.debug(f"Found {len(entities)} entities via search index")
                return entities

            # Fallback to Kuzu FTS query if search index is unavailable
            fts_query = COMMON_QUERIES["fts_entity_search"]
            result = self.conn.execute(
                fts_query,
                {
                    "text_query": query_text,
                    "limit": limit,
                },
            )

            if isinstance(result, list):
                if not result:
                    return []
                result = result[0]

            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

            entities: List[EntityNode] = []
            for row in iter_rows(result):  # type: ignore
                entity_data = row[0]  # type: ignore

                entity_node = EntityNode(
                    id=entity_data["id"],
                    name=entity_data["name"],
                    entity_type=entity_data["entity_type"],
                    description=entity_data.get("description", ""),
                    aliases=entity_data.get("aliases", []),
                    confidence=entity_data.get("confidence", 0.5),
                    created_at=self.client._safe_parse_datetime(  # type: ignore
                        entity_data["created_at"]
                    )
                    or datetime.datetime.now(datetime.timezone.utc),
                    updated_at=self.client._safe_parse_datetime(  # type: ignore
                        entity_data["updated_at"]
                    )
                    or datetime.datetime.now(datetime.timezone.utc),
                    metadata=self.client._deserialize_metadata(  # type: ignore
                        entity_data.get("metadata", "{}")
                    ),
                )
                entities.append(entity_node)

            logger.debug(f"Found {len(entities)} entities via Kuzu FTS search")
            return entities

        except Exception as e:
            logger.error("Entity FTS search failed", query=query_text, error=str(e))
            return []  # Return empty list on error instead of raising

    async def create_entity_mention(
        self,
        memory_id: str,
        entity_id: str,
        confidence: float,
    ) -> str:
        """Create MENTIONS relationship between memory and entity."""
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            relationship_id = f"mentions_{memory_id}_{entity_id}"
            logger.debug(
                f"🔗 create_entity_mention called: memory_id={memory_id}, entity_id={entity_id}, confidence={confidence}"
            )

            query = """
                MATCH (m:Memory {id: $memory_id}), (e:Entity {id: $entity_id})
                CREATE (m)-[:MENTIONS {
                    confidence: $confidence,
                    mention_count: 1,
                    created_at: $created_at,
                    properties: $properties
                }]->(e)
            """

            # Store source memory info in properties for deletion tracking
            properties = {
                "source_memory_id": memory_id,
                "extraction_method": "llm_distillation",
            }

            logger.debug(f"🔗 Executing MENTIONS query for {memory_id} -> {entity_id}")
            self.conn.execute(
                query,
                {
                    "memory_id": memory_id,
                    "entity_id": entity_id,
                    "confidence": confidence,
                    "created_at": datetime.datetime.now(datetime.timezone.utc),
                    "properties": json.dumps(properties),
                },
            )
            logger.debug(
                f"🔗 MENTIONS query executed successfully: {memory_id} -> {entity_id}"
            )

            return relationship_id

        except Exception as e:
            logger.error(
                "Failed to create entity mention",
                memory_id=memory_id,
                entity_id=entity_id,
                error=str(e),
            )
            raise

    async def list_entities(
        self,
        limit: int = 50,
        entity_type: Optional[str] = None,
    ) -> List[EntityNode]:
        """List entities with optional filtering by type.

        Args:
            limit: Maximum number of entities to return
            entity_type: Optional filter by entity type

        Returns:
            List of EntityNode objects
        """
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            # Build query based on whether entity_type filter is provided
            if entity_type:
                query = """
                    MATCH (e:Entity {entity_type: $entity_type})
                    RETURN e
                    ORDER BY e.created_at DESC
                    LIMIT $limit
                """
                params = {"entity_type": entity_type, "limit": limit}
            else:
                query = """
                    MATCH (e:Entity)
                    RETURN e
                    ORDER BY e.created_at DESC
                    LIMIT $limit
                """
                params = {"limit": limit}

            result = self.conn.execute(query, params)

            # Handle result format
            if isinstance(result, list):
                if not result:
                    return []
                result = result[0]

            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

            entities: List[EntityNode] = []
            for row in iter_rows(result):  # type: ignore
                entity_data = row[0]  # type: ignore

                entity_node = EntityNode(
                    id=entity_data["id"],
                    name=entity_data["name"],
                    entity_type=entity_data["entity_type"],
                    description=entity_data.get("description", ""),
                    aliases=entity_data.get("aliases", []),
                    confidence=entity_data.get("confidence", 0.5),
                    created_at=self.client._safe_parse_datetime( # type: ignore
                        entity_data["created_at"]
                    )
                    or datetime.datetime.now(datetime.timezone.utc),
                    updated_at=self.client._safe_parse_datetime( # type: ignore
                        entity_data["updated_at"]
                    )
                    or datetime.datetime.now(datetime.timezone.utc),
                    metadata=self.client._deserialize_metadata( # type: ignore
                        entity_data.get("metadata", "{}")
                    ),
                )
                entities.append(entity_node)

            logger.debug(
                f"Listed {len(entities)} entities", entity_type=entity_type, limit=limit
            )
            return entities

        except Exception as e:
            logger.error("Failed to list entities", error=str(e))
            raise
