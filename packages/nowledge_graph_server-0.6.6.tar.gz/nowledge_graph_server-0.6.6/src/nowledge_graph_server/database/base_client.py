"""
KuzuDB Base Client

Core database connection, schema management, and shared utilities.

## WAL Corruption Prevention

This module implements several safeguards against WAL (Write-Ahead Log) corruption:

1. **Checkpoint on close**: Always checkpoint before closing the connection to flush
   any pending WAL entries to the main database file.

2. **Checkpoint with retry**: Checkpoint operations retry on transient failures with
   exponential backoff to handle temporary resource contention.

3. **Transaction-based writes**: All write operations use explicit transactions with
   optional checkpoint after commit for critical operations.

4. **Checkpoint tracking**: Tracks last successful checkpoint time for diagnostics.

5. **WAL corruption recovery**: If a corrupted WAL is detected on startup, it is
   moved aside (preserving it for forensics) and the database is reopened.

See: https://github.com/kuzudb/kuzu/issues/6045 for related vector index issues.
"""

from pathlib import Path
from typing import Any, Dict, Optional, Union
from threading import Lock
import datetime
import time
from contextlib import contextmanager
import os
import structlog
import real_ladybug as kuzu
import json
from .schema import get_init_sequence
from .version_upgrade.db_version_manager import get_db_version

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .memory_repository import MemoryRepository
    from .thread_repository import ThreadRepository
    from .entity_repository import EntityRepository
    from .relationship_manager import RelationshipManager
    from .search_engine import KuzuSearchEngine
    from .label_manager import LabelManager
    from .favorites_manager import FavoritesManager

logger = structlog.get_logger(__name__)

_DEFAULT_BUFFER_POOL_SIZE = 512 * 1024 * 1024  # 512 MB


def _parse_buffer_pool_size() -> int:
    raw = os.getenv("NOWLEDGE_KUZU_BUFFER_POOL_SIZE", "").strip()
    if not raw:
        return _DEFAULT_BUFFER_POOL_SIZE
    if raw.lower() == "auto":
        return 0
    raw_upper = raw.upper()
    multiplier = 1
    if raw_upper.endswith("GB"):
        multiplier = 1024 * 1024 * 1024
        raw_upper = raw_upper[:-2].strip()
    elif raw_upper.endswith("MB"):
        multiplier = 1024 * 1024
        raw_upper = raw_upper[:-2].strip()
    elif raw_upper.endswith("KB"):
        multiplier = 1024
        raw_upper = raw_upper[:-2].strip()
    try:
        value = int(raw_upper) * multiplier
    except ValueError:
        logger.warning(
            "Invalid NOWLEDGE_KUZU_BUFFER_POOL_SIZE; falling back to auto",
            value=raw,
        )
        return _DEFAULT_BUFFER_POOL_SIZE
    if value < 0:
        logger.warning(
            "Negative NOWLEDGE_KUZU_BUFFER_POOL_SIZE; falling back to auto",
            value=raw,
        )
        return _DEFAULT_BUFFER_POOL_SIZE
    return value


# KuzuDB buffer pool: default to a fixed 256MB cap to avoid excessive RAM usage
# in desktop sessions. Set NOWLEDGE_KUZU_BUFFER_POOL_SIZE to override (bytes or
# KB/MB/GB). Use "auto" to allow Kuzu to size by system RAM.
_KUZU_BUFFER_POOL_SIZE = _parse_buffer_pool_size()


def ensure_kuzu_extensions(
    conn: kuzu.Connection, raise_on_failure: bool = True
) -> None:
    """Shared utility to ensure KuzuDB extensions are loaded.

    Uses the same pattern as GraphAnalysisService to check and load extensions.

    Args:
        conn: KuzuDB connection
        raise_on_failure: Whether to raise exception on critical failures
    """
    required_extensions = ["VECTOR", "FTS", "ALGO"]

    try:
        # First, check what extensions are already loaded
        result = conn.execute("CALL show_loaded_extensions() RETURN *")
        loaded_extensions: set[str] = set()

        if hasattr(result, "has_next"):
            assert isinstance(result, kuzu.QueryResult)
            while result.has_next():
                row = result.get_next()
                if row and len(row) > 0:
                    loaded_extensions.add(str(row[0]).upper())  # type: ignore

        logger.debug("Currently loaded extensions", extensions=list(loaded_extensions))

        # Load missing extensions
        for ext_name in required_extensions:
            if ext_name not in loaded_extensions:
                try:
                    if ext_name == "ALGO":
                        conn.execute("INSTALL algo; LOAD algo;")
                    else:
                        conn.execute(f"INSTALL {ext_name}; LOAD {ext_name};")
                    logger.debug(f"Successfully loaded {ext_name} extension")
                except Exception as e:
                    error_msg = str(e).lower()
                    if (
                        "already loaded" in error_msg
                        or "is already loaded" in error_msg
                    ):
                        logger.debug(f"{ext_name} extension already loaded")
                    else:
                        logger.error(
                            f"Failed to load {ext_name} extension", error=str(e)
                        )
                        if raise_on_failure and ext_name == "VECTOR":
                            raise RuntimeError(
                                f"Vector extension is required but failed to load: {e}"
                            )
            else:
                logger.debug(f"{ext_name} extension already loaded")

        logger.debug("Extension loading completed")

    except Exception as e:
        if raise_on_failure:
            logger.error("Failed to check/load extensions", error=str(e))
            # Try to load extensions without checking (fallback)
            try:
                conn.execute("INSTALL VECTOR; LOAD VECTOR;")
                conn.execute("INSTALL FTS; LOAD FTS;")
                conn.execute("INSTALL ALGO; LOAD ALGO;")
                logger.info("Fallback: Extensions loaded without verification")
            except Exception as fallback_e:
                logger.error(
                    "Fallback extension loading also failed", error=str(fallback_e)
                )
                raise RuntimeError(f"Extension loading failed: {fallback_e}")
        else:
            logger.warning("Extension loading failed but continuing", error=str(e))


def build_kuzu_params(**kwargs: Any) -> dict[str, Any]:
    """Helper function to build KuzuDB parameter dict with proper typing.

    KuzuDB's Python bindings have incorrect type annotations for parameter values.
    This helper works around the type checker issues.
    """
    params: dict[str, Any] = {}
    for key, value in kwargs.items():
        if value is not None:
            # Convert datetime objects to ISO format strings for KuzuDB
            if isinstance(value, datetime.datetime):
                params[key] = value.isoformat()
            else:
                params[key] = value
    return params


class KuzuBaseClient:
    """Base client handling connection, schema, and core utilities.
    
    This client implements WAL corruption prevention through:
    - Checkpoint with retry logic for transient failures
    - Checkpoint on close to flush pending WAL entries
    - Checkpoint tracking for diagnostics
    """

    # Repository classes
    memory_repo: "MemoryRepository"
    thread_repo: "ThreadRepository"
    entity_repo: "EntityRepository"
    relationship_mgr: "RelationshipManager"
    search_engine: "KuzuSearchEngine"
    label_mgr: "LabelManager"
    favorites_mgr: "FavoritesManager"

    # Database connection
    conn: Optional[kuzu.Connection]

    # Checkpoint tracking
    _last_checkpoint_time: Optional[datetime.datetime] = None
    _checkpoint_failure_count: int = 0
    _last_checkpoint_failure: Optional[str] = None

    # Process-level guard: only one READ_WRITE Database per process.
    _open_db_paths: set[Path] = set()
    _open_db_paths_lock: Lock = Lock()

    def __init__(self, db_path: Path, embedding_dimension: int = 384):
        """Initialize KuzuDB client.

        Args:
            db_path: Path to database directory
            embedding_dimension: Dimension for embedding vectors (affects schema)
        """
        self.db_path = Path(db_path)
        self.embedding_dimension = embedding_dimension
        self.db: Optional[kuzu.Database] = None
        self.conn = None
        self._initialized = False
        self._db_path_claimed = False
        
        # Reset checkpoint tracking
        self._last_checkpoint_time = None
        self._checkpoint_failure_count = 0
        self._last_checkpoint_failure = None

    def _ensure_initialized(self) -> None:
        """Ensure the client is initialized."""
        if not self._initialized:
            raise RuntimeError("KuzuClient not initialized. Call initialize() first.")

    @property
    def db_version(self) -> int:
        """
        Get current database version (0=alpine, 1=birch).

        Returns:
            Database version number
        """
        from .version_upgrade.db_version_manager import get_db_version

        return get_db_version(self.db_path)

    async def initialize(self) -> None:
        """Initialize the database connection and create schema."""
        try:
            # Enforce single Database object per process for this path.
            with self._open_db_paths_lock:
                if self.db_path in self._open_db_paths:
                    raise RuntimeError(
                        f"Database already open in this process: {self.db_path}. "
                        "Use a singleton KuzuClient and share its connections."
                    )
                self._open_db_paths.add(self.db_path)
                self._db_path_claimed = True

            # Create database directory if it doesn't exist
            self.db_path.parent.mkdir(parents=True, exist_ok=True)

            # Track if this is a fresh database creation
            is_fresh_db = not self.db_path.exists()

            logger.info(
                "Initializing DB",
                path=str(self.db_path),
                embedding_dimension=self.embedding_dimension,
                is_fresh_db=is_fresh_db,
            )

            # KuzuDB expects a file path, not a directory path. Ensure db_path is a file, not a directory.
            # if self.db_path.is_dir():
            # raise RuntimeError(f"Database path cannot be a directory: {self.db_path}")

            # Try to initialize the database with WAL corruption recovery
            try:
                self.db = kuzu.Database(
                    str(self.db_path),
                    buffer_pool_size=_KUZU_BUFFER_POOL_SIZE,
                )
                self.conn = kuzu.Connection(self.db)
            except RuntimeError as db_error:
                # Check if this is a corrupted WAL file error
                error_msg = str(db_error)
                is_wal_corruption = (
                    "corrupted wal" in error_msg.lower()
                    or "wal_record.cpp" in error_msg
                    or "wal record" in error_msg.lower()
                    or "KU_UNREACHABLE" in error_msg
                )
                if is_wal_corruption:
                    logger.warning(
                        "Detected corrupted WAL file, attempting recovery",
                        error=error_msg,
                        db_path=str(self.db_path),
                    )

                    # Construct WAL file path
                    wal_file_path = Path(str(self.db_path) + ".wal")

                    if wal_file_path.exists():
                        try:
                            # IMPORTANT:
                            # Removing a WAL can cause loss of any uncheckpointed data.
                            # We therefore *never delete it outright*; instead we move it aside
                            # so the database can be opened while preserving the WAL for forensics.
                            ts = datetime.datetime.now(datetime.timezone.utc).strftime(
                                "%Y%m%dT%H%M%SZ"
                            )
                            wal_backup_path = Path(str(wal_file_path) + f".corrupt-{ts}")
                            logger.warning(
                                "Moving corrupted WAL file aside (may lose uncheckpointed data)",
                                wal_path=str(wal_file_path),
                                backup_path=str(wal_backup_path),
                            )
                            wal_file_path.replace(wal_backup_path)
                            logger.info(
                                "Successfully moved corrupted WAL file aside",
                                backup_path=str(wal_backup_path),
                            )
                        except Exception as remove_error:
                            logger.error(
                                "Failed to move corrupted WAL file aside",
                                error=str(remove_error),
                                wal_path=str(wal_file_path),
                            )
                            raise RuntimeError(
                                f"Cannot move corrupted WAL file at {wal_file_path}: {remove_error}"
                            ) from remove_error

                        # Retry database initialization after moving WAL aside
                        logger.info(
                            "Retrying database initialization after WAL was moved aside"
                        )
                        try:
                            self.db = kuzu.Database(
                                str(self.db_path),
                                buffer_pool_size=_KUZU_BUFFER_POOL_SIZE,
                            )
                            self.conn = kuzu.Connection(self.db)
                            logger.info(
                                "Database initialized successfully after WAL recovery",
                                db_path=str(self.db_path),
                            )
                        except Exception as retry_error:
                            logger.error(
                                "Database initialization failed even after WAL was moved aside",
                                error=str(retry_error),
                            )
                            raise
                    else:
                        logger.error(
                            "Corrupted WAL error reported but WAL file not found",
                            expected_wal_path=str(wal_file_path),
                        )
                        raise
                else:
                    # Not a WAL corruption error, re-raise original error
                    raise

            # Load extensions first
            await self._ensure_extensions_loaded()

            # Check if schema exists, but don't create it (migrations handle schema)
            await self._verify_schema_exists()

            # Mark as initialized BEFORE creating indexes
            self._initialized = True

            # Create vector and FTS indexes after initialization is complete
            logger.info("Creating vector and bm25 indexes")
            await self.ensure_vector_indexes()

            # CRITICAL: Checkpoint after initialization to flush WAL and sync catalog
            # This prevents catalog corruption from stale WAL entries on startup
            try:
                if self.conn:
                    self.conn.execute("CHECKPOINT;")
                    logger.debug("Checkpointed after initialization to sync catalog")
            except Exception as checkpoint_err:
                logger.warning(
                    "Failed to checkpoint after initialization (WAL may contain stale entries)",
                    error=str(checkpoint_err),
                )
                # Don't fail initialization if checkpoint fails

            # If this is a fresh database, write version metadata
            if is_fresh_db:
                await self._initialize_version_metadata()

            logger.info("DB initialized successfully")

        except Exception as e:
            import traceback

            if self._db_path_claimed:
                with self._open_db_paths_lock:
                    self._open_db_paths.discard(self.db_path)
                self._db_path_claimed = False

            logger.error(
                "Failed to initialize DB",
                error=str(e),
                backtrace=traceback.format_exc(),
            )
            raise

    def checkpoint(
        self,
        *,
        reason: str | None = None,
        retry_count: int = 3,
        retry_delay_base: float = 0.1,
        raise_on_failure: bool = False,
    ) -> bool:
        """Flush WAL to the main store with retry logic.

        Ladybug/Kuzu persists recent writes into a WAL. A CHECKPOINT forces WAL flush,
        reducing risk of losing recently-written data if the WAL is later removed/corrupt.

        Args:
            reason: Description of why checkpoint is being performed (for logging)
            retry_count: Number of retry attempts on failure (default: 3)
            retry_delay_base: Base delay in seconds for exponential backoff (default: 0.1)
            raise_on_failure: If True, raise exception on failure; otherwise log warning

        Returns:
            True if checkpoint succeeded, False otherwise
        """
        self._ensure_initialized()
        if not self.conn:
            raise RuntimeError("Database connection not available")

        last_failure: Optional[Exception] = None
        
        for attempt in range(retry_count):
            try:
                self.conn.execute("CHECKPOINT;")
                self._last_checkpoint_time = datetime.datetime.now(datetime.timezone.utc)
                self._checkpoint_failure_count = 0
                self._last_checkpoint_failure = None
                
                if attempt > 0:
                    logger.info(
                        "Checkpoint succeeded after retry",
                        reason=reason,
                        attempt=attempt + 1,
                    )
                else:
                    logger.debug("Checkpointed", reason=reason)
                return True
                
            except Exception as e:
                last_failure = e
                self._checkpoint_failure_count += 1
                self._last_checkpoint_failure = str(e)
                
                if attempt < retry_count - 1:
                    # Exponential backoff
                    delay = retry_delay_base * (2 ** attempt)
                    logger.warning(
                        "Checkpoint failed, retrying",
                        reason=reason,
                        attempt=attempt + 1,
                        retry_count=retry_count,
                        delay=delay,
                        error=str(e),
                    )
                    time.sleep(delay)
                else:
                    # Final failure
                    logger.error(
                        "Checkpoint failed after all retries",
                        reason=reason,
                        attempts=retry_count,
                        error=str(e),
                        total_failures=self._checkpoint_failure_count,
                    )
                    
        if raise_on_failure and last_failure:
            raise last_failure
            
        return False

    def get_checkpoint_status(self) -> Dict[str, Any]:
        """Get checkpoint status for diagnostics.
        
        Returns:
            Dict with last_checkpoint_time, failure_count, and last_failure
        """
        return {
            "last_checkpoint_time": self._last_checkpoint_time.isoformat() 
                if self._last_checkpoint_time else None,
            "failure_count": self._checkpoint_failure_count,
            "last_failure": self._last_checkpoint_failure,
        }

    @contextmanager
    def transaction(
        self,
        *,
        checkpoint: bool = False,
        reason: str | None = None,
        checkpoint_retry_count: int = 3,
    ):
        """Execute multiple statements atomically.

        Wraps statements in BEGIN/COMMIT and attempts ROLLBACK on errors.
        Optionally checkpoints after commit for durability.
        
        Args:
            checkpoint: If True, checkpoint after successful commit
            reason: Description for logging
            checkpoint_retry_count: Number of checkpoint retry attempts
        """
        self._ensure_initialized()
        if not self.conn:
            raise RuntimeError("Database connection not available")
        self.conn.execute("BEGIN TRANSACTION;")
        try:
            yield
        except Exception:
            try:
                self.conn.execute("ROLLBACK;")
            except Exception as rollback_err:
                logger.warning(
                    "Rollback failed",
                    reason=reason,
                    error=str(rollback_err),
                )
            raise
        else:
            self.conn.execute("COMMIT;")
            if checkpoint:
                # Use retry logic for checkpoint after commit
                checkpoint_success = self.checkpoint(
                    reason=reason,
                    retry_count=checkpoint_retry_count,
                    raise_on_failure=False,  # Don't raise - transaction is already committed
                )
                if not checkpoint_success:
                    logger.warning(
                        "Transaction committed but checkpoint failed - data in WAL",
                        reason=reason,
                        last_failure=self._last_checkpoint_failure,
                    )

    async def close(self) -> None:
        """Close database connection with final checkpoint.
        
        CRITICAL: This method checkpoints before closing to ensure all WAL entries
        are flushed to the main database file. This prevents WAL corruption that
        can occur if the database is closed (or the process crashes) with unflushed
        WAL entries.
        """
        if self._initialized and self.conn:
            # Checkpoint before closing to flush any pending WAL entries
            # This is critical to prevent WAL corruption
            logger.info("Performing final checkpoint before closing database")
            try:
                checkpoint_success = self.checkpoint(
                    reason="close",
                    retry_count=3,
                    raise_on_failure=False,
                )
                if checkpoint_success:
                    logger.info("Final checkpoint completed successfully")
                else:
                    logger.warning(
                        "Final checkpoint failed - WAL may contain unflushed data",
                        last_failure=self._last_checkpoint_failure,
                    )
            except Exception as e:
                logger.error(
                    "Exception during final checkpoint",
                    error=str(e),
                )
        
        if self.conn:
            try:
                self.conn.close()
            except Exception as e:
                logger.warning("Error closing connection", error=str(e))
                
        if self.db:
            try:
                self.db.close()
            except Exception as e:
                logger.warning("Error closing database", error=str(e))
                
        self._initialized = False
        if self._db_path_claimed:
            with self._open_db_paths_lock:
                self._open_db_paths.discard(self.db_path)
            self._db_path_claimed = False
        logger.debug("DB connection closed")

    async def _ensure_extensions_loaded(self) -> None:
        """Ensure vector and FTS extensions are loaded for current session."""
        if not self.conn:
            raise RuntimeError("Database connection not available")

        ensure_kuzu_extensions(self.conn, raise_on_failure=True)
        logger.debug("All required extensions loaded and verified")

    async def _initialize_version_metadata(self) -> None:
        """Write version metadata for a freshly created database.

        This is called during initialize() when creating a new database to ensure
        it's properly tagged with the current version (v1 = birch/Ladybug).
        """
        try:
            from .version_upgrade.db_version_manager import (
                set_db_version,
                CURRENT_DB_VERSION,
            )

            # Write version metadata
            set_db_version(
                self.db_path,
                CURRENT_DB_VERSION,
                additional_metadata={
                    "created_at": datetime.datetime.now().isoformat(),
                    "reason": "fresh_database_initialization",
                },
            )

            logger.info(
                "Initialized version metadata for fresh database",
                db_version=CURRENT_DB_VERSION,
                db_path=str(self.db_path),
            )
        except Exception as e:
            logger.error(
                "Failed to initialize version metadata (non-critical)",
                error=str(e),
            )
            # Don't fail initialization if metadata write fails
            # The database is still usable

    # dead code

    # async def _ensure_schema(self) -> None:
    #     """Ensure database schema exists."""
    #     if not self.conn:
    #         raise RuntimeError("Database connection not available")

    #     try:
    #         # Check if any tables exist
    #         result = self.conn.execute("CALL show_tables() RETURN *;")

    #         # Handle case where result might be a list
    #         existing_tables: set[str] = set()
    #         if isinstance(result, list):
    #             if not result:
    #                 existing_tables = set()
    #             else:
    #                 result = result[0]

    #         if hasattr(result, "has_next"):
    #             assert isinstance(result, kuzu.QueryResult), (
    #                 "result is not a QueryResult"
    #             )
    #             while result.has_next():
    #                 row = result.get_next()
    #                 if row and len(row) > 1:
    #                     existing_tables.add(row[1])  # type: ignore

    #         # If no tables exist, create schema
    #         if not existing_tables:
    #             logger.info("Creating database schema")
    #             await self._create_schema()
    #         else:
    #             logger.info("Database schema exists", tables=len(existing_tables))

    #     except Exception as e:
    #         logger.warning("Error checking schema, creating new", error=str(e))
    #         await self._create_schema()

    async def _verify_schema_exists(self) -> None:
        """Verify that required schema exists (migrations should have created it)."""
        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            # Check if core tables exist
            result = self.conn.execute("CALL show_tables() RETURN *")
            existing_tables: set[str] = set()

            if hasattr(result, "has_next"):
                assert isinstance(result, kuzu.QueryResult), (
                    "result is not a QueryResult"
                )
                while result.has_next():
                    row = result.get_next()
                    if row and len(row) > 1:
                        existing_tables.add(row[1])  # type: ignore

            # Check for essential tables
            required_tables = {"Memory", "Thread", "Entity", "Label"}
            missing_tables = required_tables - existing_tables

            if missing_tables:
                logger.warning(
                    "Missing required tables - migrations may not have run",
                    missing_tables=list(missing_tables),
                    existing_tables=list(existing_tables),
                )
                # For fresh installs, create basic schema
                if not existing_tables:
                    logger.debug(
                        "No tables found, creating basic schema for fresh install"
                    )
                    await self._create_basic_schema()
            else:
                logger.debug(
                    "Schema verification passed",
                    tables_found=len(existing_tables),
                    embedding_dimension=self.embedding_dimension,
                )

        except Exception as e:
            logger.error("Failed to verify schema", error=str(e))
            # Try to create basic schema for fresh installs
            logger.info("Attempting to create basic schema as fallback")
            await self._create_basic_schema()

    async def _create_basic_schema(self) -> None:
        """Create basic schema for fresh installations only."""
        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            # Use dynamic schema generation with configured embedding dimension
            init_sequence = get_init_sequence(self.embedding_dimension)
            failed_queries: list[tuple[int, str, str]] = []

            for i, query in enumerate(init_sequence):
                try:
                    self.conn.execute(query)
                    logger.debug(
                        f"Successfully executed schema query {i + 1}/{len(init_sequence)}"
                    )
                except Exception as query_error:
                    if "already exists" in str(query_error).lower():
                        logger.debug(f"Table already exists (skipping): {query_error}")
                    else:
                        logger.warning(
                            f"Failed to execute schema query {i + 1}: {query_error}"
                        )
                        failed_queries.append((i, query, str(query_error)))

            logger.debug(
                "Basic schema created for fresh installation",
                embedding_dimension=self.embedding_dimension,
                total_queries=len(init_sequence),
                failed_queries=len(failed_queries),
            )

        except Exception as e:
            logger.error("Failed to create basic schema", error=str(e))
            raise

    async def recreate_memory_vector_index(self) -> None:
        """Drop and recreate the Memory vector index (v1 only).

        This is a workaround for KuzuDB 0.11.1 bug where checkpointing on an empty
        Memory table corrupts the vector index. By dropping and recreating the index
        when the table becomes empty, we ensure the index stays consistent.

        In v2+, LanceDB handles search - this is a no-op.

        See: https://github.com/kuzudb/kuzu/issues/6045
        """
        if not self.conn:
            raise RuntimeError("Database connection not available")

        # Skip for v2+ databases - LanceDB handles search
        db_version = get_db_version(self.db_path)
        if db_version >= 2:
            logger.debug(
                "Skipping Kuzu vector index recreation for v2+ database - LanceDB handles search"
            )
            return

        try:
            # Step 1: Drop the index (ignore if it doesn't exist)
            try:
                self.conn.execute("""
                    CALL DROP_VECTOR_INDEX('Memory', 'memory_embedding_idx_new')
                """)
                logger.info("Dropped Memory vector index for recreation")
            except Exception as e:
                error_msg = str(e).lower()
                if (
                    "does not exist" in error_msg
                    or "not found" in error_msg
                    or "doesn't have" in error_msg
                ):
                    logger.debug("Vector index does not exist, will create new one")
                else:
                    logger.warning(
                        "Failed to drop vector index (will try to create anyway)",
                        error=str(e),
                    )
                    # Continue anyway - try to create it

            # Step 2: Checkpoint to sync catalog state
            # Note: If checkpoint fails due to catalog corruption, we continue anyway
            # The index creation might still work despite the checkpoint failure
            try:
                self.conn.execute("CHECKPOINT;")
                logger.debug("Checkpointed after dropping vector index")
            except Exception as checkpoint_err:
                error_msg = str(checkpoint_err).lower()
                if "catalog" in error_msg:
                    logger.warning(
                        "Checkpoint failed due to catalog corruption - continuing with index creation anyway",
                        error=str(checkpoint_err),
                    )
                else:
                    logger.warning(
                        "Checkpoint failed - continuing with index creation anyway",
                        error=str(checkpoint_err),
                    )
                # Continue - index creation might still work

            # Step 3: Recreate the index (must be in separate execute call)
            self.conn.execute("""
                CALL CREATE_VECTOR_INDEX('Memory', 'memory_embedding_idx_new', 'embedding')
            """)
            logger.info("Recreated Memory vector index successfully")

        except Exception as e:
            logger.error("Vector index recreation failed", error=str(e))
            raise

    async def ensure_vector_indexes(self) -> None:
        """Ensure vector and FTS indexes exist for Memory table.

        For v2+ databases (cedar), indexes are NOT created because search
        is handled by LanceDB with BGE-M3 embeddings. This reduces DB size
        and improves write performance.
        """
        if not self.conn:
            raise RuntimeError("Database connection not available")

        # Check database version - skip index creation for v2+ (LanceDB handles search)
        db_version = get_db_version(self.db_path)
        if db_version >= 2:
            logger.info(
                "Skipping Kuzu vector/FTS index creation for v2+ database",
                version=db_version,
                reason="LanceDB handles search with BGE-M3 embeddings",
            )
            return

        try:
            # Create vector index using correct KuzuDB syntax
            # Based on docs: CALL CREATE_VECTOR_INDEX('table_name', 'index_name', 'column_name')
            try:
                vector_index_query = """
                    CALL CREATE_VECTOR_INDEX('Memory', 'memory_embedding_idx_new', 'embedding')
                """
                self.conn.execute(vector_index_query)
                logger.debug("Created vector index for Memory.embedding")
            except Exception as e:
                error_msg = str(e).lower()
                if (
                    "already exists" in error_msg
                    or "duplicate" in error_msg
                    or "index already exists" in error_msg
                ):
                    logger.debug("Vector index for Memory.embedding already exists")
                else:
                    logger.warning("Vector index creation failed", error=str(e))

            # Create FTS index for Memory semantic_field (combined title+content for search)
            try:
                self.conn.execute("""
                    CALL CREATE_FTS_INDEX('Memory', 'memory_semantic_index', ['semantic_field'])
                """)
                logger.debug("Created bm25 index for Memory.semantic_field")
            except Exception as e:
                error_msg = str(e).lower()
                if (
                    "already exists" in error_msg
                    or "duplicate" in error_msg
                    or "index already exists" in error_msg
                ):
                    logger.debug("bm25 index for Memory.semantic_field already exists")
                else:
                    logger.warning(
                        "bm25 index creation failed for Memory.semantic_field",
                        error=str(e),
                    )

            # Create additional FTS indexes for other tables
            try:
                self.conn.execute("""
                    CALL CREATE_FTS_INDEX('Entity', 'entity_content_index', ['name', 'description'])
                """)
                logger.debug("Created bm25 index for Entity name and description")
            except Exception as e:
                error_message = str(e).lower()
                if (
                    "already exists" in error_message
                    or "index with the same name" in error_message
                ):
                    logger.debug("bm25 index for Entity already exists")
                else:
                    logger.warning(
                        "bm25 index creation failed for Entity", error=str(e)
                    )

            # Create FTS index for Thread content
            try:
                self.conn.execute("""
                    CALL CREATE_FTS_INDEX('Thread', 'thread_content_index', ['title', 'summary'])
                """)
                logger.debug("Created bm25 index for Thread title and summary")
            except Exception as e:
                error_message = str(e).lower()
                if (
                    "already exists" in error_message
                    or "index with the same name" in error_message
                ):
                    logger.debug("bm25 index for Thread already exists")
                else:
                    logger.warning(
                        "bm25 index creation failed for Thread", error=str(e)
                    )

            # Create FTS index for Community name, description, and ai_summary
            try:
                self.conn.execute("""
                    CALL CREATE_FTS_INDEX('Community', 'community_summary_search', ['name', 'description', 'ai_summary'])
                """)
                logger.debug(
                    "Created bm25 index for Community name, description, and ai_summary"
                )
            except Exception as e:
                error_message = str(e).lower()
                if (
                    "already exists" in error_message
                    or "index with the same name" in error_message
                ):
                    logger.debug("bm25 index for Community already exists")
                else:
                    logger.warning(
                        "bm25 index creation failed for Community", error=str(e)
                    )

            # Create FTS index for Message content (for thread search)
            try:
                self.conn.execute("""
                    CALL CREATE_FTS_INDEX('Message', 'message_content_fts', ['content'])
                """)
                logger.debug("Created bm25 index for Message.content")
            except Exception as e:
                error_message = str(e).lower()
                if (
                    "already exists" in error_message
                    or "index with the same name" in error_message
                ):
                    logger.debug("bm25 index for Message already exists")
                else:
                    logger.warning(
                        "bm25 index creation failed for Message", error=str(e)
                    )

        except Exception as e:
            logger.error("Failed to ensure vector indexes", error=str(e))
            raise

    def _serialize_metadata(self, metadata: Dict[str, Any]) -> str:
        """Serialize metadata dictionary to JSON string."""
        return json.dumps(metadata) if metadata else "{}"

    def _deserialize_metadata(self, metadata_str: str) -> Dict[str, Any]:
        """Deserialize JSON string to metadata dictionary."""
        try:
            return json.loads(metadata_str) if metadata_str else {}
        except json.JSONDecodeError:
            return {}

    def _format_timestamp(self, dt: datetime.datetime) -> str:
        """Format datetime for KuzuDB."""
        return dt.isoformat()

    def _safe_parse_datetime(self, value: Any) -> datetime.datetime | None:
        """Safely parse datetime from various input types."""
        if value is None:
            return None

        if isinstance(value, datetime.datetime):
            # KuzuDB returns timezone-naive datetimes — treat as UTC
            if value.tzinfo is None:
                return value.replace(tzinfo=datetime.timezone.utc)
            return value

        if isinstance(value, str):
            try:
                return datetime.datetime.fromisoformat(value.replace("Z", "+00:00"))
            except ValueError:
                try:
                    # Try other common formats
                    return datetime.datetime.strptime(value, "%Y-%m-%d %H:%M:%S")
                except ValueError:
                    return None

        return None

    async def test_connection(self) -> Dict[str, Any]:
        """Test database connection and return basic info."""
        self._ensure_initialized()

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            # Test a simple query
            result = self.conn.execute("RETURN 1 as test")
            assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"
            test_value = result.get_next()[0] if result.has_next() else None  # type: ignore

            # Get table count
            try:
                tables_result = self.conn.execute("SHOW TABLES")
                table_count: Union[int, str]
                if isinstance(tables_result, list):
                    table_count = len(tables_result)
                elif hasattr(tables_result, "has_next"):
                    # Count QueryResult rows
                    count = 0
                    while tables_result.has_next():
                        tables_result.get_next()
                        count += 1
                    table_count = count
                else:
                    table_count = "unknown"
            except Exception:
                table_count = "unknown"

            return {
                "status": "connected",
                "database_path": str(self.db_path),
                "test_query": test_value,
                "tables": table_count,
            }

        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "database_path": str(self.db_path),
            }
