import datetime
import json
from typing import TYPE_CHECKING, Any, Optional

import structlog
import real_ladybug as kuzu

from nowledge_graph_server.config import get_settings
from nowledge_graph_server.models.memory import MemoryNode, MemorySearchResult
from nowledge_graph_server.models.graph import NodeType
from nowledge_graph_server.services.local_llm import get_local_llm_service
from nowledge_graph_server.services.json_utils import clean_and_parse_json
from nowledge_graph_server.database.utils import DatabaseUtils
from nowledge_graph_server.database.result_utils import iter_rows, managed_result

if TYPE_CHECKING:
    from nowledge_graph_server.database.search_engine import KuzuSearchEngine

logger = structlog.get_logger(__name__)


LABEL_COUNT_THRESHOLD = 50


def _normalize_date_for_comparison(date_str: str) -> str:
    """
    Normalize date string to YYYY-MM-DD format for comparison.

    Args:
        date_str: Date in format YYYY, YYYY-MM, or YYYY-MM-DD

    Returns:
        Normalized date string in YYYY-MM-DD format

    Examples:
        "2020" -> "2020-01-01"
        "2023-06" -> "2023-06-01"
        "2024-01-15" -> "2024-01-15"
    """
    if not date_str:
        return date_str

    if len(date_str) == 4:  # YYYY
        return f"{date_str}-01-01"
    elif len(date_str) == 7:  # YYYY-MM
        return f"{date_str}-01"
    return date_str  # Already YYYY-MM-DD


def validate_temporal_filters(
    event_date_from: Optional[str] = None,
    event_date_to: Optional[str] = None,
    recorded_date_from: Optional[str] = None,
    recorded_date_to: Optional[str] = None,
) -> None:
    """
    Validate temporal filter parameters (language-agnostic).

    Raises:
        ValueError: If date formats are invalid or logic is inconsistent

    Note: This validation is language-agnostic - it only validates:
    - Date format (ISO 8601 is universal)
    - Logical consistency (date arithmetic)
    Does NOT validate query text (no English-only assumptions).
    """
    import re

    # Date format pattern (YYYY, YYYY-MM, or YYYY-MM-DD)
    date_pattern = re.compile(r"^\d{4}(-\d{2})?(-\d{2})?$")

    # Validate formats
    for param_name, param_value in [
        ("event_date_from", event_date_from),
        ("event_date_to", event_date_to),
        ("recorded_date_from", recorded_date_from),
        ("recorded_date_to", recorded_date_to),
    ]:
        if param_value and not date_pattern.match(param_value):
            raise ValueError(
                f"Invalid date format for {param_name}: {param_value}. "
                f"Use YYYY, YYYY-MM, or YYYY-MM-DD"
            )

    # Logical consistency: event dates cannot be after record dates
    if event_date_from and recorded_date_from:
        event_year = int(event_date_from[:4])
        record_year = int(recorded_date_from[:4])

        if event_year > record_year:
            logger.warning(
                "Unusual query: event_date_from > recorded_date_from",
                event_date_from=event_date_from,
                recorded_date_from=recorded_date_from,
                event_year=event_year,
                record_year=record_year,
                message=(
                    f"Event year {event_year} is after record year {record_year}. "
                    "This filters for events that occurred AFTER they were recorded (rare). "
                    "Did you mean to swap the filters?"
                ),
            )


# Intent → Strategy mapping aligned with our three pipelines
INTENT_STRATEGY_MAPPING = {
    "concept_lookup": {  # Single terms, concepts (e.g., "AI", "blockchain")
        "entity": 0.8,  # High: Find entities matching the concept
        "vector": 0.8,  # High: Semantic similarity for concept matching
        "community": 0.4,  # Low: Community context
        "fts": 0.3,  # Low: Exact text matching
    },
    "factual_query": {  # Specific facts (e.g., "John's email", "Python version")
        "fts": 0.9,  # High: Exact text matching
        "entity": 0.6,  # Medium: Named entity lookup
        "vector": 0.3,  # Low: Semantic similarity
        "community": 0.2,  # Low: Community context
    },
    "conceptual_question": {  # How/why questions (e.g., "How does ML work?")
        "vector": 0.9,  # High: Semantic understanding
        "community": 0.7,  # Medium: Community knowledge
        "entity": 0.5,  # Medium: Related concepts
        "fts": 0.3,  # Low: Exact matching
    },
    "exploratory_search": {  # Broad exploration (e.g., "machine learning trends")
        "community": 0.8,  # High: Community insights
        "vector": 0.7,  # High: Semantic similarity
        "entity": 0.6,  # Medium: Related entities
        "fts": 0.4,  # Medium: Text matching
    },
    "relationship_query": {  # Connections (e.g., "projects using React")
        "entity": 0.9,  # High: Entity relationships
        "community": 0.7,  # Medium: Community connections
        "vector": 0.5,  # Medium: Semantic similarity
        "fts": 0.4,  # Medium: Text matching
    },
}


def _build_memory_node(
    search_engine: "KuzuSearchEngine", memory_data: dict[str, Any]
) -> MemoryNode:
    """Build MemoryNode from database record."""
    # Parse metadata if it's a string
    metadata = memory_data.get("metadata", {})
    if isinstance(metadata, str):
        try:
            metadata = json.loads(metadata)
        except json.JSONDecodeError:
            metadata = {}

    return MemoryNode(
        id=memory_data["id"],
        content=memory_data.get("content", ""),
        metadata=metadata,
        node_type=NodeType.MEMORY,
        importance=memory_data.get("importance", 0.5),
        created_at=search_engine.client._safe_parse_datetime(
            memory_data.get("created_at")
        )
        or datetime.datetime.now(datetime.UTC),
        embedding=[],
        source=memory_data.get("source", ""),
        source_range=json.loads(memory_data["source_range"])
        if memory_data.get("source_range")
        and isinstance(memory_data["source_range"], str | bytes | bytearray)
        else None,
        title=memory_data.get("title", ""),
        confidence=memory_data.get("confidence", 0.5),
        semantic_field=f"{memory_data.get('title', '')},\n{memory_data.get('content', '')}",
        reindex_needed=memory_data.get("reindex_needed", False),
        last_reindexed_at=search_engine.client._safe_parse_datetime(
            memory_data.get("last_reindexed_at")
        ),
        updated_at=search_engine.client._safe_parse_datetime(
            memory_data.get("updated_at")
        )
        or datetime.datetime.now(datetime.UTC),
        # Decay model fields
        last_accessed_at=search_engine.client._safe_parse_datetime(
            memory_data.get("last_accessed_at")
        ),
        access_count=memory_data.get("access_count", 0),
        appearances=memory_data.get("appearances", 0),
        clicks=memory_data.get("clicks", 0),
        total_dwell_time_ms=memory_data.get("total_dwell_time_ms", 0),
        last_clicked_at=search_engine.client._safe_parse_datetime(
            memory_data.get("last_clicked_at")
        ),
        decay_score_cached=memory_data.get("decay_score_cached", 0.0) or 0.0,
        # Bi-temporal fields (convert date objects to strings)
        temporal_type=memory_data.get("temporal_type"),
        event_start=str(memory_data["event_start"]) if memory_data.get("event_start") else None,
        event_end=str(memory_data["event_end"]) if memory_data.get("event_end") else None,
        temporal_precision=memory_data.get("temporal_precision"),
        temporal_confidence=memory_data.get("temporal_confidence"),
        temporal_context=memory_data.get("temporal_context"),
        # Knowledge Agent fields (v0.6)
        unit_type=memory_data.get("unit_type", "fact"),
        is_latest=memory_data.get("is_latest", True),
        version=memory_data.get("version", 1),
        is_crystal=memory_data.get("is_crystal", False),
        crystal_title=memory_data.get("crystal_title"),
        source_unit_count=memory_data.get("source_unit_count"),
        extraction_method=memory_data.get("extraction_method", "manual"),
    )


async def _fuse_hybrid_results(
    search_engine: "KuzuSearchEngine",
    vector_results: list[tuple],
    fts_results: list[tuple],
    limit: int,
    label_results: list[tuple] | None = None,
    search_context: dict[str, Any] | None = None,
    entity_results: list[tuple] | None = None,
    community_results: list[tuple] | None = None,
) -> list[MemorySearchResult]:
    """Fuse vector and FTS results with intelligent scoring."""
    memory_scores = {}
    # Initialize debug metrics collector on context
    metrics = None
    if search_context is not None:
        metrics = search_context.setdefault("debug_metrics", {})

    # Process vector results
    for memory_data, score, source in vector_results:
        memory_id = memory_data["id"]
        memory_scores[memory_id] = {
            "data": memory_data,
            "vector_score": score,
            "fts_score": 0.0,
            "label_score": 0.0,
            "entity_score": 0.0,
            "community_score": 0.0,
            "sources": {source},
        }

    # Find max FTS (BM25) score for normalization
    fts_scores = [score for _, score, _ in fts_results]
    fts_max_score = max(fts_scores) if fts_scores else 1.0  # Prevent division by zero

    # Process FTS results
    for memory_data, score, source in fts_results:
        memory_id = memory_data["id"]
        normalized_fts_score = score / fts_max_score if fts_max_score > 0 else 0.0
        if memory_id in memory_scores:
            memory_scores[memory_id]["fts_score"] = normalized_fts_score
            memory_scores[memory_id]["sources"].add(source)
        else:
            memory_scores[memory_id] = {
                "data": memory_data,
                "vector_score": 0.0,
                "fts_score": normalized_fts_score,
                "label_score": 0.0,
                "entity_score": 0.0,
                "community_score": 0.0,
                "sources": {source},
            }

    # Process label results
    if label_results:
        for memory_data, score, source in label_results:
            memory_id = memory_data["id"]
            if memory_id in memory_scores:
                memory_scores[memory_id]["label_score"] = score
                memory_scores[memory_id]["sources"].add(source)
            else:
                memory_scores[memory_id] = {
                    "data": memory_data,
                    "vector_score": 0.0,
                    "fts_score": 0.0,
                    "label_score": score,
                    "entity_score": 0.0,
                    "community_score": 0.0,
                    "sources": {source},
                }

    # Process entity results
    if entity_results:
        for memory_data, score, source in entity_results:
            memory_id = memory_data["id"]
            if memory_id in memory_scores:
                memory_scores[memory_id]["entity_score"] = score
                memory_scores[memory_id]["sources"].add(source)
            else:
                memory_scores[memory_id] = {
                    "data": memory_data,
                    "vector_score": 0.0,
                    "fts_score": 0.0,
                    "label_score": 0.0,
                    "entity_score": score,
                    "community_score": 0.0,
                    "sources": {source},
                }

    # Process community results
    if community_results:
        for memory_data, score, source in community_results:
            memory_id = memory_data["id"]
            if memory_id in memory_scores:
                memory_scores[memory_id]["community_score"] = score
                memory_scores[memory_id]["sources"].add(source)
            else:
                memory_scores[memory_id] = {
                    "data": memory_data,
                    "vector_score": 0.0,
                    "fts_score": 0.0,
                    "label_score": 0.0,
                    "entity_score": 0.0,
                    "community_score": score,
                    "sources": {source},
                }

    # Calculate combined scores and create results
    results = []

    # IMPROVED: Dynamic score recalibration for new embedding model
    vector_scores = [
        info["vector_score"]
        for info in memory_scores.values()
        if info["vector_score"] > 0
    ]
    vector_min = 0.0
    vector_max = 0.0
    vector_range = 0.0
    if vector_scores:
        vector_min = min(vector_scores)
        vector_max = max(vector_scores)
        vector_range = vector_max - vector_min
        logger.debug(
            "Vector score distribution",
            min=vector_min,
            max=vector_max,
            range=vector_range,
        )
        if metrics is not None:
            metrics["vector_score_min"] = float(vector_min)
            metrics["vector_score_max"] = float(vector_max)
            metrics["vector_score_range"] = float(vector_range)

    for memory_id, info in memory_scores.items():
        # Normalize scores - ENHANCED NORMALIZATION FOR NEW MODEL
        vector_raw = info["vector_score"]
        fts_raw = info["fts_score"]
        label_raw = info.get("label_score", 0.0)
        entity_raw = info.get("entity_score", 0.0)
        community_raw = info.get("community_score", 0.0)

        # Use actual similarity scores instead of range normalization
        vector_norm = min(vector_raw, 1.0)

        # FTS score normalization (already 0-1 range)
        fts_norm = min(fts_raw, 1.0)

        # Label score normalization (already 0-1 range)
        label_norm = min(label_raw, 1.0) if label_raw > 0 else 0.0

        # Entity score normalization (already 0-1 range)
        entity_norm = min(entity_raw, 1.0) if entity_raw > 0 else 0.0

        # Community score normalization (already 0-1 range)
        community_norm = min(community_raw, 1.0) if community_raw > 0 else 0.0

        # DYNAMIC: Use intent-based weights for result fusion instead of hardcoded coefficients
        weights = search_context.get("weights", {}) if search_context else {}
        vector_weight = weights.get("vector", 0.6)
        fts_weight = weights.get("fts", 0.4)
        entity_weight = weights.get("entity", 0.3)
        community_weight = weights.get("community", 0.2)

        # Normalize fusion weights to sum to 1.0 for the available sources
        available_sources = info["sources"]
        fusion_weights = {}
        total_weight = 0.0

        if "vector" in available_sources:
            fusion_weights["vector"] = vector_weight
            total_weight += vector_weight
        if "fts" in available_sources:
            fusion_weights["fts"] = fts_weight
            total_weight += fts_weight
        if "label" in available_sources:
            fusion_weights["label"] = (
                entity_weight  # Label search is part of entity strategy
            )
            total_weight += entity_weight
        if "entity" in available_sources:
            fusion_weights["entity"] = entity_weight
            total_weight += entity_weight
        if "community" in available_sources:
            fusion_weights["community"] = community_weight
            total_weight += community_weight

        # Normalize weights
        if total_weight > 0:
            for key in fusion_weights:
                fusion_weights[key] /= total_weight

        # Initialize defaults
        combined_score = 0.0
        reason = "No match"

        # Apply dynamic fusion based on available sources and intent weights
        if (
            "label" in info["sources"]
            or "entity" in info["sources"]
            or "community" in info["sources"]
        ) and len(info["sources"]) > 1:
            # Multi-source with label/entity/community: use normalized intent weights
            v_w = fusion_weights.get("vector", 0.2)
            f_w = fusion_weights.get("fts", 0.3)
            l_w = fusion_weights.get("label", 0.0)
            e_w = fusion_weights.get("entity", 0.0)
            c_w = fusion_weights.get("community", 0.0)
            combined_score = (
                vector_norm * v_w
                + fts_norm * f_w
                + label_norm * l_w
                + entity_norm * e_w
                + community_norm * c_w
            ) * 1.1

            # Enhanced user-friendly reason
            primary_sources = []
            if label_norm > 0.5:
                primary_sources.append(f"Label Match ({label_norm * 100:.0f}%)")
            if entity_norm > 0.5:
                primary_sources.append(f"Entity Match ({entity_norm * 100:.0f}%)")
            if community_norm > 0.5:
                primary_sources.append(f"Community Match ({community_norm * 100:.0f}%)")
            if vector_norm > 0.3:
                primary_sources.append(f"Semantic ({vector_norm * 100:.0f}%)")
            if fts_norm > 0.3:
                primary_sources.append(f"Text Match ({fts_norm * 100:.0f}%)")
            reason = (
                " + ".join(primary_sources)
                if primary_sources
                else "Multi-strategy match"
            )

            logger.debug(
                "Multi-source fusion",
                memory_id=memory_id,
                weights=fusion_weights,
                combined=combined_score,
            )
        elif "label" in info["sources"]:
            # Label only
            combined_score = label_norm
            reason = f"Label Match ({label_norm * 100:.0f}%)"
        elif "entity" in info["sources"]:
            # Entity only
            combined_score = entity_norm
            reason = f"Entity Match ({entity_norm * 100:.0f}%)"
        elif "community" in info["sources"]:
            # Community only
            combined_score = community_norm
            reason = f"Community Match ({community_norm * 100:.0f}%)"
        elif len(info["sources"]) > 1:
            # Vector + FTS hybrid: use similar logic as _fuse_vector_fts_fast for score fusion,
            # but keep intent-based weights for compatibility with upstream logic.
            v_w = fusion_weights.get("vector", 0.7 if vector_norm >= 0.83 else 0.4)
            f_w = 1.0 - v_w  # Keep fts and vector weights complementary

            combined_score = vector_norm * v_w + fts_norm * f_w

            # User-friendly reason string (consistent with multi-source threshold logic)
            reason_parts = []
            if vector_norm > 0.3:
                reason_parts.append(f"Semantic ({vector_norm * 100:.0f}%)")
            if fts_norm > 0.3:
                reason_parts.append(f"Text Match ({fts_norm * 100:.0f}%)")
            reason = " + ".join(reason_parts) if reason_parts else "Hybrid"

            logger.debug(
                "Hybrid fusion",
                memory_id=memory_id,
                vector_weight=v_w,
                fts_weight=f_w,
                combined=combined_score,
            )
        elif "vector" in info["sources"]:
            # Accept vector-only hits as strong (score untouched) only when very high.
            if vector_norm >= 0.848:
                combined_score = vector_norm
                reason = f"Semantic Match (strong, {vector_norm * 80:.0f}%)"
            else:
                # Our model is weak; text not hit, so penalize
                # Let low vector-only hits get capped down to a poor score (e.g. max 0.25)
                combined_score = min(vector_norm * 0.3, 0.25)
                reason = f"Semantic Match (weak, {vector_norm * 100:.0f}%)"
        else:
            combined_score = fts_norm
            reason = f"Text Match ({fts_norm * 100:.0f}%)"

        # Topic validation is computed after preliminary scoring list is assembled
        topic_adjusted_score = combined_score

        # Cap at 0.95 to prevent artificial 100%
        final_score = min(topic_adjusted_score, 0.95)

        memory_node = _build_memory_node(search_engine, info["data"])
        search_result = MemorySearchResult(
            memory=memory_node,
            similarity_score=final_score,
            relevance_reason=reason,
            related_entities=[],
        )

        results.append(search_result)

    # Sort prelim results by score
    results.sort(key=lambda x: x.similarity_score, reverse=True)

    # Apply adaptive semantic similarity threshold
    initial_count = len(results)
    if initial_count == 0:
        logger.debug("No results to filter, skipping semantic threshold")
    else:
        # Adaptive threshold for BGE-M3/Qwen3-Embedding (1024-dim)
        # These models have higher noise floor (~0.25-0.35) than E5-small (~0.15-0.25)
        if initial_count >= 10:
            semantic_threshold = 0.30  # Strict filtering when many results
        elif initial_count >= 5:
            semantic_threshold = 0.25  # Moderate filtering
        else:
            semantic_threshold = 0.20  # Lenient but still filters noise

        filtered_results = []
        for r in results:
            # Check if this result has reasonable semantic similarity
            if (
                hasattr(r, "similarity_score")
                and r.similarity_score >= semantic_threshold
            ):
                filtered_results.append(r)

        # Safety check: only keep top-3 if max score is reasonable (>0.4)
        # For low max scores, the query likely has no good matches - return empty
        max_score = results[0].similarity_score if results else 0.0
        if len(filtered_results) == 0 and initial_count > 0:
            if max_score >= 0.4:
                filtered_results = results[:3]
            # else: return empty - query has no good matches
        elif len(filtered_results) < 2 and initial_count >= 3:
            if max_score >= 0.4:
                filtered_results = results[:3]

        if metrics is not None:
            metrics["adaptive_threshold"] = float(semantic_threshold)
            metrics["pre_filter_count"] = int(initial_count)
            metrics["post_threshold_count"] = int(len(filtered_results))

        results = filtered_results
        logger.debug(
            "Adaptive semantic filtering applied",
            remaining=len(results),
            threshold=semantic_threshold,
            initial=initial_count,
        )

    # Late-stage content relevance on top-k only to reduce latency
    top_k = min(10, len(results))
    if top_k > 5 and search_context and search_context.get("mode", "fast") != "fast":
        refined: list[MemorySearchResult] = []
        floors_applied = 0
        penalized_count = 0
        for idx, r in enumerate(results):
            if idx < top_k:
                relevance = await _validate_content_relevance(
                    search_engine,
                    search_context.get("query_text", "") if search_context else "",
                    r.memory.content if r.memory else "",
                    r.memory.title if r.memory else "",
                    search_context or {},
                )
                # Relevance floor for very strong semantic matches to protect against small-LLM variance
                try:
                    query_terms = (
                        set(search_context.get("key_terms") or [])
                        if search_context
                        else set()
                    )
                    title_lc = (r.memory.title or "").lower() if r.memory else ""
                    content_lc = (r.memory.content or "").lower() if r.memory else ""
                    terms_present = (
                        all(t in title_lc or t in content_lc for t in query_terms)
                        if query_terms
                        else False
                    )
                except Exception:
                    terms_present = False

                if r.similarity_score >= 0.82 and terms_present and relevance < 0.7:
                    relevance = 0.7
                    floors_applied += 1

                # Multiply: similarity × relevance (which already has penalty applied)
                adjusted = r.similarity_score * relevance
                refined.append(
                    MemorySearchResult(
                        memory=r.memory,
                        similarity_score=adjusted,
                        relevance_reason=r.relevance_reason,
                        related_entities=[],
                    )
                )
            else:
                # Apply conservative penalty to unvalidated results (beyond top-k)
                conservative_penalty = 0.2
                adjusted = r.similarity_score * conservative_penalty
                # Cap at 0.25 to ensure they rank below validated moderate+ results
                adjusted = min(adjusted, 0.25)
                penalized_count += 1
                refined.append(
                    MemorySearchResult(
                        memory=r.memory,
                        similarity_score=adjusted,
                        relevance_reason=r.relevance_reason,
                        related_entities=[],
                    )
                )
        refined.sort(key=lambda x: x.similarity_score, reverse=True)

        # Store validation metrics
        if metrics is not None:
            metrics["validator_top_k"] = int(top_k)
            metrics["relevance_floor_applied"] = int(floors_applied)
            metrics["conservative_penalty_count"] = int(penalized_count)

        return refined[:limit]

    return results[:limit]


async def _fuse_vector_fts_fast(
    search_engine: "KuzuSearchEngine",
    vector_results: list[tuple],
    fts_results: list[tuple],
    limit: int,
) -> list[MemorySearchResult]:
    """Fast fusion of vector and FTS results without LLM validation or labels.

    - Uses simple weighted sum with emphasis on vector similarity.
    - Avoids HyDE/topic validation/penalties for low latency.
    - Applies a light semantic threshold with safety keep-top-3.
    """
    try:
        memory_scores: dict[str, dict[str, Any]] = {}

        # Collect vector results
        for memory_data, score, _ in vector_results:
            memory_id = memory_data["id"]
            memory_scores[memory_id] = {
                "data": memory_data,
                "vector_score": float(score),
                "fts_score": 0.0,
            }

        # Collect FTS results
        for memory_data, score, _ in fts_results:
            memory_id = memory_data["id"]
            if memory_id in memory_scores:
                memory_scores[memory_id]["fts_score"] = float(score)
            else:
                memory_scores[memory_id] = {
                    "data": memory_data,
                    "vector_score": 0.0,
                    "fts_score": float(score),
                }

        # Determine adaptive vector weight
        # Using cosine similarity (1 - distance) as scores
        vector_top = 0.0
        if vector_results:
            try:
                vector_top = max(float(v[1]) for v in vector_results)
            except Exception:
                vector_top = 0.0
        vector_weight = 0.7 if vector_top >= 0.83 else 0.5
        fts_weight = 1.0 - vector_weight  # 0.1 or 0.2 accordingly

        results: list[MemorySearchResult] = []
        for _, info in memory_scores.items():
            vector_raw = float(info.get("vector_score", 0.0))
            fts_raw = float(info.get("fts_score", 0.0))

            # Keep scores in 0..1 domain
            vector_norm = min(max(vector_raw, 0.0), 1.0)
            fts_norm = min(max(fts_raw, 0.0), 1.0)

            combined = vector_norm * vector_weight + fts_norm * fts_weight

            # Build result
            memory_node = _build_memory_node(search_engine, info["data"])
            reason_parts = []
            if vector_norm > 0:
                reason_parts.append(f"Semantic ({vector_norm * 100:.0f}%)")
            if fts_norm > 0:
                reason_parts.append(f"Text Match ({fts_norm * 100:.0f}%)")
            reason = " + ".join(reason_parts) if reason_parts else "Hybrid"

            results.append(
                MemorySearchResult(
                    memory=memory_node,
                    similarity_score=min(combined, 0.95),
                    relevance_reason=reason,
                    related_entities=[],
                )
            )

        # Sort by score desc
        results.sort(key=lambda r: r.similarity_score, reverse=True)

        # Light semantic threshold with safety keep-top-3
        # For BGE-M3/Qwen3-Embedding, noise floor is ~0.25-0.35, so use 0.30
        if results:
            threshold = 0.30
            filtered = [r for r in results if r.similarity_score >= threshold]
            if len(filtered) == 0:
                # Only keep top-3 if max score is reasonable (>0.4), else return empty
                max_score = results[0].similarity_score if results else 0
                if max_score >= 0.4:
                    filtered = results[:3]
                # else: return empty - query has no good matches
            results = filtered

        return results[:limit]

    except Exception as e:
        logger.warning("Fast fusion failed", error=str(e))
        # Fallback: build simple vector-only results if available
        fallback: list[MemorySearchResult] = []
        try:
            for memory_data, score, _ in vector_results[:limit]:
                memory_node = _build_memory_node(search_engine, memory_data)
                fallback.append(
                    MemorySearchResult(
                        memory=memory_node,
                        similarity_score=min(float(score), 1.0),
                        relevance_reason="Semantic Match",
                        related_entities=[],
                    )
                )
        except Exception:
            return []
        return fallback


FTS_QUERY_MEMORY = """
    CALL QUERY_FTS_INDEX(
        'Memory',
        'memory_semantic_index',
        $text_query
    )
    WITH node AS m, score AS fts_score
    WHERE fts_score > 0
    RETURN m, fts_score ORDER BY fts_score DESC LIMIT $limit
"""

VECTOR_QUERY_MEMORY = """
    CALL QUERY_VECTOR_INDEX(
        'Memory', 
        'memory_embedding_idx_new',
        $query_embedding,
        $limit
    )
    WITH node AS m, distance
    RETURN m, distance ORDER BY distance ASC
"""

COMMUNITY_FTS_QUERY = """
    CALL QUERY_FTS_INDEX(
        'Community',
        'community_summary_search',
        $text_query
    )
    WITH node as c, score as community_score
    WHERE community_score > 0
        AND c.ai_summary IS NOT NULL
        AND c.ai_summary <> ''
    RETURN c, community_score
    ORDER BY community_score DESC
    LIMIT 1
"""


def _calculate_strategy_weights(
    search_engine: "KuzuSearchEngine", context: dict[str, Any], query_text: str
) -> dict[str, Any]:
    """Calculate strategy weights based on refined intent detection aligned with our three pipelines."""

    # Use LLM-refined intent only (no heuristics)
    refined_intent = context.get("refined_intent", "exploratory_search")
    context["refined_intent"] = refined_intent
    # Get weights for the detected intent
    weights = INTENT_STRATEGY_MAPPING.get(
        refined_intent,
        {
            "vector": 0.6,
            "fts": 0.4,
            "entity": 0.3,
            "community": 0.2,  # Fallback
        },
    )

    logger.debug(
        "Intent-based weights calculated",
        query=query_text,
        intent=refined_intent,
        weights=weights,
    )

    context["weights"] = weights
    return context


async def _process_advanced_query_strategies(
    search_engine: "KuzuSearchEngine", context: dict[str, Any], query_text: str
) -> dict[str, Any]:
    """Apply advanced query processing strategies like HyDE and label search."""

    # Initialize advanced processing results
    context["advanced"] = {
        "use_hyde": False,
        "hyde_query": None,
        "label_search_enabled": False,
        "potential_labels": [],
        "query_rewrite": None,
    }

    refined_intent = context.get("refined_intent", "exploratory_search")

    # Simple strategy decisions based on intent
    # 1. HyDE for questions only (LLM signal only)
    if context.get("is_question", False):
        context["advanced"]["use_hyde"] = True
        context["advanced"]["hyde_query"] = await _generate_simple_hyde(
            search_engine, query_text
        )
        logger.debug("HyDE enabled for question", query=query_text)

    # 2. Label search for specific terms
    if refined_intent in ["concept_lookup", "factual_query", "relationship_query"]:
        key_terms = context.get("key_terms", [])
        if key_terms:
            context["advanced"]["label_search_enabled"] = True
            context["advanced"]["potential_labels"] = key_terms
            logger.debug("Label search enabled", labels=key_terms)
    logger.debug("Advanced query processing complete", context=context)
    return context


async def _generate_simple_hyde(
    search_engine: "KuzuSearchEngine", query_text: str
) -> str:
    """Generate simple hypothetical answer for HyDE embedding."""
    try:
        settings = get_settings()
        llm_service = await get_local_llm_service(
            cache_dir=settings.llm_cache_dir,
            cache_only=settings.llm_cache_only,
        )
        # Use LlamaIndex-inspired HyDE template
        prompt = f"""Please write a passage to answer the question
Try to include as many key details as possible.

{query_text}

Passage:"""
        response = await llm_service._generate_response(  # type: ignore
            prompt, max_tokens=60, use_thinking=False
        )

        hyde_query = response.strip()
        logger.debug("HyDE generated", query=query_text, hyde_query=hyde_query)
        return hyde_query

    except Exception as e:
        logger.warning("HyDE generation failed", error=str(e))
        return query_text  # Fallback to original


async def _identify_potential_labels(
    search_engine: "KuzuSearchEngine", query_text: str
) -> list[str]:
    """Identify potential labels that might be relevant to the query."""
    try:
        # First, extract key terms from the query
        terms = _extract_key_terms(search_engine, query_text)

        # Query existing labels that might match
        existing_labels = await _query_matching_labels(search_engine, terms)

        # Use LLM to suggest additional relevant labels
        suggested_labels = await _suggest_labels_llm(
            search_engine, query_text, existing_labels
        )

        # Combine and deduplicate
        all_labels = list(set(existing_labels + suggested_labels))
        logger.debug("Identified potential labels", labels=all_labels)
        return all_labels

    except Exception as e:
        logger.warning("Label identification failed", error=str(e))
        return []


def _extract_key_terms(search_engine: "KuzuSearchEngine", query_text: str) -> list[str]:
    """Deprecated: Key term extraction now handled by LLM for multilingual support."""
    # This method is kept for fallback only - LLM handles term extraction
    return query_text.split()[:3]


async def _query_matching_labels(
    search_engine: "KuzuSearchEngine", terms: list[str]
) -> list[str]:
    """Query existing labels using KuzuDB regex with multilingual support."""
    try:
        if not terms:
            return []

        # Build KuzuDB regex pattern for multilingual terms
        # Using regexp_matches for partial matching as documented
        patterns = []
        for term in terms:
            if not term or len(term.strip()) == 0:
                continue
            # Escape special regex characters in the term
            escaped_term = term.strip()
            for char in r"\.+*?[]{}()^$|":
                escaped_term = escaped_term.replace(char, f"\\{char}")
            patterns.append(f"(?i).*{escaped_term}.*")  # Case-insensitive partial match

        if not patterns:
            return []

        logger.debug("Generated regex patterns for label search", count=len(patterns))

        # Use regexp_matches for better multilingual support
        query = """
            MATCH (l:Label)
            WHERE regexp_matches(l.name, $pattern)
            RETURN DISTINCT l.name
            ORDER BY length(l.name)
            LIMIT 15
        """

        matched_labels = []
        for i, pattern in enumerate(patterns):
            try:
                assert search_engine.conn is not None
                result = search_engine.conn.execute(query, {"pattern": pattern})
                assert isinstance(result, kuzu.QueryResult)

                pattern_matches = 0
                for row in iter_rows(result):
                    label_name = row[0]  # type: ignore
                    if label_name not in matched_labels:
                        matched_labels.append(label_name)
                        pattern_matches += 1

            except Exception as e:
                logger.warning("Pattern matching failed", pattern=pattern, error=str(e))
                continue

        logger.debug("Label regex matching complete", matched_count=len(matched_labels))
        return matched_labels

    except Exception as e:
        logger.debug(f"Label regex query failed: {e}")
        return []


async def _suggest_labels_llm(
    search_engine: "KuzuSearchEngine", query_text: str, existing_labels: list[str]
) -> list[str]:
    """Use LLM to suggest relevant labels with smart context inclusion."""
    try:
        settings = get_settings()
        llm_service = await get_local_llm_service(
            cache_dir=settings.llm_cache_dir,
            cache_only=settings.llm_cache_only,
        )

        # Smart label context: include all labels if manageable scale, or sample if too many
        if len(existing_labels) == 0:
            # Get a sample of all labels if none matched
            all_labels = await _get_label_sample(search_engine)
            label_context = (
                f"Available labels: {', '.join(all_labels[:20])}"
                if all_labels
                else "No existing labels."
            )
        elif len(existing_labels) <= LABEL_COUNT_THRESHOLD:
            label_context = f"Matched labels: {', '.join(existing_labels)}"
        else:
            label_context = f"Some matched labels: {', '.join(existing_labels[:10])}... (+{len(existing_labels) - 10} more)"

        prompt = f"""Pick 2-3 most relevant labels from available options OR suggest new ones for this query.

{label_context}

Query: {query_text}

Best labels (comma-separated):"""

        # Set operation context for LangFuse tracking
        llm_service._current_operation = "label_suggestion"  # type: ignore
        response = await llm_service._generate_response(  # type: ignore
            prompt, max_tokens=40, use_thinking=False
        )

        # Parse comma-separated labels
        suggested = [label.strip() for label in response.split(",") if label.strip()]
        return suggested[:3]  # Limit to 3 suggestions for focus

    except Exception as e:
        logger.debug(f"LLM label suggestion failed: {e}")
        return []


async def _get_label_sample(search_engine: "KuzuSearchEngine") -> list[str]:
    """Get a representative sample of existing labels for LLM context."""
    try:
        query = """
            MATCH (l:Label)
            RETURN l.name
            ORDER BY l.name
            LIMIT 30
        """
        assert search_engine.conn is not None
        result = search_engine.conn.execute(query)
        assert isinstance(result, kuzu.QueryResult)

        labels = []
        for row in iter_rows(result):
            labels.append(row[0])  # type: ignore

        return labels

    except Exception as e:
        logger.debug(f"Label sample query failed: {e}")
        return []


async def _search_by_labels(
    search_engine: "KuzuSearchEngine", potential_labels: list[str], limit: int
) -> list[tuple[Any, float, str]]:
    """Search memories by label connections using KuzuDB HAS_LABEL relationships."""
    try:
        if not potential_labels:
            return []

        # Quick check: Do we have any labels at all?
        assert search_engine.conn is not None
        count_result = search_engine.conn.execute(
            "MATCH (l:Label) RETURN count(*) as label_count"
        )
        assert isinstance(count_result, kuzu.QueryResult), (
            f"count_result is not a kuzu.QueryResult: {type(count_result)}"
        )
        with managed_result(count_result):
            if count_result.has_next():
                label_count = count_result.get_next()[0]  # type: ignore
                if label_count == 0:
                    return []

        # Build query to find memories connected to these labels
        # Using the consolidated HAS_LABEL table (FROM Memory TO Label)
        # Escape regex special characters for Cypher regex (e.g., "C++", "test{", "Node.js")
        labels_pattern = "|".join(
            DatabaseUtils.escape_cypher_regex(label) for label in potential_labels[:5]
        )

        label_query = f"""
            MATCH (m:Memory)-[hl:HAS_LABEL]->(l:Label)
            WHERE l.name =~ '(?i).*({labels_pattern}).*'
            RETURN DISTINCT m, l.name as label_name,
                    COUNT(*) as label_connections
            ORDER BY label_connections DESC
            LIMIT $limit
        """
        assert search_engine.conn is not None
        result = search_engine.conn.execute(label_query, {"limit": limit})
        label_memories = []
        assert isinstance(result, kuzu.QueryResult)

        for row in iter_rows(result):
            memory_data = row[0]  # type: ignore
            label_name = row[1]  # type: ignore
            connections = float(row[2])  # type: ignore

            # Score based on label relevance and connections
            # Higher score for more connections and exact label matches
            base_score = 0.3  # Base score for label connection
            connection_bonus = min(connections * 0.1, 0.4)  # Up to 0.4 bonus

            # Exact match bonus
            exact_match_bonus = 0.0
            for potential_label in potential_labels:
                if potential_label.lower() in label_name.lower():
                    exact_match_bonus = 0.3
                    break

            total_score = base_score + connection_bonus + exact_match_bonus

            label_memories.append((memory_data, total_score, "label"))

        return label_memories

    except Exception as e:
        logger.debug(f"Label search failed: {e}")
        return []


async def _extract_entities_llm(
    search_engine: "KuzuSearchEngine", query_text: str
) -> list[str]:
    """Extract key entities using LLM."""
    try:
        settings = get_settings()
        llm_service = await get_local_llm_service(
            cache_dir=settings.llm_cache_dir,
            cache_only=settings.llm_cache_only,
        )

        prompt = f"""Extract 2-3 key entities (technologies, tools, concepts) from this search query.
Return only entity names, no explanations. in JSON format.

*Example:*
Query: "What is the best way to learn about the latest trends in AI?"
Entities:
{{"entities": ["AI", "Machine Learning"]}}

*End Example*

Now, extract the key entities from this query, note(DO-NOT-THINK, DO-NOT-EXPLAIN, JUST RETURN THE JSON):

Query: {query_text}

Entities:"""

        response = await llm_service._generate_response(  # type: ignore
            prompt, max_tokens=50, use_thinking=False
        )
        # Use json_repair to handle any JSON formatting issues
        try:
            data = clean_and_parse_json(response)
            if not isinstance(data, dict) or "entities" not in data:
                logger.warning("Response did not contain expected entities structure")
                entities = []
            else:
                entities = data["entities"]
        except Exception as e:
            logger.warning(
                f"Could not parse entities from response: {e}, response: {response}"
            )
            entities = []

        logger.debug(f"LLM extracted entities: {entities}")
        return entities[:3]

    except Exception as e:
        logger.error("Entity extraction failed", error=str(e))
        return []


def _deduplicate_results(
    search_engine: "KuzuSearchEngine", results: list[MemorySearchResult], limit: int
) -> list[MemorySearchResult]:
    """Remove duplicates and return top results."""
    seen_ids = set()
    unique_results = []

    # Sort by score first
    results.sort(key=lambda x: x.similarity_score, reverse=True)

    for result in results:
        memory_id = result.memory.id if result.memory else None
        if memory_id not in seen_ids:
            seen_ids.add(memory_id)
            unique_results.append(result)

            if len(unique_results) >= limit:
                break

    return unique_results


def _get_memory_labels_batch(
    search_engine: "KuzuSearchEngine",
    memory_ids: list[str],
) -> dict[str, list[str]]:
    """Batch fetch labels for multiple memories from the graph.
    
    Returns a dict mapping memory_id -> list of label names.
    """
    if not memory_ids:
        return {}
    
    try:
        assert search_engine.conn is not None
        # Batch query to get all labels for the given memory IDs
        query = """
            MATCH (m:Memory)-[:HAS_LABEL]->(l:Label)
            WHERE m.id IN $memory_ids
            RETURN m.id as memory_id, l.name as label_name
        """
        result = search_engine.conn.execute(query, {"memory_ids": memory_ids})
        
        labels_map: dict[str, list[str]] = {}
        assert isinstance(result, kuzu.QueryResult)
        for row in iter_rows(result):
            memory_id = row[0]  # type: ignore
            label_name = row[1]  # type: ignore
            if memory_id not in labels_map:
                labels_map[memory_id] = []
            labels_map[memory_id].append(label_name.lower())  # Normalize to lowercase for matching
        
        return labels_map
    except Exception as e:
        logger.warning(f"Failed to batch fetch memory labels: {e}")
        return {}


def _apply_filters(
    search_engine: "KuzuSearchEngine",
    results: list[MemorySearchResult],
    filters: dict[str, Any],
) -> list[MemorySearchResult]:
    """Apply filters to the results."""
    # Pre-fetch labels if label filter is present
    memory_labels_map: dict[str, list[str]] = {}
    if "labels" in filters and filters["labels"]:
        memory_ids = [r.memory.id for r in results if r.memory]
        memory_labels_map = _get_memory_labels_batch(search_engine, memory_ids)
        logger.debug(
            f"Label filter active: fetched labels for {len(memory_labels_map)} memories, "
            f"filter labels: {filters['labels']}"
        )
    
    filtered_results = []
    for result in results:
        memory_node = result.memory
        if not memory_node:
            continue

        # Apply importance filter
        if "importance_min" in filters:
            if memory_node.importance < filters["importance_min"]:
                continue

        # Apply labels filter - use graph-fetched labels instead of metadata
        if "labels" in filters and filters["labels"]:
            memory_labels = memory_labels_map.get(memory_node.id, [])
            if not memory_labels:
                # Memory has no labels, skip it
                continue
            # Check if ALL filter labels are present (case-insensitive)
            filter_labels_lower = [l.lower() for l in filters["labels"]]
            if not all(
                any(fl in ml for ml in memory_labels) for fl in filter_labels_lower
            ):
                continue

        # Apply event time filters (valid time - when the event occurred)
        if "event_date_from" in filters or "event_date_to" in filters:
            event_start = getattr(memory_node, "event_start", None)

            # Policy: Memories without event_start cannot match event date filters
            if not event_start:
                continue

            # Normalize to YYYY-MM-DD for comparison
            event_start_normalized = _normalize_date_for_comparison(event_start)

            if "event_date_from" in filters:
                filter_from = _normalize_date_for_comparison(filters["event_date_from"])
                if event_start_normalized < filter_from:
                    continue

            if "event_date_to" in filters:
                filter_to = _normalize_date_for_comparison(filters["event_date_to"])
                if event_start_normalized > filter_to:
                    continue

        # Apply temporal context filter
        if "temporal_context" in filters:
            mem_context = getattr(memory_node, "temporal_context", None)
            if mem_context != filters["temporal_context"]:
                continue

        # Apply record time filters (transaction time - when we recorded it)
        if "recorded_date_from" in filters:
            recorded_from = _normalize_date_for_comparison(filters["recorded_date_from"])
            created_at_normalized = memory_node.created_at.strftime("%Y-%m-%d") if memory_node.created_at else None
            if not created_at_normalized or created_at_normalized < recorded_from:
                continue

        if "recorded_date_to" in filters:
            recorded_to = _normalize_date_for_comparison(filters["recorded_date_to"])
            created_at_normalized = memory_node.created_at.strftime("%Y-%m-%d") if memory_node.created_at else None
            if not created_at_normalized or created_at_normalized > recorded_to:
                continue

        # Apply confidence filter
        if "confidence_min" in filters:
            if memory_node.confidence < filters["confidence_min"]:
                continue

        # Apply reindex_needed filter
        if "reindex_needed" in filters:
            if memory_node.reindex_needed != filters["reindex_needed"]:
                continue

        # Apply updated_at filter
        if "updated_from" in filters:
            if memory_node.updated_at < filters["updated_from"]:
                continue
        if "updated_to" in filters:
            if memory_node.updated_at > filters["updated_to"]:
                continue

        filtered_results.append(result)
    return filtered_results


async def _validate_content_relevance(
    search_engine: "KuzuSearchEngine",
    query_text: str,
    content: str,
    title: str,
    search_context: dict[str, Any],
) -> float:
    """
    Validate topical relevance between query and content using LLM.
    Returns a relevance score between 0.0 (completely unrelated) and 1.0 (highly relevant).
    """
    try:
        # Skip validation for very short content
        if len(content) < 50:
            return 1.0

        settings = get_settings()
        llm_service = await get_local_llm_service(
            cache_dir=settings.llm_cache_dir,
            cache_only=settings.llm_cache_only,
        )

        # Domain-agnostic validation prompt tuned to reduce cross-domain false positives
        prompt = f"""Rate how well this content matches the search query topic. Judge by semantic/topic alignment only.

Query: {query_text}

Content: {title}
{content[:400]}...

Score 0-10 based on TOPIC match (ignore language/wording differences):
0-2: Completely different topics
3-4: Distant relation, different domains
5-6: Same general field, different specific focus
7-8: Related topics with meaningful overlap
9-10: Same core topic OR directly addresses the relationship/comparison implied by the query (e.g., differences, similarities, evolutionary/causal relation)

Guidelines:
- Only assign 7-10 if the content explicitly discusses the SAME entities/topics (by name or obvious equivalent) OR their direct relationship
- If the content is clearly from a different domain than the query (e.g., software/dev vs biology), score 0-2
- Do not require exact phrasing or list formats; focus on the underlying topic/relationship

Score (0-10):"""

        response = await llm_service._generate_response(  # type: ignore
            prompt, max_tokens=32, use_thinking=False
        )

        # Early exit: if response is empty/truncated, do not penalize (treat as neutral)
        if not response or not response.strip():
            return 1.0

        # Parse relevance score - handle various LLM response formats
        try:
            score_text = response.strip()
            # Extract number from various formats:
            # "Score (0-10): 10", "10", "0", "Score: 8.5",
            # "**Score: 0**\n\n**Reasoning:**..." (Anthropic)
            import re

            raw_score = None

            # Strategy 1: Look for explicit "Score:" patterns in first non-empty line
            # This handles Anthropic's "**Score: 0**" format
            lines = [l.strip() for l in score_text.split("\n") if l.strip()]
            if lines:
                first_line = lines[0]
                # Match "Score: 5", "**Score: 0**", "Score (0-10): 7", etc.
                score_match = re.search(
                    r"Score\s*(?:\([^)]*\))?\s*:\s*(\d+(?:\.\d+)?)",
                    first_line,
                    re.IGNORECASE,
                )
                if score_match:
                    raw_score = float(score_match.group(1))

            # Strategy 2: Check if first line is just a standalone number
            if raw_score is None and lines and lines[0]:
                first_line_match = re.match(r"^\s*(\d+(?:\.\d+)?)\s*$", lines[0])
                if first_line_match:
                    raw_score = float(first_line_match.group(1))

            # Strategy 3: If no explicit pattern, look for first number in response
            if raw_score is None:
                matches = re.findall(r"(\d+(?:\.\d+)?)", score_text)
                if matches:
                    raw_score = float(matches[0])

            if raw_score is not None:
                # Validate range - clamp out-of-range values
                if raw_score < 0:
                    raw_score = 0.0
                elif raw_score > 10:
                    raw_score = 10.0
                # Convert 0-10 scale to 0.0-1.0 scale
                relevance_score = raw_score / 10.0
            else:
                logger.warning("Could not parse score from LLM response", response=score_text[:100])
                relevance_score = 0.1  # Default to low relevance

        except Exception as e:
            logger.warning(
                f"LLM relevance parsing failed: {e}, response: '{response.strip()}'"
            )
            relevance_score = 0.1  # Default to low relevance if parsing fails

        # Apply penalties to normalized 0.0-1.0 score (already divided by 10)
        # This is the ONLY place we apply LLM-based penalties
        # The score is ALREADY 0.0-1.0 here (0/10 → 0.0, 5/10 → 0.5, 10/10 → 1.0)
        if relevance_score < 0.3:  # LLM gave 0-2/10
            # Extremely heavy penalty for completely unrelated content
            relevance_score *= 0.05
        elif relevance_score < 0.5:  # LLM gave 3-4/10
            # Heavy penalty for distant relation
            relevance_score *= 0.3
        elif relevance_score < 0.7:  # LLM gave 5-6/10
            # Moderate penalty for same field, different focus
            relevance_score *= 0.6
        elif relevance_score < 0.9:  # LLM gave 7-8/10
            # Light penalty for related topics
            relevance_score *= 0.85
        # else: LLM gave 9-10/10 - direct match, keep full score
        # No additional penalty needed for perfect matches

        return relevance_score

    except Exception as e:
        logger.warning(f"Content relevance validation failed: {e}")
        return 1.0  # Default to no penalty if validation fails


STOP_WORDS = set(
    [
        "a",
        "an",
        "and",
        "are",
        "as",
        "at",
        "be",
        "by",
        "for",
        "from",
        "has",
        "he",
        "in",
        "is",
        "it",
        "of",
        "on",
        "or",
        "that",
        "the",
        "to",
        "was",
        "were",
        "will",
        "with",
        "的",
        "是",
        "有",
        "我",
        "你",
        "他",
        "她",
        "它",
        "我们",
        "你们",
        "他们",
        "她们",
        "它们",
    ]
)
