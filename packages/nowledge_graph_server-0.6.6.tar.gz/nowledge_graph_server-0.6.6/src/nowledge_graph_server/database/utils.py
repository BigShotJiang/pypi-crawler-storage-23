"""
Database Utils

Shared utility functions for database operations.
"""

from typing import Any, Dict, List
import structlog
import re
import uuid
import json

logger = structlog.get_logger(__name__)


def build_kuzu_params(**kwargs: Any) -> Dict[str, Any]:
    """Build KuzuDB query parameters from keyword arguments."""
    params: Dict[str, Any] = {}
    for key, value in kwargs.items():
        if value is not None:
            params[key] = value
    return params


class DatabaseUtils:
    """Utility functions for database operations."""

    @staticmethod
    def build_pagination_query(base_query: str, limit: int, offset: int) -> str:
        """Add pagination to a query."""
        # Remove any existing SKIP/LIMIT clauses
        query = re.sub(r"\s+(SKIP|LIMIT)\s+\d+", "", base_query, flags=re.IGNORECASE)

        # Add pagination
        pagination = f" SKIP {offset}"
        if limit > 0:
            pagination += f" LIMIT {limit}"

        return query + pagination

    @staticmethod
    def build_filter_conditions(filters: Dict[str, Any]) -> str:
        """Build WHERE conditions from filter dictionary."""
        if not filters:
            return ""

        conditions: List[str] = []
        for key, value in filters.items():
            if value is None:
                continue
            if isinstance(value, (list, tuple)):
                if not value:  # Check for empty sequence
                    continue
                # IN clause for lists
                value_list = ", ".join(
                    f"'{DatabaseUtils.escape_cypher_string(str(v))}'" if isinstance(v, str) else str(v) for v in value # type: ignore
                )
                conditions.append(f"{key} IN [{value_list}]")
            elif isinstance(value, str):
                # String equality
                conditions.append(f"{key} = '{value}'")
            elif isinstance(value, (int, float)):
                # Numeric equality
                conditions.append(f"{key} = {value}")
            elif isinstance(value, bool):
                # Boolean equality
                conditions.append(f"{key} = {str(value).lower()}")

        if conditions:
            return "WHERE " + " AND ".join(conditions)
        return ""

    @staticmethod
    def validate_uuid(uuid_string: str) -> bool:
        """Validate UUID format."""
        try:
            uuid.UUID(uuid_string)
            return True
        except ValueError:
            return False

    @staticmethod
    def sanitize_fts_query(query: str) -> str:
        """Sanitize full-text search query."""
        if not query:
            return ""

        # Remove special characters that might break FTS
        sanitized = re.sub(r"[^\w\s\-\+\*\?]", " ", query)

        # Collapse multiple spaces
        sanitized = re.sub(r"\s+", " ", sanitized)

        # Trim and return
        return sanitized.strip()

    @staticmethod
    def escape_cypher_string(value: str) -> str:
        """Escape string for safe use in Cypher queries."""
        # Escape quotes and backslashes
        escaped = value.replace("\\", "\\\\").replace("'", "\\'").replace('"', '\\"')
        return escaped

    @staticmethod
    def escape_cypher_regex(value: str) -> str:
        """Escape string for safe use in Cypher regex patterns.

        Cypher regex uses standard regex syntax, so we need to escape regex
        metacharacters. In Cypher string literals, backslashes are also escape
        characters, so we need double escaping.

        For example, to match literal "{" in Cypher regex:
        - Regex needs: \\{
        - Cypher string needs: \\\\{

        To match literal backslash:
        - Regex needs: \\\\
        - Cypher string needs: \\\\\\\\

        Args:
            value: Raw string to escape for regex

        Returns:
            String safe to use in Cypher regex pattern
        """
        if not value:
            return value

        # First, escape backslashes (special case: need 4 backslashes in Cypher string)
        # Input backslash -> \\\\  in Cypher string -> \\ in regex -> matches literal \
        result = value.replace('\\', '\\\\\\\\')

        # Then escape other regex metacharacters
        # Each needs \\ prefix in Cypher string to become \ in regex
        other_metacharacters = ['^', '$', '.', '|', '?', '*', '+', '(', ')', '[', ']', '{', '}']
        for char in other_metacharacters:
            result = result.replace(char, f'\\\\{char}')

        # Escape single quotes - not a regex metacharacter, but terminates
        # Cypher single-quoted string literals. Only needs single-level escaping.
        # Common in pinyin input like "hui'gu'de" for 回顾的.
        result = result.replace("'", "\\'")

        return result

    @staticmethod
    def format_memory_metadata(metadata: Dict[str, Any]) -> str:
        """Format memory metadata for database storage."""
        if not metadata:
            return "{}"

        # Remove None values and format as JSON string
        cleaned = {k: v for k, v in metadata.items() if v is not None}
        return json.dumps(cleaned)

    @staticmethod
    def parse_memory_metadata(metadata_str: str) -> Dict[str, Any]:
        """Parse memory metadata from database storage."""
        if not metadata_str:
            return {}

        try:
            return json.loads(metadata_str)
        except (json.JSONDecodeError, TypeError):
            logger.warning("Failed to parse metadata", metadata=metadata_str)
            return {}
