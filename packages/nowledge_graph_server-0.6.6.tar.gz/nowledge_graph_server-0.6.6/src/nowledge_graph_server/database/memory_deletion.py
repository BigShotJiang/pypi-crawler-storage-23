"""
Memory Deletion Operations

Cascade deletion, orphan detection, and entity cleanup for memories.
Extracted from memory_repository.py to keep files under the build limit.
"""

from typing import List, Dict, Any, cast
import structlog
import real_ladybug as kuzu

from nowledge_graph_server.database.base_client import KuzuBaseClient
from nowledge_graph_server.database.result_utils import iter_rows, managed_result

logger = structlog.get_logger(__name__)


class MemoryDeletionManager:
    """Handles memory deletion with cascade cleanup of orphaned entities."""

    def __init__(self, client: KuzuBaseClient):
        self.client = client

    @property
    def conn(self) -> kuzu.Connection | None:
        return cast(kuzu.Connection | None, self.client.conn)  # type: ignore[attr-defined]

    async def delete_memory(self, memory_id: str) -> bool:
        """Delete a memory and its relationships safely, handling vector index edges."""
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            logger.info("Starting memory deletion", memory_id=memory_id)

            # Use DETACH DELETE to remove memory and all its relationships atomically
            delete_query = """
                MATCH (m:Memory {id: $memory_id})
                DETACH DELETE m
            """

            logger.debug("Executing DETACH DELETE for memory", memory_id=memory_id)
            self.conn.execute(delete_query, {"memory_id": memory_id})

            logger.info(
                "Memory deleted successfully with DETACH DELETE", memory_id=memory_id
            )
            return True

        except Exception as e:
            logger.error("Failed to delete memory", memory_id=memory_id, error=str(e))
            # Return False instead of raising to prevent API crashes
            return False

    async def delete_relationships_from_memory(self, memory_id: str) -> int:
        """Delete RELATES_TO relationships that were created from a specific memory.

        Args:
            memory_id: Memory ID to clean up relationships from

        Returns:
            Number of relationships deleted
        """
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            logger.debug(
                "Deleting relationships created from memory", memory_id=memory_id
            )

            # First, count the relationships to be deleted for logging
            count_query = """
                MATCH (e1:Entity)-[r:RELATES_TO]->(e2:Entity)
                WHERE r.source_reference = $memory_id
                RETURN count(r) as count
            """

            result = self.conn.execute(count_query, {"memory_id": memory_id})
            count_to_delete = 0
            with managed_result(result):
                if result.has_next():  # type: ignore
                    count_to_delete = result.get_next()[0]  # type: ignore

            logger.debug(
                "Found relationships to delete",
                memory_id=memory_id,
                count=count_to_delete,
            )

            if count_to_delete == 0:
                logger.debug(
                    "No relationships to delete from memory", memory_id=memory_id
                )
                return 0

            # Delete the relationships using proper KuzuDB syntax
            delete_query = """
                MATCH (e1:Entity)-[r:RELATES_TO]->(e2:Entity)
                WHERE r.source_reference = $memory_id
                DELETE r
            """

            self.conn.execute(delete_query, {"memory_id": memory_id})

            logger.info(
                "Deleted relationships from memory",
                memory_id=memory_id,
                deleted_count=count_to_delete,
            )
            return count_to_delete  # type: ignore[return-value]

        except Exception as e:
            logger.error(
                "Failed to delete relationships from memory",
                memory_id=memory_id,
                error=str(e),
            )
            return 0

    async def delete_memory_with_cascade(self, memory_id: str) -> Dict[str, Any]:
        """Delete a memory with proper cascade deletion of orphaned entities.

        Args:
            memory_id: Memory to delete

        Returns:
            Deletion result with counts
        """
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            logger.info("Starting enhanced cascade deletion", memory_id=memory_id)

            # Step 1: Find entities that would become orphaned
            orphaned_entities = await self.find_orphaned_entities_after_memory_deletion(
                memory_id
            )

            # Step 2a: Decrement source.memory_count for SOURCED_FROM edges
            try:
                sourced_result = self.conn.execute(
                    "MATCH (m:Memory {id: $id})-[:SOURCED_FROM]->(s:Source) RETURN s.id",
                    {"id": memory_id},
                )
                source_ids = [row[0] for row in sourced_result.get_as_df().values]
                for sid in source_ids:
                    self.conn.execute(
                        "MATCH (s:Source {id: $id}) SET s.memory_count = CASE "
                        "WHEN s.memory_count > 0 THEN s.memory_count - 1 ELSE 0 END",
                        {"id": sid},
                    )
                if source_ids:
                    logger.info("Decremented source memory_count", source_ids=source_ids)
            except Exception as e:
                logger.warning("Failed to decrement source memory_count", error=str(e))

            # Step 2b: Delete RELATES_TO relationships created from this memory
            deleted_source_relationships = await self.delete_relationships_from_memory(
                memory_id
            )

            # Step 3: Delete the memory (this removes MENTIONS + SOURCED_FROM relationships)
            memory_deleted = await self.delete_memory(memory_id)

            if not memory_deleted:
                return {
                    "deleted": False,
                    "error": "Failed to delete memory",
                    "deleted_relationships": 0,
                    "deleted_entities": 0,
                }

            # Step 4: Delete orphaned entities
            deleted_entities = await self.delete_orphaned_entities(orphaned_entities)

            # Step 5: Calculate total relationships deleted
            # MENTIONS relationships are deleted automatically with DETACH DELETE
            # Plus the RELATES_TO relationships we explicitly deleted
            total_deleted_relationships = (
                len(orphaned_entities) + deleted_source_relationships
            )

            # NOTE: Checkpoint is handled at the operation level (memory_operations.py)

            logger.info(
                "Enhanced cascade deletion completed",
                memory_id=memory_id,
                deleted_entities=deleted_entities,
                deleted_source_relationships=deleted_source_relationships,
                total_deleted_relationships=total_deleted_relationships,
            )

            return {
                "deleted": True,
                "deleted_relationships": total_deleted_relationships,
                "deleted_entities": deleted_entities,
                "deleted_source_relationships": deleted_source_relationships,
                "orphaned_entities_found": len(orphaned_entities),
            }

        except Exception as e:
            logger.error(
                "Failed to delete memory with enhanced cascade",
                memory_id=memory_id,
                error=str(e),
            )
            return {
                "deleted": False,
                "error": str(e),
                "deleted_relationships": 0,
                "deleted_entities": 0,
            }

    async def find_orphaned_entities_after_memory_deletion(
        self, memory_id: str
    ) -> List[str]:
        """Find entities that would become orphaned after deleting a memory.

        Args:
            memory_id: Memory that will be deleted

        Returns:
            List of entity IDs that would become orphaned
        """
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        try:
            logger.debug(
                "Finding orphaned entities for memory deletion", memory_id=memory_id
            )

            # Find entities connected to this memory via MENTIONS
            mentions_query = """
                MATCH (m:Memory {id: $memory_id})-[:MENTIONS]->(e:Entity)
                RETURN e.id as entity_id, e.name as entity_name
            """

            result = self.conn.execute(mentions_query, {"memory_id": memory_id})
            connected_entities: List[dict[str, Any]] = []
            seen_entity_ids: set[str] = set()

            for row in iter_rows(result):  # type: ignore
                entity_id = row[0]  # type: ignore
                if entity_id not in seen_entity_ids:
                    connected_entities.append(
                        {
                            "id": entity_id,
                            "name": row[1],  # type: ignore
                        }
                    )
                    seen_entity_ids.add(entity_id)

            # ALSO find entities that are connected via RELATES_TO from this memory
            # These entities might not have MENTIONS to this memory, but have relationships
            # that were created during this memory's distillation.
            relates_to_query = """
                MATCH (e:Entity)-[r:RELATES_TO]-()
                WHERE r.source_reference = $memory_id
                RETURN DISTINCT e.id as entity_id, e.name as entity_name
            """

            relates_result = self.conn.execute(relates_to_query, {"memory_id": memory_id})
            for row in iter_rows(relates_result):  # type: ignore
                entity_id = row[0]  # type: ignore
                if entity_id not in seen_entity_ids:
                    connected_entities.append(
                        {
                            "id": entity_id,
                            "name": row[1],  # type: ignore
                        }
                    )
                    seen_entity_ids.add(entity_id)
                    logger.debug(
                        "Found entity connected via RELATES_TO only",
                        entity_id=entity_id,
                        entity_name=row[1],
                    )

            logger.debug(
                "Found entities connected to memory",
                memory_id=memory_id,
                entity_count=len(connected_entities),
                entities=[e["name"] for e in connected_entities],
            )

            orphaned_entities: List[str] = []

            # Check each entity to see if it would become orphaned
            for entity in connected_entities:
                entity_id = entity["id"]
                entity_name = entity["name"]

                logger.debug(
                    "Checking if entity would be orphaned",
                    entity_id=entity_id,
                    entity_name=entity_name,
                )

                # Check for other MENTIONS relationships from other memories
                other_mentions_query = """
                    MATCH (e:Entity {id: $entity_id})<-[:MENTIONS]-(other_memory:Memory)
                    WHERE other_memory.id <> $memory_id
                    RETURN count(*) as other_mentions_count
                """
                other_mentions_result = self.conn.execute(
                    other_mentions_query,
                    {"entity_id": entity_id, "memory_id": memory_id},
                )
                other_mentions_count = 0
                with managed_result(other_mentions_result):
                    if other_mentions_result.has_next():  # type: ignore
                        other_mentions_count = other_mentions_result.get_next()[0]  # type: ignore

                # Check for entity-entity relationships NOT created from this memory (bidirectional)
                entity_rels_query = """
                    MATCH (e:Entity {id: $entity_id})
                    OPTIONAL MATCH (e)-[r1:RELATES_TO]-()
                    WHERE r1.source_reference <> $memory_id
                       OR r1.source_reference IS NULL
                       OR r1.source_reference = ''
                    OPTIONAL MATCH ()-[r2:RELATES_TO]->(e)
                    WHERE r2.source_reference <> $memory_id
                       OR r2.source_reference IS NULL
                       OR r2.source_reference = ''
                    RETURN (count(r1) + count(r2)) as external_entity_rel_count
                """
                entity_rels_result = self.conn.execute(
                    entity_rels_query, {"entity_id": entity_id, "memory_id": memory_id}
                )
                external_entity_rel_count = 0
                with managed_result(entity_rels_result):
                    if entity_rels_result.has_next():  # type: ignore
                        external_entity_rel_count = entity_rels_result.get_next()[0]  # type: ignore

                # Check for label relationships (HAS_LABEL) - these are user-assigned, not memory-specific
                label_rels_query = """
                    MATCH (e:Entity {id: $entity_id})-[:HAS_LABEL]-()
                    RETURN count(*) as label_rel_count
                """
                label_rels_result = self.conn.execute(
                    label_rels_query, {"entity_id": entity_id}
                )
                label_rel_count = 0
                with managed_result(label_rels_result):
                    if label_rels_result.has_next():  # type: ignore
                        label_rel_count = label_rels_result.get_next()[0]  # type: ignore

                # NOTE: We intentionally do NOT check BELONGS_TO (community) relationships:
                # 1. Currently BELONGS_TO edges are not used - community membership is stored
                #    as a community_id property on Entity nodes instead
                # 2. Even if BELONGS_TO edges existed, they would be auto-generated by
                #    community detection and regenerated when the algorithm runs again
                # 3. An entity's value comes from its MENTIONS connections to memories,
                #    not from community membership which is derived/computed

                logger.debug(
                    "Entity relationship counts",
                    entity_id=entity_id,
                    entity_name=entity_name,
                    other_mentions=other_mentions_count,
                    external_entity_rels=external_entity_rel_count,
                    label_rels=label_rel_count,
                )

                # Entity is orphaned if it has NO external relationships
                # (relationships not created from this memory)
                # BELONGS_TO (community) relationships are NOT counted - they're auto-generated
                is_orphaned: bool = cast(bool, (
                    other_mentions_count == 0
                    and external_entity_rel_count == 0
                    and label_rel_count == 0
                ))

                if is_orphaned:
                    orphaned_entities.append(entity_id)  # type: ignore[arg-type]
                    logger.debug(
                        "Entity will be orphaned",
                        entity_id=entity_id,
                        entity_name=entity_name,
                    )
                else:
                    logger.debug(
                        "Entity has external connections, will not be orphaned",
                        entity_id=entity_id,
                        entity_name=entity_name,
                    )

            logger.info(
                "Found orphaned entities after memory deletion",
                memory_id=memory_id,
                count=len(orphaned_entities),
                orphaned_entities=orphaned_entities,
            )
            return orphaned_entities

        except Exception as e:
            logger.error(
                "Failed to find orphaned entities", memory_id=memory_id, error=str(e)
            )
            return []

    async def delete_orphaned_entities(self, entity_ids: List[str]) -> int:
        """Delete orphaned entities and their relationships with enhanced safety checks.

        Args:
            entity_ids: List of entity IDs to delete

        Returns:
            Number of entities deleted
        """
        self.client._ensure_initialized()  # type: ignore[attr-defined]

        if not self.conn:
            raise RuntimeError("Database connection not available")

        if not entity_ids:
            return 0

        # Safety limit: Don't delete more than 50 entities at once
        if len(entity_ids) > 50:
            logger.warning(
                "Batch deletion request too large, limiting to 50 entities",
                requested=len(entity_ids),
                limit=50,
            )
            entity_ids = entity_ids[:50]

        try:
            deleted_count = 0
            skipped_count = 0

            for entity_id in entity_ids:
                # Enhanced safety check: verify entity is truly orphaned
                enhanced_check_query = """
                    MATCH (e:Entity {id: $entity_id})
                    OPTIONAL MATCH (e)-[r1]-()
                    OPTIONAL MATCH ()-[r2]->(e)
                    WITH e, (count(DISTINCT r1) + count(DISTINCT r2)) as total_relationships
                    RETURN e.name as entity_name,
                           e.entity_type as entity_type,
                           e.created_at as created_at,
                           total_relationships
                """

                result = self.conn.execute(
                    enhanced_check_query, {"entity_id": entity_id}
                )
                with managed_result(result):
                    if result.has_next():  # type: ignore
                        row = result.get_next()  # type: ignore
                        entity_name = row[0]  # type: ignore
                        entity_type = row[1]  # type: ignore
                        created_at = row[2]  # type: ignore
                        rel_count = row[3]  # type: ignore

                        # Safety check 1: Entity must have zero relationships
                        if rel_count > 0:
                            logger.warning(
                                "Entity not orphaned, skipping deletion",
                                entity_id=entity_id,
                                entity_name=entity_name,
                                rel_count=rel_count,
                            )
                            skipped_count += 1
                            continue

                        # Don't skip entities based on age - just delete if orphaned
                        # The ONLY safety check is: entity must have zero relationships (checked above)

                        # Entity is truly orphaned and safe to delete
                        try:
                            # Use DETACH DELETE for safety - handles any attached relationships
                            # This is required if relationships exist (e.g., stale HAS_LABEL that
                            # wasn't cleaned up, or future BELONGS_TO edges if implemented)
                            delete_query = """
                                MATCH (e:Entity {id: $entity_id})
                                DETACH DELETE e
                            """
                            self.conn.execute(delete_query, {"entity_id": entity_id})
                            deleted_count += 1
                            logger.debug(
                                "Deleted orphaned entity",
                                entity_id=entity_id,
                                entity_name=entity_name,
                                entity_type=entity_type,
                            )
                        except Exception as delete_error:
                            logger.error(
                                "Failed to delete orphaned entity",
                                entity_id=entity_id,
                                entity_name=entity_name,
                                error=str(delete_error),
                            )
                            skipped_count += 1
                    else:
                        logger.warning(
                            "Entity not found during deletion check", entity_id=entity_id
                        )
                        skipped_count += 1

            logger.info(
                "Orphaned entity cleanup completed",
                deleted=deleted_count,
                skipped=skipped_count,
                total_processed=len(entity_ids),
            )

            # NOTE: Checkpoint is handled at the operation level (memory_operations.py)
            return deleted_count

        except Exception as e:
            logger.error(
                "Failed to delete orphaned entities",
                entity_ids=entity_ids,
                error=str(e),
            )
            return 0
