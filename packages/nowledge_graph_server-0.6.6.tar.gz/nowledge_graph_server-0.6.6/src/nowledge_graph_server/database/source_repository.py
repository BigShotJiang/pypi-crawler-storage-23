"""
Source Repository

All source-related database operations including CRUD, lifecycle state
transitions, and revision tracking.
"""

from typing import List, Optional, Dict, Any, cast
import datetime
import json

import structlog
import real_ladybug as kuzu

from nowledge_graph_server.models.graph import SourceNode
from nowledge_graph_server.database.base_client import KuzuBaseClient
from nowledge_graph_server.database.result_utils import iter_rows, managed_result

logger = structlog.get_logger(__name__)


class SourceRepository:
    """Repository for source-related database operations."""

    # Whitelist of fields allowed in update_lifecycle_state(**extra_fields).
    # Prevents field injection via dynamic SET clause construction.
    ALLOWED_UPDATE_FIELDS = frozenset({
        "chunk_count", "memory_count", "section_tree", "summary",
        "parsed_path",
    })
    ALLOWED_SOURCE_FIELDS = frozenset({
        "original_name", "mime_type", "file_path", "source_url",
        "sha256", "size_bytes", "metadata",
    })

    def __init__(self, client: KuzuBaseClient):
        self.client: KuzuBaseClient = client

    @property
    def conn(self) -> kuzu.Connection | None:
        return cast(kuzu.Connection | None, self.client.conn)  # type: ignore[attr-defined]

    def _ensure_ready(self) -> kuzu.Connection:
        self.client._ensure_initialized()  # type: ignore[attr-defined]
        if not self.conn:
            raise RuntimeError("Database connection not available")
        return self.conn

    def _row_to_source(self, row: Dict[str, Any]) -> SourceNode:
        """Convert a Kuzu row dict to SourceNode."""
        return SourceNode(
            id=row["id"],
            source_type=row.get("source_type", "file"),
            original_name=row.get("original_name", ""),
            mime_type=row.get("mime_type"),
            file_path=row.get("file_path"),
            parsed_path=row.get("parsed_path"),
            source_url=row.get("source_url"),
            sha256=row.get("sha256"),
            size_bytes=row.get("size_bytes", 0),
            version=row.get("version", 1),
            lifecycle_state=row.get("lifecycle_state", "ingested"),
            chunk_count=row.get("chunk_count", 0),
            memory_count=row.get("memory_count", 0),
            section_tree=row.get("section_tree"),
            summary=row.get("summary"),
            error_message=row.get("error_message"),
            created_at=self.client._safe_parse_datetime(row.get("created_at"))  # type: ignore
            or datetime.datetime.now(datetime.timezone.utc),
            updated_at=self.client._safe_parse_datetime(row.get("updated_at"))  # type: ignore
            or datetime.datetime.now(datetime.timezone.utc),
            metadata=self.client._deserialize_metadata(row.get("metadata", "{}"))  # type: ignore
            if row.get("metadata")
            else {},
        )

    async def create_source(self, source: SourceNode) -> SourceNode:
        """Create a new source node."""
        conn = self._ensure_ready()
        now = datetime.datetime.now(datetime.timezone.utc)

        query = """
            CREATE (s:Source {
                id: $id,
                source_type: $source_type,
                original_name: $original_name,
                mime_type: $mime_type,
                file_path: $file_path,
                parsed_path: $parsed_path,
                source_url: $source_url,
                sha256: $sha256,
                size_bytes: $size_bytes,
                version: $version,
                lifecycle_state: $lifecycle_state,
                chunk_count: $chunk_count,
                memory_count: $memory_count,
                section_tree: $section_tree,
                summary: $summary,
                error_message: $error_message,
                created_at: $created_at,
                updated_at: $updated_at,
                metadata: $metadata
            })
            RETURN s
        """

        conn.execute(
            query,
            {
                "id": source.id,
                "source_type": source.source_type,
                "original_name": source.original_name,
                "mime_type": source.mime_type or "",
                "file_path": source.file_path or "",
                "parsed_path": source.parsed_path or "",
                "source_url": source.source_url or "",
                "sha256": source.sha256 or "",
                "size_bytes": source.size_bytes,
                "version": source.version,
                "lifecycle_state": source.lifecycle_state,
                "chunk_count": source.chunk_count,
                "memory_count": source.memory_count,
                "section_tree": source.section_tree or "",
                "summary": source.summary or "",
                "error_message": source.error_message or "",
                "created_at": now,
                "updated_at": now,
                "metadata": json.dumps(source.metadata) if source.metadata else "{}",
            },
        )

        logger.info("Created source", source_id=source.id, name=source.original_name)
        return source

    async def get_source(self, source_id: str) -> Optional[SourceNode]:
        """Get a source by ID."""
        conn = self._ensure_ready()

        result = conn.execute(
            "MATCH (s:Source {id: $id}) RETURN s",
            {"id": source_id},
        )
        assert isinstance(result, kuzu.QueryResult)

        with managed_result(result):
            if result.has_next():
                row = result.get_next()[0]
                return self._row_to_source(row)
        return None

    async def get_source_by_sha256(self, sha256: str) -> Optional[SourceNode]:
        """Find a source by content hash (dedup check)."""
        conn = self._ensure_ready()

        result = conn.execute(
            "MATCH (s:Source {sha256: $sha256}) RETURN s ORDER BY s.version DESC LIMIT 1",
            {"sha256": sha256},
        )
        assert isinstance(result, kuzu.QueryResult)

        with managed_result(result):
            if result.has_next():
                row = result.get_next()[0]
                return self._row_to_source(row)
        return None

    async def find_by_name(self, original_name: str) -> List[SourceNode]:
        """Find sources by original name (for revision detection)."""
        conn = self._ensure_ready()

        result = conn.execute(
            "MATCH (s:Source) WHERE s.original_name = $name RETURN s ORDER BY s.version DESC",
            {"name": original_name},
        )
        assert isinstance(result, kuzu.QueryResult)

        sources = []
        for row in iter_rows(result):
            row = row[0]
            sources.append(self._row_to_source(row))
        return sources

    async def update_lifecycle_state(
        self,
        source_id: str,
        state: str,
        error_message: Optional[str] = None,
        **extra_fields: Any,
    ) -> bool:
        """Update the lifecycle state of a source."""
        conn = self._ensure_ready()
        now = datetime.datetime.now(datetime.timezone.utc)

        set_clauses = ["s.lifecycle_state = $state", "s.updated_at = $updated_at"]
        params: Dict[str, Any] = {
            "id": source_id,
            "state": state,
            "updated_at": now,
        }

        if error_message is not None:
            set_clauses.append("s.error_message = $error_message")
            params["error_message"] = error_message

        for field, value in extra_fields.items():
            if field not in self.ALLOWED_UPDATE_FIELDS:
                raise ValueError(
                    f"Cannot update field '{field}'. "
                    f"Allowed: {', '.join(sorted(self.ALLOWED_UPDATE_FIELDS))}"
                )
            set_clauses.append(f"s.{field} = ${field}")
            params[field] = value

        query = f"""
            MATCH (s:Source {{id: $id}})
            SET {', '.join(set_clauses)}
        """
        conn.execute(query, params)
        logger.debug("Updated source lifecycle", source_id=source_id, state=state)
        return True

    async def update_source_fields(self, source_id: str, **fields: Any) -> bool:
        """Update core source fields with a strict whitelist."""
        conn = self._ensure_ready()
        now = datetime.datetime.now(datetime.timezone.utc)

        if not fields:
            return True

        set_clauses = ["s.updated_at = $updated_at"]
        params: Dict[str, Any] = {
            "id": source_id,
            "updated_at": now,
        }

        for field, value in fields.items():
            if field not in self.ALLOWED_SOURCE_FIELDS:
                raise ValueError(
                    f"Cannot update field '{field}'. "
                    f"Allowed: {', '.join(sorted(self.ALLOWED_SOURCE_FIELDS))}"
                )
            set_clauses.append(f"s.{field} = ${field}")
            if field == "metadata":
                params[field] = json.dumps(value) if value is not None else "{}"
            else:
                params[field] = value

        query = f"""
            MATCH (s:Source {{id: $id}})
            SET {', '.join(set_clauses)}
        """
        conn.execute(query, params)
        logger.debug("Updated source fields", source_id=source_id, fields=list(fields.keys()))
        return True

    async def list_sources(
        self,
        source_type: Optional[str] = None,
        lifecycle_state: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[SourceNode]:
        """List sources with optional filtering."""
        conn = self._ensure_ready()

        conditions = []
        params: Dict[str, Any] = {"limit": limit, "offset": offset}

        if source_type:
            conditions.append("s.source_type = $source_type")
            params["source_type"] = source_type
        if lifecycle_state:
            conditions.append("s.lifecycle_state = $lifecycle_state")
            params["lifecycle_state"] = lifecycle_state

        where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""

        query = f"""
            MATCH (s:Source)
            {where_clause}
            RETURN s
            ORDER BY s.created_at DESC
            SKIP $offset LIMIT $limit
        """

        result = conn.execute(query, params)
        assert isinstance(result, kuzu.QueryResult)

        sources = []
        for row in iter_rows(result):
            row = row[0]
            sources.append(self._row_to_source(row))
        return sources

    async def count_sources(
        self,
        source_type: Optional[str] = None,
        lifecycle_state: Optional[str] = None,
    ) -> int:
        """Count sources with optional filtering."""
        conn = self._ensure_ready()

        conditions = []
        params: Dict[str, Any] = {}

        if source_type:
            conditions.append("s.source_type = $source_type")
            params["source_type"] = source_type
        if lifecycle_state:
            conditions.append("s.lifecycle_state = $lifecycle_state")
            params["lifecycle_state"] = lifecycle_state

        where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""

        query = f"MATCH (s:Source) {where_clause} RETURN COUNT(s) as cnt"
        result = conn.execute(query, params)
        assert isinstance(result, kuzu.QueryResult)

        with managed_result(result):
            if result.has_next():
                return result.get_next()[0]
        return 0

    async def delete_source(self, source_id: str) -> bool:
        """Delete a source and its relationships."""
        conn = self._ensure_ready()

        try:
            # Delete relationships first
            conn.execute(
                "MATCH (m:Memory)-[r:SOURCED_FROM]->(s:Source {id: $id}) DELETE r",
                {"id": source_id},
            )
            conn.execute(
                "MATCH (s1:Source)-[r:REVISED_AS]->(s2:Source) "
                "WHERE s1.id = $id OR s2.id = $id DELETE r",
                {"id": source_id},
            )
            # Delete the node
            conn.execute(
                "MATCH (s:Source {id: $id}) DELETE s",
                {"id": source_id},
            )
            logger.info("Deleted source", source_id=source_id)
            return True
        except Exception as e:
            logger.error("Failed to delete source", source_id=source_id, error=str(e))
            return False

    async def create_sourced_from(
        self,
        memory_id: str,
        source_id: str,
        chunk_index: Optional[int] = None,
        chunk_range: Optional[str] = None,
        source_version: int = 1,
    ) -> bool:
        """Create SOURCED_FROM relationship between Memory and Source."""
        conn = self._ensure_ready()
        now = datetime.datetime.now(datetime.timezone.utc)

        query = """
            MATCH (m:Memory {id: $memory_id}), (s:Source {id: $source_id})
            CREATE (m)-[:SOURCED_FROM {
                chunk_index: $chunk_index,
                chunk_range: $chunk_range,
                source_version: $source_version,
                created_at: $created_at
            }]->(s)
        """
        try:
            conn.execute(
                query,
                {
                    "memory_id": memory_id,
                    "source_id": source_id,
                    "chunk_index": chunk_index or 0,
                    "chunk_range": chunk_range or "",
                    "source_version": source_version,
                    "created_at": now,
                },
            )

            # Increment memory_count on the Source node
            conn.execute(
                "MATCH (s:Source {id: $id}) SET s.memory_count = s.memory_count + 1",
                {"id": source_id},
            )

            return True
        except Exception as e:
            logger.error(
                "Failed to create SOURCED_FROM",
                memory_id=memory_id,
                source_id=source_id,
                error=str(e),
            )
            return False

    async def create_revised_as(
        self,
        newer_source_id: str,
        older_source_id: str,
        diff_summary: Optional[str] = None,
        sections_changed: Optional[List[str]] = None,
        revision_type: Optional[str] = None,
        detected_by: str = "system",
    ) -> bool:
        """Create REVISED_AS relationship (newer → older)."""
        conn = self._ensure_ready()
        now = datetime.datetime.now(datetime.timezone.utc)

        query = """
            MATCH (newer:Source {id: $newer_id}), (older:Source {id: $older_id})
            CREATE (newer)-[:REVISED_AS {
                diff_summary: $diff_summary,
                sections_changed: $sections_changed,
                revision_type: $revision_type,
                detected_by: $detected_by,
                created_at: $created_at
            }]->(older)
        """
        try:
            conn.execute(
                query,
                {
                    "newer_id": newer_source_id,
                    "older_id": older_source_id,
                    "diff_summary": diff_summary or "",
                    "sections_changed": json.dumps(sections_changed) if sections_changed else "[]",
                    "revision_type": revision_type or "update",
                    "detected_by": detected_by,
                    "created_at": now,
                },
            )
            logger.info(
                "Created REVISED_AS",
                newer=newer_source_id,
                older=older_source_id,
            )
            return True
        except Exception as e:
            logger.error(
                "Failed to create REVISED_AS",
                newer=newer_source_id,
                older=older_source_id,
                error=str(e),
            )
            return False

    async def get_source_memories(
        self, source_id: str, limit: int = 50
    ) -> List[Dict[str, Any]]:
        """Get memories extracted from a source."""
        conn = self._ensure_ready()

        query = """
            MATCH (m:Memory)-[r:SOURCED_FROM]->(s:Source {id: $source_id})
            RETURN m.id as memory_id, m.title as title, m.content as content,
                   r.chunk_index as chunk_index, r.chunk_range as chunk_range,
                   m.unit_type as unit_type, m.confidence as confidence
            ORDER BY r.chunk_index ASC
            LIMIT $limit
        """
        result = conn.execute(query, {"source_id": source_id, "limit": limit})
        assert isinstance(result, kuzu.QueryResult)

        memories = []
        for row in iter_rows(result):
            memories.append({
                "memory_id": row[0],
                "title": row[1],
                "content": row[2],
                "chunk_index": row[3],
                "chunk_range": row[4],
                "unit_type": row[5] or "fact",
                "confidence": row[6] if row[6] is not None else 0.5,
            })
        return memories

    async def get_revision_chain(
        self, source_id: str, max_depth: int = 10
    ) -> List[Dict[str, Any]]:
        """Get the version chain for a source (newer → older)."""
        conn = self._ensure_ready()

        depth = min(max(max_depth, 1), 20)
        query = f"""
            MATCH p = (s:Source {{id: $source_id}})-[:REVISED_AS*1..{depth}]->(older:Source)
            RETURN older.id as id, older.original_name as name,
                   older.version as version, older.sha256 as sha256,
                   older.created_at as created_at
            ORDER BY older.version DESC
        """
        result = conn.execute(query, {"source_id": source_id})
        assert isinstance(result, kuzu.QueryResult)

        chain = []
        for row in iter_rows(result):
            chain.append({
                "id": row[0],
                "name": row[1],
                "version": row[2],
                "sha256": row[3],
                "created_at": row[4],
            })
        return chain
