import json
import datetime
import html
from typing import List, Dict, Any, Optional
from nowledge_graph_server.models.graph import MemoryNode

def export_memory_json(
    memory: MemoryNode, labels: List[Dict[str, Any]], source_thread: Optional[Dict[str, Any]], related_entities: List[Dict[str, Any]], include_metadata: bool = True
) -> str:
    """Export memory as JSON."""
    export_data: Dict[str, Any] = {
        "memory_id": memory.id,
        "content": memory.content,
        "title": memory.title,
        "importance": memory.importance,
        "confidence": memory.confidence,
        "created_at": memory.created_at.isoformat() if memory.created_at else None,
        "updated_at": memory.updated_at.isoformat() if memory.updated_at else None,
        "export_info": {
            "exported_at": datetime.datetime.now().isoformat(),
            "format": "json",
            "version": "1.0",
        },
    }

    if include_metadata:
        export_data["metadata"] = {
            "labels": labels,
            "source_thread": source_thread,
            "related_entities": related_entities,
            "additional_metadata": memory.metadata,
        }

    return json.dumps(export_data, indent=2, ensure_ascii=False)


def export_memory_markdown(
    memory: MemoryNode, labels: List[Dict[str, Any]], source_thread: Optional[Dict[str, Any]], related_entities: List[Dict[str, Any]], include_metadata: bool = True
) -> str:
    """Export memory as Markdown in Cursor-style format."""
    lines: List[str] = []
    # Title and export info (Cursor-style header)
    title = ""
    if memory.title is not None:
        title = memory.title[:50] + "..." if len(memory.title) > 50 else memory.title
    else:
        title = "(No title)"
    lines.append(f"# Memory: {title}")
    lines.append(
        f"_Exported on {datetime.datetime.now().strftime('%m/%d/%Y at %H:%M:%S GMT%z')} from nowledge-mem_"
    )
    lines.append("")
    lines.append("---")
    lines.append("")

    # Main content section
    lines.append("**Memory Content**")
    lines.append("")
    lines.append(memory.content)
    lines.append("")

    # Related entities if available
    if include_metadata and related_entities:
        lines.append("---")
        lines.append("")
        lines.append("**Related Entities**")
        lines.append("")
        for entity in related_entities:
            lines.append(
                f"- **{entity['name']}** ({entity['type']}) - Confidence: {entity['confidence']:.2f}"
            )
        lines.append("")

    # Metadata section at the end
    if include_metadata:
        lines.append("---")
        lines.append("")
        lines.append("**Memory Metadata**")
        lines.append("")
        lines.append(
            f"- Created: {memory.created_at.strftime('%Y-%m-%d %H:%M:%S') if memory.created_at else 'Unknown'}"
        )
        lines.append(
            f"- Updated: {memory.updated_at.strftime('%Y-%m-%d %H:%M:%S') if memory.updated_at else 'Unknown'}"
        )
        lines.append(f"- Importance: {memory.importance:.2f}")
        lines.append(f"- Confidence: {memory.confidence:.2f}")

        if labels:
            label_names = [
                label.get("name", str(label)) if isinstance(label, dict) else str(label) # type: ignore[arg-type]
                for label in labels
            ]
            lines.append(f"- Labels: {', '.join(label_names)}")

        if source_thread:
            lines.append(
                f"- Source Thread: {source_thread['title']} ({source_thread['source']})"
            )

        lines.append(f"- Memory ID: {memory.id}")

    return "\n".join(lines)


def export_memory_html(
    memory: MemoryNode, labels: List[Dict[str, Any]], source_thread: Optional[Dict[str, Any]], related_entities: List[Dict[str, Any]], include_metadata: bool = True
) -> str:
    """Export memory as HTML."""
    title = ""
    if memory.title is not None:
        title = html.escape(memory.title[:50] + "..." if len(memory.title) > 50 else memory.title)
    else:
        title = "(No title)"

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            line-height: 1.6;
            color: #333;
        }}
        .header {{
            border-bottom: 2px solid #e0e0e0;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }}
        .metadata {{
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 30px;
        }}
        .metadata h3 {{
            margin-top: 0;
            color: #495057;
        }}
        .metadata ul {{
            list-style: none;
            padding: 0;
        }}
        .metadata li {{
            padding: 5px 0;
            border-bottom: 1px solid #e9ecef;
        }}
        .metadata li:last-child {{
            border-bottom: none;
        }}
        .content {{
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e0e0e0;
            margin-bottom: 30px;
        }}
        .entities {{
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 30px;
        }}
        .entity {{
            background: #e3f2fd;
            padding: 8px 12px;
            border-radius: 4px;
            margin: 5px 0;
            border-left: 4px solid #2196f3;
        }}
        .footer {{
            border-top: 2px solid #e0e0e0;
            padding-top: 20px;
            margin-top: 30px;
            font-size: 0.9em;
            color: #666;
        }}
        .label {{
            background: #007bff;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8em;
            margin-right: 5px;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>{title}</h1>
    </div>
"""

    # Add metadata section
    if include_metadata:
        html_content += """
    <div class="metadata">
        <h3>Memory Information</h3>
        <ul>
"""
        html_content += f"            <li><strong>Created:</strong> {memory.created_at.strftime('%Y-%m-%d %H:%M:%S') if memory.created_at else 'Unknown'}</li>"
        html_content += f"            <li><strong>Updated:</strong> {memory.updated_at.strftime('%Y-%m-%d %H:%M:%S') if memory.updated_at else 'Unknown'}</li>"
        html_content += (
            f"            <li><strong>Importance:</strong> {memory.importance:.2f}</li>"
        )
        html_content += (
            f"            <li><strong>Confidence:</strong> {memory.confidence:.2f}</li>"
        )

        if labels:
            label_names = [
                label.get("name", str(label)) if isinstance(label, dict) else str(label) # type: ignore[arg-type]
                for label in labels
            ]
            labels_html = " ".join(
                [
                    f'<span class="label">{html.escape(label_name)}</span>'
                    for label_name in label_names
                ]
            )
            html_content += (
                f"            <li><strong>Labels:</strong> {labels_html}</li>"
            )

        if source_thread:
            html_content += f"            <li><strong>Source Thread:</strong> {html.escape(source_thread['title'])} ({html.escape(source_thread['source'])})</li>"

        html_content += """
        </ul>
    </div>
"""

    # Add content
    html_content += f"""
    <div class="content">
        <h3>Content</h3>
        <p>{html.escape(memory.content)}</p>
    </div>
"""

    # Add related entities
    if include_metadata and related_entities:
        html_content += """
    <div class="entities">
        <h3>Related Entities</h3>
"""
        for entity in related_entities:
            html_content += f"""
        <div class="entity">
            <strong>{html.escape(entity["name"])}</strong> ({html.escape(entity["type"])}) - Confidence: {entity["confidence"]:.2f}
        </div>
"""
        html_content += "    </div>"

    # Add footer
    html_content += f"""
    <div class="footer">
        <p><strong>Export Information:</strong></p>
        <ul>
            <li><strong>Exported:</strong> {datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</li>
            <li><strong>Format:</strong> HTML</li>
            <li><strong>Memory ID:</strong> {html.escape(memory.id)}</li>
        </ul>
    </div>
</body>
</html>
"""

    return html_content
