#!/usr/bin/env python3
"""
Debug tools for investigating database state and orphaned entities.
This module provides utilities for debugging the knowledge graph database.
"""

import asyncio
from typing import List, Dict, Any, Optional
from nowledge_graph_server.database.kuzu_client import KuzuClient
import structlog

logger = structlog.get_logger(__name__)


class DebugTools:
    """Debug tools for investigating database state."""

    def __init__(self, kuzu_client: KuzuClient):
        self.client = kuzu_client

    async def find_all_orphaned_entities(self) -> List[Dict[str, Any]]:
        """Find all entities that appear to be orphaned (no relationships)."""
        try:
            # Find all entities with no relationships
            query = """
                MATCH (e:Entity)
                WHERE NOT (e)-[:MENTIONS]-(m:Memory)
                  AND NOT (e)-[:RELATES_TO]-()
                  AND NOT (e)-[:HAS_LABEL]-()
                  AND NOT (e)-[:BELONGS_TO]-()
                RETURN e.id as entity_id, e.name as entity_name, e.entity_type as entity_type
            """
            assert self.client.conn is not None, "Kuzu client connection is None"

            result = self.client.conn.execute(query)
            orphaned_entities = []

            while result.has_next():  # type: ignore
                row = result.get_next()  # type: ignore
                orphaned_entities.append(
                    {
                        "entity_id": row[0],  # type: ignore
                        "entity_name": row[1],  # type: ignore
                        "entity_type": row[2],  # type: ignore
                    }
                )

            logger.info("Found orphaned entities", count=len(orphaned_entities))
            return orphaned_entities

        except Exception as e:
            logger.error("Failed to find orphaned entities", error=str(e))
            return []

    async def debug_entity_relationships(self, entity_id: str) -> Dict[str, Any]:
        """Debug a specific entity to see what relationships it has."""
        return await self.client.debug_entity_relationships(entity_id)  # type: ignore[attr-defined]

    async def clean_orphaned_entities(self, confirm: bool = False) -> int:
        """Clean up orphaned entities that have no relationships."""
        try:
            orphaned_entities = await self.find_all_orphaned_entities()

            if not orphaned_entities:
                logger.info("No orphaned entities found")
                return 0

            if not confirm:
                logger.warning(
                    "Dry run mode - would delete entities", count=len(orphaned_entities)
                )
                return 0

            # Delete orphaned entities
            entity_ids = [entity["entity_id"] for entity in orphaned_entities]
            deleted_count = await self.client.delete_orphaned_entities(entity_ids)  # type: ignore[attr-defined]

            logger.info("Deleted orphaned entities", count=deleted_count)
            return deleted_count

        except Exception as e:
            logger.error("Failed to clean orphaned entities", error=str(e))
            return 0

    async def get_database_stats(self) -> Dict[str, Any]:
        """Get comprehensive database statistics."""
        try:
            stats = await self.client.get_graph_stats()  # type: ignore[attr-defined]

            # Add orphaned entities count
            orphaned_entities = await self.find_all_orphaned_entities()
            stats["orphaned_entities_count"] = len(orphaned_entities)

            return stats

        except Exception as e:
            logger.error("Failed to get database stats", error=str(e))
            return {}

    async def find_threads_with_stale_distillation_state(self) -> List[Dict[str, Any]]:
        """Find threads marked as distilled but with no remaining memories."""
        try:
            query = """
                MATCH (t:Thread)
                WHERE t.metadata CONTAINS '"distilled":true'
                WITH t
                OPTIONAL MATCH (t)-[:COMPACTS_TO]->(m:Memory)
                WITH t, count(m) as memory_count
                WHERE memory_count = 0
                RETURN t.thread_id as thread_id, t.title as title, t.metadata as metadata
            """

            assert self.client.conn is not None, "Kuzu client connection is None"

            result = self.client.conn.execute(query)
            stale_threads = []

            while result.has_next():  # type: ignore
                row = result.get_next()  # type: ignore
                stale_threads.append(
                    {
                        "thread_id": row[0],  # type: ignore
                        "title": row[1],  # type: ignore
                        "metadata": row[2],  # type: ignore
                    }
                )

            logger.info(
                "Found threads with stale distillation state", count=len(stale_threads)
            )
            return stale_threads

        except Exception as e:
            logger.error("Failed to find stale distillation threads", error=str(e))
            return []

    async def clear_stale_distillation_states(self, confirm: bool = False) -> int:
        """Clear distillation state from threads that have no memories."""
        try:
            stale_threads = await self.find_threads_with_stale_distillation_state()

            if not stale_threads:
                logger.info("No threads with stale distillation state found")
                return 0

            if not confirm:
                logger.warning(
                    "Dry run mode - would clear distillation state",
                    count=len(stale_threads),
                )
                return 0

            import json

            cleared_count = 0

            for thread in stale_threads:
                try:
                    metadata = (
                        json.loads(thread["metadata"]) if thread["metadata"] else {}
                    )

                    # Remove distillation-related fields
                    metadata.pop("distilled", None)
                    metadata.pop("distillation_type", None)
                    metadata.pop("distilled_at", None)
                    metadata.pop("memory_count", None)

                    # Update thread metadata
                    update_query = """
                        MATCH (t:Thread {thread_id: $thread_id})
                        SET t.metadata = $metadata
                    """

                    assert self.client.conn is not None, (
                        "Kuzu client connection is None"
                    )

                    self.client.conn.execute(
                        update_query,
                        {
                            "thread_id": thread["thread_id"],
                            "metadata": json.dumps(metadata),
                        },
                    )

                    cleared_count += 1
                    logger.info(
                        "Cleared distillation state", thread_id=thread["thread_id"]
                    )

                except Exception as thread_error:
                    logger.error(
                        "Failed to clear distillation state for thread",
                        thread_id=thread["thread_id"],
                        error=str(thread_error),
                    )

            logger.info("Cleared stale distillation states", count=cleared_count)
            return cleared_count

        except Exception as e:
            logger.error("Failed to clear stale distillation states", error=str(e))
            return 0
