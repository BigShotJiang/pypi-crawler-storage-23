"""
Offline MLX Model Loader
Override MLX-LM's load() function to bypass HuggingFace Hub API calls for cached models.

This addresses the issue described in: https://github.com/ml-explore/mlx-lm/issues/109
When models are cached locally, we should load them directly without internet calls.
"""

import os
import warnings
from pathlib import Path
from typing import Tuple, Optional, Any

import structlog
from .model_cache import HuggingFaceMirrorManager

logger = structlog.get_logger(__name__)


def load_offline_mlx_model(
    path_or_hf_repo: str,
    tokenizer_config: Optional[dict] = None,
    adapter_path: Optional[str] = None,
    lazy: bool = True,
    **kwargs,
) -> Tuple[Any, Any]:
    """
    Load MLX model in offline mode, bypassing HuggingFace Hub API calls.

    This function first checks if the model exists in the local cache.
    If found, it loads directly from the cache path to avoid network calls.

    Args:
        path_or_hf_repo: Model name or path
        tokenizer_config: Tokenizer configuration
        adapter_path: Optional adapter path
        lazy: Whether to use lazy loading
        **kwargs: Additional arguments passed to mlx_lm.load

    Returns:
        Tuple of (model, tokenizer)
    """

    # First, try to resolve to a local cache path
    local_model_path = _find_cached_model_path(path_or_hf_repo)

    if local_model_path and local_model_path.exists():
        # Get the actual snapshot path containing model files
        snapshot_path = _get_model_snapshot_path(local_model_path)

        if snapshot_path:
            logger.info(
                "Loading MLX model from local cache (offline)",
                model=path_or_hf_repo,
                cache_path=str(local_model_path),
                snapshot_path=str(snapshot_path),
            )

            # Force offline mode to prevent any network calls
            original_hf_hub_offline = os.environ.get("HF_HUB_OFFLINE")
            original_transformers_offline = os.environ.get("TRANSFORMERS_OFFLINE")

            try:
                # Set strict offline mode
                os.environ["HF_HUB_OFFLINE"] = "1"
                os.environ["TRANSFORMERS_OFFLINE"] = "1"
                os.environ["DISABLE_TELEMETRY"] = "1"

                logger.debug(
                    "Loading MLX model with offline environment",
                    snapshot_path=str(snapshot_path),
                    hf_hub_offline=os.environ.get("HF_HUB_OFFLINE"),
                    transformers_offline=os.environ.get("TRANSFORMERS_OFFLINE"),
                )

                # Import here to avoid issues during module initialization (only on macOS)
                import platform
                if platform.system() != "Darwin" or platform.machine() != "arm64":
                    raise RuntimeError("MLX loading is only available on macOS Apple Silicon")
                
                from mlx_lm.utils import load as mlx_load

                # Load from the snapshot path (not the model root)
                # Try different approaches to work around the kwargs issue
                logger.debug(
                    "About to call mlx_load",
                    kwargs_type=type(kwargs).__name__,
                    kwargs_value=kwargs,
                    tokenizer_config_type=type(tokenizer_config).__name__
                    if tokenizer_config is not None
                    else "None",
                )

                # Try multiple loading strategies to work around the issue
                try:
                    # Strategy 1: Pass minimal arguments to avoid kwargs issue
                    result = mlx_load(str(snapshot_path), lazy=lazy)
                    model, tokenizer = result[0], result[1]
                    logger.debug("Strategy 1 (minimal args) succeeded")
                except Exception as e1:
                    logger.debug("Strategy 1 failed", error=str(e1))
                    try:
                        # Strategy 2: Pass arguments one by one
                        if tokenizer_config is not None:
                            result = mlx_load(
                                str(snapshot_path),
                                tokenizer_config=tokenizer_config,
                                lazy=lazy,
                            )
                        else:
                            result = mlx_load(str(snapshot_path), lazy=lazy)
                        model, tokenizer = result[0], result[1]
                        logger.debug("Strategy 2 (explicit args) succeeded")
                    except Exception as e2:
                        logger.debug("Strategy 2 failed", error=str(e2))
                        # Strategy 3: Use original approach with safe kwargs
                        load_kwargs = kwargs if kwargs is not None else {}
                        result = mlx_load(
                            str(snapshot_path),
                            tokenizer_config=tokenizer_config,
                            adapter_path=adapter_path,
                            lazy=lazy,
                            **load_kwargs,
                        )
                        model, tokenizer = result[0], result[1]
                        logger.debug("Strategy 3 (safe kwargs) succeeded")

                logger.info(
                    "Successfully loaded MLX model from cache",
                    model=path_or_hf_repo,
                    cache_path=str(local_model_path),
                )

                return model, tokenizer

            except Exception as e:
                logger.error(
                    "Failed to load MLX model from cache",
                    model=path_or_hf_repo,
                    snapshot_path=str(snapshot_path),
                    error=str(e),
                    error_type=type(e).__name__,
                )
                raise  # Re-raise so the fallback mechanism works

            finally:
                # Restore original environment
                if original_hf_hub_offline is not None:
                    os.environ["HF_HUB_OFFLINE"] = original_hf_hub_offline
                else:
                    os.environ.pop("HF_HUB_OFFLINE", None)

                if original_transformers_offline is not None:
                    os.environ["TRANSFORMERS_OFFLINE"] = original_transformers_offline
                else:
                    os.environ.pop("TRANSFORMERS_OFFLINE", None)
        else:
            logger.warning(
                "Model cache found but no valid snapshot directory",
                model=path_or_hf_repo,
                cache_path=str(local_model_path),
            )

    # If not cached locally, fall back to standard MLX loading
    # (which may trigger downloads)
    logger.warning(
        "Model not found in cache, falling back to standard loading",
        model=path_or_hf_repo,
        searched_path=str(local_model_path) if local_model_path else "None",
    )

    # Import MLX load function (only on macOS)
    import platform
    if platform.system() != "Darwin" or platform.machine() != "arm64":
        raise RuntimeError("MLX loading is only available on macOS Apple Silicon")
    
    from mlx_lm.utils import load as mlx_load

    # Ensure kwargs is a dictionary to avoid TypeError
    load_kwargs = kwargs if kwargs is not None else {}
    result = mlx_load(
        path_or_hf_repo,
        tokenizer_config=tokenizer_config,
        adapter_path=adapter_path,
        lazy=lazy,
        **load_kwargs,
    )
    return result[0], result[1]


def _find_cached_model_path(model_name: str) -> Optional[Path]:
    """
    Find the local cache path for a HuggingFace model.

    Args:
        model_name: HuggingFace model name (e.g., "mlx-community/Qwen3-4B-Instruct-2507-DDWQ")

    Returns:
        Path to cached model directory, or None if not found
    """

    # Convert model name to cache directory format
    cache_model_name = f"models--{model_name.replace('/', '--')}"

    # Check possible cache locations in order of preference
    cache_locations = []

    def _is_china_region() -> bool:
        # Reuse existing mirror/region detection logic
        try:
            return HuggingFaceMirrorManager.detect_region() == "china"
        except Exception:
            return False

    # Prepare ModelScope and HF locations
    modelscope_path: Optional[Path] = None
    org_name: Optional[str] = None
    model_name_part: Optional[str] = None
    try:
        org_name, model_name_part = model_name.split("/", 1)
        modelscope_path = (
            Path.home() / ".cache" / "modelscope" / "hub" / "models" / org_name / model_name_part
        )
    except Exception:
        modelscope_path = None

    hf_locations: list[Path] = []
    modelscope_in_hf_locations: list[Path] = []
    hf_root_candidates: list[Path] = []
    # Environment-provided HF caches
    hf_home = os.environ.get("HF_HOME")
    if hf_home:
        hf_locations.append(Path(hf_home) / "hub" / cache_model_name)
        hf_locations.append(Path(hf_home) / cache_model_name)  # root level (snapshot_download saves here)
        hf_root_candidates.append(Path(hf_home))
    hf_cache = os.environ.get("HUGGINGFACE_HUB_CACHE")
    if hf_cache:
        hf_cache_path = Path(hf_cache)
        hf_locations.append(hf_cache_path / cache_model_name)
        hf_root_candidates.append(
            hf_cache_path.parent if hf_cache_path.name == "hub" else hf_cache_path
        )
    # Legacy app cache
    app_hf_root = (
        Path.home()
        / ".cache"
        / "nowledge-graph"
        / "llm"
        / "huggingface"
    )
    hf_locations.append(app_hf_root / "hub" / cache_model_name)
    hf_locations.append(app_hf_root / cache_model_name)  # root level (snapshot_download saves here)
    hf_root_candidates.append(app_hf_root)
    # Default HF cache
    default_hf_root = Path.home() / ".cache" / "huggingface"
    hf_locations.append(default_hf_root / "hub" / cache_model_name)
    hf_locations.append(default_hf_root / cache_model_name)  # root level (snapshot_download saves here)
    hf_root_candidates.append(default_hf_root)

    # ModelScope-format models saved under HF roots (org/model)
    if org_name and model_name_part:
        for hf_root in hf_root_candidates:
            modelscope_in_hf_locations.append(hf_root / org_name / model_name_part)

    # Order by region: China -> ModelScope first, otherwise HF first
    if _is_china_region():
        if modelscope_path is not None:
            cache_locations.append(modelscope_path)
        cache_locations.extend(modelscope_in_hf_locations)
        cache_locations.extend(hf_locations)
    else:
        cache_locations.extend(hf_locations)
        cache_locations.extend(modelscope_in_hf_locations)
        if modelscope_path is not None:
            cache_locations.append(modelscope_path)

    # Find the first existing cache directory
    for cache_path in cache_locations:
        if cache_path.exists() and cache_path.is_dir():
            # Verify it has model files
            if _validate_model_cache(cache_path):
                logger.debug(
                    "Found cached model", model=model_name, cache_path=str(cache_path)
                )
                return cache_path
            else:
                logger.debug(
                    "Invalid model cache (missing files)",
                    model=model_name,
                    cache_path=str(cache_path),
                )

    logger.debug(
        "Model not found in any cache location",
        model=model_name,
        searched_locations=[str(p) for p in cache_locations],
    )
    return None


def _validate_model_cache(cache_path: Path) -> bool:
    """
    Validate that a cached model directory contains required files.

    Args:
        cache_path: Path to cached model directory

    Returns:
        True if valid model cache, False otherwise
    """

    # Support both HF cache layout (snapshots/<hash>) and ModelScope layout (model root)
    snapshots_dir = cache_path / "snapshots"
    candidate_dirs = []
    if snapshots_dir.exists():
        candidate_dirs = [d for d in snapshots_dir.iterdir() if d.is_dir()]
    else:
        # Treat cache_path itself as candidate (ModelScope or manually placed model dir)
        candidate_dirs = [cache_path]

    for snapshot_dir in candidate_dirs:
        # Required config (more flexible - config.json or model_config.json)
        has_config = (snapshot_dir / "config.json").exists() or (
            snapshot_dir / "model_config.json"
        ).exists()

        # Look for weights: multiple formats supported
        has_single = (snapshot_dir / "model.safetensors").exists()
        has_sharded = any(
            p.name.startswith("model-") and p.suffix == ".safetensors"
            for p in snapshot_dir.iterdir()
        )
        has_mlx = any(p.suffix == ".mlx" for p in snapshot_dir.iterdir())
        has_pytorch = (snapshot_dir / "pytorch_model.bin").exists() or any(
            p.name.startswith("pytorch_model") for p in snapshot_dir.iterdir()
        )
        has_weights = has_single or has_sharded or has_mlx or has_pytorch

        # For MLX models, also check for tokenizer files
        has_tokenizer = (snapshot_dir / "tokenizer.json").exists() or (
            snapshot_dir / "tokenizer_config.json"
        ).exists()

        logger.debug(
            "Model cache validation",
            snapshot_dir=str(snapshot_dir),
            has_config=has_config,
            has_single=has_single,
            has_sharded=has_sharded,
            has_mlx=has_mlx,
            has_pytorch=has_pytorch,
            has_tokenizer=has_tokenizer,
            files=[p.name for p in snapshot_dir.iterdir() if p.is_file()][:10],
        )  # Show first 10 files

        # More lenient validation: config + (weights OR tokenizer for some models)
        if has_config and (has_weights or has_tokenizer):
            logger.info(
                "Valid model cache found",
                snapshot_dir=str(snapshot_dir),
                weight_type="mlx"
                if has_mlx
                else "safetensors"
                if (has_single or has_sharded)
                else "pytorch"
                if has_pytorch
                else "tokenizer_only",
            )
            return True

    logger.warning(
        "No valid model cache found",
        cache_path=str(cache_path),
        candidate_dirs=[str(d) for d in candidate_dirs],
    )
    return False


def _get_model_snapshot_path(cache_path: Path) -> Optional[Path]:
    """
    Get the actual snapshot path containing model files.

    Args:
        cache_path: Path to cached model directory

    Returns:
        Path to snapshot directory with model files, or None if not found
    """
    snapshots_dir = cache_path / "snapshots"

    # Prefer HF snapshots when present and valid
    if snapshots_dir.exists():
        snapshot_dirs = [d for d in snapshots_dir.iterdir() if d.is_dir()]
        # Choose the first snapshot that actually contains weights
        for snapshot_dir in snapshot_dirs:
            has_config = (snapshot_dir / "config.json").exists()
            has_weights = any(
                p.name == "model.safetensors"
                or (p.name.startswith("model-") and p.suffix == ".safetensors")
                or p.suffix == ".mlx"
                for p in snapshot_dir.iterdir()
            )
            if has_config and has_weights:
                return snapshot_dir
        # If no snapshot has weights, fall through to try root

    # Otherwise, treat cache_path itself as model root (ModelScope or manual)
    if (cache_path / "config.json").exists():
        return cache_path

    return None


def patch_mlx_loading_for_offline_use():
    """
    Monkey patch MLX-LM loading to use our offline loader.

    This is a temporary solution until the upstream MLX-LM project
    implements proper offline loading support.
    
    NOTE: Only works on macOS Apple Silicon.
    """
    import platform
    if platform.system() != "Darwin" or platform.machine() != "arm64":
        logger.debug("Skipping MLX patch (not macOS Apple Silicon)")
        return

    try:
        import mlx_lm.utils

        # Store the original load function
        if not hasattr(mlx_lm.utils, "_original_load"):
            setattr(mlx_lm.utils, "_original_load", mlx_lm.utils.load)

        # Replace with our offline-aware version
        mlx_lm.utils.load = load_offline_mlx_model  # type: ignore

        logger.info("Successfully patched MLX-LM for offline loading")

    except ImportError:
        logger.warning("MLX-LM not available, skipping offline patch")
    except Exception as e:
        logger.error("Failed to patch MLX-LM for offline loading", error=str(e))


def unpatch_mlx_loading():
    """Restore original MLX-LM loading behavior.
    
    NOTE: Only works on macOS Apple Silicon.
    """
    import platform
    if platform.system() != "Darwin" or platform.machine() != "arm64":
        return  # Nothing to unpatch on non-macOS

    try:
        import mlx_lm.utils

        if hasattr(mlx_lm.utils, "_original_load"):
            original_load = getattr(mlx_lm.utils, "_original_load")
            mlx_lm.utils.load = original_load  # type: ignore
            delattr(mlx_lm.utils, "_original_load")
            logger.info("Restored original MLX-LM loading behavior")

    except Exception as e:
        logger.error("Failed to unpatch MLX-LM loading", error=str(e))
