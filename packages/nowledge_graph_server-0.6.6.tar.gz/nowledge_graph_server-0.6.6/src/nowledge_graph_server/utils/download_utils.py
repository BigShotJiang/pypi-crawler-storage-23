"""Download utilities for HuggingFace and ModelScope models."""

import asyncio
import os
import platform
from functools import partial
from pathlib import Path
from typing import Optional, List

import structlog

from .mirror_manager import get_best_mirror
from .progress_logger import log_stage
from .progress_tqdm import make_progress_tqdm, make_modelscope_callback, ModelScopeProgressCallback, ProgressTqdm

logger = structlog.get_logger(__name__)


async def download_hf_snapshot(
    model_name: str,
    cache_dir: str,
    operation: str,
    allow_patterns: Optional[List[str]] = None,
) -> Optional[str]:
    """Download model via HuggingFace snapshot_download with progress tracking."""
    # Save and temporarily enable online access
    orig_offline = os.environ.get("HF_HUB_OFFLINE")
    os.environ["HF_HUB_OFFLINE"] = "0"
    os.environ["TRANSFORMERS_OFFLINE"] = "0"

    if "HF_HUB_DISABLE_XET" not in os.environ:
        os.environ["HF_HUB_DISABLE_XET"] = "1"

    try:
        from huggingface_hub import snapshot_download
        import huggingface_hub.constants
        # CRITICAL: Override the cached constant since it's set at import time
        # If huggingface_hub was already imported elsewhere with HF_HUB_OFFLINE=1,
        # setting the env var alone won't help - we must override the constant
        huggingface_hub.constants.HF_HUB_OFFLINE = False

        # Set mirror if needed
        mirror = get_best_mirror()
        if mirror != "https://huggingface.co":
            os.environ["HF_ENDPOINT"] = mirror

        log_stage(operation=operation, stage="initializing", message=f"Downloading {model_name}")

        # Reset progress counters for new download
        ProgressTqdm.reset()
        tqdm_class = make_progress_tqdm(operation)
        kwargs = {"repo_id": model_name, "cache_dir": cache_dir, "tqdm_class": tqdm_class}
        if allow_patterns:
            kwargs["allow_patterns"] = allow_patterns
        # Windows requires admin privileges for symlinks
        if platform.system() == "Windows":
            kwargs["local_dir_use_symlinks"] = False

        loop = asyncio.get_event_loop()
        path = await loop.run_in_executor(None, partial(snapshot_download, **kwargs))

        log_stage(operation=operation, stage="completed", message="Download completed")
        return path

    except Exception as e:
        logger.error("HuggingFace download failed", model=model_name, error=str(e))
        return None
    finally:
        # Restore offline setting
        if orig_offline is not None:
            os.environ["HF_HUB_OFFLINE"] = orig_offline
        else:
            os.environ.pop("HF_HUB_OFFLINE", None)


async def download_modelscope_snapshot(
    model_name: str,
    cache_dir: str,
    operation: str,
) -> Optional[str]:
    """Download model via ModelScope snapshot_download with progress tracking."""
    try:
        from modelscope.hub.snapshot_download import snapshot_download

        log_stage(operation=operation, stage="initializing", message=f"Downloading {model_name}")

        ModelScopeProgressCallback.reset()
        callback = make_modelscope_callback(operation)

        loop = asyncio.get_event_loop()
        download_fn = partial(snapshot_download, model_name, cache_dir=cache_dir, progress_callbacks=[callback])
        path = await loop.run_in_executor(None, download_fn)

        log_stage(operation=operation, stage="completed", message="Download completed")
        return path

    except ImportError:
        logger.warning("ModelScope not installed")
        return None
    except Exception as e:
        logger.error("ModelScope download failed", model=model_name, error=str(e))
        return None


async def download_modelscope_files(
    model_name: str,
    cache_dir: str,
    files: List[str],
) -> List[str]:
    """Download specific files from ModelScope."""
    try:
        from modelscope.hub.file_download import model_file_download
    except ImportError:
        logger.error("ModelScope not installed")
        return []

    downloaded = []
    loop = asyncio.get_event_loop()

    for file_path in files:
        try:
            download_fn = partial(
                model_file_download,
                model_id=model_name,
                file_path=file_path,
                cache_dir=cache_dir,
            )
            local_path = await loop.run_in_executor(None, download_fn)
            downloaded.append(local_path)
            logger.debug("Downloaded file", file=file_path)
        except Exception as e:
            logger.warning("Failed to download file", file=file_path, error=str(e))

    return downloaded


def resolve_hf_cache_path(model_name: str, cache_dir: Path) -> Optional[Path]:
    """Resolve HuggingFace cache path for a model (models--org--name/snapshots/hash/)."""
    cache_name = model_name.replace("/", "--")
    model_dir = cache_dir / f"models--{cache_name}"

    if not model_dir.exists():
        return None

    snapshots_dir = model_dir / "snapshots"
    if not snapshots_dir.exists():
        return None

    # Find first valid snapshot
    for snapshot in snapshots_dir.iterdir():
        if snapshot.is_dir() and (snapshot / "config.json").exists():
            return snapshot

    return None


def resolve_modelscope_cache_path(model_name: str, cache_dir: Optional[Path] = None) -> Optional[Path]:
    """Resolve ModelScope cache path for a model.

    Args:
        model_name: Model name in 'org/name' format
        cache_dir: Optional custom cache directory to check. If None, checks default ModelScope cache.

    Returns:
        Path to model directory if found, None otherwise.
    """
    if "/" not in model_name:
        return None

    org, name = model_name.split("/", 1)

    # Check custom cache directory first (ModelScope format: org/name)
    if cache_dir is not None:
        custom_path = cache_dir / org / name
        path_exists = custom_path.exists()
        config_exists = (custom_path / "config.json").exists() if path_exists else False
        logger.debug("resolve_modelscope_cache_path: checking custom path", path=str(custom_path), exists=path_exists, config_exists=config_exists)
        if path_exists and config_exists:
            return custom_path

    # Check default ModelScope cache
    default_path = Path.home() / ".cache" / "modelscope" / "hub" / "models" / org / name
    path_exists = default_path.exists()
    config_exists = (default_path / "config.json").exists() if path_exists else False
    logger.debug("resolve_modelscope_cache_path: checking default path", path=str(default_path), exists=path_exists, config_exists=config_exists)
    if path_exists and config_exists:
        return default_path

    return None


def detect_model_type(model_name: str) -> str:
    """Detect if model is 'embedding' or 'llm' based on name patterns."""
    name_lower = model_name.lower()

    embedding_patterns = ["embedding", "bge-", "sentence"]
    if any(p in name_lower for p in embedding_patterns):
        return "embedding"

    return "llm"
