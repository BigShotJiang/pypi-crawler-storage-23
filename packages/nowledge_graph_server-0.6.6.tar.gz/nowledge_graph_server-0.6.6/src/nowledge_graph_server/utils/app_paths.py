"""Cross-platform app storage path helpers.

Storage policy:
- App config/state files: app config dir / co.nowledge.mem.desktop
- Graph database/index data: platform data dir / NowledgeGraph

The config helper includes legacy fallbacks for older builds that stored config
under app data dir / co.nowledge.mem.desktop.
"""

from __future__ import annotations

import os
import platform
import shutil
from pathlib import Path
from typing import Iterable, Optional

_REAL_HOME = Path.home()
_APP_STATE_DIRNAME = "co.nowledge.mem.desktop"
_GRAPH_DATA_DIRNAME = "NowledgeGraph"


def get_real_home() -> Path:
    """Return the real user home captured at import time."""
    return _REAL_HOME


def get_app_config_dir() -> Path:
    """Return canonical app config/state directory."""
    sys_name = platform.system()
    if sys_name == "Windows":
        base = Path(os.environ.get("APPDATA", str(_REAL_HOME / "AppData" / "Roaming")))
    elif sys_name == "Darwin":
        base = _REAL_HOME / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", str(_REAL_HOME / ".config")))
    return base / _APP_STATE_DIRNAME


def get_legacy_app_data_dir() -> Path:
    """Return legacy app data dir used by older desktop builds for config files."""
    sys_name = platform.system()
    if sys_name == "Windows":
        base = Path(os.environ.get("APPDATA", str(_REAL_HOME / "AppData" / "Roaming")))
    elif sys_name == "Darwin":
        base = _REAL_HOME / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", str(_REAL_HOME / ".local" / "share")))
    return base / _APP_STATE_DIRNAME


def get_nowledge_graph_data_dir() -> Path:
    """Return canonical graph data dir for database/index files."""
    sys_name = platform.system()
    if sys_name == "Windows":
        base = Path(os.environ.get("LOCALAPPDATA", str(_REAL_HOME / "AppData" / "Local")))
    elif sys_name == "Darwin":
        base = _REAL_HOME / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", str(_REAL_HOME / ".local" / "share")))
    return base / _GRAPH_DATA_DIRNAME


def _candidate_legacy_paths(relative_name: str, extra_legacy_paths: Optional[Iterable[Path]] = None) -> list[Path]:
    candidates: list[Path] = []

    legacy_data = get_legacy_app_data_dir() / relative_name
    canonical = get_app_config_dir() / relative_name
    if legacy_data != canonical:
        candidates.append(legacy_data)

    if extra_legacy_paths:
        for p in extra_legacy_paths:
            if p and p != canonical:
                candidates.append(p)

    return candidates


def migrate_legacy_config_file(
    relative_name: str, extra_legacy_paths: Optional[Iterable[Path]] = None
) -> Path:
    """Copy a legacy config file into canonical app config dir when needed.

    Returns canonical path when migration succeeds or no migration is needed.
    Returns original legacy path if migration failed but legacy file exists.
    """
    target = get_app_config_dir() / relative_name
    if target.exists():
        return target

    for legacy_path in _candidate_legacy_paths(relative_name, extra_legacy_paths):
        if not legacy_path.exists():
            continue

        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(legacy_path, target)
            return target
        except Exception:
            return legacy_path

    return target


def resolve_config_file_path(
    relative_name: str, extra_legacy_paths: Optional[Iterable[Path]] = None
) -> Path:
    """Resolve config file path with migration and legacy fallback.

    Returns canonical path when available (or migration succeeded), otherwise
    returns a readable legacy file path when one exists.
    """
    resolved = migrate_legacy_config_file(relative_name, extra_legacy_paths)
    if resolved.exists():
        return resolved

    for legacy_path in _candidate_legacy_paths(relative_name, extra_legacy_paths):
        if legacy_path.exists():
            return legacy_path

    return get_app_config_dir() / relative_name


def resolve_config_subdir_path(
    relative_name: str, extra_legacy_paths: Optional[Iterable[Path]] = None
) -> Path:
    """Resolve subdirectory path with migration and legacy fallback.

    For runtime/state directories (e.g. kimi_home, builtin_agents), we prefer
    the canonical app-config root and attempt a best-effort move from legacy
    app-data root. If migration fails, we keep using the legacy path.
    """
    target = get_app_config_dir() / relative_name
    if target.exists():
        return target

    for legacy_path in _candidate_legacy_paths(relative_name, extra_legacy_paths):
        if not legacy_path.exists():
            continue

        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(legacy_path), str(target))
            return target
        except Exception:
            return legacy_path

    return target
