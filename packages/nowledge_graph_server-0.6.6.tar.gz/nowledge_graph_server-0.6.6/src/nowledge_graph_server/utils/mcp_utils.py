import re


def unescape_unicode_sequences(text: str) -> str:
    """Unescape Unicode sequences like \\u2014 to actual Unicode characters."""
    if not text:
        return text
    # Fix Unicode escapes: \u2014 (em dash), \u2013 (en dash), etc.
    return re.sub(r"\\u([0-9a-fA-F]{4})", lambda m: chr(int(m.group(1), 16)), text)


def get_app_source_from_headers(headers: dict) -> str:
    """Get the app source from the headers."""
    app_source = headers.get("app") or headers.get("APP") or "mcp_generic"
    app_source = app_source.lower().strip().replace(" ", "_")
    return app_source
