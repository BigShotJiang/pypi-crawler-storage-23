"""Shared time-partitioned file path utilities.

Used across agent tools, API routers, and feed event persistence.
File structure: base_dir/YYYY/MM/YYYY-MM-DD.{extension}
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import List


def get_time_partitioned_path(
    base_dir: Path, date: datetime, extension: str, *, ensure_parents: bool = True
) -> Path:
    """Get time-partitioned file path: YYYY/MM/YYYY-MM-DD.{extension}

    Args:
        base_dir: Root directory for partitioned files.
        date: Date to partition by.
        extension: File extension (without dot).
        ensure_parents: Create parent directories if they don't exist.
    """
    year = date.strftime("%Y")
    month = date.strftime("%m")
    filename = f"{date.strftime('%Y-%m-%d')}.{extension}"
    path = base_dir / year / month / filename
    if ensure_parents:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def iter_time_partitioned_files(
    base_dir: Path, extension: str, *, last_n_days: int = 90
) -> List[Path]:
    """List time-partitioned files, newest first.

    Scans year/month directories and returns files within the look-back window.

    Args:
        base_dir: Root directory containing YYYY/MM/ structure.
        extension: File extension to match (without dot).
        last_n_days: Only include files from the last N days.
    """
    cutoff = datetime.now(timezone.utc) - timedelta(days=last_n_days)

    files: List[Path] = []
    if not base_dir.exists():
        return files

    for year_dir in sorted(base_dir.iterdir(), reverse=True):
        if not year_dir.is_dir() or not year_dir.name.isdigit():
            continue
        for month_dir in sorted(year_dir.iterdir(), reverse=True):
            if not month_dir.is_dir() or not month_dir.name.isdigit():
                continue
            for f in sorted(month_dir.glob(f"*.{extension}"), reverse=True):
                try:
                    file_date = datetime.strptime(f.stem, "%Y-%m-%d").replace(
                        tzinfo=timezone.utc
                    )
                    if file_date >= cutoff:
                        files.append(f)
                except ValueError:
                    continue

    return files


# Backward-compatible aliases (underscore-prefixed names used throughout codebase)
_get_time_partitioned_path = get_time_partitioned_path
_iter_time_partitioned_files = iter_time_partitioned_files
