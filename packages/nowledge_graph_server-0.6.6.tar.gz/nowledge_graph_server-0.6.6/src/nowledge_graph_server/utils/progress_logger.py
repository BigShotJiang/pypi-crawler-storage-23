#!/usr/bin/env python3
"""
Progress logging utility for real-time progress tracking.

Writes progress events to a dedicated log file that Tauri can monitor.
This enables real progress tracking instead of fake progress bars.
"""

import json
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime
import threading
from nowledge_graph_server.utils.app_paths import get_nowledge_graph_data_dir


class ProgressLogger:
    """Singleton progress logger that writes to a dedicated file."""

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if hasattr(self, '_initialized') and self._initialized:
            return

        try:
            # Canonical location shared with Rust watcher:
            # {NowledgeGraph data dir}/Logs/progress.log
            self.log_dir = get_nowledge_graph_data_dir() / "Logs"

            # Create directory if it doesn't exist
            self.log_dir.mkdir(parents=True, exist_ok=True)

            # Progress log file path
            self.log_file = self.log_dir / "progress.log"

            # Clear old logs on startup and create fresh file
            if self.log_file.exists():
                self.log_file.unlink()

            # Create empty file immediately so watchers can start
            self.log_file.touch()

            self._file_lock = threading.Lock()
            self._initialized = True

            print(f"📊 Progress logger initialized: {self.log_file}")
            print(f"📊 Progress log file exists: {self.log_file.exists()}")
        except Exception as e:
            print(f"❌ Failed to initialize progress logger: {e}")
            import traceback
            traceback.print_exc()
            # Set a fallback
            self.log_dir = Path("/tmp")
            self.log_file = self.log_dir / "progress.log"
            self.log_file.touch()
            self._file_lock = threading.Lock()
            self._initialized = True

    def log_progress(
        self,
        operation: str,
        percentage: float,
        message: str,
        details: Optional[Dict[str, Any]] = None
    ):
        """Log a progress update.

        Args:
            operation: Operation type (e.g., "model_download", "community_detection")
            percentage: Progress percentage (0-100)
            message: Human-readable message
            details: Additional details (downloaded bytes, speed, etc.)
        """
        event = {
            "type": "progress",
            "operation": operation,
            "percentage": round(percentage, 2),
            "message": message,
            "timestamp": datetime.utcnow().isoformat(),
        }

        if details:
            event["details"] = details

        # Write to file (thread-safe)
        with self._file_lock:
            try:
                with open(self.log_file, "a", encoding="utf-8") as f:
                    f.write(json.dumps(event) + "\n")
                    f.flush()  # Ensure immediate write
            except Exception as e:
                # Don't let progress logging break the main operation
                print(f"⚠️ Failed to write progress log: {e}")

    def log_stage(
        self,
        operation: str,
        stage: str,
        message: str,
        details: Optional[Dict[str, Any]] = None
    ):
        """Log a stage change (e.g., initializing -> downloading -> extracting).

        Args:
            operation: Operation type
            stage: Stage name (e.g., "initializing", "downloading", "completed")
            message: Human-readable message
            details: Additional details
        """
        event: Dict[str, Any] = {
            "type": "stage",
            "operation": operation,
            "stage": stage,
            "message": message,
            "timestamp": datetime.utcnow().isoformat(),
        }

        if details:
            event["details"] = details

        # Write to file (thread-safe)
        with self._file_lock:
            try:
                with open(self.log_file, "a", encoding="utf-8") as f:
                    f.write(json.dumps(event) + "\n")
                    f.flush()
            except Exception as e:
                print(f"⚠️ Failed to write stage log: {e}")

    def log_data_change(
        self,
        change_type: str,  # "memory_created", "memory_updated", "memory_deleted", "thread_created", "label_created", etc.
        entity_type: str,  # "memory", "thread", "label"
        entity_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        """Log a data change event (for UI refresh notifications).
        
        This is used to notify the UI when data changes via MCP, CLI, or other external sources.
        The Rust layer will emit Tauri events that the frontend can listen to.

        Args:
            change_type: Type of change (e.g., "memory_created", "label_assigned_to_memory")
            entity_type: Type of entity (e.g., "memory", "thread", "label")
            entity_id: ID of the entity that changed (optional)
            details: Additional details about the change
        """
        event: Dict[str, Any] = {
            "type": "data-change",
            "change_type": change_type,
            "entity_type": entity_type,
            "timestamp": datetime.utcnow().isoformat(),
        }
        
        if entity_id:
            event["entity_id"] = entity_id
            
        if details:
            event["details"] = details

        # Write to file (thread-safe)
        with self._file_lock:
            try:
                with open(self.log_file, "a", encoding="utf-8") as f:
                    f.write(json.dumps(event) + "\n")
                    f.flush()  # Ensure immediate write
            except Exception as e:
                print(f"⚠️ Failed to write data change log: {e}")

    def get_log_path(self) -> str:
        """Get the path to the progress log file."""
        return str(self.log_file)


# Global instance
_progress_logger = ProgressLogger()


def log_progress(
    operation: str,
    percentage: float,
    message: str,
    details: Optional[Dict[str, Any]] = None
):
    """Log a progress update (convenience function)."""
    _progress_logger.log_progress(operation, percentage, message, details)


def log_stage(
    operation: str,
    stage: str,
    message: str,
    details: Optional[Dict[str, Any]] = None
):
    """Log a stage change (convenience function)."""
    _progress_logger.log_stage(operation, stage, message, details)


def log_data_change(
    change_type: str,
    entity_type: str,
    entity_id: Optional[str] = None,
    details: Optional[Dict[str, Any]] = None
):
    """Log a data change event (convenience function).
    
    Examples:
        log_data_change("memory_created", "memory", memory_id)
        log_data_change("label_assigned_to_memory", "memory", memory_id, {"label_id": label_id})
        log_data_change("thread_created", "thread", thread_id)
    """
    _progress_logger.log_data_change(change_type, entity_type, entity_id, details)


def get_progress_log_path() -> str:
    """Get the path to the progress log file."""
    return _progress_logger.get_log_path()
