"""
LLM Availability Utility

Checks if LLM is available on the current platform and provides helpful error messages.
"""
import platform
from typing import Tuple
import structlog

from nowledge_graph_server.services.remote_llm_config import get_config_manager
from nowledge_graph_server.services.license import get_license_service

logger = structlog.get_logger(__name__)

# MLX is only available on macOS Apple Silicon
IS_APPLE_SILICON = platform.system() == "Darwin" and platform.machine() == "arm64"


def check_llm_availability() -> Tuple[bool, str]:
    """Check if LLM is available on the current platform.
    
    Returns:
        Tuple of (is_available, error_message)
        - is_available: True if LLM is available (MLX on Apple Silicon or Remote LLM configured)
        - error_message: Empty string if available, otherwise helpful error message
    """
    # On Apple Silicon, MLX is always available (even if not initialized)
    if IS_APPLE_SILICON:
        logger.debug("LLM available: Apple Silicon detected")
        return True, ""
    
    # On non-Apple-Silicon platforms, check if remote LLM is configured and enabled
    try:
        config_manager = get_config_manager()
        license_service = get_license_service()
        
        license_tier = license_service.get_tier()
        is_device_activated = license_service.is_device_activated()
        activation_status = license_service.get_activation_status()
        config_enabled = config_manager.is_enabled()
        config = config_manager.get_config()
        # Check if actually configured (has model and provider)
        is_configured = config_enabled and bool(config.model and config.model.strip() and config.provider and config.provider.strip())
        
        logger.debug(
            "LLM availability check",
            platform=platform.system(),
            license_tier=license_tier,
            is_device_activated=is_device_activated,
            activation_status=activation_status,
            config_enabled=config_enabled,
            has_model=bool(config.model and config.model.strip()),
            has_provider=bool(config.provider and config.provider.strip()),
            is_configured=is_configured
        )
        
        # Check 1: License tier (what user paid for)
        if license_tier != "pro":
            error_msg = (
                "LLM features require Pro tier. "
                "Please upgrade to Pro in Settings > Plans."
            )
            logger.warn("LLM not available: No Pro license", tier=license_tier)
            return False, error_msg
        
        # Check 2: Device activation status
        if not is_device_activated:
            if activation_status == "expired":
                error_msg = (
                    "Your device authorization has expired. "
                    "Please connect to the internet and restart the app to re-activate, "
                    "or go to Settings > Plans to refresh your license."
                )
                logger.warn("LLM not available: Device authorization expired")
            else:
                error_msg = (
                    "This device is not activated. "
                    "Please go to Settings > Plans to activate your Pro license on this device."
                )
                logger.warn("LLM not available: Device not activated", status=activation_status)
            return False, error_msg
        
        # Check 3: Remote LLM configuration
        if not is_configured:
            if not config_enabled:
                error_msg = (
                    "LLM features require Remote LLM configuration. "
                    "Please enable and configure Remote LLM in Settings > Remote LLM. "
                    "On Intel Mac/Windows/Linux, Remote LLM is required for LLM-powered features."
                )
            elif not (config.model and config.model.strip()):
                error_msg = (
                    "LLM features require Remote LLM model selection. "
                    "Please select a model in Settings > Remote LLM."
                )
            else:
                error_msg = (
                    "LLM features require Remote LLM configuration. "
                    "Please configure Remote LLM in Settings > Remote LLM. "
                    "On Intel Mac/Windows/Linux, Remote LLM is required for LLM-powered features."
                )
            logger.warn("LLM not available: Remote LLM not properly configured", 
                       enabled=config_enabled, 
                       has_model=bool(config.model and config.model.strip()))
            return False, error_msg
        
        # All checks passed
        logger.info("LLM available: Pro license, device activated, and Remote LLM configured")
        return True, ""
        
    except Exception as e:
        error_msg = (
            f"Failed to check LLM availability: {str(e)}. "
            "Please configure Remote LLM in Settings > Remote LLM."
        )
        logger.error("LLM availability check failed", error=str(e), exc_info=True)
        return False, error_msg
