"""Shared utility for emitting feed events to JSONL + progress.log.

Consolidates the duplicated _get_time_partitioned_path() + JSONL write + log_data_change()
pattern that was copied across insight.py, flag.py, knowledge_tools.py, agent.py, etc.
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog

from nowledge_graph_server.agent.paths import get_builtin_agents_home
from nowledge_graph_server.utils.progress_logger import log_data_change
from nowledge_graph_server.utils.time_partitioning import (
    get_time_partitioned_path as _get_time_partitioned_path,
    iter_time_partitioned_files as _iter_time_partitioned_files,  # noqa: F401
)

logger = structlog.get_logger(__name__)


def get_events_dir() -> Path:
    """Get the events directory (static path, no lifecycle dependency)."""
    return get_builtin_agents_home() / "events"


def get_reports_dir() -> Path:
    """Get the reports directory (static path, no lifecycle dependency)."""
    return get_builtin_agents_home() / "reports"


def emit_feed_event(
    event_type: str,
    title: str,
    description: str = "",
    severity: str = "info",
    related_memory_ids: Optional[List[str]] = None,
    metadata: Optional[Dict[str, Any]] = None,
    *,
    event_id: Optional[str] = None,
    write_report: bool = False,
) -> str:
    """Write a feed event to JSONL + notify UI via progress.log.

    Args:
        event_type: Event type (e.g. "memory_created", "insight_generated", "flag_contradiction")
        title: Short, human-readable title
        description: Detailed description
        severity: "info", "warning", or "action_required"
        related_memory_ids: IDs of memories related to this event
        metadata: Additional event-specific data (dict, not JSON string)
        event_id: Optional custom event ID (auto-generated if not provided)
        write_report: Also append to the daily markdown report

    Returns:
        The event_id.
    """
    now = datetime.now(timezone.utc)
    if event_id is None:
        event_id = f"evt-{uuid.uuid4().hex[:12]}"

    event = {
        "id": event_id,
        "event_type": event_type,
        "severity": severity,
        "title": title,
        "description": description,
        "metadata": metadata or {},
        "related_memory_ids": related_memory_ids or [],
        "resolved": False,
        "created_at": now.isoformat(),
    }

    try:
        events_dir = get_events_dir()
        event_path = _get_time_partitioned_path(events_dir, now, "jsonl")
        with open(event_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(event) + "\n")

        log_data_change(
            "feed_event_created", "feed", event_id,
            {"event_type": event_type, "severity": severity},
        )

        if write_report:
            reports_dir = get_reports_dir()
            report_path = _get_time_partitioned_path(reports_dir, now, "md")
            severity_badge = f" [{severity.upper()}]" if severity != "info" else ""
            with open(report_path, "a", encoding="utf-8") as f:
                f.write(f"\n### [{now.strftime('%H:%M')}] {event_type}{severity_badge}: {title}\n")
                f.write(f"{description}\n")
                if related_memory_ids:
                    f.write(f"Related: {', '.join(related_memory_ids)}\n")

        logger.info(
            "Feed event emitted",
            event_id=event_id,
            event_type=event_type,
            severity=severity,
        )

    except Exception as e:
        logger.error("Failed to emit feed event", error=str(e), event_type=event_type)

    return event_id
