"""Logging configuration for Nowledge Graph MCP Server."""

import logging
import sys
import io
import os
from typing import Any, Dict

import structlog


def setup_logging(log_level: str = "INFO", debug: bool = False) -> None:
    """Setup structured logging for the application.

    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        debug: Whether to enable debug mode with detailed output
    """
    
    # On Windows, configure stdout/stderr to use UTF-8 encoding to handle emojis
    if sys.platform == "win32":
        # Reconfigure stdout and stderr to use UTF-8
        if hasattr(sys.stdout, 'reconfigure'):
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')  # type: ignore[attr-defined]
        if hasattr(sys.stderr, 'reconfigure'):
            sys.stderr.reconfigure(encoding='utf-8', errors='replace')  # type: ignore[attr-defined]
        # Also set environment variable for child processes
        os.environ['PYTHONIOENCODING'] = 'utf-8'

    # Configure standard library logging
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=getattr(logging, log_level.upper()),
    )

    # Configure processors for structured logs
    processors = [
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.contextvars.merge_contextvars,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]

    if debug:
        # In debug mode, use colorful console output
        processors.append(structlog.dev.ConsoleRenderer(colors=True))
    else:
        # In production, use JSON output
        processors.append(structlog.processors.JSONRenderer())

    # Configure structlog
    structlog.configure(
        processors=processors,
        wrapper_class=structlog.stdlib.BoundLogger,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )


def get_logger(name: str) -> Any:
    """Get a structured logger instance.

    Args:
        name: Logger name (usually __name__)

    Returns:
        Structured logger instance
    """
    return structlog.get_logger(name)


def log_context(**kwargs: Any) -> Dict[str, Any]:
    """Create logging context dictionary.

    Args:
        **kwargs: Context key-value pairs

    Returns:
        Context dictionary for structured logging
    """
    return kwargs
