"""HuggingFace/ModelScope mirror management for region-based downloads."""

import os
import time
import urllib.request
import structlog

logger = structlog.get_logger(__name__)

MIRRORS = {
    "default": "https://huggingface.co",
    "china": "https://hf-mirror.com",
    "modelscope": "https://modelscope.cn",
}


def detect_region() -> str:
    """Detect region based on timezone. Returns 'china' or 'default'."""
    try:
        # China is UTC+8, timezone offset is -28800 seconds
        if time.timezone == -28800:
            return "china"
    except Exception:
        pass
    return "default"


def test_mirror(url: str, timeout: int = 5) -> bool:
    """Test if a mirror URL is accessible."""
    try:
        req = urllib.request.Request(url, method="HEAD")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status == 200
    except Exception:
        return False


def get_best_mirror() -> str:
    """Get the best available mirror based on region and connectivity."""
    region = detect_region()
    test_order = ["china", "modelscope", "default"] if region == "china" else ["default", "china"]

    for key in test_order:
        url = MIRRORS[key]
        if test_mirror(url):
            logger.info("Selected mirror", mirror=key, url=url)
            return url

    logger.warning("All mirrors failed, using default")
    return MIRRORS["default"]


def setup_hf_environment(cache_dir: str) -> str:
    """Setup HuggingFace environment variables. Returns selected mirror."""
    from pathlib import Path

    mirror = get_best_mirror()

    if "hf-mirror.com" in mirror:
        os.environ["HF_ENDPOINT"] = mirror
    elif "modelscope.cn" in mirror:
        os.environ["MODELSCOPE_CACHE"] = cache_dir

    # HF_HOME should be the parent of the hub directory (e.g., ~/.cache/huggingface)
    # NOT the hub directory itself (e.g., ~/.cache/huggingface/hub)
    # get_default_huggingface_cache() appends /hub to HF_HOME
    cache_path = Path(cache_dir)
    if cache_path.name == "hub":
        os.environ["HF_HOME"] = str(cache_path.parent)
    else:
        os.environ["HF_HOME"] = str(cache_dir)

    if "HF_HUB_DISABLE_XET" not in os.environ:
        os.environ["HF_HUB_DISABLE_XET"] = "1"

    return mirror
