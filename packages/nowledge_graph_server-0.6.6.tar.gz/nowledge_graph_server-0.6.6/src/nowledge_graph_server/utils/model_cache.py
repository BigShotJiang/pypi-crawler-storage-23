"""Model caching utility for offline deployment."""

import asyncio
import os
import platform
from pathlib import Path
from typing import Optional, Dict, List

import structlog

from .mirror_manager import MIRRORS, get_best_mirror, setup_hf_environment, detect_region, test_mirror
from .download_utils import (
    download_hf_snapshot,
    download_modelscope_snapshot,
    download_modelscope_files,
    resolve_hf_cache_path,
    resolve_modelscope_cache_path,
    detect_model_type,
)
from .progress_logger import log_stage

logger = structlog.get_logger(__name__)

IS_APPLE_SILICON = platform.system() == "Darwin" and platform.machine() == "arm64"
IS_INTEL_MAC = platform.system() == "Darwin" and platform.machine() == "x86_64"
IS_ONNX_PLATFORM = platform.system() in ("Windows", "Linux") or IS_INTEL_MAC

# ONNX files needed for BGE-M3 (non-Apple-Silicon)
ONNX_FILES = [
    "onnx/model.onnx",
    "tokenizer.json",
    "tokenizer_config.json",
    "special_tokens_map.json",
    "sentencepiece.bpe.model",
    "config.json",
]


class ModelCacheManager:
    """Manages downloading and caching of models for offline deployment."""

    def __init__(self, cache_dir: Optional[str] = None):
        if cache_dir:
            self.cache_dir = Path(cache_dir)
            self.embedding_cache_dir = self.cache_dir / "embeddings"
            self.hf_cache_dir = self.cache_dir / "llm" / "huggingface" / "hub"
        else:
            from ..config import get_app_cache_dir, get_default_huggingface_cache
            self.embedding_cache_dir = get_app_cache_dir("embeddings")
            self.hf_cache_dir = get_default_huggingface_cache()
            self.cache_dir = self.embedding_cache_dir.parent

        self.embedding_cache_dir.mkdir(parents=True, exist_ok=True)
        logger.info("ModelCacheManager initialized", embedding=str(self.embedding_cache_dir))

    @property
    def huggingface_cache_dir(self) -> Path:
        """Backward compatibility alias for hf_cache_dir."""
        return self.hf_cache_dir

    async def setup_huggingface_environment(self):
        """Setup HuggingFace environment variables for mirror usage."""
        setup_hf_environment(str(self.hf_cache_dir))

    def check_models_exist(self) -> Dict[str, bool]:
        """Check which models are already cached."""
        results = {"embedding": False, "local_llm": False}

        # Check embedding models
        if self.embedding_cache_dir.exists():
            for item in self.embedding_cache_dir.iterdir():
                if item.is_dir():
                    if IS_ONNX_PLATFORM:
                        # Check for ONNX model files
                        has_onnx = (
                            any(item.rglob("*.onnx")) or
                            (item / "onnx" / "model.onnx").exists() or
                            (item / "model.onnx").exists()
                        )
                        if has_onnx:
                            results["embedding"] = True
                            break
                    else:
                        # macOS: Check for MLX/safetensors files
                        if any(item.rglob("*.bin")) or any(item.rglob("*.safetensors")):
                            results["embedding"] = True
                            break

        # Also check default HuggingFace cache for ONNX models (non-Apple-Silicon)
        if IS_ONNX_PLATFORM and not results["embedding"]:
            from ..config import get_default_huggingface_cache
            default_hf_cache = get_default_huggingface_cache()

            if default_hf_cache.exists():
                for cache_item in default_hf_cache.iterdir():
                    if cache_item.is_dir():
                        # Check models--org--name/snapshots/*/onnx/model.onnx
                        if "models--" in cache_item.name:
                            for snapshot_dir in cache_item.glob("snapshots/*"):
                                if (snapshot_dir / "onnx" / "model.onnx").exists():
                                    results["embedding"] = True
                                    break
                        # Check org/model-name/onnx/model.onnx (ModelScope format in HF cache)
                        else:
                            for model_dir in cache_item.iterdir():
                                if model_dir.is_dir() and (model_dir / "onnx" / "model.onnx").exists():
                                    results["embedding"] = True
                                    break
                    if results["embedding"]:
                        break

        # Check LLM models
        llm_model = "mlx-community/Qwen3-4B-Instruct-2507-DDWQ"
        from ..config import get_default_huggingface_cache
        default_cache = get_default_huggingface_cache()

        logger.debug("check_models_exist: checking LLM", model=llm_model, hf_cache_dir=str(self.hf_cache_dir), hf_cache_dir_parent=str(self.hf_cache_dir.parent), default_cache=str(default_cache))

        # Build list of all possible cache locations to check
        # Include legacy "double-hub" paths for backward compatibility (don't re-download existing models)
        cache_locations = [
            # Current paths
            self.hf_cache_dir,                    # ~/.cache/huggingface/hub
            self.hf_cache_dir.parent,             # ~/.cache/huggingface (where downloads actually go)
            default_cache,                        # Default HF cache
            default_cache.parent,                 # Parent of default cache
            # Legacy double-hub paths (from previous bug where HF_HOME was set incorrectly)
            self.hf_cache_dir / "hub",            # ~/.cache/huggingface/hub/hub (legacy buggy path)
            self.hf_cache_dir,                    # Also serves as parent of double-hub
        ]
        # Remove duplicates while preserving order
        seen = set()
        unique_locations = []
        for loc in cache_locations:
            if str(loc) not in seen:
                seen.add(str(loc))
                unique_locations.append(loc)

        # Check all locations with both HF and ModelScope format
        for cache_loc in unique_locations:
            # Try HuggingFace format (models--org--name/snapshots/hash/)
            hf_path = resolve_hf_cache_path(llm_model, cache_loc)
            if hf_path:
                logger.debug("check_models_exist: found LLM (HF format)", path=str(hf_path))
                results["local_llm"] = True
                break

            # Try ModelScope format (org/name/)
            ms_path = resolve_modelscope_cache_path(llm_model, cache_loc)
            if ms_path:
                logger.debug("check_models_exist: found LLM (ModelScope format)", path=str(ms_path))
                results["local_llm"] = True
                break
        else:
            # Also check default ModelScope cache location
            ms_default = resolve_modelscope_cache_path(llm_model)
            if ms_default:
                logger.debug("check_models_exist: found LLM in default ModelScope cache", path=str(ms_default))
                results["local_llm"] = True
            else:
                logger.debug("check_models_exist: LLM NOT found after checking all locations")

        logger.debug("check_models_exist: final results", embedding=results["embedding"], local_llm=results["local_llm"])
        return results

    def get_cache_info(self) -> dict:
        """Get information about cached models."""
        try:
            total_size = 0
            models = []
            seen = set()

            logger.debug("get_cache_info: starting",
                embedding_cache_dir=str(self.embedding_cache_dir),
                hf_cache_dir=str(self.hf_cache_dir))

            # Scan embedding cache
            if self.embedding_cache_dir.exists():
                self._scan_embedding_cache(self.embedding_cache_dir, models, seen)

            # Scan HuggingFace cache
            if self.hf_cache_dir.exists():
                self._scan_hf_cache(self.hf_cache_dir, models, seen)

            # Scan custom LLM cache location (hf_cache_dir.parent)
            # This is where download saves LLM models - could be HF or ModelScope format
            custom_llm_cache = self.hf_cache_dir.parent
            if custom_llm_cache.exists() and custom_llm_cache != self.hf_cache_dir:
                self._scan_hf_cache(custom_llm_cache, models, seen)  # HF format (models--org--name/)
                self._scan_modelscope_cache(custom_llm_cache, models, seen)  # ModelScope format (org/name/)

            # Scan legacy double-hub path (from previous bug where HF_HOME was set incorrectly)
            legacy_double_hub = self.hf_cache_dir / "hub"
            if legacy_double_hub.exists():
                self._scan_hf_cache(legacy_double_hub, models, seen)
                self._scan_modelscope_cache(legacy_double_hub, models, seen)

            # Scan default ModelScope cache
            ms_cache = Path.home() / ".cache" / "modelscope" / "hub" / "models"
            if ms_cache.exists():
                self._scan_modelscope_cache(ms_cache, models, seen)

            # Calculate total size
            total_size_mb = sum(m.get("size_mb", 0) for m in models)

            logger.debug("get_cache_info: completed",
                model_count=len(models),
                total_size_mb=total_size_mb,
                model_names=[m.get("name") for m in models])

            return {
                "cache_directory": str(self.cache_dir),
                "embedding_cache": str(self.embedding_cache_dir),
                "huggingface_cache": str(self.hf_cache_dir),
                "modelscope_cache": str(Path.home() / ".cache" / "modelscope"),
                "total_size_mb": total_size_mb,
                "models": models,
            }
        except Exception as e:
            logger.error("Error getting cache info", error=str(e))
            return {
                "cache_directory": str(self.cache_dir),
                "embedding_cache": str(self.embedding_cache_dir),
                "huggingface_cache": str(self.hf_cache_dir),
                "total_size_mb": 0,
                "models": [],
            }

    def _scan_embedding_cache(self, cache_dir: Path, models: List, seen: set):
        """Scan embedding cache directory for models."""
        # Force filesystem cache refresh by using os.listdir directly
        if cache_dir.exists():
            try:
                os.sync()  # Sync filesystem buffers (macOS/Linux)
            except (AttributeError, OSError):
                pass  # os.sync not available on all platforms
            raw_items = os.listdir(str(cache_dir))
            items_list = [cache_dir / name for name in raw_items]
        else:
            items_list = []
            raw_items = []

        logger.debug("_scan_embedding_cache: scanning",
            cache_dir=str(cache_dir),
            exists=cache_dir.exists(),
            item_count=len(items_list),
            items=raw_items)
        for item in items_list:
            if not item.is_dir() or item.name.startswith(".") or item.name.startswith("_"):
                continue

            logger.debug("_scan_embedding_cache: checking item", item=item.name)
            model_found = False

            # Check for org/model structure (ModelScope format)
            for model_dir in item.iterdir():
                if model_dir.is_dir() and (model_dir / "config.json").exists():
                    name = f"{item.name}/{model_dir.name}"
                    if name not in seen:
                        seen.add(name)
                        size = self._calc_size(model_dir)
                        logger.debug("_scan_embedding_cache: found ModelScope model", name=name, size=size)
                        models.append({
                            "name": name,
                            "type": "embedding",
                            "size_mb": size / (1024 * 1024),
                            "path": str(model_dir),
                            "source": "modelscope",
                        })
                    model_found = True

            if not model_found:
                # Check for direct config.json (HF format without snapshots)
                if (item / "config.json").exists():
                    if item.name not in seen:
                        seen.add(item.name)
                        size = self._calc_size(item)
                        logger.debug("_scan_embedding_cache: found direct HF model", name=item.name, size=size)
                        models.append({
                            "name": item.name,
                            "type": "embedding",
                            "size_mb": size / (1024 * 1024),
                            "path": str(item),
                            "source": "huggingface",
                        })
                # Check for HuggingFace snapshots structure (models--org--name/snapshots/hash/)
                elif (item / "snapshots").exists():
                    logger.debug("_scan_embedding_cache: found snapshots dir", item=item.name)
                    for snapshot_dir in (item / "snapshots").iterdir():
                        if snapshot_dir.is_dir() and (snapshot_dir / "config.json").exists():
                            name = item.name.replace("models--", "").replace("--", "/")
                            if name not in seen:
                                seen.add(name)
                                size = self._calc_size(item)
                                logger.debug("_scan_embedding_cache: found HF snapshots model", name=name, size=size, path=str(item))
                                models.append({
                                    "name": name,
                                    "type": "embedding",
                                    "size_mb": size / (1024 * 1024),
                                    "path": str(item),
                                    "source": "huggingface",
                                })
                            break

    def _scan_hf_cache(self, cache_dir: Path, models: List, seen: set):
        """Scan HuggingFace cache for models."""
        for item in cache_dir.iterdir():
            if not item.is_dir() or item.name.startswith("."):
                continue

            # HuggingFace format: models--org--model
            if item.name.startswith("models--"):
                name = item.name.replace("models--", "").replace("--", "/")
                if name not in seen:
                    seen.add(name)
                    size = self._calc_size(item)
                    models.append({
                        "name": name,
                        "type": detect_model_type(name),
                        "size_mb": size / (1024 * 1024),
                        "path": str(item),
                        "source": "huggingface",
                    })
            else:
                # ModelScope format in HF cache: org/model-name
                # This happens when model_file_download saves to hf_cache_root
                for model_dir in item.iterdir():
                    if model_dir.is_dir():
                        has_onnx = (model_dir / "onnx" / "model.onnx").exists()
                        has_config = (model_dir / "config.json").exists()
                        if has_onnx or has_config:
                            name = f"{item.name}/{model_dir.name}"
                            if name not in seen:
                                seen.add(name)
                                size = self._calc_size(model_dir)
                                models.append({
                                    "name": name,
                                    "type": detect_model_type(name),
                                    "size_mb": size / (1024 * 1024),
                                    "path": str(model_dir),
                                    "source": "modelscope",
                                })

    def _scan_modelscope_cache(self, cache_dir: Path, models: List, seen: set):
        """Scan ModelScope cache for models."""
        for org_dir in cache_dir.iterdir():
            if not org_dir.is_dir():
                continue
            for model_dir in org_dir.iterdir():
                if model_dir.is_dir() and (model_dir / "config.json").exists():
                    name = f"{org_dir.name}/{model_dir.name}"
                    if name not in seen:
                        seen.add(name)
                        size = self._calc_size(model_dir)
                        models.append({
                            "name": name,
                            "type": detect_model_type(name),
                            "size_mb": size / (1024 * 1024),
                            "path": str(model_dir),
                            "source": "modelscope",
                        })

    def _calc_size(self, path: Path) -> int:
        """Calculate total size of directory.

        Handles both:
        - Windows: No symlinks (local_dir_use_symlinks=False), all regular files
        - macOS/Linux: HuggingFace uses blobs/ + symlinks in snapshots/

        Uses inode tracking to avoid double-counting when symlinks point to same blob.
        """
        total = 0
        seen_inodes = set()  # Track inodes to avoid counting same file twice
        file_count = 0

        logger.debug("_calc_size: starting", path=str(path), exists=path.exists())

        for f in path.rglob("*"):
            try:
                # Skip symlinks on platforms where they're problematic
                # On macOS/Linux, symlinks point to blobs which we count directly
                if f.is_symlink():
                    continue

                if f.is_file():
                    stat = f.stat()
                    # Track inode to avoid counting same file twice
                    # (shouldn't happen if we skip symlinks, but defensive)
                    inode = (stat.st_dev, stat.st_ino)
                    if inode not in seen_inodes:
                        seen_inodes.add(inode)
                        total += stat.st_size
                        file_count += 1
            except (OSError, ValueError):
                # Skip files that can't be accessed
                pass

        logger.debug("_calc_size: completed", path=str(path), total=total, file_count=file_count)
        return total

    async def cache_embedding_model(
        self,
        model_name: Optional[str] = None,
        download_source: str = "huggingface",
    ) -> bool:
        """Cache embedding model (MLX on macOS Apple Silicon, ONNX otherwise)."""
        if model_name is None:
            model_name = (
                "mlx-community/Qwen3-Embedding-0.6B-4bit-DWQ"
                if IS_APPLE_SILICON
                else "BAAI/bge-m3"
            )

        logger.info("Caching embedding model", model=model_name, source=download_source)

        try:
            if IS_APPLE_SILICON and "mlx-community" in model_name:
                return await self._cache_mlx_embedding(model_name, download_source)
            else:
                return await self._cache_onnx_embedding(model_name, download_source)
        except Exception as e:
            logger.error("Failed to cache embedding", model=model_name, error=str(e))
            log_stage("embedding_download", "completed", f"Download failed: {e}")
            return False

    async def _cache_mlx_embedding(self, model_name: str, source: str) -> bool:
        """Cache MLX embedding model (macOS only)."""
        if not IS_APPLE_SILICON:
            logger.warning("MLX only available on Apple Silicon")
            return False

        # Download model
        logger.debug("_cache_mlx_embedding: starting download",
            model=model_name,
            embedding_cache_dir=str(self.embedding_cache_dir),
            source=source)

        if source == "modelscope":
            path = await download_modelscope_snapshot(model_name, str(self.embedding_cache_dir), "embedding_download")
            if not path:
                path = await download_hf_snapshot(model_name, str(self.embedding_cache_dir), "embedding_download")
        else:
            path = await download_hf_snapshot(model_name, str(self.embedding_cache_dir), "embedding_download")
            if not path:
                path = await download_modelscope_snapshot(model_name, str(self.embedding_cache_dir), "embedding_download")

        logger.debug("_cache_mlx_embedding: download completed",
            returned_path=path,
            path_exists=Path(path).exists() if path else False)

        if not path:
            return False

        # Verify with MLX
        try:
            from mlx_embeddings.utils import load
            model, tokenizer = load(path)
            logger.info("MLX embedding verified", model=model_name, path=path)
            return True
        except Exception as e:
            logger.error("MLX verification failed", error=str(e))
            return False

    async def _cache_onnx_embedding(self, model_name: str, source: str) -> bool:
        """Cache ONNX embedding model (non-Apple-Silicon)."""
        cache_dir = str(self.embedding_cache_dir)

        if source == "modelscope":
            files = await download_modelscope_files(model_name, cache_dir, ONNX_FILES)
            if not any("onnx" in str(f).lower() for f in files):
                # Fallback to HuggingFace
                path = await download_hf_snapshot(model_name, cache_dir, "embedding_download", allow_patterns=["onnx/*", "*.json", "*.model"])
                return path is not None and Path(path, "onnx", "model.onnx").exists()
            return True
        else:
            path = await download_hf_snapshot(model_name, cache_dir, "embedding_download", allow_patterns=["onnx/*", "*.json", "*.model"])
            if path and Path(path, "onnx", "model.onnx").exists():
                return True
            # Fallback to ModelScope
            files = await download_modelscope_files(model_name, cache_dir, ONNX_FILES)
            return any("onnx" in str(f).lower() for f in files)

    async def cache_llm_model(
        self,
        model_name: str = "mlx-community/Qwen3-4B-Instruct-2507-DDWQ",
        download_source: str = "huggingface",
    ) -> bool:
        """Cache LLM model (macOS Apple Silicon only)."""
        if not IS_APPLE_SILICON:
            logger.warning("MLX LLM caching only available on Apple Silicon")
            return False

        logger.info("cache_llm_model: starting", model=model_name, source=download_source, hf_cache_dir=str(self.hf_cache_dir), download_target=str(self.hf_cache_dir.parent))

        # Set ModelScope flag before importing mlx_lm
        os.environ["MLXLM_USE_MODELSCOPE"] = "true" if download_source == "modelscope" else "false"
        self.hf_cache_dir.mkdir(parents=True, exist_ok=True)

        try:
            # Check if already cached (HF format or ModelScope format in various locations)
            # Include legacy double-hub paths for backward compatibility
            logger.debug("cache_llm_model: checking if already cached")
            cache_locations = [
                self.hf_cache_dir,
                self.hf_cache_dir.parent,
                self.hf_cache_dir / "hub",  # Legacy double-hub path
            ]
            cached = None
            for cache_loc in cache_locations:
                cached = resolve_hf_cache_path(model_name, cache_loc) or resolve_modelscope_cache_path(model_name, cache_loc)
                if cached:
                    break
            if not cached:
                cached = resolve_modelscope_cache_path(model_name)  # Default ModelScope cache

            if cached:
                logger.info("cache_llm_model: found cached LLM", path=str(cached))
                from mlx_lm.utils import load
                load(str(cached))
                return True
            else:
                logger.debug("cache_llm_model: NOT cached, will download")

            # Download
            if download_source == "modelscope":
                logger.debug("cache_llm_model: downloading via ModelScope", target=str(self.hf_cache_dir.parent))
                path = await download_modelscope_snapshot(model_name, str(self.hf_cache_dir.parent), "llm_download")
                if not path:
                    logger.debug("cache_llm_model: ModelScope failed, trying HuggingFace")
                    path = await download_hf_snapshot(model_name, str(self.hf_cache_dir.parent), "llm_download")
            else:
                logger.debug("cache_llm_model: downloading via HuggingFace", target=str(self.hf_cache_dir.parent))
                path = await download_hf_snapshot(model_name, str(self.hf_cache_dir.parent), "llm_download")
                if not path:
                    logger.debug("cache_llm_model: HuggingFace failed, trying ModelScope")
                    path = await download_modelscope_snapshot(model_name, str(self.hf_cache_dir.parent), "llm_download")

            if not path:
                logger.error("cache_llm_model: download failed, no path returned")
                return False

            path_obj = Path(path)
            logger.info("cache_llm_model: download completed", returned_path=path, path_exists=path_obj.exists(), config_exists=(path_obj / "config.json").exists())

            # Verify
            logger.debug("cache_llm_model: verifying with mlx_lm.load")
            from mlx_lm.utils import load
            load(str(path))
            logger.info("cache_llm_model: verification successful")
            return True

        except Exception as e:
            logger.error("cache_llm_model: exception", model=model_name, error=str(e))
            log_stage("llm_download", "completed", f"Download failed: {e}")
            return False

    async def warm_up_lang_detect(self) -> bool:
        """Pre-load the language detection model during model setup.

        Calls detect() on a small sentence to ensure the fast-langdetect model
        is loaded and cached. This prevents a surprise download on first search
        query. Uses model="lite" which loads the bundled small model (~916KB)
        shipped with the fast-langdetect pip package — no network download needed.

        Returns:
            True if lang detect is ready, False on failure (Unicode fallback will be used).
        """
        try:
            from fast_langdetect import detect

            log_stage("embedding_download", "downloading", "Initializing language detection...")
            # Use model="lite" — same as tokenizers.py runtime calls.
            # This loads the bundled lid.176.ftz model into memory.
            result = detect("hello world", model="lite")
            logger.info("Language detection model ready", result=result)
            return True
        except ImportError:
            logger.debug("fast-langdetect not installed, will use Unicode fallback")
            return False
        except Exception as e:
            logger.warning("Failed to warm up language detection", error=str(e))
            return False

    async def cache_all_models(self, download_source: str = "huggingface") -> bool:
        """Cache all required models."""
        embedding_ok = await self.cache_embedding_model(download_source=download_source)
        llm_ok = await self.cache_llm_model(download_source=download_source) if IS_APPLE_SILICON else True
        return embedding_ok and llm_ok


# Backward compatibility class
class HuggingFaceMirrorManager:
    """Backward compatibility wrapper for mirror_manager functions."""

    MIRRORS = MIRRORS

    @classmethod
    def detect_region(cls) -> str:
        return detect_region()

    @classmethod
    def test_mirror_connectivity(cls, mirror_url: str, timeout: int = 5) -> bool:
        return test_mirror(mirror_url, timeout)

    @classmethod
    def get_best_mirror(cls) -> str:
        return get_best_mirror()
