#!/usr/bin/env python3
"""
Custom TQDM progress bar that logs to progress file.

This replaces visual progress bars with structured logging for Tauri to consume.
"""

from tqdm import tqdm as _tqdm
from typing import Optional
from .progress_logger import log_progress, log_stage


def make_progress_tqdm(operation: str):
    """Factory function to create a ProgressTqdm class with a specific operation type.

    Args:
        operation: The operation type (e.g., "embedding_download", "llm_download")

    Returns:
        A ProgressTqdm class configured with the operation type
    """
    class ConfiguredProgressTqdm(ProgressTqdm):
        def __init__(self, *args, **kwargs):
            # Set the operation type before calling parent __init__
            self._configured_operation = operation
            super().__init__(*args, **kwargs)

    return ConfiguredProgressTqdm


def make_modelscope_callback(operation: str):
    """Factory function to create a ModelScope callback with a specific operation type.

    Args:
        operation: The operation type (e.g., "embedding_download", "llm_download")

    Returns:
        A ModelScopeProgressCallback class configured with the operation type
    """
    class ConfiguredModelScopeCallback(ModelScopeProgressCallback):
        def __init__(self, filename: str, file_size: int):
            # Set operation before calling parent
            self._configured_operation = operation
            super().__init__(filename, file_size)

    return ConfiguredModelScopeCallback


class ModelScopeProgressCallback:
    """Custom ModelScope ProgressCallback that logs to progress file.

    ModelScope uses a different API than HuggingFace:
    - Instead of tqdm_class, it uses progress_callbacks parameter
    - Callbacks must implement: __init__(filename, file_size), update(size), end()
    """

    # Class-level tracking for multi-file downloads
    _current_file_number = 0
    _completed_files: list = []
    _total_bytes_downloaded = 0
    _configured_operation: Optional[str] = None  # Set by make_modelscope_callback factory

    def __init__(self, filename: str, file_size: int):
        """Initialize callback.

        Args:
            filename: Name of file being downloaded
            file_size: Total size in bytes
        """
        self.filename = filename
        self.file_size = file_size
        self.downloaded = 0
        self.last_logged_percentage = -1

        # Increment file counter
        ModelScopeProgressCallback._current_file_number += 1
        self.file_number = ModelScopeProgressCallback._current_file_number

        # Check if operation was pre-configured (via make_modelscope_callback factory)
        if self._configured_operation is not None:
            self.operation: str = self._configured_operation
        else:
            # Determine operation type from filename
            if "embedding" in filename.lower() or "bge" in filename.lower() or "qwen3-embedding" in filename.lower():
                self.operation = "embedding_download"
            elif "llm" in filename.lower() or "qwen" in filename.lower() or "instruct" in filename.lower():
                self.operation = "llm_download"
            else:
                self.operation = "model_download"

        # Log initial stage with file number
        log_stage(
            operation=self.operation,
            stage="downloading",
            message=f"Starting download: File {self.file_number} - {filename}",
            details={
                "filename": filename,
                "total_bytes": file_size,
                "file_number": self.file_number
            }
        )

    def update(self, size: int):
        """Update progress by size bytes.

        Args:
            size: Number of bytes downloaded in this chunk
        """
        self.downloaded += size

        if self.file_size > 0:
            percentage = (self.downloaded / self.file_size) * 100

            # Log every 0.5% for smoother progress (or always if at 100%)
            if abs(percentage - self.last_logged_percentage) >= 0.5 or percentage >= 100:
                self.last_logged_percentage = percentage

                # Calculate speed (approximation based on chunk size)
                speed_mbps = round(size / (1024 * 1024), 2)

                details = {
                    "downloaded": self.downloaded,
                    "total": self.file_size,
                    "filename": self.filename,
                    "file_number": self.file_number,
                    "completed_files": len(ModelScopeProgressCallback._completed_files)
                }

                if speed_mbps > 0:
                    details["speed_mbps"] = speed_mbps

                log_progress(
                    operation=self.operation,
                    percentage=percentage,
                    message=f"File {self.file_number}: {percentage:.1f}% - {self.filename}",
                    details=details
                )

    def end(self):
        """Signal download completion for this file."""
        # Mark this file as completed
        ModelScopeProgressCallback._completed_files.append(self.filename)
        ModelScopeProgressCallback._total_bytes_downloaded += self.downloaded

        # Don't emit stage here - individual file completion shouldn't trigger UI state change
        # The final stage is emitted from model_cache.py after ALL files are downloaded
        # We already emitted 100% progress in update(), so UI knows this file is done

    @classmethod
    def reset(cls):
        """Reset class-level counters for a new download operation."""
        cls._current_file_number = 0
        cls._completed_files = []
        cls._total_bytes_downloaded = 0


class ProgressTqdm(_tqdm):
    """Custom tqdm that emits structured progress logs instead of terminal output.

    This works with huggingface_hub.snapshot_download and modelscope downloads.

    HuggingFace creates TWO types of tqdm instances:
    1. Outer "Fetching N files" - tracks file count (total is small, like 13)
    2. Inner file downloads - tracks bytes (total is large, like 2.34GB)

    We detect which type based on the total size and report accordingly.
    """

    _configured_operation: Optional[str] = None  # Set by make_progress_tqdm factory

    # Class-level tracking for multi-file downloads (similar to ModelScope)
    _current_file_number: int = 0
    _completed_files: list = []  # type: ignore[assignment]
    _total_bytes_all_files: int = 0
    _downloaded_bytes_all_files: int = 0
    _total_file_count: int = 0  # From outer "Fetching N files" progress
    _completed_file_count: int = 0

    @classmethod
    def reset(cls) -> None:
        """Reset class-level counters for a new download operation."""
        cls._current_file_number = 0
        cls._completed_files = []
        cls._total_bytes_all_files = 0
        cls._downloaded_bytes_all_files = 0
        cls._total_file_count = 0
        cls._completed_file_count = 0

    def __init__(self, *args, **kwargs):
        # Check if operation was pre-configured (via make_progress_tqdm factory)
        if self._configured_operation is not None:
            self.operation: str = self._configured_operation
        else:
            # Extract operation type from description or use default
            desc = kwargs.get("desc", "download")

            # Determine operation type based on description
            if "embedding" in desc.lower():
                self.operation = "embedding_download"
            elif "llm" in desc.lower() or "model" in desc.lower():
                self.operation = "llm_download"
            else:
                self.operation = "model_download"

        self.model_name = kwargs.pop("model_name", None)
        self.last_logged_percentage = -1  # Track to avoid spam
        self._prev_n = 0  # Track previous n for delta calculation

        # Redirect output to null to prevent terminal output (but keep progress tracking active)
        # Use io.StringIO instead of /dev/null for better cross-platform compatibility
        from io import StringIO
        self._devnull = StringIO()
        kwargs["file"] = self._devnull
        # Set mininterval to 0 to get more frequent updates
        kwargs["mininterval"] = 0

        super().__init__(*args, **kwargs)

        desc = getattr(self, 'desc', 'unknown')

        # Detect if this is the outer "Fetching N files" progress bar
        # HuggingFace creates this with total=file_count (small number like 13)
        # vs actual file downloads which have total=bytes (large, like 2GB+)
        # Threshold: if total < 1000, it's likely a file count, not bytes
        self.is_file_count_progress = self.total is not None and self.total < 1000

        if self.is_file_count_progress:
            # This is the outer "Fetching N files" progress - store the total file count
            ProgressTqdm._total_file_count = self.total or 0
            self.file_number = 0  # Not a real file

            log_stage(
                operation=self.operation,
                stage="downloading",
                message=f"Fetching {self.total} files...",
                details={
                    "total_files": self.total,
                    "filename": desc
                }
            )
        else:
            # This is an actual file download (bytes)
            ProgressTqdm._current_file_number += 1
            self.file_number = ProgressTqdm._current_file_number

            # Add this file's size to total
            if self.total:
                ProgressTqdm._total_bytes_all_files += self.total

            # Log initial stage with file info
            log_stage(
                operation=self.operation,
                stage="downloading",
                message=f"File {self.file_number}/{ProgressTqdm._total_file_count or '?'}: {desc}",
                details={
                    "total_bytes": self.total,
                    "file_number": self.file_number,
                    "total_files": ProgressTqdm._total_file_count,
                    "filename": desc
                } if self.total else {"file_number": self.file_number, "filename": desc}
            )

    def update(self, n=1):
        """Override update to log progress."""
        super().update(n)

        # Force tqdm to recalculate rate/ETA immediately
        self.refresh()

        if self.total and self.total > 0:
            percentage = (self.n / self.total) * 100

            if self.is_file_count_progress:
                # This is the outer "Fetching N files" progress
                # Update completed file count (but don't spam logs)
                ProgressTqdm._completed_file_count = int(self.n)

                # Only log when a file completes (n changes by 1)
                if percentage >= 100 or int(self.n) != int(self._prev_n):
                    self._prev_n = self.n
                    log_progress(
                        operation=self.operation,
                        percentage=percentage,
                        message=f"Fetched {int(self.n)}/{self.total} files",
                        details={
                            "fetched_files": int(self.n),
                            "total_files": self.total,
                        }
                    )
            else:
                # This is an actual file download (bytes) - report detailed progress
                # Track cumulative bytes for multi-file progress
                delta = self.n - self._prev_n
                self._prev_n = self.n
                ProgressTqdm._downloaded_bytes_all_files += delta

                # Log every 0.5% for smoother progress (or always if at 100%)
                if abs(percentage - self.last_logged_percentage) >= 0.5 or percentage >= 100:
                    self.last_logged_percentage = percentage

                    # Calculate speed (bytes/sec) - use format_dict for accurate rate
                    format_dict = self.format_dict
                    rate = format_dict.get("rate", None) or getattr(self, "rate", None)
                    speed_mbps = None
                    if rate:
                        speed_mbps = round(rate / (1024 * 1024), 2)  # Convert to MB/s

                    # Calculate ETA for current file
                    eta_seconds = None
                    if rate and rate > 0:
                        remaining_bytes = self.total - self.n
                        eta_seconds = int(remaining_bytes / rate)

                    # Include file description for multi-file tracking
                    desc = format_dict.get("desc", "") or getattr(self, "desc", "")

                    # Format downloaded/total as human-readable
                    downloaded_mb = self.n / (1024 * 1024)
                    total_mb = self.total / (1024 * 1024)

                    details = {
                        "downloaded": self.n,
                        "total": self.total,
                        "file_number": self.file_number,
                        "total_files": ProgressTqdm._total_file_count,
                        "completed_files": len(ProgressTqdm._completed_files),
                    }

                    if desc:
                        details["filename"] = desc

                    if speed_mbps:
                        details["speed_mbps"] = speed_mbps

                    if eta_seconds is not None:
                        details["eta_seconds"] = eta_seconds

                    if self.model_name:
                        details["model_name"] = self.model_name

                    # Create informative message
                    file_info = f"File {self.file_number}/{ProgressTqdm._total_file_count}" if ProgressTqdm._total_file_count else f"File {self.file_number}"
                    size_info = f"{downloaded_mb:.1f}/{total_mb:.1f}MB"

                    log_progress(
                        operation=self.operation,
                        percentage=percentage,
                        message=f"{file_info}: {percentage:.1f}% ({size_info})",
                        details=details
                    )

    def close(self):
        """Override close to log completion for this file."""
        super().close()

        # Mark this file as completed
        desc = getattr(self, 'desc', f'file_{self.file_number}')
        ProgressTqdm._completed_files.append(desc)


class MultiFileProgressTqdm(ProgressTqdm):
    """TQDM for tracking multi-file downloads (e.g., HuggingFace repos).

    HuggingFace downloads multiple files, this aggregates their progress.
    Note: This is largely superseded by the improved ProgressTqdm class above.
    """

    _multi_total_files: int = 0
    _multi_completed_files: int = 0

    def __init__(self, *args, **kwargs):
        # Track file count if provided
        if "total_files" in kwargs:
            MultiFileProgressTqdm._multi_total_files = kwargs.pop("total_files")
            MultiFileProgressTqdm._multi_completed_files = 0

        super().__init__(*args, **kwargs)

    def close(self):
        """Track completed files."""
        super().close()

        if MultiFileProgressTqdm._multi_total_files > 0:
            MultiFileProgressTqdm._multi_completed_files += 1

            file_percentage = (
                MultiFileProgressTqdm._multi_completed_files /
                MultiFileProgressTqdm._multi_total_files * 100
            )

            log_progress(
                operation=self.operation,
                percentage=file_percentage,
                message=f"Downloaded {MultiFileProgressTqdm._multi_completed_files}/{MultiFileProgressTqdm._multi_total_files} files",
                details={
                    "completed_files": MultiFileProgressTqdm._multi_completed_files,
                    "total_files": MultiFileProgressTqdm._multi_total_files
                }
            )
