from typing import Optional, Dict, Any, List
from nowledge_graph_server.database.kuzu_client import KuzuClient
from nowledge_graph_server.models.graph import ThreadNode, MemoryNode
from nowledge_graph_server.utils.formatters import format_time_ago

import structlog
import real_ladybug as kuzu

logger = structlog.get_logger(__name__)


async def transform_memory_to_frontend_format(
    memory: MemoryNode,
    kuzu_client: KuzuClient,
    include_labels: bool = True,
    include_source_thread: bool = True,
) -> Dict[str, Any]:
    """Transform MemoryNode to frontend-expected format."""
    # Extract isFavorite from metadata
    is_favorite = False
    if memory.metadata:
        is_favorite = memory.metadata.get("is_favorite", False)

    # Convert importance to rating (0-1 to 1-5 scale)
    rating = max(1, min(5, int(memory.importance * 5)))

    # Use title directly, fallback to truncated content if title is missing
    title = memory.title or (
        memory.content[:50] + "..." if len(memory.content) > 50 else memory.content
    )

    # Get labels if requested
    label_ids: List[str] = []
    if include_labels:
        try:
            labels: List[Dict[str, Any]] = await kuzu_client.label_mgr.get_memory_labels(memory.id) # type: ignore[attr-defined]
            label_ids = [label["id"] for label in labels] # type: ignore[assignment]
        except Exception as e:
            logger.warning(
                "Failed to get memory labels", memory_id=memory.id, error=str(e)
            )

    # Get source thread if requested
    source_thread = None
    source = memory.source or memory.metadata.get("source_detected", "Manual")
    if include_source_thread:
        try:
            # Query to find source thread
            # FIX: Return thread_id instead of id - API expects thread_id for /threads/{thread_id} endpoint
            query = """
                MATCH (t:Thread)-[r:COMPACTS_TO]->(m:Memory {id: $memory_id})
                RETURN t.thread_id, t.title, t.source
            """
            if kuzu_client.conn:
                result = kuzu_client.conn.execute(query, {"memory_id": memory.id})
                assert isinstance(result, kuzu.QueryResult), (
                    "result is not a QueryResult"
                )
                if result.has_next():
                    row = result.get_next()
                    source_thread = {
                        "id": row[0],  # type: ignore - This is thread_id, used as 'id' in frontend
                        "title": row[1],  # type: ignore
                    }
                    source = row[2] or "Manual"  # type: ignore
        except Exception as e:
            logger.warning(
                "Failed to get source thread", memory_id=memory.id, error=str(e)
            )

    return {
        "id": memory.id,  # Use raw UUID directly instead of hash conversion
        "title": title,
        "content": memory.content,  # Add the actual memory content
        "source": source,
        "time": format_time_ago(memory.created_at),
        "rating": rating,
        "confidence": memory.confidence,  # Add missing confidence field
        "metadata": {
            **(memory.metadata or {}),  # Include existing metadata
            # Add bi-temporal fields for client-side filtering
            "event_start": memory.event_start,
            "event_end": memory.event_end,
            "temporal_context": memory.temporal_context,
            # ISO timestamp for frontend i18n relative-time formatting
            "created_at": memory.created_at.isoformat() if memory.created_at else None,
        },
        "label_ids": label_ids,
        "is_favorite": is_favorite,
        "source_thread": source_thread,
    }


async def find_memory_by_frontend_id(
    frontend_id: str, kuzu_client: KuzuClient
) -> Optional[str]:
    """Find backend memory ID - now simply validates UUID exists.

    Args:
        frontend_id: Frontend UUID string
        kuzu_client: Database client

    Returns:
        Backend memory ID string if found, None otherwise
    """
    if not kuzu_client.conn:
        logger.error("Database connection not available for ID validation")
        return None

    try:
        # Since we're using UUIDs directly, just validate it exists
        query = "MATCH (m:Memory {id: $memory_id}) RETURN m.id"
        result = kuzu_client.conn.execute(query, {"memory_id": frontend_id})
        assert isinstance(result, kuzu.QueryResult), "result is not a QueryResult"

        if result.has_next():
            return frontend_id  # UUID exists, return as-is
        else:
            logger.warning(f"Memory not found with UUID: {frontend_id}")
            return None

    except Exception as e:
        logger.error(f"Memory ID validation failed: {e}", frontend_id=frontend_id)
        return None


async def transform_thread_to_frontend_format(
    thread: ThreadNode, kuzu_client: KuzuClient
) -> Dict[str, Any]:
    """Transform ThreadNode to frontend-expected format."""
    # Extract isFavorite from metadata
    is_favorite = False
    if thread.metadata:
        is_favorite = thread.metadata.get("is_favorite", False)

    # Format date
    date_str = (
        thread.created_at.strftime("%b %d, %Y") if thread.created_at else "Unknown"
    )

    return {
        "id": thread.thread_id,  # Use thread_id (frontend ID) instead of UUID id
        "title": thread.title,
        "source": thread.source or "Manual",
        "messages": thread.message_count or 0,
        "date": date_str,
        "is_favorite": is_favorite,
    }
