from fastapi import HTTPException
from fastapi.responses import JSONResponse
from nowledge_graph_server.api.models.responses import APIError
from nowledge_graph_server.main import app

import structlog


logger = structlog.get_logger(__name__)


@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    """Handle HTTP exceptions."""
    return JSONResponse(
        status_code=exc.status_code,
        content=APIError(error=exc.detail).dict(),
    )


@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    """Handle general exceptions."""
    logger.error("Unhandled exception", error=str(exc), request_path=request.url.path)
    return JSONResponse(
        status_code=500,
        content=APIError(error="Internal server error").dict(),
    )
