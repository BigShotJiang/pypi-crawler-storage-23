"""MCP Server Integration with FastAPI using FastMCP SSE mode."""

from typing import Any

import structlog

from fastmcp import FastMCP

from nowledge_graph_server.core.memory_operations import MemoryOperations
from nowledge_graph_server.core.search_operations import SearchOperations
from nowledge_graph_server.core.graph_operations import GraphOperations
from nowledge_graph_server.core.thread_operations import ThreadOperations
from nowledge_graph_server.core.evolves_operations import EvolvesOperations
from nowledge_graph_server.database.kuzu_client import KuzuClient

# Import modular MCP components
from nowledge_graph_server.mcp.middleware import AppFilteringMiddleware
from nowledge_graph_server.mcp.tools.memory_tools import register_memory_tools
from nowledge_graph_server.mcp.tools.thread_tools import register_thread_tools
from nowledge_graph_server.mcp.tools.graph_tools import register_graph_tools
from nowledge_graph_server.mcp.tools.web_search_tools import register_web_search_tools
from nowledge_graph_server.mcp.tools.obsidian_tools import register_obsidian_tools
from nowledge_graph_server.mcp.tools.apple_notes_tools import register_apple_notes_tools
from nowledge_graph_server.mcp.tools.working_memory_tools import register_working_memory_tools
from nowledge_graph_server.mcp.tools.knowledge_processing_tools import register_knowledge_processing_tools
from nowledge_graph_server.mcp.prompts.prompts import register_prompts

logger = structlog.get_logger(__name__)

# Global variables for services (will be initialized from existing FastAPI app context)
_services_initialized = False
_memory_operations, _search_operations, _graph_operations, _thread_operations = None, None, None, None
_mcp_server = None


def set_operations_context(
    memory_ops: MemoryOperations,
    search_ops: SearchOperations,
    graph_ops: GraphOperations,
    thread_ops: ThreadOperations,
    kuzu_client: KuzuClient | None = None,
):
    """Set the operations context from the main FastAPI app."""
    global \
        _services_initialized, \
        _memory_operations, \
        _search_operations, \
        _graph_operations, \
        _thread_operations, \
        _mcp_server
    _memory_operations = memory_ops
    _search_operations = search_ops
    _graph_operations = graph_ops
    _thread_operations = thread_ops
    _services_initialized = True
    logger.info("MCP operations context initialized")

    # Register tools now that operations are available
    if _mcp_server is not None:
        logger.info("Registering tools with initialized operations")
        register_memory_tools(_mcp_server, memory_ops, search_ops)
        register_thread_tools(_mcp_server, thread_ops)
        register_web_search_tools(_mcp_server)  # Web search doesn't need ops context
        register_obsidian_tools(_mcp_server)  # Obsidian tools don't need ops context
        register_apple_notes_tools(_mcp_server)  # Apple Notes tools: macOS only, no ops context
        register_working_memory_tools(_mcp_server)  # Filesystem only, no ops context
        register_knowledge_processing_tools(_mcp_server)  # Agent manager triggers, no ops context
        # Graph tools (v0.6) — EVOLVES chains, neighbors, crystals, stats, explore_graph
        if kuzu_client is not None:
            evolves_ops = EvolvesOperations(kuzu_client)
            register_graph_tools(_mcp_server, evolves_ops, graph_ops=graph_ops, memory_ops=memory_ops)
            logger.info("Graph tools registered (EVOLVES chain, neighbors, crystals, stats, explore_graph)")
        logger.info("Tools registered successfully")


def create_mcp_server() -> FastMCP[Any]:
    """Create and configure the FastMCP server with tools and middleware.

    This server includes:
    - Memory management tools (available to all apps)
    - Thread persistence tools (Claude Code/Codex only)
    - Prompts for memory analysis and session saving
    - App-based filtering middleware to restrict certain tools/prompts

    Note: Tools are registered later in set_operations_context() after
    operations are initialized. Only prompts and middleware are set up here.
    """
    global _mcp_server

    mcp = FastMCP[Any](
        name="Nowledge Mem",
        instructions="""Personal memory store with semantic search.

Tools: memory_search, memory_add, memory_update, memory_delete, list_memory_labels, memory_evolves_chain, memory_neighbors, list_crystals, graph_stats, thread_search, thread_fetch_messages, thread_persist, web_search, obsidian_search, obsidian_get_note, read_working_memory

Labels: lowercase-hyphenated, check existing first (list_memory_labels)
Update: search → get memory_id → memory_update
Delete single: search → get memory_id → memory_delete(memory_id=...)
Delete bulk: search → collect memory IDs → memory_delete(memory_ids=[...])

Memory → Thread: memory_search results include source_thread_id when available. Use thread_fetch_messages(source_thread_id) to get full conversation context.

Threads: Use thread_search to find past conversations, then thread_fetch_messages to get full content. More efficient than distilling all messages.

Web search: Use web_search to find current info
Obsidian: Use obsidian_search/obsidian_get_note directly (CLI-based, no connect step)
Apple Notes (macOS only): Use apple_notes_search, apple_notes_list, apple_notes_get_note to access Notes.app""",
        on_duplicate_tools="warn",  # Warn if duplicate tools are registered
    )

    # Store reference for later tool registration
    _mcp_server = mcp

    # Add app-based filtering middleware
    # This middleware filters tools and prompts based on the MCP client app source
    # - thread_persist tool: only available to Claude Code and Codex
    # - save prompt: only available to Claude Code and Codex
    # - All other tools/prompts: available to all apps
    mcp.add_middleware(AppFilteringMiddleware())
    logger.info("Added app-based filtering middleware to MCP server")

    # Register prompts (these don't need operations context)
    register_prompts(mcp)
    logger.info("Registered MCP prompts")

    # NOTE: Tools will be registered later in set_operations_context()
    # after the operations are initialized during app startup
    logger.info("MCP server created, tools will be registered after operations are initialized")

    return mcp


def initialize_mcp_context_from_dependencies():
    """Initialize MCP context using the existing dependency system."""
    from .api.dependencies import (
        memory_operations, search_operations, graph_operations, thread_operations,
        kuzu_client,
    )
    async def setup_context():
        """Set up the MCP context with operations."""
        try:
            # Use the global operations instances directly
            if (
                memory_operations is None
                or search_operations is None
                or graph_operations is None
                or thread_operations is None
            ):
                logger.warning(
                    "Some operations not initialized yet, MCP tools may not work properly"
                )
                return
            # Set the context for MCP tools
            set_operations_context(
                memory_operations, search_operations, graph_operations, thread_operations,
                kuzu_client=kuzu_client,
            )
            logger.info("MCP context initialized from API dependencies")

        except Exception as e:
            logger.error("Failed to initialize MCP context", error=str(e))
            raise

    return setup_context
