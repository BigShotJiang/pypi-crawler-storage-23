"""Base types and utilities for conversation discovery.

Contains:
- ConversationFile dataclass
- Path encoding/decoding utilities
"""

import os
import re
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import structlog

logger = structlog.get_logger(__name__)


def decode_project_path_enhanced(encoded: str) -> Optional[str]:
    """Decode encoded project path with filesystem validation.

    Handles project names that contain hyphens (e.g., my-cool-project).
    Claude Code encodes paths by replacing / with -, but this is ambiguous
    when the project name itself contains hyphens.

    For example:
    - Encoded: -Users-weyl-my-cool-project
    - Simple decode: /Users/weyl/my/cool/project (WRONG)
    - Correct decode: /Users/weyl/my-cool-project (via filesystem validation)

    Args:
        encoded: Encoded path string (e.g., -Users-weyl-project)

    Returns:
        Decoded absolute path, or None if decoding fails
    """
    if not encoded or not encoded.startswith("-"):
        return None

    # Try simple decode first
    simple = "/" + encoded[1:].replace("-", "/")
    if os.path.exists(simple):
        return simple

    # Simple decode failed - try combinations via filesystem validation
    segments = encoded[1:].split("-")
    result = _find_valid_path("/", segments)
    if result:
        return result

    # Fallback to simple decode (even if path doesn't exist)
    return simple


def _find_valid_path(base: str, remaining: List[str]) -> Optional[str]:
    """Recursively find a valid path by trying segment combinations.

    Tries each segment as-is first, then combines adjacent segments with
    hyphens to handle project names containing hyphens.

    Args:
        base: Current base path being constructed
        remaining: List of remaining path segments to process

    Returns:
        Valid path if found, None otherwise
    """
    if not remaining:
        return base if os.path.exists(base) else None

    # Try the first segment as-is
    next_segment = remaining[0]
    with_slash = os.path.join(base, next_segment)

    if os.path.exists(with_slash):
        result = _find_valid_path(with_slash, remaining[1:])
        if result:
            return result

    # Try combining adjacent segments with hyphen
    # This handles cases like "my-cool-project" being split into ["my", "cool", "project"]
    if len(remaining) >= 2:
        combined = remaining[0] + "-" + remaining[1]
        result = _find_valid_path(base, [combined] + remaining[2:])
        if result:
            return result

    return None


def decode_project_path_windows(encoded: str) -> Optional[str]:
    """Decode encoded project path for Windows.

    Windows paths have the format: C-Users-user-project -> C:\\Users\\user\\project

    Args:
        encoded: Encoded path string (e.g., C-Users-user-project)

    Returns:
        Decoded absolute Windows path, or None if decoding fails
    """
    drive_match = re.match(r"^([A-Za-z])-(.*)$", encoded)
    if not drive_match:
        return None

    drive_letter = drive_match.group(1)
    rest = drive_match.group(2)

    # Try simple decode first
    simple = f"{drive_letter}:\\" + rest.replace("-", "\\")
    if os.path.exists(simple):
        return simple

    # Try combinations via filesystem validation
    segments = rest.split("-")
    base = f"{drive_letter}:\\"
    result = _find_valid_path_windows(base, segments)
    if result:
        return result

    # Fallback to simple decode
    return simple


def _find_valid_path_windows(base: str, remaining: List[str]) -> Optional[str]:
    """Recursively find a valid Windows path by trying segment combinations."""
    if not remaining:
        return base if os.path.exists(base) else None

    next_segment = remaining[0]
    with_slash = os.path.join(base, next_segment)

    if os.path.exists(with_slash):
        result = _find_valid_path_windows(with_slash, remaining[1:])
        if result:
            return result

    if len(remaining) >= 2:
        combined = remaining[0] + "-" + remaining[1]
        result = _find_valid_path_windows(base, [combined] + remaining[2:])
        if result:
            return result

    return None


# --- WSL2 utilities (Windows only) ---

_wsl_cache: Optional[Tuple[float, List[str]]] = None
_WSL_CACHE_TTL = 30.0  # seconds


def _get_wsl_distros() -> List[str]:
    """Enumerate installed WSL2 distributions (Windows only).

    Results are cached for 30 seconds to avoid redundant subprocess calls
    when multiple discovery functions run in sequence.

    Returns:
        List of distribution names, or empty list if WSL is not available.
    """
    global _wsl_cache

    if sys.platform != "win32":
        return []

    now = time.time()
    if _wsl_cache is not None:
        cache_time, distros = _wsl_cache
        if now - cache_time < _WSL_CACHE_TTL:
            return distros

    try:
        result = subprocess.run(
            ["wsl.exe", "--list", "--quiet"],
            capture_output=True,
            timeout=10,
        )
        if result.returncode != 0:
            _wsl_cache = (now, [])
            return []

        # wsl.exe outputs UTF-16LE
        output = result.stdout.decode("utf-16-le", errors="ignore").strip()
        distros = [
            name.strip("\x00").strip()
            for name in output.splitlines()
            if name.strip("\x00").strip()
        ]
        _wsl_cache = (now, distros)
        logger.debug("Found WSL distributions", distros=distros)
        return distros
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError) as e:
        logger.debug("WSL not available", error=str(e))
        _wsl_cache = (now, [])
        return []


def _get_wsl_unc_prefix(distro: str) -> Optional[str]:
    """Get the working UNC prefix for a WSL distribution.

    Tries ``\\\\wsl.localhost\\`` first (Windows 11+), falls back to
    ``\\\\wsl$\\`` (Windows 10+).

    Args:
        distro: WSL distribution name

    Returns:
        UNC prefix string or None if the distro is not accessible
    """
    for prefix in [f"\\\\wsl.localhost\\{distro}", f"\\\\wsl$\\{distro}"]:
        try:
            if Path(prefix).exists():
                return prefix
        except OSError:
            continue
    return None


def get_wsl_paths_for_tool(tool_subpath: str) -> List[Path]:
    """Get accessible WSL2 paths for a tool across all distros and users.

    Only active on Windows. Scans all running WSL distributions and their
    user home directories for the given tool path.

    Args:
        tool_subpath: Path relative to user home directory
                      (e.g., ``.claude/projects``, ``.codex/sessions``)

    Returns:
        List of existing Path objects for the tool across WSL distros/users
    """
    if sys.platform != "win32":
        return []

    distros = _get_wsl_distros()
    if not distros:
        return []

    paths: List[Path] = []
    for distro in distros:
        prefix = _get_wsl_unc_prefix(distro)
        if not prefix:
            continue

        # Scan user home directories under /home/
        home_base = Path(prefix) / "home"
        if home_base.exists():
            try:
                for user_dir in home_base.iterdir():
                    if user_dir.is_dir():
                        tool_path = user_dir / tool_subpath
                        if tool_path.exists():
                            paths.append(tool_path)
            except (PermissionError, OSError) as e:
                logger.debug(
                    "Failed to scan WSL home directory",
                    distro=distro,
                    error=str(e),
                )

        # Also check root home
        root_tool_path = Path(prefix) / "root" / tool_subpath
        try:
            if root_tool_path.exists():
                paths.append(root_tool_path)
        except OSError:
            pass

    if paths:
        logger.info(
            "Found WSL2 tool paths",
            tool=tool_subpath,
            count=len(paths),
            paths=[str(p) for p in paths],
        )

    return paths


@dataclass
class ConversationFile:
    """Represents a discovered conversation file."""

    source: str  # "claude", "codex", "cursor", "opencode"
    path: str  # Absolute path to file/database
    session_id: Optional[str] = None
    project: Optional[str] = None
    workspace: Optional[str] = None
    date: Optional[str] = None
    last_modified: float = 0.0
    message_count: Optional[int] = None
    preview: Optional[str] = None  # First few messages for preview
    title: Optional[str] = None  # Session title (e.g., Cursor composer name)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "source": self.source,
            "path": self.path,
            "session_id": self.session_id,
            "project": self.project,
            "workspace": self.workspace,
            "date": self.date,
            "last_modified": self.last_modified,
            "message_count": self.message_count,
            "preview": self.preview,
            "title": self.title,
            "metadata": self.metadata,
        }
