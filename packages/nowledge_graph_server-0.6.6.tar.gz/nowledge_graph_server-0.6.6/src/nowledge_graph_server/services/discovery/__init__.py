"""Conversation discovery module for finding AI agent conversation files.

This module discovers conversation files from:
- Claude Code
- Codex
- Cursor
- OpenCode

The module is split into:
- base: ConversationFile dataclass and path utilities
- claude: Claude Code discovery
- codex: Codex CLI discovery
- cursor: Cursor IDE discovery
- opencode: OpenCode CLI discovery
- service: Main ConversationDiscoveryService that orchestrates all sources
"""

from .base import (
    ConversationFile,
    decode_project_path_enhanced,
    decode_project_path_windows,
)
from .service import ConversationDiscoveryService

__all__ = [
    "ConversationFile",
    "ConversationDiscoveryService",
    "decode_project_path_enhanced",
    "decode_project_path_windows",
]
