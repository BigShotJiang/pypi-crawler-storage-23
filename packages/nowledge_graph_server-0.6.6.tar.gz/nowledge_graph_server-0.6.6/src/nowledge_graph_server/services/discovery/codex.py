"""Codex conversation discovery.

Contains functions for discovering Codex session files from ~/.codex/sessions.
"""

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog

from .base import ConversationFile, get_wsl_paths_for_tool

logger = structlog.get_logger(__name__)


def discover_codex_conversations(
    base_path: Optional[Path] = None,
) -> List[ConversationFile]:
    """Discover Codex conversation files.

    On Windows, also scans WSL2 distributions for Codex installations.

    Args:
        base_path: Optional base path (defaults to ~/.codex/sessions)

    Returns:
        List of discovered conversation files
    """
    scan_wsl = base_path is None and sys.platform == "win32"

    if base_path is None:
        base_path = Path.home() / ".codex" / "sessions"

    conversations: List[ConversationFile] = []

    if base_path.exists() and base_path.is_dir():
        # Walk date-based directory structure: YYYY/MM/DD/
        for year_dir in base_path.iterdir():
            if not year_dir.is_dir() or not year_dir.name.isdigit():
                continue

            for month_dir in year_dir.iterdir():
                if not month_dir.is_dir() or not month_dir.name.isdigit():
                    continue

                for day_dir in month_dir.iterdir():
                    if not day_dir.is_dir() or not day_dir.name.isdigit():
                        continue

                    date_str = f"{year_dir.name}-{month_dir.name}-{day_dir.name}"

                    for jsonl_file in day_dir.glob("rollout-*.jsonl"):
                        try:
                            session_id, workspace, message_count, preview, extra_metadata = (
                                _analyze_codex_file(jsonl_file)
                            )

                            # Build metadata combining date info with git/model info
                            metadata = {
                                "year": year_dir.name,
                                "month": month_dir.name,
                                "day": day_dir.name,
                            }
                            if extra_metadata:
                                metadata.update(extra_metadata)

                            # Extract project name from workspace path
                            project_name = None
                            if workspace and workspace != "/":
                                project_name = os.path.basename(workspace.rstrip("/\\"))

                            conversations.append(
                                ConversationFile(
                                    source="codex",
                                    path=str(jsonl_file),
                                    session_id=session_id,
                                    project=project_name,
                                    workspace=workspace,
                                    date=date_str,
                                    last_modified=jsonl_file.stat().st_mtime,
                                    message_count=message_count,
                                    preview=preview,
                                    metadata=metadata,
                                )
                            )
                        except Exception as e:
                            logger.warning(
                                "Failed to analyze Codex conversation file",
                                file=str(jsonl_file),
                                error=str(e),
                            )
                            continue
    else:
        logger.debug("Codex sessions directory not found", path=str(base_path))

    # Also scan WSL2 distributions on Windows
    if scan_wsl:
        for wsl_path in get_wsl_paths_for_tool(".codex/sessions"):
            try:
                wsl_convos = discover_codex_conversations(wsl_path)
                conversations.extend(wsl_convos)
            except Exception as e:
                logger.warning(
                    "Failed to scan WSL2 Codex path",
                    path=str(wsl_path),
                    error=str(e),
                )

    logger.info(
        "Discovered Codex conversations",
        count=len(conversations),
        base_path=str(base_path),
    )
    return conversations


def _analyze_codex_file(
    jsonl_file: Path,
) -> tuple[Optional[str], Optional[str], int, Optional[str], Optional[dict]]:
    """Analyze Codex JSONL file to extract session info.

    Memory-efficient: Only reads first 100 lines for preview, estimates count from file size.

    Args:
        jsonl_file: Path to the Codex JSONL file

    Returns:
        Tuple of (session_id, workspace, estimated_message_count, preview_text, metadata)
    """
    session_id = None
    workspace = None
    message_count = 0
    preview_parts: List[str] = []
    git_info = None
    model_info = None

    try:
        file_size = jsonl_file.stat().st_size
        line_num = 0

        # Only read first 100 lines for preview (memory-efficient)
        with open(jsonl_file, "r") as f:
            for line_num, line in enumerate(f, 1):
                if line_num > 100:  # Only analyze first 100 lines for preview
                    break

                line = line.strip()
                if not line:
                    continue

                try:
                    record = json.loads(line)
                    record_type = record.get("type")

                    # Extract session metadata
                    if record_type == "session_meta" and not session_id:
                        payload = record.get("payload", {})
                        session_id = payload.get("id")
                        workspace = payload.get("cwd")
                        git_info = payload.get("git")  # Extract git info
                        model_info = payload.get("model")

                    # Count messages in preview
                    if record_type == "event_msg":
                        payload = record.get("payload", {})
                        if payload.get("type") in ["user_message", "agent_message"]:
                            message_count += 1

                            # Extract preview
                            if len(preview_parts) < 3:
                                msg_text = payload.get("message", "")
                                if msg_text:
                                    role = (
                                        "user"
                                        if payload.get("type") == "user_message"
                                        else "assistant"
                                    )
                                    preview_text = msg_text[:100].replace("\n", " ")
                                    if len(msg_text) > 100:
                                        preview_text += "..."
                                    preview_parts.append(f"{role}: {preview_text}")

                except json.JSONDecodeError:
                    continue

        # Estimate total message count from file size
        if message_count > 0 and file_size > 0:
            avg_line_size = file_size / max(1, line_num) if line_num > 0 else 1000
            estimated_total_lines = int(file_size / avg_line_size) if avg_line_size > 0 else 0
            # Estimate messages as ~20% of total lines (Codex has more metadata)
            estimated_messages = max(message_count, int(estimated_total_lines * 0.2))
            message_count = estimated_messages

    except Exception as e:
        logger.warning("Failed to analyze Codex file", file=str(jsonl_file), error=str(e))

    # Extract session ID from filename if not found in content
    if not session_id:
        filename = jsonl_file.stem
        # Format: rollout-{timestamp}-{session_id}
        parts = filename.rsplit("-", 1)
        if len(parts) > 1:
            session_id = parts[1]

    preview = "\n".join(preview_parts) if preview_parts else None

    # Build metadata dict
    metadata: Optional[Dict[str, Any]] = {}
    if git_info:
        metadata["git"] = git_info
    if model_info:
        metadata["model"] = model_info

    return session_id, workspace, message_count, preview, metadata if metadata else None
