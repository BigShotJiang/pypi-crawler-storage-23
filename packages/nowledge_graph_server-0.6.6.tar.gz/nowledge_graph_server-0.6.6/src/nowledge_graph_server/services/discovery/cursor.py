"""Cursor conversation discovery.

Contains functions for discovering Cursor conversations from workspace storage.
"""

import json
import os
import sqlite3
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog

from .base import ConversationFile

logger = structlog.get_logger(__name__)


def _safe_sqlite_connect(db_path: Path, timeout: float = 5.0, max_retries: int = 3) -> Optional[sqlite3.Connection]:
    """Safely connect to SQLite database with timeout and retry logic.

    Cursor's SQLite databases can be locked by the running application.
    This helper adds:
    - Connection timeout to avoid hanging
    - Retry logic with exponential backoff
    - Read-only mode to minimize lock contention

    Args:
        db_path: Path to SQLite database
        timeout: Connection timeout in seconds
        max_retries: Maximum number of retry attempts

    Returns:
        SQLite connection or None if all retries failed
    """
    for attempt in range(max_retries):
        try:
            # Open in read-only mode with timeout
            # URI mode allows ?mode=ro query parameter
            conn = sqlite3.connect(
                f"file:{db_path}?mode=ro",
                timeout=timeout,
                uri=True,
            )
            # Defense-in-depth: ensure we never accidentally write
            conn.execute("PRAGMA query_only = ON")
            return conn
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e).lower() and attempt < max_retries - 1:
                # Exponential backoff: 0.1s, 0.2s, 0.4s
                wait_time = 0.1 * (2 ** attempt)
                logger.debug(
                    "SQLite database locked, retrying",
                    db_path=str(db_path),
                    attempt=attempt + 1,
                    wait_time=wait_time,
                )
                time.sleep(wait_time)
                continue
            else:
                logger.warning(
                    "Failed to connect to SQLite database",
                    db_path=str(db_path),
                    error=str(e),
                    attempts=attempt + 1,
                )
                return None
        except Exception as e:
            logger.warning(
                "Unexpected error connecting to SQLite database",
                db_path=str(db_path),
                error=str(e),
                error_type=type(e).__name__,
            )
            return None

    return None


def discover_cursor_conversations(
    base_path: Optional[Path] = None,
) -> List[ConversationFile]:
    """Discover Cursor conversation databases.

    Uses the same approach as the working import flow:
    1. Check each workspace's ItemTable for composer.composerData
    2. Only include workspaces that have valid composer data
    3. Preview is loaded on-demand when user selects a session

    Args:
        base_path: Optional base path (defaults to platform-specific Cursor storage)

    Returns:
        List of discovered conversation databases
    """
    if base_path is None:
        base_path = _get_cursor_base_path()

    if not base_path or not base_path.exists() or not base_path.is_dir():
        logger.debug("Cursor workspaceStorage directory not found", path=str(base_path) if base_path else "None")
        return []

    conversations: List[ConversationFile] = []

    for workspace_dir in base_path.iterdir():
        if not workspace_dir.is_dir():
            continue

        db_path = workspace_dir / "state.vscdb"
        if not db_path.exists():
            continue

        try:
            # Extract workspace info from workspace.json
            workspace_json = workspace_dir / "workspace.json"
            workspace_info = {}
            workspace_folder = None
            project_name = None

            if workspace_json.exists():
                try:
                    with open(workspace_json, "r") as f:
                        workspace_info = json.load(f)
                        # Extract folder path from workspace.json
                        # Format: {"folder": "file:///Users/weyl/dev/nowledge-mem"}
                        folder_uri = workspace_info.get("folder", "")
                        if folder_uri.startswith("file://"):
                            workspace_folder = folder_uri[7:]  # Remove "file://" prefix
                            project_name = os.path.basename(workspace_folder.rstrip("/\\"))
                except Exception:
                    pass

            # Check if workspace has valid composer data (same approach as import)
            composer_info = _get_cursor_workspace_composer_info(db_path)
            if not composer_info or not composer_info.get("has_conversations"):
                continue

            conversations.append(
                ConversationFile(
                    source="cursor",
                    path=str(db_path),
                    session_id=workspace_dir.name,  # Use workspace hash as session ID
                    project=project_name,  # Extracted project name
                    workspace=workspace_folder,  # Full workspace path
                    last_modified=db_path.stat().st_mtime,
                    message_count=composer_info.get("message_count"),
                    preview=composer_info.get("preview"),  # May be None - loaded on demand
                    title=composer_info.get("title") or project_name,
                    metadata={
                        "workspace_info": workspace_info,
                        "workspace_hash": workspace_dir.name,
                        "composer_count": composer_info.get("composer_count", 0),
                    },
                )
            )
        except Exception as e:
            logger.warning(
                "Failed to analyze Cursor workspace",
                workspace=str(workspace_dir),
                error=str(e),
            )
            continue

    logger.info(
        "Discovered Cursor workspaces",
        count=len(conversations),
        base_path=str(base_path),
    )
    return conversations


def _get_cursor_base_path() -> Optional[Path]:
    """Get Cursor workspace storage base path for current platform.

    Returns:
        Path to Cursor workspaceStorage directory, or None if not determinable
    """
    home = Path.home()

    if sys.platform == "darwin":
        # macOS: ~/Library/Application Support/Cursor/User/workspaceStorage
        return (
            home
            / "Library"
            / "Application Support"
            / "Cursor"
            / "User"
            / "workspaceStorage"
        )
    elif sys.platform == "win32":
        # Windows: %APPDATA%\Cursor\User\workspaceStorage
        appdata = os.environ.get("APPDATA", "")
        if appdata:
            return Path(appdata) / "Cursor" / "User" / "workspaceStorage"
        return None
    else:
        # Linux: ~/.config/Cursor/User/workspaceStorage
        return home / ".config" / "Cursor" / "User" / "workspaceStorage"


def _get_cursor_global_storage_path() -> Optional[Path]:
    """Get Cursor global storage path for current platform.

    Returns:
        Path to Cursor globalStorage/state.vscdb, or None if not determinable
    """
    home = Path.home()

    if sys.platform == "darwin":
        return (
            home
            / "Library"
            / "Application Support"
            / "Cursor"
            / "User"
            / "globalStorage"
            / "state.vscdb"
        )
    elif sys.platform == "win32":
        appdata = os.environ.get("APPDATA", "")
        if appdata:
            return (
                Path(appdata)
                / "Cursor"
                / "User"
                / "globalStorage"
                / "state.vscdb"
            )
        return None
    else:
        return (
            home
            / ".config"
            / "Cursor"
            / "User"
            / "globalStorage"
            / "state.vscdb"
        )


def _get_cursor_workspace_composer_info(db_path: Path) -> Optional[Dict[str, Any]]:
    """Get composer info from a Cursor workspace's state.vscdb.

    This uses the same approach as the working import flow:
    1. Read composer.composerData from workspace's ItemTable
    2. Check if any composers have conversations (local data)
    3. Look up message count and preview from globalStorage

    Args:
        db_path: Path to the workspace's state.vscdb

    Returns:
        Dict with has_conversations, composer_count, message_count, title, preview
        or None if no valid data found
    """
    conn = None
    try:
        conn = _safe_sqlite_connect(db_path)
        if not conn:
            return None

        cursor = conn.cursor()

        # Query composer.composerData from ItemTable (same as import)
        cursor.execute("SELECT value FROM ItemTable WHERE key = 'composer.composerData'")
        row = cursor.fetchone()

        # Close ASAP — we only needed the one row
        conn.close()
        conn = None

        if not row or not row[0]:
            return None

        data = json.loads(row[0]) if isinstance(row[0], str) else row[0]
        all_composers = data.get("allComposers", [])

        if not all_composers:
            return None

        # Count composers with valid IDs and find most recent
        valid_composers = []
        for composer in all_composers:
            if isinstance(composer, dict) and composer.get("composerId"):
                valid_composers.append({
                    "id": composer["composerId"],
                    "name": composer.get("name", ""),
                    "lastUpdatedAt": composer.get("lastUpdatedAt", 0),
                })

        if not valid_composers:
            return None

        # Sort by lastUpdatedAt to get most recent
        valid_composers.sort(key=lambda x: x.get("lastUpdatedAt", 0), reverse=True)
        most_recent = valid_composers[0]

        # Get message count and preview from globalStorage for the most recent composer
        message_count, preview = _get_cursor_composer_info_from_global(most_recent.get("id"))

        return {
            "has_conversations": True,
            "composer_count": len(valid_composers),
            "message_count": message_count,
            "title": most_recent.get("name") or None,
            "preview": preview,
            "composer_id": most_recent.get("id"),
        }

    except Exception as e:
        logger.debug(
            "Failed to get Cursor workspace composer info",
            db_path=str(db_path),
            error=str(e),
        )
        return None
    finally:
        if conn:
            conn.close()


def _get_cursor_composer_info_from_global(
    composer_id: Optional[str],
) -> tuple[Optional[int], Optional[str]]:
    """Get message count and preview for a Cursor composer from globalStorage.

    Args:
        composer_id: The composer ID to look up

    Returns:
        Tuple of (message_count, preview_text), either can be None if not found
    """
    if not composer_id:
        return None, None

    global_db_path = _get_cursor_global_storage_path()
    if not global_db_path or not global_db_path.exists():
        return None, None

    conn = None
    try:
        conn = _safe_sqlite_connect(global_db_path)
        if not conn:
            return None, None

        cursor = conn.cursor()

        cursor.execute(
            "SELECT value FROM cursorDiskKV WHERE key = ?",
            (f"composerData:{composer_id}",),
        )
        row = cursor.fetchone()

        if not row or not row[0]:
            return None, None

        data = json.loads(row[0]) if isinstance(row[0], str) else row[0]
        # Check both fullConversationHeadersOnly and conversation (same as _parse_cursor_vscdb)
        conversation = data.get("fullConversationHeadersOnly", [])
        if not conversation:
            conversation = data.get("conversation", [])

        message_count = len(conversation) if conversation else None

        # Get preview from first few messages
        preview = None
        if conversation:
            preview_parts: List[str] = []
            for item in conversation[:3]:
                if not isinstance(item, dict):
                    continue

                bubble_id = item.get("bubbleId")
                bubble_type = item.get("type")  # 1 = user, 2 = assistant

                if not bubble_id:
                    continue

                # Look up the full bubble data from cursorDiskKV
                cursor.execute(
                    "SELECT value FROM cursorDiskKV WHERE key = ?",
                    (f"bubbleId:{composer_id}:{bubble_id}",),
                )
                bubble_row = cursor.fetchone()

                if bubble_row and bubble_row[0]:
                    try:
                        bubble_data = json.loads(bubble_row[0]) if isinstance(bubble_row[0], str) else bubble_row[0]
                        text = (
                            bubble_data.get("text")
                            or bubble_data.get("rawText")
                            or bubble_data.get("content")
                            or ""
                        )
                        if text and isinstance(text, str) and text.strip():
                            role = "user" if bubble_type == 1 else "assistant"
                            preview_text = text[:100].replace("\n", " ")
                            if len(text) > 100:
                                preview_text += "..."
                            preview_parts.append(f"{role}: {preview_text}")
                    except (json.JSONDecodeError, TypeError):
                        continue

            if preview_parts:
                preview = "\n".join(preview_parts)

        return message_count, preview

    except Exception as e:
        logger.debug(
            "Failed to get Cursor composer info from global",
            composer_id=composer_id[:20] if composer_id else "N/A",
            error=str(e),
        )
        return None, None
    finally:
        if conn:
            conn.close()


def load_cursor_composer_cache() -> List[Dict[str, Any]]:
    """Load all Cursor composer data from global storage once.

    Returns a list of composer data dicts with conversation, sorted by lastUpdatedAt.
    This is cached to avoid repeated database queries.

    Returns:
        List of composer data dictionaries
    """
    global_db_path = _get_cursor_global_storage_path()
    if not global_db_path or not global_db_path.exists():
        logger.debug("Cursor global storage not found", path=str(global_db_path) if global_db_path else "None")
        return []

    composers: List[Dict[str, Any]] = []
    conn = None
    try:
        conn = _safe_sqlite_connect(global_db_path)
        if not conn:
            logger.debug("Could not connect to Cursor global storage")
            return []

        cursor = conn.cursor()

        # Get all composer data keys - don't use json_extract as it may not be available
        cursor.execute(
            """
            SELECT value FROM cursorDiskKV
            WHERE key LIKE 'composerData:%'
            """
        )

        raw_rows = cursor.fetchall()

        # Close ASAP — all data fetched
        conn.close()
        conn = None

        logger.debug("Found Cursor composer keys", count=len(raw_rows))

        # Parse JSON in Python and filter/sort
        for row in raw_rows:
            try:
                data = json.loads(row[0])
                conversation = data.get("conversation", [])
                # Only include composers with actual conversation
                if conversation and len(conversation) > 0:
                    # Extract key info to reduce memory usage
                    composers.append({
                        "name": data.get("name", ""),
                        "conversation": conversation[:10],  # Only first 10 messages for preview
                        "message_count": len(conversation),
                        "context": data.get("context", {}),
                        "lastUpdatedAt": data.get("lastUpdatedAt", 0),
                    })
            except (json.JSONDecodeError, KeyError) as e:
                logger.debug("Failed to parse composer data", error=str(e))
                continue

        # Sort by lastUpdatedAt descending in Python
        composers.sort(key=lambda x: x.get("lastUpdatedAt", 0), reverse=True)

        # Limit to 200 most recent
        composers = composers[:200]

        logger.debug("Loaded Cursor composer cache", count=len(composers))

    except Exception as e:
        logger.warning("Failed to load Cursor composer cache", error=str(e))
    finally:
        if conn:
            conn.close()

    return composers


def get_cursor_preview_from_cache(
    composer_cache: List[Dict[str, Any]],
    workspace_folder: Optional[str] = None,
) -> tuple[Optional[str], Optional[str], Optional[int]]:
    """Get preview, title, and message count from cached composer data.

    Tries to find a composer matching the workspace folder.
    Falls back to most recent composer if no match found.

    Args:
        composer_cache: List of cached composer data
        workspace_folder: Optional workspace folder path to match

    Returns:
        Tuple of (preview_text, title, message_count)
    """
    if not composer_cache:
        return None, None, None

    best_composer = None
    best_match_score = 0

    for composer in composer_cache:
        conversation = composer.get("conversation", [])
        if not conversation:
            continue

        match_score = 0

        # Check if any file selections match the workspace folder
        if workspace_folder:
            context = composer.get("context", {})
            file_selections = context.get("fileSelections", [])
            for fs in file_selections:
                uri = fs.get("uri", "")
                if workspace_folder in uri:
                    match_score += 10
                    break

            # Check first few message contexts for file references
            for item in conversation[:3]:
                item_context = item.get("context", {})
                item_files = item_context.get("fileSelections", [])
                for fs in item_files:
                    uri = fs.get("uri", "")
                    if workspace_folder in uri:
                        match_score += 5
                        break
                if match_score >= 5:
                    break

        # Small score for having more messages
        match_score += min(composer.get("message_count", 0) / 1000, 0.5)

        if match_score > best_match_score:
            best_match_score = match_score
            best_composer = composer
            # If good match found, stop early
            if match_score >= 10:
                break

    # If no match found with workspace, use most recent composer
    if not best_composer and composer_cache:
        best_composer = composer_cache[0]  # Already sorted by lastUpdatedAt

    if not best_composer:
        return None, None, None

    title = best_composer.get("name", "")
    message_count = best_composer.get("message_count", 0)
    conversation = best_composer.get("conversation", [])

    # Generate preview text
    preview_parts: List[str] = []
    for item in conversation[:5]:
        item_type = item.get("type", 0)
        role = "user" if item_type == 1 else "assistant"
        text = item.get("text", "")
        if text:
            preview_text = text[:100].replace("\n", " ")
            if len(text) > 100:
                preview_text += "..."
            preview_parts.append(f"{role}: {preview_text}")
            if len(preview_parts) >= 3:
                break

    preview = "\n".join(preview_parts) if preview_parts else None
    return preview, title, message_count
