"""Claude Code conversation discovery.

Discovers Claude Code CLI session files from ~/.claude/projects/
"""

import json
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import structlog

from .base import (
    ConversationFile,
    decode_project_path_enhanced,
    decode_project_path_windows,
    get_wsl_paths_for_tool,
)

logger = structlog.get_logger(__name__)


def discover_claude_conversations(
    base_path: Optional[Path] = None,
) -> List[ConversationFile]:
    """Discover Claude Code conversation files.

    On Windows, also scans WSL2 distributions for Claude Code installations.

    Args:
        base_path: Optional base path (defaults to ~/.claude/projects)

    Returns:
        List of discovered conversation files
    """
    scan_wsl = base_path is None and sys.platform == "win32"

    if base_path is None:
        base_path = Path.home() / ".claude" / "projects"

    conversations: List[ConversationFile] = []

    if base_path.exists() and base_path.is_dir():
        for project_dir in base_path.iterdir():
            if not project_dir.is_dir():
                continue

            # Decode project path from directory name using enhanced decoding
            encoded_name = project_dir.name
            decoded_path = None

            if sys.platform == "win32":
                decoded_path = decode_project_path_windows(encoded_name)
                if decoded_path is None:
                    # Linux-style path (e.g., from WSL2 installation)
                    decoded_path = decode_project_path_enhanced(encoded_name)
            else:
                decoded_path = decode_project_path_enhanced(encoded_name)

            for jsonl_file in project_dir.glob("*.jsonl"):
                try:
                    session_id = _extract_session_id(jsonl_file)
                    message_count, preview, extra_metadata = _analyze_file(jsonl_file)

                    project_name = None
                    if decoded_path:
                        project_name = os.path.basename(decoded_path.rstrip("/\\"))

                    metadata = {
                        "encoded_project_name": encoded_name,
                        "decoded_project_path": decoded_path,
                    }
                    if extra_metadata:
                        metadata.update(extra_metadata)

                    conversations.append(
                        ConversationFile(
                            source="claude",
                            path=str(jsonl_file),
                            session_id=session_id,
                            project=project_name,
                            workspace=decoded_path,
                            last_modified=jsonl_file.stat().st_mtime,
                            message_count=message_count,
                            preview=preview,
                            metadata=metadata,
                        )
                    )
                except Exception as e:
                    logger.warning(
                        "Failed to analyze Claude conversation file",
                        file=str(jsonl_file),
                        error=str(e),
                    )
                    continue
    else:
        logger.debug("Claude Code projects directory not found", path=str(base_path))

    # Also scan WSL2 distributions on Windows
    if scan_wsl:
        for wsl_path in get_wsl_paths_for_tool(".claude/projects"):
            try:
                wsl_convos = discover_claude_conversations(wsl_path)
                conversations.extend(wsl_convos)
            except Exception as e:
                logger.warning(
                    "Failed to scan WSL2 Claude path",
                    path=str(wsl_path),
                    error=str(e),
                )

    logger.info(
        "Discovered Claude Code conversations",
        count=len(conversations),
        base_path=str(base_path),
    )
    return conversations


def _extract_session_id(jsonl_file: Path) -> Optional[str]:
    """Extract session ID from Claude Code JSONL file."""
    session_id = None
    try:
        with open(jsonl_file, "r") as f:
            first_line = f.readline().strip()
            if first_line:
                event = json.loads(first_line)
                session_id = event.get("sessionId")
    except Exception:
        pass

    # Fallback: use filename stem if sessionId not found in file
    if not session_id:
        stem = jsonl_file.stem
        if stem.startswith("agent-"):
            session_id = stem[6:]
        else:
            session_id = stem

    return session_id


def _analyze_file(
    jsonl_file: Path,
) -> Tuple[int, Optional[str], Optional[Dict]]:
    """Analyze Claude Code JSONL file to estimate message count and extract preview.

    Memory-efficient: Only reads first 50 lines for preview, estimates count from file size.

    Returns:
        Tuple of (estimated_message_count, preview_text, metadata)
    """
    message_count = 0
    preview_parts: List[str] = []
    git_branch: Optional[str] = None
    model: Optional[str] = None
    line_num = 0

    try:
        file_size = jsonl_file.stat().st_size

        with open(jsonl_file, "r") as f:
            for line_num, line in enumerate(f, 1):
                if line_num > 50:
                    break

                line = line.strip()
                if not line:
                    continue

                try:
                    event = json.loads(line)
                    event_type = event.get("type")

                    if event_type in ["file-history-snapshot", "summary"]:
                        continue

                    if not git_branch:
                        git_branch = event.get("gitBranch")

                    if not model and event_type == "assistant":
                        msg_data = event.get("message", {})
                        model = msg_data.get("model")

                    if event_type in ["user", "assistant"]:
                        message_count += 1

                        if len(preview_parts) < 3:
                            msg_data = event.get("message", {})
                            content = msg_data.get("content", "")

                            if isinstance(content, list):
                                text_parts = [
                                    item.get("text", "")
                                    for item in content
                                    if isinstance(item, dict) and item.get("type") == "text"
                                ]
                                content = "\n".join(text_parts)

                            if content and content.strip():
                                role = event_type
                                preview_text = content[:100].replace("\n", " ")
                                if len(content) > 100:
                                    preview_text += "..."
                                preview_parts.append(f"{role}: {preview_text}")

                except json.JSONDecodeError:
                    continue

        # Estimate total message count from file size
        if message_count > 0 and file_size > 0:
            avg_line_size = file_size / max(1, line_num) if line_num > 0 else 1000
            estimated_total_lines = int(file_size / avg_line_size) if avg_line_size > 0 else 0
            estimated_messages = max(message_count, int(estimated_total_lines * 0.3))
            message_count = estimated_messages

    except Exception as e:
        logger.warning("Failed to analyze Claude file", file=str(jsonl_file), error=str(e))

    preview = "\n".join(preview_parts) if preview_parts else None

    metadata: Optional[Dict] = None
    if git_branch or model:
        metadata = {}
        if git_branch:
            metadata["git"] = {"branch": git_branch}
        if model:
            metadata["model"] = model

    return message_count, preview, metadata
