"""OpenCode conversation discovery.

Contains functions for discovering OpenCode session files (cross-platform).
Supports both legacy JSON files and the new SQLite database format.
"""

import json
import os
import sqlite3
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog

from .base import ConversationFile, get_wsl_paths_for_tool

logger = structlog.get_logger(__name__)


def discover_opencode_conversations(
    base_path: Optional[Path] = None,
) -> List[ConversationFile]:
    """Discover OpenCode session files (cross-platform).

    Supports two storage formats:
    - SQLite database: ~/.local/share/opencode/opencode.db (new, v2025+)
    - JSON files: ~/.local/share/opencode/storage/ (legacy)

    On Windows, also scans WSL2 distributions for OpenCode installations.

    Args:
        base_path: Optional base path (defaults to platform-specific location)

    Returns:
        List of discovered conversation files
    """
    scan_wsl = base_path is None and sys.platform == "win32"

    if base_path is None:
        base_path = _get_opencode_base_path()

    conversations: List[ConversationFile] = []
    seen_session_ids: set = set()

    # 1. Try SQLite database first (new format takes priority)
    if base_path:
        db_path = _get_opencode_db_path(base_path)
        if db_path and db_path.exists():
            sqlite_convos = _discover_from_sqlite(db_path)
            for conv in sqlite_convos:
                if conv.session_id:
                    seen_session_ids.add(conv.session_id)
                conversations.append(conv)

    # 2. Fall back to JSON files (legacy format)
    if base_path and base_path.exists():
        json_convos = _discover_from_json(base_path)
        for conv in json_convos:
            # Deduplicate: skip if already found in SQLite
            if conv.session_id and conv.session_id in seen_session_ids:
                continue
            conversations.append(conv)

    # Also scan WSL2 distributions on Windows
    if scan_wsl:
        for wsl_path in get_wsl_paths_for_tool(".local/share/opencode"):
            try:
                # WSL paths point to the opencode root dir
                wsl_convos = discover_opencode_conversations(wsl_path)
                conversations.extend(wsl_convos)
            except Exception as e:
                logger.warning(
                    "Failed to scan WSL2 OpenCode path",
                    path=str(wsl_path),
                    error=str(e),
                )

    logger.info(
        "Discovered OpenCode conversations",
        count=len(conversations),
        base_path=str(base_path),
    )
    return conversations


def _get_opencode_base_path() -> Optional[Path]:
    """Get OpenCode data base path for current platform.

    Returns:
        Path to OpenCode data directory (~/.local/share/opencode/),
        or None if not determinable
    """
    home = Path.home()

    if sys.platform == "darwin":
        return home / ".local" / "share" / "opencode"
    elif sys.platform == "win32":
        return home / ".local" / "share" / "opencode"
    else:
        # Linux: $XDG_DATA_HOME/opencode/ or ~/.local/share/opencode/
        xdg_data = os.environ.get("XDG_DATA_HOME")
        if xdg_data:
            return Path(xdg_data) / "opencode"
        return home / ".local" / "share" / "opencode"


def _get_opencode_db_path(base_path: Path) -> Optional[Path]:
    """Get path to OpenCode's SQLite database.

    Args:
        base_path: OpenCode data directory

    Returns:
        Path to opencode.db, or None
    """
    # base_path is ~/.local/share/opencode/ or ~/.local/share/opencode/storage/
    # Handle both cases for backward compatibility
    db_path = base_path / "opencode.db"
    if db_path.exists():
        return db_path

    # If base_path is the storage/ subdir, check parent
    parent_db = base_path.parent / "opencode.db"
    if base_path.name == "storage" and parent_db.exists():
        return parent_db

    return None


def _safe_sqlite_connect(db_path: Path) -> Optional[sqlite3.Connection]:
    """Safely connect to SQLite database in read-only mode with retry.

    Args:
        db_path: Path to SQLite database

    Returns:
        Connection or None on failure
    """
    max_retries = 3
    delays = [0.1, 0.2, 0.4]

    for attempt in range(max_retries):
        try:
            conn = sqlite3.connect(
                f"file:{db_path}?mode=ro",
                timeout=5,
                uri=True,
            )
            conn.row_factory = sqlite3.Row
            return conn
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e) and attempt < max_retries - 1:
                time.sleep(delays[attempt])
                continue
            logger.warning(
                "Failed to connect to OpenCode SQLite database",
                db_path=str(db_path),
                error=str(e),
                attempt=attempt + 1,
            )
            return None
        except Exception as e:
            logger.warning(
                "Unexpected error connecting to OpenCode database",
                db_path=str(db_path),
                error=str(e),
            )
            return None

    return None


def _discover_from_sqlite(db_path: Path) -> List[ConversationFile]:
    """Discover sessions from OpenCode's SQLite database.

    Args:
        db_path: Path to opencode.db

    Returns:
        List of discovered conversation files
    """
    conn = _safe_sqlite_connect(db_path)
    if not conn:
        return []

    conversations: List[ConversationFile] = []

    try:
        cursor = conn.cursor()

        # Check if session table exists (might be an old or different DB)
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='session'"
        )
        if not cursor.fetchone():
            logger.debug("No session table in OpenCode database", db_path=str(db_path))
            return []

        # Query sessions with message counts
        cursor.execute("""
            SELECT
                s.id,
                s.project_id,
                s.directory,
                s.title,
                s.version,
                s.time_created,
                s.time_updated,
                s.parent_id,
                (SELECT COUNT(*) FROM message m WHERE m.session_id = s.id) as message_count
            FROM session s
            WHERE s.time_archived IS NULL
            ORDER BY s.time_updated DESC
        """)

        # Load project names for display
        project_names: Dict[str, str] = {}
        try:
            cursor_projects = conn.cursor()
            cursor_projects.execute("SELECT id, name, worktree FROM project")
            for row in cursor_projects.fetchall():
                project_names[row["id"]] = row["name"] or os.path.basename(
                    (row["worktree"] or "").rstrip("/\\")
                )
        except Exception:
            pass

        for row in cursor.fetchall():
            try:
                session_id = row["id"]
                directory = row["directory"] or ""
                title = row["title"] or ""
                project_id = row["project_id"] or ""
                message_count = row["message_count"] or 0
                time_created = row["time_created"] or 0
                time_updated = row["time_updated"] or time_created

                # Extract project name
                project_name = project_names.get(
                    project_id,
                    os.path.basename(directory.rstrip("/\\")) if directory else project_id,
                )

                # Handle default titles
                display_title = None if _is_default_opencode_title(title) else title

                # Encode project path
                project_encoded = _encode_project_path(directory)

                # Get preview from first message
                preview = _get_preview_from_sqlite(conn, session_id)

                conversations.append(
                    ConversationFile(
                        source="opencode",
                        path=str(db_path),
                        session_id=session_id,
                        project=project_name,
                        workspace=directory,
                        title=display_title,
                        last_modified=time_updated / 1000,  # ms to seconds
                        message_count=message_count,
                        preview=preview,
                        metadata={
                            "project_id": project_id,
                            "version": row["version"],
                            "project_encoded": project_encoded,
                            "storage": "sqlite",
                        },
                    )
                )
            except Exception as e:
                logger.warning(
                    "Failed to process OpenCode SQLite session",
                    session_id=row["id"] if row else "unknown",
                    error=str(e),
                )
                continue

        logger.info(
            "Discovered OpenCode sessions from SQLite",
            count=len(conversations),
            db_path=str(db_path),
        )

    except Exception as e:
        logger.warning(
            "Failed to query OpenCode SQLite database",
            db_path=str(db_path),
            error=str(e),
        )
    finally:
        conn.close()

    return conversations


def _get_preview_from_sqlite(
    conn: sqlite3.Connection, session_id: str
) -> Optional[str]:
    """Get preview text from first few messages in SQLite.

    Args:
        conn: SQLite connection
        session_id: Session ID

    Returns:
        Preview text or None
    """
    try:
        cursor = conn.cursor()

        # Get first 3 messages (oldest first)
        cursor.execute(
            """
            SELECT m.id, m.data
            FROM message m
            WHERE m.session_id = ?
            ORDER BY m.time_created ASC
            LIMIT 3
            """,
            (session_id,),
        )

        preview_parts: List[str] = []

        for msg_row in cursor.fetchall():
            try:
                msg_data = json.loads(msg_row["data"]) if isinstance(msg_row["data"], str) else msg_row["data"]
                role = msg_data.get("role", "user")
                msg_id = msg_row["id"]

                # Get text parts for this message
                part_cursor = conn.cursor()
                part_cursor.execute(
                    """
                    SELECT data FROM part
                    WHERE message_id = ?
                    ORDER BY id ASC
                    """,
                    (msg_id,),
                )

                for part_row in part_cursor.fetchall():
                    try:
                        part_data = json.loads(part_row["data"]) if isinstance(part_row["data"], str) else part_row["data"]
                        if part_data.get("type") == "text" and not part_data.get("ignored"):
                            text = part_data.get("text", "")[:100].replace("\n", " ")
                            if text:
                                if len(part_data.get("text", "")) > 100:
                                    text += "..."
                                preview_parts.append(f"{role}: {text}")
                                break
                    except Exception:
                        continue
            except Exception:
                continue

        return "\n".join(preview_parts) if preview_parts else None

    except Exception:
        return None


def _discover_from_json(base_path: Path) -> List[ConversationFile]:
    """Discover sessions from legacy JSON files.

    Args:
        base_path: OpenCode data directory (may be the root or storage/ subdir)

    Returns:
        List of discovered conversation files
    """
    conversations: List[ConversationFile] = []

    # Determine the storage path
    storage_path = base_path
    if not (storage_path / "session").exists():
        storage_path = base_path / "storage"

    session_path = storage_path / "session"
    if not session_path.exists():
        return []

    # Walk project directories: session/{projectID}/{sessionID}.json
    for project_dir in session_path.iterdir():
        if not project_dir.is_dir():
            continue

        project_id = project_dir.name

        for session_file in project_dir.glob("*.json"):
            try:
                session_data = json.loads(session_file.read_text(encoding="utf-8"))

                session_id = session_data.get("id", session_file.stem)
                title = session_data.get("title", "")
                directory = session_data.get("directory", "")
                time_info = session_data.get("time", {})

                # Count messages
                message_path = storage_path / "message" / session_id
                message_count = (
                    len(list(message_path.glob("*.json")))
                    if message_path.exists()
                    else 0
                )

                # Get preview from first message
                preview = _get_opencode_preview(storage_path, session_id)

                # Extract project name from directory
                project_name = (
                    os.path.basename(directory.rstrip("/\\"))
                    if directory
                    else project_id
                )

                # Handle default/auto-generated titles
                display_title = None if _is_default_opencode_title(title) else title

                # Encode the project path for frontend compatibility
                project_encoded = _encode_project_path(directory)

                conversations.append(
                    ConversationFile(
                        source="opencode",
                        path=str(session_file),
                        session_id=session_id,
                        project=project_name,
                        workspace=directory,
                        title=display_title,
                        last_modified=time_info.get(
                            "updated", time_info.get("created", 0)
                        )
                        / 1000,  # ms to seconds
                        message_count=message_count,
                        preview=preview,
                        metadata={
                            "project_id": project_id,
                            "version": session_data.get("version"),
                            "project_encoded": project_encoded,
                            "storage": "json",
                        },
                    )
                )
            except Exception as e:
                logger.warning(
                    "Failed to analyze OpenCode session",
                    file=str(session_file),
                    error=str(e),
                )
                continue

    return conversations


def _is_default_opencode_title(title: str) -> bool:
    """Check if title is auto-generated default."""
    if not title:
        return True
    return title.startswith("New session - ") or title.startswith("Child session - ")


def _encode_project_path(directory: str) -> Optional[str]:
    """Encode project path for frontend compatibility.

    Encodes paths like Claude Code does:
    - Unix: /Users/weyl/project -> -Users-weyl-project
    - Windows: C:\\Users\\user\\project -> C-Users-user-project
    """
    if not directory:
        return None

    if sys.platform == "win32":
        norm_path = directory.replace("\\", "/")
        if len(norm_path) >= 2 and norm_path[1] == ":":
            return norm_path[0] + norm_path[2:].replace("/", "-")
    else:
        if directory.startswith("/"):
            return "-" + directory[1:].replace("/", "-")

    return None


def _get_opencode_preview(base_path: Path, session_id: str) -> Optional[str]:
    """Get preview text from first few messages (legacy JSON format)."""
    message_path = base_path / "message" / session_id
    if not message_path.exists():
        return None

    msg_files = sorted(message_path.glob("*.json"))
    preview_parts: List[str] = []

    for msg_file in msg_files[:3]:
        try:
            msg_data = json.loads(msg_file.read_text(encoding="utf-8"))
            role = msg_data.get("role", "user")
            msg_id = msg_data.get("id", msg_file.stem)

            part_path = base_path / "part" / msg_id
            if part_path.exists():
                for part_file in sorted(part_path.glob("*.json")):
                    try:
                        part_data = json.loads(part_file.read_text(encoding="utf-8"))
                        if part_data.get("type") == "text" and not part_data.get(
                            "ignored"
                        ):
                            text = part_data.get("text", "")[:100].replace("\n", " ")
                            if text:
                                if len(part_data.get("text", "")) > 100:
                                    text += "..."
                                preview_parts.append(f"{role}: {text}")
                                break
                    except Exception:
                        continue
        except Exception:
            continue

    return "\n".join(preview_parts) if preview_parts else None
