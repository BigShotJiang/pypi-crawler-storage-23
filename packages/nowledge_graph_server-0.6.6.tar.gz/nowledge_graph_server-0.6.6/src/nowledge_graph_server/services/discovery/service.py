"""Conversation discovery service.

Main service class that coordinates discovery across all sources.
"""

from pathlib import Path
from typing import Dict, List, Optional

import structlog

from .base import ConversationFile
from .claude import discover_claude_conversations
from .codex import discover_codex_conversations
from .cursor import discover_cursor_conversations, load_cursor_composer_cache, get_cursor_preview_from_cache
from .opencode import discover_opencode_conversations

logger = structlog.get_logger(__name__)


class ConversationDiscoveryService:
    """Service for discovering conversation files from AI coding assistants.

    Supports:
    - Claude Code (~/.claude/projects)
    - Codex (~/.codex/sessions)
    - Cursor (platform-specific workspace storage)
    - OpenCode (~/.local/share/opencode/storage)
    """

    def __init__(self):
        """Initialize the discovery service."""
        pass

    def discover_claude_conversations(
        self, base_path: Optional[Path] = None
    ) -> List[ConversationFile]:
        """Discover Claude Code conversation files.

        Args:
            base_path: Optional base path (defaults to ~/.claude/projects)

        Returns:
            List of discovered conversation files
        """
        return discover_claude_conversations(base_path)

    def discover_codex_conversations(
        self, base_path: Optional[Path] = None
    ) -> List[ConversationFile]:
        """Discover Codex conversation files.

        Args:
            base_path: Optional base path (defaults to ~/.codex/sessions)

        Returns:
            List of discovered conversation files
        """
        return discover_codex_conversations(base_path)

    def discover_cursor_conversations(
        self, base_path: Optional[Path] = None
    ) -> List[ConversationFile]:
        """Discover Cursor conversation databases.

        Args:
            base_path: Optional base path (defaults to platform-specific Cursor storage)

        Returns:
            List of discovered conversation databases
        """
        return discover_cursor_conversations(base_path)

    def discover_opencode_conversations(
        self, base_path: Optional[Path] = None
    ) -> List[ConversationFile]:
        """Discover OpenCode session files (cross-platform).

        Args:
            base_path: Optional base path (defaults to platform-specific location)

        Returns:
            List of discovered conversation files
        """
        return discover_opencode_conversations(base_path)

    def discover_all(self) -> Dict[str, List[ConversationFile]]:
        """Discover all conversation files from all sources.

        Returns:
            Dictionary mapping source names to lists of conversation files
        """
        return {
            "claude": self.discover_claude_conversations(),
            "codex": self.discover_codex_conversations(),
            "cursor": self.discover_cursor_conversations(),
            "opencode": self.discover_opencode_conversations(),
        }

    # Cursor-specific utilities exposed for backward compatibility
    def _load_cursor_composer_cache(self) -> List[Dict]:
        """Load all Cursor composer data from global storage once.

        Returns a list of composer data dicts with conversation, sorted by lastUpdatedAt.
        """
        return load_cursor_composer_cache()

    def _get_cursor_preview_from_cache(
        self,
        composer_cache: List[Dict],
        workspace_folder: Optional[str] = None,
    ) -> tuple[Optional[str], Optional[str], Optional[int]]:
        """Get preview, title, and message count from cached composer data.

        Args:
            composer_cache: List of cached composer data
            workspace_folder: Optional workspace folder path to match

        Returns:
            Tuple of (preview_text, title, message_count)
        """
        return get_cursor_preview_from_cache(composer_cache, workspace_folder)
