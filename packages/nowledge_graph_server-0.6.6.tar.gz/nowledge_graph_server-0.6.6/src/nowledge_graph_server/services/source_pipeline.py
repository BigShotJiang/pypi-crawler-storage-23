"""Source ingestion pipeline — orchestrates the full lifecycle.

Ingest → Parse → Chunk → Index → (Agent Extraction later)

Each stage transitions the source's lifecycle_state and emits feed events.
Errors are caught per-stage to allow partial progress.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog

from nowledge_graph_server.models.graph import SourceNode
from nowledge_graph_server.services.source_storage import (
    SourceStorageService,
    sha256_bytes,
)
from nowledge_graph_server.services.source_parser import (
    detect_mime_type,
    fetch_url_file,
    fetch_url_html,
    is_pdf_mime_type,
    is_probable_pdf_url,
    looks_like_pdf_bytes,
    parse_file,
    parse_html,
)
from nowledge_graph_server.services.source_chunker import chunk_source, SourceChunk
from nowledge_graph_server.utils.progress_logger import log_data_change

logger = structlog.get_logger(__name__)


class SourcePipeline:
    """Orchestrates source ingestion: ingest → parse → chunk → index."""

    def __init__(
        self,
        db_client: Any,  # KuzuClient
        storage: Optional[SourceStorageService] = None,
    ):
        self.db = db_client
        self.storage = storage or SourceStorageService()

    async def ingest_file(
        self,
        file_path: Path,
        user_comment: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> SourceNode:
        """Full pipeline for a dropped/uploaded file.

        Returns the created SourceNode (lifecycle_state will reflect
        how far processing got).
        """
        # Step 1: Ingest (copy to storage, compute hash)
        info = self.storage.ingest_file(file_path, metadata=metadata)
        source_id = info["source_id"]
        mime_type = detect_mime_type(file_path)

        # Check for duplicate by SHA-256
        existing = await self.db.source_repo.get_source_by_sha256(info["sha256"])
        if existing:
            logger.info("Duplicate source detected", sha256=info["sha256"], existing_id=existing.id)
            return existing

        # Check for revision by filename
        previous_versions = await self.db.source_repo.find_by_name(file_path.name)

        now = datetime.now(timezone.utc)
        version = (previous_versions[0].version + 1) if previous_versions else 1

        source = SourceNode(
            id=source_id,
            source_type="file",
            original_name=file_path.name,
            mime_type=mime_type,
            file_path=info["file_path"],
            sha256=info["sha256"],
            size_bytes=info["size_bytes"],
            version=version,
            lifecycle_state="ingested",
            created_at=now,
            updated_at=now,
            metadata=metadata or {},
        )

        source = await self.db.source_repo.create_source(source)

        # Link as revision if previous versions exist
        if previous_versions:
            older = previous_versions[0]
            await self.db.source_repo.create_revised_as(
                newer_source_id=source.id,
                older_source_id=older.id,
                revision_type="update",
                detected_by="filename_match",
            )
            logger.info(
                "Linked as revision",
                source_id=source.id,
                older_id=older.id,
                version=version,
            )

        # Step 2: Parse
        log_data_change("source_stage", "source", source.id, {"stage": "parsing", "name": source.original_name})
        source = await self._parse(source)
        if source.lifecycle_state == "error":
            return source

        # Step 3: Chunk
        log_data_change("source_stage", "source", source.id, {"stage": "chunking", "name": source.original_name})
        source = await self._chunk(source)
        if source.lifecycle_state == "error":
            return source

        # Step 4: Index
        log_data_change("source_stage", "source", source.id, {"stage": "indexing", "name": source.original_name})
        source = await self._index(source)

        logger.info(
            "File ingestion complete",
            source_id=source.id,
            state=source.lifecycle_state,
            chunks=source.chunk_count,
        )
        return source

    async def ingest_url(
        self,
        url: str,
        user_comment: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> SourceNode:
        """Full pipeline for a pasted URL.

        The returned SourceNode's metadata includes ``fetch_method``
        (``"browse_now"``, ``"httpx"``, or ``"httpx_file"``) so callers
        can surface which fetch strategy was used to the user.
        """
        # Direct file URL (e.g. .pdf): fetch as bytes and parse via file pipeline
        if is_probable_pdf_url(url):
            try:
                content, mime_type, filename, fetch_method = await fetch_url_file(url)
                if self._is_pdf_payload(mime_type, content):
                    return await self._ingest_url_file_content(
                        url=url,
                        file_content=content,
                        mime_type=mime_type,
                        filename=filename,
                        fetch_method=fetch_method,
                        metadata=metadata,
                    )
                logger.info(
                    "URL looked like PDF but payload was not PDF; falling back to HTML ingestion",
                    url=url,
                    mime_type=mime_type,
                )
            except Exception as e:
                logger.warning(
                    "PDF URL fetch failed; falling back to HTML ingestion",
                    url=url,
                    error=str(e),
                )

        # Step 1: Fetch
        try:
            html_content, page_title, fetch_method = await fetch_url_html(url)
        except Exception as e:
            logger.error("Failed to fetch URL", url=url, error=str(e))
            raise

        content_hash = sha256_bytes(html_content.encode("utf-8"))

        # Dedup check
        existing = await self.db.source_repo.get_source_by_sha256(content_hash)
        if existing:
            logger.info("Duplicate URL content", url=url, existing_id=existing.id)
            # Carry fetch_method on duplicate too so callers can still read it
            if existing.metadata is None:
                existing.metadata = {}
            existing.metadata["fetch_method"] = fetch_method
            await self._update_source_fields(existing.id, metadata=existing.metadata)
            return existing

        # Merge fetch_method into metadata persisted with the source
        merged_meta: Dict[str, Any] = {"url": url, "fetch_method": fetch_method, **(metadata or {})}

        # Ingest to storage
        info = self.storage.ingest_url(url, html_content, title=page_title, metadata=merged_meta)
        source_id = info["source_id"]
        now = datetime.now(timezone.utc)

        source = SourceNode(
            id=source_id,
            source_type="url",
            original_name=page_title or url,
            mime_type="text/html",
            source_url=url,
            sha256=content_hash,
            size_bytes=info["size_bytes"],
            version=1,
            lifecycle_state="ingested",
            created_at=now,
            updated_at=now,
            metadata=merged_meta,
        )

        source = await self.db.source_repo.create_source(source)

        # Parse HTML → markdown
        try:
            parsed_md, title, section_tree = parse_html(html_content, title=page_title)

            from nowledge_graph_server.services.source_storage import _safe_filename
            stem = _safe_filename(page_title or url)
            parsed_path = self.storage.write_parsed(source_id, parsed_md, stem=stem)

            source.parsed_path = str(parsed_path)
            source.summary = parsed_md[:500] if parsed_md else ""
            source.section_tree = section_tree
            source.lifecycle_state = "parsed"

            await self.db.source_repo.update_lifecycle_state(
                source_id,
                "parsed",
                parsed_path=str(parsed_path),
                summary=source.summary[:500] if source.summary else "",
                section_tree=section_tree or "",
            )

        except Exception as e:
            logger.error("Failed to parse URL content", source_id=source_id, error=str(e))
            await self.db.source_repo.update_lifecycle_state(
                source_id, "error", error_message=str(e)
            )
            source.lifecycle_state = "error"
            source.error_message = str(e)
            return source

        # Chunk and index
        source = await self._chunk(source)
        if source.lifecycle_state != "error":
            source = await self._index(source)

        return source

    async def refetch_url(self, source_id: str, url: str) -> SourceNode:
        """Re-fetch a URL source's content and re-parse/re-index.

        Used when the initial fetch captured an SPA shell or stale content.
        Preserves the existing source ID and metadata.
        """
        source = await self.db.source_repo.get_source(source_id)
        if not source:
            raise ValueError(f"Source not found: {source_id}")

        if is_probable_pdf_url(url):
            try:
                content, mime_type, filename, fetch_method = await fetch_url_file(url)
                if self._is_pdf_payload(mime_type, content):
                    return await self._refetch_url_file_content(
                        source=source,
                        url=url,
                        file_content=content,
                        mime_type=mime_type,
                        filename=filename,
                        fetch_method=fetch_method,
                    )
                logger.info(
                    "Refetch URL looked like PDF but payload was not PDF; falling back to HTML flow",
                    source_id=source_id,
                    url=url,
                    mime_type=mime_type,
                )
            except Exception as e:
                logger.warning(
                    "PDF URL refetch failed; falling back to HTML flow",
                    source_id=source_id,
                    url=url,
                    error=str(e),
                )

        # Re-fetch HTML
        html_content, page_title, fetch_method = await fetch_url_html(url)
        content_hash = sha256_bytes(html_content.encode("utf-8"))

        # Update metadata with new fetch info
        meta = source.metadata or {}
        meta["fetch_method"] = fetch_method
        meta["refetched"] = True
        source.metadata = meta
        source.sha256 = content_hash

        # Re-parse HTML → markdown
        try:
            parsed_md, title, section_tree = parse_html(html_content, title=page_title)

            from nowledge_graph_server.services.source_storage import _safe_filename
            stem = _safe_filename(page_title or url)
            parsed_path = self.storage.write_parsed(source_id, parsed_md, stem=stem)

            source.parsed_path = str(parsed_path)
            source.original_name = page_title or source.original_name
            source.summary = parsed_md[:500] if parsed_md else ""
            source.section_tree = section_tree
            source.lifecycle_state = "parsed"

            await self.db.source_repo.update_lifecycle_state(
                source_id,
                "parsed",
                parsed_path=str(parsed_path),
                summary=source.summary[:500] if source.summary else "",
                section_tree=section_tree or "",
            )
            await self._update_source_fields(
                source_id,
                original_name=source.original_name,
                mime_type="text/html",
                file_path=source.file_path or "",
                source_url=url,
                sha256=content_hash,
                size_bytes=len(html_content.encode("utf-8")),
                metadata=meta,
            )

        except Exception as e:
            logger.error("Re-fetch parse failed", source_id=source_id, error=str(e))
            await self.db.source_repo.update_lifecycle_state(
                source_id, "error", error_message=str(e)
            )
            source.lifecycle_state = "error"
            source.error_message = str(e)
            return source

        # Re-chunk and re-index
        source = await self._chunk(source)
        if source.lifecycle_state != "error":
            source = await self._index(source)

        logger.info("Re-fetched URL source", source_id=source_id, url=url,
                     fetch_method=fetch_method, lifecycle_state=source.lifecycle_state)
        return source

    def _is_pdf_payload(self, mime_type: Optional[str], content: bytes) -> bool:
        """Decide whether fetched URL content is a PDF file."""
        return is_pdf_mime_type(mime_type) or looks_like_pdf_bytes(content)

    async def _ingest_url_file_content(
        self,
        url: str,
        file_content: bytes,
        mime_type: Optional[str],
        filename: Optional[str],
        fetch_method: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> SourceNode:
        """Ingest URL binary payload (PDF) through the file parse pipeline."""
        content_hash = sha256_bytes(file_content)

        existing = await self.db.source_repo.get_source_by_sha256(content_hash)
        if existing:
            logger.info("Duplicate URL file content", url=url, existing_id=existing.id)
            if existing.metadata is None:
                existing.metadata = {}
            existing.metadata["fetch_method"] = fetch_method
            await self._update_source_fields(existing.id, metadata=existing.metadata)
            return existing

        merged_meta: Dict[str, Any] = {"url": url, "fetch_method": fetch_method, **(metadata or {})}
        info = self.storage.ingest_url_file(
            url=url,
            file_content=file_content,
            filename=filename,
            mime_type=mime_type,
            metadata=merged_meta,
        )
        source_id = info["source_id"]
        now = datetime.now(timezone.utc)

        source = SourceNode(
            id=source_id,
            source_type="url",
            original_name=info["original_name"] or filename or url,
            mime_type=mime_type or detect_mime_type(Path(info["file_path"])),
            file_path=info["file_path"],
            source_url=url,
            sha256=content_hash,
            size_bytes=info["size_bytes"],
            version=1,
            lifecycle_state="ingested",
            created_at=now,
            updated_at=now,
            metadata=merged_meta,
        )

        source = await self.db.source_repo.create_source(source)
        source = await self._parse(source)
        if source.lifecycle_state == "error":
            return source

        source = await self._chunk(source)
        if source.lifecycle_state != "error":
            source = await self._index(source)

        return source

    async def _refetch_url_file_content(
        self,
        source: SourceNode,
        url: str,
        file_content: bytes,
        mime_type: Optional[str],
        filename: Optional[str],
        fetch_method: str,
    ) -> SourceNode:
        """Refetch URL binary payload (PDF) and re-run parse/chunk/index."""
        meta = source.metadata or {}
        meta["fetch_method"] = fetch_method
        meta["refetched"] = True
        source.metadata = meta

        info = self.storage.ingest_url_file(
            url=url,
            file_content=file_content,
            filename=filename,
            mime_type=mime_type,
            source_id=source.id,
            metadata=meta,
        )

        source.file_path = info["file_path"]
        source.mime_type = mime_type or detect_mime_type(Path(info["file_path"]))
        source.sha256 = info["sha256"]
        source.size_bytes = info["size_bytes"]
        source.original_name = info["original_name"] or source.original_name
        source.source_url = url
        await self._update_source_fields(
            source.id,
            original_name=source.original_name,
            mime_type=source.mime_type,
            file_path=source.file_path,
            source_url=source.source_url,
            sha256=source.sha256,
            size_bytes=source.size_bytes,
            metadata=meta,
        )

        source = await self._parse(source)
        if source.lifecycle_state == "error":
            return source

        source = await self._chunk(source)
        if source.lifecycle_state != "error":
            source = await self._index(source)

        logger.info(
            "Re-fetched URL source as file",
            source_id=source.id,
            url=url,
            fetch_method=fetch_method,
            lifecycle_state=source.lifecycle_state,
        )
        return source

    async def _update_source_fields(self, source_id: str, **fields: Any) -> None:
        """Persist core source fields when repository supports it."""
        updater = getattr(self.db.source_repo, "update_source_fields", None)
        if callable(updater):
            await updater(source_id, **fields)

    async def _parse(self, source: SourceNode) -> SourceNode:
        """Parse a file source to markdown."""
        try:
            raw_path = Path(source.file_path) if source.file_path else None
            if not raw_path or not raw_path.exists():
                raise FileNotFoundError(f"Raw file not found: {source.file_path}")

            # Pass the source directory so images can be extracted alongside the parsed .md
            source_dir = self.storage.source_dir(source.id)
            parsed_md, title, section_tree = parse_file(raw_path, output_dir=source_dir)

            # Write parsed .md alongside original
            stem = raw_path.stem
            parsed_path = self.storage.write_parsed(source.id, parsed_md, stem=stem)

            source.parsed_path = str(parsed_path)
            source.summary = parsed_md[:500] if parsed_md else ""
            source.section_tree = section_tree
            source.lifecycle_state = "parsed"

            await self.db.source_repo.update_lifecycle_state(
                source.id,
                "parsed",
                parsed_path=str(parsed_path),
                summary=source.summary[:500] if source.summary else "",
                section_tree=section_tree or "",
            )

            return source

        except Exception as e:
            logger.error("Parse failed", source_id=source.id, error=str(e))
            await self.db.source_repo.update_lifecycle_state(
                source.id, "error", error_message=f"Parse error: {e}"
            )
            source.lifecycle_state = "error"
            source.error_message = str(e)
            return source

    async def _chunk(self, source: SourceNode) -> SourceNode:
        """Chunk parsed markdown."""
        try:
            parsed_path = Path(source.parsed_path) if source.parsed_path else None
            if not parsed_path or not parsed_path.exists():
                raise FileNotFoundError(f"Parsed file not found: {source.parsed_path}")

            parsed_md = parsed_path.read_text(encoding="utf-8")
            chunks = chunk_source(parsed_md, mime_type=source.mime_type or "text/markdown")

            source.chunk_count = len(chunks)
            source.lifecycle_state = "chunked"

            await self.db.source_repo.update_lifecycle_state(
                source.id, "chunked", chunk_count=len(chunks)
            )

            # Store chunks in memory for the index step
            source.metadata["_chunks"] = chunks

            return source

        except Exception as e:
            logger.error("Chunk failed", source_id=source.id, error=str(e))
            await self.db.source_repo.update_lifecycle_state(
                source.id, "error", error_message=f"Chunk error: {e}"
            )
            source.lifecycle_state = "error"
            source.error_message = str(e)
            return source

    async def _index(self, source: SourceNode) -> SourceNode:
        """Index source and chunks in LanceDB."""
        try:
            from nowledge_graph_server.services.search_index.source_sync import (
                sync_source_to_index,
                sync_source_chunks_to_index,
            )

            # Index the source-level record
            await sync_source_to_index(source)

            # Index chunks
            chunks = source.metadata.pop("_chunks", [])
            if chunks:
                synced = await sync_source_chunks_to_index(source.id, chunks)
                logger.info("Indexed chunks", source_id=source.id, count=synced)

            source.lifecycle_state = "indexed"
            await self.db.source_repo.update_lifecycle_state(source.id, "indexed")

            return source

        except Exception as e:
            logger.error("Index failed", source_id=source.id, error=str(e))
            await self.db.source_repo.update_lifecycle_state(
                source.id, "error", error_message=f"Index error: {e}"
            )
            source.lifecycle_state = "error"
            source.error_message = str(e)
            return source
