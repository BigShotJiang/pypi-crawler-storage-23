"""BGE-M3 embedding service for high-quality 1024-dim multilingual embeddings.

This service uses the BGE-M3 model (BAAI/bge-m3) via FastEmbed with ONNX runtime
for efficient local inference. It provides 1024-dimensional embeddings optimized
for semantic search across 100+ languages.

Model options:
- BAAI/bge-m3: Original model (~2.3GB ONNX)
- Teradata/bge-m3: Quantized INT8 version (~542MB)
"""

import asyncio
import os
from pathlib import Path
from typing import Any, List, Optional

import structlog

logger = structlog.get_logger(__name__)

# BGE-M3 configuration
BGE_M3_DIMENSION = 1024
BGE_M3_MODEL_NAME = "BAAI/bge-m3"
BGE_M3_QUANTIZED_MODEL = "Teradata/bge-m3"  # INT8 quantized, smaller


def _import_fastembed():
    """Lazy import for fastembed."""
    try:
        from fastembed import TextEmbedding

        return TextEmbedding
    except ImportError as e:
        logger.error("Failed to import fastembed", error=str(e))
        raise ImportError(
            "fastembed is REQUIRED for BGE-M3 embeddings. "
            "Install with: pip install fastembed"
        )


class BGEM3EmbeddingService:
    """BGE-M3 embedding service using FastEmbed with ONNX runtime.

    Provides high-quality 1024-dimensional multilingual embeddings
    for semantic search. Uses CLS pooling with L2 normalization.
    """

    def __init__(
        self,
        model_name: str = BGE_M3_QUANTIZED_MODEL,  # Use quantized by default
        cache_dir: Optional[str] = None,
        cache_only: bool = True,
        download_source: str = "huggingface",
        use_quantized: bool = True,  # Use INT8 quantized model
    ):
        """Initialize BGE-M3 embedding service.

        Args:
            model_name: Model name (BAAI/bge-m3 or Teradata/bge-m3)
            cache_dir: Local cache directory for models
            cache_only: Use only cached models (don't download)
            download_source: Download source (huggingface/modelscope)
            use_quantized: Use INT8 quantized model (smaller, faster)
        """
        self.model_name = BGE_M3_QUANTIZED_MODEL if use_quantized else BGE_M3_MODEL_NAME
        self.cache_dir = cache_dir
        self.cache_only = cache_only
        self.download_source = download_source
        self.use_quantized = use_quantized
        self._initialized: bool = False

        self.dimension = BGE_M3_DIMENSION
        self.model: Optional[Any] = None

    async def _download_onnx_files(self, hf_cache_root: Path) -> Path:
        """Download ONNX files for BGE-M3.

        Args:
            hf_cache_root: HuggingFace cache root directory

        Returns:
            Path to the model snapshot directory
        """
        logger.info(
            "Downloading BGE-M3 ONNX files",
            model=self.model_name,
            source=self.download_source,
        )

        import logging

        # Suppress HuggingFace Hub's verbose lock messages
        hf_hub_logger = logging.getLogger("huggingface_hub")
        original_hf_hub_level = hf_hub_logger.level
        hf_hub_logger.setLevel(logging.WARNING)

        original_hf_offline = os.environ.get("HF_HUB_OFFLINE")
        original_transformers_offline = os.environ.get("TRANSFORMERS_OFFLINE")

        try:
            # Temporarily enable online access
            if not self.cache_only:
                os.environ["HF_HUB_OFFLINE"] = "0"
                os.environ["TRANSFORMERS_OFFLINE"] = "0"

            from huggingface_hub import snapshot_download
            import huggingface_hub.constants
            # Override cached constant in case huggingface_hub was imported elsewhere first
            if not self.cache_only:
                huggingface_hub.constants.HF_HUB_OFFLINE = False

            loop = asyncio.get_event_loop()

            # Patterns for BGE-M3 ONNX files
            if self.use_quantized:
                # Teradata/bge-m3 structure
                allow_patterns = [
                    "onnx/*",
                    "tokenizer.json",
                    "tokenizer_config.json",
                    "special_tokens_map.json",
                    "config.json",
                ]
            else:
                # BAAI/bge-m3 structure
                allow_patterns = [
                    "onnx/*",
                    "tokenizer.json",
                    "tokenizer_config.json",
                    "special_tokens_map.json",
                    "sentencepiece.bpe.model",
                    "config.json",
                ]

            logger.info(
                "Downloading BGE-M3 ONNX files from HuggingFace",
                model=self.model_name,
                patterns=allow_patterns,
            )

            model_dir = await loop.run_in_executor(
                None,
                lambda: snapshot_download(
                    repo_id=self.model_name,
                    allow_patterns=allow_patterns,
                    cache_dir=str(hf_cache_root),
                    local_files_only=self.cache_only,
                ),
            )

            model_path = Path(model_dir)

            # Verify ONNX file exists
            onnx_file = None
            if self.use_quantized:
                # Teradata uses model_int8.onnx
                for candidate in [
                    model_path / "onnx" / "model_int8.onnx",
                    model_path / "onnx" / "model.onnx",
                ]:
                    if candidate.exists():
                        onnx_file = candidate
                        break
            else:
                onnx_file = model_path / "onnx" / "model.onnx"

            if not onnx_file or not onnx_file.exists():
                raise RuntimeError(
                    f"ONNX file not found after download. "
                    f"Model directory: {model_dir}"
                )

            logger.info(
                "✅ Downloaded BGE-M3 ONNX files successfully",
                model_dir=str(model_dir),
                onnx_file=str(onnx_file),
            )

            return model_path

        finally:
            # Restore original settings
            if not self.cache_only:
                if original_hf_offline is not None:
                    os.environ["HF_HUB_OFFLINE"] = original_hf_offline
                else:
                    os.environ.pop("HF_HUB_OFFLINE", None)

                if original_transformers_offline is not None:
                    os.environ["TRANSFORMERS_OFFLINE"] = original_transformers_offline
                else:
                    os.environ.pop("TRANSFORMERS_OFFLINE", None)

            hf_hub_logger.setLevel(original_hf_hub_level)

    def _find_cached_model(self, hf_cache_root: Path) -> Optional[Path]:
        """Find cached BGE-M3 model.

        Args:
            hf_cache_root: HuggingFace cache root directory

        Returns:
            Path to model directory or None if not found
        """
        hf_cache_name = f"models--{self.model_name.replace('/', '--')}"
        model_cache_dir = hf_cache_root / hf_cache_name

        if not model_cache_dir.exists():
            return None

        # Check for snapshots directory (HuggingFace structure)
        snapshots_dir = model_cache_dir / "snapshots"
        if snapshots_dir.exists():
            for snapshot_dir in snapshots_dir.iterdir():
                if snapshot_dir.is_dir():
                    # Check for ONNX files
                    onnx_dir = snapshot_dir / "onnx"
                    if onnx_dir.exists():
                        for onnx_file in ["model_int8.onnx", "model.onnx"]:
                            if (onnx_dir / onnx_file).exists():
                                return snapshot_dir

        return None

    async def initialize(self) -> None:
        """Initialize the BGE-M3 model with ONNX-only downloads."""
        if self._initialized:
            return

        TextEmbedding = _import_fastembed()

        try:
            logger.info(
                "Initializing BGE-M3 embedding model",
                model=self.model_name,
                cache_only=self.cache_only,
                use_quantized=self.use_quantized,
            )

            # Get HuggingFace cache directory
            from ..config import get_default_huggingface_cache

            hf_cache_root = get_default_huggingface_cache()

            # Find or download model
            local_model_path = self._find_cached_model(hf_cache_root)

            if not local_model_path:
                if self.cache_only:
                    raise RuntimeError(
                        f"BGE-M3 model not found in cache and cache_only mode is enabled. "
                        f"Please download the model first using the UI or API."
                    )
                local_model_path = await self._download_onnx_files(hf_cache_root)

            # Set offline mode for FastEmbed
            if self.cache_only:
                os.environ["HF_HUB_OFFLINE"] = "1"
                os.environ["TRANSFORMERS_OFFLINE"] = "1"

            # Register BGE-M3 as custom model for FastEmbed
            from fastembed.common.model_description import ModelSource, PoolingType

            # Determine ONNX model file name
            if self.use_quantized:
                model_file = "onnx/model_int8.onnx"
                if not (local_model_path / model_file).exists():
                    model_file = "onnx/model.onnx"
            else:
                model_file = "onnx/model.onnx"

            logger.info(
                "Registering BGE-M3 custom model for FastEmbed",
                model_file=model_file,
            )

            TextEmbedding.add_custom_model(
                model=self.model_name,
                pooling=PoolingType.CLS,  # BGE uses CLS pooling
                normalization=True,  # L2 normalize
                sources=ModelSource(hf=self.model_name),
                dim=BGE_M3_DIMENSION,
                model_file=model_file,
            )

            loop = asyncio.get_event_loop()

            def _init():
                return TextEmbedding(
                    model_name=self.model_name,
                    specific_model_path=str(local_model_path),
                    cache_dir=str(hf_cache_root.parent),
                    local_files_only=self.cache_only,
                )

            self.model = await loop.run_in_executor(None, _init)
            self._initialized = True

            logger.info(
                "✅ BGE-M3 embedding model initialized successfully",
                model=self.model_name,
                dimension=self.dimension,
            )

        except Exception as e:
            logger.error(
                "Failed to initialize BGE-M3 embedding model",
                model=self.model_name,
                error=str(e),
            )
            raise

    async def embed_text(self, text: str) -> List[float]:
        """Generate BGE-M3 embedding for a single text.

        Args:
            text: Input text

        Returns:
            1024-dimensional embedding vector
        """
        if not self._initialized or self.model is None:
            raise RuntimeError("BGE-M3 service not initialized")

        if not text or not text.strip():
            return [0.0] * self.dimension

        try:
            loop = asyncio.get_event_loop()

            def _embed():
                embeddings = list(self.model.embed([text.strip()]))
                if embeddings:
                    return embeddings[0].tolist()
                return [0.0] * self.dimension

            embedding = await loop.run_in_executor(None, _embed)
            return [float(x) for x in embedding]

        except Exception as e:
            logger.error(
                "Failed to generate BGE-M3 embedding",
                text=text[:100],
                error=str(e),
            )
            raise

    async def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """Generate BGE-M3 embeddings for a batch of texts.

        Args:
            texts: List of input texts

        Returns:
            List of 1024-dimensional embedding vectors
        """
        if not self._initialized or self.model is None:
            raise RuntimeError("BGE-M3 service not initialized")

        if not texts:
            return []

        # Filter and prepare texts
        valid_texts = [t.strip() for t in texts if t and t.strip()]

        if not valid_texts:
            return [[0.0] * self.dimension for _ in texts]

        try:
            loop = asyncio.get_event_loop()

            def _embed_batch():
                embeddings = list(self.model.embed(valid_texts))
                return [emb.tolist() for emb in embeddings]

            embeddings = await loop.run_in_executor(None, _embed_batch)

            # Map back to original order (handle empty strings)
            result = []
            valid_idx = 0
            for text in texts:
                if text and text.strip():
                    result.append([float(x) for x in embeddings[valid_idx]])
                    valid_idx += 1
                else:
                    result.append([0.0] * self.dimension)

            return result

        except Exception as e:
            logger.error(
                "Failed to generate BGE-M3 batch embeddings",
                count=len(texts),
                error=str(e),
            )
            raise

    async def cleanup(self) -> None:
        """Cleanup resources."""
        if hasattr(self, "model") and self.model is not None:
            del self.model
        self._initialized = False
        logger.info("BGE-M3 embedding service cleaned up")


def check_bge_m3_model_exists(
    use_quantized: bool = True,
    cache_dir: Optional[str] = None,
) -> bool:
    """Check if BGE-M3 model is cached.

    Args:
        use_quantized: Check for quantized model
        cache_dir: Custom cache directory

    Returns:
        True if model is cached
    """
    from ..config import get_default_huggingface_cache

    hf_cache_root = get_default_huggingface_cache()

    model_name = BGE_M3_QUANTIZED_MODEL if use_quantized else BGE_M3_MODEL_NAME
    hf_cache_name = f"models--{model_name.replace('/', '--')}"
    model_cache_dir = hf_cache_root / hf_cache_name

    if not model_cache_dir.exists():
        return False

    # Check for ONNX files
    snapshots_dir = model_cache_dir / "snapshots"
    if snapshots_dir.exists():
        for snapshot_dir in snapshots_dir.iterdir():
            if snapshot_dir.is_dir():
                onnx_dir = snapshot_dir / "onnx"
                if onnx_dir.exists():
                    for onnx_file in ["model_int8.onnx", "model.onnx"]:
                        if (onnx_dir / onnx_file).exists():
                            return True

    return False
