"""Source parsing service — converts files/URLs to markdown using markitdown.

Handles:
- File parsing via markitdown (PDF, DOCX, PPTX, XLSX, HTML, CSV, etc.)
- URL fetching via browse-now/httpx (HTML and direct file URLs)
- Section tree extraction from heading hierarchy
"""

from __future__ import annotations

import io
import json
import re
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import unquote, urlparse

import structlog

logger = structlog.get_logger(__name__)

# MIME type mapping for common extensions
EXTENSION_MIME_MAP = {
    ".pdf": "application/pdf",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".csv": "text/csv",
    ".html": "text/html",
    ".htm": "text/html",
    ".md": "text/markdown",
    ".txt": "text/plain",
    ".json": "application/json",
    ".xml": "application/xml",
    ".py": "text/x-python",
    ".js": "text/javascript",
    ".ts": "text/typescript",
    ".rs": "text/x-rust",
    ".go": "text/x-go",
    ".java": "text/x-java",
    ".c": "text/x-c",
    ".cpp": "text/x-c++",
    ".rb": "text/x-ruby",
    ".swift": "text/x-swift",
}

# Files that are already markdown — skip parsing, just copy
PASSTHROUGH_EXTENSIONS = {".md", ".txt"}

# Code file extensions — pass through as fenced code blocks
CODE_EXTENSIONS = {".py", ".js", ".ts", ".rs", ".go", ".java", ".c", ".cpp", ".rb", ".swift"}

_PDF_SIGNATURE = b"%PDF-"


def detect_mime_type(file_path: Path) -> str:
    """Detect MIME type from file extension."""
    ext = file_path.suffix.lower()
    return EXTENSION_MIME_MAP.get(ext, "application/octet-stream")


def is_pdf_mime_type(mime_type: Optional[str]) -> bool:
    """Return True when MIME type identifies PDF content."""
    if not mime_type:
        return False
    return mime_type.split(";", 1)[0].strip().lower() == "application/pdf"


def looks_like_pdf_bytes(content: bytes) -> bool:
    """Cheap signature check for PDF binaries."""
    return content.startswith(_PDF_SIGNATURE)


def is_probable_pdf_url(url: str) -> bool:
    """Detect URL patterns that likely point to a PDF file."""
    parsed = urlparse(url)
    path = unquote(parsed.path or "").lower()
    if path.endswith(".pdf"):
        return True
    # Common direct-PDF route style (e.g. arXiv: /pdf/<paper-id>)
    if "/pdf/" in path:
        return True
    query = unquote(parsed.query or "").lower()
    return ".pdf" in query


async def fetch_url_file(url: str) -> Tuple[bytes, str, Optional[str], str]:
    """Fetch URL content as binary with MIME/filename hints.

    Returns:
        (content_bytes, mime_type, filename, fetch_method)
    """
    try:
        import httpx
    except ImportError as e:
        raise RuntimeError("httpx is required for URL file fetching") from e

    async with httpx.AsyncClient(follow_redirects=True, timeout=30) as http:
        resp = await http.get(url)
        resp.raise_for_status()

        raw_mime = resp.headers.get("content-type", "")
        mime_type = raw_mime.split(";", 1)[0].strip().lower() or "application/octet-stream"
        filename = _filename_from_content_disposition(resp.headers.get("content-disposition"))
        if not filename:
            filename = _filename_from_url(str(resp.url), mime_type)

        return resp.content, mime_type, filename, "httpx_file"


def parse_file(
    file_path: Path, output_dir: Optional[Path] = None
) -> Tuple[str, Optional[str], Optional[str]]:
    """Parse a file to markdown using markitdown.

    Args:
        file_path: Path to the raw file
        output_dir: Directory to write extracted images (for DOCX/PPTX).
                    If None, images are not extracted.

    Returns:
        (parsed_markdown, title, section_tree_json)
    """
    ext = file_path.suffix.lower()

    # Markdown/text: pass through directly
    if ext in PASSTHROUGH_EXTENSIONS:
        content = file_path.read_text(encoding="utf-8", errors="replace")
        title = _extract_title(content, file_path.stem)
        section_tree = _extract_section_tree(content)
        return content, title, section_tree

    # Code files: wrap in fenced block
    if ext in CODE_EXTENSIONS:
        content = file_path.read_text(encoding="utf-8", errors="replace")
        lang = ext.lstrip(".")
        wrapped = f"```{lang}\n{content}\n```"
        return wrapped, file_path.name, None

    # PDF: use pymupdf4llm for higher-quality layout-aware conversion
    if ext == ".pdf":
        try:
            import pymupdf4llm

            markdown = pymupdf4llm.to_markdown(str(file_path))
            title = _extract_title(markdown, file_path.stem)
            section_tree = _extract_section_tree(markdown)
            logger.info("Parsed PDF with pymupdf4llm", path=str(file_path), chars=len(markdown), title=title)
            return markdown, title, section_tree
        except ImportError:
            logger.warning("pymupdf4llm not installed, falling back to markitdown for PDF")
        except Exception as e:
            logger.warning("pymupdf4llm failed, falling back to markitdown", path=str(file_path), error=str(e))

    # All other formats (and PDF fallback): use markitdown
    try:
        from markitdown import MarkItDown

        md = MarkItDown()
        result = md.convert(file_path)
        markdown = result.markdown or ""
        title = result.title or _extract_title(markdown, file_path.stem)

        # Extract embedded images from DOCX/PPTX and replace placeholders
        if ext in {".docx", ".pptx"} and output_dir:
            markdown = _extract_office_images(file_path, markdown, output_dir)
            # Also rewrite bare filename image refs (e.g. ![alt](Image0.jpg))
            markdown = _rewrite_bare_image_refs(markdown, output_dir, file_path)

        # Clean up PPTX slide markers and stray HTML comments
        if ext == ".pptx":
            markdown = _clean_slide_markers(markdown)

        section_tree = _extract_section_tree(markdown)

        logger.info(
            "Parsed file",
            path=str(file_path),
            chars=len(markdown),
            title=title,
        )
        return markdown, title, section_tree

    except ImportError:
        logger.error("markitdown not installed — cannot parse non-text files")
        raise RuntimeError(
            "markitdown is required for parsing. Install with: pip install markitdown"
        )
    except Exception as e:
        logger.error("Failed to parse file", path=str(file_path), error=str(e))
        raise


def parse_html(html_content: str, title: Optional[str] = None) -> Tuple[str, Optional[str], Optional[str]]:
    """Parse HTML content to markdown using markitdown's HTML converter.

    Args:
        html_content: Raw HTML string
        title: Optional title override

    Returns:
        (parsed_markdown, title, section_tree_json)
    """
    try:
        from markitdown import MarkItDown
        from markitdown._stream_info import StreamInfo

        md = MarkItDown()
        stream = io.BytesIO(html_content.encode("utf-8"))
        result = md.convert_stream(stream, stream_info=StreamInfo(extension=".html"))
        markdown = result.markdown or ""
        parsed_title = title or result.title or _extract_title(markdown, "page")
        section_tree = _extract_section_tree(markdown)

        return markdown, parsed_title, section_tree

    except ImportError:
        logger.error("markitdown not installed")
        raise RuntimeError("markitdown is required")
    except Exception as e:
        logger.error("Failed to parse HTML", error=str(e))
        raise


async def fetch_url_html(url: str) -> Tuple[str, Optional[str], str]:
    """Fetch URL content using the browser extension via browser bridge.

    The browser bridge runs in the same process — we call the registry
    directly rather than connecting as a WebSocket client.

    For SPA-heavy sites (x.com, React apps), the initial HTML after the
    ``load`` event may only contain a shell / ``<noscript>`` fallback.
    We detect this and retry after a delay so the JS app has time to render.

    Falls back to httpx for public URLs if no browser is connected.

    Returns:
        (html_content, page_title, fetch_method)
        fetch_method is one of: "browse_now", "httpx"
    """
    import asyncio as _asyncio
    import uuid as _uuid

    browse_now_reason: Optional[str] = None

    try:
        from nowledge_graph_server.api.routers.browser_bridge import (
            browser_registry,
            WSMessage,
        )

        # Check if any browser extension is connected
        browsers = await browser_registry.get_all_browsers()
        if not browsers:
            browse_now_reason = "no_browser_connected"
        else:
            # Navigate to URL — use networkidle to wait for SPA async loads
            nav_resp = await browser_registry.send_to_browser(
                browser_id=None,
                message=WSMessage(
                    id=str(_uuid.uuid4()),
                    type="command",
                    payload={"action": "navigate", "params": {"url": url, "waitUntil": "networkidle"}},
                ),
                timeout=30.0,
            )
            if not nav_resp.success:
                logger.warning("browse-now navigate failed", url=url, error=nav_resp.error)
                browse_now_reason = "navigate_error"
            else:
                html = await _evaluate_browser_html(browser_registry, WSMessage, _uuid)

                # SPA check: if the page looks like an unhydrated shell, wait and retry.
                # x.com and similar React SPAs serve <noscript> content that fires before
                # the JS app mounts. The real content appears after async data fetches.
                if html and _looks_like_spa_shell(html):
                    logger.info("SPA shell detected, waiting for JS render", url=url)
                    await _asyncio.sleep(3)
                    html = await _evaluate_browser_html(browser_registry, WSMessage, _uuid)

                if html:
                    # Get page title
                    title_resp = await browser_registry.send_to_browser(
                        browser_id=None,
                        message=WSMessage(
                            id=str(_uuid.uuid4()),
                            type="command",
                            payload={"action": "evaluate", "params": {"code": "document.title"}},
                        ),
                        timeout=10.0,
                    )
                    title = (title_resp.data or {}).get("result") if title_resp.success else None
                    return html, title, "browse_now"
                else:
                    browse_now_reason = "no_html_returned"

    except ImportError:
        browse_now_reason = "browser_bridge_unavailable"
    except Exception as e:
        logger.warning("browse-now failed", url=url, error=str(e))
        browse_now_reason = f"error: {e}"

    logger.info("browse-now unavailable, using httpx fallback",
                url=url, reason=browse_now_reason)

    # Fallback: httpx for public URLs
    try:
        import httpx

        async with httpx.AsyncClient(follow_redirects=True, timeout=30) as http:
            resp = await http.get(url)
            resp.raise_for_status()
            return resp.text, None, "httpx"

    except ImportError:
        raise RuntimeError("Neither browse-now nor httpx available for URL fetching")
    except Exception as e:
        raise RuntimeError(f"Failed to fetch URL {url}: {e}")


async def _evaluate_browser_html(browser_registry: Any, WSMessage: Any, _uuid: Any) -> str:
    """Evaluate document.documentElement.outerHTML in the browser."""
    html_resp = await browser_registry.send_to_browser(
        browser_id=None,
        message=WSMessage(
            id=str(_uuid.uuid4()),
            type="command",
            payload={"action": "evaluate", "params": {"code": "document.documentElement.outerHTML"}},
        ),
        timeout=30.0,
    )
    return (html_resp.data or {}).get("result", "") if html_resp.success else ""


# Patterns that indicate an SPA shell that hasn't rendered yet.
# These appear in <noscript> tags of React/Next.js/SPA frameworks.
_SPA_SHELL_MARKERS = (
    "JavaScript is not available",
    "JavaScript is required",
    "enable JavaScript",
    "noscript",
)


def _looks_like_spa_shell(html: str) -> bool:
    """Detect if HTML looks like an unhydrated SPA shell.

    SPA frameworks (x.com, Twitter, many React apps) serve minimal HTML
    with a <noscript> fallback. The real content loads via JS after mount.
    We check if the visible text (outside script/style tags) is suspiciously
    short or contains known SPA placeholder text.
    """
    # Quick check: known markers in the HTML
    html_lower = html.lower()
    for marker in _SPA_SHELL_MARKERS:
        if marker.lower() in html_lower:
            # Also verify the page has very little visible content —
            # some sites legitimately mention "JavaScript" in content
            visible_len = _estimate_visible_text_length(html)
            if visible_len < 500:
                return True

    return False


def _estimate_visible_text_length(html: str) -> int:
    """Rough estimate of visible text length by stripping tags."""
    # Strip <script> and <style> blocks
    stripped = re.sub(r"<(script|style|noscript)[^>]*>[\s\S]*?</\1>", "", html, flags=re.IGNORECASE)
    # Strip all remaining tags
    stripped = re.sub(r"<[^>]+>", " ", stripped)
    # Collapse whitespace
    stripped = re.sub(r"\s+", " ", stripped).strip()
    return len(stripped)


def _filename_from_content_disposition(content_disposition: Optional[str]) -> Optional[str]:
    """Extract filename from Content-Disposition header when present."""
    if not content_disposition:
        return None

    # RFC 5987 form: filename*=UTF-8''encoded-name.pdf
    match_star = re.search(r"filename\*\s*=\s*([^;]+)", content_disposition, flags=re.IGNORECASE)
    if match_star:
        value = match_star.group(1).strip().strip('"').strip("'")
        if "''" in value:
            _, encoded_name = value.split("''", 1)
            name = unquote(encoded_name)
        else:
            name = unquote(value)
        return Path(name).name or None

    # Legacy form: filename="name.pdf"
    match = re.search(r"filename\s*=\s*([^;]+)", content_disposition, flags=re.IGNORECASE)
    if not match:
        return None
    value = match.group(1).strip().strip('"').strip("'")
    name = unquote(value)
    return Path(name).name or None


def _filename_from_url(url: str, mime_type: str) -> str:
    """Build a reasonable filename from URL path and MIME type."""
    parsed = urlparse(url)
    basename = Path(unquote(parsed.path or "")).name
    if basename:
        return basename
    if is_pdf_mime_type(mime_type):
        return "document.pdf"
    return "download.bin"


# Regex matching markitdown's truncated image placeholders
_TRUNCATED_IMAGE_RE = re.compile(r"!\[([^\]]*)\]\(data:image/[^)]*\.\.\.\)")

# Media directory inside Office ZIP files
_OFFICE_MEDIA_DIRS = {"word/media/", "ppt/media/"}


def _extract_office_images(
    file_path: Path, markdown: str, output_dir: Path
) -> str:
    """Extract images from DOCX/PPTX ZIP and replace truncated placeholders.

    Markitdown (via mammoth) truncates base64 data URIs to literal '...',
    losing all image data. This function:
    1. Opens the original Office file as a ZIP
    2. Extracts media files (images) in order
    3. Saves them to output_dir/images/
    4. Replaces each ![fig:](data:image/...;base64...) with ![fig:](images/name)
    """
    placeholders = list(_TRUNCATED_IMAGE_RE.finditer(markdown))
    if not placeholders:
        return markdown

    # Extract images from ZIP in order
    images: List[Tuple[str, bytes]] = []
    try:
        with zipfile.ZipFile(file_path, "r") as zf:
            for name in sorted(zf.namelist()):
                for media_prefix in _OFFICE_MEDIA_DIRS:
                    if name.startswith(media_prefix) and not name.endswith("/"):
                        images.append((Path(name).name, zf.read(name)))
                        break
    except (zipfile.BadZipFile, OSError) as e:
        logger.warning("Could not extract images from Office file", error=str(e))
        return markdown

    if not images:
        return markdown

    # Save images to output_dir/images/
    images_dir = output_dir / "images"
    images_dir.mkdir(parents=True, exist_ok=True)

    saved_names: List[str] = []
    for img_name, img_data in images:
        dest = images_dir / img_name
        dest.write_bytes(img_data)
        saved_names.append(img_name)

    # Replace placeholders in order — zip images with placeholders
    result = markdown
    for i, match in enumerate(placeholders):
        if i < len(saved_names):
            alt = match.group(1)
            result = result.replace(
                match.group(0),
                f"![{alt}](images/{saved_names[i]})",
                1,  # Replace one at a time to preserve order
            )

    logger.info(
        "Extracted images from Office file",
        count=len(saved_names),
        replaced=min(len(placeholders), len(saved_names)),
    )
    return result


def _rewrite_bare_image_refs(
    markdown: str, output_dir: Path, file_path: Path
) -> str:
    """Rewrite bare-filename image refs to point to extracted images.

    Markitdown's PPTX converter may produce ![alt](Image0.jpg) — a bare
    filename that doesn't match the truncated data-URI regex. This function
    checks if those filenames exist in the Office ZIP's media dirs and,
    if so, extracts + rewrites them to images/filename.
    """
    # Regex: ![alt](BareFilename.ext) — no path separators, no data:, no http
    bare_ref_re = re.compile(
        r"!\[([^\]]*)\]\(([^/\):][^)]*\.(?:jpg|jpeg|png|gif|emf|wmf|svg|tiff|bmp))\)",
        re.IGNORECASE,
    )
    matches = list(bare_ref_re.finditer(markdown))
    if not matches:
        return markdown

    # Build a lookup of available media files from the Office ZIP
    zip_media: Dict[str, bytes] = {}
    try:
        with zipfile.ZipFile(file_path, "r") as zf:
            for name in zf.namelist():
                for prefix in _OFFICE_MEDIA_DIRS:
                    if name.startswith(prefix) and not name.endswith("/"):
                        zip_media[Path(name).name] = zf.read(name)
                        break
    except (zipfile.BadZipFile, OSError):
        return markdown

    if not zip_media:
        return markdown

    images_dir = output_dir / "images"
    images_dir.mkdir(parents=True, exist_ok=True)

    # Build ordered list of unmatched media files for positional fallback
    available_media = list(zip_media.items())  # Sorted by ZIP order
    used_media: set = set()

    result = markdown
    rewrote = 0
    for match in matches:
        bare_name = match.group(2)
        out_name: Optional[str] = None
        img_data: Optional[bytes] = None

        # 1) Exact filename match
        if bare_name in zip_media:
            out_name = bare_name
            img_data = zip_media[bare_name]
        else:
            # 2) Case-insensitive lookup
            for zname, zdata in zip_media.items():
                if zname.lower() == bare_name.lower():
                    out_name = zname
                    img_data = zdata
                    break

        # 3) Positional fallback — assign next unused media file
        if img_data is None:
            for zname, zdata in available_media:
                if zname not in used_media:
                    out_name = zname
                    img_data = zdata
                    break

        if img_data and out_name:
            used_media.add(out_name)
            dest = images_dir / out_name
            if not dest.exists():
                dest.write_bytes(img_data)
            alt = match.group(1)
            result = result.replace(match.group(0), f"![{alt}](images/{out_name})", 1)
            rewrote += 1

    logger.info("Rewrote bare image refs", count=len(matches), rewrote=rewrote, file=str(file_path.name))
    return result


def _clean_slide_markers(markdown: str) -> str:
    """Convert slide comments to visual separators and strip remaining HTML comments.

    Markitdown inserts <!-- Slide number: N --> for PPTX files. Convert to
    readable slide separators, then strip any remaining HTML comments.
    """
    # Convert slide markers to bold headings with horizontal rule
    markdown = re.sub(
        r"<!--\s*Slide\s+number:\s*(\d+)\s*-->",
        r"\n---\n\n**Slide \1**\n",
        markdown,
    )
    # Strip remaining HTML comments
    markdown = re.sub(r"<!--[\s\S]*?-->", "", markdown)
    return markdown


def _extract_title(markdown: str, fallback: str) -> str:
    """Extract title from first heading or first line."""
    for line in markdown.split("\n")[:10]:
        line = line.strip()
        if line.startswith("# "):
            return line[2:].strip()
    # Use first non-empty line
    for line in markdown.split("\n")[:5]:
        line = line.strip()
        if line and len(line) > 3:
            return line[:100]
    return fallback


def _extract_section_tree(markdown: str) -> Optional[str]:
    """Extract heading hierarchy as a JSON tree.

    Returns JSON like:
    [
        {"level": 1, "title": "Introduction", "line": 1},
        {"level": 2, "title": "Background", "line": 5},
        ...
    ]
    """
    headings: List[Dict[str, Any]] = []
    for i, line in enumerate(markdown.split("\n"), 1):
        match = re.match(r"^(#{1,6})\s+(.+)$", line)
        if match:
            headings.append({
                "level": len(match.group(1)),
                "title": match.group(2).strip(),
                "line": i,
            })

    if not headings:
        return None

    return json.dumps(headings)
