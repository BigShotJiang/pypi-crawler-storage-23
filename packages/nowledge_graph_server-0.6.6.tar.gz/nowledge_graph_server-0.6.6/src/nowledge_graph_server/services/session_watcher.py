"""Session watcher service for auto-importing AI coding assistant sessions.

Watches for new/modified session files and triggers auto-import based on user rules.
Uses watchdog for file system monitoring.
"""

import asyncio
import os
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, Optional, Set

import sys

import structlog
from watchdog.events import FileSystemEventHandler, FileModifiedEvent, FileCreatedEvent

# On macOS, FSEventsObserver can fail in child processes (e.g., Tauri).
# Use the polling observer as a reliable fallback.
if sys.platform == "darwin":
    from watchdog.observers.polling import PollingObserver as Observer
else:
    from watchdog.observers import Observer

from .import_config import get_import_config_service, ImportConfigService

logger = structlog.get_logger(__name__)


@dataclass
class WatcherStatus:
    """Status of the session watcher."""

    running: bool
    watched_paths: list[str]
    last_check: Optional[float] = None
    auto_import_count: int = 0
    errors: list[str] = None

    def __post_init__(self):
        if self.errors is None:
            self.errors = []

    def to_dict(self) -> dict:
        return {
            "running": self.running,
            "watched_paths": self.watched_paths,
            "last_check": self.last_check,
            "auto_import_count": self.auto_import_count,
            "errors": self.errors,
        }


class SessionFileHandler(FileSystemEventHandler):
    """Handles file system events for session files."""

    def __init__(
        self,
        callback: Callable[..., None],
        config_service: ImportConfigService,
        debounce_seconds: float = 2.0,
    ):
        """Initialize the handler.

        Args:
            callback: Function to call when a session is ready for import.
                      Takes (path, source, session_id=None) as arguments.
            config_service: Config service for checking auto-import rules.
            debounce_seconds: Seconds to wait before triggering import (debounce).
        """
        super().__init__()
        self.callback = callback
        self.config_service = config_service
        self.debounce_seconds = debounce_seconds
        self._pending: Dict[str, float] = {}  # path -> scheduled time
        self._processed: Set[str] = set()  # Recently processed paths
        self._lock = threading.Lock()

    def on_created(self, event):
        """Handle file creation."""
        if event.is_directory:
            return
        logger.info("Watcher: file created", path=event.src_path)
        self._handle_session_file(event.src_path)

    def on_modified(self, event):
        """Handle file modification."""
        if event.is_directory:
            return
        logger.info("Watcher: file modified", path=event.src_path)
        self._handle_session_file(event.src_path)

    def _handle_session_file(self, path: str):
        """Process a potential session file."""
        path_normalized = path.replace("\\", "/")
        filename = os.path.basename(path)

        # Handle different file types:
        # - .jsonl: Claude Code, Codex
        # - .json: OpenCode
        valid_extension = (
            path.endswith(".jsonl") or
            path.endswith(".json")
        )
        if not valid_extension:
            return

        # For .json files, only handle OpenCode session files (not message/part files)
        if path.endswith(".json"):
            # OpenCode sessions are in: storage/session/{projectID}/{sessionID}.json
            if "/session/" not in path_normalized:
                return
            # Skip if this is a message or part file
            if "/message/" in path_normalized or "/part/" in path_normalized:
                return

        # Skip agent files (subagents) - they're handled with parent session
        if filename.startswith("agent-"):
            return

        # Determine source from path
        source = self._detect_source(path)
        if not source:
            return

        # Extract project encoded from path
        project_encoded = self._extract_project_encoded(path, source)
        if not project_encoded:
            return

        # Check if should auto-import based on rules
        if not self.config_service.should_auto_import(source, project_encoded):
            logger.debug(
                "Session does not match auto-import rules",
                path=path,
                source=source,
                project=project_encoded,
            )
            return

        # Debounce: schedule callback after delay
        with self._lock:
            self._pending[path] = time.time() + self.debounce_seconds

        # Schedule the check
        threading.Timer(self.debounce_seconds + 0.1, self._check_pending, args=[path, source]).start()

    def _check_pending(self, path: str, source: str):
        """Check if a pending file is ready to be processed."""
        with self._lock:
            if path not in self._pending:
                return

            scheduled_time = self._pending[path]
            if time.time() < scheduled_time:
                # Not ready yet, reschedule
                remaining = scheduled_time - time.time()
                threading.Timer(remaining + 0.1, self._check_pending, args=[path, source]).start()
                return

            # Ready to process
            del self._pending[path]

            # Check deduplication using file mtime (only skip if file hasn't changed)
            try:
                mtime = os.path.getmtime(path)
                dedup_key = f"{path}:{mtime}"
            except OSError:
                # Fallback to time-window dedup if file stat fails
                config = self.config_service.load()
                dedup_key = f"{path}:{int(time.time() // config.dedup_window_seconds)}"

            if dedup_key in self._processed:
                logger.debug("Skipping duplicate import (file unchanged)", path=path)
                return

            self._processed.add(dedup_key)

            # Cleanup old processed entries
            self._cleanup_processed()

        # Trigger callback
        logger.info("Auto-importing session", path=path, source=source)
        try:
            self.callback(path, source)
        except Exception as e:
            logger.error("Failed to auto-import session", path=path, error=str(e))

    def _cleanup_processed(self):
        """Remove old entries from processed set."""
        # Keep set from growing indefinitely
        if len(self._processed) > 1000:
            # Clear oldest half
            items = list(self._processed)
            self._processed = set(items[len(items) // 2 :])

    def _detect_source(self, path: str) -> Optional[str]:
        """Detect the source type from the file path (cross-platform)."""
        # Normalize path separators for comparison
        path_normalized = path.replace("\\", "/").lower()

        if "/.claude/projects/" in path_normalized:
            return "claude"
        elif "/.codex/sessions/" in path_normalized:
            return "codex"
        elif "/opencode/storage/session/" in path_normalized:
            return "opencode"
        # Cursor uses SQLite, not JSONL/JSON, so we don't watch for it

        return None

    def _extract_project_encoded(self, path: str, source: str) -> Optional[str]:
        """Extract encoded project name from path."""
        parts = path.replace("\\", "/").split("/")

        if source == "claude":
            # Pattern: ~/.claude/projects/{encoded}/session.jsonl
            try:
                projects_idx = parts.index("projects")
                if projects_idx + 1 < len(parts):
                    return parts[projects_idx + 1]
            except ValueError:
                pass

        elif source == "codex":
            # Pattern: ~/.codex/sessions/YYYY/MM/DD/rollout-*.jsonl
            # For codex, we don't have a project encoded, use date as identifier
            try:
                sessions_idx = parts.index("sessions")
                if sessions_idx + 3 < len(parts):
                    # Return date path as "encoded" identifier
                    return f"{parts[sessions_idx + 1]}-{parts[sessions_idx + 2]}-{parts[sessions_idx + 3]}"
            except ValueError:
                pass

        elif source == "opencode":
            # Pattern: ~/.local/share/opencode/storage/session/{projectID}/{sessionID}.json
            # The projectID is the Git root commit SHA1 or "global"
            try:
                session_idx = parts.index("session")
                if session_idx + 1 < len(parts):
                    project_id = parts[session_idx + 1]
                    # For OpenCode, we return the projectID as the encoded value
                    # This can be used to match against watched projects
                    return project_id
            except ValueError:
                pass

        return None


class CursorPoller(threading.Thread):
    """Periodic poller for Cursor conversations.

    Unlike Claude/Codex/OpenCode which use append-only files that work well with
    file system events, Cursor uses SQLite databases that:
    - Can be locked by the running application
    - Trigger multiple FS events per logical write (WAL files)
    - Don't provide atomic "conversation changed" signals

    This poller periodically checks for new/updated Cursor conversations via
    discovery and triggers imports for changes.
    """

    def __init__(
        self,
        callback: Callable[..., None],
        config_service: ImportConfigService,
        poll_interval: float = 30.0,
    ):
        """Initialize the Cursor poller.

        Args:
            callback: Function to call when a session should be imported.
                     Takes (path, source, session_id=None) as arguments.
            config_service: Config service for checking auto-import rules.
            poll_interval: Seconds between polls (default: 30)
        """
        super().__init__(daemon=True, name="CursorPoller")
        self.callback = callback
        self.config_service = config_service
        self.poll_interval = poll_interval
        self._stop_event = threading.Event()
        self._last_seen: Dict[str, float] = {}  # session_id -> lastUpdatedAt
        self._lock = threading.Lock()

        logger.info(
            "Initialized Cursor poller",
            poll_interval=poll_interval,
        )

    def run(self):
        """Main polling loop."""
        logger.info("Cursor poller started")

        # Initial delay before first poll (let app settle)
        time.sleep(5.0)

        while not self._stop_event.is_set():
            try:
                self._poll_cursor_conversations()
            except Exception as e:
                logger.error(
                    "Error polling Cursor conversations",
                    error=str(e),
                    error_type=type(e).__name__,
                )

            # Wait for poll_interval or stop signal
            self._stop_event.wait(self.poll_interval)

        logger.info("Cursor poller stopped")

    def stop(self):
        """Stop the polling loop."""
        self._stop_event.set()

    def _poll_cursor_conversations(self):
        """Poll for new/updated Cursor conversations."""
        from .conversation_discovery import ConversationDiscoveryService

        try:
            # Discover all Cursor conversations
            discovery = ConversationDiscoveryService()
            conversations = discovery.discover_cursor_conversations()

            if not conversations:
                logger.debug("No Cursor conversations found")
                return

            logger.debug("Polled Cursor conversations", count=len(conversations))

            with self._lock:
                for conv in conversations:
                    session_id = conv.session_id or conv.path
                    last_modified = conv.last_modified or 0
                    project_encoded = self._extract_project_encoded(conv)

                    # Check if this is a new or updated conversation
                    last_seen = self._last_seen.get(session_id, 0)

                    if last_modified > last_seen:
                        # Check if we should auto-import this session
                        if self.config_service.should_auto_import("cursor", project_encoded):
                            logger.info(
                                "Cursor conversation changed, triggering import",
                                session_id=session_id[:20] if len(session_id) > 20 else session_id,
                                last_modified=last_modified,
                                last_seen=last_seen,
                            )
                            try:
                                self.callback(conv.path, "cursor", conv.session_id)
                            except Exception as e:
                                logger.error(
                                    "Failed to auto-import Cursor session",
                                    path=conv.path,
                                    error=str(e),
                                )
                        else:
                            logger.debug(
                                "Cursor conversation changed but not in auto-import rules",
                                session_id=session_id[:20] if len(session_id) > 20 else session_id,
                            )

                        # Update last seen timestamp
                        self._last_seen[session_id] = last_modified

                # Cleanup old entries (keep only last 500)
                if len(self._last_seen) > 500:
                    items = sorted(self._last_seen.items(), key=lambda x: x[1], reverse=True)
                    self._last_seen = dict(items[:500])

        except Exception as e:
            logger.warning(
                "Failed to poll Cursor conversations",
                error=str(e),
                error_type=type(e).__name__,
            )

    def _extract_project_encoded(self, conv) -> str:
        """Extract encoded project path from Cursor conversation.

        For Cursor, the workspace folder is the project path.
        We encode it similar to Claude: replace / with -

        Args:
            conv: ConversationFile with workspace attribute

        Returns:
            Encoded project path (e.g., "-Users-weyl-dev-project")
        """
        workspace = conv.workspace or conv.project or ""
        if not workspace:
            return ""

        # Encode: remove leading /, replace / with -
        if workspace.startswith("/"):
            return "-" + workspace[1:].replace("/", "-")
        elif ":\\" in workspace:
            # Windows path: C:\Users\... -> C--Users-...
            return workspace.replace(":\\", "--").replace("\\", "-")
        else:
            return workspace.replace("/", "-")


class OpenCodePoller(threading.Thread):
    """Periodic poller for OpenCode SQLite database.

    OpenCode migrated from JSON files to SQLite (opencode.db). SQLite with WAL
    mode triggers multiple FS events per logical write, making file watchers
    unreliable. This poller periodically checks the database for new/updated sessions.
    """

    def __init__(
        self,
        callback: Callable[..., None],
        config_service: ImportConfigService,
        poll_interval: float = 30.0,
    ):
        """Initialize the OpenCode poller.

        Args:
            callback: Function to call when a session should be imported.
                     Takes (path, source, session_id=None) as arguments.
            config_service: Config service for checking auto-import rules.
            poll_interval: Seconds between polls (default: 30)
        """
        super().__init__(daemon=True, name="OpenCodePoller")
        self.callback = callback
        self.config_service = config_service
        self.poll_interval = poll_interval
        self._stop_event = threading.Event()
        self._last_seen: Dict[str, float] = {}  # session_id -> time_updated (ms)
        self._lock = threading.Lock()

        logger.info(
            "Initialized OpenCode poller",
            poll_interval=poll_interval,
        )

    def run(self):
        """Main polling loop."""
        logger.info("OpenCode poller started")

        # Initial delay before first poll
        time.sleep(5.0)

        while not self._stop_event.is_set():
            try:
                self._poll_opencode_sessions()
            except Exception as e:
                logger.error(
                    "Error polling OpenCode sessions",
                    error=str(e),
                    error_type=type(e).__name__,
                )

            self._stop_event.wait(self.poll_interval)

        logger.info("OpenCode poller stopped")

    def stop(self):
        """Stop the polling loop."""
        self._stop_event.set()

    def _poll_opencode_sessions(self):
        """Poll OpenCode SQLite database for new/updated sessions."""
        from .discovery.opencode import _get_opencode_base_path, _get_opencode_db_path, _safe_sqlite_connect

        try:
            base_path = _get_opencode_base_path()
            if not base_path:
                return

            db_path = _get_opencode_db_path(base_path)
            if not db_path or not db_path.exists():
                return

            conn = _safe_sqlite_connect(db_path)
            if not conn:
                return

            try:
                cursor = conn.cursor()

                # Check if session table exists
                cursor.execute(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name='session'"
                )
                if not cursor.fetchone():
                    return

                # Get sessions with their update timestamps
                cursor.execute("""
                    SELECT s.id, s.project_id, s.directory, s.time_updated
                    FROM session s
                    WHERE s.time_archived IS NULL
                    ORDER BY s.time_updated DESC
                    LIMIT 200
                """)

                with self._lock:
                    for row in cursor.fetchall():
                        session_id = row["id"]
                        time_updated = row["time_updated"] or 0
                        directory = row["directory"] or ""
                        project_id = row["project_id"] or ""

                        last_seen = self._last_seen.get(session_id, 0)

                        if time_updated > last_seen:
                            # Determine project encoded for auto-import check
                            project_encoded = self._encode_project(directory, project_id)

                            if self.config_service.should_auto_import("opencode", project_encoded):
                                logger.info(
                                    "OpenCode session changed, triggering import",
                                    session_id=session_id[:20],
                                    time_updated=time_updated,
                                    last_seen=last_seen,
                                )
                                try:
                                    self.callback(str(db_path), "opencode", session_id)
                                except Exception as e:
                                    logger.error(
                                        "Failed to auto-import OpenCode session",
                                        session_id=session_id[:20],
                                        error=str(e),
                                    )
                            else:
                                logger.debug(
                                    "OpenCode session changed but not in auto-import rules",
                                    session_id=session_id[:20],
                                )

                            self._last_seen[session_id] = time_updated

                    # Cleanup old entries
                    if len(self._last_seen) > 500:
                        items = sorted(
                            self._last_seen.items(), key=lambda x: x[1], reverse=True
                        )
                        self._last_seen = dict(items[:500])

            finally:
                conn.close()

        except Exception as e:
            logger.warning(
                "Failed to poll OpenCode sessions",
                error=str(e),
                error_type=type(e).__name__,
            )

    def _encode_project(self, directory: str, project_id: str) -> str:
        """Encode project identifier for auto-import matching."""
        if directory and directory.startswith("/"):
            return "-" + directory[1:].replace("/", "-")
        return project_id or ""


class SessionWatcherService:
    """Service for watching and auto-importing sessions."""

    def __init__(
        self,
        import_callback: Callable[..., None],
        config_service: Optional[ImportConfigService] = None,
        cursor_poll_interval: float = 30.0,
    ):
        """Initialize the watcher service.

        Args:
            import_callback: Function to call when a session should be imported.
                            Takes (path, source, session_id=None) as arguments.
            config_service: Config service. Uses singleton if not provided.
            cursor_poll_interval: Seconds between Cursor polls (default: 30)
        """
        self.import_callback = import_callback
        self.config_service = config_service or get_import_config_service()
        self.cursor_poll_interval = cursor_poll_interval
        self._observer: Optional[Observer] = None
        self._cursor_poller: Optional[CursorPoller] = None
        self._opencode_poller: Optional[OpenCodePoller] = None
        self._status = WatcherStatus(running=False, watched_paths=[])
        self._lock = threading.Lock()

    def _get_opencode_session_path(self) -> Optional[Path]:
        """Get OpenCode session path for watching (cross-platform).

        OpenCode uses XDG standard directory specification:
        - macOS: ~/.local/share/opencode/storage/session/
        - Linux: $XDG_DATA_HOME/opencode/storage/session/ or ~/.local/share/opencode/storage/session/
        - Windows: %USERPROFILE%\\.local\\share\\opencode\\storage\\session\\

        Returns:
            Path to OpenCode session directory, or None if not determinable
        """
        import sys

        home = Path.home()

        if sys.platform == "darwin":
            # macOS
            return home / ".local" / "share" / "opencode" / "storage" / "session"
        elif sys.platform == "win32":
            # Windows
            return home / ".local" / "share" / "opencode" / "storage" / "session"
        else:
            # Linux: check XDG_DATA_HOME first
            xdg_data = os.environ.get("XDG_DATA_HOME")
            if xdg_data:
                return Path(xdg_data) / "opencode" / "storage" / "session"
            return home / ".local" / "share" / "opencode" / "storage" / "session"

    @property
    def status(self) -> WatcherStatus:
        """Get current watcher status."""
        return self._status

    def start(self) -> bool:
        """Start watching for session files.

        Returns:
            True if watcher started successfully.
        """
        with self._lock:
            if self._observer is not None and self._observer.is_alive():
                logger.warning("Watcher already running")
                return True

            try:
                # Wrap callback to track stats
                def tracked_callback(*args, **kwargs):
                    self.import_callback(*args, **kwargs)
                    with self._lock:
                        self._status.auto_import_count += 1
                        self._status.last_check = time.time()

                handler = SessionFileHandler(
                    callback=tracked_callback,
                    config_service=self.config_service,
                )

                self._observer = Observer()
                watched_paths = []

                # Watch Claude Code sessions
                claude_path = Path.home() / ".claude" / "projects"
                if claude_path.exists():
                    self._observer.schedule(handler, str(claude_path), recursive=True)
                    watched_paths.append(str(claude_path))
                    logger.info("Watching Claude Code sessions", path=str(claude_path))

                # Watch Codex sessions
                codex_path = Path.home() / ".codex" / "sessions"
                if codex_path.exists():
                    self._observer.schedule(handler, str(codex_path), recursive=True)
                    watched_paths.append(str(codex_path))
                    logger.info("Watching Codex sessions", path=str(codex_path))

                # Watch OpenCode sessions (cross-platform)
                opencode_path = self._get_opencode_session_path()
                if opencode_path and opencode_path.exists():
                    self._observer.schedule(handler, str(opencode_path), recursive=True)
                    watched_paths.append(str(opencode_path))
                    logger.info("Watching OpenCode sessions", path=str(opencode_path))

                # On Windows, also watch WSL2 paths
                if sys.platform == "win32":
                    try:
                        from .discovery.base import get_wsl_paths_for_tool

                        for wsl_claude in get_wsl_paths_for_tool(".claude/projects"):
                            self._observer.schedule(handler, str(wsl_claude), recursive=True)
                            watched_paths.append(str(wsl_claude))
                            logger.info("Watching WSL2 Claude Code sessions", path=str(wsl_claude))

                        for wsl_codex in get_wsl_paths_for_tool(".codex/sessions"):
                            self._observer.schedule(handler, str(wsl_codex), recursive=True)
                            watched_paths.append(str(wsl_codex))
                            logger.info("Watching WSL2 Codex sessions", path=str(wsl_codex))

                        for wsl_opencode in get_wsl_paths_for_tool(
                            ".local/share/opencode/storage/session"
                        ):
                            self._observer.schedule(handler, str(wsl_opencode), recursive=True)
                            watched_paths.append(str(wsl_opencode))
                            logger.info("Watching WSL2 OpenCode sessions", path=str(wsl_opencode))
                    except Exception as e:
                        logger.warning("Failed to set up WSL2 watchers", error=str(e))

                if not watched_paths:
                    logger.warning("No session directories found to watch")
                    # Continue anyway - Cursor poller might still work
                else:
                    self._observer.start()

                # Start Cursor poller (separate thread for polling-based monitoring)
                try:
                    self._cursor_poller = CursorPoller(
                        callback=tracked_callback,
                        config_service=self.config_service,
                        poll_interval=self.cursor_poll_interval,
                    )
                    self._cursor_poller.start()
                    logger.info("Cursor poller started", poll_interval=self.cursor_poll_interval)
                except Exception as e:
                    logger.warning("Failed to start Cursor poller", error=str(e))

                # Start OpenCode poller (for SQLite-based sessions)
                try:
                    self._opencode_poller = OpenCodePoller(
                        callback=tracked_callback,
                        config_service=self.config_service,
                        poll_interval=self.cursor_poll_interval,  # Reuse same interval
                    )
                    self._opencode_poller.start()
                    logger.info("OpenCode poller started", poll_interval=self.cursor_poll_interval)
                except Exception as e:
                    logger.warning("Failed to start OpenCode poller", error=str(e))

                self._status = WatcherStatus(
                    running=True,
                    watched_paths=watched_paths,
                    last_check=time.time(),
                )

                # Update config
                self.config_service.update(watcher_enabled=True)

                logger.info(
                    "Session watcher started",
                    paths=watched_paths,
                    cursor_polling=self._cursor_poller is not None,
                    opencode_polling=self._opencode_poller is not None,
                )
                return True

            except Exception as e:
                logger.error("Failed to start session watcher", error=str(e))
                self._status.errors.append(str(e))
                return False

    def stop(self) -> bool:
        """Stop watching for session files.

        Returns:
            True if watcher stopped successfully.
        """
        with self._lock:
            success = True

            # Stop file system observer
            if self._observer is not None:
                try:
                    self._observer.stop()
                    self._observer.join(timeout=5.0)
                    self._observer = None
                    logger.info("File system observer stopped")
                except Exception as e:
                    logger.error("Failed to stop file system observer", error=str(e))
                    self._status.errors.append(str(e))
                    success = False

            # Stop Cursor poller
            if self._cursor_poller is not None:
                try:
                    self._cursor_poller.stop()
                    self._cursor_poller.join(timeout=5.0)
                    self._cursor_poller = None
                    logger.info("Cursor poller stopped")
                except Exception as e:
                    logger.error("Failed to stop Cursor poller", error=str(e))
                    self._status.errors.append(str(e))
                    success = False

            # Stop OpenCode poller
            if self._opencode_poller is not None:
                try:
                    self._opencode_poller.stop()
                    self._opencode_poller.join(timeout=5.0)
                    self._opencode_poller = None
                    logger.info("OpenCode poller stopped")
                except Exception as e:
                    logger.error("Failed to stop OpenCode poller", error=str(e))
                    self._status.errors.append(str(e))
                    success = False

            self._status = WatcherStatus(
                running=False,
                watched_paths=[],
                auto_import_count=self._status.auto_import_count,
            )

            # Update config
            self.config_service.update(watcher_enabled=False)

            logger.info("Session watcher stopped")
            return success

    def is_running(self) -> bool:
        """Check if watcher is running.

        Returns True if any observer or poller is running.
        """
        with self._lock:
            observer_running = self._observer is not None and self._observer.is_alive()
            cursor_running = self._cursor_poller is not None and self._cursor_poller.is_alive()
            opencode_running = self._opencode_poller is not None and self._opencode_poller.is_alive()
            return observer_running or cursor_running or opencode_running


# Singleton instance
_watcher_service: Optional[SessionWatcherService] = None
_watcher_lock = threading.Lock()


def get_session_watcher_service(
    import_callback: Optional[Callable[..., None]] = None,
) -> SessionWatcherService:
    """Get the singleton session watcher service instance.

    Args:
        import_callback: Callback for importing sessions. Required on first call.

    Returns:
        The session watcher service instance.

    Raises:
        ValueError: If called for the first time without import_callback.
    """
    global _watcher_service

    with _watcher_lock:
        if _watcher_service is None:
            if import_callback is None:
                raise ValueError("import_callback required for first initialization")
            _watcher_service = SessionWatcherService(import_callback=import_callback)

        return _watcher_service


def initialize_session_watcher(
    import_callback: Callable[..., None],
    cursor_poll_interval: Optional[float] = None,
) -> SessionWatcherService:
    """Initialize the session watcher service with the given callback.

    This should be called during application startup.

    Args:
        import_callback: Function to call when a session should be imported.
        cursor_poll_interval: Seconds between Cursor polls (defaults to 30.0).
                             Can be loaded from config if not provided.

    Returns:
        The initialized watcher service.
    """
    global _watcher_service

    with _watcher_lock:
        # If cursor_poll_interval not provided, load from config
        if cursor_poll_interval is None:
            try:
                config = get_import_config_service().load()
                cursor_poll_interval = config.cursor_poll_interval
            except Exception:
                cursor_poll_interval = 30.0  # Default fallback

        _watcher_service = SessionWatcherService(
            import_callback=import_callback,
            cursor_poll_interval=cursor_poll_interval,
        )
        return _watcher_service
