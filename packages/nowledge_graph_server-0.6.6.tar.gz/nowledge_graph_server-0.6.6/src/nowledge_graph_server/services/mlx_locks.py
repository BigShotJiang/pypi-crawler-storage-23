"""
Shared MLX locks to prevent Metal GPU conflicts.

All MLX operations (embeddings, LLM inference) must share the same lock
to prevent concurrent Metal command buffer operations which cause crashes:
    [_MTLCommandBuffer addCompletedHandler:]:976: failed assertion
    `Completed handler provided after commit call'

Usage:
    from nowledge_graph_server.services.mlx_locks import get_mlx_inference_lock

    lock = get_mlx_inference_lock()
    if lock:
        async with lock:
            # MLX operation
"""

import asyncio
import platform
from typing import Optional

# Detect Apple Silicon
IS_APPLE_SILICON = (
    platform.system() == "Darwin" and platform.machine() == "arm64"
)

# Single global lock for ALL MLX operations (embeddings + LLM)
_SHARED_MLX_LOCK: Optional[asyncio.Lock] = asyncio.Lock() if IS_APPLE_SILICON else None


def get_mlx_inference_lock() -> Optional[asyncio.Lock]:
    """Get the shared MLX inference lock.

    Returns None on non-Apple Silicon platforms.
    """
    return _SHARED_MLX_LOCK
