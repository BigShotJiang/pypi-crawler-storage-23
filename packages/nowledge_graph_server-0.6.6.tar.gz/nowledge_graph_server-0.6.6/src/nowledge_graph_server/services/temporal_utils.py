"""
Temporal utilities for bi-temporal model.

This module provides date normalization and precision tracking for the bi-temporal model.
Based on BITEMPORAL_MODEL_STUDY.md - addresses Date Precision Storage Trap.
"""

from typing import Optional, Tuple
from datetime import date
import re
import structlog

logger = structlog.get_logger(__name__)


class TemporalPrecision:
    """Temporal precision constants."""
    YEAR = "year"
    MONTH = "month"
    DAY = "day"


class TemporalType:
    """Temporal type constants."""
    EXACT = "exact"
    RANGE = "range"
    UNKNOWN = "unknown"


class TemporalContext:
    """Temporal context constants."""
    PAST = "past"
    PRESENT = "present"
    FUTURE = "future"
    TIMELESS = "timeless"


def normalize_temporal_date(date_string: Optional[str]) -> Tuple[Optional[str], Optional[str]]:
    """
    Normalize fuzzy date to strict YYYY-MM-DD format.

    This solves the Date Precision Storage Trap: Most databases (PostgreSQL, Kuzu)
    require strict DATE format (YYYY-MM-DD). You cannot store "2020" or "2020-05" directly.

    Solution: Normalize to YYYY-MM-DD and track original precision separately.

    Args:
        date_string: Input date in various formats (YYYY, YYYY-MM, YYYY-MM-DD)

    Returns:
        Tuple of (normalized_date, precision):
        - normalized_date: Strict YYYY-MM-DD format for database storage
        - precision: "year"|"month"|"day" for UI display

    Examples:
        >>> normalize_temporal_date("2020")
        ("2020-01-01", "year")

        >>> normalize_temporal_date("2020-05")
        ("2020-05-01", "month")

        >>> normalize_temporal_date("2020-05-15")
        ("2020-05-15", "day")

        >>> normalize_temporal_date(None)
        (None, None)

        >>> normalize_temporal_date("")
        (None, None)

    Raises:
        ValueError: If date_string is not in valid format
    """
    if not date_string or date_string.strip() == "":
        return (None, None)

    date_string = date_string.strip()

    # Year only (YYYY)
    # Match exactly 4 digits
    if re.match(r'^\d{4}$', date_string):
        year = date_string
        # Validate year range (1000-9999)
        year_int = int(year)
        if year_int < 1000 or year_int > 9999:
            raise ValueError(f"Year out of range (1000-9999): {year}")
        return (f"{year}-01-01", TemporalPrecision.YEAR)

    # Year-Month (YYYY-MM)
    # Match YYYY-MM format
    month_match = re.match(r'^(\d{4})-(\d{2})$', date_string)
    if month_match:
        year, month = month_match.groups()
        year_int = int(year)
        month_int = int(month)

        # Validate ranges
        if year_int < 1000 or year_int > 9999:
            raise ValueError(f"Year out of range (1000-9999): {year}")
        if month_int < 1 or month_int > 12:
            raise ValueError(f"Month out of range (1-12): {month}")

        return (f"{year}-{month}-01", TemporalPrecision.MONTH)

    # Full date (YYYY-MM-DD)
    # Match YYYY-MM-DD format
    day_match = re.match(r'^(\d{4})-(\d{2})-(\d{2})$', date_string)
    if day_match:
        year, month, day = day_match.groups()
        year_int = int(year)
        month_int = int(month)
        day_int = int(day)

        # Validate ranges
        if year_int < 1000 or year_int > 9999:
            raise ValueError(f"Year out of range (1000-9999): {year}")
        if month_int < 1 or month_int > 12:
            raise ValueError(f"Month out of range (1-12): {month}")
        if day_int < 1 or day_int > 31:
            raise ValueError(f"Day out of range (1-31): {day}")

        # Try to parse as date to validate (e.g., Feb 30 is invalid)
        try:
            date(year_int, month_int, day_int)
        except ValueError as e:
            raise ValueError(f"Invalid date: {date_string} - {str(e)}")

        return (date_string, TemporalPrecision.DAY)

    # LLMs sometimes output datetime strings like "2026-02-22 03:12" or
    # "2026-02-22T14:30:00". Strip time portion and retry with date only.
    datetime_match = re.match(r'^(\d{4}-\d{2}-\d{2})[T\s]', date_string)
    if datetime_match:
        date_only = datetime_match.group(1)
        logger.debug(
            "Stripping time from datetime string",
            raw=date_string,
            date_only=date_only,
        )
        return normalize_temporal_date(date_only)

    # If we get here, format is invalid
    raise ValueError(
        f"Invalid date format: '{date_string}'. "
        f"Expected YYYY, YYYY-MM, or YYYY-MM-DD"
    )


def display_temporal_date(date_string: Optional[str], precision: Optional[str]) -> Optional[str]:
    """
    Display date according to original precision.

    This prevents UI bugs where "2020" (year precision) displays as "January 1, 2020".

    Args:
        date_string: Normalized date in YYYY-MM-DD format
        precision: Original precision ("year"|"month"|"day")

    Returns:
        Date formatted according to original precision

    Examples:
        >>> display_temporal_date("2020-01-01", "year")
        "2020"

        >>> display_temporal_date("2020-05-01", "month")
        "2020-05"

        >>> display_temporal_date("2020-05-15", "day")
        "2020-05-15"

        >>> display_temporal_date(None, None)
        None
    """
    if not date_string or not precision:
        return None

    if precision == TemporalPrecision.YEAR:
        # Return year only: "2020-01-01" → "2020"
        return date_string[:4]

    elif precision == TemporalPrecision.MONTH:
        # Return year-month: "2020-05-01" → "2020-05"
        return date_string[:7]

    else:  # TemporalPrecision.DAY
        # Return full date: "2020-05-15" → "2020-05-15"
        return date_string


def format_temporal_date_human(date_string: Optional[str], precision: Optional[str]) -> Optional[str]:
    """
    Format date in human-readable format.

    Args:
        date_string: Normalized date in YYYY-MM-DD format
        precision: Original precision ("year"|"month"|"day")

    Returns:
        Human-readable date string

    Examples:
        >>> format_temporal_date_human("2020-01-01", "year")
        "2020"

        >>> format_temporal_date_human("2020-05-01", "month")
        "May 2020"

        >>> format_temporal_date_human("2020-05-15", "day")
        "May 15, 2020"
    """
    if not date_string or not precision:
        return None

    try:
        # Parse the date
        parts = date_string.split('-')
        year = int(parts[0])
        month = int(parts[1])
        day = int(parts[2]) if len(parts) > 2 else 1

        # Month names
        month_names = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ]

        if precision == TemporalPrecision.YEAR:
            return str(year)

        elif precision == TemporalPrecision.MONTH:
            return f"{month_names[month - 1]} {year}"

        else:  # TemporalPrecision.DAY
            return f"{month_names[month - 1]} {day}, {year}"

    except Exception as e:
        logger.warning("Failed to format temporal date", date=date_string, precision=precision, error=str(e))
        return date_string


def validate_temporal_confidence(confidence: Optional[float]) -> Optional[float]:
    """
    Validate and normalize temporal confidence score.

    Args:
        confidence: Confidence score (0-1)

    Returns:
        Normalized confidence or None if invalid

    Examples:
        >>> validate_temporal_confidence(0.9)
        0.9

        >>> validate_temporal_confidence(1.5)
        1.0

        >>> validate_temporal_confidence(-0.1)
        0.0

        >>> validate_temporal_confidence(None)
        None
    """
    if confidence is None:
        return None

    # Clamp to 0-1 range
    if confidence < 0:
        logger.warning("Temporal confidence < 0, clamping to 0", confidence=confidence)
        return 0.0

    if confidence > 1:
        logger.warning("Temporal confidence > 1, clamping to 1", confidence=confidence)
        return 1.0

    return confidence


def should_store_temporal(confidence: Optional[float], threshold: float = 0.3) -> bool:
    """
    Determine if temporal information should be stored based on confidence.

    Per BITEMPORAL_MODEL_STUDY.md: Only store temporal info if confidence >= 0.3
    to prevent hallucinated dates.

    Args:
        confidence: Temporal confidence (0-1)
        threshold: Minimum confidence to store (default: 0.3)

    Returns:
        True if should store, False otherwise

    Examples:
        >>> should_store_temporal(0.9)
        True

        >>> should_store_temporal(0.5)
        True

        >>> should_store_temporal(0.2)
        False

        >>> should_store_temporal(None)
        False
    """
    if confidence is None:
        return False

    return confidence >= threshold


def flag_for_review(confidence: Optional[float]) -> bool:
    """
    Determine if temporal extraction should be flagged for manual review.

    Per BITEMPORAL_MODEL_STUDY.md: Flag if confidence is 0.3-0.5 (stored but uncertain).

    Args:
        confidence: Temporal confidence (0-1)

    Returns:
        True if should flag for review, False otherwise

    Examples:
        >>> flag_for_review(0.9)
        False

        >>> flag_for_review(0.4)
        True

        >>> flag_for_review(0.2)
        False

        >>> flag_for_review(None)
        False
    """
    if confidence is None:
        return False

    return 0.3 <= confidence < 0.5
