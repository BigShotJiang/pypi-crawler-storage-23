"""
Graph Analysis Service using native algorithms for superior performance.

This service provides:
- native Louvain community detection for topic clustering (entities + memories)
- native PageRank centrality for node importance (entities + memories)
- Direct graph database algorithms without data export overhead
- Integrated with KuzuDB's algo extension for optimal performance
- LLM-powered community summarization with context window handling
"""

import real_ladybug as kuzu
import datetime
from typing import Dict, Any, Optional, List
import structlog

from nowledge_graph_server.config import get_settings
from nowledge_graph_server.services.local_llm import get_local_llm_service
from nowledge_graph_server.services.json_utils import clean_and_parse_json


logger = structlog.get_logger(__name__)


class GraphAnalysisService:
    """Service for advanced graph analysis using native algorithms."""

    def __init__(self, conn: kuzu.Connection):
        """Initialize with connection."""
        self.conn = conn
        self._initialized = False
        self._algo_extension_loaded = False

    async def initialize(self) -> None:
        """Initialize the graph analysis service and load algo extension."""
        if self._initialized:
            return

        logger.debug("Initializing Graph Analysis Service with native algorithms")

        try:
            # Check if extension is already loaded
            try:
                result = self.conn.execute("CALL show_loaded_extensions() RETURN *")
                assert isinstance(result, kuzu.QueryResult)

                extension_loaded = False
                while result.has_next():
                    row = result.get_next()
                    if row[0] == "ALGO":  # type: ignore
                        extension_loaded = True
                        break

                if not extension_loaded:
                    # Install and load the algo extension
                    self.conn.execute("INSTALL algo; LOAD algo;")
                    logger.info("algo extension loaded successfully")
                else:
                    logger.debug("algo extension already loaded")

                self._algo_extension_loaded = True

            except Exception as e:
                # If we can't check, try to load anyway
                logger.warning(
                    "Cannot check loaded extensions, attempting to load algo extension",
                    error=str(e),
                )
                try:
                    self.conn.execute("INSTALL algo")
                    self.conn.execute("LOAD algo")
                    self._algo_extension_loaded = True
                    logger.info("algo extension loaded successfully")
                except Exception as load_error:
                    # Handle the already loaded case
                    if "already loaded" in str(load_error).lower():
                        self._algo_extension_loaded = True
                        logger.info("algo extension was already loaded")
                    else:
                        logger.error(
                            "Failed to load algo extension",
                            error=str(load_error),
                        )
                        self._algo_extension_loaded = False

        except Exception as e:
            logger.error("Failed to initialize algo extension", error=str(e))
            self._algo_extension_loaded = False

        self._initialized = True

    async def cleanup(self) -> None:
        """Clean up resources."""
        self._initialized = False
        logger.info("Graph Analysis Service cleaned up")

    async def detect_communities_with_memories(
        self,
        resolution: float = 1.0,
        max_iterations: int = 20,
        include_summarization: bool = False,
    ) -> Dict[str, Any]:
        """
        Detect communities using native Louvain algorithm on entities.

        Args:
            resolution: Resolution parameter for community detection (higher = more communities)
            max_iterations: Maximum number of iterations for the algorithm
            include_summarization: Whether to generate LLM summaries for communities

        Returns:
            Dictionary with communities, modularity score, and analysis
        """
        logger.info(
            "Starting native Louvain community detection on entities and memories"
        )

        if not self._algo_extension_loaded:
            logger.error("algo extension not available")
            return self._empty_community_result()

        try:
            return await self._native_community_detection(
                resolution, max_iterations, include_summarization
            )
        except Exception as e:
            logger.error("Community detection failed", error=str(e))
            return self._empty_community_result()

    async def detect_communities(
        self,
        resolution: float = 1.0,
        max_iterations: int = 20,
        include_summarization: bool = False,
    ) -> Dict[str, Any]:
        """Alias for detect_communities_with_memories for backward compatibility."""
        return await self.detect_communities_with_memories(
            resolution, max_iterations, include_summarization
        )

    async def calculate_centrality_with_memories(
        self, persist_results: bool = True
    ) -> Dict[str, Any]:
        """
        Calculate PageRank centrality using native algorithm on entities.

        Args:
            persist_results: Whether to persist results as node properties

        Returns:
            Dictionary with centrality scores for entities and memories
        """
        logger.info(
            "Calculating PageRank centrality with native algorithm on entities and memories"
        )

        if not self._algo_extension_loaded:
            logger.error("algo extension not available")
            return self._empty_centrality_result()

        try:
            return await self._native_pagerank_calculation_unified(persist_results)
        except Exception as e:
            logger.error("PageRank calculation failed", error=str(e))
            return self._empty_centrality_result()

    async def calculate_centrality(
        self, persist_results: bool = True
    ) -> Dict[str, Any]:
        """Alias for calculate_centrality_with_memories for backward compatibility."""
        return await self.calculate_centrality_with_memories(persist_results)

    async def _native_community_detection(
        self,
        resolution: float = 1.0,
        max_iterations: int = 20,
        include_summarization: bool = False,
    ) -> Dict[str, Any]:
        """Native Louvain algorithm implementation."""
        try:
            # Create entity-only projected graph due to limitations with mixed node types
            # NOTE: This always recreates the projected graph to ensure current edges are included
            await self._ensure_entity_only_projected_graph()

            # Debug: Count entities and edges before running Louvain
            try:
                entity_count_result = self.conn.execute(
                    "MATCH (e:Entity) RETURN COUNT(e)"
                )
                assert isinstance(entity_count_result, kuzu.QueryResult)
                entity_count = 0
                if entity_count_result.has_next():
                    entity_count = int(entity_count_result.get_next()[0])  # type: ignore

                edge_count_result = self.conn.execute(
                    "MATCH (e1:Entity)-[r:RELATES_TO]->(e2:Entity) RETURN COUNT(r)"
                )
                assert isinstance(edge_count_result, kuzu.QueryResult)
                edge_count = 0
                if edge_count_result.has_next():
                    edge_count = int(edge_count_result.get_next()[0])  # type: ignore

                logger.info(
                    "Running Louvain community detection",
                    entity_count=entity_count,
                    relates_to_edge_count=edge_count,
                )

                if edge_count == 0:
                    logger.warning(
                        "No RELATES_TO edges found between entities. "
                        "Louvain algorithm requires edges to detect communities. "
                        "All nodes will be in a single community."
                    )
                    
                    # Additional diagnostic: Check if edges exist in metadata but not as graph edges
                    try:
                        metadata_rel_query = self.conn.execute("""
                            MATCH (m:Memory)
                            WHERE m.metadata IS NOT NULL
                            RETURN m.id, m.metadata
                            LIMIT 5
                        """)
                        assert isinstance(metadata_rel_query, kuzu.QueryResult)
                        
                        memories_with_rels = 0
                        while metadata_rel_query.has_next():
                            row = metadata_rel_query.get_next()
                            metadata_str = row[1]  # type: ignore
                            if metadata_str and "extracted_relationships" in str(metadata_str):
                                import json
                                try:
                                    metadata = json.loads(metadata_str) if isinstance(metadata_str, str) else metadata_str
                                    rels = metadata.get("extracted_relationships", [])
                                    if rels:
                                        memories_with_rels += 1
                                        logger.warning(
                                            "Memory has extracted_relationships in metadata but no RELATES_TO edges in graph",
                                            memory_id=row[0],  # type: ignore
                                            relationships_in_metadata=len(rels),
                                        )
                                except Exception:
                                    pass
                        
                        if memories_with_rels > 0:
                            logger.error(
                                "CRITICAL: Relationships exist in Memory metadata but NOT as RELATES_TO edges in the graph! "
                                "This indicates the relationship writing code is not executing properly."
                            )
                    except Exception as meta_error:
                        logger.debug("Failed to check metadata", error=str(meta_error))
                        
            except Exception as count_error:
                logger.debug("Failed to count entities/edges", error=str(count_error))

            # Run native Louvain algorithm using correct syntax from documentation
            result = self.conn.execute(f"""
                CALL louvain('EntityGraph', 
                    maxPhases := 20,
                    maxIterations := {max_iterations})
                RETURN node, louvain_id
            """)
            assert isinstance(result, kuzu.QueryResult)

            # Process results
            communities: Dict[int, Dict[str, Any]] = {}
            node_communities: Dict[str, int] = {}

            while result.has_next():
                row = result.get_next()
                node_obj = row[0]  # type: ignore - This is a dictionary
                louvain_id = int(row[1])  # type: ignore - Ensure it's an integer

                # Extract the user-defined ID from the node dictionary
                if isinstance(node_obj, dict) and "id" in node_obj:
                    node_id = str(node_obj["id"])  # type: ignore[union-attr]
                else:
                    logger.warning(
                        f"Node object missing 'id' property or not a dict: {node_obj}"
                    )
                    continue

                node_communities[node_id] = louvain_id

                if louvain_id not in communities:
                    communities[louvain_id] = {
                        "id": louvain_id,
                        "members": [],
                        "member_count": 0,
                        "entities": [],
                        "memories": [],
                    }

                communities[louvain_id]["members"].append(node_id)  # type: ignore[arg-type]
                communities[louvain_id]["member_count"] += 1
                communities[louvain_id]["entities"].append(node_id)  # type: ignore[arg-type]  # All from EntityGraph

            # Diagnostic: Check if all nodes ended up in community -1 (isolated nodes)
            if len(communities) == 1 and -1 in communities:
                logger.warning(
                    "All nodes assigned to community -1, indicating isolated nodes with no edges. "
                    "This typically means no RELATES_TO relationships exist between entities in the projected graph.",
                    total_nodes=len(node_communities),
                    community_ids=list(communities.keys()),
                )

            logger.info(
                "Louvain community detection completed",
                num_communities=len(communities),
                total_nodes=len(node_communities),
                community_ids=list(communities.keys()),
            )

            # Calculate modularity (simplified for entity-only)
            modularity = await self._calculate_modularity_entity_only(communities)  # type: ignore[attr-defined]

            # Generate summaries if requested
            if include_summarization:
                for community_id, community_data in communities.items():  # type: ignore[arg-type]
                    logger.debug(
                        f"Processing community {community_id}, type: {type(community_data)}, data: {community_data}"  # type: ignore[arg-type]
                    )
                    if isinstance(community_data, dict):  # type: ignore[arg-type]
                        summary = await self._generate_community_summary(community_data)  # type: ignore[attr-defined]
                        logger.info(
                            f"Generated summary for community {community_id}: {summary}"
                        )
                        community_data["ai_summary"] = summary

                        # Extract title from structured summary and update community name
                        if summary and summary.startswith("TITLE:"):
                            # Clean up quotes and whitespace
                            cleaned_summary = summary.strip().strip("\"'")
                            lines = cleaned_summary.split("\n")
                            if len(lines) >= 2:
                                extracted_title = lines[0].replace("TITLE:", "").strip()
                                # Update the community name with the extracted title
                                community_data["name"] = extracted_title
                                logger.info(
                                    f"Updated community {community_id} name to: {extracted_title}"
                                )
                    else:
                        logger.error(
                            f"Community data is not a dict: {community_data} (type: {type(community_data)})"
                        )

            return {
                "communities": communities,
                "node_communities": node_communities,
                "modularity": modularity,
                "algorithm": "louvain_entities",
                "resolution": resolution,
                "num_communities": len(communities),  # type: ignore[arg-type]
                "quality": self._get_modularity_quality(modularity),
            }

        except Exception as e:
            logger.error("Native community detection failed", error=str(e))
            raise

    async def _native_pagerank_calculation_unified(
        self, persist_results: bool = True
    ) -> Dict[str, Any]:
        """Native PageRank algorithm implementation for unified graph (entities + memories)."""
        try:
            # Create unified projected graph with both entities and memories
            await self._ensure_projected_graph_with_memories()

            # Run native PageRank algorithm on unified graph
            result = self.conn.execute(f"""
                CALL page_rank('UnifiedGraph', 
                    dampingFactor := 0.85,
                    maxIterations := 20,
                    tolerance := 0.0000001,
                    normalizeInitial := true)
                RETURN node, rank
            """)
            assert isinstance(result, kuzu.QueryResult)

            # Process results - separate entity and memory PageRank scores
            entity_pagerank = {}
            memory_pagerank = {}

            while result.has_next():
                row = result.get_next()
                node_obj = row[0]  # type: ignore - This is a dictionary
                rank = float(row[1])  # type: ignore

                # Extract the user-defined ID and determine node type
                if isinstance(node_obj, dict) and "id" in node_obj:
                    user_id = str(node_obj["id"])  # type: ignore[union-attr]

                    # Determine if this is an entity or memory based on node properties
                    if "entity_type" in node_obj:
                        # This is an entity
                        entity_pagerank[user_id] = rank
                    elif "role" in node_obj or "title" in node_obj:
                        # This is a memory
                        memory_pagerank[user_id] = rank
                    else:
                        # Fallback: check if it's in entity or memory table
                        # For now, assume it's an entity if we can't determine
                        entity_pagerank[user_id] = rank
                        logger.warning(
                            f"Could not determine node type for {user_id}, treating as entity"
                        )
                else:
                    logger.warning(
                        f"Node object missing 'id' property or not a dict: {node_obj}"
                    )

            # Persist results if requested
            if persist_results:
                await self._persist_pagerank_scores(entity_pagerank, memory_pagerank)  # type: ignore[attr-defined]

            # Calculate top entities and memories
            top_entities = sorted(  # type: ignore[arg-type]
                entity_pagerank.items(),
                key=lambda x: x[1],
                reverse=True,  # type: ignore[arg-type]
            )[:10]  # type: ignore[arg-type]
            top_memories = sorted(  # type: ignore[arg-type]
                memory_pagerank.items(),
                key=lambda x: x[1],
                reverse=True,  # type: ignore[arg-type]
            )[:10]

            # Find most central entity
            most_central_entity: Optional[Dict[str, Any]] = None  # type: ignore[assignment]
            if top_entities:
                most_central_id, most_central_score = top_entities[0]  # type: ignore[arg-type]
                # Get entity name from database
                try:
                    entity_query = "MATCH (e:Entity {id: $entity_id}) RETURN e.name"
                    entity_result = self.conn.execute(
                        entity_query, {"entity_id": most_central_id}
                    )
                    # Handle result format
                    if isinstance(entity_result, list) and entity_result:
                        entity_result = entity_result[0]

                    if entity_result.has_next():  # type: ignore
                        entity_name = entity_result.get_next()[0]  # type: ignore
                        most_central_entity: Dict[str, Any] = {
                            "id": most_central_id,
                            "name": entity_name or most_central_id,
                            "score": most_central_score,
                        }
                except Exception as e:
                    logger.warning(
                        f"Failed to get entity name for {most_central_id}", error=str(e)
                    )
                    most_central_entity = {
                        "id": most_central_id,
                        "name": most_central_id,
                        "score": most_central_score,
                    }

            return {
                "entity_pagerank": entity_pagerank,
                "memory_pagerank": memory_pagerank,
                "node_scores": {**entity_pagerank, **memory_pagerank},
                "top_entities": [
                    {"id": eid, "score": score}
                    for eid, score in top_entities  # type: ignore[arg-type]
                ],
                "top_memories": [
                    {"id": mid, "score": score}
                    for mid, score in top_memories  # type: ignore[arg-type]
                ],
                "analysis": {
                    "most_central_entity": most_central_entity,
                    "total_entities": len(entity_pagerank),  # type: ignore[arg-type]
                    "total_memories": len(memory_pagerank),  # type: ignore[arg-type]
                    "avg_entity_score": sum(entity_pagerank.values())  # type: ignore[arg-type]
                    / len(entity_pagerank)  # type: ignore[arg-type]
                    if entity_pagerank
                    else 0,
                    "avg_memory_score": sum(memory_pagerank.values())  # type: ignore[arg-type]
                    / len(memory_pagerank)  # type: ignore[arg-type]
                    if memory_pagerank
                    else 0,
                },
                "algorithm": "pagerank_unified",
                "iterations": 20,
                "total_nodes": len(entity_pagerank) + len(memory_pagerank),  # type: ignore[arg-type]
                "computed_at": datetime.datetime.now().isoformat(),
            }

        except Exception as e:
            logger.error("Native unified PageRank calculation failed", error=str(e))
            # Fallback to entity-only calculation
            logger.info("Falling back to entity-only PageRank calculation")
            return await self._native_pagerank_calculation_entity_only(persist_results)

    async def _native_pagerank_calculation_entity_only(
        self, persist_results: bool = True
    ) -> Dict[str, Any]:
        """Native PageRank algorithm implementation for entities only (fallback)."""
        try:
            # Create entity-only projected graph due to limitations with mixed node types
            await self._ensure_entity_only_projected_graph()

            # Run native PageRank algorithm using correct syntax from documentation
            result = self.conn.execute(f"""
                CALL page_rank('EntityGraph', 
                    dampingFactor := 0.85,
                    maxIterations := 20,
                    tolerance := 0.0000001,
                    normalizeInitial := true)
                RETURN node, rank
            """)
            assert isinstance(result, kuzu.QueryResult)

            # Process results - extract entity PageRank scores
            entity_pagerank = {}
            memory_pagerank = {}  # Empty since we're only processing entities

            while result.has_next():
                row = result.get_next()
                node_obj = row[0]  # type: ignore - This is a dictionary
                rank = float(row[1])  # type: ignore

                # Extract the user-defined ID from the node dictionary
                if isinstance(node_obj, dict) and "id" in node_obj:
                    user_id = str(node_obj["id"])  # type: ignore[union-attr]
                    entity_pagerank[user_id] = rank
                else:
                    logger.warning(
                        f"Node object missing 'id' property or not a dict: {node_obj}"
                    )

            # Persist results if requested
            if persist_results:
                await self._persist_pagerank_scores(entity_pagerank, memory_pagerank)  # type: ignore[attr-defined]

            # Calculate top entities
            top_entities = sorted(  # type: ignore[arg-type]
                entity_pagerank.items(),
                key=lambda x: x[1],
                reverse=True,  # type: ignore[arg-type]
            )[:10]

            # Find most central entity
            most_central_entity: Optional[Dict[str, Any]] = None  # type: ignore[assignment]
            if top_entities:
                most_central_id, most_central_score = top_entities[0]  # type: ignore[arg-type]
                # Get entity name from database
                try:
                    entity_query = "MATCH (e:Entity {id: $entity_id}) RETURN e.name"
                    entity_result = self.conn.execute(
                        entity_query, {"entity_id": most_central_id}
                    )
                    # Handle result format
                    if isinstance(entity_result, list) and entity_result:
                        entity_result = entity_result[0]

                    if entity_result.has_next():  # type: ignore
                        entity_name = entity_result.get_next()[0]  # type: ignore
                        most_central_entity = {
                            "id": most_central_id,
                            "name": entity_name or most_central_id,
                            "score": most_central_score,
                        }
                except Exception as e:
                    logger.warning(
                        f"Failed to get entity name for {most_central_id}", error=str(e)
                    )
                    most_central_entity = {
                        "id": most_central_id,
                        "name": most_central_id,
                        "score": most_central_score,
                    }

            return {
                "entity_pagerank": entity_pagerank,
                "memory_pagerank": memory_pagerank,
                "node_scores": {**entity_pagerank, **memory_pagerank},
                "top_entities": [
                    {"id": eid, "score": score}
                    for eid, score in top_entities  # type: ignore[arg-type]
                ],
                "top_memories": [],
                "analysis": {
                    "most_central_entity": most_central_entity,
                    "total_entities": len(entity_pagerank),  # type: ignore[arg-type]
                    "total_memories": 0,
                    "avg_entity_score": sum(entity_pagerank.values())  # type: ignore[arg-type]
                    / len(entity_pagerank)  # type: ignore[arg-type]
                    if entity_pagerank
                    else 0,
                    "avg_memory_score": 0,
                },
                "algorithm": "pagerank_entities",
                "iterations": 20,
                "total_nodes": len(entity_pagerank) + len(memory_pagerank),  # type: ignore[arg-type]
                "computed_at": datetime.datetime.now().isoformat(),
            }

        except Exception as e:
            logger.error("Native PageRank calculation failed", error=str(e))
            raise

    async def _ensure_projected_graph_with_memories(self) -> None:
        """Create projected graph for algorithms including both entities and memories.
        
        IMPORTANT: Always drops and recreates the projected graph to ensure it reflects
        the current state of the database. Projected graphs in KuzuDB are snapshots and
        do not automatically update when the underlying data changes.
        """
        try:
            # Check if projected graph already exists and drop it if so
            # We must recreate to capture any new edges added since last creation
            try:
                result = self.conn.execute("CALL SHOW_PROJECTED_GRAPHS() RETURN *")
                assert isinstance(result, kuzu.QueryResult)
                graph_exists = False

                while result.has_next():
                    row = result.get_next()
                    graph_name = row[0]  # type: ignore
                    if graph_name == "UnifiedGraph":
                        graph_exists = True
                        break

                if graph_exists:
                    # Drop the existing projected graph to ensure fresh data
                    logger.info("Dropping existing 'UnifiedGraph' to refresh with current data")
                    self.conn.execute("CALL DROP_PROJECTED_GRAPH('UnifiedGraph')")

            except Exception as e:
                logger.warning(
                    "Could not check/drop existing projected graphs", error=str(e)
                )

            # Create projected graph using correct syntax from documentation with current data
            self.conn.execute("""
                CALL PROJECT_GRAPH('UnifiedGraph', 
                    ['Entity', 'Memory'], 
                    ['RELATES_TO', 'MENTIONS'])
            """)
            logger.info(
                "Created projected graph 'UnifiedGraph' with entities, memories, and current edges"
            )

        except Exception as e:
            logger.error("Failed to ensure projected graph with memories", error=str(e))
            raise

    async def _ensure_entity_only_projected_graph(self) -> None:
        """Create projected graph with Entity nodes only for algorithm processing.
        
        IMPORTANT: Always drops and recreates the projected graph to ensure it reflects
        the current state of the database. Projected graphs in KuzuDB are snapshots and
        do not automatically update when the underlying data changes. This was causing
        community detection to fail when RELATES_TO edges were added after the projected
        graph was first created.
        """
        try:
            # Check if projected graph already exists and drop it if so
            # We must recreate to capture any new edges added since last creation
            try:
                result = self.conn.execute("CALL SHOW_PROJECTED_GRAPHS() RETURN *")
                assert isinstance(result, kuzu.QueryResult)
                graph_exists = False

                while result.has_next():
                    row = result.get_next()
                    graph_name = row[0]  # type: ignore
                    if graph_name == "EntityGraph":
                        graph_exists = True
                        break

                if graph_exists:
                    # Drop the existing projected graph to ensure fresh data
                    logger.info("Dropping existing 'EntityGraph' to refresh with current data")
                    self.conn.execute("CALL DROP_PROJECTED_GRAPH('EntityGraph')")

            except Exception as e:
                logger.warning(
                    "Could not check/drop existing projected graphs", error=str(e)
                )

            # Create projected graph for Entity nodes only with current data
            self.conn.execute("""
                CALL PROJECT_GRAPH('EntityGraph', 
                    ['Entity'], 
                    ['RELATES_TO'])
            """)
            logger.info("Created projected graph 'EntityGraph' with entities and current edges")

        except Exception as e:
            logger.error("Failed to create entity-only projected graph", error=str(e))
            raise

    async def _calculate_network_density_unified(self) -> float:
        """Calculate network density for unified graph including both entities and memories."""
        try:
            # Get total number of nodes
            nodes_result = self.conn.execute("""
                MATCH (n:Entity) RETURN COUNT(n) as entity_count
                UNION ALL
                MATCH (n:Memory) RETURN COUNT(n) as memory_count
            """)

            assert isinstance(nodes_result, kuzu.QueryResult)
            total_nodes = 0
            while nodes_result.has_next():
                row = nodes_result.get_next()
                total_nodes += int(row[0])  # type: ignore

            if total_nodes <= 1:
                return 0.0

            # Get total number of relationships
            rel_result = self.conn.execute("""
                MATCH ()-[r:RELATES_TO]->() RETURN COUNT(r) as count
                UNION ALL
                MATCH ()-[r:MENTIONS]->() RETURN COUNT(r) as count
            """)
            assert isinstance(rel_result, kuzu.QueryResult)
            rel_count = 0
            while rel_result.has_next():
                row = rel_result.get_next()
                rel_count += int(row[0])  # type: ignore

            # Calculate density
            max_possible_edges = total_nodes * (total_nodes - 1)
            density = (
                (2 * rel_count) / max_possible_edges if max_possible_edges > 0 else 0.0
            )

            return density

        except Exception as e:
            logger.error("Failed to calculate network density", error=str(e))
            return 0.0

    async def _calculate_network_density(self) -> float:
        """Alias for _calculate_network_density_unified for backward compatibility."""
        return await self._calculate_network_density_unified()

    async def _calculate_modularity_entity_only(
        self, communities_dict: Dict[int, Dict[str, Any]]
    ) -> float:
        """Calculate modularity for entity-only graph."""
        try:
            if not communities_dict:
                return 0.0

            # Get total number of Entity-Entity edges
            ee_result = self.conn.execute("""
                MATCH (e1:Entity)-[r:RELATES_TO]->(e2:Entity)
                RETURN COUNT(r) as edge_count
            """)
            assert isinstance(ee_result, kuzu.QueryResult)
            total_edges = 0
            if ee_result.has_next():
                row = ee_result.get_next()
                total_edges = int(row[0])  # type: ignore

            if total_edges == 0:
                return 0.0

            # Calculate modularity
            modularity = 0.0

            for community_id, community_data in communities_dict.items():  # type: ignore[arg-type]
                # community_data is the dictionary, community_id is the integer key
                if (
                    not isinstance(community_data, dict)  # type: ignore[arg-type]
                    or "members" not in community_data
                ):
                    continue

                node_ids = community_data["members"]
                if not node_ids:
                    continue

                # Calculate internal connections within this community (entity-only)
                internal_connections = (
                    await self._calculate_internal_connections_entity_only(node_ids)
                )

                # Calculate expected connections (simplified)
                community_size = len(node_ids)
                if community_size > 1:
                    expected_connections = (community_size * (community_size - 1)) / (
                        2 * total_edges
                    )
                    # Add to modularity
                    modularity += (
                        internal_connections / total_edges
                    ) - expected_connections

            return modularity

        except Exception as e:
            logger.error("Failed to calculate modularity", error=str(e))
            return 0.0

    async def _calculate_internal_connections_entity_only(
        self, node_ids: list[str]
    ) -> int:
        """Calculate internal connections within a community for entities only."""
        try:
            if not node_ids or len(node_ids) < 2:
                return 0

            # Use user-defined IDs for querying
            node_ids_quoted = ", ".join([f"'{node_id}'" for node_id in node_ids])

            # Count Entity-Entity internal connections using user-defined IDs
            try:
                ee_result = self.conn.execute(f"""
                    MATCH (e1:Entity)-[r:RELATES_TO]->(e2:Entity)
                    WHERE e1.id IN [{node_ids_quoted}] AND e2.id IN [{node_ids_quoted}]
                    RETURN COUNT(r) as connection_count
                """)
                assert isinstance(ee_result, kuzu.QueryResult)
                if ee_result.has_next():
                    row = ee_result.get_next()
                    return int(row[0])  # type: ignore
            except Exception as e:
                logger.warning(
                    "Failed to count Entity-Entity internal connections", error=str(e)
                )

            return 0

        except Exception as e:
            logger.error("Failed to calculate internal connections", error=str(e))
            return 0

    async def _persist_pagerank_scores(
        self, entity_pagerank: Dict[str, float], memory_pagerank: Dict[str, float]
    ) -> None:
        """Persist PageRank scores as node properties using user-defined IDs."""
        try:
            # Persist entity PageRank scores using user-defined ID
            for user_id, score in entity_pagerank.items():
                try:
                    self.conn.execute(f"""
                        MATCH (e:Entity)
                        WHERE e.id = '{user_id}'
                        SET e.pagerank_score = {score}
                    """)
                except Exception as e:
                    logger.warning(
                        f"Failed to persist PageRank score for entity {user_id}",
                        error=str(e),
                    )

            # Persist memory PageRank scores using user-defined ID
            for user_id, score in memory_pagerank.items():
                try:
                    self.conn.execute(f"""
                        MATCH (m:Memory)
                        WHERE m.id = '{user_id}'
                        SET m.pagerank_score = {score}
                    """)
                except Exception as e:
                    logger.warning(
                        f"Failed to persist PageRank score for memory {user_id}",
                        error=str(e),
                    )

            logger.info(
                "PageRank scores persisted successfully",
                entities_processed=len(entity_pagerank),
                memories_processed=len(memory_pagerank),
            )

        except Exception as e:
            logger.error("Failed to persist PageRank scores", error=str(e))
            # Don't raise - this is not critical for the calculation itself

    async def undo_pagerank_scores(self) -> Dict[str, Any]:
        """Remove PageRank scores from all nodes."""
        try:
            # Remove PageRank scores from entities
            self.conn.execute("""
                MATCH (e:Entity) WHERE e.pagerank_score IS NOT NULL
                SET e.pagerank_score = NULL
            """)

            # Remove PageRank scores from memories
            self.conn.execute("""
                MATCH (m:Memory) WHERE m.pagerank_score IS NOT NULL
                SET m.pagerank_score = NULL
            """)

            logger.info("PageRank scores removed from all nodes")

            return {
                "success": True,
                "message": "PageRank scores removed from all nodes",
            }

        except Exception as e:
            logger.error("Failed to remove PageRank scores", error=str(e))
            return {"success": False, "error": str(e)}

    async def _generate_community_summary(
        self, community_data: Dict[str, Any]
    ) -> Optional[str]:
        """Generate AI summary for a community using LLM with actual edge content."""
        try:
            # Get community members (entities)
            members = community_data.get("members", [])
            entities = community_data.get("entities", [])

            if not members and not entities:
                return None

            # Get actual edge content and entity information
            edge_sentences: List[str] = []
            entity_names: List[str] = []

            if len(entities) >= 2:
                # Get actual relationships with content
                relationship_query = """
                    MATCH (e1:Entity)-[r:RELATES_TO]->(e2:Entity)
                    WHERE e1.id IN $entity_ids AND e2.id IN $entity_ids
                    RETURN e1.name, e2.name, r.relation_type, r.strength, 
                           r.context, r.confidence, e1.entity_type, e2.entity_type
                    ORDER BY r.strength DESC, r.confidence DESC
                    LIMIT 20
                """

                try:
                    result = self.conn.execute(
                        relationship_query, {"entity_ids": entities[:20]}
                    )
                    if isinstance(result, list) and result:
                        result = result[0]

                    while result.has_next():  # type: ignore
                        row = result.get_next()  # type: ignore
                        e1_name = row[0] if row[0] else "Unknown"  # type: ignore
                        e2_name = row[1] if row[1] else "Unknown"  # type: ignore
                        relation_type = row[2] if row[2] else "relates to"  # type: ignore
                        strength = row[3] if row[3] is not None else 0.0  # type: ignore
                        context = row[4] if row[4] else ""  # type: ignore
                        confidence = row[5] if row[5] is not None else 0.0  # type: ignore
                        e1_type = row[6] if row[6] else "concept"  # type: ignore
                        e2_type = row[7] if row[7] else "concept"  # type: ignore

                        # Only include high-quality relationships
                        if strength > 0.3 and confidence > 0.5:
                            # Create natural language sentence
                            relation_text = relation_type.replace("_", " ").lower()  # type: ignore[arg-type]

                            if context:
                                sentence = f"{e1_name} {relation_text} {e2_name} in the context of {context}."
                            else:
                                sentence = f"{e1_name} {relation_text} {e2_name}."

                            edge_sentences.append(sentence)

                            # Collect entity names
                            if e1_name not in entity_names:
                                entity_names.append(e1_name)  # type: ignore[arg-type]
                            if e2_name not in entity_names:
                                entity_names.append(e2_name)  # type: ignore[arg-type]

                    logger.info(
                        f"Found {len(edge_sentences)} relationship sentences for community summary"
                    )
                except Exception as e:
                    logger.warning(
                        "Failed to fetch relationships for community summary",
                        error=str(e),
                    )

            # If we have relationships, use LLM to generate summary
            if edge_sentences:
                try:
                    # Check LLM availability before attempting to use it
                    from ..utils.llm_availability import check_llm_availability

                    is_available, error_msg = check_llm_availability()
                    if not is_available:
                        logger.info(
                            "Skipping LLM community summary generation - LLM not available",
                            reason=error_msg,
                        )
                        # Return None to indicate LLM summary is not available
                        return None

                    settings = get_settings()
                    llm_service = await get_local_llm_service(
                        cache_dir=str(settings.llm_cache_dir),
                        cache_only=settings.llm_cache_only,
                    )

                    # Create natural language context
                    context_text = " ".join(
                        edge_sentences[:15]
                    )  # Limit to avoid token overflow
                    entity_list = ", ".join(entity_names[:10])  # Top 10 entities

                    # Read user's preferred language for summary output
                    try:
                        from nowledge_graph_server.agent.settings_reader import read_user_profile
                        from nowledge_graph_server.services.remote_llm_prompts import build_language_instruction
                        _profile = read_user_profile()
                        _lang_instruction = build_language_instruction(_profile.get("preferred_language"))
                    except Exception:
                        _lang_instruction = ""

                    # Optimized prompt for reliable JSON generation
                    _lang_line = f"\n{_lang_instruction}" if _lang_instruction else ""
                    prompt = f"""Generate a JSON object with "title" and "summary" fields for this knowledge community.{_lang_line}

The community contains these related concepts: {entity_list}

Relationship context:
{context_text}

Requirements:
- title: A descriptive 3-6 word title for this knowledge community
- summary: A 2-3 sentence summary explaining what these concepts share and how they relate
- Entity names should stay in their original language

Respond with ONLY a valid JSON object, no other text:
{{"title": "...", "summary": "..."}}"""

                    assert llm_service is not None, "LLM service is not initialized"
                    # Set operation context for LangFuse tracking
                    llm_service._current_operation = "graph_analysis"  # type: ignore[attr-defined]
                    
                    # Retry mechanism for JSON generation
                    max_retries = 2
                    response: Optional[str] = None
                    parsed_result: Optional[Dict[str, Any]] = None
                    
                    for attempt in range(max_retries):
                        try:
                            # Don't pass temperature/top_p/etc - _generate_response handles
                            # local (Qwen3 optimized) vs remote (API defaults) internally
                            response = await llm_service._generate_response(  # type: ignore[attr-defined]
                                prompt,
                                max_tokens=256,
                                use_thinking=False,
                            )
                            
                            if response and len(response.strip()) > 10:
                                parsed_result = clean_and_parse_json(response)
                                if parsed_result and isinstance(parsed_result, dict):
                                    title = parsed_result.get("title", "")
                                    summary = parsed_result.get("summary", "")
                                    if title and summary:
                                        break  # Success
                                    else:
                                        logger.debug(f"Attempt {attempt + 1}: Missing title or summary")
                                else:
                                    logger.debug(f"Attempt {attempt + 1}: Failed to parse JSON")
                            else:
                                logger.debug(f"Attempt {attempt + 1}: Empty response")
                        except Exception as e:
                            logger.debug(f"Attempt {attempt + 1} failed: {e}")
                    
                    # Process result
                    if parsed_result and isinstance(parsed_result, dict):
                        title_str: str = str(parsed_result.get("title", "")).strip()
                        summary_str: str = str(parsed_result.get("summary", "")).strip()

                        if title_str and summary_str:
                            logger.info(f"Generated community summary: {title_str}")
                            return f"TITLE: {title_str}\n{summary_str}"
                        else:
                            logger.warning(
                                "JSON response missing title or summary fields",
                                parsed_result=parsed_result,
                            )
                    else:
                        logger.warning(
                            "Could not parse valid JSON from LLM response after retries",
                            response_preview=response[:100] if response else None,
                        )

                except Exception as e:
                    logger.warning(
                        "LLM community summary generation failed", error=str(e)
                    )

            # Simple fallback
            member_count = len(members)
            if member_count <= 3:
                return f"TITLE: Small Group\nSmall community with {member_count} related concepts."
            elif member_count <= 8:
                return f"TITLE: Concept Cluster\nMedium community with {member_count} connected concepts."
            else:
                return f"TITLE: Knowledge Network\nLarge community with {member_count} interconnected concepts."

        except Exception as e:
            logger.error("Failed to generate community summary", error=str(e))
            return None

    async def identify_topic_clusters(
        self, communities: List[Dict[str, Any]], min_cluster_size: int = 3
    ) -> List[Dict[str, Any]]:
        """Identify topic clusters from communities."""
        # This is a placeholder implementation
        clusters: List[Dict[str, Any]] = []

        for i, community in enumerate(communities):
            if community.get("member_count", 0) >= min_cluster_size:
                clusters.append(
                    {
                        "cluster_id": f"cluster_{i}",
                        "topic": f"Topic {i + 1}",
                        "members": community.get("members", []),
                        "size": community.get("member_count", 0),
                        "description": f"Topic cluster with {community.get('member_count', 0)} members",
                    }
                )

        return clusters

    async def analyze_entity_co_occurrence(
        self, memories: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Analyze entity co-occurrence patterns."""
        # This is a placeholder implementation
        co_occurrences: List[Dict[str, Any]] = []

        for i, memory in enumerate(memories):
            co_occurrences.append(
                {
                    "memory_id": memory.get("id", f"mem_{i}"),
                    "entities": memory.get("entities", []),
                    "co_occurrence_count": len(memory.get("entities", [])),
                }
            )

        return co_occurrences

    def _get_modularity_quality(self, modularity: float) -> str:
        """Get quality assessment based on modularity score."""
        if modularity >= 0.3:
            return "excellent"
        elif modularity >= 0.2:
            return "good"
        elif modularity >= 0.1:
            return "moderate"
        else:
            return "poor"

    def _empty_community_result(self) -> Dict[str, Any]:
        """Return empty community detection result."""
        return {
            "communities": {},
            "node_communities": {},
            "modularity": 0.0,
            "algorithm": "none",
            "resolution": 1.0,
            "num_communities": 0,
            "quality": "poor",
            "error": "Community detection failed",
        }

    def _empty_centrality_result(self) -> Dict[str, Any]:
        """Return empty centrality calculation result."""
        return {
            "entity_pagerank": {},
            "memory_pagerank": {},
            "node_scores": {},
            "algorithm": "none",
            "iterations": 0,
            "total_nodes": 0,
            "error": "Centrality calculation failed",
        }


def get_graph_analysis_service(conn: kuzu.Connection) -> GraphAnalysisService:
    """Get a GraphAnalysisService instance."""
    return GraphAnalysisService(conn)
