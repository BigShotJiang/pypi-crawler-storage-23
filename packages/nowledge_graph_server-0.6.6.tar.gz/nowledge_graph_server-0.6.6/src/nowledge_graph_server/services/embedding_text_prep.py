"""Embedding text preparation service.

This service prepares text for embedding by summarizing content that exceeds
the embedding model's token limit.

For search embeddings (Qwen3-Embedding / BGE-M3):
- Max sequence length: 8192 tokens
- In practice, we still limit to avoid excessive computation

When content is too long:
1. First try to use LLM to create a search-optimized summary
2. If LLM is not available, fall back to truncation (handled in embedding service)

The full content is always stored in the database - this service only
prepares text for the embedding vector.
"""

import structlog
from typing import Optional, Tuple

logger = structlog.get_logger(__name__)

# Embedding model constraints for context embeddings
# Qwen3-Embedding/BGE-M3 have 8192 token limit, but we use shorter limits for efficiency
# With safety margin, we target ~7 tokens
# Conservative estimate: 2 chars per token for mixed content
MAX_EMBEDDING_TOKENS = 7680
CHARS_PER_TOKEN_ESTIMATE = 2
MAX_EMBEDDING_CHARS = MAX_EMBEDDING_TOKENS * CHARS_PER_TOKEN_ESTIMATE  # ~15,360 chars

# Note: Search embeddings (Qwen3/BGE-M3) have much larger limits (8192 tokens)
# but we use summarization for consistency and to improve search quality

# Prompt for creating search-optimized summaries
EMBEDDING_SUMMARY_PROMPT = """You are helping prepare text for semantic search indexing. Your task is to create a CONCISE summary that preserves the key searchable concepts.

ORIGINAL TEXT:
{content}

Create a summary that:
1. Is under 800 characters
2. Preserves ALL key concepts, entities, and technical terms
3. Maintains the core meaning and relationships
4. Uses keywords that someone might search for
5. Omits filler words and redundant explanations

Respond with ONLY the summary text, no explanation or metadata.

SUMMARY:"""


async def prepare_text_for_embedding(
    content: str,
    title: Optional[str] = None,
    llm_service: Optional[object] = None,
) -> Tuple[str, bool]:
    """Prepare text for embedding, summarizing if necessary.
    
    Args:
        content: The full memory content
        title: Optional title to include
        llm_service: Optional LocalLLMService for summarization
        
    Returns:
        Tuple of (text_for_embedding, was_summarized)
    """
    # Combine title and content as the embedding service does
    semantic_field = f"{title or ''}\n{content}".strip()
    
    # Check if text is short enough for embedding
    if len(semantic_field) <= MAX_EMBEDDING_CHARS:
        logger.debug(
            "Content within embedding limit, no summarization needed",
            content_length=len(semantic_field),
            max_chars=MAX_EMBEDDING_CHARS,
        )
        return semantic_field, False
    
    logger.info(
        "Content exceeds embedding limit, attempting LLM summarization",
        content_length=len(semantic_field),
        max_chars=MAX_EMBEDDING_CHARS,
    )
    
    # Try LLM summarization
    if llm_service is not None:
        try:
            summary = await _summarize_for_embedding(semantic_field, llm_service)
            if summary and len(summary) <= MAX_EMBEDDING_CHARS:
                logger.info(
                    "Successfully summarized content for embedding",
                    original_length=len(semantic_field),
                    summary_length=len(summary),
                )
                return summary, True
            elif summary:
                logger.warning(
                    "LLM summary still too long, will be truncated by embedding service",
                    summary_length=len(summary),
                    max_chars=MAX_EMBEDDING_CHARS,
                )
                # Return the summary anyway - embedding service will truncate
                return summary, True
        except Exception as e:
            logger.warning(
                "LLM summarization failed, falling back to truncation",
                error=str(e),
            )
    else:
        logger.debug(
            "No LLM service available for summarization, embedding service will truncate",
        )
    
    # If LLM not available or failed, return original text
    # The embedding service will handle truncation
    return semantic_field, False


async def _summarize_for_embedding(content: str, llm_service: object) -> Optional[str]:
    """Use LLM to create a search-optimized summary.
    
    Args:
        content: The text to summarize
        llm_service: LocalLLMService instance
        
    Returns:
        The summarized text, or None if summarization failed
    """
    # Check if LLM service has the required method
    if not hasattr(llm_service, '_generate_response'):
        logger.warning("LLM service does not have _generate_response method")
        return None
    
    # Check if service is initialized
    if hasattr(llm_service, '_initialized') and not llm_service._initialized:  # type: ignore
        logger.warning("LLM service not initialized")
        return None
    
    # Check if any LLM is available (local or remote)
    has_local = hasattr(llm_service, 'local_llm') and llm_service.local_llm is not None  # type: ignore
    has_remote = hasattr(llm_service, '_remote_initialized') and llm_service._remote_initialized  # type: ignore
    
    if not has_local and not has_remote:
        logger.debug("No LLM available (neither local nor remote)")
        return None
    
    try:
        # Truncate content for prompt if it's extremely long (>10K chars)
        # This prevents OOM errors with very long content
        truncated_content = content
        if len(content) > 10000:
            truncated_content = content[:10000] + "\n...[content truncated for summarization]"
        
        prompt = EMBEDDING_SUMMARY_PROMPT.format(content=truncated_content)
        
        # Generate response with modest token limit
        response = await llm_service._generate_response(  # type: ignore
            prompt,
            max_tokens=512,  # Enough for ~800 char summary
        )
        
        # Clean up the response
        summary = response.strip()
        
        # Remove any markdown code blocks if present
        if summary.startswith("```"):
            lines = summary.split("\n")
            # Remove first and last lines if they're code block markers
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            summary = "\n".join(lines).strip()
        
        # Basic validation - summary should have some content
        if not summary or len(summary) < 10:
            logger.warning("LLM returned empty or very short summary")
            return None
        
        return summary
        
    except Exception as e:
        logger.error("Error during LLM summarization", error=str(e))
        return None


def needs_summarization(content: str, title: Optional[str] = None) -> bool:
    """Check if content needs summarization for embedding.
    
    Args:
        content: The memory content
        title: Optional title
        
    Returns:
        True if content exceeds embedding limit
    """
    semantic_field = f"{title or ''}\n{content}".strip()
    return len(semantic_field) > MAX_EMBEDDING_CHARS
