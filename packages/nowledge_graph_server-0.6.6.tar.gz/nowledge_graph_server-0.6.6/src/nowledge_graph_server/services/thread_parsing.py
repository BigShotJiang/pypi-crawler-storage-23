"""Thread parsing services for various conversation formats."""

import json
import structlog
import re
from typing import List, Optional
from dataclasses import dataclass
from abc import ABC, abstractmethod
from markdownify import markdownify as md

logger = structlog.get_logger(__name__)


@dataclass
class ParsedMessage:
    """Represents a parsed message from a conversation."""

    speaker: str
    content: str
    timestamp: Optional[str] = None


@dataclass
class ParsedThread:
    """Represents a parsed conversation thread."""

    title: str
    source: str
    messages: List[ParsedMessage]
    export_info: Optional[str] = None

    @property
    def message_count(self) -> int:
        return len(self.messages)

    @property
    def participants(self) -> List[str]:
        return list(set(msg.speaker for msg in self.messages))


class BaseThreadParser(ABC):
    """Abstract base class for thread parsers."""

    @abstractmethod
    def can_parse(self, content: str, filename: str) -> bool:
        """Check if this parser can handle the given content."""
        pass

    @abstractmethod
    def parse(self, content: str, filename: str) -> ParsedThread:
        """Parse the content into a ParsedThread."""
        pass


class CursorMarkdownParser(BaseThreadParser):
    """Parser for Cursor markdown exports."""

    def can_parse(self, content: str, filename: str) -> bool:
        lines = content.split("\n", 2)
        if not filename.endswith(".md"):
            return False
        if len(lines) < 2:
            return False
        # First line is the title, must start with "# "
        if not lines[0].strip().startswith("# "):
            return False
        # Second line: look for "_Exported on ... from <Source>_", extract source with regex
        match = re.match(r"_Exported on .+ from (.+)_", lines[1].strip())
        if not match:
            return False
        return True

    def parse(self, content: str, filename: str) -> ParsedThread:
        lines = content.split("\n")

        # Extract title (first line starting with #)
        title = "Imported Thread"
        for line in lines:
            if line.startswith("# "):
                title = line[2:].strip()
                break

        # Extract export metadata
        export_info = None
        for line in lines:
            if "_Exported on" in line:
                export_info = line.strip("_").strip()
                break

        # Parse messages
        messages = []
        current_speaker = None
        current_content = []

        for line in lines:
            line = line.strip()

            # Skip empty lines and separator lines
            if not line or line == "---":
                continue

            # Check for speaker lines (**User** or **Cursor**)
            if line == "**User**":
                # Save previous message if exists
                if current_speaker and current_content:
                    messages.append(
                        ParsedMessage(
                            speaker=current_speaker,
                            content="\n".join(current_content).strip(),
                            timestamp=None,
                        )
                    )
                current_speaker = "user"
                current_content = []
            elif line == "**Cursor**":
                # Save previous message if exists
                if current_speaker and current_content:
                    messages.append(
                        ParsedMessage(
                            speaker=current_speaker,
                            content="\n".join(current_content).strip(),
                            timestamp=None,
                        )
                    )
                current_speaker = "assistant"
                current_content = []
            elif current_speaker is not None:
                # Continue current message - collect all content until next speaker or separator
                current_content.append(line)

        # Save final message
        if current_speaker and current_content:
            messages.append(
                ParsedMessage(
                    speaker=current_speaker,
                    content="\n".join(current_content).strip(),
                    timestamp=None,
                )
            )

        return ParsedThread(
            title=title, source="Cursor", messages=messages, export_info=export_info
        )


class NowledgeMemMarkdownParser(BaseThreadParser):
    """Parser for nowledge-mem markdown exports."""

    def can_parse(self, content: str, filename: str) -> bool:
        return (
            filename.endswith(".md")
            and "_Exported on" in content
            and "from nowledge-mem" in content
        )

    def parse(self, content: str, filename: str) -> ParsedThread:
        lines = content.split("\n")

        # Extract title (first line starting with #)
        title = "Imported Thread"
        for line in lines:
            if line.startswith("# "):
                title = line[2:].strip()
                break

        # Extract export metadata
        export_info = None
        for line in lines:
            if "_Exported on" in line and "from nowledge-mem" in line:
                export_info = line.strip("_").strip()
                break

        # Parse thread metadata if present
        original_source = "nowledge-mem"
        thread_metadata_section = False
        for i, line in enumerate(lines):
            if line.strip() == "**Thread Metadata**":
                thread_metadata_section = True
                continue
            if thread_metadata_section and line.strip().startswith("- Source:"):
                original_source = line.strip().replace("- Source:", "").strip()
                break

        # Parse messages
        messages = []
        current_speaker = None
        current_content = []
        in_metadata_section = False

        for line in lines:
            line = line.strip()

            # Skip metadata section
            if line == "**Thread Metadata**":
                in_metadata_section = True
                continue
            if in_metadata_section:
                continue

            # Skip empty lines and separator lines
            if not line or line == "---":
                continue

            # Check for speaker lines (**User** or **Assistant**)
            if line == "**User**":
                # Save previous message if exists
                if current_speaker and current_content:
                    messages.append(
                        ParsedMessage(
                            speaker=current_speaker,
                            content="\n".join(current_content).strip(),
                            timestamp=None,
                        )
                    )
                current_speaker = "user"
                current_content = []
            elif line == "**Assistant**":
                # Save previous message if exists
                if current_speaker and current_content:
                    messages.append(
                        ParsedMessage(
                            speaker=current_speaker,
                            content="\n".join(current_content).strip(),
                            timestamp=None,
                        )
                    )
                current_speaker = "assistant"
                current_content = []
            elif current_speaker is not None:
                # Continue current message - collect all content until next speaker or separator
                current_content.append(line)

        # Save final message
        if current_speaker and current_content:
            messages.append(
                ParsedMessage(
                    speaker=current_speaker,
                    content="\n".join(current_content).strip(),
                    timestamp=None,
                )
            )

        return ParsedThread(
            title=title,
            source=original_source,
            messages=messages,
            export_info=export_info,
        )


class ChatWiseParser(BaseThreadParser):
    """Parser for ChatWise HTML exports."""

    def can_parse(self, content: str, filename: str) -> bool:
        return (
            filename.endswith(".html")
            and "message-role" in content
            and "message-content" in content
        )

    def parse(self, content: str, filename: str) -> ParsedThread:
        # Parse HTML content to extract messages
        messages = []
        title = "ChatWise Conversation"

        # Extract title from HTML title tag
        title_match = re.search(r"<title>(.*?)</title>", content, flags=re.IGNORECASE)
        if title_match:
            title = title_match.group(1).strip()

        # Extract messages using regex patterns
        message_pattern = r'<div class="message-role">\s*<strong>(.*?)</strong>\s*</div>\s*<div class="message-content">(.*?)</div>'
        matches = re.findall(message_pattern, content, re.DOTALL | re.IGNORECASE)

        def code_language_callback(el):
            # Extract language from pre tag class
            if el.has_attr("class"):
                classes = el["class"]
                # Look for language- prefix or other common patterns
                for cls in classes:
                    if cls.startswith("language-"):
                        return cls[9:]  # Remove language- prefix
                    if cls.startswith("lang-"):
                        return cls[5:]  # Remove lang- prefix
                    # Common class names for code blocks
                    if cls in [
                        "python",
                        "javascript",
                        "typescript",
                        "java",
                        "cpp",
                        "csharp",
                        "ruby",
                        "php",
                        "html",
                        "css",
                        "sql",
                        "json",
                        "yaml",
                        "yml",
                        "bash",
                        "sh",
                        "powershell",
                        "ps1",
                    ]:
                        return cls
            return None

        for role, content_html in matches:
            # Convert HTML to markdown using markdownify
            content_text = md(
                content_html,
                heading_style="ATX",  # Use # for headers
                bullets="*+-",  # Use multiple bullet styles
                strip=["script", "style"],  # Strip script and style tags
                escape_asterisks=False,  # Don't escape asterisks in code
                escape_underscores=False,  # Don't escape underscores in code
                autolinks=True,  # Convert links automatically
                default_title=True,  # Use href as title if no title
                wrap=True,  # Wrap long lines
                wrap_width=80,  # Wrap at 80 characters
                code_language="python",  # Default language
                code_language_callback=code_language_callback,  # Add language detection
            ).strip()

            # Clean up any remaining HTML entities
            # content_text = (content_text
            #               .replace('&nbsp;', ' ')
            #               .replace('&amp;', '&')
            #               .replace('&lt;', '<')
            #               .replace('&gt;', '>')
            #               .replace('&quot;', '"')
            #               .replace('&#39;', "'"))

            if content_text:
                messages.append(
                    ParsedMessage(
                        speaker=role.strip(), content=content_text, timestamp=None
                    )
                )

        return ParsedThread(
            title=title,
            source="ChatWise",
            messages=messages,
            export_info=f"Imported from ChatWise HTML export",
        )


class ChatGPTParser(BaseThreadParser):
    """Parser for ChatGPT JSON exports."""

    def can_parse(self, content: str, filename: str) -> bool:
        return (
            filename.endswith(".json")
            and '"conversation_id"' in content
            and '"openai.com"' in content
        )

    def parse(self, content: str, filename: str) -> ParsedThread:
        try:
            data = json.loads(content)

            title = data.get("title", "ChatGPT Conversation")
            messages = []

            # Extract messages from the conversation
            for msg in data.get("messages", []):
                if msg.get("content") and msg.get("role"):
                    # Handle different content types
                    content_text = ""
                    if isinstance(msg["content"], str):
                        content_text = msg["content"]
                    elif isinstance(msg["content"], list):
                        for part in msg["content"]:
                            if isinstance(part, str):
                                content_text += part
                            elif isinstance(part, dict) and "text" in part:
                                content_text += part["text"]

                    if content_text.strip():
                        messages.append(
                            ParsedMessage(
                                speaker=msg["role"],
                                content=content_text.strip(),
                                timestamp=msg.get("timestamp"),
                            )
                        )

            return ParsedThread(
                title=title,
                source="ChatGPT",
                messages=messages,
                export_info=f"Conversation ID: {data.get('conversation_id', 'Unknown')}",
            )

        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON format")


class ClaudeParser(BaseThreadParser):
    """Parser for Claude JSON exports."""

    def can_parse(self, content: str, filename: str) -> bool:
        return filename.endswith(".json") and '"claude.ai"' in content

    def parse(self, content: str, filename: str) -> ParsedThread:
        try:
            data = json.loads(content)

            title = data.get("title", "Claude Conversation")
            messages = []

            for msg in data.get("messages", []):
                if msg.get("content") and msg.get("role"):
                    messages.append(
                        ParsedMessage(
                            speaker=msg["role"],
                            content=msg["content"],
                            timestamp=msg.get("timestamp"),
                        )
                    )

            return ParsedThread(
                title=title,
                source="Claude",
                messages=messages,
                export_info=f"Imported from Claude conversation",
            )

        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON format")


class PlainMarkdownParser(BaseThreadParser):
    """Fallback parser for plain markdown files treated as single-message threads.
    
    This parser handles any .md file that doesn't match other specific formats.
    The entire content becomes a single message with role="document".
    """

    def can_parse(self, content: str, filename: str) -> bool:
        # Fallback for any .md file
        return filename.lower().endswith((".md", ".markdown"))

    def parse(self, content: str, filename: str) -> ParsedThread:
        # Extract title from first H1 heading or use filename
        title = None
        lines = content.split("\n")
        for line in lines:
            if line.startswith("# "):
                title = line[2:].strip()
                break
        
        if not title:
            # Use filename without extension
            import os
            title = os.path.splitext(os.path.basename(filename))[0]
            # Convert hyphens/underscores to spaces and title case
            title = title.replace("-", " ").replace("_", " ").title()
        
        # Clean content - remove frontmatter if present
        clean_content = content
        if content.startswith("---"):
            parts = content.split("---", 2)
            if len(parts) >= 3:
                clean_content = parts[2].strip()
        
        # Create single message with the entire content
        messages = [
            ParsedMessage(
                speaker="document",
                content=clean_content,
                timestamp=None,
            )
        ]
        
        return ParsedThread(
            title=title,
            source="markdown",
            messages=messages,
            export_info=f"Imported from {filename}",
        )


class ThreadParsingService:
    """Service for parsing conversation threads from various formats."""

    def __init__(self):
        self.parsers = [
            CursorMarkdownParser(),
            NowledgeMemMarkdownParser(),
            ChatWiseParser(),
            ChatGPTParser(),
            ClaudeParser(),
            PlainMarkdownParser(),  # Fallback for plain .md files
        ]

    def detect_format(self, content: str, filename: str) -> str:
        """Detect the format of the conversation content."""
        for parser in self.parsers:
            if parser.can_parse(content, filename):
                return parser.__class__.__name__.replace("Parser", "").lower()
        return "unknown"

    def parse_thread(self, content: str, filename: str) -> ParsedThread:
        """Parse thread content based on detected format."""
        for parser in self.parsers:
            if parser.can_parse(content, filename):
                return parser.parse(content, filename)

        raise ValueError(f"Unsupported format")


# Global service instance
thread_parsing_service = ThreadParsingService()
