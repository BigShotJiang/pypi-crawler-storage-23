"""Shared base helpers for data transfer."""

from __future__ import annotations

from typing import Any, Dict, Optional

import structlog

from nowledge_graph_server.services.data_transfer_utils import (
    KNOWN_COLUMN_TYPES,
    _sanitize_table_name,
)

logger = structlog.get_logger(__name__)


class DataTransferBase:
    def __init__(self, db):
        self.db = db
        self.base_client = getattr(db, "base_client", db)

    def _close_result(self, result: Any) -> None:
        close_fn = getattr(result, "close", None)
        if callable(close_fn):
            try:
                close_fn()
            except Exception:
                pass

    def _checkpoint(self, warnings: list[str], context: str) -> None:
        conn = self.db.conn
        if not conn:
            return
        try:
            result = conn.execute("CHECKPOINT;")
            self._close_result(result)
        except Exception as e:
            warnings.append(f"Checkpoint skipped after {context}: {e}")

    def _mark_reindex_needed(self, warnings: list[str]) -> None:
        try:
            from ..config import get_app_cache_dir

            cache_dir = get_app_cache_dir("embeddings")
            cache_dir.mkdir(parents=True, exist_ok=True)
            marker_file = cache_dir / ".reindex_needed"
            marker_file.touch()
        except Exception as e:
            warnings.append(f"Failed to mark search index for rebuild: {e}")

    def run_checkpoint(self) -> Dict[str, Any]:
        self._ensure_initialized()
        if not self.db.conn:
            raise RuntimeError("Database connection not available")
        result = self.db.conn.execute("CHECKPOINT;")
        self._close_result(result)
        return {"success": True}

    def _ensure_initialized(self) -> None:
        if hasattr(self.base_client, "_ensure_initialized"):
            self.base_client._ensure_initialized()  # type: ignore[attr-defined]
            return
        if hasattr(self.db, "_initialized") and not getattr(self.db, "_initialized"):
            raise RuntimeError("KuzuClient not initialized. Call initialize() first.")

    def _get_table_columns(self, table: str) -> Dict[str, Optional[str]]:
        conn = self.db.conn
        if not conn:
            raise RuntimeError("Database connection not available")
        table_safe = _sanitize_table_name(table)
        result = conn.execute(f"CALL table_info('{table_safe}') RETURN *")
        columns: Dict[str, Optional[str]] = {}
        try:
            if hasattr(result, "has_next"):
                while result.has_next():
                    row = result.get_next()
                    if not row or len(row) < 2:
                        continue
                    name = str(row[1])
                    col_type = None
                    for item in row:
                        if isinstance(item, str) and item.upper() in KNOWN_COLUMN_TYPES:
                            col_type = item.upper()
                            break
                    columns[name] = col_type
        finally:
            self._close_result(result)
        return columns
