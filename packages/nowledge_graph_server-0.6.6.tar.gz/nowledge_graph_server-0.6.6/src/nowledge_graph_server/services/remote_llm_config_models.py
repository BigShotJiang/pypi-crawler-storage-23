"""Remote LLM configuration models."""

from typing import Any, Dict, Optional

from pydantic import BaseModel, Field


class RemoteLLMConfig(BaseModel):
    """Configuration for remote LLM provider."""

    enabled: bool = Field(default=False, description="Whether remote LLM is enabled")
    # NOTE: In our app config, `provider` is a provider *id* (stable key in remote_llm.json).
    # For built-in providers, provider_id == provider_type (e.g. "openai", "anthropic").
    # For multi-instance providers (e.g. custom OpenAI-compatible endpoints), provider_id is unique
    # (e.g. "openai_compatible:my-local-1") and `provider_type` indicates how to talk to it.
    provider: str = Field(
        default="openai", description="Provider id (built-ins use provider type)"
    )
    provider_type: Optional[str] = Field(
        default=None,
        description="Provider type / driver (e.g. 'openai', 'anthropic', 'openai_compatible')",
    )
    display_name: Optional[str] = Field(
        default=None, description="Optional user-facing name for provider instances"
    )
    model: str = Field(
        default="", description="Model name for the provider (empty until user selects)"
    )
    api_key: Optional[str] = Field(default=None, description="API key for the provider")
    api_base: Optional[str] = Field(
        default=None, description="Custom API base URL (optional)"
    )
    api_version: Optional[str] = Field(
        default=None, description="API version (for Azure)"
    )
    # Additional provider-specific settings
    extra_params: Dict[str, Any] = Field(
        default_factory=dict, description="Additional parameters for litellm.completion"
    )

    # Performance settings
    temperature: float = Field(
        default=0.7, ge=0.0, le=2.0, description="Temperature for generation"
    )
    max_tokens: int = Field(
        default=8192, ge=1, le=128000, description="Max tokens to generate"
    )
    timeout: float = Field(
        default=60.0, ge=1.0, description="Request timeout in seconds"
    )

    # Metadata
    last_updated: Optional[str] = Field(
        default=None, description="ISO timestamp of last update"
    )
    last_test_success: Optional[str] = Field(
        default=None, description="ISO timestamp of last successful test"
    )
