"""Import configuration service for managing session import preferences.

Handles:
- Hidden projects and sessions
- Auto-import rules
- Watcher settings
"""

import json
import shutil
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog

from nowledge_graph_server.utils.app_paths import (
    get_app_config_dir,
    resolve_config_file_path,
)

logger = structlog.get_logger(__name__)


class AutoImportRuleType(str, Enum):
    """Types of auto-import rules."""

    PROJECT = "project"  # Match specific project (by encoded name)
    PATH_PATTERN = "path_pattern"  # Match glob pattern
    SOURCE = "source"  # Match all from a source (claude/codex/cursor)


@dataclass
class AutoImportRule:
    """Rule for auto-importing sessions."""

    id: str
    type: AutoImportRuleType
    value: str  # Encoded project name, glob pattern, or source type
    enabled: bool = True
    created_at: float = 0.0

    def matches(self, session_source: str, project_encoded: str) -> bool:
        """Check if this rule matches a session."""
        if not self.enabled:
            return False

        if self.type == AutoImportRuleType.PROJECT:
            return project_encoded == self.value
        elif self.type == AutoImportRuleType.SOURCE:
            return session_source == self.value
        elif self.type == AutoImportRuleType.PATH_PATTERN:
            # Simple glob matching for path patterns
            import fnmatch

            # Decode project path for matching
            decoded = "/" + project_encoded[1:].replace("-", "/") if project_encoded.startswith("-") else project_encoded
            return fnmatch.fnmatch(decoded, self.value)

        return False


@dataclass
class ImportConfig:
    """User's import configuration."""

    hidden_projects: List[str] = field(default_factory=list)
    hidden_sessions: List[str] = field(default_factory=list)
    auto_import_rules: List[AutoImportRule] = field(default_factory=list)
    watcher_enabled: bool = False
    show_hidden_by_default: bool = False
    dedup_window_seconds: int = 60  # Ignore reimports within this window
    watched_platforms: List[str] = field(default_factory=list)  # e.g. ["claude", "codex", "opencode", "cursor"]
    watched_projects: List[str] = field(default_factory=list)  # Encoded project paths to auto-import
    cursor_poll_interval: float = 30.0  # Seconds between Cursor polls (SQLite polling, not FS events)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "hidden_projects": self.hidden_projects,
            "hidden_sessions": self.hidden_sessions,
            "auto_import_rules": [
                {
                    "id": rule.id,
                    "type": rule.type.value,
                    "value": rule.value,
                    "enabled": rule.enabled,
                    "created_at": rule.created_at,
                }
                for rule in self.auto_import_rules
            ],
            "watcher_enabled": self.watcher_enabled,
            "show_hidden_by_default": self.show_hidden_by_default,
            "dedup_window_seconds": self.dedup_window_seconds,
            "watched_platforms": self.watched_platforms,
            "watched_projects": self.watched_projects,
            "cursor_poll_interval": self.cursor_poll_interval,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ImportConfig":
        """Create from dictionary."""
        rules = []
        for rule_data in data.get("auto_import_rules", []):
            try:
                rules.append(
                    AutoImportRule(
                        id=rule_data["id"],
                        type=AutoImportRuleType(rule_data["type"]),
                        value=rule_data["value"],
                        enabled=rule_data.get("enabled", True),
                        created_at=rule_data.get("created_at", 0.0),
                    )
                )
            except (KeyError, ValueError) as e:
                logger.warning("Invalid auto-import rule", rule=rule_data, error=str(e))

        return cls(
            hidden_projects=data.get("hidden_projects", []),
            hidden_sessions=data.get("hidden_sessions", []),
            auto_import_rules=rules,
            watcher_enabled=data.get("watcher_enabled", False),
            show_hidden_by_default=data.get("show_hidden_by_default", False),
            dedup_window_seconds=data.get("dedup_window_seconds", 60),
            watched_platforms=data.get("watched_platforms", []),
            watched_projects=data.get("watched_projects", []),
            cursor_poll_interval=data.get("cursor_poll_interval", 30.0),
        )


class ImportConfigService:
    """Service for managing import configuration."""

    def __init__(self, config_dir: Optional[Path] = None):
        """Initialize the config service.

        Args:
            config_dir: Directory to store config. Defaults to Tauri app config directory.
        """
        if config_dir is None:
            config_dir = self._get_app_data_dir()

        self.config_dir = config_dir
        self.config_path = config_dir / "import-config.json"
        self._config: Optional[ImportConfig] = None

        # Migrate from legacy location if needed
        self._migrate_legacy_config()

    @staticmethod
    def _get_app_data_dir() -> Path:
        """Get canonical app config directory path (aligned with Tauri appConfigDir).

        Paths must match Tauri's appConfigDir() for each platform:
        - macOS: ~/Library/Application Support/co.nowledge.mem.desktop
        - Windows: %APPDATA%/co.nowledge.mem.desktop
        - Linux: ~/.config/co.nowledge.mem.desktop (XDG_CONFIG_HOME)
        """
        return get_app_config_dir()

    def _migrate_legacy_config(self):
        """Migrate import-config.json from legacy locations."""
        extra_legacy = [Path.home() / ".config" / "nowledge-mem" / "import-config.json"]
        resolved = resolve_config_file_path("import-config.json", extra_legacy)
        if resolved == self.config_path:
            return
        if resolved.exists() and not self.config_path.exists():
            try:
                self.config_dir.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(resolved), str(self.config_path))
                logger.info(
                    "Migrated import config from legacy location",
                    legacy=str(resolved),
                    new=str(self.config_path),
                )
            except Exception as e:
                logger.warning(
                    "Failed to migrate legacy import config",
                    legacy=str(resolved),
                    error=str(e),
                )

    def load(self) -> ImportConfig:
        """Load configuration from disk."""
        if self._config is not None:
            return self._config

        if not self.config_path.exists():
            logger.debug("Config file not found, using defaults", path=str(self.config_path))
            self._config = ImportConfig()
            return self._config

        try:
            with open(self.config_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self._config = ImportConfig.from_dict(data)
            logger.debug("Loaded import config", path=str(self.config_path))
        except (json.JSONDecodeError, IOError) as e:
            logger.error("Failed to load import config", error=str(e))
            self._config = ImportConfig()

        return self._config

    def save(self, config: Optional[ImportConfig] = None) -> bool:
        """Save configuration to disk.

        Args:
            config: Config to save. If None, saves current config.

        Returns:
            True if save was successful.
        """
        if config is not None:
            self._config = config

        if self._config is None:
            return False

        try:
            # Ensure directory exists
            self.config_dir.mkdir(parents=True, exist_ok=True)

            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(self._config.to_dict(), f, indent=2)

            logger.info("Saved import config", path=str(self.config_path))
            return True
        except Exception as e:
            logger.error("Failed to save import config", path=str(self.config_path), error=str(e), error_type=type(e).__name__)
            return False

    def update(self, **kwargs: Any) -> ImportConfig:
        """Update specific config fields.

        Args:
            **kwargs: Fields to update.

        Returns:
            Updated config.
        """
        config = self.load()

        for key, value in kwargs.items():
            if hasattr(config, key):
                setattr(config, key, value)

        self.save(config)
        return config

    # Convenience methods

    def hide_project(self, project_encoded: str) -> None:
        """Add a project to the hidden list."""
        config = self.load()
        if project_encoded not in config.hidden_projects:
            config.hidden_projects.append(project_encoded)
            self.save(config)

    def unhide_project(self, project_encoded: str) -> None:
        """Remove a project from the hidden list."""
        config = self.load()
        if project_encoded in config.hidden_projects:
            config.hidden_projects.remove(project_encoded)
            self.save(config)

    def hide_session(self, session_id: str) -> None:
        """Add a session to the hidden list."""
        config = self.load()
        if session_id not in config.hidden_sessions:
            config.hidden_sessions.append(session_id)
            self.save(config)

    def unhide_session(self, session_id: str) -> None:
        """Remove a session from the hidden list."""
        config = self.load()
        if session_id in config.hidden_sessions:
            config.hidden_sessions.remove(session_id)
            self.save(config)

    def add_auto_import_rule(self, rule: AutoImportRule) -> None:
        """Add an auto-import rule."""
        config = self.load()
        # Remove existing rule with same ID if exists
        config.auto_import_rules = [r for r in config.auto_import_rules if r.id != rule.id]
        config.auto_import_rules.append(rule)
        self.save(config)

    def remove_auto_import_rule(self, rule_id: str) -> None:
        """Remove an auto-import rule."""
        config = self.load()
        config.auto_import_rules = [r for r in config.auto_import_rules if r.id != rule_id]
        self.save(config)

    def should_auto_import(self, session_source: str, project_encoded: str) -> bool:
        """Check if a session should be auto-imported.

        Checks in order:
        1. Explicit auto-import rules (legacy)
        2. Watched platforms (source-level matching)
        3. Watched projects (project-level matching)

        Args:
            session_source: Source type (claude, codex, cursor, opencode)
            project_encoded: Encoded project path

        Returns:
            True if session should be auto-imported.
        """
        config = self.load()

        # Check explicit rules first
        for rule in config.auto_import_rules:
            if rule.matches(session_source, project_encoded):
                return True

        # Check watched platforms (source-level)
        if session_source in config.watched_platforms:
            return True

        # Check watched projects (project-level)
        if project_encoded in config.watched_projects:
            return True

        return False

    def is_hidden(self, project_encoded: Optional[str] = None, session_id: Optional[str] = None) -> bool:
        """Check if a project or session is hidden.

        Args:
            project_encoded: Encoded project path to check
            session_id: Session ID to check

        Returns:
            True if the item is hidden.
        """
        config = self.load()

        if project_encoded and project_encoded in config.hidden_projects:
            return True

        if session_id and session_id in config.hidden_sessions:
            return True

        return False


# Singleton instance
_config_service: Optional[ImportConfigService] = None


def get_import_config_service() -> ImportConfigService:
    """Get the singleton import config service instance."""
    global _config_service
    if _config_service is None:
        _config_service = ImportConfigService()
    return _config_service
