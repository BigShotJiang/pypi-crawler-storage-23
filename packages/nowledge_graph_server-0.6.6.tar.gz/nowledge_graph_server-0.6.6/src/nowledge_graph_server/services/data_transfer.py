"""Data export/import service entrypoint.

This module stays small for build tooling, and re-exports the full
implementation from split modules.
"""

from __future__ import annotations

from nowledge_graph_server.services.data_transfer_base import DataTransferBase
from nowledge_graph_server.services.data_transfer_export import DataTransferExportMixin
from nowledge_graph_server.services.data_transfer_import import DataTransferImportMixin
from nowledge_graph_server.services.data_transfer_models import (
    EXPORT_FORMAT,
    EXPORT_VERSION,
    ExportOptions,
    ImportOptions,
)


class DataTransferService(
    DataTransferImportMixin,
    DataTransferExportMixin,
    DataTransferBase,
):
    pass


__all__ = [
    "DataTransferService",
    "ExportOptions",
    "ImportOptions",
    "EXPORT_FORMAT",
    "EXPORT_VERSION",
]
