"""Entity extraction methods for LocalLLMService (mixin).

Separated from local_llm.py to stay within the pyarmor free-tier
line limit (1 000 lines per file).
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict, List, Optional

import structlog

from nowledge_graph_server.services.base_llm import (
    ENTITY_EXTRACTION_PROMPT_SINGLE_MEMORY_TEMPLATE,
    EntityExtractionResult,
)
from nowledge_graph_server.services.json_utils import clean_and_parse_json
from nowledge_graph_server.services.remote_llm_extraction import RemoteLLMExtraction
from nowledge_graph_server.utils.progress_logger import log_progress

logger = structlog.get_logger()


class ExtractionMixin:
    """Entity extraction capabilities mixed into LocalLLMService."""

    async def extract_entities_from_single_memory(
        self,
        memory_text: str,
        memory_index: int = 0,
        memory_title: str = "",
        extraction_level: str = "swift",
        force_local: bool = False,
    ) -> EntityExtractionResult:
        """Extract entities from a single memory.

        Args:
            memory_text: The memory content to extract entities from
            memory_index: Index of the memory in the batch
            memory_title: Title of the memory
            extraction_level: "swift" (fast) or "guided" (multi-step)
            force_local: If True, always use local LLM regardless of config
        """
        if extraction_level == "guided":
            logger.debug("Using Level 2 guided extraction")
            from nowledge_graph_server.services.guided_extraction_optimized import OptimizedGuidedExtraction

            def robust_json_parser(response: str) -> Optional[Dict[str, Any]]:
                result = clean_and_parse_json(response)
                if not result:
                    return None
                if isinstance(result, dict):
                    return {key.strip("\"'"): value for key, value in result.items()}
                return result

            async def llm_wrapper(prompt: str, max_tokens: int, temperature: float) -> str:
                self._current_operation = "entity_extraction"
                return await self._generate_response(prompt, max_tokens=max_tokens, temperature=temperature, force_local=force_local)

            try:
                guided = OptimizedGuidedExtraction(llm_wrapper, robust_json_parser)
                return await guided.extract(memory_text, memory_title, memory_index)
            except Exception as e:
                logger.error(f"Level 2 guided extraction failed: {e}")

        # Default Level 1 swift extraction
        logger.debug("Using Level 1 swift extraction")
        prompt = ENTITY_EXTRACTION_PROMPT_SINGLE_MEMORY_TEMPLATE.format(memory_text=memory_text)

        try:
            response = await self._generate_response(prompt, max_tokens=1536, use_thinking=False, force_local=force_local)
            if not response or not response.strip():
                logger.warning("LLM returned empty response for entity extraction", memory_index=memory_index)
                return EntityExtractionResult(entities=[], relationships=[], confidence=0.0)
            parsed_result = clean_and_parse_json(response)

            if parsed_result is not None:
                entities = parsed_result.get("entities", [])
                relationships = parsed_result.get("relationships", [])
                confidence = self._fix_confidence(parsed_result.get("confidence", 0.6))

                # Add metadata and fix confidence values
                for entity in entities:
                    entity["extraction_method"] = "few_shot_memory_llm"
                    entity["source_type"] = "memory"
                    entity.setdefault("mentions", 1)
                    entity["confidence"] = self._fix_confidence(entity.get("confidence"))

                for rel in relationships:
                    rel["extraction_method"] = "few_shot_memory_llm"
                    rel["source_type"] = "memory"
                    rel["confidence"] = self._fix_confidence(rel.get("confidence"))

                # Apply confidence filtering
                filtered_entities = [e for e in entities if e.get("confidence", 0) >= 0.5]
                entity_names = {e["name"] for e in filtered_entities}
                filtered_relationships = [
                    rel for rel in relationships
                    if rel.get("source") in entity_names
                    and rel.get("target") in entity_names
                    and rel.get("confidence", 0) >= 0.5
                ]

                logger.info(
                    "Individual memory extraction completed",
                    memory_index=memory_index,
                    entities_count=len(filtered_entities),
                    relationships_count=len(filtered_relationships),
                )

                return EntityExtractionResult(
                    entities=filtered_entities,
                    relationships=filtered_relationships,
                    confidence=confidence,
                )
            else:
                logger.warning("Failed to parse memory entity extraction", memory_index=memory_index)
                return EntityExtractionResult(entities=[], relationships=[], confidence=0.0)

        except Exception as e:
            logger.error("Individual memory entity extraction failed", memory_index=memory_index, error=str(e))
            return EntityExtractionResult(entities=[], relationships=[], confidence=0.0)

    def _fix_confidence(self, value: Any, default: float = 0.6) -> float:
        """Convert confidence value to float, handling string placeholders."""
        if isinstance(value, (int, float)):
            return max(0.0, min(1.0, float(value)))
        elif isinstance(value, str):
            try:
                return max(0.0, min(1.0, float(value)))
            except (ValueError, TypeError):
                return default
        return default

    async def _extract_entities_from_memories(
        self,
        memories: List[Dict[str, Any]],
        use_remote: bool,
        extraction_level: str,
        force_local: bool = False,
        preferred_language: Optional[str] = None,
    ) -> EntityExtractionResult:
        """Extract entities from individual memories."""
        logger.debug("Extracting entities from memories", count=len(memories), force_local=force_local)

        all_entities: List[Dict[str, Any]] = []
        all_relationships: List[Dict[str, Any]] = []
        total_memories = len(memories)

        if use_remote:
            remote_extraction = await self._get_remote_extraction()
            if remote_extraction:
                return await self._parallel_remote_extraction(
                    remote_extraction, memories, total_memories, preferred_language=preferred_language
                )

        # Sequential fallback for local LLM
        accumulated_entities = []
        for idx, memory_data in enumerate(memories):
            memory_title = memory_data.get("title", f"Memory {idx + 1}")
            memory_content = memory_data.get("content", "")

            progress = 20 + ((idx + 1) / total_memories) * 35
            log_progress(
                operation="thread_distillation",
                percentage=progress,
                message=f"Analyzing memory {idx + 1}/{total_memories}: {memory_title[:50]}...",
                details={"memory_index": idx + 1, "total_memories": total_memories}
            )

            if len(memory_content.strip()) < 30:
                continue

            memory_text = f"Memory Title: {memory_title}\n\nMemory Content: {memory_content}"

            try:
                result = await self.extract_entities_from_single_memory(
                    memory_text=memory_text,
                    memory_index=idx,
                    memory_title=memory_title,
                    extraction_level=extraction_level,
                    force_local=force_local,
                )

                for entity in result.entities:
                    entity["source_memory_index"] = idx
                    entity["source_memory_title"] = memory_title
                    entity["extraction_method"] = "individual_memory_llm"

                for rel in result.relationships:
                    rel["source_memory_index"] = idx
                    rel["source_memory_title"] = memory_title
                    rel["extraction_method"] = "individual_memory_llm"

                accumulated_entities.extend(result.entities)
                all_entities.extend(result.entities)
                all_relationships.extend(result.relationships)

            except Exception as e:
                logger.error(f"Failed to extract from memory {idx + 1}", error=str(e))
                continue

        return EntityExtractionResult(entities=all_entities, relationships=all_relationships, confidence=0.7)

    async def _parallel_remote_extraction(
        self,
        remote_extraction: RemoteLLMExtraction,
        memories: List[Dict[str, Any]],
        total_memories: int,
        preferred_language: Optional[str] = None,
    ) -> EntityExtractionResult:
        """Run parallel entity extraction using remote LLM."""
        logger.info(f"Using PARALLEL remote extraction for {total_memories} memories")

        all_entities: List[Dict[str, Any]] = []
        all_relationships: List[Dict[str, Any]] = []

        async def extract_memory(idx: int, memory_data: dict):
            memory_title = memory_data.get("title", f"Memory {idx + 1}")
            memory_content = memory_data.get("content", "")

            if len(memory_content.strip()) < 30:
                return None

            result = await remote_extraction.extract_entities_remote(
                memory_title=memory_title,
                memory_content=memory_content,
                memory_index=idx,
                enable_reflection=False,
                enable_deduplication=False,
                accumulated_entities=[],
                preferred_language=preferred_language,
            )

            for entity in result.entities:
                entity["source_memory_index"] = idx
                entity["source_memory_title"] = memory_title

            for rel in result.relationships:
                rel["source_memory_index"] = idx
                rel["source_memory_title"] = memory_title

            return result

        log_progress(
            operation="thread_distillation",
            percentage=51,
            message=f"[1/3] Extracting entities from {total_memories} memories (parallel)...",
            details={"total_memories": total_memories, "stage": "extraction"}
        )

        tasks = [asyncio.create_task(extract_memory(idx, mem)) for idx, mem in enumerate(memories)]

        completed = 0
        extraction_progress = 14 // max(total_memories, 1)

        for coro in asyncio.as_completed(tasks):
            try:
                result = await coro
                completed += 1
                if result is not None:
                    all_entities.extend(result.entities)
                    all_relationships.extend(result.relationships)

                    log_progress(
                        operation="thread_distillation",
                        percentage=51 + (completed * extraction_progress),
                        message=f"[1/3] Memory {completed}/{total_memories}: +{len(result.entities)} entities",
                        details={
                            "completed": completed,
                            "total": total_memories,
                            "stage": "extraction",
                            "total_entities": len(all_entities),
                            "entities": [{"name": e["name"], "type": e.get("type", "CONCEPT")} for e in result.entities],
                            "relationships": [{"source": r["source"], "target": r["target"]} for r in result.relationships],
                        }
                    )
            except Exception as e:
                completed += 1
                logger.warning(f"Memory extraction failed: {e}")

        log_progress(
            operation="thread_distillation",
            percentage=65,
            message=f"[1/3] Extraction done: {len(all_entities)} entities",
            details={"stage": "extraction_complete", "total_entities": len(all_entities)}
        )

        # Fast filtering
        fast_reflected = remote_extraction.reflect_on_extraction_fast({
            "entities": all_entities,
            "relationships": all_relationships,
        })
        pre_filter = len(all_entities)
        all_entities = fast_reflected.get("entities", all_entities)
        all_relationships = fast_reflected.get("relationships", all_relationships)
        filtered_out = pre_filter - len(all_entities)

        log_progress(
            operation="thread_distillation",
            percentage=68,
            message=f"[2/3] Filter: {len(all_entities)} entities ({filtered_out} removed)",
            details={"stage": "filter", "entities": len(all_entities), "filtered_out": filtered_out}
        )

        # Parallel polish + dedup
        log_progress(
            operation="thread_distillation",
            percentage=69,
            message=f"[3/3] Running polish + dedup in parallel...",
            details={"stage": "parallel_polish_dedup", "entities": len(all_entities)}
        )

        has_repo = remote_extraction.entity_repository is not None

        async def do_llm_reflection():
            return await remote_extraction.reflect_on_extraction_parallel(
                entities=all_entities, relationships=all_relationships
            )

        async def do_deduplication():
            if not all_entities or not has_repo or remote_extraction.entity_repository is None:
                return [], []

            entity_repo = remote_extraction.entity_repository  # Capture for closure

            async def search_entity(entity):
                query = f"{entity['name']} {entity.get('description', '')}"
                existing = await entity_repo.search_entities_fts(query_text=query, limit=3)
                return entity, existing

            search_results = await asyncio.gather(
                *[search_entity(e) for e in all_entities], return_exceptions=True
            )

            db_candidates = {}
            entities_with_candidates = []
            for result in search_results:
                if isinstance(result, Exception):
                    continue
                entity, existing = result if isinstance(result, tuple) else (result, [])
                if existing:
                    entities_with_candidates.append(entity)
                    for e in existing:
                        if e.id not in db_candidates:
                            db_candidates[e.id] = {
                                "id": e.id,
                                "name": e.name,
                                "type": e.entity_type,
                                "description": e.description,
                            }

            if entities_with_candidates and db_candidates:
                batch_results = await remote_extraction.batch_check_entity_duplicates(
                    new_entities=entities_with_candidates,
                    existing_entities=list(db_candidates.values()),
                )
                return batch_results, entities_with_candidates
            return [], []

        llm_task = asyncio.create_task(do_llm_reflection())
        dedup_task = asyncio.create_task(do_deduplication())

        llm_reflected, dedup_result = await asyncio.gather(llm_task, dedup_task, return_exceptions=True)

        # Apply LLM reflection
        if llm_reflected and not isinstance(llm_reflected, BaseException) and isinstance(llm_reflected, dict):
            for fix in llm_reflected.get("language_fixes", []):
                idx = fix.get("index")
                if idx is not None and idx < len(all_entities):
                    all_entities[idx]["name"] = fix.get("corrected_name", all_entities[idx]["name"])

            for imp in llm_reflected.get("description_improvements", []):
                idx = imp.get("index")
                if idx is not None and idx < len(all_entities):
                    all_entities[idx]["description"] = imp.get("improved", all_entities[idx].get("description", ""))

        # Apply deduplication
        dups_found = 0
        if dedup_result and not isinstance(dedup_result, Exception) and isinstance(dedup_result, tuple) and len(dedup_result) == 2:
            batch_results, entities_with_candidates = dedup_result
            if batch_results:
                for i, result in enumerate(batch_results):
                    if result["is_duplicate"]:
                        entity = entities_with_candidates[i]
                        entity["_is_duplicate"] = True
                        entity["_duplicate_of_id"] = result["matching_id"]
                        entity["_duplicate_of_name"] = result["matching_name"]
                        entity["_duplicate_source"] = "database"
                        dups_found += 1

        log_progress(
            operation="thread_distillation",
            percentage=80,
            message=f"[3/3] Done: {len(all_entities)} entities ({dups_found} duplicates)",
            details={
                "stage": "parallel_complete",
                "total_entities": len(all_entities),
                "total_relationships": len(all_relationships),
                "duplicates": dups_found,
            }
        )

        logger.info("Parallel extraction complete", entities=len(all_entities), relationships=len(all_relationships))

        return EntityExtractionResult(entities=all_entities, relationships=all_relationships, confidence=0.7)
